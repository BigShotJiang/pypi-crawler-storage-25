# v0.1.2 Secrets UX Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make `.env`-based secrets safe and ergonomic out of the box: `das init` scaffolds a `.env` (without overwriting), gitignores `.env`/`.env.*` (allowing `.env.example`), idempotently patches a pre-existing `.gitignore`, and `das source add` appends a per-source block using `<PREFIX>__<KIND>` env-var names.

**Architecture:** All edits localized to `src/das_cli/cli.py` and corresponding tests. New module-level constants (`ENV_TEMPLATE`, `GITIGNORE_SECRETS_BLOCK`) and three small helpers (`_source_env_prefix`, `_gitignore_already_covers_env`, `_append_source_env_block`). `_source_yml_template` gains a `name` parameter so generated env-var names are namespaced by source.

**Tech Stack:** Python 3, Typer (CLI), pytest + `typer.testing.CliRunner`, `uv` for dependency management.

**Spec:** `docs/superpowers/specs/2026-05-06-secrets-ux-design.md`

---

## File Structure

| File | Role |
|---|---|
| `src/das_cli/cli.py` | All implementation. New constants + 3 helpers + updates to `init` and `source_add`. |
| `tests/unit/test_cli_secrets.py` | **NEW.** Unit tests for the two pure helpers (`_source_env_prefix`, `_gitignore_already_covers_env`). |
| `tests/integration/test_cli_init.py` | Extended with `.env` and `.gitignore` integration cases. |
| `tests/integration/test_cli_source_add.py` | Extended with namespaced env-var assertions and per-source `.env` append cases. |

Helpers live as module-level functions in `cli.py` (not exported, prefix `_`). Keeping them in one module avoids inventing a new package; the file is still small enough.

---

## Task 1: `_source_env_prefix` normalization helper

Pure function: source name → uppercase env-var prefix. Replaces any run of non-alphanumerics with a single `_`, strips leading/trailing `_`. Empty result is a usage error (handled by callers, not the helper).

**Files:**
- Create: `tests/unit/test_cli_secrets.py`
- Modify: `src/das_cli/cli.py` (add helper after the `_VALID_*` constants block, before `_source_yml_template`)

- [ ] **Step 1: Write the failing tests**

Create `tests/unit/test_cli_secrets.py`:

```python
"""Unit tests for the small helpers added in v0.1.2 (secrets UX)."""

from __future__ import annotations

import pytest

from das_cli.cli import _source_env_prefix


@pytest.mark.parametrize(
    "name,expected",
    [
        ("northwind", "NORTHWIND"),
        ("Northwind", "NORTHWIND"),
        ("my-source", "MY_SOURCE"),
        ("acme.api", "ACME_API"),
        ("a__b", "A_B"),
        ("__leading", "LEADING"),
        ("trailing__", "TRAILING"),
        ("a1b2", "A1B2"),
        ("mixed-case_NAME", "MIXED_CASE_NAME"),
    ],
)
def test_source_env_prefix_normalizes(name: str, expected: str) -> None:
    assert _source_env_prefix(name) == expected


def test_source_env_prefix_rejects_no_alnum() -> None:
    assert _source_env_prefix("___") == ""
    assert _source_env_prefix("---") == ""
    assert _source_env_prefix("") == ""
```

- [ ] **Step 2: Run test to verify it fails**

```
uv run pytest tests/unit/test_cli_secrets.py -v
```

Expected: `ImportError` — `cannot import name '_source_env_prefix' from 'das_cli.cli'`.

- [ ] **Step 3: Implement the helper**

Add this near the top of `src/das_cli/cli.py`, just below the `_VALID_AUTH_TYPES = {...}` line (around line 140):

```python
import re as _re

_NON_ALNUM_RE = _re.compile(r"[^A-Z0-9]+")


def _source_env_prefix(name: str) -> str:
    """Normalize a source name into an uppercase env-var prefix.

    Replaces any run of non-alphanumerics with a single underscore and
    strips leading/trailing underscores. Returns "" if the name has no
    alphanumeric characters; callers should treat that as a usage error.
    """
    upper = name.upper()
    collapsed = _NON_ALNUM_RE.sub("_", upper)
    return collapsed.strip("_")
```

(The `import re as _re` keeps it private; if `re` is already imported elsewhere in the file, plain `import re` at the top is fine and the helper can use `re.compile` directly. As of this task `cli.py` imports only `os`, `pathlib.Path`, `typing.Annotated`, and `typer`, so adding `import re` at the top with the other stdlib imports is the cleanest move.)

Final form (add `import re` to the top stdlib block, drop the `_re` alias):

```python
# top of file, with the other stdlib imports
import os
import re
from pathlib import Path

# ... later, after _VALID_AUTH_TYPES = {...}
_NON_ALNUM_RE = re.compile(r"[^A-Z0-9]+")


def _source_env_prefix(name: str) -> str:
    """Normalize a source name into an uppercase env-var prefix.

    Replaces any run of non-alphanumerics with a single underscore and
    strips leading/trailing underscores. Returns "" if the name has no
    alphanumeric characters; callers should treat that as a usage error.
    """
    upper = name.upper()
    collapsed = _NON_ALNUM_RE.sub("_", upper)
    return collapsed.strip("_")
```

- [ ] **Step 4: Run tests to verify they pass**

```
uv run pytest tests/unit/test_cli_secrets.py -v
```

Expected: 10 passed (9 parametrize cases + 1 reject case).

- [ ] **Step 5: Commit**

```
git add tests/unit/test_cli_secrets.py src/das_cli/cli.py
git commit -m "feat(cli): add _source_env_prefix env-var name normalizer"
```

---

## Task 2: `_gitignore_already_covers_env` detection helper

Pure function: given a `.gitignore`'s text, return `True` if any non-comment line equals exactly `.env` (after stripping). `.env.*` and `!.env.example` alone do **not** count — only the unqualified `.env` line satisfies the contract.

**Files:**
- Modify: `tests/unit/test_cli_secrets.py` (extend)
- Modify: `src/das_cli/cli.py` (add helper next to `_source_env_prefix`)

- [ ] **Step 1: Write the failing tests**

Append to `tests/unit/test_cli_secrets.py`:

```python
from das_cli.cli import _gitignore_already_covers_env


def test_gitignore_covers_env_when_present() -> None:
    text = ".dlt/\n.env\nlanding/\n"
    assert _gitignore_already_covers_env(text) is True


def test_gitignore_covers_env_with_surrounding_whitespace() -> None:
    assert _gitignore_already_covers_env("   .env  \n") is True


def test_gitignore_does_not_count_glob_only() -> None:
    text = ".env.*\n!.env.example\n"
    assert _gitignore_already_covers_env(text) is False


def test_gitignore_does_not_count_comment() -> None:
    text = "# .env is gitignored elsewhere\n"
    assert _gitignore_already_covers_env(text) is False


def test_gitignore_does_not_count_negation() -> None:
    text = "!.env\n"
    assert _gitignore_already_covers_env(text) is False


def test_gitignore_empty_returns_false() -> None:
    assert _gitignore_already_covers_env("") is False
```

- [ ] **Step 2: Run tests to verify they fail**

```
uv run pytest tests/unit/test_cli_secrets.py -v
```

Expected: ImportError on `_gitignore_already_covers_env`.

- [ ] **Step 3: Implement the helper**

Add directly under `_source_env_prefix` in `src/das_cli/cli.py`:

```python
def _gitignore_already_covers_env(text: str) -> bool:
    """Return True if `text` contains a non-comment line equal to `.env`.

    Only the unqualified `.env` pattern satisfies the contract; `.env.*`,
    `!.env.example`, and comments are ignored. Used by `das init` to decide
    whether a pre-existing `.gitignore` already protects the user's secrets.
    """
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or line.startswith("!"):
            continue
        if line == ".env":
            return True
    return False
```

- [ ] **Step 4: Run tests to verify they pass**

```
uv run pytest tests/unit/test_cli_secrets.py -v
```

Expected: 16 passed (10 from Task 1 + 6 new).

- [ ] **Step 5: Commit**

```
git add tests/unit/test_cli_secrets.py src/das_cli/cli.py
git commit -m "feat(cli): add _gitignore_already_covers_env detector"
```

---

## Task 3: `das init` scaffolds `.env` (without overwriting)

Add the `ENV_TEMPLATE` constant and extend `init` to write `.env` if missing, leave it alone if present (even with `--force`).

**Files:**
- Modify: `tests/integration/test_cli_init.py` (add three tests)
- Modify: `src/das_cli/cli.py` (add `ENV_TEMPLATE`; extend `init`)

- [ ] **Step 1: Write the failing tests**

Append to `tests/integration/test_cli_init.py`:

```python
def test_init_writes_env_when_missing(workspace: Path, cli_runner: CliRunner) -> None:
    result = cli_runner.invoke(app, ["init"])
    assert result.exit_code == 0, result.stdout + result.stderr

    env_path = workspace / ".env"
    assert env_path.is_file()
    text = env_path.read_text()
    # Workspace overrides remain commented so a fresh `das ingest` works.
    assert "# DAS_TARGET_DB=" in text
    assert "# DAS_LANDING_URL=" in text
    # Header marking where source credentials get appended.
    assert "Source credentials" in text


def test_init_does_not_overwrite_existing_env(
    workspace: Path, cli_runner: CliRunner
) -> None:
    sentinel = "USER_SECRET=do-not-touch\n"
    (workspace / ".env").write_text(sentinel)

    result = cli_runner.invoke(app, ["init"])
    assert result.exit_code == 0

    assert (workspace / ".env").read_text() == sentinel


def test_init_force_does_not_overwrite_env(
    workspace: Path, cli_runner: CliRunner
) -> None:
    sentinel = "USER_SECRET=do-not-touch\n"
    (workspace / ".env").write_text(sentinel)
    # `das.yaml` must exist for `--force` to be exercised meaningfully.
    (workspace / "das.yaml").write_text("# placeholder\n")

    result = cli_runner.invoke(app, ["init", "--force"])
    assert result.exit_code == 0

    assert (workspace / ".env").read_text() == sentinel
```

- [ ] **Step 2: Run tests to verify they fail**

```
uv run pytest tests/integration/test_cli_init.py -v
```

Expected: three new tests fail (no `.env` is created today).

- [ ] **Step 3: Add `ENV_TEMPLATE`**

In `src/das_cli/cli.py`, just below `GITIGNORE_TEMPLATE`:

```python
ENV_TEMPLATE = """\
# Workspace overrides (defaults work; uncomment to override)
# DAS_TARGET_DB=./das.duckdb
# DAS_LANDING_URL=./landing

# Source credentials — populated by `das source add`
"""
```

- [ ] **Step 4: Extend `init` to scaffold `.env`**

In `src/das_cli/cli.py`, append the following block to `init` after the existing `gitignore` handling and before `success("workspace initialized")`:

```python
    env_path = cwd / ".env"
    if env_path.exists():
        info(".env exists; not modified")
    else:
        env_path.write_text(ENV_TEMPLATE)
        info(f"wrote {env_path.relative_to(cwd)}")
```

(`--force` deliberately does not flow through here — `.env` is never overwritten.)

- [ ] **Step 5: Run tests to verify they pass**

```
uv run pytest tests/integration/test_cli_init.py -v
```

Expected: all `test_init_*` tests pass (originals + three new).

- [ ] **Step 6: Commit**

```
git add tests/integration/test_cli_init.py src/das_cli/cli.py
git commit -m "feat(init): scaffold .env on workspace init (never overwrite)"
```

---

## Task 4: `das init` extends `.gitignore` idempotently

Refactor `GITIGNORE_TEMPLATE` to include a secrets block; teach `init` to append the secrets block to a pre-existing `.gitignore` only when `.env` isn't already covered.

**Files:**
- Modify: `tests/integration/test_cli_init.py` (add three tests)
- Modify: `src/das_cli/cli.py` (split templates; refactor `init`'s gitignore branch)

- [ ] **Step 1: Write the failing tests**

Append to `tests/integration/test_cli_init.py`:

```python
def test_init_writes_gitignore_with_secrets_block(
    workspace: Path, cli_runner: CliRunner
) -> None:
    result = cli_runner.invoke(app, ["init"])
    assert result.exit_code == 0

    gi = (workspace / ".gitignore").read_text()
    # Original entries preserved.
    assert ".dlt/" in gi
    assert "landing/" in gi
    assert "das.duckdb" in gi
    assert "*.duckdb.wal" in gi
    # Secrets block present.
    assert "\n.env\n" in gi
    assert ".env.*" in gi
    assert "!.env.example" in gi


def test_init_appends_secrets_block_to_existing_gitignore(
    workspace: Path, cli_runner: CliRunner
) -> None:
    original = "node_modules/\n"
    (workspace / ".gitignore").write_text(original)

    result = cli_runner.invoke(app, ["init"])
    assert result.exit_code == 0

    gi = (workspace / ".gitignore").read_text()
    assert gi.startswith(original), "original entries must be preserved at the top"
    assert "\n.env\n" in gi
    assert ".env.*" in gi
    assert "!.env.example" in gi


def test_init_leaves_gitignore_untouched_when_env_already_ignored(
    workspace: Path, cli_runner: CliRunner
) -> None:
    original = "node_modules/\n.env\n"
    (workspace / ".gitignore").write_text(original)

    result = cli_runner.invoke(app, ["init"])
    assert result.exit_code == 0

    assert (workspace / ".gitignore").read_text() == original
```

- [ ] **Step 2: Run tests to verify they fail**

```
uv run pytest tests/integration/test_cli_init.py -v
```

Expected: the three new tests fail (current code only writes `.gitignore` when missing, and the template lacks a secrets block).

- [ ] **Step 3: Refactor templates in `src/das_cli/cli.py`**

Replace the existing `GITIGNORE_TEMPLATE` definition (around lines 98-103) with:

```python
GITIGNORE_SECRETS_BLOCK = """\
# Secrets — never commit
.env
.env.*
!.env.example
"""

GITIGNORE_TEMPLATE = """\
.dlt/
landing/
das.duckdb
*.duckdb.wal

""" + GITIGNORE_SECRETS_BLOCK
```

- [ ] **Step 4: Refactor `init`'s gitignore branch**

In `init`, replace:

```python
    gitignore = cwd / ".gitignore"
    if not gitignore.exists():
        gitignore.write_text(GITIGNORE_TEMPLATE)
        info(f"wrote {gitignore.relative_to(cwd)}")
```

with:

```python
    gitignore = cwd / ".gitignore"
    if not gitignore.exists():
        gitignore.write_text(GITIGNORE_TEMPLATE)
        info(f"wrote {gitignore.relative_to(cwd)}")
    elif _gitignore_already_covers_env(gitignore.read_text()):
        info(".gitignore already ignores .env; not modified")
    else:
        existing = gitignore.read_text()
        sep = "" if existing.endswith("\n") else "\n"
        gitignore.write_text(existing + sep + "\n" + GITIGNORE_SECRETS_BLOCK)
        info("appended secrets block to .gitignore")
```

The `sep` guard ensures we don't smash a no-trailing-newline existing line into our `# Secrets` header. The extra `"\n"` after `sep` produces one blank line between user content and our block.

- [ ] **Step 5: Run tests to verify they pass**

```
uv run pytest tests/integration/test_cli_init.py -v
```

Expected: all init tests pass.

- [ ] **Step 6: Commit**

```
git add tests/integration/test_cli_init.py src/das_cli/cli.py
git commit -m "feat(init): gitignore .env (idempotent on existing files)"
```

---

## Task 5: Namespaced env-var names in `_source_yml_template`

Change `_source_yml_template`'s signature to take the source name and emit `<PREFIX>__<KIND>` env-var references. Update the existing source-add tests to assert the namespaced form.

**Files:**
- Modify: `tests/integration/test_cli_source_add.py` (tighten existing assertions; add one normalization case)
- Modify: `src/das_cli/cli.py` (`_source_yml_template` signature and body; `source_add` call site)

- [ ] **Step 1: Tighten the failing tests**

In `tests/integration/test_cli_source_add.py`, replace the assertion line in `test_source_add_with_bearer_auth`:

```python
    assert "{{ env_var" in raw["auth"]["token"]
```

with:

```python
    assert raw["auth"]["token"] == "{{ env_var('NORTHWIND__TOKEN') }}"
```

Then append a new test for normalization:

```python
def test_source_add_normalizes_source_name_for_env_var(
    workspace: Path, cli_runner: CliRunner
) -> None:
    cli_runner.invoke(app, ["init"])
    result = cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "my-source",
            "--type",
            "openapi",
            "--url",
            "https://e/x",
            "--auth",
            "bearer",
        ],
    )
    assert result.exit_code == 0, result.stdout + result.stderr
    raw = yaml.safe_load(
        (workspace / "contracts" / "my-source" / "_source.yml").read_text()
    )
    assert raw["auth"]["token"] == "{{ env_var('MY_SOURCE__TOKEN') }}"
```

- [ ] **Step 2: Run tests to verify they fail**

```
uv run pytest tests/integration/test_cli_source_add.py -v
```

Expected: the bearer-auth test fails (current template uses bare `TOKEN`); the new test fails for the same reason.

- [ ] **Step 3: Update `_source_yml_template`**

Replace the existing `_source_yml_template` (around lines 143-171) with:

```python
def _source_yml_template(name: str, source_type: str, url: str, auth_type: str) -> str:
    prefix = _source_env_prefix(name)
    auth_block = "  type: none"
    if auth_type == "bearer":
        auth_block = (
            f"  type: bearer\n  token: \"{{{{ env_var('{prefix}__TOKEN') }}}}\""
        )
    elif auth_type == "basic":
        auth_block = (
            "  type: basic\n"
            f"  username: \"{{{{ env_var('{prefix}__USERNAME') }}}}\"\n"
            f"  password: \"{{{{ env_var('{prefix}__PASSWORD') }}}}\""
        )
    elif auth_type == "api_key":
        auth_block = (
            f"  type: api_key\n  key: \"{{{{ env_var('{prefix}__API_KEY') }}}}\""
        )

    spec = ""
    if source_type == "odata":
        spec = f"spec:\n  kind: odata\n  metadata_url: {url.rstrip('/')}/$metadata\n"
    elif source_type in {"openapi", "rest"}:
        spec = f"spec:\n  kind: openapi\n  swagger_url: {url.rstrip('/')}/swagger.json\n"
    else:
        spec = "spec:\n  kind: none\n"

    return (
        f"type: {source_type}\n"
        f"endpoint: {url}\n"
        f"{spec}"
        f"auth:\n{auth_block}\n"
        f"ownership:\n  team: data-platform\n"
    )
```

- [ ] **Step 4: Update the call site in `source_add`**

In `source_add` (around line 199), reject empty-prefix names just before writing, then pass `name` to the template:

```python
    if auth != "none" and not _source_env_prefix(name):
        die(
            f"Source name '{name}' has no alphanumeric characters; "
            "cannot derive an env-var prefix.",
            code=USAGE,
        )

    src_dir.mkdir(parents=True, exist_ok=False)
    (src_dir / "_source.yml").write_text(_source_yml_template(name, type_, url, auth))
```

(The empty-prefix check is gated on `auth != "none"` because a none-auth source generates no env-var references and the user is free to use whatever name they want.)

- [ ] **Step 5: Run tests to verify they pass**

```
uv run pytest tests/integration/test_cli_source_add.py -v
```

Expected: all source_add tests pass, including the new normalization case.

- [ ] **Step 6: Commit**

```
git add tests/integration/test_cli_source_add.py src/das_cli/cli.py
git commit -m "feat(source add): namespace env-var names as <PREFIX>__<KIND>"
```

---

## Task 6: `das source add` appends per-source `.env` block

Add `_append_source_env_block(name, auth_type)` and wire it into `source_add`. Idempotent on a header line `# <name> (<auth_type>)`. Skip entirely for `--auth none`. Create `.env` from `ENV_TEMPLATE` if missing.

**Files:**
- Modify: `tests/integration/test_cli_source_add.py` (add five tests)
- Modify: `src/das_cli/cli.py` (add helper; call from `source_add`)

- [ ] **Step 1: Write the failing tests**

Append to `tests/integration/test_cli_source_add.py`:

```python
def test_source_add_appends_env_block_bearer(
    workspace: Path, cli_runner: CliRunner
) -> None:
    cli_runner.invoke(app, ["init"])
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "northwind",
            "--type",
            "openapi",
            "--url",
            "https://e/x",
            "--auth",
            "bearer",
        ],
    )

    env = (workspace / ".env").read_text()
    assert "# northwind (bearer)" in env
    assert "NORTHWIND__TOKEN=" in env


def test_source_add_appends_env_block_basic(
    workspace: Path, cli_runner: CliRunner
) -> None:
    cli_runner.invoke(app, ["init"])
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "north",
            "--type",
            "openapi",
            "--url",
            "https://e/x",
            "--auth",
            "basic",
        ],
    )

    env = (workspace / ".env").read_text()
    assert "# north (basic)" in env
    assert "NORTH__USERNAME=" in env
    assert "NORTH__PASSWORD=" in env


def test_source_add_appends_env_block_api_key(
    workspace: Path, cli_runner: CliRunner
) -> None:
    cli_runner.invoke(app, ["init"])
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "north",
            "--type",
            "openapi",
            "--url",
            "https://e/x",
            "--auth",
            "api_key",
        ],
    )

    env = (workspace / ".env").read_text()
    assert "# north (api_key)" in env
    assert "NORTH__API_KEY=" in env


def test_source_add_none_auth_does_not_modify_env(
    workspace: Path, cli_runner: CliRunner
) -> None:
    cli_runner.invoke(app, ["init"])
    before = (workspace / ".env").read_text()

    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "public",
            "--type",
            "openapi",
            "--url",
            "https://e/x",
            "--auth",
            "none",
        ],
    )

    after = (workspace / ".env").read_text()
    assert before == after


def test_source_add_creates_env_when_missing(
    workspace: Path, cli_runner: CliRunner
) -> None:
    cli_runner.invoke(app, ["init"])
    (workspace / ".env").unlink()  # simulate user having deleted it

    result = cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "northwind",
            "--type",
            "openapi",
            "--url",
            "https://e/x",
            "--auth",
            "bearer",
        ],
    )
    assert result.exit_code == 0

    env = (workspace / ".env").read_text()
    # File was recreated from ENV_TEMPLATE plus the per-source block.
    assert "Source credentials" in env
    assert "# northwind (bearer)" in env
    assert "NORTHWIND__TOKEN=" in env
```

- [ ] **Step 2: Run tests to verify they fail**

```
uv run pytest tests/integration/test_cli_source_add.py -v
```

Expected: all five new tests fail (no `.env` mutation happens today).

- [ ] **Step 3: Implement the helper**

Add `_append_source_env_block` near `_source_yml_template` in `src/das_cli/cli.py`:

```python
def _append_source_env_block(env_path: Path, name: str, auth_type: str) -> str:
    """Append a per-source secrets block to `.env`, creating the file if missing.

    Idempotent: if a line equal to `# <name> (<auth_type>)` is already present
    in `.env`, this is a no-op. Returns one of:
      "wrote"    — created `.env` and added the block
      "appended" — existing `.env` got the block
      "skipped"  — block already present
      "noop"     — auth_type == "none"; nothing to do
    """
    if auth_type == "none":
        return "noop"

    prefix = _source_env_prefix(name)
    if auth_type == "bearer":
        var_lines = [f"{prefix}__TOKEN="]
    elif auth_type == "basic":
        var_lines = [f"{prefix}__USERNAME=", f"{prefix}__PASSWORD="]
    elif auth_type == "api_key":
        var_lines = [f"{prefix}__API_KEY="]
    else:
        return "noop"  # defensive — _VALID_AUTH_TYPES already gates this

    header = f"# {name} ({auth_type})"
    block = "\n" + header + "\n" + "\n".join(var_lines) + "\n"

    if not env_path.exists():
        env_path.write_text(ENV_TEMPLATE + block)
        return "wrote"

    existing = env_path.read_text()
    for raw_line in existing.splitlines():
        if raw_line.strip() == header:
            return "skipped"

    sep = "" if existing.endswith("\n") else "\n"
    env_path.write_text(existing + sep + block)
    return "appended"
```

- [ ] **Step 4: Wire it into `source_add`**

After the `_source_yml_template` write inside `source_add`, add:

```python
    env_path = Path(".env")
    status = _append_source_env_block(env_path, name, auth)
    if status == "wrote":
        info(f"wrote {env_path}")
    elif status == "appended":
        info(f"appended {name} block to {env_path}")
    elif status == "skipped":
        info(f"{env_path} already contains {name} block; not modified")
```

- [ ] **Step 5: Run tests to verify they pass**

```
uv run pytest tests/integration/test_cli_source_add.py -v
```

Expected: every test in that file passes (originals + the five new ones).

- [ ] **Step 6: Commit**

```
git add tests/integration/test_cli_source_add.py src/das_cli/cli.py
git commit -m "feat(source add): append per-source secrets block to .env"
```

---

## Task 7: Final verification

Confirm no regressions across the unit + integration suite, and sanity-check the CLI by hand on a temp workspace.

- [ ] **Step 1: Run the full unit + integration suite**

```
uv run pytest tests/unit tests/integration -q
```

Expected: all passing. Count should be the previous baseline (149) plus 28 new test IDs = 177 (10 prefix incl. 9 parametrize cases + 6 gitignore-detector + 3 init `.env` + 3 init gitignore-extension + 1 source-add normalization + 5 source-add `.env` append). The exact number is informational; what matters is **0 failures** and the count went *up* by ~28.

- [ ] **Step 2: Manual smoke check**

```
mkdir -p /tmp/dasux && cd /tmp/dasux && rm -rf .env .gitignore das.yaml contracts
uv run --project /home/mattiasthalen/repos/das-cli/.claude/worktrees/v0.1.2-secrets-ux das init
cat .env
cat .gitignore
uv run --project /home/mattiasthalen/repos/das-cli/.claude/worktrees/v0.1.2-secrets-ux das source add northwind --type openapi --url https://demodata.grapecity.com/northwind/api/v1 --auth bearer
cat .env
cat contracts/northwind/_source.yml
```

Expected:
- `.env` contains the workspace-overrides comments and a `# northwind (bearer)` block followed by `NORTHWIND__TOKEN=`.
- `.gitignore` contains the existing entries plus `.env`, `.env.*`, `!.env.example`.
- `_source.yml` references `{{ env_var('NORTHWIND__TOKEN') }}`.

Then back to the worktree:

```
cd /home/mattiasthalen/repos/das-cli/.claude/worktrees/v0.1.2-secrets-ux
```

- [ ] **Step 3: No final commit**

The smoke check is read-only — there is no commit at this step. The bundle's commits are Task 1 through Task 6.

---

## Summary of commits this plan produces

1. `feat(cli): add _source_env_prefix env-var name normalizer`
2. `feat(cli): add _gitignore_already_covers_env detector`
3. `feat(init): scaffold .env on workspace init (never overwrite)`
4. `feat(init): gitignore .env (idempotent on existing files)`
5. `feat(source add): namespace env-var names as <PREFIX>__<KIND>`
6. `feat(source add): append per-source secrets block to .env`

Six small, self-contained commits — bisectable and reviewable individually.
