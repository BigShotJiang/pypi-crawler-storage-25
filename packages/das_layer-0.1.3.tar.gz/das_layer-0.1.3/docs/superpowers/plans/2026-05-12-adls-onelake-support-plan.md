# ADLS / OneLake support implementation plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make `landing.bucket_url` and the Delta destination's `bucket_url` accept ADLS Gen2 / OneLake (Fabric) ABFS URLs end-to-end, with two explicit auth modes (`service_principal`, `default`).

**Architecture:** New Pydantic models for `AzureCredentials` (discriminated on `auth`); a `dlt_glue/azure_credentials.py` adapter that produces dlt's typed credential classes for the destination factories; a `dlt_glue/landing_fs.py` fsspec-backed landing reader that replaces the `pathlib`+`gzip.open` reader in `extract.py`/`load.py`. dlt 1.5+ auto-bridges its typed Azure credentials into `object_store` storage_options for the Rust deltalake writer (fix for [dlt#2055][i2055]) — das-cli does not own storage_options plumbing.

**Tech Stack:** Python 3.12+, dlt 1.5+ (Azure-typed credentials + deltalake fix), adlfs (transitively via `dlt[filesystem]`), fsspec, pydantic 2, pytest, python-dotenv (dev-only e2e gate).

**Spec:** `docs/superpowers/specs/2026-05-12-adls-onelake-support-design.md` — read this first.

**ADRs to read before starting:**
- `docs/adrs/0020-azure-landing-and-delta-via-fsspec-and-typed-credentials.md` (drafted alongside the spec; bumped to Accepted in the final task)
- `docs/adrs/0017-delta-destination-via-filesystem-alias.md` (Status annotated; Decision still authoritative for filesystem-alias + per-resource `table_format`)
- `docs/adrs/0016-destination-dispatch-and-pipeline-driven-reads.md` (dispatch + sql_client contract)
- `docs/adrs/0007-secrets-via-env-var-jinja.md` (secrets come in via `{{ env_var(...) }}` — no `.dlt/secrets.toml`)
- `docs/adrs/0013-load-date-semantics.md` (hive partition layout for landing)

**Lifecycle reminder:** ADR-0017 is already on `main`. CLAUDE.md forbids any edit to its Decision / Context / Alternatives / Consequences sections — the only allowed in-place edit is the Status field (which the brainstorming pass already did). Do not "tidy" ADR-0017 during implementation.

[i2055]: https://github.com/dlt-hub/dlt/issues/2055

---

## File structure

**New files:**

| File | Responsibility |
|---|---|
| `src/das_cli/models/das_yaml.py` *(extended)* | `AzureServicePrincipalAuth`, `AzureDefaultAuth`, `AzureCredentials` union, `is_azure_url`, `_parse_azure_credentials` |
| `src/das_cli/dlt_glue/azure_credentials.py` *(new)* | `build_dlt_azure_credentials`, `_adlfs_storage_options` — translates das-cli's `AzureCredentials` into dlt's typed classes and into adlfs kwargs |
| `src/das_cli/dlt_glue/landing_fs.py` *(new)* | `landing_fs`, `iter_landing_records`, `count_landing_records` — fsspec-backed landing reader. Works for both `LocalFileSystem` and `AzureBlobFileSystem` |
| `tests/unit/test_azure_credentials.py` *(new)* | Models, URL detection, dlt-class adapter |
| `tests/unit/test_landing_fs.py` *(new)* | `landing_fs` selection logic + LocalFS read coverage (subsumes the existing `test_load_precount.py` cases) |
| `tests/unit/test_doctor_azure.py` *(new)* | Doctor Azure-credentials checks |
| `tests/integration/test_landing_fs_local.py` *(new)* | LocalFS round-trip on `iter_landing_records` |
| `tests/e2e/destinations/test_delta_azure.py` *(new)* | Opt-in e2e edge: AdventureWorks → Azure landing → Delta on Azure, both auth modes |

**Modified files:**

| File | Change |
|---|---|
| `src/das_cli/pipelines/load.py` | Replace `count_landing_rows(Path)` + `_iter_landing(Path)` with calls into `landing_fs`; wire typed Azure creds in `_build_destination`'s `delta` branch |
| `src/das_cli/pipelines/extract.py` | Replace inline post-extract row-count rglob with `count_landing_records`; build typed Azure creds for the landing `filesystem` destination; lift the `az://` `NotImplementedError` in `reset_extract_state` to use fsspec delete |
| `src/das_cli/cli.py` | One call site at line 801 (`count_landing_rows(landing_root / src.name / c.resource_name)`) — update to new signature; extend the two `startswith` tuples (lines 465, 790) to include `abfs://` / `abfss://` so an Azure URL doesn't fall through into `Path(...).expanduser()` |
| `src/das_cli/doctor.py` | New `_check_azure_credentials` helper; wired into both the landing check (newly added) and the `delta` target check |
| `pyproject.toml` | Bump `dlt[…]>=1.0` → `>=1.5.0`; add `python-dotenv` to the `dev` dependency group |
| `tests/e2e/conftest.py` | Load `.env` via python-dotenv at session start (gated on file existence) |
| `tests/unit/test_destination_dispatch.py` | New cases for `delta` + Azure URL with both auth modes |
| `tests/unit/test_load_precount.py` | **Deleted** — coverage moves to `test_landing_fs.py` |
| `README.md` | Update existing "Delta" row in the verified-destinations matrix to mention Azure / OneLake; cite ADR-0020 |
| `docs/adrs/0020-azure-landing-and-delta-via-fsspec-and-typed-credentials.md` | `Status: Draft` → `Status: Accepted` (final task, after all code commits land) |
| `docs/adrs/README.md` | Update the index row for ADR-0020 to `Accepted` |

---

## Conventions

- **Commit identity:** repo-local already set during the brainstorming pass (`Mattias Thalén <bitter-polders0x@icloud.com>`). If a fresh worktree is created later, re-run `git config --local user.email bitter-polders0x@icloud.com` and `git config --local user.name "Mattias Thalén"` before the first commit.
- **Commit messages:** conventional commits (`feat:`, `test:`, `fix:`, `docs:`, `refactor:`) — see recent history. End every commit with the trailer:
  ```
  Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
  ```
- **Test selection:** `uv run pytest <path>` for individual files; `uv run pytest -m 'not e2e'` for the default suite; e2e tests live behind `@pytest.mark.e2e` via `tests/e2e/conftest.py` and are opt-in.
- **Pre-commit hook:** `uv run pre-commit run --all-files` should pass before each commit. If a hook fails, fix the underlying issue — do not pass `--no-verify`.

---

## Task 1: Pydantic Azure-auth models + URL detection

**Files:**
- Modify: `src/das_cli/models/das_yaml.py`
- Test: `tests/unit/test_azure_credentials.py` (new)

- [ ] **Step 1: Write the failing test**

Create `tests/unit/test_azure_credentials.py`:

```python
"""Unit tests for AzureCredentials Pydantic models and is_azure_url."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from das_cli.models.das_yaml import (
    AzureDefaultAuth,
    AzureServicePrincipalAuth,
    _parse_azure_credentials,
    is_azure_url,
)


def test_is_azure_url_matches_abfss() -> None:
    assert is_azure_url("abfss://lake@acct.dfs.core.windows.net/path") is True


def test_is_azure_url_matches_abfs() -> None:
    assert is_azure_url("abfs://lake@acct.dfs.core.windows.net/path") is True


def test_is_azure_url_matches_az() -> None:
    assert is_azure_url("az://lake/path") is True


def test_is_azure_url_rejects_local_file() -> None:
    assert is_azure_url("file:///tmp/landing") is False


def test_is_azure_url_rejects_bare_path() -> None:
    assert is_azure_url("./landing") is False


def test_is_azure_url_rejects_s3() -> None:
    assert is_azure_url("s3://bucket/key") is False


def test_parse_returns_none_for_non_azure_url() -> None:
    out = _parse_azure_credentials({"some": "thing"}, "./landing")
    assert out is None


def test_parse_service_principal() -> None:
    out = _parse_azure_credentials(
        {
            "auth": "service_principal",
            "tenant_id": "tid",
            "client_id": "cid",
            "client_secret": "secret",
        },
        "abfss://lake@acct.dfs.core.windows.net/path",
    )
    assert isinstance(out, AzureServicePrincipalAuth)
    assert out.tenant_id == "tid"
    assert out.client_id == "cid"
    assert out.client_secret == "secret"


def test_parse_default_auth() -> None:
    out = _parse_azure_credentials(
        {"auth": "default"},
        "abfss://lake@acct.dfs.core.windows.net/path",
    )
    assert isinstance(out, AzureDefaultAuth)


def test_parse_empty_creds_on_azure_url_raises() -> None:
    with pytest.raises(ValidationError):
        _parse_azure_credentials({}, "abfss://lake@acct.dfs.core.windows.net/path")


def test_parse_missing_sp_field_raises() -> None:
    with pytest.raises(ValidationError):
        _parse_azure_credentials(
            {"auth": "service_principal", "tenant_id": "tid", "client_id": "cid"},
            "abfss://lake@acct.dfs.core.windows.net/path",
        )


def test_parse_extra_field_in_default_raises() -> None:
    with pytest.raises(ValidationError):
        _parse_azure_credentials(
            {"auth": "default", "tenant_id": "tid"},
            "abfss://lake@acct.dfs.core.windows.net/path",
        )
```

- [ ] **Step 2: Run test to verify it fails**

```bash
uv run pytest tests/unit/test_azure_credentials.py -v
```

Expected: `ImportError` — `AzureServicePrincipalAuth`, `AzureDefaultAuth`, `_parse_azure_credentials`, `is_azure_url` not in `das_cli.models.das_yaml`.

- [ ] **Step 3: Implement the models and helpers**

Append to `src/das_cli/models/das_yaml.py` (after the existing `DasConfig` class — keep imports grouped at the top):

Add to the existing imports block:

```python
from typing import Annotated, Literal
```

Add to the bottom of the file:

```python
class AzureServicePrincipalAuth(BaseModel):
    """Explicit Azure AD service-principal credentials. See ADR-0020 Decision B."""
    model_config = ConfigDict(extra="forbid")
    auth: Literal["service_principal"]
    tenant_id: str
    client_id: str
    client_secret: str


class AzureDefaultAuth(BaseModel):
    """DefaultAzureCredential chain (env vars / managed identity / az CLI / dev tools).
    See ADR-0020 Decision B."""
    model_config = ConfigDict(extra="forbid")
    auth: Literal["default"]


AzureCredentials = Annotated[
    AzureServicePrincipalAuth | AzureDefaultAuth,
    Field(discriminator="auth"),
]


_AZURE_SCHEMES: tuple[str, ...] = ("az://", "abfs://", "abfss://")


def is_azure_url(url: str) -> bool:
    """True for Azure Blob File System URLs (ADLS Gen2 + OneLake). See ADR-0020 Decision A."""
    return url.startswith(_AZURE_SCHEMES)


def _parse_azure_credentials(
    creds: dict[str, Any], bucket_url: str
) -> AzureServicePrincipalAuth | AzureDefaultAuth | None:
    """Return a typed AzureCredentials when bucket_url is Azure, else None.

    Empty creds on an Azure URL raises ValidationError (discriminator missing).
    See ADR-0020 Decision B: auth is required for Azure URLs."""
    if not is_azure_url(bucket_url):
        return None
    # Use a TypeAdapter so the discriminated union validates from a plain dict.
    from pydantic import TypeAdapter

    return TypeAdapter(AzureCredentials).validate_python(creds)
```

- [ ] **Step 4: Run test to verify it passes**

```bash
uv run pytest tests/unit/test_azure_credentials.py -v
```

Expected: all 12 tests PASS.

- [ ] **Step 5: Lint + type-check**

```bash
uv run ruff check src/das_cli/models/das_yaml.py tests/unit/test_azure_credentials.py
uv run mypy src/das_cli/models/das_yaml.py
```

Expected: clean.

- [ ] **Step 6: Commit**

```bash
git add src/das_cli/models/das_yaml.py tests/unit/test_azure_credentials.py
git commit -m "$(cat <<'EOF'
feat(models): add AzureCredentials discriminated union + is_azure_url

Two-mode auth (service_principal, default) per ADR-0020 Decision B.
Parser raises ValidationError when an Azure URL has empty credentials —
auth is required for Azure landing/target URLs.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 2: dlt credentials bridge

**Files:**
- Create: `src/das_cli/dlt_glue/azure_credentials.py`
- Test: extend `tests/unit/test_azure_credentials.py`

- [ ] **Step 1: Add failing tests to `tests/unit/test_azure_credentials.py`**

Append to the existing test file:

```python
from das_cli.dlt_glue.azure_credentials import (
    _adlfs_storage_options,
    build_dlt_azure_credentials,
)


def test_build_dlt_creds_service_principal_returns_typed_class() -> None:
    from dlt.common.configuration.specs import (
        AzureServicePrincipalCredentialsWithoutDefaults,
    )

    auth = AzureServicePrincipalAuth(
        auth="service_principal",
        tenant_id="tid",
        client_id="cid",
        client_secret="secret",
    )
    out = build_dlt_azure_credentials(auth)
    assert isinstance(out, AzureServicePrincipalCredentialsWithoutDefaults)
    assert out.azure_tenant_id == "tid"
    assert out.azure_client_id == "cid"
    assert out.azure_client_secret == "secret"


def test_build_dlt_creds_default_returns_dlt_azure_credentials() -> None:
    from dlt.common.configuration.specs import AzureCredentials as DltAzureCredentials

    auth = AzureDefaultAuth(auth="default")
    out = build_dlt_azure_credentials(auth)
    assert isinstance(out, DltAzureCredentials)


def test_adlfs_storage_options_service_principal() -> None:
    auth = AzureServicePrincipalAuth(
        auth="service_principal",
        tenant_id="tid",
        client_id="cid",
        client_secret="secret",
    )
    assert _adlfs_storage_options(auth) == {
        "tenant_id": "tid",
        "client_id": "cid",
        "client_secret": "secret",
    }


def test_adlfs_storage_options_default() -> None:
    assert _adlfs_storage_options(AzureDefaultAuth(auth="default")) == {"anon": False}


def test_adlfs_storage_options_none() -> None:
    assert _adlfs_storage_options(None) == {}
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
uv run pytest tests/unit/test_azure_credentials.py -v
```

Expected: 5 new tests fail with `ModuleNotFoundError: No module named 'das_cli.dlt_glue.azure_credentials'`.

- [ ] **Step 3: Implement the adapter**

Create `src/das_cli/dlt_glue/azure_credentials.py`:

```python
"""Translate das-cli's AzureCredentials into dlt's typed Azure credential classes
and into adlfs kwargs. See ADR-0020 Decision D.

dlt's typed credentials produce the right storage_options for both Python adlfs
(landing reads/writes) and the Rust object_store crate (Delta writer). das-cli
does not own storage_options plumbing — this module just produces the typed dlt
instances and the adlfs kwargs.
"""

from __future__ import annotations

from typing import Any

from dlt.common.configuration.specs import (
    AzureCredentials as DltAzureCredentials,
    AzureServicePrincipalCredentialsWithoutDefaults,
)

from das_cli.models.das_yaml import AzureDefaultAuth, AzureServicePrincipalAuth


def build_dlt_azure_credentials(
    creds: AzureServicePrincipalAuth | AzureDefaultAuth,
) -> DltAzureCredentials | AzureServicePrincipalCredentialsWithoutDefaults:
    """Build the dlt credentials object the filesystem destination expects.

    Service-principal → `AzureServicePrincipalCredentialsWithoutDefaults`
        (explicit values, no fallback).
    Default          → `AzureCredentials` (DefaultAzureCredential chain — env vars,
                                           managed identity, az CLI, dev tools).
    """
    if isinstance(creds, AzureServicePrincipalAuth):
        return AzureServicePrincipalCredentialsWithoutDefaults(
            azure_tenant_id=creds.tenant_id,
            azure_client_id=creds.client_id,
            azure_client_secret=creds.client_secret,
        )
    # AzureDefaultAuth — dlt's AzureCredentials wraps DefaultAzureCredential.
    return DltAzureCredentials()


def _adlfs_storage_options(
    creds: AzureServicePrincipalAuth | AzureDefaultAuth | None,
) -> dict[str, Any]:
    """Map AzureCredentials to adlfs's `AzureBlobFileSystem` kwargs.

    Used by `landing_fs` for direct fsspec construction (P2 reads). dlt's
    `to_adlfs_credentials()` does the equivalent translation internally for
    its own filesystem destination; we reproduce a minimal subset for the
    read path because dlt does not expose its filesystem reader for arbitrary
    use.
    """
    if creds is None:
        return {}
    if isinstance(creds, AzureServicePrincipalAuth):
        return {
            "tenant_id": creds.tenant_id,
            "client_id": creds.client_id,
            "client_secret": creds.client_secret,
        }
    # Default chain — adlfs picks up env vars / az CLI / MI when anon=False.
    return {"anon": False}
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
uv run pytest tests/unit/test_azure_credentials.py -v
```

Expected: all 17 tests (12 from task 1 + 5 new) PASS.

- [ ] **Step 5: Lint + type-check**

```bash
uv run ruff check src/das_cli/dlt_glue/azure_credentials.py tests/unit/test_azure_credentials.py
uv run mypy src/das_cli/dlt_glue/
```

Expected: clean.

- [ ] **Step 6: Commit**

```bash
git add src/das_cli/dlt_glue/azure_credentials.py tests/unit/test_azure_credentials.py
git commit -m "$(cat <<'EOF'
feat(dlt_glue): build dlt typed Azure credentials + adlfs storage options

Adapter from das-cli's AzureCredentials union into dlt's typed credential
classes (used by both filesystem destination and the Rust Delta writer
via dlt's auto-bridge for object_store storage_options) and into adlfs
kwargs (used by the fsspec-backed landing reader). See ADR-0020 Decision D.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 3: fsspec-backed landing reader

**Files:**
- Create: `src/das_cli/dlt_glue/landing_fs.py`
- Test: `tests/unit/test_landing_fs.py` (new)
- Test: `tests/integration/test_landing_fs_local.py` (new)

- [ ] **Step 1: Write the unit-test file**

Create `tests/unit/test_landing_fs.py`:

```python
"""Unit tests for the fsspec-backed landing reader."""

from __future__ import annotations

import gzip
from pathlib import Path

import pytest
from fsspec.implementations.local import LocalFileSystem

from das_cli.dlt_glue.landing_fs import (
    count_landing_records,
    iter_landing_records,
    landing_fs,
)
from das_cli.models.das_yaml import LandingConfig


def _local_landing(tmp_path: Path) -> LandingConfig:
    return LandingConfig(bucket_url=str(tmp_path), credentials={})


def test_landing_fs_local_returns_localfs(tmp_path: Path) -> None:
    fs, root = landing_fs(_local_landing(tmp_path))
    assert isinstance(fs, LocalFileSystem)
    assert Path(root) == tmp_path.resolve()


def test_landing_fs_azure_returns_adlfs() -> None:
    # adlfs's AzureBlobFileSystem constructor does not perform a network call.
    pytest.importorskip("adlfs")
    from adlfs import AzureBlobFileSystem

    landing = LandingConfig(
        bucket_url="abfss://lake@acct.dfs.core.windows.net/landing",
        credentials={"auth": "default"},
    )
    fs, _root = landing_fs(landing)
    assert isinstance(fs, AzureBlobFileSystem)


def test_count_plain_jsonl(tmp_path: Path) -> None:
    rdir = tmp_path / "src1" / "products"
    rdir.mkdir(parents=True)
    (rdir / "a.jsonl").write_text('{"x":1}\n{"x":2}\n{"x":3}\n')
    assert count_landing_records(_local_landing(tmp_path), source="src1", resource="products") == 3


def test_count_gzipped_jsonl(tmp_path: Path) -> None:
    rdir = tmp_path / "src1" / "orders"
    rdir.mkdir(parents=True)
    with gzip.open(rdir / "a.jsonl.gz", "wt") as fh:
        fh.write('{"x":1}\n{"x":2}\n')
    assert count_landing_records(_local_landing(tmp_path), source="src1", resource="orders") == 2


def test_count_across_multiple_files(tmp_path: Path) -> None:
    rdir = tmp_path / "src1" / "customers"
    rdir.mkdir(parents=True)
    (rdir / "a.jsonl").write_text('{"x":1}\n{"x":2}\n')
    with gzip.open(rdir / "b.jsonl.gz", "wt") as fh:
        fh.write('{"x":3}\n')
    assert count_landing_records(_local_landing(tmp_path), source="src1", resource="customers") == 3


def test_count_skips_blank_lines(tmp_path: Path) -> None:
    rdir = tmp_path / "src1" / "x"
    rdir.mkdir(parents=True)
    (rdir / "a.jsonl").write_text('{"x":1}\n\n{"x":2}\n\n')
    assert count_landing_records(_local_landing(tmp_path), source="src1", resource="x") == 2


def test_count_zero_for_missing_resource(tmp_path: Path) -> None:
    assert (
        count_landing_records(_local_landing(tmp_path), source="src1", resource="nope") == 0
    )


def test_count_zero_for_empty_resource(tmp_path: Path) -> None:
    (tmp_path / "src1" / "empty").mkdir(parents=True)
    assert count_landing_records(_local_landing(tmp_path), source="src1", resource="empty") == 0


def test_iter_records_yields_dicts(tmp_path: Path) -> None:
    rdir = tmp_path / "src1" / "t"
    rdir.mkdir(parents=True)
    (rdir / "a.jsonl").write_text('{"x":1}\n{"x":2}\n')
    rows = list(iter_landing_records(_local_landing(tmp_path), source="src1", resource="t"))
    assert rows == [{"x": 1}, {"x": 2}]


def test_iter_records_handles_partitioned_layout(tmp_path: Path) -> None:
    # Mirrors ADR-0013: bucket_url/<source>/<table>/_extracted_on=YYYY-MM-DD/<file>
    rdir = tmp_path / "src1" / "products" / "_extracted_on=2026-05-12"
    rdir.mkdir(parents=True)
    (rdir / "1.0.jsonl").write_text('{"id":1}\n')
    rows = list(iter_landing_records(_local_landing(tmp_path), source="src1", resource="products"))
    assert rows == [{"id": 1}]
```

- [ ] **Step 2: Run unit tests to verify they fail**

```bash
uv run pytest tests/unit/test_landing_fs.py -v
```

Expected: all fail with `ModuleNotFoundError: No module named 'das_cli.dlt_glue.landing_fs'`.

- [ ] **Step 3: Implement the helper**

Create `src/das_cli/dlt_glue/landing_fs.py`:

```python
"""fsspec-backed landing reader. See ADR-0020 Decision C.

Replaces the pathlib + gzip.open / builtin open reader in extract.py / load.py.
Local paths flow through fsspec's LocalFileSystem; az:// / abfs:// / abfss://
URLs flow through adlfs's AzureBlobFileSystem. Same code path either way.
"""

from __future__ import annotations

import gzip
import json
from collections.abc import Iterator
from pathlib import Path
from typing import Any

import fsspec
from fsspec.spec import AbstractFileSystem

from das_cli.dlt_glue.azure_credentials import _adlfs_storage_options
from das_cli.models.das_yaml import (
    LandingConfig,
    _parse_azure_credentials,
    is_azure_url,
)


def landing_fs(landing: LandingConfig) -> tuple[AbstractFileSystem, str]:
    """Return (filesystem, root_path) for reading the landing zone.

    For local paths: (LocalFileSystem, absolute_path).
    For Azure URLs: (AzureBlobFileSystem, the URL itself — adlfs paths include
    the container@host portion).
    """
    url = landing.bucket_url
    if is_azure_url(url):
        azure = _parse_azure_credentials(landing.credentials, url)
        opts = _adlfs_storage_options(azure)
        fs, root = fsspec.core.url_to_fs(url, **opts)
        return fs, root
    fs = fsspec.filesystem("file")
    return fs, str(Path(url).expanduser().resolve())


def _resource_glob(root: str, source: str, resource: str) -> str:
    """Glob pattern matching all *.jsonl[.gz] under <root>/<source>/<resource>/."""
    return f"{root.rstrip('/')}/{source}/{resource}/**/*.jsonl*"


def iter_landing_records(
    landing: LandingConfig, *, source: str, resource: str
) -> Iterator[dict[str, Any]]:
    """Yield records from the JSONL landing files under <source>/<resource>/."""
    fs, root = landing_fs(landing)
    pattern = _resource_glob(root, source, resource)
    # fsspec's glob returns sorted paths from LocalFileSystem; for AzureBlobFileSystem
    # we sort explicitly so the iteration order is stable across backends.
    paths = sorted(fs.glob(pattern))
    for path in paths:
        is_gz = path.endswith(".gz")
        with fs.open(path, "rb") as raw:
            if is_gz:
                stream: Any = gzip.open(raw, "rt", encoding="utf-8")
            else:
                stream = (line.decode("utf-8") for line in raw)
            for line in stream:
                line = line.strip()
                if not line:
                    continue
                yield json.loads(line)


def count_landing_records(
    landing: LandingConfig, *, source: str, resource: str
) -> int:
    """Count newline-delimited records (skipping blanks) for one resource."""
    fs, root = landing_fs(landing)
    pattern = _resource_glob(root, source, resource)
    paths = fs.glob(pattern)
    if not paths:
        return 0
    total = 0
    for path in paths:
        is_gz = path.endswith(".gz")
        with fs.open(path, "rb") as raw:
            if is_gz:
                with gzip.open(raw, "rt", encoding="utf-8") as fh:
                    total += sum(1 for line in fh if line.strip())
            else:
                for line in raw:
                    if line.strip():
                        total += 1
    return total
```

- [ ] **Step 4: Run unit tests to verify they pass**

```bash
uv run pytest tests/unit/test_landing_fs.py -v
```

Expected: all 10 tests PASS.

- [ ] **Step 5: Write the integration smoke test**

Create `tests/integration/test_landing_fs_local.py`:

```python
"""Integration test: landing_fs round-trip against LocalFileSystem.

Mirrors the partition layout produced by P1 (ADR-0013) so the test exercises
the same glob shape that production reads."""

from __future__ import annotations

import gzip
import json
from pathlib import Path

from das_cli.dlt_glue.landing_fs import (
    count_landing_records,
    iter_landing_records,
)
from das_cli.models.das_yaml import LandingConfig


def _seed_partition(root: Path, source: str, resource: str, date: str, rows: list[dict]) -> None:
    rdir = root / source / resource / f"_extracted_on={date}"
    rdir.mkdir(parents=True)
    with gzip.open(rdir / "1.0.jsonl.gz", "wt", encoding="utf-8") as fh:
        for r in rows:
            fh.write(json.dumps(r) + "\n")


def test_round_trip_multi_partition(tmp_path: Path) -> None:
    _seed_partition(tmp_path, "src1", "products", "2026-05-10", [{"id": 1}, {"id": 2}])
    _seed_partition(tmp_path, "src1", "products", "2026-05-11", [{"id": 3}])
    _seed_partition(tmp_path, "src1", "orders", "2026-05-12", [{"oid": "a"}])

    landing = LandingConfig(bucket_url=str(tmp_path), credentials={})

    assert count_landing_records(landing, source="src1", resource="products") == 3
    assert count_landing_records(landing, source="src1", resource="orders") == 1
    assert count_landing_records(landing, source="src1", resource="missing") == 0

    products = list(iter_landing_records(landing, source="src1", resource="products"))
    assert sorted(r["id"] for r in products) == [1, 2, 3]
```

- [ ] **Step 6: Run integration test**

```bash
uv run pytest tests/integration/test_landing_fs_local.py -v
```

Expected: PASS.

- [ ] **Step 7: Lint + type-check**

```bash
uv run ruff check src/das_cli/dlt_glue/landing_fs.py tests/unit/test_landing_fs.py tests/integration/test_landing_fs_local.py
uv run mypy src/das_cli/dlt_glue/
```

Expected: clean.

- [ ] **Step 8: Commit**

```bash
git add src/das_cli/dlt_glue/landing_fs.py tests/unit/test_landing_fs.py tests/integration/test_landing_fs_local.py
git commit -m "$(cat <<'EOF'
feat(dlt_glue): fsspec-backed landing reader (landing_fs)

iter_landing_records + count_landing_records via fsspec. LocalFileSystem
for local paths; adlfs for az:// / abfs:// / abfss:// — same call path
either way. See ADR-0020 Decision C.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 4: Swap load.py landing reads to use landing_fs

**Files:**
- Modify: `src/das_cli/pipelines/load.py`
- Modify: `src/das_cli/cli.py` (one call site)
- Delete: `tests/unit/test_load_precount.py` (coverage moved to `tests/unit/test_landing_fs.py`)

- [ ] **Step 1: Confirm baseline tests pass**

```bash
uv run pytest tests/unit/test_load_precount.py tests/integration/test_load_pipeline.py -v
```

Expected: existing tests PASS. (Baseline before refactor.)

- [ ] **Step 2: Remove the old helpers from `load.py`**

In `src/das_cli/pipelines/load.py`:

Delete the entire `count_landing_rows` function (currently around lines 113–134) and the entire `_iter_landing` + `_iter_lines` helpers (currently around lines 136–149). Remove their imports if any become unused (`gzip`, `Path` may still be needed elsewhere — check).

- [ ] **Step 3: Update `_build_load_resource` to use landing_fs**

In `src/das_cli/pipelines/load.py`, change the signature of `_build_load_resource`:

```python
def _build_load_resource(
    contract: LoadedContract,
    *,
    landing: LandingConfig,
    source: str,
    resource: str,
    hash_exclude: set[str],
    primary_key: list[str],
    pipeline: dlt.Pipeline,
    dataset: str,
    schema_contract: dict[str, str],
    table_format: str | None = None,
    progress_handle: ProgressHandle | None = None,
    full: bool = False,
) -> Any:
```

Replace the `_iter_landing(landing_dir)` call inside `_projected_iter` with:

```python
for line in iter_landing_records(landing, source=source, resource=resource):
```

Add the import at the top:

```python
from das_cli.dlt_glue.landing_fs import iter_landing_records
from das_cli.models.das_yaml import LandingConfig
```

- [ ] **Step 4: Update `run_load` to pass the new kwargs**

In `src/das_cli/pipelines/load.py`, inside `run_load`, the existing block that constructs `landing_root` and calls `_build_load_resource(c, landing_dir=...)` becomes:

```python
for src in sources:
    contracts = load_source_contracts(src.path)
    if only_resources:
        wanted = set(only_resources)
        contracts = [c for c in contracts if c.resource_name in wanted]
    if not contracts:
        continue
    dataset = resolve_dataset_name(src.name, prefix=cfg.dataset.prefix)
    for c in contracts:
        hash_exclude = set(
            get_das_value(c.contract.custom_properties, "das.hash_exclude") or []
        )
        res = _build_load_resource(
            c,
            landing=cfg.landing,
            source=src.name,
            resource=c.resource_name,
            hash_exclude=hash_exclude,
            primary_key=primary_keys_for(c.contract),
            pipeline=pipeline,
            dataset=dataset,
            schema_contract=schema_contract,
            table_format=table_format,
            progress_handle=progress_handle,
            full=full,
        )
        resources.append(res)
        dataset_per_resource.append((res, dataset))
```

Remove the `bucket_url = cfg.landing.bucket_url` / `if not bucket_url.startswith(...)` / `landing_root = Path(...)` block at the top of the section — the resource builder now reads through `landing_fs` directly. Remove the `Path` import if it becomes unused.

- [ ] **Step 5: Update the cli.py post-load row-count call**

In `src/das_cli/cli.py`, around line 762–801, replace:

```python
from das_cli.pipelines.load import count_landing_rows, run_load
...
bucket_url = cfg.landing.bucket_url
if not bucket_url.startswith(("s3://", "gs://", "az://", "file://")):
    landing_root = Path(bucket_url).expanduser()
else:
    landing_root = Path(bucket_url)
for src in sources_to_count:
    contracts = load_source_contracts(src.path)
    if only:
        wanted = set(only)
        contracts = [c for c in contracts if c.resource_name in wanted]
    for c in contracts:
        table = c.contract.primary_schema.physicalName or c.resource_name
        totals[table] = count_landing_rows(landing_root / src.name / c.resource_name)
```

with:

```python
from das_cli.dlt_glue.landing_fs import count_landing_records
from das_cli.pipelines.load import run_load
...
for src in sources_to_count:
    contracts = load_source_contracts(src.path)
    if only:
        wanted = set(only)
        contracts = [c for c in contracts if c.resource_name in wanted]
    for c in contracts:
        table = c.contract.primary_schema.physicalName or c.resource_name
        totals[table] = count_landing_records(
            cfg.landing, source=src.name, resource=c.resource_name
        )
```

- [ ] **Step 6: Delete the old precount test file**

```bash
git rm tests/unit/test_load_precount.py
```

Its coverage is now in `tests/unit/test_landing_fs.py` (task 3).

- [ ] **Step 7: Run the full unit + integration suite**

```bash
uv run pytest -m 'not e2e' -v
```

Expected: all PASS. If the existing `test_load_pipeline.py` exercises landing reads, it will now flow through `landing_fs` against a local LandingConfig — no behavior change expected for local paths.

- [ ] **Step 8: Lint + type-check**

```bash
uv run ruff check src/das_cli/pipelines/load.py src/das_cli/cli.py
uv run mypy src/das_cli/
```

Expected: clean.

- [ ] **Step 9: Commit**

```bash
git add src/das_cli/pipelines/load.py src/das_cli/cli.py tests/unit/test_load_precount.py
git commit -m "$(cat <<'EOF'
refactor(load): route landing reads through landing_fs

Drop count_landing_rows + _iter_landing from load.py; replace with
count_landing_records / iter_landing_records from dlt_glue.landing_fs.
_build_load_resource now takes (landing, source, resource) instead of
landing_dir: Path. Local-path behavior is unchanged; the new code path
is also Azure-ready (see ADR-0020 Decision C). Coverage migrates from
test_load_precount.py to test_landing_fs.py.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 5: Swap extract.py post-extract counter to use landing_fs

**Files:**
- Modify: `src/das_cli/pipelines/extract.py`

- [ ] **Step 1: Confirm extract integration tests pass on baseline**

```bash
uv run pytest tests/integration/test_extract_pipeline.py -v
```

Expected: PASS.

- [ ] **Step 2: Replace the inline post-extract counter**

In `src/das_cli/pipelines/extract.py`, inside `run_extract`, replace the trailing block:

```python
# Count rows by inspecting written files (simple, reliable for local v0.1).
summary: dict[str, Any] = {"resources": {}, "total_rows": 0}
landing_path = Path(bucket_url).expanduser() / source_name
for c in contracts:
    rdir = landing_path / c.resource_name
    if not rdir.exists():
        continue
    count = 0
    for f in rdir.rglob("*.jsonl*"):
        if f.suffix == ".gz":
            with gzip.open(f, "rt") as fh:
                count += sum(1 for _ in fh)
        else:
            with f.open("r") as fh:
                count += sum(1 for _ in fh)
    summary["resources"][c.resource_name] = count
    summary["total_rows"] += count

return summary
```

with:

```python
summary: dict[str, Any] = {"resources": {}, "total_rows": 0}
for c in contracts:
    count = count_landing_records(cfg.landing, source=source_name, resource=c.resource_name)
    if count == 0:
        continue
    summary["resources"][c.resource_name] = count
    summary["total_rows"] += count

return summary
```

Add the import at the top of `extract.py`:

```python
from das_cli.dlt_glue.landing_fs import count_landing_records
```

Remove the `gzip` import and the trailing `import gzip` line if it becomes unused. Confirm `Path` is still imported for `reset_extract_state` (it is — leave it).

- [ ] **Step 3: Run extract tests**

```bash
uv run pytest tests/integration/test_extract_pipeline.py -v
```

Expected: PASS. Row counts come from `count_landing_records` now.

- [ ] **Step 4: Run full unit + integration suite**

```bash
uv run pytest -m 'not e2e' -v
```

Expected: all PASS.

- [ ] **Step 5: Lint + type-check**

```bash
uv run ruff check src/das_cli/pipelines/extract.py
uv run mypy src/das_cli/pipelines/extract.py
```

Expected: clean.

- [ ] **Step 6: Commit**

```bash
git add src/das_cli/pipelines/extract.py
git commit -m "$(cat <<'EOF'
refactor(extract): route post-run row count through landing_fs

Drop the inline rglob+gzip loop in run_extract; use count_landing_records.
Same behavior on local paths; ready for Azure landing per ADR-0020.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 6: Lift `reset_extract_state` NotImplementedError for Azure landing

**Files:**
- Modify: `src/das_cli/pipelines/extract.py`
- Modify: `src/das_cli/cli.py` (extend the `startswith` tuple at line 465)
- Test: extend `tests/integration/test_extract_pipeline.py` if it covers `reset_extract_state`; otherwise add a unit test.

- [ ] **Step 1: Check the existing reset_extract_state test coverage**

```bash
grep -n "reset_extract_state" tests/ -r
```

If a test already covers the local-path case, mirror it. Otherwise, write a new unit test below.

- [ ] **Step 2: Write a unit test for reset_extract_state on local landing**

Add (or create) `tests/unit/test_reset_extract_state.py`:

```python
"""Unit tests for reset_extract_state. See ADR-0019, ADR-0020."""

from __future__ import annotations

from pathlib import Path

import pytest

from das_cli.pipelines.extract import reset_extract_state


def _seed_workspace(tmp_path: Path) -> Path:
    (tmp_path / "das.yaml").write_text(
        """\
target:
  destination: duckdb
  credentials: {database: ./das.duckdb}
landing:
  bucket_url: ./landing
  credentials: {}
contracts: {root: ./contracts}
"""
    )
    (tmp_path / "contracts" / "src1").mkdir(parents=True)
    return tmp_path


def test_reset_extract_state_removes_landing_dlt_dirs(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    workspace = _seed_workspace(tmp_path)
    monkeypatch.chdir(workspace)

    src_landing = workspace / "landing" / "src1"
    for sub in ("_dlt_pipeline_state", "_dlt_loads", "_dlt_version"):
        (src_landing / sub).mkdir(parents=True)
        (src_landing / sub / "marker").write_text("x")

    (src_landing / "products").mkdir(parents=True)
    (src_landing / "products" / "data.jsonl").write_text('{"x":1}\n')

    reset_extract_state("src1", workspace / "das.yaml")

    for sub in ("_dlt_pipeline_state", "_dlt_loads", "_dlt_version"):
        assert not (src_landing / sub).exists()
    # Resource data subtree must be left intact.
    assert (src_landing / "products" / "data.jsonl").exists()


def test_reset_extract_state_on_azure_url_uses_fsspec(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Azure URLs no longer raise NotImplementedError; reset uses fsspec.

    We don't have real Azure access in unit tests. Patch `landing_fs` to hand
    out a `MemoryFileSystem` so the rest of reset_extract_state's logic runs
    against an in-process filesystem. The assertion is structural: dlt state
    dirs are removed and resource data is preserved.
    """
    import fsspec

    mem = fsspec.filesystem("memory")
    for sub in ("_dlt_pipeline_state", "_dlt_loads", "_dlt_version"):
        mem.touch(f"/landing/src1/{sub}/marker")
    mem.touch("/landing/src1/products/data.jsonl")

    monkeypatch.setattr(
        "das_cli.pipelines.extract.landing_fs",
        lambda landing: (mem, "/landing"),
    )

    (tmp_path / "das.yaml").write_text(
        """\
target:
  destination: duckdb
  credentials: {database: ./das.duckdb}
landing:
  bucket_url: abfss://lake@acct.dfs.core.windows.net/landing
  credentials: {auth: default}
contracts: {root: ./contracts}
"""
    )
    (tmp_path / "contracts" / "src1").mkdir(parents=True)

    reset_extract_state("src1", tmp_path / "das.yaml")

    for sub in ("_dlt_pipeline_state", "_dlt_loads", "_dlt_version"):
        assert not mem.exists(f"/landing/src1/{sub}")
    assert mem.exists("/landing/src1/products/data.jsonl")
```

- [ ] **Step 3: Run the test to verify the second case fails**

```bash
uv run pytest tests/unit/test_reset_extract_state.py -v
```

Expected: the local-path test PASSES (existing behavior); the Azure-path test FAILS with `NotImplementedError`.

- [ ] **Step 4: Rewrite `reset_extract_state`**

First, hoist the `landing_fs` import to module top in `src/das_cli/pipelines/extract.py` so tests can patch it via `monkeypatch.setattr("das_cli.pipelines.extract.landing_fs", ...)`:

```python
from das_cli.dlt_glue.landing_fs import count_landing_records, landing_fs
```

(`count_landing_records` is already imported from Task 5; just add `landing_fs` next to it.)

Then replace the body of `reset_extract_state`:

```python
def reset_extract_state(source_name: str, config_path: Path | str) -> None:
    """Reset dlt incremental cursor state for one source. See ADR-0019, ADR-0020.

    Wipes both:
      * local `.dlt/pipelines/das_extract__<source>/` (pipeline state dir)
      * landing `<bucket_url>/<source>/_dlt_pipeline_state/`,
        `_dlt_loads/`, `_dlt_version/` (destination-side state files)

    Landing table-data directories are left untouched — P1 remains
    append-only (see ADR-0002). Works against both local paths and Azure
    landing (az:// / abfs:// / abfss://) via fsspec.
    """
    import shutil

    local_state = Path(".dlt/pipelines") / f"das_extract__{source_name}"
    if local_state.exists():
        shutil.rmtree(local_state)

    cfg = load_das_config(config_path)
    fs, root = landing_fs(cfg.landing)
    source_landing = f"{root.rstrip('/')}/{source_name}"
    for sub in ("_dlt_pipeline_state", "_dlt_loads", "_dlt_version"):
        target = f"{source_landing}/{sub}"
        if fs.exists(target):
            fs.rm(target, recursive=True)
```

Remove the `if bucket_url.startswith(("s3://", "gs://", "az://")):` block and the `bucket_url` / `landing_root` derivations from the previous body. Keep the local `import shutil` inside the function — only `landing_fs` needs the module-level promotion.

- [ ] **Step 5: Extend cli.py's `startswith` tuple at line 465**

In `src/das_cli/cli.py`, find the bootstrap-from-sample code:

```python
if not bucket_url.startswith(("s3://", "gs://", "az://", "file://")):
    landing_root = Path(bucket_url).expanduser()
else:
    landing_root = Path(bucket_url)
```

Replace with:

```python
if not bucket_url.startswith(("s3://", "gs://", "az://", "abfs://", "abfss://", "file://")):
    landing_root = Path(bucket_url).expanduser()
else:
    landing_root = Path(bucket_url)
```

This prevents `Path("abfss://...").expanduser()` from running silently. The sample-bootstrap feature still doesn't *work* on Azure landing, but at least it no longer wedges the path. (Sample-bootstrap on Azure is out of scope per the spec's non-goals.)

- [ ] **Step 6: Run the reset_extract_state tests + full suite**

```bash
uv run pytest tests/unit/test_reset_extract_state.py -v
uv run pytest -m 'not e2e' -v
```

Expected: both reset_extract_state tests PASS; full suite PASS.

- [ ] **Step 7: Lint + type-check**

```bash
uv run ruff check src/das_cli/pipelines/extract.py src/das_cli/cli.py tests/unit/test_reset_extract_state.py
uv run mypy src/das_cli/pipelines/extract.py
```

Expected: clean.

- [ ] **Step 8: Commit**

```bash
git add src/das_cli/pipelines/extract.py src/das_cli/cli.py tests/unit/test_reset_extract_state.py
git commit -m "$(cat <<'EOF'
feat(extract): reset_extract_state works on Azure landing (fsspec)

Drop the az:// NotImplementedError; delete dlt state subdirs via fsspec.
cli.py's sample-bootstrap startswith check extends to abfs:// / abfss://
so an Azure URL no longer silently runs through Path.expanduser().
See ADR-0020.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 7: Wire Azure credentials into destination factories

**Files:**
- Modify: `src/das_cli/pipelines/load.py` (`_build_destination` `delta` branch)
- Modify: `src/das_cli/pipelines/extract.py` (filesystem destination construction)
- Test: extend `tests/unit/test_destination_dispatch.py`

- [ ] **Step 1: Write failing dispatch tests**

Append to `tests/unit/test_destination_dispatch.py`:

```python
def test_delta_dispatch_with_azure_url_service_principal() -> None:
    from dlt.common.configuration.specs import (
        AzureServicePrincipalCredentialsWithoutDefaults,
    )

    target = TargetConfig(
        destination="delta",
        credentials={
            "bucket_url": "abfss://lake@acct.dfs.core.windows.net/warehouse",
            "auth": "service_principal",
            "tenant_id": "tid",
            "client_id": "cid",
            "client_secret": "secret",
        },
    )
    dest = _build_destination(target)
    assert dest.destination_type == "dlt.destinations.filesystem"
    creds = dest.config_params["credentials"]
    assert isinstance(creds, AzureServicePrincipalCredentialsWithoutDefaults)


def test_delta_dispatch_with_azure_url_default_auth() -> None:
    from dlt.common.configuration.specs import AzureCredentials as DltAzureCredentials

    target = TargetConfig(
        destination="delta",
        credentials={
            "bucket_url": "abfss://lake@acct.dfs.core.windows.net/warehouse",
            "auth": "default",
        },
    )
    dest = _build_destination(target)
    assert dest.destination_type == "dlt.destinations.filesystem"
    assert isinstance(dest.config_params["credentials"], DltAzureCredentials)


def test_delta_dispatch_with_azure_url_missing_auth_raises() -> None:
    import pydantic

    target = TargetConfig(
        destination="delta",
        credentials={"bucket_url": "abfss://lake@acct.dfs.core.windows.net/warehouse"},
    )
    with pytest.raises(pydantic.ValidationError):
        _build_destination(target)


def test_delta_dispatch_local_url_passes_no_credentials() -> None:
    """Regression: local Delta target still constructs without credentials."""
    target = TargetConfig(destination="delta", credentials={"bucket_url": "./das_delta"})
    dest = _build_destination(target)
    # The local-Delta case forwards credentials=None to dlt's filesystem factory.
    assert dest.config_params.get("credentials") is None
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
uv run pytest tests/unit/test_destination_dispatch.py -v
```

Expected: the four new tests fail (Azure URL goes through the current passthrough and produces no typed credentials).

- [ ] **Step 3: Update `_build_destination`'s delta branch**

In `src/das_cli/pipelines/load.py`, replace the existing `delta` branch:

```python
if name == "delta":
    # See ADR-0017: delta is an alias for filesystem; table_format is per-resource.
    bucket_url = creds.get("bucket_url", "./das_delta")
    return dlt.destinations.filesystem(
        bucket_url=bucket_url,
        enable_dataset_name_normalization=False,
    )
```

with:

```python
if name == "delta":
    # See ADR-0017: delta is an alias for filesystem; table_format is per-resource.
    # See ADR-0020: typed Azure credentials when bucket_url is abfs[s]:// / az://.
    bucket_url = creds.get("bucket_url", "./das_delta")
    azure = _parse_azure_credentials(creds, bucket_url)
    dlt_creds = build_dlt_azure_credentials(azure) if azure else None
    return dlt.destinations.filesystem(
        bucket_url=bucket_url,
        credentials=dlt_creds,
        enable_dataset_name_normalization=False,
    )
```

Add the imports at the top:

```python
from das_cli.dlt_glue.azure_credentials import build_dlt_azure_credentials
from das_cli.models.das_yaml import _parse_azure_credentials
```

- [ ] **Step 4: Wire Azure credentials into the landing filesystem destination**

In `src/das_cli/pipelines/extract.py`, locate the `dlt.destinations.filesystem(...)` call inside `run_extract`:

```python
destination=dlt.destinations.filesystem(
    bucket_url=bucket_url,
    credentials=cfg.landing.credentials or None,
    layout="{table_name}/_extracted_on={curr_date}/{load_id}.{file_id}.{ext}",
),
```

Replace with:

```python
azure = _parse_azure_credentials(cfg.landing.credentials, cfg.landing.bucket_url)
dlt_creds: object = (
    build_dlt_azure_credentials(azure) if azure else (cfg.landing.credentials or None)
)

pipeline = dlt.pipeline(  # type: ignore[call-overload]
    pipeline_name=f"das_extract__{source_name}",
    destination=dlt.destinations.filesystem(
        bucket_url=bucket_url,
        credentials=dlt_creds,
        layout="{table_name}/_extracted_on={curr_date}/{load_id}.{file_id}.{ext}",
    ),
    dataset_name=source_name,
    pipelines_dir=".dlt/pipelines",
    progress=dlt_progress,
)
```

Add the imports at the top of `extract.py`:

```python
from das_cli.dlt_glue.azure_credentials import build_dlt_azure_credentials
from das_cli.models.das_yaml import _parse_azure_credentials
```

- [ ] **Step 5: Run dispatch tests**

```bash
uv run pytest tests/unit/test_destination_dispatch.py -v
```

Expected: all PASS, including the four new Azure cases.

- [ ] **Step 6: Run full suite**

```bash
uv run pytest -m 'not e2e' -v
```

Expected: all PASS.

- [ ] **Step 7: Lint + type-check**

```bash
uv run ruff check src/das_cli/pipelines/
uv run mypy src/das_cli/pipelines/
```

Expected: clean.

- [ ] **Step 8: Commit**

```bash
git add src/das_cli/pipelines/load.py src/das_cli/pipelines/extract.py tests/unit/test_destination_dispatch.py
git commit -m "$(cat <<'EOF'
feat(pipelines): wire Azure credentials into delta and landing destinations

_build_destination's delta branch and extract.py's filesystem destination
both translate cfg.{target,landing}.credentials into a dlt typed Azure
credentials object when the bucket_url is Azure. dlt then bridges the
typed credentials into object_store storage_options for the Rust Delta
writer automatically (fix for dlt#2055). See ADR-0020 Decision D.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 8: Dependency bumps

**Files:**
- Modify: `pyproject.toml`

- [ ] **Step 1: Verify the dlt floor needed for issue #2055's fix**

```bash
gh issue view 2055 --repo dlt-hub/dlt --json closedAt
```

The fix shipped after 2025-01-29. dlt 1.5.0 was published in late January / early February 2025. Verify the changelog mentions the Azure object_store fix:

```bash
curl -sSf https://raw.githubusercontent.com/dlt-hub/dlt/master/CHANGELOG.md | head -200 | grep -iE "azure|object.store|2055|deltalake"
```

If a 1.5.x line mentions the fix, set the floor to that version. If the earliest mention is 1.6.x, set the floor to that. **Record the chosen floor and the matching changelog line in the commit message.**

- [ ] **Step 2: Bump the dlt floor + add python-dotenv to dev**

In `pyproject.toml`, change:

```toml
dependencies = [
    "dlt[deltalake,duckdb,ducklake,filesystem,parquet,sql_database]>=1.0",
```

to (using the version confirmed in step 1 — example shows 1.5.0):

```toml
dependencies = [
    "dlt[deltalake,duckdb,ducklake,filesystem,parquet,sql_database]>=1.5.0",
```

Then in the `[dependency-groups]` `dev` array, append:

```toml
dev = [
    ...existing entries...,
    "python-dotenv>=1.0",
]
```

(Keep alphabetical ordering if the existing list is alphabetised; otherwise append.)

- [ ] **Step 3: Resolve dependencies and verify the existing suite still passes**

```bash
uv sync
uv run pytest -m 'not e2e' -v
```

Expected: lockfile regenerates without conflict; full suite PASSES.

- [ ] **Step 4: Confirm uv.lock changes are reasonable**

```bash
git diff --stat uv.lock pyproject.toml
```

Expected: `pyproject.toml` and `uv.lock` modified. `uv.lock` may pick up newer transitive versions — read the diff and confirm it doesn't include unrelated surprises.

- [ ] **Step 5: Commit**

```bash
git add pyproject.toml uv.lock
git commit -m "$(cat <<'EOF'
build: bump dlt floor + add python-dotenv dev dep

dlt floor lifted to the release that contains the fix for dlt#2055
(default-credentials → object_store storage_options bridge for Azure +
Delta). python-dotenv is added to the dev group only — used by the e2e
conftest to load .env at session start. See ADR-0020.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 9: Doctor — Azure credential validation

**Files:**
- Modify: `src/das_cli/doctor.py`
- Test: `tests/unit/test_doctor_azure.py` (new)

- [ ] **Step 1: Write the failing tests**

Create `tests/unit/test_doctor_azure.py`:

```python
"""Unit tests for doctor's Azure credentials checks. See ADR-0020."""

from __future__ import annotations

from pathlib import Path

import pytest

from das_cli.doctor import run_doctor


def _write_workspace(tmp_path: Path, landing_url: str, target_creds: dict, landing_creds: dict) -> Path:
    import json
    import yaml

    (tmp_path / "contracts").mkdir()
    config = {
        "target": {
            "destination": "delta",
            "credentials": target_creds,
        },
        "landing": {
            "bucket_url": landing_url,
            "credentials": landing_creds,
        },
        "contracts": {"root": "./contracts"},
    }
    (tmp_path / "das.yaml").write_text(yaml.safe_dump(config))
    return tmp_path / "das.yaml"


def _clear_azure_env(monkeypatch: pytest.MonkeyPatch) -> None:
    for var in (
        "AZURE_TENANT_ID",
        "AZURE_CLIENT_ID",
        "AZURE_CLIENT_SECRET",
        "AZURE_USERNAME",
        "AZURE_FEDERATED_TOKEN_FILE",
    ):
        monkeypatch.delenv(var, raising=False)
    # Prepend a directory that does not contain `az` so the shutil.which lookup fails.
    monkeypatch.setenv("PATH", str(Path("/nonexistent")))


def test_doctor_flags_missing_azure_auth_on_landing(tmp_path: Path) -> None:
    cfg = _write_workspace(
        tmp_path,
        landing_url="abfss://lake@acct.dfs.core.windows.net/landing",
        target_creds={"bucket_url": "./das_delta"},
        landing_creds={},
    )
    issues = run_doctor(cfg)
    msgs = [i.message for i in issues if i.component == "landing"]
    assert any("azure credentials invalid" in m for m in msgs)


def test_doctor_flags_missing_azure_auth_on_target(tmp_path: Path) -> None:
    cfg = _write_workspace(
        tmp_path,
        landing_url="./landing",
        target_creds={"bucket_url": "abfss://lake@acct.dfs.core.windows.net/warehouse"},
        landing_creds={},
    )
    issues = run_doctor(cfg)
    msgs = [i.message for i in issues if i.component == "target"]
    assert any("azure credentials invalid" in m for m in msgs)


def test_doctor_warns_on_default_without_env_or_cli(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    _clear_azure_env(monkeypatch)
    cfg = _write_workspace(
        tmp_path,
        landing_url="abfss://lake@acct.dfs.core.windows.net/landing",
        target_creds={"bucket_url": "./das_delta"},
        landing_creds={"auth": "default"},
    )
    issues = run_doctor(cfg)
    msgs = [i.message for i in issues if i.component == "landing"]
    assert any("auth: default" in m and "AZURE_" in m for m in msgs)


def test_doctor_silent_on_default_with_env_present(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    _clear_azure_env(monkeypatch)
    monkeypatch.setenv("AZURE_CLIENT_ID", "cid")
    cfg = _write_workspace(
        tmp_path,
        landing_url="abfss://lake@acct.dfs.core.windows.net/landing",
        target_creds={"bucket_url": "./das_delta"},
        landing_creds={"auth": "default"},
    )
    issues = run_doctor(cfg)
    msgs = [i.message for i in issues if i.component == "landing"]
    assert not any("auth: default" in m for m in msgs)


def test_doctor_silent_on_service_principal(tmp_path: Path) -> None:
    cfg = _write_workspace(
        tmp_path,
        landing_url="abfss://lake@acct.dfs.core.windows.net/landing",
        target_creds={"bucket_url": "./das_delta"},
        landing_creds={
            "auth": "service_principal",
            "tenant_id": "tid",
            "client_id": "cid",
            "client_secret": "secret",
        },
    )
    issues = run_doctor(cfg)
    msgs = [i.message for i in issues if i.component == "landing"]
    assert msgs == []
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
uv run pytest tests/unit/test_doctor_azure.py -v
```

Expected: all 5 tests fail — doctor currently doesn't run any Azure checks.

- [ ] **Step 3: Implement the doctor extension**

In `src/das_cli/doctor.py`, add the helper and wire it into both the target and landing checks.

Add to imports:

```python
import os
import shutil

from pydantic import ValidationError

from das_cli.models.das_yaml import (
    AzureDefaultAuth,
    _parse_azure_credentials,
    is_azure_url,
)
```

Add the helpers (next to `run_doctor`):

```python
def _has_azure_default_credential_hint() -> bool:
    """True if DefaultAzureCredential is likely to find an identity locally.

    Checks env vars and `az` on PATH. No network calls. False negatives are
    accepted (managed identity on an Azure VM produces no env-var or az hint
    but DefaultAzureCredential still works there)."""
    env_keys = (
        "AZURE_TENANT_ID",
        "AZURE_CLIENT_ID",
        "AZURE_CLIENT_SECRET",
        "AZURE_USERNAME",
        "AZURE_FEDERATED_TOKEN_FILE",
    )
    if any(os.environ.get(k) for k in env_keys):
        return True
    if shutil.which("az") is not None:
        return True
    return False


def _check_azure_credentials(component: str, creds: dict, url: str) -> list[DoctorIssue]:
    """Validate Azure credentials shape when the URL is Azure. See ADR-0020."""
    if not is_azure_url(url):
        return []
    try:
        azure = _parse_azure_credentials(creds, url)
    except ValidationError as e:
        return [DoctorIssue(component, f"azure credentials invalid: {e}")]
    # azure is never None here — is_azure_url(url) was true, so the parser either
    # returned a typed instance or raised above.
    assert azure is not None
    if isinstance(azure, AzureDefaultAuth):
        if not _has_azure_default_credential_hint():
            return [
                DoctorIssue(
                    component,
                    "auth: default chosen but no AZURE_* env vars detected and "
                    "`az` not on PATH; this only works on Azure VMs with "
                    "managed identity",
                )
            ]
    return []
```

Wire the helper into `run_doctor`'s target check (alongside the existing destination branches):

```python
    elif cfg.target.destination == "delta":
        # See ADR-0017.
        if not cfg.target.credentials.get("bucket_url"):
            issues.append(DoctorIssue("target", "delta destination missing credentials.bucket_url"))
        else:
            issues.extend(
                _check_azure_credentials("target", cfg.target.credentials, cfg.target.credentials["bucket_url"])
            )
```

And add a new landing check (top-level, alongside the target/per-source checks):

```python
    # Landing — validate Azure credentials when the URL is Azure. See ADR-0020.
    issues.extend(
        _check_azure_credentials("landing", cfg.landing.credentials, cfg.landing.bucket_url)
    )
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
uv run pytest tests/unit/test_doctor_azure.py -v
```

Expected: all 5 tests PASS.

- [ ] **Step 5: Run full suite**

```bash
uv run pytest -m 'not e2e' -v
```

Expected: PASS. (Existing doctor tests should still pass; new ones are additive.)

- [ ] **Step 6: Lint + type-check**

```bash
uv run ruff check src/das_cli/doctor.py tests/unit/test_doctor_azure.py
uv run mypy src/das_cli/doctor.py
```

Expected: clean.

- [ ] **Step 7: Commit**

```bash
git add src/das_cli/doctor.py tests/unit/test_doctor_azure.py
git commit -m "$(cat <<'EOF'
feat(doctor): validate Azure credentials on landing + delta target

Strict shape check (missing auth field, partial service_principal config)
and a best-effort hint when auth: default is chosen but no AZURE_* env
vars or az CLI are detected. Config-typo hygiene only — no live token
fetch. See ADR-0020.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 10: e2e infrastructure — dotenv loading + Azure gating

**Files:**
- Modify: `tests/e2e/conftest.py`

- [ ] **Step 1: Update the e2e conftest**

Replace `tests/e2e/conftest.py` with:

```python
"""e2e fixtures: skip these tests by default; opt in via -m e2e.

Loads .env at repo root once per session (gated on the file existing) so
opt-in cloud edge tests (e.g. the Azure Delta edge) can read their
gating variables without the developer having to source .env manually.
The conftest never reads or logs the env-var values."""

from __future__ import annotations

import os
from pathlib import Path

import pytest


def _load_repo_dotenv_if_present() -> None:
    env_path = Path(__file__).resolve().parents[2] / ".env"
    if not env_path.is_file():
        return
    try:
        from dotenv import load_dotenv
    except ModuleNotFoundError:
        return
    # override=False so values already in the shell win.
    load_dotenv(env_path, override=False)


_load_repo_dotenv_if_present()


def pytest_collection_modifyitems(config: pytest.Config, items: list[pytest.Item]) -> None:
    """Inject the e2e marker into all tests under tests/e2e/."""
    for item in items:
        if "tests/e2e/" in str(item.fspath) or "tests\\e2e\\" in str(item.fspath):
            item.add_marker(pytest.mark.e2e)


def require_azure_e2e() -> None:
    """Skip the calling test unless Azure e2e gating is set up.

    Required variables:
      DAS_E2E_AZURE_BUCKET_URL   base ABFS URL for the test workspace
      AZURE_TENANT_ID            (service-principal variant)
      AZURE_CLIENT_ID            (service-principal variant)
      AZURE_CLIENT_SECRET        (service-principal variant)

    All values stay opaque — never logged or echoed."""
    required = ("DAS_E2E_AZURE_BUCKET_URL", "AZURE_TENANT_ID", "AZURE_CLIENT_ID", "AZURE_CLIENT_SECRET")
    missing = [name for name in required if not os.environ.get(name)]
    if missing:
        pytest.skip(f"Azure e2e gate missing env: {', '.join(missing)}")
```

- [ ] **Step 2: Sanity-check the conftest doesn't break existing e2e collection**

```bash
uv run pytest -m e2e --collect-only -q
```

Expected: existing e2e tests collect normally; no import errors. (You do not need to run them.)

- [ ] **Step 3: Lint**

```bash
uv run ruff check tests/e2e/conftest.py
```

Expected: clean.

- [ ] **Step 4: Commit**

```bash
git add tests/e2e/conftest.py
git commit -m "$(cat <<'EOF'
test(e2e): load .env at session start + require_azure_e2e gate

python-dotenv loads .env if present at repo root (override=False so the
shell wins). require_azure_e2e() skips a test cleanly when the Azure
gating env vars are absent. Values are never read or logged by the
conftest itself.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 11: e2e Delta-on-Azure test

**Files:**
- Create: `tests/e2e/destinations/test_delta_azure.py`

- [ ] **Step 1: Write the e2e test**

Create `tests/e2e/destinations/test_delta_azure.py`:

```python
"""End-to-end edge: AdventureWorks → Azure landing → Delta on Azure.

Opt-in. Gated by DAS_E2E_AZURE_BUCKET_URL + the three AZURE_* SP env
vars. Run with: uv run pytest tests/e2e/destinations/test_delta_azure.py -m e2e -v

See ADR-0020. The base bucket URL is used for both landing
(<base>/Files/landing/<run>) and Delta (<base>/Tables/<run>) so a single
.env entry covers both surfaces. Each test variant uses its own random
run-id subpath so parallel runs don't collide."""

from __future__ import annotations

import os
import uuid
from pathlib import Path

import dlt
import pytest
from typer.testing import CliRunner

from das_cli.cli import app
from tests.e2e.conftest import require_azure_e2e


def _azure_workspace(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    *,
    auth_block: str,
    run_id: str,
) -> tuple[Path, str, str]:
    """Write a das.yaml pointing at Azure landing + Delta target.

    Returns (workspace_path, landing_url, target_bucket_url)."""
    base = os.environ["DAS_E2E_AZURE_BUCKET_URL"].rstrip("/")
    landing_url = f"{base}/Files/landing/{run_id}"
    target_url = f"{base}/Tables/{run_id}"

    monkeypatch.chdir(tmp_path)
    (tmp_path / "das.yaml").write_text(
        f"""\
target:
  destination: delta
  credentials:
    bucket_url: "{target_url}"
{auth_block}
landing:
  bucket_url: "{landing_url}"
{auth_block}
contracts:
  root: ./contracts
dataset:
  prefix: das
defaults:
  write_disposition: append
  change_detection: row_hash
  schema_contract:
    tables: evolve
    columns: freeze
    data_type: freeze
"""
    )
    return tmp_path, landing_url, target_url


def _service_principal_block() -> str:
    return """\
    auth: service_principal
    tenant_id: "{{ env_var('AZURE_TENANT_ID') }}"
    client_id: "{{ env_var('AZURE_CLIENT_ID') }}"
    client_secret: "{{ env_var('AZURE_CLIENT_SECRET') }}"
"""


def _default_auth_block() -> str:
    return """\
    auth: default
"""


def _azure_reader_pipeline(workspace: Path, target_url: str) -> dlt.Pipeline:
    """Reader pipeline for Delta tables on Azure. Shares the writer's
    pipeline_name / pipelines_dir per ADR-0017 Decision C."""
    from das_cli.config import load_das_config
    from das_cli.dlt_glue.azure_credentials import build_dlt_azure_credentials
    from das_cli.models.das_yaml import _parse_azure_credentials

    cfg = load_das_config(workspace / "das.yaml")
    azure = _parse_azure_credentials(cfg.target.credentials, target_url)
    creds = build_dlt_azure_credentials(azure) if azure else None

    return dlt.pipeline(
        pipeline_name="das_load",
        destination=dlt.destinations.filesystem(
            bucket_url=target_url,
            credentials=creds,
            enable_dataset_name_normalization=False,
        ),
        pipelines_dir=str(workspace / ".dlt" / "pipelines"),
    )


def _teardown_run(landing_url: str, target_url: str, auth_block: str) -> None:
    """Best-effort cleanup of the per-run subtrees. Uses the same fsspec
    plumbing as the production code."""
    from das_cli.dlt_glue.azure_credentials import _adlfs_storage_options
    from das_cli.models.das_yaml import _parse_azure_credentials
    import fsspec

    # Reconstruct creds dict from the auth block string.
    creds_dict = (
        {
            "auth": "service_principal",
            "tenant_id": os.environ["AZURE_TENANT_ID"],
            "client_id": os.environ["AZURE_CLIENT_ID"],
            "client_secret": os.environ["AZURE_CLIENT_SECRET"],
        }
        if "service_principal" in auth_block
        else {"auth": "default"}
    )
    azure = _parse_azure_credentials(creds_dict, landing_url)
    opts = _adlfs_storage_options(azure)
    for url in (landing_url, target_url):
        fs, root = fsspec.core.url_to_fs(url, **opts)
        if fs.exists(root):
            fs.rm(root, recursive=True)


@pytest.fixture(params=["service_principal", "default"])
def azure_auth_block(request: pytest.FixtureRequest) -> str:
    if request.param == "service_principal":
        return _service_principal_block()
    return _default_auth_block()


def test_adventureworks_extract_load_azure(
    azure_auth_block: str,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    cli_runner: CliRunner,
) -> None:
    require_azure_e2e()

    run_id = uuid.uuid4().hex[:12]
    workspace, landing_url, target_url = _azure_workspace(
        tmp_path, monkeypatch, auth_block=azure_auth_block, run_id=run_id
    )

    try:
        # source add
        result = cli_runner.invoke(
            app,
            [
                "source",
                "add",
                "adventureworks",
                "--type",
                "odata",
                "--url",
                "https://demodata.grapecity.com/adventureworks/odata/v1",
            ],
        )
        assert result.exit_code == 0, result.stdout + result.stderr

        # bootstrap one resource
        result = cli_runner.invoke(
            app,
            ["contract", "bootstrap", "adventureworks", "--only", "products"],
        )
        assert result.exit_code == 0, result.stdout + result.stderr
        assert (workspace / "contracts" / "adventureworks" / "products.odcs.yaml").is_file()

        # extract → Azure landing
        result = cli_runner.invoke(
            app, ["extract", "adventureworks", "--resource", "products", "--limit", "10"]
        )
        assert result.exit_code == 0, result.stdout + result.stderr

        # load → Delta on Azure
        result = cli_runner.invoke(app, ["load", "adventureworks", "--resource", "products"])
        assert result.exit_code == 0, result.stdout + result.stderr

        # Read back via the reader pipeline.
        reader = _azure_reader_pipeline(workspace, target_url)
        with reader.sql_client() as c:
            rows = c.execute_sql('SELECT COUNT(*) FROM "das__adventureworks".products')
            assert rows is not None
            count = rows[0][0]
            assert 1 <= count <= 10, f"row count {count} outside (0, --limit=10]"

            named_rows = c.execute_sql(
                'SELECT COUNT(*) FROM "das__adventureworks".products WHERE name IS NOT NULL'
            )
            assert named_rows is not None and named_rows[0][0] >= 1

            stamp_rows = c.execute_sql(
                'SELECT COUNT(*) FROM "das__adventureworks".products '
                "WHERE _extracted_at IS NULL OR _extracted_on IS NULL "
                "OR _loaded_at IS NULL OR _loaded_on IS NULL"
            )
            assert stamp_rows is not None and stamp_rows[0][0] == 0

        # Second-cycle: change detection should produce zero new rows.
        result = cli_runner.invoke(app, ["load", "adventureworks", "--resource", "products"])
        assert result.exit_code == 0, result.stdout + result.stderr
        reader = _azure_reader_pipeline(workspace, target_url)
        with reader.sql_client() as c:
            rows = c.execute_sql('SELECT COUNT(*) FROM "das__adventureworks".products')
            assert rows is not None and rows[0][0] == count, "change detection should append zero rows"
    finally:
        _teardown_run(landing_url, target_url, azure_auth_block)
```

- [ ] **Step 2: Sanity-check collection (do not run unless DAS_E2E_AZURE_BUCKET_URL is set)**

```bash
uv run pytest tests/e2e/destinations/test_delta_azure.py -m e2e --collect-only -q
```

Expected: 2 tests collected (one per `auth_block` param).

- [ ] **Step 3: Run the e2e test if .env is populated**

If your `.env` already has `DAS_E2E_AZURE_BUCKET_URL` + the three `AZURE_*` SP vars:

```bash
uv run pytest tests/e2e/destinations/test_delta_azure.py -m e2e -v
```

Expected: both parameterised variants PASS. If `DAS_E2E_AZURE_BUCKET_URL` is missing, both should report SKIP (not FAIL).

- [ ] **Step 4: Lint**

```bash
uv run ruff check tests/e2e/destinations/test_delta_azure.py
```

Expected: clean.

- [ ] **Step 5: Commit**

```bash
git add tests/e2e/destinations/test_delta_azure.py
git commit -m "$(cat <<'EOF'
test(e2e): Delta on Azure edge (service_principal + default auth)

AdventureWorks OData → Azure landing → Delta on Azure, both auth modes
exercised via pytest parametrisation. Gated on DAS_E2E_AZURE_BUCKET_URL
+ AZURE_* env vars; skips cleanly when absent. Per-run subpaths under
.../Files/landing/<run> and .../Tables/<run> keep parallel runs
isolated; teardown deletes both subtrees via fsspec. Reader pipeline
shares writer's pipeline_name/pipelines_dir per ADR-0017 Decision C.
See ADR-0020.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 12: Docs — ADR-0020 status flip + README matrix

**Files:**
- Modify: `docs/adrs/0020-azure-landing-and-delta-via-fsspec-and-typed-credentials.md`
- Modify: `docs/adrs/README.md`
- Modify: `README.md`

- [ ] **Step 1: Flip ADR-0020 to Accepted**

In `docs/adrs/0020-azure-landing-and-delta-via-fsspec-and-typed-credentials.md`, change:

```markdown
- **Status:** Draft
```

to:

```markdown
- **Status:** Accepted
```

- [ ] **Step 2: Update the ADR index**

In `docs/adrs/README.md`, change the ADR-0020 row:

```markdown
| 0020 | Azure landing and Delta destination via fsspec + typed dlt credentials | Draft |
```

to:

```markdown
| 0020 | Azure landing and Delta destination via fsspec + typed dlt credentials | Accepted |
```

- [ ] **Step 3: Run the pre-merge ADR consistency check (per CLAUDE.md)**

```bash
head -1 docs/adrs/0*.md | grep -v "==" | sort > /tmp/headings.txt
grep "^| 00" docs/adrs/README.md | awk -F'|' '{print "# " $2 "." $3}' | sed 's/  / /g; s/  / /g; s/^ //; s/ *$//' > /tmp/index.txt
diff /tmp/headings.txt /tmp/index.txt
```

Expected: empty diff (every ADR file's `# NNNN. <title>` heading appears verbatim in the index).

- [ ] **Step 4: Update the README's verified-destinations matrix**

In `README.md`, find the row:

```markdown
| Delta       | Local Delta tables on filesystem (ADR-0017)            |
```

Replace with:

```markdown
| Delta       | Local filesystem + Azure (ADLS Gen2, OneLake); ADR-0017, ADR-0020 |
```

- [ ] **Step 5: Run the full non-e2e suite as a final smoke check**

```bash
uv run pytest -m 'not e2e' -v
uv run pre-commit run --all-files
```

Expected: PASS / clean.

- [ ] **Step 6: Commit**

```bash
git add docs/adrs/0020-azure-landing-and-delta-via-fsspec-and-typed-credentials.md docs/adrs/README.md README.md
git commit -m "$(cat <<'EOF'
docs: flip ADR-0020 to Accepted; README matrix mentions Azure Delta

Implementation lands; status moves Draft → Accepted. Verified-destinations
matrix updated: Delta now covers local + Azure (ADLS Gen2, OneLake).

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Final verification

- [ ] **Step 1: Run the complete non-e2e suite**

```bash
uv run pytest -m 'not e2e' -v
```

Expected: all PASS.

- [ ] **Step 2: Run pre-commit on all files**

```bash
uv run pre-commit run --all-files
```

Expected: clean.

- [ ] **Step 3: Confirm the ADR ledger is consistent**

```bash
head -1 docs/adrs/0*.md | grep -v "==" | wc -l
grep -c "^| 00" docs/adrs/README.md
```

Expected: both equal `20`.

- [ ] **Step 4: Inspect the commit history**

```bash
git log --oneline origin/main..HEAD
```

Expected: ~12 commits (one per task), each conventional-commit-prefixed, each with the Claude trailer.

- [ ] **Step 5: Optional — run the Azure e2e edge if `.env` is configured**

```bash
uv run pytest tests/e2e/destinations/test_delta_azure.py -m e2e -v
```

Expected: 2 PASS, or 2 SKIP if `.env` is not populated.

---

## Risks & gotchas

- **Path quoting in glob patterns.** `fsspec`'s `glob()` accepts standard shell-style patterns. The `_resource_glob` helper assembles `<root>/<source>/<resource>/**/*.jsonl*`. If a resource name ever contains `*` / `?` / `[]`, this glob misbehaves. das-cli's resource names today are sanitised at bootstrap (no special chars), but it's worth keeping in mind if the rule ever relaxes.
- **`adlfs` token lifetime.** dlt's `AzureCredentialsBase.to_object_store_rs_credentials()` fetches a bearer token from `DefaultAzureCredential.get_token(...)` and passes it as a string. The token has a fixed expiry (~1 hour). For long-running loads, this is a known dlt limitation; not in scope here. If you hit a 401 mid-load, surface it as a follow-up issue against dlt.
- **`reset_extract_state` on Azure deletes _dlt_pipeline_state irreversibly.** Same blast radius as the local case. The unit test in Task 6 covers the dataflow but not concurrency — don't run `--full` against the same source from two machines simultaneously.
- **OneLake name-form URLs.** Spec recommends GUID-form. If a user files a bug against name-form (`abfss://my-workspace@onelake…/my-lake.lakehouse/…`) and the failure is inside adlfs, treat as out-of-scope for das-cli. The dlt docs hard-recommend GUIDs.
- **`config_params["credentials"]` shape.** Task 7's dispatch tests assert on `config_params["credentials"]`. If a future dlt version renames or reshapes that surface, the tests will break — they are the canary, not the contract.
- **`AzureServicePrincipalCredentialsWithoutDefaults` kwarg names.** dlt uses `azure_tenant_id` / `azure_client_id` / `azure_client_secret` (with the `azure_` prefix). The Pydantic model on das-cli's side uses unprefixed names (`tenant_id` / `client_id` / `client_secret`) to match user-friendly YAML. The mapping happens inside `build_dlt_azure_credentials`. If dlt drops the `azure_` prefix in a future version, update only that one function.
