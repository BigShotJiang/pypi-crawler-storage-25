# README Daana Attribution Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Insert a one-line blockquote into `README.md` crediting Daana's two foundational blog posts (the DAS layer concept and contract-driven philosophy).

**Architecture:** Pure documentation edit. Single text insertion between the badge row (line 8) and the `## What it is` heading (line 10). No code, no tests, no behavior changes.

**Tech Stack:** Markdown only.

---

## File Structure

- Modify: `README.md` — insert a 7-line block (5 lines of blockquote + 2 blank lines around it) between line 8 (last badge) and line 10 (`## What it is`).

No new files. No other files touched.

---

## Task 1: Insert Daana attribution blockquote

**Files:**
- Modify: `README.md:8-10`

- [ ] **Step 1: Read README.md to confirm the anchor lines are unchanged**

Run:

```bash
sed -n '7,11p' README.md
```

Expected output (exact match):

```
[![CI](https://github.com/mattiasthalen/das-cli/actions/workflows/ci.yml/badge.svg)](https://github.com/mattiasthalen/das-cli/actions/workflows/ci.yml)
[![License](https://img.shields.io/github/license/mattiasthalen/das-cli.svg)](LICENSE)

## What it is

```

If the output differs (e.g. the file has drifted on main), stop and rebase before continuing.

- [ ] **Step 2: Apply the insertion**

Use the Edit tool with these exact strings.

`old_string`:

```
[![License](https://img.shields.io/github/license/mattiasthalen/das-cli.svg)](LICENSE)

## What it is
```

`new_string`:

```
[![License](https://img.shields.io/github/license/mattiasthalen/das-cli.svg)](LICENSE)

> Built on the **DAS** (Data As System) layer concept and contract-driven
> philosophy from Daana's writing — [The rise of the model-driven data
> engineer](https://blog.daana.dev/blog/the-rise-of-model-driven-data-engineer)
> and [Contract-driven data
> transformation](https://blog.daana.dev/blog/contract-driven-data-transformation).

## What it is
```

- [ ] **Step 3: Verify the diff is exactly the insertion and nothing else**

Run:

```bash
git diff README.md
```

Expected: a single hunk that adds exactly 7 lines (5 blockquote lines + 1 leading blank line + 1 trailing blank line) directly after the License badge line, with no deletions and no other changes.

If the diff includes any other modification, revert with the Edit tool (do not use `git checkout`) and re-do Step 2.

- [ ] **Step 4: Verify the rendered blockquote by reading the surrounding context**

Run:

```bash
sed -n '7,17p' README.md
```

Expected output (exact match):

```
[![CI](https://github.com/mattiasthalen/das-cli/actions/workflows/ci.yml/badge.svg)](https://github.com/mattiasthalen/das-cli/actions/workflows/ci.yml)
[![License](https://img.shields.io/github/license/mattiasthalen/das-cli.svg)](LICENSE)

> Built on the **DAS** (Data As System) layer concept and contract-driven
> philosophy from Daana's writing — [The rise of the model-driven data
> engineer](https://blog.daana.dev/blog/the-rise-of-model-driven-data-engineer)
> and [Contract-driven data
> transformation](https://blog.daana.dev/blog/contract-driven-data-transformation).

## What it is

```

- [ ] **Step 5: Run pre-commit to ensure markdown style hooks pass**

Run:

```bash
uv run pre-commit run --files README.md
```

Expected: all hooks `Passed` (or `Skipped` if not applicable to markdown). If any hook reports `Failed`, read its output, apply the fix it suggests, re-stage, and re-run before committing.

- [ ] **Step 6: Commit**

```bash
git add README.md
git commit -m "$(cat <<'EOF'
docs(readme): credit Daana posts for DAS layer + contract-driven concepts

Adds a one-line blockquote between the badge row and "What it is" linking
"The rise of the model-driven data engineer" and "Contract-driven data
transformation" — the prior art that established das-cli's DAS layer and
contract-as-source-of-truth philosophy. See spec
docs/superpowers/specs/2026-05-13-readme-daana-attribution-design.md.
EOF
)"
```

Expected: commit succeeds, working tree clean (`git status` reports nothing to commit).

---

## Self-Review

- **Spec coverage:** Spec calls for one blockquote between line 8 and line 10 with exact wording. Task 1 inserts that exact text at that exact location. Covered.
- **Placeholder scan:** No TBDs, no "implement later", every step has concrete commands or exact strings.
- **Type consistency:** N/A — no code, no types.
- **Anchor stability:** Step 1 verifies the lines before the edit so the plan is robust to small unrelated README changes that don't touch the insertion site.
