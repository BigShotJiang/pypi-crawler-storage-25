# File-based sources Plan #4: QVD reader

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add Qlik QVD (`.qvd`) support to the `type: filesystem` umbrella so QVD exports can be ingested with row-by-row streaming, native typed values, and rich bootstrap (column **names AND types** inferred from the file's embedded metadata header).

**Architecture:** New `dlt_glue/file_readers/qvd.py` uses `pyqvd.QvdTable.from_stream(<binary>, chunk_size=10_000)` to obtain an `Iterator[QvdTable]`; for each chunk, iterate rows and unwrap `IntegerValue`/`StringValue`/etc. via `.calculation_value` to native Python types. The bootstrap walker grows a `.qvd` branch that reads the file's first chunk to derive both column names and per-column logical types (the QVD format embeds typed metadata, so types aren't string-by-default like csv/excel). `_select_file_reader` dispatches `format=qvd`.

**Tech Stack:** Python 3.12, dlt filesystem source, pyqvd (2.3+, pure Python, MIT), pytest. Adds optional `[qvd]` extra.

**Spec:** `docs/superpowers/specs/2026-05-12-file-based-sources-design.md` (qvd sections).

**Issue:** [#40](https://github.com/mattiasthalen/das-cli/issues/40) (qvd child folded into #49). Umbrella + ADR-0022/0023 already on the branch from Plan #1; csv/excel/xml shipped in Plans #1–#3.

---

## Tasks at a glance

1. Add `pyqvd` to `[qvd]` optional extra + dev dep
2. `file_readers/qvd.py` — streaming reader (from_stream + chunk_size + .calculation_value)
3. Wire `qvd` into `_select_file_reader`
4. Bootstrap `.qvd` walker — names + types from metadata header
5. E2E: `tests/e2e/sources/test_qvd_to_duckdb.py` — fixture built in-test via QvdTable.to_qvd
6. README — add QVD row + quickstart

---

### Task 1: Add `pyqvd` to the `[qvd]` optional extra

**Files:**
- Modify: `pyproject.toml`

- [ ] **Step 1: Inspect the current optional-dependencies + dev structure**

Run: `grep -n "optional-dependencies\|excel\|openpyxl\|lxml\|pyqvd\|qvd" pyproject.toml`
Expected: `[project.optional-dependencies]` already has `excel = ["openpyxl>=3.1"]` (Plan #2) and `xml = ["lxml>=5.2"]` (Plan #3); no `qvd` entry yet.

- [ ] **Step 2: Add the `[qvd]` extra**

Edit `pyproject.toml`. In the `[project.optional-dependencies]` table, add a `qvd` line. The result:

```toml
[project.optional-dependencies]
excel = ["openpyxl>=3.1"]
xml = ["lxml>=5.2"]
qvd = ["pyqvd>=2.3"]
```

Also add `pyqvd>=2.3` to the `dev` list inside `[dependency-groups]`:

```toml
[dependency-groups]
dev = [
    "pytest>=8.0",
    "pytest-cov>=5.0",
    "pytest-xdist>=3.5",
    "responses>=0.25",
    "ruff>=0.5",
    "mypy>=1.10",
    "pre-commit>=3.7",
    "types-PyYAML>=6.0",
    "types-requests>=2.31",
    "testcontainers[oracle,mssql]>=4.0",
    "oracledb>=2.0",
    "pyodbc>=5.0",
    "openpyxl>=3.1",
    "lxml>=5.2",
    "lxml-stubs>=0.5",
    "pyqvd>=2.3",
]
```

(Preserve any other entries already in the dev list; add just the `pyqvd` line.)

- [ ] **Step 3: Sync the lockfile and verify**

Run: `uv sync --all-extras`
Expected: lockfile updates; pyqvd resolves (it pulls a small `tabulate` transitive dep).

Run: `uv run python -c "from pyqvd import QvdTable; print('ok')"`
Expected: prints `ok`.

- [ ] **Step 4: Commit**

```bash
git add pyproject.toml uv.lock
git commit -m "$(cat <<'EOF'
feat(deps): add pyqvd as [qvd] optional + dev dep

Plan #4 of the file-based sources umbrella needs pyqvd's
QvdTable.from_stream(..., chunk_size=...) streaming API. Lives under
the [qvd] optional extra (users opt in); pinned in the dev group so
unit + e2e tests run on default 'uv sync'. pyqvd is pure Python
(MIT) with no native deps.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

- [ ] **Step 5: Verify the commit landed on the branch**

Run: `git log --oneline -3`
Expected: your new commit SHA at HEAD; the Plan #4 doc commit directly below.

---

### Task 2: `file_readers/qvd.py` — streaming reader

**Files:**
- Create: `src/das_cli/dlt_glue/file_readers/qvd.py`
- Test: `tests/unit/dlt_glue/file_readers/test_qvd.py`
- Modify: `tests/unit/dlt_glue/file_readers/__init__.py` (add `make_qvd_bytes` helper)

The reader streams via `pyqvd.QvdTable.from_stream(binary, chunk_size=10_000)`, which returns `Iterator[QvdTable]`. For each chunk, iterate `chunk.data` (rows of typed value objects) and unwrap each cell via `.calculation_value` to get native Python primitives (`int`, `float`, `str`, `datetime.date`, `datetime.datetime`).

QVD's metadata is self-describing, so the reader doesn't need any spec_ref fields beyond `path` and the umbrella basics (`inject`, etc.). No `sheet`, `xpath`, `delimiter`, or `encoding` for qvd.

For blob URLs, `from_stream` accepts any `BinaryIO`. fsspec handles are file-like and seekable enough for pyqvd. No tempfile workaround needed.

- [ ] **Step 1: Add the shared qvd-bytes helper**

Edit `tests/unit/dlt_glue/file_readers/__init__.py`. After the existing `make_xlsx_bytes` function (from Plan #2), append:

```python
def make_qvd_bytes(columns: list[str], rows: list[list[object]]) -> bytes:
    """Build an in-memory QVD file with the given columns + rows.

    Each row is a flat list of native Python values (`int`, `str`, etc.).
    Returns the QVD bytes for use in BytesIO fixtures.
    """
    import io as _io

    from pyqvd import QvdTable

    t = QvdTable.from_dict({"columns": columns, "data": rows})
    buf = _io.BytesIO()
    t.to_stream(buf)
    return buf.getvalue()
```

- [ ] **Step 2: Write the failing QVD reader tests**

Create `tests/unit/dlt_glue/file_readers/test_qvd.py`:

```python
"""Unit tests for the QVD file reader. See ADR-0022."""

from __future__ import annotations

import io
from pathlib import Path

import pytest

from das_cli.contracts.filesystem_spec_ref import FilesystemSpecRef
from das_cli.dlt_glue.file_readers.qvd import read_rows
from tests.unit.dlt_glue.file_readers import make_qvd_bytes


class _FakeFileItem:
    """Stand-in for dlt's FileItemDict — supports `open(mode='rb')` + `file_name`."""

    def __init__(self, body: bytes, file_name: str = "x.qvd"):
        self._body = body
        self.file_name = file_name
        self.file_url = f"file:///fake/{file_name}"
        self.modification_date = "2026-05-13T00:00:00+00:00"

    def open(self, mode: str = "rb") -> io.BytesIO:
        assert mode == "rb"
        return io.BytesIO(self._body)


def _spec(**overrides: object) -> FilesystemSpecRef:
    base: dict[str, object] = {"kind": "filesystem", "format": "qvd", "path": "*.qvd"}
    base.update(overrides)
    return FilesystemSpecRef.model_validate(base)


def test_reads_simple_records() -> None:
    body = make_qvd_bytes(
        columns=["id", "name"],
        rows=[[1, "Alice"], [2, "Bob"]],
    )
    fi = _FakeFileItem(body)
    out = list(read_rows(fi, _spec()))
    assert out == [{"id": 1, "name": "Alice"}, {"id": 2, "name": "Bob"}]


def test_mixed_numeric_and_string_types() -> None:
    body = make_qvd_bytes(
        columns=["product_id", "name", "price"],
        rows=[[10, "Widget", 9.95], [11, "Gadget", 19.50]],
    )
    fi = _FakeFileItem(body)
    out = list(read_rows(fi, _spec()))
    assert out == [
        {"product_id": 10, "name": "Widget", "price": 9.95},
        {"product_id": 11, "name": "Gadget", "price": 19.50},
    ]


def test_inject_basename() -> None:
    body = make_qvd_bytes(columns=["id"], rows=[[1]])
    fi = _FakeFileItem(body, "Q1-2024.qvd")
    out = list(read_rows(fi, _spec(inject={"source_file": "basename"})))
    assert out == [{"id": 1, "source_file": "Q1-2024.qvd"}]


def test_inject_mtime() -> None:
    body = make_qvd_bytes(columns=["id"], rows=[[1]])
    fi = _FakeFileItem(body, "x.qvd")
    out = list(read_rows(fi, _spec(inject={"loaded_at": "mtime"})))
    assert out == [{"id": 1, "loaded_at": "2026-05-13T00:00:00+00:00"}]


def test_empty_table_yields_nothing() -> None:
    """A QVD with columns but no rows yields no records."""
    body = make_qvd_bytes(columns=["id", "name"], rows=[])
    fi = _FakeFileItem(body)
    out = list(read_rows(fi, _spec()))
    assert out == []


def test_streaming_does_not_load_full_file() -> None:
    """Reader must yield rows lazily across chunks, not eagerly materialize.

    We can't easily assert RSS; verify the reader returns a generator that
    hasn't consumed its source after one row is pulled.
    """
    body = make_qvd_bytes(
        columns=["id"],
        rows=[[1], [2], [3], [4], [5]],
    )
    fi = _FakeFileItem(body)
    gen = read_rows(fi, _spec())
    first = next(gen)
    assert first == {"id": 1}
    rest = list(gen)
    assert rest == [{"id": 2}, {"id": 3}, {"id": 4}, {"id": 5}]


def test_many_rows_traverse_multiple_chunks() -> None:
    """Force chunk-boundary crossing: read enough rows that pyqvd's stream emits
    multiple chunks at chunk_size=10_000.

    pyqvd chunks at the reader's request size, so with chunk_size=10_000 a
    25k-row file produces 3 chunks. Verify all rows are emitted in order
    across the boundary.
    """
    rows = [[i] for i in range(25_000)]
    body = make_qvd_bytes(columns=["id"], rows=rows)
    fi = _FakeFileItem(body)
    out = list(read_rows(fi, _spec()))
    assert len(out) == 25_000
    assert out[0] == {"id": 0}
    assert out[10_000] == {"id": 10_000}
    assert out[24_999] == {"id": 24_999}
```

- [ ] **Step 3: Run the failing tests**

Run: `uv run pytest tests/unit/dlt_glue/file_readers/test_qvd.py -v`
Expected: FAIL with `ImportError: cannot import name 'read_rows' from 'das_cli.dlt_glue.file_readers.qvd'`.

- [ ] **Step 4: Write the QVD reader**

Create `src/das_cli/dlt_glue/file_readers/qvd.py`:

```python
"""QVD (Qlik) file reader. See ADR-0022.

Uses pyqvd.QvdTable.from_stream(binary, chunk_size=N) to obtain an
Iterator[QvdTable]; iterates each chunk's rows and unwraps the typed
value objects (IntegerValue, StringValue, etc.) via .calculation_value
to native Python primitives. Never loads the full file — chunk_size
caps the resident-set per yielded chunk.
"""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path
from typing import Any

from das_cli.contracts.filesystem_spec_ref import FilesystemSpecRef
from das_cli.dlt_glue.file_readers._inject import apply_inject

# pyqvd internally chunks at this size; tuned to balance per-chunk
# memory with iteration overhead. 10k rows per chunk fits typical
# wide qvd schemas comfortably under a few MB.
_CHUNK_SIZE = 10_000


def read_rows(file_item: Any, spec_ref: FilesystemSpecRef) -> Iterator[dict[str, Any]]:
    """Yield one dict per row from a QVD file.

    Args:
        file_item: dlt FileItemDict (or stand-in with `open(mode="rb")`,
                   `file_name`, optional `modification_date`).
        spec_ref: Resource spec; `inject` is honored. QVD has no per-resource
                  selectors (the file is self-describing).
    """
    from pyqvd import QvdTable

    context = _build_inject_context(file_item)

    with file_item.open(mode="rb") as binary:
        chunks = QvdTable.from_stream(binary, chunk_size=_CHUNK_SIZE)
        # When chunk_size is set, from_stream returns Iterator[QvdTable].
        # Cast for the type checker; at runtime it's the iterator path.
        chunks_iter: Iterator[QvdTable] = chunks  # type: ignore[assignment]
        yield from apply_inject(
            _rows_from_chunks(chunks_iter),
            inject=spec_ref.inject,
            context=context,
        )


def _rows_from_chunks(chunks: Iterator[Any]) -> Iterator[dict[str, Any]]:
    """For each QvdTable chunk, yield row dicts with unwrapped native values."""
    for chunk in chunks:
        columns = list(chunk.columns)
        for row in chunk.data:
            yield {
                col: _unwrap(cell) for col, cell in zip(columns, row, strict=False)
            }


def _unwrap(cell: Any) -> Any:
    """Pull the native Python value out of a pyqvd typed-value wrapper.

    pyqvd wraps each cell in IntegerValue / StringValue / DoubleValue / etc.
    `.calculation_value` returns the underlying primitive. `None` (missing
    cells) passes through unchanged.
    """
    if cell is None:
        return None
    return getattr(cell, "calculation_value", cell)


def _build_inject_context(file_item: Any) -> dict[str, Any]:
    file_name = getattr(file_item, "file_name", None)
    if file_name is None and hasattr(file_item, "get"):
        file_name = file_item.get("file_name", "")
    file_name = file_name or ""

    file_url = getattr(file_item, "file_url", None)
    if file_url is None and hasattr(file_item, "get"):
        file_url = file_item.get("file_url", "")
    file_url = file_url or ""

    mtime = getattr(file_item, "modification_date", None)
    if mtime is None and hasattr(file_item, "get"):
        mtime = file_item.get("modification_date")

    return {
        "basename": Path(file_name).name if file_name else "",
        "fullpath": file_url,
        "mtime": mtime,
    }
```

- [ ] **Step 5: Run the tests and verify they pass**

Run: `uv run pytest tests/unit/dlt_glue/file_readers/test_qvd.py -v`
Expected: 7 passed.

- [ ] **Step 6: Commit**

```bash
git add src/das_cli/dlt_glue/file_readers/qvd.py tests/unit/dlt_glue/file_readers/test_qvd.py tests/unit/dlt_glue/file_readers/__init__.py
git commit -m "$(cat <<'EOF'
feat(file_readers): QVD reader with chunked streaming + native types

pyqvd.QvdTable.from_stream(binary, chunk_size=10_000) yields an
Iterator[QvdTable]; we walk each chunk's rows and unwrap the typed
value objects (IntegerValue/StringValue/...) via .calculation_value
to native Python primitives. Caps per-chunk memory; rows stream all
the way through to dlt's blob writer.

The make_qvd_bytes helper in
tests/unit/dlt_glue/file_readers/__init__.py uses pyqvd's QvdTable
serialization to build in-memory QVD fixtures for unit tests
without committing binary blobs.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

- [ ] **Step 7: Verify the commit landed on the branch**

Run: `git log --oneline -3`
Expected: your new commit SHA at HEAD.

---

### Task 3: Dispatch `qvd` in `_select_file_reader`

**Files:**
- Modify: `src/das_cli/dlt_glue/source_factory.py` (`_select_file_reader`)
- Test: `tests/unit/test_source_factory_filesystem.py` (extend existing)

The factory currently dispatches `csv`, `excel`, `xml` (Plans #1–#3). Add `qvd`.

- [ ] **Step 1: Write the failing dispatch test**

Append to `tests/unit/test_source_factory_filesystem.py`:

```python
def test_filesystem_qvd_resource_yields_blob_wrapped_rows(tmp_path: Path) -> None:
    """Smoke: write a QVD in tmp_path, dispatch via format=qvd, assert blobs."""
    import io as _io

    from pyqvd import QvdTable

    t = QvdTable.from_dict(
        {"columns": ["id", "name"], "data": [[1, "Alice"], [2, "Bob"]]}
    )
    buf = _io.BytesIO()
    t.to_stream(buf)
    (tmp_path / "customers.qvd").write_bytes(buf.getvalue())

    contracts = [
        _make_fs_contract(
            "customers",
            spec_ref={
                "kind": "filesystem",
                "format": "qvd",
                "path": "customers.qvd",
            },
        )
    ]
    resources = build_extract_resources(
        _fs_scfg(endpoint=str(tmp_path)), contracts, source_name="files"
    )
    out = list(resources[0])
    assert out == [
        {"_data": {"id": 1, "name": "Alice"}},
        {"_data": {"id": 2, "name": "Bob"}},
    ]
```

- [ ] **Step 2: Run the failing test**

Run: `uv run pytest tests/unit/test_source_factory_filesystem.py::test_filesystem_qvd_resource_yields_blob_wrapped_rows -v`
Expected: FAIL — `_select_file_reader` raises `ValueError: No file reader for format 'qvd'`.

- [ ] **Step 3: Extend `_select_file_reader`**

Edit `src/das_cli/dlt_glue/source_factory.py`. Replace the existing function:

```python
def _select_file_reader(format_name: str) -> Any:
    """Return the `read_rows` callable for a given format. See ADR-0022."""
    if format_name == "csv":
        from das_cli.dlt_glue.file_readers import csv as csv_reader

        return csv_reader.read_rows
    if format_name == "excel":
        from das_cli.dlt_glue.file_readers import excel as excel_reader

        return excel_reader.read_rows
    if format_name == "xml":
        from das_cli.dlt_glue.file_readers import xml as xml_reader

        return xml_reader.read_rows
    # qvd lands in a future format PR under ADR-0022.
    raise ValueError(
        f"No file reader for format '{format_name}'. Supported: csv, excel, xml. "
        "(qvd is a planned follow-up.)"
    )
```

with:

```python
def _select_file_reader(format_name: str) -> Any:
    """Return the `read_rows` callable for a given format. See ADR-0022."""
    if format_name == "csv":
        from das_cli.dlt_glue.file_readers import csv as csv_reader

        return csv_reader.read_rows
    if format_name == "excel":
        from das_cli.dlt_glue.file_readers import excel as excel_reader

        return excel_reader.read_rows
    if format_name == "xml":
        from das_cli.dlt_glue.file_readers import xml as xml_reader

        return xml_reader.read_rows
    if format_name == "qvd":
        from das_cli.dlt_glue.file_readers import qvd as qvd_reader

        return qvd_reader.read_rows
    raise ValueError(
        f"No file reader for format '{format_name}'. "
        "Supported: csv, excel, xml, qvd."
    )
```

- [ ] **Step 4: Run the test and verify it passes**

Run: `uv run pytest tests/unit/test_source_factory_filesystem.py -v`
Expected: 7 passed (6 existing + 1 new).

- [ ] **Step 5: Commit**

```bash
git add src/das_cli/dlt_glue/source_factory.py tests/unit/test_source_factory_filesystem.py
git commit -m "$(cat <<'EOF'
feat(source_factory): dispatch format=qvd to file_readers.qvd

Extends _select_file_reader with the qvd branch. All four formats
under ADR-0022's umbrella now have readers; the 'unsupported format'
message no longer enumerates planned follow-ups.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

- [ ] **Step 6: Verify the commit landed on the branch**

Run: `git log --oneline -3`
Expected: your new commit SHA at HEAD.

---

### Task 4: Bootstrap `.qvd` walker — names + types from header

**Files:**
- Modify: `src/das_cli/bootstrap/filesystem.py`
- Test: `tests/unit/test_bootstrap_filesystem.py` (extend existing)

For each `.qvd` found in `endpoint`, open via pyqvd, grab the first chunk (small `chunk_size=1`), extract column names from `chunk.columns` and types from the first row's value classes. Unlike csv/excel/xml (all types default to `string`), QVD gives real types: `IntegerValue` → `integer`, `DoubleValue`/`MoneyValue` → `number`, `StringValue` → `string`, `DateValue` → `date`, `TimestampValue` → `timestamp`. Anything else falls back to `string`.

- [ ] **Step 1: Write the failing bootstrap tests**

Append to `tests/unit/test_bootstrap_filesystem.py`:

```python
def test_qvd_emits_one_contract_per_file(tmp_path: Path) -> None:
    import io as _io

    from pyqvd import QvdTable

    t = QvdTable.from_dict({"columns": ["id"], "data": [[1]]})
    buf = _io.BytesIO()
    t.to_stream(buf)
    (tmp_path / "customers.qvd").write_bytes(buf.getvalue())
    (tmp_path / "orders.qvd").write_bytes(buf.getvalue())

    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files"
    )
    names = sorted(c.resource_name for c in contracts)
    assert names == ["customers", "orders"]


def test_qvd_columns_from_header(tmp_path: Path) -> None:
    import io as _io

    from pyqvd import QvdTable

    t = QvdTable.from_dict(
        {"columns": ["customer_id", "name", "amount"], "data": [[1, "Alice", 9.95]]}
    )
    buf = _io.BytesIO()
    t.to_stream(buf)
    (tmp_path / "x.qvd").write_bytes(buf.getvalue())

    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files"
    )
    schema = contracts[0].contract.primary_schema
    assert [p.name for p in schema.properties] == ["customer_id", "name", "amount"]


def test_qvd_types_inferred_from_value_classes(tmp_path: Path) -> None:
    import io as _io

    from pyqvd import QvdTable

    # IntegerValue → integer, StringValue → string, DoubleValue → number.
    t = QvdTable.from_dict(
        {"columns": ["id", "name", "amount"], "data": [[1, "Alice", 9.95]]}
    )
    buf = _io.BytesIO()
    t.to_stream(buf)
    (tmp_path / "x.qvd").write_bytes(buf.getvalue())

    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files"
    )
    types = {p.name: p.logicalType for p in contracts[0].contract.primary_schema.properties}
    assert types == {"id": "integer", "name": "string", "amount": "number"}


def test_qvd_unknown_type_falls_back_to_string(tmp_path: Path) -> None:
    """When the first cell of a column is None (no value class), default to string."""
    import io as _io

    from pyqvd import QvdTable

    t = QvdTable.from_dict({"columns": ["maybe"], "data": [[None], [None]]})
    buf = _io.BytesIO()
    t.to_stream(buf)
    (tmp_path / "x.qvd").write_bytes(buf.getvalue())

    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files"
    )
    types = [p.logicalType for p in contracts[0].contract.primary_schema.properties]
    assert types == ["string"]


def test_qvd_spec_ref_records_filename(tmp_path: Path) -> None:
    import io as _io

    from pyqvd import QvdTable

    from das_cli.contracts.custom_properties import get_das_value

    t = QvdTable.from_dict({"columns": ["id"], "data": [[1]]})
    buf = _io.BytesIO()
    t.to_stream(buf)
    (tmp_path / "Q1-Sales.qvd").write_bytes(buf.getvalue())

    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files"
    )
    spec_ref = get_das_value(
        contracts[0].contract.custom_properties, "das.spec_ref"
    )
    assert spec_ref == {
        "kind": "filesystem",
        "format": "qvd",
        "path": "Q1-Sales.qvd",
    }


def test_qvd_empty_table_emits_contract_with_no_properties(tmp_path: Path) -> None:
    """A QVD with columns but zero rows yields a contract with column names but no types."""
    import io as _io

    from pyqvd import QvdTable

    t = QvdTable.from_dict({"columns": ["id", "name"], "data": []})
    buf = _io.BytesIO()
    t.to_stream(buf)
    (tmp_path / "x.qvd").write_bytes(buf.getvalue())

    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files"
    )
    types = [p.logicalType for p in contracts[0].contract.primary_schema.properties]
    # No rows to type-infer from; default to string.
    assert types == ["string", "string"]
```

- [ ] **Step 2: Run the failing tests**

Run: `uv run pytest tests/unit/test_bootstrap_filesystem.py -v -k qvd`
Expected: all 6 new tests FAIL — the walker only handles `.csv`, `.xlsx`, `.xml`.

- [ ] **Step 3: Extend the bootstrap walker for `.qvd`**

Edit `src/das_cli/bootstrap/filesystem.py`. Inside the `for path in sorted(root.iterdir())` loop, replace:

```python
        suffix = path.suffix.lower()
        if suffix == ".csv":
            out.append(_build_csv_contract(path, source_name=source_name))
        elif suffix == ".xlsx":
            out.extend(_build_excel_contracts(path, source_name=source_name))
        elif suffix == ".xml":
            if not xpath:
                raise ValueError(
                    "--xpath is required for filesystem bootstrap with .xml files"
                )
            out.append(
                _build_xml_contract(path, source_name=source_name, xpath=xpath)
            )
        # qvd dispatch lands in its follow-up plan under ADR-0022.
```

with:

```python
        suffix = path.suffix.lower()
        if suffix == ".csv":
            out.append(_build_csv_contract(path, source_name=source_name))
        elif suffix == ".xlsx":
            out.extend(_build_excel_contracts(path, source_name=source_name))
        elif suffix == ".xml":
            if not xpath:
                raise ValueError(
                    "--xpath is required for filesystem bootstrap with .xml files"
                )
            out.append(
                _build_xml_contract(path, source_name=source_name, xpath=xpath)
            )
        elif suffix == ".qvd":
            out.append(_build_qvd_contract(path, source_name=source_name))
```

Update the docstring directly under `def bootstrap_filesystem_contracts(...)` to reflect QVD support. Find:

```python
    """Walk `scfg.endpoint` and emit one ODCS contract per discoverable file.

    Plan #1 supports CSV; Plan #2 supports Excel; Plan #3 supports XML.
    QVD discovery lands in Plan #4.

    `xpath` (optional) is the XPath expression used to extract records from
    each .xml file. Required only if the endpoint contains .xml files;
    csv/xlsx don't use it.

    Local paths only at the moment; blob endpoints (`az://`, `s3://`) require
    fsspec wiring and are deferred to a follow-up.
    """
```

and replace with:

```python
    """Walk `scfg.endpoint` and emit one ODCS contract per discoverable file.

    Supports CSV (Plan #1), Excel (Plan #2), XML (Plan #3), and QVD
    (Plan #4) — the complete ADR-0022 umbrella.

    `xpath` (optional) is the XPath expression used to extract records from
    each .xml file. Required only if the endpoint contains .xml files;
    csv/xlsx/qvd don't use it.

    Local paths only at the moment; blob endpoints (`az://`, `s3://`) require
    fsspec wiring and are deferred to a follow-up.
    """
```

At the end of the file (after `_read_xml_columns`), append:

```python
def _build_qvd_contract(file_path: Path, *, source_name: str) -> LoadedContract:
    """Emit one LoadedContract for a .qvd file by inspecting the first chunk.

    Unlike csv/excel/xml (types default to `string`), QVD's metadata header
    carries real types — we infer per-column logicalType from the value
    classes pyqvd returns for the first data row. Empty tables default to
    `string` (no values to inspect).
    """
    from pyqvd import QvdTable

    resource_name = snake_case(file_path.stem)

    columns, types = _read_qvd_columns_and_types(file_path)
    properties = [
        OdcsProperty(name=col, logicalType=t)  # type: ignore[arg-type]
        for col, t in zip(columns, types, strict=False)
    ]
    spec_ref_value = {
        "kind": "filesystem",
        "format": "qvd",
        "path": file_path.name,
    }
    contract = OdcsContract(
        apiVersion="v3.0.0",
        kind="DataContract",
        id=f"{source_name}.{resource_name}",
        name=resource_name,
        version="0.1.0",
        status="draft",
        info=OdcsInfo(title=resource_name, owner="data-platform"),
        schema=[
            OdcsSchema(
                name=resource_name,
                physicalName=resource_name,
                physicalType="table",
                properties=properties,
            )
        ],
        customProperties=[
            CustomProperty(property="das.spec_ref", value=spec_ref_value)
        ],
    )
    return LoadedContract(
        path=Path(f"{resource_name}.odcs.yaml"),
        resource_name=resource_name,
        contract=contract,
    )


def _read_qvd_columns_and_types(file_path: Path) -> tuple[list[str], list[str]]:
    """Return (column_names, logical_types) from a .qvd file's first chunk."""
    from pyqvd import QvdTable

    # chunk_size=1 keeps memory tiny; we only need one row to type-infer.
    chunks = QvdTable.from_qvd(file_path, chunk_size=1)
    columns: list[str] = []
    types: list[str] = []
    consumed = False
    for chunk in chunks:  # type: ignore[union-attr]
        columns = list(chunk.columns)
        if not chunk.data:
            # First chunk has no rows — empty table; default all types to string.
            types = ["string"] * len(columns)
        else:
            first_row = chunk.data[0]
            types = [_qvd_logical_type(cell) for cell in first_row]
        consumed = True
        break  # one chunk is enough to derive the schema
    if not consumed:
        # No chunks at all (shouldn't happen for a well-formed file); empty schema.
        return [], []
    return columns, types


_QVD_TYPE_MAP: dict[str, str] = {
    "IntegerValue": "integer",
    "DualIntegerValue": "integer",
    "DoubleValue": "number",
    "MoneyValue": "number",
    "DualDoubleValue": "number",
    "StringValue": "string",
    "DateValue": "date",
    "TimestampValue": "timestamp",
    "TimeValue": "string",
    "IntervalValue": "string",
}


def _qvd_logical_type(cell: object) -> str:
    """Map a pyqvd typed value to an ODCS logicalType. None → string."""
    if cell is None:
        return "string"
    cls = type(cell).__name__
    return _QVD_TYPE_MAP.get(cls, "string")
```

- [ ] **Step 4: Run the bootstrap tests**

Run: `uv run pytest tests/unit/test_bootstrap_filesystem.py -v`
Expected: all qvd tests pass; previous csv/xlsx/xml tests still pass.

- [ ] **Step 5: Commit**

```bash
git add src/das_cli/bootstrap/filesystem.py tests/unit/test_bootstrap_filesystem.py
git commit -m "$(cat <<'EOF'
feat(bootstrap): qvd discovery — names AND types from header

Adds _build_qvd_contract: each .qvd file → one ODCS contract with
columns from chunk.columns and per-column logicalType inferred from
the pyqvd value class of the first data row (IntegerValue → integer,
DoubleValue/MoneyValue → number, StringValue → string, DateValue →
date, TimestampValue → timestamp; unknown → string).

This is the first format under the umbrella where bootstrap emits
real types instead of defaulting everything to 'string' — QVD's
metadata header is self-describing.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

- [ ] **Step 6: Verify the commit landed on the branch**

Run: `git log --oneline -3`
Expected: your new commit SHA at HEAD.

---

### Task 5: E2E — QVD to DuckDB

**Files:**
- Create: `tests/e2e/sources/test_qvd_to_duckdb.py`

QVD is binary, so the fixture is built in-test using pyqvd (same approach as Excel). The e2e test follows the csv/excel/xml pattern.

- [ ] **Step 1: Write the failing e2e test**

Create `tests/e2e/sources/test_qvd_to_duckdb.py`:

```python
"""E2E: das against a local .qvd file, landing into DuckDB. See ADR-0022.

Opt-in via `pytest -m e2e`. Builds the fixture in tmp_path via pyqvd so
no binary file is committed. Pattern mirrors test_excel_to_duckdb.py.
"""

from __future__ import annotations

import io
from pathlib import Path

import duckdb
from pyqvd import QvdTable
from typer.testing import CliRunner

from das_cli.cli import app


def _stage_qvd(data_dir: Path) -> None:
    t = QvdTable.from_dict(
        {
            "columns": ["customer_id", "name", "amount"],
            "data": [
                [1, "Alice", 9.95],
                [2, "Bob", 19.50],
                [3, "Charlie", 99.00],
            ],
        }
    )
    buf = io.BytesIO()
    t.to_stream(buf)
    (data_dir / "customers.qvd").write_bytes(buf.getvalue())


def test_qvd_to_duckdb_with_provenance(
    workspace: Path, cli_runner: CliRunner
) -> None:
    """QVD → DuckDB with type-aware schema + inject for provenance."""

    data_dir = workspace / "data"
    data_dir.mkdir()
    _stage_qvd(data_dir)

    init = cli_runner.invoke(app, ["init"])
    assert init.exit_code == 0, init.stdout + init.stderr

    add = cli_runner.invoke(
        app,
        ["source", "add", "files", "--type", "filesystem", "--url", str(data_dir)],
    )
    assert add.exit_code == 0, add.stdout + add.stderr

    boot = cli_runner.invoke(app, ["contract", "bootstrap", "files"])
    assert boot.exit_code == 0, boot.stdout + boot.stderr

    contracts_dir = workspace / "contracts" / "files"
    written = sorted(p.name for p in contracts_dir.glob("*.odcs.yaml"))
    assert written == ["customers.odcs.yaml"]

    # The bootstrap already inferred types from the QVD header — just add
    # primaryKey + inject. (Other formats default to string and need
    # hand-edits to widen types; QVD doesn't.)
    (contracts_dir / "customers.odcs.yaml").write_text(
        "apiVersion: v3.0.0\n"
        "kind: DataContract\n"
        "id: files.customers\n"
        "name: customers\n"
        "version: 0.1.0\n"
        "status: draft\n"
        "info:\n  title: customers\n  owner: data-platform\n"
        "schema:\n"
        "  - name: customers\n"
        "    physicalName: customers\n"
        "    physicalType: table\n"
        "    properties:\n"
        "      - name: customer_id\n"
        "        logicalType: integer\n"
        "        primaryKey: true\n"
        "        required: true\n"
        "      - name: name\n"
        "        logicalType: string\n"
        "      - name: amount\n"
        "        logicalType: number\n"
        "      - name: source_file\n"
        "        logicalType: string\n"
        "customProperties:\n"
        "  - property: das.spec_ref\n"
        "    value:\n"
        "      kind: filesystem\n"
        "      format: qvd\n"
        "      path: 'customers.qvd'\n"
        "      inject:\n"
        "        source_file: basename\n"
    )

    ext = cli_runner.invoke(app, ["extract", "files"])
    assert ext.exit_code == 0, ext.stdout + ext.stderr

    load = cli_runner.invoke(app, ["load", "files"])
    assert load.exit_code == 0, load.stdout + load.stderr

    db = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        rows = db.execute(
            'SELECT customer_id, name, amount, source_file '
            'FROM "das__files".customers ORDER BY customer_id'
        ).fetchall()
    finally:
        db.close()

    assert rows == [
        (1, "Alice", 9.95, "customers.qvd"),
        (2, "Bob", 19.50, "customers.qvd"),
        (3, "Charlie", 99.00, "customers.qvd"),
    ]
```

- [ ] **Step 2: Run the e2e test**

Run: `uv run pytest tests/e2e/sources/test_qvd_to_duckdb.py -m e2e -v`

Expected: PASS. If the test fails on type coercion (the contract declares `amount` as `logicalType: number` and pyqvd emits native `float`; the load pipeline should accept floats into `number` columns — csv's e2e proves string→integer coercion works, and float→number is simpler), report DONE_WITH_CONCERNS with the specific failure.

- [ ] **Step 3: Sanity sweep**

Run: `uv run pytest -q -m "not e2e"`
Expected: all filesystem tests pass; pre-existing test_progress.py / midnight-flake failures are unrelated.

Run: `uv run pytest -m e2e -v -k "csv or excel or xml or qvd"`
Expected: 4 passed (all four filesystem edges).

- [ ] **Step 4: Commit**

```bash
git add tests/e2e/sources/test_qvd_to_duckdb.py
git commit -m "$(cat <<'EOF'
test(e2e): QVD-to-DuckDB edge with type-aware schema + provenance

Completes the file-based sources umbrella's verified-edge matrix: all
four formats (csv, excel, xml, qvd) now have an e2e test against
DuckDB. The QVD test exercises pyqvd's streaming reader + the
type-aware bootstrap (customer_id → integer, amount → number from
the QVD header) plus inject for source_file provenance. The fixture
is built in tmp_path via pyqvd so no binary blob is committed.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

- [ ] **Step 5: Verify the commit landed on the branch**

Run: `git log --oneline -3`
Expected: your new commit SHA at HEAD.

---

### Task 6: README — add QVD to the verified sources table

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Append the QVD row**

Edit `README.md`. Find the "Verified sources (against DuckDB)" table. After the XML row added in Plan #3, append:

```markdown
| QVD (Qlik export)   | pyqvd chunked streaming (ADR-0022); types inferred from header |
```

- [ ] **Step 2: Add a QVD quickstart snippet**

After the XML quickstart code-block in the README (the "For an XML source..." block + its `bash` fence), insert:

````markdown
For a QVD source (local Qlik `.qvd` exports), point das at a directory
of QVD files. Unlike csv/excel/xml — where bootstrap defaults all
column types to `string` — QVD's embedded metadata gives das the real
types up front (integer/number/string/date/timestamp), so you usually
only need to set primary keys post-bootstrap.

```bash
uv tool install das-cli --with pyqvd

das source add finance \
  --type filesystem \
  --url ./data/finance/

das contract bootstrap finance
# Edit contracts/finance/*.odcs.yaml — set primary keys (types already good).

das ingest finance
```
````

- [ ] **Step 3: Commit**

```bash
git add README.md
git commit -m "$(cat <<'EOF'
docs(readme): document QVD file source + verified-edge row

Adds the QVD row to the verified sources table (DuckDB destination
edge covered by tests/e2e/sources/test_qvd_to_duckdb.py) and a
quickstart snippet that highlights QVD's type-aware bootstrap (the
only format under ADR-0022 where types come from the file itself).

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

- [ ] **Step 4: Verify the commit landed on the branch**

Run: `git log --oneline -3`
Expected: your new commit SHA at HEAD.

---

## Post-plan verification

After all tasks land, run the full sweep:

- [ ] `uv run pytest -q` — unit + integration (e2e excluded by default).
- [ ] `uv run pytest -m e2e -v` — opt-in e2e suite, including the new qvd edge.
- [ ] `uv run pre-commit run --all-files` — ruff format/lint + mypy.

After Plan #4 ships, the file-based sources umbrella is complete: all four formats from the issue #49 group (csv, excel, xml, qvd) have streaming readers, bootstrap discovery, e2e edges against DuckDB, and README documentation under ADR-0022 + ADR-0023.
