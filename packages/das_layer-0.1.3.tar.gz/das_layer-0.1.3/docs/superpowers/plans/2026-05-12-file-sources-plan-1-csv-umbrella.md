# File-based sources Plan #1: CSV + umbrella plumbing

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Land the `type: filesystem` source umbrella plus a working CSV reader, so `das-cli` can ingest one or many CSV files (local or blob) into staging via the existing landing/load pipelines.

**Architecture:** One source-type branch (`_build_filesystem_resources`) in `dlt_glue/source_factory.py` dispatches per-resource via `das.spec_ref.format`. Format-specific readers live in a new `dlt_glue/file_readers/` package. Bootstrap walks `endpoint` and emits one contract per file. Streaming-by-default: stdlib `csv.DictReader` over a fsspec-backed file handle. Opt-in row-level provenance via `das.spec_ref.inject`.

**Tech Stack:** Python 3.12, dlt (`dlt.sources.filesystem`), Pydantic 2, stdlib `csv`, Typer CLI, pytest.

**Spec:** `docs/superpowers/specs/2026-05-12-file-based-sources-design.md`

**Issue:** [#49](https://github.com/mattiasthalen/das-cli/issues/49) (umbrella) — this plan delivers the umbrella + the [#38](https://github.com/mattiasthalen/das-cli/issues/38) csv child. Plans #2 (excel), #3 (xml), #4 (qvd) will follow once this lands.

---

## Tasks at a glance

1. ADR-0022 (filesystem source type) + ADR-0023 (opt-in inject) + ADR index update
2. `FilesystemSpecRef` Pydantic model + validator integration
3. `file_readers/` package: `__init__.py` + shared `_inject.py` helper
4. `file_readers/csv.py` reader
5. `source_factory.py` — `_build_filesystem_resources` branch
6. `bootstrap/filesystem.py` — discovery walker for CSV
7. CLI: `contract bootstrap` dispatch to filesystem
8. CLI: `source add` template for filesystem
9. E2E: `tests/e2e/sources/test_csv_to_duckdb.py`
10. README — add CSV to the verified sources table

---

### Task 1: Write ADR-0022, ADR-0023, and update the index

**Files:**
- Create: `docs/adrs/0022-filesystem-source-type.md`
- Create: `docs/adrs/0023-opt-in-row-provenance-via-inject.md`
- Modify: `docs/adrs/README.md` (append two index rows)

- [ ] **Step 1: Write ADR-0022**

Create `docs/adrs/0022-filesystem-source-type.md` with this exact content:

```markdown
# 0022. File-based sources via a single `type: filesystem` umbrella

- **Status:** Accepted
- **Date:** 2026-05-12
- **Deciders:** mattiasthalen

## Context

Issue #49 bundled csv, excel, xml as file-based sources, with qvd (#40)
explicitly out of scope as "not a 1:1 shape fit." But the underlying
plumbing — path/glob resolution, blob-URL passthrough, per-resource
selectors, opt-in row provenance — is format-agnostic. Treating qvd as
a sibling source type would have meant a near-duplicate dispatch branch
in `dlt_glue/source_factory.py` for each new format, the same multiplication
ADR-0018 rejected for SQL dialects.

`_source.yml.type` already declared `filesystem` as a placeholder
literal (`src/das_cli/models/source_yml.py`); the CLI accepts it
(`_VALID_SOURCE_TYPES`); the validator forbids `das.endpoint` on it.
None of this was wired to a builder.

## Decision

**Decision A: a single source type `filesystem` covers csv, excel, xml,
and qvd.** Format dispatches per-resource via `das.spec_ref.format`.
One new branch `_build_filesystem_resources` in `dlt_glue/source_factory.py`,
symmetric with ADR-0018's SQL branch. No registry, no plugin layer.

**Decision B: format-specific reading lives in `dlt_glue/file_readers/`,**
one module per format. Each exports `read_rows(file_item, spec_ref) ->
Iterator[dict]`. Readers are pure functions over a dlt `FileItemDict` and
the resource's spec_ref. Independently unit-testable without dlt.

**Decision C: file enumeration uses `dlt.sources.filesystem`,** the
standard dlt source. This brings free fsspec-backed blob support
(`az://`, `s3://`, `gs://`) and free incremental "only new files since
last run" via modification-time tracking. `--full` (ADR-0019) resets
that state via the existing `pipelines/extract.py::reset_extract_state`.

**Decision D: `_source.yml.endpoint` is the root path/URL,** and each
contract's `das.spec_ref.path` is a glob (or single file) relative to
it. Format-specific reader options (delimiter, sheet, xpath, ...) live
in `das.spec_ref` per-resource. `_source.yml.spec.kind = filesystem`
stays format-agnostic.

## Alternatives considered

- **Per-format source types (`type: csv`, `type: excel`, `type: xml`,
  `type: qvd`).** Rejected: four near-duplicate dispatch branches; each
  new format multiplies file/glob/blob plumbing. Diverges from ADR-0018's
  "one branch per source type" pattern.
- **Registry-style source dispatch.** Same rejection rationale as
  ADR-0016 and ADR-0018 — duplicates dlt's abstraction; adds a layer
  for no gain.
- **Per-source format with one format per source.** Forces "one Excel
  workbook = one source," which is the wrong shape — sheets are the
  natural resource unit.
- **Auto-detect format from file extension at extract time.** Rejected:
  conflates discovery (bootstrap concern) with extraction; loses
  explicitness in the contract.

## Consequences

- The `filesystem` literal in `SourceType` becomes load-bearing rather
  than a placeholder. A new branch in `_build_extract_resources` covers
  it. Future formats (parquet, jsonl, ...) plug in as new modules under
  `dlt_glue/file_readers/` plus an enum value in `FilesystemSpecRef.format`.
- The `auth` block carries no credentials for filesystem sources. Blob
  auth flows through dlt's filesystem config (env vars), symmetric with
  the destination side per ADR-0016/0017.
- One PR per format under this umbrella ADR. The umbrella ships with the
  CSV reader (Plan #1); excel/xml/qvd follow.
- Readers must stream. Each reader yields rows one at a time and never
  materializes the full file in memory. This is policy, not enforcement —
  the test suite asserts it per reader (see plan tests).
```

- [ ] **Step 2: Write ADR-0023**

Create `docs/adrs/0023-opt-in-row-provenance-via-inject.md` with this exact content:

```markdown
# 0023. Opt-in row-level provenance via `das.spec_ref.inject`

- **Status:** Accepted
- **Date:** 2026-05-12
- **Deciders:** mattiasthalen

## Context

File-based sources (ADR-0022) commonly use globbing: `customers_*.csv`
becomes one resource that concatenates twelve monthly files. Sheets
share the same pattern: a glob of workbooks combined by sheet name.

Concatenating loses file-level provenance. Users may want a column
recording which file (or sheet) a row came from — for audit, for
debugging a bad row, or for downstream partitioning. The landing-rules
question is: do we preserve that information, and if so how?

## Decision

Provenance is **opt-in per resource via `das.spec_ref.inject`,**
declared alongside a matching column in the contract's schema.

```yaml
das.spec_ref:
  kind: filesystem
  format: csv
  path: "customers_*.csv"
  inject:
    source_file: basename       # → row["source_file"] = file basename
    source_mtime: mtime         # → row["source_mtime"] = file mtime
```

The reader sets `row[col] = <derived value>` before blobbing. The user
declares `source_file` as a property in the ODCS schema like any other
column; P2 projects it into staging.

Supported source values: `basename`, `fullpath`, `mtime`, and `sheet`
(excel only). The column name is user-chosen.

## Alternatives considered

- **Hive-partition landing by source file**
  (`_extracted_on=.../_source_file=.../...jsonl`). Rejected: a glob
  matching N files creates N landing partitions per run. For
  partitioned exports (12 monthly files) it's mild; for `*.qvd` over
  200 files it's a small-files pathology — Object-storage listing
  latency and downstream Parquet/Delta compaction both suffer.
- **Inject `_source_file` as a sibling key to `_data`** in the row
  blob: `{"_data": row, "_source_file": "..."}`. Rejected because it
  breaks ADR-0003's strict `{"_data": row}` outer shape; would require
  an ADR superseding 0003 for a feature most users will never use.
- **Sidecar manifest per run** listing files+row-counts. Rejected for
  Plan #1's scope — useful for audit but not for per-row queries. May
  layer on top later.
- **No provenance.** Rejected — for combining globs it's a real
  footgun. Users would be on their own to add columns at the source.

## Consequences

- ADR-0003's blob pattern is **reaffirmed**, not superseded. Injected
  values land *inside* the user-declared `_data` dict, alongside the
  user's other columns.
- The contract is the source of truth: if `inject.source_file` is set
  but no `source_file` column exists in the schema, the validator
  rejects (the injected value would be silently dropped at the
  contract-projection boundary in P2).
- Default = no injection. Resources that don't need provenance pay
  nothing — no extra fields, no extra columns, no extra storage.
- The `inject` mechanism extends naturally to excel (`sheet` source)
  and qvd (file metadata) under the same umbrella in later format PRs.
```

- [ ] **Step 3: Update the ADR index**

Append two rows to `docs/adrs/README.md` — find the existing table and add at the bottom:

```markdown
| 0022 | File-based sources via a single `type: filesystem` umbrella | Accepted |
| 0023 | Opt-in row-level provenance via `das.spec_ref.inject` | Accepted |
```

- [ ] **Step 4: Verify ADR index consistency**

Run: `head -1 docs/adrs/0022-filesystem-source-type.md && head -1 docs/adrs/0023-opt-in-row-provenance-via-inject.md`
Expected output:
```
# 0022. File-based sources via a single `type: filesystem` umbrella
# 0023. Opt-in row-level provenance via `das.spec_ref.inject`
```

CLAUDE.md's ADR pre-merge check requires these titles to match `README.md` exactly. Confirm they do.

- [ ] **Step 5: Commit**

```bash
git add docs/adrs/0022-filesystem-source-type.md docs/adrs/0023-opt-in-row-provenance-via-inject.md docs/adrs/README.md
git commit -m "$(cat <<'EOF'
docs(adrs): ADR-0022 filesystem source type + ADR-0023 opt-in inject

ADR-0022 records the single-umbrella decision for csv/excel/xml/qvd
with per-resource format dispatch via das.spec_ref. ADR-0023 records
the row-level provenance mechanism (and why hive-partition-by-file
and outer-blob metadata were rejected).

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

### Task 2: `FilesystemSpecRef` model + validator integration

**Files:**
- Create: `src/das_cli/contracts/filesystem_spec_ref.py`
- Modify: `src/das_cli/contracts/validator.py` (extend `_validate_contract`)
- Test: `tests/unit/test_filesystem_spec_ref.py` (new)
- Test: `tests/unit/test_validator.py` (extend existing)

The validator needs to accept `das.spec_ref` for `type: filesystem` and reject malformed shapes. Format-specific required fields (sheet for excel, xpath for xml) are enforced now even though only csv ships its reader in this plan — so the model is complete from day one.

- [ ] **Step 1: Write the failing test for the spec_ref model**

Create `tests/unit/test_filesystem_spec_ref.py`:

```python
"""Unit tests for FilesystemSpecRef Pydantic model. See ADR-0022."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from das_cli.contracts.filesystem_spec_ref import FilesystemSpecRef


def test_minimal_csv_spec_ref() -> None:
    sr = FilesystemSpecRef.model_validate(
        {"kind": "filesystem", "format": "csv", "path": "customers.csv"}
    )
    assert sr.format == "csv"
    assert sr.path == "customers.csv"
    assert sr.inject is None


def test_csv_with_options() -> None:
    sr = FilesystemSpecRef.model_validate(
        {
            "kind": "filesystem",
            "format": "csv",
            "path": "customers_*.csv",
            "delimiter": ";",
            "encoding": "latin-1",
        }
    )
    assert sr.delimiter == ";"
    assert sr.encoding == "latin-1"


def test_inject_accepts_known_sources() -> None:
    sr = FilesystemSpecRef.model_validate(
        {
            "kind": "filesystem",
            "format": "csv",
            "path": "*.csv",
            "inject": {"source_file": "basename", "source_mtime": "mtime"},
        }
    )
    assert sr.inject == {"source_file": "basename", "source_mtime": "mtime"}


def test_inject_rejects_unknown_source() -> None:
    with pytest.raises(ValidationError):
        FilesystemSpecRef.model_validate(
            {
                "kind": "filesystem",
                "format": "csv",
                "path": "*.csv",
                "inject": {"source_file": "magical_value"},
            }
        )


def test_kind_must_be_filesystem() -> None:
    with pytest.raises(ValidationError):
        FilesystemSpecRef.model_validate(
            {"kind": "sql", "format": "csv", "path": "*.csv"}
        )


def test_format_must_be_in_set() -> None:
    with pytest.raises(ValidationError):
        FilesystemSpecRef.model_validate(
            {"kind": "filesystem", "format": "parquet", "path": "*.parquet"}
        )


def test_path_required() -> None:
    with pytest.raises(ValidationError):
        FilesystemSpecRef.model_validate({"kind": "filesystem", "format": "csv"})


def test_path_non_empty() -> None:
    with pytest.raises(ValidationError):
        FilesystemSpecRef.model_validate(
            {"kind": "filesystem", "format": "csv", "path": ""}
        )


def test_extra_fields_forbidden() -> None:
    with pytest.raises(ValidationError):
        FilesystemSpecRef.model_validate(
            {
                "kind": "filesystem",
                "format": "csv",
                "path": "x.csv",
                "bogus_field": True,
            }
        )
```

- [ ] **Step 2: Run the test to verify it fails**

Run: `uv run pytest tests/unit/test_filesystem_spec_ref.py -v`
Expected: FAIL with `ImportError: cannot import name 'FilesystemSpecRef'`.

- [ ] **Step 3: Write the model**

Create `src/das_cli/contracts/filesystem_spec_ref.py`:

```python
"""Pydantic model for `das.spec_ref` on filesystem sources. See ADR-0022 and ADR-0023."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

FileFormat = Literal["csv", "excel", "xml", "qvd"]
InjectSource = Literal["basename", "fullpath", "mtime", "sheet"]


class FilesystemSpecRef(BaseModel):
    """Per-resource filesystem spec embedded under `das.spec_ref` in an ODCS contract.

    The full model accepts options for all four formats (csv, excel, xml, qvd),
    even though Plan #1 only ships the csv reader. Format-specific required
    fields (`sheet` for excel, `xpath` for xml) are validated here so contracts
    that target later formats fail fast.
    """

    model_config = ConfigDict(extra="forbid")

    kind: Literal["filesystem"]
    format: FileFormat
    path: str = Field(..., min_length=1)

    # csv / xml options.
    delimiter: str | None = None
    encoding: str | None = None

    # excel options.
    sheet: str | None = None
    header_row: int | None = None

    # xml options.
    xpath: str | None = None
    namespaces: dict[str, str] | None = None

    # Opt-in row-level provenance (ADR-0023). Keys are user-chosen column names;
    # values name the source of the injected value.
    inject: dict[str, InjectSource] | None = None
```

- [ ] **Step 4: Run the model tests and verify they pass**

Run: `uv run pytest tests/unit/test_filesystem_spec_ref.py -v`
Expected: 9 passed.

- [ ] **Step 5: Write the failing validator tests**

Edit `tests/unit/test_validator.py` — append these tests at the end of the file:

```python
def test_filesystem_spec_ref_required(tmp_path: Path) -> None:
    """A filesystem-typed source whose contract is missing das.spec_ref fails."""
    _seed_workspace(
        tmp_path,
        source_name="files",
        source_yml="type: filesystem\nendpoint: ./data/\nspec:\n  kind: filesystem\nauth:\n  type: none\n",
        contract_yaml=_contract_yaml_no_spec_ref(),
    )
    issues = validate_workspace(tmp_path / "das.yaml")
    assert any(
        "das.spec_ref is required for type=filesystem" in i.message for i in issues
    )


def test_filesystem_spec_ref_format_dispatch(tmp_path: Path) -> None:
    """A filesystem contract with format=excel but no sheet fails validation."""
    contract = _contract_yaml_with_spec_ref(
        {"kind": "filesystem", "format": "excel", "path": "wb.xlsx"}
    )
    _seed_workspace(
        tmp_path,
        source_name="files",
        source_yml="type: filesystem\nendpoint: ./data/\nspec:\n  kind: filesystem\nauth:\n  type: none\n",
        contract_yaml=contract,
    )
    issues = validate_workspace(tmp_path / "das.yaml")
    assert any("sheet is required for format=excel" in i.message for i in issues)


def test_filesystem_inject_column_must_exist(tmp_path: Path) -> None:
    """inject.<col> must reference a column declared in the schema."""
    contract = _contract_yaml_with_spec_ref(
        {
            "kind": "filesystem",
            "format": "csv",
            "path": "*.csv",
            "inject": {"undeclared_col": "basename"},
        }
    )
    _seed_workspace(
        tmp_path,
        source_name="files",
        source_yml="type: filesystem\nendpoint: ./data/\nspec:\n  kind: filesystem\nauth:\n  type: none\n",
        contract_yaml=contract,
    )
    issues = validate_workspace(tmp_path / "das.yaml")
    assert any(
        "inject column 'undeclared_col' is not in the schema" in i.message
        for i in issues
    )


def test_filesystem_inject_with_declared_column_passes(tmp_path: Path) -> None:
    """When the inject target column is in the schema, no issue is raised."""
    contract = _contract_yaml_with_spec_ref(
        {
            "kind": "filesystem",
            "format": "csv",
            "path": "*.csv",
            "inject": {"source_file": "basename"},
        },
        extra_property={"name": "source_file", "logicalType": "string"},
    )
    _seed_workspace(
        tmp_path,
        source_name="files",
        source_yml="type: filesystem\nendpoint: ./data/\nspec:\n  kind: filesystem\nauth:\n  type: none\n",
        contract_yaml=contract,
    )
    issues = validate_workspace(tmp_path / "das.yaml")
    assert not any("inject" in i.message for i in issues)


def _seed_workspace(
    root: Path, *, source_name: str, source_yml: str, contract_yaml: str
) -> None:
    (root / "das.yaml").write_text(
        "contracts:\n  root: contracts\n"
        "landing:\n  bucket_url: ./landing\n"
        "defaults:\n  change_detection: row_hash\n"
    )
    src_dir = root / "contracts" / source_name
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(source_yml)
    (src_dir / "customers.odcs.yaml").write_text(contract_yaml)


def _contract_yaml_no_spec_ref() -> str:
    return (
        "apiVersion: v3.0.0\n"
        "kind: DataContract\n"
        "id: files.customers\n"
        "name: customers\n"
        "version: 0.1.0\n"
        "status: draft\n"
        "info:\n  title: customers\n"
        "schema:\n"
        "  - name: customers\n"
        "    physicalName: customers\n"
        "    physicalType: table\n"
        "    properties:\n"
        "      - name: id\n"
        "        logicalType: integer\n"
        "        primaryKey: true\n"
        "        required: true\n"
    )


def _contract_yaml_with_spec_ref(
    spec_ref: dict,
    *,
    extra_property: dict | None = None,
) -> str:
    import yaml

    props = [{"name": "id", "logicalType": "integer", "primaryKey": True, "required": True}]
    if extra_property is not None:
        props.append(extra_property)

    doc = {
        "apiVersion": "v3.0.0",
        "kind": "DataContract",
        "id": "files.customers",
        "name": "customers",
        "version": "0.1.0",
        "status": "draft",
        "info": {"title": "customers"},
        "schema": [
            {
                "name": "customers",
                "physicalName": "customers",
                "physicalType": "table",
                "properties": props,
            }
        ],
        "customProperties": [{"property": "das.spec_ref", "value": spec_ref}],
    }
    return yaml.safe_dump(doc, sort_keys=False)
```

If the existing `tests/unit/test_validator.py` already imports `Path` and `validate_workspace` at the top, no extra imports are needed. Otherwise add at the top of the file:

```python
from pathlib import Path

from das_cli.contracts.validator import validate_workspace
```

- [ ] **Step 6: Run the failing validator tests**

Run: `uv run pytest tests/unit/test_validator.py -v -k filesystem`
Expected: 4 tests, all FAIL (the validator hasn't been extended yet).

- [ ] **Step 7: Extend the validator**

Edit `src/das_cli/contracts/validator.py` — at the end of `_validate_contract`, before `return out`, insert:

```python
    # Filesystem-typed sources: validate das.spec_ref shape and required fields.
    # See ADR-0022 and ADR-0023.
    if source_type == "filesystem":
        raw_spec_ref = das_props.get("das.spec_ref")
        if raw_spec_ref is None:
            out.append(
                ValidationIssue(
                    path=str(c.path),
                    message="das.spec_ref is required for type=filesystem",
                )
            )
        else:
            from das_cli.contracts.filesystem_spec_ref import FilesystemSpecRef

            try:
                spec_ref = FilesystemSpecRef.model_validate(raw_spec_ref)
            except ValidationError as e:
                out.append(
                    ValidationIssue(
                        path=str(c.path),
                        message=f"das.spec_ref invalid for filesystem source: {e}",
                    )
                )
            else:
                if spec_ref.format == "excel" and not spec_ref.sheet:
                    out.append(
                        ValidationIssue(
                            path=str(c.path),
                            message="sheet is required for format=excel",
                        )
                    )
                if spec_ref.format == "xml" and not spec_ref.xpath:
                    out.append(
                        ValidationIssue(
                            path=str(c.path),
                            message="xpath is required for format=xml",
                        )
                    )
                # inject keys must reference declared columns.
                for col in (spec_ref.inject or {}):
                    if col not in column_names:
                        out.append(
                            ValidationIssue(
                                path=str(c.path),
                                message=(
                                    f"inject column '{col}' is not in the schema "
                                    f"(declare it in properties or remove from inject)"
                                ),
                            )
                        )
```

- [ ] **Step 8: Run the validator tests and verify they pass**

Run: `uv run pytest tests/unit/test_validator.py -v -k filesystem`
Expected: 4 passed.

- [ ] **Step 9: Run the full test suite to confirm no regressions**

Run: `uv run pytest tests/unit/ -q`
Expected: all unit tests pass.

- [ ] **Step 10: Commit**

```bash
git add src/das_cli/contracts/filesystem_spec_ref.py src/das_cli/contracts/validator.py tests/unit/test_filesystem_spec_ref.py tests/unit/test_validator.py
git commit -m "$(cat <<'EOF'
feat(contracts): FilesystemSpecRef model + validator integration

Adds the das.spec_ref shape for type=filesystem (ADR-0022): kind, format,
path, optional reader options (delimiter/sheet/xpath/...), and the
inject map for opt-in row-level provenance (ADR-0023). Validator
rejects missing/invalid spec_ref, missing sheet for excel, missing
xpath for xml, and inject keys that don't name declared columns.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

### Task 3: `file_readers/` package + shared inject helper

**Files:**
- Create: `src/das_cli/dlt_glue/file_readers/__init__.py`
- Create: `src/das_cli/dlt_glue/file_readers/_inject.py`
- Test: `tests/unit/dlt_glue/__init__.py`
- Test: `tests/unit/dlt_glue/file_readers/__init__.py`
- Test: `tests/unit/dlt_glue/file_readers/test_inject.py`

- [ ] **Step 1: Write the failing inject tests**

Create the test scaffold:
- `tests/unit/dlt_glue/__init__.py` (empty file)
- `tests/unit/dlt_glue/file_readers/__init__.py` (empty file)
- `tests/unit/dlt_glue/file_readers/test_inject.py`:

```python
"""Unit tests for the shared inject helper. See ADR-0023."""

from __future__ import annotations

from das_cli.dlt_glue.file_readers._inject import apply_inject


def test_no_inject_passes_rows_through() -> None:
    rows = iter([{"a": 1}, {"a": 2}])
    out = list(apply_inject(rows, inject=None, context={}))
    assert out == [{"a": 1}, {"a": 2}]


def test_basename_injection() -> None:
    rows = iter([{"a": 1}])
    ctx = {"basename": "customers_2024-01.csv"}
    out = list(apply_inject(rows, inject={"source_file": "basename"}, context=ctx))
    assert out == [{"a": 1, "source_file": "customers_2024-01.csv"}]


def test_multiple_injections() -> None:
    rows = iter([{"a": 1}])
    ctx = {"basename": "x.csv", "mtime": "2026-05-12T00:00:00"}
    out = list(
        apply_inject(
            rows,
            inject={"source_file": "basename", "loaded_at": "mtime"},
            context=ctx,
        )
    )
    assert out == [
        {"a": 1, "source_file": "x.csv", "loaded_at": "2026-05-12T00:00:00"}
    ]


def test_unknown_inject_source_silently_skipped() -> None:
    """Unknown source keys (e.g. 'sheet' for csv where it isn't populated) are skipped.

    The model validation in Task 2 enforces that inject values are in the known
    set; this helper is defensive — if a context key is missing, the column is
    not injected rather than the row failing.
    """
    rows = iter([{"a": 1}])
    ctx = {"basename": "x.csv"}  # no 'sheet' in context
    out = list(
        apply_inject(
            rows, inject={"src": "basename", "sheet_name": "sheet"}, context=ctx
        )
    )
    assert out == [{"a": 1, "src": "x.csv"}]
```

- [ ] **Step 2: Run the failing tests**

Run: `uv run pytest tests/unit/dlt_glue/file_readers/test_inject.py -v`
Expected: FAIL with `ImportError`.

- [ ] **Step 3: Write the package + inject helper**

Create `src/das_cli/dlt_glue/file_readers/__init__.py`:

```python
"""Format-specific readers for filesystem sources. See ADR-0022."""
```

Create `src/das_cli/dlt_glue/file_readers/_inject.py`:

```python
"""Apply opt-in row-level provenance injection. See ADR-0023."""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any


def apply_inject(
    rows: Iterator[dict[str, Any]],
    *,
    inject: dict[str, str] | None,
    context: dict[str, Any],
) -> Iterator[dict[str, Any]]:
    """Inject provenance values into rows per the inject map.

    Args:
        rows: Source row iterator.
        inject: Map of column-name → source-key (e.g. {"source_file": "basename"}).
                When None or empty, rows pass through unchanged.
        context: Source-key → value (e.g. {"basename": "customers_2024-01.csv"}).
                 Keys not in context are silently skipped (defensive — the model
                 validator in `FilesystemSpecRef` already enforces the known set).
    """
    if not inject:
        yield from rows
        return

    # Pre-resolve which (column, value) pairs we'll inject so the loop body
    # doesn't redo lookups per row.
    pairs: list[tuple[str, Any]] = []
    for col, source_key in inject.items():
        if source_key in context:
            pairs.append((col, context[source_key]))

    for row in rows:
        for col, value in pairs:
            row[col] = value
        yield row
```

- [ ] **Step 4: Run the tests and verify they pass**

Run: `uv run pytest tests/unit/dlt_glue/file_readers/test_inject.py -v`
Expected: 4 passed.

- [ ] **Step 5: Commit**

```bash
git add src/das_cli/dlt_glue/file_readers/ tests/unit/dlt_glue/
git commit -m "$(cat <<'EOF'
feat(file_readers): package + shared inject helper

Lays the foundation for ADR-0022's per-format readers. apply_inject
handles ADR-0023's opt-in row provenance: column-name -> source-key
map resolved against a context provided by each format reader.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

### Task 4: CSV reader

**Files:**
- Create: `src/das_cli/dlt_glue/file_readers/csv.py`
- Test: `tests/unit/dlt_glue/file_readers/test_csv.py`

The reader signature is `read_rows(file_item, spec_ref) -> Iterator[dict]`. `file_item` is a dlt `FileItemDict`-like object — for tests we construct a tiny stand-in that supports `open(mode="rb")` and exposes `file_name`. The reader must stream (no `list()`, no `read()` of the whole file).

- [ ] **Step 1: Write the failing CSV reader tests**

Create `tests/unit/dlt_glue/file_readers/test_csv.py`:

```python
"""Unit tests for the CSV file reader. See ADR-0022."""

from __future__ import annotations

import io
from pathlib import Path

import pytest

from das_cli.contracts.filesystem_spec_ref import FilesystemSpecRef
from das_cli.dlt_glue.file_readers.csv import read_rows


class _FakeFileItem:
    """Stand-in for dlt's FileItemDict — supports `open(mode='rb')` + `file_name`."""

    def __init__(self, body: bytes, file_name: str = "x.csv"):
        self._body = body
        self.file_name = file_name
        self.file_url = f"file:///fake/{file_name}"
        self.modification_date = "2026-05-12T00:00:00+00:00"

    def open(self, mode: str = "rb") -> io.BytesIO:
        assert mode == "rb", "csv reader must open in binary mode"
        return io.BytesIO(self._body)


def _spec(**overrides: object) -> FilesystemSpecRef:
    base = {"kind": "filesystem", "format": "csv", "path": "*.csv"}
    base.update(overrides)
    return FilesystemSpecRef.model_validate(base)


def test_reads_header_row_then_data() -> None:
    body = b"id,name\n1,Alice\n2,Bob\n"
    fi = _FakeFileItem(body, "customers.csv")
    out = list(read_rows(fi, _spec()))
    assert out == [{"id": "1", "name": "Alice"}, {"id": "2", "name": "Bob"}]


def test_custom_delimiter() -> None:
    body = b"id;name\n1;Alice\n"
    fi = _FakeFileItem(body, "x.csv")
    out = list(read_rows(fi, _spec(delimiter=";")))
    assert out == [{"id": "1", "name": "Alice"}]


def test_custom_encoding() -> None:
    body = "id,name\n1,Café\n".encode("latin-1")
    fi = _FakeFileItem(body, "x.csv")
    out = list(read_rows(fi, _spec(encoding="latin-1")))
    assert out == [{"id": "1", "name": "Café"}]


def test_empty_file_yields_nothing() -> None:
    fi = _FakeFileItem(b"", "empty.csv")
    out = list(read_rows(fi, _spec()))
    assert out == []


def test_header_only_yields_nothing() -> None:
    fi = _FakeFileItem(b"id,name\n", "h.csv")
    out = list(read_rows(fi, _spec()))
    assert out == []


def test_inject_basename_column() -> None:
    body = b"id\n1\n2\n"
    fi = _FakeFileItem(body, "customers_2024-01.csv")
    out = list(read_rows(fi, _spec(inject={"source_file": "basename"})))
    assert out == [
        {"id": "1", "source_file": "customers_2024-01.csv"},
        {"id": "2", "source_file": "customers_2024-01.csv"},
    ]


def test_inject_mtime_column() -> None:
    fi = _FakeFileItem(b"id\n1\n", "x.csv")
    out = list(read_rows(fi, _spec(inject={"loaded_at": "mtime"})))
    assert out == [{"id": "1", "loaded_at": "2026-05-12T00:00:00+00:00"}]


def test_streaming_does_not_load_full_file() -> None:
    """Reader must yield rows one at a time, not load everything via list().

    We can't directly measure RSS, but we can verify the reader returns a
    generator that hasn't consumed its source after one row is pulled.
    """
    body = b"id\n1\n2\n3\n"
    fi = _FakeFileItem(body, "x.csv")
    gen = read_rows(fi, _spec())
    first = next(gen)
    assert first == {"id": "1"}
    # gen is still pending — remaining rows haven't been materialized.
    rest = list(gen)
    assert rest == [{"id": "2"}, {"id": "3"}]
```

- [ ] **Step 2: Run the failing tests**

Run: `uv run pytest tests/unit/dlt_glue/file_readers/test_csv.py -v`
Expected: FAIL with `ImportError: cannot import name 'read_rows'`.

- [ ] **Step 3: Write the CSV reader**

Create `src/das_cli/dlt_glue/file_readers/csv.py`:

```python
"""CSV file reader. See ADR-0022.

Streams rows via stdlib csv.DictReader over a TextIOWrapper around the
fsspec-backed binary file handle. Never materializes the full file.
"""

from __future__ import annotations

import csv as _csv
import io
from collections.abc import Iterator
from pathlib import Path
from typing import Any

from das_cli.contracts.filesystem_spec_ref import FilesystemSpecRef
from das_cli.dlt_glue.file_readers._inject import apply_inject


def read_rows(file_item: Any, spec_ref: FilesystemSpecRef) -> Iterator[dict[str, Any]]:
    """Yield one dict per data row from a CSV file.

    Args:
        file_item: dlt FileItemDict (or stand-in with `open(mode="rb")`,
                   `file_name`, optional `modification_date`).
        spec_ref: Resource spec; uses `delimiter`, `encoding`, `inject`.
    """
    delimiter = spec_ref.delimiter or ","
    encoding = spec_ref.encoding or "utf-8"

    context = _build_inject_context(file_item)

    with file_item.open(mode="rb") as binary:
        text = io.TextIOWrapper(binary, encoding=encoding, newline="")
        reader = _csv.DictReader(text, delimiter=delimiter)
        yield from apply_inject(reader, inject=spec_ref.inject, context=context)


def _build_inject_context(file_item: Any) -> dict[str, Any]:
    file_name = getattr(file_item, "file_name", None) or ""
    file_url = getattr(file_item, "file_url", None) or ""
    mtime = getattr(file_item, "modification_date", None)

    return {
        "basename": Path(file_name).name if file_name else "",
        "fullpath": file_url,
        "mtime": mtime,
    }
```

- [ ] **Step 4: Run the tests and verify they pass**

Run: `uv run pytest tests/unit/dlt_glue/file_readers/test_csv.py -v`
Expected: 8 passed.

- [ ] **Step 5: Commit**

```bash
git add src/das_cli/dlt_glue/file_readers/csv.py tests/unit/dlt_glue/file_readers/test_csv.py
git commit -m "$(cat <<'EOF'
feat(file_readers): CSV reader with streaming + inject

stdlib csv.DictReader over a TextIOWrapper on the file_item's binary
handle. Streams row-by-row; never materializes the full file. Honors
delimiter/encoding from spec_ref and applies inject mapping per
ADR-0023.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

### Task 5: `_build_filesystem_resources` branch in `source_factory.py`

**Files:**
- Modify: `src/das_cli/dlt_glue/source_factory.py`
- Test: `tests/unit/test_source_factory_filesystem.py` (new)

The factory needs a new branch that for each contract:
1. Reads `das.spec_ref` from the contract.
2. Picks the right reader from `dlt_glue/file_readers/`.
3. Builds a dlt resource: `dlt.sources.filesystem(...)` piped into a `@dlt.transformer` that calls `read_rows()` and wraps each row as `{"_data": row}`.

- [ ] **Step 1: Write the failing source-factory tests**

Create `tests/unit/test_source_factory_filesystem.py`:

```python
"""Unit tests for filesystem source factory dispatch. See ADR-0022."""

from __future__ import annotations

from pathlib import Path

import pytest

from das_cli.contracts.loader import LoadedContract
from das_cli.contracts.odcs import (
    CustomProperty,
    OdcsContract,
    OdcsInfo,
    OdcsProperty,
    OdcsSchema,
)
from das_cli.dlt_glue.source_factory import build_extract_resources
from das_cli.models.source_yml import SourceConfig


def _make_fs_contract(
    resource: str,
    *,
    spec_ref: dict[str, object] | None = None,
) -> LoadedContract:
    spec_ref = spec_ref or {
        "kind": "filesystem",
        "format": "csv",
        "path": f"{resource}.csv",
    }
    contract = OdcsContract(
        apiVersion="v3.0.0",
        kind="DataContract",
        id=f"files.{resource}",
        name=resource,
        version="0.1.0",
        status="draft",
        info=OdcsInfo(title=resource),
        schema=[
            OdcsSchema(
                name=resource,
                physicalName=resource,
                physicalType="table",
                properties=[
                    OdcsProperty(
                        name="id", logicalType="integer", primaryKey=True, required=True
                    ),
                ],
            )
        ],
        customProperties=[CustomProperty(property="das.spec_ref", value=spec_ref)],
    )
    return LoadedContract(
        path=Path(f"{resource}.odcs.yaml"), resource_name=resource, contract=contract
    )


def _fs_scfg(endpoint: str = "./data/") -> SourceConfig:
    return SourceConfig.model_validate(
        {
            "type": "filesystem",
            "endpoint": endpoint,
            "spec": {"kind": "filesystem"},
            "auth": {"type": "none"},
        }
    )


def test_filesystem_dispatch_returns_one_resource_per_contract(tmp_path: Path) -> None:
    contracts = [_make_fs_contract("customers"), _make_fs_contract("orders")]
    resources = build_extract_resources(
        _fs_scfg(endpoint=str(tmp_path)), contracts, source_name="files"
    )
    assert len(resources) == 2


def test_filesystem_dispatch_resource_name_matches_contract(tmp_path: Path) -> None:
    contracts = [_make_fs_contract("customers"), _make_fs_contract("orders")]
    resources = build_extract_resources(
        _fs_scfg(endpoint=str(tmp_path)), contracts, source_name="files"
    )
    names = sorted(r.name for r in resources)
    assert names == ["customers", "orders"]


def test_filesystem_csv_resource_yields_blob_wrapped_rows(tmp_path: Path) -> None:
    """Smoke: drop a real CSV in tmp_path and assert the resource produces blobs."""
    (tmp_path / "customers.csv").write_text("id,name\n1,Alice\n2,Bob\n")
    contracts = [_make_fs_contract("customers")]
    resources = build_extract_resources(
        _fs_scfg(endpoint=str(tmp_path)), contracts, source_name="files"
    )
    out = list(resources[0])
    assert out == [
        {"_data": {"id": "1", "name": "Alice"}},
        {"_data": {"id": "2", "name": "Bob"}},
    ]


def test_filesystem_unknown_format_raises(tmp_path: Path) -> None:
    # Bypass FilesystemSpecRef validation by constructing the contract with a
    # raw value (Pydantic at the validator boundary would catch this in
    # workspace-level validation, but the factory should also defend itself).
    contracts = [
        _make_fs_contract(
            "weird",
            spec_ref={"kind": "filesystem", "format": "parquet", "path": "x.parquet"},
        )
    ]
    with pytest.raises(ValueError, match="No file reader for format"):
        build_extract_resources(
            _fs_scfg(endpoint=str(tmp_path)), contracts, source_name="files"
        )
```

- [ ] **Step 2: Run the failing tests**

Run: `uv run pytest tests/unit/test_source_factory_filesystem.py -v`
Expected: FAIL — `UnknownSourceTypeError` or similar (no filesystem branch yet).

- [ ] **Step 3: Extend `source_factory.py` with the filesystem branch**

Edit `src/das_cli/dlt_glue/source_factory.py`. Find the `build_extract_resources` function near the bottom of the file. Above it, insert these two new functions:

```python
def _select_file_reader(format_name: str) -> Any:
    """Return the `read_rows` callable for a given format. See ADR-0022."""
    if format_name == "csv":
        from das_cli.dlt_glue.file_readers import csv as csv_reader

        return csv_reader.read_rows
    # excel, xml, qvd land in future format PRs under ADR-0022.
    raise ValueError(
        f"No file reader for format '{format_name}'. Supported: csv. "
        "(excel/xml/qvd are planned follow-ups.)"
    )


def _make_filesystem_resource(
    *,
    endpoint: str,
    spec_ref: Any,  # FilesystemSpecRef; not annotated to avoid circular import surface
    resource_name: str,
    limit: int | None,
    progress_handle: ProgressHandle | None,
) -> Any:
    """Build a single dlt resource for one filesystem-typed contract.

    Composes dlt's filesystem source (file enumeration + fsspec auth +
    incremental mtime tracking) with a per-format reader transformer.
    See ADR-0022.
    """
    from dlt.sources.filesystem import filesystem  # type: ignore[attr-defined]

    read_rows = _select_file_reader(spec_ref.format)

    files_resource = filesystem(bucket_url=endpoint, file_glob=spec_ref.path)

    @dlt.transformer(  # type: ignore[misc,call-overload,untyped-decorator]
        data_from=files_resource,
        name=resource_name,
        write_disposition="append",
        columns={"_data": {"data_type": "json", "nullable": False}},
        primary_key=None,
    )
    def _parse(file_item: Any) -> Iterator[dict[str, Any]]:
        # See ADR-0003: blob pattern.
        rows: Iterator[dict[str, Any]] = read_rows(file_item, spec_ref)
        if limit is not None:
            rows = _limit_gen(rows, limit)
        if progress_handle is not None:
            rows = progress_handle.wrap(resource_name, rows)
        for row in rows:
            yield {"_data": row}

    return _parse


def _build_filesystem_resources(
    scfg: SourceConfig,
    contracts: list[LoadedContract],
    *,
    source_name: str,
    limit: int | None = None,
    progress_handle: ProgressHandle | None = None,
) -> list[Any]:
    """Build dlt resources for a filesystem source. See ADR-0022."""
    from das_cli.contracts.filesystem_spec_ref import FilesystemSpecRef

    endpoint = scfg.endpoint.rstrip("/")
    out: list[Any] = []
    for contract in contracts:
        raw_spec_ref = get_das_value(contract.contract.custom_properties, "das.spec_ref")
        if raw_spec_ref is None:
            raise ValueError(
                f"contract '{contract.resource_name}' missing das.spec_ref "
                f"(required for type=filesystem)"
            )
        spec_ref = FilesystemSpecRef.model_validate(raw_spec_ref)
        out.append(
            _make_filesystem_resource(
                endpoint=endpoint,
                spec_ref=spec_ref,
                resource_name=contract.resource_name,
                limit=limit,
                progress_handle=progress_handle,
            )
        )
    return out
```

Then, in the existing `build_extract_resources` function, replace the final branch:

```python
    if scfg.type == "sql":
        # See ADR-0018.
        return _build_sql_resources(
            scfg,
            contracts,
            source_name=source_name,
            limit=limit,
            progress_handle=progress_handle,
        )
    raise UnknownSourceTypeError(f"No P1 builder for source type '{scfg.type}'")
```

with:

```python
    if scfg.type == "sql":
        # See ADR-0018.
        return _build_sql_resources(
            scfg,
            contracts,
            source_name=source_name,
            limit=limit,
            progress_handle=progress_handle,
        )
    if scfg.type == "filesystem":
        # See ADR-0022.
        return _build_filesystem_resources(
            scfg,
            contracts,
            source_name=source_name,
            limit=limit,
            progress_handle=progress_handle,
        )
    raise UnknownSourceTypeError(f"No P1 builder for source type '{scfg.type}'")
```

- [ ] **Step 4: Run the source-factory tests and verify they pass**

Run: `uv run pytest tests/unit/test_source_factory_filesystem.py -v`
Expected: 4 passed.

- [ ] **Step 5: Run the existing SQL/HTTP source-factory tests to confirm no regressions**

Run: `uv run pytest tests/unit/test_source_factory.py tests/unit/test_source_factory_sql.py -v`
Expected: all existing pass; `test_filesystem_still_raises_unknown_source_type_error` in `test_source_factory_sql.py` will now FAIL (it asserted the old behavior).

- [ ] **Step 6: Update the stale assertion**

Edit `tests/unit/test_source_factory_sql.py` — find `test_filesystem_still_raises_unknown_source_type_error` and rename + rewrite it to assert the new behavior. Replace the entire function with:

```python
def test_filesystem_now_dispatches_to_filesystem_branch() -> None:
    """Filesystem used to raise UnknownSourceTypeError; ADR-0022 makes it dispatch."""
    scfg = SourceConfig.model_validate(
        {
            "type": "filesystem",
            "endpoint": "file:///tmp",
            "spec": {"kind": "filesystem"},
            "auth": {"type": "none"},
        }
    )
    # A bare filesystem source with no contracts should produce an empty list,
    # not raise UnknownSourceTypeError.
    resources = build_extract_resources(scfg, [], source_name="x")
    assert resources == []
```

- [ ] **Step 7: Run the SQL test file again**

Run: `uv run pytest tests/unit/test_source_factory_sql.py -v`
Expected: all passed.

- [ ] **Step 8: Commit**

```bash
git add src/das_cli/dlt_glue/source_factory.py tests/unit/test_source_factory_filesystem.py tests/unit/test_source_factory_sql.py
git commit -m "$(cat <<'EOF'
feat(source_factory): _build_filesystem_resources for type=filesystem

Per ADR-0022: one branch in build_extract_resources dispatches
filesystem-typed sources. Each contract gets a dlt.sources.filesystem
file enumerator piped into a per-format reader transformer that
wraps each row as {"_data": row}. csv reader wired; excel/xml/qvd
selectors raise with a clear message until their PRs ship.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

### Task 6: `bootstrap/filesystem.py` — discovery walker for CSV

**Files:**
- Create: `src/das_cli/bootstrap/filesystem.py`
- Test: `tests/unit/test_bootstrap_filesystem.py` (new)

The walker scans `endpoint` for CSV files and emits one `LoadedContract` per file. Column names come from the header row; all types default to `logicalType: string`. Each contract's `das.spec_ref` is set to the single file's path; the user widens to a glob if they want combining.

- [ ] **Step 1: Write the failing bootstrap tests**

Create `tests/unit/test_bootstrap_filesystem.py`:

```python
"""Unit tests for filesystem bootstrap. See ADR-0022."""

from __future__ import annotations

from pathlib import Path

import pytest

from das_cli.bootstrap.filesystem import bootstrap_filesystem_contracts
from das_cli.contracts.custom_properties import get_das_value
from das_cli.models.source_yml import SourceConfig


def _scfg(endpoint: str) -> SourceConfig:
    return SourceConfig.model_validate(
        {
            "type": "filesystem",
            "endpoint": endpoint,
            "spec": {"kind": "filesystem"},
            "auth": {"type": "none"},
        }
    )


def test_emits_one_contract_per_csv(tmp_path: Path) -> None:
    (tmp_path / "customers.csv").write_text("id,name\n1,Alice\n")
    (tmp_path / "orders.csv").write_text("order_id,amount\n10,99.50\n")
    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files"
    )
    names = sorted(c.resource_name for c in contracts)
    assert names == ["customers", "orders"]


def test_columns_taken_from_header_row(tmp_path: Path) -> None:
    (tmp_path / "customers.csv").write_text("id,name,email\n1,Alice,a@x\n")
    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files"
    )
    schema = contracts[0].contract.primary_schema
    assert [p.name for p in schema.properties] == ["id", "name", "email"]


def test_types_default_to_string(tmp_path: Path) -> None:
    (tmp_path / "x.csv").write_text("a,b\n1,2\n")
    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files"
    )
    types = [p.logicalType for p in contracts[0].contract.primary_schema.properties]
    assert types == ["string", "string"]


def test_spec_ref_records_filename(tmp_path: Path) -> None:
    (tmp_path / "customers.csv").write_text("id\n1\n")
    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files"
    )
    spec_ref = get_das_value(
        contracts[0].contract.custom_properties, "das.spec_ref"
    )
    assert spec_ref == {
        "kind": "filesystem",
        "format": "csv",
        "path": "customers.csv",
    }


def test_resource_name_snake_cased(tmp_path: Path) -> None:
    (tmp_path / "CustomerOrders.csv").write_text("Id\n1\n")
    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files"
    )
    assert contracts[0].resource_name == "customer_orders"


def test_skips_non_csv_files(tmp_path: Path) -> None:
    (tmp_path / "customers.csv").write_text("id\n1\n")
    (tmp_path / "readme.txt").write_text("hello")
    (tmp_path / "notes.md").write_text("# notes")
    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files"
    )
    names = [c.resource_name for c in contracts]
    assert names == ["customers"]


def test_empty_directory_returns_empty_list(tmp_path: Path) -> None:
    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files"
    )
    assert contracts == []


def test_empty_csv_emits_contract_with_no_properties(tmp_path: Path) -> None:
    """A CSV with no header row produces an empty-schema contract.

    Bootstrap leaves the contract in a state the user can edit; the validator
    will then flag the empty schema if they try to ingest.
    """
    (tmp_path / "x.csv").write_text("")
    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files"
    )
    assert len(contracts) == 1
    assert contracts[0].contract.primary_schema.properties == []
```

- [ ] **Step 2: Run the failing tests**

Run: `uv run pytest tests/unit/test_bootstrap_filesystem.py -v`
Expected: FAIL with `ImportError`.

- [ ] **Step 3: Write the bootstrap walker**

Create `src/das_cli/bootstrap/filesystem.py`:

```python
"""Discover files under a filesystem source's endpoint and emit ODCS contracts.

See ADR-0022: filesystem source type.
"""

from __future__ import annotations

import csv as _csv
from pathlib import Path

from das_cli.bootstrap.naming import snake_case
from das_cli.contracts.loader import LoadedContract
from das_cli.contracts.odcs import (
    CustomProperty,
    OdcsContract,
    OdcsInfo,
    OdcsProperty,
    OdcsSchema,
)
from das_cli.models.source_yml import SourceConfig


def bootstrap_filesystem_contracts(
    scfg: SourceConfig,
    *,
    source_name: str,
) -> list[LoadedContract]:
    """Walk `scfg.endpoint` and emit one ODCS contract per discoverable file.

    Plan #1 supports CSV only. Excel/XML/QVD discovery lands in follow-up PRs.
    Local paths only at the moment; blob endpoints (`az://`, `s3://`) require
    fsspec wiring and are deferred to a follow-up.
    """
    endpoint = scfg.endpoint
    if endpoint.startswith(("s3://", "gs://", "az://")):
        raise NotImplementedError(
            "Bootstrap from blob endpoints is not yet supported. "
            "Mirror the files locally and re-run, or write contracts by hand."
        )

    root = Path(endpoint).expanduser()
    if not root.is_dir():
        raise FileNotFoundError(f"Filesystem source endpoint not found: {root}")

    out: list[LoadedContract] = []
    for path in sorted(root.iterdir()):
        if not path.is_file():
            continue
        suffix = path.suffix.lower()
        if suffix == ".csv":
            out.append(_build_csv_contract(path, source_name=source_name))
        # excel/xml/qvd dispatch lands in their follow-up plans under ADR-0022.
    return out


def _build_csv_contract(file_path: Path, *, source_name: str) -> LoadedContract:
    resource_name = snake_case(file_path.stem)

    columns = _read_csv_header(file_path)
    properties = [
        OdcsProperty(name=col, logicalType="string") for col in columns
    ]

    spec_ref_value = {
        "kind": "filesystem",
        "format": "csv",
        "path": file_path.name,
    }

    contract = OdcsContract(
        apiVersion="v3.0.0",
        kind="DataContract",
        id=f"{source_name}.{resource_name}",
        name=resource_name,
        version="0.1.0",
        status="draft",
        info=OdcsInfo(title=resource_name, owner="data-platform"),
        schema=[
            OdcsSchema(
                name=resource_name,
                physicalName=resource_name,
                physicalType="table",
                properties=properties,
            )
        ],
        customProperties=[
            CustomProperty(property="das.spec_ref", value=spec_ref_value)
        ],
    )

    return LoadedContract(
        path=Path(f"{resource_name}.odcs.yaml"),
        resource_name=resource_name,
        contract=contract,
    )


def _read_csv_header(file_path: Path) -> list[str]:
    """Return the header row of a CSV file; empty list if the file is empty."""
    with file_path.open("r", encoding="utf-8", newline="") as fh:
        reader = _csv.reader(fh)
        try:
            header = next(reader)
        except StopIteration:
            return []
    return [col.strip() for col in header if col.strip()]
```

- [ ] **Step 4: Run the tests and verify they pass**

Run: `uv run pytest tests/unit/test_bootstrap_filesystem.py -v`
Expected: 8 passed.

- [ ] **Step 5: Commit**

```bash
git add src/das_cli/bootstrap/filesystem.py tests/unit/test_bootstrap_filesystem.py
git commit -m "$(cat <<'EOF'
feat(bootstrap): filesystem walker for CSV discovery

Walks scfg.endpoint, emits one ODCS contract per *.csv file. Column
names come from the header row; types default to logicalType: string
(user refines after bootstrap). das.spec_ref records the per-file path;
user widens to a glob if combining is desired.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

### Task 7: CLI — dispatch `contract bootstrap` to filesystem

**Files:**
- Modify: `src/das_cli/cli.py` (extend `contract_bootstrap`)
- Test: `tests/unit/test_cli_bootstrap_filesystem.py` (new)

The existing `contract_bootstrap` function dispatches on `scfg.spec.kind`. Add a `filesystem` branch that calls `bootstrap_filesystem_contracts`.

- [ ] **Step 1: Write the failing CLI test**

Create `tests/unit/test_cli_bootstrap_filesystem.py`:

```python
"""CLI: das contract bootstrap for type=filesystem. See ADR-0022."""

from __future__ import annotations

from pathlib import Path

from typer.testing import CliRunner

from das_cli.cli import app


def _seed_workspace(root: Path, *, source_name: str = "files") -> Path:
    """Create a minimal das workspace under `root` with a filesystem source."""
    (root / "das.yaml").write_text(
        "contracts:\n  root: contracts\n"
        "landing:\n  bucket_url: ./landing\n"
        "defaults:\n  change_detection: row_hash\n"
    )

    data_dir = root / "data"
    data_dir.mkdir()
    (data_dir / "customers.csv").write_text("id,name\n1,Alice\n")
    (data_dir / "orders.csv").write_text("order_id,amount\n10,99.50\n")

    src_dir = root / "contracts" / source_name
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(
        f"type: filesystem\n"
        f"endpoint: {data_dir}\n"
        "spec:\n  kind: filesystem\n"
        "auth:\n  type: none\n"
    )
    return src_dir


def test_filesystem_bootstrap_writes_one_contract_per_csv(tmp_path: Path) -> None:
    src_dir = _seed_workspace(tmp_path)
    runner = CliRunner()
    result = runner.invoke(
        app,
        ["--config", str(tmp_path / "das.yaml"), "contract", "bootstrap", "files"],
    )
    assert result.exit_code == 0, result.stdout
    written = sorted(p.name for p in src_dir.glob("*.odcs.yaml"))
    assert written == ["customers.odcs.yaml", "orders.odcs.yaml"]


def test_filesystem_bootstrap_only_filter(tmp_path: Path) -> None:
    src_dir = _seed_workspace(tmp_path)
    runner = CliRunner()
    result = runner.invoke(
        app,
        [
            "--config",
            str(tmp_path / "das.yaml"),
            "contract",
            "bootstrap",
            "files",
            "--only",
            "customers",
        ],
    )
    assert result.exit_code == 0, result.stdout
    written = sorted(p.name for p in src_dir.glob("*.odcs.yaml"))
    assert written == ["customers.odcs.yaml"]


def test_filesystem_bootstrap_dry_run(tmp_path: Path) -> None:
    src_dir = _seed_workspace(tmp_path)
    runner = CliRunner()
    result = runner.invoke(
        app,
        [
            "--config",
            str(tmp_path / "das.yaml"),
            "contract",
            "bootstrap",
            "files",
            "--dry-run",
        ],
    )
    assert result.exit_code == 0, result.stdout
    assert list(src_dir.glob("*.odcs.yaml")) == []
    assert "dry-run" in result.stdout
```

- [ ] **Step 2: Run the failing test**

Run: `uv run pytest tests/unit/test_cli_bootstrap_filesystem.py -v`
Expected: FAIL — `contract_bootstrap` returns a `die()` message about unsupported spec.kind, OR `loaded` is undefined.

- [ ] **Step 3: Extend `cli.py contract_bootstrap`**

Edit `src/das_cli/cli.py`. Locate the existing `if scfg.spec.kind == "odata":` block inside `contract_bootstrap` (around line 546). The dispatch ends with `elif scfg.spec.kind == "sql":` and an `else:` that dies. Add a new branch before the `else:`. Replace:

```python
    elif scfg.spec.kind == "sql":
        # See ADR-0018.
        from das_cli.bootstrap.sql import bootstrap_sql_contracts

        loaded = bootstrap_sql_contracts(scfg, source_name=source)
    else:
        die(f"Cannot bootstrap from spec.kind={scfg.spec.kind}", code=USAGE)
        return
```

with:

```python
    elif scfg.spec.kind == "sql":
        # See ADR-0018.
        from das_cli.bootstrap.sql import bootstrap_sql_contracts

        loaded = bootstrap_sql_contracts(scfg, source_name=source)
    elif scfg.spec.kind == "filesystem":
        # See ADR-0022.
        from das_cli.bootstrap.filesystem import bootstrap_filesystem_contracts

        loaded = bootstrap_filesystem_contracts(scfg, source_name=source)
    else:
        die(f"Cannot bootstrap from spec.kind={scfg.spec.kind}", code=USAGE)
        return
```

- [ ] **Step 4: Run the CLI tests and verify they pass**

Run: `uv run pytest tests/unit/test_cli_bootstrap_filesystem.py -v`
Expected: 3 passed.

- [ ] **Step 5: Commit**

```bash
git add src/das_cli/cli.py tests/unit/test_cli_bootstrap_filesystem.py
git commit -m "$(cat <<'EOF'
feat(cli): contract bootstrap dispatch for type=filesystem

Wires bootstrap_filesystem_contracts into contract_bootstrap. Honors
--only and --dry-run the same way the OData/OpenAPI/SQL branches do.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

### Task 8: CLI — `source add` template for filesystem

**Files:**
- Modify: `src/das_cli/cli.py` (`_source_yml_template` + `source_add`)
- Test: `tests/unit/test_cli_skeleton.py` (extend existing)

`das source add --type filesystem --url ./data/` must write a `_source.yml` whose `spec.kind == "filesystem"`. The auth block is `none` (no credentials handled by das for local paths; blob auth uses dlt env-var config).

- [ ] **Step 1: Read the existing skeleton tests to see the pattern**

Run: `uv run pytest tests/unit/test_cli_skeleton.py --collect-only -q`
Expected: list of skeleton test names. Note the typical test shape — a `CliRunner.invoke` then assertions on the written `_source.yml`.

- [ ] **Step 2: Write the failing source-add test**

Append to `tests/unit/test_cli_skeleton.py` (or place in a new file `tests/unit/test_cli_source_add_filesystem.py` if it cleaner there). New file content:

```python
"""CLI: das source add --type filesystem. See ADR-0022."""

from __future__ import annotations

from pathlib import Path

from typer.testing import CliRunner

from das_cli.cli import app


def test_source_add_filesystem_writes_source_yml(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.chdir(tmp_path)
    runner = CliRunner()
    result = runner.invoke(
        app, ["source", "add", "files", "--type", "filesystem", "--url", "./data/"]
    )
    assert result.exit_code == 0, result.stdout
    src_yml = (tmp_path / "contracts" / "files" / "_source.yml").read_text()
    assert "type: filesystem" in src_yml
    assert "endpoint: ./data/" in src_yml
    assert "spec:\n  kind: filesystem" in src_yml
    assert "auth:\n  type: none" in src_yml


def test_source_add_filesystem_rejects_auth_basic(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.chdir(tmp_path)
    runner = CliRunner()
    result = runner.invoke(
        app,
        [
            "source",
            "add",
            "files",
            "--type",
            "filesystem",
            "--url",
            "./data/",
            "--auth",
            "basic",
        ],
    )
    # Filesystem credentials flow through dlt's filesystem config, not the
    # auth block — basic/bearer/api_key on --auth are nonsense.
    assert result.exit_code != 0
    assert "auth" in result.stdout.lower()
```

- [ ] **Step 3: Run the failing tests**

Run: `uv run pytest tests/unit/test_cli_source_add_filesystem.py -v`
Expected: FAIL — the second test won't fail in the way we want yet (the existing flow allows `basic` auth on any non-SQL source). We need an explicit rejection.

- [ ] **Step 4: Wire filesystem into `_source_yml_template` and add the auth guard**

Edit `src/das_cli/cli.py`. First, in `_source_yml_template` (the function that renders the YAML body, around line 247), find the `spec = ""` block:

```python
    spec = ""
    if source_type == "odata":
        spec = f"spec:\n  kind: odata\n  metadata_url: {url.rstrip('/')}/$metadata\n"
    elif source_type in {"openapi", "rest"}:
        spec = f"spec:\n  kind: openapi\n  swagger_url: {url.rstrip('/')}/swagger.json\n"
    else:
        spec = "spec:\n  kind: none\n"
```

Replace with:

```python
    spec = ""
    if source_type == "odata":
        spec = f"spec:\n  kind: odata\n  metadata_url: {url.rstrip('/')}/$metadata\n"
    elif source_type in {"openapi", "rest"}:
        spec = f"spec:\n  kind: openapi\n  swagger_url: {url.rstrip('/')}/swagger.json\n"
    elif source_type == "filesystem":
        # See ADR-0022.
        spec = "spec:\n  kind: filesystem\n"
    else:
        spec = "spec:\n  kind: none\n"
```

Then, in `source_add` (around line 339, right after the existing SQL-specific block), add a filesystem guard. Find:

```python
    if type_ == "sql":
        if auth != "none":
            die(
                "--auth is not used for sql sources; credentials are templated "
                "into the endpoint URL.",
                code=USAGE,
            )
        url_err = _validate_sql_url(url)
        if url_err is not None:
            die(url_err, code=USAGE)
```

Right after that block (before the `src_dir = Path("contracts") / name` line), insert:

```python
    if type_ == "filesystem" and auth != "none":
        # See ADR-0022: filesystem credentials flow through dlt's filesystem
        # config (env vars), not the per-source auth block.
        die(
            "--auth is not used for filesystem sources; blob credentials flow "
            "through dlt's filesystem config (env vars).",
            code=USAGE,
        )
```

- [ ] **Step 5: Run the CLI tests and verify they pass**

Run: `uv run pytest tests/unit/test_cli_source_add_filesystem.py -v`
Expected: 2 passed.

- [ ] **Step 6: Run the full skeleton suite to confirm no regressions**

Run: `uv run pytest tests/unit/test_cli_skeleton.py tests/unit/test_cli_source_add_filesystem.py -v`
Expected: all passed.

- [ ] **Step 7: Commit**

```bash
git add src/das_cli/cli.py tests/unit/test_cli_source_add_filesystem.py
git commit -m "$(cat <<'EOF'
feat(cli): source add --type filesystem template + auth guard

Adds the spec block (kind: filesystem) to _source_yml_template so
'das source add --type filesystem' writes a valid _source.yml. Rejects
non-none --auth on filesystem sources (blob auth flows through dlt's
filesystem config per ADR-0022).

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

### Task 9: E2E — CSV to DuckDB

**Files:**
- Create: `tests/e2e/sources/test_csv_to_duckdb.py`
- Create: `tests/e2e/fixtures/csv/` (directory)
- Create: `tests/e2e/fixtures/csv/customers_2024-01.csv`
- Create: `tests/e2e/fixtures/csv/customers_2024-02.csv`

E2E pattern follows the SQL e2e tests: create a workspace under `tmp_path`, run `das source add` → `contract bootstrap` → `ingest`, assert rows landed in DuckDB.

- [ ] **Step 1: Create the fixture CSV files**

Create `tests/e2e/fixtures/csv/customers_2024-01.csv`:

```
customer_id,name,signup_month
1,Alice,2024-01
2,Bob,2024-01
3,Charlie,2024-01
```

Create `tests/e2e/fixtures/csv/customers_2024-02.csv`:

```
customer_id,name,signup_month
4,Diana,2024-02
5,Eve,2024-02
```

- [ ] **Step 2: Write the failing e2e test**

Create `tests/e2e/sources/test_csv_to_duckdb.py`:

```python
"""E2E: das against a local CSV folder, landing into DuckDB. See ADR-0022.

Opt-in via `pytest -m e2e`. Reads fixtures from tests/e2e/fixtures/csv/.

Uses the shared `workspace` + `cli_runner` fixtures from tests/conftest.py.
`workspace` is a tmp_path with cwd switched, DAS_TARGET_DB and DAS_LANDING_URL
env vars set. The pattern mirrors tests/e2e/sources/test_oracle.py.
"""

from __future__ import annotations

import shutil
from pathlib import Path

import duckdb
from typer.testing import CliRunner

from das_cli.cli import app

FIXTURE_DIR = Path(__file__).parent.parent / "fixtures" / "csv"


def test_csv_glob_to_duckdb_with_provenance(
    workspace: Path, cli_runner: CliRunner
) -> None:
    """Glob across monthly partitioned CSV files; assert combined row count + provenance."""

    # Stage the fixture CSVs in a data directory inside the workspace.
    data_dir = workspace / "data"
    data_dir.mkdir()
    shutil.copy(FIXTURE_DIR / "customers_2024-01.csv", data_dir)
    shutil.copy(FIXTURE_DIR / "customers_2024-02.csv", data_dir)

    # 1. init — writes das.yaml in cwd (the workspace fixture has chdir'd here).
    init = cli_runner.invoke(app, ["init"])
    assert init.exit_code == 0, init.stdout + init.stderr

    # 2. source add
    add = cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "files",
            "--type",
            "filesystem",
            "--url",
            str(data_dir),
        ],
    )
    assert add.exit_code == 0, add.stdout + add.stderr

    # 3. contract bootstrap — writes one contract per CSV
    boot = cli_runner.invoke(app, ["contract", "bootstrap", "files"])
    assert boot.exit_code == 0, boot.stdout + boot.stderr

    contracts_dir = workspace / "contracts" / "files"
    written = sorted(p.name for p in contracts_dir.glob("*.odcs.yaml"))
    assert written == [
        "customers_2024_01.odcs.yaml",
        "customers_2024_02.odcs.yaml",
    ]

    # 4. Merge the two contracts into a single "customers" resource with a glob,
    #    a primary key, and an inject column for provenance. This is what a
    #    user does post-bootstrap.
    (contracts_dir / "customers_2024_01.odcs.yaml").unlink()
    (contracts_dir / "customers_2024_02.odcs.yaml").unlink()

    (contracts_dir / "customers.odcs.yaml").write_text(
        "apiVersion: v3.0.0\n"
        "kind: DataContract\n"
        "id: files.customers\n"
        "name: customers\n"
        "version: 0.1.0\n"
        "status: draft\n"
        "info:\n  title: customers\n  owner: data-platform\n"
        "schema:\n"
        "  - name: customers\n"
        "    physicalName: customers\n"
        "    physicalType: table\n"
        "    properties:\n"
        "      - name: customer_id\n"
        "        logicalType: integer\n"
        "        primaryKey: true\n"
        "        required: true\n"
        "      - name: name\n"
        "        logicalType: string\n"
        "      - name: signup_month\n"
        "        logicalType: string\n"
        "      - name: source_file\n"
        "        logicalType: string\n"
        "customProperties:\n"
        "  - property: das.spec_ref\n"
        "    value:\n"
        "      kind: filesystem\n"
        "      format: csv\n"
        "      path: 'customers_*.csv'\n"
        "      inject:\n"
        "        source_file: basename\n"
    )

    # 5. extract + load (the Oracle test uses the same two-step flow).
    ext = cli_runner.invoke(app, ["extract", "files"])
    assert ext.exit_code == 0, ext.stdout + ext.stderr

    load = cli_runner.invoke(app, ["load", "files"])
    assert load.exit_code == 0, load.stdout + load.stderr

    # 6. Assert rows in DuckDB. The `workspace` fixture sets DAS_TARGET_DB to
    #    workspace / "test.duckdb"; das.yaml's default template uses that env
    #    var, so the DB lands there. Tables are namespaced under das__<source>.
    db = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        rows = db.execute(
            'SELECT customer_id, name, source_file FROM "das__files".customers '
            "ORDER BY customer_id"
        ).fetchall()
    finally:
        db.close()

    assert rows == [
        (1, "Alice", "customers_2024-01.csv"),
        (2, "Bob", "customers_2024-01.csv"),
        (3, "Charlie", "customers_2024-01.csv"),
        (4, "Diana", "customers_2024-02.csv"),
        (5, "Eve", "customers_2024-02.csv"),
    ]
```

- [ ] **Step 3: Run the e2e test (opt-in)**

Run: `uv run pytest tests/e2e/sources/test_csv_to_duckdb.py -m e2e -v`
Expected: PASS. (The `workspace` fixture in `tests/conftest.py` already handles cwd switching via `monkeypatch.chdir(tmp_path)` and sets the required env vars; the e2e marker is auto-injected by `tests/e2e/conftest.py` based on path.)

- [ ] **Step 4: Run the full test suite to ensure no regression**

Run: `uv run pytest -q` (unit + integration)
Expected: all pass.
Run: `uv run pytest -m e2e -v -k csv`
Expected: the new csv e2e passes.

- [ ] **Step 5: Commit**

```bash
git add tests/e2e/fixtures/csv/ tests/e2e/sources/test_csv_to_duckdb.py
git commit -m "$(cat <<'EOF'
test(e2e): CSV-to-DuckDB edge with glob + provenance

Verifies the filesystem source umbrella end-to-end: source add →
contract bootstrap → manual contract widening to a glob with an
inject column → ingest → DuckDB row assertions. Two monthly fixture
files (2024-01 + 2024-02) get combined by the customers_*.csv glob;
the source_file inject column proves per-row provenance is preserved.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

### Task 10: README — add CSV to the verified sources table

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Locate the "Verified sources" table**

Read `README.md`. Find the table starting with `| Source              | Notes                                                  |`.

- [ ] **Step 2: Append the CSV row**

In the verified sources table, after the SQL Server row, append:

```markdown
| CSV (local)         | Filesystem source via dlt (ADR-0022); glob across files |
```

- [ ] **Step 3: Add a CSV quickstart snippet**

After the existing SQL quickstart in the README ("For a SQL source..."), add a new section:

````markdown
For a CSV source (local files), point das at a directory of CSV files.
das walks the directory, emits one contract per file, then ingests via a
glob if the user widens the contract's `das.spec_ref.path`:

```bash
das source add accounts \
  --type filesystem \
  --url ./data/accounts/

das contract bootstrap accounts
# Edit contracts/accounts/*.odcs.yaml — widen `path` to a glob and refine types.

das ingest accounts
```
````

- [ ] **Step 4: Commit**

```bash
git add README.md
git commit -m "$(cat <<'EOF'
docs(readme): document CSV file source + verified-edge row

Adds the CSV row to the verified sources table (DuckDB destination
edge covered by tests/e2e/sources/test_csv_to_duckdb.py) and a
quickstart snippet for local CSV ingest under ADR-0022.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Post-plan verification

After all tasks land, run the full verification sweep:

- [ ] `uv run pytest -q` — unit + integration (e2e excluded by default).
- [ ] `uv run pytest -m e2e -v` — opt-in e2e suite, including the new csv edge.
- [ ] `uv run pre-commit run --all-files` — ruff format/lint + mypy.
- [ ] Manual sanity in a scratch dir: `mkdir /tmp/dascsv && cd /tmp/dascsv && das init && mkdir data && cp ~/some-file.csv data/ && das source add files --type filesystem --url ./data/ && das contract bootstrap files && das ingest files`. Confirm `das.duckdb` contains the rows.

## What's left for Plans #2–#4

This plan delivers the umbrella + CSV. The follow-on plans each add one format and lean on this plan's plumbing:

- **Plan #2 (Excel):** new `file_readers/excel.py` (openpyxl read-only streaming); extend `bootstrap/filesystem.py` to discover `*.xlsx` and emit one contract per sheet (`das.spec_ref.sheet`); add `openpyxl` to the `[excel]` extra; e2e edge.
- **Plan #3 (XML):** new `file_readers/xml.py` (lxml iterparse with the `elem.clear()` discipline); extend bootstrap with an `--xpath` flag (xml only); add `lxml` to `[xml]` extra; e2e edge.
- **Plan #4 (QVD):** library-research spike up front (streaming-capable parser); new `file_readers/qvd.py`; bootstrap reads embedded XML metadata header for both names *and* types; add the chosen parser to `[qvd]` extra; e2e edge.

Each follow-on plan adds exactly one new `file_readers/<format>.py` and one new `bootstrap/filesystem.py` extension; no ADRs (ADR-0022/0021 already cover the umbrella).
