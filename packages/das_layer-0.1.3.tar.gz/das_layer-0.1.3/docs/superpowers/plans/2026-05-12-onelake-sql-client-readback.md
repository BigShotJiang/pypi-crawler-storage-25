# OneLake sql_client() read-back (issue #55) — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make `pipeline.sql_client()` against OneLake-backed Delta tables authenticate correctly, so `change_detection.load_latest_hash` works on second-cycle loads and the gated e2e read-back assertions pass.

**Architecture:**
- A new context-manager helper `open_sql_client(pipeline, *, bucket_url, azure)` in `src/das_cli/dlt_glue/azure_credentials.py` wraps `pipeline.sql_client()`. For Fabric URLs only, it issues `CREATE OR REPLACE SECRET ... TYPE AZURE PROVIDER ACCESS_TOKEN ACCOUNT_NAME 'onelake'` against the DuckDB connection dlt opens, overwriting dlt's malformed CONNECTION_STRING secret.
- The bearer token is acquired from the configured `AzureCredentials` via the existing token helper (promoted to public).
- `change_detection.load_latest_hash` gains optional `bucket_url=` and `azure=` kwargs, threaded down from `pipelines/load.py:_build_destination` through `_build_load_resource`.
- Non-Fabric paths (local Delta, ADLS Gen2, duckdb, ducklake) are pass-through no-ops.

**Tech Stack:** Python 3.12, dlt 1.26, DuckDB Azure + Delta extensions, azure-identity, pytest, ruff, mypy. Project uses `uv` for dependency management.

**Spec:** [docs/superpowers/specs/2026-05-12-onelake-sql-client-readback-design.md](../specs/2026-05-12-onelake-sql-client-readback-design.md)

---

## File Structure

**Source files (modify):**
- `src/das_cli/dlt_glue/azure_credentials.py` — rename `_acquire_storage_bearer_token` → `acquire_storage_bearer_token`; add `_build_fabric_secret_sql` (pure helper), `_install_fabric_duckdb_secret`, and `open_sql_client` (context manager).
- `src/das_cli/pipelines/change_detection.py` — extend `load_latest_hash` signature to accept `bucket_url` and `azure`; route through `open_sql_client`.
- `src/das_cli/pipelines/load.py` — capture parsed `azure` + `bucket_url` once in `_build_destination` (returns the destination plus the auth pair via a helper); thread both through `_build_load_resource` to `load_latest_hash`.

**Test files (modify/extend):**
- `tests/unit/test_azure_credentials.py` — append tests for `_build_fabric_secret_sql` and `open_sql_client`.
- `tests/unit/test_change_detection_filter.py` (or new `tests/unit/test_change_detection_load_latest_hash.py`) — add unit test for the bucket_url/azure pass-through.
- `tests/e2e/destinations/test_delta_azure.py` — switch the reader's `sql_client()` to `open_sql_client(...)`.

**ADRs:**
- `docs/adrs/0021-onelake-duckdb-readback-via-access-token-secret.md` — new ADR; Supersedes ADR-0020. Restates A/B/C/D verbatim and adds the DuckDB read-back decision.
- `docs/adrs/0020-azure-landing-and-delta-via-fsspec-and-typed-credentials.md` — Status field flip only (`Accepted` → `Superseded by ADR-0021`). No other edits.
- `docs/adrs/README.md` — add ADR-0021 row; update ADR-0020 row's Status column.

---

## Task 1: Promote `_acquire_storage_bearer_token` to public + add `_build_fabric_secret_sql`

**Why:** The bearer-token acquisition is reused by the new helper. Rather than deepening private-symbol coupling, rename it and add a pure SQL builder we can test in isolation.

**Files:**
- Modify: `src/das_cli/dlt_glue/azure_credentials.py`
- Modify: `tests/unit/test_azure_credentials.py`

- [ ] **Step 1: Write the failing unit test for `_build_fabric_secret_sql`**

Append to `tests/unit/test_azure_credentials.py`:

```python
def test_build_fabric_secret_sql_strips_container_from_scope() -> None:
    """The SCOPE in the emitted SQL strips the `<container>@` prefix.

    DuckDB matches secrets by longest-SCOPE-prefix against the URL it's about
    to fetch. dlt itself strips `@` (see duckdb/sql_client.py:303) — match that
    convention so multiple secrets at different paths under the same lakehouse
    coexist cleanly.
    """
    from das_cli.dlt_glue.azure_credentials import _build_fabric_secret_sql

    sql = _build_fabric_secret_sql(
        bucket_url="abfss://ws@onelake.dfs.fabric.microsoft.com/lh/Tables",
        token="fake-jwt-token",
    )
    assert "TYPE AZURE" in sql
    assert "PROVIDER ACCESS_TOKEN" in sql
    assert "ACCESS_TOKEN 'fake-jwt-token'" in sql
    assert "ACCOUNT_NAME 'onelake'" in sql
    # Scope: ws@ stripped; trailing slash preserved or absent — assert presence
    # of host + path, absence of container.
    assert "SCOPE 'abfss://onelake.dfs.fabric.microsoft.com/lh/Tables'" in sql
    assert "ws@" not in sql


def test_build_fabric_secret_sql_secret_name_sanitization() -> None:
    """Secret name follows dlt's convention: `.lower()` + strip non-letters
    (see dlt/destinations/impl/duckdb/sql_client.py:240), prefixed with
    `das_fabric_` to avoid collision with dlt's own `<dataset>_*` secret.
    """
    from das_cli.dlt_glue.azure_credentials import _build_fabric_secret_sql

    sql = _build_fabric_secret_sql(
        bucket_url="abfss://ws@onelake.dfs.fabric.microsoft.com/lh/Tables/x",
        token="t",
    )
    # Expected sanitization: scope.lower() → strip [^a-zA-Z] → letters only.
    assert "CREATE OR REPLACE SECRET das_fabric_abfssonelakedfsfabricmicrosoftcomlhtablesx" in sql


def test_build_fabric_secret_sql_escapes_token_safely() -> None:
    """Token is inserted via a single-quoted SQL literal. A `'` in the token
    would break the SQL; reject it rather than producing invalid SQL.
    """
    from das_cli.dlt_glue.azure_credentials import _build_fabric_secret_sql

    with pytest.raises(ValueError, match="single quote"):
        _build_fabric_secret_sql(
            bucket_url="abfss://ws@onelake.dfs.fabric.microsoft.com/lh",
            token="bad'token",
        )


def test_acquire_storage_bearer_token_is_public(monkeypatch: pytest.MonkeyPatch) -> None:
    """The public name is used by the new sql_client helper; pin it."""
    from das_cli.dlt_glue import azure_credentials as ac_mod

    assert hasattr(ac_mod, "acquire_storage_bearer_token")
    assert callable(ac_mod.acquire_storage_bearer_token)
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
uv run pytest tests/unit/test_azure_credentials.py::test_build_fabric_secret_sql_strips_container_from_scope \
              tests/unit/test_azure_credentials.py::test_build_fabric_secret_sql_secret_name_sanitization \
              tests/unit/test_azure_credentials.py::test_build_fabric_secret_sql_escapes_token_safely \
              tests/unit/test_azure_credentials.py::test_acquire_storage_bearer_token_is_public \
              -v
```

Expected: 4 failures with `ImportError: cannot import name '_build_fabric_secret_sql' / 'acquire_storage_bearer_token'`.

- [ ] **Step 3: Promote the token helper and add `_build_fabric_secret_sql`**

In `src/das_cli/dlt_glue/azure_credentials.py`, rename `_acquire_storage_bearer_token` to `acquire_storage_bearer_token` (drop the leading underscore everywhere it's used in this file — currently called from `build_deltalake_storage_options`).

Then add the SQL builder near the bottom of the module (before `_adlfs_storage_options`):

```python
import re


def _build_fabric_secret_sql(*, bucket_url: str, token: str) -> str:
    """Build the DuckDB CREATE OR REPLACE SECRET statement for OneLake.

    Issue #55: DuckDB's Azure auth is a third credential surface (separate from
    adlfs and Rust object_store). For Fabric URLs we issue this SQL inside
    `open_sql_client` to overwrite dlt's malformed CONNECTION_STRING secret
    with one that carries a real bearer token.

    Scope strips the `<container>@` prefix to mirror dlt's own scope-handling
    (see dlt/destinations/impl/duckdb/sql_client.py:303). DuckDB matches the
    longest SCOPE prefix when resolving credentials for a URL, so the stripped
    form correctly covers every `delta_scan` path under the lakehouse root.

    Secret name follows dlt's sanitization (lowercase + strip non-letters)
    prefixed with `das_fabric_` to avoid collision with dlt's `<dataset>_*`
    secret. Both can coexist; DuckDB picks the longest matching SCOPE.
    """
    if "'" in token:
        raise ValueError(
            "bearer token contains a single quote; cannot inject into SQL literal"
        )
    scope = bucket_url.split("@", 1)[-1] if "@" in bucket_url else bucket_url
    # Restore the URL scheme stripped by split("@")[1]: for "abfss://ws@host/path"
    # split("@",1)[-1] yields "host/path" — we need "abfss://host/path".
    if "://" in bucket_url and "://" not in scope:
        scheme = bucket_url.split("://", 1)[0]
        scope = f"{scheme}://{scope}"
    # Match dlt's sanitization convention exactly (sql_client.py:240): lower-case
    # then strip non-letters. Letting our convention drift would produce
    # unpredictable secret names.
    sanitized = re.sub(r"[^a-zA-Z]", "", scope.lower())
    secret_name = f"das_fabric_{sanitized}"
    return (
        f"CREATE OR REPLACE SECRET {secret_name} (\n"
        f"    TYPE AZURE,\n"
        f"    PROVIDER ACCESS_TOKEN,\n"
        f"    ACCESS_TOKEN '{token}',\n"
        f"    ACCOUNT_NAME 'onelake',\n"
        f"    SCOPE '{scope}'\n"
        f")"
    )
```

Update the existing call site in `build_deltalake_storage_options` (search for `_acquire_storage_bearer_token` and replace with `acquire_storage_bearer_token`).

- [ ] **Step 4: Run tests to verify they pass**

```bash
uv run pytest tests/unit/test_azure_credentials.py -v
```

Expected: all tests in the file pass — both the new 4 and the existing 30+.

- [ ] **Step 5: Type-check + lint**

```bash
uv run mypy src/das_cli/dlt_glue/azure_credentials.py
uv run ruff check src/das_cli/dlt_glue/azure_credentials.py tests/unit/test_azure_credentials.py
uv run ruff format src/das_cli/dlt_glue/azure_credentials.py tests/unit/test_azure_credentials.py
```

Expected: no errors.

- [ ] **Step 6: Commit**

```bash
git add src/das_cli/dlt_glue/azure_credentials.py tests/unit/test_azure_credentials.py
git commit -m "$(cat <<'EOF'
feat(azure): _build_fabric_secret_sql + promote token helper

Pure SQL builder for the OneLake DuckDB secret. Token helper promoted to
public for reuse by the upcoming open_sql_client wrapper. Part of issue #55.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 2: Add `_install_fabric_duckdb_secret` + `open_sql_client` context manager

**Why:** The context manager is the actual integration point — it wraps `pipeline.sql_client()`, runs the secret install for Fabric URLs, and yields the client unchanged.

**Files:**
- Modify: `src/das_cli/dlt_glue/azure_credentials.py`
- Modify: `tests/unit/test_azure_credentials.py`

- [ ] **Step 1: Write the failing unit tests**

Append to `tests/unit/test_azure_credentials.py`:

```python
def test_open_sql_client_installs_secret_for_onelake(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """OneLake bucket_url + azure creds → executes CREATE OR REPLACE SECRET."""
    from unittest.mock import MagicMock

    from das_cli.dlt_glue import azure_credentials as ac_mod
    from das_cli.dlt_glue.azure_credentials import open_sql_client

    # Mock token acquisition — no real Azure call.
    monkeypatch.setattr(
        ac_mod, "acquire_storage_bearer_token", lambda creds: "fake-jwt-token"
    )

    fake_client = MagicMock()
    fake_pipeline = MagicMock()
    fake_pipeline.sql_client.return_value.__enter__.return_value = fake_client
    fake_pipeline.sql_client.return_value.__exit__.return_value = False

    sp = AzureServicePrincipalAuth(
        auth="service_principal", tenant_id="t", client_id="c", client_secret="s"
    )

    with open_sql_client(
        fake_pipeline,
        bucket_url="abfss://ws@onelake.dfs.fabric.microsoft.com/lh/Tables",
        azure=sp,
    ) as c:
        assert c is fake_client

    # Exactly one execute_sql call, with the OneLake CREATE SECRET.
    assert fake_client.execute_sql.call_count == 1
    sql_arg = fake_client.execute_sql.call_args[0][0]
    assert "CREATE OR REPLACE SECRET das_fabric_" in sql_arg
    assert "ACCESS_TOKEN 'fake-jwt-token'" in sql_arg
    assert "ACCOUNT_NAME 'onelake'" in sql_arg


def test_open_sql_client_noop_for_adls_gen2(monkeypatch: pytest.MonkeyPatch) -> None:
    """Standard ADLS Gen2 → no CREATE SECRET issued (dlt's native secret works)."""
    from unittest.mock import MagicMock

    from das_cli.dlt_glue import azure_credentials as ac_mod
    from das_cli.dlt_glue.azure_credentials import open_sql_client

    # Token helper should NOT be called for non-Fabric URLs; trip-wire it.
    monkeypatch.setattr(
        ac_mod,
        "acquire_storage_bearer_token",
        lambda creds: pytest.fail("token should not be acquired for ADLS Gen2"),
    )

    fake_client = MagicMock()
    fake_pipeline = MagicMock()
    fake_pipeline.sql_client.return_value.__enter__.return_value = fake_client
    fake_pipeline.sql_client.return_value.__exit__.return_value = False

    sp = AzureServicePrincipalAuth(
        auth="service_principal", tenant_id="t", client_id="c", client_secret="s"
    )

    with open_sql_client(
        fake_pipeline,
        bucket_url="abfss://lake@acct.dfs.core.windows.net/warehouse",
        azure=sp,
    ) as c:
        assert c is fake_client

    assert fake_client.execute_sql.call_count == 0


def test_open_sql_client_noop_for_no_bucket_url() -> None:
    """bucket_url=None (duckdb / ducklake destination) → pass-through."""
    from unittest.mock import MagicMock

    from das_cli.dlt_glue.azure_credentials import open_sql_client

    fake_client = MagicMock()
    fake_pipeline = MagicMock()
    fake_pipeline.sql_client.return_value.__enter__.return_value = fake_client
    fake_pipeline.sql_client.return_value.__exit__.return_value = False

    with open_sql_client(fake_pipeline, bucket_url=None, azure=None) as c:
        assert c is fake_client

    assert fake_client.execute_sql.call_count == 0


def test_open_sql_client_noop_when_azure_is_none() -> None:
    """Local Delta (`./das_delta`) → pass-through."""
    from unittest.mock import MagicMock

    from das_cli.dlt_glue.azure_credentials import open_sql_client

    fake_client = MagicMock()
    fake_pipeline = MagicMock()
    fake_pipeline.sql_client.return_value.__enter__.return_value = fake_client
    fake_pipeline.sql_client.return_value.__exit__.return_value = False

    with open_sql_client(fake_pipeline, bucket_url="./das_delta", azure=None) as c:
        assert c is fake_client

    assert fake_client.execute_sql.call_count == 0
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
uv run pytest tests/unit/test_azure_credentials.py::test_open_sql_client_installs_secret_for_onelake \
              tests/unit/test_azure_credentials.py::test_open_sql_client_noop_for_adls_gen2 \
              tests/unit/test_azure_credentials.py::test_open_sql_client_noop_for_no_bucket_url \
              tests/unit/test_azure_credentials.py::test_open_sql_client_noop_when_azure_is_none \
              -v
```

Expected: 4 failures with `ImportError: cannot import name 'open_sql_client'`.

- [ ] **Step 3: Add `_install_fabric_duckdb_secret` + `open_sql_client`**

In `src/das_cli/dlt_glue/azure_credentials.py`, add new imports at top:

```python
import contextlib
from collections.abc import Iterator
```

If `TYPE_CHECKING` is not yet imported, add it too — used for the `dlt.Pipeline` type:

```python
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import dlt
```

(If a similar TYPE_CHECKING block is already present elsewhere in the file, add `import dlt` inside it; otherwise add the block.)

Add the helpers after `_build_fabric_secret_sql`:

```python
def _install_fabric_duckdb_secret(
    client: Any,
    *,
    bucket_url: str,
    azure: AzureServicePrincipalAuth | AzureDefaultAuth,
) -> None:
    """Issue CREATE OR REPLACE SECRET against the DuckDB connection dlt opened.

    Overwrites dlt's malformed CONNECTION_STRING secret (which dlt emits because
    das-cli passes AzureCredentialsWithoutDefaults with a placeholder SAS to
    satisfy dlt's config-resolver — see ADR-0020). The new secret carries a
    real bearer token and routes via ACCOUNT_NAME='onelake'.
    """
    token = acquire_storage_bearer_token(azure)
    sql = _build_fabric_secret_sql(bucket_url=bucket_url, token=token)
    client.execute_sql(sql)


@contextlib.contextmanager
def open_sql_client(
    pipeline: "dlt.Pipeline",
    *,
    bucket_url: str | None,
    azure: AzureServicePrincipalAuth | AzureDefaultAuth | None,
) -> Iterator[Any]:
    """`pipeline.sql_client()` with Fabric-aware DuckDB auth. See issue #55.

    For Fabric URLs (and only for Fabric URLs), issues CREATE OR REPLACE
    SECRET TYPE AZURE PROVIDER ACCESS_TOKEN inside the opened sql_client
    context, before yielding. For non-Fabric URLs, non-Azure URLs, and
    destinations that don't pass a bucket_url (duckdb/ducklake), this is a
    pass-through wrapper around `pipeline.sql_client()`.

    Token TTL is ~1h (same shape as the deltalake_storage_options bearer_token
    constraint already documented in ADR-0020 Consequences). Long-running
    pipelines that hold a sql_client across that boundary are out of scope.
    """
    with pipeline.sql_client() as client:
        if bucket_url and azure and is_fabric_url(bucket_url):
            _install_fabric_duckdb_secret(client, bucket_url=bucket_url, azure=azure)
        yield client
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
uv run pytest tests/unit/test_azure_credentials.py -v
```

Expected: all tests pass.

- [ ] **Step 5: Type-check + lint**

```bash
uv run mypy src/das_cli/dlt_glue/azure_credentials.py
uv run ruff check src/das_cli/dlt_glue/azure_credentials.py tests/unit/test_azure_credentials.py
uv run ruff format src/das_cli/dlt_glue/azure_credentials.py tests/unit/test_azure_credentials.py
```

Expected: clean.

- [ ] **Step 6: Commit**

```bash
git add src/das_cli/dlt_glue/azure_credentials.py tests/unit/test_azure_credentials.py
git commit -m "$(cat <<'EOF'
feat(azure): open_sql_client wraps pipeline.sql_client for OneLake auth

For Fabric URLs only, issues CREATE OR REPLACE SECRET TYPE AZURE PROVIDER
ACCESS_TOKEN against the DuckDB connection dlt opens, overwriting dlt's
malformed CONNECTION_STRING secret. Non-Fabric paths pass through unchanged.
Part of issue #55.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 3: Route `change_detection.load_latest_hash` through `open_sql_client`

**Why:** This is the production-relevant call site — second-cycle `das ingest` against OneLake fails today inside this function.

**Files:**
- Modify: `src/das_cli/pipelines/change_detection.py`
- Create or modify: `tests/unit/test_change_detection_load_latest_hash.py`

- [ ] **Step 1: Write the failing unit test**

Create `tests/unit/test_change_detection_load_latest_hash.py`:

```python
"""Unit tests for load_latest_hash — verifies open_sql_client is used so the
Fabric-aware DuckDB auth runs before the SELECT.
"""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock

import pytest

from das_cli.models.das_yaml import AzureServicePrincipalAuth
from das_cli.pipelines.change_detection import load_latest_hash


def test_load_latest_hash_passes_bucket_url_and_azure_to_open_sql_client(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When bucket_url + azure are provided, load_latest_hash routes through
    open_sql_client so the Fabric secret install runs before the SELECT.
    """
    captured: dict[str, Any] = {}

    fake_client = MagicMock()
    fake_client.execute_sql.return_value = []

    import contextlib

    @contextlib.contextmanager
    def fake_open_sql_client(pipeline, *, bucket_url, azure):  # type: ignore[no-untyped-def]
        captured["pipeline"] = pipeline
        captured["bucket_url"] = bucket_url
        captured["azure"] = azure
        yield fake_client

    monkeypatch.setattr(
        "das_cli.pipelines.change_detection.open_sql_client", fake_open_sql_client
    )

    sp = AzureServicePrincipalAuth(
        auth="service_principal", tenant_id="t", client_id="c", client_secret="s"
    )
    fake_pipeline = MagicMock()
    out = load_latest_hash(
        pipeline=fake_pipeline,
        dataset="das__src",
        table="products",
        primary_key=["id"],
        bucket_url="abfss://ws@onelake.dfs.fabric.microsoft.com/lh/Tables",
        azure=sp,
    )

    assert out == {}
    assert captured["pipeline"] is fake_pipeline
    assert captured["bucket_url"] == "abfss://ws@onelake.dfs.fabric.microsoft.com/lh/Tables"
    assert captured["azure"] is sp


def test_load_latest_hash_works_without_bucket_url_and_azure(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Default call signature (no Azure kwargs) still works for duckdb / ducklake."""
    fake_client = MagicMock()
    fake_client.execute_sql.return_value = [("a", "hashA"), ("b", "hashB")]

    import contextlib

    @contextlib.contextmanager
    def fake_open_sql_client(pipeline, *, bucket_url, azure):  # type: ignore[no-untyped-def]
        assert bucket_url is None
        assert azure is None
        yield fake_client

    monkeypatch.setattr(
        "das_cli.pipelines.change_detection.open_sql_client", fake_open_sql_client
    )

    out = load_latest_hash(
        pipeline=MagicMock(),
        dataset="das__src",
        table="customers",
        primary_key=["id"],
    )
    assert out == {("a",): "hashA", ("b",): "hashB"}


def test_load_latest_hash_returns_empty_on_undefined_relation(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """First load (table doesn't exist yet) → empty dict, no Azure surprises."""
    from dlt.destinations.exceptions import DatabaseUndefinedRelation

    fake_client = MagicMock()
    fake_client.execute_sql.side_effect = DatabaseUndefinedRelation("nope")

    import contextlib

    @contextlib.contextmanager
    def fake_open_sql_client(pipeline, *, bucket_url, azure):  # type: ignore[no-untyped-def]
        yield fake_client

    monkeypatch.setattr(
        "das_cli.pipelines.change_detection.open_sql_client", fake_open_sql_client
    )

    out = load_latest_hash(
        pipeline=MagicMock(),
        dataset="das__src",
        table="products",
        primary_key=["id"],
    )
    assert out == {}
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
uv run pytest tests/unit/test_change_detection_load_latest_hash.py -v
```

Expected: 3 failures — `load_latest_hash` doesn't yet accept `bucket_url`/`azure`, and doesn't yet import `open_sql_client`.

- [ ] **Step 3: Update `load_latest_hash` to use `open_sql_client`**

Replace the body of `src/das_cli/pipelines/change_detection.py` with:

```python
"""Per-PK change-detection filter. See ADR-0004 (filter), ADR-0016 (read path)."""

from __future__ import annotations

from collections.abc import Iterable, Iterator
from typing import TYPE_CHECKING, Any

from das_cli.dlt_glue.azure_credentials import open_sql_client

if TYPE_CHECKING:
    import dlt

    from das_cli.models.das_yaml import AzureDefaultAuth, AzureServicePrincipalAuth


class ChangeDetectionFilter:
    """Yield only rows whose `_row_hash` differs from the latest hash for their PK."""

    def __init__(
        self,
        *,
        primary_key: list[str],
        latest_hash: dict[tuple[Any, ...], str],
    ) -> None:
        self.primary_key = primary_key
        self.latest_hash: dict[tuple[Any, ...], str] = dict(latest_hash)

    def __call__(self, items: Iterable[dict[str, Any]]) -> Iterator[dict[str, Any]]:
        for row in items:
            pk = tuple(row[k] for k in self.primary_key)
            new_hash = row["_row_hash"]
            if self.latest_hash.get(pk) != new_hash:
                self.latest_hash[pk] = new_hash
                yield row


def load_latest_hash(
    *,
    pipeline: dlt.Pipeline,
    dataset: str,
    table: str,
    primary_key: list[str],
    bucket_url: str | None = None,
    azure: AzureServicePrincipalAuth | AzureDefaultAuth | None = None,
) -> dict[tuple[Any, ...], str]:
    """Latest `_row_hash` per primary key, queried via the destination's SQL client.

    Returns an empty dict if the dataset/table doesn't exist yet (first load).
    Destination-agnostic — works for any dlt destination that exposes
    `pipeline.sql_client()`. See ADR-0016.

    For OneLake-backed Delta destinations, `bucket_url` + `azure` must be
    supplied so the DuckDB Azure secret can be installed before the SELECT
    runs (issue #55). Other destinations leave both as None; the underlying
    helper is a pass-through in that case.
    """
    from dlt.destinations.exceptions import DatabaseUndefinedRelation

    pk_cols = ", ".join(f'"{c}"' for c in primary_key)
    sql = f"""
    SELECT {pk_cols}, _row_hash
    FROM "{dataset}"."{table}"
    QUALIFY ROW_NUMBER() OVER (PARTITION BY {pk_cols} ORDER BY _dlt_load_id DESC) = 1
    """
    try:
        with open_sql_client(pipeline, bucket_url=bucket_url, azure=azure) as client:
            rows = client.execute_sql(sql) or []
    except DatabaseUndefinedRelation:
        return {}
    out: dict[tuple[Any, ...], str] = {}
    for row in rows:
        pk = tuple(row[: len(primary_key)])
        out[pk] = row[-1]
    return out
```

- [ ] **Step 4: Run the new + existing change-detection tests**

```bash
uv run pytest tests/unit/test_change_detection_load_latest_hash.py tests/unit/test_change_detection_filter.py -v
```

Expected: all pass.

- [ ] **Step 5: Type-check + lint**

```bash
uv run mypy src/das_cli/pipelines/change_detection.py
uv run ruff check src/das_cli/pipelines/change_detection.py tests/unit/test_change_detection_load_latest_hash.py
uv run ruff format src/das_cli/pipelines/change_detection.py tests/unit/test_change_detection_load_latest_hash.py
```

Expected: clean.

- [ ] **Step 6: Commit**

```bash
git add src/das_cli/pipelines/change_detection.py tests/unit/test_change_detection_load_latest_hash.py
git commit -m "$(cat <<'EOF'
fix(change-detection): route load_latest_hash through open_sql_client

Adds optional bucket_url + azure kwargs to load_latest_hash so the OneLake
DuckDB secret is installed before the SELECT runs on second-cycle loads.
Backwards-compatible: non-Azure callers pass nothing, helper is a pass-through.
Part of issue #55.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 4: Thread `bucket_url` + `azure` through `pipelines/load.py`

**Why:** `change_detection.load_latest_hash` now needs both; the values are derived inside `_build_destination` and must reach `_build_load_resource` (which calls `load_latest_hash`).

**Files:**
- Modify: `src/das_cli/pipelines/load.py`

- [ ] **Step 1: Refactor `_build_destination` to also return the parsed Azure context**

In `src/das_cli/pipelines/load.py`, change the helper to return a tuple `(destination, bucket_url, azure)` for the delta branch — `(destination, None, None)` for other destinations.

Replace `_build_destination`:

```python
def _build_destination(
    target: TargetConfig,
) -> tuple[Any, str | None, "AzureServicePrincipalAuth | AzureDefaultAuth | None"]:
    """Construct a dlt destination from cfg.target. See ADR-0016.

    Returns (destination, bucket_url_or_None, parsed_azure_or_None). The
    bucket_url + azure pair is captured here once and threaded into
    `change_detection.load_latest_hash` so the OneLake DuckDB secret install
    can run before second-cycle reads (issue #55). For non-delta destinations
    both are None.

    Adding a new destination is one branch here plus a `dlt[<extra>]` entry in
    pyproject.toml. enable_dataset_name_normalization=False is unconditional —
    it preserves the `das__<source>` dataset prefix literally instead of letting
    each destination's normalizer rewrite it.
    """
    name = target.destination
    creds = dict(target.credentials)
    if name == "duckdb":
        return (
            dlt.destinations.duckdb(
                credentials=creds.get("database", "./das.duckdb"),
                enable_dataset_name_normalization=False,
            ),
            None,
            None,
        )
    if name == "ducklake":
        catalog = creds.get("catalog")
        if isinstance(catalog, str) and "://" not in catalog:
            creds = {**creds, "catalog": f"duckdb:///{catalog}"}
        # dlt's ducklake factory accepts a dict at runtime and converts to
        # DuckLakeCredentials via dlt's spec machinery; the static type only
        # advertises DuckLakeCredentials | None.
        return (
            dlt.destinations.ducklake(
                credentials=creds,  # type: ignore[arg-type]
                enable_dataset_name_normalization=False,
            ),
            None,
            None,
        )
    if name == "delta":
        # See ADR-0017: delta is an alias for filesystem; table_format is per-resource.
        # See ADR-0020: typed Azure credentials when bucket_url is abfs[s]:// / az://.
        bucket_url = creds.get("bucket_url", "./das_delta")
        azure = parse_azure_credentials(creds, bucket_url)
        dlt_creds = build_dlt_azure_credentials(azure, bucket_url=bucket_url) if azure else None
        # OneLake / Fabric-specific config: deltalake_storage_options for the
        # Rust writer, and adlfs `credential` object via kwargs (adlfs uses
        # the Blob API for list ops; needs a credential object, not a SAS).
        deltalake_opts = build_deltalake_storage_options(bucket_url, azure)
        adlfs_kwargs = build_adlfs_kwargs(azure, bucket_url)
        factory_kwargs: dict[str, Any] = {
            "bucket_url": bucket_url,
            "credentials": dlt_creds,
            "enable_dataset_name_normalization": False,
        }
        if deltalake_opts is not None:
            factory_kwargs["deltalake_storage_options"] = deltalake_opts
        if adlfs_kwargs:
            factory_kwargs["kwargs"] = adlfs_kwargs
        return (dlt.destinations.filesystem(**factory_kwargs), bucket_url, azure)
    raise ValueError(
        f"Unsupported target.destination: {name!r}. "
        f"Verified destinations: duckdb, ducklake, delta."
    )
```

Add the forward-ref import near the top of the file, beside the existing das_cli imports:

```python
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from das_cli.models.das_yaml import AzureDefaultAuth, AzureServicePrincipalAuth
```

(If a `TYPE_CHECKING` block already exists, add the import inside it.)

- [ ] **Step 2: Thread the new values into `_build_load_resource` and `run_load`**

Update `_build_load_resource` signature — add two new optional kwargs after `full`:

```python
def _build_load_resource(
    contract: LoadedContract,
    *,
    landing: LandingConfig,
    source: str,
    resource: str,
    hash_exclude: set[str],
    primary_key: list[str],
    pipeline: dlt.Pipeline,
    dataset: str,
    schema_contract: dict[str, str],
    table_format: str | None = None,
    progress_handle: ProgressHandle | None = None,
    full: bool = False,
    bucket_url: str | None = None,
    azure: "AzureServicePrincipalAuth | AzureDefaultAuth | None" = None,
) -> Any:
```

Inside `_build_load_resource`, find the existing `load_latest_hash(...)` call and add the two new kwargs:

```python
latest = load_latest_hash(
    pipeline=pipeline,
    dataset=dataset,
    table=table_name,
    primary_key=primary_key,
    bucket_url=bucket_url,
    azure=azure,
)
```

Update `run_load` to capture the new tuple and pass it down:

```python
destination, bucket_url, azure = _build_destination(cfg.target)
pipeline = dlt.pipeline(  # type: ignore[call-overload]
    pipeline_name="das_load",
    destination=destination,
    pipelines_dir=".dlt/pipelines",
    progress=dlt_progress,
)
```

And forward into `_build_load_resource`:

```python
res = _build_load_resource(
    c,
    landing=cfg.landing,
    source=src.name,
    resource=c.resource_name,
    hash_exclude=hash_exclude,
    primary_key=primary_keys_for(c.contract),
    pipeline=pipeline,
    dataset=dataset,
    schema_contract=schema_contract,
    table_format=table_format,
    progress_handle=progress_handle,
    full=full,
    bucket_url=bucket_url,
    azure=azure,
)
```

- [ ] **Step 3: Run the load-pipeline integration tests**

```bash
uv run pytest tests/integration/test_load_pipeline_delta.py tests/integration/test_load_pipeline_ducklake.py -v
```

Expected: all pass. The change is additive — duckdb/ducklake destinations and local Delta paths get `bucket_url=None` / `azure=None`, which `open_sql_client` treats as pass-through.

- [ ] **Step 4: Run the broader unit + integration suite to spot regressions**

```bash
uv run pytest tests/unit tests/integration -v
```

Expected: all green. If a test fails because it called `_build_destination` directly and unpacked one value, update it to unpack three (`destination, _, _ = _build_destination(target)`). Sweep:

```bash
grep -rn "_build_destination" tests/
```

If any matches exist, fix the destructure.

- [ ] **Step 5: Type-check + lint**

```bash
uv run mypy src/das_cli/pipelines/load.py
uv run ruff check src/das_cli/pipelines/load.py
uv run ruff format src/das_cli/pipelines/load.py
```

Expected: clean.

- [ ] **Step 6: Commit**

```bash
git add src/das_cli/pipelines/load.py
git commit -m "$(cat <<'EOF'
fix(load): thread bucket_url + azure into change-detection sql_client

_build_destination now returns the parsed Azure context alongside the dlt
destination so load_latest_hash can install the OneLake DuckDB secret on
second-cycle reads. Non-delta destinations carry None/None — pass-through.
Part of issue #55.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 5: Switch the e2e Azure reader to `open_sql_client`

**Why:** The gated e2e is the only test that exercises a real OneLake `delta_scan` from outside Fabric runtime. Without this change it stays red.

**Files:**
- Modify: `tests/e2e/destinations/test_delta_azure.py`

- [ ] **Step 1: Update the reader to use `open_sql_client`**

In `tests/e2e/destinations/test_delta_azure.py`, replace the two `with reader.sql_client() as c:` blocks (around lines 217 and 239) with `open_sql_client(...)`.

Add to the top-of-file imports:

```python
from das_cli.dlt_glue.azure_credentials import open_sql_client
```

Then replace the first read-back block:

```python
        # Read back via the reader pipeline.
        reader = _azure_reader_pipeline(workspace, target_url, dataset)
        # Resolve azure creds the same way the reader pipeline does.
        from das_cli.config import load_das_config
        from das_cli.models.das_yaml import parse_azure_credentials

        cfg = load_das_config(workspace / "das.yaml")
        azure = parse_azure_credentials(cfg.target.credentials, target_url)

        with open_sql_client(reader, bucket_url=target_url, azure=azure) as c:
            rows = c.execute_sql(f'SELECT COUNT(*) FROM "{dataset}".products')
            assert rows is not None
            count = rows[0][0]
            assert 1 <= count <= 10, f"row count {count} outside (0, --limit=10]"

            named_rows = c.execute_sql(
                f'SELECT COUNT(*) FROM "{dataset}".products WHERE name IS NOT NULL'
            )
            assert named_rows is not None and named_rows[0][0] >= 1

            stamp_rows = c.execute_sql(
                f'SELECT COUNT(*) FROM "{dataset}".products '
                "WHERE _extracted_at IS NULL OR _extracted_on IS NULL "
                "OR _loaded_at IS NULL OR _loaded_on IS NULL"
            )
            assert stamp_rows is not None and stamp_rows[0][0] == 0
```

And the second-cycle block:

```python
        # Second-cycle: change detection should produce zero new rows.
        result = cli_runner.invoke(app, ["load", source, "--resource", "products"])
        assert result.exit_code == 0, result.stdout + result.stderr
        reader = _azure_reader_pipeline(workspace, target_url, dataset)
        with open_sql_client(reader, bucket_url=target_url, azure=azure) as c:
            rows = c.execute_sql(f'SELECT COUNT(*) FROM "{dataset}".products')
            assert (
                rows is not None and rows[0][0] == count
            ), "change detection should append zero rows"
```

- [ ] **Step 2: Run the non-Azure subset to confirm nothing else regressed**

```bash
uv run pytest tests/e2e/destinations/test_delta.py tests/e2e/destinations/test_ducklake.py -m e2e -v
```

Expected: all pass (the test_delta_azure.py file requires `DAS_E2E_AZURE_BUCKET_URL` and is auto-skipped otherwise — see `tests/e2e/conftest.py:require_azure_e2e`).

- [ ] **Step 3: Type-check + lint**

```bash
uv run mypy tests/e2e/destinations/test_delta_azure.py
uv run ruff check tests/e2e/destinations/test_delta_azure.py
uv run ruff format tests/e2e/destinations/test_delta_azure.py
```

Expected: clean.

- [ ] **Step 4: Commit**

```bash
git add tests/e2e/destinations/test_delta_azure.py
git commit -m "$(cat <<'EOF'
test(e2e): use open_sql_client for OneLake read-back assertions

Switch the Azure e2e reader to the Fabric-aware sql_client wrapper so the
read-back COUNT and second-cycle change-detection assertions hit a valid
DuckDB Azure secret. Part of issue #55.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 6: Author ADR-0021 and supersede ADR-0020

**Why:** ADRs in this project are immutable post-merge. ADR-0020 documented
the DuckDB read-back gap as a follow-up; that follow-up is landing now.
Authoring ADR-0021 with `Status: Supersedes ADR-0020`, flipping ADR-0020's
Status to `Superseded by ADR-0021`, and updating the README index is the
only correct way to record the change. (The Status field flip is the only
in-place edit ever allowed on a merged ADR.)

**Files:**
- Create: `docs/adrs/0021-onelake-duckdb-readback-via-access-token-secret.md`
- Modify (Status field only): `docs/adrs/0020-azure-landing-and-delta-via-fsspec-and-typed-credentials.md`
- Modify: `docs/adrs/README.md`

- [ ] **Step 1: Author ADR-0021**

Create `docs/adrs/0021-onelake-duckdb-readback-via-access-token-secret.md`
with the content below. The Decision section restates ADR-0020's operative
pieces verbatim (Decision A/B/C/D about Azure landing + Delta + typed
credentials) plus the new DuckDB read-back decision (Decision E), so the
ADR tree is internally complete without back-references.

```markdown
# 0021. OneLake DuckDB read-back via PROVIDER ACCESS_TOKEN secret

- **Status:** Supersedes ADR-0020
- **Date:** 2026-05-12
- **Deciders:** mattiasthalen

## Context

ADR-0020 verified write paths to OneLake (extract → JSONL, load → Delta)
from outside Fabric runtime using three workaround surfaces — adlfs's
`account_host` rewrite plus credential-object passthrough, and the Rust
`object_store`'s `use_fabric_endpoint` + bearer token via
`deltalake_storage_options`. The Consequences section explicitly tracked a
remaining gap as a follow-up:

> OneLake from outside Fabric runtime: write paths work, read-back via
> DuckDB-Delta extension does not. DuckDB's Azure auth is a separate
> credential surface from both adlfs and `object_store` — it requires
> either a `CREATE SECRET ... TYPE AZURE` statement or environment
> variables under DuckDB's naming convention. das-cli does not wire either
> today, so `pipeline.sql_client()` against OneLake-backed Delta fails
> with `401 Unauthorized` from DuckDB's underlying HTTP fetch.

That gap bites in production: `change_detection.load_latest_hash` reads
prior row hashes via `pipeline.sql_client()` on second-cycle loads (first
load short-circuits via `DatabaseUndefinedRelation`). Without DuckDB Azure
auth, every second `das ingest` on an OneLake destination would 401.

The mechanism: dlt's `FilesystemSqlClient.create_secret` auto-emits an
Azure secret on connection open. For OneLake URLs, das-cli passes
`AzureCredentialsWithoutDefaults` with a placeholder SAS to satisfy dlt's
config-resolver — the real auth flows through `kwargs=` and
`deltalake_storage_options`. dlt sees the placeholder shape and emits
`CONNECTION_STRING 'AccountName=onelake;AccountKey=<placeholder>'`, which
DuckDB accepts at CREATE time but fails on first `delta_scan`.

DuckDB's Azure extension supports `PROVIDER ACCESS_TOKEN` with a
freshly-acquired storage-audience bearer token plus
`ACCOUNT_NAME 'onelake'` — that combination routes to the Fabric blob
endpoint with a valid Bearer header.

ADR-0020 is superseded so this ADR records both the Azure landing + Delta
decisions and the DuckDB read-back decision in one place.

[i2055]: https://github.com/dlt-hub/dlt/issues/2055
[adlfs486]: https://github.com/fsspec/adlfs/issues/486

## Decision

**Decision A (restated from ADR-0020): das-cli accepts `az://`,
`abfs://`, `abfss://` URLs for both `landing.bucket_url` and the Delta
target's `target.credentials.bucket_url`.** OneLake is a URL convention on
`abfss://`, not a separate scheme. das-cli does not branch on
`onelake.dfs.fabric.microsoft.com` vs `<account>.dfs.core.windows.net` —
both flow through dlt and adlfs as opaque ABFS URLs. For OneLake, the
GUID URL form (`abfss://<workspace_guid>@onelake.dfs.fabric.microsoft.com/<item_guid>/…`)
is recommended; the name form is per Microsoft Learn but the dlt docs
hard-recommend GUIDs and the name form is not verified.

**Decision B (restated from ADR-0020): two explicit `auth` modes —
`service_principal` and `default`.** A discriminated `AzureCredentials`
Pydantic model lives in `models/das_yaml.py` and parses the `credentials`
dict when the corresponding `bucket_url` is Azure:

```yaml
credentials:
  auth: service_principal
  tenant_id: "{{ env_var('AZURE_TENANT_ID') }}"
  client_id: "{{ env_var('AZURE_CLIENT_ID') }}"
  client_secret: "{{ env_var('AZURE_CLIENT_SECRET') }}"
```

```yaml
credentials:
  auth: default
```

`default` invokes dlt's `AzureCredentials` (which wraps
`DefaultAzureCredential`), chaining env-var SP → managed identity → az
CLI → developer Azure tools. A separate `cli` mode would just be a slower
alias for the same code path; managed identity is one link in the same
chain.

Per ADR-0007, secrets only come in via `{{ env_var(...) }}`. Standard
Azure SDK env-var names (`AZURE_TENANT_ID`, `AZURE_CLIENT_ID`,
`AZURE_CLIENT_SECRET`, `AZURE_STORAGE_ACCOUNT_NAME`) are used throughout
the docs because they are the names both Python `azure-identity` and
Rust `object_store` read — one `.env` works for both sides.

**Decision C (restated from ADR-0020): landing reads go through fsspec.**
The helper `dlt_glue/landing_fs.py` returns a
`(fsspec.AbstractFileSystem, root_path)` pair for any
`landing.bucket_url`. `LocalFileSystem` for bare paths and `file://`;
`AzureBlobFileSystem` (adlfs) for `az://` / `abfs://` / `abfss://`.
`_iter_landing`, `count_landing_rows`, and `reset_extract_state` all flow
through this helper. Only `file://` and Azure are verified.

**Decision D (restated from ADR-0020): das-cli does not own
`storage_options` plumbing, but does set `azure_storage_account_name` on
the typed credentials object.** dlt's typed Azure credentials
(`AzureServicePrincipalCredentialsWithoutDefaults` and
`AzureCredentials`) produce the right `object_store` storage_options for
the Rust deltalake writer automatically. das-cli builds the credentials
object from das-cli's `AzureCredentials` model and passes it as
`credentials=` to `dlt.destinations.filesystem(...)`. The per-resource
`table_format="delta"` plumbing from ADR-0017 is unchanged.

For OneLake, `azure_storage_account_name` is derived from the URL host
(`onelake` for OneLake, `<account>` for ADLS Gen2 generic), and
`azure_account_host` is set to the **blob** equivalent of the DFS host
because adlfs uses the Blob API for `iterdir`/`glob`/`find`/`ls` and
OneLake's DFS endpoint rejects those (see [adlfs486]). For ADLS Gen2
generic, both fields take dlt's defaults.

**Decision E (new): DuckDB read-back authenticates via
`PROVIDER ACCESS_TOKEN`, installed inside an `open_sql_client` wrapper.**
A new context-manager helper
`das_cli.dlt_glue.azure_credentials.open_sql_client(pipeline, *,
bucket_url, azure)` wraps `pipeline.sql_client()`. For Fabric URLs (and
only for Fabric URLs), the helper executes
`CREATE OR REPLACE SECRET das_fabric_<sanitized_scope> ( TYPE AZURE,
PROVIDER ACCESS_TOKEN, ACCESS_TOKEN '<jwt>', ACCOUNT_NAME 'onelake',
SCOPE '<bucket_url_without_container>' )` against the DuckDB connection
dlt opens, *after* dlt has emitted its own (malformed-for-OneLake)
CONNECTION_STRING secret and *before* yielding the client to the caller.

The bearer token is acquired via `azure_credentials.acquire_storage_bearer_token`
against the `https://storage.azure.com/.default` audience — the same
acquisition used for `deltalake_storage_options.bearer_token`. Secret
name follows dlt's sanitization (lowercase + strip non-letters) prefixed
with `das_fabric_` so both secrets coexist; DuckDB matches the longest
SCOPE prefix and the explicit `das_fabric_*` wins for the Fabric URL.

Callers: `change_detection.load_latest_hash` accepts optional
`bucket_url=` and `azure=` kwargs, threaded down from
`pipelines/load.py:_build_destination` through `_build_load_resource`.
The Azure e2e reader pipeline in
`tests/e2e/destinations/test_delta_azure.py` opens its `sql_client()`
through the same helper.

Standard ADLS Gen2 takes the simpler path: dlt's auto-emitted
`PROVIDER SERVICE_PRINCIPAL` secret already works, so `open_sql_client`
is a pass-through wrapper.

## Alternatives considered

(Decisions A–D alternatives carried over from ADR-0020; only Decision E
alternatives are new.)

- **Add a discrete `cli` auth mode for `az login`.** Rejected — it's one
  link in the `DefaultAzureCredential` chain, exposed via `auth: default`.
- **Add `managed_identity` as a distinct mode.** Rejected for the same
  reason — `DefaultAzureCredential` already picks up the IMDS endpoint
  on Azure VMs / AKS / Functions.
- **Manage `storage_options` in das-cli, merge with dlt's.** Rejected —
  duplicates the work dlt already does in
  `to_object_store_rs_credentials()` and locks das-cli to dlt's internal
  shape.
- **Use the dlt `fabric` destination
  ([dlt PR #3535](https://github.com/dlt-hub/dlt/pull/3535))**.
  Rejected — that destination targets Fabric **Warehouse** (T-SQL +
  COPY INTO), a different surface from OneLake-as-files + Delta.
- **Add `s3://` and `gs://` in the same pass.** Rejected — different
  credential shapes, different `object_store` quirks. S3/GCS can land on
  their own verified slices later.
- **(Decision E) Use DuckDB environment variables (`AZURE_*` /
  `AZURE_STORAGE_CONNECTION_STRING`).** Rejected — DuckDB's variable-based
  Azure config has no ACCESS_TOKEN slot; bearer tokens don't fit. Leaks
  across pipelines/tests in the same process.
- **(Decision E) Open a separate `duckdb.connect()` bypassing dlt.**
  Rejected — doubles the read path for the OneLake case only and breaks
  destination-agnosticism in `change_detection.py` that ADR-0016
  deliberately preserved.
- **(Decision E) Overwrite dlt's existing secret in place (same name)
  rather than publishing a new `das_fabric_*` secret.** Equivalent end
  state but couples to dlt's internal secret-naming convention. Brittle
  if dlt changes that scheme.
- **(Decision E) Persist the secret (`PERSISTENT`).** Tokens are
  short-lived (~1h); persistence has no value.

## Consequences

- The `AzureCredentials` Pydantic model in `models/das_yaml.py` is opt-in:
  only parsed when the relevant `bucket_url` is Azure. Existing local-path
  workspaces are unaffected.
- das-cli relies on dlt's `to_object_store_rs_credentials()` to produce
  the right Azure storage_options for the Rust deltalake writer. A future
  dlt release that changes the merge semantics or the
  `azure_storage_token` field name would break das-cli; this is a
  stable-API-shaped surface and is documented here so future maintainers
  know where to look.
- The `delta` destination accepts Azure URLs but offers no extra
  configurability beyond `bucket_url` + `credentials`. Compaction,
  retention, and vacuum remain out of scope.
- AWS S3 and GCS are *not* verified by this ADR.
- `doctor` performs config-typo hygiene only for Azure. No live token
  fetch, no network call.
- Cross-pipeline reads on Azure-backed Delta carry the same constraint
  as local Delta (ADR-0017 Decision C): readers must share the writer's
  `pipeline_name` / `pipelines_dir`.
- **OneLake from outside Fabric runtime: verified end-to-end.** Three
  workaround surfaces, each addressing a separate credential domain:
  1. **adlfs (Python landing reads/writes):** DFS→Blob host rewrite plus
     credential object via dlt's `kwargs=` passthrough.
  2. **`object_store` (Rust deltalake writer):** `use_fabric_endpoint:
     "true"` + bearer token via `deltalake_storage_options`.
  3. **DuckDB (Delta extension read-back):** `open_sql_client` installs
     `CREATE OR REPLACE SECRET ... TYPE AZURE PROVIDER ACCESS_TOKEN
     ACCOUNT_NAME 'onelake'` against the DuckDB connection dlt opens.

  Verified end-to-end on OneLake from outside Fabric: extract → JSONL
  into `/Files/`, load → Delta into `/Tables/`, read-back via DuckDB, and
  second-cycle change-detection no-op (which exercises `sql_client()`
  inside `change_detection.load_latest_hash`).

  Token TTL (~1h) is the same shape across surfaces 2 and 3. Long-running
  pipelines that span that boundary would need token-refresh participation
  in dlt's per-request credential plumbing — out of scope today.

  Standard ADLS Gen2 endpoints (`<account>.dfs.core.windows.net`) take
  the simpler typed-credentials path on all three surfaces.
```

- [ ] **Step 2: Flip ADR-0020 Status to `Superseded by ADR-0021`**

Open `docs/adrs/0020-azure-landing-and-delta-via-fsspec-and-typed-credentials.md`
and change exactly one line. The current header reads:

```
- **Status:** Accepted
```

Replace with:

```
- **Status:** Superseded by ADR-0021
```

No other edits. Decision, Context, Alternatives, and Consequences sections
remain exactly as merged.

- [ ] **Step 3: Update `docs/adrs/README.md`**

Open `docs/adrs/README.md`. In the index table, change the ADR-0020 row's
Status column from `Accepted` to `Superseded by ADR-0021`, and add a new
row for ADR-0021 directly below it:

```
| 0020 | Azure landing and Delta destination via fsspec + typed dlt credentials | Superseded by ADR-0021 |
| 0021 | OneLake DuckDB read-back via PROVIDER ACCESS_TOKEN secret | Accepted |
```

- [ ] **Step 4: Verify the ADR index is consistent**

```bash
head -1 docs/adrs/0021-*.md
head -1 docs/adrs/0020-*.md
grep -E '0020|0021' docs/adrs/README.md
```

Expected:
- `# 0021. OneLake DuckDB read-back via PROVIDER ACCESS_TOKEN secret`
- `# 0020. Azure landing and Delta destination via fsspec + typed dlt credentials`
- two README rows matching the titles verbatim.

- [ ] **Step 5: Commit**

```bash
git add docs/adrs/0021-onelake-duckdb-readback-via-access-token-secret.md \
        docs/adrs/0020-azure-landing-and-delta-via-fsspec-and-typed-credentials.md \
        docs/adrs/README.md
git commit -m "$(cat <<'EOF'
docs(adrs): ADR-0021 supersedes ADR-0020 (OneLake DuckDB read-back, #55)

New ADR-0021 records both the Azure landing + Delta decisions (carried
over from ADR-0020) and the new DuckDB read-back decision (open_sql_client
installs PROVIDER ACCESS_TOKEN secret). ADR-0020 Status flipped to
Superseded by ADR-0021 — the only in-place edit allowed on a merged ADR.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 7: Final verification

**Why:** Sanity check before opening the PR. The gated e2e is the only definitive proof against real Fabric — the user runs it.

**Files:** none modified

- [ ] **Step 1: Full local test suite**

```bash
uv run pytest tests/unit tests/integration -v
```

Expected: all green.

- [ ] **Step 2: Full lint + type-check sweep**

```bash
uv run mypy src tests
uv run ruff check src tests
uv run ruff format --check src tests
```

Expected: clean.

- [ ] **Step 3: Gated e2e (manual — requires Fabric workspace)**

The opt-in e2e is the acceptance criterion from the spec. The user (or whoever has Fabric credentials configured) runs:

```bash
export DAS_E2E_AZURE_BUCKET_URL="abfss://<workspace_guid>@onelake.dfs.fabric.microsoft.com/<lakehouse_guid>"
export AZURE_TENANT_ID="..."
export AZURE_CLIENT_ID="..."
export AZURE_CLIENT_SECRET="..."
uv run pytest tests/e2e/destinations/test_delta_azure.py -m e2e -v
```

Expected: both parametrisations (`service_principal` and `default`) pass — extract, load, read-back COUNT, and second-cycle change-detection no-op all green.

- [ ] **Step 4: Open the PR**

```bash
gh pr create --title "fix(azure): OneLake sql_client() read-back via DuckDB ACCESS_TOKEN secret" --body "$(cat <<'EOF'
## Summary
- `open_sql_client` wraps `pipeline.sql_client()` and overwrites dlt's malformed Azure secret with `PROVIDER ACCESS_TOKEN` for Fabric URLs.
- `change_detection.load_latest_hash` now accepts `bucket_url=` / `azure=`; `pipelines/load.py` threads both from `_build_destination`.
- ADR-0020 Consequences updated to remove the read-back-fails caveat.

Closes #55.

## Test plan
- [ ] `uv run pytest tests/unit tests/integration` — green
- [ ] `uv run mypy src tests` + `uv run ruff check src tests` — clean
- [ ] `uv run pytest tests/e2e/destinations/test_delta_azure.py -m e2e -v` — green against real Fabric (both `service_principal` and `default` parametrisations)

🤖 Generated with [Claude Code](https://claude.com/claude-code)
EOF
)"
```

---

## Self-review notes

- **Spec coverage:** every Decision item from the spec (A helper module, B call-site plumbing, C tests, D ADR update) maps to a task. Acceptance criteria (e2e green, unit assertions, no regression in non-Azure destinations) map to Tasks 5 and 7.
- **Type consistency:** `bucket_url: str | None` and `azure: AzureServicePrincipalAuth | AzureDefaultAuth | None` propagate identically through `open_sql_client` → `load_latest_hash` → `_build_load_resource` → `_build_destination`.
- **No placeholders:** every code-bearing step includes the full code block.
- **DRY:** `_build_fabric_secret_sql` is the single source of truth for the SQL string; both `_install_fabric_duckdb_secret` and the unit tests consume it.
- **YAGNI:** no token refresh, no persistent secrets, no S3/GCS hooks, no doctor check. Matches the spec's "Out of scope" list.
- **TDD:** every code-bearing task has its tests written first.
- **Commit cadence:** seven commits across six tasks, each a coherent unit.
