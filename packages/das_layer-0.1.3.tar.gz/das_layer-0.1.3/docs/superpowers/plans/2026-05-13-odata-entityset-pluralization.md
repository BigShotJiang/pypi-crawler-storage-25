# OData EntitySet pluralization — implementation plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fix issue #61 — `das ingest` 404s on AdventureWorks because `synthesize_odata_endpoint()` builds the URL path with naive `+s` pluralization. Capture the authoritative `EntitySet` name from `$metadata` at bootstrap and use a case-preserving heuristic as a fallback.

**Architecture:** Three additive changes:
1. `bootstrap/odata.py` parses `<EntityContainer><EntitySet>` from `$metadata` and persists `entity_set: <Name>` on `das.spec_ref` per EntityType.
2. `synthesize_odata_endpoint()` in `contracts/das_endpoint.py` resolves the path in this order: explicit `das.endpoint` (already wins, unchanged) → `spec_ref.entity_set` (new) → `pluralize_preserving_case(spec_ref.type)` (new heuristic) → `resource_name`.
3. `bootstrap/naming.py` gains `pluralize_preserving_case()` — same `y → ies` rule as `pluralize()` plus the `+es` rule for consonant + s/x/z/ch/sh, with no `endswith("s")` pass-through (OData EntityTypes are conventionally singular).

A new ADR (0024) records the contract-surface addition. The existing `pluralize()` and the resource_name path are left alone to avoid schema-freeze churn (ADR-0012). Spec: `docs/superpowers/specs/2026-05-13-odata-entityset-pluralization-design.md`.

**Tech Stack:** Python 3.12, pydantic 2.x, stdlib `xml.etree.ElementTree`, pytest, uv, ruff, mypy, pre-commit.

---

## File map

- **Modify:** `src/das_cli/bootstrap/naming.py` — add `pluralize_preserving_case()`.
- **Modify:** `tests/unit/test_bootstrap_naming.py` — pin the new function's rules.
- **Modify:** `tests/fixtures/sample_odata_metadata.xml` — add an `<EntityContainer>` block declaring `Products` and `Departments`.
- **Create:** `tests/fixtures/sample_odata_metadata_irregular.xml` — minimal fixture with `Address` + `Currency` EntityTypes and an `<EntityContainer>` mapping them to `Addresses` + `Currencies`. Exercises the issue-#61 shape.
- **Modify:** `src/das_cli/bootstrap/odata.py` — walk `<EntityContainer><EntitySet>`, build a `type_name → entity_set_name` map, plumb it into `_build_contract` / `_build_custom_properties`.
- **Modify:** `tests/unit/test_bootstrap_odata.py` — update the existing `test_spec_ref_added` (its `==` assertion will no longer match after we add `entity_set`), add new tests for the EntityContainer behaviors.
- **Modify:** `src/das_cli/contracts/das_endpoint.py` — rewrite `synthesize_odata_endpoint()` for the 3-step resolution chain.
- **Modify:** `tests/unit/test_das_endpoint.py` — update one existing test (`test_synthesize_odata_uses_spec_ref_type` should still pass; new tests pin entity_set / heuristic / fallback).
- **Create:** `docs/adrs/0024-odata-entityset-on-spec-ref.md` — new ADR.
- **Modify:** `docs/adrs/README.md` — append the row for ADR-0024.
- **Modify:** `tests/e2e/sources/test_odata_adventureworks.py` — add a second test exercising an irregular plural (`addresses`) against the live AdventureWorks endpoint. Auto-marked `e2e`, opt-in via `-m e2e`.

No CI changes. No new dependencies.

---

### Task 1: Add `pluralize_preserving_case` to `bootstrap/naming.py` (TDD)

The new helper is the simplest unit in the plan and is consumed by Task 5 (synthesis). Write its tests first.

**Files:**
- Modify: `tests/unit/test_bootstrap_naming.py` (append at the end)
- Modify: `src/das_cli/bootstrap/naming.py`

- [ ] **Step 1: Write the failing tests**

Append to `tests/unit/test_bootstrap_naming.py`:

```python
# --- pluralize_preserving_case ---

from das_cli.bootstrap.naming import pluralize_preserving_case


def test_pluralize_preserving_case_plus_s() -> None:
    assert pluralize_preserving_case("Product") == "Products"
    assert pluralize_preserving_case("Order") == "Orders"
    assert pluralize_preserving_case("Customer") == "Customers"


def test_pluralize_preserving_case_plus_es_on_consonant_plus_s() -> None:
    # Singular EntityType names that end in -s require +es. OData conventionally
    # uses singular names, so we do NOT pass these through as already-plural.
    assert pluralize_preserving_case("Address") == "Addresses"
    assert pluralize_preserving_case("EmailAddress") == "EmailAddresses"
    assert pluralize_preserving_case("Status") == "Statuses"
    assert pluralize_preserving_case("Class") == "Classes"


def test_pluralize_preserving_case_plus_es_on_x_z_ch_sh() -> None:
    assert pluralize_preserving_case("Box") == "Boxes"
    assert pluralize_preserving_case("Quartz") == "Quartzes"
    assert pluralize_preserving_case("Match") == "Matches"
    assert pluralize_preserving_case("Dish") == "Dishes"


def test_pluralize_preserving_case_y_to_ies_after_consonant() -> None:
    assert pluralize_preserving_case("Currency") == "Currencies"
    assert pluralize_preserving_case("BusinessEntity") == "BusinessEntities"
    assert pluralize_preserving_case("SalesTerritory") == "SalesTerritories"
    assert pluralize_preserving_case("TransactionHistory") == "TransactionHistories"


def test_pluralize_preserving_case_y_after_vowel_keeps_y_plus_s() -> None:
    assert pluralize_preserving_case("Day") == "Days"
    assert pluralize_preserving_case("Key") == "Keys"
    assert pluralize_preserving_case("Boy") == "Boys"


def test_pluralize_preserving_case_empty() -> None:
    assert pluralize_preserving_case("") == ""
```

- [ ] **Step 2: Run the tests to verify they fail**

```bash
uv run pytest tests/unit/test_bootstrap_naming.py -v
```

Expected: the six new tests fail with `ImportError: cannot import name 'pluralize_preserving_case'`. Existing `snake_case` / `pluralize` tests still pass.

- [ ] **Step 3: Implement `pluralize_preserving_case`**

Append to `src/das_cli/bootstrap/naming.py`:

```python
def pluralize_preserving_case(name: str) -> str:
    """Pluralize an OData EntityType name to its conventional EntitySet form.

    Preserves the input's capitalization, unlike `pluralize()` which lowercases
    via `snake_case` first. Differs from `pluralize()` in two deliberate ways:

    1. No `endswith("s")` pass-through. OData EntityTypes are conventionally
       singular, so `Address` / `EmailAddress` / `Status` are inputs we *want*
       to pluralize to `Addresses` / `EmailAddresses` / `Statuses`, not pass
       through.
    2. Adds the `+es` rule for consonant + s/x/z/ch/sh.

    See ADR-0024: OData EntitySet name persisted on `das.spec_ref`.
    """
    if not name:
        return ""
    if name.endswith("y") and not name.endswith(("ay", "ey", "iy", "oy", "uy")):
        return name[:-1] + "ies"
    if name[-1].lower() in ("s", "x", "z") or name[-2:].lower() in ("ch", "sh"):
        return name + "es"
    return name + "s"
```

- [ ] **Step 4: Run the tests to verify they pass**

```bash
uv run pytest tests/unit/test_bootstrap_naming.py -v
```

Expected: all tests pass (both pre-existing `snake_case` / `pluralize` ones and the six new ones).

- [ ] **Step 5: Commit**

```bash
git add src/das_cli/bootstrap/naming.py tests/unit/test_bootstrap_naming.py
git commit -m "$(cat <<'EOF'
feat(bootstrap-naming): add pluralize_preserving_case for OData EntitySet guesses

Singular OData EntityType names (Address, EmailAddress, Status, Currency)
need a case-preserving pluralizer with the +es rule and y→ies — but
without the endswith("s") pass-through that pluralize() uses for snake_case
resource names. Adds the helper; consumed by synthesize_odata_endpoint() in
a follow-up commit. See spec docs/superpowers/specs/2026-05-13-odata-entityset-pluralization-design.md.
EOF
)"
```

---

### Task 2: Add `<EntityContainer>` to the existing OData fixture and update the affected unit test

The existing fixture `tests/fixtures/sample_odata_metadata.xml` has two EntityTypes (`Product`, `Department`) and no `<EntityContainer>`. We add an `EntityContainer` so the next bootstrap-side test in Task 3 has something to match against, **and** update the existing `test_spec_ref_added` assertion that uses `==` against the exact dict — adding `entity_set` to the value will break that assertion otherwise.

**Files:**
- Modify: `tests/fixtures/sample_odata_metadata.xml`
- Modify: `tests/unit/test_bootstrap_odata.py` (test `test_spec_ref_added`, around line 66-70)

- [ ] **Step 1: Add the `<EntityContainer>` block to the fixture**

Edit `tests/fixtures/sample_odata_metadata.xml`. Replace:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<edmx:Edmx xmlns:edmx="http://docs.oasis-open.org/odata/ns/edmx" Version="4.0">
  <edmx:DataServices>
    <Schema xmlns="http://docs.oasis-open.org/odata/ns/edm" Namespace="Test.Models">
      <EntityType Name="Product">
        <Key>
          <PropertyRef Name="ProductId" />
        </Key>
        <Property Name="ProductId" Type="Edm.Int32" Nullable="false" />
        <Property Name="Name" Type="Edm.String" Nullable="false" MaxLength="50" />
        <Property Name="ListPrice" Type="Edm.Decimal" Nullable="true" Precision="19" Scale="4" />
        <Property Name="ModifiedDate" Type="Edm.DateTimeOffset" Nullable="false" />
      </EntityType>
      <EntityType Name="Department">
        <Key><PropertyRef Name="DepartmentId" /></Key>
        <Property Name="DepartmentId" Type="Edm.Int16" Nullable="false" />
        <Property Name="Name" Type="Edm.String" Nullable="false" />
      </EntityType>
    </Schema>
  </edmx:DataServices>
</edmx:Edmx>
```

with:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<edmx:Edmx xmlns:edmx="http://docs.oasis-open.org/odata/ns/edmx" Version="4.0">
  <edmx:DataServices>
    <Schema xmlns="http://docs.oasis-open.org/odata/ns/edm" Namespace="Test.Models">
      <EntityType Name="Product">
        <Key>
          <PropertyRef Name="ProductId" />
        </Key>
        <Property Name="ProductId" Type="Edm.Int32" Nullable="false" />
        <Property Name="Name" Type="Edm.String" Nullable="false" MaxLength="50" />
        <Property Name="ListPrice" Type="Edm.Decimal" Nullable="true" Precision="19" Scale="4" />
        <Property Name="ModifiedDate" Type="Edm.DateTimeOffset" Nullable="false" />
      </EntityType>
      <EntityType Name="Department">
        <Key><PropertyRef Name="DepartmentId" /></Key>
        <Property Name="DepartmentId" Type="Edm.Int16" Nullable="false" />
        <Property Name="Name" Type="Edm.String" Nullable="false" />
      </EntityType>
      <EntityContainer Name="Default">
        <EntitySet Name="Products" EntityType="Test.Models.Product" />
        <EntitySet Name="Departments" EntityType="Test.Models.Department" />
      </EntityContainer>
    </Schema>
  </edmx:DataServices>
</edmx:Edmx>
```

- [ ] **Step 2: Update `test_spec_ref_added` to expect the new shape**

In `tests/unit/test_bootstrap_odata.py`, find:

```python
def test_spec_ref_added(sample_xml: str) -> None:
    contracts = bootstrap_odata_contracts(sample_xml, source_name="adventureworks")
    products = next(c for c in contracts if c.resource_name == "products")
    spec = next(p for p in products.contract.custom_properties if p.property == "das.spec_ref")
    assert spec.value == {"kind": "odata", "type": "Product"}
```

Replace the last line with:

```python
    assert spec.value == {"kind": "odata", "type": "Product", "entity_set": "Products"}
```

- [ ] **Step 3: Run the full bootstrap-odata test file to confirm only that assertion changes**

```bash
uv run pytest tests/unit/test_bootstrap_odata.py -v
```

Expected before Task 3 lands: `test_spec_ref_added` **fails** because the parser doesn't yet emit `entity_set` — that's intentional, we'll make it pass in Task 3. All other tests in the file pass (Task 2's fixture additions are additive — they don't change the `Product` / `Department` EntityType properties, cursor inference, resource_name, or count of contracts).

- [ ] **Step 4: Commit (still red on the one test — fixed in Task 3)**

```bash
git add tests/fixtures/sample_odata_metadata.xml tests/unit/test_bootstrap_odata.py
git commit -m "$(cat <<'EOF'
test(bootstrap-odata): add EntityContainer to sample fixture; expect entity_set in spec_ref

Adds <EntityContainer> with EntitySets to the existing OData fixture so the
parser can be exercised against both shapes (EntityType + container). Updates
test_spec_ref_added's `==` assertion to expect the new entity_set key. The
test is currently red — Task 3 lands the parser change that makes it green.
EOF
)"
```

---

### Task 3: Parse `<EntityContainer><EntitySet>` and plumb `entity_set` into `das.spec_ref`

This is the bootstrap-side change that makes Task 2's red test pass and persists the authoritative name.

**Files:**
- Modify: `src/das_cli/bootstrap/odata.py`
- Modify: `tests/unit/test_bootstrap_odata.py` (append new tests)

- [ ] **Step 1: Modify `bootstrap_odata_contracts` to build a type→EntitySet map and pass it to `_build_contract`**

In `src/das_cli/bootstrap/odata.py`, replace:

```python
def _build_contract(entity: ElementTree.Element, source_name: str) -> LoadedContract:
    type_name = entity.get("Name", "")
    key_names: set[str] = set()
    key_elem = entity.find("edm:Key", _NS)
    if key_elem is not None:
        for ref in key_elem.findall("edm:PropertyRef", _NS):
            n = ref.get("Name")
            if n:
                key_names.add(n)

    properties = [
        _build_property(p, key_names=key_names) for p in entity.findall("edm:Property", _NS)
    ]

    resource_name = pluralize(type_name)
    contract = OdcsContract(
        apiVersion="v3.0.0",
        kind="DataContract",
        id=f"{source_name}.{resource_name}",
        name=type_name,
        version="0.1.0",
        status="draft",
        info=OdcsInfo(title=type_name, owner="data-platform"),
        schema=[
            OdcsSchema(
                name=resource_name,
                physicalName=resource_name,
                physicalType="table",
                properties=properties,
            )
        ],
        customProperties=_build_custom_properties(type_name, properties),
    )

    return LoadedContract(
        path=Path(f"{resource_name}.odcs.yaml"),
        resource_name=resource_name,
        contract=contract,
    )


def _build_custom_properties(
    type_name: str, properties: list[OdcsProperty]
) -> list[CustomProperty]:
    cps: list[CustomProperty] = [
        CustomProperty(property="das.spec_ref", value={"kind": "odata", "type": type_name}),
    ]
    cursor = _pick_cursor(properties)
    if cursor:
        cps.append(CustomProperty(property="das.cursor", value=cursor))
    return cps


def bootstrap_odata_contracts(metadata_xml: str, *, source_name: str) -> list[LoadedContract]:
    """Parse $metadata XML and return one LoadedContract per EntityType."""
    root = ElementTree.fromstring(metadata_xml)
    out: list[LoadedContract] = []
    for entity in root.iter(f"{{{_NS['edm']}}}EntityType"):
        out.append(_build_contract(entity, source_name=source_name))
    return out
```

with:

```python
def _build_contract(
    entity: ElementTree.Element,
    source_name: str,
    *,
    entity_set_by_type: dict[str, str],
) -> LoadedContract:
    type_name = entity.get("Name", "")
    key_names: set[str] = set()
    key_elem = entity.find("edm:Key", _NS)
    if key_elem is not None:
        for ref in key_elem.findall("edm:PropertyRef", _NS):
            n = ref.get("Name")
            if n:
                key_names.add(n)

    properties = [
        _build_property(p, key_names=key_names) for p in entity.findall("edm:Property", _NS)
    ]

    resource_name = pluralize(type_name)
    contract = OdcsContract(
        apiVersion="v3.0.0",
        kind="DataContract",
        id=f"{source_name}.{resource_name}",
        name=type_name,
        version="0.1.0",
        status="draft",
        info=OdcsInfo(title=type_name, owner="data-platform"),
        schema=[
            OdcsSchema(
                name=resource_name,
                physicalName=resource_name,
                physicalType="table",
                properties=properties,
            )
        ],
        customProperties=_build_custom_properties(
            type_name, properties, entity_set=entity_set_by_type.get(type_name)
        ),
    )

    return LoadedContract(
        path=Path(f"{resource_name}.odcs.yaml"),
        resource_name=resource_name,
        contract=contract,
    )


def _build_custom_properties(
    type_name: str, properties: list[OdcsProperty], *, entity_set: str | None
) -> list[CustomProperty]:
    # See ADR-0024: persist the authoritative EntitySet name on das.spec_ref when
    # $metadata declares one. synthesize_odata_endpoint() prefers this over its
    # case-preserving pluralization heuristic.
    spec_ref_value: dict[str, str] = {"kind": "odata", "type": type_name}
    if entity_set:
        spec_ref_value["entity_set"] = entity_set
    cps: list[CustomProperty] = [
        CustomProperty(property="das.spec_ref", value=spec_ref_value),
    ]
    cursor = _pick_cursor(properties)
    if cursor:
        cps.append(CustomProperty(property="das.cursor", value=cursor))
    return cps


def _build_entity_set_map(root: ElementTree.Element) -> dict[str, str]:
    """Map bare EntityType name → declared EntitySet `Name` from `<EntityContainer>`.

    Strips the namespace prefix from the EntitySet's `EntityType` attribute
    (`AdventureWorks.Address` → `Address`). Returns an empty dict if `$metadata`
    has no EntityContainer.
    """
    out: dict[str, str] = {}
    for container in root.iter(f"{{{_NS['edm']}}}EntityContainer"):
        for entity_set in container.findall("edm:EntitySet", _NS):
            set_name = entity_set.get("Name")
            qualified_type = entity_set.get("EntityType", "")
            if not set_name or not qualified_type:
                continue
            bare_type = qualified_type.rsplit(".", 1)[-1]
            out[bare_type] = set_name
    return out


def bootstrap_odata_contracts(metadata_xml: str, *, source_name: str) -> list[LoadedContract]:
    """Parse $metadata XML and return one LoadedContract per EntityType."""
    root = ElementTree.fromstring(metadata_xml)
    entity_set_by_type = _build_entity_set_map(root)
    out: list[LoadedContract] = []
    for entity in root.iter(f"{{{_NS['edm']}}}EntityType"):
        out.append(
            _build_contract(entity, source_name=source_name, entity_set_by_type=entity_set_by_type)
        )
    return out
```

- [ ] **Step 2: Run Task 2's updated test to verify it now passes**

```bash
uv run pytest tests/unit/test_bootstrap_odata.py::test_spec_ref_added -v
```

Expected: PASS.

- [ ] **Step 3: Add new bootstrap-odata tests for the container behaviors**

Append to `tests/unit/test_bootstrap_odata.py`:

```python
def test_entity_set_added_when_container_present(sample_xml: str) -> None:
    """The fixture's EntityContainer declares Products and Departments — both
    should land on das.spec_ref.entity_set."""
    contracts = bootstrap_odata_contracts(sample_xml, source_name="adventureworks")
    products = next(c for c in contracts if c.resource_name == "products")
    departments = next(c for c in contracts if c.resource_name == "departments")

    prod_spec = next(
        p for p in products.contract.custom_properties if p.property == "das.spec_ref"
    )
    dept_spec = next(
        p for p in departments.contract.custom_properties if p.property == "das.spec_ref"
    )

    assert prod_spec.value == {"kind": "odata", "type": "Product", "entity_set": "Products"}
    assert dept_spec.value == {
        "kind": "odata",
        "type": "Department",
        "entity_set": "Departments",
    }


def test_entity_set_strips_namespace_from_entity_type() -> None:
    """`EntityType="X.Y.Z.Address"` must key on the bare `Address`, not the qualified form."""
    xml = '''<?xml version="1.0" encoding="UTF-8"?>
<edmx:Edmx xmlns:edmx="http://docs.oasis-open.org/odata/ns/edmx" Version="4.0">
  <edmx:DataServices>
    <Schema xmlns="http://docs.oasis-open.org/odata/ns/edm" Namespace="Test.Models">
      <EntityType Name="Address">
        <Key><PropertyRef Name="AddressId" /></Key>
        <Property Name="AddressId" Type="Edm.Int32" Nullable="false" />
      </EntityType>
      <EntityContainer Name="Default">
        <EntitySet Name="Addresses" EntityType="Some.Deep.Namespace.Address" />
      </EntityContainer>
    </Schema>
  </edmx:DataServices>
</edmx:Edmx>
'''
    contracts = bootstrap_odata_contracts(xml, source_name="aw")
    addr = next(c for c in contracts if c.resource_name == "address")
    spec = next(p for p in addr.contract.custom_properties if p.property == "das.spec_ref")
    assert spec.value == {"kind": "odata", "type": "Address", "entity_set": "Addresses"}


def test_entity_set_omitted_when_no_container() -> None:
    """`$metadata` without an EntityContainer keeps the legacy spec_ref shape."""
    xml = '''<?xml version="1.0" encoding="UTF-8"?>
<edmx:Edmx xmlns:edmx="http://docs.oasis-open.org/odata/ns/edmx" Version="4.0">
  <edmx:DataServices>
    <Schema xmlns="http://docs.oasis-open.org/odata/ns/edm" Namespace="Test.Models">
      <EntityType Name="Product">
        <Key><PropertyRef Name="ProductId" /></Key>
        <Property Name="ProductId" Type="Edm.Int32" Nullable="false" />
      </EntityType>
    </Schema>
  </edmx:DataServices>
</edmx:Edmx>
'''
    contracts = bootstrap_odata_contracts(xml, source_name="aw")
    prod = next(c for c in contracts if c.resource_name == "products")
    spec = next(p for p in prod.contract.custom_properties if p.property == "das.spec_ref")
    assert spec.value == {"kind": "odata", "type": "Product"}
    assert "entity_set" not in spec.value


def test_entity_set_omitted_when_type_not_in_container() -> None:
    """EntityContainer that covers only some EntityTypes — uncovered types still emit."""
    xml = '''<?xml version="1.0" encoding="UTF-8"?>
<edmx:Edmx xmlns:edmx="http://docs.oasis-open.org/odata/ns/edmx" Version="4.0">
  <edmx:DataServices>
    <Schema xmlns="http://docs.oasis-open.org/odata/ns/edm" Namespace="Test.Models">
      <EntityType Name="Product">
        <Key><PropertyRef Name="ProductId" /></Key>
        <Property Name="ProductId" Type="Edm.Int32" Nullable="false" />
      </EntityType>
      <EntityType Name="Department">
        <Key><PropertyRef Name="DepartmentId" /></Key>
        <Property Name="DepartmentId" Type="Edm.Int16" Nullable="false" />
      </EntityType>
      <EntityContainer Name="Default">
        <EntitySet Name="Products" EntityType="Test.Models.Product" />
      </EntityContainer>
    </Schema>
  </edmx:DataServices>
</edmx:Edmx>
'''
    contracts = bootstrap_odata_contracts(xml, source_name="aw")
    prod = next(c for c in contracts if c.resource_name == "products")
    dept = next(c for c in contracts if c.resource_name == "departments")
    prod_spec = next(p for p in prod.contract.custom_properties if p.property == "das.spec_ref")
    dept_spec = next(p for p in dept.contract.custom_properties if p.property == "das.spec_ref")
    assert prod_spec.value == {"kind": "odata", "type": "Product", "entity_set": "Products"}
    assert dept_spec.value == {"kind": "odata", "type": "Department"}
    assert "entity_set" not in dept_spec.value
```

- [ ] **Step 4: Run the bootstrap-odata test file end-to-end**

```bash
uv run pytest tests/unit/test_bootstrap_odata.py -v
```

Expected: all tests pass — the existing eight tests (`test_emits_one_contract_per_entity_type`, `test_property_names_snake_cased`, `test_physical_names_preserved`, `test_decimal_with_precision_scale`, `test_int32_maps_to_integer`, `test_datetime_offset_to_timestamp`, `test_cursor_heuristic_picks_modified_date`, `test_spec_ref_added`, `test_no_cursor_when_no_modified_date`) plus the four new ones.

- [ ] **Step 5: Commit**

```bash
git add src/das_cli/bootstrap/odata.py tests/unit/test_bootstrap_odata.py
git commit -m "$(cat <<'EOF'
feat(bootstrap-odata): persist EntitySet name on das.spec_ref

Walks <EntityContainer><EntitySet> in $metadata and adds entity_set:<Name>
to das.spec_ref for each EntityType with a matching declaration. Strips
the namespace prefix from EntitySet@EntityType. Contracts whose EntityType
has no EntitySet entry keep the legacy {kind, type} shape — additive only.

Fixes the bootstrap side of issue #61. synthesize_odata_endpoint() picks up
the new key in a follow-up commit. See ADR-0024.
EOF
)"
```

---

### Task 4: Add the irregular-plural fixture and pin it end-to-end through bootstrap

This task introduces `sample_odata_metadata_irregular.xml` — a minimal `$metadata` exercising the actual issue-#61 shape (`Address` → `Addresses`, `Currency` → `Currencies`). Task 5 will use the same fixture-derived data to confirm `synthesize_odata_endpoint()` produces the right URLs.

**Files:**
- Create: `tests/fixtures/sample_odata_metadata_irregular.xml`
- Modify: `tests/unit/test_bootstrap_odata.py` (append one test)

- [ ] **Step 1: Create the fixture**

Create `tests/fixtures/sample_odata_metadata_irregular.xml`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<edmx:Edmx xmlns:edmx="http://docs.oasis-open.org/odata/ns/edmx" Version="4.0">
  <edmx:DataServices>
    <Schema xmlns="http://docs.oasis-open.org/odata/ns/edm" Namespace="AdventureWorks">
      <EntityType Name="Address">
        <Key><PropertyRef Name="AddressId" /></Key>
        <Property Name="AddressId" Type="Edm.Int32" Nullable="false" />
        <Property Name="AddressLine1" Type="Edm.String" Nullable="true" />
      </EntityType>
      <EntityType Name="Currency">
        <Key><PropertyRef Name="CurrencyCode" /></Key>
        <Property Name="CurrencyCode" Type="Edm.String" Nullable="false" MaxLength="3" />
        <Property Name="Name" Type="Edm.String" Nullable="false" />
      </EntityType>
      <EntityContainer Name="Default">
        <EntitySet Name="Addresses" EntityType="AdventureWorks.Address" />
        <EntitySet Name="Currencies" EntityType="AdventureWorks.Currency" />
      </EntityContainer>
    </Schema>
  </edmx:DataServices>
</edmx:Edmx>
```

- [ ] **Step 2: Write the test**

Append to `tests/unit/test_bootstrap_odata.py`:

```python
@pytest.fixture
def irregular_xml(fixtures_dir: Path) -> str:
    return (fixtures_dir / "sample_odata_metadata_irregular.xml").read_text()


def test_irregular_plurals_captured_from_entity_container(irregular_xml: str) -> None:
    """Issue #61 shape: EntityType plurals that the naive +s heuristic gets wrong
    (Address → Addresses, Currency → Currencies) must be captured from the
    EntityContainer."""
    contracts = bootstrap_odata_contracts(irregular_xml, source_name="adventureworks")
    # resource_name comes from pluralize(snake_case(name)).
    addr = next(c for c in contracts if c.resource_name == "address")
    curr = next(c for c in contracts if c.resource_name == "currencies")
    addr_spec = next(p for p in addr.contract.custom_properties if p.property == "das.spec_ref")
    curr_spec = next(p for p in curr.contract.custom_properties if p.property == "das.spec_ref")
    assert addr_spec.value == {
        "kind": "odata",
        "type": "Address",
        "entity_set": "Addresses",
    }
    assert curr_spec.value == {
        "kind": "odata",
        "type": "Currency",
        "entity_set": "Currencies",
    }
```

Note on `resource_name`: `pluralize(snake_case("Address"))` = `pluralize("address")`. `"address"` ends with `"s"`, so `pluralize()` returns it unchanged — the resource_name is `"address"` (singular). For `Currency`: `snake_case("Currency")` = `"currency"`, ends in `"y"` after consonant, so `pluralize()` returns `"currencies"`. The test asserts on these actual values.

- [ ] **Step 3: Run the test**

```bash
uv run pytest tests/unit/test_bootstrap_odata.py::test_irregular_plurals_captured_from_entity_container -v
```

Expected: PASS.

- [ ] **Step 4: Commit**

```bash
git add tests/fixtures/sample_odata_metadata_irregular.xml tests/unit/test_bootstrap_odata.py
git commit -m "$(cat <<'EOF'
test(bootstrap-odata): irregular-plural fixture (Address, Currency)

Adds a minimal $metadata exercising the issue-#61 shape so the EntitySet
parser is pinned against the actual failing cases. Used by the synthesis
tests in a follow-up commit to confirm /Addresses and /Currencies URLs.
EOF
)"
```

---

### Task 5: Update `synthesize_odata_endpoint` to use `entity_set` then the heuristic (TDD)

This is the synthesis-side change that produces the correct URL path. Tests first.

**Files:**
- Modify: `tests/unit/test_das_endpoint.py` (append after `test_synthesize_odata_falls_back_to_resource_name_when_no_spec_ref`)
- Modify: `src/das_cli/contracts/das_endpoint.py` (function `synthesize_odata_endpoint`, lines 91-103)

- [ ] **Step 1: Write the failing tests**

Append to `tests/unit/test_das_endpoint.py`:

```python
def test_synthesize_uses_entity_set_when_present() -> None:
    """Authoritative entity_set wins over the heuristic."""
    c = _contract(
        "address",
        CustomProperty(
            property="das.spec_ref",
            value={"kind": "odata", "type": "Address", "entity_set": "Addresses"},
        ),
    )
    ep = synthesize_odata_endpoint(c)
    assert ep.path == "/Addresses"


def test_synthesize_heuristic_handles_plus_es() -> None:
    """No entity_set → pluralize_preserving_case kicks in. Address → Addresses."""
    c = _contract(
        "address",
        CustomProperty(property="das.spec_ref", value={"kind": "odata", "type": "Address"}),
    )
    ep = synthesize_odata_endpoint(c)
    assert ep.path == "/Addresses"


def test_synthesize_heuristic_handles_y_to_ies() -> None:
    """No entity_set → Currency → Currencies via y→ies."""
    c = _contract(
        "currencies",
        CustomProperty(property="das.spec_ref", value={"kind": "odata", "type": "Currency"}),
    )
    ep = synthesize_odata_endpoint(c)
    assert ep.path == "/Currencies"


def test_synthesize_heuristic_handles_business_entity() -> None:
    """No entity_set → BusinessEntity → BusinessEntities via y→ies."""
    c = _contract(
        "business_entities",
        CustomProperty(
            property="das.spec_ref", value={"kind": "odata", "type": "BusinessEntity"}
        ),
    )
    ep = synthesize_odata_endpoint(c)
    assert ep.path == "/BusinessEntities"


def test_synthesize_entity_set_overrides_heuristic() -> None:
    """If entity_set is present, it wins even when the heuristic disagrees.

    Useful when $metadata declares a custom EntitySet name unrelated to its
    EntityType (e.g., set 'People' for type 'Person')."""
    c = _contract(
        "people",
        CustomProperty(
            property="das.spec_ref",
            value={"kind": "odata", "type": "Person", "entity_set": "People"},
        ),
    )
    ep = synthesize_odata_endpoint(c)
    assert ep.path == "/People"
```

- [ ] **Step 2: Run the tests to verify they fail**

```bash
uv run pytest tests/unit/test_das_endpoint.py -v
```

Expected: the five new tests fail. The existing `test_synthesize_odata_uses_spec_ref_type` (asserts `/Products` for type `Product`) and `test_synthesize_odata_falls_back_to_resource_name_when_no_spec_ref` still pass — they exercise paths the new code preserves.

- [ ] **Step 3: Implement the resolution chain**

In `src/das_cli/contracts/das_endpoint.py`, replace:

```python
def synthesize_odata_endpoint(contract: LoadedContract) -> DasEndpoint:
    """Default endpoint for an OData contract that lacks `das.endpoint`.

    Reproduces v0.1's call shape exactly.
    """
    spec_ref = get_das_value(contract.contract.custom_properties, "das.spec_ref")
    type_name = spec_ref.get("type") if isinstance(spec_ref, dict) else None
    path = f"/{type_name}s" if type_name else f"/{contract.resource_name}"
    return DasEndpoint(
        path=path,
        response_path="$.value",
        pagination={"type": "json_link", "next_url_path": "@odata.nextLink"},
    )
```

with:

```python
def synthesize_odata_endpoint(contract: LoadedContract) -> DasEndpoint:
    """Default endpoint for an OData contract that lacks `das.endpoint`.

    Path resolution order (see ADR-0024):

    1. `das.spec_ref.entity_set` — authoritative, captured at bootstrap from
       `$metadata`'s `<EntityContainer><EntitySet>`.
    2. `pluralize_preserving_case(das.spec_ref.type)` — case-preserving
       heuristic for contracts bootstrapped before ADR-0024 landed, or for
       `$metadata` without an EntityContainer.
    3. `contract.resource_name` — last-ditch fallback when `das.spec_ref` is
       absent entirely.

    Other endpoint fields are unchanged: OData's `$.value` envelope and the
    JSON-link paginator on `@odata.nextLink`.
    """
    from das_cli.bootstrap.naming import pluralize_preserving_case

    spec_ref = get_das_value(contract.contract.custom_properties, "das.spec_ref")
    if isinstance(spec_ref, dict):
        entity_set = spec_ref.get("entity_set")
        if isinstance(entity_set, str) and entity_set:
            path = f"/{entity_set}"
        else:
            type_name = spec_ref.get("type")
            if isinstance(type_name, str) and type_name:
                path = f"/{pluralize_preserving_case(type_name)}"
            else:
                path = f"/{contract.resource_name}"
    else:
        path = f"/{contract.resource_name}"

    return DasEndpoint(
        path=path,
        response_path="$.value",
        pagination={"type": "json_link", "next_url_path": "@odata.nextLink"},
    )
```

Note the deliberate local import of `pluralize_preserving_case` inside the function — `contracts/das_endpoint.py` does not currently import from `bootstrap/`, and routing the synthesis fallback through a bootstrap helper at the top level would create a contracts-↛bootstrap import edge. Keeping the import local stays neutral on module boundaries; if a top-level import is preferred, move it and confirm nothing in `contracts/` is imported during `bootstrap/`'s module init.

- [ ] **Step 4: Run the synthesis tests**

```bash
uv run pytest tests/unit/test_das_endpoint.py -v
```

Expected: all tests pass — the five new ones plus all 15 pre-existing tests.

- [ ] **Step 5: Commit**

```bash
git add src/das_cli/contracts/das_endpoint.py tests/unit/test_das_endpoint.py
git commit -m "$(cat <<'EOF'
fix(das-endpoint): use entity_set then case-preserving heuristic for OData paths (#61)

synthesize_odata_endpoint() previously appended a naive 's' to spec_ref.type,
producing /Addresss, /Currencys, /BusinessEntitys against AdventureWorks. The
new resolution chain prefers das.spec_ref.entity_set (authoritative from
$metadata), then pluralize_preserving_case() (y→ies, +es on s/x/z/ch/sh),
then resource_name. Explicit das.endpoint on the contract still wins
(ADR-0014, unchanged). See ADR-0024.

Fixes #61.
EOF
)"
```

---

### Task 6: Write ADR-0024 and update the ADR index

Per `CLAUDE.md`: ADRs on a feature branch are free to evolve until merge. Both files land here.

**Files:**
- Create: `docs/adrs/0024-odata-entityset-on-spec-ref.md`
- Modify: `docs/adrs/README.md` (append one row to the index table)

- [ ] **Step 1: Create the ADR**

Create `docs/adrs/0024-odata-entityset-on-spec-ref.md`:

```markdown
# 0024. OData EntitySet name persisted on `das.spec_ref`

- **Status:** Accepted
- **Date:** 2026-05-13
- **Deciders:** mattiasthalen

## Context

ADR-0014's synthesis fallback for OData derives the URL path by appending `"s"`
to `das.spec_ref.type`. This works for EntityTypes whose EntitySet pluralizes
via plain `+s` (Northwind: `Product` → `/Products`) but fails for `+es`,
`y → ies`, and irregular plurals (AdventureWorks: `Address` → `/Addresses`,
`Currency` → `/Currencies`, `Person` → `/People`). The authoritative name lives
in `$metadata`'s `<EntityContainer><EntitySet>` block.

## Decision

OData bootstrap (`bootstrap/odata.py`) reads `<EntityContainer><EntitySet>` and
persists the set name on `das.spec_ref.entity_set` for each EntityType with a
matching declaration:

    customProperties:
      - property: das.spec_ref
        value:
          kind: odata
          type: Address
          entity_set: Addresses

`synthesize_odata_endpoint()` resolves the path in this order:

1. `spec_ref.entity_set` if present.
2. `pluralize_preserving_case(spec_ref.type)` heuristic (`y → ies`, `+es` on
   `s/x/z/ch/sh`, else `+s`).
3. `contract.resource_name`.

Explicit `das.endpoint` on the contract continues to win over synthesis
(ADR-0014, unchanged).

## Alternatives considered

- **Heuristic only.** Cheaper, but drifts from authoritative `$metadata` and
  silently 404s on truly irregular plurals.
- **Require explicit `das.endpoint` everywhere.** Hard-breaks the OData
  zero-config ergonomic that ADR-0014 deliberately preserved.

## Consequences

- **Positive:** Newly-bootstrapped OData sources use the actual EntitySet
  names from `$metadata`. Legacy contracts gain a meaningful heuristic
  improvement for free.
- **Negative:** Legacy contracts with truly irregular plurals (Person/People)
  still fail until re-bootstrap or explicit `das.endpoint`. Documented as the
  migration path; no automatic upgrade.
- **Neutral:** `das.spec_ref.entity_set` is additive; older das-cli versions
  ignore unknown keys.
```

- [ ] **Step 2: Append the row to the ADR index**

Edit `docs/adrs/README.md`. After the line:

```markdown
| 0023 | Opt-in row-level provenance via `das.spec_ref.inject` | Accepted |
```

append:

```markdown
| 0024 | OData EntitySet name persisted on `das.spec_ref` | Accepted |
```

- [ ] **Step 3: Confirm the ADR index sanity rules from CLAUDE.md**

Run:

```bash
head -1 docs/adrs/0*.md
```

Expected output ends with:

```
==> docs/adrs/0024-odata-entityset-on-spec-ref.md <==
# 0024. OData EntitySet name persisted on `das.spec_ref`
```

Confirm the title in the file matches the title in the index row (verbatim, including the trailing-period suffix style used by adjacent rows).

- [ ] **Step 4: Verify no ADR-0024 collision on `origin/main`**

```bash
git fetch origin main && git ls-tree --name-only origin/main docs/adrs/ | grep '^docs/adrs/0024' || echo "no collision"
```

Expected: `no collision`. (If origin/main already contains a `0024-*.md`, renumber this branch's ADR to the next free number, update the index row, and update all references — `synthesize_odata_endpoint`'s docstring, the spec file, and Task 1's `pluralize_preserving_case` docstring.)

- [ ] **Step 5: Commit**

```bash
git add docs/adrs/0024-odata-entityset-on-spec-ref.md docs/adrs/README.md
git commit -m "$(cat <<'EOF'
docs(adr): 0024 — OData EntitySet name persisted on das.spec_ref

Records the contract-surface addition (das.spec_ref.entity_set) and the
3-step path resolution chain in synthesize_odata_endpoint(). Extends —
does not contradict — ADR-0014. Adds the index row.
EOF
)"
```

---

### Task 7: Add an opt-in e2e test exercising an irregular plural against AdventureWorks

The existing `test_adventureworks_bootstrap_extract_load` uses `--only products` (regular plural, would have passed even with today's naive code). We add a sibling test using `--only addresses` so the live regression for issue #61 is captured. Auto-marked `e2e` via `tests/e2e/conftest.py`; opt-in only.

**Files:**
- Modify: `tests/e2e/sources/test_odata_adventureworks.py` (append after the existing test)

- [ ] **Step 1: Append the test**

Append to `tests/e2e/sources/test_odata_adventureworks.py`:

```python
def test_adventureworks_irregular_plural_addresses(
    workspace: Path, cli_runner: CliRunner
) -> None:
    """Regression: issue #61 — Address → /Addresses (not /Addresss).

    Bootstraps the addresses resource against the live AdventureWorks OData
    feed and extracts a small page. If this fails with a 404, the EntitySet
    name was not captured from $metadata OR the heuristic regressed.
    """
    cli_runner.invoke(app, ["init"])
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "adventureworks",
            "--type",
            "odata",
            "--url",
            "https://demodata.grapecity.com/adventureworks/odata/v1",
        ],
    )

    bootstrap = cli_runner.invoke(
        app,
        [
            "contract",
            "bootstrap",
            "adventureworks",
            "--only",
            "address",
        ],
    )
    assert bootstrap.exit_code == 0, bootstrap.stdout + bootstrap.stderr

    extract = cli_runner.invoke(
        app,
        [
            "extract",
            "adventureworks",
            "--resource",
            "address",
            "--limit",
            "5",
        ],
    )
    assert extract.exit_code == 0, extract.stdout + extract.stderr

    landing = workspace / "landing" / "adventureworks" / "address"
    assert any(landing.rglob("*.jsonl*")), "no JSONL files landed; extract path resolution failed"

    load = cli_runner.invoke(app, ["load", "adventureworks", "--resource", "address"])
    assert load.exit_code == 0, load.stdout + load.stderr

    db = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        row = db.execute('SELECT COUNT(*) FROM "das__adventureworks".address').fetchone()
        count = row[0] if row is not None else 0
    finally:
        db.close()
    assert 1 <= count <= 5, f"row count {count} outside (0, --limit=5]"
```

Note on the `--only address` argument: `bootstrap/naming.py::pluralize("Address")` → `"address"` (snake_case "address" already ends in `s` → passthrough). The resource_name is the singular form `"address"`. The same name is used as the table name in DuckDB (`"das__adventureworks".address`).

- [ ] **Step 2: Run the new e2e test (opt-in)**

```bash
uv run pytest tests/e2e/sources/test_odata_adventureworks.py::test_adventureworks_irregular_plural_addresses -v -m e2e
```

Expected: PASS. If the public AdventureWorks endpoint is flaky or unreachable, the test will fail with a network error; rerun. If it fails with a 404 on `/Addresses`, the implementation in Task 3 or Task 5 has a defect — debug from there.

- [ ] **Step 3: Run the full e2e file**

```bash
uv run pytest tests/e2e/sources/test_odata_adventureworks.py -v -m e2e
```

Expected: both tests pass (the original `test_adventureworks_bootstrap_extract_load` plus the new one).

- [ ] **Step 4: Commit**

```bash
git add tests/e2e/sources/test_odata_adventureworks.py
git commit -m "$(cat <<'EOF'
test(e2e): AdventureWorks irregular plural — /Addresses (#61)

Live regression for issue #61. Bootstraps and extracts the address resource
against the public AdventureWorks OData feed, asserts ≥1 row lands. Opt-in
via -m e2e.
EOF
)"
```

---

### Task 8: Run the full unit + integration suite and pre-commit

Confirm nothing else regressed before pushing.

- [ ] **Step 1: Run unit + integration**

```bash
uv run pytest tests/unit tests/integration -q
```

Expected: all green. Task 1 adds 6 tests, Task 3 adds 4 tests, Task 4 adds 1 test, Task 5 adds 5 tests — 16 new unit tests total. The baseline is whatever's on `origin/main` at merge time; expect baseline + 16.

- [ ] **Step 2: Run pre-commit on all files**

```bash
uv run pre-commit run --all-files
```

Expected: clean. If ruff-format reflows any new code, stage the reflow and amend it into the most-recent relevant commit (or create a small `style:` follow-up commit — do not amend `feat:` or `fix:` commits if you've already pushed). If mypy complains about the new local import in `synthesize_odata_endpoint`, confirm `from das_cli.bootstrap.naming import pluralize_preserving_case` resolves — if not, the function name in `bootstrap/naming.py` doesn't match what's imported.

- [ ] **Step 3: Optional — run the OData e2e locally if you have network**

```bash
uv run pytest tests/e2e/sources/test_odata_adventureworks.py -v -m e2e
```

Expected: both AdventureWorks tests pass. Skip if no network — CI will run them.

---

### Task 9: Push the branch and open a PR

- [ ] **Step 1: Push the branch**

The current worktree branch is `worktree-issue-61-odata-pluralization-spec` (created by `EnterWorktree` during brainstorming; the spec commit and all implementation commits sit on it). Push:

```bash
git push -u origin worktree-issue-61-odata-pluralization-spec
```

- [ ] **Step 2: Open the PR**

```bash
gh pr create --title "fix(odata): use EntitySet from \$metadata for synthesized paths (#61)" --body "$(cat <<'EOF'
## Summary

- Fixes #61 — `synthesize_odata_endpoint()` was appending `"s"` to `spec_ref.type`, producing `/Addresss` / `/Currencys` / `/BusinessEntitys` against AdventureWorks. 7 EntityTypes broke; the public AdventureWorks demo feed 404'd at the first resource.
- Bootstrap now reads `<EntityContainer><EntitySet>` from `$metadata` and persists `entity_set: <Name>` on `das.spec_ref`. Synthesis prefers it.
- Fallback is a new `pluralize_preserving_case()` (y→ies, +es on s/x/z/ch/sh) so legacy contracts also improve without re-bootstrap. Explicit `das.endpoint` still wins (ADR-0014).
- Adds ADR-0024 for the contract-surface change.

Spec: `docs/superpowers/specs/2026-05-13-odata-entityset-pluralization-design.md`.
Plan: `docs/superpowers/plans/2026-05-13-odata-entityset-pluralization.md`.

## Test plan

- [x] `uv run pytest tests/unit tests/integration -q` — all green locally; +16 new unit tests.
- [x] `uv run pre-commit run --all-files` — clean.
- [x] Bootstrap-side: 5 new tests cover EntityContainer present/absent, namespace-stripped, partial coverage, and the irregular-plural fixture.
- [x] Synthesis-side: 5 new tests cover entity_set wins, heuristic +es, heuristic y→ies, BusinessEntity, and entity_set overriding the heuristic.
- [x] Naming-side: 6 new tests pin `pluralize_preserving_case` rules including negative cases (News / Person / Mouse are out of scope for the heuristic and rely on entity_set).
- [ ] CI e2e: new `test_adventureworks_irregular_plural_addresses` is the live regression — it must run on a runner with network access to demodata.grapecity.com.

## Migration

Existing OData workspaces:
- Re-run `das contract bootstrap <source>` to upgrade `das.spec_ref` with `entity_set`. Optional but recommended.
- Without re-bootstrap, the new heuristic still fixes the seven AdventureWorks irregulars; only truly irregular plurals (Person/People, Mouse/Mice, English uncountables) still need re-bootstrap or an explicit `das.endpoint`.

## ADR

- **New:** ADR-0024 — OData EntitySet name persisted on `das.spec_ref`.
- **Unchanged:** ADR-0014 (per-resource `das.endpoint`) — `das.endpoint` still wins over synthesis.

## Out of scope

- `das ingest` partial-vs-full exit semantics (issue #61 side observation: rc=5 even though 0/66 processed). File as a separate issue.
EOF
)"
```

- [ ] **Step 3: Watch CI**

```bash
gh pr checks --watch
```

Expected: all checks green. The new e2e test against AdventureWorks is the live regression — confirm it runs and passes. If it 404s, the implementation has a defect; investigate locally before iterating.

---

## Self-review

- **Spec coverage:** every section of the spec maps to a task —
  - Problem statement / bug repro → context for Tasks 3 + 5; live regression in Task 7.
  - Fix §1 (bootstrap reads `<EntityContainer>`) → Task 3.
  - Fix §2 (synthesis resolution chain) → Task 5.
  - Fix §3 (`pluralize_preserving_case`) → Task 1.
  - Behavior matrix rows → covered by Task 1 (heuristic), Task 5 (synthesis), Task 7 (live e2e for irregulars).
  - Test plan — bootstrap → Tasks 2, 3, 4. Synthesis → Task 5. Naming → Task 1. E2e → Task 7.
  - ADR section → Task 6.
  - Out-of-scope items (ingest exit semantics, pluralize() augmentation) → not implemented; documented in the PR body and spec.
- **Placeholder scan:** no TBD / "implement later" / "similar to Task N" — every step has a shell command or a complete code block.
- **Type consistency:**
  - `pluralize_preserving_case(name: str) -> str` — signature consistent across Task 1 implementation, Task 5 import, and Task 1 / Task 5 test usages.
  - `_build_custom_properties(type_name: str, properties: list[OdcsProperty], *, entity_set: str | None) -> list[CustomProperty]` — only callsite is `_build_contract` in Task 3; both updated together.
  - `_build_entity_set_map(root: ElementTree.Element) -> dict[str, str]` — only callsite is `bootstrap_odata_contracts`; both updated in Task 3.
  - `spec_ref` value shape: `{"kind": "odata", "type": <str>}` (legacy) and `{"kind": "odata", "type": <str>, "entity_set": <str>}` (new) — exact-dict assertions in Tasks 2 + 3 + 4 use these shapes consistently.
- **TDD order:** Task 1 (red → green → commit). Task 2 (red on one existing test). Task 3 (makes Task 2 green + adds new green tests). Task 4 (new fixture + test, green). Task 5 (red → green → commit). Tasks 6–9 (docs / e2e / CI — no new internal API surface).
- **Branch & worktree:** all work happens on `worktree-issue-61-odata-pluralization-spec`, which already contains the spec commit. The PR title and body reference issue #61.
