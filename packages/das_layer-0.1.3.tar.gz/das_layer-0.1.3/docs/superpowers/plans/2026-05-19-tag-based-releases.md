# Tag-Based Releases Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Enable cutting a release of `das-cli` (PyPI distribution name `das-layer`) by pushing a `vX.Y.Z` git tag — GitHub Actions builds the package, derives the version from the tag via `hatch-vcs`, publishes to PyPI via OIDC trusted publishing, and creates a GitHub Release with auto-generated notes.

**Architecture:** `pyproject.toml` switches `[project] name` from `das-cli` to `das-layer` and `version = "0.1.0"` to `dynamic = ["version"]` with `hatch-vcs` reading the git tag. `src/das_cli/__init__.py` reads `__version__` via `importlib.metadata.version("das-layer")`. A new workflow `.github/workflows/release.yml` runs only on `push.tags: ["v*"]`: checkout with `fetch-depth: 0`, `uv build`, `pypa/gh-action-pypi-publish@release/v1` (OIDC, no tokens), then `softprops/action-gh-release@v2` with auto-generated notes. ADR-0026 documents the decision.

**Tech Stack:** Python 3.12+, `hatchling`, `hatch-vcs`, `uv`, GitHub Actions, PyPI OIDC trusted publishing.

**Spec:** `docs/superpowers/specs/2026-05-19-tag-based-releases-design.md`

---

## File Structure

- Create: `docs/adrs/0026-tag-based-releases-via-hatch-vcs.md` — the policy ADR.
- Modify: `docs/adrs/README.md` — add the `0026` row to the index table.
- Modify: `pyproject.toml` — rename `[project] name`, drop static `version`, add `dynamic = ["version"]`, add `hatch-vcs` to `[build-system].requires`, add `[tool.hatch.version]` block.
- Modify: `src/das_cli/__init__.py` — replace literal `__version__` with `importlib.metadata.version("das-layer")`.
- Create: `.github/workflows/release.yml` — tag-triggered build + publish + GitHub Release.
- Modify: `README.md` — update PyPI badge URLs and the two `uv tool install` lines to use `das-layer`; add a one-line note about `pip` / `pipx` alternatives.

**Out of scope (do not touch):**
- `src/das_cli/bootstrap/*.py` `version="0.1.0"` strings — these are ODCS contract document version fields, not the das-cli package version. Leave them alone.
- `.github/workflows/ci.yml` — `fallback-version = "0.0.0"` in pyproject means shallow checkouts still work; no fetch-depth changes needed.

---

## Task 1: Write ADR-0026 and update the ADR index

**Files:**
- Create: `docs/adrs/0026-tag-based-releases-via-hatch-vcs.md`
- Modify: `docs/adrs/README.md` (add one row to the index table)

- [ ] **Step 1: Verify ADR-0026 is free on `main` and on this branch**

Run:

```bash
git fetch origin main >/dev/null 2>&1
ls docs/adrs/0026-*.md 2>/dev/null && echo "COLLISION" || echo "FREE locally"
git ls-tree -r origin/main docs/adrs/ | grep '^.*0026-' && echo "COLLISION on main" || echo "FREE on main"
```

Expected: `FREE locally` and `FREE on main`. If either prints `COLLISION`, stop and renumber to the next available integer before continuing — and update every reference to `0026` in this plan accordingly.

- [ ] **Step 2: Create the ADR file**

Use the Write tool to create `docs/adrs/0026-tag-based-releases-via-hatch-vcs.md` with exactly this content:

```markdown
# 0026. Tag-based releases via hatch-vcs and PyPI OIDC trusted publishing

- **Status:** Accepted
- **Date:** 2026-05-19
- **Deciders:** Mattias Thalén

## Context

das-cli ships as a CLI installed from PyPI (`uv tool install ...`). The
repo had no git tags, no release workflow, and a static `version = "0.1.0"`
in `pyproject.toml`. Cutting a release meant building and uploading by
hand — error-prone and not reproducible.

Two adjacent constraints shape the decision:

1. The PyPI name `das-cli` is already taken by an unrelated active project
   (Royal Netherlands Institute for Sea Research, distributed acoustic
   sensing). The package must publish under a different distribution name.
2. The maintainer ships solo, pre-1.0, and picks version numbers by hand.
   A fully automated release-please / semantic-release setup is overkill
   for this scale.

## Decision

- **PyPI distribution name** is `das-layer`. The GitHub repo, the CLI
  command (`das`), and the Python import path (`das_cli`) are unchanged.
- **Release trigger** is a `vX.Y.Z` git tag pushed to the repo. A
  workflow `.github/workflows/release.yml` runs on `push.tags: ["v*"]`.
  No other trigger.
- **Version source** is the git tag, read by `hatch-vcs` at build time.
  `pyproject.toml` declares `dynamic = ["version"]` and configures
  `[tool.hatch.version] source = "vcs"` with `fallback-version = "0.0.0"`.
  `src/das_cli/__init__.py` reads `__version__` via
  `importlib.metadata.version("das-layer")`.
- **PyPI authentication** is OIDC trusted publishing via
  `pypa/gh-action-pypi-publish@release/v1`. No long-lived tokens in
  GitHub. One-time bootstrap on pypi.org registers a pending publisher
  for `das-layer` pointing at the repo and workflow filename.
- **Release notes** are auto-generated from PR titles since the previous
  tag, via `softprops/action-gh-release@v2` with
  `generate_release_notes: true`. No CHANGELOG.md.

## Alternatives considered

- **GitHub Release UI as trigger** (workflow on `release: published`) —
  adds a second path to a release with no benefit; `git tag && git push
  --tags` already does the job.
- **release-please / semantic-release** — automates conventional-commit
  to version bumps. Overkill for one maintainer pre-1.0; revisit if
  multi-maintainer or external consumers demand strict semver.
- **Static `version` in `pyproject.toml` + CI guard** — eliminates the
  hatch-vcs dependency at the cost of a manual step. `hatch-vcs` makes
  the drift it would catch impossible in the first place.
- **API token in a GitHub secret** instead of OIDC — simpler one-time
  bootstrap, but the token is long-lived and needs rotation. OIDC is
  PyPA's current recommendation.
- **TestPyPI dry-run before PyPI publish** — adds a second publisher to
  register. The first real PyPI publish (`v0.1.0`) is itself the dry-run.
  Add later if a release goes wrong in a way TestPyPI would have caught.
- **`pip install` as the primary install command in docs** — the repo is
  uv-native end-to-end (CI, README). Keep `uv tool install` primary and
  mention `pip` as an alternative.

## Consequences

**Positive**
- Every PyPI artifact corresponds to a signed git tag; no manual build
  steps.
- No long-lived PyPI credentials stored in GitHub.
- Tag and package version cannot drift — they are the same value.
- Pre-release tags (`v0.2.0a1`) flow through the same workflow with no
  extra config.

**Negative**
- First release requires one-time pending-publisher registration in the
  pypi.org UI.
- `hatch-vcs` is a new build-time dependency. The
  `fallback-version = "0.0.0"` setting keeps `uv sync` working on shallow
  CI checkouts without tags.
- Release-note quality is coupled to PR-title hygiene; currently good.

**Neutral**
- The maintainer continues to pick version numbers by hand. SemVer is a
  convention, not enforced by tooling.
- No CHANGELOG.md. Release history is reconstructible from GitHub
  Releases and `git log`.
```

- [ ] **Step 3: Read the ADR README index header before editing**

Run:

```bash
sed -n '1,7p' docs/adrs/README.md
tail -7 docs/adrs/README.md
```

Confirm the table format is `| NNNN | Title | Status |` and the last row before any trailing blank lines is for `0025`. If `0026` already appears in the table, stop — your ADR file collision check missed it.

- [ ] **Step 4: Append the new row to the index**

Use the Edit tool on `docs/adrs/README.md` with these exact strings.

`old_string`:

```
| 0025 | OData bootstrap driven by `<EntityContainer><EntitySet>` | Accepted |
```

`new_string`:

```
| 0025 | OData bootstrap driven by `<EntityContainer><EntitySet>` | Accepted |
| 0026 | Tag-based releases via hatch-vcs and PyPI OIDC trusted publishing | Accepted |
```

- [ ] **Step 5: Verify the index now matches the file set per CLAUDE.md's pre-merge ADR check**

Run:

```bash
head -1 docs/adrs/0026-*.md
grep -c "^| 0026 " docs/adrs/README.md
```

Expected output:

```
# 0026. Tag-based releases via hatch-vcs and PyPI OIDC trusted publishing
1
```

The `# 0026.` heading must exactly match the title text in the index row (modulo the leading `# NNNN.` prefix in the file).

- [ ] **Step 6: Commit**

```bash
git add docs/adrs/0026-tag-based-releases-via-hatch-vcs.md docs/adrs/README.md
git commit -m "docs(adr): 0026 — tag-based releases via hatch-vcs + PyPI OIDC"
```

---

## Task 2: Switch `pyproject.toml` to `das-layer` + dynamic version

**Files:**
- Modify: `pyproject.toml:1-3,28-30`

- [ ] **Step 1: Read the current top of `pyproject.toml`**

Run:

```bash
sed -n '1,10p' pyproject.toml
sed -n '28,30p' pyproject.toml
```

Confirm lines 1-3 read:

```
[project]
name = "das-cli"
version = "0.1.0"
```

…and lines 28-30 read:

```
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"
```

If either differs, stop and rebase.

- [ ] **Step 2: Rename the project and switch to dynamic version**

Use the Edit tool on `pyproject.toml`.

`old_string`:

```
[project]
name = "das-cli"
version = "0.1.0"
description = "Contract-driven DAS-layer ingestion CLI built on dlt"
```

`new_string`:

```
[project]
name = "das-layer"
dynamic = ["version"]
description = "Contract-driven DAS-layer ingestion CLI built on dlt"
```

- [ ] **Step 3: Add `hatch-vcs` to the build backend requirements and the version-source config**

Use the Edit tool on `pyproject.toml`.

`old_string`:

```
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/das_cli"]
```

`new_string`:

```
[build-system]
requires = ["hatchling", "hatch-vcs"]
build-backend = "hatchling.build"

[tool.hatch.version]
source = "vcs"
fallback-version = "0.0.0"

[tool.hatch.build.targets.wheel]
packages = ["src/das_cli"]
```

- [ ] **Step 4: Verify the diff is exactly what was intended**

Run:

```bash
git diff pyproject.toml
```

Expected: two hunks. The first changes `name = "das-cli"` and `version = "0.1.0"` into `name = "das-layer"` and `dynamic = ["version"]`. The second adds three lines (`requires` gets `, "hatch-vcs"`) and a new `[tool.hatch.version]` block before `[tool.hatch.build.targets.wheel]`. No other lines change.

- [ ] **Step 5: Commit (do not run `uv sync` yet — that's the smoke test in Task 4)**

```bash
git add pyproject.toml
git commit -m "build: rename to das-layer + dynamic version via hatch-vcs"
```

---

## Task 3: Switch `__version__` to `importlib.metadata`

**Files:**
- Modify: `src/das_cli/__init__.py`

- [ ] **Step 1: Confirm the file is still the single literal**

Run:

```bash
cat src/das_cli/__init__.py
```

Expected output (exactly):

```
__version__ = "0.1.0"
```

If it differs, stop and rebase.

- [ ] **Step 2: Replace the literal with an `importlib.metadata` lookup**

Use the Write tool to overwrite `src/das_cli/__init__.py` with:

```python
from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("das-layer")
except PackageNotFoundError:  # not installed (e.g., running from source tree)
    __version__ = "0.0.0+unknown"

__all__ = ["__version__"]
```

The `try`/`except` is a real boundary case: a developer running `python -c "from das_cli import __version__"` from a checkout that has never been installed has no dist-info on disk, and `importlib.metadata.version` raises `PackageNotFoundError`. After `uv sync` the editable install registers the dist-info and the happy path resolves.

- [ ] **Step 3: Verify the change**

Run:

```bash
git diff src/das_cli/__init__.py
```

Expected: one hunk removing the single line `__version__ = "0.1.0"` and replacing it with the seven-line block above. No other changes.

- [ ] **Step 4: Commit**

```bash
git add src/das_cli/__init__.py
git commit -m "build: read __version__ from installed distribution metadata"
```

---

## Task 4: Smoke-test the local build with `hatch-vcs`

This task verifies that the changes from Tasks 2 and 3 produce a working install and a sane wheel filename before adding the publish workflow. **No new commit at the end** — this is a verification pass.

**Files:** none modified.

- [ ] **Step 1: Re-sync the project so `uv` picks up the new metadata**

Run:

```bash
uv sync
```

Expected: succeeds, prints a line like `Installed N packages` or `Audited N packages`. If it fails complaining about `hatch-vcs`, that's the regression we're testing for — stop and investigate (most likely `uv` did not invoke the new build backend; try `uv sync --reinstall-package das-layer`).

- [ ] **Step 2: Confirm the installed version reports the fallback**

There are no tags on this branch, so `hatch-vcs` should produce a version starting with `0.0.0` (the fallback) plus a dev-suffix derived from the current commit.

Run:

```bash
uv run python -c "from importlib.metadata import version; print(version('das-layer'))"
uv run das --version
```

Expected output for both: a version string that **starts with `0.0.0`** (e.g., `0.0.0.post1.dev2+gabcdef0` or just `0.0.0`). Any concrete X.Y.Z value is fine as long as it does not say `0.1.0` (which would mean hatch-vcs didn't run and we're still reading the old literal somehow).

- [ ] **Step 3: Build a wheel and confirm the filename uses `das_layer`**

Run:

```bash
rm -rf dist/
uv build
ls dist/
```

Expected: two files matching `das_layer-*.whl` and `das_layer-*.tar.gz`. The version segment in the filename should match what Step 2 printed.

- [ ] **Step 4: Simulate the tagged build locally**

Create an ephemeral local tag, rebuild, then delete the tag. This proves the workflow will produce a clean `0.1.0` wheel when the real tag is pushed.

Run:

```bash
git tag v0.1.0
rm -rf dist/
uv build
ls dist/
git tag -d v0.1.0
```

Expected: `dist/` contains exactly `das_layer-0.1.0-py3-none-any.whl` and `das_layer-0.1.0.tar.gz` (no `.dev` suffix). If the filename still contains `0.0.0` or a dev suffix, hatch-vcs is not seeing the tag — most likely a shallow checkout issue (should not apply locally, but worth recording).

- [ ] **Step 5: Clean up build artifacts**

Run:

```bash
rm -rf dist/
git status
```

Expected: `git status` shows no `dist/` files (already in `.gitignore`) and no `src/das_cli/_version.py` (we don't use `version-file`). The tree is clean.

- [ ] **Step 6: Run the existing test suite to verify nothing else regressed**

Run:

```bash
uv run pytest tests/unit tests/integration -q
```

Expected: all currently-passing tests still pass. There are no new tests for this task because the only behavior added (`das --version` reading from metadata) was already covered by Step 2; the existing CLI integration tests do not depend on a specific version string.

If any test fails, the most likely cause is a hard-coded `0.1.0` somewhere outside the bootstrap/*.py files this plan explicitly leaves alone. Investigate before continuing.

---

## Task 5: Add the release workflow

**Files:**
- Create: `.github/workflows/release.yml`

- [ ] **Step 1: Confirm the workflow file does not yet exist**

Run:

```bash
ls .github/workflows/
```

Expected: `ci.yml` only.

- [ ] **Step 2: Create `.github/workflows/release.yml`**

Use the Write tool with this exact content:

```yaml
name: Release
on:
  push:
    tags: ["v*"]

permissions:
  contents: read

jobs:
  build-and-publish:
    name: Build, publish to PyPI, and cut a GitHub Release
    runs-on: ubuntu-latest
    permissions:
      id-token: write       # OIDC for PyPI trusted publishing
      contents: write       # create GitHub Release + upload assets

    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0    # hatch-vcs needs full tag history

      - uses: astral-sh/setup-uv@v3
        with:
          enable-cache: true

      - run: uv python install 3.12

      - name: Build sdist and wheel
        run: uv build

      - name: List built artifacts
        run: ls -lh dist/

      - name: Publish to PyPI (OIDC trusted publishing)
        uses: pypa/gh-action-pypi-publish@release/v1

      - name: Create GitHub Release with auto-generated notes
        uses: softprops/action-gh-release@v2
        with:
          generate_release_notes: true
          files: dist/*
```

Notes on the shape (do not edit unless a problem is found):

- The top-level `permissions: contents: read` is the default-deny baseline; the job overrides it to `id-token: write` (PyPI OIDC) and `contents: write` (GitHub Release).
- `fetch-depth: 0` is mandatory: hatch-vcs walks `git describe --tags`; a shallow clone produces the fallback version and the wheel filename would not match the tag.
- `pypa/gh-action-pypi-publish@release/v1` is the canonical PyPA action and the path PyPI's own trusted-publishing setup guide references. No `username` or `password` inputs are passed — the action reads the OIDC token automatically.
- `softprops/action-gh-release@v2` auto-detects prerelease status from the tag (`v0.2.0a1` → prerelease) and uploads the `dist/*` files as release assets.

- [ ] **Step 3: Lint the YAML for syntax errors**

Run:

```bash
uv run python -c "import yaml; yaml.safe_load(open('.github/workflows/release.yml'))"
```

Expected: no output, exit code 0. If pyyaml is not available in the dev environment, the same can be done with `python3 -c ...`.

- [ ] **Step 4: Sanity-check the action references**

Run:

```bash
grep -E 'uses: ' .github/workflows/release.yml
```

Expected output (exactly four `uses:` lines):

```
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v3
      - uses: pypa/gh-action-pypi-publish@release/v1
      - uses: softprops/action-gh-release@v2
```

- [ ] **Step 5: Commit**

```bash
git add .github/workflows/release.yml
git commit -m "ci: add release workflow on vX.Y.Z tag push"
```

---

## Task 6: Update README install instructions and PyPI badge URLs

**Files:**
- Modify: `README.md` (PyPI badge line, two `uv tool install das-cli` lines in the Quickstart, add a one-line pip/pipx note)

- [ ] **Step 1: Read every line that needs to change**

Run:

```bash
grep -n "das-cli" README.md | head -20
```

Identify the lines we will touch:

1. The PyPI badge line: `[![PyPI version](https://img.shields.io/pypi/v/das-cli.svg)](https://pypi.org/project/das-cli/)`
2. The Python-versions badge line: `[![Python versions](https://img.shields.io/pypi/pyversions/das-cli.svg)](https://pypi.org/project/das-cli/)`
3. The two `uv tool install das-cli` invocations in Quickstart (one in the first example, one in the SQL-source example with `--with oracledb`).

Other matches of `das-cli` (the repo name, the README title, GitHub URLs) **stay** — those refer to the repository, not the PyPI distribution.

- [ ] **Step 2: Update the PyPI badges**

Use the Edit tool on `README.md`.

`old_string`:

```
[![PyPI version](https://img.shields.io/pypi/v/das-cli.svg)](https://pypi.org/project/das-cli/)
[![Python versions](https://img.shields.io/pypi/pyversions/das-cli.svg)](https://pypi.org/project/das-cli/)
```

`new_string`:

```
[![PyPI version](https://img.shields.io/pypi/v/das-layer.svg)](https://pypi.org/project/das-layer/)
[![Python versions](https://img.shields.io/pypi/pyversions/das-layer.svg)](https://pypi.org/project/das-layer/)
```

- [ ] **Step 3: Update the first Quickstart install command and add a pip/pipx note**

Use the Edit tool on `README.md`. Match only the single line — the surrounding fenced code block stays as-is.

`old_string` (one line, exactly):

```
uv tool install das-cli
```

`new_string` (one line, exactly):

```
uv tool install das-layer   # or: pip install das-layer / pipx install das-layer
```

Note: `replace_all` must stay `false` here. The other `uv tool install das-cli` invocation in the SQL-source example includes the `--with oracledb` suffix and is unique-matched in Step 4, so this match is already unique.

- [ ] **Step 4: Update the SQL-source install command**

Use the Edit tool on `README.md`.

`old_string`:

```
uv tool install das-cli --with oracledb       # or --with pyodbc
```

`new_string`:

```
uv tool install das-layer --with oracledb     # or --with pyodbc
```

- [ ] **Step 5: Verify no stale `das-cli` PyPI references remain**

Run:

```bash
grep -n "pypi.org/project/das-cli\|install das-cli\|/das-cli.svg" README.md
```

Expected: no matches (exit code 1). If anything prints, fix it before committing.

- [ ] **Step 6: Verify the kept `das-cli` references are still correct**

Run:

```bash
grep -n "das-cli" README.md
```

Expected: only references to the GitHub repo (`mattiasthalen/das-cli`), the README title (`# das-cli`), and CI badge URLs. None of these change.

- [ ] **Step 7: Commit**

```bash
git add README.md
git commit -m "docs(readme): rename PyPI distribution to das-layer + note pip/pipx install"
```

---

## Task 7: Open the PR and document the one-time PyPI bootstrap

This task does not modify code. It captures the manual steps the maintainer must perform around merge.

- [ ] **Step 1: Push the branch and open a PR**

Run:

```bash
git push -u origin HEAD
gh pr create --title "Tag-based releases via hatch-vcs and PyPI OIDC" --body "$(cat <<'EOF'
## Summary
- Switches the PyPI distribution name from `das-cli` (taken by an unrelated active project) to `das-layer`.
- Adds tag-driven release pipeline: push `vX.Y.Z` → GitHub Actions builds with `uv`, derives version from the tag via `hatch-vcs`, publishes to PyPI via OIDC trusted publishing, and cuts a GitHub Release with auto-generated notes.
- ADR-0026 captures the decision and alternatives.

Spec: `docs/superpowers/specs/2026-05-19-tag-based-releases-design.md`
Plan: `docs/superpowers/plans/2026-05-19-tag-based-releases.md`

## Test plan
- [ ] CI passes on this branch (lint + test).
- [ ] After merge: register a **pending publisher** on pypi.org for `das-layer` pointing at `mattiasthalen/das-cli`, workflow filename `release.yml`, environment blank. (Account → Your projects → "Manage" any account, or "Publishing" → "Add a new pending publisher".)
- [ ] After merge + PyPI bootstrap: tag `v0.1.0` on `main` and push. Confirm the workflow:
  - builds `das_layer-0.1.0-py3-none-any.whl` + `das_layer-0.1.0.tar.gz`,
  - publishes to https://pypi.org/project/das-layer/,
  - creates GitHub Release `v0.1.0` with auto-generated notes and both `dist/` files attached.
- [ ] In a clean shell: `uv tool install das-layer` and `pip install das-layer` both produce a working `das --help` and a `das --version` of `0.1.0`.

🤖 Generated with [Claude Code](https://claude.com/claude-code)
EOF
)"
```

Expected: PR URL printed. Return that URL to the user.

- [ ] **Step 2: Surface the one-time PyPI bootstrap to the user**

The PyPI side of trusted publishing must be configured **before** the first tag is pushed, or `pypa/gh-action-pypi-publish` will fail with a 401/403. Tell the user to do this before tagging `v0.1.0`:

1. Sign in at https://pypi.org/.
2. Navigate to **Account → Publishing → Add a new pending publisher**.
3. Fill in:
   - **PyPI Project Name:** `das-layer`
   - **Owner:** `mattiasthalen`
   - **Repository name:** `das-cli`
   - **Workflow name:** `release.yml`
   - **Environment name:** *(leave blank)*
4. Save. After the first publish, the pending publisher promotes to a regular trusted publisher automatically.

No tokens or secrets need to be added to the GitHub repo.

- [ ] **Step 3: Stop here**

The first real `v0.1.0` tag is the end-to-end acceptance test described in the spec. It happens **after** this PR merges and **after** the PyPI bootstrap is done — not as part of this implementation. Hand off to the maintainer once the PR is open and the bootstrap instructions are surfaced.

---

## Verification checklist (run from a clean tree after Task 6 commits, before opening the PR)

- [ ] `git status` shows a clean tree with no untracked files.
- [ ] `git log --oneline -10` shows the six task commits in order: ADR, pyproject, __init__, release.yml, README. (Task 4 has no commit.)
- [ ] `uv run pytest tests/unit tests/integration -q` passes.
- [ ] `uv run das --version` prints a `0.0.0`-prefixed version (no tag on this branch).
- [ ] `grep -rn '"0.1.0"' src/das_cli/ | grep -v bootstrap/` returns nothing — no stray hardcoded `0.1.0` outside the bootstrap-contract files we deliberately left alone.
- [ ] `head -1 docs/adrs/0*.md | tail -10` shows `0026` with the title matching its index row in `docs/adrs/README.md`.
