# Progress Bars Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add Rich-based per-resource progress bars to `das extract` and `das load`, with mode-aware behavior for `--quiet`, `--verbose`, TTY default, and non-TTY default.

**Architecture:** A single new module `src/das_cli/progress.py` owns a `progress(...)` context manager and three renderer implementations (Rich, plain, silent). The pipeline runners gain optional `progress_handle` / `dlt_progress` parameters; the CLI layer resolves mode from flags and passes through. Resource generators are wrapped at the call site in the pipelines — no changes to `dlt_glue/source_factory.py` internals.

**Tech Stack:** Python 3.12, `rich.progress` (already a dependency), Typer (already used), pytest with Typer's `CliRunner`. dlt's `progress=` parameter accepts `"log"` or `None`; we already use `"log"` today.

**Spec:** `docs/superpowers/specs/2026-05-06-progress-bars-design.md`

---

## File map

| File | Action | Purpose |
|------|--------|---------|
| `src/das_cli/progress.py` | create | Renderers + `progress()` context manager + `ProgressHandle` |
| `src/das_cli/pipelines/extract.py` | modify | Accept `progress_handle` / `dlt_progress`; wrap generators |
| `src/das_cli/pipelines/load.py` | modify | Accept `progress_handle` / `dlt_progress`; pre-count + wrap |
| `src/das_cli/cli.py` | modify | Resolve mode from flags; build handle; pass into runners |
| `tests/unit/test_progress.py` | create | Renderer + wrapper unit tests |
| `tests/integration/test_extract_pipeline.py` | modify | Assert plain-mode and silent-mode behavior |
| `tests/integration/test_load_pipeline.py` | modify | Assert plain-mode and silent-mode behavior |

---

## Task 1: Mode resolution helper

A pure function that maps `(quiet, verbose, isatty)` to `(mode, dlt_progress)`. Lives in `progress.py` from the start so tests can import it without touching CLI machinery.

**Files:**
- Create: `src/das_cli/progress.py`
- Test: `tests/unit/test_progress.py`

- [ ] **Step 1: Write the failing test**

Create `tests/unit/test_progress.py`:

```python
"""Tests for the progress module."""

from __future__ import annotations

from das_cli.progress import resolve_mode


def test_quiet_wins_over_verbose() -> None:
    assert resolve_mode(quiet=True, verbose=True, isatty=True) == ("silent", None)


def test_quiet_silences_progress_and_dlt() -> None:
    assert resolve_mode(quiet=True, verbose=False, isatty=True) == ("silent", None)
    assert resolve_mode(quiet=True, verbose=False, isatty=False) == ("silent", None)


def test_verbose_disables_rich_keeps_dlt_log() -> None:
    assert resolve_mode(quiet=False, verbose=True, isatty=True) == (None, "log")
    assert resolve_mode(quiet=False, verbose=True, isatty=False) == (None, "log")


def test_default_tty_uses_rich() -> None:
    assert resolve_mode(quiet=False, verbose=False, isatty=True) == ("rich", None)


def test_default_non_tty_uses_plain() -> None:
    assert resolve_mode(quiet=False, verbose=False, isatty=False) == ("plain", None)
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/unit/test_progress.py -v`
Expected: FAIL with `ModuleNotFoundError: No module named 'das_cli.progress'`

- [ ] **Step 3: Write minimal implementation**

Create `src/das_cli/progress.py`:

```python
"""Live progress display for long-running pipelines.

See docs/superpowers/specs/2026-05-06-progress-bars-design.md.
"""

from __future__ import annotations

from typing import Literal

Mode = Literal["rich", "plain", "silent"]


def resolve_mode(
    *, quiet: bool, verbose: bool, isatty: bool
) -> tuple[Mode | None, str | None]:
    """Resolve (progress_mode, dlt_progress) from CLI flags + TTY status.

    Returns (mode, dlt_progress) where:
    - mode is "silent"|"rich"|"plain"|None — None means "no Rich progress at all"
      (verbose mode falls into this; dlt's own log output takes over).
    - dlt_progress is the value to pass to dlt.pipeline(progress=...).
    """
    if quiet:
        return "silent", None
    if verbose:
        return None, "log"
    return ("rich" if isatty else "plain"), None
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/unit/test_progress.py -v`
Expected: PASS, 5 tests

- [ ] **Step 5: Commit**

```bash
git add src/das_cli/progress.py tests/unit/test_progress.py
git commit -m "feat(progress): add resolve_mode helper for CLI flag resolution"
```

---

## Task 2: SilentRenderer + progress() context manager skeleton

Establish the public surface: `progress(resources, *, mode)` context manager, `ProgressHandle` with `wrap()` and `fail()`, and the simplest renderer (silent = pass-through).

**Files:**
- Modify: `src/das_cli/progress.py`
- Test: `tests/unit/test_progress.py`

- [ ] **Step 1: Write the failing tests**

Append to `tests/unit/test_progress.py`:

```python
from das_cli.progress import progress


def test_silent_progress_is_passthrough() -> None:
    items = [1, 2, 3, 4, 5]
    with progress(["a"], mode="silent") as h:
        out = list(h.wrap("a", iter(items)))
    assert out == items


def test_silent_progress_handles_multiple_resources() -> None:
    with progress(["a", "b"], mode="silent") as h:
        a = list(h.wrap("a", iter([1, 2])))
        b = list(h.wrap("b", iter([3, 4, 5])))
    assert a == [1, 2]
    assert b == [3, 4, 5]


def test_silent_progress_accepts_total_mapping() -> None:
    """Mapping form (used by load) should also work in silent mode."""
    with progress({"a": 100, "b": 50}, mode="silent") as h:
        out = list(h.wrap("a", iter([1, 2, 3])))
    assert out == [1, 2, 3]


def test_silent_wrap_propagates_exceptions() -> None:
    def boom() -> object:
        yield 1
        raise RuntimeError("fail")

    with progress(["a"], mode="silent") as h:
        gen = h.wrap("a", boom())
        assert next(gen) == 1
        try:
            next(gen)
        except RuntimeError as e:
            assert str(e) == "fail"
        else:
            raise AssertionError("expected RuntimeError")
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/unit/test_progress.py -v`
Expected: 4 FAIL with `ImportError: cannot import name 'progress'`

- [ ] **Step 3: Implement**

Replace the body of `src/das_cli/progress.py` with:

```python
"""Live progress display for long-running pipelines.

See docs/superpowers/specs/2026-05-06-progress-bars-design.md.
"""

from __future__ import annotations

from collections.abc import Iterable, Iterator, Mapping, Sequence
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Literal, Protocol, TypeVar

T = TypeVar("T")

Mode = Literal["rich", "plain", "silent"]


def resolve_mode(
    *, quiet: bool, verbose: bool, isatty: bool
) -> tuple[Mode | None, str | None]:
    if quiet:
        return "silent", None
    if verbose:
        return None, "log"
    return ("rich" if isatty else "plain"), None


class _Renderer(Protocol):
    def start(self, name: str) -> None: ...
    def tick(self, name: str, n: int) -> None: ...
    def done(self, name: str, n: int) -> None: ...
    def fail(self, name: str, n: int, exc: BaseException) -> None: ...
    def close(self) -> None: ...


class _SilentRenderer:
    def start(self, name: str) -> None: ...
    def tick(self, name: str, n: int) -> None: ...
    def done(self, name: str, n: int) -> None: ...
    def fail(self, name: str, n: int, exc: BaseException) -> None: ...
    def close(self) -> None: ...


@dataclass
class ProgressHandle:
    _renderer: _Renderer

    def wrap(self, name: str, it: Iterable[T]) -> Iterator[T]:
        self._renderer.start(name)
        n = 0
        try:
            for item in it:
                yield item
                n += 1
                self._renderer.tick(name, n)
            self._renderer.done(name, n)
        except BaseException as exc:
            self._renderer.fail(name, n, exc)
            raise

    def fail(self, name: str, exc: BaseException) -> None:
        """Mark a resource failed without iterating (for caller-driven failures)."""
        self._renderer.fail(name, 0, exc)


def _resource_names(
    resources: Sequence[str] | Mapping[str, int],
) -> list[str]:
    if isinstance(resources, Mapping):
        return list(resources.keys())
    return list(resources)


def _resource_totals(
    resources: Sequence[str] | Mapping[str, int],
) -> dict[str, int | None]:
    if isinstance(resources, Mapping):
        return dict(resources)
    return {name: None for name in resources}


@contextmanager
def progress(
    resources: Sequence[str] | Mapping[str, int],
    *,
    mode: Mode,
) -> Iterator[ProgressHandle]:
    """Open a progress display for a sequence of resources.

    `resources` may be a list of names (totals unknown — extract) or a mapping
    of name → row count (totals known — load).
    """
    renderer: _Renderer
    if mode == "silent":
        renderer = _SilentRenderer()
    else:
        # Rich and Plain renderers added in later tasks.
        raise NotImplementedError(f"mode={mode!r} not yet implemented")

    try:
        yield ProgressHandle(_renderer=renderer)
    finally:
        renderer.close()
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/unit/test_progress.py -v`
Expected: PASS, 9 tests total (5 from Task 1 + 4 new)

- [ ] **Step 5: Commit**

```bash
git add src/das_cli/progress.py tests/unit/test_progress.py
git commit -m "feat(progress): add ProgressHandle, silent renderer, context manager"
```

---

## Task 3: PlainRenderer

Non-TTY mode: writes per-resource start/finish lines via `output.info` and `output.warn`. No animation.

**Files:**
- Modify: `src/das_cli/progress.py`
- Test: `tests/unit/test_progress.py`

- [ ] **Step 1: Write the failing tests**

Append to `tests/unit/test_progress.py`:

```python
import pytest


def test_plain_writes_start_and_finish_lines(capsys: pytest.CaptureFixture[str]) -> None:
    with progress(["customers"], mode="plain") as h:
        out = list(h.wrap("customers", iter([{"x": 1}, {"x": 2}, {"x": 3}])))
    assert out == [{"x": 1}, {"x": 2}, {"x": 3}]
    captured = capsys.readouterr()
    text = captured.out + captured.err
    assert "customers: started" in text
    assert "customers: 3 rows" in text


def test_plain_writes_failure_line_on_exception(capsys: pytest.CaptureFixture[str]) -> None:
    def boom() -> object:
        yield {"x": 1}
        raise RuntimeError("boom")

    with pytest.raises(RuntimeError, match="boom"):
        with progress(["orders"], mode="plain") as h:
            list(h.wrap("orders", boom()))
    captured = capsys.readouterr()
    text = captured.out + captured.err
    assert "orders: started" in text
    assert "orders: FAILED after 1 rows" in text


def test_plain_handles_multiple_resources_in_sequence(
    capsys: pytest.CaptureFixture[str],
) -> None:
    with progress(["a", "b"], mode="plain") as h:
        list(h.wrap("a", iter([1])))
        list(h.wrap("b", iter([1, 2])))
    text = capsys.readouterr().out + capsys.readouterr().err
    # Each name appears once for "started" and once for "N rows"
    # (capsys was already drained — recapture)


def test_plain_does_not_emit_per_record_lines(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """Sanity: plain mode is start/finish only, no per-tick output."""
    with progress(["x"], mode="plain") as h:
        list(h.wrap("x", iter(range(50))))
    text = capsys.readouterr().out + capsys.readouterr().err
    # Exactly two relevant lines: "started" and "50 rows".
    started = text.count("x: started")
    finished = text.count("x: 50 rows")
    assert started == 1
    assert finished == 1
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/unit/test_progress.py -v`
Expected: FAIL on the new tests with `NotImplementedError: mode='plain' not yet implemented`

- [ ] **Step 3: Implement**

In `src/das_cli/progress.py`, add the renderer class above the `progress()` context manager:

```python
from das_cli import output


class _PlainRenderer:
    """Writes per-resource start/finish lines. Used for non-TTY stdout."""

    def __init__(self) -> None:
        self._started: set[str] = set()

    def start(self, name: str) -> None:
        if name in self._started:
            return
        self._started.add(name)
        output.info(f"{name}: started")

    def tick(self, name: str, n: int) -> None:
        # Plain mode: no per-tick output.
        return

    def done(self, name: str, n: int) -> None:
        output.info(f"{name}: {n} rows")

    def fail(self, name: str, n: int, exc: BaseException) -> None:
        output.warn(f"{name}: FAILED after {n} rows")

    def close(self) -> None:
        return
```

Update the `progress()` context manager dispatch:

```python
    if mode == "silent":
        renderer = _SilentRenderer()
    elif mode == "plain":
        renderer = _PlainRenderer()
    else:
        # Rich renderer added in next task.
        raise NotImplementedError(f"mode={mode!r} not yet implemented")
```

Note: `start()` guards against double-start because the wrapper's first iteration calls it before the first yield, but defensive code is cheap and the test for sequence behavior depends on the contract that `start` is idempotent.

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/unit/test_progress.py -v`
Expected: PASS, 13 tests total

- [ ] **Step 5: Commit**

```bash
git add src/das_cli/progress.py tests/unit/test_progress.py
git commit -m "feat(progress): add plain renderer for non-TTY stdout"
```

---

## Task 4: RichRenderer

The animated TTY renderer. Tests are minimal — Rich's animated output is not asserted on; we test that construction works, `wrap()` is iterable-equivalent, and the renderer is closed cleanly.

**Files:**
- Modify: `src/das_cli/progress.py`
- Test: `tests/unit/test_progress.py`

- [ ] **Step 1: Write the failing tests**

Append to `tests/unit/test_progress.py`:

```python
def test_rich_wrap_yields_all_items() -> None:
    items = list(range(20))
    with progress(["x"], mode="rich") as h:
        out = list(h.wrap("x", iter(items)))
    assert out == items


def test_rich_with_total_mapping_yields_all_items() -> None:
    items = list(range(7))
    with progress({"x": len(items)}, mode="rich") as h:
        out = list(h.wrap("x", iter(items)))
    assert out == items


def test_rich_propagates_exceptions() -> None:
    def boom() -> object:
        yield 1
        raise RuntimeError("nope")

    with pytest.raises(RuntimeError, match="nope"):
        with progress(["a"], mode="rich") as h:
            list(h.wrap("a", boom()))
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/unit/test_progress.py -v`
Expected: FAIL on the 3 new tests with `NotImplementedError`

- [ ] **Step 3: Implement**

Add to `src/das_cli/progress.py` above the `progress()` context manager:

```python
from rich.console import Console
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress as RichProgress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
    TimeRemainingColumn,
)


class _RichRenderer:
    """Live stacked progress panel for TTY stdout."""

    def __init__(self, totals: dict[str, int | None]) -> None:
        self._totals = totals
        any_total = any(t is not None for t in totals.values())
        columns: list = [
            SpinnerColumn(),
            TextColumn("{task.description}"),
            MofNCompleteColumn(),
            TimeElapsedColumn(),
        ]
        if any_total:
            columns.insert(3, BarColumn())
            columns.append(TimeRemainingColumn())
        self._progress = RichProgress(
            *columns,
            console=Console(),
            transient=False,
        )
        self._progress.start()
        self._tasks: dict[str, int] = {}
        for name, total in totals.items():
            task_id = self._progress.add_task(
                description=name,
                total=total,
                start=False,
            )
            self._tasks[name] = task_id

    def start(self, name: str) -> None:
        task_id = self._tasks[name]
        # `start_task` is idempotent in rich; no need to guard.
        self._progress.start_task(task_id)

    def tick(self, name: str, n: int) -> None:
        task_id = self._tasks[name]
        self._progress.update(task_id, completed=n)

    def done(self, name: str, n: int) -> None:
        task_id = self._tasks[name]
        # When total was unknown, set total=n so the line shows "n/n".
        if self._totals.get(name) is None:
            self._progress.update(task_id, total=n, completed=n)
        else:
            self._progress.update(task_id, completed=n)
        self._progress.stop_task(task_id)

    def fail(self, name: str, n: int, exc: BaseException) -> None:
        task_id = self._tasks[name]
        self._progress.update(
            task_id,
            description=f"[red]✗[/] {name} (error after {n} rows)",
        )
        self._progress.stop_task(task_id)

    def close(self) -> None:
        self._progress.stop()
```

Update `progress()` dispatch:

```python
    if mode == "silent":
        renderer = _SilentRenderer()
    elif mode == "plain":
        renderer = _PlainRenderer()
    elif mode == "rich":
        renderer = _RichRenderer(_resource_totals(resources))
    else:
        raise ValueError(f"unknown mode: {mode!r}")
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/unit/test_progress.py -v`
Expected: PASS, 16 tests total

- [ ] **Step 5: Visual smoke test**

Run a quick interactive sanity check (this is for the human, optional in CI):

```python
# python -c '...' or paste in a REPL:
import time
from das_cli.progress import progress

with progress({"customers": 10, "orders": 5}, mode="rich") as h:
    for i in h.wrap("customers", range(10)):
        time.sleep(0.05)
    for i in h.wrap("orders", range(5)):
        time.sleep(0.05)
```

Expected: stacked panel with two lines, both progressing to "n/n" with elapsed time and ETA bar. No assertion, just visual confirmation.

- [ ] **Step 6: Commit**

```bash
git add src/das_cli/progress.py tests/unit/test_progress.py
git commit -m "feat(progress): add rich renderer for TTY stdout"
```

---

## Task 5: Integrate into `run_extract`

Add `progress_handle` and `dlt_progress` keyword-only parameters. Wrap each generator. Replace hard-coded `progress="log"` on `dlt.pipeline()`.

**Files:**
- Modify: `src/das_cli/pipelines/extract.py`
- Test: `tests/integration/test_extract_pipeline.py`

- [ ] **Step 1: Read the current extract.py**

Read `src/das_cli/pipelines/extract.py` end-to-end. The hot spots are:
- The `dlt.pipeline(...)` call — does **not** currently pass `progress=`. Today `progress="log"` is the dlt default, but the spec says we want to silence dlt by default and only enable `"log"` under `--verbose`. We'll explicitly pass `progress=dlt_progress` (which is `None` in the default case).
- The `pipeline.run(resources, ...)` line — `resources` here is a list of dlt resource objects. Wrapping happens at the dlt-resource boundary: each resource's underlying generator must be wrapped before dlt iterates it.

**Wrapping strategy:** dlt resources are already callables (`@dlt.resource`-decorated). When dlt iterates them, it calls the inner `_gen()`. We can't easily intercept that without rebuilding the resource. Instead, we wrap by constructing a **new** dlt resource that yields-from the wrapped iterator of the original. Use `dlt.resource(name=...)` as a thin proxy.

Actually simpler: each resource object exposes its name via `.name`. We re-wrap by replacing each `resource` with a new resource that delegates iteration through the handle's `wrap`. The cleanest pattern is:

```python
def _wrapped_resource(orig, handle, name):
    @dlt.resource(name=name)
    def _w():
        yield from handle.wrap(name, orig())
    return _w
```

But this loses dlt config (write_disposition, columns, primary_key, schema_contract) attached to `orig`. Cleaner approach: leave the dlt resource shape unchanged, and instead add the wrapper **inside** `build_extract_resources` is what the spec rejected. The least-invasive approach is:

Look at `build_extract_resources` — each dlt resource has its inner `_gen()` defined via decorator. We can pre-wrap by composition: wrap the *raw* iterator inside `_gen`, and pass the handle in. But that re-couples source_factory to progress.

**Decision:** Don't wrap at the dlt-resource level. Wrap **after** `pipeline.run()` is not possible (dlt has already iterated). Instead, change `_make_odata_resource` and analogous builders to optionally accept a `progress_handle`/`name` pair and wrap the inner yield:

```python
def _gen():
    ...
    source = _raw_items()
    if limit is not None:
        source = _limit_gen(source, limit)
    if progress_handle is not None:
        source = progress_handle.wrap(resource_name, source)
    yield from source
```

This keeps the dlt resource shape intact (all dlt config preserved) and adds three lines per builder. The cost: `source_factory.py` now imports `ProgressHandle`. That coupling is acceptable: progress is a cross-cutting concern that legitimately belongs at this seam.

- [ ] **Step 2: Write the failing test**

Append to `tests/integration/test_extract_pipeline.py` (after existing imports — preserve them):

```python
def test_extract_plain_mode_emits_per_resource_lines(
    workspace: Path, cli_runner: CliRunner, capsys: pytest.CaptureFixture[str]
) -> None:
    """Non-TTY default: per-resource start/finish lines."""
    import sys

    from das_cli.pipelines.extract import run_extract
    from das_cli.progress import progress

    _setup(workspace, cli_runner)
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.GET,
            "https://example.com/odata/v1/Products",
            json=PRODUCTS_RESPONSE,
            status=200,
        )
        with progress(["products"], mode="plain") as h:
            run_extract(
                source_name="x",
                config_path=workspace / "das.yaml",
                progress_handle=h,
                dlt_progress=None,
            )
    out = capsys.readouterr().out
    assert "products: started" in out
    assert "products: 2 rows" in out
```

Add `import pytest` at the top of the file if not already present.

- [ ] **Step 3: Run test to verify it fails**

Run: `uv run pytest tests/integration/test_extract_pipeline.py::test_extract_plain_mode_emits_per_resource_lines -v`
Expected: FAIL — `run_extract()` got an unexpected keyword argument 'progress_handle'

- [ ] **Step 4: Implement — extend source_factory.py**

In `src/das_cli/dlt_glue/source_factory.py`, modify `_make_odata_resource` to accept an optional progress handle and wrap inside `_gen`:

```python
from das_cli.progress import ProgressHandle  # add at top

def _make_odata_resource(
    *,
    base_url: str,
    path: str,
    resource_name: str,
    cursor_field: str | None,
    headers: dict[str, str],
    limit: int | None = None,
    progress_handle: ProgressHandle | None = None,  # NEW
) -> Any:
    @dlt.resource(...)
    def _gen() -> Iterator[dict[str, Any]]:
        client = RESTClient(base_url=base_url, headers=headers)
        paginator: BasePaginator = JSONLinkPaginator(
            next_url_path="@odata.nextLink",
        )

        def _raw_items() -> Iterator[dict[str, Any]]:
            for page in client.paginate(...):
                for item in page:
                    yield {"_data": item}

        source = _raw_items()
        if limit is not None:
            source = _limit_gen(source, limit)
        if progress_handle is not None:
            source = progress_handle.wrap(resource_name, source)
        yield from source

    return _gen
```

(Keep the existing `client.paginate(...)` arguments — only the `source = _raw_items()` and following lines change.)

Modify `_build_odata_resources` and `build_extract_resources` to thread `progress_handle` through:

```python
def _build_odata_resources(
    scfg: SourceConfig,
    contracts: list[LoadedContract],
    *,
    source_name: str,
    limit: int | None = None,
    progress_handle: ProgressHandle | None = None,  # NEW
) -> list[Any]:
    base_url = scfg.endpoint.rstrip("/")
    headers = _auth_headers(scfg)
    out: list[Any] = []
    for contract in contracts:
        path = _odata_path_for(contract)
        resource = _make_odata_resource(
            base_url=base_url,
            path=path,
            resource_name=contract.resource_name,
            cursor_field=get_das_value(contract.contract.custom_properties, "das.cursor"),
            headers=headers,
            limit=limit,
            progress_handle=progress_handle,
        )
        out.append(resource)
    return out


def build_extract_resources(
    scfg: SourceConfig,
    contracts: list[LoadedContract],
    *,
    source_name: str,
    limit: int | None = None,
    progress_handle: ProgressHandle | None = None,  # NEW
) -> list[Any]:
    if scfg.type == "odata":
        return _build_odata_resources(
            scfg, contracts, source_name=source_name, limit=limit,
            progress_handle=progress_handle,
        )
    if scfg.type in {"openapi", "rest"}:
        return _build_odata_resources(
            scfg, contracts, source_name=source_name, limit=limit,
            progress_handle=progress_handle,
        )
    raise UnknownSourceTypeError(f"No P1 builder for source type '{scfg.type}'")
```

- [ ] **Step 5: Implement — extend extract.py**

In `src/das_cli/pipelines/extract.py`:

```python
from das_cli.progress import ProgressHandle  # add at top

def run_extract(
    *,
    source_name: str,
    config_path: Path | str,
    only_resources: list[str] | None = None,
    limit: int | None = None,
    progress_handle: ProgressHandle | None = None,  # NEW
    dlt_progress: str | None = None,                 # NEW
) -> dict[str, Any]:
    cfg = load_das_config(config_path)
    contracts_root = (Path(config_path).parent / cfg.contracts.root).resolve()
    src_dir = contracts_root / source_name
    if not src_dir.is_dir():
        raise FileNotFoundError(f"Source '{source_name}' not found at {src_dir}")

    scfg = load_source_config(src_dir / "_source.yml")
    contracts = load_source_contracts(src_dir)

    if only_resources:
        wanted = set(only_resources)
        contracts = [c for c in contracts if c.resource_name in wanted]
    if not contracts:
        return {"resources": {}, "total_rows": 0}

    resources = build_extract_resources(
        scfg, contracts, source_name=source_name, limit=limit,
        progress_handle=progress_handle,
    )

    bucket_url = cfg.landing.bucket_url.rstrip("/")
    pipeline = dlt.pipeline(
        pipeline_name=f"das_extract__{source_name}",
        destination=dlt.destinations.filesystem(
            bucket_url=bucket_url,
            credentials=cfg.landing.credentials or None,
        ),
        dataset_name=source_name,
        pipelines_dir=".dlt/pipelines",
        progress=dlt_progress,  # NEW: was implicit "log"; now opt-in
    )

    pipeline.run(resources, loader_file_format="jsonl")
    # ... (rest of the function unchanged: row counting block)
```

- [ ] **Step 6: Run the new test + the full unit suite**

Run: `uv run pytest tests/integration/test_extract_pipeline.py tests/unit/test_progress.py -v`
Expected: PASS — all tests in both files green.

- [ ] **Step 7: Run the full suite to catch regressions**

Run: `uv run pytest -q`
Expected: PASS — 149 baseline tests + new ones from earlier tasks.

- [ ] **Step 8: Commit**

```bash
git add src/das_cli/dlt_glue/source_factory.py src/das_cli/pipelines/extract.py tests/integration/test_extract_pipeline.py
git commit -m "feat(extract): integrate progress wrapper and dlt_progress override"
```

---

## Task 6: Pre-count helper for load

Pure helper that counts JSONL lines per resource. Shared between unit test and `run_load`.

**Files:**
- Modify: `src/das_cli/pipelines/load.py`
- Test: `tests/unit/test_load_precount.py` (new)

- [ ] **Step 1: Write the failing test**

Create `tests/unit/test_load_precount.py`:

```python
"""Tests for the load pre-count helper."""

from __future__ import annotations

import gzip
from pathlib import Path

import pytest

from das_cli.pipelines.load import count_landing_rows


def test_counts_plain_jsonl(tmp_path: Path) -> None:
    rdir = tmp_path / "products"
    rdir.mkdir()
    (rdir / "a.jsonl").write_text('{"x":1}\n{"x":2}\n{"x":3}\n')
    assert count_landing_rows(rdir) == 3


def test_counts_gzipped_jsonl(tmp_path: Path) -> None:
    rdir = tmp_path / "orders"
    rdir.mkdir()
    with gzip.open(rdir / "a.jsonl.gz", "wt") as fh:
        fh.write('{"x":1}\n{"x":2}\n')
    assert count_landing_rows(rdir) == 2


def test_counts_across_multiple_files(tmp_path: Path) -> None:
    rdir = tmp_path / "customers"
    rdir.mkdir()
    (rdir / "a.jsonl").write_text('{"x":1}\n{"x":2}\n')
    with gzip.open(rdir / "b.jsonl.gz", "wt") as fh:
        fh.write('{"x":3}\n')
    assert count_landing_rows(rdir) == 3


def test_skips_blank_lines(tmp_path: Path) -> None:
    rdir = tmp_path / "x"
    rdir.mkdir()
    (rdir / "a.jsonl").write_text('{"x":1}\n\n{"x":2}\n\n')
    assert count_landing_rows(rdir) == 2


def test_returns_zero_for_missing_dir(tmp_path: Path) -> None:
    assert count_landing_rows(tmp_path / "does_not_exist") == 0


def test_returns_zero_for_empty_dir(tmp_path: Path) -> None:
    rdir = tmp_path / "empty"
    rdir.mkdir()
    assert count_landing_rows(rdir) == 0
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/unit/test_load_precount.py -v`
Expected: FAIL — `cannot import name 'count_landing_rows' from 'das_cli.pipelines.load'`

- [ ] **Step 3: Implement**

Add to `src/das_cli/pipelines/load.py` (above `_iter_landing` is a good spot):

```python
def count_landing_rows(landing_dir: Path) -> int:
    """Count newline-delimited records across all *.jsonl[.gz] files in landing_dir.

    Skips blank lines. Returns 0 if the directory is missing or empty. No JSON
    parsing — purely a line count.
    """
    if not landing_dir.exists():
        return 0
    total = 0
    for f in landing_dir.rglob("*.jsonl*"):
        opener = gzip.open if f.suffix == ".gz" else open
        with opener(f, "rt", encoding="utf-8") as fh:
            for line in fh:
                if line.strip():
                    total += 1
    return total
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/unit/test_load_precount.py -v`
Expected: PASS, 6 tests

- [ ] **Step 5: Commit**

```bash
git add src/das_cli/pipelines/load.py tests/unit/test_load_precount.py
git commit -m "feat(load): add count_landing_rows helper for progress totals"
```

---

## Task 7: Integrate into `run_load`

Wire `progress_handle` and `dlt_progress` into `run_load`. Wrap the projected iterator inside `_build_load_resource`.

**Files:**
- Modify: `src/das_cli/pipelines/load.py`
- Test: `tests/integration/test_load_pipeline.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/integration/test_load_pipeline.py`:

```python
def test_load_plain_mode_emits_per_resource_lines(
    workspace: Path, cli_runner: CliRunner, capsys: pytest.CaptureFixture[str]
) -> None:
    """Plain mode for load: per-resource start/finish lines."""
    from das_cli.pipelines.load import run_load
    from das_cli.progress import progress

    # Reuse the existing setup helper that lays down a contract + landing data.
    _setup_workspace_with_landing(workspace, cli_runner)

    with progress({"products": 2}, mode="plain") as h:
        run_load(
            config_path=workspace / "das.yaml",
            progress_handle=h,
            dlt_progress=None,
        )
    out = capsys.readouterr().out
    assert "products: started" in out
    # Note: the wrapped count reflects rows that flow through change-detection.
    # On first load with no previous hash, all rows pass — so count == 2.
    assert "products: 2 rows" in out
```

If a `_setup_workspace_with_landing` helper does not already exist in the test file, add a minimal one:

```python
def _setup_workspace_with_landing(workspace: Path, runner: CliRunner) -> None:
    """Create a workspace with one contract + one landing JSONL file (2 rows)."""
    runner.invoke(app, ["init"])
    contracts = workspace / "contracts" / "x"
    contracts.mkdir(parents=True, exist_ok=True)
    (contracts / "_source.yml").write_text(SOURCE_YML)
    (contracts / "products.odcs.yaml").write_text(CONTRACT)
    landing = workspace / "landing" / "x" / "products"
    landing.mkdir(parents=True, exist_ok=True)
    (landing / "data.jsonl").write_text(
        '{"_data": {"ProductId": 1, "Name": "A"}}\n'
        '{"_data": {"ProductId": 2, "Name": "B"}}\n'
    )
```

(Inspect the existing test file for SOURCE_YML and CONTRACT — they should already be defined as module-level strings. If named differently, adapt.)

Add `import pytest` at the top of the file if missing.

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/integration/test_load_pipeline.py::test_load_plain_mode_emits_per_resource_lines -v`
Expected: FAIL — `run_load() got an unexpected keyword argument 'progress_handle'`

- [ ] **Step 3: Implement**

In `src/das_cli/pipelines/load.py`:

```python
from das_cli.progress import ProgressHandle  # add at top

def _build_load_resource(
    contract: LoadedContract,
    *,
    landing_dir: Path,
    hash_exclude: set[str],
    primary_key: list[str],
    db_path: str,
    dataset: str,
    schema_contract: dict[str, str],
    progress_handle: ProgressHandle | None = None,  # NEW
) -> Any:
    cols = build_dlt_columns(contract.contract)
    table_name: str = contract.contract.primary_schema.physicalName or contract.resource_name

    @dlt.resource(...)  # unchanged decorator args
    def _gen() -> Iterator[dict[str, Any]]:
        if primary_key:
            latest = load_latest_hash_from_duckdb(...)
            change_filter: ChangeDetectionFilter | None = ChangeDetectionFilter(
                primary_key=primary_key, latest_hash=latest
            )
        else:
            change_filter = None

        def _projected_iter() -> Iterator[dict[str, Any]]:
            for line in _iter_landing(landing_dir):
                raw = line.get("_data", line)
                projected = _project_record(raw, contract)
                projected["_row_hash"] = compute_row_hash(raw, exclude=hash_exclude)
                yield projected

        if change_filter is None:
            stream = _projected_iter()
        else:
            stream = change_filter(_projected_iter())

        # Wrap *after* change-detection: counter reflects rows reaching dlt.
        if progress_handle is not None:
            stream = progress_handle.wrap(table_name, stream)
        yield from stream

    return _gen


def run_load(
    *,
    config_path: Path | str,
    only_source: str | None = None,
    only_resources: list[str] | None = None,
    progress_handle: ProgressHandle | None = None,  # NEW
    dlt_progress: str | None = None,                 # NEW
) -> dict[str, Any]:
    cfg = load_das_config(config_path)
    contracts_root = (Path(config_path).parent / cfg.contracts.root).resolve()
    sources = discover_sources(contracts_root)

    if only_source:
        sources = [s for s in sources if s.name == only_source]
        if not sources:
            raise FileNotFoundError(f"Source '{only_source}' not found")

    db_path = cfg.target.credentials.get("database", "./das.duckdb")

    pipeline = dlt.pipeline(
        pipeline_name="das_load",
        destination=dlt.destinations.duckdb(
            credentials=db_path,
            enable_dataset_name_normalization=False,
        ),
        pipelines_dir=".dlt/pipelines",
        progress=dlt_progress,  # NEW
    )

    summary: dict[str, Any] = {"sources": {}}

    schema_contract: dict[str, str] = {
        "tables": _TABLES_MODE,
        "columns": cfg.defaults.schema_contract.columns,
        "data_type": cfg.defaults.schema_contract.data_type,
    }

    bucket_url = cfg.landing.bucket_url
    if not bucket_url.startswith(("s3://", "gs://", "az://", "file://")):
        landing_root = Path(bucket_url).expanduser()
    else:
        landing_root = Path(bucket_url)

    resources: list[Any] = []
    dataset_per_resource: list[tuple[Any, str]] = []
    for src in sources:
        contracts = load_source_contracts(src.path)
        if only_resources:
            wanted = set(only_resources)
            contracts = [c for c in contracts if c.resource_name in wanted]
        if not contracts:
            continue
        dataset = resolve_dataset_name(src.name, prefix=cfg.dataset.prefix)
        for c in contracts:
            hash_exclude = set(
                get_das_value(c.contract.custom_properties, "das.hash_exclude") or []
            )
            res = _build_load_resource(
                c,
                landing_dir=landing_root / src.name / c.resource_name,
                hash_exclude=hash_exclude,
                primary_key=primary_keys_for(c.contract),
                db_path=db_path,
                dataset=dataset,
                schema_contract=schema_contract,
                progress_handle=progress_handle,  # NEW
            )
            resources.append(res)
            dataset_per_resource.append((res, dataset))

    if not resources:
        return summary

    by_dataset: dict[str, list[Any]] = {}
    for res, ds in dataset_per_resource:
        by_dataset.setdefault(ds, []).append(res)

    for dataset, rs in by_dataset.items():
        pipeline.run(rs, dataset_name=dataset)

    return summary
```

- [ ] **Step 4: Run the new test**

Run: `uv run pytest tests/integration/test_load_pipeline.py::test_load_plain_mode_emits_per_resource_lines -v`
Expected: PASS

- [ ] **Step 5: Run the full suite**

Run: `uv run pytest -q`
Expected: PASS — all tests green.

- [ ] **Step 6: Commit**

```bash
git add src/das_cli/pipelines/load.py tests/integration/test_load_pipeline.py
git commit -m "feat(load): integrate progress wrapper and dlt_progress override"
```

---

## Task 8: Wire into `cli.py`

Resolve mode in `extract`, `load`, `ingest`. Open the progress context manager around the runner call. For load, build the `{table_name: row_count}` total map first.

**Files:**
- Modify: `src/das_cli/cli.py`
- Test: `tests/integration/test_cli_ingest.py` (extend) or new test file `tests/integration/test_cli_progress.py`

- [ ] **Step 1: Write the failing test**

Create `tests/integration/test_cli_progress.py`:

```python
"""End-to-end CLI tests for progress mode resolution."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest
import responses
from typer.testing import CliRunner

from das_cli.cli import app

METADATA = """\
<?xml version="1.0" encoding="UTF-8"?>
<edmx:Edmx xmlns:edmx="http://docs.oasis-open.org/odata/ns/edmx" Version="4.0">
  <edmx:DataServices>
    <Schema xmlns="http://docs.oasis-open.org/odata/ns/edm" Namespace="X.M">
      <EntityType Name="Product">
        <Key><PropertyRef Name="ProductId" /></Key>
        <Property Name="ProductId" Type="Edm.Int32" Nullable="false" />
        <Property Name="Name" Type="Edm.String" Nullable="false" />
      </EntityType>
    </Schema>
  </edmx:DataServices>
</edmx:Edmx>
"""

PRODUCTS_RESPONSE = {
    "value": [
        {"ProductId": 1, "Name": "A"},
        {"ProductId": 2, "Name": "B"},
    ]
}


def _bootstrap(workspace: Path, runner: CliRunner) -> None:
    runner.invoke(app, ["init"])
    runner.invoke(
        app,
        ["source", "add", "x", "--type", "odata", "--url", "https://example.com/odata/v1"],
    )
    with responses.RequestsMock(assert_all_requests_are_fired=False) as rsps:
        rsps.add(
            responses.GET,
            "https://example.com/odata/v1/$metadata",
            body=METADATA,
            status=200,
        )
        runner.invoke(app, ["contract", "bootstrap", "x"])


def test_extract_default_mode_under_pipe_emits_plain_lines(
    workspace: Path, cli_runner: CliRunner
) -> None:
    """CliRunner runs in non-TTY (mix_stderr defaults), so default mode = plain."""
    _bootstrap(workspace, cli_runner)
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.GET,
            "https://example.com/odata/v1/Products",
            json=PRODUCTS_RESPONSE,
            status=200,
        )
        result = cli_runner.invoke(app, ["extract", "x"])
    assert result.exit_code == 0, result.output
    assert "products: started" in result.output
    assert "products: 2 rows" in result.output


def test_extract_quiet_mode_emits_no_progress_lines(
    workspace: Path, cli_runner: CliRunner
) -> None:
    _bootstrap(workspace, cli_runner)
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.GET,
            "https://example.com/odata/v1/Products",
            json=PRODUCTS_RESPONSE,
            status=200,
        )
        result = cli_runner.invoke(app, ["--quiet", "extract", "x"])
    assert result.exit_code == 0, result.output
    assert "products: started" not in result.output
    # Final "extract complete" success line still prints.
    assert "extract complete" in result.output
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/integration/test_cli_progress.py -v`
Expected: FAIL — assertions on `progress: started` lines are not present (CLI doesn't yet open a progress handle).

- [ ] **Step 3: Implement — extract command**

In `src/das_cli/cli.py`, the `extract` function changes around the `run_extract(...)` call:

```python
@app.command()
def extract(
    ctx: typer.Context,
    source: Annotated[str | None, typer.Argument()] = None,
    resource: Annotated[list[str] | None, typer.Option("--resource")] = None,
    full: Annotated[bool, typer.Option("--full", help="Ignore cursor; full reload.")] = False,
    limit: Annotated[int | None, typer.Option("--limit")] = None,
) -> None:
    """P1: pull raw data into ./landing/."""
    import sys

    from das_cli.contracts.loader import discover_sources, load_source_contracts
    from das_cli.exit_codes import OK, PIPELINE_FAILURE, USAGE
    from das_cli.output import die, header, info, success
    from das_cli.pipelines.extract import run_extract
    from das_cli.progress import progress, resolve_mode

    config_path: Path = ctx.obj["config_path"] if ctx.obj else Path("das.yaml")
    contracts_root = config_path.parent / "contracts"
    sources = discover_sources(contracts_root) if source is None else None

    target_sources: list[str]
    if source is None:
        if not sources:
            die("No sources found in contracts/", code=USAGE)
        target_sources = [s.name for s in (sources or [])]
    else:
        target_sources = [source]
        if not (contracts_root / source).is_dir():
            die(f"Source '{source}' not found", code=USAGE)

    only = list(resource) if resource else None
    if full:
        import shutil
        for s in target_sources:
            state_dir = Path(".dlt/pipelines") / f"das_extract__{s}"
            if state_dir.exists():
                shutil.rmtree(state_dir)

    quiet = bool(ctx.obj.get("quiet", False)) if ctx.obj else False
    verbose = bool(ctx.obj.get("verbose", False)) if ctx.obj else False
    mode, dlt_progress = resolve_mode(
        quiet=quiet, verbose=verbose, isatty=sys.stdout.isatty()
    )

    failed = False
    for s in target_sources:
        header("extract", s)
        # Compute the resource list for the progress display.
        src_dir = contracts_root / s
        contracts = load_source_contracts(src_dir)
        if only:
            wanted = set(only)
            contracts = [c for c in contracts if c.resource_name in wanted]
        resource_names = [c.resource_name for c in contracts]

        try:
            if mode is None:
                summary = run_extract(
                    source_name=s, config_path=config_path,
                    only_resources=only, limit=limit,
                    progress_handle=None, dlt_progress=dlt_progress,
                )
            else:
                with progress(resource_names, mode=mode) as h:
                    summary = run_extract(
                        source_name=s, config_path=config_path,
                        only_resources=only, limit=limit,
                        progress_handle=h, dlt_progress=dlt_progress,
                    )
        except Exception as e:
            from das_cli.output import warn
            warn(f"{s}: extract failed: {e}")
            failed = True
            continue
        for rname, count in summary["resources"].items():
            info(f"  {rname}: {count} rows")

    if failed:
        raise typer.Exit(code=PIPELINE_FAILURE)
    success("extract complete")
    raise typer.Exit(code=OK)
```

- [ ] **Step 4: Implement — load command**

```python
@app.command()
def load(
    ctx: typer.Context,
    source: Annotated[str | None, typer.Argument()] = None,
    resource: Annotated[list[str] | None, typer.Option("--resource")] = None,
) -> None:
    """P2: load ./landing/ → DuckDB with contract enforcement."""
    import sys

    from das_cli.config import load_das_config
    from das_cli.contracts.loader import discover_sources, load_source_contracts
    from das_cli.exit_codes import OK, PIPELINE_FAILURE, USAGE
    from das_cli.output import die, header, success
    from das_cli.pipelines.load import count_landing_rows, run_load
    from das_cli.progress import progress, resolve_mode

    config_path: Path = ctx.obj["config_path"] if ctx.obj else Path("das.yaml")

    if source is not None:
        contracts_root = config_path.parent / "contracts"
        if not (contracts_root / source).is_dir():
            die(f"Source '{source}' not found", code=USAGE)

    only = list(resource) if resource else None

    header("load", source or "all sources")

    quiet = bool(ctx.obj.get("quiet", False)) if ctx.obj else False
    verbose = bool(ctx.obj.get("verbose", False)) if ctx.obj else False
    mode, dlt_progress = resolve_mode(
        quiet=quiet, verbose=verbose, isatty=sys.stdout.isatty()
    )

    # Build {table_name: row_count} for progress totals.
    totals: dict[str, int] = {}
    if mode is not None:
        cfg = load_das_config(config_path)
        contracts_root = (config_path.parent / cfg.contracts.root).resolve()
        sources_to_count = discover_sources(contracts_root)
        if source is not None:
            sources_to_count = [s for s in sources_to_count if s.name == source]
        bucket_url = cfg.landing.bucket_url
        if not bucket_url.startswith(("s3://", "gs://", "az://", "file://")):
            landing_root = Path(bucket_url).expanduser()
        else:
            landing_root = Path(bucket_url)
        for src in sources_to_count:
            contracts = load_source_contracts(src.path)
            if only:
                wanted = set(only)
                contracts = [c for c in contracts if c.resource_name in wanted]
            for c in contracts:
                table = c.contract.primary_schema.physicalName or c.resource_name
                totals[table] = count_landing_rows(landing_root / src.name / c.resource_name)

    try:
        if mode is None:
            run_load(
                config_path=config_path, only_source=source, only_resources=only,
                progress_handle=None, dlt_progress=dlt_progress,
            )
        else:
            with progress(totals, mode=mode) as h:
                run_load(
                    config_path=config_path, only_source=source, only_resources=only,
                    progress_handle=h, dlt_progress=dlt_progress,
                )
    except Exception as e:
        from das_cli.output import warn
        warn(f"load failed: {e}")
        raise typer.Exit(code=PIPELINE_FAILURE) from e

    success("load complete")
    raise typer.Exit(code=OK)
```

- [ ] **Step 5: Verify ingest still works**

`ingest` calls `extract(...)` then `load(...)` directly. Both now resolve their own modes from `ctx.obj`. No further edits needed in `ingest`.

- [ ] **Step 6: Run the new tests + full suite**

Run: `uv run pytest -q`
Expected: PASS — all 149 baseline + new progress tests.

- [ ] **Step 7: Commit**

```bash
git add src/das_cli/cli.py tests/integration/test_cli_progress.py
git commit -m "feat(cli): wire progress mode resolution into extract/load/ingest"
```

---

## Task 9: Manual smoke test against Northwind

Verify the full UX end-to-end with a real source. This is a human-in-the-loop check, not an automated test.

**Files:**
- None modified.

- [ ] **Step 1: Set up the Northwind workspace**

The repo's e2e tests already use Northwind. Manually run:

```bash
cd /tmp && rm -rf smoke && mkdir smoke && cd smoke
uv run --project /home/mattiasthalen/repos/das-cli/.claude/worktrees/progress-bars-v0.1.4 das init
uv run --project /home/mattiasthalen/repos/das-cli/.claude/worktrees/progress-bars-v0.1.4 das source add nw --type odata --url https://services.odata.org/V4/Northwind/Northwind.svc
uv run --project /home/mattiasthalen/repos/das-cli/.claude/worktrees/progress-bars-v0.1.4 das contract bootstrap nw
```

- [ ] **Step 2: TTY default — Rich bars**

Run: `uv run das extract nw --limit 100`
Expected: stacked Rich panel with one line per resource (Customers, Orders, etc.), spinners advancing, counters reaching the limit. Bar tear-down is clean (no leftover ANSI).

- [ ] **Step 3: TTY quiet — no bars**

Run: `uv run das --quiet extract nw --limit 100`
Expected: only `[das] extract → nw` and `✓ extract complete` lines. No per-resource lines.

- [ ] **Step 4: TTY verbose — dlt log, no bars**

Run: `uv run das --verbose extract nw --limit 100`
Expected: dlt log output (verbose, multi-line per resource); no Rich bars.

- [ ] **Step 5: Non-TTY — plain lines**

Run: `uv run das extract nw --limit 100 | cat`
Expected: per-resource `[das] <name>: started` / `[das] <name>: N rows` lines, no animation.

- [ ] **Step 6: Load with totals**

Run: `uv run das load nw`
Expected: stacked Rich panel with real bars showing `n/total` and ETA.

- [ ] **Step 7: Confirmation**

Tick this checkbox after a human has visually confirmed the four modes look correct. No commit needed (no files changed).

---

## Task 10: Type-check & lint pass

Final verification: mypy strict + ruff are clean.

**Files:**
- None modified (unless lint surfaces issues).

- [ ] **Step 1: Run mypy**

Run: `uv run mypy src tests`
Expected: PASS, 0 errors.

If errors surface, fix them inline. Common ones for this change:
- The `_Renderer` Protocol may need `runtime_checkable` if used in `isinstance`. We don't use it that way, so no decorator needed.
- `_RichRenderer.__init__` constructs `columns: list` — annotate as `list[Any]` if mypy strict complains.

- [ ] **Step 2: Run ruff**

Run: `uv run ruff check src tests`
Expected: PASS, 0 violations.

- [ ] **Step 3: Run the full test suite once more**

Run: `uv run pytest -q`
Expected: PASS — all tests green.

- [ ] **Step 4: Commit any fixes**

```bash
git add -u
git commit -m "chore: type and lint cleanups for progress integration" || echo "no changes"
```

---

## Self-review

**1. Spec coverage**

| Spec section | Task |
|---|---|
| Mode resolution | Task 1 (helper) + Task 8 (wiring) |
| Per-resource lifecycle (rich) | Task 4 |
| Per-resource lifecycle (plain) | Task 3 |
| Per-resource lifecycle (silent) | Task 2 |
| Module layout (`progress.py`) | Tasks 1–4 |
| Counting generator (`wrap`) | Task 2 |
| Integration: extract | Task 5 |
| Integration: load (incl. pre-count) | Tasks 6–7 |
| Integration: cli | Task 8 |
| Tests: unit + integration | Tasks 1–8 |
| ADR impact (none) | n/a |

All sections covered.

**2. Placeholder scan**

No `TBD`, `TODO`, "implement later", or "similar to Task N". All code blocks are complete. Test bodies are full.

**3. Type / name consistency**

- `progress(...)` accepts `Sequence[str] | Mapping[str, int]` everywhere — Task 2 defines, Tasks 5/7/8 consume.
- `ProgressHandle.wrap(name, it)` — used in source_factory.py (Task 5), load.py (Task 7), tests (Tasks 2–4).
- `resolve_mode(quiet, verbose, isatty)` — Task 1 defines, Task 8 consumes.
- `count_landing_rows(landing_dir)` — Task 6 defines, Task 8 consumes.
- `run_extract` keyword params `progress_handle`, `dlt_progress` — Task 5 adds, Task 8 calls.
- `run_load` keyword params `progress_handle`, `dlt_progress` — Task 7 adds, Task 8 calls.
- Rich renderer's task name comes from `resource_name` (extract) or `table_name` (load). Task 8's load wiring builds `totals` keyed by `table_name`, matching Task 7's `progress_handle.wrap(table_name, ...)` call. Consistent.

No naming or type drift detected.
