# Verify SQL Sources (Oracle + SQL Server) Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a generic `sql` source family driven by `dlt.sources.sql_database` (SQLAlchemy under the hood). Verify end-to-end against Oracle Free and SQL Server 2022 in testcontainers. Closes #31 and #32.

**Architecture:** New `bootstrap/sql.py` does live SQLAlchemy reflection → ODCS contracts. New `_build_sql_resources` branch in `dlt_glue/source_factory.py` builds one dlt resource per contract via `sql_table`. P2 is unchanged (it reads JSONL blobs and dispatches per ADR-0016). One ADR-0018 captures the dispatch pattern, the SQLAlchemy choice, the URL-as-endpoint convention, and the MSSQL driver decision (`pyodbc` + ODBC Driver 18).

**Tech Stack:** Python 3.12, dlt 1.26 (with `sql_database` extra), SQLAlchemy 2.x, `oracledb` (thin mode, pure-Python), `pyodbc` + `msodbcsql18`, testcontainers-python, pytest, uv, ruff, mypy strict.

**Spec:** `docs/superpowers/specs/2026-05-08-verify-sql-sources-design.md`

**Pre-flight:**
- Branch: `claude/brainstorm-issue-31-85hF3`. All work commits there. The spec is already committed (commit `64b6aa6`).
- Today's date: `2026-05-08`. Use it for any new spec/plan filenames.
- `git status` should be clean before starting Task 1.

**Universal commands:**
- Run unit + integration tests: `uv run pytest -q`
- Run a single test: `uv run pytest tests/path/test_x.py::test_y -v`
- E2E (opt-in, requires Docker + drivers): `uv run pytest -m e2e -v`
- Lint/format: `uv run ruff check .` and `uv run ruff format .`
- Types: `uv run mypy src tests`
- Pre-commit: `uv run pre-commit run --all-files`

---

## Task 1: Extend `SourceConfig.spec` to accept `kind: sql`

Pure model change. No new runtime behavior. Existing OData/OpenAPI workspaces stay green.

**Files:**
- Modify: `src/das_cli/models/source_yml.py`
- Test: `tests/unit/test_source_yml_model.py` (extend)

- [ ] **Step 1: Add failing tests for the SQL spec shape**

Append to `tests/unit/test_source_yml_model.py`:

```python
def test_spec_kind_sql_accepts_schemas_tables_include_views() -> None:
    payload = {
        "type": "sql",
        "endpoint": "oracle+oracledb://host:1521/?service_name=XE",
        "spec": {
            "kind": "sql",
            "schemas": ["HR"],
            "tables": ["EMPLOYEES"],
            "include_views": True,
        },
        "auth": {"type": "none"},
    }
    cfg = SourceConfig.model_validate(payload)
    assert cfg.spec.kind == "sql"
    assert cfg.spec.schemas == ["HR"]
    assert cfg.spec.tables == ["EMPLOYEES"]
    assert cfg.spec.include_views is True


def test_spec_kind_sql_defaults_schemas_tables_include_views() -> None:
    payload = {
        "type": "sql",
        "endpoint": "sqlite:///:memory:",
        "spec": {"kind": "sql"},
        "auth": {"type": "none"},
    }
    cfg = SourceConfig.model_validate(payload)
    assert cfg.spec.kind == "sql"
    assert cfg.spec.schemas is None
    assert cfg.spec.tables is None
    assert cfg.spec.include_views is False


def test_spec_kind_sql_rejects_metadata_url() -> None:
    payload = {
        "type": "sql",
        "endpoint": "sqlite:///:memory:",
        "spec": {"kind": "sql", "metadata_url": "https://x/$metadata"},
        "auth": {"type": "none"},
    }
    with pytest.raises(ValidationError, match=r"metadata_url"):
        SourceConfig.model_validate(payload)


def test_spec_kind_sql_rejects_swagger_url() -> None:
    payload = {
        "type": "sql",
        "endpoint": "sqlite:///:memory:",
        "spec": {"kind": "sql", "swagger_url": "https://x/swagger.json"},
        "auth": {"type": "none"},
    }
    with pytest.raises(ValidationError, match=r"swagger_url"):
        SourceConfig.model_validate(payload)


def test_spec_kind_odata_rejects_schemas() -> None:
    payload = {
        "type": "odata",
        "endpoint": "https://example.com/odata/v1",
        "spec": {
            "kind": "odata",
            "metadata_url": "https://example.com/odata/v1/$metadata",
            "schemas": ["HR"],
        },
        "auth": {"type": "none"},
    }
    with pytest.raises(ValidationError, match=r"schemas"):
        SourceConfig.model_validate(payload)


def test_spec_kind_openapi_rejects_tables() -> None:
    payload = {
        "type": "openapi",
        "endpoint": "https://example.com/api/v1",
        "spec": {
            "kind": "openapi",
            "swagger_url": "https://example.com/api/v1/swagger.json",
            "tables": ["x"],
        },
        "auth": {"type": "none"},
    }
    with pytest.raises(ValidationError, match=r"tables"):
        SourceConfig.model_validate(payload)
```

- [ ] **Step 2: Run the new tests; confirm they fail**

Run: `uv run pytest tests/unit/test_source_yml_model.py -v`

Expected: the six new tests fail (some with "extra fields not permitted"-shaped errors against today's `extra='forbid'`; the SQL-accepting test fails because `SpecKind` doesn't include `"sql"` yet).

- [ ] **Step 3: Extend `SpecKind` and `SpecConfig`**

Replace the contents of `src/das_cli/models/source_yml.py` with:

```python
"""SourceConfig model — represents the contents of `_source.yml`."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

SourceType = Literal["odata", "openapi", "rest", "sql", "filesystem"]
AuthType = Literal["none", "bearer", "basic", "api_key"]
SpecKind = Literal["odata", "openapi", "sql", "none"]


class SpecConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")
    kind: SpecKind
    metadata_url: str | None = None
    swagger_url: str | None = None
    # SQL-only fields. See ADR-0018.
    schemas: list[str] | None = None
    tables: list[str] | None = None
    include_views: bool = False

    @model_validator(mode="after")
    def _enforce_kind_field_compatibility(self) -> SpecConfig:
        sql_only = ("schemas", "tables", "include_views")
        http_only = ("metadata_url", "swagger_url")
        if self.kind == "sql":
            for field in http_only:
                if getattr(self, field) is not None:
                    raise ValueError(
                        f"`spec.{field}` is not allowed when `spec.kind == 'sql'`"
                    )
        else:
            if self.schemas is not None:
                raise ValueError(
                    f"`spec.schemas` is only allowed when `spec.kind == 'sql'` "
                    f"(got kind='{self.kind}')"
                )
            if self.tables is not None:
                raise ValueError(
                    f"`spec.tables` is only allowed when `spec.kind == 'sql'` "
                    f"(got kind='{self.kind}')"
                )
            if self.include_views:
                raise ValueError(
                    f"`spec.include_views` is only allowed when `spec.kind == 'sql'` "
                    f"(got kind='{self.kind}')"
                )
        return self


class AuthConfig(BaseModel):
    model_config = ConfigDict(extra="allow")  # auth shape varies; allow extras
    type: AuthType = "none"


class OwnershipConfig(BaseModel):
    model_config = ConfigDict(extra="allow")
    team: str | None = None


class SourceConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")
    type: SourceType
    endpoint: str
    spec: SpecConfig = Field(default_factory=lambda: SpecConfig(kind="none"))
    auth: AuthConfig = Field(default_factory=AuthConfig)
    ownership: OwnershipConfig = Field(default_factory=OwnershipConfig)
    # Future: schedule, transport overrides, etc.
```

- [ ] **Step 4: Run the unit tests for the model; confirm green**

Run: `uv run pytest tests/unit/test_source_yml_model.py -v`

Expected: all tests pass (existing + the six new ones).

- [ ] **Step 5: Run the full test suite; confirm no regressions**

Run: `uv run pytest -q`

Expected: all green. If any other test fails because it constructs a `SpecConfig` with `metadata_url` plus a non-OData kind, that is a real bug — file a fix in a follow-up; do not loosen the validator.

- [ ] **Step 6: Commit**

```bash
git add src/das_cli/models/source_yml.py tests/unit/test_source_yml_model.py
git commit -m "$(cat <<'EOF'
feat(models): accept spec.kind=sql with schemas/tables/include_views

Extends SpecConfig per ADR-0018. SQL-specific fields are mutually
exclusive with metadata_url/swagger_url; validator enforces both
directions.

https://claude.ai/code/session_01ERzWp1HTdXLik89ZRfw2w4
EOF
)"
```

---

## Task 2: Add `bootstrap/sql.py` with SQLAlchemy reflection

New module that turns a SQL `_source.yml` plus reflected catalog into ODCS contracts. Tested against an in-memory SQLite — no Docker needed for unit coverage.

**Files:**
- Create: `src/das_cli/bootstrap/sql.py`
- Create: `tests/unit/test_bootstrap_sql.py`
- Modify: `pyproject.toml` (add `dlt[sql_database]` + `sqlalchemy` to runtime deps; `oracledb` and `pyodbc` stay test-only)

- [ ] **Step 1: Add the runtime dependency for the SQL source**

In `pyproject.toml`, change line 9 from:

```toml
    "dlt[duckdb,ducklake,filesystem,parquet]>=1.0",
```

to:

```toml
    "dlt[duckdb,ducklake,filesystem,parquet,sql_database]>=1.0",
    "sqlalchemy>=2.0",
```

(`dlt[sql_database]` already pulls SQLAlchemy transitively, but pinning explicitly makes the dependency intentional and gives mypy/ruff a stable target.)

Run: `uv sync`

Expected: succeeds; `uv.lock` updates with `sqlalchemy` and any sql_database-extra deps.

- [ ] **Step 2: Confirm dlt's `sql_table` import path on this dlt version**

Run:

```bash
uv run python -c "
from dlt.sources.sql_database import sql_table
print('sql_table:', sql_table)
"
```

Expected: prints something like `sql_table: <function sql_table at 0x...>`.

If the import fails, stop and update this plan with the actual import path used by the installed dlt version (`dlt.sources.sql_database` is documented for dlt 1.x). Do not proceed until this step prints successfully.

- [ ] **Step 3: Write failing unit tests for `bootstrap_sql_contracts`**

Create `tests/unit/test_bootstrap_sql.py`:

```python
"""Unit tests for SQL bootstrap. See ADR-0018."""

from __future__ import annotations

from pathlib import Path

import pytest
from sqlalchemy import (
    BLOB,
    Boolean,
    Column,
    Date,
    DateTime,
    Float,
    Integer,
    LargeBinary,
    MetaData,
    Numeric,
    String,
    Table,
    Text,
    create_engine,
)

from das_cli.bootstrap.sql import bootstrap_sql_contracts
from das_cli.contracts.custom_properties import get_das_value
from das_cli.models.source_yml import SourceConfig


def _seed_sqlite(path: Path) -> None:
    engine = create_engine(f"sqlite:///{path}")
    md = MetaData()
    Table(
        "customers",
        md,
        Column("customer_id", Integer, primary_key=True),
        Column("name", String(100), nullable=False),
        Column("created_at", DateTime, nullable=False),
        Column("updated_at", DateTime, nullable=False),
    )
    Table(
        "orders",
        md,
        Column("order_id", Integer, primary_key=True),
        Column("line_no", Integer, primary_key=True),
        Column("customer_id", Integer, nullable=False),
        Column("amount", Numeric(12, 2), nullable=False),
    )
    Table(
        "attachments",
        md,
        Column("attachment_id", Integer, primary_key=True),
        Column("payload", LargeBinary),
    )
    md.create_all(engine)
    engine.dispose()


def _scfg(url: str, **spec_overrides: object) -> SourceConfig:
    spec: dict[str, object] = {"kind": "sql", **spec_overrides}
    return SourceConfig.model_validate(
        {"type": "sql", "endpoint": url, "spec": spec, "auth": {"type": "none"}}
    )


def test_emits_one_contract_per_table(tmp_path: Path) -> None:
    db = tmp_path / "test.sqlite"
    _seed_sqlite(db)
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    names = sorted(c.resource_name for c in contracts)
    assert names == ["attachments", "customers", "orders"]


def test_resource_name_snake_cased(tmp_path: Path) -> None:
    db = tmp_path / "case.sqlite"
    engine = create_engine(f"sqlite:///{db}")
    md = MetaData()
    Table(
        "CustomerOrders",
        md,
        Column("Id", Integer, primary_key=True),
    )
    md.create_all(engine)
    engine.dispose()
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    assert [c.resource_name for c in contracts] == ["customer_orders"]


def test_physical_name_preserves_db_casing(tmp_path: Path) -> None:
    db = tmp_path / "case.sqlite"
    engine = create_engine(f"sqlite:///{db}")
    md = MetaData()
    Table(
        "CustomerOrders",
        md,
        Column("OrderId", Integer, primary_key=True),
    )
    md.create_all(engine)
    engine.dispose()
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    schema = contracts[0].contract.primary_schema
    assert schema.physicalName == "CustomerOrders"
    assert schema.properties[0].physicalName == "OrderId"
    assert schema.properties[0].name == "order_id"


def test_primary_key_detection_single(tmp_path: Path) -> None:
    db = tmp_path / "test.sqlite"
    _seed_sqlite(db)
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    customers = next(c for c in contracts if c.resource_name == "customers")
    pks = [p.name for p in customers.contract.primary_schema.properties if p.primaryKey]
    assert pks == ["customer_id"]


def test_primary_key_detection_composite(tmp_path: Path) -> None:
    db = tmp_path / "test.sqlite"
    _seed_sqlite(db)
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    orders = next(c for c in contracts if c.resource_name == "orders")
    pks = sorted(p.name for p in orders.contract.primary_schema.properties if p.primaryKey)
    assert pks == ["line_no", "order_id"]


def test_type_mapping_integer(tmp_path: Path) -> None:
    db = tmp_path / "test.sqlite"
    _seed_sqlite(db)
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    customers = next(c for c in contracts if c.resource_name == "customers")
    cid = next(p for p in customers.contract.primary_schema.properties if p.name == "customer_id")
    assert cid.logicalType == "integer"


def test_type_mapping_numeric_with_precision(tmp_path: Path) -> None:
    db = tmp_path / "test.sqlite"
    _seed_sqlite(db)
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    orders = next(c for c in contracts if c.resource_name == "orders")
    amount = next(p for p in orders.contract.primary_schema.properties if p.name == "amount")
    assert amount.logicalType == "number"
    assert amount.physicalType == "decimal(12,2)"


def test_type_mapping_string(tmp_path: Path) -> None:
    db = tmp_path / "test.sqlite"
    _seed_sqlite(db)
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    customers = next(c for c in contracts if c.resource_name == "customers")
    name = next(p for p in customers.contract.primary_schema.properties if p.name == "name")
    assert name.logicalType == "string"


def test_type_mapping_datetime_to_timestamp(tmp_path: Path) -> None:
    db = tmp_path / "test.sqlite"
    _seed_sqlite(db)
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    customers = next(c for c in contracts if c.resource_name == "customers")
    created = next(p for p in customers.contract.primary_schema.properties if p.name == "created_at")
    assert created.logicalType == "timestamp"


def test_type_mapping_largebinary_to_string(tmp_path: Path) -> None:
    db = tmp_path / "test.sqlite"
    _seed_sqlite(db)
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    attachments = next(c for c in contracts if c.resource_name == "attachments")
    payload = next(p for p in attachments.contract.primary_schema.properties if p.name == "payload")
    assert payload.logicalType == "string"


def test_cursor_inferred_from_updated_at(tmp_path: Path) -> None:
    db = tmp_path / "test.sqlite"
    _seed_sqlite(db)
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    customers = next(c for c in contracts if c.resource_name == "customers")
    cursor = get_das_value(customers.contract.custom_properties, "das.cursor")
    assert cursor == "updated_at"


def test_no_cursor_when_no_hint_column(tmp_path: Path) -> None:
    db = tmp_path / "test.sqlite"
    _seed_sqlite(db)
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    orders = next(c for c in contracts if c.resource_name == "orders")
    cursor = get_das_value(orders.contract.custom_properties, "das.cursor")
    assert cursor is None


def test_spec_ref_records_schema_and_table(tmp_path: Path) -> None:
    db = tmp_path / "test.sqlite"
    _seed_sqlite(db)
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    customers = next(c for c in contracts if c.resource_name == "customers")
    spec_ref = get_das_value(customers.contract.custom_properties, "das.spec_ref")
    # SQLite reports the default schema as None; Oracle/MSSQL will be a real name.
    assert spec_ref == {"kind": "sql", "schema": None, "table": "customers"}


def test_tables_filter_narrows_reflection(tmp_path: Path) -> None:
    db = tmp_path / "test.sqlite"
    _seed_sqlite(db)
    contracts = bootstrap_sql_contracts(
        _scfg(f"sqlite:///{db}", tables=["customers"]), source_name="x"
    )
    assert [c.resource_name for c in contracts] == ["customers"]


def test_unknown_type_falls_back_to_string(tmp_path: Path) -> None:
    """A Boolean column lands as logicalType=boolean; unknown types fall back."""
    db = tmp_path / "test.sqlite"
    engine = create_engine(f"sqlite:///{db}")
    md = MetaData()
    Table(
        "flags",
        md,
        Column("id", Integer, primary_key=True),
        Column("is_active", Boolean, nullable=False),
        Column("note", Text),
    )
    md.create_all(engine)
    engine.dispose()
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    flags = next(c for c in contracts if c.resource_name == "flags")
    is_active = next(p for p in flags.contract.primary_schema.properties if p.name == "is_active")
    note = next(p for p in flags.contract.primary_schema.properties if p.name == "note")
    assert is_active.logicalType == "boolean"
    assert note.logicalType == "string"
```

- [ ] **Step 4: Run the new tests; confirm they fail**

Run: `uv run pytest tests/unit/test_bootstrap_sql.py -v`

Expected: ImportError — `bootstrap.sql` does not exist.

- [ ] **Step 5: Write `bootstrap/sql.py`**

Create `src/das_cli/bootstrap/sql.py`:

```python
"""Reflect a SQL source via SQLAlchemy and emit ODCS contracts.

See ADR-0018: SQL source via SQLAlchemy reflection.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from sqlalchemy import MetaData, create_engine, inspect

from das_cli.bootstrap.naming import snake_case
from das_cli.contracts.loader import LoadedContract
from das_cli.contracts.odcs import (
    CustomProperty,
    OdcsContract,
    OdcsInfo,
    OdcsProperty,
    OdcsSchema,
)
from das_cli.models.source_yml import SourceConfig

if TYPE_CHECKING:
    from sqlalchemy import Column, Table

# Hint columns the cursor heuristic looks for. Lowercased compare.
_CURSOR_HINTS: tuple[str, ...] = (
    "updated_at",
    "modified_at",
    "last_modified",
    "updated_date",
    "modified_date",
)


def _logical_for(col: Column[object]) -> tuple[str, str | None]:
    """Map a SQLAlchemy generic Column type to (logicalType, physicalType).

    Falls back to ('string', None) for unknown types. See ADR-0018.
    """
    from sqlalchemy import (
        BigInteger,
        Boolean,
        Date,
        DateTime,
        Float,
        Integer,
        LargeBinary,
        Numeric,
        SmallInteger,
        String,
        Text,
        Time,
    )
    from sqlalchemy.types import (
        BLOB,
        TIMESTAMP,
    )

    sa_type = col.type
    if isinstance(sa_type, BigInteger):
        return ("integer", "bigint")
    if isinstance(sa_type, (Integer, SmallInteger)):
        return ("integer", None)
    if isinstance(sa_type, Numeric) and not isinstance(sa_type, Float):
        precision = sa_type.precision
        scale = sa_type.scale
        if precision is not None and scale is not None:
            return ("number", f"decimal({precision},{scale})")
        return ("number", None)
    if isinstance(sa_type, Float):
        return ("number", None)
    if isinstance(sa_type, Boolean):
        return ("boolean", None)
    if isinstance(sa_type, (String, Text)):
        return ("string", None)
    if isinstance(sa_type, Date):
        return ("date", None)
    if isinstance(sa_type, Time):
        return ("string", None)
    if isinstance(sa_type, (DateTime, TIMESTAMP)):
        return ("timestamp", None)
    if isinstance(sa_type, (LargeBinary, BLOB)):
        return ("string", None)
    return ("string", None)


def _pick_cursor(props: list[OdcsProperty]) -> str | None:
    """Return the first property whose name matches a cursor hint."""
    by_name = {p.name: p for p in props}
    for hint in _CURSOR_HINTS:
        if hint in by_name:
            return hint
    return None


def _build_property(col: Column[object]) -> OdcsProperty:
    logical, physical = _logical_for(col)
    return OdcsProperty(
        name=snake_case(col.name),
        physicalName=col.name,
        logicalType=logical,  # type: ignore[arg-type]
        physicalType=physical,
        required=not col.nullable,
        primaryKey=bool(col.primary_key),
    )


def _build_contract(
    table: Table,
    *,
    source_name: str,
    schema: str | None,
) -> LoadedContract:
    properties = [_build_property(c) for c in table.columns]
    resource_name = snake_case(table.name)

    custom_props: list[CustomProperty] = [
        CustomProperty(
            property="das.spec_ref",
            value={"kind": "sql", "schema": schema, "table": table.name},
        ),
    ]
    cursor = _pick_cursor(properties)
    if cursor:
        custom_props.append(CustomProperty(property="das.cursor", value=cursor))

    contract = OdcsContract(
        apiVersion="v3.0.0",
        kind="DataContract",
        id=f"{source_name}.{resource_name}",
        name=table.name,
        version="0.1.0",
        status="draft",
        info=OdcsInfo(title=table.name, owner="data-platform"),
        schema=[
            OdcsSchema(
                name=resource_name,
                physicalName=table.name,
                physicalType="table",
                properties=properties,
            )
        ],
        customProperties=custom_props,
    )

    return LoadedContract(
        path=Path(f"{resource_name}.odcs.yaml"),
        resource_name=resource_name,
        contract=contract,
    )


def bootstrap_sql_contracts(
    scfg: SourceConfig,
    *,
    source_name: str,
) -> list[LoadedContract]:
    """Reflect schemas via SQLAlchemy and return one LoadedContract per table.

    Schemas to reflect: `scfg.spec.schemas` if set, else the connection user's
    default schema (which is `None` for SQLite, `dbo` for SQL Server, the user
    name for Oracle, `public` for Postgres). `scfg.spec.tables` filters to a
    subset; absent means "every table in the listed schemas." Views are
    included when `scfg.spec.include_views` is True.
    """
    engine = create_engine(scfg.endpoint)
    try:
        if scfg.spec.schemas:
            target_schemas: list[str | None] = list(scfg.spec.schemas)
        else:
            insp = inspect(engine)
            target_schemas = [insp.default_schema_name]

        out: list[LoadedContract] = []
        for schema in target_schemas:
            md = MetaData()
            md.reflect(
                bind=engine,
                schema=schema,
                only=scfg.spec.tables,
                views=scfg.spec.include_views,
            )
            for table in md.sorted_tables:
                out.append(_build_contract(table, source_name=source_name, schema=schema))
    finally:
        engine.dispose()
    return out
```

- [ ] **Step 6: Run the bootstrap unit tests; confirm green**

Run: `uv run pytest tests/unit/test_bootstrap_sql.py -v`

Expected: all 13 tests pass.

- [ ] **Step 7: Run full unit suite; confirm no regressions**

Run: `uv run pytest tests/unit -q`

Expected: green.

- [ ] **Step 8: Type-check**

Run: `uv run mypy src tests`

Expected: clean. If mypy complains about SQLAlchemy generic type parameters (`Column[object]`), the simplest fix is to drop the generic parameters in the `_logical_for` signature: `def _logical_for(col: Column) -> tuple[str, str | None]:` and add `# type: ignore[type-arg]` on the parameter line if necessary. Do not silence whole-module ignores.

- [ ] **Step 9: Commit**

```bash
git add pyproject.toml uv.lock src/das_cli/bootstrap/sql.py tests/unit/test_bootstrap_sql.py
git commit -m "$(cat <<'EOF'
feat(bootstrap): reflect SQL sources via SQLAlchemy into ODCS contracts

New bootstrap/sql.py walks SQLAlchemy MetaData reflection and emits one
ODCS contract per table. Type mapping covers SQLAlchemy generic types;
unknowns fall back to logicalType=string. Cursor heuristic mirrors
bootstrap/odata.py. See ADR-0018.

https://claude.ai/code/session_01ERzWp1HTdXLik89ZRfw2w4
EOF
)"
```

---

## Task 3: Wire SQL bootstrap into `das contract bootstrap` dispatch

Hook the new module into the CLI command that already dispatches `odata`/`openapi`. Adds an integration test that exercises the SQLite happy path.

**Files:**
- Modify: `src/das_cli/cli.py:492-514` (`contract_bootstrap` dispatch block)
- Create: `tests/integration/test_bootstrap_sql.py`

- [ ] **Step 1: Write a failing integration test for `das contract bootstrap` against SQLite**

Create `tests/integration/test_bootstrap_sql.py`:

```python
"""Integration: `das contract bootstrap` against a real SQLite DB. See ADR-0018."""

from __future__ import annotations

from pathlib import Path

import yaml
from sqlalchemy import (
    Column,
    DateTime,
    Integer,
    MetaData,
    Numeric,
    String,
    Table,
    create_engine,
)
from typer.testing import CliRunner

from das_cli.cli import app


def _seed_sqlite(path: Path) -> None:
    engine = create_engine(f"sqlite:///{path}")
    md = MetaData()
    Table(
        "customers",
        md,
        Column("customer_id", Integer, primary_key=True),
        Column("name", String(100), nullable=False),
        Column("updated_at", DateTime, nullable=False),
    )
    Table(
        "orders",
        md,
        Column("order_id", Integer, primary_key=True),
        Column("line_no", Integer, primary_key=True),
        Column("amount", Numeric(12, 2), nullable=False),
    )
    md.create_all(engine)
    engine.dispose()


def test_bootstrap_sql_emits_one_contract_per_table(
    workspace: Path, cli_runner: CliRunner
) -> None:
    db_path = workspace / "demo.sqlite"
    _seed_sqlite(db_path)

    cli_runner.invoke(app, ["init"])
    src_dir = workspace / "contracts" / "demo"
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(
        f"type: sql\n"
        f"endpoint: sqlite:///{db_path}\n"
        f"spec:\n  kind: sql\n"
        f"auth:\n  type: none\n"
    )

    result = cli_runner.invoke(app, ["contract", "bootstrap", "demo"])
    assert result.exit_code == 0, result.stdout + result.stderr

    yamls = sorted(p.name for p in src_dir.glob("*.odcs.yaml"))
    assert yamls == ["customers.odcs.yaml", "orders.odcs.yaml"]


def test_bootstrap_sql_writes_pks_and_cursor(
    workspace: Path, cli_runner: CliRunner
) -> None:
    db_path = workspace / "demo.sqlite"
    _seed_sqlite(db_path)

    cli_runner.invoke(app, ["init"])
    src_dir = workspace / "contracts" / "demo"
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(
        f"type: sql\n"
        f"endpoint: sqlite:///{db_path}\n"
        f"spec:\n  kind: sql\n"
        f"auth:\n  type: none\n"
    )

    cli_runner.invoke(app, ["contract", "bootstrap", "demo"])
    customers_yaml = yaml.safe_load((src_dir / "customers.odcs.yaml").read_text())
    pks = [p["name"] for p in customers_yaml["schema"][0]["properties"] if p.get("primaryKey")]
    assert pks == ["customer_id"]

    cursor_props = [
        cp for cp in customers_yaml.get("customProperties", []) if cp["property"] == "das.cursor"
    ]
    assert cursor_props == [{"property": "das.cursor", "value": "updated_at"}]
```

- [ ] **Step 2: Run the new test; confirm it fails**

Run: `uv run pytest tests/integration/test_bootstrap_sql.py -v`

Expected: failure with exit code 2 (USAGE), because `cli.py:contract_bootstrap` does not yet dispatch on `kind: sql`.

- [ ] **Step 3: Add the SQL dispatch branch to `contract_bootstrap`**

In `src/das_cli/cli.py`, locate the dispatch block at lines 492-514:

```python
    if scfg.spec.kind == "odata":
        ...
    elif scfg.spec.kind == "openapi":
        ...
    else:
        die(f"Cannot bootstrap from spec.kind={scfg.spec.kind}", code=USAGE)
        return
```

Replace the `else` branch with an `elif` for SQL plus the existing fallback:

```python
    if scfg.spec.kind == "odata":
        metadata_url = scfg.spec.metadata_url
        if not metadata_url:
            die("OData source missing spec.metadata_url", code=USAGE)
            return
        resp = requests.get(metadata_url, timeout=30)
        resp.raise_for_status()
        loaded = bootstrap_odata_contracts(resp.text, source_name=source)
    elif scfg.spec.kind == "openapi":
        swagger_url = scfg.spec.swagger_url
        if not swagger_url:
            die("OpenAPI source missing spec.swagger_url", code=USAGE)
            return
        resp = requests.get(swagger_url, timeout=30)
        resp.raise_for_status()
        loaded = bootstrap_openapi_contracts(
            resp.json(),
            source_name=source,
            source_endpoint=scfg.endpoint,
        )
    elif scfg.spec.kind == "sql":
        # See ADR-0018.
        from das_cli.bootstrap.sql import bootstrap_sql_contracts

        loaded = bootstrap_sql_contracts(scfg, source_name=source)
    else:
        die(f"Cannot bootstrap from spec.kind={scfg.spec.kind}", code=USAGE)
        return
```

- [ ] **Step 4: Run the new test; confirm green**

Run: `uv run pytest tests/integration/test_bootstrap_sql.py -v`

Expected: both tests pass.

- [ ] **Step 5: Run full integration suite; confirm no regressions**

Run: `uv run pytest tests/integration -q`

Expected: green.

- [ ] **Step 6: Type-check + lint**

Run: `uv run mypy src tests && uv run ruff check .`

Expected: clean.

- [ ] **Step 7: Commit**

```bash
git add src/das_cli/cli.py tests/integration/test_bootstrap_sql.py
git commit -m "$(cat <<'EOF'
feat(cli): dispatch contract bootstrap for spec.kind=sql

Adds a third branch to contract_bootstrap that delegates to
bootstrap_sql_contracts when scfg.spec.kind == 'sql'. See ADR-0018.

https://claude.ai/code/session_01ERzWp1HTdXLik89ZRfw2w4
EOF
)"
```

---

## Task 4: Add `_build_sql_resources` to source factory

Wire `dlt.sources.sql_database.sql_table` into the extract pipeline. Engine lifecycle (dispose) lives in `extract.run_extract`. Existing HTTP path stays untouched.

**Files:**
- Modify: `src/das_cli/dlt_glue/source_factory.py` (add SQL builder + dispatch)
- Modify: `src/das_cli/pipelines/extract.py` (engine disposal in finally)
- Create: `tests/unit/test_source_factory_sql.py`

- [ ] **Step 1: Write failing unit tests for the SQL dispatch path**

Create `tests/unit/test_source_factory_sql.py`:

```python
"""Unit tests for SQL source factory dispatch. See ADR-0018."""

from __future__ import annotations

from pathlib import Path

import pytest

from das_cli.contracts.loader import LoadedContract
from das_cli.contracts.odcs import (
    CustomProperty,
    OdcsContract,
    OdcsInfo,
    OdcsProperty,
    OdcsSchema,
)
from das_cli.dlt_glue.source_factory import (
    UnknownSourceTypeError,
    build_extract_resources,
)
from das_cli.models.source_yml import SourceConfig


def _make_sql_contract(
    resource: str,
    *,
    table: str | None = None,
    schema: str | None = None,
    cursor: str | None = None,
) -> LoadedContract:
    custom_props = [
        CustomProperty(
            property="das.spec_ref",
            value={"kind": "sql", "schema": schema, "table": table or resource},
        ),
    ]
    if cursor:
        custom_props.append(CustomProperty(property="das.cursor", value=cursor))
    contract = OdcsContract(
        apiVersion="v3.0.0",
        kind="DataContract",
        id=f"x.{resource}",
        name=resource,
        version="0.1.0",
        status="draft",
        info=OdcsInfo(title=resource),
        schema=[
            OdcsSchema(
                name=resource,
                physicalName=table or resource,
                physicalType="table",
                properties=[
                    OdcsProperty(
                        name="id", logicalType="integer", primaryKey=True, required=True
                    ),
                ],
            )
        ],
        customProperties=custom_props,
    )
    return LoadedContract(
        path=Path(f"{resource}.odcs.yaml"), resource_name=resource, contract=contract
    )


def _sql_scfg(url: str = "sqlite:///:memory:") -> SourceConfig:
    return SourceConfig.model_validate(
        {"type": "sql", "endpoint": url, "spec": {"kind": "sql"}, "auth": {"type": "none"}}
    )


def test_sql_dispatch_returns_one_resource_per_contract() -> None:
    contracts = [_make_sql_contract("customers"), _make_sql_contract("orders")]
    resources = build_extract_resources(_sql_scfg(), contracts, source_name="x")
    assert len(resources) == 2


def test_sql_dispatch_resource_name_matches_contract() -> None:
    contracts = [_make_sql_contract("customers"), _make_sql_contract("orders")]
    resources = build_extract_resources(_sql_scfg(), contracts, source_name="x")
    names = sorted(r.name for r in resources)
    assert names == ["customers", "orders"]


def test_filesystem_still_raises_unknown_source_type_error() -> None:
    scfg = SourceConfig.model_validate(
        {
            "type": "filesystem",
            "endpoint": "file:///tmp",
            "spec": {"kind": "none"},
            "auth": {"type": "none"},
        }
    )
    with pytest.raises(UnknownSourceTypeError):
        build_extract_resources(scfg, [], source_name="x")
```

Note: this test asserts only the resource list shape (count and `.name`). Cursor wiring and dlt-internal incremental behavior are exercised by Task 5's integration test, which actually runs an extract.

- [ ] **Step 2: Run the new tests; confirm they fail**

Run: `uv run pytest tests/unit/test_source_factory_sql.py -v`

Expected: failures — `build_extract_resources` raises `UnknownSourceTypeError("No P1 builder for source type 'sql'")`.

- [ ] **Step 3: Add `_build_sql_resources` to `source_factory.py`**

Open `src/das_cli/dlt_glue/source_factory.py`. Append before `build_extract_resources` (and after the existing HTTP helpers):

```python
def _build_sql_resources(
    scfg: SourceConfig,
    contracts: list[LoadedContract],
    *,
    source_name: str,
    limit: int | None = None,
    progress_handle: ProgressHandle | None = None,
) -> list[Any]:
    """Build dlt resources for a SQL source. See ADR-0018."""
    from dlt.sources.sql_database import sql_table  # type: ignore[attr-defined]
    from sqlalchemy import create_engine

    engine = create_engine(scfg.endpoint)
    out: list[Any] = []
    for contract in contracts:
        spec_ref = (
            get_das_value(contract.contract.custom_properties, "das.spec_ref") or {}
        )
        # `das.spec_ref` is populated by bootstrap_sql_contracts; for hand-written
        # contracts that omit it, fall back to physical_name and dlt's default schema.
        schema = spec_ref.get("schema") if isinstance(spec_ref, dict) else None
        table = (
            spec_ref.get("table")
            if isinstance(spec_ref, dict) and spec_ref.get("table")
            else contract.contract.primary_schema.physicalName
        )
        cursor = get_das_value(contract.contract.custom_properties, "das.cursor")

        out.append(
            _make_sql_resource(
                engine=engine,
                resource_name=contract.resource_name,
                table=table,
                schema=schema,
                cursor=cursor,
                limit=limit,
                progress_handle=progress_handle,
            )
        )
    return out


def _make_sql_resource(
    *,
    engine: Any,
    resource_name: str,
    table: str,
    schema: str | None,
    cursor: str | None,
    limit: int | None,
    progress_handle: ProgressHandle | None,
) -> Any:
    from dlt.sources.sql_database import sql_table  # type: ignore[attr-defined]

    @dlt.resource(  # type: ignore[misc,call-overload,untyped-decorator]
        name=resource_name,
        write_disposition="append",
        columns={"_data": {"data_type": "json", "nullable": False}},
        primary_key=None,
    )
    def _gen() -> Iterator[dict[str, Any]]:
        kwargs: dict[str, Any] = {
            "credentials": engine,
            "table": table,
            "chunk_size": 10_000,
        }
        if schema is not None:
            kwargs["schema"] = schema
        if cursor is not None:
            kwargs["incremental"] = dlt.sources.incremental(cursor)  # type: ignore[attr-defined]

        base = sql_table(**kwargs)

        def _wrap_blobs() -> Iterator[dict[str, Any]]:
            for row in base:
                yield {"_data": row}

        source: Iterator[dict[str, Any]] = _wrap_blobs()
        if limit is not None:
            source = _limit_gen(source, limit)
        if progress_handle is not None:
            source = progress_handle.wrap(resource_name, source)
        yield from source

    return _gen
```

Now extend `build_extract_resources` (currently the function ends with `raise UnknownSourceTypeError(...)`). Replace its body with:

```python
def build_extract_resources(
    scfg: SourceConfig,
    contracts: list[LoadedContract],
    *,
    source_name: str,
    limit: int | None = None,
    progress_handle: ProgressHandle | None = None,
) -> list[Any]:
    """Build a list of dlt resources for P1 extraction."""
    if scfg.type in _HTTP_SOURCE_TYPES:
        return _build_http_resources(
            scfg,
            contracts,
            source_name=source_name,
            limit=limit,
            progress_handle=progress_handle,
        )
    if scfg.type == "sql":
        # See ADR-0018.
        return _build_sql_resources(
            scfg,
            contracts,
            source_name=source_name,
            limit=limit,
            progress_handle=progress_handle,
        )
    raise UnknownSourceTypeError(f"No P1 builder for source type '{scfg.type}'")
```

- [ ] **Step 4: Run the new tests; confirm green**

Run: `uv run pytest tests/unit/test_source_factory_sql.py -v`

Expected: all three tests pass.

- [ ] **Step 5: Add engine-disposal `try / finally` to `run_extract`**

`_build_sql_resources` constructs a SQLAlchemy `Engine`. dlt's pipeline run does not own its lifecycle. We dispose the engine after the run.

In `src/das_cli/pipelines/extract.py`, locate the `pipeline.run(...)` call (around line 75). The current `run_extract` body is a single linear flow. Wrap the section that builds resources, runs the pipeline, and counts files in a `try / finally` that disposes any SQL engine present in the resources.

The cleanest approach is to surface the engine for disposal. Modify `_build_sql_resources` to attach the engine to a function attribute on the first generator, and have `run_extract` look for it. Simpler: dispose in `_gen`'s finalizer? No — generators are short-lived.

Use an explicit dispose protocol: `_build_sql_resources` returns the engine alongside the resources. Refactor signatures so the existing HTTP path is unchanged.

Replace the body of `_build_sql_resources` with this version that stashes the engine on the returned list:

```python
def _build_sql_resources(
    scfg: SourceConfig,
    contracts: list[LoadedContract],
    *,
    source_name: str,
    limit: int | None = None,
    progress_handle: ProgressHandle | None = None,
) -> list[Any]:
    """Build dlt resources for a SQL source. See ADR-0018.

    The returned list carries the SQLAlchemy engine on `_das_sql_engine`
    so the caller (run_extract) can dispose it after the pipeline run.
    """
    from sqlalchemy import create_engine

    engine = create_engine(scfg.endpoint)
    out: list[Any] = []
    for contract in contracts:
        spec_ref = (
            get_das_value(contract.contract.custom_properties, "das.spec_ref") or {}
        )
        schema = spec_ref.get("schema") if isinstance(spec_ref, dict) else None
        table = (
            spec_ref.get("table")
            if isinstance(spec_ref, dict) and spec_ref.get("table")
            else contract.contract.primary_schema.physicalName
        )
        cursor = get_das_value(contract.contract.custom_properties, "das.cursor")

        out.append(
            _make_sql_resource(
                engine=engine,
                resource_name=contract.resource_name,
                table=table,
                schema=schema,
                cursor=cursor,
                limit=limit,
                progress_handle=progress_handle,
            )
        )
    out._das_sql_engine = engine  # type: ignore[attr-defined]
    return out
```

Then in `src/das_cli/pipelines/extract.py`, wrap the existing pipeline.run call in `try / finally`. Replace lines 42-75 (resources construction through `pipeline.run`) with:

```python
    resources = build_extract_resources(
        scfg,
        contracts,
        source_name=source_name,
        limit=limit,
        progress_handle=progress_handle,
    )

    bucket_url = cfg.landing.bucket_url.rstrip("/")

    pipeline = dlt.pipeline(  # type: ignore[call-overload]
        pipeline_name=f"das_extract__{source_name}",
        destination=dlt.destinations.filesystem(
            bucket_url=bucket_url,
            credentials=cfg.landing.credentials or None,
            layout="{table_name}/_extracted_on={curr_date}/{load_id}.{file_id}.{ext}",
        ),
        dataset_name=source_name,
        pipelines_dir=".dlt/pipelines",
        progress=dlt_progress,
    )

    try:
        pipeline.run(resources, loader_file_format="jsonl")
    finally:
        # See ADR-0018: SQL sources stash a SQLAlchemy engine on the resource list
        # so we can dispose it after the run. HTTP sources don't need this.
        engine = getattr(resources, "_das_sql_engine", None)
        if engine is not None:
            engine.dispose()
```

- [ ] **Step 6: Run extract pipeline tests; confirm no regressions**

Run: `uv run pytest tests/integration/test_extract_pipeline.py tests/unit/test_source_factory_sql.py tests/unit/test_source_factory.py -v`

Expected: green. Existing OData/OpenAPI extract tests still pass; new SQL dispatch tests pass.

- [ ] **Step 7: Type-check**

Run: `uv run mypy src tests`

Expected: clean. The `# type: ignore[attr-defined]` on `out._das_sql_engine = engine` suppresses the "list has no attribute" complaint; this attaches an attribute to a list instance (Python permits it via `__dict__` only on subclasses — see fix below if mypy/runtime balks). If mypy still rejects it, replace the `out: list[Any] = []` line with a tiny subclass:

```python
class _SqlResourceList(list[Any]):
    """A list with a SQLAlchemy engine attached for caller-side disposal."""

    _das_sql_engine: Any = None
```

…and use `out: _SqlResourceList = _SqlResourceList()`. Update the access in `extract.py` to `engine = resources._das_sql_engine if isinstance(resources, _SqlResourceList) else None` (importing the class). The behavior is identical; the type checker is happy.

- [ ] **Step 8: Commit**

```bash
git add src/das_cli/dlt_glue/source_factory.py src/das_cli/pipelines/extract.py tests/unit/test_source_factory_sql.py
git commit -m "$(cat <<'EOF'
feat(extract): build dlt resources for SQL sources via sql_database

Adds _build_sql_resources alongside the HTTP path in source_factory.py.
One sql_table per contract, optional dlt incremental when das.cursor is
set, JSONL blob discipline preserved per ADR-0003. run_extract disposes
the SQLAlchemy engine after the pipeline run. See ADR-0018.

https://claude.ai/code/session_01ERzWp1HTdXLik89ZRfw2w4
EOF
)"
```

---

## Task 5: Integration test — full SQL extract round-trip with cursor

Verify that `das extract` against a SQLite source writes JSONL blobs, applies the cursor on a second run, and that `--full` ignores it.

**Files:**
- Create: `tests/integration/test_extract_pipeline_sql.py`

- [ ] **Step 1: Write the failing test**

Create `tests/integration/test_extract_pipeline_sql.py`:

```python
"""Integration: `das extract` against a real SQLite source. See ADR-0018."""

from __future__ import annotations

import gzip
import json
from datetime import datetime, timezone
from pathlib import Path

from sqlalchemy import (
    Column,
    DateTime,
    Integer,
    MetaData,
    String,
    Table,
    create_engine,
    insert,
)
from typer.testing import CliRunner

from das_cli.cli import app


def _seed_sqlite(path: Path, *, rows: list[dict[str, object]]) -> None:
    engine = create_engine(f"sqlite:///{path}")
    md = MetaData()
    customers = Table(
        "customers",
        md,
        Column("customer_id", Integer, primary_key=True),
        Column("name", String(100), nullable=False),
        Column("updated_at", DateTime, nullable=False),
    )
    md.create_all(engine)
    with engine.begin() as conn:
        conn.execute(insert(customers), rows)
    engine.dispose()


def _read_jsonl(landing_dir: Path) -> list[dict[str, object]]:
    out: list[dict[str, object]] = []
    for f in landing_dir.rglob("*.jsonl*"):
        text = gzip.decompress(f.read_bytes()).decode() if f.suffix == ".gz" else f.read_text()
        for line in text.strip().splitlines():
            out.append(json.loads(line))
    return [r for r in out if "_data" in r]


def test_sql_extract_writes_jsonl_blobs(workspace: Path, cli_runner: CliRunner) -> None:
    db = workspace / "demo.sqlite"
    _seed_sqlite(
        db,
        rows=[
            {"customer_id": 1, "name": "Ada", "updated_at": datetime(2026, 5, 1, tzinfo=timezone.utc)},
            {"customer_id": 2, "name": "Linus", "updated_at": datetime(2026, 5, 2, tzinfo=timezone.utc)},
        ],
    )

    cli_runner.invoke(app, ["init"])
    src_dir = workspace / "contracts" / "demo"
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(
        f"type: sql\nendpoint: sqlite:///{db}\nspec:\n  kind: sql\nauth:\n  type: none\n"
    )

    boot = cli_runner.invoke(app, ["contract", "bootstrap", "demo"])
    assert boot.exit_code == 0, boot.stdout + boot.stderr

    result = cli_runner.invoke(app, ["extract", "demo"])
    assert result.exit_code == 0, result.stdout + result.stderr

    blobs = _read_jsonl(workspace / "landing" / "demo" / "customers")
    payloads = [r["_data"] for r in blobs]
    assert {p["customer_id"] for p in payloads} == {1, 2}
    assert {p["name"] for p in payloads} == {"Ada", "Linus"}


def test_sql_extract_cursor_picks_up_only_new_rows(
    workspace: Path, cli_runner: CliRunner
) -> None:
    db = workspace / "demo.sqlite"
    _seed_sqlite(
        db,
        rows=[
            {"customer_id": 1, "name": "Ada", "updated_at": datetime(2026, 5, 1, tzinfo=timezone.utc)},
        ],
    )

    cli_runner.invoke(app, ["init"])
    src_dir = workspace / "contracts" / "demo"
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(
        f"type: sql\nendpoint: sqlite:///{db}\nspec:\n  kind: sql\nauth:\n  type: none\n"
    )
    cli_runner.invoke(app, ["contract", "bootstrap", "demo"])

    first = cli_runner.invoke(app, ["extract", "demo"])
    assert first.exit_code == 0, first.stdout + first.stderr

    # Insert a second row with a later updated_at; cursor should pick only it up.
    engine = create_engine(f"sqlite:///{db}")
    md = MetaData()
    customers = Table("customers", md, autoload_with=engine)
    with engine.begin() as conn:
        conn.execute(
            insert(customers),
            [
                {
                    "customer_id": 2,
                    "name": "Linus",
                    "updated_at": datetime(2026, 5, 2, tzinfo=timezone.utc),
                }
            ],
        )
    engine.dispose()

    second = cli_runner.invoke(app, ["extract", "demo"])
    assert second.exit_code == 0, second.stdout + second.stderr

    blobs = _read_jsonl(workspace / "landing" / "demo" / "customers")
    customer_ids_per_load = {}
    for r in blobs:
        load = r.get("_dlt_load_id", "?")
        customer_ids_per_load.setdefault(load, set()).add(r["_data"]["customer_id"])
    # Two distinct load_ids; the second contains only customer_id 2.
    second_load_ids = sorted(customer_ids_per_load.values(), key=lambda s: min(s))
    assert second_load_ids[0] == {1}
    assert second_load_ids[1] == {2}


def test_sql_extract_full_flag_replays_everything(
    workspace: Path, cli_runner: CliRunner
) -> None:
    db = workspace / "demo.sqlite"
    _seed_sqlite(
        db,
        rows=[
            {"customer_id": 1, "name": "Ada", "updated_at": datetime(2026, 5, 1, tzinfo=timezone.utc)},
            {"customer_id": 2, "name": "Linus", "updated_at": datetime(2026, 5, 2, tzinfo=timezone.utc)},
        ],
    )

    cli_runner.invoke(app, ["init"])
    src_dir = workspace / "contracts" / "demo"
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(
        f"type: sql\nendpoint: sqlite:///{db}\nspec:\n  kind: sql\nauth:\n  type: none\n"
    )
    cli_runner.invoke(app, ["contract", "bootstrap", "demo"])

    cli_runner.invoke(app, ["extract", "demo"])
    second = cli_runner.invoke(app, ["extract", "demo", "--full"])
    assert second.exit_code == 0, second.stdout + second.stderr

    blobs = _read_jsonl(workspace / "landing" / "demo" / "customers")
    # --full ignores cursor state; the second run must re-emit both rows.
    counts: dict[str, int] = {}
    for r in blobs:
        load = r.get("_dlt_load_id", "?")
        counts[load] = counts.get(load, 0) + 1
    # We expect at least 2 load_ids, and at least one with 2 rows (the --full one).
    assert any(c == 2 for c in counts.values()), counts
```

- [ ] **Step 2: Run the new tests; confirm they pass**

Run: `uv run pytest tests/integration/test_extract_pipeline_sql.py -v`

Expected: all three tests pass. If `test_sql_extract_cursor_picks_up_only_new_rows` fails because dlt's incremental needs a different cursor type (e.g. `last_value` semantics for `DateTime`), inspect dlt 1.26's `dlt.sources.incremental` docstring and adjust the cursor column dtype if necessary. The most robust way is to keep `updated_at` as a SQLAlchemy `DateTime`; SQLite stores it as text but dlt's incremental does string comparison, which is correct for ISO-8601 timestamps.

- [ ] **Step 3: Run full pytest; confirm green**

Run: `uv run pytest -q`

Expected: green.

- [ ] **Step 4: Pre-commit (lint + types)**

Run: `uv run pre-commit run --all-files`

Expected: clean.

- [ ] **Step 5: Commit**

```bash
git add tests/integration/test_extract_pipeline_sql.py
git commit -m "$(cat <<'EOF'
test(integration): full SQL extract round-trip with cursor + --full

SQLite-driven coverage: blob shape, incremental picks up only new rows,
--full replays everything. See ADR-0018.

https://claude.ai/code/session_01ERzWp1HTdXLik89ZRfw2w4
EOF
)"
```

---

## Task 6: `das source add --type sql` ergonomics

Reject credentials in URL, auto-template `env_var(...)` placeholders for username/password, generate the `<PREFIX>__USERNAME` / `<PREFIX>__PASSWORD` env block, and reject `--auth` for SQL.

**Files:**
- Modify: `src/das_cli/cli.py:247-322` (`_source_yml_template` + `source_add`)
- Modify: `tests/integration/test_cli_source_add.py` (extend)

- [ ] **Step 1: Write failing tests for the new ergonomics**

Append to `tests/integration/test_cli_source_add.py`:

```python
def test_source_add_sql_writes_templated_endpoint(
    workspace: Path, cli_runner: CliRunner
) -> None:
    cli_runner.invoke(app, ["init"])
    result = cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "finance",
            "--type",
            "sql",
            "--url",
            "oracle+oracledb://oracle-host:1521/?service_name=XEPDB1",
        ],
    )
    assert result.exit_code == 0, result.stdout + result.stderr
    raw = yaml.safe_load(
        (workspace / "contracts" / "finance" / "_source.yml").read_text()
    )
    assert raw["type"] == "sql"
    assert "{{ env_var('FINANCE__USERNAME') }}" in raw["endpoint"]
    assert "{{ env_var('FINANCE__PASSWORD') }}" in raw["endpoint"]
    assert raw["endpoint"].endswith("@oracle-host:1521/?service_name=XEPDB1")
    assert raw["spec"] == {"kind": "sql"}
    assert raw["auth"]["type"] == "none"

    env_text = (workspace / ".env").read_text()
    assert "FINANCE__USERNAME=" in env_text
    assert "FINANCE__PASSWORD=" in env_text


def test_source_add_sql_rejects_userinfo_in_url(
    workspace: Path, cli_runner: CliRunner
) -> None:
    cli_runner.invoke(app, ["init"])
    result = cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "finance",
            "--type",
            "sql",
            "--url",
            "oracle+oracledb://scott:tiger@oracle-host:1521/?service_name=XEPDB1",
        ],
    )
    assert result.exit_code == 2, result.stdout + result.stderr
    assert "credentials" in (result.stdout + result.stderr).lower()


def test_source_add_sql_rejects_auth_flag(
    workspace: Path, cli_runner: CliRunner
) -> None:
    cli_runner.invoke(app, ["init"])
    result = cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "finance",
            "--type",
            "sql",
            "--url",
            "oracle+oracledb://oracle-host:1521/?service_name=XE",
            "--auth",
            "basic",
        ],
    )
    assert result.exit_code == 2
    msg = (result.stdout + result.stderr).lower()
    assert "auth" in msg and "sql" in msg
```

- [ ] **Step 2: Run tests; confirm they fail**

Run: `uv run pytest tests/integration/test_cli_source_add.py -v -k sql`

Expected: failures — the URL is written verbatim today, no env templating, no userinfo rejection, no auth-flag rejection.

- [ ] **Step 3: Update `_source_yml_template` and `source_add` in `cli.py`**

In `src/das_cli/cli.py`, replace the existing `_source_yml_template` function (lines 247-275) with:

```python
def _source_yml_template(name: str, source_type: str, url: str, auth_type: str) -> str:
    prefix = _source_env_prefix(name)

    if source_type == "sql":
        # See ADR-0018: SQL credentials live in the URL via env_var(); auth block is no-op.
        templated = _inject_env_var_userinfo(url, prefix)
        return (
            f"type: sql\n"
            f"endpoint: \"{templated}\"\n"
            f"spec:\n  kind: sql\n"
            f"auth:\n  type: none\n"
            f"ownership:\n  team: data-platform\n"
        )

    auth_block = "  type: none"
    if auth_type == "bearer":
        auth_block = f"  type: bearer\n  token: \"{{{{ env_var('{prefix}__TOKEN') }}}}\""
    elif auth_type == "basic":
        auth_block = (
            "  type: basic\n"
            f"  username: \"{{{{ env_var('{prefix}__USERNAME') }}}}\"\n"
            f"  password: \"{{{{ env_var('{prefix}__PASSWORD') }}}}\""
        )
    elif auth_type == "api_key":
        auth_block = f"  type: api_key\n  key: \"{{{{ env_var('{prefix}__API_KEY') }}}}\""

    spec = ""
    if source_type == "odata":
        spec = f"spec:\n  kind: odata\n  metadata_url: {url.rstrip('/')}/$metadata\n"
    elif source_type in {"openapi", "rest"}:
        spec = f"spec:\n  kind: openapi\n  swagger_url: {url.rstrip('/')}/swagger.json\n"
    else:
        spec = "spec:\n  kind: none\n"

    return (
        f"type: {source_type}\n"
        f"endpoint: {url}\n"
        f"{spec}"
        f"auth:\n{auth_block}\n"
        f"ownership:\n  team: data-platform\n"
    )


def _inject_env_var_userinfo(url: str, prefix: str) -> str:
    """Insert env_var('<PREFIX>__USERNAME'):env_var('<PREFIX>__PASSWORD') into a SQLAlchemy URL.

    The input URL must NOT already contain userinfo. `_validate_sql_url` enforces
    this contract before this helper is called.
    """
    scheme, _, rest = url.partition("://")
    user = f"{{{{ env_var('{prefix}__USERNAME') }}}}"
    pw = f"{{{{ env_var('{prefix}__PASSWORD') }}}}"
    return f"{scheme}://{user}:{pw}@{rest}"


def _validate_sql_url(url: str) -> str | None:
    """Return None if the URL is OK, else an error message describing the problem.

    The URL must contain `://` and must NOT contain userinfo (`user:pass@host`).
    """
    if "://" not in url:
        return "SQL --url must be a SQLAlchemy URL with `<dialect>://<host>...` shape."
    _, _, rest = url.partition("://")
    host_part = rest.split("/", 1)[0]
    if "@" in host_part:
        return (
            "SQLAlchemy URLs in --url must not contain credentials; das will "
            "template them via env_var. Set credentials in .env after `source add`."
        )
    return None
```

Now extend `source_add` (lines 278-322). Replace the validation-and-write block with the version below. The existing first three lines (imports + `if type_ not in _VALID_SOURCE_TYPES`) stay; the new content sits between the `_VALID_AUTH_TYPES` check and `src_dir.mkdir`:

```python
    if type_ not in _VALID_SOURCE_TYPES:
        die(f"Unknown --type '{type_}'. Choose from: {sorted(_VALID_SOURCE_TYPES)}", code=USAGE)
    if auth not in _VALID_AUTH_TYPES:
        die(f"Unknown --auth '{auth}'. Choose from: {sorted(_VALID_AUTH_TYPES)}", code=USAGE)

    if type_ == "sql":
        if auth != "none":
            die(
                "--auth is not used for sql sources; credentials are templated "
                "into the endpoint URL.",
                code=USAGE,
            )
        url_err = _validate_sql_url(url)
        if url_err is not None:
            die(url_err, code=USAGE)

    src_dir = Path("contracts") / name
    if src_dir.exists():
        die(f"Source already exists at {src_dir}", code=GENERIC)

    if (auth != "none" or type_ == "sql") and not _source_env_prefix(name):
        die(
            f"Source name '{name}' has no alphanumeric characters; "
            "cannot derive an env-var prefix.",
            code=USAGE,
        )

    src_dir.mkdir(parents=True, exist_ok=False)
    (src_dir / "_source.yml").write_text(_source_yml_template(name, type_, url, auth))
    info(f"wrote {src_dir}/_source.yml")

    env_path = Path(".env")
    # SQL sources always need username/password env entries; reuse the basic-auth shape.
    effective_auth_for_env = "basic" if type_ == "sql" else auth
    status = _append_source_env_block(env_path, name, effective_auth_for_env)
    if status == "wrote":
        info(f"wrote {env_path}")
    elif status == "appended":
        info(f"appended {name} block to {env_path}")
    elif status == "skipped":
        info(f"{env_path} already contains {name} block; not modified")

    success(f"source '{name}' added")
```

- [ ] **Step 4: Run new tests; confirm green**

Run: `uv run pytest tests/integration/test_cli_source_add.py -v`

Expected: all tests pass (existing + the three new SQL tests).

- [ ] **Step 5: Run full suite + lint + types**

Run: `uv run pytest -q && uv run pre-commit run --all-files`

Expected: green.

- [ ] **Step 6: Commit**

```bash
git add src/das_cli/cli.py tests/integration/test_cli_source_add.py
git commit -m "$(cat <<'EOF'
feat(cli): templated env_var credentials for sql sources in source add

`das source add --type sql --url <DSN>` now rejects userinfo in --url,
auto-templates {{ env_var('PREFIX__USERNAME/PASSWORD') }} into the
endpoint, generates a basic-auth-shaped .env block, and rejects --auth.
See ADR-0018.

https://claude.ai/code/session_01ERzWp1HTdXLik89ZRfw2w4
EOF
)"
```

---

## Task 7: Doctor note for SQL sources

Lightweight check — URL parses, dialect's driver wheel is importable. No connection attempt. Mirrors the DuckLake doctor note added in #22.

**Files:**
- Modify: `src/das_cli/doctor.py`
- Modify: `tests/integration/test_cli_doctor.py`

- [ ] **Step 1: Write a failing doctor test**

Append to `tests/integration/test_cli_doctor.py`:

```python
def test_doctor_flags_unparseable_sql_endpoint(
    workspace: Path, cli_runner: CliRunner
) -> None:
    cli_runner.invoke(app, ["init"])
    src_dir = workspace / "contracts" / "demo"
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(
        "type: sql\n"
        "endpoint: not-a-url\n"
        "spec:\n  kind: sql\n"
        "auth:\n  type: none\n"
    )
    result = cli_runner.invoke(app, ["doctor"])
    # exit code 6 == DOCTOR_FAILURE per src/das_cli/exit_codes.py
    assert result.exit_code != 0
    assert "demo" in (result.stdout + result.stderr)
    assert "endpoint" in (result.stdout + result.stderr).lower()


def test_doctor_passes_for_valid_sqlite_url(
    workspace: Path, cli_runner: CliRunner
) -> None:
    cli_runner.invoke(app, ["init"])
    src_dir = workspace / "contracts" / "demo"
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(
        f"type: sql\n"
        f"endpoint: sqlite:///{workspace / 'demo.sqlite'}\n"
        f"spec:\n  kind: sql\n"
        f"auth:\n  type: none\n"
    )
    result = cli_runner.invoke(app, ["doctor"])
    assert result.exit_code == 0, result.stdout + result.stderr
```

(If the existing test file does not import `app` and the `workspace`/`cli_runner` fixtures, mirror the imports at the top of an existing test in the file.)

- [ ] **Step 2: Run; confirm the first test fails**

Run: `uv run pytest tests/integration/test_cli_doctor.py -v -k sql`

Expected: the "unparseable URL" test fails because doctor doesn't currently validate SQL endpoints.

- [ ] **Step 3: Add the SQL doctor check**

In `src/das_cli/doctor.py`, locate the `for src in discover_sources(...)` loop. Just inside that loop, after the `scfg = load_source_config(...)` call, add a SQL-specific branch. Replace the entire loop body with:

```python
        try:
            scfg = load_source_config(src.path / "_source.yml")
        except Exception as e:
            issues.append(DoctorIssue(f"source/{src.name}", f"_source.yml invalid: {e}"))
            continue

        if scfg.type == "sql":
            # See ADR-0018: lightweight URL + driver-importability check.
            from sqlalchemy.engine.url import make_url

            try:
                url = make_url(scfg.endpoint)
            except Exception as e:
                issues.append(
                    DoctorIssue(
                        f"source/{src.name}",
                        f"sql endpoint URL did not parse: {e}",
                    )
                )
                continue
            try:
                url.get_dialect().dbapi()
            except ImportError as e:
                issues.append(
                    DoctorIssue(
                        f"source/{src.name}",
                        f"sql driver for dialect '{url.drivername}' not importable: {e}",
                    )
                )
            except Exception as e:
                # Some dialects validate further on dbapi() (eg. odbc driver string).
                issues.append(
                    DoctorIssue(
                        f"source/{src.name}",
                        f"sql driver for dialect '{url.drivername}' check failed: {e}",
                    )
                )
            continue

        spec_url = scfg.spec.metadata_url or scfg.spec.swagger_url
        if spec_url:
            try:
                resp = requests.get(spec_url, timeout=10)
                if resp.status_code >= 400:
                    issues.append(
                        DoctorIssue(
                            f"source/{src.name}",
                            f"spec URL {spec_url} returned {resp.status_code}",
                        )
                    )
            except requests.RequestException as e:
                issues.append(DoctorIssue(f"source/{src.name}", f"spec URL unreachable: {e}"))
```

- [ ] **Step 4: Run the doctor tests; confirm green**

Run: `uv run pytest tests/integration/test_cli_doctor.py -v`

Expected: green. The "unparseable URL" test reports an issue; the "valid sqlite URL" test passes (sqlite's dialect is in stdlib).

- [ ] **Step 5: Pre-commit**

Run: `uv run pre-commit run --all-files`

Expected: clean.

- [ ] **Step 6: Commit**

```bash
git add src/das_cli/doctor.py tests/integration/test_cli_doctor.py
git commit -m "$(cat <<'EOF'
feat(doctor): sanity-check sql source endpoint URL + driver import

URL must parse via sqlalchemy.engine.url.make_url; driver wheel must be
importable via url.get_dialect().dbapi(). Lightweight — no connection
attempt. See ADR-0018.

https://claude.ai/code/session_01ERzWp1HTdXLik89ZRfw2w4
EOF
)"
```

---

## Task 8: E2E — Oracle Free via testcontainers

Real Oracle container, real schema, real CLI happy path. Behind `@pytest.mark.e2e`.

**Files:**
- Modify: `pyproject.toml` (add `testcontainers[oracle]>=4.0` and `oracledb>=2.0` to dev deps)
- Create: `tests/e2e/fixtures/sql_seed_oracle.sql`
- Create: `tests/e2e/test_oracle.py`

- [ ] **Step 1: Add the dev deps**

In `pyproject.toml`, modify the `dev` dependency group (lines 30-40). Replace it with:

```toml
[dependency-groups]
dev = [
    "pytest>=8.0",
    "pytest-cov>=5.0",
    "pytest-xdist>=3.5",
    "responses>=0.25",
    "ruff>=0.5",
    "mypy>=1.10",
    "pre-commit>=3.7",
    "types-PyYAML>=6.0",
    "types-requests>=2.31",
    "testcontainers[oracle,mssql]>=4.0",
    "oracledb>=2.0",
    "pyodbc>=5.0",
]
```

Run: `uv sync`

Expected: succeeds. If `testcontainers[oracle,mssql]` rejects either extra (the package's extra names changed in 4.x), use `testcontainers[oracle]>=4.0` and `testcontainers[mssql]>=4.0` on separate lines, or fall back to `testcontainers>=4.0` plus dialect modules pinned individually as the package docs recommend at the time of running. The names `OracleContainer` and `MsSqlContainer` are stable across the `testcontainers-python` 4.x series.

- [ ] **Step 2: Write the seed SQL**

Create `tests/e2e/fixtures/sql_seed_oracle.sql`:

```sql
-- Seed schema for the Oracle e2e test. See ADR-0018.
-- Owner is the connection user (gvenzl image's APPUSER).

CREATE TABLE customers (
  customer_id   NUMBER(10) PRIMARY KEY,
  name          VARCHAR2(100) NOT NULL,
  created_at    TIMESTAMP NOT NULL,
  updated_at    TIMESTAMP NOT NULL
);

CREATE TABLE orders (
  order_id      NUMBER(10),
  line_no       NUMBER(5),
  customer_id   NUMBER(10) NOT NULL,
  amount        NUMBER(12, 2) NOT NULL,
  PRIMARY KEY (order_id, line_no)
);

CREATE TABLE attachments (
  attachment_id NUMBER(10) PRIMARY KEY,
  payload       BLOB
);

INSERT INTO customers (customer_id, name, created_at, updated_at)
VALUES (1, 'Ada Lovelace', TIMESTAMP '2026-04-01 10:00:00', TIMESTAMP '2026-05-01 10:00:00');
INSERT INTO customers (customer_id, name, created_at, updated_at)
VALUES (2, 'Linus Torvalds', TIMESTAMP '2026-04-02 10:00:00', TIMESTAMP '2026-05-02 10:00:00');
INSERT INTO customers (customer_id, name, created_at, updated_at)
VALUES (3, 'Grace Hopper', TIMESTAMP '2026-04-03 10:00:00', TIMESTAMP '2026-05-03 10:00:00');

INSERT INTO orders (order_id, line_no, customer_id, amount) VALUES (100, 1, 1, 19.99);
INSERT INTO orders (order_id, line_no, customer_id, amount) VALUES (100, 2, 1, 29.50);
INSERT INTO orders (order_id, line_no, customer_id, amount) VALUES (101, 1, 2, 9.00);

INSERT INTO attachments (attachment_id, payload)
VALUES (1, UTL_RAW.CAST_TO_RAW('hello'));

COMMIT;
```

- [ ] **Step 3: Write the e2e test**

Create `tests/e2e/test_oracle.py`:

```python
"""E2E: das against an Oracle Free container. See ADR-0018.

Opt-in via `pytest -m e2e`. Requires Docker.
"""

from __future__ import annotations

import base64
from pathlib import Path
from typing import Iterator

import duckdb
import pytest
from typer.testing import CliRunner

from das_cli.cli import app


@pytest.fixture(scope="module")
def oracle_url() -> Iterator[str]:
    """Spin gvenzl/oracle-free:slim-faststart, run the seed, yield a SQLAlchemy URL."""
    pytest.importorskip("testcontainers.oracle")
    from testcontainers.oracle import OracleDbContainer

    seed_sql = (
        Path(__file__).parent / "fixtures" / "sql_seed_oracle.sql"
    ).read_text()

    container = OracleDbContainer("gvenzl/oracle-free:slim-faststart")
    container.start()
    try:
        # OracleDbContainer's get_connection_url() returns oracle+oracledb://...
        url = container.get_connection_url()

        # Apply the seed via sqlalchemy.
        from sqlalchemy import create_engine, text

        engine = create_engine(url)
        with engine.begin() as conn:
            for stmt in [s.strip() for s in seed_sql.split(";") if s.strip()]:
                if stmt.upper().startswith("COMMIT") or stmt.startswith("--"):
                    continue
                conn.execute(text(stmt))
        engine.dispose()
        yield url
    finally:
        container.stop()


def test_oracle_bootstrap_extract_load(
    workspace: Path, cli_runner: CliRunner, oracle_url: str
) -> None:
    cli_runner.invoke(app, ["init"])

    # Use --type sql with a clean URL; das templates env_var() into the YAML.
    # Then we override the env vars to the actual container creds before extract.
    # The container URL has the form:
    #   oracle+oracledb://USER:PASS@host:port/?service_name=FREEPDB1
    # We need to strip user:pass and pass them via env vars.
    from sqlalchemy.engine.url import make_url

    parsed = make_url(oracle_url)
    user = parsed.username or ""
    password = parsed.password or ""
    clean_url = parsed.set(username=None, password=None).render_as_string(hide_password=False)

    add = cli_runner.invoke(
        app,
        ["source", "add", "demo", "--type", "sql", "--url", clean_url],
    )
    assert add.exit_code == 0, add.stdout + add.stderr

    # Set credentials via env so Jinja env_var() resolves at load time.
    import os
    os.environ["DEMO__USERNAME"] = user
    os.environ["DEMO__PASSWORD"] = password
    try:
        boot = cli_runner.invoke(app, ["contract", "bootstrap", "demo"])
        assert boot.exit_code == 0, boot.stdout + boot.stderr

        ext = cli_runner.invoke(app, ["extract", "demo"])
        assert ext.exit_code == 0, ext.stdout + ext.stderr

        load = cli_runner.invoke(app, ["load", "demo"])
        assert load.exit_code == 0, load.stdout + load.stderr
    finally:
        os.environ.pop("DEMO__USERNAME", None)
        os.environ.pop("DEMO__PASSWORD", None)

    # Read DuckDB destination — verify rows landed.
    db = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        rows = db.execute('SELECT COUNT(*) FROM "das__demo".customers').fetchone()
        assert rows is not None and rows[0] == 3, rows

        order_rows = db.execute('SELECT COUNT(*) FROM "das__demo".orders').fetchone()
        assert order_rows is not None and order_rows[0] == 3, order_rows

        att = db.execute(
            'SELECT payload FROM "das__demo".attachments WHERE attachment_id = 1'
        ).fetchone()
        assert att is not None
        # BLOB round-trips through base64 — decoded matches the seed.
        assert base64.b64decode(att[0]) == b"hello"
    finally:
        db.close()


def test_oracle_second_extract_uses_cursor(
    workspace: Path, cli_runner: CliRunner, oracle_url: str
) -> None:
    """Second extract pulls only rows newer than the cursor state."""
    import os
    from sqlalchemy import create_engine, text
    from sqlalchemy.engine.url import make_url

    parsed = make_url(oracle_url)
    user = parsed.username or ""
    password = parsed.password or ""
    clean_url = parsed.set(username=None, password=None).render_as_string(hide_password=False)

    cli_runner.invoke(app, ["init"])
    add = cli_runner.invoke(
        app, ["source", "add", "demo", "--type", "sql", "--url", clean_url]
    )
    assert add.exit_code == 0

    os.environ["DEMO__USERNAME"] = user
    os.environ["DEMO__PASSWORD"] = password
    try:
        cli_runner.invoke(app, ["contract", "bootstrap", "demo"])
        first = cli_runner.invoke(app, ["extract", "demo", "--resource", "customers"])
        assert first.exit_code == 0, first.stdout + first.stderr

        # Insert one new customer with a later updated_at.
        engine = create_engine(oracle_url)
        with engine.begin() as conn:
            conn.execute(
                text(
                    "INSERT INTO customers (customer_id, name, created_at, updated_at) "
                    "VALUES (4, 'Margaret Hamilton', "
                    "TIMESTAMP '2026-06-01 10:00:00', TIMESTAMP '2026-06-01 10:00:00')"
                )
            )
        engine.dispose()

        second = cli_runner.invoke(app, ["extract", "demo", "--resource", "customers"])
        assert second.exit_code == 0, second.stdout + second.stderr

        load = cli_runner.invoke(app, ["load", "demo", "--resource", "customers"])
        assert load.exit_code == 0, load.stdout + load.stderr
    finally:
        os.environ.pop("DEMO__USERNAME", None)
        os.environ.pop("DEMO__PASSWORD", None)

    db = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        rows = db.execute('SELECT COUNT(*) FROM "das__demo".customers').fetchone()
        assert rows is not None and rows[0] == 4, rows
    finally:
        db.close()
```

- [ ] **Step 4: Run the e2e Oracle tests**

Run: `uv run pytest -m e2e tests/e2e/test_oracle.py -v`

Expected: both tests pass. First run downloads the gvenzl image (~2GB; subsequent runs are cached). If the container fails to start with `wait_for_logs` timing out, raise the timeout: `OracleDbContainer("gvenzl/oracle-free:slim-faststart").with_kwargs(startup_timeout=180)` (or whatever the testcontainers 4.x kwarg is named in your installed version).

If the test fails because dlt's `sql_table` fails to read Oracle's `BLOB` (some dlt versions need explicit type adapters), narrow the test seed to drop the `attachments` insert and assert only `customers`/`orders` first. Then file a follow-up issue against dlt — do not silently strip BLOB coverage from the design. Update the spec's risk surface section if so.

- [ ] **Step 5: Run unit + integration to confirm no collateral**

Run: `uv run pytest -q`

Expected: green (e2e is not collected by default).

- [ ] **Step 6: Commit**

```bash
git add pyproject.toml uv.lock tests/e2e/fixtures/sql_seed_oracle.sql tests/e2e/test_oracle.py
git commit -m "$(cat <<'EOF'
test(e2e): verify SQL source against Oracle Free in testcontainers

Two tests: full bootstrap → extract → load round-trip with BLOB
base64 round-trip; cursor-driven incremental on a second run picks
up only new rows. Behind @pytest.mark.e2e. See ADR-0018.

https://claude.ai/code/session_01ERzWp1HTdXLik89ZRfw2w4
EOF
)"
```

---

## Task 9: E2E — SQL Server 2022 via testcontainers + pyodbc

Same shape as Task 8. Adds the `apt-get` step to CI's e2e workflow.

**Files:**
- Modify: `.github/workflows/ci.yml` (e2e job: install msodbcsql18 + unixodbc-dev)
- Create: `tests/e2e/fixtures/sql_seed_sqlserver.sql`
- Create: `tests/e2e/test_sqlserver.py`

- [ ] **Step 1: Update CI to install ODBC Driver 18 in the e2e job**

In `.github/workflows/ci.yml`, replace the `e2e` job (lines 34-44) with:

```yaml
  e2e:
    if: github.ref == 'refs/heads/main' || contains(github.event.pull_request.labels.*.name, 'e2e')
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v3
        with:
          enable-cache: true
      - run: uv python install 3.12
      - run: uv sync
      - name: Install Microsoft ODBC Driver 18
        run: |
          curl -fsSL https://packages.microsoft.com/keys/microsoft.asc | sudo gpg --dearmor -o /usr/share/keyrings/microsoft.gpg
          echo "deb [arch=amd64,arm64 signed-by=/usr/share/keyrings/microsoft.gpg] https://packages.microsoft.com/ubuntu/$(lsb_release -rs)/prod $(lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/mssql-release.list
          sudo apt-get update
          sudo ACCEPT_EULA=Y apt-get install -y msodbcsql18 unixodbc-dev
      - run: uv run pytest -m e2e
```

- [ ] **Step 2: Write the seed SQL**

Create `tests/e2e/fixtures/sql_seed_sqlserver.sql`:

```sql
-- Seed schema for the SQL Server e2e test. See ADR-0018.
-- Runs against the dbo schema in the default database (master).

CREATE TABLE customers (
  customer_id   BIGINT NOT NULL PRIMARY KEY,
  name          NVARCHAR(100) NOT NULL,
  created_at    DATETIME2 NOT NULL,
  updated_at    DATETIME2 NOT NULL
);

CREATE TABLE orders (
  order_id      BIGINT NOT NULL,
  line_no       BIGINT NOT NULL,
  customer_id   BIGINT NOT NULL,
  amount        DECIMAL(12, 2) NOT NULL,
  CONSTRAINT pk_orders PRIMARY KEY (order_id, line_no)
);

CREATE TABLE attachments (
  attachment_id BIGINT NOT NULL PRIMARY KEY,
  payload       VARBINARY(MAX) NULL
);

INSERT INTO customers (customer_id, name, created_at, updated_at) VALUES
  (1, 'Ada Lovelace',  '2026-04-01T10:00:00', '2026-05-01T10:00:00'),
  (2, 'Linus Torvalds','2026-04-02T10:00:00', '2026-05-02T10:00:00'),
  (3, 'Grace Hopper',  '2026-04-03T10:00:00', '2026-05-03T10:00:00');

INSERT INTO orders (order_id, line_no, customer_id, amount) VALUES
  (100, 1, 1, 19.99),
  (100, 2, 1, 29.50),
  (101, 1, 2,  9.00);

INSERT INTO attachments (attachment_id, payload) VALUES (1, CONVERT(VARBINARY(MAX), 'hello'));
```

- [ ] **Step 3: Write the e2e test**

Create `tests/e2e/test_sqlserver.py`:

```python
"""E2E: das against a SQL Server 2022 container. See ADR-0018.

Opt-in via `pytest -m e2e`. Requires Docker + msodbcsql18.
"""

from __future__ import annotations

import base64
from pathlib import Path
from typing import Iterator

import duckdb
import pytest
from typer.testing import CliRunner

from das_cli.cli import app


@pytest.fixture(scope="module")
def mssql_url() -> Iterator[str]:
    """Spin SQL Server 2022, run the seed, yield a mssql+pyodbc SQLAlchemy URL."""
    pytest.importorskip("testcontainers.mssql")
    try:
        import pyodbc  # noqa: F401
    except ImportError:
        pytest.skip(
            "pyodbc + Microsoft ODBC Driver 18 not installed; "
            "see https://learn.microsoft.com/en-us/sql/connect/odbc/linux-mac/installing-the-microsoft-odbc-driver-for-sql-server"
        )

    from testcontainers.mssql import SqlServerContainer

    seed_sql = (
        Path(__file__).parent / "fixtures" / "sql_seed_sqlserver.sql"
    ).read_text()

    # SqlServerContainer defaults to mcr.microsoft.com/mssql/server:2022-latest
    container = SqlServerContainer()
    container.start()
    try:
        # SqlServerContainer.get_connection_url() returns mssql+pymssql:// by default
        # in older testcontainers versions. Force pyodbc instead by composing it ourselves.
        host = container.get_container_host_ip()
        port = container.get_exposed_port(1433)
        user = container.SQLSERVER_USER if hasattr(container, "SQLSERVER_USER") else "sa"
        password = container.password if hasattr(container, "password") else container.SQLSERVER_PASSWORD
        url = (
            f"mssql+pyodbc://{user}:{password}@{host}:{port}/master"
            f"?driver=ODBC+Driver+18+for+SQL+Server&Encrypt=no&TrustServerCertificate=yes"
        )

        from sqlalchemy import create_engine, text

        engine = create_engine(url)
        with engine.begin() as conn:
            for stmt in [s.strip() for s in seed_sql.split(";") if s.strip()]:
                if stmt.startswith("--"):
                    continue
                conn.execute(text(stmt))
        engine.dispose()
        yield url
    finally:
        container.stop()


def test_sqlserver_bootstrap_extract_load(
    workspace: Path, cli_runner: CliRunner, mssql_url: str
) -> None:
    import os
    from sqlalchemy.engine.url import make_url

    parsed = make_url(mssql_url)
    user = parsed.username or ""
    password = parsed.password or ""
    clean_url = parsed.set(username=None, password=None).render_as_string(hide_password=False)

    cli_runner.invoke(app, ["init"])
    add = cli_runner.invoke(
        app, ["source", "add", "demo", "--type", "sql", "--url", clean_url]
    )
    assert add.exit_code == 0, add.stdout + add.stderr

    os.environ["DEMO__USERNAME"] = user
    os.environ["DEMO__PASSWORD"] = password
    try:
        boot = cli_runner.invoke(app, ["contract", "bootstrap", "demo"])
        assert boot.exit_code == 0, boot.stdout + boot.stderr

        ext = cli_runner.invoke(app, ["extract", "demo"])
        assert ext.exit_code == 0, ext.stdout + ext.stderr

        load = cli_runner.invoke(app, ["load", "demo"])
        assert load.exit_code == 0, load.stdout + load.stderr
    finally:
        os.environ.pop("DEMO__USERNAME", None)
        os.environ.pop("DEMO__PASSWORD", None)

    db = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        rows = db.execute('SELECT COUNT(*) FROM "das__demo".customers').fetchone()
        assert rows is not None and rows[0] == 3

        order_rows = db.execute('SELECT COUNT(*) FROM "das__demo".orders').fetchone()
        assert order_rows is not None and order_rows[0] == 3

        att = db.execute(
            'SELECT payload FROM "das__demo".attachments WHERE attachment_id = 1'
        ).fetchone()
        assert att is not None
        assert base64.b64decode(att[0]) == b"hello"
    finally:
        db.close()
```

- [ ] **Step 4: Run the e2e MSSQL test**

Run: `uv run pytest -m e2e tests/e2e/test_sqlserver.py -v`

Expected: passes. First run pulls `mcr.microsoft.com/mssql/server:2022-latest` (~1.5GB). If pyodbc isn't installed locally, the test skips with a pointer to Microsoft's install docs.

If the test fails inside `SqlServerContainer.start()` because the testcontainers default password doesn't satisfy SQL Server's complexity rules, set an explicit password: `SqlServerContainer(password="Strong!Passw0rd")`. The container's image enforces 8+ chars with three of: upper, lower, digit, symbol.

- [ ] **Step 5: Run unit + integration to confirm no collateral**

Run: `uv run pytest -q`

Expected: green.

- [ ] **Step 6: Commit**

```bash
git add .github/workflows/ci.yml tests/e2e/fixtures/sql_seed_sqlserver.sql tests/e2e/test_sqlserver.py
git commit -m "$(cat <<'EOF'
test(e2e): verify SQL source against SQL Server 2022 + pyodbc

Same shape as the Oracle e2e: bootstrap → extract → load with BLOB
round-trip. CI's e2e job installs Microsoft ODBC Driver 18 +
unixodbc-dev. See ADR-0018.

https://claude.ai/code/session_01ERzWp1HTdXLik89ZRfw2w4
EOF
)"
```

---

## Task 10: ADR-0018 + README + ADR index

The doc work that hardens the decisions and lists the new verified rows.

**Files:**
- Create: `docs/adrs/0018-sql-source-via-sqlalchemy.md`
- Modify: `docs/adrs/README.md`
- Modify: `README.md`

- [ ] **Step 1: Write ADR-0018**

Create `docs/adrs/0018-sql-source-via-sqlalchemy.md`:

```markdown
# 0017. SQL source via SQLAlchemy reflection

- **Status:** Accepted
- **Date:** 2026-05-08
- **Deciders:** mattiasthalen

## Context

das-cli's v0.1 design listed `type: sql` as a placeholder — `dlt.sources.
sql_database` driven by `_source.yml` connection — but nothing was
implemented. `models/source_yml.py` accepted `sql` as a literal source
type; `dlt_glue/source_factory.py` raised `UnknownSourceTypeError` for
it. Issues #31 (Oracle) and #32 (SQL Server) ask to verify a SQL source.
Verifying each independently would have meant two near-duplicate ADRs,
two source-factory builders, and two seed-data fixtures for the same
plumbing. dlt's `sql_database` source is driver-agnostic on the read
side via SQLAlchemy, so adding both at once is strictly cheaper.

## Decision

**Decision A: source dispatch lives as a small `_build_sql_resources`
branch in `dlt_glue/source_factory.py`,** alongside the existing HTTP
branch. No registry, no plugin layer — same dispatch shape ADR-0016
chose for destinations. Adding a future SQL dialect to the verified
matrix is a driver-extra change in `pyproject.toml` plus an e2e test;
no new code path.

**Decision B: bootstrap reflects schemas via SQLAlchemy
`MetaData.reflect`.** das-cli does not own per-dialect catalog SQL.
Type mapping covers SQLAlchemy generic types only; dialect-specific
types fall back to `logicalType: string` with a `bootstrap`-time
warning. SQLAlchemy already dispatches the right catalog query per
dialect (`information_schema.columns` for Postgres / MySQL / MSSQL,
`ALL_TAB_COLUMNS` + `ALL_CONSTRAINTS` for Oracle, `sqlite_master` for
SQLite); reimplementing that would duplicate work for no offsetting
benefit.

**Decision C: SQL connection URL lives in `_source.yml.endpoint`,**
templated with Jinja `env_var(...)` for credentials. Symmetric with
ADR-0016's URL-passthrough convention for DuckLake's `catalog`. The
`auth` block is no-op for SQL sources — the URL holds the credentials.
`das source add --type sql` rejects URLs that contain userinfo and
auto-templates `{{ env_var('PREFIX__USERNAME') }}` and
`{{ env_var('PREFIX__PASSWORD') }}` into the URL written to disk,
generating a basic-auth-shaped `.env` block alongside.

**Decision D: SQL Server uses `mssql+pyodbc` + Microsoft ODBC Driver 18.**
Long-standing primary path pre-mssql-python; full Azure / Entra ID
support; dlt's MSSQL examples reference it. CI's e2e job installs
`msodbcsql18` and `unixodbc-dev` via apt; local devs running e2e
need the same.

## Alternatives considered

- **Registry-style source dispatch** (a `SOURCE_BUILDERS: dict[str,
  Builder]`). Rejected for the same reason ADR-0016 rejected it for
  destinations: duplicates dlt's own abstraction; each new source
  would be two registrations for no gain.
- **Per-dialect catalog SQL we own** (`information_schema.columns`,
  `ALL_TAB_COLUMNS`, etc.). Rejected: reimplements SQLAlchemy
  reflection. SQLAlchemy is already a runtime dependency via
  `dlt[sql_database]`.
- **`das.query` custom-query resources** (compute one resource from
  an arbitrary SELECT). Deferred. One-resource-per-table covers the
  verification surface; a v2 follow-up can layer queries on top.
- **`pymssql` for MSSQL.** Considered: SQLAlchemy 2.x supports it,
  CI footprint is slimmer (no system deps). Rejected because Microsoft
  does not recommend it, Azure SQL is painful (default wheels lack SSL
  bindings), and maintenance is sparse.
- **`mssql-python` (Microsoft's new in-house GA driver).** Considered:
  faster than pyodbc per Microsoft's benchmarks. Rejected because no
  SQLAlchemy dialect ships for it as of this writing, so it cannot
  plug into `dlt.sources.sql_database` without an upstream contribution.
  Out of scope; revisit when a dialect ships.
- **Discrete connection flags** (`--driver`, `--host`, `--port`,
  `--service`, `--username`). Rejected: reimplements SQLAlchemy's URL
  builder; per-dialect quirks (Oracle TNS, MSSQL ODBC `driver=` query
  param) make a unified flag set ugly.

## Consequences

- das-cli now imports SQLAlchemy and the `dlt[sql_database]` extra at
  runtime. Per-source driver wheels (`oracledb`, `pyodbc`) are the
  user's responsibility — pyproject lists them only in the dev group
  for tests; the README quickstart documents the install.
- `_build_sql_resources` is the second branch in
  `build_extract_resources`; the function is no longer
  HTTP-or-die. Adding e.g. Postgres-as-source is a driver-wheel and
  e2e-test change.
- Locks in SQLAlchemy reflection as a contract surface. A dialect
  without reflection support could not be bootstrapped without
  per-dialect catalog SQL, which would require revisiting this ADR.
- The `auth` block carries no SQL credentials — credentials live in the
  URL. This breaks symmetry with HTTP auth blocks but fits the
  passthrough-to-dlt philosophy ADR-0016 established for destinations.
- E2E coverage requires Docker + driver wheels (`oracledb`, `pyodbc` +
  ODBC Driver 18). The default `pytest` invocation (without `-m e2e`)
  does not need any of that.
```

- [ ] **Step 2: Append the new ADR row to the index**

In `docs/adrs/README.md`, append after line 25 (the ADR-0016 row):

```markdown
| 0017 | SQL source via SQLAlchemy reflection | Accepted |
```

- [ ] **Step 3: Update the README "Verified" matrix**

In `README.md`, locate the Verified matrix (around lines 88-95). Replace it with:

```markdown
### Verified

| Source              | Destination | Notes                                          |
|---------------------|-------------|------------------------------------------------|
| OData v2 / v4       | DuckDB      | OData metadata bootstrap (ADR-0006)            |
| OpenAPI / REST      | DuckDB      | Per-resource `das.endpoint` (ADR-0014, 0015)   |
| OData v2 / v4       | DuckLake    | Local DuckDB-file catalog (ADR-0016)           |
| OpenAPI / REST      | DuckLake    | Local DuckDB-file catalog (ADR-0016)           |
| Oracle (oracledb)   | DuckDB      | SQLAlchemy reflection (ADR-0018)               |
| SQL Server (pyodbc) | DuckDB      | SQLAlchemy reflection (ADR-0018); ODBC 18      |
```

- [ ] **Step 4: Add a SQL example block to the Quickstart**

In `README.md`, append after the existing Quickstart example (after the `das ingest adventureworks` line, around line 55):

````markdown

For a SQL source (Oracle/SQL Server/Postgres/MySQL/SQLite), pass a
SQLAlchemy URL with no credentials — das templates `env_var(...)` for
username/password into `_source.yml` and writes a matching `.env`
block. The driver wheel is your responsibility:

```bash
uv tool install das-cli --with oracledb       # or --with pyodbc

das source add finance \
  --type sql \
  --url "oracle+oracledb://oracle-host:1521/?service_name=XEPDB1"
# Edit .env: set FINANCE__USERNAME / FINANCE__PASSWORD.
das contract bootstrap finance
das ingest finance
```
````

- [ ] **Step 5: Pre-commit (lint + types)**

Run: `uv run pre-commit run --all-files`

Expected: clean.

- [ ] **Step 6: Pre-merge ADR sync check (per CLAUDE.md)**

Run:

```bash
git fetch origin main
git rebase origin/main
head -1 docs/adrs/0*.md | grep -E "^(==|# )"
```

Expected: every ADR file has a matching row in `docs/adrs/README.md`. If a number collides with an ADR already on `main`, renumber the branch's ADR (renumbering is allowed pre-merge per CLAUDE.md's lifecycle policy) and update the index row + the inline `# See ADR-NNNN` comments in `bootstrap/sql.py`, `dlt_glue/source_factory.py`, `cli.py`, and `doctor.py`.

- [ ] **Step 7: Verify all done-criteria from the spec**

Run:

```bash
uv run pytest -q                               # unit + integration must pass
uv run pytest -m e2e tests/e2e/test_oracle.py tests/e2e/test_sqlserver.py -v  # e2e
uv run pre-commit run --all-files              # lint + mypy strict
grep -E "Oracle|SQL Server" README.md          # matrix rows present
ls docs/adrs/0018-sql-source-via-sqlalchemy.md # ADR file exists
grep "0017" docs/adrs/README.md                # ADR index row present
```

Expected: every command exits 0 / produces the expected match.

- [ ] **Step 8: Commit + push**

```bash
git add docs/adrs/0018-sql-source-via-sqlalchemy.md docs/adrs/README.md README.md
git commit -m "$(cat <<'EOF'
docs(adrs): file ADR-0018 SQL source via SQLAlchemy; update README matrix

Adds ADR-0018 covering source dispatch, SQLAlchemy reflection, URL-as-
endpoint, and the mssql+pyodbc decision. README "Verified" matrix gains
Oracle and SQL Server rows against DuckDB. Quickstart documents the
SQL source flow.

Closes #31, closes #32.

https://claude.ai/code/session_01ERzWp1HTdXLik89ZRfw2w4
EOF
)"

git push -u origin claude/brainstorm-issue-31-85hF3
```

---

## Final verification

After Task 10 commits, the branch must satisfy every "Done criteria" item from
`docs/superpowers/specs/2026-05-08-verify-sql-sources-design.md`:

- [x] All existing tests green (unit, integration, e2e). — Task 5 and Task 9 verify.
- [x] New unit tests green: `test_source_factory_sql.py`, `test_bootstrap_sql.py`,
      extended `test_source_yml_model.py`, extended `test_cli_source_add.py`. — Tasks 1, 2, 4, 6.
- [x] New integration tests green: `test_extract_pipeline_sql.py`, `test_bootstrap_sql.py`. — Tasks 3, 5.
- [x] E2E tests green under `pytest -m e2e`: `test_oracle.py`, `test_sqlserver.py`. — Tasks 8, 9.
- [x] README "Verified" matrix lists Oracle and SQL Server against DuckDB. — Task 10.
- [x] `docs/adrs/0018-sql-source-via-sqlalchemy.md` committed; ADR index row added. — Task 10.
- [x] Pre-commit (ruff, mypy strict) clean. — Each task ends with a pre-commit pass.
- [x] Backwards compatibility: existing OData/OpenAPI workspaces, contracts,
      and `_source.yml` files unchanged. — `SpecConfig` validator preserves
      old shapes; `build_extract_resources` HTTP path is untouched; P2 and
      load are not modified at all.
