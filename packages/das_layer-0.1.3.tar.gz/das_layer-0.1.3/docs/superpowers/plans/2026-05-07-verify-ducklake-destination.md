# Verify DuckLake destination Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add DuckLake as the second verified destination, driving P2 destination construction from `cfg.target.destination` and routing change-detection reads through dlt's `pipeline.sql_client()` so das-cli stops importing `duckdb` for read access.

**Architecture:** Light dispatch (`_build_destination` in `pipelines/load.py`) selects the dlt destination by name. Change detection (`load_latest_hash`) reads through the running pipeline's SQL client — destination-agnostic. DuckLake catalog accepts both SQLAlchemy URLs and bare paths (auto-prefixed `duckdb:///`).

**Tech Stack:** Python 3.12, dlt 1.26, DuckDB, DuckLake (dlt destination), pytest, uv, ruff, mypy.

**Spec:** `docs/superpowers/specs/2026-05-07-verify-ducklake-destination-design.md`

**Pre-flight:**
- Wait for issue #21's ADR-index fix to land in `main` and rebase this branch on top before starting Task 1. The user signals when ready. The README/index touches in Task 9 must sit on the cleaned-up index, not the stale one.
- Branch is `claude/assign-first-issue-SZwJB`. All work commits there.

**Universal commands:**
- Run tests: `uv run pytest -q`
- Run a single test: `uv run pytest tests/path/test_x.py::test_y -v`
- E2E (opt-in): `uv run pytest -m e2e -v`
- Lint/format: `uv run ruff check .` and `uv run ruff format .`
- Types: `uv run mypy src tests`
- Pre-commit: `uv run pre-commit run --all-files`

---

## Task 1: Refactor change-detection to use `pipeline.sql_client()` (DuckDB only)

Pure refactor. No new destination yet. The renamed function takes the live pipeline; existing DuckDB tests must stay green at the end of this task.

**Files:**
- Modify: `src/das_cli/pipelines/change_detection.py` (rewrite `load_latest_hash_from_duckdb`)
- Modify: `src/das_cli/pipelines/load.py:25-28` (import rename), `src/das_cli/pipelines/load.py:108-181` (`_build_load_resource` parameter), `src/das_cli/pipelines/load.py:184-272` (`run_load` call site)
- Test (existing, must stay green): `tests/integration/test_load_pipeline.py`

- [ ] **Step 1: Confirm dlt's sql_client is available and returns rows in the expected shape**

Run: `uv run python -c "
import dlt, tempfile, os
from dlt.destinations.exceptions import DatabaseUndefinedRelation
with tempfile.TemporaryDirectory() as td:
    p = dlt.pipeline(pipeline_name='t', destination=dlt.destinations.duckdb(credentials=os.path.join(td, 't.duckdb'), enable_dataset_name_normalization=False), pipelines_dir=os.path.join(td, '.dlt'))
    @dlt.resource(name='items', primary_key='id')
    def items():
        yield {'id': 1, 'name': 'A', '_row_hash': 'abc', '_dlt_load_id': '1'}
    p.run(items, dataset_name='das__test')
    with p.sql_client() as c:
        print(list(c.execute_sql('SELECT id, _row_hash FROM \"das__test\".items')))
    try:
        with p.sql_client() as c:
            list(c.execute_sql('SELECT id FROM \"das__test\".missing'))
    except DatabaseUndefinedRelation as e:
        print('DUR:', type(e).__name__)
"`

Expected: prints `[(1, 'abc')]` then `DUR: DatabaseUndefinedRelation`.

If the API differs in the actual installed dlt, stop and update this plan with the real exception class name before continuing.

- [ ] **Step 2: Rewrite `change_detection.py` to use `pipeline.sql_client()`**

Replace the entire contents of `src/das_cli/pipelines/change_detection.py` with:

```python
"""Per-PK change-detection filter. See ADR-0004 (filter), ADR-0016 (read path)."""

from __future__ import annotations

from collections.abc import Iterable, Iterator
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import dlt


class ChangeDetectionFilter:
    """Yield only rows whose `_row_hash` differs from the latest hash for their PK."""

    def __init__(
        self,
        *,
        primary_key: list[str],
        latest_hash: dict[tuple[Any, ...], str],
    ) -> None:
        self.primary_key = primary_key
        self.latest_hash: dict[tuple[Any, ...], str] = dict(latest_hash)

    def __call__(self, items: Iterable[dict[str, Any]]) -> Iterator[dict[str, Any]]:
        for row in items:
            pk = tuple(row[k] for k in self.primary_key)
            new_hash = row["_row_hash"]
            if self.latest_hash.get(pk) != new_hash:
                self.latest_hash[pk] = new_hash
                yield row


def load_latest_hash(
    *,
    pipeline: "dlt.Pipeline",
    dataset: str,
    table: str,
    primary_key: list[str],
) -> dict[tuple[Any, ...], str]:
    """Latest `_row_hash` per primary key, queried via the destination's SQL client.

    Returns an empty dict if the dataset/table doesn't exist yet (first load).
    Destination-agnostic — works for any dlt destination that exposes
    `pipeline.sql_client()`. See ADR-0016.
    """
    from dlt.destinations.exceptions import DatabaseUndefinedRelation

    pk_cols = ", ".join(f'"{c}"' for c in primary_key)
    sql = f"""
    SELECT {pk_cols}, _row_hash
    FROM "{dataset}"."{table}"
    QUALIFY ROW_NUMBER() OVER (PARTITION BY {pk_cols} ORDER BY _dlt_load_id DESC) = 1
    """
    try:
        with pipeline.sql_client() as client:
            rows = list(client.execute_sql(sql))
    except DatabaseUndefinedRelation:
        return {}
    out: dict[tuple[Any, ...], str] = {}
    for row in rows:
        pk = tuple(row[: len(primary_key)])
        out[pk] = row[-1]
    return out
```

- [ ] **Step 3: Update `load.py` import and `_build_load_resource` signature**

In `src/das_cli/pipelines/load.py`, change the import block at lines 25-28:

```python
from das_cli.pipelines.change_detection import (
    ChangeDetectionFilter,
    load_latest_hash,
)
```

Change the `_build_load_resource` signature at lines 108-118 to take `pipeline` instead of `db_path`:

```python
def _build_load_resource(
    contract: LoadedContract,
    *,
    landing_dir: Path,
    hash_exclude: set[str],
    primary_key: list[str],
    pipeline: dlt.Pipeline,
    dataset: str,
    schema_contract: dict[str, str],
    progress_handle: ProgressHandle | None = None,
) -> Any:
```

Update the call inside the resource body at lines 135-142 to pass the pipeline:

```python
        # Load latest hashes from destination for this resource. See ADR-0016.
        if primary_key:
            latest = load_latest_hash(
                pipeline=pipeline,
                dataset=dataset,
                table=table_name,
                primary_key=primary_key,
            )
            change_filter: ChangeDetectionFilter | None = ChangeDetectionFilter(
                primary_key=primary_key, latest_hash=latest
            )
        else:
            change_filter = None
```

- [ ] **Step 4: Update the `run_load` call site to pass the pipeline through**

In `src/das_cli/pipelines/load.py`, update the `_build_load_resource(...)` invocation around lines 248-257 to pass `pipeline=pipeline` instead of `db_path=db_path`:

```python
            res = _build_load_resource(
                c,
                landing_dir=landing_root / src.name / c.resource_name,
                hash_exclude=hash_exclude,
                primary_key=primary_keys_for(c.contract),
                pipeline=pipeline,
                dataset=dataset,
                schema_contract=schema_contract,
                progress_handle=progress_handle,
            )
```

Leave `db_path = cfg.target.credentials.get(...)` at line 202 alone for now — it's still consumed by the inline `dlt.destinations.duckdb(credentials=db_path, ...)` construction at line 207. Task 2 extracts that construction and removes `db_path` then.

The destination construction at lines 204-215 stays untouched in this task. Task 2 extracts it.

- [ ] **Step 5: Run integration + unit suite to confirm DuckDB path is unchanged**

Run: `uv run pytest tests/integration/test_load_pipeline.py tests/unit -v`

Expected: all pass. The four change-detection tests in particular (`test_load_change_detection_suppresses_duplicate`, `test_load_a_b_a_preserved`, plus the create/row-hash tests) prove the new SQL-client path round-trips identically against DuckDB.

If any test fails, do NOT proceed — diagnose. Common causes: signature/import mismatch, exception class wrong, `execute_sql` returning a different shape than expected.

- [ ] **Step 6: Run full test suite (excluding e2e)**

Run: `uv run pytest -q`

Expected: all pass.

- [ ] **Step 7: Lint, format, type-check**

Run: `uv run ruff check . && uv run ruff format --check . && uv run mypy src tests`

Expected: all green. If `ruff format --check` fails, run `uv run ruff format .` and re-check.

- [ ] **Step 8: Commit**

```bash
git add src/das_cli/pipelines/change_detection.py src/das_cli/pipelines/load.py
git commit -m "refactor(p2): route change-detection reads through pipeline.sql_client

Renames load_latest_hash_from_duckdb -> load_latest_hash. The new
implementation uses dlt's pipeline.sql_client() instead of opening a
direct duckdb connection, so it works for any dlt destination that
exposes the standard SQL client. das-cli no longer imports duckdb for
read access.

Pure refactor. DuckDB-backed integration tests stay green; behavior is
unchanged for the only currently-supported destination. The single
call site in load.py is updated to pass the pipeline through.

See ADR-0016 (filed in a later commit on this branch)."
```

---

## Task 2: Extract `_build_destination` (still DuckDB-only)

Pull the inline destination construction out of `run_load` into a small private function. Still only handles `duckdb`. Pure refactor — DuckDB tests must stay green.

**Files:**
- Modify: `src/das_cli/pipelines/load.py:204-215` (extract function), top of file (imports if needed)
- Test (existing): `tests/integration/test_load_pipeline.py`

- [ ] **Step 1: Add `_build_destination` and use it in `run_load`**

In `src/das_cli/pipelines/load.py`, add this private function above `_project_record` (after the `_TABLES_MODE` constant, around line 38):

```python
def _build_destination(target: "TargetConfig") -> Any:
    """Construct a dlt destination from cfg.target. See ADR-0016.

    Adding a new destination is one branch here plus a `dlt[<extra>]`
    entry in pyproject.toml. enable_dataset_name_normalization=False is
    unconditional — it implements ADR-0008's prefix-preservation policy
    globally, not per-destination.
    """
    name = target.destination
    creds = dict(target.credentials)
    if name == "duckdb":
        return dlt.destinations.duckdb(
            credentials=creds.get("database", "./das.duckdb"),
            enable_dataset_name_normalization=False,
        )
    raise ValueError(
        f"Unsupported target.destination: {name!r}. "
        f"Verified destinations: duckdb."
    )
```

Add the `TargetConfig` import at the top of the file alongside the other model imports — find the existing `from das_cli.config import load_das_config` line and add a sibling import:

```python
from das_cli.models.das_yaml import TargetConfig
```

Replace the inline destination construction at lines 204-215 in `run_load` with a single call, AND remove the `db_path = cfg.target.credentials.get(...)` line above it (line 202) — Task 1 left it in place because the inline construction still consumed it. Now `_build_destination` owns the credential extraction.

```python
    pipeline = dlt.pipeline(  # type: ignore[call-overload]
        pipeline_name="das_load",
        destination=_build_destination(cfg.target),
        pipelines_dir=".dlt/pipelines",
        progress=dlt_progress,
    )
```

- [ ] **Step 2: Run the integration suite**

Run: `uv run pytest tests/integration -v`

Expected: all pass. The duckdb-backed pipeline tests must produce identical results — this task is a pure code-organization refactor.

- [ ] **Step 3: Run full suite + lint + types**

Run: `uv run pytest -q && uv run ruff check . && uv run ruff format --check . && uv run mypy src tests`

Expected: all green.

- [ ] **Step 4: Commit**

```bash
git add src/das_cli/pipelines/load.py
git commit -m "refactor(p2): extract destination construction into _build_destination

Pulls dlt.destinations.duckdb(...) out of run_load and into a small
private dispatch function. Still only handles 'duckdb' — Task 3 adds
the ducklake branch. Adding a new destination is now one branch here
plus a dlt[<extra>] entry in pyproject.toml.

Pure refactor; identical behavior for the only currently-supported
destination. See ADR-0016."
```

---

## Task 3: Unit-test `_build_destination` (DuckDB)

TDD: lock in the dispatch contract with unit tests before the second branch lands. Tests assert on observable destination state — not internal dlt private fields.

**Files:**
- Create: `tests/unit/test_destination_dispatch.py`
- Modify (if needed): nothing — `_build_destination` already imported indirectly via the module

- [ ] **Step 1: Write the unit test file**

Create `tests/unit/test_destination_dispatch.py`:

```python
"""Unit tests for _build_destination dispatch. See ADR-0016."""

from __future__ import annotations

import pytest

from das_cli.models.das_yaml import TargetConfig
from das_cli.pipelines.load import _build_destination


def test_duckdb_dispatch_returns_duckdb_destination() -> None:
    target = TargetConfig(destination="duckdb", credentials={"database": "./test.duckdb"})
    dest = _build_destination(target)
    # dlt destinations expose a destination_type attribute; assert on that.
    assert dest.destination_type == "duckdb"


def test_duckdb_dispatch_forwards_database_path() -> None:
    target = TargetConfig(destination="duckdb", credentials={"database": "./custom.duckdb"})
    dest = _build_destination(target)
    # config_params is the public surface for dlt destination factories.
    assert dest.config_params["credentials"] == "./custom.duckdb"


def test_duckdb_dispatch_defaults_database_when_missing() -> None:
    target = TargetConfig(destination="duckdb", credentials={})
    dest = _build_destination(target)
    assert dest.config_params["credentials"] == "./das.duckdb"


def test_duckdb_dispatch_disables_dataset_name_normalization() -> None:
    target = TargetConfig(destination="duckdb", credentials={"database": "./x.duckdb"})
    dest = _build_destination(target)
    assert dest.config_params["enable_dataset_name_normalization"] is False


def test_unknown_destination_raises_value_error() -> None:
    target = TargetConfig(destination="postgres", credentials={})
    with pytest.raises(ValueError, match="Unsupported target.destination"):
        _build_destination(target)
```

- [ ] **Step 2: Run the new unit tests to verify they pass**

Run: `uv run pytest tests/unit/test_destination_dispatch.py -v`

Expected: all 5 tests pass. If `dest.destination_type` doesn't exist or has a different name, inspect with:

```bash
uv run python -c "
from das_cli.models.das_yaml import TargetConfig
from das_cli.pipelines.load import _build_destination
t = TargetConfig(destination='duckdb', credentials={'database': './x.duckdb'})
d = _build_destination(t)
print('type:', type(d))
print('destination_type:', getattr(d, 'destination_type', None))
print('config_params:', d.config_params)
"
```

Adapt the test assertions to whatever public attributes are present.

- [ ] **Step 3: Lint + types**

Run: `uv run ruff check tests/unit/test_destination_dispatch.py && uv run ruff format --check tests/unit/test_destination_dispatch.py && uv run mypy tests/unit/test_destination_dispatch.py`

Expected: all green.

- [ ] **Step 4: Commit**

```bash
git add tests/unit/test_destination_dispatch.py
git commit -m "test(unit): cover _build_destination dispatch for duckdb

Locks in the dispatch contract: destination_type, credentials forwarding,
default database path, the unconditional enable_dataset_name_normalization=False
flag, and the ValueError on unknown destination names.

Task 4 adds the ducklake branch and parallel test cases. See ADR-0016."
```

---

## Task 4: Add `ducklake` branch + extras + dispatch tests

This is the first task that introduces DuckLake. It adds the dispatch branch, the `dlt[ducklake]` extra, and unit tests covering both the bare-path auto-prefix and the verbatim URL behavior.

**Files:**
- Modify: `pyproject.toml` (extras)
- Modify: `src/das_cli/pipelines/load.py` (`_build_destination`)
- Modify: `tests/unit/test_destination_dispatch.py` (new ducklake tests)
- Modify: `uv.lock` (regenerated by uv sync)

- [ ] **Step 1: Add `ducklake` to dlt extras and sync**

Edit `pyproject.toml`. Find the line:

```
"dlt[duckdb,filesystem,parquet]>=1.0",
```

Replace with:

```
"dlt[duckdb,ducklake,filesystem,parquet]>=1.0",
```

Then sync:

```bash
uv sync
```

Expected: uv resolves and installs `ducklake` extras (likely no new top-level packages on Python 3.12; the ducklake dlt impl is part of dlt itself).

Verify the destination is importable:

```bash
uv run python -c "from dlt.destinations import ducklake; print(ducklake)"
```

Expected: prints the class. If it errors, the extras spelling is wrong — consult `uv run python -c "import dlt; help(dlt.destinations)"` for the actual key.

- [ ] **Step 2: Write failing unit tests for the ducklake dispatch**

Add to `tests/unit/test_destination_dispatch.py` (append below the existing tests):

```python
def test_ducklake_dispatch_returns_ducklake_destination() -> None:
    target = TargetConfig(
        destination="ducklake",
        credentials={"catalog": "./das.ducklake", "storage": "./ducklake_data"},
    )
    dest = _build_destination(target)
    assert dest.destination_type == "ducklake"


def test_ducklake_dispatch_disables_dataset_name_normalization() -> None:
    target = TargetConfig(
        destination="ducklake",
        credentials={"catalog": "./das.ducklake", "storage": "./ducklake_data"},
    )
    dest = _build_destination(target)
    assert dest.config_params["enable_dataset_name_normalization"] is False


def test_ducklake_dispatch_auto_prefixes_bare_catalog_path() -> None:
    target = TargetConfig(
        destination="ducklake",
        credentials={"catalog": "./das.ducklake", "storage": "./ducklake_data"},
    )
    dest = _build_destination(target)
    creds = dest.config_params["credentials"]
    assert creds["catalog"] == "duckdb:///./das.ducklake"
    assert creds["storage"] == "./ducklake_data"


def test_ducklake_dispatch_passes_url_catalog_through() -> None:
    target = TargetConfig(
        destination="ducklake",
        credentials={
            "catalog": "postgresql://user:pw@host:5432/cat",
            "storage": "./ducklake_data",
        },
    )
    dest = _build_destination(target)
    creds = dest.config_params["credentials"]
    assert creds["catalog"] == "postgresql://user:pw@host:5432/cat"


def test_ducklake_dispatch_passes_duckdb_url_catalog_through() -> None:
    target = TargetConfig(
        destination="ducklake",
        credentials={
            "catalog": "duckdb:///./other.ducklake",
            "storage": "./ducklake_data",
        },
    )
    dest = _build_destination(target)
    creds = dest.config_params["credentials"]
    assert creds["catalog"] == "duckdb:///./other.ducklake"
```

Also update the existing unknown-destination test's expected message — it now lists two verified destinations:

```python
def test_unknown_destination_raises_value_error() -> None:
    target = TargetConfig(destination="postgres", credentials={})
    with pytest.raises(ValueError, match="Unsupported target.destination"):
        _build_destination(target)
```

(The match pattern stays loose; the user-facing message is checked in Step 4.)

- [ ] **Step 3: Run the new tests; expect failures**

Run: `uv run pytest tests/unit/test_destination_dispatch.py -v`

Expected: the five new ducklake tests fail with `ValueError: Unsupported target.destination: 'ducklake'`. Existing duckdb tests still pass.

- [ ] **Step 4: Add the ducklake branch to `_build_destination`**

In `src/das_cli/pipelines/load.py`, modify `_build_destination` to add the ducklake branch (insert before the `raise ValueError`):

```python
    if name == "ducklake":
        catalog = creds.get("catalog")
        if isinstance(catalog, str) and "://" not in catalog:
            creds = {**creds, "catalog": f"duckdb:///{catalog}"}
        return dlt.destinations.ducklake(
            credentials=creds,
            enable_dataset_name_normalization=False,
        )
    raise ValueError(
        f"Unsupported target.destination: {name!r}. "
        f"Verified destinations: duckdb, ducklake."
    )
```

- [ ] **Step 5: Run unit tests; expect all to pass**

Run: `uv run pytest tests/unit/test_destination_dispatch.py -v`

Expected: all 9 tests pass.

If `dest.config_params["credentials"]` is something other than a plain dict on the ducklake side (e.g., a `DuckLakeCredentials` instance), update the assertions to read attributes (`creds.catalog`, `creds.storage`) instead of dict items. Sanity-check with:

```bash
uv run python -c "
from das_cli.models.das_yaml import TargetConfig
from das_cli.pipelines.load import _build_destination
t = TargetConfig(destination='ducklake', credentials={'catalog': './das.ducklake', 'storage': './storage'})
d = _build_destination(t)
print('config_params:', d.config_params)
print('creds type:', type(d.config_params.get('credentials')))
"
```

Adapt the assertions to match the actual shape, then re-run.

- [ ] **Step 6: Run full suite + lint + types**

Run: `uv run pytest -q && uv run ruff check . && uv run ruff format --check . && uv run mypy src tests`

Expected: all green.

- [ ] **Step 7: Commit**

```bash
git add pyproject.toml uv.lock src/das_cli/pipelines/load.py tests/unit/test_destination_dispatch.py
git commit -m "feat(p2): dispatch ducklake destination + unit-test the catalog UX

_build_destination grows a ducklake branch. The catalog field accepts
both bare DuckDB-file paths (auto-prefixed with duckdb:///) and full
SQLAlchemy URLs (passed through verbatim). Bare-path auto-prefix
mirrors the existing duckdb-destination UX where database accepts a
plain path; URL form is required for non-DuckDB catalog backends
(Postgres, MySQL, SQLite).

Adds dlt[ducklake] to extras. See ADR-0016."
```

---

## Task 5: Integration test for DuckLake load + change detection

The real proof that Task 1's `pipeline.sql_client()` refactor works through DuckLake. Two-cycle ingestion: second cycle must append zero rows.

**Files:**
- Create: `tests/integration/test_load_pipeline_ducklake.py`
- Modify: `tests/conftest.py` (no — keep existing `workspace` fixture; the new test writes its own das.yaml)
- Reference: existing `tests/integration/test_load_pipeline.py` for shape

- [ ] **Step 1: Write the integration test**

Create `tests/integration/test_load_pipeline_ducklake.py`:

```python
"""Integration tests for the DuckLake destination. See ADR-0016."""

from __future__ import annotations

import gzip
import json
from pathlib import Path

import pytest
from typer.testing import CliRunner

from das_cli.cli import app

CONTRACT = """\
apiVersion: v3.0.0
kind: DataContract
id: x.products
name: Products
version: 0.1.0
status: draft
info: { title: Products, owner: x }
schema:
  - name: products
    physicalName: products
    physicalType: table
    properties:
      - name: product_id
        physicalName: ProductId
        logicalType: integer
        physicalType: bigint
        required: true
        primaryKey: true
      - { name: name, physicalName: Name, logicalType: string, required: true }
"""

SOURCE_YML = """\
type: odata
endpoint: https://example.com/odata/v1
spec:
  kind: odata
  metadata_url: https://example.com/odata/v1/$metadata
auth: { type: none }
"""


@pytest.fixture()
def ducklake_workspace(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """A das workspace configured for DuckLake (local catalog + local storage)."""
    catalog = tmp_path / "test.ducklake"
    storage = tmp_path / "ducklake_data"
    landing = tmp_path / "landing"
    storage.mkdir()
    monkeypatch.setenv("DAS_LANDING_URL", str(landing))
    monkeypatch.chdir(tmp_path)

    # Hand-write das.yaml — the `das init` template targets duckdb. We override.
    (tmp_path / "das.yaml").write_text(
        f"""\
target:
  destination: ducklake
  credentials:
    catalog: {catalog}
    storage: {storage}

landing:
  bucket_url: "{{{{ env_var('DAS_LANDING_URL', './landing') }}}}"
  credentials: {{}}

contracts:
  root: ./contracts

dataset:
  prefix: das

defaults:
  write_disposition: append
  change_detection: row_hash
  schema_contract:
    tables: evolve
    columns: freeze
    data_type: freeze
"""
    )

    # Source + contract
    src_dir = tmp_path / "contracts" / "x"
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(SOURCE_YML)
    (src_dir / "products.odcs.yaml").write_text(CONTRACT)

    return tmp_path


def _write_landing(workspace: Path, records: list[dict[str, object]]) -> None:
    landing = workspace / "landing" / "x" / "products"
    landing.mkdir(parents=True, exist_ok=True)
    out = landing / "1.jsonl.gz"
    payload = (
        "\n".join(
            json.dumps({"_data": r, "_dlt_load_id": "1700000000", "_dlt_id": f"id-{i}"})
            for i, r in enumerate(records)
        )
        + "\n"
    )
    with gzip.open(out, "wt") as f:
        f.write(payload)


def _ducklake_count(workspace: Path, table: str) -> int:
    """Open the ducklake catalog read-only and count rows in das__x.<table>."""
    import duckdb

    catalog = workspace / "test.ducklake"
    storage = workspace / "ducklake_data"
    conn = duckdb.connect(":memory:")
    try:
        conn.execute("INSTALL ducklake; LOAD ducklake;")
        conn.execute(
            f"ATTACH 'ducklake:{catalog}' AS lake (DATA_PATH '{storage}')"
        )
        conn.execute("USE lake")
        row = conn.execute(f'SELECT COUNT(*) FROM "das__x".{table}').fetchone()
        return row[0] if row is not None else 0
    finally:
        conn.close()


def test_ducklake_load_creates_table_with_contract_schema(
    ducklake_workspace: Path, cli_runner: CliRunner
) -> None:
    workspace = ducklake_workspace
    _write_landing(workspace, [{"ProductId": 1, "Name": "A"}, {"ProductId": 2, "Name": "B"}])

    result = cli_runner.invoke(app, ["load", "x"])
    assert result.exit_code == 0, result.output
    assert _ducklake_count(workspace, "products") == 2


def test_ducklake_change_detection_suppresses_duplicate(
    ducklake_workspace: Path, cli_runner: CliRunner
) -> None:
    """Two cycles with identical landing should append zero rows the second time.

    This is the real proof that load_latest_hash works through pipeline.sql_client()
    against a DuckLake destination — same contract as the DuckDB test in
    test_load_pipeline.py::test_load_change_detection_suppresses_duplicate.
    """
    workspace = ducklake_workspace
    _write_landing(workspace, [{"ProductId": 1, "Name": "A"}])

    first = cli_runner.invoke(app, ["load", "x"])
    assert first.exit_code == 0, first.output

    second = cli_runner.invoke(app, ["load", "x"])
    assert second.exit_code == 0, second.output

    assert _ducklake_count(workspace, "products") == 1


def test_ducklake_a_b_a_preserved(
    ducklake_workspace: Path, cli_runner: CliRunner
) -> None:
    """A → B → A produces three rows; change detection only suppresses no-ops."""
    workspace = ducklake_workspace

    _write_landing(workspace, [{"ProductId": 1, "Name": "A"}])
    cli_runner.invoke(app, ["load", "x"])

    landing = workspace / "landing" / "x" / "products"
    for f in landing.glob("*"):
        f.unlink()
    _write_landing(workspace, [{"ProductId": 1, "Name": "B"}])
    cli_runner.invoke(app, ["load", "x"])

    for f in landing.glob("*"):
        f.unlink()
    _write_landing(workspace, [{"ProductId": 1, "Name": "A"}])
    cli_runner.invoke(app, ["load", "x"])

    assert _ducklake_count(workspace, "products") == 3
```

Note: `_ducklake_count` opens the catalog using DuckDB's `ATTACH 'ducklake:...'` syntax, which is how DuckLake catalogs are read by an external client. If the test environment cannot install the duckdb extension (e.g., offline CI), the test will need `INSTALL ducklake FROM core_nightly;` or an alternative read path. Run Step 2 to find out before tweaking.

- [ ] **Step 2: Run the new integration tests**

Run: `uv run pytest tests/integration/test_load_pipeline_ducklake.py -v`

Expected: all 3 tests pass.

If `INSTALL ducklake;` fails in the duckdb client, try the bundled-with-dlt path: read via the dlt pipeline instead of an external duckdb connection. Replace `_ducklake_count` with:

```python
def _ducklake_count(workspace: Path, table: str) -> int:
    """Count rows in das__x.<table> via a dlt pipeline pointed at the same DuckLake."""
    import dlt

    pipeline = dlt.pipeline(
        pipeline_name="das_load",
        destination=dlt.destinations.ducklake(
            credentials={
                "catalog": f"duckdb:///{workspace / 'test.ducklake'}",
                "storage": str(workspace / "ducklake_data"),
            },
            enable_dataset_name_normalization=False,
        ),
        pipelines_dir=str(workspace / ".dlt" / "pipelines"),
    )
    with pipeline.sql_client() as c:
        row = list(c.execute_sql(f'SELECT COUNT(*) FROM "das__x".{table}'))[0]
        return int(row[0])
```

This reuses dlt's installed extension automatically. Pick whichever path runs cleanly in the dev environment.

- [ ] **Step 3: Run full suite + lint + types**

Run: `uv run pytest -q && uv run ruff check . && uv run ruff format --check . && uv run mypy src tests`

Expected: all green.

- [ ] **Step 4: Commit**

```bash
git add tests/integration/test_load_pipeline_ducklake.py
git commit -m "test(integration): cover P2 against a DuckLake destination

Three integration tests mirroring the DuckDB load-pipeline tests:
table creation from contract schema, change-detection no-op on a
second identical load, and A->B->A preserved (change detection
suppresses no-ops only).

Real proof that load_latest_hash's pipeline.sql_client() path round-trips
through DuckLake. See ADR-0016."
```

---

## Task 6: E2E tests for DuckLake (AdventureWorks + Northwind)

Mirror the existing e2e tests with the `target:` block pointing at DuckLake. Behind the existing `@pytest.mark.e2e` marker (auto-applied by `tests/e2e/conftest.py`).

**Files:**
- Create: `tests/e2e/test_adventureworks_ducklake.py`
- Create: `tests/e2e/test_northwind_ducklake.py`
- Reference: `tests/e2e/test_adventureworks.py`, `tests/e2e/test_northwind.py`

- [ ] **Step 1: Read the existing e2e tests in full**

Read both files end-to-end:

- `tests/e2e/test_adventureworks.py`
- `tests/e2e/test_northwind.py`

Note the post-load assertions, which currently use `duckdb.connect(workspace / "test.duckdb")`. Those become DuckLake reads via the same `_ducklake_count`-style helper from Task 5.

- [ ] **Step 2: Create the AdventureWorks DuckLake e2e**

Create `tests/e2e/test_adventureworks_ducklake.py` as a near-copy of `tests/e2e/test_adventureworks.py`, with these adjustments:

1. Replace the `workspace` fixture usage with a hand-written `das.yaml` that targets DuckLake. Same shape as the `ducklake_workspace` fixture body in Task 5 — a local catalog + storage under `tmp_path`. To avoid duplicating that fixture across `tests/integration/` and `tests/e2e/`, lift it into `tests/conftest.py`:

   In `tests/conftest.py`, add (below the existing `workspace` fixture):

   ```python
   @pytest.fixture()
   def ducklake_workspace(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[Path]:
       """A das workspace targeting a local DuckLake. Same shape as `workspace`."""
       catalog = tmp_path / "test.ducklake"
       storage = tmp_path / "ducklake_data"
       landing = tmp_path / "landing"
       storage.mkdir()
       monkeypatch.setenv("DAS_LANDING_URL", str(landing))
       monkeypatch.chdir(tmp_path)
       (tmp_path / "das.yaml").write_text(
           f"""\
   target:
     destination: ducklake
     credentials:
       catalog: {catalog}
       storage: {storage}

   landing:
     bucket_url: "{{{{ env_var('DAS_LANDING_URL', './landing') }}}}"
     credentials: {{}}

   contracts:
     root: ./contracts

   dataset:
     prefix: das

   defaults:
     write_disposition: append
     change_detection: row_hash
     schema_contract:
       tables: evolve
       columns: freeze
       data_type: freeze
   """
       )
       yield tmp_path
   ```

   Then remove the duplicated fixture body from `tests/integration/test_load_pipeline_ducklake.py` and import the shared one (no import needed — pytest discovers conftest fixtures by path).

2. Replace the body of the AdventureWorks e2e to use `ducklake_workspace` instead of `workspace`. The resource is `products` (matches the existing DuckDB e2e at `tests/e2e/test_adventureworks.py:31`):

   ```python
   from pathlib import Path

   import dlt
   from typer.testing import CliRunner

   from das_cli.cli import app


   def test_adventureworks_ducklake_bootstrap_extract_load(
       ducklake_workspace: Path, cli_runner: CliRunner
   ) -> None:
       # Note: NO `cli_runner.invoke(app, ["init"])` — ducklake_workspace already
       # writes a custom das.yaml. `init` would overwrite it without --force.
       cli_runner.invoke(
           app,
           [
               "source",
               "add",
               "adventureworks",
               "--type",
               "odata",
               "--url",
               "https://demodata.grapecity.com/adventureworks/odata/v1",
           ],
       )

       bootstrap = cli_runner.invoke(
           app,
           ["contract", "bootstrap", "adventureworks", "--only", "products"],
       )
       assert bootstrap.exit_code == 0, bootstrap.stdout + bootstrap.stderr
       products_contract = (
           ducklake_workspace / "contracts" / "adventureworks" / "products.odcs.yaml"
       )
       assert products_contract.is_file()

       extract = cli_runner.invoke(
           app,
           ["extract", "adventureworks", "--resource", "products", "--limit", "10"],
       )
       assert extract.exit_code == 0, extract.stdout + extract.stderr

       landing = ducklake_workspace / "landing" / "adventureworks" / "products"
       assert any(landing.rglob("*.jsonl*"))

       load = cli_runner.invoke(app, ["load", "adventureworks", "--resource", "products"])
       assert load.exit_code == 0, load.stdout + load.stderr

       # DuckLake read: open via a dlt pipeline (extension is bundled with dlt).
       pipeline = dlt.pipeline(
           pipeline_name="das_load_read",
           destination=dlt.destinations.ducklake(
               credentials={
                   "catalog": f"duckdb:///{ducklake_workspace / 'test.ducklake'}",
                   "storage": str(ducklake_workspace / "ducklake_data"),
               },
               enable_dataset_name_normalization=False,
           ),
           pipelines_dir=str(ducklake_workspace / ".dlt" / "pipelines_read"),
       )
       with pipeline.sql_client() as c:
           count = list(
               c.execute_sql('SELECT COUNT(*) FROM "das__adventureworks".products')
           )[0][0]
           assert count >= 1, "expected at least one product row"
           nulls = list(
               c.execute_sql(
                   'SELECT COUNT(*) FROM "das__adventureworks".products '
                   "WHERE _extracted_at IS NULL OR _extracted_on IS NULL "
                   "OR _loaded_at IS NULL OR _loaded_on IS NULL"
               )
           )[0][0]
           assert nulls == 0, "metadata columns must be NOT NULL"
   ```

   The reader pipeline uses a different `pipeline_name` and `pipelines_dir` than the load pipeline — this avoids stepping on the load pipeline's state when the test is re-run.

- [ ] **Step 3: Create the Northwind DuckLake e2e**

Create `tests/e2e/test_northwind_ducklake.py`, mirroring `tests/e2e/test_northwind.py` with `ducklake_workspace` and the dlt-pipeline read. The Northwind resource is `customer_dtos` (matches the existing test). Full body:

```python
from pathlib import Path

import dlt
import yaml as _yaml
from typer.testing import CliRunner

from das_cli.cli import app


def test_northwind_ducklake_bootstrap_extract_load(
    ducklake_workspace: Path, cli_runner: CliRunner
) -> None:
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "northwind",
            "--type",
            "openapi",
            "--url",
            "https://demodata.grapecity.com/northwind/api/v1",
        ],
    )

    # Same swagger override the DuckDB Northwind test does.
    src = ducklake_workspace / "contracts" / "northwind" / "_source.yml"
    text = src.read_text().replace(
        "swagger.json",
        "../../docs/NorthWind/v1/restful_swagger.json",
    )
    text = text.replace(
        "https://demodata.grapecity.com/northwind/api/v1/../../docs/NorthWind/v1/restful_swagger.json",
        "https://demodata.grapecity.com/docs/NorthWind/v1/restful_swagger.json",
    )
    src.write_text(text)

    bootstrap = cli_runner.invoke(
        app,
        ["contract", "bootstrap", "northwind", "--only", "customer_dtos"],
    )
    assert bootstrap.exit_code == 0, bootstrap.stdout + bootstrap.stderr
    cust_contract = (
        ducklake_workspace / "contracts" / "northwind" / "customer_dtos.odcs.yaml"
    )
    assert cust_contract.is_file()

    cust_data = _yaml.safe_load(cust_contract.read_text())
    cps = cust_data.get("customProperties") or []
    endpoint = next((p for p in cps if p["property"] == "das.endpoint"), None)
    assert endpoint is not None, (
        "bootstrap should have emitted das.endpoint for CustomerDto"
    )
    assert endpoint["value"]["path"] == "/Customers", endpoint["value"]["path"]

    extract = cli_runner.invoke(
        app,
        ["extract", "northwind", "--resource", "customer_dtos", "--limit", "5"],
    )
    assert extract.exit_code == 0, extract.stdout + extract.stderr

    load = cli_runner.invoke(app, ["load", "northwind", "--resource", "customer_dtos"])
    assert load.exit_code == 0, load.stdout + load.stderr

    pipeline = dlt.pipeline(
        pipeline_name="das_load_read",
        destination=dlt.destinations.ducklake(
            credentials={
                "catalog": f"duckdb:///{ducklake_workspace / 'test.ducklake'}",
                "storage": str(ducklake_workspace / "ducklake_data"),
            },
            enable_dataset_name_normalization=False,
        ),
        pipelines_dir=str(ducklake_workspace / ".dlt" / "pipelines_read"),
    )
    with pipeline.sql_client() as c:
        count = list(
            c.execute_sql('SELECT COUNT(*) FROM "das__northwind".customer_dtos')
        )[0][0]
        assert count >= 1
        nulls = list(
            c.execute_sql(
                'SELECT COUNT(*) FROM "das__northwind".customer_dtos '
                "WHERE _extracted_at IS NULL OR _extracted_on IS NULL "
                "OR _loaded_at IS NULL OR _loaded_on IS NULL"
            )
        )[0][0]
        assert nulls == 0, "metadata columns must be NOT NULL"
```

- [ ] **Step 4: Run the e2e tests opt-in**

Run: `uv run pytest -m e2e -v`

Expected: all e2e tests pass — including the four DuckDB ones (unchanged) plus the two new DuckLake ones. These hit live public APIs; if the network is flaky, retry. If a DuckDB e2e fails, that is a regression from earlier tasks — stop and diagnose.

- [ ] **Step 5: Run the full non-e2e suite to confirm no collateral damage**

Run: `uv run pytest -q`

Expected: green.

- [ ] **Step 6: Lint + types**

Run: `uv run ruff check . && uv run ruff format --check . && uv run mypy src tests`

Expected: all green.

- [ ] **Step 7: Commit**

```bash
git add tests/conftest.py tests/integration/test_load_pipeline_ducklake.py tests/e2e/test_adventureworks_ducklake.py tests/e2e/test_northwind_ducklake.py
git commit -m "test(e2e): verify DuckLake against AdventureWorks and Northwind

Mirrors the existing DuckDB e2e tests with target.destination=ducklake.
Reads the loaded data back through a dlt pipeline (so the test path
exercises the same SQL client used by load_latest_hash).

Lifts the ducklake_workspace fixture into tests/conftest.py so e2e
and integration share it. See ADR-0016."
```

---

## Task 7: Doctor check for ducklake

Add a one-line note in `run_doctor` when `cfg.target.destination == "ducklake"`. Hygiene only — flag obvious config typos, no hard validation.

**Files:**
- Modify: `src/das_cli/doctor.py:31-35`
- Modify: `tests/integration/test_cli_doctor.py` (add a passing-clean-ducklake-workspace test case)

- [ ] **Step 1: Update `run_doctor`**

In `src/das_cli/doctor.py`, find the existing target check at lines 31-35:

```python
    # Target — for v0.1, just verify it's a duckdb destination with a database key.
    if cfg.target.destination == "duckdb":
        db = cfg.target.credentials.get("database")
        if not db:
            issues.append(DoctorIssue("target", "duckdb destination missing credentials.database"))
```

Replace with:

```python
    # Target — sanity-check known destinations. See ADR-0016.
    if cfg.target.destination == "duckdb":
        db = cfg.target.credentials.get("database")
        if not db:
            issues.append(
                DoctorIssue("target", "duckdb destination missing credentials.database")
            )
    elif cfg.target.destination == "ducklake":
        creds = cfg.target.credentials
        if not creds.get("catalog"):
            issues.append(
                DoctorIssue("target", "ducklake destination missing credentials.catalog")
            )
        if not creds.get("storage"):
            issues.append(
                DoctorIssue("target", "ducklake destination missing credentials.storage")
            )
```

- [ ] **Step 2: Add doctor tests for ducklake**

Read `tests/integration/test_cli_doctor.py` first. Append the following tests at the end:

```python
def test_doctor_passes_clean_ducklake_workspace(
    ducklake_workspace: Path, cli_runner: CliRunner
) -> None:
    # No sources defined; doctor should still pass on the workspace + target alone.
    result = cli_runner.invoke(app, ["doctor"])
    assert result.exit_code == 0, result.output


def test_doctor_flags_ducklake_missing_catalog(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, cli_runner: CliRunner
) -> None:
    monkeypatch.chdir(tmp_path)
    (tmp_path / "das.yaml").write_text(
        """\
target:
  destination: ducklake
  credentials:
    storage: ./ducklake_data

landing:
  bucket_url: ./landing
  credentials: {}

contracts:
  root: ./contracts
"""
    )
    (tmp_path / "contracts").mkdir()
    result = cli_runner.invoke(app, ["doctor"])
    assert result.exit_code != 0
    assert "credentials.catalog" in result.output


def test_doctor_flags_ducklake_missing_storage(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, cli_runner: CliRunner
) -> None:
    monkeypatch.chdir(tmp_path)
    (tmp_path / "das.yaml").write_text(
        """\
target:
  destination: ducklake
  credentials:
    catalog: ./test.ducklake

landing:
  bucket_url: ./landing
  credentials: {}

contracts:
  root: ./contracts
"""
    )
    (tmp_path / "contracts").mkdir()
    result = cli_runner.invoke(app, ["doctor"])
    assert result.exit_code != 0
    assert "credentials.storage" in result.output
```

If `pytest` is not already imported at the top of that file, add:

```python
import pytest
```

(Most likely already imported — check before adding.)

- [ ] **Step 3: Run doctor tests**

Run: `uv run pytest tests/integration/test_cli_doctor.py -v`

Expected: all pass — both existing duckdb cases and the three new ducklake ones.

- [ ] **Step 4: Run full suite + lint + types**

Run: `uv run pytest -q && uv run ruff check . && uv run ruff format --check . && uv run mypy src tests`

Expected: all green.

- [ ] **Step 5: Commit**

```bash
git add src/das_cli/doctor.py tests/integration/test_cli_doctor.py
git commit -m "feat(doctor): sanity-check ducklake credentials shape

Mirrors the existing duckdb check: flag a clear DoctorIssue when
target.destination=ducklake and credentials.catalog or .storage is
missing. Config-typo hygiene only — no connectivity probe.

See ADR-0016."
```

---

## Task 8: ADR-0016

File the ADR documenting the two coupled decisions: dispatch in `_build_destination`, reads through `pipeline.sql_client()`.

**Files:**
- Create: `docs/adrs/0016-destination-dispatch-and-pipeline-driven-reads.md`
- Modify: `docs/adrs/README.md` (append index row — Task 9 also touches this)

- [ ] **Step 1: Write the ADR**

Create `docs/adrs/0016-destination-dispatch-and-pipeline-driven-reads.md`:

```markdown
# 0016. Destination dispatch and pipeline-driven reads

- **Status:** Accepted
- **Date:** 2026-05-07
- **Deciders:** Mattias Thalén

## Context

Until now, P2's load pipeline hard-coded `dlt.destinations.duckdb(...)` and
read latest row hashes via a direct `duckdb.connect(db_path)` call. The
README advertised support for "any dlt destination," but adding even one
more destination required changing both the construction site and the
read path. The change-detection layer was the bigger problem: it imported
DuckDB and ran DuckDB-flavored SQL, so any destination without a literal
DuckDB-file would have needed parallel read code.

We needed a way to add destinations cheaply, starting with DuckLake,
without growing a plugin framework or a parallel abstraction layer
alongside dlt's own.

## Decision

**Decision A: destination dispatch lives in a small private function in
`pipelines/load.py`.** `_build_destination(target: TargetConfig) -> Any`
matches on `target.destination` and constructs the corresponding dlt
destination, forwarding `target.credentials`. Adding a new destination is
one branch in one function plus a `dlt[<extra>]` entry in `pyproject.toml`.

`enable_dataset_name_normalization=False` is unconditional — every
destination das-cli verifies must accept that flag, because it implements
ADR-0008's prefix-preservation policy globally.

For DuckLake specifically, the `catalog` field accepts both a SQLAlchemy
URL (`duckdb:///./das.ducklake`, `postgresql://...`, etc.) and a bare
filesystem path. Bare paths are auto-prefixed with `duckdb:///` before
construction — symmetric with the existing duckdb-destination UX where
`database: ./das.duckdb` is accepted as a path. URL form remains
necessary for non-DuckDB catalog backends.

**Decision B: change detection reads through `pipeline.sql_client()`.**
`load_latest_hash` (renamed from `load_latest_hash_from_duckdb`) takes
the running `dlt.Pipeline` and runs the latest-hash query through dlt's
SQL client. das-cli no longer imports `duckdb` for read access; dlt
owns destination-specific connection plumbing. The "table not found"
case is handled by catching `dlt.destinations.exceptions.DatabaseUndefinedRelation`.

## Alternatives considered

- **Hand-rolled DestinationAdapter Protocol with per-destination
  implementations.** Rejected: duplicates dlt's own abstraction. Each
  new destination would have meant two registrations (in das-cli's
  registry and in dlt) for no net gain.
- **Branch by destination name inside `change_detection.py`.** Rejected:
  ugly past two destinations and would have to be ripped out the first
  time we added a third.
- **Translate DuckLake credential field names to dlt's spelling.**
  Rejected: keeps das-cli in sync with dlt's evolution; field-name
  passthrough is cheaper than maintaining a translation table. The only
  exception is the bare-path → `duckdb:///` convenience for `catalog`,
  which is symmetric with the duckdb destination's existing path-as-string
  acceptance.

## Consequences

- Adding a new dlt destination is a one-branch change in
  `_build_destination` plus a `dlt[<extra>]` entry. The work to verify it
  is dominated by the e2e tests, not the integration glue.
- das-cli no longer imports `duckdb` for read access. The duckdb
  package is still pulled in transitively via `dlt[duckdb]`, but the
  P2 pipeline does not use it directly.
- The ADR locks in dlt's `pipeline.sql_client()` API as a contract
  surface. A future destination without a usable SQL client could not
  support change detection without per-destination read code, and the
  decision to add it would require revisiting this ADR.
- `change_detection.py` no longer has a destination word in any public
  symbol, which makes adding more destinations a config-only change
  rather than a code-and-config one.
```

- [ ] **Step 2: Append the ADR row to `docs/adrs/README.md`**

Read `docs/adrs/README.md` first to see the post-#21 (rebased) shape of the index table, then append a new row at the bottom:

```
| 0016 | Destination dispatch and pipeline-driven reads | Accepted |
```

If issue #21's index fix has not yet landed, STOP — the rebase pre-flight requirement was missed.

- [ ] **Step 3: Lint + types (markdown is not type-checked, but run anyway for completeness)**

Run: `uv run pre-commit run --all-files`

Expected: all hooks green. Markdown linters (if configured) will catch malformed tables.

- [ ] **Step 4: Commit**

```bash
git add docs/adrs/0016-destination-dispatch-and-pipeline-driven-reads.md docs/adrs/README.md
git commit -m "docs(adrs): file ADR-0016 destination dispatch and pipeline-driven reads

Captures the two coupled decisions behind the DuckLake verification:
_build_destination dispatch in pipelines/load.py, and change-detection
reads through pipeline.sql_client(). Lists alternatives considered and
the API-surface consequence (dlt's sql_client becomes a contract surface)."
```

---

## Task 9: README updates

Land the user-visible documentation: the "Verified" matrix gains a DuckLake row, and the "What it is" lead generalizes from "DuckDB warehouse" to a destination-neutral phrasing. The ADR lookup links land here too.

**Files:**
- Modify: `README.md:12-19` (What it is paragraph)
- Modify: `README.md:88-94` (Verified matrix)
- Modify: `src/das_cli/pipelines/load.py` (add ADR-pointer comments — see CLAUDE.md convention)
- Modify: `src/das_cli/pipelines/change_detection.py` (add ADR-pointer comment)

- [ ] **Step 1: Update README "What it is"**

Read `README.md:10-20`. Replace the line:

```
das-cli lands raw source data into a compressed JSONL landing zone, then
promotes it into a contract-enforced DuckDB warehouse. ODCS v3 contracts are
```

with:

```
das-cli lands raw source data into a compressed JSONL landing zone, then
promotes it into a contract-enforced warehouse (DuckDB or DuckLake). ODCS v3 contracts are
```

- [ ] **Step 2: Update README "Verified" matrix**

Read `README.md:88-94`. Add a new row at the end of the table for DuckLake:

```
| OData v2 / v4  | DuckLake    | Local DuckDB-file catalog (ADR-0016)          |
| OpenAPI / REST | DuckLake    | Local DuckDB-file catalog (ADR-0016)          |
```

- [ ] **Step 3: Add ADR-0016 pointer comments in code**

In `src/das_cli/pipelines/load.py`, the existing docstring on `_build_destination` (added in Task 2) already references ADR-0016. Confirm — it should already say `See ADR-0016`. If not, add it.

In `src/das_cli/pipelines/change_detection.py`, confirm `load_latest_hash`'s docstring already mentions ADR-0016 (added in Task 1). If not, add it.

The CLAUDE.md convention is single-line `# See ADR-NNNN.` comments at the binding of an ADR-driven decision. The function docstrings already cover this.

- [ ] **Step 4: Run pre-commit on the whole repo**

Run: `uv run pre-commit run --all-files`

Expected: all hooks green.

- [ ] **Step 5: Run the full test matrix as a final check**

Run: `uv run pytest -q && uv run pytest -m e2e -v`

Expected: all green. If any e2e test fails on network, retry once.

- [ ] **Step 6: Commit**

```bash
git add README.md
git commit -m "docs(readme): list DuckLake in verified matrix; generalize lead

The 'What it is' paragraph no longer claims DuckDB exclusively. The
verified-destinations matrix gains DuckLake rows for both OData and
OpenAPI/REST sources, with a link to ADR-0016 for the local-catalog
configuration that this verification covered."
```

---

## Task 10: Push and final verification

Single push at the end so all the commits land together with a clean history.

- [ ] **Step 1: Verify branch state**

Run: `git status && git log --oneline -15`

Expected: clean working tree, ~9 commits ahead of `origin/claude/assign-first-issue-SZwJB` (one per Task 1-9).

- [ ] **Step 2: Re-run the full test matrix one more time**

Run: `uv run pytest -q && uv run pytest -m e2e -v && uv run pre-commit run --all-files`

Expected: all green.

- [ ] **Step 3: Push**

Run: `git push -u origin claude/assign-first-issue-SZwJB`

Expected: push succeeds; remote tracking updates. If the push is rejected (someone pushed in the meantime), `git pull --rebase origin claude/assign-first-issue-SZwJB` and retry.

- [ ] **Step 4: Confirm the issue references the design + ADR**

Issue #22 has no body. The PR description (when filed by the user) is the appropriate place to link to the spec, plan, and ADR. Do NOT close issue #22 from this branch — that's the user's decision after merge.
