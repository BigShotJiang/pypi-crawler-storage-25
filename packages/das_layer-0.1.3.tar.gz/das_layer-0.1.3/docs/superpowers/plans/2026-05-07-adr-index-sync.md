# ADR Index Sync Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Sync the ADR index in `docs/adrs/README.md` with on-disk file headings (issue #21 + two additional drifts found during verification), and add a pre-merge check to `CLAUDE.md` to prevent recurrence.

**Architecture:** Two-file documentation change in a single commit. (1) Edit four rows in `docs/adrs/README.md` so titles match each ADR file's `# NNNN.` heading. (2) Insert a new "Pre-merge ADR check" subsection in `CLAUDE.md` immediately after `### Lifecycle`.

**Tech Stack:** Markdown only. No code, no tests, no tooling.

**Spec:** `docs/superpowers/specs/2026-05-07-adr-index-sync-design.md`

---

## Task 1: Cross-check ADR titles against the existing index

**STATUS: COMPLETED** by the controller before plan revision. Findings recorded below.

Goal: confirm the only drift between `docs/adrs/README.md` and on-disk ADR file headings, before editing.

**Files:**
- Read: `docs/adrs/README.md`
- Read: `docs/adrs/0*.md` (headings only)

- [x] **Step 1: Dump every ADR file's first line**

Ran:

```bash
head -n 1 docs/adrs/0*.md
```

- [x] **Step 2: Compare each heading to its index row**

Findings (drifts to fix in Task 2):

1. **ADR-0001:** file heading `# 0001. Use Python (not Go) for the CLI`; index row says "Python over Go for the CLI". Wording drift.
2. **ADR-0006:** file heading `# 0006. Bootstrap mix: custom OData parser, direct OpenAPI walker`; index row says "Bootstrap mix: custom OData parser, `datacontract-cli` for OpenAPI". Heading was updated when ADR-0015 extended ADR-0006; index never caught up.
3. **ADR-0013:** file heading correct; index row at line 22 mislabels it as `0015`.
4. **ADR-0014:** missing from index entirely.
5. **ADR-0015:** missing from index entirely.

Rows 0002, 0003, 0004, 0005, 0007, 0008, 0009, 0010, 0011, 0012 — clean (heading matches index).

---

## Task 2: Apply both documentation edits in a single commit

Goal: in one commit, update the four affected rows of `docs/adrs/README.md` and insert the "Pre-merge ADR check" subsection into `CLAUDE.md`.

**Files:**
- Modify: `docs/adrs/README.md` (rows 0001, 0006, and the broken last row)
- Modify: `CLAUDE.md` (insert new subsection after `### Lifecycle`)

- [ ] **Step 1: Edit `docs/adrs/README.md` — row 0001**

Replace:

```
| 0001 | Python over Go for the CLI | Accepted |
```

with:

```
| 0001 | Use Python (not Go) for the CLI | Accepted |
```

Title taken verbatim from `docs/adrs/0001-python-not-go.md` line 1.

- [ ] **Step 2: Edit `docs/adrs/README.md` — row 0006**

Replace:

```
| 0006 | Bootstrap mix: custom OData parser, `datacontract-cli` for OpenAPI | Accepted |
```

with:

```
| 0006 | Bootstrap mix: custom OData parser, direct OpenAPI walker | Accepted |
```

Title taken verbatim from `docs/adrs/0006-bootstrap-mix-odata-openapi.md` line 1. The status column stays `Accepted` (matching the existing index convention — the file's `(extended by ADR-0015)` annotation is not surfaced in the index).

- [ ] **Step 3: Edit `docs/adrs/README.md` — broken last row**

Replace:

```
| 0015 | Load-date semantics: hive partition + derived staging columns | Accepted |
```

with three rows in this exact order:

```
| 0013 | Load-date semantics: hive partition + derived staging columns | Accepted |
| 0014 | Per-resource `das.endpoint` for HTTP source resolution        | Accepted |
| 0015 | Extend OpenAPI bootstrap to walk paths                        | Accepted |
```

Notes on the new rows:
- `0013` title: verbatim from `docs/adrs/0013-load-date-semantics.md` line 1.
- `0014` title: verbatim from `docs/adrs/0014-per-resource-das-endpoint.md` line 1; backticks around `das.endpoint` are preserved.
- `0015` title: from `docs/adrs/0015-extend-openapi-bootstrap-to-walk-paths.md` line 1, with the backticks around `paths` dropped to match the issue's "Suggested fix" block. The file heading itself uses backticks; the index does not.

After Steps 1–3 the table should read (showing the full table for verification):

```
| # | Title | Status |
|---|---|---|
| 0001 | Use Python (not Go) for the CLI | Accepted |
| 0002 | Two-pipeline architecture (extract vs. load) | Accepted |
| 0003 | P1 uses dlt's pipeline with `_data: json` blob pattern | Accepted |
| 0004 | Append + row-hash change detection over SCD2 merge | Accepted |
| 0005 | ODCS v3 for resource contracts; custom `_source.yml` for connection | Accepted |
| 0006 | Bootstrap mix: custom OData parser, direct OpenAPI walker | Accepted |
| 0007 | Secrets via Jinja `env_var(...)` only — no `.dlt/secrets.toml` | Accepted |
| 0008 | One P2 pipeline; one P1 pipeline per source | Accepted |
| 0009 | dlt config flows via Python objects, not `.dlt/config.toml` | Accepted |
| 0010 | CLI tests live in the CLI repo; user workspaces get only `das doctor`/`das validate` wrappers | Accepted |
| 0011 | `das.*` namespace for ODCS `customProperties` | Accepted |
| 0012 | Schema enforcement via `data_type: freeze` plus contract projection | Accepted |
| 0013 | Load-date semantics: hive partition + derived staging columns | Accepted |
| 0014 | Per-resource `das.endpoint` for HTTP source resolution        | Accepted |
| 0015 | Extend OpenAPI bootstrap to walk paths                        | Accepted |
```

- [ ] **Step 4: Edit `CLAUDE.md` — insert "Pre-merge ADR check" subsection**

Locate the line `### Lifecycle` near the top of the ADR section. Find the end of the Lifecycle subsection (the next `###` heading is `### Before changing architectural behavior`).

Insert this content **immediately before** `### Before changing architectural behavior`, separated by a blank line:

```markdown
### Pre-merge ADR check

Before opening or merging a PR that adds, removes, or renumbers an ADR:

1. Rebase on `main` and confirm no ADR file number on the branch collides
   with one already on `main`. If a collision exists, renumber the branch's
   ADR(s) before opening the PR (renumbering is allowed pre-merge per the
   lifecycle policy above).
2. Run `head -1 docs/adrs/0*.md` and confirm every ADR file has a matching
   row in `docs/adrs/README.md` whose title equals the file's `# NNNN.`
   heading verbatim.
3. Confirm `docs/adrs/README.md` has no rows referring to ADR numbers that
   don't exist as files.
```

- [ ] **Step 5: Verify both edits**

Run:

```bash
sed -n '6,30p' docs/adrs/README.md
```

Expected: 15 data rows numbered 0001–0015 in order, no gaps, no duplicates. Row 0001 reads "Use Python (not Go) for the CLI". Row 0006 reads "Bootstrap mix: custom OData parser, direct OpenAPI walker". Last row is 0015 reading "Extend OpenAPI bootstrap to walk paths".

Run:

```bash
grep -E '^\| 00(1[6-9]|[2-9][0-9]) ' docs/adrs/README.md
```

Expected: no output (no rows referencing nonexistent ADR numbers).

Run:

```bash
grep -n '^### ' CLAUDE.md
```

Expected: among other headings, `### Lifecycle` followed (in source order) by `### Pre-merge ADR check` followed by `### Before changing architectural behavior`.

Run:

```bash
grep -A 12 '^### Pre-merge ADR check' CLAUDE.md
```

Expected: the new subsection's full content (numbered list, three steps, exactly as inserted in Step 4).

Re-run the cross-check from Task 1 to confirm zero remaining drift between index and file headings:

```bash
head -n 1 docs/adrs/0*.md
```

Each file's `# NNNN. <title>` should match the corresponding index row's title in `docs/adrs/README.md`, with the documented exception that the 0015 index row drops backticks around `paths`.

- [ ] **Step 6: Commit**

```bash
git add docs/adrs/README.md CLAUDE.md
git commit -m "$(cat <<'EOF'
docs(adrs): sync index and add pre-merge ADR check

Fixes the index drift reported in #21 (rows 0013/0014/0015 missing or
mislabeled) and two additional drifts found during verification: row 0001
title (wording) and row 0006 title (datacontract-cli → direct OpenAPI
walker, post-ADR-0015 extension).

Adds a "Pre-merge ADR check" subsection to CLAUDE.md so contributors
verify ADR-number collisions and index/heading sync before opening a PR.

Closes #21.
EOF
)"
```

---

## Self-Review Notes

Spec coverage:
- Spec "Decision → Index changes → Change 1" → Task 2 Step 1.
- Spec "Decision → Index changes → Change 2" → Task 2 Step 2.
- Spec "Decision → Index changes → Change 3" → Task 2 Step 3.
- Spec "Decision → Policy change (CLAUDE.md)" → Task 2 Step 4.
- Spec "Verification" → Task 2 Step 5.
- Spec "Out of scope" → no tasks, as intended.

Placeholder scan: none.

Type consistency: N/A (no code).
