# Oracle `NUMBER(p,s)` decimal round-trip — implementation plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fix the Oracle e2e load failure (`amount__v_text` variant rejected by frozen contract) by reordering `_logical_for` so `Numeric` columns with scale > 0 are detected before the `Integer` branches.

**Architecture:** SQLAlchemy's `oracle.NUMBER` extends both `Numeric` and `Integer`, so today the Integer branch wins for `NUMBER(12,2)` and the column is emitted as `logicalType=integer`. We restructure `_logical_for` in `src/das_cli/bootstrap/sql.py` so a Numeric-with-scale-greater-than-zero is classified as `decimal(p,s)` first, and only `scale == 0` / `scale is None` falls through to the integer branches. No new ADR (defect in ADR-0018's implementation, not an architectural change). Spec: `docs/superpowers/specs/2026-05-12-oracle-decimal-roundtrip-design.md`.

**Tech Stack:** Python 3.12, SQLAlchemy 2.x, pytest (TDD), uv, ruff, mypy, pre-commit.

---

## File map

- **Modify:** `src/das_cli/bootstrap/sql.py` — reorder `_logical_for` (lines ~54-84).
- **Modify:** `tests/unit/test_bootstrap_sql.py` — add 4 new tests covering the Oracle-NUMBER inheritance quirk and the existing scale-zero fallback.

No other files touched. No fixture changes. No CI changes. The existing `tests/e2e/sources/test_oracle.py::test_oracle_bootstrap_extract_load` is the live regression test — it must turn green in CI on the fix branch.

---

### Task 1: Add a failing unit test for `oracle.NUMBER(12,2)`

This test exercises the bug directly: today `_logical_for` returns `("integer", None)` for `oracle.NUMBER(12,2)`; after the fix it must return `("number", "decimal(12,2)")`.

**Files:**
- Modify: `tests/unit/test_bootstrap_sql.py` (append after `test_logical_for_falls_back_to_string_for_pickle_type`, around line 257)

- [ ] **Step 1: Write the failing test**

Append to `tests/unit/test_bootstrap_sql.py`:

```python
def test_logical_for_oracle_number_with_scale_maps_to_decimal() -> None:
    """oracle.NUMBER extends both Numeric and Integer; scale>0 must win as decimal.

    Regression: previously the Integer branch in _logical_for fired first, so
    NUMBER(12,2) became logicalType=integer and lost its scale. That broke
    P2's decimal coercion in _project_record (see ADR-0018 Consequences) and
    failed the Oracle e2e load with `amount__v_text` variant rejection.
    """
    from sqlalchemy import Column
    from sqlalchemy.dialects.oracle import NUMBER

    from das_cli.bootstrap.sql import _logical_for

    col: Column[Any] = Column("amount", NUMBER(12, 2))
    logical, physical = _logical_for(col)
    assert logical == "number"
    assert physical == "decimal(12,2)"
```

- [ ] **Step 2: Run the test to verify it fails**

Run:
```bash
uv run pytest tests/unit/test_bootstrap_sql.py::test_logical_for_oracle_number_with_scale_maps_to_decimal -v
```
Expected: FAIL. The assertion error will show `logical == "integer"` and `physical is None` because the Integer branch catches `oracle.NUMBER` before the Numeric branch.

- [ ] **Step 3: Commit the failing test (red)**

```bash
git add tests/unit/test_bootstrap_sql.py
git commit -m "test(bootstrap-sql): pin Oracle NUMBER(p,s>0) → decimal(p,s) — currently fails"
```

---

### Task 2: Implement the `_logical_for` reorder to make the test pass

Move the `Numeric and not Float` branch ahead of the Integer branches, but only when `scale > 0`. `scale == 0` and `scale is None` keep falling through so the existing behavior for `oracle.NUMBER(p, 0)` (integer-like) and generic `Numeric()` (no scale) is preserved.

**Files:**
- Modify: `src/das_cli/bootstrap/sql.py` (function `_logical_for`, lines 54-84)

- [ ] **Step 1: Replace the body of `_logical_for`**

In `src/das_cli/bootstrap/sql.py`, replace this block:

```python
def _logical_for(col: Column[Any]) -> tuple[str, str | None]:
    """Map a SQLAlchemy generic Column type to (logicalType, physicalType).

    Falls back to ('string', None) for unknown types. See ADR-0018.
    """
    sa_type = col.type
    if isinstance(sa_type, BigInteger):
        return ("integer", "bigint")
    if isinstance(sa_type, Integer | SmallInteger):
        return ("integer", None)
    if isinstance(sa_type, Numeric) and not isinstance(sa_type, Float):
        precision = sa_type.precision
        scale = sa_type.scale
        if precision is not None and scale is not None:
            return ("number", f"decimal({precision},{scale})")
        return ("number", None)
    if isinstance(sa_type, Float):
        return ("number", None)
    if isinstance(sa_type, Boolean):
        return ("boolean", None)
    if isinstance(sa_type, String | Text):
        return ("string", None)
    if isinstance(sa_type, Date):
        return ("date", None)
    if isinstance(sa_type, Time):
        return ("string", None)
    if isinstance(sa_type, DateTime | TIMESTAMP):
        return ("timestamp", None)
    if isinstance(sa_type, LargeBinary | BLOB):
        return ("string", None)
    return ("string", None)
```

with:

```python
def _logical_for(col: Column[Any]) -> tuple[str, str | None]:
    """Map a SQLAlchemy generic Column type to (logicalType, physicalType).

    Falls back to ('string', None) for unknown types. See ADR-0018.
    """
    sa_type = col.type

    # Numeric-with-scale must be detected BEFORE the Integer branches: oracle.NUMBER
    # extends both Numeric and Integer (sqlalchemy/dialects/oracle/types.py), so the
    # Integer branch would otherwise catch NUMBER(p,s>0) and lose the scale — which
    # then breaks P2's decimal coercion in pipelines/load.py::_project_record.
    # scale == 0 (or None) falls through so NUMBER(p,0) stays integer-like, matching
    # Oracle's own driver behavior (asdecimal=False ⇒ int).
    if isinstance(sa_type, Numeric) and not isinstance(sa_type, Float):
        scale = sa_type.scale
        if scale is not None and scale > 0:
            precision = sa_type.precision
            if precision is not None:
                return ("number", f"decimal({precision},{scale})")
            return ("number", None)

    if isinstance(sa_type, BigInteger):
        return ("integer", "bigint")
    if isinstance(sa_type, Integer | SmallInteger):
        return ("integer", None)

    # Generic Numeric with scale == 0 or unspecified that didn't get caught by the
    # Integer branches above (e.g. MSSQL / Postgres NUMERIC(10,0), or NUMERIC with
    # no precision/scale at all).
    if isinstance(sa_type, Numeric) and not isinstance(sa_type, Float):
        precision = sa_type.precision
        scale = sa_type.scale
        if precision is not None and scale is not None:
            return ("number", f"decimal({precision},{scale})")
        return ("number", None)

    if isinstance(sa_type, Float):
        return ("number", None)
    if isinstance(sa_type, Boolean):
        return ("boolean", None)
    if isinstance(sa_type, String | Text):
        return ("string", None)
    if isinstance(sa_type, Date):
        return ("date", None)
    if isinstance(sa_type, Time):
        return ("string", None)
    if isinstance(sa_type, DateTime | TIMESTAMP):
        return ("timestamp", None)
    if isinstance(sa_type, LargeBinary | BLOB):
        return ("string", None)
    return ("string", None)
```

- [ ] **Step 2: Run the new test to verify it passes**

Run:
```bash
uv run pytest tests/unit/test_bootstrap_sql.py::test_logical_for_oracle_number_with_scale_maps_to_decimal -v
```
Expected: PASS.

- [ ] **Step 3: Run the full bootstrap-sql test file to verify no regression**

Run:
```bash
uv run pytest tests/unit/test_bootstrap_sql.py -v
```
Expected: all tests pass, including `test_type_mapping_integer`, `test_type_mapping_numeric_with_precision`, and the two `_logical_for_falls_back_to_string` tests.

- [ ] **Step 4: Commit the fix (green)**

```bash
git add src/das_cli/bootstrap/sql.py
git commit -m "fix(bootstrap-sql): detect Numeric(scale>0) before Integer for Oracle NUMBER

oracle.NUMBER extends both Numeric and Integer in SQLAlchemy. The Integer
branch was catching NUMBER(p, s>0) and dropping the scale, breaking ADR-0018's
decimal(p,s) round-trip on Oracle. Reorder so Numeric-with-scale wins first;
NUMBER(p, 0) still falls through to Integer, matching Oracle driver semantics."
```

---

### Task 3: Lock down the scale-zero fallback for `oracle.NUMBER(p, 0)`

Today the Integer branch catches `oracle.NUMBER(10, 0)` and returns `("integer", None)`. The fix preserves that behavior — but it's a non-obvious invariant (`oracle.NUMBER` extends both bases, and we deliberately fall through), so pin it with a regression test so a future tweak to `_logical_for` cannot silently regress.

**Files:**
- Modify: `tests/unit/test_bootstrap_sql.py` (append after the test added in Task 1)

- [ ] **Step 1: Write the test**

Append:

```python
def test_logical_for_oracle_number_scale_zero_falls_through_to_integer() -> None:
    """NUMBER(p, 0) is integer-like in Oracle (driver returns int with asdecimal=False).

    The Numeric-with-scale guard added for the NUMBER(p, s>0) case must let
    scale==0 fall through to the Integer branch so this stays integer.
    """
    from sqlalchemy import Column
    from sqlalchemy.dialects.oracle import NUMBER

    from das_cli.bootstrap.sql import _logical_for

    col: Column[Any] = Column("order_id", NUMBER(10, 0))
    logical, physical = _logical_for(col)
    assert logical == "integer"
    assert physical is None
```

- [ ] **Step 2: Run the test**

Run:
```bash
uv run pytest tests/unit/test_bootstrap_sql.py::test_logical_for_oracle_number_scale_zero_falls_through_to_integer -v
```
Expected: PASS.

- [ ] **Step 3: Commit**

```bash
git add tests/unit/test_bootstrap_sql.py
git commit -m "test(bootstrap-sql): pin Oracle NUMBER(p, 0) → integer fallback"
```

---

### Task 4: Pin the generic-Numeric scale-zero path

The two-branch shape in `_logical_for` has a fallback `Numeric` block specifically for generic SQLAlchemy `Numeric(p, 0)` / `Numeric()` that didn't get caught by `Integer`. Pin both shapes so a future cleanup that drops the fallback branch is caught.

**Files:**
- Modify: `tests/unit/test_bootstrap_sql.py` (append after Task 3's test)

- [ ] **Step 1: Write the tests**

Append:

```python
def test_logical_for_generic_numeric_scale_zero_maps_to_decimal() -> None:
    """SQLAlchemy generic Numeric(10, 0) is NOT Integer-derived — keep mapping to decimal.

    This pins the fallback Numeric branch in _logical_for; without it, removing
    that branch would silently make Numeric(10, 0) fall all the way through to
    the `("string", None)` default.
    """
    from sqlalchemy import Column, Numeric

    from das_cli.bootstrap.sql import _logical_for

    col: Column[Any] = Column("qty", Numeric(10, 0))
    logical, physical = _logical_for(col)
    assert logical == "number"
    assert physical == "decimal(10,0)"


def test_logical_for_generic_numeric_no_precision_scale_maps_to_number_none() -> None:
    """Numeric() with no precision or scale → ('number', None)."""
    from sqlalchemy import Column, Numeric

    from das_cli.bootstrap.sql import _logical_for

    col: Column[Any] = Column("qty", Numeric())
    logical, physical = _logical_for(col)
    assert logical == "number"
    assert physical is None
```

- [ ] **Step 2: Run the tests**

Run:
```bash
uv run pytest tests/unit/test_bootstrap_sql.py::test_logical_for_generic_numeric_scale_zero_maps_to_decimal tests/unit/test_bootstrap_sql.py::test_logical_for_generic_numeric_no_precision_scale_maps_to_number_none -v
```
Expected: both PASS.

- [ ] **Step 3: Commit**

```bash
git add tests/unit/test_bootstrap_sql.py
git commit -m "test(bootstrap-sql): pin generic Numeric(scale=0) and bare Numeric() paths"
```

---

### Task 5: Run the full unit + integration suite

Confirm nothing else regressed. The integration test `test_sql_extract_decimal_with_scale_round_trips` exercises the SQLite path end-to-end and should still pass.

- [ ] **Step 1: Run unit + integration**

Run:
```bash
uv run pytest tests/unit tests/integration -q
```
Expected: all pass. The exact count depends on `main` at merge time; PR #53 reported 336/336 — Tasks 1, 3, 4 add 4 new tests so expect 340 (or whatever the new baseline is) passing on the fix branch.

- [ ] **Step 2: Run pre-commit hooks**

Run:
```bash
uv run pre-commit run --all-files
```
Expected: all hooks pass (ruff, ruff-format, mypy).

If ruff-format reflows the new test code, accept the reflow and amend it into Task 4's commit (or re-stage and create a small follow-up `style: ...` commit if cleaner). Do not amend the merged source-side `fix:` commit.

---

### Task 6: Push the branch and open a PR

The branch is `worktree-fix-oracle-decimal-roundtrip` (created by `EnterWorktree`). Push and open a PR so CI runs the Oracle e2e — that's the live regression test we cannot run locally.

- [ ] **Step 1: Push the branch**

Run:
```bash
git push -u origin worktree-fix-oracle-decimal-roundtrip
```

- [ ] **Step 2: Open the PR**

Run:
```bash
gh pr create --title "fix(bootstrap-sql): Oracle NUMBER(p,s>0) maps to decimal — not integer" --body "$(cat <<'EOF'
## Summary

- Fixes the Oracle e2e load failure on `main` — `tests/e2e/sources/test_oracle.py::test_oracle_bootstrap_extract_load`.
- `oracle.NUMBER` extends both `Numeric` AND `Integer` in SQLAlchemy 2.x, so the `Integer` branch in `_logical_for` was claiming `NUMBER(12,2)` and dropping its scale. The column was emitted as `logicalType=integer`, dlt mapped it to `bigint`, and `_project_record` skipped the decimal coercion path — landing's stringified `"19.99"` then reached dlt as text and the frozen contract rejected an `amount__v_text` variant.
- Restructured `_logical_for` so `Numeric(scale>0)` wins before the `Integer` branches. `NUMBER(p, 0)` continues to fall through to Integer, matching Oracle's own driver semantics (asdecimal=False).

Design and rationale: `docs/superpowers/specs/2026-05-12-oracle-decimal-roundtrip-design.md`. No new ADR — ADR-0018 already declares the round-trip intent in its Consequences section; this is a defect fix.

## Test plan

- [x] `uv run pytest tests/unit tests/integration -q` — all green locally.
- [x] `uv run pre-commit run --all-files` — clean.
- [x] 4 new unit tests pin the four corners of the `_logical_for` Numeric/Integer ordering: `oracle.NUMBER(12,2)`, `oracle.NUMBER(10,0)`, generic `Numeric(10,0)`, generic `Numeric()`.
- [ ] CI Oracle e2e turns green (this is the live regression — cannot run locally without an Oracle container).
EOF
)"
```

- [ ] **Step 3: Watch the Oracle e2e in CI**

Once CI starts, the relevant signal is the `e2e` job. Confirm `test_oracle_bootstrap_extract_load` runs and passes. Run:
```bash
gh pr checks --watch
```
or:
```bash
gh run watch
```
Expected: e2e passes, including the Oracle test.

---

## Self-review

- **Spec coverage:** every section of the spec maps to a task —
  - Root cause (the `_logical_for` ordering bug) → Tasks 1 + 2.
  - Behavior matrix rows (oracle.NUMBER(12,2), oracle.NUMBER(10,0), generic Numeric(p,0), generic Numeric()) → Tasks 1, 3, 4 (one row each).
  - Existing coverage call-out (test_type_mapping_numeric_with_precision, test_sql_extract_decimal_with_scale_round_trips) → Task 5 (running the full suite).
  - Regression test call-out (test_oracle_bootstrap_extract_load) → Task 6 step 3 (watch CI).
  - "Why not the alternatives" section → no implementation work; documented in the spec.
  - "No new ADR" → confirmed; plan adds no ADR file.
- **Placeholder scan:** no TBD / "implement later" / "similar to Task N" — every step has either a shell command or a code block.
- **Type consistency:** new tests all use the same `Column[Any]` annotation style as the existing fallback tests in `test_bootstrap_sql.py`. `_logical_for` signature is unchanged.
- **TDD order:** Task 1 writes a failing test before Task 2's implementation. Tasks 3 + 4 add regression pins after the fix is in; they should pass on their first run because Task 2 already preserves those paths — that's intentional (pinning invariants, not driving new code).
