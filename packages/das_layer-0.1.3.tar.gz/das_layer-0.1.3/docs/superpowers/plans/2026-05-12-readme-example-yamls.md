# README Example YAMLs Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add an `## Example workspace` section to `README.md` showing the `das.yaml`, `_source.yml`, and `products.odcs.yaml` trio for the AdventureWorks Quickstart, plus OpenAPI and SQL `_source.yml` variants in a sub-section.

**Architecture:** Docs-only change to a single file (`README.md`). No code, no new ADR, no tests. Every YAML block must be byte-identical to either the `DAS_YAML_TEMPLATE` constant in `src/das_cli/cli.py`, the output `_source_yml_template(...)` in the same file would produce for the documented arguments, or a canonical fixture in `tests/unit/test_validator.py`. The section is inserted between the existing `## Quickstart` and `## Concepts` H2s.

**Tech Stack:** Markdown (GitHub-flavored). No new dependencies. Pre-commit hooks in this repo target Python only; no markdown/YAML linter is configured, so verification is manual (parse YAML via Python one-liner, then preview the rendered README).

**Spec:** `docs/superpowers/specs/2026-05-12-readme-example-yamls-design.md`.

**Issue:** [#46](https://github.com/mattiasthalen/das-cli/issues/46).

**Branch:** working in worktree `worktree-issue-46-readme-example-yamls` (already entered).

---

## File Structure

Only one file is modified.

- **Modify:** `README.md` — insert a new `## Example workspace` section between line 79 (end of Quickstart) and line 80 (`## Concepts`). Resulting README grows by ~80 lines.

No other files are created or modified. The spec doc was already committed in `0aa45a8`.

---

## Sources of truth (for copy-paste fidelity)

When pasting YAML blocks, copy verbatim from these locations. **Do not retype.**

| Block | Source of truth |
|-------|----------------|
| `das.yaml` | `src/das_cli/cli.py` — `DAS_YAML_TEMPLATE` string starting at line 74 |
| `_source.yml` (OData / AdventureWorks) | Output of `_source_yml_template("adventureworks", "odata", "https://demodata.grapecity.com/adventureworks/odata/v1", "none")` — see `src/das_cli/cli.py:247-287` |
| `products.odcs.yaml` | `tests/unit/test_validator.py` — `PRODUCTS` constant at line 32 |
| `_source.yml` (OpenAPI variant) | Output of `_source_yml_template("northwind", "openapi", "https://api.example.com/v1", "none")` |
| `_source.yml` (SQL variant) | Output of `_source_yml_template("finance", "sql", "oracle+oracledb://oracle-host:1521/?service_name=XEPDB1", "none")` |
| `das.endpoint` snippet | `tests/unit/test_validator.py` — `CUSTOMERS_WITH_ENDPOINT` constant at line 136 (just the `customProperties` block) |

---

## Task 1: Add main trio (framing, tree, das.yaml, _source.yml, contract)

**Files:**
- Modify: `README.md` (insert between line 79 and line 80)

- [ ] **Step 1: Confirm current README anchor lines**

Run:

```bash
sed -n '75,82p' README.md
```

Expected output (line numbers from `cat -n` would be 75–82):

```
After `das ingest`:

- raw JSONL lands in `./landing/`, hive-partitioned by extract date
- contract-enforced staging tables live in `./das.duckdb`

## Concepts

- **Contract** — an [ODCS v3](https://bitol-io.github.io/open-data-contract-standard/)
```

If `## Concepts` is not at the line shown, stop and re-read the README before editing — the section index may have drifted since the spec was written.

- [ ] **Step 2: Insert the `## Example workspace` H2 above `## Concepts`**

Use the Edit tool with `old_string` set to:

```
- contract-enforced staging tables live in `./das.duckdb`

## Concepts
```

and `new_string` set to the block below. Note the blank line conventions: one blank line after the last Quickstart bullet, one blank line before the new H2, then the section body.

````
- contract-enforced staging tables live in `./das.duckdb`

## Example workspace

After `das init` and `das source add --type odata ...`, the workspace looks
like this — the `das.yaml` is the workspace config; `_source.yml` is the
per-source connection; the `.odcs.yaml` file is the contract you'd typically
hand-edit after `das contract bootstrap`.

```text
.
├── das.yaml
├── .env
└── contracts/
    └── adventureworks/
        ├── _source.yml
        └── products.odcs.yaml
```

**`das.yaml`** — workspace config written by `das init`. (For DuckLake or
Delta targets, see ADR-0016 / ADR-0017.)

```yaml
target:
  destination: duckdb
  credentials:
    database: "{{ env_var('DAS_TARGET_DB', './das.duckdb') }}"

landing:
  bucket_url: "{{ env_var('DAS_LANDING_URL', './landing') }}"
  credentials: {}

contracts:
  root: ./contracts

dataset:
  prefix: das          # set to null (or omit) for no prefix; dataset = source name

defaults:
  write_disposition: append
  change_detection: row_hash
  schema_contract:
    tables: evolve
    columns: freeze
    data_type: freeze
```

**`contracts/adventureworks/_source.yml`** — per-source connection written
by `das source add`. (ADR-0005 covers the contract/source split; ADR-0007
covers secrets via `env_var`.)

```yaml
type: odata
endpoint: https://demodata.grapecity.com/adventureworks/odata/v1
spec:
  kind: odata
  metadata_url: https://demodata.grapecity.com/adventureworks/odata/v1/$metadata
auth:
  type: none
ownership:
  team: data-platform
```

**`contracts/adventureworks/products.odcs.yaml`** — ODCS v3 contract,
post-edit. Defines the projected schema, primary key, and a `das.cursor`
for incremental extraction. (ADR-0011, ADR-0014 cover the `das.*`
namespace.)

```yaml
apiVersion: v3.0.0
kind: DataContract
id: adventureworks.products
name: Products
version: 0.1.0
status: draft
info: { title: Products, owner: data-platform }
schema:
  - name: products
    physicalName: products
    physicalType: table
    properties:
      - { name: product_id, physicalName: ProductId, logicalType: integer,
          physicalType: bigint, required: true, primaryKey: true }
      - { name: name, physicalName: Name, logicalType: string, required: true }
      - { name: modified_at, physicalName: ModifiedDate, logicalType: timestamp }
customProperties:
  - { property: das.cursor, value: modified_at }
```

## Concepts
````

- [ ] **Step 3: Verify the inserted YAML blocks parse**

Run:

```bash
uv run python - <<'PY'
import re, yaml, sys, pathlib
src = pathlib.Path("README.md").read_text()
# Extract every ```yaml ... ``` block.
blocks = re.findall(r"```yaml\n(.*?)```", src, flags=re.DOTALL)
print(f"Found {len(blocks)} yaml block(s); parsing each...")
for i, b in enumerate(blocks):
    try:
        yaml.safe_load(b)
        print(f"  block {i+1}: OK ({len(b.splitlines())} lines)")
    except yaml.YAMLError as e:
        print(f"  block {i+1}: FAIL — {e}", file=sys.stderr)
        sys.exit(1)
PY
```

Expected: prints `OK` for **3** yaml blocks (das.yaml, _source.yml, contract). Exit 0.

If any block fails to parse: the paste lost indentation or a brace. Re-read the relevant source-of-truth file from the table at the top and re-paste verbatim. Do not "fix" the YAML — fix the paste.

- [ ] **Step 4: Sanity-check that `_source.yml` matches what `cli.py` would emit**

Run:

```bash
uv run python - <<'PY'
import sys, pathlib, re
sys.path.insert(0, "src")
from das_cli.cli import _source_yml_template
emitted = _source_yml_template(
    "adventureworks", "odata",
    "https://demodata.grapecity.com/adventureworks/odata/v1", "none",
)
src = pathlib.Path("README.md").read_text()
blocks = re.findall(r"```yaml\n(.*?)```", src, flags=re.DOTALL)
# Identify the OData block by its content rather than its surrounding markdown,
# so the regex can't be tricked by the literal `_source.yml` token in the file tree.
odata_blocks = [b for b in blocks if b.lstrip().startswith("type: odata")]
assert len(odata_blocks) == 1, f"expected 1 odata block, got {len(odata_blocks)}"
in_readme = odata_blocks[0]
if emitted != in_readme:
    print("MISMATCH:\n--- expected ---\n" + repr(emitted))
    print("--- actual ---\n" + repr(in_readme))
    sys.exit(1)
print("OK: README OData _source.yml byte-identical to _source_yml_template output")
PY
```

Expected: `OK: README OData _source.yml byte-identical ...`. Any `MISMATCH` means the YAML was hand-typed instead of pasted; redo Step 2.

- [ ] **Step 5: Commit**

```bash
git add README.md
git commit -m "$(cat <<'EOF'
docs(readme): add Example workspace section with trio of YAMLs (#46)

Shows the das.yaml / _source.yml / products.odcs.yaml trio that `das
init` and `das source add --type odata` produce for the AdventureWorks
Quickstart, plus a hand-edited contract with a das.cursor custom
property.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

Expected: one file changed, ~70 insertions.

---

## Task 2: Add "Other source shapes" subsection (OpenAPI + SQL)

**Files:**
- Modify: `README.md` (append below the contract block, still inside the new section, above `## Concepts`)

- [ ] **Step 1: Insert the H3 subsection**

Use the Edit tool. Match on the unique closing of the contract block plus the next H2 (the `das.cursor` line is the only such customProperty in the file at this point, so the anchor is unique).

`old_string`:

````
customProperties:
  - { property: das.cursor, value: modified_at }
```

## Concepts
````

`new_string`:

````
customProperties:
  - { property: das.cursor, value: modified_at }
```

### Other source shapes

Only `_source.yml` varies per source type. The `das.yaml` workspace config
and the contract shape are the same regardless of source.

**OpenAPI / REST** — produced by `das source add --type openapi --url
https://api.example.com/v1`:

```yaml
type: openapi
endpoint: https://api.example.com/v1
spec:
  kind: openapi
  swagger_url: https://api.example.com/v1/swagger.json
auth:
  type: none
ownership:
  team: data-platform
```

Resource contracts under OpenAPI sources need an extra `das.endpoint`
custom property so the extractor knows which path to hit and how to
unwrap the response. (ADR-0014, ADR-0015.)

```yaml
customProperties:
  - property: das.endpoint
    value:
      path: /Customers
      response_path: $.value
```

**SQL** — produced by `das source add --type sql --url
"oracle+oracledb://oracle-host:1521/?service_name=XEPDB1"`. Credentials
are templated into the URL via `env_var`; the matching `.env` block is
written by the same command. (ADR-0018.)

```yaml
type: sql
endpoint: "oracle+oracledb://{{ env_var('FINANCE__USERNAME') }}:{{ env_var('FINANCE__PASSWORD') }}@oracle-host:1521/?service_name=XEPDB1"
spec:
  kind: sql
auth:
  type: none
ownership:
  team: data-platform
```

## Concepts
````

- [ ] **Step 2: Re-run YAML parse over the whole README**

Run the same script as Task 1 / Step 3:

```bash
uv run python - <<'PY'
import re, yaml, sys, pathlib
src = pathlib.Path("README.md").read_text()
blocks = re.findall(r"```yaml\n(.*?)```", src, flags=re.DOTALL)
print(f"Found {len(blocks)} yaml block(s); parsing each...")
for i, b in enumerate(blocks):
    try:
        yaml.safe_load(b)
        print(f"  block {i+1}: OK ({len(b.splitlines())} lines)")
    except yaml.YAMLError as e:
        print(f"  block {i+1}: FAIL — {e}", file=sys.stderr)
        sys.exit(1)
PY
```

Expected: prints `OK` for **5** yaml blocks total (was 3 after Task 1; +1 OpenAPI `_source.yml`, +1 OpenAPI `customProperties` snippet, +1 SQL `_source.yml` = +3 → total 6).

Wait — recount: das.yaml(1) + odata _source(2) + contract(3) + openapi _source(4) + das.endpoint snippet(5) + sql _source(6) = **6 blocks**.

Expected: `Found 6 yaml block(s)` and each prints `OK`.

- [ ] **Step 3: Sanity-check OpenAPI and SQL variants against `_source_yml_template`**

Run:

```bash
uv run python - <<'PY'
import sys, pathlib, re
sys.path.insert(0, "src")
from das_cli.cli import _source_yml_template

cases = [
    ("openapi", "openapi", "https://api.example.com/v1", "none"),
    ("sql",     "sql",     "oracle+oracledb://oracle-host:1521/?service_name=XEPDB1", "none"),
]
# For sql, the name controls the env prefix; use "finance" to match README.
name_for_kind = {"openapi": "northwind", "sql": "finance"}

src = pathlib.Path("README.md").read_text()
yaml_blocks = re.findall(r"```yaml\n(.*?)```", src, flags=re.DOTALL)

# Helper: find a block that starts with `type: <kind>`.
def find_block(kind: str) -> str:
    for b in yaml_blocks:
        if b.lstrip().startswith(f"type: {kind}"):
            return b
    raise AssertionError(f"no `type: {kind}` block found in README")

for label, kind, url, auth in cases:
    expected = _source_yml_template(name_for_kind[kind], kind, url, auth)
    actual = find_block(kind)
    assert expected == actual, (
        f"MISMATCH on {label}:\n--- expected ---\n{expected}\n--- actual ---\n{actual}"
    )
    print(f"{label}: byte-identical")
print("OK")
PY
```

Expected: `openapi: byte-identical`, `sql: byte-identical`, then `OK`.

Note: this only catches drift in the OpenAPI and SQL variants. The OData variant was already verified in Task 1 / Step 4 (still passing since we didn't change it).

- [ ] **Step 4: Eyeball the rendered section**

Run:

```bash
sed -n '80,180p' README.md
```

Confirm visually:
- Heading hierarchy is `## Example workspace` then `### Other source shapes` (no skipped levels, no extra H2).
- The file tree block is fenced as `text` (not `yaml`).
- All YAML blocks are fenced as `yaml`.
- Inline ADR references use the existing parenthetical bracketed style.
- No literal `…`, `<TODO>`, or other placeholder strings.

- [ ] **Step 5: Commit**

```bash
git add README.md
git commit -m "$(cat <<'EOF'
docs(readme): add Other source shapes subsection (OpenAPI + SQL) (#46)

Adds the two _source.yml variants that das source add produces for
--type openapi and --type sql, plus the das.endpoint customProperties
entry that resource contracts under OpenAPI sources need.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

Expected: one file changed, ~40 insertions.

---

## Task 3: Final verification and PR

**Files:** (none — verification + git operations only)

- [ ] **Step 1: Run pre-commit over the whole worktree**

Run:

```bash
uv run pre-commit run --all-files
```

Expected: all hooks `Passed` or `Skipped`. The configured hooks (`ruff`, `ruff-format`, `mypy`, `pytest-quick` at pre-push only) target Python; the README change should not trigger any failure. If something fails, it's almost certainly unrelated to this change — confirm by checking the failing file path is not `README.md`.

- [ ] **Step 2: Re-run the YAML parse + cli.py byte-identity checks end-to-end**

Run both verification scripts from Task 1 / Step 3 and Task 2 / Step 3 again, as a final sanity check after pre-commit. Expected: 6 yaml blocks, all OK; openapi + sql byte-identical to `_source_yml_template`.

- [ ] **Step 3: Push the branch and open the PR**

```bash
git push -u origin worktree-issue-46-readme-example-yamls
gh pr create --title "docs(readme): add Example workspace section with example YAMLs" --body "$(cat <<'EOF'
## Summary
- Adds a new `## Example workspace` section to `README.md` showing the trio of YAMLs the Quickstart actually produces (`das.yaml`, `_source.yml`, `<resource>.odcs.yaml`) for the AdventureWorks/OData example.
- Adds an `### Other source shapes` subsection with the differing `_source.yml` for OpenAPI/REST and SQL, plus the `das.endpoint` customProperty needed by OpenAPI resource contracts.
- No code, no ADR — every YAML block is byte-identical to what `cli.py` emits or to canonical test fixtures, so the README cannot silently drift from real CLI output.

Closes #46.

## Test plan
- [ ] `python` parses every \`\`\`yaml fenced block in README.md (script in the plan)
- [ ] OData / OpenAPI / SQL `_source.yml` blocks are byte-identical to `_source_yml_template(...)` output (script in the plan)
- [ ] `uv run pre-commit run --all-files` passes
- [ ] GitHub-rendered README preview reads correctly (no broken fences, correct heading hierarchy)

🤖 Generated with [Claude Code](https://claude.com/claude-code)
EOF
)"
```

Expected: the gh CLI prints the new PR URL.

- [ ] **Step 4: Confirm the PR rendered correctly on GitHub**

Run:

```bash
gh pr view --web
```

Visually confirm in the browser:
- Each `yaml` block is syntax-highlighted (not raw text).
- The file tree renders as a code block (no broken indentation).
- The `### Other source shapes` heading is nested under `## Example workspace` (visible as smaller in the rendered TOC).

If anything looks off in the rendered preview but the source looks fine, the most common cause is missing blank lines around fenced blocks — fix in a follow-up commit.

---

## Self-review notes

The plan covers every section of the spec:

- Placement ✓ — Task 1 / Step 2 inserts between Quickstart and Concepts.
- File tree ✓ — Task 1 / Step 2 (the `text` fence).
- `das.yaml` block ✓ — Task 1 / Step 2.
- `_source.yml` (OData) ✓ — Task 1 / Step 2.
- Contract (Products) ✓ — Task 1 / Step 2.
- `### Other source shapes` H3 ✓ — Task 2 / Step 1.
- OpenAPI `_source.yml` + `das.endpoint` snippet ✓ — Task 2 / Step 1.
- SQL `_source.yml` ✓ — Task 2 / Step 1.
- Source-of-truth rule ✓ — Task 1 / Step 4 and Task 2 / Step 3 enforce it programmatically.
- ADR cross-references ✓ — pasted inline in Tasks 1 & 2 matching the spec's list.
- Source-of-truth fidelity guard ✓ — byte-identity scripts catch drift; if they break it's a paste error.

No placeholders. No "implement later". All literal YAML in this plan is what should land in `README.md` verbatim.
