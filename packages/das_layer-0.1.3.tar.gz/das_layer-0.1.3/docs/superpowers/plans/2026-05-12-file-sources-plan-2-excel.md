# File-based sources Plan #2: Excel reader

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add Excel (`.xlsx`) support to the `type: filesystem` umbrella so workbooks can be ingested with per-sheet resources, streaming row reads, and optional `sheet` provenance injection.

**Architecture:** New `dlt_glue/file_readers/excel.py` uses `openpyxl.load_workbook(read_only=True, data_only=True)` plus `ws.iter_rows(values_only=True)` for true streaming. The bootstrap walker grows an `.xlsx` branch that enumerates workbook sheets and emits one contract per `(workbook, sheet)`. `_select_file_reader` dispatches `format=excel`. Inject context gains `sheet: <sheet_name>` so users can opt into `inject: {sheet_col: sheet}`.

**Tech Stack:** Python 3.12, dlt filesystem source, openpyxl (read-only mode), pytest. Adds optional `[excel]` extra.

**Spec:** `docs/superpowers/specs/2026-05-12-file-based-sources-design.md` (excel sections).

**Issue:** [#37](https://github.com/mattiasthalen/das-cli/issues/37) (excel child of #49). The umbrella + ADR-0022/0023 are already on the branch from Plan #1.

---

## Tasks at a glance

1. Add `openpyxl` `[excel]` extra to `pyproject.toml`
2. `file_readers/excel.py` — streaming reader with sheet injection
3. Wire `excel` into `_select_file_reader`
4. Bootstrap walker — `.xlsx` enumeration (one contract per `(workbook, sheet)`)
5. E2E: `tests/e2e/sources/test_excel_to_duckdb.py` — multi-sheet workbook
6. README — add Excel row to verified sources + quickstart

---

### Task 1: Add `openpyxl` to the `[excel]` optional extra

**Files:**
- Modify: `pyproject.toml`

- [ ] **Step 1: Inspect the current `pyproject.toml` structure**

Run: `grep -n "dependencies\|optional-dependencies\|excel\|openpyxl" pyproject.toml`
Expected: locates the existing `[project]` `dependencies` and `[dependency-groups]` `dev` sections; no excel/openpyxl entry yet.

- [ ] **Step 2: Add the `[excel]` extra**

Edit `pyproject.toml`. After the existing top-level `dependencies = [...]` array (around line 18), add a new `[project.optional-dependencies]` table containing `excel = ["openpyxl>=3.1"]`. If `[project.optional-dependencies]` already exists, just add the new line to it.

Insert between the existing `dependencies = [...]` block and the `[project.scripts]` block:

```toml

[project.optional-dependencies]
excel = ["openpyxl>=3.1"]
```

Also add `openpyxl>=3.1` to the `dev` group inside `[dependency-groups]` so unit + e2e tests can run without the user opting in:

```toml
[dependency-groups]
dev = [
    "pytest>=8.0",
    "pytest-cov>=5.0",
    "pytest-xdist>=3.5",
    "responses>=0.25",
    "ruff>=0.5",
    "mypy>=1.10",
    "pre-commit>=3.7",
    "types-PyYAML>=6.0",
    "types-requests>=2.31",
    "testcontainers[oracle,mssql]>=4.0",
    "oracledb>=2.0",
    "pyodbc>=5.0",
    "openpyxl>=3.1",
]
```

- [ ] **Step 3: Sync the lockfile and verify openpyxl is installed**

Run: `uv sync --all-extras`
Expected: lockfile updates; openpyxl wheel resolves.

Run: `uv run python -c "import openpyxl; print(openpyxl.__version__)"`
Expected: prints a version string ≥ `3.1.0`.

- [ ] **Step 4: Commit**

```bash
git add pyproject.toml uv.lock
git commit -m "$(cat <<'EOF'
feat(deps): add openpyxl as [excel] optional + dev dep

Plan #2 of the file-based sources umbrella needs openpyxl's
read_only=True streaming API. Lives under the [excel] optional
extra (users opt in); pinned in the dev group so the unit/e2e
tests run on default 'uv sync'.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

### Task 2: `file_readers/excel.py` — streaming reader

**Files:**
- Create: `src/das_cli/dlt_glue/file_readers/excel.py`
- Test: `tests/unit/dlt_glue/file_readers/test_excel.py`

The reader signature mirrors CSV: `read_rows(file_item, spec_ref) -> Iterator[dict]`. Per-spec_ref selectors: `sheet` (required), `header_row` (1-based; defaults to 1). Streams rows via openpyxl's read-only mode; never materializes the full sheet.

Excel adds `sheet` to the inject context so `inject: {col: sheet}` works.

For blob URLs, openpyxl's read-only mode wants a seekable local file. Plan #2 supports local paths only; the bootstrap walker already rejects blob endpoints (Plan #1 deferred), so this matches scope.

- [ ] **Step 1: Add a shared fixture helper for building xlsx in-memory**

Edit `tests/unit/dlt_glue/file_readers/__init__.py` (currently empty per Plan #1 Task 3). Replace with:

```python
"""Shared helpers for file-reader unit tests."""

from __future__ import annotations

import io

import openpyxl


def make_xlsx_bytes(sheets: dict[str, list[list[object]]]) -> bytes:
    """Build an in-memory xlsx workbook with the given {sheet_name: rows}.

    Each row is a flat list of cell values. The first list per sheet is the
    header row. Returns the workbook's bytes for use in BytesIO fixtures.
    """
    wb = openpyxl.Workbook()
    # Workbook ships with a default "Sheet" we don't want.
    wb.remove(wb.active)
    for name, rows in sheets.items():
        ws = wb.create_sheet(name)
        for row in rows:
            ws.append(row)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
```

- [ ] **Step 2: Write the failing Excel reader tests**

Create `tests/unit/dlt_glue/file_readers/test_excel.py`:

```python
"""Unit tests for the Excel file reader. See ADR-0022."""

from __future__ import annotations

import io
from pathlib import Path

import pytest

from das_cli.contracts.filesystem_spec_ref import FilesystemSpecRef
from das_cli.dlt_glue.file_readers.excel import read_rows
from tests.unit.dlt_glue.file_readers import make_xlsx_bytes


class _FakeFileItem:
    """Stand-in for dlt's FileItemDict that writes its body to a real tempfile.

    openpyxl's read_only mode wants a seekable file path or a real file handle;
    a BytesIO works but is treated differently. We simulate the real-world
    FileItemDict.open(mode='rb') by returning a tempfile-backed binary handle.
    """

    def __init__(self, body: bytes, file_name: str = "wb.xlsx", tmp_dir: Path | None = None):
        if tmp_dir is None:
            raise ValueError("_FakeFileItem requires tmp_dir for excel tests")
        self._path = tmp_dir / file_name
        self._path.write_bytes(body)
        self.file_name = file_name
        self.file_url = f"file://{self._path}"
        self.modification_date = "2026-05-12T00:00:00+00:00"

    def open(self, mode: str = "rb") -> object:
        assert mode == "rb"
        return self._path.open("rb")


def _spec(**overrides: object) -> FilesystemSpecRef:
    base: dict[str, object] = {
        "kind": "filesystem",
        "format": "excel",
        "path": "wb.xlsx",
        "sheet": "Customers",
    }
    base.update(overrides)
    return FilesystemSpecRef.model_validate(base)


def test_reads_header_then_data(tmp_path: Path) -> None:
    body = make_xlsx_bytes(
        {
            "Customers": [
                ["id", "name"],
                [1, "Alice"],
                [2, "Bob"],
            ]
        }
    )
    fi = _FakeFileItem(body, "wb.xlsx", tmp_dir=tmp_path)
    out = list(read_rows(fi, _spec()))
    assert out == [{"id": 1, "name": "Alice"}, {"id": 2, "name": "Bob"}]


def test_only_selected_sheet_is_read(tmp_path: Path) -> None:
    body = make_xlsx_bytes(
        {
            "Customers": [["id"], [1], [2]],
            "Orders": [["order_id"], [10]],
        }
    )
    fi = _FakeFileItem(body, "wb.xlsx", tmp_dir=tmp_path)
    out = list(read_rows(fi, _spec(sheet="Orders")))
    assert out == [{"order_id": 10}]


def test_custom_header_row(tmp_path: Path) -> None:
    body = make_xlsx_bytes(
        {
            "Customers": [
                ["banner row to skip"],
                ["id", "name"],
                [1, "Alice"],
            ]
        }
    )
    fi = _FakeFileItem(body, "wb.xlsx", tmp_dir=tmp_path)
    out = list(read_rows(fi, _spec(header_row=2)))
    assert out == [{"id": 1, "name": "Alice"}]


def test_missing_sheet_raises(tmp_path: Path) -> None:
    body = make_xlsx_bytes({"Customers": [["id"], [1]]})
    fi = _FakeFileItem(body, "wb.xlsx", tmp_dir=tmp_path)
    with pytest.raises(KeyError, match="NonExistent"):
        list(read_rows(fi, _spec(sheet="NonExistent")))


def test_inject_basename_and_sheet(tmp_path: Path) -> None:
    body = make_xlsx_bytes({"Customers": [["id"], [1]]})
    fi = _FakeFileItem(body, "march-export.xlsx", tmp_dir=tmp_path)
    out = list(
        read_rows(
            fi,
            _spec(inject={"source_file": "basename", "source_sheet": "sheet"}),
        )
    )
    assert out == [
        {"id": 1, "source_file": "march-export.xlsx", "source_sheet": "Customers"}
    ]


def test_empty_sheet_yields_nothing(tmp_path: Path) -> None:
    body = make_xlsx_bytes({"Customers": []})
    fi = _FakeFileItem(body, "wb.xlsx", tmp_dir=tmp_path)
    out = list(read_rows(fi, _spec()))
    assert out == []


def test_header_only_yields_nothing(tmp_path: Path) -> None:
    body = make_xlsx_bytes({"Customers": [["id", "name"]]})
    fi = _FakeFileItem(body, "wb.xlsx", tmp_dir=tmp_path)
    out = list(read_rows(fi, _spec()))
    assert out == []


def test_streaming_does_not_load_full_sheet(tmp_path: Path) -> None:
    """Reader must yield rows lazily, not materialize via list()."""
    body = make_xlsx_bytes(
        {
            "Customers": [
                ["id"],
                [1],
                [2],
                [3],
            ]
        }
    )
    fi = _FakeFileItem(body, "wb.xlsx", tmp_dir=tmp_path)
    gen = read_rows(fi, _spec())
    first = next(gen)
    assert first == {"id": 1}
    rest = list(gen)
    assert rest == [{"id": 2}, {"id": 3}]
```

- [ ] **Step 3: Run the failing tests**

Run: `uv run pytest tests/unit/dlt_glue/file_readers/test_excel.py -v`
Expected: FAIL with `ImportError: cannot import name 'read_rows' from 'das_cli.dlt_glue.file_readers.excel'`.

- [ ] **Step 4: Write the Excel reader**

Create `src/das_cli/dlt_glue/file_readers/excel.py`:

```python
"""Excel file reader. See ADR-0022.

Uses openpyxl's read_only mode plus iter_rows(values_only=True) for true
row-by-row streaming. Never materializes the full sheet.

`data_only=True` returns formula results (the last cached value) rather
than the formula text — matching what users see in the UI.
"""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path
from typing import Any

from das_cli.contracts.filesystem_spec_ref import FilesystemSpecRef
from das_cli.dlt_glue.file_readers._inject import apply_inject


def read_rows(file_item: Any, spec_ref: FilesystemSpecRef) -> Iterator[dict[str, Any]]:
    """Yield one dict per data row from one sheet of an Excel workbook.

    Args:
        file_item: dlt FileItemDict (or stand-in with `open(mode="rb")`,
                   `file_name`, optional `modification_date`).
        spec_ref: Resource spec; `sheet` is required, `header_row` defaults to 1,
                  `inject` is honored.

    Raises:
        KeyError: when `spec_ref.sheet` isn't in the workbook.
    """
    import openpyxl

    if spec_ref.sheet is None:
        raise ValueError("excel reader requires spec_ref.sheet")
    sheet_name = spec_ref.sheet
    header_row = spec_ref.header_row or 1

    with file_item.open(mode="rb") as binary:
        wb = openpyxl.load_workbook(binary, read_only=True, data_only=True)
        try:
            if sheet_name not in wb.sheetnames:
                raise KeyError(
                    f"Sheet {sheet_name!r} not in workbook. "
                    f"Available: {wb.sheetnames}"
                )
            ws = wb[sheet_name]

            context = _build_inject_context(file_item, sheet_name)

            row_iter = ws.iter_rows(values_only=True)
            yield from apply_inject(
                _rows_from_sheet(row_iter, header_row=header_row),
                inject=spec_ref.inject,
                context=context,
            )
        finally:
            wb.close()


def _rows_from_sheet(
    row_iter: Iterator[tuple[Any, ...]],
    *,
    header_row: int,
) -> Iterator[dict[str, Any]]:
    """Pull the header row, then yield {col: value} dicts for each data row.

    `header_row` is 1-based to match Excel's row numbering. Rows above the
    header are skipped.
    """
    header: list[str] | None = None
    for row_index, raw in enumerate(row_iter, start=1):
        if row_index < header_row:
            continue
        if row_index == header_row:
            header = [str(c) if c is not None else "" for c in raw]
            continue
        assert header is not None  # set above when row_index == header_row
        if all(cell is None for cell in raw):
            # Skip fully-blank trailing rows openpyxl sometimes emits.
            continue
        yield dict(zip(header, raw, strict=False))


def _build_inject_context(file_item: Any, sheet_name: str) -> dict[str, Any]:
    file_name = getattr(file_item, "file_name", None)
    if file_name is None and hasattr(file_item, "get"):
        file_name = file_item.get("file_name", "")
    file_name = file_name or ""

    file_url = getattr(file_item, "file_url", None)
    if file_url is None and hasattr(file_item, "get"):
        file_url = file_item.get("file_url", "")
    file_url = file_url or ""

    mtime = getattr(file_item, "modification_date", None)
    if mtime is None and hasattr(file_item, "get"):
        mtime = file_item.get("modification_date")

    return {
        "basename": Path(file_name).name if file_name else "",
        "fullpath": file_url,
        "mtime": mtime,
        "sheet": sheet_name,
    }
```

- [ ] **Step 5: Run the tests and verify they pass**

Run: `uv run pytest tests/unit/dlt_glue/file_readers/test_excel.py -v`
Expected: 8 passed.

- [ ] **Step 6: Commit**

```bash
git add src/das_cli/dlt_glue/file_readers/excel.py tests/unit/dlt_glue/file_readers/test_excel.py tests/unit/dlt_glue/file_readers/__init__.py
git commit -m "$(cat <<'EOF'
feat(file_readers): Excel reader with streaming + sheet inject

openpyxl read_only=True + iter_rows(values_only=True) streams rows
without materializing the full sheet. Honors sheet selector and
header_row from spec_ref; raises KeyError on unknown sheets. Adds
'sheet' to the inject context so inject: {col: sheet} is honored
per ADR-0023.

The test helper make_xlsx_bytes in
tests/unit/dlt_glue/file_readers/__init__.py builds in-memory
workbooks for unit tests without committing binary fixtures.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

### Task 3: Dispatch `excel` in `_select_file_reader`

**Files:**
- Modify: `src/das_cli/dlt_glue/source_factory.py` (`_select_file_reader`)
- Test: `tests/unit/test_source_factory_filesystem.py` (extend existing)

The factory's `_select_file_reader` currently dispatches `csv` and raises for everything else. Add an `excel` branch that returns `file_readers.excel.read_rows`.

- [ ] **Step 1: Write the failing dispatch test**

Append to `tests/unit/test_source_factory_filesystem.py` (above the existing module-level helpers / at the end of the test functions):

```python
def test_filesystem_excel_resource_yields_blob_wrapped_rows(tmp_path: Path) -> None:
    """Smoke: drop an xlsx in tmp_path, dispatch via format=excel, assert blobs."""
    import io

    import openpyxl

    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    ws = wb.create_sheet("Customers")
    ws.append(["id", "name"])
    ws.append([1, "Alice"])
    ws.append([2, "Bob"])
    buf = io.BytesIO()
    wb.save(buf)
    (tmp_path / "wb.xlsx").write_bytes(buf.getvalue())

    contracts = [
        _make_fs_contract(
            "customers",
            spec_ref={
                "kind": "filesystem",
                "format": "excel",
                "path": "wb.xlsx",
                "sheet": "Customers",
            },
        )
    ]
    resources = build_extract_resources(
        _fs_scfg(endpoint=str(tmp_path)), contracts, source_name="files"
    )
    out = list(resources[0])
    assert out == [
        {"_data": {"id": 1, "name": "Alice"}},
        {"_data": {"id": 2, "name": "Bob"}},
    ]
```

- [ ] **Step 2: Run the failing test**

Run: `uv run pytest tests/unit/test_source_factory_filesystem.py::test_filesystem_excel_resource_yields_blob_wrapped_rows -v`
Expected: FAIL — `_select_file_reader` raises `ValueError: No file reader for format 'excel'`.

- [ ] **Step 3: Extend `_select_file_reader`**

Edit `src/das_cli/dlt_glue/source_factory.py`. Replace:

```python
def _select_file_reader(format_name: str) -> Any:
    """Return the `read_rows` callable for a given format. See ADR-0022."""
    if format_name == "csv":
        from das_cli.dlt_glue.file_readers import csv as csv_reader

        return csv_reader.read_rows
    # excel, xml, qvd land in future format PRs under ADR-0022.
    raise ValueError(
        f"No file reader for format '{format_name}'. Supported: csv. "
        "(excel/xml/qvd are planned follow-ups.)"
    )
```

with:

```python
def _select_file_reader(format_name: str) -> Any:
    """Return the `read_rows` callable for a given format. See ADR-0022."""
    if format_name == "csv":
        from das_cli.dlt_glue.file_readers import csv as csv_reader

        return csv_reader.read_rows
    if format_name == "excel":
        from das_cli.dlt_glue.file_readers import excel as excel_reader

        return excel_reader.read_rows
    # xml, qvd land in future format PRs under ADR-0022.
    raise ValueError(
        f"No file reader for format '{format_name}'. Supported: csv, excel. "
        "(xml/qvd are planned follow-ups.)"
    )
```

- [ ] **Step 4: Run the test and verify it passes**

Run: `uv run pytest tests/unit/test_source_factory_filesystem.py -v`
Expected: 5 passed (4 existing + 1 new).

- [ ] **Step 5: Commit**

```bash
git add src/das_cli/dlt_glue/source_factory.py tests/unit/test_source_factory_filesystem.py
git commit -m "$(cat <<'EOF'
feat(source_factory): dispatch format=excel to file_readers.excel

Extends _select_file_reader with the excel branch; updates the
'unsupported format' error message to reflect the new state
(csv + excel supported; xml/qvd still planned).

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

### Task 4: Bootstrap walker — `.xlsx` discovery

**Files:**
- Modify: `src/das_cli/bootstrap/filesystem.py`
- Test: `tests/unit/test_bootstrap_filesystem.py` (extend existing)

For each `.xlsx` found in `endpoint`, the walker opens the workbook (read-only), enumerates `sheetnames`, and emits one contract per `(workbook, sheet)`. Header row provides column names; all types default to `logicalType: string`. Resource name = `<workbook_stem>__<sheet>` snake-cased so multiple workbooks with the same sheet name don't collide.

- [ ] **Step 1: Write the failing bootstrap tests**

Append to `tests/unit/test_bootstrap_filesystem.py`. The file already imports `bootstrap_filesystem_contracts`, `get_das_value`, `SourceConfig`, plus the `_scfg` helper. Add at the end:

```python
def test_emits_one_contract_per_sheet(tmp_path: Path) -> None:
    import openpyxl

    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    ws_c = wb.create_sheet("Customers")
    ws_c.append(["id", "name"])
    ws_o = wb.create_sheet("Orders")
    ws_o.append(["order_id", "amount"])
    wb.save(tmp_path / "wb.xlsx")

    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files"
    )
    names = sorted(c.resource_name for c in contracts)
    assert names == ["wb__customers", "wb__orders"]


def test_xlsx_columns_taken_from_header(tmp_path: Path) -> None:
    import openpyxl

    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    ws = wb.create_sheet("Customers")
    ws.append(["id", "name", "email"])
    ws.append([1, "Alice", "a@x"])
    wb.save(tmp_path / "wb.xlsx")

    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files"
    )
    schema = contracts[0].contract.primary_schema
    assert [p.name for p in schema.properties] == ["id", "name", "email"]


def test_xlsx_types_default_to_string(tmp_path: Path) -> None:
    import openpyxl

    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    ws = wb.create_sheet("Customers")
    ws.append(["id", "name"])
    ws.append([1, "Alice"])
    wb.save(tmp_path / "wb.xlsx")

    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files"
    )
    types = [p.logicalType for p in contracts[0].contract.primary_schema.properties]
    assert types == ["string", "string"]


def test_xlsx_spec_ref_carries_sheet_and_filename(tmp_path: Path) -> None:
    import openpyxl

    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    wb.create_sheet("Customers").append(["id"])
    wb.save(tmp_path / "Q1-Export.xlsx")

    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files"
    )
    spec_ref = get_das_value(
        contracts[0].contract.custom_properties, "das.spec_ref"
    )
    assert spec_ref == {
        "kind": "filesystem",
        "format": "excel",
        "path": "Q1-Export.xlsx",
        "sheet": "Customers",
    }


def test_xlsx_resource_name_is_workbook_stem_plus_sheet(tmp_path: Path) -> None:
    import openpyxl

    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    wb.create_sheet("OrderItems").append(["id"])
    wb.save(tmp_path / "CustomerOrders.xlsx")

    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files"
    )
    assert contracts[0].resource_name == "customer_orders__order_items"


def test_xlsx_skips_empty_sheet(tmp_path: Path) -> None:
    """A sheet with no header row produces a contract with empty properties.

    Bootstrap emits the contract anyway so the user can see it exists; the
    validator will then flag the empty schema if they try to ingest.
    """
    import openpyxl

    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    wb.create_sheet("Empty")
    wb.save(tmp_path / "wb.xlsx")

    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files"
    )
    assert len(contracts) == 1
    assert contracts[0].contract.primary_schema.properties == []
```

- [ ] **Step 2: Run the failing tests**

Run: `uv run pytest tests/unit/test_bootstrap_filesystem.py -v -k xlsx`
Expected: 6 tests, all FAIL — the walker only handles `.csv` right now.

Plus one will pass — the count check. Make sure failures dominate; the `.xlsx` walker logic isn't wired.

- [ ] **Step 3: Extend the bootstrap walker**

Edit `src/das_cli/bootstrap/filesystem.py`. Find the `bootstrap_filesystem_contracts` function. Inside the `for path in sorted(root.iterdir())` loop, replace:

```python
        suffix = path.suffix.lower()
        if suffix == ".csv":
            out.append(_build_csv_contract(path, source_name=source_name))
        # excel/xml/qvd dispatch lands in their follow-up plans under ADR-0022.
```

with:

```python
        suffix = path.suffix.lower()
        if suffix == ".csv":
            out.append(_build_csv_contract(path, source_name=source_name))
        elif suffix == ".xlsx":
            out.extend(_build_excel_contracts(path, source_name=source_name))
        # xml/qvd dispatch lands in their follow-up plans under ADR-0022.
```

At the end of the file (after `_read_csv_header`), append two new helpers:

```python
def _build_excel_contracts(
    file_path: Path, *, source_name: str
) -> list[LoadedContract]:
    """Yield one LoadedContract per (workbook, sheet) in `file_path`.

    Resource name = "<workbook_stem>__<sheet>" snake-cased so multi-workbook
    sources with the same sheet name don't collide.
    """
    import openpyxl

    workbook_stem = snake_case(file_path.stem)
    wb = openpyxl.load_workbook(file_path, read_only=True, data_only=True)
    out: list[LoadedContract] = []
    try:
        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            columns = _read_xlsx_header(ws)
            out.append(
                _make_excel_contract(
                    file_path=file_path,
                    sheet_name=sheet_name,
                    workbook_stem=workbook_stem,
                    columns=columns,
                    source_name=source_name,
                )
            )
    finally:
        wb.close()
    return out


def _read_xlsx_header(ws: object) -> list[str]:
    """Pull the first row as column names. Empty sheet → []."""
    # `ws` is openpyxl's read-only worksheet; typed loosely so we can defer
    # importing openpyxl at module level (it's only required when xlsx files
    # are present).
    for raw in ws.iter_rows(values_only=True, max_row=1):  # type: ignore[attr-defined]
        return [str(c).strip() for c in raw if c is not None and str(c).strip()]
    return []


def _make_excel_contract(
    *,
    file_path: Path,
    sheet_name: str,
    workbook_stem: str,
    columns: list[str],
    source_name: str,
) -> LoadedContract:
    resource_name = f"{workbook_stem}__{snake_case(sheet_name)}"
    properties = [OdcsProperty(name=col, logicalType="string") for col in columns]
    spec_ref_value = {
        "kind": "filesystem",
        "format": "excel",
        "path": file_path.name,
        "sheet": sheet_name,
    }
    contract = OdcsContract(
        apiVersion="v3.0.0",
        kind="DataContract",
        id=f"{source_name}.{resource_name}",
        name=resource_name,
        version="0.1.0",
        status="draft",
        info=OdcsInfo(title=resource_name, owner="data-platform"),
        schema=[
            OdcsSchema(
                name=resource_name,
                physicalName=resource_name,
                physicalType="table",
                properties=properties,
            )
        ],
        customProperties=[
            CustomProperty(property="das.spec_ref", value=spec_ref_value)
        ],
    )
    return LoadedContract(
        path=Path(f"{resource_name}.odcs.yaml"),
        resource_name=resource_name,
        contract=contract,
    )
```

- [ ] **Step 4: Run the bootstrap tests**

Run: `uv run pytest tests/unit/test_bootstrap_filesystem.py -v`
Expected: all xlsx tests pass; existing csv tests still pass.

- [ ] **Step 5: Commit**

```bash
git add src/das_cli/bootstrap/filesystem.py tests/unit/test_bootstrap_filesystem.py
git commit -m "$(cat <<'EOF'
feat(bootstrap): xlsx discovery — one contract per (workbook, sheet)

Extends bootstrap_filesystem_contracts with an .xlsx branch that opens
each workbook read-only, enumerates sheetnames, and emits one ODCS
contract per (workbook, sheet) with das.spec_ref.{path,sheet}. Resource
name is "<workbook_stem>__<sheet>" snake-cased so multi-workbook sources
with shared sheet names don't collide.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

### Task 5: E2E — Excel to DuckDB

**Files:**
- Create: `tests/e2e/sources/test_excel_to_duckdb.py`

Test pattern: workspace fixture, build an xlsx fixture in tmp_path (no committed binary), exercise source add → bootstrap → manual contract edit (set primary key + inject) → extract → load → assert DuckDB rows.

- [ ] **Step 1: Write the failing e2e test**

Create `tests/e2e/sources/test_excel_to_duckdb.py`:

```python
"""E2E: das against a local .xlsx workbook, landing into DuckDB. See ADR-0022.

Opt-in via `pytest -m e2e`. Builds the fixture workbook in tmp_path so no
binary file is committed. Pattern mirrors tests/e2e/sources/test_csv_to_duckdb.py.
"""

from __future__ import annotations

from pathlib import Path

import duckdb
import openpyxl
from typer.testing import CliRunner

from das_cli.cli import app


def _stage_workbook(data_dir: Path) -> None:
    wb = openpyxl.Workbook()
    wb.remove(wb.active)

    customers = wb.create_sheet("Customers")
    customers.append(["customer_id", "name", "signup_month"])
    customers.append([1, "Alice", "2024-01"])
    customers.append([2, "Bob", "2024-01"])
    customers.append([3, "Charlie", "2024-02"])

    orders = wb.create_sheet("Orders")
    orders.append(["order_id", "customer_id", "amount"])
    orders.append([10, 1, "99.50"])
    orders.append([11, 2, "150.00"])

    wb.save(data_dir / "Q1-2024.xlsx")


def test_xlsx_multi_sheet_to_duckdb_with_provenance(
    workspace: Path, cli_runner: CliRunner
) -> None:
    """Multi-sheet workbook: each sheet becomes its own staging table."""

    data_dir = workspace / "data"
    data_dir.mkdir()
    _stage_workbook(data_dir)

    init = cli_runner.invoke(app, ["init"])
    assert init.exit_code == 0, init.stdout + init.stderr

    add = cli_runner.invoke(
        app,
        ["source", "add", "files", "--type", "filesystem", "--url", str(data_dir)],
    )
    assert add.exit_code == 0, add.stdout + add.stderr

    boot = cli_runner.invoke(app, ["contract", "bootstrap", "files"])
    assert boot.exit_code == 0, boot.stdout + boot.stderr

    contracts_dir = workspace / "contracts" / "files"
    written = sorted(p.name for p in contracts_dir.glob("*.odcs.yaml"))
    assert written == [
        "q1_2024__customers.odcs.yaml",
        "q1_2024__orders.odcs.yaml",
    ]

    # Hand-edit the customers contract to set the primary key + inject sheet/file.
    (contracts_dir / "q1_2024__customers.odcs.yaml").write_text(
        "apiVersion: v3.0.0\n"
        "kind: DataContract\n"
        "id: files.q1_2024__customers\n"
        "name: q1_2024__customers\n"
        "version: 0.1.0\n"
        "status: draft\n"
        "info:\n  title: q1_2024__customers\n  owner: data-platform\n"
        "schema:\n"
        "  - name: q1_2024__customers\n"
        "    physicalName: q1_2024__customers\n"
        "    physicalType: table\n"
        "    properties:\n"
        "      - name: customer_id\n"
        "        logicalType: integer\n"
        "        primaryKey: true\n"
        "        required: true\n"
        "      - name: name\n"
        "        logicalType: string\n"
        "      - name: signup_month\n"
        "        logicalType: string\n"
        "      - name: source_file\n"
        "        logicalType: string\n"
        "      - name: source_sheet\n"
        "        logicalType: string\n"
        "customProperties:\n"
        "  - property: das.spec_ref\n"
        "    value:\n"
        "      kind: filesystem\n"
        "      format: excel\n"
        "      path: 'Q1-2024.xlsx'\n"
        "      sheet: 'Customers'\n"
        "      inject:\n"
        "        source_file: basename\n"
        "        source_sheet: sheet\n"
    )

    # Hand-edit the orders contract to set the primary key.
    (contracts_dir / "q1_2024__orders.odcs.yaml").write_text(
        "apiVersion: v3.0.0\n"
        "kind: DataContract\n"
        "id: files.q1_2024__orders\n"
        "name: q1_2024__orders\n"
        "version: 0.1.0\n"
        "status: draft\n"
        "info:\n  title: q1_2024__orders\n  owner: data-platform\n"
        "schema:\n"
        "  - name: q1_2024__orders\n"
        "    physicalName: q1_2024__orders\n"
        "    physicalType: table\n"
        "    properties:\n"
        "      - name: order_id\n"
        "        logicalType: integer\n"
        "        primaryKey: true\n"
        "        required: true\n"
        "      - name: customer_id\n"
        "        logicalType: integer\n"
        "      - name: amount\n"
        "        logicalType: string\n"
        "customProperties:\n"
        "  - property: das.spec_ref\n"
        "    value:\n"
        "      kind: filesystem\n"
        "      format: excel\n"
        "      path: 'Q1-2024.xlsx'\n"
        "      sheet: 'Orders'\n"
    )

    ext = cli_runner.invoke(app, ["extract", "files"])
    assert ext.exit_code == 0, ext.stdout + ext.stderr

    load = cli_runner.invoke(app, ["load", "files"])
    assert load.exit_code == 0, load.stdout + load.stderr

    db = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        cust = db.execute(
            'SELECT customer_id, name, signup_month, source_file, source_sheet '
            'FROM "das__files".q1_2024__customers ORDER BY customer_id'
        ).fetchall()
        ords = db.execute(
            'SELECT order_id, customer_id FROM "das__files".q1_2024__orders '
            "ORDER BY order_id"
        ).fetchall()
    finally:
        db.close()

    assert cust == [
        (1, "Alice", "2024-01", "Q1-2024.xlsx", "Customers"),
        (2, "Bob", "2024-01", "Q1-2024.xlsx", "Customers"),
        (3, "Charlie", "2024-02", "Q1-2024.xlsx", "Customers"),
    ]
    assert ords == [(10, 1), (11, 2)]
```

- [ ] **Step 2: Run the e2e test**

Run: `uv run pytest tests/e2e/sources/test_excel_to_duckdb.py -m e2e -v`

Expected: PASS. The `workspace` + `cli_runner` fixtures from `tests/conftest.py` switch cwd and set env vars; the e2e marker is auto-injected by `tests/e2e/conftest.py`.

If the test fails on type coercion (e.g., openpyxl returns `int` for the `customer_id` column but the contract declares it `logicalType: integer` → load expects coercion), inspect `pipelines/load.py::_project_record` to see how existing sources handle int/string round-trips. Adjust the contract types if needed (e.g., make `customer_id` `logicalType: string` if integer coercion isn't wired for this case).

- [ ] **Step 3: Sanity sweep**

Run: `uv run pytest -q -m "not e2e"`
Expected: all unit + integration tests pass (the 6 pre-existing `test_progress.py` failures are unrelated).

Run: `uv run pytest -m e2e -v -k excel`
Expected: 1 passed (the new excel edge).

- [ ] **Step 4: Commit**

```bash
git add tests/e2e/sources/test_excel_to_duckdb.py
git commit -m "$(cat <<'EOF'
test(e2e): Excel-to-DuckDB edge with multi-sheet + provenance

Verifies the filesystem source umbrella for excel: one workbook with
Customers + Orders sheets becomes two staging tables. Customers
contract uses inject for source_file + source_sheet provenance. The
fixture workbook is built in tmp_path so no binary file is committed.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

### Task 6: README — add Excel to the verified sources table

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Append the Excel row**

Edit `README.md`. Find the "Verified sources (against DuckDB)" table. Below the CSV row added in Plan #1, append:

```markdown
| Excel (local .xlsx) | openpyxl read-only streaming (ADR-0022); one resource per sheet |
```

- [ ] **Step 2: Add an Excel quickstart snippet**

After the existing CSV quickstart paragraph in the README (the "For a CSV source..." block), add:

````markdown
For an Excel source (local `.xlsx` workbooks), point das at a directory
of workbooks. `das contract bootstrap` enumerates each workbook's
sheets and emits one contract per `(workbook, sheet)`. Each contract's
`das.spec_ref.path` is the workbook filename; `sheet` selects which
sheet to read. Use `inject: {col: sheet}` if you want the sheet name
projected as a column (ADR-0023).

```bash
uv tool install das-cli --with openpyxl

das source add q1-exports \
  --type filesystem \
  --url ./data/q1-exports/

das contract bootstrap q1-exports
# Edit contracts/q1-exports/*.odcs.yaml — set primary keys, refine types.

das ingest q1-exports
```
````

- [ ] **Step 3: Commit**

```bash
git add README.md
git commit -m "$(cat <<'EOF'
docs(readme): document Excel file source + verified-edge row

Adds the Excel row to the verified sources table (DuckDB destination
edge covered by tests/e2e/sources/test_excel_to_duckdb.py) and a
quickstart snippet for local .xlsx ingest under ADR-0022.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Post-plan verification

After all tasks land, run:

- [ ] `uv run pytest -q` — unit + integration (e2e excluded by default).
- [ ] `uv run pytest -m e2e -v` — opt-in e2e suite, including csv and the new excel edge.
- [ ] `uv run pre-commit run --all-files` — ruff format/lint + mypy.

## What's left for Plans #3–#4

- **Plan #3 (XML):** new `file_readers/xml.py` (lxml iterparse with the `elem.clear()` discipline); extend bootstrap with an `--xpath` flag (xml only); add `lxml` to `[xml]` extra; e2e edge.
- **Plan #4 (QVD):** library-research spike up front (streaming-capable parser); new `file_readers/qvd.py`; bootstrap reads embedded XML metadata header for both names *and* types; add the chosen parser to `[qvd]` extra; e2e edge.
