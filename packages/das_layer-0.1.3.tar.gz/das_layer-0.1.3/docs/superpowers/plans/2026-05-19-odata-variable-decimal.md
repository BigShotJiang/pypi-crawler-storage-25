# OData Variable-Decimal Fallback Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fix issue [#73](https://github.com/mattiasthalen/das-cli/issues/73) by replacing the OData bootstrap's `decimal(19,4)` magic default with `decimal(38,9)` whenever the source declares an `Edm.Decimal` property without a usable `(Precision, Scale)` pair.

**Architecture:** Localized change in `src/das_cli/bootstrap/odata.py:_logical_for`. Add a module-level `_MAX_DECIMAL` constant and a `_parse_int` helper. Add a new ADR-0027 documenting the (38, 9) choice and updating `docs/adrs/README.md`. No schema, dlt-glue, or pipeline changes — `schema_factory.py`'s existing `_DECIMAL_RE` already matches `decimal(38,9)`. See spec: `docs/superpowers/specs/2026-05-19-odata-variable-decimal-design.md`.

**Tech Stack:** Python 3.12, `xml.etree.ElementTree` (stdlib), pytest. Tests run via `uv run pytest`.

---

## File Structure

- Modify: `src/das_cli/bootstrap/odata.py` — add `_MAX_DECIMAL` constant, `_parse_int` helper, replace `Edm.Decimal` branch in `_logical_for`.
- Create: `tests/fixtures/sample_odata_metadata_variable_decimal.xml` — one entity with a battery of decimal shapes covering the trigger matrix.
- Modify: `tests/unit/test_bootstrap_odata.py` — add new tests for each fallback case. Existing `test_decimal_with_precision_scale` must remain green unchanged.
- Create: `docs/adrs/0027-max-precision-fallback-for-variable-decimals.md` — new ADR.
- Modify: `docs/adrs/README.md` — append the ADR-0027 index row.

No other files change. `schema_factory.py:30` (`_DECIMAL_RE`) already accepts `decimal(38,9)` without modification.

---

### Task 1: Add the test fixture

**Files:**
- Create: `tests/fixtures/sample_odata_metadata_variable_decimal.xml`

- [ ] **Step 1: Create the fixture file**

The fixture carries one `EntityType` (`Reading`) inside an `EntityContainer` so the bootstrap's container-driven path (ADR-0025) is exercised. Each `Edm.Decimal` property covers one row of the spec's trigger matrix.

Write the file `tests/fixtures/sample_odata_metadata_variable_decimal.xml`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<edmx:Edmx xmlns:edmx="http://docs.oasis-open.org/odata/ns/edmx" Version="4.0">
  <edmx:DataServices>
    <Schema xmlns="http://docs.oasis-open.org/odata/ns/edm" Namespace="VarDec">
      <EntityType Name="Reading">
        <Key><PropertyRef Name="ReadingId" /></Key>
        <Property Name="ReadingId" Type="Edm.Int32" Nullable="false" />
        <Property Name="FixedAmount" Type="Edm.Decimal" Nullable="true" Precision="19" Scale="4" />
        <Property Name="IntegerAmount" Type="Edm.Decimal" Nullable="true" Precision="10" Scale="0" />
        <Property Name="VariableScaleAmount" Type="Edm.Decimal" Nullable="true" Precision="19" Scale="Variable" />
        <Property Name="VariablePrecisionAmount" Type="Edm.Decimal" Nullable="true" Precision="Variable" Scale="4" />
        <Property Name="MissingPrecisionAmount" Type="Edm.Decimal" Nullable="true" Scale="4" />
        <Property Name="MissingScaleAmount" Type="Edm.Decimal" Nullable="true" Precision="19" />
        <Property Name="UnannotatedAmount" Type="Edm.Decimal" Nullable="true" />
        <Property Name="NonsensePrecisionAmount" Type="Edm.Decimal" Nullable="true" Precision="foo" Scale="4" />
        <Property Name="ZeroPrecisionAmount" Type="Edm.Decimal" Nullable="true" Precision="0" Scale="0" />
        <Property Name="ScaleExceedsPrecisionAmount" Type="Edm.Decimal" Nullable="true" Precision="5" Scale="9" />
      </EntityType>
      <EntityContainer Name="Default">
        <EntitySet Name="Readings" EntityType="VarDec.Reading" />
      </EntityContainer>
    </Schema>
  </edmx:DataServices>
</edmx:Edmx>
```

- [ ] **Step 2: Commit the fixture**

```bash
git add tests/fixtures/sample_odata_metadata_variable_decimal.xml
git commit -m "test(fixtures): add OData metadata fixture covering variable-decimal shapes"
```

---

### Task 2: Write failing tests

**Files:**
- Modify: `tests/unit/test_bootstrap_odata.py`

- [ ] **Step 1: Add a fixture function and the new tests at the end of the file**

Open `tests/unit/test_bootstrap_odata.py` and append the following block after the last existing test (after the `test_no_cursor_when_no_modified_date` function):

```python
@pytest.fixture
def variable_decimal_xml(fixtures_dir: Path) -> str:
    return (fixtures_dir / "sample_odata_metadata_variable_decimal.xml").read_text()


def _decimal_props(contracts, resource: str) -> dict[str, str | None]:
    """Return {property_name: physicalType} for the decimal-bearing entity."""
    target = next(c for c in contracts if c.resource_name == resource)
    return {
        p.name: p.physicalType
        for p in target.contract.primary_schema.properties
        if p.logicalType == "number"
    }


def test_decimal_fixed_precision_scale_preserved(variable_decimal_xml: str) -> None:
    contracts = bootstrap_odata_contracts(variable_decimal_xml, source_name="vardec")
    physical = _decimal_props(contracts, "readings")
    assert physical["fixed_amount"] == "decimal(19,4)"


def test_decimal_scale_zero_preserved(variable_decimal_xml: str) -> None:
    """Scale='0' is a real declaration (integer-valued decimal) and must not
    be treated as missing. Regression guard for the parsing logic."""
    contracts = bootstrap_odata_contracts(variable_decimal_xml, source_name="vardec")
    physical = _decimal_props(contracts, "readings")
    assert physical["integer_amount"] == "decimal(10,0)"


def test_decimal_scale_variable_falls_back_to_max(variable_decimal_xml: str) -> None:
    contracts = bootstrap_odata_contracts(variable_decimal_xml, source_name="vardec")
    physical = _decimal_props(contracts, "readings")
    assert physical["variable_scale_amount"] == "decimal(38,9)"


def test_decimal_precision_variable_falls_back_to_max(variable_decimal_xml: str) -> None:
    contracts = bootstrap_odata_contracts(variable_decimal_xml, source_name="vardec")
    physical = _decimal_props(contracts, "readings")
    assert physical["variable_precision_amount"] == "decimal(38,9)"


def test_decimal_missing_precision_falls_back_to_max(variable_decimal_xml: str) -> None:
    contracts = bootstrap_odata_contracts(variable_decimal_xml, source_name="vardec")
    physical = _decimal_props(contracts, "readings")
    assert physical["missing_precision_amount"] == "decimal(38,9)"


def test_decimal_missing_scale_falls_back_to_max(variable_decimal_xml: str) -> None:
    contracts = bootstrap_odata_contracts(variable_decimal_xml, source_name="vardec")
    physical = _decimal_props(contracts, "readings")
    assert physical["missing_scale_amount"] == "decimal(38,9)"


def test_decimal_unannotated_falls_back_to_max(variable_decimal_xml: str) -> None:
    contracts = bootstrap_odata_contracts(variable_decimal_xml, source_name="vardec")
    physical = _decimal_props(contracts, "readings")
    assert physical["unannotated_amount"] == "decimal(38,9)"


def test_decimal_nonsense_precision_falls_back_to_max(variable_decimal_xml: str) -> None:
    contracts = bootstrap_odata_contracts(variable_decimal_xml, source_name="vardec")
    physical = _decimal_props(contracts, "readings")
    assert physical["nonsense_precision_amount"] == "decimal(38,9)"


def test_decimal_zero_precision_falls_back_to_max(variable_decimal_xml: str) -> None:
    """Precision='0' is invalid per the OData CSDL spec — fall back."""
    contracts = bootstrap_odata_contracts(variable_decimal_xml, source_name="vardec")
    physical = _decimal_props(contracts, "readings")
    assert physical["zero_precision_amount"] == "decimal(38,9)"


def test_decimal_scale_exceeds_precision_falls_back_to_max(variable_decimal_xml: str) -> None:
    """Scale > Precision is invalid per the OData CSDL spec — fall back."""
    contracts = bootstrap_odata_contracts(variable_decimal_xml, source_name="vardec")
    physical = _decimal_props(contracts, "readings")
    assert physical["scale_exceeds_precision_amount"] == "decimal(38,9)"
```

- [ ] **Step 2: Run the new tests to verify they fail**

```bash
uv run pytest tests/unit/test_bootstrap_odata.py -v -k "decimal"
```

Expected: `test_decimal_fixed_precision_scale_preserved`, `test_decimal_scale_zero_preserved`, and the pre-existing `test_decimal_with_precision_scale` PASS (both attributes parse as integers, so the current code already honors them). Every `test_decimal_*_falls_back_to_max` test FAILS with an `AssertionError` because the current code returns `decimal(19,4)` instead of `decimal(38,9)`.

- [ ] **Step 3: Commit the red tests**

```bash
git add tests/unit/test_bootstrap_odata.py
git commit -m "test(odata): add failing tests for variable/missing decimal precision-scale"
```

---

### Task 3: Implement the fallback

**Files:**
- Modify: `src/das_cli/bootstrap/odata.py`

- [ ] **Step 1: Add the `_MAX_DECIMAL` constant**

In `src/das_cli/bootstrap/odata.py`, immediately AFTER the `_EDM_TO_LOGICAL` dict (around line 42, before `_CURSOR_HINTS`), add:

```python
# See ADR-0027: max-precision fallback for variable/unspecified decimals.
_MAX_DECIMAL = "decimal(38,9)"
```

- [ ] **Step 2: Add the `_parse_int` helper**

Immediately ABOVE the existing `_logical_for` function, add:

```python
def _parse_int(value: str | None) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except ValueError:
        return None
```

- [ ] **Step 3: Replace the `Edm.Decimal` branch in `_logical_for`**

Find this block (currently around line 50-53):

```python
    if edm_type == "Edm.Decimal":
        if precision and scale is not None:
            return ("number", f"decimal({precision},{scale})")
        return ("number", "decimal(19,4)")  # safe default
```

Replace it with:

```python
    if edm_type == "Edm.Decimal":
        # See ADR-0027. Honor the source's (P, S) only when both parse as
        # integers satisfying the OData CSDL constraint P >= 1 and 0 <= S <= P.
        # Everything else (Scale="Variable", missing attrs, nonsense values)
        # falls back to _MAX_DECIMAL so downstream freeze-mode loads do not
        # truncate real data.
        p = _parse_int(precision)
        s = _parse_int(scale)
        if p is not None and s is not None and p >= 1 and 0 <= s <= p:
            return ("number", f"decimal({p},{s})")
        return ("number", _MAX_DECIMAL)
```

- [ ] **Step 4: Run the new tests to verify they pass**

```bash
uv run pytest tests/unit/test_bootstrap_odata.py -v
```

Expected: every test in the file PASSES. In particular both the pre-existing `test_decimal_with_precision_scale` (still asserting `decimal(19,4)` for the `ListPrice` fixture column) AND every new `test_decimal_*` case from Task 2.

- [ ] **Step 5: Run the full unit suite to confirm no regressions**

```bash
uv run pytest -v
```

Expected: all tests PASS. The e2e marker is excluded by default
(`addopts = "-m 'not e2e'"` in `pyproject.toml`), so this run does NOT
hit the AdventureWorks demo service.

- [ ] **Step 6: Commit the implementation**

```bash
git add src/das_cli/bootstrap/odata.py
git commit -m "fix(odata): fall back to decimal(38,9) for variable/unspecified precision (closes #73)"
```

---

### Task 4: Add ADR-0027

**Files:**
- Create: `docs/adrs/0027-max-precision-fallback-for-variable-decimals.md`
- Modify: `docs/adrs/README.md`

- [ ] **Step 1: Write the ADR file**

Create `docs/adrs/0027-max-precision-fallback-for-variable-decimals.md` with this content:

```markdown
# 0027. Max-precision fallback for variable/unspecified OData decimals

- **Status:** Accepted
- **Date:** 2026-05-19
- **Deciders:** mattiasthalen

## Context

OData `$metadata` may declare an `Edm.Decimal` property with
`Scale="Variable"`, omit `Precision`/`Scale` entirely, or provide values
that do not parse as non-negative integers. The Adventure Works demo
service at GrapeCity exemplifies the first case: every Decimal column
in its `$metadata` carries `Scale="Variable"` with no `Precision`
attribute.

Prior to this decision the OData bootstrap (`src/das_cli/bootstrap/odata.py`)
pinned all such properties to `decimal(19,4)`. Most Adventure Works
decimals do fit (19, 4), but `sales_order_details.LineTotal` is a
computed column whose data exhibits scale up to 6. The contract that
bootstrap authored therefore contradicted the source data, and
ADR-0012's `schema_contract.data_type: freeze` correctly refused to
silently rescale — surfacing the contradiction as a terminal
`NormalizeJobFailed` ("Rescaling Decimal value would cause data loss")
during `das ingest`. See issue #73 for the full reproducer.

The right behavior when the source declines to promise a scale is to
emit a contract that is generous enough to hold any value the source
might subsequently produce. Storing the source's "Variable" as an
opaque annotation in the contract — and resolving precision at load
time — is also possible but couples destinations to OData metadata and
breaks ADR-0012's freeze-time guarantee.

## Decision

When `_logical_for` in `bootstrap/odata.py` cannot resolve a fully
numeric `(Precision, Scale)` pair satisfying the OData CSDL constraint
(`Precision >= 1` and `0 <= Scale <= Precision`), emit
`physicalType: decimal(38,9)` for that `Edm.Decimal` property. The
fallback is exposed as a module-level constant `_MAX_DECIMAL` for
visibility and so a future ADR can revise it cleanly.

The chosen values:

- **Precision 38** is the universal upper bound for fixed-precision
  decimals across every destination das supports today (Delta, Postgres,
  SQL Server, Iceberg, DuckDB all cap at 38).
- **Scale 9** matches dlt's own internal default
  (`DEFAULT_NUMERIC_SCALE = 9`). Aligning eliminates a class of
  normalizer-level rescale paths and leaves 29 whole-number digits —
  well beyond anything plausible in operational data.

The fallback fires for: `Scale="Variable"`, `Precision="Variable"`,
missing `Precision`, missing `Scale`, non-integer values, negative
values, `Precision="0"`, and `Scale > Precision`. When both attributes
parse as integers satisfying the constraint, the source-declared pair
is honored — including `Scale="0"`.

## Alternatives considered

- **Emit bare `decimal` (no precision/scale)** and let the destination
  pick. Requires a parallel change in `dlt_glue/schema_factory.py`'s
  `_DECIMAL_RE` and contradicts ADR-0012's freeze-time stance — a
  contract whose shape varies depending on whether the source declared
  scale is harder for diff (`das contract diff`) and freeze policy to
  reason about.
- **Look up the destination's decimal cap at bootstrap time.**
  Bootstrap emits source-side contracts before destination dispatch
  (ADR-0016). Restructuring for no observable benefit (every
  destination das supports caps at 38).
- **Propagate `Scale="Variable"` as an ODCS `customProperties`
  annotation** and translate at load time. More accurate but defers the
  contradiction-detection that ADR-0012 is built to enforce; freeze
  loses its meaning.
- **Mirror the fix in `bootstrap/sql.py`** for its analogous
  `Numeric` without precision case. Different surface, different test
  fixtures, deserves its own issue and its own decision; deliberately
  deferred. The SQL bootstrap continues to return `("number", None)` in
  that branch, which falls back to dlt's `double` — lossy but
  non-crashing.

## Consequences

- **Positive:** Issue #73 is resolved. Future OData sources with
  `Scale="Variable"` columns work out of the box. The (38, 9) choice is
  documented and centralized in `_MAX_DECIMAL`, not scattered as a
  magic literal.
- **Negative:** Pre-existing sources that relied on the old
  `decimal(19,4)` fallback (i.e. never declared `(Precision, Scale)`,
  and their stored values fit `(19, 4)`) now get `decimal(38,9)`. Stored
  values are unchanged; only the contract YAML shifts. On destinations
  where decimal storage width is precision-tiered (Parquet/Delta uses
  int128 for precision > 18), files written under the new contract use
  a wider physical representation. Acceptable for the safety it buys.
- **Neutral:** The SQL bootstrap's analogous `Numeric`-without-precision
  case is unchanged. A follow-up issue should track aligning it.
```

- [ ] **Step 2: Update the ADR index**

Open `docs/adrs/README.md`. Append a new row to the table immediately after the existing ADR-0026 row (line 35):

```markdown
| 0027 | Max-precision fallback for variable/unspecified OData decimals | Accepted |
```

- [ ] **Step 3: Run the pre-merge ADR check**

Per `CLAUDE.md` pre-merge ADR check:

```bash
# 1. Confirm no ADR file number on the branch collides with main.
git fetch origin main
git log origin/main --name-only --pretty=format: -- 'docs/adrs/0*.md' | sort -u
ls docs/adrs/0*.md
```

Expected: `docs/adrs/0027-max-precision-fallback-for-variable-decimals.md` exists on the branch but NOT on origin/main. ADRs 0001–0026 appear in both.

```bash
# 2. Confirm every ADR file has a matching README row whose title equals
#    the file's `# NNNN.` heading verbatim.
head -1 docs/adrs/0*.md
```

Expected output (first lines of every ADR file):

```
==> docs/adrs/0001-python-not-go.md <==
# 0001. Use Python (not Go) for the CLI

... (all 26 existing rows match) ...

==> docs/adrs/0027-max-precision-fallback-for-variable-decimals.md <==
# 0027. Max-precision fallback for variable/unspecified OData decimals
```

Verify the README row's title text matches the heading after `# NNNN.` exactly.

```bash
# 3. Confirm README has no rows referring to ADR numbers that don't exist
#    as files.
grep -oE '^\| 00[0-9]{2} ' docs/adrs/README.md | sort -u
ls docs/adrs/00*.md | sed -E 's@.*/(00[0-9]{2}).*@| \1 @' | sort -u
```

Expected: both lists are identical (0001 through 0027).

- [ ] **Step 4: Commit the ADR**

```bash
git add docs/adrs/0027-max-precision-fallback-for-variable-decimals.md docs/adrs/README.md
git commit -m "docs(adr): ADR-0027 max-precision fallback for variable OData decimals"
```

---

### Task 5: Final verification

**Files:** none (read-only checks)

- [ ] **Step 1: Verify the worktree has a clean, complete history**

```bash
git log --oneline main..HEAD
```

Expected: five new commits on the worktree branch, in order:

```
<sha> docs(adr): ADR-0027 max-precision fallback for variable OData decimals
<sha> fix(odata): fall back to decimal(38,9) for variable/unspecified precision (closes #73)
<sha> test(odata): add failing tests for variable/missing decimal precision-scale
<sha> test(fixtures): add OData metadata fixture covering variable-decimal shapes
<sha> docs(spec/plan): odata bootstrap max-precision fallback for variable decimals
```

The spec/plan commits from the brainstorming phase already exist on the branch.

- [ ] **Step 2: Verification-before-completion**

Re-run the full unit suite to confirm nothing regressed since the implementation commit:

```bash
uv run pytest -v
```

Expected: all tests PASS. Specifically all 10 newly added decimal tests in `tests/unit/test_bootstrap_odata.py` are green, and the pre-existing `test_decimal_with_precision_scale` is also green.

- [ ] **Step 3: Confirm linting/typing still clean**

```bash
uv run ruff check src/das_cli/bootstrap/odata.py tests/unit/test_bootstrap_odata.py
uv run mypy src/das_cli/bootstrap/odata.py
```

Expected: no errors. (Project-wide mypy is strict per `pyproject.toml`; the changes here only add a typed helper and a typed constant.)

- [ ] **Step 4: Sanity-check the fix locally against the issue's reproducer (optional, manual)**

If you have access to a workspace and want to confirm the user-facing behavior end-to-end before opening the PR:

```bash
# In a scratch dir, install the worktree's das as an editable tool, then:
das source add adventure_works \
  --type odata \
  --url https://demodata.grapecity.com/adventureworks/odata/v1
das contract bootstrap adventure_works
grep -A1 'line_total' das/contracts/adventure_works/sales_order_details.odcs.yaml
# Expected: physicalType: decimal(38,9)
```

This is optional — the unit tests in Task 3 already prove the bootstrap behavior. The manual check only validates that the issue's reproducer is no longer hit.

---

## Notes for the implementer

- **Do not change `bootstrap/sql.py`** in this plan, even though it has an analogous shape. That's a separate decision (see ADR-0027 "Alternatives considered") and a separate issue surface.
- **Do not change `dlt_glue/schema_factory.py`** — the existing `_DECIMAL_RE` already matches `decimal(38,9)`.
- The new ADR is being authored on a feature branch. Per `CLAUDE.md` lifecycle policy, ADRs are free to evolve on the branch; once this branch is merged to `main`, Decision and Context become immutable. The pre-merge ADR check in Task 4 Step 3 is the gate.
