# OData bootstrap driven by `<EntityContainer><EntitySet>` — implementation plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fix issue #63 — `das contract bootstrap` over-produces contracts because `bootstrap_odata_contracts()` walks every `<EntityType>` in `$metadata` instead of driving off the authoritative `<EntityContainer><EntitySet>` declarations. AdventureWorks: 66 contracts emitted, 59 queryable; the 7 extras 404 at extract time.

**Architecture:** One internal-API change in `src/das_cli/bootstrap/odata.py`. When `<EntityContainer>` is present, iterate its `<EntitySet>` declarations and look up the backing `<EntityType>` element for schema; types not declared as EntitySets are dropped. When `<EntityContainer>` is absent (OData v1/v2, partial metadata), preserve the per-EntityType walk. `das.spec_ref.entity_set` semantics (ADR-0024) and `pluralize(snake_case(...))` resource naming both unchanged. A new ADR-0025 records the inversion and extends ADR-0024.

Spec: `docs/superpowers/specs/2026-05-13-odata-bootstrap-entitycontainer-driven-design.md`.

**Tech Stack:** Python 3.12, stdlib `xml.etree.ElementTree`, pytest, uv, ruff, mypy, pre-commit. No new dependencies.

---

## File map

- **Modify:** `src/das_cli/bootstrap/odata.py` — invert the loop in `bootstrap_odata_contracts`; collapse `_build_contract`'s `entity_set_by_type: dict[str, str]` parameter to a single `entity_set: str | None`.
- **Modify:** `tests/unit/test_bootstrap_odata.py` — rewrite one existing test whose expectation inverts; rename one existing test for clarity; add one new test for malformed metadata.
- **Create:** `docs/adrs/0025-odata-bootstrap-driven-by-entity-container.md` — new ADR extending ADR-0024.
- **Modify:** `docs/adrs/0024-odata-entityset-on-spec-ref.md` — Status-only edit (the one in-place change CLAUDE.md allows on a merged ADR).
- **Modify:** `docs/adrs/README.md` — append the ADR-0025 row.
- **Modify:** `tests/e2e/sources/test_odata_adventureworks.py` — add a count-check e2e against the live feed (no extract).

No CI / config / dependency changes.

---

### Task 1: Invert the bootstrap loop to be `<EntityContainer>`-driven (TDD)

The refactor lives in one function. Tests change first to express the new contract, then the implementation makes them green. Existing tests that already match the new contract (fixture has matching EntityType/EntitySet pairs) stay green throughout.

**Files:**
- Modify: `tests/unit/test_bootstrap_odata.py:144-172` (existing `test_entity_set_omitted_when_type_not_in_container` — inverts) and `tests/unit/test_bootstrap_odata.py:13-16` (existing `test_emits_one_contract_per_entity_type` — rename) and append one new test.
- Modify: `src/das_cli/bootstrap/odata.py:86-181` (the `_build_contract`, `_build_custom_properties`, and `bootstrap_odata_contracts` block).

- [ ] **Step 1: Rewrite the test that asserts the old over-producing behavior**

In `tests/unit/test_bootstrap_odata.py`, find this test (currently at lines 144-172):

```python
def test_entity_set_omitted_when_type_not_in_container() -> None:
    """EntityContainer that covers only some EntityTypes — uncovered types still emit."""
    xml = """<?xml version="1.0" encoding="UTF-8"?>
<edmx:Edmx xmlns:edmx="http://docs.oasis-open.org/odata/ns/edmx" Version="4.0">
  <edmx:DataServices>
    <Schema xmlns="http://docs.oasis-open.org/odata/ns/edm" Namespace="Test.Models">
      <EntityType Name="Product">
        <Key><PropertyRef Name="ProductId" /></Key>
        <Property Name="ProductId" Type="Edm.Int32" Nullable="false" />
      </EntityType>
      <EntityType Name="Department">
        <Key><PropertyRef Name="DepartmentId" /></Key>
        <Property Name="DepartmentId" Type="Edm.Int16" Nullable="false" />
      </EntityType>
      <EntityContainer Name="Default">
        <EntitySet Name="Products" EntityType="Test.Models.Product" />
      </EntityContainer>
    </Schema>
  </edmx:DataServices>
</edmx:Edmx>
"""
    contracts = bootstrap_odata_contracts(xml, source_name="aw")
    prod = next(c for c in contracts if c.resource_name == "products")
    dept = next(c for c in contracts if c.resource_name == "departments")
    prod_spec = next(p for p in prod.contract.custom_properties if p.property == "das.spec_ref")
    dept_spec = next(p for p in dept.contract.custom_properties if p.property == "das.spec_ref")
    assert prod_spec.value == {"kind": "odata", "type": "Product", "entity_set": "Products"}
    assert dept_spec.value == {"kind": "odata", "type": "Department"}
    assert "entity_set" not in dept_spec.value
```

Replace the entire function with:

```python
def test_entity_type_without_entity_set_is_dropped() -> None:
    """When `<EntityContainer>` is present it is the authority on what is queryable.
    EntityTypes that don't appear as an EntitySet are dropped — see ADR-0025."""
    xml = """<?xml version="1.0" encoding="UTF-8"?>
<edmx:Edmx xmlns:edmx="http://docs.oasis-open.org/odata/ns/edmx" Version="4.0">
  <edmx:DataServices>
    <Schema xmlns="http://docs.oasis-open.org/odata/ns/edm" Namespace="Test.Models">
      <EntityType Name="Product">
        <Key><PropertyRef Name="ProductId" /></Key>
        <Property Name="ProductId" Type="Edm.Int32" Nullable="false" />
      </EntityType>
      <EntityType Name="Department">
        <Key><PropertyRef Name="DepartmentId" /></Key>
        <Property Name="DepartmentId" Type="Edm.Int16" Nullable="false" />
      </EntityType>
      <EntityContainer Name="Default">
        <EntitySet Name="Products" EntityType="Test.Models.Product" />
      </EntityContainer>
    </Schema>
  </edmx:DataServices>
</edmx:Edmx>
"""
    contracts = bootstrap_odata_contracts(xml, source_name="aw")
    resource_names = sorted(c.resource_name for c in contracts)
    assert resource_names == ["products"]
    prod = contracts[0]
    prod_spec = next(p for p in prod.contract.custom_properties if p.property == "das.spec_ref")
    assert prod_spec.value == {"kind": "odata", "type": "Product", "entity_set": "Products"}
```

- [ ] **Step 2: Rename `test_emits_one_contract_per_entity_type` for clarity**

In `tests/unit/test_bootstrap_odata.py` (currently at line 13), find:

```python
def test_emits_one_contract_per_entity_type(sample_xml: str) -> None:
    contracts = bootstrap_odata_contracts(sample_xml, source_name="adventureworks")
    names = sorted(c.contract.id for c in contracts)
    assert names == ["adventureworks.departments", "adventureworks.products"]
```

Rename the function and update the docstring to match the new semantics:

```python
def test_emits_one_contract_per_entity_set_when_container_present(sample_xml: str) -> None:
    """The fixture's EntityContainer declares two EntitySets (Products, Departments);
    both EntityTypes are referenced so two contracts emit. See ADR-0025."""
    contracts = bootstrap_odata_contracts(sample_xml, source_name="adventureworks")
    names = sorted(c.contract.id for c in contracts)
    assert names == ["adventureworks.departments", "adventureworks.products"]
```

- [ ] **Step 3: Add a new test for malformed metadata (EntitySet references missing EntityType)**

Append to `tests/unit/test_bootstrap_odata.py` (after the last test currently in the file):

```python
def test_malformed_metadata_entity_set_without_matching_entity_type() -> None:
    """EntityContainer references a type with no matching <EntityType> element.
    The orphaned EntitySet is silently skipped; well-formed sets still emit. See ADR-0025."""
    xml = """<?xml version="1.0" encoding="UTF-8"?>
<edmx:Edmx xmlns:edmx="http://docs.oasis-open.org/odata/ns/edmx" Version="4.0">
  <edmx:DataServices>
    <Schema xmlns="http://docs.oasis-open.org/odata/ns/edm" Namespace="Test.Models">
      <EntityType Name="Product">
        <Key><PropertyRef Name="ProductId" /></Key>
        <Property Name="ProductId" Type="Edm.Int32" Nullable="false" />
      </EntityType>
      <EntityContainer Name="Default">
        <EntitySet Name="Products" EntityType="Test.Models.Product" />
        <EntitySet Name="Ghosts" EntityType="Test.Models.Ghost" />
      </EntityContainer>
    </Schema>
  </edmx:DataServices>
</edmx:Edmx>
"""
    contracts = bootstrap_odata_contracts(xml, source_name="aw")
    resource_names = sorted(c.resource_name for c in contracts)
    assert resource_names == ["products"]
```

- [ ] **Step 4: Run the bootstrap-odata tests to verify the expected failures**

```bash
uv run pytest tests/unit/test_bootstrap_odata.py -v
```

Expected: the rewritten `test_entity_type_without_entity_set_is_dropped` fails (today's code emits 2 contracts; the test expects 1). The new `test_malformed_metadata_entity_set_without_matching_entity_type` fails (today's code emits 1 contract from the Product EntityType, ignoring container — actually it *would* emit "products" today too, so this test might already pass; if it does, that's fine, it just means we have stronger pre-existing coverage). The renamed `test_emits_one_contract_per_entity_set_when_container_present` continues to pass. All other tests in the file continue to pass.

Acceptable terminal state for this step: at least the rewritten test must be RED. If the malformed-metadata test is also RED, even better. Continue to Step 5 regardless.

- [ ] **Step 5: Implement the inverted bootstrap loop**

In `src/das_cli/bootstrap/odata.py`, replace the block starting at `def _build_contract(` (line 86) through the end of `def bootstrap_odata_contracts(` (line 180) with:

```python
def _build_contract(
    entity: ElementTree.Element,
    source_name: str,
    *,
    entity_set: str | None,
) -> LoadedContract:
    type_name = entity.get("Name", "")
    key_names: set[str] = set()
    key_elem = entity.find("edm:Key", _NS)
    if key_elem is not None:
        for ref in key_elem.findall("edm:PropertyRef", _NS):
            n = ref.get("Name")
            if n:
                key_names.add(n)

    properties = [
        _build_property(p, key_names=key_names) for p in entity.findall("edm:Property", _NS)
    ]

    resource_name = pluralize(type_name)
    contract = OdcsContract(
        apiVersion="v3.0.0",
        kind="DataContract",
        id=f"{source_name}.{resource_name}",
        name=type_name,
        version="0.1.0",
        status="draft",
        info=OdcsInfo(title=type_name, owner="data-platform"),
        schema=[
            OdcsSchema(
                name=resource_name,
                physicalName=resource_name,
                physicalType="table",
                properties=properties,
            )
        ],
        customProperties=_build_custom_properties(
            type_name, properties, entity_set=entity_set
        ),
    )

    return LoadedContract(
        path=Path(f"{resource_name}.odcs.yaml"),
        resource_name=resource_name,
        contract=contract,
    )


def _build_custom_properties(
    type_name: str, properties: list[OdcsProperty], *, entity_set: str | None
) -> list[CustomProperty]:
    # See ADR-0024 for the entity_set persistence rule, and ADR-0025 for the
    # EntityContainer-driven emission rule that ensures entity_set is populated
    # whenever a container is present.
    spec_ref_value: dict[str, str] = {"kind": "odata", "type": type_name}
    if entity_set:
        spec_ref_value["entity_set"] = entity_set
    cps: list[CustomProperty] = [
        CustomProperty(property="das.spec_ref", value=spec_ref_value),
    ]
    cursor = _pick_cursor(properties)
    if cursor:
        cps.append(CustomProperty(property="das.cursor", value=cursor))
    return cps


def _build_entity_set_map(root: ElementTree.Element) -> dict[str, str]:
    """Map bare EntityType name → declared EntitySet `Name` from `<EntityContainer>`.

    Strips the namespace prefix from the EntitySet's `EntityType` attribute
    (`AdventureWorks.Address` → `Address`). Returns an empty dict if `$metadata`
    has no EntityContainer.
    """
    out: dict[str, str] = {}
    for container in root.iter(f"{{{_NS['edm']}}}EntityContainer"):
        for entity_set in container.findall("edm:EntitySet", _NS):
            set_name = entity_set.get("Name")
            qualified_type = entity_set.get("EntityType", "")
            if not set_name or not qualified_type:
                continue
            bare_type = qualified_type.rsplit(".", 1)[-1]
            out[bare_type] = set_name
    return out


def bootstrap_odata_contracts(metadata_xml: str, *, source_name: str) -> list[LoadedContract]:
    """Parse $metadata XML and return one LoadedContract per queryable resource.

    When `<EntityContainer>` is present it is authoritative: one contract per
    declared `<EntitySet>`, with the backing `<EntityType>` element looked up
    for schema. EntityTypes referenced only via NavigationProperty / Collection
    are dropped. See ADR-0025.

    When `<EntityContainer>` is absent (OData v1/v2 or stripped metadata),
    fall back to the legacy per-EntityType walk; `entity_set` is omitted from
    `das.spec_ref` and `synthesize_odata_endpoint()` uses its
    case-preserving pluralization heuristic (ADR-0024).
    """
    root = ElementTree.fromstring(metadata_xml)
    entity_set_by_type = _build_entity_set_map(root)
    type_elements = {
        e.get("Name"): e for e in root.iter(f"{{{_NS['edm']}}}EntityType")
    }

    out: list[LoadedContract] = []
    if entity_set_by_type:
        for type_name, set_name in entity_set_by_type.items():
            elem = type_elements.get(type_name)
            if elem is None:
                # Malformed metadata: EntitySet references a type with no
                # matching <EntityType> element. Skip silently.
                continue
            out.append(
                _build_contract(elem, source_name=source_name, entity_set=set_name)
            )
    else:
        for elem in type_elements.values():
            out.append(
                _build_contract(elem, source_name=source_name, entity_set=None)
            )
    return out
```

- [ ] **Step 6: Run the bootstrap-odata tests to verify all green**

```bash
uv run pytest tests/unit/test_bootstrap_odata.py -v
```

Expected: all tests pass. Specifically:

- Rewritten `test_entity_type_without_entity_set_is_dropped` — green.
- Renamed `test_emits_one_contract_per_entity_set_when_container_present` — green.
- New `test_malformed_metadata_entity_set_without_matching_entity_type` — green.
- All other tests in the file (`test_property_names_snake_cased`, `test_physical_names_preserved`, `test_decimal_with_precision_scale`, `test_int32_maps_to_integer`, `test_datetime_offset_to_timestamp`, `test_cursor_heuristic_picks_modified_date`, `test_spec_ref_added`, `test_no_cursor_when_no_modified_date`, `test_entity_set_added_when_container_present`, `test_entity_set_strips_namespace_from_entity_type`, `test_entity_set_omitted_when_no_container`, `test_irregular_plurals_captured_from_entity_container`) — green.

If `test_entity_set_added_when_container_present` fails, double-check that the fixture `tests/fixtures/sample_odata_metadata.xml` still contains its `<EntityContainer>` block (it should, post-#62 — line 19).

- [ ] **Step 7: Run the diff tests (which exercise the no-container fallback)**

```bash
uv run pytest tests/unit/test_diff.py -v
```

Expected: all four diff tests pass. The diff fixtures don't include `<EntityContainer>`, so they exercise the legacy fallback path of `bootstrap_odata_contracts`.

- [ ] **Step 8: Commit**

```bash
git add src/das_cli/bootstrap/odata.py tests/unit/test_bootstrap_odata.py
git commit -m "$(cat <<'EOF'
fix(bootstrap-odata): drive contracts off <EntityContainer><EntitySet> (#63)

bootstrap_odata_contracts() previously walked every <EntityType> in
$metadata, including types reachable only through NavigationProperty/
Collection. AdventureWorks emitted 66 contracts against 59 queryable
EntitySets; the 7 extras 404'd at extract time.

When <EntityContainer> is present it is now the authority: one contract
per declared <EntitySet>, with the backing <EntityType> looked up for
schema. EntityTypes that aren't declared as EntitySets are dropped.
$metadata without an EntityContainer keeps the legacy per-EntityType
walk. das.spec_ref.entity_set semantics (ADR-0024) and resource naming
are unchanged. See ADR-0025.

Fixes #63.
EOF
)"
```

---

### Task 2: Write ADR-0025 and update the ADR index (and ADR-0024's status line)

Per `CLAUDE.md`: ADRs on a feature branch are free to evolve; the Status flip on the already-merged ADR-0024 is the one in-place edit the lifecycle policy allows. The new ADR-0025 lands here on the branch.

**Files:**
- Create: `docs/adrs/0025-odata-bootstrap-driven-by-entity-container.md`
- Modify: `docs/adrs/0024-odata-entityset-on-spec-ref.md` (Status line only)
- Modify: `docs/adrs/README.md` (append one row; update ADR-0024's status cell)

- [ ] **Step 1: Verify there's no ADR-0025 collision on `origin/main`**

```bash
git fetch origin main && git ls-tree --name-only origin/main docs/adrs/ | grep '^docs/adrs/0025' || echo "no collision"
```

Expected: `no collision`. If origin/main already contains a `0025-*.md`, renumber this branch's ADR to the next free number (0026, 0027, …) and update every reference (the spec, the README row, the docstrings in `_build_custom_properties` / `bootstrap_odata_contracts` from Task 1, and ADR-0024's Status line).

- [ ] **Step 2: Create the new ADR**

Create `docs/adrs/0025-odata-bootstrap-driven-by-entity-container.md`:

```markdown
# 0025. OData bootstrap driven by `<EntityContainer><EntitySet>`

- **Status:** Accepted
- **Date:** 2026-05-13
- **Deciders:** mattiasthalen

## Context

ADR-0024 added `das.spec_ref.entity_set` and a fallback pluralization
heuristic so `synthesize_odata_endpoint()` can produce correct URL paths
for irregular OData plurals. It did not change *which* EntityTypes get a
contract: `bootstrap_odata_contracts()` continued to walk every
`<EntityType>` in `$metadata`.

EDM separates two concerns. `<EntityType>` declares a type — its keys,
properties, and navigation links. `<EntityContainer><EntitySet>` declares
the queryable *resources* the service exposes; the set name is the URL
segment served at runtime. Services routinely declare EntityTypes that
are not exposed as EntitySets — link targets reached only through
`NavigationProperty` / `Collection(...)`, or join shapes the service
hides. Treating every EntityType as queryable over-produces contracts
that 404 at extract time.

Evidence from the public AdventureWorks demo feed: `$metadata` declares
59 EntitySets; the bootstrap emitted 66 contracts. The 7 extras —
`country_region_currencies`, `person_credit_cards`, `passwords`,
`product_model_product_description_cultures`,
`sales_order_header_sales_reasons`, `product_product_photos`,
`special_offer_products` — are not in `<EntityContainer>` and 404 when
queried.

## Decision

`bootstrap_odata_contracts()` iterates `<EntityContainer><EntitySet>`
declarations and looks up the backing `<EntityType>` element for schema.
One contract per `<EntitySet>`. EntityTypes referenced only via
`NavigationProperty` / `Collection(...)` are dropped.

When `<EntityContainer>` is absent (rare; OData v1/v2 or stripped
metadata), preserve the legacy per-EntityType walk. The container-less
case has no authoritative source of "what is queryable", so the
heuristic fallback in `synthesize_odata_endpoint()` (ADR-0024) does its
documented job.

Resource naming (`pluralize(snake_case(type_name))`) is unchanged.
`das.spec_ref.entity_set` semantics (ADR-0024) are unchanged. The
heuristic fallback in `synthesize_odata_endpoint()` is now reached only
by container-less metadata or pre-ADR-0024 contracts — exactly the
purpose ADR-0024 documented for it.

## Alternatives considered

- **Hard-fail on container-less metadata.** Stricter, but breaks an
  extant code path with no compensating benefit. Overproduction only
  matters when types-without-sets exist, which container-less metadata
  cannot express.
- **Live-probe each EntitySet during bootstrap.** Catches the
  declared-but-still-404 case (e.g., `BusinessEntities` on the
  AdventureWorks demo), but adds an HTTP call per resource and slows
  bootstrap from seconds to minutes. Worth a future `--probe` flag;
  out of scope here.
- **Leave bootstrap as-is and ship `das contract prune` to drop dead
  contracts after the first failed ingest.** Shifts work to the user
  and ignores the authority-of-truth question.

## Consequences

- **Positive:** Bootstrap output aligns with what the server actually
  serves. The heuristic fallback in `synthesize_odata_endpoint()`
  becomes reachable only via container-less metadata or pre-ADR-0024
  contracts — exactly its documented purpose.
- **Negative:** Pre-existing on-disk contracts for EntityTypes now
  dropped (e.g., `passwords.odcs.yaml` on AdventureWorks) remain until
  the user re-bootstraps with `--force`. Documented migration path; no
  automatic upgrade.
- **Neutral:** Container-less metadata follows the same legacy path as
  before. Existing diff and bootstrap tests over container-less
  fixtures continue to pass unchanged.
```

- [ ] **Step 3: Flip ADR-0024's Status line**

In `docs/adrs/0024-odata-entityset-on-spec-ref.md`, change the Status line. Find:

```markdown
- **Status:** Accepted
```

Replace with:

```markdown
- **Status:** Accepted (extended by ADR-0025)
```

Do not touch the Decision, Context, Alternatives, or Consequences sections — Status is the one in-place edit `CLAUDE.md` allows on a merged ADR. ADR-0006 (`Accepted (extended by ADR-0015)`) is the precedent.

- [ ] **Step 4: Update the ADR index**

In `docs/adrs/README.md`, find:

```markdown
| 0024 | OData EntitySet name persisted on `das.spec_ref` | Accepted |
```

Replace with:

```markdown
| 0024 | OData EntitySet name persisted on `das.spec_ref` | Accepted (extended by ADR-0025) |
| 0025 | OData bootstrap driven by `<EntityContainer><EntitySet>` | Accepted |
```

- [ ] **Step 5: Confirm ADR index sanity per `CLAUDE.md`**

Run the project's pre-merge checks:

```bash
head -1 docs/adrs/0*.md
```

Expected: the last line printed is `# 0025. OData bootstrap driven by ...`. Confirm the title matches the README row verbatim (modulo the leading `0025.` / numeric column).

```bash
ls docs/adrs/0*.md | wc -l
```

Expected: 25 (0001 through 0025, plus README.md is not in the glob).

- [ ] **Step 6: Commit**

```bash
git add docs/adrs/0025-odata-bootstrap-driven-by-entity-container.md \
        docs/adrs/0024-odata-entityset-on-spec-ref.md \
        docs/adrs/README.md
git commit -m "$(cat <<'EOF'
docs(adr): 0025 — drive OData bootstrap off <EntityContainer><EntitySet>

Records the iteration inversion in bootstrap_odata_contracts(). Extends
ADR-0024 — the entity_set persistence rule there is unchanged; this ADR
adds the rule about which EntityTypes get a contract emitted at all.
Flips ADR-0024 Status to "Accepted (extended by ADR-0025)" (the only
in-place edit allowed by the lifecycle policy on a merged ADR). Updates
the index row for ADR-0024 and appends the ADR-0025 row.
EOF
)"
```

---

### Task 3: Add an opt-in e2e count-check against the live AdventureWorks feed

Today's e2e tests both use `--only`, so the over-producing behavior the issue reports never shows up in CI. Add a third e2e that bootstraps the full source (no `--only`) and asserts the on-disk contract count equals the `<EntitySet>` count in AdventureWorks' `$metadata`. No extract — one HTTP round-trip plus a filesystem read. Cheap and the direct live regression for #63.

**Files:**
- Modify: `tests/e2e/sources/test_odata_adventureworks.py` (append after the existing two tests)

- [ ] **Step 1: Append the test**

Append to `tests/e2e/sources/test_odata_adventureworks.py`:

```python
def test_adventureworks_bootstrap_count_matches_entity_container(
    workspace: Path, cli_runner: CliRunner
) -> None:
    """Regression: issue #63 — bootstrap emitted 66 contracts against an
    EntityContainer that declares 59 EntitySets, and the 7 extras 404 at
    extract time.

    Bootstraps the full source (no --only), then independently fetches
    $metadata and counts <EntitySet> elements inside <EntityContainer>.
    Asserts the on-disk contract count equals the EntitySet count.
    """
    import requests
    from xml.etree import ElementTree

    cli_runner.invoke(app, ["init"])
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "adventureworks",
            "--type",
            "odata",
            "--url",
            "https://demodata.grapecity.com/adventureworks/odata/v1",
        ],
    )

    bootstrap = cli_runner.invoke(
        app,
        ["contract", "bootstrap", "adventureworks"],
    )
    assert bootstrap.exit_code == 0, bootstrap.stdout + bootstrap.stderr

    metadata_url = "https://demodata.grapecity.com/adventureworks/odata/v1/$metadata"
    resp = requests.get(metadata_url, timeout=30)
    resp.raise_for_status()
    root = ElementTree.fromstring(resp.text)
    ns = {"edm": "http://docs.oasis-open.org/odata/ns/edm"}
    expected_count = sum(
        len(container.findall("edm:EntitySet", ns))
        for container in root.iter("{http://docs.oasis-open.org/odata/ns/edm}EntityContainer")
    )
    assert expected_count > 0, "AdventureWorks $metadata returned no EntitySets"

    contracts_dir = workspace / "contracts" / "adventureworks"
    actual_count = len(list(contracts_dir.glob("*.odcs.yaml")))
    assert actual_count == expected_count, (
        f"bootstrap wrote {actual_count} contracts but AdventureWorks "
        f"<EntityContainer> declares {expected_count} EntitySets"
    )
```

The test deliberately re-derives `expected_count` from the live `$metadata` rather than hard-coding `59`. AdventureWorks demo schema can shift; the test verifies the *invariant* (bootstrap count == EntitySet count), not a magic number.

- [ ] **Step 2: Run the new e2e test (opt-in via `-m e2e`)**

```bash
uv run pytest tests/e2e/sources/test_odata_adventureworks.py::test_adventureworks_bootstrap_count_matches_entity_container -v -m e2e
```

Expected: PASS. If it fails reporting `actual_count > expected_count`, Task 1's bootstrap refactor didn't land or has a bug. If it fails with a network/DNS error, rerun.

- [ ] **Step 3: Run the full e2e file**

```bash
uv run pytest tests/e2e/sources/test_odata_adventureworks.py -v -m e2e
```

Expected: all three tests pass — `test_adventureworks_bootstrap_extract_load`, `test_adventureworks_irregular_plural_addresses`, and the new `test_adventureworks_bootstrap_count_matches_entity_container`.

- [ ] **Step 4: Commit**

```bash
git add tests/e2e/sources/test_odata_adventureworks.py
git commit -m "$(cat <<'EOF'
test(e2e): AdventureWorks bootstrap count matches <EntityContainer> (#63)

Live regression for issue #63. Bootstraps the full source against the
public AdventureWorks OData feed (no --only), independently counts
<EntitySet> elements in $metadata, and asserts the on-disk contract
count matches. Catches any future regression that resurrects the
EntityType-walk behavior. Opt-in via -m e2e.
EOF
)"
```

---

### Task 4: Run the full local suite + pre-commit

Confirm nothing else regressed before pushing.

- [ ] **Step 1: Run unit + integration**

```bash
uv run pytest tests/unit tests/integration -q
```

Expected: all green. Task 1 net changes: +1 test (the new malformed-metadata test); the rewritten test replaces an old one (count unchanged for that swap) and the rename is name-only. Baseline tests count from `origin/main` + 1.

- [ ] **Step 2: Run pre-commit on all files**

```bash
uv run pre-commit run --all-files
```

Expected: clean. If `ruff-format` reflows any new code, stage the reflow and create a `style:` follow-up commit. If `mypy` complains about anything in `bootstrap/odata.py`, check that `type_elements` is typed correctly (it's `dict[str | None, ElementTree.Element]` strictly speaking since `e.get("Name")` returns `str | None`; if mypy flags this, narrow the comprehension to `if (n := e.get("Name")) is not None` and key on `n`).

- [ ] **Step 3: Optional — run the OData e2e suite locally if you have network**

```bash
uv run pytest tests/e2e/sources/test_odata_adventureworks.py -v -m e2e
```

Expected: all three tests pass. Skip if no network — CI runs them.

---

### Task 5: Push the branch and open a PR

- [ ] **Step 1: Push the branch**

```bash
git push -u origin worktree-worktree-issue-63-brainstorm
```

(The branch name is the auto-generated one from the worktree this work was started in. If you prefer a cleaner branch name, rename locally with `git branch -m worktree-issue-63-entitycontainer-driven-bootstrap` and push that instead — keep the rename consistent with whatever the PR title references.)

- [ ] **Step 2: Open the PR**

```bash
gh pr create --title "fix(bootstrap-odata): drive contracts off <EntityContainer><EntitySet> (#63)" --body "$(cat <<'EOF'
## Summary

- Fixes #63 — `bootstrap_odata_contracts()` walked every `<EntityType>` in `$metadata`, emitting contracts for types reachable only through `NavigationProperty`/`Collection`. AdventureWorks: 66 contracts emitted, 59 queryable; the 7 extras 404'd at extract time.
- When `<EntityContainer>` is present it is now the authority: one contract per declared `<EntitySet>`, with the backing `<EntityType>` looked up for schema. Container-less `$metadata` keeps the legacy walk.
- `das.spec_ref.entity_set` semantics (ADR-0024) and resource naming (`pluralize(snake_case(type_name))`) are unchanged. The heuristic fallback in `synthesize_odata_endpoint()` is now reached only by container-less or pre-ADR-0024 contracts — exactly its documented purpose.
- Adds ADR-0025 extending ADR-0024. Status flip on ADR-0024 is the one in-place edit allowed by `CLAUDE.md`.

Spec: `docs/superpowers/specs/2026-05-13-odata-bootstrap-entitycontainer-driven-design.md`.
Plan: `docs/superpowers/plans/2026-05-13-odata-bootstrap-entitycontainer-driven.md`.

## Test plan

- [x] `uv run pytest tests/unit tests/integration -q` — green locally; net +1 unit test.
- [x] `uv run pre-commit run --all-files` — clean.
- [x] Bootstrap-side: 1 rewritten test (`test_entity_type_without_entity_set_is_dropped`), 1 rename for clarity (`test_emits_one_contract_per_entity_set_when_container_present`), 1 new test (`test_malformed_metadata_entity_set_without_matching_entity_type`).
- [x] Diff tests (`tests/unit/test_diff.py`) — unchanged; their fixtures are container-less and exercise the legacy path.
- [ ] CI e2e: new `test_adventureworks_bootstrap_count_matches_entity_container` is the live regression — must run on a runner with network access to `demodata.grapecity.com`.

## Migration

Existing OData workspaces:

- Re-run `das contract bootstrap <source> --force` to drop now-dropped contract files. The remaining contracts are unchanged (resource names, `das.spec_ref.entity_set` values, schemas all stable).
- Without re-bootstrap, stale contracts for un-queryable EntityTypes remain on disk and will 404 at extract — exactly as before.

## ADR

- **New:** ADR-0025 — OData bootstrap driven by `<EntityContainer><EntitySet>`.
- **Status edit:** ADR-0024 → `Accepted (extended by ADR-0025)`. Status is the only in-place mutation `CLAUDE.md` allows on a merged ADR; ADR-0006 → ADR-0015 is the precedent.

## Out of scope

- Services that *declare* an EntitySet but still 404 (e.g., `BusinessEntities` on the AdventureWorks demo). Needs a live probe; future `--probe` flag.
- `das ingest` all-or-nothing extract semantics when one resource 404s. Separate side observation on #61.
- Aligning `resource_name` with EntitySet name (would rename existing on-disk contracts and downstream tables — not a behavior change to bundle here).
EOF
)"
```

- [ ] **Step 3: Watch CI**

```bash
gh pr checks --watch
```

Expected: all checks green. If the new e2e test fails on the CI runner, confirm the runner has network access to `demodata.grapecity.com` and that the test isn't being filtered out by the `-m e2e` marker requirement.

---

## Self-review

- **Spec coverage:** every spec section maps to a task —
  - Problem / evidence → context in Task 1; live regression in Task 3.
  - Decision §"Code shape" → Task 1 Step 5.
  - Decision §"What does NOT change" → preserved in Task 1 (resource naming untouched; `_build_entity_set_map` untouched).
  - Tests §unit (rewrite + 1 new) → Task 1 Steps 1–3.
  - Tests §diff (stay green via legacy fallback) → Task 1 Step 7.
  - Tests §e2e (count check) → Task 3.
  - ADR work (new 0025 + 0024 status flip + README) → Task 2.
  - Out-of-scope items → not implemented; reflected in PR body and ADR-0025 Alternatives.
- **Placeholder scan:** no TBD / "implement later" / "similar to Task N" — every step ships a complete code block or a precise command. The one optional step (Task 5 Step 1's branch-rename note) is explicitly marked optional.
- **Type consistency:**
  - `_build_contract(entity: ElementTree.Element, source_name: str, *, entity_set: str | None) -> LoadedContract` — signature defined in Task 1 Step 5, called in the same file in the same step. No external callers (verified by grep before plan: only `bootstrap_odata_contracts` calls `_build_contract`).
  - `_build_custom_properties(type_name: str, properties: list[OdcsProperty], *, entity_set: str | None) -> list[CustomProperty]` — already had the `entity_set: str | None` keyword param post-ADR-0024; signature unchanged in this plan.
  - `_build_entity_set_map(root: ElementTree.Element) -> dict[str, str]` — unchanged.
  - `bootstrap_odata_contracts(metadata_xml: str, *, source_name: str) -> list[LoadedContract]` — signature unchanged; only body changes.
  - `das.spec_ref` value shape: `{kind: odata, type: <str>}` (legacy / container-less) or `{kind: odata, type: <str>, entity_set: <str>}` (when container declares the EntitySet) — exact-dict assertions in Task 1 Steps 1 and 3 use the new shape; Task 1 Step 7 (diff tests, container-less) implicitly use the legacy shape via existing assertions.
- **TDD order:** Task 1 rewrites/adds tests (red), then implements (green). Tasks 2–3 are docs + a live e2e — no internal-API surface to TDD against.
- **Branch & worktree:** the brainstorming spec commit sits on `worktree-worktree-issue-63-brainstorm`; all implementation commits land on the same branch.
