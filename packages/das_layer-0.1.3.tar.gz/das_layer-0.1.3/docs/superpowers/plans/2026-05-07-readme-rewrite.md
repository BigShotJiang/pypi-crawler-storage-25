# README Rewrite Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the current 38-line `README.md` with a storefront-oriented rewrite that pitches the contract-driven angle, scopes the project to the DAS layer, and points contributors at the existing depth (ADRs, specs, plans, CLAUDE.md) without duplicating it.

**Architecture:** Single-file rewrite of `README.md`. No `CONTRIBUTING.md` (process stays in `CLAUDE.md`). All ADR cross-references are anchored to existing ADR files; external links are limited to the dlt docs, the ODCS spec, and the project's own GitHub URLs. Badges follow standard shields.io patterns against the published-or-soon-to-be-published `das-cli` PyPI package and the existing `ci.yml` workflow.

**Tech Stack:** Markdown (GitHub-Flavored), shields.io badges, ADR file references.

**Spec:** `docs/superpowers/specs/2026-05-07-readme-rewrite-design.md`

---

## File Structure

- **Modify:** `README.md` (full replacement; current content is the v0.1 stub)

No other files change. The spec already addressed the CONTRIBUTING.md decision (rejected) and flagged the ADR-index drift (issue #21, out of scope here).

---

### Task 1: Pre-flight verification

**Files:**
- Read: `README.md`
- Read: `docs/adrs/` (directory listing)
- Read: `.github/workflows/ci.yml`

This task confirms the inputs the new README depends on are still present and exactly as the spec assumed. Catching a renamed ADR or workflow file here prevents broken refs in the rewrite.

- [ ] **Step 1: Confirm current README state**

Run: `wc -l README.md && head -1 README.md`
Expected: ~38 lines, first line `# das-cli`.

- [ ] **Step 2: Confirm all referenced ADR files exist**

Run:
```bash
for n in 0002 0003 0004 0005 0006 0007 0008 0011 0012 0013 0014 0015; do
  ls docs/adrs/${n}-*.md 2>/dev/null || echo "MISSING: ADR-${n}"
done
```

Expected: 12 file paths printed, no `MISSING:` lines. The plan references ADR-0002, 0003, 0004, 0005, 0006, 0007, 0008, 0011, 0012, 0013, 0014, 0015.

If any ADR is missing, STOP and surface the gap to the user before proceeding — the rewrite anchors content to these ADRs and a missing one means either the spec is stale or an ADR was renamed.

- [ ] **Step 3: Confirm CI workflow filename**

Run: `ls .github/workflows/`
Expected: includes `ci.yml`.

If the file has been renamed, the CI badge URL in Task 2 must be updated to match before proceeding.

- [ ] **Step 4: Confirm package name and metadata**

Run: `grep -E '^(name|version|requires-python)' pyproject.toml`
Expected:
```
name = "das-cli"
version = "0.1.0"
requires-python = ">=3.12"
```

The PyPI badges and the Python-versions badge depend on `name = "das-cli"` and the `>=3.12` requirement. If either has changed, update the badge URLs in Task 2 accordingly.

---

### Task 2: Replace `README.md` with the new content

**Files:**
- Modify: `README.md` (full replacement)

This is a single Write of the entire new README. Doing it in one shot — rather than section-by-section Edit calls — is appropriate here because the existing file is a stub that's being wholly replaced and every section depends on the surrounding structure (heading levels, link references, badge layout).

- [ ] **Step 1: Write the new README**

Replace `README.md` with **exactly** this content:

````markdown
# das-cli

Contract-driven ingestion for the raw→staging boundary, built on [dlt](https://dlthub.com/).

[![PyPI version](https://img.shields.io/pypi/v/das-cli.svg)](https://pypi.org/project/das-cli/)
[![Python versions](https://img.shields.io/pypi/pyversions/das-cli.svg)](https://pypi.org/project/das-cli/)
[![CI](https://github.com/mattiasthalen/das-cli/actions/workflows/ci.yml/badge.svg)](https://github.com/mattiasthalen/das-cli/actions/workflows/ci.yml)
[![License](https://img.shields.io/github/license/mattiasthalen/das-cli.svg)](LICENSE)

## What it is

das-cli lands raw source data into a compressed JSONL landing zone, then
promotes it into a contract-enforced DuckDB warehouse. ODCS v3 contracts are
the single source of truth for schema, types, and keys — schemas are
*frozen and projected*, not inferred at load time.

It is scoped to the DAS layer: lossless landing and contract-projected
staging. It is *not* an ELT modeling tool. Transformations, business logic,
and downstream modeling belong in the layers above (dbt, SQLMesh, etc.).

## How it works

das-cli runs two pipelines per source:

1. **Bootstrap a contract** — point das-cli at an OData service or OpenAPI
   spec; it emits an editable ODCS v3 contract per resource, plus a
   `_source.yml` for connection details. (See ADR-0005, ADR-0006, ADR-0015.)

2. **P1 — land** — extract raw records into a compressed JSONL landing zone
   under `./landing/`, hive-partitioned by extract date. Each row is stored
   as a `_data: json` blob — lossless, no schema applied. (See ADR-0002,
   ADR-0003.)

3. **P2 — promote** — project the JSONL blobs into contract-enforced DuckDB
   staging tables. Schemas are frozen against the ODCS contract. Loads are
   append-only with row-hash change detection: each row's hash is compared
   against the latest hash per primary key in the destination, and only
   changed rows are appended. (See ADR-0004, ADR-0008, ADR-0012.)

## Quickstart

```bash
uv tool install das-cli

mkdir my-data && cd my-data
das init

das source add adventureworks \
  --type odata \
  --url https://demodata.grapecity.com/adventureworks/odata/v1

das contract bootstrap adventureworks
das ingest adventureworks
```

After `das ingest`:

- raw JSONL lands in `./landing/`, hive-partitioned by extract date
- contract-enforced staging tables live in `./das.duckdb`

## Concepts

- **Contract** — an [ODCS v3](https://bitol-io.github.io/open-data-contract-standard/)
  YAML file per resource. Defines schema, types, and primary keys. Edited by
  hand after `bootstrap`; frozen on ingest. (ADR-0005, ADR-0012.)
- **`_source.yml`** — per-source connection config (type, URL, auth). Kept
  separate from contracts so resource definitions stay portable. (ADR-0005.)
- **`das.*` custom properties** — the namespace for das-cli's extensions to
  ODCS, including `das.endpoint`, `das.hash_exclude`, and load-date hints.
  (ADR-0011, ADR-0014.)
- **Landing zone** — `./landing/<source>/<resource>/_extracted_on=YYYY-MM-DD/`,
  compressed JSONL, hive-partitioned. The lossless raw record. (ADR-0002,
  ADR-0013.)
- **P1 / P2 pipelines** — extract (source → landing) and load (landing →
  DuckDB). One P1 per source, one shared P2. (ADR-0002, ADR-0008.)
- **Secrets** — referenced in `_source.yml` via `{{ env_var("...") }}`. No
  `.dlt/secrets.toml`. (ADR-0007.)

## Sources & destinations

das-cli is built on [dlt](https://dlthub.com/), so in principle any dlt
[source](https://dlthub.com/docs/dlt-ecosystem/verified-sources) or
[destination](https://dlthub.com/docs/dlt-ecosystem/destinations) should
work. Only the combinations below are exercised by the test suite — that's
what "verified" means here.

### Verified

| Source         | Destination | Notes                                         |
|----------------|-------------|-----------------------------------------------|
| OData v2 / v4  | DuckDB      | OData metadata bootstrap (ADR-0006)           |
| OpenAPI / REST | DuckDB      | Per-resource `das.endpoint` (ADR-0014, 0015)  |

### Want a combination verified?

[Open an issue](https://github.com/mattiasthalen/das-cli/issues/new)
describing the source and destination you'd like to use. Verified means
there's an end-to-end test against a real instance — happy to add more as
people land on them.

## Development

```bash
uv sync
uv run pytest                       # unit + integration
uv run pytest -m e2e                # opt-in; hits public AdventureWorks/Northwind APIs
uv run pre-commit run --all-files
```

For architectural context (decision records, design specs, implementation
plans), see the **Documentation** section below and `CLAUDE.md`.

## Documentation

- [`docs/adrs/`](docs/adrs/) — Architecture Decision Records: *why is it
  built this way?*
- [`docs/superpowers/specs/`](docs/superpowers/specs/) — design specs:
  *what's planned / shipped?*
- [`docs/superpowers/plans/`](docs/superpowers/plans/) — implementation
  plans: *how is it being built?*
- [`CLAUDE.md`](CLAUDE.md) — project rules and ADR lifecycle policy.

## License

See [`LICENSE`](LICENSE).
````

- [ ] **Step 2: Verify the file replaced cleanly**

Run: `wc -l README.md && head -3 README.md`
Expected: ~120–140 lines (the new README); first three lines:
```
# das-cli

Contract-driven ingestion for the raw→staging boundary, built on [dlt](https://dlthub.com/).
```

If the line count is well outside that range, the Write either appended instead of replaced, or the content was truncated — re-do the Write before continuing.

---

### Task 3: Verify all internal links resolve

**Files:**
- Read: `README.md` (the just-written file)

The new README references files and directories inside the repo. Each must resolve, or readers (and GitHub's link checker) will see broken links.

- [ ] **Step 1: Verify the four explicit relative-path links exist**

Run:
```bash
for path in docs/adrs/ docs/superpowers/specs/ docs/superpowers/plans/ CLAUDE.md LICENSE; do
  test -e "$path" && echo "OK: $path" || echo "MISSING: $path"
done
```

Expected: five `OK:` lines. If any `MISSING:` appears, the corresponding link in `README.md` must be removed or corrected before commit.

- [ ] **Step 2: Verify ADR numeric references are present in `docs/adrs/`**

Run:
```bash
for n in 0002 0003 0004 0005 0006 0007 0008 0011 0012 0013 0014 0015; do
  ls docs/adrs/${n}-*.md >/dev/null 2>&1 || echo "MISSING: ADR-${n}"
done
```

Expected: no output (silent success means all 12 ADRs exist). Same set as Task 1, repeated here as a defense against an ADR being renamed between Task 1 and Task 3 in a long execution session.

- [ ] **Step 3: Spot-check for stale references**

Run: `grep -nE 'ADR-[0-9]+' README.md`

Read each match and confirm it appears in the set `{0002, 0003, 0004, 0005, 0006, 0007, 0008, 0011, 0012, 0013, 0014, 0015}`. Any reference outside this set is a typo introduced during the Write — fix in `README.md` before continuing.

---

### Task 4: Spec coverage check

**Files:**
- Read: `docs/superpowers/specs/2026-05-07-readme-rewrite-design.md`
- Read: `README.md`

Walk the spec's "Design" section and confirm every committed decision shows up in the rewritten README.

- [ ] **Step 1: Section presence**

Run: `grep -nE '^##? ' README.md`
Expected output (in this order):
```
# das-cli
## What it is
## How it works
## Quickstart
## Concepts
## Sources & destinations
### Verified
### Want a combination verified?
## Development
## Documentation
## License
```

If any heading is missing, reordered, or extra, fix `README.md` before continuing.

- [ ] **Step 2: Badges present and ordered correctly**

Run: `grep -nE '!\[' README.md`
Expected: four lines, in this order — PyPI version, Python versions, CI, License. Any deviation must be corrected.

- [ ] **Step 3: Verified table contents**

Run: `awk '/^### Verified/,/^### Want/' README.md`
Expected: includes a markdown table with two data rows — `OData v2 / v4 | DuckDB | …` and `OpenAPI / REST | DuckDB | …`. If the table is malformed (broken pipes, missing header separator), GitHub will not render it — fix before commit.

- [ ] **Step 4: Quickstart outcome bullets**

Run: `grep -nE '(hive-partitioned by extract date|contract-enforced staging tables live)' README.md`
Expected: two matches in the Quickstart section.

---

### Task 5: Commit

**Files:**
- `README.md`

- [ ] **Step 1: Stage and commit**

Run:
```bash
git add README.md
git commit -m "$(cat <<'EOF'
docs(readme): rewrite as contract-driven storefront

Replaces the 38-line v0.1 stub with a storefront-oriented README:
contract-driven positioning, P1/P2 mental model anchored to ADRs,
verified-sources table with dlt-surface pointer and issue CTA, dev
commands, and pointers to CLAUDE.md / ADRs / specs / plans.

Implements docs/superpowers/specs/2026-05-07-readme-rewrite-design.md.
EOF
)"
```

Expected: a single commit on the current branch with one file changed and the new README content. The commit message references the spec by path so the trail from spec to implementation is recoverable.

- [ ] **Step 2: Push the commit**

Run: `git push -u origin claude/readme-contributions-EDecF`

Expected: push succeeds. (The branch is already tracking the remote from the spec commit; `-u` is harmless on re-push.)

If the push fails for transient network reasons, retry up to 4 times with 2s/4s/8s/16s backoff. Do not retry on non-network failures (e.g., non-fast-forward) — investigate instead.

---

## Self-review notes

- **Spec coverage:** every Design section in the spec maps to text in Task 2: tagline (line under title), badges (4 lines under tagline), what-it-is (`## What it is`), how-it-works (`## How it works`, 3 numbered items with the precise ADR refs and corrected language about row-hash detection living in P2), quickstart (line-broken `das source add` and the two outcome bullets), concepts (six bullets in spec order with the ODCS public-spec link in bullet 1), sources-and-destinations (framing paragraph + verified table + CTA pointing at the no-label issues URL), development (4 commands plus pointer line), documentation (4 bullets in the spec's Q-ordering), license. Goals and Non-goals are honored: no CONTRIBUTING.md is created, no comparison table appears, ADR numbers are inline.
- **Placeholder scan:** none. Every step contains the exact command, the exact content, or the exact expected output it depends on.
- **Type / name consistency:** ADR numbers used in the README are the same set verified in Task 1, Task 3, and Task 4. The CI badge URL matches the workflow filename verified in Task 1. The PyPI package name `das-cli` matches the `pyproject.toml` value verified in Task 1. The branch name in Task 5 matches the branch named in the system prompt and the existing remote.
