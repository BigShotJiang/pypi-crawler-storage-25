# Harden e2e suite: edge structure + content assertions — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Restructure `tests/e2e/` into edge suites (`sources/` × DuckDB, `destinations/` × OData) and tighten assertions to verify business-column content and row-count-vs-limit, then update the README to reflect the new "verified" semantics.

**Architecture:** Two-pronged refactor of the e2e tier. (1) Move existing per-(source,destination) files into edge folders so adding a new source costs O(1) and adding a new destination costs O(1). The fixed source for destination edges is OData/AdventureWorks; the fixed destination for source edges is DuckDB. (2) Add two assertions to every test: a non-null business column from the source spec (e.g. `products.name`, `customer_dtos.customer_id`, `customers.name`), and a row count that is `>= 1 AND <= --limit` so a silently empty page can't be a passing run.

**Tech Stack:** pytest, typer.testing.CliRunner, duckdb, dlt (for DuckLake/Delta reader pipelines).

Closes #44 and #35; both are bundled by #48.

---

## File Structure

```
tests/e2e/
  conftest.py                                  # unchanged (auto-marks any tests/e2e/ file with @pytest.mark.e2e)
  fixtures/                                    # unchanged
  sources/                                     # NEW — real sources × DuckDB
    __init__.py                                # NEW (empty)
    test_odata_adventureworks.py               # moved+renamed from test_adventureworks.py
    test_openapi_northwind.py                  # moved+renamed from test_northwind.py
    test_oracle.py                             # moved from tests/e2e/test_oracle.py
    test_sqlserver.py                          # moved from tests/e2e/test_sqlserver.py
  destinations/                                # NEW — OData/AdventureWorks × real destinations
    __init__.py                                # NEW (empty)
    test_ducklake.py                           # moved+renamed from test_adventureworks_ducklake.py
    test_delta.py                              # moved+renamed from test_adventureworks_delta.py
```

Deleted (covered by the new edge suites):
- `tests/e2e/test_northwind_ducklake.py` — Northwind/OpenAPI is covered by source-edge against DuckDB; DuckLake is covered by destination-edge against OData.
- `tests/e2e/test_northwind_delta.py` — same reasoning.
- The bare `tests/e2e/test_*.py` files at the top level cease to exist after Task 1/2; only `conftest.py` remains directly under `tests/e2e/`.

The conftest's path filter (`"tests/e2e/" in str(item.fspath)`) matches subdirectories, so the `@pytest.mark.e2e` auto-marker keeps working.

---

## Task 1: Move source-edge tests into `tests/e2e/sources/`

**Files:**
- Create: `tests/e2e/sources/__init__.py` (empty)
- Move (rename): `tests/e2e/test_adventureworks.py` → `tests/e2e/sources/test_odata_adventureworks.py`
- Move (rename): `tests/e2e/test_northwind.py` → `tests/e2e/sources/test_openapi_northwind.py`
- Move: `tests/e2e/test_oracle.py` → `tests/e2e/sources/test_oracle.py`
- Move: `tests/e2e/test_sqlserver.py` → `tests/e2e/sources/test_sqlserver.py`

- [ ] **Step 1: Create the directory and `__init__.py`**

```bash
mkdir -p tests/e2e/sources
touch tests/e2e/sources/__init__.py
```

- [ ] **Step 2: `git mv` the four source files**

```bash
git mv tests/e2e/test_adventureworks.py tests/e2e/sources/test_odata_adventureworks.py
git mv tests/e2e/test_northwind.py     tests/e2e/sources/test_openapi_northwind.py
git mv tests/e2e/test_oracle.py        tests/e2e/sources/test_oracle.py
git mv tests/e2e/test_sqlserver.py     tests/e2e/sources/test_sqlserver.py
```

- [ ] **Step 3: Verify the test bodies still import correctly**

Run: `uv run python -m py_compile tests/e2e/sources/*.py`
Expected: silent (no SyntaxError, no ImportError at parse time).

- [ ] **Step 4: Confirm pytest collects them and applies the e2e marker**

Run: `uv run pytest tests/e2e/sources/ --collect-only -q`
Expected: each test prefixed with `tests/e2e/sources/...` and listed (collection respects `addopts = "-m 'not e2e'"`, so the count may show 0 selected after deselection — that's fine; we only care that the discovered tests appear in the deselected count, not that they run).

- [ ] **Step 5: Commit**

```bash
git add tests/e2e/sources/
git commit -m "test: relocate source-edge e2e tests under tests/e2e/sources/ (#44)"
```

---

## Task 2: Move destination-edge tests into `tests/e2e/destinations/`

**Files:**
- Create: `tests/e2e/destinations/__init__.py` (empty)
- Move (rename): `tests/e2e/test_adventureworks_ducklake.py` → `tests/e2e/destinations/test_ducklake.py`
- Move (rename): `tests/e2e/test_adventureworks_delta.py` → `tests/e2e/destinations/test_delta.py`
- Delete: `tests/e2e/test_northwind_ducklake.py`
- Delete: `tests/e2e/test_northwind_delta.py`
- Modify: `tests/e2e/destinations/test_ducklake.py` — rename test function to `test_ducklake_bootstrap_extract_load`
- Modify: `tests/e2e/destinations/test_delta.py` — rename test function to `test_delta_bootstrap_extract_load`

- [ ] **Step 1: Create the directory and `__init__.py`**

```bash
mkdir -p tests/e2e/destinations
touch tests/e2e/destinations/__init__.py
```

- [ ] **Step 2: `git mv` the kept destination tests, delete the redundant Northwind variants**

```bash
git mv tests/e2e/test_adventureworks_ducklake.py tests/e2e/destinations/test_ducklake.py
git mv tests/e2e/test_adventureworks_delta.py    tests/e2e/destinations/test_delta.py
git rm tests/e2e/test_northwind_ducklake.py
git rm tests/e2e/test_northwind_delta.py
```

- [ ] **Step 3: Rename the test function in `test_ducklake.py`**

In `tests/e2e/destinations/test_ducklake.py`, change the function name from
`test_adventureworks_ducklake_bootstrap_extract_load` to
`test_ducklake_bootstrap_extract_load`. The function body is unchanged in this
task — only the name. The fixed source is still AdventureWorks/OData; the
filename now scopes the file to the destination, not the source.

- [ ] **Step 4: Rename the test function in `test_delta.py`**

In `tests/e2e/destinations/test_delta.py`, change the function name from
`test_adventureworks_delta_bootstrap_extract_load` to
`test_delta_bootstrap_extract_load`.

- [ ] **Step 5: Verify the surviving tests still parse**

Run: `uv run python -m py_compile tests/e2e/destinations/*.py`
Expected: silent.

- [ ] **Step 6: Commit**

```bash
git add tests/e2e/destinations/
git add -u tests/e2e/  # stages the deletions of the moved-from + removed files
git commit -m "test: collapse destination e2e suite to OData edge (#44)"
```

---

## Task 3: Strengthen `test_odata_adventureworks.py` (source edge × DuckDB)

**Files:**
- Modify: `tests/e2e/sources/test_odata_adventureworks.py` — add business-column non-null assertion + row-count-vs-limit assertion.

The existing test calls `extract --limit 10` and asserts `count >= 1`. Tighten
to `1 <= count <= 10` and require at least one non-null `name`.

- [ ] **Step 1: Replace the count assertion with a stricter one**

Replace this block (currently roughly at lines 57–63):

```python
    db = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        row = db.execute('SELECT COUNT(*) FROM "das__adventureworks".products').fetchone()
        count = row[0] if row is not None else 0
    finally:
        db.close()
    assert count >= 1, "expected at least one product row"
```

with:

```python
    db = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        row = db.execute('SELECT COUNT(*) FROM "das__adventureworks".products').fetchone()
        count = row[0] if row is not None else 0
        named_row = db.execute(
            'SELECT COUNT(*) FROM "das__adventureworks".products WHERE name IS NOT NULL'
        ).fetchone()
        named = named_row[0] if named_row is not None else 0
    finally:
        db.close()
    # extract --limit 10 above; the staged count must respect it and not be a
    # silently-empty page. Assert business content (`name`) is populated for
    # at least one row — proves the OData spec → contract → projection chain
    # actually carries source columns through, not just the metadata columns.
    assert 1 <= count <= 10, f"row count {count} outside (0, --limit=10]"
    assert named >= 1, "expected at least one product with a non-null name"
```

The metadata-NOT-NULL block below it stays as-is.

- [ ] **Step 2: Sanity-check the syntax**

Run: `uv run python -m py_compile tests/e2e/sources/test_odata_adventureworks.py`
Expected: silent.

- [ ] **Step 3: Commit**

```bash
git add tests/e2e/sources/test_odata_adventureworks.py
git commit -m "test: assert content + row-count-vs-limit for OData source edge (#35)"
```

---

## Task 4: Strengthen `test_openapi_northwind.py` (source edge × DuckDB)

**Files:**
- Modify: `tests/e2e/sources/test_openapi_northwind.py`

The Northwind extract uses `--limit 5`. The business column called out in #35
is `customer_id`.

- [ ] **Step 1: Replace the count assertion**

Replace the block that currently reads:

```python
    db = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        row = db.execute('SELECT COUNT(*) FROM "das__northwind".customer_dtos').fetchone()
        count = row[0] if row is not None else 0
    finally:
        db.close()
    assert count >= 1
```

with:

```python
    db = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        row = db.execute('SELECT COUNT(*) FROM "das__northwind".customer_dtos').fetchone()
        count = row[0] if row is not None else 0
        keyed_row = db.execute(
            'SELECT COUNT(*) FROM "das__northwind".customer_dtos '
            "WHERE customer_id IS NOT NULL"
        ).fetchone()
        keyed = keyed_row[0] if keyed_row is not None else 0
    finally:
        db.close()
    # extract --limit 5 above; staged count must respect that bound and not
    # silently be 0 from an empty page. customer_id is the OpenAPI business
    # key — assert it survives the bootstrap → extract → load chain.
    assert 1 <= count <= 5, f"row count {count} outside (0, --limit=5]"
    assert keyed >= 1, "expected at least one customer_dto with a non-null customer_id"
```

- [ ] **Step 2: Syntax check**

Run: `uv run python -m py_compile tests/e2e/sources/test_openapi_northwind.py`
Expected: silent.

- [ ] **Step 3: Commit**

```bash
git add tests/e2e/sources/test_openapi_northwind.py
git commit -m "test: assert content + row-count-vs-limit for OpenAPI source edge (#35)"
```

---

## Task 5: Strengthen `test_ducklake.py` (destination edge × OData)

**Files:**
- Modify: `tests/e2e/destinations/test_ducklake.py`

Same pattern as Task 3, against the DuckLake reader pipeline. Uses
`extract --limit 10`.

- [ ] **Step 1: Replace the count + name block**

Replace the block that currently reads (inside `with pipeline.sql_client() as c:`):

```python
        rows = c.execute_sql('SELECT COUNT(*) FROM "das__adventureworks".products')
        assert rows is not None
        count = rows[0][0]
        assert count >= 1, "expected at least one product row"
```

with:

```python
        rows = c.execute_sql('SELECT COUNT(*) FROM "das__adventureworks".products')
        assert rows is not None
        count = rows[0][0]
        named_rows = c.execute_sql(
            'SELECT COUNT(*) FROM "das__adventureworks".products WHERE name IS NOT NULL'
        )
        assert named_rows is not None
        named = named_rows[0][0]
        # extract --limit 10 above; assert the count respects the limit and
        # business columns survived the OData → landing → DuckLake projection.
        assert 1 <= count <= 10, f"row count {count} outside (0, --limit=10]"
        assert named >= 1, "expected at least one product with a non-null name"
```

- [ ] **Step 2: Syntax check**

Run: `uv run python -m py_compile tests/e2e/destinations/test_ducklake.py`
Expected: silent.

- [ ] **Step 3: Commit**

```bash
git add tests/e2e/destinations/test_ducklake.py
git commit -m "test: assert content + row-count-vs-limit for DuckLake destination edge (#35)"
```

---

## Task 6: Strengthen `test_delta.py` (destination edge × OData)

**Files:**
- Modify: `tests/e2e/destinations/test_delta.py`

Identical change to Task 5 but against `delta_reader_pipeline`.

- [ ] **Step 1: Replace the count block**

Replace the block that currently reads (inside `with pipeline.sql_client() as c:`):

```python
        rows = c.execute_sql('SELECT COUNT(*) FROM "das__adventureworks".products')
        assert rows is not None
        count = rows[0][0]
        assert count >= 1, "expected at least one product row"
```

with:

```python
        rows = c.execute_sql('SELECT COUNT(*) FROM "das__adventureworks".products')
        assert rows is not None
        count = rows[0][0]
        named_rows = c.execute_sql(
            'SELECT COUNT(*) FROM "das__adventureworks".products WHERE name IS NOT NULL'
        )
        assert named_rows is not None
        named = named_rows[0][0]
        # extract --limit 10 above; assert the count respects the limit and
        # business columns survived the OData → landing → Delta projection.
        assert 1 <= count <= 10, f"row count {count} outside (0, --limit=10]"
        assert named >= 1, "expected at least one product with a non-null name"
```

- [ ] **Step 2: Syntax check**

Run: `uv run python -m py_compile tests/e2e/destinations/test_delta.py`
Expected: silent.

- [ ] **Step 3: Commit**

```bash
git add tests/e2e/destinations/test_delta.py
git commit -m "test: assert content + row-count-vs-limit for Delta destination edge (#35)"
```

---

## Task 7: Strengthen Oracle source-edge test

**Files:**
- Modify: `tests/e2e/sources/test_oracle.py`

The Oracle test already asserts exact row counts (`== 3`, `== 3`) and decodes
`payload`. The remaining gap from #35 is asserting that the business column
(`customers.name`) is non-null for every row — the existing tests verify the
container's seed loaded but not that string columns survived the
SQLAlchemy → JSON → frozen-contract round-trip without being silently nulled.

Note: there is no `--limit` on this test (the SQL extract pulls the full
seed), so the limit-bound assertion does not apply. The existing exact-count
assertion is strictly stronger than `>= 1`.

- [ ] **Step 1: Add a `name IS NOT NULL` assertion to `test_oracle_bootstrap_extract_load`**

After the existing `att = db.execute(...)` / `assert base64.b64decode(att[0]) == b"hello"` block, before the `finally:` that closes the connection, add:

```python
        named = db.execute(
            'SELECT COUNT(*) FROM "das__demo".customers WHERE name IS NOT NULL'
        ).fetchone()
        # The seed inserts three customers, all with non-null names. Assert
        # the business column survived the SQLAlchemy reflection → JSON blob
        # → contract projection chain.
        assert named is not None and named[0] == 3, named
```

- [ ] **Step 2: Syntax check**

Run: `uv run python -m py_compile tests/e2e/sources/test_oracle.py`
Expected: silent.

- [ ] **Step 3: Commit**

```bash
git add tests/e2e/sources/test_oracle.py
git commit -m "test: assert non-null business content for Oracle source edge (#35)"
```

---

## Task 8: Strengthen SQL Server source-edge test

**Files:**
- Modify: `tests/e2e/sources/test_sqlserver.py`

Mirror of Task 7.

- [ ] **Step 1: Add the `name IS NOT NULL` assertion**

After the existing `att = db.execute(...)` / `assert base64.b64decode(att[0]) == b"hello"` block, before the `finally:` that closes the connection, add:

```python
        named = db.execute(
            'SELECT COUNT(*) FROM "das__demo".customers WHERE name IS NOT NULL'
        ).fetchone()
        # Seed inserts three customers with non-null names; verifies the
        # NVARCHAR → JSON → frozen-contract round-trip preserved them.
        assert named is not None and named[0] == 3, named
```

- [ ] **Step 2: Syntax check**

Run: `uv run python -m py_compile tests/e2e/sources/test_sqlserver.py`
Expected: silent.

- [ ] **Step 3: Commit**

```bash
git add tests/e2e/sources/test_sqlserver.py
git commit -m "test: assert non-null business content for SQL Server source edge (#35)"
```

---

## Task 9: Update README "Verified" section to reflect edge semantics

**Files:**
- Modify: `README.md` (the "Sources & destinations" → "Verified" section, around lines 100–125)

Today's matrix presents one row per (source, destination) pair, implying every
cell is exercised. Per #48's DoD, restate it as two columns — one for sources
edge-tested against DuckDB, one for destinations edge-tested against
OData/AdventureWorks — and tighten the "verified means" line to match.

- [ ] **Step 1: Replace the Verified section**

Replace the block that currently reads:

```markdown
das-cli is built on [dlt](https://dlthub.com/), so in principle any dlt
[source](https://dlthub.com/docs/dlt-ecosystem/verified-sources) or
[destination](https://dlthub.com/docs/dlt-ecosystem/destinations) should
work. Only the combinations below are exercised by the test suite — that's
what "verified" means here.

### Verified

| Source              | Destination | Notes                                                  |
|---------------------|-------------|--------------------------------------------------------|
| OData v2 / v4       | DuckDB      | OData metadata bootstrap (ADR-0006)                    |
| OpenAPI / REST      | DuckDB      | Per-resource `das.endpoint` (ADR-0014, 0015)           |
| OData v2 / v4       | DuckLake    | Local DuckDB-file catalog (ADR-0016)                   |
| OpenAPI / REST      | DuckLake    | Local DuckDB-file catalog (ADR-0016)                   |
| OData v2 / v4       | Delta       | Local Delta tables on filesystem (ADR-0017)            |
| OpenAPI / REST      | Delta       | Local Delta tables on filesystem (ADR-0017)            |
| Oracle (oracledb)   | DuckDB      | SQLAlchemy reflection (ADR-0018); Oracle Free          |
| SQL Server (pyodbc) | DuckDB      | SQLAlchemy reflection (ADR-0018); ODBC Driver 18       |

### Want a combination verified?

[Open an issue](https://github.com/mattiasthalen/das-cli/issues/new)
describing the source and destination you'd like to use. Verified means
there's an end-to-end test against a real instance — happy to add more as
people land on them.
```

with:

```markdown
das-cli is built on [dlt](https://dlthub.com/), so in principle any dlt
[source](https://dlthub.com/docs/dlt-ecosystem/verified-sources) or
[destination](https://dlthub.com/docs/dlt-ecosystem/destinations) should
work. The e2e suite verifies *edges*, not the full matrix: each source is
exercised against DuckDB, and each destination is exercised against
AdventureWorks (OData). A row below means the corresponding edge has an
end-to-end test against a real instance.

### Verified sources (against DuckDB)

| Source              | Notes                                                  |
|---------------------|--------------------------------------------------------|
| OData v2 / v4       | OData metadata bootstrap (ADR-0006)                    |
| OpenAPI / REST      | Per-resource `das.endpoint` (ADR-0014, 0015)           |
| Oracle (oracledb)   | SQLAlchemy reflection (ADR-0018); Oracle Free          |
| SQL Server (pyodbc) | SQLAlchemy reflection (ADR-0018); ODBC Driver 18       |

### Verified destinations (against OData / AdventureWorks)

| Destination | Notes                                                  |
|-------------|--------------------------------------------------------|
| DuckDB      | Default; in-process, no container                      |
| DuckLake    | Local DuckDB-file catalog (ADR-0016)                   |
| Delta       | Local Delta tables on filesystem (ADR-0017)            |

### Want a combination verified?

[Open an issue](https://github.com/mattiasthalen/das-cli/issues/new)
describing the source or destination you'd like to use. "Verified" means
there's an end-to-end edge test against a real instance — source verified
against DuckDB, or destination verified against OData. We don't fan out the
full N×M matrix; if you need a specific (source, destination) pair
exercised, file an issue and we'll discuss whether it warrants its own test.
```

- [ ] **Step 2: Verify the markdown renders**

Run: `git diff README.md`
Expected: only the "Verified" section changed; the surrounding sections are intact.

- [ ] **Step 3: Commit**

```bash
git add README.md
git commit -m "docs: tighten README verified semantics to edge testing (#48)"
```

---

## Task 10: Run the non-e2e suite locally as a regression guard

The e2e tests require Docker (Oracle, SQL Server) and network access
(AdventureWorks, Northwind), so we cannot run them in CI-detached
environments. Confirm at least the unit + integration tiers still pass.

- [ ] **Step 1: Run unit + integration**

Run: `uv run pytest tests/unit tests/integration -q`
Expected: PASS. (Test files moved here are e2e only; the non-e2e tiers are
unaffected and should be green at HEAD.)

- [ ] **Step 2: Confirm the e2e suite still collects without errors**

Run: `uv run pytest tests/e2e --collect-only -q`
Expected: each surviving test under `tests/e2e/sources/` and
`tests/e2e/destinations/` is listed in the deselected count (default
`addopts = "-m 'not e2e'"` means no test runs, but they all still collect).
Six test functions across six files (four source-edge + two destination-edge),
plus `test_oracle_second_extract_uses_cursor` — so seven items total.

---

## Task 11: Push to the working branch

- [ ] **Step 1: Push**

Run:

```bash
git push -u origin claude/fix-issue-48-HshDQ
```

Retry on transient network errors per the harness's exponential-backoff policy.

---

## ADR check

This change does not introduce a new architectural decision — it tightens
existing test conventions and updates a README claim. ADR-0010 already
covers "tests live in the CLI repo," and that is unchanged. No new ADR is
filed; no existing ADR is superseded.

---

## Definition of done (mirroring #48)

- `tests/e2e/sources/` contains the four source-edge tests, each targeting DuckDB.
- `tests/e2e/destinations/` contains the two destination-edge tests, each targeting OData/AdventureWorks.
- `tests/e2e/test_northwind_*.py` no longer exist.
- Every e2e test, after the load step, asserts (a) at least one expected business column is non-null and (b) row count is consistent with the `--limit` passed to extract (where applicable; the SQL tests instead retain their exact-count seed assertions).
- README "Verified" section presents two edge tables (sources × DuckDB, destinations × OData) and the prose explains the new semantics.
- `uv run pytest tests/unit tests/integration` is green.
- `uv run pytest tests/e2e --collect-only` lists the moved files in the deselected count (e2e itself is opt-in and not run here).
