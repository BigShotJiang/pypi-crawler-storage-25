# SQL source defects (issue #47) — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fix the two SQL-source defects in issue #47 by splitting `--full` semantics (P1 cursor reset vs P2 table replace) and round-tripping `decimal(p,s)` columns losslessly through P2 projection.

**Architecture:**
- `das extract --full` resets the dlt incremental cursor state only — wipes `.dlt/pipelines/das_extract__<source>/` locally **and** the `_dlt_pipeline_state/`, `_dlt_loads/`, `_dlt_version/` dirs under `landing/<source>/`. Table data dirs stay intact (landing is append-only).
- `das load --full` adds a flag that flips `write_disposition` to `"replace"` and bypasses the change-detection filter, causing dlt to truncate and rebuild the destination table from all landing files.
- `das ingest` exposes both as `--extract-full` and `--load-full` (no composite `--full`).
- `decimal(p,s)` values arrive at P2 as strings (dlt's JSON encoder quotes `Decimal` since JSON has no native decimal type); a small `coerce_decimal` step in `_project_record` parses them back into `Decimal` for columns whose contract has `logicalType=number` + `physicalType=decimal(p,s)`.

**Tech Stack:** Python 3.x, dlt, SQLAlchemy, typer, pytest, duckdb. Project uses `uv` for dependency management.

**Spec:** [docs/superpowers/specs/2026-05-11-sql-source-defects-design.md](../specs/2026-05-11-sql-source-defects-design.md)

---

## File Structure

**Source files (modify):**
- `src/das_cli/dlt_glue/schema_factory.py` — add `coerce_decimal` and `is_decimal_column` helpers next to existing `_DECIMAL_RE`; export both.
- `src/das_cli/pipelines/extract.py` — add `reset_extract_state(source_name, config_path)` helper.
- `src/das_cli/pipelines/load.py` — thread `full: bool` through `run_load` and `_build_load_resource`; switch `write_disposition` and skip change detection; call `coerce_decimal` in `_project_record`.
- `src/das_cli/cli.py` — `extract` calls `reset_extract_state` instead of inlining `shutil.rmtree`; `load` gains `--full`; `ingest` swaps `--full` for `--extract-full` / `--load-full`.

**ADRs:**
- `docs/adrs/0018-sql-source-via-sqlalchemy.md` — append bullet to Consequences.
- `docs/adrs/0019-full-flag-semantics.md` — new file; document the split.
- `docs/adrs/README.md` — add row for ADR-0019.

**Fixtures:**
- `tests/e2e/fixtures/sql_seed_oracle.sql` — restore `amount` to `NUMBER(12,2)`.
- `tests/e2e/fixtures/sql_seed_sqlserver.sql` — restore `amount` to `DECIMAL(12,2)`.

**Tests:**
- `tests/unit/test_schema_factory.py` (new or co-located) — coverage for `coerce_decimal` and `is_decimal_column`.
- `tests/integration/test_extract_pipeline_sql.py` — rename + tighten existing `--full` test; add `decimal` round-trip test.
- `tests/integration/test_load_pipeline.py` — add `load --full` table-replace test.
- `tests/integration/test_cli_ingest.py` — add test for `ingest --extract-full --load-full` flag wiring.

---

## Task 1: Add `coerce_decimal` + `is_decimal_column` helpers

**Files:**
- Modify: `src/das_cli/dlt_glue/schema_factory.py`
- Create: `tests/unit/test_schema_factory.py`

- [ ] **Step 1: Write the failing unit tests**

Create `tests/unit/test_schema_factory.py`:

```python
"""Unit tests for schema_factory helpers."""

from __future__ import annotations

from decimal import Decimal

import pytest

from das_cli.contracts.odcs import OdcsProperty
from das_cli.dlt_glue.schema_factory import coerce_decimal, is_decimal_column


def _prop(**kw: object) -> OdcsProperty:
    base = {
        "name": "amount",
        "logicalType": "number",
        "physicalType": "decimal(12,2)",
        "required": False,
        "primaryKey": False,
    }
    base.update(kw)
    return OdcsProperty.model_validate(base)


def test_coerce_decimal_passes_through_none() -> None:
    assert coerce_decimal(None) is None


def test_coerce_decimal_returns_existing_decimal_unchanged() -> None:
    d = Decimal("1234.56")
    assert coerce_decimal(d) is d


def test_coerce_decimal_parses_string() -> None:
    assert coerce_decimal("1234.56") == Decimal("1234.56")


def test_coerce_decimal_parses_int() -> None:
    assert coerce_decimal(42) == Decimal("42")


def test_coerce_decimal_parses_float_via_str_avoiding_binary_artefacts() -> None:
    # str(0.1) == "0.1" — Decimal(0.1) would yield 0.10000000000000000555...
    assert coerce_decimal(0.1) == Decimal("0.1")


def test_is_decimal_column_true_for_number_logical_with_decimal_physical() -> None:
    assert is_decimal_column(_prop()) is True


def test_is_decimal_column_false_for_other_logical_types() -> None:
    assert is_decimal_column(_prop(logicalType="string", physicalType="varchar(10)")) is False


def test_is_decimal_column_false_for_double_physical() -> None:
    assert is_decimal_column(_prop(physicalType="double")) is False


def test_is_decimal_column_false_when_physical_type_missing() -> None:
    assert is_decimal_column(_prop(physicalType=None)) is False
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/unit/test_schema_factory.py -v`
Expected: FAIL with `ImportError: cannot import name 'coerce_decimal' from 'das_cli.dlt_glue.schema_factory'`.

- [ ] **Step 3: Add the helpers to `schema_factory.py`**

In `src/das_cli/dlt_glue/schema_factory.py`, change the imports at the top:

```python
"""Map ODCS contracts to dlt column hints. See ADR-0012, spec §5.4."""

from __future__ import annotations

import re
from decimal import Decimal
from typing import Any

from das_cli.contracts.odcs import LogicalType, OdcsContract, OdcsProperty
```

Then, after the existing `_DECIMAL_RE = re.compile(...)` line and before `_column_hint`, add:

```python
def is_decimal_column(prop: OdcsProperty) -> bool:
    """Return True if `prop` is a fixed-precision decimal column.

    A column qualifies when its ODCS `logicalType` is `number` AND its
    `physicalType` matches `decimal(p,s)`. See ADR-0018 (Consequences).
    """
    if prop.logicalType != "number":
        return False
    pt = prop.physicalType
    if pt is None:
        return False
    return _DECIMAL_RE.match(pt) is not None


def coerce_decimal(value: object) -> Decimal | None:
    """Coerce a value into `Decimal`, preserving `None`.

    Accepts `str | int | float | Decimal | None`. Uses `str(value)` for the
    `float` case to avoid binary-precision artefacts (e.g. `Decimal(0.1)` yields
    `0.10000000000000000555...`). See ADR-0018 (Consequences).
    """
    if value is None:
        return None
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))
```

- [ ] **Step 4: Run unit tests to verify they pass**

Run: `uv run pytest tests/unit/test_schema_factory.py -v`
Expected: 8 passed.

- [ ] **Step 5: Commit**

```bash
git add src/das_cli/dlt_glue/schema_factory.py tests/unit/test_schema_factory.py
git commit -m "feat(dlt_glue): add coerce_decimal + is_decimal_column helpers"
```

---

## Task 2: Apply `coerce_decimal` in P2 projection

**Files:**
- Modify: `src/das_cli/pipelines/load.py` (function `_project_record` around line 81)
- Test: `tests/integration/test_extract_pipeline_sql.py` (new test)

- [ ] **Step 1: Write the failing integration test**

Append to `tests/integration/test_extract_pipeline_sql.py`:

```python
def test_sql_extract_decimal_with_scale_round_trips(
    workspace: Path, cli_runner: CliRunner
) -> None:
    """A `Numeric(12, 2)` SQL column round-trips losslessly through P1 → P2."""
    from decimal import Decimal

    import duckdb
    from sqlalchemy import Numeric

    db = workspace / "demo.sqlite"
    engine = create_engine(f"sqlite:///{db}")
    md = MetaData()
    orders = Table(
        "orders",
        md,
        Column("order_id", Integer, primary_key=True),
        Column("amount", Numeric(12, 2), nullable=False),
        Column("updated_at", DateTime, nullable=False),
    )
    md.create_all(engine)
    with engine.begin() as conn:
        conn.execute(
            insert(orders),
            [
                {
                    "order_id": 1,
                    "amount": Decimal("1234.56"),
                    "updated_at": datetime(2026, 5, 1, tzinfo=UTC),
                },
                {
                    "order_id": 2,
                    "amount": Decimal("0.01"),
                    "updated_at": datetime(2026, 5, 2, tzinfo=UTC),
                },
                {
                    "order_id": 3,
                    "amount": Decimal("99999999.99"),
                    "updated_at": datetime(2026, 5, 3, tzinfo=UTC),
                },
            ],
        )
    engine.dispose()

    cli_runner.invoke(app, ["init"])
    src_dir = workspace / "contracts" / "demo"
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(
        f"type: sql\nendpoint: sqlite:///{db}\nspec:\n  kind: sql\nauth:\n  type: none\n"
    )

    boot = cli_runner.invoke(app, ["contract", "bootstrap", "demo"])
    assert boot.exit_code == 0, boot.stdout + boot.stderr

    extracted = cli_runner.invoke(app, ["extract", "demo"])
    assert extracted.exit_code == 0, extracted.stdout + extracted.stderr

    loaded = cli_runner.invoke(app, ["load", "demo"])
    assert loaded.exit_code == 0, loaded.stdout + loaded.stderr

    conn = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        rows = conn.execute(
            'SELECT order_id, amount FROM "das__demo".orders ORDER BY order_id'
        ).fetchall()
    finally:
        conn.close()

    assert rows == [
        (1, Decimal("1234.56")),
        (2, Decimal("0.01")),
        (3, Decimal("99999999.99")),
    ]
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/integration/test_extract_pipeline_sql.py::test_sql_extract_decimal_with_scale_round_trips -v`
Expected: FAIL — P2 load step exits non-zero with a `NormalizeJobFailed` / frozen-schema variant error (the exact #45 symptom). The assertion on `loaded.exit_code == 0` is what trips first.

- [ ] **Step 3: Wire `coerce_decimal` into `_project_record`**

Edit `src/das_cli/pipelines/load.py`. Update the import block (around line 22):

```python
from das_cli.dlt_glue.schema_factory import (
    build_dlt_columns,
    coerce_decimal,
    is_decimal_column,
    primary_keys_for,
)
```

Replace the `_project_record` function (around line 81-93):

```python
def _project_record(record: dict[str, Any], contract: LoadedContract) -> dict[str, Any]:
    """Project one record through the contract — physicalName → name."""
    schema = contract.contract.primary_schema
    out: dict[str, Any] = {}
    for prop in schema.properties:
        source_path = get_das_value(prop.custom_properties, "das.source_path")
        if source_path:
            value = _resolve_path(record, source_path)
        else:
            phys = prop.physicalName or prop.name
            value = record.get(phys)
        # See ADR-0018: SQL drivers return `Decimal`, dlt's JSON encoder serialises
        # it as a quoted string in landing; restore the type here so P2's frozen
        # contract sees the declared `decimal` data type.
        if is_decimal_column(prop):
            value = coerce_decimal(value)
        out[prop.name] = value
    return out
```

- [ ] **Step 4: Run the new test to verify it passes**

Run: `uv run pytest tests/integration/test_extract_pipeline_sql.py::test_sql_extract_decimal_with_scale_round_trips -v`
Expected: PASS.

- [ ] **Step 5: Run the rest of the integration suite to verify no regressions**

Run: `uv run pytest tests/integration/test_extract_pipeline_sql.py tests/integration/test_load_pipeline.py -v`
Expected: All pass. (HTTP tests in `test_extract_pipeline.py` are unaffected; decimal coercion is a per-property check.)

- [ ] **Step 6: Commit**

```bash
git add src/das_cli/pipelines/load.py tests/integration/test_extract_pipeline_sql.py
git commit -m "fix(load): coerce decimal columns back to Decimal in P2 projection

Resolves the JSONL str-in-decimal frozen-schema variant rejection for SQL
sources whose drivers return decimal.Decimal (Oracle NUMBER(p,s), MSSQL
DECIMAL(p,s), Postgres NUMERIC(p,s), MySQL DECIMAL(p,s)).

Fixes #45."
```

---

## Task 3: Restore decimal in e2e SQL seed fixtures

**Files:**
- Modify: `tests/e2e/fixtures/sql_seed_oracle.sql`
- Modify: `tests/e2e/fixtures/sql_seed_sqlserver.sql`

These fixtures had the `amount` column changed to integer to work around #45. With the P2 fix in place we restore the original types.

- [ ] **Step 1: Restore Oracle fixture**

In `tests/e2e/fixtures/sql_seed_oracle.sql`, replace the `CREATE TABLE orders` block (workaround comments + integer column):

```sql
-- amount is intentionally NUMBER(10) (integer) rather than NUMBER(12,2):
-- oracledb returns Decimal for fixed-precision NUMBER, dlt serialises
-- Decimal as string in the JSONL blob, and P2's frozen contract then
-- rejects the str-in-number variant. Tracked as a follow-up issue;
-- INTEGER keeps the round-trip verification intact for now.
CREATE TABLE orders (
  order_id      NUMBER(10),
  line_no       NUMBER(5),
  customer_id   NUMBER(10) NOT NULL,
  amount        NUMBER(10) NOT NULL,
  PRIMARY KEY (order_id, line_no)
);
```

with:

```sql
CREATE TABLE orders (
  order_id      NUMBER(10),
  line_no       NUMBER(5),
  customer_id   NUMBER(10) NOT NULL,
  amount        NUMBER(12,2) NOT NULL,
  PRIMARY KEY (order_id, line_no)
);
```

Also update the `INSERT INTO orders` lines so the seeded values are decimals rather than integers, exercising the round-trip:

```sql
INSERT INTO orders (order_id, line_no, customer_id, amount) VALUES (100, 1, 1, 19.99);
INSERT INTO orders (order_id, line_no, customer_id, amount) VALUES (100, 2, 1, 29.50);
INSERT INTO orders (order_id, line_no, customer_id, amount) VALUES (101, 1, 2, 9.00);
```

- [ ] **Step 2: Restore SQL Server fixture**

In `tests/e2e/fixtures/sql_seed_sqlserver.sql`, replace the workaround comment + integer column block:

```sql
-- amount is intentionally BIGINT (not DECIMAL(12,2)). pyodbc returns
-- Decimal for DECIMAL columns, dlt serialises Decimal as string in the
-- JSONL blob, and P2's frozen contract rejects the str-in-number variant.
-- Tracked as a follow-up issue. BIGINT keeps the round-trip intact.
CREATE TABLE orders (
  order_id      BIGINT NOT NULL,
  line_no       BIGINT NOT NULL,
  customer_id   BIGINT NOT NULL,
  amount        BIGINT NOT NULL,
  CONSTRAINT pk_orders PRIMARY KEY (order_id, line_no)
);
```

with:

```sql
CREATE TABLE orders (
  order_id      BIGINT NOT NULL,
  line_no       BIGINT NOT NULL,
  customer_id   BIGINT NOT NULL,
  amount        DECIMAL(12,2) NOT NULL,
  CONSTRAINT pk_orders PRIMARY KEY (order_id, line_no)
);
```

And update the `INSERT INTO orders` block to use decimal literals:

```sql
INSERT INTO orders (order_id, line_no, customer_id, amount) VALUES
  (100, 1, 1, 19.99),
  (100, 2, 1, 29.50),
  (101, 1, 2,  9.00);
```

- [ ] **Step 3: Inspect any e2e test code that asserts on `amount` values**

Run: `grep -n "amount" tests/e2e/sources/test_oracle.py tests/e2e/sources/test_sqlserver.py`
Expected: locate any assertions referencing `amount` to see whether they assume integer values. If any exist, update them to use `Decimal("19.99")`, `Decimal("29.50")`, `Decimal("9.00")` to match the new fixture.

If updates are needed, edit both `tests/e2e/sources/test_oracle.py` and `tests/e2e/sources/test_sqlserver.py` to compare against `Decimal` values rather than ints. Add `from decimal import Decimal` to the imports if needed.

- [ ] **Step 4: Commit**

```bash
git add tests/e2e/fixtures/sql_seed_oracle.sql tests/e2e/fixtures/sql_seed_sqlserver.sql tests/e2e/sources/test_oracle.py tests/e2e/sources/test_sqlserver.py
git commit -m "test(e2e): restore decimal(p,s) amount column in SQL seed fixtures

The Decimal-as-string workaround is no longer needed now that P2
projection coerces decimal columns back to Decimal (#45)."
```

Note: e2e tests require Docker + driver wheels and are not run in this default flow. They will be exercised in CI.

---

## Task 4: Add `reset_extract_state` helper

**Files:**
- Modify: `src/das_cli/pipelines/extract.py`

This helper centralises the "reset cursor state for a source" operation. It is the implementation behind `extract --full`. Landing data files are not touched; only the dlt-internal `_dlt_pipeline_state/`, `_dlt_loads/`, `_dlt_version/` directories under `landing/<source>/` plus the local `.dlt/pipelines/das_extract__<source>/` state directory.

- [ ] **Step 1: Add the helper to `pipelines/extract.py`**

In `src/das_cli/pipelines/extract.py`, after the imports and before `run_extract`, add:

```python
def reset_extract_state(source_name: str, config_path: Path | str) -> None:
    """Reset dlt incremental cursor state for one source. See ADR-0019.

    Wipes both:
      * local `.dlt/pipelines/das_extract__<source>/` (pipeline state dir)
      * landing `<bucket_url>/<source>/_dlt_pipeline_state/`,
        `_dlt_loads/`, `_dlt_version/` (destination-side state files)

    Landing table-data directories are left untouched — P1 remains
    append-only (see ADR-0002).

    Raises `NotImplementedError` if `landing.bucket_url` is a remote URL
    (`s3://`, `gs://`, `az://`); local landing is the only supported shape
    in v0.1.
    """
    import shutil

    local_state = Path(".dlt/pipelines") / f"das_extract__{source_name}"
    if local_state.exists():
        shutil.rmtree(local_state)

    cfg = load_das_config(config_path)
    bucket_url = cfg.landing.bucket_url
    if bucket_url.startswith(("s3://", "gs://", "az://")):
        raise NotImplementedError(
            "--full reset on remote landing (s3/gs/az) not supported in v0.1"
        )
    landing_root = Path(bucket_url).expanduser()
    source_landing = landing_root / source_name
    for sub in ("_dlt_pipeline_state", "_dlt_loads", "_dlt_version"):
        p = source_landing / sub
        if p.exists():
            shutil.rmtree(p)
```

- [ ] **Step 2: Smoke-check the import surface**

Run: `uv run python -c "from das_cli.pipelines.extract import reset_extract_state; print('ok')"`
Expected: `ok`.

- [ ] **Step 3: Commit**

```bash
git add src/das_cli/pipelines/extract.py
git commit -m "feat(extract): add reset_extract_state helper for --full

Wipes local + landing-side dlt cursor state without touching the
append-only landing table data. Preparation for the --full split (#43)."
```

---

## Task 5: Switch `extract --full` to use `reset_extract_state`; tighten the test

**Files:**
- Modify: `src/das_cli/cli.py` (around line 670)
- Modify: `tests/integration/test_extract_pipeline_sql.py` — rename and tighten existing test

- [ ] **Step 1: Rename + tighten the existing test**

In `tests/integration/test_extract_pipeline_sql.py`, replace `test_sql_extract_full_flag_replays_everything` with the tightened form:

```python
def test_sql_extract_full_resets_cursor_and_replays_source(
    workspace: Path, cli_runner: CliRunner
) -> None:
    db = workspace / "demo.sqlite"
    _seed_sqlite(
        db,
        rows=[
            {
                "customer_id": 1,
                "name": "Ada",
                "updated_at": datetime(2026, 5, 1, tzinfo=UTC),
            },
            {
                "customer_id": 2,
                "name": "Linus",
                "updated_at": datetime(2026, 5, 2, tzinfo=UTC),
            },
        ],
    )

    cli_runner.invoke(app, ["init"])
    src_dir = workspace / "contracts" / "demo"
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(
        f"type: sql\nendpoint: sqlite:///{db}\nspec:\n  kind: sql\nauth:\n  type: none\n"
    )
    cli_runner.invoke(app, ["contract", "bootstrap", "demo"])

    cli_runner.invoke(app, ["extract", "demo"])
    second = cli_runner.invoke(app, ["extract", "demo", "--full"])
    assert second.exit_code == 0, second.stdout + second.stderr

    blobs = _read_jsonl(workspace / "landing" / "demo" / "customers")
    by_load: dict[str, set[int]] = {}
    for r in blobs:
        load = r.get("_dlt_load_id", "?")
        by_load.setdefault(load, set()).add(r["_data"]["customer_id"])
    loads_in_order = [by_load[k] for k in sorted(by_load)]
    assert len(loads_in_order) >= 2, by_load
    assert loads_in_order[0] == {1, 2}
    assert loads_in_order[1] == {1, 2}
```

- [ ] **Step 2: Run test to confirm it fails today**

Run: `uv run pytest tests/integration/test_extract_pipeline_sql.py::test_sql_extract_full_resets_cursor_and_replays_source -v`
Expected: FAIL — `assert len(loads_in_order) >= 2` (only one load_id in landing because destination state suppresses the second run) OR `loads_in_order[1] == {1, 2}` (empty set). This is the #43 symptom.

- [ ] **Step 3: Replace inline `shutil.rmtree` with `reset_extract_state`**

In `src/das_cli/cli.py`, locate the `extract` command's `--full` handling (around line 670-676):

```python
    only = list(resource) if resource else None
    if full:
        import shutil

        for s in target_sources:
            state_dir = Path(".dlt/pipelines") / f"das_extract__{s}"
            if state_dir.exists():
                shutil.rmtree(state_dir)
```

Replace with:

```python
    only = list(resource) if resource else None
    if full:
        # See ADR-0019: --full resets dlt cursor state on both sides; landing
        # table data is preserved (append-only per ADR-0002).
        from das_cli.pipelines.extract import reset_extract_state

        for s in target_sources:
            reset_extract_state(s, config_path)
```

Also update the `--full` help text from `"Ignore cursor; full reload."` to `"Reset dlt cursor state so the next extract re-reads the source from the beginning. Landing files are preserved."`:

```python
    full: Annotated[
        bool,
        typer.Option(
            "--full",
            help=(
                "Reset dlt cursor state so the next extract re-reads the "
                "source from the beginning. Landing files are preserved."
            ),
        ),
    ] = False,
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/integration/test_extract_pipeline_sql.py::test_sql_extract_full_resets_cursor_and_replays_source -v`
Expected: PASS.

- [ ] **Step 5: Run the full SQL extract test file to check for regressions**

Run: `uv run pytest tests/integration/test_extract_pipeline_sql.py -v`
Expected: All pass (3 tests: existing `writes_jsonl_blobs`, `cursor_picks_up_only_new_rows`, plus the renamed test).

- [ ] **Step 6: Commit**

```bash
git add src/das_cli/cli.py tests/integration/test_extract_pipeline_sql.py
git commit -m "fix(extract): --full resets dlt state on both sides

Wipe local pipeline state AND landing's _dlt_pipeline_state/_dlt_loads/
_dlt_version dirs so dlt re-pulls the full source on the next extract.
Landing table data is preserved.

Fixes #43."
```

---

## Task 6: Thread `full` through `run_load` and `_build_load_resource`

**Files:**
- Modify: `src/das_cli/pipelines/load.py`

`full=True` flips two behaviours: per-resource `write_disposition` becomes `"replace"`, and the `ChangeDetectionFilter` is skipped so all landing rows reach dlt.

- [ ] **Step 1: Update `_build_load_resource` signature and body**

Edit `src/das_cli/pipelines/load.py`. Change the function signature of `_build_load_resource` (around line 149) to add `full: bool`:

```python
def _build_load_resource(
    contract: LoadedContract,
    *,
    landing_dir: Path,
    hash_exclude: set[str],
    primary_key: list[str],
    pipeline: dlt.Pipeline,
    dataset: str,
    schema_contract: dict[str, str],
    table_format: str | None = None,
    progress_handle: ProgressHandle | None = None,
    full: bool = False,
) -> Any:
```

Inside the function, change the `write_disposition` and skip the `ChangeDetectionFilter` when `full=True`. Replace the `resource_kwargs` block:

```python
    resource_kwargs: dict[str, Any] = {
        "name": table_name,
        "write_disposition": "append",
        "primary_key": primary_key or None,
        "columns": cols,
        "schema_contract": schema_contract,
    }
```

with:

```python
    # See ADR-0019: --full uses dlt's "replace" disposition to truncate +
    # rebuild from full landing replay. Default is the incremental append path.
    write_disposition = "replace" if full else "append"
    resource_kwargs: dict[str, Any] = {
        "name": table_name,
        "write_disposition": write_disposition,
        "primary_key": primary_key or None,
        "columns": cols,
        "schema_contract": schema_contract,
    }
```

Then, inside the inner `_gen` function, replace the change-filter block:

```python
        # Load latest hashes from destination for this resource. See ADR-0016.
        if primary_key:
            latest = load_latest_hash(
                pipeline=pipeline,
                dataset=dataset,
                table=table_name,
                primary_key=primary_key,
            )
            change_filter: ChangeDetectionFilter | None = ChangeDetectionFilter(
                primary_key=primary_key, latest_hash=latest
            )
        else:
            change_filter = None
```

with:

```python
        # See ADR-0019: --full bypasses change-detection so every landing row
        # reaches dlt and the destination table is rebuilt from scratch.
        if full or not primary_key:
            change_filter: ChangeDetectionFilter | None = None
        else:
            latest = load_latest_hash(
                pipeline=pipeline,
                dataset=dataset,
                table=table_name,
                primary_key=primary_key,
            )
            change_filter = ChangeDetectionFilter(
                primary_key=primary_key, latest_hash=latest
            )
```

- [ ] **Step 2: Update `run_load` signature and pass `full` through**

Change the `run_load` signature (around line 231):

```python
def run_load(
    *,
    config_path: Path | str,
    only_source: str | None = None,
    only_resources: list[str] | None = None,
    progress_handle: ProgressHandle | None = None,
    dlt_progress: str | None = None,
    full: bool = False,
) -> dict[str, Any]:
```

In the `_build_load_resource(...)` call inside `run_load` (around line 290), pass `full=full`:

```python
            res = _build_load_resource(
                c,
                landing_dir=landing_root / src.name / c.resource_name,
                hash_exclude=hash_exclude,
                primary_key=primary_keys_for(c.contract),
                pipeline=pipeline,
                dataset=dataset,
                schema_contract=schema_contract,
                table_format=table_format,
                progress_handle=progress_handle,
                full=full,
            )
```

- [ ] **Step 3: Verify nothing else broke at import time**

Run: `uv run python -c "from das_cli.pipelines.load import run_load; print('ok')"`
Expected: `ok`.

- [ ] **Step 4: Run existing load integration tests to verify default behaviour unchanged**

Run: `uv run pytest tests/integration/test_load_pipeline.py -v`
Expected: All existing tests still pass (the new `full=False` default preserves prior behaviour).

- [ ] **Step 5: Commit**

```bash
git add src/das_cli/pipelines/load.py
git commit -m "feat(load): plumb full=bool through run_load and resource builder

--full sets write_disposition='replace' and skips change-detection;
default path (full=False) is unchanged. CLI wiring lands in the next
commit (#43)."
```

---

## Task 7: Add `--full` to `das load` CLI + integration test

**Files:**
- Modify: `src/das_cli/cli.py` (the `load` command around line 730)
- Modify: `tests/integration/test_load_pipeline.py` — add table-replace test

- [ ] **Step 1: Write the failing integration test**

Append to `tests/integration/test_load_pipeline.py`:

```python
def test_load_full_replaces_destination_table(
    workspace: Path, cli_runner: CliRunner
) -> None:
    """`load --full` rebuilds the destination table from all landing files."""
    _setup_workspace(workspace, cli_runner)
    _write_landing_partitioned(
        workspace,
        [{"ProductId": 1, "Name": "A"}],
        extracted_on="2026-05-01",
        load_id="1700000000",
    )
    _write_landing_partitioned(
        workspace,
        [{"ProductId": 2, "Name": "B"}],
        extracted_on="2026-05-02",
        load_id="1700000100",
    )

    # Incremental load first — both rows land via the standard path.
    first = cli_runner.invoke(app, ["load", "x"])
    assert first.exit_code == 0, first.output

    # Insert an out-of-band marker row directly into the destination so we can
    # detect whether the table was truncated by --full.
    conn = duckdb.connect(str(workspace / "test.duckdb"))
    try:
        conn.execute(
            'INSERT INTO "das__x".products (product_id, name, _row_hash, '
            "_extracted_at, _extracted_on, _loaded_at, _loaded_on) VALUES "
            "(999, 'MARKER', 'sentinel', "
            "TIMESTAMP '2026-05-01 00:00:00', DATE '2026-05-01', "
            "TIMESTAMP '2026-05-01 00:00:00', DATE '2026-05-01')"
        )
    finally:
        conn.close()

    # --full should drop+rebuild from landing — the marker must disappear.
    second = cli_runner.invoke(app, ["load", "x", "--full"])
    assert second.exit_code == 0, second.output

    conn = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        rows = conn.execute(
            'SELECT product_id, name FROM "das__x".products ORDER BY product_id'
        ).fetchall()
    finally:
        conn.close()

    assert rows == [(1, "A"), (2, "B")], rows
```

- [ ] **Step 2: Run the test to verify it fails**

Run: `uv run pytest tests/integration/test_load_pipeline.py::test_load_full_replaces_destination_table -v`
Expected: FAIL — the CLI rejects `--full` as an unknown option (`No such option: --full`).

- [ ] **Step 3: Add `--full` to `das load`**

In `src/das_cli/cli.py`, update the `load` command signature (around line 731):

```python
@app.command()
def load(
    ctx: typer.Context,
    source: Annotated[str | None, typer.Argument()] = None,
    resource: Annotated[list[str] | None, typer.Option("--resource")] = None,
    full: Annotated[
        bool,
        typer.Option(
            "--full",
            help=(
                "Replace the destination table by replaying all landing files. "
                "Bypasses change detection."
            ),
        ),
    ] = False,
) -> None:
```

Pass `full=full` through to both `run_load` calls inside the function. Replace the existing two-branch invocation (around line 784-801):

```python
    try:
        if mode is None:
            run_load(
                config_path=config_path,
                only_source=source,
                only_resources=only,
                progress_handle=None,
                dlt_progress=dlt_progress,
            )
        else:
            with progress(totals, mode=mode) as h:
                run_load(
                    config_path=config_path,
                    only_source=source,
                    only_resources=only,
                    progress_handle=h,
                    dlt_progress=dlt_progress,
                )
```

with:

```python
    try:
        if mode is None:
            run_load(
                config_path=config_path,
                only_source=source,
                only_resources=only,
                progress_handle=None,
                dlt_progress=dlt_progress,
                full=full,
            )
        else:
            with progress(totals, mode=mode) as h:
                run_load(
                    config_path=config_path,
                    only_source=source,
                    only_resources=only,
                    progress_handle=h,
                    dlt_progress=dlt_progress,
                    full=full,
                )
```

- [ ] **Step 4: Run the new test to verify it passes**

Run: `uv run pytest tests/integration/test_load_pipeline.py::test_load_full_replaces_destination_table -v`
Expected: PASS.

- [ ] **Step 5: Run the full load test suite to check for regressions**

Run: `uv run pytest tests/integration/test_load_pipeline.py -v`
Expected: All pass.

- [ ] **Step 6: Commit**

```bash
git add src/das_cli/cli.py tests/integration/test_load_pipeline.py
git commit -m "feat(load): add --full to replace destination table from landing

When --full is set, write_disposition flips to 'replace' and change
detection is bypassed; dlt truncates and rebuilds the table from a full
landing replay. Default behaviour is unchanged.

Companion fix for #43."
```

---

## Task 8: Swap `ingest --full` for `--extract-full` / `--load-full`

**Files:**
- Modify: `src/das_cli/cli.py` (the `ingest` command around line 812)
- Modify: `tests/integration/test_cli_ingest.py` — add a test that exercises both flags

- [ ] **Step 1: Write the failing test**

Open `tests/integration/test_cli_ingest.py` to check existing structure:

Run: `head -50 tests/integration/test_cli_ingest.py`

Append a new test that exercises the two flags. Use the patterns established in the file; here is the test body:

```python
def test_ingest_extract_full_resets_cursor_and_load_full_replaces_table(
    workspace: Path, cli_runner: CliRunner
) -> None:
    """`ingest --extract-full --load-full` reruns both phases in their full mode."""
    from datetime import UTC, datetime

    import duckdb
    from sqlalchemy import (
        Column,
        DateTime,
        Integer,
        MetaData,
        String,
        Table,
        create_engine,
        insert,
    )

    db = workspace / "demo.sqlite"
    engine = create_engine(f"sqlite:///{db}")
    md = MetaData()
    customers = Table(
        "customers",
        md,
        Column("customer_id", Integer, primary_key=True),
        Column("name", String(100), nullable=False),
        Column("updated_at", DateTime, nullable=False),
    )
    md.create_all(engine)
    with engine.begin() as conn:
        conn.execute(
            insert(customers),
            [
                {
                    "customer_id": 1,
                    "name": "Ada",
                    "updated_at": datetime(2026, 5, 1, tzinfo=UTC),
                },
                {
                    "customer_id": 2,
                    "name": "Linus",
                    "updated_at": datetime(2026, 5, 2, tzinfo=UTC),
                },
            ],
        )
    engine.dispose()

    cli_runner.invoke(app, ["init"])
    src_dir = workspace / "contracts" / "demo"
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(
        f"type: sql\nendpoint: sqlite:///{db}\nspec:\n  kind: sql\nauth:\n  type: none\n"
    )
    cli_runner.invoke(app, ["contract", "bootstrap", "demo"])

    first = cli_runner.invoke(app, ["ingest", "demo"])
    assert first.exit_code == 0, first.output

    second = cli_runner.invoke(
        app, ["ingest", "demo", "--extract-full", "--load-full"]
    )
    assert second.exit_code == 0, second.output

    # extract --full should have produced a second landing load_id with all rows.
    import gzip
    import json

    landing = workspace / "landing" / "demo" / "customers"
    by_load: dict[str, set[int]] = {}
    for f in landing.rglob("*.jsonl*"):
        text = (
            gzip.decompress(f.read_bytes()).decode()
            if f.suffix == ".gz"
            else f.read_text()
        )
        for line in text.strip().splitlines():
            r = json.loads(line)
            if "_data" not in r:
                continue
            by_load.setdefault(r.get("_dlt_load_id", "?"), set()).add(
                r["_data"]["customer_id"]
            )
    loads_in_order = [by_load[k] for k in sorted(by_load)]
    assert len(loads_in_order) >= 2, by_load
    assert loads_in_order[-1] == {1, 2}

    # load --full should leave exactly the two customers in the destination.
    conn = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        rows = conn.execute(
            'SELECT customer_id, name FROM "das__demo".customers ORDER BY customer_id'
        ).fetchall()
    finally:
        conn.close()
    assert rows == [(1, "Ada"), (2, "Linus")], rows
```

- [ ] **Step 2: Run the test to verify it fails**

Run: `uv run pytest tests/integration/test_cli_ingest.py::test_ingest_extract_full_resets_cursor_and_load_full_replaces_table -v`
Expected: FAIL — `No such option: --extract-full`.

- [ ] **Step 3: Swap `ingest`'s `--full` for `--extract-full` / `--load-full`**

In `src/das_cli/cli.py`, replace the `ingest` command (around line 812-841):

```python
@app.command()
def ingest(
    ctx: typer.Context,
    source: Annotated[str | None, typer.Argument()] = None,
    resource: Annotated[list[str] | None, typer.Option("--resource")] = None,
    full: Annotated[bool, typer.Option("--full", help="Ignore cursor; full reload.")] = False,
    limit: Annotated[int | None, typer.Option("--limit")] = None,
) -> None:
    """Run extract followed by load. Exit code = worst of the two."""
    from das_cli.exit_codes import OK
    from das_cli.output import header, success

    header("ingest", source or "all sources")

    # Forward to extract first.
    try:
        extract(ctx=ctx, source=source, resource=resource, full=full, limit=limit)
    except typer.Exit as e:
        if e.exit_code != OK:
            raise typer.Exit(code=e.exit_code) from None

    # Then load.
    try:
        load(ctx=ctx, source=source, resource=resource)
    except typer.Exit as e:
        if e.exit_code != OK:
            raise typer.Exit(code=e.exit_code) from None

    success("ingest complete")
    raise typer.Exit(code=OK)
```

with:

```python
@app.command()
def ingest(
    ctx: typer.Context,
    source: Annotated[str | None, typer.Argument()] = None,
    resource: Annotated[list[str] | None, typer.Option("--resource")] = None,
    extract_full: Annotated[
        bool,
        typer.Option(
            "--extract-full",
            help="Forward --full to the extract phase (reset dlt cursor state).",
        ),
    ] = False,
    load_full: Annotated[
        bool,
        typer.Option(
            "--load-full",
            help="Forward --full to the load phase (replace destination table).",
        ),
    ] = False,
    limit: Annotated[int | None, typer.Option("--limit")] = None,
) -> None:
    """Run extract followed by load. Exit code = worst of the two.

    See ADR-0019: --full splits into source-side (--extract-full) and
    destination-side (--load-full) reset; no composite --full on ingest.
    """
    from das_cli.exit_codes import OK
    from das_cli.output import header, success

    header("ingest", source or "all sources")

    try:
        extract(
            ctx=ctx, source=source, resource=resource, full=extract_full, limit=limit
        )
    except typer.Exit as e:
        if e.exit_code != OK:
            raise typer.Exit(code=e.exit_code) from None

    try:
        load(ctx=ctx, source=source, resource=resource, full=load_full)
    except typer.Exit as e:
        if e.exit_code != OK:
            raise typer.Exit(code=e.exit_code) from None

    success("ingest complete")
    raise typer.Exit(code=OK)
```

- [ ] **Step 4: Run the new test to verify it passes**

Run: `uv run pytest tests/integration/test_cli_ingest.py::test_ingest_extract_full_resets_cursor_and_load_full_replaces_table -v`
Expected: PASS.

- [ ] **Step 5: Run the full ingest test suite**

Run: `uv run pytest tests/integration/test_cli_ingest.py -v`
Expected: All pass. If a pre-existing test used `ingest --full`, it will fail; update it to use `--extract-full` (the previous `--full` only forwarded to extract).

- [ ] **Step 6: Commit**

```bash
git add src/das_cli/cli.py tests/integration/test_cli_ingest.py
git commit -m "feat(ingest): replace --full with explicit --extract-full / --load-full

The two phases now have distinct refresh semantics (ADR-0019); a single
composite flag on ingest would hide the distinction. Users wanting an
end-to-end refresh pass both."
```

---

## Task 9: Update ADR-0018 Consequences

**Files:**
- Modify: `docs/adrs/0018-sql-source-via-sqlalchemy.md`

- [ ] **Step 1: Append a Consequences bullet for the decimal round-trip**

In `docs/adrs/0018-sql-source-via-sqlalchemy.md`, locate the closing bullet under `## Consequences` (the one about E2E coverage requiring Docker + driver wheels). After it, append:

```markdown
- `decimal(p,s)` columns round-trip losslessly through P1 → landing → P2.
  Drivers (`oracledb`, `pyodbc`, etc.) return `decimal.Decimal`; dlt's JSON
  encoder writes it as a quoted string in landing JSONL; P2's projection
  (`pipelines/load.py::_project_record`) parses the string back into
  `Decimal` for columns whose contract declares `logicalType: number` with
  `physicalType: decimal(p,s)`. The cost is one parse per decimal cell at
  P2 ingest, paid in exchange for no precision loss. The contract surface
  for the round-trip lives in `dlt_glue/schema_factory.py`
  (`coerce_decimal`, `is_decimal_column`).
```

- [ ] **Step 2: Commit**

```bash
git add docs/adrs/0018-sql-source-via-sqlalchemy.md
git commit -m "docs(adr-0018): document decimal(p,s) round-trip in Consequences"
```

---

## Task 10: File ADR-0019 (`--full` semantics split)

**Files:**
- Create: `docs/adrs/0019-full-flag-semantics.md`
- Modify: `docs/adrs/README.md`

- [ ] **Step 1: Verify the next available ADR number is 0019**

Run: `ls docs/adrs/ | grep -E '^00[0-9]+'`
Expected: 0001 through 0018 present; 0019 is free.

- [ ] **Step 2: Write the ADR**

Create `docs/adrs/0019-full-flag-semantics.md`:

```markdown
# 0019. `--full` semantics: split between extract and load

- **Status:** Accepted
- **Date:** 2026-05-11
- **Deciders:** mattiasthalen

## Context

`das extract --full` was originally specified as "ignore cursor; full reload"
and implemented as a wipe of `.dlt/pipelines/das_extract__<source>/`. dlt
persists pipeline state on **both** sides — locally and at the destination
(landing). Wiping only the local copy means dlt re-derives the same state
hash on the next run, finds it already-loaded at landing, and reports zero
rows. The integration test for `--full` carried a deliberately loose
assertion to stay green; #43 made the latent defect visible.

Resolving #43 forced a re-examination of what `--full` means. The pipeline
has two distinct phases with two distinct kinds of "refresh":

- P1 (extract) reads from a source and appends to landing. Refresh here is
  about the **source-side cursor** — making the next read pull the source
  from the beginning rather than from where the last cursor checkpoint left
  off. Landing data must remain untouched (ADR-0002: landing is the
  append-only archive).
- P2 (load) reads landing and writes the destination table via the contract,
  with row-hash change detection deduping unchanged rows (ADR-0004).
  Refresh here is about the **destination table** — replacing it with a
  fresh projection of all landing files.

A single flag named `--full` would have to mean different things on
different commands. Better to give each phase its own flag with clear
semantics.

## Decision

`--full` is split into two independent flags, one per phase, with no
composite version:

- **`das extract --full`** resets dlt cursor state for the named source(s).
  Wipes `.dlt/pipelines/das_extract__<source>/` locally AND
  `<landing>/<source>/_dlt_pipeline_state/`, `_dlt_loads/`, `_dlt_version/`.
  Landing table-data directories are untouched.
- **`das load --full`** sets `write_disposition="replace"` and skips the
  `ChangeDetectionFilter`, causing dlt to truncate and rebuild the
  destination table from a full landing replay.
- **`das ingest`** exposes both as `--extract-full` and `--load-full`. No
  composite `--full` is offered.

Remote landing (`s3://`, `gs://`, `az://`) raises `NotImplementedError` on
`extract --full` until cloud-landing support lands; local landing is the
only currently-tested shape.

## Alternatives considered

- **Composite `--full` on every command meaning "do the most refresh-y
  thing".** Rejected: hides the distinction between source-side and
  destination-side refresh; ambiguous on `ingest` (does it mean re-pull,
  replace, or both?).
- **Use dlt's `refresh="drop_resources"` on `pipeline.run()` for both
  sides.** Rejected: drops resource data along with state, which on
  the P1 pipeline would erase landing files and violate ADR-0002.
- **Surgically delete only the `_dlt_pipeline_state` file (not the whole
  directory hierarchy).** Rejected: dlt also tracks load-package metadata
  in `_dlt_loads`, and the cursor re-sync depends on the pair being
  consistent.
- **Keep `--full` on ingest with both flags as aliases.** Considered:
  more discoverable. Rejected: encourages users to think of "full" as one
  concept; the explicit two-flag form forces the split into muscle memory.

## Consequences

- `_dlt_pipeline_state`, `_dlt_loads`, and `_dlt_version` directory names
  become a contract surface with dlt's filesystem destination. A dlt
  upgrade renaming them would break `extract --full` loudly on the first
  run rather than silently — acceptable for v0.1.
- `ingest --full` is removed (was forwarded to extract only). Users with
  scripts that relied on it must migrate to `--extract-full`. This is a
  CLI-shape breaking change accepted in v0.1.
- P1 stays strictly append-only. The historical record of every extract
  load_id remains in landing across `--full` runs.
- P2's table-replace path goes through dlt's first-class
  `write_disposition="replace"`, not through manual table-drop SQL, so it
  works uniformly across DuckDB, DuckLake, and Delta destinations.
```

- [ ] **Step 3: Update the ADR index**

In `docs/adrs/README.md`, append a row to the table (after the ADR-0018 row):

```markdown
| 0019 | `--full` semantics: split between extract and load | Accepted |
```

- [ ] **Step 4: Run the project's ADR sanity checks (per CLAUDE.md)**

Run: `head -1 docs/adrs/0*.md`
Expected: One line per ADR file, each starting with `# NNNN. <Title>`. Verify visually that 0019's heading matches the table row.

- [ ] **Step 5: Commit**

```bash
git add docs/adrs/0019-full-flag-semantics.md docs/adrs/README.md
git commit -m "docs(adrs): file ADR-0019 — --full semantics split between extract and load

Locks in the source-side cursor reset (extract --full) vs destination-side
table replace (load --full) split, with rationale and alternatives. See
issue #43, #47."
```

---

## Task 11: Final verification — run the whole suite

**Files:** none.

- [ ] **Step 1: Run the unit + integration tests**

Run: `uv run pytest tests/unit tests/integration -v`
Expected: All pass. E2E suite (`tests/e2e/`) requires Docker + Oracle / SQL Server containers and is not in scope for local verification; CI exercises it.

- [ ] **Step 2: Run linters / type checks if configured**

Run: `uv run pre-commit run --all-files`
Expected: All hooks pass. If `mypy` or `ruff` flag the new code, fix the issues, re-run, and commit a follow-up `style:` fix if needed.

- [ ] **Step 3: Verify both ADRs pass the pre-merge ADR check (per CLAUDE.md)**

Run: `head -1 docs/adrs/0*.md`
Expected: Files 0001-0019 each present, headings match README table entries verbatim. No collisions on main (run `git fetch origin main && git log --oneline origin/main -- docs/adrs/` to confirm no `0019-*.md` exists upstream).

- [ ] **Step 4: Push the branch**

Run: `git push -u origin claude/brainstorm-das-cli-defects-TjkZY`
Expected: Push succeeds. PR creation is **not** part of this plan — the user creates it manually.

---

## Spec coverage summary

| Spec section | Covered by task(s) |
|---|---|
| `extract --full` cursor reset on both sides | 4, 5 |
| `load --full` table replace | 6, 7 |
| `ingest --extract-full --load-full` | 8 |
| Decimal lossless round-trip in P2 | 1, 2 |
| Shared `coerce_decimal` / `is_decimal_column` in schema_factory | 1 |
| E2E fixtures restored | 3 |
| ADR-0018 Consequences bullet | 9 |
| ADR-0019 filed + listed | 10 |
| Tightened #43 assertion | 5 |
| New decimal round-trip integration test | 2 |
| New `load --full` integration test | 7 |
| New `ingest --extract-full --load-full` integration test | 8 |
| Cloud landing `NotImplementedError` for v0.1 | 4 |

All Definition-of-Done items from issue #47 are covered.
