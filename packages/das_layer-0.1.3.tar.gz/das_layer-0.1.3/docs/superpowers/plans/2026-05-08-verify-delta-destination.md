# Verify Delta Destination Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add Delta as the third verified destination in das-cli, implemented as a filesystem-alias (`destination: delta` → `dlt.destinations.filesystem(...)` plus per-resource `table_format="delta"`), with full unit/integration/e2e test coverage and a documented architectural decision (ADR-0017).

**Architecture:** A new `delta` branch in `_build_destination` (`pipelines/load.py`) constructs a `dlt.destinations.filesystem` instance. `_build_load_resource` gains an optional `table_format` kwarg, and `run_load` plumbs `"delta"` through it when the destination is `delta` (dlt 1.26 has no destination-level `default_table_format` kwarg — table format is per-resource). `change_detection.py` is unchanged — change detection round-trips through dlt's filesystem `sql_client()`, which is DuckDB-backed and reads Delta tables via `delta_scan`. The `delta` alias keeps the verified contract narrow (Delta-on-filesystem, not Parquet-on-filesystem).

**Tech Stack:** Python 3.12, dlt (≥1.0, with `deltalake` extra adding the Rust-backed `deltalake` package), pytest, typer testing CliRunner. Mirrors the test patterns of the existing DuckLake destination.

**Spec:** `docs/superpowers/specs/2026-05-07-verify-delta-destination-design.md`

---

## File Structure

**Create:**
- `docs/adrs/0017-delta-destination-via-filesystem-alias.md` — new ADR documenting the alias decision and the extended sql_client contract.
- `tests/integration/test_load_pipeline_delta.py` — three integration tests (initial load, change-detection two-cycle, A→B→A).
- `tests/e2e/test_adventureworks_delta.py` — e2e test using OData against AdventureWorks.
- `tests/e2e/test_northwind_delta.py` — e2e test using OpenAPI against Northwind.

**Modify:**
- `src/das_cli/pipelines/load.py:42-70` — add `delta` branch to `_build_destination`; update unknown-destination error message.
- `src/das_cli/doctor.py:32-41` — add `delta` branch alongside the existing `duckdb` and `ducklake` branches.
- `pyproject.toml:9` — add `deltalake` to the dlt extras.
- `tests/conftest.py:33-95` — add `delta_workspace` fixture and `delta_reader_pipeline` helper alongside the existing ducklake versions.
- `tests/unit/test_destination_dispatch.py` — add unit tests for the `delta` branch; update unknown-destination message assertion.
- `tests/integration/test_cli_doctor.py:67-123` — add `delta` doctor tests alongside the ducklake ones.
- `docs/adrs/README.md:25-26` — append ADR-0017 row to the index.
- `README.md:12-13` — extend "What it is" lead to mention Delta.
- `README.md:88-95` — add two Delta rows to the Verified matrix.

**File responsibilities (unchanged from ADR-0016):**
- `pipelines/load.py` owns destination dispatch via `_build_destination`. Adding a destination is one branch.
- `pipelines/change_detection.py` is destination-agnostic; reads through `pipeline.sql_client()`.
- `tests/conftest.py` owns workspace fixtures and reader-pipeline helpers, keyed by destination name.

---

## Task 1: Add `deltalake` to dlt extras

**Files:**
- Modify: `pyproject.toml:9`

- [ ] **Step 1: Update the `dlt[...]` extras list**

In `pyproject.toml`, change line 9:

```toml
"dlt[duckdb,ducklake,filesystem,parquet]>=1.0",
```

to:

```toml
"dlt[deltalake,duckdb,ducklake,filesystem,parquet]>=1.0",
```

- [ ] **Step 2: Sync the dependency**

Run: `uv sync`
Expected: completes without error; `deltalake` (Rust-backed) appears in the install log.

- [ ] **Step 3: Verify the deltalake package is importable**

Run: `uv run python -c "import deltalake; print(deltalake.__version__)"`
Expected: prints a version string (e.g. `0.x.y`); no `ModuleNotFoundError`.

- [ ] **Step 4: Commit**

```bash
git add pyproject.toml uv.lock
git commit -m "deps: add dlt[deltalake] extra for delta destination"
```

---

## Task 2: TDD the `delta` branch in `_build_destination` + plumb `table_format`

**Files:**
- Modify: `src/das_cli/pipelines/load.py`
- Modify: `tests/unit/test_destination_dispatch.py`

**Design note:** dlt 1.26 does NOT expose a `default_table_format` kwarg on the filesystem destination factory (verified empirically — silently dropped). Table format is per-resource via `@dlt.resource(..., table_format="delta")`. This task therefore does TWO things: (1) add the `delta` dispatch branch (filesystem with no special kwargs), and (2) plumb `table_format` through `_build_load_resource` and `run_load`. See ADR-0017 Decision B.

- [ ] **Step 1: Write the failing unit tests for dispatch**

Append to `tests/unit/test_destination_dispatch.py`:

```python
def test_delta_dispatch_returns_filesystem_destination() -> None:
    target = TargetConfig(
        destination="delta",
        credentials={"bucket_url": "./das_delta"},
    )
    dest = _build_destination(target)
    # Delta is implemented as a filesystem destination; table_format is set per-resource.
    assert dest.destination_type == "dlt.destinations.filesystem"


def test_delta_dispatch_forwards_bucket_url_verbatim() -> None:
    target = TargetConfig(
        destination="delta",
        credentials={"bucket_url": "./custom_delta"},
    )
    dest = _build_destination(target)
    assert dest.config_params["bucket_url"] == "./custom_delta"


def test_delta_dispatch_defaults_bucket_url_when_missing() -> None:
    target = TargetConfig(destination="delta", credentials={})
    dest = _build_destination(target)
    assert dest.config_params["bucket_url"] == "./das_delta"


def test_delta_dispatch_disables_dataset_name_normalization() -> None:
    target = TargetConfig(
        destination="delta",
        credentials={"bucket_url": "./das_delta"},
    )
    dest = _build_destination(target)
    assert dest.config_params["enable_dataset_name_normalization"] is False
```

Also UPDATE the existing `test_unknown_destination_raises_value_error` to assert on the new error string:

```python
def test_unknown_destination_raises_value_error() -> None:
    target = TargetConfig(destination="postgres", credentials={})
    with pytest.raises(
        ValueError,
        match=r"Verified destinations: duckdb, ducklake, delta",
    ):
        _build_destination(target)
```

- [ ] **Step 2: Run the new tests to verify they fail**

Run: `uv run pytest tests/unit/test_destination_dispatch.py -v`
Expected: the four new `test_delta_*` tests FAIL because the `delta` branch doesn't exist (likely a `ValueError: Unsupported target.destination`); `test_unknown_destination_raises_value_error` FAILS because the error string still says `Verified destinations: duckdb, ducklake.`. All previously-passing tests still pass.

- [ ] **Step 3: Add the `delta` branch and update the error message**

Edit `src/das_cli/pipelines/load.py`. Replace:

```python
    if name == "ducklake":
        catalog = creds.get("catalog")
        if isinstance(catalog, str) and "://" not in catalog:
            creds = {**creds, "catalog": f"duckdb:///{catalog}"}
        # dlt's ducklake factory accepts a dict at runtime and converts to
        # DuckLakeCredentials via dlt's spec machinery; the static type only
        # advertises DuckLakeCredentials | None.
        return dlt.destinations.ducklake(
            credentials=creds,  # type: ignore[arg-type]
            enable_dataset_name_normalization=False,
        )
    raise ValueError(
        f"Unsupported target.destination: {name!r}. Verified destinations: duckdb, ducklake."
    )
```

with:

```python
    if name == "ducklake":
        catalog = creds.get("catalog")
        if isinstance(catalog, str) and "://" not in catalog:
            creds = {**creds, "catalog": f"duckdb:///{catalog}"}
        # dlt's ducklake factory accepts a dict at runtime and converts to
        # DuckLakeCredentials via dlt's spec machinery; the static type only
        # advertises DuckLakeCredentials | None.
        return dlt.destinations.ducklake(
            credentials=creds,  # type: ignore[arg-type]
            enable_dataset_name_normalization=False,
        )
    if name == "delta":
        # See ADR-0017: delta is an alias for filesystem; table_format is per-resource.
        bucket_url = creds.get("bucket_url", "./das_delta")
        return dlt.destinations.filesystem(
            bucket_url=bucket_url,
            enable_dataset_name_normalization=False,
        )
    raise ValueError(
        f"Unsupported target.destination: {name!r}. "
        f"Verified destinations: duckdb, ducklake, delta."
    )
```

- [ ] **Step 4: Run the unit tests to verify they pass**

Run: `uv run pytest tests/unit/test_destination_dispatch.py -v`
Expected: all tests PASS, including the four new `test_delta_*` tests and the updated `test_unknown_destination_raises_value_error`.

- [ ] **Step 5: Plumb `table_format` through `_build_load_resource` and `run_load`**

This is the per-resource table-format wiring. Edit `src/das_cli/pipelines/load.py`.

In `_build_load_resource`, add `table_format: str | None = None` to the signature and forward it into the `@dlt.resource(...)` decorator. The function currently looks like:

```python
def _build_load_resource(
    contract: LoadedContract,
    *,
    landing_dir: Path,
    hash_exclude: set[str],
    primary_key: list[str],
    pipeline: dlt.Pipeline,
    dataset: str,
    schema_contract: dict[str, str],
    progress_handle: ProgressHandle | None = None,
) -> Any:
    cols = build_dlt_columns(contract.contract)
    table_name: str = contract.contract.primary_schema.physicalName or contract.resource_name

    @dlt.resource(  # type: ignore[misc,call-overload,untyped-decorator]
        name=table_name,
        write_disposition="append",
        primary_key=primary_key or None,
        columns=cols,
        schema_contract=schema_contract,
    )
    def _gen() -> Iterator[dict[str, Any]]:
```

Change it to:

```python
def _build_load_resource(
    contract: LoadedContract,
    *,
    landing_dir: Path,
    hash_exclude: set[str],
    primary_key: list[str],
    pipeline: dlt.Pipeline,
    dataset: str,
    schema_contract: dict[str, str],
    table_format: str | None = None,
    progress_handle: ProgressHandle | None = None,
) -> Any:
    cols = build_dlt_columns(contract.contract)
    table_name: str = contract.contract.primary_schema.physicalName or contract.resource_name

    # See ADR-0017: table_format is set per-resource (dlt has no destination-level pin).
    resource_kwargs: dict[str, Any] = {
        "name": table_name,
        "write_disposition": "append",
        "primary_key": primary_key or None,
        "columns": cols,
        "schema_contract": schema_contract,
    }
    if table_format is not None:
        resource_kwargs["table_format"] = table_format

    @dlt.resource(**resource_kwargs)  # type: ignore[misc,call-overload,untyped-decorator]
    def _gen() -> Iterator[dict[str, Any]]:
```

In `run_load`, compute `table_format` from `cfg.target.destination` once and pass it through to every `_build_load_resource` call. Find the existing call site (around line 273):

```python
            res = _build_load_resource(
                c,
                landing_dir=landing_root / src.name / c.resource_name,
                hash_exclude=hash_exclude,
                primary_key=primary_keys_for(c.contract),
                pipeline=pipeline,
                dataset=dataset,
                schema_contract=schema_contract,
                progress_handle=progress_handle,
            )
```

Replace with:

```python
            res = _build_load_resource(
                c,
                landing_dir=landing_root / src.name / c.resource_name,
                hash_exclude=hash_exclude,
                primary_key=primary_keys_for(c.contract),
                pipeline=pipeline,
                dataset=dataset,
                schema_contract=schema_contract,
                table_format=table_format,
                progress_handle=progress_handle,
            )
```

And immediately above the `resources: list[Any] = []` block (just before the `for src in sources:` loop), compute the table format once:

```python
    # See ADR-0017: per-destination table format. Currently only delta sets a value.
    table_format: str | None = "delta" if cfg.target.destination == "delta" else None
```

- [ ] **Step 6: Run the full unit test suite to verify no regressions**

Run: `uv run pytest tests/unit -v`
Expected: all unit tests pass. The plumbing change in `_build_load_resource` is exercised by the existing duckdb/ducklake unit tests (which pass `table_format=None` by default) and will be covered end-to-end by Task 4's integration tests.

- [ ] **Step 7: Run the full integration suite to verify no regressions**

Run: `uv run pytest tests/integration -v`
Expected: existing duckdb and ducklake integration tests still pass. The added optional kwarg defaults to `None`, so existing call paths are unchanged.

- [ ] **Step 8: Commit**

```bash
git add src/das_cli/pipelines/load.py tests/unit/test_destination_dispatch.py
git commit -m "feat(load): dispatch delta destination + per-resource table_format

target.destination=delta now constructs dlt.destinations.filesystem and
plumbs table_format='delta' through _build_load_resource. dlt 1.26 has
no default_table_format on the filesystem factory; per-resource is the
only mechanism. See ADR-0017."
```

---

## Task 3: Add `delta_workspace` fixture and `delta_reader_pipeline` helper

**Files:**
- Modify: `tests/conftest.py`

- [ ] **Step 1: Add the `delta_workspace` fixture**

In `tests/conftest.py`, after the existing `ducklake_workspace` fixture (line 69), insert:

```python
@pytest.fixture()
def delta_workspace(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[Path]:
    """A das workspace targeting a local Delta destination. Same shape as `workspace`."""
    bucket_url = tmp_path / "das_delta"
    landing = tmp_path / "landing"
    monkeypatch.setenv("DAS_LANDING_URL", str(landing))
    monkeypatch.chdir(tmp_path)
    (tmp_path / "das.yaml").write_text(
        f"""\
target:
  destination: delta
  credentials:
    bucket_url: {bucket_url}

landing:
  bucket_url: "{{{{ env_var('DAS_LANDING_URL', './landing') }}}}"
  credentials: {{}}

contracts:
  root: ./contracts

dataset:
  prefix: das

defaults:
  write_disposition: append
  change_detection: row_hash
  schema_contract:
    tables: evolve
    columns: freeze
    data_type: freeze
"""
    )
    yield tmp_path
```

- [ ] **Step 2: Add the `delta_reader_pipeline` helper**

In `tests/conftest.py`, after the existing `ducklake_reader_pipeline` helper (line 95), insert:

```python
def delta_reader_pipeline(workspace: Path) -> dlt.Pipeline:
    """A reader dlt pipeline pointed at the workspace's Delta tables.

    Unlike DuckLake (where the catalog drives table discovery), dlt's
    filesystem `sql_client()` discovers tables from the pipeline's stored
    schema state. The reader therefore must share `pipeline_name` and
    `pipelines_dir` with the writer (`das_load` / `.dlt/pipelines`, see
    `pipelines/load.py:run_load`). It is read-only — only `sql_client()`
    is used — so no writer-state collision occurs. See ADR-0017.
    """
    import dlt

    return dlt.pipeline(
        pipeline_name="das_load",
        destination=dlt.destinations.filesystem(
            bucket_url=str(workspace / "das_delta"),
            enable_dataset_name_normalization=False,
        ),
        pipelines_dir=str(workspace / ".dlt" / "pipelines"),
    )
```

- [ ] **Step 3: Verify the conftest still imports cleanly**

Run: `uv run pytest tests/conftest.py --collect-only`
Expected: collection completes without errors. (No tests to collect; this confirms the file imports.)

Then run: `uv run pytest tests/unit -v`
Expected: all unit tests still pass — the new fixture/helper is additive and doesn't affect existing tests.

- [ ] **Step 4: Commit**

```bash
git add tests/conftest.py
git commit -m "test: add delta_workspace fixture and delta_reader_pipeline helper"
```

---

## Task 4: TDD integration tests for Delta load

**Files:**
- Create: `tests/integration/test_load_pipeline_delta.py`

This task is the real proof that change detection round-trips through filesystem's DuckDB-backed `sql_client()` on Delta tables. The first test verifies a Delta table is created on the initial load; the second verifies the missing-table exception path; the third verifies A→B→A.

If `test_delta_change_detection_suppresses_duplicate` fails because the missing-table query raises an exception class other than `DatabaseUndefinedRelation`, STOP and consult the user. The fix is either to widen the catch in `change_detection.py` (a small contained change) or to revisit ADR-0017's Decision C.

- [ ] **Step 1: Write the failing integration test file**

Create `tests/integration/test_load_pipeline_delta.py`:

```python
"""Integration tests for the Delta destination. See ADR-0017."""

from __future__ import annotations

import gzip
import json
from pathlib import Path

import pytest
from typer.testing import CliRunner

from das_cli.cli import app
from tests.conftest import delta_reader_pipeline

CONTRACT = """\
apiVersion: v3.0.0
kind: DataContract
id: x.products
name: Products
version: 0.1.0
status: draft
info: { title: Products, owner: x }
schema:
  - name: products
    physicalName: products
    physicalType: table
    properties:
      - name: product_id
        physicalName: ProductId
        logicalType: integer
        physicalType: bigint
        required: true
        primaryKey: true
      - { name: name, physicalName: Name, logicalType: string, required: true }
"""

SOURCE_YML = """\
type: odata
endpoint: https://example.com/odata/v1
spec:
  kind: odata
  metadata_url: https://example.com/odata/v1/$metadata
auth: { type: none }
"""


@pytest.fixture()
def delta_workspace_with_contract(delta_workspace: Path) -> Path:
    """`delta_workspace` plus a source `x` with a single `products` contract."""
    src_dir = delta_workspace / "contracts" / "x"
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(SOURCE_YML)
    (src_dir / "products.odcs.yaml").write_text(CONTRACT)
    return delta_workspace


def _write_landing(workspace: Path, records: list[dict[str, object]]) -> None:
    landing = workspace / "landing" / "x" / "products"
    landing.mkdir(parents=True, exist_ok=True)
    out = landing / "1.jsonl.gz"
    payload = (
        "\n".join(
            json.dumps({"_data": r, "_dlt_load_id": "1700000000", "_dlt_id": f"id-{i}"})
            for i, r in enumerate(records)
        )
        + "\n"
    )
    with gzip.open(out, "wt") as f:
        f.write(payload)


def _delta_count(workspace: Path, table: str) -> int:
    """Count rows in das__x.<table> via a reader pipeline pointed at the same Delta storage."""
    pipeline = delta_reader_pipeline(workspace)
    with pipeline.sql_client() as c:
        rows = c.execute_sql(f'SELECT COUNT(*) FROM "das__x".{table}')
        assert rows is not None
        return int(rows[0][0])


def test_delta_load_creates_table_with_contract_schema(
    delta_workspace_with_contract: Path, cli_runner: CliRunner
) -> None:
    workspace = delta_workspace_with_contract
    _write_landing(workspace, [{"ProductId": 1, "Name": "A"}, {"ProductId": 2, "Name": "B"}])

    result = cli_runner.invoke(app, ["load", "x"])
    assert result.exit_code == 0, result.output
    assert _delta_count(workspace, "products") == 2


def test_delta_change_detection_suppresses_duplicate(
    delta_workspace_with_contract: Path, cli_runner: CliRunner
) -> None:
    """Two cycles with identical landing should append zero rows the second time."""
    workspace = delta_workspace_with_contract
    _write_landing(workspace, [{"ProductId": 1, "Name": "A"}])

    first = cli_runner.invoke(app, ["load", "x"])
    assert first.exit_code == 0, first.output

    second = cli_runner.invoke(app, ["load", "x"])
    assert second.exit_code == 0, second.output

    assert _delta_count(workspace, "products") == 1


def test_delta_a_b_a_preserved(
    delta_workspace_with_contract: Path, cli_runner: CliRunner
) -> None:
    """A → B → A produces three rows; change detection only suppresses no-ops."""
    workspace = delta_workspace_with_contract

    _write_landing(workspace, [{"ProductId": 1, "Name": "A"}])
    first = cli_runner.invoke(app, ["load", "x"])
    assert first.exit_code == 0, first.output

    landing = workspace / "landing" / "x" / "products"
    for f in landing.glob("*"):
        f.unlink()
    _write_landing(workspace, [{"ProductId": 1, "Name": "B"}])
    second = cli_runner.invoke(app, ["load", "x"])
    assert second.exit_code == 0, second.output

    for f in landing.glob("*"):
        f.unlink()
    _write_landing(workspace, [{"ProductId": 1, "Name": "A"}])
    third = cli_runner.invoke(app, ["load", "x"])
    assert third.exit_code == 0, third.output

    assert _delta_count(workspace, "products") == 3
```

- [ ] **Step 2: Run the new tests to verify they fail or pass appropriately**

Run: `uv run pytest tests/integration/test_load_pipeline_delta.py -v`
Expected: ALL THREE tests should PASS — the dispatch and reader infrastructure are already in place. If `test_delta_load_creates_table_with_contract_schema` fails, the failure mode is the diagnostic — investigate whether dlt is actually writing Delta tables under `das_delta/das__x/products/`.

If `test_delta_change_detection_suppresses_duplicate` fails with a row count of 2 (rather than 1), the missing-table exception class on filesystem+Delta differs from `DatabaseUndefinedRelation`. STOP and consult the user before patching `change_detection.py`.

- [ ] **Step 3: Run the full integration suite to confirm no regressions**

Run: `uv run pytest tests/integration -v`
Expected: all integration tests pass, including the three new Delta tests and the existing ducklake/duckdb tests.

- [ ] **Step 4: Commit**

```bash
git add tests/integration/test_load_pipeline_delta.py
git commit -m "test(integration): verify delta destination load + change detection

Mirrors the ducklake integration test set: initial load, two-cycle
change detection (proves load_latest_hash works through filesystem's
DuckDB-backed sql_client over delta_scan), and A→B→A preservation."
```

---

## Task 5: TDD doctor branch + integration tests

**Files:**
- Modify: `src/das_cli/doctor.py:32-41`
- Modify: `tests/integration/test_cli_doctor.py`

- [ ] **Step 1: Write the failing doctor tests**

Append to `tests/integration/test_cli_doctor.py`:

```python
def test_doctor_passes_clean_delta_workspace(
    delta_workspace: Path, cli_runner: CliRunner
) -> None:
    # The fixture writes a complete das.yaml; doctor should pass it.
    result = cli_runner.invoke(app, ["doctor"])
    assert result.exit_code == 0, result.output


def test_doctor_flags_delta_missing_bucket_url(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, cli_runner: CliRunner
) -> None:
    monkeypatch.chdir(tmp_path)
    (tmp_path / "das.yaml").write_text(
        """\
target:
  destination: delta
  credentials: {}

landing:
  bucket_url: ./landing
  credentials: {}

contracts:
  root: ./contracts
"""
    )
    (tmp_path / "contracts").mkdir()
    result = cli_runner.invoke(app, ["doctor"])
    assert result.exit_code == 4
    assert "credentials.bucket_url" in result.output
```

- [ ] **Step 2: Run the new tests to verify they fail**

Run: `uv run pytest tests/integration/test_cli_doctor.py::test_doctor_flags_delta_missing_bucket_url -v`
Expected: FAILS — currently doctor doesn't know about the `delta` destination, so it silently accepts an empty credentials dict; the test expects exit_code 4 and the missing-key message.

`test_doctor_passes_clean_delta_workspace` may already pass (doctor doesn't validate when destination is unknown), but assert it directly.

- [ ] **Step 3: Add the `delta` branch to doctor**

Edit `src/das_cli/doctor.py`. Replace:

```python
    elif cfg.target.destination == "ducklake":
        creds = cfg.target.credentials
        if not creds.get("catalog"):
            issues.append(DoctorIssue("target", "ducklake destination missing credentials.catalog"))
        if not creds.get("storage"):
            issues.append(DoctorIssue("target", "ducklake destination missing credentials.storage"))
```

with:

```python
    elif cfg.target.destination == "ducklake":
        creds = cfg.target.credentials
        if not creds.get("catalog"):
            issues.append(DoctorIssue("target", "ducklake destination missing credentials.catalog"))
        if not creds.get("storage"):
            issues.append(DoctorIssue("target", "ducklake destination missing credentials.storage"))
    elif cfg.target.destination == "delta":
        # See ADR-0017.
        if not cfg.target.credentials.get("bucket_url"):
            issues.append(
                DoctorIssue("target", "delta destination missing credentials.bucket_url")
            )
```

- [ ] **Step 4: Run the doctor tests to verify they pass**

Run: `uv run pytest tests/integration/test_cli_doctor.py -v`
Expected: all doctor tests pass, including the two new Delta tests.

- [ ] **Step 5: Commit**

```bash
git add src/das_cli/doctor.py tests/integration/test_cli_doctor.py
git commit -m "feat(doctor): flag delta destination missing bucket_url

Mirror the existing ducklake credential check. See ADR-0017."
```

---

## Task 6: e2e test — AdventureWorks (OData) on Delta

**Files:**
- Create: `tests/e2e/test_adventureworks_delta.py`

- [ ] **Step 1: Write the e2e test**

Note: `tests/e2e/conftest.py` auto-applies the `e2e` marker to every test under `tests/e2e/` via `pytest_collection_modifyitems`. Do NOT add an explicit `@pytest.mark.e2e` decorator — match the existing ducklake e2e style.

Create `tests/e2e/test_adventureworks_delta.py`:

```python
from pathlib import Path

from typer.testing import CliRunner

from das_cli.cli import app
from tests.conftest import delta_reader_pipeline


def test_adventureworks_delta_bootstrap_extract_load(
    delta_workspace: Path, cli_runner: CliRunner
) -> None:
    # Note: NO `cli_runner.invoke(app, ["init"])` — delta_workspace already
    # writes a custom das.yaml. `init` would overwrite it without --force.
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "adventureworks",
            "--type",
            "odata",
            "--url",
            "https://demodata.grapecity.com/adventureworks/odata/v1",
        ],
    )

    bootstrap = cli_runner.invoke(
        app,
        ["contract", "bootstrap", "adventureworks", "--only", "products"],
    )
    assert bootstrap.exit_code == 0, bootstrap.stdout + bootstrap.stderr
    products_contract = delta_workspace / "contracts" / "adventureworks" / "products.odcs.yaml"
    assert products_contract.is_file()

    extract = cli_runner.invoke(
        app,
        ["extract", "adventureworks", "--resource", "products", "--limit", "10"],
    )
    assert extract.exit_code == 0, extract.stdout + extract.stderr

    landing = delta_workspace / "landing" / "adventureworks" / "products"
    assert any(landing.rglob("*.jsonl*"))

    load = cli_runner.invoke(app, ["load", "adventureworks", "--resource", "products"])
    assert load.exit_code == 0, load.stdout + load.stderr

    pipeline = delta_reader_pipeline(delta_workspace)
    with pipeline.sql_client() as c:
        rows = c.execute_sql('SELECT COUNT(*) FROM "das__adventureworks".products')
        assert rows is not None
        count = rows[0][0]
        assert count >= 1, "expected at least one product row"
        rows = c.execute_sql(
            'SELECT COUNT(*) FROM "das__adventureworks".products '
            "WHERE _extracted_at IS NULL OR _extracted_on IS NULL "
            "OR _loaded_at IS NULL OR _loaded_on IS NULL"
        )
        assert rows is not None
        nulls = rows[0][0]
        assert nulls == 0, "metadata columns must be NOT NULL"
```

- [ ] **Step 2: Run the e2e test to verify it passes**

Run: `uv run pytest tests/e2e/test_adventureworks_delta.py -v -m e2e`
Expected: PASS. The test hits a real public OData endpoint; if the endpoint is down the test will fail with a network error, which is a known acceptable failure mode (the matching ducklake e2e has the same behavior).

- [ ] **Step 3: Commit**

```bash
git add tests/e2e/test_adventureworks_delta.py
git commit -m "test(e2e): adventureworks bootstrap → extract → load on delta"
```

---

## Task 7: e2e test — Northwind (OpenAPI) on Delta

**Files:**
- Create: `tests/e2e/test_northwind_delta.py`

- [ ] **Step 1: Write the e2e test**

Reminder: the `e2e` marker is auto-applied by `tests/e2e/conftest.py`. Do NOT add an explicit `@pytest.mark.e2e` decorator.

Create `tests/e2e/test_northwind_delta.py`:

```python
from pathlib import Path

import yaml as _yaml
from typer.testing import CliRunner

from das_cli.cli import app
from tests.conftest import delta_reader_pipeline


def test_northwind_delta_bootstrap_extract_load(
    delta_workspace: Path, cli_runner: CliRunner
) -> None:
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "northwind",
            "--type",
            "openapi",
            "--url",
            "https://demodata.grapecity.com/northwind/api/v1",
        ],
    )

    # Same swagger override the DuckDB Northwind test does.
    src = delta_workspace / "contracts" / "northwind" / "_source.yml"
    text = src.read_text().replace(
        "swagger.json",
        "../../docs/NorthWind/v1/restful_swagger.json",
    )
    text = text.replace(
        "https://demodata.grapecity.com/northwind/api/v1/../../docs/NorthWind/v1/restful_swagger.json",
        "https://demodata.grapecity.com/docs/NorthWind/v1/restful_swagger.json",
    )
    src.write_text(text)

    bootstrap = cli_runner.invoke(
        app,
        ["contract", "bootstrap", "northwind", "--only", "customer_dtos"],
    )
    assert bootstrap.exit_code == 0, bootstrap.stdout + bootstrap.stderr
    cust_contract = delta_workspace / "contracts" / "northwind" / "customer_dtos.odcs.yaml"
    assert cust_contract.is_file()

    cust_data = _yaml.safe_load(cust_contract.read_text())
    cps = cust_data.get("customProperties") or []
    endpoint = next((p for p in cps if p["property"] == "das.endpoint"), None)
    assert endpoint is not None, "bootstrap should have emitted das.endpoint for CustomerDto"
    assert endpoint["value"]["path"] == "/Customers", endpoint["value"]["path"]

    extract = cli_runner.invoke(
        app,
        ["extract", "northwind", "--resource", "customer_dtos", "--limit", "5"],
    )
    assert extract.exit_code == 0, extract.stdout + extract.stderr

    load = cli_runner.invoke(app, ["load", "northwind", "--resource", "customer_dtos"])
    assert load.exit_code == 0, load.stdout + load.stderr

    pipeline = delta_reader_pipeline(delta_workspace)
    with pipeline.sql_client() as c:
        rows = c.execute_sql('SELECT COUNT(*) FROM "das__northwind".customer_dtos')
        assert rows is not None
        count = rows[0][0]
        assert count >= 1
        rows = c.execute_sql(
            'SELECT COUNT(*) FROM "das__northwind".customer_dtos '
            "WHERE _extracted_at IS NULL OR _extracted_on IS NULL "
            "OR _loaded_at IS NULL OR _loaded_on IS NULL"
        )
        assert rows is not None
        nulls = rows[0][0]
        assert nulls == 0, "metadata columns must be NOT NULL"
```

- [ ] **Step 2: Run the e2e test**

Run: `uv run pytest tests/e2e/test_northwind_delta.py -v -m e2e`
Expected: PASS.

- [ ] **Step 3: Commit**

```bash
git add tests/e2e/test_northwind_delta.py
git commit -m "test(e2e): northwind bootstrap → extract → load on delta"
```

---

## Task 8: Author ADR-0017 and update the index

**Files:**
- Create: `docs/adrs/0017-delta-destination-via-filesystem-alias.md`
- Modify: `docs/adrs/README.md:25-26`

- [ ] **Step 1: Write ADR-0017**

Create `docs/adrs/0017-delta-destination-via-filesystem-alias.md`:

```markdown
# 0017. Delta destination via filesystem alias

- **Status:** Accepted
- **Date:** 2026-05-08
- **Deciders:** mattiasthalen

## Context

ADR-0016 set up destination dispatch in `_build_destination` and pipeline-driven
reads through `pipeline.sql_client()`. DuckLake was the first non-DuckDB
destination verified under that pattern. Delta is the next.

In dlt 1.x, Delta is not its own destination — it is a `table_format` on
`dlt.destinations.filesystem(...)`. Naming it `filesystem` in `das.yaml` would
be honest about dlt's structure but blur what is verified: Parquet-on-filesystem
is not in scope here. Naming it `delta` keeps the verified contract narrow.

The change-detection read path adds a new contract surface. dlt's filesystem
`sql_client()` is a DuckDB-backed in-memory client that reads Delta tables via
`delta_scan`. This is structurally different from DuckDB and DuckLake's native
SQL clients — ADR-0016's "any destination with sql_client" claim extends to it,
but this ADR records the fact explicitly.

## Decision

**Decision A: das-cli's `target.destination: delta` is an alias for
`dlt.destinations.filesystem(bucket_url=..., enable_dataset_name_normalization=False)`,
combined with a per-resource `table_format="delta"` set inside
`_build_load_resource`.** The alias is owned by `_build_destination`; users
do not see "filesystem" in `das.yaml` for this verified slice. `bucket_url`
is forwarded verbatim — no auto-prefix, since a bare path is a valid
filesystem path. Default `bucket_url` is `./das_delta` when omitted,
mirroring the duckdb destination's `./das.duckdb` default.

**Decision B: Table format is set per-resource via a new optional
`table_format` kwarg on `_build_load_resource`, plumbed from
`cfg.target.destination` in `run_load`.** dlt 1.26 does not expose a
`default_table_format` kwarg on the filesystem destination factory — the
kwarg is silently dropped. Per-resource is the only mechanism dlt provides.
The coupling introduced into `_build_load_resource` is a single string
kwarg with a `None` default; the function still doesn't know about
destinations specifically — it forwards a string into `@dlt.resource(...)`.

**Decision C: change detection continues to read through `pipeline.sql_client()`.**
For the filesystem destination this is a DuckDB-backed in-memory SQL client that
reads Delta tables via `delta_scan`. This extends ADR-0016's contract surface
to filesystem-style sql_clients — the implementation is verified to satisfy the
same `DatabaseUndefinedRelation` exception contract for the missing-table path.

## Alternatives considered

- **`destination: filesystem` + `table_format: delta`.** Rejected: exposes a
  knob whose Parquet branch is unverified; the user-facing name should reflect
  what das-cli has actually tested.
- **Destination-level `default_table_format` via dlt's filesystem factory.**
  Preferred design; rejected because dlt 1.26's filesystem factory does not
  accept that kwarg (silently dropped). Forced the per-resource approach in
  Decision B.
- **Adding both `delta` and `filesystem` as separate dispatch branches.**
  Rejected: premature. Verify Parquet-on-filesystem when there is a use case;
  give it its own dispatch branch and matrix row at that point.

## Consequences

- Adding Delta is one branch in `_build_destination` plus a `dlt[deltalake]`
  extra in `pyproject.toml`, matching the cost of the DuckLake addition.
- dlt's filesystem `sql_client()` is now a contract surface alongside ADR-0016's
  general claim. A future filesystem-based destination with a different
  SQL-client path (e.g., a DataFusion-backed Delta reader) would need to satisfy
  the same exception contract or revisit this ADR.
- The `delta` alias locks users out of Parquet-on-filesystem under that name.
  That is intentional — the alias names what is verified.
- Cloud-backed Delta (S3/GCS/Azure) is out of scope. `bucket_url` accepts
  cloud URLs in dlt's filesystem destination, but das-cli has not verified
  authentication, retry, or eventual-consistency behavior in those modes.
```

- [ ] **Step 2: Append the ADR to the index**

Edit `docs/adrs/README.md`. Append after line 25 (the existing 0016 row):

```markdown
| 0017 | Delta destination via filesystem alias | Accepted |
```

The full bottom of the table now reads:

```markdown
| 0016 | Destination dispatch and pipeline-driven reads | Accepted |
| 0017 | Delta destination via filesystem alias | Accepted |
```

- [ ] **Step 3: Verify the index entry matches the ADR title verbatim**

Run: `head -1 docs/adrs/0017-delta-destination-via-filesystem-alias.md`
Expected: `# 0017. Delta destination via filesystem alias`

The `Title` column in `docs/adrs/README.md` row must equal `Delta destination via filesystem alias` (matches the part of the heading after `# 0017.`). Per CLAUDE.md, this is verified by reading and comparing.

Run: `head -1 docs/adrs/0*.md`
Expected: each line begins with `==> docs/adrs/0NNN-...md <==` followed by the heading. Confirm 0001–0017 are all present and match the index rows.

- [ ] **Step 4: Commit**

```bash
git add docs/adrs/0017-delta-destination-via-filesystem-alias.md docs/adrs/README.md
git commit -m "docs(adr): ADR-0017 delta destination via filesystem alias"
```

---

## Task 9: Update README

**Files:**
- Modify: `README.md:12-13`
- Modify: `README.md:88-95`

- [ ] **Step 1: Update the "What it is" lead**

Edit `README.md`. Replace lines 12-13:

```markdown
das-cli lands raw source data into a compressed JSONL landing zone, then
promotes it into a contract-enforced warehouse (DuckDB or DuckLake). ODCS v3
```

with:

```markdown
das-cli lands raw source data into a compressed JSONL landing zone, then
promotes it into a contract-enforced warehouse (DuckDB, DuckLake, or Delta).
ODCS v3
```

- [ ] **Step 2: Add the two Delta rows to the Verified matrix**

Edit `README.md`. Replace lines 88-95:

```markdown
### Verified

| Source         | Destination | Notes                                         |
|----------------|-------------|-----------------------------------------------|
| OData v2 / v4  | DuckDB      | OData metadata bootstrap (ADR-0006)           |
| OpenAPI / REST | DuckDB      | Per-resource `das.endpoint` (ADR-0014, 0015)  |
| OData v2 / v4  | DuckLake    | Local DuckDB-file catalog (ADR-0016)          |
| OpenAPI / REST | DuckLake    | Local DuckDB-file catalog (ADR-0016)          |
```

with:

```markdown
### Verified

| Source         | Destination | Notes                                         |
|----------------|-------------|-----------------------------------------------|
| OData v2 / v4  | DuckDB      | OData metadata bootstrap (ADR-0006)           |
| OpenAPI / REST | DuckDB      | Per-resource `das.endpoint` (ADR-0014, 0015)  |
| OData v2 / v4  | DuckLake    | Local DuckDB-file catalog (ADR-0016)          |
| OpenAPI / REST | DuckLake    | Local DuckDB-file catalog (ADR-0016)          |
| OData v2 / v4  | Delta       | Local Delta tables on filesystem (ADR-0017)   |
| OpenAPI / REST | Delta       | Local Delta tables on filesystem (ADR-0017)   |
```

- [ ] **Step 3: Commit**

```bash
git add README.md
git commit -m "docs(readme): list delta in verified destinations matrix"
```

---

## Task 10: Final verification

**Files:**
- None (verification only)

- [ ] **Step 1: Run the full unit + integration test suite**

Run: `uv run pytest tests/unit tests/integration -v`
Expected: all tests pass. No regressions from the existing duckdb/ducklake tests; new delta tests all green.

- [ ] **Step 2: Run the e2e suite**

Run: `uv run pytest tests/e2e -v -m e2e`
Expected: all e2e tests pass (4 ducklake, 4 duckdb, 2 new delta — exact count depends on existing baseline).

If a non-delta e2e test fails, that's pre-existing flake (network-dependent), not a regression introduced by this work; note it in the commit message of any subsequent fix but do NOT mark this task complete until the new delta e2e tests are green.

- [ ] **Step 3: Run pre-commit checks**

Run: `uv run pre-commit run --all-files`
Expected: ruff, mypy, and any other configured hooks pass cleanly.

If mypy reports errors in the new delta code, fix them inline. The most likely category is the dlt typing override already noted in `pyproject.toml:67-75` (`das_cli.pipelines.load`, `tests.conftest`); the new code paths fall under those overrides and should not require new type-ignore comments.

- [ ] **Step 4: Verify backwards compatibility — duckdb workspace**

Run: `uv run pytest tests/integration/test_load_pipeline.py -v`
Expected: existing duckdb tests pass with no changes to behavior.

- [ ] **Step 5: Verify backwards compatibility — ducklake workspace**

Run: `uv run pytest tests/integration/test_load_pipeline_ducklake.py -v`
Expected: existing ducklake tests pass with no changes to behavior.

- [ ] **Step 6: Push the branch**

Run: `git push -u origin claude/brainstorm-issue-29-UNFsq`
Expected: push succeeds; the branch is updated on the remote with all task commits.

---

## Notes for the executing engineer

**Resolved risk: `default_table_format` kwarg.** During execution this risk materialized — dlt 1.26's filesystem factory silently drops the kwarg (verified empirically). Decision B in ADR-0017 was inverted to set `table_format` per-resource via `_build_load_resource`, which is the only mechanism dlt provides. The plan above (Task 2) reflects this corrected design.

**Risk: missing-table exception class differs on filesystem+Delta.** Surfaces as a failed integration test in Task 4 Step 2 — specifically `test_delta_change_detection_suppresses_duplicate` returning a row count of 2 instead of 1, because `load_latest_hash` failed to catch the missing-table case and reported empty hashes. Fix: widen the catch in `src/das_cli/pipelines/change_detection.py` (read it first to find the catch site) to also catch the actual exception class. If the change requires more than adding one exception type to the existing `except` clause, STOP and consult the user — Decision C in ADR-0017 needs revisiting.

**Risk: schema-evolution semantics on Delta diverge from DuckDB.** Surfaces as a failed integration test in Task 4 Step 2 — likely `test_delta_load_creates_table_with_contract_schema` failing during the dlt schema-contract validation step. The contract `tables: evolve, columns: freeze, data_type: freeze` is the v0.1 default; if Delta rejects a shape DuckDB accepts (e.g., a particular `bigint` mapping), the failure surfaces here. STOP and consult the user before changing the contract defaults.

**Granularity reminder.** Each step is a single small action. If a step takes more than ~5 minutes, split it. If a step is "implement X" without code, that is a plan failure — open the spec and the existing DuckLake equivalent and write the code into the plan before implementing.

**Frequency.** Commit at the end of every numbered task, not at the end of the implementation. The plan is structured so each commit leaves the repo in a green-test state.
