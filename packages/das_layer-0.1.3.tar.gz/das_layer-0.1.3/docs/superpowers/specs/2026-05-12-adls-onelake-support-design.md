# ADLS / OneLake support for landing and Delta — design

- **Status:** Draft
- **Date:** 2026-05-12
- **Branch:** `worktree-adls-onelake-support`

## Context

das-cli is built on dlt and has two pipelines (ADR-0002): P1 lands raw JSONL
into `landing.bucket_url`, P2 projects landing rows into the destination
configured under `target:`. ADR-0017 added Delta as the third verified
destination — as an alias for `dlt.destinations.filesystem(...)` with
`table_format="delta"` set per-resource.

ADR-0017 explicitly punted on cloud-backed Delta:

> Cloud-backed Delta (S3/GCS/Azure) is out of scope. `bucket_url` accepts
> cloud URLs in dlt's filesystem destination, but das-cli has not verified
> authentication, retry, or eventual-consistency behavior in those modes.

ADR-0013's landing convention was likewise verified only for local paths;
`extract.py:reset_extract_state` raises `NotImplementedError` for any
`az://`/`s3://`/`gs://` URL, and `load.py:_iter_landing` reads landing
through `pathlib` + `gzip.open` / builtin `open` — local-FS only.

This design lifts the Azure-side of those restrictions for **both** landing
and the Delta target. ADLS Gen2 and OneLake (Fabric) are covered by the same
mechanism: both speak the Azure Blob File System (ABFS) protocol and accept
the same `AZURE_*` credentials. AWS S3 and GCS remain out of scope.

### What changed at the dlt layer since ADR-0017 was written

ADR-0017's caution about cloud-backed Delta was load-bearing: at the time,
dlt issue [#2055][i2055] documented that `DefaultAzureCredential` /
`AzureCliCredential` paths failed when used with `table_format="delta"` on
the filesystem destination, because dlt's bridge into `object_store`'s
`storage_options` passed a `bool` where the Rust side expected a `String`.
Explicit service-principal credentials worked; the default-chain path did
not.

That bug was closed as completed on 2025-01-29. dlt's
`AzureCredentialsBase.to_object_store_rs_credentials()` now resolves the
default credential chain to a bearer token and passes `azure_storage_token`
as a string into storage_options. das-cli's pinned dlt version (1.26.0 in
`uv.lock`) is well past the fix. The combination
`filesystem + table_format="delta" + Azure` now works for both auth paths,
which is what makes this work tractable.

[i2055]: https://github.com/dlt-hub/dlt/issues/2055

### URL shapes

Three URL shapes are in play. das-cli treats all three as opaque ABFS URLs
and forwards them verbatim to dlt — the differences are documented for
users, not branched on in code.

- **Plain ADLS Gen2:**
  `abfss://<container>@<storage_account>.dfs.core.windows.net/<path>`
- **OneLake by GUID** (recommended; dlt-docs hard-recommendation):
  `abfss://<workspace_guid>@onelake.dfs.fabric.microsoft.com/<item_guid>/<path>`
- **OneLake by name** (Microsoft-Learn-documented but dlt-docs less
  emphatic — may fail if names contain spaces or special characters):
  `abfss://<workspace_name>@onelake.dfs.fabric.microsoft.com/<item_name>.lakehouse/<path>`

The `.lakehouse` suffix on the name form is lowercase and mandatory per the
[OneLake URI syntax docs][onelake-uri]. GUID form does not take the suffix.
For OneLake landing/Delta targets, recommend `…/Files/<dir>` for landing
and `…/Tables/` for Delta tables — Fabric's Lakehouse UI auto-discovers
Delta tables under `Tables/`. das-cli does not enforce this layout.

[onelake-uri]: https://learn.microsoft.com/fabric/onelake/onelake-access-api#uri-syntax

## Goals

- `landing.bucket_url` accepts `abfss://` / `abfs://` / `az://` URLs and the
  full P1 round-trip (extract → JSONL into ADLS / OneLake) works.
- `target.destination: delta` with an Azure `bucket_url` works end-to-end:
  Delta tables land on ADLS / OneLake, change detection reads them through
  `pipeline.sql_client()`, P2 second-cycle is a no-op.
- One credentials shape for both landing and target, plumbed through das-cli's
  existing Pydantic config and rendered with the existing
  `{{ env_var(...) }}` Jinja machinery (ADR-0007). Two explicit `auth`
  modes: `service_principal` and `default`.
- `doctor` validates the new credentials shape statically (config-typo
  hygiene, no live probes) and adds a friendly hint if `auth: default` is
  chosen but neither the standard `AZURE_*` env vars nor `az login` look
  reachable.
- `extract.py:reset_extract_state` works against Azure landing.
- An opt-in e2e edge test exercises the full chain (OData source → Azure
  landing → Delta on Azure), gated by the presence of
  `DAS_E2E_AZURE_BUCKET_URL` and the standard `AZURE_*` env vars in `.env`.
- File ADR-0020. Mark ADR-0017's "cloud-backed Delta is out of scope"
  consequence as superseded for Azure specifically (the alias and
  per-resource `table_format` decisions stay intact).

## Non-goals

- AWS S3 and GCS verification. The same `bucket_url` plumbing makes them
  *probably* work — but they are unverified, doctor doesn't validate
  their credentials shapes, and the matrix row stays unchecked.
- Cloud-backed DuckDB or DuckLake catalogs. Out of scope; both destinations
  remain local-filesystem only.
- Managed Identity as a distinct `auth` mode. It is one link in the
  `DefaultAzureCredential` chain and is exercised through `auth: default`
  on machines where MI is the available identity (e.g., an Azure VM).
- A separate `cli` auth mode. `az login` is also a link in the
  `DefaultAzureCredential` chain; `auth: default` covers it.
- New CLI surface. Destinations and landing stay configured in `das.yaml`.
- Cross-tenant scenarios. Each block (`landing` / `target`) is configured
  independently, so a workspace that wants two different accounts can do
  it — but the slice is not specifically verified.
- Migrating local landing → Azure landing in place. New workspaces only.

## Design

### Config surface

`LandingConfig` and `TargetConfig` keep their existing `credentials: dict`
fields — no breaking change. das-cli adds a **typed view** that runs only
when the corresponding `bucket_url` is an Azure URL:

```yaml
# Example: landing on OneLake (GUID form), Delta target on the same lakehouse,
# both authenticated via az CLI / managed identity / env vars.
landing:
  bucket_url: "abfss://aaaaaaaa-…@onelake.dfs.fabric.microsoft.com/bbbbbbbb-…/Files/landing"
  credentials:
    auth: default

target:
  destination: delta
  credentials:
    bucket_url: "abfss://aaaaaaaa-…@onelake.dfs.fabric.microsoft.com/bbbbbbbb-…/Tables"
    auth: default
```

Or with an explicit service principal — values templated from the standard
Azure SDK env-var names (which are also the names the Rust `object_store`
crate reads, so a single `.env` works for both Python and Rust sides):

```yaml
landing:
  bucket_url: "abfss://lake@<account>.dfs.core.windows.net/landing"
  credentials:
    auth: service_principal
    tenant_id: "{{ env_var('AZURE_TENANT_ID') }}"
    client_id: "{{ env_var('AZURE_CLIENT_ID') }}"
    client_secret: "{{ env_var('AZURE_CLIENT_SECRET') }}"

target:
  destination: delta
  credentials:
    bucket_url: "abfss://lake@<account>.dfs.core.windows.net/warehouse"
    auth: service_principal
    tenant_id: "{{ env_var('AZURE_TENANT_ID') }}"
    client_id: "{{ env_var('AZURE_CLIENT_ID') }}"
    client_secret: "{{ env_var('AZURE_CLIENT_SECRET') }}"
```

Notes:

- **Two auth modes only**: `service_principal` and `default`. `default`
  invokes `DefaultAzureCredential`, which already chains env-var SP →
  managed identity → az CLI → developer Azure tools. A distinct `cli`
  mode would just be a slower-named alias for the same code path.
- `account_name` is *not* a config field. dlt infers it from the URL
  host, and that inference matches both Microsoft and adlfs conventions.
- **`auth` is required when the `bucket_url` is Azure.** No implicit
  default. An empty `credentials` block on an Azure URL is a validation
  error (caught at config-load time and surfaced by `doctor`). This
  keeps the parse rule total: Azure URL → must produce an
  `AzureCredentials` instance.
- For non-Azure URLs (`file://`, bare local paths), `credentials` stays
  empty and no new validation runs. Pre-existing local-path setups are
  untouched.

### Pydantic typing

A new `AzureCredentials` model with a discriminated `auth` field. Lives in
`src/das_cli/models/das_yaml.py`:

```python
from typing import Annotated, Literal, Union
from pydantic import BaseModel, ConfigDict, Discriminator, Field


class AzureServicePrincipalAuth(BaseModel):
    model_config = ConfigDict(extra="forbid")
    auth: Literal["service_principal"]
    tenant_id: str
    client_id: str
    client_secret: str


class AzureDefaultAuth(BaseModel):
    model_config = ConfigDict(extra="forbid")
    auth: Literal["default"]


AzureCredentials = Annotated[
    Union[AzureServicePrincipalAuth, AzureDefaultAuth],
    Discriminator("auth"),
]
```

`LandingConfig.credentials` and `TargetConfig.credentials` stay as
`dict[str, Any]` (no breaking change for existing duckdb / ducklake / delta
configs). A new helper `_parse_azure_credentials(creds: dict, bucket_url:
str) -> AzureCredentials | None` returns `None` when the URL is not Azure,
or an `AzureCredentials` instance otherwise. Empty `creds` on an Azure
URL raises `ValidationError` (missing discriminator) — the call site
either lets it propagate (for `doctor`, which formats and surfaces it)
or wraps it in a friendlier message at pipeline-construction time. This
keeps the typing local to the Azure path.

The `bucket_url`-is-Azure test is `bucket_url.startswith(("az://",
"abfs://", "abfss://"))`. A small `is_azure_url(url: str) -> bool` helper
lives next to the parser; it's used by all the dispatch sites below.

### Building dlt credentials

A new module `src/das_cli/dlt_glue/azure_credentials.py` translates
das-cli's `AzureCredentials` model into dlt's typed credential objects:

```python
from dlt.common.configuration.specs import (
    AzureCredentials as DltAzureCredentials,
    AzureServicePrincipalCredentialsWithoutDefaults,
)


def build_dlt_azure_credentials(creds: AzureCredentials) -> object:
    if isinstance(creds, AzureServicePrincipalAuth):
        return AzureServicePrincipalCredentialsWithoutDefaults(
            tenant_id=creds.tenant_id,
            azure_client_id=creds.client_id,
            azure_client_secret=creds.client_secret,
        )
    # AzureDefaultAuth — DefaultAzureCredential chain.
    return DltAzureCredentials()
```

das-cli does **not** set `azure_storage_account_name` — dlt infers it from
the `bucket_url`'s host. (Verified by reading
`dlt/common/configuration/specs/azure_credentials.py` in dlt 1.26.0.)

### Destination dispatch (`pipelines/load.py`)

The `delta` branch of `_build_destination` gains one conditional:

```python
if name == "delta":
    bucket_url = creds.get("bucket_url", "./das_delta")
    azure = _parse_azure_credentials(creds, bucket_url)
    dlt_creds = build_dlt_azure_credentials(azure) if azure else None
    return dlt.destinations.filesystem(
        bucket_url=bucket_url,
        credentials=dlt_creds,
        enable_dataset_name_normalization=False,
    )
```

No table-format changes. The per-resource `table_format="delta"`
plumbing from ADR-0017 carries through unchanged. dlt's `AzureCredentials`
class internally produces `azure_storage_token` for the Rust `object_store`
storage_options, so the Delta writer authenticates via the same credentials
object.

### Landing extract (`pipelines/extract.py`)

Same pattern, against `cfg.landing.credentials`:

```python
azure = _parse_azure_credentials(cfg.landing.credentials, cfg.landing.bucket_url)
dlt_creds = build_dlt_azure_credentials(azure) if azure else (cfg.landing.credentials or None)

pipeline = dlt.pipeline(
    pipeline_name=f"das_extract__{source_name}",
    destination=dlt.destinations.filesystem(
        bucket_url=bucket_url,
        credentials=dlt_creds,
        layout="{table_name}/_extracted_on={curr_date}/{load_id}.{file_id}.{ext}",
    ),
    ...
)
```

The existing `credentials=cfg.landing.credentials or None` already accepts
a raw dict; we replace the dict with a typed credentials object when the
URL is Azure. Local-path behavior is unchanged.

### Landing reads (P2 and post-extract row counts)

Today's `_iter_landing` and `count_landing_rows` in both `extract.py` and
`load.py` open files via `pathlib` + `gzip.open` / builtin `open`. That
path is local-FS only.

Replace it with an fsspec-backed reader. dlt already pulls fsspec and
adlfs transitively (`dlt[filesystem]` extras). One helper:

```python
# src/das_cli/dlt_glue/landing_fs.py
import gzip
from collections.abc import Iterator
from typing import Any

import fsspec

from das_cli.models.das_yaml import LandingConfig
from das_cli.dlt_glue.azure_credentials import build_dlt_azure_credentials, is_azure_url
from das_cli.models.das_yaml import _parse_azure_credentials


def landing_fs(landing: LandingConfig) -> tuple[fsspec.AbstractFileSystem, str]:
    """Return (filesystem, root_path) for reading landing files.

    For local paths, returns (LocalFileSystem, absolute_path).
    For Azure URLs, returns (AzureBlobFileSystem, normalised_path).
    """
    url = landing.bucket_url
    if is_azure_url(url):
        azure = _parse_azure_credentials(landing.credentials, url)
        opts = _adlfs_storage_options(azure)  # tenant_id / client_id / … or anon=False
        fs, root = fsspec.core.url_to_fs(url, **opts)
        return fs, root
    # Local path.
    fs = fsspec.filesystem("file")
    return fs, str(Path(url).expanduser().resolve())


def iter_landing_records(landing: LandingConfig, *, source: str, resource: str) -> Iterator[dict]:
    fs, root = landing_fs(landing)
    pattern = f"{root}/{source}/{resource}/**/*.jsonl*"
    for path in sorted(fs.glob(pattern)):
        with fs.open(path, "rb") as raw:
            stream = gzip.open(raw, "rt", encoding="utf-8") if path.endswith(".gz") else raw
            for line in stream:
                line = line.strip() if isinstance(line, str) else line.decode("utf-8").strip()
                if not line:
                    continue
                yield json.loads(line)
```

`_iter_landing` and `count_landing_rows` in both `extract.py` and
`load.py` switch to `iter_landing_records` and a sibling
`count_landing_records`. Their function signatures don't change in v0.1
beyond taking a `LandingConfig` (or its components) instead of a `Path`.

`_adlfs_storage_options` maps das-cli's `AzureCredentials` to adlfs's
kwarg names (`tenant_id`, `client_id`, `client_secret`, or empty for
DefaultAzureCredential). Roughly:

```python
def _adlfs_storage_options(creds: AzureCredentials | None) -> dict:
    if creds is None:
        return {}
    if isinstance(creds, AzureServicePrincipalAuth):
        return {
            "tenant_id": creds.tenant_id,
            "client_id": creds.client_id,
            "client_secret": creds.client_secret,
        }
    # Default chain — adlfs picks up env vars / az CLI / MI automatically when
    # no explicit credentials are passed and anon=False.
    return {"anon": False}
```

### `reset_extract_state` on Azure landing (ADR-0019)

`reset_extract_state` deletes three subdirectories under
`<landing>/<source>/`. Replace the `NotImplementedError` for `az://` with
an fsspec-based delete:

```python
fs, root = landing_fs(cfg.landing)
source_landing = f"{root}/{source_name}"
for sub in ("_dlt_pipeline_state", "_dlt_loads", "_dlt_version"):
    target = f"{source_landing}/{sub}"
    if fs.exists(target):
        fs.rm(target, recursive=True)
```

Local-path semantics stay identical because `LocalFileSystem.rm(...,
recursive=True)` matches `shutil.rmtree`.

### Doctor

In `src/das_cli/doctor.py`, extend the existing `delta` and (newly) the
`landing` checks to validate the Azure credentials shape when the URL is
Azure:

```python
def _check_azure_credentials(component: str, creds: dict, url: str) -> list[DoctorIssue]:
    if not is_azure_url(url):
        return []
    try:
        azure = _parse_azure_credentials(creds, url)
    except ValidationError as e:
        # Covers both "no auth field" (discriminator missing) and "invalid auth
        # shape" (e.g., service_principal with one field missing). Pydantic's
        # error message names the bad field; pass it through.
        return [DoctorIssue(component, f"azure credentials invalid: {e}")]
    # azure is never None here — is_azure_url(url) was true, so the helper
    # either returned an AzureCredentials instance or raised above.
    assert azure is not None
    if isinstance(azure, AzureDefaultAuth):
        # Best-effort hint: if neither AZURE_* env vars nor `az` CLI look reachable,
        # warn — but don't fail. Some setups (managed identity on Azure VM) need
        # neither.
        if not _has_azure_default_credential_hint():
            return [DoctorIssue(
                component,
                "auth: default chosen but no AZURE_* env vars detected and `az` "
                "not on PATH; this only works on Azure VMs with managed identity",
            )]
    return []
```

`_has_azure_default_credential_hint()` is a cheap check: returns true if
any of `AZURE_TENANT_ID`/`AZURE_CLIENT_ID`/`AZURE_CLIENT_SECRET`/
`AZURE_USERNAME`/`AZURE_FEDERATED_TOKEN_FILE` is set, **or** `az` is on
`PATH`. No live token fetch, no network call.

### Dependencies

`pyproject.toml` already pulls `dlt[filesystem]`, which transitively pulls
`adlfs` and `fsspec` — no new top-level dependencies needed for Azure I/O.

Two adjustments:

- Bump the dlt floor from `>=1.0` to `>=1.5.0` to guarantee the
  default-credentials → `azure_storage_token` fix from dlt issue #2055
  (closed 2025-01-29). Verify during implementation that the fix actually
  shipped in 1.5; if it landed later, raise the floor accordingly.
- Add `python-dotenv` to the `dev` dependency group (e2e-only). Loaded
  from the e2e conftest if `.env` exists at repo root.

### `.env` and `.gitignore`

`.env` is already in `.gitignore` and present at the repo root with values
for local e2e runs. No change to `.gitignore`. Document the expected `.env`
keys in the e2e test's docstring:

```
AZURE_TENANT_ID=...
AZURE_CLIENT_ID=...
AZURE_CLIENT_SECRET=...
DAS_E2E_AZURE_BUCKET_URL=abfss://...
```

The e2e conftest uses `python-dotenv` to load `.env` at session start.
**The conftest never reads or logs the env-var values** — it only checks
for presence, to gate the test.

## Test strategy

### Unit

- **`tests/unit/test_azure_credentials.py`** — round-trip the three
  config shapes (`service_principal`, `default`, missing `auth`) through
  `_parse_azure_credentials`. Confirm `build_dlt_azure_credentials`
  returns the right dlt class for each. Confirm `is_azure_url` returns
  true for `az://`, `abfs://`, `abfss://` and false for `file://`,
  bare paths, and `s3://`.
- **`tests/unit/test_destination_dispatch.py`** — extend the existing
  delta tests with one case: `target.destination: delta` +
  `bucket_url: abfss://...` + `auth: service_principal` constructs a
  filesystem destination with a non-None `credentials` kwarg of the right
  dlt type.
- **`tests/unit/test_landing_fs.py`** — `landing_fs` returns a
  `LocalFileSystem` for local paths and an `AzureBlobFileSystem` for
  Azure URLs (the latter constructed without any network call).
- **`tests/unit/test_doctor_azure.py`** — `auth: default` with no AZURE_*
  env vars and no `az` on PATH emits the warning; with either present,
  no warning. `auth: service_principal` with one field missing fails
  validation cleanly.

### Integration

dlt does not expose `memory://` as an Azure substitute, and adlfs has no
in-process backend. The integration layer for Azure stays narrow:

- **`tests/integration/test_landing_fs_local.py`** — exhaustive
  round-trips on `LocalFileSystem` through `iter_landing_records` and
  `count_landing_records`. Confirms the new fsspec-backed code matches
  the old `pathlib`-backed behavior for the local case (no regression
  for the duckdb / ducklake / local-delta paths).
- **No Azure integration test.** Azure is exercised by the e2e edge.

### E2E (opt-in)

One new edge test: `tests/e2e/destinations/test_delta_azure.py`. Gated by
the presence of `DAS_E2E_AZURE_BUCKET_URL` and all three `AZURE_*` SP env
vars. Mirrors the existing `test_delta.py` flow:

- bootstrap a fixture workspace with `landing.bucket_url` and
  `target.credentials.bucket_url` derived from `DAS_E2E_AZURE_BUCKET_URL`
  (`/Files/landing/<run_id>` and `/Tables/<run_id>` respectively, so
  parallel runs don't collide).
- `auth: service_principal` for both, templated from the standard
  `AZURE_*` env vars.
- `das source add adventureworks --type odata --url ...` (public
  AdventureWorks).
- `das ingest adventureworks --resource products --limit 10`.
- Read the Delta table back via a reader pipeline that shares the
  writer's `pipeline_name` / `pipelines_dir` (ADR-0017 Decision C).
- Teardown: delete the per-run subtree via fsspec.

A second test variant runs the same flow with `auth: default` —
exercising the dlt issue #2055 fix end-to-end. Gated identically, plus
relies on the SP env vars being picked up by `DefaultAzureCredential`'s
env-var link.

### What gets verified by the README matrix

The existing Delta row is **updated**, not duplicated. Pattern in the
README is one row per destination, with backends listed in Notes:

| Destination | Notes                                                  |
|-------------|--------------------------------------------------------|
| Delta       | Local filesystem + Azure (ADLS Gen2, OneLake); ADR-0017, ADR-0020 |

No new "Verified sources" row — landing is not a destination in das-cli's
verification grammar.

## ADR work

### New: ADR-0020 — Azure landing and Delta destination via fsspec + typed dlt credentials

Decisions to capture:

- **A:** `abfss://`, `abfs://`, `az://` URL schemes for landing and the
  Delta target. OneLake is a URL convention on `abfss://`, not a separate
  scheme. das-cli treats all three as opaque ABFS URLs.
- **B:** Two `auth` modes — `service_principal` and `default`. `cli` and
  managed identity fold into `default` because both are links in dlt's
  `DefaultAzureCredential` chain.
- **C:** Landing reads switch to fsspec for filesystem abstraction. The
  local case continues to work through `LocalFileSystem`. This is the
  first time landing reads stop using `pathlib`; record the contract
  surface so future destinations can use the same helper.
- **D:** das-cli does not own `storage_options` plumbing. dlt's typed
  Azure credentials produce the right `object_store` storage_options
  (including the `azure_storage_token` from a `DefaultAzureCredential`
  default chain) automatically. ADR-0017's per-resource
  `table_format="delta"` decision carries through unchanged.

### Update: ADR-0017

ADR-0017 is on `main`, so CLAUDE.md's lifecycle rule restricts in-place
edits to the **Status field only** — additive sections (even below
Consequences) are not allowed. The supersedure is therefore encoded by
annotating ADR-0017's Status line:

```
- **Status:** Accepted (cloud-Delta consequence superseded for Azure by ADR-0020)
```

The cross-reference back to ADR-0017 lives in ADR-0020's Decision D and
Consequences (which talk about what ADR-0017 still owns and what is
now superseded). ADR-0017's Decision, Context, Alternatives, and
Consequences sections are unchanged.

## Implementation sequence

Each step is a separately-green commit. Steps 1–3 land the typing and
glue without flipping any user-visible behavior; step 4 is the first
e2e-relevant change; steps 5–7 add tests and docs.

1. **Typed credentials + `is_azure_url`.** New
   `src/das_cli/models/das_yaml.py` additions (the discriminated union)
   and `src/das_cli/dlt_glue/azure_credentials.py`. Unit tests for both.
   No call sites changed.
2. **fsspec-backed landing reader.** New `dlt_glue/landing_fs.py`. Swap
   `_iter_landing` / `count_landing_rows` in both `extract.py` and
   `load.py`. Integration test ensures local-path behavior is unchanged.
3. **`reset_extract_state` works on Azure landing.** Delete the
   `NotImplementedError`; use `landing_fs` + `fs.rm(recursive=True)`.
4. **Wire Azure credentials into both destination factories.**
   `_build_destination` for `delta` and the `dlt.destinations.filesystem`
   call in `extract.py` both translate `auth` into a dlt credentials
   object. Unit test for dispatch.
5. **Doctor.** Add `_check_azure_credentials` and wire it into the
   existing landing and target checks. Unit tests.
6. **e2e Azure edge.** `tests/e2e/destinations/test_delta_azure.py` with
   the two auth variants. `python-dotenv` added to `dev` extras. Gated
   on `DAS_E2E_AZURE_BUCKET_URL`.
7. **Docs.** ADR-0020 + the additive footnote on ADR-0017 + a
   README "Verified destinations" row + a "Verified destinations against
   OData" matrix-row entry.

## Open questions

- **dlt floor:** the spec sets `dlt>=1.5.0` based on rough timing of
  issue #2055 closure. Verify the actual release in step 1 by reading
  dlt's CHANGELOG and adjust if needed.
- **adlfs anon flag:** dlt's
  `AzureCredentialsBase.to_adlfs_credentials()` sets `anon=False`
  unconditionally for the typed classes; the spec's
  `_adlfs_storage_options` does the same. Confirm during implementation
  that we don't double-set it (dlt might already inject it through the
  destination factory).
- **OneLake name-form failure mode:** dlt-docs hard-recommend GUID-form.
  The spec recommends GUID-form to users and does not test name-form.
  If a user files an issue against name-form, treat as out-of-scope
  unless the failure is in das-cli code rather than adlfs.
