# Verify DuckLake destination — design

- **Status:** Draft
- **Date:** 2026-05-07
- **Branch:** `claude/assign-first-issue-SZwJB`
- **Issue:** [#22 — Verify DuckLake destination](https://github.com/mattiasthalen/das-cli/issues/22)

## Context

das-cli's `README.md` advertises that "in principle any dlt destination should
work," but only DuckDB is exercised end-to-end. Two pieces of the load
pipeline are coupled to DuckDB:

- `src/das_cli/pipelines/load.py:206` constructs `dlt.destinations.duckdb(...)`
  inline, ignoring `cfg.target.destination` even though `TargetConfig` types
  it as "any dlt destination name."
- `src/das_cli/pipelines/change_detection.py:30` (`load_latest_hash_from_duckdb`)
  opens its own `duckdb.connect(db_path)` and runs DuckDB-specific SQL,
  bypassing dlt entirely for read access.

Until both are generalized, the "Verified" matrix can only honestly list
DuckDB. This design adds **DuckLake** as the second verified destination
and removes the structural coupling that made adding it harder than it
needs to be — without building a plugin framework. DuckLake is "just
another dlt destination"; the abstraction stays as light as that framing.

## Goals

- Add DuckLake to the verified destinations matrix, with end-to-end test
  coverage mirroring the existing AdventureWorks and Northwind tests.
- Drive P2's destination construction from `cfg.target.destination` instead
  of hard-coding DuckDB.
- Make change detection destination-agnostic by reading through dlt's
  `pipeline.sql_client()` rather than a direct `duckdb.connect()`.
- File one ADR documenting both decisions so a future destination addition
  has a clear pattern to follow.
- Preserve full backwards compatibility: existing DuckDB configs and
  `./das.duckdb` files behave identically.

## Non-goals

- Postgres-catalog DuckLake. Filed as a follow-up issue.
- S3-backed DuckLake storage. Same follow-up issue.
- A general plugin/adapter framework for arbitrary destinations. The
  dispatch is a small private function, not a registry.
- Reworking landing-zone configuration.
- New CLI surface. Destinations stay configured in `das.yaml` `target:`.
- MotherDuck, Postgres, BigQuery, Snowflake verification. Out of scope here.

## Design

### Verified DuckLake configuration

Local DuckDB-file catalog plus local Parquet storage. The smallest
verifiable slice; runnable in CI without external services.

```yaml
target:
  destination: ducklake
  credentials:
    catalog: ./das.ducklake          # local DuckDB-file catalog (bare path)
    storage: ./ducklake_data         # local Parquet output dir
```

**Catalog accepts both bare paths and SQLAlchemy URLs.** das-cli inspects
the `catalog` value before forwarding it to `DuckLakeCredentials`:

- If it contains `://`, it is treated as a SQLAlchemy URL and passed
  through verbatim (e.g. `duckdb:///./das.ducklake`,
  `postgresql://user:pass@host:5432/db`, `sqlite:///./catalog.sqlite`).
  This is required for non-DuckDB catalog backends (Postgres, MySQL,
  SQLite) and remains supported for users who prefer explicit URLs.
- Otherwise it is treated as a local DuckDB-file path and prefixed
  with `duckdb:///` before construction. This mirrors the existing
  duckdb-destination UX, where `database: ./das.duckdb` is accepted as
  a bare path.

`storage` and the remaining `DuckLakeCredentials` fields
(`ducklake_name`, `metadata_schema`) are forwarded verbatim. The whole
mapping is then handed to `dlt.destinations.ducklake(credentials=creds, ...)`.

The bare-path form is the only convenience; everything else is
passthrough.

Today's DuckDB shape stays unchanged:

```yaml
target:
  destination: duckdb
  credentials:
    database: ./das.duckdb
```

`TargetConfig.credentials: dict[str, Any]` is already permissive enough to
accept either; no pydantic schema change needed.

### Destination dispatch

A small private function in `pipelines/load.py`:

```python
def _build_destination(target: TargetConfig) -> Any:
    """Construct a dlt destination from cfg.target. See ADR-0016."""
    name = target.destination
    creds = dict(target.credentials)
    if name == "duckdb":
        return dlt.destinations.duckdb(
            credentials=creds.get("database", "./das.duckdb"),
            enable_dataset_name_normalization=False,
        )
    if name == "ducklake":
        catalog = creds.get("catalog")
        if isinstance(catalog, str) and "://" not in catalog:
            creds = {**creds, "catalog": f"duckdb:///{catalog}"}
        return dlt.destinations.ducklake(
            credentials=creds,
            enable_dataset_name_normalization=False,
        )
    raise ValueError(
        f"Unsupported target.destination: {name!r}. "
        f"Verified destinations: duckdb, ducklake."
    )
```

`enable_dataset_name_normalization=False` is unconditional — it implements
ADR-0008's prefix-preservation policy globally, not per-destination. Every
destination das-cli supports must carry this flag; if a future destination
does not accept it, that is a blocker for verification, not a per-case
override.

The current inline construction in `run_load` is replaced with a single
call: `destination=_build_destination(cfg.target)`.

### Destination-agnostic change detection

Rename `load_latest_hash_from_duckdb` → `load_latest_hash`. New signature
takes the running pipeline:

```python
def load_latest_hash(
    *,
    pipeline: dlt.Pipeline,
    dataset: str,
    table: str,
    primary_key: list[str],
) -> dict[tuple[Any, ...], str]:
    """Latest `_row_hash` per primary key, from the destination. See ADR-0016."""
    pk_cols = ", ".join(f'"{c}"' for c in primary_key)
    sql = f"""
    SELECT {pk_cols}, _row_hash
    FROM "{dataset}"."{table}"
    QUALIFY ROW_NUMBER() OVER (PARTITION BY {pk_cols} ORDER BY _dlt_load_id DESC) = 1
    """
    try:
        with pipeline.sql_client() as client:
            rows = list(client.execute_sql(sql))
    except DatabaseUndefinedRelation:
        return {}
    out: dict[tuple[Any, ...], str] = {}
    for row in rows:
        pk = tuple(row[: len(primary_key)])
        out[pk] = row[-1]
    return out
```

das-cli no longer imports `duckdb` for read access. dlt owns the
destination-specific connection plumbing. The exact missing-table exception
class will be confirmed during the refactor — `DatabaseUndefinedRelation`
is the expected dlt 1.x class; if it differs, the implementation adopts
the actual class.

### Doctor

`src/das_cli/doctor.py` adds a one-line note when
`cfg.target.destination == "ducklake"` confirming the catalog and
storage paths are readable. Not a hard validation — config-typo hygiene
only, mirroring the lightweight checks already in the doctor.

## Test strategy

Three layers, mirroring `tests/unit`, `tests/integration`, `tests/e2e`.

**Unit — `tests/unit/test_destination_dispatch.py`:**

- `_build_destination` returns a `duckdb` destination for `destination: duckdb`.
- `_build_destination` returns a `ducklake` destination for `destination: ducklake`.
- Both dispatched destinations carry `enable_dataset_name_normalization=False`.
- Unknown destination name raises `ValueError` naming the field and the
  verified destinations.
- Credentials dict is forwarded as kwargs.

**Integration — `tests/integration/test_load_pipeline_ducklake.py`:**

- Full P2 against a local DuckLake target (catalog file + storage dir
  under `tmp_path`).
- Two ingest cycles with the same source data; second cycle appends zero
  rows. Proves change detection round-trips through `pipeline.sql_client()`
  on DuckLake.
- Asserts row counts, `_row_hash` populated, `das__<source>` dataset name
  preserved through DuckLake.
- Existing `tests/integration/test_load_pipeline.py` continues covering
  the DuckDB path; the change-detection rename keeps it green.

**E2E — `tests/e2e/test_adventureworks_ducklake.py`, `tests/e2e/test_northwind_ducklake.py`:**

- Mirror the existing e2e tests with the `target:` block pointing at
  DuckLake. Same `@pytest.mark.e2e` opt-in marker, same public APIs.
- Assertions read through `pipeline.dataset()` (destination-agnostic)
  rather than the existing `duckdb.connect(...)` pattern in the current
  e2e tests. Existing DuckDB e2e tests stay as-is.

## Implementation sequence

Each step is a separately-green commit.

1. **Rebase gate.** Wait for issue #21's ADR-index fix to land in main; rebase
   onto it. User signals when ready. The README index touch in step 7
   appends to the cleaned index.
2. **Refactor change detection to dlt-driven reads.** Rename
   `load_latest_hash_from_duckdb` → `load_latest_hash`, switch to
   `pipeline.sql_client()`, update the single call site in `load.py`.
   Pure refactor; existing DuckDB tests stay green; no new destination yet.
3. **Extract `_build_destination`.** Pull the inline destination construction
   into the dispatch function. Still only handles `duckdb`. Pure refactor.
4. **Add ducklake branch + extras.** Extend `_build_destination`, add
   `ducklake` to `dlt[...]` extras in `pyproject.toml`, add unit tests for
   dispatch.
5. **Integration test for DuckLake.** `test_load_pipeline_ducklake.py`
   with the two-cycle change-detection assertion. Real proof step 2's
   refactor works through DuckLake.
6. **E2E tests for DuckLake.** `test_adventureworks_ducklake.py`,
   `test_northwind_ducklake.py`. Behind `@pytest.mark.e2e`.
7. **Doctor, ADR, README.** Doctor note for ducklake, README "Verified"
   matrix row, README "What it is" wording, ADR-0016 file, ADR index row.

## Risk surface

- **`pipeline.sql_client()` missing-table exception.** dlt's class may
  differ from today's `duckdb.CatalogException`. Discoverable in step 2;
  the implementation adopts the actual class.
- **DuckLake credential key names.** Confirmed against dlt 1.26's
  `DuckLakeCredentials`: `catalog`, `storage`, `ducklake_name`,
  `metadata_schema`. das-cli forwards the entire `credentials` dict
  unchanged.
- **DuckLake first-load behaviour.** Empty-catalog initialization may
  surface differently than DuckDB's "table not found." Step 5's two-cycle
  test catches it.
- **Index file collision with issue #21.** Mitigated by the explicit
  rebase gate in step 1.

## ADRs

One new ADR: **`docs/adrs/0016-destination-dispatch-and-pipeline-driven-reads.md`**.

- **Decision A:** destination construction lives in a small private
  `_build_destination` function in `pipelines/load.py`. Adding a new
  destination is one branch in one function plus a `dlt[<extra>]` entry
  in `pyproject.toml`.
- **Decision B:** change detection reads through `pipeline.sql_client()`.
  das-cli no longer imports `duckdb` for read access.
- **Alternatives considered:** adapter-registry (rejected — duplicates
  dlt's own abstraction); branch-by-name inside `change_detection.py`
  (rejected — does not scale past two destinations).
- **Consequences:** locks in dlt's `sql_client()` API as a contract
  surface. A future destination without a usable SQL client could not
  support change detection without per-destination read code.

## Documentation updates

- `README.md` "Verified" matrix — add `DuckLake` row.
- `README.md` "What it is" paragraph (line 12-13) — generalize "DuckDB
  warehouse" to "DuckDB or DuckLake warehouse" (or "contract-enforced
  warehouse"), so the lead claim does not contradict the matrix.
- `docs/adrs/README.md` — append the ADR-0016 row, on top of the rebased
  cleanup from issue #21.
- Inline `# See ADR-0016` comments on `_build_destination` and on the
  renamed `load_latest_hash`, per the CLAUDE.md pointer-to-ADR convention.

## Done criteria

- All existing tests green (unit, integration, e2e).
- New DuckLake unit, integration, and e2e tests green.
- `README.md` "Verified" matrix lists DuckLake.
- `docs/adrs/0016-destination-dispatch-and-pipeline-driven-reads.md`
  committed.
- Pre-commit (ruff, mypy) clean.
- Backwards compatibility verified: existing `target.destination: duckdb`
  configs and `./das.duckdb` files unchanged.
