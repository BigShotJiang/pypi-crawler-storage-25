# Progress bars for `das extract` and `das load` — design

- **Status:** Draft
- **Date:** 2026-05-06
- **Issue:** [#14 — Bundle: v0.1.4 — progress bars](https://github.com/mattiasthalen/das-cli/issues/14) (sub-issue [#2](https://github.com/mattiasthalen/das-cli/issues/2))

## Goal

Live runtime feedback for long-running ingest operations. Replace today's
"header line, silence, final summary" UX with a per-resource progress display
that shows which resource is in flight, how many records have flowed through,
elapsed time, and (for load) an ETA based on a known row total.

Two pipelines are in scope: `das extract` and `das load`. The behavior must
also work cleanly under `--quiet`, `--verbose`, and on non-TTY stdout.

## Non-goals

- Concurrent extraction across resources (today dlt processes them in sequence
  inside one `pipeline.run()`; the bars only need to render that sequence).
- Progress for other commands (`bootstrap`, `validate`, `doctor`) — those are
  short by nature.
- Periodic milestone lines in non-TTY mode. Per-resource start/finish only.
  Can be added later if a multi-hour resource ever surfaces.
- Customizing the visual style. Rich defaults are used as-is.

## Mode resolution

Three flags determine three modes. Resolution lives in `cli.py`, in each of
the `extract`, `load`, and `ingest` commands:

| Flags                         | `mode`     | dlt `progress=` |
|-------------------------------|------------|-----------------|
| `--quiet`                     | `silent`   | `None`          |
| `--verbose`                   | (unused)   | `"log"`         |
| default, `sys.stdout.isatty()`| `rich`     | `None`          |
| default, non-TTY              | `plain`    | `None`          |

Notes:

- `--verbose` keeps today's behavior (dlt's verbose log lines, no bars).
  Verbose is for debugging; bars get in the way of grepping logs.
- The default mode previously hard-coded `progress="log"` in
  `pipelines/extract.py` and `pipelines/load.py`. That string moves into the
  CLI layer so the default mode can switch dlt to silent and let the Rich
  bars own the screen.
- `--quiet` and `--verbose` together: `--quiet` wins (no progress at all).

## Per-resource lifecycle

Every resource passes through three (or four) states. The Rich renderer
shows them in a single stacked panel; the plain renderer writes them as
individual log lines.

| State    | Rich                                          | Plain                                              |
|----------|-----------------------------------------------|----------------------------------------------------|
| pending  | `  Customers          waiting`                | (not printed)                                      |
| active   | `⠋ Customers          1,234 rows · 0:00:03`   | `[das] Customers: started` (printed once on entry) |
| done     | `✓ Customers          1,234 rows · 0:00:05`   | `[das] Customers: 1,234 rows · 5.2s`               |
| failed   | `✗ Customers          (error after 412 rows)` | `[das] Customers: FAILED after 412 rows`           |

State transitions are driven by the wrapping generator — see "Counting
generator" below.

For **load**, totals are pre-computed (cheap line count over each resource's
landing JSONL) and supplied as a `{resource_name: row_count}` mapping; Rich
renders a real bar with ETA. For **extract**, totals are unknown; resources
are supplied as a list and Rich renders a spinner + counter only.

## Module layout

One new file: `src/das_cli/progress.py` (~120 lines). Public surface:

```python
@contextmanager
def progress(
    resources: Sequence[str] | Mapping[str, int],
    *,
    mode: Literal["rich", "plain", "silent"],
) -> Iterator[ProgressHandle]: ...

@dataclass
class ProgressHandle:
    def wrap(self, name: str, it: Iterable[T]) -> Iterator[T]: ...
    def fail(self, name: str, err: BaseException) -> None: ...
```

Three internal renderer classes implement the same protocol:

- `_RichRenderer` — owns a `rich.progress.Progress` instance configured with
  per-resource columns (`SpinnerColumn`, `TextColumn(name)`, `MofNCompleteColumn`,
  `TimeElapsedColumn`, optional `BarColumn` + `TimeRemainingColumn` when total
  is known).
- `_PlainRenderer` — writes start/finish/fail lines via the existing
  `output.info` / `output.warn` helpers.
- `_SilentRenderer` — a no-op; `wrap` returns the input iterator unchanged,
  no counters are instantiated.

`output.py` is unchanged. It owns one-shot styled lines; `progress.py` owns
live progress.

## Counting generator

`ProgressHandle.wrap(name, it)` is a thin generator wrapper:

```python
def wrap(self, name: str, it: Iterable[T]) -> Iterator[T]:
    self._renderer.start(name)        # active state
    n = 0
    try:
        for item in it:
            yield item
            n += 1
            self._renderer.tick(name, n)
        self._renderer.done(name, n)  # done state
    except BaseException as exc:
        self._renderer.fail(name, n, exc)
        raise
```

Every yielded record bumps the relevant Rich task by one (or appends to the
plain renderer's per-resource counter); exceptions propagate after the
renderer is told. The existing pipeline-level error handling in `cli.py`
already catches these and converts them to `PIPELINE_FAILURE`.

## Integration points

Three files are edited; the total surface is small.

### `src/das_cli/progress.py` (new)

The module described above. It has no imports from the pipeline layer — only
`rich` and stdlib.

### `src/das_cli/pipelines/extract.py`

- `run_extract` gains keyword-only parameters
  `progress_handle: ProgressHandle | None = None` and
  `dlt_progress: str | None = None`.
- The hard-coded `progress="log"` argument to `dlt.pipeline()` is replaced
  with `progress=dlt_progress`.
- Each generator returned by `build_extract_resources` is wrapped:
  `progress_handle.wrap(c.resource_name, gen)` when the handle is non-None.
  This is done at the call site in `run_extract`, not inside
  `build_extract_resources`, to keep the source factory pure.

### `src/das_cli/pipelines/load.py`

- Same two new parameters on `run_load`.
- Before building dlt resources, count rows per (source, resource) by
  iterating `landing_root / src.name / c.resource_name / *.jsonl*` and
  summing line counts (no JSON parsing). The result is a flat
  `{table_name: row_count}` map keyed by the table name (post-physicalName
  resolution) so it matches what the wrapper sees.
- Pass that map to `progress({...}, mode=...)` from the CLI; pipelines
  receive the resulting handle.
- In `_build_load_resource`, the inner `_gen()` is wrapped:
  `progress_handle.wrap(table_name, _projected_iter())` when handle is
  non-None. The change-detection filter still wraps that result; ordering is
  `wrap → change_filter` so the counter reflects rows that actually arrive
  at dlt (post-filter), which matches the bar's semantics ("rows being
  loaded").
- One subtlety: when `--full` is not set, change detection may filter out
  most rows. The bar's total (pre-counted from landing files) will then
  finish well below 100%. This is acceptable: the bar still advances
  monotonically, never overshoots, and the final summary line tells the
  truth. The Rich progress text shows "rows" not "%" so the under-fill is
  not misleading.

### `src/das_cli/cli.py`

In `extract`, `load`, and `ingest`:

```python
import sys
from das_cli.progress import progress

quiet = ctx.obj.get("quiet", False)
verbose = ctx.obj.get("verbose", False)
if quiet:
    mode, dlt_progress = "silent", None
elif verbose:
    mode, dlt_progress = None, "log"
else:
    mode = "rich" if sys.stdout.isatty() else "plain"
    dlt_progress = None

# build resource list (or {name: total} map for load)
if mode is None:
    handle = None
    run_extract(..., progress_handle=None, dlt_progress=dlt_progress)
else:
    with progress(resources, mode=mode) as handle:
        run_extract(..., progress_handle=handle, dlt_progress=dlt_progress)
```

The existing post-run `info(f"  {rname}: {count} rows")` summary lines are
kept — they print after the bar tears down and give grep-friendly final
counts in all modes except `--quiet`.

## Testing

### Unit (`tests/test_progress.py`, new)

- `wrap` yields items unchanged in count and order.
- `wrap` propagates exceptions after the renderer is told.
- `_PlainRenderer` writes the expected start / finish / fail lines.
- `_SilentRenderer.wrap` is the identity (no Rich instance is created).
- Mode resolution helper (extracted from cli.py to a pure function for
  testability) maps `(quiet, verbose, isatty)` correctly.

### Integration (extends existing pipeline tests)

- `test_extract.py`: assert that under `mode="plain"`, captured stdout
  contains `[das] <resource>: started` and `[das] <resource>: N rows`.
- `test_load.py`: same.
- `test_cli.py`: run `extract` with `--quiet` against a tiny fixture; assert
  no `[das]` progress lines appear (only the final `success(...)` line).

The Rich renderer path is exercised manually during development but not
asserted in tests; animated output is fragile to assert against and does not
add coverage beyond what `_PlainRenderer` and `_SilentRenderer` already give.

### Out of scope for tests

- e2e (Northwind) tests are unaffected; they run with default mode and the
  bars render but the test assertions don't depend on stdout shape.
- Performance tests. The wrapper adds sub-microsecond overhead per yielded
  record; not measurable at v0.1 scale.

## Acceptance criteria (from issue #2)

How this design satisfies each criterion:

- **Live extract progress** — `mode="rich"` runs spinners + counters per
  resource via `_RichRenderer`.
- **Live load progress with real bar** — load pre-counts JSONL lines and
  passes totals to `progress({name: total, ...})`, enabling a real
  `BarColumn` with ETA.
- **`--quiet` suppresses progress** — resolves to `mode="silent"`, whose
  renderer is a no-op; the final `success(...)` line still prints.
- **`--verbose` keeps dlt log output** — resolves to `mode=None`, no Rich
  bars; dlt receives `progress="log"`.
- **Non-TTY graceful degradation** — `mode="plain"` writes per-resource
  start/finish lines via existing `output.info` / `output.warn`.
- **Existing tests pass; one new test asserts progress output** — see
  Testing section.

## ADR impact

No new ADR required. This change is internal UX; it does not alter:

- Pipeline architecture (ADR-0002).
- P1 blob pattern (ADR-0003).
- Schema contract enforcement (ADR-0012).
- dlt config approach (ADR-0009) — the `progress=` argument is already a
  Python-object config; we're just making it conditional.

If the load pre-count step ever becomes expensive enough to want caching or
streaming (it shouldn't at v0.1 scale), that would warrant an ADR.

## Open questions

None at design time. Implementation may surface edge cases worth documenting
in the implementation plan (e.g., what to do if a resource is in the
contract but has zero landing files for `load` — current behavior is to skip
it silently; the bar would show it as "0/0 done" which is fine).
