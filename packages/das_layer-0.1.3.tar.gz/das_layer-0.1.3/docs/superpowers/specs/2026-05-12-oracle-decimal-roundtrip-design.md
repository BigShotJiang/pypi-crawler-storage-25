# Oracle `NUMBER(p,s)` decimal round-trip fix

- **Date:** 2026-05-12
- **Status:** Draft
- **Related ADRs:** ADR-0018 (SQL source via SQLAlchemy reflection)
- **Regression introduced by:** PR #53 (`fix(sql): split --full semantics and fix decimal(p,s) round-trip (#43, #45)`)

## Problem

The Oracle e2e test `tests/e2e/sources/test_oracle.py::test_oracle_bootstrap_extract_load` fails at the **load** step on `main` (every CI run since #53 merged) with:

```
In Table: `orders` Column: `amount__v_text`.
Contract on `data_type` with `contract_mode=freeze` is violated.
Can't add variant column `amount__v_text` for table `orders` because `data_types` are frozen.
Offending data item: order_id: 100, line_no: 1.
```

The SQL Server e2e test against the equivalent `DECIMAL(12,2)` fixture passes, so the bug is Oracle-specific. ADR-0018 (Consequences) states that `decimal(p,s)` columns "round-trip losslessly through P1 → landing → P2"; that contract is broken for Oracle.

## Root cause

`src/das_cli/bootstrap/sql.py::_logical_for` checks `Integer` before `Numeric`:

```python
def _logical_for(col):
    sa_type = col.type
    if isinstance(sa_type, BigInteger):
        return ("integer", "bigint")
    if isinstance(sa_type, Integer | SmallInteger):
        return ("integer", None)                     # ← oracle.NUMBER takes this branch
    if isinstance(sa_type, Numeric) and not isinstance(sa_type, Float):
        ...
```

SQLAlchemy's `oracle.NUMBER` (`sqlalchemy/dialects/oracle/types.py`) is declared as:

```python
class NUMBER(sqltypes.Numeric, sqltypes.Integer): ...
```

So `isinstance(oracle.NUMBER(12,2), Integer)` is **True**, and the Integer branch wins. The contract for `orders.amount` is emitted with `logicalType: integer, physicalType: null` instead of `logicalType: number, physicalType: decimal(12,2)`.

Downstream consequences:
- `build_dlt_columns` maps `logicalType=integer` → dlt `data_type=bigint`.
- `is_decimal_column(prop)` in `_project_record` returns `False` (it checks `logicalType=="number"`), so `coerce_decimal` is **not** called.
- The value reaches dlt as the JSON-stringified `"19.99"` written by P1's landing encoder.
- dlt's frozen `bigint` contract sees text → tries to add an `amount__v_text` variant → freeze rejects it → load fails.

SQL Server's `DECIMAL(12,2)` reflects to a SQLAlchemy `Numeric` that does **not** inherit `Integer`, so it falls through to the Numeric branch and works correctly. The bug is dialect-specific to types whose Python class inherits both `Numeric` and `Integer` — at present, only `oracle.NUMBER` in SQLAlchemy 2.x.

## Fix

Reorder `_logical_for` so a `Numeric` with **scale > 0** is detected before the Integer branches. `NUMBER(p, 0)` (which Oracle treats as integer-like, returning `int` from the driver) continues to fall through to the Integer branch unchanged.

```python
def _logical_for(col):
    sa_type = col.type

    # NOTE: this check runs BEFORE the Integer branches because oracle.NUMBER
    # extends both Numeric AND Integer. We want NUMBER(p,s>0) to be classified
    # as a fixed-precision decimal, not as an integer (which would lose scale
    # and break P2's decimal coercion in _project_record).
    if isinstance(sa_type, Numeric) and not isinstance(sa_type, Float):
        scale = sa_type.scale
        if scale is not None and scale > 0:
            precision = sa_type.precision
            if precision is not None:
                return ("number", f"decimal({precision},{scale})")
            return ("number", None)
        # scale == 0 or None: fall through. oracle.NUMBER(p,0) is caught by
        # the Integer branch below (matches Oracle's own semantics — driver
        # returns int when scale == 0). Generic Numeric(p,0) is caught by
        # the second Numeric branch.

    if isinstance(sa_type, BigInteger):
        return ("integer", "bigint")
    if isinstance(sa_type, Integer | SmallInteger):
        return ("integer", None)

    # Generic Numeric with scale 0 or unspecified (not Integer-derived).
    # E.g., MSSQL/Postgres NUMERIC(10,0) or NUMERIC with no precision.
    if isinstance(sa_type, Numeric) and not isinstance(sa_type, Float):
        precision = sa_type.precision
        scale = sa_type.scale
        if precision is not None and scale is not None:
            return ("number", f"decimal({precision},{scale})")
        return ("number", None)

    if isinstance(sa_type, Float):
        return ("number", None)
    # …rest unchanged…
```

### Behavior matrix

| SQLAlchemy type | Today | After fix | Notes |
|---|---|---|---|
| `oracle.NUMBER(12,2)` | `("integer", None)` ❌ | `("number","decimal(12,2)")` ✅ | the bug |
| `oracle.NUMBER(10,0)` | `("integer", None)` | `("integer", None)` | unchanged; matches Oracle semantics |
| `Numeric(12,2)` (MSSQL / SQLite / Postgres) | `("number","decimal(12,2)")` | `("number","decimal(12,2)")` | unchanged |
| `Numeric(10,0)` | `("number","decimal(10,0)")` | `("number","decimal(10,0)")` | unchanged |
| `Numeric()` (no precision/scale) | `("number", None)` | `("number", None)` | unchanged |
| `Integer / BigInteger / SmallInteger` | `("integer", …)` | `("integer", …)` | unchanged |
| `Float / Double` | `("number", None)` | `("number", None)` | unchanged |

No other paths are affected.

## Why not the alternatives

- **SQLAlchemy `_type_affinity` dispatch.** `oracle.NUMBER._type_affinity` already classifies scale>0 as Numeric and scale==0 as Integer. Switching the function to `sa_type._type_affinity` would be a one-line dispatch. Rejected because `_type_affinity` is a leading-underscore private API and we'd be coupling to it across SQLAlchemy minor versions.

- **Dialect-specific `isinstance(sa_type, oracle.NUMBER)` shim.** Surgical, but violates ADR-0018 Decision B ("Type mapping covers SQLAlchemy generic types only; dialect-specific types fall back to `logicalType: string`"). The mapper is intentionally dialect-agnostic; adding vendor branches sets a precedent we'd pay for in every future dialect.

## ADR

No new ADR. ADR-0018 already declares the round-trip intent in its Consequences section; this is a defect in the implementation of that decision, not an architectural change. (Per `CLAUDE.md`: "Skip ADRs for: bug fixes, refactors that preserve behavior…")

## Test plan

### New unit tests (`tests/unit/test_bootstrap_sql.py`)

`_logical_for` can be exercised directly without any Oracle container — `oracle.NUMBER` is just a Python class:

```python
def test_logical_for_oracle_number_with_scale_maps_to_decimal() -> None:
    from sqlalchemy import Column
    from sqlalchemy.dialects.oracle import NUMBER
    from das_cli.bootstrap.sql import _logical_for
    col = Column("amount", NUMBER(12, 2))
    assert _logical_for(col) == ("number", "decimal(12,2)")

def test_logical_for_oracle_number_scale_zero_maps_to_integer() -> None:
    # NUMBER(p, 0) is integer-like in Oracle; the driver returns int.
    from sqlalchemy import Column
    from sqlalchemy.dialects.oracle import NUMBER
    from das_cli.bootstrap.sql import _logical_for
    col = Column("order_id", NUMBER(10, 0))
    assert _logical_for(col) == ("integer", None)
```

These tests would have failed against the buggy `_logical_for` and pass against the fix.

### Existing coverage that already exercises this path

- `tests/unit/test_bootstrap_sql.py::test_type_mapping_numeric_with_precision` — generic `Numeric(12,2)`, still passes after the fix.
- `tests/integration/test_extract_pipeline_sql.py::test_sql_extract_decimal_with_scale_round_trips` — SQLite `Numeric(12,2)` end-to-end, still passes after the fix.

### Regression test (already exists, no changes)

- `tests/e2e/sources/test_oracle.py::test_oracle_bootstrap_extract_load` is the live regression test. CI on the fix branch must show this green before merge.

## Code-comment update

The fix adds a single short comment in `_logical_for` explaining why the Numeric-with-scale branch precedes the Integer branches (Oracle's NUMBER MRO). Per `CLAUDE.md`, comments are reserved for non-obvious *why*; this qualifies because the ordering looks arbitrary without the MRO context.

## Out of scope

- ADR-0018 update: not required. The Consequences section already documents the round-trip intent; the implementation will now match it.
- Wider audit of `_logical_for` ordering for other dialect-specific types: deferred. No other SQLAlchemy 2.x dialect ships a numeric type that inherits both `Numeric` and `Integer`. If one appears, the same reorder principle applies.
- Whether `Numeric(p, 0)` should map to `integer` rather than `decimal(p,0)`: out of scope — that's a behavior question for ADR-0018 follow-up, not a bug.
