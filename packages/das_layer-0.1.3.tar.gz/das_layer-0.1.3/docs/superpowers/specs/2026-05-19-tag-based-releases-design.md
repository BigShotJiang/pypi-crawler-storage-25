# Tag-based releases for das-cli

- **Date:** 2026-05-19
- **Status:** Draft

## Context

`das-cli` is the GitHub repository and the CLI command (`das`); its Python
import path is `das_cli`. The PyPI distribution name `das-cli`, however,
is already occupied by an unrelated active project (the Royal Netherlands
Institute for Sea Research's distributed-acoustic-sensing client). The
package is published instead under the distribution name **`das-layer`**,
which aligns with the "DAS layer" terminology used throughout the repo's
README and ADRs.

End users install with `uv tool install das-layer` (or `pip install
das-layer`) and run the `das` command. The repository has no git tags, no
release workflow, and nothing on PyPI under either name yet. The current
`pyproject.toml` declares `name = "das-cli"` and `version = "0.1.0"`
statically — both need to change.

CI today (`.github/workflows/ci.yml`) is uv-native: every job uses
`astral-sh/setup-uv@v3`, `uv python install`, `uv sync`, `uv run`. There is
no separate publish path. To cut a release today, the maintainer would have
to build and upload by hand from a local checkout — error-prone and not
reproducible.

This spec defines the release pipeline: how a release is triggered, how the
version is sourced, how the workflow authenticates to PyPI, and how release
notes are produced.

## Decision

**Trigger.** A new workflow `.github/workflows/release.yml` runs on
`push.tags: ["v*"]`. The maintainer cuts a release by tagging
`vX.Y.Z` and pushing the tag. No other trigger (no `workflow_dispatch`,
no GitHub Release UI trigger).

**Project name.** `pyproject.toml`'s `[project] name` switches from
`das-cli` to `das-layer`. The Python package (`src/das_cli/`), the
CLI entry point (`das = "das_cli.cli:app"`), and the GitHub repository name
are all unchanged.

**Version source.** `pyproject.toml` switches the project version from
static to dynamic, sourced from the git tag via `hatch-vcs`. The tag is the
single source of truth — tag and package version cannot drift.

```toml
[project]
name = "das-layer"
# version = "0.1.0"        ← removed
dynamic = ["version"]

[build-system]
requires = ["hatchling", "hatch-vcs"]
build-backend = "hatchling.build"

[tool.hatch.version]
source = "vcs"
fallback-version = "0.0.0"   # so `uv sync` works on shallow clones without tags
```

Between tags, local `uv build` produces versions like `0.2.0.dev3+gabcdef0`.
The release workflow only fires on a tag, so PyPI never receives a dev
build. `src/das_cli/__init__.py`'s `__version__` switches from the literal
`"0.1.0"` to `importlib.metadata.version("das-layer")` so `das --version`
returns whatever the installed distribution reports — no generated
`_version.py` file is needed.

**PyPI authentication.** OIDC trusted publishing via
`pypa/gh-action-pypi-publish@release/v1`. No long-lived tokens stored in
GitHub. One-time bootstrap on pypi.org: register a **pending publisher**
for the project name `das-layer` (the project does not yet exist on PyPI),
pointing at the repository `mattiasthalen/das-cli`, workflow filename
`release.yml`, environment blank. After the first publish the pending
publisher promotes to a regular trusted publisher automatically.

**Release notes.** Auto-generated from PR titles since the previous tag,
using GitHub's `generate_release_notes: true` in
`softprops/action-gh-release@v2`. No `CHANGELOG.md`. PR titles in this repo
already follow conventional prefixes (`feat(...)`, `fix(...)`,
`docs(adr): ...`), which render cleanly.

**Install command in docs.** README quickstart switches every
`uv tool install das-cli` invocation to `uv tool install das-layer`. Add a
short note that `pip install das-layer` and `pipx install das-layer` also
work, for users without uv. The PyPI badge URLs in the README header
update from `pypi.org/project/das-cli` to `pypi.org/project/das-layer`.

**Tag format.** `vX.Y.Z` with the leading `v` (e.g., `v0.1.0`). Pre-release
tags (`v0.2.0a1`, `v0.2.0rc1`) flow through the same workflow; PEP 440
parsing in `hatch-vcs` produces the matching PyPI pre-release version, and
`action-gh-release` marks the GitHub Release as a prerelease when the tag
contains an `a`, `b`, or `rc` segment.

### Workflow shape

```yaml
name: Release
on:
  push:
    tags: ["v*"]

jobs:
  build-and-publish:
    runs-on: ubuntu-latest
    permissions:
      id-token: write       # OIDC for PyPI
      contents: write       # create GH Release
    steps:
      - uses: actions/checkout@v4
        with: { fetch-depth: 0 }   # hatch-vcs needs tag history
      - uses: astral-sh/setup-uv@v3
        with: { enable-cache: true }
      - run: uv python install 3.12
      - run: uv build                              # produces dist/*.whl + dist/*.tar.gz
      - uses: pypa/gh-action-pypi-publish@release/v1
      - uses: softprops/action-gh-release@v2
        with:
          generate_release_notes: true
          files: dist/*
```

`uv build` produces the artifacts; `gh-action-pypi-publish` (the canonical
PyPA action) handles OIDC and the actual upload to PyPI. Recent `uv`
versions also support trusted publishing via `uv publish
--trusted-publishing`, but the PyPA action is the better-documented path
and is what PyPI's own trusted-publishing setup guide references — staying
on it keeps us on the well-trodden track.

### Existing CI workflow

`.github/workflows/ci.yml` is left untouched. It runs on `push: branches:
[main]` and `pull_request`; the new `release.yml` runs only on tag pushes.
The triggers do not overlap.

`hatch-vcs` becomes a build-time dependency. `uv sync` and `uv run pytest`
continue to function because `uv` honors `[build-system].requires` when
resolving the local project.

### ADR

A new ADR `docs/adrs/0026-tag-based-releases-via-hatch-vcs.md` captures the
decision and the alternatives below. It lands in the same PR as the
workflow and `pyproject.toml` changes. The ADR README index gains a row
for 0026.

## Alternatives considered

- **GitHub Release UI as trigger** — clicking "Draft release" in the GitHub
  UI to create the tag, with the workflow listening for `release:
  published`. Rejected: the trigger lives outside git, and the same outcome
  is reachable with `git tag && git push --tags`. No reason to add a
  second path.

- **Fully automated release-please / semantic-release** — bot reads
  conventional commits, opens a release PR that bumps version + changelog;
  merging it cuts the release. Rejected for the current size of the
  project: one maintainer, pre-1.0, version numbers picked by hand are
  fine. Reconsider if multi-maintainer or external consumers start
  demanding strict semver enforcement.

- **Static version in `pyproject.toml` + CI guard** — keep `version =
  "X.Y.Z"` static, have the workflow assert the tag matches before
  publishing. Rejected: adds a manual step that `hatch-vcs` eliminates, and
  the guard exists to catch a failure mode that `hatch-vcs` makes
  impossible.

- **API token in a GitHub secret** instead of OIDC — simpler one-time
  bootstrap (paste a token into a secret), but the token is long-lived and
  needs rotation. Rejected; OIDC is the current PyPA recommendation and the
  setup is no harder once the publisher is registered.

- **TestPyPI dry-run before PyPI publish** — publish each tag to TestPyPI
  first, gate the PyPI step on its success. Rejected for now: adds a
  second publisher to register on TestPyPI, and the first real PyPI
  publish is itself the dry-run for a `v0.1.0` cut. Add later if a release
  goes wrong in a way TestPyPI would have caught.

- **`pip install` as primary in docs** instead of `uv tool install` —
  `pip install` is more universally recognized, but the rest of the
  project is uv-native and the current README already leads with uv tool.
  Keep that and mention pip as an alternative.

## Consequences

**Positive**
- Reproducible releases: every artifact on PyPI corresponds to a signed
  git tag in the repo, with no manual build steps.
- No long-lived PyPI credentials in GitHub.
- Version drift becomes impossible: the tag *is* the version.
- Pre-release tags work without extra config.

**Negative**
- First release requires one-time PyPI trusted-publisher registration in
  the pypi.org UI.
- `hatch-vcs` adds a build-time dependency. Local builds from a shallow
  checkout (e.g., a CI runner without `fetch-depth: 0`) will produce odd
  versions or fail; the new release workflow sets `fetch-depth: 0`, and
  existing CI does not build wheels so it is unaffected.
- Release notes quality is coupled to PR-title hygiene. Already good in
  this repo; revisit if it degrades.

**Neutral**
- The maintainer continues to choose version numbers by hand. SemVer
  policy is not enforced by tooling.
- No changelog file. Release history is reconstructible from GitHub
  Releases and `git log`.

## Test plan

The release workflow cannot be unit-tested. Acceptance is end-to-end:

1. **First tag, real PyPI.** After merge, tag `v0.1.0` on `main`, push
   the tag, watch the workflow.
   - Build step succeeds; `dist/das_layer-0.1.0-py3-none-any.whl` and
     `das_layer-0.1.0.tar.gz` appear (hatchling derives wheel filenames
     from the distribution name).
   - `gh-action-pypi-publish` succeeds; the artifact appears on
     pypi.org/project/das-layer.
   - GitHub Release `v0.1.0` exists with auto-generated notes and the
     two `dist/` files attached.
2. **Post-publish install probe.**
   - `uv tool install das-layer` in a clean shell produces a working `das`
     binary; `das --version` prints `0.1.0`; `das --help` exits 0.
   - `pip install das-layer` into a fresh venv does the same.
3. **`hatch-vcs` produces the expected version locally.**
   - On a checkout pointing at the `v0.1.0` tag: `uv build` produces a
     wheel named `das_layer-0.1.0-...whl` (no `.dev` suffix).
   - On `main` one commit past the tag: `uv build` produces a wheel
     containing `0.1.0.dev1+<sha>`.

If step 1 fails on the publish step (most likely cause: trusted publisher
not registered), the build artifact remains in the workflow run for
download — we do not need to retag to retry once the registration is
fixed.

## Out of scope

- Signed tags or sigstore attestations.
- Provenance attestation via `actions/attest-build-provenance`.
- Automated changelog generation into a `CHANGELOG.md`.
- TestPyPI publishing.
- Conventional-commit enforcement on PR titles (currently honor-system).
- Documentation site / release announcements outside GitHub.
