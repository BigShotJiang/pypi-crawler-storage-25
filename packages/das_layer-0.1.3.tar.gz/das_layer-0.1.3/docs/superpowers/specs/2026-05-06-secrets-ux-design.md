# v0.1.2 — Secrets UX

- **Date:** 2026-05-06
- **Bundle issue:** [#12](https://github.com/mattiasthalen/das-cli/issues/12)
- **Sub-issues:** [#7](https://github.com/mattiasthalen/das-cli/issues/7) (gitignore), [#8](https://github.com/mattiasthalen/das-cli/issues/8) (.env scaffold + per-source append)
- **Related ADR:** [ADR-0007](../../adrs/0007-secrets-via-env-var-jinja.md) (Jinja `env_var()` is the only secret mechanism)

## Goal

Make `.env`-based secrets safe and ergonomic out of the box. Today's `das init` neither scaffolds a `.env` nor gitignores one, so the canonical local-dev pattern (the only one ADR-0007 endorses) is undefended on a fresh workspace.

## Scope

Two scoped behavioral changes to existing CLI commands:

1. `das init` — extend the gitignore scaffold; add a `.env` scaffold; both behave correctly when files already exist.
2. `das source add` — generate per-source env-var names; append a per-source `.env` block.

No new commands, no new modules. All edits in `src/das_cli/cli.py` and corresponding tests.

## Non-goals

- No `.env` *parser* or loader — Jinja `env_var()` already reads from `os.environ`; populating `os.environ` from `.env` is the user's job (e.g. `direnv`, `dotenv` in shell, IDE integration). The scaffold is a head-start file, not a runtime input.
- No source-name validation tightening. `source_add` already accepts any string; we normalize for env-var purposes rather than reject.
- No `.dlt/secrets.toml` support. Out of scope per ADR-0007.

## Templates

Three module-level constants in `src/das_cli/cli.py`:

```python
GITIGNORE_SECRETS_BLOCK = """\
# Secrets — never commit
.env
.env.*
!.env.example
"""

GITIGNORE_TEMPLATE = """\
.dlt/
landing/
das.duckdb
*.duckdb.wal

""" + GITIGNORE_SECRETS_BLOCK

ENV_TEMPLATE = """\
# Workspace overrides (defaults work; uncomment to override)
# DAS_TARGET_DB=./das.duckdb
# DAS_LANDING_URL=./landing

# Source credentials — populated by `das source add`
"""
```

The `!.env.example` allow-pattern preserves the convention of committing a sanitized template `.env.example` showing required vars without values.

## `das init` behavior

The command runs four ordered checks; each prints a single `info(...)` line indicating which path was taken.

1. **`das.yaml`** — unchanged: write `DAS_YAML_TEMPLATE`; refuse if it exists unless `--force`.
2. **`contracts/`** — unchanged: `mkdir -p`, drop a `.gitkeep`.
3. **`.gitignore`** — three branches:
   - Missing → write `GITIGNORE_TEMPLATE`. → `info("wrote .gitignore")`.
   - Present, does **not** already ignore `.env` → append `\n` + `GITIGNORE_SECRETS_BLOCK`. → `info("appended secrets block to .gitignore")`.
   - Present, already ignores `.env` → no change. → `info(".gitignore already ignores .env; not modified")`.

   "Already ignores" detection: read the file, split into lines, treat any line whose stripped form equals `.env` (and is not a comment) as a hit. Pure pattern `.env` is the discriminator — `.env.*`, `!.env.example`, etc. don't count on their own. Detection function lives at module scope so tests can target it directly.

4. **`.env`** — two branches:
   - Missing → write `ENV_TEMPLATE`. → `info("wrote .env")`.
   - Present → leave untouched, **even with `--force`**. → `info(".env exists; not modified")`.

`--force` continues to control only `das.yaml` overwrite. It has no effect on `.gitignore` (idempotent append) or `.env` (never overwritten).

## `das source add` behavior

Three changes, all in `src/das_cli/cli.py`:

### 1. Env-var name normalization

A small helper `_source_env_prefix(name: str) -> str`:

- Uppercase the input.
- Replace any run of `[^A-Z0-9]+` with `_`.
- Strip leading and trailing `_`.

Examples: `northwind` → `NORTHWIND`, `my-source` → `MY_SOURCE`, `acme.api` → `ACME_API`. Empty result (e.g. name was all punctuation) is treated as a usage error in `source_add` — `die("source name has no alphanumeric characters", code=USAGE)`.

### 2. `_source_yml_template` takes the source name

Signature becomes `_source_yml_template(name: str, source_type: str, url: str, auth_type: str)`. Env-var names switch from generic `TOKEN` / `USERNAME` / `PASSWORD` / `API_KEY` to `<PREFIX>__TOKEN` / `<PREFIX>__USERNAME` / `<PREFIX>__PASSWORD` / `<PREFIX>__API_KEY`, where `<PREFIX>` is the normalized source name and the separator is **double underscore**.

Example for `northwind --auth bearer`:

```yaml
auth:
  type: bearer
  token: "{{ env_var('NORTHWIND__TOKEN') }}"
```

### 3. Append per-source block to `.env`

After `_source.yml` is written, run `_append_source_env_block(name, auth_type)`:

- If `auth_type == "none"` → return immediately (no secrets to declare).
- If `.env` is missing → create it with `ENV_TEMPLATE`.
- Compose the per-source block:

  ```
  
  # <name> (<auth_type>)
  <PREFIX>__TOKEN=
  ```

  (Lead with one blank line to space it from prior content. `bearer` → 1 var. `basic` → 2 vars `<PREFIX>__USERNAME` and `<PREFIX>__PASSWORD`. `api_key` → 1 var `<PREFIX>__API_KEY`.)

- **Idempotent append:** before writing, scan the existing `.env` for the literal header line `# <name> (<auth_type>)`. If found, skip and `info(".env already contains <name> block; not modified")`. Otherwise, append and `info("appended <name> block to .env")`.

The header includes the auth type so re-running with a different `--auth` (which the existing "source already exists" guard rejects today, but might change in future) would still be detected as distinct.

## File-level summary of changes

| File | Change |
|---|---|
| `src/das_cli/cli.py` | Add `ENV_TEMPLATE`, `GITIGNORE_SECRETS_BLOCK`, refactor `GITIGNORE_TEMPLATE`. Refactor `init` to handle existing `.gitignore` + scaffold `.env`. Add `_source_env_prefix`, `_append_source_env_block`, `_gitignore_already_covers_env`. Update `_source_yml_template` signature and `source_add` to call it with the name + append to `.env`. |
| `tests/integration/test_cli_init.py` | Extend with `.env` and `.gitignore` cases (see below). |
| `tests/integration/test_cli_source_add.py` | Extend with `.env` append cases for each non-`none` auth type, and idempotency. |

No changes to ADRs (ADR-0007 already establishes the mechanism; the env-var-naming convention is implementation detail, not architectural).

## Tests

Following ADR-0010 (tests live in this repo). All new tests are integration tests using the existing `workspace` + `cli_runner` fixtures.

**`das init`:**

- `test_init_writes_env_when_missing` — fresh dir, run `init`, assert `.env` exists with workspace-override comments.
- `test_init_does_not_overwrite_existing_env` — pre-create `.env` with sentinel content, run `init`, assert content unchanged.
- `test_init_force_does_not_overwrite_env` — same with `--force`.
- `test_init_writes_gitignore_with_secrets_block` — fresh dir, run `init`, assert `.env`, `.env.*`, `!.env.example` all present.
- `test_init_appends_secrets_block_to_existing_gitignore` — pre-create `.gitignore` with only `node_modules/`, run `init`, assert original line preserved + secrets block appended.
- `test_init_leaves_gitignore_untouched_when_env_already_ignored` — pre-create `.gitignore` containing `.env`, run `init`, assert no append (file unchanged byte-for-byte).

**`das source add`:**

- `test_source_add_uses_namespaced_env_vars` — bearer auth, assert generated `_source.yml` references `<NAME>__TOKEN`.
- `test_source_add_appends_env_block_bearer` — assert `.env` exists post-run with `# <name> (bearer)` header and `<NAME>__TOKEN=`.
- `test_source_add_appends_env_block_basic` — same for `_USERNAME` + `_PASSWORD`.
- `test_source_add_appends_env_block_api_key` — same for `_API_KEY`.
- `test_source_add_none_auth_does_not_touch_env` — `--auth none`, assert `.env` either absent or unchanged.
- `test_source_add_creates_env_when_missing` — delete the `.env` written by `init` first, then run `source add`, assert `.env` is recreated from `ENV_TEMPLATE` plus the per-source block.
- `test_source_add_normalizes_source_name_for_env_var` — name `my-source` produces `MY_SOURCE__TOKEN`.

**Unit-level helpers:**

- `test_source_env_prefix` — table-driven check for the normalization function (`northwind`, `my-source`, `acme.api`, empty-after-normalize, leading/trailing punctuation).
- `test_gitignore_already_covers_env` — a few `.gitignore` shapes including the comment-only false positive.

## Acceptance criteria (from the issues)

From #7:
- [x] `.gitignore` produced by `das init` contains `.env`, `.env.*`, `!.env.example` allow-pattern.
- [x] Existing entries (`.dlt/`, `landing/`, `das.duckdb`, `*.duckdb.wal`) preserved.
- [x] One integration test verifies `.env` is ignored after `das init`.

From #8:
- [x] `das init` writes a `.env` if none exists.
- [x] `das init` (and `das init --force`) does not overwrite an existing `.env`.
- [x] `das source add <name> --auth <non-none>` appends a per-source block and uses `<NAME_UPPER>__<KIND>` env-var names in the generated `_source.yml`.
- [x] `.env` is gitignored (relies on #7 — same bundle).

Bundle-level addition (not in the original issues, surfaced during brainstorm):
- [x] `das init` does **not** silently leave `.env` exposed when run in a directory that already has a `.gitignore`. The init flow appends the secrets block to an existing `.gitignore` if it doesn't already ignore `.env`.

## Risk and rollback

Low risk. All behavior changes are scaffolding-time only; no runtime/load-path code touched. Rollback is reverting the commits.

The one behavioral subtlety to watch: appending to a user-edited `.gitignore`. The detection rule errs on the side of *not* appending (we only append when no plain `.env` line is present), so the worst case is a redundant append — easily noticed and removed by the user.
