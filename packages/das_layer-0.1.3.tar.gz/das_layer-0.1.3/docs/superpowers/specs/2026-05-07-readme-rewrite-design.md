# README rewrite — design

- **Status:** Draft
- **Date:** 2026-05-07
- **Branch:** `claude/readme-contributions-EDecF`

## Context

The current `README.md` is ~38 lines: status, quickstart, dev commands, and a
license pointer. It does not pitch what das-cli is or how it differs from
plain dlt or other ELT tooling, and it predates several architectural ADRs
that now define the project (contracts as truth, P1/P2 split, hive-partitioned
landing, row-hash change detection in P2).

The repo already has rich contributor-facing material — `CLAUDE.md`,
`docs/adrs/`, `docs/superpowers/specs/`, `docs/superpowers/plans/` — and a
public CI pipeline. The README needs to act as the project's storefront for
prospective users while pointing curious contributors at the existing depth
without restating it.

A separate `CONTRIBUTING.md` was considered and explicitly rejected: process
guidance lives in `CLAUDE.md`; ADR lifecycle is documented there; design and
plan structure is self-evident in `docs/superpowers/`. Duplicating any of
that into `CONTRIBUTING.md` would create drift.

## Goals

- Lead with the differentiator: contract-driven, schemas frozen and
  projected (not inferred).
- Scope expectations: das-cli is the raw→staging boundary, not an ELT
  modeler.
- Give a reader the architectural mental model in 30 seconds before any
  command.
- Keep dev commands discoverable for casual contributors (no forced
  click-through to `CLAUDE.md` for `uv sync`).
- Be honest about which source/destination combinations are actually
  verified vs. "should work via dlt", and turn the unverified surface into a
  contribution funnel via GitHub issues.
- Anchor every concept and pipeline step to its ADR so the README stays
  thin and the ADRs remain the source of truth.

## Non-goals

- A `CONTRIBUTING.md` file. Process lives in `CLAUDE.md`.
- A comparison table vs. dlt / Meltano / Airbyte.
- Screenshots, asciicasts, or animated demos.
- Any duplication of ADR content. The README links; the ADRs explain.
- Restating the spec/plan/ADR workflow for human contributors. Pointers
  only.

## Design

### Section order

1. Title
2. Tagline
3. Badges (PyPI, Python versions, CI, License)
4. What it is / what it isn't
5. How it works (3-step P1/P2 mental model)
6. Quickstart
7. Concepts
8. Sources & destinations
9. Development
10. Documentation
11. License

The earlier draft included a separate "Status & versioning" section; that
was dropped because the PyPI/CI badges carry the same signal without
narrative.

### Tagline

> Contract-driven ingestion for the raw→staging boundary, built on dlt.

### Badges

Four badges, in this order: PyPI version, Python versions, CI status,
License.

- PyPI: `https://img.shields.io/pypi/v/das-cli.svg` → `https://pypi.org/project/das-cli/`
- Python versions: `https://img.shields.io/pypi/pyversions/das-cli.svg` → `https://pypi.org/project/das-cli/`
- CI: `https://github.com/mattiasthalen/das-cli/actions/workflows/ci.yml/badge.svg` → workflow URL
- License: `https://img.shields.io/github/license/mattiasthalen/das-cli.svg` → `LICENSE`

(`ci.yml` confirmed as the workflow file name.)

### What it is / what it isn't

Two short paragraphs, ~80 words total.

> das-cli lands raw source data into a compressed JSONL landing zone, then
> promotes it into a contract-enforced DuckDB warehouse. ODCS v3 contracts
> are the single source of truth for schema, types, and keys — schemas are
> *frozen and projected*, not inferred at load time.
>
> It is scoped to the DAS layer: lossless landing and contract-projected
> staging. It is *not* an ELT modeling tool. Transformations, business
> logic, and downstream modeling belong in the layers above (dbt, SQLMesh,
> etc.).

### How it works

Three numbered steps, each with parenthetical ADR references.

1. **Bootstrap a contract** — point das-cli at an OData service or OpenAPI
   spec; it emits an editable ODCS v3 contract per resource, plus a
   `_source.yml` for connection details. (ADR-0005, ADR-0006, ADR-0015.)
2. **P1 — land** — extract raw records into a compressed JSONL landing
   zone under `./landing/`, hive-partitioned by extract date. Each row is
   stored as a `_data: json` blob — lossless, no schema applied. (ADR-0002,
   ADR-0003.)
3. **P2 — promote** — project the JSONL blobs into contract-enforced
   DuckDB staging tables. Schemas are frozen against the ODCS contract.
   Loads are append-only with row-hash change detection: each row's hash is
   compared against the latest hash per primary key in the destination,
   and only changed rows are appended. (ADR-0004, ADR-0008, ADR-0012.)

P1/P2 vocabulary is intentional: it matches the code, ADRs, and CLI output
so the README's terms are consistent with the rest of the project.

### Quickstart

The current README's command block, with two polish edits:

- Line-break the `das source add` invocation so it does not horizontal-scroll
  on narrow terminals or GitHub mobile.
- Replace the single-line outcome description with two bullets that connect
  back to the P1/P2 mental model:
  - raw JSONL lands in `./landing/`, hive-partitioned by extract date
  - contract-enforced staging tables live in `./das.duckdb`

### Concepts

Six bullets, each one or two sentences, each ADR-anchored. Order chosen so
each bullet introduces vocabulary used by the next:

1. **Contract** — ODCS v3 YAML per resource. (ADR-0005, ADR-0012.)
2. **`_source.yml`** — per-source connection config. (ADR-0005.)
3. **`das.*` custom properties** — namespace for ODCS extensions. (ADR-0011,
   ADR-0014.)
4. **Landing zone** — `./landing/<source>/<resource>/_extracted_on=YYYY-MM-DD/`,
   compressed JSONL, hive-partitioned. (ADR-0002, ADR-0013.)
5. **P1 / P2 pipelines** — extract and load. (ADR-0002, ADR-0008.)
6. **Secrets** — Jinja `env_var(...)` in `_source.yml`. (ADR-0007.)

The ODCS link in bullet 1 points to the public spec
(`https://bitol-io.github.io/open-data-contract-standard/`).

### Sources & destinations

One short framing paragraph, one verified table, one CTA.

- **Framing:** das-cli is built on dlt; in principle any dlt source or
  destination should work, but only the combinations exercised by the test
  suite count as "verified".
- **Verified table:**

  | Source | Destination | Notes |
  |---|---|---|
  | OData v2 / v4 | DuckDB | OData metadata bootstrap (ADR-0006) |
  | OpenAPI / REST | DuckDB | Per-resource `das.endpoint` (ADR-0014, 0015) |

- **CTA:** "Open an issue describing the source and destination you'd like
  to use." Link target: `https://github.com/mattiasthalen/das-cli/issues/new`
  (no preset labels, since labels can be added later without breaking the
  link).

### Development

Four commands plus a one-line pointer to deeper docs.

```bash
uv sync
uv run pytest                       # unit + integration
uv run pytest -m e2e                # opt-in; hits public AdventureWorks/Northwind APIs
uv run pre-commit run --all-files
```

> For architectural context (decision records, design specs, implementation
> plans), see the **Documentation** section below and `CLAUDE.md`.

### Documentation

Four bulleted pointers, ordered by the question each answers:

- `docs/adrs/` (linked, with link to its index) — *why is it built this way?*
- `docs/superpowers/specs/` — *what's planned / shipped?*
- `docs/superpowers/plans/` — *how is it being built?*
- `CLAUDE.md` — *what are the rules?*

### License

Unchanged: a one-line pointer to `LICENSE`.

## Alternatives considered

- **Single combined README + contributor doc.** Rejected: the storefront
  audience (data engineers evaluating das-cli) and the contributor audience
  have different first questions; mixing them buries the pitch behind dev
  setup.
- **Separate `CONTRIBUTING.md`.** Rejected: every section we drafted for
  it would either restate `CLAUDE.md` (the workflow, the ADR lifecycle) or
  duplicate three lines of dev commands that are more useful in the README.
  The dev commands moved back into the README; the workflow stays
  exclusively in `CLAUDE.md`.
- **Workflow-prescriptive README** (require spec/plan/ADR for all
  non-trivial PRs). Rejected: `CLAUDE.md` already encodes the rule, and the
  decision of which artifacts a contribution needs is contextual; baking
  it into the README would either oversimplify or overspecify.
- **Comparison table vs. dlt / Meltano / Airbyte.** Rejected: comparisons
  date quickly, invite arguments unrelated to the project, and the
  positioning paragraph already does the necessary differentiation work.
- **Conservative "verified-only" sources section** (no mention of the
  broader dlt surface). Rejected: under-promises and hides the real
  capability surface; the verified + dlt-pointer + issue-CTA framing is
  honest and turns the unknown into a contribution funnel.
- **Status & versioning section.** Rejected: the PyPI and CI badges carry
  the same signal without narrative bloat.

## Consequences

- The README becomes ~5x longer (~150–180 lines vs. 38), with the cost
  concentrated in concepts and the architecture mental model — both of
  which materially help an evaluator decide whether das-cli fits.
- Every concept and pipeline step is anchored to an ADR. ADRs become the
  long-form reference; the README stays a directory.
- The "verified" framing creates a small ongoing maintenance task: when a
  new source/destination combination gains an e2e test, the table must be
  updated. This is acceptable — the table is short and the update is
  one-line.
- The README references ADR numbers (ADR-0005, ADR-0014, etc.) inline. If
  ADRs are renumbered in the future (which the lifecycle in `CLAUDE.md`
  forbids on main but allows on feature branches), README references must
  be updated in the same PR. Issue #21 captures the existing inconsistency
  in `docs/adrs/README.md` from the recent renumber and is out of scope
  for this rewrite.
- Removing the `## Status` section means the badge row carries the
  pre-stable signal. Until the package is published to PyPI, the PyPI
  badge will show "no releases" — this is the desired pre-stable signal,
  not a defect.

## Out of scope

- Publishing to PyPI. The badges assume the package is or will be
  published as `das-cli`; first release is a separate workstream.
- Fixing `docs/adrs/README.md` index drift — tracked in issue #21.
- Adding a `CONTRIBUTING.md`, `CODE_OF_CONDUCT.md`, issue templates, or
  PR templates. These are separate decisions and not requested.
- Comparison tables, asciicasts, demo videos.
