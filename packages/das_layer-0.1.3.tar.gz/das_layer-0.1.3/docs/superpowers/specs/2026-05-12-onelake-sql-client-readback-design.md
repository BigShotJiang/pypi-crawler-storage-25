# OneLake read-back via `pipeline.sql_client()` — design

**Issue:** #55
**Date:** 2026-05-12
**Related:** ADR-0020, PR #54, ADR-0016, ADR-0004

## Summary

PR #54 made writes to OneLake-backed Delta work end-to-end. Reads through
`pipeline.sql_client()` still fail with `401 Unauthorized` because DuckDB's Azure
extension is a third credential surface that das-cli does not configure.

This design adds a small helper, `open_sql_client(pipeline, bucket_url=, azure=)`,
that wraps `pipeline.sql_client()` and — for Fabric URLs only — issues a
`CREATE OR REPLACE SECRET ... TYPE AZURE PROVIDER ACCESS_TOKEN` after dlt opens
the DuckDB connection. The secret carries a freshly-acquired storage-audience
bearer token and `ACCOUNT_NAME 'onelake'`, which together route DuckDB's
`delta_scan` to the OneLake blob endpoint with a valid Bearer header.

`change_detection.load_latest_hash` and the gated e2e reader switch to the
helper. Non-Fabric paths (local Delta, ADLS Gen2 SP, ADLS Gen2 default) get a
pass-through no-op — dlt's native secret emission already handles them.

## Problem

`pipeline.sql_client()` against an OneLake-backed Delta table fails with:

```
DeltaKernel ObjectStoreError (8): The operation lacked valid authentication
credentials for path .../products/_delta_log/_last_checkpoint
Server returned non-2xx status code: 401 Unauthorized
  Authentication Failed with Bearer token is not present in the request
```

Two production-relevant code paths hit this:

1. **Second-cycle `das ingest` on OneLake.** `change_detection.load_latest_hash`
   reads prior `_row_hash` values via `pipeline.sql_client()` for incremental
   loads. First load short-circuits via `DatabaseUndefinedRelation`; second
   load issues a real `SELECT` and 401s.
2. **Read-back assertions** in `tests/e2e/destinations/test_delta_azure.py`.

### Root cause

For OneLake URLs, das-cli passes
`AzureCredentialsWithoutDefaults(azure_storage_account_name="onelake",
azure_account_host="onelake.blob.fabric.microsoft.com",
azure_storage_sas_token=_FABRIC_SAS_PLACEHOLDER)`
to dlt — the placeholder satisfies dlt's config resolver while the real auth
flows through `kwargs={"credential": <SDK credential>}` for adlfs and through
`deltalake_storage_options={"bearer_token": ...}` for the Rust writer.

When `sql_client()` is opened, dlt's `FilesystemSqlClient.create_secret`
runs (see `.venv/.../dlt/destinations/impl/duckdb/sql_client.py:264`) and
recognises `AzureCredentialsWithoutDefaults` as the "storage key" shape,
emitting:

```sql
CREATE OR REPLACE SECRET <dataset>_abfssonelakedfs... (
    TYPE AZURE,
    CONNECTION_STRING 'AccountName=onelake;AccountKey=fabric-credential-object-supplied-via-kwargs',
    SCOPE 'abfss://onelake.dfs.fabric.microsoft.com/<item>/...'
)
```

DuckDB accepts that string at CREATE time. The first `delta_scan(...)` then
issues an unauthenticated GET (no usable secret matches), and Fabric returns
401.

DuckDB's Azure extension auth is structurally separate from both adlfs (the
landing-write path) and `object_store_rs` (the Delta-write path); the
workarounds das-cli installs for those two surfaces don't reach DuckDB.

## Decision

### A. Helper module

Add a context-manager helper to `src/das_cli/dlt_glue/azure_credentials.py`:

```python
@contextlib.contextmanager
def open_sql_client(
    pipeline: dlt.Pipeline,
    *,
    bucket_url: str | None,
    azure: AzureServicePrincipalAuth | AzureDefaultAuth | None,
) -> Iterator[Any]:
    """`pipeline.sql_client()` with Fabric-aware DuckDB auth.

    For Fabric URLs, overwrites dlt's emitted Azure secret with a working
    `PROVIDER ACCESS_TOKEN` secret. No-op for non-Fabric URLs and for
    non-`delta` destinations (whose sql_client doesn't open Azure secrets).
    """
    with pipeline.sql_client() as c:
        if bucket_url and azure and is_fabric_url(bucket_url):
            _install_fabric_duckdb_secret(c, bucket_url=bucket_url, azure=azure)
        yield c
```

The internal helper emits:

```sql
CREATE OR REPLACE SECRET das_fabric_<sanitized_scope> (
    TYPE AZURE,
    PROVIDER ACCESS_TOKEN,
    ACCESS_TOKEN '<jwt>',
    ACCOUNT_NAME 'onelake',
    SCOPE '<bucket_url_without_container>'
)
```

The `<sanitized_scope>` follows dlt's own convention (`duckdb/sql_client.py:240`):
lower-case the scope and strip every non-letter character. Example: scope
`abfss://onelake.dfs.fabric.microsoft.com/<item>/Tables/...` →
`abfssonelakedfsfabricmicrosoftcomitemTables`. Prefixed with `das_fabric_` so
the secret name does not collide with dlt's `<dataset>_<sanitized>` secret.
Both secrets can coexist; DuckDB picks the longest matching SCOPE per request.

Token acquired via the existing `_acquire_storage_bearer_token(azure)` (promoted
from `_`-private to public: `acquire_storage_bearer_token`). Scope strips the
`<container>@` prefix to mirror dlt's internal convention
(`duckdb/sql_client.py:303`).

### B. Call-site plumbing

`change_detection.load_latest_hash` gains two optional kwargs:

```python
def load_latest_hash(
    *,
    pipeline: dlt.Pipeline,
    dataset: str,
    table: str,
    primary_key: list[str],
    bucket_url: str | None = None,
    azure: AzureServicePrincipalAuth | AzureDefaultAuth | None = None,
) -> dict[tuple[Any, ...], str]:
    ...
    with open_sql_client(pipeline, bucket_url=bucket_url, azure=azure) as client:
        rows = client.execute_sql(sql) or []
```

`pipelines/load.py:_build_load_resource` receives `bucket_url` and `azure`
(both already computed in `_build_destination`) and forwards them to
`load_latest_hash`. `run_load` extracts them once when constructing the
destination and threads them through.

### C. Tests

- **Unit** (extend `tests/unit/test_azure_credentials.py`): mock dlt's
  sql_client and `acquire_storage_bearer_token`; assert the emitted SQL string
  for the OneLake branch contains `TYPE AZURE`, `PROVIDER ACCESS_TOKEN`,
  `ACCOUNT_NAME 'onelake'`, the masked token, and the container-stripped
  scope (e.g. `abfss://onelake.dfs.fabric.microsoft.com/<item>/...`, no
  `<workspace>@` prefix — mirrors how dlt itself strips scopes in
  `duckdb/sql_client.py:303`). Assert *no* CREATE SECRET is issued for
  `abfss://acct.dfs.core.windows.net/...` (standard ADLS Gen2) or for
  `./local/path` (no `azure`).
- **Integration** (`tests/integration/test_load_pipeline_delta.py`,
  `test_load_pipeline_ducklake.py`): unchanged — they continue to prove the
  non-Fabric no-op.
- **E2E** (`tests/e2e/destinations/test_delta_azure.py`, opt-in): the
  read-back assertions inside `_azure_reader_pipeline(...).sql_client()` get
  wrapped in `open_sql_client(...)`. The second-cycle change-detection
  assertion now exercises the same code path that production `das ingest`
  exercises.

### D. New ADR-0021 superseding ADR-0020

ADRs in this project are immutable post-merge — even Consequences sections.
The only in-place edit allowed is the Status field. To record the resolved
DuckDB read-back gap, author a new ADR-0021 that supersedes ADR-0020 and
restates the operative pieces verbatim.

The work:

- Create `docs/adrs/0021-onelake-duckdb-readback-via-access-token-secret.md`
  with `Status: Supersedes ADR-0020`, `Date: 2026-05-12`, Context section
  summarising ADR-0020's three-surface picture (adlfs / object_store / DuckDB)
  and noting that the DuckDB surface was left as a follow-up, Decision section
  describing the `open_sql_client` helper and the
  `PROVIDER ACCESS_TOKEN ACCOUNT_NAME 'onelake'` secret shape, Alternatives
  Considered restating Approach A vs B vs C from the spec, and Consequences
  describing the three-surface workaround as a stable triple.
- Flip ADR-0020 Status from `Accepted` to `Superseded by ADR-0021` (the only
  in-place edit allowed on a merged ADR).
- Add the ADR-0021 row to `docs/adrs/README.md` and update the ADR-0020 row's
  Status column.
- The Decision/Context of ADR-0021 restates the operative pieces of ADR-0020
  (so the doc tree is internally complete without back-references) plus the
  new DuckDB decision. ADR-0020 stays in the repo as historical record.

ADR-0021 is narrowly named after the new decision but operationally
supersedes ADR-0020 in full per the project's binary supersession convention
(`Status: Accepted | Superseded by ADR-MMMM`). Pointer comments in code that
reference ADR-0020 may be updated opportunistically to point at ADR-0021 when
touched, but a sweep is out of scope.

## Alternatives considered

- **DuckDB environment variables (`AZURE_*` / `AZURE_STORAGE_CONNECTION_STRING`).**
  Doesn't carry a bearer token — DuckDB's variable-based Azure config is the
  legacy path and has no ACCESS_TOKEN slot. Leaks across pipelines/tests in
  the same process. Rejected.
- **Open a separate `duckdb.connect()` bypassing dlt entirely.** Doubles the
  read path for the OneLake case only and breaks destination-agnosticism in
  `change_detection.py` that ADR-0016 deliberately preserved. Doesn't help
  the e2e test which legitimately uses `pipeline.sql_client()`. Rejected.
- **Overwrite dlt's existing secret in place** (same name) rather than
  publishing a new `das_fabric_*` secret. Equivalent end state but couples to
  dlt's internal secret-naming convention
  (`<dataset_name>_<sanitized_bucket>`). Brittle if dlt changes that scheme.
  Rejected.
- **Persist the secret to disk** (`PERSISTENT` modifier). Tokens are
  short-lived (~1h) so persistence has no value. Rejected.
- **Refresh the token inside the helper** if it expires mid-read. Out of
  scope; `change_detection.load_latest_hash` issues exactly one SELECT per
  resource per load and the token TTL is comfortably long enough for that.
  Tracked as the same "long-running pipelines may hit token expiry"
  limitation already documented in ADR-0020 for the `deltalake_storage_options`
  bearer_token. Same shape, no new constraint.
- **Make `open_sql_client` destination-aware** (skip the Fabric branch for
  duckdb/ducklake destinations). Already implicit: the helper checks
  `is_fabric_url(bucket_url)`, which is False whenever `bucket_url` is None
  (duckdb/ducklake never pass one). No extra dispatch needed.

## Acceptance criteria

- `tests/e2e/destinations/test_delta_azure.py` passes end-to-end against real
  Fabric for both `service_principal` and `default` auth parametrisations,
  including the read-back COUNT and the second-cycle no-op.
- `pytest tests/unit/dlt_glue/test_azure_credentials.py` passes — new SQL-shape
  assertions plus the existing helpers.
- `pytest tests/integration/test_load_pipeline_delta.py
  tests/integration/test_load_pipeline_ducklake.py` continue to pass against
  local Delta and DuckLake (no regression in non-Azure destinations).
- `pytest tests/integration` and `pytest tests/e2e` (non-Azure subset) green;
  `ruff` and `mypy` clean.
- ADR-0020 Consequences bullet updated; `docs/adrs/README.md` row unchanged
  (title doesn't change).

## Out of scope

- Token refresh / long-running pipeline support.
- DuckDB `delta_scan` against S3 or GCS (no verified slice; out of scope per
  ADR-0017 and ADR-0020).
- `doctor` checks for the DuckDB-read path (matches the rest of doctor's
  config-typo-only contract).
- Persistent / cross-process DuckDB secrets.
- Refactoring `change_detection.load_latest_hash` to use a destination
  dispatch table — destination-agnosticism via `pipeline.sql_client()` is
  what ADR-0016 mandates.

## File summary

| File | Change |
|---|---|
| `src/das_cli/dlt_glue/azure_credentials.py` | Add `open_sql_client`, `_install_fabric_duckdb_secret`, rename `_acquire_storage_bearer_token` → `acquire_storage_bearer_token`. |
| `src/das_cli/pipelines/change_detection.py` | `load_latest_hash` accepts `bucket_url=` and `azure=`, uses `open_sql_client`. |
| `src/das_cli/pipelines/load.py` | Capture parsed `azure` + `bucket_url` once in `_build_destination`; thread them through `_build_load_resource` → `load_latest_hash`. |
| `tests/unit/test_azure_credentials.py` | New SQL-shape assertions for the Fabric / non-Fabric branches (extend existing file). |
| `tests/e2e/destinations/test_delta_azure.py` | Reader uses `open_sql_client(...)`. |
| `docs/adrs/0021-onelake-duckdb-readback-via-access-token-secret.md` | New ADR; Supersedes ADR-0020; restates A/B/C/D + adds DuckDB read-back decision. |
| `docs/adrs/0020-azure-landing-and-delta-via-fsspec-and-typed-credentials.md` | Status field flip only: `Accepted` → `Superseded by ADR-0021`. |
| `docs/adrs/README.md` | Add ADR-0021 row; update ADR-0020 row's Status column. |
