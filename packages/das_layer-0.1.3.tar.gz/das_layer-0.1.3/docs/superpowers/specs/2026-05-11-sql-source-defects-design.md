# SQL source defects (issue #47): `--full` semantics + `decimal` round-trip

- **Date:** 2026-05-11
- **Tracks:** [#47](https://github.com/mattiasthalen/das-cli/issues/47), [#43](https://github.com/mattiasthalen/das-cli/issues/43), [#45](https://github.com/mattiasthalen/das-cli/issues/45)
- **Branch:** `claude/brainstorm-das-cli-defects-TjkZY`

## Context

PR #42 (Verify Oracle + SQL Server sources) surfaced two pre-existing defects on
the SQL source path:

1. **#43** — `extract --full` does not produce a fresh landing payload. The
   current implementation wipes only local `.dlt/pipelines/das_extract__<source>/`
   state. The destination-side state files in `landing/<source>/_dlt_pipeline_state/`,
   `_dlt_loads/`, `_dlt_version/` persist across runs. dlt re-derives the same
   pipeline-state hash, finds it already-loaded at the destination, and reports
   `0 rows`. The integration test was forced into a loose assertion to stay
   green.
2. **#45** — `decimal(p,s)` columns with non-zero scale fail P2 with a frozen
   schema variant error. Drivers (`oracledb`, `pyodbc`) return `decimal.Decimal`;
   dlt's JSON encoder serialises `Decimal` as a quoted string in the JSONL blob
   (Python `json` has no native Decimal); P2 reads the string and hands a `str`
   to dlt for a column declared `data_type=decimal`. The frozen contract rejects
   the variant and the load fails with:

   ```
   NormalizeJobFailed: ... Column: `amount__v_text`.
   Contract on `data_type` with `contract_mode=freeze` is violated.
   ```

Both issues touch the SQL extract code path and the same e2e fixtures. Bundling
them avoids two rounds of Oracle / SQL Server container churn.

A deeper redesign emerged during brainstorming: `--full` was conflating two
distinct concerns. The fix is not just to make `--full` work as previously
specified — it is to split the flag into a P1 cursor-state reset and a P2
table-replace, with each side having a single, unambiguous job.

## Decision

### `--full` semantics: split between extract and load

**`das extract --full`** resets the dlt incremental cursor state for the named
source(s). Landing data is **not** touched. The next extract pulls source rows
from the beginning and appends a new load_id to landing. Implementation: wipe
`.dlt/pipelines/das_extract__<source>/` (already done) **and** wipe
`<bucket_url>/<source>/_dlt_pipeline_state/`, `_dlt_loads/`, `_dlt_version/`
directories (new). The table data directories under
`<bucket_url>/<source>/<table>/...` are left intact — landing remains an
append-only archive.

**`das load --full`** replaces the destination table by replaying every landing
file through the contract. Per-resource behaviour change when `full=True`:

1. `write_disposition="replace"` instead of `"append"` — dlt truncates and
   inserts.
2. Skip `ChangeDetectionFilter` — every landing row reaches dlt, not just
   new/changed.

**`das ingest`** keeps the orchestration role but exposes the split explicitly:
`--extract-full` and `--load-full` flags forward independently. The composite
`--full` on ingest is removed because it would hide the distinct semantics.

### `decimal(p,s)` round-trip: lossless str ↔ Decimal at P2

P1 stays unchanged. dlt continues to serialise `Decimal` as a quoted string in
JSONL — that is fine and consistent. The fix is in P2's projection step
(`pipelines/load.py::_project_record`): for each `OdcsProperty` whose contract
declares `logicalType=number` and a `physicalType` matching
`decimal(p,s)`, parse the incoming value into `Decimal` before yielding to dlt.

Implementation detail: `dlt_glue/schema_factory.py::_DECIMAL_RE` is moved to a
small shared helper module (or re-exported) so projection and column-hint code
share a single source of truth for the regex. The coerce function accepts
`str | int | float | Decimal | None` and normalises via `Decimal(str(value))` to
avoid float-binary precision artefacts.

## Architecture

### Touch points

| Concern | File | Change |
|---|---|---|
| P1 cursor reset | `pipelines/extract.py` | New `reset_extract_state(source_name, config_path)` helper. Wipes the four `_dlt_*` dirs locally and at landing. |
| P1 CLI | `cli.py::extract` | `--full` now calls `reset_extract_state` instead of inlining `shutil.rmtree`. Help text updated. |
| P2 table replace | `pipelines/load.py::run_load`, `_build_load_resource` | New `full: bool` param. When true: `write_disposition="replace"`, no `ChangeDetectionFilter`. |
| P2 CLI | `cli.py::load` | New `--full` option, threaded through `run_load(full=full)`. |
| Ingest CLI | `cli.py::ingest` | Replace `--full` with `--extract-full` and `--load-full`; forward each independently. |
| Decimal coerce | `pipelines/load.py::_project_record` (or sibling helper) | For decimal columns, `coerce_decimal(value)` before assignment. |
| Shared helper | `dlt_glue/schema_factory.py` | Add `coerce_decimal` and `is_decimal_column(prop)` next to the existing `_DECIMAL_RE`. `pipelines/load.py` imports both. |
| ADR | `docs/adrs/0018-sql-source-via-sqlalchemy.md` | Append a Consequences bullet on the `decimal` round-trip cost (one parse per cell). |
| ADR (new) | `docs/adrs/0019-full-flag-semantics.md` | Document the split. See "ADR-0019" below. |
| Fixtures | `tests/e2e/fixtures/sql_seed_oracle.sql`, `sql_seed_sqlserver.sql` | Restore `amount` to `NUMBER(12,2)` / `DECIMAL(12,2)`. Drop the workaround comment block. |

### `reset_extract_state` behaviour

```
reset_extract_state(source_name, config_path):
    1. local = Path(".dlt/pipelines") / f"das_extract__{source_name}"
       if local.exists(): shutil.rmtree(local)
    2. landing_root = resolve from das.yaml landing.bucket_url
       source_landing = landing_root / source_name
       for sub in ("_dlt_pipeline_state", "_dlt_loads", "_dlt_version"):
           p = source_landing / sub
           if p.exists(): shutil.rmtree(p)
```

For non-local landing (`s3://`, `gs://`, `az://`), v0.1 raises a clear
`NotImplementedError("--full reset on remote landing not supported in v0.1")`
rather than silently no-op-ing. Local landing is the only currently-tested
shape; remote support can land with the broader cloud-landing work.

### `coerce_decimal` shape

```python
def coerce_decimal(value: object) -> Decimal | None:
    if value is None:
        return None
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))  # str() avoids float-binary artefacts
```

Wired into `_project_record` keyed off the per-property contract:

```python
for prop in schema.properties:
    raw_value = ...  # existing path resolution
    if _is_decimal_column(prop):
        out[prop.name] = coerce_decimal(raw_value)
    else:
        out[prop.name] = raw_value
```

`_is_decimal_column(prop)` is `prop.logicalType == "number" and
_DECIMAL_RE.match(prop.physicalType or "")`.

## ADR-0019 (new): `--full` semantics split

Filed alongside this spec because the split is a contract change with
alternatives worth recording. Skeleton:

- **Status:** Accepted
- **Decision:** `--full` on `extract` resets dlt cursor state only; `--full` on
  `load` replaces the destination table. `ingest` exposes both as
  `--extract-full` and `--load-full`.
- **Alternatives considered:**
  - Composite `--full` on every command meaning "do the most refresh-y thing"
    — rejected: hides the distinction between source-side and destination-side
    refresh.
  - Use dlt's `refresh="drop_resources"` for both sides — rejected: it drops
    resource data, which violates "landing is append-only".
  - Surgically delete only the `_dlt_pipeline_state` file (not the whole dir)
    — rejected: dlt also tracks load-package state in `_dlt_loads`, and the
    cursor resync depends on the pair being consistent.
- **Consequences:** Locks in the four `_dlt_*` dir names as a contract surface
  with dlt's filesystem destination. A dlt upgrade that renamed those dirs
  would break `extract --full` loudly (we'd notice at first run) rather than
  silently. Acceptable tradeoff.

## Test plan

### Existing — update

- `tests/integration/test_extract_pipeline_sql.py::test_sql_extract_full_flag_replays_everything`
  → rename to `test_sql_extract_full_resets_cursor_and_replays_source`. Tighten
  the assertion to issue #43's preferred form:

  ```python
  loads_in_order = [by_load[k] for k in sorted(by_load)]
  assert len(loads_in_order) >= 2
  assert loads_in_order[0] == {1, 2}
  assert loads_in_order[1] == {1, 2}
  ```

### New — P2 `--full`

- `tests/integration/test_load_pipeline.py::test_load_full_replaces_destination_table`
  — Seed landing with two extract load_ids; run `load` (incremental) once to
  populate the destination; insert an out-of-band marker row directly into the
  destination; run `load --full`; assert:
  - The marker row is gone (table was replaced, not appended to).
  - Row count equals the count of rows that would result from a full
    contract-projected replay of all landing files.

### New — decimal round-trip

- `tests/integration/test_extract_pipeline_sql.py::test_sql_extract_decimal_with_scale_round_trips`
  — SQLite source with a `Numeric(12, 2)` column seeded with values like
  `Decimal("1234.56")`, `Decimal("0.01")`, `Decimal("99999999.99")`. Run
  `extract` then `load`. Assert destination values equal the seeded `Decimal`
  values exactly (no precision loss, no string leakage).
- `tests/unit/test_dlt_glue_types.py::test_coerce_decimal_handles_all_inputs`
  (new file or co-locate with existing dlt_glue tests) — covers `str → Decimal`,
  `int → Decimal`, `float → Decimal`, `Decimal → Decimal`, `None → None`.

### Fixtures

- `tests/e2e/fixtures/sql_seed_oracle.sql`: `amount NUMBER(12,2) NOT NULL`,
  workaround comments deleted.
- `tests/e2e/fixtures/sql_seed_sqlserver.sql`: `amount DECIMAL(12,2) NOT NULL`,
  workaround comments deleted.
- e2e tests `test_oracle.py`, `test_sqlserver.py` need no test-code changes —
  they should now exercise the real decimal path end-to-end.

## Acceptance criteria

From issue #47's Definition of Done, plus what this redesign adds:

- [ ] Issue #43's tightened assertion (above) passes against the renamed test.
- [ ] `das load --full` replaces the destination table from full landing replay
      (covered by the new integration test).
- [ ] `das ingest --extract-full --load-full` runs end-to-end and matches the
      effect of running `extract --full` then `load --full`.
- [ ] The decimal round-trip test passes with no precision loss.
- [ ] e2e fixtures restored to `NUMBER(12,2)` / `DECIMAL(12,2)`; workaround
      comments removed; Oracle and SQL Server e2e tests still pass.
- [ ] ADR-0018 Consequences updated with the decimal round-trip cost note.
- [ ] ADR-0019 filed and listed in `docs/adrs/README.md`.

## Out of scope

- Cloud landing (`s3://`, `gs://`, `az://`) support for `extract --full`. This
  spec keeps the local-landing scope of v0.1; remote support raises a clear
  `NotImplementedError`.
- HTTP source `--full` semantics (#43 notes "HTTP source path likely has the
  same limitation"). HTTP sources today don't wire dlt incremental into
  `_make_http_resource`, so cursor reset is effectively a no-op for them. The
  same `reset_extract_state` helper applies uniformly when called; no
  source-type-specific branching is needed in this spec.
- Custom-query SQL resources (deferred per ADR-0018).
- Decimal precision beyond what `str ↔ Decimal` round-trips handle (i.e., none
  — the chosen approach is lossless).
