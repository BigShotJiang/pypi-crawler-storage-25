# OData bootstrap driven by `<EntityContainer><EntitySet>`

- **Issue:** [#63](https://github.com/mattiasthalen/das-cli/issues/63)
- **Date:** 2026-05-13
- **Status:** Draft

## Problem

`bootstrap_odata_contracts()` walks every `<EntityType>` in `$metadata` and
emits one contract per type
(`src/das_cli/bootstrap/odata.py:171-180`). EDM, however, separates two
concerns:

- `<EntityType>` declares a *type* — its keys, properties, and
  navigation links to other types.
- `<EntityContainer><EntitySet>` declares the queryable *resources* exposed
  by the service. The set name is the URL segment served at runtime.

A schema can — and routinely does — declare EntityTypes that are not exposed
as EntitySets: link targets reached only through `NavigationProperty` /
`Collection(...)`, or join shapes that the service deliberately hides. The
bootstrap currently treats every EntityType as queryable. Contracts emitted
for unexposed types then 404 at extract time.

### Evidence (AdventureWorks demo OData, `main @ e32663e`)

Real ingest against the public AdventureWorks feed:

```bash
das source add adventure_works \
  --type odata \
  --url https://demodata.grapecity.com/adventureworks/odata/v1
das contract bootstrap adventure_works   # writes 66 contracts
das ingest adventure_works               # aborts at first 404
```

`$metadata` declares **59** EntitySets in `<EntityContainer>`. Bootstrap
emits **66** contracts. The 7 extras are EntityTypes that exist as types
only:

| Contract emitted                                       | In EntityContainer? | Live URL probe |
|--------------------------------------------------------|---------------------|----------------|
| `country_region_currencies.odcs.yaml`                  | no                  | HTTP 404       |
| `person_credit_cards.odcs.yaml`                        | no                  | HTTP 404       |
| `passwords.odcs.yaml`                                  | no                  | HTTP 404       |
| `product_model_product_description_cultures.odcs.yaml` | no                  | HTTP 404       |
| `sales_order_header_sales_reasons.odcs.yaml`           | no                  | HTTP 404       |
| `product_product_photos.odcs.yaml`                     | no                  | HTTP 404       |
| `special_offer_products.odcs.yaml`                     | no                  | HTTP 404       |

Combined with das-cli's all-or-nothing extract (one resource 404 aborts the
batch), the user has to manually delete each dead contract and re-`ingest`
until the batch survives. The remaining 58 ingest cleanly in ~4 minutes;
the pipeline is fine — bootstrap is the over-producer.

## Decision

Invert the iteration in `bootstrap_odata_contracts()`. When
`<EntityContainer>` is present, drive contract emission off
`<EntitySet>` declarations and look up the backing `<EntityType>` for
schema. EntityTypes not declared as EntitySets are dropped.

When `<EntityContainer>` is absent (rare; OData v1/v2 or stripped
metadata), preserve the current per-EntityType walk — the container-less
case has no authoritative source of "what is queryable", so we keep the
existing best-effort behavior.

`das.spec_ref.entity_set` continues to be populated per ADR-0024. Resource
naming continues to be `pluralize(snake_case(type_name))`; only *which*
types produce contracts changes.

### Code shape

```python
# src/das_cli/bootstrap/odata.py

def bootstrap_odata_contracts(metadata_xml, *, source_name):
    root = ElementTree.fromstring(metadata_xml)
    entity_set_by_type = _build_entity_set_map(root)
    type_elements = {
        e.get("Name"): e for e in root.iter(f"{{{_NS['edm']}}}EntityType")
    }

    contracts: list[LoadedContract] = []
    if entity_set_by_type:
        # See ADR-0025: EntityContainer is authoritative when present.
        for type_name, set_name in entity_set_by_type.items():
            elem = type_elements.get(type_name)
            if elem is None:
                continue  # malformed metadata: EntitySet's type element missing
            contracts.append(
                _build_contract(elem, source_name=source_name, entity_set=set_name)
            )
    else:
        # Legacy fallback: container-less metadata → emit all EntityTypes.
        for elem in type_elements.values():
            contracts.append(
                _build_contract(elem, source_name=source_name, entity_set=None)
            )
    return contracts
```

`_build_contract`'s parameter collapses from `entity_set_by_type: dict[str, str]`
to `entity_set: str | None`. `_build_custom_properties` already handles the
optional value and is unchanged.

### What does NOT change

- `_build_entity_set_map`: still the source of truth for the type → set
  mapping, untouched.
- `pluralize(...)` and resource-name derivation: unchanged. Aligning
  `resource_name` with EntitySet name would rename existing on-disk
  contracts and database tables for live users — out of scope.
- `synthesize_odata_endpoint` / `pluralize_preserving_case` heuristic
  fallback: unchanged. After this change the heuristic is reached only by
  contracts bootstrapped from container-less metadata (its documented
  purpose).
- `das.spec_ref.entity_set` semantics: unchanged. Still optional; legacy
  contracts and container-less metadata still omit it.

## Alternatives considered

- **Hard-fail on container-less metadata.** Stricter, but breaks an extant
  code path with no compensating benefit. Overproduction only matters when
  types-without-sets exist, which container-less metadata cannot express.
- **Live-probe each EntitySet during bootstrap.** Catches the
  declared-but-still-404 case (`BusinessEntities`), but adds an HTTP call
  per resource, slowing bootstrap from seconds to minutes. Explicitly named
  out of scope in the issue; worth a future `--probe` flag.
- **Leave bootstrap as-is, add `das contract prune` to drop 404-emitting
  contracts after the first failed ingest.** Shifts work to the user and
  doesn't address the underlying authority-of-truth question. Rejected.

## Tests

### Unit — `tests/unit/test_bootstrap_odata.py`

**Rewrite** `test_entity_set_omitted_when_type_not_in_container`. Today it
asserts that an EntityType present in `$metadata` but absent from
`<EntityContainer>` *still gets a contract* with `entity_set` omitted from
`spec_ref`. Under the new behavior such a type is **dropped**. Rename to
`test_entity_type_without_entity_set_is_dropped` and update assertions to:

- A contract is emitted for the EntityType that *is* in the container.
- No contract is emitted for the EntityType that is not.

**New** `test_malformed_metadata_entity_set_without_matching_type`. Build
XML where `<EntityContainer>` references a type that has no `<EntityType>`
element. Assert: that EntitySet is silently skipped; other well-formed
EntitySets still emit.

**Keep green** (no changes expected):

- `test_emits_one_contract_per_entity_type` — fixture
  `sample_odata_metadata.xml` has matching pairs.
- `test_entity_set_omitted_when_no_container` — legacy fallback path.
- `test_entity_set_strips_namespace_from_entity_type` — exercises
  `_build_entity_set_map`, untouched.
- `test_irregular_plurals_captured_from_entity_container` — fixture has
  matching pairs.
- All schema/property/cursor tests — they read the products fixture which
  is fully covered by its container.

### Diff — `tests/unit/test_diff.py`

The diff fixtures (`METADATA_BASE`, `METADATA_NEW_COL`, `METADATA_NULL_CHANGE`)
all lack `<EntityContainer>`. They take the legacy fallback path and stay
green unchanged.

### E2E — `tests/e2e/sources/test_odata_adventureworks.py`

**New** `test_adventureworks_bootstrap_count_matches_entity_container`.
Steps:

1. `das init` and `das source add adventure_works ...`.
2. `das contract bootstrap adventure_works` (no `--only`).
3. Fetch `$metadata` once with `requests`, count `<EntitySet>` elements
   inside `<EntityContainer>` via `xml.etree.ElementTree`.
4. Count `*.odcs.yaml` files under `contracts/adventure_works/`.
5. Assert equality.

No extract — one HTTP round-trip plus filesystem read. Directly validates
the reported defect.

## ADR work

### New ADR-0025 — Drive OData bootstrap off `<EntityContainer>`

Extends ADR-0024. Reuses the AdventureWorks evidence above in Context.
Decision: container-driven iteration with legacy fallback. Alternatives
section lists the two rejected options above. Consequences:

- Positive: bootstrap output aligns with what the server actually serves.
  The post-ADR-0024 "degraded spec_ref" pluralization fallback in
  `synthesize_odata_endpoint` becomes reachable only via genuinely-old
  contracts or container-less metadata — exactly its documented purpose.
- Negative: pre-existing on-disk contracts for now-dropped EntityTypes
  remain until the user re-bootstraps with `--force`. Documented as the
  migration path; no automatic upgrade.
- Neutral: container-less metadata follows the same legacy path as before.

### ADR-0024 Status edit

`Accepted` → `Accepted (extended by ADR-0025)`. Status-only edit on an
already-merged ADR is the one in-place mutation allowed by the project
lifecycle policy (`CLAUDE.md`, ADR-0006 precedent).

### `docs/adrs/README.md`

Add the ADR-0025 row.

## Out of scope

- **Servers that declare an EntitySet but still 404** (e.g.
  `BusinessEntities` on the AdventureWorks demo). Only detectable via a
  live probe; worth a future `--probe` flag on `das contract bootstrap`.
- **All-or-nothing extract semantics** when one resource 404s. A separate
  side observation on issue #61; not part of this change.
- **Aligning `resource_name` with the EntitySet name** (e.g.
  `address` → `addresses`, `persons` → `people`). Would rename on-disk
  contracts and downstream tables for live users; a behavior change worth
  its own issue and ADR if pursued.
