# OData EntitySet pluralization — capture from `$metadata`

- **Date:** 2026-05-13
- **Status:** Draft
- **Related ADRs:** ADR-0006 (bootstrap mix), ADR-0014 (per-resource `das.endpoint`)
- **Issue:** [#61](https://github.com/mattiasthalen/das-cli/issues/61)

## Problem

`synthesize_odata_endpoint()` in `src/das_cli/contracts/das_endpoint.py:91-103` builds the OData URL path by appending `"s"` to the EntityType name read from `das.spec_ref`:

```python
type_name = spec_ref.get("type") if isinstance(spec_ref, dict) else None
path = f"/{type_name}s" if type_name else f"/{contract.resource_name}"
```

This produces `/Addresss` for the entity set `Addresses`, `/Currencys` for `Currencies`, etc. — any EntityType whose plural needs `+es` (consonant + `s`/`x`/`ch`/`sh`) or `y → ies` returns 404 at extract time.

Reproduction against the public AdventureWorks OData feed (issue #61):

```bash
das source add adventure_works --type odata \
  --url https://demodata.grapecity.com/adventureworks/odata/v1
das contract bootstrap adventure_works     # 66 contracts written ✓
das ingest adventure_works                 # aborts at first resource (Addresss → 404)
```

Seven AdventureWorks EntityTypes hit the bug: `Address`, `BusinessEntity`, `BusinessEntityAddress`, `Currency`, `EmailAddress`, `SalesTerritory`, `TransactionHistory`. The Northwind e2e test slipped past this because all its EntityTypes pluralize via plain `+s`.

The authoritative plural lives in `$metadata` under `<EntityContainer><EntitySet>`. Bootstrap (`bootstrap/odata.py`) parses `$metadata` but ignores the `EntityContainer` element today.

Asymmetry worth noting: `bootstrap/odata.py:100` already uses `naming.pluralize()` to derive the snake_case **resource name** correctly (it handles `y→ies` and already-plural pass-through). Only `synthesize_odata_endpoint()` does plain `+s`.

## Fix

Three changes, additive.

### 1. Bootstrap: read EntitySets from `$metadata`

In `bootstrap/odata.py`, before walking EntityTypes, build a `type_name → entity_set_name` map by walking `<edmx:Edmx>/<DataServices>/<Schema>/<EntityContainer>/<EntitySet>`. Each `EntitySet` declares:

- `Name` — the URL segment (e.g. `Addresses`)
- `EntityType` — qualified type reference (e.g. `AdventureWorks.Address`)

Strip the namespace prefix from `EntityType` (everything up to the last `.`) to key on the bare type name.

In `_build_custom_properties()`, when the EntityType has a matching EntitySet, add `entity_set` to the `das.spec_ref` value:

```yaml
- property: das.spec_ref
  value:
    kind: odata
    type: Address
    entity_set: Addresses   # NEW — present when $metadata has an EntityContainer entry
```

When `$metadata` has no `EntityContainer` (rare but legal), bootstrap emits contracts without `entity_set` — same shape as today.

### 2. Endpoint synthesis: prefer `entity_set`, fall back gracefully

In `synthesize_odata_endpoint()`, resolve the path in this order:

1. **`spec_ref["entity_set"]` if present** → `path = f"/{entity_set}"`. Authoritative.
2. **Else, heuristic on `spec_ref["type"]`** → `path = f"/{pluralize_preserving_case(type_name)}"`. Covers existing contracts (pre-this-change) and bootstrap runs against `$metadata` without an `EntityContainer`.
3. **Else, fall through to `resource_name`** → today's last-ditch fallback. Unchanged.

The other endpoint fields (`response_path: $.value`, JSON-link paginator with `@odata.nextLink`) are unchanged.

### 3. Case-preserving pluralizer

Add to `bootstrap/naming.py`:

```python
def pluralize_preserving_case(name: str) -> str:
    """Pluralize an OData EntityType name to its conventional EntitySet form.

    Preserves the input's capitalization. Differs from `pluralize()` in two
    deliberate ways:

    1. No `endswith("s")` pass-through. OData EntityTypes are conventionally
       singular, so `Address` / `EmailAddress` / `Status` are inputs we *want*
       to pluralize to `Addresses` / `EmailAddresses` / `Statuses`, not pass
       through.
    2. Adds the `+es` rule for consonant + s/x/z/ch/sh.

    See ADR-0024: OData EntitySet name persisted on `das.spec_ref`.
    """
    if not name:
        return ""
    if name.endswith("y") and not name.endswith(("ay", "ey", "iy", "oy", "uy")):
        return name[:-1] + "ies"
    if name[-1].lower() in ("s", "x", "z") or name[-2:].lower() in ("ch", "sh"):
        return name + "es"
    return name + "s"
```

The existing `pluralize()` (used to derive the snake_case resource name) is **not** modified. The two functions diverge intentionally: `pluralize()` operates on names that may already be plural and is used for stable resource-name derivation; `pluralize_preserving_case()` assumes singular input (the OData convention) and is used only as a fallback for endpoint synthesis when `entity_set` isn't available.

Known limitation: a pathological singular EntityType like `News` (English uncountable) would become `Newses` under this heuristic. Such cases need an explicit `entity_set` in `$metadata` (which bootstrap will capture) or an explicit `das.endpoint`. Out of scope for the heuristic.

### Behavior matrix

| EntityType | Today | After fix (post re-bootstrap) | After fix (legacy contract — no `entity_set`) |
|---|---|---|---|
| `Product` | `/Products` ✅ | `/Products` (from `entity_set`) | `/Products` (heuristic) |
| `Address` | `/Addresss` ❌ | `/Addresses` | `/Addresses` (heuristic, `+es`) |
| `EmailAddress` | `/EmailAddresss` ❌ | `/EmailAddresses` | `/EmailAddresses` (heuristic, `+es`) |
| `Currency` | `/Currencys` ❌ | `/Currencies` | `/Currencies` (heuristic, `y→ies`) |
| `BusinessEntity` | `/BusinessEntitys` ❌ | `/BusinessEntities` | `/BusinessEntities` (heuristic, `y→ies`) |
| `TransactionHistory` | `/TransactionHistorys` ❌ | `/TransactionHistories` | `/TransactionHistories` (heuristic, `y→ies`) |
| `Person` (set `People`) | `/Persons` ❌ | `/People` (from `entity_set`) | `/Persons` ❌ — still wrong, requires re-bootstrap or explicit `das.endpoint` |
| `News` (uncountable) | `/Newss` ❌ | `/News` (from `entity_set`) | `/Newses` ❌ — heuristic over-pluralizes, requires re-bootstrap or explicit `das.endpoint` |
| Explicit `das.endpoint` on contract | uses `das.endpoint` | uses `das.endpoint` | uses `das.endpoint` (ADR-0014 priority unchanged) |

The legacy-contract column matters: users who installed das-cli on a prior version and have AdventureWorks contracts in git will not have `entity_set` in `das.spec_ref` until they re-run `das contract bootstrap adventure_works --force` (the `--force` flag is required to overwrite existing contract files). The heuristic gives them a free win for all seven AdventureWorks irregulars; truly irregular plurals (Person/People, Mouse/Mice) and English uncountables (News) still need re-bootstrap or an explicit `das.endpoint` override per ADR-0014.

## Why not the alternatives

- **Heuristic only (issue's "quick patch", no `$metadata` read).** One-file change in `das_endpoint.py` plus the new `pluralize_preserving_case`. Unblocks AdventureWorks today. Rejected as the only fix because heuristics drift from authoritative names — an EntityType whose set is `People`/`Mice` would silently 404 with no signal that the heuristic guessed wrong. We keep the heuristic as a *fallback* for legacy contracts and `$metadata` without an `EntityContainer`, but the new bootstrap path makes the authoritative name available where we have it.

- **Drop synthesis entirely; require explicit `das.endpoint` on every OData contract.** Aligned with ADR-0014's "authority lives in the contract." Rejected as a hard break: every existing OData contract would need an edit before the next extract works, and bootstrap would emit `das.endpoint` for all N contracts even though OData's `EntityType ↔ EntitySet` mapping is mechanically derivable. The ergonomic property of OData (zero-config extract after `bootstrap`) is worth preserving.

- **Use an `inflect`-style library.** Heavyweight dependency for a problem where the authoritative answer is already in `$metadata`. The fallback heuristic doesn't need to be linguistically complete — it just needs to be no worse than what an authoritative `entity_set` lookup would replace.

## ADR

New **ADR-0024: OData EntitySet name persisted on `das.spec_ref`**.

This extends — does not contradict — ADR-0014. ADR-0014 says synthesis applies when `das.endpoint` is absent; ADR-0024 specifies the inputs synthesis uses for OData (authoritative `entity_set` if available, then heuristic on `type`, then `resource_name`). The contract surface gains a new optional key (`das.spec_ref.entity_set` for `kind: odata`), which clears the "change to contract format / naming convention" bar in `CLAUDE.md`.

ADR-0014 stays Accepted. ADR-0006 (bootstrap mix) is referenced but unchanged.

Draft text:

```markdown
# 0024. OData EntitySet name persisted on `das.spec_ref`

- **Status:** Accepted
- **Date:** 2026-05-13
- **Deciders:** mattiasthalen

## Context

ADR-0014's synthesis fallback for OData derives the URL path by appending `"s"`
to `das.spec_ref.type`. This works for EntityTypes whose EntitySet pluralizes
via plain `+s` (Northwind: `Product` → `/Products`) but fails for `+es`,
`y → ies`, and irregular plurals (AdventureWorks: `Address` → `/Addresses`,
`Currency` → `/Currencies`, `Person` → `/People`). The authoritative name lives
in `$metadata`'s `<EntityContainer><EntitySet>` block.

## Decision

OData bootstrap (`bootstrap/odata.py`) reads `<EntityContainer><EntitySet>` and
persists the set name on `das.spec_ref.entity_set` for each EntityType with a
matching declaration:

    customProperties:
      - property: das.spec_ref
        value:
          kind: odata
          type: Address
          entity_set: Addresses

`synthesize_odata_endpoint()` resolves the path in this order:

1. `spec_ref.entity_set` if present.
2. `pluralize_preserving_case(spec_ref.type)` heuristic (`y → ies`, `+es` on
   `s/x/z/ch/sh`, else `+s`).
3. `contract.resource_name`.

Explicit `das.endpoint` on the contract continues to win over synthesis
(ADR-0014, unchanged).

## Alternatives considered

- **Heuristic only.** Cheaper, but drifts from authoritative `$metadata` and
  silently 404s on truly irregular plurals.
- **Require explicit `das.endpoint` everywhere.** Hard-breaks the OData
  zero-config ergonomic that ADR-0014 deliberately preserved.

## Consequences

- **Positive:** Newly-bootstrapped OData sources use the actual EntitySet
  names from `$metadata`. Legacy contracts gain a meaningful heuristic
  improvement for free.
- **Negative:** Legacy contracts with truly irregular plurals (Person/People)
  still fail until re-bootstrap or explicit `das.endpoint`. Documented as the
  migration path; no automatic upgrade.
- **Neutral:** `das.spec_ref.entity_set` is additive; older das-cli versions
  ignore unknown keys.
```

Don't forget to add the corresponding row to `docs/adrs/README.md`.

## Test plan

### Unit — bootstrap (`tests/unit/test_bootstrap_odata.py`)

Extend `tests/fixtures/sample_odata_metadata.xml` with an `<EntityContainer>` block:

```xml
<EntityContainer Name="Default">
  <EntitySet Name="Products" EntityType="Test.Models.Product" />
  <EntitySet Name="Departments" EntityType="Test.Models.Department" />
</EntityContainer>
```

Add a second fixture `sample_odata_metadata_irregular.xml` containing an EntityType whose set name is irregular (e.g. `Address` → `Addresses`, `Currency` → `Currencies`) so the parser is exercised on the actual issue-#61 shape.

New tests:

- `test_entity_set_added_when_container_present` — both fixtures: assert `spec_ref.value["entity_set"]` equals the declared `Name`.
- `test_entity_set_strips_namespace_from_entity_type` — qualified type reference resolves to the bare `Name` key.
- `test_entity_set_omitted_when_no_container` — XML without `<EntityContainer>`: `spec_ref.value` has no `entity_set` key (backward compatibility).
- `test_entity_set_omitted_when_type_not_in_container` — `<EntityContainer>` present but missing one of the EntityTypes: that contract has no `entity_set`; the other does.

Existing tests in `test_bootstrap_odata.py` continue to pass — the new fixture additions don't change emitted resource_name, properties, or cursor behavior.

### Unit — synthesis (`tests/unit/test_das_endpoint.py`)

Add tests:

- `test_synthesize_uses_entity_set_when_present` — `spec_ref={kind: odata, type: Address, entity_set: Addresses}` → `path == "/Addresses"` even though the naive heuristic would say `/Addresss`.
- `test_synthesize_falls_back_to_pluralize_preserving_case` — `spec_ref={kind: odata, type: Address}` (no `entity_set`) → `path == "/Addresses"` (heuristic `+es`).
- `test_synthesize_falls_back_pluralize_y_to_ies` — `spec_ref={kind: odata, type: Currency}` → `path == "/Currencies"`.
- `test_synthesize_falls_back_pluralize_passthrough_already_plural` — `spec_ref={kind: odata, type: Products}` → `path == "/Products"`.
- `test_synthesize_falls_back_to_resource_name_when_no_spec_ref` — unchanged from today.

Existing tests in `test_das_endpoint.py` continue to pass (`/Products` for `Product` works via either the heuristic or `entity_set`).

### Unit — naming (`tests/unit/test_bootstrap_naming.py` if it exists; else new file)

`pluralize_preserving_case` cases:

| Input | Expected | Rule |
|---|---|---|
| `Product` | `Products` | +s |
| `Address` | `Addresses` | +es (consonant + s) |
| `EmailAddress` | `EmailAddresses` | +es (consonant + s) |
| `Box` | `Boxes` | +es (x) |
| `Quartz` | `Quartzes` | +es (z) |
| `Class` | `Classes` | +es (consonant + s) |
| `Match` | `Matches` | +es (ch) |
| `Dish` | `Dishes` | +es (sh) |
| `Status` | `Statuses` | +es (consonant + s) |
| `Currency` | `Currencies` | y→ies |
| `BusinessEntity` | `BusinessEntities` | y→ies |
| `Day` | `Days` | +s (vowel + y, not y→ies) |
| `Boy` | `Boys` | +s (vowel + y) |
| `""` | `""` | empty pass-through |

Negative-confirmation cases (documenting accepted heuristic failures):

| Input | Heuristic output | Authoritative `entity_set` would be |
|---|---|---|
| `News` | `Newses` | `News` |
| `Person` | `Persons` | `People` |
| `Mouse` | `Mouses` | `Mice` |

These cases are why the authoritative `entity_set` path takes priority over the heuristic.

### Integration / e2e

- `tests/e2e/sources/test_odata_adventureworks.py` is the closest regression target. It currently runs `--only products` (which works under the naive heuristic). **Add a second e2e test** invocation that runs `--only addresses` (or `currencies`) against the same live AdventureWorks endpoint. If that test is flaky on CI due to the public AdventureWorks demo service, gate it behind the same opt-in marker the existing AdventureWorks test uses; otherwise run inline.
- The existing `test_adventureworks_bootstrap_extract_load` keeps passing unchanged.

## Out of scope

- **`ingest` partial-vs-full exit semantics.** Issue #61 notes that `das ingest` returned `5` (`DAS_EXIT_INGEST_PARTIAL`) on the bug repro even though 0/66 resources processed. Whether a single resource extract failure should halt the pipeline, mark it partial, or per-resource-degrade is a separate design question. File as its own issue; not addressed here.
- **`pluralize()` (snake_case variant) augmentation.** The existing `pluralize()` is **not** broken for AdventureWorks resource names — its `endswith("s")` pass-through happens to produce reasonable resource names for the seven problematic types: `Address`→`address`, `EmailAddress`→`email_address` (singular but acceptable as a resource name), `BusinessEntity`→`business_entities` (y→ies path), `Currency`→`currencies` (y→ies path), etc. The naive `+s` bug lives **only** in `synthesize_odata_endpoint()`. We deliberately leave `pluralize()` alone to avoid renaming any resources in already-bootstrapped workspaces — that would cross schema-freeze contract boundaries (ADR-0012).
- **Custom paginators per ADR-0014.** This spec doesn't touch the paginator registry.
- **OpenAPI / REST equivalent.** OpenAPI bootstrap (ADR-0015) walks `paths` and stores them directly in `das.endpoint`; no equivalent pluralization heuristic exists or is needed.
