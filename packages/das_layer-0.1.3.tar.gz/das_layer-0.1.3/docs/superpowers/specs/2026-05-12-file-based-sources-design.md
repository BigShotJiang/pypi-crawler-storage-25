# File-based sources (csv, excel, xml, qvd)

**Issue:** [#49](https://github.com/mattiasthalen/das-cli/issues/49) (umbrella) — bundles [#38](https://github.com/mattiasthalen/das-cli/issues/38) (csv), [#37](https://github.com/mattiasthalen/das-cli/issues/37) (excel), [#39](https://github.com/mattiasthalen/das-cli/issues/39) (xml). [#40](https://github.com/mattiasthalen/das-cli/issues/40) (qvd) is folded into this design rather than left as a separate track.

**Status:** Approved (brainstorming) — pending implementation plan via `superpowers:writing-plans`.

## Background

das-cli already declares `filesystem` in `SourceType` (`src/das_cli/models/source_yml.py`) and accepts it in `das source add`'s `_VALID_SOURCE_TYPES` (`src/das_cli/cli.py`), but no builder exists in `dlt_glue/source_factory.py` and no bootstrap module exists in `bootstrap/`. The validator (`contracts/validator.py`) already rejects `das.endpoint` on `filesystem`, treating it as an HTTP-only field.

Issue #49 originally listed csv, excel, and xml as siblings, with qvd ([#40](https://github.com/mattiasthalen/das-cli/issues/40)) explicitly out of scope as "not a 1:1 shape fit." This design folds qvd back in: the file-source plumbing (path resolution, glob, blob URLs, per-resource selectors, opt-in provenance) is format-agnostic, and qvd plugs in as just another reader.

Issue [#41](https://github.com/mattiasthalen/das-cli/issues/41) (Azure Blob source) is already closed, so blob URLs are available to file readers via dlt's filesystem config.

## Architecture

Single source type `filesystem` covers all four formats. Format dispatches **per resource** via `das.spec_ref.format`. One new branch in `dlt_glue/source_factory.py` (`_build_filesystem_resources`), symmetric with the SQL branch from ADR-0018 — no registry, no plugin layer.

Format-specific reading lives in a new `dlt_glue/file_readers/` package — one module per format, each exposing `read_rows(file_item, spec_ref) -> Iterator[dict]`.

```
_build_filesystem_resources
  └─ for each contract:
      ├─ dlt.sources.filesystem(bucket_url=endpoint, file_glob=spec_ref.path)
      └─ @dlt.transformer
          └─ file_readers.<format>.read_rows(file_item, spec_ref)
              ├─ inject metadata into row per spec_ref.inject (opt-in)
              └─ yield {"_data": row}
```

`dlt.sources.filesystem` provides file enumeration plus free incremental "only new files since last run" tracking via modification time. `--full` (ADR-0019) resets that state the same way as HTTP/SQL via `pipelines/extract.py::reset_extract_state`.

## Config shape

`_source.yml`:

```yaml
type: filesystem
endpoint: ./data/                  # or az://bucket/exports/, s3://..., file:///abs
spec:
  kind: filesystem
auth:
  type: none                       # blob auth via dlt env-var config
```

Per-resource `das.spec_ref` in each ODCS contract:

```yaml
customProperties:
  - property: das.spec_ref
    value:
      kind: filesystem
      format: csv                    # csv | excel | xml | qvd
      path: "customers_*.csv"        # glob, relative to endpoint
      # format-specific (only the relevant ones):
      delimiter: ","                 # csv
      encoding: utf-8                # csv, xml
      sheet: "Customers"             # excel
      header_row: 1                  # excel (1-based)
      xpath: "//customer"            # xml
      namespaces: {ns: "http://..."} # xml (optional)
      # opt-in row-level provenance:
      inject:
        source_file: basename        # → row["source_file"] = file.basename
        source_sheet: sheet          # excel only
        source_mtime: mtime          # ISO timestamp
```

Supported `inject` values: `basename`, `fullpath`, `mtime`, `sheet` (excel only). User declares a matching column in the ODCS schema; the reader sets `row[col] = value` before blobbing. Outer `{"_data": row}` shape from ADR-0003 stays intact.

No `das.cursor` for filesystem — incremental is mtime-based and built into dlt's filesystem source.

## Resource semantics

| Format | Path glob | Selector | Combine behavior |
|---|---|---|---|
| csv | `customers_*.csv` | — | concatenate matched files into one resource |
| excel | `*.xlsx` | `sheet: Customers` | match `Customers` sheet across all workbooks; concatenate |
| xml | `*.xml` | `xpath: //customer` | apply xpath to each matched file; concatenate records |
| qvd | `*.qvd` | — | concatenate matched files into one resource |

A single-workbook resource is a special case of the Excel pattern: `path: workbook.xlsx, sheet: Sheet1` — N sheets → N contracts, one per sheet.

## Streaming

Massive files are a first-class concern. Every reader must be a generator that does not materialize the full file in memory. The reader interface (`Iterator[dict]`) supports this; the constraint is on implementation.

Per-format streaming requirements:

- **csv** — stdlib `csv.reader` over a line-iterating file handle. Streams natively; nothing special needed.
- **excel** — `openpyxl.load_workbook(..., read_only=True, data_only=True)` plus `ws.iter_rows(values_only=True)`. Read-only mode uses an iterator over rows and does not load the full sheet into memory. Caveat: read-only mode wants a path or a seekable file; for blob URLs we may download to a tempfile first (single-file scope, deleted after the resource finishes).
- **xml** — `lxml.etree.iterparse(file, events=('end',), tag=...)`. After yielding each matched element, `elem.clear()` and prune previous siblings (`while elem.getprevious() is not None: del elem.getparent()[0]`) to release memory. Required pattern — without it, lxml accumulates the full DOM. Works directly on file-like objects (fsspec handles).
- **qvd** — streaming-capable parser required. QVD layout (small XML metadata header + per-column symbol tables + bit-stuffed row table) makes row-by-row iteration feasible without loading the full row table: keep symbol tables in memory (typically small), decode bits for one row at a time. Library selection criterion: must expose a row iterator, not just a DataFrame loader. Candidates to evaluate at implementation time:
  - `qvd` (Rust-backed Python bindings, qlik-quad/qvd) — check for row-iter API.
  - `pyqvd` (pure Python) — likely DataFrame-only; verify.
  - Fallback: thin streaming reader on top of an existing parser's lower-level API, or — last resort — a minimal in-repo qvd parser scoped only to row iteration.

  If no library exposes streaming, we ship qvd last with that limitation documented and revisit the library choice in a follow-up. The umbrella design does not block on qvd reader availability.

For blob URLs (`az://`, `s3://`, `gs://`) the file handle comes from dlt's `FileItemDict.open(mode="rb")`, which is an fsspec-backed streaming file. csv/xml stream directly off it. excel and qvd may require a tempfile round-trip if the chosen parser requires a seekable local file; this is a per-format decision documented in the reader module.

## Bootstrap

`das contract bootstrap <source>` for `type: filesystem` walks `endpoint` and dispatches per extension:

| Extension | Contract output | Type inference |
|---|---|---|
| `*.csv` | one per file, single-file `path` | names from header row; all types → `string` |
| `*.xlsx` | one per (workbook, sheet) | names from header row; all types → `string` |
| `*.xml` | one per file; requires `--xpath` flag | names from element children; all types → `string` |
| `*.qvd` | one per file | names AND types from embedded XML metadata header (Symbol → string, Numeric → number) |

User edits generated contracts to: (a) widen single-file `path` to globs for partitioned exports, (b) refine types beyond `string` for non-qvd formats, (c) declare and `inject` provenance columns.

Bootstrap reads only what's needed for schema discovery — header row for csv/excel, first matched element for xml, metadata header for qvd. Never loads file bodies.

## P2 (load) — no changes

Load reads `{"_data": row}` blobs and projects through the contract. Filesystem sources are indistinguishable from HTTP/SQL at this layer. Injected provenance fields are just columns in the contract. The decimal round-trip path (`pipelines/load.py::_project_record` + `dlt_glue/schema_factory.py::coerce_decimal`) from ADR-0018 carries over for Excel and qvd numerics.

## CLI

- `das source add --type filesystem --url ./data/` — no `--auth` for local files; blob URLs use dlt env-var config (same shape as #41 wired for destinations).
- `das contract bootstrap <name>` — adds an `--xpath` flag (XML only, optional otherwise).

## Validation (`contracts/validator.py`)

For `type: filesystem`:

- `das.spec_ref` required; `kind == filesystem`; `format` in the allowed set.
- `path` required and non-empty.
- Format-specific required fields: `sheet` for excel; `xpath` for xml.
- `inject` keys must reference columns that exist in the ODCS schema (otherwise reject — the column would be injected but never declared, defeating the type-frozen contract).
- Existing `das.endpoint` rejection on `filesystem` stays.

## Dependencies

| Format | Library | Install extra |
|---|---|---|
| csv | stdlib `csv` | (none — base install) |
| excel | `openpyxl` (read-only mode) | `das-cli[excel]` |
| xml | `lxml` (`iterparse` streaming) | `das-cli[xml]` |
| qvd | streaming-capable parser (candidates evaluated per the Streaming section) | `das-cli[qvd]` |

Filesystem source uses `dlt[filesystem]`, already a dependency for the destination side (ADR-0016, ADR-0017).

Driver wheels are the user's responsibility, same convention as ADR-0018 for SQL drivers. `pyproject.toml` lists each extra; the README quickstart documents the install pattern.

## Testing

Each source × DuckDB destination gets an e2e edge per the README's "verified edges" pattern:

- `tests/e2e/sources/csv_to_duckdb/` — partitioned monthly CSV fixture; glob ingest; provenance column asserted; row counts match.
- `tests/e2e/sources/excel_to_duckdb/` — multi-sheet single workbook + glob across workbooks (combine-by-sheet).
- `tests/e2e/sources/xml_to_duckdb/` — namespaced XML with xpath selection.
- `tests/e2e/sources/qvd_to_duckdb/` — mixed-type qvd; asserts type fidelity from metadata header.

Unit:

- `tests/unit/dlt_glue/file_readers/test_{csv,excel,xml,qvd}.py` — readers against bytes/temp files. Each test asserts streaming behavior by feeding a file larger than would fit in expected RSS and observing peak memory stays bounded.
- `tests/unit/bootstrap/test_filesystem.py` — discovery + contract emission.
- `tests/unit/contracts/test_validator_filesystem.py` — spec_ref validation.

## ADRs to write

- **ADR-0022** — filesystem source type: single umbrella + per-resource format dispatch. Records alternatives rejected (per-format source types; registry-style dispatch).
- **ADR-0023** — opt-in row-level provenance via `inject`. Records why hive-partition-by-file was rejected (small-files explosion on combining globs) and why outer-blob metadata was rejected (ADR-0003 break).

ADR-0003 (P1 blob pattern) is reaffirmed, not superseded — the inject mechanism puts injected fields *inside* the user-declared contract columns, not alongside `_data`. ADR-0013 (hive partition scheme) unchanged.

## Implementation order

Per #49's suggested order, with qvd folded in at the end:

1. **csv** — establishes plumbing: source-factory branch, `file_readers/` package, bootstrap walker, validator changes, ADR-0022 + ADR-0023, e2e edge.
2. **excel** — adds sheet enumeration; per-sheet contracts; openpyxl read-only streaming.
3. **xml** — xpath + namespaces; lxml `iterparse` streaming pattern.
4. **qvd** — leverages the established patterns; metadata-header type inference; streaming reader selection (or fallback documented).

One PR per format under the shared umbrella ADRs.

## Out of scope

- Parquet / JSON / JSONL sources — natural follow-on under the same `type: filesystem` umbrella; dlt has native readers. Deferred to a separate issue.
- CSV dialect auto-detection (sniffing delimiters / quoting). Fragile; user specifies explicitly.
- XML namespace auto-discovery from document declarations. User provides `namespaces` in `das.spec_ref`.
- Filename-pattern detector that suggests globs at bootstrap (e.g. `customers_2024-01.csv` → `customers_*.csv`). Nice-to-have; defer.
- Writing to file destinations — already covered by ADR-0016 (destination dispatch) and ADR-0017 (Delta via filesystem alias).
