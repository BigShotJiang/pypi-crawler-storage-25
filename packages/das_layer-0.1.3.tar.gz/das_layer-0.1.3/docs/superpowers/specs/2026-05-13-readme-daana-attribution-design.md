# README — Daana attribution

- **Status:** Draft
- **Date:** 2026-05-13
- **Author:** Mattias Thalén

## Context

The das-cli README introduces the project as "contract-driven ingestion"
and later scopes the project to the "DAS layer" without crediting where
those concepts come from. Both terms originate in Daana's blog:

- *The rise of the model-driven data engineer* — establishes the
  Data As System / Data As Business / Data As Requirements layering.
- *Contract-driven data transformation* — establishes contracts as the
  single source of truth.

These posts are already cited in `docs/superpowers/specs/2026-05-05-das-cli-v0.1-design.md`
as the philosophical foundation, but the README — the public-facing entry
point — has no attribution. Readers landing on the project page have no
pointer to the prior art.

## Decision

Add a one-line blockquote crediting Daana between the README's badge row
(line 8) and the `## What it is` heading (line 10). The blockquote names
the **DAS (Data As System)** acronym and links both posts inline.

Exact wording:

```markdown
> Built on the **DAS** (Data As System) layer concept and contract-driven
> philosophy from Daana's writing — [The rise of the model-driven data
> engineer](https://blog.daana.dev/blog/the-rise-of-model-driven-data-engineer)
> and [Contract-driven data
> transformation](https://blog.daana.dev/blog/contract-driven-data-transformation).
```

No other README content changes.

## Alternatives considered

- **Dedicated `## Inspiration` section near the end (before License).**
  Clearer as a credit block, but buried at the bottom — readers may never
  reach it. Rejected.
- **Weave attribution into the existing line 18 sentence** (`scoped to
  the DAS layer ...`). Closer to the term being defined, but disrupts the
  scope statement's flow. Rejected.
- **Brief inline credit at line 18 plus a Documentation bullet.**
  Redundant; doubles the maintenance surface. Rejected.
- **"Prior art:" labeled line instead of a blockquote.** Heavier
  framing than needed for a one-line credit. Rejected.

## Consequences

**Positive**
- Public-facing credit for the conceptual prior art is now on the README,
  not hidden in a design spec.
- Defines the DAS acronym up front, before it's used in the intro prose.
- Low maintenance: one block, inline links matching the README's house
  style.

**Negative / neutral**
- Adds five lines above the fold. The blockquote framing keeps it
  visually distinct so it doesn't dilute the one-line project tagline.
- If Daana renames or moves the posts, the URLs break — same risk as
  every other external link in the README.
