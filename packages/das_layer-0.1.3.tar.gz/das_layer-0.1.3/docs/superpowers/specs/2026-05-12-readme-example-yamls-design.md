# README example YAMLs — design

- **Status:** Draft
- **Date:** 2026-05-12
- **Issue:** [#46](https://github.com/mattiasthalen/das-cli/issues/46) — Add example yamls to readme

## Context

`README.md` names three distinct YAML files by role — `das.yaml` (workspace),
`contracts/<source>/_source.yml` (per-source connection), and
`contracts/<source>/<resource>.odcs.yaml` (per-resource ODCS v3 contract) —
but shows zero example content. A new reader running the Quickstart sees the
commands (`das init`, `das source add`, `das contract bootstrap`) but has no
way to recognise what the files those commands write look like, nor what they
need to hand-edit after `bootstrap`.

The current README also leaves three concrete shape differences invisible:

- `_source.yml` varies materially by source type — OData has `spec.kind: odata`
  with a `metadata_url`; OpenAPI has `spec.kind: openapi` with a `swagger_url`;
  SQL templates credentials into the endpoint URL via `env_var(...)` and has
  no `spec` block.
- ODCS contracts under OpenAPI sources require a `das.endpoint` custom
  property (per ADR-0014, ADR-0015); contracts under OData / SQL sources do
  not.
- `das.*` custom properties (especially `das.cursor`) are the only piece of
  the contract that's truly das-cli-specific — but they're easy to miss
  unless an example shows one.

This spec covers the user-facing README change only. It does not propose a
new ADR (no architecture is changing), a new `examples/` directory, or
contract-fixture refactoring.

## Goals

- Make the three YAML files concrete and copy-pasteable from the README.
- Reinforce the conceptual split surfaced by the existing Concepts section
  (contract vs `_source.yml` vs `das.yaml`) by showing each in isolation.
- Cover the three source-type shapes (OData, OpenAPI/REST, SQL) without
  duplicating the contract or `das.yaml` per variant.
- Keep the README readable as a storefront — examples land mid-document where
  they're motivated, not as a wall of YAML.

## Non-goals

- DuckLake / Delta `das.yaml` examples. Link to ADR-0016 / ADR-0017 instead.
- A new top-level `examples/` directory. Out of scope; revisit if the trio
  ever needs deeper companion files (`.env` walkthroughs, end-to-end fixture
  workspaces, etc.).
- Showing pre-edit `bootstrap` output. The contract example is the curated
  post-edit shape — that's what the rest of the README assumes.
- An auth-variants table for `_source.yml` (bearer / basic / api_key).
  Mentioned in passing only; the templating shape is identical to the SQL
  example's `env_var(...)` pattern.

## Decision

Add a new `## Example workspace` H2 section to `README.md`, inserted between
the existing Quickstart and Concepts sections.

### Placement

After the `das ingest finance` block at the end of Quickstart (currently
ending around line 79, "contract-enforced staging tables live in
`./das.duckdb`"), and before the `## Concepts` heading. The reader's flow
becomes: pitch → architecture → run-the-commands → see-the-files → vocabulary.

### Section structure

1. **Opening paragraph (≤ 3 sentences).** Frames the examples as "what `das
   init` and `das source add --type odata` produced for the AdventureWorks
   Quickstart, plus the curated contract you'd typically hand-edit after
   `bootstrap`."

2. **File tree** in a `text` fence:

   ```
   .
   ├── das.yaml
   ├── .env
   └── contracts/
       └── adventureworks/
           ├── _source.yml
           └── products.odcs.yaml
   ```

   `.env` appears in the tree but its contents are not shown — Quickstart
   already mentions editing it.

3. **`das.yaml`** — a `yaml`-fenced block containing the verbatim contents of
   `DAS_YAML_TEMPLATE` from `src/das_cli/cli.py:74` (the DuckDB default
   `das init` writes). Followed by a one-line note: "For DuckLake or Delta
   targets, see ADR-0016 / ADR-0017."

4. **`contracts/adventureworks/_source.yml`** — a `yaml`-fenced block
   matching the OData output of `_source_yml_template(...)` in
   `src/das_cli/cli.py:247` for the Quickstart URL
   (`https://demodata.grapecity.com/adventureworks/odata/v1`,
   `--auth none`).

5. **`contracts/adventureworks/products.odcs.yaml`** — a `yaml`-fenced block
   matching the `PRODUCTS` fixture in `tests/unit/test_validator.py:32`
   verbatim (its `id` is already `adventureworks.products`; no rename
   needed). Demonstrates: schema with PK (`product_id`, integer → bigint,
   physical name `ProductId`), `name` (string, required), `modified_at`
   (timestamp, physical name `ModifiedDate`), and one `customProperties`
   entry: `{ property: das.cursor, value: modified_at }`. Followed by a
   one-line pointer to ADR-0011 / ADR-0014 for the `das.*` namespace.

6. **`### Other source shapes`** (H3 subsection). Two `yaml`-fenced blocks
   containing only the differing `_source.yml` body — no `das.yaml` or
   contract repetition.

   - **OpenAPI / REST:** matches `_source_yml_template` output for
     `--type openapi --url https://api.example.com/v1 --auth none`
     (so `swagger_url: https://api.example.com/v1/swagger.json`). Followed
     by a one-sentence note plus a tiny inline `yaml` block illustrating
     the `customProperties` entry that resource contracts under OpenAPI
     sources need — `{ property: das.endpoint, value: { path: /Customers,
     response_path: $.value } }` — keyed off `tests/unit/test_validator.py:136`
     (`CUSTOMERS_WITH_ENDPOINT`).

   - **SQL:** matches `_source_yml_template` output for source name
     `finance`, `--type sql --url
     "oracle+oracledb://oracle-host:1521/?service_name=XEPDB1"`. The
     username and password appear as the literal
     `{{ env_var('FINANCE__USERNAME') }}` /
     `{{ env_var('FINANCE__PASSWORD') }}` strings produced by
     `_inject_env_var_userinfo`, since that's what `source add` actually
     writes and what `_source.yml` parses. (Source name `finance` matches
     the SQL example already in Quickstart.)

### Source-of-truth rule

Every YAML block in the new section must be byte-identical to one of:

- the literal `DAS_YAML_TEMPLATE` string in `src/das_cli/cli.py`;
- output that `_source_yml_template(name, source_type, url, auth_type)`
  in `src/das_cli/cli.py` would produce for the documented arguments;
- a canonical test fixture under `tests/unit/test_validator.py` (`PRODUCTS`,
  `SOURCE_YML`, `SOURCE_YML_OPENAPI`, `SOURCE_YML_SQL`,
  `CUSTOMERS_WITH_ENDPOINT`) modulo source/resource renaming
  (`x` / `northwind` / `adventureworks`).

No invented YAML. This is what stops the README from drifting away from
what `das` actually emits.

### ADR cross-references

Match existing README style (parenthetical bracketed ADR mentions, e.g.
"(ADR-0002, ADR-0003)"). The new section gets references at most once per
block:

- `das.yaml` block → "(ADR-0016 / ADR-0017 for DuckLake / Delta.)"
- `_source.yml` block → "(ADR-0005 covers the contract/source split;
  ADR-0007 covers secrets via `env_var`.)"
- Contract block → "(ADR-0011, ADR-0014 cover the `das.*` namespace.)"
- OpenAPI shape note → "(ADR-0014, ADR-0015.)"
- SQL shape note → "(ADR-0018.)"

No code-style `# See ADR-NNNN` comments inside YAML blocks. README YAML is
illustrative, not load-bearing code; ADR pointer comments belong in real
code per `CLAUDE.md`.

## Alternatives considered

- **Fold examples into the existing Concepts bullets.** Rejected: would
  bloat Concepts (each bullet currently 2–3 lines; adding fenced YAML
  pushes them to 12–20 lines each) and mixes the "vocabulary" and
  "concrete shape" jobs. Keeping them as adjacent H2s preserves both jobs.

- **Inline YAML between the Quickstart bash commands.** Rejected: the
  command/output interleaving is heavy on the page and forces bash-first
  readers to step over YAML. The current Quickstart is deliberately
  copy-paste-only.

- **Per-source minigroups (one full trio per source type).** Rejected:
  duplicates `das.yaml` and the contract block three times to show a
  single-block diff in `_source.yml`. The "only `_source.yml` varies" point
  is itself worth surfacing.

- **Separate `examples/` directory with full sample workspaces.** Rejected
  for now (YAGNI). If the trio ever needs companion files (`.env`,
  per-destination `das.yaml`, multi-resource contracts), file an issue and
  add the directory in a follow-up.

- **Bare ODCS contract with no `das.*` properties.** Rejected: skips the
  one piece of the contract that's actually das-cli-specific, defeating
  the purpose of showing it.

## Consequences

**Positive.**
- New users can recognise the files `das init` / `das source add` write
  without leaving the README.
- The "only `_source.yml` varies per source type" insight is now visible.
- `das.cursor` and `das.endpoint` — the two `das.*` properties a real user
  is likeliest to touch — both have concrete examples on the README page.
- README stays a storefront (no `examples/` directory to maintain in
  parallel).

**Negative.**
- README grows by roughly 60–80 lines (one trio + two variant snippets +
  framing).
- Three source-of-truth coupling points: if `DAS_YAML_TEMPLATE` or
  `_source_yml_template` ever change shape, the README block must be
  updated in lockstep. Mitigation: the "Source-of-truth rule" subsection
  above is the checklist; no automated drift detection is added (YAGNI).

**Neutral.**
- This is a docs-only change. No code, no ADR, no test changes. The
  workspace `.gitignore` change visible in `git status` is unrelated and
  out of scope.

## Implementation notes

- Single PR. No code changes. No new ADR (no architectural decision being
  made — this just surfaces existing decisions).
- The PR description should close issue #46.
- Manual verification: render the README on GitHub's preview (or
  `gh pr view --web`) and confirm each YAML block lints as valid YAML.
- No tests required: nothing in `tests/` reads the README.
