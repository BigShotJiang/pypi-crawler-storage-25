# Verify SQL sources (Oracle + SQL Server) — design

- **Status:** Draft
- **Date:** 2026-05-08
- **Branch:** `claude/brainstorm-issue-31-85hF3`
- **Closes:** [#31 — Verify Oracle source](https://github.com/mattiasthalen/das-cli/issues/31), [#32 — Verify SQL Server source](https://github.com/mattiasthalen/das-cli/issues/32)

## Context

das-cli's v0.1 design (line 448) listed `type: sql` as a placeholder using
"dlt's `sql_database` source" with "connection from `_source.yml`," but
nothing was implemented. `models/source_yml.py` already accepts `sql` as a
literal `SourceType`; `dlt_glue/source_factory.py:148` raises
`UnknownSourceTypeError` for it; `bootstrap/` has no SQL module.

Two open issues — #31 (Oracle) and #32 (SQL Server) — ask to verify a SQL
source. Verifying each independently would mean two near-duplicate ADRs,
two parallel source-factory builders, and two seed-data fixtures for the
same plumbing. dlt's `sql_database` source already runs through SQLAlchemy
and is driver-agnostic on the read side, so adding both at once is
strictly cheaper than adding them in sequence.

This design closes both issues with one ADR, one source-factory branch,
one bootstrap module, and one e2e pattern that exercises Oracle Free and
SQL Server 2022 dev edition via testcontainers. Postgres, MySQL, SQLite,
and DuckDB-as-source remain unverified — they almost certainly work via
the same SQLAlchemy path, but "verified = real e2e" stays the project's
honest contract.

## Goals

- Add Oracle and SQL Server rows to the README "Verified" matrix,
  exercised against the DuckDB destination.
- Wire `_source.yml.type: sql` end-to-end: bootstrap (live SQLAlchemy
  reflection), extract (`dlt.sources.sql_database.sql_table`), and the
  existing P2 unchanged.
- Verify with two real DBs in testcontainers: gvenzl/oracle-free
  (slim-faststart variant) and mcr.microsoft.com/mssql/server:2022-latest.
- File one ADR (analog of ADR-0016 for destinations) so a future SQL
  dialect addition is a config-and-driver-extra change.
- Preserve full backwards compatibility: existing OData/OpenAPI workspaces
  and contracts behave identically.

## Non-goals

- Postgres, MySQL, SQLite, DuckDB-as-source as **verified**. Likely work
  via the same path; file as separate follow-ups when needed.
- SQL sources × DuckLake destination matrix coverage. The plumbing is
  destination-agnostic (P1 writes JSONL, P2 dispatches per ADR-0016), so
  cross-coverage is mechanical — file as a follow-up to keep this PR
  scoped to the source side.
- `das contract diff` for SQL. Mirrors the OpenAPI deferral. Re-reflect-
  and-compare is the natural future implementation.
- `das.query` custom-query resources (compute one resource from a SQL
  expression). Defer to a v2 follow-up; one-resource-per-table covers the
  verification surface.
- Materialized views, synonyms, sequences, stored procedures.
- Log-based / CDC change capture. ADR-0004 row-hash change detection in
  P2 still applies unchanged.
- Per-driver advanced auth: Oracle wallet, SQL Server Kerberos / Azure
  AD / Entra ID, AWS RDS IAM. Connection-string passthrough only —
  whatever the SQLAlchemy URL encodes works.
- A `mssql-python` dialect contribution upstream. See "SQL Server driver
  choice" below.

## Design

### `_source.yml` shape

A SQL source declares connection via a SQLAlchemy URL in the existing
`endpoint` field. Secrets template through Jinja `env_var(...)`
(ADR-0007), the same pattern used for HTTP auth headers today.

```yaml
type: sql
endpoint: "oracle+oracledb://{{ env_var('FINANCE__USERNAME') }}:{{ env_var('FINANCE__PASSWORD') }}@oracle-host:1521/?service_name=XEPDB1"
spec:
  kind: sql
  schemas: [HR]                     # optional; defaults to connection user's default schema
  tables: [EMPLOYEES, DEPARTMENTS]  # optional; if absent, all tables in `schemas` are reflected
  include_views: false              # optional; default false. Views extract as tables when true.
auth:
  type: none                        # creds are templated into `endpoint`; auth block is no-op for SQL
ownership:
  team: data-platform
```

The OData/OpenAPI shapes are unchanged. `auth: {type: none}` is
intentional for SQL: the URL holds the credentials, so the auth block
adds nothing. SQL Server's equivalent endpoint:

```yaml
endpoint: "mssql+pyodbc://{{ env_var('SALES__USERNAME') }}:{{ env_var('SALES__PASSWORD') }}@sqlserver-host:1433/master?driver=ODBC+Driver+18+for+SQL+Server&Encrypt=no"
```

#### Model changes

- `models/source_yml.py`:
  - Extend `SpecKind` literal to include `"sql"`.
  - Extend `SpecConfig` with optional `schemas: list[str] | None = None`,
    `tables: list[str] | None = None`, `include_views: bool = False`.
- Validator (existing extra-fields-forbidden discipline carries through):
  - `kind == "sql"` rejects `metadata_url` / `swagger_url`.
  - `kind in {"odata", "openapi"}` rejects `schemas` / `tables` /
    `include_views`.

### `das source add --type sql` ergonomics

The existing `--url` flag accepts a SQLAlchemy URL **without** userinfo.
das-cli auto-injects `env_var(...)` placeholders for username/password
into the URL written to `_source.yml`, and appends a `<PREFIX>__USERNAME`
+ `<PREFIX>__PASSWORD` block to `.env` (the same block today's
`--auth basic` produces).

```bash
das source add finance \
  --type sql \
  --url "oracle+oracledb://oracle-host:1521/?service_name=XEPDB1"
```

Rejection rules:

- If the user-provided URL contains a `userinfo` part
  (`scott:tiger@host`), `source add` exits non-zero with: *"SQLAlchemy
  URLs in --url must not contain credentials; das will template them
  via env_var. Set credentials in .env after `source add`."*
- If `--auth` is passed with `--type sql`, exit non-zero with:
  *"--auth is not used for sql sources; credentials are templated
  into the endpoint URL."*

Why URL-only, not discrete flags (`--driver`, `--host`, `--port`,
`--service`, `--username`):

- Five-plus flags per driver, and Oracle vs. MSSQL spell things
  differently (`service_name` vs. `database`, ODBC `driver=` query-
  string parameter, Oracle TNS names).
- We would be reimplementing a chunk of SQLAlchemy's URL builder, on
  top of SQLAlchemy. Same trap ADR-0006 and ADR-0016 rejected.
- One `--url` is what users paste from a DBA runbook.

The escape hatch — hand-edit `_source.yml` after `source add` — covers
unusual URLs (TLS args, Oracle wallet paths, MSSQL trusted-connection
strings).

### Bootstrap via SQLAlchemy reflection

`das contract bootstrap <source>` adds a third dispatch branch:

```python
elif scfg.spec.kind == "sql":
    from das_cli.bootstrap.sql import bootstrap_sql_contracts
    loaded = bootstrap_sql_contracts(scfg, source_name=source)
```

`bootstrap_sql_contracts(scfg, source_name) -> list[LoadedContract]`
flow (`src/das_cli/bootstrap/sql.py`, new module):

1. `engine = sqlalchemy.create_engine(scfg.endpoint)`.
2. Determine target schemas: `scfg.spec.schemas` if set, else
   `[engine.dialect.default_schema_name(connection)]`.
3. For each schema, `MetaData().reflect(engine, schema=<s>,
   only=scfg.spec.tables, views=scfg.spec.include_views)`.
4. For each reflected `Table`, emit one ODCS contract:
   - `resource_name = snake_case(table.name)` (reuses
     `bootstrap/naming.py`).
   - `physicalName = table.name` (preserves DB-side casing).
   - For each `Column`, emit `OdcsProperty(name=snake_case(col.name),
     physicalName=col.name, logicalType=..., physicalType=...,
     required=not col.nullable, primaryKey=col.primary_key)`.
   - `customProperties` carry `das.spec_ref: {schema: <schema>,
     table: <table.name>}` — analog of the OData `das.spec_ref.type`
     pointer the existing factory reads.
5. Cursor inference reuses the OData heuristic (`bootstrap/odata.py:
   _pick_cursor`): pick the first column whose lowercased name matches
   a hint set (`updated_at`, `modified_at`, `last_modified`,
   `updated_date`, `modified_date`). Materialized as
   `das.cursor: <column>` exactly like OData today.

Why SQLAlchemy reflection over per-dialect catalog SQL we own: SQLAlchemy
already dispatches the right catalog query per dialect (`information_
schema.columns` for Postgres / MySQL / MSSQL, `ALL_TAB_COLUMNS` +
`ALL_CONSTRAINTS` for Oracle, `sqlite_master` for SQLite) and returns a
uniform `Table`/`Column` shape. Owning per-dialect SQL would reimplement
this with no offsetting benefit — we already pull SQLAlchemy via
`dlt[sql_database]`.

#### Type mapping table

`bootstrap/sql.py` carries a SQLAlchemy-generic-type → ODCS table,
analogous to `_EDM_TO_LOGICAL` in `bootstrap/odata.py`:

| SQLAlchemy generic type | ODCS `logicalType` | ODCS `physicalType` |
|---|---|---|
| `Integer`, `SmallInteger` | `integer` | `null` |
| `BigInteger` | `integer` | `bigint` |
| `Numeric(p, s)` | `number` | `decimal(p,s)` |
| `Float`, `Double` | `number` | `null` |
| `Boolean` | `boolean` | `null` |
| `String`, `Text`, `Unicode`, `UnicodeText` | `string` | `null` |
| `Date` | `date` | `null` |
| `Time` | `string` | `null` (no native ODCS Time; serialized as ISO string) |
| `DateTime`, `TIMESTAMP` | `timestamp` | `null` |
| `LargeBinary`, `BLOB` | `string` | `null` (serialized base64; see "Risk surface") |
| Unknown | `string` | `null` (fallback, with a `bootstrap`-time warning) |

BLOB/`LargeBinary` columns are accepted as base64-encoded strings: the
warehouse column is text, but the content round-trips losslessly through
base64. Contract column descriptions note the encoding.

### Source factory dispatch

`dlt_glue/source_factory.py:build_extract_resources` adds a SQL branch
analogous to ADR-0016's destination dispatch — same pattern, no registry:

```python
def build_extract_resources(scfg, contracts, *, source_name, limit=None, progress_handle=None):
    if scfg.type in _HTTP_SOURCE_TYPES:
        return _build_http_resources(...)
    if scfg.type == "sql":
        return _build_sql_resources(...)
    raise UnknownSourceTypeError(...)
```

`_build_sql_resources` (skeleton — exact import paths confirmed during
implementation; dlt 1.26 ships `dlt[sql_database]` as a separately-
installed extra):

```python
def _build_sql_resources(scfg, contracts, *, source_name, limit=None, progress_handle=None):
    from dlt.sources.sql_database import sql_table
    from sqlalchemy import create_engine
    engine = create_engine(scfg.endpoint)
    out = []
    for contract in contracts:
        spec_ref = get_das_value(contract.contract.custom_properties, "das.spec_ref") or {}
        schema = spec_ref.get("schema")
        table = spec_ref.get("table") or contract.physical_name
        cursor = get_das_value(contract.contract.custom_properties, "das.cursor")

        @dlt.resource(
            name=contract.resource_name,
            write_disposition="append",
            columns={"_data": {"data_type": "json", "nullable": False}},
            primary_key=None,
        )
        def _gen(table=table, schema=schema, cursor=cursor):
            # `das.spec_ref` is populated by `bootstrap_sql_contracts`. For
            # hand-written contracts that omit it, `table` falls back to
            # `contract.physical_name` and `schema` falls back to dlt's
            # behavior (the connection user's default schema), matching how
            # an OData contract without `das.endpoint` falls back today.
            base = sql_table(
                credentials=engine,
                table=table,
                schema=schema,
                incremental=dlt.sources.incremental(cursor) if cursor else None,
                chunk_size=10_000,
            )
            stream = ({"_data": row} for row in base)
            if limit is not None:
                stream = _limit_gen(stream, limit)
            if progress_handle is not None:
                stream = progress_handle.wrap(contract.resource_name, stream)
            yield from stream
        out.append(_gen)
    return out
```

Notes:

- One `sql_table` per contract — symmetric with one `_make_http_resource`
  per contract today.
- `engine` is shared across resources in one extract run (SQLAlchemy
  pools connections). `extract.run_extract` gains a `try / finally` that
  disposes the engine after the run. HTTP sources need no equivalent.
- `chunk_size=10_000` matches dlt's default; the existing JSONL writer
  batches lines independently.
- `columns={"_data": {"data_type": "json", ...}}` and
  `primary_key=None` are the same blob discipline as
  `_make_http_resource` — ADR-0003. P1 stays append-only blob; the
  contract's PK is enforced in P2.

Incremental cursor: if the contract has `das.cursor: <column>`, wrap with
`dlt.sources.incremental(<column>)`. dlt persists the cursor under
`./_dlt_pipelines/`. `das extract --full` clears state via existing
behavior; no new code path.

#### JSON serialization edges

| Python type from SQLAlchemy | dlt's normalizer behavior | Acceptable? |
|---|---|---|
| `int`, `float`, `str`, `bool`, `None` | passthrough | yes |
| `datetime.datetime`, `datetime.date`, `datetime.time` | ISO 8601 string | yes |
| `decimal.Decimal` | string (preserves precision) | yes |
| `bytes` (BLOB / RAW) | base64 string | yes (see type mapping) |
| `uuid.UUID` | string | yes |
| Oracle `LOB` objects | dlt reads via `read()` to `str` / `bytes` | verified in e2e |

dlt's `sql_database` runs everything through the same normalizer it uses
for destinations. das-cli does not implement a custom serializer. If a
type slips through that dlt does not normalize, the JSONL writer will
raise; we catch and re-raise with a contract-pointing message
(analogous to today's freeze-violation reporting in P2).

### SQL Server driver choice

Locked to `mssql+pyodbc` with Microsoft's ODBC Driver 18.

- Microsoft positioned `pyodbc` as the long-standing primary driver
  pre-`mssql-python`. dlt's MSSQL examples use it. SQLAlchemy 2.x
  documents it as the best-supported MSSQL dialect. Full Azure / Entra
  ID compatibility.
- `pymssql` (community / FreeTDS) considered: SQLAlchemy 2.x supports
  it, dlt would happily run through it, and CI footprint is slimmer (no
  system deps). Rejected because Microsoft does not recommend it,
  Azure SQL is painful (default wheels lack SSL bindings), and
  maintenance is sparse.
- `mssql-python` (Microsoft's new in-house driver, recently moved out
  of preview to GA) considered: faster than pyodbc per Microsoft's
  benchmarks. Rejected because no registered SQLAlchemy dialect exists
  (verified against the project's README and SQLAlchemy 2.x dialect
  list), so it cannot plug into `dlt.sources.sql_database` without an
  upstream contribution. Out of scope for this issue; revisit when a
  community or Microsoft-authored dialect ships.

CI cost: e2e jobs install `msodbcsql18` and `unixodbc-dev` via
`apt-get`. Two extra workflow lines, gated to the e2e job. Local devs
running `pytest -m e2e` see a skip message pointing to Microsoft's
install docs when the driver is missing.

### Doctor

`src/das_cli/doctor.py` adds a one-line note when `scfg.type == "sql"`:

- The `endpoint` field parses as a SQLAlchemy URL (`make_url(...)`
  succeeds).
- The dialect's driver wheel is importable
  (`engine.dialect.dbapi` returns without `ImportError`).

Not a connection attempt — config-typo hygiene only. Mirrors the
DuckLake doctor note added in #22.

## Test strategy

Three layers, mirroring `tests/unit`, `tests/integration`, `tests/e2e`.

### Unit — pure-Python, no DB, no Docker

- `tests/unit/test_source_factory_sql.py`
  - `build_extract_resources` returns SQL resources for `type: sql`,
    HTTP resources for HTTP types, raises `UnknownSourceTypeError` for
    `type: filesystem` (still unbuilt).
  - `_build_sql_resources` reads `das.spec_ref.schema` and
    `das.spec_ref.table` from each contract.
  - `das.cursor` presence wires `dlt.sources.incremental(...)`;
    absence does not.
- `tests/unit/test_bootstrap_sql.py`
  - Type mapping table: each SQLAlchemy generic type → expected ODCS
    `logicalType` / `physicalType`.
  - Cursor inference: a table with `updated_at` gets
    `das.cursor: updated_at`; a table without any hint column gets none.
  - PK detection: single-column PK lands on one property; composite PK
    lands on multiple.
  - Schema scoping: `spec.schemas` empty/absent → uses
    `default_schema_name`; `spec.tables` filter narrows reflection.
  - Driver: SQLAlchemy + **SQLite in-memory**. SQLite is in stdlib;
    no Docker, no network. We test the mapping logic, not Oracle-
    specific behavior.
- `tests/unit/test_source_yml_model.py` (extend)
  - `spec.kind: sql` accepts `schemas` / `tables` / `include_views`;
    rejects `metadata_url` / `swagger_url`.
  - `spec.kind: odata` / `openapi` rejects
    `schemas` / `tables` / `include_views`.
- `tests/unit/test_cli_source_add.py` (extend)
  - `source add --type sql --url <DSN with userinfo>` exits non-zero
    with the credentials-rejection message.
  - `source add --type sql --url <clean DSN>` writes `_source.yml`
    with `endpoint:` containing the templated
    `env_var('PREFIX__USERNAME')` and `env_var('PREFIX__PASSWORD')`,
    and appends the `.env` block.
  - `source add --type sql --auth basic` is rejected with the
    URL-templating-only message.

### Integration — real SQLite via SQLAlchemy, no Docker

- `tests/integration/test_extract_pipeline_sql.py`
  - Stand up a SQLite DB in `tmp_path` with two tables and a few rows.
  - Hand-write `_source.yml` and ODCS contracts (or run `bootstrap`).
  - Invoke `das extract`. Assert: JSONL files appear under `landing/`,
    each row has `_data` populated with the row dict, `_extracted_on`
    partition is set.
  - Two cycles + an UPDATE between them: cursor-driven incremental
    picks up only the new rows when `das.cursor` is set; full mode
    picks up everything.
- `tests/integration/test_bootstrap_sql.py`
  - Reflect a SQLite schema with mixed types (int, text, real, date as
    text, blob), a composite-PK table, and one view (with
    `include_views: true`). Assert emitted ODCS YAML matches a golden
    file under `tests/fixtures/`.

The integration tier intentionally hits SQLite to keep CI fast and
dependency-light. Oracle and MSSQL idiosyncrasies live in e2e.

### E2E — testcontainers, opt-in via `pytest -m e2e`

- `tests/e2e/test_oracle.py`
  - Pytest fixture spins `gvenzl/oracle-free:slim-faststart`, waits
    for ready (180s ceiling), runs the seed SQL.
  - Test runs the CLI happy path: `init` → `source add --type sql` →
    `contract bootstrap` → `extract` → `load`. Asserts row counts in
    the destination, BLOB round-trip via base64, cursor-driven
    idempotence on a second extract.
  - `oracledb` wheel added as a dev dep for the e2e job. No system
    package install required (oracledb's "thin" mode is pure-Python).
- `tests/e2e/test_sqlserver.py`
  - Same shape; container is `mcr.microsoft.com/mssql/server:2022-latest`.
    Driver: `mssql+pyodbc` with ODBC Driver 18.
  - `pyodbc` wheel as a dev dep. CI workflow gains
    `apt-get install -y msodbcsql18 unixodbc-dev` gated to the e2e job.
  - Skip message on missing driver points to Microsoft's install docs.

#### Seed schema (das-cli-owned, not AdventureWorks/Northwind)

```sql
-- Oracle dialect
CREATE TABLE customers (
  customer_id   NUMBER(10) PRIMARY KEY,
  name          VARCHAR2(100) NOT NULL,
  created_at    TIMESTAMP NOT NULL,
  updated_at    TIMESTAMP NOT NULL              -- cursor column
);
CREATE TABLE orders (
  order_id      NUMBER(10),
  line_no       NUMBER(5),
  customer_id   NUMBER(10) NOT NULL,
  amount        NUMBER(12, 2) NOT NULL,
  PRIMARY KEY (order_id, line_no)               -- composite PK
);
CREATE TABLE attachments (
  attachment_id NUMBER(10) PRIMARY KEY,
  payload       BLOB                             -- base64 round-trip
);
```

Same shape for SQL Server (translated types: `BIGINT`, `NVARCHAR(100)`,
`DATETIME2`, `DECIMAL(12,2)`, `VARBINARY(MAX)`). 30 rows total per DB,
deterministic content. Lives in
`tests/e2e/fixtures/sql_seed_oracle.sql` and `..._sqlserver.sql`.

## Implementation sequence

Each step is a separately-green commit.

1. **Models + spec validation.** Extend `SourceConfig.spec` to accept
   `kind: sql` with `schemas` / `tables` / `include_views`. Unit tests
   for the model + validator. No new runtime behavior yet.
2. **Bootstrap module.** New `bootstrap/sql.py` driving SQLAlchemy
   reflection → ODCS contracts. SQLite-driven unit + integration tests.
   Wire into `cli.py contract bootstrap` dispatch.
3. **Source factory dispatch.** `_build_sql_resources` in
   `dlt_glue/source_factory.py`. Engine-disposal `try / finally` in
   `extract.run_extract`. SQLite-driven integration test for full
   extract round-trip with cursor.
4. **CLI ergonomics.** `source add --type sql`: URL-credential
   rejection, env-block templating, `--auth` flag rejection. Unit tests.
5. **Doctor note.** SQL source URL parseability + driver-importability
   check. Existing doctor exit-code semantics carry through.
6. **E2E — Oracle.** `tests/e2e/test_oracle.py` with testcontainers +
   gvenzl/oracle-free seed. `oracledb` extra in test deps. CI workflow
   add: nothing extra (gvenzl image is self-contained; oracledb thin
   mode is pure-Python).
7. **E2E — SQL Server.** `tests/e2e/test_sqlserver.py` with
   testcontainers + mcr.microsoft.com/mssql/server:2022-latest seed.
   `pyodbc` test dep. CI workflow add:
   `apt-get install -y msodbcsql18 unixodbc-dev` gated to the e2e job.
8. **ADR + README + index.** ADR-0018, ADR index row, README "Verified"
   matrix and quickstart example.

## Risk surface

- **gvenzl/oracle-free boot time variance.** `slim-faststart` typically
  ~30s but spikes on slow CI runners. Mitigation: testcontainers'
  `wait_for_logs` plus a 180s ceiling; e2e jobs run on a workflow with
  a longer timeout.
- **ODBC Driver 18 install on macOS dev machines.** Apple-silicon
  installs of `msodbcsql18` via Homebrew sometimes need post-install
  `odbcinst.ini` edits. Mitigation: e2e fixture skip-message points to
  Microsoft's install docs.
- **SQLAlchemy reflection of large schemas.** Reflecting all of Oracle's
  `SYS` is hostile. Mitigation: validator requires explicit
  `spec.schemas` for any production-shaped use; the test seed exercises
  the default-schema fallback to confirm it works on the demo user.
- **JSON serialization edge types not covered by dlt's normalizer.**
  Mitigation: e2e seeds include `BLOB`, `TIMESTAMP WITH TIME ZONE`,
  `NVARCHAR(MAX)`, and composite PK to flush these out early.
- **MSSQL identifier case sensitivity.** Reflection returns whatever case
  the catalog stores. `bootstrap/naming.py:snake_case` handles
  normalization without surprise.
- **dlt `sql_table` import path.** `dlt.sources.sql_database.sql_table`
  is the documented entry point on dlt 1.26 and ships under
  `dlt[sql_database]`. The implementation step verifies the exact
  import; if the path differs in 1.x patch releases, the dispatch
  function adopts the actual one. Same risk-handling pattern ADR-0016
  used for `DatabaseUndefinedRelation`.

## ADR

One new ADR: **`docs/adrs/0018-sql-source-via-sqlalchemy.md`**.

- **Decision A:** source dispatch lives as a small `_build_sql_resources`
  branch in `dlt_glue/source_factory.py`, alongside the existing HTTP
  branch. No registry. Adding a future SQL dialect to the verified
  matrix is a driver-extra change plus an e2e test.
- **Decision B:** bootstrap reflects schemas via SQLAlchemy
  `MetaData.reflect`. das-cli does not own per-dialect catalog SQL.
  Type mapping covers SQLAlchemy generic types only; dialect-specific
  types fall back to `string` with a `bootstrap`-time warning.
- **Decision C:** SQL connection URL lives in `_source.yml.endpoint`,
  templated with Jinja `env_var(...)` for credentials. Symmetric with
  ADR-0016's URL-passthrough convention for DuckLake's `catalog`. The
  `auth` block is no-op for SQL.
- **Decision D:** SQL Server uses `mssql+pyodbc` + ODBC Driver 18.
  pymssql considered and rejected (community, weak Azure story);
  `mssql-python` considered and rejected (no SQLAlchemy dialect
  available, would require upstream contribution).
- **Alternatives considered:** registry-style source dispatch
  (rejected, same reasoning as ADR-0016); per-dialect catalog SQL we
  own (rejected, reimplements SQLAlchemy with no offsetting benefit);
  `das.query` custom-query resources (deferred).
- **Consequences:** das-cli now imports SQLAlchemy and the
  `dlt[sql_database]` extra at runtime. Per-source driver wheels
  (`oracledb`, `pyodbc`) are the user's responsibility to install;
  pyproject does not pull them as defaults — installing them is
  documented in the README quickstart for SQL sources. Locks in
  SQLAlchemy reflection as a contract surface; a dialect without
  reflection support could not be bootstrapped without per-dialect
  catalog SQL, which would require revisiting this ADR.

## Documentation updates

- `README.md` "Verified" matrix — add `Oracle (oracledb)` and
  `SQL Server (pyodbc)` rows against `DuckDB`. DuckLake-as-target for
  SQL sources is filed as a follow-up per Non-goals.
- `README.md` Quickstart — append a small `--type sql` example block
  under the existing OData example.
- `docs/adrs/README.md` — append the ADR-0018 row.
- Inline `# See ADR-0018` comments on `_build_sql_resources` and
  `bootstrap_sql_contracts`, per the CLAUDE.md pointer-to-ADR
  convention.

## Done criteria

- All existing tests green (unit, integration, e2e).
- New tests green: unit `test_source_factory_sql.py`,
  `test_bootstrap_sql.py`; extended `test_source_yml_model.py` and
  `test_cli_source_add.py`; integration `test_extract_pipeline_sql.py`,
  `test_bootstrap_sql.py`; e2e `test_oracle.py`, `test_sqlserver.py`
  under `pytest -m e2e`.
- README "Verified" matrix lists Oracle and SQL Server against DuckDB.
- `docs/adrs/0018-sql-source-via-sqlalchemy.md` committed; ADR index
  row added.
- Pre-commit (ruff, mypy strict) clean.
- Backwards compatibility verified: existing OData/OpenAPI workspaces,
  contracts, and `_source.yml` files unchanged.
- Issues #31 and #32 close together.
