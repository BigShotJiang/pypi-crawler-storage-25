# Verify Delta destination — design

- **Status:** Draft
- **Date:** 2026-05-07
- **Branch:** `claude/brainstorm-issue-29-UNFsq`
- **Issue:** [#29 — Verify delta destination](https://github.com/mattiasthalen/das-cli/issues/29)

## Context

ADR-0016 established destination dispatch in `_build_destination` and pipeline-driven
reads through `pipeline.sql_client()`. DuckLake was the first non-DuckDB destination
verified under that pattern. The README's "Verified" matrix lists DuckDB and DuckLake;
the next destination to verify is **Delta**.

In dlt 1.x, Delta is not its own destination — it is a `table_format` on
`dlt.destinations.filesystem(...)`. The verification therefore touches two surfaces
beyond ADR-0016:

- A new dispatch branch that aliases `target.destination: delta` to a `filesystem`
  destination, with `table_format="delta"` plumbed through `_build_load_resource`
  per-resource (dlt 1.26 has no destination-level `default_table_format` kwarg).
  Users see "delta" in `das.yaml`; `_build_load_resource` takes a single optional
  `table_format` kwarg and stays destination-agnostic.
- The change-detection read path now relies on dlt's filesystem `sql_client()`, which
  is a DuckDB-backed in-memory client that reads Delta tables via `delta_scan`. This
  is structurally different from DuckDB/DuckLake's native SQL clients; ADR-0016's
  "any destination with sql_client" claim extends to it, but the contract surface
  is wider.

This design adds **Delta** as the third verified destination, with the smallest
verifiable slice (local filesystem only).

## Goals

- Add Delta to the verified destinations matrix, with end-to-end test coverage
  mirroring the existing AdventureWorks and Northwind tests for DuckDB and DuckLake.
- Extend `_build_destination` with a `delta` branch that maps to
  `dlt.destinations.filesystem(bucket_url=..., enable_dataset_name_normalization=False)`,
  with `table_format="delta"` propagated per-resource via `_build_load_resource`.
- Verify that `load_latest_hash` (ADR-0016) round-trips through filesystem's
  DuckDB-backed `sql_client()` against Delta tables.
- File ADR-0017 documenting the filesystem-alias decision and the extended
  contract surface.
- Preserve full backwards compatibility: existing DuckDB and DuckLake configs
  behave identically.

## Non-goals

- S3-, GCS-, or Azure-backed Delta storage. Filed as a follow-up issue.
- Iceberg or any other table format on filesystem.
- Parquet-only filesystem destination (no `table_format` pin). Possible future
  verification; not in scope here.
- Delta-specific compaction / vacuum / retention configuration.
- Reworking `_build_load_resource` to know about table formats.
- New CLI surface. Destinations stay configured in `das.yaml` `target:`.

## Design

### Verified Delta configuration

Local filesystem only. The smallest verifiable slice; runnable in CI without
external services.

```yaml
target:
  destination: delta
  credentials:
    bucket_url: ./das_delta          # local directory; Delta tables land here
```

`bucket_url` is forwarded verbatim — no auto-prefix gymnastics like DuckLake's
`catalog`. A bare path is just a path. If omitted, dispatch defaults to
`./das_delta`, mirroring the DuckDB default of `./das.duckdb` and the convention
of placing destination state under the workspace root.

`TargetConfig.credentials: dict[str, Any]` is already permissive enough; no
pydantic schema change needed.

Today's DuckDB and DuckLake shapes stay unchanged.

### Destination dispatch

A new branch in the existing `_build_destination` (`pipelines/load.py`):

```python
if name == "delta":
    bucket_url = creds.get("bucket_url", "./das_delta")
    return dlt.destinations.filesystem(
        bucket_url=bucket_url,
        enable_dataset_name_normalization=False,
    )
```

Three things to call out:

- **Alias, not raw `filesystem`.** Users see `destination: delta` in `das.yaml`.
  The `filesystem` name does not appear in user-facing config under this design;
  if Parquet-on-filesystem ever needs verification, it gets its own dispatch
  branch and matrix row.
- **Table format is per-resource, not destination-level.** dlt 1.26 does not
  expose a `default_table_format` kwarg on `dlt.destinations.filesystem`;
  `table_format` is set on each `@dlt.resource(...)`. `_build_load_resource`
  takes a new optional `table_format: str | None = None` kwarg, and `run_load`
  computes it from `cfg.target.destination` (`"delta"` → `"delta"`, otherwise
  `None`). This is the minimum coupling needed: the resource builder knows
  about a single string kwarg, not about destinations.
- **`enable_dataset_name_normalization=False` is unconditional**, per ADR-0016.

The `unknown destination` error message updates to list the third name:

```python
raise ValueError(
    f"Unsupported target.destination: {name!r}. "
    f"Verified destinations: duckdb, ducklake, delta."
)
```

### Change detection on Delta

No code change in `change_detection.py`. `load_latest_hash` already takes a
`dlt.Pipeline` and queries through `pipeline.sql_client()`. For a filesystem
destination, dlt opens an in-memory DuckDB client and exposes the configured
tables via `delta_scan`. The latest-hash query is read-only and the
`DROP/CREATE` semantics that change detection avoids are not triggered.

The `DatabaseUndefinedRelation` exception path (caught for the empty-destination
first-load case) extends to filesystem+Delta unchanged.

**Cross-pipeline reads constraint** (discovered during execution, captured in
ADR-0017 Decision C): unlike DuckLake's catalog-driven discovery, dlt's
filesystem `sql_client()` discovers tables from the pipeline's stored schema
state. Change detection is unaffected because it reads from the writer's own
pipeline. Test helpers and any other cross-pipeline reader must share the
writer's `pipeline_name` and `pipelines_dir` (`das_load` and `.dlt/pipelines`).

### Doctor

`src/das_cli/doctor.py` adds one branch next to the ducklake check:

```python
elif cfg.target.destination == "delta":
    if not cfg.target.credentials.get("bucket_url"):
        issues.append(
            DoctorIssue("target", "delta destination missing credentials.bucket_url")
        )
```

Config-typo hygiene only. No connectivity probe, no path-writability check —
mirrors the existing ducklake check.

### Extras

`pyproject.toml`:

```diff
- "dlt[duckdb,ducklake,filesystem,parquet]>=1.0",
+ "dlt[deltalake,duckdb,ducklake,filesystem,parquet]>=1.0",
```

`dlt[deltalake]` pulls the `deltalake` Python package (Rust-backed). Wheels
are available for x86_64 and arm64 on Linux/macOS/Windows; CI runs on standard
runners.

## Test strategy

Three layers, mirroring `tests/unit`, `tests/integration`, `tests/e2e` and
the DuckLake test set.

**Unit — extend `tests/unit/test_destination_dispatch.py`:**

- `_build_destination` returns a filesystem destination for `destination: delta`
  (`destination_type == "dlt.destinations.filesystem"`).
- `bucket_url` is forwarded verbatim (no auto-prefix).
- Default `bucket_url` (`./das_delta`) is used when the key is omitted.
- `enable_dataset_name_normalization=False` is set.
- The unknown-destination error message includes `delta` (matched via a
  `Unsupported target.destination.*delta` regex, not a brittle full enumeration).

**Integration — `tests/integration/test_load_pipeline_delta.py`:**

Three tests mirroring `test_load_pipeline_ducklake.py`:

- `test_delta_load_creates_table_with_contract_schema` — initial load creates
  the Delta table from the contract schema; row count matches landing.
- `test_delta_change_detection_suppresses_duplicate` — two cycles with identical
  landing should append zero rows on the second. **Real proof that
  `load_latest_hash` round-trips through filesystem's DuckDB-backed `sql_client()`
  against Delta tables.**
- `test_delta_a_b_a_preserved` — A → B → A produces three rows; change detection
  only suppresses no-ops.

Reads happen through a `dlt.pipeline(...)` configured to **share the writer's
`pipeline_name` and `pipelines_dir`** (see ADR-0017 Decision C). dlt's filesystem
`sql_client()` discovers tables from the pipeline's stored schema state, not
from filesystem metadata, so a separate reader pipeline would see no tables.
The reader is read-only — only `sql_client()` is used — so no writer-state
collision occurs.

**E2E — `tests/e2e/test_adventureworks_delta.py`, `tests/e2e/test_northwind_delta.py`:**

Near-copies of the existing `_ducklake.py` e2e tests:

- Workspace fixture targets Delta (local `bucket_url` under `tmp_path`).
- Source-add → bootstrap → extract → load chain identical to the DuckLake e2e.
- Read assertions through a Delta reader pipeline (analogous to
  `ducklake_reader_pipeline`).
- Behind `@pytest.mark.e2e`.

**Conftest changes** (`tests/conftest.py`):

- Add `delta_workspace` fixture next to `ducklake_workspace`. Same shape: writes
  a `das.yaml` targeting Delta, sets `DAS_LANDING_URL`, switches cwd.
- Add `delta_reader_pipeline` helper next to `ducklake_reader_pipeline`. Same
  signature pattern (takes `workspace`, optional `pipeline_name`).

## Implementation sequence

Each step is a separately-green commit.

1. **Probe `dlt.destinations.filesystem` for `default_table_format` support and
   the missing-table exception class on Delta.** A short throwaway script run
   in the dev environment that:
   - Constructs `dlt.destinations.filesystem(bucket_url=tmpdir, default_table_format="delta", enable_dataset_name_normalization=False)` and confirms it returns without error and that `config_params["default_table_format"] == "delta"`.
   - Writes one row through it, then runs a `pipeline.sql_client()` query against the resulting Delta table.
   - Triggers a missing-table query and confirms the exception class.

   If `default_table_format` is rejected, fall back in order: (a) `loader_file_format="delta"`, (b) per-resource `table_format` propagated through `_build_load_resource` via a new optional kwarg, (c) `pipeline.run(..., loader_file_format=...)` at the call site. Update the design before proceeding.

2. **Add `delta` branch to `_build_destination` + extras.** Extend
   `_build_destination`, add `deltalake` to the dlt extras in `pyproject.toml`,
   add unit tests for the dispatch (parallel to the ducklake unit tests). Update
   the unknown-destination error message.

3. **Add `delta_workspace` fixture and `delta_reader_pipeline` helper to
   `tests/conftest.py`.** Pure fixture/helper additions; no test code yet.
   Confirms the fixtures import cleanly.

4. **Integration test for Delta.** `test_load_pipeline_delta.py` with the
   three-test set. Real proof of the change-detection round-trip on Delta.

5. **E2E tests for Delta.** `test_adventureworks_delta.py`,
   `test_northwind_delta.py`. Behind `@pytest.mark.e2e`.

6. **Doctor.** One branch added next to the ducklake check + tests
   mirroring the ducklake doctor tests.

7. **ADR-0017.** File the ADR documenting the filesystem-alias decision and the
   extended contract surface. Append the index row to `docs/adrs/README.md`.

8. **README.** Two new rows in the Verified matrix; "What it is" lead updated
   to mention Delta as the third destination.

## Risk surface

- **`default_table_format` kwarg on `dlt.destinations.filesystem`.** The single
  architectural gamble. Discoverable in step 1's probe. Fallbacks listed above.
- **`pipeline.sql_client()` exception class on filesystem+Delta.** ADR-0016
  catches `DatabaseUndefinedRelation`. The filesystem sql_client uses an
  embedded DuckDB; the missing-table path may surface as a DuckDB
  `CatalogException` wrapped in a different dlt exception. Discoverable in
  step 1's probe. If different, `load_latest_hash` adopts the actual class
  — destination-agnostic by behavior, not by exception name.
- **Schema evolution on Delta.** Delta has its own schema-evolution semantics;
  dlt mediates, but the `tables: evolve, columns: freeze, data_type: freeze`
  contract may interact differently than DuckDB. Discoverable in the
  integration test's first-load step. If Delta rejects a `data_type: freeze`
  shape that DuckDB accepts, that surfaces as an integration-test failure.
- **`deltalake` Python package binary wheels.** Wheels are available for the
  CI matrix; no surprises expected.
- **Two-cycle change detection through `delta_scan`.** The whole point of the
  integration test. If it fails, ADR-0016/0017 need revision and filesystem
  destinations need their own change-detection path.

## ADRs

One new ADR: **`docs/adrs/0017-delta-destination-via-filesystem-alias.md`**.

- **Decision A:** `target.destination: delta` is an alias for
  `dlt.destinations.filesystem(bucket_url=..., enable_dataset_name_normalization=False)`,
  combined with a per-resource `table_format="delta"` set by
  `_build_load_resource`. The alias is owned by `_build_destination`; users
  do not see "filesystem" in `das.yaml` for this verified slice.
- **Decision B:** Table format is set per-resource via a new optional
  `table_format` kwarg on `_build_load_resource`, plumbed from
  `cfg.target.destination` in `run_load`. dlt 1.26 does not expose a
  `default_table_format` destination-level kwarg; per-resource is the only
  mechanism dlt provides. The coupling is a single string kwarg, not a
  destination-aware code path.
- **Decision C:** Change detection continues to read through
  `pipeline.sql_client()`. For the filesystem destination this is a
  DuckDB-backed in-memory SQL client that reads Delta tables via `delta_scan`.
  This extends ADR-0016's contract surface to filesystem-style sql_clients.
- **Alternatives considered:** `destination: filesystem` + `table_format: delta`
  (rejected — exposes a knob whose Parquet branch is unverified); separate
  `delta` and `filesystem` dispatch branches (rejected — premature). A
  destination-level `default_table_format` was preferred but is not exposed
  by dlt 1.26's filesystem factory (silently dropped), forcing the
  per-resource approach in Decision B.
- **Consequences:** dlt's filesystem `sql_client()` is now a contract surface
  alongside ADR-0016's general claim. The `delta` alias locks users out of
  Parquet-on-filesystem under that name; that is intentional — it is what is
  verified.

## Documentation updates

- `README.md` "Verified" matrix — add two `Delta` rows (OData and OpenAPI/REST).
- `README.md` "What it is" paragraph (line 12-13) — extend the destination list
  to include Delta: *"contract-enforced warehouse (DuckDB, DuckLake, or Delta)"*.
- `docs/adrs/README.md` — append the ADR-0017 row.
- Inline `# See ADR-0017` comment on the new `delta` branch in
  `_build_destination`, per the CLAUDE.md pointer-to-ADR convention.

## Done criteria

- All existing tests green (unit, integration, e2e for DuckDB and DuckLake).
- New Delta unit, integration, and e2e tests green.
- `README.md` "Verified" matrix lists Delta (two rows).
- `docs/adrs/0017-delta-destination-via-filesystem-alias.md` committed and
  indexed in `docs/adrs/README.md`.
- Pre-commit (ruff, mypy) clean.
- Backwards compatibility verified: existing `target.destination: duckdb` and
  `target.destination: ducklake` configs unchanged.
