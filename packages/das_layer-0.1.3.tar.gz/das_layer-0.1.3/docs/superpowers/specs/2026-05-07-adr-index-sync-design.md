# ADR Index Sync — Design

- **Date:** 2026-05-07
- **Issue:** [#21](https://github.com/mattiasthalen/das-cli/issues/21) — `docs(adrs): index out of sync after 0013→0014, 0014→0015 renumber`
- **Author:** mattiasthalen

## Context

Commit `32ae9d0` (`docs(adrs): renumber source-flexibility ADRs 0013→0014,
0014→0015`) renumbered two ADRs on the `v0.2-source-flexibility` branch before
merging to `main`, but the index in `docs/adrs/README.md` was not fully updated
to match. The current state:

- The last row of the index is labeled `0015` with the title "Load-date
  semantics", but the file on disk is `0013-load-date-semantics.md` and its
  front-matter heading is `# 0013.`. The row number is wrong.
- ADR-0014 (`0014-per-resource-das-endpoint.md` — "Per-resource `das.endpoint`
  for HTTP source resolution") is missing from the index.
- ADR-0015 (`0015-extend-openapi-bootstrap-to-walk-paths.md` — "Extend OpenAPI
  bootstrap to walk paths") is missing from the index.

A repository-wide audit of `ADR-001[3-5]` references was performed prior to
writing this spec. Findings:

- All `# See ADR-NNNN` citations in `src/` and `tests/` point at the correct
  current ADR (load-date for 0013; `das.endpoint` for 0014; OpenAPI walker
  for 0015).
- Top-level `README.md` ADR citations are correct.
- `docs/adrs/0006-bootstrap-mix-odata-openapi.md` carries the correct
  `(extended by ADR-0015)` annotation.
- Historical specs and plans under `docs/superpowers/` already use the
  post-renumber ADR numbers (they were authored on or after the renumber
  and document the work as performed). They are intentionally left as-is.

A subsequent verification sweep (`head -1 docs/adrs/0*.md` compared row-by-row
against `docs/adrs/README.md`) surfaced **two additional index drifts** beyond
the issue's reported problem:

- **ADR-0001** — file heading is `# 0001. Use Python (not Go) for the CLI`,
  but the index row reads "Python over Go for the CLI". Apparent wording-only
  drift; cause unknown.
- **ADR-0006** — file heading is `# 0006. Bootstrap mix: custom OData parser,
  direct OpenAPI walker`, but the index row reads "Bootstrap mix: custom
  OData parser, `datacontract-cli` for OpenAPI". The file heading was
  updated when ADR-0015 extended ADR-0006 to a direct walker; the index
  was never updated to match.

Both drifts are the same class of bug as the issue's reported problem (index
out of sync with on-disk file headings) and are folded into this fix.

A second observation: the renumber that produced issue #21 was almost
certainly a **branch-vs-main collision** — `v0.2-source-flexibility` carried
ADRs whose numbers collided with what landed on main, the branch renumbered
to dodge, and the index never caught up. The existing CLAUDE.md lifecycle
policy forbids post-merge renumbering but says nothing about pre-merge
collision detection or index synchronization. We add a pre-merge check to
close this gap.

## Decision

Two coordinated edits, one commit:

1. Edit the `docs/adrs/README.md` index table so every row's title matches
   its ADR file's `# NNNN.` heading verbatim (three row-level changes).
2. Add a "Pre-merge ADR check" subsection to `CLAUDE.md` documenting the
   collision-and-sync verification that contributors must run before
   opening or merging a PR that adds, removes, or renumbers an ADR.

### Index changes (`docs/adrs/README.md`)

#### Change 1 — ADR-0001 row

Replace:

```
| 0001 | Python over Go for the CLI | Accepted |
```

with:

```
| 0001 | Use Python (not Go) for the CLI | Accepted |
```

#### Change 2 — ADR-0006 row

Replace:

```
| 0006 | Bootstrap mix: custom OData parser, `datacontract-cli` for OpenAPI | Accepted |
```

with:

```
| 0006 | Bootstrap mix: custom OData parser, direct OpenAPI walker | Accepted |
```

#### Change 3 — broken last row

Replace:

```
| 0015 | Load-date semantics: hive partition + derived staging columns | Accepted |
```

with:

```
| 0013 | Load-date semantics: hive partition + derived staging columns | Accepted |
| 0014 | Per-resource `das.endpoint` for HTTP source resolution        | Accepted |
| 0015 | Extend OpenAPI bootstrap to walk paths                        | Accepted |
```

Titles for 0013 and 0014 are taken verbatim from their file headings. The
0015 title drops the backticks around `paths` to match the issue's
"Suggested fix" block; the file heading itself uses backticks. Status column
shows `Accepted` only (matching the existing index convention — annotations
like `(extended by ADR-0015)` are not surfaced in the index).

### Policy change (`CLAUDE.md`)

Insert a new subsection **immediately after** `### Lifecycle` (before
`### Before changing architectural behavior`) with the following content:

```markdown
### Pre-merge ADR check

Before opening or merging a PR that adds, removes, or renumbers an ADR:

1. Rebase on `main` and confirm no ADR file number on the branch collides
   with one already on `main`. If a collision exists, renumber the branch's
   ADR(s) before opening the PR (renumbering is allowed pre-merge per the
   lifecycle policy above).
2. Run `head -1 docs/adrs/0*.md` and confirm every ADR file has a matching
   row in `docs/adrs/README.md` whose title equals the file's `# NNNN.`
   heading verbatim.
3. Confirm `docs/adrs/README.md` has no rows referring to ADR numbers that
   don't exist as files.
```

### Verification

Before committing, run:

```sh
head -1 docs/adrs/0*.md
```

and visually confirm each `# NNNN. <title>` line matches the corresponding row
in the updated index (numbers 0001–0015). This is a one-shot sanity sweep, not
a recurring check.

## Alternatives considered

- **Verbatim fix only, no cross-check.** Edit just the three rows from the
  issue without the `head -1` sweep. Rejected because the sweep is ~30
  seconds and — as shown by this spec's revision — actually catches drift
  the issue reporter and the prior audit both missed.
- **Leave 0001/0006 drifts; file a follow-up issue.** Keeps PR scope tight
  to issue #21. Rejected because the drifts are the same class of bug, the
  fix is one-line each, and a separate PR for two-row edits is unnecessary
  ceremony.
- **Auto-generate the index from filesystem.** Replace the hand-maintained
  table with a script that scans `docs/adrs/0*.md` and emits the table from
  each file's `# NNNN.` heading and `**Status:**` line. Rejected as premature:
  the index changes a handful of times per release at most, and the renumber
  that triggered this issue is itself a forbidden operation post-merge per
  the project's ADR lifecycle policy. The cost of tooling outweighs the
  benefit.
- **Skip the CLAUDE.md policy update.** Trust the existing "only Status is
  editable post-merge" rule to prevent recurrence and rely on PR review to
  catch drift. Rejected because this fix uncovered drift (0001 and 0006)
  the existing policy didn't prevent and PR review didn't catch, and because
  the underlying issue (#21) was a branch-vs-main collision that the
  existing policy says nothing about.
- **Encode the pre-merge check as CI or a pre-commit hook.** Strongest
  guarantee. Rejected as premature: the index changes rarely, and a written
  policy in `CLAUDE.md` is the lowest-cost intervention that closes the
  practical loophole.

## Consequences

- **Positive.** Index reflects on-disk reality. Anyone navigating the ADR
  directory by reading `README.md` first sees an accurate map. CLAUDE.md
  now documents the pre-merge check that prevents recurrence (collision
  detection + index-vs-file-heading verification).
- **Negative.** Adds three steps to the contributor workflow when an ADR
  changes. Cost is low (one rebase, one `head -1`, one visual diff) and
  is bounded to PRs that touch ADR files.
- **Neutral.** No code paths change. No tests added. No new tooling. The
  policy is enforced by convention and PR review, not by CI.

## Out of scope

- Code/comment ADR citations across `src/`, `tests/`, the top-level
  `README.md`, and `docs/superpowers/` — already audited clean.
- The `(extended by ADR-0015)` annotation on `docs/adrs/0006-…md` — already
  correct.
- Any automation (CI, pre-commit hook, generator script) to enforce or
  regenerate the index. The pre-merge check is policy-only.
