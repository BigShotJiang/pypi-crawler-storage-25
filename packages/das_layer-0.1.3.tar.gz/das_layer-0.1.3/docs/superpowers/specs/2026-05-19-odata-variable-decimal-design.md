# OData bootstrap: max-precision fallback for variable / unspecified decimals

- **Issue:** [#73](https://github.com/mattiasthalen/das-cli/issues/73)
- **Date:** 2026-05-19
- **Status:** Draft

## Problem

`das contract bootstrap` against an OData source pins every `Edm.Decimal`
property without a fully numeric `(Precision, Scale)` pair to
`decimal(19, 4)`. When the source declares `Scale="Variable"` (or omits
`Precision`/`Scale` entirely) and the real data contains scale > 4, the
subsequent `das ingest` fails terminally inside dlt's normalizer:

```
Rescaling Decimal value would cause data loss.
```

This is correct behavior given ADR-0012 (`schema_contract.data_type: freeze`).
The bug is that the contract was authored with a scale the source did
not promise.

Concrete reproducer in #73 (Adventure Works @ GrapeCity,
`sales_order_details.LineTotal`): computed column with `Scale="Variable"`,
observed scale 6 in the data, currently bootstrapped to `decimal(19, 4)`.

## Goals

- When OData `$metadata` declares an `Edm.Decimal` property with a fully
  numeric `(Precision, Scale)` pair, keep the current behavior:
  `physicalType: decimal({Precision},{Scale})`.
- When OData `$metadata` declares an `Edm.Decimal` property with
  `Scale="Variable"`, missing `Precision`, missing `Scale`, or any
  non-integer value for either attribute, emit a generous fixed maximum
  that is safe across every destination das supports today.
- The chosen maximum is recorded in an ADR so future readers know why
  the constant is what it is.

## Non-goals

- Fixing the analogous shape in `bootstrap/sql.py` (SQLAlchemy
  reflection that returns `Numeric` without a precision). Different
  surface, different test fixtures, deserves its own issue. Out of scope
  for this spec.
- Making the maximum user-configurable. YAGNI — users can hand-edit the
  emitted contract if they need a different scale, and the case for a
  knob has not been seen in practice.
- Per-destination precision lookup at bootstrap time. Bootstrap emits
  source-side contracts before destination dispatch (ADR-0016), so this
  would be a structural change for no observable benefit.

## Decision

Emit `decimal(38,9)` as the OData bootstrap's fallback when the source
declares `Edm.Decimal` without a usable `(Precision, Scale)` pair.

Why these numbers:

- **Precision 38** — universal upper bound for fixed-precision decimals
  across every destination das supports (Delta, Postgres, SQL Server,
  Iceberg, DuckDB all cap at 38).
- **Scale 9** — matches dlt's own internal default
  (`DEFAULT_NUMERIC_SCALE = 9`), so dlt's normalizer never has to
  rescale a value sourced under this contract. Leaves 29 whole-number
  digits — well above anything plausible in operational source data.

The constant lives at module scope in `bootstrap/odata.py` as
`_MAX_DECIMAL = "decimal(38,9)"` (no whitespace — matches the existing
`f"decimal({P},{S})"` emit format) and is referenced from `_logical_for`.

## Trigger matrix

| Precision attr | Scale attr     | Behavior         |
|----------------|----------------|------------------|
| `"19"`         | `"4"`          | `decimal(19,4)`  |
| `"19"`         | `"0"`          | `decimal(19,0)`  |
| (missing)      | `"4"`          | `decimal(38,9)`  |
| `"19"`         | (missing)      | `decimal(38,9)`  |
| (missing)      | (missing)      | `decimal(38,9)`  |
| `"19"`         | `"Variable"`   | `decimal(38,9)`  |
| `"Variable"`   | `"4"`          | `decimal(38,9)`  |
| any non-int    | any            | `decimal(38,9)`  |
| `"0"`          | any            | `decimal(38,9)`  |
| `"19"`         | `"20"` (s>p)   | `decimal(38,9)`  |

Both attributes must be present AND parse as integers with
`Precision >= 1` and `0 <= Scale <= Precision` (the OData CSDL
constraint) for the source-declared `(P, S)` to be honored; anything
else falls through to `_MAX_DECIMAL`. `Scale="0"` is a real declared
value (integer-valued decimal) and is preserved when paired with a
valid Precision.

## Architecture

The change is localized to one function in one module.

### `_logical_for` in `bootstrap/odata.py`

Replace the `Edm.Decimal` branch:

```python
# before
if edm_type == "Edm.Decimal":
    if precision and scale is not None:
        return ("number", f"decimal({precision},{scale})")
    return ("number", "decimal(19,4)")  # safe default
```

```python
# after — see ADR-0027 for the (38,9) fallback constant.
if edm_type == "Edm.Decimal":
    p = _parse_int(precision)
    s = _parse_int(scale)
    if p is not None and s is not None and p >= 1 and 0 <= s <= p:
        return ("number", f"decimal({p},{s})")
    return ("number", _MAX_DECIMAL)
```

`_parse_int` is a small private helper:

```python
def _parse_int(value: str | None) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except ValueError:
        return None
```

`_MAX_DECIMAL` is a module-level constant just below the existing
`_EDM_TO_LOGICAL` table.

Nothing else in the OData bootstrap, ODCS schema, dlt glue, or pipeline
code needs to change. `schema_factory.py:30`'s `_DECIMAL_RE` already
matches `decimal(38,9)` form; the existing freeze policy applies as-is.

### New ADR-0027

File: `docs/adrs/0027-max-precision-fallback-for-variable-decimals.md`,
plus a matching row in `docs/adrs/README.md`.

The ADR records: the precision/scale choice (38, 9), the reason for each
component, the rejected alternatives (bare `decimal`, per-destination
lookup, propagating `Scale="Variable"` as an ODCS annotation), and notes
that SQL-bootstrap's analogous case is intentionally deferred.

## Testing

All tests use existing fixture patterns
(`tests/fixtures/sample_odata_metadata.xml`,
`tests/fixtures/sample_odata_metadata_irregular.xml`,
`tests/unit/test_bootstrap_odata.py`).

### Existing tests

- `test_decimal_with_precision_scale` continues to assert
  `decimal(19,4)` for the `ListPrice` property (declared
  `Precision="19" Scale="4"`). No change.

### New unit tests

In `tests/unit/test_bootstrap_odata.py`, against a small inline-XML
fixture (or a new tiny file under `tests/fixtures/`) carrying one
entity with several `Edm.Decimal` shapes:

- `test_decimal_scale_variable_falls_back_to_max_precision`
- `test_decimal_missing_precision_falls_back_to_max_precision`
- `test_decimal_missing_scale_falls_back_to_max_precision`
- `test_decimal_both_missing_falls_back_to_max_precision`
- `test_decimal_scale_zero_is_preserved` (regression guard:
  `Scale="0"` must NOT be treated as missing)
- `test_decimal_non_integer_scale_falls_back_to_max_precision`
  (e.g. `Scale="foo"`)

Each new test asserts both `logicalType == "number"` and
`physicalType == "decimal(38,9)"` (or `decimal(38,9)` — the exact
formatting must match the constant's chosen whitespace).

### E2E

`tests/e2e/sources/test_odata_adventureworks.py` already covers the
GrapeCity AW service end-to-end. Once the fix lands, that test
exercises the `sales_order_details` resource that #73 reproduces
against; the load that previously failed in the normalizer should now
succeed with `LineTotal` typed as `decimal(38,9)` and rows persisted
intact.

If that e2e test does not currently cover the failing entity end-to-end,
extending it is in scope: assert that `sales_order_details` lands at
least one row whose `line_total` has scale > 4.

### Manual reproducer from #73

```bash
uv tool install das-layer==<dev> --with 'dlt[az]' --with adlfs --with azure-identity
mkdir aw && cd aw && das init
das source add adventure_works \
  --type odata \
  --url https://demodata.grapecity.com/adventureworks/odata/v1
das contract bootstrap adventure_works
grep -A1 'line_total' das/contracts/adventure_works/sales_order_details.odcs.yaml
# expected: physicalType: decimal(38,9)
das ingest adventure_works
# expected: completes; no NormalizeJobFailed
```

## Consequences

- **Positive.** Issue #73's reported failure is resolved. Future OData
  sources with `Scale="Variable"` columns work out of the box. The
  source of the magic constant is documented in ADR-0027 and pointed to
  from the code.
- **Negative.** Sources that *did* expect the old `decimal(19, 4)`
  fallback (i.e. never declared Precision/Scale, and stored fits-in-19,4
  data) now get `decimal(38,9)`. Stored values are unchanged; the only
  visible difference is the contract YAML. For destinations where
  decimal storage width matters (e.g. Parquet/Delta uses int128 for
  precision > 18), files written under the new contract will use a
  wider physical representation. Acceptable for the safety it buys.
- **Neutral.** SQL bootstrap retains its current `("number", None)`
  behavior for un-precisioned `Numeric` columns. A follow-up issue
  should track aligning it.

## Open questions

None. All scope/value choices were made inline with the user during
brainstorming.
