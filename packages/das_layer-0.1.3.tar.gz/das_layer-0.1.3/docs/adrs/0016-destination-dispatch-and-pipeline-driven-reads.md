# 0016. Destination dispatch and pipeline-driven reads

- **Status:** Accepted
- **Date:** 2026-05-07
- **Deciders:** mattiasthalen

## Context

Until now, P2's load pipeline hard-coded `dlt.destinations.duckdb(...)` and
read latest row hashes via a direct `duckdb.connect(db_path)` call. The
README advertised support for "any dlt destination," but adding even one
more destination required changing both the construction site and the
read path. The change-detection layer was the bigger problem: it imported
DuckDB and ran DuckDB-flavored SQL, so any destination without a literal
DuckDB-file would have needed parallel read code.

We needed a way to add destinations cheaply, starting with DuckLake,
without growing a plugin framework or a parallel abstraction layer
alongside dlt's own.

## Decision

**Decision A: destination dispatch lives in a small private function in
`pipelines/load.py`.** `_build_destination(target: TargetConfig) -> Any`
matches on `target.destination` and constructs the corresponding dlt
destination, forwarding `target.credentials`. Adding a new destination is
one branch in one function plus a `dlt[<extra>]` entry in `pyproject.toml`.

`enable_dataset_name_normalization=False` is unconditional — every
destination das-cli verifies must accept that flag, because it preserves
das-cli's `das__<source>` dataset-prefix convention literally rather
than letting each destination's normalizer rewrite it. The convention
itself is set by `dataset.prefix` in `das.yaml` and is not formally
documented in an ADR; this decision pins the flag, not the prefix.

For DuckLake specifically, the `catalog` field accepts both a SQLAlchemy
URL (`duckdb:///./das.ducklake`, `postgresql://...`, etc.) and a bare
filesystem path. Bare paths are auto-prefixed with `duckdb:///` before
construction — symmetric with the existing duckdb-destination UX where
`database: ./das.duckdb` is accepted as a path. URL form remains
necessary for non-DuckDB catalog backends.

**Decision B: change detection reads through `pipeline.sql_client()`.**
`load_latest_hash` (renamed from `load_latest_hash_from_duckdb`) takes
the running `dlt.Pipeline` and runs the latest-hash query through dlt's
SQL client. das-cli no longer imports `duckdb` for read access; dlt
owns destination-specific connection plumbing. The "table not found"
case is handled by catching `dlt.destinations.exceptions.DatabaseUndefinedRelation`.

## Alternatives considered

- **Hand-rolled DestinationAdapter Protocol with per-destination
  implementations.** Rejected: duplicates dlt's own abstraction. Each
  new destination would have meant two registrations (in das-cli's
  registry and in dlt) for no net gain.
- **Branch by destination name inside `change_detection.py`.** Rejected:
  the branching gets ugly past two destinations and would have to be
  ripped out the first time we added a third.
- **Translate DuckLake credential field names to dlt's spelling.**
  Rejected: keeps das-cli in sync with dlt's evolution; field-name
  passthrough is cheaper than maintaining a translation table. The only
  exception is the bare-path → `duckdb:///` convenience for `catalog`,
  which is symmetric with the duckdb destination's existing path-as-string
  acceptance.

## Consequences

- Adding a new dlt destination is a one-branch change in
  `_build_destination` plus a `dlt[<extra>]` entry. The work to verify it
  is dominated by the e2e tests, not the integration glue.
- das-cli no longer imports `duckdb` for read access. The duckdb
  package is still pulled in transitively via `dlt[duckdb]`, but the
  P2 pipeline does not use it directly.
- Decision B locks in dlt's `pipeline.sql_client()` API as a contract
  surface. A future destination without a usable SQL client could not
  support change detection without per-destination read code, and adding
  one would require revisiting this ADR.
- `change_detection.py` no longer has a destination word in any public
  symbol, which makes adding more destinations a config-only change
  rather than a code-and-config one.
