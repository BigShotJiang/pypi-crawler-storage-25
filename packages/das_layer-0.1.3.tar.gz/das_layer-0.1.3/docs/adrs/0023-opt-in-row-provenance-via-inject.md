# 0023. Opt-in row-level provenance via `das.spec_ref.inject`

- **Status:** Accepted
- **Date:** 2026-05-12
- **Deciders:** mattiasthalen

## Context

File-based sources (ADR-0022) commonly use globbing: `customers_*.csv`
becomes one resource that concatenates twelve monthly files. Sheets
share the same pattern: a glob of workbooks combined by sheet name.

Concatenating loses file-level provenance. Users may want a column
recording which file (or sheet) a row came from — for audit, for
debugging a bad row, or for downstream partitioning. The landing-rules
question is: do we preserve that information, and if so how?

## Decision

Provenance is **opt-in per resource via `das.spec_ref.inject`,**
declared alongside a matching column in the contract's schema.

```yaml
das.spec_ref:
  kind: filesystem
  format: csv
  path: "customers_*.csv"
  inject:
    source_file: basename       # → row["source_file"] = file basename
    source_mtime: mtime         # → row["source_mtime"] = file mtime
```

The reader sets `row[col] = <derived value>` before blobbing. The user
declares `source_file` as a property in the ODCS schema like any other
column; P2 projects it into staging.

Supported source values: `basename`, `fullpath`, `mtime`, and `sheet`
(excel only). The column name is user-chosen.

## Alternatives considered

- **Hive-partition landing by source file**
  (`_extracted_on=.../_source_file=.../...jsonl`). Rejected: a glob
  matching N files creates N landing partitions per run. For
  partitioned exports (12 monthly files) it's mild; for `*.qvd` over
  200 files it's a small-files pathology — Object-storage listing
  latency and downstream Parquet/Delta compaction both suffer.
- **Inject `_source_file` as a sibling key to `_data`** in the row
  blob: `{"_data": row, "_source_file": "..."}`. Rejected because it
  breaks ADR-0003's strict `{"_data": row}` outer shape; would require
  an ADR superseding 0003 for a feature most users will never use.
- **Sidecar manifest per run** listing files+row-counts. Rejected for
  Plan #1's scope — useful for audit but not for per-row queries. May
  layer on top later.
- **No provenance.** Rejected — for combining globs it's a real
  footgun. Users would be on their own to add columns at the source.

## Consequences

- ADR-0003's blob pattern is **reaffirmed**, not superseded. Injected
  values land *inside* the user-declared `_data` dict, alongside the
  user's other columns.
- The contract is the source of truth: if `inject.source_file` is set
  but no `source_file` column exists in the schema, the validator
  rejects (the injected value would be silently dropped at the
  contract-projection boundary in P2).
- Default = no injection. Resources that don't need provenance pay
  nothing — no extra fields, no extra columns, no extra storage.
- The `inject` mechanism extends naturally to excel (`sheet` source)
  and qvd (file metadata) under the same umbrella in later format PRs.
