# 0002. Two-pipeline architecture (extract vs. load)

- **Status:** Accepted
- **Date:** 2026-05-05
- **Deciders:** mattiasthalen

## Context

Source data must reach DuckDB as contract-enforced staging tables. The work breaks naturally into two phases: pulling raw bytes from external systems, and applying a contract while writing to the warehouse.

## Decision

Two distinct pipelines with separate verbs:

- `das extract` (P1) — strict raw landing into `./landing/<source>/<resource>/*.jsonl.gz`. Schema-blind. No type coercion, no flattening, no column inference.
- `das load` (P2) — reads landing files, applies ODCS contracts, writes to DuckDB with `schema_contract: freeze`.
- `das ingest` = extract + load (compose).

## Alternatives considered

- **Single pipeline source → DuckDB.** Couples ingestion timing to contract enforcement. A schema break upstream blocks raw data capture. Replaying becomes expensive.
- **Three-stage (raw → bronze → silver).** Premature for v0.1; adds a stage with no clear consumer.

## Consequences

- Schema discipline lives at exactly one layer (P2), not smeared.
- Landing files are durable replay material — re-running P2 with frozen landing reproduces staging deterministically.
- Two state files per source instead of one (acceptable; dlt handles them).
- Verbs `extract`/`load`/`ingest` map directly to dlt's internal phases and ETL convention.
