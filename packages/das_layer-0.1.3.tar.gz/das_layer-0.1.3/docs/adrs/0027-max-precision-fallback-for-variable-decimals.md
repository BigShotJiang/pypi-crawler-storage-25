# 0027. Max-precision fallback for variable/unspecified OData decimals

- **Status:** Accepted
- **Date:** 2026-05-19
- **Deciders:** mattiasthalen

## Context

OData `$metadata` may declare an `Edm.Decimal` property with
`Scale="Variable"`, omit `Precision`/`Scale` entirely, or provide values
that do not parse as non-negative integers. The Adventure Works demo
service at GrapeCity exemplifies the first case: every Decimal column
in its `$metadata` carries `Scale="Variable"` with no `Precision`
attribute.

Prior to this decision the OData bootstrap (`src/das_cli/bootstrap/odata.py`)
pinned all such properties to `decimal(19,4)`. Most Adventure Works
decimals do fit (19, 4), but `sales_order_details.LineTotal` is a
computed column whose data exhibits scale up to 6. The contract that
bootstrap authored therefore contradicted the source data, and
ADR-0012's `schema_contract.data_type: freeze` correctly refused to
silently rescale — surfacing the contradiction as a terminal
`NormalizeJobFailed` ("Rescaling Decimal value would cause data loss")
during `das ingest`. See issue #73 for the full reproducer.

The right behavior when the source declines to promise a scale is to
emit a contract that is generous enough to hold any value the source
might subsequently produce. Storing the source's "Variable" as an
opaque annotation in the contract — and resolving precision at load
time — is also possible but couples destinations to OData metadata and
breaks ADR-0012's freeze-time guarantee.

## Decision

When `_logical_for` in `bootstrap/odata.py` cannot resolve a fully
numeric `(Precision, Scale)` pair satisfying the OData CSDL constraint
(`Precision >= 1` and `0 <= Scale <= Precision`), emit
`physicalType: decimal(38,9)` for that `Edm.Decimal` property. The
fallback is exposed as a module-level constant `_MAX_DECIMAL` for
visibility and so a future ADR can revise it cleanly.

The chosen values:

- **Precision 38** is the universal upper bound for fixed-precision
  decimals across every destination das supports today (Delta, Postgres,
  SQL Server, Iceberg, DuckDB all cap at 38).
- **Scale 9** matches dlt's own internal default
  (`DEFAULT_NUMERIC_SCALE = 9`). Aligning eliminates a class of
  normalizer-level rescale paths and leaves 29 whole-number digits —
  well beyond anything plausible in operational data.

The fallback fires for: `Scale="Variable"`, `Precision="Variable"`,
missing `Precision`, missing `Scale`, non-integer values, negative
values, `Precision="0"`, and `Scale > Precision`. When both attributes
parse as integers satisfying the constraint, the source-declared pair
is honored — including `Scale="0"`.

## Alternatives considered

- **Emit bare `decimal` (no precision/scale)** and let the destination
  pick. Requires a parallel change in `dlt_glue/schema_factory.py`'s
  `_DECIMAL_RE` and contradicts ADR-0012's freeze-time stance — a
  contract whose shape varies depending on whether the source declared
  scale is harder for diff (`das contract diff`) and freeze policy to
  reason about.
- **Look up the destination's decimal cap at bootstrap time.**
  Bootstrap emits source-side contracts before destination dispatch
  (ADR-0016). Restructuring for no observable benefit (every
  destination das supports caps at 38).
- **Propagate `Scale="Variable"` as an ODCS `customProperties`
  annotation** and translate at load time. More accurate but defers the
  contradiction-detection that ADR-0012 is built to enforce; freeze
  loses its meaning.
- **Mirror the fix in `bootstrap/sql.py`** for its analogous
  `Numeric` without precision case. Different surface, different test
  fixtures, deserves its own issue and its own decision; deliberately
  deferred. The SQL bootstrap continues to return `("number", None)` in
  that branch, which falls back to dlt's `double` — lossy but
  non-crashing.

## Consequences

- **Positive:** Issue #73 is resolved. Future OData sources with
  `Scale="Variable"` columns work out of the box. The (38, 9) choice is
  documented and centralized in `_MAX_DECIMAL`, not scattered as a
  magic literal.
- **Negative:** Pre-existing sources that relied on the old
  `decimal(19,4)` fallback (i.e. never declared `(Precision, Scale)`,
  and their stored values fit `(19, 4)`) now get `decimal(38,9)`. Stored
  values are unchanged; only the contract YAML shifts. On destinations
  where decimal storage width is precision-tiered (Parquet/Delta uses
  int128 for precision > 18), files written under the new contract use
  a wider physical representation. Acceptable for the safety it buys.
- **Neutral:** The SQL bootstrap's analogous `Numeric`-without-precision
  case is unchanged. A follow-up issue should track aligning it.
