# 0018. SQL source via SQLAlchemy reflection

- **Status:** Accepted
- **Date:** 2026-05-08
- **Deciders:** mattiasthalen

## Context

das-cli's v0.1 design listed `type: sql` as a placeholder — `dlt.sources.
sql_database` driven by `_source.yml` connection — but nothing was
implemented. `models/source_yml.py` accepted `sql` as a literal source
type; `dlt_glue/source_factory.py` raised `UnknownSourceTypeError` for
it. Issues #31 (Oracle) and #32 (SQL Server) ask to verify a SQL source.
Verifying each independently would have meant two near-duplicate ADRs,
two source-factory builders, and two seed-data fixtures for the same
plumbing. dlt's `sql_database` source is driver-agnostic on the read
side via SQLAlchemy, so adding both at once is strictly cheaper.

## Decision

**Decision A: source dispatch lives as a small `_build_sql_resources`
branch in `dlt_glue/source_factory.py`,** alongside the existing HTTP
branch. No registry, no plugin layer — same dispatch shape ADR-0016
chose for destinations. Adding a future SQL dialect to the verified
matrix is a driver-extra change in `pyproject.toml` plus an e2e test;
no new code path.

**Decision B: bootstrap reflects schemas via SQLAlchemy
`MetaData.reflect`.** das-cli does not own per-dialect catalog SQL.
Type mapping covers SQLAlchemy generic types only; dialect-specific
types fall back to `logicalType: string` with a `bootstrap`-time
warning. SQLAlchemy already dispatches the right catalog query per
dialect (`information_schema.columns` for Postgres / MySQL / MSSQL,
`ALL_TAB_COLUMNS` + `ALL_CONSTRAINTS` for Oracle, `sqlite_master` for
SQLite); reimplementing that would duplicate work for no offsetting
benefit.

**Decision C: SQL connection URL lives in `_source.yml.endpoint`,**
templated with Jinja `env_var(...)` for credentials. Symmetric with
ADR-0016's URL-passthrough convention for DuckLake's `catalog`. The
`auth` block is no-op for SQL sources — the URL holds the credentials.
`das source add --type sql` rejects URLs that contain userinfo and
auto-templates `{{ env_var('PREFIX__USERNAME') }}` and
`{{ env_var('PREFIX__PASSWORD') }}` into the URL written to disk,
generating a basic-auth-shaped `.env` block alongside.

**Decision D: SQL Server uses `mssql+pyodbc` + Microsoft ODBC Driver 18.**
Long-standing primary path pre-mssql-python; full Azure / Entra ID
support; dlt's MSSQL examples reference it. CI's e2e job installs
`msodbcsql18` and `unixodbc-dev` via apt; local devs running e2e
need the same.

## Alternatives considered

- **Registry-style source dispatch** (a `SOURCE_BUILDERS: dict[str,
  Builder]`). Rejected for the same reason ADR-0016 rejected it for
  destinations: duplicates dlt's own abstraction; each new source
  would be two registrations for no gain.
- **Per-dialect catalog SQL we own** (`information_schema.columns`,
  `ALL_TAB_COLUMNS`, etc.). Rejected: reimplements SQLAlchemy
  reflection. SQLAlchemy is already a runtime dependency via
  `dlt[sql_database]`.
- **`das.query` custom-query resources** (compute one resource from
  an arbitrary SELECT). Deferred. One-resource-per-table covers the
  verification surface; a v2 follow-up can layer queries on top.
- **`pymssql` for MSSQL.** Considered: SQLAlchemy 2.x supports it,
  CI footprint is slimmer (no system deps). Rejected because Microsoft
  does not recommend it, Azure SQL is painful (default wheels lack SSL
  bindings), and maintenance is sparse.
- **`mssql-python` (Microsoft's new in-house GA driver).** Considered:
  faster than pyodbc per Microsoft's benchmarks. Rejected because no
  SQLAlchemy dialect ships for it as of this writing, so it cannot
  plug into `dlt.sources.sql_database` without an upstream contribution.
  Out of scope; revisit when a dialect ships.
- **Discrete connection flags** (`--driver`, `--host`, `--port`,
  `--service`, `--username`). Rejected: reimplements SQLAlchemy's URL
  builder; per-dialect quirks (Oracle TNS, MSSQL ODBC `driver=` query
  param) make a unified flag set ugly.

## Consequences

- das-cli now imports SQLAlchemy and the `dlt[sql_database]` extra at
  runtime. Per-source driver wheels (`oracledb`, `pyodbc`) are the
  user's responsibility — pyproject lists them only in the dev group
  for tests; the README quickstart documents the install.
- `_build_sql_resources` is the second branch in
  `build_extract_resources`; the function is no longer
  HTTP-or-die. Adding e.g. Postgres-as-source is a driver-wheel and
  e2e-test change.
- Locks in SQLAlchemy reflection as a contract surface. A dialect
  without reflection support could not be bootstrapped without
  per-dialect catalog SQL, which would require revisiting this ADR.
- The `auth` block carries no SQL credentials — credentials live in the
  URL. This breaks symmetry with HTTP auth blocks but fits the
  passthrough-to-dlt philosophy ADR-0016 established for destinations.
- E2E coverage requires Docker + driver wheels (`oracledb`, `pyodbc` +
  ODBC Driver 18). The default `pytest` invocation (without `-m e2e`)
  does not need any of that.
- `decimal(p,s)` columns round-trip losslessly through P1 → landing → P2.
  Drivers (`oracledb`, `pyodbc`, etc.) return `decimal.Decimal`; dlt's JSON
  encoder writes it as a quoted string in landing JSONL; P2's projection
  (`pipelines/load.py::_project_record`) parses the string back into
  `Decimal` for columns whose contract declares `logicalType: number` with
  `physicalType: decimal(p,s)`. The cost is one parse per decimal cell at
  P2 ingest, paid in exchange for no precision loss. The contract surface
  for the round-trip lives in `dlt_glue/schema_factory.py`
  (`coerce_decimal`, `is_decimal_column`).
