# 0020. Azure landing and Delta destination via fsspec + typed dlt credentials

- **Status:** Superseded by ADR-0021
- **Date:** 2026-05-12
- **Deciders:** mattiasthalen

## Context

ADR-0017 added Delta as the third verified destination but punted on
cloud-backed Delta: "Cloud-backed Delta (S3/GCS/Azure) is out of scope."
At the time, dlt issue [#2055][i2055] documented that the
`DefaultAzureCredential` / `AzureCliCredential` path failed when used with
`table_format="delta"` on the filesystem destination, because dlt's
bridge into `object_store`'s `storage_options` passed a `bool` where the
Rust side expected a `String`. Explicit service-principal credentials
worked; the default-chain path did not. That bug was closed as completed
on 2025-01-29.

ADR-0013's landing convention was likewise verified only for local paths.
`extract.py:reset_extract_state` raises `NotImplementedError` for
`az://` URLs, and the landing readers in both `extract.py` and
`load.py` use `pathlib` + `gzip.open` / builtin `open` — local-FS only.

dlt 1.26.0 (das-cli's pinned version) includes the issue #2055 fix —
`AzureCredentialsBase.to_object_store_rs_credentials()` resolves the
default credential chain to a bearer token and passes
`azure_storage_token` as a string. The combination
`filesystem + table_format="delta" + Azure` now works for both the
service-principal and default-credential paths, which makes a verified
Azure slice tractable.

ADLS Gen2 and OneLake (Fabric) speak the same Azure Blob File System
(ABFS) protocol and accept the same `AZURE_*` credentials. das-cli
treats both as opaque ABFS URLs and does not branch on them.

[i2055]: https://github.com/dlt-hub/dlt/issues/2055

## Decision

**Decision A: das-cli accepts `az://`, `abfs://`, `abfss://` URLs for
both `landing.bucket_url` and the Delta target's
`target.credentials.bucket_url`.** OneLake is a URL convention on
`abfss://`, not a separate scheme. das-cli does not branch on
`onelake.dfs.fabric.microsoft.com` vs `<account>.dfs.core.windows.net` —
both flow through dlt and adlfs as opaque ABFS URLs. For OneLake, the
GUID URL form (`abfss://<workspace_guid>@onelake.dfs.fabric.microsoft.com/<item_guid>/…`)
is recommended; the name form (`…/<item>.lakehouse/…`) is per Microsoft
Learn but the dlt docs hard-recommend GUIDs and the name form is not
verified.

**Decision B: two explicit `auth` modes — `service_principal` and
`default`.** A new discriminated `AzureCredentials` Pydantic model lives
in `models/das_yaml.py` and parses the `credentials` dict when the
corresponding `bucket_url` is Azure:

```yaml
credentials:
  auth: service_principal
  tenant_id: "{{ env_var('AZURE_TENANT_ID') }}"
  client_id: "{{ env_var('AZURE_CLIENT_ID') }}"
  client_secret: "{{ env_var('AZURE_CLIENT_SECRET') }}"
```

```yaml
credentials:
  auth: default
```

`default` invokes dlt's `AzureCredentials` (which wraps
`DefaultAzureCredential`), chaining env-var SP → managed identity → az
CLI → developer Azure tools. A separate `cli` mode would just be a slower
alias for the same code path; managed identity is one link in the same
chain. Both are reachable through `auth: default` on the appropriate
host.

Per ADR-0007, secrets only come in via `{{ env_var(...) }}`. Standard
Azure SDK env-var names (`AZURE_TENANT_ID`, `AZURE_CLIENT_ID`,
`AZURE_CLIENT_SECRET`, `AZURE_STORAGE_ACCOUNT_NAME`) are used throughout
the docs because they are the names both Python `azure-identity` and
Rust `object_store` read — one `.env` works for both sides.

**Decision C: landing reads go through fsspec.** A new helper
`dlt_glue/landing_fs.py` returns a `(fsspec.AbstractFileSystem,
root_path)` pair for any `landing.bucket_url`. `LocalFileSystem` for
bare paths and `file://`; `AzureBlobFileSystem` (adlfs) for `az://` /
`abfs://` / `abfss://`. `_iter_landing`, `count_landing_rows`, and the
state-reset path in `reset_extract_state` all flow through this helper.
This is the first time landing reads stop using `pathlib`; the contract
surface generalises to any fsspec-supported scheme, but only `file://`
and Azure are verified.

**Decision D: das-cli does not own `storage_options` plumbing, but does
set `azure_storage_account_name` on the typed credentials object.** dlt's
typed Azure credentials (`AzureServicePrincipalCredentialsWithoutDefaults`
and `AzureCredentials`) produce the right `object_store` storage_options
for the Rust deltalake writer automatically — including the
`azure_storage_token` resolution from `DefaultAzureCredential` that fixed
issue #2055. das-cli builds the credentials object from das-cli's
`AzureCredentials` model and passes it as `credentials=` to
`dlt.destinations.filesystem(...)`. The per-resource `table_format="delta"`
plumbing from ADR-0017 is unchanged.

One sharp edge: dlt's `FilesystemDestinationClientConfiguration` requires
`azure_storage_account_name` on the credentials object. A `None` value
triggers full re-resolution of every credentials field via dlt's
`DESTINATION__FILESYSTEM__CREDENTIALS__*` env-var naming convention —
not what we want, since we already populated the SP fields explicitly.
das-cli therefore derives `azure_storage_account_name` from the URL host
(`onelake` for OneLake, `<account>` for ADLS Gen2 generic) and sets it
on the credentials object. The function `build_dlt_azure_credentials`
takes `bucket_url` as a required kwarg for exactly this reason.

## Alternatives considered

- **Add a discrete `cli` auth mode for `az login`.** Rejected — it's one
  link in the `DefaultAzureCredential` chain, exposed via `auth: default`.
  Two modes that resolve to the same code path is configuration sprawl
  with no behavior gain.
- **Add `managed_identity` as a distinct mode.** Rejected for the same
  reason — `DefaultAzureCredential` already picks up the IMDS endpoint
  on Azure VMs / AKS / Functions.
- **Manage `storage_options` in das-cli, merge with dlt's.** Rejected —
  duplicates the work dlt already does in
  `to_object_store_rs_credentials()` and locks das-cli to dlt's internal
  shape. The risk of dlt's auto-merge missing an edge case is real but
  is dlt's problem to fix, not das-cli's to work around upstream.
- **Use the dlt `fabric` destination
  ([dlt PR #3535](https://github.com/dlt-hub/dlt/pull/3535))**.
  Rejected — that destination targets Fabric **Warehouse** (a T-SQL
  endpoint, COPY INTO loader), which is a different surface from
  OneLake-as-files + Delta. Worth revisiting when das-cli wants to add
  a managed-warehouse destination row alongside DuckLake.
- **Add `s3://` and `gs://` in the same pass.** Rejected — different
  credential shapes, different `object_store` quirks (and the dlt
  GCS fix from #1965 happened before #2055; the Azure fix is the
  load-bearing one for ADR-0017's supersedure). S3/GCS can land on
  their own verified slices later.

## Consequences

- A new `AzureCredentials` Pydantic model lives in `models/das_yaml.py`.
  It is opt-in: only parsed when the relevant `bucket_url` is Azure.
  Existing local-path workspaces are unaffected.
- A new contract surface: das-cli relies on dlt's
  `to_object_store_rs_credentials()` to produce the right Azure
  storage_options for the Rust deltalake writer. A future dlt release
  that changes the merge semantics or the `azure_storage_token` field
  name would break das-cli; this is a stable-API-shaped surface and is
  documented here so future maintainers know where to look.
- The `delta` destination accepts Azure URLs but offers no extra
  configurability beyond `bucket_url` + `credentials`. Compaction,
  retention, and vacuum remain out of scope.
- AWS S3 and GCS are *not* verified by this ADR. The fsspec helper and
  the dispatch glue would *probably* work for both, but neither has a
  doctor check, a credentials model, or an e2e edge. Treat as
  unverified.
- `doctor` performs config-typo hygiene only for Azure. No live token
  fetch, no network call. A user with a misconfigured SP will not hear
  about it until `das ingest` actually fails — same shape as the
  existing doctor checks for other destinations.
- Cross-pipeline reads on Azure-backed Delta carry the same constraint
  as local Delta (ADR-0017 Decision C): readers must share the
  writer's `pipeline_name` / `pipelines_dir` because dlt's filesystem
  `sql_client()` discovers tables from pipeline state, not filesystem
  metadata. This is a property of the dispatch layer, not of Azure.
- ADR-0017's "Cloud-backed Delta is out of scope" consequence is
  partially superseded by this ADR for the Azure case. S3 and GCS stay
  out of scope under ADR-0017.
- **OneLake from outside Fabric runtime: write paths work, read-back via
  DuckDB-Delta extension does not.** Through a combination of three
  workarounds, das-cli writes correctly to OneLake from any environment:
  (a) rewrite `*.dfs.fabric.microsoft.com` → `*.blob.fabric.microsoft.com`
  for adlfs's `account_host` (adlfs uses the Blob API for list ops; the
  DFS endpoint rejects them — [fsspec/adlfs#486][adlfs486]); (b) supply
  an Azure SDK credential *object* (not a SAS string) via dlt's `kwargs=`
  passthrough to `dlt.destinations.filesystem(...)`, because adlfs's
  `sas_token` field is strictly a URL query-string SAS and a JWT bearer
  doesn't fit; (c) pass `use_fabric_endpoint: "true"` + a separately-acquired
  bearer token via `deltalake_storage_options` so the Rust deltalake
  writer hits the correct endpoint.

  Verified end-to-end on OneLake from outside Fabric: extract → JSONL
  into `/Files/`, load → Delta into `/Tables/`. The remaining gap is the
  **read-back** path: `pipeline.sql_client()` opens an in-memory DuckDB
  with the Delta extension and issues `delta_scan(...)` directly against
  OneLake. DuckDB's Azure auth is a separate credential surface from
  both adlfs and `object_store` — it requires either a `CREATE SECRET ... TYPE AZURE`
  statement or environment variables under DuckDB's naming convention.
  das-cli does not wire either today, so `pipeline.sql_client()` against
  OneLake-backed Delta fails with `401 Unauthorized` from DuckDB's
  underlying HTTP fetch. This affects: the e2e read-back assertions, and
  `change_detection.load_latest_hash` on second-cycle loads (first load
  works because the prior-state read short-circuits via
  `DatabaseUndefinedRelation`). Tracked as a follow-up.

  Standard ADLS Gen2 endpoints (`<account>.dfs.core.windows.net`) take
  the simpler typed-credentials path and are unaffected.

  [adlfs486]: https://github.com/fsspec/adlfs/issues/486
