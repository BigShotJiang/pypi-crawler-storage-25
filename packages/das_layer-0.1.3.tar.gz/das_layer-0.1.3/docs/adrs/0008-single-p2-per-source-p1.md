# 0008. One P2 pipeline; one P1 pipeline per source

- **Status:** Accepted
- **Date:** 2026-05-05
- **Deciders:** mattiasthalen

## Context

dlt manages state per pipeline. Topology choice affects state isolation, parallelism, and load atomicity.

## Decision

- **P1**: one dlt pipeline per source (`das_extract__<source>`). Each has its own auth, endpoint, and incremental cursor state — these must be isolated.
- **P2**: one dlt pipeline total (`das_load`). It reads landing files (local or cloud) and writes to one DuckDB. No source-level state to isolate.

`das load <source>` runs the single P2 pipeline filtered to that source's resources via dlt's resource selection.

## Alternatives considered

- **One P2 per source.** Multiplies state files; complicates "load everything" semantics.
- **One P1 total.** Conflates per-source cursors and auth; bad isolation.
- **One pipeline total (P1+P2 fused).** Couples extraction failure to load failure; replays expensive.

## Consequences

- Single P2 state file. One `_dlt_load_id` sequence at load time — easier to query "what was loaded together".
- `das load` (no arg) runs every source's resources in one pipeline pass.
- dlt does not roll back already-loaded resources within a pipeline run; exit 5 is set on any failure but successes persist. Documented as best-effort across resources.
- Per-source P1 pipelines parallelize freely (deferred to v0.2).
