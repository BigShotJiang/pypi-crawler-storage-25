# 0010. CLI tests live in the CLI repo; user workspaces get only `das doctor`/`das validate` wrappers

- **Status:** Accepted
- **Date:** 2026-05-05
- **Deciders:** mattiasthalen

## Context

Where do tests for das-cli live, and what do user workspaces include?

## Decision

- **CLI repo (`das-cli/tests/`)** holds the full test suite: unit, integration (mocked HTTP + real DuckDB in tmp), e2e (real public APIs, opt-in).
- **User workspace** scaffolded by `das init` includes only `tests/test_workspace.py` — a thin pytest wrapper around `das doctor` and `das validate`. Users add their own tests on top.

## Alternatives considered

- **Heavy test scaffolding in user workspaces (unit/integration/e2e dirs).** Confuses concerns; users shouldn't test CLI internals from their workspace.
- **No tests at all in user workspace.** Loses the "drift fails CI" property.

## Consequences

- CLI repo tests focus on CLI behavior; no user-data dependencies.
- User workspaces stay focused on contracts; their CI catches connectivity/auth/contract issues via `das doctor` and `das validate`.
- e2e tests in CLI repo gated by `-m e2e`, run on `main` branch only.
