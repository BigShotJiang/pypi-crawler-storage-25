# Architecture Decision Records

This directory contains MADR-format ADRs documenting architectural choices for
das-cli. See `../../CLAUDE.md` for lifecycle policy and authoring guidance.

## Index

| # | Title | Status |
|---|---|---|
| 0001 | Use Python (not Go) for the CLI | Accepted |
| 0002 | Two-pipeline architecture (extract vs. load) | Accepted |
| 0003 | P1 uses dlt's pipeline with `_data: json` blob pattern | Accepted |
| 0004 | Append + row-hash change detection over SCD2 merge | Accepted |
| 0005 | ODCS v3 for resource contracts; custom `_source.yml` for connection | Accepted |
| 0006 | Bootstrap mix: custom OData parser, direct OpenAPI walker | Accepted |
| 0007 | Secrets via Jinja `env_var(...)` only — no `.dlt/secrets.toml` | Accepted |
| 0008 | One P2 pipeline; one P1 pipeline per source | Accepted |
| 0009 | dlt config flows via Python objects, not `.dlt/config.toml` | Accepted |
| 0010 | CLI tests live in the CLI repo; user workspaces get only `das doctor`/`das validate` wrappers | Accepted |
| 0011 | `das.*` namespace for ODCS `customProperties` | Accepted |
| 0012 | Schema enforcement via `data_type: freeze` plus contract projection | Accepted |
| 0013 | Load-date semantics: hive partition + derived staging columns | Accepted |
| 0014 | Per-resource `das.endpoint` for HTTP source resolution | Accepted |
| 0015 | Extend OpenAPI bootstrap to walk `paths` | Accepted |
| 0016 | Destination dispatch and pipeline-driven reads | Accepted |
| 0017 | Delta destination via filesystem alias | Accepted |
| 0018 | SQL source via SQLAlchemy reflection | Accepted |
| 0019 | `--full` semantics: split between extract and load | Accepted |
| 0020 | Azure landing and Delta destination via fsspec + typed dlt credentials | Superseded by ADR-0021 |
| 0021 | OneLake DuckDB read-back via PROVIDER ACCESS_TOKEN secret | Accepted |
| 0022 | File-based sources via a single `type: filesystem` umbrella | Accepted |
| 0023 | Opt-in row-level provenance via `das.spec_ref.inject` | Accepted |
| 0024 | OData EntitySet name persisted on `das.spec_ref` | Accepted (extended by ADR-0025) |
| 0025 | OData bootstrap driven by `<EntityContainer><EntitySet>` | Accepted |
| 0026 | Tag-based releases via hatch-vcs and PyPI OIDC trusted publishing | Accepted |
| 0027 | Max-precision fallback for variable/unspecified OData decimals | Accepted |
