# 0004. Append + row-hash change detection over SCD2 merge

- **Status:** Accepted
- **Date:** 2026-05-05
- **Deciders:** mattiasthalen

## Context

P2 must produce historized tables from P1 data. Many sources return full snapshots, so naive append duplicates rows across runs. We need a change-detection mechanism that handles A→B→A transitions correctly and works on every dlt destination — including append-only ones (delta, iceberg, parquet/S3).

## Decision

`write_disposition: append` with row-hash-based change detection:

- For each row, compute `_row_hash = md5(canonical_json(_data minus das.hash_exclude))`.
- Before append, query latest hash per primary key from the destination (`QUALIFY ROW_NUMBER() OVER (PARTITION BY pk ORDER BY _dlt_load_id DESC) = 1`).
- Append only if `_row_hash` differs from the latest seen hash for that PK.
- Insert-only at the destination. All transitions (including A→B→A) preserved.

## Alternatives considered

- **dlt's `merge` strategy with `scd2`.** Closes old rows with UPDATE; expensive on append-only destinations. Pushes SCD logic into DAS where the model-driven blog says it belongs in DAB.
- **Hash as PK with `UNIQUE` constraint.** Suppresses round-trips (A→B→A becomes A→B because the second A's hash already exists somewhere).
- **Pure append, no change detection.** Snapshot-only sources duplicate every row each run.

## Consequences

- Works on every dlt destination.
- Storage scales with distinct row versions, not snapshot count.
- Per-PK latest-hash cache loaded into memory at load start; sized by distinct PK count, not row count.
- A `_row_hash` column added to every staging table.
- DAB layer can compute SCD2 / current views from this base table without DAS pre-computing them.
- Tombstone detection (rows that disappeared from a snapshot) deferred to v0.2.
