# 0017. Delta destination via filesystem alias

- **Status:** Accepted (cloud-Delta consequence superseded for Azure by ADR-0020)
- **Date:** 2026-05-08
- **Deciders:** mattiasthalen

## Context

ADR-0016 set up destination dispatch in `_build_destination` and pipeline-driven
reads through `pipeline.sql_client()`. DuckLake was the first non-DuckDB
destination verified under that pattern. Delta is the next.

In dlt 1.x, Delta is not its own destination — it is a `table_format` on
`dlt.destinations.filesystem(...)`. Naming it `filesystem` in `das.yaml` would
be honest about dlt's structure but blur what is verified: Parquet-on-filesystem
is not in scope here. Naming it `delta` keeps the verified contract narrow.

The change-detection read path adds a new contract surface. dlt's filesystem
`sql_client()` is a DuckDB-backed in-memory client that reads Delta tables via
`delta_scan`. This is structurally different from DuckDB and DuckLake's native
SQL clients — ADR-0016's "any destination with sql_client" claim extends to it,
but this ADR records the fact explicitly.

## Decision

**Decision A: das-cli's `target.destination: delta` is an alias for
`dlt.destinations.filesystem(bucket_url=..., enable_dataset_name_normalization=False)`,
combined with a per-resource `table_format="delta"` set inside
`_build_load_resource`.** The alias is owned by `_build_destination`; users
do not see "filesystem" in `das.yaml` for this verified slice. `bucket_url`
is forwarded verbatim — no auto-prefix, since a bare path is a valid
filesystem path. Default `bucket_url` is `./das_delta` when omitted,
mirroring the duckdb destination's `./das.duckdb` default.

**Decision B: Table format is set per-resource via a new optional
`table_format` kwarg on `_build_load_resource`, plumbed from
`cfg.target.destination` in `run_load`.** dlt 1.26 does not expose a
`default_table_format` kwarg on the filesystem destination factory — the
kwarg is silently dropped. Per-resource is the only mechanism dlt provides.
The coupling introduced into `_build_load_resource` is a single string
kwarg with a `None` default; the function still doesn't know about
destinations specifically — it forwards a string into `@dlt.resource(...)`.

**Decision C: change detection continues to read through `pipeline.sql_client()`.**
For the filesystem destination this is a DuckDB-backed in-memory SQL client that
reads Delta tables via `delta_scan`. This extends ADR-0016's contract surface
to filesystem-style sql_clients — the implementation is verified to satisfy the
same `DatabaseUndefinedRelation` exception contract for the missing-table path.

Unlike DuckLake (where the catalog is the source of truth for table discovery),
dlt's filesystem `sql_client()` discovers tables from the **pipeline's stored
schema state**, not from filesystem metadata. Change detection works because it
reads from the writer's own pipeline. Cross-pipeline reads (e.g., test helpers
querying a writer's output) must share the writer's `pipeline_name` and
`pipelines_dir` — a different pipeline pointed at the same `bucket_url` sees no
tables.

## Alternatives considered

- **`destination: filesystem` + `table_format: delta`.** Rejected: exposes a
  knob whose Parquet branch is unverified; the user-facing name should reflect
  what das-cli has actually tested.
- **Destination-level `default_table_format` via dlt's filesystem factory.**
  Preferred design; rejected because dlt 1.26's filesystem factory does not
  accept that kwarg (silently dropped). Forced the per-resource approach in
  Decision B.
- **Adding both `delta` and `filesystem` as separate dispatch branches.**
  Rejected: premature. Verify Parquet-on-filesystem when there is a use case;
  give it its own dispatch branch and matrix row at that point.

## Consequences

- Adding Delta is one branch in `_build_destination` plus one optional kwarg
  on `_build_load_resource` plus a `dlt[deltalake]` extra in `pyproject.toml`.
  Small surface area.
- dlt's filesystem `sql_client()` is now a contract surface alongside ADR-0016's
  general claim. A future filesystem-based destination with a different
  SQL-client path (e.g., a DataFusion-backed Delta reader) would need to satisfy
  the same exception contract or revisit this ADR.
- The `delta` alias locks users out of Parquet-on-filesystem under that name.
  That is intentional — the alias names what is verified.
- Cloud-backed Delta (S3/GCS/Azure) is out of scope. `bucket_url` accepts
  cloud URLs in dlt's filesystem destination, but das-cli has not verified
  authentication, retry, or eventual-consistency behavior in those modes.
- `_build_load_resource` now takes a `table_format` kwarg. It is destination-
  agnostic in name and behavior — it forwards a string into `@dlt.resource(...)`
  without branching on destination. Future destinations that need a table
  format set the kwarg the same way.
