# 0025. OData bootstrap driven by `<EntityContainer><EntitySet>`

- **Status:** Accepted
- **Date:** 2026-05-13
- **Deciders:** mattiasthalen

## Context

ADR-0024 added `das.spec_ref.entity_set` and a fallback pluralization
heuristic so `synthesize_odata_endpoint()` can produce correct URL paths
for irregular OData plurals. It did not change *which* EntityTypes get a
contract: `bootstrap_odata_contracts()` continued to walk every
`<EntityType>` in `$metadata`.

EDM separates two concerns. `<EntityType>` declares a type — its keys,
properties, and navigation links. `<EntityContainer><EntitySet>` declares
the queryable *resources* the service exposes; the set name is the URL
segment served at runtime. Services routinely declare EntityTypes that
are not exposed as EntitySets — link targets reached only through
`NavigationProperty` / `Collection(...)`, or join shapes the service
hides. Treating every EntityType as queryable over-produces contracts
that 404 at extract time.

Evidence from the public AdventureWorks demo feed: `$metadata` declares
59 EntitySets; the bootstrap emitted 66 contracts. The 7 extras —
`country_region_currencies`, `person_credit_cards`, `passwords`,
`product_model_product_description_cultures`,
`sales_order_header_sales_reasons`, `product_product_photos`,
`special_offer_products` — are not in `<EntityContainer>` and 404 when
queried.

## Decision

`bootstrap_odata_contracts()` iterates `<EntityContainer><EntitySet>`
declarations and looks up the backing `<EntityType>` element for schema.
One contract per `<EntitySet>`. EntityTypes referenced only via
`NavigationProperty` / `Collection(...)` are dropped. A container with
zero `<EntitySet>` children emits zero contracts — an empty container is
the service declaring "nothing queryable," not a trigger to fall back to
the EntityType walk.

When `<EntityContainer>` is absent (rare; OData v1/v2 or stripped
metadata), preserve the legacy per-EntityType walk. The container-less
case has no authoritative source of "what is queryable", so the
heuristic fallback in `synthesize_odata_endpoint()` (ADR-0024) does its
documented job.

Bootstrap-time contract `resource_name` derivation (`pluralize(type_name)`,
which snake-cases internally) is unchanged. `das.spec_ref.entity_set`
semantics (ADR-0024) are unchanged. The URL-path heuristic fallback in
`synthesize_odata_endpoint()` — `pluralize_preserving_case(spec_ref.type)`
— is now reached only by container-less metadata or pre-ADR-0024
contracts, which is exactly the purpose ADR-0024 documented for it.

## Alternatives considered

- **Hard-fail on container-less metadata.** Stricter, but breaks an
  extant code path with no compensating benefit. Overproduction only
  matters when types-without-sets exist, which container-less metadata
  cannot express.
- **Live-probe each EntitySet during bootstrap.** Catches the
  declared-but-still-404 case (e.g., `BusinessEntities` on the
  AdventureWorks demo), but adds an HTTP call per resource and slows
  bootstrap from seconds to minutes. Worth a future `--probe` flag;
  out of scope here.
- **Leave bootstrap as-is and ship `das contract prune` to drop dead
  contracts after the first failed ingest.** Shifts work to the user
  and ignores the authority-of-truth question.

## Consequences

- **Positive:** Bootstrap output aligns with what the server actually
  serves. A fresh `das contract bootstrap <source>` against any
  OData service with a well-formed `<EntityContainer>` will not emit
  contracts that 404 by default.
- **Negative:** Pre-existing on-disk contracts for EntityTypes the new
  bootstrap no longer produces (e.g., `passwords.odcs.yaml` on
  AdventureWorks) are not removed by re-bootstrapping. `--force`
  overwrites contracts that the new bootstrap still produces; it has no
  deletion path. Stale files linger on disk until the user deletes them
  manually (or a future `das contract prune` command removes them).
  Without cleanup, the stale contracts continue to 404 at extract time.
- **Neutral:** Container-less metadata follows the same legacy path as
  before. Existing diff and bootstrap tests over container-less
  fixtures continue to pass unchanged.
