# 0019. `--full` semantics: split between extract and load

- **Status:** Accepted
- **Date:** 2026-05-11
- **Deciders:** mattiasthalen

## Context

`das extract --full` was originally specified as "ignore cursor; full reload"
and implemented as a wipe of `.dlt/pipelines/das_extract__<source>/`. dlt
persists pipeline state on **both** sides — locally and at the destination
(landing). Wiping only the local copy means dlt re-derives the same state
hash on the next run, finds it already-loaded at landing, and reports zero
rows. The integration test for `--full` carried a deliberately loose
assertion to stay green; #43 made the latent defect visible.

Resolving #43 forced a re-examination of what `--full` means. The pipeline
has two distinct phases with two distinct kinds of "refresh":

- P1 (extract) reads from a source and appends to landing. Refresh here is
  about the **source-side cursor** — making the next read pull the source
  from the beginning rather than from where the last cursor checkpoint left
  off. Landing data must remain untouched (ADR-0002: landing is the
  append-only archive).
- P2 (load) reads landing and writes the destination table via the contract,
  with row-hash change detection deduping unchanged rows (ADR-0004).
  Refresh here is about the **destination table** — replacing it with a
  fresh projection of all landing files.

A single flag named `--full` would have to mean different things on
different commands. Better to give each phase its own flag with clear
semantics.

## Decision

`--full` is split into two independent flags, one per phase, with no
composite version:

- **`das extract --full`** resets dlt cursor state for the named source(s).
  Wipes `.dlt/pipelines/das_extract__<source>/` locally AND
  `<landing>/<source>/_dlt_pipeline_state/`, `_dlt_loads/`, `_dlt_version/`.
  Landing table-data directories are untouched.
- **`das load --full`** sets `write_disposition="replace"` and skips the
  `ChangeDetectionFilter`, causing dlt to truncate and rebuild the
  destination table from a full landing replay. To handle the append-only
  landing's duplicate-payload accumulation (one full landing per
  `extract --full` run), the resource generator deduplicates by primary
  key in-memory, keeping the row with the latest `_extracted_at`. The
  dedup applies only when `full=True` AND a primary key is declared in the
  contract; resources without a primary key fall back to last-write-wins
  per dlt's standard `replace` behaviour.
- **`das ingest`** exposes both as `--extract-full` and `--load-full`. No
  composite `--full` is offered.

Remote landing (`s3://`, `gs://`, `az://`) raises `NotImplementedError` on
`extract --full` until cloud-landing support lands; local landing is the
only currently-tested shape.

## Alternatives considered

- **Composite `--full` on every command meaning "do the most refresh-y
  thing".** Rejected: hides the distinction between source-side and
  destination-side refresh; ambiguous on `ingest` (does it mean re-pull,
  replace, or both?).
- **Use dlt's `refresh="drop_resources"` on `pipeline.run()` for both
  sides.** Rejected: drops resource data along with state, which on
  the P1 pipeline would erase landing files and violate ADR-0002.
- **Surgically delete only the `_dlt_pipeline_state` file (not the whole
  directory hierarchy).** Rejected: dlt also tracks load-package metadata
  in `_dlt_loads`, and the cursor re-sync depends on the pair being
  consistent.
- **Keep `--full` on ingest with both flags as aliases.** Considered:
  more discoverable. Rejected: encourages users to think of "full" as one
  concept; the explicit two-flag form forces the split into muscle memory.
- **Filter landing to only the latest extract's load_id when
  `load --full` is set.** Considered: O(1)-memory alternative to the
  in-memory dedup. Rejected for now: loses cross-extract reconciliation
  semantics (a contract change in extract N could mean older landings
  contain rows under different physical names). Revisit if full-replay
  resource sizes exceed the ~5M-row in-memory dedup ceiling.

## Consequences

- `_dlt_pipeline_state`, `_dlt_loads`, and `_dlt_version` directory names
  become a contract surface with dlt's filesystem destination. A dlt
  upgrade renaming them would break `extract --full` loudly on the first
  run rather than silently — acceptable for v0.1.
- `ingest --full` is removed (was forwarded to extract only). Users with
  scripts that relied on it must migrate to `--extract-full`. This is a
  CLI-shape breaking change accepted in v0.1.
- P1 stays strictly append-only. The historical record of every extract
  load_id remains in landing across `--full` runs.
- P2's table-replace path goes through dlt's first-class
  `write_disposition="replace"`, not through manual table-drop SQL, so it
  works uniformly across DuckDB, DuckLake, and Delta destinations.
- `load --full` holds the deduplicated dataset in memory before yielding
  to dlt: O(distinct-PKs) per resource. For typical workspace sizes
  (thousands to low-millions of rows) this is fine; resources approaching
  ~5M distinct PKs may warrant the load_id-filter alternative described
  above. Tracked as a follow-up if it becomes load-blocking.
