# 0015. Extend OpenAPI bootstrap to walk `paths`

- **Status:** Accepted
- **Date:** 2026-05-06
- **Deciders:** mattiasthalen

## Context

ADR-0006 records the decision to walk `components.schemas` directly when
bootstrapping OpenAPI sources, owning the walker rather than delegating to
`datacontract-cli`. That covers schema → contract translation, but says
nothing about path → schema mapping.

ADR-0014 introduces `das.endpoint` as a contract field. To keep the user-
facing burden zero for spec'd APIs, bootstrap should auto-populate it.

## Decision

Extend `bootstrap/openapi.py` to also walk the `paths` section of the OpenAPI
document. For each `GET` operation, resolve the 200/2xx response body schema
(following `$ref` chains) and index it under the schema name. Recognised
response shapes:

- direct schema reference;
- `array of <schema>`;
- single-key wrapper object (`{value: array of <schema>}`,
  `{data: array of <schema>}`, `{results: array of <schema>}`).

For each schema being emitted as a contract:

- **Exactly one indexed path** → emit `das.endpoint` with that path and
  `response_path` inferred from the response shape.
- **Zero or more-than-one paths** → emit no `das.endpoint`. The user fills
  it in manually.

`pagination` is left at default `{type: none}`. Bootstrap does not infer
pagination from OpenAPI specs — they rarely declare it reliably.

`method`, `query_params`, `headers` are not emitted; defaults apply.

This extends ADR-0006 — it does not supersede it. The walker still walks
`components.schemas` exactly as before; the `paths` walk is additive.

## Alternatives considered

- **Best-effort matching with heuristics for ambiguous cases.** Subtly-wrong
  bootstraps waste more user time than null-and-prompted ones; bootstrap is
  a one-shot operation whose output is committed to git.
- **Always emit, mark uncertain.** Adds a parallel `das.bootstrap_uncertain`
  flag the validator must understand. Strict matching is simpler.

## Consequences

- **Positive:** Spec'd OpenAPI sources extract end-to-end after one
  `das contract bootstrap` invocation. Northwind's `CustomerDto` resolves
  unambiguously to `/Customers`.
- **Negative:** Bootstrap is now coupled to OpenAPI's `paths` shape, not
  just `components.schemas`. Specs with unusual response shapes (deep
  wrappers, `oneOf`/`anyOf` unions) fall back to no `das.endpoint`.
- **Neutral:** ADR-0006 still describes the walker's core; this ADR
  describes the extension.
