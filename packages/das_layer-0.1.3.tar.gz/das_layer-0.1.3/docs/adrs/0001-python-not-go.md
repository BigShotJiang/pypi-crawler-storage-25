# 0001. Use Python (not Go) for the CLI

- **Status:** Accepted
- **Date:** 2026-05-05
- **Deciders:** mattiasthalen

## Context

das-cli orchestrates dlt (a Python library) and runs ingestion pipelines into DuckDB. The original concept proposed Go for the CLI with a uv-managed Python venv hosting dlt as a subprocess.

## Decision

Implement the CLI in pure Python, distributed via `uv tool install das-cli`. No Go.

## Alternatives considered

- **Go CLI shelling out to a Python `das_runner`** — adds a process boundary, a second type system, and parses every contract twice (Go and Python). Distribution simplicity is illusory because users still need Python+uv for dlt.
- **Go CLI as code-generator emitting Python pipelines** — defensible aesthetic but introduces a generated-artifact tier that has to be kept in sync.

## Consequences

- Single language, one parser, one type system end-to-end.
- Direct use of dlt's Python API including `schema_contract` enforcement.
- Native ecosystem fit (duckdb, pyarrow, pydantic, ruamel.yaml, datacontract-cli, pyodata in-process).
- `uv tool install das-cli` and `uvx das` give the same single-command UX a Go binary would.
- Branch name `claude/das-cli-go-dlt-…` is historical; not renamed.
