# 0014. Per-resource `das.endpoint` for HTTP source resolution

- **Status:** Accepted
- **Date:** 2026-05-06
- **Deciders:** mattiasthalen

## Context

`das extract` v0.1 derives the HTTP path for a resource by pluralizing the
`das.spec_ref.type` (e.g., `Product` → `/Products`). This works for OData
because OData's convention is `EntityType` ↔ `/EntityTypes`, but breaks for
generic OpenAPI/REST APIs. Northwind's `CustomerDto` schema is exposed at
`/Customers`, not `/customer_dtos`. The Northwind e2e test xfails at extract
to document this gap.

We need a way to express the actual HTTP shape per resource without per-source
code, while preserving OData's working behavior for existing workspaces.

## Decision

Introduce a contract-level customProperty `das.endpoint` that describes the
HTTP call:

```yaml
customProperties:
  - property: das.endpoint
    value:
      method: GET
      path: /Customers
      response_path: $.value           # null for bare array
      pagination:
        type: json_link
        next_url_path: "@odata.nextLink"
      query_params: {}
      headers: {}
```

Resolution at extract time:

1. Explicit `das.endpoint` wins regardless of source type.
2. OData with no `das.endpoint` synthesizes the v0.1 default
   (`/{spec_ref.type}s`, `$.value`, `@odata.nextLink` paginator).
3. `openapi` and `rest` source types with no `das.endpoint` raise an error.
4. `sql` and `filesystem` ignore `das.endpoint` entirely.

`pagination.type` is dispatched through a registry
(`PAGINATOR_REGISTRY: dict[str, type[BasePaginator]]`) keyed by string. All
other keys in the `pagination` block are passed verbatim as kwargs to the
paginator constructor. dlt is pinned via `uv.lock`, so a paginator config
shape change is a deliberate dlt bump — not a silent break.

## Alternatives considered

- **`--path` CLI override flag.** Doesn't scale beyond ad-hoc cases; not
  declarative.
- **A fixed enum of pagination types.** Forces every paginator extension to
  go through a contract-format change. Pass-through keeps the contract stable
  while letting future custom paginators slot in via the registry.
- **`das.endpoint` as non-OData-only.** Forces two HTTP builders and prevents
  OData users from overriding a misbehaving entity-set name. The universal
  approach collapses to one builder.

## Consequences

- **Positive:** Generic REST APIs work end-to-end with a contract edit, no
  code change. The Northwind e2e test stops xfailing. OData behavior is
  bit-identical for existing contracts.
- **Negative:** A new field to learn; the contract surface grows. Pagination
  pass-through couples contracts to dlt's paginator class shape.
- **Neutral:** Future per-resource auth, templating, etc. can extend the same
  field. Custom paginators slot in via `PAGINATOR_REGISTRY`.
