# 0022. File-based sources via a single `type: filesystem` umbrella

- **Status:** Accepted
- **Date:** 2026-05-12
- **Deciders:** mattiasthalen

## Context

Issue #49 bundled csv, excel, xml as file-based sources, with qvd (#40)
explicitly out of scope as "not a 1:1 shape fit." But the underlying
plumbing — path/glob resolution, blob-URL passthrough, per-resource
selectors, opt-in row provenance — is format-agnostic. Treating qvd as
a sibling source type would have meant a near-duplicate dispatch branch
in `dlt_glue/source_factory.py` for each new format, the same multiplication
ADR-0018 rejected for SQL dialects.

`_source.yml.type` already declared `filesystem` as a placeholder
literal (`src/das_cli/models/source_yml.py`); the CLI accepts it
(`_VALID_SOURCE_TYPES`); the validator forbids `das.endpoint` on it.
None of this was wired to a builder.

## Decision

**Decision A: a single source type `filesystem` covers csv, excel, xml,
and qvd.** Format dispatches per-resource via `das.spec_ref.format`.
One new branch `_build_filesystem_resources` in `dlt_glue/source_factory.py`,
symmetric with ADR-0018's SQL branch. No registry, no plugin layer.

**Decision B: format-specific reading lives in `dlt_glue/file_readers/`,**
one module per format. Each exports `read_rows(file_item, spec_ref) ->
Iterator[dict]`. Readers are pure functions over a dlt `FileItemDict` and
the resource's spec_ref. Independently unit-testable without dlt.

**Decision C: file enumeration uses `dlt.sources.filesystem`,** the
standard dlt source. This brings free fsspec-backed blob support
(`az://`, `s3://`, `gs://`) and free incremental "only new files since
last run" via modification-time tracking. `--full` (ADR-0019) resets
that state via the existing `pipelines/extract.py::reset_extract_state`.

**Decision D: `_source.yml.endpoint` is the root path/URL,** and each
contract's `das.spec_ref.path` is a glob (or single file) relative to
it. Format-specific reader options (delimiter, sheet, xpath, ...) live
in `das.spec_ref` per-resource. `_source.yml.spec.kind = filesystem`
stays format-agnostic.

## Alternatives considered

- **Per-format source types (`type: csv`, `type: excel`, `type: xml`,
  `type: qvd`).** Rejected: four near-duplicate dispatch branches; each
  new format multiplies file/glob/blob plumbing. Diverges from ADR-0018's
  "one branch per source type" pattern.
- **Registry-style source dispatch.** Same rejection rationale as
  ADR-0016 and ADR-0018 — duplicates dlt's abstraction; adds a layer
  for no gain.
- **Per-source format with one format per source.** Forces "one Excel
  workbook = one source," which is the wrong shape — sheets are the
  natural resource unit.
- **Auto-detect format from file extension at extract time.** Rejected:
  conflates discovery (bootstrap concern) with extraction; loses
  explicitness in the contract.

## Consequences

- The `filesystem` literal in `SourceType` becomes load-bearing rather
  than a placeholder. A new branch in `_build_extract_resources` covers
  it. Future formats (parquet, jsonl, ...) plug in as new modules under
  `dlt_glue/file_readers/` plus an enum value in `FilesystemSpecRef.format`.
- The `auth` block carries no credentials for filesystem sources. Blob
  auth flows through dlt's filesystem config (env vars), symmetric with
  the destination side per ADR-0016/0017.
- One PR per format under this umbrella ADR. The umbrella ships with the
  CSV reader (Plan #1); excel/xml/qvd follow.
- Readers must stream. Each reader yields rows one at a time and never
  materializes the full file in memory. This is policy, not enforcement —
  the test suite asserts it per reader (see plan tests).
