# 0006. Bootstrap mix: custom OData parser, direct OpenAPI walker

- **Status:** Accepted (extended by ADR-0015)
- **Date:** 2026-05-05
- **Deciders:** mattiasthalen

## Context

`das contract bootstrap` must turn a source spec (OData `$metadata` XML or OpenAPI JSON) into ODCS YAML files. Implementations exist for some formats but not all.

## Decision

- **OData**: own the parser. Use stdlib `ElementTree` to read `$metadata` XML; write our own ODCS emitter for the EDM-type → ODCS-logicalType mapping.
- **OpenAPI**: walk `components.schemas` directly in our own code (`bootstrap/openapi.py`). We initially planned to delegate to `datacontract-cli`, but found that walking the JSON document directly was simpler and gave us full control over the post-processing (snake_case, primary key inference, `das.*` customProperties). No external delegation.
- **Sample-from-lake**: own the inference. Walk recent JSONL records, infer types, emit `status: draft` ODCS.

## Alternatives considered

- **Hand-roll both parsers.** Reinvents wheels; OpenAPI edge cases are vast. Accepted risk — the walker covers the subset we actually use.
- **Delegate both.** `datacontract-cli` doesn't currently support OData import.
- **Delegate OpenAPI to datacontract-cli.** Rejected during implementation: see Decision. The dependency was removed after we confirmed the in-process walker was sufficient.

## Consequences

- We maintain ~one file of OData mapping logic (`bootstrap/odata.py`) and one for OpenAPI (`bootstrap/openapi.py`).
- No dependency on `datacontract-cli`; we are not tied to its release cadence.
- Sample-fallback works for any source after a first successful extract.
- Future formats (Avro, Protobuf) can reuse the walk-and-emit pattern established here.
