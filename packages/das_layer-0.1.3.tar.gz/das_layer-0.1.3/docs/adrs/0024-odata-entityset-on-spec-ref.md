# 0024. OData EntitySet name persisted on `das.spec_ref`

- **Status:** Accepted (extended by ADR-0025)
- **Date:** 2026-05-13
- **Deciders:** mattiasthalen

## Context

ADR-0014's synthesis fallback for OData derives the URL path by appending `"s"`
to `das.spec_ref.type`. This works for EntityTypes whose EntitySet pluralizes
via plain `+s` (Northwind: `Product` → `/Products`) but fails for `+es`,
`y → ies`, and irregular plurals (AdventureWorks: `Address` → `/Addresses`,
`Currency` → `/Currencies`, `Person` → `/People`). The authoritative name lives
in `$metadata`'s `<EntityContainer><EntitySet>` block.

## Decision

OData bootstrap (`bootstrap/odata.py`) reads `<EntityContainer><EntitySet>` and
persists the set name on `das.spec_ref.entity_set` for each EntityType with a
matching declaration:

```yaml
customProperties:
  - property: das.spec_ref
    value:
      kind: odata
      type: Address
      entity_set: Addresses
```

`synthesize_odata_endpoint()` resolves the path in this order:

1. `spec_ref.entity_set` if present.
2. `pluralize_preserving_case(spec_ref.type)` heuristic (`y → ies`, `+es` on
   `s/x/z/ch/sh`, else `+s`).
3. `contract.resource_name`.

Explicit `das.endpoint` on the contract continues to win over synthesis
(ADR-0014, unchanged).

## Alternatives considered

- **Heuristic only.** Cheaper, but drifts from authoritative `$metadata` and
  silently 404s on truly irregular plurals.
- **Require explicit `das.endpoint` everywhere.** Hard-breaks the OData
  zero-config ergonomic that ADR-0014 deliberately preserved.

## Consequences

- **Positive:** Newly-bootstrapped OData sources use the actual EntitySet
  names from `$metadata`. Legacy contracts gain a meaningful heuristic
  improvement for free.
- **Negative:** Legacy contracts with truly irregular plurals (Person/People)
  still fail until re-bootstrap (`das contract bootstrap <source> --force`) or
  explicit `das.endpoint`. Documented as the migration path; no automatic upgrade.
- **Neutral:** `das.spec_ref.entity_set` is additive; older das-cli versions
  ignore unknown keys.
