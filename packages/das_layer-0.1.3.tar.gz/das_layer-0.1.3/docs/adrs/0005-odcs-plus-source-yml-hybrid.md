# 0005. ODCS v3 for resource contracts; custom `_source.yml` for connection

- **Status:** Accepted
- **Date:** 2026-05-05
- **Deciders:** mattiasthalen

## Context

A contract format must hold the schema (column types, keys, descriptions) per resource. We also need workspace-level connection config (auth, endpoint, source spec reference). ODCS v3 is the Linux Foundation's contract standard but models one document per dataset — it doesn't natively express the source-vs-resource hierarchy.

## Decision

Two-tier YAML:

- **Resource contracts** are ODCS v3 documents at `contracts/<source>/<resource>.odcs.yaml`. Schema, primary keys, types, descriptions live here.
- **Connection config** lives in `contracts/<source>/_source.yml` — a minimal custom format with `type`, `endpoint`, `spec`, `auth`, `ownership`. It is *not* an ODCS document.

DAS-specific bits (cursor, change detection overrides, hash exclusions, source spec ref) go into ODCS `customProperties` under the `das.*` namespace.

## Alternatives considered

- **All-ODCS, with source-level config encoded as `customProperties` repeated across resources.** Duplicates connection info; brittle.
- **All-custom, no standards.** Loses ecosystem interop (BI tools, lineage, governance read ODCS).
- **`datacontract-cli`'s schema (also ODCS, but their fork).** Same as ODCS; we use upstream.

## Consequences

- ODCS resource files are interoperable with downstream tooling without translation.
- `_source.yml` is small, focused, and free to evolve without breaking ODCS conformance.
- Bootstrap targets ODCS shape — code maps source-spec types to ODCS, not to a homegrown DSL.
- DAS-specific extensions live under one namespace (`das.*`) — see ADR-0011.
