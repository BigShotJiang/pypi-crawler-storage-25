# 0009. dlt config flows via Python objects, not `.dlt/config.toml`

- **Status:** Accepted
- **Date:** 2026-05-05
- **Deciders:** mattiasthalen

## Context

dlt accepts configuration via env vars, `.dlt/config.toml`, or in-process Python objects passed to `dlt.pipeline(...)`. das-cli already loads workspace config from `das.yaml` with Jinja env_var rendering.

## Decision

Render `das.yaml` to Python dicts at config load, then pass them to dlt's pipeline factory directly:

```python
pipeline = dlt.pipeline(
    pipeline_name=...,
    destination=dlt.destinations.duckdb(credentials=cfg.target.credentials),
    dataset_name=resolve_dataset_name(...),
    pipelines_dir=".dlt/pipelines",
)
```

We do not create `.dlt/config.toml` and do not depend on dlt reading it.

## Alternatives considered

- **Translate `das.yaml` to `.dlt/config.toml` and let dlt read it.** Adds a write step; two config files in the workspace; harder to override per-test.
- **Use env vars (`DESTINATION__DUCKDB__CREDENTIALS=...`).** Pollutes process environment; brittle for parallel tests.

## Consequences

- One config layer, one parser, one place to look.
- `--target` and `--landing` CLI flags become trivial overrides on the rendered dict.
- Pytest fixtures use `monkeypatch.setenv()` for `DAS_TARGET_DB` / `DAS_LANDING_URL`; das-cli renders against the modified env.
- Env vars *are* used for dlt-native runtime knobs (`RUNTIME__LOG_LEVEL` when `-v`).
