# 0026. Tag-based releases via hatch-vcs and PyPI OIDC trusted publishing

- **Status:** Accepted
- **Date:** 2026-05-19
- **Deciders:** Mattias Thalén

## Context

das-cli ships as a CLI installed from PyPI (`uv tool install ...`). The
repo had no git tags, no release workflow, and a static `version = "0.1.0"`
in `pyproject.toml`. Cutting a release meant building and uploading by
hand — error-prone and not reproducible.

Two adjacent constraints shape the decision:

1. The PyPI name `das-cli` is already taken by an unrelated active project
   (Royal Netherlands Institute for Sea Research, distributed acoustic
   sensing). The package must publish under a different distribution name.
2. The maintainer ships solo, pre-1.0, and picks version numbers by hand.
   A fully automated release-please / semantic-release setup is overkill
   for this scale.

## Decision

- **PyPI distribution name** is `das-layer`. The GitHub repo, the CLI
  command (`das`), and the Python import path (`das_cli`) are unchanged.
- **Release trigger** is a `vX.Y.Z` git tag pushed to the repo. A
  workflow `.github/workflows/release.yml` runs on `push.tags: ["v*"]`.
  No other trigger.
- **Version source** is the git tag, read by `hatch-vcs` at build time.
  `pyproject.toml` declares `dynamic = ["version"]` and configures
  `[tool.hatch.version] source = "vcs"` with `fallback-version = "0.0.0"`.
  `src/das_cli/__init__.py` reads `__version__` via
  `importlib.metadata.version("das-layer")`.
- **PyPI authentication** is OIDC trusted publishing via
  `pypa/gh-action-pypi-publish@release/v1`. No long-lived tokens in
  GitHub. One-time bootstrap on pypi.org registers a pending publisher
  for `das-layer` pointing at the repo and workflow filename.
- **Release notes** are auto-generated from PR titles since the previous
  tag, via `softprops/action-gh-release@v2` with
  `generate_release_notes: true`. No CHANGELOG.md.

## Alternatives considered

- **GitHub Release UI as trigger** (workflow on `release: published`) —
  adds a second path to a release with no benefit; `git tag && git push
  --tags` already does the job.
- **release-please / semantic-release** — automates conventional-commit
  to version bumps. Overkill for one maintainer pre-1.0; revisit if
  multi-maintainer or external consumers demand strict semver.
- **Static `version` in `pyproject.toml` + CI guard** — eliminates the
  hatch-vcs dependency at the cost of a manual step. `hatch-vcs` makes
  the drift it would catch impossible in the first place.
- **API token in a GitHub secret** instead of OIDC — simpler one-time
  bootstrap, but the token is long-lived and needs rotation. OIDC is
  PyPA's current recommendation.
- **TestPyPI dry-run before PyPI publish** — adds a second publisher to
  register. The first real PyPI publish (`v0.1.0`) is itself the dry-run.
  Add later if a release goes wrong in a way TestPyPI would have caught.
- **`pip install` as the primary install command in docs** — the repo is
  uv-native end-to-end (CI, README). Keep `uv tool install` primary and
  mention `pip` as an alternative.

## Consequences

**Positive**
- Every PyPI artifact corresponds to a signed git tag; no manual build
  steps.
- No long-lived PyPI credentials stored in GitHub.
- Tag and package version cannot drift — they are the same value.
- Pre-release tags (`v0.2.0a1`) flow through the same workflow with no
  extra config.

**Negative**
- First release requires one-time pending-publisher registration in the
  pypi.org UI.
- `hatch-vcs` is a new build-time dependency. The
  `fallback-version = "0.0.0"` setting keeps `uv sync` working on shallow
  CI checkouts without tags.
- Release-note quality is coupled to PR-title hygiene; currently good.

**Neutral**
- The maintainer continues to pick version numbers by hand. SemVer is a
  convention, not enforced by tooling.
- No CHANGELOG.md. Release history is reconstructible from GitHub
  Releases and `git log`.
