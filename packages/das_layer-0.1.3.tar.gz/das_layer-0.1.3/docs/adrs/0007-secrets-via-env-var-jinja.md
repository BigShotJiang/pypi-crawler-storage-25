# 0007. Secrets via Jinja `env_var(...)` only — no `.dlt/secrets.toml`

- **Status:** Accepted
- **Date:** 2026-05-05
- **Deciders:** mattiasthalen

## Context

Source authentication tokens, cloud credentials, and target connection strings must not be committed. dlt natively reads `.dlt/secrets.toml`; dbt-style projects use Jinja `{{ env_var() }}` in YAML.

## Decision

das-cli supports exactly one secret mechanism: Jinja `{{ env_var('NAME') }}` (with optional `default`) in `das.yaml`, `_source.yml`, and ODCS files. Templates render at config-load time. We do not write or read `.dlt/secrets.toml`.

## Alternatives considered

- **`.dlt/secrets.toml` + Jinja.** Two mechanisms; users won't know which place wins.
- **Custom secret resolver protocol (`secret://aws/...`).** Premature; not needed for v0.1.

## Consequences

- Single mechanism. Secrets live in environment, never in repo.
- Missing required env vars fail loudly at config load with file+field context.
- Cloud credentials (AWS, GCS, Azure) for landing/target are templated the same way.
- Tests use `monkeypatch.setenv()`; no fixture files for secrets.
