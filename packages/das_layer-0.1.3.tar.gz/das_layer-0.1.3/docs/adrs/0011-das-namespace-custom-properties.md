# 0011. `das.*` namespace for ODCS `customProperties`

- **Status:** Accepted
- **Date:** 2026-05-05
- **Deciders:** mattiasthalen

## Context

ODCS v3 reserves `customProperties` for downstream-specific extensions. das-cli needs places to attach: cursor field, source spec reference, change-detection overrides, hash exclusions, source paths for nested fields.

## Decision

All das-cli-specific metadata uses keys prefixed with `das.`:

- Contract-level: `das.spec_ref`, `das.cursor`, `das.write_disposition`, `das.change_detection`, `das.hash_exclude`, `das.bootstrapped_from`.
- Column-level: `das.source_path`.

The validator rejects unknown `das.*` keys (typo protection).

## Alternatives considered

- **Top-level keys outside `customProperties`.** Breaks ODCS conformance; downstream ODCS tooling fails on unknown top-level keys.
- **No prefix (e.g., bare `cursor:`).** Collides with future ODCS additions.

## Consequences

- Future ODCS-tooling interop is unambiguous — they ignore `das.*`.
- Adding a new DAS extension is mechanical: add to validator's allowlist + the model.
- If ODCS later adopts a similar concept (say, `cursor`), we keep `das.cursor` and document the relationship.
