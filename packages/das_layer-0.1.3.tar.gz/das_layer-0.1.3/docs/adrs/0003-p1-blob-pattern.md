# 0003. P1 uses dlt's pipeline with `_data: json` blob pattern

- **Status:** Accepted
- **Date:** 2026-05-05
- **Deciders:** mattiasthalen

## Context

P1 must produce strict raw JSONL — no normalization, no flattening, no type coercion. dlt's default pipeline includes a `normalize` phase that flattens nested objects and infers columns. We need raw output without rebuilding dlt's auth, pagination, retry, and incremental machinery.

## Decision

Each P1 resource is defined with a single column `_data: json` (dlt's complex type). The dlt source yields `{"_data": <raw record>}` per item. The `normalize` phase becomes a no-op because there is nothing to flatten. Output JSONL line shape: `{"_data": {...raw record...}, "_dlt_load_id": "...", "_dlt_id": "..."}`.

## Alternatives considered

- **Bypass dlt entirely for P1.** Use `requests` + custom paginators + write JSONL directly. Reimplements OAuth, OData `@odata.nextLink`, retries, incremental state — significant code, ongoing maintenance.
- **Use dlt with `max_table_nesting=0`.** Still infers top-level columns; not strictly raw. Rejected.

## Consequences

- Inherits dlt's auth, paginators, retries, incremental cursors, parallelism.
- Two metadata fields (`_dlt_load_id`, `_dlt_id`) wrap each record. Provenance, not normalization.
- Filesystem destination writes `.jsonl.gz` natively (`loader_file_format=jsonl`, `compression=gzip`).
- P2 reads `_data` and applies the contract — clean separation of concerns.
