# 0013. Load-date semantics: hive partition + derived staging columns

- **Status:** Accepted
- **Date:** 2026-05-06
- **Deciders:** mattiasthalen

## Context

Two related needs surfaced together:

1. **Landing layout.** Flat `landing/<source>/<resource>/<load_id>.<file_id>.jsonl.gz`
   blocks date-partition pushdown when querying landing directly with DuckDB,
   Spark, Trino, or Athena, and makes retention pruning ("delete everything
   older than 30 days") awkward.
2. **Staging metadata.** `_dlt_load_id` is an epoch-as-string; load-time
   queries require `TO_TIMESTAMP(CAST(_dlt_load_id AS DOUBLE))` everywhere.
   No first-class `TIMESTAMP` or `DATE` for "when was this row loaded?"

These are two tiers of the same concept — *when did data move?* — and
benefit from coordinated naming.

## Decision

**Landing (P1):** files are physically partitioned by extract date using
Hive-style partitioning:

```
landing/<source>/<resource>/_extracted_on=YYYY-MM-DD/<load_id>.<file_id>.jsonl.gz
```

dlt's filesystem destination accepts a `layout` parameter; we set it to
`{table_name}/_extracted_on={curr_date}/{load_id}.{file_id}.{ext}`. `{curr_date}`
resolves to the load package's UTC date.

**Staging (P2):** every staging table carries four NOT-NULL metadata columns
alongside `_row_hash`:

| Column          | Type      | Source                                                   | Cardinality |
|-----------------|-----------|----------------------------------------------------------|-------------|
| `_extracted_at` | TIMESTAMP | `datetime.fromtimestamp(line["_dlt_load_id"], UTC)`     | per-row     |
| `_extracted_on` | DATE      | `_extracted_at.date()`                                   | per-row     |
| `_loaded_at`    | TIMESTAMP | `datetime.fromtimestamp(load_package_state["load_id"])`  | per-load    |
| `_loaded_on`    | DATE      | `_loaded_at.date()`                                      | per-load    |

Per-row extract stamps come from the JSONL line's `_dlt_load_id` — the
extract pipeline's load id, written by dlt during P1. Per-load load stamps
come from `dlt.current.load_package_state()["load_id"]` inside the P2
resource closure. All times are UTC.

The on-disk partition key (`_extracted_on=...`) and the staging column
(`_extracted_on`) are deliberately the same name. A user querying landing
with `read_json('.../*.jsonl.gz', hive_partitioning=true)` gets a virtual
column literally indistinguishable from the staging column.

## Alternatives considered

- **Single `loaded_on` semantic at both tiers** (the umbrella issue's first
  framing). Conflated extraction with loading. Cross-day extract→load made
  the meaning ambiguous; rejected in favor of the two-tier model.
- **Stamp `_loaded_at` from `datetime.now(UTC)` at resource-build time**
  (issue #9 Option A). Simple but introduces sub-second skew vs.
  `_dlt_load_id`. Reading from `dlt.current.load_package_state()` (Option B)
  costs ~3 lines and gives exact alignment.
- **DuckDB `GENERATED ALWAYS AS (...) STORED` columns** (issue #9 Option C).
  Conflicts with `schema_contract: freeze` and requires injecting DDL
  around dlt's table-creation step. Rejected.
- **Surface the partition path into the column by parsing the file path
  in P2.** The column is derivable from `_dlt_load_id` (a superset of
  information). Path parsing adds fragility for no benefit.
- **Migrate pre-existing flat-layout landing files** as part of this
  release. v0.x is pre-stable; `das load`'s `rglob` is layout-indifferent;
  cohabit is simpler and equivalent. Rejected.

## Consequences

- DuckDB / Spark / Trino / Athena can query landing with native partition
  pushdown. `read_json('.../*.jsonl.gz', hive_partitioning=true)` exposes
  `_extracted_on` automatically.
- Retention pruning is `find landing -path '*/_extracted_on=2026-04*' -delete`.
- Load-time and extract-time queries on staging are one-liners
  (`WHERE _loaded_on = CURRENT_DATE - 7`).
- Cross-day extract→load is unambiguous: `_extracted_on` reflects extract
  day; `_loaded_on` reflects load day. They may differ; that is by design.
- Pre-existing staging tables (created before v0.1.3) lack the four
  columns. With `columns: freeze` (the default per ADR-0012), the next
  load against such a table fails. Users on the v0.1.x upgrade path must
  drop the affected staging tables (full history rebuilds from landing,
  per ADR-0004) or `ALTER TABLE ... ADD COLUMN` manually. Documented as a
  v0.1.3 breaking change in release notes.
- `_loaded_at` is derived from dlt's load id via the public
  `dlt.current.load_package_state()` API. Pinned to dlt 1.x's
  `TLoadPackage["load_id"]`; revisit if upgrading dlt majors.
- The change-detection hash is computed on the source `_data` record
  before the metadata columns are added, so the new columns never
  influence change detection. No `das.hash_exclude` entry needed.
