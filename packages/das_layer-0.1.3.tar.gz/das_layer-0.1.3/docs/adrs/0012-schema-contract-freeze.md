# 0012. Schema enforcement via `data_type: freeze` plus contract projection

- **Status:** Accepted
- **Date:** 2026-05-05
- **Deciders:** mattiasthalen

## Context

dlt's `schema_contract` parameter has three independent knobs: `tables`, `columns`, and `data_type`. Each accepts `evolve` (allow drift), `freeze` (reject the load), or `discard_value` / `discard_row` (silently drop). P2's purpose is contract enforcement — drift must surface loudly without silent data loss, while still letting valid first loads succeed.

A naive reading of "freeze everything" runs into a dlt 1.x quirk: `tables: freeze` rejects creation of new tables in the destination. On the very first load against an empty DuckDB no staging tables exist yet, so `freeze` blocks the legitimate first run. Working around it would require a stateful "schema-init" pre-pass that adds operational friction for no real safety gain (we never create unexpected tables; we only generate resources from declared contracts).

## Decision

P2 resources use:

```python
schema_contract = {
    "tables":    "evolve",
    "columns":   "freeze",
    "data_type": "freeze",
}
```

Drift detection in v0.1 is a composition of three mechanisms:

1. **Contract projection at load time.** P2 only emits columns declared in the resource's ODCS contract — extra source-side fields are dropped by the projection layer in `pipelines/load.py` before dlt sees them. Source APIs are free to add fields without breaking the load; new fields become "invisible" until the contract opts them in.
2. **`columns: freeze`.** Once a staging table exists, dlt rejects any load that would add a new column to it. Combined with projection, this is mostly a safety net.
3. **`data_type: freeze`.** Loads that would change the type of an existing column fail with `SchemaFrozenException` → exit code 5. This is the active drift detector and the one tested end-to-end (`test_freeze_rejects_changed_type`).

`tables: evolve` is set explicitly because we never create unexpected tables — every resource that runs corresponds to a contract file in `contracts/<source>/`.

## Alternatives considered

- **Full `freeze` everywhere.** Blocks legitimate first loads. Workable only with a pre-pass that primes the pipeline's saved schema with `evolve`, then locks it. Adds a stateful setup step for no safety gain over what `data_type: freeze` already gives us.
- **`discard_value` / `discard_row`.** Silently drops drifted data — data loss without alarms. Rejected.
- **Pre-projection drift check** (an explicit `_check_schema_drift` that errors on extra source-side fields). Initially implemented in P2; removed because it conflicts with the projection model (extra fields are *supposed* to be dropped, not error).
- **Per-resource opt-out.** Premature; if a resource truly can't conform, that's a contract bug.

## Consequences

- Type changes for an already-loaded column fail the load with exit 5. The fix path is `das contract diff` → edit contract → re-run.
- Extra source-side fields are silently projected away. Engineers learn about new source fields via `das contract diff` (compares contracts vs. live spec), not via load failures. This is a deliberate trade — failing every minor source-side addition would be too noisy in practice; explicit `diff` is the discovery tool.
- New tables are created on first load. We don't enforce "only known tables" at the dlt layer because contract files already constrain what gets generated.
- `tables: evolve` does not weaken contract discipline: the schema of each table is still locked by `columns: freeze` + `data_type: freeze` once the table exists.
- A future v0.2 improvement is to surface "extra source field" as a soft-warning during `das doctor` or `das ingest`, so silently-dropped fields don't go unnoticed indefinitely.
