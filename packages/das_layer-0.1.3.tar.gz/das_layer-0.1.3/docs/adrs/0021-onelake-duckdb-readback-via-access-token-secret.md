# 0021. OneLake DuckDB read-back via PROVIDER ACCESS_TOKEN secret

- **Status:** Supersedes ADR-0020
- **Date:** 2026-05-12
- **Deciders:** mattiasthalen

## Context

ADR-0020 verified write paths to OneLake (extract → JSONL, load → Delta)
from outside Fabric runtime using three workaround surfaces — adlfs's
`account_host` rewrite plus credential-object passthrough, and the Rust
`object_store`'s `use_fabric_endpoint` + bearer token via
`deltalake_storage_options`. The Consequences section explicitly tracked a
remaining gap as a follow-up:

> OneLake from outside Fabric runtime: write paths work, read-back via
> DuckDB-Delta extension does not. DuckDB's Azure auth is a separate
> credential surface from both adlfs and `object_store` — it requires
> either a `CREATE SECRET ... TYPE AZURE` statement or environment
> variables under DuckDB's naming convention. das-cli does not wire either
> today, so `pipeline.sql_client()` against OneLake-backed Delta fails
> with `401 Unauthorized` from DuckDB's underlying HTTP fetch.

That gap bites in production: `change_detection.load_latest_hash` reads
prior row hashes via `pipeline.sql_client()` on second-cycle loads (first
load short-circuits via `DatabaseUndefinedRelation`). Without DuckDB Azure
auth, every second `das ingest` on an OneLake destination would 401.

The mechanism: dlt's `FilesystemSqlClient.create_secret` auto-emits an
Azure secret on connection open. For OneLake URLs, das-cli passes
`AzureCredentialsWithoutDefaults` with a placeholder SAS to satisfy dlt's
config-resolver — the real auth flows through `kwargs=` and
`deltalake_storage_options`. dlt sees the placeholder shape and emits
`CONNECTION_STRING 'AccountName=onelake;AccountKey=<placeholder>'`, which
DuckDB accepts at CREATE time but fails on first `delta_scan`.

DuckDB's Azure extension supports `PROVIDER ACCESS_TOKEN` with a
freshly-acquired storage-audience bearer token plus
`ACCOUNT_NAME 'onelake'` — that combination routes to the Fabric blob
endpoint with a valid Bearer header.

ADR-0020 is superseded so this ADR records both the Azure landing + Delta
decisions and the DuckDB read-back decision in one place.

[adlfs486]: https://github.com/fsspec/adlfs/issues/486

## Decision

**Decision A (restated from ADR-0020): das-cli accepts `az://`,
`abfs://`, `abfss://` URLs for both `landing.bucket_url` and the Delta
target's `target.credentials.bucket_url`.** OneLake is a URL convention on
`abfss://`, not a separate scheme. das-cli does not branch on
`onelake.dfs.fabric.microsoft.com` vs `<account>.dfs.core.windows.net` —
both flow through dlt and adlfs as opaque ABFS URLs. For OneLake, the
GUID URL form (`abfss://<workspace_guid>@onelake.dfs.fabric.microsoft.com/<item_guid>/…`)
is recommended; the name form is per Microsoft Learn but the dlt docs
hard-recommend GUIDs and the name form is not verified.

**Decision B (restated from ADR-0020): two explicit `auth` modes —
`service_principal` and `default`.** A discriminated `AzureCredentials`
Pydantic model lives in `models/das_yaml.py` and parses the `credentials`
dict when the corresponding `bucket_url` is Azure:

```yaml
credentials:
  auth: service_principal
  tenant_id: "{{ env_var('AZURE_TENANT_ID') }}"
  client_id: "{{ env_var('AZURE_CLIENT_ID') }}"
  client_secret: "{{ env_var('AZURE_CLIENT_SECRET') }}"
```

```yaml
credentials:
  auth: default
```

`default` invokes dlt's `AzureCredentials` (which wraps
`DefaultAzureCredential`), chaining env-var SP → managed identity → az
CLI → developer Azure tools. A separate `cli` mode would just be a slower
alias for the same code path; managed identity is one link in the same
chain.

Per ADR-0007, secrets only come in via `{{ env_var(...) }}`. Standard
Azure SDK env-var names (`AZURE_TENANT_ID`, `AZURE_CLIENT_ID`,
`AZURE_CLIENT_SECRET`, `AZURE_STORAGE_ACCOUNT_NAME`) are used throughout
the docs because they are the names both Python `azure-identity` and
Rust `object_store` read — one `.env` works for both sides.

**Decision C (restated from ADR-0020): landing reads go through fsspec.**
The helper `dlt_glue/landing_fs.py` returns a
`(fsspec.AbstractFileSystem, root_path)` pair for any
`landing.bucket_url`. `LocalFileSystem` for bare paths and `file://`;
`AzureBlobFileSystem` (adlfs) for `az://` / `abfs://` / `abfss://`.
`_iter_landing`, `count_landing_rows`, and `reset_extract_state` all flow
through this helper. Only `file://` and Azure are verified.

**Decision D (restated from ADR-0020): das-cli does not own
`storage_options` plumbing, but does set `azure_storage_account_name` on
the typed credentials object.** dlt's typed Azure credentials
(`AzureServicePrincipalCredentialsWithoutDefaults` and
`AzureCredentials`) produce the right `object_store` storage_options for
the Rust deltalake writer automatically. das-cli builds the credentials
object from das-cli's `AzureCredentials` model and passes it as
`credentials=` to `dlt.destinations.filesystem(...)`. The per-resource
`table_format="delta"` plumbing from ADR-0017 is unchanged.

For OneLake, `azure_storage_account_name` is derived from the URL host
(`onelake` for OneLake, `<account>` for ADLS Gen2 generic), and
`azure_account_host` is set to the **blob** equivalent of the DFS host
because adlfs uses the Blob API for `iterdir`/`glob`/`find`/`ls` and
OneLake's DFS endpoint rejects those (see [adlfs486]). For ADLS Gen2
generic, both fields take dlt's defaults.

**Decision E (new): DuckDB read-back authenticates via
`PROVIDER ACCESS_TOKEN`, installed inside an `open_sql_client` wrapper.**
A new context-manager helper
`das_cli.dlt_glue.azure_credentials.open_sql_client(pipeline, *,
bucket_url, azure)` wraps `pipeline.sql_client()`. For Fabric URLs (and
only for Fabric URLs), the helper executes
`CREATE OR REPLACE SECRET das_fabric_<sanitized_scope> ( TYPE AZURE,
PROVIDER ACCESS_TOKEN, ACCESS_TOKEN '<jwt>', ACCOUNT_NAME 'onelake',
SCOPE '<bucket_url_without_container>' )` against the DuckDB connection
dlt opens, *after* dlt has emitted its own (malformed-for-OneLake)
CONNECTION_STRING secret and *before* yielding the client to the caller.

The bearer token is acquired via `azure_credentials.acquire_storage_bearer_token`
against the `https://storage.azure.com/.default` audience — the same
acquisition used for `deltalake_storage_options.bearer_token`. Secret
name follows dlt's sanitization (lowercase + strip non-letters) prefixed
with `das_fabric_` so both secrets coexist; DuckDB matches the longest
SCOPE prefix and the explicit `das_fabric_*` wins for the Fabric URL.

Callers: `change_detection.load_latest_hash` accepts optional
`bucket_url=` and `azure=` kwargs, threaded down from
`pipelines/load.py:_build_destination` through `_build_load_resource`.
The Azure e2e reader pipeline in
`tests/e2e/destinations/test_delta_azure.py` opens its `sql_client()`
through the same helper.

Standard ADLS Gen2 takes the simpler path: dlt's auto-emitted
`PROVIDER SERVICE_PRINCIPAL` secret already works, so `open_sql_client`
is a pass-through wrapper.

## Alternatives considered

(Decisions A–D alternatives carried over from ADR-0020; only Decision E
alternatives are new.)

- **Add a discrete `cli` auth mode for `az login`.** Rejected — it's one
  link in the `DefaultAzureCredential` chain, exposed via `auth: default`.
- **Add `managed_identity` as a distinct mode.** Rejected for the same
  reason — `DefaultAzureCredential` already picks up the IMDS endpoint
  on Azure VMs / AKS / Functions.
- **Manage `storage_options` in das-cli, merge with dlt's.** Rejected —
  duplicates the work dlt already does in
  `to_object_store_rs_credentials()` and locks das-cli to dlt's internal
  shape.
- **Use the dlt `fabric` destination
  ([dlt PR #3535](https://github.com/dlt-hub/dlt/pull/3535))**.
  Rejected — that destination targets Fabric **Warehouse** (T-SQL +
  COPY INTO), a different surface from OneLake-as-files + Delta.
- **Add `s3://` and `gs://` in the same pass.** Rejected — different
  credential shapes, different `object_store` quirks. S3/GCS can land on
  their own verified slices later.
- **(Decision E) Use DuckDB environment variables (`AZURE_*` /
  `AZURE_STORAGE_CONNECTION_STRING`).** Rejected — DuckDB's variable-based
  Azure config has no ACCESS_TOKEN slot; bearer tokens don't fit. Leaks
  across pipelines/tests in the same process.
- **(Decision E) Open a separate `duckdb.connect()` bypassing dlt.**
  Rejected — doubles the read path for the OneLake case only and breaks
  destination-agnosticism in `change_detection.py` that ADR-0016
  deliberately preserved.
- **(Decision E) Overwrite dlt's existing secret in place (same name)
  rather than publishing a new `das_fabric_*` secret.** Equivalent end
  state but couples to dlt's internal secret-naming convention. Brittle
  if dlt changes that scheme.
- **(Decision E) Persist the secret (`PERSISTENT`).** Tokens are
  short-lived (~1h); persistence has no value.

## Consequences

- The `AzureCredentials` Pydantic model in `models/das_yaml.py` is opt-in:
  only parsed when the relevant `bucket_url` is Azure. Existing local-path
  workspaces are unaffected.
- das-cli relies on dlt's `to_object_store_rs_credentials()` to produce
  the right Azure storage_options for the Rust deltalake writer. A future
  dlt release that changes the merge semantics or the
  `azure_storage_token` field name would break das-cli; this is a
  stable-API-shaped surface and is documented here so future maintainers
  know where to look.
- The `delta` destination accepts Azure URLs but offers no extra
  configurability beyond `bucket_url` + `credentials`. Compaction,
  retention, and vacuum remain out of scope.
- AWS S3 and GCS are *not* verified by this ADR.
- `doctor` performs config-typo hygiene only for Azure. No live token
  fetch, no network call.
- Cross-pipeline reads on Azure-backed Delta carry the same constraint
  as local Delta (ADR-0017 Decision C): readers must share the writer's
  `pipeline_name` / `pipelines_dir`.
- **OneLake from outside Fabric runtime: verified end-to-end.** Three
  workaround surfaces, each addressing a separate credential domain:
  1. **adlfs (Python landing reads/writes):** DFS→Blob host rewrite plus
     credential object via dlt's `kwargs=` passthrough.
  2. **`object_store` (Rust deltalake writer):** `use_fabric_endpoint:
     "true"` + bearer token via `deltalake_storage_options`.
  3. **DuckDB (Delta extension read-back):** `open_sql_client` installs
     `CREATE OR REPLACE SECRET ... TYPE AZURE PROVIDER ACCESS_TOKEN
     ACCOUNT_NAME 'onelake'` against the DuckDB connection dlt opens.

  Verified end-to-end on OneLake from outside Fabric: extract → JSONL
  into `/Files/`, load → Delta into `/Tables/`, read-back via DuckDB, and
  second-cycle change-detection no-op (which exercises `sql_client()`
  inside `change_detection.load_latest_hash`).

  Token TTL (~1h) is the same shape across surfaces 2 and 3. Long-running
  pipelines that span that boundary would need token-refresh participation
  in dlt's per-request credential plumbing — out of scope today.

  Standard ADLS Gen2 endpoints (`<account>.dfs.core.windows.net`) take
  the simpler typed-credentials path on all three surfaces.
