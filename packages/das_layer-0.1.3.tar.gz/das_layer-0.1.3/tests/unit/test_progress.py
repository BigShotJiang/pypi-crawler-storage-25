"""Tests for the progress module."""

from __future__ import annotations

from collections.abc import Iterator

import pytest

from das_cli.progress import progress, resolve_mode


def test_quiet_wins_over_verbose() -> None:
    assert resolve_mode(quiet=True, verbose=True, isatty=True) == ("silent", None)


def test_quiet_silences_progress_and_dlt() -> None:
    assert resolve_mode(quiet=True, verbose=False, isatty=True) == ("silent", None)
    assert resolve_mode(quiet=True, verbose=False, isatty=False) == ("silent", None)


def test_verbose_disables_rich_keeps_dlt_log() -> None:
    assert resolve_mode(quiet=False, verbose=True, isatty=True) == (None, "log")
    assert resolve_mode(quiet=False, verbose=True, isatty=False) == (None, "log")


def test_default_tty_uses_rich() -> None:
    assert resolve_mode(quiet=False, verbose=False, isatty=True) == ("rich", None)


def test_default_non_tty_uses_plain() -> None:
    assert resolve_mode(quiet=False, verbose=False, isatty=False) == ("plain", None)


def test_silent_progress_is_passthrough() -> None:
    items = [1, 2, 3, 4, 5]
    with progress(["a"], mode="silent") as h:
        out = list(h.wrap("a", iter(items)))
    assert out == items


def test_silent_progress_handles_multiple_resources() -> None:
    with progress(["a", "b"], mode="silent") as h:
        a = list(h.wrap("a", iter([1, 2])))
        b = list(h.wrap("b", iter([3, 4, 5])))
    assert a == [1, 2]
    assert b == [3, 4, 5]


def test_silent_progress_accepts_total_mapping() -> None:
    """Mapping form (used by load) should also work in silent mode."""
    with progress({"a": 100, "b": 50}, mode="silent") as h:
        out = list(h.wrap("a", iter([1, 2, 3])))
    assert out == [1, 2, 3]


def test_silent_wrap_propagates_exceptions() -> None:
    def boom() -> Iterator[int]:
        yield 1
        raise RuntimeError("fail")

    with progress(["a"], mode="silent") as h:
        gen = h.wrap("a", boom())
        assert next(gen) == 1
        try:
            next(gen)
        except RuntimeError as e:
            assert str(e) == "fail"
        else:
            raise AssertionError("expected RuntimeError")


def test_plain_writes_start_and_finish_lines(capsys: pytest.CaptureFixture[str]) -> None:
    with progress(["customers"], mode="plain") as h:
        out = list(h.wrap("customers", iter([{"x": 1}, {"x": 2}, {"x": 3}])))
    assert out == [{"x": 1}, {"x": 2}, {"x": 3}]
    captured = capsys.readouterr()
    text = captured.out + captured.err
    assert "customers: started" in text
    assert "customers: 3 rows" in text


def test_plain_writes_failure_line_on_exception(capsys: pytest.CaptureFixture[str]) -> None:
    def boom() -> Iterator[dict[str, int]]:
        yield {"x": 1}
        raise RuntimeError("boom")

    with pytest.raises(RuntimeError, match="boom"), progress(["orders"], mode="plain") as h:
        list(h.wrap("orders", boom()))
    captured = capsys.readouterr()
    text = captured.out + captured.err
    assert "orders: started" in text
    assert "orders: FAILED after 1 rows" in text


def test_plain_does_not_emit_per_record_lines(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """Sanity: plain mode is start/finish only, no per-tick output."""
    with progress(["x"], mode="plain") as h:
        list(h.wrap("x", iter(range(50))))
    captured = capsys.readouterr()
    text = captured.out + captured.err
    started = text.count("x: started")
    finished = text.count("x: 50 rows")
    assert started == 1
    assert finished == 1


def test_rich_wrap_yields_all_items() -> None:
    items = list(range(20))
    with progress(["x"], mode="rich") as h:
        out = list(h.wrap("x", iter(items)))
    assert out == items


def test_rich_with_total_mapping_yields_all_items() -> None:
    items = list(range(7))
    with progress({"x": len(items)}, mode="rich") as h:
        out = list(h.wrap("x", iter(items)))
    assert out == items


def test_rich_propagates_exceptions() -> None:
    def boom() -> Iterator[int]:
        yield 1
        raise RuntimeError("nope")

    with pytest.raises(RuntimeError, match="nope"), progress(["a"], mode="rich") as h:
        list(h.wrap("a", boom()))
