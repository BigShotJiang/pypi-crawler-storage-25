from pathlib import Path

import yaml

from das_cli.contracts.loader import LoadedContract, load_contract
from das_cli.contracts.odcs import (
    CustomProperty,
    OdcsContract,
    OdcsInfo,
    OdcsProperty,
    OdcsSchema,
)
from das_cli.contracts.writer import write_contract


def _make() -> LoadedContract:
    contract = OdcsContract(
        apiVersion="v3.0.0",
        kind="DataContract",
        id="x.y",
        name="Y",
        version="0.1.0",
        status="draft",
        info=OdcsInfo(title="Y"),
        schema=[
            OdcsSchema(
                name="y",
                physicalName="y",
                physicalType="table",
                properties=[
                    OdcsProperty(
                        name="a",
                        physicalName="A",
                        logicalType="integer",
                        primaryKey=True,
                        required=True,
                    ),
                ],
            )
        ],
        customProperties=[CustomProperty(property="das.cursor", value="modified_at")],
    )
    return LoadedContract(path=Path("y.odcs.yaml"), resource_name="y", contract=contract)


def test_writes_yaml_round_trippable(tmp_path: Path) -> None:
    loaded = _make()
    out = tmp_path / "y.odcs.yaml"
    write_contract(loaded, out)
    assert out.is_file()

    re_loaded = load_contract(out)
    assert re_loaded.contract.id == "x.y"
    assert re_loaded.contract.primary_schema.properties[0].name == "a"
    assert re_loaded.contract.custom_properties[0].property == "das.cursor"


def test_writes_block_style_not_flow(tmp_path: Path) -> None:
    loaded = _make()
    out = tmp_path / "y.odcs.yaml"
    write_contract(loaded, out)
    text = out.read_text()
    # Block style: no `{name: ...}` flow style.
    assert "{name:" not in text
    assert "name: a" in text


def test_uses_schema_alias_not_schema_(tmp_path: Path) -> None:
    loaded = _make()
    out = tmp_path / "y.odcs.yaml"
    write_contract(loaded, out)
    raw = yaml.safe_load(out.read_text())
    assert "schema" in raw
    assert "schema_" not in raw


def test_uses_customProperties_alias(tmp_path: Path) -> None:  # noqa: N802
    loaded = _make()
    out = tmp_path / "y.odcs.yaml"
    write_contract(loaded, out)
    raw = yaml.safe_load(out.read_text())
    assert "customProperties" in raw
    assert "custom_properties" not in raw
