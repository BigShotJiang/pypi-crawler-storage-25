"""CLI: das source add --type filesystem. See ADR-0022."""

from __future__ import annotations

from pathlib import Path

import pytest
from typer.testing import CliRunner

from das_cli.cli import app


def test_source_add_filesystem_writes_source_yml(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    runner = CliRunner()
    result = runner.invoke(
        app, ["source", "add", "files", "--type", "filesystem", "--url", "./data/"]
    )
    assert result.exit_code == 0, result.stdout
    src_yml = (tmp_path / "contracts" / "files" / "_source.yml").read_text()
    assert "type: filesystem" in src_yml
    assert "endpoint: ./data/" in src_yml
    assert "spec:\n  kind: filesystem" in src_yml
    assert "auth:\n  type: none" in src_yml


def test_source_add_filesystem_rejects_auth_basic(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    runner = CliRunner()
    result = runner.invoke(
        app,
        [
            "source",
            "add",
            "files",
            "--type",
            "filesystem",
            "--url",
            "./data/",
            "--auth",
            "basic",
        ],
    )
    # Filesystem credentials flow through dlt's filesystem config, not the
    # auth block — basic/bearer/api_key on --auth are nonsense. The
    # rejection message goes to stderr (via die()); CliRunner's `output`
    # captures both streams by default.
    assert result.exit_code != 0
    assert "auth" in result.output.lower()
    assert not (tmp_path / "contracts" / "files").exists()
