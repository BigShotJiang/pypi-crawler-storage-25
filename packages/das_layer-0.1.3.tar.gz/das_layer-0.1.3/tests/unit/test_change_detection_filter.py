from __future__ import annotations

from typing import Any

from das_cli.pipelines.change_detection import ChangeDetectionFilter


def make_row(pk: int, hash_val: str, **extra: Any) -> dict[str, Any]:
    return {"id": pk, "_row_hash": hash_val, **extra}


def test_first_load_emits_all() -> None:
    f = ChangeDetectionFilter(primary_key=["id"], latest_hash={})
    rows = [make_row(1, "h1"), make_row(2, "h2")]
    out = list(f(rows))
    assert len(out) == 2


def test_repeated_same_hash_suppressed() -> None:
    f = ChangeDetectionFilter(primary_key=["id"], latest_hash={(1,): "h1"})
    rows = [make_row(1, "h1")]
    out = list(f(rows))
    assert out == []


def test_changed_hash_emitted() -> None:
    f = ChangeDetectionFilter(primary_key=["id"], latest_hash={(1,): "h1"})
    rows = [make_row(1, "h2")]
    out = list(f(rows))
    assert len(out) == 1


def test_a_b_a_round_trip_preserved() -> None:
    """Each transition must produce a row even if it cycles."""
    f = ChangeDetectionFilter(primary_key=["id"], latest_hash={})
    rows = [
        make_row(1, "hA", name="A"),
        make_row(1, "hB", name="B"),
        make_row(1, "hA", name="A"),
    ]
    out = list(f(rows))
    assert [r["name"] for r in out] == ["A", "B", "A"]


def test_composite_primary_key() -> None:
    f = ChangeDetectionFilter(primary_key=["a", "b"], latest_hash={(1, "x"): "h1"})
    rows = [
        {"a": 1, "b": "x", "_row_hash": "h1"},  # unchanged
        {"a": 1, "b": "y", "_row_hash": "h1"},  # different PK
    ]
    out = list(f(rows))
    assert len(out) == 1
    assert out[0]["b"] == "y"


def test_state_updates_in_place() -> None:
    f = ChangeDetectionFilter(primary_key=["id"], latest_hash={})
    list(f([make_row(1, "h1")]))
    list(f([make_row(1, "h1")]))  # second call: should suppress
    rows = list(f([make_row(1, "h2")]))
    assert len(rows) == 1
