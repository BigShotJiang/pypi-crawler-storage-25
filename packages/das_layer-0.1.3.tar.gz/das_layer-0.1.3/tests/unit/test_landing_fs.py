"""Unit tests for the fsspec-backed landing reader."""

from __future__ import annotations

import gzip
from pathlib import Path

import pytest
from fsspec.implementations.local import LocalFileSystem

from das_cli.dlt_glue.landing_fs import (
    count_landing_records,
    iter_landing_records,
    landing_fs,
)
from das_cli.models.das_yaml import LandingConfig


def _local_landing(tmp_path: Path) -> LandingConfig:
    return LandingConfig(bucket_url=str(tmp_path), credentials={})


def test_landing_fs_local_returns_localfs(tmp_path: Path) -> None:
    fs, root = landing_fs(_local_landing(tmp_path))
    assert isinstance(fs, LocalFileSystem)
    assert Path(root) == tmp_path.resolve()


def test_landing_fs_azure_returns_adlfs() -> None:
    # adlfs's AzureBlobFileSystem constructor does not perform a network call.
    pytest.importorskip("adlfs")
    from adlfs import AzureBlobFileSystem

    landing = LandingConfig(
        bucket_url="abfss://lake@acct.dfs.core.windows.net/landing",
        credentials={"auth": "default"},
    )
    fs, _root = landing_fs(landing)
    assert isinstance(fs, AzureBlobFileSystem)


def test_count_plain_jsonl(tmp_path: Path) -> None:
    rdir = tmp_path / "src1" / "products"
    rdir.mkdir(parents=True)
    (rdir / "a.jsonl").write_text('{"x":1}\n{"x":2}\n{"x":3}\n')
    assert count_landing_records(_local_landing(tmp_path), source="src1", resource="products") == 3


def test_count_gzipped_jsonl(tmp_path: Path) -> None:
    rdir = tmp_path / "src1" / "orders"
    rdir.mkdir(parents=True)
    with gzip.open(rdir / "a.jsonl.gz", "wt") as fh:
        fh.write('{"x":1}\n{"x":2}\n')
    assert count_landing_records(_local_landing(tmp_path), source="src1", resource="orders") == 2


def test_count_across_multiple_files(tmp_path: Path) -> None:
    rdir = tmp_path / "src1" / "customers"
    rdir.mkdir(parents=True)
    (rdir / "a.jsonl").write_text('{"x":1}\n{"x":2}\n')
    with gzip.open(rdir / "b.jsonl.gz", "wt") as fh:
        fh.write('{"x":3}\n')
    assert count_landing_records(_local_landing(tmp_path), source="src1", resource="customers") == 3


def test_count_skips_blank_lines(tmp_path: Path) -> None:
    rdir = tmp_path / "src1" / "x"
    rdir.mkdir(parents=True)
    (rdir / "a.jsonl").write_text('{"x":1}\n\n{"x":2}\n\n')
    assert count_landing_records(_local_landing(tmp_path), source="src1", resource="x") == 2


def test_count_zero_for_missing_resource(tmp_path: Path) -> None:
    assert count_landing_records(_local_landing(tmp_path), source="src1", resource="nope") == 0


def test_count_zero_for_empty_resource(tmp_path: Path) -> None:
    (tmp_path / "src1" / "empty").mkdir(parents=True)
    assert count_landing_records(_local_landing(tmp_path), source="src1", resource="empty") == 0


def test_iter_records_yields_dicts(tmp_path: Path) -> None:
    rdir = tmp_path / "src1" / "t"
    rdir.mkdir(parents=True)
    (rdir / "a.jsonl").write_text('{"x":1}\n{"x":2}\n')
    rows = list(iter_landing_records(_local_landing(tmp_path), source="src1", resource="t"))
    assert rows == [{"x": 1}, {"x": 2}]


def test_iter_records_handles_partitioned_layout(tmp_path: Path) -> None:
    # Mirrors ADR-0013: bucket_url/<source>/<table>/_extracted_on=YYYY-MM-DD/<file>
    rdir = tmp_path / "src1" / "products" / "_extracted_on=2026-05-12"
    rdir.mkdir(parents=True)
    (rdir / "1.0.jsonl").write_text('{"id":1}\n')
    rows = list(iter_landing_records(_local_landing(tmp_path), source="src1", resource="products"))
    assert rows == [{"id": 1}]
