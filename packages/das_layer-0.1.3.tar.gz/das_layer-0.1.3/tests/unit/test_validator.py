from pathlib import Path

from das_cli.contracts.validator import (
    ValidationIssue,
    validate_workspace,
)

_FS_SOURCE_YML = (
    "type: filesystem\n" "endpoint: ./data/\n" "spec:\n  kind: filesystem\n" "auth:\n  type: none\n"
)

DAS_YAML = """\
target:
  destination: duckdb
  credentials: { database: ./das.duckdb }
landing:
  bucket_url: ./landing
  credentials: {}
contracts: { root: ./contracts }
dataset: {}
defaults:
  write_disposition: append
  change_detection: row_hash
  schema_contract: { tables: freeze, columns: freeze, data_type: freeze }
"""

SOURCE_YML = """\
type: odata
endpoint: https://example.com/odata/v1
spec:
  kind: odata
  metadata_url: https://example.com/odata/v1/$metadata
auth: { type: none }
"""

PRODUCTS = """\
apiVersion: v3.0.0
kind: DataContract
id: adventureworks.products
name: Products
version: 0.1.0
status: draft
info: { title: Products, owner: data-platform }
schema:
  - name: products
    physicalName: products
    physicalType: table
    properties:
      - { name: product_id, physicalName: ProductId, logicalType: integer,
          physicalType: bigint, required: true, primaryKey: true }
      - { name: name, physicalName: Name, logicalType: string, required: true }
      - { name: modified_at, physicalName: ModifiedDate, logicalType: timestamp }
customProperties:
  - { property: das.cursor, value: modified_at }
"""


def _make_workspace(
    tmp: Path, das_yaml: str = DAS_YAML, source_yml: str = SOURCE_YML, products: str = PRODUCTS
) -> None:
    (tmp / "das.yaml").write_text(das_yaml)
    src = tmp / "contracts" / "adventureworks"
    src.mkdir(parents=True)
    (src / "_source.yml").write_text(source_yml)
    (src / "products.odcs.yaml").write_text(products)


def test_clean_workspace_validates(tmp_path: Path) -> None:
    _make_workspace(tmp_path)
    issues = validate_workspace(tmp_path / "das.yaml")
    assert issues == []


def test_missing_das_yaml(tmp_path: Path) -> None:
    issues = validate_workspace(tmp_path / "das.yaml")
    assert any("das.yaml" in i.message for i in issues)


def test_unknown_das_key_fails(tmp_path: Path) -> None:
    bad = PRODUCTS.replace(
        "{ property: das.cursor, value: modified_at }",
        "{ property: das.unknown, value: x }",
    )
    _make_workspace(tmp_path, products=bad)
    issues = validate_workspace(tmp_path / "das.yaml")
    assert any("das.unknown" in i.message for i in issues)


def test_cursor_must_name_existing_column(tmp_path: Path) -> None:
    bad = PRODUCTS.replace("value: modified_at", "value: nonexistent")
    _make_workspace(tmp_path, products=bad)
    issues = validate_workspace(tmp_path / "das.yaml")
    assert any("cursor" in i.message and "nonexistent" in i.message for i in issues)


def test_row_hash_change_detection_requires_pk(tmp_path: Path) -> None:
    no_pk = PRODUCTS.replace(", primaryKey: true", "")
    _make_workspace(tmp_path, products=no_pk)
    issues = validate_workspace(tmp_path / "das.yaml")
    assert any("primary key" in i.message.lower() for i in issues)


def test_duplicate_property_names_fail(tmp_path: Path) -> None:
    dup = PRODUCTS.replace(
        "{ name: name, physicalName: Name, logicalType: string, required: true }",
        "{ name: product_id, physicalName: Name, logicalType: string, required: true }",
    )
    _make_workspace(tmp_path, products=dup)
    issues = validate_workspace(tmp_path / "das.yaml")
    assert any("duplicate" in i.message.lower() for i in issues)


def test_missing_source_yml_in_dir(tmp_path: Path) -> None:
    _make_workspace(tmp_path)
    (tmp_path / "contracts" / "adventureworks" / "_source.yml").unlink()
    issues = validate_workspace(tmp_path / "das.yaml")
    assert any("_source.yml" in i.message for i in issues)


def test_validation_issue_has_path() -> None:
    issue = ValidationIssue(path="x.yaml", message="bad")
    assert issue.path == "x.yaml"


SOURCE_YML_OPENAPI = """\
type: openapi
endpoint: https://example.com/api/v1
spec:
  kind: openapi
  swagger_url: https://example.com/api/v1/swagger.json
auth: { type: none }
"""

SOURCE_YML_SQL = """\
type: sql
endpoint: postgres://user:pw@host/db
auth: { type: none }
"""

CUSTOMERS_WITH_ENDPOINT = """\
apiVersion: v3.0.0
kind: DataContract
id: northwind.customers
name: Customers
version: 0.1.0
status: draft
info: { title: Customers, owner: data-platform }
schema:
  - name: customers
    physicalName: customers
    physicalType: table
    properties:
      - { name: id, logicalType: integer, required: true, primaryKey: true }
customProperties:
  - property: das.endpoint
    value:
      path: /Customers
      response_path: $.value
"""

CUSTOMERS_BAD_ENDPOINT = """\
apiVersion: v3.0.0
kind: DataContract
id: northwind.customers
name: Customers
version: 0.1.0
status: draft
info: { title: Customers, owner: data-platform }
schema:
  - name: customers
    physicalName: customers
    physicalType: table
    properties:
      - { name: id, logicalType: integer, required: true, primaryKey: true }
customProperties:
  - property: das.endpoint
    value:
      path: Customers
"""


def test_valid_endpoint_passes(tmp_path: Path) -> None:
    (tmp_path / "das.yaml").write_text(DAS_YAML)
    src = tmp_path / "contracts" / "northwind"
    src.mkdir(parents=True)
    (src / "_source.yml").write_text(SOURCE_YML_OPENAPI)
    (src / "customers.odcs.yaml").write_text(CUSTOMERS_WITH_ENDPOINT)
    issues = validate_workspace(tmp_path / "das.yaml")
    assert issues == []


def test_malformed_endpoint_path_reported(tmp_path: Path) -> None:
    (tmp_path / "das.yaml").write_text(DAS_YAML)
    src = tmp_path / "contracts" / "northwind"
    src.mkdir(parents=True)
    (src / "_source.yml").write_text(SOURCE_YML_OPENAPI)
    (src / "customers.odcs.yaml").write_text(CUSTOMERS_BAD_ENDPOINT)
    issues = validate_workspace(tmp_path / "das.yaml")
    assert any("das.endpoint" in i.message for i in issues)


def test_endpoint_rejected_on_sql_source(tmp_path: Path) -> None:
    (tmp_path / "das.yaml").write_text(DAS_YAML)
    src = tmp_path / "contracts" / "warehouse"
    src.mkdir(parents=True)
    (src / "_source.yml").write_text(SOURCE_YML_SQL)
    (src / "customers.odcs.yaml").write_text(CUSTOMERS_WITH_ENDPOINT)
    issues = validate_workspace(tmp_path / "das.yaml")
    assert any("das.endpoint" in i.message and "sql" in i.message.lower() for i in issues)


def test_filesystem_spec_ref_required(tmp_path: Path) -> None:
    """A filesystem-typed source whose contract is missing das.spec_ref fails."""
    _seed_workspace(
        tmp_path,
        source_name="files",
        source_yml=_FS_SOURCE_YML,
        contract_yaml=_contract_yaml_no_spec_ref(),
    )
    issues = validate_workspace(tmp_path / "das.yaml")
    assert any("das.spec_ref is required for type=filesystem" in i.message for i in issues)


def test_filesystem_spec_ref_format_dispatch(tmp_path: Path) -> None:
    """A filesystem contract with format=excel but no sheet fails validation."""
    contract = _contract_yaml_with_spec_ref(
        {"kind": "filesystem", "format": "excel", "path": "wb.xlsx"}
    )
    _seed_workspace(
        tmp_path,
        source_name="files",
        source_yml=_FS_SOURCE_YML,
        contract_yaml=contract,
    )
    issues = validate_workspace(tmp_path / "das.yaml")
    assert any("sheet is required for format=excel" in i.message for i in issues)


def test_filesystem_inject_column_must_exist(tmp_path: Path) -> None:
    """inject.<col> must reference a column declared in the schema."""
    contract = _contract_yaml_with_spec_ref(
        {
            "kind": "filesystem",
            "format": "csv",
            "path": "*.csv",
            "inject": {"undeclared_col": "basename"},
        }
    )
    _seed_workspace(
        tmp_path,
        source_name="files",
        source_yml=_FS_SOURCE_YML,
        contract_yaml=contract,
    )
    issues = validate_workspace(tmp_path / "das.yaml")
    assert any("inject column 'undeclared_col' is not in the schema" in i.message for i in issues)


def test_filesystem_inject_with_declared_column_passes(tmp_path: Path) -> None:
    """When the inject target column is in the schema, no issue is raised."""
    contract = _contract_yaml_with_spec_ref(
        {
            "kind": "filesystem",
            "format": "csv",
            "path": "*.csv",
            "inject": {"source_file": "basename"},
        },
        extra_property={"name": "source_file", "logicalType": "string"},
    )
    _seed_workspace(
        tmp_path,
        source_name="files",
        source_yml=_FS_SOURCE_YML,
        contract_yaml=contract,
    )
    issues = validate_workspace(tmp_path / "das.yaml")
    assert not any("inject" in i.message for i in issues)


def _seed_workspace(root: Path, *, source_name: str, source_yml: str, contract_yaml: str) -> None:
    (root / "das.yaml").write_text(
        "target:\n  destination: duckdb\n  credentials: {database: ./das.duckdb}\n"
        "contracts:\n  root: contracts\n"
        "landing:\n  bucket_url: ./landing\n"
        "defaults:\n  change_detection: row_hash\n"
    )
    src_dir = root / "contracts" / source_name
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(source_yml)
    (src_dir / "customers.odcs.yaml").write_text(contract_yaml)


def _contract_yaml_no_spec_ref() -> str:
    return (
        "apiVersion: v3.0.0\n"
        "kind: DataContract\n"
        "id: files.customers\n"
        "name: customers\n"
        "version: 0.1.0\n"
        "status: draft\n"
        "info:\n  title: customers\n"
        "schema:\n"
        "  - name: customers\n"
        "    physicalName: customers\n"
        "    physicalType: table\n"
        "    properties:\n"
        "      - name: id\n"
        "        logicalType: integer\n"
        "        primaryKey: true\n"
        "        required: true\n"
    )


def _contract_yaml_with_spec_ref(
    spec_ref: dict[str, object],
    *,
    extra_property: dict[str, object] | None = None,
) -> str:
    import yaml

    props = [{"name": "id", "logicalType": "integer", "primaryKey": True, "required": True}]
    if extra_property is not None:
        props.append(extra_property)

    doc = {
        "apiVersion": "v3.0.0",
        "kind": "DataContract",
        "id": "files.customers",
        "name": "customers",
        "version": "0.1.0",
        "status": "draft",
        "info": {"title": "customers"},
        "schema": [
            {
                "name": "customers",
                "physicalName": "customers",
                "physicalType": "table",
                "properties": props,
            }
        ],
        "customProperties": [{"property": "das.spec_ref", "value": spec_ref}],
    }
    return yaml.safe_dump(doc, sort_keys=False)
