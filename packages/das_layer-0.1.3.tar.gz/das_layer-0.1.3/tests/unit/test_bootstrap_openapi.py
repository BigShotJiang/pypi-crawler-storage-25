import json
from pathlib import Path
from typing import Any

import pytest

from das_cli.bootstrap.openapi import bootstrap_openapi_contracts
from das_cli.contracts.loader import LoadedContract


@pytest.fixture
def sample_doc(fixtures_dir: Path) -> dict[str, Any]:
    return json.loads((fixtures_dir / "sample_openapi.json").read_text())  # type: ignore[no-any-return]


def _by_name(contracts: list[LoadedContract], resource_name: str) -> LoadedContract:
    return next(c for c in contracts if c.resource_name == resource_name)


def test_emits_one_contract_per_schema(sample_doc: dict[str, Any]) -> None:
    contracts = bootstrap_openapi_contracts(sample_doc, source_name="northwind")
    names = sorted(c.resource_name for c in contracts)
    assert names == ["customers", "orders", "regions"]


def test_property_names_snake_cased(sample_doc: dict[str, Any]) -> None:
    contracts = bootstrap_openapi_contracts(sample_doc, source_name="northwind")
    cust = _by_name(contracts, "customers")
    names = [p.name for p in cust.contract.primary_schema.properties]
    assert names == ["customer_id", "company_name", "credit_limit", "modified_at"]


def test_required_fields_marked(sample_doc: dict[str, Any]) -> None:
    contracts = bootstrap_openapi_contracts(sample_doc, source_name="northwind")
    cust = _by_name(contracts, "customers")
    by_name = {p.name: p for p in cust.contract.primary_schema.properties}
    assert by_name["customer_id"].required is True
    assert by_name["company_name"].required is True
    assert by_name["credit_limit"].required is False


def test_id_field_inferred_as_pk(sample_doc: dict[str, Any]) -> None:
    contracts = bootstrap_openapi_contracts(sample_doc, source_name="northwind")
    cust = _by_name(contracts, "customers")
    by_name = {p.name: p for p in cust.contract.primary_schema.properties}
    assert by_name["customer_id"].primaryKey is True


def test_date_time_format_to_timestamp(sample_doc: dict[str, Any]) -> None:
    contracts = bootstrap_openapi_contracts(sample_doc, source_name="northwind")
    cust = _by_name(contracts, "customers")
    by_name = {p.name: p for p in cust.contract.primary_schema.properties}
    assert by_name["modified_at"].logicalType == "timestamp"


def test_spec_ref_points_to_schema(sample_doc: dict[str, Any]) -> None:
    contracts = bootstrap_openapi_contracts(sample_doc, source_name="northwind")
    cust = _by_name(contracts, "customers")
    spec = next(p for p in cust.contract.custom_properties if p.property == "das.spec_ref")
    assert spec.value == {"kind": "openapi", "path": "#/components/schemas/Customer"}


def test_cursor_heuristic(sample_doc: dict[str, Any]) -> None:
    contracts = bootstrap_openapi_contracts(sample_doc, source_name="northwind")
    cust = _by_name(contracts, "customers")
    cursor = next((p for p in cust.contract.custom_properties if p.property == "das.cursor"), None)
    assert cursor is not None
    assert cursor.value == "modified_at"


def test_emits_endpoint_for_unambiguous_bare_array(sample_doc: dict[str, Any]) -> None:
    contracts = bootstrap_openapi_contracts(sample_doc, source_name="northwind")
    cust = _by_name(contracts, "customers")
    ep = next(
        (p for p in cust.contract.custom_properties if p.property == "das.endpoint"),
        None,
    )
    assert ep is not None
    assert ep.value == {"path": "/Customers", "response_path": None}


def test_no_endpoint_for_ambiguous_schema(sample_doc: dict[str, Any]) -> None:
    contracts = bootstrap_openapi_contracts(sample_doc, source_name="northwind")
    orders = _by_name(contracts, "orders")
    ep = next(
        (p for p in orders.contract.custom_properties if p.property == "das.endpoint"),
        None,
    )
    assert ep is None


def test_no_endpoint_for_zero_path_schema(sample_doc: dict[str, Any]) -> None:
    contracts = bootstrap_openapi_contracts(sample_doc, source_name="northwind")
    regions = _by_name(contracts, "regions")
    ep = next(
        (p for p in regions.contract.custom_properties if p.property == "das.endpoint"),
        None,
    )
    assert ep is None


def test_emits_endpoint_for_unambiguous_wrapper_object() -> None:
    """Schema referenced by exactly one path returning {value: [Item]}."""
    doc = {
        "openapi": "3.0.0",
        "info": {"title": "x", "version": "1"},
        "paths": {
            "/Items": {
                "get": {
                    "responses": {
                        "200": {
                            "description": "ok",
                            "content": {
                                "application/json": {
                                    "schema": {
                                        "type": "object",
                                        "properties": {
                                            "value": {
                                                "type": "array",
                                                "items": {"$ref": "#/components/schemas/Item"},
                                            }
                                        },
                                    }
                                }
                            },
                        }
                    }
                }
            }
        },
        "components": {
            "schemas": {
                "Item": {
                    "type": "object",
                    "required": ["id"],
                    "properties": {"id": {"type": "string"}},
                }
            }
        },
    }
    contracts = bootstrap_openapi_contracts(doc, source_name="x")
    item = _by_name(contracts, "items")
    ep = next(p for p in item.contract.custom_properties if p.property == "das.endpoint")
    assert ep.value == {"path": "/Items", "response_path": "$.value"}


def test_source_endpoint_prefix_stripped_from_paths() -> None:
    """When _source.yml.endpoint has a path component (e.g. /northwind/api/v1)
    and the spec bakes that prefix into its paths, bootstrap strips it so the
    emitted das.endpoint.path concatenates cleanly with the source endpoint."""
    doc = {
        "openapi": "3.0.0",
        "info": {"title": "x", "version": "1"},
        "paths": {
            "/northwind/api/v1/Customers": {
                "get": {
                    "responses": {
                        "200": {
                            "description": "ok",
                            "content": {
                                "application/json": {
                                    "schema": {
                                        "type": "array",
                                        "items": {"$ref": "#/components/schemas/Customer"},
                                    }
                                }
                            },
                        }
                    }
                }
            }
        },
        "components": {
            "schemas": {
                "Customer": {
                    "type": "object",
                    "required": ["id"],
                    "properties": {"id": {"type": "string"}},
                }
            }
        },
    }
    contracts = bootstrap_openapi_contracts(
        doc,
        source_name="northwind",
        source_endpoint="https://example.com/northwind/api/v1",
    )
    cust = _by_name(contracts, "customers")
    ep = next(p for p in cust.contract.custom_properties if p.property == "das.endpoint")
    assert ep.value == {"path": "/Customers", "response_path": None}


def test_data_wrapper_recognised() -> None:
    doc = {
        "openapi": "3.0.0",
        "info": {"title": "x", "version": "1"},
        "paths": {
            "/Items": {
                "get": {
                    "responses": {
                        "200": {
                            "description": "ok",
                            "content": {
                                "application/json": {
                                    "schema": {
                                        "type": "object",
                                        "properties": {
                                            "data": {
                                                "type": "array",
                                                "items": {"$ref": "#/components/schemas/Item"},
                                            }
                                        },
                                    }
                                }
                            },
                        }
                    }
                }
            }
        },
        "components": {
            "schemas": {
                "Item": {
                    "type": "object",
                    "required": ["id"],
                    "properties": {"id": {"type": "string"}},
                }
            }
        },
    }
    contracts = bootstrap_openapi_contracts(doc, source_name="x")
    item = _by_name(contracts, "items")
    ep = next(p for p in item.contract.custom_properties if p.property == "das.endpoint")
    assert ep.value == {"path": "/Items", "response_path": "$.data"}
