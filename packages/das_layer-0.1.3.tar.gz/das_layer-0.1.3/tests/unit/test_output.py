import pytest

from das_cli.exit_codes import VALIDATION_FAILURE
from das_cli.output import die, header, info, success, warn


def test_header_prints_to_stdout(capsys: pytest.CaptureFixture[str]) -> None:
    header("extract", "adventureworks")
    out = capsys.readouterr().out
    assert "extract" in out
    assert "adventureworks" in out


def test_info_prints_to_stdout(capsys: pytest.CaptureFixture[str]) -> None:
    info("hello")
    assert "hello" in capsys.readouterr().out


def test_warn_prints_to_stderr(capsys: pytest.CaptureFixture[str]) -> None:
    warn("careful")
    assert "careful" in capsys.readouterr().err


def test_die_raises_typer_exit_with_code() -> None:
    import typer

    with pytest.raises(typer.Exit) as exc:
        die("nope", code=VALIDATION_FAILURE)
    assert exc.value.exit_code == VALIDATION_FAILURE


def test_success_prints(capsys: pytest.CaptureFixture[str]) -> None:
    success("done")
    assert "done" in capsys.readouterr().out
