import re

from typer.testing import CliRunner

from das_cli.cli import app

runner = CliRunner()


def test_version_flag_prints_version() -> None:
    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    version_str = result.stdout.strip()
    assert re.match(
        r"^\d+\.\d+(\.\d+)?", version_str
    ), f"Expected PEP 440-style version, got: {version_str!r}"
    assert "unknown" not in version_str, (
        f"das --version reports the PackageNotFoundError fallback "
        f"({version_str!r}) — the package is not installed in this environment."
    )


def test_help_flag_lists_commands() -> None:
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "Usage:" in result.stdout
