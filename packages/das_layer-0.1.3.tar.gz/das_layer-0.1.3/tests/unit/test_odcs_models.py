from typing import Any

import pytest
from pydantic import ValidationError

from das_cli.contracts.odcs import OdcsContract

VALID: dict[str, Any] = {
    "apiVersion": "v3.0.0",
    "kind": "DataContract",
    "id": "adventureworks.products",
    "name": "Products",
    "version": "0.1.0",
    "status": "draft",
    "info": {"title": "Products", "owner": "data-platform"},
    "schema": [
        {
            "name": "products",
            "physicalName": "products",
            "physicalType": "table",
            "properties": [
                {
                    "name": "product_id",
                    "physicalName": "ProductId",
                    "logicalType": "integer",
                    "physicalType": "bigint",
                    "required": True,
                    "primaryKey": True,
                },
                {
                    "name": "name",
                    "physicalName": "Name",
                    "logicalType": "string",
                    "required": True,
                },
            ],
        }
    ],
    "customProperties": [
        {"property": "das.spec_ref", "value": {"kind": "odata", "type": "Product"}},
        {"property": "das.cursor", "value": "modified_at"},
    ],
}


def test_valid_contract_parses() -> None:
    c = OdcsContract.model_validate(VALID)
    assert c.id == "adventureworks.products"
    assert c.schema_[0].properties[0].primaryKey is True
    assert c.custom_properties[0].property == "das.spec_ref"


def test_apiversion_must_be_v3() -> None:
    payload = {**VALID, "apiVersion": "v2.0.0"}
    with pytest.raises(ValidationError):
        OdcsContract.model_validate(payload)


def test_kind_must_be_data_contract() -> None:
    payload = {**VALID, "kind": "Other"}
    with pytest.raises(ValidationError):
        OdcsContract.model_validate(payload)


def test_logical_type_validated() -> None:
    bad = {
        **VALID,
        "schema": [
            {
                **VALID["schema"][0],
                "properties": [{**VALID["schema"][0]["properties"][0], "logicalType": "weird"}],
            }
        ],
    }
    with pytest.raises(ValidationError):
        OdcsContract.model_validate(bad)


def test_status_validated() -> None:
    payload = {**VALID, "status": "weird"}
    with pytest.raises(ValidationError):
        OdcsContract.model_validate(payload)


def test_at_least_one_schema_required() -> None:
    payload = {**VALID, "schema": []}
    with pytest.raises(ValidationError):
        OdcsContract.model_validate(payload)
