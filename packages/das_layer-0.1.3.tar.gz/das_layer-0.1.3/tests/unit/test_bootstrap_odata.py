from pathlib import Path

import pytest

from das_cli.bootstrap.odata import bootstrap_odata_contracts
from das_cli.contracts.loader import LoadedContract


@pytest.fixture
def sample_xml(fixtures_dir: Path) -> str:
    return (fixtures_dir / "sample_odata_metadata.xml").read_text()


def test_emits_one_contract_per_entity_set_when_container_present(sample_xml: str) -> None:
    """The fixture's EntityContainer declares two EntitySets (Products, Departments);
    both EntityTypes are referenced so two contracts emit. See ADR-0025."""
    contracts = bootstrap_odata_contracts(sample_xml, source_name="adventureworks")
    names = sorted(c.contract.id for c in contracts)
    assert names == ["adventureworks.departments", "adventureworks.products"]


def test_property_names_snake_cased(sample_xml: str) -> None:
    contracts = bootstrap_odata_contracts(sample_xml, source_name="adventureworks")
    products = next(c for c in contracts if c.resource_name == "products")
    names = [p.name for p in products.contract.primary_schema.properties]
    assert names == ["product_id", "name", "list_price", "modified_date"]


def test_physical_names_preserved(sample_xml: str) -> None:
    contracts = bootstrap_odata_contracts(sample_xml, source_name="adventureworks")
    products = next(c for c in contracts if c.resource_name == "products")
    physical = [p.physicalName for p in products.contract.primary_schema.properties]
    assert physical == ["ProductId", "Name", "ListPrice", "ModifiedDate"]


def test_decimal_with_precision_scale(sample_xml: str) -> None:
    contracts = bootstrap_odata_contracts(sample_xml, source_name="adventureworks")
    products = next(c for c in contracts if c.resource_name == "products")
    list_price = next(
        p for p in products.contract.primary_schema.properties if p.name == "list_price"
    )
    assert list_price.logicalType == "number"
    assert list_price.physicalType == "decimal(19,4)"


def test_int32_maps_to_integer(sample_xml: str) -> None:
    contracts = bootstrap_odata_contracts(sample_xml, source_name="adventureworks")
    products = next(c for c in contracts if c.resource_name == "products")
    pid = next(p for p in products.contract.primary_schema.properties if p.name == "product_id")
    assert pid.logicalType == "integer"
    assert pid.primaryKey is True
    assert pid.required is True


def test_datetime_offset_to_timestamp(sample_xml: str) -> None:
    contracts = bootstrap_odata_contracts(sample_xml, source_name="adventureworks")
    products = next(c for c in contracts if c.resource_name == "products")
    md = next(p for p in products.contract.primary_schema.properties if p.name == "modified_date")
    assert md.logicalType == "timestamp"


def test_cursor_heuristic_picks_modified_date(sample_xml: str) -> None:
    contracts = bootstrap_odata_contracts(sample_xml, source_name="adventureworks")
    products = next(c for c in contracts if c.resource_name == "products")
    cursor_prop = next(p for p in products.contract.custom_properties if p.property == "das.cursor")
    assert cursor_prop.value == "modified_date"


def test_spec_ref_added(sample_xml: str) -> None:
    contracts = bootstrap_odata_contracts(sample_xml, source_name="adventureworks")
    products = next(c for c in contracts if c.resource_name == "products")
    spec = next(p for p in products.contract.custom_properties if p.property == "das.spec_ref")
    assert spec.value == {"kind": "odata", "type": "Product", "entity_set": "Products"}


def test_no_cursor_when_no_modified_date(sample_xml: str) -> None:
    contracts = bootstrap_odata_contracts(sample_xml, source_name="adventureworks")
    dept = next(c for c in contracts if c.resource_name == "departments")
    cursor_props = [p for p in dept.contract.custom_properties if p.property == "das.cursor"]
    assert cursor_props == []


def test_entity_set_added_when_container_present(sample_xml: str) -> None:
    """The fixture's EntityContainer declares Products and Departments — both
    should land on das.spec_ref.entity_set."""
    contracts = bootstrap_odata_contracts(sample_xml, source_name="adventureworks")
    products = next(c for c in contracts if c.resource_name == "products")
    departments = next(c for c in contracts if c.resource_name == "departments")

    prod_spec = next(p for p in products.contract.custom_properties if p.property == "das.spec_ref")
    dept_spec = next(
        p for p in departments.contract.custom_properties if p.property == "das.spec_ref"
    )

    assert prod_spec.value == {"kind": "odata", "type": "Product", "entity_set": "Products"}
    assert dept_spec.value == {
        "kind": "odata",
        "type": "Department",
        "entity_set": "Departments",
    }


def test_entity_set_strips_namespace_from_entity_type() -> None:
    """`EntityType="X.Y.Z.Address"` must key on the bare `Address`, not the qualified form."""
    xml = """<?xml version="1.0" encoding="UTF-8"?>
<edmx:Edmx xmlns:edmx="http://docs.oasis-open.org/odata/ns/edmx" Version="4.0">
  <edmx:DataServices>
    <Schema xmlns="http://docs.oasis-open.org/odata/ns/edm" Namespace="Test.Models">
      <EntityType Name="Address">
        <Key><PropertyRef Name="AddressId" /></Key>
        <Property Name="AddressId" Type="Edm.Int32" Nullable="false" />
      </EntityType>
      <EntityContainer Name="Default">
        <EntitySet Name="Addresses" EntityType="Some.Deep.Namespace.Address" />
      </EntityContainer>
    </Schema>
  </edmx:DataServices>
</edmx:Edmx>
"""
    contracts = bootstrap_odata_contracts(xml, source_name="aw")
    addr = next(c for c in contracts if c.resource_name == "address")
    spec = next(p for p in addr.contract.custom_properties if p.property == "das.spec_ref")
    assert spec.value == {"kind": "odata", "type": "Address", "entity_set": "Addresses"}


def test_entity_set_omitted_when_no_container() -> None:
    """`$metadata` without an EntityContainer keeps the legacy spec_ref shape."""
    xml = """<?xml version="1.0" encoding="UTF-8"?>
<edmx:Edmx xmlns:edmx="http://docs.oasis-open.org/odata/ns/edmx" Version="4.0">
  <edmx:DataServices>
    <Schema xmlns="http://docs.oasis-open.org/odata/ns/edm" Namespace="Test.Models">
      <EntityType Name="Product">
        <Key><PropertyRef Name="ProductId" /></Key>
        <Property Name="ProductId" Type="Edm.Int32" Nullable="false" />
      </EntityType>
    </Schema>
  </edmx:DataServices>
</edmx:Edmx>
"""
    contracts = bootstrap_odata_contracts(xml, source_name="aw")
    prod = next(c for c in contracts if c.resource_name == "products")
    spec = next(p for p in prod.contract.custom_properties if p.property == "das.spec_ref")
    assert spec.value == {"kind": "odata", "type": "Product"}
    assert "entity_set" not in spec.value


def test_entity_type_without_entity_set_is_dropped() -> None:
    """When `<EntityContainer>` is present it is the authority on what is queryable.
    EntityTypes that don't appear as an EntitySet are dropped — see ADR-0025."""
    xml = """<?xml version="1.0" encoding="UTF-8"?>
<edmx:Edmx xmlns:edmx="http://docs.oasis-open.org/odata/ns/edmx" Version="4.0">
  <edmx:DataServices>
    <Schema xmlns="http://docs.oasis-open.org/odata/ns/edm" Namespace="Test.Models">
      <EntityType Name="Product">
        <Key><PropertyRef Name="ProductId" /></Key>
        <Property Name="ProductId" Type="Edm.Int32" Nullable="false" />
      </EntityType>
      <EntityType Name="Department">
        <Key><PropertyRef Name="DepartmentId" /></Key>
        <Property Name="DepartmentId" Type="Edm.Int16" Nullable="false" />
      </EntityType>
      <EntityContainer Name="Default">
        <EntitySet Name="Products" EntityType="Test.Models.Product" />
      </EntityContainer>
    </Schema>
  </edmx:DataServices>
</edmx:Edmx>
"""
    contracts = bootstrap_odata_contracts(xml, source_name="aw")
    resource_names = sorted(c.resource_name for c in contracts)
    assert resource_names == ["products"]
    prod = next(c for c in contracts if c.resource_name == "products")
    prod_spec = next(p for p in prod.contract.custom_properties if p.property == "das.spec_ref")
    assert prod_spec.value == {"kind": "odata", "type": "Product", "entity_set": "Products"}


@pytest.fixture
def irregular_xml(fixtures_dir: Path) -> str:
    return (fixtures_dir / "sample_odata_metadata_irregular.xml").read_text()


def test_irregular_plurals_captured_from_entity_container(irregular_xml: str) -> None:
    """Issue #61 shape: EntityType plurals that the naive +s heuristic gets wrong
    (Address → Addresses, Currency → Currencies) must be captured from the
    EntityContainer."""
    contracts = bootstrap_odata_contracts(irregular_xml, source_name="adventureworks")
    # resource_name comes from pluralize(snake_case(name)).
    addr = next(c for c in contracts if c.resource_name == "address")
    curr = next(c for c in contracts if c.resource_name == "currencies")
    addr_spec = next(p for p in addr.contract.custom_properties if p.property == "das.spec_ref")
    curr_spec = next(p for p in curr.contract.custom_properties if p.property == "das.spec_ref")
    assert addr_spec.value == {
        "kind": "odata",
        "type": "Address",
        "entity_set": "Addresses",
    }
    assert curr_spec.value == {
        "kind": "odata",
        "type": "Currency",
        "entity_set": "Currencies",
    }


def test_malformed_metadata_entity_set_without_matching_entity_type() -> None:
    """EntityContainer references a type with no matching <EntityType> element.
    The orphaned EntitySet is silently skipped; well-formed sets still emit. See ADR-0025."""
    xml = """<?xml version="1.0" encoding="UTF-8"?>
<edmx:Edmx xmlns:edmx="http://docs.oasis-open.org/odata/ns/edmx" Version="4.0">
  <edmx:DataServices>
    <Schema xmlns="http://docs.oasis-open.org/odata/ns/edm" Namespace="Test.Models">
      <EntityType Name="Product">
        <Key><PropertyRef Name="ProductId" /></Key>
        <Property Name="ProductId" Type="Edm.Int32" Nullable="false" />
      </EntityType>
      <EntityContainer Name="Default">
        <EntitySet Name="Products" EntityType="Test.Models.Product" />
        <EntitySet Name="Ghosts" EntityType="Test.Models.Ghost" />
      </EntityContainer>
    </Schema>
  </edmx:DataServices>
</edmx:Edmx>
"""
    contracts = bootstrap_odata_contracts(xml, source_name="aw")
    resource_names = sorted(c.resource_name for c in contracts)
    assert resource_names == ["products"]


def test_empty_entity_container_emits_no_contracts() -> None:
    """A `<EntityContainer>` with no `<EntitySet>` children declares zero
    queryable resources. The container is authoritative — emit zero contracts
    rather than falling back to the EntityType walk. See ADR-0025."""
    xml = """<?xml version="1.0" encoding="UTF-8"?>
<edmx:Edmx xmlns:edmx="http://docs.oasis-open.org/odata/ns/edmx" Version="4.0">
  <edmx:DataServices>
    <Schema xmlns="http://docs.oasis-open.org/odata/ns/edm" Namespace="Test.Models">
      <EntityType Name="Product">
        <Key><PropertyRef Name="ProductId" /></Key>
        <Property Name="ProductId" Type="Edm.Int32" Nullable="false" />
      </EntityType>
      <EntityContainer Name="Default" />
    </Schema>
  </edmx:DataServices>
</edmx:Edmx>
"""
    contracts = bootstrap_odata_contracts(xml, source_name="aw")
    assert contracts == []


@pytest.fixture
def variable_decimal_xml(fixtures_dir: Path) -> str:
    return (fixtures_dir / "sample_odata_metadata_variable_decimal.xml").read_text()


def _decimal_props(contracts: list[LoadedContract], resource: str) -> dict[str, str | None]:
    """Return {property_name: physicalType} for the decimal-bearing entity."""
    target = next(c for c in contracts if c.resource_name == resource)
    return {
        p.name: p.physicalType
        for p in target.contract.primary_schema.properties
        if p.logicalType == "number"
    }


def test_decimal_fixed_precision_scale_preserved(variable_decimal_xml: str) -> None:
    contracts = bootstrap_odata_contracts(variable_decimal_xml, source_name="vardec")
    physical = _decimal_props(contracts, "readings")
    assert physical["fixed_amount"] == "decimal(19,4)"


def test_decimal_scale_zero_preserved(variable_decimal_xml: str) -> None:
    """Scale='0' is a real declaration (integer-valued decimal) and must not
    be treated as missing. Regression guard for the parsing logic."""
    contracts = bootstrap_odata_contracts(variable_decimal_xml, source_name="vardec")
    physical = _decimal_props(contracts, "readings")
    assert physical["integer_amount"] == "decimal(10,0)"


def test_decimal_scale_variable_falls_back_to_max(variable_decimal_xml: str) -> None:
    contracts = bootstrap_odata_contracts(variable_decimal_xml, source_name="vardec")
    physical = _decimal_props(contracts, "readings")
    assert physical["variable_scale_amount"] == "decimal(38,9)"


def test_decimal_precision_variable_falls_back_to_max(variable_decimal_xml: str) -> None:
    contracts = bootstrap_odata_contracts(variable_decimal_xml, source_name="vardec")
    physical = _decimal_props(contracts, "readings")
    assert physical["variable_precision_amount"] == "decimal(38,9)"


def test_decimal_missing_precision_falls_back_to_max(variable_decimal_xml: str) -> None:
    contracts = bootstrap_odata_contracts(variable_decimal_xml, source_name="vardec")
    physical = _decimal_props(contracts, "readings")
    assert physical["missing_precision_amount"] == "decimal(38,9)"


def test_decimal_missing_scale_falls_back_to_max(variable_decimal_xml: str) -> None:
    contracts = bootstrap_odata_contracts(variable_decimal_xml, source_name="vardec")
    physical = _decimal_props(contracts, "readings")
    assert physical["missing_scale_amount"] == "decimal(38,9)"


def test_decimal_unannotated_falls_back_to_max(variable_decimal_xml: str) -> None:
    contracts = bootstrap_odata_contracts(variable_decimal_xml, source_name="vardec")
    physical = _decimal_props(contracts, "readings")
    assert physical["unannotated_amount"] == "decimal(38,9)"


def test_decimal_nonsense_precision_falls_back_to_max(variable_decimal_xml: str) -> None:
    contracts = bootstrap_odata_contracts(variable_decimal_xml, source_name="vardec")
    physical = _decimal_props(contracts, "readings")
    assert physical["nonsense_precision_amount"] == "decimal(38,9)"


def test_decimal_zero_precision_falls_back_to_max(variable_decimal_xml: str) -> None:
    """Precision='0' is invalid per the OData CSDL spec — fall back."""
    contracts = bootstrap_odata_contracts(variable_decimal_xml, source_name="vardec")
    physical = _decimal_props(contracts, "readings")
    assert physical["zero_precision_amount"] == "decimal(38,9)"


def test_decimal_scale_exceeds_precision_falls_back_to_max(variable_decimal_xml: str) -> None:
    """Scale > Precision is invalid per the OData CSDL spec — fall back."""
    contracts = bootstrap_odata_contracts(variable_decimal_xml, source_name="vardec")
    physical = _decimal_props(contracts, "readings")
    assert physical["scale_exceeds_precision_amount"] == "decimal(38,9)"
