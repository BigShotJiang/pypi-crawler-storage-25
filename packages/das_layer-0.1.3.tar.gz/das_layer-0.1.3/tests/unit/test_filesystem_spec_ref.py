"""Unit tests for FilesystemSpecRef Pydantic model. See ADR-0022."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from das_cli.contracts.filesystem_spec_ref import FilesystemSpecRef


def test_minimal_csv_spec_ref() -> None:
    sr = FilesystemSpecRef.model_validate(
        {"kind": "filesystem", "format": "csv", "path": "customers.csv"}
    )
    assert sr.format == "csv"
    assert sr.path == "customers.csv"
    assert sr.inject is None


def test_csv_with_options() -> None:
    sr = FilesystemSpecRef.model_validate(
        {
            "kind": "filesystem",
            "format": "csv",
            "path": "customers_*.csv",
            "delimiter": ";",
            "encoding": "latin-1",
        }
    )
    assert sr.delimiter == ";"
    assert sr.encoding == "latin-1"


def test_inject_accepts_known_sources() -> None:
    sr = FilesystemSpecRef.model_validate(
        {
            "kind": "filesystem",
            "format": "csv",
            "path": "*.csv",
            "inject": {"source_file": "basename", "source_mtime": "mtime"},
        }
    )
    assert sr.inject == {"source_file": "basename", "source_mtime": "mtime"}


def test_inject_rejects_unknown_source() -> None:
    with pytest.raises(ValidationError):
        FilesystemSpecRef.model_validate(
            {
                "kind": "filesystem",
                "format": "csv",
                "path": "*.csv",
                "inject": {"source_file": "magical_value"},
            }
        )


def test_kind_must_be_filesystem() -> None:
    with pytest.raises(ValidationError):
        FilesystemSpecRef.model_validate({"kind": "sql", "format": "csv", "path": "*.csv"})


def test_format_must_be_in_set() -> None:
    with pytest.raises(ValidationError):
        FilesystemSpecRef.model_validate(
            {"kind": "filesystem", "format": "parquet", "path": "*.parquet"}
        )


def test_path_required() -> None:
    with pytest.raises(ValidationError):
        FilesystemSpecRef.model_validate({"kind": "filesystem", "format": "csv"})


def test_path_non_empty() -> None:
    with pytest.raises(ValidationError):
        FilesystemSpecRef.model_validate({"kind": "filesystem", "format": "csv", "path": ""})


def test_extra_fields_forbidden() -> None:
    with pytest.raises(ValidationError):
        FilesystemSpecRef.model_validate(
            {
                "kind": "filesystem",
                "format": "csv",
                "path": "x.csv",
                "bogus_field": True,
            }
        )
