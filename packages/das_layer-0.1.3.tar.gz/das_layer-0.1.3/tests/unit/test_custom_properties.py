import pytest

from das_cli.contracts.custom_properties import (
    KNOWN_CONTRACT_KEYS,
    KNOWN_PROPERTY_KEYS,
    UnknownDasKeyError,
    extract_das_props,
    get_das_value,
)
from das_cli.contracts.odcs import CustomProperty


def make_props(*pairs: tuple[str, object]) -> list[CustomProperty]:
    return [CustomProperty(property=k, value=v) for k, v in pairs]


def test_get_das_value_returns_value() -> None:
    props = make_props(("das.cursor", "modified_at"), ("das.hash_exclude", ["x"]))
    assert get_das_value(props, "das.cursor") == "modified_at"
    assert get_das_value(props, "das.hash_exclude") == ["x"]


def test_get_das_value_returns_default_when_missing() -> None:
    assert get_das_value([], "das.cursor", default=None) is None


def test_extract_das_props_returns_dict() -> None:
    props = make_props(("das.cursor", "x"), ("foreign", 1))
    out = extract_das_props(props)
    assert out == {"das.cursor": "x"}


def test_extract_das_props_rejects_unknown_das_key() -> None:
    props = make_props(("das.unknown", "x"))
    with pytest.raises(UnknownDasKeyError):
        extract_das_props(props, allowed=KNOWN_CONTRACT_KEYS)


def test_property_level_keys_distinct() -> None:
    assert "das.source_path" in KNOWN_PROPERTY_KEYS
    assert "das.cursor" in KNOWN_CONTRACT_KEYS
    assert "das.cursor" not in KNOWN_PROPERTY_KEYS


def test_das_endpoint_in_known_contract_keys() -> None:
    assert "das.endpoint" in KNOWN_CONTRACT_KEYS


def test_extract_das_props_accepts_endpoint() -> None:
    props = make_props(("das.endpoint", {"path": "/x"}))
    out = extract_das_props(props, allowed=KNOWN_CONTRACT_KEYS)
    assert out == {"das.endpoint": {"path": "/x"}}
