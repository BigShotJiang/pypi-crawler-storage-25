from das_cli.bootstrap.sample import infer_contract_from_records

SAMPLES = [
    {
        "_data": {
            "ProductId": 1,
            "Name": "A",
            "ListPrice": 19.99,
            "Color": "Red",
            "ModifiedDate": "2024-01-15T10:00:00Z",
        }
    },
    {
        "_data": {
            "ProductId": 2,
            "Name": "B",
            "ListPrice": 29.99,
            "Color": None,
            "ModifiedDate": "2024-01-16T11:00:00Z",
        }
    },
    {
        "_data": {
            "ProductId": 3,
            "Name": "C",
            "ListPrice": 39.99,
            "Color": "Blue",
            "ModifiedDate": "2024-01-17T12:00:00Z",
        }
    },
]


def test_infers_logical_types() -> None:
    contract = infer_contract_from_records(
        SAMPLES, source_name="adventureworks", resource_name="products"
    )
    by_name = {p.name: p for p in contract.contract.primary_schema.properties}
    assert by_name["product_id"].logicalType == "integer"
    assert by_name["name"].logicalType == "string"
    assert by_name["list_price"].logicalType == "number"
    assert by_name["modified_date"].logicalType == "timestamp"


def test_required_inferred_from_observed_nulls() -> None:
    contract = infer_contract_from_records(
        SAMPLES, source_name="adventureworks", resource_name="products"
    )
    by_name = {p.name: p for p in contract.contract.primary_schema.properties}
    assert by_name["product_id"].required is True  # never null
    assert by_name["color"].required is False  # one null observed


def test_no_primary_key_inferred() -> None:
    contract = infer_contract_from_records(
        SAMPLES, source_name="adventureworks", resource_name="products"
    )
    pks = [p for p in contract.contract.primary_schema.properties if p.primaryKey]
    assert pks == []


def test_marks_status_draft_with_bootstrapped_from() -> None:
    contract = infer_contract_from_records(
        SAMPLES, source_name="adventureworks", resource_name="products"
    )
    assert contract.contract.status == "draft"
    bf = next(
        (p for p in contract.contract.custom_properties if p.property == "das.bootstrapped_from"),
        None,
    )
    assert bf is not None and bf.value == "sample"


def test_empty_records_raises() -> None:
    import pytest

    with pytest.raises(ValueError):
        infer_contract_from_records([], source_name="x", resource_name="y")
