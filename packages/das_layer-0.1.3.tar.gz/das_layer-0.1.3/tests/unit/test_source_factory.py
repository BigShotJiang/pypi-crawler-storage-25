from typing import Any

import pytest

from das_cli.contracts.das_endpoint import MissingEndpointError
from das_cli.contracts.loader import LoadedContract
from das_cli.contracts.odcs import (
    CustomProperty,
    OdcsContract,
    OdcsInfo,
    OdcsProperty,
    OdcsSchema,
)
from das_cli.dlt_glue.source_factory import (
    UnknownSourceTypeError,
    build_extract_resources,
)
from das_cli.models.source_yml import SourceConfig


def make_loaded(resource: str, source_path: str = "Products") -> LoadedContract:
    contract = OdcsContract(
        apiVersion="v3.0.0",
        kind="DataContract",
        id=f"x.{resource}",
        name=resource,
        version="0.1.0",
        status="draft",
        info=OdcsInfo(title=resource),
        schema=[
            OdcsSchema(
                name=resource,
                physicalName=resource,
                physicalType="table",
                properties=[
                    OdcsProperty(name="id", logicalType="integer", primaryKey=True, required=True),
                ],
            )
        ],
        customProperties=[
            CustomProperty(property="das.spec_ref", value={"kind": "odata", "type": source_path}),
        ],
    )
    from pathlib import Path

    return LoadedContract(
        path=Path(f"{resource}.odcs.yaml"), resource_name=resource, contract=contract
    )


def test_odata_source_emits_one_resource_per_contract() -> None:
    scfg = SourceConfig.model_validate(
        {
            "type": "odata",
            "endpoint": "https://example.com/odata/v1",
            "spec": {"kind": "odata", "metadata_url": "https://example.com/odata/v1/$metadata"},
            "auth": {"type": "none"},
        }
    )
    contracts = [make_loaded("products"), make_loaded("employees", "Employee")]
    resources = build_extract_resources(scfg, contracts, source_name="x")
    names = sorted(r.name for r in resources)
    assert names == ["employees", "products"]


def test_odata_resource_has_correct_name_and_disposition() -> None:
    """Verify resource attributes; full column-shape check happens in the
    integration test (test_extract_pipeline.py) where landed JSONL is read back."""
    scfg = SourceConfig.model_validate(
        {
            "type": "odata",
            "endpoint": "https://example.com/odata/v1",
            "spec": {"kind": "odata", "metadata_url": "https://example.com/odata/v1/$metadata"},
            "auth": {"type": "none"},
        }
    )
    contracts = [make_loaded("products")]
    resources = build_extract_resources(scfg, contracts, source_name="x")
    r = resources[0]
    assert r.name == "products"
    # write_disposition is set on the dlt resource hints; access via _hints attr if needed
    # but keep this test resilient to dlt's internal API changes.


def test_unknown_source_type_raises() -> None:
    # All SourceType literals now have builders; bypass Pydantic to test the
    # guard clause with a hypothetical future type.
    scfg = SourceConfig.model_construct(
        type="unknown_future_type", endpoint="/tmp", auth=None, spec=None
    )
    contracts = [make_loaded("products")]
    with pytest.raises(UnknownSourceTypeError):
        build_extract_resources(scfg, contracts, source_name="x")


def make_loaded_with_endpoint(resource: str, endpoint: dict[str, Any]) -> LoadedContract:
    contract = OdcsContract(
        apiVersion="v3.0.0",
        kind="DataContract",
        id=f"x.{resource}",
        name=resource,
        version="0.1.0",
        status="draft",
        info=OdcsInfo(title=resource),
        schema=[
            OdcsSchema(
                name=resource,
                physicalName=resource,
                physicalType="table",
                properties=[
                    OdcsProperty(name="id", logicalType="integer", primaryKey=True, required=True),
                ],
            )
        ],
        customProperties=[
            CustomProperty(property="das.endpoint", value=endpoint),
        ],
    )
    from pathlib import Path

    return LoadedContract(
        path=Path(f"{resource}.odcs.yaml"), resource_name=resource, contract=contract
    )


def test_openapi_with_endpoint_builds_resource() -> None:
    scfg = SourceConfig.model_validate(
        {
            "type": "openapi",
            "endpoint": "https://example.com/api/v1",
            "spec": {"kind": "openapi", "swagger_url": "https://example.com/api/v1/swagger.json"},
            "auth": {"type": "none"},
        }
    )
    contracts = [
        make_loaded_with_endpoint("customers", {"path": "/Customers", "response_path": None})
    ]
    resources = build_extract_resources(scfg, contracts, source_name="x")
    assert [r.name for r in resources] == ["customers"]


def test_openapi_without_endpoint_raises() -> None:
    scfg = SourceConfig.model_validate(
        {
            "type": "openapi",
            "endpoint": "https://example.com/api/v1",
            "spec": {"kind": "openapi", "swagger_url": "https://example.com/api/v1/swagger.json"},
            "auth": {"type": "none"},
        }
    )
    contracts = [make_loaded("customer_dtos", "CustomerDto")]
    with pytest.raises(MissingEndpointError, match="customer_dtos"):
        build_extract_resources(scfg, contracts, source_name="x")


def test_rest_without_endpoint_raises() -> None:
    scfg = SourceConfig.model_validate(
        {
            "type": "rest",
            "endpoint": "https://example.com/api/v1",
            "auth": {"type": "none"},
        }
    )
    contracts = [make_loaded("customer_dtos", "CustomerDto")]
    with pytest.raises(MissingEndpointError):
        build_extract_resources(scfg, contracts, source_name="x")


def test_explicit_endpoint_on_odata_overrides_synthesized() -> None:
    """An OData contract with an explicit das.endpoint uses it, not the
    pluralization synthesis."""
    scfg = SourceConfig.model_validate(
        {
            "type": "odata",
            "endpoint": "https://example.com/odata/v1",
            "spec": {"kind": "odata", "metadata_url": "https://example.com/odata/v1/$metadata"},
            "auth": {"type": "none"},
        }
    )
    contract = OdcsContract(
        apiVersion="v3.0.0",
        kind="DataContract",
        id="x.products",
        name="products",
        version="0.1.0",
        status="draft",
        info=OdcsInfo(title="products"),
        schema=[
            OdcsSchema(
                name="products",
                physicalName="products",
                physicalType="table",
                properties=[
                    OdcsProperty(name="id", logicalType="integer", primaryKey=True, required=True),
                ],
            )
        ],
        customProperties=[
            CustomProperty(property="das.spec_ref", value={"kind": "odata", "type": "Product"}),
            CustomProperty(
                property="das.endpoint",
                value={"path": "/CustomProductsPath", "response_path": "$.value"},
            ),
        ],
    )
    from pathlib import Path

    lc = LoadedContract(
        path=Path("products.odcs.yaml"), resource_name="products", contract=contract
    )
    resources = build_extract_resources(scfg, [lc], source_name="x")
    assert [r.name for r in resources] == ["products"]
