"""Unit tests for SQL bootstrap. See ADR-0018."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Integer,
    LargeBinary,
    MetaData,
    Numeric,
    String,
    Table,
    Text,
    create_engine,
)

from das_cli.bootstrap.sql import bootstrap_sql_contracts
from das_cli.contracts.custom_properties import get_das_value
from das_cli.models.source_yml import SourceConfig


def _seed_sqlite(path: Path) -> None:
    engine = create_engine(f"sqlite:///{path}")
    md = MetaData()
    Table(
        "customers",
        md,
        Column("customer_id", Integer, primary_key=True),
        Column("name", String(100), nullable=False),
        Column("created_at", DateTime, nullable=False),
        Column("updated_at", DateTime, nullable=False),
    )
    Table(
        "orders",
        md,
        Column("order_id", Integer, primary_key=True),
        Column("line_no", Integer, primary_key=True),
        Column("customer_id", Integer, nullable=False),
        Column("amount", Numeric(12, 2), nullable=False),
    )
    Table(
        "attachments",
        md,
        Column("attachment_id", Integer, primary_key=True),
        Column("payload", LargeBinary),
    )
    md.create_all(engine)
    engine.dispose()


def _scfg(url: str, **spec_overrides: object) -> SourceConfig:
    spec: dict[str, object] = {"kind": "sql", **spec_overrides}
    return SourceConfig.model_validate(
        {"type": "sql", "endpoint": url, "spec": spec, "auth": {"type": "none"}}
    )


def test_emits_one_contract_per_table(tmp_path: Path) -> None:
    db = tmp_path / "test.sqlite"
    _seed_sqlite(db)
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    names = sorted(c.resource_name for c in contracts)
    assert names == ["attachments", "customers", "orders"]


def test_resource_name_snake_cased(tmp_path: Path) -> None:
    db = tmp_path / "case.sqlite"
    engine = create_engine(f"sqlite:///{db}")
    md = MetaData()
    Table(
        "CustomerOrders",
        md,
        Column("Id", Integer, primary_key=True),
    )
    md.create_all(engine)
    engine.dispose()
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    assert [c.resource_name for c in contracts] == ["customer_orders"]


def test_physical_name_preserves_db_casing(tmp_path: Path) -> None:
    db = tmp_path / "case.sqlite"
    engine = create_engine(f"sqlite:///{db}")
    md = MetaData()
    Table(
        "CustomerOrders",
        md,
        Column("OrderId", Integer, primary_key=True),
    )
    md.create_all(engine)
    engine.dispose()
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    schema = contracts[0].contract.primary_schema
    assert schema.physicalName == "CustomerOrders"
    assert schema.properties[0].physicalName == "OrderId"
    assert schema.properties[0].name == "order_id"


def test_primary_key_detection_single(tmp_path: Path) -> None:
    db = tmp_path / "test.sqlite"
    _seed_sqlite(db)
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    customers = next(c for c in contracts if c.resource_name == "customers")
    pks = [p.name for p in customers.contract.primary_schema.properties if p.primaryKey]
    assert pks == ["customer_id"]


def test_primary_key_detection_composite(tmp_path: Path) -> None:
    db = tmp_path / "test.sqlite"
    _seed_sqlite(db)
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    orders = next(c for c in contracts if c.resource_name == "orders")
    pks = sorted(p.name for p in orders.contract.primary_schema.properties if p.primaryKey)
    assert pks == ["line_no", "order_id"]


def test_type_mapping_integer(tmp_path: Path) -> None:
    db = tmp_path / "test.sqlite"
    _seed_sqlite(db)
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    customers = next(c for c in contracts if c.resource_name == "customers")
    cid = next(p for p in customers.contract.primary_schema.properties if p.name == "customer_id")
    assert cid.logicalType == "integer"


def test_type_mapping_numeric_with_precision(tmp_path: Path) -> None:
    db = tmp_path / "test.sqlite"
    _seed_sqlite(db)
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    orders = next(c for c in contracts if c.resource_name == "orders")
    amount = next(p for p in orders.contract.primary_schema.properties if p.name == "amount")
    assert amount.logicalType == "number"
    assert amount.physicalType == "decimal(12,2)"


def test_type_mapping_string(tmp_path: Path) -> None:
    db = tmp_path / "test.sqlite"
    _seed_sqlite(db)
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    customers = next(c for c in contracts if c.resource_name == "customers")
    name = next(p for p in customers.contract.primary_schema.properties if p.name == "name")
    assert name.logicalType == "string"


def test_type_mapping_datetime_to_timestamp(tmp_path: Path) -> None:
    db = tmp_path / "test.sqlite"
    _seed_sqlite(db)
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    customers = next(c for c in contracts if c.resource_name == "customers")
    created = next(
        p for p in customers.contract.primary_schema.properties if p.name == "created_at"
    )
    assert created.logicalType == "timestamp"


def test_type_mapping_largebinary_to_string(tmp_path: Path) -> None:
    db = tmp_path / "test.sqlite"
    _seed_sqlite(db)
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    attachments = next(c for c in contracts if c.resource_name == "attachments")
    payload = next(p for p in attachments.contract.primary_schema.properties if p.name == "payload")
    assert payload.logicalType == "string"


def test_cursor_inferred_from_updated_at(tmp_path: Path) -> None:
    db = tmp_path / "test.sqlite"
    _seed_sqlite(db)
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    customers = next(c for c in contracts if c.resource_name == "customers")
    cursor = get_das_value(customers.contract.custom_properties, "das.cursor")
    assert cursor == "updated_at"


def test_no_cursor_when_no_hint_column(tmp_path: Path) -> None:
    db = tmp_path / "test.sqlite"
    _seed_sqlite(db)
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    orders = next(c for c in contracts if c.resource_name == "orders")
    cursor = get_das_value(orders.contract.custom_properties, "das.cursor")
    assert cursor is None


def test_spec_ref_records_schema_and_table(tmp_path: Path) -> None:
    db = tmp_path / "test.sqlite"
    _seed_sqlite(db)
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    customers = next(c for c in contracts if c.resource_name == "customers")
    spec_ref = get_das_value(customers.contract.custom_properties, "das.spec_ref")
    # SQLite's default schema is "main"; Oracle/MSSQL/Postgres will report
    # a real name (the user, dbo, public, ...). What matters is that whatever
    # SQLAlchemy reports as default_schema_name lands verbatim in spec_ref.
    assert spec_ref == {"kind": "sql", "schema": "main", "table": "customers"}


def test_tables_filter_narrows_reflection(tmp_path: Path) -> None:
    db = tmp_path / "test.sqlite"
    _seed_sqlite(db)
    contracts = bootstrap_sql_contracts(
        _scfg(f"sqlite:///{db}", tables=["customers"]), source_name="x"
    )
    assert [c.resource_name for c in contracts] == ["customers"]


def test_boolean_and_text_mapping_through_reflection(tmp_path: Path) -> None:
    """Boolean → boolean; Text → string. Reflection round-trip via SQLite."""
    db = tmp_path / "test.sqlite"
    engine = create_engine(f"sqlite:///{db}")
    md = MetaData()
    Table(
        "flags",
        md,
        Column("id", Integer, primary_key=True),
        Column("is_active", Boolean, nullable=False),
        Column("note", Text),
    )
    md.create_all(engine)
    engine.dispose()
    contracts = bootstrap_sql_contracts(_scfg(f"sqlite:///{db}"), source_name="x")
    flags = next(c for c in contracts if c.resource_name == "flags")
    is_active = next(p for p in flags.contract.primary_schema.properties if p.name == "is_active")
    note = next(p for p in flags.contract.primary_schema.properties if p.name == "note")
    assert is_active.logicalType == "boolean"
    assert note.logicalType == "string"


def test_logical_for_falls_back_to_string_for_unmapped_type() -> None:
    """The final return path of _logical_for catches unmapped SQLAlchemy types."""
    from sqlalchemy import Column, Interval

    from das_cli.bootstrap.sql import _logical_for

    # Interval is a generic SQLAlchemy type that none of the explicit branches
    # in _logical_for handle (it's not Integer, Numeric, Boolean, String, Date,
    # Time, DateTime, TIMESTAMP, LargeBinary, or BLOB). It should fall through
    # to the final `return ("string", None)`.
    col: Column[Any] = Column("duration", Interval())
    logical, physical = _logical_for(col)
    assert logical == "string"
    assert physical is None


def test_logical_for_falls_back_to_string_for_pickle_type() -> None:
    """Second fallback exemplar — PickleType also lands as string."""
    from sqlalchemy import Column, PickleType

    from das_cli.bootstrap.sql import _logical_for

    col: Column[Any] = Column("payload", PickleType())
    logical, physical = _logical_for(col)
    assert logical == "string"
    assert physical is None


def test_logical_for_oracle_number_with_scale_maps_to_decimal() -> None:
    """oracle.NUMBER extends both Numeric and Integer; scale>0 must win as decimal.

    Regression: previously the Integer branch in _logical_for fired first, so
    NUMBER(12,2) became logicalType=integer and lost its scale. That broke
    P2's decimal coercion in _project_record (see ADR-0018 Consequences) and
    failed the Oracle e2e load with `amount__v_text` variant rejection.
    """
    from sqlalchemy import Column
    from sqlalchemy.dialects.oracle import NUMBER

    from das_cli.bootstrap.sql import _logical_for

    col: Column[Any] = Column("amount", NUMBER(12, 2))
    logical, physical = _logical_for(col)
    assert logical == "number"
    assert physical == "decimal(12,2)"


def test_logical_for_oracle_number_scale_zero_falls_through_to_integer() -> None:
    """NUMBER(p, 0) is integer-like in Oracle (driver returns int with asdecimal=False).

    The Numeric-with-scale guard added for the NUMBER(p, s>0) case must let
    scale==0 fall through to the Integer branch so this stays integer.
    """
    from sqlalchemy import Column
    from sqlalchemy.dialects.oracle import NUMBER

    from das_cli.bootstrap.sql import _logical_for

    col: Column[Any] = Column("order_id", NUMBER(10, 0))
    logical, physical = _logical_for(col)
    assert logical == "integer"
    assert physical is None


def test_logical_for_generic_numeric_scale_zero_maps_to_decimal() -> None:
    """SQLAlchemy generic Numeric(10, 0) is NOT Integer-derived — keep mapping to decimal.

    This pins the fallback Numeric branch in _logical_for; without it, removing
    that branch would silently make Numeric(10, 0) fall all the way through to
    the `("string", None)` default.
    """
    from sqlalchemy import Column, Numeric

    from das_cli.bootstrap.sql import _logical_for

    col: Column[Any] = Column("qty", Numeric(10, 0))
    logical, physical = _logical_for(col)
    assert logical == "number"
    assert physical == "decimal(10,0)"


def test_logical_for_generic_numeric_no_precision_scale_maps_to_number_none() -> None:
    """Numeric() with no precision or scale → ('number', None)."""
    from sqlalchemy import Column, Numeric

    from das_cli.bootstrap.sql import _logical_for

    col: Column[Any] = Column("qty", Numeric())
    logical, physical = _logical_for(col)
    assert logical == "number"
    assert physical is None
