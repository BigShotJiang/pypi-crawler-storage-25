from typing import Any

import pytest
from pydantic import ValidationError

from das_cli.models.das_yaml import DasConfig

VALID: dict[str, Any] = {
    "target": {
        "destination": "duckdb",
        "credentials": {"database": "./das.duckdb"},
    },
    "landing": {
        "bucket_url": "./landing",
        "credentials": {},
    },
    "contracts": {"root": "./contracts"},
    "dataset": {"prefix": "das"},
    "defaults": {
        "write_disposition": "append",
        "change_detection": "row_hash",
        "schema_contract": {
            "tables": "freeze",
            "columns": "freeze",
            "data_type": "freeze",
        },
    },
}


def test_valid_config_parses() -> None:
    cfg = DasConfig.model_validate(VALID)
    assert cfg.target.destination == "duckdb"
    assert cfg.target.credentials["database"] == "./das.duckdb"
    assert cfg.landing.bucket_url == "./landing"
    assert cfg.dataset.prefix == "das"
    assert cfg.defaults.write_disposition == "append"


def test_dataset_prefix_optional() -> None:
    payload = {**VALID, "dataset": {}}
    cfg = DasConfig.model_validate(payload)
    assert cfg.dataset.prefix is None


def test_change_detection_must_be_known() -> None:
    payload = {**VALID, "defaults": {**VALID["defaults"], "change_detection": "weird"}}
    with pytest.raises(ValidationError):
        DasConfig.model_validate(payload)


def test_schema_contract_modes_validated() -> None:
    payload = {
        **VALID,
        "defaults": {
            **VALID["defaults"],
            "schema_contract": {"tables": "wrong", "columns": "freeze", "data_type": "freeze"},
        },
    }
    with pytest.raises(ValidationError):
        DasConfig.model_validate(payload)


def test_target_destination_required() -> None:
    payload = {**VALID, "target": {"credentials": {}}}
    with pytest.raises(ValidationError):
        DasConfig.model_validate(payload)


def test_schema_contract_discard_value_accepted() -> None:
    """discard_value is a valid schema_contract mode and should be accepted by the model."""
    payload = {
        **VALID,
        "defaults": {
            **VALID["defaults"],
            "schema_contract": {
                "tables": "evolve",
                "columns": "freeze",
                "data_type": "discard_value",
            },
        },
    }
    cfg = DasConfig.model_validate(payload)
    assert cfg.defaults.schema_contract.data_type == "discard_value"
    assert cfg.defaults.schema_contract.columns == "freeze"
    # tables is always evolve in practice; the model just holds what the user wrote
    assert cfg.defaults.schema_contract.tables == "evolve"


def test_schema_contract_defaults_are_evolve_for_tables() -> None:
    """Default schema_contract.tables is evolve to match the runtime behaviour."""
    from das_cli.models.das_yaml import SchemaContractConfig

    sc = SchemaContractConfig()
    assert sc.tables == "evolve"
    assert sc.columns == "freeze"
    assert sc.data_type == "freeze"


@pytest.mark.parametrize(
    "raw_prefix, expected",
    [
        ("das", "das"),
        ("custom", "custom"),
        (None, None),
    ],
)
def test_dataset_prefix_pass_through(raw_prefix: object, expected: object) -> None:
    """Real prefixes and real None must survive the validator unchanged."""
    payload = {**VALID, "dataset": {"prefix": raw_prefix}}
    cfg = DasConfig.model_validate(payload)
    assert cfg.dataset.prefix == expected


@pytest.mark.parametrize(
    "raw_prefix",
    [
        "",
        "none",
        "None",
        "NONE",
        "null",
        "Null",
        "NULL",
        "  none  ",
        "\tnull\n",
    ],
)
def test_dataset_prefix_string_none_normalizes_to_none(raw_prefix: str) -> None:
    """Empty/none/null strings (any case, with whitespace) normalize to None."""
    payload = {**VALID, "dataset": {"prefix": raw_prefix}}
    cfg = DasConfig.model_validate(payload)
    assert cfg.dataset.prefix is None
