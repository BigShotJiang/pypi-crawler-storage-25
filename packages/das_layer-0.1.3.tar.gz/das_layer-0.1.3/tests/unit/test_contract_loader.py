from pathlib import Path

from das_cli.contracts.loader import (
    LoadedContract,
    discover_sources,
    load_contract,
    load_source_contracts,
)

PRODUCTS_YAML = """\
apiVersion: v3.0.0
kind: DataContract
id: adventureworks.products
name: Products
version: 0.1.0
status: draft
info:
  title: Products
  owner: data-platform
schema:
  - name: products
    physicalName: products
    physicalType: table
    properties:
      - name: product_id
        physicalName: ProductId
        logicalType: integer
        physicalType: bigint
        required: true
        primaryKey: true
customProperties:
  - property: das.cursor
    value: modified_at
"""


SOURCE_YML = """\
type: odata
endpoint: https://example.com/odata/v1
spec:
  kind: odata
  metadata_url: https://example.com/odata/v1/$metadata
auth:
  type: none
"""


def test_load_contract_returns_loaded(tmp_path: Path) -> None:
    p = tmp_path / "products.odcs.yaml"
    p.write_text(PRODUCTS_YAML)
    loaded = load_contract(p)
    assert isinstance(loaded, LoadedContract)
    assert loaded.resource_name == "products"
    assert loaded.contract.id == "adventureworks.products"
    assert loaded.path == p


def test_load_source_contracts_skips_underscore_files(tmp_path: Path) -> None:
    src_dir = tmp_path / "adventureworks"
    src_dir.mkdir()
    (src_dir / "_source.yml").write_text(SOURCE_YML)
    (src_dir / "products.odcs.yaml").write_text(PRODUCTS_YAML)

    loaded = load_source_contracts(src_dir)
    names = [c.resource_name for c in loaded]
    assert names == ["products"]


def test_discover_sources_lists_directories(tmp_path: Path) -> None:
    (tmp_path / "adventureworks").mkdir()
    (tmp_path / "adventureworks" / "_source.yml").write_text(SOURCE_YML)
    (tmp_path / "northwind").mkdir()
    (tmp_path / "northwind" / "_source.yml").write_text(SOURCE_YML)

    sources = discover_sources(tmp_path)
    assert sorted(s.name for s in sources) == ["adventureworks", "northwind"]


def test_discover_sources_skips_dirs_without_source_yml(tmp_path: Path) -> None:
    (tmp_path / "real").mkdir()
    (tmp_path / "real" / "_source.yml").write_text(SOURCE_YML)
    (tmp_path / "garbage").mkdir()

    sources = discover_sources(tmp_path)
    assert [s.name for s in sources] == ["real"]


def test_resource_name_must_match_contract_table(tmp_path: Path) -> None:
    bad = PRODUCTS_YAML.replace("physicalName: products", "physicalName: other_table")
    p = tmp_path / "products.odcs.yaml"
    p.write_text(bad)
    # Loader doesn't enforce; that's the validator's job. Just verify load works.
    loaded = load_contract(p)
    assert loaded.resource_name == "products"
    assert loaded.contract.primary_schema.physicalName == "other_table"
