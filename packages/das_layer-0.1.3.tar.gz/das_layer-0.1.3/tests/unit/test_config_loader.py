from pathlib import Path

import pytest

from das_cli.config import load_das_config, load_source_config
from das_cli.jinja_env import MissingEnvVarError

DAS_YAML = """\
target:
  destination: duckdb
  credentials:
    database: "{{ env_var('DAS_TARGET_DB', './das.duckdb') }}"
landing:
  bucket_url: "{{ env_var('DAS_LANDING_URL', './landing') }}"
  credentials: {}
contracts:
  root: ./contracts
dataset:
  prefix: das
defaults:
  write_disposition: append
  change_detection: row_hash
  schema_contract:
    tables: freeze
    columns: freeze
    data_type: freeze
"""


SOURCE_YAML = """\
type: odata
endpoint: https://example.com/odata/v1
spec:
  kind: odata
  metadata_url: https://example.com/odata/v1/$metadata
auth:
  type: bearer
  token: "{{ env_var('TEST_TOKEN') }}"
ownership:
  team: data-platform
"""


def test_load_das_config_renders_env(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DAS_TARGET_DB", "/tmp/from_env.duckdb")
    monkeypatch.delenv("DAS_LANDING_URL", raising=False)
    p = tmp_path / "das.yaml"
    p.write_text(DAS_YAML)

    cfg = load_das_config(p)
    assert cfg.target.credentials["database"] == "/tmp/from_env.duckdb"
    assert cfg.landing.bucket_url == "./landing"  # default applied
    assert cfg.defaults.schema_contract.tables == "freeze"


def test_load_das_config_missing_required_env(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("DAS_TARGET_DB", raising=False)
    yaml = DAS_YAML.replace("'./das.duckdb'", "")  # remove default
    yaml = yaml.replace("env_var('DAS_TARGET_DB', )", "env_var('DAS_TARGET_DB')")
    p = tmp_path / "das.yaml"
    p.write_text(yaml)

    with pytest.raises(MissingEnvVarError):
        load_das_config(p)


def test_load_source_config_renders_env(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("TEST_TOKEN", "abc123")
    p = tmp_path / "_source.yml"
    p.write_text(SOURCE_YAML)

    cfg = load_source_config(p)
    assert cfg.type == "odata"
    assert cfg.auth.type == "bearer"
    assert cfg.auth.model_extra is not None
    assert cfg.auth.model_extra["token"] == "abc123"


def test_load_source_config_unknown_type(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("TEST_TOKEN", "dummy")
    yaml = SOURCE_YAML.replace("type: odata", "type: unknown")
    p = tmp_path / "_source.yml"
    p.write_text(yaml)
    from pydantic import ValidationError

    with pytest.raises(ValidationError):
        load_source_config(p)
