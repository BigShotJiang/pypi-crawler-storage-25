"""Unit tests for reset_extract_state. See ADR-0019, ADR-0020."""

from __future__ import annotations

from pathlib import Path

import pytest

from das_cli.pipelines.extract import reset_extract_state


def _seed_workspace(tmp_path: Path) -> Path:
    (tmp_path / "das.yaml").write_text(
        """\
target:
  destination: duckdb
  credentials: {database: ./das.duckdb}
landing:
  bucket_url: ./landing
  credentials: {}
contracts: {root: ./contracts}
"""
    )
    (tmp_path / "contracts" / "src1").mkdir(parents=True)
    return tmp_path


def test_reset_extract_state_removes_landing_dlt_dirs(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    workspace = _seed_workspace(tmp_path)
    monkeypatch.chdir(workspace)

    src_landing = workspace / "landing" / "src1"
    for sub in ("_dlt_pipeline_state", "_dlt_loads", "_dlt_version"):
        (src_landing / sub).mkdir(parents=True)
        (src_landing / sub / "marker").write_text("x")

    (src_landing / "products").mkdir(parents=True)
    (src_landing / "products" / "data.jsonl").write_text('{"x":1}\n')

    reset_extract_state("src1", workspace / "das.yaml")

    for sub in ("_dlt_pipeline_state", "_dlt_loads", "_dlt_version"):
        assert not (src_landing / sub).exists()
    # Resource data subtree must be left intact.
    assert (src_landing / "products" / "data.jsonl").exists()


def test_reset_extract_state_on_azure_url_uses_fsspec(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Azure URLs no longer raise NotImplementedError; reset uses fsspec.

    We don't have real Azure access in unit tests. Patch `landing_fs` to hand
    out a `MemoryFileSystem` so the rest of reset_extract_state's logic runs
    against an in-process filesystem. The assertion is structural: dlt state
    dirs are removed and resource data is preserved.
    """
    import fsspec

    mem = fsspec.filesystem("memory")
    for sub in ("_dlt_pipeline_state", "_dlt_loads", "_dlt_version"):
        mem.touch(f"/landing/src1/{sub}/marker")
    mem.touch("/landing/src1/products/data.jsonl")

    monkeypatch.setattr(
        "das_cli.pipelines.extract.landing_fs",
        lambda landing: (mem, "/landing"),
    )

    (tmp_path / "das.yaml").write_text(
        """\
target:
  destination: duckdb
  credentials: {database: ./das.duckdb}
landing:
  bucket_url: abfss://lake@acct.dfs.core.windows.net/landing
  credentials: {auth: default}
contracts: {root: ./contracts}
"""
    )
    (tmp_path / "contracts" / "src1").mkdir(parents=True)

    reset_extract_state("src1", tmp_path / "das.yaml")

    for sub in ("_dlt_pipeline_state", "_dlt_loads", "_dlt_version"):
        assert not mem.exists(f"/landing/src1/{sub}")
    assert mem.exists("/landing/src1/products/data.jsonl")
