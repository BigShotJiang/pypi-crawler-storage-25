"""Unit tests for load_latest_hash — verifies open_sql_client is used so the
Fabric-aware DuckDB auth runs before the SELECT.
"""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock

import pytest

from das_cli.models.das_yaml import AzureServicePrincipalAuth
from das_cli.pipelines.change_detection import load_latest_hash


def test_load_latest_hash_passes_bucket_url_and_azure_to_open_sql_client(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When bucket_url + azure are provided, load_latest_hash routes through
    open_sql_client so the Fabric secret install runs before the SELECT.
    """
    captured: dict[str, Any] = {}

    fake_client = MagicMock()
    fake_client.execute_sql.return_value = []

    import contextlib

    @contextlib.contextmanager
    def fake_open_sql_client(pipeline, *, bucket_url, azure):  # type: ignore[no-untyped-def]
        captured["pipeline"] = pipeline
        captured["bucket_url"] = bucket_url
        captured["azure"] = azure
        yield fake_client

    monkeypatch.setattr("das_cli.pipelines.change_detection.open_sql_client", fake_open_sql_client)

    sp = AzureServicePrincipalAuth(
        auth="service_principal", tenant_id="t", client_id="c", client_secret="s"
    )
    fake_pipeline = MagicMock()
    out = load_latest_hash(
        pipeline=fake_pipeline,
        dataset="das__src",
        table="products",
        primary_key=["id"],
        bucket_url="abfss://ws@onelake.dfs.fabric.microsoft.com/lh/Tables",
        azure=sp,
    )

    assert out == {}
    assert captured["pipeline"] is fake_pipeline
    assert captured["bucket_url"] == "abfss://ws@onelake.dfs.fabric.microsoft.com/lh/Tables"
    assert captured["azure"] is sp


def test_load_latest_hash_works_without_bucket_url_and_azure(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Default call signature (no Azure kwargs) still works for duckdb / ducklake."""
    fake_client = MagicMock()
    fake_client.execute_sql.return_value = [("a", "hashA"), ("b", "hashB")]

    import contextlib

    @contextlib.contextmanager
    def fake_open_sql_client(pipeline, *, bucket_url, azure):  # type: ignore[no-untyped-def]
        assert bucket_url is None
        assert azure is None
        yield fake_client

    monkeypatch.setattr("das_cli.pipelines.change_detection.open_sql_client", fake_open_sql_client)

    out = load_latest_hash(
        pipeline=MagicMock(),
        dataset="das__src",
        table="customers",
        primary_key=["id"],
    )
    assert out == {("a",): "hashA", ("b",): "hashB"}


def test_load_latest_hash_returns_empty_on_undefined_relation(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """First load (table doesn't exist yet) → empty dict, no Azure surprises."""
    from dlt.destinations.exceptions import DatabaseUndefinedRelation

    fake_client = MagicMock()
    fake_client.execute_sql.side_effect = DatabaseUndefinedRelation(Exception("nope"))

    import contextlib

    @contextlib.contextmanager
    def fake_open_sql_client(pipeline, *, bucket_url, azure):  # type: ignore[no-untyped-def]
        yield fake_client

    monkeypatch.setattr("das_cli.pipelines.change_detection.open_sql_client", fake_open_sql_client)

    out = load_latest_hash(
        pipeline=MagicMock(),
        dataset="das__src",
        table="products",
        primary_key=["id"],
    )
    assert out == {}
