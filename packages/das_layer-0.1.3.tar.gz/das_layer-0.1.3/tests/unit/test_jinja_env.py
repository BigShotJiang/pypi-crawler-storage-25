import pytest
from jinja2 import TemplateAssertionError

from das_cli.jinja_env import MissingEnvVarError, render_template


def test_env_var_renders_when_set(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("FOO", "bar")
    assert render_template("{{ env_var('FOO') }}", origin="test") == "bar"


def test_env_var_default_used_when_unset(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("FOO", raising=False)
    assert render_template("{{ env_var('FOO', 'fallback') }}", origin="test") == "fallback"


def test_missing_env_var_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("FOO", raising=False)
    with pytest.raises(MissingEnvVarError) as excinfo:
        render_template("{{ env_var('FOO') }}", origin="das.yaml: target.credentials")
    assert "FOO" in str(excinfo.value)
    assert "das.yaml: target.credentials" in str(excinfo.value)


def test_literal_string_passes_through() -> None:
    assert render_template("./das.duckdb", origin="test") == "./das.duckdb"


def test_no_other_jinja_features_supported() -> None:
    # Filters, conditionals, etc. should not work — only env_var() is exposed.
    with pytest.raises(TemplateAssertionError):
        render_template("{{ 'foo' | upper }}", origin="test")
