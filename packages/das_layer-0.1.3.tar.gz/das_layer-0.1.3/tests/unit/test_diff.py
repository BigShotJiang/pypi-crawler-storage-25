from das_cli.bootstrap.odata import bootstrap_odata_contracts
from das_cli.contracts.diff import diff_against_odata

METADATA_BASE = """\
<?xml version="1.0" encoding="UTF-8"?>
<edmx:Edmx xmlns:edmx="http://docs.oasis-open.org/odata/ns/edmx" Version="4.0">
  <edmx:DataServices>
    <Schema xmlns="http://docs.oasis-open.org/odata/ns/edm" Namespace="X.M">
      <EntityType Name="Product">
        <Key><PropertyRef Name="ProductId" /></Key>
        <Property Name="ProductId" Type="Edm.Int32" Nullable="false" />
        <Property Name="Name" Type="Edm.String" Nullable="false" />
      </EntityType>
    </Schema>
  </edmx:DataServices>
</edmx:Edmx>
"""

METADATA_NEW_COL = METADATA_BASE.replace(
    '<Property Name="Name" Type="Edm.String" Nullable="false" />',
    '<Property Name="Name" Type="Edm.String" Nullable="false" />\n'
    '        <Property Name="Color" Type="Edm.String" />',
)

METADATA_NULL_CHANGE = METADATA_BASE.replace(
    'Type="Edm.String" Nullable="false"',
    'Type="Edm.String"',
)


def test_no_diff_when_identical() -> None:
    loaded = bootstrap_odata_contracts(METADATA_BASE, source_name="x")
    diffs = diff_against_odata(loaded, METADATA_BASE)
    assert diffs == []


def test_added_column_in_source() -> None:
    loaded = bootstrap_odata_contracts(METADATA_BASE, source_name="x")
    diffs = diff_against_odata(loaded, METADATA_NEW_COL)
    assert any(d.kind == "added" and "color" in d.message.lower() for d in diffs)


def test_required_change() -> None:
    loaded = bootstrap_odata_contracts(METADATA_BASE, source_name="x")
    diffs = diff_against_odata(loaded, METADATA_NULL_CHANGE)
    assert any(d.kind == "changed" and "name" in d.message.lower() for d in diffs)


def test_removed_column() -> None:
    loaded = bootstrap_odata_contracts(METADATA_NEW_COL, source_name="x")
    diffs = diff_against_odata(loaded, METADATA_BASE)
    assert any(d.kind == "removed" and "color" in d.message.lower() for d in diffs)
