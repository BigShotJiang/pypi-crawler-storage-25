"""CLI: das contract bootstrap for type=filesystem. See ADR-0022."""

from __future__ import annotations

from pathlib import Path

import pytest
from typer.testing import CliRunner

from das_cli.cli import app


def _seed_workspace(root: Path, *, source_name: str = "files") -> Path:
    """Create a minimal das workspace under `root` with a filesystem source."""
    (root / "das.yaml").write_text(
        "contracts:\n  root: contracts\n"
        "landing:\n  bucket_url: ./landing\n"
        "defaults:\n  change_detection: row_hash\n"
    )

    data_dir = root / "data"
    data_dir.mkdir()
    (data_dir / "customers.csv").write_text("id,name\n1,Alice\n")
    (data_dir / "orders.csv").write_text("order_id,amount\n10,99.50\n")

    src_dir = root / "contracts" / source_name
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(
        f"type: filesystem\n"
        f"endpoint: {data_dir}\n"
        "spec:\n  kind: filesystem\n"
        "auth:\n  type: none\n"
    )
    return src_dir


def test_filesystem_bootstrap_writes_one_contract_per_csv(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _seed_workspace(tmp_path)
    monkeypatch.chdir(tmp_path)
    runner = CliRunner()
    result = runner.invoke(
        app,
        ["contract", "bootstrap", "files"],
    )
    assert result.exit_code == 0, result.stdout
    src_dir = tmp_path / "contracts" / "files"
    written = sorted(p.name for p in src_dir.glob("*.odcs.yaml"))
    assert written == ["customers.odcs.yaml", "orders.odcs.yaml"]


def test_filesystem_bootstrap_only_filter(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    _seed_workspace(tmp_path)
    monkeypatch.chdir(tmp_path)
    runner = CliRunner()
    result = runner.invoke(
        app,
        [
            "contract",
            "bootstrap",
            "files",
            "--only",
            "customers",
        ],
    )
    assert result.exit_code == 0, result.stdout
    src_dir = tmp_path / "contracts" / "files"
    written = sorted(p.name for p in src_dir.glob("*.odcs.yaml"))
    assert written == ["customers.odcs.yaml"]


def test_filesystem_bootstrap_dry_run(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    _seed_workspace(tmp_path)
    monkeypatch.chdir(tmp_path)
    runner = CliRunner()
    result = runner.invoke(
        app,
        [
            "contract",
            "bootstrap",
            "files",
            "--dry-run",
        ],
    )
    assert result.exit_code == 0, result.stdout
    src_dir = tmp_path / "contracts" / "files"
    assert list(src_dir.glob("*.odcs.yaml")) == []
    assert "would write" in result.stdout


def test_filesystem_bootstrap_xml_with_xpath(tmp_path: Path) -> None:
    """`das contract bootstrap --xpath //customer` discovers xml contracts."""
    (tmp_path / "das.yaml").write_text(
        "contracts:\n  root: contracts\n"
        "landing:\n  bucket_url: ./landing\n"
        "defaults:\n  change_detection: row_hash\n"
    )

    data_dir = tmp_path / "data"
    data_dir.mkdir()
    (data_dir / "customers.xml").write_text(
        '<?xml version="1.0"?>\n<root>\n'
        "  <customer><id>1</id><name>Alice</name></customer>\n"
        "</root>\n"
    )

    src_dir = tmp_path / "contracts" / "files"
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(
        f"type: filesystem\n"
        f"endpoint: {data_dir}\n"
        "spec:\n  kind: filesystem\n"
        "auth:\n  type: none\n"
    )

    runner = CliRunner()
    result = runner.invoke(
        app,
        [
            "--config",
            str(tmp_path / "das.yaml"),
            "contract",
            "bootstrap",
            "files",
            "--xpath",
            "//customer",
        ],
    )
    assert result.exit_code == 0, result.stdout
    written = sorted(p.name for p in src_dir.glob("*.odcs.yaml"))
    assert written == ["customers.odcs.yaml"]


def test_filesystem_bootstrap_xml_without_xpath_fails(tmp_path: Path) -> None:
    """Bootstrap with an xml file but no --xpath errors out."""
    (tmp_path / "das.yaml").write_text(
        "contracts:\n  root: contracts\n"
        "landing:\n  bucket_url: ./landing\n"
        "defaults:\n  change_detection: row_hash\n"
    )
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    (data_dir / "x.xml").write_text("<root/>")

    src_dir = tmp_path / "contracts" / "files"
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(
        f"type: filesystem\nendpoint: {data_dir}\n"
        "spec:\n  kind: filesystem\nauth:\n  type: none\n"
    )

    runner = CliRunner()
    result = runner.invoke(
        app,
        ["--config", str(tmp_path / "das.yaml"), "contract", "bootstrap", "files"],
    )
    assert result.exit_code != 0
    assert "xpath" in result.output.lower()
