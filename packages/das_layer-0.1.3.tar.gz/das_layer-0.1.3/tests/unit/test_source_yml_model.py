from typing import Any

import pytest
from pydantic import ValidationError

from das_cli.models.source_yml import SourceConfig

VALID: dict[str, Any] = {
    "type": "odata",
    "endpoint": "https://example.com/odata/v1",
    "spec": {
        "kind": "odata",
        "metadata_url": "https://example.com/odata/v1/$metadata",
    },
    "auth": {"type": "bearer", "token": "secret"},
    "ownership": {"team": "data-platform"},
}


def test_valid_source_parses() -> None:
    cfg = SourceConfig.model_validate(VALID)
    assert cfg.type == "odata"
    assert cfg.spec.kind == "odata"
    assert cfg.auth.type == "bearer"
    assert cfg.ownership.team == "data-platform"


def test_auth_type_validated() -> None:
    payload = {**VALID, "auth": {"type": "weird", "token": "x"}}
    with pytest.raises(ValidationError):
        SourceConfig.model_validate(payload)


def test_no_auth_allowed() -> None:
    payload = {**VALID, "auth": {"type": "none"}}
    cfg = SourceConfig.model_validate(payload)
    assert cfg.auth.type == "none"


def test_spec_kind_validated() -> None:
    payload = {**VALID, "spec": {"kind": "weird"}}
    with pytest.raises(ValidationError):
        SourceConfig.model_validate(payload)


def test_type_required() -> None:
    payload = {k: v for k, v in VALID.items() if k != "type"}
    with pytest.raises(ValidationError):
        SourceConfig.model_validate(payload)


def test_spec_kind_sql_accepts_schemas_tables_include_views() -> None:
    payload = {
        "type": "sql",
        "endpoint": "oracle+oracledb://host:1521/?service_name=XE",
        "spec": {
            "kind": "sql",
            "schemas": ["HR"],
            "tables": ["EMPLOYEES"],
            "include_views": True,
        },
        "auth": {"type": "none"},
    }
    cfg = SourceConfig.model_validate(payload)
    assert cfg.spec.kind == "sql"
    assert cfg.spec.schemas == ["HR"]
    assert cfg.spec.tables == ["EMPLOYEES"]
    assert cfg.spec.include_views is True


def test_spec_kind_sql_defaults_schemas_tables_include_views() -> None:
    payload = {
        "type": "sql",
        "endpoint": "sqlite:///:memory:",
        "spec": {"kind": "sql"},
        "auth": {"type": "none"},
    }
    cfg = SourceConfig.model_validate(payload)
    assert cfg.spec.kind == "sql"
    assert cfg.spec.schemas is None
    assert cfg.spec.tables is None
    assert cfg.spec.include_views is False


def test_spec_kind_sql_rejects_metadata_url() -> None:
    payload = {
        "type": "sql",
        "endpoint": "sqlite:///:memory:",
        "spec": {"kind": "sql", "metadata_url": "https://x/$metadata"},
        "auth": {"type": "none"},
    }
    with pytest.raises(ValidationError, match=r"metadata_url"):
        SourceConfig.model_validate(payload)


def test_spec_kind_sql_rejects_swagger_url() -> None:
    payload = {
        "type": "sql",
        "endpoint": "sqlite:///:memory:",
        "spec": {"kind": "sql", "swagger_url": "https://x/swagger.json"},
        "auth": {"type": "none"},
    }
    with pytest.raises(ValidationError, match=r"swagger_url"):
        SourceConfig.model_validate(payload)


def test_spec_kind_odata_rejects_schemas() -> None:
    payload = {
        "type": "odata",
        "endpoint": "https://example.com/odata/v1",
        "spec": {
            "kind": "odata",
            "metadata_url": "https://example.com/odata/v1/$metadata",
            "schemas": ["HR"],
        },
        "auth": {"type": "none"},
    }
    with pytest.raises(ValidationError, match=r"schemas"):
        SourceConfig.model_validate(payload)


def test_spec_kind_openapi_rejects_tables() -> None:
    payload = {
        "type": "openapi",
        "endpoint": "https://example.com/api/v1",
        "spec": {
            "kind": "openapi",
            "swagger_url": "https://example.com/api/v1/swagger.json",
            "tables": ["x"],
        },
        "auth": {"type": "none"},
    }
    with pytest.raises(ValidationError, match=r"tables"):
        SourceConfig.model_validate(payload)


def test_spec_kind_none_rejects_schemas() -> None:
    payload = {
        "type": "filesystem",
        "endpoint": "file:///tmp",
        "spec": {"kind": "none", "schemas": ["HR"]},
        "auth": {"type": "none"},
    }
    with pytest.raises(ValidationError, match=r"schemas"):
        SourceConfig.model_validate(payload)


def test_spec_kind_rest_rejects_include_views() -> None:
    payload = {
        "type": "rest",
        "endpoint": "https://example.com/api/v1",
        "spec": {"kind": "openapi", "swagger_url": "https://example.com/api/v1/swagger.json"},
        "auth": {"type": "none"},
    }
    # The above payload is valid (kind=openapi, no SQL fields). Now corrupt it.
    payload["spec"] = {"kind": "openapi", "swagger_url": "https://x/y.json", "include_views": True}
    with pytest.raises(ValidationError, match=r"include_views"):
        SourceConfig.model_validate(payload)
