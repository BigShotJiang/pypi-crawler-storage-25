"""Unit tests for _build_destination dispatch. See ADR-0016."""

from __future__ import annotations

import pytest

from das_cli.models.das_yaml import TargetConfig
from das_cli.pipelines.load import _build_destination


def test_duckdb_dispatch_returns_duckdb_destination() -> None:
    target = TargetConfig(destination="duckdb", credentials={"database": "./test.duckdb"})
    dest, _, _ = _build_destination(target)
    # dlt destinations expose a destination_type attribute; assert on that.
    # The dlt duckdb factory reports destination_type as "dlt.destinations.duckdb".
    assert dest.destination_type == "dlt.destinations.duckdb"


def test_duckdb_dispatch_forwards_database_path() -> None:
    target = TargetConfig(destination="duckdb", credentials={"database": "./custom.duckdb"})
    dest, _, _ = _build_destination(target)
    # config_params is the public surface for dlt destination factories.
    assert dest.config_params["credentials"] == "./custom.duckdb"


def test_duckdb_dispatch_defaults_database_when_missing() -> None:
    target = TargetConfig(destination="duckdb", credentials={})
    dest, _, _ = _build_destination(target)
    assert dest.config_params["credentials"] == "./das.duckdb"


def test_duckdb_dispatch_disables_dataset_name_normalization() -> None:
    target = TargetConfig(destination="duckdb", credentials={"database": "./x.duckdb"})
    dest, _, _ = _build_destination(target)
    assert dest.config_params["enable_dataset_name_normalization"] is False


def test_unknown_destination_raises_value_error() -> None:
    target = TargetConfig(destination="postgres", credentials={})
    with pytest.raises(
        ValueError,
        match=r"Unsupported target\.destination.*delta",
    ):
        _build_destination(target)


def test_ducklake_dispatch_returns_ducklake_destination() -> None:
    target = TargetConfig(
        destination="ducklake",
        credentials={"catalog": "./das.ducklake", "storage": "./ducklake_data"},
    )
    dest, _, _ = _build_destination(target)
    # The dlt ducklake factory reports destination_type fully-qualified, like duckdb.
    assert dest.destination_type == "dlt.destinations.ducklake"


def test_ducklake_dispatch_disables_dataset_name_normalization() -> None:
    target = TargetConfig(
        destination="ducklake",
        credentials={"catalog": "./das.ducklake", "storage": "./ducklake_data"},
    )
    dest, _, _ = _build_destination(target)
    assert dest.config_params["enable_dataset_name_normalization"] is False


def test_ducklake_dispatch_auto_prefixes_bare_catalog_path() -> None:
    target = TargetConfig(
        destination="ducklake",
        credentials={"catalog": "./das.ducklake", "storage": "./ducklake_data"},
    )
    dest, _, _ = _build_destination(target)
    creds = dest.config_params["credentials"]
    assert creds["catalog"] == "duckdb:///./das.ducklake"
    assert creds["storage"] == "./ducklake_data"


def test_ducklake_dispatch_passes_url_catalog_through() -> None:
    target = TargetConfig(
        destination="ducklake",
        credentials={
            "catalog": "postgresql://user:pw@host:5432/cat",
            "storage": "./ducklake_data",
        },
    )
    dest, _, _ = _build_destination(target)
    creds = dest.config_params["credentials"]
    assert creds["catalog"] == "postgresql://user:pw@host:5432/cat"


def test_ducklake_dispatch_passes_duckdb_url_catalog_through() -> None:
    target = TargetConfig(
        destination="ducklake",
        credentials={
            "catalog": "duckdb:///./other.ducklake",
            "storage": "./ducklake_data",
        },
    )
    dest, _, _ = _build_destination(target)
    creds = dest.config_params["credentials"]
    assert creds["catalog"] == "duckdb:///./other.ducklake"


def test_delta_dispatch_returns_filesystem_destination() -> None:
    target = TargetConfig(
        destination="delta",
        credentials={"bucket_url": "./das_delta"},
    )
    dest, _, _ = _build_destination(target)
    # Delta is implemented as a filesystem destination; table_format is set per-resource.
    assert dest.destination_type == "dlt.destinations.filesystem"


def test_delta_dispatch_forwards_bucket_url_verbatim() -> None:
    target = TargetConfig(
        destination="delta",
        credentials={"bucket_url": "./custom_delta"},
    )
    dest, _, _ = _build_destination(target)
    assert dest.config_params["bucket_url"] == "./custom_delta"


def test_delta_dispatch_defaults_bucket_url_when_missing() -> None:
    target = TargetConfig(destination="delta", credentials={})
    dest, _, _ = _build_destination(target)
    assert dest.config_params["bucket_url"] == "./das_delta"


def test_delta_dispatch_disables_dataset_name_normalization() -> None:
    target = TargetConfig(
        destination="delta",
        credentials={"bucket_url": "./das_delta"},
    )
    dest, _, _ = _build_destination(target)
    assert dest.config_params["enable_dataset_name_normalization"] is False


def test_delta_dispatch_with_azure_url_service_principal() -> None:
    from dlt.common.configuration.specs import (
        AzureServicePrincipalCredentialsWithoutDefaults,
    )

    target = TargetConfig(
        destination="delta",
        credentials={
            "bucket_url": "abfss://lake@acct.dfs.core.windows.net/warehouse",
            "auth": "service_principal",
            "tenant_id": "tid",
            "client_id": "cid",
            "client_secret": "secret",
        },
    )
    dest, _, _ = _build_destination(target)
    assert dest.destination_type == "dlt.destinations.filesystem"
    creds = dest.config_params["credentials"]
    assert isinstance(creds, AzureServicePrincipalCredentialsWithoutDefaults)


def test_delta_dispatch_with_azure_url_default_auth() -> None:
    from dlt.common.configuration.specs import AzureCredentials as DltAzureCredentials

    target = TargetConfig(
        destination="delta",
        credentials={
            "bucket_url": "abfss://lake@acct.dfs.core.windows.net/warehouse",
            "auth": "default",
        },
    )
    dest, _, _ = _build_destination(target)
    assert dest.destination_type == "dlt.destinations.filesystem"
    assert isinstance(dest.config_params["credentials"], DltAzureCredentials)


def test_delta_dispatch_with_azure_url_missing_auth_raises() -> None:
    import pydantic

    target = TargetConfig(
        destination="delta",
        credentials={"bucket_url": "abfss://lake@acct.dfs.core.windows.net/warehouse"},
    )
    with pytest.raises(pydantic.ValidationError):
        _build_destination(target)


def test_delta_dispatch_local_url_passes_no_credentials() -> None:
    """Regression: local Delta target still constructs without credentials."""
    target = TargetConfig(destination="delta", credentials={"bucket_url": "./das_delta"})
    dest, _, _ = _build_destination(target)
    # The local-Delta case forwards credentials=None to dlt's filesystem factory.
    assert dest.config_params.get("credentials") is None


def test_delta_dispatch_onelake_passes_deltalake_storage_options(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """OneLake URL → deltalake_storage_options includes use_fabric_endpoint + bearer."""
    import azure.identity

    class _FakeToken:
        token = "fake-bearer-jwt"

    class _FakeCred:
        def get_token(self, scope: str) -> _FakeToken:
            return _FakeToken()

    monkeypatch.setattr(azure.identity, "ClientSecretCredential", lambda **kw: _FakeCred())
    monkeypatch.setattr(azure.identity, "DefaultAzureCredential", lambda: _FakeCred())

    target = TargetConfig(
        destination="delta",
        credentials={
            "bucket_url": "abfss://ws@onelake.dfs.fabric.microsoft.com/lh/Tables",
            "auth": "service_principal",
            "tenant_id": "tid",
            "client_id": "cid",
            "client_secret": "secret",
        },
    )
    dest, _, _ = _build_destination(target)
    assert dest.config_params["deltalake_storage_options"] == {
        "use_fabric_endpoint": "true",
        "bearer_token": "fake-bearer-jwt",
    }
