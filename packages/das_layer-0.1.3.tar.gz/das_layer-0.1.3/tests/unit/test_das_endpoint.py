"""Unit tests for DasEndpoint model and paginator registry."""

from __future__ import annotations

from pathlib import Path

import pytest
from pydantic import ValidationError

from das_cli.contracts.das_endpoint import (
    PAGINATOR_REGISTRY,
    DasEndpoint,
    MissingEndpointError,
    build_paginator,
    resolve_endpoint,
    synthesize_odata_endpoint,
)
from das_cli.contracts.loader import LoadedContract
from das_cli.contracts.odcs import (
    CustomProperty,
    OdcsContract,
    OdcsInfo,
    OdcsProperty,
    OdcsSchema,
)


def test_minimal_endpoint_only_path() -> None:
    ep = DasEndpoint.model_validate({"path": "/Customers"})
    assert ep.path == "/Customers"
    assert ep.method == "GET"
    assert ep.response_path is None
    assert ep.pagination == {"type": "none"}
    assert ep.query_params == {}
    assert ep.headers == {}


def test_full_endpoint_round_trip() -> None:
    raw = {
        "method": "GET",
        "path": "/Customers",
        "response_path": "$.value",
        "pagination": {"type": "json_link", "next_url_path": '"@odata.nextLink"'},
        "query_params": {"api-version": "v1"},
        "headers": {"X-Tenant-Id": "foo"},
    }
    ep = DasEndpoint.model_validate(raw)
    assert ep.path == "/Customers"
    assert ep.response_path == "$.value"
    assert ep.pagination["type"] == "json_link"
    assert ep.query_params == {"api-version": "v1"}


def test_path_must_start_with_slash() -> None:
    with pytest.raises(ValidationError):
        DasEndpoint.model_validate({"path": "Customers"})


def test_path_required() -> None:
    with pytest.raises(ValidationError):
        DasEndpoint.model_validate({})


def test_method_must_be_get_in_v02() -> None:
    with pytest.raises(ValidationError):
        DasEndpoint.model_validate({"path": "/x", "method": "POST"})


def test_response_path_must_be_supported_subset() -> None:
    DasEndpoint.model_validate({"path": "/x", "response_path": None})
    DasEndpoint.model_validate({"path": "/x", "response_path": "$.value"})
    DasEndpoint.model_validate({"path": "/x", "response_path": "$.data"})
    with pytest.raises(ValidationError):
        DasEndpoint.model_validate({"path": "/x", "response_path": "$.a.b"})
    with pytest.raises(ValidationError):
        DasEndpoint.model_validate({"path": "/x", "response_path": "value"})


def test_pagination_requires_type() -> None:
    with pytest.raises(ValidationError):
        DasEndpoint.model_validate({"path": "/x", "pagination": {}})


def test_query_params_scalars_only() -> None:
    DasEndpoint.model_validate({"path": "/x", "query_params": {"a": "v", "b": 1, "c": True}})
    with pytest.raises(ValidationError):
        DasEndpoint.model_validate({"path": "/x", "query_params": {"a": ["v"]}})
    with pytest.raises(ValidationError):
        DasEndpoint.model_validate({"path": "/x", "query_params": {"a": {"x": 1}}})


def test_paginator_registry_covers_dlt_built_ins() -> None:
    assert "none" in PAGINATOR_REGISTRY
    assert "json_link" in PAGINATOR_REGISTRY
    assert "header_link" in PAGINATOR_REGISTRY
    assert "offset" in PAGINATOR_REGISTRY
    assert "page_number" in PAGINATOR_REGISTRY


def test_build_paginator_none_returns_single_page() -> None:
    from dlt.sources.helpers.rest_client.paginators import SinglePagePaginator

    p = build_paginator({"type": "none"})
    assert isinstance(p, SinglePagePaginator)


def test_build_paginator_json_link_passes_kwargs() -> None:
    from dlt.sources.helpers.rest_client.paginators import JSONLinkPaginator

    p = build_paginator({"type": "json_link", "next_url_path": '"@odata.nextLink"'})
    assert isinstance(p, JSONLinkPaginator)


def test_build_paginator_json_link_extracts_odata_next_link() -> None:
    """Behavioral test: paginator built from the synthesized OData pagination
    config must extract `@odata.nextLink` from a real OData-shape response.

    Regression: jsonpath_ng treats the unquoted `@odata.nextLink` as
    Child(Fields('@odata'), Fields('nextLink')) and finds nothing on
    a flat key `"@odata.nextLink"`. See issue #70.
    """
    from unittest.mock import MagicMock

    # Build paginator the same way the source factory does.
    c = _contract(
        "customers",
        CustomProperty(
            property="das.spec_ref",
            value={"kind": "odata", "type": "Customer", "entity_set": "Customers"},
        ),
    )
    ep = synthesize_odata_endpoint(c)
    paginator = build_paginator(ep.pagination)

    # Real OData server response shape.
    odata_response = {
        "@odata.context": "https://demo/$metadata#Customers",
        "@odata.nextLink": "https://demo/Customers?$skip=500",
        "value": [{"id": i} for i in range(500)],
    }
    resp = MagicMock()
    resp.json.return_value = odata_response

    paginator.update_state(resp, data=odata_response["value"])
    assert paginator.has_next_page is True
    assert paginator._next_reference == "https://demo/Customers?$skip=500"


def test_build_paginator_json_link_stops_when_no_next_link() -> None:
    """Last page: server omits `@odata.nextLink`; paginator must halt."""
    from unittest.mock import MagicMock

    c = _contract(
        "customers",
        CustomProperty(
            property="das.spec_ref",
            value={"kind": "odata", "type": "Customer", "entity_set": "Customers"},
        ),
    )
    paginator = build_paginator(synthesize_odata_endpoint(c).pagination)

    last_page = {
        "@odata.context": "https://demo/$metadata#Customers",
        "value": [{"id": 1}],
    }
    resp = MagicMock()
    resp.json.return_value = last_page

    paginator.update_state(resp, data=last_page["value"])
    assert paginator.has_next_page is False


def test_build_paginator_unknown_type_raises() -> None:
    with pytest.raises(ValueError, match="unknown pagination type"):
        build_paginator({"type": "made_up"})


def _contract(resource: str, *cps: CustomProperty) -> LoadedContract:
    contract = OdcsContract(
        apiVersion="v3.0.0",
        kind="DataContract",
        id=f"x.{resource}",
        name=resource,
        version="0.1.0",
        status="draft",
        info=OdcsInfo(title=resource),
        schema=[
            OdcsSchema(
                name=resource,
                physicalName=resource,
                physicalType="table",
                properties=[
                    OdcsProperty(name="id", logicalType="integer", primaryKey=True, required=True),
                ],
            )
        ],
        customProperties=list(cps),
    )
    return LoadedContract(
        path=Path(f"{resource}.odcs.yaml"), resource_name=resource, contract=contract
    )


def test_synthesize_odata_uses_spec_ref_type() -> None:
    c = _contract(
        "products",
        CustomProperty(property="das.spec_ref", value={"kind": "odata", "type": "Product"}),
    )
    ep = synthesize_odata_endpoint(c)
    assert ep.path == "/Products"
    assert ep.response_path == "$.value"
    # See issue #70: jsonpath_ng requires the dotted key to be quoted so it's
    # treated as a single field name, not a nested path.
    assert ep.pagination == {"type": "json_link", "next_url_path": '"@odata.nextLink"'}


def test_synthesize_odata_falls_back_to_resource_name_when_no_spec_ref() -> None:
    c = _contract("products")
    ep = synthesize_odata_endpoint(c)
    assert ep.path == "/products"


def test_synthesize_uses_entity_set_when_present() -> None:
    """Authoritative entity_set wins over the heuristic."""
    c = _contract(
        "address",
        CustomProperty(
            property="das.spec_ref",
            value={"kind": "odata", "type": "Address", "entity_set": "Addresses"},
        ),
    )
    ep = synthesize_odata_endpoint(c)
    assert ep.path == "/Addresses"


def test_synthesize_heuristic_handles_plus_es() -> None:
    """No entity_set → pluralize_preserving_case kicks in. Address → Addresses."""
    c = _contract(
        "address",
        CustomProperty(property="das.spec_ref", value={"kind": "odata", "type": "Address"}),
    )
    ep = synthesize_odata_endpoint(c)
    assert ep.path == "/Addresses"


def test_synthesize_heuristic_handles_y_to_ies() -> None:
    """No entity_set → Currency → Currencies via y→ies."""
    c = _contract(
        "currencies",
        CustomProperty(property="das.spec_ref", value={"kind": "odata", "type": "Currency"}),
    )
    ep = synthesize_odata_endpoint(c)
    assert ep.path == "/Currencies"


def test_synthesize_heuristic_handles_business_entity() -> None:
    """No entity_set → BusinessEntity → BusinessEntities via y→ies."""
    c = _contract(
        "business_entities",
        CustomProperty(property="das.spec_ref", value={"kind": "odata", "type": "BusinessEntity"}),
    )
    ep = synthesize_odata_endpoint(c)
    assert ep.path == "/BusinessEntities"


def test_synthesize_entity_set_overrides_heuristic() -> None:
    """If entity_set is present, it wins even when the heuristic disagrees.

    Useful when $metadata declares a custom EntitySet name unrelated to its
    EntityType (e.g., set 'People' for type 'Person')."""
    c = _contract(
        "people",
        CustomProperty(
            property="das.spec_ref",
            value={"kind": "odata", "type": "Person", "entity_set": "People"},
        ),
    )
    ep = synthesize_odata_endpoint(c)
    assert ep.path == "/People"


def test_synthesize_falls_back_to_resource_name_when_spec_ref_lacks_type_and_entity_set() -> None:
    """A degraded spec_ref (dict with kind only) falls through to resource_name."""
    c = _contract(
        "customers",
        CustomProperty(property="das.spec_ref", value={"kind": "odata"}),
    )
    ep = synthesize_odata_endpoint(c)
    assert ep.path == "/customers"


def test_resolve_explicit_endpoint_wins() -> None:
    c = _contract(
        "customers",
        CustomProperty(
            property="das.endpoint",
            value={"path": "/Customers", "response_path": None},
        ),
        CustomProperty(property="das.spec_ref", value={"kind": "openapi", "path": "x"}),
    )
    ep = resolve_endpoint(c, source_type="openapi")
    assert ep.path == "/Customers"
    assert ep.response_path is None


def test_resolve_odata_synthesizes_when_missing() -> None:
    c = _contract(
        "products",
        CustomProperty(property="das.spec_ref", value={"kind": "odata", "type": "Product"}),
    )
    ep = resolve_endpoint(c, source_type="odata")
    assert ep.path == "/Products"


def test_resolve_openapi_missing_endpoint_raises() -> None:
    c = _contract("customer_dtos")
    with pytest.raises(MissingEndpointError, match="customer_dtos"):
        resolve_endpoint(c, source_type="openapi")


def test_resolve_rest_missing_endpoint_raises() -> None:
    c = _contract("customer_dtos")
    with pytest.raises(MissingEndpointError):
        resolve_endpoint(c, source_type="rest")
