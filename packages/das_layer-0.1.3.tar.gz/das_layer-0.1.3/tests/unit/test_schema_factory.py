"""Unit tests for schema_factory helpers and column mapping."""

from __future__ import annotations

from decimal import Decimal

import pytest

from das_cli.contracts.odcs import OdcsContract, OdcsProperty
from das_cli.dlt_glue.schema_factory import (
    build_dlt_columns,
    coerce_decimal,
    is_decimal_column,
    primary_keys_for,
)


def make_contract(properties: list[dict[str, object]]) -> OdcsContract:
    return OdcsContract.model_validate(
        {
            "apiVersion": "v3.0.0",
            "kind": "DataContract",
            "id": "x.y",
            "name": "y",
            "version": "0.1.0",
            "status": "draft",
            "schema": [
                {
                    "name": "y",
                    "physicalName": "y",
                    "physicalType": "table",
                    "properties": properties,
                }
            ],
        }
    )


def test_string_maps_to_text() -> None:
    c = make_contract([{"name": "x", "logicalType": "string"}])
    cols = build_dlt_columns(c)
    assert cols["x"]["data_type"] == "text"


def test_integer_maps_to_bigint() -> None:
    c = make_contract([{"name": "x", "logicalType": "integer"}])
    cols = build_dlt_columns(c)
    assert cols["x"]["data_type"] == "bigint"


def test_decimal_with_precision_scale() -> None:
    c = make_contract([{"name": "x", "logicalType": "number", "physicalType": "decimal(19,4)"}])
    cols = build_dlt_columns(c)
    assert cols["x"]["data_type"] == "decimal"
    assert cols["x"]["precision"] == 19
    assert cols["x"]["scale"] == 4


def test_number_without_physical_type_maps_to_double() -> None:
    c = make_contract([{"name": "x", "logicalType": "number"}])
    cols = build_dlt_columns(c)
    assert cols["x"]["data_type"] == "double"


def test_boolean_maps_to_bool() -> None:
    c = make_contract([{"name": "x", "logicalType": "boolean"}])
    cols = build_dlt_columns(c)
    assert cols["x"]["data_type"] == "bool"


def test_required_becomes_not_nullable() -> None:
    c = make_contract([{"name": "x", "logicalType": "string", "required": True}])
    cols = build_dlt_columns(c)
    assert cols["x"]["nullable"] is False


def test_primary_key_propagates() -> None:
    c = make_contract([{"name": "x", "logicalType": "integer", "primaryKey": True}])
    cols = build_dlt_columns(c)
    assert cols["x"]["primary_key"] is True


def test_row_hash_column_added() -> None:
    c = make_contract([{"name": "x", "logicalType": "string"}])
    cols = build_dlt_columns(c)
    assert "_row_hash" in cols
    assert cols["_row_hash"]["data_type"] == "text"
    assert cols["_row_hash"]["nullable"] is False


def test_primary_keys_for_collects_pk_names() -> None:
    c = make_contract(
        [
            {"name": "a", "logicalType": "integer", "primaryKey": True},
            {"name": "b", "logicalType": "integer", "primaryKey": True},
            {"name": "c", "logicalType": "string"},
        ]
    )
    assert primary_keys_for(c) == ["a", "b"]


def test_metadata_columns_added() -> None:
    """build_dlt_columns must add _extracted_at/_on, _loaded_at/_on, _row_hash."""
    c = make_contract([{"name": "x", "logicalType": "string"}])
    cols = build_dlt_columns(c)
    expected = {
        "_extracted_at": ("timestamp", False),
        "_extracted_on": ("date", False),
        "_loaded_at": ("timestamp", False),
        "_loaded_on": ("date", False),
        "_row_hash": ("text", False),
    }
    for name, (data_type, nullable) in expected.items():
        assert name in cols, f"missing column {name}"
        assert cols[name]["data_type"] == data_type, f"{name}: wrong data_type"
        assert cols[name]["nullable"] is nullable, f"{name}: wrong nullable"


def test_unknown_decimal_format_raises() -> None:
    c = make_contract([{"name": "x", "logicalType": "number", "physicalType": "decimal(bad)"}])
    with pytest.raises(ValueError):
        build_dlt_columns(c)


# ---------------------------------------------------------------------------
# Helpers: is_decimal_column, coerce_decimal
# ---------------------------------------------------------------------------


def _prop(**kw: object) -> OdcsProperty:
    base = {
        "name": "amount",
        "logicalType": "number",
        "physicalType": "decimal(12,2)",
        "required": False,
        "primaryKey": False,
    }
    base.update(kw)
    return OdcsProperty.model_validate(base)


def test_coerce_decimal_passes_through_none() -> None:
    assert coerce_decimal(None) is None


def test_coerce_decimal_returns_existing_decimal_unchanged() -> None:
    d = Decimal("1234.56")
    assert coerce_decimal(d) is d


def test_coerce_decimal_parses_string() -> None:
    assert coerce_decimal("1234.56") == Decimal("1234.56")


def test_coerce_decimal_parses_int() -> None:
    assert coerce_decimal(42) == Decimal("42")


def test_coerce_decimal_parses_float_via_str_avoiding_binary_artefacts() -> None:
    # str(0.1) == "0.1" — Decimal(0.1) would yield 0.10000000000000000555...
    assert coerce_decimal(0.1) == Decimal("0.1")


def test_is_decimal_column_true_for_number_logical_with_decimal_physical() -> None:
    assert is_decimal_column(_prop()) is True


def test_is_decimal_column_false_for_other_logical_types() -> None:
    assert is_decimal_column(_prop(logicalType="string", physicalType="varchar(10)")) is False


def test_is_decimal_column_false_for_double_physical() -> None:
    assert is_decimal_column(_prop(physicalType="double")) is False


def test_is_decimal_column_false_when_physical_type_missing() -> None:
    assert is_decimal_column(_prop(physicalType=None)) is False
