"""Unit tests for doctor's Azure credentials checks. See ADR-0020."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest

from das_cli.doctor import run_doctor


def _write_workspace(
    tmp_path: Path,
    landing_url: str,
    target_creds: dict[str, Any],
    landing_creds: dict[str, Any],
) -> Path:
    import yaml

    (tmp_path / "contracts").mkdir()
    config = {
        "target": {
            "destination": "delta",
            "credentials": target_creds,
        },
        "landing": {
            "bucket_url": landing_url,
            "credentials": landing_creds,
        },
        "contracts": {"root": "./contracts"},
    }
    (tmp_path / "das.yaml").write_text(yaml.safe_dump(config))
    return tmp_path / "das.yaml"


def _clear_azure_env(monkeypatch: pytest.MonkeyPatch) -> None:
    for var in (
        "AZURE_TENANT_ID",
        "AZURE_CLIENT_ID",
        "AZURE_CLIENT_SECRET",
        "AZURE_USERNAME",
        "AZURE_FEDERATED_TOKEN_FILE",
    ):
        monkeypatch.delenv(var, raising=False)
    # Prepend a directory that does not contain `az` so the shutil.which lookup fails.
    monkeypatch.setenv("PATH", str(Path("/nonexistent")))


def test_doctor_flags_missing_azure_auth_on_landing(tmp_path: Path) -> None:
    cfg = _write_workspace(
        tmp_path,
        landing_url="abfss://lake@acct.dfs.core.windows.net/landing",
        target_creds={"bucket_url": "./das_delta"},
        landing_creds={},
    )
    issues = run_doctor(cfg)
    msgs = [i.message for i in issues if i.component == "landing"]
    assert any("azure credentials invalid" in m for m in msgs)


def test_doctor_flags_missing_azure_auth_on_target(tmp_path: Path) -> None:
    cfg = _write_workspace(
        tmp_path,
        landing_url="./landing",
        target_creds={"bucket_url": "abfss://lake@acct.dfs.core.windows.net/warehouse"},
        landing_creds={},
    )
    issues = run_doctor(cfg)
    msgs = [i.message for i in issues if i.component == "target"]
    assert any("azure credentials invalid" in m for m in msgs)


def test_doctor_warns_on_default_without_env_or_cli(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _clear_azure_env(monkeypatch)
    cfg = _write_workspace(
        tmp_path,
        landing_url="abfss://lake@acct.dfs.core.windows.net/landing",
        target_creds={"bucket_url": "./das_delta"},
        landing_creds={"auth": "default"},
    )
    issues = run_doctor(cfg)
    msgs = [i.message for i in issues if i.component == "landing"]
    assert any("auth: default" in m and "AZURE_" in m for m in msgs)


def test_doctor_silent_on_default_with_env_present(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _clear_azure_env(monkeypatch)
    monkeypatch.setenv("AZURE_CLIENT_ID", "cid")
    cfg = _write_workspace(
        tmp_path,
        landing_url="abfss://lake@acct.dfs.core.windows.net/landing",
        target_creds={"bucket_url": "./das_delta"},
        landing_creds={"auth": "default"},
    )
    issues = run_doctor(cfg)
    msgs = [i.message for i in issues if i.component == "landing"]
    assert not any("auth: default" in m for m in msgs)


def test_doctor_silent_on_service_principal(tmp_path: Path) -> None:
    cfg = _write_workspace(
        tmp_path,
        landing_url="abfss://lake@acct.dfs.core.windows.net/landing",
        target_creds={"bucket_url": "./das_delta"},
        landing_creds={
            "auth": "service_principal",
            "tenant_id": "tid",
            "client_id": "cid",
            "client_secret": "secret",
        },
    )
    issues = run_doctor(cfg)
    msgs = [i.message for i in issues if i.component == "landing"]
    assert msgs == []
