"""Unit tests for filesystem source factory dispatch. See ADR-0022."""

from __future__ import annotations

from pathlib import Path

import pytest

from das_cli.contracts.loader import LoadedContract
from das_cli.contracts.odcs import (
    CustomProperty,
    OdcsContract,
    OdcsInfo,
    OdcsProperty,
    OdcsSchema,
)
from das_cli.dlt_glue.source_factory import build_extract_resources
from das_cli.models.source_yml import SourceConfig


def _make_fs_contract(
    resource: str,
    *,
    spec_ref: dict[str, object] | None = None,
) -> LoadedContract:
    spec_ref = spec_ref or {
        "kind": "filesystem",
        "format": "csv",
        "path": f"{resource}.csv",
    }
    contract = OdcsContract(
        apiVersion="v3.0.0",
        kind="DataContract",
        id=f"files.{resource}",
        name=resource,
        version="0.1.0",
        status="draft",
        info=OdcsInfo(title=resource),
        schema=[
            OdcsSchema(
                name=resource,
                physicalName=resource,
                physicalType="table",
                properties=[
                    OdcsProperty(name="id", logicalType="integer", primaryKey=True, required=True),
                ],
            )
        ],
        customProperties=[CustomProperty(property="das.spec_ref", value=spec_ref)],
    )
    return LoadedContract(
        path=Path(f"{resource}.odcs.yaml"), resource_name=resource, contract=contract
    )


def _fs_scfg(endpoint: str = "./data/") -> SourceConfig:
    return SourceConfig.model_validate(
        {
            "type": "filesystem",
            "endpoint": endpoint,
            "spec": {"kind": "filesystem"},
            "auth": {"type": "none"},
        }
    )


def test_filesystem_dispatch_returns_one_resource_per_contract(tmp_path: Path) -> None:
    contracts = [_make_fs_contract("customers"), _make_fs_contract("orders")]
    resources = build_extract_resources(
        _fs_scfg(endpoint=str(tmp_path)), contracts, source_name="files"
    )
    assert len(resources) == 2


def test_filesystem_dispatch_resource_name_matches_contract(tmp_path: Path) -> None:
    contracts = [_make_fs_contract("customers"), _make_fs_contract("orders")]
    resources = build_extract_resources(
        _fs_scfg(endpoint=str(tmp_path)), contracts, source_name="files"
    )
    names = sorted(r.name for r in resources)
    assert names == ["customers", "orders"]


def test_filesystem_csv_resource_yields_blob_wrapped_rows(tmp_path: Path) -> None:
    """Smoke: drop a real CSV in tmp_path and assert the resource produces blobs."""
    (tmp_path / "customers.csv").write_text("id,name\n1,Alice\n2,Bob\n")
    contracts = [_make_fs_contract("customers")]
    resources = build_extract_resources(
        _fs_scfg(endpoint=str(tmp_path)), contracts, source_name="files"
    )
    out = list(resources[0])
    assert out == [
        {"_data": {"id": "1", "name": "Alice"}},
        {"_data": {"id": "2", "name": "Bob"}},
    ]


def test_filesystem_unknown_format_raises(tmp_path: Path) -> None:
    # Bypass FilesystemSpecRef validation by constructing the contract with a
    # raw value (Pydantic at the validator boundary would catch this in
    # workspace-level validation, but the factory should also defend itself).
    contracts = [
        _make_fs_contract(
            "weird",
            spec_ref={"kind": "filesystem", "format": "parquet", "path": "x.parquet"},
        )
    ]
    with pytest.raises(ValueError, match="No file reader for format"):
        build_extract_resources(_fs_scfg(endpoint=str(tmp_path)), contracts, source_name="files")


def test_filesystem_excel_resource_yields_blob_wrapped_rows(tmp_path: Path) -> None:
    """Smoke: drop an xlsx in tmp_path, dispatch via format=excel, assert blobs."""
    import io

    import openpyxl

    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    ws = wb.create_sheet("Customers")
    ws.append(["id", "name"])
    ws.append([1, "Alice"])
    ws.append([2, "Bob"])
    buf = io.BytesIO()
    wb.save(buf)
    (tmp_path / "wb.xlsx").write_bytes(buf.getvalue())

    contracts = [
        _make_fs_contract(
            "customers",
            spec_ref={
                "kind": "filesystem",
                "format": "excel",
                "path": "wb.xlsx",
                "sheet": "Customers",
            },
        )
    ]
    resources = build_extract_resources(
        _fs_scfg(endpoint=str(tmp_path)), contracts, source_name="files"
    )
    out = list(resources[0])
    assert out == [
        {"_data": {"id": 1, "name": "Alice"}},
        {"_data": {"id": 2, "name": "Bob"}},
    ]


def test_filesystem_xml_resource_yields_blob_wrapped_rows(tmp_path: Path) -> None:
    """Smoke: drop an XML file in tmp_path, dispatch via format=xml, assert blobs."""
    (tmp_path / "customers.xml").write_text(
        '<?xml version="1.0"?>\n'
        "<customers>\n"
        "  <customer><id>1</id><name>Alice</name></customer>\n"
        "  <customer><id>2</id><name>Bob</name></customer>\n"
        "</customers>\n"
    )

    contracts = [
        _make_fs_contract(
            "customers",
            spec_ref={
                "kind": "filesystem",
                "format": "xml",
                "path": "customers.xml",
                "xpath": "//customer",
            },
        )
    ]
    resources = build_extract_resources(
        _fs_scfg(endpoint=str(tmp_path)), contracts, source_name="files"
    )
    out = list(resources[0])
    assert out == [
        {"_data": {"id": "1", "name": "Alice"}},
        {"_data": {"id": "2", "name": "Bob"}},
    ]


def test_filesystem_qvd_resource_yields_blob_wrapped_rows(tmp_path: Path) -> None:
    """Smoke: write a QVD in tmp_path, dispatch via format=qvd, assert blobs."""
    import io as _io

    from pyqvd import QvdTable

    t = QvdTable.from_dict({"columns": ["id", "name"], "data": [[1, "Alice"], [2, "Bob"]]})
    buf = _io.BytesIO()
    t.to_stream(buf)
    (tmp_path / "customers.qvd").write_bytes(buf.getvalue())

    contracts = [
        _make_fs_contract(
            "customers",
            spec_ref={
                "kind": "filesystem",
                "format": "qvd",
                "path": "customers.qvd",
            },
        )
    ]
    resources = build_extract_resources(
        _fs_scfg(endpoint=str(tmp_path)), contracts, source_name="files"
    )
    out = list(resources[0])
    assert out == [
        {"_data": {"id": 1, "name": "Alice"}},
        {"_data": {"id": 2, "name": "Bob"}},
    ]
