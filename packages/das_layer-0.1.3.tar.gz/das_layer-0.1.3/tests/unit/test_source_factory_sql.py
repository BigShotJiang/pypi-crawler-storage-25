"""Unit tests for SQL source factory dispatch. See ADR-0018."""

from __future__ import annotations

from pathlib import Path

from das_cli.contracts.loader import LoadedContract
from das_cli.contracts.odcs import (
    CustomProperty,
    OdcsContract,
    OdcsInfo,
    OdcsProperty,
    OdcsSchema,
)
from das_cli.dlt_glue.source_factory import (
    build_extract_resources,
)
from das_cli.models.source_yml import SourceConfig


def _make_sql_contract(
    resource: str,
    *,
    table: str | None = None,
    schema: str | None = None,
    cursor: str | None = None,
) -> LoadedContract:
    custom_props = [
        CustomProperty(
            property="das.spec_ref",
            value={"kind": "sql", "schema": schema, "table": table or resource},
        ),
    ]
    if cursor:
        custom_props.append(CustomProperty(property="das.cursor", value=cursor))
    contract = OdcsContract(
        apiVersion="v3.0.0",
        kind="DataContract",
        id=f"x.{resource}",
        name=resource,
        version="0.1.0",
        status="draft",
        info=OdcsInfo(title=resource),
        schema=[
            OdcsSchema(
                name=resource,
                physicalName=table or resource,
                physicalType="table",
                properties=[
                    OdcsProperty(name="id", logicalType="integer", primaryKey=True, required=True),
                ],
            )
        ],
        customProperties=custom_props,
    )
    return LoadedContract(
        path=Path(f"{resource}.odcs.yaml"), resource_name=resource, contract=contract
    )


def _sql_scfg(url: str = "sqlite:///:memory:") -> SourceConfig:
    return SourceConfig.model_validate(
        {"type": "sql", "endpoint": url, "spec": {"kind": "sql"}, "auth": {"type": "none"}}
    )


def test_sql_dispatch_returns_one_resource_per_contract() -> None:
    contracts = [_make_sql_contract("customers"), _make_sql_contract("orders")]
    resources = build_extract_resources(_sql_scfg(), contracts, source_name="x")
    assert len(resources) == 2


def test_sql_dispatch_resource_name_matches_contract() -> None:
    contracts = [_make_sql_contract("customers"), _make_sql_contract("orders")]
    resources = build_extract_resources(_sql_scfg(), contracts, source_name="x")
    names = sorted(r.name for r in resources)
    assert names == ["customers", "orders"]


def test_filesystem_now_dispatches_to_filesystem_branch() -> None:
    """Filesystem used to raise UnknownSourceTypeError; ADR-0022 makes it dispatch."""
    scfg = SourceConfig.model_validate(
        {
            "type": "filesystem",
            "endpoint": "file:///tmp",
            "spec": {"kind": "filesystem"},
            "auth": {"type": "none"},
        }
    )
    # A bare filesystem source with no contracts should produce an empty list,
    # not raise UnknownSourceTypeError.
    resources = build_extract_resources(scfg, [], source_name="x")
    assert resources == []
