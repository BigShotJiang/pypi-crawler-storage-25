from das_cli.bootstrap.naming import pluralize, pluralize_preserving_case, snake_case


def test_camel_case() -> None:
    assert snake_case("ProductId") == "product_id"
    assert snake_case("ListPrice") == "list_price"
    assert snake_case("ProductNumber") == "product_number"


def test_acronyms() -> None:
    assert snake_case("URLSlug") == "url_slug"
    assert snake_case("HTTPSConnection") == "https_connection"


def test_already_snake() -> None:
    assert snake_case("already_snake") == "already_snake"


def test_all_lower() -> None:
    assert snake_case("name") == "name"


def test_with_digits() -> None:
    assert snake_case("AddressLine1") == "address_line1"


def test_empty() -> None:
    assert snake_case("") == ""


# --- pluralize ---


def test_pluralize_common() -> None:
    assert pluralize("Product") == "products"
    assert pluralize("Order") == "orders"
    assert pluralize("Customer") == "customers"


def test_pluralize_already_plural() -> None:
    assert pluralize("Products") == "products"
    assert pluralize("orders") == "orders"


def test_pluralize_ends_in_y_consonant() -> None:
    # y after consonant → ies
    assert pluralize("Category") == "categories"
    assert pluralize("City") == "cities"


def test_pluralize_ends_in_y_vowel() -> None:
    # y after vowel → keep y + s
    assert pluralize("Day") == "days"
    assert pluralize("Key") == "keys"
    assert pluralize("Boy") == "boys"


def test_pluralize_camel_case_input() -> None:
    # CamelCase is snake-cased first
    assert pluralize("SalesOrder") == "sales_orders"
    # WorkflowStatus → workflow_status → ends in "s" → treated as already plural
    assert pluralize("WorkflowStatus") == "workflow_status"


# --- pluralize_preserving_case ---


def test_pluralize_preserving_case_plus_s() -> None:
    assert pluralize_preserving_case("Product") == "Products"
    assert pluralize_preserving_case("Order") == "Orders"
    assert pluralize_preserving_case("Customer") == "Customers"


def test_pluralize_preserving_case_plus_es_on_consonant_plus_s() -> None:
    # Singular EntityType names that end in -s require +es. OData conventionally
    # uses singular names, so we do NOT pass these through as already-plural.
    assert pluralize_preserving_case("Address") == "Addresses"
    assert pluralize_preserving_case("EmailAddress") == "EmailAddresses"
    assert pluralize_preserving_case("Status") == "Statuses"
    assert pluralize_preserving_case("Class") == "Classes"


def test_pluralize_preserving_case_plus_es_on_x_z_ch_sh() -> None:
    assert pluralize_preserving_case("Box") == "Boxes"
    assert pluralize_preserving_case("Quartz") == "Quartzes"
    assert pluralize_preserving_case("Match") == "Matches"
    assert pluralize_preserving_case("Dish") == "Dishes"


def test_pluralize_preserving_case_y_to_ies_after_consonant() -> None:
    assert pluralize_preserving_case("Currency") == "Currencies"
    assert pluralize_preserving_case("BusinessEntity") == "BusinessEntities"
    assert pluralize_preserving_case("SalesTerritory") == "SalesTerritories"
    assert pluralize_preserving_case("TransactionHistory") == "TransactionHistories"


def test_pluralize_preserving_case_y_after_vowel_keeps_y_plus_s() -> None:
    assert pluralize_preserving_case("Day") == "Days"
    assert pluralize_preserving_case("Key") == "Keys"
    assert pluralize_preserving_case("Boy") == "Boys"


def test_pluralize_preserving_case_empty() -> None:
    assert pluralize_preserving_case("") == ""
