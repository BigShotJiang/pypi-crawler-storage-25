"""Unit tests for AzureCredentials Pydantic models and is_azure_url."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from das_cli.models.das_yaml import (
    AzureDefaultAuth,
    AzureServicePrincipalAuth,
    is_azure_url,
    parse_azure_credentials,
)


def test_is_azure_url_matches_abfss() -> None:
    assert is_azure_url("abfss://lake@acct.dfs.core.windows.net/path") is True


def test_is_azure_url_matches_abfs() -> None:
    assert is_azure_url("abfs://lake@acct.dfs.core.windows.net/path") is True


def test_is_azure_url_matches_az() -> None:
    assert is_azure_url("az://lake/path") is True


def test_is_azure_url_rejects_local_file() -> None:
    assert is_azure_url("file:///tmp/landing") is False


def test_is_azure_url_rejects_bare_path() -> None:
    assert is_azure_url("./landing") is False


def test_is_azure_url_rejects_s3() -> None:
    assert is_azure_url("s3://bucket/key") is False


def test_parse_returns_none_for_non_azure_url() -> None:
    out = parse_azure_credentials({"some": "thing"}, "./landing")
    assert out is None


def test_parse_service_principal() -> None:
    out = parse_azure_credentials(
        {
            "auth": "service_principal",
            "tenant_id": "tid",
            "client_id": "cid",
            "client_secret": "secret",
        },
        "abfss://lake@acct.dfs.core.windows.net/path",
    )
    assert isinstance(out, AzureServicePrincipalAuth)
    assert out.tenant_id == "tid"
    assert out.client_id == "cid"
    assert out.client_secret == "secret"


def test_parse_default_auth() -> None:
    out = parse_azure_credentials(
        {"auth": "default"},
        "abfss://lake@acct.dfs.core.windows.net/path",
    )
    assert isinstance(out, AzureDefaultAuth)


def test_parse_empty_creds_on_azure_url_raises() -> None:
    with pytest.raises(ValidationError):
        parse_azure_credentials({}, "abfss://lake@acct.dfs.core.windows.net/path")


def test_parse_missing_sp_field_raises() -> None:
    with pytest.raises(ValidationError):
        parse_azure_credentials(
            {"auth": "service_principal", "tenant_id": "tid", "client_id": "cid"},
            "abfss://lake@acct.dfs.core.windows.net/path",
        )


def test_parse_extra_field_in_default_raises() -> None:
    with pytest.raises(ValidationError):
        parse_azure_credentials(
            {"auth": "default", "tenant_id": "tid"},
            "abfss://lake@acct.dfs.core.windows.net/path",
        )


def test_build_dlt_creds_service_principal_returns_typed_class() -> None:
    from dlt.common.configuration.specs import (
        AzureServicePrincipalCredentialsWithoutDefaults,
    )

    from das_cli.dlt_glue.azure_credentials import build_dlt_azure_credentials

    auth = AzureServicePrincipalAuth(
        auth="service_principal",
        tenant_id="tid",
        client_id="cid",
        client_secret="secret",
    )
    out = build_dlt_azure_credentials(
        auth, bucket_url="abfss://lake@acct.dfs.core.windows.net/warehouse"
    )
    assert isinstance(out, AzureServicePrincipalCredentialsWithoutDefaults)
    assert out.azure_tenant_id == "tid"
    assert out.azure_client_id == "cid"
    assert out.azure_client_secret == "secret"
    assert out.azure_storage_account_name == "acct"


def test_build_dlt_creds_default_returns_dlt_azure_credentials_for_adls() -> None:
    """For standard ADLS Gen2 + default auth: AzureCredentials (default chain)."""
    from dlt.common.configuration.specs import AzureCredentials as DltAzureCredentials

    from das_cli.dlt_glue.azure_credentials import build_dlt_azure_credentials

    auth = AzureDefaultAuth(auth="default")
    out = build_dlt_azure_credentials(
        auth, bucket_url="abfss://lake@acct.dfs.core.windows.net/landing"
    )
    assert isinstance(out, DltAzureCredentials)
    assert out.azure_storage_account_name == "acct"


def test_build_dlt_creds_onelake_returns_placeholder_sas() -> None:
    """OneLake URL → AzureCredentialsWithoutDefaults with placeholder sas_token.

    The placeholder satisfies dlt's config-resolver. Real auth runs via the
    credential object supplied through `build_adlfs_kwargs`.
    """
    from dlt.common.configuration.specs import (
        AzureCredentialsWithoutDefaults as DltAzureCredentialsWithoutDefaults,
    )

    from das_cli.dlt_glue.azure_credentials import build_dlt_azure_credentials

    sp = AzureServicePrincipalAuth(
        auth="service_principal", tenant_id="t", client_id="c", client_secret="s"
    )
    onelake_url = "abfss://ws@onelake.dfs.fabric.microsoft.com/lh/Files/landing"
    out_sp = build_dlt_azure_credentials(sp, bucket_url=onelake_url)
    assert isinstance(out_sp, DltAzureCredentialsWithoutDefaults)
    assert out_sp.azure_storage_account_name == "onelake"
    # adlfs uses the Blob API for list operations — host rewritten DFS→blob.
    assert out_sp.azure_account_host == "onelake.blob.fabric.microsoft.com"
    # Placeholder, NOT a real token. Real auth goes through build_adlfs_kwargs.
    assert "credential-object" in str(out_sp.azure_storage_sas_token)

    default = AzureDefaultAuth(auth="default")
    out_default = build_dlt_azure_credentials(default, bucket_url=onelake_url)
    assert isinstance(out_default, DltAzureCredentialsWithoutDefaults)
    assert out_default.azure_account_host == "onelake.blob.fabric.microsoft.com"


def test_build_adlfs_kwargs_for_onelake_sp(monkeypatch: pytest.MonkeyPatch) -> None:
    """OneLake + SP → kwargs.credential is a ClientSecretCredential-shaped object."""
    from das_cli.dlt_glue import azure_credentials as ac_mod

    class _FakeCred:
        pass

    import azure.identity

    monkeypatch.setattr(azure.identity, "ClientSecretCredential", lambda **kw: _FakeCred())

    sp = AzureServicePrincipalAuth(
        auth="service_principal", tenant_id="t", client_id="c", client_secret="s"
    )
    out = ac_mod.build_adlfs_kwargs(sp, "abfss://ws@onelake.dfs.fabric.microsoft.com/lh/Files")
    assert set(out.keys()) == {"credential"}
    assert isinstance(out["credential"], _FakeCred)


def test_build_adlfs_kwargs_for_onelake_default(monkeypatch: pytest.MonkeyPatch) -> None:
    """OneLake + default → kwargs.credential is a DefaultAzureCredential-shaped object."""
    from das_cli.dlt_glue import azure_credentials as ac_mod

    class _FakeCred:
        pass

    import azure.identity

    monkeypatch.setattr(azure.identity, "DefaultAzureCredential", lambda: _FakeCred())

    out = ac_mod.build_adlfs_kwargs(
        AzureDefaultAuth(auth="default"),
        "abfss://ws@onelake.dfs.fabric.microsoft.com/lh/Files",
    )
    assert isinstance(out["credential"], _FakeCred)


def test_build_adlfs_kwargs_empty_for_adls_gen2() -> None:
    """Standard ADLS Gen2 → empty kwargs (typed credentials handle it)."""
    from das_cli.dlt_glue.azure_credentials import build_adlfs_kwargs

    sp = AzureServicePrincipalAuth(
        auth="service_principal", tenant_id="t", client_id="c", client_secret="s"
    )
    assert build_adlfs_kwargs(sp, "abfss://lake@acct.dfs.core.windows.net/landing") == {}


def test_build_adlfs_kwargs_empty_when_no_creds() -> None:
    from das_cli.dlt_glue.azure_credentials import build_adlfs_kwargs

    assert build_adlfs_kwargs(None, "abfss://ws@onelake.dfs.fabric.microsoft.com/lh") == {}


def test_is_fabric_url() -> None:
    from das_cli.dlt_glue.azure_credentials import is_fabric_url

    assert is_fabric_url("abfss://ws@onelake.dfs.fabric.microsoft.com/lh/Files") is True
    assert is_fabric_url("abfss://lake@acct.dfs.core.windows.net/landing") is False
    assert is_fabric_url("./landing") is False


def test_build_deltalake_storage_options_for_onelake(monkeypatch: pytest.MonkeyPatch) -> None:
    """OneLake → use_fabric_endpoint + bearer_token (acquired from creds)."""
    from das_cli.dlt_glue.azure_credentials import build_deltalake_storage_options

    class _FakeToken:
        token = "fake-bearer-jwt"

    class _FakeCred:
        def get_token(self, scope: str) -> _FakeToken:
            return _FakeToken()

    import azure.identity

    monkeypatch.setattr(azure.identity, "ClientSecretCredential", lambda **kw: _FakeCred())
    sp = AzureServicePrincipalAuth(
        auth="service_principal", tenant_id="t", client_id="c", client_secret="s"
    )
    opts = build_deltalake_storage_options(
        "abfss://ws@onelake.dfs.fabric.microsoft.com/lh/Tables", sp
    )
    assert opts == {"use_fabric_endpoint": "true", "bearer_token": "fake-bearer-jwt"}


def test_build_deltalake_storage_options_none_for_adls() -> None:
    from das_cli.dlt_glue.azure_credentials import build_deltalake_storage_options

    assert (
        build_deltalake_storage_options(
            "abfss://lake@acct.dfs.core.windows.net/warehouse",
            AzureDefaultAuth(auth="default"),
        )
        is None
    )


def test_build_deltalake_storage_options_none_for_no_creds() -> None:
    from das_cli.dlt_glue.azure_credentials import build_deltalake_storage_options

    assert (
        build_deltalake_storage_options(
            "abfss://ws@onelake.dfs.fabric.microsoft.com/lh/Tables", None
        )
        is None
    )


def test_adlfs_storage_options_service_principal() -> None:
    from das_cli.dlt_glue.azure_credentials import _adlfs_storage_options

    auth = AzureServicePrincipalAuth(
        auth="service_principal",
        tenant_id="tid",
        client_id="cid",
        client_secret="secret",
    )
    assert _adlfs_storage_options(auth) == {
        "tenant_id": "tid",
        "client_id": "cid",
        "client_secret": "secret",
    }


def test_adlfs_storage_options_default() -> None:
    from das_cli.dlt_glue.azure_credentials import _adlfs_storage_options

    assert _adlfs_storage_options(AzureDefaultAuth(auth="default")) == {"anon": False}


def test_adlfs_storage_options_none() -> None:
    from das_cli.dlt_glue.azure_credentials import _adlfs_storage_options

    assert _adlfs_storage_options(None) == {}


def test_build_fabric_secret_sql_uses_full_bucket_url_as_scope() -> None:
    """The SCOPE is the bucket URL verbatim — container included.

    DuckDB matches secrets by longest URL prefix. dlt's auto-emitted secret
    uses `split("@")[0]` (see duckdb/sql_client.py:303) → `abfss://<container>`,
    so our full-URL SCOPE is strictly longer and wins on specificity. Stripping
    the container would break prefix matching against the actual delta_scan
    URLs (`abfss://<container>@…/path/...`) and DuckDB would fall back to
    dlt's malformed CONNECTION_STRING secret.
    """
    from das_cli.dlt_glue.azure_credentials import _build_fabric_secret_sql

    sql = _build_fabric_secret_sql(
        bucket_url="abfss://ws@onelake.dfs.fabric.microsoft.com/lh/Tables",
        token="fake-jwt-token",
    )
    assert "TYPE AZURE" in sql
    assert "PROVIDER ACCESS_TOKEN" in sql
    assert "ACCESS_TOKEN 'fake-jwt-token'" in sql
    assert "ACCOUNT_NAME 'onelake'" in sql
    assert "SCOPE 'abfss://ws@onelake.dfs.fabric.microsoft.com/lh/Tables'" in sql


def test_build_fabric_secret_sql_secret_name_sanitization() -> None:
    """Secret name follows dlt's convention: `.lower()` + strip non-letters
    (see dlt/destinations/impl/duckdb/sql_client.py:240), prefixed with
    `das_fabric_` to avoid collision with dlt's own `<dataset>_*` secret.
    """
    from das_cli.dlt_glue.azure_credentials import _build_fabric_secret_sql

    sql = _build_fabric_secret_sql(
        bucket_url="abfss://ws@onelake.dfs.fabric.microsoft.com/lh/Tables/x",
        token="t",
    )
    # Expected sanitization: bucket_url.lower() → strip [^a-zA-Z] → letters
    # only. The `ws` container is preserved.
    assert "CREATE OR REPLACE SECRET das_fabric_abfsswsonelakedfsfabricmicrosoftcomlhtablesx" in sql


def test_build_fabric_secret_sql_escapes_token_safely() -> None:
    """Token is inserted via a single-quoted SQL literal. A `'` in the token
    would break the SQL; reject it rather than producing invalid SQL.
    """
    from das_cli.dlt_glue.azure_credentials import _build_fabric_secret_sql

    with pytest.raises(ValueError, match="single quote"):
        _build_fabric_secret_sql(
            bucket_url="abfss://ws@onelake.dfs.fabric.microsoft.com/lh",
            token="bad'token",
        )


def test_acquire_storage_bearer_token_is_public(monkeypatch: pytest.MonkeyPatch) -> None:
    """The public name is used by the new sql_client helper; pin it."""
    from das_cli.dlt_glue import azure_credentials as ac_mod

    assert hasattr(ac_mod, "acquire_storage_bearer_token")
    assert callable(ac_mod.acquire_storage_bearer_token)


def test_open_sql_client_installs_secret_for_onelake(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """OneLake bucket_url + azure creds → executes CREATE OR REPLACE SECRET."""
    from unittest.mock import MagicMock

    from das_cli.dlt_glue import azure_credentials as ac_mod
    from das_cli.dlt_glue.azure_credentials import open_sql_client

    # Mock token acquisition — no real Azure call.
    monkeypatch.setattr(ac_mod, "acquire_storage_bearer_token", lambda creds: "fake-jwt-token")

    fake_client = MagicMock()
    fake_pipeline = MagicMock()
    fake_pipeline.sql_client.return_value.__enter__.return_value = fake_client
    fake_pipeline.sql_client.return_value.__exit__.return_value = False

    sp = AzureServicePrincipalAuth(
        auth="service_principal", tenant_id="t", client_id="c", client_secret="s"
    )

    with open_sql_client(
        fake_pipeline,
        bucket_url="abfss://ws@onelake.dfs.fabric.microsoft.com/lh/Tables",
        azure=sp,
    ) as c:
        assert c is fake_client

    # Exactly one execute_sql call, with the OneLake CREATE SECRET.
    assert fake_client.execute_sql.call_count == 1
    sql_arg = fake_client.execute_sql.call_args[0][0]
    assert "CREATE OR REPLACE SECRET das_fabric_" in sql_arg
    assert "ACCESS_TOKEN 'fake-jwt-token'" in sql_arg
    assert "ACCOUNT_NAME 'onelake'" in sql_arg


def test_open_sql_client_noop_for_adls_gen2(monkeypatch: pytest.MonkeyPatch) -> None:
    """Standard ADLS Gen2 → no CREATE SECRET issued (dlt's native secret works)."""
    from unittest.mock import MagicMock

    from das_cli.dlt_glue import azure_credentials as ac_mod
    from das_cli.dlt_glue.azure_credentials import open_sql_client

    # Token helper should NOT be called for non-Fabric URLs; trip-wire it.
    monkeypatch.setattr(
        ac_mod,
        "acquire_storage_bearer_token",
        lambda creds: pytest.fail("token should not be acquired for ADLS Gen2"),
    )

    fake_client = MagicMock()
    fake_pipeline = MagicMock()
    fake_pipeline.sql_client.return_value.__enter__.return_value = fake_client
    fake_pipeline.sql_client.return_value.__exit__.return_value = False

    sp = AzureServicePrincipalAuth(
        auth="service_principal", tenant_id="t", client_id="c", client_secret="s"
    )

    with open_sql_client(
        fake_pipeline,
        bucket_url="abfss://lake@acct.dfs.core.windows.net/warehouse",
        azure=sp,
    ) as c:
        assert c is fake_client

    assert fake_client.execute_sql.call_count == 0


def test_open_sql_client_noop_for_no_bucket_url() -> None:
    """bucket_url=None (duckdb / ducklake destination) → pass-through."""
    from unittest.mock import MagicMock

    from das_cli.dlt_glue.azure_credentials import open_sql_client

    fake_client = MagicMock()
    fake_pipeline = MagicMock()
    fake_pipeline.sql_client.return_value.__enter__.return_value = fake_client
    fake_pipeline.sql_client.return_value.__exit__.return_value = False

    with open_sql_client(fake_pipeline, bucket_url=None, azure=None) as c:
        assert c is fake_client

    assert fake_client.execute_sql.call_count == 0


def test_open_sql_client_noop_when_azure_is_none() -> None:
    """Local Delta (`./das_delta`) → pass-through."""
    from unittest.mock import MagicMock

    from das_cli.dlt_glue.azure_credentials import open_sql_client

    fake_client = MagicMock()
    fake_pipeline = MagicMock()
    fake_pipeline.sql_client.return_value.__enter__.return_value = fake_client
    fake_pipeline.sql_client.return_value.__exit__.return_value = False

    with open_sql_client(fake_pipeline, bucket_url="./das_delta", azure=None) as c:
        assert c is fake_client

    assert fake_client.execute_sql.call_count == 0
