from das_cli.pipelines.row_hash import compute_row_hash


def test_stable_for_same_dict() -> None:
    a = {"id": 1, "name": "x"}
    b = {"name": "x", "id": 1}
    assert compute_row_hash(a, exclude=set()) == compute_row_hash(b, exclude=set())


def test_changes_when_value_changes() -> None:
    h1 = compute_row_hash({"id": 1, "name": "x"}, exclude=set())
    h2 = compute_row_hash({"id": 1, "name": "y"}, exclude=set())
    assert h1 != h2


def test_excluded_keys_ignored() -> None:
    h1 = compute_row_hash({"id": 1, "name": "x", "ts": "T1"}, exclude={"ts"})
    h2 = compute_row_hash({"id": 1, "name": "x", "ts": "T2"}, exclude={"ts"})
    assert h1 == h2


def test_nested_structures_canonicalized() -> None:
    a = {"id": 1, "tags": ["b", "a"]}
    b = {"id": 1, "tags": ["b", "a"]}
    assert compute_row_hash(a, exclude=set()) == compute_row_hash(b, exclude=set())


def test_returns_hex_string() -> None:
    h = compute_row_hash({"id": 1}, exclude=set())
    assert isinstance(h, str)
    assert all(c in "0123456789abcdef" for c in h)
