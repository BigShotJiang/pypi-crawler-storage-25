from das_cli.dlt_glue.dataset import resolve_dataset_name
from das_cli.models.das_yaml import DatasetConfig


def test_with_prefix_joins_with_double_underscore() -> None:
    assert resolve_dataset_name("adventureworks", prefix="das") == "das__adventureworks"


def test_without_prefix_returns_source_name() -> None:
    assert resolve_dataset_name("adventureworks", prefix=None) == "adventureworks"


def test_empty_prefix_treated_as_none() -> None:
    assert resolve_dataset_name("adventureworks", prefix="") == "adventureworks"


def test_string_none_prefix_resolves_to_bare_source_name() -> None:
    """A DatasetConfig built from raw 'none' string yields the bare source name end-to-end."""
    cfg = DatasetConfig(prefix="none")
    assert cfg.prefix is None
    assert resolve_dataset_name("adventureworks", prefix=cfg.prefix) == "adventureworks"
