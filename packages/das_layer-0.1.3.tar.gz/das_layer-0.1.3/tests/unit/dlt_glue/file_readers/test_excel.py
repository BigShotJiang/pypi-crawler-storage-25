"""Unit tests for the Excel file reader. See ADR-0022."""

from __future__ import annotations

from pathlib import Path

import pytest

from das_cli.contracts.filesystem_spec_ref import FilesystemSpecRef
from das_cli.dlt_glue.file_readers.excel import read_rows
from tests.unit.dlt_glue.file_readers import make_xlsx_bytes


class _FakeFileItem:
    """Stand-in for dlt's FileItemDict that writes its body to a real tempfile.

    openpyxl's read_only mode wants a seekable file path or a real file handle;
    a BytesIO works but is treated differently. We simulate the real-world
    FileItemDict.open(mode='rb') by returning a tempfile-backed binary handle.
    """

    def __init__(self, body: bytes, file_name: str = "wb.xlsx", tmp_dir: Path | None = None):
        if tmp_dir is None:
            raise ValueError("_FakeFileItem requires tmp_dir for excel tests")
        self._path = tmp_dir / file_name
        self._path.write_bytes(body)
        self.file_name = file_name
        self.file_url = f"file://{self._path}"
        self.modification_date = "2026-05-12T00:00:00+00:00"

    def open(self, mode: str = "rb") -> object:
        assert mode == "rb"
        return self._path.open("rb")


def _spec(**overrides: object) -> FilesystemSpecRef:
    base: dict[str, object] = {
        "kind": "filesystem",
        "format": "excel",
        "path": "wb.xlsx",
        "sheet": "Customers",
    }
    base.update(overrides)
    return FilesystemSpecRef.model_validate(base)


def test_reads_header_then_data(tmp_path: Path) -> None:
    body = make_xlsx_bytes(
        {
            "Customers": [
                ["id", "name"],
                [1, "Alice"],
                [2, "Bob"],
            ]
        }
    )
    fi = _FakeFileItem(body, "wb.xlsx", tmp_dir=tmp_path)
    out = list(read_rows(fi, _spec()))
    assert out == [{"id": 1, "name": "Alice"}, {"id": 2, "name": "Bob"}]


def test_only_selected_sheet_is_read(tmp_path: Path) -> None:
    body = make_xlsx_bytes(
        {
            "Customers": [["id"], [1], [2]],
            "Orders": [["order_id"], [10]],
        }
    )
    fi = _FakeFileItem(body, "wb.xlsx", tmp_dir=tmp_path)
    out = list(read_rows(fi, _spec(sheet="Orders")))
    assert out == [{"order_id": 10}]


def test_custom_header_row(tmp_path: Path) -> None:
    body = make_xlsx_bytes(
        {
            "Customers": [
                ["banner row to skip"],
                ["id", "name"],
                [1, "Alice"],
            ]
        }
    )
    fi = _FakeFileItem(body, "wb.xlsx", tmp_dir=tmp_path)
    out = list(read_rows(fi, _spec(header_row=2)))
    assert out == [{"id": 1, "name": "Alice"}]


def test_missing_sheet_raises(tmp_path: Path) -> None:
    body = make_xlsx_bytes({"Customers": [["id"], [1]]})
    fi = _FakeFileItem(body, "wb.xlsx", tmp_dir=tmp_path)
    with pytest.raises(KeyError, match="NonExistent"):
        list(read_rows(fi, _spec(sheet="NonExistent")))


def test_inject_basename_and_sheet(tmp_path: Path) -> None:
    body = make_xlsx_bytes({"Customers": [["id"], [1]]})
    fi = _FakeFileItem(body, "march-export.xlsx", tmp_dir=tmp_path)
    out = list(
        read_rows(
            fi,
            _spec(inject={"source_file": "basename", "source_sheet": "sheet"}),
        )
    )
    assert out == [{"id": 1, "source_file": "march-export.xlsx", "source_sheet": "Customers"}]


def test_empty_sheet_yields_nothing(tmp_path: Path) -> None:
    body = make_xlsx_bytes({"Customers": []})
    fi = _FakeFileItem(body, "wb.xlsx", tmp_dir=tmp_path)
    out = list(read_rows(fi, _spec()))
    assert out == []


def test_header_only_yields_nothing(tmp_path: Path) -> None:
    body = make_xlsx_bytes({"Customers": [["id", "name"]]})
    fi = _FakeFileItem(body, "wb.xlsx", tmp_dir=tmp_path)
    out = list(read_rows(fi, _spec()))
    assert out == []


def test_streaming_does_not_load_full_sheet(tmp_path: Path) -> None:
    """Reader must yield rows lazily, not materialize via list()."""
    body = make_xlsx_bytes(
        {
            "Customers": [
                ["id"],
                [1],
                [2],
                [3],
            ]
        }
    )
    fi = _FakeFileItem(body, "wb.xlsx", tmp_dir=tmp_path)
    gen = read_rows(fi, _spec())
    first = next(gen)
    assert first == {"id": 1}
    rest = list(gen)
    assert rest == [{"id": 2}, {"id": 3}]
