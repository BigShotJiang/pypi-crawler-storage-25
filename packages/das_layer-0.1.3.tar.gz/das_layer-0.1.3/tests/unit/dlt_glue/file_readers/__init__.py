"""Shared helpers for file-reader unit tests."""

from __future__ import annotations

import io

import openpyxl


def make_xlsx_bytes(sheets: dict[str, list[list[object]]]) -> bytes:
    """Build an in-memory xlsx workbook with the given {sheet_name: rows}.

    Each row is a flat list of cell values. The first list per sheet is the
    header row. Returns the workbook's bytes for use in BytesIO fixtures.
    """
    wb = openpyxl.Workbook()
    # Workbook ships with a default "Sheet" we don't want.
    wb.remove(wb.active)
    for name, rows in sheets.items():
        ws = wb.create_sheet(name)
        for row in rows:
            ws.append(row)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def make_qvd_bytes(columns: list[str], rows: list[list[object]]) -> bytes:
    """Build an in-memory QVD file with the given columns + rows.

    Each row is a flat list of native Python values (`int`, `str`, etc.).
    Returns the QVD bytes for use in BytesIO fixtures.
    """
    import io as _io

    from pyqvd import QvdTable

    t = QvdTable.from_dict({"columns": columns, "data": rows})
    buf = _io.BytesIO()
    t.to_stream(buf)
    return buf.getvalue()
