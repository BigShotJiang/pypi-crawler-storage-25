"""Unit tests for the CSV file reader. See ADR-0022."""

from __future__ import annotations

import io

from das_cli.contracts.filesystem_spec_ref import FilesystemSpecRef
from das_cli.dlt_glue.file_readers.csv import read_rows


class _FakeFileItem:
    """Stand-in for dlt's FileItemDict — supports `open(mode='rb')` + `file_name`."""

    def __init__(self, body: bytes, file_name: str = "x.csv"):
        self._body = body
        self.file_name = file_name
        self.file_url = f"file:///fake/{file_name}"
        self.modification_date = "2026-05-12T00:00:00+00:00"

    def open(self, mode: str = "rb") -> io.BytesIO:
        assert mode == "rb", "csv reader must open in binary mode"
        return io.BytesIO(self._body)


def _spec(**overrides: object) -> FilesystemSpecRef:
    base: dict[str, object] = {"kind": "filesystem", "format": "csv", "path": "*.csv"}
    base.update(overrides)
    return FilesystemSpecRef.model_validate(base)


def test_reads_header_row_then_data() -> None:
    body = b"id,name\n1,Alice\n2,Bob\n"
    fi = _FakeFileItem(body, "customers.csv")
    out = list(read_rows(fi, _spec()))
    assert out == [{"id": "1", "name": "Alice"}, {"id": "2", "name": "Bob"}]


def test_custom_delimiter() -> None:
    body = b"id;name\n1;Alice\n"
    fi = _FakeFileItem(body, "x.csv")
    out = list(read_rows(fi, _spec(delimiter=";")))
    assert out == [{"id": "1", "name": "Alice"}]


def test_custom_encoding() -> None:
    body = "id,name\n1,Café\n".encode("latin-1")
    fi = _FakeFileItem(body, "x.csv")
    out = list(read_rows(fi, _spec(encoding="latin-1")))
    assert out == [{"id": "1", "name": "Café"}]


def test_empty_file_yields_nothing() -> None:
    fi = _FakeFileItem(b"", "empty.csv")
    out = list(read_rows(fi, _spec()))
    assert out == []


def test_header_only_yields_nothing() -> None:
    fi = _FakeFileItem(b"id,name\n", "h.csv")
    out = list(read_rows(fi, _spec()))
    assert out == []


def test_inject_basename_column() -> None:
    body = b"id\n1\n2\n"
    fi = _FakeFileItem(body, "customers_2024-01.csv")
    out = list(read_rows(fi, _spec(inject={"source_file": "basename"})))
    assert out == [
        {"id": "1", "source_file": "customers_2024-01.csv"},
        {"id": "2", "source_file": "customers_2024-01.csv"},
    ]


def test_inject_mtime_column() -> None:
    fi = _FakeFileItem(b"id\n1\n", "x.csv")
    out = list(read_rows(fi, _spec(inject={"loaded_at": "mtime"})))
    assert out == [{"id": "1", "loaded_at": "2026-05-12T00:00:00+00:00"}]


def test_streaming_does_not_load_full_file() -> None:
    """Reader must yield rows one at a time, not load everything via list().

    We can't directly measure RSS, but we can verify the reader returns a
    generator that hasn't consumed its source after one row is pulled.
    """
    body = b"id\n1\n2\n3\n"
    fi = _FakeFileItem(body, "x.csv")
    gen = read_rows(fi, _spec())
    first = next(gen)
    assert first == {"id": "1"}
    # gen is still pending — remaining rows haven't been materialized.
    rest = list(gen)
    assert rest == [{"id": "2"}, {"id": "3"}]
