"""Unit tests for the XML file reader. See ADR-0022."""

from __future__ import annotations

import io
from pathlib import Path

import pytest

from das_cli.contracts.filesystem_spec_ref import FilesystemSpecRef
from das_cli.dlt_glue.file_readers.xml import read_rows


class _FakeFileItem:
    """Stand-in for dlt's FileItemDict — supports `open(mode='rb')` + `file_name`."""

    def __init__(self, body: bytes, file_name: str = "x.xml"):
        self._body = body
        self.file_name = file_name
        self.file_url = f"file:///fake/{file_name}"
        self.modification_date = "2026-05-13T00:00:00+00:00"

    def open(self, mode: str = "rb") -> io.BytesIO:
        assert mode == "rb"
        return io.BytesIO(self._body)


def _spec(xpath: str = "//customer", **overrides: object) -> FilesystemSpecRef:
    base: dict[str, object] = {
        "kind": "filesystem",
        "format": "xml",
        "path": "*.xml",
        "xpath": xpath,
    }
    base.update(overrides)
    return FilesystemSpecRef.model_validate(base)


def test_reads_simple_records() -> None:
    body = b"""<?xml version="1.0"?>
<customers>
  <customer><id>1</id><name>Alice</name></customer>
  <customer><id>2</id><name>Bob</name></customer>
</customers>"""
    fi = _FakeFileItem(body)
    out = list(read_rows(fi, _spec()))
    assert out == [
        {"id": "1", "name": "Alice"},
        {"id": "2", "name": "Bob"},
    ]


def test_attributes_become_columns() -> None:
    body = b"""<?xml version="1.0"?>
<customers>
  <customer id="1" active="true"><name>Alice</name></customer>
</customers>"""
    fi = _FakeFileItem(body)
    out = list(read_rows(fi, _spec()))
    assert out == [{"id": "1", "active": "true", "name": "Alice"}]


def test_child_text_falls_back_to_empty_string_when_missing() -> None:
    """A child element with no text content yields an empty string for that column."""
    body = b"""<?xml version="1.0"?>
<customers>
  <customer><id>1</id><name/></customer>
</customers>"""
    fi = _FakeFileItem(body)
    out = list(read_rows(fi, _spec()))
    assert out == [{"id": "1", "name": ""}]


def test_namespaced_elements() -> None:
    body = b"""<?xml version="1.0"?>
<ns:customers xmlns:ns="http://example.com/x">
  <ns:customer><ns:id>1</ns:id><ns:name>Alice</ns:name></ns:customer>
</ns:customers>"""
    fi = _FakeFileItem(body)
    out = list(
        read_rows(
            fi,
            _spec(xpath="//ns:customer", namespaces={"ns": "http://example.com/x"}),
        )
    )
    assert out == [{"id": "1", "name": "Alice"}]


def test_namespace_required_when_xpath_uses_prefix() -> None:
    body = b'<?xml version="1.0"?><ns:r xmlns:ns="http://x"/>'
    fi = _FakeFileItem(body)
    with pytest.raises(ValueError, match="namespace prefix 'ns' is not declared"):
        list(read_rows(fi, _spec(xpath="//ns:r")))


def test_complex_xpath_rejected() -> None:
    fi = _FakeFileItem(b"<r/>")
    with pytest.raises(NotImplementedError, match="only simple xpath forms are supported"):
        list(read_rows(fi, _spec(xpath="//customer[@active='true']")))


def test_xpath_required() -> None:
    """Reader rejects spec_ref without xpath (validator catches earlier; reader defends too)."""
    body = b"<root/>"
    fi = _FakeFileItem(body)
    sr = FilesystemSpecRef.model_validate({"kind": "filesystem", "format": "xml", "path": "*.xml"})
    with pytest.raises(ValueError, match="xml reader requires spec_ref.xpath"):
        list(read_rows(fi, sr))


def test_inject_basename(tmp_path: Path) -> None:
    body = b"""<?xml version="1.0"?>
<customers><customer><id>1</id></customer></customers>"""
    fi = _FakeFileItem(body, "exports-2024-01.xml")
    out = list(read_rows(fi, _spec(inject={"src": "basename"})))
    assert out == [{"id": "1", "src": "exports-2024-01.xml"}]


def test_streaming_clears_elements() -> None:
    """Reader yields lazily and clears each element after emission."""
    body = b"""<?xml version="1.0"?>
<customers>
  <customer><id>1</id></customer>
  <customer><id>2</id></customer>
  <customer><id>3</id></customer>
</customers>"""
    fi = _FakeFileItem(body)
    gen = read_rows(fi, _spec())
    first = next(gen)
    assert first == {"id": "1"}
    rest = list(gen)
    assert rest == [{"id": "2"}, {"id": "3"}]


def test_empty_xpath_match_yields_nothing() -> None:
    body = b"""<?xml version="1.0"?>
<customers><other/></customers>"""
    fi = _FakeFileItem(body)
    out = list(read_rows(fi, _spec()))
    assert out == []
