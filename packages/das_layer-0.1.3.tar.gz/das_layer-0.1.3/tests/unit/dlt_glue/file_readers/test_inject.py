"""Unit tests for the shared inject helper. See ADR-0023."""

from __future__ import annotations

from das_cli.dlt_glue.file_readers._inject import apply_inject


def test_no_inject_passes_rows_through() -> None:
    rows = iter([{"a": 1}, {"a": 2}])
    out = list(apply_inject(rows, inject=None, context={}))
    assert out == [{"a": 1}, {"a": 2}]


def test_basename_injection() -> None:
    rows = iter([{"a": 1}])
    ctx = {"basename": "customers_2024-01.csv"}
    out = list(apply_inject(rows, inject={"source_file": "basename"}, context=ctx))
    assert out == [{"a": 1, "source_file": "customers_2024-01.csv"}]


def test_multiple_injections() -> None:
    rows = iter([{"a": 1}])
    ctx = {"basename": "x.csv", "mtime": "2026-05-12T00:00:00"}
    out = list(
        apply_inject(
            rows,
            inject={"source_file": "basename", "loaded_at": "mtime"},
            context=ctx,
        )
    )
    assert out == [{"a": 1, "source_file": "x.csv", "loaded_at": "2026-05-12T00:00:00"}]


def test_unknown_inject_source_silently_skipped() -> None:
    """Unknown source keys (e.g. 'sheet' for csv where it isn't populated) are skipped.

    The model validation in Task 2 enforces that inject values are in the known
    set; this helper is defensive — if a context key is missing, the column is
    not injected rather than the row failing.
    """
    rows = iter([{"a": 1}])
    ctx = {"basename": "x.csv"}  # no 'sheet' in context
    out = list(apply_inject(rows, inject={"src": "basename", "sheet_name": "sheet"}, context=ctx))
    assert out == [{"a": 1, "src": "x.csv"}]
