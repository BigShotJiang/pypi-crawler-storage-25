"""Unit tests for the QVD file reader. See ADR-0022."""

from __future__ import annotations

import io

from das_cli.contracts.filesystem_spec_ref import FilesystemSpecRef
from das_cli.dlt_glue.file_readers.qvd import read_rows
from tests.unit.dlt_glue.file_readers import make_qvd_bytes


class _FakeFileItem:
    """Stand-in for dlt's FileItemDict — supports `open(mode='rb')` + `file_name`."""

    def __init__(self, body: bytes, file_name: str = "x.qvd"):
        self._body = body
        self.file_name = file_name
        self.file_url = f"file:///fake/{file_name}"
        self.modification_date = "2026-05-13T00:00:00+00:00"

    def open(self, mode: str = "rb") -> io.BytesIO:
        assert mode == "rb"
        return io.BytesIO(self._body)


def _spec(**overrides: object) -> FilesystemSpecRef:
    base: dict[str, object] = {"kind": "filesystem", "format": "qvd", "path": "*.qvd"}
    base.update(overrides)
    return FilesystemSpecRef.model_validate(base)


def test_reads_simple_records() -> None:
    body = make_qvd_bytes(
        columns=["id", "name"],
        rows=[[1, "Alice"], [2, "Bob"]],
    )
    fi = _FakeFileItem(body)
    out = list(read_rows(fi, _spec()))
    assert out == [{"id": 1, "name": "Alice"}, {"id": 2, "name": "Bob"}]


def test_mixed_numeric_and_string_types() -> None:
    body = make_qvd_bytes(
        columns=["product_id", "name", "price"],
        rows=[[10, "Widget", 9.95], [11, "Gadget", 19.50]],
    )
    fi = _FakeFileItem(body)
    out = list(read_rows(fi, _spec()))
    assert out == [
        {"product_id": 10, "name": "Widget", "price": 9.95},
        {"product_id": 11, "name": "Gadget", "price": 19.50},
    ]


def test_inject_basename() -> None:
    body = make_qvd_bytes(columns=["id"], rows=[[1]])
    fi = _FakeFileItem(body, "Q1-2024.qvd")
    out = list(read_rows(fi, _spec(inject={"source_file": "basename"})))
    assert out == [{"id": 1, "source_file": "Q1-2024.qvd"}]


def test_inject_mtime() -> None:
    body = make_qvd_bytes(columns=["id"], rows=[[1]])
    fi = _FakeFileItem(body, "x.qvd")
    out = list(read_rows(fi, _spec(inject={"loaded_at": "mtime"})))
    assert out == [{"id": 1, "loaded_at": "2026-05-13T00:00:00+00:00"}]


def test_empty_table_yields_nothing() -> None:
    """A QVD with columns but no rows yields no records.

    pyqvd cannot serialize a zero-row QVD (writer bug: max() on empty list),
    so we patch from_stream to return an iterator over a single empty chunk
    rather than fabricating a binary fixture.
    """
    from unittest.mock import MagicMock, patch

    empty_chunk = MagicMock()
    empty_chunk.columns = ["id", "name"]
    empty_chunk.data = []

    body = b"fake-qvd-empty"
    fi = _FakeFileItem(body)

    with patch(
        "pyqvd.QvdTable.from_stream",
        return_value=iter([empty_chunk]),
    ):
        out = list(read_rows(fi, _spec()))
    assert out == []


def test_streaming_does_not_load_full_file() -> None:
    """Reader must yield rows lazily across chunks."""
    body = make_qvd_bytes(
        columns=["id"],
        rows=[[1], [2], [3], [4], [5]],
    )
    fi = _FakeFileItem(body)
    gen = read_rows(fi, _spec())
    first = next(gen)
    assert first == {"id": 1}
    rest = list(gen)
    assert rest == [{"id": 2}, {"id": 3}, {"id": 4}, {"id": 5}]


def test_many_rows_traverse_multiple_chunks() -> None:
    """Force chunk-boundary crossing: 25k rows at chunk_size=10_000 → 3 chunks."""
    rows: list[list[object]] = [[i] for i in range(25_000)]
    body = make_qvd_bytes(columns=["id"], rows=rows)
    fi = _FakeFileItem(body)
    out = list(read_rows(fi, _spec()))
    assert len(out) == 25_000
    assert out[0] == {"id": 0}
    assert out[10_000] == {"id": 10_000}
    assert out[24_999] == {"id": 24_999}
