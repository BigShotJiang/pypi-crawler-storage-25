"""Unit tests for filesystem bootstrap. See ADR-0022."""

from __future__ import annotations

from pathlib import Path

import pytest

from das_cli.bootstrap.filesystem import bootstrap_filesystem_contracts
from das_cli.contracts.custom_properties import get_das_value
from das_cli.models.source_yml import SourceConfig


def _scfg(endpoint: str) -> SourceConfig:
    return SourceConfig.model_validate(
        {
            "type": "filesystem",
            "endpoint": endpoint,
            "spec": {"kind": "filesystem"},
            "auth": {"type": "none"},
        }
    )


def test_emits_one_contract_per_csv(tmp_path: Path) -> None:
    (tmp_path / "customers.csv").write_text("id,name\n1,Alice\n")
    (tmp_path / "orders.csv").write_text("order_id,amount\n10,99.50\n")
    contracts = bootstrap_filesystem_contracts(_scfg(str(tmp_path)), source_name="files")
    names = sorted(c.resource_name for c in contracts)
    assert names == ["customers", "orders"]


def test_columns_taken_from_header_row(tmp_path: Path) -> None:
    (tmp_path / "customers.csv").write_text("id,name,email\n1,Alice,a@x\n")
    contracts = bootstrap_filesystem_contracts(_scfg(str(tmp_path)), source_name="files")
    schema = contracts[0].contract.primary_schema
    assert [p.name for p in schema.properties] == ["id", "name", "email"]


def test_types_default_to_string(tmp_path: Path) -> None:
    (tmp_path / "x.csv").write_text("a,b\n1,2\n")
    contracts = bootstrap_filesystem_contracts(_scfg(str(tmp_path)), source_name="files")
    types = [p.logicalType for p in contracts[0].contract.primary_schema.properties]
    assert types == ["string", "string"]


def test_spec_ref_records_filename(tmp_path: Path) -> None:
    (tmp_path / "customers.csv").write_text("id\n1\n")
    contracts = bootstrap_filesystem_contracts(_scfg(str(tmp_path)), source_name="files")
    spec_ref = get_das_value(contracts[0].contract.custom_properties, "das.spec_ref")
    assert spec_ref == {
        "kind": "filesystem",
        "format": "csv",
        "path": "customers.csv",
    }


def test_resource_name_snake_cased(tmp_path: Path) -> None:
    (tmp_path / "CustomerOrders.csv").write_text("Id\n1\n")
    contracts = bootstrap_filesystem_contracts(_scfg(str(tmp_path)), source_name="files")
    assert contracts[0].resource_name == "customer_orders"


def test_skips_non_csv_files(tmp_path: Path) -> None:
    (tmp_path / "customers.csv").write_text("id\n1\n")
    (tmp_path / "readme.txt").write_text("hello")
    (tmp_path / "notes.md").write_text("# notes")
    contracts = bootstrap_filesystem_contracts(_scfg(str(tmp_path)), source_name="files")
    names = [c.resource_name for c in contracts]
    assert names == ["customers"]


def test_empty_directory_returns_empty_list(tmp_path: Path) -> None:
    contracts = bootstrap_filesystem_contracts(_scfg(str(tmp_path)), source_name="files")
    assert contracts == []


def test_empty_csv_emits_contract_with_no_properties(tmp_path: Path) -> None:
    """A CSV with no header row produces an empty-schema contract.

    Bootstrap leaves the contract in a state the user can edit; the validator
    will then flag the empty schema if they try to ingest.
    """
    (tmp_path / "x.csv").write_text("")
    contracts = bootstrap_filesystem_contracts(_scfg(str(tmp_path)), source_name="files")
    assert len(contracts) == 1
    assert contracts[0].contract.primary_schema.properties == []


def test_emits_one_contract_per_sheet(tmp_path: Path) -> None:
    import openpyxl

    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    ws_c = wb.create_sheet("Customers")
    ws_c.append(["id", "name"])
    ws_o = wb.create_sheet("Orders")
    ws_o.append(["order_id", "amount"])
    wb.save(tmp_path / "wb.xlsx")

    contracts = bootstrap_filesystem_contracts(_scfg(str(tmp_path)), source_name="files")
    names = sorted(c.resource_name for c in contracts)
    assert names == ["wb__customers", "wb__orders"]


def test_xlsx_columns_taken_from_header(tmp_path: Path) -> None:
    import openpyxl

    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    ws = wb.create_sheet("Customers")
    ws.append(["id", "name", "email"])
    ws.append([1, "Alice", "a@x"])
    wb.save(tmp_path / "wb.xlsx")

    contracts = bootstrap_filesystem_contracts(_scfg(str(tmp_path)), source_name="files")
    schema = contracts[0].contract.primary_schema
    assert [p.name for p in schema.properties] == ["id", "name", "email"]


def test_xlsx_types_default_to_string(tmp_path: Path) -> None:
    import openpyxl

    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    ws = wb.create_sheet("Customers")
    ws.append(["id", "name"])
    ws.append([1, "Alice"])
    wb.save(tmp_path / "wb.xlsx")

    contracts = bootstrap_filesystem_contracts(_scfg(str(tmp_path)), source_name="files")
    types = [p.logicalType for p in contracts[0].contract.primary_schema.properties]
    assert types == ["string", "string"]


def test_xlsx_spec_ref_carries_sheet_and_filename(tmp_path: Path) -> None:
    import openpyxl

    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    wb.create_sheet("Customers").append(["id"])
    wb.save(tmp_path / "Q1-Export.xlsx")

    contracts = bootstrap_filesystem_contracts(_scfg(str(tmp_path)), source_name="files")
    spec_ref = get_das_value(contracts[0].contract.custom_properties, "das.spec_ref")
    assert spec_ref == {
        "kind": "filesystem",
        "format": "excel",
        "path": "Q1-Export.xlsx",
        "sheet": "Customers",
    }


def test_xlsx_resource_name_is_workbook_stem_plus_sheet(tmp_path: Path) -> None:
    import openpyxl

    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    wb.create_sheet("OrderItems").append(["id"])
    wb.save(tmp_path / "CustomerOrders.xlsx")

    contracts = bootstrap_filesystem_contracts(_scfg(str(tmp_path)), source_name="files")
    assert contracts[0].resource_name == "customer_orders__order_items"


def test_xlsx_skips_empty_sheet(tmp_path: Path) -> None:
    """A sheet with no header row produces a contract with empty properties.

    Bootstrap emits the contract anyway so the user can see it exists; the
    validator will then flag the empty schema if they try to ingest.
    """
    import openpyxl

    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    wb.create_sheet("Empty")
    wb.save(tmp_path / "wb.xlsx")

    contracts = bootstrap_filesystem_contracts(_scfg(str(tmp_path)), source_name="files")
    assert len(contracts) == 1
    assert contracts[0].contract.primary_schema.properties == []


def test_xml_emits_one_contract_per_file(tmp_path: Path) -> None:
    (tmp_path / "customers.xml").write_text(
        '<?xml version="1.0"?>\n<customers>\n'
        "  <customer><id>1</id><name>Alice</name></customer>\n"
        "</customers>\n"
    )
    (tmp_path / "orders.xml").write_text(
        '<?xml version="1.0"?>\n<orders>\n'
        "  <customer><order_id>10</order_id></customer>\n"
        "</orders>\n"
    )
    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files", xpath="//customer"
    )
    names = sorted(c.resource_name for c in contracts)
    assert names == ["customers", "orders"]


def test_xml_columns_taken_from_first_element(tmp_path: Path) -> None:
    (tmp_path / "x.xml").write_text(
        '<?xml version="1.0"?>\n<root>\n'
        '  <customer id="1"><name>Alice</name><email>a@x</email></customer>\n'
        "</root>\n"
    )
    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files", xpath="//customer"
    )
    schema = contracts[0].contract.primary_schema
    assert sorted(p.name for p in schema.properties) == ["email", "id", "name"]


def test_xml_types_default_to_string(tmp_path: Path) -> None:
    (tmp_path / "x.xml").write_text(
        '<?xml version="1.0"?>\n<root><customer><id>1</id></customer></root>'
    )
    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files", xpath="//customer"
    )
    types = [p.logicalType for p in contracts[0].contract.primary_schema.properties]
    assert types == ["string"]


def test_xml_spec_ref_records_xpath_and_filename(tmp_path: Path) -> None:
    from das_cli.contracts.custom_properties import get_das_value

    (tmp_path / "customers.xml").write_text(
        '<?xml version="1.0"?>\n<root><customer><id>1</id></customer></root>'
    )
    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files", xpath="//customer"
    )
    spec_ref = get_das_value(contracts[0].contract.custom_properties, "das.spec_ref")
    assert spec_ref == {
        "kind": "filesystem",
        "format": "xml",
        "path": "customers.xml",
        "xpath": "//customer",
    }


def test_xml_no_xpath_raises_when_xml_present(tmp_path: Path) -> None:
    (tmp_path / "x.xml").write_text("<root/>")
    with pytest.raises(ValueError, match="--xpath is required"):
        bootstrap_filesystem_contracts(_scfg(str(tmp_path)), source_name="files")


def test_xml_no_match_emits_empty_schema(tmp_path: Path) -> None:
    """A file where xpath matches nothing produces a contract with no properties."""
    (tmp_path / "x.xml").write_text('<?xml version="1.0"?>\n<root><other/></root>')
    contracts = bootstrap_filesystem_contracts(
        _scfg(str(tmp_path)), source_name="files", xpath="//customer"
    )
    assert len(contracts) == 1
    assert contracts[0].contract.primary_schema.properties == []


def test_qvd_emits_one_contract_per_file(tmp_path: Path) -> None:
    import io as _io

    from pyqvd import QvdTable

    t = QvdTable.from_dict({"columns": ["id"], "data": [[1]]})
    buf = _io.BytesIO()
    t.to_stream(buf)
    (tmp_path / "customers.qvd").write_bytes(buf.getvalue())
    (tmp_path / "orders.qvd").write_bytes(buf.getvalue())

    contracts = bootstrap_filesystem_contracts(_scfg(str(tmp_path)), source_name="files")
    names = sorted(c.resource_name for c in contracts)
    assert names == ["customers", "orders"]


def test_qvd_columns_from_header(tmp_path: Path) -> None:
    import io as _io

    from pyqvd import QvdTable

    t = QvdTable.from_dict(
        {"columns": ["customer_id", "name", "amount"], "data": [[1, "Alice", 9.95]]}
    )
    buf = _io.BytesIO()
    t.to_stream(buf)
    (tmp_path / "x.qvd").write_bytes(buf.getvalue())

    contracts = bootstrap_filesystem_contracts(_scfg(str(tmp_path)), source_name="files")
    schema = contracts[0].contract.primary_schema
    assert [p.name for p in schema.properties] == ["customer_id", "name", "amount"]


def test_qvd_types_inferred_from_value_classes(tmp_path: Path) -> None:
    import io as _io

    from pyqvd import QvdTable

    # IntegerValue → integer, StringValue → string, DoubleValue → number.
    t = QvdTable.from_dict({"columns": ["id", "name", "amount"], "data": [[1, "Alice", 9.95]]})
    buf = _io.BytesIO()
    t.to_stream(buf)
    (tmp_path / "x.qvd").write_bytes(buf.getvalue())

    contracts = bootstrap_filesystem_contracts(_scfg(str(tmp_path)), source_name="files")
    types = {p.name: p.logicalType for p in contracts[0].contract.primary_schema.properties}
    assert types == {"id": "integer", "name": "string", "amount": "number"}


def test_qvd_unknown_type_falls_back_to_string(tmp_path: Path) -> None:
    """When the first cell of a column is None (no value class), default to string."""
    import io as _io

    from pyqvd import QvdTable

    t = QvdTable.from_dict({"columns": ["maybe"], "data": [[None], [None]]})
    buf = _io.BytesIO()
    t.to_stream(buf)
    (tmp_path / "x.qvd").write_bytes(buf.getvalue())

    contracts = bootstrap_filesystem_contracts(_scfg(str(tmp_path)), source_name="files")
    types = [p.logicalType for p in contracts[0].contract.primary_schema.properties]
    assert types == ["string"]


def test_qvd_spec_ref_records_filename(tmp_path: Path) -> None:
    import io as _io

    from pyqvd import QvdTable

    from das_cli.contracts.custom_properties import get_das_value

    t = QvdTable.from_dict({"columns": ["id"], "data": [[1]]})
    buf = _io.BytesIO()
    t.to_stream(buf)
    (tmp_path / "Q1-Sales.qvd").write_bytes(buf.getvalue())

    contracts = bootstrap_filesystem_contracts(_scfg(str(tmp_path)), source_name="files")
    spec_ref = get_das_value(contracts[0].contract.custom_properties, "das.spec_ref")
    assert spec_ref == {
        "kind": "filesystem",
        "format": "qvd",
        "path": "Q1-Sales.qvd",
    }
