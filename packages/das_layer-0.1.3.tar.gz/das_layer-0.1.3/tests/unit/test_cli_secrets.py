"""Unit tests for the small helpers added in v0.1.2 (secrets UX)."""

from __future__ import annotations

import pytest

from das_cli.cli import _gitignore_already_covers_env, _source_env_prefix


@pytest.mark.parametrize(
    "name,expected",
    [
        ("northwind", "NORTHWIND"),
        ("Northwind", "NORTHWIND"),
        ("my-source", "MY_SOURCE"),
        ("acme.api", "ACME_API"),
        ("a__b", "A_B"),
        ("__leading", "LEADING"),
        ("trailing__", "TRAILING"),
        ("a1b2", "A1B2"),
        ("mixed-case_NAME", "MIXED_CASE_NAME"),
    ],
)
def test_source_env_prefix_normalizes(name: str, expected: str) -> None:
    assert _source_env_prefix(name) == expected


def test_source_env_prefix_rejects_no_alnum() -> None:
    assert _source_env_prefix("___") == ""
    assert _source_env_prefix("---") == ""
    assert _source_env_prefix("") == ""


def test_gitignore_covers_env_when_present() -> None:
    text = ".dlt/\n.env\nlanding/\n"
    assert _gitignore_already_covers_env(text) is True


def test_gitignore_covers_env_with_surrounding_whitespace() -> None:
    assert _gitignore_already_covers_env("   .env  \n") is True


def test_gitignore_does_not_count_glob_only() -> None:
    text = ".env.*\n!.env.example\n"
    assert _gitignore_already_covers_env(text) is False


def test_gitignore_does_not_count_comment() -> None:
    text = "# .env is gitignored elsewhere\n"
    assert _gitignore_already_covers_env(text) is False


def test_gitignore_does_not_count_negation() -> None:
    text = "!.env\n"
    assert _gitignore_already_covers_env(text) is False


def test_gitignore_empty_returns_false() -> None:
    assert _gitignore_already_covers_env("") is False
