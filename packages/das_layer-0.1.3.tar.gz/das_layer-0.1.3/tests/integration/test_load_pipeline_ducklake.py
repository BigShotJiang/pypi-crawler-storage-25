"""Integration tests for the DuckLake destination. See ADR-0016."""

from __future__ import annotations

import gzip
import json
from pathlib import Path

import pytest
from typer.testing import CliRunner

from das_cli.cli import app
from tests.conftest import ducklake_reader_pipeline

CONTRACT = """\
apiVersion: v3.0.0
kind: DataContract
id: x.products
name: Products
version: 0.1.0
status: draft
info: { title: Products, owner: x }
schema:
  - name: products
    physicalName: products
    physicalType: table
    properties:
      - name: product_id
        physicalName: ProductId
        logicalType: integer
        physicalType: bigint
        required: true
        primaryKey: true
      - { name: name, physicalName: Name, logicalType: string, required: true }
"""

SOURCE_YML = """\
type: odata
endpoint: https://example.com/odata/v1
spec:
  kind: odata
  metadata_url: https://example.com/odata/v1/$metadata
auth: { type: none }
"""


@pytest.fixture()
def ducklake_workspace_with_contract(ducklake_workspace: Path) -> Path:
    """`ducklake_workspace` plus a source `x` with a single `products` contract."""
    src_dir = ducklake_workspace / "contracts" / "x"
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(SOURCE_YML)
    (src_dir / "products.odcs.yaml").write_text(CONTRACT)
    return ducklake_workspace


def _write_landing(workspace: Path, records: list[dict[str, object]]) -> None:
    landing = workspace / "landing" / "x" / "products"
    landing.mkdir(parents=True, exist_ok=True)
    out = landing / "1.jsonl.gz"
    payload = (
        "\n".join(
            json.dumps({"_data": r, "_dlt_load_id": "1700000000", "_dlt_id": f"id-{i}"})
            for i, r in enumerate(records)
        )
        + "\n"
    )
    with gzip.open(out, "wt") as f:
        f.write(payload)


def _ducklake_count(workspace: Path, table: str) -> int:
    """Count rows in das__x.<table> via a reader pipeline pointed at the same DuckLake."""
    pipeline = ducklake_reader_pipeline(workspace)
    with pipeline.sql_client() as c:
        rows = c.execute_sql(f'SELECT COUNT(*) FROM "das__x".{table}')
        assert rows is not None
        return int(rows[0][0])


def test_ducklake_load_creates_table_with_contract_schema(
    ducklake_workspace_with_contract: Path, cli_runner: CliRunner
) -> None:
    workspace = ducklake_workspace_with_contract
    _write_landing(workspace, [{"ProductId": 1, "Name": "A"}, {"ProductId": 2, "Name": "B"}])

    result = cli_runner.invoke(app, ["load", "x"])
    assert result.exit_code == 0, result.output
    assert _ducklake_count(workspace, "products") == 2


def test_ducklake_change_detection_suppresses_duplicate(
    ducklake_workspace_with_contract: Path, cli_runner: CliRunner
) -> None:
    """Two cycles with identical landing should append zero rows the second time."""
    workspace = ducklake_workspace_with_contract
    _write_landing(workspace, [{"ProductId": 1, "Name": "A"}])

    first = cli_runner.invoke(app, ["load", "x"])
    assert first.exit_code == 0, first.output

    second = cli_runner.invoke(app, ["load", "x"])
    assert second.exit_code == 0, second.output

    assert _ducklake_count(workspace, "products") == 1


def test_ducklake_a_b_a_preserved(
    ducklake_workspace_with_contract: Path, cli_runner: CliRunner
) -> None:
    """A → B → A produces three rows; change detection only suppresses no-ops."""
    workspace = ducklake_workspace_with_contract

    _write_landing(workspace, [{"ProductId": 1, "Name": "A"}])
    first = cli_runner.invoke(app, ["load", "x"])
    assert first.exit_code == 0, first.output

    landing = workspace / "landing" / "x" / "products"
    for f in landing.glob("*"):
        f.unlink()
    _write_landing(workspace, [{"ProductId": 1, "Name": "B"}])
    second = cli_runner.invoke(app, ["load", "x"])
    assert second.exit_code == 0, second.output

    for f in landing.glob("*"):
        f.unlink()
    _write_landing(workspace, [{"ProductId": 1, "Name": "A"}])
    third = cli_runner.invoke(app, ["load", "x"])
    assert third.exit_code == 0, third.output

    assert _ducklake_count(workspace, "products") == 3
