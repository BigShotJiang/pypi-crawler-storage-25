import gzip
import json
import re
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import pytest
import responses
from typer.testing import CliRunner

from das_cli.cli import app

METADATA = """\
<?xml version="1.0" encoding="UTF-8"?>
<edmx:Edmx xmlns:edmx="http://docs.oasis-open.org/odata/ns/edmx" Version="4.0">
  <edmx:DataServices>
    <Schema xmlns="http://docs.oasis-open.org/odata/ns/edm" Namespace="X.M">
      <EntityType Name="Product">
        <Key><PropertyRef Name="ProductId" /></Key>
        <Property Name="ProductId" Type="Edm.Int32" Nullable="false" />
        <Property Name="Name" Type="Edm.String" Nullable="false" />
      </EntityType>
    </Schema>
  </edmx:DataServices>
</edmx:Edmx>
"""

PRODUCTS_RESPONSE = {
    "value": [
        {"ProductId": 1, "Name": "A"},
        {"ProductId": 2, "Name": "B"},
    ]
}


def _setup(workspace: Path, runner: CliRunner) -> None:
    runner.invoke(app, ["init"])
    runner.invoke(
        app,
        [
            "source",
            "add",
            "x",
            "--type",
            "odata",
            "--url",
            "https://example.com/odata/v1",
        ],
    )
    with responses.RequestsMock(assert_all_requests_are_fired=False) as rsps:
        rsps.add(
            responses.GET,
            "https://example.com/odata/v1/$metadata",
            body=METADATA,
            status=200,
        )
        runner.invoke(app, ["contract", "bootstrap", "x"])


def test_extract_writes_jsonl_gz(workspace: Path, cli_runner: CliRunner) -> None:
    _setup(workspace, cli_runner)
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.GET,
            "https://example.com/odata/v1/Products",
            json=PRODUCTS_RESPONSE,
            status=200,
        )
        result = cli_runner.invoke(app, ["extract", "x"])
    assert result.exit_code == 0, result.stdout + (
        result.stderr if hasattr(result, "stderr") else ""
    )

    # Find the landing file. Path layout: landing/x/products/<load>/...
    products_dir = workspace / "landing" / "x" / "products"
    assert products_dir.exists()
    files = list(products_dir.rglob("*.jsonl*"))
    assert files, "expected at least one jsonl file"

    # Read one file (gzipped or not) and verify shape.
    contents = []
    for f in files:
        text = gzip.decompress(f.read_bytes()).decode() if f.suffix == ".gz" else f.read_text()
        for line in text.strip().splitlines():
            contents.append(json.loads(line))
    assert any("_data" in row for row in contents)
    payloads = [row["_data"] for row in contents if "_data" in row]
    assert {p["ProductId"] for p in payloads} == {1, 2}


def test_extract_unknown_source_exits_usage(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    result = cli_runner.invoke(app, ["extract", "nonexistent"])
    assert result.exit_code == 2


def test_extract_limit_caps_records(workspace: Path, cli_runner: CliRunner) -> None:
    """--limit 1 results in exactly one record landed even when the source returns multiple."""
    _setup(workspace, cli_runner)
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.GET,
            "https://example.com/odata/v1/Products",
            json=PRODUCTS_RESPONSE,  # returns 2 records
            status=200,
        )
        result = cli_runner.invoke(app, ["extract", "x", "--limit", "1"])
    assert result.exit_code == 0, result.stdout + (
        result.stderr if hasattr(result, "stderr") else ""
    )

    products_dir = workspace / "landing" / "x" / "products"
    assert products_dir.exists()

    contents = []
    for f in products_dir.rglob("*.jsonl*"):
        text = gzip.decompress(f.read_bytes()).decode() if f.suffix == ".gz" else f.read_text()
        for line in text.strip().splitlines():
            contents.append(json.loads(line))

    # Only the _data rows count; dlt may write metadata lines without _data.
    data_rows = [row for row in contents if "_data" in row]
    assert len(data_rows) == 1, f"expected 1 record, got {len(data_rows)}"


def test_extract_writes_hive_partitioned_layout(workspace: Path, cli_runner: CliRunner) -> None:
    """Files land at <source>/<resource>/_extracted_on=YYYY-MM-DD/<load_id>.<file_id>.jsonl.gz."""
    _setup(workspace, cli_runner)
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.GET,
            "https://example.com/odata/v1/Products",
            json=PRODUCTS_RESPONSE,
            status=200,
        )
        result = cli_runner.invoke(app, ["extract", "x"])
    assert result.exit_code == 0, result.stdout

    products_dir = workspace / "landing" / "x" / "products"
    assert products_dir.exists()

    files = list(products_dir.rglob("*.jsonl.gz"))
    assert files, "expected at least one jsonl.gz file"

    today = datetime.now(UTC).date().isoformat()
    pattern = re.compile(rf"_extracted_on={today}$")
    parents = {f.parent.name for f in files}
    assert any(
        pattern.match(p) for p in parents
    ), f"no file under _extracted_on={today}/ — found parents: {parents}"


def test_extract_plain_mode_emits_per_resource_lines(
    workspace: Path, cli_runner: CliRunner, capsys: pytest.CaptureFixture[str]
) -> None:
    """Non-TTY default: per-resource start/finish lines."""
    from das_cli.pipelines.extract import run_extract
    from das_cli.progress import progress

    _setup(workspace, cli_runner)
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.GET,
            "https://example.com/odata/v1/Products",
            json=PRODUCTS_RESPONSE,
            status=200,
        )
        with progress(["products"], mode="plain") as h:
            run_extract(
                source_name="x",
                config_path=workspace / "das.yaml",
                progress_handle=h,
                dlt_progress=None,
            )
    out = capsys.readouterr().out
    assert "products: started" in out
    assert "products: 2 rows" in out


def test_extract_openapi_with_explicit_endpoint(workspace: Path, cli_runner: CliRunner) -> None:
    """Non-OData REST source with das.endpoint extracts end-to-end."""
    (workspace / "das.yaml").write_text(
        "target: { destination: duckdb, credentials: { database: ./das.duckdb } }\n"
        "landing: { bucket_url: ./landing, credentials: {} }\n"
        "contracts: { root: ./contracts }\n"
        "dataset: {}\n"
        "defaults:\n"
        "  write_disposition: append\n"
        "  change_detection: row_hash\n"
        "  schema_contract: { tables: freeze, columns: freeze, data_type: freeze }\n"
    )
    src = workspace / "contracts" / "northwind"
    src.mkdir(parents=True)
    (src / "_source.yml").write_text(
        "type: openapi\n"
        "endpoint: https://example.test/api/v1\n"
        "spec: { kind: openapi, swagger_url: https://example.test/api/v1/swagger.json }\n"
        "auth: { type: none }\n"
    )
    (src / "customers.odcs.yaml").write_text(
        "apiVersion: v3.0.0\n"
        "kind: DataContract\n"
        "id: northwind.customers\n"
        "name: Customers\n"
        "version: 0.1.0\n"
        "status: draft\n"
        "info: { title: Customers, owner: data-platform }\n"
        "schema:\n"
        "  - name: customers\n"
        "    physicalName: customers\n"
        "    physicalType: table\n"
        "    properties:\n"
        "      - { name: customer_id, logicalType: string, required: true, primaryKey: true }\n"
        "customProperties:\n"
        "  - property: das.endpoint\n"
        "    value: { path: /Customers, response_path: null,"
        " pagination: { type: none } }\n"
    )

    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.GET,
            "https://example.test/api/v1/Customers",
            json=[
                {"customerId": "ALFKI", "companyName": "Alfreds"},
                {"customerId": "ANATR", "companyName": "Ana Trujillo"},
            ],
            status=200,
        )
        result = cli_runner.invoke(app, ["extract", "northwind"])

    assert result.exit_code == 0, result.stdout + (
        result.stderr if hasattr(result, "stderr") else ""
    )

    customers_dir = workspace / "landing" / "northwind" / "customers"
    assert customers_dir.exists()
    rows: list[dict[str, Any]] = []
    for f in customers_dir.rglob("*.jsonl*"):
        text = gzip.decompress(f.read_bytes()).decode() if f.suffix == ".gz" else f.read_text()
        for line in text.strip().splitlines():
            rows.append(json.loads(line))

    data_rows = [r for r in rows if "_data" in r]
    customer_ids = {r["_data"]["customerId"] for r in data_rows}
    assert customer_ids == {"ALFKI", "ANATR"}


def test_extract_full_flag_exits_zero_for_http_source(
    workspace: Path, cli_runner: CliRunner
) -> None:
    """Smoke test: `extract --full` must exit 0 for HTTP (OData) sources.

    HTTP sources don't wire dlt incremental state, so `reset_extract_state`
    has nothing to reset.  This test guards against an accidental crash if
    that code path ever breaks on HTTP source layouts — exit 0 with no
    exception is the only contract being verified here.
    """
    _setup(workspace, cli_runner)
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.GET,
            "https://example.com/odata/v1/Products",
            json=PRODUCTS_RESPONSE,
            status=200,
        )
        result = cli_runner.invoke(app, ["extract", "x", "--full"])
    assert result.exit_code == 0, result.stdout + (
        result.stderr if hasattr(result, "stderr") else ""
    )
