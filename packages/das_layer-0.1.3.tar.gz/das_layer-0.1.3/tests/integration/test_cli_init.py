from pathlib import Path

import yaml
from typer.testing import CliRunner

from das_cli.cli import app


def test_init_creates_das_yaml_and_dirs(workspace: Path, cli_runner: CliRunner) -> None:
    result = cli_runner.invoke(app, ["init"])
    assert result.exit_code == 0, result.stdout + result.stderr

    assert (workspace / "das.yaml").is_file()
    assert (workspace / "contracts").is_dir()
    assert (workspace / ".gitignore").is_file()

    raw = yaml.safe_load((workspace / "das.yaml").read_text())
    assert raw["target"]["destination"] == "duckdb"
    assert raw["landing"]["bucket_url"].startswith("{{ env_var")


def test_init_refuses_when_das_yaml_exists(workspace: Path, cli_runner: CliRunner) -> None:
    (workspace / "das.yaml").write_text("# placeholder")
    result = cli_runner.invoke(app, ["init"])
    assert result.exit_code != 0
    assert "exists" in (result.stdout + result.stderr).lower()


def test_init_force_overwrites(workspace: Path, cli_runner: CliRunner) -> None:
    (workspace / "das.yaml").write_text("# placeholder")
    result = cli_runner.invoke(app, ["init", "--force"])
    assert result.exit_code == 0
    raw = yaml.safe_load((workspace / "das.yaml").read_text())
    assert raw["target"]["destination"] == "duckdb"


def test_init_writes_env_when_missing(workspace: Path, cli_runner: CliRunner) -> None:
    result = cli_runner.invoke(app, ["init"])
    assert result.exit_code == 0, result.stdout + result.stderr

    env_path = workspace / ".env"
    assert env_path.is_file()
    text = env_path.read_text()
    # Workspace overrides remain commented so a fresh `das ingest` works.
    assert "# DAS_TARGET_DB=" in text
    assert "# DAS_LANDING_URL=" in text
    # Header marking where source credentials get appended.
    assert "Source credentials" in text


def test_init_does_not_overwrite_existing_env(workspace: Path, cli_runner: CliRunner) -> None:
    sentinel = "USER_SECRET=do-not-touch\n"
    (workspace / ".env").write_text(sentinel)

    result = cli_runner.invoke(app, ["init"])
    assert result.exit_code == 0

    assert (workspace / ".env").read_text() == sentinel


def test_init_force_does_not_overwrite_env(workspace: Path, cli_runner: CliRunner) -> None:
    sentinel = "USER_SECRET=do-not-touch\n"
    (workspace / ".env").write_text(sentinel)
    # `das.yaml` must exist for `--force` to be exercised meaningfully.
    (workspace / "das.yaml").write_text("# placeholder\n")

    result = cli_runner.invoke(app, ["init", "--force"])
    assert result.exit_code == 0

    assert (workspace / ".env").read_text() == sentinel


def test_init_writes_gitignore_with_secrets_block(workspace: Path, cli_runner: CliRunner) -> None:
    result = cli_runner.invoke(app, ["init"])
    assert result.exit_code == 0

    gi = (workspace / ".gitignore").read_text()
    # Original entries preserved.
    assert ".dlt/" in gi
    assert "landing/" in gi
    assert "das.duckdb" in gi
    assert "*.duckdb.wal" in gi
    # Secrets block present.
    assert "\n.env\n" in gi
    assert ".env.*" in gi
    assert "!.env.example" in gi


def test_init_appends_secrets_block_to_existing_gitignore(
    workspace: Path, cli_runner: CliRunner
) -> None:
    original = "node_modules/\n"
    (workspace / ".gitignore").write_text(original)

    result = cli_runner.invoke(app, ["init"])
    assert result.exit_code == 0

    gi = (workspace / ".gitignore").read_text()
    assert gi.startswith(original), "original entries must be preserved at the top"
    assert "\n.env\n" in gi
    assert ".env.*" in gi
    assert "!.env.example" in gi


def test_init_leaves_gitignore_untouched_when_env_already_ignored(
    workspace: Path, cli_runner: CliRunner
) -> None:
    original = "node_modules/\n.env\n"
    (workspace / ".gitignore").write_text(original)

    result = cli_runner.invoke(app, ["init"])
    assert result.exit_code == 0

    assert (workspace / ".gitignore").read_text() == original
