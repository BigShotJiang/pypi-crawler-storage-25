import gzip
import json
from pathlib import Path

import duckdb
import responses
from typer.testing import CliRunner

from das_cli.cli import app

METADATA = """\
<?xml version="1.0" encoding="UTF-8"?>
<edmx:Edmx xmlns:edmx="http://docs.oasis-open.org/odata/ns/edmx" Version="4.0">
  <edmx:DataServices>
    <Schema xmlns="http://docs.oasis-open.org/odata/ns/edm" Namespace="X.M">
      <EntityType Name="Product">
        <Key><PropertyRef Name="ProductId" /></Key>
        <Property Name="ProductId" Type="Edm.Int32" Nullable="false" />
        <Property Name="Name" Type="Edm.String" Nullable="false" />
      </EntityType>
    </Schema>
  </edmx:DataServices>
</edmx:Edmx>
"""

METADATA_TWO_ENTITIES = """\
<?xml version="1.0" encoding="UTF-8"?>
<edmx:Edmx xmlns:edmx="http://docs.oasis-open.org/odata/ns/edmx" Version="4.0">
  <edmx:DataServices>
    <Schema xmlns="http://docs.oasis-open.org/odata/ns/edm" Namespace="X.M">
      <EntityType Name="Product">
        <Key><PropertyRef Name="ProductId" /></Key>
        <Property Name="ProductId" Type="Edm.Int32" Nullable="false" />
        <Property Name="Name" Type="Edm.String" Nullable="false" />
      </EntityType>
      <EntityType Name="Order">
        <Key><PropertyRef Name="OrderId" /></Key>
        <Property Name="OrderId" Type="Edm.Int32" Nullable="false" />
        <Property Name="Total" Type="Edm.Int32" Nullable="false" />
      </EntityType>
    </Schema>
  </edmx:DataServices>
</edmx:Edmx>
"""

PRODUCTS_RESPONSE = {
    "value": [
        {"ProductId": 1, "Name": "A"},
        {"ProductId": 2, "Name": "B"},
    ]
}

PRODUCTS_RESPONSE_3 = {
    "value": [
        {"ProductId": 1, "Name": "A"},
        {"ProductId": 2, "Name": "B"},
        {"ProductId": 3, "Name": "C"},
    ]
}


def test_ingest_runs_extract_then_load(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "x",
            "--type",
            "odata",
            "--url",
            "https://example.com/odata/v1",
        ],
    )
    with responses.RequestsMock(assert_all_requests_are_fired=False) as rsps:
        rsps.add(responses.GET, "https://example.com/odata/v1/$metadata", body=METADATA, status=200)
        cli_runner.invoke(app, ["contract", "bootstrap", "x"])

    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.GET,
            "https://example.com/odata/v1/Products",
            json=PRODUCTS_RESPONSE,
            status=200,
        )
        result = cli_runner.invoke(app, ["ingest", "x"])
    assert result.exit_code == 0, result.stdout + result.stderr

    conn = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        rows = conn.execute(
            'SELECT product_id, name FROM "das__x".products ORDER BY product_id'
        ).fetchall()
        assert rows == [(1, "A"), (2, "B")]
    finally:
        conn.close()


def test_ingest_propagates_extract_failure(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "x",
            "--type",
            "odata",
            "--url",
            "https://example.com/odata/v1",
        ],
    )
    with responses.RequestsMock(assert_all_requests_are_fired=False) as rsps:
        rsps.add(responses.GET, "https://example.com/odata/v1/$metadata", body=METADATA, status=200)
        cli_runner.invoke(app, ["contract", "bootstrap", "x"])

    # Now make the data endpoint fail.
    with responses.RequestsMock() as rsps:
        rsps.add(responses.GET, "https://example.com/odata/v1/Products", status=500)
        result = cli_runner.invoke(app, ["ingest", "x"])
    assert result.exit_code == 5


def test_ingest_forwards_limit_to_extract(workspace: Path, cli_runner: CliRunner) -> None:
    """`ingest --limit 1` caps records during the extract phase even if the source returns more."""
    cli_runner.invoke(app, ["init"])
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "x",
            "--type",
            "odata",
            "--url",
            "https://example.com/odata/v1",
        ],
    )
    with responses.RequestsMock(assert_all_requests_are_fired=False) as rsps:
        rsps.add(responses.GET, "https://example.com/odata/v1/$metadata", body=METADATA, status=200)
        cli_runner.invoke(app, ["contract", "bootstrap", "x"])

    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.GET,
            "https://example.com/odata/v1/Products",
            json=PRODUCTS_RESPONSE_3,
            status=200,
        )
        result = cli_runner.invoke(app, ["ingest", "x", "--limit", "1"])
    assert result.exit_code == 0, result.stdout + result.stderr

    products_dir = workspace / "landing" / "x" / "products"
    contents = []
    for f in products_dir.rglob("*.jsonl*"):
        text = gzip.decompress(f.read_bytes()).decode() if f.suffix == ".gz" else f.read_text()
        for line in text.strip().splitlines():
            contents.append(json.loads(line))
    data_rows = [row for row in contents if "_data" in row]
    assert len(data_rows) == 1, f"expected 1 record, got {len(data_rows)}"


def test_ingest_forwards_full_to_extract(workspace: Path, cli_runner: CliRunner) -> None:
    """`ingest --extract-full` wipes the extract pipeline state dir."""
    cli_runner.invoke(app, ["init"])
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "x",
            "--type",
            "odata",
            "--url",
            "https://example.com/odata/v1",
        ],
    )
    with responses.RequestsMock(assert_all_requests_are_fired=False) as rsps:
        rsps.add(responses.GET, "https://example.com/odata/v1/$metadata", body=METADATA, status=200)
        cli_runner.invoke(app, ["contract", "bootstrap", "x"])

    state_dir = workspace / ".dlt" / "pipelines" / "das_extract__x"
    state_dir.mkdir(parents=True, exist_ok=True)
    sentinel = state_dir / "sentinel.txt"
    sentinel.write_text("present")
    assert sentinel.exists()

    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.GET,
            "https://example.com/odata/v1/Products",
            json=PRODUCTS_RESPONSE,
            status=200,
        )
        result = cli_runner.invoke(app, ["ingest", "x", "--extract-full"])
    assert result.exit_code == 0, result.stdout + result.stderr

    assert not sentinel.exists(), "expected --extract-full to wipe the extract pipeline state"


def test_ingest_forwards_resource_to_extract_and_load(
    workspace: Path, cli_runner: CliRunner
) -> None:
    """`ingest --resource products` only extracts and loads `products`, not `orders`."""
    cli_runner.invoke(app, ["init"])
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "x",
            "--type",
            "odata",
            "--url",
            "https://example.com/odata/v1",
        ],
    )
    with responses.RequestsMock(assert_all_requests_are_fired=False) as rsps:
        rsps.add(
            responses.GET,
            "https://example.com/odata/v1/$metadata",
            body=METADATA_TWO_ENTITIES,
            status=200,
        )
        cli_runner.invoke(app, ["contract", "bootstrap", "x"])

    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.GET,
            "https://example.com/odata/v1/Products",
            json=PRODUCTS_RESPONSE,
            status=200,
        )
        result = cli_runner.invoke(app, ["ingest", "x", "--resource", "products"])
    assert result.exit_code == 0, result.stdout + result.stderr

    conn = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        rows = conn.execute(
            'SELECT product_id, name FROM "das__x".products ORDER BY product_id'
        ).fetchall()
        assert rows == [(1, "A"), (2, "B")]

        tables = conn.execute(
            "SELECT table_name FROM information_schema.tables " "WHERE table_schema = 'das__x'"
        ).fetchall()
        table_names = {t[0] for t in tables}
        assert (
            "orders" not in table_names
        ), f"--resource should have excluded orders, got tables: {table_names}"
    finally:
        conn.close()


def test_ingest_extract_full_resets_cursor_and_load_full_replaces_table(
    workspace: Path, cli_runner: CliRunner
) -> None:
    """`ingest --extract-full --load-full` reruns both phases in their full mode."""
    from datetime import UTC, datetime

    import duckdb
    from sqlalchemy import (
        Column,
        DateTime,
        Integer,
        MetaData,
        String,
        Table,
        create_engine,
        insert,
    )

    db = workspace / "demo.sqlite"
    engine = create_engine(f"sqlite:///{db}")
    md = MetaData()
    customers = Table(
        "customers",
        md,
        Column("customer_id", Integer, primary_key=True),
        Column("name", String(100), nullable=False),
        Column("updated_at", DateTime, nullable=False),
    )
    md.create_all(engine)
    with engine.begin() as conn:
        conn.execute(
            insert(customers),
            [
                {
                    "customer_id": 1,
                    "name": "Ada",
                    "updated_at": datetime(2026, 5, 1, tzinfo=UTC),
                },
                {
                    "customer_id": 2,
                    "name": "Linus",
                    "updated_at": datetime(2026, 5, 2, tzinfo=UTC),
                },
            ],
        )
    engine.dispose()

    cli_runner.invoke(app, ["init"])
    src_dir = workspace / "contracts" / "demo"
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(
        f"type: sql\nendpoint: sqlite:///{db}\nspec:\n  kind: sql\nauth:\n  type: none\n"
    )
    cli_runner.invoke(app, ["contract", "bootstrap", "demo"])

    first = cli_runner.invoke(app, ["ingest", "demo"])
    assert first.exit_code == 0, first.output

    second = cli_runner.invoke(app, ["ingest", "demo", "--extract-full", "--load-full"])
    assert second.exit_code == 0, second.output

    # extract --full should have produced a second landing load_id with all rows.
    import gzip
    import json

    landing = workspace / "landing" / "demo" / "customers"
    by_load: dict[str, set[int]] = {}
    for f in landing.rglob("*.jsonl*"):
        text = gzip.decompress(f.read_bytes()).decode() if f.suffix == ".gz" else f.read_text()
        for line in text.strip().splitlines():
            r = json.loads(line)
            if "_data" not in r:
                continue
            by_load.setdefault(r.get("_dlt_load_id", "?"), set()).add(r["_data"]["customer_id"])
    loads_in_order = [by_load[k] for k in sorted(by_load)]
    assert len(loads_in_order) >= 2, by_load
    assert loads_in_order[-1] == {1, 2}

    # load --full should leave exactly the two customers in the destination.
    conn = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        rows = conn.execute(
            'SELECT customer_id, name FROM "das__demo".customers ORDER BY customer_id'
        ).fetchall()
    finally:
        conn.close()
    assert rows == [(1, "Ada"), (2, "Linus")], rows
