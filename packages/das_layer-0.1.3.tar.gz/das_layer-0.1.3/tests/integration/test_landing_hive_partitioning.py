"""DuckDB hive_partitioning=true on landing surfaces _extracted_on as a column.

See ADR-0013.
"""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

import duckdb
import responses
from typer.testing import CliRunner

from das_cli.cli import app

METADATA = """\
<?xml version="1.0" encoding="UTF-8"?>
<edmx:Edmx xmlns:edmx="http://docs.oasis-open.org/odata/ns/edmx" Version="4.0">
  <edmx:DataServices>
    <Schema xmlns="http://docs.oasis-open.org/odata/ns/edm" Namespace="X.M">
      <EntityType Name="Product">
        <Key><PropertyRef Name="ProductId" /></Key>
        <Property Name="ProductId" Type="Edm.Int32" Nullable="false" />
        <Property Name="Name" Type="Edm.String" Nullable="false" />
      </EntityType>
    </Schema>
  </edmx:DataServices>
</edmx:Edmx>
"""

PRODUCTS_RESPONSE = {
    "value": [
        {"ProductId": 1, "Name": "A"},
        {"ProductId": 2, "Name": "B"},
    ]
}


def test_landing_hive_partitioning_surfaces_extracted_on(
    workspace: Path, cli_runner: CliRunner
) -> None:
    cli_runner.invoke(app, ["init"])
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "x",
            "--type",
            "odata",
            "--url",
            "https://example.com/odata/v1",
        ],
    )
    with responses.RequestsMock(assert_all_requests_are_fired=False) as rsps:
        rsps.add(
            responses.GET,
            "https://example.com/odata/v1/$metadata",
            body=METADATA,
            status=200,
        )
        cli_runner.invoke(app, ["contract", "bootstrap", "x"])

    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.GET,
            "https://example.com/odata/v1/Products",
            json=PRODUCTS_RESPONSE,
            status=200,
        )
        result = cli_runner.invoke(app, ["extract", "x"])
    assert result.exit_code == 0, result.stdout

    glob = str(workspace / "landing" / "x" / "products" / "**" / "*.jsonl.gz")
    today = datetime.now(UTC).date()

    conn = duckdb.connect(":memory:")
    try:
        rows = conn.execute(
            f"SELECT _extracted_on, COUNT(*) "
            f"FROM read_json('{glob}', hive_partitioning=true) "
            f"GROUP BY _extracted_on"
        ).fetchall()
    finally:
        conn.close()

    assert len(rows) == 1, f"expected one partition, got {rows}"
    partition_date, count = rows[0]
    assert partition_date == today
    assert count == 2  # PRODUCTS_RESPONSE has two rows
