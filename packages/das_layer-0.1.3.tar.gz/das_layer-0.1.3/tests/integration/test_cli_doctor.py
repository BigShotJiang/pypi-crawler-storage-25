from pathlib import Path

import pytest
import responses
from typer.testing import CliRunner

from das_cli.cli import app


def test_doctor_passes_clean_workspace(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "x",
            "--type",
            "odata",
            "--url",
            "https://example.com/odata/v1",
        ],
    )
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.GET,
            "https://example.com/odata/v1/$metadata",
            body="<edmx />",
            status=200,
        )
        result = cli_runner.invoke(app, ["doctor"])
    assert result.exit_code == 0, result.stdout + result.stderr


def test_doctor_fails_when_source_unreachable(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "x",
            "--type",
            "odata",
            "--url",
            "https://example.invalid/odata/v1",
        ],
    )
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.GET,
            "https://example.invalid/odata/v1/$metadata",
            status=500,
        )
        result = cli_runner.invoke(app, ["doctor"])
    assert result.exit_code == 4


def test_doctor_fails_when_das_yaml_invalid(
    tmp_path: Path, cli_runner: CliRunner, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    (tmp_path / "das.yaml").write_text("not: valid: yaml: !!!:")
    result = cli_runner.invoke(app, ["doctor"])
    assert result.exit_code == 4


def test_doctor_passes_clean_ducklake_workspace(
    ducklake_workspace: Path, cli_runner: CliRunner
) -> None:
    # The fixture writes a complete das.yaml; doctor should pass it.
    result = cli_runner.invoke(app, ["doctor"])
    assert result.exit_code == 0, result.output


def test_doctor_flags_ducklake_missing_catalog(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, cli_runner: CliRunner
) -> None:
    monkeypatch.chdir(tmp_path)
    (tmp_path / "das.yaml").write_text(
        """\
target:
  destination: ducklake
  credentials:
    storage: ./ducklake_data

landing:
  bucket_url: ./landing
  credentials: {}

contracts:
  root: ./contracts
"""
    )
    (tmp_path / "contracts").mkdir()
    result = cli_runner.invoke(app, ["doctor"])
    assert result.exit_code == 4
    assert "credentials.catalog" in result.output


def test_doctor_flags_ducklake_missing_storage(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, cli_runner: CliRunner
) -> None:
    monkeypatch.chdir(tmp_path)
    (tmp_path / "das.yaml").write_text(
        """\
target:
  destination: ducklake
  credentials:
    catalog: ./test.ducklake

landing:
  bucket_url: ./landing
  credentials: {}

contracts:
  root: ./contracts
"""
    )
    (tmp_path / "contracts").mkdir()
    result = cli_runner.invoke(app, ["doctor"])
    assert result.exit_code == 4
    assert "credentials.storage" in result.output


def test_doctor_passes_clean_delta_workspace(delta_workspace: Path, cli_runner: CliRunner) -> None:
    # The fixture writes a complete das.yaml; doctor should pass it.
    result = cli_runner.invoke(app, ["doctor"])
    assert result.exit_code == 0, result.output


def test_doctor_flags_delta_missing_bucket_url(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, cli_runner: CliRunner
) -> None:
    monkeypatch.chdir(tmp_path)
    (tmp_path / "das.yaml").write_text(
        """\
target:
  destination: delta
  credentials: {}

landing:
  bucket_url: ./landing
  credentials: {}

contracts:
  root: ./contracts
"""
    )
    (tmp_path / "contracts").mkdir()
    result = cli_runner.invoke(app, ["doctor"])
    assert result.exit_code == 4
    assert "credentials.bucket_url" in result.output


def test_doctor_flags_unparseable_sql_endpoint(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    src_dir = workspace / "contracts" / "demo"
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(
        "type: sql\n" "endpoint: not-a-url\n" "spec:\n  kind: sql\n" "auth:\n  type: none\n"
    )
    result = cli_runner.invoke(app, ["doctor"])
    # exit code 6 == DOCTOR_FAILURE per src/das_cli/exit_codes.py
    assert result.exit_code != 0
    assert "demo" in (result.stdout + result.stderr)
    assert "endpoint" in (result.stdout + result.stderr).lower()


def test_doctor_passes_for_valid_sqlite_url(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    src_dir = workspace / "contracts" / "demo"
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(
        f"type: sql\n"
        f"endpoint: sqlite:///{workspace / 'demo.sqlite'}\n"
        f"spec:\n  kind: sql\n"
        f"auth:\n  type: none\n"
    )
    result = cli_runner.invoke(app, ["doctor"])
    assert result.exit_code == 0, result.stdout + result.stderr
