"""Integration: `das contract bootstrap` against a real SQLite DB. See ADR-0018."""

from __future__ import annotations

from pathlib import Path

import yaml
from sqlalchemy import (
    Column,
    DateTime,
    Integer,
    MetaData,
    Numeric,
    String,
    Table,
    create_engine,
)
from typer.testing import CliRunner

from das_cli.cli import app


def _seed_sqlite(path: Path) -> None:
    engine = create_engine(f"sqlite:///{path}")
    md = MetaData()
    Table(
        "customers",
        md,
        Column("customer_id", Integer, primary_key=True),
        Column("name", String(100), nullable=False),
        Column("updated_at", DateTime, nullable=False),
    )
    Table(
        "orders",
        md,
        Column("order_id", Integer, primary_key=True),
        Column("line_no", Integer, primary_key=True),
        Column("amount", Numeric(12, 2), nullable=False),
    )
    md.create_all(engine)
    engine.dispose()


def test_bootstrap_sql_emits_one_contract_per_table(workspace: Path, cli_runner: CliRunner) -> None:
    db_path = workspace / "demo.sqlite"
    _seed_sqlite(db_path)

    cli_runner.invoke(app, ["init"])
    src_dir = workspace / "contracts" / "demo"
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(
        f"type: sql\n"
        f"endpoint: sqlite:///{db_path}\n"
        f"spec:\n  kind: sql\n"
        f"auth:\n  type: none\n"
    )

    result = cli_runner.invoke(app, ["contract", "bootstrap", "demo"])
    assert result.exit_code == 0, result.stdout + result.stderr

    yamls = sorted(p.name for p in src_dir.glob("*.odcs.yaml"))
    assert yamls == ["customers.odcs.yaml", "orders.odcs.yaml"]


def test_bootstrap_sql_writes_pks_and_cursor(workspace: Path, cli_runner: CliRunner) -> None:
    db_path = workspace / "demo.sqlite"
    _seed_sqlite(db_path)

    cli_runner.invoke(app, ["init"])
    src_dir = workspace / "contracts" / "demo"
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(
        f"type: sql\n"
        f"endpoint: sqlite:///{db_path}\n"
        f"spec:\n  kind: sql\n"
        f"auth:\n  type: none\n"
    )

    cli_runner.invoke(app, ["contract", "bootstrap", "demo"])
    customers_yaml = yaml.safe_load((src_dir / "customers.odcs.yaml").read_text())
    pks = [p["name"] for p in customers_yaml["schema"][0]["properties"] if p.get("primaryKey")]
    assert pks == ["customer_id"]

    cursor_props = [
        cp for cp in customers_yaml.get("customProperties", []) if cp["property"] == "das.cursor"
    ]
    assert cursor_props == [{"property": "das.cursor", "value": "updated_at"}]
