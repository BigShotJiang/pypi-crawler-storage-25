import gzip
import json
from pathlib import Path

from typer.testing import CliRunner

from das_cli.cli import app

CONTRACT = """\
apiVersion: v3.0.0
kind: DataContract
id: x.products
name: Products
version: 0.1.0
status: draft
info: { title: Products, owner: x }
schema:
  - name: products
    physicalName: products
    physicalType: table
    properties:
      - name: product_id
        physicalName: ProductId
        logicalType: integer
        primaryKey: true
        required: true
      - { name: name, physicalName: Name, logicalType: string, required: true }
"""

SOURCE_YML = """\
type: odata
endpoint: https://example.com/odata/v1
spec: { kind: odata, metadata_url: https://example.com/odata/v1/$metadata }
auth: { type: none }
"""


def _setup(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    src = workspace / "contracts" / "x"
    src.mkdir(parents=True)
    (src / "_source.yml").write_text(SOURCE_YML)
    (src / "products.odcs.yaml").write_text(CONTRACT)


def _write_landing(workspace: Path, records: list[dict[str, object]]) -> None:
    landing = workspace / "landing" / "x" / "products"
    landing.mkdir(parents=True, exist_ok=True)
    out = landing / "1.jsonl.gz"
    # Include _dlt_load_id so the load pipeline can derive _extracted_at.
    payload = (
        "\n".join(
            json.dumps({"_data": r, "_dlt_load_id": "1700000000", "_dlt_id": f"id-{i}"})
            for i, r in enumerate(records)
        )
        + "\n"
    )
    with gzip.open(out, "wt") as f:
        f.write(payload)


def test_freeze_rejects_extra_field(workspace: Path, cli_runner: CliRunner) -> None:
    """An ODCS contract without `Color` should reject landing data containing `Color`."""
    _setup(workspace, cli_runner)
    _write_landing(
        workspace,
        [
            {"ProductId": 1, "Name": "A"},  # contract-conformant
        ],
    )
    r = cli_runner.invoke(app, ["load", "x"])
    assert r.exit_code == 0  # baseline succeeds

    # Now landing carries an extra source-side field. Projection drops it
    # (only contract columns are emitted by P2), so this *passes* —
    # documenting the contract-projection behavior. Drift in the destination
    # is what `schema_contract: freeze` actually catches.
    _write_landing(
        workspace,
        [
            {"ProductId": 2, "Name": "B", "Color": "Red"},
        ],
    )
    r = cli_runner.invoke(app, ["load", "x"])
    assert r.exit_code == 0  # extra fields outside the projection don't drift dlt's schema


def test_freeze_rejects_changed_type(workspace: Path, cli_runner: CliRunner) -> None:
    """A contract-declared integer column receiving strings should fail freeze."""

    _setup(workspace, cli_runner)
    _write_landing(workspace, [{"ProductId": 1, "Name": "A"}])
    cli_runner.invoke(app, ["load", "x"])

    # Tamper with the contract: change product_id to text. dlt's freeze should
    # reject the second load because the destination already has bigint.
    contract_path = workspace / "contracts" / "x" / "products.odcs.yaml"
    text = contract_path.read_text()
    text = text.replace("logicalType: integer", "logicalType: string", 1)
    text = text.replace("physicalType: bigint", "")
    contract_path.write_text(text)

    _write_landing(workspace, [{"ProductId": "now-a-string", "Name": "B"}])
    r = cli_runner.invoke(app, ["load", "x"])
    assert r.exit_code == 5
