import gzip
import json
from pathlib import Path

import responses
from typer.testing import CliRunner

from das_cli.cli import app

METADATA_XML = """\
<?xml version="1.0" encoding="UTF-8"?>
<edmx:Edmx xmlns:edmx="http://docs.oasis-open.org/odata/ns/edmx" Version="4.0">
  <edmx:DataServices>
    <Schema xmlns="http://docs.oasis-open.org/odata/ns/edm" Namespace="X.M">
      <EntityType Name="Product">
        <Key><PropertyRef Name="ProductId" /></Key>
        <Property Name="ProductId" Type="Edm.Int32" Nullable="false" />
        <Property Name="Name" Type="Edm.String" Nullable="false" />
        <Property Name="ModifiedDate" Type="Edm.DateTimeOffset" />
      </EntityType>
    </Schema>
  </edmx:DataServices>
</edmx:Edmx>
"""


def test_bootstrap_odata_writes_contracts(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "x",
            "--type",
            "odata",
            "--url",
            "https://example.com/odata/v1",
        ],
    )
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.GET,
            "https://example.com/odata/v1/$metadata",
            body=METADATA_XML,
            status=200,
            content_type="application/xml",
        )
        result = cli_runner.invoke(app, ["contract", "bootstrap", "x"])
    assert result.exit_code == 0, result.stdout + str(result.exception)

    contracts_dir = workspace / "contracts" / "x"
    assert (contracts_dir / "products.odcs.yaml").is_file()


def test_bootstrap_refuses_overwrite_without_force(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "x",
            "--type",
            "odata",
            "--url",
            "https://example.com/odata/v1",
        ],
    )
    (workspace / "contracts" / "x" / "products.odcs.yaml").write_text("# pre-existing")
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.GET,
            "https://example.com/odata/v1/$metadata",
            body=METADATA_XML,
            status=200,
        )
        result = cli_runner.invoke(app, ["contract", "bootstrap", "x"])
    assert result.exit_code != 0


def test_bootstrap_force_overwrites(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "x",
            "--type",
            "odata",
            "--url",
            "https://example.com/odata/v1",
        ],
    )
    (workspace / "contracts" / "x" / "products.odcs.yaml").write_text("# pre-existing")
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.GET,
            "https://example.com/odata/v1/$metadata",
            body=METADATA_XML,
            status=200,
        )
        result = cli_runner.invoke(app, ["contract", "bootstrap", "x", "--force"])
    assert result.exit_code == 0
    text = (workspace / "contracts" / "x" / "products.odcs.yaml").read_text()
    assert "# pre-existing" not in text


def test_bootstrap_dry_run_writes_nothing(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "x",
            "--type",
            "odata",
            "--url",
            "https://example.com/odata/v1",
        ],
    )
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.GET,
            "https://example.com/odata/v1/$metadata",
            body=METADATA_XML,
            status=200,
        )
        result = cli_runner.invoke(app, ["contract", "bootstrap", "x", "--dry-run"])
    assert result.exit_code == 0
    assert not (workspace / "contracts" / "x" / "products.odcs.yaml").exists()


def _write_landing_gz(
    workspace: Path, source: str, resource: str, records: list[dict[str, object]]
) -> None:
    """Write sample records to a gzip JSONL landing file."""
    rdir = workspace / "landing" / source / resource
    rdir.mkdir(parents=True, exist_ok=True)
    fpath = rdir / "sample.jsonl.gz"
    with gzip.open(fpath, "wt", encoding="utf-8") as fh:
        for rec in records:
            fh.write(json.dumps(rec) + "\n")


def test_bootstrap_from_sample_creates_contract(workspace: Path, cli_runner: CliRunner) -> None:
    """bootstrap --from sample reads landing files and creates a draft ODCS contract."""
    cli_runner.invoke(app, ["init"])
    cli_runner.invoke(
        app,
        ["source", "add", "x", "--type", "odata", "--url", "https://example.com/odata/v1"],
    )

    # Pre-populate a landing file with two sample records.
    _write_landing_gz(
        workspace,
        "x",
        "products",
        [
            {"_data": {"ProductId": 1, "Name": "A", "Price": 9.99}},
            {"_data": {"ProductId": 2, "Name": "B", "Price": 19.99}},
        ],
    )

    result = cli_runner.invoke(app, ["contract", "bootstrap", "x", "--from", "sample"])
    assert result.exit_code == 0, result.stdout + str(result.exception)

    contract_file = workspace / "contracts" / "x" / "products.odcs.yaml"
    assert contract_file.is_file(), "expected products.odcs.yaml to be written"

    import yaml

    data = yaml.safe_load(contract_file.read_text())
    assert data["status"] == "draft"
    custom = {p["property"]: p["value"] for p in data.get("customProperties", [])}
    assert custom.get("das.bootstrapped_from") == "sample"
    # Schema should have the three inferred fields.
    props = {p["name"] for p in data["schema"][0]["properties"]}
    assert props == {"product_id", "name", "price"}
