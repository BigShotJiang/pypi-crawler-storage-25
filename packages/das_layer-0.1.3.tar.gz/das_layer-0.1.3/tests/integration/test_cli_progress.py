"""End-to-end CLI tests for progress mode resolution."""

from __future__ import annotations

from pathlib import Path

import responses
from typer.testing import CliRunner

from das_cli.cli import app

METADATA = """\
<?xml version="1.0" encoding="UTF-8"?>
<edmx:Edmx xmlns:edmx="http://docs.oasis-open.org/odata/ns/edmx" Version="4.0">
  <edmx:DataServices>
    <Schema xmlns="http://docs.oasis-open.org/odata/ns/edm" Namespace="X.M">
      <EntityType Name="Product">
        <Key><PropertyRef Name="ProductId" /></Key>
        <Property Name="ProductId" Type="Edm.Int32" Nullable="false" />
        <Property Name="Name" Type="Edm.String" Nullable="false" />
      </EntityType>
    </Schema>
  </edmx:DataServices>
</edmx:Edmx>
"""

PRODUCTS_RESPONSE = {
    "value": [
        {"ProductId": 1, "Name": "A"},
        {"ProductId": 2, "Name": "B"},
    ]
}


def _bootstrap(workspace: Path, runner: CliRunner) -> None:
    runner.invoke(app, ["init"])
    runner.invoke(
        app,
        ["source", "add", "x", "--type", "odata", "--url", "https://example.com/odata/v1"],
    )
    with responses.RequestsMock(assert_all_requests_are_fired=False) as rsps:
        rsps.add(
            responses.GET,
            "https://example.com/odata/v1/$metadata",
            body=METADATA,
            status=200,
        )
        runner.invoke(app, ["contract", "bootstrap", "x"])


def test_extract_default_mode_under_pipe_emits_plain_lines(
    workspace: Path, cli_runner: CliRunner
) -> None:
    """CliRunner runs in non-TTY, so default mode = plain."""
    _bootstrap(workspace, cli_runner)
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.GET,
            "https://example.com/odata/v1/Products",
            json=PRODUCTS_RESPONSE,
            status=200,
        )
        result = cli_runner.invoke(app, ["extract", "x"])
    assert result.exit_code == 0, result.output
    assert "products: started" in result.output
    assert "products: 2 rows" in result.output


def test_extract_quiet_mode_emits_no_progress_lines(workspace: Path, cli_runner: CliRunner) -> None:
    _bootstrap(workspace, cli_runner)
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.GET,
            "https://example.com/odata/v1/Products",
            json=PRODUCTS_RESPONSE,
            status=200,
        )
        result = cli_runner.invoke(app, ["--quiet", "extract", "x"])
    assert result.exit_code == 0, result.output
    assert "products: started" not in result.output
    assert "extract complete" in result.output
