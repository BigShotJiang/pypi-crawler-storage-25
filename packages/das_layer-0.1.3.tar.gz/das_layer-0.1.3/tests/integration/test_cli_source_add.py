from pathlib import Path

import yaml
from typer.testing import CliRunner

from das_cli.cli import app


def test_source_add_creates_source_yml(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    result = cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "adventureworks",
            "--type",
            "odata",
            "--url",
            "https://demodata.grapecity.com/adventureworks/odata/v1",
        ],
    )
    assert result.exit_code == 0, result.stdout + result.stderr

    src = workspace / "contracts" / "adventureworks" / "_source.yml"
    assert src.is_file()
    raw = yaml.safe_load(src.read_text())
    assert raw["type"] == "odata"
    assert raw["endpoint"] == "https://demodata.grapecity.com/adventureworks/odata/v1"
    assert raw["spec"]["kind"] == "odata"
    assert raw["spec"]["metadata_url"].endswith("$metadata")
    assert raw["auth"]["type"] == "none"


def test_source_add_with_bearer_auth(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    result = cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "northwind",
            "--type",
            "openapi",
            "--url",
            "https://demodata.grapecity.com/northwind/api/v1",
            "--auth",
            "bearer",
        ],
    )
    assert result.exit_code == 0
    raw = yaml.safe_load((workspace / "contracts" / "northwind" / "_source.yml").read_text())
    assert raw["auth"]["type"] == "bearer"
    assert raw["auth"]["token"] == "{{ env_var('NORTHWIND__TOKEN') }}"


def test_source_add_refuses_existing_source(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "x",
            "--type",
            "odata",
            "--url",
            "https://e/x",
        ],
    )
    result = cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "x",
            "--type",
            "odata",
            "--url",
            "https://e/x",
        ],
    )
    assert result.exit_code != 0


def test_source_add_unknown_type_rejected(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    result = cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "x",
            "--type",
            "weird",
            "--url",
            "https://e/x",
        ],
    )
    assert result.exit_code != 0


def test_source_add_normalizes_source_name_for_env_var(
    workspace: Path, cli_runner: CliRunner
) -> None:
    cli_runner.invoke(app, ["init"])
    result = cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "my-source",
            "--type",
            "openapi",
            "--url",
            "https://e/x",
            "--auth",
            "bearer",
        ],
    )
    assert result.exit_code == 0, result.stdout + result.stderr
    raw = yaml.safe_load((workspace / "contracts" / "my-source" / "_source.yml").read_text())
    assert raw["auth"]["token"] == "{{ env_var('MY_SOURCE__TOKEN') }}"


def test_source_add_appends_env_block_bearer(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "northwind",
            "--type",
            "openapi",
            "--url",
            "https://e/x",
            "--auth",
            "bearer",
        ],
    )

    env = (workspace / ".env").read_text()
    assert "# northwind (bearer)" in env
    assert "NORTHWIND__TOKEN=" in env


def test_source_add_appends_env_block_basic(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "north",
            "--type",
            "openapi",
            "--url",
            "https://e/x",
            "--auth",
            "basic",
        ],
    )

    env = (workspace / ".env").read_text()
    assert "# north (basic)" in env
    assert "NORTH__USERNAME=" in env
    assert "NORTH__PASSWORD=" in env


def test_source_add_appends_env_block_api_key(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "north",
            "--type",
            "openapi",
            "--url",
            "https://e/x",
            "--auth",
            "api_key",
        ],
    )

    env = (workspace / ".env").read_text()
    assert "# north (api_key)" in env
    assert "NORTH__API_KEY=" in env


def test_source_add_none_auth_does_not_modify_env(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    before = (workspace / ".env").read_text()

    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "public",
            "--type",
            "openapi",
            "--url",
            "https://e/x",
            "--auth",
            "none",
        ],
    )

    after = (workspace / ".env").read_text()
    assert before == after


def test_source_add_creates_env_when_missing(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    (workspace / ".env").unlink()  # simulate user having deleted it

    result = cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "northwind",
            "--type",
            "openapi",
            "--url",
            "https://e/x",
            "--auth",
            "bearer",
        ],
    )
    assert result.exit_code == 0

    env = (workspace / ".env").read_text()
    # File was recreated from ENV_TEMPLATE plus the per-source block.
    assert "Source credentials" in env
    assert "# northwind (bearer)" in env
    assert "NORTHWIND__TOKEN=" in env


def test_source_add_sql_writes_templated_endpoint(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    result = cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "finance",
            "--type",
            "sql",
            "--url",
            "oracle+oracledb://oracle-host:1521/?service_name=XEPDB1",
        ],
    )
    assert result.exit_code == 0, result.stdout + result.stderr
    raw = yaml.safe_load((workspace / "contracts" / "finance" / "_source.yml").read_text())
    assert raw["type"] == "sql"
    assert "{{ env_var('FINANCE__USERNAME') }}" in raw["endpoint"]
    assert "{{ env_var('FINANCE__PASSWORD') }}" in raw["endpoint"]
    assert raw["endpoint"].endswith("@oracle-host:1521/?service_name=XEPDB1")
    assert raw["spec"] == {"kind": "sql"}
    assert raw["auth"]["type"] == "none"

    env_text = (workspace / ".env").read_text()
    assert "FINANCE__USERNAME=" in env_text
    assert "FINANCE__PASSWORD=" in env_text


def test_source_add_sql_rejects_userinfo_in_url(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    result = cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "finance",
            "--type",
            "sql",
            "--url",
            "oracle+oracledb://scott:tiger@oracle-host:1521/?service_name=XEPDB1",
        ],
    )
    assert result.exit_code == 2, result.stdout + result.stderr
    assert "credentials" in (result.stdout + result.stderr).lower()


def test_source_add_sql_rejects_auth_flag(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    result = cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "finance",
            "--type",
            "sql",
            "--url",
            "oracle+oracledb://oracle-host:1521/?service_name=XE",
            "--auth",
            "basic",
        ],
    )
    assert result.exit_code == 2
    msg = (result.stdout + result.stderr).lower()
    assert "auth" in msg and "sql" in msg
