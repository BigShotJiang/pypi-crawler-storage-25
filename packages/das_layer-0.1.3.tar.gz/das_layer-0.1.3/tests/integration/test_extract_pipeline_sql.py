"""Integration: `das extract` against a real SQLite source. See ADR-0018."""

from __future__ import annotations

import gzip
import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from sqlalchemy import (
    Column,
    DateTime,
    Integer,
    MetaData,
    String,
    Table,
    create_engine,
    insert,
)
from typer.testing import CliRunner

from das_cli.cli import app


def _seed_sqlite(path: Path, *, rows: list[dict[str, Any]]) -> None:
    engine = create_engine(f"sqlite:///{path}")
    md = MetaData()
    customers = Table(
        "customers",
        md,
        Column("customer_id", Integer, primary_key=True),
        Column("name", String(100), nullable=False),
        Column("updated_at", DateTime, nullable=False),
    )
    md.create_all(engine)
    with engine.begin() as conn:
        conn.execute(insert(customers), rows)
    engine.dispose()


def _read_jsonl(landing_dir: Path) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for f in landing_dir.rglob("*.jsonl*"):
        text = gzip.decompress(f.read_bytes()).decode() if f.suffix == ".gz" else f.read_text()
        for line in text.strip().splitlines():
            out.append(json.loads(line))
    return [r for r in out if "_data" in r]


def test_sql_extract_writes_jsonl_blobs(workspace: Path, cli_runner: CliRunner) -> None:
    db = workspace / "demo.sqlite"
    _seed_sqlite(
        db,
        rows=[
            {
                "customer_id": 1,
                "name": "Ada",
                "updated_at": datetime(2026, 5, 1, tzinfo=UTC),
            },
            {
                "customer_id": 2,
                "name": "Linus",
                "updated_at": datetime(2026, 5, 2, tzinfo=UTC),
            },
        ],
    )

    cli_runner.invoke(app, ["init"])
    src_dir = workspace / "contracts" / "demo"
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(
        f"type: sql\nendpoint: sqlite:///{db}\nspec:\n  kind: sql\nauth:\n  type: none\n"
    )

    boot = cli_runner.invoke(app, ["contract", "bootstrap", "demo"])
    assert boot.exit_code == 0, boot.stdout + boot.stderr

    result = cli_runner.invoke(app, ["extract", "demo"])
    assert result.exit_code == 0, result.stdout + result.stderr

    blobs = _read_jsonl(workspace / "landing" / "demo" / "customers")
    payloads = [r["_data"] for r in blobs]
    assert {p["customer_id"] for p in payloads} == {1, 2}
    assert {p["name"] for p in payloads} == {"Ada", "Linus"}


def test_sql_extract_cursor_picks_up_only_new_rows(workspace: Path, cli_runner: CliRunner) -> None:
    db = workspace / "demo.sqlite"
    _seed_sqlite(
        db,
        rows=[
            {
                "customer_id": 1,
                "name": "Ada",
                "updated_at": datetime(2026, 5, 1, tzinfo=UTC),
            },
        ],
    )

    cli_runner.invoke(app, ["init"])
    src_dir = workspace / "contracts" / "demo"
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(
        f"type: sql\nendpoint: sqlite:///{db}\nspec:\n  kind: sql\nauth:\n  type: none\n"
    )
    cli_runner.invoke(app, ["contract", "bootstrap", "demo"])

    first = cli_runner.invoke(app, ["extract", "demo"])
    assert first.exit_code == 0, first.stdout + first.stderr

    # Insert a second row with a later updated_at; cursor should pick only it up.
    engine = create_engine(f"sqlite:///{db}")
    md = MetaData()
    customers = Table("customers", md, autoload_with=engine)
    with engine.begin() as conn:
        conn.execute(
            insert(customers),
            [
                {
                    "customer_id": 2,
                    "name": "Linus",
                    "updated_at": datetime(2026, 5, 2, tzinfo=UTC),
                }
            ],
        )
    engine.dispose()

    second = cli_runner.invoke(app, ["extract", "demo"])
    assert second.exit_code == 0, second.stdout + second.stderr

    blobs = _read_jsonl(workspace / "landing" / "demo" / "customers")
    customer_ids_per_load: dict[str, set[int]] = {}
    for r in blobs:
        load = r.get("_dlt_load_id", "?")
        customer_ids_per_load.setdefault(load, set()).add(r["_data"]["customer_id"])
    # Two distinct load_ids; the second contains only customer_id 2.
    second_load_ids = sorted(customer_ids_per_load.values(), key=lambda s: min(s))
    assert second_load_ids[0] == {1}
    assert second_load_ids[1] == {2}


def test_sql_extract_decimal_with_scale_round_trips(workspace: Path, cli_runner: CliRunner) -> None:
    """A `Numeric(12, 2)` SQL column round-trips losslessly through P1 → P2."""
    from decimal import Decimal

    import duckdb
    from sqlalchemy import Numeric

    db = workspace / "demo.sqlite"
    engine = create_engine(f"sqlite:///{db}")
    md = MetaData()
    orders = Table(
        "orders",
        md,
        Column("order_id", Integer, primary_key=True),
        Column("amount", Numeric(12, 2), nullable=False),
        Column("updated_at", DateTime, nullable=False),
    )
    md.create_all(engine)
    with engine.begin() as conn:
        conn.execute(
            insert(orders),
            [
                {
                    "order_id": 1,
                    "amount": Decimal("1234.56"),
                    "updated_at": datetime(2026, 5, 1, tzinfo=UTC),
                },
                {
                    "order_id": 2,
                    "amount": Decimal("0.01"),
                    "updated_at": datetime(2026, 5, 2, tzinfo=UTC),
                },
                {
                    "order_id": 3,
                    "amount": Decimal("99999999.99"),
                    "updated_at": datetime(2026, 5, 3, tzinfo=UTC),
                },
            ],
        )
    engine.dispose()

    cli_runner.invoke(app, ["init"])
    src_dir = workspace / "contracts" / "demo"
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(
        f"type: sql\nendpoint: sqlite:///{db}\nspec:\n  kind: sql\nauth:\n  type: none\n"
    )

    boot = cli_runner.invoke(app, ["contract", "bootstrap", "demo"])
    assert boot.exit_code == 0, boot.stdout + boot.stderr

    extracted = cli_runner.invoke(app, ["extract", "demo"])
    assert extracted.exit_code == 0, extracted.stdout + extracted.stderr

    loaded = cli_runner.invoke(app, ["load", "demo"])
    assert loaded.exit_code == 0, loaded.stdout + loaded.stderr

    conn = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        rows = conn.execute(
            'SELECT order_id, amount FROM "das__demo".orders ORDER BY order_id'
        ).fetchall()
    finally:
        conn.close()

    assert rows == [
        (1, Decimal("1234.56")),
        (2, Decimal("0.01")),
        (3, Decimal("99999999.99")),
    ]


def test_sql_extract_full_resets_cursor_and_replays_source(
    workspace: Path, cli_runner: CliRunner
) -> None:
    db = workspace / "demo.sqlite"
    _seed_sqlite(
        db,
        rows=[
            {
                "customer_id": 1,
                "name": "Ada",
                "updated_at": datetime(2026, 5, 1, tzinfo=UTC),
            },
            {
                "customer_id": 2,
                "name": "Linus",
                "updated_at": datetime(2026, 5, 2, tzinfo=UTC),
            },
        ],
    )

    cli_runner.invoke(app, ["init"])
    src_dir = workspace / "contracts" / "demo"
    src_dir.mkdir(parents=True)
    (src_dir / "_source.yml").write_text(
        f"type: sql\nendpoint: sqlite:///{db}\nspec:\n  kind: sql\nauth:\n  type: none\n"
    )
    cli_runner.invoke(app, ["contract", "bootstrap", "demo"])

    cli_runner.invoke(app, ["extract", "demo"])
    second = cli_runner.invoke(app, ["extract", "demo", "--full"])
    assert second.exit_code == 0, second.stdout + second.stderr

    blobs = _read_jsonl(workspace / "landing" / "demo" / "customers")
    by_load: dict[str, set[int]] = {}
    for r in blobs:
        load = r.get("_dlt_load_id", "?")
        by_load.setdefault(load, set()).add(r["_data"]["customer_id"])
    loads_in_order = [by_load[k] for k in sorted(by_load)]
    assert len(loads_in_order) >= 2, by_load
    assert loads_in_order[0] == {1, 2}
    assert loads_in_order[1] == {1, 2}
