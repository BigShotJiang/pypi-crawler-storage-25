from __future__ import annotations

import gzip
import json
from datetime import UTC, date, datetime
from pathlib import Path

import duckdb
import pytest
from typer.testing import CliRunner

from das_cli.cli import app

CONTRACT = """\
apiVersion: v3.0.0
kind: DataContract
id: x.products
name: Products
version: 0.1.0
status: draft
info: { title: Products, owner: x }
schema:
  - name: products
    physicalName: products
    physicalType: table
    properties:
      - name: product_id
        physicalName: ProductId
        logicalType: integer
        physicalType: bigint
        required: true
        primaryKey: true
      - { name: name, physicalName: Name, logicalType: string, required: true }
"""


SOURCE_YML = """\
type: odata
endpoint: https://example.com/odata/v1
spec:
  kind: odata
  metadata_url: https://example.com/odata/v1/$metadata
auth: { type: none }
"""


def _setup_workspace(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    src = workspace / "contracts" / "x"
    src.mkdir(parents=True, exist_ok=True)
    (src / "_source.yml").write_text(SOURCE_YML)
    (src / "products.odcs.yaml").write_text(CONTRACT)


def _write_landing(workspace: Path, records: list[dict[str, object]]) -> None:
    landing = workspace / "landing" / "x" / "products"
    landing.mkdir(parents=True, exist_ok=True)
    out = landing / "1.jsonl.gz"
    # Include _dlt_load_id so the load pipeline can derive _extracted_at.
    payload = (
        "\n".join(
            json.dumps({"_data": r, "_dlt_load_id": "1700000000", "_dlt_id": f"id-{i}"})
            for i, r in enumerate(records)
        )
        + "\n"
    )
    with gzip.open(out, "wt") as f:
        f.write(payload)


def test_load_creates_table_with_contract_schema(workspace: Path, cli_runner: CliRunner) -> None:
    _setup_workspace(workspace, cli_runner)
    _write_landing(
        workspace,
        [
            {"ProductId": 1, "Name": "A"},
            {"ProductId": 2, "Name": "B"},
        ],
    )

    result = cli_runner.invoke(app, ["load", "x"])
    assert result.exit_code == 0, result.output

    db = workspace / "test.duckdb"
    assert db.is_file()
    conn = duckdb.connect(str(db), read_only=True)
    try:
        rows = conn.execute(
            'SELECT product_id, name FROM "das__x".products ORDER BY product_id'
        ).fetchall()
        assert rows == [(1, "A"), (2, "B")]
    finally:
        conn.close()


def test_load_includes_row_hash(workspace: Path, cli_runner: CliRunner) -> None:
    _setup_workspace(workspace, cli_runner)
    _write_landing(workspace, [{"ProductId": 1, "Name": "A"}])

    result = cli_runner.invoke(app, ["load", "x"])
    assert result.exit_code == 0

    conn = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        cols = [c[0] for c in conn.execute('DESCRIBE "das__x".products').fetchall()]
    finally:
        conn.close()
    assert "_row_hash" in cols


def test_load_change_detection_suppresses_duplicate(workspace: Path, cli_runner: CliRunner) -> None:
    _setup_workspace(workspace, cli_runner)
    _write_landing(workspace, [{"ProductId": 1, "Name": "A"}])

    cli_runner.invoke(app, ["load", "x"])
    # second load with identical landing should not append duplicates
    cli_runner.invoke(app, ["load", "x"])

    conn = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        row = conn.execute('SELECT COUNT(*) FROM "das__x".products').fetchone()
        count = row[0] if row is not None else 0
    finally:
        conn.close()
    assert count == 1


def test_load_a_b_a_preserved(workspace: Path, cli_runner: CliRunner) -> None:
    _setup_workspace(workspace, cli_runner)

    _write_landing(workspace, [{"ProductId": 1, "Name": "A"}])
    cli_runner.invoke(app, ["load", "x"])

    # Replace landing with B
    landing = workspace / "landing" / "x" / "products"
    for f in landing.glob("*"):
        f.unlink()
    _write_landing(workspace, [{"ProductId": 1, "Name": "B"}])
    cli_runner.invoke(app, ["load", "x"])

    # Replace landing with A again
    for f in landing.glob("*"):
        f.unlink()
    _write_landing(workspace, [{"ProductId": 1, "Name": "A"}])
    cli_runner.invoke(app, ["load", "x"])

    conn = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        rows = conn.execute('SELECT name FROM "das__x".products ORDER BY _dlt_load_id').fetchall()
    finally:
        conn.close()
    assert [r[0] for r in rows] == ["A", "B", "A"]


def test_load_extra_fields_dropped_by_projection(workspace: Path, cli_runner: CliRunner) -> None:
    """Source-side fields not in the contract are silently dropped by the projection layer.

    This is by design — explicit type drift is the failing case, tested in
    test_freeze_rejects_changed_type (see tests/integration/test_schema_contract_freeze.py).
    """
    _setup_workspace(workspace, cli_runner)
    _write_landing(
        workspace,
        [
            {"ProductId": 1, "Name": "A", "ExtraField": "drift"},
        ],
    )

    result = cli_runner.invoke(app, ["load", "x"])
    # Extra fields outside the contract are dropped by projection — not an error.
    assert result.exit_code == 0, result.output


def _write_landing_partitioned(
    workspace: Path,
    records: list[dict[str, object]],
    *,
    extracted_on: str,
    load_id: str = "1",
) -> None:
    """Write a landing file under _extracted_on=YYYY-MM-DD/ with a controlled load_id.

    The line-level _dlt_load_id determines _extracted_at in staging, so callers
    that want a specific extract timestamp must pass a matching numeric load_id
    (epoch seconds as a string) AND a matching extracted_on directory.
    """
    landing = workspace / "landing" / "x" / "products" / f"_extracted_on={extracted_on}"
    landing.mkdir(parents=True, exist_ok=True)
    out = landing / f"{load_id}.0.jsonl.gz"
    payload = (
        "\n".join(
            json.dumps({"_data": r, "_dlt_load_id": load_id, "_dlt_id": f"id-{i}"})
            for i, r in enumerate(records)
        )
        + "\n"
    )
    with gzip.open(out, "wt") as f:
        f.write(payload)


def test_load_populates_four_metadata_columns(workspace: Path, cli_runner: CliRunner) -> None:
    _setup_workspace(workspace, cli_runner)
    # Use a deterministic extract load id (epoch-as-string) so we can assert _extracted_*.
    extract_ts = "1700000000"  # 2023-11-14 22:13:20 UTC
    extract_date = "2023-11-14"
    _write_landing_partitioned(
        workspace,
        [{"ProductId": 1, "Name": "A"}, {"ProductId": 2, "Name": "B"}],
        extracted_on=extract_date,
        load_id=extract_ts,
    )

    result = cli_runner.invoke(app, ["load", "x"])
    assert result.exit_code == 0, result.output

    conn = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        # All four columns exist with correct types.
        col_info = {row[0]: row[1] for row in conn.execute('DESCRIBE "das__x".products').fetchall()}
        assert col_info["_extracted_at"].upper().startswith("TIMESTAMP")
        assert col_info["_extracted_on"] == "DATE"
        assert col_info["_loaded_at"].upper().startswith("TIMESTAMP")
        assert col_info["_loaded_on"] == "DATE"

        # All rows populated; nulls are forbidden.
        nulls = conn.execute(
            'SELECT COUNT(*) FROM "das__x".products '
            "WHERE _extracted_at IS NULL OR _extracted_on IS NULL "
            "OR _loaded_at IS NULL OR _loaded_on IS NULL"
        ).fetchone()
        assert (nulls[0] if nulls else 0) == 0

        # _extracted_on derived from line._dlt_load_id (1700000000 = 2023-11-14 UTC).
        # dlt maps data_type=timestamp to DuckDB TIMESTAMPTZ; compare against a
        # tz-aware UTC datetime — astimezone(UTC) normalizes any local-tz
        # representation DuckDB may return.
        rows = conn.execute(
            'SELECT _extracted_at, _extracted_on FROM "das__x".products LIMIT 1'
        ).fetchone()
        assert rows is not None
        expected_extracted_at = datetime.fromtimestamp(float(extract_ts), tz=UTC)
        assert rows[0].astimezone(UTC) == expected_extracted_at
        assert rows[1] == date.fromisoformat(extract_date)

        # _loaded_at::DATE == _loaded_on; _extracted_at::DATE == _extracted_on.
        mismatches = conn.execute(
            'SELECT COUNT(*) FROM "das__x".products '
            "WHERE CAST(_loaded_at AS DATE) <> _loaded_on "
            "OR CAST(_extracted_at AS DATE) <> _extracted_on"
        ).fetchone()
        assert (mismatches[0] if mismatches else 0) == 0
    finally:
        conn.close()


def test_load_loaded_at_is_constant_within_one_load(workspace: Path, cli_runner: CliRunner) -> None:
    """All rows produced by a single `das load` share one _loaded_at."""
    _setup_workspace(workspace, cli_runner)
    # Two landing files with different extract dates / load_ids — but a single load.
    _write_landing_partitioned(
        workspace,
        [{"ProductId": 1, "Name": "A"}],
        extracted_on="2023-11-14",
        load_id="1700000000",
    )
    _write_landing_partitioned(
        workspace,
        [{"ProductId": 2, "Name": "B"}],
        extracted_on="2024-06-01",
        load_id="1717200000",  # 2024-06-01 03:00:00 UTC (within that day)
    )

    result = cli_runner.invoke(app, ["load", "x"])
    assert result.exit_code == 0, result.output

    conn = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        rows = conn.execute('SELECT DISTINCT _loaded_at FROM "das__x".products').fetchall()
        assert len(rows) == 1, f"expected one _loaded_at, got {rows}"

        # Two distinct _extracted_on values (one per file).
        ext_dates = conn.execute(
            'SELECT DISTINCT _extracted_on FROM "das__x".products ORDER BY _extracted_on'
        ).fetchall()
        assert [r[0] for r in ext_dates] == [
            date(2023, 11, 14),
            date(2024, 6, 1),
        ]
    finally:
        conn.close()


def test_load_loaded_at_ge_extracted_at(workspace: Path, cli_runner: CliRunner) -> None:
    """_loaded_at >= _extracted_at for every row."""
    _setup_workspace(workspace, cli_runner)
    _write_landing_partitioned(
        workspace,
        [{"ProductId": 1, "Name": "A"}],
        extracted_on="2023-11-14",
        load_id="1700000000",
    )

    result = cli_runner.invoke(app, ["load", "x"])
    assert result.exit_code == 0, result.output

    conn = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        bad = conn.execute(
            'SELECT COUNT(*) FROM "das__x".products WHERE _loaded_at < _extracted_at'
        ).fetchone()
        assert (bad[0] if bad else 0) == 0
    finally:
        conn.close()


def test_load_mixed_layout_landing_cohabits(workspace: Path, cli_runner: CliRunner) -> None:
    """Flat-layout legacy files and partitioned new files can coexist in landing."""
    _setup_workspace(workspace, cli_runner)
    # Legacy flat-layout file (pre-v0.1.3 shape).
    _write_landing(workspace, [{"ProductId": 1, "Name": "Legacy"}])
    # New partitioned file with a different load_id (different extract day).
    _write_landing_partitioned(
        workspace,
        [{"ProductId": 2, "Name": "Partitioned"}],
        extracted_on="2024-06-01",
        load_id="1717200000",
    )

    result = cli_runner.invoke(app, ["load", "x"])
    assert result.exit_code == 0, result.output

    conn = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        rows = conn.execute(
            'SELECT name, _extracted_on FROM "das__x".products ORDER BY name'
        ).fetchall()
    finally:
        conn.close()
    # Both rows present; each has its own _extracted_on derived from its own _dlt_load_id.
    assert len(rows) == 2
    names = {r[0] for r in rows}
    assert names == {"Legacy", "Partitioned"}
    # The partitioned-file row must reflect its _dlt_load_id (1717200000 → 2024-06-01).
    by_name = dict(rows)
    assert by_name["Partitioned"] == date(2024, 6, 1)


def _setup_workspace_with_landing(workspace: Path, runner: CliRunner) -> None:
    """Stage a workspace with one contract + one landing JSONL file (2 rows)."""
    _setup_workspace(workspace, runner)
    _write_landing(workspace, [{"ProductId": 1, "Name": "A"}, {"ProductId": 2, "Name": "B"}])


def test_load_plain_mode_emits_per_resource_lines(
    workspace: Path, cli_runner: CliRunner, capsys: pytest.CaptureFixture[str]
) -> None:
    """Plain mode for load: per-resource start/finish lines."""
    from das_cli.pipelines.load import run_load
    from das_cli.progress import progress

    _setup_workspace_with_landing(workspace, cli_runner)

    with progress({"products": 2}, mode="plain") as h:
        run_load(
            config_path=workspace / "das.yaml",
            progress_handle=h,
            dlt_progress=None,
        )
    out = capsys.readouterr().out
    assert "products: started" in out
    assert "products: 2 rows" in out


def test_load_full_replaces_destination_table(workspace: Path, cli_runner: CliRunner) -> None:
    """`load --full` rebuilds the destination table from all landing files."""
    _setup_workspace(workspace, cli_runner)
    _write_landing_partitioned(
        workspace,
        [{"ProductId": 1, "Name": "A"}],
        extracted_on="2026-05-01",
        load_id="1700000000",
    )
    _write_landing_partitioned(
        workspace,
        [{"ProductId": 2, "Name": "B"}],
        extracted_on="2026-05-02",
        load_id="1700000100",
    )

    # Incremental load first — both rows land via the standard path.
    first = cli_runner.invoke(app, ["load", "x"])
    assert first.exit_code == 0, first.output

    # Insert an out-of-band marker row directly into the destination so we can
    # detect whether the table was truncated by --full.
    conn = duckdb.connect(str(workspace / "test.duckdb"))
    try:
        conn.execute(
            'INSERT INTO "das__x".products '
            "(product_id, name, _row_hash, "
            "_extracted_at, _extracted_on, _loaded_at, _loaded_on, "
            "_dlt_load_id, _dlt_id) VALUES "
            "(999, 'MARKER', 'sentinel', "
            "TIMESTAMP '2026-05-01 00:00:00', DATE '2026-05-01', "
            "TIMESTAMP '2026-05-01 00:00:00', DATE '2026-05-01', "
            "'marker', 'marker-id')"
        )
    finally:
        conn.close()

    # --full should drop+rebuild from landing — the marker must disappear.
    second = cli_runner.invoke(app, ["load", "x", "--full"])
    assert second.exit_code == 0, second.output

    conn = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        rows = conn.execute(
            'SELECT product_id, name FROM "das__x".products ORDER BY product_id'
        ).fetchall()
    finally:
        conn.close()

    assert rows == [(1, "A"), (2, "B")], rows


# A contract identical to CONTRACT but without a primary key on any property.
# Used to exercise the load --full code path that skips dedup (gated on
# `if full and primary_key`).
CONTRACT_NO_PK = """\
apiVersion: v3.0.0
kind: DataContract
id: x.products
name: Products
version: 0.1.0
status: draft
info: { title: Products, owner: x }
schema:
  - name: products
    physicalName: products
    physicalType: table
    properties:
      - name: product_id
        physicalName: ProductId
        logicalType: integer
        physicalType: bigint
        required: true
      - { name: name, physicalName: Name, logicalType: string, required: true }
"""


def _setup_workspace_no_pk(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    src = workspace / "contracts" / "x"
    src.mkdir(parents=True, exist_ok=True)
    (src / "_source.yml").write_text(SOURCE_YML)
    (src / "products.odcs.yaml").write_text(CONTRACT_NO_PK)


def test_load_full_replaces_no_pk_resource(workspace: Path, cli_runner: CliRunner) -> None:
    """`load --full` replaces the destination table for a resource without a primary key.

    The dedup path in the load pipeline is gated on `if full and primary_key`.
    Resources without a PK must still get a full table replace (dlt replace
    disposition) — all rows land, no dedup occurs.  This test verifies:
      1. The marker row inserted out-of-band is gone after --full.
      2. The row count equals the landing row count (all 3 rows, no dedup loss).
    """
    _setup_workspace_no_pk(workspace, cli_runner)
    _write_landing_partitioned(
        workspace,
        [{"ProductId": 1, "Name": "A"}],
        extracted_on="2026-05-01",
        load_id="1700000000",
    )
    _write_landing_partitioned(
        workspace,
        [{"ProductId": 2, "Name": "B"}, {"ProductId": 3, "Name": "C"}],
        extracted_on="2026-05-02",
        load_id="1700000100",
    )

    # Incremental load first — all 3 rows land via the standard path.
    first = cli_runner.invoke(app, ["load", "x"])
    assert first.exit_code == 0, first.output

    # Insert an out-of-band marker row directly into the destination so we can
    # detect whether the table was truncated by --full.
    conn = duckdb.connect(str(workspace / "test.duckdb"))
    try:
        conn.execute(
            'INSERT INTO "das__x".products '
            "(product_id, name, _row_hash, "
            "_extracted_at, _extracted_on, _loaded_at, _loaded_on, "
            "_dlt_load_id, _dlt_id) VALUES "
            "(999, 'MARKER', 'sentinel', "
            "TIMESTAMP '2026-05-01 00:00:00', DATE '2026-05-01', "
            "TIMESTAMP '2026-05-01 00:00:00', DATE '2026-05-01', "
            "'marker', 'marker-id')"
        )
    finally:
        conn.close()

    # --full should drop+rebuild from landing — the marker must disappear and
    # all 3 landing rows must be present (no dedup for no-PK resources).
    second = cli_runner.invoke(app, ["load", "x", "--full"])
    assert second.exit_code == 0, second.output

    conn = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        rows = conn.execute(
            'SELECT product_id, name FROM "das__x".products ORDER BY product_id'
        ).fetchall()
    finally:
        conn.close()

    # Marker gone; all 3 landing rows present.
    product_ids = [r[0] for r in rows]
    assert 999 not in product_ids, f"marker row should have been removed by --full: {rows}"
    assert len(rows) == 3, f"expected 3 rows (no dedup on no-PK resource), got: {rows}"
    assert rows == [(1, "A"), (2, "B"), (3, "C")], rows
