from pathlib import Path

import pytest
from typer.testing import CliRunner

from das_cli.cli import app

PRODUCTS_OK = """\
apiVersion: v3.0.0
kind: DataContract
id: x.products
name: Products
version: 0.1.0
status: draft
info: { title: Products, owner: x }
schema:
  - name: products
    physicalName: products
    physicalType: table
    properties:
      - { name: id, logicalType: integer, primaryKey: true, required: true }
      - { name: name, logicalType: string }
"""


def _setup(workspace: Path, runner: CliRunner) -> None:
    runner.invoke(app, ["init"])
    runner.invoke(app, ["source", "add", "x", "--type", "odata", "--url", "https://example.com"])


def test_validate_clean_workspace(workspace: Path, cli_runner: CliRunner) -> None:
    _setup(workspace, cli_runner)
    (workspace / "contracts" / "x" / "products.odcs.yaml").write_text(PRODUCTS_OK)
    result = cli_runner.invoke(app, ["validate"])
    assert result.exit_code == 0


def test_validate_reports_issues(workspace: Path, cli_runner: CliRunner) -> None:
    _setup(workspace, cli_runner)
    bad = PRODUCTS_OK.replace("primaryKey: true,", "")
    (workspace / "contracts" / "x" / "products.odcs.yaml").write_text(bad)
    result = cli_runner.invoke(app, ["validate"])
    assert result.exit_code == 3
    assert "primary key" in (result.stdout + result.stderr).lower()


def test_validate_missing_das_yaml(
    tmp_path: Path, cli_runner: CliRunner, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    result = cli_runner.invoke(app, ["validate"])
    assert result.exit_code == 3
