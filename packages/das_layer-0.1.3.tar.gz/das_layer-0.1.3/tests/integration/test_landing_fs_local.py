"""Integration test: landing_fs round-trip against LocalFileSystem.

Mirrors the partition layout produced by P1 (ADR-0013) so the test exercises
the same glob shape that production reads."""

from __future__ import annotations

import gzip
import json
from pathlib import Path
from typing import Any

from das_cli.dlt_glue.landing_fs import (
    count_landing_records,
    iter_landing_records,
)
from das_cli.models.das_yaml import LandingConfig


def _seed_partition(
    root: Path, source: str, resource: str, date: str, rows: list[dict[str, Any]]
) -> None:
    rdir = root / source / resource / f"_extracted_on={date}"
    rdir.mkdir(parents=True)
    with gzip.open(rdir / "1.0.jsonl.gz", "wt", encoding="utf-8") as fh:
        for r in rows:
            fh.write(json.dumps(r) + "\n")


def test_round_trip_multi_partition(tmp_path: Path) -> None:
    _seed_partition(tmp_path, "src1", "products", "2026-05-10", [{"id": 1}, {"id": 2}])
    _seed_partition(tmp_path, "src1", "products", "2026-05-11", [{"id": 3}])
    _seed_partition(tmp_path, "src1", "orders", "2026-05-12", [{"oid": "a"}])

    landing = LandingConfig(bucket_url=str(tmp_path), credentials={})

    assert count_landing_records(landing, source="src1", resource="products") == 3
    assert count_landing_records(landing, source="src1", resource="orders") == 1
    assert count_landing_records(landing, source="src1", resource="missing") == 0

    products = list(iter_landing_records(landing, source="src1", resource="products"))
    assert sorted(r["id"] for r in products) == [1, 2, 3]
