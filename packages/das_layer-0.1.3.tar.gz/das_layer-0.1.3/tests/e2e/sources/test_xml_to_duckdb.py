"""E2E: das against a local XML file, landing into DuckDB. See ADR-0022.

Opt-in via `pytest -m e2e`. Reads the fixture from tests/e2e/fixtures/xml/.
Uses the shared `workspace` + `cli_runner` fixtures from tests/conftest.py.
"""

from __future__ import annotations

import shutil
from pathlib import Path

import duckdb
from typer.testing import CliRunner

from das_cli.cli import app

FIXTURE_DIR = Path(__file__).parent.parent / "fixtures" / "xml"


def test_xml_to_duckdb_with_provenance(workspace: Path, cli_runner: CliRunner) -> None:
    """XPath-driven extraction into a single staging table with provenance."""

    data_dir = workspace / "data"
    data_dir.mkdir()
    shutil.copy(FIXTURE_DIR / "customers.xml", data_dir)

    init = cli_runner.invoke(app, ["init"])
    assert init.exit_code == 0, init.stdout + init.stderr

    add = cli_runner.invoke(
        app,
        ["source", "add", "files", "--type", "filesystem", "--url", str(data_dir)],
    )
    assert add.exit_code == 0, add.stdout + add.stderr

    boot = cli_runner.invoke(
        app,
        ["contract", "bootstrap", "files", "--xpath", "//customer"],
    )
    assert boot.exit_code == 0, boot.stdout + boot.stderr

    contracts_dir = workspace / "contracts" / "files"
    written = sorted(p.name for p in contracts_dir.glob("*.odcs.yaml"))
    assert written == ["customers.odcs.yaml"]

    # Hand-edit the contract: set primary key on id, refine types, add inject.
    (contracts_dir / "customers.odcs.yaml").write_text(
        "apiVersion: v3.0.0\n"
        "kind: DataContract\n"
        "id: files.customers\n"
        "name: customers\n"
        "version: 0.1.0\n"
        "status: draft\n"
        "info:\n  title: customers\n  owner: data-platform\n"
        "schema:\n"
        "  - name: customers\n"
        "    physicalName: customers\n"
        "    physicalType: table\n"
        "    properties:\n"
        "      - name: id\n"
        "        logicalType: integer\n"
        "        primaryKey: true\n"
        "        required: true\n"
        "      - name: name\n"
        "        logicalType: string\n"
        "      - name: signup_month\n"
        "        logicalType: string\n"
        "      - name: source_file\n"
        "        logicalType: string\n"
        "customProperties:\n"
        "  - property: das.spec_ref\n"
        "    value:\n"
        "      kind: filesystem\n"
        "      format: xml\n"
        "      path: 'customers.xml'\n"
        "      xpath: '//customer'\n"
        "      inject:\n"
        "        source_file: basename\n"
    )

    ext = cli_runner.invoke(app, ["extract", "files"])
    assert ext.exit_code == 0, ext.stdout + ext.stderr

    load = cli_runner.invoke(app, ["load", "files"])
    assert load.exit_code == 0, load.stdout + load.stderr

    db = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        rows = db.execute(
            'SELECT id, name, signup_month, source_file FROM "das__files".customers ' "ORDER BY id"
        ).fetchall()
    finally:
        db.close()

    assert rows == [
        (1, "Alice", "2024-01", "customers.xml"),
        (2, "Bob", "2024-01", "customers.xml"),
        (3, "Charlie", "2024-02", "customers.xml"),
    ]
