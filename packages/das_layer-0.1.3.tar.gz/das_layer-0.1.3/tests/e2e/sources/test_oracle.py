"""E2E: das against an Oracle Free container. See ADR-0018.

Opt-in via `pytest -m e2e`. Requires Docker.
"""

from __future__ import annotations

import base64
import os
from collections.abc import Iterator
from pathlib import Path

import duckdb
import pytest
from typer.testing import CliRunner

from das_cli.cli import app


def _split_sql_statements(sql: str) -> list[str]:
    """Split a SQL script into executable statements, stripping `--` line comments.

    Each statement (delimited by `;`) is stripped of full-line `--` comments,
    then trimmed. Empty statements and bare `COMMIT` keywords are skipped — the
    SQLAlchemy connection auto-commits at exit of `engine.begin()`.
    """
    out: list[str] = []
    for chunk in sql.split(";"):
        body_lines = [line for line in chunk.splitlines() if not line.strip().startswith("--")]
        body = "\n".join(body_lines).strip()
        if not body or body.upper() == "COMMIT":
            continue
        out.append(body)
    return out


def _scope_to_seed_tables(workspace: Path, source_name: str) -> None:
    """Pin `_source.yml` to reflect only the e2e seed tables.

    Without scoping, `bootstrap_sql_contracts` reflects every table the
    connection user can see — fine for a small fixture, but the gvenzl
    Oracle image still surfaces a handful of helper objects in APPUSER's
    schema. Pinning `tables` keeps the test deterministic.

    SQLAlchemy's Oracle dialect normalises identifiers to lowercase, so
    the filter values are lowercase even though Oracle stores them upper
    in the catalog.
    """
    src_yml = workspace / "contracts" / source_name / "_source.yml"
    text = src_yml.read_text()
    text = text.replace(
        "spec:\n  kind: sql\n",
        "spec:\n  kind: sql\n" "  tables:\n    - customers\n    - orders\n    - attachments\n",
    )
    src_yml.write_text(text)


# Credentials for the gvenzl APP_USER. Lowercase to match SQLAlchemy's Oracle
# identifier normalisation (default_schema_name returns the lowercase form).
_ORACLE_APP_USER = "appuser"
_ORACLE_APP_PWD = "apppwd1"


@pytest.fixture(scope="module")
def oracle_url() -> Iterator[str]:
    """Spin gvenzl/oracle-free:slim-faststart, run the seed, yield a SQLAlchemy URL.

    Uses the image's APP_USER feature to create a non-DBA user. SQLAlchemy's
    Oracle dialect filters out tables owned by SYSTEM/SYS/etc., so reflecting
    against the default `system` connection finds nothing. Connecting as a
    plain APP_USER bypasses that filter.
    """
    pytest.importorskip("testcontainers.oracle")
    from testcontainers.oracle import OracleDbContainer

    seed_sql = (Path(__file__).parent.parent / "fixtures" / "sql_seed_oracle.sql").read_text()

    container = OracleDbContainer("gvenzl/oracle-free:slim-faststart")
    container.with_env("APP_USER", _ORACLE_APP_USER)
    container.with_env("APP_USER_PASSWORD", _ORACLE_APP_PWD)
    container.start()
    try:
        host = container.get_container_host_ip()
        port = container.get_exposed_port(1521)
        url = (
            f"oracle+oracledb://{_ORACLE_APP_USER}:{_ORACLE_APP_PWD}"
            f"@{host}:{port}/?service_name=FREEPDB1"
        )

        from sqlalchemy import create_engine, text

        engine = create_engine(url)
        with engine.begin() as conn:
            for stmt in _split_sql_statements(seed_sql):
                conn.execute(text(stmt))
        engine.dispose()
        yield url
    finally:
        container.stop()


def test_oracle_bootstrap_extract_load(
    workspace: Path, cli_runner: CliRunner, oracle_url: str
) -> None:
    cli_runner.invoke(app, ["init"])

    from sqlalchemy.engine.url import URL, make_url

    parsed = make_url(oracle_url)
    user = parsed.username or ""
    password = parsed.password or ""
    # SQLAlchemy URL.set(username=None, ...) leaves the existing values in place;
    # rebuild explicitly without userinfo to satisfy `das source add --type sql`,
    # which rejects URLs containing credentials.
    clean_url = URL.create(
        drivername=parsed.drivername,
        host=parsed.host,
        port=parsed.port,
        database=parsed.database,
        query=parsed.query,
    ).render_as_string(hide_password=False)

    add = cli_runner.invoke(
        app,
        ["source", "add", "demo", "--type", "sql", "--url", clean_url],
    )
    assert add.exit_code == 0, add.stdout + add.stderr

    # Scope reflection to our seed tables. The gvenzl image's SYSTEM user
    # is a DBA, so without scoping bootstrap reflects every internal Oracle
    # table — making the test brittle and the load empty of relevant data.
    _scope_to_seed_tables(workspace, "demo")

    os.environ["DEMO__USERNAME"] = user
    os.environ["DEMO__PASSWORD"] = password
    try:
        boot = cli_runner.invoke(app, ["contract", "bootstrap", "demo"])
        assert boot.exit_code == 0, boot.stdout + boot.stderr

        ext = cli_runner.invoke(app, ["extract", "demo"])
        assert ext.exit_code == 0, ext.stdout + ext.stderr

        load = cli_runner.invoke(app, ["load", "demo"])
        assert load.exit_code == 0, load.stdout + load.stderr
    finally:
        os.environ.pop("DEMO__USERNAME", None)
        os.environ.pop("DEMO__PASSWORD", None)

    db = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        rows = db.execute('SELECT COUNT(*) FROM "das__demo".customers').fetchone()
        assert rows is not None and rows[0] == 3, rows

        order_rows = db.execute('SELECT COUNT(*) FROM "das__demo".orders').fetchone()
        assert order_rows is not None and order_rows[0] == 3, order_rows

        att = db.execute(
            'SELECT payload FROM "das__demo".attachments WHERE attachment_id = 1'
        ).fetchone()
        assert att is not None
        assert base64.b64decode(att[0]) == b"hello"

        named = db.execute(
            'SELECT COUNT(*) FROM "das__demo".customers WHERE name IS NOT NULL'
        ).fetchone()
        assert named is not None and named[0] == 3, named
    finally:
        db.close()


def test_oracle_second_extract_uses_cursor(
    workspace: Path, cli_runner: CliRunner, oracle_url: str
) -> None:
    """Second extract pulls only rows newer than the cursor state."""
    from sqlalchemy import create_engine, text
    from sqlalchemy.engine.url import URL, make_url

    parsed = make_url(oracle_url)
    user = parsed.username or ""
    password = parsed.password or ""
    # See test_oracle_bootstrap_extract_load for why URL.create over .set().
    clean_url = URL.create(
        drivername=parsed.drivername,
        host=parsed.host,
        port=parsed.port,
        database=parsed.database,
        query=parsed.query,
    ).render_as_string(hide_password=False)

    cli_runner.invoke(app, ["init"])
    add = cli_runner.invoke(app, ["source", "add", "demo", "--type", "sql", "--url", clean_url])
    assert add.exit_code == 0

    _scope_to_seed_tables(workspace, "demo")

    os.environ["DEMO__USERNAME"] = user
    os.environ["DEMO__PASSWORD"] = password
    try:
        cli_runner.invoke(app, ["contract", "bootstrap", "demo"])
        first = cli_runner.invoke(app, ["extract", "demo", "--resource", "customers"])
        assert first.exit_code == 0, first.stdout + first.stderr

        engine = create_engine(oracle_url)
        with engine.begin() as conn:
            conn.execute(
                text(
                    "INSERT INTO customers (customer_id, name, created_at, updated_at) "
                    "VALUES (4, 'Margaret Hamilton', "
                    "TIMESTAMP '2026-06-01 10:00:00', TIMESTAMP '2026-06-01 10:00:00')"
                )
            )
        engine.dispose()

        second = cli_runner.invoke(app, ["extract", "demo", "--resource", "customers"])
        assert second.exit_code == 0, second.stdout + second.stderr

        load = cli_runner.invoke(app, ["load", "demo", "--resource", "customers"])
        assert load.exit_code == 0, load.stdout + load.stderr
    finally:
        os.environ.pop("DEMO__USERNAME", None)
        os.environ.pop("DEMO__PASSWORD", None)

    db = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        rows = db.execute('SELECT COUNT(*) FROM "das__demo".customers').fetchone()
        assert rows is not None and rows[0] == 4, rows
    finally:
        db.close()
