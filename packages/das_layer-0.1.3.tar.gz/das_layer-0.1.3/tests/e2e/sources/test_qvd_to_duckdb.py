"""E2E: das against a local .qvd file, landing into DuckDB. See ADR-0022.

Opt-in via `pytest -m e2e`. Builds the fixture in tmp_path via pyqvd so
no binary file is committed. Pattern mirrors test_excel_to_duckdb.py.
"""

from __future__ import annotations

import io
from pathlib import Path

import duckdb
from pyqvd import QvdTable
from typer.testing import CliRunner

from das_cli.cli import app


def _stage_qvd(data_dir: Path) -> None:
    t = QvdTable.from_dict(
        {
            "columns": ["customer_id", "name", "amount"],
            "data": [
                [1, "Alice", 9.95],
                [2, "Bob", 19.50],
                [3, "Charlie", 99.00],
            ],
        }
    )
    buf = io.BytesIO()
    t.to_stream(buf)
    (data_dir / "customers.qvd").write_bytes(buf.getvalue())


def test_qvd_to_duckdb_with_provenance(workspace: Path, cli_runner: CliRunner) -> None:
    """QVD → DuckDB with type-aware schema + inject for provenance."""

    data_dir = workspace / "data"
    data_dir.mkdir()
    _stage_qvd(data_dir)

    init = cli_runner.invoke(app, ["init"])
    assert init.exit_code == 0, init.stdout + init.stderr

    add = cli_runner.invoke(
        app,
        ["source", "add", "files", "--type", "filesystem", "--url", str(data_dir)],
    )
    assert add.exit_code == 0, add.stdout + add.stderr

    boot = cli_runner.invoke(app, ["contract", "bootstrap", "files"])
    assert boot.exit_code == 0, boot.stdout + boot.stderr

    contracts_dir = workspace / "contracts" / "files"
    written = sorted(p.name for p in contracts_dir.glob("*.odcs.yaml"))
    assert written == ["customers.odcs.yaml"]

    # The bootstrap already inferred types from the QVD header — just add
    # primaryKey + inject. (Other formats default to string and need
    # hand-edits to widen types; QVD doesn't.)
    (contracts_dir / "customers.odcs.yaml").write_text(
        "apiVersion: v3.0.0\n"
        "kind: DataContract\n"
        "id: files.customers\n"
        "name: customers\n"
        "version: 0.1.0\n"
        "status: draft\n"
        "info:\n  title: customers\n  owner: data-platform\n"
        "schema:\n"
        "  - name: customers\n"
        "    physicalName: customers\n"
        "    physicalType: table\n"
        "    properties:\n"
        "      - name: customer_id\n"
        "        logicalType: integer\n"
        "        primaryKey: true\n"
        "        required: true\n"
        "      - name: name\n"
        "        logicalType: string\n"
        "      - name: amount\n"
        "        logicalType: number\n"
        "      - name: source_file\n"
        "        logicalType: string\n"
        "customProperties:\n"
        "  - property: das.spec_ref\n"
        "    value:\n"
        "      kind: filesystem\n"
        "      format: qvd\n"
        "      path: 'customers.qvd'\n"
        "      inject:\n"
        "        source_file: basename\n"
    )

    ext = cli_runner.invoke(app, ["extract", "files"])
    assert ext.exit_code == 0, ext.stdout + ext.stderr

    load = cli_runner.invoke(app, ["load", "files"])
    assert load.exit_code == 0, load.stdout + load.stderr

    db = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        rows = db.execute(
            "SELECT customer_id, name, amount, source_file "
            'FROM "das__files".customers ORDER BY customer_id'
        ).fetchall()
    finally:
        db.close()

    assert rows == [
        (1, "Alice", 9.95, "customers.qvd"),
        (2, "Bob", 19.50, "customers.qvd"),
        (3, "Charlie", 99.00, "customers.qvd"),
    ]
