"""E2E: das against a local .xlsx workbook, landing into DuckDB. See ADR-0022.

Opt-in via `pytest -m e2e`. Builds the fixture workbook in tmp_path so no
binary file is committed. Pattern mirrors tests/e2e/sources/test_csv_to_duckdb.py.
"""

from __future__ import annotations

from pathlib import Path

import duckdb
import openpyxl
from typer.testing import CliRunner

from das_cli.cli import app


def _stage_workbook(data_dir: Path) -> None:
    wb = openpyxl.Workbook()
    wb.remove(wb.active)

    customers = wb.create_sheet("Customers")
    customers.append(["customer_id", "name", "signup_month"])
    customers.append([1, "Alice", "2024-01"])
    customers.append([2, "Bob", "2024-01"])
    customers.append([3, "Charlie", "2024-02"])

    orders = wb.create_sheet("Orders")
    orders.append(["order_id", "customer_id", "amount"])
    orders.append([10, 1, "99.50"])
    orders.append([11, 2, "150.00"])

    wb.save(data_dir / "Q1-2024.xlsx")


def test_xlsx_multi_sheet_to_duckdb_with_provenance(workspace: Path, cli_runner: CliRunner) -> None:
    """Multi-sheet workbook: each sheet becomes its own staging table."""

    data_dir = workspace / "data"
    data_dir.mkdir()
    _stage_workbook(data_dir)

    init = cli_runner.invoke(app, ["init"])
    assert init.exit_code == 0, init.stdout + init.stderr

    add = cli_runner.invoke(
        app,
        ["source", "add", "files", "--type", "filesystem", "--url", str(data_dir)],
    )
    assert add.exit_code == 0, add.stdout + add.stderr

    boot = cli_runner.invoke(app, ["contract", "bootstrap", "files"])
    assert boot.exit_code == 0, boot.stdout + boot.stderr

    contracts_dir = workspace / "contracts" / "files"
    written = sorted(p.name for p in contracts_dir.glob("*.odcs.yaml"))
    # snake_case preserves hyphens (only converts CamelCase boundaries), so
    # "Q1-2024" → "q1-2024" and "Customers" → "customers".
    assert written == [
        "q1-2024__customers.odcs.yaml",
        "q1-2024__orders.odcs.yaml",
    ]

    # Rename bootstrapped contracts to underscore form (a natural user action
    # since dlt normalises hyphens→underscores in both landing paths and
    # destination table names; the contract filename drives the resource_name
    # used in landing glob lookups).
    (contracts_dir / "q1-2024__customers.odcs.yaml").rename(
        contracts_dir / "q1_2024__customers.odcs.yaml"
    )
    (contracts_dir / "q1-2024__orders.odcs.yaml").rename(
        contracts_dir / "q1_2024__orders.odcs.yaml"
    )

    # Hand-edit the customers contract to set the primary key + inject sheet/file.
    (contracts_dir / "q1_2024__customers.odcs.yaml").write_text(
        "apiVersion: v3.0.0\n"
        "kind: DataContract\n"
        "id: files.q1_2024__customers\n"
        "name: q1_2024__customers\n"
        "version: 0.1.0\n"
        "status: draft\n"
        "info:\n  title: q1_2024__customers\n  owner: data-platform\n"
        "schema:\n"
        "  - name: q1_2024__customers\n"
        "    physicalName: q1_2024__customers\n"
        "    physicalType: table\n"
        "    properties:\n"
        "      - name: customer_id\n"
        "        logicalType: integer\n"
        "        primaryKey: true\n"
        "        required: true\n"
        "      - name: name\n"
        "        logicalType: string\n"
        "      - name: signup_month\n"
        "        logicalType: string\n"
        "      - name: source_file\n"
        "        logicalType: string\n"
        "      - name: source_sheet\n"
        "        logicalType: string\n"
        "customProperties:\n"
        "  - property: das.spec_ref\n"
        "    value:\n"
        "      kind: filesystem\n"
        "      format: excel\n"
        "      path: 'Q1-2024.xlsx'\n"
        "      sheet: 'Customers'\n"
        "      inject:\n"
        "        source_file: basename\n"
        "        source_sheet: sheet\n"
    )

    # Hand-edit the orders contract to set the primary key.
    (contracts_dir / "q1_2024__orders.odcs.yaml").write_text(
        "apiVersion: v3.0.0\n"
        "kind: DataContract\n"
        "id: files.q1_2024__orders\n"
        "name: q1_2024__orders\n"
        "version: 0.1.0\n"
        "status: draft\n"
        "info:\n  title: q1_2024__orders\n  owner: data-platform\n"
        "schema:\n"
        "  - name: q1_2024__orders\n"
        "    physicalName: q1_2024__orders\n"
        "    physicalType: table\n"
        "    properties:\n"
        "      - name: order_id\n"
        "        logicalType: integer\n"
        "        primaryKey: true\n"
        "        required: true\n"
        "      - name: customer_id\n"
        "        logicalType: integer\n"
        "      - name: amount\n"
        "        logicalType: string\n"
        "customProperties:\n"
        "  - property: das.spec_ref\n"
        "    value:\n"
        "      kind: filesystem\n"
        "      format: excel\n"
        "      path: 'Q1-2024.xlsx'\n"
        "      sheet: 'Orders'\n"
    )

    ext = cli_runner.invoke(app, ["extract", "files"])
    assert ext.exit_code == 0, ext.stdout + ext.stderr

    load = cli_runner.invoke(app, ["load", "files"])
    assert load.exit_code == 0, load.stdout + load.stderr

    db = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        cust = db.execute(
            "SELECT customer_id, name, signup_month, source_file, source_sheet "
            'FROM "das__files".q1_2024__customers ORDER BY customer_id'
        ).fetchall()
        ords = db.execute(
            'SELECT order_id, customer_id FROM "das__files".q1_2024__orders ' "ORDER BY order_id"
        ).fetchall()
    finally:
        db.close()

    assert cust == [
        (1, "Alice", "2024-01", "Q1-2024.xlsx", "Customers"),
        (2, "Bob", "2024-01", "Q1-2024.xlsx", "Customers"),
        (3, "Charlie", "2024-02", "Q1-2024.xlsx", "Customers"),
    ]
    assert ords == [(10, 1), (11, 2)]
