from pathlib import Path

import duckdb
from typer.testing import CliRunner

from das_cli.cli import app


def test_northwind_bootstrap_extract_load(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "northwind",
            "--type",
            "openapi",
            "--url",
            "https://demodata.grapecity.com/northwind/api/v1",
        ],
    )

    # Northwind exposes its swagger at a known location; override the swagger_url
    # in _source.yml to point at the JSON document.
    src = workspace / "contracts" / "northwind" / "_source.yml"
    text = src.read_text().replace(
        "swagger.json",
        "../../docs/NorthWind/v1/restful_swagger.json",
    )
    # Swagger lives at https://demodata.grapecity.com/docs/NorthWind/v1/restful_swagger.json
    text = text.replace(
        "https://demodata.grapecity.com/northwind/api/v1/../../docs/NorthWind/v1/restful_swagger.json",
        "https://demodata.grapecity.com/docs/NorthWind/v1/restful_swagger.json",
    )
    src.write_text(text)

    # Northwind's OpenAPI uses Dto-suffixed schema names (CustomerDto, OrderDto, …).
    # After snake_case + pluralize, CustomerDto → customer_dtos. The contract layer
    # is faithful to source-spec names; renaming to a friendlier `customers` would be
    # a contract-authoring step (edit the file + physicalName).
    bootstrap = cli_runner.invoke(
        app,
        [
            "contract",
            "bootstrap",
            "northwind",
            "--only",
            "customer_dtos",
        ],
    )
    assert bootstrap.exit_code == 0, bootstrap.stdout + bootstrap.stderr
    cust_contract = workspace / "contracts" / "northwind" / "customer_dtos.odcs.yaml"
    assert cust_contract.is_file()

    # OpenAPI bootstrap should walk paths and emit das.endpoint pointing at
    # /Customers (the actual REST path, not /customer_dtos). See ADR-0014/0015.
    import yaml as _yaml

    cust_data = _yaml.safe_load(cust_contract.read_text())
    cps = cust_data.get("customProperties") or []
    endpoint = next((p for p in cps if p["property"] == "das.endpoint"), None)
    assert endpoint is not None, (
        "bootstrap should have emitted das.endpoint for CustomerDto "
        "(unambiguous path-to-schema mapping in Northwind swagger)"
    )
    assert endpoint["value"]["path"] == "/Customers", endpoint["value"]["path"]

    extract = cli_runner.invoke(
        app,
        [
            "extract",
            "northwind",
            "--resource",
            "customer_dtos",
            "--limit",
            "5",
        ],
    )
    assert extract.exit_code == 0, extract.stdout + extract.stderr

    load = cli_runner.invoke(app, ["load", "northwind", "--resource", "customer_dtos"])
    assert load.exit_code == 0, load.stdout + load.stderr

    db = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        row = db.execute('SELECT COUNT(*) FROM "das__northwind".customer_dtos').fetchone()
        count = row[0] if row is not None else 0
        keyed_row = db.execute(
            'SELECT COUNT(*) FROM "das__northwind".customer_dtos ' "WHERE customer_id IS NOT NULL"
        ).fetchone()
        keyed = keyed_row[0] if keyed_row is not None else 0
    finally:
        db.close()
    assert 1 <= count <= 5, f"row count {count} outside (0, --limit=5]"
    assert keyed >= 1, "expected at least one customer_dto with a non-null customer_id"

    db = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        nulls = db.execute(
            'SELECT COUNT(*) FROM "das__northwind".customer_dtos '
            "WHERE _extracted_at IS NULL OR _extracted_on IS NULL "
            "OR _loaded_at IS NULL OR _loaded_on IS NULL"
        ).fetchone()
        assert (nulls[0] if nulls else 0) == 0, "metadata columns must be NOT NULL"
    finally:
        db.close()
