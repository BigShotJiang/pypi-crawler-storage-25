"""E2E: das against a local CSV folder, landing into DuckDB. See ADR-0022.

Opt-in via `pytest -m e2e`. Reads fixtures from tests/e2e/fixtures/csv/.

Uses the shared `workspace` + `cli_runner` fixtures from tests/conftest.py.
`workspace` is a tmp_path with cwd switched, DAS_TARGET_DB and DAS_LANDING_URL
env vars set. The pattern mirrors tests/e2e/sources/test_oracle.py.
"""

from __future__ import annotations

import shutil
from pathlib import Path

import duckdb
from typer.testing import CliRunner

from das_cli.cli import app

FIXTURE_DIR = Path(__file__).parent.parent / "fixtures" / "csv"


def test_csv_glob_to_duckdb_with_provenance(workspace: Path, cli_runner: CliRunner) -> None:
    """Glob across monthly partitioned CSV files; assert combined row count + provenance."""

    # Stage the fixture CSVs in a data directory inside the workspace.
    data_dir = workspace / "data"
    data_dir.mkdir()
    shutil.copy(FIXTURE_DIR / "customers_2024-01.csv", data_dir)
    shutil.copy(FIXTURE_DIR / "customers_2024-02.csv", data_dir)

    # 1. init — writes das.yaml in cwd (the workspace fixture has chdir'd here).
    init = cli_runner.invoke(app, ["init"])
    assert init.exit_code == 0, init.stdout + init.stderr

    # 2. source add
    add = cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "files",
            "--type",
            "filesystem",
            "--url",
            str(data_dir),
        ],
    )
    assert add.exit_code == 0, add.stdout + add.stderr

    # 3. contract bootstrap — writes one contract per CSV.
    # snake_case("customers_2024-01") yields "customers_2024-01" (hyphens are
    # preserved by the naming helper; it only converts CamelCase boundaries).
    boot = cli_runner.invoke(app, ["contract", "bootstrap", "files"])
    assert boot.exit_code == 0, boot.stdout + boot.stderr

    contracts_dir = workspace / "contracts" / "files"
    written = sorted(p.name for p in contracts_dir.glob("*.odcs.yaml"))
    assert written == [
        "customers_2024-01.odcs.yaml",
        "customers_2024-02.odcs.yaml",
    ]

    # 4. Merge the two contracts into a single "customers" resource with a glob,
    #    a primary key, and an inject column for provenance. This is what a
    #    user does post-bootstrap.
    (contracts_dir / "customers_2024-01.odcs.yaml").unlink()
    (contracts_dir / "customers_2024-02.odcs.yaml").unlink()

    (contracts_dir / "customers.odcs.yaml").write_text(
        "apiVersion: v3.0.0\n"
        "kind: DataContract\n"
        "id: files.customers\n"
        "name: customers\n"
        "version: 0.1.0\n"
        "status: draft\n"
        "info:\n  title: customers\n  owner: data-platform\n"
        "schema:\n"
        "  - name: customers\n"
        "    physicalName: customers\n"
        "    physicalType: table\n"
        "    properties:\n"
        "      - name: customer_id\n"
        "        logicalType: integer\n"
        "        primaryKey: true\n"
        "        required: true\n"
        "      - name: name\n"
        "        logicalType: string\n"
        "      - name: signup_month\n"
        "        logicalType: string\n"
        "      - name: source_file\n"
        "        logicalType: string\n"
        "customProperties:\n"
        "  - property: das.spec_ref\n"
        "    value:\n"
        "      kind: filesystem\n"
        "      format: csv\n"
        "      path: 'customers_*.csv'\n"
        "      inject:\n"
        "        source_file: basename\n"
    )

    # 5. extract + load (the Oracle test uses the same two-step flow).
    ext = cli_runner.invoke(app, ["extract", "files"])
    assert ext.exit_code == 0, ext.stdout + ext.stderr

    load = cli_runner.invoke(app, ["load", "files"])
    assert load.exit_code == 0, load.stdout + load.stderr

    # 6. Assert rows in DuckDB. The `workspace` fixture sets DAS_TARGET_DB to
    #    workspace / "test.duckdb"; das.yaml's default template uses that env
    #    var, so the DB lands there. Tables are namespaced under das__<source>.
    db = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        rows = db.execute(
            'SELECT customer_id, name, source_file FROM "das__files".customers '
            "ORDER BY customer_id"
        ).fetchall()
    finally:
        db.close()

    assert rows == [
        (1, "Alice", "customers_2024-01.csv"),
        (2, "Bob", "customers_2024-01.csv"),
        (3, "Charlie", "customers_2024-01.csv"),
        (4, "Diana", "customers_2024-02.csv"),
        (5, "Eve", "customers_2024-02.csv"),
    ]
