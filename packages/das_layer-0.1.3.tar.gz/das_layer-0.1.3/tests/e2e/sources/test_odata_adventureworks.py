from pathlib import Path

import duckdb
from typer.testing import CliRunner

from das_cli.cli import app


def test_adventureworks_bootstrap_extract_load(workspace: Path, cli_runner: CliRunner) -> None:
    cli_runner.invoke(app, ["init"])
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "adventureworks",
            "--type",
            "odata",
            "--url",
            "https://demodata.grapecity.com/adventureworks/odata/v1",
        ],
    )

    bootstrap = cli_runner.invoke(
        app,
        [
            "contract",
            "bootstrap",
            "adventureworks",
            "--only",
            "products",
        ],
    )
    assert bootstrap.exit_code == 0, bootstrap.stdout + bootstrap.stderr
    products_contract = workspace / "contracts" / "adventureworks" / "products.odcs.yaml"
    assert products_contract.is_file()

    extract = cli_runner.invoke(
        app,
        [
            "extract",
            "adventureworks",
            "--resource",
            "products",
            "--limit",
            "10",
        ],
    )
    assert extract.exit_code == 0, extract.stdout + extract.stderr

    landing = workspace / "landing" / "adventureworks" / "products"
    assert any(landing.rglob("*.jsonl*"))

    load = cli_runner.invoke(app, ["load", "adventureworks", "--resource", "products"])
    assert load.exit_code == 0, load.stdout + load.stderr

    db = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        row = db.execute('SELECT COUNT(*) FROM "das__adventureworks".products').fetchone()
        count = row[0] if row is not None else 0
        named_row = db.execute(
            'SELECT COUNT(*) FROM "das__adventureworks".products WHERE name IS NOT NULL'
        ).fetchone()
        named = named_row[0] if named_row is not None else 0
    finally:
        db.close()
    assert 1 <= count <= 10, f"row count {count} outside (0, --limit=10]"
    assert named >= 1, "expected at least one product with a non-null name"

    db = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        nulls = db.execute(
            'SELECT COUNT(*) FROM "das__adventureworks".products '
            "WHERE _extracted_at IS NULL OR _extracted_on IS NULL "
            "OR _loaded_at IS NULL OR _loaded_on IS NULL"
        ).fetchone()
        assert (nulls[0] if nulls else 0) == 0, "metadata columns must be NOT NULL"
    finally:
        db.close()


def test_adventureworks_irregular_plural_addresses(workspace: Path, cli_runner: CliRunner) -> None:
    """Regression: issue #61 — Address → /Addresses (not /Addresss).

    Bootstraps the addresses resource against the live AdventureWorks OData
    feed and extracts a small page. If this fails with a 404, the EntitySet
    name was not captured from $metadata OR the heuristic regressed.
    """
    cli_runner.invoke(app, ["init"])
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "adventureworks",
            "--type",
            "odata",
            "--url",
            "https://demodata.grapecity.com/adventureworks/odata/v1",
        ],
    )

    bootstrap = cli_runner.invoke(
        app,
        [
            "contract",
            "bootstrap",
            "adventureworks",
            "--only",
            "address",
        ],
    )
    assert bootstrap.exit_code == 0, bootstrap.stdout + bootstrap.stderr

    extract = cli_runner.invoke(
        app,
        [
            "extract",
            "adventureworks",
            "--resource",
            "address",
            "--limit",
            "5",
        ],
    )
    assert extract.exit_code == 0, extract.stdout + extract.stderr

    landing = workspace / "landing" / "adventureworks" / "address"
    assert any(landing.rglob("*.jsonl*")), "no JSONL files landed; extract path resolution failed"

    load = cli_runner.invoke(app, ["load", "adventureworks", "--resource", "address"])
    assert load.exit_code == 0, load.stdout + load.stderr

    db = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        row = db.execute('SELECT COUNT(*) FROM "das__adventureworks".address').fetchone()
        count = row[0] if row is not None else 0
    finally:
        db.close()
    assert 1 <= count <= 5, f"row count {count} outside (0, --limit=5]"


def test_adventureworks_bootstrap_count_matches_entity_container(
    workspace: Path, cli_runner: CliRunner
) -> None:
    """Regression: issue #63 — bootstrap emitted 66 contracts against an
    EntityContainer that declares 59 EntitySets, and the 7 extras 404 at
    extract time.

    Bootstraps the full source (no --only), then independently fetches
    $metadata and counts <EntitySet> elements inside <EntityContainer>.
    Asserts the on-disk contract count equals the EntitySet count.
    """
    from xml.etree import ElementTree

    import requests

    cli_runner.invoke(app, ["init"])
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "adventureworks",
            "--type",
            "odata",
            "--url",
            "https://demodata.grapecity.com/adventureworks/odata/v1",
        ],
    )

    bootstrap = cli_runner.invoke(
        app,
        ["contract", "bootstrap", "adventureworks"],
    )
    assert bootstrap.exit_code == 0, bootstrap.stdout + bootstrap.stderr

    metadata_url = "https://demodata.grapecity.com/adventureworks/odata/v1/$metadata"
    resp = requests.get(metadata_url, timeout=30)
    resp.raise_for_status()
    root = ElementTree.fromstring(resp.text)
    ns = {"edm": "http://docs.oasis-open.org/odata/ns/edm"}
    expected_count = sum(
        len(container.findall("edm:EntitySet", ns))
        for container in root.iter("{http://docs.oasis-open.org/odata/ns/edm}EntityContainer")
    )
    assert expected_count > 0, "AdventureWorks $metadata returned no EntitySets"

    contracts_dir = workspace / "contracts" / "adventureworks"
    actual_count = len(list(contracts_dir.glob("*.odcs.yaml")))
    assert actual_count == expected_count, (
        f"bootstrap wrote {actual_count} contracts but AdventureWorks "
        f"<EntityContainer> declares {expected_count} EntitySets"
    )
