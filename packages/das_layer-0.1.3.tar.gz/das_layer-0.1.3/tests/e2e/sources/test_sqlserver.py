"""E2E: das against a SQL Server 2022 container. See ADR-0018.

Opt-in via `pytest -m e2e`. Requires Docker + msodbcsql18.
"""

from __future__ import annotations

import base64
import os
from collections.abc import Iterator
from pathlib import Path

import duckdb
import pytest
from typer.testing import CliRunner

from das_cli.cli import app


def _split_sql_statements(sql: str) -> list[str]:
    """Split a SQL script into executable statements, stripping `--` line comments.

    Each statement (delimited by `;`) is stripped of full-line `--` comments,
    then trimmed. Empty statements and bare `COMMIT` keywords are skipped — the
    SQLAlchemy connection auto-commits at exit of `engine.begin()`.
    """
    out: list[str] = []
    for chunk in sql.split(";"):
        body_lines = [line for line in chunk.splitlines() if not line.strip().startswith("--")]
        body = "\n".join(body_lines).strip()
        if not body or body.upper() == "COMMIT":
            continue
        out.append(body)
    return out


def _scope_to_seed_tables(workspace: Path, source_name: str) -> None:
    """Pin `_source.yml` to the seed tables only.

    Without scoping, bootstrap reflects every table in `dbo` — including the
    handful of system tables SQL Server keeps there. Pinning keeps the test
    deterministic. SQL Server preserves the case from CREATE TABLE in the
    catalog, so the filter is lower-case.
    """
    src_yml = workspace / "contracts" / source_name / "_source.yml"
    text = src_yml.read_text()
    text = text.replace(
        "spec:\n  kind: sql\n",
        "spec:\n  kind: sql\n" "  tables:\n    - customers\n    - orders\n    - attachments\n",
    )
    src_yml.write_text(text)


@pytest.fixture(scope="module")
def mssql_url() -> Iterator[str]:
    """Spin SQL Server 2022, run the seed, yield a mssql+pyodbc SQLAlchemy URL."""
    pytest.importorskip("testcontainers.mssql")
    try:
        import pyodbc  # noqa: F401
    except ImportError:
        pytest.skip(
            "pyodbc + Microsoft ODBC Driver 18 not installed; see "
            "https://learn.microsoft.com/en-us/sql/connect/odbc/linux-mac/installing-the-microsoft-odbc-driver-for-sql-server"
        )

    from testcontainers.mssql import SqlServerContainer

    seed_sql = (Path(__file__).parent.parent / "fixtures" / "sql_seed_sqlserver.sql").read_text()

    container = SqlServerContainer()
    container.start()
    try:
        host = container.get_container_host_ip()
        port = container.get_exposed_port(1433)
        user = container.SQLSERVER_USER if hasattr(container, "SQLSERVER_USER") else "sa"
        password = (
            container.password if hasattr(container, "password") else container.SQLSERVER_PASSWORD
        )
        url = (
            f"mssql+pyodbc://{user}:{password}@{host}:{port}/master"
            f"?driver=ODBC+Driver+18+for+SQL+Server&Encrypt=no&TrustServerCertificate=yes"
        )

        from sqlalchemy import create_engine, text

        engine = create_engine(url)
        with engine.begin() as conn:
            for stmt in _split_sql_statements(seed_sql):
                conn.execute(text(stmt))
        engine.dispose()
        yield url
    finally:
        container.stop()


def test_sqlserver_bootstrap_extract_load(
    workspace: Path, cli_runner: CliRunner, mssql_url: str
) -> None:
    from sqlalchemy.engine.url import URL, make_url

    parsed = make_url(mssql_url)
    user = parsed.username or ""
    password = parsed.password or ""
    # SQLAlchemy URL.set(username=None, ...) leaves the existing values in place;
    # rebuild explicitly without userinfo to satisfy `das source add --type sql`,
    # which rejects URLs containing credentials.
    clean_url = URL.create(
        drivername=parsed.drivername,
        host=parsed.host,
        port=parsed.port,
        database=parsed.database,
        query=parsed.query,
    ).render_as_string(hide_password=False)

    cli_runner.invoke(app, ["init"])
    add = cli_runner.invoke(app, ["source", "add", "demo", "--type", "sql", "--url", clean_url])
    assert add.exit_code == 0, add.stdout + add.stderr

    _scope_to_seed_tables(workspace, "demo")

    os.environ["DEMO__USERNAME"] = user
    os.environ["DEMO__PASSWORD"] = password
    try:
        boot = cli_runner.invoke(app, ["contract", "bootstrap", "demo"])
        assert boot.exit_code == 0, boot.stdout + boot.stderr

        ext = cli_runner.invoke(app, ["extract", "demo"])
        assert ext.exit_code == 0, ext.stdout + ext.stderr

        load = cli_runner.invoke(app, ["load", "demo"])
        assert load.exit_code == 0, load.stdout + load.stderr
    finally:
        os.environ.pop("DEMO__USERNAME", None)
        os.environ.pop("DEMO__PASSWORD", None)

    db = duckdb.connect(str(workspace / "test.duckdb"), read_only=True)
    try:
        rows = db.execute('SELECT COUNT(*) FROM "das__demo".customers').fetchone()
        assert rows is not None and rows[0] == 3

        order_rows = db.execute('SELECT COUNT(*) FROM "das__demo".orders').fetchone()
        assert order_rows is not None and order_rows[0] == 3

        att = db.execute(
            'SELECT payload FROM "das__demo".attachments WHERE attachment_id = 1'
        ).fetchone()
        assert att is not None
        assert base64.b64decode(att[0]) == b"hello"

        named = db.execute(
            'SELECT COUNT(*) FROM "das__demo".customers WHERE name IS NOT NULL'
        ).fetchone()
        assert named is not None and named[0] == 3, named
    finally:
        db.close()
