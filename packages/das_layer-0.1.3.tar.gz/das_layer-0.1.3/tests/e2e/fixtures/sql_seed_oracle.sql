-- Seed schema for the Oracle e2e test. See ADR-0018.
-- Owner is the connection user (gvenzl image's APPUSER).

CREATE TABLE customers (
  customer_id   NUMBER(10) PRIMARY KEY,
  name          VARCHAR2(100) NOT NULL,
  created_at    TIMESTAMP NOT NULL,
  updated_at    TIMESTAMP NOT NULL
);

CREATE TABLE orders (
  order_id      NUMBER(10),
  line_no       NUMBER(5),
  customer_id   NUMBER(10) NOT NULL,
  amount        NUMBER(12,2) NOT NULL,
  PRIMARY KEY (order_id, line_no)
);

CREATE TABLE attachments (
  attachment_id NUMBER(10) PRIMARY KEY,
  payload       BLOB
);

INSERT INTO customers (customer_id, name, created_at, updated_at)
VALUES (1, 'Ada Lovelace', TIMESTAMP '2026-04-01 10:00:00', TIMESTAMP '2026-05-01 10:00:00');
INSERT INTO customers (customer_id, name, created_at, updated_at)
VALUES (2, 'Linus Torvalds', TIMESTAMP '2026-04-02 10:00:00', TIMESTAMP '2026-05-02 10:00:00');
INSERT INTO customers (customer_id, name, created_at, updated_at)
VALUES (3, 'Grace Hopper', TIMESTAMP '2026-04-03 10:00:00', TIMESTAMP '2026-05-03 10:00:00');

INSERT INTO orders (order_id, line_no, customer_id, amount) VALUES (100, 1, 1, 19.99);
INSERT INTO orders (order_id, line_no, customer_id, amount) VALUES (100, 2, 1, 29.50);
INSERT INTO orders (order_id, line_no, customer_id, amount) VALUES (101, 1, 2, 9.00);

INSERT INTO attachments (attachment_id, payload)
VALUES (1, UTL_RAW.CAST_TO_RAW('hello'));

COMMIT;
