-- Seed schema for the SQL Server e2e test. See ADR-0018.
-- Runs against the dbo schema in the default database (master).

CREATE TABLE customers (
  customer_id   BIGINT NOT NULL PRIMARY KEY,
  name          NVARCHAR(100) NOT NULL,
  created_at    DATETIME2 NOT NULL,
  updated_at    DATETIME2 NOT NULL
);

CREATE TABLE orders (
  order_id      BIGINT NOT NULL,
  line_no       BIGINT NOT NULL,
  customer_id   BIGINT NOT NULL,
  amount        DECIMAL(12,2) NOT NULL,
  CONSTRAINT pk_orders PRIMARY KEY (order_id, line_no)
);

CREATE TABLE attachments (
  attachment_id BIGINT NOT NULL PRIMARY KEY,
  payload       VARBINARY(MAX) NULL
);

INSERT INTO customers (customer_id, name, created_at, updated_at) VALUES
  (1, 'Ada Lovelace',  '2026-04-01T10:00:00', '2026-05-01T10:00:00'),
  (2, 'Linus Torvalds','2026-04-02T10:00:00', '2026-05-02T10:00:00'),
  (3, 'Grace Hopper',  '2026-04-03T10:00:00', '2026-05-03T10:00:00');

INSERT INTO orders (order_id, line_no, customer_id, amount) VALUES
  (100, 1, 1, 19.99),
  (100, 2, 1, 29.50),
  (101, 1, 2,  9.00);

INSERT INTO attachments (attachment_id, payload) VALUES (1, CONVERT(VARBINARY(MAX), 'hello'));
