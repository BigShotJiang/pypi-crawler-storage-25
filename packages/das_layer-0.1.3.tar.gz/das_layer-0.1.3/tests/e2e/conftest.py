"""e2e fixtures: skip these tests by default; opt in via -m e2e.

Loads .env at repo root once per session (gated on the file existing) so
opt-in cloud edge tests (e.g. the Azure Delta edge) can read their
gating variables without the developer having to source .env manually.
The conftest never reads or logs the env-var values."""

from __future__ import annotations

import os
from pathlib import Path

import pytest


def _load_repo_dotenv_if_present() -> None:
    env_path = Path(__file__).resolve().parents[2] / ".env"
    if not env_path.is_file():
        return
    try:
        from dotenv import load_dotenv
    except ModuleNotFoundError:
        return
    # override=False so values already in the shell win.
    load_dotenv(env_path, override=False)


_load_repo_dotenv_if_present()


def pytest_collection_modifyitems(config: pytest.Config, items: list[pytest.Item]) -> None:
    """Inject the e2e marker into all tests under tests/e2e/."""
    for item in items:
        if "tests/e2e/" in str(item.fspath) or "tests\\e2e\\" in str(item.fspath):
            item.add_marker(pytest.mark.e2e)


def require_azure_e2e() -> None:
    """Skip the calling test unless Azure e2e gating is set up.

    Required variables:
      DAS_E2E_AZURE_BUCKET_URL   base ABFS URL for the test workspace
      AZURE_TENANT_ID            (service-principal variant)
      AZURE_CLIENT_ID            (service-principal variant)
      AZURE_CLIENT_SECRET        (service-principal variant)

    All values stay opaque — never logged or echoed."""
    required = (
        "DAS_E2E_AZURE_BUCKET_URL",
        "AZURE_TENANT_ID",
        "AZURE_CLIENT_ID",
        "AZURE_CLIENT_SECRET",
    )
    missing = [name for name in required if not os.environ.get(name)]
    if missing:
        pytest.skip(f"Azure e2e gate missing env: {', '.join(missing)}")
