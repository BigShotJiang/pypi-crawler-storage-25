"""End-to-end edge: AdventureWorks → Azure landing → Delta on Azure.

Opt-in. Gated by DAS_E2E_AZURE_BUCKET_URL + the three AZURE_* SP env
vars. Run with: uv run pytest tests/e2e/destinations/test_delta_azure.py -m e2e -v

See ADR-0020.

Per-run isolation is achieved by suffixing the source name with a UTC
timestamp (dlt's `dev_mode` convention), e.g. `adventureworks__20260512143246`.
This puts the per-run variation at the dataset level — so paths land at
`<base>/Tables/das__adventureworks__<ts>/<resource>/...` and Fabric's
auto-discovery treats them as managed Delta tables. The base bucket URL
points at `<workspace>@onelake.../<lakehouse>` with no intermediate
run-hash directories cluttering the layout."""

from __future__ import annotations

import os
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import dlt
import pytest
from typer.testing import CliRunner

from das_cli.cli import app
from das_cli.dlt_glue.azure_credentials import open_sql_client
from tests.e2e.conftest import require_azure_e2e


def _azure_workspace(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    *,
    auth_block: str,
) -> tuple[Path, str, str]:
    """Write a das.yaml pointing at Azure landing + Delta target.

    Returns (workspace_path, landing_url, target_bucket_url). Both URLs
    point at the lakehouse root — no per-run hash subdirectory. Per-run
    uniqueness lives in the source name (and therefore the dataset name)."""
    base = os.environ["DAS_E2E_AZURE_BUCKET_URL"].rstrip("/")
    landing_url = f"{base}/Files/landing"
    target_url = f"{base}/Tables"

    monkeypatch.chdir(tmp_path)
    (tmp_path / "das.yaml").write_text(
        f"""\
target:
  destination: delta
  credentials:
    bucket_url: "{target_url}"
{auth_block}
landing:
  bucket_url: "{landing_url}"
  credentials:
{auth_block}
contracts:
  root: ./contracts
dataset:
  prefix: das
defaults:
  write_disposition: append
  change_detection: row_hash
  schema_contract:
    tables: evolve
    columns: freeze
    data_type: freeze
"""
    )
    return tmp_path, landing_url, target_url


def _service_principal_block() -> str:
    return """\
    auth: service_principal
    tenant_id: "{{ env_var('AZURE_TENANT_ID') }}"
    client_id: "{{ env_var('AZURE_CLIENT_ID') }}"
    client_secret: "{{ env_var('AZURE_CLIENT_SECRET') }}"
"""


def _default_auth_block() -> str:
    return """\
    auth: default
"""


def _azure_reader_pipeline(workspace: Path, target_url: str, dataset: str) -> dlt.Pipeline:
    """Reader pipeline for Delta tables on Azure. Shares the writer's
    pipeline_name / pipelines_dir per ADR-0017 Decision C.

    dataset_name must be passed explicitly: with timestamp-suffixed dataset
    names, dlt's filesystem sql_client does not auto-resolve which dataset
    to scope to."""
    from das_cli.config import load_das_config
    from das_cli.dlt_glue.azure_credentials import build_adlfs_kwargs, build_dlt_azure_credentials
    from das_cli.models.das_yaml import parse_azure_credentials

    cfg = load_das_config(workspace / "das.yaml")
    azure = parse_azure_credentials(cfg.target.credentials, target_url)
    creds = build_dlt_azure_credentials(azure, bucket_url=target_url) if azure else None
    adlfs_kwargs = build_adlfs_kwargs(azure, target_url)

    fs_kwargs: dict[str, Any] = {
        "bucket_url": target_url,
        "credentials": creds,
        "enable_dataset_name_normalization": False,
    }
    if adlfs_kwargs:
        fs_kwargs["kwargs"] = adlfs_kwargs

    return dlt.pipeline(
        pipeline_name="das_load",
        dataset_name=dataset,
        destination=dlt.destinations.filesystem(**fs_kwargs),
        pipelines_dir=str(workspace / ".dlt" / "pipelines"),
    )


def _teardown_run(
    landing_url: str, target_url: str, dataset: str, source: str, auth_block: str
) -> None:
    """Best-effort cleanup of the per-run dataset/source subtrees.

    Deletes <landing>/<source>/ and <target>/<dataset>/ only — leaves
    sibling datasets intact (which matters when the test base URL is a
    shared lakehouse)."""
    import fsspec

    from das_cli.dlt_glue.azure_credentials import _adlfs_storage_options
    from das_cli.models.das_yaml import parse_azure_credentials

    creds_dict: dict[str, str] = (
        {
            "auth": "service_principal",
            "tenant_id": os.environ["AZURE_TENANT_ID"],
            "client_id": os.environ["AZURE_CLIENT_ID"],
            "client_secret": os.environ["AZURE_CLIENT_SECRET"],
        }
        if "service_principal" in auth_block
        else {"auth": "default"}
    )
    azure = parse_azure_credentials(creds_dict, landing_url)
    opts = _adlfs_storage_options(azure, bucket_url=landing_url)
    for url, leaf in ((landing_url, source), (target_url, dataset)):
        target = f"{url.rstrip('/')}/{leaf}"
        try:
            fs, root = fsspec.core.url_to_fs(target, **opts)
            if fs.exists(root):
                fs.rm(root, recursive=True)
        except Exception:  # teardown is best-effort
            pass


@pytest.fixture(params=["service_principal", "default"])
def azure_auth_block(request: pytest.FixtureRequest) -> str:
    if request.param == "service_principal":
        return _service_principal_block()
    return _default_auth_block()


def test_adventureworks_extract_load_azure(
    azure_auth_block: str,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    cli_runner: CliRunner,
) -> None:
    require_azure_e2e()

    # dlt's `dev_mode` convention: append a UTC timestamp to make this run's
    # dataset unique. Result: <base>/Tables/das__adventureworks__<ts>/products/
    ts = datetime.now(UTC).strftime("%Y%m%d%H%M%S")
    source = f"adventureworks__{ts}"
    dataset = f"das__{source}"

    workspace, landing_url, target_url = _azure_workspace(
        tmp_path, monkeypatch, auth_block=azure_auth_block
    )

    try:
        # source add
        result = cli_runner.invoke(
            app,
            [
                "source",
                "add",
                source,
                "--type",
                "odata",
                "--url",
                "https://demodata.grapecity.com/adventureworks/odata/v1",
            ],
        )
        assert result.exit_code == 0, result.stdout + result.stderr

        # bootstrap one resource
        result = cli_runner.invoke(
            app,
            ["contract", "bootstrap", source, "--only", "products"],
        )
        assert result.exit_code == 0, result.stdout + result.stderr
        assert (workspace / "contracts" / source / "products.odcs.yaml").is_file()

        # extract → Azure landing
        result = cli_runner.invoke(
            app, ["extract", source, "--resource", "products", "--limit", "10"]
        )
        assert result.exit_code == 0, result.stdout + result.stderr

        # load → Delta on Azure
        result = cli_runner.invoke(app, ["load", source, "--resource", "products"])
        assert result.exit_code == 0, result.stdout + result.stderr

        # Read back via the reader pipeline.
        reader = _azure_reader_pipeline(workspace, target_url, dataset)
        # Resolve azure creds the same way the reader pipeline does.
        from das_cli.config import load_das_config
        from das_cli.models.das_yaml import parse_azure_credentials

        cfg = load_das_config(workspace / "das.yaml")
        azure = parse_azure_credentials(cfg.target.credentials, target_url)

        with open_sql_client(reader, bucket_url=target_url, azure=azure) as c:
            rows = c.execute_sql(f'SELECT COUNT(*) FROM "{dataset}".products')
            assert rows is not None
            count = rows[0][0]
            assert 1 <= count <= 10, f"row count {count} outside (0, --limit=10]"

            named_rows = c.execute_sql(
                f'SELECT COUNT(*) FROM "{dataset}".products WHERE name IS NOT NULL'
            )
            assert named_rows is not None and named_rows[0][0] >= 1

            stamp_rows = c.execute_sql(
                f'SELECT COUNT(*) FROM "{dataset}".products '
                "WHERE _extracted_at IS NULL OR _extracted_on IS NULL "
                "OR _loaded_at IS NULL OR _loaded_on IS NULL"
            )
            assert stamp_rows is not None and stamp_rows[0][0] == 0

        # Second-cycle: change detection should produce zero new rows.
        result = cli_runner.invoke(app, ["load", source, "--resource", "products"])
        assert result.exit_code == 0, result.stdout + result.stderr
        reader = _azure_reader_pipeline(workspace, target_url, dataset)
        with open_sql_client(reader, bucket_url=target_url, azure=azure) as c:
            rows = c.execute_sql(f'SELECT COUNT(*) FROM "{dataset}".products')
            assert (
                rows is not None and rows[0][0] == count
            ), "change detection should append zero rows"
    finally:
        _teardown_run(landing_url, target_url, dataset, source, azure_auth_block)
