from pathlib import Path

from typer.testing import CliRunner

from das_cli.cli import app
from tests.conftest import delta_reader_pipeline


def test_delta_bootstrap_extract_load(delta_workspace: Path, cli_runner: CliRunner) -> None:
    # Note: NO `cli_runner.invoke(app, ["init"])` — delta_workspace already
    # writes a custom das.yaml. `init` would overwrite it without --force.
    cli_runner.invoke(
        app,
        [
            "source",
            "add",
            "adventureworks",
            "--type",
            "odata",
            "--url",
            "https://demodata.grapecity.com/adventureworks/odata/v1",
        ],
    )

    bootstrap = cli_runner.invoke(
        app,
        ["contract", "bootstrap", "adventureworks", "--only", "products"],
    )
    assert bootstrap.exit_code == 0, bootstrap.stdout + bootstrap.stderr
    products_contract = delta_workspace / "contracts" / "adventureworks" / "products.odcs.yaml"
    assert products_contract.is_file()

    extract = cli_runner.invoke(
        app,
        ["extract", "adventureworks", "--resource", "products", "--limit", "10"],
    )
    assert extract.exit_code == 0, extract.stdout + extract.stderr

    landing = delta_workspace / "landing" / "adventureworks" / "products"
    assert any(landing.rglob("*.jsonl*"))

    load = cli_runner.invoke(app, ["load", "adventureworks", "--resource", "products"])
    assert load.exit_code == 0, load.stdout + load.stderr

    pipeline = delta_reader_pipeline(delta_workspace)
    with pipeline.sql_client() as c:
        rows = c.execute_sql('SELECT COUNT(*) FROM "das__adventureworks".products')
        assert rows is not None
        count = rows[0][0]
        named_rows = c.execute_sql(
            'SELECT COUNT(*) FROM "das__adventureworks".products WHERE name IS NOT NULL'
        )
        assert named_rows is not None
        named = named_rows[0][0]
        assert 1 <= count <= 10, f"row count {count} outside (0, --limit=10]"
        assert named >= 1, "expected at least one product with a non-null name"
        rows = c.execute_sql(
            'SELECT COUNT(*) FROM "das__adventureworks".products '
            "WHERE _extracted_at IS NULL OR _extracted_on IS NULL "
            "OR _loaded_at IS NULL OR _loaded_on IS NULL"
        )
        assert rows is not None
        nulls = rows[0][0]
        assert nulls == 0, "metadata columns must be NOT NULL"
