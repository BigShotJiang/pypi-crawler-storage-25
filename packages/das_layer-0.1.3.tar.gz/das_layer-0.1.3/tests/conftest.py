"""Shared pytest fixtures."""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path
from typing import TYPE_CHECKING

import pytest
from typer.testing import CliRunner

if TYPE_CHECKING:
    import dlt


@pytest.fixture()
def cli_runner() -> CliRunner:
    """Typer's testing runner; invokes `das` commands in-process."""
    return CliRunner()


@pytest.fixture()
def workspace(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[Path]:
    """A real DAS workspace in a tmp dir, env vars set, cwd switched."""
    target = tmp_path / "test.duckdb"
    landing = tmp_path / "landing"
    monkeypatch.setenv("DAS_TARGET_DB", str(target))
    monkeypatch.setenv("DAS_LANDING_URL", str(landing))
    monkeypatch.chdir(tmp_path)
    yield tmp_path


@pytest.fixture()
def ducklake_workspace(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[Path]:
    """A das workspace targeting a local DuckLake. Same shape as `workspace`."""
    catalog = tmp_path / "test.ducklake"
    storage = tmp_path / "ducklake_data"
    landing = tmp_path / "landing"
    storage.mkdir()
    monkeypatch.setenv("DAS_LANDING_URL", str(landing))
    monkeypatch.chdir(tmp_path)
    (tmp_path / "das.yaml").write_text(
        f"""\
target:
  destination: ducklake
  credentials:
    catalog: {catalog}
    storage: {storage}

landing:
  bucket_url: "{{{{ env_var('DAS_LANDING_URL', './landing') }}}}"
  credentials: {{}}

contracts:
  root: ./contracts

dataset:
  prefix: das

defaults:
  write_disposition: append
  change_detection: row_hash
  schema_contract:
    tables: evolve
    columns: freeze
    data_type: freeze
"""
    )
    yield tmp_path


@pytest.fixture()
def delta_workspace(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[Path]:
    """A das workspace targeting a local Delta destination. Same shape as `workspace`."""
    bucket_url = tmp_path / "das_delta"
    landing = tmp_path / "landing"
    monkeypatch.setenv("DAS_LANDING_URL", str(landing))
    monkeypatch.chdir(tmp_path)
    (tmp_path / "das.yaml").write_text(
        f"""\
target:
  destination: delta
  credentials:
    bucket_url: {bucket_url}

landing:
  bucket_url: "{{{{ env_var('DAS_LANDING_URL', './landing') }}}}"
  credentials: {{}}

contracts:
  root: ./contracts

dataset:
  prefix: das

defaults:
  write_disposition: append
  change_detection: row_hash
  schema_contract:
    tables: evolve
    columns: freeze
    data_type: freeze
"""
    )
    yield tmp_path


def ducklake_reader_pipeline(
    workspace: Path,
    *,
    pipeline_name: str = "das_load_read",
) -> dlt.Pipeline:
    """A reader dlt pipeline pointed at the workspace's DuckLake.

    Used by integration and e2e tests to query loaded data via `sql_client()`.
    The default pipeline_name is distinct from the writer's `das_load` so the
    reader doesn't collide with writer state.
    """
    import dlt

    return dlt.pipeline(
        pipeline_name=pipeline_name,
        destination=dlt.destinations.ducklake(
            credentials={  # type: ignore[arg-type]
                "catalog": f"duckdb:///{workspace / 'test.ducklake'}",
                "storage": str(workspace / "ducklake_data"),
            },
            enable_dataset_name_normalization=False,
        ),
        pipelines_dir=str(workspace / ".dlt" / pipeline_name),
    )


def delta_reader_pipeline(workspace: Path) -> dlt.Pipeline:
    """A reader dlt pipeline pointed at the workspace's Delta tables.

    Unlike DuckLake (where the catalog drives table discovery), dlt's
    filesystem `sql_client()` discovers tables from the pipeline's stored
    schema state. The reader therefore must share `pipeline_name` and
    `pipelines_dir` with the writer (`das_load` / `.dlt/pipelines`, see
    `pipelines/load.py:run_load`). It is read-only — only `sql_client()`
    is used — so no writer-state collision occurs. See ADR-0017.
    """
    import dlt

    return dlt.pipeline(
        pipeline_name="das_load",
        destination=dlt.destinations.filesystem(
            bucket_url=str(workspace / "das_delta"),
            enable_dataset_name_normalization=False,
        ),
        pipelines_dir=str(workspace / ".dlt" / "pipelines"),
    )


@pytest.fixture()
def fixtures_dir() -> Path:
    return Path(__file__).parent / "fixtures"
