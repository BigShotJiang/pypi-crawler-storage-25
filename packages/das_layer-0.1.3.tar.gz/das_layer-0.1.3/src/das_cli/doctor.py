"""`das doctor` checks: workspace parses, sources reachable, target writable."""

from __future__ import annotations

import os
import shutil
from dataclasses import dataclass
from pathlib import Path

import requests
from pydantic import ValidationError

from das_cli.config import load_das_config, load_source_config
from das_cli.contracts.loader import discover_sources
from das_cli.models.das_yaml import (
    AzureDefaultAuth,
    is_azure_url,
    parse_azure_credentials,
)


@dataclass(frozen=True)
class DoctorIssue:
    component: str
    message: str


def _has_azure_default_credential_hint() -> bool:
    """True if DefaultAzureCredential is likely to find an identity locally.

    Checks env vars and `az` on PATH. No network calls. False negatives are
    accepted (managed identity on an Azure VM produces no env-var or az hint
    but DefaultAzureCredential still works there)."""
    env_keys = (
        "AZURE_TENANT_ID",
        "AZURE_CLIENT_ID",
        "AZURE_CLIENT_SECRET",
        "AZURE_USERNAME",
        "AZURE_FEDERATED_TOKEN_FILE",
    )
    if any(os.environ.get(k) for k in env_keys):
        return True
    return shutil.which("az") is not None


def _check_azure_credentials(
    component: str, creds: dict[str, object], url: str
) -> list[DoctorIssue]:
    """Validate Azure credentials shape when the URL is Azure. See ADR-0020."""
    if not is_azure_url(url):
        return []
    try:
        azure = parse_azure_credentials(creds, url)
    except ValidationError as e:
        return [DoctorIssue(component, f"azure credentials invalid: {e}")]
    # azure is never None here — is_azure_url(url) was true, so the parser either
    # returned a typed instance or raised above.
    assert azure is not None
    if isinstance(azure, AzureDefaultAuth) and not _has_azure_default_credential_hint():
        return [
            DoctorIssue(
                component,
                "auth: default chosen but no AZURE_* env vars detected and "
                "`az` not on PATH; this only works on Azure VMs with "
                "managed identity",
            )
        ]
    return []


def run_doctor(das_yaml_path: Path | str) -> list[DoctorIssue]:
    issues: list[DoctorIssue] = []
    p = Path(das_yaml_path)
    if not p.is_file():
        return [DoctorIssue("workspace", f"das.yaml not found at {p}")]

    try:
        cfg = load_das_config(p)
    except Exception as e:
        return [DoctorIssue("workspace", f"das.yaml invalid: {e}")]

    # Target — sanity-check known destinations. See ADR-0016.
    if cfg.target.destination == "duckdb":
        db = cfg.target.credentials.get("database")
        if not db:
            issues.append(DoctorIssue("target", "duckdb destination missing credentials.database"))
    elif cfg.target.destination == "ducklake":
        creds = cfg.target.credentials
        if not creds.get("catalog"):
            issues.append(DoctorIssue("target", "ducklake destination missing credentials.catalog"))
        if not creds.get("storage"):
            issues.append(DoctorIssue("target", "ducklake destination missing credentials.storage"))
    elif cfg.target.destination == "delta":
        # See ADR-0017.
        if not cfg.target.credentials.get("bucket_url"):
            issues.append(DoctorIssue("target", "delta destination missing credentials.bucket_url"))
        else:
            bucket_url = cfg.target.credentials["bucket_url"]
            issues.extend(_check_azure_credentials("target", cfg.target.credentials, bucket_url))

    # Landing — validate Azure credentials when the URL is Azure. See ADR-0020.
    issues.extend(
        _check_azure_credentials("landing", cfg.landing.credentials, cfg.landing.bucket_url)
    )

    # Each source: parse _source.yml, ping the spec URL.
    contracts_root = (p.parent / cfg.contracts.root).resolve()
    for src in discover_sources(contracts_root):
        try:
            scfg = load_source_config(src.path / "_source.yml")
        except Exception as e:
            issues.append(DoctorIssue(f"source/{src.name}", f"_source.yml invalid: {e}"))
            continue

        if scfg.type == "sql":
            # See ADR-0018: lightweight URL + driver-importability check.
            from sqlalchemy.engine.url import make_url

            try:
                url = make_url(scfg.endpoint)
            except Exception as e:
                issues.append(
                    DoctorIssue(
                        f"source/{src.name}",
                        f"sql endpoint URL did not parse: {e}",
                    )
                )
                continue
            try:
                url.get_dialect().import_dbapi()
            except ImportError as e:
                issues.append(
                    DoctorIssue(
                        f"source/{src.name}",
                        f"sql driver for dialect '{url.drivername}' not importable: {e}",
                    )
                )
            except Exception as e:
                # Some dialects validate further on dbapi() (e.g., odbc driver string).
                issues.append(
                    DoctorIssue(
                        f"source/{src.name}",
                        f"sql driver for dialect '{url.drivername}' check failed: {e}",
                    )
                )
            continue

        spec_url = scfg.spec.metadata_url or scfg.spec.swagger_url
        if spec_url:
            try:
                resp = requests.get(spec_url, timeout=10)
                if resp.status_code >= 400:
                    issues.append(
                        DoctorIssue(
                            f"source/{src.name}",
                            f"spec URL {spec_url} returned {resp.status_code}",
                        )
                    )
            except requests.RequestException as e:
                issues.append(DoctorIssue(f"source/{src.name}", f"spec URL unreachable: {e}"))

    return issues
