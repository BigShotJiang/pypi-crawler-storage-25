"""Infer an ODCS contract from a sample of raw records.

Sees only top-level fields of `record["_data"]` (the blob from P1).
Type inference is conservative: pick the most permissive consistent type
across observations.
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from pathlib import Path
from typing import Any

from das_cli.bootstrap.naming import snake_case
from das_cli.contracts.loader import LoadedContract
from das_cli.contracts.odcs import (
    CustomProperty,
    OdcsContract,
    OdcsInfo,
    OdcsProperty,
    OdcsSchema,
)

_ISO_TS_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}")
_ISO_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def _classify_value(v: Any) -> str | None:
    if v is None:
        return None
    if isinstance(v, bool):
        return "boolean"
    if isinstance(v, int):
        return "integer"
    if isinstance(v, float):
        return "number"
    if isinstance(v, str):
        if _ISO_TS_RE.match(v):
            return "timestamp"
        if _ISO_DATE_RE.match(v):
            return "date"
        return "string"
    if isinstance(v, list):
        return "array"
    if isinstance(v, dict):
        return "object"
    return "string"


def _merge_types(types: set[str]) -> str:
    """Pick the most permissive type consistent with all observations."""
    types = {t for t in types if t is not None}
    if not types:
        return "string"
    if types == {"integer"}:
        return "integer"
    if types <= {"integer", "number"}:
        return "number"
    if types == {"boolean"}:
        return "boolean"
    if types == {"timestamp"}:
        return "timestamp"
    if types == {"date"}:
        return "date"
    if types == {"object"}:
        return "object"
    if types == {"array"}:
        return "array"
    return "string"


def infer_contract_from_records(
    records: Iterable[dict[str, Any]],
    *,
    source_name: str,
    resource_name: str,
) -> LoadedContract:
    """Build a draft ODCS contract from raw records.

    Each record is expected in P1 shape: `{"_data": {...}, ...}`.
    """
    records = list(records)
    if not records:
        raise ValueError("Cannot infer contract from empty record set")

    field_types: dict[str, set[str]] = {}
    field_observed: dict[str, int] = {}
    field_nulls: dict[str, int] = {}
    field_first_pos: dict[str, int] = {}

    for rec in records:
        data = rec.get("_data", rec)
        if not isinstance(data, dict):
            continue
        for i, (k, v) in enumerate(data.items()):
            field_types.setdefault(k, set())
            classified = _classify_value(v)
            if classified is None:
                field_nulls[k] = field_nulls.get(k, 0) + 1
            else:
                field_types[k].add(classified)
            field_observed[k] = field_observed.get(k, 0) + 1
            field_first_pos.setdefault(k, i)

    properties: list[OdcsProperty] = []
    for original_name in sorted(field_first_pos, key=lambda k: field_first_pos[k]):
        observed = field_observed[original_name]
        nulls = field_nulls.get(original_name, 0)
        merged = _merge_types(field_types[original_name])
        properties.append(
            OdcsProperty(
                name=snake_case(original_name),
                physicalName=original_name,
                logicalType=merged,  # type: ignore[arg-type]
                required=(nulls == 0 and observed == len(records)),
                primaryKey=False,
            )
        )

    contract = OdcsContract(
        apiVersion="v3.0.0",
        kind="DataContract",
        id=f"{source_name}.{resource_name}",
        name=resource_name.title(),
        version="0.1.0",
        status="draft",
        info=OdcsInfo(title=resource_name.title(), owner="data-platform"),
        schema=[
            OdcsSchema(
                name=resource_name,
                physicalName=resource_name,
                physicalType="table",
                properties=properties,
            )
        ],
        customProperties=[
            CustomProperty(property="das.bootstrapped_from", value="sample"),
        ],
    )

    return LoadedContract(
        path=Path(f"{resource_name}.odcs.yaml"),
        resource_name=resource_name,
        contract=contract,
    )
