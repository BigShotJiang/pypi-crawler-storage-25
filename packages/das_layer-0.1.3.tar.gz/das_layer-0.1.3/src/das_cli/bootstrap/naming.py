"""Naming helpers for bootstrap (CamelCase → snake_case, pluralization)."""

from __future__ import annotations

import re

_ACRONYM_BOUNDARY = re.compile(r"([A-Z]+)([A-Z][a-z])")
_LOWER_UPPER_BOUNDARY = re.compile(r"([a-z\d])([A-Z])")


def snake_case(name: str) -> str:
    """Convert CamelCase / PascalCase to snake_case.

    Treats acronym boundaries (HTTPSConn → https_conn) and digits sensibly.
    """
    if not name:
        return ""
    s = _ACRONYM_BOUNDARY.sub(r"\1_\2", name)
    s = _LOWER_UPPER_BOUNDARY.sub(r"\1_\2", s)
    return s.lower()


def pluralize(name: str) -> str:
    """Simple pluralizer for resource names (Product → products, Category → categories)."""
    snake = snake_case(name)
    if snake.endswith("s"):
        return snake
    if snake.endswith("y") and not snake.endswith(("ay", "ey", "iy", "oy", "uy")):
        return snake[:-1] + "ies"
    return snake + "s"


def pluralize_preserving_case(name: str) -> str:
    """Pluralize an OData EntityType name to its conventional EntitySet form.

    Preserves the input's capitalization, unlike `pluralize()` which lowercases
    via `snake_case` first. Differs from `pluralize()` in two deliberate ways:

    1. No `endswith("s")` pass-through. OData EntityTypes are conventionally
       singular, so `Address` / `EmailAddress` / `Status` are inputs we *want*
       to pluralize to `Addresses` / `EmailAddresses` / `Statuses`, not pass
       through.
    2. Adds the `+es` rule for consonant + s/x/z/ch/sh.

    See ADR-0024: OData EntitySet name persisted on `das.spec_ref`.
    """
    if not name:
        return ""
    if name.endswith("y") and not name.endswith(("ay", "ey", "iy", "oy", "uy")):
        return name[:-1] + "ies"
    if name[-1].lower() in ("s", "x", "z") or name[-2:].lower() in ("ch", "sh"):
        return name + "es"
    return name + "s"
