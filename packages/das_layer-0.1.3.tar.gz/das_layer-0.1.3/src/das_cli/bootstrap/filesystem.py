"""Discover files under a filesystem source's endpoint and emit ODCS contracts.

See ADR-0022: filesystem source type.
"""

from __future__ import annotations

import csv as _csv
from pathlib import Path

from das_cli.bootstrap.naming import snake_case
from das_cli.contracts.loader import LoadedContract
from das_cli.contracts.odcs import (
    CustomProperty,
    OdcsContract,
    OdcsInfo,
    OdcsProperty,
    OdcsSchema,
)
from das_cli.models.source_yml import SourceConfig


def bootstrap_filesystem_contracts(
    scfg: SourceConfig,
    *,
    source_name: str,
    xpath: str | None = None,
) -> list[LoadedContract]:
    """Walk `scfg.endpoint` and emit one ODCS contract per discoverable file.

    Supports CSV (Plan #1), Excel (Plan #2), XML (Plan #3), and QVD
    (Plan #4) — the complete ADR-0022 umbrella.

    `xpath` (optional) is the XPath expression used to extract records from
    each .xml file. Required only if the endpoint contains .xml files;
    csv/xlsx/qvd don't use it.

    Local paths only at the moment; blob endpoints (`az://`, `s3://`) require
    fsspec wiring and are deferred to a follow-up.
    """
    endpoint = scfg.endpoint
    if endpoint.startswith(("s3://", "gs://", "az://")):
        raise NotImplementedError(
            "Bootstrap from blob endpoints is not yet supported. "
            "Mirror the files locally and re-run, or write contracts by hand."
        )

    root = Path(endpoint).expanduser()
    if not root.is_dir():
        raise FileNotFoundError(f"Filesystem source endpoint not found: {root}")

    out: list[LoadedContract] = []
    for path in sorted(root.iterdir()):
        if not path.is_file():
            continue
        suffix = path.suffix.lower()
        if suffix == ".csv":
            out.append(_build_csv_contract(path, source_name=source_name))
        elif suffix == ".xlsx":
            out.extend(_build_excel_contracts(path, source_name=source_name))
        elif suffix == ".xml":
            if not xpath:
                raise ValueError("--xpath is required for filesystem bootstrap with .xml files")
            out.append(_build_xml_contract(path, source_name=source_name, xpath=xpath))
        elif suffix == ".qvd":
            out.append(_build_qvd_contract(path, source_name=source_name))
    return out


def _build_csv_contract(file_path: Path, *, source_name: str) -> LoadedContract:
    resource_name = snake_case(file_path.stem)

    columns = _read_csv_header(file_path)
    properties = [OdcsProperty(name=col, logicalType="string") for col in columns]

    spec_ref_value = {
        "kind": "filesystem",
        "format": "csv",
        "path": file_path.name,
    }

    contract = OdcsContract(
        apiVersion="v3.0.0",
        kind="DataContract",
        id=f"{source_name}.{resource_name}",
        name=resource_name,
        version="0.1.0",
        status="draft",
        info=OdcsInfo(title=resource_name, owner="data-platform"),
        schema=[
            OdcsSchema(
                name=resource_name,
                physicalName=resource_name,
                physicalType="table",
                properties=properties,
            )
        ],
        customProperties=[CustomProperty(property="das.spec_ref", value=spec_ref_value)],
    )

    return LoadedContract(
        path=Path(f"{resource_name}.odcs.yaml"),
        resource_name=resource_name,
        contract=contract,
    )


def _read_csv_header(file_path: Path) -> list[str]:
    """Return the header row of a CSV file; empty list if the file is empty."""
    with file_path.open("r", encoding="utf-8", newline="") as fh:
        reader = _csv.reader(fh)
        try:
            header = next(reader)
        except StopIteration:
            return []
    return [col.strip() for col in header if col.strip()]


def _build_excel_contracts(file_path: Path, *, source_name: str) -> list[LoadedContract]:
    """Yield one LoadedContract per (workbook, sheet) in `file_path`.

    Resource name = "<workbook_stem>__<sheet>" snake-cased so multi-workbook
    sources with the same sheet name don't collide.
    """
    import openpyxl

    workbook_stem = snake_case(file_path.stem)
    wb = openpyxl.load_workbook(file_path, read_only=True, data_only=True)
    out: list[LoadedContract] = []
    try:
        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            columns = _read_xlsx_header(ws)
            out.append(
                _make_excel_contract(
                    file_path=file_path,
                    sheet_name=sheet_name,
                    workbook_stem=workbook_stem,
                    columns=columns,
                    source_name=source_name,
                )
            )
    finally:
        wb.close()
    return out


def _read_xlsx_header(ws: object) -> list[str]:
    """Pull the first row as column names. Empty sheet → []."""
    # `ws` is openpyxl's read-only worksheet; typed loosely so we can defer
    # importing openpyxl at module level (it's only required when xlsx files
    # are present).
    for raw in ws.iter_rows(values_only=True, max_row=1):  # type: ignore[attr-defined]
        return [str(c).strip() for c in raw if c is not None and str(c).strip()]
    return []


def _make_excel_contract(
    *,
    file_path: Path,
    sheet_name: str,
    workbook_stem: str,
    columns: list[str],
    source_name: str,
) -> LoadedContract:
    resource_name = f"{workbook_stem}__{snake_case(sheet_name)}"
    properties = [OdcsProperty(name=col, logicalType="string") for col in columns]
    spec_ref_value = {
        "kind": "filesystem",
        "format": "excel",
        "path": file_path.name,
        "sheet": sheet_name,
    }
    contract = OdcsContract(
        apiVersion="v3.0.0",
        kind="DataContract",
        id=f"{source_name}.{resource_name}",
        name=resource_name,
        version="0.1.0",
        status="draft",
        info=OdcsInfo(title=resource_name, owner="data-platform"),
        schema=[
            OdcsSchema(
                name=resource_name,
                physicalName=resource_name,
                physicalType="table",
                properties=properties,
            )
        ],
        customProperties=[CustomProperty(property="das.spec_ref", value=spec_ref_value)],
    )
    return LoadedContract(
        path=Path(f"{resource_name}.odcs.yaml"),
        resource_name=resource_name,
        contract=contract,
    )


def _build_xml_contract(file_path: Path, *, source_name: str, xpath: str) -> LoadedContract:
    """Emit one LoadedContract for an .xml file by inspecting the first xpath match."""
    resource_name = snake_case(file_path.stem)
    columns = _read_xml_columns(file_path, xpath=xpath)
    properties = [OdcsProperty(name=col, logicalType="string") for col in sorted(columns)]
    spec_ref_value = {
        "kind": "filesystem",
        "format": "xml",
        "path": file_path.name,
        "xpath": xpath,
    }
    contract = OdcsContract(
        apiVersion="v3.0.0",
        kind="DataContract",
        id=f"{source_name}.{resource_name}",
        name=resource_name,
        version="0.1.0",
        status="draft",
        info=OdcsInfo(title=resource_name, owner="data-platform"),
        schema=[
            OdcsSchema(
                name=resource_name,
                physicalName=resource_name,
                physicalType="table",
                properties=properties,
            )
        ],
        customProperties=[CustomProperty(property="das.spec_ref", value=spec_ref_value)],
    )
    return LoadedContract(
        path=Path(f"{resource_name}.odcs.yaml"),
        resource_name=resource_name,
        contract=contract,
    )


def _read_xml_columns(file_path: Path, *, xpath: str) -> list[str]:
    """Inspect the first xpath match in `file_path` and return its column names.

    Returns [] when the file has no matches.
    """
    from lxml import etree

    # Last path segment is the target tag.
    last = xpath.split("/")[-1]
    if ":" in last:
        # Namespaced xpath at bootstrap time isn't supported in v1 — the
        # walker has no spec_ref.namespaces to resolve the prefix against.
        # Users with namespaced XML hand-write the contract after bootstrap.
        return []
    target_tag = last

    with file_path.open("rb") as fh:
        events = etree.iterparse(fh, events=("end",), tag=target_tag)
        for _event, elem in events:
            attrs = list(elem.attrib.keys())
            children = [child.tag for child in elem]
            # Strip namespace prefixes if any sneaked through.
            cols = [t.split("}", 1)[1] if t.startswith("{") else t for t in [*attrs, *children]]
            elem.clear()
            return cols
    return []


def _build_qvd_contract(file_path: Path, *, source_name: str) -> LoadedContract:
    """Emit one LoadedContract for a .qvd file by inspecting the first chunk.

    Unlike csv/excel/xml (types default to `string`), QVD's metadata header
    carries real types — we infer per-column logicalType from the value
    classes pyqvd returns for the first data row. Empty tables default to
    `string` (no values to inspect).
    """
    resource_name = snake_case(file_path.stem)

    columns, types = _read_qvd_columns_and_types(file_path)
    properties = [
        OdcsProperty(name=col, logicalType=t)  # type: ignore[arg-type]
        for col, t in zip(columns, types, strict=False)
    ]
    spec_ref_value = {
        "kind": "filesystem",
        "format": "qvd",
        "path": file_path.name,
    }
    contract = OdcsContract(
        apiVersion="v3.0.0",
        kind="DataContract",
        id=f"{source_name}.{resource_name}",
        name=resource_name,
        version="0.1.0",
        status="draft",
        info=OdcsInfo(title=resource_name, owner="data-platform"),
        schema=[
            OdcsSchema(
                name=resource_name,
                physicalName=resource_name,
                physicalType="table",
                properties=properties,
            )
        ],
        customProperties=[CustomProperty(property="das.spec_ref", value=spec_ref_value)],
    )
    return LoadedContract(
        path=Path(f"{resource_name}.odcs.yaml"),
        resource_name=resource_name,
        contract=contract,
    )


def _read_qvd_columns_and_types(file_path: Path) -> tuple[list[str], list[str]]:
    """Return (column_names, logical_types) from a .qvd file's first chunk."""
    from pyqvd import QvdTable

    # chunk_size=1 keeps memory tiny; we only need one row to type-infer.
    chunks = QvdTable.from_qvd(file_path, chunk_size=1)
    columns: list[str] = []
    types: list[str] = []
    for chunk in chunks:
        columns = list(chunk.columns)
        if not chunk.data:
            # First chunk has no rows — empty table; default all types to string.
            types = ["string"] * len(columns)
        else:
            first_row = chunk.data[0]
            types = [_qvd_logical_type(cell) for cell in first_row]
        break  # one chunk is enough to derive the schema
    return columns, types


_QVD_TYPE_MAP: dict[str, str] = {
    "IntegerValue": "integer",
    "DualIntegerValue": "integer",
    "DoubleValue": "number",
    "MoneyValue": "number",
    "DualDoubleValue": "number",
    "StringValue": "string",
    "DateValue": "date",
    "TimestampValue": "timestamp",
    "TimeValue": "string",
    "IntervalValue": "string",
}


def _qvd_logical_type(cell: object) -> str:
    """Map a pyqvd typed value to an ODCS logicalType. None → string."""
    if cell is None:
        return "string"
    cls = type(cell).__name__
    return _QVD_TYPE_MAP.get(cls, "string")
