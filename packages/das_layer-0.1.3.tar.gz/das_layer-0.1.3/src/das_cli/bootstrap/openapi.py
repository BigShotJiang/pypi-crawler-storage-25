"""Bootstrap ODCS contracts from an OpenAPI document.

Walks `components.schemas` directly and emits ODCS v3 documents. See ADR-0006
for the rationale: walking the JSON document in-process gives us full control
over post-processing (snake_case, primary key inference, das.* customProperties)
without coupling to an external import tool's release cadence.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from das_cli.bootstrap.naming import pluralize, snake_case
from das_cli.contracts.loader import LoadedContract
from das_cli.contracts.odcs import (
    CustomProperty,
    OdcsContract,
    OdcsInfo,
    OdcsProperty,
    OdcsSchema,
)

_FORMAT_TO_LOGICAL: dict[tuple[str, str], tuple[str, str | None]] = {
    ("string", "date-time"): ("timestamp", None),
    ("string", "date"): ("date", None),
    ("string", "uuid"): ("string", None),
    ("string", "byte"): ("string", None),
    ("integer", "int32"): ("integer", None),
    ("integer", "int64"): ("integer", "bigint"),
    ("number", "double"): ("number", None),
    ("number", "float"): ("number", None),
    ("number", "decimal"): ("number", "decimal(19,4)"),
}

_TYPE_TO_LOGICAL: dict[str, tuple[str, str | None]] = {
    "string": ("string", None),
    "integer": ("integer", None),
    "number": ("number", None),
    "boolean": ("boolean", None),
    "object": ("object", None),
    "array": ("array", None),
}

_CURSOR_HINTS = ("modified_at", "modified_date", "last_modified", "updated_at", "updated_date")

_WRAPPER_KEYS = ("value", "data", "results")


def _resolve_ref(document: dict[str, Any], ref: str) -> dict[str, Any] | None:
    """Resolve a `#/components/schemas/X` ref against the OpenAPI document."""
    if not ref.startswith("#/"):
        return None
    parts = ref[2:].split("/")
    node: Any = document
    for p in parts:
        if not isinstance(node, dict) or p not in node:
            return None
        node = node[p]
    return node if isinstance(node, dict) else None


def _schema_name_from_ref(ref: str) -> str | None:
    """Return `X` from `#/components/schemas/X`, or None."""
    prefix = "#/components/schemas/"
    return ref[len(prefix) :] if ref.startswith(prefix) else None


def _classify_response_schema(
    schema: dict[str, Any], document: dict[str, Any]
) -> tuple[str | None, str | None]:
    """Return `(schema_name, response_path)` if recognised, else `(None, None)`."""
    if "$ref" in schema:
        resolved = _resolve_ref(document, schema["$ref"])
        if resolved is None:
            return (None, None)
        return _classify_response_schema(resolved, document)

    if schema.get("type") == "array":
        items = schema.get("items", {})
        ref = items.get("$ref")
        if ref:
            return (_schema_name_from_ref(ref), None)
        return (None, None)

    if schema.get("type") == "object":
        props = schema.get("properties", {})
        for key in _WRAPPER_KEYS:
            sub = props.get(key)
            if isinstance(sub, dict) and sub.get("type") == "array":
                items = sub.get("items", {})
                ref = items.get("$ref")
                if ref:
                    return (_schema_name_from_ref(ref), f"$.{key}")
        return (None, None)

    return (None, None)


def _resolve_path_prefix(document: dict[str, Any], source_endpoint: str | None) -> str:
    """Return the path prefix to strip from operation paths.

    OpenAPI 3 specs may declare a `servers[0].url` whose path component is
    duplicated into `paths.*` keys. Some specs (Northwind) skip the
    `servers` block entirely and just bake the API prefix into every path.
    Either way, we want `das.endpoint.path` to be relative to
    `_source.yml.endpoint` so that extract concatenates cleanly.

    Resolution order:
    1. `servers[0].url`'s path component if present (OpenAPI 3 standard).
    2. The path component of `source_endpoint` if provided (catches specs
       like Northwind that omit `servers`).
    3. Empty string — no stripping.
    """
    from urllib.parse import urlparse

    servers = document.get("servers") or []
    if servers and isinstance(servers[0], dict):
        url = servers[0].get("url", "")
        if url:
            prefix = urlparse(url).path.rstrip("/")
            if prefix:
                return prefix
    if source_endpoint:
        prefix = urlparse(source_endpoint).path.rstrip("/")
        if prefix:
            return prefix
    return ""


def _index_paths_by_schema(
    document: dict[str, Any],
    *,
    source_endpoint: str | None = None,
) -> dict[str, list[tuple[str, str | None]]]:
    """Walk `paths.*.get` and index `(path, response_path)` by schema name."""
    path_prefix = _resolve_path_prefix(document, source_endpoint)
    index: dict[str, list[tuple[str, str | None]]] = {}
    for path, item in (document.get("paths") or {}).items():
        if path_prefix and path.startswith(path_prefix):
            path = path[len(path_prefix) :] or "/"
        if not isinstance(item, dict):
            continue
        op = item.get("get")
        if not isinstance(op, dict):
            continue
        responses = op.get("responses") or {}
        for code, resp in responses.items():
            if not (str(code).startswith("2") and isinstance(resp, dict)):
                continue
            content = resp.get("content") or {}
            for media in content.values():
                if not isinstance(media, dict):
                    continue
                schema = media.get("schema")
                if not isinstance(schema, dict):
                    continue
                schema_name, response_path = _classify_response_schema(schema, document)
                if schema_name:
                    index.setdefault(schema_name, []).append((path, response_path))
                break
            break
    return index


def _logical_for(prop: dict[str, Any]) -> tuple[str, str | None]:
    t = prop.get("type", "string")
    fmt = prop.get("format")
    if fmt and (t, fmt) in _FORMAT_TO_LOGICAL:
        return _FORMAT_TO_LOGICAL[(t, fmt)]
    return _TYPE_TO_LOGICAL.get(t, ("string", None))


def _is_pk_candidate(snake_name: str, schema_name: str) -> bool:
    schema_snake = snake_case(schema_name)
    return snake_name in {"id", f"{schema_snake}_id"}


def _build_property(
    prop_name: str,
    prop_schema: dict[str, Any],
    *,
    required_set: set[str],
    schema_name: str,
) -> OdcsProperty:
    snake = snake_case(prop_name)
    logical, physical = _logical_for(prop_schema)
    return OdcsProperty(
        name=snake,
        physicalName=prop_name,
        logicalType=logical,  # type: ignore[arg-type]
        physicalType=physical,
        required=prop_name in required_set,
        primaryKey=_is_pk_candidate(snake, schema_name),
    )


def _pick_cursor(properties: list[OdcsProperty]) -> str | None:
    names = {p.name for p in properties}
    for hint in _CURSOR_HINTS:
        if hint in names:
            return hint
    return None


def _build_contract(
    schema_name: str,
    schema: dict[str, Any],
    *,
    source_name: str,
    paths_index: dict[str, list[tuple[str, str | None]]] | None = None,
) -> LoadedContract:
    required_set = set(schema.get("required", []))
    properties_obj = schema.get("properties", {})
    properties = [
        _build_property(name, sub, required_set=required_set, schema_name=schema_name)
        for name, sub in properties_obj.items()
    ]

    resource_name = pluralize(schema_name)
    cursor = _pick_cursor(properties)
    cps: list[CustomProperty] = [
        CustomProperty(
            property="das.spec_ref",
            value={"kind": "openapi", "path": f"#/components/schemas/{schema_name}"},
        ),
    ]
    if cursor:
        cps.append(CustomProperty(property="das.cursor", value=cursor))

    # See ADR-0015: emit das.endpoint when paths-walker found exactly one match.
    if paths_index is not None:
        matches = paths_index.get(schema_name, [])
        if len(matches) == 1:
            path, response_path = matches[0]
            cps.append(
                CustomProperty(
                    property="das.endpoint",
                    value={"path": path, "response_path": response_path},
                )
            )

    contract = OdcsContract(
        apiVersion="v3.0.0",
        kind="DataContract",
        id=f"{source_name}.{resource_name}",
        name=schema_name,
        version="0.1.0",
        status="draft",
        info=OdcsInfo(title=schema_name, owner="data-platform"),
        schema=[
            OdcsSchema(
                name=resource_name,
                physicalName=resource_name,
                physicalType="table",
                properties=properties,
            )
        ],
        customProperties=cps,
    )

    return LoadedContract(
        path=Path(f"{resource_name}.odcs.yaml"),
        resource_name=resource_name,
        contract=contract,
    )


def bootstrap_openapi_contracts(
    document: dict[str, Any],
    *,
    source_name: str,
    source_endpoint: str | None = None,
) -> list[LoadedContract]:
    """Walk components.schemas and emit one LoadedContract per object schema.

    `source_endpoint` is the `_source.yml.endpoint` URL; when provided, the
    paths-walker strips its path component from operation paths so emitted
    `das.endpoint.path` values are relative to that endpoint.
    """
    schemas = document.get("components", {}).get("schemas", {})
    paths_index = _index_paths_by_schema(document, source_endpoint=source_endpoint)
    out: list[LoadedContract] = []
    for name, schema in schemas.items():
        if schema.get("type") != "object":
            continue
        out.append(_build_contract(name, schema, source_name=source_name, paths_index=paths_index))
    return out
