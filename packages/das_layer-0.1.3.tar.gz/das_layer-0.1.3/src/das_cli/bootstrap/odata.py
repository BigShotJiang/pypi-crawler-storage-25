"""Parse OData $metadata XML and emit ODCS LoadedContracts.

See ADR-0006: bootstrap mix.
We use stdlib ElementTree rather than pyodata for v0.1 — pyodata's loader
requires a live HTTP service. The $metadata XML structure is well-defined
enough to walk directly.
"""

from __future__ import annotations

from pathlib import Path
from xml.etree import ElementTree

from das_cli.bootstrap.naming import pluralize, snake_case
from das_cli.contracts.loader import LoadedContract
from das_cli.contracts.odcs import (
    CustomProperty,
    OdcsContract,
    OdcsInfo,
    OdcsProperty,
    OdcsSchema,
)

_NS = {
    "edmx": "http://docs.oasis-open.org/odata/ns/edmx",
    "edm": "http://docs.oasis-open.org/odata/ns/edm",
}

_EDM_TO_LOGICAL: dict[str, tuple[str, str | None]] = {
    "Edm.String": ("string", None),
    "Edm.Boolean": ("boolean", None),
    "Edm.Int16": ("integer", None),
    "Edm.Int32": ("integer", None),
    "Edm.Int64": ("integer", "bigint"),
    "Edm.Single": ("number", None),
    "Edm.Double": ("number", None),
    "Edm.DateTimeOffset": ("timestamp", None),
    "Edm.DateTime": ("timestamp", None),
    "Edm.Date": ("date", None),
    "Edm.Guid": ("string", None),
    "Edm.Binary": ("string", None),
}

_CURSOR_HINTS = ("ModifiedDate", "LastModified", "UpdatedAt", "UpdatedDate")

# See ADR-0027: max-precision fallback for variable/unspecified decimals.
_MAX_DECIMAL = "decimal(38,9)"


def _parse_int(value: str | None) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except ValueError:
        return None


def _logical_for(
    edm_type: str, *, precision: str | None, scale: str | None
) -> tuple[str, str | None]:
    if edm_type == "Edm.Decimal":
        # See ADR-0027: honor (P,S) only when both satisfy OData CSDL
        # constraints; otherwise fall back to _MAX_DECIMAL.
        p = _parse_int(precision)
        s = _parse_int(scale)
        if p is not None and s is not None and p >= 1 and 0 <= s <= p:
            return ("number", f"decimal({p},{s})")
        return ("number", _MAX_DECIMAL)
    if edm_type in _EDM_TO_LOGICAL:
        return _EDM_TO_LOGICAL[edm_type]
    return ("string", None)


def _build_property(elem: ElementTree.Element, *, key_names: set[str]) -> OdcsProperty:
    edm_name = elem.get("Name", "")
    edm_type = elem.get("Type", "Edm.String")
    nullable = elem.get("Nullable", "true").lower() != "false"
    precision = elem.get("Precision")
    scale = elem.get("Scale")

    logical, physical = _logical_for(edm_type, precision=precision, scale=scale)

    return OdcsProperty(
        name=snake_case(edm_name),
        physicalName=edm_name,
        logicalType=logical,  # type: ignore[arg-type]
        physicalType=physical,
        required=not nullable,
        primaryKey=edm_name in key_names,
    )


def _pick_cursor(properties: list[OdcsProperty]) -> str | None:
    by_physical = {p.physicalName: p for p in properties}
    for hint in _CURSOR_HINTS:
        if hint in by_physical:
            return by_physical[hint].name
    return None


def _build_contract(
    entity: ElementTree.Element,
    source_name: str,
    *,
    entity_set: str | None,
) -> LoadedContract:
    type_name = entity.get("Name", "")
    key_names: set[str] = set()
    key_elem = entity.find("edm:Key", _NS)
    if key_elem is not None:
        for ref in key_elem.findall("edm:PropertyRef", _NS):
            n = ref.get("Name")
            if n:
                key_names.add(n)

    properties = [
        _build_property(p, key_names=key_names) for p in entity.findall("edm:Property", _NS)
    ]

    resource_name = pluralize(type_name)
    contract = OdcsContract(
        apiVersion="v3.0.0",
        kind="DataContract",
        id=f"{source_name}.{resource_name}",
        name=type_name,
        version="0.1.0",
        status="draft",
        info=OdcsInfo(title=type_name, owner="data-platform"),
        schema=[
            OdcsSchema(
                name=resource_name,
                physicalName=resource_name,
                physicalType="table",
                properties=properties,
            )
        ],
        customProperties=_build_custom_properties(type_name, properties, entity_set=entity_set),
    )

    return LoadedContract(
        path=Path(f"{resource_name}.odcs.yaml"),
        resource_name=resource_name,
        contract=contract,
    )


def _build_custom_properties(
    type_name: str, properties: list[OdcsProperty], *, entity_set: str | None
) -> list[CustomProperty]:
    # See ADR-0024 for the entity_set persistence rule, and ADR-0025 for the
    # EntityContainer-driven emission rule that ensures entity_set is populated
    # whenever a container is present.
    spec_ref_value: dict[str, str] = {"kind": "odata", "type": type_name}
    if entity_set:
        spec_ref_value["entity_set"] = entity_set
    cps: list[CustomProperty] = [
        CustomProperty(property="das.spec_ref", value=spec_ref_value),
    ]
    cursor = _pick_cursor(properties)
    if cursor:
        cps.append(CustomProperty(property="das.cursor", value=cursor))
    return cps


def _build_entity_set_map(root: ElementTree.Element) -> dict[str, str]:
    """Map bare EntityType name → declared EntitySet `Name` from `<EntityContainer>`.

    Strips the namespace prefix from the EntitySet's `EntityType` attribute
    (`AdventureWorks.Address` → `Address`). Returns an empty dict if `$metadata`
    has no EntityContainer.

    If two EntitySets reference the same bare EntityType name (a pre-existing
    limitation of this map shape), the last one wins. Not encountered in any
    OData service the project has bootstrapped against to date.
    """
    out: dict[str, str] = {}
    for container in root.iter(f"{{{_NS['edm']}}}EntityContainer"):
        for entity_set in container.findall("edm:EntitySet", _NS):
            set_name = entity_set.get("Name")
            qualified_type = entity_set.get("EntityType", "")
            if not set_name or not qualified_type:
                continue
            bare_type = qualified_type.rsplit(".", 1)[-1]
            out[bare_type] = set_name
    return out


def bootstrap_odata_contracts(metadata_xml: str, *, source_name: str) -> list[LoadedContract]:
    """Parse $metadata XML and return one LoadedContract per queryable resource.

    When `<EntityContainer>` is present it is authoritative: one contract per
    declared `<EntitySet>`, with the backing `<EntityType>` element looked up
    for schema. EntityTypes referenced only via NavigationProperty / Collection
    are dropped. A container with zero `<EntitySet>` children emits zero
    contracts — the container's emptiness is a declaration, not a fall-through
    trigger. See ADR-0025.

    When `<EntityContainer>` is absent (OData v1/v2 or stripped metadata),
    fall back to the legacy per-EntityType walk; `entity_set` is omitted from
    `das.spec_ref` and `synthesize_odata_endpoint()` uses its
    case-preserving pluralization heuristic (ADR-0024).
    """
    root = ElementTree.fromstring(metadata_xml)
    containers = list(root.iter(f"{{{_NS['edm']}}}EntityContainer"))
    entity_set_by_type = _build_entity_set_map(root)
    type_elements = {e.get("Name"): e for e in root.iter(f"{{{_NS['edm']}}}EntityType")}

    out: list[LoadedContract] = []
    if containers:
        for type_name, set_name in entity_set_by_type.items():
            elem = type_elements.get(type_name)
            if elem is None:
                # Malformed metadata: EntitySet references a type with no
                # matching <EntityType> element. Skip silently.
                continue
            out.append(_build_contract(elem, source_name=source_name, entity_set=set_name))
    else:
        for elem in type_elements.values():
            out.append(_build_contract(elem, source_name=source_name, entity_set=None))
    return out
