"""Contract bootstrap from source specs and sampled landings."""
