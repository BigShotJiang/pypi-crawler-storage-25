"""Reflect a SQL source via SQLAlchemy and emit ODCS contracts.

See ADR-0018: SQL source via SQLAlchemy reflection.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

from sqlalchemy import (
    BigInteger,
    Boolean,
    Date,
    DateTime,
    Float,
    Integer,
    LargeBinary,
    MetaData,
    Numeric,
    SmallInteger,
    String,
    Text,
    Time,
    create_engine,
    inspect,
)
from sqlalchemy.types import BLOB, TIMESTAMP

from das_cli.bootstrap.naming import snake_case
from das_cli.contracts.loader import LoadedContract
from das_cli.contracts.odcs import (
    CustomProperty,
    OdcsContract,
    OdcsInfo,
    OdcsProperty,
    OdcsSchema,
)
from das_cli.models.source_yml import SourceConfig

if TYPE_CHECKING:
    from sqlalchemy import Column, Table

# Hint columns the cursor heuristic looks for. Lowercased compare.
_CURSOR_HINTS: tuple[str, ...] = (
    "updated_at",
    "modified_at",
    "last_modified",
    "updated_date",
    "modified_date",
)


def _logical_for(col: Column[Any]) -> tuple[str, str | None]:
    """Map a SQLAlchemy generic Column type to (logicalType, physicalType).

    Falls back to ('string', None) for unknown types. See ADR-0018.
    """
    sa_type = col.type

    # Numeric-with-scale must be detected BEFORE the Integer branches: oracle.NUMBER
    # extends both Numeric and Integer (sqlalchemy/dialects/oracle/types.py), so the
    # Integer branch would otherwise catch NUMBER(p,s>0) and lose the scale — which
    # then breaks P2's decimal coercion in pipelines/load.py::_project_record.
    # scale == 0 (or None) falls through so NUMBER(p,0) stays integer-like, matching
    # Oracle's own driver behavior (asdecimal=False ⇒ int).
    if isinstance(sa_type, Numeric) and not isinstance(sa_type, Float):
        scale = sa_type.scale
        if scale is not None and scale > 0:
            precision = sa_type.precision
            if precision is not None:
                return ("number", f"decimal({precision},{scale})")
            return ("number", None)

    if isinstance(sa_type, BigInteger):
        return ("integer", "bigint")
    if isinstance(sa_type, Integer | SmallInteger):
        return ("integer", None)

    # Generic Numeric with scale == 0 or unspecified that didn't get caught by the
    # Integer branches above (e.g. MSSQL / Postgres NUMERIC(10,0), or NUMERIC with
    # no precision/scale at all).
    if isinstance(sa_type, Numeric) and not isinstance(sa_type, Float):
        precision = sa_type.precision
        scale = sa_type.scale
        if precision is not None and scale is not None:
            return ("number", f"decimal({precision},{scale})")
        return ("number", None)

    if isinstance(sa_type, Float):
        return ("number", None)
    if isinstance(sa_type, Boolean):
        return ("boolean", None)
    if isinstance(sa_type, String | Text):
        return ("string", None)
    if isinstance(sa_type, Date):
        return ("date", None)
    if isinstance(sa_type, Time):
        return ("string", None)
    if isinstance(sa_type, DateTime | TIMESTAMP):
        return ("timestamp", None)
    if isinstance(sa_type, LargeBinary | BLOB):
        return ("string", None)
    return ("string", None)


def _pick_cursor(props: list[OdcsProperty]) -> str | None:
    """Return the first property whose name matches a cursor hint."""
    by_name = {p.name: p for p in props}
    for hint in _CURSOR_HINTS:
        if hint in by_name:
            return hint
    return None


def _build_property(col: Column[Any]) -> OdcsProperty:
    logical, physical = _logical_for(col)
    # SQLAlchemy reflection returns `quoted_name` (a str subclass) for col.name;
    # PyYAML safe_dump can't represent it, so coerce to plain str.
    col_name = str(col.name)
    return OdcsProperty(
        name=snake_case(col_name),
        physicalName=col_name,
        logicalType=logical,  # type: ignore[arg-type]
        physicalType=physical,
        required=not col.nullable,
        primaryKey=bool(col.primary_key),
    )


def _build_contract(
    table: Table,
    *,
    source_name: str,
    schema: str | None,
) -> LoadedContract:
    properties = [_build_property(c) for c in table.columns]
    # SQLAlchemy reflection returns `quoted_name` (a str subclass); coerce to
    # plain str so PyYAML safe_dump can represent it on write.
    table_name = str(table.name)
    schema_name = str(schema) if schema is not None else None
    resource_name = snake_case(table_name)

    custom_props: list[CustomProperty] = [
        CustomProperty(
            property="das.spec_ref",
            value={"kind": "sql", "schema": schema_name, "table": table_name},
        ),
    ]
    cursor = _pick_cursor(properties)
    if cursor:
        custom_props.append(CustomProperty(property="das.cursor", value=cursor))

    contract = OdcsContract(
        apiVersion="v3.0.0",
        kind="DataContract",
        id=f"{source_name}.{resource_name}",
        name=table_name,
        version="0.1.0",
        status="draft",
        info=OdcsInfo(title=table_name, owner="data-platform"),
        schema=[
            OdcsSchema(
                name=resource_name,
                physicalName=table_name,
                physicalType="table",
                properties=properties,
            )
        ],
        customProperties=custom_props,
    )

    return LoadedContract(
        path=Path(f"{resource_name}.odcs.yaml"),
        resource_name=resource_name,
        contract=contract,
    )


def bootstrap_sql_contracts(
    scfg: SourceConfig,
    *,
    source_name: str,
) -> list[LoadedContract]:
    """Reflect schemas via SQLAlchemy and return one LoadedContract per table.

    Schemas to reflect: `scfg.spec.schemas` if set, else the connection user's
    default schema (which is `None` for SQLite, `dbo` for SQL Server, the user
    name for Oracle, `public` for Postgres). `scfg.spec.tables` filters to a
    subset; absent means "every table in the listed schemas." Views are
    included when `scfg.spec.include_views` is True.
    """
    engine = create_engine(scfg.endpoint)
    try:
        if scfg.spec.schemas:
            target_schemas: list[str | None] = list(scfg.spec.schemas)
        else:
            insp = inspect(engine)
            target_schemas = [insp.default_schema_name]

        out: list[LoadedContract] = []
        for schema in target_schemas:
            md = MetaData()
            md.reflect(
                bind=engine,
                schema=schema,
                only=scfg.spec.tables,
                views=scfg.spec.include_views,
            )
            for table in md.sorted_tables:
                out.append(_build_contract(table, source_name=source_name, schema=schema))
    finally:
        engine.dispose()
    return out
