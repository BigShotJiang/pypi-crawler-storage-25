"""Excel file reader. See ADR-0022.

Uses openpyxl's read_only mode plus iter_rows(values_only=True) for true
row-by-row streaming. Never materializes the full sheet.

`data_only=True` returns formula results (the last cached value) rather
than the formula text — matching what users see in the UI.
"""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path
from typing import Any

from das_cli.contracts.filesystem_spec_ref import FilesystemSpecRef
from das_cli.dlt_glue.file_readers._inject import apply_inject


def read_rows(file_item: Any, spec_ref: FilesystemSpecRef) -> Iterator[dict[str, Any]]:
    """Yield one dict per data row from one sheet of an Excel workbook.

    Args:
        file_item: dlt FileItemDict (or stand-in with `open(mode="rb")`,
                   `file_name`, optional `modification_date`).
        spec_ref: Resource spec; `sheet` is required, `header_row` defaults to 1,
                  `inject` is honored.

    Raises:
        KeyError: when `spec_ref.sheet` isn't in the workbook.
    """
    import openpyxl

    if spec_ref.sheet is None:
        raise ValueError("excel reader requires spec_ref.sheet")
    sheet_name = spec_ref.sheet
    header_row = spec_ref.header_row or 1

    with file_item.open(mode="rb") as binary:
        wb = openpyxl.load_workbook(binary, read_only=True, data_only=True)
        try:
            if sheet_name not in wb.sheetnames:
                raise KeyError(
                    f"Sheet {sheet_name!r} not in workbook. " f"Available: {wb.sheetnames}"
                )
            ws = wb[sheet_name]

            context = _build_inject_context(file_item, sheet_name)

            row_iter = ws.iter_rows(values_only=True)
            yield from apply_inject(
                _rows_from_sheet(row_iter, header_row=header_row),
                inject=spec_ref.inject,
                context=context,
            )
        finally:
            wb.close()


def _rows_from_sheet(
    row_iter: Iterator[tuple[Any, ...]],
    *,
    header_row: int,
) -> Iterator[dict[str, Any]]:
    """Pull the header row, then yield {col: value} dicts for each data row.

    `header_row` is 1-based to match Excel's row numbering. Rows above the
    header are skipped.
    """
    header: list[str] | None = None
    for row_index, raw in enumerate(row_iter, start=1):
        if row_index < header_row:
            continue
        if row_index == header_row:
            header = [str(c) if c is not None else "" for c in raw]
            continue
        assert header is not None  # set above when row_index == header_row
        if all(cell is None for cell in raw):
            # Skip fully-blank trailing rows openpyxl sometimes emits.
            continue
        yield dict(zip(header, raw, strict=False))


def _build_inject_context(file_item: Any, sheet_name: str) -> dict[str, Any]:
    file_name = getattr(file_item, "file_name", None)
    if file_name is None and hasattr(file_item, "get"):
        file_name = file_item.get("file_name", "")
    file_name = file_name or ""

    file_url = getattr(file_item, "file_url", None)
    if file_url is None and hasattr(file_item, "get"):
        file_url = file_item.get("file_url", "")
    file_url = file_url or ""

    mtime = getattr(file_item, "modification_date", None)
    if mtime is None and hasattr(file_item, "get"):
        mtime = file_item.get("modification_date")

    return {
        "basename": Path(file_name).name if file_name else "",
        "fullpath": file_url,
        "mtime": mtime,
        "sheet": sheet_name,
    }
