"""CSV file reader. See ADR-0022.

Streams rows via stdlib csv.DictReader over a TextIOWrapper around the
fsspec-backed binary file handle. Never materializes the full file.
"""

from __future__ import annotations

import csv as _csv
import io
from collections.abc import Iterator
from pathlib import Path
from typing import Any

from das_cli.contracts.filesystem_spec_ref import FilesystemSpecRef
from das_cli.dlt_glue.file_readers._inject import apply_inject


def read_rows(file_item: Any, spec_ref: FilesystemSpecRef) -> Iterator[dict[str, Any]]:
    """Yield one dict per data row from a CSV file.

    Args:
        file_item: dlt FileItemDict (or stand-in with `open(mode="rb")`,
                   `file_name`, optional `modification_date`).
        spec_ref: Resource spec; uses `delimiter`, `encoding`, `inject`.
    """
    delimiter = spec_ref.delimiter or ","
    encoding = spec_ref.encoding or "utf-8"

    context = _build_inject_context(file_item)

    with file_item.open(mode="rb") as binary:
        text = io.TextIOWrapper(binary, encoding=encoding, newline="")
        reader = _csv.DictReader(text, delimiter=delimiter)
        yield from apply_inject(reader, inject=spec_ref.inject, context=context)


def _build_inject_context(file_item: Any) -> dict[str, Any]:
    # dlt's FileItemDict is a dict subclass; data is stored as dict keys, not
    # attributes. Use .get() so stand-in objects with real attributes (tests)
    # also work via the fallback getattr path.
    file_name = (
        (file_item.get("file_name") if hasattr(file_item, "get") else None)
        or getattr(file_item, "file_name", None)
        or ""
    )
    file_url = (
        (file_item.get("file_url") if hasattr(file_item, "get") else None)
        or getattr(file_item, "file_url", None)
        or ""
    )
    mtime = (file_item.get("modification_date") if hasattr(file_item, "get") else None) or getattr(
        file_item, "modification_date", None
    )

    return {
        "basename": Path(file_name).name if file_name else "",
        "fullpath": file_url,
        "mtime": mtime,
    }
