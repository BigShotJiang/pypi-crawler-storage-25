"""QVD (Qlik) file reader. See ADR-0022.

Uses pyqvd.QvdTable.from_stream(binary, chunk_size=N) to obtain an
Iterator[QvdTable]; iterates each chunk's rows and unwraps the typed
value objects (IntegerValue, StringValue, etc.) via .calculation_value
to native Python primitives. Never loads the full file — chunk_size
caps the resident-set per yielded chunk.
"""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path
from typing import Any

from das_cli.contracts.filesystem_spec_ref import FilesystemSpecRef
from das_cli.dlt_glue.file_readers._inject import apply_inject

# pyqvd internally chunks at this size; tuned to balance per-chunk
# memory with iteration overhead. 10k rows per chunk fits typical
# wide qvd schemas comfortably under a few MB.
_CHUNK_SIZE = 10_000


def read_rows(file_item: Any, spec_ref: FilesystemSpecRef) -> Iterator[dict[str, Any]]:
    """Yield one dict per row from a QVD file.

    Args:
        file_item: dlt FileItemDict (or stand-in with `open(mode="rb")`,
                   `file_name`, optional `modification_date`).
        spec_ref: Resource spec; `inject` is honored. QVD has no per-resource
                  selectors (the file is self-describing).
    """
    from pyqvd import QvdTable

    context = _build_inject_context(file_item)

    with file_item.open(mode="rb") as binary:
        chunks = QvdTable.from_stream(binary, chunk_size=_CHUNK_SIZE)
        # When chunk_size is set, from_stream returns Iterator[QvdTable].
        chunks_iter: Iterator[QvdTable] = chunks
        yield from apply_inject(
            _rows_from_chunks(chunks_iter),
            inject=spec_ref.inject,
            context=context,
        )


def _rows_from_chunks(chunks: Iterator[Any]) -> Iterator[dict[str, Any]]:
    """For each QvdTable chunk, yield row dicts with unwrapped native values."""
    for chunk in chunks:
        columns = list(chunk.columns)
        for row in chunk.data:
            yield {col: _unwrap(cell) for col, cell in zip(columns, row, strict=False)}


def _unwrap(cell: Any) -> Any:
    """Pull the native Python value out of a pyqvd typed-value wrapper.

    pyqvd wraps each cell in IntegerValue / StringValue / DoubleValue / etc.
    `.calculation_value` returns the underlying primitive. `None` (missing
    cells) passes through unchanged.
    """
    if cell is None:
        return None
    return getattr(cell, "calculation_value", cell)


def _build_inject_context(file_item: Any) -> dict[str, Any]:
    file_name = (
        (file_item.get("file_name") if hasattr(file_item, "get") else None)
        or getattr(file_item, "file_name", None)
        or ""
    )
    file_url = (
        (file_item.get("file_url") if hasattr(file_item, "get") else None)
        or getattr(file_item, "file_url", None)
        or ""
    )
    mtime = (file_item.get("modification_date") if hasattr(file_item, "get") else None) or getattr(
        file_item, "modification_date", None
    )

    return {
        "basename": Path(file_name).name if file_name else "",
        "fullpath": file_url,
        "mtime": mtime,
    }
