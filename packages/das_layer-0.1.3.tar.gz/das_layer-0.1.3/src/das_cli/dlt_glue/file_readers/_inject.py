"""Apply opt-in row-level provenance injection. See ADR-0023."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any


def apply_inject(
    rows: Iterator[dict[str, Any]],
    *,
    inject: Mapping[str, str] | None,
    context: dict[str, Any],
) -> Iterator[dict[str, Any]]:
    """Inject provenance values into rows per the inject map.

    Args:
        rows: Source row iterator.
        inject: Map of column-name → source-key (e.g. {"source_file": "basename"}).
                When None or empty, rows pass through unchanged.
        context: Source-key → value (e.g. {"basename": "customers_2024-01.csv"}).
                 Keys not in context are silently skipped (defensive — the model
                 validator in `FilesystemSpecRef` already enforces the known set).
    """
    if not inject:
        yield from rows
        return

    # Pre-resolve which (column, value) pairs we'll inject so the loop body
    # doesn't redo lookups per row.
    pairs: list[tuple[str, Any]] = []
    for col, source_key in inject.items():
        if source_key in context:
            pairs.append((col, context[source_key]))

    for row in rows:
        for col, value in pairs:
            row[col] = value
        yield row
