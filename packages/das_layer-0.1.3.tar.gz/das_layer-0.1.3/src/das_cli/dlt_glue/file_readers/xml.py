"""XML file reader. See ADR-0022.

Streams matched elements via lxml.etree.iterparse with events=('end',) and a
resolved tag filter. After yielding each row, the matched element is cleared
and prior siblings are pruned — without that discipline, lxml accumulates the
full DOM and RSS grows unboundedly.

Xpath support is intentionally minimal for v1: only simple last-segment forms
are accepted (`//tag`, `/root/tag`, `//ns:tag`). Predicates and complex paths
raise NotImplementedError with a clear message.
"""

from __future__ import annotations

import re
from collections.abc import Iterator
from pathlib import Path
from typing import Any

from das_cli.contracts.filesystem_spec_ref import FilesystemSpecRef
from das_cli.dlt_glue.file_readers._inject import apply_inject

# Simple xpath form: optional leading // or /, optional path segments,
# final segment is a bare name or "prefix:name". No predicates, no wildcards.
_SIMPLE_XPATH = re.compile(r"^/?/?([\w-]+:)?[\w-]+(/[\w-]+(:[\w-]+)?)*$")


def read_rows(file_item: Any, spec_ref: FilesystemSpecRef) -> Iterator[dict[str, Any]]:
    """Yield one dict per element matched by `spec_ref.xpath`.

    Args:
        file_item: dlt FileItemDict (or stand-in with `open(mode="rb")`,
                   `file_name`, optional `modification_date`).
        spec_ref: Resource spec; `xpath` is required, `namespaces` is optional.

    Raises:
        ValueError: when xpath is missing or names an undeclared namespace prefix.
        NotImplementedError: when xpath uses predicates or other complex forms.
    """
    from lxml import etree

    if not spec_ref.xpath:
        raise ValueError("xml reader requires spec_ref.xpath")
    xpath = spec_ref.xpath
    namespaces = dict(spec_ref.namespaces or {})

    if not _SIMPLE_XPATH.match(xpath):
        raise NotImplementedError(
            f"xml reader: only simple xpath forms are supported in v1 "
            f"(`//tag`, `/root/tag`, `//ns:tag`). Got: {xpath!r}"
        )

    target_tag = _resolve_tag(xpath, namespaces)

    context = _build_inject_context(file_item)

    with file_item.open(mode="rb") as binary:
        events = etree.iterparse(binary, events=("end",), tag=target_tag)
        yield from apply_inject(
            _stream_rows(events),
            inject=spec_ref.inject,
            context=context,
        )


def _resolve_tag(xpath: str, namespaces: dict[str, str]) -> str:
    """Extract the target element tag from an xpath, resolving namespace prefix.

    Returns a Clark-notation tag (`{<uri>}localname`) when the xpath uses a
    namespace prefix, else just the local name.
    """
    # Last path segment is the target.
    last = xpath.split("/")[-1]
    if ":" in last:
        prefix, _, local = last.partition(":")
        if prefix not in namespaces:
            raise ValueError(
                f"xml reader: namespace prefix {prefix!r} is not declared in "
                f"spec_ref.namespaces (declared: {sorted(namespaces)})"
            )
        return f"{{{namespaces[prefix]}}}{local}"
    return last


def _stream_rows(events: Any) -> Iterator[dict[str, Any]]:
    """Iterate (event, element) pairs, yield a row per matched element,
    and clean up after each yield."""
    for _event, elem in events:
        yield _element_to_row(elem)
        # Memory discipline: clear this element and prune earlier siblings so
        # lxml can release the accumulated parent tree.
        elem.clear()
        prev = elem.getprevious()
        parent = elem.getparent()
        while prev is not None and parent is not None:
            del parent[0]
            prev = elem.getprevious()


def _element_to_row(elem: Any) -> dict[str, Any]:
    """Build a row dict from element attributes + direct-child {tag: child_text}.

    Namespace prefixes are stripped from both attribute and child tags so
    column names stay clean. Child elements without text are emitted as
    empty strings rather than None to match CSV semantics.
    """
    row: dict[str, Any] = {}
    for attr_name, attr_value in elem.attrib.items():
        row[_localname(attr_name)] = attr_value
    for child in elem:
        # An lxml element with no text is `None`; coerce to "" for CSV-like
        # consistency.
        row[_localname(child.tag)] = child.text if child.text is not None else ""
    return row


def _localname(tag: str) -> str:
    """Strip a Clark-notation namespace (`{uri}name`) down to its local name."""
    if tag.startswith("{"):
        return tag.split("}", 1)[1]
    return tag


def _build_inject_context(file_item: Any) -> dict[str, Any]:
    file_name = (
        (file_item.get("file_name") if hasattr(file_item, "get") else None)
        or getattr(file_item, "file_name", None)
        or ""
    )
    file_url = (
        (file_item.get("file_url") if hasattr(file_item, "get") else None)
        or getattr(file_item, "file_url", None)
        or ""
    )
    mtime = (file_item.get("modification_date") if hasattr(file_item, "get") else None) or getattr(
        file_item, "modification_date", None
    )

    return {
        "basename": Path(file_name).name if file_name else "",
        "fullpath": file_url,
        "mtime": mtime,
    }
