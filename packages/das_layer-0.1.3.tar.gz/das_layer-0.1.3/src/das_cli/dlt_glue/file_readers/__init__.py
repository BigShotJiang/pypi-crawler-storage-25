"""Format-specific readers for filesystem sources. See ADR-0022."""
