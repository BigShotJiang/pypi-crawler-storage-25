"""Translate das-cli's AzureCredentials into dlt's typed Azure credential classes
and into adlfs kwargs. See ADR-0020 Decision D.

dlt's typed credentials produce the right storage_options for both Python adlfs
(landing reads/writes) and the Rust object_store crate (Delta writer). das-cli
does not own storage_options plumbing — this module just produces the typed dlt
instances and the adlfs kwargs.
"""

from __future__ import annotations

import contextlib
import re
from collections.abc import Iterator
from typing import TYPE_CHECKING, Any, cast
from urllib.parse import urlparse

from dlt.common.configuration.specs import (
    AzureCredentials as DltAzureCredentials,
)
from dlt.common.configuration.specs import (
    AzureCredentialsWithoutDefaults as DltAzureCredentialsWithoutDefaults,
)
from dlt.common.configuration.specs import (
    AzureServicePrincipalCredentialsWithoutDefaults,
)

from das_cli.models.das_yaml import AzureDefaultAuth, AzureServicePrincipalAuth

if TYPE_CHECKING:
    import dlt

_STORAGE_SCOPE = "https://storage.azure.com/.default"


def _account_name_from_url(url: str) -> str:
    """Derive the Azure storage account name from an ABFS URL.

    OneLake (`abfss://<workspace>@onelake.dfs.fabric.microsoft.com/...`) → `onelake`.
    ADLS Gen2 (`abfss://<container>@<account>.dfs.core.windows.net/...`) → `<account>`.
    Both are the first dotted segment of the URL's host.
    """
    host = urlparse(url).hostname or ""
    return host.split(".", 1)[0]


def _account_host_from_url(url: str) -> str | None:
    """Return a non-default account host (full FQDN) for non-Azure-public endpoints.

    For standard ADLS Gen2 hosts (`<account>.dfs.core.windows.net` /
    `.blob.core.windows.net`) dlt builds the endpoint from
    `azure_storage_account_name` and returns to its defaults — no override
    needed.

    For OneLake / Fabric DFS hosts (`*.dfs.fabric.microsoft.com`), the host
    is rewritten to the **blob** equivalent (`*.blob.fabric.microsoft.com`).
    adlfs uses the Azure Blob API for `iterdir`/`glob`/`find`/`ls`; OneLake's
    DFS endpoint rejects those operations with `IncorrectEndpointError`, but
    its blob endpoint accepts them and serves the same underlying storage
    (see [fsspec/adlfs#486][1]). dlt's filesystem destination ignores the
    URL's host when `azure_account_host` is set explicitly.

    The deltalake-Rust writer is unaffected by this rewrite — it receives
    `use_fabric_endpoint=true` separately and parses the original `abfss://`
    URL host on its own (see `build_deltalake_storage_options`).

    [1]: https://github.com/fsspec/adlfs/issues/486
    """
    host = urlparse(url).hostname or ""
    if not host:
        return None
    standard_suffixes = (".dfs.core.windows.net", ".blob.core.windows.net")
    if any(host.endswith(s) for s in standard_suffixes):
        return None
    # Fabric DFS → Fabric Blob (regional or global).
    if host.endswith(".dfs.fabric.microsoft.com"):
        return host.replace(".dfs.fabric.microsoft.com", ".blob.fabric.microsoft.com", 1)
    return host


def acquire_storage_bearer_token(
    creds: AzureServicePrincipalAuth | AzureDefaultAuth,
) -> str:
    """Acquire a bearer token for the Azure Storage audience from configured auth.

    Used for OneLake / Fabric where adlfs's native SP-auth flow doesn't route
    against the Fabric endpoint correctly. Token TTL is typically ~1 hour; for
    longer-running pipelines this becomes a known limitation (refresh would
    require das-cli to participate in dlt's per-request credential plumbing,
    which is out of scope today).
    """
    from azure.identity import ClientSecretCredential, DefaultAzureCredential

    if isinstance(creds, AzureServicePrincipalAuth):
        credential: Any = ClientSecretCredential(
            tenant_id=creds.tenant_id,
            client_id=creds.client_id,
            client_secret=creds.client_secret,
        )
    else:
        credential = DefaultAzureCredential()
    return cast(str, credential.get_token(_STORAGE_SCOPE).token)


def is_fabric_url(url: str) -> bool:
    """True for OneLake / Fabric URLs (non-standard Azure host).

    Practically: any Azure URL whose host is NOT `<account>.{dfs,blob}.core.windows.net`.
    """
    return _account_host_from_url(url) is not None


def _build_sdk_credential(creds: AzureServicePrincipalAuth | AzureDefaultAuth) -> Any:
    """Construct an Azure SDK credential object (TokenCredential) for adlfs.

    SP → `ClientSecretCredential`; default → `DefaultAzureCredential` (the
    standard chain: env vars → managed identity → az CLI → developer tools).
    """
    from azure.identity import ClientSecretCredential, DefaultAzureCredential

    if isinstance(creds, AzureServicePrincipalAuth):
        return ClientSecretCredential(
            tenant_id=creds.tenant_id,
            client_id=creds.client_id,
            client_secret=creds.client_secret,
        )
    return DefaultAzureCredential()


# Placeholder string set as azure_storage_sas_token on Fabric-targeted typed
# credentials. Required because dlt's config-resolver treats a None-valued
# field as "unresolved" and triggers an env-var-fallback that masks our
# explicit configuration. adlfs ignores this value because the credential
# *object* in the destination's kwargs takes precedence (see adlfs.do_connect
# in `azure_credentials` source — `credential` is checked before `sas_token`).
_FABRIC_SAS_PLACEHOLDER = "fabric-credential-object-supplied-via-kwargs"


def build_dlt_azure_credentials(
    creds: AzureServicePrincipalAuth | AzureDefaultAuth,
    *,
    bucket_url: str,
) -> (
    DltAzureCredentials
    | DltAzureCredentialsWithoutDefaults
    | AzureServicePrincipalCredentialsWithoutDefaults
):
    """Build the dlt credentials object the filesystem destination expects.

    Three code paths:

    * **OneLake / Fabric** (`*.dfs.fabric.microsoft.com`):
      Returns an `AzureCredentialsWithoutDefaults` with `account_host` rewritten
      to the **blob** equivalent (`*.blob.fabric.microsoft.com`) and a
      placeholder `azure_storage_sas_token`. adlfs uses the blob API for
      `glob`/`find`/`ls` (OneLake's DFS endpoint rejects those — see
      [fsspec/adlfs#486][1]), and adlfs's `sas_token` is strictly a
      query-string SAS, not a JWT bearer. The real auth happens via the
      `credential` object supplied through dlt's `kwargs` passthrough (see
      `build_adlfs_kwargs`); the placeholder satisfies dlt's config-resolver
      so it doesn't fall back to env-var lookups.

    * **ADLS Gen2 with service-principal**: `AzureServicePrincipalCredentialsWithoutDefaults`.
      adlfs handles the Azure-AD token-exchange natively for standard endpoints.

    * **ADLS Gen2 with default auth**: `AzureCredentials` (DefaultAzureCredential
      chain). dlt's `to_object_store_rs_credentials()` produces the right
      `azure_storage_token` for the Rust deltalake writer automatically.

    `azure_storage_account_name` is always set on the returned object — dlt's
    config-resolver treats a None field as "unresolved" and triggers env-var
    fallback under `DESTINATION__FILESYSTEM__CREDENTIALS__*` naming.

    [1]: https://github.com/fsspec/adlfs/issues/486
    """
    account = _account_name_from_url(bucket_url)
    account_host = _account_host_from_url(bucket_url)

    if account_host is not None:
        # OneLake / Fabric. The credential object goes via build_adlfs_kwargs;
        # this typed-credentials object only exists to satisfy dlt's resolver.
        return DltAzureCredentialsWithoutDefaults(
            azure_storage_account_name=account,
            azure_account_host=account_host,
            azure_storage_sas_token=_FABRIC_SAS_PLACEHOLDER,
        )

    # Standard ADLS Gen2.
    if isinstance(creds, AzureServicePrincipalAuth):
        return AzureServicePrincipalCredentialsWithoutDefaults(
            azure_tenant_id=creds.tenant_id,
            azure_client_id=creds.client_id,
            azure_client_secret=creds.client_secret,
            azure_storage_account_name=account,
        )
    return DltAzureCredentials(azure_storage_account_name=account)


def build_adlfs_kwargs(
    creds: AzureServicePrincipalAuth | AzureDefaultAuth | None,
    bucket_url: str,
) -> dict[str, Any]:
    """Build kwargs for `dlt.destinations.filesystem(..., kwargs=...)`.

    For Fabric/OneLake URLs, returns `{"credential": <Azure SDK credential>}`.
    adlfs's `do_connect` checks `self.credential` before `self.sas_token`, so
    this object overrides the placeholder sas_token on the dlt typed credentials
    and produces correctly-authenticated Bearer-header requests.

    For standard ADLS Gen2 (or non-Azure URLs), returns `{}` — dlt's typed
    credentials handle adlfs configuration unaided.
    """
    if creds is None or not is_fabric_url(bucket_url):
        return {}
    return {"credential": _build_sdk_credential(creds)}


def build_deltalake_storage_options(
    bucket_url: str,
    creds: AzureServicePrincipalAuth | AzureDefaultAuth | None,
) -> dict[str, str] | None:
    """Build `deltalake_storage_options` for Fabric URLs.

    Returns None for standard ADLS Gen2 — dlt's typed-credentials auto-bridge
    is sufficient (ADR-0020 Decision D).

    For OneLake / Fabric, returns `{"use_fabric_endpoint": "true", "bearer_token": <token>}`.
    `use_fabric_endpoint` switches the Rust `object_store` (used by deltalake)
    to Fabric endpoint construction. `bearer_token` is acquired from the
    configured auth at construction time (TTL ~1h — long-running pipelines may
    hit token expiry, a known limitation).
    """
    if not is_fabric_url(bucket_url) or creds is None:
        return None
    token = acquire_storage_bearer_token(creds)
    return {"use_fabric_endpoint": "true", "bearer_token": token}


def _build_fabric_secret_sql(*, bucket_url: str, token: str) -> str:
    """Build the DuckDB CREATE OR REPLACE SECRET statement for OneLake.

    Issue #55: DuckDB's Azure auth is a third credential surface (separate from
    adlfs and Rust object_store). For Fabric URLs we issue this SQL inside
    `open_sql_client` to overwrite dlt's malformed CONNECTION_STRING secret
    with one that carries a real bearer token.

    SCOPE is the bucket URL verbatim (container included). DuckDB matches the
    longest URL prefix when resolving credentials. dlt's auto-emitted secret
    uses `split("@")[0]` → `abfss://<container>` (see dlt/destinations/impl/
    duckdb/sql_client.py:303), so our full-URL SCOPE is strictly longer and
    wins on specificity. Stripping the container — which an earlier draft did —
    would break prefix matching against `delta_scan('abfss://<container>@…')`
    URLs and DuckDB would fall back to dlt's malformed CONNECTION_STRING secret.

    Secret name follows dlt's sanitization (lowercase + strip non-letters)
    prefixed with `das_fabric_` to avoid collision with dlt's `<dataset>_*`
    secret. Both secrets can coexist; DuckDB picks the longest matching SCOPE.
    """
    if "'" in token:
        raise ValueError("bearer token contains a single quote; cannot inject into SQL literal")
    scope = bucket_url
    # Match dlt's sanitization convention exactly (sql_client.py:240): lower-case
    # then strip non-letters. Letting our convention drift would produce
    # unpredictable secret names.
    sanitized = re.sub(r"[^a-zA-Z]", "", scope.lower())
    secret_name = f"das_fabric_{sanitized}"
    return (
        f"CREATE OR REPLACE SECRET {secret_name} (\n"
        f"    TYPE AZURE,\n"
        f"    PROVIDER ACCESS_TOKEN,\n"
        f"    ACCESS_TOKEN '{token}',\n"
        f"    ACCOUNT_NAME 'onelake',\n"
        f"    SCOPE '{scope}'\n"
        f")"
    )


def _install_fabric_duckdb_secret(
    client: Any,
    *,
    bucket_url: str,
    azure: AzureServicePrincipalAuth | AzureDefaultAuth,
) -> None:
    """Issue CREATE OR REPLACE SECRET against the DuckDB connection dlt opened.

    Overwrites dlt's malformed CONNECTION_STRING secret (which dlt emits because
    das-cli passes AzureCredentialsWithoutDefaults with a placeholder SAS to
    satisfy dlt's config-resolver — see ADR-0020). The new secret carries a
    real bearer token and routes via ACCOUNT_NAME='onelake'.
    """
    token = acquire_storage_bearer_token(azure)
    sql = _build_fabric_secret_sql(bucket_url=bucket_url, token=token)
    client.execute_sql(sql)


@contextlib.contextmanager
def open_sql_client(
    pipeline: dlt.Pipeline,
    *,
    bucket_url: str | None,
    azure: AzureServicePrincipalAuth | AzureDefaultAuth | None,
) -> Iterator[Any]:
    """`pipeline.sql_client()` with Fabric-aware DuckDB auth. See issue #55.

    For Fabric URLs (and only for Fabric URLs), issues CREATE OR REPLACE
    SECRET TYPE AZURE PROVIDER ACCESS_TOKEN inside the opened sql_client
    context, before yielding. For non-Fabric URLs, non-Azure URLs, and
    destinations that don't pass a bucket_url (duckdb/ducklake), this is a
    pass-through wrapper around `pipeline.sql_client()`.

    Token TTL is ~1h (same shape as the deltalake_storage_options bearer_token
    constraint already documented in ADR-0020 Consequences). Long-running
    pipelines that hold a sql_client across that boundary are out of scope.
    """
    with pipeline.sql_client() as client:
        if bucket_url and azure and is_fabric_url(bucket_url):
            _install_fabric_duckdb_secret(client, bucket_url=bucket_url, azure=azure)
        yield client


def _adlfs_storage_options(
    creds: AzureServicePrincipalAuth | AzureDefaultAuth | None,
    bucket_url: str | None = None,
) -> dict[str, Any]:
    """Map AzureCredentials to adlfs's `AzureBlobFileSystem` kwargs.

    Used by `landing_fs` for direct fsspec construction (P2 reads). dlt's
    `to_adlfs_credentials()` does the equivalent translation internally for
    its own filesystem destination; we reproduce a minimal subset for the
    read path because dlt does not expose its filesystem reader for arbitrary
    use.

    For OneLake / Fabric URLs, returns an Azure SDK credential object plus
    explicit `account_name` / `account_host` (blob endpoint). adlfs uses the
    Blob API for `glob`/`find`/`ls`; the DFS endpoint rejects those.
    """
    if creds is None:
        return {}
    if bucket_url is not None and is_fabric_url(bucket_url):
        return {
            "account_name": _account_name_from_url(bucket_url),
            "account_host": _account_host_from_url(bucket_url),
            "credential": _build_sdk_credential(creds),
        }
    if isinstance(creds, AzureServicePrincipalAuth):
        return {
            "tenant_id": creds.tenant_id,
            "client_id": creds.client_id,
            "client_secret": creds.client_secret,
        }
    # Default chain — adlfs picks up env vars / az CLI / MI when anon=False.
    return {"anon": False}
