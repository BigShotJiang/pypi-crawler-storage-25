"""DuckDB / dlt dataset name resolution."""

from __future__ import annotations


def resolve_dataset_name(source_name: str, *, prefix: str | None) -> str:
    """Compute the dlt dataset name for a source.

    With a non-empty prefix: `<prefix>__<source>`. Otherwise just `<source>`.
    """
    if prefix:
        return f"{prefix}__{source_name}"
    return source_name
