"""Map ODCS contracts to dlt column hints. See ADR-0012, spec §5.4."""

from __future__ import annotations

import re
from decimal import Decimal
from typing import Any

from das_cli.contracts.odcs import LogicalType, OdcsContract, OdcsProperty

# See ADR-0012: schema_contract: freeze.
SCHEMA_CONTRACT_FREEZE: dict[str, str] = {
    "tables": "freeze",
    "columns": "freeze",
    "data_type": "freeze",
}


_LOGICAL_TO_DLT: dict[LogicalType, str] = {
    "string": "text",
    "integer": "bigint",
    "number": "double",
    "boolean": "bool",
    "date": "date",
    "timestamp": "timestamp",
    "object": "json",
    "array": "json",
}

_DECIMAL_RE = re.compile(r"^\s*decimal\(\s*(\d+)\s*,\s*(\d+)\s*\)\s*$", re.IGNORECASE)


def is_decimal_column(prop: OdcsProperty) -> bool:
    """Return True if `prop` is a fixed-precision decimal column.

    A column qualifies when its ODCS `logicalType` is `number` AND its
    `physicalType` matches `decimal(p,s)`. See ADR-0018 (Consequences).
    """
    if prop.logicalType != "number":
        return False
    pt = prop.physicalType
    if pt is None:
        return False
    return _DECIMAL_RE.match(pt) is not None


def coerce_decimal(value: object) -> Decimal | None:
    """Coerce a value into `Decimal`, preserving `None`.

    Accepts `str | int | float | Decimal | None`. Uses `str(value)` for the
    `float` case to avoid binary-precision artefacts (e.g. `Decimal(0.1)` yields
    `0.10000000000000000555...`). See ADR-0018 (Consequences).
    """
    if value is None:
        return None
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


def _column_hint(prop: OdcsProperty) -> dict[str, Any]:
    hint: dict[str, Any] = {
        "data_type": _LOGICAL_TO_DLT[prop.logicalType],
        "nullable": not prop.required,
    }
    if prop.primaryKey:
        hint["primary_key"] = True

    pt = prop.physicalType
    if pt and prop.logicalType == "number":
        m = _DECIMAL_RE.match(pt)
        if m:
            hint["data_type"] = "decimal"
            hint["precision"] = int(m.group(1))
            hint["scale"] = int(m.group(2))
        elif pt.lower() not in {"double", "float"}:
            raise ValueError(f"Column '{prop.name}': unrecognized physicalType '{pt}' for number")
    # bigint/varchar/etc. on string/integer are accepted but don't change mapping.

    return hint


def build_dlt_columns(contract: OdcsContract) -> dict[str, dict[str, Any]]:
    """Build dlt's `columns` dict from an ODCS contract.

    Always appends five metadata columns. See ADR-0004 (row_hash) and ADR-0013
    (load-date semantics):
      - _extracted_at / _extracted_on  (per-row, derived from landing _dlt_load_id)
      - _loaded_at    / _loaded_on     (per-load, derived from dlt.current.load_package_state)
      - _row_hash                       (per-row, change detection)
    """
    schema = contract.primary_schema
    cols: dict[str, dict[str, Any]] = {}
    for prop in schema.properties:
        cols[prop.name] = _column_hint(prop)
    cols["_extracted_at"] = {"data_type": "timestamp", "nullable": False}
    cols["_extracted_on"] = {"data_type": "date", "nullable": False}
    cols["_loaded_at"] = {"data_type": "timestamp", "nullable": False}
    cols["_loaded_on"] = {"data_type": "date", "nullable": False}
    cols["_row_hash"] = {"data_type": "text", "nullable": False}
    return cols


def primary_keys_for(contract: OdcsContract) -> list[str]:
    """Return the names of properties marked as primary keys (in declaration order)."""
    return [p.name for p in contract.primary_schema.properties if p.primaryKey]
