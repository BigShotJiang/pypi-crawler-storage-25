"""fsspec-backed landing reader. See ADR-0020 Decision C.

Replaces the pathlib + gzip.open / builtin open reader in extract.py / load.py.
Local paths flow through fsspec's LocalFileSystem; az:// / abfs:// / abfss://
URLs flow through adlfs's AzureBlobFileSystem. Same code path either way.
"""

from __future__ import annotations

import gzip
import json
from collections.abc import Iterator
from pathlib import Path
from typing import Any

import fsspec
from fsspec.spec import AbstractFileSystem

from das_cli.dlt_glue.azure_credentials import _adlfs_storage_options
from das_cli.models.das_yaml import (
    LandingConfig,
    is_azure_url,
    parse_azure_credentials,
)


def landing_fs(landing: LandingConfig) -> tuple[AbstractFileSystem, str]:
    """Return (filesystem, root_path) for reading the landing zone.

    For local paths: (LocalFileSystem, absolute_path).
    For Azure URLs: (AzureBlobFileSystem, the URL itself — adlfs paths include
    the container@host portion).
    """
    url = landing.bucket_url
    if is_azure_url(url):
        azure = parse_azure_credentials(landing.credentials, url)
        opts = _adlfs_storage_options(azure, bucket_url=url)
        fs, root = fsspec.core.url_to_fs(url, **opts)
        return fs, root
    fs = fsspec.filesystem("file")
    return fs, str(Path(url).expanduser().resolve())


def _resource_glob(root: str, source: str, resource: str) -> str:
    """Glob pattern matching all *.jsonl[.gz] under <root>/<source>/<resource>/."""
    return f"{root.rstrip('/')}/{source}/{resource}/**/*.jsonl*"


def iter_landing_records(
    landing: LandingConfig, *, source: str, resource: str
) -> Iterator[dict[str, Any]]:
    """Yield records from the JSONL landing files under <source>/<resource>/."""
    fs, root = landing_fs(landing)
    pattern = _resource_glob(root, source, resource)
    # fsspec's glob returns sorted paths from LocalFileSystem; for AzureBlobFileSystem
    # we sort explicitly so the iteration order is stable across backends.
    paths = sorted(fs.glob(pattern))
    for path in paths:
        is_gz = path.endswith(".gz")
        with fs.open(path, "rb") as raw:
            if is_gz:
                with gzip.open(raw, "rt", encoding="utf-8") as stream:
                    for line in stream:
                        line = line.strip()
                        if not line:
                            continue
                        yield json.loads(line)
            else:
                for raw_line in raw:
                    line = raw_line.decode("utf-8").strip()
                    if not line:
                        continue
                    yield json.loads(line)


def count_landing_records(landing: LandingConfig, *, source: str, resource: str) -> int:
    """Count newline-delimited records (skipping blanks) for one resource."""
    fs, root = landing_fs(landing)
    pattern = _resource_glob(root, source, resource)
    paths = fs.glob(pattern)
    if not paths:
        return 0
    total = 0
    for path in paths:
        is_gz = path.endswith(".gz")
        with fs.open(path, "rb") as raw:
            if is_gz:
                with gzip.open(raw, "rt", encoding="utf-8") as fh:
                    total += sum(1 for line in fh if line.strip())
            else:
                for line in raw:
                    if line.strip():
                        total += 1
    return total
