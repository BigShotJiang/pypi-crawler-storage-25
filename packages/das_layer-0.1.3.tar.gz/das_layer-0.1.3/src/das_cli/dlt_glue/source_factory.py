"""Build dlt resources for P1 from `_source.yml` + ODCS contracts.

See ADR-0003: P1 blob pattern.
See ADR-0014: das.endpoint for HTTP source resolution.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any

import dlt
from dlt.sources.helpers.rest_client import RESTClient  # type: ignore[attr-defined]

from das_cli.contracts.custom_properties import get_das_value
from das_cli.contracts.das_endpoint import (
    DasEndpoint,
    build_paginator,
    resolve_endpoint,
)
from das_cli.contracts.loader import LoadedContract
from das_cli.models.source_yml import SourceConfig
from das_cli.progress import ProgressHandle

_HTTP_SOURCE_TYPES = {"odata", "openapi", "rest"}


class _SqlResourceList(list[Any]):
    """A list with a SQLAlchemy engine attached for caller-side disposal.

    See ADR-0018: SQL sources construct a SQLAlchemy ``Engine`` whose lifecycle
    dlt does not own. We stash it on the resources list so ``run_extract`` can
    dispose it after the pipeline run completes.
    """

    _das_sql_engine: Any = None


class UnknownSourceTypeError(ValueError):
    """Raised when `_source.yml.type` doesn't have a builder."""


def _auth_headers(scfg: SourceConfig) -> dict[str, str]:
    extras = scfg.auth.model_extra or {}
    if scfg.auth.type == "bearer":
        token = extras.get("token", "")
        return {"Authorization": f"Bearer {token}"} if token else {}
    if scfg.auth.type == "api_key":
        key = extras.get("key", "")
        header = extras.get("header", "X-API-Key")
        return {header: key} if key else {}
    return {}


def _limit_gen(gen: Iterator[dict[str, Any]], n: int) -> Iterator[dict[str, Any]]:
    """Yield at most `n` items from `gen`."""
    for i, item in enumerate(gen):
        if i >= n:
            return
        yield item


def _data_selector(response_path: str | None) -> str | None:
    """Convert `das.endpoint.response_path` to dlt's `data_selector`.

    `null` → `None` (bare array). `$.<key>` → `<key>`.
    """
    if response_path is None:
        return None
    return response_path[2:]  # strip leading "$."


def _make_http_resource(
    *,
    base_url: str,
    endpoint: DasEndpoint,
    resource_name: str,
    cursor_field: str | None,
    auth_headers: dict[str, str],
    limit: int | None = None,
    progress_handle: ProgressHandle | None = None,
) -> Any:
    @dlt.resource(  # type: ignore[misc,call-overload,untyped-decorator]
        name=resource_name,
        write_disposition="append",
        columns={"_data": {"data_type": "json", "nullable": False}},
        primary_key=None,
    )
    def _gen() -> Iterator[dict[str, Any]]:
        # See ADR-0003: blob pattern.
        merged_headers = {**auth_headers, **endpoint.headers}
        client = RESTClient(base_url=base_url, headers=merged_headers)
        paginator = build_paginator(endpoint.pagination)
        data_selector = _data_selector(endpoint.response_path)

        def _raw_items() -> Iterator[dict[str, Any]]:
            for page in client.paginate(
                path=endpoint.path,
                params=dict(endpoint.query_params) or None,
                paginator=paginator,
                data_selector=data_selector,
            ):
                for item in page:
                    yield {"_data": item}

        source = _raw_items()
        if limit is not None:
            source = _limit_gen(source, limit)
        if progress_handle is not None:
            source = progress_handle.wrap(resource_name, source)
        yield from source

    return _gen


def _build_http_resources(
    scfg: SourceConfig,
    contracts: list[LoadedContract],
    *,
    source_name: str,
    limit: int | None = None,
    progress_handle: ProgressHandle | None = None,
) -> list[Any]:
    base_url = scfg.endpoint.rstrip("/")
    auth_headers = _auth_headers(scfg)
    out: list[Any] = []
    for contract in contracts:
        endpoint = resolve_endpoint(contract, source_type=scfg.type)
        resource = _make_http_resource(
            base_url=base_url,
            endpoint=endpoint,
            resource_name=contract.resource_name,
            cursor_field=get_das_value(contract.contract.custom_properties, "das.cursor"),
            auth_headers=auth_headers,
            limit=limit,
            progress_handle=progress_handle,
        )
        out.append(resource)
    return out


def _make_sql_resource(
    *,
    engine: Any,
    resource_name: str,
    table: str,
    schema: str | None,
    cursor: str | None,
    limit: int | None,
    progress_handle: ProgressHandle | None,
) -> Any:
    from dlt.sources.sql_database import sql_table  # type: ignore[attr-defined]

    @dlt.resource(  # type: ignore[misc,call-overload,untyped-decorator]
        name=resource_name,
        write_disposition="append",
        columns={"_data": {"data_type": "json", "nullable": False}},
        primary_key=None,
    )
    def _gen() -> Iterator[dict[str, Any]]:
        kwargs: dict[str, Any] = {
            "credentials": engine,
            "table": table,
            "chunk_size": 10_000,
        }
        if schema is not None:
            kwargs["schema"] = schema
        if cursor is not None:
            kwargs["incremental"] = dlt.sources.incremental(cursor)  # type: ignore[attr-defined]

        base = sql_table(**kwargs)

        def _wrap_blobs() -> Iterator[dict[str, Any]]:
            for row in base:
                yield {"_data": row}

        source: Iterator[dict[str, Any]] = _wrap_blobs()
        if limit is not None:
            source = _limit_gen(source, limit)
        if progress_handle is not None:
            source = progress_handle.wrap(resource_name, source)
        yield from source

    return _gen


def _build_sql_resources(
    scfg: SourceConfig,
    contracts: list[LoadedContract],
    *,
    source_name: str,
    limit: int | None = None,
    progress_handle: ProgressHandle | None = None,
) -> list[Any]:
    """Build dlt resources for a SQL source. See ADR-0018.

    The returned list carries the SQLAlchemy engine on `_das_sql_engine`
    so the caller (run_extract) can dispose it after the pipeline run.
    """
    from sqlalchemy import create_engine

    engine = create_engine(scfg.endpoint)
    out: _SqlResourceList = _SqlResourceList()
    for contract in contracts:
        spec_ref = get_das_value(contract.contract.custom_properties, "das.spec_ref") or {}
        # `das.spec_ref` is populated by bootstrap_sql_contracts; for hand-written
        # contracts that omit it, fall back to physical_name and dlt's default schema.
        schema: str | None = spec_ref.get("schema") if isinstance(spec_ref, dict) else None
        spec_table = spec_ref.get("table") if isinstance(spec_ref, dict) else None
        if isinstance(spec_table, str) and spec_table:
            table = spec_table
        else:
            physical_name = contract.contract.primary_schema.physicalName
            table = physical_name if physical_name is not None else contract.resource_name
        cursor = get_das_value(contract.contract.custom_properties, "das.cursor")

        out.append(
            _make_sql_resource(
                engine=engine,
                resource_name=contract.resource_name,
                table=table,
                schema=schema,
                cursor=cursor,
                limit=limit,
                progress_handle=progress_handle,
            )
        )
    out._das_sql_engine = engine
    return out


def _select_file_reader(format_name: str) -> Any:
    """Return the `read_rows` callable for a given format. See ADR-0022."""
    if format_name == "csv":
        from das_cli.dlt_glue.file_readers import csv as csv_reader

        return csv_reader.read_rows
    if format_name == "excel":
        from das_cli.dlt_glue.file_readers import excel as excel_reader

        return excel_reader.read_rows
    if format_name == "xml":
        from das_cli.dlt_glue.file_readers import xml as xml_reader

        return xml_reader.read_rows
    if format_name == "qvd":
        from das_cli.dlt_glue.file_readers import qvd as qvd_reader

        return qvd_reader.read_rows
    raise ValueError(
        f"No file reader for format '{format_name}'. " "Supported: csv, excel, xml, qvd."
    )


def _make_filesystem_resource(
    *,
    endpoint: str,
    spec_ref: Any,  # FilesystemSpecRef; not annotated to avoid circular import surface
    resource_name: str,
    limit: int | None,
    progress_handle: ProgressHandle | None,
) -> Any:
    """Build a single dlt resource for one filesystem-typed contract.

    Composes dlt's filesystem source (file enumeration + fsspec auth +
    incremental mtime tracking) with a per-format reader transformer.
    See ADR-0022.
    """
    from dlt.sources.filesystem import filesystem  # type: ignore[attr-defined]

    read_rows = _select_file_reader(spec_ref.format)

    files_resource = filesystem(bucket_url=endpoint, file_glob=spec_ref.path)

    @dlt.transformer(  # type: ignore[misc,call-overload,untyped-decorator]
        data_from=files_resource,
        name=resource_name,
        write_disposition="append",
        columns={"_data": {"data_type": "json", "nullable": False}},
        primary_key=None,
    )
    def _parse(items: Any) -> Iterator[dict[str, Any]]:
        # dlt passes a batch of FileItemDict objects; iterate over each file.
        # See ADR-0003: blob pattern.
        def _all_rows() -> Iterator[dict[str, Any]]:
            for file_item in items:
                yield from read_rows(file_item, spec_ref)

        rows: Iterator[dict[str, Any]] = _all_rows()
        if limit is not None:
            rows = _limit_gen(rows, limit)
        if progress_handle is not None:
            rows = progress_handle.wrap(resource_name, rows)
        for row in rows:
            yield {"_data": row}

    return _parse


def _build_filesystem_resources(
    scfg: SourceConfig,
    contracts: list[LoadedContract],
    *,
    source_name: str,
    limit: int | None = None,
    progress_handle: ProgressHandle | None = None,
) -> list[Any]:
    """Build dlt resources for a filesystem source. See ADR-0022."""
    from das_cli.contracts.filesystem_spec_ref import FilesystemSpecRef

    endpoint = scfg.endpoint.rstrip("/")
    out: list[Any] = []
    for contract in contracts:
        raw_spec_ref = get_das_value(contract.contract.custom_properties, "das.spec_ref")
        if raw_spec_ref is None:
            raise ValueError(
                f"contract '{contract.resource_name}' missing das.spec_ref "
                f"(required for type=filesystem)"
            )
        # Validate the format early so unknown formats raise ValueError with a
        # clear message before Pydantic's Literal check fires.
        if isinstance(raw_spec_ref, dict):
            _select_file_reader(raw_spec_ref.get("format", ""))
        spec_ref = FilesystemSpecRef.model_validate(raw_spec_ref)
        out.append(
            _make_filesystem_resource(
                endpoint=endpoint,
                spec_ref=spec_ref,
                resource_name=contract.resource_name,
                limit=limit,
                progress_handle=progress_handle,
            )
        )
    return out


def build_extract_resources(
    scfg: SourceConfig,
    contracts: list[LoadedContract],
    *,
    source_name: str,
    limit: int | None = None,
    progress_handle: ProgressHandle | None = None,
) -> list[Any]:
    """Build a list of dlt resources for P1 extraction."""
    if scfg.type in _HTTP_SOURCE_TYPES:
        return _build_http_resources(
            scfg,
            contracts,
            source_name=source_name,
            limit=limit,
            progress_handle=progress_handle,
        )
    if scfg.type == "sql":
        # See ADR-0018.
        return _build_sql_resources(
            scfg,
            contracts,
            source_name=source_name,
            limit=limit,
            progress_handle=progress_handle,
        )
    if scfg.type == "filesystem":
        # See ADR-0022.
        return _build_filesystem_resources(
            scfg,
            contracts,
            source_name=source_name,
            limit=limit,
            progress_handle=progress_handle,
        )
    raise UnknownSourceTypeError(f"No P1 builder for source type '{scfg.type}'")
