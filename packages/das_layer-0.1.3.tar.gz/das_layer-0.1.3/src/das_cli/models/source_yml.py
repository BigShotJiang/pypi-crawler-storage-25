"""SourceConfig model — represents the contents of `_source.yml`."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

SourceType = Literal["odata", "openapi", "rest", "sql", "filesystem"]
AuthType = Literal["none", "bearer", "basic", "api_key"]
SpecKind = Literal["odata", "openapi", "sql", "filesystem", "none"]


class SpecConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")
    kind: SpecKind
    metadata_url: str | None = None
    swagger_url: str | None = None
    # SQL-only fields. See ADR-0018.
    schemas: list[str] | None = None
    tables: list[str] | None = None
    include_views: bool = False

    @model_validator(mode="after")
    def _enforce_kind_field_compatibility(self) -> SpecConfig:
        sql_only = ("schemas", "tables", "include_views")
        http_only = ("metadata_url", "swagger_url")
        if self.kind == "sql":
            for field in http_only:
                if getattr(self, field) is not None:
                    raise ValueError(f"`spec.{field}` is not allowed when `spec.kind == 'sql'`")
        else:
            for field in sql_only:
                value = getattr(self, field)
                # schemas/tables default to None; include_views defaults to False.
                # Both shapes mean "unset"; anything else means "set".
                if value not in (None, False):
                    raise ValueError(
                        f"`spec.{field}` is only allowed when `spec.kind == 'sql'` "
                        f"(got kind='{self.kind}')"
                    )
        return self


class AuthConfig(BaseModel):
    model_config = ConfigDict(extra="allow")  # auth shape varies; allow extras
    type: AuthType = "none"


class OwnershipConfig(BaseModel):
    model_config = ConfigDict(extra="allow")
    team: str | None = None


class SourceConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")
    type: SourceType
    endpoint: str
    spec: SpecConfig = Field(default_factory=lambda: SpecConfig(kind="none"))
    auth: AuthConfig = Field(default_factory=AuthConfig)
    ownership: OwnershipConfig = Field(default_factory=OwnershipConfig)
    # Future: schedule, transport overrides, etc.
