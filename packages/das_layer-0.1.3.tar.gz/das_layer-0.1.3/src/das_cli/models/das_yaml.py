"""DasConfig model — represents the contents of `das.yaml`."""

from __future__ import annotations

from typing import Annotated, Any, Literal

from pydantic import BaseModel, ConfigDict, Field, TypeAdapter, field_validator

ChangeDetection = Literal["row_hash", "none"]
WriteDisposition = Literal["append", "merge", "replace"]
SchemaContractMode = Literal["evolve", "freeze", "discard_value", "discard_row"]


class TargetConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")
    destination: str  # any dlt destination name
    credentials: dict[str, Any] = Field(default_factory=dict)


class LandingConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")
    bucket_url: str
    credentials: dict[str, Any] = Field(default_factory=dict)


class ContractsConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")
    root: str = "./contracts"


class DatasetConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")
    prefix: str | None = None

    @field_validator("prefix", mode="before")
    @classmethod
    def _normalize_none(cls, v: object) -> object:
        """Treat case-insensitive "", "none", "null" (with whitespace) as no-prefix."""
        if isinstance(v, str) and v.strip().lower() in {"", "none", "null"}:
            return None
        return v


class SchemaContractConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")
    tables: SchemaContractMode = "evolve"
    columns: SchemaContractMode = "freeze"
    data_type: SchemaContractMode = "freeze"


class DefaultsConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")
    write_disposition: WriteDisposition = "append"
    change_detection: ChangeDetection = "row_hash"
    schema_contract: SchemaContractConfig = Field(default_factory=SchemaContractConfig)


class DasConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")
    target: TargetConfig
    landing: LandingConfig
    contracts: ContractsConfig = Field(default_factory=ContractsConfig)
    dataset: DatasetConfig = Field(default_factory=DatasetConfig)
    defaults: DefaultsConfig = Field(default_factory=DefaultsConfig)


class AzureServicePrincipalAuth(BaseModel):
    """Explicit Azure AD service-principal credentials. See ADR-0020 Decision B."""

    model_config = ConfigDict(extra="forbid")
    auth: Literal["service_principal"]
    tenant_id: str
    client_id: str
    client_secret: str


class AzureDefaultAuth(BaseModel):
    """DefaultAzureCredential chain (env vars / managed identity / az CLI / dev tools).
    See ADR-0020 Decision B."""

    model_config = ConfigDict(extra="forbid")
    auth: Literal["default"]


AzureCredentials = Annotated[
    AzureServicePrincipalAuth | AzureDefaultAuth,
    Field(discriminator="auth"),
]


_AZURE_CREDENTIALS_ADAPTER: TypeAdapter[AzureCredentials] = TypeAdapter(AzureCredentials)

_AZURE_SCHEMES: tuple[str, ...] = ("az://", "abfs://", "abfss://")


def is_azure_url(url: str) -> bool:
    """True for Azure Blob File System URLs (ADLS Gen2 + OneLake). See ADR-0020 Decision A."""
    return url.startswith(_AZURE_SCHEMES)


def parse_azure_credentials(
    creds: dict[str, Any], bucket_url: str
) -> AzureServicePrincipalAuth | AzureDefaultAuth | None:
    """Return a typed AzureCredentials when bucket_url is Azure, else None.

    Empty creds on an Azure URL raises ValidationError (discriminator missing).
    See ADR-0020 Decision B: auth is required for Azure URLs.

    Storage-routing keys (bucket_url) are stripped before validation so that
    callers can pass the full credentials dict from either LandingConfig or
    TargetConfig without requiring callers to filter first."""
    if not is_azure_url(bucket_url):
        return None
    # Strip storage-routing key(s) before validating the Azure auth union;
    # the auth models have extra="forbid" so unexpected keys raise.
    auth_creds = {k: v for k, v in creds.items() if k != "bucket_url"}
    # Use a TypeAdapter so the discriminated union validates from a plain dict.
    return _AZURE_CREDENTIALS_ADAPTER.validate_python(auth_creds)
