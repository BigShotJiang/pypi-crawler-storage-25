# See ADR-0026: dynamic version via hatch-vcs + importlib.metadata.
from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("das-layer")
except PackageNotFoundError:
    __version__ = "0.0.0+unknown"
