"""Contract models, loaders, validators, and diff."""
