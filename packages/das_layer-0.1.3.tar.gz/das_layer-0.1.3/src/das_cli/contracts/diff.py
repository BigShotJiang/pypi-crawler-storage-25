"""Diff loaded contracts vs. a fresh bootstrap output."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from das_cli.bootstrap.odata import bootstrap_odata_contracts
from das_cli.contracts.loader import LoadedContract

DiffKind = Literal["added", "removed", "changed"]


@dataclass(frozen=True)
class DiffItem:
    kind: DiffKind
    resource: str
    column: str | None
    message: str


def _index(loaded: list[LoadedContract]) -> dict[str, LoadedContract]:
    return {c.resource_name: c for c in loaded}


def _diff_resource(local: LoadedContract, fresh: LoadedContract) -> list[DiffItem]:
    local_props = {p.name: p for p in local.contract.primary_schema.properties}
    fresh_props = {p.name: p for p in fresh.contract.primary_schema.properties}

    out: list[DiffItem] = []
    for name in fresh_props.keys() - local_props.keys():
        out.append(
            DiffItem(
                kind="added",
                resource=local.resource_name,
                column=name,
                message=f"new column in source: {name}",
            )
        )
    for name in local_props.keys() - fresh_props.keys():
        out.append(
            DiffItem(
                kind="removed",
                resource=local.resource_name,
                column=name,
                message=f"column removed from source: {name}",
            )
        )
    for name in local_props.keys() & fresh_props.keys():
        lp, fp = local_props[name], fresh_props[name]
        if lp.logicalType != fp.logicalType:
            out.append(
                DiffItem(
                    kind="changed",
                    resource=local.resource_name,
                    column=name,
                    message=f"{name} logicalType: {lp.logicalType} → {fp.logicalType}",
                )
            )
        if lp.required != fp.required:
            out.append(
                DiffItem(
                    kind="changed",
                    resource=local.resource_name,
                    column=name,
                    message=f"{name} required: {lp.required} → {fp.required}",
                )
            )
    return out


def diff_against_odata(local: list[LoadedContract], metadata_xml: str) -> list[DiffItem]:
    fresh = bootstrap_odata_contracts(
        metadata_xml,
        source_name=(local[0].contract.id.split(".")[0] if local else "unknown"),
    )
    li, fi = _index(local), _index(fresh)
    out: list[DiffItem] = []
    for name in fi.keys() - li.keys():
        out.append(
            DiffItem(
                kind="added",
                resource=name,
                column=None,
                message=f"new resource in source: {name}",
            )
        )
    for name in li.keys() - fi.keys():
        out.append(
            DiffItem(
                kind="removed",
                resource=name,
                column=None,
                message=f"resource removed from source: {name}",
            )
        )
    for name in li.keys() & fi.keys():
        out.extend(_diff_resource(li[name], fi[name]))
    return out
