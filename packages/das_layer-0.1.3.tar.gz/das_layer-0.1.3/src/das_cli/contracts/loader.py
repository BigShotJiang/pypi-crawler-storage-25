"""Discover and load contracts from `contracts/<source>/*.odcs.yaml`."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import yaml

from das_cli.contracts.odcs import OdcsContract
from das_cli.jinja_env import render_obj


@dataclass(frozen=True)
class LoadedContract:
    """An ODCS contract bound to its filesystem location and resource name."""

    path: Path
    resource_name: str
    contract: OdcsContract


@dataclass(frozen=True)
class SourceDir:
    """A discovered source directory: name + path."""

    name: str
    path: Path


def load_contract(path: Path | str) -> LoadedContract:
    p = Path(path)
    with p.open("r") as f:
        raw = yaml.safe_load(f)
    rendered = render_obj(raw, origin=str(p))
    contract = OdcsContract.model_validate(rendered)
    return LoadedContract(
        path=p,
        resource_name=p.name.replace(".odcs.yaml", "").replace(".odcs.yml", ""),
        contract=contract,
    )


def load_source_contracts(source_dir: Path | str) -> list[LoadedContract]:
    """Load every `*.odcs.yaml` file in `source_dir`. Skips `_*.yml`."""
    d = Path(source_dir)
    out: list[LoadedContract] = []
    for entry in sorted(d.iterdir()):
        if entry.is_file() and entry.name.endswith((".odcs.yaml", ".odcs.yml")):
            if entry.name.startswith("_"):
                continue
            out.append(load_contract(entry))
    return out


def discover_sources(contracts_root: Path | str) -> list[SourceDir]:
    """List subdirectories of `contracts_root` that contain a `_source.yml`."""
    root = Path(contracts_root)
    out: list[SourceDir] = []
    if not root.is_dir():
        return out
    for entry in sorted(root.iterdir()):
        if entry.is_dir() and (entry / "_source.yml").is_file():
            out.append(SourceDir(name=entry.name, path=entry))
    return out
