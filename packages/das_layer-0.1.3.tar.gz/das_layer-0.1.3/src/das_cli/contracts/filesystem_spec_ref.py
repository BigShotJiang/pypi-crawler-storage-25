"""Pydantic model for `das.spec_ref` on filesystem sources. See ADR-0022 and ADR-0023."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

FileFormat = Literal["csv", "excel", "xml", "qvd"]
InjectSource = Literal["basename", "fullpath", "mtime", "sheet"]


class FilesystemSpecRef(BaseModel):
    """Per-resource filesystem spec embedded under `das.spec_ref` in an ODCS contract.

    The full model accepts options for all four formats (csv, excel, xml, qvd),
    even though Plan #1 only ships the csv reader. Format-specific required
    fields (`sheet` for excel, `xpath` for xml) are validated here so contracts
    that target later formats fail fast.
    """

    model_config = ConfigDict(extra="forbid")

    kind: Literal["filesystem"]
    format: FileFormat
    path: str = Field(..., min_length=1)

    # csv / xml options.
    delimiter: str | None = None
    encoding: str | None = None

    # excel options.
    sheet: str | None = None
    header_row: int | None = None

    # xml options.
    xpath: str | None = None
    namespaces: dict[str, str] | None = None

    # Opt-in row-level provenance (ADR-0023). Keys are user-chosen column names;
    # values name the source of the injected value.
    inject: dict[str, InjectSource] | None = None
