"""Validation for `das.yaml`, `_source.yml`, and ODCS contracts."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from pathlib import Path

from pydantic import ValidationError

from das_cli.config import load_das_config, load_source_config
from das_cli.contracts.custom_properties import (
    KNOWN_CONTRACT_KEYS,
    KNOWN_PROPERTY_KEYS,
    UnknownDasKeyError,
    extract_das_props,
)
from das_cli.contracts.loader import (
    LoadedContract,
    load_source_contracts,
)


@dataclass(frozen=True)
class ValidationIssue:
    path: str
    message: str


def validate_workspace(das_yaml_path: Path | str) -> list[ValidationIssue]:
    """Validate the workspace anchored at `das_yaml_path`. Returns issue list."""
    issues: list[ValidationIssue] = []
    das_path = Path(das_yaml_path)

    if not das_path.is_file():
        return [ValidationIssue(path=str(das_path), message=f"das.yaml not found at {das_path}")]

    try:
        cfg = load_das_config(das_path)
    except (ValidationError, ValueError) as e:
        return [ValidationIssue(path=str(das_path), message=f"das.yaml invalid: {e}")]

    contracts_root = (das_path.parent / cfg.contracts.root).resolve()

    # Scan all subdirectories in contracts_root.
    all_source_dirs: list[Path] = []
    if contracts_root.is_dir():
        for entry in sorted(contracts_root.iterdir()):
            if entry.is_dir():
                all_source_dirs.append(entry)

    if not all_source_dirs:
        return issues  # nothing to validate yet

    for source_path in all_source_dirs:
        source_yml = source_path / "_source.yml"
        if not source_yml.is_file():
            issues.append(
                ValidationIssue(
                    path=str(source_path),
                    message=f"missing _source.yml in {source_path}",
                )
            )
            continue

        source_type: str | None = None
        try:
            scfg = load_source_config(source_yml)
            source_type = scfg.type
        except (ValidationError, ValueError) as e:
            issues.append(
                ValidationIssue(path=str(source_yml), message=f"_source.yml invalid: {e}")
            )

        try:
            contracts = load_source_contracts(source_path)
        except (ValidationError, ValueError) as e:
            issues.append(
                ValidationIssue(path=str(source_path), message=f"contract load failed: {e}")
            )
            continue

        for c in contracts:
            issues.extend(
                _validate_contract(
                    c,
                    cfg_change_detection=cfg.defaults.change_detection,
                    source_type=source_type,
                )
            )

    return issues


def _validate_contract(
    c: LoadedContract,
    *,
    cfg_change_detection: str,
    source_type: str | None = None,
) -> list[ValidationIssue]:
    out: list[ValidationIssue] = []
    schema = c.contract.primary_schema
    column_names = [p.name for p in schema.properties]
    physical_names = [p.physicalName for p in schema.properties if p.physicalName]

    # Duplicate detection.
    for name, count in Counter(column_names).items():
        if count > 1:
            out.append(ValidationIssue(path=str(c.path), message=f"duplicate column name '{name}'"))
    for name, count in Counter(physical_names).items():
        if count > 1:
            out.append(
                ValidationIssue(path=str(c.path), message=f"duplicate physicalName '{name}'")
            )

    # Validate das.* keys at contract level.
    try:
        das_props = extract_das_props(c.contract.custom_properties, allowed=KNOWN_CONTRACT_KEYS)
    except UnknownDasKeyError as e:
        out.append(ValidationIssue(path=str(c.path), message=str(e)))
        das_props = {}

    # Validate das.* keys at column level.
    for prop in schema.properties:
        try:
            extract_das_props(prop.custom_properties, allowed=KNOWN_PROPERTY_KEYS)
        except UnknownDasKeyError as e:
            out.append(ValidationIssue(path=str(c.path), message=f"property '{prop.name}': {e}"))

    # das.cursor names existing column.
    cursor = das_props.get("das.cursor")
    if cursor is not None and cursor not in column_names:
        out.append(
            ValidationIssue(
                path=str(c.path),
                message=f"das.cursor names unknown column '{cursor}'",
            )
        )

    # das.hash_exclude entries name existing columns.
    hash_exclude = das_props.get("das.hash_exclude") or []
    for col in hash_exclude:
        if col not in column_names:
            out.append(
                ValidationIssue(
                    path=str(c.path),
                    message=f"das.hash_exclude names unknown column '{col}'",
                )
            )

    # row_hash change detection requires at least one primary key.
    effective_cd = das_props.get("das.change_detection", cfg_change_detection)
    if effective_cd == "row_hash":
        pks = [p.name for p in schema.properties if p.primaryKey]
        if not pks:
            out.append(
                ValidationIssue(
                    path=str(c.path),
                    message="change_detection=row_hash requires at least one primary key",
                )
            )

    # das.endpoint shape + source-type compatibility (see ADR-0014).
    raw_endpoint = das_props.get("das.endpoint")
    if raw_endpoint is not None:
        from das_cli.contracts.das_endpoint import DasEndpoint

        try:
            DasEndpoint.model_validate(raw_endpoint)
        except ValidationError as e:
            out.append(ValidationIssue(path=str(c.path), message=f"das.endpoint invalid: {e}"))
        if source_type in {"sql", "filesystem"}:
            out.append(
                ValidationIssue(
                    path=str(c.path),
                    message=(
                        f"das.endpoint is not allowed on source type "
                        f"'{source_type}' (HTTP-only field)"
                    ),
                )
            )

    # Filesystem-typed sources: validate das.spec_ref shape and required fields.
    # See ADR-0022 and ADR-0023.
    if source_type == "filesystem":
        raw_spec_ref = das_props.get("das.spec_ref")
        if raw_spec_ref is None:
            out.append(
                ValidationIssue(
                    path=str(c.path),
                    message="das.spec_ref is required for type=filesystem",
                )
            )
        else:
            from das_cli.contracts.filesystem_spec_ref import FilesystemSpecRef

            try:
                spec_ref = FilesystemSpecRef.model_validate(raw_spec_ref)
            except ValidationError as e:
                out.append(
                    ValidationIssue(
                        path=str(c.path),
                        message=f"das.spec_ref invalid for filesystem source: {e}",
                    )
                )
            else:
                if spec_ref.format == "excel" and not spec_ref.sheet:
                    out.append(
                        ValidationIssue(
                            path=str(c.path),
                            message="sheet is required for format=excel",
                        )
                    )
                if spec_ref.format == "xml" and not spec_ref.xpath:
                    out.append(
                        ValidationIssue(
                            path=str(c.path),
                            message="xpath is required for format=xml",
                        )
                    )
                # inject keys must reference declared columns.
                for col in spec_ref.inject or {}:
                    if col not in column_names:
                        out.append(
                            ValidationIssue(
                                path=str(c.path),
                                message=(
                                    f"inject column '{col}' is not in the schema "
                                    f"(declare it in properties or remove from inject)"
                                ),
                            )
                        )

    return out
