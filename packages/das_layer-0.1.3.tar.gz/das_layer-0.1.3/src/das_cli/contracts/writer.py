"""Serialize a LoadedContract back to a YAML file."""

from __future__ import annotations

from pathlib import Path

import yaml

from das_cli.contracts.loader import LoadedContract


def _to_dict(contract_obj: object) -> dict[str, object]:
    """Serialize via pydantic, using ODCS aliases (schema, customProperties)."""
    result: dict[str, object] = contract_obj.model_dump(by_alias=True, exclude_none=True)  # type: ignore[attr-defined]
    return result


def write_contract(loaded: LoadedContract, path: Path | str) -> None:
    """Write `loaded.contract` as ODCS YAML to `path`. Block style. Aliased keys."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    payload = _to_dict(loaded.contract)
    with p.open("w") as f:
        yaml.safe_dump(
            payload,
            f,
            sort_keys=False,
            default_flow_style=False,
            allow_unicode=True,
            indent=2,
        )
