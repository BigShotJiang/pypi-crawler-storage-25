"""Helpers for `das.*` keys inside ODCS customProperties."""

from __future__ import annotations

from typing import Any

from das_cli.contracts.odcs import CustomProperty

# See ADR-0011: das.* namespace.
KNOWN_CONTRACT_KEYS: frozenset[str] = frozenset(
    {
        "das.spec_ref",
        "das.cursor",
        "das.write_disposition",
        "das.change_detection",
        "das.hash_exclude",
        "das.bootstrapped_from",
        "das.endpoint",
    }
)

KNOWN_PROPERTY_KEYS: frozenset[str] = frozenset(
    {
        "das.source_path",
    }
)


class UnknownDasKeyError(ValueError):
    """Raised when an unknown `das.*` key is found (typo guard)."""


_MISSING = object()


def get_das_value(
    props: list[CustomProperty],
    key: str,
    *,
    default: Any = _MISSING,
) -> Any:
    for p in props:
        if p.property == key:
            return p.value
    if default is _MISSING:
        return None
    return default


def extract_das_props(
    props: list[CustomProperty],
    *,
    allowed: frozenset[str] | None = None,
) -> dict[str, Any]:
    """Return `{key: value}` for entries with `das.` prefix.

    If `allowed` is provided, raise on any `das.*` key not in the set.
    """
    out: dict[str, Any] = {}
    for p in props:
        if not p.property.startswith("das."):
            continue
        if allowed is not None and p.property not in allowed:
            raise UnknownDasKeyError(
                f"Unknown das.* key '{p.property}'. Allowed: {sorted(allowed)}"
            )
        out[p.property] = p.value
    return out
