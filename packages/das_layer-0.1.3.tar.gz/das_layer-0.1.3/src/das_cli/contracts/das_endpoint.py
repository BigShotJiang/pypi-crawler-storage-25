"""`das.endpoint` model, paginator registry, and resolution helpers.

See ADR-0014: per-resource das.endpoint for HTTP source resolution.
"""

from __future__ import annotations

from typing import Any, Literal

from dlt.sources.helpers.rest_client.paginators import (
    BasePaginator,
    HeaderLinkPaginator,
    JSONLinkPaginator,
    OffsetPaginator,
    PageNumberPaginator,
    SinglePagePaginator,
)
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from das_cli.contracts.custom_properties import get_das_value
from das_cli.contracts.loader import LoadedContract

# `pagination.type` → dlt paginator class. Remaining `pagination` keys pass
# through as constructor kwargs in `build_paginator()`.
PAGINATOR_REGISTRY: dict[str, type[BasePaginator]] = {
    "none": SinglePagePaginator,
    "json_link": JSONLinkPaginator,
    "header_link": HeaderLinkPaginator,
    "offset": OffsetPaginator,
    "page_number": PageNumberPaginator,
}


class DasEndpoint(BaseModel):
    """Validated shape of `das.endpoint` customProperty values.

    See ADR-0014.
    """

    model_config = ConfigDict(extra="forbid")

    path: str
    method: Literal["GET"] = "GET"
    response_path: str | None = None
    pagination: dict[str, Any] = Field(default_factory=lambda: {"type": "none"})
    query_params: dict[str, str | int | bool] = Field(default_factory=dict)
    headers: dict[str, str] = Field(default_factory=dict)

    @field_validator("path")
    @classmethod
    def _path_starts_with_slash(cls, v: str) -> str:
        if not v.startswith("/"):
            raise ValueError("path must start with '/'")
        return v

    @field_validator("response_path")
    @classmethod
    def _response_path_supported(cls, v: str | None) -> str | None:
        # v0.2 supports null (bare array) or `$.<key>` (one level deep).
        if v is None:
            return v
        if not v.startswith("$."):
            raise ValueError("response_path must be null or start with '$.'")
        rest = v[2:]
        if not rest or "." in rest or "[" in rest:
            raise ValueError(
                "response_path must be null or `$.<key>` "
                "(one level deep; deeper paths not supported in v0.2)"
            )
        return v

    @model_validator(mode="after")
    def _pagination_has_type(self) -> DasEndpoint:
        if "type" not in self.pagination:
            raise ValueError("pagination must contain a 'type' key")
        return self


def build_paginator(pagination: dict[str, Any]) -> BasePaginator:
    """Look up paginator by `type`, pass remaining keys as kwargs."""
    ptype = pagination["type"]
    cls = PAGINATOR_REGISTRY.get(ptype)
    if cls is None:
        raise ValueError(
            f"unknown pagination type '{ptype}'. " f"Known: {sorted(PAGINATOR_REGISTRY)}"
        )
    kwargs = {k: v for k, v in pagination.items() if k != "type"}
    return cls(**kwargs)


def synthesize_odata_endpoint(contract: LoadedContract) -> DasEndpoint:
    """Default endpoint for an OData contract that lacks `das.endpoint`.

    Path resolution order (see ADR-0024):

    1. `das.spec_ref.entity_set` — authoritative, captured at bootstrap from
       `$metadata`'s `<EntityContainer><EntitySet>`.
    2. `pluralize_preserving_case(das.spec_ref.type)` — case-preserving
       heuristic for contracts bootstrapped before ADR-0024 landed, or for
       `$metadata` without an EntityContainer.
    3. `contract.resource_name` — last-ditch fallback when `das.spec_ref` is
       absent entirely.

    Other endpoint fields are unchanged: OData's `$.value` envelope and the
    JSON-link paginator on `@odata.nextLink`.

    The next-link key is wrapped in double quotes so `jsonpath_ng` parses
    it as a single literal field name. Without the quotes the `.` is
    treated as a child-path separator (`Child(Fields('@odata'),
    Fields('nextLink'))`), which never matches the flat top-level key
    OData servers emit, causing paginated extracts to stop after the
    first page. See issue #70.
    """
    # Local import preserves the one-way bootstrap → contracts package convention.
    # `naming.py` happens to be a leaf today (imports only `re`), so a top-level
    # import wouldn't close a cycle — but the convention is package-level, and the
    # fallback heuristic is only used in this one function.
    from das_cli.bootstrap.naming import pluralize_preserving_case

    spec_ref = get_das_value(contract.contract.custom_properties, "das.spec_ref")
    if isinstance(spec_ref, dict):
        entity_set = spec_ref.get("entity_set")
        if isinstance(entity_set, str) and entity_set:
            path = f"/{entity_set}"
        else:
            type_name = spec_ref.get("type")
            if isinstance(type_name, str) and type_name:
                path = f"/{pluralize_preserving_case(type_name)}"
            else:
                path = f"/{contract.resource_name}"
    else:
        path = f"/{contract.resource_name}"

    return DasEndpoint(
        path=path,
        response_path="$.value",
        pagination={"type": "json_link", "next_url_path": '"@odata.nextLink"'},
    )


class MissingEndpointError(ValueError):
    """Raised when a non-OData HTTP source has no `das.endpoint` and no fallback."""


def resolve_endpoint(contract: LoadedContract, *, source_type: str) -> DasEndpoint:
    """Resolve the effective endpoint for a contract.

    Priority:
    1. Explicit `das.endpoint` on the contract.
    2. OData synthesized default.
    3. Hard error for openapi/rest.
    """
    raw = get_das_value(contract.contract.custom_properties, "das.endpoint")
    if raw is not None:
        return DasEndpoint.model_validate(raw)
    if source_type == "odata":
        return synthesize_odata_endpoint(contract)
    raise MissingEndpointError(
        f"Resource '{contract.resource_name}' has no `das.endpoint` and "
        f"source type '{source_type}' has no fallback. "
        f"Run `das contract bootstrap` or add `das.endpoint` manually."
    )
