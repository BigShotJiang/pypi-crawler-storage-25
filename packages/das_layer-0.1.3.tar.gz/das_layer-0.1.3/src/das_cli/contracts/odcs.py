"""ODCS v3 pydantic models — the subset das-cli uses."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

LogicalType = Literal[
    "string", "integer", "number", "boolean", "date", "timestamp", "object", "array"
]
ContractStatus = Literal["draft", "active", "deprecated"]


class CustomProperty(BaseModel):
    model_config = ConfigDict(extra="forbid")
    property: str
    value: Any


class OdcsProperty(BaseModel):
    model_config = ConfigDict(extra="allow")  # ODCS allows extras on properties
    name: str
    physicalName: str | None = None  # noqa: N815
    logicalType: LogicalType  # noqa: N815
    physicalType: str | None = None  # noqa: N815
    required: bool = False
    unique: bool = False
    primaryKey: bool = False  # noqa: N815
    description: str | None = None
    custom_properties: list[CustomProperty] = Field(default_factory=list, alias="customProperties")


class OdcsSchema(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)
    name: str
    physicalName: str | None = None  # noqa: N815
    physicalType: Literal["table", "view"] = "table"  # noqa: N815
    description: str | None = None
    properties: list[OdcsProperty] = Field(default_factory=list)


class OdcsInfo(BaseModel):
    model_config = ConfigDict(extra="allow")
    title: str | None = None
    description: str | None = None
    owner: str | None = None


class OdcsContract(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)
    apiVersion: Literal["v3.0.0", "v3.0.1", "v3.0.2"]  # noqa: N815
    kind: Literal["DataContract"]
    id: str
    name: str
    version: str
    status: ContractStatus
    info: OdcsInfo = Field(default_factory=OdcsInfo)
    schema_: list[OdcsSchema] = Field(alias="schema", min_length=1)
    custom_properties: list[CustomProperty] = Field(default_factory=list, alias="customProperties")

    @property
    def primary_schema(self) -> OdcsSchema:
        return self.schema_[0]
