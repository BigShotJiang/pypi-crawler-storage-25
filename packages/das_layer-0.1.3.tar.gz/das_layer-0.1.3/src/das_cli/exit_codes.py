"""CLI exit codes. See spec §6.3."""

from __future__ import annotations

OK = 0
GENERIC = 1
USAGE = 2
VALIDATION_FAILURE = 3
DOCTOR_FAILURE = 4
PIPELINE_FAILURE = 5
DRIFT_DETECTED = 6
