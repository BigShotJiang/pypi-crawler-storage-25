"""Rich-formatted CLI output helpers."""

from __future__ import annotations

import sys

import typer
from rich.console import Console

from das_cli.exit_codes import GENERIC


def _out() -> Console:
    return Console(file=sys.stdout, soft_wrap=True)


def _err() -> Console:
    return Console(file=sys.stderr, soft_wrap=True)


def header(verb: str, target: str) -> None:
    _out().print(f"[bold cyan][das][/] {verb} → [bold]{target}[/]")


def info(message: str) -> None:
    _out().print(f"[das] {message}")


def success(message: str) -> None:
    _out().print(f"[green]✓[/] {message}")


def warn(message: str) -> None:
    _err().print(f"[yellow]![/] {message}")


def die(message: str, *, code: int = GENERIC) -> typer.Exit:
    """Print to stderr and raise typer.Exit with the given code."""
    _err().print(f"[red]✗[/] {message}")
    raise typer.Exit(code=code)
