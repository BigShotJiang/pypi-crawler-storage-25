"""Config file loading with Jinja env_var() rendering."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from das_cli.jinja_env import render_obj
from das_cli.models.das_yaml import DasConfig
from das_cli.models.source_yml import SourceConfig


def _read_yaml(path: Path) -> Any:
    with path.open("r") as f:
        return yaml.safe_load(f)


def load_das_config(path: Path | str) -> DasConfig:
    """Load and validate `das.yaml`. Templates are rendered before validation."""
    p = Path(path)
    raw = _read_yaml(p)
    rendered = render_obj(raw, origin=str(p))
    return DasConfig.model_validate(rendered)


def load_source_config(path: Path | str) -> SourceConfig:
    """Load and validate `contracts/<source>/_source.yml`."""
    p = Path(path)
    raw = _read_yaml(p)
    rendered = render_obj(raw, origin=str(p))
    return SourceConfig.model_validate(rendered)
