"""Live progress display for long-running pipelines.

See docs/superpowers/specs/2026-05-06-progress-bars-design.md.
"""

from __future__ import annotations

from collections.abc import Iterable, Iterator, Mapping, Sequence
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Any, Literal, Protocol, TypeVar

from rich.console import Console
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    SpinnerColumn,
    TaskID,
    TextColumn,
    TimeElapsedColumn,
    TimeRemainingColumn,
)
from rich.progress import Progress as RichProgress

from das_cli import output

T = TypeVar("T")

Mode = Literal["rich", "plain", "silent"]


def resolve_mode(*, quiet: bool, verbose: bool, isatty: bool) -> tuple[Mode | None, str | None]:
    """Resolve (progress_mode, dlt_progress) from CLI flags + TTY status.

    Returns (mode, dlt_progress) where:
    - mode is "silent"|"rich"|"plain"|None — None means "no Rich progress at all"
      (verbose mode falls into this; dlt's own log output takes over).
    - dlt_progress is the value to pass to dlt.pipeline(progress=...).
    """
    if quiet:
        return "silent", None
    if verbose:
        return None, "log"
    return ("rich" if isatty else "plain"), None


class _Renderer(Protocol):
    def start(self, name: str) -> None: ...
    def tick(self, name: str, n: int) -> None: ...
    def done(self, name: str, n: int) -> None: ...
    def fail(self, name: str, n: int, exc: BaseException) -> None: ...
    def close(self) -> None: ...


class _SilentRenderer:
    def start(self, name: str) -> None: ...
    def tick(self, name: str, n: int) -> None: ...
    def done(self, name: str, n: int) -> None: ...
    def fail(self, name: str, n: int, exc: BaseException) -> None: ...
    def close(self) -> None: ...


class _PlainRenderer:
    """Writes per-resource start/finish lines. Used for non-TTY stdout."""

    def __init__(self) -> None:
        self._started: set[str] = set()

    def start(self, name: str) -> None:
        if name in self._started:
            return
        self._started.add(name)
        output.info(f"{name}: started")

    def tick(self, name: str, n: int) -> None:
        return

    def done(self, name: str, n: int) -> None:
        output.info(f"{name}: {n} rows")

    def fail(self, name: str, n: int, exc: BaseException) -> None:
        output.warn(f"{name}: FAILED after {n} rows")

    def close(self) -> None:
        return


class _RichRenderer:
    """Live stacked progress panel for TTY stdout."""

    def __init__(self, totals: dict[str, int | None]) -> None:
        self._totals = totals
        any_total = any(t is not None for t in totals.values())
        columns: list[Any] = [
            SpinnerColumn(),
            TextColumn("{task.description}"),
            MofNCompleteColumn(),
            TimeElapsedColumn(),
        ]
        if any_total:
            columns.insert(3, BarColumn())
            columns.append(TimeRemainingColumn())
        self._progress = RichProgress(
            *columns,
            console=Console(),
            transient=False,
        )
        self._progress.start()
        self._tasks: dict[str, TaskID] = {}
        for name, total in totals.items():
            task_id = self._progress.add_task(
                description=name,
                total=total,
                start=False,
            )
            self._tasks[name] = task_id

    def start(self, name: str) -> None:
        task_id = self._tasks[name]
        self._progress.start_task(task_id)

    def tick(self, name: str, n: int) -> None:
        task_id = self._tasks[name]
        self._progress.update(task_id, completed=n)

    def done(self, name: str, n: int) -> None:
        task_id = self._tasks[name]
        if self._totals.get(name) is None:
            self._progress.update(task_id, total=n, completed=n)
        else:
            self._progress.update(task_id, completed=n)
        self._progress.stop_task(task_id)

    def fail(self, name: str, n: int, exc: BaseException) -> None:
        task_id = self._tasks[name]
        self._progress.update(
            task_id,
            description=f"[red]✗[/] {name} (error after {n} rows)",
        )
        self._progress.stop_task(task_id)

    def close(self) -> None:
        self._progress.stop()


@dataclass
class ProgressHandle:
    _renderer: _Renderer

    def wrap(self, name: str, it: Iterable[T]) -> Iterator[T]:
        self._renderer.start(name)
        n = 0
        try:
            for item in it:
                yield item
                n += 1
                self._renderer.tick(name, n)
            self._renderer.done(name, n)
        except BaseException as exc:
            self._renderer.fail(name, n, exc)
            raise

    def fail(self, name: str, exc: BaseException) -> None:
        """Mark a resource failed without iterating (for caller-driven failures)."""
        self._renderer.fail(name, 0, exc)


def _resource_names(
    resources: Sequence[str] | Mapping[str, int],
) -> list[str]:
    if isinstance(resources, Mapping):
        return list(resources.keys())
    return list(resources)


def _resource_totals(
    resources: Sequence[str] | Mapping[str, int],
) -> dict[str, int | None]:
    if isinstance(resources, Mapping):
        return dict(resources)
    return {name: None for name in resources}


@contextmanager
def progress(
    resources: Sequence[str] | Mapping[str, int],
    *,
    mode: Mode,
) -> Iterator[ProgressHandle]:
    """Open a progress display for a sequence of resources.

    `resources` may be a list of names (totals unknown — extract) or a mapping
    of name → row count (totals known — load).
    """
    renderer: _Renderer
    if mode == "silent":
        renderer = _SilentRenderer()
    elif mode == "plain":
        renderer = _PlainRenderer()
    elif mode == "rich":
        renderer = _RichRenderer(_resource_totals(resources))
    else:
        raise ValueError(f"unknown mode: {mode!r}")

    try:
        yield ProgressHandle(_renderer=renderer)
    finally:
        renderer.close()
