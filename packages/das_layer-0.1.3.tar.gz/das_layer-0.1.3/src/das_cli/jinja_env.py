"""Jinja-based env_var() rendering for das-cli config files."""

from __future__ import annotations

import os
from typing import Any

from jinja2 import Environment, StrictUndefined


class MissingEnvVarError(RuntimeError):
    """Raised when a referenced env var is unset and has no default."""


def _env_var(name: str, default: str | None = None, *, _origin: str = "") -> str:
    value = os.environ.get(name)
    if value is not None:
        return value
    if default is not None:
        return default
    raise MissingEnvVarError(f"Missing required env var '{name}' referenced in {_origin}")


def _build_env(origin: str) -> Environment:
    env = Environment(
        autoescape=False,
        undefined=StrictUndefined,
        # Disable everything except the global we expose.
        extensions=[],
    )
    env.globals.clear()
    env.filters.clear()
    env.tests.clear()
    env.globals["env_var"] = lambda name, default=None: _env_var(name, default, _origin=origin)
    return env


def render_template(source: str, *, origin: str) -> str:
    """Render a single string template with the env_var() global available.

    `origin` is included in error messages to help users locate the offending field.
    """
    env = _build_env(origin)
    return env.from_string(source).render()


def render_obj(obj: Any, *, origin: str) -> Any:
    """Recursively render any string values in dicts/lists; passthrough for others."""
    if isinstance(obj, str):
        return render_template(obj, origin=origin)
    if isinstance(obj, dict):
        return {k: render_obj(v, origin=f"{origin}.{k}") for k, v in obj.items()}
    if isinstance(obj, list):
        return [render_obj(v, origin=f"{origin}[{i}]") for i, v in enumerate(obj)]
    return obj
