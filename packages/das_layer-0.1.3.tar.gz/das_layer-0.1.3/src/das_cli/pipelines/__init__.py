"""dlt pipeline runners (extract = P1, load = P2)."""
