"""Stable, canonical hashing for change detection. See ADR-0004."""

from __future__ import annotations

import hashlib
import json
from typing import Any


def _canonicalize(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {k: _canonicalize(obj[k]) for k in sorted(obj)}
    if isinstance(obj, list):
        return [_canonicalize(x) for x in obj]
    return obj


def compute_row_hash(record: dict[str, Any], *, exclude: set[str]) -> str:
    """Return a hex MD5 of the canonical JSON of `record` minus `exclude` keys."""
    filtered = {k: v for k, v in record.items() if k not in exclude}
    canonical = json.dumps(
        _canonicalize(filtered), separators=(",", ":"), default=str, ensure_ascii=False
    )
    return hashlib.md5(canonical.encode("utf-8")).hexdigest()
