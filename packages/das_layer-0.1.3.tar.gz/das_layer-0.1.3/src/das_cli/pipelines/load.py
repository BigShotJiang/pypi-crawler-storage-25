"""P2: read landing files, project per ODCS, append to the warehouse.

The warehouse is dlt-driven; supported destinations are dispatched in
`_build_destination`. See ADR-0004, ADR-0008, ADR-0012, ADR-0013, ADR-0016.
"""

from __future__ import annotations

from collections.abc import Iterator
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

import dlt

from das_cli.config import load_das_config
from das_cli.contracts.custom_properties import get_das_value
from das_cli.contracts.loader import LoadedContract, discover_sources, load_source_contracts
from das_cli.dlt_glue.azure_credentials import (
    build_adlfs_kwargs,
    build_deltalake_storage_options,
    build_dlt_azure_credentials,
)
from das_cli.dlt_glue.dataset import resolve_dataset_name
from das_cli.dlt_glue.landing_fs import iter_landing_records
from das_cli.dlt_glue.schema_factory import (
    build_dlt_columns,
    coerce_decimal,
    is_decimal_column,
    primary_keys_for,
)
from das_cli.models.das_yaml import LandingConfig, TargetConfig, parse_azure_credentials
from das_cli.pipelines.change_detection import (
    ChangeDetectionFilter,
    load_latest_hash,
)
from das_cli.pipelines.row_hash import compute_row_hash
from das_cli.progress import ProgressHandle

if TYPE_CHECKING:
    from das_cli.models.das_yaml import AzureDefaultAuth, AzureServicePrincipalAuth

# See ADR-0012: schema_contract: freeze.
# `tables` is always "evolve" — it allows dlt to create the destination table on first load;
# tables=freeze would block that. The user cannot override `tables` in v0.1 (see ADR-0012:
# evolve is the only safe value given dlt's first-load behavior).
# `columns` and `data_type` are user-configurable via das.yaml defaults.schema_contract.
_TABLES_MODE = "evolve"


def _build_destination(
    target: TargetConfig,
) -> tuple[Any, str | None, AzureServicePrincipalAuth | AzureDefaultAuth | None]:
    """Construct a dlt destination from cfg.target. See ADR-0016.

    Returns (destination, bucket_url_or_None, parsed_azure_or_None). The
    bucket_url + azure pair is captured here once and threaded into
    `change_detection.load_latest_hash` so the OneLake DuckDB secret install
    can run before second-cycle reads (issue #55). For non-delta destinations
    both are None.

    Adding a new destination is one branch here plus a `dlt[<extra>]` entry in
    pyproject.toml. enable_dataset_name_normalization=False is unconditional —
    it preserves the `das__<source>` dataset prefix literally instead of letting
    each destination's normalizer rewrite it.
    """
    name = target.destination
    creds = dict(target.credentials)
    if name == "duckdb":
        return (
            dlt.destinations.duckdb(
                credentials=creds.get("database", "./das.duckdb"),
                enable_dataset_name_normalization=False,
            ),
            None,
            None,
        )
    if name == "ducklake":
        catalog = creds.get("catalog")
        if isinstance(catalog, str) and "://" not in catalog:
            creds = {**creds, "catalog": f"duckdb:///{catalog}"}
        # dlt's ducklake factory accepts a dict at runtime and converts to
        # DuckLakeCredentials via dlt's spec machinery; the static type only
        # advertises DuckLakeCredentials | None.
        return (
            dlt.destinations.ducklake(
                credentials=creds,  # type: ignore[arg-type]
                enable_dataset_name_normalization=False,
            ),
            None,
            None,
        )
    if name == "delta":
        # See ADR-0017: delta is an alias for filesystem; table_format is per-resource.
        # See ADR-0020: typed Azure credentials when bucket_url is abfs[s]:// / az://.
        bucket_url = creds.get("bucket_url", "./das_delta")
        azure = parse_azure_credentials(creds, bucket_url)
        dlt_creds = build_dlt_azure_credentials(azure, bucket_url=bucket_url) if azure else None
        # OneLake / Fabric-specific config: deltalake_storage_options for the
        # Rust writer, and adlfs `credential` object via kwargs (adlfs uses
        # the Blob API for list ops; needs a credential object, not a SAS).
        deltalake_opts = build_deltalake_storage_options(bucket_url, azure)
        adlfs_kwargs = build_adlfs_kwargs(azure, bucket_url)
        factory_kwargs: dict[str, Any] = {
            "bucket_url": bucket_url,
            "credentials": dlt_creds,
            "enable_dataset_name_normalization": False,
        }
        if deltalake_opts is not None:
            factory_kwargs["deltalake_storage_options"] = deltalake_opts
        if adlfs_kwargs:
            factory_kwargs["kwargs"] = adlfs_kwargs
        return (dlt.destinations.filesystem(**factory_kwargs), bucket_url, azure)
    raise ValueError(
        f"Unsupported target.destination: {name!r}. Verified destinations: duckdb, ducklake, delta."
    )


def _project_record(record: dict[str, Any], contract: LoadedContract) -> dict[str, Any]:
    """Project one record through the contract — physicalName → name."""
    schema = contract.contract.primary_schema
    out: dict[str, Any] = {}
    for prop in schema.properties:
        source_path = get_das_value(prop.custom_properties, "das.source_path")
        if source_path:
            value = _resolve_path(record, source_path)
        else:
            phys = prop.physicalName or prop.name
            value = record.get(phys)
        # See ADR-0018: SQL drivers return `Decimal`, dlt's JSON encoder serialises
        # it as a quoted string in landing; restore the type here so P2's frozen
        # contract sees the declared `decimal` data type.
        if is_decimal_column(prop):
            value = coerce_decimal(value)
        out[prop.name] = value
    return out


def _resolve_path(record: dict[str, Any], path: str) -> Any:
    parts = path.split(".")
    cur: Any = record
    for p in parts:
        if not isinstance(cur, dict):
            return None
        cur = cur.get(p)
    return cur


def _build_load_resource(
    contract: LoadedContract,
    *,
    landing: LandingConfig,
    source: str,
    resource: str,
    hash_exclude: set[str],
    primary_key: list[str],
    pipeline: dlt.Pipeline,
    dataset: str,
    schema_contract: dict[str, str],
    table_format: str | None = None,
    progress_handle: ProgressHandle | None = None,
    full: bool = False,
    bucket_url: str | None = None,
    azure: AzureServicePrincipalAuth | AzureDefaultAuth | None = None,
) -> Any:
    cols = build_dlt_columns(contract.contract)
    table_name: str = contract.contract.primary_schema.physicalName or contract.resource_name

    # See ADR-0019: --full uses dlt's "replace" disposition to truncate +
    # rebuild from full landing replay. Default is the incremental append path.
    write_disposition = "replace" if full else "append"
    # See ADR-0017: table_format is set per-resource (dlt has no destination-level pin).
    resource_kwargs: dict[str, Any] = {
        "name": table_name,
        "write_disposition": write_disposition,
        "primary_key": primary_key or None,
        "columns": cols,
        "schema_contract": schema_contract,
    }
    if table_format is not None:
        resource_kwargs["table_format"] = table_format

    @dlt.resource(**resource_kwargs)  # type: ignore[misc,call-overload,untyped-decorator]
    def _gen() -> Iterator[dict[str, Any]]:
        # See ADR-0013: per-load load-time stamp from dlt's load package.
        pkg = dlt.current.load_package_state()
        loaded_at = datetime.fromtimestamp(float(pkg["load_id"]), tz=UTC)
        loaded_on = loaded_at.date()

        # See ADR-0019: --full bypasses change-detection so every landing row
        # reaches dlt and the destination table is rebuilt from scratch.
        if full or not primary_key:
            change_filter: ChangeDetectionFilter | None = None
        else:
            latest = load_latest_hash(
                pipeline=pipeline,
                dataset=dataset,
                table=table_name,
                primary_key=primary_key,
                bucket_url=bucket_url,
                azure=azure,
            )
            change_filter = ChangeDetectionFilter(primary_key=primary_key, latest_hash=latest)

        def _projected_iter() -> Iterator[dict[str, Any]]:
            for line in iter_landing_records(landing, source=source, resource=resource):
                raw = line.get("_data", line)
                # See ADR-0013: per-row extract stamp from line._dlt_load_id.
                extract_load_id = line.get("_dlt_load_id")
                if extract_load_id is None:
                    raise ValueError(
                        f"landing line missing _dlt_load_id (table={table_name}); "
                        "cannot derive _extracted_at"
                    )
                extracted_at = datetime.fromtimestamp(float(extract_load_id), tz=UTC)
                extracted_on = extracted_at.date()

                projected = _project_record(raw, contract)
                projected["_row_hash"] = compute_row_hash(raw, exclude=hash_exclude)
                projected["_extracted_at"] = extracted_at
                projected["_extracted_on"] = extracted_on
                projected["_loaded_at"] = loaded_at
                projected["_loaded_on"] = loaded_on
                yield projected

        if change_filter is None:
            base_stream: Iterator[dict[str, Any]] = _projected_iter()
        else:
            base_stream = change_filter(_projected_iter())

        # See ADR-0019: when full=True and a primary key exists, landing is
        # append-only so multiple extract runs may have written the same PK
        # more than once.  Deduplicate here, keeping the row with the latest
        # _extracted_at, so the "replace" destination receives exactly one row
        # per primary-key value (the most recent snapshot).
        if full and primary_key:
            # NOTE: entire dataset is held in memory for full replay; O(n) in the
            # number of distinct primary keys per resource.
            pk_latest: dict[tuple[Any, ...], tuple[datetime, dict[str, Any]]] = {}
            for row in base_stream:
                pk_val = tuple(row.get(k) for k in primary_key)
                ext_at: datetime = row["_extracted_at"]
                prev = pk_latest.get(pk_val)
                if prev is None or ext_at > prev[0]:
                    pk_latest[pk_val] = (ext_at, row)
            stream: Iterator[dict[str, Any]] = iter(v for _, v in pk_latest.values())
        else:
            stream = base_stream

        # Wrap after change_filter so the counter reflects rows that actually
        # reach dlt (post-filter), not rows read from landing.
        if progress_handle is not None:
            stream = progress_handle.wrap(table_name, stream)
        yield from stream

    return _gen


def run_load(
    *,
    config_path: Path | str,
    only_source: str | None = None,
    only_resources: list[str] | None = None,
    progress_handle: ProgressHandle | None = None,
    dlt_progress: str | None = None,
    full: bool = False,
) -> dict[str, Any]:
    """Run the single P2 pipeline. Returns a summary dict (rows per (source, resource))."""
    cfg = load_das_config(config_path)
    contracts_root = (Path(config_path).parent / cfg.contracts.root).resolve()
    sources = discover_sources(contracts_root)

    if only_source:
        sources = [s for s in sources if s.name == only_source]
        if not sources:
            raise FileNotFoundError(f"Source '{only_source}' not found")

    destination, bucket_url, azure = _build_destination(cfg.target)
    pipeline = dlt.pipeline(  # type: ignore[call-overload]
        pipeline_name="das_load",
        destination=destination,
        pipelines_dir=".dlt/pipelines",
        progress=dlt_progress,
    )

    summary: dict[str, Any] = {"sources": {}}

    # Build schema_contract from user config. `tables` is always "evolve" — it cannot be
    # user-overridden because tables=freeze blocks legitimate first-load table creation (ADR-0012).
    # `columns` and `data_type` are effective user knobs for v0.1.
    schema_contract: dict[str, str] = {
        "tables": _TABLES_MODE,
        "columns": cfg.defaults.schema_contract.columns,
        "data_type": cfg.defaults.schema_contract.data_type,
    }

    # See ADR-0017: per-destination table format. Currently only delta sets a value.
    table_format: str | None = "delta" if cfg.target.destination == "delta" else None

    resources: list[Any] = []
    dataset_per_resource: list[tuple[Any, str]] = []
    for src in sources:
        contracts = load_source_contracts(src.path)
        if only_resources:
            wanted = set(only_resources)
            contracts = [c for c in contracts if c.resource_name in wanted]
        if not contracts:
            continue
        dataset = resolve_dataset_name(src.name, prefix=cfg.dataset.prefix)
        for c in contracts:
            hash_exclude = set(
                get_das_value(c.contract.custom_properties, "das.hash_exclude") or []
            )
            res = _build_load_resource(
                c,
                landing=cfg.landing,
                source=src.name,
                resource=c.resource_name,
                hash_exclude=hash_exclude,
                primary_key=primary_keys_for(c.contract),
                pipeline=pipeline,
                dataset=dataset,
                schema_contract=schema_contract,
                table_format=table_format,
                progress_handle=progress_handle,
                full=full,
                bucket_url=bucket_url,
                azure=azure,
            )
            resources.append(res)
            dataset_per_resource.append((res, dataset))

    if not resources:
        return summary

    # One pipeline run per dataset (dlt requires a single dataset_name per run).
    by_dataset: dict[str, list[Any]] = {}
    for res, ds in dataset_per_resource:
        by_dataset.setdefault(ds, []).append(res)

    for dataset, rs in by_dataset.items():
        pipeline.run(rs, dataset_name=dataset)

    return summary
