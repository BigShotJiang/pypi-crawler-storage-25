"""Per-PK change-detection filter. See ADR-0004 (filter), ADR-0016 (read path)."""

from __future__ import annotations

from collections.abc import Iterable, Iterator
from typing import TYPE_CHECKING, Any

from das_cli.dlt_glue.azure_credentials import open_sql_client

if TYPE_CHECKING:
    import dlt

    from das_cli.models.das_yaml import AzureDefaultAuth, AzureServicePrincipalAuth


class ChangeDetectionFilter:
    """Yield only rows whose `_row_hash` differs from the latest hash for their PK."""

    def __init__(
        self,
        *,
        primary_key: list[str],
        latest_hash: dict[tuple[Any, ...], str],
    ) -> None:
        self.primary_key = primary_key
        self.latest_hash: dict[tuple[Any, ...], str] = dict(latest_hash)

    def __call__(self, items: Iterable[dict[str, Any]]) -> Iterator[dict[str, Any]]:
        for row in items:
            pk = tuple(row[k] for k in self.primary_key)
            new_hash = row["_row_hash"]
            if self.latest_hash.get(pk) != new_hash:
                self.latest_hash[pk] = new_hash
                yield row


def load_latest_hash(
    *,
    pipeline: dlt.Pipeline,
    dataset: str,
    table: str,
    primary_key: list[str],
    bucket_url: str | None = None,
    azure: AzureServicePrincipalAuth | AzureDefaultAuth | None = None,
) -> dict[tuple[Any, ...], str]:
    """Latest `_row_hash` per primary key, queried via the destination's SQL client.

    Returns an empty dict if the dataset/table doesn't exist yet (first load).
    Destination-agnostic — works for any dlt destination that exposes
    `pipeline.sql_client()`. See ADR-0016.

    For OneLake-backed Delta destinations, `bucket_url` + `azure` must be
    supplied so the DuckDB Azure secret can be installed before the SELECT
    runs (issue #55). Other destinations leave both as None; the underlying
    helper is a pass-through in that case.
    """
    from dlt.destinations.exceptions import DatabaseUndefinedRelation

    pk_cols = ", ".join(f'"{c}"' for c in primary_key)
    sql = f"""
    SELECT {pk_cols}, _row_hash
    FROM "{dataset}"."{table}"
    QUALIFY ROW_NUMBER() OVER (PARTITION BY {pk_cols} ORDER BY _dlt_load_id DESC) = 1
    """
    try:
        with open_sql_client(pipeline, bucket_url=bucket_url, azure=azure) as client:
            rows = client.execute_sql(sql) or []
    except DatabaseUndefinedRelation:
        return {}
    out: dict[tuple[Any, ...], str] = {}
    for row in rows:
        pk = tuple(row[: len(primary_key)])
        out[pk] = row[-1]
    return out
