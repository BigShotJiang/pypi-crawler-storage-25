"""P1: extract from source → ./landing as raw JSONL."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import dlt

from das_cli.config import load_das_config, load_source_config
from das_cli.contracts.loader import load_source_contracts
from das_cli.dlt_glue.azure_credentials import (
    build_adlfs_kwargs,
    build_dlt_azure_credentials,
)
from das_cli.dlt_glue.landing_fs import count_landing_records, landing_fs
from das_cli.dlt_glue.source_factory import build_extract_resources
from das_cli.models.das_yaml import parse_azure_credentials
from das_cli.progress import ProgressHandle


def reset_extract_state(source_name: str, config_path: Path | str) -> None:
    """Reset dlt incremental cursor state for one source. See ADR-0019, ADR-0020.

    Wipes both:
      * local `.dlt/pipelines/das_extract__<source>/` (pipeline state dir)
      * landing `<bucket_url>/<source>/_dlt_pipeline_state/`,
        `_dlt_loads/`, `_dlt_version/` (destination-side state files)

    Landing table-data directories are left untouched — P1 remains
    append-only (see ADR-0002). Works against both local paths and Azure
    landing (az:// / abfs:// / abfss://) via fsspec.
    """
    import shutil

    local_state = Path(".dlt/pipelines") / f"das_extract__{source_name}"
    if local_state.exists():
        shutil.rmtree(local_state)

    cfg = load_das_config(config_path)
    fs, root = landing_fs(cfg.landing)
    source_landing = f"{root.rstrip('/')}/{source_name}"
    for sub in ("_dlt_pipeline_state", "_dlt_loads", "_dlt_version"):
        target = f"{source_landing}/{sub}"
        if fs.exists(target):
            fs.rm(target, recursive=True)


def run_extract(
    *,
    source_name: str,
    config_path: Path | str,
    only_resources: list[str] | None = None,
    limit: int | None = None,
    progress_handle: ProgressHandle | None = None,
    dlt_progress: str | None = None,
) -> dict[str, Any]:
    """Run P1 for a single source. Returns a summary dict (rows per resource)."""
    cfg = load_das_config(config_path)
    contracts_root = (Path(config_path).parent / cfg.contracts.root).resolve()
    src_dir = contracts_root / source_name
    if not src_dir.is_dir():
        raise FileNotFoundError(f"Source '{source_name}' not found at {src_dir}")

    scfg = load_source_config(src_dir / "_source.yml")
    contracts = load_source_contracts(src_dir)

    if only_resources:
        wanted = set(only_resources)
        contracts = [c for c in contracts if c.resource_name in wanted]
    if not contracts:
        return {"resources": {}, "total_rows": 0}

    resources = build_extract_resources(
        scfg,
        contracts,
        source_name=source_name,
        limit=limit,
        progress_handle=progress_handle,
    )

    # Compose the landing path. v0.1 supports local paths; cloud bucket URLs
    # (s3://, gs://, az://) pass through verbatim to dlt's filesystem destination.
    # dlt filesystem lays out files as: bucket_url/<dataset_name>/<table>/<files>.
    # We set bucket_url = landing_root and dataset_name = source_name so that
    # the final paths are:
    #   landing_root/<source_name>/<table>/_extracted_on=YYYY-MM-DD/<files>
    # See ADR-0013 for partition rationale.
    bucket_url = cfg.landing.bucket_url.rstrip("/")

    azure = parse_azure_credentials(cfg.landing.credentials, cfg.landing.bucket_url)
    dlt_creds: object = (
        build_dlt_azure_credentials(azure, bucket_url=cfg.landing.bucket_url)
        if azure
        else (cfg.landing.credentials or None)
    )
    # OneLake / Fabric needs adlfs to use a credential *object* for the Blob
    # API (used by glob/find/ls). Empty {} for standard ADLS Gen2.
    adlfs_kwargs = build_adlfs_kwargs(azure, cfg.landing.bucket_url)

    fs_factory_kwargs: dict[str, Any] = {
        "bucket_url": bucket_url,
        "credentials": dlt_creds,
        # See ADR-0013: Hive-partition by extract date so the on-disk key
        # `_extracted_on` matches the staging column name. {curr_date} is
        # dlt's UTC date placeholder (YYYY-MM-DD) derived from the load
        # package timestamp.
        "layout": "{table_name}/_extracted_on={curr_date}/{load_id}.{file_id}.{ext}",
        # ADR-0016: preserve dataset names literally. Without this, dlt
        # collapses `source__name` (double underscore) to `source_name`
        # (single), and the landing reader (which uses the source name
        # verbatim) finds zero files. Matches `_build_destination` (load).
        "enable_dataset_name_normalization": False,
    }
    if adlfs_kwargs:
        fs_factory_kwargs["kwargs"] = adlfs_kwargs

    pipeline = dlt.pipeline(  # type: ignore[call-overload]
        pipeline_name=f"das_extract__{source_name}",
        destination=dlt.destinations.filesystem(**fs_factory_kwargs),
        dataset_name=source_name,
        pipelines_dir=".dlt/pipelines",
        progress=dlt_progress,
    )

    try:
        pipeline.run(resources, loader_file_format="jsonl")
    finally:
        # See ADR-0018: SQL sources stash a SQLAlchemy engine on the resource list
        # so we can dispose it after the run. HTTP sources don't need this.
        engine = getattr(resources, "_das_sql_engine", None)
        if engine is not None:
            engine.dispose()

    summary: dict[str, Any] = {"resources": {}, "total_rows": 0}
    for c in contracts:
        count = count_landing_records(cfg.landing, source=source_name, resource=c.resource_name)
        if count == 0:
            continue
        summary["resources"][c.resource_name] = count
        summary["total_rows"] += count

    return summary
