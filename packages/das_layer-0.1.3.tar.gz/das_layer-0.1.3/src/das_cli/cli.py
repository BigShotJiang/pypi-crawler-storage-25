"""Typer CLI entrypoint for das-cli."""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Annotated

import typer

from das_cli import __version__

app = typer.Typer(
    name="das",
    help="Contract-driven DAS-layer ingestion CLI built on dlt.",
    no_args_is_help=True,
    add_completion=False,
)


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(__version__)
        raise typer.Exit(code=0)


@app.callback()
def _root(
    ctx: typer.Context,
    version: Annotated[
        bool,
        typer.Option(
            "--version",
            callback=_version_callback,
            is_eager=True,
            help="Print das-cli version and exit.",
        ),
    ] = False,
    config: Annotated[
        Path | None,
        typer.Option("--config", help="Path to das.yaml (default: ./das.yaml)."),
    ] = None,
    target: Annotated[
        str | None,
        typer.Option("--target", help="Override target.credentials.database."),
    ] = None,
    landing: Annotated[
        str | None,
        typer.Option("--landing", help="Override landing.bucket_url."),
    ] = None,
    verbose: Annotated[bool, typer.Option("--verbose", "-v")] = False,
    quiet: Annotated[bool, typer.Option("--quiet", "-q")] = False,
    no_color: Annotated[bool, typer.Option("--no-color")] = False,
) -> None:
    """das — contract-driven DAS ingestion."""
    # Apply --target / --landing as env-var injection so Jinja templates pick them up.
    # See ADR-0009: dlt config via Python objects.
    if target is not None:
        os.environ["DAS_TARGET_DB"] = target
    if landing is not None:
        os.environ["DAS_LANDING_URL"] = landing
    if verbose:
        os.environ["RUNTIME__LOG_LEVEL"] = "DEBUG"
    if no_color:
        os.environ["NO_COLOR"] = "1"

    ctx.ensure_object(dict)
    ctx.obj["config_path"] = config or Path("das.yaml")
    ctx.obj["quiet"] = quiet
    ctx.obj["verbose"] = verbose


DAS_YAML_TEMPLATE = """\
target:
  destination: duckdb
  credentials:
    database: "{{ env_var('DAS_TARGET_DB', './das.duckdb') }}"

landing:
  bucket_url: "{{ env_var('DAS_LANDING_URL', './landing') }}"
  credentials: {}

contracts:
  root: ./contracts

dataset:
  prefix: das          # set to null (or omit) for no prefix; dataset = source name

defaults:
  write_disposition: append
  change_detection: row_hash
  schema_contract:
    tables: evolve
    columns: freeze
    data_type: freeze
"""

GITIGNORE_SECRETS_BLOCK = """\
# Secrets — never commit
.env
.env.*
!.env.example
"""

GITIGNORE_TEMPLATE = (
    """\
.dlt/
landing/
das.duckdb
*.duckdb.wal

"""
    + GITIGNORE_SECRETS_BLOCK
)

ENV_TEMPLATE = """\
# Workspace overrides (defaults work; uncomment to override)
# DAS_TARGET_DB=./das.duckdb
# DAS_LANDING_URL=./landing

# Source credentials — populated by `das source add`
"""


@app.command()
def init(
    force: Annotated[bool, typer.Option("--force", help="Overwrite existing das.yaml")] = False,
) -> None:
    """Scaffold a das-cli workspace in the current directory."""
    from das_cli.exit_codes import GENERIC
    from das_cli.output import die, info, success

    cwd = Path.cwd()
    das_yaml = cwd / "das.yaml"
    if das_yaml.exists() and not force:
        die(f"das.yaml already exists at {das_yaml}. Use --force to overwrite.", code=GENERIC)

    das_yaml.write_text(DAS_YAML_TEMPLATE)
    info(f"wrote {das_yaml.relative_to(cwd)}")

    contracts_dir = cwd / "contracts"
    contracts_dir.mkdir(exist_ok=True)
    (contracts_dir / ".gitkeep").touch()
    info(f"created {contracts_dir.relative_to(cwd)}/")

    gitignore = cwd / ".gitignore"
    if not gitignore.exists():
        gitignore.write_text(GITIGNORE_TEMPLATE)
        info(f"wrote {gitignore.relative_to(cwd)}")
    elif _gitignore_already_covers_env(gitignore.read_text()):
        info(".gitignore already ignores .env; not modified")
    else:
        existing = gitignore.read_text()
        sep = "" if existing.endswith("\n") else "\n"
        gitignore.write_text(existing + sep + "\n" + GITIGNORE_SECRETS_BLOCK)
        info("appended secrets block to .gitignore")

    env_path = cwd / ".env"
    if env_path.exists():
        info(".env exists; not modified")
    else:
        env_path.write_text(ENV_TEMPLATE)
        info(f"wrote {env_path.relative_to(cwd)}")

    success("workspace initialized")


source_app = typer.Typer(name="source", help="Manage source connections.")
app.add_typer(source_app)


_VALID_SOURCE_TYPES = {"odata", "openapi", "rest", "sql", "filesystem"}
_VALID_AUTH_TYPES = {"none", "bearer", "basic", "api_key"}

_NON_ALNUM_RE = re.compile(r"[^A-Z0-9]+")


def _source_env_prefix(name: str) -> str:
    """Normalize a source name into an uppercase env-var prefix.

    Replaces any run of non-alphanumerics with a single underscore and
    strips leading/trailing underscores. Returns "" if the name has no
    alphanumeric characters; callers should treat that as a usage error.
    """
    upper = name.upper()
    collapsed = _NON_ALNUM_RE.sub("_", upper)
    return collapsed.strip("_")


def _gitignore_already_covers_env(text: str) -> bool:
    """Return True if `text` contains a non-comment line equal to `.env`.

    Only the unqualified `.env` pattern satisfies the contract; `.env.*`,
    `!.env.example`, and comments are ignored. Used by `das init` to decide
    whether a pre-existing `.gitignore` already protects the user's secrets.
    """
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or line.startswith("!"):
            continue
        if line == ".env":
            return True
    return False


def _append_source_env_block(env_path: Path, name: str, auth_type: str) -> str:
    """Append a per-source secrets block to `.env`, creating the file if missing.

    Idempotent: if a line equal to `# <name> (<auth_type>)` is already present
    in `.env`, this is a no-op. Returns one of:
      "wrote"    — created `.env` and added the block
      "appended" — existing `.env` got the block
      "skipped"  — block already present
      "noop"     — auth_type == "none"; nothing to do
    """
    if auth_type == "none":
        return "noop"

    prefix = _source_env_prefix(name)
    if auth_type == "bearer":
        var_lines = [f"{prefix}__TOKEN="]
    elif auth_type == "basic":
        var_lines = [f"{prefix}__USERNAME=", f"{prefix}__PASSWORD="]
    elif auth_type == "api_key":
        var_lines = [f"{prefix}__API_KEY="]
    else:
        return "noop"  # defensive — _VALID_AUTH_TYPES already gates this

    header = f"# {name} ({auth_type})"
    block = "\n" + header + "\n" + "\n".join(var_lines) + "\n"

    if not env_path.exists():
        env_path.write_text(ENV_TEMPLATE + block)
        return "wrote"

    existing = env_path.read_text()
    for raw_line in existing.splitlines():
        if raw_line.strip() == header:
            return "skipped"

    sep = "" if existing.endswith("\n") else "\n"
    env_path.write_text(existing + sep + block)
    return "appended"


def _source_yml_template(name: str, source_type: str, url: str, auth_type: str) -> str:
    prefix = _source_env_prefix(name)

    if source_type == "sql":
        # See ADR-0018: SQL credentials live in the URL via env_var(); auth block is no-op.
        templated = _inject_env_var_userinfo(url, prefix)
        return (
            f"type: sql\n"
            f'endpoint: "{templated}"\n'
            f"spec:\n  kind: sql\n"
            f"auth:\n  type: none\n"
            f"ownership:\n  team: data-platform\n"
        )

    auth_block = "  type: none"
    if auth_type == "bearer":
        auth_block = f"  type: bearer\n  token: \"{{{{ env_var('{prefix}__TOKEN') }}}}\""
    elif auth_type == "basic":
        auth_block = (
            "  type: basic\n"
            f"  username: \"{{{{ env_var('{prefix}__USERNAME') }}}}\"\n"
            f"  password: \"{{{{ env_var('{prefix}__PASSWORD') }}}}\""
        )
    elif auth_type == "api_key":
        auth_block = f"  type: api_key\n  key: \"{{{{ env_var('{prefix}__API_KEY') }}}}\""

    spec = ""
    if source_type == "odata":
        spec = f"spec:\n  kind: odata\n  metadata_url: {url.rstrip('/')}/$metadata\n"
    elif source_type in {"openapi", "rest"}:
        spec = f"spec:\n  kind: openapi\n  swagger_url: {url.rstrip('/')}/swagger.json\n"
    elif source_type == "filesystem":
        # See ADR-0022: filesystem sources discover files from `endpoint`; no
        # remote spec URL is needed, but spec.kind must match for bootstrap dispatch.
        spec = "spec:\n  kind: filesystem\n"
    else:
        spec = "spec:\n  kind: none\n"

    return (
        f"type: {source_type}\n"
        f"endpoint: {url}\n"
        f"{spec}"
        f"auth:\n{auth_block}\n"
        f"ownership:\n  team: data-platform\n"
    )


def _inject_env_var_userinfo(url: str, prefix: str) -> str:
    """Insert env_var('<PREFIX>__USERNAME'):env_var('<PREFIX>__PASSWORD') into a SQLAlchemy URL.

    The input URL must NOT already contain userinfo. `_validate_sql_url` enforces
    this contract before this helper is called.
    """
    scheme, _, rest = url.partition("://")
    user = f"{{{{ env_var('{prefix}__USERNAME') }}}}"
    pw = f"{{{{ env_var('{prefix}__PASSWORD') }}}}"
    return f"{scheme}://{user}:{pw}@{rest}"


def _validate_sql_url(url: str) -> str | None:
    """Return None if the URL is OK, else an error message describing the problem.

    The URL must contain `://` and must NOT contain userinfo (`user:pass@host`).
    """
    if "://" not in url:
        return "SQL --url must be a SQLAlchemy URL with `<dialect>://<host>...` shape."
    _, _, rest = url.partition("://")
    host_part = rest.split("/", 1)[0]
    if "@" in host_part:
        return (
            "SQLAlchemy URLs in --url must not contain credentials; das will "
            "template them via env_var. Set credentials in .env after `source add`."
        )
    return None


@source_app.command("add")
def source_add(
    name: Annotated[str, typer.Argument(help="Source name (becomes contracts/<name>/).")],
    type_: Annotated[
        str, typer.Option("--type", help="Source type (odata|openapi|rest|sql|filesystem).")
    ],
    url: Annotated[str, typer.Option("--url", help="Source endpoint URL.")],
    auth: Annotated[
        str, typer.Option("--auth", help="Auth type (none|bearer|basic|api_key).")
    ] = "none",
) -> None:
    """Scaffold contracts/<name>/_source.yml."""
    from das_cli.exit_codes import GENERIC, USAGE
    from das_cli.output import die, info, success

    if type_ not in _VALID_SOURCE_TYPES:
        die(f"Unknown --type '{type_}'. Choose from: {sorted(_VALID_SOURCE_TYPES)}", code=USAGE)
    if auth not in _VALID_AUTH_TYPES:
        die(f"Unknown --auth '{auth}'. Choose from: {sorted(_VALID_AUTH_TYPES)}", code=USAGE)

    if type_ == "sql":
        if auth != "none":
            die(
                "--auth is not used for sql sources; credentials are templated "
                "into the endpoint URL.",
                code=USAGE,
            )
        url_err = _validate_sql_url(url)
        if url_err is not None:
            die(url_err, code=USAGE)

    if type_ == "filesystem" and auth != "none":
        # See ADR-0022: filesystem credentials flow through dlt's filesystem
        # config (env vars), not the per-source auth block.
        die(
            "--auth is not used for filesystem sources; blob credentials flow "
            "through dlt's filesystem config (env vars).",
            code=USAGE,
        )

    src_dir = Path("contracts") / name
    if src_dir.exists():
        die(f"Source already exists at {src_dir}", code=GENERIC)

    if (auth != "none" or type_ == "sql") and not _source_env_prefix(name):
        die(
            f"Source name '{name}' has no alphanumeric characters; "
            "cannot derive an env-var prefix.",
            code=USAGE,
        )

    src_dir.mkdir(parents=True, exist_ok=False)
    (src_dir / "_source.yml").write_text(_source_yml_template(name, type_, url, auth))
    info(f"wrote {src_dir}/_source.yml")

    env_path = Path(".env")
    # SQL sources always need username/password env entries; reuse the basic-auth shape.
    effective_auth_for_env = "basic" if type_ == "sql" else auth
    status = _append_source_env_block(env_path, name, effective_auth_for_env)
    if status == "wrote":
        info(f"wrote {env_path}")
    elif status == "appended":
        info(f"appended {name} block to {env_path}")
    elif status == "skipped":
        info(f"{env_path} already contains {name} block; not modified")

    success(f"source '{name}' added")


@app.command()
def validate(ctx: typer.Context) -> None:
    """Validate das.yaml + every contract under contracts/."""
    from das_cli.contracts.validator import validate_workspace
    from das_cli.exit_codes import OK, VALIDATION_FAILURE
    from das_cli.output import success, warn

    config_path: Path = ctx.obj["config_path"] if ctx.obj else Path("das.yaml")
    issues = validate_workspace(config_path)

    if not issues:
        success("workspace valid")
        raise typer.Exit(code=OK)

    for issue in issues:
        warn(f"{issue.path}: {issue.message}")
    raise typer.Exit(code=VALIDATION_FAILURE)


@app.command()
def doctor(ctx: typer.Context) -> None:
    """Check connectivity, auth, and target writability."""
    from das_cli.doctor import run_doctor
    from das_cli.exit_codes import DOCTOR_FAILURE, OK
    from das_cli.output import success, warn

    config_path: Path = ctx.obj["config_path"] if ctx.obj else Path("das.yaml")
    issues = run_doctor(config_path)

    if not issues:
        success("workspace healthy")
        raise typer.Exit(code=OK)

    for issue in issues:
        warn(f"{issue.component}: {issue.message}")
    raise typer.Exit(code=DOCTOR_FAILURE)


contract_app = typer.Typer(name="contract", help="Manage resource contracts.")
app.add_typer(contract_app)


@contract_app.command("bootstrap")
def contract_bootstrap(
    ctx: typer.Context,
    source: Annotated[str, typer.Argument(help="Source name (must exist under contracts/).")],
    from_: Annotated[
        str,
        typer.Option("--from", help="Bootstrap source: spec | sample"),
    ] = "spec",
    only: Annotated[
        str | None,
        typer.Option("--only", help="Comma-separated resource names to limit output."),
    ] = None,
    xpath: Annotated[
        str | None,
        typer.Option(
            "--xpath",
            help="XPath for filesystem .xml record extraction (e.g. //customer).",
        ),
    ] = None,
    dry_run: Annotated[bool, typer.Option("--dry-run")] = False,
    force: Annotated[bool, typer.Option("--force")] = False,
) -> None:
    """Generate ODCS contracts for a source from its spec or a sample."""
    import requests

    from das_cli.bootstrap.odata import bootstrap_odata_contracts
    from das_cli.bootstrap.openapi import bootstrap_openapi_contracts
    from das_cli.config import load_source_config
    from das_cli.contracts.writer import write_contract
    from das_cli.exit_codes import GENERIC, USAGE
    from das_cli.output import die, info, success

    config_path: Path = ctx.obj["config_path"] if ctx.obj else Path("das.yaml")
    contracts_root = config_path.parent / "contracts"
    src_dir = contracts_root / source
    if not src_dir.is_dir():
        die(f"Source '{source}' not found at {src_dir}", code=USAGE)

    scfg = load_source_config(src_dir / "_source.yml")

    if from_ not in {"spec", "sample"}:
        die(f"--from {from_} is not supported. Choose: spec | sample.", code=USAGE)

    if from_ == "sample":
        import gzip
        import json

        from das_cli.bootstrap.sample import infer_contract_from_records
        from das_cli.config import load_das_config
        from das_cli.contracts.writer import write_contract as _write_contract

        cfg = load_das_config(ctx.obj["config_path"] if ctx.obj else Path("das.yaml"))
        bucket_url = cfg.landing.bucket_url
        if not bucket_url.startswith(("s3://", "gs://", "az://", "abfs://", "abfss://", "file://")):
            landing_root = Path(bucket_url).expanduser()
        else:
            landing_root = Path(bucket_url)

        landing_source = landing_root / source

        # Determine resources: prefer existing contracts, fall back to landing subdirs.
        # This means bootstrap --from sample works even before any contracts exist.
        existing_contracts = list(src_dir.glob("*.odcs.yaml"))
        if existing_contracts:
            resource_names = [p.stem.removesuffix(".odcs") for p in existing_contracts]
        else:
            resource_names = (
                [d.name for d in landing_source.iterdir() if d.is_dir()]
                if landing_source.is_dir()
                else []
            )

        sample_only_set: set[str] | None = None
        if only:
            sample_only_set = {n.strip() for n in only.split(",") if n.strip()}

        written = 0
        for rname in resource_names:
            if sample_only_set and rname not in sample_only_set:
                continue

            rdir = landing_source / rname
            if not rdir.exists():
                info(f"  {rname}: no landing files found, skipping")
                continue

            # Collect up to 1,000 records from the most recent file(s).
            all_files = sorted(
                rdir.rglob("*.jsonl*"), key=lambda f: f.stat().st_mtime, reverse=True
            )
            records: list[dict[str, object]] = []
            for fpath in all_files:
                if len(records) >= 1000:
                    break
                try:
                    if fpath.suffix == ".gz":
                        with gzip.open(fpath, "rt", encoding="utf-8") as fh:
                            for raw_line in fh:
                                stripped = raw_line.strip()
                                if stripped:
                                    records.append(json.loads(stripped))
                                if len(records) >= 1000:
                                    break
                    else:
                        with fpath.open("r", encoding="utf-8") as fh:
                            for raw_line in fh:
                                stripped = raw_line.strip()
                                if stripped:
                                    records.append(json.loads(stripped))
                                if len(records) >= 1000:
                                    break
                except Exception as exc:
                    info(f"  {rname}: could not read {fpath.name}: {exc}")

            if not records:
                info(f"  {rname}: no records found in landing, skipping")
                continue

            loaded_contract = infer_contract_from_records(
                records, source_name=source, resource_name=rname
            )
            target = src_dir / f"{rname}.odcs.yaml"
            if target.exists() and not force:
                die(f"{target} exists; use --force to overwrite", code=GENERIC)
            if dry_run:
                info(f"[dry-run] would write {target}")
            else:
                _write_contract(loaded_contract, target)
                info(f"wrote {target}")
                written += 1

        success(f"bootstrap complete ({written} file{'s' if written != 1 else ''} written)")
        return

    if scfg.spec.kind == "odata":
        metadata_url = scfg.spec.metadata_url
        if not metadata_url:
            die("OData source missing spec.metadata_url", code=USAGE)
            return
        resp = requests.get(metadata_url, timeout=30)
        resp.raise_for_status()
        loaded = bootstrap_odata_contracts(resp.text, source_name=source)
    elif scfg.spec.kind == "openapi":
        swagger_url = scfg.spec.swagger_url
        if not swagger_url:
            die("OpenAPI source missing spec.swagger_url", code=USAGE)
            return
        resp = requests.get(swagger_url, timeout=30)
        resp.raise_for_status()
        loaded = bootstrap_openapi_contracts(
            resp.json(),
            source_name=source,
            source_endpoint=scfg.endpoint,
        )
    elif scfg.spec.kind == "sql":
        # See ADR-0018.
        from das_cli.bootstrap.sql import bootstrap_sql_contracts

        loaded = bootstrap_sql_contracts(scfg, source_name=source)
    elif scfg.spec.kind == "filesystem":
        # See ADR-0022.
        from das_cli.bootstrap.filesystem import bootstrap_filesystem_contracts

        try:
            loaded = bootstrap_filesystem_contracts(scfg, source_name=source, xpath=xpath)
        except ValueError as exc:
            die(str(exc), code=USAGE)
    else:
        die(f"Cannot bootstrap from spec.kind={scfg.spec.kind}", code=USAGE)
        return

    only_set: set[str] | None = None
    if only:
        only_set = {n.strip() for n in only.split(",") if n.strip()}

    written = 0
    for c in loaded:
        if only_set and c.resource_name not in only_set:
            continue
        target = src_dir / f"{c.resource_name}.odcs.yaml"
        if target.exists() and not force:
            die(f"{target} exists; use --force to overwrite", code=GENERIC)
        if dry_run:
            info(f"[dry-run] would write {target}")
        else:
            write_contract(c, target)
            info(f"wrote {target}")
            written += 1

    success(f"bootstrap complete ({written} file{'s' if written != 1 else ''} written)")


@contract_app.command("diff")
def contract_diff(
    source: Annotated[str, typer.Argument()],
) -> None:
    """Compare contracts against the live source spec."""
    import requests

    from das_cli.config import load_source_config
    from das_cli.contracts.diff import diff_against_odata
    from das_cli.contracts.loader import load_source_contracts
    from das_cli.exit_codes import DRIFT_DETECTED, OK, USAGE
    from das_cli.output import die, info, success, warn

    src_dir = Path("contracts") / source
    if not src_dir.is_dir():
        die(f"Source '{source}' not found at {src_dir}", code=USAGE)

    scfg = load_source_config(src_dir / "_source.yml")
    local = load_source_contracts(src_dir)

    if scfg.spec.kind == "odata":
        metadata_url = scfg.spec.metadata_url
        if not metadata_url:
            die("OData source missing spec.metadata_url", code=USAGE)
            return
        resp = requests.get(metadata_url, timeout=30)
        resp.raise_for_status()
        diffs = diff_against_odata(local, resp.text)
    else:
        die(f"diff not implemented for spec.kind={scfg.spec.kind} in v0.1", code=USAGE)
        return

    if not diffs:
        success("no drift")
        raise typer.Exit(code=OK)

    for d in diffs:
        warn(f"{d.kind}: {d.resource}{('.' + d.column) if d.column else ''} — {d.message}")
    info(f"{len(diffs)} drift item(s)")
    raise typer.Exit(code=DRIFT_DETECTED)


@app.command()
def extract(
    ctx: typer.Context,
    source: Annotated[str | None, typer.Argument()] = None,
    resource: Annotated[list[str] | None, typer.Option("--resource")] = None,
    full: Annotated[
        bool,
        typer.Option(
            "--full",
            help=(
                "Reset dlt cursor state so the next extract re-reads the "
                "source from the beginning. Landing files are preserved."
            ),
        ),
    ] = False,
    limit: Annotated[int | None, typer.Option("--limit")] = None,
) -> None:
    """P1: pull raw data into ./landing/."""
    import sys

    from das_cli.contracts.loader import discover_sources, load_source_contracts
    from das_cli.exit_codes import OK, PIPELINE_FAILURE, USAGE
    from das_cli.output import die, header, info, success
    from das_cli.pipelines.extract import run_extract
    from das_cli.progress import progress, resolve_mode

    config_path: Path = ctx.obj["config_path"] if ctx.obj else Path("das.yaml")
    contracts_root = config_path.parent / "contracts"
    sources = discover_sources(contracts_root) if source is None else None

    target_sources: list[str]
    if source is None:
        if not sources:
            die("No sources found in contracts/", code=USAGE)
        target_sources = [s.name for s in (sources or [])]
    else:
        target_sources = [source]
        if not (contracts_root / source).is_dir():
            die(f"Source '{source}' not found", code=USAGE)

    only = list(resource) if resource else None
    if full:
        # See ADR-0019: --full resets dlt cursor state on both sides; landing
        # table data is preserved (append-only per ADR-0002).
        from das_cli.pipelines.extract import reset_extract_state

        for s in target_sources:
            reset_extract_state(s, config_path)

    quiet = bool(ctx.obj.get("quiet", False)) if ctx.obj else False
    verbose = bool(ctx.obj.get("verbose", False)) if ctx.obj else False
    mode, dlt_progress = resolve_mode(quiet=quiet, verbose=verbose, isatty=sys.stdout.isatty())

    failed = False

    for s in target_sources:
        header("extract", s)

        # Compute resource list for the progress display.
        src_dir = contracts_root / s
        contracts = load_source_contracts(src_dir)
        if only:
            wanted = set(only)
            contracts = [c for c in contracts if c.resource_name in wanted]
        resource_names = [c.resource_name for c in contracts]

        try:
            if mode is None:
                summary = run_extract(
                    source_name=s,
                    config_path=config_path,
                    only_resources=only,
                    limit=limit,
                    progress_handle=None,
                    dlt_progress=dlt_progress,
                )
            else:
                with progress(resource_names, mode=mode) as h:
                    summary = run_extract(
                        source_name=s,
                        config_path=config_path,
                        only_resources=only,
                        limit=limit,
                        progress_handle=h,
                        dlt_progress=dlt_progress,
                    )
        except Exception as e:
            from das_cli.output import warn

            warn(f"{s}: extract failed: {e}")
            failed = True
            continue
        for rname, count in summary["resources"].items():
            info(f"  {rname}: {count} rows")

    if failed:
        raise typer.Exit(code=PIPELINE_FAILURE)
    success("extract complete")
    raise typer.Exit(code=OK)


@app.command()
def load(
    ctx: typer.Context,
    source: Annotated[str | None, typer.Argument()] = None,
    resource: Annotated[list[str] | None, typer.Option("--resource")] = None,
    full: Annotated[
        bool,
        typer.Option(
            "--full",
            help=(
                "Replace the destination table by replaying all landing files. "
                "Bypasses change detection."
            ),
        ),
    ] = False,
) -> None:
    """P2: load ./landing/ → warehouse with contract enforcement."""
    import sys

    from das_cli.config import load_das_config
    from das_cli.contracts.loader import discover_sources, load_source_contracts
    from das_cli.dlt_glue.landing_fs import count_landing_records
    from das_cli.exit_codes import OK, PIPELINE_FAILURE, USAGE
    from das_cli.output import die, header, success
    from das_cli.pipelines.load import run_load
    from das_cli.progress import progress, resolve_mode

    config_path: Path = ctx.obj["config_path"] if ctx.obj else Path("das.yaml")

    if source is not None:
        contracts_root = config_path.parent / "contracts"
        if not (contracts_root / source).is_dir():
            die(f"Source '{source}' not found", code=USAGE)

    only = list(resource) if resource else None

    header("load", source or "all sources")

    quiet = bool(ctx.obj.get("quiet", False)) if ctx.obj else False
    verbose = bool(ctx.obj.get("verbose", False)) if ctx.obj else False
    mode, dlt_progress = resolve_mode(quiet=quiet, verbose=verbose, isatty=sys.stdout.isatty())

    # Build {table_name: row_count} map for progress totals. Skip in silent mode
    # since the silent renderer ignores totals — no point scanning landing files.
    totals: dict[str, int] = {}
    if mode in ("rich", "plain"):
        cfg = load_das_config(config_path)
        contracts_root = (config_path.parent / cfg.contracts.root).resolve()
        sources_to_count = discover_sources(contracts_root)
        if source is not None:
            sources_to_count = [src for src in sources_to_count if src.name == source]
        for src in sources_to_count:
            contracts = load_source_contracts(src.path)
            if only:
                wanted = set(only)
                contracts = [c for c in contracts if c.resource_name in wanted]
            for c in contracts:
                table = c.contract.primary_schema.physicalName or c.resource_name
                totals[table] = count_landing_records(
                    cfg.landing, source=src.name, resource=c.resource_name
                )

    try:
        if mode is None:
            run_load(
                config_path=config_path,
                only_source=source,
                only_resources=only,
                progress_handle=None,
                dlt_progress=dlt_progress,
                full=full,
            )
        else:
            with progress(totals, mode=mode) as h:
                run_load(
                    config_path=config_path,
                    only_source=source,
                    only_resources=only,
                    progress_handle=h,
                    dlt_progress=dlt_progress,
                    full=full,
                )
    except Exception as e:
        from das_cli.output import warn

        warn(f"load failed: {e}")
        raise typer.Exit(code=PIPELINE_FAILURE) from e

    success("load complete")
    raise typer.Exit(code=OK)


@app.command()
def ingest(
    ctx: typer.Context,
    source: Annotated[str | None, typer.Argument()] = None,
    resource: Annotated[list[str] | None, typer.Option("--resource")] = None,
    extract_full: Annotated[
        bool,
        typer.Option(
            "--extract-full",
            help="Forward --full to the extract phase (reset dlt cursor state).",
        ),
    ] = False,
    load_full: Annotated[
        bool,
        typer.Option(
            "--load-full",
            help="Forward --full to the load phase (replace destination table).",
        ),
    ] = False,
    limit: Annotated[int | None, typer.Option("--limit")] = None,
) -> None:
    """Run extract followed by load. Exit code = worst of the two.

    See ADR-0019: --full splits into source-side (--extract-full) and
    destination-side (--load-full) reset; no composite --full on ingest.
    """
    from das_cli.exit_codes import OK
    from das_cli.output import header, success

    header("ingest", source or "all sources")

    try:
        extract(ctx=ctx, source=source, resource=resource, full=extract_full, limit=limit)
    except typer.Exit as e:
        if e.exit_code != OK:
            raise typer.Exit(code=e.exit_code) from None

    try:
        load(ctx=ctx, source=source, resource=resource, full=load_full)
    except typer.Exit as e:
        if e.exit_code != OK:
            raise typer.Exit(code=e.exit_code) from None

    success("ingest complete")
    raise typer.Exit(code=OK)
