from __future__ import annotations

from wexample_wex_addon_app.service.app_service import AppService as BaseAppService


class AppService(BaseAppService):
    def get_workdir_contribution(self, workdir) -> dict:
        from wexample_filestate.const.disk import DiskItemType

        d = DiskItemType.DIRECTORY

        return {
            "children": [
                {
                    "name": "supabase",
                    "type": d,
                    "should_exist": True,
                    "children": [
                        {
                            "name": "db",
                            "type": d,
                            "should_exist": True,
                            "children": [
                                {
                                    "name": "data",
                                    "type": d,
                                    "should_exist": True,
                                    "mode": {
                                        "owner": "105:106",
                                        "permissions": "750",
                                        "recursive": True,
                                    },
                                },
                                {
                                    "name": "config",
                                    "type": d,
                                    "should_exist": True,
                                    "mode": {
                                        "owner": "105:105",
                                        "permissions": "750",
                                        "recursive": True,
                                    },
                                },
                            ],
                        },
                        {"name": "storage", "type": d, "should_exist": True},
                        {"name": "functions", "type": d, "should_exist": True},
                        {"name": "snippets", "type": d, "should_exist": True},
                        {
                            "name": "config",
                            "type": d,
                            "should_exist": True,
                            "children": [
                                {"name": "api", "type": d, "should_exist": True},
                                {"name": "db", "type": d, "should_exist": True},
                                {"name": "logs", "type": d, "should_exist": True},
                                {"name": "pooler", "type": d, "should_exist": True},
                            ],
                        },
                    ],
                },
            ]
        }
