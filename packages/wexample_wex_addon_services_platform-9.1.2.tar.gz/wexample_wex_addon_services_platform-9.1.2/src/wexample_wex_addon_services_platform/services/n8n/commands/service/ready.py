from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command

if TYPE_CHECKING:
    from wexample_app.response.boolean_response import BooleanResponse
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@command(type=COMMAND_TYPE_SERVICE, description="Check if n8n service is ready")
def n8n__service__ready(
    context: ExecutionContext,
    service: AppService,
) -> BooleanResponse:
    import ssl
    import urllib.request

    from wexample_app.response.boolean_response import BooleanResponse

    ssl_ctx = ssl.create_default_context()
    ssl_ctx.check_hostname = False
    ssl_ctx.verify_mode = ssl.CERT_NONE

    for scheme in ("http", "https"):
        try:
            with urllib.request.urlopen(
                f"{scheme}://localhost:5678/healthz",
                timeout=2,
                context=ssl_ctx if scheme == "https" else None,
            ):
                return BooleanResponse(kernel=context.kernel, content=True)
        except Exception:
            continue

    return BooleanResponse(kernel=context.kernel, content=False)
