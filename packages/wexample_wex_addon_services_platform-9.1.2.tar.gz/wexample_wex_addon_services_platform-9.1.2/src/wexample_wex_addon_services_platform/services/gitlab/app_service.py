from __future__ import annotations

from wexample_wex_addon_app.service.app_service import AppService as BaseAppService


class AppService(BaseAppService):
    def get_workdir_contribution(self, workdir) -> dict:
        from wexample_filestate.const.disk import DiskItemType

        # Gitlab-ce manages its own internal permissions (runs as root),
        # we just ensure the host directories exist before first docker up.
        def _dir(name: str) -> dict:
            return {"name": name, "type": DiskItemType.DIRECTORY, "should_exist": True}

        return {
            "children": [
                {
                    "name": "gitlab",
                    "type": DiskItemType.DIRECTORY,
                    "should_exist": True,
                    "children": [
                        _dir("config"),
                        _dir("logs"),
                        _dir("data"),
                        _dir("backups"),
                    ],
                }
            ]
        }
