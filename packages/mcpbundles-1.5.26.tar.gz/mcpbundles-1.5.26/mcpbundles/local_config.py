"""Persistent local MCP connection configuration."""

from __future__ import annotations

import json
import shlex
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Literal

from mcpbundles.config import CONFIG_DIR

LOCAL_CONNECTIONS_FILE = CONFIG_DIR / "local_connections.json"
RUNTIME_KEY_FILE = CONFIG_DIR / "runtime_key"
LocalTransport = Literal["http", "stdio", "command"]


@dataclass(frozen=True)
class LocalConnection:
    name: str
    display_name: str
    transport: LocalTransport
    command: list[str] | None = None
    url: str | None = None
    server_name: str | None = None
    provider_slug: str | None = None
    bundle_slug: str | None = None

    @property
    def connection_key(self) -> str:
        return self.name


def _config_path() -> Path:
    return LOCAL_CONNECTIONS_FILE


def get_or_create_runtime_key() -> str:
    path = RUNTIME_KEY_FILE
    if path.exists():
        value = path.read_text().strip()
        if value:
            return value
    path.parent.mkdir(parents=True, exist_ok=True)
    value = f"rt_{uuid.uuid4().hex}"
    path.write_text(value)
    path.chmod(0o600)
    return value


def load_local_connections() -> dict[str, LocalConnection]:
    path = _config_path()
    if not path.exists():
        return {}
    raw = json.loads(path.read_text())
    if not isinstance(raw, dict):
        return {}
    connections: dict[str, LocalConnection] = {}
    for name, value in raw.items():
        if not isinstance(value, dict):
            continue
        connections[name] = LocalConnection(
            name=name,
            display_name=str(value.get("display_name") or name),
            transport=value["transport"],
            command=value.get("command"),
            url=value.get("url"),
            server_name=value.get("server_name"),
            provider_slug=value.get("provider_slug"),
            bundle_slug=value.get("bundle_slug"),
        )
    return connections


def save_local_connections(connections: dict[str, LocalConnection]) -> None:
    path = _config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        name: {
            key: value
            for key, value in asdict(connection).items()
            if key != "name" and value is not None
        }
        for name, connection in sorted(connections.items())
    }
    path.write_text(json.dumps(payload, indent=2, sort_keys=True))


def parse_command(command: str) -> list[str]:
    parsed = shlex.split(command)
    if not parsed:
        raise ValueError("Command cannot be empty")
    return parsed


def upsert_local_connection(
    *,
    name: str,
    display_name: str | None,
    transport: LocalTransport,
    command: list[str] | None = None,
    url: str | None = None,
    server_name: str | None = None,
    provider_slug: str | None = None,
    bundle_slug: str | None = None,
) -> LocalConnection:
    if transport in {"command", "stdio"} and not command:
        raise ValueError(f"{transport} connections require --command")
    if transport == "http" and not url:
        raise ValueError("http connections require --url")
    if command and url:
        raise ValueError("Use either --command or --url, not both")

    connections = load_local_connections()
    connection = LocalConnection(
        name=name,
        display_name=display_name or name,
        transport=transport,
        command=command,
        url=url,
        server_name=server_name,
        provider_slug=provider_slug,
        bundle_slug=bundle_slug,
    )
    connections[name] = connection
    save_local_connections(connections)
    return connection


def remove_local_connection(name: str) -> bool:
    connections = load_local_connections()
    removed = connections.pop(name, None)
    if removed is None:
        return False
    if connections:
        save_local_connections(connections)
    else:
        _config_path().unlink(missing_ok=True)
    return True


def serialize_connection(connection: LocalConnection) -> dict[str, Any]:
    data = asdict(connection)
    data["connection_key"] = connection.connection_key
    return data


__all__ = [
    "LocalConnection",
    "LOCAL_CONNECTIONS_FILE",
    "RUNTIME_KEY_FILE",
    "load_local_connections",
    "get_or_create_runtime_key",
    "parse_command",
    "remove_local_connection",
    "save_local_connections",
    "serialize_connection",
    "upsert_local_connection",
]
