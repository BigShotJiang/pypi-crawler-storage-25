"""Supervise local MCP server processes."""

from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass
from typing import Any, Literal

logger = logging.getLogger(__name__)

LocalMcpTransport = Literal["http", "stdio", "command"]


@dataclass(frozen=True)
class LocalMcpServiceConfig:
    name: str
    display_name: str
    transport: LocalMcpTransport
    command: list[str] | None = None
    url: str | None = None


class LocalMcpService:
    """Runs or tracks a configured local MCP server."""

    def __init__(self, config: LocalMcpServiceConfig) -> None:
        self.config = config
        self.process: asyncio.subprocess.Process | None = None
        self._stdio_lock = asyncio.Lock()
        self._next_request_id = 0
        self._initialized = False

    @property
    def running(self) -> bool:
        if self.config.transport == "http":
            return True
        return self.process is not None and self.process.returncode is None

    async def start(self) -> None:
        if self.config.transport == "http":
            logger.info("Registered local HTTP MCP connection %s at %s", self.config.name, self.config.url)
            return
        async with self._stdio_lock:
            await self._ensure_process_locked(timeout_seconds=10.0)

    async def stop(self) -> None:
        if self.process is None:
            return
        if self.process.returncode is None:
            self.process.terminate()
            try:
                await asyncio.wait_for(self.process.wait(), timeout=5.0)
            except asyncio.TimeoutError:
                self.process.kill()
                await self.process.wait()
        self.process = None
        self._initialized = False

    def get_status(self) -> dict:
        status = {
            "enabled": True,
            "name": self.config.name,
            "display_name": self.config.display_name,
            "transport": self.config.transport,
            "running": self.running,
        }
        if self.config.url:
            status["url"] = self.config.url
        if self.process is not None:
            status["pid"] = self.process.pid
            status["returncode"] = self.process.returncode
        return status

    async def call_tool(self, tool_name: str, arguments: dict[str, Any], *, timeout_seconds: float = 30.0) -> dict:
        """Call a tool on a command-backed local MCP server."""
        if self.config.transport == "http":
            raise ValueError("HTTP local MCP execution is not implemented yet")
        async with self._stdio_lock:
            await self._ensure_process_locked(timeout_seconds=timeout_seconds)
            response = await self._send_request_locked(
                "tools/call",
                {
                    "name": tool_name,
                    "arguments": arguments or {},
                },
                timeout_seconds=timeout_seconds,
            )
        if "error" in response:
            return {"success": False, "error_message": str(response["error"])}
        result = response.get("result") or {}
        if not isinstance(result, dict):
            result = {"value": result}
        is_error = result.get("isError") is True
        return {
            "success": not is_error,
            "result": result,
            "content_text": _content_text(result),
            "error_message": _content_text(result) if is_error else None,
        }

    async def discover_tools(self, *, timeout_seconds: float = 10.0) -> dict:
        """List tools from a command-backed local MCP server."""
        if self.config.transport == "http":
            return {"success": False, "error_message": "HTTP local MCP discovery is not implemented yet"}
        try:
            async with self._stdio_lock:
                await self._ensure_process_locked(timeout_seconds=timeout_seconds)
                response = await self._send_request_locked(
                    "tools/list",
                    {},
                    timeout_seconds=timeout_seconds,
                )
            if "error" in response:
                raise RuntimeError(str(response["error"]))
            result = response.get("result") or {}
            raw_tools = result.get("tools") if isinstance(result, dict) else None
            tools = [tool for tool in raw_tools if isinstance(tool, dict)] if isinstance(raw_tools, list) else []
        except Exception as exc:
            return {"success": False, "error_message": str(exc)}
        return {"success": True, "tools": tools}

    def _next_id(self) -> int:
        self._next_request_id += 1
        return self._next_request_id

    async def _ensure_process_locked(self, *, timeout_seconds: float) -> None:
        if not self.config.command:
            raise ValueError(f"Local MCP connection {self.config.name} requires a command")
        if self.process is not None and self.process.returncode is not None:
            self.process = None
            self._initialized = False
        if self.process is None:
            self.process = await asyncio.create_subprocess_exec(
                *self.config.command,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.DEVNULL,
            )
            logger.info(
                "Started local MCP connection %s pid=%s",
                self.config.name,
                self.process.pid,
            )
            self._initialized = False
        if self._initialized:
            return
        init_response = await self._send_request_locked(
            "initialize",
            {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "mcpbundles-local-runtime", "version": "1.0.0"},
            },
            timeout_seconds=timeout_seconds,
        )
        if "error" in init_response:
            raise RuntimeError(str(init_response["error"]))
        await _write_jsonrpc(
            self.process,
            {"jsonrpc": "2.0", "method": "notifications/initialized"},
            timeout_seconds,
        )
        self._initialized = True

    async def _send_request_locked(
        self,
        method: str,
        params: dict[str, Any],
        *,
        timeout_seconds: float,
    ) -> dict:
        if self.process is None or self.process.stdout is None:
            raise RuntimeError("MCP server process is not running")
        request_id = self._next_id()
        await _write_jsonrpc(
            self.process,
            {
                "jsonrpc": "2.0",
                "id": request_id,
                "method": method,
                "params": params,
            },
            timeout_seconds,
        )
        return await _read_jsonrpc_response(self.process.stdout, request_id, timeout_seconds)


async def _read_jsonrpc_line(stream: asyncio.StreamReader, timeout_seconds: float) -> dict:
    while True:
        line = await asyncio.wait_for(stream.readline(), timeout=timeout_seconds)
        if not line:
            raise RuntimeError("MCP server closed stdout")
        stripped = line.strip()
        if not stripped:
            continue
        try:
            decoded = json.loads(stripped)
        except json.JSONDecodeError:
            continue
        if isinstance(decoded, dict):
            return decoded


async def _read_jsonrpc_response(stream: asyncio.StreamReader, request_id: int, timeout_seconds: float) -> dict:
    while True:
        decoded = await _read_jsonrpc_line(stream, timeout_seconds)
        if decoded.get("id") == request_id:
            return decoded


async def _write_jsonrpc(process: asyncio.subprocess.Process, payload: dict, timeout_seconds: float) -> None:
    if process.stdin is None:
        raise RuntimeError("MCP server stdin unavailable")
    process.stdin.write((json.dumps(payload) + "\n").encode())
    await asyncio.wait_for(process.stdin.drain(), timeout=timeout_seconds)


def _content_text(result: dict) -> str | None:
    content = result.get("content")
    if not isinstance(content, list):
        return None
    texts: list[str] = []
    for item in content:
        if isinstance(item, dict) and item.get("type") == "text" and isinstance(item.get("text"), str):
            texts.append(item["text"])
    return "\n".join(texts) if texts else None


async def _call_stdio_tool(
    command: list[str],
    tool_name: str,
    arguments: dict[str, Any],
    *,
    timeout_seconds: float,
) -> dict:
    process = await asyncio.create_subprocess_exec(
        *command,
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.DEVNULL,
    )
    assert process.stdout is not None
    try:
        await _write_jsonrpc(
            process,
            {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "initialize",
                "params": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {},
                    "clientInfo": {"name": "mcpbundles-local-runtime", "version": "1.0.0"},
                },
            },
            timeout_seconds,
        )
        init_response = await _read_jsonrpc_line(process.stdout, timeout_seconds)
        if "error" in init_response:
            return {"success": False, "error_message": str(init_response["error"])}

        await _write_jsonrpc(
            process,
            {"jsonrpc": "2.0", "method": "notifications/initialized"},
            timeout_seconds,
        )
        await _write_jsonrpc(
            process,
            {
                "jsonrpc": "2.0",
                "id": 2,
                "method": "tools/call",
                "params": {
                    "name": tool_name,
                    "arguments": arguments or {},
                },
            },
            timeout_seconds,
        )
        response = await _read_jsonrpc_line(process.stdout, timeout_seconds)
        if "error" in response:
            return {"success": False, "error_message": str(response["error"])}
        result = response.get("result") or {}
        if not isinstance(result, dict):
            result = {"value": result}
        is_error = result.get("isError") is True
        return {
            "success": not is_error,
            "result": result,
            "content_text": _content_text(result),
            "error_message": _content_text(result) if is_error else None,
        }
    finally:
        if process.returncode is None:
            process.terminate()
            try:
                await asyncio.wait_for(process.wait(), timeout=2.0)
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()


async def _list_stdio_tools(command: list[str], *, timeout_seconds: float) -> list[dict[str, Any]]:
    process = await asyncio.create_subprocess_exec(
        *command,
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.DEVNULL,
    )
    assert process.stdout is not None
    try:
        await _write_jsonrpc(
            process,
            {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "initialize",
                "params": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {},
                    "clientInfo": {"name": "mcpbundles-local-runtime", "version": "1.0.0"},
                },
            },
            timeout_seconds,
        )
        init_response = await _read_jsonrpc_line(process.stdout, timeout_seconds)
        if "error" in init_response:
            raise RuntimeError(str(init_response["error"]))

        await _write_jsonrpc(
            process,
            {"jsonrpc": "2.0", "method": "notifications/initialized"},
            timeout_seconds,
        )
        await _write_jsonrpc(
            process,
            {"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}},
            timeout_seconds,
        )
        response = await _read_jsonrpc_line(process.stdout, timeout_seconds)
        if "error" in response:
            raise RuntimeError(str(response["error"]))
        result = response.get("result") or {}
        raw_tools = result.get("tools") if isinstance(result, dict) else None
        if not isinstance(raw_tools, list):
            return []
        tools: list[dict[str, Any]] = []
        for tool in raw_tools:
            if not isinstance(tool, dict) or not isinstance(tool.get("name"), str):
                continue
            tools.append(
                {
                    "name": tool["name"],
                    "description": tool.get("description") if isinstance(tool.get("description"), str) else None,
                    "input_schema": tool.get("inputSchema") or tool.get("input_schema"),
                    "annotations": tool.get("annotations") if isinstance(tool.get("annotations"), dict) else None,
                }
            )
        return tools
    finally:
        if process.returncode is None:
            process.terminate()
            try:
                await asyncio.wait_for(process.wait(), timeout=2.0)
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()


__all__ = ["LocalMcpService", "LocalMcpServiceConfig"]
