"""Cached update notice for the MCPBundles CLI."""

from __future__ import annotations

import json
import os
import re
import sys
import time
from typing import Any

import httpx
from rich.panel import Panel

from mcpbundles.config import CONFIG_DIR
from mcpbundles.output import console

_PYPI_URL = "https://pypi.org/pypi/mcpbundles/json"
_CACHE_FILE = CONFIG_DIR / "cache" / "version.json"
_CACHE_MAX_AGE_SECONDS = 12 * 60 * 60
_REQUEST_TIMEOUT_SECONDS = 1.0


def maybe_render_update_notice(current_version: str, *, quiet: bool) -> None:
    """Render an update notice when the installed CLI is behind PyPI."""
    if quiet or not sys.stderr.isatty() or _is_disabled():
        return

    latest_version = _latest_version()
    if not latest_version or not _is_newer_version(latest_version, current_version):
        return

    console.print()
    console.print(
        Panel(
            (
                f"[bold]Update available![/bold] "
                f"v{current_version} -> [green]v{latest_version}[/green]\n"
                "Run [cyan]pip install --upgrade mcpbundles[/cyan] to update."
            ),
            border_style="yellow",
            expand=False,
        )
    )
    console.print()


def _is_disabled() -> bool:
    return os.getenv("MCPBUNDLES_NO_UPDATE_NOTICE", "").lower() in {"1", "true", "yes"}


def _latest_version() -> str | None:
    cached = _read_cache()
    if cached and time.time() - cached.get("checked_at", 0) < _CACHE_MAX_AGE_SECONDS:
        version = cached.get("version")
        return version if isinstance(version, str) else None

    try:
        response = httpx.get(_PYPI_URL, timeout=_REQUEST_TIMEOUT_SECONDS)
        response.raise_for_status()
        payload = response.json()
        version = payload.get("info", {}).get("version")
        if not isinstance(version, str) or not version:
            _write_cache(None)
            return None
        _write_cache(version)
        return version
    except Exception:
        _write_cache(None)
        return None


def _read_cache() -> dict[str, Any] | None:
    try:
        payload = json.loads(_CACHE_FILE.read_text())
    except Exception:
        return None
    return payload if isinstance(payload, dict) else None


def _write_cache(version: str | None) -> None:
    try:
        _CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
        _CACHE_FILE.write_text(json.dumps({"version": version, "checked_at": time.time()}))
    except Exception:
        pass


def _is_newer_version(candidate: str, current: str) -> bool:
    candidate_parts = _numeric_version_parts(candidate)
    current_parts = _numeric_version_parts(current)
    if candidate_parts is None or current_parts is None:
        return False
    width = max(len(candidate_parts), len(current_parts))
    padded_candidate = candidate_parts + (0,) * (width - len(candidate_parts))
    padded_current = current_parts + (0,) * (width - len(current_parts))
    return padded_candidate > padded_current


def _numeric_version_parts(version: str) -> tuple[int, ...] | None:
    normalized = version.strip().removeprefix("v")
    if not re.fullmatch(r"\d+(?:\.\d+)*", normalized):
        return None
    return tuple(int(part) for part in normalized.split("."))
