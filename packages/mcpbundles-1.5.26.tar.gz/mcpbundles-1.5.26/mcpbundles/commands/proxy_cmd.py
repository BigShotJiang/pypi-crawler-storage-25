"""Proxy commands: proxy start, proxy stop, proxy status, proxy logs.

These preserve the existing WebSocket tunnel functionality from the
original mcpbundles-proxy, now under the 'proxy' subcommand group.
"""

import json
import os
import shlex
import subprocess
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import click

from mcpbundles.config import CLISettings, load_token, CONFIG_DIR
from mcpbundles.daemon import start_daemon, stop_daemon, get_status, get_pid_file, run_foreground
from mcpbundles.output import render_success, render_error, render_warning, stdout_console

_EXPOSED_PORTS_FILE = CONFIG_DIR / "exposed_ports.json"
_START_LOCK_FILE = CONFIG_DIR / "proxy_start.lock"


class DesktopManagedStartError(Exception):
    """Structured startup failures for desktop-managed proxy mode."""

    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def _emit_desktop_event(event: str, **fields: object) -> None:
    payload = {"event": event, **fields}
    print(json.dumps(payload), flush=True)


@contextmanager
def _start_lock() -> None:
    """Serialize proxy start/foreground run attempts."""
    _START_LOCK_FILE.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(_START_LOCK_FILE, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError as error:
        raise RuntimeError("Another proxy start is in progress.") from error
    try:
        os.write(fd, str(os.getpid()).encode("utf-8"))
        yield
    finally:
        os.close(fd)
        try:
            _START_LOCK_FILE.unlink(missing_ok=True)
        except Exception:
            pass


def _save_exposed_port(
    port: int,
    conn_name: Optional[str],
    scheme: str = "http",
    name: str | None = None,
) -> None:
    """Persist an exposed port so the daemon can auto-refresh its TTL."""
    ports = _load_exposed_ports()
    ports[str(port)] = {"conn_name": conn_name, "scheme": scheme}
    if name:
        ports[str(port)]["name"] = name
    _EXPOSED_PORTS_FILE.parent.mkdir(parents=True, exist_ok=True)
    _EXPOSED_PORTS_FILE.write_text(json.dumps(ports))


def _remove_exposed_port(port: int) -> None:
    ports = _load_exposed_ports()
    ports.pop(str(port), None)
    if ports:
        _EXPOSED_PORTS_FILE.write_text(json.dumps(ports))
    else:
        _EXPOSED_PORTS_FILE.unlink(missing_ok=True)


def load_exposed_ports() -> dict:
    """Public accessor for the daemon to read exposed ports."""
    return _load_exposed_ports()


def _load_exposed_ports() -> dict:
    try:
        if _EXPOSED_PORTS_FILE.exists():
            return json.loads(_EXPOSED_PORTS_FILE.read_text())
    except Exception:
        pass
    return {}


def _is_running() -> bool:
    """Check if tunnel daemon is running."""
    pid_file = get_pid_file()
    if not pid_file.exists():
        return False
    try:
        pid = int(pid_file.read_text())
        os.kill(pid, 0)
        return True
    except (ValueError, ProcessLookupError, PermissionError):
        pid_file.unlink(missing_ok=True)
        return False


def _running_daemon_pid() -> int | None:
    pid_file = get_pid_file()
    if not pid_file.exists():
        return None
    try:
        pid = int(pid_file.read_text())
        os.kill(pid, 0)
        return pid
    except (ValueError, ProcessLookupError, PermissionError):
        return None


def _is_proxy_start_command(command: str) -> bool:
    try:
        parts = shlex.split(command)
    except ValueError:
        parts = command.split()
    if parts and Path(parts[0]).name in {"bash", "sh", "zsh"} and "-c" in parts[:3]:
        return False
    for idx, part in enumerate(parts[:-2]):
        if Path(part).name == "mcpbundles" and parts[idx + 1 : idx + 3] == ["proxy", "start"]:
            return True
    return False


def _find_peer_processes() -> list[dict[str, str | int]]:
    """Find local proxy start processes, including stale peers outside the PID file."""
    try:
        output = subprocess.check_output(
            ["ps", "-axo", "pid=,command="],
            text=True,
            stderr=subprocess.DEVNULL,
        )
    except Exception:
        return []

    current_pid = os.getpid()
    daemon_pid = _running_daemon_pid()
    peers: list[dict[str, str | int]] = []
    for line in output.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        try:
            pid_text, command = stripped.split(maxsplit=1)
            pid = int(pid_text)
        except ValueError:
            continue
        if pid == current_pid or pid == daemon_pid:
            continue
        command_normalized = " ".join(command.split())
        if not _is_proxy_start_command(command):
            continue
        peers.append({"pid": pid, "command": command_normalized})
    return peers


def _format_age(iso_value: str | None) -> str | None:
    if not iso_value:
        return None
    try:
        normalized = iso_value.replace("Z", "+00:00")
        timestamp = datetime.fromisoformat(normalized)
        if timestamp.tzinfo is None:
            timestamp = timestamp.replace(tzinfo=timezone.utc)
        seconds = max(0, int((datetime.now(timezone.utc) - timestamp).total_seconds()))
    except Exception:
        return None

    if seconds < 60:
        return f"{seconds}s ago"
    minutes = seconds // 60
    if minutes < 60:
        return f"{minutes}m ago"
    hours = minutes // 60
    if hours < 48:
        return f"{hours}h ago"
    return f"{hours // 24}d ago"


def _build_proxy_token_data(conn_name: str | None, *, desktop_managed: bool = False) -> dict:
    """Resolve auth exactly like other CLI commands and keep refresh data when available."""
    from mcpbundles.auth_resolve import resolve_auth
    from mcpbundles.connections import ConnectionManager

    settings = CLISettings.resolve()
    manager = ConnectionManager()
    env_key = os.getenv("MCPBUNDLES_API_KEY")
    env_url = os.getenv("MCPBUNDLES_API_BASE_URL")
    env_refresh_token = os.getenv("MCPBUNDLES_REFRESH_TOKEN")
    env_client_id = os.getenv("MCPBUNDLES_CLIENT_ID")
    env_client_secret = os.getenv("MCPBUNDLES_CLIENT_SECRET")
    env_expires_at = os.getenv("MCPBUNDLES_EXPIRES_AT")
    env_workspace_id = os.getenv("MCPBUNDLES_WORKSPACE_ID")
    env_connection = os.getenv("MCPBUNDLES_CONNECTION")

    # Desktop-managed runtime uses the shared CLI connection store. Older
    # desktop builds passed raw OAuth metadata in env; keep that path so
    # installed previews can still start after upgrading the sidecar.
    if desktop_managed:
        desktop_conn_name = conn_name or env_connection
        if desktop_conn_name:
            auth = resolve_auth(settings, desktop_conn_name)
            conn = manager.get(auth.conn_name) if auth.conn_name else None
            token_data = {
                "access_token": auth.token,
                "server_url": env_url or auth.url,
                "auth_source": f"connection:{auth.conn_name}" if auth.conn_name else "connection",
                "auth_type": "api-key" if auth.token.startswith("mb_") else "access-token",
            }
            if env_workspace_id:
                token_data["workspace_id"] = env_workspace_id
            if conn and conn.workspace_id and not token_data.get("workspace_id"):
                token_data["workspace_id"] = conn.workspace_id
            refresh_data = conn.get_refresh_data() if conn and conn.auth_type == "oauth" else None
            if refresh_data:
                token_data.update(refresh_data)
                token_data["access_token"] = auth.token
                token_data["auth_type"] = "oauth"
            return token_data

        required_env = {
            "MCPBUNDLES_API_KEY": env_key,
            "MCPBUNDLES_API_BASE_URL": env_url,
            "MCPBUNDLES_REFRESH_TOKEN": env_refresh_token,
            "MCPBUNDLES_CLIENT_ID": env_client_id,
            "MCPBUNDLES_CLIENT_SECRET": env_client_secret,
            "MCPBUNDLES_EXPIRES_AT": env_expires_at,
            "MCPBUNDLES_WORKSPACE_ID": env_workspace_id,
        }
        missing = [name for name, value in required_env.items() if not value]
        if missing:
            raise DesktopManagedStartError(
                "DESKTOP_AUTH_MISSING",
                f"Desktop-managed runtime is missing required auth fields: {', '.join(missing)}",
            )
        if env_key.startswith("mb_"):
            raise DesktopManagedStartError(
                "DESKTOP_AUTH_INVALID",
                "Desktop-managed runtime requires OAuth tokens, not API keys.",
            )
        return {
            "access_token": env_key,
            "server_url": env_url,
            "auth_source": "desktop-env",
            "auth_type": "oauth",
            "workspace_id": env_workspace_id,
            "refresh_token": env_refresh_token,
            "client_id": env_client_id,
            "client_secret": env_client_secret,
            "expires_at": env_expires_at,
        }

    if conn_name is None and env_key:
        token_data: dict = {
            "access_token": env_key,
            "server_url": env_url or settings.base_url,
            "auth_source": "env:MCPBUNDLES_API_KEY",
            "auth_type": "api-key" if env_key.startswith("mb_") else "oauth",
        }
        if env_workspace_id:
            token_data["workspace_id"] = env_workspace_id
        if env_refresh_token and env_client_id and env_client_secret and env_expires_at:
            token_data.update(
                {
                    "refresh_token": env_refresh_token,
                    "client_id": env_client_id,
                    "client_secret": env_client_secret,
                    "expires_at": env_expires_at,
                }
            )
            token_data["auth_type"] = "oauth"
        return token_data

    auth = resolve_auth(settings, conn_name)
    conn = manager.get(auth.conn_name) if auth.conn_name else None
    auth_source = "global:login"
    if conn and conn.has_auth:
        auth_source = f"connection:{conn.name}"
    elif env_key:
        auth_source = "env:MCPBUNDLES_API_KEY"

    token_data: dict = {
        "access_token": auth.token,
        "server_url": env_url or auth.url,
        "auth_source": auth_source,
        "auth_type": "api-key" if auth.token.startswith("mb_") else "access-token",
    }

    if conn:
        refresh_data = conn.get_refresh_data() if conn else None
        if refresh_data:
            token_data.update(refresh_data)
            token_data["access_token"] = auth.token
            token_data["auth_type"] = "oauth"
        return token_data

    if auth_source == "env:MCPBUNDLES_API_KEY":
        token_data["auth_type"] = "api-key"
        return token_data

    global_token = load_token()
    if global_token:
        token_data.update(global_token)
        token_data["access_token"] = auth.token
        token_data["auth_type"] = "api-key" if auth.token.startswith("mb_") else "oauth"

    return token_data


def _wait_for_tunnel_status(timeout_seconds: float = 10.0) -> dict:
    deadline = time.time() + timeout_seconds
    last_status: dict = {}
    while time.time() < deadline:
        status_data = get_status()
        last_status = status_data
        tunnel_status = status_data.get("tunnel_status")
        if tunnel_status in {"connected", "authenticating", "disconnected", "auth_error", "error"}:
            return status_data
        time.sleep(0.25)
    return last_status or get_status()


def _print_start_result(status_data: dict) -> None:
    tunnel_status = status_data.get("tunnel_status")
    if tunnel_status == "connected":
        render_success("Tunnel connected")
    elif tunnel_status == "authenticating":
        render_warning("Tunnel started and is authenticating")
    elif tunnel_status in {"disconnected", "auth_error", "error"}:
        render_error(f"Tunnel daemon started but tunnel is {tunnel_status}")
    else:
        render_warning(f"Tunnel daemon started; tunnel status is {tunnel_status or 'unknown'}")

    if status_data.get("server_url"):
        stdout_console.print(f"  Server: [cyan]{status_data['server_url']}[/]")
    if status_data.get("auth_source"):
        stdout_console.print(f"  Auth:   {status_data['auth_source']}")
    if status_data.get("last_error"):
        stdout_console.print(f"  Error:  {status_data['last_error']}")


@click.group()
def proxy() -> None:
    """Manage the local WebSocket tunnel (browser, SQLite, Claude Code)."""
    pass


@proxy.command("run")
@click.option("--as", "conn_name", default=None, help="Named connection to use")
@click.option("--foreground", is_flag=True, help="Run in the current process")
@click.option("--desktop-managed", is_flag=True, help="Emit logs for MCPBundles Desktop supervision")
def proxy_run(conn_name: str | None, foreground: bool, desktop_managed: bool) -> None:
    """Run the proxy in foreground mode for desktop app supervision."""
    try:
        with _start_lock():
            if not foreground:
                render_error("proxy run currently requires --foreground")
                if desktop_managed:
                    _emit_desktop_event(
                        "proxy_start_failed",
                        code="INVALID_START_MODE",
                        message="Desktop-managed proxy requires --foreground mode.",
                    )
                raise SystemExit(1)
            if _is_running():
                render_error("Proxy is already running. Stop it before starting a desktop-managed runtime.")
                if desktop_managed:
                    _emit_desktop_event(
                        "proxy_start_failed",
                        code="OWNER_CONFLICT",
                        message="Proxy is already running on this machine.",
                    )
                raise SystemExit(1)
            try:
                token = _build_proxy_token_data(conn_name, desktop_managed=desktop_managed)
            except DesktopManagedStartError as error:
                render_error(str(error))
                if desktop_managed:
                    _emit_desktop_event(
                        "proxy_start_failed",
                        code=error.code,
                        message=str(error),
                    )
                raise SystemExit(1) from error
            except SystemExit:
                raise
            except Exception as e:
                render_error(f"Auth failed: {e}")
                if desktop_managed:
                    _emit_desktop_event(
                        "proxy_start_failed",
                        code="AUTH_RESOLUTION_FAILED",
                        message=str(e),
                    )
                raise SystemExit(1)
            token["runtime_owner"] = "desktop" if desktop_managed else "cli"
        run_foreground(token, desktop_managed=desktop_managed)
    except RuntimeError as error:
        render_error(str(error))
        if desktop_managed:
            _emit_desktop_event(
                "proxy_start_failed",
                code="START_LOCKED",
                message=str(error),
            )
        raise SystemExit(1) from error


@proxy.command("start")
@click.option("--as", "conn_name", default=None, help="Named connection to use")
def proxy_start(conn_name: str | None) -> None:
    """Start tunnel daemon in background."""
    try:
        with _start_lock():
            peers = _find_peer_processes()
            if _is_running():
                render_warning("Proxy is already running. Use 'mcpbundles proxy status' to see details.")
                if peers:
                    stdout_console.print(f"  Peer proxy start processes: {len(peers)}")
                return
            if peers:
                render_error("Another proxy start process is already running locally.")
                for peer in peers:
                    stdout_console.print(f"  PID {peer['pid']}: {peer['command']}")
                raise SystemExit(1)

            try:
                token = _build_proxy_token_data(conn_name)
            except SystemExit:
                raise
            except Exception as e:
                render_error(f"Auth failed: {e}")
                raise SystemExit(1)

            token["runtime_owner"] = "cli"
            stdout_console.print("Starting tunnel daemon...")
            start_daemon(token)
            status_data = _wait_for_tunnel_status()
            _print_start_result(status_data)
            stdout_console.print("  Use [cyan]mcpbundles proxy status[/] for details")
            stdout_console.print("  Use [cyan]mcpbundles proxy logs[/] to view logs")
    except RuntimeError as error:
        render_error(str(error))
        raise SystemExit(1) from error


@proxy.command("stop")
def proxy_stop() -> None:
    """Stop tunnel daemon."""
    if not _is_running():
        render_warning("Proxy is not running.")
        return

    stdout_console.print("Stopping tunnel daemon...")
    stop_daemon()
    render_success("Tunnel stopped")


@proxy.command("restart")
@click.option("--as", "conn_name", default=None, help="Named connection to use")
def proxy_restart(conn_name: str | None) -> None:
    """Restart tunnel daemon."""
    try:
        with _start_lock():
            if _is_running():
                stdout_console.print("Stopping tunnel daemon...")
                stop_daemon()
                time.sleep(1)

            peers = _find_peer_processes()
            if peers:
                render_error("Another proxy start process is already running locally.")
                for peer in peers:
                    stdout_console.print(f"  PID {peer['pid']}: {peer['command']}")
                raise SystemExit(1)

            try:
                token = _build_proxy_token_data(conn_name)
            except SystemExit:
                raise
            except Exception as e:
                render_error(f"Auth failed: {e}")
                raise SystemExit(1)

            token["runtime_owner"] = "cli"
            stdout_console.print("Starting tunnel daemon...")
            start_daemon(token)
            status_data = _wait_for_tunnel_status()
            _print_start_result(status_data)
    except RuntimeError as error:
        render_error(str(error))
        raise SystemExit(1) from error


@proxy.command("status")
def proxy_status() -> None:
    """Show tunnel connection status."""
    status_data = get_status()
    peers = _find_peer_processes()

    if status_data["running"]:
        from rich.panel import Panel

        updated_age = _format_age(status_data.get("updated_at"))
        lines = [
            f"  [bold]PID:[/bold]     {status_data.get('pid', '?')}",
        ]
        if "uptime" in status_data:
            lines.append(f"  [bold]Uptime:[/bold]  {status_data['uptime']}")
        if "tunnel_status" in status_data:
            icon = "[green]●[/]" if status_data["tunnel_status"] == "connected" else "[red]●[/]"
            lines.append(f"  [bold]Tunnel:[/bold]  {icon} {status_data['tunnel_status']}")
        if updated_age:
            lines.append(f"  [bold]State Age:[/bold] {updated_age}")
        if status_data.get("server_url"):
            lines.append(f"  [bold]Server:[/bold]  {status_data['server_url']}")
        if status_data.get("auth_source"):
            auth_label = status_data["auth_source"]
            if status_data.get("auth_type"):
                auth_label = f"{auth_label} ({status_data['auth_type']})"
            lines.append(f"  [bold]Auth:[/bold]    {auth_label}")
        lines.append(f"  [bold]Config:[/bold]  {status_data.get('config_dir') or CONFIG_DIR}")
        lines.append(f"  [bold]Peer Processes:[/bold] {len(peers)}")
        if status_data.get("last_error"):
            lines.append(f"  [bold]Last Error:[/bold] {status_data['last_error']}")
        if status_data.get("reconnect_in_seconds") is not None:
            lines.append(f"  [bold]Reconnect:[/bold] in {status_data['reconnect_in_seconds']}s")

        border = "green" if status_data.get("tunnel_status") == "connected" else "red"
        stdout_console.print(Panel("\n".join(lines), title="Proxy Status", border_style=border, padding=(1, 2)))
    else:
        stdout_console.print("[red]●[/] Proxy is not running")
        stdout_console.print(f"  Config: [cyan]{CONFIG_DIR}[/]")
        stdout_console.print(f"  Peer proxy start processes: {len(peers)}")
        for peer in peers[:5]:
            stdout_console.print(f"    PID {peer['pid']}: {peer['command']}")
        stdout_console.print("  Use [cyan]mcpbundles proxy start[/] to start the tunnel")


@proxy.command("expose")
@click.argument("port", type=int)
@click.option("--as", "conn_name", default=None, help="Named connection to use")
@click.option(
    "--scheme",
    type=click.Choice(["http", "https"]),
    default="http",
    show_default=True,
    help="Local scheme used by the service on this port.",
)
@click.option("--stable", is_flag=True, help="Create or reuse a durable named expose URL.")
@click.option("--name", "stable_name", default=None, help="Stable expose name, for example charge-atlas-dev.")
@click.option("--rotate", is_flag=True, help="Rotate the stable expose token.")
def proxy_expose(
    port: int,
    conn_name: str | None,
    scheme: str,
    stable: bool,
    stable_name: str | None,
    rotate: bool,
) -> None:
    """Expose a localhost port through the proxy tunnel.

    Creates a public URL that routes HTTP traffic to localhost:PORT
    through your running proxy tunnel. Use this so hosted browsers
    (Remote Browser) or mobile devices can reach your local dev server.

    Example: mcpbundles proxy expose 3000
    """
    if port < 1 or port > 65535:
        render_error(f"Invalid port: {port}")
        raise SystemExit(1)
    if stable and not stable_name:
        render_error("--stable requires --name so the URL can be reused deterministically")
        raise SystemExit(1)
    if rotate and not stable_name:
        render_error("--rotate requires --name")
        raise SystemExit(1)

    if not _is_running():
        render_error("Proxy is not running. Start it first: mcpbundles proxy start")
        raise SystemExit(1)

    from mcpbundles.auth_resolve import resolve_auth
    from mcpbundles.config import CLISettings

    settings = CLISettings.resolve()
    try:
        auth = resolve_auth(settings, conn_name)
    except SystemExit:
        raise
    except Exception as e:
        render_error(f"Auth failed: {e}")
        raise SystemExit(1)

    import httpx

    is_api_key = auth.token.startswith("mb_")
    auth_header = f"ApiKey {auth.token}" if is_api_key else f"Bearer {auth.token}"

    try:
        payload = {"port": port, "scheme": scheme}
        if stable or stable_name:
            payload["name"] = stable_name
        if rotate:
            payload["rotate"] = True
        resp = httpx.post(
            f"{auth.url}/api/tunnel/expose",
            json=payload,
            headers={"Authorization": auth_header},
            timeout=10.0,
        )
    except httpx.HTTPError as e:
        render_error(f"Failed to register expose: {e}")
        raise SystemExit(1)

    if resp.status_code != 200:
        detail = resp.json().get("detail", resp.text) if resp.headers.get("content-type", "").startswith("application/json") else resp.text
        render_error(f"Expose failed ({resp.status_code}): {detail}")
        raise SystemExit(1)

    data = resp.json()
    public_url = data["url"]

    _save_exposed_port(port, conn_name, scheme, stable_name if (stable or stable_name) else None)

    from rich.panel import Panel
    stable_line = ""
    if data.get("stable"):
        stable_line = f"  [bold]Stable Name:[/bold] {data.get('name')}\n"
    stdout_console.print(Panel(
        f"  [bold]Port:[/bold]  {port}\n"
        f"  [bold]Scheme:[/bold] {scheme}\n"
        f"{stable_line}"
        f"  [bold]URL:[/bold]   [cyan]{public_url}[/cyan]\n\n"
        f"  Pass this URL to Remote Browser or Mobile Device tools\n"
        f"  instead of http://localhost:{port}",
        title="Port Exposed",
        border_style="green",
        padding=(1, 2),
    ))


@proxy.command("unexpose")
@click.argument("port", type=int)
@click.option("--as", "conn_name", default=None, help="Named connection to use")
@click.option("--name", "stable_name", default=None, help="Stable expose name to disable.")
def proxy_unexpose(port: int, conn_name: str | None, stable_name: str | None) -> None:
    """Stop exposing a localhost port."""
    from mcpbundles.auth_resolve import resolve_auth
    from mcpbundles.config import CLISettings

    settings = CLISettings.resolve()
    try:
        auth = resolve_auth(settings, conn_name)
    except SystemExit:
        raise
    except Exception as e:
        render_error(f"Auth failed: {e}")
        raise SystemExit(1)

    import httpx

    is_api_key = auth.token.startswith("mb_")
    auth_header = f"ApiKey {auth.token}" if is_api_key else f"Bearer {auth.token}"

    try:
        payload = {"port": port}
        if stable_name:
            payload["name"] = stable_name
        resp = httpx.request(
            "DELETE",
            f"{auth.url}/api/tunnel/expose",
            json=payload,
            headers={"Authorization": auth_header},
            timeout=10.0,
        )
    except httpx.HTTPError as e:
        render_error(f"Failed to revoke: {e}")
        raise SystemExit(1)

    if resp.status_code == 200:
        _remove_exposed_port(port)
        label = f"Port {port}"
        if stable_name:
            label = f"Stable expose {stable_name} on port {port}"
        render_success(f"{label} unexposed")
    else:
        render_error(f"Unexpose failed ({resp.status_code}): {resp.text}")
        raise SystemExit(1)


@proxy.command("logs")
@click.option("-n", "--lines", default=50, help="Number of lines to show (default: 50)")
@click.option("-f", "--follow", is_flag=True, help="Follow log output (like tail -f)")
def proxy_logs(lines: int, follow: bool) -> None:
    """View tunnel logs."""
    log_file = CONFIG_DIR / "tunnel.log"

    if not log_file.exists():
        stdout_console.print("No logs found.")
        stdout_console.print("  Logs appear after running [cyan]mcpbundles proxy start[/]")
        return

    if follow:
        try:
            with open(log_file, "r") as f:
                f.seek(0, 2)
                stdout_console.print("Following logs (Ctrl+C to stop)...")
                while True:
                    line = f.readline()
                    if line:
                        print(line.rstrip())
                    else:
                        time.sleep(0.1)
        except KeyboardInterrupt:
            print("\nStopped following logs")
    else:
        with open(log_file, "r") as f:
            log_lines = f.readlines()
            for line in log_lines[-lines:]:
                print(line.rstrip())
