"""Authentication commands: login, logout, whoami, auth-token."""

import click

from mcpbundles.auth import oauth_flow
from mcpbundles.auth_resolve import resolve_auth
from mcpbundles.config import AuthError, CLISettings, load_token, delete_token, save_token
from mcpbundles.daemon import get_pid_file
from mcpbundles.output import render_success, render_error, render_warning, print_json


@click.command()
@click.option("--api-key", envvar="MCPBUNDLES_API_KEY", help="Authenticate with an API key instead of OAuth")
@click.pass_context
def login(ctx: click.Context, api_key: str | None) -> None:
    """Authenticate with MCPBundles."""
    if api_key:
        save_token({"access_token": api_key, "auth_type": "api_key"})
        render_success("Authenticated with API key!")
        return

    settings: CLISettings = ctx.obj["settings"]
    try:
        oauth_flow(oauth_base_url=settings.oauth_base_url)
        render_success("Authenticated with OAuth!")
    except Exception as e:
        render_error(f"Authentication failed: {e}")
        raise SystemExit(1)


@click.command()
def logout() -> None:
    """Remove stored credentials and stop running services."""
    pid_file = get_pid_file()
    if pid_file.exists():
        render_warning("Stopping tunnel daemon first...")
        from mcpbundles.daemon import stop_daemon
        stop_daemon()

    from mcpbundles.connections import ConnectionManager
    mgr = ConnectionManager()
    count = mgr.remove_all()

    delete_token()
    render_success(f"Logged out. Removed {count} saved connection(s).")


@click.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
@click.pass_context
def whoami(ctx: click.Context, as_json: bool) -> None:
    """Show current auth status and connected user."""
    token_data = load_token()
    if not token_data:
        render_error("Not authenticated. Run 'mcpbundles login' first.")
        raise SystemExit(1)

    settings: CLISettings = ctx.obj["settings"]
    auth_type = token_data.get("auth_type", "oauth")

    info = {
        "auth_type": auth_type,
        "server": settings.base_url,
        "config_dir": str(settings.config_dir),
    }

    if as_json:
        print_json(info)
    else:
        from rich.panel import Panel
        from mcpbundles.output import stdout_console

        lines = [
            f"  [bold]Auth type:[/bold]  {auth_type}",
            f"  [bold]Server:[/bold]     {settings.base_url}",
            f"  [bold]Config:[/bold]     {settings.config_dir}",
        ]
        stdout_console.print(Panel("\n".join(lines), title="MCPBundles Identity", border_style="green", padding=(1, 2)))


@click.command("auth-token")
@click.option("--as", "connection", default=None, help="Use a specific named connection")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
@click.pass_context
def auth_token(ctx: click.Context, connection: str | None, as_json: bool) -> None:
    """Print the resolved access token for a connection (refreshing OAuth if needed).

    Used by the desktop app to get the live token for direct HTTP calls without
    duplicating the Fernet decryption or refresh logic outside the CLI.
    """
    settings: CLISettings = ctx.obj["settings"]
    try:
        result = resolve_auth(settings, connection)
    except AuthError as exc:
        render_error(str(exc))
        raise SystemExit(1)

    if as_json:
        info: dict = {
            "token": result.token,
            "url": result.url,
            "endpoint": result.endpoint,
            "connection": result.conn_name,
        }
        if result.conn_name:
            from mcpbundles.connections import ConnectionManager

            mgr = ConnectionManager()
            conn = mgr.get(result.conn_name)
            if conn is not None:
                info["auth_type"] = conn.auth_type
                info["workspace_id"] = conn.workspace_id
                refresh = conn.get_refresh_data() if conn.auth_type == "oauth" else None
                if refresh and refresh.get("expires_at"):
                    info["expires_at"] = refresh["expires_at"]
        print_json(info)
    else:
        click.echo(result.token)
