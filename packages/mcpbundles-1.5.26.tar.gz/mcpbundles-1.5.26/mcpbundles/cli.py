"""MCPBundles CLI — connect AI to 500+ tools from the command line.

Entry point: mcpbundles (installed via pyproject.toml [project.scripts]).
"""

import click

try:
    from importlib.metadata import version
    __version__ = version("mcpbundles")
except Exception:
    __version__ = "1.0.0"

from mcpbundles.commands.auth import auth_token, login, logout, whoami
from mcpbundles.commands.conn import connect, connect_import, disconnect, list_connections, use_connection
from mcpbundles.commands.discovery import tools, resources, prompts
from mcpbundles.commands.execution import call_cmd, read_cmd, prompt_cmd, exec_cmd
from mcpbundles.commands.shell_cmd import shell_cmd
from mcpbundles.commands.proxy_cmd import proxy
from mcpbundles.commands.local_cmd import local_group
from mcpbundles.commands.agent import init_cmd, serve_cmd
from mcpbundles.commands.config_cmd import config_group
from mcpbundles.commands.install_completion import install_completion


@click.group()
@click.version_option(version=__version__, prog_name="mcpbundles")
@click.option("--url", help="Override API base URL")
@click.option("-q", "--quiet", is_flag=True, help="Suppress non-essential output")
@click.pass_context
def cli(ctx: click.Context, url: str | None, quiet: bool) -> None:
    """MCPBundles CLI — connect AI to 500+ tools from the command line.

    Authenticate once, then discover and call MCP tools directly from
    your terminal. Works with Hub tools, individual MCP servers, and
    multiple named connections.

    \b
    Getting started:
      mcpbundles login              # authenticate via browser
      mcpbundles tools              # list available tools
      mcpbundles call <tool> ...    # execute a tool
      mcpbundles exec "code"        # run code_execution
      mcpbundles shell              # interactive REPL
    """
    from mcpbundles.config import CLISettings
    from mcpbundles.output import set_quiet
    ctx.ensure_object(dict)
    ctx.obj["settings"] = CLISettings.resolve(url_override=url)
    if quiet:
        set_quiet(True)
    if not ctx.obj["settings"].is_local:
        from mcpbundles.version_notice import maybe_render_update_notice

        maybe_render_update_notice(__version__, quiet=quiet)


# Auth
cli.add_command(login)
cli.add_command(logout)
cli.add_command(whoami)
cli.add_command(auth_token)

# Connections
cli.add_command(connect)
cli.add_command(connect_import)
cli.add_command(list_connections)
cli.add_command(disconnect)
cli.add_command(use_connection)

# Discovery (always live)
cli.add_command(tools)
cli.add_command(resources)
cli.add_command(prompts)

# Execution
cli.add_command(call_cmd)
cli.add_command(read_cmd)
cli.add_command(prompt_cmd)
cli.add_command(exec_cmd)

# Interactive shell
cli.add_command(shell_cmd)

# WebSocket tunnel (legacy proxy)
cli.add_command(proxy)

# Local MCP runtime connections
cli.add_command(local_group)

# Agent integration
cli.add_command(init_cmd)
cli.add_command(serve_cmd)

# Configuration
cli.add_command(config_group)

# Shell completion installer
cli.add_command(install_completion)


if __name__ == "__main__":
    cli()
