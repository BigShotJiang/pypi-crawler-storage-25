"""Test CLI commands."""

import pytest
from click.testing import CliRunner
from types import SimpleNamespace
from unittest.mock import patch, MagicMock
from mcpbundles.cli import cli


@pytest.fixture
def runner():
    """Click CLI test runner."""
    return CliRunner()


def test_cli_version(runner):
    """Test version command."""
    result = runner.invoke(cli, ['--version'])
    assert result.exit_code == 0
    assert 'mcpbundles' in result.output
    assert 'version' in result.output


def test_cli_help(runner):
    """Test help command."""
    result = runner.invoke(cli, ['--help'])
    assert result.exit_code == 0
    assert 'MCPBundles CLI' in result.output
    assert 'login' in result.output
    assert 'tools' in result.output
    assert 'call' in result.output
    assert 'exec' in result.output
    assert 'shell' in result.output


def test_cli_update_notice_runs_from_root_command(runner):
    """Test the root CLI callback asks for an update notice."""
    with patch('mcpbundles.cli.__version__', '1.5.20'), \
         patch('mcpbundles.version_notice.maybe_render_update_notice') as mock_notice, \
         patch('mcpbundles.commands.config_cmd.config_with_defaults', return_value={"server": "https://mcp.mcpbundles.com"}):
        result = runner.invoke(cli, ['config', 'show'])

    assert result.exit_code == 0
    mock_notice.assert_called_once_with('1.5.20', quiet=False)


def test_cli_update_notice_renders_for_old_version(monkeypatch):
    """Test update notice appears when PyPI has a newer CLI."""
    from mcpbundles.version_notice import maybe_render_update_notice

    monkeypatch.setattr("mcpbundles.version_notice.sys.stderr.isatty", lambda: True)

    with patch('mcpbundles.version_notice._latest_version', return_value='1.5.21'), \
         patch('mcpbundles.version_notice.console.print') as mock_print:
        maybe_render_update_notice('1.5.20', quiet=False)

    rendered = "\n".join(
        str(getattr(call.args[0], "renderable", call.args[0]))
        for call in mock_print.call_args_list
        if call.args
    )
    assert "Update available" in rendered
    assert "1.5.20" in rendered
    assert "1.5.21" in rendered


def test_cli_update_notice_suppressed_when_quiet(monkeypatch):
    """Test quiet mode suppresses the update notice."""
    from mcpbundles.version_notice import maybe_render_update_notice

    monkeypatch.setattr("mcpbundles.version_notice.sys.stderr.isatty", lambda: True)

    with patch('mcpbundles.version_notice._latest_version', return_value='1.5.21'), \
         patch('mcpbundles.version_notice.console.print') as mock_print:
        maybe_render_update_notice('1.5.20', quiet=True)

    mock_print.assert_not_called()


def test_cli_update_notice_skips_current_version(monkeypatch):
    """Test update notice does not appear for the current CLI."""
    from mcpbundles.version_notice import maybe_render_update_notice

    monkeypatch.setattr("mcpbundles.version_notice.sys.stderr.isatty", lambda: True)

    with patch('mcpbundles.version_notice._latest_version', return_value='1.5.21'), \
         patch('mcpbundles.version_notice.console.print') as mock_print:
        maybe_render_update_notice('1.5.21', quiet=False)

    mock_print.assert_not_called()


def test_login_api_key(runner, tmp_path):
    """Test login with API key."""
    with patch('mcpbundles.commands.auth.save_token') as mock_save:
        result = runner.invoke(cli, ['login', '--api-key', 'mb_test_key'])
        assert result.exit_code == 0
        assert 'Authenticated' in result.output
        mock_save.assert_called_once_with({"access_token": "mb_test_key", "auth_type": "api_key"})


def test_login_oauth(runner):
    """Test login via OAuth flow."""
    with patch('mcpbundles.commands.auth.oauth_flow') as mock_oauth:
        mock_oauth.return_value = {"access_token": "test_token"}
        result = runner.invoke(cli, ['login'])
        assert result.exit_code == 0
        assert 'Authenticated' in result.output


def test_login_oauth_failure(runner):
    """Test OAuth login failure."""
    with patch('mcpbundles.commands.auth.oauth_flow') as mock_oauth:
        mock_oauth.side_effect = Exception("OAuth failed")
        result = runner.invoke(cli, ['login'])
        assert result.exit_code == 1
        assert 'Authentication failed' in result.output


def test_whoami_not_authenticated(runner):
    """Test whoami when not logged in."""
    with patch('mcpbundles.commands.auth.load_token', return_value=None):
        result = runner.invoke(cli, ['whoami'])
        assert result.exit_code == 1
        assert 'Not authenticated' in result.output


def test_whoami_authenticated(runner):
    """Test whoami when logged in."""
    with patch('mcpbundles.commands.auth.load_token', return_value={"access_token": "mb_test", "auth_type": "api_key"}):
        result = runner.invoke(cli, ['whoami'], catch_exceptions=False)
        assert result.exit_code == 0


def test_whoami_json(runner):
    """Test whoami JSON output."""
    with patch('mcpbundles.commands.auth.load_token', return_value={"access_token": "mb_test", "auth_type": "api_key"}):
        result = runner.invoke(cli, ['whoami', '--json'])
        assert result.exit_code == 0
        assert '"auth_type"' in result.output
        assert '"api_key"' in result.output


def test_logout(runner):
    """Test logout command."""
    with patch('mcpbundles.commands.auth.get_pid_file') as mock_pid:
        mock_pid.return_value = MagicMock(exists=MagicMock(return_value=False))
        with patch('mcpbundles.commands.auth.delete_token') as mock_delete:
            with patch('mcpbundles.connections.ConnectionManager.remove_all', return_value=0):
                result = runner.invoke(cli, ['logout'])
                assert result.exit_code == 0
                assert 'Logged out' in result.output
                mock_delete.assert_called_once()


def test_config_show(runner):
    """Test config show command."""
    with patch('mcpbundles.commands.config_cmd.config_with_defaults', return_value={"server": "https://mcp.mcpbundles.com", "output": "auto", "completion_ttl": 60}):
        result = runner.invoke(cli, ['config', 'show'], catch_exceptions=False)
        assert result.exit_code == 0


def test_config_get(runner):
    """Test config get command."""
    with patch('mcpbundles.commands.config_cmd.config_with_defaults', return_value={"server": "https://mcp.mcpbundles.com", "output": "auto"}):
        result = runner.invoke(cli, ['config', 'get', 'server'])
        assert result.exit_code == 0
        assert 'mcp.mcpbundles.com' in result.output


def test_config_set(runner):
    """Test config set command."""
    with patch('mcpbundles.commands.config_cmd.load_config', return_value={}):
        with patch('mcpbundles.commands.config_cmd.save_config') as mock_save:
            result = runner.invoke(cli, ['config', 'set', 'output', 'json'])
            assert result.exit_code == 0
            mock_save.assert_called_once_with({"output": "json"})


def test_proxy_start_uses_resolved_auth_and_reports_status(runner):
    """Test proxy start resolves auth and waits for tunnel status."""
    token_data = {
        "access_token": "mb_test_key",
        "auth_source": "connection:prod",
        "auth_type": "api-key",
        "server_url": "https://mcp.mcpbundles.com",
    }
    status_data = {
        "running": True,
        "pid": 123,
        "tunnel_status": "connected",
        "auth_source": "connection:prod",
        "server_url": "https://mcp.mcpbundles.com",
    }

    with patch('mcpbundles.commands.proxy_cmd._is_running', return_value=False), \
         patch('mcpbundles.commands.proxy_cmd._find_peer_processes', return_value=[]), \
         patch('mcpbundles.commands.proxy_cmd._build_proxy_token_data', return_value=token_data) as mock_auth, \
         patch('mcpbundles.commands.proxy_cmd.start_daemon') as mock_start, \
         patch('mcpbundles.commands.proxy_cmd._wait_for_tunnel_status', return_value=status_data), \
         patch('mcpbundles.commands.proxy_cmd.stdout_console.print') as mock_print:
        result = runner.invoke(cli, ['proxy', 'start', '--as', 'prod'])

    assert result.exit_code == 0
    mock_auth.assert_called_once_with('prod')
    mock_start.assert_called_once_with(token_data)
    assert 'Tunnel connected' in result.output
    printed = "\n".join(str(call.args[0]) for call in mock_print.call_args_list)
    assert 'connection:prod' in printed


def test_proxy_run_releases_start_lock_before_foreground_runtime(runner, tmp_path):
    """Desktop foreground runtime should not hold the startup lock while running."""
    lock_file = tmp_path / "proxy_start.lock"
    token_data = {
        "access_token": "mb_test_key",
        "auth_source": "connection:prod",
        "auth_type": "api-key",
        "server_url": "https://mcp.mcpbundles.com",
    }

    def assert_lock_released(token, desktop_managed=False):
        assert token == {**token_data, "runtime_owner": "desktop"}
        assert desktop_managed is True
        assert not lock_file.exists()

    with patch('mcpbundles.commands.proxy_cmd._START_LOCK_FILE', lock_file), \
         patch('mcpbundles.commands.proxy_cmd._is_running', return_value=False), \
         patch('mcpbundles.commands.proxy_cmd._build_proxy_token_data', return_value=token_data), \
         patch('mcpbundles.commands.proxy_cmd.run_foreground', side_effect=assert_lock_released) as mock_run:
        result = runner.invoke(cli, ['proxy', 'run', '--foreground', '--desktop-managed', '--as', 'prod'])

    assert result.exit_code == 0
    mock_run.assert_called_once()


def test_proxy_run_desktop_managed_uses_shared_connection_store(runner, tmp_path):
    """Desktop-managed runtime should resolve the selected CLI connection."""
    lock_file = tmp_path / "proxy_start.lock"
    auth_result = SimpleNamespace(
        token="access-token",
        url="https://mcp.mcpbundles.com",
        conn_name="desktop",
    )
    conn = MagicMock()
    conn.auth_type = "oauth"
    conn.workspace_id = "workspace-id"
    conn.get_refresh_data.return_value = {
        "refresh_token": "refresh-token",
        "client_id": "client-id",
        "client_secret": "client-secret",
        "expires_at": "2026-05-09T16:10:47+00:00",
    }
    manager = MagicMock()
    manager.get.return_value = conn

    def assert_connection_token(token, desktop_managed=False):
        assert token == {
            "access_token": "access-token",
            "server_url": "https://mcp.mcpbundles.com",
            "auth_source": "connection:desktop",
            "auth_type": "oauth",
            "workspace_id": "workspace-id",
            "refresh_token": "refresh-token",
            "client_id": "client-id",
            "client_secret": "client-secret",
            "expires_at": "2026-05-09T16:10:47+00:00",
            "runtime_owner": "desktop",
        }
        assert desktop_managed is True

    with patch('mcpbundles.commands.proxy_cmd._START_LOCK_FILE', lock_file), \
         patch('mcpbundles.commands.proxy_cmd._is_running', return_value=False), \
         patch('mcpbundles.auth_resolve.resolve_auth', return_value=auth_result) as mock_resolve, \
         patch('mcpbundles.connections.ConnectionManager', return_value=manager), \
         patch('mcpbundles.commands.proxy_cmd.run_foreground', side_effect=assert_connection_token) as mock_run:
        result = runner.invoke(
            cli,
            ['proxy', 'run', '--foreground', '--desktop-managed'],
            env={"MCPBUNDLES_CONNECTION": "desktop"},
        )

    assert result.exit_code == 0
    mock_resolve.assert_called_once()
    assert mock_resolve.call_args.args[1] == "desktop"
    mock_run.assert_called_once()


def test_proxy_status_includes_runtime_details(runner):
    """Test proxy status shows auth, server, config, state age, and peer count."""
    status_data = {
        "running": True,
        "pid": 123,
        "started_at": "2026-04-28T13:00:00",
        "uptime": "0:01:00",
        "tunnel_status": "connected",
        "updated_at": "2026-04-28T13:00:30+00:00",
        "auth_source": "env:MCPBUNDLES_API_KEY",
        "auth_type": "api-key",
        "server_url": "https://mcp.mcpbundles.com",
        "config_dir": "/tmp/mcpbundles",
    }
    peers = [{"pid": 456, "command": "mcpbundles proxy start"}]

    with patch('mcpbundles.commands.proxy_cmd.get_status', return_value=status_data), \
         patch('mcpbundles.commands.proxy_cmd._find_peer_processes', return_value=peers), \
         patch('mcpbundles.commands.proxy_cmd.stdout_console.print') as mock_print:
        result = runner.invoke(cli, ['proxy', 'status'])

    assert result.exit_code == 0
    panel = mock_print.call_args.args[0]
    rendered = str(panel.renderable)
    assert 'https://mcp.mcpbundles.com' in rendered
    assert 'env:MCPBUNDLES_API_KEY (api-key)' in rendered
    assert '/tmp/mcpbundles' in rendered
    assert 'Peer Processes' in rendered
    assert '1' in rendered


def test_proxy_expose_stable_posts_name_and_persists_metadata(runner):
    """Test stable exposes send the name and save it for daemon refresh."""
    auth = MagicMock(token="mb_test", url="https://mcp.mcpbundles.com")
    response = MagicMock(status_code=200)
    response.json.return_value = {
        "url": "https://stable-token.tunnel.mcpbundles.com",
        "stable": True,
        "name": "charge-atlas-dev",
        "port": 3000,
        "scheme": "http",
    }

    with patch('mcpbundles.commands.proxy_cmd._is_running', return_value=True), \
         patch('mcpbundles.auth_resolve.resolve_auth', return_value=auth), \
         patch('httpx.post', return_value=response) as mock_post, \
         patch('mcpbundles.commands.proxy_cmd._save_exposed_port') as mock_save:
        result = runner.invoke(
            cli,
            ['proxy', 'expose', '3000', '--stable', '--name', 'charge-atlas-dev', '--rotate'],
        )

    assert result.exit_code == 0
    mock_post.assert_called_once()
    assert mock_post.call_args.kwargs["json"] == {
        "port": 3000,
        "scheme": "http",
        "name": "charge-atlas-dev",
        "rotate": True,
    }
    mock_save.assert_called_once_with(3000, None, "http", "charge-atlas-dev")


def test_proxy_expose_stable_requires_name(runner):
    """Test --stable cannot create anonymous durable exposes."""
    result = runner.invoke(cli, ['proxy', 'expose', '3000', '--stable'])

    assert result.exit_code == 1
    assert "--stable requires --name" in result.output


def test_proxy_token_data_uses_env_auth_without_connections(tmp_path, monkeypatch):
    """Test proxy token data follows shared auth resolution for env API keys."""
    from mcpbundles.commands.proxy_cmd import _build_proxy_token_data

    sessions_dir = tmp_path / "sessions"
    monkeypatch.setattr("mcpbundles.connections.SESSIONS_DIR", sessions_dir)
    monkeypatch.setenv("MCPBUNDLES_API_KEY", "mb_env_key")

    token_data = _build_proxy_token_data(None)

    assert token_data["access_token"] == "mb_env_key"
    assert token_data["auth_source"] == "env:MCPBUNDLES_API_KEY"
    assert token_data["auth_type"] == "api-key"


def test_proxy_token_data_keeps_named_local_token_and_url_together(tmp_path, monkeypatch):
    """Test --as local keeps the local token paired with the local backend URL."""
    from mcpbundles.commands.proxy_cmd import _build_proxy_token_data
    from mcpbundles.connections import ConnectionManager

    sessions_dir = tmp_path / "sessions"
    key_file = tmp_path / ".key"
    monkeypatch.setattr("mcpbundles.connections.SESSIONS_DIR", sessions_dir)
    monkeypatch.setattr("mcpbundles.config.KEY_FILE", key_file)
    monkeypatch.delenv("MCPBUNDLES_API_KEY", raising=False)

    ConnectionManager().create(
        "local",
        "http://localhost:8000",
        "/hub/",
        auth_token="mb_local_key",
    )

    token_data = _build_proxy_token_data("local")

    assert token_data["access_token"] == "mb_local_key"
    assert token_data["server_url"] == "http://localhost:8000"
    assert token_data["auth_source"] == "connection:local"
    assert token_data["auth_type"] == "api-key"


def test_proxy_peer_detection_ignores_running_daemon_and_shell_wrappers():
    """Test peer detection reports only extra proxy start processes."""
    from mcpbundles.commands.proxy_cmd import _find_peer_processes

    ps_output = "\n".join(
        [
            "123 /opt/homebrew/bin/python /opt/homebrew/bin/mcpbundles proxy start --as mcpbundles_prod",
            "456 /bin/zsh -c python -c \"print('mcpbundles proxy start')\"",
            "567 /bin/zsh -c kill 123 || true && mcpbundles proxy start --as mcpbundles_prod",
            "789 /opt/homebrew/bin/python /tmp/mcpbundles proxy start",
        ]
    )

    with patch('mcpbundles.commands.proxy_cmd._running_daemon_pid', return_value=123), \
         patch('mcpbundles.commands.proxy_cmd.subprocess.check_output', return_value=ps_output), \
         patch('mcpbundles.commands.proxy_cmd.os.getpid', return_value=999):
        peers = _find_peer_processes()

    assert peers == [{"pid": 789, "command": "/opt/homebrew/bin/python /tmp/mcpbundles proxy start"}]


def test_tools_not_authenticated(runner):
    """Test tools command when not logged in and no connections exist."""
    with patch('mcpbundles.config.load_token', return_value=None), \
         patch('mcpbundles.connections.ConnectionManager.list_connections', return_value=[]), \
         patch('mcpbundles.connections.ConnectionManager.get_default', return_value=None):
        result = runner.invoke(cli, ['tools'])
        assert result.exit_code == 1
        assert 'credentials' in result.output or 'Not authenticated' in result.output


def test_resources_not_authenticated(runner):
    """Test resources command when not logged in and no connections exist."""
    with patch('mcpbundles.config.load_token', return_value=None), \
         patch('mcpbundles.connections.ConnectionManager.list_connections', return_value=[]), \
         patch('mcpbundles.connections.ConnectionManager.get_default', return_value=None):
        result = runner.invoke(cli, ['resources'])
        assert result.exit_code == 1
        assert 'credentials' in result.output or 'Not authenticated' in result.output


def test_prompts_not_authenticated(runner):
    """Test prompts command when not logged in and no connections exist."""
    with patch('mcpbundles.config.load_token', return_value=None), \
         patch('mcpbundles.connections.ConnectionManager.list_connections', return_value=[]), \
         patch('mcpbundles.connections.ConnectionManager.get_default', return_value=None):
        result = runner.invoke(cli, ['prompts'])
        assert result.exit_code == 1
        assert 'credentials' in result.output or 'Not authenticated' in result.output


def test_connections_empty(runner):
    """Test connections list when empty."""
    with patch('mcpbundles.connections.ConnectionManager.list_connections', return_value=[]):
        result = runner.invoke(cli, ['connections'])
        assert result.exit_code == 0
        assert 'No connections' in result.output


def test_disconnect_not_found(runner):
    """Test disconnect nonexistent connection."""
    with patch('mcpbundles.connections.ConnectionManager.remove', return_value=False):
        result = runner.invoke(cli, ['disconnect', 'nope'])
        assert result.exit_code == 1
        assert 'not found' in result.output
