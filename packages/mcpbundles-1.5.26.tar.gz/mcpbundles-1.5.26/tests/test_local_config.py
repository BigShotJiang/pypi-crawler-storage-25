"""Test local MCP connection configuration."""

from mcpbundles.local_config import (
    get_or_create_runtime_key,
    load_local_connections,
    parse_command,
    remove_local_connection,
    upsert_local_connection,
)


def test_upsert_local_command_connection(tmp_path, monkeypatch):
    local_file = tmp_path / "local_connections.json"
    monkeypatch.setattr("mcpbundles.local_config.LOCAL_CONNECTIONS_FILE", local_file)

    connection = upsert_local_connection(
        name="aws-docs",
        display_name="AWS Docs",
        transport="command",
        command=["uvx", "mcp-proxy-for-aws"],
        server_name="io.github.aws/docs",
        provider_slug="aws-docs",
        bundle_slug="aws-docs",
    )

    assert connection.connection_key == "aws-docs"
    loaded = load_local_connections()
    assert loaded["aws-docs"].command == ["uvx", "mcp-proxy-for-aws"]
    assert loaded["aws-docs"].display_name == "AWS Docs"
    assert loaded["aws-docs"].server_name == "io.github.aws/docs"
    assert loaded["aws-docs"].provider_slug == "aws-docs"
    assert loaded["aws-docs"].bundle_slug == "aws-docs"


def test_remove_local_connection_deletes_empty_file(tmp_path, monkeypatch):
    local_file = tmp_path / "local_connections.json"
    monkeypatch.setattr("mcpbundles.local_config.LOCAL_CONNECTIONS_FILE", local_file)

    upsert_local_connection(
        name="stripe",
        display_name=None,
        transport="http",
        url="http://localhost:3001/mcp",
    )

    assert remove_local_connection("stripe") is True
    assert local_file.exists() is False


def test_parse_command_preserves_quoted_args():
    assert parse_command("npx -y @modelcontextprotocol/server-filesystem '/Users/tony/My Files'") == [
        "npx",
        "-y",
        "@modelcontextprotocol/server-filesystem",
        "/Users/tony/My Files",
    ]


def test_runtime_key_is_stable(tmp_path, monkeypatch):
    runtime_key_file = tmp_path / "runtime_key"
    monkeypatch.setattr("mcpbundles.local_config.RUNTIME_KEY_FILE", runtime_key_file)

    first = get_or_create_runtime_key()
    second = get_or_create_runtime_key()

    assert first == second
    assert first.startswith("rt_")
