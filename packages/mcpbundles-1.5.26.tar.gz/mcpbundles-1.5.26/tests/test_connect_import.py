"""Test the connect-import + use commands used by the desktop app."""

import json

import pytest
from click.testing import CliRunner

from mcpbundles.cli import cli
from mcpbundles.config import CLISettings
from mcpbundles.connections import ConnectionManager


@pytest.fixture
def isolated(tmp_path, monkeypatch):
    sessions = tmp_path / "sessions"
    monkeypatch.setattr("mcpbundles.connections.SESSIONS_DIR", sessions)
    monkeypatch.setattr("mcpbundles.commands.conn.ConnectionManager", ConnectionManager)
    return sessions


def _invoke(args, stdin=None):
    runner = CliRunner()
    return runner.invoke(cli, args, input=stdin, obj={"settings": CLISettings.resolve()})


def test_import_oauth_creates_oauth_connection(isolated):
    payload = json.dumps({
        "auth_type": "oauth",
        "access_token": "acc",
        "refresh_token": "ref",
        "client_id": "cid",
        "client_secret": "csec",
        "expires_in": 3600,
        "workspace_id": "ws-1",
        "url": "https://mcp.mcpbundles.com",
        "endpoint": "/hub/",
    })
    result = _invoke(["connect-import", "desktop", "--default", "--json"], stdin=payload)
    assert result.exit_code == 0, result.output
    body = json.loads(result.output)
    assert body["name"] == "desktop"
    assert body["auth_type"] == "oauth"
    assert body["is_default"] is True
    assert body["workspace_id"] == "ws-1"

    conn = ConnectionManager().get("desktop")
    assert conn is not None
    assert conn.auth_type == "oauth"
    assert conn.get_auth_token() == "acc"
    refresh = conn.get_refresh_data()
    assert refresh is not None
    assert refresh["refresh_token"] == "ref"
    assert refresh["client_id"] == "cid"
    assert refresh["client_secret"] == "csec"
    assert refresh["expires_at"]


def test_import_api_key(isolated):
    payload = json.dumps({"auth_type": "api-key", "api_key": "mb_test"})
    result = _invoke(["connect-import", "ci", "--json"], stdin=payload)
    assert result.exit_code == 0, result.output
    conn = ConnectionManager().get("ci")
    assert conn is not None
    assert conn.auth_type == "api-key"
    assert conn.get_auth_token() == "mb_test"


def test_import_overwrites_existing(isolated):
    first = json.dumps({"auth_type": "api-key", "api_key": "first"})
    second = json.dumps({"auth_type": "api-key", "api_key": "second"})
    _invoke(["connect-import", "dup"], stdin=first)
    result = _invoke(["connect-import", "dup"], stdin=second)
    assert result.exit_code == 0, result.output
    conn = ConnectionManager().get("dup")
    assert conn is not None
    assert conn.get_auth_token() == "second"


def test_import_rejects_missing_oauth_fields(isolated):
    payload = json.dumps({"auth_type": "oauth", "access_token": "a"})
    result = _invoke(["connect-import", "bad"], stdin=payload)
    assert result.exit_code == 1
    assert "Missing OAuth fields" in result.output


def test_import_rejects_unknown_auth_type(isolated):
    payload = json.dumps({"auth_type": "magic"})
    result = _invoke(["connect-import", "bad"], stdin=payload)
    assert result.exit_code == 1
    assert "auth_type" in result.output


def test_import_rejects_empty_stdin(isolated):
    result = _invoke(["connect-import", "bad"], stdin="")
    assert result.exit_code == 1
    assert "stdin" in result.output


def test_use_switches_default(isolated):
    a = json.dumps({"auth_type": "api-key", "api_key": "a"})
    b = json.dumps({"auth_type": "api-key", "api_key": "b"})
    _invoke(["connect-import", "alpha", "--default"], stdin=a)
    _invoke(["connect-import", "beta"], stdin=b)

    result = _invoke(["use", "beta", "--json"])
    assert result.exit_code == 0, result.output

    mgr = ConnectionManager()
    assert mgr.get("beta").is_default is True
    assert mgr.get("alpha").is_default is False


def test_use_unknown_connection(isolated):
    result = _invoke(["use", "ghost"])
    assert result.exit_code == 1
    assert "not found" in result.output
