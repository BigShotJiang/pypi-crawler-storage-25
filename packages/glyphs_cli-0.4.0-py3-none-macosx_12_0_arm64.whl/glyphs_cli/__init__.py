"""Glyphs command-line tool."""

import os
import sys


def main():
    binary = os.path.join(os.path.dirname(__file__), "bin", "glyphs")
    if not os.access(binary, os.X_OK):
        os.chmod(binary, 0o755)
    try:
        os.execv(binary, [binary] + sys.argv[1:])
    except OSError as error:
        print(f"glyphs: {error}", file=sys.stderr)
        raise SystemExit(1)
