from __future__ import annotations

import contextlib
import json
import logging
import os
import re
import sys
import tempfile
import threading
from importlib.resources import files
from pathlib import Path

import webview

# Silence pywebview's internal attribute-introspection warnings (e.g. the
# .NET Rectangle.Empty self-recursion spam and WebView2 shutdown class
# unregister noise — both cosmetic).
# Silence pywebview + WebView2 startup introspection noise.
for _name in ("pywebview", "pywebview.util", "pywebview.platforms.edgechromium", "webview"):
    logging.getLogger(_name).setLevel(logging.CRITICAL)
# Nuclear option: filter any log record whose message contains the .NET
# Rectangle.Empty self-recursion walk.
class _EmptySpamFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        return "Empty.Empty" not in record.getMessage()
logging.getLogger().addFilter(_EmptySpamFilter())

from . import __version__, config  # noqa: E402  (must run after logger filter)
from .frontmatter import parse_frontmatter, split_frontmatter  # noqa: E402
from .render import render_frontmatter_card, render_markdown  # noqa: E402


def _render_with_frontmatter(source: str, doc_base: str | None = None) -> str:
    """Render ``source`` to HTML, prepending a frontmatter card when present."""
    raw_yaml, body = split_frontmatter(source)
    if raw_yaml is not None:
        _meta, _body, err = parse_frontmatter(source)
        card = render_frontmatter_card(raw_yaml, err)
    else:
        card = ""
    return card + render_markdown(body, doc_base=doc_base)

ASSETS = files(__package__) / "assets"


def _load_template() -> str:
    return (ASSETS / "template.html").read_text(encoding="utf-8")


def _initial_file(file: Path | None) -> tuple[Path | None, str]:
    if file:
        file = file.resolve()
        if file.exists():
            return file, file.read_text(encoding="utf-8")
        return file, ""
    example = ASSETS / "example.md"
    return None, example.read_text(encoding="utf-8")


def _json_for_script_tag(value: str) -> str:
    """JSON-encode a value safely for embedding inside an HTML <script> element.

    Standard json.dumps does not escape `</script>`, so a document that
    contains that sequence would break out of the script tag and execute
    arbitrary HTML/JS before the sanitizer runs. We additionally neutralize
    `<`, `>`, and `&` with `\\uXXXX` escapes, and `U+2028`/`U+2029` which are
    valid string breaks in HTML but invalid in JS string literals.
    """
    return (
        json.dumps(value)
        .replace("<", "\\u003c")
        .replace(">", "\\u003e")
        .replace("&", "\\u0026")
        .replace("\u2028", "\\u2028")
        .replace("\u2029", "\\u2029")
    )


_APP_ASSET_ATTR_RE = re.compile(
    r'(src|href)="((?:vendor/|app\.css|app\.js)[^"]*)"'
)


def _rewrite_app_asset_urls(template: str, assets_base: str) -> str:
    """Prefix app-asset references in the template with an absolute URL.

    Replaces `src="vendor/foo.js"` and `href="app.css"` with their
    absolute file:// equivalents. Avoids a document-wide `<base href>`,
    which would also reroute user-document relative URLs and break
    `![diagram](./diagram.png)` against the Markdown file's directory.
    """
    base = assets_base.rstrip("/") + "/"

    def _sub(m: re.Match[str]) -> str:
        return f'{m.group(1)}="{base}{m.group(2)}"'

    return _APP_ASSET_ATTR_RE.sub(_sub, template)


def _build_html(
    source: str,
    path: Path | None,
    edit: bool,
    assets_base: str = "",
    browse_root: Path | None = None,
) -> str:
    """Render the template with the given source embedded.

    `assets_base` is an absolute URL (with trailing slash) pointing at the
    packaged assets directory. App asset references in the template are
    rewritten to absolute URLs rooted there, so they keep working when
    the generated HTML file lives in a per-instance temp dir. User
    Markdown relative URLs are rewritten separately by `render_markdown`
    against the document's own directory.
    """
    template = _load_template()
    if assets_base:
        template = _rewrite_app_asset_urls(template, assets_base)
    name = path.name if path else "Welcome"
    folder = str(path.parent) if path else ""
    path_str = str(path) if path else ""
    doc_base = path.parent.resolve().as_uri() + "/" if path else None
    html_body = _render_with_frontmatter(source, doc_base=doc_base)
    return (
        template
        .replace("{{MD_HTML}}", html_body)
        .replace("{{MD_SOURCE}}", _json_for_script_tag(source))
        .replace("{{MD_NAME}}", name)
        .replace("{{MD_FOLDER}}", folder)
        .replace("{{MD_PATH}}", path_str)
        .replace("{{MD_START_MODE}}", "edit" if edit else "read")
        .replace("{{MD_BROWSE_ROOT}}", str(browse_root) if browse_root else "")
        .replace("{{MD_VERSION}}", __version__)
    )


def _atomic_write_text(path: Path, content: str) -> None:
    """Write `content` to `path` atomically. Preserves the original file on failure.

    Uses a temp file in the same directory, flushes + fsyncs, then os.replace
    to make the swap atomic at the filesystem level. Avoids partial writes
    from crashes, antivirus locks, full disks, or OSError mid-write.
    """
    path = Path(path)
    directory = path.parent if path.parent != Path("") else Path.cwd()
    directory.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=str(directory)
    )
    tmp = Path(tmp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(content)
            f.flush()
            with contextlib.suppress(OSError):
                os.fsync(f.fileno())
        os.replace(tmp, path)
    except BaseException:
        with contextlib.suppress(OSError):
            tmp.unlink()
        raise


def _stderr_print(message: str) -> None:
    """Best-effort diagnostic print to stderr.

    Under `pythonw.exe` / a PyInstaller windowed build, `sys.stderr` is
    `None`; a plain `print(..., file=sys.stderr)` would raise
    `AttributeError: 'NoneType' object has no attribute 'write'` and take
    down whatever code path emitted the diagnostic. Silently drop the
    message in that case — it would have been invisible anyway.
    """
    stream = sys.stderr
    if stream is None:
        return
    with contextlib.suppress(Exception):
        print(message, file=stream)


def _fingerprint(path: Path) -> tuple[int, int] | None:
    """Cheap (mtime_ns, size) fingerprint for concurrent-edit detection.

    Returns None if the file is absent or unreadable, which we treat as
    distinct from any present-file fingerprint.
    """
    try:
        st = path.stat()
    except OSError:
        return None
    return (st.st_mtime_ns, st.st_size)


class JsApi:
    def __init__(self) -> None:
        self._window: webview.Window | None = None
        self._current_path: Path | None = None
        # (mtime_ns, size) of the file when we last loaded or saved it.
        # None means "no known version" (e.g., new untitled document).
        self._loaded_fingerprint: tuple[int, int] | None = None
        # Proposed fingerprint for a watched change the UI hasn't yet
        # committed to. Only promotes to _loaded_fingerprint when JS calls
        # ack_reload(); otherwise the old baseline is retained so a
        # subsequent save still flags the conflict.
        self._pending_fingerprint: tuple[int, int] | None = None
        # Mirrored from JS via set_dirty() so native close/quit paths can
        # show a "discard edits?" prompt without round-tripping to JS.
        self._dirty: bool = False
        self._quitting: bool = False
        # Directory mdvw was launched in, when no file arg was provided.
        # Populated by run(). None means "single-file launch"; the file
        # browser sidebar is only offered when this is set.
        self._browse_root: Path | None = None

    def set_dirty(self, value: bool) -> None:
        self._dirty = bool(value)

    def ack_reload(self) -> bool:
        """JS calls this when it actually applied a watched reload.

        Promotes the pending fingerprint to the committed baseline.
        Required because rejecting a watched reload (user keeps edits) must
        NOT advance the save-conflict baseline, or subsequent saves would
        silently overwrite the disk edits the user chose not to take.
        """
        if self._pending_fingerprint is None:
            return False
        self._loaded_fingerprint = self._pending_fingerprint
        self._pending_fingerprint = None
        return True

    def render_markdown(self, text: str) -> str:
        return _render_with_frontmatter(text)

    def save_file(self, content: str, force: bool = False) -> dict:
        """Save the current document atomically.

        Returns a dict:
          {"status": "ok"}                — written successfully
          {"status": "cancelled"}         — user cancelled save-as dialog
          {"status": "conflict"}          — disk changed since load;
                                            caller should prompt user and
                                            retry with force=True
          {"status": "error", "message"}  — OS-level write failure
        """
        path = self._current_path
        if path is None:
            picked = self._pick_save_path()
            if picked is None:
                return {"status": "cancelled"}
            path = picked
            self._current_path = path
            self._loaded_fingerprint = None  # brand new file — no prior state
        if not force and self._loaded_fingerprint is not None:
            current = _fingerprint(path)
            # If disk state differs from what we loaded (and it existed then),
            # block the overwrite until the user explicitly opts in.
            if current != self._loaded_fingerprint:
                return {"status": "conflict"}
        try:
            _atomic_write_text(path, content)
        except OSError as e:
            _stderr_print(f"[mdvw] save_file failed: {e}")
            return {"status": "error", "message": str(e)}
        # Refresh fingerprint after successful write so the next save sees
        # this save as the new baseline.
        self._loaded_fingerprint = _fingerprint(path)
        return {"status": "ok"}

    def open_external(self, url: str) -> bool:
        """Open a user-document link outside the WebView.

        The preview window carries a native `js_api` bridge; letting an
        untrusted document navigate it would hand that bridge to the
        destination. Only http/https/mailto are allowed — `file://` links
        are rejected because a hostile Markdown document could otherwise
        ShellExecute arbitrary .exe/.lnk/etc. via `os.startfile`.
        """
        import webbrowser

        if not isinstance(url, str) or not url:
            return False
        scheme = url.split(":", 1)[0].lower() if ":" in url else ""
        if scheme in ("http", "https", "mailto"):
            webbrowser.open(url, new=2)
            return True
        return False

    _BROWSE_SKIP_DIRS = frozenset({
        "node_modules", "__pycache__", ".venv", "venv",
        "dist", "build", ".git", ".hg", ".svn", ".tox",
        ".mypy_cache", ".pytest_cache", ".ruff_cache",
    })

    def list_markdown_dir(self, path_str: str = "") -> dict | None:
        """List markdown files and subdirectories of a single directory.

        Called lazily from the sidebar so large trees don't block the UI
        on first paint — each folder's contents are fetched only when the
        user expands it.

        `path_str=""` means "the browse root". Any other value must be
        a directory inside the browse root; path-traversal is rejected.
        Returns `{"path": str, "entries": [...]}` or `None` on error.
        """
        if self._browse_root is None:
            return None
        try:
            root = self._browse_root.resolve()
        except OSError:
            return None
        if path_str:
            if not isinstance(path_str, str):
                return None
            try:
                target = Path(path_str).resolve()
            except OSError:
                return None
            if target != root and not target.is_relative_to(root):
                return None
        else:
            target = root
        if not target.is_dir():
            return None
        entries: list[dict] = []
        try:
            children = list(target.iterdir())
        except OSError:
            return None
        # Dirs first, then files, each alphabetical case-insensitive.
        children.sort(key=lambda p: (0 if p.is_dir() else 1, p.name.casefold()))
        for child in children:
            name = child.name
            if name.startswith("."):
                continue
            try:
                is_dir = child.is_dir()
            except OSError:
                continue
            if is_dir:
                if name in self._BROWSE_SKIP_DIRS:
                    continue
                entries.append({"type": "dir", "name": name, "path": str(child)})
            else:
                if child.suffix.lower() not in (".md", ".markdown"):
                    continue
                entries.append({"type": "file", "name": name, "path": str(child)})
        return {"path": str(target), "entries": entries}

    def open_path(self, path_str: str) -> bool:
        """Load a file selected from the sidebar.

        Validates that the path lies under `self._browse_root` and has a
        markdown suffix. Rejects anything else so a hostile caller (or a
        bug in the frontend) can't coerce an arbitrary disk read through
        this bridge method.
        """
        if self._browse_root is None or not isinstance(path_str, str) or not path_str:
            return False
        try:
            candidate = Path(path_str).resolve()
            root = self._browse_root.resolve()
        except OSError:
            return False
        if not candidate.is_relative_to(root):
            return False
        if candidate.suffix.lower() not in (".md", ".markdown"):
            return False
        if not candidate.is_file():
            return False
        self._load(candidate)
        return True

    def open_file(self) -> bool:
        if self._window is None:
            return False
        result = self._window.create_file_dialog(
            webview.OPEN_DIALOG,
            file_types=("Markdown (*.md;*.markdown)", "All files (*.*)"),
        )
        if not result:
            return False
        self._load(Path(result[0]))
        return True

    def register_association(self) -> bool:
        from .assoc import register

        ok = register() == 0
        config.set_key("association_prompted", True)
        return ok

    def decline_association(self) -> None:
        config.set_key("association_prompted", True)

    def _pick_save_path(self) -> Path | None:
        if self._window is None:
            return None
        result = self._window.create_file_dialog(
            webview.SAVE_DIALOG,
            save_filename="untitled.md",
            file_types=("Markdown (*.md)", "All files (*.*)"),
        )
        return Path(result) if result else None

    def _load(self, path: Path, reason: str = "open") -> None:
        source = path.read_text(encoding="utf-8")
        html = _render_with_frontmatter(source)
        self._current_path = path
        new_fp = _fingerprint(path)
        if reason == "watch":
            # Hold the new fingerprint in escrow — only promote if JS
            # confirms it applied the reload (via ack_reload).
            self._pending_fingerprint = new_fp
        else:
            # Explicit open / initial load / programmatic reload: the UI
            # will unconditionally replace its source, so commit baseline.
            self._loaded_fingerprint = new_fp
            self._pending_fingerprint = None
        if self._window is not None:
            payload = json.dumps({
                "html": html,
                "source": source,
                "name": path.name,
                "path": str(path),
                "reason": reason,
            })
            self._window.evaluate_js(f"window.mdvwSetDocument({payload})")


def _set_window_icon(window: webview.Window, title: str) -> None:
    """Attach the packaged icon.ico to the running window via WM_SETICON.

    pywebview 5.x exposes no icon parameter on Windows; without this the
    taskbar/titlebar keep the host exe's icon (Python.exe during dev).
    We look up the HWND by the window's current title and send two icon
    handles (big + small). Failure is non-fatal — the window just keeps
    the default icon.
    """
    if sys.platform != "win32":
        return
    ico = Path(str(ASSETS)).resolve() / "icon.ico"
    if not ico.exists():
        return
    try:
        import ctypes

        user32 = ctypes.windll.user32
        LR_LOADFROMFILE = 0x00000010
        IMAGE_ICON = 1
        WM_SETICON = 0x0080
        ICON_SMALL, ICON_BIG = 0, 1

        hwnd = user32.FindWindowW(None, title)
        if not hwnd:
            return
        big = user32.LoadImageW(None, str(ico), IMAGE_ICON, 256, 256, LR_LOADFROMFILE)
        small = user32.LoadImageW(None, str(ico), IMAGE_ICON, 16, 16, LR_LOADFROMFILE)
        if big:
            user32.SendMessageW(hwnd, WM_SETICON, ICON_BIG, big)
        if small:
            user32.SendMessageW(hwnd, WM_SETICON, ICON_SMALL, small)
    except Exception as exc:
        _stderr_print(f"[mdvw] could not set window icon: {exc!r}")


def _bring_to_front() -> None:
    """Force our window to the foreground on Windows.

    Finds the top-level window belonging to this process (by PID) and
    does a brief TOPMOST toggle + SetForegroundWindow.  Works even when
    the title has changed since creation.
    """
    if sys.platform != "win32":
        return
    try:
        import ctypes
        import ctypes.wintypes

        user32 = ctypes.windll.user32
        pid = os.getpid()
        found_hwnd = None

        WNDENUMPROC = ctypes.WINFUNCTYPE(
            ctypes.wintypes.BOOL,
            ctypes.wintypes.HWND,
            ctypes.wintypes.LPARAM,
        )

        def _enum_cb(hwnd: int, _lp: int) -> bool:
            nonlocal found_hwnd
            wp = ctypes.wintypes.DWORD()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(wp))
            if wp.value == pid and user32.IsWindowVisible(hwnd):
                found_hwnd = hwnd
                return False
            return True

        user32.EnumWindows(WNDENUMPROC(_enum_cb), 0)
        if not found_hwnd:
            return

        HWND_TOPMOST = -1
        HWND_NOTOPMOST = -2
        SWP_NOMOVE = 0x0002
        SWP_NOSIZE = 0x0001
        SWP_SHOWWINDOW = 0x0040
        flags = SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW

        user32.SetWindowPos(found_hwnd, HWND_TOPMOST, 0, 0, 0, 0, flags)
        user32.SetWindowPos(found_hwnd, HWND_NOTOPMOST, 0, 0, 0, 0, flags)
        user32.SetForegroundWindow(found_hwnd)
    except Exception as exc:
        _stderr_print(f"[mdvw] could not bring window to front: {exc!r}")


def _maybe_prompt_association(window: webview.Window) -> None:
    if sys.platform != "win32":
        return
    if config.get("association_prompted"):
        return

    def _later() -> None:
        with contextlib.suppress(Exception):
            window.evaluate_js("window.mdvwPromptAssociation && window.mdvwPromptAssociation()")

    threading.Timer(1.2, _later).start()


def _set_app_user_model_id() -> None:
    """Give the process its own AUMID so the Windows taskbar groups mdvw
    windows separately from the host Python.exe and uses our icon for
    the group thumbnail.
    """
    if sys.platform != "win32":
        return
    try:
        import ctypes

        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
            "dev.ThomasRohde.mdvw"
        )
    except Exception as exc:
        _stderr_print(f"[mdvw] could not set AUMID: {exc!r}")


def run(file: Path | None, edit: bool, tray: bool) -> int:
    # Single-instance handoff — only when the tray is on, because that's
    # the only config where an existing process is actually kept alive
    # across invocations. Without the tray, X destroys the window and
    # webview.start() returns, so there's never a server to hand off to.
    if tray and sys.platform == "win32":
        from .ipc import try_handoff

        resolved = file.resolve() if file else None
        if try_handoff(resolved):
            return 0

    _set_app_user_model_id()
    path, source = _initial_file(file)
    browse_root: Path | None = None
    try:
        browse_root = Path.cwd().resolve()
    except OSError:
        browse_root = None

    # Resolve the packaged assets dir and rewrite app-asset refs in the
    # template to absolute URLs rooted there. This avoids a document-wide
    # <base href>, which would silently reroute user-document relative
    # URLs (./image.png, ./other.md) to the assets dir.
    assets_dir = Path(str(ASSETS)).resolve()
    assets_base = assets_dir.as_uri().rstrip("/") + "/"
    html = _build_html(
        source, path, edit,
        assets_base=assets_base,
        browse_root=browse_root,
    )

    # Per-instance temp file in a user-writable location — not the package
    # dir (which may be read-only in installed envs) and with a unique
    # name (so concurrent mdvw instances don't race on a shared filename).
    instance_dir = Path(tempfile.mkdtemp(prefix="mdvw-"))
    index = instance_dir / "index.html"
    index.write_text(html, encoding="utf-8")

    api = JsApi()
    api._current_path = path
    api._browse_root = browse_root
    if path is not None:
        api._loaded_fingerprint = _fingerprint(path)

    window_title = f"{path.name if path else 'mdvw'} — mdvw"
    window = webview.create_window(
        title=window_title,
        url=index.as_uri(),
        js_api=api,
        width=1100,
        height=780,
        min_size=(600, 400),
    )
    api._window = window

    def _on_loaded() -> None:
        _set_window_icon(window, window_title)
        _bring_to_front()
        _maybe_prompt_association(window)

    window.events.loaded += _on_loaded

    tray_thread = None
    ipc_server = None
    if tray and sys.platform == "win32":
        from .tray import start_tray

        tray_thread = start_tray(window, api)

        from . import tray as tray_mod
        from .ipc import start_server

        def _on_remote_open(p: Path | None) -> None:
            # Always pop the window forward so the user sees the handoff
            # landed — matches what they'd expect from "open another file".
            with contextlib.suppress(Exception):
                window.show()
                window.restore()
            _bring_to_front()
            if tray_mod._tray_icon is not None:
                with contextlib.suppress(Exception):
                    tray_mod._tray_icon.title = "mdvw"
            if p is not None and p.exists() and p.is_file():
                with contextlib.suppress(Exception):
                    api._load(p)

        ipc_server = start_server(_on_remote_open)

    # Dirty-state guard: the closing event runs on the UI thread, so we
    # must NOT call evaluate_js here (that would block waiting on the
    # same thread it was dispatched from and hang the window). Instead
    # trust the `api._dirty` mirror updated by JS on each edit. There's
    # a small race where a user types + closes faster than the bridge
    # can mirror, but an unresponsive close is a worse UX than a rare
    # missed prompt.
    def _on_closing() -> bool:
        if api._quitting:
            return True
        if tray_thread is not None:
            # Close-to-tray: hide the window and veto the destroy. The
            # buffer (and api._dirty) live on in the hidden window; the
            # unsaved-changes prompt moves to the tray's Quit action.
            with contextlib.suppress(Exception):
                window.hide()
            return False
        if not api._dirty:
            return True
        try:
            confirm = window.create_confirmation_dialog(
                "Unsaved changes",
                "You have unsaved edits. Quit anyway?",
            )
        except Exception as exc:
            _stderr_print(
                f"[mdvw] unable to show close confirmation ({exc!r}); "
                "refusing close to protect unsaved edits."
            )
            return False
        return bool(confirm)

    window.events.closing += _on_closing

    if file and file.exists() and not edit:
        from .watcher import start_watcher

        start_watcher(file, api)

    try:
        webview.start()
    finally:
        # Clean up only our own instance files.
        with contextlib.suppress(OSError):
            index.unlink(missing_ok=True)
        with contextlib.suppress(OSError):
            instance_dir.rmdir()
        if ipc_server is not None:
            from .ipc import stop_server

            stop_server(ipc_server)
        if tray_thread is not None:
            from .tray import stop_tray

            stop_tray()
    return 0
