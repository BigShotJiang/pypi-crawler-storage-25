"""
Summary Data Types for Phase 4.2

Contains data models for chapter summaries, group summaries,
global summaries, and storage configuration.
"""

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List

from pydantic import BaseModel


@dataclass
class ChapterSummary:
    """Summary of a single chapter."""

    chapter_number: int
    summary: str
    key_events: List[str]
    characters: Dict[str, str]
    locations: Dict[str, str]
    plot_advancement: str
    next_chapter_setup: str
    created_at: datetime
    word_count: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "chapter_number": self.chapter_number,
            "summary": self.summary,
            "key_events": self.key_events,
            "characters": self.characters,
            "locations": self.locations,
            "plot_advancement": self.plot_advancement,
            "next_chapter_setup": self.next_chapter_setup,
            "created_at": self.created_at.isoformat(),
            "word_count": self.word_count,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ChapterSummary":
        """Create from dictionary."""
        return cls(
            chapter_number=data["chapter_number"],
            summary=data["summary"],
            key_events=data["key_events"],
            characters=data["characters"],
            locations=data["locations"],
            plot_advancement=data["plot_advancement"],
            next_chapter_setup=data["next_chapter_setup"],
            created_at=datetime.fromisoformat(data["created_at"]),
            word_count=data.get("word_count", 0),
        )


@dataclass
class GroupSummary:
    """Summary of a group of chapters (typically 5)."""

    group_id: str
    start_chapter: int
    end_chapter: int
    summary: str
    combined_events: List[str]
    character_arcs: Dict[str, str]
    plot_developments: List[str]
    created_at: datetime
    total_word_count: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "group_id": self.group_id,
            "start_chapter": self.start_chapter,
            "end_chapter": self.end_chapter,
            "summary": self.summary,
            "combined_events": self.combined_events,
            "character_arcs": self.character_arcs,
            "plot_developments": self.plot_developments,
            "created_at": self.created_at.isoformat(),
            "total_word_count": self.total_word_count,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "GroupSummary":
        """Create from dictionary."""
        return cls(
            group_id=data["group_id"],
            start_chapter=data["start_chapter"],
            end_chapter=data["end_chapter"],
            summary=data["summary"],
            combined_events=data["combined_events"],
            character_arcs=data["character_arcs"],
            plot_developments=data["plot_developments"],
            created_at=datetime.fromisoformat(data["created_at"]),
            total_word_count=data.get("total_word_count", 0),
        )


@dataclass
class GlobalSummary:
    """Global summary of the entire novel."""

    project_name: str
    summary: str
    main_plot_arc: str
    character_arcs: Dict[str, str]
    world_development: str
    themes: List[str]
    last_updated: datetime
    total_chapters_covered: int
    total_word_count: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "project_name": self.project_name,
            "summary": self.summary,
            "main_plot_arc": self.main_plot_arc,
            "character_arcs": self.character_arcs,
            "world_development": self.world_development,
            "themes": self.themes,
            "last_updated": self.last_updated.isoformat(),
            "total_chapters_covered": self.total_chapters_covered,
            "total_word_count": self.total_word_count,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "GlobalSummary":
        """Create from dictionary."""
        return cls(
            project_name=data["project_name"],
            summary=data["summary"],
            main_plot_arc=data["main_plot_arc"],
            character_arcs=data["character_arcs"],
            world_development=data["world_development"],
            themes=data["themes"],
            last_updated=datetime.fromisoformat(data["last_updated"]),
            total_chapters_covered=data["total_chapters_covered"],
            total_word_count=data.get("total_word_count", 0),
        )


class SummaryStoreConfig(BaseModel):
    """Configuration for summary storage."""

    storage_format: str = "yaml"  # yaml or json
    auto_backup: bool = True
    backup_count: int = 3
    compress_old_summaries: bool = False
