"""Step executor for running workflow steps."""

import logging
import random
import time
from concurrent.futures import Future, ThreadPoolExecutor
from concurrent.futures import TimeoutError as FuturesTimeoutError
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from .hooks.models import StepRetryPolicy
from .message_formatter import MessageFormatter
from .orchestrator_agent_integration import AgentSystemIntegration
from .run_logger import RunLogger
from .runtime.error_taxonomy import classify_exception
from .storage import StorageBackend
from .system_actions import SystemActionHandler
from .variable_resolver import VariableResolver
from .workflow_loader import OnFailure, WorkflowStep

if TYPE_CHECKING:
    from .secrets import SecretStore

# Re-export for backward compatibility
__all__ = ["StepExecutor", "SystemActionHandler", "StepExecutionError"]


class StepExecutionError(Exception):
    """Raised when a workflow step fails and execution must stop."""


class StepExecutor:
    """Execute workflow steps."""

    def __init__(
        self,
        agent_integration: AgentSystemIntegration,
        storage: StorageBackend,
        git_manager,
        work_dir: str | Path = None,
        run_logger: Optional[RunLogger] = None,
        secret_store: Optional["SecretStore"] = None,
    ):
        """Initialize step executor.

        Args:
            agent_integration: Agent system integration
            storage: Storage backend
            git_manager: Git manager
            work_dir: Working directory
            run_logger: Optional run logger for structured event emission
            secret_store: Optional secret store for ${secrets.*} resolution
        """
        self.agent_integration = agent_integration
        self.storage = storage
        self.git_manager = git_manager
        self.work_dir = Path(work_dir) if work_dir else Path.cwd()
        self.run_logger = run_logger
        self.secret_store = secret_store
        self.resolver = VariableResolver(secret_store=secret_store)
        self.system_handler = SystemActionHandler(storage, git_manager, work_dir)
        self.logger = logging.getLogger(__name__)
        self._msg = MessageFormatter()

    def execute_step(
        self,
        step: WorkflowStep,
        project_name: str,
        variables: Dict[str, Any],
        step_outputs: Dict[str, Any],
        config: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Execute a workflow step with optional retry and timeout.

        Args:
            step: Step to execute
            project_name: Project name
            variables: Workflow variables
            step_outputs: Outputs from previous steps
            config: LLM configuration

        Returns:
            Step execution result
        """
        try:
            if step.condition:
                condition_met = self.resolver.evaluate_condition(
                    step.condition, variables, step_outputs
                )

                if not condition_met:
                    self.logger.info(
                        self._msg.format("step_skipped", step=step.step, name=step.name)
                    )
                    return {"step": step.step, "name": step.name, "skipped": True, "success": True}

            resolved_input = self.resolver.resolve_dict(step.input, variables, step_outputs)

            if step.retry is not None:
                result = self._execute_with_retry(
                    step, project_name, resolved_input, variables, config
                )
            elif step.timeout_sec is not None:
                result = self._execute_with_timeout(
                    step, project_name, resolved_input, variables, config
                )
            else:
                result = self._execute_core(step, project_name, resolved_input, variables, config)

            if not result.get("success") and step.on_failure == OnFailure.STOP:
                if step.on_rollback:
                    self._execute_rollback(step, project_name, variables, step_outputs, config)
                raise StepExecutionError(f"Step failed and on_failure=stop: {step.name}")

            resolved_output = self.resolver.resolve_dict(
                step.output, variables, {**step_outputs, **result}
            )

            return self._validate_output(
                step,
                {
                    "step": step.step,
                    "name": step.name,
                    "success": result.get("success", True),
                    "output": resolved_output,
                    "skipped": False,
                    "error": self._redact(result.get("error")),
                    "attempts": result.get("attempts", 1),
                },
            )

        except Exception as e:
            self.logger.error(self._msg.format("step_failed", name=step.name, error=str(e)))

            if step.on_rollback:
                self._execute_rollback(step, project_name, variables, step_outputs, config)

            if step.on_failure == OnFailure.STOP:
                raise

            return {
                "step": step.step,
                "name": step.name,
                "success": False,
                "error": self._redact(str(e)),
                "skipped": False,
            }

    def _redact(self, text: Optional[str]) -> Optional[str]:
        """Redact known secret values from text."""
        if text is None or self.secret_store is None:
            return text
        return self.secret_store.redact(text)

    def _validate_output(
        self,
        step: WorkflowStep,
        result: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Validate step output against declared JSON Schema.

        Non-blocking by default: validation errors are logged and
        attached to the result dict.  Set config key
        ``strict_output_validation`` to ``True`` to make it blocking.
        """
        schema = step.output_schema
        if not schema:
            return result

        strict = getattr(self, "_strict_output_validation", False)

        errors: List[str] = self._check_schema(result.get("output", {}), schema)

        if not errors:
            return result

        self.logger.warning(
            "Output schema validation failed for step %s: %s",
            step.name,
            "; ".join(errors),
        )
        result["output_validation_errors"] = errors

        if strict:
            result["success"] = False
            result["error"] = f"Output validation failed: {'; '.join(errors)}"

        return result

    @staticmethod
    def _check_schema(
        data: Any,
        schema: Dict[str, Any],
        path: str = "",
    ) -> List[str]:
        """Minimal JSON Schema checker (type, required, properties)."""
        errors: List[str] = []

        if "type" in schema:
            expected = schema["type"]
            type_map = {
                "string": str,
                "integer": int,
                "number": (int, float),
                "boolean": bool,
                "array": list,
                "object": dict,
            }
            expected_type = type_map.get(expected)
            if expected_type and not isinstance(data, expected_type):
                errors.append(f"{path or '$'}: expected type {expected}, got {type(data).__name__}")
                return errors

        if isinstance(data, dict):
            required = schema.get("required", [])
            for field in required:
                if field not in data:
                    errors.append(f"{path}.{field}: required field missing")

            properties = schema.get("properties", {})
            for key, prop_schema in properties.items():
                if key in data:
                    errors.extend(
                        StepExecutor._check_schema(data[key], prop_schema, f"{path}.{key}")
                    )

        if isinstance(data, list) and "items" in schema:
            for i, item in enumerate(data):
                errors.extend(StepExecutor._check_schema(item, schema["items"], f"{path}[{i}]"))

        return errors

    def _execute_rollback(
        self,
        step: WorkflowStep,
        project_name: str,
        variables: Dict[str, Any],
        step_outputs: Dict[str, Any],
        config: Dict[str, Any],
    ) -> None:
        """Execute rollback action on step failure."""
        rollback_config = step.on_rollback
        if not rollback_config:
            return
        try:
            action_name = rollback_config.get("action")
            if action_name:
                self.system_handler.execute_action(
                    action_name=action_name,
                    project_name=project_name,
                    params=rollback_config.get("input", {}),
                )
                self.logger.info(f"Rollback executed for step {step.name}")
        except Exception as rollback_exc:
            self.logger.warning(f"Rollback failed for step {step.name}: {rollback_exc}")

    def _compute_backoff(self, policy: StepRetryPolicy, attempt: int) -> float:
        """Compute backoff delay in seconds for the given attempt."""
        if policy.backoff_strategy == "exponential":
            delay_ms = policy.backoff_ms * (2 ** (attempt - 1))
            jitter_ms = random.uniform(0, policy.backoff_ms / 2)
            delay_ms += jitter_ms
        else:
            delay_ms = policy.backoff_ms
        return min(delay_ms, 30000) / 1000.0

    def _execute_with_retry(
        self,
        step: WorkflowStep,
        project_name: str,
        resolved_input: Dict[str, Any],
        variables: Dict[str, Any],
        config: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Execute step with retry policy based on error classification."""
        policy = step.retry
        last_error: str | None = None

        for attempt in range(1, policy.max_attempts + 1):
            try:
                if step.timeout_sec is not None:
                    result = self._execute_with_timeout(
                        step, project_name, resolved_input, variables, config
                    )
                else:
                    result = self._execute_core(
                        step, project_name, resolved_input, variables, config
                    )

                if result.get("success", True):
                    result["attempts"] = attempt
                    return result

                last_error = result.get("error", "unknown error")
                self.logger.warning(
                    f"Step {step.name} attempt {attempt}/{policy.max_attempts} failed: {last_error}"
                )

            except Exception as exc:
                category, retryable = classify_exception(exc)
                if category.value not in policy.retry_on:
                    self.logger.info(
                        f"Step {step.name} error category '{category.value}' "
                        "not in retry_on, propagating"
                    )
                    raise

                last_error = str(exc)
                self.logger.warning(
                    f"Step {step.name} attempt {attempt}/{policy.max_attempts} "
                    f"error ({category.value}): {last_error}"
                )

            if attempt < policy.max_attempts:
                backoff = self._compute_backoff(policy, attempt)
                self.logger.debug(f"Step {step.name} retry backoff: {backoff:.2f}s")
                time.sleep(backoff)

        return {
            "success": False,
            "error": f"Step failed after {policy.max_attempts} attempts: {last_error}",
            "attempts": policy.max_attempts,
        }

    def _execute_with_timeout(
        self,
        step: WorkflowStep,
        project_name: str,
        resolved_input: Dict[str, Any],
        variables: Dict[str, Any],
        config: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Execute step with timeout enforcement via thread pool."""
        executor = ThreadPoolExecutor(max_workers=1)
        try:
            future: Future = executor.submit(
                self._execute_core, step, project_name, resolved_input, variables, config
            )
            return future.result(timeout=step.timeout_sec)
        except FuturesTimeoutError:
            self.logger.error(f"Step {step.name} timed out after {step.timeout_sec}s")
            return {
                "success": False,
                "error": f"Step timed out after {step.timeout_sec}s",
            }
        finally:
            executor.shutdown(wait=False)

    def _execute_core(
        self,
        step: WorkflowStep,
        project_name: str,
        resolved_input: Dict[str, Any],
        variables: Dict[str, Any],
        config: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Core step execution dispatching to agent, workflow, or system action."""
        if step.agent:
            return self._execute_agent_step(step, project_name, resolved_input, config)
        elif step.workflow:
            return self._execute_workflow_step(
                step, project_name, resolved_input, variables, config
            )
        elif step.action:
            return self._execute_system_action(step, project_name, resolved_input)
        else:
            raise ValueError(f"Step must have agent, workflow, or action: {step.name}")

    def _execute_agent_step(
        self,
        step: WorkflowStep,
        project_name: str,
        input_data: Dict[str, Any],
        config: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Execute agent step.

        Args:
            step: Step to execute
            project_name: Project name
            input_data: Resolved input data
            config: LLM configuration

        Returns:
            Execution result
        """
        t0 = time.monotonic()
        result = self.agent_integration.execute_agent_step(
            agent_name=step.agent,
            project_name=project_name,
            step_context={"input_data": input_data, "variables": {}, "previous_outputs": {}},
            config=config,
        )
        elapsed_ms = int((time.monotonic() - t0) * 1000)

        if self.run_logger is not None:
            self.run_logger.emit(
                "agent_complete",
                {
                    "agent": step.agent,
                    "step": step.step,
                    "step_name": step.name,
                    "duration_ms": elapsed_ms,
                    "success": result.get("success", True),
                },
            )

        return result

    def _execute_workflow_step(
        self,
        step: WorkflowStep,
        project_name: str,
        input_data: Dict[str, Any],
        variables: Dict[str, Any],
        config: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Execute nested workflow step.

        Args:
            step: Step to execute
            project_name: Project name
            input_data: Resolved input data
            variables: Workflow variables
            config: LLM configuration

        Returns:
            Execution result
        """
        from .workflow_executor import WorkflowExecutor

        executor = WorkflowExecutor(
            workflows_dir=self.work_dir / "workflows",
            agent_integration=self.agent_integration,
            storage=self.storage,
            git_manager=self.git_manager,
            work_dir=self.work_dir,
        )

        merged_variables = {**variables, **input_data}

        result = executor.execute_workflow(
            workflow_name=step.workflow,
            project_name=project_name,
            variables=merged_variables,
            config=config,
        )

        return result

    def _execute_system_action(
        self, step: WorkflowStep, project_name: str, input_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Execute system action step.

        Args:
            step: Step to execute
            project_name: Project name
            input_data: Resolved input data

        Returns:
            Execution result
        """
        return self.system_handler.execute_action(
            action=step.action, input_data=input_data, project_name=project_name
        )
