"""Context Assembly — select and order context blocks from the store.

The ContextAssembler maps an agent's declared context_needs (AgentContextSchema)
to artifacts in the ContextStore, producing an ordered list of ContextBlocks.
The assembler does NOT enforce the token budget — that is the compressor's job.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, List, Optional

from pydantic import BaseModel, Field

from core.context_schema import AgentContextSchema, ContextNeed, TokenBudget
from core.context_store import ArtifactFilter, ContextArtifact, ContextStore
from core.token_estimator import TokenEstimator

if TYPE_CHECKING:
    from core.phase_context_cache import PhaseContextCache

NON_COMPRESSIBLE_TYPES = frozenset({"meta", "outline"})


class ContextBlock(BaseModel):
    """A single context block for assembly, produced by ContextAssembler."""

    source: str = Field(..., description="Artifact type (e.g. meta, chapter)")
    priority: int = Field(..., description="0=required, 1=optional — lower is higher priority")
    content: str = Field(..., description="Block text content")
    token_count: int = Field(..., ge=0, description="Pre-computed token count")
    compressible: bool = Field(default=True, description="Whether this block can be compressed")
    label: str = Field(default="", description="Human-readable label for debugging")


class ContextAssembler:
    """Select and order context blocks based on agent schema and store contents.

    Assembly algorithm:
    1. For each ContextNeed in schema.required → gather → ContextBlock (priority 0)
    2. For each ContextNeed in schema.optional → gather → ContextBlock (priority 1)
    3. Sort optional blocks by relevance (newest first)
    4. Return ordered block list
    """

    def assemble(
        self,
        schema: AgentContextSchema,
        budget: TokenBudget,
        store: ContextStore,
        phase_cache: Optional["PhaseContextCache"] = None,
    ) -> List[ContextBlock]:
        """Assemble context blocks from store based on agent schema.

        Args:
            schema: Agent's declared context needs.
            budget: Token budget (used for informational purposes).
            store: Persistent artifact store.
            phase_cache: Optional in-memory cache; checked before store.

        Returns:
            Ordered list of ContextBlocks (required first, then optional).
        """
        blocks: List[ContextBlock] = []

        for need in schema.required:
            blocks.extend(
                self._gather_blocks(need, priority=0, store=store, phase_cache=phase_cache)
            )

        for need in schema.optional:
            blocks.extend(
                self._gather_blocks(need, priority=1, store=store, phase_cache=phase_cache)
            )

        self._sort_optional_by_relevance(blocks)

        return blocks

    def _gather_blocks(
        self,
        need: ContextNeed,
        priority: int,
        store: ContextStore,
        phase_cache: Optional["PhaseContextCache"] = None,
    ) -> List[ContextBlock]:
        """Gather ContextBlocks for a single ContextNeed.

        Maps need.scope to the appropriate store query.
        """
        artifacts = self._query_store(need, store, phase_cache=phase_cache)
        blocks: List[ContextBlock] = []

        for artifact in artifacts:
            content = artifact.content or ""
            token_count = artifact.token_count or TokenEstimator.estimate_tokens(content)

            if need.max_tokens is not None and token_count > need.max_tokens:
                content = self._truncate_content(content, need.max_tokens)
                token_count = need.max_tokens

            compressible = need.artifact_type not in NON_COMPRESSIBLE_TYPES
            label = self._make_label(need, artifact)

            blocks.append(
                ContextBlock(
                    source=need.artifact_type,
                    priority=priority,
                    content=content,
                    token_count=token_count,
                    compressible=compressible,
                    label=label,
                )
            )

        return blocks

    def _query_store(
        self,
        need: ContextNeed,
        store: ContextStore,
        phase_cache: Optional["PhaseContextCache"] = None,
    ) -> List[ContextArtifact]:
        """Map ContextNeed scope to ContextStore query (cache-first)."""
        source = phase_cache if phase_cache is not None else store

        if need.scope == "latest":
            artifact = source.get_latest_by_type(need.artifact_type)
            return [artifact] if artifact is not None else []

        if need.scope == "recent":
            all_artifacts = source.query(ArtifactFilter(artifact_type=need.artifact_type))
            all_artifacts.sort(
                key=lambda a: a.chapter_number or 0,
                reverse=True,
            )
            return all_artifacts[: need.recent_count]

        if need.scope == "all":
            return source.query(ArtifactFilter(artifact_type=need.artifact_type))

        if need.scope == "group":
            return source.get_summaries()

        return []

    def _sort_optional_by_relevance(self, blocks: List[ContextBlock]) -> None:
        """Sort optional blocks (priority 1) by relevance — newest first.

        Required blocks (priority 0) maintain their declaration order.
        """
        required = [b for b in blocks if b.priority == 0]
        optional = [b for b in blocks if b.priority == 1]

        optional.sort(key=lambda b: b.label, reverse=False)

        blocks.clear()
        blocks.extend(required)
        blocks.extend(optional)

    def _truncate_content(self, content: str, max_tokens: int) -> str:
        """Truncate content to approximately max_tokens."""
        if not content:
            return content

        estimated = TokenEstimator.estimate_tokens(content)
        if estimated <= max_tokens:
            return content

        char_ratio = max_tokens / estimated
        target_chars = int(len(content) * char_ratio)
        truncated = content[:target_chars]

        last_newline = truncated.rfind("\n")
        if last_newline > target_chars // 2:
            truncated = truncated[:last_newline]

        return truncated

    def _make_label(self, need: ContextNeed, artifact: ContextArtifact) -> str:
        """Create a human-readable label for a context block."""
        parts = [need.artifact_type]

        if artifact.chapter_number is not None:
            parts.append(str(artifact.chapter_number))

        parts.append(f"({need.scope})")

        return " ".join(parts)
