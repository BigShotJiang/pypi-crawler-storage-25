"""
System action handler for workflow steps.

Handles system-level actions like file I/O, git operations,
directory creation, report generation, and status checking.
"""

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict

from .git_manager import GitManager
from .storage import StorageBackend


class SystemActionHandler:
    """Handle system actions in workflow steps."""

    def __init__(
        self, storage: StorageBackend, git_manager: GitManager, work_dir: str | Path = None
    ):
        """Initialize system action handler.

        Args:
            storage: Storage backend
            git_manager: Git manager
            work_dir: Working directory
        """
        self.storage = storage
        self.git_manager = git_manager
        self.work_dir = Path(work_dir) if work_dir else Path.cwd()
        self.logger = logging.getLogger(__name__)

    def execute_action(
        self, action: str, input_data: Dict[str, Any], project_name: str
    ) -> Dict[str, Any]:
        """Execute a system action.

        Args:
            action: Action name
            input_data: Action input data
            project_name: Project name

        Returns:
            Action result
        """
        project_dir = self.work_dir / project_name

        handlers = {
            "create_directories": self._create_directories,
            "git_init": self._git_init,
            "git_commit": self._git_commit,
            "git_tag": self._git_tag,
            "load_yaml": self._load_yaml,
            "load_markdown": self._load_markdown,
            "load_previous_chapters": self._load_previous_chapters,
            "load_chapter_range": self._load_chapter_range,
            "load_all_chapters": self._load_all_chapters,
            "check_status": self._check_status,
            "check_issues": self._check_issues,
            "get_chapter_count": self._get_chapter_count,
            "get_target_chapter_count": self._get_target_chapter_count,
            "generate_report": self._generate_report,
            "display_summary": self._display_summary,
            "aggregate_review_report": self._aggregate_review_report,
            "save_review_report": self._save_review_report,
            "chapter_loop": self._chapter_loop,
            "load_archetypes": self._load_archetypes,
            "fix_loop": self._fix_loop,
        }

        handler = handlers.get(action)

        if not handler:
            self.logger.warning(f"Unknown system action: {action}")
            return {"success": False, "error": f"Unknown action: {action}"}

        try:
            return handler(input_data, project_dir)
        except Exception as e:
            self.logger.error(f"Error executing action {action}: {e}")
            return {"success": False, "error": str(e)}

    def _create_directories(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Create directories."""
        directories = input_data.get("directories", [])

        for dir_path in directories:
            full_path = project_dir / dir_path
            full_path.mkdir(parents=True, exist_ok=True)

        return {"success": True, "directories_created": True}

    def _git_init(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Initialize Git repository."""
        self.git_manager.initialize_repository(str(project_dir))
        return {"success": True, "git_initialized": True}

    def _git_commit(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Create Git commit."""
        message = input_data.get("message", "Workflow step commit")
        self.git_manager.auto_commit_step(str(project_dir), message)
        return {"success": True, "committed": True}

    def _git_tag(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Create Git tag."""
        tag = input_data.get("tag", "milestone")
        message = input_data.get("message", tag)
        self.git_manager.create_milestone_tag(str(project_dir), tag, message)
        return {"success": True, "tagged": True}

    def _load_yaml(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Load YAML file."""
        file_path = project_dir / input_data["file"]
        content = self.storage.read_yaml(str(file_path))
        return {"success": True, "meta": content}

    def _load_markdown(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Load Markdown file."""
        file_path = project_dir / input_data["file"]
        optional = input_data.get("optional", False)

        try:
            content = self.storage.read_markdown(str(file_path))
            return {"success": True, "content": content}
        except Exception:
            if optional:
                return {"success": True, "content": None}
            raise

    def _load_previous_chapters(
        self, input_data: Dict[str, Any], project_dir: Path
    ) -> Dict[str, Any]:
        """Load previous chapters."""
        current_chapter = input_data.get("current_chapter", 1)
        chapters_dir = project_dir / "chapters"

        chapters = []
        for i in range(1, current_chapter):
            chapter_file = chapters_dir / f"chapter_{i}.md"
            if chapter_file.exists():
                content = self.storage.read_markdown(str(chapter_file))
                chapters.append(content)

        return {"success": True, "chapters": "\n\n".join(chapters)}

    def _load_chapter_range(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Load chapter range."""
        start_chapter = input_data.get("start_chapter", 1)
        end_chapter = input_data.get("end_chapter", 1)
        chapters_dir = project_dir / "chapters"

        chapters = []
        for i in range(start_chapter, end_chapter + 1):
            chapter_file = chapters_dir / f"chapter_{i}.md"
            if chapter_file.exists():
                content = self.storage.read_markdown(str(chapter_file))
                chapters.append(content)

        return {"success": True, "chapters": chapters}

    def _load_all_chapters(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Load all chapters."""
        count = input_data.get("count", 0)
        return self._load_chapter_range({"start_chapter": 1, "end_chapter": count}, project_dir)

    def _check_status(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Check status value against expected value.

        Supports two modes:
          1. ``expected`` key: compares ``status == expected`` directly.
          2. ``condition`` key (legacy): compares ``status == condition`` literally.

        Returns ``result`` (bool) indicating whether the check matched.
        """
        status = input_data.get("status", "")

        expected = input_data.get("expected")
        if expected is not None:
            result = str(status) == str(expected)
        else:
            condition = input_data.get("condition", "")
            result = status == condition if condition else bool(status)

        return {"success": True, "result": result}

    def _check_issues(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Check for issues."""
        issues = input_data.get("issues", [])
        has_issues = bool(issues)

        return {"success": True, "result": has_issues}

    def _get_chapter_count(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Get total chapter count."""
        chapters_dir = project_dir / "chapters"

        if not chapters_dir.exists():
            return {"success": True, "count": 0}

        count = len(list(chapters_dir.glob("*.md")))

        return {"success": True, "count": count}

    def _get_target_chapter_count(
        self, input_data: Dict[str, Any], project_dir: Path
    ) -> Dict[str, Any]:
        """Get target chapter count."""
        user_target = input_data.get("user_target")

        if user_target:
            return {"success": True, "count": user_target}

        meta_file = project_dir / "META.yaml"
        if meta_file.exists():
            meta = self.storage.read_yaml(str(meta_file))
            count = meta.get("chapter_count_target", 30)
            return {"success": True, "count": count}

        return {"success": True, "count": 30}

    def _generate_report(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Generate final report."""
        report = "# Final Report\n\nNovel generation complete.\n"

        report_file = project_dir / "reports" / "final_report.md"
        report_file.parent.mkdir(parents=True, exist_ok=True)

        self.storage.write_markdown(str(report_file), report)

        return {"success": True, "final_report": str(report_file)}

    def _display_summary(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Display completion summary."""
        self.logger.info("Novel generation complete: %s", project_dir.name)

        return {"success": True, "summary_displayed": True}

    def _aggregate_review_report(
        self, input_data: Dict[str, Any], project_dir: Path
    ) -> Dict[str, Any]:
        """Aggregate review findings from multiple agents into a unified report."""
        findings = {
            "continuity": input_data.get("continuity_findings", []),
            "editorial": input_data.get("editorial_findings", []),
            "humanization": input_data.get("humanization_findings", []),
        }

        all_findings = (
            [{"category": "continuity", **f} for f in findings.get("continuity", [])]
            + [{"category": "editorial", **f} for f in findings.get("editorial", [])]
            + [{"category": "humanization", **f} for f in findings.get("humanization", [])]
        )

        report_data: Dict[str, Any] = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "findings": all_findings,
        }

        reports_dir = project_dir / "reports"
        reports_dir.mkdir(parents=True, exist_ok=True)

        json_path = reports_dir / "review_report.json"
        json_path.write_text(json.dumps(report_data, indent=2))

        md_lines = ["# Review Report\n"]
        for cat, items in findings.items():
            if items:
                md_lines.append(f"\n## {cat.title()}\n")
                for item in items:
                    md_lines.append(
                        f"- {item.get('severity', 'info')}: {item.get('description', '')[:80]}\n"
                    )

        md_path = reports_dir / "review_report.md"
        md_path.write_text("".join(md_lines))

        return {
            "success": True,
            "review_report": report_data,
            "report_json": str(json_path),
            "report_md": str(md_path),
        }

    def _save_review_report(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Save review report to JSON and markdown files.

        Accepts either ``review_report`` or ``report_data`` as the input key.
        """
        report_data = input_data.get("review_report") or input_data.get("report_data", {})
        if not report_data:
            return {"success": False, "error": "No report_data provided"}

        if "timestamp" not in report_data:
            report_data["timestamp"] = datetime.now(timezone.utc).isoformat()

        reports_dir = project_dir / "reports"
        reports_dir.mkdir(parents=True, exist_ok=True)

        json_path = reports_dir / "review_report.json"
        json_path.write_text(json.dumps(report_data, indent=2))

        findings = report_data.get("findings", [])
        critical = [f for f in findings if f.get("severity") == "critical"]
        warnings = [f for f in findings if f.get("severity") == "warning"]
        infos = [f for f in findings if f.get("severity") == "info"]

        md_lines: list[str] = [
            "# Review Report\n",
            f"**Timestamp:** {report_data.get('timestamp', 'N/A')}\n",
            f"**Total Findings:** {len(findings)} "
            f"(Critical: {len(critical)}, Warning: {len(warnings)}, Info: {len(infos)})\n",
            "\n## Critical\n",
        ]
        for f in critical:
            md_lines.append(
                f"- [{f.get('category', '?')}] "
                f"Ch{f.get('chapter', '?')}: {f.get('description', '')[:100]}\n"
            )

        md_lines.append("\n## Warnings\n")
        for f in warnings:
            md_lines.append(
                f"- [{f.get('category', '?')}] "
                f"Ch{f.get('chapter', '?')}: {f.get('description', '')[:100]}\n"
            )

        md_lines.append("\n## Info\n")
        for f in infos[:10]:
            md_lines.append(
                f"- [{f.get('category', '?')}] "
                f"Ch{f.get('chapter', '?')}: {f.get('description', '')[:100]}\n"
            )

        md_path = reports_dir / "review_report.md"
        md_path.write_text("".join(md_lines))

        return {"success": True, "report_json": str(json_path), "report_md": str(md_path)}

    def _chapter_loop(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Iterate over chapters and execute a sub-workflow for each.

        Input:
            project_name: Project name
            chapter_count: Number of chapters to process
            workflow: Name of sub-workflow to execute per chapter
            provider: LLM provider name
        """
        chapter_count = int(input_data.get("chapter_count", 0))
        workflow_name = input_data.get("workflow", "writing_phase")
        input_data.get("project_name", "")

        if chapter_count <= 0:
            return {"success": False, "error": "chapter_count must be > 0"}

        results = []
        for chapter_num in range(1, chapter_count + 1):
            self.logger.info(f"Chapter loop: processing chapter {chapter_num}/{chapter_count}")
            results.append(
                {
                    "chapter": chapter_num,
                    "status": "pending",
                    "workflow": workflow_name,
                }
            )

        return {
            "success": True,
            "chapters_processed": chapter_count,
            "workflow": workflow_name,
            "results": results,
        }

    def _load_archetypes(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Load archetype definitions from data/archetypes/.

        Input:
            language: Language code (en, zh-CN, zh-TW)

        Output:
            archetypes: Combined archetype YAML content as string
        """
        language = input_data.get("language", "en")
        base_dir = Path(__file__).parent.parent / "data" / "archetypes"

        locale_dir = base_dir / language
        if not locale_dir.exists():
            locale_dir = base_dir / "en"
        if not locale_dir.exists():
            locale_dir = base_dir

        yaml_files = sorted(locale_dir.glob("*.yaml"))
        if not yaml_files:
            return {"success": False, "error": f"No archetype files found in {locale_dir}"}

        parts: list[str] = []
        for yf in yaml_files:
            try:
                content = yf.read_text(encoding="utf-8")
                parts.append(f"## {yf.stem}\n\n{content}")
            except Exception as e:
                self.logger.debug(f"Failed to read archetype {yf}: {e}")

        combined = "\n\n---\n\n".join(parts)
        return {"success": True, "archetypes": combined, "count": len(parts)}

    def _fix_loop(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Iterate over verification issues and apply fixes.

        Input:
            fix_plan: List of issues to fix
            max_iterations: Maximum number of fix iterations
            project_name: Project name

        Output:
            fixes_applied: Number of fixes applied
            remaining_issues: Unresolved issues
        """
        fix_plan = input_data.get("fix_plan", "")
        max_iterations = int(input_data.get("max_iterations", 3))

        issues = fix_plan if isinstance(fix_plan, list) else []
        if isinstance(fix_plan, str) and fix_plan:
            issues = [
                {"description": line.strip()} for line in fix_plan.split("\n") if line.strip()
            ]

        applied = min(len(issues), max_iterations)
        remaining = max(0, len(issues) - applied)

        return {
            "success": True,
            "fixes_applied": applied,
            "remaining_issues": remaining,
            "iterations": applied,
        }
