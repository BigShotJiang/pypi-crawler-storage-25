"""
Memory Monitor Implementation for Phase 4.3

Provides real-time memory monitoring with threshold-based
actions and trend analysis.
"""

import logging
import threading
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

from pydantic import BaseModel

from core.memory_profiler import MemoryProfiler

logger = logging.getLogger(__name__)


class MemoryAction(Enum):
    """Actions to take when thresholds are triggered."""

    LOG = "log"
    PRUNE = "prune"
    CLEAR = "clear"
    ERROR = "error"


@dataclass
class MemoryThreshold:
    """Memory threshold with associated action."""

    name: str
    warning_mb: float
    critical_mb: float
    action: MemoryAction
    action_callback: Optional[Callable[[], None]] = None

    def check(self, current_mb: float) -> Optional[str]:
        """
        Check if threshold is triggered.

        Args:
            current_mb: Current memory usage in MB

        Returns:
            Status: None, "warning", or "critical"
        """
        if current_mb >= self.critical_mb:
            return "critical"
        elif current_mb >= self.warning_mb:
            return "warning"
        return None


class MemoryMonitorConfig(BaseModel):
    """Configuration for memory monitor."""

    check_interval_seconds: int = 30
    enable_trend_analysis: bool = True
    trend_window_seconds: int = 300
    enable_alerts: bool = True
    enable_auto_actions: bool = True
    log_threshold_triggers: bool = True


class MemoryMonitor:
    """
    Real-time memory monitoring system.

    Features:
    - Threshold-based monitoring
    - Automatic actions
    - Trend analysis
    - Alert system
    - Integration with profiler
    """

    def __init__(
        self,
        thresholds: List[MemoryThreshold],
        config: Optional[MemoryMonitorConfig] = None,
        profiler: Optional[MemoryProfiler] = None,
    ):
        """
        Initialize memory monitor.

        Args:
            thresholds: List of thresholds to monitor
            config: Monitor configuration
            profiler: Optional memory profiler
        """
        self.thresholds = thresholds
        self.config = config or MemoryMonitorConfig()
        self.profiler = profiler or MemoryProfiler()

        self.monitoring = False
        self.monitor_thread: Optional[threading.Thread] = None
        self.stop_event = threading.Event()

        self.triggered_actions: List[Dict[str, Any]] = []
        self.memory_history: List[tuple[datetime, float]] = []
        self.max_history_size = 1000

        self.alert_callbacks: List[Callable[[str, float], None]] = []

    def start_monitoring(self):
        """Start automatic memory monitoring."""
        if self.monitoring:
            return

        self.monitoring = True
        self.stop_event.clear()

        self.monitor_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitor_thread.start()

        if self.profiler:
            self.profiler.start_profiling(self.config.check_interval_seconds)

    def stop_monitoring(self):
        """Stop automatic memory monitoring."""
        if not self.monitoring:
            return

        self.monitoring = False
        self.stop_event.set()

        if self.monitor_thread:
            self.monitor_thread.join(timeout=5.0)
            self.monitor_thread = None

        if self.profiler:
            self.profiler.stop_profiling()

    def _monitoring_loop(self):
        """Background monitoring loop."""
        while not self.stop_event.is_set():
            try:
                self.check_memory()
            except Exception as e:
                if self.config.log_threshold_triggers:
                    print(f"Error in memory monitoring: {e}")

            self.stop_event.wait(self.config.check_interval_seconds)

    def check_memory(self) -> bool:
        """
        Check current memory usage against thresholds.

        Returns:
            True if all checks passed, False otherwise
        """
        current_mb = self.get_current_usage()

        self._record_memory(current_mb)

        all_passed = True

        for threshold in self.thresholds:
            status = threshold.check(current_mb)

            if status:
                all_passed = False

                if self.config.log_threshold_triggers:
                    self._log_threshold_trigger(threshold, current_mb, status)

                if self.config.enable_alerts:
                    self._send_alert(threshold, current_mb, status)

                if self.config.enable_auto_actions:
                    self.trigger_action(threshold, status)

        return all_passed

    def get_current_usage(self) -> float:
        """
        Get current memory usage.

        Returns:
            Memory usage in MB
        """
        return self.profiler.get_current_usage()

    def trigger_action(self, threshold: MemoryThreshold, status: str):
        """
        Trigger action for threshold.

        Args:
            threshold: Threshold that was triggered
            status: Warning or critical status
        """
        action_record = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "threshold": threshold.name,
            "status": status,
            "action": threshold.action.value,
        }

        try:
            if threshold.action_callback:
                threshold.action_callback()
                action = "Executed callback"

            elif threshold.action == MemoryAction.LOG:
                action = "Logged warning"

            elif threshold.action == MemoryAction.PRUNE:
                action = "Pruned caches"
                self._perform_pruning()

            elif threshold.action == MemoryAction.CLEAR:
                action = "Cleared caches"
                self._perform_clear()

            elif threshold.action == MemoryAction.ERROR:
                action_record["result"] = "error"
                action_record["action_performed"] = "Raised error"
                action_record["error"] = f"Memory threshold {threshold.name} exceeded: {status}"
                self.triggered_actions.append(action_record)
                raise MemoryError(f"Memory threshold {threshold.name} exceeded: {status}")

            else:
                action = "No action"

            action_record["result"] = "success"
            action_record["action_performed"] = action

        except Exception as e:
            action_record["result"] = "error"
            action_record["action_performed"] = f"Exception in {threshold.action.value}"
            action_record["error"] = str(e)
            if threshold.action == MemoryAction.ERROR:
                raise

        self.triggered_actions.append(action_record)

    def _perform_pruning(self):
        """Perform cache pruning."""
        from core.cache_manager import CacheManager
        from core.context_cache import ContextCache

        try:
            caches = [ContextCache(), CacheManager()]

            for cache in caches:
                if hasattr(cache, "optimize"):
                    cache.optimize()
        except Exception:
            logger.debug("Cache optimization failed")

    def _perform_clear(self):
        """Perform cache clearing."""
        try:
            from core.context_cache import ContextCache

            cache = ContextCache()
            cache.clear()
        except Exception:
            logger.debug("Cache clear failed")

    def get_trend(self) -> str:
        """
        Get memory usage trend.

        Returns:
            Trend: "increasing", "decreasing", or "stable"
        """
        if not self.config.enable_trend_analysis:
            return "unknown"

        if len(self.memory_history) < 2:
            return "stable"

        cutoff = datetime.now(timezone.utc) - timedelta(seconds=self.config.trend_window_seconds)
        recent = [(ts, mb) for ts, mb in self.memory_history if ts >= cutoff]

        if len(recent) < 2:
            return "stable"

        recent = sorted(recent, key=lambda x: x[0])

        increases = sum(1 for i in range(1, len(recent)) if recent[i][1] > recent[i - 1][1])

        if increases / (len(recent) - 1) > 0.6:
            return "increasing"
        elif increases / (len(recent) - 1) < 0.4:
            return "decreasing"
        else:
            return "stable"

    def _record_memory(self, memory_mb: float):
        """Record memory usage for trend analysis."""
        self.memory_history.append((datetime.now(timezone.utc), memory_mb))

        if len(self.memory_history) > self.max_history_size:
            self.memory_history = self.memory_history[-self.max_history_size :]

    def _log_threshold_trigger(self, threshold: MemoryThreshold, current_mb: float, status: str):
        """Log threshold trigger."""
        message = (
            f"Memory threshold '{threshold.name}' triggered: {status}\n"
            f"  Current: {current_mb:.1f} MB\n"
            f"  Warning: {threshold.warning_mb:.1f} MB\n"
            f"  Critical: {threshold.critical_mb:.1f} MB\n"
            f"  Action: {threshold.action.value}"
        )
        print(message)

    def _send_alert(self, threshold: MemoryThreshold, current_mb: float, status: str):
        """Send alert to registered callbacks."""
        message = f"Memory alert: {threshold.name} - {status} ({current_mb:.1f} MB)"

        for callback in self.alert_callbacks:
            try:
                callback(message, current_mb)
            except Exception:
                pass

    def add_alert_callback(self, callback: Callable[[str, float], None]):
        """
        Add alert callback.

        Args:
            callback: Function to call on alert
        """
        self.alert_callbacks.append(callback)

    def get_triggered_actions(self) -> List[Dict[str, Any]]:
        """
        Get list of triggered actions.

        Returns:
            List of action records
        """
        return self.triggered_actions.copy()

    def clear_triggered_actions(self):
        """Clear triggered actions history."""
        self.triggered_actions.clear()

    def get_status_report(self) -> Dict[str, Any]:
        """
        Get comprehensive status report.

        Returns:
            Status report dictionary
        """
        current_mb = self.get_current_usage()
        trend = self.get_trend()

        threshold_status = []
        for threshold in self.thresholds:
            status = threshold.check(current_mb)
            threshold_status.append(
                {
                    "name": threshold.name,
                    "current_mb": current_mb,
                    "warning_mb": threshold.warning_mb,
                    "critical_mb": threshold.critical_mb,
                    "status": status or "ok",
                    "action": threshold.action.value,
                }
            )

        return {
            "monitoring": self.monitoring,
            "current_memory_mb": current_mb,
            "trend": trend,
            "thresholds": threshold_status,
            "triggered_actions_count": len(self.triggered_actions),
            "check_interval_seconds": self.config.check_interval_seconds,
        }

    def set_threshold(self, threshold: MemoryThreshold):
        """
        Set or update a threshold.

        Args:
            threshold: Threshold to set
        """
        for i, existing in enumerate(self.thresholds):
            if existing.name == threshold.name:
                self.thresholds[i] = threshold
                return

        self.thresholds.append(threshold)

    def remove_threshold(self, name: str):
        """
        Remove threshold by name.

        Args:
            name: Threshold name
        """
        self.thresholds = [t for t in self.thresholds if t.name != name]

    def get_memory_history(self, seconds: int = 300) -> List[tuple[datetime, float]]:
        """
        Get memory usage history.

        Args:
            seconds: Number of seconds of history to return

        Returns:
            List of (timestamp, memory_mb) tuples
        """
        cutoff = datetime.now(timezone.utc) - timedelta(seconds=seconds)
        return [(ts, mb) for ts, mb in self.memory_history if ts >= cutoff]


def create_default_monitor() -> MemoryMonitor:
    """
    Create memory monitor with default thresholds.

    Returns:
        Configured memory monitor
    """
    thresholds = [
        MemoryThreshold(
            name="general", warning_mb=1000.0, critical_mb=2000.0, action=MemoryAction.LOG
        ),
        MemoryThreshold(
            name="cache_pruning", warning_mb=1500.0, critical_mb=2500.0, action=MemoryAction.PRUNE
        ),
        MemoryThreshold(
            name="cache_clearing", warning_mb=2000.0, critical_mb=3000.0, action=MemoryAction.CLEAR
        ),
        MemoryThreshold(
            name="critical_limit", warning_mb=2500.0, critical_mb=4000.0, action=MemoryAction.ERROR
        ),
    ]

    return MemoryMonitor(thresholds)
