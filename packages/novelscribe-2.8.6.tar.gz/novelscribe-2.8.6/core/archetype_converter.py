"""
Archetype Converter Module

Converts archetype templates into fully original, psychologically coherent
character profiles suitable for long-form serialization using LLM generation.
"""

import logging
from typing import Any, Dict, Optional

from core.archetype_loader import ArchetypeLoader, get_archetype_loader
from core.llm_client import LLMClient, LLMClientFactory, LLMConfig, LLMResponse

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = (
    "You are a character creation engine for long-form fiction. "
    "Your task is to transform a character archetype template into a fully "
    "original character profile. The new character MUST inherit the "
    "archetype's personality structure, behavioral logic, emotional "
    "responses, psychological tensions, and language patterns — but must "
    "NOT copy or closely imitate any existing fictional character. "
    "The character must be psychologically coherent and suitable for "
    "long-form serialization (no dead ends in character arc). "
    "Output ONLY the character profile in valid Markdown format."
)

USER_PROMPT_TEMPLATE = (
    'Create an original character named "{name}" based on the '
    '"{archetype_name}" archetype.\n\n'
    "ARCHETYPE DEFINITION:\n{archetype_yaml}\n\n"
    "REQUIREMENTS:\n"
    "1. The character must feel like a real person, not a stereotype.\n"
    "2. Inherit the archetype's psychological tensions, behavioral logic, "
    "and emotional patterns — but express them through unique details.\n"
    "3. Give the character a specific background, culture, and life history "
    "that shapes who they are.\n"
    "4. Ensure the character arc has growth potential — no dead ends.\n"
    "5. Make the voice distinct and consistent.\n\n"
    "OUTPUT FORMAT — produce EXACTLY this Markdown structure:\n\n"
    "## {name}\n\n"
    "**Role**: [character's narrative role]\n"
    "**Age**: [age]\n"
    "**Archetype**: {archetype_name}\n\n"
    "### Physical Description\n"
    "- [Appearance details]\n"
    "- [Distinguishing features]\n"
    "- [Clothing style]\n"
    "- [Mannerisms]\n\n"
    "### Personality\n"
    "- **Core Traits**: [3-5 dominant traits]\n"
    "- **Strengths**: [what makes them capable]\n"
    "- **Weaknesses**: [fatal flaws, shortcomings]\n"
    "- **Values**: [what matters most]\n"
    "- **Fears**: [deep-seated fears]\n"
    "- **Desires**: [what they want most]\n\n"
    "### Background\n"
    "- [Key history that shaped them]\n"
    "- [Family background]\n"
    "- [Education/experience]\n"
    "- [Defining trauma or triumph]\n\n"
    "### Relationships\n"
    "- [Relationship patterns and dynamics]\n"
    "- [How they connect with others]\n"
    "- [Key relationship tensions]\n\n"
    "### Character Arc\n"
    "- **Arc Type**: [Growth/Change/Fall/Flat]\n"
    "- **Starting State**: [who they are at the beginning]\n"
    "- **Want vs. Need**: [what they think they want vs. what they need]\n"
    "- **Lie They Believe**: [core misconception]\n"
    "- **Truth They Must Learn**: [what growth requires]\n"
    "- **Potential Endpoints**: [2-3 possible arc resolutions]\n\n"
    "### Voice\n"
    "- [Speech patterns and rhythm]\n"
    "- [Worldview and biases]\n"
    "- [Vocabulary level and style]\n"
    "- [Internal narrative style]\n"
)


class ArchetypeConverter:
    """Convert archetype templates into original character profiles."""

    def __init__(
        self,
        llm_client: Optional[LLMClient] = None,
        llm_config: Optional[LLMConfig] = None,
        archetype_loader: Optional[ArchetypeLoader] = None,
        language: str = "en",
    ) -> None:
        """
        Initialize the archetype converter.

        Args:
            llm_client: Pre-configured LLM client. If None, created from llm_config.
            llm_config: LLM configuration for creating client. Used if llm_client is None.
            archetype_loader: Archetype loader instance. If None, created with language.
            language: Language code for archetype loading.
        """
        if llm_client:
            self._llm_client = llm_client
        elif llm_config:
            self._llm_client = LLMClientFactory.create(llm_config)
        else:
            default_config = LLMConfig(temperature=0.8, max_tokens=4096)
            self._llm_client = LLMClientFactory.create(default_config)

        self._loader = archetype_loader or get_archetype_loader(language)
        self._language = language

    def convert(
        self,
        archetype_slug: str,
        character_name: str,
        genre: Optional[str] = None,
    ) -> str:
        """
        Convert an archetype into an original character profile.

        Args:
            archetype_slug: Archetype identifier (e.g., "hero").
            character_name: Name for the new character.
            genre: Optional genre context for the character.

        Returns:
            Markdown character profile string.

        Raises:
            ValueError: If archetype not found.
            RuntimeError: If LLM generation fails.
        """
        archetype = self._loader.get_archetype(archetype_slug)
        if not archetype:
            available = self._loader.list_archetypes()
            raise ValueError(
                f"Archetype '{archetype_slug}' not found. Available: {', '.join(available)}"
            )

        archetype_text = self._format_archetype_for_prompt(archetype)
        archetype_name = archetype.get("name", archetype_slug)

        user_prompt = USER_PROMPT_TEMPLATE.format(
            name=character_name,
            archetype_name=archetype_name,
            archetype_yaml=archetype_text,
        )

        if genre:
            user_prompt += (
                f"\nADDITIONAL CONTEXT:\n"
                f"Genre: {genre}\n"
                f"Adapt the character to fit naturally within {genre} fiction.\n"
            )

        try:
            response: LLMResponse = self._llm_client.generate(
                system_prompt=SYSTEM_PROMPT,
                user_prompt=user_prompt,
            )
            profile = response.content.strip()

            if not profile:
                raise RuntimeError("LLM returned empty character profile")

            if not profile.startswith("#"):
                profile = "## " + profile.lstrip("#").strip()
                if not profile.startswith("##"):
                    profile = f"## {character_name}\n\n{profile}"

            return profile

        except ValueError:
            raise
        except Exception as e:
            raise RuntimeError(f"Failed to generate character profile: {e}") from e

    def _format_archetype_for_prompt(self, archetype: Dict[str, Any]) -> str:
        """
        Format archetype data as readable text for the LLM prompt.

        Args:
            archetype: Archetype data dictionary.

        Returns:
            Formatted string representation of the archetype.
        """
        lines: list[str] = []

        lines.append(f"Name: {archetype.get('name', 'Unknown')}")
        lines.append(f"Category: {archetype.get('category', 'unknown')}")
        lines.append(f"Description: {archetype.get('description', '')}")
        lines.append("")

        personality = archetype.get("personality_structure", {})
        if personality:
            lines.append("PERSONALITY STRUCTURE:")
            for trait in personality.get("core_traits", []):
                lines.append(f"  Core Trait: {trait}")
            for pattern in personality.get("behavioral_patterns", []):
                lines.append(f"  Behavioral Pattern: {pattern}")
            lines.append("")

        emotional = archetype.get("emotional_responses", {})
        if emotional:
            lines.append("EMOTIONAL RESPONSES:")
            for trigger in emotional.get("triggers", []):
                lines.append(
                    f"  Trigger: {trigger.get('description', '')} -> {trigger.get('reaction', '')}"
                )
            if emotional.get("default_reaction"):
                lines.append(f"  Default Reaction: {emotional['default_reaction']}")
            if emotional.get("emotional_range"):
                lines.append(f"  Emotional Range: {emotional['emotional_range']}")
            lines.append("")

        tensions = archetype.get("psychological_tensions", [])
        if tensions:
            lines.append("PSYCHOLOGICAL TENSIONS:")
            for tension in tensions:
                lines.append(f"  {tension.get('conflict', '')}: {tension.get('description', '')}")
            lines.append("")

        lang_patterns = archetype.get("language_patterns", {})
        if lang_patterns:
            lines.append("LANGUAGE PATTERNS:")
            if lang_patterns.get("speech_style"):
                lines.append(f"  Speech Style: {lang_patterns['speech_style']}")
            if lang_patterns.get("narrative_voice"):
                lines.append(f"  Narrative Voice: {lang_patterns['narrative_voice']}")
            lines.append("")

        behavioral = archetype.get("behavioral_logic", {})
        if behavioral:
            lines.append("BEHAVIORAL LOGIC:")
            for rule in behavioral.get("decision_rules", []):
                lines.append(f"  Decision Rule: {rule}")
            if behavioral.get("stress_response"):
                lines.append(f"  Stress Response: {behavioral['stress_response']}")
            if behavioral.get("conflict_approach"):
                lines.append(f"  Conflict Approach: {behavioral['conflict_approach']}")
            lines.append("")

        motivations = archetype.get("motivations", {})
        if motivations:
            lines.append("MOTIVATIONS:")
            if motivations.get("wants"):
                lines.append(f"  Wants: {motivations['wants']}")
            if motivations.get("needs"):
                lines.append(f"  Needs: {motivations['needs']}")
            if motivations.get("fears"):
                lines.append(f"  Fears: {motivations['fears']}")
            if motivations.get("values"):
                lines.append(f"  Values: {', '.join(motivations['values'])}")
            lines.append("")

        arc = archetype.get("arc_potential", {})
        if arc:
            lines.append("ARC POTENTIAL:")
            if arc.get("growth"):
                lines.append(f"  Growth: {arc['growth']}")
            if arc.get("fall"):
                lines.append(f"  Fall: {arc['fall']}")
            if arc.get("flat"):
                lines.append(f"  Flat: {arc['flat']}")

        return "\n".join(lines)

    def list_archetypes(self) -> list[str]:
        """Delegate to loader's list_archetypes."""
        return self._loader.list_archetypes()
