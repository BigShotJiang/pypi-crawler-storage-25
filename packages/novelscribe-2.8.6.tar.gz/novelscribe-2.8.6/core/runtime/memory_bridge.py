"""Memory bridge for runtime injection and writeback."""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from uuid import uuid4

from core.memory.models import ConversationEvent

from .models import RuntimeState, RuntimeTask


class MemoryBridge:
    """Bridge runtime loop with MemoryBus read/write operations."""

    def __init__(self, memory_bus) -> None:
        self._memory_bus = memory_bus
        self._logger = logging.getLogger(__name__)

    def build_memory_context(self, task: RuntimeTask, state: RuntimeState) -> tuple[str, dict]:
        """Build memory context from short-term and long-term memory."""
        metadata: dict = {"conversation_tokens": 0, "wiki_hits": 0}
        if self._memory_bus is None:
            return "", metadata

        sections: list[str] = []
        try:
            conversations = self._memory_bus.get_conversations()
            short_term = conversations.to_context_string(max_tokens=300)
            if short_term is not None and not isinstance(short_term, str):
                short_term = str(short_term)
            if short_term:
                sections.append("### Short-term Memory")
                sections.append(short_term)
                metadata["conversation_tokens"] = len(short_term) // 4
        except Exception as exc:
            self._logger.debug("Failed to build short-term memory context: %s", exc)

        try:
            query = task.memory_query or task.user_input
            long_term = self._memory_bus.retrieve(
                agent_name=task.agent_name,
                query=query,
                max_tokens=600,
            )
            if not isinstance(long_term, list):
                long_term = []
            if long_term:
                sections.append("### Long-term Memory")
                metadata["wiki_hits"] = len(long_term)
                for item in long_term[:5]:
                    if not isinstance(item, dict):
                        continue
                    title = item.get("title", "memory")
                    content = item.get("content", item.get("summary", ""))
                    if content is not None and not isinstance(content, str):
                        content = str(content)
                    if content:
                        sections.append(f"- {title}: {content}")
        except Exception as exc:
            self._logger.debug("Failed to build long-term memory context: %s", exc)

        return "\n".join(sections).strip(), metadata

    def writeback(self, task: RuntimeTask, state: RuntimeState, final_output: str) -> None:
        """Write runtime turn results back into memory systems."""
        if self._memory_bus is None or not final_output:
            return

        runtime_meta = {"task_id": task.task_id, "source": "runtime"}
        runtime_meta.update(task.metadata)

        try:
            self._memory_bus.index(
                artifact_type="summary",
                content=final_output,
                metadata=runtime_meta,
            )
        except Exception as exc:
            self._logger.debug("Memory index writeback failed: %s", exc)

        try:
            conversations = self._memory_bus.get_conversations()
            session_id = state.metadata.get("runtime_session_id")
            project_name = task.metadata.get("project_name", "runtime_project")
            if not session_id:
                session_id = conversations.start_session(project=project_name, mode="runtime")
                state.metadata["runtime_session_id"] = session_id

            event = ConversationEvent(
                event_id=f"{task.task_id}-{state.turn_index}",
                session_id=session_id,
                timestamp=datetime.now(timezone.utc),
                event_type="agent_response",
                agent_name=task.agent_name,
                content=final_output,
                metadata={**runtime_meta, "event_uuid": str(uuid4())},
            )
            conversations.record_event(event)
        except Exception as exc:
            self._logger.debug("Conversation writeback failed: %s", exc)
