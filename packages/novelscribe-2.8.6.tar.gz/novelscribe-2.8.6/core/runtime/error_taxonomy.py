"""Runtime error taxonomy and classification helpers."""

from __future__ import annotations

from enum import Enum
from typing import Any

from core.errors import NovelScribeError


class RuntimeErrorCategory(str, Enum):
    """Unified runtime error categories."""

    TRANSIENT = "transient_error"
    RECOVERABLE_MODEL = "recoverable_model_error"
    USER_FIXABLE = "user_fixable_error"
    UNEXPECTED = "unexpected_error"


class RuntimeExecutionError(NovelScribeError):
    """Typed runtime execution error with explicit category."""

    def __init__(self, message: str, category: RuntimeErrorCategory, retryable: bool = False):
        super().__init__(message)
        self.category = category
        self.retryable = retryable


def classify_exception(exc: Exception) -> tuple[RuntimeErrorCategory, bool]:
    """Classify runtime exception into taxonomy category and retryability."""
    if isinstance(exc, TimeoutError | ConnectionError):
        return RuntimeErrorCategory.TRANSIENT, True
    if isinstance(exc, (PermissionError, ValueError, TypeError)):
        return RuntimeErrorCategory.USER_FIXABLE, False
    if isinstance(exc, RuntimeExecutionError):
        return exc.category, exc.retryable
    return RuntimeErrorCategory.UNEXPECTED, False


def build_error_payload(
    message: str,
    category: RuntimeErrorCategory,
    retryable: bool,
) -> dict[str, Any]:
    """Build structured error payload stored in runtime state metadata."""
    return {
        "error_category": category.value,
        "retryable": retryable,
        "message": message,
    }
