"""Tool protocol components for runtime tool calling."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Callable

from pydantic import BaseModel, ConfigDict, Field

from .error_taxonomy import RuntimeErrorCategory
from .guardrails import GuardrailEngine
from .models import ToolCall


class ToolSpec(BaseModel):
    """Tool declaration used by runtime and model context."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    name: str
    description: str
    input_schema: dict[str, Any]
    permission: str = "default"
    handler: Callable[[dict[str, Any], dict[str, Any]], dict[str, Any]]


class ToolResult(BaseModel):
    """Result of executing a tool call."""

    name: str
    success: bool
    output: dict[str, Any] | None = None
    error: str | None = None
    error_category: str | None = None
    audit: dict[str, Any] = Field(default_factory=dict)


class ToolRegistry:
    """Registry storing runtime tools by name."""

    def __init__(self) -> None:
        self._tools: dict[str, ToolSpec] = {}

    def register(self, spec: ToolSpec) -> None:
        """Register a tool specification."""
        self._tools[spec.name] = spec

    def get(self, name: str) -> ToolSpec | None:
        """Retrieve tool by name."""
        return self._tools.get(name)

    def list_for_model(self) -> list[dict[str, Any]]:
        """List model-visible tool definitions."""
        return [
            {
                "name": spec.name,
                "description": spec.description,
                "input_schema": spec.input_schema,
                "permission": spec.permission,
            }
            for spec in self._tools.values()
        ]


class ToolExecutor:
    """Executor with schema validation and audit recording."""

    def __init__(
        self,
        registry: ToolRegistry,
        guardrail_engine: GuardrailEngine | None = None,
    ) -> None:
        self._registry = registry
        self._guardrail_engine = guardrail_engine
        self.audit_log: list[dict[str, Any]] = []

    def execute(self, call: ToolCall, context: dict[str, Any]) -> ToolResult:
        """Execute a tool call with validation and audit."""
        started_at = datetime.now(timezone.utc).isoformat()
        spec = self._registry.get(call.name)
        if spec is None:
            result = ToolResult(
                name=call.name,
                success=False,
                error=f"Unknown tool: {call.name}",
                error_category=RuntimeErrorCategory.USER_FIXABLE.value,
                audit={"started_at": started_at, "status": "unknown_tool"},
            )
            self.audit_log.append(result.audit | {"tool": call.name})
            return result

        try:
            if self._guardrail_engine is not None:
                decision = self._guardrail_engine.validate_tool_call(call.name, spec.permission)
                if not decision.allowed:
                    audit = {
                        "started_at": started_at,
                        "finished_at": datetime.now(timezone.utc).isoformat(),
                        "permission": spec.permission,
                        "status": "blocked_by_guardrail",
                    }
                    result = ToolResult(
                        name=call.name,
                        success=False,
                        error=decision.reason,
                        error_category=RuntimeErrorCategory.USER_FIXABLE.value,
                        audit=audit | {"guardrail": decision.metadata},
                    )
                    self.audit_log.append(
                        audit
                        | {
                            "tool": call.name,
                            "arguments": call.arguments,
                            "guardrail": decision.metadata,
                        }
                    )
                    return result

            self._validate_input(spec.input_schema, call.arguments)
            output = spec.handler(call.arguments, context)
            if not isinstance(output, dict):
                output = {"result": output}
            success = bool(output.get("success", True))
            audit = {
                "started_at": started_at,
                "finished_at": datetime.now(timezone.utc).isoformat(),
                "permission": spec.permission,
                "status": "success" if success else "tool_returned_error",
            }
            result = ToolResult(
                name=call.name,
                success=success,
                output=output,
                error=None if success else str(output.get("error", "tool returned error")),
                error_category=(None if success else RuntimeErrorCategory.USER_FIXABLE.value),
                audit=audit,
            )
            self.audit_log.append(audit | {"tool": call.name, "arguments": call.arguments})
            return result
        except Exception as exc:
            audit = {
                "started_at": started_at,
                "finished_at": datetime.now(timezone.utc).isoformat(),
                "permission": spec.permission,
                "status": "failed",
            }
            result = ToolResult(
                name=call.name,
                success=False,
                error=str(exc),
                error_category=RuntimeErrorCategory.USER_FIXABLE.value,
                audit=audit,
            )
            self.audit_log.append(audit | {"tool": call.name, "arguments": call.arguments})
            return result

    def _validate_input(self, schema: dict[str, Any], arguments: dict[str, Any]) -> None:
        """Validate call arguments against simple JSON-schema-like contract."""
        if not isinstance(arguments, dict):
            raise TypeError("Tool arguments must be an object")
        if schema.get("type") != "object":
            return

        required = schema.get("required", [])
        for key in required:
            if key not in arguments:
                raise ValueError(f"Missing required tool argument: {key}")

        properties = schema.get("properties", {})
        for key, value in arguments.items():
            if key not in properties:
                continue
            expected_type = properties[key].get("type")
            if expected_type is None:
                continue
            if not self._matches_type(value, expected_type):
                raise TypeError(f"Invalid type for '{key}': expected {expected_type}")

    @staticmethod
    def _matches_type(value: Any, expected_type: str) -> bool:
        """Check if value matches expected JSON type label."""
        type_map = {
            "string": str,
            "integer": int,
            "number": (int, float),
            "boolean": bool,
            "object": dict,
            "array": list,
        }
        py_type = type_map.get(expected_type)
        if py_type is None:
            return True
        return isinstance(value, py_type)
