"""Runtime tool wrappers for SystemActionHandler."""

from __future__ import annotations

from typing import Any

from core.system_actions import SystemActionHandler

from .tool_protocol import ToolRegistry, ToolSpec


def register_system_action_tools(
    registry: ToolRegistry,
    action_handler: SystemActionHandler,
    default_project_name: str = "",
) -> None:
    """Register SystemActionHandler as runtime tool(s)."""

    def _system_action_handler(
        arguments: dict[str, Any], context: dict[str, Any]
    ) -> dict[str, Any]:
        action = arguments.get("action", "")
        input_data = arguments.get("input_data", {})
        project_name = (
            arguments.get("project_name")
            or context.get("project_name")
            or default_project_name
            or "default"
        )
        if not isinstance(input_data, dict):
            raise TypeError("input_data must be an object")
        return action_handler.execute_action(
            action=action,
            input_data=input_data,
            project_name=project_name,
        )

    registry.register(
        ToolSpec(
            name="system_action",
            description="Execute a registered SystemActionHandler action.",
            input_schema={
                "type": "object",
                "properties": {
                    "action": {"type": "string"},
                    "input_data": {"type": "object"},
                    "project_name": {"type": "string"},
                },
                "required": ["action", "input_data"],
            },
            permission="system",
            handler=_system_action_handler,
        )
    )
