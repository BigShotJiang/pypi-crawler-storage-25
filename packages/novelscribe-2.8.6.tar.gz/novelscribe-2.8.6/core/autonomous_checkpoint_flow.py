"""Checkpoint decision flow for autonomous phase execution."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Optional

from core.autonomous_checkpoint import CheckpointHandler
from core.autonomous_models import AutonomousResult
from core.progress_tracker import ExecutionStatus

if TYPE_CHECKING:
    from core.autonomous_executor import AutonomousExecutor


class CheckpointFlow:
    """Coordinates phase-level checkpoint decisions."""

    def __init__(
        self,
        executor: "AutonomousExecutor",
        checkpoint_handler: CheckpointHandler,
    ) -> None:
        self._executor = executor
        self._checkpoint_handler = checkpoint_handler

    def handle_phase_entry(
        self,
        workflow_name: str,
        current_chapter: Optional[int],
        execution_context: dict[str, Any],
        completed_phases: list[str],
        include_legacy: bool,
    ) -> Optional[AutonomousResult]:
        """Handle all checkpoint hooks before phase execution."""
        executor = self._executor
        if include_legacy and executor.human_handler:
            result = self._handle_legacy_human_checkpoint(
                workflow_name,
                execution_context,
                completed_phases,
            )
            if result is not None:
                return result

        if executor.checkpoint_orchestrator:
            chapter_for_checkpoint = None
            if workflow_name in ("chapter_plan_phase", "writing_phase"):
                chapter_for_checkpoint = current_chapter
            result = self._handle_orchestrated_checkpoint(
                workflow_name,
                chapter_for_checkpoint,
                execution_context,
                completed_phases,
            )
            if result is not None:
                return result
        return None

    def _handle_legacy_human_checkpoint(
        self,
        workflow_name: str,
        execution_context: dict[str, Any],
        completed_phases: list[str],
    ) -> Optional[AutonomousResult]:
        executor = self._executor
        assert executor.human_handler is not None
        if not executor.human_handler.should_pause_at_phase(
            workflow_name,
            executor.LEGACY_HUMAN_CHECKPOINTS,
        ):
            return None

        checkpoint = executor.human_handler.get_checkpoint_for_phase(
            workflow_name,
            executor.LEGACY_HUMAN_CHECKPOINTS,
        )
        if not checkpoint:
            return None

        decision = executor.human_handler.handle_checkpoint(checkpoint)
        if not decision.approved:
            executor.logger.info("Execution stopped by user")
            executor.progress_tracker.set_status(ExecutionStatus.PAUSED)
            return AutonomousResult(
                success=False,
                completed_phases=completed_phases,
                final_status=ExecutionStatus.PAUSED,
                error="Stopped by user at checkpoint",
            )

        if decision.input:
            execution_context["user_input"] = decision.input
        if decision.modifications:
            execution_context.update(decision.modifications)
        return None

    def _handle_orchestrated_checkpoint(
        self,
        workflow_name: str,
        chapter_for_checkpoint: Optional[int],
        execution_context: dict[str, Any],
        completed_phases: list[str],
    ) -> Optional[AutonomousResult]:
        executor = self._executor
        assert executor.checkpoint_orchestrator is not None

        if not executor.checkpoint_orchestrator.should_pause_at_phase(
            workflow_name,
            chapter_for_checkpoint,
        ):
            return None

        checkpoint_result = executor._present_checkpoint(
            workflow_name,
            chapter_for_checkpoint,
            execution_context,
        )
        if checkpoint_result is None:
            executor.logger.info("Execution paused at checkpoint (waiting for input)")
            executor.progress_tracker.set_status(ExecutionStatus.PAUSED)
            return AutonomousResult(
                success=False,
                completed_phases=completed_phases,
                final_status=ExecutionStatus.PAUSED,
                checkpoint_id=executor.checkpoint_orchestrator.get_checkpoint_id(
                    workflow_name,
                    chapter_for_checkpoint,
                ),
            )

        if checkpoint_result.get("status") == "rejected":
            executor.logger.info("Execution rejected by human at checkpoint")
            executor.progress_tracker.set_status(ExecutionStatus.PAUSED)
            return AutonomousResult(
                success=False,
                completed_phases=completed_phases,
                final_status=ExecutionStatus.PAUSED,
                error="Rejected by human at checkpoint",
                checkpoint_id=checkpoint_result.get("checkpoint_id"),
            )

        if checkpoint_result.get("modified_content"):
            execution_context["checkpoint_modifications"] = checkpoint_result["modified_content"]
        if checkpoint_result.get("guidance"):
            execution_context["human_guidance"] = checkpoint_result["guidance"]
        return None
