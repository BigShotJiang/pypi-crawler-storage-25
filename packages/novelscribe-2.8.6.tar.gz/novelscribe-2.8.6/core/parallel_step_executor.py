"""Parallel step executor with DAG-based scheduling."""

from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

from .workflow_loader import WorkflowStep


class ParallelStepExecutor:
    """Execute workflow steps in parallel respecting dependency DAG."""

    def __init__(self, max_workers: int = 4) -> None:
        self._max_workers = max_workers
        self.logger = logging.getLogger(__name__)

    def execute_dag(
        self,
        steps: list[WorkflowStep],
        step_executor_fn: Any,
        project_name: str,
        variables: dict[str, Any],
        step_outputs: dict[str, Any],
        config: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """Execute steps as a DAG with concurrent scheduling.

        Args:
            steps: Steps to execute (with depends_on fields).
            step_executor_fn: Callable(step, project_name, variables, step_outputs,
                config) -> result dict.
            project_name: Project name.
            variables: Workflow variables.
            step_outputs: Mutable step outputs dict.
            config: LLM configuration.

        Returns:
            List of result dicts in completion order.
        """
        step_map = {s.name: s for s in steps}
        dag = self._build_dag(steps)
        results: list[dict[str, Any]] = []
        completed: set[str] = set()
        remaining = set(dag.keys())

        while remaining:
            ready = self._find_ready(dag, remaining, completed)
            if not ready:
                self.logger.error("Circular dependency detected: %s", remaining)
                for name in remaining:
                    results.append(
                        {"step": 0, "name": name, "success": False, "error": "circular_dependency"}
                    )
                break

            batch = ready[: self._max_workers]
            for name in batch:
                remaining.discard(name)

            with ThreadPoolExecutor(max_workers=len(batch)) as pool:
                futures = {}
                for name in batch:
                    step = step_map[name]
                    future = pool.submit(
                        step_executor_fn, step, project_name, variables, step_outputs, config
                    )
                    futures[future] = name

                for future in as_completed(futures):
                    name = futures[future]
                    try:
                        result = future.result()
                    except Exception as exc:
                        result = {"step": 0, "name": name, "success": False, "error": str(exc)}

                    results.append(result)
                    if result.get("success", True) and result.get("output"):
                        step_outputs[name] = result["output"]
                    completed.add(name)

        return results

    def _build_dag(self, steps: list[WorkflowStep]) -> dict[str, list[str]]:
        """Build adjacency list from depends_on fields."""
        dag: dict[str, list[str]] = {}
        for step in steps:
            dag[step.name] = list(step.depends_on) if step.depends_on else []
        return dag

    @staticmethod
    def _find_ready(
        dag: dict[str, list[str]], remaining: set[str], completed: set[str]
    ) -> list[str]:
        """Find steps whose dependencies are all completed."""
        ready = []
        for name in sorted(remaining):
            deps = dag.get(name, [])
            if all(d in completed for d in deps):
                ready.append(name)
        return ready
