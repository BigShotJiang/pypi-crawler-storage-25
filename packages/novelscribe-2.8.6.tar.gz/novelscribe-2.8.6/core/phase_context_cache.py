"""PhaseContextCache — in-memory artifact cache for a single phase.

Pre-loads artifacts from ContextStore at phase start so ContextAssembler
can serve reads from memory instead of hitting disk on every agent call.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from core.context_store import ArtifactFilter, ContextArtifact


class PhaseContextCache:
    """In-memory cache for context artifacts, scoped to a single phase.

    Usage::

        cache = PhaseContextCache()
        cache.preload(store)           # load all artifacts into memory
        artifact = cache.get_latest_by_type("outline")  # served from memory
    """

    def __init__(self) -> None:
        self._by_type: Dict[str, List[ContextArtifact]] = {}
        self._latest_by_type: Dict[str, ContextArtifact] = {}
        self._summaries: List[ContextArtifact] = []
        self._hit_count = 0
        self._miss_count = 0

    def preload(self, store: Any) -> None:
        """Pre-load all artifacts from the store into memory."""
        artifact_map = store.list_artifacts()
        for artifact_type, artifact_ids in artifact_map.items():
            for aid in artifact_ids:
                try:
                    artifact = store.get(aid)
                    if artifact is None:
                        continue
                    self._by_type.setdefault(artifact_type, []).append(artifact)
                    existing = self._latest_by_type.get(artifact_type)
                    if existing is None or artifact.created_at > existing.created_at:
                        self._latest_by_type[artifact_type] = artifact
                    if artifact_type == "summary":
                        self._summaries.append(artifact)
                except Exception:
                    continue

    def warm(self, store: Any, artifact_types: Optional[List[str]] = None) -> int:
        """Batch pre-populate for specific artifact types.

        Returns the number of artifacts loaded.
        """
        loaded = 0
        types_to_load = artifact_types or [
            "meta",
            "outline",
            "characters",
            "world",
            "chapter",
            "summary",
            "plan",
        ]
        for atype in types_to_load:
            try:
                artifacts = store.query(ArtifactFilter(artifact_type=atype))
                for artifact in artifacts:
                    self._by_type.setdefault(atype, []).append(artifact)
                    existing = self._latest_by_type.get(atype)
                    if existing is None or artifact.created_at > existing.created_at:
                        self._latest_by_type[atype] = artifact
                    if atype == "summary":
                        self._summaries.append(artifact)
                    loaded += 1
            except Exception:
                continue
        return loaded

    def get_latest_by_type(self, artifact_type: str) -> Optional[ContextArtifact]:
        """Return the most recent artifact of a given type from cache."""
        result = self._latest_by_type.get(artifact_type)
        if result is not None:
            self._hit_count += 1
        else:
            self._miss_count += 1
        return result

    def query(self, filter: ArtifactFilter) -> List[ContextArtifact]:
        """Return cached artifacts matching the filter."""
        if filter.artifact_type:
            results = self._by_type.get(filter.artifact_type, [])
            if results:
                self._hit_count += 1
            else:
                self._miss_count += 1
            return list(results)
        all_artifacts = []
        for artifacts in self._by_type.values():
            all_artifacts.extend(artifacts)
        if all_artifacts:
            self._hit_count += 1
        else:
            self._miss_count += 1
        return all_artifacts

    def get_summaries(self) -> List[ContextArtifact]:
        """Return all cached summary artifacts."""
        if self._summaries:
            self._hit_count += 1
        else:
            self._miss_count += 1
        return list(self._summaries)

    def clear(self) -> None:
        """Clear all cached artifacts."""
        self._by_type.clear()
        self._latest_by_type.clear()
        self._summaries.clear()

    def get_stats(self) -> Dict[str, int]:
        """Return cache hit/miss statistics."""
        return {
            "hits": self._hit_count,
            "misses": self._miss_count,
            "types_cached": len(self._by_type),
            "total_artifacts": sum(len(v) for v in self._by_type.values()),
        }
