"""KB Context Advisor — genre-aware template recommendation service."""

from __future__ import annotations

import re
import sys
from dataclasses import dataclass
from typing import List, Optional

from core.memory.models import KBContextConfig
from core.template_kb import GlobalTemplateWikiStore, TemplateHit, TemplateWikiRetriever

_RE_TOKENIZE = re.compile(r"[^\w]+")


def _tokenize(text: str) -> set[str]:
    return {t.lower() for t in _RE_TOKENIZE.split(text) if t}


def _normalize_genre(genre: Optional[str]) -> str:
    if not genre:
        return ""
    return _tokenize(genre.lower()).pop() if _tokenize(genre.lower()) else ""


GENRE_QUERY_MAP: dict[str, dict[str, str]] = {
    "romance": {
        "scene_blueprint": "romance scene emotional beats love tension",
        "character_blueprint": "romance character love arc emotional journey",
        "plot_structure": "romance plot three act love story emotional arc",
    },
    "thriller": {
        "scene_blueprint": "thriller tension suspense suspense scene",
        "character_blueprint": "thriller character antagonist villain dark arc",
        "plot_structure": "thriller plot structure suspense rising tension",
    },
    "science_fiction": {
        "scene_blueprint": "sci-fi scene technology world building",
        "character_blueprint": "sci-fi character scientist explorer arc",
        "plot_structure": "sci-fi plot structure world building exploration",
    },
    "fantasy": {
        "scene_blueprint": "fantasy scene magic world building adventure",
        "character_blueprint": "fantasy character hero quest arc magical",
        "plot_structure": "fantasy plot structure hero journey quest",
    },
    "mystery": {
        "scene_blueprint": "mystery scene investigation clue revelation",
        "character_blueprint": "mystery character detective investigator arc",
        "plot_structure": "mystery plot structure clue discovery revelation",
    },
    "horror": {
        "scene_blueprint": "horror scene tension fear atmosphere dread",
        "character_blueprint": "horror character victim survivor dark arc",
        "plot_structure": "horror plot structure escalating tension dread",
    },
    "literary_fiction": {
        "scene_blueprint": "literary fiction scene introspection character moment",
        "character_blueprint": "literary fiction character inner arc psychological",
        "plot_structure": "literary fiction plot structure character driven",
    },
    "historical": {
        "scene_blueprint": "historical fiction scene period detail authentic",
        "character_blueprint": "historical character period role social arc",
        "plot_structure": "historical plot structure period drama social",
    },
    "slice_of_life": {
        "scene_blueprint": "slice of life daily scene mundane warm",
        "character_blueprint": "slice of life character everyday authentic arc",
        "plot_structure": "slice of life plot structure episodic daily",
    },
    "action": {
        "scene_blueprint": "action scene conflict physical chase beat",
        "character_blueprint": "action character warrior fighter physical arc",
        "plot_structure": "action plot structure escalation climax beats",
    },
}


@dataclass
class Recommendation:
    """A template recommendation with display metadata."""

    hit: TemplateHit
    index: int
    display_title: str
    display_excerpt: str


def _build_phase_keyword(phase: str) -> str:
    keywords = {
        "scene": "scene purpose tension beats",
        "character": "character arc role archetype psychological",
        "plot": "story structure plot beats narrative",
        "outline": "story structure plot beats narrative",
    }
    return keywords.get(phase.lower(), "scene purpose tension beats")


def _construct_query(genre: Optional[str], kind: str) -> str:
    normalized = _normalize_genre(genre)
    if normalized in GENRE_QUERY_MAP and kind in GENRE_QUERY_MAP[normalized]:
        return GENRE_QUERY_MAP[normalized][kind]
    return _build_phase_keyword(kind.split("_")[0])


def _format_recommendation(hit: TemplateHit, index: int) -> Recommendation:
    excerpt = hit.excerpt[:80].replace("\n", " ").strip()
    display_title = f"[{hit.template_kind}] {hit.title}"
    return Recommendation(
        hit=hit,
        index=index,
        display_title=display_title,
        display_excerpt=excerpt,
    )


def _read_selection(prompt_text: str) -> tuple[bool, list[int]]:
    sys.stdout.write(prompt_text)
    sys.stdout.flush()
    try:
        raw = input().strip()
    except (EOFError, OSError):
        sys.stdout.write("(input unavailable, defaulting to auto-selection)\n")
        sys.stdout.flush()
        return True, []
    if not raw:
        return True, []
    raw = raw.lower().strip()
    if raw in ("n", "no", "0"):
        return False, []
    if raw in ("a", "all", "*"):
        return True, []
    indices: list[int] = []
    for part in raw.split(","):
        part = part.strip()
        if not part or part == "n":
            continue
        try:
            indices.append(int(part))
        except ValueError:
            continue
    return True, indices


class KBContextAdvisor:
    """Genre-aware template recommendation service.

    Handles: genre-to-query mapping, KB retrieval, auto-select top-1 + confirm,
    and user selection for template context in the writing flow.
    """

    def __init__(
        self,
        config: KBContextConfig,
        project_genre: Optional[str] = None,
        project_lang: Optional[str] = None,
    ) -> None:
        self.config = config
        self.project_genre = _normalize_genre(project_genre) if project_genre else ""
        self.project_lang = project_lang or "en"
        self._store: Optional[GlobalTemplateWikiStore] = None
        self._retriever: Optional[TemplateWikiRetriever] = None
        self._selected: Optional[List[TemplateHit]] = None

    def _store_instance(self) -> GlobalTemplateWikiStore:
        if self._store is None:
            self._store = GlobalTemplateWikiStore.get_instance()
        return self._store

    def _retriever_instance(self) -> TemplateWikiRetriever:
        if self._retriever is None:
            self._retriever = TemplateWikiRetriever(
                store=self._store_instance(),
                top_k=self.config.top_k,
            )
        return self._retriever

    def advise(
        self,
        phase_kind: str,
        phase_name: Optional[str] = None,
        interactive: bool = True,
    ) -> List[TemplateHit]:
        """Recommend and optionally let user select templates for a given phase kind.

        Args:
            phase_kind: template kind (e.g. "scene_blueprint")
            phase_name: display name for the phase (e.g. "Scene Writing")
            interactive: whether to prompt the user for selection

        Returns:
            List of selected TemplateHit objects
        """
        if not self.config.enabled:
            return []
        if not self.config.to_kinds() or phase_kind not in self.config.to_kinds():
            return []

        query = _construct_query(self.project_genre, phase_kind)
        retriever = self._retriever_instance()
        hits = retriever.retrieve(
            query=query,
            kind=phase_kind,
            lang=self.project_lang,
            top_k=self.config.top_k,
        )
        if not hits:
            return []

        recs = [_format_recommendation(h, i) for i, h in enumerate(hits, 1)]

        if interactive:
            self._selected = self._interact(recs, phase_name or phase_kind)
        else:
            self._selected = hits[:1] if hits else []

        return self._selected or []

    def _interact(
        self,
        recs: List[Recommendation],
        phase_name: str,
    ) -> List[TemplateHit]:
        if not recs:
            return []

        phase_label = phase_name or "writing"
        sys.stdout.write(f"\n📚 Template Recommendations for {phase_label}\n")
        sys.stdout.write("─" * 50 + "\n")
        for r in recs:
            sys.stdout.write(
                f"  {r.index}. {r.display_title}\n"
                f"     {r.display_excerpt}\n"
                f"     page_id: {r.hit.page_id}\n\n"
            )
        sys.stdout.write(
            f"\n  Auto-selected: #{1} ({recs[0].display_title})\n"
            f"  Accept (Y)/Select different (1,2,3) /Reject (n or 0): "
        )
        sys.stdout.flush()
        confirmed, selected_indices = _read_selection("")

        if not confirmed:
            return []

        if not selected_indices:
            return [recs[0].hit]

        selected: List[TemplateHit] = []
        for idx in selected_indices:
            if 1 <= idx <= len(recs):
                selected.append(recs[idx - 1].hit)
        return selected

    def selected_hits(self) -> List[TemplateHit]:
        return self._selected or []
