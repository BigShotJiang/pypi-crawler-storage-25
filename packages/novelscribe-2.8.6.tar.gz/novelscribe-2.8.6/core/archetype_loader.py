"""
Archetype Loader Module

Loads and manages character archetype definitions for the
Character Archetype Transformation Engine.

Supports:
- 8+ built-in archetypes with deep psychological profiles
- Multi-language support with English fallback
- Caching for performance
"""

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

logger = logging.getLogger(__name__)


class ArchetypeLoader:
    """Load and manage character archetype definitions."""

    def __init__(self, archetypes_dir: Optional[str] = None, language: str = "en") -> None:
        """
        Initialize archetype loader.

        Args:
            archetypes_dir: Path to archetypes directory.
                Defaults to data/archetypes/ relative to this module.
            language: Language code (en, zh-CN, zh-TW).
        """
        if archetypes_dir:
            self.archetypes_dir = Path(archetypes_dir)
        else:
            self.archetypes_dir = Path(__file__).parent.parent / "data" / "archetypes"

        self.language = language
        self._cache: Dict[Path, Dict[str, Any]] = {}

    def _load_yaml(self, file_path: Path) -> Dict[str, Any]:
        """
        Load YAML file with caching.

        Args:
            file_path: Absolute path to the YAML file.

        Returns:
            Parsed YAML data as dict, or empty dict on error.
        """
        if file_path in self._cache:
            return self._cache[file_path]

        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)
                if data is None:
                    data = {}
                self._cache[file_path] = data
                return data
        except FileNotFoundError:
            logger.error("Archetype file not found: %s", file_path)
            return {}
        except yaml.YAMLError as e:
            logger.error("Invalid YAML in %s: %s", file_path, e)
            return {}

    def _get_archetype_path(self, filename: str) -> Path:
        """
        Get archetype path for current language with English fallback.

        Searches in order:
        1. Language-specific subdirectory
        2. English subdirectory
        3. Root archetypes directory (flat files)

        Args:
            filename: YAML filename (e.g., "hero.yaml").

        Returns:
            Path to the archetype file.
        """
        # Try language-specific path first
        lang_path = self.archetypes_dir / self.language / filename
        if lang_path.exists():
            return lang_path

        # Fall back to English
        if self.language != "en":
            en_path = self.archetypes_dir / "en" / filename
            if en_path.exists():
                return en_path

        # Fall back to flat files in root archetypes directory
        flat_path = self.archetypes_dir / filename
        if flat_path.exists():
            return flat_path

        return lang_path  # Return language path even if missing

    def list_archetypes(self) -> List[str]:
        """
        List available archetype slugs.

        Returns:
            Sorted list of archetype slug strings (filenames without extension).
        """
        # Check language-specific directory
        lang_dir = self.archetypes_dir / self.language
        if lang_dir.exists():
            slugs = sorted(f.stem for f in lang_dir.glob("*.yaml"))
            if slugs:
                return slugs

        # Check English directory
        if self.language != "en":
            en_dir = self.archetypes_dir / "en"
            if en_dir.exists():
                slugs = sorted(f.stem for f in en_dir.glob("*.yaml"))
                if slugs:
                    return slugs

        # Check flat directory
        if self.archetypes_dir.exists():
            slugs = sorted(f.stem for f in self.archetypes_dir.glob("*.yaml"))
            if slugs:
                return slugs

        return []

    def get_archetype(self, slug: str) -> Optional[Dict[str, Any]]:
        """
        Load a specific archetype by slug.

        Args:
            slug: Archetype identifier (e.g., "hero").

        Returns:
            Archetype data dict, or None if not found.
        """
        filename = f"{slug}.yaml"
        path = self._get_archetype_path(filename)

        if not path.exists():
            return None

        data = self._load_yaml(path)
        return data if data else None

    def get_all_archetypes(self) -> Dict[str, Dict[str, Any]]:
        """
        Load all available archetypes.

        Returns:
            Dict mapping slug strings to archetype data dicts.
        """
        result: Dict[str, Dict[str, Any]] = {}
        for slug in self.list_archetypes():
            archetype = self.get_archetype(slug)
            if archetype:
                result[slug] = archetype
        return result

    def get_archetypes_by_category(self, category: str) -> List[Dict[str, Any]]:
        """
        Filter archetypes by category.

        Args:
            category: Category to filter by (protagonist, antagonist,
                mentor, ally, shapeshifter, guardian, trickster, innocent).

        Returns:
            List of archetype data dicts matching the category.
        """
        all_archetypes = self.get_all_archetypes()
        return [data for data in all_archetypes.values() if data.get("category") == category]

    def format_archetype_summary(self, slug: str) -> str:
        """
        Format archetype as a brief summary string.

        Args:
            slug: Archetype identifier.

        Returns:
            Single-line summary like "hero - The Hero: description..."
            Empty string if archetype not found.
        """
        archetype = self.get_archetype(slug)
        if not archetype:
            return ""

        name = archetype.get("name", slug)
        description = archetype.get("description", "")
        return f"{slug} - {name}: {description}"

    def format_archetype_detail(self, slug: str) -> str:
        """
        Format archetype as a detailed multi-line string.

        Args:
            slug: Archetype identifier.

        Returns:
            Formatted multi-line string with all archetype fields.
            Empty string if archetype not found.
        """
        archetype = self.get_archetype(slug)
        if not archetype:
            return ""

        lines: List[str] = []

        # Header
        lines.append(f"Archetype: {archetype.get('name', slug)}")
        lines.append(f"Slug: {slug}")
        lines.append(f"Category: {archetype.get('category', 'unknown')}")
        lines.append(f"Description: {archetype.get('description', '')}")
        lines.append("")

        # Personality Structure
        personality = archetype.get("personality_structure", {})
        if personality:
            lines.append("Personality Structure:")
            traits = personality.get("core_traits", [])
            if traits:
                lines.append("  Core Traits:")
                for trait in traits:
                    lines.append(f"    - {trait}")
            patterns = personality.get("behavioral_patterns", [])
            if patterns:
                lines.append("  Behavioral Patterns:")
                for pattern in patterns:
                    lines.append(f"    - {pattern}")
            lines.append("")

        # Emotional Responses
        emotional = archetype.get("emotional_responses", {})
        if emotional:
            lines.append("Emotional Responses:")
            triggers = emotional.get("triggers", [])
            if triggers:
                lines.append("  Triggers:")
                for trigger in triggers:
                    lines.append(f"    - {trigger.get('description', '')}")
                    lines.append(f"      Reaction: {trigger.get('reaction', '')}")
            default = emotional.get("default_reaction", "")
            if default:
                lines.append(f"  Default Reaction: {default}")
            emotional_range = emotional.get("emotional_range", "")
            if emotional_range:
                lines.append(f"  Emotional Range: {emotional_range}")
            lines.append("")

        # Psychological Tensions
        tensions = archetype.get("psychological_tensions", [])
        if tensions:
            lines.append("Psychological Tensions:")
            for tension in tensions:
                lines.append(f"  - {tension.get('conflict', '')}")
                lines.append(f"    {tension.get('description', '')}")
            lines.append("")

        # Language Patterns
        lang_patterns = archetype.get("language_patterns", {})
        if lang_patterns:
            lines.append("Language Patterns:")
            speech = lang_patterns.get("speech_style", "")
            if speech:
                lines.append(f"  Speech Style: {speech}")
            vocab = lang_patterns.get("vocabulary", [])
            if vocab:
                lines.append(f"  Vocabulary: {', '.join(vocab)}")
            tics = lang_patterns.get("verbal_tics", [])
            if tics:
                lines.append("  Verbal Tics:")
                for tic in tics:
                    lines.append(f"    - {tic}")
            voice = lang_patterns.get("narrative_voice", "")
            if voice:
                lines.append(f"  Narrative Voice: {voice}")
            lines.append("")

        # Behavioral Logic
        behavioral = archetype.get("behavioral_logic", {})
        if behavioral:
            lines.append("Behavioral Logic:")
            rules = behavioral.get("decision_rules", [])
            if rules:
                lines.append("  Decision Rules:")
                for rule in rules:
                    lines.append(f"    - {rule}")
            stress = behavioral.get("stress_response", "")
            if stress:
                lines.append(f"  Stress Response: {stress}")
            conflict = behavioral.get("conflict_approach", "")
            if conflict:
                lines.append(f"  Conflict Approach: {conflict}")
            lines.append("")

        # Motivations
        motivations = archetype.get("motivations", {})
        if motivations:
            lines.append("Motivations:")
            wants = motivations.get("wants", "")
            if wants:
                lines.append(f"  Wants: {wants}")
            needs = motivations.get("needs", "")
            if needs:
                lines.append(f"  Needs: {needs}")
            fears = motivations.get("fears", "")
            if fears:
                lines.append(f"  Fears: {fears}")
            values = motivations.get("values", [])
            if values:
                lines.append(f"  Values: {', '.join(values)}")
            lines.append("")

        # Arc Potential
        arc = archetype.get("arc_potential", {})
        if arc:
            lines.append("Arc Potential:")
            growth = arc.get("growth", "")
            if growth:
                lines.append(f"  Growth: {growth}")
            fall = arc.get("fall", "")
            if fall:
                lines.append(f"  Fall: {fall}")
            flat = arc.get("flat", "")
            if flat:
                lines.append(f"  Flat: {flat}")
            lines.append("")

        # Transformation Notes
        notes = archetype.get("transformation_notes", "")
        if notes:
            lines.append(f"Transformation Notes: {notes}")

        return "\n".join(lines)


def get_archetype_loader(language: str = "en") -> ArchetypeLoader:
    """
    Factory function to get an archetype loader instance.

    Args:
        language: Language code (en, zh-CN, zh-TW).

    Returns:
        Configured ArchetypeLoader instance.
    """
    return ArchetypeLoader(language=language)
