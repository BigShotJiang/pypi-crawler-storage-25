"""Shared execution helpers for workflow step orchestration."""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import TimeoutError as FuturesTimeoutError
from typing import Any, Optional

from .hooks import HookEvent
from .parallel_step_executor import ParallelStepExecutor


def run_steps_with_timeout(
    executor: Any,
    workflow_timeout: int | None,
    workflow: Any,
    wf_name: str,
    proj: str,
    variables: dict[str, Any],
    config: dict[str, Any],
    hook_subs: list[Any],
    outputs: dict[str, Any],
    executed: list[dict[str, Any]],
    failed: list[dict[str, Any]],
    reports: list[dict[str, Any]],
    runtime_entry: dict[str, Any],
) -> Optional[dict[str, Any]]:
    """Run workflow steps with optional global timeout protection."""
    if workflow_timeout is None:
        execute_steps(
            executor,
            workflow,
            wf_name,
            proj,
            variables,
            config,
            hook_subs,
            outputs,
            executed,
            failed,
            reports,
        )
        return None

    with ThreadPoolExecutor(max_workers=1) as pool:
        future = pool.submit(
            execute_steps,
            executor,
            workflow,
            wf_name,
            proj,
            variables,
            config,
            hook_subs,
            outputs,
            executed,
            failed,
            reports,
        )
        try:
            future.result(timeout=workflow_timeout)
            return None
        except FuturesTimeoutError:
            executor.logger.error(
                executor._msg.format("workflow_timed_out", name=wf_name, timeout=workflow_timeout)
            )
            executor._emit_hook_event(
                HookEvent.PIPELINE_FAILURE.value,
                hook_subs,
                reports,
                {
                    "workflow": wf_name,
                    "project_name": proj,
                    "success": False,
                    "context_status": "timeout",
                    "error": f"Workflow timed out after {workflow_timeout}s",
                },
                raise_on_required_failure=False,
            )
            return {
                "workflow": wf_name,
                "success": False,
                "error": f"Workflow timed out after {workflow_timeout}s",
                "executed_steps": executed,
                "failed_steps": failed,
                "step_outputs": outputs,
                "runtime_entry": runtime_entry,
                "hook_reports": reports,
                "timed_out": True,
            }


def execute_steps(
    executor: Any,
    workflow: Any,
    wf_name: str,
    proj: str,
    variables: dict[str, Any],
    config: dict[str, Any],
    hooks: list[Any],
    outputs: dict[str, Any],
    executed: list[dict[str, Any]],
    failed: list[dict[str, Any]],
    reports: list[dict[str, Any]],
) -> None:
    """Execute workflow steps, using DAG runner when dependencies/strategy exist."""
    has_dag = any(
        step.depends_on or (step.strategy and step.strategy.mode != "sequential")
        for step in workflow.steps
    )
    if not has_dag:
        for step in workflow.steps:
            execute_single_step(
                executor,
                step,
                wf_name,
                proj,
                variables,
                outputs,
                config,
                hooks,
                reports,
                executed,
                failed,
            )
        return

    parallel = [
        step
        for step in workflow.steps
        if step.depends_on or (step.strategy and step.strategy.mode != "sequential")
    ]
    sequential = [step for step in workflow.steps if step not in parallel]
    for step in sequential:
        execute_single_step(
            executor,
            step,
            wf_name,
            proj,
            variables,
            outputs,
            config,
            hooks,
            reports,
            executed,
            failed,
        )
    if not parallel:
        return

    max_concurrent = 4
    for step in parallel:
        if step.strategy and step.strategy.max_concurrent:
            max_concurrent = step.strategy.max_concurrent
            break
    for result in ParallelStepExecutor(max_workers=max_concurrent).execute_dag(
        steps=parallel,
        step_executor_fn=executor.step_executor.execute_step,
        project_name=proj,
        variables=variables,
        step_outputs=outputs,
        config=config,
    ):
        executed.append(result)
        if not result.get("success"):
            failed.append(result)


def execute_single_step(
    executor: Any,
    step: Any,
    wf_name: str,
    proj: str,
    variables: dict[str, Any],
    outputs: dict[str, Any],
    config: dict[str, Any],
    hook_subs: list[Any],
    hook_reports: list[dict[str, Any]],
    executed: list[dict[str, Any]],
    failed: list[dict[str, Any]],
) -> None:
    """Execute one workflow step with hook dispatch and context ingestion."""
    executor.logger.info("Executing step %s: %s", step.step, step.name)
    merged_hooks = list(hook_subs)
    if step.hooks:
        merged_hooks.extend(step.hooks)
    executor._emit_hook_event(
        HookEvent.WORKFLOW_BEFORE_STEP.value,
        merged_hooks,
        hook_reports,
        {
            "workflow": wf_name,
            "project_name": proj,
            "step": step.step,
            "step_name": step.name,
            "context_status": "pending",
        },
    )
    result = executor.step_executor.execute_step(
        step=step,
        project_name=proj,
        variables=variables,
        step_outputs=outputs,
        config=config,
    )
    executed.append(result)
    if result.get("skipped"):
        return
    if not result.get("success"):
        failed.append(result)
        executor.logger.error("Step failed: %s", step.name)
        executor._emit_hook_event(
            HookEvent.WORKFLOW_STEP_FAILED.value,
            merged_hooks,
            hook_reports,
            {
                "workflow": wf_name,
                "project_name": proj,
                "step": step.step,
                "step_name": step.name,
                "context_status": "failure",
                "result": result,
            },
        )
        return

    outputs[step.name] = result.get("output", {})
    executor._emit_hook_event(
        HookEvent.WORKFLOW_AFTER_STEP.value,
        merged_hooks,
        hook_reports,
        {
            "workflow": wf_name,
            "project_name": proj,
            "step": step.step,
            "step_name": step.name,
            "context_status": "success",
            "result": result,
        },
    )
    if executor.context_bus is not None and step.context_type:
        out = result.get("output", {})
        content = (
            out
            if isinstance(out, str)
            else "\n".join(str(v) for v in out.values())
            if isinstance(out, dict)
            else str(out)
        )
        if content:
            executor.context_bus.ingest(
                artifact_type=step.context_type,
                content=content,
                source_agent=step.agent or step.name,
                chapter_number=variables.get("chapter_number"),
            )
