"""
Multi-Chapter Manager for Large-Scale Novel Projects

This module provides efficient management for projects with up to 1000 chapters,
including indexing, lazy loading, and batch operations.
"""

import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from .chapter_paginator import ChapterPage
from .multi_chapter_models import (
    ChapterContent,
    ChapterIndex,
    ChapterLoadStatus,
    ChapterReference,
    MultiChapterManagerConfig,
)
from .token_estimator import TokenEstimator

__all__ = [
    "ChapterContent",
    "ChapterIndex",
    "ChapterLoadStatus",
    "ChapterPage",
    "ChapterReference",
    "MultiChapterManager",
    "MultiChapterManagerConfig",
]


class MultiChapterManager:
    """
    Manage large-scale projects with up to 1000 chapters.

    Provides efficient indexing, lazy loading, and batch operations
    for handling very large novel projects.
    """

    def __init__(self, project_root: Path, config: Optional[MultiChapterManagerConfig] = None):
        """
        Initialize multi-chapter manager.

        Args:
            project_root: Path to project directory
            config: Optional configuration
        """
        self.project_root = Path(project_root)
        self.config = config or MultiChapterManagerConfig()

        self.chapter_references: Dict[int, ChapterReference] = {}
        self.chapter_indices: Dict[int, ChapterIndex] = {}
        self.loaded_content: Dict[int, ChapterContent] = {}

        self.chapter_order: List[int] = []
        self.token_estimator = TokenEstimator()

    def build_index(self, project_name: str) -> int:
        """
        Build index for all chapters in project.

        Args:
            project_name: Name of project

        Returns:
            Number of chapters indexed
        """
        content_dir = self.project_root / project_name

        if not content_dir.exists():
            return 0

        # Find all chapter files
        chapter_files = sorted(content_dir.glob("chapter_*.md"))

        for chapter_file in chapter_files:
            # Extract chapter number
            match = re.search(r"chapter_(\d+)", chapter_file.stem)
            if not match:
                continue

            chapter_number = int(match.group(1))

            # Get basic stats without loading content
            with open(chapter_file, "r", encoding="utf-8") as f:
                content = f.read()

            word_count = len(re.findall(r"\b\w+\b", content))
            token_count = self.token_estimator.estimate_tokens(content)

            # Create reference
            reference = ChapterReference(
                chapter_number=chapter_number,
                file_path=chapter_file,
                page_count=0,  # Will be calculated when loaded
                word_count=word_count,
                token_count=token_count,
            )

            self.chapter_references[chapter_number] = reference
            self.chapter_order.append(chapter_number)

            # Create basic index
            index = ChapterIndex(
                chapter_number=chapter_number,
                title=None,  # Will be extracted from content when loaded
                word_count=word_count,
                page_count=0,
            )

            self.chapter_indices[chapter_number] = index

        return len(self.chapter_references)

    def load_chapter(self, chapter_number: int) -> Optional[ChapterContent]:
        """
        Load chapter content with lazy loading.

        Args:
            chapter_number: Chapter number to load

        Returns:
            ChapterContent if loaded successfully, None otherwise
        """
        # Check if already loaded
        if chapter_number in self.loaded_content:
            content = self.loaded_content[chapter_number]
            content.access_count += 1
            return content

        # Check if chapter exists
        if chapter_number not in self.chapter_references:
            return None

        reference = self.chapter_references[chapter_number]

        # Check if we need to unload old chapters
        if len(self.loaded_content) >= self.config.max_loaded_chapters:
            self._unload_least_recently_used()

        # Load content
        reference.status = ChapterLoadStatus.LOADING

        try:
            with open(reference.file_path, "r", encoding="utf-8") as f:
                content_text = f.read()

            # Paginate content
            from .chapter_paginator import ChapterPaginator

            paginator = ChapterPaginator()
            pages = paginator.paginate_chapter(content_text, chapter_number, reference.metadata)

            # Update reference
            reference.page_count = len(pages)
            reference.status = ChapterLoadStatus.LOADED

            # Create content object
            import time

            content = ChapterContent(
                chapter_number=chapter_number,
                content=content_text,
                pages=pages,
                metadata=reference.metadata,
                load_time=time.time(),
                access_count=1,
            )

            self.loaded_content[chapter_number] = content

            # Update index
            self._update_index_from_content(chapter_number, content)

            return content

        except Exception as e:
            reference.status = ChapterLoadStatus.ERROR
            print(f"Error loading chapter {chapter_number}: {e}")
            return None

    def _unload_least_recently_used(self):
        """Unload least recently used chapter to free memory."""
        if not self.loaded_content:
            return

        # Find least recently accessed
        lru_chapter = min(self.loaded_content.items(), key=lambda x: x[1].load_time)

        del self.loaded_content[lru_chapter[0]]

        # Update reference status
        if lru_chapter[0] in self.chapter_references:
            self.chapter_references[lru_chapter[0]].status = ChapterLoadStatus.NOT_LOADED

    def _update_index_from_content(self, chapter_number: int, content: ChapterContent):
        """Update chapter index from loaded content."""
        if chapter_number not in self.chapter_indices:
            return

        index = self.chapter_indices[chapter_number]

        # Update page count
        index.page_count = len(content.pages)

        # Extract characters from all pages
        for page in content.pages:
            index.characters.update(page.metadata.characters_present)
            index.locations.update(page.metadata.locations_present)
            index.key_events.extend(page.metadata.key_events)

    def get_chapter_content(self, chapter_number: int) -> Optional[str]:
        """
        Get chapter content, loading if necessary.

        Args:
            chapter_number: Chapter number

        Returns:
            Chapter content as string
        """
        content = self.load_chapter(chapter_number)
        return content.content if content else None

    def get_chapter_pages(self, chapter_number: int) -> List[ChapterPage]:
        """
        Get pages for a chapter, loading if necessary.

        Args:
            chapter_number: Chapter number

        Returns:
            List of ChapterPage objects
        """
        content = self.load_chapter(chapter_number)
        return content.pages if content else []

    def get_page_content(self, chapter_number: int, page_number: int) -> Optional[str]:
        """
        Get content for a specific page.

        Args:
            chapter_number: Chapter number
            page_number: Page number within chapter

        Returns:
            Page content as string
        """
        content = self.load_chapter(chapter_number)
        if not content:
            return None

        page = content.get_page(page_number)
        return page.content if page else None

    def get_chapter_range(self, start_chapter: int, end_chapter: int) -> List[Tuple[int, str]]:
        """
        Get content for a range of chapters.

        Args:
            start_chapter: Starting chapter number
            end_chapter: Ending chapter number (inclusive)

        Returns:
            List of (chapter_number, content) tuples
        """
        results = []

        for chapter_num in range(start_chapter, end_chapter + 1):
            content = self.get_chapter_content(chapter_num)
            if content:
                results.append((chapter_num, content))

        return results

    def search_chapters(self, query: str) -> List[int]:
        """
        Search for chapters matching query.

        Args:
            query: Search query

        Returns:
            List of matching chapter numbers
        """
        results = []

        for chapter_number, index in self.chapter_indices.items():
            if index.matches_query(query):
                results.append(chapter_number)

        return sorted(results)

    def get_chapters_with_character(self, character_name: str) -> List[int]:
        """
        Get chapters containing a specific character.

        Args:
            character_name: Character name to search for

        Returns:
            List of chapter numbers
        """
        results = []

        for chapter_number, index in self.chapter_indices.items():
            if character_name in index.characters:
                results.append(chapter_number)

        return sorted(results)

    def get_chapters_with_location(self, location_name: str) -> List[int]:
        """
        Get chapters containing a specific location.

        Args:
            location_name: Location name to search for

        Returns:
            List of chapter numbers
        """
        results = []

        for chapter_number, index in self.chapter_indices.items():
            if location_name in index.locations:
                results.append(chapter_number)

        return sorted(results)

    def get_project_statistics(self) -> Dict[str, any]:
        """
        Get statistics for the entire project.

        Returns:
            Dictionary with project statistics
        """
        total_chapters = len(self.chapter_references)
        total_words = sum(ref.word_count for ref in self.chapter_references.values())
        total_tokens = sum(ref.token_count for ref in self.chapter_references.values())

        loaded_chapters = len(self.loaded_content)
        loaded_memory_mb = (
            sum(
                ref.size_kb
                for ref in self.chapter_references.values()
                if ref.chapter_number in self.loaded_content
            )
            / 1024
        )

        # Character and location statistics
        all_characters = set()
        all_locations = set()

        for index in self.chapter_indices.values():
            all_characters.update(index.characters)
            all_locations.update(index.locations)

        return {
            "total_chapters": total_chapters,
            "total_words": total_words,
            "total_tokens": total_tokens,
            "loaded_chapters": loaded_chapters,
            "loaded_memory_mb": round(loaded_memory_mb, 2),
            "unique_characters": len(all_characters),
            "unique_locations": len(all_locations),
            "avg_words_per_chapter": total_words // total_chapters if total_chapters > 0 else 0,
            "avg_tokens_per_chapter": total_tokens // total_chapters if total_chapters > 0 else 0,
        }

    def prefetch_chapters(self, current_chapter: int):
        """
        Prefetch chapters ahead of current position.

        Args:
            current_chapter: Current chapter number
        """
        prefetch_start = current_chapter + 1
        prefetch_end = current_chapter + self.config.prefetch_ahead

        for chapter_num in range(prefetch_start, prefetch_end + 1):
            if chapter_num in self.chapter_references:
                self.load_chapter(chapter_num)

    def clear_cache(self):
        """Clear all cached chapter content."""
        self.loaded_content.clear()

        # Update reference statuses
        for reference in self.chapter_references.values():
            reference.status = ChapterLoadStatus.NOT_LOADED

    def get_loading_status(self, chapter_number: int) -> ChapterLoadStatus:
        """
        Get loading status for a chapter.

        Args:
            chapter_number: Chapter number

        Returns:
            Loading status
        """
        if chapter_number in self.loaded_content:
            return ChapterLoadStatus.LOADED

        if chapter_number in self.chapter_references:
            return self.chapter_references[chapter_number].status

        return ChapterLoadStatus.NOT_LOADED

    def batch_load_chapters(self, chapter_numbers: List[int]) -> Dict[int, bool]:
        """
        Load multiple chapters in batch.

        Args:
            chapter_numbers: List of chapter numbers to load

        Returns:
            Dictionary mapping chapter numbers to load success
        """
        results = {}

        for chapter_num in chapter_numbers:
            success = self.load_chapter(chapter_num) is not None
            results[chapter_num] = success

        return results
