"""Google Gemini provider client."""

from __future__ import annotations

import os
from collections.abc import Iterator

from core.llm_client import LLMClient, LLMConfig, LLMError, LLMResponse


class GeminiClient(LLMClient):
    """Google Gemini provider client."""

    def __init__(self, config: LLMConfig):
        super().__init__(config)
        try:
            from google import genai
            from google.genai import types as genai_types

            client = genai.Client(api_key=config.api_key)
            self.client = client
            self.genai_types = genai_types
        except ImportError:
            raise LLMError(
                "Google Gemini package not installed. Install with: pip install google-genai"
            )

    def validate_config(self) -> bool:
        """Validate Gemini configuration."""
        return bool(self.config.api_key or os.getenv("GOOGLE_API_KEY"))

    def generate(self, system_prompt: str, user_prompt: str) -> LLMResponse:
        """Generate response using Gemini API."""
        if not self.validate_config():
            raise LLMError("Google API key not configured")

        try:
            combined_prompt = f"{system_prompt}\n\n{user_prompt}" if system_prompt else user_prompt

            response = self.client.models.generate_content(
                model=self.config.model,
                contents=combined_prompt,
                config=self.genai_types.GenerateContentConfig(
                    temperature=self.config.temperature,
                    max_output_tokens=self.config.max_tokens,
                ),
            )

            return LLMResponse(
                content=response.text,
                model=self.config.model,
                provider=self.provider_name,
                tokens_used=(
                    response.usage_metadata.total_token_count
                    if hasattr(response, "usage_metadata")
                    else None
                ),
                finish_reason=(
                    response.candidates[0].finish_reason.name if response.candidates else None
                ),
            )
        except Exception as e:
            raise LLMError(f"Gemini API error: {e}") from e

    def generate_with_history(self, messages: list[dict[str, str]]) -> LLMResponse:
        """Generate response using conversation history."""
        if not self.validate_config():
            raise LLMError("Google API key not configured")

        try:
            contents = []
            for msg in messages[:-1]:
                if msg["role"] in ["user", "assistant"]:
                    role = "user" if msg["role"] == "user" else "model"
                    contents.append(
                        self.genai_types.Content(
                            role=role, parts=[self.genai_types.Part(text=msg["content"])]
                        )
                    )

            contents.append(
                self.genai_types.Content(
                    role="user", parts=[self.genai_types.Part(text=messages[-1]["content"])]
                )
            )

            response = self.client.models.generate_content(
                model=self.config.model,
                contents=contents,
                config=self.genai_types.GenerateContentConfig(
                    temperature=self.config.temperature,
                    max_output_tokens=self.config.max_tokens,
                ),
            )

            return LLMResponse(
                content=response.text,
                model=self.config.model,
                provider=self.provider_name,
                tokens_used=(
                    response.usage_metadata.total_token_count
                    if hasattr(response, "usage_metadata")
                    else None
                ),
                finish_reason=(
                    response.candidates[0].finish_reason.name if response.candidates else None
                ),
            )
        except Exception as e:
            raise LLMError(f"Gemini API error: {e}") from e

    def generate_stream(self, system_prompt: str, user_prompt: str) -> Iterator[str]:
        """Stream response using Gemini API."""
        if not self.validate_config():
            raise LLMError("Google API key not configured")

        try:
            combined_prompt = f"{system_prompt}\n\n{user_prompt}" if system_prompt else user_prompt

            for chunk in self.client.models.generate_content(
                model=self.config.model,
                contents=combined_prompt,
                config=self.genai_types.GenerateContentConfig(
                    temperature=self.config.temperature,
                    max_output_tokens=self.config.max_tokens,
                ),
                stream=True,
            ):
                if chunk.text:
                    yield chunk.text
        except Exception as e:
            raise LLMError(f"Gemini streaming error: {e}") from e
