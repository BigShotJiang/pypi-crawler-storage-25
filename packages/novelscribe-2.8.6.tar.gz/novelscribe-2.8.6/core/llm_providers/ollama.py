"""Ollama (local) provider client."""

from __future__ import annotations

import os
from collections.abc import Iterator

from core.llm_client import LLMClient, LLMConfig, LLMError, LLMResponse


class OllamaClient(LLMClient):
    """Ollama (local) provider client."""

    def __init__(self, config: LLMConfig):
        super().__init__(config)
        try:
            import requests

            self.requests = requests
            self.base_url = config.base_url or os.getenv(
                "OLLAMA_BASE_URL", "http://localhost:11434"
            )
        except ImportError:
            raise LLMError("Requests package not installed. Install with: pip install requests")

    def validate_config(self) -> bool:
        """Validate Ollama configuration."""
        return True

    def generate(self, system_prompt: str, user_prompt: str) -> LLMResponse:
        """Generate response using Ollama API."""
        messages = self._format_messages(system_prompt, user_prompt)

        try:
            response = self.requests.post(
                f"{self.base_url}/api/chat",
                json={"model": self.config.model, "messages": messages, "stream": False},
                timeout=self.config.timeout,
            )

            response.raise_for_status()
            data = response.json()

            return LLMResponse(
                content=data.get("message", {}).get("content", ""),
                model=self.config.model,
                provider=self.provider_name,
                tokens_used=data.get("prompt_eval_count", 0) + data.get("eval_count", 0),
                finish_reason=data.get("done_reason"),
            )
        except Exception as e:
            raise LLMError(f"Ollama API error: {e}") from e

    def generate_with_history(self, messages: list[dict[str, str]]) -> LLMResponse:
        """Generate response using conversation history."""
        try:
            response = self.requests.post(
                f"{self.base_url}/api/chat",
                json={"model": self.config.model, "messages": messages, "stream": False},
                timeout=self.config.timeout,
            )

            response.raise_for_status()
            data = response.json()

            return LLMResponse(
                content=data.get("message", {}).get("content", ""),
                model=self.config.model,
                provider=self.provider_name,
                tokens_used=data.get("prompt_eval_count", 0) + data.get("eval_count", 0),
                finish_reason=data.get("done_reason"),
            )
        except Exception as e:
            raise LLMError(f"Ollama API error: {e}") from e

    def generate_stream(self, system_prompt: str, user_prompt: str) -> Iterator[str]:
        """Stream response using Ollama API."""
        messages = self._format_messages(system_prompt, user_prompt)
        try:
            response = self.requests.post(
                f"{self.base_url}/api/chat",
                json={"model": self.config.model, "messages": messages, "stream": True},
                timeout=self.config.timeout,
                stream=True,
            )
            response.raise_for_status()
            for line in response.iter_lines(decode_unicode=True):
                if not line:
                    continue
                import json as _json

                data = _json.loads(line)
                content = data.get("message", {}).get("content", "")
                if content:
                    yield content
                if data.get("done"):
                    break
        except LLMError:
            raise
        except Exception as e:
            raise LLMError(f"Ollama streaming error: {e}") from e
