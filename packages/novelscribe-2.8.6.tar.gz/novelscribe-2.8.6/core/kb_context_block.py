"""KB Context Block Builder — assembles injected user-context from selected templates."""

from __future__ import annotations

import re
from typing import List, Optional

from core.template_kb import GlobalTemplateWikiStore, TemplateHit

_RE_SECTION = re.compile(r"^## (.+)$", re.MULTILINE)
_RE_TOKENIZE = re.compile(r"[^\w]+")

ESTIMATED_TOKENS_PER_CHAR = 0.25


def _tokenize(text: str) -> list[str]:
    return [t for t in _RE_TOKENIZE.split(text) if t]


def _count_tokens(text: str) -> int:
    return int(len(text) * ESTIMATED_TOKENS_PER_CHAR)


def _truncate_to_tokens(text: str, max_tokens: int) -> str:
    target_chars = int(max_tokens / ESTIMATED_TOKENS_PER_CHAR)
    if len(text) <= target_chars:
        return text
    truncated = text[:target_chars]
    last_newline = truncated.rfind("\n")
    if last_newline > target_chars * 0.7:
        return truncated[:last_newline]
    last_space = truncated.rfind(" ")
    if last_space > target_chars * 0.7:
        return truncated[:last_space]
    return truncated[: int(target_chars * 0.95)] + "…"


def _extract_section(body: str, section_name: str) -> str:
    """Extract all text content under the first section matching section_name.

    Returns all markdown body content until the next ## heading,
    or the raw body if no matching section is found.
    If the matched section is "summary" and ends with "---", also include
    content from the first substantive subsection (e.g. "1. 场景目的")
    so the context block is actually useful.
    """
    sections = _RE_SECTION.split(body)
    if len(sections) < 2:
        return body.strip()
    parts = sections[1:]
    header_map: dict[str, str] = {}
    current = ""
    for i, part in enumerate(parts):
        if i % 2 == 0:
            current = part.strip()
            header_map[current] = ""
        else:
            header_map.setdefault(current, "")
            header_map[current] = part.strip()
    target_lower = section_name.lower()
    for header, content in header_map.items():
        if target_lower in header.lower():
            result = content
            if target_lower == "summary":
                before_dash = result.split("---")[0].strip()
                if len(before_dash) < 50 and len(header_map) > 1:
                    first_key = next(
                        (k for k in header_map if target_lower not in k.lower()),
                        None,
                    )
                    if first_key:
                        first_content = header_map[first_key]
                        result = before_dash + "\n\n" + first_content
            return result
    return body.strip()


def _build_single_block(hit: TemplateHit, body: str, max_tokens: int) -> str:
    summary = _extract_section(body, "summary")
    truncated_summary = _truncate_to_tokens(summary, max_tokens - 20)
    tags = getattr(hit, "tags", []) or []
    tags_str = ", ".join(f"`{t}`" for t in tags[:8]) if tags else ""
    block = f"[KB Reference: {hit.template_kind}]\nTitle: {hit.title}\nLanguage: {hit.lang}\n"
    if tags_str:
        block += f"Tags: {tags_str}\n"
    block += f"\n{truncated_summary}\n"
    return block


def build_kb_context_block(
    page_ids: List[str],
    max_tokens: int = 500,
    store: Optional[GlobalTemplateWikiStore] = None,
) -> str:
    """Assemble a compact KB context block from selected template page_ids.

    Args:
        page_ids: list of template page_ids from `KBContextAdvisor.selected_hits()`
        max_tokens: shared token budget across all selected templates (default: 500)
        store: optional GlobalTemplateWikiStore instance

    Returns:
        Formatted markdown context block, empty string if no page_ids or no store
    """
    if not page_ids:
        return ""

    if store is None:
        store = GlobalTemplateWikiStore.get_instance()

    tokens_per_template = max(50, max_tokens // max(len(page_ids), 1))

    blocks: List[str] = []
    remaining_tokens = max_tokens

    for page_id in page_ids:
        page = store.get_page(page_id)
        if page is None:
            continue
        hit = TemplateHit(
            page_id=page.page_id,
            template_id=page.template_id,
            template_kind=page.template_kind,
            title=page.title,
            lang=page.lang,
            score=100.0,
            excerpt=page.body[:200],
        )
        block_tokens = min(tokens_per_template, remaining_tokens)
        if block_tokens < 30:
            break
        block = _build_single_block(hit, page.body, block_tokens)
        block_tokens = _count_tokens(block)
        blocks.append(block)
        remaining_tokens -= block_tokens

    if not blocks:
        return ""

    header = "─" * 50
    body = "\n".join(blocks)
    return f"{header}\n[KB Reference]\n{header}\n{body}\n{header}\n"
