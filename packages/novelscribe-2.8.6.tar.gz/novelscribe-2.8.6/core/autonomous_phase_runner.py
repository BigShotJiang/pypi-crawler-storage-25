"""Phase execution runner for autonomous workflows."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Optional

from core.autonomous_models import AutonomousResult
from core.kb_context_advisor import KBContextAdvisor
from core.kb_context_block import build_kb_context_block
from core.phase_context_cache import PhaseContextCache
from core.progress_tracker import ExecutionStatus

if TYPE_CHECKING:
    from core.autonomous_checkpoint_flow import CheckpointFlow
    from core.autonomous_executor import AutonomousExecutor


class AutonomousPhaseRunner:
    """Runs autonomous phases for both fresh and resumed execution."""

    _PHASE_KIND_MAP = {
        "scene": "scene_blueprint",
        "character_phase": "character_blueprint",
        "outline_phase": "plot_structure",
    }

    _PHASE_NAME_MAP = {
        "scene": "Scene Writing",
        "character_phase": "Character Design",
        "outline_phase": "Story Outline",
    }

    def __init__(
        self,
        executor: "AutonomousExecutor",
        checkpoint_flow: "CheckpointFlow",
    ) -> None:
        self._executor = executor
        self._checkpoint_flow = checkpoint_flow
        self._advisor: Optional[KBContextAdvisor] = None
        self._kb_selected: dict[str, list[str]] = {}
        self._kb_context_block: str = ""

    def _init_advisor(self) -> KBContextAdvisor:
        """Lazy-initialize the KBContextAdvisor once per run."""
        if self._advisor is None:
            executor = self._executor
            self._advisor = KBContextAdvisor(
                config=executor.config.kb_context,
                project_genre=executor.config.project_genre,
                project_lang=executor.config.project_lang,
            )
        return self._advisor

    def _run_kb_recommendation(self, workflow_name: str) -> list[Any]:
        """Run KB recommendation once per phase kind (caching by kind key)."""
        phase_kind = self._PHASE_KIND_MAP.get(workflow_name)
        if not phase_kind:
            return []
        if phase_kind in self._kb_selected:
            return self._kb_selected[phase_kind]

        advisor = self._init_advisor()
        hits = advisor.advise(
            phase_kind=phase_kind,
            phase_name=self._PHASE_NAME_MAP.get(workflow_name, workflow_name),
            interactive=self._executor.config.human_in_loop,
        )
        page_ids = [h.page_id for h in hits]
        self._kb_selected[phase_kind] = page_ids

        max_tokens = self._executor.config.kb_context.kb_max_tokens
        if page_ids:
            block = build_kb_context_block(page_ids, max_tokens=max_tokens)
            self._kb_context_block = block
            self._executor.logger.info(f"📚 KB selected templates for {phase_kind}: {page_ids}")
        else:
            self._kb_context_block = ""

        return page_ids

    def kb_context_block(self) -> str:
        """Return the assembled KB context block for injection into prompts."""
        return getattr(self, "_kb_context_block", "") or ""

    def execute_full_pipeline(self) -> AutonomousResult:
        """Execute full autonomous pipeline."""
        executor = self._executor
        executor.logger.info(
            f"🚀 Starting autonomous pipeline for '{executor.config.project_name}'"
        )

        total_steps = len(executor.WORKFLOW_CHAIN)
        executor.progress_tracker.initialize(total_steps, executor.config.start_phase)

        completed_phases: list[str] = []
        execution_context: dict[str, Any] = {"project_name": executor.config.project_name}
        current_chapter: Optional[int] = None

        start_index = executor._get_workflow_index(executor.config.start_phase)
        end_index = executor._get_workflow_index(executor.config.end_phase)

        for i in range(start_index, end_index + 1):
            workflow_name = executor.WORKFLOW_CHAIN[i]
            if workflow_name == "new_novel" and executor.config.start_phase != "new_novel":
                continue

            executor.progress_tracker.update_phase(workflow_name)
            executor._optimizing_client.reset_circuits()
            executor.logger.info(f"→ Executing phase: {workflow_name}")

            checkpoint_result = self._checkpoint_flow.handle_phase_entry(
                workflow_name=workflow_name,
                current_chapter=current_chapter,
                execution_context=execution_context,
                completed_phases=completed_phases,
                include_legacy=True,
            )
            if checkpoint_result is not None:
                return checkpoint_result

            self._run_kb_recommendation(workflow_name)

            phase_cache = PhaseContextCache()
            try:
                try:
                    phase_cache.preload(executor.context_bus.store)
                except Exception:
                    executor.logger.debug("Phase cache preload failed, continuing without cache")
                executor.context_bus.phase_cache = phase_cache

                result = executor.workflow_executor.execute_workflow(
                    workflow_name=workflow_name,
                    project_name=executor.config.project_name,
                    variables=execution_context,
                    config=executor.llm_config.model_dump(),
                )

                if not result.get("success"):
                    executor.logger.warning(
                        f"⚠️  Workflow '{workflow_name}' completed with warnings"
                    )

                completed_phases.append(workflow_name)
                executor.progress_tracker.complete_phase(workflow_name)

                if workflow_name == "chapter_plan_phase":
                    plan = result.get("plan", {})
                    if isinstance(plan, dict):
                        chapters = plan.get("chapters", [])
                        current_chapter = len(chapters) if chapters else 0
                    else:
                        current_chapter = 0

                state = executor.progress_tracker.get_state()
                if state is None:
                    raise RuntimeError("Progress state is None after completing phase")

                executor.checkpoint_manager.create_checkpoint(
                    completed_workflows=completed_phases,
                    current_workflow=None,
                    execution_context=execution_context,
                    progress_state=state,
                )

                executor.context_bus.save_snapshot(
                    run_id=executor.config.project_name,
                    phase=workflow_name,
                    step="complete",
                )

                executor.git_manager.auto_commit_step(
                    agent="autonomous",
                    description=f"Complete {workflow_name}",
                )
            except Exception as exc:
                executor.logger.error(f"Failed to execute workflow '{workflow_name}': {exc}")
                raise
            finally:
                executor.context_bus.phase_cache = None
                phase_cache.clear()

        executor.progress_tracker.set_status(ExecutionStatus.COMPLETED)
        executor.logger.info(
            f"✅ Autonomous pipeline completed successfully for '{executor.config.project_name}'"
        )
        return AutonomousResult(
            success=True,
            completed_phases=completed_phases,
            final_status=ExecutionStatus.COMPLETED,
        )

    def resume_from_checkpoint(self) -> AutonomousResult:
        """Resume autonomous pipeline from the latest persisted checkpoint."""
        executor = self._executor
        executor.logger.info(
            f"🔄 Resuming autonomous pipeline for '{executor.config.project_name}'"
        )

        checkpoint = executor.checkpoint_manager.load_checkpoint()
        if not checkpoint:
            executor.logger.error("No checkpoint found to resume from")
            return AutonomousResult(
                success=False,
                completed_phases=[],
                final_status=ExecutionStatus.FAILED,
                error="No checkpoint found",
            )

        if not executor.checkpoint_manager.validate_checkpoint(checkpoint):
            executor.logger.error("Invalid checkpoint")
            return AutonomousResult(
                success=False,
                completed_phases=[],
                final_status=ExecutionStatus.FAILED,
                error="Invalid checkpoint",
            )

        executor.progress_tracker._state = checkpoint.progress_state
        executor.progress_tracker.set_status(ExecutionStatus.RUNNING)

        context_snapshot = executor.context_bus.restore_snapshot(
            run_id=executor.config.project_name,
        )
        if context_snapshot is not None:
            executor.logger.info(
                f"Restored context snapshot at phase={context_snapshot.phase} "
                f"step={context_snapshot.step}"
            )

        completed_phases: list[str] = checkpoint.completed_workflows
        execution_context: dict[str, Any] = checkpoint.execution_context
        current_chapter: Optional[int] = None

        last_completed = completed_phases[-1] if completed_phases else None
        start_index = executor._get_workflow_index(last_completed) + 1 if last_completed else 0
        end_index = executor._get_workflow_index(executor.config.end_phase)

        for i in range(start_index, end_index + 1):
            workflow_name = executor.WORKFLOW_CHAIN[i]
            executor.progress_tracker.update_phase(workflow_name)
            executor.logger.info(f"→ Executing phase: {workflow_name}")

            checkpoint_result = self._checkpoint_flow.handle_phase_entry(
                workflow_name=workflow_name,
                current_chapter=current_chapter,
                execution_context=execution_context,
                completed_phases=completed_phases,
                include_legacy=False,
            )
            if checkpoint_result is not None:
                return checkpoint_result

            self._run_kb_recommendation(workflow_name)

            result = executor.workflow_executor.execute_workflow(
                workflow_name=workflow_name,
                project_name=executor.config.project_name,
                variables=execution_context,
                config=executor.llm_config.model_dump(),
            )

            if not result.get("success"):
                executor.logger.warning(f"⚠️  Workflow '{workflow_name}' completed with warnings")

            completed_phases.append(workflow_name)
            executor.progress_tracker.complete_phase(workflow_name)

            if workflow_name == "chapter_plan_phase":
                plan = result.get("plan", {})
                if isinstance(plan, dict):
                    chapters = plan.get("chapters", [])
                    current_chapter = len(chapters) if chapters else 0
                else:
                    current_chapter = 0

            state = executor.progress_tracker.get_state()
            if state is None:
                raise RuntimeError("Progress state is None after completing phase")

            executor.checkpoint_manager.create_checkpoint(
                completed_workflows=completed_phases,
                current_workflow=None,
                execution_context=execution_context,
                progress_state=state,
            )

            executor.context_bus.save_snapshot(
                run_id=executor.config.project_name,
                phase=workflow_name,
                step="complete",
            )

        executor.progress_tracker.set_status(ExecutionStatus.COMPLETED)
        executor.logger.info("✅ Resumed pipeline completed successfully")
        return AutonomousResult(
            success=True,
            completed_phases=completed_phases,
            final_status=ExecutionStatus.COMPLETED,
        )
