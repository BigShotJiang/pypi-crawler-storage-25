# ruff: noqa: F401, E402, F811
"""core.performance — re-export layer for flat core modules."""

from core.cache_manager import (
    Any,
    BaseModel,
    CacheEntry,
    CacheManager,
    CacheManagerConfig,
    Callable,
    Dict,
    List,
    Optional,
    OrderedDict,
    dataclass,
    datetime,
    field,
    logger,
    timedelta,
    timezone,
)
from core.file_optimizer import (
    FileOptimizer,
    FileOptimizerStats,
    Path,
    dataclass,
    get_file_optimizer,
)
from core.performance_profiler import (
    Any,
    Dict,
    ExecutionProfile,
    ExecutionStatus,
    Optional,
    PerformanceProfiler,
    PerformanceReport,
    ProfileType,
    ProfilingContext,
    get_profiler,
    profile_function,
)
from core.performance_profiler_core import (
    Any,
    Callable,
    Clock,
    Dict,
    ExecutionProfile,
    ExecutionStatus,
    List,
    Optional,
    Path,
    PerformanceProfiler,
    PerformanceReport,
    ProfileType,
    uuid4,
)
from core.performance_profiler_types import (
    Any,
    Dict,
    Enum,
    ExecutionProfile,
    ExecutionStatus,
    List,
    Optional,
    PerformanceReport,
    ProfileType,
    dataclass,
    field,
)
