"""
Concrete validation rules for novel content.

Provides all built-in validation rule implementations organized by category:
- Content: MinimumWordCountRule, DialogueAttributionRule, DialogueBalanceRule
- Structure: ChapterOutlineAlignmentRule, SceneLengthRule
- Style: MaxSentenceLengthRule, PassiveVoiceRule, AdverbOveruseRule
- Continuity: CharacterConsistencyRule, TimelineContinuityRule
"""

import re
from typing import Any, Dict, Optional

from .validation_types import RuleCategory, Severity, ValidationResult, ValidationRule

# ---------------------------------------------------------------------------
# Content rules
# ---------------------------------------------------------------------------


class MinimumWordCountRule(ValidationRule):
    """Rule to enforce minimum word count per chapter."""

    def __init__(self, min_words: int = 1000):
        super().__init__(
            rule_id="min_word_count",
            name="Minimum Word Count",
            description="Ensures chapter meets minimum word count",
            severity=Severity.ERROR,
            category=RuleCategory.CONTENT,
        )
        self.min_words = min_words

    def validate_content(
        self, content: str, context: Optional[Dict[str, Any]] = None
    ) -> ValidationResult:
        words = re.findall(r"\b[a-zA-Z]+\b", content)
        word_count = len(words)

        passed = word_count >= self.min_words

        return ValidationResult(
            rule=self,
            passed=passed,
            message=f"Word count: {word_count} (minimum: {self.min_words})",
            suggestion=f"Add {self.min_words - word_count} more words" if not passed else None,
            context={"word_count": word_count},
        )


class DialogueAttributionRule(ValidationRule):
    """Rule to ensure dialogue has proper attribution."""

    def __init__(self, min_attribution_ratio: float = 0.6):
        super().__init__(
            rule_id="dialogue_attribution",
            name="Dialogue Attribution",
            description="Ensures dialogue lines have proper speaker attribution",
            severity=Severity.WARNING,
            category=RuleCategory.CONTENT,
        )
        self.min_attribution_ratio = min_attribution_ratio
        self.dialogue_pattern = re.compile(r'"[^"]*"')
        self.attribution_pattern = re.compile(
            r'(?:(?:")\s*[\w\s,]*\s+(?:said|asked|replied|whispered|shouted|murmured|exclaimed|cried|yelled)\s+\w+)'
        )

    def validate_content(
        self, content: str, context: Optional[Dict[str, Any]] = None
    ) -> ValidationResult:
        dialogue_lines = self.dialogue_pattern.findall(content)
        attributed_lines = self.attribution_pattern.findall(content)

        if len(dialogue_lines) == 0:
            return ValidationResult(
                rule=self, passed=True, message="No dialogue found", context={"dialogue_lines": 0}
            )

        attribution_ratio = len(attributed_lines) / len(dialogue_lines)
        passed = attribution_ratio >= self.min_attribution_ratio

        return ValidationResult(
            rule=self,
            passed=passed,
            message=(
                f"Dialogue attribution: {attribution_ratio:.1%} "
                f"(minimum: {self.min_attribution_ratio:.1%})"
            ),
            suggestion="Add speaker attributions to dialogue lines" if not passed else None,
            context={
                "dialogue_lines": len(dialogue_lines),
                "attributed_lines": len(attributed_lines),
            },
        )


class DialogueBalanceRule(ValidationRule):
    """Rule to ensure balanced dialogue and narrative."""

    def __init__(self, min_ratio: float = 0.1, max_ratio: float = 0.7):
        super().__init__(
            rule_id="dialogue_balance",
            name="Dialogue Balance",
            description="Ensures balanced mix of dialogue and narrative",
            severity=Severity.INFO,
            category=RuleCategory.CONTENT,
        )
        self.min_ratio = min_ratio
        self.max_ratio = max_ratio
        self.dialogue_pattern = re.compile(r'"[^"]*"')

    def validate_content(
        self, content: str, context: Optional[Dict[str, Any]] = None
    ) -> ValidationResult:
        dialogue_matches = self.dialogue_pattern.findall(content)
        dialogue_words = sum(len(re.findall(r"\b\w+\b", d)) for d in dialogue_matches)
        total_words = len(re.findall(r"\b\w+\b", content))

        dialogue_ratio = dialogue_words / max(total_words, 1)
        passed = self.min_ratio <= dialogue_ratio <= self.max_ratio

        if dialogue_ratio < self.min_ratio:
            message = f"Dialogue ratio: {dialogue_ratio:.1%} (below minimum: {self.min_ratio:.1%})"
            suggestion = "Consider adding dialogue to improve engagement"
        elif dialogue_ratio > self.max_ratio:
            message = f"Dialogue ratio: {dialogue_ratio:.1%} (above maximum: {self.max_ratio:.1%})"
            suggestion = "Consider adding narrative context"
        else:
            message = f"Dialogue ratio: {dialogue_ratio:.1%} (balanced)"
            suggestion = None

        return ValidationResult(
            rule=self,
            passed=passed,
            message=message,
            suggestion=suggestion,
            context={"dialogue_ratio": dialogue_ratio},
        )


# ---------------------------------------------------------------------------
# Structure rules
# ---------------------------------------------------------------------------


class ChapterOutlineAlignmentRule(ValidationRule):
    """Rule to ensure content aligns with chapter outline."""

    def __init__(self):
        super().__init__(
            rule_id="outline_alignment",
            name="Chapter Outline Alignment",
            description="Checks that chapter content aligns with outline",
            severity=Severity.WARNING,
            category=RuleCategory.STRUCTURE,
        )

    def validate_content(
        self, content: str, context: Optional[Dict[str, Any]] = None
    ) -> ValidationResult:
        if not context or "outline_key_points" not in context:
            return ValidationResult(
                rule=self, passed=True, message="No outline provided for validation"
            )

        key_points = context["outline_key_points"]
        missing_points = []

        for point in key_points:
            if point.lower() not in content.lower():
                missing_points.append(point)

        passed = len(missing_points) == 0

        return ValidationResult(
            rule=self,
            passed=passed,
            message=f"Missing {len(missing_points)} of {len(key_points)} key outline points",
            suggestion=(
                f"Include missing plot points: {', '.join(missing_points[:3])}"
                if not passed
                else None
            ),
            context={"missing_points": missing_points},
        )


class SceneLengthRule(ValidationRule):
    """Rule to check scene length variation."""

    def __init__(self, min_words: int = 200, max_words: int = 2000):
        super().__init__(
            rule_id="scene_length",
            name="Scene Length",
            description="Checks for appropriate scene lengths",
            severity=Severity.INFO,
            category=RuleCategory.STRUCTURE,
        )
        self.min_words = min_words
        self.max_words = max_words
        self.scene_break_pattern = re.compile(r"\n\s*\n\s*[*#-]{3,}\n|\n\s*\n\s*~{3,}\n")

    def validate_content(
        self, content: str, context: Optional[Dict[str, Any]] = None
    ) -> ValidationResult:
        scenes = self.scene_break_pattern.split(content)
        scenes = [s.strip() for s in scenes if s.strip()]

        if len(scenes) <= 1:
            return ValidationResult(
                rule=self, passed=True, message="Single scene detected", context={"scene_count": 1}
            )

        scene_lengths = [len(re.findall(r"\b\w+\b", scene)) for scene in scenes]
        too_short = [sl for sl in scene_lengths if sl < self.min_words]
        too_long = [sl for sl in scene_lengths if sl > self.max_words]

        passed = len(too_short) == 0 and len(too_long) == 0

        message = f"Scene lengths: {min(scene_lengths)} - {max(scene_lengths)} words"
        if too_short or too_long:
            message += f" ({len(too_short)} too short, {len(too_long)} too long)"

        return ValidationResult(
            rule=self,
            passed=passed,
            message=message,
            suggestion="Adjust scene lengths for better pacing" if not passed else None,
            context={
                "scene_count": len(scenes),
                "too_short": len(too_short),
                "too_long": len(too_long),
            },
        )


# ---------------------------------------------------------------------------
# Style rules
# ---------------------------------------------------------------------------


class MaxSentenceLengthRule(ValidationRule):
    """Rule to prevent overly long sentences."""

    def __init__(self, max_length: int = 40):
        super().__init__(
            rule_id="max_sentence_length",
            name="Maximum Sentence Length",
            description="Prevents sentences that are too long",
            severity=Severity.WARNING,
            category=RuleCategory.STYLE,
        )
        self.max_length = max_length

    def validate_content(
        self, content: str, context: Optional[Dict[str, Any]] = None
    ) -> ValidationResult:
        sentences = re.split(r"[.!?]+", content)

        long_sentences = []
        for i, sentence in enumerate(sentences):
            words = len(re.findall(r"\b\w+\b", sentence))
            if words > self.max_length:
                long_sentences.append((i, words))

        passed = len(long_sentences) == 0

        message = f"Found {len(long_sentences)} sentences exceeding {self.max_length} words"
        suggestion = "Break long sentences into shorter ones" if not passed else None

        if long_sentences:
            worst_sentence = max(long_sentences, key=lambda x: x[1])
            message += f" (worst: {worst_sentence[1]} words)"

        return ValidationResult(
            rule=self,
            passed=passed,
            message=message,
            suggestion=suggestion,
            context={"long_sentences": len(long_sentences)},
        )


class PassiveVoiceRule(ValidationRule):
    """Rule to limit passive voice usage."""

    def __init__(self, max_ratio: float = 0.15):
        super().__init__(
            rule_id="passive_voice",
            name="Passive Voice Usage",
            description="Limits passive voice construction usage",
            severity=Severity.WARNING,
            category=RuleCategory.STYLE,
        )
        self.max_ratio = max_ratio
        self.passive_patterns = [
            re.compile(r"\b(was|were|been|being)\s+(\w+ed)\b", re.IGNORECASE),
            re.compile(r"\b(was|were)\s+\w+\s+by\b", re.IGNORECASE),
        ]

    def validate_content(
        self, content: str, context: Optional[Dict[str, Any]] = None
    ) -> ValidationResult:
        sentences = re.split(r"[.!?]+", content)
        total_sentences = len([s for s in sentences if s.strip()])

        passive_count = 0
        for pattern in self.passive_patterns:
            passive_count += len(pattern.findall(content))

        passive_ratio = passive_count / max(total_sentences, 1)
        passed = passive_ratio <= self.max_ratio

        return ValidationResult(
            rule=self,
            passed=passed,
            message=f"Passive voice: {passive_ratio:.1%} (maximum: {self.max_ratio:.1%})",
            suggestion="Rewrite passive constructions as active voice" if not passed else None,
            context={"passive_count": passive_count, "total_sentences": total_sentences},
        )


class AdverbOveruseRule(ValidationRule):
    """Rule to limit adverb usage."""

    def __init__(self, max_ratio: float = 0.08):
        super().__init__(
            rule_id="adverb_overuse",
            name="Adverb Overuse",
            description="Limits excessive adverb usage",
            severity=Severity.WARNING,
            category=RuleCategory.STYLE,
        )
        self.max_ratio = max_ratio
        self.adverb_pattern = re.compile(r"\b\w+ly\b", re.IGNORECASE)

    def validate_content(
        self, content: str, context: Optional[Dict[str, Any]] = None
    ) -> ValidationResult:
        words = re.findall(r"\b[a-zA-Z]+\b", content)
        adverbs = self.adverb_pattern.findall(content)

        adverb_ratio = len(adverbs) / max(len(words), 1)
        passed = adverb_ratio <= self.max_ratio

        return ValidationResult(
            rule=self,
            passed=passed,
            message=f"Adverb usage: {adverb_ratio:.1%} (maximum: {self.max_ratio:.1%})",
            suggestion="Replace adverbs with stronger verbs" if not passed else None,
            context={"adverb_count": len(adverbs), "total_words": len(words)},
        )


# ---------------------------------------------------------------------------
# Continuity rules
# ---------------------------------------------------------------------------


class CharacterConsistencyRule(ValidationRule):
    """Rule to check character name consistency."""

    def __init__(self):
        super().__init__(
            rule_id="character_consistency",
            name="Character Consistency",
            description="Checks that character names are used consistently",
            severity=Severity.ERROR,
            category=RuleCategory.CONTINUITY,
        )

    def validate_content(
        self, content: str, context: Optional[Dict[str, Any]] = None
    ) -> ValidationResult:
        if not context or "character_names" not in context:
            return ValidationResult(
                rule=self, passed=True, message="No character names provided for validation"
            )

        character_names = context["character_names"]
        missing_characters = []

        for name in character_names:
            if name not in content:
                missing_characters.append(name)

        passed = len(missing_characters) == 0

        return ValidationResult(
            rule=self,
            passed=passed,
            message=f"Missing {len(missing_characters)} of {len(character_names)} characters",
            suggestion=(
                f"Incorporate characters: {', '.join(missing_characters)}" if not passed else None
            ),
            context={"missing_characters": missing_characters},
        )


class TimelineContinuityRule(ValidationRule):
    """Rule to check timeline continuity."""

    def __init__(self):
        super().__init__(
            rule_id="timeline_continuity",
            name="Timeline Continuity",
            description="Checks for timeline continuity issues",
            severity=Severity.ERROR,
            category=RuleCategory.CONTINUITY,
        )
        self.time_pattern = re.compile(
            r"\b(morning|afternoon|evening|night|midnight|noon|dawn|dusk)\b", re.IGNORECASE
        )

    def validate_content(
        self, content: str, context: Optional[Dict[str, Any]] = None
    ) -> ValidationResult:
        if not context or "chapter_order" not in context:
            return ValidationResult(rule=self, passed=True, message="No timeline context provided")

        time_references = self.time_pattern.findall(content)

        passed = True
        message = f"Found {len(time_references)} time references"

        if len(time_references) > 5:
            passed = False
            message += " (excessive time shifts detected)"

        return ValidationResult(
            rule=self,
            passed=passed,
            message=message,
            suggestion="Review timeline consistency" if not passed else None,
            context={"time_references": time_references},
        )
