"""
Data models for multi-chapter management.

Contains chapter loading status, references, indices, content cache,
and manager configuration.
"""

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Set

from pydantic import BaseModel, ConfigDict

from .chapter_paginator import ChapterPage


class ChapterLoadStatus(str, Enum):
    """Status of chapter loading."""

    NOT_LOADED = "not_loaded"
    LOADING = "loading"
    LOADED = "loaded"
    ERROR = "error"


@dataclass
class ChapterReference:
    """Reference to chapter content with metadata."""

    chapter_number: int
    file_path: Path
    page_count: int
    word_count: int
    token_count: int
    status: ChapterLoadStatus = ChapterLoadStatus.NOT_LOADED
    last_accessed: float = 0.0
    metadata: Dict[str, any] = field(default_factory=dict)

    @property
    def is_loaded(self) -> bool:
        """Check if chapter is loaded."""
        return self.status == ChapterLoadStatus.LOADED

    @property
    def size_kb(self) -> float:
        """Get estimated size in kilobytes."""
        return self.token_count * 2 / 1024  # Rough estimate


@dataclass
class ChapterIndex:
    """Index for efficient chapter lookup."""

    chapter_number: int
    title: Optional[str]
    word_count: int
    page_count: int
    characters: Set[str] = field(default_factory=set)
    locations: Set[str] = field(default_factory=set)
    key_events: List[str] = field(default_factory=list)
    outline_summary: Optional[str] = None

    def matches_query(self, query: str) -> bool:
        """Check if index matches search query."""
        query_lower = query.lower()

        # Check title
        if self.title and query_lower in self.title.lower():
            return True

        # Check characters
        if any(query_lower in char.lower() for char in self.characters):
            return True

        # Check locations
        if any(query_lower in loc.lower() for loc in self.locations):
            return True

        # Check outline summary
        if self.outline_summary and query_lower in self.outline_summary.lower():
            return True

        return False


@dataclass
class ChapterContent:
    """Cached chapter content with pages."""

    chapter_number: int
    content: str
    pages: List[ChapterPage]
    metadata: Dict[str, any] = field(default_factory=dict)
    load_time: float = 0.0
    access_count: int = 0

    def get_page(self, page_number: int) -> Optional[ChapterPage]:
        """Get a specific page by number."""
        for page in self.pages:
            if page.page_number == page_number:
                return page
        return None

    def get_page_range(self, start_page: int, end_page: int) -> List[ChapterPage]:
        """Get a range of pages."""
        return [p for p in self.pages if start_page <= p.page_number <= end_page]


class MultiChapterManagerConfig(BaseModel):
    """Configuration for multi-chapter manager."""

    max_loaded_chapters: int = 50
    lazy_loading_enabled: bool = True
    cache_chapters_enabled: bool = True
    index_characters: bool = True
    index_locations: bool = True
    prefetch_ahead: int = 2

    model_config = ConfigDict(use_enum_values=True)
