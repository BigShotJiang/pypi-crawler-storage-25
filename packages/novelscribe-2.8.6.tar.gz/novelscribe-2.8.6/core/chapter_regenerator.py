"""Chapter regeneration system with multiple strategies."""

from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from core.agent_registry import AgentRegistry
from core.draft_manager import DraftManager
from core.storage import StorageConfig, StorageFactory


class RegenerationStrategy(str, Enum):
    FULL = "full"
    TARGETED = "targeted"
    CONTINUITY = "continuity"
    STYLE = "style"


class RegenerationConfig(BaseModel):
    strategy: RegenerationStrategy
    preserve_dialogue: bool = True
    preserve_action_scenes: bool = True
    fix_issues: List[str] = Field(default_factory=list)
    style_target: Optional[str] = None
    max_word_count: Optional[int] = None
    quality_threshold: float = 0.7
    story_context: Dict[str, Any] = Field(default_factory=dict)


class RegenerationResult(BaseModel):
    success: bool
    chapter_number: int
    new_version: int
    words_changed: int
    content_similarity: float
    issues_resolved: List[str] = Field(default_factory=list)
    new_issues: List[str] = Field(default_factory=list)
    regeneration_time: float = 0.0
    quality_score: Optional[float] = None


class ChapterRegenerator:
    def __init__(self, project_dir: str):
        self.project_dir = Path(project_dir)
        self.draft_manager = DraftManager(str(self.project_dir))

        storage_config = StorageConfig(base_path=str(self.project_dir))
        self.storage = StorageFactory.create(storage_config)
        self.agent_registry = AgentRegistry(storage_config)

    def regenerate(
        self, chapter_number: int, config: RegenerationConfig, reason: str = "regeneration"
    ) -> RegenerationResult:
        start_time = datetime.now()

        current_content = self._get_current_content(chapter_number)
        if not current_content:
            return RegenerationResult(
                success=False,
                chapter_number=chapter_number,
                new_version=0,
                words_changed=0,
                content_similarity=0.0,
                new_issues=["Chapter not found"],
            )

        try:
            new_content = self._execute_regeneration(chapter_number, current_content, config)

            similarity = self._calculate_similarity(current_content, new_content)
            words_changed = self._count_words_changed(current_content, new_content)

            quality_score = self._assess_quality(new_content, config)

            if quality_score < config.quality_threshold:
                return RegenerationResult(
                    success=False,
                    chapter_number=chapter_number,
                    new_version=0,
                    words_changed=words_changed,
                    content_similarity=similarity,
                    new_issues=[
                        f"Quality score {quality_score:.2f} "
                        f"below threshold {config.quality_threshold}"
                    ],
                )

            metadata = self.draft_manager.create_new_version(
                chapter_number=chapter_number,
                content=new_content,
                reason=reason,
                quality_score=quality_score,
                issues_fixed=config.fix_issues,
            )

            regeneration_time = (datetime.now() - start_time).total_seconds()

            return RegenerationResult(
                success=True,
                chapter_number=chapter_number,
                new_version=metadata.version,
                words_changed=words_changed,
                content_similarity=similarity,
                issues_resolved=config.fix_issues,
                regeneration_time=regeneration_time,
                quality_score=quality_score,
            )

        except Exception as e:
            regeneration_time = (datetime.now() - start_time).total_seconds()

            return RegenerationResult(
                success=False,
                chapter_number=chapter_number,
                new_version=0,
                words_changed=0,
                content_similarity=0.0,
                new_issues=[str(e)],
                regeneration_time=regeneration_time,
            )

    def _get_current_content(self, chapter_number: int) -> Optional[str]:
        current_version = self.draft_manager.get_current_version(chapter_number)

        if not current_version:
            return None

        current_file = Path(current_version.file_path)
        if not current_file.exists():
            return None

        return current_file.read_text()

    def _execute_regeneration(
        self, chapter_number: int, current_content: str, config: RegenerationConfig
    ) -> str:
        if config.strategy == RegenerationStrategy.FULL:
            return self._regenerate_full(chapter_number, config)
        elif config.strategy == RegenerationStrategy.TARGETED:
            return self._regenerate_targeted(chapter_number, current_content, config)
        elif config.strategy == RegenerationStrategy.CONTINUITY:
            return self._regenerate_continuity(chapter_number, current_content, config)
        elif config.strategy == RegenerationStrategy.STYLE:
            return self._regenerate_style(chapter_number, current_content, config)
        else:
            raise ValueError(f"Unknown strategy: {config.strategy}")

    def _regenerate_full(self, chapter_number: int, config: RegenerationConfig) -> str:
        outline_content = self._load_chapter_outline(chapter_number)
        context = self._build_regeneration_context(chapter_number, config)

        prompt = f"""
Generate a complete new version of Chapter {chapter_number}.

Outline:
{outline_content}

Context:
{context}

Requirements:
- Max word count: {config.max_word_count or "no limit"}
- Preserve dialogue: {config.preserve_dialogue}
- Preserve action scenes: {config.preserve_action_scenes}

Generate the complete chapter content:
"""

        agent = self.agent_registry.get_agent("writer_agent")
        result = agent.execute({"prompt": prompt})

        if result.get("success"):
            return result.get("content", "")
        else:
            raise RuntimeError(f"Regeneration failed: {result.get('error')}")

    def _regenerate_targeted(
        self, chapter_number: int, current_content: str, config: RegenerationConfig
    ) -> str:
        if not config.fix_issues:
            return current_content

        context = self._build_regeneration_context(chapter_number, config)

        prompt = f"""
Revise the following chapter content to fix specific issues:
{", ".join(config.fix_issues)}

Current Content:
{current_content}

Context:
{context}

Instructions:
- Preserve dialogue: {config.preserve_dialogue}
- Preserve action scenes: {config.preserve_action_scenes}
- Only modify sections that need fixes
- Maintain overall story flow

Generate the revised content:
"""

        agent = self.agent_registry.get_agent("editor_agent")
        result = agent.execute({"prompt": prompt})

        if result.get("success"):
            return result.get("content", current_content)
        else:
            return current_content

    def _regenerate_continuity(
        self, chapter_number: int, current_content: str, config: RegenerationConfig
    ) -> str:
        continuity_context = self._load_continuity_context(chapter_number)

        prompt = f"""
Fix continuity issues in the following chapter:

Current Content:
{current_content}

Continuity Context:
{continuity_context}

Issues to Fix:
{", ".join(config.fix_issues) if config.fix_issues else "All continuity issues"}

Generate the fixed content:
"""

        agent = self.agent_registry.get_agent("continuity_agent")
        result = agent.execute({"prompt": prompt})

        if result.get("success"):
            return result.get("content", current_content)
        else:
            return current_content

    def _regenerate_style(
        self, chapter_number: int, current_content: str, config: RegenerationConfig
    ) -> str:
        style_instructions = config.style_target or "improve readability and flow"

        prompt = f"""
Rewrite the following chapter with style adjustments: {style_instructions}

Current Content:
{current_content}

Requirements:
- Preserve all dialogue
- Preserve all action scenes
- Maintain plot continuity
- Only improve style and prose

Generate the styled content:
"""

        agent = self.agent_registry.get_agent("style_agent")
        result = agent.execute({"prompt": prompt})

        if result.get("success"):
            return result.get("content", current_content)
        else:
            return current_content

    def _load_chapter_outline(self, chapter_number: int) -> str:
        outline_file = self.project_dir / "outline" / f"chapter_{chapter_number:03d}.md"

        if outline_file.exists():
            return outline_file.read_text()

        return f"Chapter {chapter_number} outline not available"

    def _load_continuity_context(self, chapter_number: int) -> str:
        context_file = self.project_dir / "continuity" / "context.md"

        if context_file.exists():
            return context_file.read_text()

        return "Continuity context not available"

    def _build_regeneration_context(
        self, chapter_number: int, config: RegenerationConfig
    ) -> Dict[str, Any]:
        context = {
            "chapter_number": chapter_number,
            "project_dir": str(self.project_dir),
            **config.story_context,
        }

        if config.max_word_count:
            context["max_words"] = config.max_word_count

        if config.style_target:
            context["style_target"] = config.style_target

        return context

    def _calculate_similarity(self, content1: str, content2: str) -> float:
        words1 = set(content1.lower().split())
        words2 = set(content2.lower().split())

        if not words1 or not words2:
            return 0.0

        intersection = words1.intersection(words2)
        union = words1.union(words2)

        return len(intersection) / len(union) if union else 0.0

    def _count_words_changed(self, content1: str, content2: str) -> int:
        words1 = content1.split()
        words2 = content2.split()

        return abs(len(words1) - len(words2))

    def _assess_quality(self, content: str, config: RegenerationConfig) -> float:
        word_count = len(content.split())

        if config.max_word_count and word_count > config.max_word_count:
            return 0.5

        dialogue_count = content.count('"') // 2
        sentence_count = content.count(".")

        if sentence_count == 0:
            return 0.5

        avg_sentence_length = word_count / sentence_count

        if avg_sentence_length < 5 or avg_sentence_length > 30:
            return 0.6

        score = 0.8

        if dialogue_count > 0:
            score += 0.1

        if word_count > 500:
            score += 0.1

        return min(1.0, score)

    def batch_regenerate(
        self,
        chapter_numbers: List[int],
        config: RegenerationConfig,
        reason: str = "batch_regeneration",
    ) -> List[RegenerationResult]:
        results = []

        for chapter_number in chapter_numbers:
            result = self.regenerate(chapter_number, config, reason)
            results.append(result)

        return results
