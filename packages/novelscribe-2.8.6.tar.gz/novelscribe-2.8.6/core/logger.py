"""
Novel Harness - Comprehensive Logging System

Tracks all LLM requests, responses, token usage, costs, latency, errors, and user actions.
Provides complete audit trails for cost optimization, debugging, and performance monitoring.

Features:
- SQLite storage for structured queries
- JSON logs for human readability
- Token usage tracking and aggregation
- Cost calculation for all providers
- Budget alerts
- Query engine for analytics
"""

from __future__ import annotations

import sqlite3
import threading
import uuid
from pathlib import Path
from typing import Any, Dict, Optional

from core.cost_calculator import CostCalculator
from core.logger_backends import JSONLogger, SQLiteLogger
from core.logger_types import (
    ActionType,
    LLMRequest,
    LogType,
    RequestStatus,
    UserAction,
)
from core.token_tracker import TokenUsageTracker

__all__ = [
    "LogType",
    "ActionType",
    "RequestStatus",
    "LLMRequest",
    "UserAction",
    "JSONLogger",
    "SQLiteLogger",
    "NovelHarnessLogger",
    "get_logger",
    "log_llm_request",
    "log_user_action",
]


class NovelHarnessLogger:
    """
    Central logging system for Novel Harness.

    Tracks:
    - LLM requests and responses
    - Token usage and costs
    - User actions
    - Project events

    Access via:
    - Direct Python API
    - CLI commands
    - API endpoints
    """

    _instance: Optional[NovelHarnessLogger] = None
    _lock = threading.Lock()

    def __init__(
        self,
        storage_path: str = ".logs",
        enable_json_logs: bool = True,
        enable_sqlite_logs: bool = True,
    ):
        """Initialize the logger system"""
        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(parents=True, exist_ok=True)

        self.enable_json_logs = enable_json_logs
        self.enable_sqlite_logs = enable_sqlite_logs

        # Initialize components
        if enable_sqlite_logs:
            self.db_logger = SQLiteLogger(str(self.storage_path / "logs.db"))
        else:
            self.db_logger = None

        if enable_json_logs:
            self.json_logger = JSONLogger(str(self.storage_path / "json"))
        else:
            self.json_logger = None

        # Initialize helpers
        self.cost_calculator = CostCalculator()
        self.token_tracker = TokenUsageTracker(self.db_logger) if self.db_logger else None

    @classmethod
    def get_instance(cls) -> NovelHarnessLogger:
        """Get singleton instance"""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    def log_llm_request(
        self,
        provider: str,
        model: str,
        input_tokens: int,
        output_tokens: int,
        latency_ms: int,
        project_name: Optional[str] = None,
        agent_name: Optional[str] = None,
        system_prompt: str = "",
        user_prompt: str = "",
        max_tokens: int = 4000,
        temperature: float = 0.7,
        cache_hit: bool = False,
        error: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Log an LLM request.

        Args:
            provider: LLM provider (openai, anthropic, google)
            model: Model name
            input_tokens: Number of input tokens
            output_tokens: Number of output tokens
            latency_ms: Request latency in milliseconds
            project_name: Optional project name
            agent_name: Optional agent name
            system_prompt: System prompt used
            user_prompt: User prompt used
            max_tokens: Max tokens requested
            temperature: Temperature setting
            cache_hit: Whether response was from cache
            error: Optional error message
            metadata: Optional additional metadata

        Returns:
            Request ID for the logged request
        """
        request_id = f"req_{uuid.uuid4().hex[:12]}"
        total_tokens = input_tokens + output_tokens

        # Calculate cost
        cost_usd = self.cost_calculator.calculate(provider, model, input_tokens, output_tokens)

        # Determine status
        if error:
            status = RequestStatus.ERROR
        elif cache_hit:
            status = RequestStatus.SUCCESS
        else:
            status = RequestStatus.SUCCESS

        # Create request object
        request = LLMRequest(
            request_id=request_id,
            project_name=project_name,
            agent_name=agent_name,
            provider=provider,
            model=model,
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=total_tokens,
            cost_usd=cost_usd,
            latency_ms=latency_ms,
            status=status,
            error_message=error,
            cache_hit=cache_hit,
            metadata=metadata or {},
        )

        # Log to SQLite
        if self.db_logger:
            self.db_logger.log_llm_request(request)
            self.db_logger.update_token_summary(request)

        # Log to JSON
        if self.json_logger:
            self.json_logger.log(self._request_to_json(request))

        return request_id

    def log_user_action(
        self,
        action_type: ActionType,
        user_command: str,
        project_name: Optional[str] = None,
        parameters: Optional[Dict[str, Any]] = None,
        result: Optional[str] = None,
        execution_time_ms: int = 0,
        success: bool = True,
    ) -> str:
        """
        Log a user action.

        Args:
            action_type: Type of action (CLI, API, WEB)
            user_command: Command or request made
            project_name: Optional project name
            parameters: Action parameters
            result: Action result
            execution_time_ms: Execution time in milliseconds
            success: Whether action succeeded

        Returns:
            Action ID for the logged action
        """
        action_id = f"act_{uuid.uuid4().hex[:12]}"

        action = UserAction(
            action_id=action_id,
            action_type=action_type,
            user_command=user_command,
            project_name=project_name,
            parameters=parameters or {},
            result=result,
            execution_time_ms=execution_time_ms,
            success=success,
        )

        # Log to SQLite
        if self.db_logger:
            self.db_logger.log_user_action(action)

        # Log to JSON
        if self.json_logger:
            self.json_logger.log(self._action_to_json(action))

        return action_id

    def log_project_created(self, project_name: str, genre: str, target_words: int):
        """Log project creation"""
        if self.db_logger:
            self.db_logger.log_project_event(
                project_name, "created", {"genre": genre, "target_words": target_words}
            )

    def log_project_deleted(self, project_name: str):
        """Log project deletion"""
        if self.db_logger:
            self.db_logger.log_project_event(project_name, "deleted", {})

    def _request_to_json(self, request: LLMRequest) -> Dict[str, Any]:
        """Convert request to JSON-serializable dict"""
        return {
            "version": "1.0",
            "type": LogType.LLM_REQUEST.value,
            "timestamp": request.timestamp.isoformat(),
            "request_id": request.request_id,
            "project": request.project_name,
            "agent": request.agent_name,
            "provider": request.provider,
            "model": request.model,
            "request": {
                "system_prompt": request.system_prompt[:500] if request.system_prompt else "",
                "user_prompt": request.user_prompt[:500] if request.user_prompt else "",
                "max_tokens": request.max_tokens,
                "temperature": request.temperature,
            },
            "usage": {
                "input_tokens": request.input_tokens,
                "output_tokens": request.output_tokens,
                "total_tokens": request.total_tokens,
                "cost_usd": request.cost_usd,
            },
            "performance": {"latency_ms": request.latency_ms, "cache_hit": request.cache_hit},
            "status": request.status.value,
            "error": request.error_message,
        }

    def _action_to_json(self, action: UserAction) -> Dict[str, Any]:
        """Convert action to JSON-serializable dict"""
        return {
            "version": "1.0",
            "type": LogType.USER_ACTION.value,
            "timestamp": action.timestamp.isoformat(),
            "action_id": action.action_id,
            "action_type": action.action_type.value,
            "user_command": action.user_command,
            "project": action.project_name,
            "parameters": action.parameters,
            "result": action.result,
            "execution_time_ms": action.execution_time_ms,
            "success": action.success,
        }

    def get_stats(self) -> Dict[str, Any]:
        """Get logging statistics"""
        if not self.db_logger:
            return {"error": "SQLite logging disabled"}

        conn = sqlite3.connect(self.db_logger.db_path)
        cursor = conn.cursor()

        # Total requests
        cursor.execute("SELECT COUNT(*) FROM llm_requests")
        total_requests = cursor.fetchone()[0]

        # Total tokens
        cursor.execute("SELECT COALESCE(SUM(total_tokens), 0) FROM llm_requests")
        total_tokens = cursor.fetchone()[0]

        # Total cost
        cursor.execute("SELECT COALESCE(SUM(cost_usd), 0) FROM llm_requests")
        total_cost = cursor.fetchone()[0]

        # Error count
        cursor.execute("SELECT COUNT(*) FROM llm_requests WHERE status = 'error'")
        error_count = cursor.fetchone()[0]

        # User actions
        cursor.execute("SELECT COUNT(*) FROM user_actions")
        total_actions = cursor.fetchone()[0]

        # Recent requests (last 24h)
        cursor.execute("""
            SELECT COUNT(*) FROM llm_requests
            WHERE timestamp > datetime('now', '-1 day')
        """)
        recent_requests = cursor.fetchone()[0]

        conn.close()

        return {
            "total_requests": total_requests,
            "total_tokens": total_tokens,
            "total_cost_usd": round(total_cost, 4),
            "error_count": error_count,
            "error_rate": round(error_count / total_requests * 100, 2) if total_requests > 0 else 0,
            "total_actions": total_actions,
            "recent_requests_24h": recent_requests,
        }


# Global logger instance
_logger: Optional[NovelHarnessLogger] = None


def get_logger() -> NovelHarnessLogger:
    """Get the global logger instance"""
    global _logger
    if _logger is None:
        _logger = NovelHarnessLogger.get_instance()
    return _logger


def log_llm_request(**kwargs) -> str:
    """Convenience function to log LLM request"""
    return get_logger().log_llm_request(**kwargs)


def log_user_action(**kwargs) -> str:
    """Convenience function to log user action"""
    return get_logger().log_user_action(**kwargs)
