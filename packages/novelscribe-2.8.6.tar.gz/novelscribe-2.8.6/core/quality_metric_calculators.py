"""Quality metrics calculator for generated novel content."""

import math
import re
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from core.quality_metric_types import (
    ContentMetrics,
    DialogueMetrics,
    PacingMetrics,
    QualityMetrics,
    ReadabilityMetrics,
    StyleMetrics,
)


class QualityMetricsCalculator:
    """Comprehensive quality metrics calculator for novel content."""

    DIALOGUE_PATTERN = re.compile(r'"[^"]*"', re.MULTILINE)
    SPEAKER_TAG_PATTERN = re.compile(
        r'"\s*([a-zA-Z]+)\s+(said|asked|replied|whispered|shouted|murmured|exclaimed|cried|yelled)'
    )
    PASSIVE_VOICE_PATTERNS = [
        re.compile(r"\b(was|were|been|being)\s+(\w+ed)\b", re.IGNORECASE),
        re.compile(r"\b(was|were)\s+\w+\s+by\b", re.IGNORECASE),
    ]
    ADVERB_PATTERN = re.compile(r"\b\w+ly\b", re.IGNORECASE)
    SENTENCE_PATTERN = re.compile(r'[.!?]+[ \n]*["\']?')
    PARAGRAPH_PATTERN = re.compile(r"\n\s*\n")
    WORD_PATTERN = re.compile(r"\b[a-zA-Z]+\b")

    ACTION_VERBS = {
        "ran",
        "jumped",
        "fought",
        "attacked",
        "defended",
        "dodged",
        "struck",
        "kicked",
        "punched",
        "grabbed",
        "threw",
        "caught",
        "slammed",
        "crashed",
        "exploded",
        "fired",
        "shot",
        "charged",
        "rushed",
        "sped",
        "dashed",
        "sprinted",
        "leaped",
        "dived",
        "rolled",
        "twisted",
        "turned",
        "spun",
        "flipped",
        "soared",
        "plummeted",
        "fell",
    }

    def __init__(self, project_root: Optional[Path] = None):
        """Initialize the quality metrics calculator."""
        self.project_root = project_root or Path.cwd()
        self.character_names: set = set()
        self.location_names: set = set()

    def calculate_metrics(
        self,
        content: str,
        chapter_number: int,
        version: int = 1,
        character_names: Optional[List[str]] = None,
        location_names: Optional[List[str]] = None,
    ) -> QualityMetrics:
        """
        Calculate comprehensive quality metrics for content.

        Args:
            content: Text content to analyze
            chapter_number: Chapter number for tracking
            version: Draft version number
            character_names: Known character names for consistency checking
            location_names: Known location names for consistency checking

        Returns:
            QualityMetrics object with all calculated metrics
        """
        if character_names:
            self.character_names = set(character_names)
        if location_names:
            self.location_names = set(location_names)

        content_metrics = self._calculate_content_metrics(content)
        readability_metrics = self._calculate_readability_metrics(content)
        dialogue_metrics = self._calculate_dialogue_metrics(content)
        pacing_metrics = self._calculate_pacing_metrics(content)
        style_metrics = self._calculate_style_metrics(content)

        character_consistency = self._calculate_character_consistency(content)
        plot_continuity = self._calculate_plot_continuity(content)

        overall_score = self._calculate_overall_quality_score(
            content_metrics,
            readability_metrics,
            dialogue_metrics,
            pacing_metrics,
            style_metrics,
            character_consistency,
            plot_continuity,
        )

        return QualityMetrics(
            chapter_number=chapter_number,
            version=version,
            timestamp=datetime.now(),
            word_count=content_metrics.word_count,
            sentence_count=content_metrics.sentence_count,
            paragraph_count=content_metrics.paragraph_count,
            avg_sentence_length=content_metrics.avg_sentence_length,
            avg_paragraph_length=content_metrics.avg_paragraph_length,
            flesch_kincaid=readability_metrics.flesch_kincaid_grade,
            gunning_fog=readability_metrics.gunning_fog_index,
            smog_index=readability_metrics.smog_index,
            dialogue_ratio=dialogue_metrics.dialogue_ratio,
            dialogue_line_count=dialogue_metrics.dialogue_line_count,
            speaker_clarity=dialogue_metrics.speaker_clarity_score,
            scene_variation=pacing_metrics.scene_variation_score,
            action_frequency=pacing_metrics.action_frequency,
            character_consistency=character_consistency,
            plot_continuity=plot_continuity,
            passive_voice_ratio=style_metrics.passive_voice_ratio,
            adverb_frequency=style_metrics.adverb_frequency,
            vocabulary_diversity=style_metrics.vocabulary_diversity,
            overall_quality_score=overall_score,
        )

    def _calculate_content_metrics(self, content: str) -> ContentMetrics:
        """Calculate basic content structure metrics."""
        words = self.WORD_PATTERN.findall(content)
        sentences = self.SENTENCE_PATTERN.split(content)
        sentences = [s.strip() for s in sentences if s.strip()]
        paragraphs = self.PARAGRAPH_PATTERN.split(content)
        paragraphs = [p.strip() for p in paragraphs if p.strip()]

        word_count = len(words)
        sentence_count = len(sentences)
        paragraph_count = len(paragraphs)

        avg_sentence_length = word_count / max(sentence_count, 1)
        avg_paragraph_length = word_count / max(paragraph_count, 1)
        avg_word_length = sum(len(w) for w in words) / max(word_count, 1)

        return ContentMetrics(
            word_count=word_count,
            sentence_count=sentence_count,
            paragraph_count=paragraph_count,
            avg_sentence_length=avg_sentence_length,
            avg_paragraph_length=avg_paragraph_length,
            avg_word_length=avg_word_length,
        )

    def _calculate_readability_metrics(self, content: str) -> ReadabilityMetrics:
        """Calculate readability scores using various formulas."""
        words = self.WORD_PATTERN.findall(content)
        sentences = self.SENTENCE_PATTERN.split(content)
        sentences = [s.strip() for s in sentences if s.strip()]
        syllables = sum(self._count_syllables(word) for word in words)

        word_count = len(words)
        sentence_count = max(len(sentences), 1)

        if word_count == 0:
            return ReadabilityMetrics(
                flesch_kincaid_grade=0,
                flesch_reading_ease=0,
                gunning_fog_index=0,
                smog_index=0,
                coleman_liau_index=0,
            )

        flesch_kincaid = max(
            0, 0.39 * (word_count / sentence_count) + 11.8 * (syllables / word_count) - 15.59
        )

        flesch_ease = max(
            0, 206.835 - 1.015 * (word_count / sentence_count) - 84.6 * (syllables / word_count)
        )

        complex_words = sum(1 for word in words if self._count_syllables(word) >= 3)
        gunning_fog = 0.4 * ((word_count / sentence_count) + 100 * (complex_words / word_count))

        polysyllables = sum(1 for word in words if self._count_syllables(word) >= 3)
        smog = 1.0430 * math.sqrt(polysyllables * (30 / sentence_count)) + 3.1291

        letters = sum(len(c) for c in words if c.isalpha())
        coleman_liau = (
            0.0588 * (letters / word_count * 100)
            - 0.296 * (sentence_count / word_count * 100)
            - 15.8
        )

        return ReadabilityMetrics(
            flesch_kincaid_grade=flesch_kincaid,
            flesch_reading_ease=flesch_ease,
            gunning_fog_index=gunning_fog,
            smog_index=smog,
            coleman_liau_index=coleman_liau,
        )

    def _calculate_dialogue_metrics(self, content: str) -> DialogueMetrics:
        """Calculate dialogue quality metrics."""
        dialogue_matches = self.DIALOGUE_PATTERN.findall(content)
        dialogue_line_count = len(dialogue_matches)

        dialogue_words = sum(len(self.WORD_PATTERN.findall(d)) for d in dialogue_matches)
        total_words = len(self.WORD_PATTERN.findall(content))

        dialogue_ratio = dialogue_words / max(total_words, 1)

        avg_dialogue_length = (
            dialogue_words / max(dialogue_line_count, 1) if dialogue_line_count > 0 else 0
        )

        speaker_tags = self.SPEAKER_TAG_PATTERN.findall(content)
        speaker_clarity = min(len(speaker_tags) / max(dialogue_line_count, 1), 1.0)

        unique_tags = set(tag[0].lower() for tag in speaker_tags)
        dialogue_tag_diversity = len(unique_tags) / max(len(speaker_tags), 1) if speaker_tags else 0

        action_pattern = re.compile(r'"\s*\w+(?:ed|s)\s+(?:said|asked|replied)')
        action_tags = action_pattern.findall(content)
        action_tag_ratio = (
            len(action_tags) / max(dialogue_line_count, 1) if dialogue_line_count > 0 else 0
        )

        return DialogueMetrics(
            dialogue_ratio=dialogue_ratio,
            dialogue_line_count=dialogue_line_count,
            avg_dialogue_length=avg_dialogue_length,
            speaker_clarity_score=speaker_clarity,
            dialogue_tag_diversity=dialogue_tag_diversity,
            action_tag_ratio=action_tag_ratio,
        )

    def _calculate_pacing_metrics(self, content: str) -> PacingMetrics:
        """Calculate pacing and flow metrics."""
        paragraphs = self.PARAGRAPH_PATTERN.split(content)
        paragraphs = [p.strip() for p in paragraphs if p.strip()]

        paragraph_lengths = [len(self.WORD_PATTERN.findall(p)) for p in paragraphs]
        avg_paragraph_length = sum(paragraph_lengths) / max(len(paragraph_lengths), 1)

        paragraph_variance = sum(
            (pl - avg_paragraph_length) ** 2 for pl in paragraph_lengths
        ) / max(len(paragraph_lengths), 1)
        paragraph_variance = (
            math.sqrt(paragraph_variance) / avg_paragraph_length if avg_paragraph_length > 0 else 0
        )

        sentences = self.SENTENCE_PATTERN.split(content)
        sentences = [s.strip() for s in sentences if s.strip()]

        sentence_lengths = [len(self.WORD_PATTERN.findall(s)) for s in sentences]
        avg_sentence_length = sum(sentence_lengths) / max(len(sentence_lengths), 1)

        sentence_variance = sum((sl - avg_sentence_length) ** 2 for sl in sentence_lengths) / max(
            len(sentence_lengths), 1
        )
        sentence_variance = (
            math.sqrt(sentence_variance) / avg_sentence_length if avg_sentence_length > 0 else 0
        )

        scene_variation = min(paragraph_variance / 0.5, 1.0)

        words = self.WORD_PATTERN.findall(content)
        action_words = sum(1 for word in words if word.lower() in self.ACTION_VERBS)
        action_frequency = action_words / len(words) if words else 0

        transition_words = [
            "however",
            "meanwhile",
            "suddenly",
            "then",
            "next",
            "after",
            "before",
            "later",
        ]
        transition_count = sum(1 for word in words if word.lower() in transition_words)
        transition_quality = min(transition_count / len(words) * 100, 1.0) if words else 0

        return PacingMetrics(
            scene_variation_score=scene_variation,
            action_frequency=action_frequency,
            paragraph_length_variance=paragraph_variance,
            sentence_length_variance=sentence_variance,
            transition_quality=transition_quality,
        )

    def _calculate_style_metrics(self, content: str) -> StyleMetrics:
        """Calculate writing style metrics."""
        sentences = self.SENTENCE_PATTERN.split(content)
        sentences = [s.strip() for s in sentences if s.strip()]

        passive_count = 0
        for pattern in self.PASSIVE_VOICE_PATTERNS:
            passive_count += len(pattern.findall(content))

        total_sentences = len(sentences)
        passive_voice_ratio = passive_count / max(total_sentences, 1)

        words = self.WORD_PATTERN.findall(content)
        adverbs = self.ADVERB_PATTERN.findall(content)
        adverb_frequency = len(adverbs) / max(len(words), 1)

        unique_words = set(word.lower() for word in words)
        vocabulary_diversity = len(unique_words) / max(len(words), 1)

        cliches = [
            "in the nick of time",
            "at the end of the day",
            "once upon a time",
            "better late than never",
            "time will tell",
            "when all is said and done",
        ]
        cliché_count = sum(1 for cliché in cliches if cliché.lower() in content.lower())

        word_frequency = {}
        for word in words:
            word_lower = word.lower()
            word_frequency[word_lower] = word_frequency.get(word_lower, 0) + 1

        total_words = len(words)
        repetition_score = sum(count - 1 for count in word_frequency.values() if count > 1) / max(
            total_words, 1
        )

        return StyleMetrics(
            passive_voice_ratio=passive_voice_ratio,
            adverb_frequency=adverb_frequency,
            vocabulary_diversity=vocabulary_diversity,
            cliché_count=cliché_count,
            repetition_score=repetition_score,
        )

    def _calculate_character_consistency(self, content: str) -> float:
        """Calculate character name consistency score."""
        if not self.character_names:
            return 1.0

        found_names = set()
        for name in self.character_names:
            if name in content:
                found_names.add(name)

        return len(found_names) / len(self.character_names)

    def _calculate_plot_continuity(self, content: str) -> float:
        """Calculate basic plot continuity score."""
        if not self.location_names:
            return 1.0

        found_locations = set()
        for location in self.location_names:
            if location in content:
                found_locations.add(location)

        return len(found_locations) / len(self.location_names)

    def _calculate_overall_quality_score(
        self,
        content: ContentMetrics,
        readability: ReadabilityMetrics,
        dialogue: DialogueMetrics,
        pacing: PacingMetrics,
        style: StyleMetrics,
        character_consistency: float,
        plot_continuity: float,
    ) -> float:
        """Calculate overall quality score from all metrics."""

        readability_score = min(readability.flesch_reading_ease / 100, 1.0)

        dialogue_score = min(dialogue.speaker_clarity_score + dialogue.dialogue_ratio, 1.0)

        pacing_score = min(pacing.scene_variation_score + pacing.action_frequency * 10, 1.0)

        style_score = (
            (1 - style.passive_voice_ratio) * 0.3
            + (1 - style.adverb_frequency) * 0.3
            + style.vocabulary_diversity * 0.4
        )

        consistency_score = (character_consistency + plot_continuity) / 2

        overall = (
            readability_score * 0.25
            + dialogue_score * 0.20
            + pacing_score * 0.15
            + style_score * 0.20
            + consistency_score * 0.20
        )

        return min(max(overall, 0.0), 1.0)

    def _count_syllables(self, word: str) -> int:
        """Estimate syllable count in a word."""
        word = word.lower()
        count = 0
        vowels = "aeiouy"

        if word[0] in vowels:
            count += 1

        for index in range(1, len(word)):
            if word[index] in vowels and word[index - 1] not in vowels:
                count += 1

        if word.endswith("e"):
            count -= 1

        if word.endswith("le") and len(word) > 2 and word[-3] not in vowels:
            count += 1

        if count == 0:
            count = 1

        return count

    def get_metrics_summary(self, metrics: QualityMetrics) -> str:
        """Generate a human-readable summary of quality metrics."""
        summary = [
            f"## Quality Metrics Summary - Chapter {metrics.chapter_number} (v{metrics.version})",
            f"Generated: {metrics.timestamp.strftime('%Y-%m-%d %H:%M:%S')}",
            "",
            "**Content Overview**",
            f"- Words: {metrics.word_count:,}",
            f"- Sentences: {metrics.sentence_count:,}",
            f"- Paragraphs: {metrics.paragraph_count:,}",
            f"- Avg Sentence Length: {metrics.avg_sentence_length:.1f} words",
            "",
            "**Readability Scores**",
            f"- Flesch-Kincaid Grade: {metrics.flesch_kincaid:.1f}",
            f"- Gunning Fog Index: {metrics.gunning_fog:.1f}",
            f"- SMOG Index: {metrics.smog_index:.1f}",
            "",
            "**Dialogue Analysis**",
            f"- Dialogue Ratio: {metrics.dialogue_ratio:.1%}",
            f"- Dialogue Lines: {metrics.dialogue_line_count}",
            f"- Speaker Clarity: {metrics.speaker_clarity:.1%}",
            "",
            "**Pacing & Flow**",
            f"- Scene Variation: {metrics.scene_variation:.1%}",
            f"- Action Frequency: {metrics.action_frequency:.2%}",
            "",
            "**Style Assessment**",
            f"- Passive Voice: {metrics.passive_voice_ratio:.1%}",
            f"- Adverb Frequency: {metrics.adverb_frequency:.2%}",
            f"- Vocabulary Diversity: {metrics.vocabulary_diversity:.1%}",
            "",
            "**Consistency**",
            f"- Character Consistency: {metrics.character_consistency:.1%}",
            f"- Plot Continuity: {metrics.plot_continuity:.1%}",
            "",
            f"**Overall Quality Score: {metrics.overall_quality_score:.1%}**",
        ]

        return "\n".join(summary)

    def compare_metrics(
        self, metrics1: QualityMetrics, metrics2: QualityMetrics
    ) -> Dict[str, float]:
        """Compare two quality metrics objects and return differences."""
        return {
            "word_count_change": metrics2.word_count - metrics1.word_count,
            "readability_change": metrics2.flesch_kincaid - metrics1.flesch_kincaid,
            "dialogue_ratio_change": metrics2.dialogue_ratio - metrics1.dialogue_ratio,
            "passive_voice_change": metrics2.passive_voice_ratio - metrics1.passive_voice_ratio,
            "vocabulary_diversity_change": metrics2.vocabulary_diversity
            - metrics1.vocabulary_diversity,
            "overall_quality_change": metrics2.overall_quality_score
            - metrics1.overall_quality_score,
        }
