"""Checkpoint handling logic for autonomous workflow execution."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Optional

from core.progress_tracker import ExecutionStatus

if TYPE_CHECKING:
    from core.autonomous_executor import AutonomousExecutor

from core.autonomous_models import AutonomousResult


class CheckpointHandler:
    """Handles checkpoint-related operations for the autonomous executor.

    Uses composition — holds a reference to the parent AutonomousExecutor
    to access shared state (config, progress_tracker, checkpoint_manager, etc.).
    """

    def __init__(self, executor: AutonomousExecutor) -> None:
        self._executor = executor

    # ------------------------------------------------------------------
    # Public checkpoint helpers
    # ------------------------------------------------------------------

    def present_checkpoint(
        self,
        phase: str,
        chapter: Optional[int],
        execution_context: dict[str, Any],
    ) -> Optional[dict[str, Any]]:
        """Present checkpoint to human and wait for decision.

        Args:
            phase: Current phase
            chapter: Current chapter number
            execution_context: Current execution context

        Returns:
            Decision result dict or None if checkpoint is pending/waiting
        """
        executor = self._executor
        if not executor.checkpoint_orchestrator:
            raise RuntimeError("checkpoint_orchestrator is not initialized")

        checkpoint_id = executor.checkpoint_orchestrator.get_checkpoint_id(phase, chapter)

        plan_content = self.build_checkpoint_plan_content(phase, chapter, execution_context)

        state = executor.progress_tracker.get_state()
        completed = list(state.completed_phases) if state else []

        context_summary = {
            "completed_phases": completed,
            "current_phase": phase,
            "chapter": chapter,
            "project_name": executor.config.project_name,
        }

        proposal = executor.checkpoint_orchestrator.present_checkpoint(
            phase=phase,
            chapter=chapter,
            plan_content=plan_content,
            context_summary=context_summary,
        )

        executor.logger.info(f"⏸️  Checkpoint {checkpoint_id}: {proposal.plan.title}")
        confidence = proposal.confidence
        conf_str = f"{confidence:.0%}" if isinstance(confidence, (int, float)) else str(confidence)
        executor.logger.info(f"   Confidence: {conf_str}")
        executor.logger.info(f"   Reasoning: {proposal.reasoning}")

        decision = executor.checkpoint_orchestrator.await_decision(checkpoint_id)

        if decision is None:
            return None

        return decision

    def build_checkpoint_plan_content(
        self,
        phase: str,
        chapter: Optional[int],
        execution_context: dict[str, Any],
    ) -> dict[str, Any]:
        """Build plan content dict for checkpoint proposal.

        Args:
            phase: Current phase
            chapter: Current chapter
            execution_context: Current execution context

        Returns:
            Plan content dict for CheckpointProposal
        """
        title = f"{phase.replace('_', ' ').title()}"
        if chapter is not None:
            title = f"{title} - Chapter {chapter}"

        plan_content: dict[str, Any] = {
            "title": title,
            "metadata": {
                "phase": phase,
                "chapter": chapter,
                "project": self._executor.config.project_name,
            },
        }

        if phase == "new_novel":
            plan_content["word_estimate"] = 80000

        elif phase == "outline_phase":
            plan_content["word_estimate"] = execution_context.get("target_word_count", 80000)

        elif phase == "chapter_plan_phase":
            plan_content["word_estimate"] = 3000

        elif phase == "writing_phase":
            plan_content["word_estimate"] = 3000

        return plan_content

    # ------------------------------------------------------------------
    # Public API (delegated from AutonomousExecutor)
    # ------------------------------------------------------------------

    def pause_at_checkpoint(
        self,
        phase: str,
        chapter: Optional[int],
        execution_context: dict[str, Any],
    ) -> Optional[str]:
        """Pause pipeline at a checkpoint for later human review.

        Args:
            phase: Current phase name.
            chapter: Current chapter number.
            execution_context: Current execution context.

        Returns:
            Checkpoint ID if paused, None if no checkpoint needed.
        """
        executor = self._executor
        if not executor.checkpoint_orchestrator:
            return None

        if not executor.checkpoint_orchestrator.should_pause_at_phase(phase, chapter):
            return None

        checkpoint_id = executor.checkpoint_orchestrator.get_checkpoint_id(phase, chapter)
        plan_content = self.build_checkpoint_plan_content(phase, chapter, execution_context)

        state = executor.progress_tracker.get_state()
        completed = list(state.completed_phases) if state else []

        proposal = executor.checkpoint_orchestrator.present_checkpoint(
            phase=phase,
            chapter=chapter,
            plan_content=plan_content,
            context_summary={
                "completed_phases": completed,
                "current_phase": phase,
                "chapter": chapter,
                "project_name": executor.config.project_name,
            },
        )

        executor.progress_tracker.set_status(ExecutionStatus.PAUSED)
        executor.checkpoint_manager.create_checkpoint(
            completed_workflows=completed,
            current_workflow=phase,
            execution_context=execution_context,
            progress_state=executor.progress_tracker.get_state(),
        )

        executor.logger.info(f"⏸️  Paused at checkpoint {checkpoint_id}: {proposal.plan.title}")

        if executor.timeout_handler:
            executor.timeout_handler.start_timer(checkpoint_id)

        return checkpoint_id

    def resume_from_checkpoint_decision(
        self, checkpoint_id: str, decision: dict[str, Any]
    ) -> AutonomousResult:
        """Resume pipeline after human makes a checkpoint decision.

        Args:
            checkpoint_id: Checkpoint that was decided.
            decision: Decision dict with type and optional modifications.

        Returns:
            Execution result after resuming.
        """
        executor = self._executor
        if not executor.checkpoint_orchestrator:
            return AutonomousResult(
                success=False,
                completed_phases=[],
                final_status=ExecutionStatus.FAILED,
                error="No checkpoint orchestrator configured",
            )

        if executor.timeout_handler:
            executor.timeout_handler.cancel_timer(checkpoint_id)

        executor.checkpoint_orchestrator.incorporate_decision(checkpoint_id, decision)

        executor.progress_tracker.set_status(ExecutionStatus.RUNNING)
        return executor._resume_from_checkpoint()

    def checkpoint_waiting(self) -> Optional[dict[str, Any]]:
        """Check if there's a checkpoint waiting for decision.

        Returns:
            Dict with checkpoint info or None.
        """
        executor = self._executor
        if not executor.checkpoint_orchestrator:
            return None

        pending = executor.checkpoint_orchestrator.get_pending_checkpoints()
        if not pending:
            return None

        cp_id = pending[0]
        state = executor.checkpoint_orchestrator.get_checkpoint_state(cp_id)
        if not state or "proposal" not in state:
            return None

        proposal = state["proposal"]
        return {
            "checkpoint_id": cp_id,
            "phase": proposal.phase,
            "title": proposal.plan.title,
            "confidence": proposal.confidence,
            "status": state["status"],
        }

    # ------------------------------------------------------------------
    # Backward compatibility private aliases
    # ------------------------------------------------------------------

    def _present_checkpoint(
        self,
        phase: str,
        chapter: Optional[int],
        execution_context: dict[str, Any],
    ) -> Optional[dict[str, Any]]:
        """Backward-compatible alias for present_checkpoint."""
        return self.present_checkpoint(phase, chapter, execution_context)

    def _build_checkpoint_plan_content(
        self,
        phase: str,
        chapter: Optional[int],
        execution_context: dict[str, Any],
    ) -> dict[str, Any]:
        """Backward-compatible alias for build_checkpoint_plan_content."""
        return self.build_checkpoint_plan_content(phase, chapter, execution_context)

    # ------------------------------------------------------------------
    # Resume from checkpoint
    # ------------------------------------------------------------------

    def _resume_from_checkpoint(self) -> AutonomousResult:
        """Resume execution from checkpoint.

        Returns:
            Execution result
        """
        executor = self._executor
        executor.logger.info(
            f"🔄 Resuming autonomous pipeline for '{executor.config.project_name}'"
        )

        checkpoint = executor.checkpoint_manager.load_checkpoint()

        if not checkpoint:
            executor.logger.error("No checkpoint found to resume from")
            return AutonomousResult(
                success=False,
                completed_phases=[],
                final_status=ExecutionStatus.FAILED,
                error="No checkpoint found",
            )

        if not executor.checkpoint_manager.validate_checkpoint(checkpoint):
            executor.logger.error("Invalid checkpoint")
            return AutonomousResult(
                success=False,
                completed_phases=[],
                final_status=ExecutionStatus.FAILED,
                error="Invalid checkpoint",
            )

        executor.progress_tracker._state = checkpoint.progress_state
        executor.progress_tracker.set_status(ExecutionStatus.RUNNING)

        context_snapshot = executor.context_bus.restore_snapshot(
            run_id=executor.config.project_name,
        )
        if context_snapshot is not None:
            executor.logger.info(
                f"Restored context snapshot at phase={context_snapshot.phase} "
                f"step={context_snapshot.step}"
            )

        completed_phases: list[str] = checkpoint.completed_workflows
        execution_context: dict[str, Any] = checkpoint.execution_context
        current_chapter: Optional[int] = None

        last_completed = completed_phases[-1] if completed_phases else None
        start_index = executor._get_workflow_index(last_completed) + 1 if last_completed else 0
        end_index = executor._get_workflow_index(executor.config.end_phase)

        for i in range(start_index, end_index + 1):
            workflow_name = executor.WORKFLOW_CHAIN[i]

            executor.progress_tracker.update_phase(workflow_name)

            executor.logger.info(f"→ Executing phase: {workflow_name}")

            if executor.checkpoint_orchestrator:
                chapter_for_checkpoint = None
                if workflow_name in ("chapter_plan_phase", "writing_phase"):
                    chapter_for_checkpoint = current_chapter

                if executor.checkpoint_orchestrator.should_pause_at_phase(
                    workflow_name, chapter_for_checkpoint
                ):
                    checkpoint_result = executor._present_checkpoint(
                        workflow_name, chapter_for_checkpoint, execution_context
                    )

                    if checkpoint_result is None:
                        executor.logger.info("Execution paused at checkpoint (waiting for input)")
                        executor.progress_tracker.set_status(ExecutionStatus.PAUSED)

                        return AutonomousResult(
                            success=False,
                            completed_phases=completed_phases,
                            final_status=ExecutionStatus.PAUSED,
                            checkpoint_id=executor.checkpoint_orchestrator.get_checkpoint_id(
                                workflow_name, chapter_for_checkpoint
                            ),
                        )

                    if checkpoint_result.get("status") == "rejected":
                        executor.logger.info("Execution rejected by human at checkpoint")
                        executor.progress_tracker.set_status(ExecutionStatus.PAUSED)

                        return AutonomousResult(
                            success=False,
                            completed_phases=completed_phases,
                            final_status=ExecutionStatus.PAUSED,
                            error="Rejected by human at checkpoint",
                            checkpoint_id=checkpoint_result.get("checkpoint_id"),
                        )

                    if checkpoint_result.get("modified_content"):
                        execution_context["checkpoint_modifications"] = checkpoint_result[
                            "modified_content"
                        ]

                    if checkpoint_result.get("guidance"):
                        execution_context["human_guidance"] = checkpoint_result["guidance"]

            result = executor.workflow_executor.execute_workflow(
                workflow_name=workflow_name,
                project_name=executor.config.project_name,
                variables=execution_context,
                config=executor.llm_config.model_dump(),
            )

            if not result.get("success"):
                executor.logger.warning(f"⚠️  Workflow '{workflow_name}' completed with warnings")

            completed_phases.append(workflow_name)
            executor.progress_tracker.complete_phase(workflow_name)

            if workflow_name == "chapter_plan_phase":
                plan = result.get("plan", {})
                if isinstance(plan, dict):
                    chapters = plan.get("chapters", [])
                    current_chapter = len(chapters) if chapters else 0
                else:
                    current_chapter = 0

            state = executor.progress_tracker.get_state()
            if state is None:
                raise RuntimeError("Progress state is None after completing phase")

            executor.checkpoint_manager.create_checkpoint(
                completed_workflows=completed_phases,
                current_workflow=None,
                execution_context=execution_context,
                progress_state=state,
            )

            executor.context_bus.save_snapshot(
                run_id=executor.config.project_name,
                phase=workflow_name,
                step="complete",
            )

        executor.progress_tracker.set_status(ExecutionStatus.COMPLETED)
        executor.logger.info("✅ Resumed pipeline completed successfully")

        return AutonomousResult(
            success=True,
            completed_phases=completed_phases,
            final_status=ExecutionStatus.COMPLETED,
        )

    def _get_workflow_index(self, workflow_name: str) -> int:
        """Get index of workflow in chain.

        Args:
            workflow_name: Workflow name

        Returns:
            Workflow index

        Raises:
            ValueError: If workflow not found in chain
        """
        try:
            return self._executor.WORKFLOW_CHAIN.index(workflow_name)
        except ValueError:
            raise ValueError(f"Unknown workflow: {workflow_name}")
