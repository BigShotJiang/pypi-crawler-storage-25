"""Chat engine — knowledge-augmented Q&A using the project's own agents and docs."""

import logging
import os
from pathlib import Path

from core.language_config import LanguageCode, LanguageResolver
from core.llm_client import LLMClientFactory, LLMConfig

logger = logging.getLogger("scribe")

SYSTEM_PROMPT_TEMPLATE = """\
You are the NovelScribe assistant. Answer the user's question about novel writing \
and the NovelScribe ("scribe") CLI system using the reference knowledge below.

Rules:
- If the question is about scribe CLI commands, explain clearly with usage examples.
- If the question is about novel writing craft, use the agent knowledge to give expert advice.
- Be concise but thorough. Use markdown formatting when helpful.
- If the answer is not in the reference knowledge, say so honestly \
and give your best general advice.
- Respond in the same language as the user's question.

=== REFERENCE KNOWLEDGE ===

--- AGENTS ---
{agents_content}

--- DOCUMENTATION ---
{docs_content}
=== END REFERENCE ===
"""

KNOWLEDGE_DOCS = [
    "getting-started/QUICK_START.md",
    "getting-started/USER_GUIDE.md",
]

KNOWLEDGE_DOCS_I18N = {
    "zh-CN": [
        "getting-started/QUICK_START.zh-CN.md",
        "getting-started/USER_GUIDE.zh-CN.md",
    ],
    "zh-TW": [
        "getting-started/QUICK_START.zh-TW.md",
        "getting-started/USER_GUIDE.zh-TW.md",
    ],
}


class ChatEngine:
    """Knowledge-augmented chat engine backed by the project's agents and docs."""

    def __init__(self, provider: str = "", model: str = "", lang: str | None = None):
        self.provider = provider or self._detect_provider()
        self.model = model or self._default_model(self.provider)
        self.lang = lang or self._resolve_lang()
        self._install_dir = Path(__file__).parent.parent
        self._system_prompt: str | None = None

    @staticmethod
    def _detect_provider() -> str:
        provider_keys = [
            ("openai", "OPENAI_API_KEY"),
            ("anthropic", "ANTHROPIC_API_KEY"),
            ("google", "GOOGLE_API_KEY"),
            ("minimax", "MINIMAX_API_KEY"),
            ("zhipu", "ZHIPUAI_API_KEY"),
            ("moonshot", "MOONSHOT_API_KEY"),
        ]
        for provider, env_key in provider_keys:
            if os.getenv(env_key):
                return provider
        for provider, env_key in [
            ("ollama", "OLLAMA_BASE_URL"),
            ("lm_studio", "LM_STUDIO_BASE_URL"),
        ]:
            if os.getenv(env_key):
                return provider
        return ""

    @staticmethod
    def _default_model(provider: str) -> str:
        defaults = {
            "openai": "gpt-4o",
            "anthropic": "claude-sonnet-4-20250514",
            "google": "gemini-2.0-flash",
            "minimax": "MiniMax-Text-01",
            "zhipu": "glm-4-flash",
            "moonshot": "moonshot-v1-8k",
            "ollama": "llama3",
            "lm_studio": "default",
        }
        return defaults.get(provider, "gpt-4o")

    @staticmethod
    def _resolve_lang() -> str:
        try:
            resolver = LanguageResolver()
            config = resolver.get_config()
            code = config.default_language
            if isinstance(code, LanguageCode):
                return code.value
            return str(code) if code else "en"
        except Exception:
            return "en"

    def is_configured(self) -> bool:
        return bool(self.provider)

    @property
    def system_prompt(self) -> str:
        if self._system_prompt is None:
            self._system_prompt = SYSTEM_PROMPT_TEMPLATE.format(
                agents_content=self._load_agents(),
                docs_content=self._load_docs(),
            )
        return self._system_prompt

    def _load_agents(self) -> str:
        lang_dir = self.lang if self.lang != "en" else "en"
        agents_dir = self._install_dir / "agents" / lang_dir
        if not agents_dir.exists():
            agents_dir = self._install_dir / "agents" / "en"
        if not agents_dir.exists():
            return "(No agent knowledge files found)"

        parts = []
        for md_file in sorted(agents_dir.glob("*.md")):
            content = md_file.read_text(encoding="utf-8").strip()
            if content:
                parts.append(f"### {md_file.stem}\n{content}")
        return "\n\n".join(parts) if parts else "(No agent content loaded)"

    def _load_docs(self) -> str:
        doc_files = list(KNOWLEDGE_DOCS)
        i18n = KNOWLEDGE_DOCS_I18N.get(self.lang)
        if i18n:
            doc_files = i18n + doc_files

        parts = []
        docs_dir = self._install_dir / "docs"
        for rel_path in doc_files:
            doc_file = docs_dir / rel_path
            if doc_file.exists():
                content = doc_file.read_text(encoding="utf-8").strip()
                if content:
                    parts.append(f"### {rel_path}\n{content}")
        return "\n\n".join(parts) if parts else "(No documentation loaded)"

    def ask(self, question: str) -> str:
        config = LLMConfig(
            provider=self.provider,
            model=self.model,
            temperature=0.7,
            max_tokens=2048,
        )
        client = LLMClientFactory.create(config)
        response = client.generate(
            system_prompt=self.system_prompt,
            user_prompt=question,
        )
        return response.content

    def ask_with_history(self, messages: list[dict[str, str]]) -> str:
        config = LLMConfig(
            provider=self.provider,
            model=self.model,
            temperature=0.7,
            max_tokens=2048,
        )
        client = LLMClientFactory.create(config)
        full_messages = [{"role": "system", "content": self.system_prompt}] + messages
        response = client.generate_with_history(full_messages)
        return response.content

    def run_interactive(self) -> None:
        print("\n💬 NovelScribe Chat (type /quit or Ctrl+C to exit)")
        print(f"   Provider: {self.provider} | Model: {self.model} | Lang: {self.lang}")
        print()

        history: list[dict[str, str]] = []
        while True:
            try:
                question = input("You: ").strip()
            except (KeyboardInterrupt, EOFError):
                print("\n👋 Bye!")
                break

            if not question:
                continue
            if question.lower() in ("/quit", "/exit", "/q"):
                print("👋 Bye!")
                break

            try:
                history.append({"role": "user", "content": question})
                answer = self.ask_with_history(history)
                history.append({"role": "assistant", "content": answer})
                print(f"\n🤖 {answer}\n")
            except Exception as e:
                logger.error(f"Chat error: {e}")
                print(f"\n❌ Error: {e}\n")
                print("💡 Check your API key with: scribe setup verify\n")
