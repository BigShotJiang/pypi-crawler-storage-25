from __future__ import annotations

from typing import List

from core.memory.knowledge_graph import KnowledgeGraph
from core.memory.models import ConsistencyIssue


class ConsistencyIssueWithResolution(ConsistencyIssue):
    suggestion: str = ""


class ConsistencyChecker:
    def __init__(self, graph: KnowledgeGraph) -> None:
        self._graph = graph

    def check(self) -> List[ConsistencyIssue]:
        return self._graph.check_consistency()

    def check_with_resolutions(self) -> List[ConsistencyIssueWithResolution]:
        issues = self._graph.check_consistency()
        return [self._add_resolution(i) for i in issues]

    def _add_resolution(self, issue: ConsistencyIssue) -> ConsistencyIssueWithResolution:
        suggestion = _SUGGESTIONS.get(issue.issue_type, "Review and resolve manually.")
        data = issue.model_dump()
        data["suggestion"] = suggestion
        return ConsistencyIssueWithResolution(**data)


_SUGGESTIONS = {
    "timeline_conflict": "Review chapters for timeline ordering errors.",
    "character_inconsistency": "Review character wiki page for inconsistencies.",
    "location_error": "Update location wiki with correct details.",
    "relationship_violation": "Check relationship history and update wiki.",
    "plot_contradiction": "Review plot thread for contradictory developments.",
    "unresolved_reference": "Run entity extraction to resolve reference.",
    "unresolved_foreshadowing": "Resolve planted foreshadowing or cut it.",
    "abandoned_plot_thread": "Resolve the plot thread or formally abandon it.",
    "world_rule_violation": "Update world wiki to fix rule contradiction.",
}
