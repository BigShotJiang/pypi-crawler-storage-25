"""Knowledge Graph — JSON-based graph for narrative entities."""

from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional, Tuple

from core.memory.models import (
    ConsistencyIssue,
    EntityType,
    ForeshadowingEvent,
    GraphEdge,
    GraphNode,
    PlotThreadNode,
    RelationType,
)


class KnowledgeGraph:
    """JSON-based knowledge graph for narrative entities."""

    def __init__(self, graph_path: Path) -> None:
        self._path = Path(graph_path)
        self._path.mkdir(parents=True, exist_ok=True)
        self._nodes_file = self._path / "nodes.json"
        self._edges_file = self._path / "edges.json"
        self._index_file = self._path / "index.json"
        self._nodes: Dict[str, Dict[str, Any]] = {}
        self._edges: Dict[str, Dict[str, Any]] = {}
        self._name_index: Dict[str, str] = {}
        self._adjacency: Dict[str, List[str]] = defaultdict(list)
        self._load()

    def _load(self) -> None:
        if self._nodes_file.exists():
            with open(self._nodes_file) as f:
                self._nodes = json.load(f)
        if self._edges_file.exists():
            with open(self._edges_file) as f:
                self._edges = json.load(f)
        if self._index_file.exists():
            with open(self._index_file) as f:
                self._name_index = json.load(f)
        for edge_id, edge_data in self._edges.items():
            src = edge_data.get("source_id", "")
            if src:
                self._adjacency[src].append(edge_id)

    def _save(self) -> None:
        with open(self._nodes_file, "w", encoding="utf-8") as f:
            json.dump(self._nodes, f, indent=2, default=str)
        with open(self._edges_file, "w", encoding="utf-8") as f:
            json.dump(self._edges, f, indent=2, default=str)
        with open(self._index_file, "w", encoding="utf-8") as f:
            json.dump(self._name_index, f, indent=2)

    def add_node(self, node: GraphNode) -> None:
        node_id = node.node_id
        if node_id in self._nodes:
            existing = self._nodes[node_id]
            existing["mention_count"] = existing.get("mention_count", 0) + node.mention_count
            if node.last_seen_chapter:
                current_last = existing.get("last_seen_chapter")
                if current_last is None or node.last_seen_chapter > current_last:
                    existing["last_seen_chapter"] = node.last_seen_chapter
            if node.aliases:
                existing_aliases = set(existing.get("aliases", []))
                existing_aliases.update(node.aliases)
                existing["aliases"] = list(existing_aliases)
            existing["properties"].update(node.properties)
        else:
            self._nodes[node_id] = node.model_dump()
        name_lower = node.name.lower()
        self._name_index[name_lower] = node_id
        for alias in node.aliases:
            self._name_index[alias.lower()] = node_id
        self._save()

    def get_node(self, node_id: str) -> Optional[GraphNode]:
        data = self._nodes.get(node_id)
        if data is None:
            return None
        entity_type = data.get("entity_type", "character")
        if entity_type == "plot_thread":
            return PlotThreadNode(**data)
        return GraphNode(**data)

    def find_by_name(self, name: str) -> Optional[GraphNode]:
        node_id = self._name_index.get(name.lower())
        if node_id is None:
            return None
        return self.get_node(node_id)

    def add_edge(self, edge: GraphEdge) -> None:
        edge_id = edge.edge_id
        self._edges[edge_id] = edge.model_dump()
        self._adjacency[edge.source_id].append(edge_id)
        self._save()

    def get_relationships(
        self,
        node_id: str,
        relation: Optional[RelationType] = None,
        direction: Literal["outgoing", "incoming", "both"] = "both",
    ) -> List[Tuple[GraphEdge, GraphNode]]:
        results = []
        if direction in ("outgoing", "both"):
            for edge_id in self._adjacency.get(node_id, []):
                edge_data = self._edges.get(edge_id)
                if edge_data is None:
                    continue
                if relation and edge_data.get("relation") != relation.value:
                    continue
                target_id = edge_data.get("target_id", "")
                target_node = self.get_node(target_id)
                if target_node:
                    results.append((GraphEdge(**edge_data), target_node))
        if direction in ("incoming", "both"):
            for edge_id, edge_data in self._edges.items():
                if edge_data.get("target_id") != node_id:
                    continue
                if relation and edge_data.get("relation") != relation.value:
                    continue
                if direction == "incoming" and edge_data.get("source_id") == node_id:
                    continue
                source_id = edge_data.get("source_id", "")
                source_node = self.get_node(source_id)
                if source_node:
                    results.append((GraphEdge(**edge_data), source_node))
        return results

    def get_chapter_entities(self, chapter: int) -> List[GraphNode]:
        results = []
        for node_data in self._nodes.values():
            first = node_data.get("first_seen_chapter")
            last = node_data.get("last_seen_chapter")
            if first is not None and last is not None:
                if first <= chapter <= last:
                    node = self.get_node(node_data["node_id"])
                    if node:
                        results.append(node)
        return results

    def get_character_arc(self, character_id: str) -> List[Tuple[int, str]]:
        results = []
        for edge_id, edge_data in self._edges.items():
            if edge_data.get("source_id") != character_id:
                continue
            rel = edge_data.get("relation", "")
            if rel not in ("participates_in", "occurs_in"):
                continue
            ch = edge_data.get("chapter")
            if ch is not None:
                results.append((ch, edge_data.get("properties", {}).get("description", "")))
        return sorted(results, key=lambda x: x[0])

    def get_plot_threads(self, status: Optional[str] = None) -> List[PlotThreadNode]:
        results = []
        for node_data in self._nodes.values():
            if node_data.get("entity_type") != EntityType.PLOT_THREAD.value:
                continue
            thread = PlotThreadNode(**node_data)
            if status is None or thread.status == status:
                results.append(thread)
        return results

    def get_unresolved_foreshadowing(self) -> List[ForeshadowingEvent]:
        results = []
        for node_data in self._nodes.values():
            if node_data.get("entity_type") != EntityType.PLOT_THREAD.value:
                continue
            for fid in node_data.get("foreshadowing_ids", []):
                parts = fid.split(".", 1)
                if len(parts) == 2:
                    fdata = {
                        "event_id": fid,
                        "plant_chapter": 0,
                        "plant_content": "",
                        "status": "planted",
                        "thread_id": node_data["node_id"],
                    }
                    results.append(ForeshadowingEvent(**fdata))
        return results

    def get_timeline(
        self, chapter: Optional[int] = None
    ) -> List[Tuple[GraphNode, List[GraphEdge]]]:
        results = []
        event_nodes = [
            v for v in self._nodes.values() if v.get("entity_type") == EntityType.EVENT.value
        ]
        for node_data in event_nodes:
            node = self.get_node(node_data["node_id"])
            if not node:
                continue
            node_edges = []
            for edge_id, edge_data in self._edges.items():
                if edge_data.get("source_id") == node_data["node_id"]:
                    node_edges.append(GraphEdge(**edge_data))
            if chapter is None or any(e.chapter == chapter for e in node_edges):
                results.append((node, node_edges))
        results.sort(key=lambda x: min((e.chapter for e in x[1]), default=0))
        return results

    def check_consistency(self) -> List[ConsistencyIssue]:
        issues = []
        for edge_id, edge_data in self._edges.items():
            if edge_data.get("relation") == RelationType.VIOLATES.value:
                issues.append(
                    ConsistencyIssue(
                        issue_type="world_rule_violation",
                        severity="warning",
                        description=(
                            f"World rule violation: "
                            f"{edge_data.get('source_id', '')} violates "
                            f"{edge_data.get('target_id', '')}"
                        ),
                        entity_ids=[edge_data.get("source_id", ""), edge_data.get("target_id", "")],
                        evidence=f"Edge {edge_id}",
                    )
                )
        for node_data in self._nodes.values():
            if node_data.get("entity_type") == EntityType.PLOT_THREAD.value:
                if node_data.get("status") == "introduced":
                    last_seen = node_data.get("last_seen_chapter")
                    if last_seen is not None and last_seen < (
                        node_data.get("first_seen_chapter", 0) + 10
                    ):
                        continue
                    issues.append(
                        ConsistencyIssue(
                            issue_type="abandoned_plot_thread",
                            severity="info",
                            description=f"Plot thread {node_data['node_id']} appears abandoned",
                            chapter=last_seen,
                            entity_ids=[node_data["node_id"]],
                        )
                    )
        return issues

    def to_context_string(self, entity_ids: List[str], max_tokens: int = 2000) -> str:
        lines = []
        current_tokens = 0
        for eid in entity_ids:
            node = self.get_node(eid)
            if not node:
                continue
            line = f"## {node.name} ({node.entity_type.value})\n{node.description}\n"
            if isinstance(node, PlotThreadNode):
                line += f"Status: {node.status}, Type: {node.thread_type}\n"
            rels = self.get_relationships(eid, direction="outgoing")
            if rels:
                rel_str = ", ".join(
                    f"{rel.relation.value} {target.name}" for rel, target in rels[:3]
                )
                line += f"Relationships: {rel_str}\n"
            line += "\n"
            estimated_tokens = len(line) // 4
            if current_tokens + estimated_tokens > max_tokens:
                break
            lines.append(line)
            current_tokens += estimated_tokens
        return "".join(lines)
