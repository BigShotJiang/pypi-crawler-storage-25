"""Memory system for NovelScribe."""

from core.memory.conversation_memory import ConversationMemory
from core.memory.entity_extractor import EntityExtractor
from core.memory.generation_learning import GenerationLearning
from core.memory.knowledge_graph import KnowledgeGraph
from core.memory.models import (
    ConsistencyIssue,
    ConversationEvent,
    EntityType,
    ForeshadowingEvent,
    GenerationOutcome,
    GraphEdge,
    GraphNode,
    LearningInsight,
    MemoryConfig,
    PlotThreadNode,
    RelationType,
    WikiIssue,
    WikiPage,
    WikiPageType,
)
from core.memory.novel_wiki import NovelWiki

__all__ = [
    "EntityType",
    "RelationType",
    "WikiPageType",
    "GraphNode",
    "GraphEdge",
    "PlotThreadNode",
    "ForeshadowingEvent",
    "WikiPage",
    "WikiIssue",
    "ConversationEvent",
    "GenerationOutcome",
    "LearningInsight",
    "ConsistencyIssue",
    "MemoryConfig",
    "KnowledgeGraph",
    "NovelWiki",
    "ConversationMemory",
    "GenerationLearning",
    "EntityExtractor",
]
