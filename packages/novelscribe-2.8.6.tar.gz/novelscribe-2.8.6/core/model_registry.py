"""Centralized registry for LLM provider context window limits."""

import logging
from pathlib import Path
from typing import Dict, Optional, Union

from .llm_client import LLMProvider

logger = logging.getLogger(__name__)


class ModelRegistry:
    """Single source of truth for provider context window limits.

    Loads defaults, applies META.yaml overrides, and provides
    limit lookups for BudgetAllocator and other consumers.
    """

    DEFAULT_LIMITS: Dict[str, int] = {
        LLMProvider.OPENAI.value: 128_000,
        LLMProvider.CLAUDE.value: 200_000,
        LLMProvider.GEMINI.value: 1_000_000,
        LLMProvider.OLLAMA.value: 8_192,
        LLMProvider.LM_STUDIO.value: 8_192,
    }

    FALLBACK_LIMIT: int = 8_192

    def __init__(
        self,
        custom_limits: Optional[Dict[str, int]] = None,
        meta_yaml_path: Optional[Path] = None,
    ):
        """Initialize ModelRegistry.

        Args:
            custom_limits: Runtime provider to limit overrides.
            meta_yaml_path: Path to META.yaml for file-based overrides.
        """
        self._limits = dict(self.DEFAULT_LIMITS)

        if meta_yaml_path and meta_yaml_path.exists():
            meta_overrides = self._load_meta_overrides(meta_yaml_path)
            self._limits.update(meta_overrides)

        if custom_limits:
            self._limits.update(custom_limits)

    def get_limit(self, provider: Union[str, LLMProvider]) -> int:
        """Get context window limit for a provider.

        Args:
            provider: Provider name (string or LLMProvider enum).

        Returns:
            Context window token limit.
        """
        key = provider.value if isinstance(provider, LLMProvider) else provider
        return self._limits.get(key, self.FALLBACK_LIMIT)

    def register_override(self, provider: str, limit: int) -> None:
        """Register a provider limit override at runtime.

        Args:
            provider: Provider name string.
            limit: Context window token limit.
        """
        self._limits[provider] = limit

    def _load_meta_overrides(self, meta_path: Path) -> Dict[str, int]:
        """Load provider_limits from META.yaml.

        Args:
            meta_path: Path to META.yaml file.

        Returns:
            Dictionary of provider to limit overrides.
        """
        try:
            import yaml

            with open(meta_path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)
            overrides = data.get("provider_limits", {})
            if isinstance(overrides, dict):
                return {str(k): int(v) for k, v in overrides.items()}
        except Exception:
            logger.debug("Failed to load provider limits from %s", meta_path)
        return {}

    @classmethod
    def from_project_root(cls, project_root: Path) -> "ModelRegistry":
        """Create ModelRegistry from project root, discovering META.yaml.

        Args:
            project_root: Path to project root directory.

        Returns:
            ModelRegistry configured with project overrides.
        """
        meta_path = project_root / "META.yaml"
        return cls(meta_yaml_path=meta_path if meta_path.exists() else None)
