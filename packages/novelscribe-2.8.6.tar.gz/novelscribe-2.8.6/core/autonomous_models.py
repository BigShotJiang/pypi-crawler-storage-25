"""Pydantic models for autonomous workflow execution."""

from typing import Literal, Optional

from pydantic import BaseModel

from core.memory.models import KBContextConfig
from core.progress_tracker import ExecutionStatus
from core.timeout_handler import TimeoutAction


class AutonomousConfig(BaseModel):
    """Autonomous executor configuration.

    Attributes:
        project_name: Name of the project
        start_phase: Starting phase name
        end_phase: Ending phase name
        human_in_loop: Enable human-in-the-loop checkpoints
        max_chapters: Maximum number of chapters to write (None for unlimited)
        provider: LLM provider to use
        checkpoint_interface: Interface to use for checkpoints (cli, file, api, all)
    """

    project_name: str
    start_phase: str = "new_novel"
    end_phase: str = "verification_phase"
    human_in_loop: bool = True
    max_chapters: Optional[int] = None
    provider: str = "openai"
    checkpoint_interface: str = "cli"
    hybrid_mode: bool = False
    checkpoint_timeout: Optional[int] = None
    timeout_action: TimeoutAction = TimeoutAction.PAUSE
    runtime_gate_mode: Literal["compat", "strict"] = "compat"
    kb_context: KBContextConfig = KBContextConfig()
    project_genre: Optional[str] = None
    project_lang: Optional[str] = None


class AutonomousResult(BaseModel):
    """Result of autonomous execution.

    Attributes:
        success: Whether execution completed successfully
        completed_phases: List of completed phase names
        final_status: Final execution status
        error: Optional error message if failed
        checkpoint_id: Optional checkpoint ID if paused
    """

    success: bool
    completed_phases: list[str]
    final_status: ExecutionStatus
    error: Optional[str] = None
    checkpoint_id: Optional[str] = None
