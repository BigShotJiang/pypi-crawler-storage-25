"""
Quality Metrics Calculator for Novel Generation

This module provides comprehensive quality assessment tools for generated content,
including readability analysis, dialogue quality, pacing metrics, consistency checks,
and style analysis.
"""

from core.quality_metric_calculators import QualityMetricsCalculator
from core.quality_metric_types import (
    ContentMetrics,
    DialogueMetrics,
    PacingMetrics,
    QualityMetrics,
    ReadabilityMetrics,
    StyleMetrics,
)

__all__ = [
    "QualityMetrics",
    "ContentMetrics",
    "ReadabilityMetrics",
    "DialogueMetrics",
    "PacingMetrics",
    "StyleMetrics",
    "QualityMetricsCalculator",
]
