"""
Background task manager for workflow execution

This module manages async workflow execution with tracking and cancellation.
"""

import asyncio
import threading
import time
import traceback
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Optional


class TaskStatus(str, Enum):
    """Task execution status"""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class ExecutionState:
    """State of a workflow execution"""

    execution_id: str
    project_name: str
    workflow: str
    status: TaskStatus = TaskStatus.PENDING
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    progress: float = 0.0
    current_step: Optional[str] = None
    error: Optional[str] = None
    result: Optional[Dict[str, Any]] = None
    variables: Dict[str, Any] = field(default_factory=dict)
    logs: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "execution_id": self.execution_id,
            "project_name": self.project_name,
            "workflow": self.workflow,
            "status": self.status.value,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "progress": self.progress,
            "current_step": self.current_step,
            "error": self.error,
            "result": self.result,
            "variables": self.variables,
        }


class TaskManager:
    """
    Manages background workflow execution

    Features:
    - Async workflow execution
    - Execution state tracking
    - Progress updates
    - Cancellation support
    - Thread-safe operations
    """

    def __init__(self, max_workers: int = 5):
        self.executions: Dict[str, ExecutionState] = {}
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        self.lock = threading.Lock()
        self.active_futures: Dict[str, Any] = {}

        # Progress callbacks
        self.progress_callbacks: List[Callable[[str, float, str], None]] = []
        self._ws_loop: Optional[asyncio.AbstractEventLoop] = None
        self._async_executor = ThreadPoolExecutor(max_workers=1)

    def add_progress_callback(self, callback: Callable[[str, float, str], None]) -> None:
        """Add a callback for progress updates"""
        self.progress_callbacks.append(callback)

    def set_event_loop(self, loop: asyncio.AbstractEventLoop) -> None:
        """Set the asyncio event loop for async operations"""
        self._ws_loop = loop

    def _notify_progress(self, execution_id: str, progress: float, step: str) -> None:
        """Notify all progress callbacks"""
        for callback in self.progress_callbacks:
            try:
                callback(execution_id, progress, step)
            except Exception:
                pass
        ws_loop = self._ws_loop
        if ws_loop is not None:
            try:
                state = self.get_execution_status(execution_id)
                if state:
                    ws_loop.call_soon_threadsafe(
                        self._broadcast_ws,
                        state.project_name,
                        state.workflow,
                        progress,
                        step,
                    )
            except Exception:
                pass

    def _broadcast_ws(self, project_name: str, workflow: str, progress: float, step: str) -> None:
        """Broadcast progress via WebSocket (called on event loop thread)"""
        ws_loop = self._ws_loop
        if ws_loop is None:
            return
        try:
            from api.websocket_manager import EventType, RealtimeEvent, get_websocket_manager

            manager = get_websocket_manager()
            event = RealtimeEvent(
                type=EventType.PROGRESS,
                data={
                    "execution_id": "",
                    "project": project_name,
                    "workflow": workflow,
                    "progress": progress,
                    "current_step": step,
                },
                source=project_name,
            )
            asyncio.run_coroutine_threadsafe(
                manager.broadcast_to_project(project_name, event),
                ws_loop,
            )
        except Exception:
            pass

    def execute_workflow(
        self, project_name: str, workflow: str, variables: Dict[str, Any], background: bool = True
    ) -> ExecutionState:
        """
        Execute a workflow

        Args:
            project_name: Target project name
            workflow: Workflow name to execute
            variables: Workflow variables
            background: Whether to run in background or wait for completion

        Returns:
            ExecutionState with execution details
        """
        execution_id = str(uuid.uuid4())

        # Create execution state
        state = ExecutionState(
            execution_id=execution_id,
            project_name=project_name,
            workflow=workflow,
            variables=variables,
        )

        with self.lock:
            self.executions[execution_id] = state

        # Submit to thread pool
        future = self.executor.submit(self._run_workflow, state)
        self.active_futures[execution_id] = future

        return state

    def _run_workflow(self, state: ExecutionState) -> None:
        """
        Run workflow in background thread

        Args:
            state: Execution state to update
        """
        try:
            # Update status
            with self.lock:
                state.status = TaskStatus.RUNNING
                state.started_at = datetime.now()
                state.current_step = "Initializing"
                state.progress = 0.0

            self._notify_progress(state.execution_id, 0.0, "Initializing")

            # Execute workflow based on name
            if state.workflow == "autonomous":
                self._run_autonomous_workflow(state)
            elif state.workflow == "write_chapter":
                self._run_write_chapter_workflow(state)
            elif state.workflow == "generate_outline":
                self._run_outline_workflow(state)
            else:
                self._run_generic_workflow(state)

            # Mark as completed
            with self.lock:
                state.status = TaskStatus.COMPLETED
                state.completed_at = datetime.now()
                state.progress = 100.0
                state.current_step = "Completed"

            self._notify_progress(state.execution_id, 100.0, "Completed")

        except Exception as e:
            # Mark as failed
            with self.lock:
                state.status = TaskStatus.FAILED
                state.completed_at = datetime.now()
                state.error = str(e)
                state.logs.append(f"Error: {str(e)}")
                state.logs.append(traceback.format_exc())

        finally:
            # Clean up future
            if state.execution_id in self.active_futures:
                del self.active_futures[state.execution_id]

    def _run_autonomous_workflow(self, state: ExecutionState) -> None:
        """Run autonomous workflow"""
        state.current_step = "Running autonomous generation"
        state.progress = 10.0

        # Simulate workflow steps (replace with actual orchestrator calls)
        steps = [
            "Discussion phase",
            "Genre analysis",
            "Character development",
            "World building",
            "Outline generation",
            "Chapter writing",
        ]

        for i, step in enumerate(steps):
            state.current_step = step
            progress = 10 + (i * 15)
            state.progress = min(progress, 90.0)
            state.logs.append(f"Executing: {step}")
            self._notify_progress(state.execution_id, state.progress, step)

            # Simulate work
            time.sleep(0.5)

        state.result = {"message": "Autonomous workflow completed", "steps_completed": len(steps)}

    def _run_write_chapter_workflow(self, state: ExecutionState) -> None:
        """Run write chapter workflow"""
        chapter_num = state.variables.get("chapter", 1)
        state.current_step = f"Writing chapter {chapter_num}"
        state.progress = 20.0
        state.logs.append(f"Writing chapter {chapter_num}")

        # Simulate chapter writing
        time.sleep(1)

        state.progress = 100.0
        state.result = {"message": f"Chapter {chapter_num} written", "chapter": chapter_num}

    def _run_outline_workflow(self, state: ExecutionState) -> None:
        """Run outline generation workflow"""
        state.current_step = "Generating outline"
        state.progress = 30.0
        state.logs.append("Generating story outline")

        # Simulate outline generation
        time.sleep(1)

        state.progress = 100.0
        state.result = {"message": "Outline generated", "chapters": 20}

    def _run_generic_workflow(self, state: ExecutionState) -> None:
        """Run generic workflow"""
        state.current_step = f"Running {state.workflow}"
        state.progress = 50.0
        state.logs.append(f"Running workflow: {state.workflow}")

        # Simulate workflow
        time.sleep(0.5)

        state.progress = 100.0
        state.result = {"message": f"Workflow {state.workflow} completed"}

    def cancel_execution(self, execution_id: str) -> bool:
        """
        Cancel a running execution

        Args:
            execution_id: Execution ID to cancel

        Returns:
            True if cancelled successfully
        """
        with self.lock:
            state = self.executions.get(execution_id)
            if not state:
                return False

            if state.status != TaskStatus.RUNNING:
                return False

            state.status = TaskStatus.CANCELLED
            state.completed_at = datetime.now()

        # Cancel future
        future = self.active_futures.get(execution_id)
        if future:
            future.cancel()
            del self.active_futures[execution_id]
            return True

        return False

    def get_execution_status(self, execution_id: str) -> Optional[ExecutionState]:
        """
        Get execution status

        Args:
            execution_id: Execution ID to query

        Returns:
            ExecutionState if found, None otherwise
        """
        with self.lock:
            return self.executions.get(execution_id)

    def get_all_executions(self, project_name: Optional[str] = None) -> List[ExecutionState]:
        """
        Get all executions

        Args:
            project_name: Optional filter by project name

        Returns:
            List of execution states
        """
        with self.lock:
            executions = list(self.executions.values())

            if project_name:
                executions = [e for e in executions if e.project_name == project_name]

            return executions

    def cleanup_old_executions(self, max_age_hours: int = 24) -> int:
        """
        Clean up old completed executions

        Args:
            max_age_hours: Maximum age in hours to keep

        Returns:
            Number of executions cleaned up
        """
        cutoff = datetime.now().timestamp() - (max_age_hours * 3600)

        with self.lock:
            to_remove = []
            for exec_id, state in self.executions.items():
                if state.status in [TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED]:
                    if state.completed_at and state.completed_at.timestamp() < cutoff:
                        to_remove.append(exec_id)

            for exec_id in to_remove:
                del self.executions[exec_id]

            return len(to_remove)


# Global task manager instance
_task_manager: Optional[TaskManager] = None


def get_task_manager() -> TaskManager:
    """Get the global task manager instance"""
    global _task_manager
    if _task_manager is None:
        _task_manager = TaskManager()
    return _task_manager
