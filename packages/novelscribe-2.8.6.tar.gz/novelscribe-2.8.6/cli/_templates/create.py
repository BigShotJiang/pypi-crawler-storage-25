"""CLI commands for template creation and management."""

import logging
import sys
from pathlib import Path

import click
import yaml

logger = logging.getLogger("scribe")


@click.group()
def templates():
    """Manage and browse story templates."""
    pass


def _load_template_loader():
    """Load template loader with error handling."""
    try:
        from core.template_loader import get_template_loader

        return get_template_loader("en")
    except ImportError as e:
        click.echo(f"❌ Failed to import template loader: {e}", err=True)
        return None


def _get_templates_dir() -> Path:
    """Get templates directory path."""
    templates_dir = Path(__file__).parent / "templates"
    return templates_dir


@click.group()
def template_create():
    """Create and manage templates (compatibility alias: `template-create`)."""
    pass


@template_create.command("from-spec")
@click.argument("spec_file", type=click.Path(exists=True))
@click.option(
    "--category", "-c", type=click.Choice(["plot", "character", "scene", "world"]), required=True
)
@click.option("--name", "-n", required=True, help="Template name (filename)")
@click.option("--language", "-l", default="en", type=click.Choice(["en", "zh-CN", "zh-TW"]))
def create_from_spec(spec_file, category, name, language):
    """Create template from specification file."""
    try:
        with open(spec_file, "r", encoding="utf-8") as f:
            spec = yaml.safe_load(f)

        templates_dir = _get_templates_dir()
        lang_dir = templates_dir / language / category
        lang_dir.mkdir(parents=True, exist_ok=True)

        output_file = lang_dir / f"{name}.yaml"

        with open(output_file, "w", encoding="utf-8") as f:
            yaml.dump(spec, f, allow_unicode=True, default_flow_style=False, sort_keys=False)

        click.echo(f"✅ Template created: {output_file}")

    except Exception as e:
        click.echo(f"❌ Error creating template: {e}", err=True)
        sys.exit(1)


@template_create.command("plot")
@click.option("--name", "-n", required=True, help="Template name")
@click.option("--description", "-d", required=True, help="Template description")
@click.option("--beats", "-b", multiple=True, help="Beats in format: position:name:description")
@click.option("--language", "-l", default="en", type=click.Choice(["en", "zh-CN", "zh-TW"]))
def create_plot_template(name, description, beats, language):
    """Create a new plot template."""
    try:
        template_data = {
            "templates": {
                name.lower().replace(" ", "_"): {
                    "name": name,
                    "description": description,
                    "beats": [],
                }
            }
        }

        for beat_spec in beats:
            parts = beat_spec.split(":")
            if len(parts) >= 3:
                position = int(parts[0])
                beat_name = parts[1]
                beat_desc = ":".join(parts[2:])

                template_data["templates"][name.lower().replace(" ", "_")]["beats"].append(
                    {
                        "name": beat_name,
                        "position": position,
                        "percentage": position * (100 // 12) if position > 0 else 0,
                        "description": beat_desc,
                        "questions": [],
                    }
                )

        templates_dir = _get_templates_dir()
        lang_dir = templates_dir / language / "plot"
        lang_dir.mkdir(parents=True, exist_ok=True)

        output_file = lang_dir / f"{name.lower().replace(' ', '_')}.yaml"

        with open(output_file, "w", encoding="utf-8") as f:
            yaml.dump(template_data, f, allow_unicode=True, default_flow_style=False)

        click.echo(f"✅ Plot template created: {output_file}")
        click.echo("\nEdit the file to add questions and refine the template.")

    except Exception as e:
        click.echo(f"❌ Error creating template: {e}", err=True)
        sys.exit(1)


@template_create.command("character")
@click.option("--name", "-n", required=True, help="Character type name")
@click.option("--description", "-d", required=True, help="Character type description")
@click.option("--elements", "-e", multiple=True, help="Elements in format: name:description")
@click.option("--language", "-l", default="en", type=click.Choice(["en", "zh-CN", "zh-TW"]))
def create_character_template(name, description, elements, language):
    """Create a new character archetype template."""
    try:
        template_data = {
            "character_types": {
                name.lower().replace(" ", "_"): {
                    "name": name,
                    "description": description,
                    "elements": [],
                }
            }
        }

        for elem_spec in elements:
            parts = elem_spec.split(":")
            if len(parts) >= 2:
                elem_name = parts[0]
                elem_desc = ":".join(parts[1:])

                template_data["character_types"][name.lower().replace(" ", "_")]["elements"].append(
                    {"name": elem_name, "description": elem_desc, "questions": []}
                )

        templates_dir = _get_templates_dir()
        lang_dir = templates_dir / language / "character"
        lang_dir.mkdir(parents=True, exist_ok=True)

        output_file = lang_dir / "archetypes.yaml"

        existing_data = {}
        if output_file.exists():
            with open(output_file, "r", encoding="utf-8") as f:
                existing_data = yaml.safe_load(f) or {}

        existing_data.update(template_data)

        with open(output_file, "w", encoding="utf-8") as f:
            yaml.dump(existing_data, f, allow_unicode=True, default_flow_style=False)

        click.echo(f"✅ Character template added to: {output_file}")

    except Exception as e:
        click.echo(f"❌ Error creating template: {e}", err=True)
        sys.exit(1)


@template_create.command("scene")
@click.option("--name", "-n", required=True, help="Scene type name")
@click.option("--description", "-d", required=True, help="Scene type description")
@click.option(
    "--elements", "-e", multiple=True, help="Structure elements in format: name:description"
)
@click.option("--language", "-l", default="en", type=click.Choice(["en", "zh-CN", "zh-TW"]))
def create_scene_template(name, description, elements, language):
    """Create a new scene type template."""
    try:
        template_data = {
            "scene_types": {
                name.lower().replace(" ", "_"): {
                    "name": name,
                    "description": description,
                    "structure": [],
                }
            }
        }

        for elem_spec in elements:
            parts = elem_spec.split(":")
            if len(parts) >= 2:
                elem_name = parts[0]
                elem_desc = ":".join(parts[1:])

                template_data["scene_types"][name.lower().replace(" ", "_")]["structure"].append(
                    {"name": elem_name, "description": elem_desc}
                )

        templates_dir = _get_templates_dir()
        lang_dir = templates_dir / language / "scene"
        lang_dir.mkdir(parents=True, exist_ok=True)

        output_file = lang_dir / "structure.yaml"

        existing_data = {}
        if output_file.exists():
            with open(output_file, "r", encoding="utf-8") as f:
                existing_data = yaml.safe_load(f) or {}

        existing_data.update(template_data)

        with open(output_file, "w", encoding="utf-8") as f:
            yaml.dump(existing_data, f, allow_unicode=True, default_flow_style=False)

        click.echo(f"✅ Scene template added to: {output_file}")

    except Exception as e:
        click.echo(f"❌ Error creating template: {e}", err=True)
        sys.exit(1)


@template_create.command("clone")
@click.argument("source_template")
@click.argument("new_name")
@click.option(
    "--category", "-c", type=click.Choice(["plot", "character", "scene", "world"]), required=True
)
@click.option("--source-language", "-sl", default="en", help="Source template language")
@click.option("--target-language", "-tl", help="Target language (default: same as source)")
def clone_template(source_template, new_name, category, source_language, target_language):
    """Clone an existing template."""
    try:
        loader = _load_template_loader()
        if not loader:
            return

        target_language = target_language or source_language

        templates_dir = _get_templates_dir()
        source_file = templates_dir / source_language / category / f"{source_template}.yaml"

        if not source_file.exists():
            click.echo(f"❌ Source template not found: {source_file}", err=True)
            sys.exit(1)

        with open(source_file, "r", encoding="utf-8") as f:
            template_data = yaml.safe_load(f)

        target_file = templates_dir / target_language / category / f"{new_name}.yaml"
        target_file.parent.mkdir(parents=True, exist_ok=True)

        with open(target_file, "w", encoding="utf-8") as f:
            yaml.dump(template_data, f, allow_unicode=True, default_flow_style=False)

        click.echo(f"✅ Template cloned: {source_template} → {new_name}")
        click.echo(f"   Location: {target_file}")

    except Exception as e:
        click.echo(f"❌ Error cloning template: {e}", err=True)
        sys.exit(1)


@template_create.command("translate")
@click.argument("template_name")
@click.option(
    "--category", "-c", type=click.Choice(["plot", "character", "scene", "world"]), required=True
)
@click.option("--source-language", "-sl", default="en", help="Source template language")
@click.option(
    "--target-language",
    "-tl",
    required=True,
    type=click.Choice(["en", "zh-CN", "zh-TW"]),
    help="Target language",
)
def translate_template(template_name, category, source_language, target_language):
    """Create translated version of a template."""
    try:
        templates_dir = _get_templates_dir()
        source_file = templates_dir / source_language / category / f"{template_name}.yaml"

        if not source_file.exists():
            click.echo(f"❌ Source template not found: {source_file}", err=True)
            return

        with open(source_file, "r", encoding="utf-8") as f:
            template_data = yaml.safe_load(f)

        target_file = templates_dir / target_language / category / f"{template_name}.yaml"
        target_file.parent.mkdir(parents=True, exist_ok=True)

        click.echo(f"\n📝 Translating template: {template_name}")
        click.echo(f"   From: {source_language}")
        click.echo(f"   To: {target_language}")
        click.echo("\n⚠️  Manual translation required!")
        click.echo("   Please edit the file and translate the content:")
        click.echo(f"   {target_file}")

        with open(target_file, "w", encoding="utf-8") as f:
            yaml.dump(template_data, f, allow_unicode=True, default_flow_style=False)

        click.echo("\n✅ Template file created. Please translate the content.")

    except Exception as e:
        click.echo(f"❌ Error: {e}", err=True)
        sys.exit(1)


@template_create.command("validate")
@click.argument("template_file", type=click.Path(exists=True))
def validate_template(template_file):
    """Validate a template file."""
    try:
        with open(template_file, "r", encoding="utf-8") as f:
            template_data = yaml.safe_load(f)

        issues = []

        if not template_data:
            issues.append("❌ Template is empty")
        elif not any(
            key in template_data for key in ["templates", "character_types", "scene_types"]
        ):
            issues.append("❌ Missing root key (templates, character_types, or scene_types)")

        if "templates" in template_data:
            for key, template in template_data["templates"].items():
                if "name" not in template:
                    issues.append(f"⚠️  Template '{key}' missing 'name' field")
                if "description" not in template:
                    issues.append(f"⚠️  Template '{key}' missing 'description' field")
                if "beats" in template:
                    positions = [b.get("position", 0) for b in template["beats"]]
                    if positions != sorted(positions):
                        issues.append(f"⚠️  Template '{key}' has beats in wrong order")

        if issues:
            click.echo("⚠️  Validation Issues:")
            for issue in issues:
                click.echo(f"   {issue}")
        else:
            click.echo("✅ Template is valid!")

        click.echo(f"\n📄 File: {template_file}")

    except yaml.YAMLError as e:
        click.echo(f"❌ YAML Syntax Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"❌ Error validating template: {e}", err=True)
        sys.exit(1)


@template_create.command("list-templates")
@click.option("--category", "-c", type=click.Choice(["plot", "character", "scene", "world"]))
def list_all_templates(category):
    """List all templates by category."""
    try:
        templates_dir = _get_templates_dir()

        categories = [category] if category else ["plot", "character", "scene", "world"]

        for cat in categories:
            click.echo(f"\n🎯 {cat.upper()}")
            click.echo("=" * 40)

            for lang in ["en", "zh-CN", "zh-TW"]:
                lang_dir = templates_dir / lang / cat
                if lang_dir.exists():
                    for template_file in lang_dir.glob("*.yaml"):
                        click.echo(f"  [{lang}] {template_file.stem}")

    except Exception as e:
        click.echo(f"❌ Error: {e}", err=True)
        sys.exit(1)


@template_create.command("info")
@click.argument("template_name")
@click.option(
    "--category", "-c", type=click.Choice(["plot", "character", "scene", "world"]), required=True
)
def template_info(template_name, category):
    """Show detailed information about a template."""
    try:
        loader = _load_template_loader()
        if not loader:
            return

        if category == "plot":
            data = loader.load_plot_template(template_name)
        elif category == "character":
            data = loader.load_character_template(template_name)
        elif category == "scene":
            data = loader.load_scene_template(template_name)
        else:
            click.echo(f"❌ Unknown category: {category}", err=True)
            return

        if not data:
            click.echo(f"❌ Template not found: {template_name}", err=True)
            return

        click.echo(f"\n📋 Template: {template_name}")
        click.echo(f"   Category: {category}")
        click.echo("   Language: en")
        click.echo("\n📄 Raw YAML:")
        click.echo(yaml.dump(data, allow_unicode=True, default_flow_style=False))

    except Exception as e:
        click.echo(f"❌ Error: {e}", err=True)
        sys.exit(1)


@template_create.command("help")
def create_help():
    """Show help for template creation."""
    click.echo("""
📚 Template Creation Guide
=========================

CREATE NEW TEMPLATES:

1. Create Plot Template:
   scribe template-create plot -n "My Structure" -d "Description" \\
     -b "0:Hook:Description" -b "1:Beat1:Description"

2. Create Character Template:
   scribe template-create character -n "My Archetype" \\
     -d "Description" -e "Want:Description" -e "Need:Description"

3. Create Scene Template:
   scribe template-create scene -n "My Scene" -d "Description" \\
     -e "Element:Description"

4. Clone Existing Template:
   scribe template-create clone heros_journey my_journey -c plot

5. Create from YAML Spec:
   scribe template-create from-spec spec.yaml -c plot -n my_template

MANAGE TEMPLATES:

6. Validate Template:
   scribe template-create validate template.yaml

7. List All Templates:
   scribe template-create list-templates
   scribe template-create list-templates -c plot

8. Show Template Info:
   scribe template-create info heros_journey -c plot

TRANSLATE TEMPLATES:

9. Translate Template:
   scribe template-create translate heros_journey -c plot \\
     --source-language en --target-language zh-CN

TIPS:
- Templates are saved in: templates/<language>/<category>/
- Template files use .yaml extension
- Use existing templates as examples
- Validate after creating
- Add questions to guide usage
""")


def register_commands(cli_group):
    """Register template creation commands."""
    cli_group.add_command(template_create)
    cli_group.add_command(create_from_spec)
    cli_group.add_command(create_plot_template)
    cli_group.add_command(create_character_template)
    cli_group.add_command(create_scene_template)
    cli_group.add_command(clone_template)
    cli_group.add_command(translate_template)
    cli_group.add_command(validate_template)
    cli_group.add_command(list_all_templates)
    cli_group.add_command(template_info)
    cli_group.add_command(create_help)
