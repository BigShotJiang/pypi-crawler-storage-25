"""CLI commands for global template KB query and inspection."""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, Optional

import click

logger = logging.getLogger("scribe")

SUPPORTED_KINDS = ["scene_blueprint", "character_blueprint", "narrative_trope", "plot_structure"]


def _kind_callback(
    ctx: click.Context, param: click.Parameter, value: Optional[str]
) -> Optional[str]:
    if value is not None and value not in SUPPORTED_KINDS:
        raise click.BadParameter(f"Invalid kind '{value}'. Supported: {', '.join(SUPPORTED_KINDS)}")
    return value


@click.group("kb")
def kb():
    """Global template knowledge base: search, inspect, and use shipped templates."""
    pass


@kb.command("search")
@click.argument("query", nargs=-1, required=True)
@click.option(
    "--kind",
    "-k",
    "kind",
    type=click.Choice(SUPPORTED_KINDS, case_sensitive=False),
    default=None,
    help="Filter by template kind",
    callback=_kind_callback,
)
@click.option(
    "--lang",
    "-l",
    "lang",
    default="en",
    help="Preferred language (en, zh)",
)
@click.option(
    "--top-k",
    "-n",
    "top_k",
    type=int,
    default=3,
    help="Maximum number of results",
)
@click.option(
    "--format",
    "-f",
    "fmt",
    type=click.Choice(["text", "json"]),
    default="text",
    help="Output format",
)
def kb_search(
    query: tuple[str, ...],
    kind: Optional[str],
    lang: str,
    top_k: int,
    fmt: str,
) -> None:
    """Search the global template KB by keyword or phrase."""
    if top_k < 1 or top_k > 20:
        raise click.BadParameter("--top-k must be between 1 and 20")

    query_text = " ".join(query)
    from core.template_kb import GlobalTemplateWikiStore, TemplateWikiRetriever

    store = GlobalTemplateWikiStore.get_instance()
    retriever = TemplateWikiRetriever(store=store, top_k=top_k)

    hits = retriever.retrieve(query=query_text, kind=kind, lang=lang, top_k=top_k)

    if fmt == "json":
        output: Dict[str, Any] = {
            "query": query_text,
            "kind": kind,
            "lang": lang,
            "total": len(hits),
            "hits": [
                {
                    "page_id": h.page_id,
                    "template_id": h.template_id,
                    "kind": h.template_kind,
                    "title": h.title,
                    "lang": h.lang,
                    "score": h.score,
                    "excerpt": h.excerpt,
                }
                for h in hits
            ],
        }
        click.echo(json.dumps(output, indent=2, ensure_ascii=False))
        return

    kind_label = kind or "all kinds"
    click.echo(f'\n🔍 Query: "{query_text}" | kind: {kind_label} | lang: {lang}\n')

    if not hits:
        click.echo("  No results found. Try a different query or broader kind.\n")
        return

    for i, hit in enumerate(hits, 1):
        click.echo(f"{i}. {hit.title}")
        click.echo(f"   kind={hit.template_kind} | lang={hit.lang} | score={hit.score}")
        click.echo(f"   {hit.excerpt[:120]}")
        click.echo(f"   page_id: {hit.page_id}")
        click.echo()


@kb.command("show")
@click.argument("page_id")
@click.option(
    "--format",
    "-f",
    "fmt",
    type=click.Choice(["text", "json"]),
    default="text",
    help="Output format",
)
def kb_show(page_id: str, fmt: str) -> None:
    """Show a single template KB page by its page_id."""
    from core.template_kb import GlobalTemplateWikiStore, TemplateWikiRetriever

    store = GlobalTemplateWikiStore.get_instance()
    retriever = TemplateWikiRetriever(store=store)

    hit = retriever.retrieve_by_page_id(page_id)

    if hit is None:
        click.echo(f"❌ Page not found: {page_id}", err=True)
        raise SystemExit(1)

    if fmt == "json":
        output = {
            "page_id": hit.page_id,
            "template_id": hit.template_id,
            "kind": hit.template_kind,
            "title": hit.title,
            "lang": hit.lang,
            "score": hit.score,
            "excerpt": hit.excerpt,
        }
        click.echo(json.dumps(output, indent=2, ensure_ascii=False))
        return

    click.echo(f"\n{'=' * 60}")
    click.echo(f"  {hit.title}")
    click.echo(f"{'=' * 60}")
    click.echo(f"  kind   : {hit.template_kind}")
    click.echo(f"  lang   : {hit.lang}")
    click.echo(f"  page_id: {hit.page_id}")
    click.echo(f"  score  : {hit.score}")
    click.echo()
    click.echo(hit.excerpt)
    click.echo()


@kb.command("stats")
@click.option(
    "--format",
    "-f",
    "fmt",
    type=click.Choice(["text", "json"]),
    default="text",
    help="Output format",
)
def kb_stats(fmt: str) -> None:
    """Show statistics about the shipped template KB."""
    from core.template_kb import GlobalTemplateWikiStore, TemplateWikiRetriever

    store = GlobalTemplateWikiStore.get_instance()
    retriever = TemplateWikiRetriever(store=store)
    stats = retriever.get_stats()

    if fmt == "json":
        click.echo(json.dumps(stats, indent=2, ensure_ascii=False))
        return

    total = stats["total"]
    click.echo(f"\n📦 Global Template KB — {total} pages shipped")
    click.echo(f"{'=' * 50}")
    click.echo("By kind:")
    for kind, count in sorted(stats["by_kind"].items()):
        click.echo(f"  • {kind}: {count}")
    click.echo("By language:")
    for lang, count in sorted(stats["by_lang"].items()):
        click.echo(f"  • {lang}: {count}")
    click.echo()
