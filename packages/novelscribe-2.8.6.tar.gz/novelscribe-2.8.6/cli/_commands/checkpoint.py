"""Checkpoint CLI commands for human-in-the-loop management."""

import json
import sys
from pathlib import Path

import click

from core.checkpoint_file_handler import CheckpointFileHandler
from core.checkpoint_proposal import CheckpointDecision, DecisionType
from core.checkpoint_scheduler import create_checkpoint_schedule
from core.confidence_calculator import ConfidenceCalculator
from core.interactive_qa_handler import InteractiveQAHandler
from core.storage import Storage


@click.group()
def checkpoint() -> None:
    """Checkpoint management commands."""
    pass


def get_handler(project_name: str, project_dir: str = ".novels") -> CheckpointFileHandler:
    """Get checkpoint handler for project."""
    storage = Storage()
    existing = storage.list_projects()
    if project_name not in existing:
        click.echo(f"Error: Project '{project_name}' not found", err=True)
        sys.exit(1)

    project_path = Path(project_dir) / project_name
    if not project_path.exists():
        click.echo(f"Error: Project path '{project_path}' not found", err=True)
        sys.exit(1)

    return CheckpointFileHandler(project_path, create_checkpoint_schedule())


@checkpoint.command("list")
@click.argument("project_name")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
def list_checkpoints(project_name: str, project_dir: str) -> None:
    """List checkpoint status for project."""
    handler = get_handler(project_name, project_dir)

    has_pending = handler.has_pending_proposal()
    proposal = handler.load_proposal()
    decision = handler.load_decision()

    click.echo(f"\n=== Checkpoint Status for '{project_name}' ===\n")

    if has_pending and proposal:
        click.echo(f"✓ Pending checkpoint: {proposal.checkpoint_id}")
        click.echo(f"  Phase: {proposal.phase}")
        click.echo(f"  Title: {proposal.plan.title}")
        click.echo(f"  Confidence: {proposal.confidence:.0%}")
        click.echo(f"  Reasoning: {proposal.reasoning}")

        if proposal.alternatives:
            click.echo("\n  Alternatives:")
            for alt in proposal.alternatives:
                click.echo(f"    [{alt.option_id}] {alt.plan.title} ({alt.confidence:.0%})")
                click.echo(f"        {alt.tradeoff_explanation}")

        if decision:
            click.echo(f"\n  Decision: {decision.decision_type.value}")
            click.echo(f"  Decided at: {decision.timestamp.isoformat()}")
        else:
            click.echo("\n  Decision: PENDING")
    else:
        click.echo("No pending checkpoints")

    history = handler.get_history()
    if history:
        click.echo(f"\n=== Decision History ({len(history)} decisions) ===")
        for h in history[-5:]:
            click.echo(f"  [{h['checkpoint_id']}] {h['decision_type']} at {h['timestamp']}")


@checkpoint.command("show")
@click.argument("project_name")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.option(
    "--format", "output_format", type=click.Choice(["text", "json", "yaml"]), default="text"
)
def show_checkpoint(project_name: str, project_dir: str, output_format: str) -> None:
    """Show current checkpoint proposal."""
    handler = get_handler(project_name, project_dir)
    proposal = handler.load_proposal()

    if not proposal:
        click.echo("No pending checkpoint proposal found")
        return

    if output_format == "json":
        data = {
            "checkpoint_id": proposal.checkpoint_id,
            "phase": proposal.phase,
            "plan": {
                "title": proposal.plan.title,
                "pov": proposal.plan.pov,
                "word_estimate": proposal.plan.word_estimate,
                "pacing": proposal.plan.pacing,
                "scenes": proposal.plan.scenes,
            },
            "confidence": f"{proposal.confidence:.0%}",
            "reasoning": proposal.reasoning,
            "reasoning_trace": proposal.reasoning_trace,
            "alternatives": [
                {
                    "id": alt.option_id,
                    "title": alt.plan.title,
                    "confidence": f"{alt.confidence:.0%}",
                    "tradeoff": alt.tradeoff_explanation,
                }
                for alt in proposal.alternatives
            ],
        }
        click.echo(json.dumps(data, indent=2))

    elif output_format == "yaml":
        handler.export_to_yaml(proposal, Path("/dev/stdout"))

    else:
        click.echo(f"\n=== Checkpoint Proposal: {proposal.checkpoint_id} ===\n")
        click.echo(f"Phase: {proposal.phase}")
        click.echo(f"Title: {proposal.plan.title}")
        click.echo(f"Confidence: {proposal.confidence:.0%}")
        click.echo(f"Reasoning: {proposal.reasoning}")

        if proposal.plan.pov:
            click.echo(f"POV: {proposal.plan.pov}")
        if proposal.plan.word_estimate:
            click.echo(f"Word Estimate: {proposal.plan.word_estimate:,}")
        if proposal.plan.pacing:
            click.echo(f"Pacing: {proposal.plan.pacing}")

        if proposal.reasoning_trace:
            click.echo("\nReasoning Trace:")
            for trace in proposal.reasoning_trace:
                click.echo(f"  → {trace}")

        if proposal.confidence_breakdown:
            bd = proposal.confidence_breakdown
            click.echo("\nConfidence Breakdown:")
            click.echo(f"  • Coherence:     {bd.coherence:.0%} (weight: 30%)")
            click.echo(f"  • Character:     {bd.character:.0%} (weight: 25%)")
            click.echo(f"  • Pacing:        {bd.pacing:.0%} (weight: 20%)")
            click.echo(f"  • Originality:   {bd.originality:.0%} (weight: 15%)")
            click.echo(f"  • Completeness:  {bd.completeness:.0%} (weight: 10%)")
            click.echo(f"  • Total:         {bd.total:.0%}")

            calculator = ConfidenceCalculator()
            details = calculator.get_factor_details(proposal.plan, proposal.phase)
            if click.confirm("\nShow detailed factor explanations?", default=False):
                click.echo()
                for d in details:
                    click.echo(f"  [{d.name}] {d.score:.0%} × {d.weight:.0%} — {d.explanation}")

        if proposal.alternatives:
            click.echo("\n=== Alternatives ===")
            for alt in proposal.alternatives:
                click.echo(f"\n  [{alt.option_id}] {alt.plan.title}")
                click.echo(f"      Confidence: {alt.confidence:.0%}")
                click.echo(f"      Tradeoff: {alt.tradeoff_explanation}")
                if alt.rejection_reasons:
                    click.echo("      Rejection reasons:")
                    for reason in alt.rejection_reasons:
                        click.echo(f"        - {reason}")


@checkpoint.command("approve")
@click.argument("project_name")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
def approve_checkpoint(project_name: str, project_dir: str, yes: bool) -> None:
    """Approve current checkpoint proposal."""
    handler = get_handler(project_name, project_dir)
    proposal = handler.load_proposal()

    if not proposal:
        click.echo("No pending checkpoint proposal found")
        return

    if not yes:
        click.echo(f"Approve checkpoint '{proposal.checkpoint_id}' ({proposal.plan.title})?")
        if not click.confirm("Proceed?"):
            click.echo("Cancelled")
            return

    decision = CheckpointDecision(
        decision_type=DecisionType.APPROVE,
        checkpoint_id=proposal.checkpoint_id,
    )

    handler.save_decision(decision)
    click.echo(f"✓ Approved checkpoint '{proposal.checkpoint_id}'")


@checkpoint.command("modify")
@click.argument("project_name")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.option("--changes", "-c", multiple=True, help="Changes as key=value pairs")
@click.option("--file", "-f", type=click.Path(exists=True), help="JSON file with modifications")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
def modify_checkpoint(
    project_name: str,
    project_dir: str,
    changes: tuple[str, ...],
    file: str | None,
    yes: bool,
) -> None:
    """Modify checkpoint proposal with changes."""
    handler = get_handler(project_name, project_dir)
    proposal = handler.load_proposal()

    if not proposal:
        click.echo("No pending checkpoint proposal found")
        return

    modified_content = {}

    if file:
        with open(file) as f:
            modified_content = json.load(f)

    if changes:
        for change in changes:
            if "=" in change:
                key, value = change.split("=", 1)
                modified_content[key.strip()] = value.strip()

    if not modified_content:
        click.echo("No modifications provided. Use --changes or --file")
        return

    if not yes:
        click.echo(f"Apply modifications to checkpoint '{proposal.checkpoint_id}'?")
        click.echo(f"Changes: {json.dumps(modified_content, indent=2)}")
        if not click.confirm("Proceed?"):
            click.echo("Cancelled")
            return

    decision = CheckpointDecision(
        decision_type=DecisionType.MODIFY,
        checkpoint_id=proposal.checkpoint_id,
        modified_content=modified_content,
    )

    handler.save_decision(decision)
    click.echo(f"✓ Modified checkpoint '{proposal.checkpoint_id}' with changes")


@checkpoint.command("reject")
@click.argument("project_name")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.option("--reason", "-r", help="Reason for rejection")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
def reject_checkpoint(project_name: str, project_dir: str, reason: str, yes: bool) -> None:
    """Reject checkpoint proposal."""
    handler = get_handler(project_name, project_dir)
    proposal = handler.load_proposal()

    if not proposal:
        click.echo("No pending checkpoint proposal found")
        return

    if not yes:
        click.echo(f"Reject checkpoint '{proposal.checkpoint_id}' ({proposal.plan.title})?")
        if reason:
            click.echo(f"Reason: {reason}")
        if not click.confirm("Proceed?"):
            click.echo("Cancelled")
            return

    decision = CheckpointDecision(
        decision_type=DecisionType.REJECT,
        checkpoint_id=proposal.checkpoint_id,
        guidance_text=reason,
    )

    handler.save_decision(decision)
    click.echo(f"✓ Rejected checkpoint '{proposal.checkpoint_id}'")


@checkpoint.command("guidance")
@click.argument("project_name")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.option("--text", "-t", required=True, help="Guidance text")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
def guidance_checkpoint(
    project_name: str,
    project_dir: str,
    text: str,
    yes: bool,
) -> None:
    """Provide guidance for checkpoint proposal."""
    handler = get_handler(project_name, project_dir)
    proposal = handler.load_proposal()

    if not proposal:
        click.echo("No pending checkpoint proposal found")
        return

    if not yes:
        click.echo(f"Provide guidance for checkpoint '{proposal.checkpoint_id}'?")
        click.echo(f"Guidance: {text}")
        if not click.confirm("Proceed?"):
            click.echo("Cancelled")
            return

    decision = CheckpointDecision(
        decision_type=DecisionType.GUIDANCE,
        checkpoint_id=proposal.checkpoint_id,
        guidance_text=text,
    )

    handler.save_decision(decision)
    click.echo(f"✓ Guidance submitted for checkpoint '{proposal.checkpoint_id}'")


@checkpoint.command("history")
@click.argument("project_name")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.option("--checkpoint-id", help="Filter by checkpoint ID")
def checkpoint_history(project_name: str, project_dir: str, checkpoint_id: str | None) -> None:
    """Show checkpoint decision history."""
    handler = get_handler(project_name, project_dir)

    history = handler.get_history(checkpoint_id)

    if not history:
        click.echo("No decision history found")
        return

    click.echo("\n=== Decision History ===\n")
    for i, h in enumerate(history, 1):
        click.echo(f"{i}. [{h['checkpoint_id']}] {h['decision_type']}")
        click.echo(f"   Timestamp: {h['timestamp']}")
        if h.get("guidance_text"):
            click.echo(f"   Guidance: {h['guidance_text']}")
        if h.get("modified_content"):
            click.echo(f"   Modifications: {json.dumps(h['modified_content'])}")
        if h.get("selected_alternative"):
            click.echo(f"   Selected: {h['selected_alternative']}")
        click.echo()


@checkpoint.command("clear")
@click.argument("project_name")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
def clear_checkpoint(project_name: str, project_dir: str, yes: bool) -> None:
    """Clear pending checkpoint proposal and decision."""
    handler = get_handler(project_name, project_dir)

    if not yes:
        if not click.confirm(f"Clear checkpoint state for '{project_name}'?"):
            click.echo("Cancelled")
            return

    handler.clear_proposal()
    handler.clear_decision()
    click.echo(f"✓ Cleared checkpoint state for '{project_name}'")


@checkpoint.command("explain")
@click.argument("project_name")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.option("--question", "-q", help="Question about the checkpoint proposal")
def explain_checkpoint(project_name: str, project_dir: str, question: str) -> None:
    """Ask a question about the current checkpoint proposal."""
    handler = get_handler(project_name, project_dir)
    proposal = handler.load_proposal()

    if not proposal:
        click.echo("No pending checkpoint proposal found")
        return

    qa_handler = InteractiveQAHandler()

    if question:
        answer = qa_handler.answer_question(question, proposal)
        click.echo(f"\nQ: {question}")
        click.echo(f"A: {answer}")
    else:
        click.echo("\nInteractive Q&A (type 'quit' to exit)")
        click.echo("Ask about: why this plan, alternatives, confidence, pacing, characters, etc.\n")
        while True:
            q = click.prompt("You", default="", show_default=False)
            if not q or q.lower() in ("quit", "exit", "q"):
                break
            answer = qa_handler.answer_question(q, proposal)
            click.echo(f"\nAI: {answer}\n")


@checkpoint.command("compare")
@click.argument("project_name")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
def compare_alternatives(project_name: str, project_dir: str) -> None:
    """Compare all alternatives for the current checkpoint."""
    handler = get_handler(project_name, project_dir)
    proposal = handler.load_proposal()

    if not proposal:
        click.echo("No pending checkpoint proposal found")
        return

    click.echo(f"\n=== Alternative Comparison: {proposal.checkpoint_id} ===\n")

    click.echo(f"[Primary] {proposal.plan.title}")
    click.echo(f"  Confidence: {proposal.confidence:.0%}")
    click.echo(f"  Reasoning: {proposal.reasoning}")
    click.echo()

    if not proposal.alternatives:
        click.echo("No alternatives available for this checkpoint.")
        return

    for alt in proposal.alternatives:
        click.echo(f"[{alt.option_id}] {alt.plan.title}")
        click.echo(f"  Confidence: {alt.confidence:.0%}")
        click.echo(f"  Tradeoff: {alt.tradeoff_explanation}")
        if alt.rejection_reasons:
            click.echo("  Not chosen because:")
            for reason in alt.rejection_reasons:
                click.echo(f"    - {reason}")
        click.echo()

    best = "Primary"
    best_score = proposal.confidence
    for alt in proposal.alternatives:
        if alt.confidence > best_score:
            best_score = alt.confidence
            best = alt.option_id
    click.echo(f"Recommendation: {best} (highest confidence: {best_score:.0%})")

    calculator = ConfidenceCalculator()
    details = calculator.get_factor_details(proposal.plan, proposal.phase)
    click.echo("\nConfidence Factors:")
    for d in details:
        bar = "█" * int(d.score * 20)
        click.echo(f"  {d.name:14s} {bar:20s} {d.score:.0%}")
