"""Execution commands for agents and workflows."""

import logging
import sys
from pathlib import Path
from typing import Any

import click

from cli._helpers.error_handling import handle_cli_exception
from core.agent_registry import AgentRegistry
from core.git_manager import create_git_manager
from core.llm_client import LLMConfig
from core.orchestrator import create_orchestrator
from core.orchestrator_agent_integration import AgentSystemIntegration
from core.storage import StorageConfig, StorageFactory
from core.workflow_loader import WorkflowLoader


def infer_type(value: str) -> Any:
    """Infer type from string value.

    Args:
        value: String value to infer type from

    Returns:
        Value with inferred type (bool, int, float, or str)
    """
    if value.lower() == "true":
        return True
    if value.lower() == "false":
        return False
    if value.isdigit():
        return int(value)
    try:
        return float(value)
    except ValueError:
        return value


def set_nested_dict(d: dict, path: str, value: Any) -> None:
    """Set value in nested dictionary using dot notation.

    Args:
        d: Dictionary to update
        path: Dot-separated path (e.g., 'project.meta.genre')
        value: Value to set
    """
    keys = path.split(".")
    current = d

    for key in keys[:-1]:
        if key not in current:
            current[key] = {}
        current = current[key]

    current[keys[-1]] = value


def parse_vars(var_list: list[str]) -> dict[str, Any]:
    """Parse KEY=VALUE pairs with type inference and dot notation.

    Args:
        var_list: List of KEY=VALUE strings

    Returns:
        Dictionary with parsed values

    Raises:
        click.BadParameter: If format is invalid
    """
    result = {}

    for var in var_list:
        if "=" not in var:
            raise click.BadParameter(f"Invalid format: {var}. Use KEY=VALUE")

        key, value = var.split("=", 1)

        if "." in key:
            set_nested_dict(result, key, infer_type(value))
        else:
            result[key] = infer_type(value)

    return result


@click.group()
def run():
    """Execute agents and workflows."""
    pass


@run.command("workflow")
@click.argument("workflow_name")
@click.option("--novel", required=True, help="Novel project name")
@click.option("--var", multiple=True, help="Variables in KEY=VALUE format")
@click.option("--provider", default="openai", help="LLM provider to use")
@click.pass_context
def run_workflow(
    ctx: click.Context, workflow_name: str, novel: str, var: tuple[str, ...], provider: str
):
    """Execute a workflow."""
    debug = (ctx.obj or {}).get("debug", False)
    logger = logging.getLogger("scribe")

    try:
        logger.info(f"Executing workflow '{workflow_name}' for novel '{novel}'")

        storage_config = StorageConfig(base_path=".novels")
        storage = StorageFactory.create(storage_config)

        project_path = Path(storage_config.base_path) / novel
        if not project_path.exists():
            logger.error(f"Novel '{novel}' not found")
            logger.info(f"Create it first with: scribe new {novel}")
            sys.exit(1)

        workflows_dir = Path("workflows")
        if not workflows_dir.exists():
            logger.error("Workflows directory not found")
            sys.exit(1)

        workflow_loader = WorkflowLoader(workflows_dir)
        workflow = workflow_loader.load_workflow(workflow_name)

        if not workflow:
            logger.error(f"Workflow '{workflow_name}' not found")
            all_workflows = workflow_loader.load_all_workflows()
            available = [w.name for w in all_workflows]
            logger.info(f"Available workflows: {', '.join(available)}")
            sys.exit(1)

        cli_vars = parse_vars(var)

        meta = storage.read_yaml(f"{novel}/META.yaml") or {}
        meta_vars = meta.get("variables", {})

        workflow_vars = {k: v for k, v in workflow.variables.items() if v is not None}

        merged_vars = {**meta_vars, **workflow_vars, **cli_vars}
        merged_vars["project_name"] = novel
        merged_vars["provider"] = provider

        llm_config = LLMConfig(provider=provider)
        orchestrator = create_orchestrator(storage_config, llm_config)
        git_manager = create_git_manager(project_path, auto_commit=True)

        logger.info(f"Running workflow with {len(merged_vars)} variables...")

        result = orchestrator.execute_workflow(
            workflow_path=f"workflows/{workflow_name}.yaml",
            project_name=novel,
            initial_context=merged_vars,
        )

        git_manager.auto_commit_step(
            agent="cli",
            description=f"Execute workflow {workflow_name}",
        )

        if result.get("success"):
            logger.info(f"✅ Workflow '{workflow_name}' completed successfully for '{novel}'")
            logger.info(f"   Executed {len(result.get('history', []))} steps")
        else:
            logger.warning(f"⚠️  Workflow '{workflow_name}' completed with warnings")
            sys.exit(1)

    except click.BadParameter as e:
        logger.error(str(e))
        sys.exit(1)
    except Exception as e:
        handle_cli_exception(logger, f"Failed to execute workflow: {e}", e, debug=debug)


@run.command("agent")
@click.argument("agent_name")
@click.option("--novel", required=True, help="Novel project name")
@click.option("--input", "inputs", multiple=True, help="Inputs in KEY=VALUE format")
@click.option("--provider", default="openai", help="LLM provider to use")
@click.pass_context
def run_agent(
    ctx: click.Context, agent_name: str, novel: str, inputs: tuple[str, ...], provider: str
):
    """Execute an agent."""
    debug = (ctx.obj or {}).get("debug", False)
    logger = logging.getLogger("scribe")

    try:
        logger.info(f"Executing agent '{agent_name}' for novel '{novel}'")

        storage_config = StorageConfig(base_path=".novels")
        storage = StorageFactory.create(storage_config)

        project_path = Path(storage_config.base_path) / novel
        if not project_path.exists():
            logger.error(f"Novel '{novel}' not found")
            logger.info(f"Create it first with: scribe new {novel}")
            sys.exit(1)

        agents_dir = Path("agents")
        if not agents_dir.exists():
            logger.error("Agents directory not found")
            sys.exit(1)

        agent_registry = AgentRegistry(agents_dir)
        agent = agent_registry.get_agent(agent_name)

        if not agent:
            logger.error(f"Agent '{agent_name}' not found")
            all_agents = agent_registry.get_all_agents()
            available = [a.name for a in all_agents]
            logger.info(f"Available agents: {', '.join(available)}")
            sys.exit(1)

        cli_inputs = parse_vars(inputs)

        llm_config = LLMConfig(provider=provider)
        agent_integration = AgentSystemIntegration(
            agent_registry=agent_registry,
            llm_config=llm_config,
            storage=storage,
            work_dir=project_path,
        )

        logger.info(f"Running agent with {len(cli_inputs)} inputs...")

        result = agent_integration.execute_agent(
            agent_name=agent_name,
            context_data=cli_inputs,
        )

        logger.info(f"✅ Agent '{agent_name}' completed successfully for '{novel}'")

        if result.output:
            logger.info(f"   Output keys: {', '.join(result.output.keys())}")

        if result.error:
            logger.warning(f"   Errors: {result.error}")

    except click.BadParameter as e:
        logger.error(str(e))
        sys.exit(1)
    except Exception as e:
        handle_cli_exception(logger, f"Failed to execute agent: {e}", e, debug=debug)
