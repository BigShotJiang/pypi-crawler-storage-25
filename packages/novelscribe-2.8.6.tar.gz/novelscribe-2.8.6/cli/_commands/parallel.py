"""
Parallel execution CLI commands for Novel Generation System

This module provides CLI commands for parallel execution of agents.
"""

import asyncio
import time

import click

from core.parallel_orchestrator import (
    ExecutionMode,
    ParallelConfig,
    ParallelOrchestrator,
    get_parallel_orchestrator,
)
from core.phase_parallelizer import PhaseDependency, PhaseParallelizer


@click.group(name="parallel")
def parallel_cli():
    """Parallel execution commands for faster generation"""
    pass


@parallel_cli.command()
@click.argument("project_name")
@click.option("--max-agents", default=3, help="Maximum concurrent agents")
@click.option(
    "--mode",
    type=click.Choice(["auto", "parallel", "sequential"]),
    default="auto",
    help="Execution mode",
)
@click.option("--timeout", default=300, help="Timeout per phase (seconds)")
def plan(project_name: str, max_agents: int, mode: str, timeout: int):
    """Show execution plan for a project"""
    click.echo(f"\n📋 Execution Plan for: {project_name}")
    click.echo(f"   Mode: {mode}")
    click.echo(f"   Max Agents: {max_agents}")
    click.echo(f"   Timeout: {timeout}s\n")

    parallelizer = PhaseParallelizer.create_novel_generation_phases(project_name)

    click.echo(parallelizer.get_execution_plan())


@parallel_cli.command()
@click.argument("project_name")
@click.option("--max-agents", default=3, help="Maximum concurrent agents")
@click.option(
    "--mode",
    type=click.Choice(["auto", "parallel", "sequential"]),
    default="auto",
    help="Execution mode",
)
@click.option("--timeout", default=300, help="Timeout per phase (seconds)")
@click.option(
    "--dry-run",
    is_flag=True,
    help="Run simulation mode with mock executor (does not call real workflow/LLM).",
)
def execute(project_name: str, max_agents: int, mode: str, timeout: int, dry_run: bool):
    """Execute phases in parallel mode.

    Notes:
    - This command currently supports simulation-only execution.
    - Use `--dry-run` to run with a mock executor explicitly.
    """
    if not dry_run:
        raise click.UsageError(
            "parallel execute now requires --dry-run for simulation mode. "
            "Use this command for plan/simulation only."
        )

    click.echo("⚠️  DRY-RUN MODE: using mock executor (no real agent/workflow execution).")
    click.echo(f"\n🚀 Parallel Execution: {project_name}")
    click.echo(f"   Mode: {mode}")
    click.echo(f"   Max Agents: {max_agents}")
    click.echo(f"   Timeout: {timeout}s\n")

    config = ParallelConfig(
        enabled=True,
        max_concurrent=max_agents,
        execution_mode=ExecutionMode(mode),
        timeout_per_phase=timeout,
    )

    orchestrator = ParallelOrchestrator(config)

    parallelizer = PhaseParallelizer.create_novel_generation_phases(project_name)

    click.echo("📊 Execution Plan:")
    click.echo(parallelizer.get_execution_plan())
    click.echo()

    async def run_execution():
        phases = list(parallelizer.phases.values())

        def progress_callback(phase: str, progress: float):
            click.echo(f"   {phase}: {progress:.1f}%")

        async def mock_executor(agent_name: str, prompt: str):
            await asyncio.sleep(0.5)
            return f"Completed: {agent_name}"

        result = await orchestrator.execute_phases(
            phases=phases, executor_func=mock_executor, progress_callback=progress_callback
        )

        return result

    start = time.time()
    result = asyncio.run(run_execution())
    duration = time.time() - start

    click.echo("\n✅ Execution Complete!")
    click.echo(f"   Duration: {duration:.2f}s")
    click.echo(f"   Phases Executed: {result.phases_executed}")
    click.echo(f"   Phases Failed: {result.phases_failed}")

    if result.phases_failed > 0:
        click.echo("\n❌ Failed Phases:")
        for phase in result.failed_phases:
            click.echo(f"   - {phase}")


@parallel_cli.command()
def benchmark():
    """Run parallel execution benchmark"""
    click.echo("\n📊 Parallel Execution Benchmark\n")

    async def run_benchmark():
        config = ParallelConfig(enabled=True, max_concurrent=3)
        orchestrator = ParallelOrchestrator(config)

        phases = [
            PhaseDependency(
                phase_name="phase1", agent_name="agent1", prompt_template="Execute phase 1"
            ),
            PhaseDependency(
                phase_name="phase2", agent_name="agent2", prompt_template="Execute phase 2"
            ),
            PhaseDependency(
                phase_name="phase3", agent_name="agent3", prompt_template="Execute phase 3"
            ),
        ]

        async def mock_executor(agent_name: str, prompt: str):
            await asyncio.sleep(0.3)
            return f"Completed: {agent_name}"

        click.echo("Sequential Execution:")
        start = time.time()
        await orchestrator.execute_phases(
            phases=phases, executor_func=mock_executor, parallel=False
        )
        seq_duration = time.time() - start
        click.echo(f"   Duration: {seq_duration:.2f}s")

        click.echo("\nParallel Execution:")
        start = time.time()
        await orchestrator.execute_phases(phases=phases, executor_func=mock_executor, parallel=True)
        par_duration = time.time() - start
        click.echo(f"   Duration: {par_duration:.2f}s")

        speedup = seq_duration / par_duration if par_duration > 0 else 0
        time_saved_percent = (
            ((seq_duration - par_duration) / seq_duration * 100) if seq_duration > 0 else 0
        )
        click.echo(f"\n🚀 Speedup: {speedup:.2f}x")
        click.echo(f"   Time Saved: {seq_duration - par_duration:.2f}s ({time_saved_percent:.1f}%)")

    asyncio.run(run_benchmark())


@parallel_cli.command()
def stats():
    """Show parallel execution statistics"""
    orchestrator = get_parallel_orchestrator()
    metrics = orchestrator.get_metrics()

    click.echo("\n📊 Parallel Execution Statistics\n")
    click.echo(f"   Total Executions: {metrics['total_executions']}")
    click.echo(f"   Parallel: {metrics['parallel_executions']}")
    click.echo(f"   Sequential: {metrics['sequential_executions']}")
    click.echo(f"   Total Duration: {metrics['total_duration']:.2f}s")
    click.echo(f"   Avg Speedup: {metrics['avg_speedup']:.2f}x")


def register_parallel_cli(cli_obj):
    """Register parallel CLI commands"""
    cli_obj.add_command(parallel_cli)
