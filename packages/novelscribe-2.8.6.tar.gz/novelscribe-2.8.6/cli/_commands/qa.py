"""
CLI Commands for Quality Assurance System

This module provides command-line interface commands for quality assurance,
including metrics calculation, validation, benchmarking, and quality gate checks.
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Optional

import click

from core.benchmarking import BenchmarkingEngine, BenchmarkType
from core.quality_gate import QualityGate, QualityLevel
from core.quality_metrics import QualityMetricsCalculator
from core.validation_system import RuleCategory, Severity, ValidationSystem
from qa_reporting_helpers import (
    build_comprehensive_report,
    render_compare_result,
    render_gate_check_result,
)


@click.group()
def qa():
    """Quality assurance commands for novel generation."""
    pass


@qa.command()
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, help="Specific chapter to analyze")
@click.option("--version", "-v", type=int, default=1, help="Draft version to analyze")
@click.option("--output", "-o", type=click.Path(), help="Output file for metrics")
@click.option(
    "--format",
    "-f",
    type=click.Choice(["text", "json", "markdown"]),
    default="text",
    help="Output format",
)
def analyze(
    project_name: str, chapter: Optional[int], version: int, output: Optional[str], format: str
):
    """
    Run quality analysis on project content.

    Calculates comprehensive quality metrics including readability,
    dialogue quality, pacing, consistency, and style analysis.
    """
    project_root = Path.cwd()
    calculator = QualityMetricsCalculator(project_root=project_root)

    if chapter:
        content_path = project_root / project_name / f"chapter_{chapter:03d}.md"
        if not content_path.exists():
            click.echo(f"Error: Chapter {chapter} not found at {content_path}")
            return

        content = content_path.read_text()
        metrics = calculator.calculate_metrics(content, chapter, version)
        results = [metrics]
    else:
        results = []
        content_dir = project_root / project_name
        for content_file in sorted(content_dir.glob("chapter_*.md")):
            chapter_num = int(content_file.stem.split("_")[1])
            content = content_file.read_text()
            metrics = calculator.calculate_metrics(content, chapter_num, version)
            results.append(metrics)

    if format == "json":
        output_data = [m.model_dump() for m in results]
        if output:
            Path(output).write_text(json.dumps(output_data, indent=2, default=str))
        else:
            click.echo(json.dumps(output_data, indent=2, default=str))
    elif format == "markdown":
        for metrics in results:
            summary = calculator.get_metrics_summary(metrics)
            if output:
                Path(output).write_text(summary)
            else:
                click.echo(summary)
                click.echo("---")
                click.echo()
    else:
        for metrics in results:
            click.echo(f"\n=== Chapter {metrics.chapter_number} (v{metrics.version}) ===")
            click.echo(f"Overall Quality Score: {metrics.overall_quality_score:.1%}")
            click.echo(f"Word Count: {metrics.word_count:,}")
            click.echo(f"Readability (Flesch-Kincaid): {metrics.flesch_kincaid:.1f}")
            click.echo(f"Dialogue Ratio: {metrics.dialogue_ratio:.1%}")
            click.echo(f"Speaker Clarity: {metrics.speaker_clarity:.1%}")
            click.echo(f"Vocabulary Diversity: {metrics.vocabulary_diversity:.1%}")
            click.echo(f"Passive Voice: {metrics.passive_voice_ratio:.1%}")

    click.echo(f"\n✅ Analyzed {len(results)} chapter(s)")


@qa.command()
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, help="Specific chapter to validate")
@click.option("--rules", "-r", help="Comma-separated list of rule IDs to validate")
@click.option(
    "--category",
    "-cat",
    type=click.Choice(["content", "structure", "style", "continuity"]),
    help="Validate specific category",
)
@click.option(
    "--severity", "-s", type=click.Choice(["error", "warning", "info"]), help="Filter by severity"
)
@click.option("--output", "-o", type=click.Path(), help="Output file for report")
def validate(
    project_name: str,
    chapter: Optional[int],
    rules: Optional[str],
    category: Optional[str],
    severity: Optional[str],
    output: Optional[str],
):
    """
    Run validation checks on project content.

    Validates content against configurable rules for content quality,
    structure, style, and continuity issues.
    """
    project_root = Path.cwd()
    validator = ValidationSystem(project_root=project_root)

    rule_ids = None
    if rules:
        rule_ids = [r.strip() for r in rules.split(",")]

    if category:
        category_enum = RuleCategory(category)
        validator.rules = {
            rid: rule for rid, rule in validator.rules.items() if rule.category == category_enum
        }

    severity_filter = Severity(severity) if severity else None

    content_path = project_root / project_name
    if chapter:
        content_files = [content_path / f"chapter_{chapter:03d}.md"]
    else:
        content_files = sorted(content_path.glob("chapter_*.md"))

    all_results = []
    for content_file in content_files:
        if not content_file.exists():
            click.echo(f"Warning: {content_file} not found")
            continue

        content = content_file.read_text()
        report = validator.validate_content(
            content, context={"content_path": str(content_file)}, rule_ids=rule_ids
        )

        if severity_filter:
            report.results = [
                r for r in report.results if not r.passed and r.rule.severity == severity_filter
            ]

        all_results.append(report)

    for report in all_results:
        summary = validator.generate_report_summary(report)
        click.echo(summary)
        click.echo()

    if output:
        output_data = {
            "timestamp": datetime.now().isoformat(),
            "total_reports": len(all_results),
            "reports": [r.model_dump() for r in all_results],
        }
        Path(output).write_text(json.dumps(output_data, indent=2, default=str))

    total_errors = sum(r.errors for r in all_results)
    total_warnings = sum(r.warnings for r in all_results)

    if total_errors > 0:
        click.echo(
            f"❌ Validation failed with {total_errors} error(s) and {total_warnings} warning(s)"
        )
    elif total_warnings > 0:
        click.echo(f"⚠️  Validation passed with {total_warnings} warning(s)")
    else:
        click.echo(f"✅ All validation checks passed for {len(all_results)} file(s)")


@qa.command()
@click.argument("project_name")
@click.option(
    "--category",
    "-cat",
    type=click.Choice(["performance", "quality", "style", "readability"]),
    help="Benchmark category",
)
@click.option(
    "--benchmark",
    "-b",
    type=str,
    default="published_novel",
    help="Comparison benchmark (published_novel, bestseller)",
)
@click.option(
    "--genre", "-g", type=str, help="Genre-specific benchmarking (fantasy, mystery, romance, scifi)"
)
@click.option("--export", "-e", type=click.Path(), help="Export benchmark data to file")
def benchmark(
    project_name: str,
    category: Optional[str],
    benchmark: str,
    genre: Optional[str],
    export: Optional[str],
):
    """
    Run performance and quality benchmarks.

    Compares content against published works and genre standards
    to assess quality and track improvements over time.
    """
    project_root = Path.cwd()
    engine = BenchmarkingEngine(project_root=project_root)

    if category:
        benchmark_type = BenchmarkType(category)
    else:
        benchmark_type = None

    report = engine.generate_benchmark_report(project_name, benchmark_type)

    click.echo(f"\n=== Benchmark Report: {project_name} ===")
    click.echo(f"Generated: {report.timestamp.strftime('%Y-%m-%d %H:%M:%S')}")
    click.echo()

    if benchmark_type is None or benchmark_type == BenchmarkType.QUALITY:
        quality_results = report.get_results_by_type(BenchmarkType.QUALITY)
        if quality_results:
            click.echo("## Quality Benchmarks")
            for result in quality_results[-5:]:
                click.echo(f"  {result}")
            click.echo()

    if benchmark_type is None or benchmark_type == BenchmarkType.PERFORMANCE:
        perf_results = report.get_results_by_type(BenchmarkType.PERFORMANCE)
        if perf_results:
            click.echo("## Performance Benchmarks")
            for result in perf_results[-5:]:
                click.echo(f"  {result}")
            click.echo()

    stats = engine.get_statistics(project_name)
    if "error" not in stats:
        click.echo("## Statistics")
        if stats["quality_metrics"]["total_entries"] > 0:
            click.echo(
                f"  Quality Score: {stats['quality_metrics']['average_score']:.2f} "
                f"(±{stats['quality_metrics'].get('std_dev', 0):.2f})"
            )
        if stats["performance_metrics"]["total_entries"] > 0:
            click.echo(
                f"  Words/Minute: {stats['performance_metrics']['average_wpm']:.1f} "
                f"(±{stats['performance_metrics'].get('std_dev', 0):.1f})"
            )

    if export:
        export_path = engine.export_benchmark_data(project_name, Path(export))
        click.echo(f"\n✅ Benchmark data exported to {export_path}")

    progress = engine.track_progress(project_name)
    if progress["trend"] != "no_data":
        click.echo(f"\n## Progress Trend: {progress['trend'].title()}")
        click.echo(f"  Current Score: {progress['current']:.2f}")
        click.echo(f"  Average: {progress['average']:.2f}")
        click.echo(f"  Improvement: {progress['improvement']:.1f}%")


@qa.command()
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, required=True, help="Chapter number to check")
@click.option("--version", "-v", type=int, default=1, help="Draft version to check")
@click.option(
    "--level",
    "-l",
    type=click.Choice(["bronze", "silver", "gold", "platinum"]),
    default="silver",
    help="Quality gate level",
)
@click.option("--auto-fix", "-a", is_flag=True, help="Generate auto-fix suggestions")
@click.option("--output", "-o", type=click.Path(), help="Output quality report to file")
def gate_check(
    project_name: str, chapter: int, version: int, level: str, auto_fix: bool, output: Optional[str]
):
    """
    Check if content meets quality gate requirements.

    Evaluates content against Bronze, Silver, Gold, or Platinum
    quality standards and provides recommendations for improvement.
    """
    project_root = Path.cwd()
    gate = QualityGate(project_root=project_root)
    calculator = QualityMetricsCalculator(project_root=project_root)
    validator = ValidationSystem(project_root=project_root)

    content_path = project_root / project_name / f"chapter_{chapter:03d}.md"
    if not content_path.exists():
        click.echo(f"Error: Chapter {chapter} not found at {content_path}")
        return

    content = content_path.read_text()
    metrics = calculator.calculate_metrics(content, chapter, version)
    validation_report = validator.validate_content(
        content, context={"content_path": str(content_path)}
    )

    target_level = QualityLevel(level)
    promotion_status = gate.promote_to_level(
        project_name, metrics, validation_report, target_level, auto_fix
    )
    render_gate_check_result(
        project_name=project_name,
        chapter=chapter,
        version=version,
        target_level=target_level,
        promotion_status=promotion_status,
        auto_fix=auto_fix,
    )

    if output:
        quality_report = gate.generate_quality_report(project_name, metrics, validation_report)
        Path(output).write_text(quality_report)
        click.echo(f"✅ Quality report saved to {output}")


@qa.command()
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, required=True, help="Chapter number to compare")
@click.option("--from", "from_version", type=int, required=True, help="Starting version")
@click.option("--to", "to_version", type=int, required=True, help="Ending version")
@click.option("--output", "-o", type=click.Path(), help="Output comparison report to file")
def compare(
    project_name: str, chapter: int, from_version: int, to_version: int, output: Optional[str]
):
    """
    Compare quality metrics between two versions.

    Shows improvements and regressions between draft versions
    to track quality evolution over time.
    """
    project_root = Path.cwd()
    calculator = QualityMetricsCalculator(project_root=project_root)

    content_dir = project_root / project_name / ".scribe" / "drafts"

    from_content_path = content_dir / f"chapter_{chapter:03d}_v{from_version}.md"
    to_content_path = content_dir / f"chapter_{chapter:03d}_v{to_version}.md"

    if not from_content_path.exists():
        click.echo(f"Error: Version {from_version} not found at {from_content_path}")
        return

    if not to_content_path.exists():
        click.echo(f"Error: Version {to_version} not found at {to_content_path}")
        return

    from_content = from_content_path.read_text()
    to_content = to_content_path.read_text()

    from_metrics = calculator.calculate_metrics(from_content, chapter, from_version)
    to_metrics = calculator.calculate_metrics(to_content, chapter, to_version)

    comparison = calculator.compare_metrics(from_metrics, to_metrics)
    render_compare_result(
        chapter=chapter,
        from_version=from_version,
        to_version=to_version,
        from_metrics=from_metrics,
        to_metrics=to_metrics,
        comparison=comparison,
    )

    if output:
        comparison_report = {
            "project_name": project_name,
            "chapter": chapter,
            "from_version": from_version,
            "to_version": to_version,
            "comparison": comparison,
            "from_metrics": from_metrics.model_dump(),
            "to_metrics": to_metrics.model_dump(),
        }
        Path(output).write_text(json.dumps(comparison_report, indent=2, default=str))
        click.echo(f"\n✅ Comparison report saved to {output}")


@qa.command()
@click.argument("project_name")
@click.option("--output", "-o", type=click.Path(), help="Output file for comprehensive report")
def report(project_name: str, output: Optional[str]):
    """
    Generate comprehensive quality report.

    Combines metrics, validation, benchmarking, and quality gate
    results into a detailed quality assessment report.
    """
    project_root = Path.cwd()

    calculator = QualityMetricsCalculator(project_root=project_root)
    validator = ValidationSystem(project_root=project_root)
    engine = BenchmarkingEngine(project_root=project_root)
    gate = QualityGate(project_root=project_root)

    content_dir = project_root / project_name

    report_text, chapter_count = build_comprehensive_report(
        project_name=project_name,
        content_dir=content_dir,
        calculator=calculator,
        validator=validator,
        engine=engine,
        gate=gate,
        quality_level=QualityLevel.SILVER,
    )

    if output:
        Path(output).write_text(report_text)
        click.echo(f"✅ Comprehensive quality report saved to {output}")
    else:
        click.echo(report_text)

    click.echo(f"\n✅ Generated report for {chapter_count} chapter(s)")
