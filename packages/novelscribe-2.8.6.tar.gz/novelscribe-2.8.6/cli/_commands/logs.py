"""CLI commands for logging system."""

import json
import logging

import click

from cli._helpers.logs_helpers import fetch_export_rows, fetch_recent_requests, render_timestamp

logger = logging.getLogger("scribe")


@click.group()
def logs():
    """Query and analyze logs."""
    pass


@logs.command()
@click.option("--project", help="Filter by project name")
@click.option("--period", default="30d", help="Time period (7d, 30d, 90d, all)")
@click.option("--provider", help="Filter by provider")
@click.option("--model", help="Filter by model")
@click.option("--group-by", default="day", type=click.Choice(["day", "provider", "model"]))
def tokens(project, period, provider, model, group_by):
    """Show token usage statistics."""
    try:
        from core.logger import get_logger

        log = get_logger()

        if not log.token_tracker:
            click.echo("❌ Token tracking not enabled", err=True)
            return

        usage = log.token_tracker.get_usage(
            project=project, period=period, provider=provider, model=model, group_by=group_by
        )

        if "error" in usage:
            click.echo(f"❌ {usage['error']}", err=True)
            return

        # Print summary
        click.echo("\n📊 Token Usage Report")
        click.echo("=" * 60)
        click.echo(f"Period: {period}")
        if project:
            click.echo(f"Project: {project}")
        if provider:
            click.echo(f"Provider: {provider}")
        if model:
            click.echo(f"Model: {model}")

        click.echo("")
        click.echo(f"Total Input Tokens:  {usage['total_input_tokens']:,}")
        click.echo(f"Total Output Tokens: {usage['total_output_tokens']:,}")
        click.echo(f"Total Tokens:       {usage['total_tokens']:,}")
        click.echo(f"Total Cost:         ${usage['total_cost_usd']:.4f}")
        click.echo(f"Request Count:      {usage['request_count']:,}")
        click.echo(f"Avg Tokens/Request: {usage['avg_tokens_per_request']:,.0f}")
        click.echo(f"Avg Cost/Request:   ${usage['avg_cost_per_request']:.6f}")

        # Print breakdown
        if "daily" in usage and usage["daily"]:
            click.echo("\n📅 Daily Breakdown:")
            click.echo("-" * 60)
            for day in usage["daily"][:10]:
                click.echo(
                    f"  {day['date']}: {day['total_tokens']:>10,} tokens (${day['cost_usd']:.4f})"
                )

        if "by_provider" in usage and usage["by_provider"]:
            click.echo("\n🏢 By Provider:")
            click.echo("-" * 60)
            for item in usage["by_provider"]:
                click.echo(
                    f"  {item['provider']:>15}: {item['total_tokens']:>10,} tokens "
                    f"(${item['cost_usd']:.4f})"
                )

        if "by_model" in usage and usage["by_model"]:
            click.echo("\n🤖 By Model:")
            click.echo("-" * 60)
            for item in usage["by_model"][:10]:
                click.echo(
                    f"  {item['model'][:30]:30}: {item['total_tokens']:>10,} tokens "
                    f"(${item['cost_usd']:.4f})"
                )

        click.echo("")

    except Exception as e:
        logger.error(f"Failed to get token usage: {e}")
        click.echo(f"❌ Error: {e}", err=True)


@logs.command()
@click.option("--project", help="Filter by project name")
@click.option("--period", default="month", help="Time period (7d, 30d, month)")
@click.option("--compare", is_flag=True, help="Compare with previous period")
def costs(project, period, compare):
    """Show cost breakdown by provider and model."""
    try:
        from core.logger import get_logger

        log = get_logger()

        if not log.token_tracker:
            click.echo("❌ Cost tracking not enabled", err=True)
            return

        breakdown = log.token_tracker.get_cost_breakdown(project=project, period=period)

        if "error" in breakdown:
            click.echo(f"❌ {breakdown['error']}", err=True)
            return

        click.echo("\n💰 Cost Breakdown Report")
        click.echo("=" * 60)
        click.echo(f"Period: {period}")
        if project:
            click.echo(f"Project: {project}")

        click.echo("")
        click.echo(f"Total Cost: ${breakdown['total_cost_usd']:.4f}")
        click.echo("")

        click.echo("📊 By Provider/Model:")
        click.echo("-" * 60)

        for item in breakdown["breakdown"]:
            provider = item["provider"]
            model = item["model"]
            cost = item["cost_usd"]
            pct = item["cost_percentage"]

            bar = "█" * int(pct / 2) if pct > 0 else ""
            click.echo(f"  {provider}/{model[:25]:25} ${cost:>8.4f} {pct:>5.1f}% {bar}")

        click.echo("")

    except Exception as e:
        logger.error(f"Failed to get cost breakdown: {e}")
        click.echo(f"❌ Error: {e}", err=True)


@logs.command()
@click.option("--limit", default=100, help="Number of requests to show")
@click.option("--slow", is_flag=True, help="Show only slow requests (>5s)")
@click.option("--errors", is_flag=True, help="Show only failed requests")
@click.option("--project", help="Filter by project")
def requests(limit, slow, errors, project):
    """Show recent LLM requests."""
    try:
        from core.logger import get_logger

        log = get_logger()

        if not log.token_tracker:
            click.echo("❌ Request logging not enabled", err=True)
            return

        if slow:
            data = log.token_tracker.get_slow_requests(threshold_ms=5000, limit=limit)
            click.echo("\n🐌 Slowest Requests (>5s latency)")
        elif errors:
            data = log.token_tracker.get_errors(project=project, limit=limit)
            click.echo("\n❌ Failed Requests")
        else:
            # Get recent requests from database
            if not log.db_logger:
                click.echo("❌ Database logging not enabled", err=True)
                return

            data = fetch_recent_requests(log, project, limit)

            click.echo("\n📝 Recent Requests")

        if not data:
            click.echo("  No requests found")
            return

        click.echo("=" * 80)

        for req in data:
            timestamp = render_timestamp(req.get("timestamp", "Unknown"))

            agent = req.get("agent") or "Unknown"
            latency = req.get("latency_ms", 0)
            tokens = req.get("total_tokens", 0)
            cost = req.get("cost_usd", 0)
            status = req.get("status", "unknown")
            error = req.get("error")

            status_icon = "✅" if status == "success" else "❌"

            click.echo(
                f"\n{status_icon} {timestamp} | "
                f"{agent[:20]:20} | "
                f"{latency:>6}ms | "
                f"{tokens:>8,} tokens | "
                f"${cost:.4f}"
            )

            if error:
                click.echo(f"   Error: {error[:60]}")

        click.echo("")

    except Exception as e:
        logger.error(f"Failed to get requests: {e}")
        click.echo(f"❌ Error: {e}", err=True)


@logs.command()
@click.option("--limit", default=10, help="Number of consumers to show")
@click.option("--period", default="30d", help="Time period")
@click.option("--group-by", default="agent", type=click.Choice(["agent", "project", "model"]))
def top(limit, period, group_by):
    """Show top token consumers."""
    try:
        from core.logger import get_logger

        log = get_logger()

        if not log.token_tracker:
            click.echo("❌ Token tracking not enabled", err=True)
            return

        consumers = log.token_tracker.get_top_consumers(
            limit=limit, period=period, group_by=group_by
        )

        click.echo(f"\n🏆 Top {limit} Token Consumers")
        click.echo("=" * 80)
        click.echo(f"Period: {period} | Grouped by: {group_by}")
        click.echo("")

        if not consumers:
            click.echo("  No data found")
            return

        for i, consumer in enumerate(consumers, 1):
            name = consumer["consumer"] or "Unknown"
            tokens = consumer["total_tokens"]
            cost = consumer["cost_usd"]
            count = consumer["request_count"]
            avg_latency = consumer["avg_latency_ms"]

            click.echo(
                f"{i:2}. {name[:40]:40} | "
                f"{tokens:>10,} tokens | "
                f"${cost:>8.4f} | "
                f"{count:>5} reqs | "
                f"{avg_latency:>6.0f}ms avg"
            )

        click.echo("")

    except Exception as e:
        logger.error(f"Failed to get top consumers: {e}")
        click.echo(f"❌ Error: {e}", err=True)


@logs.command()
@click.option("--format", default="json", type=click.Choice(["json", "csv"]))
@click.option("--period", default="30d", help="Time period")
@click.option("--project", help="Filter by project")
@click.option("--output", "-o", help="Output file (default: stdout)")
def export(format, period, project, output):
    """Export logs to JSON or CSV."""
    try:
        from core.logger import get_logger

        log = get_logger()

        if not log.db_logger:
            click.echo("❌ Database logging not enabled", err=True)
            return

        rows, _ = fetch_export_rows(log, period, project)

        # Format output
        if format == "json":
            data = [dict(row) for row in rows]
            output_str = json.dumps(data, indent=2, default=str)
        else:  # csv
            import csv
            import io

            output_str = io.StringIO()
            if rows:
                writer = csv.DictWriter(output_str, fieldnames=rows[0].keys())
                writer.writeheader()
                for row in rows:
                    writer.writerow(dict(row))
            output_str = output_str.getvalue()

        # Write output
        if output:
            with open(output, "w") as f:
                f.write(output_str)
            click.echo(f"✅ Exported {len(rows)} entries to {output}")
        else:
            click.echo(output_str)

    except Exception as e:
        logger.error(f"Failed to export logs: {e}")
        click.echo(f"❌ Error: {e}", err=True)


@logs.command()
def stats():
    """Show logging system statistics."""
    try:
        from core.logger import get_logger

        log = get_logger()

        stats = log.get_stats()

        click.echo("\n📈 Logging System Statistics")
        click.echo("=" * 60)
        click.echo(f"Total Requests:      {stats['total_requests']:,}")
        click.echo(f"Total Tokens:        {stats['total_tokens']:,}")
        click.echo(f"Total Cost:         ${stats['total_cost_usd']:.4f}")
        click.echo(f"Error Count:        {stats['error_count']}")
        click.echo(f"Error Rate:         {stats['error_rate']:.2f}%")
        click.echo(f"Total User Actions: {stats['total_actions']:,}")
        click.echo(f"Requests (24h):     {stats['recent_requests_24h']:,}")
        click.echo("")

    except Exception as e:
        logger.error(f"Failed to get stats: {e}")
        click.echo(f"❌ Error: {e}", err=True)


@logs.command("runs")
@click.argument("project")
@click.option("--run-id", help="Specific run ID to show (default: latest)")
@click.option("--filter", "event_filter", help="Filter events by type (e.g. agent_complete)")
@click.option("--limit", default=50, help="Max events to display")
def runs(project: str, run_id: str | None, event_filter: str | None, limit: int) -> None:
    """Show pipeline run logs for a project."""
    try:
        from pathlib import Path

        from core.run_logger import RunLogger

        storage_path = Path(".") / project
        if not storage_path.exists():
            click.echo(f"❌ Project directory not found: {project}", err=True)
            return

        if run_id:
            events = RunLogger.read_run(storage_path, run_id)
            if not events:
                click.echo(f"❌ No run log found: {run_id}", err=True)
                return
        else:
            all_runs = RunLogger.list_runs(storage_path)
            if not all_runs:
                click.echo("❌ No run logs found for this project", err=True)
                return

            latest = all_runs[0]
            run_id = latest["run_id"]
            events = RunLogger.read_run(storage_path, run_id)

        if event_filter:
            events = [e for e in events if e.get("type") == event_filter]

        events = events[:limit]

        click.echo(f"\n📋 Run Log: {run_id}")
        click.echo("=" * 80)

        for evt in events:
            ts = evt.get("ts", "")
            if isinstance(ts, str) and len(ts) > 19:
                ts = ts[:19]
            evt_type = evt.get("type", "unknown")
            agent = evt.get("agent", "")
            duration = evt.get("duration_ms")
            success = evt.get("success")

            parts = [f"{ts}", f"{evt_type}"]
            if agent:
                parts.append(f"agent={agent}")
            if duration is not None:
                parts.append(f"{duration}ms")
            if success is not None:
                icon = "✅" if success else "❌"
                parts.append(icon)

            click.echo(" | ".join(parts))

        click.echo("")

    except Exception as e:
        logger.error(f"Failed to show run logs: {e}")
        click.echo(f"❌ Error: {e}", err=True)


# Backward/UX aliases:
# - `logs run` (legacy)
# - `logs pipeline` (explicit pipeline wording)
logs.add_command(runs, name="run")
logs.add_command(runs, name="pipeline")
