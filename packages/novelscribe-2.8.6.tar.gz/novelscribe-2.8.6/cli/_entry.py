"""Command-line interface for novel writing harness."""

import logging
import os
import sys
from difflib import get_close_matches
from pathlib import Path

import click
from dotenv import load_dotenv

from cli._commands.agents import agents
from cli._commands.autonomous import autonomous, start_autonomous
from cli._commands.character import character
from cli._commands.chat import chat
from cli._commands.checkpoint import checkpoint
from cli._commands.config import config
from cli._commands.drafts import drafts
from cli._commands.export import export
from cli._commands.list import templates
from cli._commands.logs import logs
from cli._commands.memory import memory
from cli._commands.pagination import cache, paginate
from cli._commands.parallel import parallel_cli
from cli._commands.performance import performance_cli
from cli._commands.proactive import app as proactive
from cli._commands.project import project
from cli._commands.qa import qa
from cli._commands.review import review
from cli._commands.run import run
from cli._commands.setup import setup
from cli._commands.summary import summary
from cli._commands.verify import verify
from cli._commands.version import version as version_cmd
from cli._commands.workflows import workflows
from cli._helpers.error_handling import handle_cli_exception
from cli._templates.create import template_create
from core._version import get_version
from core.git_manager import create_git_manager
from core.llm_client import LLMConfig
from core.orchestrator import create_orchestrator
from core.storage import StorageConfig, StorageFactory

load_dotenv()


class ScribeCLI(click.Group):
    """Custom Click group with better error handling."""

    def get_command(self, ctx: click.Context, cmd_name: str):
        """Get command by name, with suggestions for typos."""
        # Try to get the command directly
        cmd = super().get_command(ctx, cmd_name)
        if cmd is not None:
            return cmd

        # If not found, try to suggest similar commands
        available_commands = list(self.commands.keys())
        suggestions = get_close_matches(cmd_name, available_commands, n=3, cutoff=0.4)

        if suggestions:
            suggestion_text = "\nDid you mean one of these?\n"
            for suggestion in suggestions:
                suggestion_text += f"  • {suggestion}\n"
            ctx.fail(f"No such command '{cmd_name}'.{suggestion_text}")
        else:
            ctx.fail(f"No such command '{cmd_name}'. Use 'scribe help' to see available commands.")


def configure_logging(verbose: int = 0, debug: bool = False) -> None:
    """Configure logging based on verbosity level."""
    log_level = logging.DEBUG if debug else logging.INFO

    if verbose == 0:
        log_format = "%(message)s"
    elif verbose == 1:
        log_format = "%(levelname)s: %(message)s"
    else:
        log_format = "%(levelname)s [%(name)s]: %(message)s"

    logging.basicConfig(
        level=log_level,
        format=log_format,
        stream=sys.stdout,
        force=True,
    )


HELP_SHORT = {"help_option_names": ["-h", "--help"]}

ENV_PROVIDER_KEYS = [
    ("openai", "OPENAI_API_KEY"),
    ("anthropic", "ANTHROPIC_API_KEY"),
    ("google", "GOOGLE_API_KEY"),
    ("minimax", "MINIMAX_API_KEY"),
    ("zhipu", "ZHIPUAI_API_KEY"),
    ("moonshot", "MOONSHOT_API_KEY"),
    ("ollama", "OLLAMA_BASE_URL"),
    ("lm_studio", "LM_STUDIO_BASE_URL"),
]

PROVIDER_DEFAULT_MODELS = {
    "openai": "gpt-4o",
    "anthropic": "claude-sonnet-4-20250514",
    "google": "gemini-2.0-flash",
    "minimax": "MiniMax-Text-01",
    "zhipu": "glm-4-flash",
    "moonshot": "moonshot-v1-8k",
    "ollama": "llama3",
    "lm_studio": "default",
}


def _canonicalize_provider(provider: str) -> str:
    """Normalize provider aliases to canonical IDs."""
    normalized = (provider or "").strip().lower()
    if normalized in {"lm-studio", "lmstudio"}:
        return "lm_studio"
    return normalized


def _detect_provider_from_setup() -> str:
    """Detect provider from configured environment variables."""
    for provider, env_key in ENV_PROVIDER_KEYS:
        if os.getenv(env_key):
            return _canonicalize_provider(provider)
    return ""


def _default_model_for_provider(provider: str) -> str:
    """Return default model for known provider."""
    return PROVIDER_DEFAULT_MODELS.get(_canonicalize_provider(provider), "gpt-4o")


def _resolve_new_project_llm(provider: str, model: str) -> tuple[str, str]:
    """Resolve provider/model for `new` with setup inheritance."""
    explicit_provider = _canonicalize_provider(provider)
    explicit_model = (model or "").strip()

    setup_provider = _canonicalize_provider(os.getenv("SCRIBE_DEFAULT_PROVIDER", ""))
    setup_model = (os.getenv("SCRIBE_DEFAULT_MODEL", "") or "").strip()

    resolved_provider = (
        explicit_provider or setup_provider or _detect_provider_from_setup() or "openai"
    )

    if explicit_model:
        resolved_model = explicit_model
    elif setup_provider and setup_provider == resolved_provider and setup_model:
        resolved_model = setup_model
    else:
        resolved_model = _default_model_for_provider(resolved_provider)

    return resolved_provider, resolved_model


@click.group(cls=ScribeCLI, context_settings=HELP_SHORT)
@click.option("-v", "--verbose", count=True, help="Increase verbosity (can be used multiple times)")
@click.option("-d", "--debug", is_flag=True, help="Enable debug mode")
@click.option(
    "--lang",
    type=click.Choice(["en", "zh-CN", "zh-TW"], case_sensitive=False),
    default=None,
    help="Language (en, zh-CN, zh-TW). Overrides project META.yaml.",
)
@click.version_option(version=get_version(), prog_name="scribe")
@click.option("--no-update-check", is_flag=True, help="Skip update check on startup")
@click.pass_context
def cli(
    ctx: click.Context, verbose: int, debug: bool, lang: str | None, no_update_check: bool
) -> None:
    """NovelScribe - AI-powered autonomous novel generation system."""
    ctx.ensure_object(dict)
    ctx.obj["verbose"] = verbose
    ctx.obj["debug"] = debug
    ctx.obj["lang"] = lang

    configure_logging(verbose, debug)

    logger = logging.getLogger("scribe")
    logger.debug(f"Scribe CLI started (verbose={verbose}, debug={debug}, lang={lang})")

    if not no_update_check and not debug:
        try:
            from core.version import notify_if_update_available

            notify_if_update_available()
        except Exception:
            pass


@cli.command()
@click.argument("project_name")
@click.option("--provider", default="", help="LLM provider (inherits setup default if omitted)")
@click.option("--model", default="", help="LLM model (inherits setup default if omitted)")
@click.pass_context
def new(ctx: click.Context, project_name: str, provider: str, model: str) -> None:
    """Initialize a new novel project."""
    debug = ctx.obj.get("debug", False)
    logger = logging.getLogger("scribe")

    try:
        logger.info(f"Creating new novel project: {project_name}")
        resolved_provider, resolved_model = _resolve_new_project_llm(provider, model)

        storage_config = StorageConfig(base_path=".novels")
        storage = StorageFactory.create(storage_config)

        project_path = Path(storage_config.base_path) / project_name
        project_path.mkdir(parents=True, exist_ok=True)

        meta_file = project_path / "META.yaml"
        if not meta_file.exists():
            storage.write_yaml(
                f"{project_name}/META.yaml",
                {
                    "name": project_name,
                    "created": str(Path.cwd()),
                    "provider": resolved_provider,
                    "model": resolved_model,
                    "status": "initialized",
                },
            )

        git_manager = create_git_manager(project_path, auto_commit=True)
        git_manager.auto_commit_step(
            agent="cli",
            description=f"Initialize project {project_name}",
        )

        logger.info(f"✅ Project '{project_name}' created successfully")
        logger.info(f"   Location: {project_path}")
        logger.info(f"   Next: Run 'scribe outline {project_name}' to generate outline")

    except Exception as e:
        handle_cli_exception(logger, f"Failed to create project: {e}", e, debug=debug)


@cli.command()
@click.argument("project_name")
@click.pass_context
def outline(ctx: click.Context, project_name: str) -> None:
    """Generate novel outline for project."""
    debug = ctx.obj.get("debug", False)
    logger = logging.getLogger("scribe")

    try:
        logger.info(f"Generating outline for: {project_name}")

        storage_config = StorageConfig(base_path=".novels")
        storage = StorageFactory.create(storage_config)
        project_path = Path(storage_config.base_path) / project_name
        if not project_path.exists():
            logger.error(f"Project '{project_name}' not found")
            logger.info(f"Create it first with: scribe new {project_name}")
            sys.exit(1)

        meta = storage.read_yaml(f"{project_name}/META.yaml") or {}
        provider = str(meta.get("provider") or "").strip()
        model = str(meta.get("model") or "").strip()

        if not provider:
            provider = _detect_provider_from_setup()
        if provider and not model:
            model = _default_model_for_provider(provider)

        if not provider:
            provider = click.prompt(
                "No provider found in project/setup. Enter provider",
                type=click.Choice(sorted(PROVIDER_DEFAULT_MODELS.keys()), case_sensitive=False),
            )
            provider = str(provider).strip()

        if not model:
            model = click.prompt(
                f"No model found for provider '{provider}'. Enter model",
                default=_default_model_for_provider(provider),
                show_default=True,
            ).strip()

        if isinstance(meta, dict):
            updated_meta = dict(meta)
            updated_meta["provider"] = provider
            updated_meta["model"] = model
            storage.write_yaml(f"{project_name}/META.yaml", updated_meta)

        llm_config = LLMConfig(provider=provider, model=model)
        orchestrator = create_orchestrator(storage_config, llm_config)
        git_manager = create_git_manager(project_path, auto_commit=True)

        logger.info("Running outline generation workflow...")

        workflow_path = str(Path(__file__).parent / "workflows" / "outline_phase.yaml")
        context = orchestrator.execute_workflow(
            workflow_path=workflow_path,
            project_name=project_name,
        )

        git_manager.auto_commit_step(
            agent="outline_agent",
            description=f"Generate outline for {project_name}",
        )

        logger.info(f"✅ Outline generated successfully for '{project_name}'")
        logger.info(f"   Executed {len(context.history)} steps")

    except Exception as e:
        handle_cli_exception(logger, f"Failed to generate outline: {e}", e, debug=debug)


@cli.command()
@click.argument("project_name")
@click.option("--chapter", "-c", required=True, type=int, help="Chapter number to write")
@click.option("--provider", default="openai", help="LLM provider to use")
@click.pass_context
def write(ctx: click.Context, project_name: str, chapter: int, provider: str) -> None:
    """Write a specific chapter."""
    debug = ctx.obj.get("debug", False)
    logger = logging.getLogger("scribe")

    try:
        logger.info(f"Writing chapter {chapter} for: {project_name}")

        storage_config = StorageConfig(base_path=".novels")
        project_path = Path(storage_config.base_path) / project_name
        if not project_path.exists():
            logger.error(f"Project '{project_name}' not found")
            sys.exit(1)

        llm_config = LLMConfig(provider=provider)
        orchestrator = create_orchestrator(storage_config, llm_config)
        git_manager = create_git_manager(project_path, auto_commit=True)

        logger.info(f"Running chapter {chapter} writing workflow...")

        workflow_path = str(Path(__file__).parent / "workflows" / "writing_phase.yaml")
        context = orchestrator.execute_workflow(
            workflow_path=workflow_path,
            project_name=project_name,
            initial_context={"chapter": chapter},
        )

        git_manager.auto_commit_step(
            agent="writer_agent",
            description=f"Write chapter {chapter}",
        )

        logger.info(f"✅ Chapter {chapter} written successfully for '{project_name}'")
        logger.info(f"   Executed {len(context.history)} steps")

    except Exception as e:
        handle_cli_exception(logger, f"Failed to write chapter: {e}", e, debug=debug)


@cli.command()
@click.argument("project_name")
@click.option("--provider", default="openai", help="LLM provider to use")
@click.option("--chapters", "-n", type=int, help="Number of chapters to generate")
@click.pass_context
def auto(ctx: click.Context, project_name: str, provider: str, chapters: int | None) -> None:
    """Deprecated alias for `autonomous start`."""
    logger = logging.getLogger("scribe")
    logger.warning(
        "⚠️  `scribe auto` is deprecated and will be removed in a future release. "
        "Please use `scribe autonomous start`."
    )
    ctx.invoke(
        start_autonomous,
        project_name=project_name,
        start_phase="new_novel",
        end_phase="autonomous",
        human_in_loop=False,
        hybrid_mode=False,
        checkpoint_timeout=None,
        timeout_action="pause",
        max_chapters=chapters,
        provider=provider,
        resume=False,
        checkpoint_id=None,
        git_commit=False,
        project_dir=".novels",
        checkpoint_dir=".checkpoints",
    )


@cli.command()
@click.argument("project_name")
@click.pass_context
def status(ctx: click.Context, project_name: str) -> None:
    """Show project status."""
    logger = logging.getLogger("scribe")

    try:
        storage_config = StorageConfig(base_path=".novels")
        project_path = Path(storage_config.base_path) / project_name

        if not project_path.exists():
            logger.error(f"Project '{project_name}' not found")
            sys.exit(1)

        git_manager = create_git_manager(project_path, auto_commit=False)
        repo_status = git_manager.status()

        logger.info(f"Project: {project_name}")
        logger.info(f"Location: {project_path}")
        logger.info(f"Git Repository: {'Yes' if repo_status['is_repository'] else 'No'}")

        if repo_status["is_repository"]:
            logger.info(f"Current Branch: {repo_status['current_branch']}")
            logger.info(f"Current Commit: {repo_status['current_commit']}")

            if repo_status["has_changes"]:
                logger.info(f"Uncommitted Changes: {len(repo_status['changed_files'])} files")
            else:
                logger.info("Uncommitted Changes: None")

            tags = git_manager.get_tags()
            if tags:
                logger.info(f"Milestones: {', '.join(tag['name'] for tag in tags)}")

    except Exception as e:
        handle_cli_exception(logger, f"Failed to get status: {e}", e, debug=False)


@cli.command()
@click.pass_context
def help(ctx: click.Context) -> None:
    """Show help information."""
    click.echo(ctx.parent.get_help())


cli.add_command(agents)
cli.add_command(character)
cli.add_command(chat)
cli.add_command(workflows)
cli.add_command(run)
cli.add_command(autonomous)
cli.add_command(verify)
cli.add_command(drafts)
cli.add_command(paginate)
cli.add_command(cache)
cli.add_command(summary)
cli.add_command(memory)
cli.add_command(performance_cli)
cli.add_command(version_cmd)
cli.add_command(config)
cli.add_command(setup)
cli.add_command(logs)
cli.add_command(templates)
cli.add_command(template_create)
cli.add_command(proactive)
cli.add_command(checkpoint)
cli.add_command(export)
cli.add_command(review)
cli.add_command(qa)
cli.add_command(parallel_cli)
cli.add_command(project)


def main() -> int:
    """Main entry point for CLI with improved error handling."""
    try:
        cli(obj={}, standalone_mode=False)
        return 0
    except click.exceptions.UsageError as e:
        msg = e.format_message() if hasattr(e, "format_message") else str(e)
        click.echo(f"❌ Usage Error: {msg}", err=True)
        click.echo("\n💡 Run 'scribe help' to see available commands.", err=True)
        return 1
    except click.exceptions.ClickException as e:
        # Handle other Click exceptions
        e.show()
        return 1
    except KeyboardInterrupt:
        # Handle Ctrl+C gracefully
        click.echo("\n⚠️  Operation cancelled by user.", err=True)
        return 130
    except Exception as e:
        # Handle unexpected errors with a clean message
        click.echo(f"❌ Unexpected error: {str(e)}", err=True)

        import logging

        logger = logging.getLogger("scribe")
        logger.debug("Full traceback:", exc_info=True)

        click.echo("\n💡 Run with -v or -vv for more verbose output.", err=True)
        return 1


if __name__ == "__main__":
    sys.exit(main())
