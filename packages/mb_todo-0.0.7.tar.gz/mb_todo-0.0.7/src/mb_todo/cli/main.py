"""CLI app definition and initialization."""

from pathlib import Path
from typing import Annotated

import typer
from mm_clikit import CoreContext, TyperPlus, setup_logging

from mb_todo.cli.commands.add import add
from mb_todo.cli.commands.close import close
from mb_todo.cli.commands.delete import delete
from mb_todo.cli.commands.edit import edit
from mb_todo.cli.commands.list import list_
from mb_todo.cli.commands.project import project_app
from mb_todo.cli.commands.reopen import reopen
from mb_todo.cli.commands.show import show
from mb_todo.cli.output import Output
from mb_todo.config import Config
from mb_todo.core import Core

app = TyperPlus(package_name="mb-todo")


@app.callback()
def main(
    ctx: typer.Context,
    *,
    data_dir: Annotated[
        Path | None,
        typer.Option("--data-dir", help="Data directory. Env: MB_TODO_DATA_DIR."),
    ] = None,
) -> None:
    """CLI-first todo manager."""
    config = Config.build(data_dir)
    setup_logging("mb_todo", config.log_path)
    core = Core(config)
    ctx.call_on_close(core.close)
    ctx.obj = CoreContext(core=core, out=Output())


app.command(aliases=["a"])(add)
app.command(name="list", aliases=["l", "ls"])(list_)
app.command(aliases=["s"])(show)
app.command(aliases=["e"])(edit)
app.command(aliases=["c"])(close)
app.command(aliases=["r"])(reopen)
app.command(aliases=["rm"])(delete)
app.add_typer(project_app, name="project", aliases=["p"], help="Manage projects.")
