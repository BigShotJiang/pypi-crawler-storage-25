"""CLI entry point."""

from mb_todo.cli.main import app as app
