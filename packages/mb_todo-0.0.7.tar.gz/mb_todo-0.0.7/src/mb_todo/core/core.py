"""Composition root — holds config, database, and service layer."""

from mb_todo.config import Config
from mb_todo.core.db import Db
from mb_todo.core.service import Service


class Core:
    """Application composition root.

    Creates and owns all shared resources (database, services).
    Passed to CLI commands via ``CoreContext``.
    """

    def __init__(self, config: Config) -> None:  # noqa: D107
        self.config = config
        self.db = Db(config.db_path)
        self.service = Service(self.db, config)

    def close(self) -> None:
        """Release resources."""
        self.db.close()
