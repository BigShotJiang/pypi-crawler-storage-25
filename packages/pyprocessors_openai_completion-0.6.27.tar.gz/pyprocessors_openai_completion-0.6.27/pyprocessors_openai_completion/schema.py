from pydantic import BaseModel, Field, RootModel


class Span(BaseModel):
    end: int = Field(..., description="End index of the span in the text", examples=[15])


class SegmentV2(BaseModel):
    id: str = Field(None, description="Identifier of the segment")
    mentions: dict[str, list[str]] | None = Field(None, description="Mentions grouped by labels")


class NERV2(RootModel):
    root: list[SegmentV2]


class MentionV3(Span):
    label: str = Field(None, description="Label of the annotation", examples=["ORG"])
    text: str | None = Field(None, description="Covering text of the annotation", examples=["Kairntech"])
    offset: int = Field(..., description="Start index of the span in the text", examples=[5])


class SegmentV3(BaseModel):
    id: str = Field(None, description="Identifier of the segment")
    mentions: list[MentionV3] | None = Field(None, description="Mentions")


class NERV3(RootModel):
    root: list[SegmentV3]
