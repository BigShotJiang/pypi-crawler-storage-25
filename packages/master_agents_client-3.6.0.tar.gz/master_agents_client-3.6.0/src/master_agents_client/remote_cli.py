"""Remote CLI client — drives a home-server session from a workstation .

Three layers:
- `RemoteConfig` + `save_remote_config` / `load_remote_config`: YAML config at
  `~/.master_agents/remote.yaml`. chmod 0600 on POSIX at save time.
- `RemoteSessionClient`: httpx-based transport that runs a full turn, handling
  `needs_local_tool` SSE events by executing locally via `RemoteToolExecutor`
  and POSTing `/local_tool_result`.
- CLI `_cmd_remote`: wires `agents remote login/run/chat/logout` subcommands.
"""

from __future__ import annotations

import asyncio
import getpass
import json
import os
import sys
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, cast

import httpx
import yaml

from ._paths import master_agents_home
from .remote_client import DEFAULT_CLIENT_SIDE_TOOLS, RemoteToolExecutor
from .tools import BUILTINS
from .tracer import ConsoleTracer, Tracer


DEFAULT_REMOTE_CONFIG_PATH = master_agents_home() / "remote.yaml"
DEFAULT_ACTIVE_SESSION_PATH = master_agents_home() / "active_session.json"


def _save_active_session(
    *,
    server: str,
    agent_name: str,
    session_id: str,
    nonce: str,
    path: Path | str = DEFAULT_ACTIVE_SESSION_PATH,
) -> None:
    """Persist the just-detached session so the next agents remote chat
    invocation can offer to resume it. Stored as JSON under
    ~/.master_agents/active_session.json with chmod 0600 on POSIX."""
    from datetime import datetime, timezone

    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "server": server,
        "agent_name": agent_name,
        "session_id": session_id,
        "session_nonce": nonce,
        "detached_at": datetime.now(timezone.utc).isoformat(),
    }
    p.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    try:
        os.chmod(p, 0o600)
    except OSError:  # pragma: no cover
        pass


def _load_active_session(
    path: Path | str = DEFAULT_ACTIVE_SESSION_PATH,
) -> dict[str, Any] | None:
    """Read the cached active session, or None if no file exists or it's
    malformed. Returning None signals the chat REPL to start fresh."""
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def _clear_active_session(
    path: Path | str = DEFAULT_ACTIVE_SESSION_PATH,
) -> None:
    """Remove the cache. Called on /exit (full destroy) and after the
    user declines a resume offer (so the prompt doesn't loop)."""
    p = Path(path)
    if p.exists():
        try:
            p.unlink()
        except OSError:  # pragma: no cover
            pass


class SessionEndedError(Exception):
    """Server cancelled the session before our request could complete.

    Raised by `_consume_stream` when the server returns `410 Gone` on
    one of the SSE-streaming POST endpoints — `/turn`,
    `/local_tool_result`, or `/resume`. Server-side this response is
    correct (per `the service`: the pending request has been
    cancelled by F1 timeout, container restart, session_cancel, or
    ws-disconnect cleanup). Client-side, the legacy behaviour of
    propagating `httpx.HTTPStatusError` crashed the CLI with a Python
    traceback — operators saw "your client is broken" when actually
    the server was correctly reporting a session that had moved on.
    The CLI command handlers `_cmd_remote_run` (returns 1 + stderr
    `[Session ended]`) and `_cmd_remote_chat` (breaks the REPL loop
    with the same marker) catch this specifically.

    Distinct from `RuntimeError` (intentionally — see test
    `test_session_ended_error_is_not_runtime_error`) so the CLI
    handlers can catch this case ahead of generic `Exception` and
    exit cleanly instead of looping on the same error every turn.

    Scope note: `rehydrate()` does NOT route through this translation
    — it issues its own POST and surfaces 410 to the caller (which
    falls back to a fresh `open()`). Different recovery semantics:
    rehydrate's 410 means "the resume target is gone, start fresh,"
    not "your in-flight work is lost." If a future change unifies
    the two paths, lift the 410 translation up to a shared helper.

    Real incidents motivating this fix: tasks `bk2yynbp0` (F1 redeploy
    cancelled session `30f2c613`) and `bl9p2rii3` (routine container
    restart cancelled session `6babf136d286445ba6a6cd7b4a58f605`),
    both within one session 2026-05-07.
    """


@dataclass
class RemoteConfig:
    server: str
    token: str
    default_master: str | None = None
    cwd_mode: str = "auto"  # "auto" = os.getcwd() at invocation; "fixed" would pin
    writable_paths: list[str] = field(default_factory=lambda: ["."])


def save_remote_config(path: Path | str, cfg: RemoteConfig) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "server": cfg.server,
        "token": cfg.token,
        "default_master": cfg.default_master,
        "cwd_mode": cfg.cwd_mode,
        "writable_paths": list(cfg.writable_paths),
    }
    p.write_text(yaml.safe_dump(payload, sort_keys=True), encoding="utf-8")
    # POSIX: enforce user-only perms. Windows: best-effort (os.chmod partial).
    try:
        os.chmod(p, 0o600)
    except OSError:  # pragma: no cover
        pass
    if sys.platform == "win32":
        print(
            f"Note: on Windows, ensure only your user can read {p}. "
            "The CLI cannot enforce ACLs automatically.",
            file=sys.stderr,
        )


def load_remote_config(path: Path | str) -> RemoteConfig:
    # Single SoT for the bearer token: MASTER_AGENTS_API_TOKEN env var,
    # auto-loaded from vps/.env.production if present (same file the
    # home-server reads). Falls back to remote.yaml's `token` field for
    # legacy configs.
    from ._paths import load_platforms_env_files
    load_platforms_env_files()

    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(str(p))
    data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    token = os.environ.get("MASTER_AGENTS_API_TOKEN") or data.get("token", "")
    return RemoteConfig(
        server=data["server"],
        token=token,
        default_master=data.get("default_master"),
        cwd_mode=data.get("cwd_mode", "auto"),
        writable_paths=list(data.get("writable_paths", ["."])),
    )


# ── E41 (2026-05-13) — Live progress visibility for long-running ──
#    local tools. Tools that exceed _LONG_TOOL_VISIBILITY_THRESHOLD_S
#    get an in-place updating `⋯ <tool> — elapsed Xm Ys` line on
#    stderr. Pre-threshold short tools render nothing (no flicker for
#    sub-second `read_file` / `file_grep` etc.). Set the env var
#    MASTER_AGENTS_DISABLE_PROGRESS=1 to suppress entirely (CI, scripts,
#    pipes where \r is unwelcome).
_LONG_TOOL_VISIBILITY_THRESHOLD_S = 5.0
_PROGRESS_TICK_S = 1.0
_PROGRESS_DISABLE_ENV = "MASTER_AGENTS_DISABLE_PROGRESS"

# Inlined mirror of the server's per-tool TTL policy (defined in
# master_agents_client.managed_session, NOT in the client wheel). Kept in
# sync via the constants here — when the server policy changes, the
# tests in tests/test_e41_e42_progress_and_bg.py pin the values so
# divergence fails CI loudly. Used only for *displaying* the timeout
# on the progress line; the server is the authoritative enforcer.
_LONG_RUNNING_LOCAL_TOOLS_CLIENT = frozenset({
    "bash", "powershell", "python_run", "python_eval", "python_eval_sandboxed",
})
_DEFAULT_SHORT_TOOL_TIMEOUT_S = 120.0
_DEFAULT_LONG_TOOL_TIMEOUT_S = 14400.0  # 4h (E41 2026-05-13 bump)


def _compute_display_timeout_s(tool_name: str) -> float:
    """Client-side mirror of `_resolve_local_tool_timeout` for the
    progress-line display. Reads the same env vars as the server.
    Returns the wallclock ceiling in seconds. Display-only — the
    server still enforces the real cutoff."""
    is_long = tool_name in _LONG_RUNNING_LOCAL_TOOLS_CLIENT
    if is_long:
        raw = os.environ.get("MASTER_AGENTS_LONG_LOCAL_TOOL_TIMEOUT_S")
        if raw:
            try:
                return float(raw)
            except (ValueError, TypeError):
                pass
        raw_short = os.environ.get("MASTER_AGENTS_LOCAL_TOOL_TIMEOUT_S")
        if raw_short:
            try:
                return max(float(raw_short), _DEFAULT_LONG_TOOL_TIMEOUT_S)
            except (ValueError, TypeError):
                pass
        return _DEFAULT_LONG_TOOL_TIMEOUT_S
    raw = os.environ.get("MASTER_AGENTS_LOCAL_TOOL_TIMEOUT_S")
    if raw:
        try:
            return float(raw)
        except (ValueError, TypeError):
            pass
    return _DEFAULT_SHORT_TOOL_TIMEOUT_S


def _format_elapsed(seconds: float) -> str:
    """Render seconds as `Xm Ys` (or `Ys` if under a minute, or
    `Xh Ym` if over an hour). E.g. 12.4 → '12s', 75 → '1m 15s',
    7321 → '2h 2m'."""
    s = int(seconds)
    if s < 60:
        return f"{s}s"
    m, s = divmod(s, 60)
    if m < 60:
        return f"{m}m {s}s"
    h, m = divmod(m, 60)
    return f"{h}h {m}m"


def _summarise_tool_invocation(tool_name: str, tool_input: dict) -> str:
    """Short one-line `tool args` summary for the progress line.
    Picks the most distinctive arg per tool family (script for
    python_run, command for bash, etc.). Truncates to ~60 chars."""
    if not isinstance(tool_input, dict):
        return tool_name
    distinctive_arg: str | None = None
    if tool_name == "python_run":
        args = tool_input.get("args")
        if isinstance(args, list) and args:
            distinctive_arg = " ".join(str(a) for a in args[:3])
    elif tool_name in ("bash", "powershell"):
        cmd = tool_input.get("command") or tool_input.get("script")
        if isinstance(cmd, str):
            distinctive_arg = cmd.splitlines()[0] if cmd else ""
    elif tool_name in ("python_eval", "python_eval_sandboxed"):
        code = tool_input.get("code")
        if isinstance(code, str):
            distinctive_arg = code.splitlines()[0] if code else ""
    if distinctive_arg:
        if len(distinctive_arg) > 60:
            distinctive_arg = distinctive_arg[:57] + "..."
        return f"{tool_name} {distinctive_arg}"
    return tool_name


async def _execute_with_progress(
    executor: "RemoteToolExecutor",
    tool_name: str,
    tool_input: dict,
    *,
    out=None,
) -> tuple[Any, bool]:
    """Run executor.execute() with an in-place elapsed-time display
    on stderr (default) for tools that exceed the visibility threshold.

    E41 (2026-05-13): wraps the single use site at the SSE round-trip
    boundary so EVERY local tool call gets visibility without affecting
    the executor's API. Short tools render nothing (threshold-gated).
    Disable entirely with MASTER_AGENTS_DISABLE_PROGRESS=1.

    Returns the same `(result, is_error)` tuple as executor.execute.
    """
    if out is None:
        out = sys.stderr
    disabled = os.environ.get(_PROGRESS_DISABLE_ENV, "").lower() in (
        "1", "true", "yes",
    )
    # Non-TTY destinations (pipes / files) get no \r dance — the line
    # would just accumulate. Only render when the destination looks
    # interactive. CI logs stay clean.
    try:
        is_tty = bool(getattr(out, "isatty", lambda: False)())
    except Exception:
        is_tty = False
    if disabled or not is_tty:
        return await executor.execute(tool_name, tool_input)

    summary = _summarise_tool_invocation(tool_name, tool_input)
    timeout_s = _compute_display_timeout_s(tool_name)
    timeout_str = _format_elapsed(timeout_s)
    started = time.monotonic()
    line_rendered = False

    async def _ticker() -> None:
        nonlocal line_rendered
        # Wait until threshold before rendering anything — short tools
        # finish in well under threshold and need zero output.
        try:
            await asyncio.sleep(_LONG_TOOL_VISIBILITY_THRESHOLD_S)
        except asyncio.CancelledError:
            return
        while True:
            elapsed = time.monotonic() - started
            try:
                # Format mirrors Claude Code's `(52s · timeout 5m)`
                # ergonomic — operator sees both how long it's been
                # AND when the server will give up. Esc-to-cancel
                # hint matches the existing keybind at remote_cli.py
                # ~line 2241 (Esc submits /cancel).
                out.write(
                    f"\r⋯ {summary} — elapsed {_format_elapsed(elapsed)}"
                    f" · timeout {timeout_str} (Esc to cancel)\033[K"
                )
                out.flush()
                line_rendered = True
            except Exception:
                # Anything goes wrong with writing (closed stream,
                # encoding error) — just stop ticking; the underlying
                # execute() carries on regardless.
                return
            try:
                await asyncio.sleep(_PROGRESS_TICK_S)
            except asyncio.CancelledError:
                return

    ticker_task = asyncio.create_task(_ticker())
    try:
        result, is_error = await executor.execute(tool_name, tool_input)
        return result, is_error
    finally:
        ticker_task.cancel()
        try:
            await ticker_task
        except (asyncio.CancelledError, Exception):
            pass
        # Clear the progress line if anything was rendered. Use
        # `\r` + ANSI erase-to-end-of-line so any pending REPL
        # prompts paint cleanly on top.
        if line_rendered:
            try:
                out.write("\r\033[K")
                out.flush()
            except Exception:
                pass


# ── E42 (2026-05-13) — Background-exec for parallel agent runs ───
#    `/bg <agent> <prompt>` in `remote chat` spawns a parallel run
#    against another agent in its own session. Operator-level
#    parallelism: the foreground REPL stays responsive while the
#    background agent works. Tracked via /tasks slash commands.
#    Lifetime: chat session. For durable long-running work, use
#    `mao-client remote run --detach` in a separate terminal.
@dataclass
class _BgTask:
    """One parallel agent run kicked off from the foreground chat
    REPL via `/bg`. Lives in the chat session's `bg_tasks` dict.

    Status transitions: 'starting' → 'running' → ('completed' |
    'failed' | 'cancelled'). The asyncio task may still be alive
    in the 'starting' window (auth/open negotiation pending)."""
    task_id: str
    agent: str
    prompt: str
    started_at: float  # time.monotonic() for elapsed display
    started_wall: float  # time.time() for human-readable timestamps
    asyncio_task: Any = None  # asyncio.Task — set after create_task
    status: str = "starting"
    result: str | None = None
    error: str | None = None
    session_id: str | None = None


async def _run_bg_task(
    cfg: "RemoteConfig",
    agent: str,
    prompt: str,
    record: _BgTask,
) -> None:
    """Runner coroutine for a /bg task. Creates a sibling client
    with the same auth context, runs the agent once, captures the
    final answer (or error) into the shared _BgTask record. Status
    updates are observable via /tasks slash commands. Never raises
    — all failures land in record.error + status='failed' so the
    bg task can be inspected without crashing the REPL."""
    record.status = "running"
    try:
        client = RemoteSessionClient(
            base_url=cfg.server,
            token=cfg.token,
            cwd=Path(os.getcwd()),
            writable_paths=cfg.writable_paths,
        )
        # Track session_id once open. RemoteSessionClient.run() manages
        # its own session lifecycle, but we don't have a hook to grab
        # the id before it's destroyed. Set via attribute access if
        # the client exposes it after open.
        record.result = await client.run(agent, prompt)
        record.session_id = getattr(client, "_last_run_session_id", None)
        record.status = "completed"
    except asyncio.CancelledError:
        record.status = "cancelled"
        raise
    except Exception as exc:
        record.error = f"{type(exc).__name__}: {exc}"
        record.status = "failed"


def _parse_sse_chunk(chunk: bytes) -> tuple[str, dict] | None:
    text = chunk.decode("utf-8", errors="replace")
    if not text.startswith("event: "):
        return None
    parts = text.strip().split("\n", 1)
    if len(parts) != 2:
        return None
    event_line, data_line = parts
    event_name = event_line.split(": ", 1)[1]
    payload_text = data_line.split(": ", 1)[1] if data_line.startswith("data: ") else "{}"
    try:
        payload = json.loads(payload_text)
    except json.JSONDecodeError:
        payload = {}
    return event_name, payload


class RemoteSessionClient:
    """Drives a single session on a remote master_agents_os server.

    Handles the SSE + POST dance for tool-inversion without surfacing it to
    the caller: `await client.run(agent_name, prompt)` returns the final text.
    """

    def __init__(
        self,
        *,
        base_url: str,
        token: str | None,
        cwd: Path | str,
        writable_paths: list[str],
        transport: httpx.BaseTransport | httpx.AsyncBaseTransport | None = None,
        tracer: Tracer | None = None,
        heartbeat: bool = False,
        show_diffs: bool = False,
        diff_color: bool = True,
        on_needs_input: Any = None,
        on_needs_approval: Any = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.cwd = Path(cwd).resolve()
        self.writable_paths = list(writable_paths)
        self._transport = transport
        self._tracer = tracer
        # When True, _consume_stream prints a dim "▸ thinking…" line as soon
        # as the SSE POST is in flight, then ANSI-overwrites it the moment
        # the first real event arrives. Off by default so non-chat callers
        # (e.g. agents remote run, tests) don't get spurious stderr noise.
        self._heartbeat = heartbeat
        # Callbacks for the agent's `ask_user` and approval flows. When
        # the server emits a needs_input / needs_approval event mid-turn,
        # _drive_turn calls these to get the user's answer + posts back
        # via /sessions/{id}/resume. None means the client raises
        # RuntimeError on those events (the original behaviour, fine
        # for `agents remote run` which doesn't expect them).
        # Signatures:
        #   on_needs_input(question: str) -> str          # awaitable
        #   on_needs_approval(tool, preview) -> bool      # awaitable
        self._on_needs_input = on_needs_input
        self._on_needs_approval = on_needs_approval
        # Populated by `_consume_stream` from the server's `final` event so
        # callers (e.g. interactive chat) can print per-turn + cumulative
        # token totals after each turn.
        self.last_tokens: dict[str, Any] | None = None
        # Wallclock duration of the most recent turn() call, in seconds.
        # Set by turn() in a finally so it's populated even on error.
        # None until the first turn completes.
        self.last_turn_seconds: float | None = None
        # captured from the server's cost_band_summary trace event
        # (emitted at root agent turn-end when estimate_tokens fired).
        # Consumed by _print_remote_token_line to surface the tier
        # indicator under the answer. None when no estimate calls were
        # made in the turn.
        self.last_cost_summary: dict[str, Any] | None = None
        # last known cap snapshot from set_cap. Used by the chat
        # REPL's footer to render `cap: X / Y used` on every turn even
        # when the cap wasn't touched this turn. None when no cap has
        # been set in this session.
        self.last_cap: dict[str, Any] | None = None
        # Session lifecycle state for the long-lived chat mode (open/turn/
        # close). Stays None for one-shot run() callers, which manage their
        # own AsyncClient + session inside the call.
        self._http: httpx.AsyncClient | None = None
        self._session_id: str | None = None
        self._nonce: str | None = None
        self._executor = RemoteToolExecutor(
            cwd=self.cwd,
            writable_paths=self.writable_paths,
            tools={n: BUILTINS[n] for n in DEFAULT_CLIENT_SIDE_TOOLS if n in BUILTINS},
            show_diffs=show_diffs,
            diff_color=diff_color,
        )

    def _auth_headers(self, nonce: str | None = None) -> dict[str, str]:
        headers: dict[str, str] = {}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        if nonce:
            headers["X-Session-Nonce"] = nonce
        return headers

    async def run(
        self,
        agent_name: str,
        prompt: str,
        *,
        # Phase 1 will populate these from CLI flags. Defaults preserve
        # the original simple-positional contract — `client.run(agent,
        # prompt)` keeps working unchanged. Each kwarg maps 1:1 to the
        # equivalent chat slash command's POST endpoint:
        #   cap                       → POST /sessions/{id}/set_cap
        #   threshold_ask_user        → POST /sessions/{id}/set_budget
        #   threshold_max_steps       → POST /sessions/{id}/set_max_steps
        #   threshold_total_steps     → POST /sessions/{id}/set_total_steps
        #   threshold_turn_input      → POST /sessions/{id}/set_turn_input_ceiling
        #   threshold_auto_compact    → POST /sessions/{id}/set_compact_threshold
        #   model                     → POST /sessions/{id}/set_model
        # detach / resume_session_id control the open / close lifecycle
        # (mirror chat's `--resume`, `/detach`).
        cap: int | None = None,
        threshold_ask_user: int | None = None,
        threshold_max_steps: int | None = None,
        threshold_total_steps: int | None = None,
        threshold_turn_input: int | None = None,
        threshold_auto_compact: int | None = None,
        model: str | None = None,
        detach: bool = False,
        resume_session_id: str | None = None,
    ) -> str:
        """One-shot: open a session, run a single turn, tear down.

        Used by `agents remote run` and most tests. For the long-lived
        chat REPL, prefer `open()` → repeated `turn()` → `close()` so the
        server-side conversation history persists across prompts.

        Declares interactive=False because there is no REPL to answer
        ask_user — the runner gates that tool server-side and the
        agent must proceed with stated assumptions.

        All keyword-only args default to None / False / no-op so the
        simple positional call `client.run(agent, prompt)` keeps its
        original semantics. New flags arrive in Phase 1 of the
        consolidation branch.
        """
        if resume_session_id is not None:
            await self.open_resumed(resume_session_id)
        else:
            await self.open(agent_name, interactive=False)
        try:
            # Apply any session-control settings BEFORE the turn —
            # mirrors a chat operator typing slash commands before
            # their first prompt. Each helper is a no-op when its
            # arg is None.
            await self._apply_run_controls(
                cap=cap,
                threshold_ask_user=threshold_ask_user,
                threshold_max_steps=threshold_max_steps,
                threshold_total_steps=threshold_total_steps,
                threshold_turn_input=threshold_turn_input,
                threshold_auto_compact=threshold_auto_compact,
                model=model,
            )
            return await self.turn(prompt)
        finally:
            if not detach:
                await self.close()

    async def open_resumed(self, session_id: str) -> None:
        """Re-attach to an existing server-side session by id, instead
        of creating a new one. Mirror of chat's `--resume <id>` — the
        session's conversation history is preserved across the boundary.

        Thin wrapper over the existing `rehydrate()` method (which
        chat's --resume / --pick paths use) — keeps a single canonical
        re-attachment surface.
        """
        await self.rehydrate(session_id)

    async def _apply_run_controls(
        self,
        *,
        cap: int | None = None,
        threshold_ask_user: int | None = None,
        threshold_max_steps: int | None = None,
        threshold_total_steps: int | None = None,
        threshold_turn_input: int | None = None,
        threshold_auto_compact: int | None = None,
        model: str | None = None,
    ) -> None:
        """Apply the chat-slash-command-equivalent session controls.

        Each branch fires only when its kwarg is non-None — all-None
        invocation is a complete no-op (the simple-positional
        `client.run(agent, prompt)` path's default).

        Each call dispatches to an existing `POST /sessions/{id}/set_*`
        endpoint that chat operators already use via slash commands.
        No new server-side surface; pure leverage.
        """
        if cap is not None:
            await self.set_cap(cap)
        if threshold_ask_user is not None:
            await self.set_budget(threshold_ask_user)
        if threshold_max_steps is not None:
            await self.set_max_steps(threshold_max_steps)
        if threshold_total_steps is not None:
            await self.set_total_steps(threshold_total_steps)
        if threshold_turn_input is not None:
            await self.set_turn_input_ceiling(threshold_turn_input)
        if threshold_auto_compact is not None:
            await self.set_compact_threshold(threshold_auto_compact)
        if model is not None:
            await self.set_model(model)

    async def open(
        self,
        agent_name: str,
        *,
        interactive: bool = True,
    ) -> None:
        """Create a server-side session and keep it open across multiple
        turns. Persists `session_id` + `nonce` on the client so subsequent
        `turn()` calls reuse the same conversation history.

        `interactive` defaults True (chat REPL can answer ask_user).
        Set False from one-shot paths (run()) so the runner gates
        ask_user and the agent backs off with stated assumptions.

        Raises RuntimeError if already open — callers must `close()` first.
        """
        if self._http is not None:
            raise RuntimeError("client already open; call close() first")
        http = httpx.AsyncClient(
            transport=self._transport, base_url=self.base_url, timeout=None,
        )
        try:
            from .platform_info import detect_client_platform
            #  + 2026-05-07 cwd extension: machine-level platform
            # detection (os/shell/wsl_distro) PLUS session-level cwd.
            # Why cwd lives here, not in detect_client_platform(): the
            # detector's output is module-cached (machine doesn't
            # change mid-process); cwd is per-session (varies by where
            # the user invoked `agents remote run`). Keep the caches
            # separate. Real failure mode this fixes (P3 trace
            # `c641042702714d7fa5a2897a8ceb5104`): agent guessed
            # `/master_agents_os`, `/workspace`, `/home`; all failed;
            # tried ask_user (BLOCKED in non-interactive mode); gave
            # up with generic content. Surfacing cwd in the platform
            # block lets the agent grep with the right base on turn 1.
            platform_payload = dict(detect_client_platform())
            platform_payload["cwd"] = str(self.cwd)
            create = await http.post(
                "/sessions",
                json={
                    "agent_name": agent_name,
                    "remote_client_tools": sorted(DEFAULT_CLIENT_SIDE_TOOLS),
                    # tell the server which OS / shell / cwd the
                    # client is actually running in. Server injects this
                    # into the agent's system prompt so specialists pick
                    # the right command syntax + path base instead of
                    # guessing.
                    "client_platform": platform_payload,
                    # False = one-shot non-interactive (e.g.
                    # `agents remote run`); server's runner gates
                    # ask_user pre-dispatch.
                    "interactive": interactive,
                },
                headers=self._auth_headers(),
            )
            create.raise_for_status()
            body = create.json()
            self._session_id = body["session_id"]
            self._nonce = body["session_nonce"]
            self._http = http
        except Exception:
            await http.aclose()
            raise

    async def turn(self, prompt: str) -> str:
        """Drive one turn against the currently-open session.

        Records wallclock duration on `self.last_turn_seconds` so the
        chat REPL can show 'Time: 30s' alongside the token line.
        """
        import time

        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        # Reset the per-turn cost summary so the previous turn's tier
        # indicator doesn't bleed into a turn that didn't call
        # estimate_tokens. last_tokens self-replaces from `final.tokens`.
        self.last_cost_summary = None
        start = time.perf_counter()
        try:
            return await self._drive_turn(
                self._http, self._session_id, self._nonce, prompt,
            )
        finally:
            self.last_turn_seconds = time.perf_counter() - start

    async def reset(self) -> dict[str, Any]:
        """Clear the master agent's conversation history server-side.

        Returns the server's response, e.g. `{"status": "reset",
        "messages_cleared": 4}`.
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/reset",
            headers=self._auth_headers(self._nonce),
        )
        resp.raise_for_status()
        return resp.json()

    async def memory_list_curate(
        self,
        scope: str,
        qualifier: str = "",
        *,
        prefix: str = "",
        max_results: int = 200,
        created_by_agent: str | None = None,
    ) -> dict[str, Any]:
        """v3.2.0 — list memory keys for a scope/qualifier WITHOUT a
        session. Powers `mao-client memory list`. Returns
        `{scope, qualifier, total, keys: [{key, value_chars,
        updated_at, created_by_agent}]}`.

        Uses the bearer-token-only `/memory/list` endpoint (no session
        nonce required) so users can audit memory before opening any
        agent session.

        v3.3.1: `created_by_agent` (optional) filters the result set
        to entries saved while the named agent was the master. Powers
        the `/memory list by <agent>` slash command. None means no
        filter — return all entries.
        """
        if self.token is None:
            raise RuntimeError(
                "memory curation requires a configured token"
            )
        # Use a short-lived httpx client since curation may be called
        # without prior open() — no session, no _http set up.
        import httpx
        body: dict[str, Any] = {
            "scope": scope,
            "qualifier": qualifier,
            "prefix": prefix,
            "max_results": max_results,
        }
        if created_by_agent is not None:
            body["created_by_agent"] = created_by_agent
        async with httpx.AsyncClient(
            base_url=self.base_url, timeout=15.0,
        ) as http:
            resp = await http.post(
                "/memory/list",
                headers={"Authorization": f"Bearer {self.token}"},
                json=body,
            )
            resp.raise_for_status()
            return resp.json()

    async def memory_get_curate(
        self, scope: str, key: str, qualifier: str = "",
    ) -> dict[str, Any]:
        """v3.2.0 — fetch one memory entry's full value via the
        non-session `/memory/get` endpoint. Raises HTTPStatusError on
        404 (not-found) so the CLI can render a friendly error.
        Returns `{scope, qualifier, key, value, value_chars}`.
        """
        if self.token is None:
            raise RuntimeError("memory curation requires a configured token")
        import httpx
        async with httpx.AsyncClient(
            base_url=self.base_url, timeout=15.0,
        ) as http:
            resp = await http.post(
                "/memory/get",
                headers={"Authorization": f"Bearer {self.token}"},
                json={"scope": scope, "qualifier": qualifier, "key": key},
            )
            resp.raise_for_status()
            return resp.json()

    async def memory_delete_curate(
        self, scope: str, key: str, qualifier: str = "",
    ) -> dict[str, Any]:
        """v3.2.0 — delete one memory entry. Idempotent (missing key
        returns existed=false, not 404). Returns
        `{scope, qualifier, key, existed: bool}`.
        """
        if self.token is None:
            raise RuntimeError("memory curation requires a configured token")
        import httpx
        async with httpx.AsyncClient(
            base_url=self.base_url, timeout=15.0,
        ) as http:
            resp = await http.post(
                "/memory/delete",
                headers={"Authorization": f"Bearer {self.token}"},
                json={"scope": scope, "qualifier": qualifier, "key": key},
            )
            resp.raise_for_status()
            return resp.json()

    async def remember(
        self, text: str, *, key: str | None = None,
    ) -> dict[str, Any]:
        """v3.1.0 — save a fact to user-scope memory via the server's
        `/memory/remember` endpoint. Powers the `/remember <text>`
        slash command in the chat REPL.

        On the NEXT session start, the new fact appears in every
        agent's `<memory>` block auto-load (user-scope is cross-cutting).

        `key` is optional — if omitted the server generates a
        timestamp-based key (`note_<UTC-timestamp>`). When provided,
        must be 1-64 chars [A-Za-z0-9_-] only.

        Returns the server's response, e.g. `{"status": "remembered",
        "scope": "user", "key": "note_20260513T133542Z",
        "value_chars": 42}`.
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        body: dict[str, Any] = {"text": text}
        if key is not None:
            body["key"] = key
        resp = await self._http.post(
            f"/sessions/{self._session_id}/memory/remember",
            headers=self._auth_headers(self._nonce),
            json=body,
        )
        resp.raise_for_status()
        return resp.json()

    async def compact(self) -> dict[str, Any]:
        """Fold older messages into a summary server-side.

        Returns the server's response, e.g. `{"status": "compacted",
        "removed_messages": 6, "before_tokens": 12000, "after_tokens": 4500,
        "summary_tokens": 320}` or `{"status": "no_op", "removed_messages": 0}`
        if there was nothing to compact.
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/compact",
            headers=self._auth_headers(self._nonce),
        )
        resp.raise_for_status()
        return resp.json()

    async def resume(self, session_id: str, nonce: str) -> dict[str, Any]:
        """Adopt an existing server-side session without minting a new one.

        Used when a previous chat invocation called /detach and saved its
        session_id+nonce. We probe `GET /sessions/{id}/resume_state` to
        confirm the session is still alive (not idle-reaped); if it is,
        we re-use it and skip the POST /sessions cost. Returns the
        server's state snapshot on success.

        Raises RuntimeError if already open. Raises httpx.HTTPStatusError
        on 404 (session reaped — caller can fall back to rehydrate()).
        """
        if self._http is not None:
            raise RuntimeError("client already open; call close() first")
        http = httpx.AsyncClient(
            transport=self._transport, base_url=self.base_url, timeout=None,
        )
        try:
            check = await http.get(
                f"/sessions/{session_id}/resume_state",
                headers={**self._auth_headers(nonce)},
            )
            check.raise_for_status()
            self._session_id = session_id
            self._nonce = nonce
            self._http = http
            return check.json()
        except Exception:
            await http.aclose()
            raise

    async def rehydrate(self, old_session_id: str) -> dict[str, Any]:
        """Recreate a session from Postgres-persisted history when the
        original was idle-reaped. Returns a NEW session_id+nonce
        pre-loaded with the prior conversation buffer; the old id is
        retired.

        Server returns 503 if Postgres isn't configured, 404 if the row
        doesn't exist, 410 if the session was explicitly terminated.
        Client falls back to a fresh open() in those cases.
        """
        if self._http is not None:
            raise RuntimeError("client already open; call close() first")
        http = httpx.AsyncClient(
            transport=self._transport, base_url=self.base_url, timeout=None,
        )
        try:
            resp = await http.post(
                f"/sessions/{old_session_id}/rehydrate",
                headers=self._auth_headers(),
            )
            resp.raise_for_status()
            body = resp.json()
            self._session_id = body["session_id"]
            self._nonce = body["session_nonce"]
            self._http = http
            return body
        except Exception:
            await http.aclose()
            raise

    async def set_model(self, model: str) -> dict[str, Any]:
        """: override the master agent's model tier for this
        session. Accepts user-facing aliases: 'standard' / 'flash'
        for the standard tier, 'pro' for the pro tier. Backend
        provider is intentionally opaque on this API surface.
        Returns server's response: {status, alias, tier}."""
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/set_model",
            headers=self._auth_headers(self._nonce),
            json={"name": model},  # server's body field is `name`
        )
        resp.raise_for_status()
        return resp.json()

    async def get_thresholds(self) -> dict[str, Any]:
        """: introspect all current session thresholds in one
        round-trip. Returns the effective values for cap, budget,
        compact_threshold, plus context state (history_tokens,
        model_max, mandatory_floor, model_alias) and the
        allow_main_commits flag.

        Each value carries a `source` label (session / spec / default)
        so the user knows which layer is winning.
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.get(
            f"/sessions/{self._session_id}/thresholds",
            headers=self._auth_headers(self._nonce),
        )
        resp.raise_for_status()
        return resp.json()

    async def set_allow_main_commits(self, allowed: bool) -> dict[str, Any]:
        """: per-session override for the feat-branch-only commit
        guard. Default False (guard active). Returns
        {status, allow_main_commits}.
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/set_allow_main_commits",
            headers=self._auth_headers(self._nonce),
            json={"allowed": bool(allowed)},
        )
        resp.raise_for_status()
        return resp.json()

    async def set_compact_threshold(
        self, tokens: int | None,
    ) -> dict[str, Any]:
        """: per-session auto-compact threshold override. The
        mandatory 80% floor still applies as a safety net.
        Pass int (positive) to set; None to clear.
        Returns {status, compact_threshold}.
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/set_compact_threshold",
            headers=self._auth_headers(self._nonce),
            json={"tokens": tokens},
        )
        resp.raise_for_status()
        return resp.json()

    async def set_turn_input_ceiling(
        self, tokens: int | None,
    ) -> dict[str, Any]:
        """: per-session per-turn input-token ceiling override.
        Persists for every remaining turn of the session — set once,
        applies until reset. Default is unlimited; pass int (positive)
        to set a ceiling, None to clear.
        Returns {status, turn_input_ceiling}.
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/set_turn_input_ceiling",
            headers=self._auth_headers(self._nonce),
            json={"tokens": tokens},
        )
        resp.raise_for_status()
        return resp.json()

    async def list_agents(
        self, channel: str | None = None,
    ) -> dict[str, Any]:
        """ UAT — list available master agents on the server.

        Calls GET /agents (the existing endpoint that powers the
        --pick UI). When `channel` is provided, server filters the
        list to agents whose `channels` allowlist admits that
        channel. CLI sessions should pass channel='cli'.

        Returns {agents: [name], details: [{name, description,
        channels, model, ...}]}.
        """
        if self._http is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        params = {"channel": channel} if channel else {}
        # /agents uses auth_dep (token only), not nonce_dep, so the
        # session_nonce header is unnecessary — but `_auth_headers`
        # adds it harmlessly.
        resp = await self._http.get(
            "/agents",
            headers=self._auth_headers(self._nonce),
            params=params,
        )
        resp.raise_for_status()
        return resp.json()

    async def set_master(self, name: str) -> dict[str, Any]:
        """: switch the active master agent mid-session.

        The new master inherits the conversation history; a
        synthetic UserMessage marks the handoff so the LLM
        doesn't conflate prior tool calls (made under a
        different system prompt) with its own. Subsequent /turn
        calls run as the new master with the new spec's tools,
        system prompt, and per-turn caps.

        Returns {status, previous_master, new_master}. Raises
        httpx.HTTPStatusError(400) on validation failure (unknown
        agent, channel mismatch, attempting to switch to current).
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/set_master",
            headers=self._auth_headers(self._nonce),
            json={"name": name},
        )
        resp.raise_for_status()
        return resp.json()

    async def set_max_steps(
        self, steps: int | None,
    ) -> dict[str, Any]:
        """: per-session max_steps override. Persists for every
        remaining turn of the session. Default falls back to the
        spec's max_steps. Pass int (positive) to set, None to
        clear.
        Returns {status, max_steps}.
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/set_max_steps",
            headers=self._auth_headers(self._nonce),
            json={"steps": steps},
        )
        resp.raise_for_status()
        return resp.json()

    async def set_total_steps(
        self, steps: int | None,
    ) -> dict[str, Any]:
        """: per-session max_total_steps override. The
        session-cumulative step counter (across all turns + spawned
        subagents) hard-halts when it crosses this value. Pre-
        the only recovery from MaxTotalStepsExceeded was starting
        a new session — which re-paid the loaded codebase context.
        Persists for the lifetime of the session. Pass int
        (positive) to set, None to revert to the construction-time
        default (typically 100).
        Returns {status, total_steps}.
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/set_total_steps",
            headers=self._auth_headers(self._nonce),
            json={"steps": steps},
        )
        resp.raise_for_status()
        return resp.json()

    async def set_cap(self, tokens: int | None) -> dict[str, Any]:
        """: session-wide spend cap (cumulative input+output tokens).
        Pass int (positive) to set; None to remove. Returns server's
        response: {status, cap, used, remaining, halted}.

        Updates `self.last_cap` so the chat REPL's footer can render
        the cap line on every turn without re-querying the server.
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/set_cap",
            headers=self._auth_headers(self._nonce),
            json={"tokens": tokens},
        )
        resp.raise_for_status()
        info = resp.json()
        self.last_cap = info if info.get("cap") is not None else None
        return info

    async def set_budget(self, tokens: int | None) -> dict[str, Any]:
        """: override the  cost-gate threshold for this session.
        Pass an int (positive) to set tier_1 at that token count;
        pass None to clear and revert to spec/global default.

        Returns server's response: {status, budget, tier_2_at, tier_3_at}.
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/set_budget",
            headers=self._auth_headers(self._nonce),
            json={"tokens": tokens},
        )
        resp.raise_for_status()
        return resp.json()

    async def list_models(self) -> list[dict[str, Any]]:
        """: enumerate switchable model tiers for the /model
        command picker. Returns tier-named entries; backend provider
        names are not exposed on the API surface."""
        if self._http is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.get(
            "/models", headers=self._auth_headers(),
        )
        resp.raise_for_status()
        return list(resp.json().get("models", []))

    async def cancel(self) -> dict[str, Any]:
        """Cancel the currently-running turn server-side. The runner's
        next _check_cancelled() raises SessionCancelled and the in-flight
        turn aborts cleanly. Mid-flight tool calls cancel via the
        existing watchdog. Tools that are non-abortable run to
        completion (their results are then discarded).

        Used by `/cancel` slash command in the chat REPL.
        Returns the server's response, e.g. `{"status": "cancelled"}`.
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/cancel",
            headers=self._auth_headers(self._nonce),
        )
        resp.raise_for_status()
        return resp.json()

    async def detach(self) -> None:
        """Like close() but does NOT issue DELETE /sessions/{id}. The
        server-side session lives on its idle-reap timer (default ~30
        min); the Postgres row persists indefinitely. Used by the chat
        REPL's /detach command so the user can resume on the next
        invocation."""
        if self._http is not None:
            try:
                await self._http.aclose()
            finally:
                self._http = None
                self._session_id = None
                self._nonce = None

    @property
    def session_id(self) -> str | None:
        """Current server-side session_id, or None if not open."""
        return self._session_id

    @property
    def nonce(self) -> str | None:
        """Current session nonce, or None if not open."""
        return self._nonce

    async def close(self) -> None:
        """DELETE the server session and close the underlying HTTP client.
        Idempotent — safe to call when already closed or partially open.
        DELETE failures are swallowed so a flaky tunnel can't prevent
        local cleanup."""
        if self._http is None:
            return
        if self._session_id is not None and self._nonce is not None:
            try:
                await self._http.delete(
                    f"/sessions/{self._session_id}",
                    headers=self._auth_headers(self._nonce),
                )
            except Exception:  # pragma: no cover - best-effort cleanup
                pass
        try:
            await self._http.aclose()
        finally:
            self._http = None
            self._session_id = None
            self._nonce = None

    async def _drive_turn(
        self,
        http: httpx.AsyncClient,
        session_id: str,
        nonce: str,
        prompt: str,
    ) -> str:
        # Per-client-turn token accumulator. The server emits a `tokens`
        # block on every needs_local_tool event AND on the terminal final
        # event, but each one only covers a single server-side cycle. A
        # client turn that uses three local tools has four cycles, so we
        # sum here to give the user a true per-turn cost. (UAT defect #4.)
        accumulated_input = 0
        accumulated_output = 0
        latest_session_total = 0
        latest_history_tokens = 0
        latest_compact_savings = 0
        # model max context window + soft compact threshold +
        # vendor-abstracted model alias from the server's `final`
        # event payload. Used to render the ctx footer: `ctx: 65K /
        # 1M (compact at 100K) · model: standard`.
        latest_model_max_tokens = 0
        latest_soft_compact_threshold: int | None = None
        latest_model_alias: str | None = None

        def _accumulate(event: dict[str, Any]) -> None:
            nonlocal accumulated_input, accumulated_output
            nonlocal latest_session_total, latest_history_tokens, latest_compact_savings
            nonlocal latest_model_max_tokens, latest_soft_compact_threshold
            nonlocal latest_model_alias
            tokens = event.get("tokens") or {}
            accumulated_input += int(tokens.get("input", 0) or 0)
            accumulated_output += int(tokens.get("output", 0) or 0)
            if "session_total" in tokens:
                latest_session_total = int(tokens["session_total"] or 0)
            if "history_tokens" in tokens:
                latest_history_tokens = int(tokens["history_tokens"] or 0)
            if "compact_savings" in tokens:
                latest_compact_savings = int(tokens["compact_savings"] or 0)
            if "model_max_tokens" in tokens:
                latest_model_max_tokens = int(tokens["model_max_tokens"] or 0)
            if "soft_compact_threshold" in tokens:
                v = tokens["soft_compact_threshold"]
                latest_soft_compact_threshold = (
                    int(v) if v is not None else None
                )
            if "model_alias" in tokens:
                a = tokens["model_alias"]
                latest_model_alias = str(a) if a else None

        # Open the initial /turn SSE stream.
        final = await self._consume_stream(
            http, session_id, nonce,
            method="POST",
            path=f"/sessions/{session_id}/turn",
            json_body={"prompt": prompt},
        )
        _accumulate(final)
        while final["kind"] in ("needs_local_tool", "needs_input", "needs_approval"):
            kind = final["kind"]
            if kind == "needs_local_tool":
                # E41 (2026-05-13): wrap executor in elapsed-time progress
                # display so long-running python_run/bash/powershell calls
                # show in-place updating status on stderr instead of dead
                # air. Threshold-gated (≥5s); disabled on non-TTY and via
                # MASTER_AGENTS_DISABLE_PROGRESS=1.
                result, is_error = await _execute_with_progress(
                    self._executor, final["tool_name"], final["input"],
                )
                final = await self._consume_stream(
                    http, session_id, nonce,
                    method="POST",
                    path=f"/sessions/{session_id}/local_tool_result",
                    json_body={
                        "continuation_token": final["continuation_token"],
                        "result": result,
                        "is_error": is_error,
                    },
                )
            elif kind == "needs_input":
                # Agent called ask_user — surface the question to the
                # caller's input handler, post the answer back via
                # /resume. Without a callback, raise so the chat REPL
                # can recover instead of crashing the turn.
                if self._on_needs_input is None:
                    raise RuntimeError(
                        "agent called ask_user but no on_needs_input "
                        "callback is registered on the client"
                    )
                question = final.get("question", "")
                answer = await self._on_needs_input(question)
                final = await self._consume_stream(
                    http, session_id, nonce,
                    method="POST",
                    path=f"/sessions/{session_id}/resume",
                    json_body={
                        "continuation_token": final["continuation_token"],
                        "answer": answer,
                    },
                )
            elif kind == "needs_approval":
                if self._on_needs_approval is None:
                    raise RuntimeError(
                        "agent requested approval but no "
                        "on_needs_approval callback is registered"
                    )
                tool_name = final.get("tool_name", "?")
                preview_text = final.get("input_preview", "")
                approved = await self._on_needs_approval(
                    tool_name, preview_text,
                )
                final = await self._consume_stream(
                    http, session_id, nonce,
                    method="POST",
                    path=f"/sessions/{session_id}/resume",
                    json_body={
                        "continuation_token": final["continuation_token"],
                        "approved": bool(approved),
                    },
                )
            _accumulate(final)
        # Replace the per-stream snapshot in last_tokens (which only
        # reflects the LAST server-side cycle) with the accumulated
        # client-side turn totals. session_total / history_tokens /
        # compact_savings come from the last final event since they're
        # already cumulative on the server side.
        self.last_tokens = {
            "input": accumulated_input,
            "output": accumulated_output,
            "session_total": latest_session_total,
            "history_tokens": latest_history_tokens,
            "compact_savings": latest_compact_savings,
            # context-window meta + model alias for footer.
            "model_max_tokens": latest_model_max_tokens,
            "soft_compact_threshold": latest_soft_compact_threshold,
            "model_alias": latest_model_alias,
        }
        if final["kind"] == "final":
            return final["answer"]
        if final["kind"] == "error":
            raise RuntimeError(final.get("error", "remote session error"))
        raise RuntimeError(f"unexpected terminal event: {final}")

    async def _consume_stream(
        self,
        http: httpx.AsyncClient,
        session_id: str,
        nonce: str,
        *,
        method: str,
        path: str,
        json_body: dict[str, Any],
    ) -> dict[str, Any]:
        headers = self._auth_headers(nonce)
        # Heartbeat: print a dim "thinking…" the instant we open the stream,
        # then overwrite it the moment any real event (trace, final, error,
        # needs_*) arrives. Without this, on a no-tool prompt the user sees
        # nothing until `final` lands seconds later. CR + clear-line ANSI
        # makes the overwrite invisible on a working VT terminal.
        heartbeat_active = False
        if self._heartbeat:
            sys.stderr.write("\x1b[2m  ▸ thinking…\x1b[0m\r")
            sys.stderr.flush()
            heartbeat_active = True

        def _clear_heartbeat() -> None:
            nonlocal heartbeat_active
            if heartbeat_active:
                sys.stderr.write("\x1b[2K")
                sys.stderr.flush()
                heartbeat_active = False

        try:
            async with http.stream(method, path, json=json_body, headers=headers) as resp:
                # F2 follow-up (2026-05-07): translate 410 Gone on any
                # session endpoint into SessionEndedError so the CLI can
                # exit cleanly instead of crashing with an unhandled
                # HTTPStatusError. Server-side 410 means the pending
                # request was cancelled (F1 timeout, container restart,
                # explicit cancel) — that's ops-level, not a client bug,
                # so we surface it as a distinct exception class.
                if resp.status_code == 410:
                    _clear_heartbeat()
                    # Read the body for diagnostic detail without
                    # raising; aread() is safe on an already-streaming
                    # response and returns whatever the server sent.
                    try:
                        body = await resp.aread()
                        detail = body.decode("utf-8", errors="replace")[:200]
                    except Exception:
                        detail = ""
                    raise SessionEndedError(
                        f"session cancelled by server before request "
                        f"completed (410 Gone on {path}); "
                        f"server detail: {detail or '(none)'}"
                    )
                resp.raise_for_status()
                # SSE events are `\n\n`-delimited. A single TCP chunk can split a
                # frame, so buffer bytes across chunks and only parse completed
                # events. Without the buffer, any event that straddles a chunk
                # boundary is silently dropped.
                buffer = b""
                async for chunk in resp.aiter_raw():
                    if not chunk:
                        continue
                    buffer += chunk
                    while b"\n\n" in buffer:
                        block, buffer = buffer.split(b"\n\n", 1)
                        if not block.strip():
                            continue
                        parsed = _parse_sse_chunk(block + b"\n")
                        if not parsed:
                            continue
                        event_name, payload = parsed
                        if event_name == "trace":
                            _clear_heartbeat()
                            # / — capture cost summary so the chat
                            # REPL can render the tier indicator. Each
                            # Runner emits its own summary only when it
                            # called estimate_tokens; events fire in
                            # depth-DESCENDING order (deepest finishes
                            # first), so "last wins" naturally lands on
                            # the root's summary when the root estimated,
                            # and falls through to the deepest estimating
                            # agent otherwise. The common forced-routing
                            # case (assistant_cli → parallel_read_files,
                            # only the specialist estimates) is captured.
                            if (
                                isinstance(payload, dict)
                                and payload.get("type") == "cost_band_summary"
                            ):
                                self.last_cost_summary = dict(payload)
                            if self._tracer is not None:
                                try:
                                    self._tracer.emit(payload)
                                except Exception:  # pragma: no cover - defensive
                                    pass
                            continue
                        if event_name == "final":
                            _clear_heartbeat()
                            return {
                                "kind": "final",
                                "answer": payload.get("answer", ""),
                                "tokens": payload.get("tokens", {}),
                            }
                        if event_name == "error":
                            _clear_heartbeat()
                            return {"kind": "error", **payload}
                        if event_name == "needs_local_tool":
                            _clear_heartbeat()
                            return {
                                "kind": "needs_local_tool",
                                "tool_name": payload["tool_name"],
                                "input": payload.get("input", {}),
                                "continuation_token": payload["continuation_token"],
                                "tokens": payload.get("tokens", {}),
                            }
                        if event_name in ("needs_input", "needs_approval"):
                            _clear_heartbeat()
                            return {"kind": event_name, **payload}
        finally:
            _clear_heartbeat()
        raise RuntimeError("SSE stream closed without terminal event")


# ---- CLI wiring ----


def _cmd_remote(args) -> int:
    if args.remote_command == "login":
        return _cmd_remote_login(args)
    if args.remote_command == "logout":
        return _cmd_remote_logout(args)
    if args.remote_command == "run":
        return asyncio.run(_cmd_remote_run(args))
    if args.remote_command == "chat":
        return asyncio.run(_cmd_remote_chat(args))
    return 2


def _config_path(args) -> Path:
    return Path(args.config) if args.config else DEFAULT_REMOTE_CONFIG_PATH


# ── Phase 1 — `mao-client remote run` flag helpers ─────────────────


_TOKEN_SUFFIXES: dict[str, int] = {"k": 1_000, "m": 1_000_000}


def parse_token_count(value: str) -> int:
    """Parse a human-friendly token count string into an int.

    Accepts:
      - plain integers: `100`, `100000`
      - underscore separators: `100_000`, `4_000_000`
      - k/M suffixes (case-insensitive): `100k`, `4M`, `1.5k`, `2.5M`

    Rejects everything else with ValueError so argparse surfaces a
    clean error instead of silently coercing.
    """
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"empty/invalid token count: {value!r}")
    s = value.strip().replace("_", "")
    multiplier = 1
    if s and s[-1].lower() in _TOKEN_SUFFIXES:
        multiplier = _TOKEN_SUFFIXES[s[-1].lower()]
        s = s[:-1]
    try:
        # Decimal multipliers like `1.5k` resolve to int via float math.
        n = float(s) * multiplier
    except ValueError as exc:
        raise ValueError(
            f"cannot parse token count {value!r}: not a number "
            f"(allowed suffixes: k, M; underscores OK)"
        ) from exc
    if n < 0:
        raise ValueError(f"token count must be non-negative; got {value!r}")
    return int(n)


def last_session_file_path(
    master: str, *, config_root: Path | None = None,
) -> Path:
    """Per-master file storing the last detached session id.

    Per-master scoping (one file per agent) prevents collisions when
    multiple chains run concurrently across different agents.

    Default config_root is `~/.master_agents/`. Tests pass a tmp_path
    to avoid touching the operator's real config.
    """
    root = (
        Path(config_root) if config_root is not None
        else Path.home() / ".master_agents"
    )
    safe_master = "".join(
        ch if (ch.isalnum() or ch in "-_") else "_" for ch in master
    )
    return root / f"last_session_{safe_master}.txt"


def write_last_session_id(
    master: str, session_id: str, *, config_root: Path | None = None,
) -> None:
    """Write `session_id` to the per-master last-session file. Creates
    parent directory if missing. Overwrites any prior id."""
    p = last_session_file_path(master, config_root=config_root)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(session_id.strip() + "\n", encoding="utf-8")


def read_last_session_id(
    master: str, *, config_root: Path | None = None,
) -> str | None:
    """Read the per-master last-session id. Returns None when the
    file is missing OR empty (operator hasn't detached anything for
    this master yet)."""
    p = last_session_file_path(master, config_root=config_root)
    if not p.exists():
        return None
    text = p.read_text(encoding="utf-8").strip()
    return text or None


# ── Item 2 — Mode-A deterministic post-processor (E5) ───────────────


# Plan-shaped agents subject to Mode-A detection. architect itself
# is excluded because it's the FIX for Mode-A (running it upstream
# is what we recommend), so its own output need not be PHASE 5
# shaped to avoid the warning.
_PLAN_SHAPED_AGENTS: frozenset[str] = frozenset({"code_planner"})

# Architect-blueprint section markers — when any appear in the brief,
# the user has already run architect upstream and pasted the
# blueprint as context. No warning needed.
_BLUEPRINT_MARKERS: tuple[str, ...] = (
    "## Architecture",
    "## Modules",
    "Phase 1 (thin end-to-end slice)",
    "Tradeoff that drove",
    "## Constraints",
    "## Modules / interfaces",
)

# Heuristic threshold for "thin brief". Briefs shorter than this AND
# without anchors are very likely Mode-A.
_THIN_BRIEF_CHARS: int = 500

# Compiled once: matches `path/to/file.ext:LINE` or `:LINE-LINE`.
#
# Requires AT LEAST ONE path separator (`/` or `\`) before the file
# extension. Without this constraint, the regex over-matched network
# endpoints like `db.host:5432` and URLs like `example.com:443`,
# silently suppressing the Mode-A warning when a thin brief mentioned
# any host:port. Both MAO and Claude code reviewers identified this
# independently in the consolidation review (2026-05-06). Test
# coverage in test_mode_a_postprocessor.py:
#   - test_host_port_does_not_count_as_citation
#   - test_url_with_port_does_not_count_as_citation
#   - test_real_file_path_citation_still_recognised
#
# Extension restricted to {1,5} chars after the dot — covers .py /
# .yaml / .json / .md / .toml / .pyi / .yml / .ts / .tsx / .rs /
# .go / .ipynb without false-matching arbitrary `name.attr:value`
# config-style refs.
import re as _re
_CITATION_RE = _re.compile(
    r"\b[\w\-]+(?:[/\\][\w\-./\\]+)+\.[a-zA-Z]\w{0,4}:\d+(?:-\d+)?\b"
)


def detect_mode_a_brief(prompt: str) -> bool:
    """Return True if the brief looks Mode-A (no architect upstream).

    Heuristic — must satisfy all of:
      - No `path/to/file.ext:LINE` citations, AND
      - No architect-blueprint section markers, AND
      - (length < threshold OR explicitly thin shape)

    Returns True on empty/None to be safe — empty briefs are the
    most Mode-A-shaped of all.
    """
    if not prompt:
        return True
    if any(marker in prompt for marker in _BLUEPRINT_MARKERS):
        return False
    if _CITATION_RE.search(prompt):
        return False
    # No citations, no blueprint markers — short OR long, the brief
    # is operating without explicit code anchors. Mode-A by
    # definition. Length only varies the *flavour* of Mode-A, not
    # the verdict; the threshold constant is kept for future
    # reporting (e.g. "very thin brief — also too short").
    return True


def detect_no_phase5_emitted(output: str | None) -> bool:
    """Return True if the agent's output does NOT show PHASE-5 markers.

    A successful PHASE 5 emission produces either:
      - a `# Plan:` heading, OR
      - a JSON handoff section (`## JSON handoff` or `sub_plans` literal)

    Anything else — exploration thoughts, soft-landing free text,
    empty — counts as did-not-reach-PHASE-5.
    """
    if not output:
        return True
    if "# Plan:" in output or "# Plan " in output:
        return False
    if "## JSON handoff" in output or "sub_plans" in output:
        return False
    return True


def should_emit_mode_a_warning(
    *, master: str, prompt: str, output: str | None,
) -> bool:
    """Strict AND of three conditions:
      - master is in the plan-shaped agent set
      - brief is Mode-A shaped (no architect upstream)
      - output didn't reach PHASE 5

    Conservative on purpose. False positives would train operators
    to ignore the warning; only fire when the diagnostic is high-
    confidence."""
    if master not in _PLAN_SHAPED_AGENTS:
        return False
    if not detect_mode_a_brief(prompt):
        return False
    if not detect_no_phase5_emitted(output):
        return False
    return True


def format_mode_a_warning(*, master: str = "code_planner") -> str:
    """The warning text emitted to stderr. Actionable: tells the
    operator what happened and exactly what to run instead."""
    return (
        f"⚠ Mode-A detected ({master} received a thin brief AND its "
        f"output didn't reach PHASE 5).\n"
        f"   Recommend running architect upstream first:\n"
        f"     mao-client remote run -m architect \"<your brief>\"\n"
        f"   Then feed the resulting blueprint to {master}."
    )


def _cmd_remote_login(args) -> int:
    token = args.token
    if token is None:
        if sys.stdin.isatty():
            token = getpass.getpass("Bearer token: ")
        else:
            print(
                "Error: --token required for non-interactive login.",
                file=sys.stderr,
            )
            return 2
    writable_paths = [p.strip() for p in args.writable_paths.split(",")] if args.writable_paths else ["."]
    cfg = RemoteConfig(
        server=args.server,
        token=token,
        default_master=args.default_master,
        cwd_mode="auto",
        writable_paths=writable_paths,
    )
    save_remote_config(_config_path(args), cfg)
    print(f"Logged in to {args.server}. Config: {_config_path(args)}")
    return 0


def _cmd_remote_logout(args) -> int:
    path = _config_path(args)
    if path.exists():
        path.unlink()
        print(f"Removed {path}")
    else:
        print(f"(no config at {path})")
    return 0


async def _resolve_master(cfg, args, *, interactive: bool) -> str | None:
    """Resolve which master agent to use, in priority order:
    1. --master/-m on the command line
    2. default_master in remote.yaml
    3. interactive picker against live `GET /agents` (chat only)
    4. error message listing the server's agents
    """
    chosen = args.master or cfg.default_master
    if chosen:
        return chosen

    # Fetch the live list so we can either prompt or print useful options.
    try:
        async with httpx.AsyncClient(base_url=cfg.server, timeout=10) as http:
            headers = {"Authorization": f"Bearer {cfg.token}"} if cfg.token else {}
            # `?channel=cli` so the picker hides office-only / web-only
            # agents (assistant_office, excel_modeler, pptx_modeler,
            # assistant_web). Channel-agnostic agents (no `channels`
            # field on the spec) are returned for any channel.
            resp = await http.get(
                "/agents", headers=headers, params={"channel": "cli"},
            )
            resp.raise_for_status()
            agents = resp.json().get("agents", [])
    except Exception as exc:
        print(
            f"Error: no master agent specified, and failed to fetch /agents "
            f"to suggest options: {type(exc).__name__}: {exc}",
            file=sys.stderr,
        )
        return None

    if not agents:
        print(
            "Error: no master agent specified and the server has none registered.",
            file=sys.stderr,
        )
        return None

    if interactive and sys.stdin.isatty():
        print("No master agent specified. Available agents on the server:")
        for i, name in enumerate(agents, 1):
            print(f"  [{i}] {name}")
        try:
            raw = input("Pick one by number or name (Enter for [1]): ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return None
        if not raw:
            return agents[0]
        if raw.isdigit():
            idx = int(raw) - 1
            if 0 <= idx < len(agents):
                return agents[idx]
            print(f"Error: pick must be between 1 and {len(agents)}.", file=sys.stderr)
            return None
        if raw in agents:
            return raw
        print(f"Error: {raw!r} is not in the server's agent list.", file=sys.stderr)
        return None

    print(
        "Error: no master agent specified. Pass --master / -m, or set "
        "default_master via `agents remote login --default-master <name>`.",
        file=sys.stderr,
    )
    print("Available agents on the server:", file=sys.stderr)
    for name in agents:
        print(f"  - {name}", file=sys.stderr)
    return None


def _build_headless_approval_callback(
    policy: str,
) -> Any | None:
    """Return an async on_needs_approval callback for headless dispatch.

    Maps `--approve-tool-calls` value to the callback `RemoteSessionClient`
    expects:
      - "ask"   → None (caller raises RuntimeError on needs_approval —
                  the original, backward-compatible behaviour).
      - "allow" → async fn returning True (auto-approve every event).
      - "deny"  → async fn returning False (auto-reject every event).

    Any other value falls back to "ask" with a stderr warning so a
    typo'd flag never silently flips the policy to "allow."
    """
    if policy == "allow":
        async def _allow(tool_name: str, preview_text: str) -> bool:
            # Stderr breadcrumb so an operator scanning logs can see
            # which tool calls were auto-approved. Preview text is
            # often a multi-line YAML block — truncate hard so a
            # screen of output doesn't drown the log.
            print(
                f"[remote run] auto-approving tool {tool_name!r} "
                f"(preview: {preview_text[:120]!r}...)",
                file=sys.stderr,
            )
            return True
        return _allow
    if policy == "deny":
        async def _deny(tool_name: str, preview_text: str) -> bool:
            print(
                f"[remote run] auto-denying tool {tool_name!r} "
                f"(preview: {preview_text[:120]!r}...)",
                file=sys.stderr,
            )
            return False
        return _deny
    if policy != "ask":
        # Defensive — argparse `choices=[...]` should make this
        # unreachable, but a misconfigured caller (e.g. a wrapper
        # script forwarding stale strings) shouldn't silently get
        # "allow." Fall through to "ask" with a warning.
        print(
            f"[remote run] unknown --approve-tool-calls value "
            f"{policy!r}; falling back to 'ask'.",
            file=sys.stderr,
        )
    return None


async def _cmd_remote_run(args) -> int:
    cfg = load_remote_config(_config_path(args))

    # headless approval policy. `mao-client remote run` is the
    # non-interactive entry point: when the agent emits a
    # `needs_approval` event mid-turn (tool-call requires explicit
    # approval per server policy), there is no human at a REPL to
    # answer. Pre- the dispatch crashed with
    # `RuntimeError: agent requested approval but no
    # on_needs_approval callback is registered`, taking the entire
    # answer down with it (UAT-B 2026-05-11 incident: 15 sim_builder
    # dispatches blocked at this gate).
    #
    # `--approve-tool-calls {ask,allow,deny}` lets the caller pick the
    # policy explicitly:
    #   - ask   (default, backward-compatible): no callback → raise.
    #   - allow: auto-approve every needs_approval event.
    #   - deny:  auto-reject every needs_approval event.
    # The server's tier-key writable_paths + tool inventory are still
    # the security boundary — this flag only decides what the *client*
    # answers when the server asks. Callers who pick `allow` should
    # have already reviewed the agent's tool surface.
    approval_policy = getattr(args, "approve_tool_calls", "ask")
    on_needs_approval = _build_headless_approval_callback(approval_policy)

    client = RemoteSessionClient(
        base_url=cfg.server,
        token=cfg.token,
        cwd=Path(os.getcwd()),
        writable_paths=cfg.writable_paths,
        on_needs_approval=on_needs_approval,
    )
    master = await _resolve_master(cfg, args, interactive=False)
    if not master:
        return 2

    # Resolve --resume / --resume-last → concrete session_id (or None).
    resume_session_id = getattr(args, "resume", None)
    if not resume_session_id and getattr(args, "resume_last", False):
        resume_session_id = read_last_session_id(master)
        if resume_session_id is None:
            print(
                f"--resume-last: no detached session found for master "
                f"{master!r}. Run with --detach first.",
                file=sys.stderr,
            )
            return 2

    detach = getattr(args, "detach", False)

    try:
        result = await client.run(
            master,
            args.prompt,
            cap=getattr(args, "cap", None),
            threshold_ask_user=getattr(args, "threshold_ask_user", None),
            threshold_max_steps=getattr(args, "threshold_max_steps", None),
            threshold_total_steps=getattr(args, "threshold_total_steps", None),
            threshold_turn_input=getattr(args, "threshold_turn_input", None),
            threshold_auto_compact=getattr(args, "threshold_auto_compact", None),
            model=getattr(args, "model", None),
            detach=detach,
            resume_session_id=resume_session_id,
        )
    except SessionEndedError as exc:
        # Server cancelled mid-flight (F1 timeout, container restart,
        # explicit cancel). NOT a client bug — exit cleanly with a
        # one-line message instead of a Python traceback that confuses
        # operators. Exit code 1 still signals "this dispatch did not
        # complete" so scripts can detect it; just no stack noise.
        #
        # E39 (2026-05-13): surface the session_id + resume hints. The
        # session is fully recoverable from Postgres via the rehydrate
        # endpoint, but the user has to know its id. Auto-arm BOTH
        # storage paths so `--resume <id>` AND `--resume-last` work
        # after abnormal end (the explicit-detach branch only writes
        # both, so the recovery surfaces match).
        session_id = client.session_id
        nonce = client.nonce
        if session_id and nonce:
            _save_active_session(
                server=cfg.server,
                agent_name=master,
                session_id=session_id,
                nonce=nonce,
            )
            write_last_session_id(master, session_id)
            print(
                f"[Session ended] {exc}\n"
                f"  session_id={session_id}\n"
                f"  Resume with: agents remote chat --resume {session_id}\n"
                f"  Or:          agents remote chat --resume-last",
                file=sys.stderr,
            )
        else:
            # Session never reached server (auth fail, network 500
            # pre-create, etc.). No id to surface; no resume possible.
            print(f"[Session ended] {exc}", file=sys.stderr)
        return 1
    print(result)

    # Item 2 — Mode-A post-processor (E5). Deterministic warning
    # on stderr when a plan-shaped agent received a Mode-A brief
    # AND failed to reach PHASE 5. Independent of agent prompt
    # behaviour; fires regardless of where the agent terminated.
    if should_emit_mode_a_warning(
        master=master, prompt=args.prompt, output=result,
    ):
        print(format_mode_a_warning(master=master), file=sys.stderr)

    # Lifecycle footer on stderr — keeps stdout clean for piping.
    session_id = getattr(client, "_session_id", None)
    if detach and session_id:
        write_last_session_id(master, session_id)
        print(
            f"[Session detached] session_id={session_id} "
            f"— resume with --resume {session_id} (or --resume-last)",
            file=sys.stderr,
        )
    else:
        print("[Session closed]", file=sys.stderr)
    return 0


# preserve typed buffer on Esc (closes A22).
#
# Pre-: hitting Esc with text in the prompt buffer silently
# wiped the buffer (the eager Esc binding submitted "/cancel" and
# prompt_toolkit cleared the buffer on exit). Real-impact failure
# mode for users typing /threshold... commands and bumping Esc
# mid-type — every keystroke gone.
#
#  saves the buffer to a module-level draft slot when Esc fires
# with non-empty text, and adds a /draft slash command that recalls
# the most-recent draft into the next prompt. The Esc cancel
# behaviour itself is preserved (still submits /cancel), so the
# kill-the-running-turn affordance is unchanged.
#
# Two slots:
#   _draft_slot        — text saved by Esc, consumed by /draft.
#   _pending_default_slot — text /draft loaded for the next prompt
#                            session.prompt_async(default=...) call.
_draft_slot: dict[str, str | None] = {"text": None}
_pending_default_slot: dict[str, str | None] = {"text": None}


def _save_draft(text: str) -> None:
    """Save `text` to the draft slot if non-empty.  — called by
    the Esc binding before exiting the prompt with /cancel, so the
    user's typed-but-not-submitted buffer survives the cancel."""
    if text:
        _draft_slot["text"] = text


def _recall_draft() -> str | None:
    """Pop the saved draft (or None if no draft saved). Single-use:
    a second call returns None unless another save happened in
    between."""
    text = _draft_slot.get("text")
    _draft_slot["text"] = None
    return text


def _has_draft() -> bool:
    """Check whether a draft is currently saved without consuming
    it. Used by the /cancel handler's notice line."""
    return _draft_slot.get("text") is not None


def _set_pending_prompt_default(text: str) -> None:
    """Set the default text the NEXT prompt read should be
    pre-populated with. Used by /draft to recall a saved draft into
    the next prompt session.prompt_async() call."""
    _pending_default_slot["text"] = text


def _take_pending_prompt_default() -> str:
    """Pop the pending prompt default. Returns "" when nothing
    pending. Single-use: subsequent calls return "" until another
    set call runs."""
    text = _pending_default_slot.get("text") or ""
    _pending_default_slot["text"] = None
    return text


_REMOTE_CHAT_HELP = (
    "Commands:\n"
    "  /exit, /quit          Leave the chat AND destroy the server "
    "session (history is gone).\n"
    "  /detach               Leave the chat but KEEP the session alive. "
    "Next run offers to resume.\n"
    "  /cancel, /stop        Cancel the currently-running turn (works "
    "while the agent is busy).\n"
    "  /help                 Show this message.\n"
    "  /capabilities         Show the current agent's tools + "
    "delegation map (no LLM cost).\n"
    "  /model [standard|pro] Switch the agent's reasoning tier for "
    "this session. No arg = list available.\n"
    "  /threshold-ask-user [N | reset]   Per-turn cost-gate budget. "
    "tier_1 ≤budget (silent); tier_2 (budget..2×) requires ask_user; "
    "tier_3 (>2×) auto-rejected. Default 100K. Alias: /budget.\n"
    "  /threshold-auto-compact [N | reset]  Auto-compact trigger. "
    "Folds older turns into a summary when master's history exceeds N. "
    "Mandatory 80%-of-context-window floor still applies as safety net.\n"
    "  /threshold-turn-input [N | reset]  Per-turn input-token ceiling. "
    "Default UNLIMITED — set N to halt the runner mid-turn when input "
    "tokens within a single turn exceed N (forces the agent to "
    "consolidate). Persists for every remaining turn of this session.\n"
    "  /threshold-max-steps [N | reset]  Per-turn max_steps loop bound. "
    "Default = spec.max_steps (varies per agent). Override raises (or "
    "lowers) how many LLM round-trips a single turn can fire before "
    "soft-landing. Persists for every remaining turn of this session.\n"
    "  /threshold-total-steps [N | reset]  Session-cumulative step "
    "counter (all turns + all spawned subagents). Default 100. "
    "Override raises the ceiling for long autonomous runs — pre- "
    "the only recovery from a hit was starting a new session.\n"
    "  /cap [N | +N | reset] Session-wide spend cap (cumulative input"
    "+output tokens). Halts execution when crossed; /clear and /compact "
    "preserve the cumulative counter. `+N` adds N to current usage.\n"
    "  /allow-main-commits [on | off]  Override feat-branch-only "
    "commit guard . Default off (guard active — commits to "
    "main/master refused). Use only for emergency hotfixes.\n"
    "  /remember <text>      v3.1.0 — save a fact to user-scope memory. "
    "Auto-loads into every agent's <memory> block from the NEXT session "
    "start. Use `key=text` form to set an explicit key.\n"
    "  /memory               v3.3.0 — audit + curate saved memory: "
    "`/memory` lists user-scope keys + datetimes; `/memory list agent` "
    "for this agent's scope; `/memory get <key>` / `/memory delete <key>` "
    "for single-key ops. Type `/memory help` for full subcommand list.\n"
    "  /clear, /reset        Clear conversation history (start fresh, "
    "same session).\n"
    "  /compact              Fold older messages into a summary to "
    "reclaim context budget.\n"
    "  /draft                Recall the most recent Esc-saved draft "
    "into the next prompt.  — Esc with typed text saves the "
    "buffer instead of silently dropping it.\n"
    "  /agent <name|N>       Switch the active master agent "
    "mid-session . Conversation history carries forward; a "
    "synthetic handoff message is inserted so the new agent treats "
    "prior context as background. Validates target is in the "
    "registry, drivable, and admits this session's channel. Accepts "
    "either the long name (e.g. `/agent code_reviewer`) or the "
    "[N] number from the /agents listing (e.g. `/agent 3`) as a "
    "typing shortcut .\n"
    "  /agents               List available master agents on "
    "this server (filtered by this session's channel) with [N] "
    "shortcuts. Use the names or numbers with /agent.\n"
    "\n"
    "Background work:\n"
    "  Type ANY input while the agent is busy — it queues automatically.\n"
    "  Queued messages dispatch in order after the current turn finishes.\n"
    "\n"
    "Input keys:\n"
    "  Enter                 Submit the prompt.\n"
    "  Esc                   Cancel the currently-running turn "
    "(quick interrupt — same as /cancel).\n"
    "  Ctrl+J                Insert a newline (universal — works on "
    "any terminal).\n"
    "  \\ + Enter             Backslash continuation — drops the "
    "trailing \\ and inserts a newline (universal, no protocol).\n"
    "  (Shift+Enter)  Not enabled by default —  disabled "
    "the kitty keyboard protocol enable that made it work natively, "
    "because unmapped functional keys leaked as phantom Esc presses.\n"
    "  Paste                 Multi-line paste lands as a single prompt "
    "(bracketed paste).\n"
    "  ↑ / ↓                 Recall earlier prompts in this session.\n"
    "  /                     Show slash-command popup."
)


def _make_prompt_reader():
    """Build an async callable that reads one user input line.

    Returns a coroutine function so the caller awaits it from inside the
    asyncio.run-driven chat loop. We can't use prompt_toolkit's sync
    `prompt()` here because it internally spawns its own asyncio.run(),
    which raises "asyncio.run() cannot be called from a running event
    loop" when nested. `prompt_async()` cooperates with the existing
    loop instead.

    Tries prompt_toolkit first (bracketed-paste so multi-line pastes
    don't truncate at the first newline, plus arrow-key history). Falls
    back to running plain input() in a worker thread when prompt_toolkit
    isn't available or can't attach to the terminal.

    When the fallback fires, writes a one-line diagnostic to stderr so
    the user knows WHY rich features are absent — silent fallback was
    making "blue input doesn't work, Shift+Enter doesn't work" look like
    code bugs when they were really an environment issue.
    """
    def _fallback_reader(reason: str):
        sys.stderr.write(f"(rich input disabled: {reason})\n")
        sys.stderr.flush()

        async def _read(prompt: str) -> str:
            return await asyncio.to_thread(input, prompt)

        return _read

    try:
        from prompt_toolkit import PromptSession
        from prompt_toolkit.completion import Completer, Completion
        from prompt_toolkit.history import FileHistory, InMemoryHistory
        from prompt_toolkit.input.ansi_escape_sequences import ANSI_SEQUENCES
        from prompt_toolkit.key_binding import KeyBindings
        from prompt_toolkit.keys import Keys
        from prompt_toolkit.styles import Style
    except ImportError as exc:
        return _fallback_reader(
            f"prompt_toolkit not installed — {exc}. "
            "Install with `pip install prompt_toolkit` for blue prompt "
            "+ multi-line paste + Shift+Enter."
        )

    # Teach prompt_toolkit's vt100 parser the kitty-keyboard CSI-u
    # encodings used when the terminal is in "disambiguate escape
    # codes" mode (which we enable below via `\x1b[>1u`). Without
    # these mappings, the parser hits the leading `\x1b` and falls
    # through, so each disambiguated key leaks its literal CSI bytes
    # into the user's input — pressing Esc would paste "[27u",
    # pressing Ctrl+C would paste "[99;5u", etc.
    #
    # prompt_toolkit ships only 4 CSI-u entries (just enough for
    # Ctrl+`5` and friends). We round out the table for every key
    # that kitty level 1 disambiguates and that we (or prompt_toolkit
    # itself) bind: plain Esc/Tab/Backspace/Enter, Shift+Tab,
    # modifier+Esc, all Ctrl+letter, plus the modifier+Enter chords
    # we use for newline insertion.
    #
    # ANSI_SEQUENCES is a plain dict; setdefault keeps any future
    # prompt_toolkit-shipped mappings authoritative.
    _CSI_U_MAPPINGS: dict[str, "Keys"] = {
        # --- Modifier+Enter → newline (the original feature) ---
        "\x1b[13;2u": Keys.ControlJ,   # Shift+Enter
        "\x1b[13;3u": Keys.ControlJ,   # Alt+Enter
        "\x1b[13;5u": Keys.ControlJ,   # Ctrl+Enter
        "\x1b[13;6u": Keys.ControlJ,   # Ctrl+Shift+Enter
        # --- Legacy Alt+Enter (Esc+CR/LF) on terminals without
        # kitty protocol — preserves the chord on the broad set of
        # terminals where eager Esc would otherwise eat the prefix.
        "\x1b\r": Keys.ControlJ,
        "\x1b\n": Keys.ControlJ,
        # --- Plain unmodified disambiguated keys ---
        "\x1b[27u": Keys.Escape,       # Plain Esc — the bug fix
        "\x1b[9u": Keys.Tab,           # Plain Tab (some terminals)
        "\x1b[127u": Keys.Backspace,   # Plain Backspace
        "\x1b[13u": Keys.ControlM,     # Plain Enter (rarely disambiguated;
                                       # ControlM == Enter for binding purposes)
        # --- Shift+Tab ---
        "\x1b[9;2u": Keys.BackTab,
        # --- Modifier+Esc → treat all as plain Esc; nobody binds
        # these specifically and we want /cancel to fire regardless.
        "\x1b[27;2u": Keys.Escape,     # Shift+Esc
        "\x1b[27;3u": Keys.Escape,     # Alt+Esc
        "\x1b[27;5u": Keys.Escape,     # Ctrl+Esc
        "\x1b[27;6u": Keys.Escape,     # Ctrl+Shift+Esc
    }
    # Ctrl+letter (a-z) → corresponding Keys.Control[A-Z]. Critical
    # entries: Ctrl+C (raises KeyboardInterrupt → exits prompt),
    # Ctrl+D (EOF), Ctrl+J (newline — same handler as Shift+Enter).
    # Without these, kitty mode breaks every single Ctrl+letter
    # shortcut that prompt_toolkit relies on.
    import string
    for _letter in string.ascii_lowercase:
        _keycode = ord(_letter)  # 97-122
        _ctrl_key = getattr(Keys, f"Control{_letter.upper()}")
        _CSI_U_MAPPINGS[f"\x1b[{_keycode};5u"] = _ctrl_key

    for _seq, _key in _CSI_U_MAPPINGS.items():
        ANSI_SEQUENCES.setdefault(_seq, _key)

    try:
        kb = KeyBindings()

        @kb.add("enter")
        def _accept(event):
            """Plain Enter submits the buffer (Slack/Discord convention).

            Backslash continuation: if the buffer ends with `\\` and
            the cursor is at the end, strip the trailing backslash
            and insert a newline instead of submitting. Mirrors the
            bash / Python REPL / Claude Code pattern — universal
            multi-line entry chord that needs no terminal protocol
            and works in every shell. Complements Ctrl+J and the
            kitty-protocol Shift+Enter mapped above.

            E46.1 (2026-05-13): MUST call `buf.append_to_history()`
            before `app.exit(result=text)` — bypassing
            prompt_toolkit's standard `validate_and_handle()` flow
            (which is what we do by calling exit directly) ALSO
            bypasses the auto-history-append step. Without this
            line, every submitted prompt is dropped on the floor
            instead of landing in FileHistory → Up arrow has
            nothing to recall, no matter how many prompts the user
            sent. User-reported regression caught 2026-05-13."""
            buf = event.current_buffer
            text = buf.text
            if text.endswith("\\") and buf.cursor_position == len(text):
                buf.delete_before_cursor(1)
                buf.insert_text("\n")
                return
            if text.strip():
                # Only persist non-empty submissions — bare Enter
                # would otherwise litter the FileHistory file with
                # empty lines that pollute Up-arrow recall.
                buf.append_to_history()
            event.app.exit(result=text)

        @kb.add("c-j")
        def _ctrl_j_newline(event):
            """Ctrl+J inserts a newline mid-prompt. Universal: every
            terminal sends Ctrl+J distinctly from Enter so this works
            on Windows Terminal, iTerm2, VS Code's integrated
            terminal, cmd.exe, etc.

            Shift+Enter, Alt+Enter, and Ctrl+Enter all funnel here too
            via the ANSI_SEQUENCES extension above (kitty keyboard
            protocol on capable terminals; bare Esc+CR fallback for
            Alt+Enter on the rest)."""
            event.current_buffer.insert_text("\n")

        # E46 (2026-05-13, refined 2026-05-13) — bash/readline-style
        # history recall in multiline mode. multiline=True (used so
        # Shift+Enter / Ctrl+J insert newlines) rebinds Up/Down to
        # cursor-up/cursor-down by default. That kills the standard
        # shell ergonomic of "Up arrow = last message."
        #
        # v1 (manual cursor_position_row check) didn't fire reliably —
        # the user reported Up still doesn't recall in interactive use.
        # v2 uses prompt_toolkit's `auto_up` / `auto_down` primitives
        # which encapsulate the routing logic robustly (handles wrapped
        # lines, completion menu state, history-search mode etc.) AND
        # also bind `c-p` / `c-n` (Ctrl+P / Ctrl+N) as guaranteed-not-
        # cursor-movement history alternatives — these are universal
        # readline shortcuts and have no multiline-cursor conflict.
        @kb.add("up")
        def _history_up(event):
            event.current_buffer.auto_up(
                count=event.arg,
                go_to_start_of_line_if_history_changes=True,
            )

        @kb.add("down")
        def _history_down(event):
            event.current_buffer.auto_down(
                count=event.arg,
                go_to_start_of_line_if_history_changes=True,
            )

        @kb.add("c-p")
        def _history_prev(event):
            """Ctrl+P — explicit previous-history, never cursor-up.
            Universal readline binding; works regardless of buffer
            state. Use this when Up is ambiguous (mid-buffer)."""
            event.current_buffer.history_backward(count=event.arg)

        @kb.add("c-n")
        def _history_next(event):
            """Ctrl+N — explicit next-history, never cursor-down."""
            event.current_buffer.history_forward(count=event.arg)

        @kb.add("escape", eager=True)
        def _esc_cancel(event):
            """Esc immediately submits `/cancel` — quick interrupt of
            a running turn (Claude-Code-style). The producer's slash-
            handler picks up `/cancel`, posts to /sessions/{id}/cancel,
            agent halts at the next step boundary.

             — before exit, save the typed-but-unsubmitted buffer
            to the module-level draft slot so /draft can recall it.
            Pre- the buffer was silently wiped on Esc, costing
            users any in-progress text. The cancel intent is
            preserved (we still exit with /cancel); the draft is a
            zero-cost addition.

            If no turn is running, the producer prints a soft '(no turn
            running to cancel)' notice and the prompt re-opens; user
            keeps typing.

            `eager=True` makes Esc fire immediately on press without
            waiting for follow-up key disambiguation at the binding
            layer. Esc-Enter (Alt+Enter) is preserved by registering
            `` directly in ANSI_SEQUENCES → Keys.ControlJ at
            the parser layer (above), so the parser emits ControlJ
            for the full two-byte sequence and never emits a bare
            Keys.Escape that this handler would see. Plain Esc still
            falls through here after the parser's input timeout."""
            _save_draft(event.current_buffer.text)
            event.app.exit(result="/cancel")

        style = Style.from_dict({
            "prompt": "ansibrightblack",
            "": "ansibrightblue bold",
            "completion-menu.completion": "bg:#222222 ansibrightcyan",
            "completion-menu.completion.current": "bg:ansibrightcyan ansiblack",
            "completion-menu.meta.completion": "bg:#222222 ansigray",
        })

        slash_commands = [
            ("/exit", "Leave the chat AND destroy the server session."),
            ("/quit", "Alias for /exit."),
            ("/detach", "Leave but KEEP the session alive — next run resumes."),
            ("/cancel", "Cancel the currently-running turn (if any)."),
            ("/stop", "Alias for /cancel."),
            ("/help", "Show this command list."),
            ("/capabilities", "Show this agent's tools + delegation map."),
            ("/model", "Switch tier: /model standard or /model pro."),
            ("/threshold-ask-user", "Per-turn cost-gate (tier_2 → ask_user, tier_3 → reject). Alias /budget."),
            ("/threshold-auto-compact", "Override auto-compact trigger; mandatory 80% floor still applies."),
            ("/threshold-turn-input", "Per-turn input-token ceiling (default UNLIMITED). Set N to halt runaway turns."),
            ("/threshold-max-steps", "Override per-turn max_steps. Default = spec.max_steps. Set N to expand or shrink."),
            ("/threshold-total-steps", "Override session-cumulative max_total_steps (all turns+subagents). Set N to extend long autonomous runs."),
            ("/budget", "Alias for /threshold-ask-user."),
            ("/cap", "Session spend cap: /cap 1M | +500k | reset."),
            ("/allow-main-commits", "Override feat-branch guard : on | off. Default off."),
            ("/remember", "v3.1.0 — save a fact to user-scope memory: /remember <text> | <key>=<text>. Auto-loads in every agent next session."),
            ("/memory", "v3.3.0 — audit + curate saved memory: /memory [list|get|delete] [agent] [key]. Lists user-scope by default with datetimes."),
            ("/clear", "Clear conversation history (start fresh)."),
            ("/reset", "Alias for /clear."),
            ("/compact", "Fold older messages into a summary."),
            ("/draft", "Recall the most recent Esc-saved draft into the next prompt ."),
            ("/agent", "Switch the active master agent mid-session: /agent <name> ."),
            ("/agents", "List available master agents (filtered by this session's channel)."),
            ("/bg", "E42 — spawn a parallel agent run in the background: /bg <agent> <prompt>. Foreground REPL stays responsive."),
            ("/tasks", "E42 — inspect bg tasks: /tasks list | /tasks status <id> | /tasks kill <id>."),
            ("/auto-approve", "E44 — autonomous-run toggle: /auto-approve on|off|status. Auto-grants every needs_approval event when on."),
        ]

        class _SlashCompleter(Completer):
            def get_completions(self, document, complete_event):
                text = document.text_before_cursor
                if not text.startswith("/"):
                    return
                token = text.split()[0] if text.split() else "/"
                for name, desc in slash_commands:
                    if name.startswith(token):
                        yield Completion(
                            name,
                            start_position=-len(token),
                            display_meta=desc,
                        )

        # E46 (2026-05-13) — persistent chat-input history across
        # sessions. Lives at ~/.master_agents/chat_history. Falls
        # back to in-memory if the file can't be created (read-only
        # home dir, permissions, etc.) so chat still works.
        try:
            _hist_path = master_agents_home() / "chat_history"
            _hist_path.parent.mkdir(parents=True, exist_ok=True)
            _history: Any = FileHistory(str(_hist_path))
        except Exception:
            _history = InMemoryHistory()
        session = PromptSession(
            history=_history,
            multiline=True,
            key_bindings=kb,
            style=style,
            completer=_SlashCompleter(),
            complete_while_typing=True,
        )
    except Exception as exc:
        return _fallback_reader(
            f"prompt_toolkit setup failed — "
            f"{type(exc).__name__}: {exc}. Multi-line paste and "
            "Shift+Enter won't work."
        )

    # kitty keyboard protocol enable removed.
    #  originally enabled `\x1b[>1u` so capable terminals would
    # report Shift+Enter as `\x1b[13;2u`. Run 2 of the live mao
    # refactor test (2026-05-03) revealed the trade-off was net
    # negative: capable terminals also start emitting unmapped
    # functional keys (F13+, Caps Lock state reports, Windows
    # menu keys, Print Screen, etc. — kitty-PUA codes 57344–57471)
    # as CSI-u sequences. prompt_toolkit's vt100 parser doesn't
    # recognise those codes, so it emits a phantom Keys.Escape
    # instead — which trips the eager Esc binding and submits
    # `/cancel` automatically. User saw `/threshold-auto-compact`
    # mysteriously routed to `/cancel` because some background
    # key event arrived while typing.
    #
    # Multi-line input still works without kitty: `\` + Enter
    # (universal backslash continuation, B-cli-shift-enter-newline)
    # and Ctrl+J both insert newlines on every terminal. The
    # ergonomic loss is "Shift+Enter no longer works natively";
    # the gain is "no random /cancel hijacks during chat".
    #
    # The `_enable_kitty_keyboard_protocol` function and the
    # ANSI_SEQUENCES extensions are KEPT in the codebase so a
    # future opt-in mechanism (env var, CLI flag) can re-enable
    # them for users on terminals that don't emit phantom keys.
    # Just no longer called at session start.

    async def _read(prompt: str) -> str:
        # if /draft just recalled a saved buffer, pre-populate
        # the next prompt with it so the user can edit/send instead
        # of typing it again from scratch. _take_pending_prompt_default
        # is single-use; the slot is cleared after this read.
        default = _take_pending_prompt_default()
        if default:
            return await session.prompt_async(prompt, default=default)
        return await session.prompt_async(prompt)

    return _read


_KITTY_ENABLE = "\x1b[>1u"
_KITTY_DISABLE = "\x1b[<u"
_kitty_pushed = False


def _defensive_kitty_disable() -> None:
    """ — defensive pop of kitty keyboard protocol on session start
    (closes A23).

    A pre- master_agents_os process pushed kitty keyboard
    protocol level 1 via `\\x1b[>1u`. If that process crashed before
    the atexit pop ran, the terminal stayed in disambiguate-escape
    mode. A + process started afterward inherits the leftover
    state and starts seeing phantom Esc presses from unmapped
    functional keys (kitty PUA codes 57344-57471). User reports
    `[57414u` leaks STILL appearing post- even though the binary
    has .

    The fix: send `\\x1b[<u` (the kitty pop sequence) on session
    start unconditionally. Terminals not in kitty mode treat the
    sequence as a no-op (CSI sequences with unknown final bytes
    are silently discarded by sane terminal emulators), so calling
    it is safe even on bare cmd.exe / non-kitty xterm.

    Skipped when stdout isn't a TTY (capturing the bytes as visible
    output would corrupt redirected logs).

    Best-effort by design: write failures are swallowed because
    terminal cleanup is not load-bearing — the rest of the session
    must proceed even if the cleanup couldn't write.
    """
    if not sys.stdout.isatty():
        return
    try:
        sys.stdout.write(_KITTY_DISABLE)
        sys.stdout.flush()
    except Exception:
        pass


def _enable_kitty_keyboard_protocol() -> None:
    """Idempotently push kitty keyboard protocol level 1 on stdout
    and register a pop handler. No-op if stdout isn't a TTY (e.g.
    redirected to a file) — the sequence would just leak as visible
    bytes into the captured output."""
    global _kitty_pushed
    if _kitty_pushed:
        return
    if not sys.stdout.isatty():
        return
    try:
        sys.stdout.write(_KITTY_ENABLE)
        sys.stdout.flush()
    except Exception:
        return
    _kitty_pushed = True

    def _pop() -> None:
        try:
            sys.stdout.write(_KITTY_DISABLE)
            sys.stdout.flush()
        except Exception:
            pass

    import atexit
    atexit.register(_pop)
    # Best-effort: also pop on SIGTERM so kill from outside leaves
    # the terminal clean. SIGINT is already handled by atexit since
    # KeyboardInterrupt unwinds normally.
    import signal
    try:
        prev = signal.getsignal(signal.SIGTERM)

        def _handle_sigterm(signum, frame):
            _pop()
            if callable(prev):
                prev(signum, frame)
            else:
                # Re-raise as default handler (terminate).
                signal.signal(signal.SIGTERM, signal.SIG_DFL)
                signal.raise_signal(signal.SIGTERM)

        signal.signal(signal.SIGTERM, _handle_sigterm)
    except (ValueError, OSError):
        # Not on the main thread, or platform doesn't support it
        # (Windows lacks SIGTERM in the POSIX sense) — atexit alone
        # covers normal exits.
        pass


async def _fetch_agent_details(
    cfg: "RemoteConfig", agent_name: str,
) -> dict[str, Any] | None:
    """Fetch the current master's full spec details (description, tools,
    allowed_subagents, model) from GET /agents. Returns None if the
    server doesn't return details for the requested name (older server
    or filter mismatch)."""
    try:
        async with httpx.AsyncClient(base_url=cfg.server, timeout=10) as http:
            headers = (
                {"Authorization": f"Bearer {cfg.token}"} if cfg.token else {}
            )
            resp = await http.get("/agents", headers=headers)
            resp.raise_for_status()
            body = resp.json()
    except Exception as exc:
        sys.stderr.write(
            f"(could not fetch agent details: {type(exc).__name__}: {exc})\n"
        )
        sys.stderr.flush()
        return None
    for entry in body.get("details", []):
        if entry.get("name") == agent_name:
            return entry
    return None


def _print_capabilities(details: dict[str, Any], *, color: bool) -> None:
    """Render the current master's capabilities — model, channels, tools
    grouped, allowed_subagents — for the /capabilities slash command."""
    name = details.get("name", "?")
    description = details.get("description", "").strip()
    channels = details.get("channels") or ["all"]
    tools = sorted(details.get("tools", []))
    subagents = details.get("allowed_subagents", [])
    model = details.get("model", "?")

    def _dim(text: str) -> str:
        return f"\x1b[2m{text}\x1b[0m" if color else text

    def _bold(text: str) -> str:
        return f"\x1b[1m{text}\x1b[0m" if color else text

    print(_bold(f"agent: {name}") + _dim(f"  (model={model})"))
    if description:
        # First sentence of the description for a one-line teaser; the
        # full text is in the yaml if the user wants more.
        first_sentence = description.split(". ")[0].strip().rstrip(".")
        print(_dim(f"  {first_sentence}."))
    print(_dim(f"  channels: {', '.join(channels)}"))
    print()
    if tools:
        print(_bold(f"tools ({len(tools)}):"))
        # Group by prefix when there's a clear cluster (memory_*,
        # create_*, notebook_*); show the rest as flat list.
        clusters: dict[str, list[str]] = {}
        flat: list[str] = []
        for t in tools:
            for prefix in ("memory_", "create_", "notebook_", "scratchpad_"):
                if t.startswith(prefix):
                    clusters.setdefault(prefix.rstrip("_"), []).append(t)
                    break
            else:
                flat.append(t)
        for prefix in sorted(clusters):
            members = sorted(clusters[prefix])
            print(_dim(f"  {prefix}_*: {', '.join(m.removeprefix(prefix + '_') for m in members)}"))
        if flat:
            # Wrap to ~76 cols for readability.
            line = "  "
            for t in flat:
                if len(line) + len(t) + 2 > 76:
                    print(_dim(line.rstrip(", ")))
                    line = "  "
                line += t + ", "
            if line.strip() != "":
                print(_dim(line.rstrip(", ")))
    if subagents:
        print()
        print(_bold(f"can spawn ({len(subagents)}):"))
        print(_dim(f"  {', '.join(subagents)}"))
    print()


async def _list_recent_sessions(
    cfg: "RemoteConfig", *, limit: int = 20,
) -> list[dict[str, Any]]:
    """Fetch recent persisted sessions from the server. Returns an empty
    list if the server has no Postgres backend or the request fails."""
    try:
        async with httpx.AsyncClient(base_url=cfg.server, timeout=10) as http:
            headers = (
                {"Authorization": f"Bearer {cfg.token}"} if cfg.token else {}
            )
            resp = await http.get(
                "/sessions", headers=headers, params={"limit": limit},
            )
            resp.raise_for_status()
            return list(resp.json().get("sessions", []))
    except Exception as exc:
        sys.stderr.write(
            f"(could not list sessions: {type(exc).__name__}: {exc})\n"
        )
        sys.stderr.flush()
        return []


def _format_age(epoch: float | int | None) -> str:
    """Render a unix timestamp as a relative age suitable for the
    picker — `5m`, `2h`, `3d`. Returns `?` on missing/invalid input."""
    if not epoch:
        return "?"
    import time

    delta = max(0, int(time.time() - float(epoch)))
    if delta < 60:
        return f"{delta}s"
    if delta < 3600:
        return f"{delta // 60}m"
    if delta < 86400:
        return f"{delta // 3600}h"
    return f"{delta // 86400}d"


async def _pick_session(cfg: "RemoteConfig") -> dict[str, Any] | None:
    """Show an interactive picker of recent persisted sessions. Returns
    the picked session dict (with session_id + agent_name) or None if
    the user bails out. Server returns server-side metadata; the
    client doesn't have a nonce for arbitrary persisted sessions, so
    the caller MUST go through /rehydrate (which mints a fresh
    nonce) rather than direct resume."""
    sessions = await _list_recent_sessions(cfg, limit=20)
    if not sessions:
        sys.stderr.write(
            "(no persisted sessions on the server — starting fresh)\n"
        )
        sys.stderr.flush()
        return None
    print(f"Recent sessions on {cfg.server}:")
    for i, s in enumerate(sessions, 1):
        sid = s.get("session_id", "?")
        agent = s.get("agent_name", "?")
        age = _format_age(s.get("last_activity_ts"))
        print(f"  [{i}] {sid[:16]}…  {agent:20s}  {age} ago")
    if not sys.stdin.isatty():
        return None
    try:
        raw = input("Pick one by number (Enter to start fresh): ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return None
    if not raw:
        return None
    if not raw.isdigit():
        print("Not a number — starting fresh.")
        return None
    idx = int(raw) - 1
    if not 0 <= idx < len(sessions):
        print("Out of range — starting fresh.")
        return None
    return sessions[idx]


async def _rehydrate_specific(
    client: "RemoteSessionClient", session_id: str,
) -> str | None:
    """Rehydrate a specific persisted session by id.

    Used by --resume <id> and the --pick flow. Returns the resumed
    agent_name on success, or None if the server can't rehydrate (no
    Postgres, terminated session, unknown id, spec gone). Caller
    falls through to a fresh open() on None.
    """
    try:
        body = await client.rehydrate(session_id)
    except Exception as exc:
        sys.stderr.write(
            f"(could not rehydrate {session_id}: {type(exc).__name__}: "
            f"{exc}; starting fresh)\n"
        )
        sys.stderr.flush()
        return None
    msg_count = body.get("message_count", 0)
    new_id = body.get("session_id", "?")
    sys.stderr.write(
        f"(rehydrated session {session_id[:12]}… → {new_id[:12]}…: "
        f"{msg_count} messages restored)\n"
    )
    sys.stderr.flush()
    return body.get("agent_name")


async def _try_resume_active_session(
    client: "RemoteSessionClient", current_server: str,
) -> str | None:
    """Attempt to adopt the cached active session for `current_server`.

    Returns the agent_name of the resumed session on success (caller
    sets it as the master). Returns None when:
      - No cache file
      - Cache points at a different server (don't cross-contaminate)
      - User declines the resume offer
      - Both resume() and rehydrate() fail

    On a successful rehydrate the cache is rewritten with the new
    session_id so subsequent /detach + resume cycles stay coherent.
    """
    cached = _load_active_session()
    if cached is None:
        return None
    if cached.get("server") != current_server:
        return None
    session_id = cached.get("session_id")
    nonce = cached.get("session_nonce")
    agent_name = cached.get("agent_name")
    if not (session_id and nonce and agent_name):
        return None

    detached_at = cached.get("detached_at", "?")
    sys.stderr.write(
        f"Found a detached session: agent={agent_name}, "
        f"session_id={session_id[:12]}…, detached at {detached_at}.\n"
    )
    sys.stderr.flush()
    try:
        # Use the synchronous prompt — the resume question runs BEFORE
        # the chat loop's async prompt session; sys.stdin.isatty()
        # check keeps non-interactive callers (CI scripts) from hanging.
        if sys.stdin.isatty():
            try:
                raw = input("Resume? [Y/n]: ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                print()
                return None
        else:
            raw = "y"
    except OSError:
        return None
    if raw and raw not in ("y", "yes"):
        _clear_active_session()
        return None

    # Try direct resume first (cheaper — no Postgres read, no new id).
    try:
        await client.resume(session_id, nonce)
        return agent_name
    except Exception:
        pass

    # Fallback: server idle-reaped the in-memory session. Rehydrate from
    # Postgres — returns a NEW session_id pre-loaded with prior history.
    try:
        body = await client.rehydrate(session_id)
    except Exception as exc:
        sys.stderr.write(
            f"(could not rehydrate prior session: {type(exc).__name__}: "
            f"{exc}; starting fresh)\n"
        )
        sys.stderr.flush()
        _clear_active_session()
        return None

    # Update cache with the new id so the next /detach saves the right one.
    new_id = body.get("session_id")
    new_nonce = body.get("session_nonce")
    if new_id and new_nonce:
        _save_active_session(
            server=current_server,
            agent_name=agent_name,
            session_id=new_id,
            nonce=new_nonce,
        )
    msg_count = body.get("message_count", 0)
    sys.stderr.write(
        f"(rehydrated from Postgres: {msg_count} messages restored, "
        f"new session_id={new_id[:12] if new_id else '?'}…)\n"
    )
    sys.stderr.flush()
    return agent_name


def _print_user_separator(*, color: bool) -> None:
    """Short `──── you ────` rule above the next prompt."""
    _print_separator(label="you", color=color)


def _print_agent_separator(*, color: bool, agent: str | None = None) -> None:
    """Short `──── agent ────` (or `──── brainstormer ────`) rule
    printed right after the user submits, before the agent's activity
    stream begins. Mirrors the user separator so each turn is bookended
    visually."""
    label = agent if agent else "agent"
    _print_separator(label=label, color=color)


def _print_separator(*, label: str, color: bool) -> None:
    """Fixed-width separator anchor — full-width rules dominated the
    output and made the chat feel like form-filling. 4 dashes each side
    of the label is enough to anchor the eye without crowding."""
    line = f"──── {label} ────"
    if color:
        sys.stderr.write(f"\x1b[2m{line}\x1b[0m\n")
    else:
        sys.stderr.write(line + "\n")
    sys.stderr.flush()


def _print_answer(text: str, *, markdown: bool) -> None:
    """Render the agent's final answer.

    With `markdown=True`, try to use `rich` for terminal-friendly rendering
    of bold/headings/tables/code blocks. Falls back to plain `print` if rich
    isn't installed (it's an optional `[remote-chat]` extra) or if the user
    passed --no-markdown.
    """
    if markdown:
        try:
            from rich.console import Console
            from rich.markdown import Markdown

            Console().print(Markdown(text))
            return
        except ImportError:
            pass
    print(text)


def _surface_agent_question(
    question: str,
    *,
    markdown: bool,
    color: bool,
    client: "RemoteSessionClient",
) -> None:
    """ — print an `ask_user` / `needs_approval` question with
    markdown rendering AND a token-line footer.

    Pre- the inline `_on_needs_input` closure printed the
    question verbatim with no rendering and no footer. Two distinct
    UX gaps:

      A7 — markdown surface fields like bold / lists / code fences
        printed as raw `**bold**` / `- item` source. Dense audit
        summaries (the exact case where ask_user fires most) were
        hard to read.

      A6 — token / cost / cap / duration footer only emitted at
        clean turn end, never on pause. The user couldn't see how
        much spend had accrued before deciding what to type back —
        exactly when that decision matters most.

    Extracted to a module-level helper so tests can drive it
    directly without spinning up the full chat REPL."""
    print()
    print("──── agent question ────")
    _print_answer(question, markdown=markdown)
    if client.last_tokens:
        _print_remote_token_line(
            client.last_tokens,
            color=color,
            duration_s=client.last_turn_seconds,
            cost_summary=client.last_cost_summary,
            cap_info=client.last_cap,
        )
    print(
        "(type your answer below; the next message you send goes "
        "back to the agent — queue is paused)"
    )


def _format_duration(seconds: float | None) -> str:
    """Render wallclock seconds for the token line: `30s`, `1m 5s`,
    `1h 23m`. None or non-positive → empty string so the caller can
    omit the prefix entirely."""
    if seconds is None or seconds <= 0:
        return ""
    s = int(seconds)
    if s < 60:
        # Sub-second precision below 10s gives faster turns a more
        # informative read; integer seconds beyond that.
        if seconds < 10:
            return f"{seconds:.1f}s"
        return f"{s}s"
    if s < 3600:
        return f"{s // 60}m {s % 60}s"
    return f"{s // 3600}h {(s % 3600) // 60}m"


_BUDGET_RE = __import__("re").compile(
    r"^\s*([\d_.]+)\s*([kKmM]?)\s*$"
)


_CAP_RE = __import__("re").compile(
    r"^\s*(\+)?\s*([\d_.]+)\s*([kKmM]?)\s*$"
)


def _parse_cap_arg(arg: str) -> tuple[int, bool] | str | None:
    """Parse the user-typed argument to /cap.

    Accepts:
      - absolute integer / k / M:        "1M", "500k", "2_000_000"
      - relative-add :              "+500k", "+200000"
      - reset / default:                 "reset", "default"

    Returns:
      - (int, False) for absolute set
      - (int, True)  for relative-add (caller adds to current usage)
      - "reset"     literal
      - None        for malformed / non-positive
    """
    if not isinstance(arg, str):
        return None
    a = arg.strip().lower()
    if not a:
        return None
    if a in ("reset", "default", "off", "none"):
        return "reset"
    m = _CAP_RE.match(a)
    if not m:
        return None
    is_relative = m.group(1) == "+"
    raw = m.group(2).replace("_", "")
    try:
        val = float(raw)
    except ValueError:
        return None
    suffix = m.group(3).lower()
    if suffix == "k":
        val *= 1000
    elif suffix == "m":
        val *= 1_000_000
    n = int(val)
    if n <= 0:
        return None
    return (n, is_relative)


def _parse_budget_arg(arg: str) -> int | str | None:
    """Parse the user-typed argument to /budget.

    Accepts:
      - bare integer or `_`-separated:  "50000", "50_000"
      - k/K suffix (×1000):              "50k", "50K", "1.5k"
      - M/m suffix (×1_000_000):         "2M", "0.5M"
      - reset / default:                 "reset", "default", "RESET"

    Returns:
      - positive int for a numeric form
      - the literal string "reset" for reset/default
      - None for malformed / non-positive input

    The chat REPL uses the result to either POST a new budget or
    POST None (reset). None from this parser surfaces a usage hint
    to the user instead of calling the server.
    """
    if not isinstance(arg, str):
        return None
    a = arg.strip().lower()
    if not a:
        return None
    if a in ("reset", "default"):
        return "reset"
    m = _BUDGET_RE.match(a)
    if not m:
        return None
    raw = m.group(1).replace("_", "")
    try:
        val = float(raw)
    except ValueError:
        return None
    suffix = m.group(2).lower()
    if suffix == "k":
        val *= 1000
    elif suffix == "m":
        val *= 1_000_000
    n = int(val)
    if n <= 0:
        return None
    return n


def _format_ctx_suffix(tokens: dict[str, Any] | None) -> str:
    """: render the context-window indicator.

    Format depends on what's known:
      ctx: 65K / 1M (compact at 100K)        — both fields present
      ctx: 65K / 1M                          — model_max known, no soft threshold
      (empty)                                — model_max=0 (older server)

    Always shows "compact at 80%" when soft_compact is None — the
    mandatory floor always applies.
    """
    if not tokens:
        return ""
    history = int(tokens.get("history_tokens", 0) or 0)
    model_max = int(tokens.get("model_max_tokens", 0) or 0)
    if model_max <= 0:
        return ""
    soft = tokens.get("soft_compact_threshold")
    # Format helpers — match the cap suffix style.
    def _k(n: int) -> str:
        if n < 1000:
            return str(n)
        if n < 1_000_000:
            return f"{n / 1000:g}K"
        return f"{n / 1_000_000:.2f}M"
    pct = int(100 * history / model_max) if model_max else 0
    base = f"  ·  ctx: {_k(history)} / {_k(model_max)}"
    if soft is not None and isinstance(soft, int):
        base += f" (compact at {_k(soft)})"
    elif model_max:
        # No soft threshold; surface the mandatory 80% floor .
        base += f" (auto-compact at {_k(int(model_max * 0.8))})"
    if pct >= 80:
        base += " — close to context wall"
    # append model tier alias when present (vendor-abstracted per
    # ; users see "standard" / "pro", not the canonical model ID).
    alias = tokens.get("model_alias")
    if isinstance(alias, str) and alias:
        base += f"  ·  model: {alias}"
    return base


def _format_cache_suffix(tokens: dict[str, Any] | None) -> str:
    """E36 (2026-05-13): render the cache-hit-rate indicator.

    Format depends on what the server payload carries:

      cache: 78% (3.2M read this session)    — full data
      cache: 78%                              — turn-zero session
      (empty)                                 — older server (no
                                                cache fields in
                                                payload), OR no
                                                cache reads yet.

    The ratio is server-computed via `session.cache_hit_ratio`
    (`_total_cache_read_tokens / _total_input_tokens`); this client
    just renders.

    Cache-regression diagnosis time motivated this — pre-E36, a
    cache-hit-rate collapse like E32 (DeepSeek prefix-cache
    regression, May 2026) only surfaced after a forensic JSONL
    trace dive. With this footer the user sees "cache: 1%" the
    first turn after a regression lands.
    """
    if not tokens:
        return ""
    ratio = tokens.get("session_cache_hit_ratio")
    cache_total = tokens.get("session_cache_read_total")
    if ratio is None and cache_total is None:
        return ""  # older server, no cache fields
    try:
        pct = int(round(float(ratio or 0.0) * 100))
    except (TypeError, ValueError):
        return ""
    if pct <= 0 and not cache_total:
        return ""  # no cache reads yet — don't add noise
    base = f"  ·  cache: {pct}%"
    try:
        total = int(cache_total or 0)
    except (TypeError, ValueError):
        total = 0
    if total >= 1000:
        # Match the K/M format style used by `_format_ctx_suffix`.
        if total < 1_000_000:
            base += f" ({total / 1000:g}K read)"
        else:
            base += f" ({total / 1_000_000:.2f}M read)"
    return base


def _format_cap_suffix(cap_info: dict[str, Any] | None, session_total: int) -> str:
    """Render the  cap indicator. Empty when no cap is set.

    Formats:
      cap: 263K / 1M used (26%)
      cap: 920K / 1M used (92%) — close to halt
      cap: 1.02M / 1M — HALTED
    """
    if not cap_info:
        return ""
    cap = int(cap_info.get("cap", 0) or 0)
    if cap <= 0:
        return ""
    # Always use the live session_total when the chat updates between
    # turns, since cap_info.used can be stale by one turn.
    used = max(int(cap_info.get("used", 0) or 0), session_total)
    pct = int(100 * used / cap) if cap else 0
    used_str = f"{used / 1000:g}K" if used < 1_000_000 else f"{used / 1_000_000:.2f}M"
    cap_str = f"{cap / 1000:g}K" if cap < 1_000_000 else f"{cap / 1_000_000:.2f}M"
    if used > cap:
        return f"  ·  cap: {used_str} / {cap_str} — HALTED"
    if pct >= 90:
        return f"  ·  cap: {used_str} / {cap_str} used ({pct}%) — close to halt"
    return f"  ·  cap: {used_str} / {cap_str} used ({pct}%)"


def _format_cost_band_suffix(cost_summary: dict[str, Any] | None) -> str:
    """Render the  cost-band indicator that appends to the token line.

    Surfaces the agent's estimate-then-decide footprint for every turn that
    called estimate_tokens. Three formats by tier:

      tier_1: "  ·  cost: 25K est within 100K budget"
      tier_2: "  ·  cost: 130K est over budget — user consulted"
      tier_3: "  ·  cost: 250K est REJECTED (over 200K hard cap)"

    Returns "" when no estimate calls were made — keeps the line clean for
    pure-text turns.
    """
    if not cost_summary:
        return ""
    total = int(cost_summary.get("total_estimated_tokens", 0) or 0)
    threshold = int(cost_summary.get("threshold", 0) or 0)
    band = cost_summary.get("band", "tier_1")
    consulted = bool(cost_summary.get("user_consulted", False))
    total_k = total / 1000
    threshold_k = threshold / 1000
    if band == "tier_1":
        return f"  ·  cost: {total_k:g}K est within {threshold_k:g}K budget"
    if band == "tier_2":
        suffix = "user consulted" if consulted else "approval required"
        return f"  ·  cost: {total_k:g}K est over budget — {suffix}"
    # tier_3
    return (
        f"  ·  cost: {total_k:g}K est REJECTED "
        f"(over {threshold_k * 2:g}K hard cap)"
    )


def _print_remote_token_line(
    tokens: dict[str, Any],
    *,
    color: bool,
    duration_s: float | None = None,
    cost_summary: dict[str, Any] | None = None,
    cap_info: dict[str, Any] | None = None,
) -> None:
    """Format the server's `final.tokens` payload as a dim one-liner.

    Mirrors the local-chat token line so remote users get the same per-turn +
    cumulative visibility. With duration_s set, prefixes the line with
    `Time: 30s | ` so the user sees turn latency alongside cost
    (matches Claude Code's per-message summary).

    With `cost_summary` set (the  cost_band_summary event payload),
    appends a tier indicator: `cost: 25K est within 100K budget`.

    Server payload shape:
      {input, output, session_total, history_tokens, compact_savings}
    """
    turn_in = int(tokens.get("input", 0) or 0)
    turn_out = int(tokens.get("output", 0) or 0)
    session_total = int(tokens.get("session_total", 0) or 0)
    duration = _format_duration(duration_s)
    prefix = f"Time: {duration} | " if duration else ""
    cost_suffix = _format_cost_band_suffix(cost_summary)
    cap_suffix = _format_cap_suffix(cap_info, session_total)
    ctx_suffix = _format_ctx_suffix(tokens)
    # E36 (2026-05-13) — surface the cache hit rate in the per-turn
    # footer. Pre-fix the data existed server-side
    # (`session.cache_hit_ratio`, `_total_cache_read_tokens`) but
    # never reached this footer; cache regressions like E32 took
    # days to diagnose because the signal was buried in trace
    # JSONL. Now any user can see "cache: 78%" in real time.
    # Backward-compatible: older servers won't include the cache
    # fields and the suffix collapses to an empty string.
    cache_suffix = _format_cache_suffix(tokens)
    text = (
        f"  {prefix}tokens: {turn_in:,} in + {turn_out:,} out "
        f"({turn_in + turn_out:,} turn)  ·  {session_total:,} session"
        f"{cache_suffix}{cap_suffix}{ctx_suffix}{cost_suffix}"
    )
    if color:
        print(f"\x1b[2m{text}\x1b[0m")
    else:
        print(text)


async def _cmd_remote_chat(args) -> int:
    # defensive kitty pop. Belt-and-suspenders cleanup of any
    # leftover kitty keyboard mode pushed by a crashed pre-
    # process. No-op if the terminal isn't in kitty mode.
    _defensive_kitty_disable()
    # self-hosted refactor banner. When the agent is launched
    # from a master_agents_os repo checkout, surface the risk so the
    # user is reminded they're editing the agent's own source. No-op
    # for normal end-user installs.
    from ._self_host import is_self_hosted_repo
    if is_self_hosted_repo(Path(os.getcwd())):
        sys.stderr.write(
            "ℹ self-hosted refactor mode — cwd is a master_agents_os "
            "checkout. Edits to load-bearing modules (cli, runner, "
            "session, server, providers, agent, types) can break the "
            "running agent at next launch.  catches import-time "
            "errors automatically; behavioural bugs are still on you. "
            "Use docs/onramp/INSTALL_SELF_HOSTED.md's pattern for safer work.\n"
        )
        sys.stderr.flush()
    cfg = load_remote_config(_config_path(args))
    color = not getattr(args, "no_color", False)
    quiet = getattr(args, "quiet", False)
    markdown = not getattr(args, "no_markdown", False)
    show_diffs = not getattr(args, "no_diffs", False)
    # min_depth=0 so root-only agents (no subagents) still surface tool calls.
    # Local chat passes min_depth=1 because the user already issued the prompt
    # and root noise is redundant; here the user is staring at a blank prompt
    # waiting for the network round-trip, so any signal beats silence.
    tracer: Tracer | None = (
        None if quiet else ConsoleTracer(color=color, min_depth=0)
    )
    client = RemoteSessionClient(
        base_url=cfg.server,
        token=cfg.token,
        cwd=Path(os.getcwd()),
        writable_paths=cfg.writable_paths,
        tracer=tracer,
        heartbeat=not quiet and color,
        show_diffs=show_diffs and not quiet,
        diff_color=color,
    )

    # Resume flow:
    #   1. If --new, skip resume entirely (Phase 1).
    #   2. If --resume <id>, rehydrate that specific id (Phase 2).
    #   3. If --resume-last, resolve master, read per-master last_session
    #      file, rehydrate (E39 — added 2026-05-13 hotfix; the
    #      original E39 added the flag to `remote run` only, leaving
    #      `remote chat` with a stale hint message that pointed at a
    #      flag the parser didn't have).
    #   4. If --pick, fetch /sessions list, show picker, rehydrate (Phase 2).
    #   5. Otherwise look at ~/.master_agents/active_session.json
    #      (Phase 1). If it points at THIS server, offer to resume.
    #      Try direct resume first; fall back to /rehydrate.
    #   6. Anything fails → silent fresh open.
    force_new = getattr(args, "new", False)
    resume_id = getattr(args, "resume_id", None)
    resume_last = getattr(args, "resume_last", False)
    pick = getattr(args, "pick", False)
    resumed_master: str | None = None

    if not force_new:
        if resume_id:
            resumed_master = await _rehydrate_specific(client, resume_id)
        elif resume_last:
            # --resume-last needs the master resolved first because the
            # last-session file is per-master (parity with --resume-last
            # in `remote run` at line ~1671).
            _rl_master = await _resolve_master(cfg, args, interactive=True)
            if not _rl_master:
                return 2
            _rl_last_id = read_last_session_id(_rl_master)
            if _rl_last_id is None:
                print(
                    f"--resume-last: no detached session found for master "
                    f"{_rl_master!r}. Run /detach in chat or pass --detach "
                    f"to `remote run` first; or pass --resume <id> if you "
                    f"have the id from a previous [Session ended] line.",
                    file=sys.stderr,
                )
                return 2
            resumed_master = await _rehydrate_specific(client, _rl_last_id)
            if resumed_master is None:
                # Server-side session gone (purged/expired). Fall through
                # to fresh open with the resolved master — printed warning
                # so the operator knows the recovery didn't fire.
                print(
                    f"--resume-last: stored session {_rl_last_id} no longer "
                    f"exists on the server. Starting a fresh session with "
                    f"master {_rl_master}.",
                    file=sys.stderr,
                )
        elif pick:
            picked = await _pick_session(cfg)
            if picked is not None:
                resumed_master = await _rehydrate_specific(
                    client, picked["session_id"],
                )
        else:
            resumed_master = await _try_resume_active_session(client, cfg.server)

    if resumed_master is not None:
        master = resumed_master
        print(
            f"remote chat with {master} @ {cfg.server} (resumed). "
            "/exit to quit, /detach to leave session alive, /help for commands."
        )
    else:
        master = await _resolve_master(cfg, args, interactive=True)
        if not master:
            return 2
        print(
            f"remote chat with {master} @ {cfg.server}. "
            "/exit to quit, /detach to leave session alive, /help for commands."
        )
        try:
            await client.open(master)
        except Exception as exc:
            print(
                f"Error opening session on {cfg.server}: {type(exc).__name__}: {exc}",
                file=sys.stderr,
            )
            return 1
    read_prompt = _make_prompt_reader()
    # `intent` controls what happens in the finally block:
    #   "destroy" — full teardown via client.close() (DELETE on the server)
    #   "detach"  — exit but keep the server session alive
    state = {"intent": "destroy", "should_exit": False}
    # E42 (2026-05-13): bg tasks spawned via /bg slash command. Each
    # entry is a _BgTask record. Lives for the chat session lifetime;
    # remaining tasks are cancelled on /exit + /detach. Recoverable
    # long-running work should use `mao-client remote run --detach`
    # in a separate terminal instead — this is operator-level
    # parallelism, not durable background work.
    bg_tasks: dict[str, _BgTask] = {}
    state["bg_tasks"] = bg_tasks  # type: ignore[assignment]
    # E44 (2026-05-13): autonomous-run mode — when on, the chat REPL
    # auto-approves every needs_approval event with a stderr
    # breadcrumb instead of prompting interactively. Toggled by
    # CLI flag `--auto-approve` (initial state) and slash command
    # `/auto-approve on|off|status` (mid-session toggle). Matches
    # Claude Code's `--dangerously-skip-permissions` ergonomic for
    # known-trusted agent specs. Default False — explicit opt-in
    # because the agent's tool surface IS the security boundary.
    state["auto_approve"] = bool(getattr(args, "auto_approve", False))
    input_queue: asyncio.Queue[str] = asyncio.Queue()
    turn_busy = asyncio.Event()
    _EXIT_SENTINEL = "__EXIT__"

    # When the agent calls ask_user, the consumer sets pending_input["future"];
    # the producer's NEXT keystroke fulfils that future instead of queueing.
    # Single slot — the agent only blocks on one ask_user at a time.
    pending_input: dict[str, Any] = {"future": None}

    # numbered shortcut for /agent. /agents prints a numbered
    # list AND populates this map; /agent N looks up by number to
    # avoid typing long names. Refreshed on every /agents call so a
    # server-side spec change between calls is reflected. Empty
    # until the user runs /agents at least once.
    agent_index_map: dict[int, str] = {}

    async def _on_needs_input(question: str) -> str:
        loop = asyncio.get_running_loop()
        fut: asyncio.Future[str] = loop.create_future()
        pending_input["future"] = fut
        _surface_agent_question(
            question, markdown=markdown, color=color, client=client,
        )
        try:
            return await fut
        finally:
            pending_input["future"] = None

    async def _on_needs_approval(tool_name: str, preview_text: str) -> bool:
        # E44 (2026-05-13): autonomous-mode bypass. When state's
        # `auto_approve` flag is set (via --auto-approve CLI flag or
        # `/auto-approve on` slash command), every approval event
        # is granted with a stderr breadcrumb instead of an
        # interactive prompt. Same shape as the headless dispatch
        # callback at line ~1800 so operators see uniform logs
        # whether they're in run-headless or chat-autonomous mode.
        if state.get("auto_approve"):
            print(
                f"[auto-approve] {tool_name} "
                f"(preview: {preview_text[:120]!r}...)",
                file=sys.stderr,
            )
            return True
        # Approvals are a yes/no; route through the same input channel
        # but parse the answer as boolean-ish.
        answer = await _on_needs_input(
            f"Approve tool {tool_name!r} with input: {preview_text}? "
            "(yes/no)"
        )
        return answer.strip().lower() in ("y", "yes", "true", "1", "ok")

    # Re-build the client with these callbacks wired up. (The earlier
    # construction already happened; we mutate the existing client so
    # follow-up turns also use the callbacks.)
    client._on_needs_input = _on_needs_input
    client._on_needs_approval = _on_needs_approval

    # Optional: prompt_toolkit's patch_stdout wraps stdout/stderr so trace
    # events from the agent's run don't smudge the active prompt line
    # while the user is typing. Falls back to a no-op context manager if
    # prompt_toolkit isn't installed (chat still works, just messier
    # output during concurrent typing).
    try:
        from prompt_toolkit.patch_stdout import patch_stdout
        stdout_patch = patch_stdout(raw=True)
    except ImportError:
        import contextlib
        stdout_patch = contextlib.nullcontext()

    async def _producer() -> None:
        """Reads input forever. Slash commands that don't need server
        state (/exit, /detach, /cancel, /help) execute IMMEDIATELY.
        Everything else is enqueued for the consumer to dispatch
        sequentially. Status indicator shows queue depth when typing
        during a turn."""
        #  follow-up — `master` is set in the outer
        # `_cmd_remote_chat` scope at session creation. The /agent
        # slash handler MUST update it after a successful
        # set_master so the agent-separator label
        # (`_print_agent_separator(agent=master)`) reflects the
        # current master, not the one from session creation.
        nonlocal master
        first_prompt = True
        while not state["should_exit"]:
            try:
                if first_prompt:
                    _print_user_separator(color=color)
                    first_prompt = False
                line = await read_prompt("> ")
            except (EOFError, KeyboardInterrupt):
                state["intent"] = "destroy"
                state["should_exit"] = True
                await input_queue.put(_EXIT_SENTINEL)
                return
            stripped = line.strip()
            if not stripped:
                continue

            # If the agent is waiting on ask_user, the next message is
            # the answer — not a new prompt. Fulfil the pending future
            # and skip the queue. /cancel and /exit still bypass to
            # let the user escape a stuck question.
            pending_fut = pending_input.get("future")
            if (
                pending_fut is not None
                and not pending_fut.done()
                and stripped not in ("/cancel", "/stop", "/exit", "/quit", "/detach")
            ):
                pending_fut.set_result(line)
                continue

            # Immediate (don't queue):
            if stripped in ("/exit", "/quit"):
                state["intent"] = "destroy"
                state["should_exit"] = True
                if turn_busy.is_set():
                    try:
                        await client.cancel()
                    except Exception:
                        pass
                await input_queue.put(_EXIT_SENTINEL)
                return
            if stripped == "/detach":
                state["intent"] = "detach"
                state["should_exit"] = True
                if turn_busy.is_set():
                    try:
                        await client.cancel()
                    except Exception:
                        pass
                await input_queue.put(_EXIT_SENTINEL)
                return
            if stripped in ("/cancel", "/stop"):
                # if Esc-with-text triggered this /cancel, the
                # draft slot was populated. Surface the recovery
                # affordance so the user knows their text isn't lost.
                draft_was_saved = _has_draft()
                if turn_busy.is_set():
                    print("(cancelling current turn...)")
                    try:
                        await client.cancel()
                    except Exception as exc:
                        print(
                            f"(cancel failed: {type(exc).__name__}: {exc})"
                        )
                    # If a pending ask_user future exists, fail it so
                    # the consumer's await unblocks and the cancel
                    # propagates cleanly.
                    pf = pending_input.get("future")
                    if pf is not None and not pf.done():
                        pf.set_exception(
                            asyncio.CancelledError("user cancelled")
                        )
                else:
                    print("(no turn running to cancel)")
                if draft_was_saved:
                    print("(your typed buffer was saved — type /draft to recall it)")
                continue
            if stripped == "/draft":
                # recall the most-recent Esc-saved draft into
                # the next prompt. _recall_draft consumes the slot;
                # _set_pending_prompt_default makes _read use the
                # text as the prompt's `default` argument.
                saved = _recall_draft()
                if saved is None:
                    print(
                        "(no draft saved — drafts are saved automatically "
                        "when you press Esc with text in the buffer)"
                    )
                else:
                    _set_pending_prompt_default(saved)
                    print(
                        "(draft restored — next prompt is pre-populated; "
                        "edit and Enter to send)"
                    )
                continue
            if stripped == "/help":
                print(_REMOTE_CHAT_HELP)
                continue

            # Queued: dispatched in order by the consumer.
            await input_queue.put(stripped)
            if turn_busy.is_set():
                # Print the queue-depth indicator AFTER the current
                # turn's activity finishes; for now flag that this
                # message is queued.
                pending = input_queue.qsize()
                msg_word = "message" if pending == 1 else "messages"
                print(
                    f"(queued — {pending} {msg_word} waiting ✓)"
                )
            else:
                # Not busy yet: consumer will pick this up in a moment.
                # Skip the user separator print here — the consumer
                # will print the agent separator itself.
                pass

    async def _consumer() -> None:
        """Drains the queue and dispatches turns sequentially. Each
        turn sets turn_busy so the producer can show queue indicators
        when input arrives during execution."""
        # `master` is written below at the /agent <name> switch
        # ; without `nonlocal`, Python treats it as a
        # local-only and the read in _print_agent_separator(agent=master)
        # raises UnboundLocalError on the FIRST turn of every chat
        # (before any /agent switch). Pre-fix: every customer's first
        # non-/agent input crashed `mao-client remote chat`. v1.0.0
        # through v1.0.2 shipped with this defect.
        nonlocal master
        while True:
            # Poll with a short timeout so we can re-check should_exit
            # promptly without blocking forever on an empty queue.
            try:
                line = await asyncio.wait_for(input_queue.get(), timeout=0.25)
            except asyncio.TimeoutError:
                if state["should_exit"]:
                    break
                continue

            if line == _EXIT_SENTINEL or state["should_exit"]:
                # Discard any further queued items with a notice so the
                # user knows nothing got silently dropped.
                discarded: list[str] = []
                while not input_queue.empty():
                    try:
                        item = input_queue.get_nowait()
                        if item != _EXIT_SENTINEL:
                            discarded.append(item)
                    except asyncio.QueueEmpty:
                        break
                if discarded:
                    print(
                        f"({len(discarded)} queued message(s) discarded on exit)"
                    )
                return

            # Server-state slash commands (queued because they need
            # the session to be idle). Single-stream consumer means
            # they only run between turns, never during one.
            if line == "/capabilities":
                details = await _fetch_agent_details(cfg, master)
                if details is None:
                    print(
                        f"(could not fetch capabilities for {master!r} — "
                        "the server may not support this endpoint yet, "
                        "or the agent isn't visible to your token.)"
                    )
                else:
                    _print_capabilities(details, color=color)
                _print_user_separator(color=color)
                continue
            if line == "/model" or line.startswith("/model "):
                # Empty form: print CURRENT + available tiers; arg form:
                # switch to that model.
                parts = line.split(maxsplit=1)
                if len(parts) == 1:
                    # fetch the active tier so we can mark it in
                    # the listing. /thresholds returns model_alias in
                    # the context section.
                    try:
                        models = await client.list_models()
                    except Exception as exc:
                        print(
                            f"Error: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    current_alias: str | None = None
                    try:
                        thresholds = await client.get_thresholds()
                        current_alias = (
                            thresholds.get("context", {}).get("model_alias")
                        )
                    except Exception:
                        # Older server without /thresholds endpoint or
                        # transient failure — show the list without a
                        # current marker.
                        current_alias = None
                    print("Switchable tiers:")
                    for m in models:
                        marker = (
                            "→ "
                            if current_alias == m["alias"]
                            else "  "
                        )
                        suffix = " (current)" if current_alias == m["alias"] else ""
                        print(
                            f"{marker}{m['alias']:10s}  ({m['tier']}) — "
                            f"{m['description']}{suffix}"
                        )
                    if current_alias:
                        print(
                            f"Usage: `/model standard` or `/model pro` "
                            f"to switch (current: {current_alias})."
                        )
                    else:
                        print(
                            "Usage: `/model standard` or `/model pro` "
                            "(applies to current session only)."
                        )
                else:
                    target = parts[1].strip()
                    try:
                        info = await client.set_model(target)
                    except Exception as exc:
                        print(
                            f"Error: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    print(
                        f"(switched to {info['alias']} tier "
                        f"for this session)"
                    )
                _print_user_separator(color=color)
                continue
            if line == "/cap" or line.startswith("/cap "):
                # session-wide spend cap. Empty form → show usage;
                # arg form → set absolute / relative-add / reset.
                parts = line.split(maxsplit=1)
                if len(parts) == 1:
                    # query the live state, not just local cache.
                    try:
                        info = await client.get_thresholds()
                    except Exception as exc:
                        print(
                            f"Error fetching thresholds: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    cap_state = info.get("cap", {})
                    cap_tokens = cap_state.get("tokens")
                    used = int(cap_state.get("used", 0))
                    if cap_tokens is None:
                        print(
                            "Cap: NOT SET (default = no limit on cumulative "
                            "session spend)\n"
                            f"Used so far this session: {used:,} tokens\n"
                            "Set with:\n"
                            "  /cap 1M       cap at 1,000,000 tokens total\n"
                            "  /cap 500k     tighten\n"
                            "  /cap +500k    add 500K to current usage\n"
                            "  /cap reset    remove cap"
                        )
                    else:
                        cap = int(cap_tokens)
                        remaining = cap_state.get("remaining")
                        pct = (100 * used / cap) if cap else 0
                        status = "HALTED" if cap_state.get("halted") else "active"
                        print(
                            f"Cap:       {cap:,} tokens\n"
                            f"Used:      {used:,} ({pct:.0f}%)"
                        )
                        if isinstance(remaining, int):
                            print(f"Remaining: {remaining:,}")
                        print(f"Status:    {status}")
                        print(
                            "Note: /clear and /compact preserve the "
                            "cumulative counter (financial truth)."
                        )
                else:
                    parsed = _parse_cap_arg(parts[1])
                    if parsed is None:
                        print(
                            f"Invalid cap: {parts[1]!r}. Examples: "
                            "`/cap 1M`, `/cap 500000`, `/cap +500k`, "
                            "`/cap reset`."
                        )
                        _print_user_separator(color=color)
                        continue
                    if parsed == "reset":
                        tokens_arg: int | None = None
                    else:
                        n, is_relative = parsed
                        if is_relative:
                            current_used = (
                                int(client.last_tokens.get("session_total", 0))
                                if client.last_tokens else 0
                            )
                            tokens_arg = current_used + n
                        else:
                            tokens_arg = n
                    try:
                        info = await client.set_cap(tokens_arg)
                    except Exception as exc:
                        print(
                            f"Error: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    if info.get("cap") is None:
                        print(
                            "(cap removed — no limit on cumulative "
                            "session spend)"
                        )
                    else:
                        cap = int(info["cap"])
                        used = int(info["used"])
                        rem = info.get("remaining")
                        if isinstance(rem, int):
                            print(
                                f"(cap set to {cap:,} tokens; used "
                                f"{used:,}, remaining {rem:,})"
                            )
                        else:
                            print(f"(cap set to {cap:,} tokens; used {used:,})")
                _print_user_separator(color=color)
                continue
            if (
                line == "/allow-main-commits"
                or line.startswith("/allow-main-commits ")
            ):
                # feat-branch-only commit guard override.
                parts = line.split(maxsplit=1)
                arg = parts[1].strip().lower() if len(parts) == 2 else ""
                if arg in ("on", "true", "yes", "1"):
                    allowed = True
                elif arg in ("off", "false", "no", "0", "reset", "default"):
                    allowed = False
                elif arg == "":
                    print(
                        " feat-branch commit guard. Default: GUARD ACTIVE\n"
                        "  /allow-main-commits on    bypass for emergency hotfixes\n"
                        "  /allow-main-commits off   re-enable guard (default)\n"
                        "Project policy requires feat/<name> branches for all\n"
                        "code changes; override sparingly."
                    )
                    _print_user_separator(color=color)
                    continue
                else:
                    print(
                        f"Invalid argument {arg!r}. Use `on` or `off`."
                    )
                    _print_user_separator(color=color)
                    continue
                try:
                    info = await client.set_allow_main_commits(allowed)
                except Exception as exc:
                    print(
                        f"Error: {type(exc).__name__}: {exc}",
                        file=sys.stderr,
                    )
                    _print_user_separator(color=color)
                    continue
                if info.get("allow_main_commits"):
                    print(
                        "(WARNING — feat-branch commit guard DISABLED for "
                        "this session. Commits to main/master will proceed. "
                        "Re-enable with `/allow-main-commits off`.)"
                    )
                else:
                    print(
                        "(feat-branch commit guard ACTIVE — commits to "
                        "main/master refused; agent must `git_write "
                        "checkout -b feat/<name>` first.)"
                    )
                _print_user_separator(color=color)
                continue
            if (
                line == "/threshold-auto-compact"
                or line.startswith("/threshold-auto-compact ")
            ):
                # per-session auto-compact threshold override.
                # Soft trigger; the  mandatory 80% floor still applies.
                parts = line.split(maxsplit=1)
                if len(parts) == 1:
                    # show CURRENT effective threshold + source +
                    # current history fill. None → only mandatory floor.
                    try:
                        info = await client.get_thresholds()
                    except Exception as exc:
                        print(
                            f"Error fetching thresholds: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    ct = info.get("compact_threshold", {})
                    ctx = info.get("context", {})
                    cur = ct.get("tokens")  # may be None
                    src = ct.get("source", "default")
                    history = int(ctx.get("history_tokens", 0))
                    floor = int(ctx.get("mandatory_floor", 0))
                    if cur is None:
                        #  revised: no soft trigger by default.
                        print(
                            "Auto-compact threshold\n"
                            "  Soft trigger:    NOT SET  (no soft compact "
                            "by default; users opt in)\n"
                            f"  History now:     {history:,} tokens\n"
                            f"  Mandatory floor: {floor:,} tokens  "
                            f"\n"
                            "Set a soft trigger with:\n"
                            "  /threshold-auto-compact 200k    compact at 200K\n"
                            "  /threshold-auto-compact 50k     compact at 50K\n"
                            "  /threshold-auto-compact 1M      loosen further"
                        )
                    else:
                        cur_int = int(cur)
                        src_label = {
                            "session": "set via /threshold-auto-compact this session",
                            "spec": "set in agent YAML (history_compact_threshold)",
                        }.get(src, src)
                        pct = (100 * history / cur_int) if cur_int else 0
                        print(
                            f"Auto-compact threshold\n"
                            f"  Soft trigger:    {cur_int:,} tokens  "
                            f"({src_label})\n"
                            f"  History now:     {history:,} tokens  "
                            f"({pct:.0f}% of soft trigger)\n"
                            f"  Mandatory floor: {floor:,} tokens  "
                            f"\n"
                            "Change with:\n"
                            "  /threshold-auto-compact 50k     tighten\n"
                            "  /threshold-auto-compact 1M      loosen\n"
                            "  /threshold-auto-compact reset   revert to spec / no default"
                        )
                else:
                    parsed = _parse_budget_arg(parts[1])
                    if parsed is None:
                        print(
                            f"Invalid threshold: {parts[1]!r}. Examples: "
                            "`/threshold-auto-compact 50k`, "
                            "`/threshold-auto-compact 200000`, "
                            "`/threshold-auto-compact reset`."
                        )
                        _print_user_separator(color=color)
                        continue
                    tokens_arg = None if parsed == "reset" else parsed
                    try:
                        info = await client.set_compact_threshold(tokens_arg)
                    except Exception as exc:
                        print(
                            f"Error: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    val = info.get("compact_threshold")
                    if val is None:
                        print(
                            "(auto-compact threshold reset — falls back "
                            "to spec setting; mandatory 80% floor still "
                            "applies)"
                        )
                    else:
                        print(
                            f"(auto-compact threshold set to {val:,} tokens "
                            f"for this session; mandatory 80% floor still "
                            f"applies as safety net)"
                        )
                _print_user_separator(color=color)
                continue
            if (
                line == "/threshold-turn-input"
                or line.startswith("/threshold-turn-input ")
            ):
                # per-session per-turn input-token ceiling. Halts
                # the runner mid-turn once cumulative LLM input exceeds
                # the limit, forcing the agent to consolidate. Default
                # is unlimited — users opt in here when they want the
                # safety net. The override persists for every
                # remaining turn of THIS session.
                parts = line.split(maxsplit=1)
                if len(parts) == 1:
                    try:
                        info = await client.get_thresholds()
                    except Exception as exc:
                        print(
                            f"Error fetching thresholds: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    ti = info.get("turn_input_ceiling", {})
                    cur = ti.get("tokens")  # may be None (unlimited)
                    src = ti.get("source", "default")
                    if cur is None:
                        print(
                            "Per-turn input-token ceiling\n"
                            "  Current:    UNLIMITED  (default — no "
                            "per-turn cap)\n"
                            "Set a ceiling for this session with:\n"
                            "  /threshold-turn-input 200k    halt at 200K "
                            "input tokens within a single turn\n"
                            "  /threshold-turn-input 50k     tighter — "
                            "use for short focused turns\n"
                            "  /threshold-turn-input 1M      loose safety "
                            "net for long research turns\n"
                            "Once set, the ceiling applies to every "
                            "subsequent turn of this session until you "
                            "reset it (`/threshold-turn-input reset`)."
                        )
                    else:
                        cur_int = int(cur)
                        src_label = {
                            "session": "set via /threshold-turn-input "
                            "this session",
                            "default": "global default",
                        }.get(src, src)
                        print(
                            f"Per-turn input-token ceiling\n"
                            f"  Current: {cur_int:,} tokens  "
                            f"({src_label})\n"
                            "  Halts the runner if cumulative LLM input "
                            "in a single turn exceeds this value;\n"
                            "  injects a STOP message forcing the agent "
                            "to consolidate or call ask_user.\n"
                            "Change with:\n"
                            "  /threshold-turn-input 50k     tighten\n"
                            "  /threshold-turn-input 1M      loosen\n"
                            "  /threshold-turn-input reset   revert to "
                            "default (UNLIMITED)"
                        )
                else:
                    parsed = _parse_budget_arg(parts[1])
                    if parsed is None:
                        print(
                            f"Invalid threshold: {parts[1]!r}. Examples: "
                            "`/threshold-turn-input 200k`, "
                            "`/threshold-turn-input 1000000`, "
                            "`/threshold-turn-input reset`."
                        )
                        _print_user_separator(color=color)
                        continue
                    tokens_arg = None if parsed == "reset" else parsed
                    try:
                        info = await client.set_turn_input_ceiling(tokens_arg)
                    except Exception as exc:
                        print(
                            f"Error: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    val = info.get("turn_input_ceiling")
                    if val is None:
                        print(
                            "(per-turn input-token ceiling reset to "
                            "default UNLIMITED — no per-turn cap)"
                        )
                    else:
                        print(
                            f"(per-turn input-token ceiling set to "
                            f"{val:,} tokens for this session — applies "
                            f"to every remaining turn until reset)"
                        )
                _print_user_separator(color=color)
                continue
            if (
                line == "/threshold-max-steps"
                or line.startswith("/threshold-max-steps ")
            ):
                # per-session max_steps override. Mirrors the
                #  /threshold-turn-input pattern. Useful when an
                # autonomous run needs more (or fewer) loop
                # iterations per turn than the spec's default. The
                # override persists for every remaining turn of
                # THIS session.
                parts = line.split(maxsplit=1)
                if len(parts) == 1:
                    try:
                        info = await client.get_thresholds()
                    except Exception as exc:
                        print(
                            f"Error fetching thresholds: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    ms = info.get("max_steps", {})
                    cur = ms.get("steps")
                    src = ms.get("source", "spec")
                    src_label = {
                        "session": "set via /threshold-max-steps "
                        "this session",
                        "spec": "agent's YAML default",
                    }.get(src, src)
                    print(
                        f"Per-turn max_steps\n"
                        f"  Current: {cur} steps  ({src_label})\n"
                        "  When the runner hits this number of\n"
                        "  iterations in a single turn it soft-lands\n"
                        "  with a final 'best answer from accumulated\n"
                        "  context' call. Higher = more exploration\n"
                        "  budget per turn (and more cost).\n"
                        "Change with:\n"
                        "  /threshold-max-steps 60     loosen for\n"
                        "                              long autonomous\n"
                        "                              runs (conductor\n"
                        "                              cycles often need\n"
                        "                              this)\n"
                        "  /threshold-max-steps 15     tighten for\n"
                        "                              focused turns\n"
                        "  /threshold-max-steps reset  revert to spec\n"
                        "                              default"
                    )
                else:
                    arg = parts[1].strip()
                    if arg.lower() == "reset":
                        steps_arg = None
                    else:
                        try:
                            steps_arg = int(arg)
                            if steps_arg <= 0:
                                raise ValueError
                        except ValueError:
                            print(
                                f"Invalid steps: {arg!r}. Examples: "
                                "`/threshold-max-steps 60`, "
                                "`/threshold-max-steps 15`, "
                                "`/threshold-max-steps reset`."
                            )
                            _print_user_separator(color=color)
                            continue
                    try:
                        info = await client.set_max_steps(steps_arg)
                    except Exception as exc:
                        print(
                            f"Error: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    val = info.get("max_steps")
                    if val is None:
                        print(
                            "(max_steps reset — falls back to spec "
                            "default for the current agent)"
                        )
                    else:
                        print(
                            f"(max_steps set to {val} for this session — "
                            "applies to every remaining turn until reset)"
                        )
                _print_user_separator(color=color)
                continue
            if (
                line == "/threshold-total-steps"
                or line.startswith("/threshold-total-steps ")
            ):
                # per-session max_total_steps override.
                # Session-cumulative step counter (all turns + all
                # spawned subagents). When it crosses, the runner
                # hard-halts with MaxTotalStepsExceeded and the
                # only recovery was starting a new session
                # (re-paying the loaded codebase context). With
                # this slash command users can raise the ceiling
                # mid-session.
                parts = line.split(maxsplit=1)
                if len(parts) == 1:
                    try:
                        info = await client.get_thresholds()
                    except Exception as exc:
                        print(
                            f"Error fetching thresholds: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    ts = info.get("total_steps", {})
                    cur = ts.get("steps")
                    used = int(ts.get("used", 0) or 0)
                    src = ts.get("source", "default")
                    src_label = {
                        "session": "set via /threshold-total-steps "
                        "this session",
                        "default": "construction-time default",
                    }.get(src, src)
                    pct = int(100 * used / cur) if cur else 0
                    print(
                        f"Session-cumulative max_total_steps\n"
                        f"  Current: {cur} steps  ({src_label})\n"
                        f"  Used:    {used} steps  ({pct}%)\n"
                        f"  Remaining: {max(cur - used, 0)} steps\n"
                        "  Counts every LLM round-trip across every\n"
                        "  turn and every spawned subagent. Halts the\n"
                        "  whole session with no recovery once exceeded.\n"
                        "Change with:\n"
                        "  /threshold-total-steps 500    raise for long\n"
                        "                                 autonomous runs\n"
                        "  /threshold-total-steps reset  revert to\n"
                        "                                 construction\n"
                        "                                 default"
                    )
                else:
                    arg = parts[1].strip()
                    if arg.lower() == "reset":
                        steps_arg = None
                    else:
                        try:
                            steps_arg = int(arg)
                            if steps_arg <= 0:
                                raise ValueError
                        except ValueError:
                            print(
                                f"Invalid steps: {arg!r}. Examples: "
                                "`/threshold-total-steps 500`, "
                                "`/threshold-total-steps 1000`, "
                                "`/threshold-total-steps reset`."
                            )
                            _print_user_separator(color=color)
                            continue
                    try:
                        info = await client.set_total_steps(steps_arg)
                    except Exception as exc:
                        print(
                            f"Error: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    val = info.get("total_steps")
                    if val is None:
                        print(
                            "(max_total_steps reset — reverts to the "
                            "construction-time default)"
                        )
                    else:
                        print(
                            f"(max_total_steps set to {val} for this "
                            "session — applies to all remaining turns "
                            "and spawned subagents until reset)"
                        )
                _print_user_separator(color=color)
                continue
            if line == "/agents":
                #  UAT — list valid master agents the user can switch
                # to via /agent <name>. Filtered by this session's
                # channel ("cli" for remote chat) so the list shows only
                # agents that would actually accept the switch.
                # also populates agent_index_map so /agent N
                # accepts a numeric shortcut from the listing.
                try:
                    info = await client.list_agents(channel="cli")
                except Exception as exc:
                    print(
                        f"Error fetching agent list: "
                        f"{type(exc).__name__}: {exc}",
                        file=sys.stderr,
                    )
                    _print_user_separator(color=color)
                    continue
                # Pin types explicitly: `info` is `dict[str, Any]` so
                # `info.get(...)` returns `Any` and the `or []`
                # short-circuit doesn't narrow. The local name
                # `details` is also bound in this same function at
                # ~L3050 (`details = await _fetch_agent_details(...)`,
                # `dict[str, Any] | None`), so mypy unions both
                # bindings — `cast` to a different name (`agent_rows`)
                # avoids the rebinding-induced widening and gives the
                # listcomp + later iteration a clean type.
                agent_rows: list[dict[str, Any]] = cast(
                    list[dict[str, Any]], info.get("details") or [],
                )
                # `d.get("name") or "?"` (not `d.get("name", "?")`)
                # preserves exact behavioural parity with the pre-
                # narrowing code: when `d["name"]` is explicitly
                # None the listcomp must NOT yield the literal
                # string "None" — that would change observable
                # output for the rare server payload that emits
                # `{"name": null}` instead of omitting the key.
                names: list[str] = info.get("agents") or [
                    d.get("name") or "?" for d in agent_rows
                ]
                # refresh the index map every call. Reset first so
                # a stale entry from a prior /agents (with different
                # registry contents) doesn't leak.
                agent_index_map.clear()
                if not names:
                    print("(no agents available on this channel)")
                else:
                    # Compute the width needed so [001], [002], ...
                    # [025] all align cleanly when N >= 10.
                    width = len(str(len(names)))
                    print(f"Available masters ({len(names)}):")
                    # Print each on its own line with description
                    # snippet (one-line) so the user can see what each
                    # is for without going to /capabilities.  — each
                    # row gets a [N] prefix; that N can be passed to
                    # /agent as a shortcut for the long name.
                    for idx, d in enumerate(agent_rows, start=1):
                        name = d.get("name", "?")
                        agent_index_map[idx] = name
                        desc = (d.get("description") or "").strip()
                        first_line = desc.split("\n", 1)[0][:80]
                        prefix = f"  [{idx:>{width}}] {name}"
                        if first_line:
                            print(f"{prefix}  —  {first_line}")
                        else:
                            print(prefix)
                    print(
                        "Switch with `/agent <name>` or `/agent <number>` "
                        "(e.g. `/agent 3`). Conversation history carries "
                        "forward."
                    )
                _print_user_separator(color=color)
                continue
            if line == "/agent" or line.startswith("/agent "):
                # switch the active master agent mid-session.
                # `/agent` (no arg)  → usage hint.
                # `/agent <name>`    → switch to that master, carrying chat
                #                      history forward. The new master sees
                #                      a synthetic UserMessage marking the
                #                      handoff (so it doesn't conflate prior
                #                      tool calls — made under the previous
                #                      master's system prompt — with its
                #                      own).
                parts = line.split(maxsplit=1)
                if len(parts) == 1:
                    print(
                        "Usage: /agent <name|number>\n"
                        "  Switches the active master agent. Conversation "
                        "history carries forward; a synthetic handoff "
                        "message is inserted so the new agent treats prior "
                        "context as background.\n"
                        "  Run /agents first to see the list — then\n"
                        "  /agent <number> uses the [N] from that listing\n"
                        "  as a shortcut for the long name .\n"
                        "  Use /capabilities to see the current master."
                    )
                else:
                    target = parts[1].strip()
                    if not target:
                        print("Usage: /agent <name|number>")
                        _print_user_separator(color=color)
                        continue
                    # numeric shortcut: if the arg is a positive
                    # integer, look it up in the agent_index_map that
                    # /agents populated. Falls through to the
                    # name-as-given path on any miss so a user typing
                    # an agent literally named "3" (unlikely but legal)
                    # still works as a name match on the server side.
                    if target.isdigit():
                        idx = int(target)
                        if not agent_index_map:
                            print(
                                "Numeric shortcut requires running "
                                "`/agents` first to populate the listing. "
                                "Run /agents, then try /agent <number> "
                                "again.",
                                file=sys.stderr,
                            )
                            _print_user_separator(color=color)
                            continue
                        resolved = agent_index_map.get(idx)
                        if resolved is None:
                            print(
                                f"`{target}` is out of range (last "
                                f"/agents listed {len(agent_index_map)} "
                                f"agents). Re-run /agents to refresh "
                                f"the list, or use the agent name "
                                f"directly.",
                                file=sys.stderr,
                            )
                            _print_user_separator(color=color)
                            continue
                        # Tell the user what we resolved to so the
                        # subsequent confirmation message isn't a
                        # surprise.
                        print(f"(resolved /agent {target} → `{resolved}`)")
                        target = resolved
                    try:
                        result = await client.set_master(target)
                    except httpx.HTTPStatusError as exc:
                        # Server returned 4xx with a clear detail
                        try:
                            detail = exc.response.json().get("detail", "")
                        except Exception:
                            detail = exc.response.text
                        #  UAT finding: a 404 with detail "Not Found"
                        # means the server doesn't have the /set_master
                        # endpoint at all — i.e. the deployed
                        # master-agents-api container is older than the
                        # CLI. Surface a more helpful message so the user
                        # knows to redeploy rather than thinking the
                        # agent name was bad.
                        if (
                            exc.response.status_code == 404
                            and "Not Found" in str(detail)
                        ):
                            print(
                                f"Cannot switch to {target!r}: server has "
                                f"no /set_master endpoint. The deployed "
                                f"master-agents-api container is older "
                                f"than this CLI . Rebuild + restart the "
                                f"container, then retry.",
                                file=sys.stderr,
                            )
                        else:
                            print(
                                f"Cannot switch to {target!r}: {detail}",
                                file=sys.stderr,
                            )
                        _print_user_separator(color=color)
                        continue
                    except Exception as exc:
                        print(
                            f"Error switching agent: "
                            f"{type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    prev = result.get("previous_master")
                    new = result.get("new_master")
                    #  follow-up — update the producer's `master`
                    # closure so the agent-separator label printed at
                    # the top of every subsequent turn shows the new
                    # master, not the stale one captured at session
                    # creation. Without this, /agent appeared to
                    # succeed but the chat label kept saying the old
                    # name AND the runtime correctly used the new
                    # master — confusing UX (UAT-found 2026-05-04).
                    if isinstance(new, str) and new:
                        master = new
                    print(
                        f"(switched from `{prev}` to `{new}` — chat history "
                        f"carries forward; handoff message inserted)"
                    )
                _print_user_separator(color=color)
                continue
            # /threshold-ask-user is a  descriptive alias for /budget.
            # The / cost-gate gates content reads BEFORE they happen,
            # forcing ask_user when the cumulative estimate_tokens accumulator
            # crosses the threshold (tier_2). The handler below handles both
            # forms identically.
            if (
                line == "/budget"
                or line.startswith("/budget ")
                or line == "/threshold-ask-user"
                or line.startswith("/threshold-ask-user ")
            ):
                # empty form → print usage + current state hint;
                # arg form → set or reset the cost-gate threshold.
                parts = line.split(maxsplit=1)
                if len(parts) == 1:
                    # show CURRENT effective threshold + source.
                    try:
                        info = await client.get_thresholds()
                    except Exception as exc:
                        print(
                            f"Error fetching thresholds: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    b = info.get("budget", {})
                    cur = int(b.get("tokens", 0))
                    src = b.get("source", "default")
                    src_label = {
                        "session": "set via /threshold-ask-user this session",
                        "spec": "set in agent YAML",
                        "default": "global default",
                    }.get(src, src)
                    print(
                        f"Threshold (ask-user /  cost gate)\n"
                        f"  Current: {cur:,} tokens  ({src_label})\n"
                        f"  tier_1 ≤ {cur:,} (auto-run)\n"
                        f"  tier_2 {cur+1:,}..{cur*2:,} (gates → ask_user)\n"
                        f"  tier_3 > {cur*2:,} (auto-rejected)\n"
                        "Set with:\n"
                        "  /threshold-ask-user 50k    tighten to 50K\n"
                        "  /threshold-ask-user 200000 raw integer\n"
                        "  /threshold-ask-user 1.5M   loosen\n"
                        "  /threshold-ask-user reset  revert to default (100K)\n"
                        "Aliases: /budget = /threshold-ask-user (same command)"
                    )
                else:
                    parsed = _parse_budget_arg(parts[1])
                    if parsed is None:
                        print(
                            f"Invalid budget: {parts[1]!r}. Examples: "
                            "`/budget 50k`, `/budget 200000`, `/budget reset`."
                        )
                        _print_user_separator(color=color)
                        continue
                    tokens_arg = None if parsed == "reset" else parsed
                    try:
                        info = await client.set_budget(tokens_arg)
                    except Exception as exc:
                        print(
                            f"Error: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    if info.get("budget") is None:
                        print(
                            "(budget reset — falls back to spec setting "
                            "or 100K default)"
                        )
                    else:
                        b = int(info["budget"])
                        t2 = int(info["tier_2_at"])
                        t3 = int(info["tier_3_at"])
                        print(
                            f"(budget set to {b:,} tokens for this "
                            f"session — tier_2 at {t2:,}, tier_3 at {t3:,})"
                        )
                _print_user_separator(color=color)
                continue
            if line == "/memory" or line.startswith("/memory "):
                # v3.3.0 — memory curation slash command.
                #   /memory                   list user-scope keys
                #                             (with updated_at + preview)
                #   /memory list [agent]      list user-scope OR this
                #                             agent's agent-scope
                #   /memory get <key> [agent] show full value
                #   /memory delete <key>      delete from user-scope (or
                #                             /memory delete agent <key>)
                # Discoverability surface for the /remember write path —
                # users need to see what they have before they can
                # forget anything.
                parts = line.split(maxsplit=2)
                if len(parts) == 1:
                    sub = "list"
                    sub_arg = ""
                else:
                    sub = parts[1].lower()
                    sub_arg = parts[2] if len(parts) > 2 else ""

                if sub == "help":
                    print(
                        "/memory — audit + curate persisted memory.\n"
                        "  /memory                       list user-scope keys\n"
                        "  /memory list                  list user-scope keys\n"
                        "  /memory list agent            list THIS agent's "
                        "agent-scope keys\n"
                        "  /memory get <key>             show full value "
                        "(user-scope)\n"
                        "  /memory get agent <key>       show full value "
                        "(this agent's agent-scope)\n"
                        "  /memory delete <key>          delete a user-scope "
                        "entry\n"
                        "  /memory delete agent <key>    delete this agent's "
                        "agent-scope entry"
                    )
                    _print_user_separator(color=color)
                    continue

                if sub == "list":
                    # v3.3.1 — parse sub_arg for scope + by-agent filter:
                    #   /memory list                      → user-scope, no filter
                    #   /memory list agent                → agent-scope (this agent)
                    #   /memory list by <agent_name>      → user-scope, filter by created_by_agent
                    #   /memory list agent by <agent_name>→ both (rare; allowed for completeness)
                    by_filter: str | None = None
                    tokens = sub_arg.strip().split()
                    if tokens and tokens[0].lower() == "agent":
                        scope = "agent"
                        qualifier = master
                        # consume 'agent', look for 'by <name>'
                        if len(tokens) >= 3 and tokens[1].lower() == "by":
                            by_filter = tokens[2]
                    elif len(tokens) >= 2 and tokens[0].lower() == "by":
                        scope = "user"
                        qualifier = ""
                        by_filter = tokens[1]
                    else:
                        scope = "user"
                        qualifier = ""
                    try:
                        # v3.3.1 — pass the by_filter via memory_list_curate
                        # (we extend the call below; for now the client
                        # method passes it through as a kwarg the endpoint
                        # accepts).
                        info = await client.memory_list_curate(
                            scope, qualifier,
                            created_by_agent=by_filter,
                        )
                    except Exception as exc:
                        print(
                            f"Error: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    total = info.get("total", 0)
                    entries = info.get("keys", [])
                    qual_part = (
                        f" (this agent: {master})" if scope == "agent"
                        else " (cross-cutting)"
                    )
                    filter_part = (
                        f" — saved while chatting with {by_filter!r}"
                        if by_filter else ""
                    )
                    print(
                        f"{total} memory key(s) in {scope}-scope"
                        f"{qual_part}{filter_part}:"
                    )
                    if not entries:
                        print("  (none)")
                    else:
                        # Fetch values for short previews. N+1 round-
                        # trips but N is small (capped at 200) and this
                        # is interactive UI, not a hot path.
                        for entry in entries:
                            key = entry["key"]
                            ts = entry.get("updated_at", "?")
                            chars = entry["value_chars"]
                            # v3.3.1 — show provenance ("[via <agent>]")
                            # alongside each entry so user can see who
                            # was active when the fact was saved.
                            by = entry.get("created_by_agent") or "?"
                            try:
                                got = await client.memory_get_curate(
                                    scope, key, qualifier,
                                )
                                value = got.get("value", "")
                                preview = (
                                    value if len(value) <= 60
                                    else value[:60] + "..."
                                )
                            except Exception:
                                preview = "<value fetch failed>"
                            print(
                                f"  {ts}  [via {by:<22s}] "
                                f"{key:<30s} ({chars:>5,} chars)  {preview}"
                            )
                    _print_user_separator(color=color)
                    continue

                if sub == "get":
                    # /memory get <key>          → user-scope
                    # /memory get agent <key>    → agent-scope
                    arg_parts = sub_arg.split(maxsplit=1)
                    if not arg_parts:
                        print(
                            "/memory get: missing <key>. "
                            "Usage: /memory get <key> | /memory get agent <key>"
                        )
                        _print_user_separator(color=color)
                        continue
                    if arg_parts[0].lower() == "agent" and len(arg_parts) == 2:
                        scope = "agent"
                        qualifier = master
                        key = arg_parts[1].strip()
                    else:
                        scope = "user"
                        qualifier = ""
                        key = sub_arg.strip()
                    try:
                        got = await client.memory_get_curate(
                            scope, key, qualifier,
                        )
                    except Exception as exc:
                        msg = f"{type(exc).__name__}: {exc}"
                        if "404" in msg:
                            print(
                                f"Not found: {scope}:{qualifier}:{key}",
                                file=sys.stderr,
                            )
                        else:
                            print(f"Error: {msg}", file=sys.stderr)
                        _print_user_separator(color=color)
                        continue
                    print(
                        f"{scope}-scope key={key!r} "
                        f"(updated {got.get('updated_at', '?')}, "
                        f"{got.get('value_chars', 0):,} chars):"
                    )
                    print(got.get("value", ""))
                    _print_user_separator(color=color)
                    continue

                if sub == "delete":
                    # /memory delete <key>           → user-scope
                    # /memory delete agent <key>     → agent-scope
                    arg_parts = sub_arg.split(maxsplit=1)
                    if not arg_parts:
                        print(
                            "/memory delete: missing <key>. "
                            "Usage: /memory delete <key> | "
                            "/memory delete agent <key>"
                        )
                        _print_user_separator(color=color)
                        continue
                    if arg_parts[0].lower() == "agent" and len(arg_parts) == 2:
                        scope = "agent"
                        qualifier = master
                        key = arg_parts[1].strip()
                    else:
                        scope = "user"
                        qualifier = ""
                        key = sub_arg.strip()
                    # Confirmation prompt — bad delete is hard to undo
                    # unless you remember the value.
                    print(
                        f"Delete {scope}-scope key={key!r}?",
                        file=sys.stderr,
                    )
                    # Plain input() — blocks the event loop briefly but
                    # that's fine for a confirmation prompt in the
                    # interactive REPL (no concurrent work to interleave
                    # with). Matches the pattern used by other slash
                    # commands that need user confirmation.
                    try:
                        answer = input("  Confirm [y/N]: ")
                    except (KeyboardInterrupt, EOFError):
                        print("\n(aborted)")
                        _print_user_separator(color=color)
                        continue
                    if answer.strip().lower() not in ("y", "yes"):
                        print("(aborted)")
                        _print_user_separator(color=color)
                        continue
                    try:
                        result = await client.memory_delete_curate(
                            scope, key, qualifier,
                        )
                    except Exception as exc:
                        print(
                            f"Error: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    if result.get("existed"):
                        print(f"(deleted {scope}-scope key={key!r})")
                    else:
                        print(
                            f"({scope}-scope key={key!r} was not "
                            f"present — no-op)"
                        )
                    _print_user_separator(color=color)
                    continue

                # Unknown subcommand.
                print(
                    f"/memory: unknown subcommand {sub!r}. "
                    "Use `/memory help` for the full list."
                )
                _print_user_separator(color=color)
                continue
            if line == "/remember" or line.startswith("/remember "):
                # v3.1.0 — user-driven fact save to user-scope memory.
                # `/remember <text>` saves to auto-keyed entry;
                # `/remember <key>=<text>` saves with explicit key.
                # On next session start, the fact appears in every
                # agent's <memory> block auto-load.
                parts = line.split(maxsplit=1)
                if len(parts) == 1:
                    print(
                        "/remember: save a fact to user-scope memory.\n"
                        "Usage:\n"
                        "  /remember <text>           "
                        "auto-keyed (note_<UTC-timestamp>)\n"
                        "  /remember <key>=<text>     "
                        "explicit key (1-64 chars [A-Za-z0-9_-])\n"
                        "User-scope facts auto-load into every agent's "
                        "<memory> block on the next session start."
                    )
                    _print_user_separator(color=color)
                    continue
                raw = parts[1]
                # Parse `key=text` if present; else auto-key.
                explicit_key: str | None = None
                fact_text = raw
                if "=" in raw:
                    candidate_key, _, rest = raw.partition("=")
                    candidate_key = candidate_key.strip()
                    # Only treat as key=text when the LHS looks like a
                    # valid slug AND there's content after `=`. Avoids
                    # mistaking `/remember a=1, b=2` (a freeform fact
                    # containing `=`) for an explicit key.
                    import re as _re
                    if (
                        rest.strip()
                        and _re.fullmatch(
                            r"[A-Za-z0-9_-]{1,64}", candidate_key,
                        )
                    ):
                        explicit_key = candidate_key
                        fact_text = rest.strip()
                try:
                    info = await client.remember(
                        fact_text, key=explicit_key,
                    )
                except Exception as exc:
                    print(
                        f"Error: {type(exc).__name__}: {exc}",
                        file=sys.stderr,
                    )
                    _print_user_separator(color=color)
                    continue
                saved_key = info.get("key", "?")
                chars = info.get("value_chars", len(fact_text))
                print(
                    f"(remembered — user-scope, key={saved_key}, "
                    f"{chars} chars. Visible in all agents' <memory> "
                    f"block from the NEXT session.)"
                )
                _print_user_separator(color=color)
                continue
            if line in ("/clear", "/reset"):
                try:
                    info = await client.reset()
                except Exception as exc:
                    print(
                        f"Error: {type(exc).__name__}: {exc}",
                        file=sys.stderr,
                    )
                    _print_user_separator(color=color)
                    continue
                cleared = info.get("messages_cleared", 0)
                print(f"(history cleared — {cleared} messages dropped)")
                _print_user_separator(color=color)
                continue
            # ── E44 (2026-05-13) — /auto-approve toggle ──────────
            if line == "/auto-approve" or line.startswith("/auto-approve "):
                parts = line.split(maxsplit=1)
                sub = parts[1].strip().lower() if len(parts) >= 2 else "status"
                if sub == "status":
                    cur = "on" if state.get("auto_approve") else "off"
                    print(f"/auto-approve: currently {cur}.")
                    print(
                        "Usage: /auto-approve on   — auto-grant every needs_approval\n"
                        "       /auto-approve off  — restore interactive prompts (default)\n"
                        "       /auto-approve      — show current setting"
                    )
                elif sub == "on":
                    if state.get("auto_approve"):
                        print("/auto-approve: already on (no change).")
                    else:
                        state["auto_approve"] = True
                        print(
                            "/auto-approve: ON. All subsequent tool-approval "
                            "events will auto-grant with a [auto-approve] stderr "
                            "breadcrumb. Type `/auto-approve off` to restore "
                            "interactive prompts."
                        )
                elif sub == "off":
                    if not state.get("auto_approve"):
                        print("/auto-approve: already off (no change).")
                    else:
                        state["auto_approve"] = False
                        print(
                            "/auto-approve: OFF. Interactive approval prompts "
                            "restored for subsequent tool calls."
                        )
                else:
                    print(
                        f"/auto-approve: unknown argument {sub!r}. "
                        "Use `on`, `off`, or leave blank for status."
                    )
                _print_user_separator(color=color)
                continue
            # ── E42 (2026-05-13) — /bg + /tasks ──────────────────
            if line == "/bg" or line.startswith("/bg "):
                parts = line.split(maxsplit=2)
                if len(parts) < 3:
                    print(
                        "/bg: spawn a parallel agent run in the background.\n"
                        "Usage: /bg <agent> <prompt>\n"
                        "Example: /bg simos_consultant \"summarise SimOS architecture\"\n"
                        "The foreground REPL stays responsive while the\n"
                        "background agent works. Inspect with /tasks list,\n"
                        "/tasks status <id>, /tasks kill <id>.\n"
                        "Note: bg tasks die with the chat session — for\n"
                        "durable long runs, use `mao-client remote run\n"
                        "--detach <agent> <prompt>` in a separate terminal."
                    )
                    _print_user_separator(color=color)
                    continue
                _bg_agent = parts[1]
                _bg_prompt = parts[2]
                _bg_task_id = uuid.uuid4().hex[:8]
                _bg_record = _BgTask(
                    task_id=_bg_task_id,
                    agent=_bg_agent,
                    prompt=_bg_prompt,
                    started_at=time.monotonic(),
                    started_wall=time.time(),
                )
                _bg_record.asyncio_task = asyncio.create_task(
                    _run_bg_task(cfg, _bg_agent, _bg_prompt, _bg_record),
                )
                bg_tasks[_bg_task_id] = _bg_record
                _bg_preview = (
                    _bg_prompt if len(_bg_prompt) <= 60
                    else _bg_prompt[:57] + "..."
                )
                print(
                    f"[bg:{_bg_task_id}] started — {_bg_agent}: {_bg_preview}"
                )
                _print_user_separator(color=color)
                continue
            if line == "/tasks" or line.startswith("/tasks "):
                parts = line.split(maxsplit=2)
                sub = parts[1].lower() if len(parts) >= 2 else "list"
                if sub == "list":
                    if not bg_tasks:
                        print("(no /bg tasks running in this session)")
                    else:
                        print(
                            f"{'id':<10}{'status':<11}{'agent':<24}"
                            f"{'elapsed':<10}prompt"
                        )
                        for _tid, _t in bg_tasks.items():
                            _el = _format_elapsed(
                                time.monotonic() - _t.started_at,
                            )
                            _pp = (
                                _t.prompt if len(_t.prompt) <= 40
                                else _t.prompt[:37] + "..."
                            )
                            print(
                                f"{_tid:<10}{_t.status:<11}"
                                f"{_t.agent:<24}{_el:<10}{_pp}"
                            )
                    _print_user_separator(color=color)
                    continue
                if sub == "status":
                    if len(parts) < 3:
                        print("/tasks status: usage: /tasks status <task_id>")
                        _print_user_separator(color=color)
                        continue
                    _tid = parts[2].strip()
                    _t = bg_tasks.get(_tid)
                    if _t is None:
                        print(f"/tasks status: no bg task with id {_tid!r}")
                        _print_user_separator(color=color)
                        continue
                    _el = _format_elapsed(time.monotonic() - _t.started_at)
                    print(f"task_id:     {_t.task_id}")
                    print(f"agent:       {_t.agent}")
                    print(f"status:      {_t.status}")
                    print(f"elapsed:     {_el}")
                    print(f"prompt:      {_t.prompt}")
                    if _t.session_id:
                        print(f"session_id:  {_t.session_id}")
                    if _t.status == "completed" and _t.result:
                        _ans = _t.result
                        if len(_ans) > 800:
                            print(f"answer:      {_ans[:800]}...")
                            print(
                                f"             ({len(_ans) - 800} more chars; "
                                "full answer in record)"
                            )
                        else:
                            print(f"answer:      {_ans}")
                    elif _t.error:
                        print(f"error:       {_t.error}")
                    _print_user_separator(color=color)
                    continue
                if sub == "kill":
                    if len(parts) < 3:
                        print("/tasks kill: usage: /tasks kill <task_id>")
                        _print_user_separator(color=color)
                        continue
                    _tid = parts[2].strip()
                    _t = bg_tasks.get(_tid)
                    if _t is None:
                        print(f"/tasks kill: no bg task with id {_tid!r}")
                        _print_user_separator(color=color)
                        continue
                    if _t.status not in ("starting", "running"):
                        print(
                            f"/tasks kill: bg task {_tid} already "
                            f"{_t.status} — nothing to cancel."
                        )
                        _print_user_separator(color=color)
                        continue
                    if _t.asyncio_task is not None:
                        _t.asyncio_task.cancel()
                    print(f"[bg:{_tid}] cancellation requested.")
                    _print_user_separator(color=color)
                    continue
                print(
                    f"/tasks: unknown subcommand {sub!r}. "
                    "Use `list`, `status <id>`, or `kill <id>`."
                )
                _print_user_separator(color=color)
                continue
            if line == "/compact":
                try:
                    info = await client.compact()
                except Exception as exc:
                    print(
                        f"Error: {type(exc).__name__}: {exc}",
                        file=sys.stderr,
                    )
                    _print_user_separator(color=color)
                    continue
                if info.get("status") == "no_op":
                    msg_count = info.get("message_count")
                    min_count = info.get("min_messages_to_compact")
                    history_tokens = info.get("history_tokens")
                    # history_tokens guarded separately — server may omit
                    # it on certain no_op shapes (e.g. the service),
                    # and `f"{None:,}"` crashes with the 2026-05-09 bug
                    # class. See master_agents_os/CLAUDE.md "Spec field
                    # defaults" for the canonical reference.
                    if msg_count is not None and min_count is not None:
                        if history_tokens is not None:
                            print(
                                f"(nothing to compact: {msg_count} messages "
                                f"in history, need ≥{min_count} before "
                                f"compaction kicks in. ~{history_tokens:,} "
                                "tokens of history right now.)"
                            )
                        else:
                            print(
                                f"(nothing to compact: {msg_count} messages "
                                f"in history, need ≥{min_count} before "
                                "compaction kicks in.)"
                            )
                    else:
                        print("(nothing to compact)")
                else:
                    print(
                        f"(compacted: {info.get('removed_messages', 0)} messages folded; "
                        f"{info.get('before_tokens', 0):,} → "
                        f"{info.get('after_tokens', 0):,} tokens)"
                    )
                _print_user_separator(color=color)
                continue

            # Normal turn dispatch.
            _print_agent_separator(color=color, agent=master)
            turn_busy.set()
            try:
                result = await client.turn(line)
            except SessionEndedError as exc:
                # Server-side cancellation (F1 timeout, container
                # restart, explicit cancel). The session is dead —
                # every subsequent turn would hit the same 410, so
                # we EXIT the chat loop instead of looping on errors.
                # Run-path exits 1 (script-callable signal). Chat
                # path exits 0 because the user is interactive and
                # already saw the message; "exit code" matters only
                # if the chat REPL itself was scripted, which is
                # rare. Error class is distinct from generic
                # `Exception` so this branch fires before the
                # catch-all below.
                #
                # E39 (2026-05-13): surface the session_id + resume
                # hints. The dead session is fully recoverable via
                # /sessions/{id}/rehydrate. Auto-arm both storage
                # paths so `--resume <id>` AND `--resume-last` work
                # after abnormal end (the prior message only said
                # "start a new session" — actively misled users away
                # from the recovery path that existed).
                session_id = client.session_id
                nonce = client.nonce
                if session_id and nonce:
                    _save_active_session(
                        server=cfg.server,
                        agent_name=master,
                        session_id=session_id,
                        nonce=nonce,
                    )
                    write_last_session_id(master, session_id)
                    print(
                        f"\n[Session ended] {exc}\n"
                        f"  session_id={session_id}\n"
                        f"  Resume with: agents remote chat --resume {session_id}\n"
                        f"  Or:          agents remote chat --resume-last\n",
                        file=sys.stderr,
                    )
                else:
                    # Session never reached server. No id to surface.
                    print(
                        f"\n[Session ended] {exc}\n"
                        f"Chat ended; reopen with `agents remote chat` "
                        f"to start a new session.",
                        file=sys.stderr,
                    )
                turn_busy.clear()
                state["intent"] = "destroy"
                state["should_exit"] = True
                # P3 follow-up: wake the producer immediately. Without
                # this, the producer is still awaiting `read_prompt`
                # and gather waits for the user's next keystroke. The
                # producer task is stashed on state by the gather
                # caller; cancelling it makes asyncio.gather return
                # right away with CancelledError, which the caller's
                # try/except absorbs cleanly.
                producer_task = state.get("_producer_task")
                if producer_task is not None and not producer_task.done():
                    producer_task.cancel()
                break
            except Exception as exc:
                print(
                    f"Error: {type(exc).__name__}: {exc}",
                    file=sys.stderr,
                )
                turn_busy.clear()
                _print_user_separator(color=color)
                continue
            finally:
                turn_busy.clear()
            _print_answer(result, markdown=markdown)
            if client.last_tokens:
                _print_remote_token_line(
                    client.last_tokens,
                    color=color,
                    duration_s=client.last_turn_seconds,
                    cost_summary=client.last_cost_summary,
                    cap_info=client.last_cap,
                )
            # Print user separator NOW so the next prompt has a clean
            # boundary above it (whether it comes from queued input or
            # fresh user typing).
            _print_user_separator(color=color)

    # P3 follow-up (2026-05-07): wrap the producer as an explicit task
    # so the consumer can cancel it on consumer-initiated termination
    # (e.g. SessionEndedError — server-side cancel cancels every
    # subsequent prompt before it lands, so we exit the REPL instead
    # of looping). Without this wrapping, the producer awaits
    # `read_prompt("> ")` with no timeout; even after the consumer
    # sets `should_exit=True` and breaks, gather doesn't return until
    # the user presses any key. Cancelling the producer task surfaces
    # the exit immediately.
    producer_task = asyncio.create_task(_producer())
    state["_producer_task"] = producer_task  # consumer reads this to cancel
    try:
        with stdout_patch:
            await asyncio.gather(producer_task, _consumer())
    except asyncio.CancelledError:
        # Producer cancellation propagates here when the consumer
        # cancels it on SessionEndedError. Treat as clean exit (we
        # already printed `[Session ended]` from the consumer).
        pass
    finally:
        # Defensive: ensure the producer task is finished, even if
        # gather aborted before it returned naturally.
        if not producer_task.done():
            producer_task.cancel()
            try:
                await producer_task
            except (asyncio.CancelledError, Exception):
                pass
        # E42 (2026-05-13): cancel any /bg tasks still running. They
        # are tied to the chat session lifetime — operator-level
        # parallelism, NOT durable background work. Surface a count
        # if anything was cancelled so the operator knows what got
        # cut. For durable runs use `mao-client remote run --detach`.
        _live_bg = [
            t for t in bg_tasks.values()
            if t.status in ("starting", "running") and t.asyncio_task is not None
        ]
        if _live_bg:
            print(
                f"(cancelling {len(_live_bg)} /bg task"
                f"{'s' if len(_live_bg) != 1 else ''} on exit — "
                "their server sessions will be destroyed; for durable "
                "long runs use `mao-client remote run --detach`)",
                file=sys.stderr,
            )
            for _t in _live_bg:
                _t.asyncio_task.cancel()
            # Drain so the underlying clients close cleanly.
            try:
                await asyncio.gather(
                    *(t.asyncio_task for t in _live_bg),
                    return_exceptions=True,
                )
            except Exception:
                pass
        if state["intent"] == "detach" and client.session_id and client.nonce:
            _save_active_session(
                server=cfg.server,
                agent_name=master,
                session_id=client.session_id,
                nonce=client.nonce,
            )
            sid = client.session_id
            print(
                f"(detached — session {sid[:12]}… kept alive on the "
                "server. Next `agents remote chat` will offer to resume.)"
            )
            await client.detach()
        else:
            # Full destroy: clear the cache so a leftover detached
            # session from yesterday doesn't auto-offer alongside today's
            # explicit /exit.
            _clear_active_session()
            await client.close()
    return 0
