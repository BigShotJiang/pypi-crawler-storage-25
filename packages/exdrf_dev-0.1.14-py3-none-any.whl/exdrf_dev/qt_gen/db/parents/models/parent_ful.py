# This file was automatically generated using the exdrf_gen package.
# Source: exdrf_gen_al2qt.creator -> c/m/m_ful.py.j2
# Don't change it manually.

from typing import TYPE_CHECKING, Any, List, Optional, Tuple, Union

from sqlalchemy import select
from sqlalchemy.orm import joinedload, selectinload

from exdrf.constants import RecIdType
from exdrf_dev.qt_gen.db.parents.fields.fld_children import ChildrenField
from exdrf_dev.qt_gen.db.parents.fields.fld_created_at import CreatedAtField
from exdrf_dev.qt_gen.db.parents.fields.fld_id import IdField
from exdrf_dev.qt_gen.db.parents.fields.fld_is_active import IsActiveField
from exdrf_dev.qt_gen.db.parents.fields.fld_name import NameField
from exdrf_dev.qt_gen.db.parents.fields.fld_profile import ProfileField
from exdrf_dev.qt_gen.db.parents.fields.fld_tags import TagsField
from exdrf_qt.models import QtModel
from exdrf_qt.plugins import exdrf_qt_pm
from exdrf_qt.utils.plugins import safe_hook_call

# exdrf-keep-start other_imports ----------------------------------------------

# exdrf-keep-end other_imports ------------------------------------------------

if TYPE_CHECKING:
    from sqlalchemy import Select  # noqa: F401

    from exdrf.filter import FilterType  # noqa: F401
    from exdrf_dev.db.api import Parent  # noqa: F401
    from exdrf_qt.context import QtContext  # noqa: F401

from exdrf.filter import SearchType

# exdrf-keep-start other_globals ----------------------------------------------

# exdrf-keep-end other_globals ------------------------------------------------


def default_parent_list_selection():
    from exdrf_dev.db.api import Child as DbChild
    from exdrf_dev.db.api import Parent as DbParent
    from exdrf_dev.db.api import Profile as DbProfile
    from exdrf_dev.db.api import Tag as DbTag

    return (
        select(DbParent)
        .options(
            selectinload(DbParent.children).load_only(
                DbChild.data,
                DbChild.id,
            ),
            selectinload(DbParent.children)
            .joinedload(DbChild.parent)
            .load_only(
                DbParent.name,
            ),
        )
        .options(
            joinedload(DbParent.profile).load_only(
                DbProfile.bio,
                DbProfile.id,
            ),
        )
        .options(
            selectinload(DbParent.tags).load_only(
                DbTag.id,
                DbTag.name,
            ),
        )
    )


class QtParentFuMo(QtModel["Parent"]):
    """The model that contains all the fields of the Parent table."""

    # exdrf-keep-start other_attributes ---------------------------------------

    # exdrf-keep-end other_attributes -----------------------------------------

    def __init__(
        self,
        ctx: "QtContext",
        selection: Union["Select", None] = None,
        fields=None,
        **kwargs,
    ):
        from exdrf_dev.db.api import Parent as DbParent

        super().__init__(
            ctx=ctx,
            db_model=ctx.get_ovr("exdrf_dev.qt_gen.db.parents.ful.model", DbParent),
            selection=(
                selection if selection is not None else default_parent_list_selection()
            ),
            fields=(
                fields
                if fields is not None
                else [
                    ChildrenField,
                    CreatedAtField,
                    IsActiveField,
                    NameField,
                    ProfileField,
                    TagsField,
                    IdField,
                ]
            ),
            **kwargs,
        )

        # Inform plugins that the model has been created.
        safe_hook_call(exdrf_qt_pm.hook.parent_fumo_created, model=self)

    def get_primary_columns(self) -> Any:
        return self.db_model.id

    def get_db_item_id(self, item: "Parent") -> Union[int, Tuple[int, ...]]:
        return item.id

    def item_by_id_conditions(self, rec_id: RecIdType) -> List[Any]:
        """Return the conditions that filter by ID.

        Args:
            rec_id: The ID of the item to filter by.
        """
        return [self.db_model.id == rec_id]

    def text_to_filter(
        self,
        text: str,
        search_type: Optional[SearchType] = SearchType.EXTENDED,
        limit: Optional[str] = None,
    ) -> "FilterType":
        """Convert a text to a filter.

        The function converts a text to a filter. The text is converted to a
        filter using the `simple_search_fields` property.
        """
        filters = super().text_to_filter(text, search_type, limit)
        hook_exact = (
            search_type == SearchType.EXACT if search_type is not None else None
        )
        safe_hook_call(
            exdrf_qt_pm.hook.parent_fumo_ttf,
            model=self,
            filters=filters,
            text=text,
            exact=hook_exact,
            limit=limit,
        )
        return filters

        # exdrf-keep-start extra_init -----------------------------------------

        # exdrf-keep-end extra_init -------------------------------------------

    # exdrf-keep-start extra_fumo_content -------------------------------------

    # exdrf-keep-end extra_fumo_content ---------------------------------------


# exdrf-keep-start more_content -----------------------------------------------

# exdrf-keep-end more_content -------------------------------------------------
