# This file was automatically generated using the exdrf_gen package.
# Source: exdrf_gen_al2qt.creator -> c/m/field.py.j2
# Don't change it manually.

from typing import TYPE_CHECKING, Any, Optional

from attrs import define, field
from sqlalchemy.orm import aliased

from exdrf.constants import RecIdType
from exdrf_qt.models.fi_op import filter_op_registry
from exdrf_qt.models.fields import QtRefManyToOneField

# exdrf-keep-start other_imports ----------------------------------------------

# exdrf-keep-end other_imports ------------------------------------------------

if TYPE_CHECKING:
    from exdrf.filter import FieldFilter
    from exdrf.resource import ExResource  # noqa: F401
    from exdrf_dev.db.api import (
        CompositeKeyModel,  # noqa: F401
        RelatedItem,  # noqa: F401
    )
    from exdrf_qt.models.selector import Selector

# exdrf-keep-start other_globals ----------------------------------------------

# exdrf-keep-end other_globals ------------------------------------------------


@define
class CompKeyOwnerField(QtRefManyToOneField["RelatedItem"]):
    """ """

    name: str = field(default="comp_key_owner", init=False)
    title: str = field(default="Comp Key Owner")
    category: str = field(default="general")
    preferred_width: int = field(default=100)

    # exdrf-keep-start other_attributes ---------------------------------------

    # exdrf-keep-end other_attributes -----------------------------------------

    ref: "ExResource" = field(default=None, repr=False)

    def part_id(self, record: "CompositeKeyModel") -> RecIdType:
        """Compute the ID for one of the components of the field."""
        return (
            record.key_part1,
            record.key_part2,
        )

    def part_label(self, record: "CompositeKeyModel") -> str:
        """Compute the label for one of the components of the field."""
        return str("Description:") + str(record.description)

    def apply_filter(
        self,
        item: "FieldFilter",
        selector: "Selector",
        no_dia: Optional[str] = None,
    ) -> Any:
        from exdrf_dev.db.api import CompositeKeyModel as DbCompositeKeyModel

        predicate = filter_op_registry[item.op].predicate
        related_entity = getattr(self.resource.db_model, self.name)
        # M2O(CompositeKeyModel)
        subq = related_entity.has(
            predicate(DbCompositeKeyModel.description, item.vl),
        )
        return subq

        with_alias = aliased(DbCompositeKeyModel)
        predicate = filter_op_registry[item.op].predicate
        selector.joins.append(
            (
                with_alias,
                getattr(self.resource.db_model, self.name),
                {"isouter": True},
            )
        )

        return predicate(
            with_alias.description,
            item.vl,
        )

    # exdrf-keep-start extra_field_content ------------------------------------

    # exdrf-keep-end extra_field_content --------------------------------------


# exdrf-keep-start more_content -----------------------------------------------

# exdrf-keep-end more_content -------------------------------------------------
