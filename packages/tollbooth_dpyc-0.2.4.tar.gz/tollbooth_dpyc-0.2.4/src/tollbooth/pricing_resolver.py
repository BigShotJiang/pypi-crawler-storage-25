"""Pricing resolver — runtime cost lookup with TTL cache.

The resolver is the integration point MCP servers use to get dynamic tool
pricing.  It checks the active pricing model from Neon, caches it in
memory, and returns 0 on cache miss or Neon failure.

All lookups are by ``tool_id`` (UUID), not tool name.
"""

from __future__ import annotations

import logging
import time
from typing import Any

from tollbooth.constraints.config import load_constraints
from tollbooth.constraints.engine import ConstraintEngine
from tollbooth.pricing_model import PricingModel

logger = logging.getLogger(__name__)


class PricingResolver:
    """Runtime resolver for tool costs and constraint engines.

    Parameters
    ----------
    store:
        A ``PricingModelStore`` instance (or anything with
        ``fetch_active_model(operator) -> PricingModel | None``).
    operator:
        The operator identifier (npub) whose active model to resolve.
    cache_ttl:
        Time-to-live in seconds for the in-memory cache (default 300).
    """

    def __init__(
        self,
        *,
        store: Any,
        operator: str,
        cache_ttl: float = 300.0,
    ) -> None:
        self._store = store
        self._operator = operator
        self._cache_ttl = cache_ttl

        self._cached_model: PricingModel | None = None
        self._cached_cost_map: dict[str, int] | None = None
        self._cached_tool_ids: set[str] | None = None
        self._cached_engine: ConstraintEngine | None = None
        # Initialize to negative infinity so the first _is_stale() always
        # returns True — even if time.monotonic() is small (fresh CI runner).
        self._cache_ts: float = -self._cache_ttl - 1.0

    def _is_stale(self) -> bool:
        return (time.monotonic() - self._cache_ts) > self._cache_ttl

    async def _ensure_fresh(self) -> None:
        """Refresh the cache if stale.  Neon failure degrades gracefully."""
        if not self._is_stale():
            return

        try:
            model = await self._store.fetch_active_model(self._operator)
            self._cached_model = model
            if model is not None:
                self._cached_cost_map = model.tool_cost_map()
                self._cached_tool_ids = model.tool_id_set()
                constraint_cfg = model.to_constraint_config()
                if constraint_cfg is not None:
                    self._cached_engine = load_constraints(constraint_cfg)
                else:
                    self._cached_engine = None
            else:
                self._cached_cost_map = None
                self._cached_tool_ids = None
                self._cached_engine = None
            self._cache_ts = time.monotonic()
        except Exception:
            logger.warning(
                "Failed to refresh pricing model for %s; using cached/fallback",
                self._operator,
                exc_info=True,
            )
            # Keep existing cache (stale > nothing)
            if self._cache_ts < 0:
                # First call ever failed — mark as attempted so we don't
                # hammer Neon on every request
                self._cache_ts = time.monotonic()

    async def get_cost(self, tool_id: str) -> int:
        """Return the cost for *tool_id*.

        Returns 0 if the tool is not in the active model.
        """
        await self._ensure_fresh()
        if self._cached_cost_map is not None and tool_id in self._cached_cost_map:
            return self._cached_cost_map[tool_id]
        return 0

    async def has_tool(self, tool_id: str) -> bool:
        """Return True if *tool_id* has an explicit entry in the pricing model.

        Distinguishes "intentionally priced at 0" from "not in model at all".
        """
        await self._ensure_fresh()
        if self._cached_tool_ids is not None:
            return tool_id in self._cached_tool_ids
        return False

    async def has_tool_by_name(self, tool_name: str) -> bool:
        """Fallback lookup by tool_name for legacy models with string tool_ids."""
        await self._ensure_fresh()
        if self._cached_model is not None:
            return any(tp.tool_name == tool_name for tp in self._cached_model.tools)
        return False

    async def get_cost_by_name(self, tool_name: str) -> int:
        """Fallback cost lookup by tool_name for legacy models."""
        await self._ensure_fresh()
        if self._cached_model is not None:
            for tp in self._cached_model.tools:
                if tp.tool_name == tool_name:
                    return tp.price_sats
        return 0

    async def get_tool_pricing(self, tool_id: str) -> "ToolPricing":
        """Return a ToolPricing for *tool_id*, supporting ad valorem pricing.

        Returns a free ToolPricing if the tool is not in the active model.
        """
        from tollbooth.pricing import ToolPricing

        await self._ensure_fresh()
        if self._cached_model is not None:
            for tp in self._cached_model.tools:
                if tp.tool_id == tool_id:
                    return tp.to_tool_pricing()
        return ToolPricing(fixed=0)

    async def get_constraint_engine(self) -> ConstraintEngine | None:
        """Return the constraint engine from the active model's pipeline.

        Returns ``None`` if no active model or no pipeline defined.
        """
        await self._ensure_fresh()
        return self._cached_engine

    def refresh(self) -> None:
        """Force cache reset — call after Pricing Studio activates a model."""
        self._cache_ts = -self._cache_ttl - 1.0
