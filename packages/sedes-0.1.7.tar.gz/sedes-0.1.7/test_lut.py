"""
MOSFET LUT demo — design-oriented plots and gm/Id sizing.

Run with:
    uv run python test_lut.py
"""

import matplotlib.pyplot as plt
from sedes import SimulationPool, LutConfig

pool = SimulationPool(workers=8)

# ─────────────────────────────────────────────────────────────────────────────
# Generate 3-D LUT: 4 L values × 37 Vgs × 37 Vds
# ─────────────────────────────────────────────────────────────────────────────

cfg = LutConfig(
    device_type="nmos",
    model_file="/Users/timvandenakker/Documents/GitHub/sedes/logic018_no1of.l",
    model_name="nch",
    lengths=(200e-9, 2000e-9, 100e-9),   # 200 nm → 2 µm in 100 nm steps
    vgs=(0.0, 1.8, 0.005),
    vds=(0.0, 1.8, 0.005),
)

print(f"Generating LUT: {cfg}")
lut = pool.generate_lut(cfg)
print(f"LUT shape: {lut.id.shape}  (n_l={len(lut.lengths)}, n_vgs, n_vds)")

# ─────────────────────────────────────────────────────────────────────────────
# Design-oriented plots (no Vgs/Vds axes)
# ─────────────────────────────────────────────────────────────────────────────

print("\nGenerating design plots ...")
fig = lut.plot()
fig.suptitle("180NM NMOS  (200–2000 nm)", fontsize=13, fontweight="bold", y=1.01)
plt.tight_layout()

# ─────────────────────────────────────────────────────────────────────────────
# gm/Id transistor sizing
# ─────────────────────────────────────────────────────────────────────────────

result = lut.design(gm_id=20.0, gain=200.0, ids=20e-6)
print(result)
print(f"  W       = {result.w*1e6:.2f} µm")
print(f"  L       = {result.l*1e9:.0f} nm")
print(f"  Vgs     = {result.vgs:.3f} V")
print(f"  Vds     = {result.vds:.3f} V")
print(f"  Id      = {result.id*1e6:.1f} µA")
print(f"  gm/Id   = {result.gm_over_id:.2f} V⁻¹")
print(f"  Gain    = {result.gain:.1f} V/V")
print("  Constraint errors:")
for name, err in result.constraint_errors:
    print(f"    {name}: {err*100:+.1f}%")

plt.show()
