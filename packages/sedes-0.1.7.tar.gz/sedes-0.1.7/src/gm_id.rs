/// gm/Id transistor sizing methodology.
///
/// This module implements the gm/Id design method entirely in Rust:
/// - A flexible constraint system (gm/Id ratio, intrinsic gain, drain current, ...)
/// - Bilinear/trilinear interpolation on the regular LUT grid
/// - Correct two-phase algorithm:
///   1. For each L, find the Vgs where gm/Id equals the target (1-D root search)
///   2. Among all (L, Vgs) pairs that satisfy the gm/Id target, find the L that
///      best satisfies the gain constraint
///   3. Back-compute W from the Ids constraint
///
/// This is the standard gm/Id methodology as taught in analog IC design:
/// gm/Id sets the operating region (Vgs), L sets the gain, W sets the current.
///
/// # Adding a new constraint
///
/// 1. Add a variant to [`ConstraintKind`].
/// 2. Add a match arm in the solver logic.
/// 3. No Python changes needed.
use crate::error::NgspiceError;
use crate::lut::TransistorLut;

// ─────────────────────────────────────────────────────────────────────────────
// Public types
// ─────────────────────────────────────────────────────────────────────────────

/// The physical quantity a [`DesignConstraint`] targets.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ConstraintKind {
    /// gm/Id ratio (V⁻¹). Typical range: 5–25. Controls efficiency and speed.
    GmOverId,
    /// Intrinsic voltage gain gm/gds (V/V). Controls self-gain of the stage.
    Gain,
    /// Absolute drain current Id (A). Scales linearly with W.
    Ids,
}

/// A single design target: a physical quantity and its desired value.
#[derive(Debug, Clone)]
pub struct DesignConstraint {
    pub kind: ConstraintKind,
    pub target: f64,
}

impl DesignConstraint {
    pub fn new(kind: ConstraintKind, target: f64) -> Self {
        Self { kind, target }
    }
}

/// The result of a successful transistor sizing.
#[derive(Debug, Clone)]
pub struct DesignResult {
    /// Computed gate width (m).
    pub w: f64,
    /// Chosen gate length (m).
    pub l: f64,
    /// Drain current at the operating point (A), scaled to actual W.
    pub id: f64,
    /// Gate-source voltage at the operating point (V).
    pub vgs: f64,
    /// Drain-source voltage used during sizing (V).
    pub vds: f64,
    /// Transconductance at the operating point (S), scaled to actual W.
    pub gm: f64,
    /// Output conductance at the operating point (S), scaled to actual W.
    pub gds: f64,
    /// gm/Id ratio (V⁻¹). W-independent.
    pub gm_over_id: f64,
    /// Intrinsic gain gm/gds (V/V). W-independent.
    pub gain: f64,
    /// Relative error for each constraint: `(actual - target) / target`.
    pub constraint_errors: Vec<(String, f64)>,
}

/// Solving mode.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SolveMode {
    /// Use the provided LUT as-is with interpolation.
    Interpolation,
}

// ─────────────────────────────────────────────────────────────────────────────
// Interpolation helpers
// ─────────────────────────────────────────────────────────────────────────────

/// Interpolate a 1-D axis to find the fractional index for `value`.
fn axis_frac(axis: &[f64], value: f64) -> (usize, f64) {
    if axis.len() == 1 || value <= axis[0] {
        return (0, 0.0);
    }
    let last = axis.len() - 1;
    if value >= axis[last] {
        return (last.saturating_sub(1), 1.0);
    }
    let idx = axis
        .partition_point(|&x| x < value)
        .saturating_sub(1)
        .min(last - 1);
    let frac = (value - axis[idx]) / (axis[idx + 1] - axis[idx]);
    (idx, frac.clamp(0.0, 1.0))
}

/// Linear interpolation along the Vds axis using a fractional index `df`.
fn interp_vds(row: &[f64], df: f64) -> f64 {
    let n = row.len();
    if n == 1 {
        return row[0];
    }
    let i0 = (df.floor() as usize).min(n - 2);
    let i1 = i0 + 1;
    let t = df - i0 as f64;
    row[i0] * (1.0 - t) + row[i1] * t
}

/// Trilinear interpolation of a LUT field at fractional grid indices
/// `(lf, gf, df)` for L, Vgs, Vds respectively.
fn trilinear_lut<F>(lut: &TransistorLut, lf: f64, gf: f64, df: f64, field: F) -> f64
where
    F: Fn(&TransistorLut, usize, usize) -> &Vec<f64>,
{
    let n_l = lut.lengths.len();
    let n_g = lut.vgs.len();

    let li0 = (lf.floor() as usize).min(n_l.saturating_sub(2));
    let gi0 = (gf.floor() as usize).min(n_g.saturating_sub(2));
    let li1 = (li0 + 1).min(n_l - 1);
    let gi1 = (gi0 + 1).min(n_g - 1);

    let dl = lf - li0 as f64;
    let dg = gf - gi0 as f64;

    let v000 = interp_vds(field(lut, li0, gi0), df);
    let v001 = interp_vds(field(lut, li0, gi1), df);
    let v100 = interp_vds(field(lut, li1, gi0), df);
    let v101 = interp_vds(field(lut, li1, gi1), df);

    v000 * (1.0 - dl) * (1.0 - dg)
        + v001 * (1.0 - dl) * dg
        + v100 * dl * (1.0 - dg)
        + v101 * dl * dg
}

/// Interpolate a physical value from a regular axis using a fractional index.
fn interp_axis(axis: &[f64], fi: f64) -> f64 {
    let n = axis.len();
    if n == 1 {
        return axis[0];
    }
    let i0 = (fi.floor() as usize).min(n - 2);
    let i1 = i0 + 1;
    let t = fi - i0 as f64;
    axis[i0] * (1.0 - t) + axis[i1] * t
}

// ─────────────────────────────────────────────────────────────────────────────
// gm/Id operating-point finder
// ─────────────────────────────────────────────────────────────────────────────

/// For a single L index `li`, find the fractional Vgs index where
/// `gm/Id = gm_id_target` using the moderate-inversion crossing.
///
/// Scans the Vgs axis from high to low. The first crossing where gm/Id rises
/// above the target (as Vgs decreases) corresponds to the moderate-inversion
/// (or subthreshold-edge) operating point — the physically meaningful design point.
///
/// Returns `Some((gf, id, gm, gds))` at the interpolated Vgs, or `None` if the
/// target is not achievable for this L.
fn find_gm_id_crossing(
    lut: &TransistorLut,
    li: usize,
    gm_id_target: f64,
    vds_f: f64,
    id_threshold: f64,
) -> Option<(f64, f64, f64, f64)> {
    let n_vgs = lut.vgs.len();

    // Build gm/Id at each Vgs grid point.
    let gm_id_at: Vec<f64> = (0..n_vgs)
        .map(|gi| {
            let id = interp_vds(&lut.id[li][gi], vds_f);
            let gm = interp_vds(&lut.gm[li][gi], vds_f);
            if id.abs() < id_threshold {
                f64::NAN
            } else {
                gm / id
            }
        })
        .collect();

    // Scan from HIGH Vgs (gi = n_vgs-1) down to LOW Vgs (gi = 1).
    // Find the first adjacent pair (gi-1, gi) where:
    //   gm_id[gi-1] >= target  and  gm_id[gi] <= target
    // (i.e., gm/Id rises above the target as we move to lower Vgs).
    // This is the moderate-inversion operating point.
    for gi in (1..n_vgs).rev() {
        let lo = gm_id_at[gi - 1]; // lower Vgs end of the interval
        let hi = gm_id_at[gi]; // higher Vgs end of the interval

        if lo.is_nan() || hi.is_nan() {
            continue;
        }

        // We want lo >= target >= hi (gm/Id decreasing as Vgs increases).
        // Also accept reversed-monotonicity pairs (safety for non-monotone models).
        let crosses = (lo >= gm_id_target && hi <= gm_id_target)
            || (lo <= gm_id_target && hi >= gm_id_target);

        if crosses {
            let denom = lo - hi;
            let t = if denom.abs() > 1e-30 {
                ((lo - gm_id_target) / denom).clamp(0.0, 1.0)
            } else {
                0.5
            };
            let gf = (gi as f64 - 1.0) + t;

            let id = trilinear_lut(lut, li as f64, gf, vds_f, |l, li, gi| &l.id[li][gi]);
            let gm = trilinear_lut(lut, li as f64, gf, vds_f, |l, li, gi| &l.gm[li][gi]);
            let gds = trilinear_lut(lut, li as f64, gf, vds_f, |l, li, gi| &l.gds[li][gi]);

            return Some((gf, id, gm, gds));
        }
    }

    None
}

// ─────────────────────────────────────────────────────────────────────────────
// Main solver
// ─────────────────────────────────────────────────────────────────────────────

/// Find the transistor operating point (W, L, Vgs, Vds) that best satisfies
/// all given constraints.
///
/// # Two-phase algorithm (when a gm/Id constraint is present)
///
/// **Phase 1 — find Vgs per L**:
/// gm/Id is a function of Vgs only (W and L cancel). For each L, the Vgs that
/// satisfies the gm/Id target is found by scanning the LUT and interpolating to
/// the exact crossing. This gives a set of (L, Vgs) candidate pairs that all
/// satisfy the gm/Id target to within the LUT interpolation error.
///
/// **Phase 2 — select L by gain**:
/// For each candidate pair the gain gm/gds is evaluated. The L (and corresponding
/// Vgs) that minimises the gain error is chosen.
///
/// **Phase 3 — compute W**:
/// W is back-computed from the `Ids` constraint (if present):
/// `W = W_lut × (Id_target / Id_lut_at_operating_point)`.
///
/// # Fallback (no gm/Id constraint)
///
/// Grid search over (L, Vgs) space minimising the sum of squared relative
/// errors for the remaining constraints (gain, Ids). Ids is excluded from the
/// grid-search cost because W is always back-computed after finding (L, Vgs).
pub fn solve_design(
    lut: &TransistorLut,
    constraints: &[DesignConstraint],
    vds: Option<f64>,
    _mode: SolveMode,
    gm_id_min: Option<f64>,
    gm_id_max: Option<f64>,
    id_min: Option<f64>,
) -> Result<DesignResult, NgspiceError> {
    if lut.vgs.is_empty() || lut.vds.is_empty() || lut.lengths.is_empty() {
        return Err(NgspiceError::SimulationFailed("LUT is empty".into()));
    }
    if constraints.is_empty() {
        return Err(NgspiceError::SimulationFailed(
            "at least one constraint is required".into(),
        ));
    }

    let w_lut = lut.width;

    // ── Choose Vds ────────────────────────────────────────────────────────────
    let vds_target = vds.unwrap_or_else(|| {
        let mid = lut.vds.len() / 2;
        lut.vds[mid]
    });
    let (vds_idx, vds_frac) = axis_frac(&lut.vds, vds_target);
    let vds_f = vds_idx as f64 + vds_frac;

    let n_l = lut.lengths.len();
    let n_vgs = lut.vgs.len();

    let ids_target: Option<f64> = constraints
        .iter()
        .find(|c| c.kind == ConstraintKind::Ids)
        .map(|c| c.target);

    let gm_id_c = constraints
        .iter()
        .find(|c| c.kind == ConstraintKind::GmOverId);
    let gain_c = constraints.iter().find(|c| c.kind == ConstraintKind::Gain);

    let id_threshold = id_min.unwrap_or(1e-12);

    // ── Phase 1 & 2: gm/Id methodology ───────────────────────────────────────
    let (best_lf, best_gf) = if let Some(gm_id_c) = gm_id_c {
        // For each L find the Vgs that satisfies gm/Id = target.
        struct Candidate {
            lf: f64,
            gf: f64,
            gain: f64,
        }

        let mut candidates: Vec<Candidate> = Vec::with_capacity(n_l);

        for li in 0..n_l {
            let Some((gf, id, gm, gds)) =
                find_gm_id_crossing(lut, li, gm_id_c.target, vds_f, id_threshold)
            else {
                continue;
            };

            // Apply gm/Id range filter.
            let gm_id_here = if id.abs() > 1e-30 { gm / id } else { 0.0 };
            if gm_id_min.is_some_and(|lo| gm_id_here < lo) {
                continue;
            }
            if gm_id_max.is_some_and(|hi| gm_id_here > hi) {
                continue;
            }

            let gain = if gds.abs() > 1e-30 {
                gm / gds
            } else {
                f64::INFINITY
            };
            candidates.push(Candidate {
                lf: li as f64,
                gf,
                gain,
            });
        }

        if candidates.is_empty() {
            return Err(NgspiceError::SimulationFailed(format!(
                "No operating point found for gm/Id = {:.2} V⁻¹. \
                 Try adjusting gm_id_min/gm_id_max or widening the LUT voltage range.",
                gm_id_c.target
            )));
        }

        if let Some(gain_c) = gain_c {
            // Pick the L whose gain is closest to the gain target.
            //
            // Use relative squared error.  When all gains are far from the
            // target (e.g. model has no CLM in subthreshold), the L with the
            // numerically closest gain is still chosen, giving a well-defined
            // and reproducible result.
            let best = candidates
                .iter()
                .min_by(|a, b| {
                    let err_a = relative_err_sq(a.gain, gain_c.target);
                    let err_b = relative_err_sq(b.gain, gain_c.target);
                    err_a
                        .partial_cmp(&err_b)
                        .unwrap_or(std::cmp::Ordering::Equal)
                })
                .unwrap();

            // Sub-grid refinement along the L axis: search the neighbourhood
            // [best_li ± 0.5] in 32 sub-steps, re-computing the gm/Id
            // crossing at each fractional L and evaluating the gain.
            let li_center = best.lf;
            let l_lo = (li_center - 0.5).max(0.0);
            let l_hi = (li_center + 0.5).min((n_l - 1) as f64);
            const REFINE: usize = 32;

            let mut best_lf = best.lf;
            let mut best_gf = best.gf;
            let mut best_err = relative_err_sq(best.gain, gain_c.target);

            for step in 0..=REFINE {
                let lf = l_lo + (l_hi - l_lo) * step as f64 / REFINE as f64;

                // For a fractional L we need both bounding L slices.
                // We evaluate a pseudo-gm/Id sweep by trilinearly interpolating
                // and then do a direct Vgs scan using a helper that handles
                // fractional li.
                let Some((gf, _id, gm, gds)) =
                    find_gm_id_crossing_frac(lut, lf, gm_id_c.target, vds_f, id_threshold)
                else {
                    continue;
                };

                let gm_id_here = {
                    let id2 = trilinear_lut(lut, lf, gf, vds_f, |l, li, gi| &l.id[li][gi]);
                    if id2.abs() > 1e-30 { gm / id2 } else { 0.0 }
                };
                if gm_id_min.is_some_and(|lo| gm_id_here < lo) {
                    continue;
                }
                if gm_id_max.is_some_and(|hi| gm_id_here > hi) {
                    continue;
                }

                let gain = if gds.abs() > 1e-30 {
                    gm / gds
                } else {
                    f64::INFINITY
                };
                let err = relative_err_sq(gain, gain_c.target);
                if err < best_err {
                    best_err = err;
                    best_lf = lf;
                    best_gf = gf;
                }
            }

            (best_lf, best_gf)
        } else {
            // No gain constraint — return the first (shortest L) candidate
            // so the API remains deterministic.  The caller can pass a gain
            // target to override this selection.
            (candidates[0].lf, candidates[0].gf)
        }
    } else {
        // ── Fallback: grid search (no gm/Id constraint) ──────────────────────
        // Ids is excluded from the cost (W-independent: back-computed later).
        let mut best_cost = f64::INFINITY;
        let mut best_li = 0usize;
        let mut best_gi = 0usize;

        for li in 0..n_l {
            for gi in 0..n_vgs {
                let id = trilinear_lut(lut, li as f64, gi as f64, vds_f, |l, li, gi| &l.id[li][gi]);
                let gm = trilinear_lut(lut, li as f64, gi as f64, vds_f, |l, li, gi| &l.gm[li][gi]);
                let gds =
                    trilinear_lut(lut, li as f64, gi as f64, vds_f, |l, li, gi| &l.gds[li][gi]);

                if id.abs() < id_threshold {
                    continue;
                }

                let gm_id_here = gm / id;
                if gm_id_min.is_some_and(|lo| gm_id_here < lo) {
                    continue;
                }
                if gm_id_max.is_some_and(|hi| gm_id_here > hi) {
                    continue;
                }

                let cost: f64 = constraints
                    .iter()
                    .filter(|c| c.kind != ConstraintKind::Ids)
                    .map(|c| {
                        let metric = match c.kind {
                            ConstraintKind::GmOverId => gm_id_here,
                            ConstraintKind::Gain => {
                                if gds.abs() > 1e-30 {
                                    gm / gds
                                } else {
                                    f64::INFINITY
                                }
                            }
                            ConstraintKind::Ids => unreachable!(),
                        };
                        relative_err_sq(metric, c.target)
                    })
                    .sum();

                if cost < best_cost {
                    best_cost = cost;
                    best_li = li;
                    best_gi = gi;
                }
            }
        }

        (best_li as f64, best_gi as f64)
    };

    // ── Evaluate at the chosen operating point ────────────────────────────────
    let id_op = trilinear_lut(lut, best_lf, best_gf, vds_f, |l, li, gi| &l.id[li][gi]);
    let gm_op = trilinear_lut(lut, best_lf, best_gf, vds_f, |l, li, gi| &l.gm[li][gi]);
    let gds_op = trilinear_lut(lut, best_lf, best_gf, vds_f, |l, li, gi| &l.gds[li][gi]);

    let l_op = interp_axis(&lut.lengths, best_lf);
    let vgs_op = interp_axis(&lut.vgs, best_gf);

    // ── Compute W from Ids target ─────────────────────────────────────────────
    let w = if let Some(id_target) = ids_target {
        if id_op.abs() > 1e-18 {
            w_lut * (id_target / id_op)
        } else {
            w_lut
        }
    } else {
        w_lut
    };

    let scale = w / w_lut;
    let id_actual = id_op * scale;
    let gm_actual = gm_op * scale;
    let gds_actual = gds_op * scale;

    // ── Constraint errors ─────────────────────────────────────────────────────
    // gm/Id and gain are W-independent: their errors are meaningful.
    // Ids is satisfied by construction (W is derived from it) → error = 0.
    let gm_id_actual = if id_op.abs() > 1e-18 {
        gm_op / id_op
    } else {
        0.0
    };
    let gain_actual = if gds_op.abs() > 1e-18 {
        gm_op / gds_op
    } else {
        f64::INFINITY
    };

    let constraint_errors: Vec<(String, f64)> = constraints
        .iter()
        .map(|c| {
            let (name, err) = match c.kind {
                ConstraintKind::GmOverId => {
                    let e = if c.target.abs() > 1e-30 {
                        (gm_id_actual - c.target) / c.target
                    } else {
                        gm_id_actual - c.target
                    };
                    ("gm/Id", e)
                }
                ConstraintKind::Gain => {
                    let e = if c.target.abs() > 1e-30 && gain_actual.is_finite() {
                        (gain_actual - c.target) / c.target
                    } else if gain_actual.is_infinite() {
                        f64::INFINITY
                    } else {
                        gain_actual - c.target
                    };
                    ("gain", e)
                }
                ConstraintKind::Ids => {
                    // W was computed to exactly satisfy this → error = 0 by construction.
                    ("Ids", 0.0)
                }
            };
            (name.to_string(), err)
        })
        .collect();

    Ok(DesignResult {
        w,
        l: l_op,
        id: id_actual,
        vgs: vgs_op,
        vds: vds_target,
        gm: gm_actual,
        gds: gds_actual,
        gm_over_id: gm_id_actual,
        gain: gain_actual,
        constraint_errors,
    })
}

// ─────────────────────────────────────────────────────────────────────────────
// Internal helpers
// ─────────────────────────────────────────────────────────────────────────────

/// Squared relative error `((actual - target) / target)²`.
/// Falls back to `(actual - target)²` when `|target| < 1e-30`.
/// Returns 0.0 if both `actual` and `target` are non-finite.
#[inline]
fn relative_err_sq(actual: f64, target: f64) -> f64 {
    if actual.is_infinite() || actual.is_nan() {
        // Non-finite gain can't be compared on a relative scale; penalise
        // heavily but not infinitely so the solver can still distinguish.
        return 1e30;
    }
    let diff = actual - target;
    if target.abs() > 1e-30 {
        (diff / target).powi(2)
    } else {
        diff.powi(2)
    }
}

/// Like [`find_gm_id_crossing`] but accepts a fractional L index.
///
/// Internally trilinearly interpolates id and gm at each Vgs grid point to
/// synthesise a virtual 1-D gm/Id sweep for the fractional L.
fn find_gm_id_crossing_frac(
    lut: &TransistorLut,
    lf: f64,
    gm_id_target: f64,
    vds_f: f64,
    id_threshold: f64,
) -> Option<(f64, f64, f64, f64)> {
    let n_vgs = lut.vgs.len();

    let gm_id_at: Vec<f64> = (0..n_vgs)
        .map(|gi| {
            let id = trilinear_lut(lut, lf, gi as f64, vds_f, |l, li, gi| &l.id[li][gi]);
            let gm = trilinear_lut(lut, lf, gi as f64, vds_f, |l, li, gi| &l.gm[li][gi]);
            if id.abs() < id_threshold {
                f64::NAN
            } else {
                gm / id
            }
        })
        .collect();

    for gi in (1..n_vgs).rev() {
        let lo = gm_id_at[gi - 1];
        let hi = gm_id_at[gi];
        if lo.is_nan() || hi.is_nan() {
            continue;
        }

        let crosses = (lo >= gm_id_target && hi <= gm_id_target)
            || (lo <= gm_id_target && hi >= gm_id_target);

        if crosses {
            let denom = lo - hi;
            let t = if denom.abs() > 1e-30 {
                ((lo - gm_id_target) / denom).clamp(0.0, 1.0)
            } else {
                0.5
            };
            let gf = (gi as f64 - 1.0) + t;
            let id = trilinear_lut(lut, lf, gf, vds_f, |l, li, gi| &l.id[li][gi]);
            let gm = trilinear_lut(lut, lf, gf, vds_f, |l, li, gi| &l.gm[li][gi]);
            let gds = trilinear_lut(lut, lf, gf, vds_f, |l, li, gi| &l.gds[li][gi]);
            return Some((gf, id, gm, gds));
        }
    }
    None
}
