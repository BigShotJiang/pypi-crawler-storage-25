/// Transistor lookup-table generation — parallelised across the Vgs axis.
///
/// # Parallelisation strategy
///
/// A single nested `.dc Vds ... Vgs ...` sweep runs entirely inside one ngspice
/// process, so it uses one CPU core regardless of how large the grid is.  To
/// exploit the worker pool we split the **Vgs axis** into N contiguous slices
/// and submit each slice as a separate simulation:
///
/// ```text
///   Vgs axis:  [0 ──────────────────────────────────────── 1.8 V]
///   chunk 0:   [0 ──────── 0.44]   → worker 0
///   chunk 1:   [0.45 ───── 0.89]   → worker 1
///   chunk 2:   [0.90 ───── 1.34]   → worker 2
///   chunk 3:   [1.35 ───── 1.8 ]   → worker 3
/// ```
///
/// All chunks run concurrently.  When every chunk has responded we concatenate
/// the sub-grids in order along the Vgs axis to reconstruct the full 2-D Id
/// table, then numerically differentiate it to produce gm and gds.
///
/// Because the full grid is assembled before differentiation, there are **no
/// boundary artefacts** between chunks: the central-difference stencil spans
/// across chunk seams naturally.
///
/// # Sweep layout
///
/// `.dc Vds start stop step Vgs start stop step` places Vds as the
/// **inner** (fast) sweep and Vgs as the **outer** (slow) sweep.
/// Result vectors are a flat array of length `N_vds × N_vgs`:
///
/// ```text
///   [Vgs=Vgs₀, Vds=Vds₀..Vds_max]  [Vgs=Vgs₁, Vds=Vds₀..Vds_max]  ...
/// ```
use std::{path::Path, sync::Arc, time::Instant};

use tokio::task::JoinSet;

use crate::{
    error::NgspiceError,
    pool::WorkerPool,
    protocol::{SimulationRequest, SimulationResponse, VectorData},
};

// ─────────────────────────────────────────────────────────────────────────────
// Configuration
// ─────────────────────────────────────────────────────────────────────────────

#[derive(Debug, Clone, Copy)]
pub enum DeviceType {
    Nmos,
    Pmos,
}

/// Range for one DC sweep axis.
#[derive(Debug, Clone, Copy)]
pub struct SweepRange {
    pub start: f64,
    pub stop: f64,
    pub step: f64,
}

impl SweepRange {
    /// Number of points, inclusive of both endpoints.
    pub fn num_points(self) -> usize {
        (((self.stop - self.start) / self.step).round() as usize) + 1
    }

    /// Axis values computed from index (no floating-point drift).
    pub fn points(self) -> Vec<f64> {
        (0..self.num_points())
            .map(|i| self.start + i as f64 * self.step)
            .collect()
    }

    /// Return a sub-range covering indices `start_i..=stop_i` of this range.
    /// Uses index arithmetic to avoid floating-point accumulation.
    fn slice(self, start_i: usize, stop_i: usize) -> Self {
        Self {
            start: self.start + start_i as f64 * self.step,
            stop: self.start + stop_i as f64 * self.step,
            step: self.step,
        }
    }
}

#[derive(Debug, Clone)]
pub struct LutConfig {
    pub device_type: DeviceType,
    /// Full `.model` card string; empty → built-in Level-3 model.
    /// Ignored when `model_file` is set.
    pub model_card: String,
    /// Path to an external SPICE model file (`.lib` / `.mod`).
    /// When set together with `model_section` a `.lib path section` directive
    /// is emitted (selects a specific corner/section from a multi-section lib).
    /// When set without `model_section` a `.include path` directive is emitted.
    pub model_file: Option<String>,
    /// Section / corner name inside a multi-section `.lib` file (e.g. `"TT"`).
    /// Ignored when `model_file` is `None`.
    pub model_section: Option<String>,
    /// Model name referenced on the M-line.
    pub model_name: String,
    pub width: f64,
    /// Gate-length sweep.  A single length is represented as a 1-point range
    /// (start == stop, step == 1.0).  Use `LutConfig::length()` to get the
    /// single value, or `lengths.points()` to iterate.
    pub lengths: SweepRange,
    pub vgs: SweepRange,
    pub vds: SweepRange,
    /// Fixed bulk-source voltage.
    pub vbs: f64,
}

impl LutConfig {
    /// Convenience accessor for the first (or only) length value.
    pub fn length(&self) -> f64 {
        self.lengths.start
    }
}

impl Default for LutConfig {
    fn default() -> Self {
        Self {
            device_type: DeviceType::Nmos,
            model_card: String::new(),
            model_file: None,
            model_section: None,
            model_name: "nch".to_string(),
            width: 10e-6, // 10 µm — wide device for visible currents
            lengths: SweepRange {
                start: 500e-9,
                stop: 500e-9,
                step: 1.0,
            }, // single point: 0.5 µm
            vgs: SweepRange {
                start: 0.0,
                stop: 1.8,
                step: 0.05,
            },
            vds: SweepRange {
                start: 0.0,
                stop: 1.8,
                step: 0.05,
            },
            vbs: 0.0,
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Output lookup table
// ─────────────────────────────────────────────────────────────────────────────

/// Fully characterised transistor lookup table.
///
/// Arrays are indexed `[l_idx][vgs_idx][vds_idx]`.  When only a single length
/// was requested, `lengths` has one element and the Python bindings squeeze
/// `id`/`gm`/`gds` to 2-D arrays for backward compatibility.
pub struct TransistorLut {
    /// Gate-length axis values (m).
    pub lengths: Vec<f64>,
    pub vgs: Vec<f64>,
    pub vds: Vec<f64>,
    /// Drain current Id (A).  Shape: `[l_idx][vgs_idx][vds_idx]`.
    pub id: Vec<Vec<Vec<f64>>>,
    /// Transconductance  gm  = ∂Id/∂Vgs (S).
    pub gm: Vec<Vec<Vec<f64>>>,
    /// Output conductance gds = ∂Id/∂Vds (S).
    pub gds: Vec<Vec<Vec<f64>>>,
    /// Gate width used during characterisation (m).
    pub width: f64,
    /// Fixed bulk-source voltage used during characterisation (V).
    pub vbs: f64,
}

impl TransistorLut {
    /// Write `L,Vgs,Vds,Id,gm,gds` CSV, one row per operating point.
    pub fn write_csv(&self, path: &Path) -> Result<(), std::io::Error> {
        use std::io::Write;
        let mut f = std::io::BufWriter::new(std::fs::File::create(path)?);
        writeln!(f, "L,Vgs,Vds,Id,gm,gds")?;
        for (li, l) in self.lengths.iter().enumerate() {
            for (gi, vgs) in self.vgs.iter().enumerate() {
                for (di, vds) in self.vds.iter().enumerate() {
                    writeln!(
                        f,
                        "{:.6e},{:.6e},{:.6e},{:.6e},{:.6e},{:.6e}",
                        l, vgs, vds, self.id[li][gi][di], self.gm[li][gi][di], self.gds[li][gi][di]
                    )?;
                }
            }
        }
        f.flush()?;
        Ok(())
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Built-in model cards
// ─────────────────────────────────────────────────────────────────────────────

fn builtin_nmos_model() -> String {
    ".model nch nmos level=3 tox=10n vth0=0.7 kp=80u gamma=0.5 phi=0.6 lambda=0.01 \
     +nsub=1e17 nss=0 nfs=1e11 xj=0.2u ld=0.05u delta=0 theta=0.1 eta=0 kappa=0.2"
        .to_string()
}

fn builtin_pmos_model() -> String {
    ".model pch pmos level=3 tox=10n vth0=-0.7 kp=40u gamma=0.6 phi=0.6 lambda=0.015 \
     +nsub=1e17 nss=0 nfs=1e11 xj=0.2u ld=0.05u delta=0 theta=0.1 eta=0 kappa=0.2"
        .to_string()
}

// ─────────────────────────────────────────────────────────────────────────────
// Netlist generation
// ─────────────────────────────────────────────────────────────────────────────

/// Build a netlist for a nested DC sweep using the given Vgs sub-range and
/// a specific gate length `l_value`.
///
/// `vgs_chunk` may cover the full Vgs range (when running without
/// parallelisation) or just a slice of it (when one of many parallel chunks).
fn build_netlist(cfg: &LutConfig, l_value: f64, vgs_chunk: SweepRange) -> String {
    // Priority: external file > inline card > built-in model.
    let model_card = if let Some(ref path) = cfg.model_file {
        match cfg.model_section.as_deref() {
            Some(section) => format!(".lib {path} {section}"),
            None => format!(".include {path}"),
        }
    } else if cfg.model_card.is_empty() {
        match cfg.device_type {
            DeviceType::Nmos => builtin_nmos_model(),
            DeviceType::Pmos => builtin_pmos_model(),
        }
    } else {
        cfg.model_card.clone()
    };

    let title = match cfg.device_type {
        DeviceType::Nmos => "nmos",
        DeviceType::Pmos => "pmos",
    };

    // .dc Vds (inner/fast) for each Vgs (outer/slow).
    // For PMOS the user passes negative step values; ngspice handles them fine.
    format!(
        "{title} characterisation W={w:.3e} L={l:.3e}\n\
         \n\
         * model\n\
         {model}\n\
         \n\
         * test bench: M1 drain gate source bulk\n\
         M1 drain gate source bulk {name} W={w:.3e} L={l:.3e}\n\
         Vds drain source dc 0\n\
         Vgs gate  source dc 0\n\
         Vbs bulk  source dc {vbs:.3e}\n\
         Vs  source 0    dc 0\n\
         \n\
         * sweep\n\
         .dc Vds {vds_start:.6e} {vds_stop:.6e} {vds_step:.6e} \
              Vgs {vgs_start:.6e} {vgs_stop:.6e} {vgs_step:.6e}\n\
         \n\
         .end",
        title = title,
        model = model_card,
        name = cfg.model_name,
        w = cfg.width,
        l = l_value,
        vbs = cfg.vbs,
        vds_start = cfg.vds.start,
        vds_stop = cfg.vds.stop,
        vds_step = cfg.vds.step,
        vgs_start = vgs_chunk.start,
        vgs_stop = vgs_chunk.stop,
        vgs_step = vgs_chunk.step,
    )
}

// ─────────────────────────────────────────────────────────────────────────────
// Response parsing
// ─────────────────────────────────────────────────────────────────────────────

fn find_vector<'a>(resp: &'a SimulationResponse, name: &str) -> Option<&'a VectorData> {
    resp.vectors
        .iter()
        .find(|v| v.name.eq_ignore_ascii_case(name))
}

/// Extract the Id rows from one simulation response.
///
/// Returns `id_rows[vgs_idx][vds_idx]` for the Vgs sub-range covered by this
/// particular chunk.  `n_vgs_chunk` is the number of Vgs points expected.
///
/// Sign convention: `vds#branch` is negated so that Id is **positive** when
/// current enters the drain (both NMOS and PMOS — the user's sign on the sweep
/// voltages already handles polarity).
fn extract_id_rows(
    resp: &SimulationResponse,
    n_vgs_chunk: usize,
    n_vds: usize,
) -> Result<Vec<Vec<f64>>, NgspiceError> {
    let id_vec = find_vector(resp, "vds#branch").ok_or_else(|| {
        let available: Vec<_> = resp.vectors.iter().map(|v| v.name.as_str()).collect();
        NgspiceError::SimulationFailed(format!("'vds#branch' not found; available: {available:?}"))
    })?;

    let expected = n_vgs_chunk * n_vds;
    if id_vec.data.len() != expected {
        return Err(NgspiceError::SimulationFailed(format!(
            "expected {expected} points ({n_vgs_chunk}×{n_vds}), got {}",
            id_vec.data.len(),
        )));
    }

    let mut rows = vec![vec![0.0_f64; n_vds]; n_vgs_chunk];
    for (gi, row) in rows.iter_mut().enumerate().take(n_vgs_chunk) {
        for (di, cell) in row.iter_mut().enumerate().take(n_vds) {
            *cell = -id_vec.data[gi * n_vds + di]; // negate → conventional Id
        }
    }
    Ok(rows)
}

// ─────────────────────────────────────────────────────────────────────────────
// Numerical differentiation (operates on the complete assembled grid)
// ─────────────────────────────────────────────────────────────────────────────

/// Central finite-difference derivative along axis 0 (rows = Vgs).
fn diff_vgs(id: &[Vec<f64>], step: f64) -> Vec<Vec<f64>> {
    let n_vgs = id.len();
    let n_vds = id[0].len();
    let mut gm = vec![vec![0.0; n_vds]; n_vgs];
    for di in 0..n_vds {
        for gi in 0..n_vgs {
            gm[gi][di] = if gi == 0 {
                (id[1][di] - id[0][di]) / step
            } else if gi == n_vgs - 1 {
                (id[n_vgs - 1][di] - id[n_vgs - 2][di]) / step
            } else {
                (id[gi + 1][di] - id[gi - 1][di]) / (2.0 * step)
            };
        }
    }
    gm
}

/// Central finite-difference derivative along axis 1 (columns = Vds).
fn diff_vds(id: &[Vec<f64>], step: f64) -> Vec<Vec<f64>> {
    let n_vgs = id.len();
    let n_vds = id[0].len();
    let mut gds = vec![vec![0.0; n_vds]; n_vgs];
    for gi in 0..n_vgs {
        for di in 0..n_vds {
            gds[gi][di] = if di == 0 {
                (id[gi][1] - id[gi][0]) / step
            } else if di == n_vds - 1 {
                (id[gi][n_vds - 1] - id[gi][n_vds - 2]) / step
            } else {
                (id[gi][di + 1] - id[gi][di - 1]) / (2.0 * step)
            };
        }
    }
    gds
}

// ─────────────────────────────────────────────────────────────────────────────
// Chunking helpers
// ─────────────────────────────────────────────────────────────────────────────

/// Divide `n_total` indices into at most `n_chunks` contiguous slices.
///
/// Returns a `Vec` of `(start_i, stop_i)` index pairs (both inclusive).
/// If `n_total < n_chunks` the returned vec has fewer entries than requested.
fn chunk_indices(n_total: usize, n_chunks: usize) -> Vec<(usize, usize)> {
    let chunk_size = n_total.div_ceil(n_chunks);
    let mut ranges = Vec::new();
    let mut start = 0;
    while start < n_total {
        let stop = (start + chunk_size - 1).min(n_total - 1);
        ranges.push((start, stop));
        start = stop + 1;
    }
    ranges
}

// ─────────────────────────────────────────────────────────────────────────────
// Parallel LUT generation — public API
// ─────────────────────────────────────────────────────────────────────────────

/// Generate a transistor LUT by sweeping L values and splitting the Vgs axis
/// across concurrent worker simulations.
///
/// All `(l_value, vgs_chunk)` job pairs are dispatched in parallel into the
/// pool.  Results are grouped by L index, concatenated along the Vgs axis per
/// L slice, then differentiated to give gm and gds.
pub async fn generate_lut(
    pool: &Arc<WorkerPool>,
    cfg: &LutConfig,
    n_chunks: usize,
    csv_path: Option<&Path>,
) -> Result<TransistorLut, NgspiceError> {
    let l_points = cfg.lengths.points();
    let n_l = l_points.len();
    let n_vgs_total = cfg.vgs.num_points();
    let n_vds = cfg.vds.num_points();

    let vgs_chunks = chunk_indices(n_vgs_total, n_chunks);
    let n_vgs_chunks = vgs_chunks.len();
    let total_jobs = n_l * n_vgs_chunks;

    println!(
        "  {n_l} L value(s) × {n_vgs_total} Vgs pts × {n_vds} Vds pts  \
         → {total_jobs} jobs across {n_vgs_chunks} Vgs chunk(s)"
    );

    // ── Submit all (l_idx, chunk_idx) jobs concurrently ──────────────────────

    let t0 = Instant::now();
    // Key: (l_idx, chunk_idx), value: id rows for that slice.
    #[allow(clippy::type_complexity)]
    let mut join_set: JoinSet<Result<(usize, usize, Vec<Vec<f64>>), NgspiceError>> = JoinSet::new();

    for (l_idx, &l_value) in l_points.iter().enumerate() {
        for (chunk_idx, &(start_i, stop_i)) in vgs_chunks.iter().enumerate() {
            let vgs_chunk = cfg.vgs.slice(start_i, stop_i);
            let n_vgs_chunk = stop_i - start_i + 1;
            let netlist = build_netlist(cfg, l_value, vgs_chunk);
            let pool_ref = Arc::clone(pool);

            let request = SimulationRequest {
                id: format!("lut-l{l_idx}-chunk{chunk_idx}"),
                netlist,
                commands: vec!["run".to_string()],
                return_vectors: Some(vec!["vds#branch".to_string()]),
            };

            let n_vds_cap = n_vds;
            join_set.spawn(async move {
                let resp = pool_ref.run_simulation(request).await?;
                if !resp.success {
                    return Err(NgspiceError::SimulationFailed(format!(
                        "L={l_value:.3e} chunk {chunk_idx} failed: {}",
                        resp.error.as_deref().unwrap_or("(no message)")
                    )));
                }
                let rows = extract_id_rows(&resp, n_vgs_chunk, n_vds_cap)?;
                Ok((l_idx, chunk_idx, rows))
            });
        }
    }

    // ── Collect results ───────────────────────────────────────────────────────

    let mut job_results: Vec<(usize, usize, Vec<Vec<f64>>)> = Vec::with_capacity(total_jobs);

    while let Some(result) = join_set.join_next().await {
        match result {
            Ok(Ok(triple)) => job_results.push(triple),
            Ok(Err(e)) => return Err(e),
            Err(e) => return Err(NgspiceError::WorkerCrashed(e.to_string())),
        }
    }

    let sim_elapsed = t0.elapsed();
    let total_points = n_l * n_vgs_total * n_vds;
    println!(
        "  all {total_jobs} jobs completed in {:.1}ms  ({:.0} op/s)",
        sim_elapsed.as_secs_f64() * 1000.0,
        total_points as f64 / sim_elapsed.as_secs_f64(),
    );

    // ── Assemble 3-D Id grid [l_idx][vgs_idx][vds_idx] ───────────────────────
    //
    // Sort by (l_idx, chunk_idx) to ensure correct concatenation order.

    job_results.sort_by_key(|&(l_idx, c_idx, _)| (l_idx, c_idx));

    let mut id: Vec<Vec<Vec<f64>>> = Vec::with_capacity(n_l);
    for l_idx in 0..n_l {
        let mut id_slice: Vec<Vec<f64>> = Vec::with_capacity(n_vgs_total);
        for &(li, _, ref rows) in job_results.iter().filter(|(li, _, _)| *li == l_idx) {
            debug_assert_eq!(li, l_idx);
            id_slice.extend(rows.iter().cloned());
        }
        debug_assert_eq!(id_slice.len(), n_vgs_total);
        id.push(id_slice);
    }

    // ── Differentiate per L slice ─────────────────────────────────────────────

    let mut gm: Vec<Vec<Vec<f64>>> = Vec::with_capacity(n_l);
    let mut gds: Vec<Vec<Vec<f64>>> = Vec::with_capacity(n_l);
    for id_slice in &id {
        gm.push(diff_vgs(id_slice, cfg.vgs.step));
        gds.push(diff_vds(id_slice, cfg.vds.step));
    }

    let lut = TransistorLut {
        lengths: l_points,
        vgs: cfg.vgs.points(),
        vds: cfg.vds.points(),
        id,
        gm,
        gds,
        width: cfg.width,
        vbs: cfg.vbs,
    };

    if let Some(path) = csv_path {
        lut.write_csv(path)?;
        println!("  CSV written to {}", path.display());
    }

    Ok(lut)
}

// ─────────────────────────────────────────────────────────────────────────────
// Top-level entry point called from main.rs
// ─────────────────────────────────────────────────────────────────────────────

pub async fn run_lut_generation(
    pool: &Arc<WorkerPool>,
    cfg: &LutConfig,
    n_chunks: usize,
    csv_path: Option<&Path>,
) {
    let n_l = cfg.lengths.num_points();
    let n_vgs = cfg.vgs.num_points();
    let n_vds = cfg.vds.num_points();
    let dev = match cfg.device_type {
        DeviceType::Nmos => "NMOS",
        DeviceType::Pmos => "PMOS",
    };

    println!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    println!(" Transistor LUT generation");
    println!(
        "   device  : {dev}  ({})  W={:.3e}",
        cfg.model_name, cfg.width
    );
    if n_l == 1 {
        println!("   L       : {:.3e} m", cfg.length());
    } else {
        println!(
            "   L       : {:.3e} → {:.3e} m  step {:.3e} m  ({n_l} pts)",
            cfg.lengths.start, cfg.lengths.stop, cfg.lengths.step
        );
    }
    println!(
        "   Vgs     : {:.4} → {:.4} V  step {:.4e} V  ({n_vgs} pts)",
        cfg.vgs.start, cfg.vgs.stop, cfg.vgs.step
    );
    println!(
        "   Vds     : {:.4} → {:.4} V  step {:.4e} V  ({n_vds} pts)",
        cfg.vds.start, cfg.vds.stop, cfg.vds.step
    );
    println!("   Vbs     : {:.4} V", cfg.vbs);
    println!("   grid    : {} operating points", n_l * n_vgs * n_vds);
    println!("   workers : {n_chunks}");
    println!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

    match generate_lut(pool, cfg, n_chunks, csv_path).await {
        Ok(lut) => print_lut_summary(&lut),
        Err(e) => {
            eprintln!("  LUT generation failed: {e}");
            std::process::exit(1);
        }
    }
}

fn print_lut_summary(lut: &TransistorLut) {
    let n_l = lut.lengths.len();
    let n_vgs = lut.vgs.len();
    let n_vds = lut.vds.len();

    // Show a sample table for each L value (up to 3; show first+last if more).
    let l_show: Vec<usize> = if n_l <= 3 {
        (0..n_l).collect()
    } else {
        vec![0, n_l - 1]
    };

    let sample = |n: usize| -> Vec<usize> {
        if n <= 6 {
            (0..n).collect()
        } else {
            (0..6).map(|i| i * (n - 1) / 5).collect()
        }
    };
    let gi_s = sample(n_vgs);
    let di_s = sample(n_vds);

    for &li in &l_show {
        println!();
        println!(
            "  L = {:.3e} m — sample (Vgs rows × Vds cols → Id [A]):",
            lut.lengths[li]
        );
        println!();

        print!("  {:>9}", "Vgs\\Vds");
        for &di in &di_s {
            print!("  {:>11.3}", lut.vds[di]);
        }
        println!();
        print!("  {:>9}", "");
        for _ in &di_s {
            print!("  {:>11}", "───────────");
        }
        println!();
        for &gi in &gi_s {
            print!("  {:>9.4}", lut.vgs[gi]);
            for &di in &di_s {
                print!("  {:>11.3e}", lut.id[li][gi][di]);
            }
            println!();
        }
    }

    let (gm_min, gm_max) = min_max(lut.gm.iter().flatten().flatten().copied());
    let (gds_min, gds_max) = min_max(lut.gds.iter().flatten().flatten().copied());
    println!();
    println!("  gm  range: {gm_min:.3e} .. {gm_max:.3e} S");
    println!("  gds range: {gds_min:.3e} .. {gds_max:.3e} S");
    println!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
}

fn min_max(iter: impl Iterator<Item = f64>) -> (f64, f64) {
    iter.fold((f64::INFINITY, f64::NEG_INFINITY), |(lo, hi), v| {
        (lo.min(v), hi.max(v))
    })
}
