/// Error types for the ngspice-rust worker pool.
///
/// `thiserror` generates the `Display` and `Error` impls automatically.
/// The `#[from]` attribute enables the `?` operator to convert standard
/// library errors into our domain error type.

#[derive(Debug, thiserror::Error)]
pub enum NgspiceError {
    /// ngSpice_Init returned a non-zero code, or the callbacks reported a
    /// fatal initialisation error via the SendChar channel.
    #[error("ngspice initialization failed: {0}")]
    InitFailed(String),

    /// A simulation command failed (e.g. syntax error in the netlist,
    /// convergence failure, timeout waiting for the worker's stdout).
    #[error("simulation failed: {0}")]
    SimulationFailed(String),

    /// The worker child process terminated unexpectedly (signal, OOM, etc.).
    /// The pool will attempt to respawn it before the next request.
    #[error("worker process crashed: {0}")]
    WorkerCrashed(String),

    /// JSON encoding/decoding failed on the IPC protocol layer.
    #[error("serialization error: {0}")]
    Serialization(#[from] serde_json::Error),

    /// An OS-level I/O error on the worker's stdin/stdout pipe or on
    /// the process spawning call.
    #[error("I/O error: {0}")]
    Io(#[from] std::io::Error),

    /// All workers are busy and the request could not be queued
    /// (only relevant for bounded-queue configurations).
    #[error("worker pool send failed: all workers are shut down")]
    PoolExhausted,

    /// libloading failed to open libngspice or resolve a required symbol.
    #[error("failed to load libngspice: {0}")]
    LibraryLoad(#[from] libloading::Error),
}
