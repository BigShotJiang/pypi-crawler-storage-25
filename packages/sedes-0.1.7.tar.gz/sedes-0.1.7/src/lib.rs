/// sedes library — exposes the worker pool, protocol types, LUT
/// generation, and (when compiled with `--features python`) PyO3 bindings.
#[allow(dead_code)]
pub mod bindings;
pub mod error;
pub mod gm_id;
pub mod lut;
pub mod ngspice_lib;
pub mod pool;
pub mod protocol;
pub mod worker;

#[cfg(feature = "python")]
mod python;

#[cfg(feature = "python")]
use pyo3::prelude::*;

/// Python extension module entry point (compiled only with `--features python`).
///
/// Exposes:
///   - `SimulationPool`  — async worker pool, synchronous Python API
///   - `LutConfig`       — transistor characterisation configuration
///   - `TransistorLut`   — output LUT with numpy-array accessors
///   - `SimulationResult` — raw simulation output
///   - `_run_worker()`   — internal: runs the ngspice worker loop (called by
///                         the `ngspice-worker` entry-point script)
#[cfg(feature = "python")]
#[pymodule]
fn sedes(m: &Bound<'_, PyModule>) -> PyResult<()> {
    python::register(m)
}
