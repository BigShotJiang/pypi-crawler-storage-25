#!/usr/bin/env bash
# fetch_ngspice.sh — Build or download libngspice and place it in a destination
# directory ready to be bundled inside a Python wheel.
#
# Usage:
#   ./fetch_ngspice.sh <linux|macos|windows> <dest_dir> [cache_dir]
#
# Arguments:
#   platform   One of: linux, macos, windows
#   dest_dir   Directory to copy the final library + COPYING into (created if needed)
#   cache_dir  Optional directory for build cache (default: ./ngspice-cache)
#              On Linux/macOS the source is compiled and the install tree cached here.
#              Pass "" to disable caching (always rebuilds).
#
# The script is idempotent: if the library already exists in dest_dir it exits 0.
#
# After running, dest_dir will contain:
#   libngspice.so.0     (Linux)
#   libngspice.0.dylib  (macOS)
#   ngspice.dll         (Windows)
#   COPYING             (ngspice BSD-3 license notice)
#
# Environment variables honoured:
#   NGSPICE_VERSION   ngspice release to fetch (default: 46)

set -euo pipefail

PLATFORM="${1:?Usage: fetch_ngspice.sh <linux|macos|windows> <dest_dir> [cache_dir]}"
DEST_DIR="${2:?Usage: fetch_ngspice.sh <linux|macos|windows> <dest_dir> [cache_dir]}"
CACHE_DIR="${3:-./ngspice-cache}"
NGSPICE_VERSION="${NGSPICE_VERSION:-45}"

SOURCEFORGE_BASE="https://sourceforge.net/projects/ngspice/files/ng-spice-rework/old-releases/${NGSPICE_VERSION}"

mkdir -p "$DEST_DIR"
# DEST_DIR must also be absolute — auto-tools --prefix rejects relative paths,
# and downstream consumers (rust-quality NGSPICE_LIBRARY_PATH, Python __init__)
# expect a stable absolute location.
DEST_DIR="$(cd "$DEST_DIR" && pwd)"

# Resolve CACHE_DIR to an absolute path.  autoconf --prefix in the Linux/macOS
# build paths rejects relative paths ("expected an absolute directory name").
if [ -n "$CACHE_DIR" ]; then
    mkdir -p "$CACHE_DIR"
    CACHE_DIR="$(cd "$CACHE_DIR" && pwd)"
fi

# ── Helpers ──────────────────────────────────────────────────────────────────

already_present() {
    local lib="$1"
    if [ -f "$DEST_DIR/$lib" ]; then
        echo "fetch_ngspice: $lib already present in $DEST_DIR — skipping"
        exit 0
    fi
}

copy_license() {
    # Copy the upstream COPYING file into dest_dir for wheel attribution.
    local src="$1"
    if [ -f "$src/COPYING" ]; then
        cp "$src/COPYING" "$DEST_DIR/COPYING"
    elif [ -f "$src/COPYING.BSD" ]; then
        cp "$src/COPYING.BSD" "$DEST_DIR/COPYING"
    fi
}

# ── Linux ────────────────────────────────────────────────────────────────────

build_linux() {
    already_present "libngspice.so.0"

    local install_dir="$CACHE_DIR/ngspice-${NGSPICE_VERSION}-install"

    if [ ! -f "$install_dir/lib/libngspice.so" ] && \
       [ ! -f "$install_dir/lib64/libngspice.so" ]; then
        echo "fetch_ngspice: building ngspice ${NGSPICE_VERSION} from source (linux)"

        # Install build toolchain.  Three contexts to support:
        #   - manylinux_2_28 Docker image: root user, dnf, no sudo available.
        #   - ubuntu-latest GH runner: non-root user, apt-get, sudo required.
        #   - ubuntu-latest as root (unlikely but covered): no sudo needed.
        #
        # Detect sudo availability and package manager.
        SUDO=""
        if [ "$(id -u)" != "0" ] && command -v sudo &>/dev/null; then
            SUDO="sudo"
        fi

        if command -v dnf &>/dev/null; then
            $SUDO dnf install -y gcc gcc-c++ make autoconf automake libtool \
                bison flex libffi-devel wget tar
        elif command -v apt-get &>/dev/null; then
            $SUDO apt-get update -qq
            $SUDO apt-get install -y --no-install-recommends \
                gcc g++ make autoconf automake libtool bison flex libffi-dev wget tar
        fi

        local tarball="ngspice-${NGSPICE_VERSION}.tar.gz"
        wget -q "${SOURCEFORGE_BASE}/${tarball}" -O "/tmp/${tarball}"
        tar xf "/tmp/${tarball}" -C /tmp

        pushd "/tmp/ngspice-${NGSPICE_VERSION}"
        ./configure \
            --disable-debug \
            --disable-openmp \
            --with-ngshared \
            --without-x \
            --without-readline \
            --prefix="$install_dir"
        make -j"$(nproc)"
        make install
        popd

        rm -rf "/tmp/ngspice-${NGSPICE_VERSION}" "/tmp/${tarball}"
    else
        echo "fetch_ngspice: using cached ngspice at $install_dir"
    fi

    # Resolve the .so — may be in lib or lib64
    local lib
    lib=$(find "$install_dir" -name 'libngspice.so.0' 2>/dev/null | head -1 || true)
    if [ -z "$lib" ]; then
        # Fallback: unversioned soname
        lib=$(find "$install_dir" -name 'libngspice.so' 2>/dev/null | head -1 || true)
    fi
    if [ -z "$lib" ]; then
        echo "ERROR: libngspice.so not found under $install_dir" >&2
        find "$install_dir" -name 'libngspice*' >&2 || true
        exit 1
    fi

    cp "$lib" "$DEST_DIR/libngspice.so.0"
    copy_license "/tmp/ngspice-${NGSPICE_VERSION}" 2>/dev/null || \
        copy_license "$install_dir/share/doc/ngspice" 2>/dev/null || true
    echo "fetch_ngspice: placed $DEST_DIR/libngspice.so.0"
}

# ── macOS ────────────────────────────────────────────────────────────────────

build_macos() {
    already_present "libngspice.0.dylib"

    local install_dir="$CACHE_DIR/ngspice-${NGSPICE_VERSION}-install"

    if [ ! -f "$install_dir/lib/libngspice.0.dylib" ] && \
       [ ! -f "$install_dir/lib/libngspice.dylib" ]; then
        echo "fetch_ngspice: building ngspice ${NGSPICE_VERSION} from source (macos)"

        local tarball="ngspice-${NGSPICE_VERSION}.tar.gz"
        wget -q "${SOURCEFORGE_BASE}/${tarball}" -O "/tmp/${tarball}" || \
            curl -fsSL "${SOURCEFORGE_BASE}/${tarball}" -o "/tmp/${tarball}"
        tar xf "/tmp/${tarball}" -C /tmp

        pushd "/tmp/ngspice-${NGSPICE_VERSION}"
        # Ensure C++ headers (cmath, etc.) are found on macOS with
        # CommandLineTools-only setups (no full Xcode).
        if command -v xcrun &>/dev/null; then
            export SDKROOT="$(xcrun --sdk macosx --show-sdk-path)"
            export CPLUS_INCLUDE_PATH="$SDKROOT/usr/include/c++/v1"
        fi
        ./configure \
            --disable-debug \
            --disable-openmp \
            --with-ngshared \
            --without-x \
            --without-readline \
            --prefix="$install_dir"
        make -j"$(sysctl -n hw.ncpu)"
        make install
        popd

        rm -rf "/tmp/ngspice-${NGSPICE_VERSION}" "/tmp/${tarball}"
    else
        echo "fetch_ngspice: using cached ngspice at $install_dir"
    fi

    local lib
    lib=$(find "$install_dir/lib" -name 'libngspice.0.dylib' 2>/dev/null | head -1 || true)
    if [ -z "$lib" ]; then
        lib=$(find "$install_dir/lib" -name 'libngspice.dylib' 2>/dev/null | head -1 || true)
    fi
    if [ -z "$lib" ]; then
        echo "ERROR: libngspice dylib not found under $install_dir" >&2
        exit 1
    fi

    cp "$lib" "$DEST_DIR/libngspice.0.dylib"

    # Rewrite install-name so the dylib resolves relative to its loader.
    # When libloading opens the absolute path we pass in NGSPICE_LIBRARY_PATH,
    # the install-name doesn't matter for loading — but it matters if the dylib
    # internally references itself (e.g. for flat-namespace re-exports).
    install_name_tool -id "@loader_path/libngspice.0.dylib" "$DEST_DIR/libngspice.0.dylib"

    # Audit external dependencies — all should be system libs only.
    echo "fetch_ngspice: external deps of bundled dylib:"
    otool -L "$DEST_DIR/libngspice.0.dylib" | grep -v '@loader_path' | grep -v '/usr/lib' | \
        grep -v '/System/' || true

    copy_license "$install_dir" 2>/dev/null || true
    echo "fetch_ngspice: placed $DEST_DIR/libngspice.0.dylib"
}

# ── Windows ──────────────────────────────────────────────────────────────────

fetch_windows() {
    already_present "ngspice.dll"

    echo "fetch_ngspice: downloading prebuilt ngspice ${NGSPICE_VERSION} for Windows"

    # The "_dll_64.7z" archive is the shared-library build — it contains
    # ngspice.dll, sharedspice.h, and a linker .lib.  The "_64.7z" variant is
    # the standalone GUI/console executable and does NOT contain ngspice.dll.
    local archive="ngspice-${NGSPICE_VERSION}_dll_64.7z"
    local url="${SOURCEFORGE_BASE}/${archive}"

    local tmp_dir
    tmp_dir=$(mktemp -d)
    curl -fsSL "$url" -o "$tmp_dir/$archive"

    # 7-Zip is available on GitHub windows-latest runners
    7z x "$tmp_dir/$archive" -o"$tmp_dir/ngspice_extracted" -y

    # Find ngspice.dll anywhere in the extracted tree.
    local dll
    dll=$(find "$tmp_dir/ngspice_extracted" -name 'ngspice.dll' 2>/dev/null | head -1 || true)
    if [ -z "$dll" ]; then
        echo "ERROR: ngspice.dll not found in $archive — listing archive contents:" >&2
        7z l "$tmp_dir/$archive" >&2
        exit 1
    fi

    cp "$dll" "$DEST_DIR/ngspice.dll"

    # Bundle sibling DLLs that ngspice.dll depends on (libomp, etc.).  These
    # must sit in the same directory as ngspice.dll for the Windows loader
    # to find them.
    local dll_parent
    dll_parent="$(dirname "$dll")"
    find "$dll_parent" -maxdepth 1 -name '*.dll' ! -name 'ngspice.dll' -print0 2>/dev/null \
        | while IFS= read -r -d '' extra; do
            cp "$extra" "$DEST_DIR/"
            echo "fetch_ngspice: bundled sibling DLL $(basename "$extra")"
        done

    # Copy license if available
    local copying
    copying=$(find "$tmp_dir/ngspice_extracted" -name 'COPYING' 2>/dev/null | head -1 || true)
    [ -n "$copying" ] && cp "$copying" "$DEST_DIR/COPYING"

    rm -rf "$tmp_dir"
    echo "fetch_ngspice: placed $DEST_DIR/ngspice.dll"
}

# ── Dispatch ─────────────────────────────────────────────────────────────────

case "$PLATFORM" in
    linux)   build_linux   ;;
    macos)   build_macos   ;;
    windows) fetch_windows ;;
    *)
        echo "ERROR: unknown platform '$PLATFORM' — expected linux, macos, or windows" >&2
        exit 1
        ;;
esac
