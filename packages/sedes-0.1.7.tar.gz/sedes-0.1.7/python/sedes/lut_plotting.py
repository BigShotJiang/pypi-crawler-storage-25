"""Design-oriented LUT visualisation.

Three panels — no Vgs/Vds on any axis.  Vgs/Vds are outputs of the design
process, not inputs.

Panel 1: gm/Id vs Intrinsic Gain (gm/gds)
    The fundamental efficiency–gain trade-off.  Designer picks a gm/Id point
    that meets a gain target, then reads off Vgs from the LUT.

Panel 2: gm/Id vs Current Density (Id/W)
    Speed–efficiency trade-off proxy.  Higher Id/W → faster device (higher
    Vgs overdrive), lower gm/Id → less efficient.

Panel 3: Heatmap — Intrinsic Gain over (gm/Id, L) plane
    2-D colour map.  Lets the designer visually identify (gm/Id, L) regions
    that meet a gain specification across the L sweep.

All panels are matplotlib only; this module is not imported unless the user
calls ``.plot()``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from .lut import Lut


def plot_lut_design(lut: "Lut", vds_index: int | None = None):
    """Generate the three-panel design plot.

    Args:
        lut:        A :class:`~sedes.Lut` instance.
        vds_index:  Index into the Vds axis used for the 2-D curves.
                    Default: midpoint.

    Returns:
        The matplotlib ``Figure``.
    """
    import matplotlib.pyplot as plt
    import matplotlib.colors as mcolors

    id_arr = lut.id    # (n_l, n_vgs, n_vds) or (n_vgs, n_vds)
    gm_arr = lut.gm
    gds_arr = lut.gds
    lengths = lut.lengths  # (n_l,)
    vds_axis = lut.vds     # (n_vds,)
    width_lut = lut.width

    # ── Normalise to 3-D ─────────────────────────────────────────────────────
    if id_arr.ndim == 2:
        id_arr = id_arr[np.newaxis]    # (1, n_vgs, n_vds)
        gm_arr = gm_arr[np.newaxis]
        gds_arr = gds_arr[np.newaxis]

    n_l, n_vgs, n_vds = id_arr.shape

    # ── Choose Vds slice ─────────────────────────────────────────────────────
    if vds_index is None:
        vds_index = n_vds // 2
    vds_index = int(np.clip(vds_index, 0, n_vds - 1))
    vds_val = float(vds_axis[vds_index])

    # ── Derived quantities at the chosen Vds ─────────────────────────────────
    id_slice = id_arr[:, :, vds_index]    # (n_l, n_vgs)
    gm_slice = gm_arr[:, :, vds_index]
    gds_slice = gds_arr[:, :, vds_index]

    # Avoid division by zero.
    eps = 1e-18
    gm_id = np.where(np.abs(id_slice) > eps, gm_slice / id_slice, np.nan)
    gain = np.where(np.abs(gds_slice) > eps, gm_slice / gds_slice, np.nan)
    id_per_w = id_slice / width_lut    # current density A/m

    # Restrict to the valid gm/Id operating range.
    GM_ID_MIN = 2.5   # V⁻¹
    GM_ID_MAX = 28.0  # V⁻¹
    valid = (gm_id >= GM_ID_MIN) & (gm_id <= GM_ID_MAX)
    gm_id = np.where(valid, gm_id, np.nan)
    gain = np.where(valid, gain, np.nan)
    id_per_w = np.where(valid, id_per_w, np.nan)

    # ── Colour cycle: one colour per L ───────────────────────────────────────
    cmap = plt.get_cmap("viridis")
    colours = [cmap(i / max(n_l - 1, 1)) for i in range(n_l)]

    # ── Figure ───────────────────────────────────────────────────────────────
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    fig.suptitle(f"gm/Id Design Charts  (Vds = {vds_val:.2f} V)", fontsize=13)

    # ── Panel 1: gm/Id vs Intrinsic Gain ─────────────────────────────────────
    ax1 = axes[0]
    for li in range(n_l):
        # Sort by gm/Id for a clean curve.
        order = np.argsort(gm_id[li])
        x = gm_id[li][order]
        y = gain[li][order]
        label = f"L={float(lengths[li])*1e9:.0f} nm"
        ax1.plot(x, y, color=colours[li], label=label)

    ax1.set_xlabel("gm/Id  (V⁻¹)")
    ax1.set_ylabel("Intrinsic Gain  gm/gds  (V/V)")
    ax1.set_title("Gain vs Efficiency")
    ax1.set_xlim(GM_ID_MIN, GM_ID_MAX)
    ax1.set_ylim(bottom=0)
    ax1.grid(True, alpha=0.3)
    if n_l <= 8:
        ax1.legend(fontsize=8)

    # ── Panel 2: gm/Id vs Current Density ─────────────────────────────────────
    ax2 = axes[1]
    for li in range(n_l):
        order = np.argsort(gm_id[li])
        x = gm_id[li][order]
        y = id_per_w[li][order] * 1e3   # convert to mA/µm for readability
        label = f"L={float(lengths[li])*1e9:.0f} nm"
        ax2.semilogy(x, np.abs(y) + 1e-12, color=colours[li], label=label)

    ax2.set_xlabel("gm/Id  (V⁻¹)")
    ax2.set_ylabel("Current Density  Id/W  (mA/µm)")
    ax2.set_title("Speed–Efficiency Trade-off")
    ax2.set_xlim(GM_ID_MIN, GM_ID_MAX)
    ax2.grid(True, alpha=0.3, which="both")
    if n_l <= 8:
        ax2.legend(fontsize=8)

    # ── Panel 3: Heatmap of Intrinsic Gain ────────────────────────────────────
    ax3 = axes[2]
    if n_l > 1:
        # Build a 2-D image: rows = L, cols = gm/Id (common axis).
        # Each row has its own gm/Id values; interpolate to a shared grid.
        n_grid = 100
        gm_id_grid = np.linspace(GM_ID_MIN, GM_ID_MAX, n_grid)

        heatmap = np.full((n_l, n_grid), np.nan)
        for li in range(n_l):
            x = gm_id[li]
            y = gain[li]
            # Keep only monotone region for interpolation.
            order = np.argsort(x)
            xu, idx = np.unique(x[order], return_index=True)
            yu = y[order][idx]
            heatmap[li] = np.interp(gm_id_grid, xu, yu, left=np.nan, right=np.nan)

        l_nm = lengths * 1e9  # convert m → nm for tick labels
        im = ax3.imshow(
            heatmap,
            aspect="auto",
            origin="lower",
            extent=[GM_ID_MIN, GM_ID_MAX, float(l_nm[0]), float(l_nm[-1])],
            cmap="plasma",
            norm=mcolors.LogNorm(
                vmin=max(np.nanmin(heatmap[heatmap > 0]), 1),
                vmax=np.nanmax(heatmap),
            ),
        )
        fig.colorbar(im, ax=ax3, label="Intrinsic Gain  gm/gds  (V/V)")
        ax3.set_xlabel("gm/Id  (V⁻¹)")
        ax3.set_ylabel("Gate Length  L  (nm)")
        ax3.set_title("Gain Map over Design Space")
    else:
        # Only one L: plot gain as a simple curve.
        order = np.argsort(gm_id[0])
        ax3.plot(gm_id[0][order], gain[0][order])
        ax3.set_xlabel("gm/Id  (V⁻¹)")
        ax3.set_ylabel("Intrinsic Gain  gm/gds  (V/V)")
        ax3.set_title("Gain vs Efficiency")
        ax3.set_xlim(GM_ID_MIN, GM_ID_MAX)
        ax3.grid(True, alpha=0.3)

    fig.tight_layout()
    return fig
