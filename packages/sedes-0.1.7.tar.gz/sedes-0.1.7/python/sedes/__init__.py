import os
import sys
from pathlib import Path

# Point the worker processes at the bundled libngspice before importing the
# Rust extension module.  The worker subprocesses inherit this environment
# variable and resolve the same bundled library automatically.
if "NGSPICE_LIBRARY_PATH" not in os.environ:
    _libdir = Path(__file__).parent / "_libs"
    _candidates = {
        "linux": "libngspice.so.0",
        "darwin": "libngspice.0.dylib",
        "win32": "ngspice.dll",
    }
    _name = _candidates.get(sys.platform)
    if _name and (_libdir / _name).exists():
        os.environ["NGSPICE_LIBRARY_PATH"] = str(_libdir / _name)

        # On Windows, ngspice.dll depends on sibling DLLs (libomp, ivlng, ...)
        # that live next to it in _libs/.  The Windows loader does NOT search
        # the directory of the DLL being loaded for dependencies — it searches
        # PATH and the process DLL directories.  Prepend _libs/ to both so that
        # both this process (os.add_dll_directory) and spawned worker
        # subprocesses (PATH inheritance) can resolve the dependencies.
        if sys.platform == "win32":
            os.environ["PATH"] = str(_libdir) + os.pathsep + os.environ.get("PATH", "")
            if hasattr(os, "add_dll_directory"):
                os.add_dll_directory(str(_libdir))

# Re-export from the compiled Rust extension.
from .sedes import (  # noqa: F401
    _SimulationPool,
    LutConfig,
    TransistorLut,
    SimulationResult,
    DesignResult,
    _run_worker,
)

# Pure-Python API layer.
from .circuit import Circuit  # noqa: F401
from .parser import parse_file, parse_string  # noqa: F401
from .results import (  # noqa: F401
    OpResult,
    DCResult,
    TranResult,
    ACResult,
    NoiseResult,
    SensResult,
    TFResult,
)
from .lut import Lut  # noqa: F401


class SimulationPool:
    """ngspice worker pool.

    Creates and manages N worker processes.  Wraps the Rust ``_SimulationPool``
    and adds a :meth:`generate_lut` that returns an enriched :class:`Lut` (with
    ``.plot()`` and ``.design()`` methods).

    Args:
        workers:      Number of parallel worker processes (default: CPU count).
        timeout_secs: Per-simulation timeout in seconds (default: 120).
        worker_exe:   Override path to the ``ngspice-worker`` binary.
    """

    def __init__(self, workers=None, timeout_secs=120.0, worker_exe=None):
        if workers is not None and worker_exe is not None:
            self._pool = _SimulationPool(
                workers=workers, timeout_secs=timeout_secs, worker_exe=worker_exe
            )
        elif workers is not None:
            self._pool = _SimulationPool(workers=workers, timeout_secs=timeout_secs)
        else:
            self._pool = _SimulationPool(timeout_secs=timeout_secs)

    # ── Delegate everything to the Rust pool ─────────────────────────────────

    def run_simulation(self, netlist, commands, id=None):
        """Run an arbitrary SPICE netlist.

        Args:
            netlist:  Netlist string (multi-line SPICE text).
            commands: List of ngspice commands, e.g. ``["run"]``.
            id:       Optional correlation ID string.

        Returns:
            :class:`~sedes.SimulationResult`
        """
        if id is not None:
            return self._pool.run_simulation(netlist, commands, id=id)
        return self._pool.run_simulation(netlist, commands)

    def generate_lut(self, config, n_chunks=None):
        """Generate a MOSFET look-up table.

        Returns a :class:`~sedes.Lut` wrapper that adds design-oriented
        plotting (:meth:`~sedes.Lut.plot`) and the gm/Id sizing method
        (:meth:`~sedes.Lut.design`).

        Args:
            config:   A :class:`~sedes.LutConfig` describing the sweep.
            n_chunks: Override the number of parallel Vgs chunks.
        """
        if n_chunks is not None:
            raw = self._pool.generate_lut(config, n_chunks=n_chunks)
        else:
            raw = self._pool.generate_lut(config)
        return Lut(raw, config=config, pool=self)

    def __repr__(self):
        return repr(self._pool)


__all__ = [
    # Public API
    "SimulationPool",
    "LutConfig",
    "TransistorLut",
    "SimulationResult",
    "DesignResult",
    "_run_worker",
    # Python API
    "Circuit",
    "parse_file",
    "parse_string",
    "Lut",
    "OpResult",
    "DCResult",
    "TranResult",
    "ACResult",
    "NoiseResult",
    "SensResult",
    "TFResult",
]
