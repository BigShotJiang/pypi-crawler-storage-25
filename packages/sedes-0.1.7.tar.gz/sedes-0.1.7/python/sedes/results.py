"""
Typed simulation result classes.

Each class wraps a raw :class:`~sedes.SimulationResult` and adds
analysis-aware convenience properties and ``.plot()`` methods.

These are returned by :meth:`~sedes.circuit.Circuit.run` depending on
which analysis was added to the circuit.  You can also wrap a raw result
yourself::

    raw = pool.run_simulation(netlist, ["run"])
    result = TranResult(raw)
    result.plot("v(out)", "v(in)")
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from .sedes import SimulationResult


# ─────────────────────────────────────────────────────────────────────────────
# Base — re-exposes everything on SimulationResult
# ─────────────────────────────────────────────────────────────────────────────

class _BaseResult:
    """Thin wrapper around a raw :class:`~sedes.SimulationResult`."""

    def __init__(self, raw: "SimulationResult"):
        self._raw = raw

    # ── Forwarded properties ─────────────────────────────────────────────────

    @property
    def id(self) -> str:
        """Correlation ID."""
        return self._raw.id

    @property
    def success(self) -> bool:
        """``True`` if the simulation completed without errors."""
        return self._raw.success

    @property
    def log(self) -> list[str]:
        """ngspice log lines captured during the simulation."""
        return self._raw.log

    @property
    def error(self) -> str | None:
        """First error message, if any."""
        return self._raw.error

    @property
    def measures(self) -> dict[str, float]:
        """Parsed ``.meas`` results as ``{name: value}``."""
        return self._raw.measures

    def vector_names(self) -> list[str]:
        """List of all vector names available in this result."""
        return self._raw.vector_names()

    def vector(self, name: str) -> np.ndarray:
        """Return a vector by name as a 1-D numpy array."""
        return self._raw.vector(name)

    def vectors_dict(self) -> dict[str, np.ndarray]:
        """Return all vectors as ``{name: np.ndarray}``."""
        return self._raw.vectors_dict()

    def __repr__(self) -> str:
        return (
            f"{type(self).__name__}("
            f"id={self.id!r}, "
            f"success={self.success}, "
            f"vectors={self.vector_names()})"
        )


# ─────────────────────────────────────────────────────────────────────────────
# OpResult
# ─────────────────────────────────────────────────────────────────────────────

class OpResult(_BaseResult):
    """
    DC operating-point result.

    All vectors are scalars (1-element arrays).  Access them by name::

        result = circuit.op().run(pool)
        print(result.node("V(out)"))
    """

    def node(self, name: str) -> float:
        """Return a scalar node voltage or branch current.

        Equivalent to ``result.vector(name)[0]``.
        """
        arr = self.vector(name)
        if len(arr) == 0:
            raise ValueError(f"vector '{name}' is empty")
        return float(arr[0])


# ─────────────────────────────────────────────────────────────────────────────
# DCResult
# ─────────────────────────────────────────────────────────────────────────────

class DCResult(_BaseResult):
    """
    DC sweep result.

    Usage::

        result = circuit.dc("Vin", 0, 1.8, 0.01).run(pool)
        result.plot("v(out)")
    """

    @property
    def sweep(self) -> np.ndarray:
        """The DC sweep axis (swept source values)."""
        for name in self.vector_names():
            if "sweep" in name.lower():
                return self.vector(name)
        names = self.vector_names()
        if names:
            return self.vector(names[0])
        return np.array([])

    def plot(self, *signals: str, ax=None, **kwargs):
        """Plot DC sweep signals versus the sweep axis.

        Args:
            *signals: One or more vector names to plot (e.g. ``"v(out)"``).
            ax:       Existing matplotlib ``Axes`` to draw into. Creates a new
                      figure if not provided.
            **kwargs: Forwarded to ``ax.plot()``.

        Returns:
            The matplotlib ``Axes``.

        Example::

            result.plot("v(out)", "v(in)")
        """
        import matplotlib.pyplot as plt
        if ax is None:
            _, ax = plt.subplots()
        x = self.sweep
        for sig in signals:
            ax.plot(x, self.vector(sig), label=sig, **kwargs)
        ax.set_xlabel("Sweep (V / A)")
        ax.set_ylabel("Signal")
        ax.legend()
        ax.grid(True, alpha=0.3)
        return ax


# ─────────────────────────────────────────────────────────────────────────────
# TranResult
# ─────────────────────────────────────────────────────────────────────────────

class TranResult(_BaseResult):
    """
    Transient analysis result.

    Usage::

        result = circuit.tran("1u", "2m").run(pool)
        result.plot("v(out)", "v(in)")
    """

    @property
    def time(self) -> np.ndarray:
        """Simulation time axis in seconds."""
        for name in self.vector_names():
            if name.lower() == "time":
                return self.vector(name)
        for name in self.vector_names():
            if name.lower().endswith(".time") or name.lower().endswith("time"):
                return self.vector(name)
        return np.array([])

    def plot(self, *signals: str, ax=None, **kwargs):
        """Plot time-domain signals.

        Args:
            *signals: One or more vector names (e.g. ``"v(out)"``, ``"i(r1)"``).
            ax:       Existing matplotlib ``Axes``. Creates a new figure if None.
            **kwargs: Forwarded to ``ax.plot()``.

        Returns:
            The matplotlib ``Axes``.

        Example::

            result.plot("v(out)", "v(in)")
        """
        import matplotlib.pyplot as plt
        if ax is None:
            _, ax = plt.subplots()
        t = self.time
        for sig in signals:
            ax.plot(t, self.vector(sig), label=sig, **kwargs)
        ax.set_xlabel("Time (s)")
        ax.set_ylabel("Signal")
        ax.legend()
        ax.grid(True, alpha=0.3)
        return ax


# ─────────────────────────────────────────────────────────────────────────────
# ACResult
# ─────────────────────────────────────────────────────────────────────────────

class ACResult(_BaseResult):
    """
    AC small-signal analysis result.

    Usage::

        result = circuit.ac("dec", 100, 1, 1e9).run(pool)
        result.plot("v(out)")
    """

    @property
    def frequency(self) -> np.ndarray:
        """Frequency axis in Hz."""
        for name in self.vector_names():
            if name.lower() in ("frequency", "freq"):
                return self.vector(name)
            if name.lower().endswith(".frequency") or name.lower().endswith(".freq"):
                return self.vector(name)
        return np.array([])

    def complex(self, name: str) -> np.ndarray:
        """Return the AC vector as a complex128 numpy array."""
        return self._raw.complex_vector(name)

    def mag(self, name: str) -> np.ndarray:
        """Magnitude |H(f)| in linear scale."""
        return np.abs(self.complex(name))

    def mag_db(self, name: str) -> np.ndarray:
        """Magnitude in dB: ``20 * log10(|H(f)|)``."""
        return 20.0 * np.log10(np.abs(self.complex(name)))

    def phase(self, name: str) -> np.ndarray:
        """Phase in degrees."""
        return np.angle(self.complex(name), deg=True)

    def phase_unwrapped(self, name: str) -> np.ndarray:
        """Unwrapped phase in degrees."""
        return np.unwrap(self.phase(name), period=360.0)

    def plot(self, *signals: str, fig=None, **kwargs):
        """Bode plot (magnitude + phase) for the specified signals.

        Creates two vertically stacked subplots: magnitude (dB) on top,
        phase (degrees) on the bottom.

        Args:
            *signals: One or more vector names (e.g. ``"v(out)"``).
            fig:      Existing matplotlib ``Figure`` to draw into. Creates a
                      new figure if not provided.
            **kwargs: Forwarded to both ``ax.semilogx()`` calls.

        Returns:
            The matplotlib ``Figure``.

        Example::

            result.plot("v(out)")
        """
        import matplotlib.pyplot as plt
        if fig is None:
            fig, _ = plt.subplots(2, 1, sharex=True)
        axes = fig.axes
        ax_mag, ax_ph = axes[0], axes[1]
        f = self.frequency
        for sig in signals:
            ax_mag.semilogx(f, self.mag_db(sig), label=sig, **kwargs)
            ax_ph.semilogx(f, self.phase(sig), label=sig, **kwargs)
        ax_mag.set_ylabel("Magnitude (dB)")
        ax_mag.legend()
        ax_mag.grid(True, alpha=0.3, which="both")
        ax_ph.set_ylabel("Phase (°)")
        ax_ph.set_xlabel("Frequency (Hz)")
        ax_ph.legend()
        ax_ph.grid(True, alpha=0.3, which="both")
        fig.tight_layout()
        return fig


# ─────────────────────────────────────────────────────────────────────────────
# NoiseResult
# ─────────────────────────────────────────────────────────────────────────────

class NoiseResult(_BaseResult):
    """
    Noise analysis result.

    Usage::

        result = circuit.noise("V(out)", "Vin", "dec", 100, 1, 1e9).run(pool)
        result.plot("onoise_spectrum")
    """

    @property
    def frequency(self) -> np.ndarray:
        """Frequency axis in Hz."""
        for name in self.vector_names():
            if "freq" in name.lower():
                return self.vector(name)
        return np.array([])

    def spectral_density(self, name: str | None = None) -> np.ndarray:
        """Return an output noise spectral density vector.

        If *name* is None, returns the first ``onoise`` vector found.
        """
        if name is not None:
            return self.vector(name)
        for n in self.vector_names():
            if "onoise" in n.lower():
                return self.vector(n)
        raise KeyError("no onoise vector found; use vector_names() to inspect")

    def plot(self, *signals: str, ax=None, **kwargs):
        """Log-log plot of noise spectral density.

        Args:
            *signals: One or more vector names. If empty, auto-selects the
                      first ``onoise`` vector.
            ax:       Existing matplotlib ``Axes``.
            **kwargs: Forwarded to ``ax.loglog()``.

        Returns:
            The matplotlib ``Axes``.
        """
        import matplotlib.pyplot as plt
        if ax is None:
            _, ax = plt.subplots()
        f = self.frequency
        if not signals:
            signals = tuple(n for n in self.vector_names() if "noise" in n.lower())
        for sig in signals:
            ax.loglog(f, np.abs(self.vector(sig)), label=sig, **kwargs)
        ax.set_xlabel("Frequency (Hz)")
        ax.set_ylabel("Spectral Density")
        ax.legend()
        ax.grid(True, alpha=0.3, which="both")
        return ax


# ─────────────────────────────────────────────────────────────────────────────
# SensResult / TFResult (thin wrappers)
# ─────────────────────────────────────────────────────────────────────────────

class SensResult(_BaseResult):
    """Sensitivity analysis result. Use ``vector_names()`` to discover outputs."""


class TFResult(_BaseResult):
    """Transfer function result. Use ``vector_names()`` to discover outputs."""


# ─────────────────────────────────────────────────────────────────────────────
# Factory
# ─────────────────────────────────────────────────────────────────────────────

_TYPE_MAP = {
    "op":    OpResult,
    "dc":    DCResult,
    "tran":  TranResult,
    "ac":    ACResult,
    "noise": NoiseResult,
    "sens":  SensResult,
    "tf":    TFResult,
}


def _wrap_result(raw: "SimulationResult", analysis_type: str | None):
    """Wrap a raw :class:`~sedes.SimulationResult` in the appropriate typed class."""
    cls = _TYPE_MAP.get(analysis_type or "")
    if cls is None:
        return raw
    return cls(raw)
