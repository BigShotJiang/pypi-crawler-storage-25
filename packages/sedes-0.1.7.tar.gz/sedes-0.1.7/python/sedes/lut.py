"""Enriched transistor LUT wrapper.

The :class:`Lut` class wraps the Rust ``TransistorLut`` and adds:

* :meth:`plot` — three-panel design-oriented visualisation.
* :meth:`design` — gm/Id transistor sizing (all computation in Rust).

All heavy computation (LUT generation, interpolation, solving) happens in
Rust.  This module only wires together the Rust result with matplotlib.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .sedes import TransistorLut, LutConfig
    from . import SimulationPool


class Lut:
    """Enriched transistor look-up table.

    Created automatically by :meth:`~sedes.SimulationPool.generate_lut`.
    Do not construct directly.
    """

    def __init__(
        self,
        raw_lut: "TransistorLut",
        config: "LutConfig | None" = None,
        pool: "SimulationPool | None" = None,
    ) -> None:
        self._lut = raw_lut
        self._config = config
        self._pool = pool

    # ── Delegate all data properties to the Rust LUT ─────────────────────────

    @property
    def id(self):
        """Drain current Id (A). Shape: (n_vgs, n_vds) or (n_l, n_vgs, n_vds)."""
        return self._lut.id

    @property
    def gm(self):
        """Transconductance gm = ∂Id/∂Vgs (S)."""
        return self._lut.gm

    @property
    def gds(self):
        """Output conductance gds = ∂Id/∂Vds (S)."""
        return self._lut.gds

    @property
    def vgs(self):
        """Vgs axis values (V), shape (n_vgs,)."""
        return self._lut.vgs

    @property
    def vds(self):
        """Vds axis values (V), shape (n_vds,)."""
        return self._lut.vds

    @property
    def lengths(self):
        """Gate-length axis values (m), shape (n_l,). None for single-L LUTs."""
        return self._lut.lengths

    @property
    def width(self) -> float:
        """Gate width used during LUT generation (m)."""
        return self._lut.width

    @property
    def vbs(self) -> float:
        """Bulk-source voltage used during LUT generation (V)."""
        return self._lut.vbs

    def to_csv(self, path: str) -> None:
        """Write L, Vgs, Vds, Id, gm, gds CSV."""
        self._lut.to_csv(path)

    # ── Design-oriented plotting ──────────────────────────────────────────────

    def plot(self, vds_index: int | None = None):
        """Three-panel design-oriented LUT visualisation.

        Panels (no Vgs/Vds on any axis):

        1. **gm/Id vs Intrinsic Gain** (gm/gds) — one curve per L.
           The fundamental efficiency-vs-gain trade-off.
        2. **gm/Id vs Current Density** (Id/W) — one curve per L.
           Shows the speed-efficiency trade-off.
        3. **Heatmap: Intrinsic Gain** over (gm/Id, L) space.
           Visual design-point picker.

        Args:
            vds_index: Index into the Vds axis to slice for 2-D curves.
                       Default: midpoint (saturation region).

        Returns:
            The matplotlib ``Figure``.
        """
        from .lut_plotting import plot_lut_design
        return plot_lut_design(self, vds_index=vds_index)

    # ── gm/Id transistor sizing ───────────────────────────────────────────────

    def design(
        self,
        *,
        gm_id: float | None = None,
        gain: float | None = None,
        ids: float | None = None,
        vds: float | None = None,
        gm_id_min: float = 5.0,
        gm_id_max: float = 25.0,
        id_min: float | None = None,
        mode: str = "interpolation",
    ):
        """Find W, L, Vgs, Vds that satisfy the given design constraints.

        All computation runs in Rust (bilinear interpolation + least-squares
        grid search). No scipy dependency.

        Args:
            gm_id:  Target gm/Id ratio (V⁻¹). Typical: 5–25.
            gain:   Target intrinsic gain gm/gds (V/V).
            ids:    Target drain current (A). Used to back-compute W.
            vds:    Fix the Vds bias point (V). Default: midpoint of LUT axis.
            mode:   ``"interpolation"`` (default) — use this LUT with bilinear
                    refinement between grid points.
                    ``"refinement"`` — run a second fine-grained LUT sweep
                    around the coarse solution (requires the pool reference).

        Returns:
            :class:`~sedes.DesignResult`

        Example::

            result = lut.design(gm_id=15.0, gain=30.0, ids=100e-6)
            print(f"W={result.w:.2e} m, L={result.l:.2e} m")
            print(f"Vgs={result.vgs:.3f} V, gm/Id={result.gm_over_id:.1f}")
        """
        if mode == "refinement":
            return self._design_refinement(
                gm_id=gm_id, gain=gain, ids=ids, vds=vds,
                gm_id_min=gm_id_min, gm_id_max=gm_id_max, id_min=id_min,
            )
        # Interpolation mode: call the Rust solver directly.
        kwargs = dict(gm_id=gm_id, gain=gain, ids=ids, vds=vds,
                      gm_id_min=gm_id_min, gm_id_max=gm_id_max)
        if id_min is not None:
            kwargs["id_min"] = id_min
        return self._lut.design(**kwargs)

    def _design_refinement(
        self,
        *,
        gm_id: float | None,
        gain: float | None,
        ids: float | None,
        vds: float | None,
        gm_id_min: float,
        gm_id_max: float,
        id_min: float | None,
    ):
        """Two-pass refinement: coarse grid → fine LUT → interpolation."""
        if self._pool is None or self._config is None:
            raise RuntimeError(
                "Refinement mode requires a pool reference. "
                "Use lut = pool.generate_lut(config) to get a Lut with a pool."
            )

        # Pass 1: coarse solution using this LUT.
        coarse_kwargs: dict = dict(gm_id=gm_id, gain=gain, ids=ids, vds=vds,
                             gm_id_min=gm_id_min, gm_id_max=gm_id_max)
        if id_min is not None:
            coarse_kwargs["id_min"] = id_min
        coarse = self._lut.design(**coarse_kwargs)

        # Pass 2: generate a fine LUT around the coarse solution.
        import sedes as _sedes

        l_c = coarse.l
        vgs_c = coarse.vgs
        vds_c = coarse.vds

        # Span ±20% around the coarse point, clamped to the original range.
        def _clamp(v, lo, hi):
            return max(lo, min(hi, v))

        l_min = float(self.lengths.min())
        l_max = float(self.lengths.max())
        l_step = max((l_max - l_min) / 200, 1e-9)
        fine_l_lo = _clamp(l_c * 0.8, l_min, l_max)
        fine_l_hi = _clamp(l_c * 1.2, l_min, l_max)

        vgs_arr = self.vgs
        vgs_min = float(vgs_arr.min())
        vgs_max = float(vgs_arr.max())
        vgs_step_orig = float(vgs_arr[1] - vgs_arr[0]) if len(vgs_arr) > 1 else 0.05
        vgs_step = vgs_step_orig / 10
        fine_vgs_lo = _clamp(vgs_c - 0.1, vgs_min, vgs_max)
        fine_vgs_hi = _clamp(vgs_c + 0.1, vgs_min, vgs_max)

        vds_arr = self.vds
        vds_min = float(vds_arr.min())
        vds_max = float(vds_arr.max())
        vds_step_orig = float(vds_arr[1] - vds_arr[0]) if len(vds_arr) > 1 else 0.05
        vds_step = vds_step_orig / 10
        fine_vds_lo = _clamp(vds_c - 0.1, vds_min, vds_max)
        fine_vds_hi = _clamp(vds_c + 0.1, vds_min, vds_max)

        # If the coarse L range is too narrow for a sweep, keep a single L.
        if abs(fine_l_hi - fine_l_lo) < 2 * l_step:
            fine_l_lo = l_c
            fine_l_hi = l_c
            l_step = 1.0  # dummy step for single-point range

        fine_cfg = _sedes.LutConfig(
            device_type=self._config.device_type,
            model_card=self._config.model_card,
            model_file=self._config.model_file,
            model_name=self._config.model_name,
            width=self._config.width,
            lengths=(fine_l_lo, fine_l_hi, l_step),
            vgs=(fine_vgs_lo, fine_vgs_hi, vgs_step),
            vds=(fine_vds_lo, fine_vds_hi, vds_step),
            vbs=self._config.vbs,
        )
        fine_lut = self._pool.generate_lut(fine_cfg)
        fine_kwargs = dict(gm_id=gm_id, gain=gain, ids=ids, vds=vds,
                           gm_id_min=gm_id_min, gm_id_max=gm_id_max)
        if id_min is not None:
            fine_kwargs["id_min"] = id_min
        return fine_lut.design(**fine_kwargs)

    def __repr__(self) -> str:
        return f"Lut({self._lut!r})"
