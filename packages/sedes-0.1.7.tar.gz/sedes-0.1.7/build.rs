/// build.rs — Copies pre-generated FFI bindings into $OUT_DIR so they can be
/// included by src/bindings.rs.
///
/// ngspice is loaded at **runtime** via libloading (dlopen), so no link-time
/// library path is required.  The pregenerated type definitions in
/// src/bindings_pregenerated.rs are sufficient to compile without ngspice
/// installed at all.
///
/// To regenerate bindings after an ngspice API change, set NGSPICE_INCLUDE_DIR
/// to the directory containing sharedspice.h:
///
///   NGSPICE_INCLUDE_DIR=/opt/homebrew/include/ngspice cargo build
///
/// This will re-run bindgen and overwrite src/bindings_pregenerated.rs.
use std::{env, path::PathBuf};

fn main() {
    // ── Bindings ─────────────────────────────────────────────────────────────

    let manifest_dir = PathBuf::from(env::var("CARGO_MANIFEST_DIR").unwrap());
    let out_dir = PathBuf::from(env::var("OUT_DIR").unwrap());
    let pregenerated = manifest_dir.join("src/bindings_pregenerated.rs");

    println!("cargo:rerun-if-env-changed=NGSPICE_INCLUDE_DIR");

    if let Ok(include_dir) = env::var("NGSPICE_INCLUDE_DIR") {
        // Regenerate bindings from the header, then update the committed file so
        // the next build (without NGSPICE_INCLUDE_DIR set) uses fresh bindings.
        let header = format!("{include_dir}/sharedspice.h");
        println!("cargo:rerun-if-changed={header}");

        let bindings = bindgen::Builder::default()
            .header_contents(
                "wrapper.h",
                &format!("#include <stdbool.h>\n#include \"{header}\"\n"),
            )
            .clang_arg(format!("-I{include_dir}"))
            .allowlist_function("ngSpice_Init")
            .allowlist_function("ngSpice_Circ")
            .allowlist_function("ngSpice_Command")
            .allowlist_function("ngGet_Vec_Info")
            .allowlist_function("ngSpice_CurPlot")
            .allowlist_function("ngSpice_AllVecs")
            .allowlist_function("ngSpice_AllPlots")
            .allowlist_function("ngSpice_running")
            .allowlist_type("vector_info")
            .allowlist_type("vecvalues")
            .allowlist_type("vecvaluesall")
            .allowlist_type("vecinfo")
            .allowlist_type("vecinfoall")
            .allowlist_type("ngcomplex")
            .derive_debug(true)
            .layout_tests(false)
            .parse_callbacks(Box::new(bindgen::CargoCallbacks::new()))
            .generate()
            .expect(
                "bindgen failed to generate bindings for sharedspice.h — \
                 check NGSPICE_INCLUDE_DIR and that sharedspice.h is present",
            );

        // Write to $OUT_DIR for this build.
        bindings
            .write_to_file(out_dir.join("bindings.rs"))
            .expect("failed to write bindings.rs");

        // Also overwrite the committed pre-generated file so it stays current.
        bindings
            .write_to_file(&pregenerated)
            .expect("failed to update src/bindings_pregenerated.rs");
    } else {
        // Fast path: no header needed, just copy the committed pre-generated file.
        println!("cargo:rerun-if-changed=src/bindings_pregenerated.rs");
        std::fs::copy(&pregenerated, out_dir.join("bindings.rs"))
            .expect("failed to copy src/bindings_pregenerated.rs to $OUT_DIR/bindings.rs");
    }
}
