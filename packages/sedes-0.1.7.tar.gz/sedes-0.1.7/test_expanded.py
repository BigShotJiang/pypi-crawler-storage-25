"""
Expanded ngspice-rust test — Phase 1 + Phase 2 + Phase 3 verification.

Run with:
    uv run python test_expanded.py
"""

import numpy as np
import matplotlib.pyplot as plt
import sedes
import time
from sedes import (
    Circuit, parse_string,
    TranResult, ACResult, DCResult, OpResult,
)
from sedes.plotting import plot_waveforms, plot_bode, plot_xy

SEP = "━" * 64


def section(title: str) -> None:
    print(f"\n{SEP}")
    print(f" {title}")
    print(SEP)


# ─────────────────────────────────────────────────────────────────────────────
# Pool
# ─────────────────────────────────────────────────────────────────────────────

import os
workers = min(int(os.cpu_count() or 4), 4)
pool = sedes.SimulationPool(workers=workers, timeout_secs=60.0)
print(f"  Pool: {repr(pool)}")


start_time = time.time()

# ─────────────────────────────────────────────────────────────────────────────
# 1. Circuit builder — .tran
# ─────────────────────────────────────────────────────────────────────────────

section("1. Circuit builder — RC low-pass .tran")

ckt = (Circuit("RC low-pass")
    .V("v1", "in", "0", "sin(0 1 1k)")
    .R("r1", "in", "out", "1k")
    .C("c1", "out", "0", "100n")
    .tran("1u", "2m"))

print(f"  Netlist:\n{ckt.to_spice()}")
print()

result = ckt.run(pool)
assert isinstance(result, TranResult), f"expected TranResult, got {type(result)}"
assert result.success, f"simulation failed: {result.error}"
assert len(result.time) > 0, "time vector is empty"
# ngspice uses bare node names for named nodes ("out") vs "V(2)" for numbered.
# Our vector() lookup handles both forms transparently.
names_lower = [n.lower() for n in result.vector_names()]
assert "out" in names_lower or "v(out)" in names_lower, \
    f"output node not in vectors: {result.vector_names()}"

print(f"  Type    : {type(result).__name__}")
print(f"  Vectors : {result.vector_names()}")
print(f"  Time    : {result.time[0]:.3e} .. {result.time[-1]:.3e} s  ({len(result.time)} pts)")
vout = result.vector("v(out)")   # find_vector handles "v(out)" → "out" lookup
print(f"  v(out)  : min={vout.min():.3f}  max={vout.max():.3f}")
assert abs(vout.max()) < 1.0, "output amplitude too large (filter not working?)"

fig1, ax1 = plt.subplots()
plot_waveforms(result, ["in", "out"], ax=ax1, title="1. RC low-pass .tran")
ax1.set_ylabel("Voltage (V)")

print("  PASS")


# ─────────────────────────────────────────────────────────────────────────────
# 2. Circuit builder — .op
# ─────────────────────────────────────────────────────────────────────────────

section("2. Circuit builder — voltage divider .op")

ckt_op = (Circuit("voltage divider")
    .V("vdd", "vdd", "0", "dc 5")
    .R("r1", "vdd", "mid", "1k")
    .R("r2", "mid", "0", "1k")
    .op())

result_op = ckt_op.run(pool)
assert isinstance(result_op, OpResult), f"expected OpResult, got {type(result_op)}"
assert result_op.success, f"op failed: {result_op.error}"

v_mid = result_op.node("V(mid)")
print(f"  V(mid) = {v_mid:.4f} V  (expect 2.5 V)")
assert abs(v_mid - 2.5) < 1e-6, f"wrong V(mid): {v_mid}"
print("  PASS")


# ─────────────────────────────────────────────────────────────────────────────
# 3. Circuit builder — .ac with complex data (Phase 1a fix)
# ─────────────────────────────────────────────────────────────────────────────

section("3. Circuit builder — RC .ac, complex data round-trip")

ckt_ac = (Circuit("RC low-pass AC")
    .V("vin", "in", "0", "ac 1")
    .R("r1", "in", "out", "1k")
    .C("c1", "out", "0", "100n")
    .ac("dec", 20, 100, 10e6))

result_ac = ckt_ac.run(pool)
assert isinstance(result_ac, ACResult), f"expected ACResult, got {type(result_ac)}"
assert result_ac.success, f"ac failed: {result_ac.error}"

freq = result_ac.frequency
assert len(freq) > 0, "frequency vector is empty"

# Complex data must have been transmitted (Phase 1a).
cpx = result_ac.complex("v(out)")
assert cpx.dtype == np.complex128 or np.issubdtype(cpx.dtype, np.complexfloating), \
    f"complex vector dtype is {cpx.dtype}, expected complex"
assert len(cpx) == len(freq), "complex length mismatch"

mag_db = result_ac.mag_db("v(out)")
phase_deg = result_ac.phase("v(out)")


# At f << f_c (100 Hz, f_c ≈ 1.6 kHz): gain should be ~ 0 dB
# At f >> f_c (10 MHz): gain should be << 0 dB
f_c = 1.0 / (2 * np.pi * 1e3 * 100e-9)
print(f"  f_c     ≈ {f_c/1e3:.1f} kHz")
print(f"  Freq    : {freq[0]:.0f} .. {freq[-1]:.0f} Hz  ({len(freq)} pts)")
print(f"  Mag     : {mag_db[0]:.1f} dB .. {mag_db[-1]:.1f} dB")
print(f"  Phase   : {phase_deg[0]:.1f}° .. {phase_deg[-1]:.1f}°")

# At DC-ish (100 Hz), gain should be close to 0 dB.
assert mag_db[0] > -3, f"gain at 100 Hz should be near 0 dB, got {mag_db[0]:.1f}"
# At 10 MHz, gain should be well below -3 dB.
assert mag_db[-1] < -20, f"gain at 10 MHz should be << 0 dB, got {mag_db[-1]:.1f}"

plot_bode(result_ac, "v(out)", title="3. RC low-pass .ac — Bode plot")

print("  PASS")


# ─────────────────────────────────────────────────────────────────────────────
# 4. .meas parsing (Phase 1b fix)
# ─────────────────────────────────────────────────────────────────────────────

section("4. .meas result parsing")

ckt_meas = (Circuit("meas test")
    .V("v1", "in", "0", "pulse(0 1 0 1n 1n 500n 1u)")
    .R("r1", "in", "out", "1k")
    .C("c1", "out", "0", "10n")
    .measure("tran", "vout_max", "MAX V(out)")
    .measure("tran", "vout_min", "MIN V(out)")
    .tran("1n", "20u"))

result_meas = ckt_meas.run(pool)
assert result_meas.success, f"meas simulation failed: {result_meas.error}"

meas = result_meas.measures
print(f"  .meas results: {meas}")
assert "vout_max" in meas, f"vout_max not in measures: {meas}"
assert "vout_min" in meas, f"vout_min not in measures: {meas}"
assert meas["vout_max"] > 0.05, f"vout_max={meas['vout_max']:.3f} unexpectedly low"
assert meas["vout_min"] >= 0.0, f"vout_min={meas['vout_min']:.3f} unexpectedly negative"
print(f"  vout_max = {meas['vout_max']:.4f} V")
print(f"  vout_min = {meas['vout_min']:.4f} V")

fig4, ax4 = plt.subplots()
plot_waveforms(result_meas, ["in", "out"], ax=ax4, title="4. .meas test — pulse response")
ax4.set_ylabel("Voltage (V)")

print("  PASS")


# ─────────────────────────────────────────────────────────────────────────────
# 5. Multi-plot harvesting (Phase 1c) — .op + .ac in one netlist
# ─────────────────────────────────────────────────────────────────────────────

section("5. Multi-plot: .op then .ac in one netlist")

netlist_multi = """\
multi-plot test
Vin in 0 dc 1 ac 1
R1 in out 1k
C1 out 0 100n
.op
.ac dec 10 100 10meg
.end"""

raw_multi = pool.run_simulation(netlist_multi, ["run"])
print(f"  Success : {raw_multi.success}")
print(f"  Vectors : {raw_multi.vector_names()}")
# At minimum we should have AC vectors; .op may merge into the AC plot
# depending on ngspice version.
assert raw_multi.success, f"multi-plot failed: {raw_multi.error}"
assert len(raw_multi.vector_names()) > 0, "no vectors from multi-plot run"
print("  PASS")


# ─────────────────────────────────────────────────────────────────────────────
# 6. Netlist parser — round-trip
# ─────────────────────────────────────────────────────────────────────────────

section("6. Netlist parser — parse + modify + re-simulate")

original_netlist = """\
RC filter
V1 in 0 sin(0 1 1k)
R1 in out 1k
C1 out 0 100n
.tran 1u 2m
.end"""

parsed = parse_string(original_netlist)
print(f"  Parsed  : {repr(parsed)}")
print(f"  Netlist :\n{parsed.to_spice()}")
print()

# Verify components are accessible
r1 = parsed["r1"]
print(f"  R1 line : {r1.to_spice()!r}")
assert "r1" in r1.to_spice().lower(), "R1 not found"

# Modify C1 to 10n (should increase bandwidth)
parsed.replace("c1", "C1 out 0 10n")
result_parsed = parsed.run(pool)
assert isinstance(result_parsed, TranResult), f"expected TranResult, got {type(result_parsed)}"
assert result_parsed.success, f"parsed circuit sim failed: {result_parsed.error}"

vout_modified = result_parsed.vector("v(out)")
print(f"  Modified C1=10n: v(out) max={vout_modified.max():.3f} V")
# With smaller cap, output should be closer to input amplitude (higher bandwidth)
assert vout_modified.max() > 0.7, \
    f"v(out) max {vout_modified.max():.3f} too low for C=10n"

fig6, ax6 = plt.subplots()
plot_waveforms(result_parsed, ["in", "out"], ax=ax6, title="6. Parsed circuit (C1=10n) .tran")
ax6.set_ylabel("Voltage (V)")

print("  PASS")


# ─────────────────────────────────────────────────────────────────────────────
# 7. DC sweep via Circuit builder
# ─────────────────────────────────────────────────────────────────────────────

section("7. Circuit builder — .dc sweep")

ckt_dc = (Circuit("diode I-V")
    .V("vd", "anode", "0", "dc 0")
    .R("rs", "anode", "cathode", "1")
    .D("d1", "cathode", "0", "D1N4148")
    .model(".model D1N4148 D(IS=2.52e-9 N=1.752 BV=110 IBV=0.1e-3 RS=0.568)")
    .dc("vd", 0, 0.8, 0.01))

result_dc = ckt_dc.run(pool)
assert isinstance(result_dc, DCResult), f"expected DCResult, got {type(result_dc)}"
assert result_dc.success, f"dc failed: {result_dc.error}"

sweep = result_dc.sweep
print(f"  Sweep   : {sweep[0]:.2f} .. {sweep[-1]:.2f} V  ({len(sweep)} pts)")
print(f"  Vectors : {result_dc.vector_names()}")

fig7, ax7 = plt.subplots()
plot_xy(result_dc, "v-sweep", "vd#branch", ax=ax7, xlabel="Vd (V)", ylabel="Id (A)")
ax7.set_title("7. Diode I-V curve (.dc sweep)")

print("  PASS")


# ─────────────────────────────────────────────────────────────────────────────
# Done
# ─────────────────────────────────────────────────────────────────────────────

print(f"\n{SEP}")
print(" All expanded tests passed.")
print(SEP)
print(f"Total simulation time: {time.time() - start_time:.2f} seconds")

plt.show()
