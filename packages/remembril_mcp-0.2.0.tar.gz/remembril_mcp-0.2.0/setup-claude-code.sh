#!/usr/bin/env bash
# Setup Remembril MCP server for Claude Code
# Usage: ./setup-claude-code.sh [--url http://localhost:7070]

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
API_URL="${REMEMBRIL_URL:-http://localhost:7070}"
CLAUDE_SETTINGS_DIR="$HOME/.claude"
CLAUDE_SETTINGS="$CLAUDE_SETTINGS_DIR/settings.json"

# Parse args
while [[ $# -gt 0 ]]; do
  case $1 in
    --url) API_URL="$2"; shift 2 ;;
    *) echo "Unknown arg: $1"; exit 1 ;;
  esac
done

echo "=== Remembril MCP Setup for Claude Code ==="
echo ""
echo "API URL: $API_URL"
echo ""

# 1. Install the MCP server
echo "[1/4] Installing remembril-mcp..."
pip install -e "$SCRIPT_DIR" -q 2>/dev/null || pip install -e "$SCRIPT_DIR"
echo "  Installed: $(remembril-mcp --version 2>/dev/null || echo 'ok')"

# 2. Check if backend is running
echo ""
echo "[2/4] Checking backend..."
if curl -sf "$API_URL/docs" > /dev/null 2>&1; then
  echo "  Backend is running at $API_URL"
else
  echo "  WARNING: Backend not reachable at $API_URL"
  echo "  Start it with: cd backend && uvicorn app.main:app --port 7070 --reload"
  echo "  Then re-run this script."
  echo ""
fi

# 3. Get auth token
echo ""
echo "[3/4] Authentication"

TOKEN="${REMEMBRIL_TOKEN:-}"
if [ -z "$TOKEN" ]; then
  echo "  No REMEMBRIL_TOKEN set. Let's log in."
  echo ""
  read -p "  Email: " EMAIL
  read -sp "  Password: " PASSWORD
  echo ""

  RESPONSE=$(curl -sf -X POST "$API_URL/api/v1/qa/auth/login" \
    -H "Content-Type: application/json" \
    -d "{\"email\": \"$EMAIL\", \"password\": \"$PASSWORD\"}" 2>&1) || {
    echo "  Login failed. Create an account first:"
    echo ""
    read -p "  First name: " FIRST
    read -p "  Last name: " LAST

    RESPONSE=$(curl -sf -X POST "$API_URL/api/v1/qa/auth/signup" \
      -H "Content-Type: application/json" \
      -d "{\"email\": \"$EMAIL\", \"password\": \"$PASSWORD\", \"first_name\": \"$FIRST\", \"last_name\": \"$LAST\"}")

    # Login after signup
    RESPONSE=$(curl -sf -X POST "$API_URL/api/v1/qa/auth/login" \
      -H "Content-Type: application/json" \
      -d "{\"email\": \"$EMAIL\", \"password\": \"$PASSWORD\"}")
  }

  TOKEN=$(echo "$RESPONSE" | python3 -c "import sys,json; print(json.load(sys.stdin)['access_token'])" 2>/dev/null)

  if [ -z "$TOKEN" ]; then
    echo "  ERROR: Could not get token. Response: $RESPONSE"
    exit 1
  fi
  echo "  Logged in successfully."
fi

# Save to remembril config
mkdir -p "$HOME/.remembril"
cat > "$HOME/.remembril/config.json" << EOF
{
  "api_url": "$API_URL",
  "token": "$TOKEN"
}
EOF
chmod 600 "$HOME/.remembril/config.json"
echo "  Token saved to ~/.remembril/config.json"

# 4. Configure Claude Code MCP settings
echo ""
echo "[4/4] Configuring Claude Code..."

mkdir -p "$CLAUDE_SETTINGS_DIR"

# Read existing settings or start fresh
if [ -f "$CLAUDE_SETTINGS" ]; then
  EXISTING=$(cat "$CLAUDE_SETTINGS")
else
  EXISTING='{}'
fi

# Merge mcpServers config using python
python3 << PYEOF
import json, sys

try:
    settings = json.loads('''$EXISTING''')
except:
    settings = {}

if "mcpServers" not in settings:
    settings["mcpServers"] = {}

settings["mcpServers"]["remembril"] = {
    "command": "remembril-mcp",
    "args": ["serve"],
    "env": {
        "REMEMBRIL_URL": "$API_URL",
        "REMEMBRIL_TOKEN": "$TOKEN"
    }
}

with open("$CLAUDE_SETTINGS", "w") as f:
    json.dump(settings, f, indent=2)

print("  Added 'remembril' MCP server to $CLAUDE_SETTINGS")
PYEOF

echo ""
echo "=== Setup Complete ==="
echo ""
echo "Restart Claude Code to pick up the MCP server."
echo ""
echo "Then you can say things like:"
echo '  "List my projects"               -> remembril_projects'
echo '  "Create a project called MyApp"  -> remembril_project_create'
echo '  "Set up this repo for coding"    -> remembril_project_configure'
echo '  "Create an issue: fix the bug"   -> remembril_issue_create'
echo '  "Run the pipeline"               -> remembril_pipeline_run'
echo '  "Start the coding loop"          -> remembril_loop_start'
echo ""
