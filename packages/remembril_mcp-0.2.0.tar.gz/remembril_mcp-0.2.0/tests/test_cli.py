"""Tests for CLI generate-token command."""

import json
import pytest
from unittest.mock import patch, AsyncMock, MagicMock
from pathlib import Path
from click.testing import CliRunner

import httpx

from remembril_mcp.cli import main, _extract_token, _generate_token


# ---------------------------------------------------------------------------
# _extract_token unit tests
# ---------------------------------------------------------------------------

class TestExtractToken:
    def test_flat_access_token(self):
        assert _extract_token({"access_token": "tok1"}) == "tok1"

    def test_flat_token(self):
        assert _extract_token({"token": "tok2"}) == "tok2"

    def test_nested_accessToken(self):
        assert _extract_token({"tokens": {"accessToken": "tok3"}}) == "tok3"

    def test_nested_access_token(self):
        assert _extract_token({"tokens": {"access_token": "tok4"}}) == "tok4"

    def test_priority_flat_over_nested(self):
        data = {"access_token": "flat", "tokens": {"accessToken": "nested"}}
        assert _extract_token(data) == "flat"

    def test_empty_dict(self):
        assert _extract_token({}) is None

    def test_no_token_fields(self):
        assert _extract_token({"user": "bob", "status": "ok"}) is None

    def test_empty_tokens_object(self):
        assert _extract_token({"tokens": {}}) is None


# ---------------------------------------------------------------------------
# _generate_token async tests
# ---------------------------------------------------------------------------

class TestGenerateTokenAsync:
    @pytest.mark.asyncio
    async def test_login_success(self):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"tokens": {"accessToken": "jwt-login"}}

        mock_client = AsyncMock()
        mock_client.post.return_value = mock_response
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("remembril_mcp.cli.httpx.AsyncClient", return_value=mock_client):
            result = await _generate_token("http://localhost:7070", "a@b.com", "pass", None, None)

        assert result == "jwt-login"
        mock_client.post.assert_called_once()
        assert "/login" in mock_client.post.call_args[0][0]

    @pytest.mark.asyncio
    async def test_login_fails_signup_success(self):
        login_resp = MagicMock()
        login_resp.status_code = 401

        signup_resp = MagicMock()
        signup_resp.status_code = 200
        signup_resp.json.return_value = {"tokens": {"accessToken": "jwt-signup"}}

        mock_client = AsyncMock()
        mock_client.post.side_effect = [login_resp, signup_resp]
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("remembril_mcp.cli.httpx.AsyncClient", return_value=mock_client):
            result = await _generate_token("http://localhost:7070", "a@b.com", "pass", "Tom", "H")

        assert result == "jwt-signup"
        assert mock_client.post.call_count == 2

    @pytest.mark.asyncio
    async def test_login_fails_no_name_for_signup(self):
        login_resp = MagicMock()
        login_resp.status_code = 401

        mock_client = AsyncMock()
        mock_client.post.return_value = login_resp
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("remembril_mcp.cli.httpx.AsyncClient", return_value=mock_client):
            result = await _generate_token("http://localhost:7070", "a@b.com", "pass", None, None)

        assert result is None

    @pytest.mark.asyncio
    async def test_connection_error(self):
        mock_client = AsyncMock()
        mock_client.post.side_effect = httpx.ConnectError("refused")
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("remembril_mcp.cli.httpx.AsyncClient", return_value=mock_client):
            result = await _generate_token("http://localhost:9999", "a@b.com", "pass", None, None)

        assert result is None

    @pytest.mark.asyncio
    async def test_login_server_error(self):
        resp = MagicMock()
        resp.status_code = 500
        resp.text = "Internal Server Error"

        mock_client = AsyncMock()
        mock_client.post.return_value = resp
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("remembril_mcp.cli.httpx.AsyncClient", return_value=mock_client):
            result = await _generate_token("http://localhost:7070", "a@b.com", "pass", None, None)

        assert result is None

    @pytest.mark.asyncio
    async def test_signup_email_already_exists(self):
        login_resp = MagicMock()
        login_resp.status_code = 401

        signup_resp = MagicMock()
        signup_resp.status_code = 400
        signup_resp.text = "Email already registered"

        mock_client = AsyncMock()
        mock_client.post.side_effect = [login_resp, signup_resp]
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("remembril_mcp.cli.httpx.AsyncClient", return_value=mock_client):
            result = await _generate_token("http://localhost:7070", "a@b.com", "pass", "Tom", "H")

        assert result is None


# ---------------------------------------------------------------------------
# CLI runner integration tests
# ---------------------------------------------------------------------------

class TestGenerateTokenCLI:
    def test_login_saves_token(self, tmp_path, monkeypatch):
        config_dir = tmp_path / ".remembril"
        config_file = config_dir / "config.json"

        async def fake_generate_token(*args):
            return "saved-jwt"

        with patch("remembril_mcp.cli._generate_token", side_effect=fake_generate_token), \
             patch("remembril_mcp.config.Config.config_dir", return_value=config_dir), \
             patch("remembril_mcp.config.Config.config_file", return_value=config_file):
            monkeypatch.delenv("REMEMBRIL_URL", raising=False)
            monkeypatch.delenv("REMEMBRIL_TOKEN", raising=False)
            monkeypatch.delenv("REMEMBRIL_PROJECT_ID", raising=False)

            runner = CliRunner()
            result = runner.invoke(main, [
                "generate-token",
                "-e", "test@example.com",
                "-p", "pass123",
                "-u", "http://localhost:7070",
            ])

        assert result.exit_code == 0
        assert "Token saved" in result.output
        # Verify the config file was written
        assert config_file.exists()
        data = json.loads(config_file.read_text())
        assert data["token"] == "saved-jwt"

    def test_no_save_prints_token(self, tmp_path, monkeypatch):
        async def fake_generate_token(*args):
            return "print-me-jwt"

        config_dir = tmp_path / ".remembril"
        config_file = config_dir / "config.json"

        with patch("remembril_mcp.cli._generate_token", side_effect=fake_generate_token), \
             patch("remembril_mcp.config.Config.config_dir", return_value=config_dir), \
             patch("remembril_mcp.config.Config.config_file", return_value=config_file):
            monkeypatch.delenv("REMEMBRIL_URL", raising=False)
            monkeypatch.delenv("REMEMBRIL_TOKEN", raising=False)
            monkeypatch.delenv("REMEMBRIL_PROJECT_ID", raising=False)

            runner = CliRunner()
            result = runner.invoke(main, [
                "generate-token",
                "-e", "test@example.com",
                "-p", "pass123",
                "-u", "http://localhost:7070",
                "--no-save",
            ])

        assert result.exit_code == 0
        assert "print-me-jwt" in result.output
        assert "Token saved" not in result.output

    def test_failure_exits_nonzero(self, monkeypatch):
        async def fake_generate_token(*args):
            return None

        with patch("remembril_mcp.cli._generate_token", side_effect=fake_generate_token):
            monkeypatch.delenv("REMEMBRIL_URL", raising=False)
            monkeypatch.delenv("REMEMBRIL_TOKEN", raising=False)
            monkeypatch.delenv("REMEMBRIL_PROJECT_ID", raising=False)

            runner = CliRunner()
            result = runner.invoke(main, [
                "generate-token",
                "-e", "test@example.com",
                "-p", "pass123",
                "-u", "http://localhost:7070",
            ])

        assert result.exit_code != 0

    def test_url_defaults_to_localhost(self, tmp_path, monkeypatch):
        """When no --url and config has production default, falls back to localhost."""
        calls = []

        async def fake_generate_token(base_url, *args):
            calls.append(base_url)
            return "tok"

        config_dir = tmp_path / ".remembril"
        config_file = config_dir / "config.json"

        with patch("remembril_mcp.cli._generate_token", side_effect=fake_generate_token), \
             patch("remembril_mcp.config.Config.config_dir", return_value=config_dir), \
             patch("remembril_mcp.config.Config.config_file", return_value=config_file):
            monkeypatch.delenv("REMEMBRIL_URL", raising=False)
            monkeypatch.delenv("REMEMBRIL_TOKEN", raising=False)
            monkeypatch.delenv("REMEMBRIL_PROJECT_ID", raising=False)

            runner = CliRunner()
            result = runner.invoke(main, [
                "generate-token",
                "-e", "test@example.com",
                "-p", "pass123",
            ])

        assert result.exit_code == 0
        assert calls[0] == "http://localhost:7070"
