"""Tests for RembrilClient HTTP methods.

Uses unittest.mock to patch httpx.AsyncClient and verify correct HTTP calls,
headers, error handling, and response parsing.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
import httpx

from remembril_mcp.client import RembrilClient, RembrilError
from remembril_mcp.config import Config


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_response(status_code=200, json_data=None, text=""):
    """Create a mock httpx.Response."""
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.text = text or ""
    resp.json.return_value = json_data if json_data is not None else {}
    return resp


def make_client(token="test-token", api_url="http://localhost:7070"):
    """Create a RembrilClient with a mocked HTTP client."""
    config = Config(api_url=api_url, token=token, default_project_id="proj-001")
    client = RembrilClient(config)
    mock_http = AsyncMock(spec=httpx.AsyncClient)
    client._client = mock_http
    return client, mock_http


# ---------------------------------------------------------------------------
# Client initialization
# ---------------------------------------------------------------------------

class TestClientInit:
    def test_creates_with_config(self):
        config = Config(api_url="http://test.com", token="abc")
        client = RembrilClient(config)
        assert client.config.api_url == "http://test.com"
        assert client.config.token == "abc"

    def test_auth_header_set(self):
        config = Config(api_url="http://test.com", token="mytoken")
        client = RembrilClient(config)
        http = client.client
        assert http._headers.get("Authorization") == "Bearer mytoken"

    def test_no_auth_without_token(self):
        config = Config(api_url="http://test.com", token=None)
        client = RembrilClient(config)
        http = client.client
        assert "Authorization" not in http._headers

    @pytest.mark.asyncio
    async def test_close_resets_client(self):
        client, mock_http = make_client()
        await client.close()
        mock_http.aclose.assert_called_once()
        assert client._client is None


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------

class TestErrorHandling:
    @pytest.mark.asyncio
    async def test_4xx_raises_remembril_error(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(
            404, json_data={"detail": "Not found"}
        )
        with pytest.raises(RembrilError) as exc:
            await client.get_me()
        assert exc.value.status_code == 404
        assert "Not found" in str(exc.value)

    @pytest.mark.asyncio
    async def test_5xx_raises_remembril_error(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(500, text="Internal error")
        with pytest.raises(RembrilError) as exc:
            await client.get_me()
        assert exc.value.status_code == 500

    @pytest.mark.asyncio
    async def test_204_returns_empty_dict(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(204)
        result = await client._request("DELETE", "/something")
        assert result == {}

    @pytest.mark.asyncio
    async def test_error_with_non_json_body(self):
        client, mock_http = make_client()
        resp = make_response(400, text="Bad request")
        resp.json.side_effect = ValueError("Not JSON")
        mock_http.request.return_value = resp
        with pytest.raises(RembrilError):
            await client.get_me()


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

class TestAuth:
    @pytest.mark.asyncio
    async def test_get_me(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(200, {"id": "u1", "email": "t@t.com"})
        result = await client.get_me()
        mock_http.request.assert_called_with("GET", "/api/v1/auth/me")
        assert result["id"] == "u1"


# ---------------------------------------------------------------------------
# Projects
# ---------------------------------------------------------------------------

class TestProjects:
    @pytest.mark.asyncio
    async def test_list_projects(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(200, [{"id": "p1", "name": "Test"}])
        result = await client.list_projects()
        mock_http.request.assert_called_with("GET", "/api/v1/design/projects")
        assert len(result) == 1


# ---------------------------------------------------------------------------
# Issues
# ---------------------------------------------------------------------------

class TestIssues:
    @pytest.mark.asyncio
    async def test_create_issue(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(200, {"id": 1, "title": "Bug"})
        result = await client.create_issue(title="Bug", severity="high")
        call_args = mock_http.request.call_args
        assert call_args[0] == ("POST", "/api/v1/qa/issues")
        body = call_args[1]["json"]
        assert body["title"] == "Bug"
        assert body["severity"] == "high"
        assert body["project_id"] == "proj-001"  # from default

    @pytest.mark.asyncio
    async def test_create_issue_requires_project_id(self):
        config = Config(api_url="http://test.com", token="t")
        client = RembrilClient(config)
        client._client = AsyncMock(spec=httpx.AsyncClient)
        with pytest.raises(RembrilError, match="project_id"):
            await client.create_issue(title="Bug")

    @pytest.mark.asyncio
    async def test_list_issues_with_filters(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(200, [])
        await client.list_issues(status="open", severity="high", project_id="p1")
        call_args = mock_http.request.call_args
        params = call_args[1]["params"]
        assert params["status"] == "open"
        assert params["severity"] == "high"
        assert params["project_id"] == "p1"

    @pytest.mark.asyncio
    async def test_list_issues_no_filters(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(200, [])
        await client.list_issues()
        call_args = mock_http.request.call_args
        assert call_args[1]["params"] == {}

    @pytest.mark.asyncio
    async def test_get_issue(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(200, {"id": 5})
        result = await client.get_issue("ISS-005")
        mock_http.request.assert_called_with("GET", "/api/v1/qa/issues/ISS-005")


# ---------------------------------------------------------------------------
# Ripples
# ---------------------------------------------------------------------------

class TestRipples:
    @pytest.mark.asyncio
    async def test_generate_ripples(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(200, {"ripples": []})
        await client.generate_ripples(42)
        mock_http.request.assert_called_with("POST", "/api/v1/qa/ripples/generate/42")

    @pytest.mark.asyncio
    async def test_approve_ripple(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(200, {"status": "approved"})
        result = await client.approve_ripple(10)
        mock_http.request.assert_called_with("POST", "/api/v1/qa/ripples/10/approve")
        assert result["status"] == "approved"

    @pytest.mark.asyncio
    async def test_reject_ripple(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(200, {})
        await client.reject_ripple(10, "Not relevant")
        call_args = mock_http.request.call_args
        assert call_args[0] == ("POST", "/api/v1/qa/ripples/10/reject")
        assert call_args[1]["json"]["reason"] == "Not relevant"

    @pytest.mark.asyncio
    async def test_update_ripple(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(200, {})
        await client.update_ripple(10, "new changes", "adjusted scope")
        call_args = mock_http.request.call_args
        assert call_args[0] == ("PATCH", "/api/v1/qa/ripples/10")
        body = call_args[1]["json"]
        assert body["suggested_changes"] == "new changes"
        assert body["reviewer_notes"] == "adjusted scope"

    @pytest.mark.asyncio
    async def test_apply_ripple(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(200, {})
        await client.apply_ripple(10)
        mock_http.request.assert_called_with("POST", "/api/v1/qa/ripples/10/apply")

    @pytest.mark.asyncio
    async def test_get_ripple(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(200, {"id": 7})
        result = await client.get_ripple(7)
        mock_http.request.assert_called_with("GET", "/api/v1/qa/ripples/7")

    @pytest.mark.asyncio
    async def test_get_pending_ripples_with_filters(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(200, [])
        await client.get_pending_ripples(project_id="p1", risk_level="high", limit=10)
        params = mock_http.request.call_args[1]["params"]
        assert params["project_id"] == "p1"
        assert params["risk_level"] == "high"
        assert params["limit"] == 10


# ---------------------------------------------------------------------------
# Documents
# ---------------------------------------------------------------------------

class TestDocuments:
    @pytest.mark.asyncio
    async def test_list_documents(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(200, [])
        await client.list_documents(project_id="p1")
        params = mock_http.request.call_args[1]["params"]
        assert params["project_id"] == "p1"

    @pytest.mark.asyncio
    async def test_get_document(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(200, {"id": "DOC-1"})
        result = await client.get_document("DOC-1")
        mock_http.request.assert_called_with("GET", "/api/v1/documents/DOC-1")

    @pytest.mark.asyncio
    async def test_get_traceability(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(200, {"matrix": []})
        await client.get_traceability("proj-001")
        mock_http.request.assert_called_with("GET", "/api/v1/documents/traceability/proj-001")


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------

class TestPipeline:
    @pytest.mark.asyncio
    async def test_run_pipeline(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(200, {"status": "completed"})
        await client.run_pipeline("p1", mode="full_auto")
        body = mock_http.request.call_args[1]["json"]
        assert body["project_id"] == "p1"
        assert body["mode"] == "full_auto"

    @pytest.mark.asyncio
    async def test_pipeline_status(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(200, {})
        await client.pipeline_status("p1")
        params = mock_http.request.call_args[1]["params"]
        assert params["project_id"] == "p1"

    @pytest.mark.asyncio
    async def test_generate_docs(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(200, {})
        await client.generate_docs("p1", output_path="/tmp/docs")
        body = mock_http.request.call_args[1]["json"]
        assert body["project_id"] == "p1"
        assert body["output_path"] == "/tmp/docs"


# ---------------------------------------------------------------------------
# Design
# ---------------------------------------------------------------------------

class TestDesign:
    @pytest.mark.asyncio
    async def test_create_design_project(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(201, {"id": "dp1"})
        await client.create_design_project("My App", description="Cool app")
        body = mock_http.request.call_args[1]["json"]
        assert body["name"] == "My App"
        assert body["description"] == "Cool app"

    @pytest.mark.asyncio
    async def test_design_chat(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(200, {"updated": True})
        await client.design_chat("DOC-1", "Add a login section")
        call_args = mock_http.request.call_args
        assert call_args[0] == ("POST", "/api/v1/documents/DOC-1/chat")
        assert call_args[1]["json"]["message"] == "Add a login section"

    @pytest.mark.asyncio
    async def test_design_generate(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(200, {"id": "DOC-NEW"})
        await client.design_generate(
            doc_type="requirements",
            title="Auth Spec",
            description="Spec for auth",
            project_id="p1",
        )
        body = mock_http.request.call_args[1]["json"]
        assert body["doc_type"] == "requirements"
        assert body["title"] == "Auth Spec"
        assert body["project_id"] == "p1"


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------

class TestOrchestration:
    @pytest.mark.asyncio
    async def test_get_pending_work(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(200, {"pending_issues": 3})
        await client.get_pending_work(project_id="p1")
        params = mock_http.request.call_args[1]["params"]
        assert params["project_id"] == "p1"

    @pytest.mark.asyncio
    async def test_create_orchestration_session(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(200, {"session_id": "s1"})
        await client.create_orchestration_session(
            project_id="p1", mode="parallel", max_iterations=5
        )
        body = mock_http.request.call_args[1]["json"]
        assert body["project_id"] == "p1"
        assert body["mode"] == "parallel"
        assert body["max_iterations"] == 5

    @pytest.mark.asyncio
    async def test_complete_task(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(200, {})
        await client.complete_task("s1", ripple_id=10, success=False, error="timeout")
        call_args = mock_http.request.call_args
        assert "/task/10/complete" in call_args[0][1]
        params = call_args[1]["params"]
        assert params["success"] == "false"
        assert params["error"] == "timeout"

    @pytest.mark.asyncio
    async def test_generate_all_ripples(self):
        client, mock_http = make_client()
        mock_http.request.return_value = make_response(200, {"generated": 5})
        await client.generate_all_ripples("p1")
        params = mock_http.request.call_args[1]["params"]
        assert params["project_id"] == "p1"
