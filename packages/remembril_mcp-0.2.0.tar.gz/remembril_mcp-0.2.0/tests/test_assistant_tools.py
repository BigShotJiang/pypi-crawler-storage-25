"""Tests for Remembril assistant mode tools.

Tests remembril_assist, remembril_context, and remembril_workflow_status
tool handlers and their associated formatters.
"""

import pytest
from unittest.mock import AsyncMock

from remembril_mcp.server import _handle_tool
from remembril_mcp.client import RembrilClient, RembrilError
from remembril_mcp.config import Config
from remembril_mcp.formatters.assistant_fmt import (
    format_assist_narrative,
    format_context_narrative,
    format_workflow_status,
    group_by_type,
    generate_suggestions,
    determine_workflow_phase,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_mock_client():
    """Create a fully mocked RembrilClient."""
    client = AsyncMock(spec=RembrilClient)
    client.config = Config(
        api_url="http://localhost:7070",
        token="test",
        default_project_id="proj-001",
    )
    return client


# ---------------------------------------------------------------------------
# remembril_assist
# ---------------------------------------------------------------------------

class TestAssist:
    @pytest.mark.asyncio
    async def test_full_workflow(self):
        """Issue + ripples + pipeline all succeed."""
        client = make_mock_client()
        client.create_issue.return_value = {
            "id": 42,
            "issue_key": "ISSUE-20260301-001",
        }
        client.generate_ripples.return_value = {
            "ripples": [
                {"target_type": "requirements"},
                {"target_type": "hld"},
            ]
        }
        client.run_pipeline.return_value = {
            "status": "completed",
            "ripples_applied": 2,
            "documents_updated": 2,
        }

        result = await _handle_tool(client, "remembril_assist", {
            "intent": "Fix the signup bug",
        })

        assert not result.isError
        data = result.structuredContent
        assert "issue" in data["steps_completed"]
        assert "ripples" in data["steps_completed"]
        assert "pipeline" in data["steps_completed"]
        assert data["issue"]["id"] == 42
        assert data["ripples"]["count"] == 2
        assert data["pipeline"]["ripples_applied"] == 2

    @pytest.mark.asyncio
    async def test_auto_severity(self):
        """Severity is auto-calculated when not provided."""
        client = make_mock_client()
        client.create_issue.return_value = {"id": 1, "issue_key": "ISS-1"}
        client.generate_ripples.return_value = {"ripples": []}
        client.run_pipeline.return_value = {"status": "completed"}

        result = await _handle_tool(client, "remembril_assist", {
            "intent": "Fix the typo in readme",
        })

        data = result.structuredContent
        assert data["auto_severity"]["level"] == "low"

    @pytest.mark.asyncio
    async def test_provided_severity_used(self):
        """Explicit severity overrides auto-calculation."""
        client = make_mock_client()
        client.create_issue.return_value = {"id": 1, "issue_key": "ISS-1"}
        client.generate_ripples.return_value = {"ripples": []}
        client.run_pipeline.return_value = {"status": "completed"}

        result = await _handle_tool(client, "remembril_assist", {
            "intent": "Fix the typo",
            "severity": "critical",
        })

        client.create_issue.assert_called_once()
        call_kwargs = client.create_issue.call_args[1]
        assert call_kwargs["severity"] == "critical"
        assert "auto_severity" not in result.structuredContent

    @pytest.mark.asyncio
    async def test_step_filtering(self):
        """Only requested steps are executed."""
        client = make_mock_client()
        client.create_issue.return_value = {"id": 1, "issue_key": "ISS-1"}

        result = await _handle_tool(client, "remembril_assist", {
            "intent": "Track this change",
            "steps": ["issue"],
        })

        data = result.structuredContent
        assert data["steps_completed"] == ["issue"]
        client.generate_ripples.assert_not_called()
        client.run_pipeline.assert_not_called()

    @pytest.mark.asyncio
    async def test_loop_step(self):
        """Loop is started when included in steps."""
        client = make_mock_client()
        client.create_issue.return_value = {"id": 1, "issue_key": "ISS-1"}
        client.generate_ripples.return_value = {"ripples": []}
        client.run_pipeline.return_value = {"status": "completed"}
        client.loop_start.return_value = {
            "storm_id": 10,
            "storm_key": "STORM-001",
        }

        result = await _handle_tool(client, "remembril_assist", {
            "intent": "Fix and deploy",
            "steps": ["issue", "ripples", "pipeline", "loop"],
        })

        data = result.structuredContent
        assert "loop" in data["steps_completed"]
        assert data["loop"]["storm_key"] == "STORM-001"

    @pytest.mark.asyncio
    async def test_issue_failure_graceful(self):
        """Issue creation failure doesn't crash; later steps skip."""
        client = make_mock_client()
        client.create_issue.side_effect = RembrilError("Server error")
        client.run_pipeline.return_value = {"status": "completed"}

        result = await _handle_tool(client, "remembril_assist", {
            "intent": "Something",
        })

        data = result.structuredContent
        assert "issue" not in data["steps_completed"]
        assert len(data["errors"]) >= 1
        assert "Issue creation failed" in data["errors"][0]
        # Ripples should be skipped since issue_id is None
        client.generate_ripples.assert_not_called()

    @pytest.mark.asyncio
    async def test_pipeline_failure_graceful(self):
        """Pipeline failure is recorded but doesn't crash."""
        client = make_mock_client()
        client.create_issue.return_value = {"id": 1, "issue_key": "ISS-1"}
        client.generate_ripples.return_value = {"ripples": []}
        client.run_pipeline.side_effect = RembrilError("Timeout")

        result = await _handle_tool(client, "remembril_assist", {
            "intent": "Do something",
        })

        data = result.structuredContent
        assert "issue" in data["steps_completed"]
        assert "ripples" in data["steps_completed"]
        assert "pipeline" not in data["steps_completed"]
        assert any("Pipeline failed" in e for e in data["errors"])

    @pytest.mark.asyncio
    async def test_uses_default_project_id(self):
        """Falls back to config default_project_id."""
        client = make_mock_client()
        client.create_issue.return_value = {"id": 1, "issue_key": "ISS-1"}
        client.generate_ripples.return_value = {"ripples": []}
        client.run_pipeline.return_value = {"status": "completed"}

        await _handle_tool(client, "remembril_assist", {
            "intent": "Something",
        })

        call_kwargs = client.create_issue.call_args[1]
        assert call_kwargs["project_id"] == "proj-001"

    @pytest.mark.asyncio
    async def test_narrative_text(self):
        """Result text contains a readable narrative."""
        client = make_mock_client()
        client.create_issue.return_value = {
            "id": 1,
            "issue_key": "ISSUE-001",
        }
        client.generate_ripples.return_value = {
            "ripples": [{"target_type": "requirements"}]
        }
        client.run_pipeline.return_value = {
            "status": "completed",
            "ripples_applied": 1,
            "documents_updated": 1,
        }

        result = await _handle_tool(client, "remembril_assist", {
            "intent": "Fix the login",
        })

        text = result.content[0].text
        assert "Fix the login" in text
        assert "ISSUE-001" in text
        assert "1 ripples" in text or "1 ripple" in text


# ---------------------------------------------------------------------------
# remembril_context
# ---------------------------------------------------------------------------

class TestContext:
    @pytest.mark.asyncio
    async def test_all_sections(self):
        """All sections returned when no filter specified."""
        client = make_mock_client()
        client.list_issues.return_value = [
            {"id": 1, "status": "open", "title": "Bug"},
            {"id": 2, "status": "closed", "title": "Done"},
        ]
        client.get_pending_work.return_value = {
            "pending_ripples": 3,
            "issues_needing_ripples": 1,
        }
        client.list_documents.return_value = [
            {"id": "DOC-1", "doc_type": "requirements", "title": "Reqs"},
        ]
        client.get_pipeline_settings.return_value = {
            "mode": "full_auto",
            "repo_path": "/code",
        }

        result = await _handle_tool(client, "remembril_context", {})

        data = result.structuredContent
        assert data["issues"]["total"] == 2
        assert data["issues"]["open"] == 1
        assert data["ripples"]["pending_ripples"] == 3
        assert data["documents"]["total"] == 1
        assert data["settings"]["mode"] == "full_auto"
        assert len(data["suggestions"]) > 0

    @pytest.mark.asyncio
    async def test_include_filter(self):
        """Only requested sections are fetched."""
        client = make_mock_client()
        client.list_issues.return_value = [
            {"id": 1, "status": "open", "title": "Bug"},
        ]

        result = await _handle_tool(client, "remembril_context", {
            "include": ["issues"],
        })

        data = result.structuredContent
        assert "issues" in data
        assert "ripples" not in data
        assert "documents" not in data
        assert "settings" not in data

    @pytest.mark.asyncio
    async def test_api_error_graceful(self):
        """API errors are captured, not raised."""
        client = make_mock_client()
        client.list_issues.side_effect = RembrilError("Down")
        client.get_pending_work.side_effect = RembrilError("Down")
        client.list_documents.side_effect = RembrilError("Down")
        client.get_pipeline_settings.side_effect = RembrilError("Down")

        result = await _handle_tool(client, "remembril_context", {})

        data = result.structuredContent
        assert data["issues"]["error"] == "Could not fetch issues"
        assert data["ripples"]["error"] == "Could not fetch pending work"
        assert data["documents"]["error"] == "Could not fetch documents"
        assert data["settings"]["error"] == "Could not fetch settings"

    @pytest.mark.asyncio
    async def test_suggestions_for_no_docs(self):
        """Suggests running pipeline when no docs exist."""
        client = make_mock_client()
        client.list_issues.return_value = [
            {"id": 1, "status": "open", "title": "Bug"},
        ]
        client.get_pending_work.return_value = {"pending_ripples": 0}
        client.list_documents.return_value = []
        client.get_pipeline_settings.return_value = {}

        result = await _handle_tool(client, "remembril_context", {})

        suggestions = result.structuredContent["suggestions"]
        assert any("pipeline" in s.lower() for s in suggestions)

    @pytest.mark.asyncio
    async def test_suggestions_for_pending_ripples(self):
        """Suggests reviewing ripples when there are pending ones."""
        client = make_mock_client()
        client.list_issues.return_value = []
        client.get_pending_work.return_value = {"pending_ripples": 5}
        client.list_documents.return_value = [{"id": "D1", "doc_type": "req"}]
        client.get_pipeline_settings.return_value = {}

        result = await _handle_tool(client, "remembril_context", {})

        suggestions = result.structuredContent["suggestions"]
        assert any("5 pending" in s for s in suggestions)

    @pytest.mark.asyncio
    async def test_narrative_text(self):
        """Result text is formatted markdown."""
        client = make_mock_client()
        client.list_issues.return_value = [
            {"id": 1, "status": "open", "title": "Bug", "severity": "high",
             "issue_key": "ISS-1"},
        ]
        client.get_pending_work.return_value = {"pending_ripples": 0}
        client.list_documents.return_value = []
        client.get_pipeline_settings.return_value = {}

        result = await _handle_tool(client, "remembril_context", {})

        text = result.content[0].text
        assert "Project:" in text
        assert "Issues:" in text


# ---------------------------------------------------------------------------
# remembril_workflow_status
# ---------------------------------------------------------------------------

class TestWorkflowStatus:
    @pytest.mark.asyncio
    async def test_basic_status(self):
        """Returns issue and ripple breakdown."""
        client = make_mock_client()
        client.get_issue.return_value = {
            "id": 42,
            "issue_key": "ISSUE-001",
            "title": "Fix signup",
            "status": "open",
            "phase": "development",
        }
        client.get_ripple_queue.return_value = [
            {"id": 1, "status": "applied"},
            {"id": 2, "status": "applied"},
            {"id": 3, "status": "pending"},
        ]

        result = await _handle_tool(client, "remembril_workflow_status", {
            "issue_id": 42,
        })

        data = result.structuredContent
        assert data["issue"]["key"] == "ISSUE-001"
        assert data["ripples"]["total"] == 3
        assert data["ripples"]["applied"] == 2
        assert data["ripples"]["pending"] == 1

    @pytest.mark.asyncio
    async def test_workflow_phase_detection(self):
        """Workflow phase is correctly determined."""
        client = make_mock_client()
        client.get_issue.return_value = {
            "id": 42,
            "issue_key": "ISSUE-001",
            "title": "Fix",
            "status": "open",
        }
        client.get_ripple_queue.return_value = [
            {"id": 1, "status": "approved"},
            {"id": 2, "status": "approved"},
        ]

        result = await _handle_tool(client, "remembril_workflow_status", {
            "issue_id": 42,
        })

        assert result.structuredContent["workflow_phase"] == "ripples_approved"

    @pytest.mark.asyncio
    async def test_no_ripples_phase(self):
        """No ripples means not_started phase."""
        client = make_mock_client()
        client.get_issue.return_value = {
            "id": 42,
            "issue_key": "ISSUE-001",
            "title": "Fix",
            "status": "open",
        }
        client.get_ripple_queue.return_value = []

        result = await _handle_tool(client, "remembril_workflow_status", {
            "issue_id": 42,
        })

        assert result.structuredContent["workflow_phase"] == "not_started"

    @pytest.mark.asyncio
    async def test_all_applied_phase(self):
        """All ripples applied means applied phase."""
        client = make_mock_client()
        client.get_issue.return_value = {
            "id": 42,
            "issue_key": "ISSUE-001",
            "title": "Fix",
            "status": "open",
        }
        client.get_ripple_queue.return_value = [
            {"id": 1, "status": "applied"},
            {"id": 2, "status": "applied"},
        ]

        result = await _handle_tool(client, "remembril_workflow_status", {
            "issue_id": 42,
        })

        assert result.structuredContent["workflow_phase"] == "applied"

    @pytest.mark.asyncio
    async def test_narrative_text(self):
        """Result text is formatted with issue key and phase."""
        client = make_mock_client()
        client.get_issue.return_value = {
            "id": 42,
            "issue_key": "ISSUE-001",
            "title": "Fix signup",
            "status": "open",
            "phase": "development",
        }
        client.get_ripple_queue.return_value = [
            {"id": 1, "status": "pending"},
        ]

        result = await _handle_tool(client, "remembril_workflow_status", {
            "issue_id": 42,
        })

        text = result.content[0].text
        assert "ISSUE-001" in text
        assert "Fix signup" in text


# ---------------------------------------------------------------------------
# Formatters (unit tests)
# ---------------------------------------------------------------------------

class TestFormatAssistNarrative:
    def test_all_steps(self):
        results = {
            "steps_completed": ["issue", "ripples", "pipeline"],
            "errors": [],
            "issue": {"id": 1, "key": "ISS-1"},
            "ripples": {"count": 3, "by_type": {"requirements": 1, "hld": 1, "lld": 1}},
            "pipeline": {"ripples_applied": 3, "documents_updated": 3},
        }
        text = format_assist_narrative(results, "Fix the bug")
        assert "Fix the bug" in text
        assert "ISS-1" in text
        assert "3 ripples" in text
        assert "3 docs updated" in text or "3 ripples applied" in text

    def test_with_errors(self):
        results = {
            "steps_completed": ["issue"],
            "errors": ["Pipeline failed: timeout"],
            "issue": {"id": 1, "key": "ISS-1"},
        }
        text = format_assist_narrative(results, "Something")
        assert "Pipeline failed" in text

    def test_no_steps(self):
        results = {
            "steps_completed": [],
            "errors": ["Issue creation failed"],
        }
        text = format_assist_narrative(results, "Nothing worked")
        assert "No steps completed" in text

    def test_with_loop(self):
        results = {
            "steps_completed": ["issue", "loop"],
            "errors": [],
            "issue": {"id": 1, "key": "ISS-1"},
            "loop": {"storm_id": 10, "storm_key": "STORM-001"},
        }
        text = format_assist_narrative(results, "Fix and run")
        assert "STORM-001" in text


class TestFormatContextNarrative:
    def test_full_context(self):
        context = {
            "project_id": "proj-001",
            "issues": {"total": 5, "open": 2, "recent": []},
            "ripples": {"pending_ripples": 3},
            "documents": {"total": 7, "by_type": {"requirements": 1, "hld": 1}},
            "suggestions": ["Review 3 pending ripples"],
        }
        text = format_context_narrative(context)
        assert "proj-001" in text
        assert "2 open" in text
        assert "3" in text
        assert "7" in text
        assert "Review 3" in text

    def test_with_errors(self):
        context = {
            "project_id": "proj-001",
            "issues": {"error": "Could not fetch issues"},
        }
        text = format_context_narrative(context)
        assert "Could not fetch issues" in text


class TestFormatWorkflowStatus:
    def test_basic(self):
        result = {
            "issue": {"id": 42, "key": "ISS-1", "title": "Fix", "status": "open", "phase": "dev"},
            "ripples": {"total": 2, "pending": 1, "approved": 1, "applied": 0, "rejected": 0},
            "workflow_phase": "ripples_pending",
        }
        text = format_workflow_status(result)
        assert "ISS-1" in text
        assert "Pending: 1" in text
        assert "awaiting review" in text


class TestGroupByType:
    def test_groups_correctly(self):
        items = [
            {"target_type": "requirements"},
            {"target_type": "hld"},
            {"target_type": "requirements"},
        ]
        groups = group_by_type(items)
        assert groups == {"requirements": 2, "hld": 1}

    def test_custom_key(self):
        items = [{"doc_type": "req"}, {"doc_type": "hld"}, {"doc_type": "req"}]
        groups = group_by_type(items, "doc_type")
        assert groups == {"req": 2, "hld": 1}

    def test_empty_list(self):
        assert group_by_type([]) == {}

    def test_non_dict_items_skipped(self):
        items = [{"target_type": "a"}, "not a dict", None]
        groups = group_by_type(items)
        assert groups == {"a": 1}


class TestGenerateSuggestions:
    def test_suggests_ripple_generation(self):
        context = {
            "ripples": {"issues_needing_ripples": 3, "pending_ripples": 0},
            "issues": {"open": 3},
            "documents": {"total": 5},
        }
        suggestions = generate_suggestions(context)
        assert any("3 issue" in s for s in suggestions)

    def test_suggests_ripple_review(self):
        context = {
            "ripples": {"pending_ripples": 5, "issues_needing_ripples": 0},
            "issues": {"open": 1},
            "documents": {"total": 5},
        }
        suggestions = generate_suggestions(context)
        assert any("5 pending" in s for s in suggestions)

    def test_suggests_no_docs(self):
        context = {
            "ripples": {"pending_ripples": 0},
            "issues": {"open": 1},
            "documents": {"total": 0},
        }
        suggestions = generate_suggestions(context)
        assert any("pipeline" in s.lower() for s in suggestions)

    def test_default_suggestion(self):
        context = {
            "ripples": {"pending_ripples": 0},
            "issues": {"open": 1},
            "documents": {"total": 5},
        }
        suggestions = generate_suggestions(context)
        assert any("looks good" in s.lower() for s in suggestions)


class TestDetermineWorkflowPhase:
    def test_no_ripples(self):
        assert determine_workflow_phase({}, []) == "not_started"

    def test_all_pending(self):
        ripples = [{"status": "pending"}, {"status": "pending"}]
        assert determine_workflow_phase({}, ripples) == "ripples_pending"

    def test_all_approved(self):
        ripples = [{"status": "approved"}, {"status": "approved"}]
        assert determine_workflow_phase({}, ripples) == "ripples_approved"

    def test_all_applied(self):
        ripples = [{"status": "applied"}, {"status": "applied"}]
        assert determine_workflow_phase({}, ripples) == "applied"

    def test_mixed_pending_approved(self):
        ripples = [{"status": "pending"}, {"status": "approved"}]
        assert determine_workflow_phase({}, ripples) == "ripples_pending"

    def test_in_progress(self):
        ripples = [{"status": "in_progress"}, {"status": "applied"}]
        assert determine_workflow_phase({}, ripples) == "in_progress"
