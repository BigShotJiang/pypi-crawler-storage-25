"""Shared fixtures for MCP server tests."""

import pytest


# Sample ripple data used across formatter and server tests
@pytest.fixture
def sample_ripples():
    return [
        {
            "id": 1,
            "risk_level": "low",
            "target_type": "requirements",
            "issue_title": "Add login feature",
            "change_type": "ADDED",
            "section": "features[0].requirements",
        },
        {
            "id": 2,
            "risk_level": "high",
            "target_type": "hld",
            "issue_title": "Refactor auth module",
            "change_type": "MODIFIED",
            "section": "components[1]",
        },
        {
            "id": 3,
            "risk_level": "critical",
            "target_type": "tests",
            "issue_title": "Remove legacy endpoint",
            "change_type": "REMOVED",
            "section": "test_suites[0].cases",
        },
    ]


@pytest.fixture
def sample_traceability():
    return {
        "project_id": "proj-001",
        "doc_types": ["requirements", "prfaq", "hld", "tests", "lld", "compliance"],
        "total_requirements": 3,
        "fully_traced": 1,
        "coverage_percent": 33,
        "matrix": [
            {
                "req_id": "REQ-001-001",
                "requirements": True,
                "prfaq": True,
                "hld": True,
                "tests": True,
                "lld": True,
                "compliance": True,
                "coverage_count": 6,
            },
            {
                "req_id": "REQ-001-002",
                "requirements": True,
                "prfaq": False,
                "hld": True,
                "tests": False,
                "lld": False,
                "compliance": False,
                "coverage_count": 2,
            },
            {
                "req_id": "REQ-002-001",
                "requirements": True,
                "prfaq": False,
                "hld": False,
                "tests": False,
                "lld": False,
                "compliance": False,
                "coverage_count": 1,
            },
        ],
    }


@pytest.fixture
def sample_pipeline_status():
    return {
        "status": "completed",
        "mode": "full_auto",
        "issues_processed": 3,
        "total_issues": 5,
        "ripples_generated": 10,
        "ripples_approved": 8,
        "ripples_applied": 6,
        "documents_updated": 4,
        "documents": [
            {"id": "REQ-001", "doc_type": "requirements", "updated": True},
            {"id": "HLD-001", "doc_type": "hld", "updated": True},
            {"id": "TST-001", "doc_type": "tests", "updated": False},
        ],
        "errors": ["Failed to process issue #5: timeout"],
    }
