"""Tests for Config class and widget HTML validation."""

import json
import os
import pytest
from pathlib import Path
from unittest.mock import patch

from remembril_mcp.config import Config


# ---------------------------------------------------------------------------
# Config defaults
# ---------------------------------------------------------------------------

class TestConfigDefaults:
    def test_default_api_url(self):
        config = Config()
        assert "remembril" in config.api_url

    def test_default_token_is_none(self):
        config = Config()
        assert config.token is None

    def test_default_project_id_is_none(self):
        config = Config()
        assert config.default_project_id is None


# ---------------------------------------------------------------------------
# Config.is_authenticated
# ---------------------------------------------------------------------------

class TestConfigAuthentication:
    def test_authenticated_with_token(self):
        config = Config(token="abc")
        assert config.is_authenticated is True

    def test_not_authenticated_without_token(self):
        config = Config(token=None)
        assert config.is_authenticated is False


# ---------------------------------------------------------------------------
# Config.load() with environment overrides
# ---------------------------------------------------------------------------

class TestConfigEnvOverrides:
    def test_url_from_env(self, monkeypatch):
        monkeypatch.setenv("REMEMBRIL_URL", "http://custom:8080")
        monkeypatch.setenv("REMEMBRIL_TOKEN", "")
        monkeypatch.delenv("REMEMBRIL_PROJECT_ID", raising=False)
        # Use a non-existent config dir to avoid loading real config
        with patch.object(Config, "config_file", return_value=Path("/nonexistent/config.json")):
            config = Config.load()
        assert config.api_url == "http://custom:8080"

    def test_token_from_env(self, monkeypatch):
        monkeypatch.setenv("REMEMBRIL_TOKEN", "env-token")
        monkeypatch.delenv("REMEMBRIL_URL", raising=False)
        monkeypatch.delenv("REMEMBRIL_PROJECT_ID", raising=False)
        with patch.object(Config, "config_file", return_value=Path("/nonexistent/config.json")):
            config = Config.load()
        assert config.token == "env-token"

    def test_project_id_from_env(self, monkeypatch):
        monkeypatch.setenv("REMEMBRIL_PROJECT_ID", "proj-env")
        monkeypatch.delenv("REMEMBRIL_URL", raising=False)
        monkeypatch.delenv("REMEMBRIL_TOKEN", raising=False)
        with patch.object(Config, "config_file", return_value=Path("/nonexistent/config.json")):
            config = Config.load()
        assert config.default_project_id == "proj-env"

    def test_env_overrides_file(self, tmp_path, monkeypatch):
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({
            "api_url": "http://file-url",
            "token": "file-token",
        }))
        monkeypatch.setenv("REMEMBRIL_TOKEN", "env-token")
        monkeypatch.delenv("REMEMBRIL_URL", raising=False)
        monkeypatch.delenv("REMEMBRIL_PROJECT_ID", raising=False)
        with patch.object(Config, "config_file", return_value=config_file):
            config = Config.load()
        assert config.api_url == "http://file-url"  # from file
        assert config.token == "env-token"  # env overrides file


# ---------------------------------------------------------------------------
# Config.load() from file
# ---------------------------------------------------------------------------

class TestConfigFileLoad:
    def test_loads_from_json_file(self, tmp_path, monkeypatch):
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({
            "api_url": "http://from-file",
            "token": "file-tok",
            "default_project_id": "proj-file",
        }))
        monkeypatch.delenv("REMEMBRIL_URL", raising=False)
        monkeypatch.delenv("REMEMBRIL_TOKEN", raising=False)
        monkeypatch.delenv("REMEMBRIL_PROJECT_ID", raising=False)
        with patch.object(Config, "config_file", return_value=config_file):
            config = Config.load()
        assert config.api_url == "http://from-file"
        assert config.token == "file-tok"
        assert config.default_project_id == "proj-file"

    def test_handles_missing_file(self, monkeypatch):
        monkeypatch.delenv("REMEMBRIL_URL", raising=False)
        monkeypatch.delenv("REMEMBRIL_TOKEN", raising=False)
        monkeypatch.delenv("REMEMBRIL_PROJECT_ID", raising=False)
        with patch.object(Config, "config_file", return_value=Path("/does/not/exist.json")):
            config = Config.load()
        assert config.api_url  # has default

    def test_handles_corrupt_json(self, tmp_path, monkeypatch):
        config_file = tmp_path / "config.json"
        config_file.write_text("NOT JSON {{{")
        monkeypatch.delenv("REMEMBRIL_URL", raising=False)
        monkeypatch.delenv("REMEMBRIL_TOKEN", raising=False)
        monkeypatch.delenv("REMEMBRIL_PROJECT_ID", raising=False)
        with patch.object(Config, "config_file", return_value=config_file):
            config = Config.load()  # should not raise
        assert config.api_url  # has default


# ---------------------------------------------------------------------------
# Config.save()
# ---------------------------------------------------------------------------

class TestConfigSave:
    def test_saves_to_json(self, tmp_path):
        config_dir = tmp_path / ".remembril"
        config_file = config_dir / "config.json"
        with patch.object(Config, "config_dir", return_value=config_dir), \
             patch.object(Config, "config_file", return_value=config_file):
            config = Config(api_url="http://saved", token="saved-tok")
            config.save()

        assert config_file.exists()
        data = json.loads(config_file.read_text())
        assert data["api_url"] == "http://saved"
        assert data["token"] == "saved-tok"

    def test_file_permissions_are_600(self, tmp_path):
        config_dir = tmp_path / ".remembril"
        config_file = config_dir / "config.json"
        with patch.object(Config, "config_dir", return_value=config_dir), \
             patch.object(Config, "config_file", return_value=config_file):
            config = Config(token="secret")
            config.save()

        mode = oct(config_file.stat().st_mode)[-3:]
        assert mode == "600"

    def test_excludes_none_values(self, tmp_path):
        config_dir = tmp_path / ".remembril"
        config_file = config_dir / "config.json"
        with patch.object(Config, "config_dir", return_value=config_dir), \
             patch.object(Config, "config_file", return_value=config_file):
            config = Config(api_url="http://test", token=None)
            config.save()

        data = json.loads(config_file.read_text())
        assert "token" not in data


# ---------------------------------------------------------------------------
# Config paths
# ---------------------------------------------------------------------------

class TestConfigPaths:
    def test_config_dir_under_home(self):
        assert ".remembril" in str(Config.config_dir())

    def test_config_file_is_json(self):
        assert Config.config_file().name == "config.json"


# ---------------------------------------------------------------------------
# Widget HTML validation
# ---------------------------------------------------------------------------

WIDGET_DIR = Path(__file__).parent.parent / "src" / "remembril_mcp" / "widgets"

EXPECTED_WIDGETS = ["ripple-review", "traceability", "pipeline-dashboard", "design-preview"]


class TestWidgetHTML:
    @pytest.mark.parametrize("widget_name", EXPECTED_WIDGETS)
    def test_widget_dir_exists(self, widget_name):
        widget_path = WIDGET_DIR / widget_name
        assert widget_path.is_dir(), f"Widget directory missing: {widget_name}"

    @pytest.mark.parametrize("widget_name", EXPECTED_WIDGETS)
    def test_widget_has_index_html(self, widget_name):
        html_path = WIDGET_DIR / widget_name / "index.html"
        assert html_path.exists(), f"Missing index.html for {widget_name}"

    @pytest.mark.parametrize("widget_name", EXPECTED_WIDGETS)
    def test_widget_html_not_empty(self, widget_name):
        html_path = WIDGET_DIR / widget_name / "index.html"
        content = html_path.read_text()
        assert len(content) > 100, f"Widget {widget_name} HTML too short"

    @pytest.mark.parametrize("widget_name", EXPECTED_WIDGETS)
    def test_widget_has_html_structure(self, widget_name):
        html_path = WIDGET_DIR / widget_name / "index.html"
        content = html_path.read_text().lower()
        assert "<html" in content or "<!doctype" in content
        assert "<script" in content  # All widgets have JS
        assert "<style" in content   # All widgets have CSS

    @pytest.mark.parametrize("widget_name", EXPECTED_WIDGETS)
    def test_widget_has_postmessage_bridge(self, widget_name):
        html_path = WIDGET_DIR / widget_name / "index.html"
        content = html_path.read_text()
        assert "postMessage" in content or "addEventListener" in content, \
            f"Widget {widget_name} missing postMessage bridge"

    @pytest.mark.parametrize("widget_name", EXPECTED_WIDGETS)
    def test_widget_handles_tool_result(self, widget_name):
        html_path = WIDGET_DIR / widget_name / "index.html"
        content = html_path.read_text()
        assert "tool-result" in content or "tool_result" in content or "toolResult" in content, \
            f"Widget {widget_name} doesn't handle tool results"

    @pytest.mark.parametrize("widget_name", EXPECTED_WIDGETS)
    def test_widget_has_dark_mode_css(self, widget_name):
        html_path = WIDGET_DIR / widget_name / "index.html"
        content = html_path.read_text()
        assert "prefers-color-scheme: dark" in content, \
            f"Widget {widget_name} missing dark mode CSS"
