"""Tests for MCP formatter functions.

Covers all 9 formatter functions across 5 modules:
- ripple_fmt: format_ripple_queue, format_ripple_diff
- trace_fmt: format_traceability_matrix
- pipeline_fmt: format_pipeline_status
- tables: format_table
- a2ui: build_a2ui_ripple_review, build_a2ui_traceability, build_a2ui_pipeline_dashboard, build_a2ui_design_preview
"""

import pytest

from remembril_mcp.formatters import (
    format_ripple_queue,
    format_ripple_diff,
    format_traceability_matrix,
    format_pipeline_status,
    format_table,
    format_review_detail,
    format_review_list,
    format_debate_detail,
    format_watcher_alerts,
    format_personas,
    build_a2ui_ripple_review,
    build_a2ui_traceability,
    build_a2ui_pipeline_dashboard,
    build_a2ui_design_preview,
    build_a2ui_agent_review,
    build_a2ui_watcher_alerts,
)


# ---------------------------------------------------------------------------
# format_ripple_queue
# ---------------------------------------------------------------------------

class TestFormatRippleQueue:
    def test_empty_returns_no_pending(self):
        assert format_ripple_queue([]) == "No pending ripples."

    def test_header_includes_count(self, sample_ripples):
        result = format_ripple_queue(sample_ripples)
        assert "3 pending" in result

    def test_risk_icons_mapped(self, sample_ripples):
        result = format_ripple_queue(sample_ripples)
        assert "\U0001f7e2" in result  # green for low
        assert "\U0001f7e0" in result  # orange for high
        assert "\U0001f534" in result  # red for critical

    def test_ripple_ids_shown(self, sample_ripples):
        result = format_ripple_queue(sample_ripples)
        assert "#1" in result
        assert "#2" in result
        assert "#3" in result

    def test_issue_titles_shown(self, sample_ripples):
        result = format_ripple_queue(sample_ripples)
        assert "Add login feature" in result
        assert "Refactor auth module" in result

    def test_change_type_and_section_shown(self, sample_ripples):
        result = format_ripple_queue(sample_ripples)
        assert "ADDED" in result
        assert "features[0].requirements" in result

    def test_footer_includes_tool_hints(self, sample_ripples):
        result = format_ripple_queue(sample_ripples)
        assert "remembril_ripple_approve" in result
        assert "remembril_ripple_reject" in result

    def test_unknown_risk_defaults_to_yellow(self):
        ripples = [{"id": 1, "risk_level": "unknown", "change_type": "ADDED", "section": "x"}]
        result = format_ripple_queue(ripples)
        assert "\U0001f7e1" in result  # yellow default

    def test_missing_fields_use_defaults(self):
        ripples = [{}]
        result = format_ripple_queue(ripples)
        assert "#?" in result  # default id
        assert "MEDIUM" in result  # default risk

    def test_fallback_field_names(self):
        ripples = [{"id": 5, "doc_type": "hld", "title": "Test Title"}]
        result = format_ripple_queue(ripples)
        assert "hld" in result
        assert "Test Title" in result


# ---------------------------------------------------------------------------
# format_ripple_diff
# ---------------------------------------------------------------------------

class TestFormatRippleDiff:
    def test_header_includes_ripple_id(self):
        result = format_ripple_diff({"id": 42})
        assert "Ripple #42" in result

    def test_shows_change_details(self):
        ripple = {
            "id": 1,
            "changes": [{
                "target": "REQ-001",
                "change_type": "MODIFIED",
                "section": "features[0]",
            }],
        }
        result = format_ripple_diff(ripple)
        assert "REQ-001" in result
        assert "MODIFIED" in result

    def test_shows_before_after(self):
        ripple = {
            "id": 1,
            "changes": [{
                "target": "DOC-1",
                "change_type": "MODIFIED",
                "section": "overview",
                "before": "Old text",
                "after": "New text",
            }],
        }
        result = format_ripple_diff(ripple)
        assert "Old text" in result
        assert "New text" in result
        assert "Before" in result
        assert "After" in result

    def test_shows_full_requirement_as_json(self):
        ripple = {
            "id": 1,
            "changes": [{
                "target": "DOC-1",
                "change_type": "ADDED",
                "section": "features",
                "full_requirement": {"id": "REQ-001", "name": "Login"},
            }],
        }
        result = format_ripple_diff(ripple)
        assert "REQ-001" in result
        assert "```json" in result

    def test_empty_changes_uses_ripple_itself(self):
        ripple = {
            "id": 1,
            "change_type": "ADDED",
            "target_doc": "DOC-1",
            "section": "features",
        }
        result = format_ripple_diff(ripple)
        assert "DOC-1" in result
        assert "ADDED" in result

    def test_no_changes_at_all(self):
        result = format_ripple_diff({"id": 99})
        assert "Ripple #99" in result


# ---------------------------------------------------------------------------
# format_traceability_matrix
# ---------------------------------------------------------------------------

class TestFormatTraceabilityMatrix:
    def test_empty_matrix(self):
        result = format_traceability_matrix({"matrix": []})
        assert "No requirements" in result

    def test_header_includes_stats(self, sample_traceability):
        result = format_traceability_matrix(sample_traceability)
        assert "3" in result  # total
        assert "1" in result  # fully traced
        assert "33%" in result  # coverage

    def test_table_has_doc_type_columns(self, sample_traceability):
        result = format_traceability_matrix(sample_traceability)
        assert "REQUIREMENTS" in result
        assert "PRFAQ" in result
        assert "HLD" in result
        assert "TESTS" in result

    def test_table_has_req_ids(self, sample_traceability):
        result = format_traceability_matrix(sample_traceability)
        assert "REQ-001-001" in result
        assert "REQ-001-002" in result
        assert "REQ-002-001" in result

    def test_coverage_marks(self, sample_traceability):
        result = format_traceability_matrix(sample_traceability)
        assert "Y" in result
        assert "-" in result

    def test_coverage_count_column(self, sample_traceability):
        result = format_traceability_matrix(sample_traceability)
        assert "6/6" in result  # REQ-001-001
        assert "2/6" in result  # REQ-001-002
        assert "1/6" in result  # REQ-002-001

    def test_has_markdown_table_separators(self, sample_traceability):
        result = format_traceability_matrix(sample_traceability)
        assert "|" in result
        assert "---" in result


# ---------------------------------------------------------------------------
# format_pipeline_status
# ---------------------------------------------------------------------------

class TestFormatPipelineStatus:
    def test_shows_status_and_mode(self, sample_pipeline_status):
        result = format_pipeline_status(sample_pipeline_status)
        assert "completed" in result
        assert "full_auto" in result

    def test_shows_issue_counts(self, sample_pipeline_status):
        result = format_pipeline_status(sample_pipeline_status)
        assert "3/5" in result

    def test_shows_ripple_stats(self, sample_pipeline_status):
        result = format_pipeline_status(sample_pipeline_status)
        assert "10 generated" in result
        assert "8 approved" in result
        assert "6 applied" in result

    def test_shows_documents_updated(self, sample_pipeline_status):
        result = format_pipeline_status(sample_pipeline_status)
        assert "4" in result

    def test_shows_per_document_details(self, sample_pipeline_status):
        result = format_pipeline_status(sample_pipeline_status)
        assert "REQ-001" in result
        assert "[Y]" in result
        assert "[-]" in result

    def test_shows_errors(self, sample_pipeline_status):
        result = format_pipeline_status(sample_pipeline_status)
        assert "timeout" in result
        assert "Errors" in result

    def test_minimal_data(self):
        result = format_pipeline_status({})
        assert "Pipeline Status" in result
        assert "0/0" in result

    def test_no_documents_section_when_empty(self):
        result = format_pipeline_status({"status": "running"})
        assert "Documents" not in result or "updated" in result


# ---------------------------------------------------------------------------
# format_table
# ---------------------------------------------------------------------------

class TestFormatTable:
    def test_empty_rows_shows_no_data(self):
        result = format_table(["A", "B"], [])
        assert "(no data)" in result

    def test_empty_rows_with_title(self):
        result = format_table(["A", "B"], [], title="My Table")
        assert "My Table" in result
        assert "(no data)" in result

    def test_basic_table(self):
        result = format_table(
            ["Name", "Value"],
            [["foo", "1"], ["bar", "2"]],
        )
        assert "Name" in result
        assert "foo" in result
        assert "bar" in result
        assert "|" in result

    def test_column_widths_adapt(self):
        result = format_table(
            ["X", "Y"],
            [["longvalue", "z"]],
        )
        # The separator should be at least as wide as "longvalue"
        lines = result.split("\n")
        sep_line = [l for l in lines if l.startswith("|") and "-" in l][0]
        assert len(sep_line) > 10

    def test_title_becomes_heading(self):
        result = format_table(["A"], [["x"]], title="Report")
        assert "## Report" in result


# ---------------------------------------------------------------------------
# build_a2ui_ripple_review
# ---------------------------------------------------------------------------

class TestBuildA2UIRippleReview:
    def test_version_is_0_8(self, sample_ripples):
        result = build_a2ui_ripple_review(sample_ripples)
        assert result["version"] == "0.8"

    def test_header_component(self, sample_ripples):
        result = build_a2ui_ripple_review(sample_ripples)
        header = result["components"][0]
        assert header["type"] == "Text"
        assert "3 pending" in header["props"]["text"]

    def test_card_per_ripple(self, sample_ripples):
        result = build_a2ui_ripple_review(sample_ripples)
        cards = [c for c in result["components"] if c.get("type") == "Card"]
        assert len(cards) == 3

    def test_card_has_risk_chip(self, sample_ripples):
        result = build_a2ui_ripple_review(sample_ripples)
        card = result["components"][1]  # First card
        chips = [c for c in card["children"] if c.get("type") == "Chip"]
        risk_chip = chips[0]
        assert risk_chip["props"]["label"] == "LOW"

    def test_card_has_action_buttons(self, sample_ripples):
        result = build_a2ui_ripple_review(sample_ripples)
        card = result["components"][1]
        row = [c for c in card["children"] if c.get("type") == "Row"][0]
        buttons = row["children"]
        labels = [b["props"]["label"] for b in buttons]
        assert "Approve" in labels
        assert "Reject" in labels
        assert "View Diff" in labels

    def test_button_ids_include_ripple_id(self, sample_ripples):
        result = build_a2ui_ripple_review(sample_ripples)
        card = result["components"][1]
        row = [c for c in card["children"] if c.get("type") == "Row"][0]
        ids = [b["id"] for b in row["children"]]
        assert "approve-1" in ids
        assert "reject-1" in ids
        assert "diff-1" in ids

    def test_empty_ripples(self):
        result = build_a2ui_ripple_review([])
        assert result["version"] == "0.8"
        assert "0 pending" in result["components"][0]["props"]["text"]

    def test_critical_risk_gets_error_color(self):
        ripples = [{"id": 1, "risk_level": "critical", "change_type": "X", "section": "y"}]
        result = build_a2ui_ripple_review(ripples)
        card = result["components"][1]
        risk_chip = [c for c in card["children"] if c.get("type") == "Chip"][0]
        assert risk_chip["props"]["color"] == "error"


# ---------------------------------------------------------------------------
# build_a2ui_traceability
# ---------------------------------------------------------------------------

class TestBuildA2UITraceability:
    def test_version_is_0_8(self, sample_traceability):
        result = build_a2ui_traceability(sample_traceability)
        assert result["version"] == "0.8"

    def test_has_header_and_table(self, sample_traceability):
        result = build_a2ui_traceability(sample_traceability)
        types = [c["type"] for c in result["components"]]
        assert "Text" in types
        assert "DataTable" in types

    def test_header_shows_coverage_percent(self, sample_traceability):
        result = build_a2ui_traceability(sample_traceability)
        header = result["components"][0]
        assert "33%" in header["props"]["text"]

    def test_table_columns_match_doc_types(self, sample_traceability):
        result = build_a2ui_traceability(sample_traceability)
        table = [c for c in result["components"] if c["type"] == "DataTable"][0]
        col_ids = [c["id"] for c in table["props"]["columns"]]
        assert "req_id" in col_ids
        assert "requirements" in col_ids
        assert "hld" in col_ids
        assert "coverage" in col_ids

    def test_rows_match_matrix(self, sample_traceability):
        result = build_a2ui_traceability(sample_traceability)
        table = [c for c in result["components"] if c["type"] == "DataTable"][0]
        rows = table["props"]["rows"]
        assert len(rows) == 3
        assert rows[0]["req_id"] == "REQ-001-001"
        assert rows[0]["requirements"] is True
        assert rows[0]["coverage"] == "6/6"

    def test_sortable_enabled(self, sample_traceability):
        result = build_a2ui_traceability(sample_traceability)
        table = [c for c in result["components"] if c["type"] == "DataTable"][0]
        assert table["props"]["sortable"] is True


# ---------------------------------------------------------------------------
# build_a2ui_pipeline_dashboard
# ---------------------------------------------------------------------------

class TestBuildA2UIPipelineDashboard:
    def test_version_is_0_8(self, sample_pipeline_status):
        result = build_a2ui_pipeline_dashboard(sample_pipeline_status)
        assert result["version"] == "0.8"

    def test_has_header(self, sample_pipeline_status):
        result = build_a2ui_pipeline_dashboard(sample_pipeline_status)
        header = result["components"][0]
        assert header["type"] == "Text"
        assert "completed" in header["props"]["text"]

    def test_has_four_progress_bars(self, sample_pipeline_status):
        result = build_a2ui_pipeline_dashboard(sample_pipeline_status)
        bars = [c for c in result["components"] if c.get("type") == "ProgressBar"]
        assert len(bars) == 4
        labels = [b["props"]["label"] for b in bars]
        assert "Issues" in labels
        assert "Ripples" in labels
        assert "Approved" in labels
        assert "Applied" in labels

    def test_progress_values(self, sample_pipeline_status):
        result = build_a2ui_pipeline_dashboard(sample_pipeline_status)
        bars = {c["props"]["label"]: c["props"] for c in result["components"] if c.get("type") == "ProgressBar"}
        assert bars["Issues"]["value"] == 3
        assert bars["Issues"]["max"] == 5
        assert bars["Ripples"]["value"] == 10
        assert bars["Approved"]["value"] == 8

    def test_has_action_buttons(self, sample_pipeline_status):
        result = build_a2ui_pipeline_dashboard(sample_pipeline_status)
        rows = [c for c in result["components"] if c.get("type") == "Row"]
        assert len(rows) == 1
        buttons = rows[0]["children"]
        labels = [b["props"]["label"] for b in buttons]
        assert "View Pending Ripples" in labels
        assert "Export Docs" in labels

    def test_zero_values_dont_divide_by_zero(self):
        result = build_a2ui_pipeline_dashboard({})
        bars = [c for c in result["components"] if c.get("type") == "ProgressBar"]
        for bar in bars:
            assert bar["props"]["max"] >= 1  # max(0, 1) = 1


# ---------------------------------------------------------------------------
# build_a2ui_design_preview
# ---------------------------------------------------------------------------

class TestBuildA2UIDesignPreview:
    def test_version_is_0_8(self):
        result = build_a2ui_design_preview({})
        assert result["version"] == "0.8"

    def test_header_shows_title(self):
        result = build_a2ui_design_preview({"title": "Auth Spec"})
        header = result["components"][0]
        assert header["type"] == "Text"
        assert "Auth Spec" in header["props"]["text"]

    def test_header_shows_doc_type_when_no_title(self):
        result = build_a2ui_design_preview({"doc_type": "requirements"})
        header = result["components"][0]
        assert "requirements" in header["props"]["text"]

    def test_summary_card_present(self):
        result = build_a2ui_design_preview({"summary": "Added login section"})
        cards = [c for c in result["components"] if c.get("type") == "Card"]
        assert len(cards) >= 1
        summary_card = cards[0]
        texts = [ch["props"]["text"] for ch in summary_card["children"] if ch.get("type") == "Text"]
        assert "Added login section" in texts

    def test_no_summary_card_when_empty(self):
        result = build_a2ui_design_preview({"title": "Test"})
        cards = [c for c in result["components"] if c.get("type") == "Card"]
        assert len(cards) == 0

    def test_questions_card_present(self):
        result = build_a2ui_design_preview({"questions": ["Auth method?", "Token format?"]})
        cards = [c for c in result["components"] if c.get("id") == "design-questions"]
        assert len(cards) == 1
        q_card = cards[0]
        texts = [ch["props"]["text"] for ch in q_card["children"] if ch.get("type") == "Text"]
        assert any("Auth method?" in t for t in texts)
        assert any("Token format?" in t for t in texts)

    def test_no_questions_card_when_empty(self):
        result = build_a2ui_design_preview({})
        cards = [c for c in result["components"] if c.get("id") == "design-questions"]
        assert len(cards) == 0

    def test_action_buttons_present(self):
        result = build_a2ui_design_preview({"id": "DOC-1"})
        rows = [c for c in result["components"] if c.get("type") == "Row"]
        assert len(rows) == 1
        labels = [b["props"]["label"] for b in rows[0]["children"]]
        assert "View Document" in labels
        assert "Regenerate" in labels

    def test_button_ids_include_doc_id(self):
        result = build_a2ui_design_preview({"id": "DOC-42"})
        rows = [c for c in result["components"] if c.get("type") == "Row"]
        ids = [b["id"] for b in rows[0]["children"]]
        assert "view-DOC-42" in ids
        assert "regenerate-DOC-42" in ids

    def test_empty_data_still_renders(self):
        result = build_a2ui_design_preview({})
        assert len(result["components"]) >= 2  # header + buttons
        assert result["components"][0]["type"] == "Text"

    def test_full_data(self):
        data = {
            "id": "DOC-1",
            "title": "Login Flow",
            "doc_type": "requirements",
            "summary": "Created login spec",
            "questions": ["OAuth or JWT?"],
        }
        result = build_a2ui_design_preview(data)
        assert result["version"] == "0.8"
        types = [c.get("type") for c in result["components"]]
        assert "Text" in types
        assert "Card" in types
        assert "Row" in types


# ---------------------------------------------------------------------------
# onAction callback tests (across all formatters)
# ---------------------------------------------------------------------------

class TestA2UIOnActions:
    """Verify all A2UI buttons have onAction callbacks mapping to MCP tools."""

    def test_ripple_approve_action(self, sample_ripples):
        result = build_a2ui_ripple_review(sample_ripples)
        card = result["components"][1]
        row = [c for c in card["children"] if c.get("type") == "Row"][0]
        approve = row["children"][0]
        assert approve["onAction"]["tool"] == "remembril_ripple_approve"
        assert approve["onAction"]["args"]["ripple_id"] == 1

    def test_ripple_reject_action(self, sample_ripples):
        result = build_a2ui_ripple_review(sample_ripples)
        card = result["components"][1]
        row = [c for c in card["children"] if c.get("type") == "Row"][0]
        reject = row["children"][1]
        assert reject["onAction"]["tool"] == "remembril_ripple_reject"
        assert reject["onAction"]["args"]["ripple_id"] == 1

    def test_ripple_diff_action(self, sample_ripples):
        result = build_a2ui_ripple_review(sample_ripples)
        card = result["components"][1]
        row = [c for c in card["children"] if c.get("type") == "Row"][0]
        diff = row["children"][2]
        assert diff["onAction"]["tool"] == "remembril_ripple_diff"
        assert diff["onAction"]["args"]["ripple_id"] == 1

    def test_pipeline_view_ripples_action(self, sample_pipeline_status):
        result = build_a2ui_pipeline_dashboard(sample_pipeline_status)
        row = [c for c in result["components"] if c.get("type") == "Row"][0]
        view_btn = row["children"][0]
        assert view_btn["onAction"]["tool"] == "remembril_ripples_queue"

    def test_pipeline_export_docs_action(self, sample_pipeline_status):
        result = build_a2ui_pipeline_dashboard(sample_pipeline_status)
        row = [c for c in result["components"] if c.get("type") == "Row"][0]
        export_btn = row["children"][1]
        assert export_btn["onAction"]["tool"] == "remembril_pipeline_generate_docs"

    def test_pipeline_passes_project_id(self):
        data = {"project_id": "proj-42"}
        result = build_a2ui_pipeline_dashboard(data)
        row = [c for c in result["components"] if c.get("type") == "Row"][0]
        assert row["children"][0]["onAction"]["args"]["project_id"] == "proj-42"
        assert row["children"][1]["onAction"]["args"]["project_id"] == "proj-42"

    def test_pipeline_omits_none_project_id(self):
        result = build_a2ui_pipeline_dashboard({})
        row = [c for c in result["components"] if c.get("type") == "Row"][0]
        assert "project_id" not in row["children"][0]["onAction"]["args"]

    def test_design_view_action(self):
        result = build_a2ui_design_preview({"id": "DOC-1"})
        row = [c for c in result["components"] if c.get("type") == "Row"][0]
        view_btn = row["children"][0]
        assert view_btn["onAction"]["tool"] == "remembril_doc_read"
        assert view_btn["onAction"]["args"]["doc_id"] == "DOC-1"

    def test_design_regenerate_action(self):
        result = build_a2ui_design_preview({"id": "DOC-1"})
        row = [c for c in result["components"] if c.get("type") == "Row"][0]
        regen_btn = row["children"][1]
        assert regen_btn["onAction"]["tool"] == "remembril_design_chat"
        assert regen_btn["onAction"]["args"]["doc_id"] == "DOC-1"
        assert "message" in regen_btn["onAction"]["args"]


# ---------------------------------------------------------------------------
# Review formatters (plain text)
# ---------------------------------------------------------------------------

@pytest.fixture
def sample_review():
    return {
        "id": "rev-abc123",
        "status": "completed",
        "individual_advisements": [
            {
                "agent_id": "security",
                "agent_name": "Security Hawk",
                "agent_type": "adversary",
                "position": "block",
                "confidence": 0.95,
                "summary": "Critical XSS vulnerability found",
                "findings": ["XSS in login form", "Missing CSRF token"],
                "concerns": ["No rate limiting"],
                "recommendations": ["Add input sanitization"],
                "praise": ["Good password hashing"],
                "evidence": [],
            },
            {
                "agent_id": "engineer",
                "agent_name": "Principal Engineer",
                "agent_type": "advocate",
                "position": "approve_with_concerns",
                "confidence": 0.75,
                "summary": "Solid architecture with minor issues",
                "findings": ["Missing error handling"],
                "concerns": [],
                "recommendations": ["Add try/catch blocks"],
                "praise": [],
                "evidence": [],
            },
        ],
        "joint_advisement": {
            "recommendation": "block",
            "recommendation_summary": "Security issues must be resolved first",
            "consensus_points": ["Architecture is sound"],
            "action_items": ["Fix XSS vulnerability", "Add CSRF protection"],
            "risks": ["Potential data breach"],
            "dissenting_agents": [],
        },
        "extracted_ripple_ids": [1, 2, 3],
        "alert_count": 2,
    }


@pytest.fixture
def sample_debate():
    return {
        "id": "deb-xyz789",
        "topic": "Should we use microservices or monolith?",
        "status": "concluded",
        "rounds": 3,
        "rounds_completed": 2,
        "messages": [
            {"agent": "engineer", "role": "Principal Engineer", "content": "Monolith is simpler.", "round": 1},
            {"agent": "pm", "role": "Product Manager", "content": "Team velocity matters.", "round": 1},
            {"agent": "engineer", "role": "Principal Engineer", "content": "Agreed on monolith-first.", "round": 2},
        ],
        "consensus": {"reached": True, "summary": "Start monolith, split later"},
    }


@pytest.fixture
def sample_alerts():
    return {
        "items": [
            {
                "id": "alert-1",
                "alert_type": "convergence",
                "severity": "info",
                "description": "All 3 agents agreed on block",
                "handled": False,
                "involved_agents": ["security", "engineer", "customer"],
            },
            {
                "id": "alert-2",
                "alert_type": "independent_discovery",
                "severity": "warning",
                "description": "2 agents found XSS independently",
                "handled": True,
                "involved_agents": ["security", "customer"],
            },
        ]
    }


@pytest.fixture
def sample_personas_data():
    return {
        "items": [
            {"id": "security", "name": "Security Hawk", "type": "adversary",
             "role": "Security analyst", "goal": "Find vulnerabilities"},
            {"id": "engineer", "name": "Principal Engineer", "type": "advocate",
             "role": "Senior engineer", "goal": "Ensure code quality"},
            {"id": "ghost_user", "name": "Ghost User", "type": "ghost",
             "role": "Silent observer", "goal": "Detect blind spots"},
        ]
    }


class TestFormatReviewDetail:
    def test_shows_status(self, sample_review):
        result = format_review_detail(sample_review)
        assert "COMPLETED" in result

    def test_shows_review_id(self, sample_review):
        result = format_review_detail(sample_review)
        assert "rev-abc123" in result

    def test_shows_committee_count(self, sample_review):
        result = format_review_detail(sample_review)
        assert "2 agents" in result

    def test_shows_agent_positions(self, sample_review):
        result = format_review_detail(sample_review)
        assert "Security Hawk" in result
        assert "block" in result
        assert "95%" in result

    def test_shows_findings(self, sample_review):
        result = format_review_detail(sample_review)
        assert "XSS in login form" in result

    def test_shows_joint_recommendation(self, sample_review):
        result = format_review_detail(sample_review)
        assert "Joint Recommendation" in result
        assert "Security issues must be resolved" in result

    def test_shows_action_items(self, sample_review):
        result = format_review_detail(sample_review)
        assert "Fix XSS vulnerability" in result

    def test_shows_ripple_count(self, sample_review):
        result = format_review_detail(sample_review)
        assert "3 ripple" in result

    def test_shows_alert_count(self, sample_review):
        result = format_review_detail(sample_review)
        assert "2 watcher alert" in result

    def test_empty_review(self):
        result = format_review_detail({"id": "r1", "status": "pending"})
        assert "PENDING" in result


class TestFormatReviewList:
    def test_shows_total(self):
        data = {"items": [{"id": "r1", "status": "completed"}], "total": 1}
        result = format_review_list(data)
        assert "1 total" in result

    def test_empty_list(self):
        result = format_review_list({"items": [], "total": 0})
        assert "No reviews found" in result

    def test_shows_status_icon(self):
        data = {"items": [{"id": "abcdef12-xxxx", "status": "completed", "trigger_type": "manual"}], "total": 1}
        result = format_review_list(data)
        assert "abcdef12" in result


class TestFormatDebateDetail:
    def test_shows_topic(self, sample_debate):
        result = format_debate_detail(sample_debate)
        assert "microservices or monolith" in result

    def test_shows_status(self, sample_debate):
        result = format_debate_detail(sample_debate)
        assert "CONCLUDED" in result

    def test_shows_round_progress(self, sample_debate):
        result = format_debate_detail(sample_debate)
        assert "2/3" in result

    def test_shows_messages(self, sample_debate):
        result = format_debate_detail(sample_debate)
        assert "Monolith is simpler" in result
        assert "engineer" in result

    def test_shows_consensus(self, sample_debate):
        result = format_debate_detail(sample_debate)
        assert "Reached" in result
        assert "Start monolith" in result


class TestFormatWatcherAlerts:
    def test_shows_alert_count(self, sample_alerts):
        result = format_watcher_alerts(sample_alerts)
        assert "2" in result

    def test_shows_alert_types(self, sample_alerts):
        result = format_watcher_alerts(sample_alerts)
        assert "convergence" in result
        assert "independent_discovery" in result

    def test_shows_handled_status(self, sample_alerts):
        result = format_watcher_alerts(sample_alerts)
        assert "open" in result
        assert "handled" in result

    def test_shows_agents(self, sample_alerts):
        result = format_watcher_alerts(sample_alerts)
        assert "security" in result

    def test_empty_alerts(self):
        result = format_watcher_alerts({"items": []})
        assert "No watcher alerts" in result


class TestFormatPersonas:
    def test_shows_persona_count(self, sample_personas_data):
        result = format_personas(sample_personas_data)
        assert "3" in result

    def test_shows_persona_details(self, sample_personas_data):
        result = format_personas(sample_personas_data)
        assert "Security Hawk" in result
        assert "security" in result
        assert "adversary" in result

    def test_shows_type_icons(self, sample_personas_data):
        result = format_personas(sample_personas_data)
        # Ghost type should use ghost icon
        assert "Ghost User" in result

    def test_empty_personas(self):
        result = format_personas({"items": []})
        assert "No personas found" in result


# ---------------------------------------------------------------------------
# build_a2ui_agent_review
# ---------------------------------------------------------------------------

class TestBuildA2UIAgentReview:
    def test_version_is_0_8(self, sample_review):
        result = build_a2ui_agent_review(sample_review)
        assert result["version"] == "0.8"

    def test_has_header(self, sample_review):
        result = build_a2ui_agent_review(sample_review)
        header = result["components"][0]
        assert header["type"] == "Text"
        assert "completed" in header["props"]["text"]

    def test_card_per_agent(self, sample_review):
        result = build_a2ui_agent_review(sample_review)
        cards = [c for c in result["components"] if c.get("type") == "Card"]
        # 2 agent cards + 1 joint card = 3
        assert len(cards) == 3

    def test_agent_card_has_position_chip(self, sample_review):
        result = build_a2ui_agent_review(sample_review)
        card = result["components"][1]
        chips = [c for c in card["children"] if c.get("type") == "Chip"]
        positions = [ch["props"]["label"] for ch in chips]
        assert "block" in positions

    def test_joint_card_present(self, sample_review):
        result = build_a2ui_agent_review(sample_review)
        joint = [c for c in result["components"] if c.get("id") == "joint-advisement"]
        assert len(joint) == 1

    def test_approve_button_when_ripples_exist(self, sample_review):
        result = build_a2ui_agent_review(sample_review)
        rows = [c for c in result["components"] if c.get("type") == "Row"]
        assert len(rows) >= 1
        labels = [b["props"]["label"] for b in rows[0]["children"]]
        assert any("Approve" in l for l in labels)

    def test_no_buttons_without_ripples(self):
        result = build_a2ui_agent_review({
            "id": "r1", "status": "pending",
            "individual_advisements": [],
            "extracted_ripple_ids": [],
        })
        rows = [c for c in result["components"] if c.get("type") == "Row"]
        assert len(rows) == 0

    def test_empty_review(self):
        result = build_a2ui_agent_review({})
        assert result["version"] == "0.8"


# ---------------------------------------------------------------------------
# build_a2ui_watcher_alerts
# ---------------------------------------------------------------------------

class TestBuildA2UIWatcherAlerts:
    def test_version_is_0_8(self, sample_alerts):
        result = build_a2ui_watcher_alerts(sample_alerts)
        assert result["version"] == "0.8"

    def test_has_header(self, sample_alerts):
        result = build_a2ui_watcher_alerts(sample_alerts)
        header = result["components"][0]
        assert "2 total" in header["props"]["text"]

    def test_card_per_alert(self, sample_alerts):
        result = build_a2ui_watcher_alerts(sample_alerts)
        cards = [c for c in result["components"] if c.get("type") == "Card"]
        assert len(cards) == 2

    def test_unhandled_alert_has_button(self, sample_alerts):
        result = build_a2ui_watcher_alerts(sample_alerts)
        # First alert is unhandled
        card = result["components"][1]
        rows = [c for c in card["children"] if c.get("type") == "Row"]
        assert len(rows) == 1

    def test_handled_alert_no_button(self, sample_alerts):
        result = build_a2ui_watcher_alerts(sample_alerts)
        # Second alert is handled
        card = result["components"][2]
        rows = [c for c in card["children"] if c.get("type") == "Row"]
        assert len(rows) == 0

    def test_empty_alerts(self):
        result = build_a2ui_watcher_alerts({"items": []})
        assert "0 total" in result["components"][0]["props"]["text"]


# ===========================================================================
# Loop Formatter
# ===========================================================================

@pytest.fixture
def sample_loop_status():
    return {
        "storm_id": 1,
        "storm_key": "STORM-20260208-001",
        "status": "active",
        "state": {
            "current_depth": 1,
            "total_iterations": 5,
            "droplets_completed": 3,
            "droplets_failed": 1,
            "review_findings_total": 2,
            "review_cycles": [
                {"depth": 1, "source_droplet": "DROP-001", "findings_count": 2}
            ],
            "terminated": False,
            "termination_reason": None,
        },
        "waves": [
            {"wave_key": "WAVE-001", "status": "in_progress", "total_droplets": 4, "completed_droplets": 3, "failed_droplets": 1},
        ],
        "droplets": [
            {"droplet_key": "DROP-001", "title": "Task 1", "status": "completed", "branch": "rem-loop-001"},
            {"droplet_key": "DROP-002", "title": "Task 2", "status": "failed", "branch": "rem-loop-002"},
            {"droplet_key": "DROP-003", "title": "Task 3", "status": "blocked", "branch": "rem-loop-003"},
        ],
    }


class TestFormatLoopStatus:
    def test_has_storm_key(self, sample_loop_status):
        from remembril_mcp.formatters.loop_fmt import format_loop_status
        text = format_loop_status(sample_loop_status)
        assert "STORM-20260208-001" in text

    def test_has_progress(self, sample_loop_status):
        from remembril_mcp.formatters.loop_fmt import format_loop_status
        text = format_loop_status(sample_loop_status)
        assert "Iterations: 5" in text
        assert "Completed: 3" in text
        assert "Failed: 1" in text

    def test_has_waves(self, sample_loop_status):
        from remembril_mcp.formatters.loop_fmt import format_loop_status
        text = format_loop_status(sample_loop_status)
        assert "WAVE-001" in text
        assert "3/4" in text

    def test_has_droplets(self, sample_loop_status):
        from remembril_mcp.formatters.loop_fmt import format_loop_status
        text = format_loop_status(sample_loop_status)
        assert "DROP-001" in text
        assert "DROP-002" in text
        assert "[GATE]" in text  # blocked droplet

    def test_has_review_cycles(self, sample_loop_status):
        from remembril_mcp.formatters.loop_fmt import format_loop_status
        text = format_loop_status(sample_loop_status)
        assert "Depth 1" in text
        assert "2 findings" in text

    def test_terminated_state(self, sample_loop_status):
        from remembril_mcp.formatters.loop_fmt import format_loop_status
        sample_loop_status["state"]["terminated"] = True
        sample_loop_status["state"]["termination_reason"] = "max_depth_reached"
        text = format_loop_status(sample_loop_status)
        assert "Terminated" in text
        assert "max_depth_reached" in text

    def test_empty_loop(self):
        from remembril_mcp.formatters.loop_fmt import format_loop_status
        text = format_loop_status({"storm_key": "S", "status": "planning", "state": {}})
        assert "S" in text
