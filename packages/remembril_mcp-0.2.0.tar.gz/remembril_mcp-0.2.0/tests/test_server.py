"""Tests for MCP server tool handlers and utility functions.

Tests _handle_tool routing, _make_result output building,
_calculate_complexity scoring, and tool registration.
"""

import pytest
from unittest.mock import AsyncMock, patch, MagicMock

from remembril_mcp.server import (
    _make_result,
    _calculate_complexity,
    _handle_tool,
    _load_widget,
    create_server,
)
from remembril_mcp.client import RembrilClient, RembrilError
from remembril_mcp.config import Config


# ---------------------------------------------------------------------------
# _calculate_complexity
# ---------------------------------------------------------------------------

class TestCalculateComplexity:
    def test_high_complexity_keywords(self):
        for keyword in ["architecture", "security", "migration", "refactor",
                        "breaking", "authentication", "encryption", "database",
                        "schema", "performance"]:
            severity, reason = _calculate_complexity(f"Issue about {keyword}")
            assert severity == "high", f"Expected high for '{keyword}', got {severity}"
            assert keyword in reason

    def test_medium_complexity_keywords(self):
        for keyword in ["feature", "api", "integration", "update", "enhance", "add"]:
            severity, reason = _calculate_complexity(keyword)
            assert severity == "medium", f"Expected medium for '{keyword}', got {severity}"

    def test_low_complexity_keywords(self):
        for keyword in ["fix", "typo", "style", "format", "docs", "comment", "minor"]:
            severity, reason = _calculate_complexity(keyword)
            assert severity == "low", f"Expected low for '{keyword}', got {severity}"

    def test_no_keywords_defaults_to_medium(self):
        severity, reason = _calculate_complexity("Something unrelated")
        assert severity == "medium"
        assert "No specific" in reason

    def test_description_also_checked(self):
        severity, _ = _calculate_complexity("Issue", "about database changes")
        assert severity == "high"

    def test_case_insensitive(self):
        severity, _ = _calculate_complexity("SECURITY concern")
        assert severity == "high"

    def test_high_takes_priority_over_medium(self):
        severity, _ = _calculate_complexity("Add new authentication feature")
        assert severity == "high"  # "authentication" beats "feature"


# ---------------------------------------------------------------------------
# _make_result
# ---------------------------------------------------------------------------

class TestMakeResult:
    def test_basic_text_output(self):
        result = _make_result({"key": "value"})
        assert len(result.content) == 1
        assert result.content[0].type == "text"
        assert "key" in result.content[0].text

    def test_custom_text(self):
        result = _make_result({"data": 1}, text="Custom message")
        assert result.content[0].text == "Custom message"

    def test_structured_content_is_dict(self):
        result = _make_result({"key": "value"})
        assert result.structuredContent["key"] == "value"

    def test_non_dict_data_wrapped(self):
        result = _make_result([1, 2, 3])
        assert result.structuredContent["data"] == [1, 2, 3]

    def test_widget_sets_meta(self):
        result = _make_result({}, widget="ripple-review")
        assert result.meta["ui"]["resourceUri"] == "ui://remembril/ripple-review"

    def test_no_widget_no_meta(self):
        result = _make_result({})
        assert result.meta is None

    def test_a2ui_added_to_structured(self):
        a2ui = {"version": "0.8", "components": []}
        result = _make_result({"data": 1}, a2ui=a2ui)
        assert result.structuredContent["a2ui"] == a2ui

    def test_no_a2ui_when_not_provided(self):
        result = _make_result({"data": 1})
        assert "a2ui" not in result.structuredContent


# ---------------------------------------------------------------------------
# _load_widget
# ---------------------------------------------------------------------------

class TestLoadWidget:
    def test_loads_existing_widget(self):
        html = _load_widget("ripple-review")
        assert "<!DOCTYPE html>" in html or "<html" in html.lower() or len(html) > 100

    def test_returns_empty_for_missing_widget(self):
        html = _load_widget("nonexistent-widget")
        assert html == ""


# ---------------------------------------------------------------------------
# _handle_tool (with mocked client)
# ---------------------------------------------------------------------------

def make_mock_client():
    """Create a fully mocked RembrilClient."""
    client = AsyncMock(spec=RembrilClient)
    client.config = Config(
        api_url="http://localhost:7070",
        token="test",
        default_project_id="proj-001",
    )
    return client


class TestHandleToolIssues:
    @pytest.mark.asyncio
    async def test_issue_create(self):
        client = make_mock_client()
        client.create_issue.return_value = {"id": 1, "title": "Bug"}
        result = await _handle_tool(client, "remembril_issue_create", {
            "title": "Bug", "severity": "high"
        })
        client.create_issue.assert_called_once_with(
            title="Bug", description=None, severity="high", project_id=None
        )
        assert not result.isError

    @pytest.mark.asyncio
    async def test_issue_create_smart_adds_complexity(self):
        client = make_mock_client()
        client.create_issue.return_value = {"id": 1, "title": "Security fix"}
        result = await _handle_tool(client, "remembril_issue_create_smart", {
            "title": "Security fix"
        })
        # Should auto-score as high (security keyword)
        client.create_issue.assert_called_once()
        call_kwargs = client.create_issue.call_args
        assert call_kwargs[1]["severity"] == "high" or call_kwargs[0][2] == "high"

    @pytest.mark.asyncio
    async def test_issue_list(self):
        client = make_mock_client()
        client.list_issues.return_value = [{"id": 1}]
        result = await _handle_tool(client, "remembril_issue_list", {"status": "open"})
        client.list_issues.assert_called_once()


class TestHandleToolRipples:
    @pytest.mark.asyncio
    async def test_ripples_generate(self):
        client = make_mock_client()
        client.generate_ripples.return_value = {"ripples": []}
        await _handle_tool(client, "remembril_ripples_generate", {"issue_id": 5})
        client.generate_ripples.assert_called_once_with(5)

    @pytest.mark.asyncio
    async def test_ripples_queue_returns_widget(self):
        client = make_mock_client()
        client.get_pending_ripples.return_value = [
            {"id": 1, "risk_level": "low", "change_type": "ADDED", "section": "x"}
        ]
        result = await _handle_tool(client, "remembril_ripples_queue", {})
        assert result.meta is not None
        assert "ripple-review" in result.meta["ui"]["resourceUri"]
        assert result.structuredContent["pending_count"] == 1
        assert "a2ui" in result.structuredContent

    @pytest.mark.asyncio
    async def test_ripple_approve_message(self):
        client = make_mock_client()
        client.approve_ripple.return_value = {"status": "approved"}
        result = await _handle_tool(client, "remembril_ripple_approve", {"ripple_id": 10})
        assert "#10" in result.content[0].text
        assert "approved" in result.content[0].text

    @pytest.mark.asyncio
    async def test_ripple_reject_message(self):
        client = make_mock_client()
        client.reject_ripple.return_value = {}
        result = await _handle_tool(client, "remembril_ripple_reject", {
            "ripple_id": 10, "reason": "Not valid"
        })
        assert "#10" in result.content[0].text
        assert "Not valid" in result.content[0].text

    @pytest.mark.asyncio
    async def test_ripple_diff_uses_formatter(self):
        client = make_mock_client()
        client.get_ripple.return_value = {
            "id": 1, "changes": [{"target": "DOC-1", "change_type": "MOD", "section": "x"}]
        }
        result = await _handle_tool(client, "remembril_ripple_diff", {"ripple_id": 1})
        assert "Ripple #1" in result.content[0].text

    @pytest.mark.asyncio
    async def test_blind_review_strips_reasoning(self):
        client = make_mock_client()
        client.get_ripple_queue.return_value = [
            {"id": 1, "status": "pending", "target_doc": "D1", "change_type": "ADD"},
            {"id": 2, "status": "approved", "target_doc": "D2", "change_type": "MOD"},
        ]
        result = await _handle_tool(client, "remembril_ripple_blind_review", {"issue_id": 5})
        data = result.structuredContent
        assert data["mode"] == "blind_validation"
        assert len(data["ripples"]) == 1  # only pending
        assert data["ripples"][0]["blind_validation"] is True


class TestHandleToolPipeline:
    @pytest.mark.asyncio
    async def test_pipeline_run(self):
        client = make_mock_client()
        client.run_pipeline.return_value = {"status": "completed", "issues_processed": 3}
        result = await _handle_tool(client, "remembril_pipeline_run", {"project_id": "p1"})
        assert "Pipeline Status" in result.content[0].text

    @pytest.mark.asyncio
    async def test_pipeline_run_no_widget(self):
        """Pipeline tools are operational — no widget URI attached."""
        client = make_mock_client()
        client.run_pipeline.return_value = {"status": "completed", "issues_processed": 3}
        result = await _handle_tool(client, "remembril_pipeline_run", {"project_id": "p1"})
        assert result.meta is None

    @pytest.mark.asyncio
    async def test_pipeline_run_has_a2ui(self):
        client = make_mock_client()
        client.run_pipeline.return_value = {"status": "completed", "issues_processed": 3}
        result = await _handle_tool(client, "remembril_pipeline_run", {"project_id": "p1"})
        assert "a2ui" in result.structuredContent
        assert result.structuredContent["a2ui"]["version"] == "0.8"

    @pytest.mark.asyncio
    async def test_pipeline_status(self):
        client = make_mock_client()
        client.pipeline_status.return_value = {"status": "running"}
        result = await _handle_tool(client, "remembril_pipeline_status", {"project_id": "p1"})
        assert "running" in result.content[0].text

    @pytest.mark.asyncio
    async def test_pipeline_status_no_widget(self):
        """Pipeline tools are operational — no widget URI attached."""
        client = make_mock_client()
        client.pipeline_status.return_value = {"status": "running"}
        result = await _handle_tool(client, "remembril_pipeline_status", {"project_id": "p1"})
        assert result.meta is None

    @pytest.mark.asyncio
    async def test_pipeline_status_has_a2ui(self):
        client = make_mock_client()
        client.pipeline_status.return_value = {"status": "running"}
        result = await _handle_tool(client, "remembril_pipeline_status", {"project_id": "p1"})
        assert "a2ui" in result.structuredContent


class TestHandleToolDocuments:
    @pytest.mark.asyncio
    async def test_docs_list(self):
        client = make_mock_client()
        client.list_documents.return_value = [{"id": "D1"}]
        result = await _handle_tool(client, "remembril_docs", {"project_id": "p1"})
        client.list_documents.assert_called_once_with("p1")

    @pytest.mark.asyncio
    async def test_doc_read(self):
        client = make_mock_client()
        client.get_document.return_value = {"id": "D1", "content": {}}
        result = await _handle_tool(client, "remembril_doc_read", {"doc_id": "D1"})
        client.get_document.assert_called_once_with("D1")

    @pytest.mark.asyncio
    async def test_traceability_returns_widget(self):
        client = make_mock_client()
        client.get_traceability.return_value = {
            "doc_types": ["requirements"], "matrix": [],
            "total_requirements": 0, "fully_traced": 0, "coverage_percent": 0,
        }
        result = await _handle_tool(client, "remembril_doc_traceability", {"project_id": "p1"})
        assert result.meta is not None
        assert "traceability" in result.meta["ui"]["resourceUri"]
        assert "a2ui" in result.structuredContent


class TestHandleToolDesign:
    @pytest.mark.asyncio
    async def test_design_create_project(self):
        client = make_mock_client()
        client.create_design_project.return_value = {"id": "dp1"}
        await _handle_tool(client, "remembril_design_create_project", {"name": "App"})
        client.create_design_project.assert_called_once()

    @pytest.mark.asyncio
    async def test_design_chat_returns_widget(self):
        client = make_mock_client()
        client.design_chat.return_value = {"summary": "Added login section"}
        result = await _handle_tool(client, "remembril_design_chat", {
            "doc_id": "D1", "message": "Add login"
        })
        assert "design-preview" in result.meta["ui"]["resourceUri"]
        assert "login" in result.content[0].text

    @pytest.mark.asyncio
    async def test_design_chat_has_a2ui(self):
        client = make_mock_client()
        client.design_chat.return_value = {"summary": "Added login section"}
        result = await _handle_tool(client, "remembril_design_chat", {
            "doc_id": "D1", "message": "Add login"
        })
        assert "a2ui" in result.structuredContent
        assert result.structuredContent["a2ui"]["version"] == "0.8"

    @pytest.mark.asyncio
    async def test_design_generate_returns_widget(self):
        client = make_mock_client()
        client.design_generate.return_value = {"id": "DOC-NEW", "summary": "Generated auth spec"}
        result = await _handle_tool(client, "remembril_design_generate", {
            "doc_type": "requirements", "title": "Auth", "description": "Auth spec"
        })
        assert "design-preview" in result.meta["ui"]["resourceUri"]

    @pytest.mark.asyncio
    async def test_design_generate_has_a2ui(self):
        client = make_mock_client()
        client.design_generate.return_value = {"id": "DOC-NEW", "summary": "Generated auth spec"}
        result = await _handle_tool(client, "remembril_design_generate", {
            "doc_type": "requirements", "title": "Auth", "description": "Auth spec"
        })
        assert "a2ui" in result.structuredContent
        assert result.structuredContent["a2ui"]["version"] == "0.8"


class TestHandleToolCodeAnalysis:
    @pytest.mark.asyncio
    async def test_scan(self):
        client = make_mock_client()
        client.scan_codebase.return_value = {"files": 100}
        await _handle_tool(client, "remembril_scan", {"path": "/repo"})
        client.scan_codebase.assert_called_once_with("/repo")

    @pytest.mark.asyncio
    async def test_impact(self):
        client = make_mock_client()
        client.analyze_impact.return_value = {"affected": []}
        await _handle_tool(client, "remembril_impact", {"file_path": "/a.py"})
        client.analyze_impact.assert_called_once()

    @pytest.mark.asyncio
    async def test_trace(self):
        client = make_mock_client()
        client.trace_requirement.return_value = {"implementations": []}
        await _handle_tool(client, "remembril_trace", {"requirement_id": "REQ-001"})
        client.trace_requirement.assert_called_once_with("REQ-001")


class TestHandleToolOrchestration:
    @pytest.mark.asyncio
    async def test_orchestrate_start(self):
        client = make_mock_client()
        client.create_orchestration_session.return_value = {"session_id": "s1"}
        await _handle_tool(client, "remembril_orchestrate_start", {
            "project_id": "p1", "mode": "parallel"
        })
        client.create_orchestration_session.assert_called_once()

    @pytest.mark.asyncio
    async def test_orchestrate_complete(self):
        client = make_mock_client()
        client.complete_task.return_value = {}
        await _handle_tool(client, "remembril_orchestrate_complete", {
            "session_id": "s1", "ripple_id": 10
        })
        client.complete_task.assert_called_once()


class TestHandleToolAgentReviews:
    @pytest.mark.asyncio
    async def test_review_run(self):
        client = make_mock_client()
        client.run_review.return_value = {"id": "rev-1", "status": "pending"}
        result = await _handle_tool(client, "remembril_review_run", {
            "project_id": "p1", "committee_size": 3
        })
        client.run_review.assert_called_once()
        assert "rev-1" in result.content[0].text

    @pytest.mark.asyncio
    async def test_review_status_has_widget(self):
        client = make_mock_client()
        client.get_review.return_value = {
            "id": "rev-1", "status": "completed",
            "individual_advisements": [
                {"agent_id": "sec", "agent_name": "Security", "agent_type": "adversary",
                 "position": "block", "confidence": 0.9, "summary": "Blocked",
                 "findings": ["XSS"], "concerns": [], "recommendations": [], "praise": [], "evidence": []},
            ],
            "joint_advisement": {"recommendation": "block", "recommendation_summary": "Blocked"},
            "extracted_ripple_ids": [1, 2],
            "alert_count": 1,
        }
        result = await _handle_tool(client, "remembril_review_status", {"review_id": "rev-1"})
        assert result.meta is not None
        assert "agent-review" in result.meta["ui"]["resourceUri"]
        assert "a2ui" in result.structuredContent
        assert "Agent Review" in result.content[0].text
        assert "block" in result.content[0].text

    @pytest.mark.asyncio
    async def test_review_list(self):
        client = make_mock_client()
        client.list_reviews.return_value = {"items": [{"id": "r1", "status": "completed"}], "total": 1}
        result = await _handle_tool(client, "remembril_review_list", {"project_id": "p1"})
        assert "Reviews" in result.content[0].text

    @pytest.mark.asyncio
    async def test_review_approve_ripples(self):
        client = make_mock_client()
        client.approve_review_ripples.return_value = {"approved": 3, "total": 5}
        result = await _handle_tool(client, "remembril_review_approve_ripples", {"review_id": "rev-1"})
        assert "3/5" in result.content[0].text

    @pytest.mark.asyncio
    async def test_debate_create(self):
        client = make_mock_client()
        client.create_debate.return_value = {"id": "deb-1", "status": "pending"}
        result = await _handle_tool(client, "remembril_debate_create", {
            "project_id": "p1", "topic": "Monolith vs microservices"
        })
        assert "deb-1" in result.content[0].text

    @pytest.mark.asyncio
    async def test_debate_status(self):
        client = make_mock_client()
        client.get_debate.return_value = {
            "id": "deb-1", "topic": "Architecture", "status": "concluded",
            "rounds": 3, "rounds_completed": 2,
            "messages": [{"agent": "eng", "role": "Engineer", "content": "Monolith.", "round": 1}],
            "consensus": {"reached": True, "summary": "Start monolith"},
        }
        result = await _handle_tool(client, "remembril_debate_status", {"debate_id": "deb-1"})
        assert "Debate" in result.content[0].text
        assert "agent-review" in result.meta["ui"]["resourceUri"]

    @pytest.mark.asyncio
    async def test_watcher_alerts(self):
        client = make_mock_client()
        client.list_watcher_alerts.return_value = {
            "items": [
                {"id": "a1", "alert_type": "convergence", "severity": "info",
                 "description": "All agreed", "handled": False, "involved_agents": ["sec", "eng"]},
            ]
        }
        result = await _handle_tool(client, "remembril_watcher_alerts", {"review_id": "rev-1"})
        assert "Watcher Alerts" in result.content[0].text
        assert "a2ui" in result.structuredContent

    @pytest.mark.asyncio
    async def test_watcher_alerts_has_widget(self):
        client = make_mock_client()
        client.list_watcher_alerts.return_value = {"items": []}
        result = await _handle_tool(client, "remembril_watcher_alerts", {})
        assert result.meta is not None
        assert "agent-review" in result.meta["ui"]["resourceUri"]

    @pytest.mark.asyncio
    async def test_alert_handle(self):
        client = make_mock_client()
        client.handle_alert.return_value = {"id": "a1", "handled": True}
        result = await _handle_tool(client, "remembril_alert_handle", {"alert_id": "a1"})
        assert "handled" in result.content[0].text

    @pytest.mark.asyncio
    async def test_personas_list(self):
        client = make_mock_client()
        client.list_personas.return_value = {
            "items": [
                {"id": "security", "name": "Security Hawk", "type": "adversary",
                 "role": "Security analyst", "goal": "Find vulns"},
            ]
        }
        result = await _handle_tool(client, "remembril_personas_list", {})
        assert "Agent Personas" in result.content[0].text

    @pytest.mark.asyncio
    async def test_personas_list_filter_by_type(self):
        client = make_mock_client()
        client.list_personas.return_value = {"items": []}
        await _handle_tool(client, "remembril_personas_list", {"type": "adversary"})
        client.list_personas.assert_called_once_with(agent_type="adversary")


class TestHandleToolLoop:
    @pytest.mark.asyncio
    async def test_loop_start(self):
        client = make_mock_client()
        client.loop_start.return_value = {
            "storm_id": 1, "storm_key": "STORM-20260208-001",
            "status": "started", "message": "Loop started"
        }
        result = await _handle_tool(client, "remembril_loop_start", {
            "project_id": "p1", "max_depth": 2
        })
        client.loop_start.assert_called_once()
        assert "STORM-20260208-001" in result.content[0].text

    @pytest.mark.asyncio
    async def test_loop_status(self):
        client = make_mock_client()
        client.loop_status.return_value = {
            "storm_id": 1, "storm_key": "STORM-20260208-001",
            "status": "active",
            "state": {
                "current_depth": 1, "total_iterations": 3,
                "droplets_completed": 2, "droplets_failed": 0,
                "review_findings_total": 1,
                "review_cycles": [], "terminated": False,
                "termination_reason": None
            },
            "waves": [], "droplets": [],
        }
        result = await _handle_tool(client, "remembril_loop_status", {"storm_id": 1})
        assert "STORM-20260208-001" in result.content[0].text

    @pytest.mark.asyncio
    async def test_loop_stop(self):
        client = make_mock_client()
        client.loop_stop.return_value = {
            "status": "stop_requested",
            "message": "Loop will stop after current task completes"
        }
        result = await _handle_tool(client, "remembril_loop_stop", {"storm_id": 1})
        client.loop_stop.assert_called_once()
        assert "stop" in result.content[0].text.lower()


class TestHandleToolWorkLoop:
    """Tests for pull-based agent work loop tools."""

    @pytest.mark.asyncio
    async def test_next_task(self):
        client = make_mock_client()
        client.loop_next_task.return_value = {
            "droplet_id": 1, "droplet_key": "DROP-20260223-001",
            "title": "Implement auth", "objective": "Create JWT middleware",
            "context": {"prompt": "Implement JWT auth"},
            "work_breakdown": {"title": "auth setup", "method": "rule_based"},
            "branch": "rem-loop-20260223-001",
            "storm_id": 42, "storm_key": "STORM-20260223-001",
            "project_id": "p1", "issue_id": 1,
        }
        result = await _handle_tool(client, "remembril_loop_next_task", {
            "storm_id": 42,
        })
        client.loop_next_task.assert_called_once_with(storm_id=42, project_id=None)
        assert "DROP-20260223-001" in result.content[0].text
        assert "Implement auth" in result.content[0].text

    @pytest.mark.asyncio
    async def test_next_task_by_project(self):
        client = make_mock_client()
        client.loop_next_task.return_value = {
            "droplet_id": 2, "droplet_key": "DROP-20260223-002",
            "title": "Fix bug",
        }
        result = await _handle_tool(client, "remembril_loop_next_task", {
            "project_id": "p1",
        })
        client.loop_next_task.assert_called_once_with(storm_id=None, project_id="p1")

    @pytest.mark.asyncio
    async def test_claim_task(self):
        client = make_mock_client()
        client.loop_claim_task.return_value = {
            "status": "claimed", "droplet_id": 1,
            "droplet_key": "DROP-20260223-001", "title": "Auth",
            "agent_id": "claude-1",
        }
        result = await _handle_tool(client, "remembril_loop_claim_task", {
            "droplet_id": 1, "agent_id": "claude-1",
        })
        client.loop_claim_task.assert_called_once_with(droplet_id=1, agent_id="claude-1")
        assert "claimed" in result.content[0].text.lower()

    @pytest.mark.asyncio
    async def test_checkpoint(self):
        client = make_mock_client()
        client.loop_checkpoint_task.return_value = {
            "status": "checkpointed", "droplet_id": 1,
            "droplet_key": "DROP-20260223-001",
            "progress_percent": 50, "checkpoint_count": 3,
        }
        result = await _handle_tool(client, "remembril_loop_checkpoint", {
            "droplet_id": 1, "progress_percent": 50,
            "completed_steps": ["Created module"],
        })
        client.loop_checkpoint_task.assert_called_once()
        assert "50%" in result.content[0].text
        assert "#3" in result.content[0].text

    @pytest.mark.asyncio
    async def test_complete_success(self):
        client = make_mock_client()
        client.loop_complete_task.return_value = {
            "status": "completed", "droplet_id": 1,
            "droplet_key": "DROP-20260223-001", "success": True,
        }
        result = await _handle_tool(client, "remembril_loop_complete_task", {
            "droplet_id": 1, "success": True,
            "summary": "Auth module done",
            "files_changed": ["auth.py"],
        })
        client.loop_complete_task.assert_called_once()
        assert "completed" in result.content[0].text.lower()

    @pytest.mark.asyncio
    async def test_complete_failure(self):
        client = make_mock_client()
        client.loop_complete_task.return_value = {
            "status": "failed", "droplet_id": 1,
            "droplet_key": "DROP-20260223-001", "success": False,
        }
        result = await _handle_tool(client, "remembril_loop_complete_task", {
            "droplet_id": 1, "success": False,
            "error": "Compilation failed",
        })
        assert "failed" in result.content[0].text.lower()


class TestHandleToolUnknown:
    @pytest.mark.asyncio
    async def test_unknown_tool_raises(self):
        client = make_mock_client()
        with pytest.raises(RembrilError, match="Unknown tool"):
            await _handle_tool(client, "nonexistent_tool", {})


# ---------------------------------------------------------------------------
# create_server
# ---------------------------------------------------------------------------

class TestCreateServer:
    def test_creates_server_instance(self):
        config = Config(api_url="http://localhost:7070", token="test")
        server = create_server(config)
        assert server is not None
        assert server.name == "remembril"
