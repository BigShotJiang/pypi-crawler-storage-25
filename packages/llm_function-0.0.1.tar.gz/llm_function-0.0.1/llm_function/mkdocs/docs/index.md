# Intro

[![PyPiVersion](https://img.shields.io/pypi/v/llm-function)](https://pypi.org/project/llm-function/) 

`llm_function` helps you build reusable LLM functions with normal Python signatures.

You define a function with Pydantic input and output models, describe what it should do
in the docstring, and provide a set of available tools. At runtime, `llm_function`
uses [`workflow_auto_assembler`](https://pypi.org/project/workflow-auto-assembler/) to
assemble and execute a workflow that satisfies that typed function contract.

The result is an LLM-backed function that can be reused like any other Python function,
while still being grounded in explicit tools, schemas, and config.

Tool definition and discovery live in
[`llm_function_tools`](https://pypi.org/project/llm-function-tools/).


## Installation

```bash
pip install llm-function
```

