from setuptools import setup

import codecs
import os

here = os.path.abspath(os.path.dirname(__file__))
path_to_readme = os.path.join(here, "README.md")

long_description = """# Llm function

`llm_function` helps you build reusable LLM functions with normal Python signatures.

You define a function with Pydantic input and output models, describe what it should do
in the docstring, and provide a set of available tools. At runtime, `llm_function`
uses [`workflow_auto_assembler`](https://pypi.org/project/workflow-auto-assembler/) to
assemble and execute a workflow that satisfies that typed function contract.

The result is an LLM-backed function that can be reused like any other Python function,
while still being grounded in explicit tools, schemas, and config.

Tool definition and discovery live in
[`llm_function_tools`](https://pypi.org/project/llm-function-tools/).

"""

if os.path.exists(path_to_readme):
  with codecs.open(path_to_readme, encoding="utf-8") as fh:
      long_description += fh.read()

setup(
    name="llm_function",
    packages=["llm_function"],
    install_requires=['pydantic', 'workflow_auto_assembler', 'attrsx', 'attrs'],
    classifiers=['Development Status :: 3 - Alpha'],
    long_description=long_description,
    long_description_content_type='text/markdown',
    author="Kyrylo Mordan",
    author_email="parachute.repo@gmail.com",
    description="Llm function is a decorator that uses llm to assemble reusable workflows from available tools to match input and output models.",
    url="https://kiril-mordan.github.io/adaptive-reusables/llm-function/",
    keywords=['aa-paa-tool'],
    version="0.0.1",
    license = "apache-2.0",
    include_package_data = True,
    package_data = {'llm_function': ['mkdocs/**/*', 'artifacts/.paa.tracking/git/**/*', 'artifacts/.paa.tracking/git_repo/**/*', '.paa.tracking/version_logs.csv', '.paa.tracking/release_notes.md', '.paa.tracking/lsts_package_versions.yml', '.paa.tracking/package_mapping.json', '.paa.tracking/package_licenses.json', '.paa.tracking/.paa.config', '.paa.tracking/git/**/*', '.paa.tracking/git_repo/**/*', '.paa.tracking/python_modules/llm_function.py', '.paa.tracking/python_modules/components/llm_func_deps/llm_function_config.py', '.paa.tracking/python_modules/components/llm_func_deps/tool_registry.py', '.paa.tracking/.paa.version']} ,
    license_files = ["LICENSE", "NOTICE"],
    )
