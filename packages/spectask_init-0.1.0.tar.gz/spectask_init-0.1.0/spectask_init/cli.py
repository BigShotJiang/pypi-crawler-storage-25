from __future__ import annotations

import argparse
import sys
import zipfile
from dataclasses import dataclass

from spectask_init.bootstrap import run_extend, run_template_bootstrap

DEFAULT_TEMPLATE_URL = "https://github.com/noant/spectask.git"


@dataclass(frozen=True)
class CliOptions:
    template_url: str
    ide: str
    template_branch: str
    extend: str | None
    extend_branch: str
    skip_example: bool


def build_parser() -> argparse.ArgumentParser:
    epilog = """
ZIP vs Git:
  If the URL path ends with .zip (case-insensitive), the tool downloads and extracts
  the archive. Otherwise it runs git clone (requires git on PATH), using
  --template-branch for --template-url and --extend-branch for --extend.
  The same rule applies to --extend when that option is used.

Default --template-url is the official Spectask GitHub repository (.git); use a .zip URL
  to avoid git for the template step only.
""".strip()
    p = argparse.ArgumentParser(
        description="Bootstrap Spectask template files into the current directory.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=epilog,
    )
    p.add_argument(
        "--template-url",
        default=DEFAULT_TEMPLATE_URL,
        metavar="URL",
        help=f"Template source (ZIP or Git). Default: {DEFAULT_TEMPLATE_URL}",
    )
    p.add_argument("--ide", required=True, help="IDE key from skills-map.json, or 'all'.")
    p.add_argument("--template-branch", default="main", help="Git branch for template URL when not ZIP (default: main).")
    p.add_argument("--extend", default=None, help="Optional overlay source (ZIP or Git) for spec/extend/.")
    p.add_argument("--extend-branch", default="main", help="Git branch for --extend when not ZIP (default: main).")
    p.add_argument("--skip-example", action="store_true", help="Do not copy example-list.json paths.")
    return p


def parse_args(argv: list[str] | None = None) -> CliOptions:
    p = build_parser()
    ns = p.parse_args(argv)
    return CliOptions(
        template_url=ns.template_url,
        ide=ns.ide,
        template_branch=ns.template_branch,
        extend=ns.extend,
        extend_branch=ns.extend_branch,
        skip_example=ns.skip_example,
    )


def main() -> None:
    opts = parse_args()
    try:
        run_template_bootstrap(
            template_url=opts.template_url,
            ide=opts.ide,
            skip_example=opts.skip_example,
            template_branch=opts.template_branch,
        )
    except (OSError, RuntimeError, zipfile.BadZipFile) as e:
        print(f"spectask-init: {e}", file=sys.stderr)
        sys.exit(1)

    if opts.extend:
        try:
            run_extend(extend_url=opts.extend, extend_branch=opts.extend_branch)
        except (OSError, RuntimeError, zipfile.BadZipFile) as e:
            print(f"spectask-init: {e}", file=sys.stderr)
            sys.exit(1)
