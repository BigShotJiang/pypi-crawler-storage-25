# 私信 cookbook

虚拟信封私信的典型玩法。每个 recipe 都是"把 ¥1 信封用在刀刃上"的不同打法。

## 1. 给查到的人发第一封信

```bash
# 先查到目标
xq query 'gender=f AND city=hangzhou AND age>=25 AND height>=165'
# 出结果，选其中一个 user_id

xq dm send 01JG... "我是杭州的程序员，也喜欢登山..."
# → ✓ 已投递（免费额度）。msg=01JH...
#   通知：pushed
```

**今日用剩多少信封**：

```bash
xq envelope state
# 今日免费剩余: 2 / 3
```

## 2. 超出每日 3 封免费后

```bash
xq dm send 01JK... "..."
# → 发信失败: 400  insufficient_envelopes

xq envelope buy --count 10 --mock
# → 购买成功。order=01JM...  10 封  ¥10.00

xq dm send 01JK... "..."   # 现在可以继续发
```

## 3. 对方是否查了 / 回了

```bash
xq dm show 01JH...
# Delivery:  delivered
# Notify:    pushed @ 2026-04-23 10:16
# Read:      2026-04-23 14:20 (对方看了)
# Replied:   2026-04-23 15:00 (msg 01JP...)
```

**一眼看所有发件**：

```bash
xq dm sent --limit 20
```

## 4. 对方拉黑了你

```bash
xq dm send 01JG... "..."
# → 发信失败: blocked_by_recipient

# 钱退了（信封没扣）
xq envelope state   # 今日免费剩余 = 3
```

## 5. 主动查收件箱（没开通知的人必做）

```bash
xq inbox list
# ● 2026-04-23 10:15  ← 01JG...  01JH...
#     你好，我是杭州的...
# ● 2026-04-22 09:00  ← 01JK...  01JF...
#     想约爬山...
```

`●` = 未读。

```bash
xq inbox show 01JH...   # 看全文 + 标已读
xq inbox reply 01JH... "谢谢，我也喜欢..."   # 回（消耗信封）
```

## 6. 开"新信通知推送"（需要 agent gateway）

```bash
xq profile set agent_gateway_url https://my-openclaw-gateway.example.com
xq profile set agent_hooks_token <your-token>
xq profile set notify_on_new_mail on

# 验证：让人试发一条，你的 gateway 应收到推送
```

**不想被打扰**：关闭即可。

```bash
xq profile set notify_on_new_mail off
```

**通知去重规则**：B 已经有未读的话 12 小时内不再推，避免刷屏。

## 7. 骚扰处理

```bash
xq inbox report 01JH... --reason '骚扰信息'
# → ✓ 已举报 (report_id=01JN...)

xq block 01JG...
# → ✓ 已拉黑 01JG...
# 对方后续发信会被服务端拦截（信封退）

xq blocklist           # 查已拉黑
xq unblock 01JG...     # 解除
```

举报**永久留档**，可取证。

## 8. 回信无限链，但每封都要信封

```bash
# 你回复 B → 消耗 1 信封（回信也是信）
# B 再回你 → 消耗 B 的 1 信封
# ...
```

物理直觉：**每发一次信 = 一个信封**，无论是开场还是回复。

## 9. 订单流水盘点

```bash
xq envelope state
# 今日免费剩余: 1 / 3
# 付费信封余量: 7
# 历史累计购买: 20
# 信封单价:    ¥1.00
```

0.1 期只支持 mock 购买（`--mock` 必带）。真付走支付宝待 v0.2 接入。
