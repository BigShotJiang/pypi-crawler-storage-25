# FAQ

## 为什么不做推荐算法？

推荐算法本质是"平台决定你能看到谁"。xiangqin 把决定权还给用户（你自己写 DSL 查），付费也不影响被谁查到，只影响你能主动给谁写信（虚拟信封）。

## 付了钱具体买到什么？

每天免费 3 封信封，超额 ¥1/封。**1 个信封 = 可以给任意一人写一封私信**。对方能在收件箱看到（如果开了通知还会收到推送）。

- 对方拉黑你 / 账号不存在 → 信封退回，不扣
- 对方已读 / 回信 / 举报 / 删除 → 你都能在 `xq dm sent` 里看到状态

## query 返回顺序真的公开吗？

`ORDER BY p.updated_at DESC` 写死在 [`src/xiangqin/query.py`](https://github.com/yarnovo/xiangqin/blob/main/src/xiangqin/query.py)。新资料 / 新活跃的人排前，没有付费插队。GitHub 上可查，你可以自己 clone 跑 sqlite 验证。

## 查不到我想要的人

先想清楚三点：

1. **对方填了吗** —— 对方没 `xq register` + 填 profile 查不到
2. **DSL 对吗** —— `gender=F` 错（值区分大小写），`gender=f` 对
3. **limit 太小** —— 默认 50，试 `--limit 100`

## 为什么收钱但不给聊天入口？

xiangqin 明确**不做聊天**。这是宪法级约束：

- 聊天做起来工作量翻 5 倍（消息存储 / 反骚扰 / 图片视频 / 举报）
- 查到人后怎么联系归你——微信 / 电话 / 线下，你自己走
- 0.1 闭环验证的是"人愿意为可见性付费"，不是"人愿意在这里聊天"

## 我想删号

```bash
xq delete --confirm
```

软删 → 7 天后物理清理。7 天内可撤销（重 register 同手机号）。

## 服务端挂了我的余额没了？

不会。余额在 sqlite，每日 02:00 自动备份到 OSS。最差情况回到前一日 02:00 的状态（≤24h 数据丢失窗口）。

支付已完成但余额没充值 → 看 [运维 § 紧急回滚](ops.md#7-紧急回滚) 或联系 acong-tech。

## 技术栈选型

- **Python 3.12+**：已有 vault / shipyard 生态
- **FastAPI + sqlite**：零运维 / 单文件数据库 / 足够应付 0.1 期
- **click**：CLI 首选，和生态其它项目一致
- **cryptography**：RSA 验签（支付宝回调）

## 开发者问题

### 怎么跑测试

```bash
uv sync --all-groups
uv run pytest -q
# 覆盖率必须 ≥70%（在 pyproject 钉了 --cov-fail-under=70）
```

### 怎么跑服务端

```bash
uv run xiangqin-server   # 默认 8000
# 或
uv run uvicorn xiangqin.app:app --reload
```

### `import xiangqin` 在哪

`src/xiangqin/` —— src-layout，已在 `pyproject.toml` 里 `packages = ["src/xiangqin"]`。

### vault 连不上怎么办

客户端不用 vault。服务端需要：

- 本地开发：设 `XIANGQIN_SECRETS_PATH=/path/to/fake-secrets.json`（见 `test/conftest.py` 里 fake_secrets fixture）
- 生产：`cd /opt/xiangqin && vault install`

## 更多

- [GitHub Issues](https://github.com/yarnovo/xiangqin/issues)
- [ADR 决策记录](https://github.com/yarnovo/xiangqin/tree/main/decisions)
