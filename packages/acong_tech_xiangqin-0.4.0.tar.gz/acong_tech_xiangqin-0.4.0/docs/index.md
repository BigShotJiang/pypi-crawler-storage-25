# xiangqin

**相亲平台** —— 虚拟信封私信商业模式（不做推荐算法、不做聊天、不做匹配评分）。

[![CI](assets/badges/ci.svg)](https://github.com/yarnovo/xiangqin/actions)
![tests](assets/badges/tests.svg)
![coverage](assets/badges/coverage.svg)
![docs](assets/badges/docs.svg)

## TL;DR

```bash
# 装
pip install acong-tech-xiangqin

# 注册 + 登录（mock 期验证码固定 123456）
xq register 13800001111
xq verify 123456 --request-id <上条返回的 ULID>

# 填资料 + 查
xq profile set gender m
xq profile set age 28
xq profile set city hangzhou
xq query 'gender=f AND city=hangzhou AND age>=25 AND age<=30'

# 给心仪的人发私信（消耗 1 信封；每天免费 3 封，超额 ¥1/封）
xq dm send <user_id> "你好，我是..."

# 查收件 + 回信
xq inbox list
xq inbox reply <message_id> "..."
```

## 三句话

1. **不做推荐**：查询权 100% 在用户 agent 端。服务端只提供受限 WHERE DSL，固定按 `updated_at DESC` 排。
2. **付费 = 主动接触权**：想跟谁说话就给谁写信。每天免费 3 封，超额 ¥1/封。对方能收到通知（如果开了）。
3. **自治单体**：除 [vault](https://agentaily-vault.pages.dev/) 外不依赖生态里其它 CLI。

## 为什么做

- 传统交友 app 推荐算法变相骗钱（多花钱 ≠ 更多真实机会）
- xiangqin 把游戏规则摊开：谁能查、谁能联系、如何联系——全部公开

## 更多

- [设计](design.md) —— 表结构 / 受限 DSL / 虚拟信封模型
- [装机上手](usage/getting-started.md) —— pip / skills / 第一次跑通
- [接入 vault](usage/vault-integration.md) —— 声明式凭证
- [私信 cookbook](usage/cookbook.md)
- [CLI 参考](cli-reference.md)
- [运维](ops.md)
- [安全](security.md)
- [FAQ](faq.md)
