# Changelog — xiangqin

所有重要变化记在这。格式基于 [Keep a Changelog](https://keepachangelog.com/)，版本号遵循 [SemVer](https://semver.org/)。

## [Unreleased]

## [0.4.0] - 2026-04-23

### Known Limitations
- **真实支付未接入**：`xq envelope buy --mock` 是唯一购买路径，**不真扣钱**；mock=1 直接增加余量
- **付费闭环留给 v0.5.0**：支付宝 / 微信支付接入会作为独立 deliverable
- 每日 3 封免费信封（UTC 0 点重置）对大多数用户足够用

### Added
- 2026-04-23 **xq CLI 版本检查 + 新版本提示**（issue #002，`src/xiangqin/version_check.py`）
  - 每次 `xq <cmd>` 检查 PyPI，新版本在 **stderr** 打印 `[xq] 新版本 X.Y.Z 可用（当前 A.B.C）...`
  - 缓存 `~/.xiangqin/version-cache.json` 24h TTL，后台子进程异步刷，不阻塞命令
  - `XIANGQIN_NO_UPDATE_CHECK=1` 关闭；CI 环境自动关
  - SKILL.md 新增 TRIGGER：agent 识别字样后主动询问用户升级

### Changed (BREAKING)
- 2026-04-23 **epsilon 生产 PHONE_SALT 轮换**（issue #003）
  - 原生产用默认值 `dev-salt-not-for-prod`（安全漏洞，salt 形同公开）
  - 替换为独立随机 salt（`openssl rand -hex 32`，写 systemd drop-in `override.conf`）
  - 副作用：老用户（老板自己测试的 4 个账号）phone_hash 全失配，需重新注册
  - alpha staging 在 provision 时已自动生成独立 salt（per-host）

### Added
- 2026-04-22 项目骨架（new-team skill 产出）
- 2026-04-22 立项 ADR：付费置顶商业模式 + 自治单体实验
- 2026-04-22 objectives O1 (0.1 闭环) / O2 (自治假设验证) 定义
- 2026-04-22 plan M1..M4 四个里程碑拆分
- 2026-04-22 vault 分配 epsilon (112.124.27.213) 给 xiangqin，gamma 从 matchmaker 释放
- 2026-04-22 **M1 通关**：epsilon 上 FastAPI + uvicorn + nginx + systemd，全链路 `xq health` 绿
- 2026-04-22 **M2 通关**：注册 / verify / profile / query / 买曝光完整闭环
  - 6 张 sqlite 表（users / profiles / exposure_orders / exposure_usage / sessions / auth_requests）+ WAL + 索引
  - 受限 WHERE DSL（字段 + 操作符 + 值三重白名单，禁 OR/JOIN/子查询）
  - query `ORDER BY exposure_remaining>0 DESC`，被命中原子扣 1
  - mock 买曝光（paid=1 + 事务充值）
  - `xq` CLI 完整：register / verify / logout / me / profile / query / expose
  - 66 单测全绿，含手机号永不落明文 red-line
  - 三用户 end-to-end demo 实证（A 查到 B🔥置顶 + C 普通；B 余额 100→99）
- 2026-04-22 **M3 通关**：sqlite → OSS 每日备份 + 恢复演练
  - OSS 桶 `agentaily-backup-xiangqin-prod` 创建（vault resource 入库）
  - aliyun cli `xiangqin` profile 装在 epsilon（AK/SK 从 vault 取）
  - 首次备份 `daily/xiangqin-20260422.db.gz` 成功
  - `/etc/cron.d/xiangqin-backup` 02:00 daily（明日 02:00 自动跑）
  - `scripts/restore.sh` 恢复演练通过（integrity_check=ok，3 users + 1 order 对得上）

### Security
- 2026-04-22 **SG 端口收窄**：epsilon 阿里云安全组关闭老 openclaw 遗留端口（7000 / 9876 / 22000-22999 / 内网 5432），只保留 22 / 80 / 443
- 2026-04-22 **服务降权**：systemd unit `User=root` → `User=xiangqin`（system user，nologin shell），加 ProtectSystem/ProtectHome/NoNewPrivileges/PrivateTmp 沙箱
- 2026-04-22 uv 管理的 Python 装到 `/opt/uv-python`（原 `/root/.local/share/uv/python` 非 xiangqin 用户可读路径），provision.sh + deploy.sh 已适配

### Changed
- 2026-04-22 **M4 方向调整**：从"1 对 1 真人访谈"改为"skill 发布 + 视频宣传 + agent 自助提示付费"（详见 [decisions/2026-04-22-2230-m4-switch-to-skill-distribution.md](./decisions/2026-04-22-2230-m4-switch-to-skill-distribution.md)）
- 2026-04-22 **pypi 包命名统一**：pyproject `name` 从 `xiangqin` 改为 `acong-tech-xiangqin`（对齐 shipyard 命名空间约定；CLI 二进制 `xq` 不变）

### Publish
- 2026-04-22 **M4 发布骨架就绪**：
  - `scripts/publish-pypi.sh` dry-run / --live / --canary，从 vault 取 PyPI token（自治单体，不依赖 shipyard）
  - `scripts/publish-skill.sh` 包装 `skill-publish-cli publish`
  - pypi build dry-run 通过（22KB wheel + 80KB sdist）
  - README.md 对外用户版（装 / 上手 / 心智模型）
  - 视频台词 scenarios/promo-video-script.md（2:30-3:00 8 分镜）
- 2026-04-22 **canary 实发通过**：pypi `acong-tech-xiangqin==0.1.0.dev202604220423` + ClawHub `xiangqin-canary`
  → `pip install --pre` + `xq health` 打生产返回 ok；`xq register` 走通
- 2026-04-23 **M4 触达架构：虚拟信封私信**（ADR `brain/decisions/2026-04-23-m4-mail-model-touchreach.md`）
  - 信箱 + 通知分离：信箱注册即开，通知（agent gateway push）可选；信件 30 天 TTL
  - 每天 3 封免费信封（UTC 0 点重置），超额 ¥1/封；投递失败（对方拉黑 / 注销）不扣
  - 信件 5 维状态：投递 / 通知 / 阅读 / 回应 / 处置
  - 通知去重：B 有未读 + <12h 不推；≥12h 兜底再提醒
  - 匿名代理：双方互不知对方 `agent_gateway_url` + `hooks_token`
  - 举报永久留档；拉黑单向拦截后续发信
  - profile 加字段：`height` / `education` / `agent_gateway_url` / `agent_hooks_token` / `notify_on_new_mail`
  - DSL 白名单扩展支持 `height` / `education`
  - CLI 新增：`xq dm` / `xq inbox` / `xq envelope` / `xq block` 命令族
  - 新表 `messages` / `envelope_usage` / `envelope_balance` / `envelope_orders` / `reports` / `blocks` / `notify_state`
- 2026-04-23 **brain/ 对内资产统一**：`decisions/ objectives/ plan/ scenarios/ sop/ wiki/` 根目录 git mv 到 `brain/`
- 2026-04-23 **docs/internal/ 拆分**：数据库 schema / 架构详情只本地 `mkdocs serve` 可见，CI 打包时剔除
- 2026-04-23 **CLAUDE.md 项目地图**：Claude 新会话 cold-start 入口；vault 项目同步建

### Removed
- 2026-04-23 **曝光系统整体下线**（ADR `brain/decisions/2026-04-23-drop-exposure-system.md`）
  - 删 `src/xiangqin/exposure.py`（211 行）
  - 删 `src/xiangqin/payment/` 整个目录（base / mock / alipay / wechat）
  - `app.py` 删 `/exposure/*` endpoints + alipay webhook
  - `cli.py` 删 `xq expose buy/balance/history` 命令
  - `query.py` 排序简化为 `ORDER BY p.updated_at DESC`（去付费置顶）
  - DB 加 `_drop_exposure_tables` 幂等迁移（生产 epsilon 部署时 DROP `exposure_orders` / `exposure_usage`）
  - 砍依赖 `cryptography`（原 alipay 验签）+ `qrcode`（原 ASCII 二维码）
  - 废掉的 M4 信封真付走支付宝待 v0.2 重新接入支付层；vault `alipay-kongxuanpin` 凭证资产保留

## [0.3.0] — 2026-04-23 零等待接入真 SMS / 真支付宝

### Added
- **短信真跑通**：`XIANGQIN_SMS_PROVIDER=aliyun`
  - 复用 vault `aliyun.power-app`（sign="杭州阿空智能科技" / template=SMS_317151039）
  - 无需新申请，零等待上线
- **支付宝真扣款**：`XIANGQIN_PAYMENT_PROVIDER=alipay`
  - 复用 vault `alipay.enterprise.kongxuanpin`（企业应用"阿空选品助手"）
  - `alipay.trade.precreate` 真调，prod 返回可扫二维码（实测）
  - webhook 路由 `/exposure/webhook/alipay` 验签 + 幂等充值
  - RSA2 签名踩坑 2 处：sign_type 参与签名 / charset 放 URL query；都在代码注释留底
- **CLI 渲染 ASCII 二维码**：`xq expose buy` 直接在 terminal 画二维码，用户手机支付宝 app 扫
- **sqlite schema 扩展**：exposure_orders 加 `provider / biz_order_id / status` 三列（老行迁移默认 `status=paid`）
- **新依赖**：`cryptography>=43`（RSA2 签名）+ `qrcode>=8`（ASCII 渲染）

### Changed
- 版本 0.2.0 → 0.3.0
- epsilon systemd unit 加 3 个 Environment：`XIANGQIN_SMS_PROVIDER` / `XIANGQIN_PAYMENT_PROVIDER` / `XIANGQIN_BASE_URL`
- SOP `sms-onboarding.md` + `payment-onboarding.md` 加"零等待复用"段（v2）

### Fixed
- sqlite schema migration 顺序 bug：`CREATE INDEX ... WHERE status='pending'` 老库没 status 列会炸，改为 `_migrate_orders_columns` 里先加列后建索引
- epsilon 上 `uv sync` 连 pypi.org 慢 → 用 `UV_INDEX_URL=阿里云 pypi mirror`，几秒完成

## [0.2.0] — 2026-04-22 夜（已被 0.3.0 覆盖）

### Added
- **SMS provider 抽象层** (`src/xiangqin/sms/`)
  - `mock`（默认，code 恒 `123456`）
  - `aliyun`（真调阿里云短信服务，RPC 签名自实现避开巨型 SDK）
  - 切换走 `XIANGQIN_SMS_PROVIDER` 环境变量
- **Payment provider 抽象层** (`src/xiangqin/payment/`)
  - `mock`（默认，立即 paid）
  - `wechat` / `alipay` 骨架（0.2 正式期对接，`__init__` 直接 raise NotImplementedError 避免误用）
  - 切换走 `XIANGQIN_PAYMENT_PROVIDER` 环境变量
- **OrderOut 扩展**：返回 `provider` / `status` / `qr_code_content`（便于支付跳转）
- **xq expose buy** CLI 适配：真支付路径输出二维码内容
- **SOP 文件齐套**：
  - `sop/services/deploy.md` - 发布新代码流程
  - `sop/services/publish.md` - PyPI + ClawHub 发版流程
  - `sop/services/restore.md` - OSS 备份恢复流程
  - `sop/operations/sms-onboarding.md` - 阿里云短信签名 / 模板申请指南
  - `sop/operations/payment-onboarding.md` - 微信 / 支付宝商户号申请指南
  - `docs/operator-manual.md` - 日常运维手册（一站式排查）

### Changed
- `pyproject.toml` version 0.1.0 → 0.2.0
- `src/xiangqin/__init__.py` __version__ 0.1.0 → 0.2.0
- epsilon 生产 version 已升级（`curl /health` 返回 0.2.0）

### Fixed / 保留兼容
- 0.2.0 API 完全向下兼容 0.1.0 客户端（新增字段全为 Optional；mock provider 默认行为不变）

### Canary
- pypi: `acong-tech-xiangqin==0.2.0.dev202604220439`
- ClawHub: `xiangqin-canary` commit `90a98f0`
