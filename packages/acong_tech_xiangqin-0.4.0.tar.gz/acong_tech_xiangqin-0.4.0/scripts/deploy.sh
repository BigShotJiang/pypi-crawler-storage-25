#!/usr/bin/env bash
# 增量部署。本地跑：bash scripts/deploy.sh [epsilon|alpha]
# 默认 epsilon（向后兼容无参调用）。

set -euo pipefail

HOST_ARG="${1:-epsilon}"

case "$HOST_ARG" in
    epsilon) TARGET_IP="112.124.27.213" ;;
    alpha)   TARGET_IP="120.27.148.143" ;;
    *) echo "未知 host: $HOST_ARG（支持 epsilon | alpha）" >&2; exit 1 ;;
esac

APP_DIR="/opt/xiangqin"

echo "[deploy:$HOST_ARG] [1/4] rsync 源码到 $TARGET_IP"
rsync -az --delete \
    --exclude '.venv' --exclude '__pycache__' --exclude '.pytest_cache' \
    --exclude 'data' --exclude '*.db*' --exclude '.git' \
    ./ "root@${TARGET_IP}:${APP_DIR}/"

echo "[deploy:$HOST_ARG] [2/4] 远端 uv sync + chown"
ssh "root@${TARGET_IP}" "cd ${APP_DIR} && \
    UV_PYTHON_INSTALL_DIR=/opt/uv-python \
    UV_PYTHON_PREFERENCE=only-managed UV_PYTHON=3.12 \
    /root/.local/bin/uv sync && \
    chown -R xiangqin:xiangqin ${APP_DIR}"

echo "[deploy:$HOST_ARG] [3/4] systemd unit"
ssh "root@${TARGET_IP}" "cp ${APP_DIR}/systemd/xiangqin.service /etc/systemd/system/ && systemctl daemon-reload && systemctl enable xiangqin"

echo "[deploy:$HOST_ARG] [4/4] 重启 + smoke test"
ssh "root@${TARGET_IP}" "systemctl restart xiangqin && sleep 2 && systemctl status --no-pager xiangqin"

echo "smoke test（内网 nginx，最多 15s 等 uvicorn ready）:"
ssh "root@${TARGET_IP}" 'for i in $(seq 1 15); do curl -sf http://127.0.0.1/health >/dev/null && break; sleep 1; done; curl -s http://127.0.0.1/health' && echo

echo "smoke test（外网，安全组未开则失败不阻断）:"
curl -s -m 3 "http://${TARGET_IP}/health" 2>/dev/null && echo || echo "  (外网不可达，可能 aliyun 安全组未开 80)"
