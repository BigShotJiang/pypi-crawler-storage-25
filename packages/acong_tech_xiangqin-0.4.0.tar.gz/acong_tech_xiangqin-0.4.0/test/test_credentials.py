"""credentials 模块单测。"""

from __future__ import annotations

import pytest


def test_get_returns_dict(fake_secrets):
    from xiangqin import credentials

    c = credentials.get("aliyun")
    assert c["access_key_id"] == "TEST_AK"
    assert c["default_region"] == "cn-hangzhou"


def test_get_alipay(fake_secrets):
    from xiangqin import credentials

    c = credentials.get("alipay")
    assert c["app_id"] == "2021000TEST"
    assert "PRIVATE KEY" in c["app_private_key"]


def test_get_unknown_alias_errors(fake_secrets):
    from xiangqin import credentials

    with pytest.raises(RuntimeError) as e:
        credentials.get("does-not-exist")
    assert "does-not-exist" in str(e.value)
    assert "已声明" in str(e.value)


def test_get_skips_underscore_keys(fake_secrets):
    from xiangqin import credentials

    with pytest.raises(RuntimeError):
        credentials.get("_generated_at")


def test_missing_secrets_file_errors(tmp_path, monkeypatch):
    from xiangqin import credentials

    monkeypatch.setenv("XIANGQIN_SECRETS_PATH", str(tmp_path / "nope.json"))
    credentials._load.cache_clear()
    with pytest.raises(RuntimeError) as e:
        credentials.get("aliyun")
    assert "不存在" in str(e.value)
    credentials._load.cache_clear()
