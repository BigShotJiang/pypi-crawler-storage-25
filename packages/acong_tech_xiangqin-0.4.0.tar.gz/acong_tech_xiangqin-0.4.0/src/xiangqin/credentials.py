"""凭证读取——直接读 `vault install` 产出的 `.vault/secrets.json`。

消费方接入协议：
  1. 项目根 `vault.json` 声明凭证别名（如 `aliyun` / `alipay`）
  2. `vault install` 生成 `.vault/secrets.json`
  3. 代码 `get("aliyun")` → dict 里含 access_key_id / access_key_secret ...

零 SDK，跨语言——Node/Go 也可直接读这个 JSON。
"""

from __future__ import annotations

import json
import os
from functools import cache
from pathlib import Path


def _secrets_path() -> Path:
    override = os.environ.get("XIANGQIN_SECRETS_PATH")
    if override:
        return Path(override)
    return Path.cwd() / ".vault" / "secrets.json"


@cache
def _load() -> dict[str, dict[str, str]]:
    p = _secrets_path()
    if not p.exists():
        raise RuntimeError(
            f".vault/secrets.json 不存在（查 {p}）。"
            "消费方项目根跑 `vault install` 生成；或设 XIANGQIN_SECRETS_PATH 指向别处。"
        )
    data = json.loads(p.read_text(encoding="utf-8"))
    return {k: v for k, v in data.items() if not k.startswith("_")}


def get(alias: str) -> dict[str, str]:
    """按 vault.json 里声明的别名取凭证字段。

    >>> get("aliyun")["access_key_id"]
    'LTAI...'
    """
    data = _load()
    if alias not in data:
        available = ", ".join(sorted(data))
        raise RuntimeError(f"vault.json 未声明凭证别名 {alias!r}（已声明：{available}）")
    return data[alias]
