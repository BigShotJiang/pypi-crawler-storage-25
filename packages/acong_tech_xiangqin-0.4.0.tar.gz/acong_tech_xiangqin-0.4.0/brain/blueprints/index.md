# 内部参考

直接读 md 源文件（VSCode / IDE），不走 MkDocs 发布通道。

- [数据库 Schema](schema.md) — 完整 sqlite 表结构（字段 / 索引 / 约束）
- [服务端架构](architecture.md) — 代码模块调用链 + 关键设计决策

## 归档

见 [archive/](archive/index.md)（暂无归档；第一个 closed/superseded 条目移入时建 `archive/index.md`）。
