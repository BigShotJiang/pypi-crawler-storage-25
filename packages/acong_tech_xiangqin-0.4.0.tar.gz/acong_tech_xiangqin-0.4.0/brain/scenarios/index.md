# 用户场景 INDEX

用 day-in-life 叙事写目标用户的完整路径。一个文件一个角色。

## 编写约束

- 不是视频脚本 / 广告台词（marketing 产物不入这里）
- 不是功能手册（功能讲法去 `docs/cli-reference.md` / `docs/usage/`）
- 文件名：`day-in-life-<角色-slug>.md`
- 时间线：08:00 场景 / 思考 / 动作 / 结果
- 标注对应的 objective / milestone

## 场景清单

- [ ] `day-in-life-first-user.md` — 对齐 [../plan/M4-sell-first-user.md](../plan/M4-sell-first-user.md)
- [ ] `day-in-life-repeat-buyer.md` — 买完第一次 100 次曝光后复购的用户
- [ ] `day-in-life-skeptic.md` — 装完 skill 但查完就走的用户

## 相关

- [../objectives/index.md](../objectives/index.md)
- [../plan/index.md](../plan/index.md)

## 归档

见 [archive/](archive/index.md)（暂无归档；第一个 closed/superseded 条目移入时建 `archive/index.md`）。
