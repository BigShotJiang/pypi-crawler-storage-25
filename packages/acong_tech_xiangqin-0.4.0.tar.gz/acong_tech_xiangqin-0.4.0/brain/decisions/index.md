# Decisions — xiangqin

倒序。最新在顶。点文件名看详情。

| 日期时间 | 标题 | 摘要 |
|---|---|---|
| 2026-04-23 21:30 | [研发发布 SOP 骨架](./2026-04-23-release-deploy-sop.md) | 单 main + tag 触发 release / alpha 合 main 自动 / epsilon 手动 / PyPI+Skill 绑定 / pyproject 版本唯一源 |
| 2026-04-23 20:30 | [砍曝光系统，信封彻底替代](./2026-04-23-drop-exposure-system.md) | 删 exposure.py / payment/ / xq expose / exposure_* 表；M4 虚拟信封作为唯一付费商品 |
| 2026-04-23 18:00 | [M4 触达架构：虚拟信封 + agent gateway 通知](./2026-04-23-m4-mail-model-touchreach.md) | 信箱/通知分离；¥1/信封 + 3 封免费/天；12h 通知去重；agent 协议中立；profile 加身高学历 |
| 2026-04-22 22:45 | [归档列表 8 → 7：shipyard 保留改 Python](./2026-04-22-2245-keep-shipyard.md) | shipyard 不归档；改 Python 栈 |
| 2026-04-22 22:30 | [M4 改 skill 分发 + 视频宣传](./2026-04-22-2230-m4-switch-to-skill-distribution.md) | 从 1 对 1 访谈改为自助分发路线 |
| 2026-04-22 18:00 | [立项 xiangqin](./2026-04-22-1800-commence-xiangqin.md) | 相亲平台 + 付费置顶 + 自治单体实验；epsilon 部署 |

## 归档

见 [archive/](archive/index.md)（暂无归档；第一个 closed/superseded 条目移入时建 `archive/index.md`）。
