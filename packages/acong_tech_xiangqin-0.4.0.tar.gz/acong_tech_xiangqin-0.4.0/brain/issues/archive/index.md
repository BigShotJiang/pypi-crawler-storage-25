# Issues Archive

已关闭 / 归档的 issue 完整清单。当前空。

## 清单

| # | 标题 | status | closed_at | 摘要 |
|---|---|---|---|---|
| [001](001-second-server-for-testing.md) | 需要第二台测试服务器（alpha 1C1G） | closed | 2026-04-23 | provision + deploy 跑通；xq --endpoint http://120.27.148.143 health → 200 |

## 约定

- issue `status: closed` 后 `git mv` 本文件到此目录
- 追加一行到上表，`closed_at` 用 frontmatter 里的值
- **不改写**已归档文件内容（遵守"不改写历史"规则）
