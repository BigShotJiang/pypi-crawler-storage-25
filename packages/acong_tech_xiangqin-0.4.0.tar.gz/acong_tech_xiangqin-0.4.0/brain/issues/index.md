# Issues

文件版的 issue 追踪（参考 GitHub Issues 模型）。每条 issue = 一个 md 文件，内含正文 + 评论 sections。

## 约定

- **文件名**：`<编号 3 位补零>-<英文 slug>.md`，例如 `001-second-server-for-testing.md`
- **frontmatter**：`id` / `title` / `status` / `labels` / `assignee` / `created_at` / `closed_at`
- **status**：`open` / `in_progress` / `closed`
- **评论**：文件里 `## 讨论` 段下按时间顺序 append，格式 `### YYYY-MM-DD HH:MM @<作者>`
- **归档**：`status: closed` 后可 `mv` 到 `archive/`；文件名保留编号
- **编号**：全项目单调递增，open 和 archive 共用编号空间

## 当前 open / in_progress

| # | 标题 | status | labels | created |
|---|---|---|---|---|
| [003](003-epsilon-phone-salt-unset.md) | epsilon 生产 PHONE_SALT 未设，跑默认 dev-salt | open | security, prod, epsilon | 2026-04-23 |
| [002](002-cli-version-check-notice.md) | xq CLI 版本检查 + 新版本提示（stderr + agent 识别） | in_progress | cli, ux, agent-native | 2026-04-23 |

## 已关闭

见 [archive/index.md](archive/index.md)。

## 新建 issue 决策流

先问：这是**待决定**还是**已决定**？

- 待决定（还要讨论 / 评估 / 拿外部资源）→ 建 issue
- 已决定（ADR 级别）→ 写 `brain/decisions/<date>-<slug>.md`

`issues/` 和 `decisions/` 互补：前者是"open question"，后者是"done decision"。
