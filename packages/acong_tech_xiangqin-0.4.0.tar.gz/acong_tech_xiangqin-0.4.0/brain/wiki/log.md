# Wiki Log

Append-only 时间线。每条记录：日期 + 动机 + 动作 + 产物链接。

## 约定

- 格式：`### YYYY-MM-DD HH:MM — <一句话动机>`
- 每条必带：`**Action:**` / `**Produced:**` / `**Sources consulted:**`
- 只写派生产物相关的事，不写常规代码改动（那归 git log）

---

### 2026-04-22 17:45 — wiki 骨架起种

**Action:** 按 Karpathy llm-wiki 范式起 wiki/ 骨架，简化为 entities / concepts 两类

**Produced:**
- brain/wiki/index.md
- brain/wiki/log.md（本文件）
- brain/wiki/entities/epsilon.md
- （concept 页 exposure-ordering / restricted-dsl 暂留下次会话补）

**Sources consulted:**
- vault.json（xiangqin 凭证声明）
- src/xiangqin/query.py（付费排序 + DSL 落地）
- src/xiangqin/dsl.py（WHERE 解析 + 白名单）
- systemd/xiangqin.service
- brain/sop/services/{deploy,restore}.md
- docs/design.md, docs/ops.md
- Karpathy llm-wiki gist: https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f

### 2026-04-22 18:00 — 对内资产统一到 brain/

**Action:** 根目录 6 个子目录 git mv 到 `brain/`：decisions / objectives / plan / scenarios / sop / wiki。根目录只保留对外 `docs/`、代码 `src/ test/`、产物 `scripts/ systemd/`、门面 `README.md` / `SKILL.md` / `CLAUDE.md`。

**Produced:**
- `brain/` 统一容器（6 子目录）
- CLAUDE.md 目录地图改为 brain/ 视角
- README.md / docs/security.md / brain/wiki/ 内部引用全部更新到 brain/ 前缀

**Sources consulted:**
- Karpathy llm-wiki 范式
