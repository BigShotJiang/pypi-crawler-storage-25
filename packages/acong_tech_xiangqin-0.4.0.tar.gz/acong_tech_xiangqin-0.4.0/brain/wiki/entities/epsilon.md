# epsilon 服务器

xiangqin 生产服务器。一站汇总所有相关信息（硬件 / 网络 / 凭证 / 服务 / 备份）。

**Sources:**
- `vault.json`（ECS 资源声明）
- vault `aliyun/ecs/i-bp1iswr9bmkv3qh89965`（阿里云侧账户记录）
- `systemd/xiangqin.service`（服务 unit）
- `scripts/deploy.sh` / `scripts/restore.sh`
- `brain/sop/services/deploy.md` / `restore.md`
- `docs/ops.md` § 1-7

## 硬件 / 网络

| 项 | 值 |
|---|---|
| 别名 | epsilon |
| IP | 112.124.27.213 |
| 规格 | 2C4G |
| 提供方 | 阿里云 ECS |
| 到期 | 2026-07-13 |
| 安全组开放端口 | 22（SSH）/ 80 / 443 |
| 已收窄端口 | 7000 / 9876 / 22000-22999 / 内网 5432（openclaw 遗留） |

## 服务拓扑

```
systemd: xiangqin.service (User=xiangqin, ProtectSystem=strict)
    ↓
uvicorn :8000 (xiangqin-server)
    ↓
FastAPI (src/xiangqin/app.py)
    ↓
sqlite WAL @ /opt/xiangqin/data/xiangqin.db
```

代码路径：`/opt/xiangqin/`（部署产物，非仓库）  
Python：`/opt/uv-python`（uv 管理，共享路径）  
运行用户：`xiangqin`（system user，nologin shell）

## 消费的凭证（来自 vault）

通过 `/opt/xiangqin/.vault/secrets.json`：

| 别名 | vault slug | 用途 |
|---|---|---|
| `aliyun` | `aliyun-main` | OSS 备份 + DNS（生产也用主账号） |
| `aliyun_sms` | `aliyun-power-app-ak` | 注册验证码短信 |
| `alipay` | `alipay-kongxuanpin` | 曝光付费当面付 |

## 外部依赖资源

| 资源 | 用途 |
|---|---|
| `aliyun/oss/agentaily-backup-xiangqin-prod` | sqlite 每日 02:00 备份目的桶 |
| `aliyun/sms-sign/杭州阿空智能科技` | 短信签名 |
| `aliyun/sms-template/SMS_317151039` | 验证码模板 |
| `alipay/openapi-app/2021000104691762` | 支付应用 |
| `aliyun/dns-record/xq.agentaily.com` | 域名解析（规划中） |

## 定时任务

- `/etc/cron.d/xiangqin-backup` 每日 02:00：`scripts/backup.sh` → OSS

## 运维剧本入口

| 场景 | 去哪 |
|---|---|
| 发新代码 | `brain/sop/services/deploy.md` + `bash scripts/deploy.sh` |
| 数据恢复 | `brain/sop/services/restore.md` + `bash scripts/restore.sh` |
| 查状态 / 日志 / 重启 | `docs/ops.md` § 1-2 |
| 紧急回滚 | `docs/ops.md` § 7 |
| 挂了切备用机 | `docs/ops.md` § 8 |

## 风险画像

- **单点**：只有一台 epsilon，挂了 xiangqin 就挂
- **恢复上限**：备份每日 02:00，数据丢失窗口最长 24h
- **容量**：2C4G，sqlite WAL 单机，0.1 期够用；到规模（>100 req/s 或 DB >5GB）得迁 PG + 多机
