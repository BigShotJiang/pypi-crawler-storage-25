# Wiki INDEX

LLM 生成的**跨目录综合视图**。源头是 `src/` / `brain/decisions/` / `brain/sop/` / `vault.json` 等，这里只放**把多个分散位置拼起来**的派生页。

## Entities（能指到的具体对象）

- [epsilon 服务器](entities/epsilon.md) — 生产服务器跨 vault / systemd / scripts / SOP 综合

## Concepts（抽象主题 / 操作范式）

- [付费排序语义](concepts/exposure-ordering.md) — query.py 实现 + ADR + 测试 + 文档的交叉索引
- [受限 WHERE DSL](concepts/restricted-dsl.md) — dsl.py + 白名单 + 测试覆盖 + 文档的交叉索引

## 工作流

见 [CLAUDE.md § Wiki 工作流](../CLAUDE.md#wiki-工作流)。
LLM 做完跨文件研究 / 分析 / 综合后，结论保留价值的 append 到这里，并更新 [log.md](log.md)。

## 约定

- **entities/**：一个"能指到的东西"一个文件（服务器 / 账号 / 外部资源 / 核心功能模块）
- **concepts/**：抽象主题 / 操作范式 / 一条边界一个文件
- 文件名英文 kebab-case（中文标题写在文档内）
- 所有 wiki 页开头必带一段「**Sources**」指回原文位置（`src/path/file.py:L123` / `brain/decisions/xxx.md` / `docs/yyy.md`）

## 归档

见 [archive/](archive/index.md)（暂无归档；第一个 closed/superseded 条目移入时建 `archive/index.md`）。
