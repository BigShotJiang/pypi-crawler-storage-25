---
name: release-flow
owner: team-lead
version: 1
last-updated: 2026-04-23
---

# SOP: 研发发布总览

本文档是发布链路的**入口图**。具体怎么执行每一步看子 SOP。

决策依据：[2026-04-23 release-deploy-sop ADR](../decisions/2026-04-23-release-deploy-sop.md)。

## 产物 × 机器

| 产物 | 去哪 | 触发 |
|---|---|---|
| Python 包 `acong-tech-xiangqin` | PyPI | `git push --tags` |
| Skill `xiangqin` | `acong-tech/skill-xiangqin` GH 仓（ClawHub 同步源）| `git push --tags` |
| 服务端代码 | alpha 测试机 | 合 main（自动） |
| 服务端代码 | epsilon 生产机 | GHA 手动 workflow_dispatch |
| 文档站 | Cloudflare Pages | 合 main（自动） |

## 时间线

```
┌──────────────────────────────────────────────────────────┐
│ 日常开发                                                  │
│                                                           │
│  本地：改码 → uv run pytest → uv run ruff check           │
│      ↓                                                    │
│  git push → GHA ci.yml：test + lint + mkdocs --strict     │
│      ↓                                                    │
│  合 main                                                  │
│      ├─ GHA deploy-staging.yml：rsync → alpha → systemctl    │
│      │  restart → smoke test curl alpha/health            │
│      └─ GHA ci.yml docs job：CF Pages 部署最新文档         │
│      ↓                                                    │
│  人肉 alpha 验收：xq --endpoint http://alpha ... 跑流程    │
│      ↓                                                    │
│  OK → bump version                                        │
└──────────────────────────────────────────────────────────┘
                      ↓
┌──────────────────────────────────────────────────────────┐
│ 发布                                                      │
│                                                           │
│  改 pyproject.toml `version = "X.Y.Z"`                    │
│  改 src/xiangqin/__init__.py `__version__ = "X.Y.Z"`      │
│  改 CHANGELOG.md（从 [Unreleased] 提到 [X.Y.Z]）           │
│  commit + push                                            │
│      ↓                                                    │
│  git tag vX.Y.Z                                           │
│  git push --tags                                          │
│      ↓                                                    │
│  GHA release.yml（on tag）：                              │
│    ├─ 发 PyPI（uv publish）                               │
│    └─ 同步 SKILL.md 到 skill-xiangqin 仓 + push tag       │
│      ↓                                                    │
│  GHA UI 手动点 Deploy to epsilon（输入 tag）              │
│      ↓                                                    │
│  冒烟：curl http://112.124.27.213/health                  │
│  人肉 xq health（从 PyPI 装新版）                         │
└──────────────────────────────────────────────────────────┘
```

## 版本号规则

SemVer：
- **patch** (`0.3.1 → 0.3.2`)：bug fix，用户无感升级
- **minor** (`0.3.x → 0.4.0`)：新功能，用户可选用；0.x 期允许 BREAKING（CHANGELOG 标）
- **major** (`0.x → 1.0.0`)：生产就绪 + 对外 API 稳定承诺

**单一版本源**：`pyproject.toml` 的 `version`。`__init__.py.__version__` / CHANGELOG 段 / git tag 都跟着它走。改版本号时 3 处一起改。

## 子 SOP

| 场景 | 看哪 |
|---|---|
| 正常发版（alpha 验过 → tag → 发 PyPI + skill → epsilon） | [services/publish.md](./services/publish.md) + [services/deploy.md](./services/deploy.md) |
| 紧急线上 bug | [services/hotfix.md](./services/hotfix.md) |
| 发完发现有问题 / 要回滚 | [emergency/rollback.md](./emergency/rollback.md) |
| 数据库坏了要恢复 | [services/restore.md](./services/restore.md) |

## 首次配置（一次性）

GHA workflow 文件 + secrets 首次建立：

### Secrets（GitHub repo settings → Secrets）

| secret | 用途 |
|---|---|
| `PYPI_API_TOKEN` | `uv publish` 发 PyPI 用 |
| `SKILL_REPO_DEPLOY_KEY` | push 到 `acong-tech/skill-xiangqin` 的 SSH key（或 PAT） |
| `ALPHA_SSH_KEY` | deploy-staging.yml 用的私钥 |
| `ALPHA_HOST` | alpha 机器 IP |
| `EPSILON_SSH_KEY` | deploy-production.yml 用的私钥 |
| `EPSILON_HOST` | `112.124.27.213` |
| `CLOUDFLARE_API_TOKEN` / `CLOUDFLARE_ACCOUNT_ID` | 已配（CF Pages 用） |

### Workflow 文件

- `.github/workflows/ci.yml`（现有）
- `.github/workflows/deploy-staging.yml`（待建，issue #001 一部分）
- `.github/workflows/release.yml`（待建）
- `.github/workflows/deploy-production.yml`（待建）

## 归档

见 [archive/](archive/index.md)（暂无）。
