# SOP INDEX

标准作业程序。遇到对应场景时**直接抄剧本**，不自己推断步骤。

## 清单

| SOP | 触发时机 | 路径 |
|---|---|---|
| **release-flow** | 想搞清楚发布链路整体长啥样（总览图） | [release-flow.md](./release-flow.md) |
| **deploy** | 发代码到 alpha 测试机或 epsilon 生产机 | [services/deploy.md](./services/deploy.md) |
| **publish** | 切版本号发 PyPI + ClawHub skill（绑在一起） | [services/publish.md](./services/publish.md) |
| **hotfix** | 线上已坏，跳常规流程直上 epsilon | [services/hotfix.md](./services/hotfix.md) |
| **rollback** | 发完发现有问题要回退 | [emergency/rollback.md](./emergency/rollback.md) |
| **restore** | sqlite 损坏 / 误删 / 调试需要 prod 数据副本 | [services/restore.md](./services/restore.md) |
| **sms-onboarding** | 阿里云短信签名 / 模板变更，或首次接入新短信供应商 | [operations/sms-onboarding.md](./operations/sms-onboarding.md) |
| **payment-onboarding** | 支付宝应用变更 / 首次接入新支付供应商 | [operations/payment-onboarding.md](./operations/payment-onboarding.md) |

## 编写约束

- **前置条件 checkbox 可验证**（`curl .../health` 能过）
- **步骤编号化**
- **失败分支写**：每步"如果挂了怎么办"
- **version / last-updated** frontmatter 保持更新

## vs docs/ops.md

- `sop/services/*.md` 是完整原始剧本（原封保留）
- `docs/ops.md` 是对外运维索引 + 要点提炼

改 SOP 时同步刷 `docs/ops.md` 对应段落。

## 归档

见 [archive/](archive/index.md)（暂无归档；第一个 closed/superseded 条目移入时建 `archive/index.md`）。
