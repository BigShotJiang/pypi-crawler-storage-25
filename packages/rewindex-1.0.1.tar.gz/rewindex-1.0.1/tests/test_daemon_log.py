# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import os
import stat
import subprocess
import sys
from unittest.mock import MagicMock, patch

import pytest


@pytest.fixture()
def pid_dir(tmp_path, monkeypatch):
    pid_file = str(tmp_path / "daemon.pid")
    monkeypatch.setattr("rewindex.config.defaults.PID_FILE", pid_file)
    monkeypatch.setattr("rewindex.daemon.runner.PID_FILE", pid_file)
    return tmp_path


# ── run_daemon_process redirects stdout/stderr to daemon.log ─────────────────

def test_run_daemon_process_redirects_to_log(pid_dir):
    """Child always writes to daemon.log regardless of how it was started."""
    log_path = str(pid_dir / "daemon.log")

    original_stdout = sys.stdout
    original_stderr = sys.stderr

    with patch("rewindex.config.loader.load_config", return_value={}), \
         patch("rewindex.daemon.reconcile.startup_reconcile"), \
         patch("rewindex.daemon.watcher.start_watching", side_effect=KeyboardInterrupt):
        from rewindex.daemon.runner import run_daemon_process
        run_daemon_process()

    assert os.path.exists(log_path), "daemon.log was not created"

    # Restore so pytest output still works
    sys.stdout = original_stdout
    sys.stderr = original_stderr


def test_run_daemon_process_log_permissions(pid_dir):
    """daemon.log must be mode 0o600 (owner read/write only)."""
    log_path = str(pid_dir / "daemon.log")

    original_stdout = sys.stdout
    original_stderr = sys.stderr

    with patch("rewindex.config.loader.load_config", return_value={}), \
         patch("rewindex.daemon.reconcile.startup_reconcile"), \
         patch("rewindex.daemon.watcher.start_watching", side_effect=KeyboardInterrupt):
        from rewindex.daemon.runner import run_daemon_process
        run_daemon_process()

    sys.stdout = original_stdout
    sys.stderr = original_stderr

    mode = stat.S_IMODE(os.stat(log_path).st_mode)
    assert mode == 0o600, f"Expected 0o600, got {oct(mode)}"


def test_run_daemon_process_writes_to_log(pid_dir):
    """Output from daemon process appears in daemon.log, not lost."""
    log_path = str(pid_dir / "daemon.log")

    original_stdout = sys.stdout
    original_stderr = sys.stderr

    def fake_watching(config):
        print("daemon started ok")
        raise KeyboardInterrupt

    with patch("rewindex.config.loader.load_config", return_value={}), \
         patch("rewindex.daemon.reconcile.startup_reconcile"), \
         patch("rewindex.daemon.watcher.start_watching", side_effect=fake_watching):
        from rewindex.daemon.runner import run_daemon_process
        run_daemon_process()

    sys.stdout = original_stdout
    sys.stderr = original_stderr

    content = open(log_path).read()
    assert "daemon started ok" in content


# ── start_daemon passes DEVNULL, not log fd ──────────────────────────────────

def test_start_daemon_passes_devnull_not_log_fd(pid_dir):
    """Parent must not open daemon.log — child owns the log file."""
    captured_kwargs = {}

    def fake_popen(cmd, **kwargs):
        captured_kwargs.update(kwargs)
        mock = MagicMock()
        mock.pid = 12345
        return mock

    with patch("rewindex.daemon.runner.subprocess.Popen", side_effect=fake_popen), \
         patch("rewindex.daemon.runner._find_bin", return_value=["rewindex"]), \
         patch("rewindex.daemon.runner.is_running", return_value=False):
        from rewindex.daemon.runner import start_daemon
        start_daemon({})

    assert captured_kwargs.get("stdout") == subprocess.DEVNULL
    assert captured_kwargs.get("stderr") == subprocess.DEVNULL


def test_start_daemon_does_not_create_log_file(pid_dir):
    """Parent must not create daemon.log — only child should create it."""
    log_path = str(pid_dir / "daemon.log")

    def fake_popen(cmd, **kwargs):
        mock = MagicMock()
        mock.pid = 12345
        return mock

    with patch("rewindex.daemon.runner.subprocess.Popen", side_effect=fake_popen), \
         patch("rewindex.daemon.runner._find_bin", return_value=["rewindex"]), \
         patch("rewindex.daemon.runner.is_running", return_value=False):
        from rewindex.daemon.runner import start_daemon
        start_daemon({})

    assert not os.path.exists(log_path), "Parent must not create daemon.log"
