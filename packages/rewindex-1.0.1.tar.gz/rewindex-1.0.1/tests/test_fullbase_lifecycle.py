# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

"""
Tests for fullbase lifecycle:
  - Trim base 1: exactly 1 per file, updates on every trim
  - Precompute base 2: exactly 1 per file, old ones cleaned up
  - Interaction between trim and precompute over many sessions
"""

import os
import sqlite3

import pytest

from rewindex.db.connection import get_connection
from rewindex.db.queries import (
    create_forced_session,
    get_all_tracked_files,
    get_file_versions_since,
    get_session_count,
)
from rewindex.snapshot.engine import snapshot_file
from rewindex.snapshot.reconstruct import reconstruct


@pytest.fixture()
def env(tmp_path, monkeypatch):
    rewindex_dir = tmp_path / ".rewindex"
    rewindex_dir.mkdir()
    snaps = rewindex_dir / "snapshots"
    snaps.mkdir()
    monkeypatch.setattr("rewindex.config.defaults.REWINDEX_DIR", str(rewindex_dir))
    monkeypatch.setattr("rewindex.config.defaults.SNAPSHOTS_DIR", str(snaps))
    folder = tmp_path / "project"
    folder.mkdir()
    conn = get_connection("fbtest")
    return {"conn": conn, "folder": folder, "name": "fbtest"}


def _snap(env, filename, content, session_uid):
    abs_path = env["folder"] / filename
    abs_path.parent.mkdir(parents=True, exist_ok=True)
    abs_path.write_text(content)
    return snapshot_file(
        env["conn"], env["name"], str(env["folder"]), str(abs_path),
        session_uid=session_uid,
    )


def _count_fullbases(conn, registry_uid, promoted_by=None):
    if promoted_by:
        rows = conn.execute(
            "SELECT COUNT(*) as c FROM file WHERE file_registry_uid = ? AND is_full = 1 AND promoted_by = ? AND is_corrupted = 0",
            (registry_uid, promoted_by),
        ).fetchone()
    else:
        rows = conn.execute(
            "SELECT COUNT(*) as c FROM file WHERE file_registry_uid = ? AND is_full = 1 AND is_corrupted = 0",
            (registry_uid,),
        ).fetchone()
    return rows["c"]


def _get_fullbase_uid(conn, registry_uid, promoted_by):
    row = conn.execute(
        "SELECT uid FROM file WHERE file_registry_uid = ? AND is_full = 1 AND promoted_by = ? AND is_corrupted = 0 ORDER BY uid DESC LIMIT 1",
        (registry_uid, promoted_by),
    ).fetchone()
    return row["uid"] if row else None


def _reg_uid(conn, file_uid):
    return conn.execute("SELECT file_registry_uid FROM file WHERE uid = ?", (file_uid,)).fetchone()["file_registry_uid"]


# ══════════════════════════════════════════════════════════════════════════════
# Trim base 1: updates on every trim, exactly 1 per file
# ══════════════════════════════════════════════════════════════════════════════

def test_trim_fullbase_updates_on_repeated_trims(env):
    """Each trim creates a new trim base at a later position, deleting the old one."""
    from rewindex.snapshot.trim import _run_trim

    conn = env["conn"]
    project = env["name"]

    for i in range(20):
        ts = f"2026-01-{(i % 28) + 1:02d}T{i:02d}:00:00+00:00"
        s = create_forced_session(conn, project, ts)
        _snap(env, "app.py", f"version {i+1}\n" * 5, s)

    # First trim: cut 5
    _run_trim(conn, project, cut=5)
    tracked = get_all_tracked_files(conn, project)
    reg = tracked[0]

    trim_count_1 = _count_fullbases(conn, reg["uid"], "trim")
    trim_uid_1 = _get_fullbase_uid(conn, reg["uid"], "trim")
    assert trim_count_1 == 1, f"Expected 1 trim base after first trim, got {trim_count_1}"
    assert trim_uid_1 is not None

    # Second trim: cut 5 more
    _run_trim(conn, project, cut=5)

    trim_count_2 = _count_fullbases(conn, reg["uid"], "trim")
    trim_uid_2 = _get_fullbase_uid(conn, reg["uid"], "trim")
    assert trim_count_2 == 1, f"Expected 1 trim base after second trim, got {trim_count_2}"
    assert trim_uid_2 > trim_uid_1, "Trim base should advance forward"

    # Third trim: cut 3 more
    _run_trim(conn, project, cut=3)

    trim_count_3 = _count_fullbases(conn, reg["uid"], "trim")
    trim_uid_3 = _get_fullbase_uid(conn, reg["uid"], "trim")
    assert trim_count_3 == 1, f"Expected 1 trim base after third trim, got {trim_count_3}"
    assert trim_uid_3 > trim_uid_2, "Trim base should advance forward again"


def test_trim_fullbase_always_exactly_one_per_file(env):
    """With multiple files, each file gets exactly 1 trim base after trim."""
    from rewindex.snapshot.trim import _run_trim

    conn = env["conn"]
    project = env["name"]
    filenames = ["a.py", "b.py", "c.py"]

    for i in range(15):
        ts = f"2026-02-{(i % 28) + 1:02d}T00:00:00+00:00"
        s = create_forced_session(conn, project, ts)
        for fn in filenames:
            _snap(env, fn, f"{fn} version {i+1}\n", s)

    _run_trim(conn, project, cut=8)

    tracked = get_all_tracked_files(conn, project)
    assert len(tracked) == 3

    for reg in tracked:
        trim_count = _count_fullbases(conn, reg["uid"], "trim")
        assert trim_count == 1, f"{reg['filepath']}: expected 1 trim base, got {trim_count}"
        total_full = _count_fullbases(conn, reg["uid"])
        assert total_full >= 1


def test_trim_base_reconstructs_correctly(env):
    """Content at trim base matches what was written at that session."""
    from rewindex.snapshot.trim import _run_trim

    conn = env["conn"]
    project = env["name"]

    contents = {}
    for i in range(12):
        ts = f"2026-03-{(i % 28) + 1:02d}T00:00:00+00:00"
        s = create_forced_session(conn, project, ts)
        content = f"line {i}\n" * 5
        uid = _snap(env, "data.py", content, s)
        contents[uid] = content.splitlines(keepends=True)

    _run_trim(conn, project, cut=7)

    tracked = get_all_tracked_files(conn, project)
    for reg in tracked:
        remaining = get_file_versions_since(conn, reg["uid"], 0)
        for ver in remaining:
            if ver["uid"] in contents:
                result = reconstruct(conn, reg["uid"], ver["uid"])
                assert result == contents[ver["uid"]]


# ══════════════════════════════════════════════════════════════════════════════
# Precompute base 2: exactly 1, old ones cleaned up
# ══════════════════════════════════════════════════════════════════════════════

def test_precompute_creates_fullbase(env):
    """_run_precompute creates a precompute fullbase at the specified session."""
    from rewindex.snapshot.precompute import _run_precompute

    conn = env["conn"]
    project = env["name"]

    uids = []
    for i in range(10):
        ts = f"2026-04-{(i % 28) + 1:02d}T00:00:00+00:00"
        s = create_forced_session(conn, project, ts)
        uid = _snap(env, "pre.py", f"precompute v{i+1}\n" * 3, s)
        uids.append((uid, s))

    target_session = uids[4][1]
    _run_precompute(conn, project, target_session, cut=5)

    tracked = get_all_tracked_files(conn, project)
    reg = tracked[0]

    pc_count = _count_fullbases(conn, reg["uid"], "precompute")
    assert pc_count == 1, f"Expected 1 precompute base, got {pc_count}"

    pc_uid = _get_fullbase_uid(conn, reg["uid"], "precompute")
    assert pc_uid is not None


def test_precompute_replaces_old_base(env):
    """Running precompute twice: second run creates new base and removes old one."""
    from rewindex.snapshot.precompute import _run_precompute

    conn = env["conn"]
    project = env["name"]

    sessions = []
    for i in range(20):
        ts = f"2026-05-{(i % 28) + 1:02d}T{i:02d}:00:00+00:00"
        s = create_forced_session(conn, project, ts)
        _snap(env, "replace.py", f"v{i+1}\n" * 3, s)
        sessions.append(s)

    # First precompute at session 5
    _run_precompute(conn, project, sessions[4], cut=5)
    tracked = get_all_tracked_files(conn, project)
    reg = tracked[0]

    pc_uid_1 = _get_fullbase_uid(conn, reg["uid"], "precompute")
    assert pc_uid_1 is not None
    assert _count_fullbases(conn, reg["uid"], "precompute") == 1

    # Second precompute at session 10 — should clean up old one
    _run_precompute(conn, project, sessions[9], cut=5)

    pc_uid_2 = _get_fullbase_uid(conn, reg["uid"], "precompute")
    assert pc_uid_2 is not None
    assert pc_uid_2 > pc_uid_1, "New precompute base should be at a later uid"
    assert _count_fullbases(conn, reg["uid"], "precompute") == 1, \
        "Old precompute base should be reverted — only 1 precompute base allowed"

    # Old base should be reverted to diff (is_full=0) — both files coexist on disk,
    # cleanup picks the original .diff/.diff.gz and deletes .full.gz
    old_row = conn.execute("SELECT is_full, promoted_by, storage_path FROM file WHERE uid = ?", (pc_uid_1,)).fetchone()
    if old_row:
        assert old_row["is_full"] == 0, "Old precompute base should be reverted to diff"
        assert old_row["promoted_by"] is None, "Old precompute base should have promoted_by cleared"
        assert ".diff" in old_row["storage_path"], "Old base storage_path should point to diff file"


def test_precompute_third_run_still_one_base(env):
    """Three consecutive precompute runs: always exactly 1 precompute base."""
    from rewindex.snapshot.precompute import _run_precompute

    conn = env["conn"]
    project = env["name"]

    sessions = []
    for i in range(30):
        ts = f"2026-06-{(i % 28) + 1:02d}T{i:02d}:00:00+00:00"
        s = create_forced_session(conn, project, ts)
        _snap(env, "triple.py", f"v{i+1} content\n" * 2, s)
        sessions.append(s)

    tracked = get_all_tracked_files(conn, project)
    reg = tracked[0]

    prev_uid = None
    for target_idx in [4, 9, 14]:
        _run_precompute(conn, project, sessions[target_idx], cut=5)

        pc_count = _count_fullbases(conn, reg["uid"], "precompute")
        assert pc_count == 1, f"After precompute at session {target_idx}: expected 1 base, got {pc_count}"

        pc_uid = _get_fullbase_uid(conn, reg["uid"], "precompute")
        if prev_uid is not None:
            assert pc_uid > prev_uid, "Precompute base should advance forward"
        prev_uid = pc_uid


def test_precompute_cleanup_reverts_to_diff_on_disk(env):
    """After cleanup, old precompute .full.gz is deleted and diff file remains."""
    from rewindex.snapshot.precompute import _run_precompute

    conn = env["conn"]
    project = env["name"]

    sessions = []
    for i in range(20):
        ts = f"2026-05-{(i % 28) + 1:02d}T{i:02d}:00:00+00:00"
        s = create_forced_session(conn, project, ts)
        _snap(env, "diskcheck.py", f"v{i+1}\n" * 3, s)
        sessions.append(s)

    # First precompute at session 5
    _run_precompute(conn, project, sessions[4], cut=5)
    tracked = get_all_tracked_files(conn, project)
    reg = tracked[0]

    pc_uid_1 = _get_fullbase_uid(conn, reg["uid"], "precompute")
    row1 = conn.execute("SELECT storage_path FROM file WHERE uid = ?", (pc_uid_1,)).fetchone()
    full_gz_path = row1["storage_path"]
    assert os.path.isfile(full_gz_path), ".full.gz should exist after first precompute"

    # Second precompute at session 10 — should revert old one to diff
    _run_precompute(conn, project, sessions[9], cut=5)

    # Old .full.gz should be deleted
    assert not os.path.isfile(full_gz_path), ".full.gz should be deleted after cleanup"

    # Old row should point to diff, which still exists
    old_row = conn.execute("SELECT storage_path, is_full FROM file WHERE uid = ?", (pc_uid_1,)).fetchone()
    if old_row:
        assert old_row["is_full"] == 0
        assert os.path.isfile(old_row["storage_path"]), "Diff file should still exist on disk"

    # Reconstruct chain should still work for all versions
    remaining = get_file_versions_since(conn, reg["uid"], 0)
    for ver in remaining:
        result = reconstruct(conn, reg["uid"], ver["uid"])
        assert len(result) > 0, f"Failed to reconstruct uid={ver['uid']}"


# ══════════════════════════════════════════════════════════════════════════════
# Interaction: trim + precompute together over many sessions
# ══════════════════════════════════════════════════════════════════════════════

def test_trim_and_precompute_coexist(env):
    """After trim + precompute, each file has exactly 1 trim base + 1 precompute base."""
    from rewindex.snapshot.trim import _run_trim
    from rewindex.snapshot.precompute import _run_precompute

    conn = env["conn"]
    project = env["name"]

    sessions = []
    for i in range(20):
        ts = f"2026-07-{(i % 28) + 1:02d}T{i:02d}:00:00+00:00"
        s = create_forced_session(conn, project, ts)
        _snap(env, "coexist.py", f"co v{i+1}\n" * 4, s)
        sessions.append(s)

    # Trim first 5 sessions → trim base at first kept (session 6)
    _run_trim(conn, project, cut=5)

    # Precompute at session 15
    _run_precompute(conn, project, sessions[14], cut=5)

    tracked = get_all_tracked_files(conn, project)
    reg = tracked[0]

    trim_count = _count_fullbases(conn, reg["uid"], "trim")
    pc_count = _count_fullbases(conn, reg["uid"], "precompute")
    total = _count_fullbases(conn, reg["uid"])

    assert trim_count == 1, f"Expected 1 trim base, got {trim_count}"
    assert pc_count == 1, f"Expected 1 precompute base, got {pc_count}"
    # total includes original (promoted_by=NULL) + trim + precompute
    assert total >= 2, f"Expected at least 2 fullbases total, got {total}"


def test_repeated_trim_then_precompute_cycle(env):
    """Simulate long-running system: trim→precompute→trim→precompute, verify invariants."""
    from rewindex.snapshot.trim import _run_trim
    from rewindex.snapshot.precompute import _run_precompute

    conn = env["conn"]
    project = env["name"]

    sessions = []
    for i in range(40):
        ts = f"2026-08-{(i % 28) + 1:02d}T{i:02d}:00:00+00:00"
        s = create_forced_session(conn, project, ts)
        _snap(env, "cycle.py", f"cycle v{i+1}\n" * 3, s)
        sessions.append(s)

    tracked = get_all_tracked_files(conn, project)
    reg = tracked[0]

    # Round 1: trim 5, precompute at 10
    _run_trim(conn, project, cut=5)
    _run_precompute(conn, project, sessions[9], cut=5)
    assert _count_fullbases(conn, reg["uid"], "trim") == 1
    assert _count_fullbases(conn, reg["uid"], "precompute") == 1
    trim_uid_1 = _get_fullbase_uid(conn, reg["uid"], "trim")
    pc_uid_1 = _get_fullbase_uid(conn, reg["uid"], "precompute")

    # Round 2: trim 5 more, precompute at 20
    _run_trim(conn, project, cut=5)
    _run_precompute(conn, project, sessions[19], cut=5)
    assert _count_fullbases(conn, reg["uid"], "trim") == 1
    assert _count_fullbases(conn, reg["uid"], "precompute") == 1
    trim_uid_2 = _get_fullbase_uid(conn, reg["uid"], "trim")
    pc_uid_2 = _get_fullbase_uid(conn, reg["uid"], "precompute")
    assert trim_uid_2 > trim_uid_1, "Trim base should advance"
    assert pc_uid_2 > pc_uid_1, "Precompute base should advance"

    # Round 3: trim 5 more, precompute at 30
    _run_trim(conn, project, cut=5)
    _run_precompute(conn, project, sessions[29], cut=5)
    assert _count_fullbases(conn, reg["uid"], "trim") == 1
    assert _count_fullbases(conn, reg["uid"], "precompute") == 1
    trim_uid_3 = _get_fullbase_uid(conn, reg["uid"], "trim")
    pc_uid_3 = _get_fullbase_uid(conn, reg["uid"], "precompute")
    assert trim_uid_3 > trim_uid_2
    assert pc_uid_3 > pc_uid_2

    # All remaining versions should reconstruct
    remaining = get_file_versions_since(conn, reg["uid"], 0)
    for ver in remaining:
        result = reconstruct(conn, reg["uid"], ver["uid"])
        assert len(result) > 0, f"Failed to reconstruct uid={ver['uid']}"


def test_trim_deletes_old_precompute_base(env):
    """When trim advances past a precompute base, it gets deleted with the old versions."""
    from rewindex.snapshot.trim import _run_trim
    from rewindex.snapshot.precompute import _run_precompute

    conn = env["conn"]
    project = env["name"]

    sessions = []
    for i in range(25):
        ts = f"2026-09-{(i % 28) + 1:02d}T{i:02d}:00:00+00:00"
        s = create_forced_session(conn, project, ts)
        _snap(env, "trimpc.py", f"tp v{i+1}\n" * 3, s)
        sessions.append(s)

    # Precompute at session 5
    _run_precompute(conn, project, sessions[4], cut=5)
    tracked = get_all_tracked_files(conn, project)
    reg = tracked[0]
    pc_uid = _get_fullbase_uid(conn, reg["uid"], "precompute")
    assert pc_uid is not None

    # Trim cuts sessions 1-10 — precompute base at session 5 should be deleted
    _run_trim(conn, project, cut=10)

    old_pc = conn.execute("SELECT * FROM file WHERE uid = ?", (pc_uid,)).fetchone()
    assert old_pc is None, "Old precompute base should be deleted by trim (was before boundary)"

    trim_count = _count_fullbases(conn, reg["uid"], "trim")
    assert trim_count == 1


def test_multifile_trim_precompute_invariants(env):
    """Multiple files: each gets exactly 1 trim + 1 precompute base after full cycle."""
    from rewindex.snapshot.trim import _run_trim
    from rewindex.snapshot.precompute import _run_precompute

    conn = env["conn"]
    project = env["name"]
    filenames = ["x.py", "y.py", "z.py"]

    sessions = []
    for i in range(20):
        ts = f"2026-10-{(i % 28) + 1:02d}T{i:02d}:00:00+00:00"
        s = create_forced_session(conn, project, ts)
        for fn in filenames:
            _snap(env, fn, f"{fn} v{i+1}\n" * 2, s)
        sessions.append(s)

    _run_trim(conn, project, cut=5)
    _run_precompute(conn, project, sessions[14], cut=5)

    tracked = get_all_tracked_files(conn, project)
    assert len(tracked) == 3

    for reg in tracked:
        trim_c = _count_fullbases(conn, reg["uid"], "trim")
        pc_c = _count_fullbases(conn, reg["uid"], "precompute")
        assert trim_c == 1, f"{reg['filepath']}: expected 1 trim base, got {trim_c}"
        assert pc_c == 1, f"{reg['filepath']}: expected 1 precompute base, got {pc_c}"

        remaining = get_file_versions_since(conn, reg["uid"], 0)
        for ver in remaining:
            result = reconstruct(conn, reg["uid"], ver["uid"])
            assert len(result) > 0


# ══════════════════════════════════════════════════════════════════════════════
# Hash verification during trim promote
# ══════════════════════════════════════════════════════════════════════════════

def test_trim_hash_verify_detects_corruption(env):
    """Trim promote skips and marks corrupted when reconstructed content has wrong hash."""
    from rewindex.snapshot.trim import _run_trim
    from rewindex.db.queries import mark_corrupted

    conn = env["conn"]
    project = env["name"]

    for i in range(10):
        ts = f"2026-11-{(i % 28) + 1:02d}T00:00:00+00:00"
        s = create_forced_session(conn, project, ts)
        _snap(env, "corrupt.py", f"v{i+1}\n" * 3, s)

    tracked = get_all_tracked_files(conn, project)
    reg = tracked[0]

    # Tamper: change hash of first_kept candidate (version at session 6) to a wrong value
    first_kept_candidates = conn.execute(
        "SELECT uid, session_uid FROM file WHERE file_registry_uid = ? AND is_corrupted = 0 ORDER BY uid ASC",
        (reg["uid"],),
    ).fetchall()

    # After cut=5, first_kept will be the first version in session >= 6
    target_uid = None
    for v in first_kept_candidates:
        if v["session_uid"] >= 6:
            target_uid = v["uid"]
            break
    assert target_uid is not None

    conn.execute("UPDATE file SET hash = 'tampered_hash_value' WHERE uid = ?", (target_uid,))
    conn.commit()

    # Trim should detect mismatch and mark corrupted instead of promoting
    _run_trim(conn, project, cut=5)

    row = conn.execute("SELECT is_corrupted FROM file WHERE uid = ?", (target_uid,)).fetchone()
    if row:
        assert row["is_corrupted"] == 1, "Tampered version should be marked corrupted"


def test_trim_hash_verify_passes_for_valid_content(env):
    """Trim promote succeeds when reconstructed content matches stored hash."""
    from rewindex.snapshot.trim import _run_trim

    conn = env["conn"]
    project = env["name"]

    for i in range(10):
        ts = f"2026-12-{(i % 28) + 1:02d}T00:00:00+00:00"
        s = create_forced_session(conn, project, ts)
        _snap(env, "valid.py", f"valid v{i+1}\n" * 3, s)

    _run_trim(conn, project, cut=5)

    tracked = get_all_tracked_files(conn, project)
    reg = tracked[0]

    # All remaining should be valid (not corrupted) and reconstructable
    remaining = get_file_versions_since(conn, reg["uid"], 0)
    for ver in remaining:
        assert ver["is_corrupted"] == 0, f"uid={ver['uid']} should not be corrupted"
        result = reconstruct(conn, reg["uid"], ver["uid"])
        assert len(result) > 0
