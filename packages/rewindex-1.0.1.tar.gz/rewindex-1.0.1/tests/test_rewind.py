# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import os

import pytest

from rewindex.db.connection import get_connection
from rewindex.snapshot.engine import snapshot_file
from rewindex.snapshot.reconstruct import reconstruct


@pytest.fixture()
def project(tmp_path, monkeypatch):
    monkeypatch.setattr("rewindex.config.defaults.SNAPSHOTS_DIR", str(tmp_path / "snapshots"))
    folder = tmp_path / "src"
    folder.mkdir()
    conn = get_connection("proj")
    return {"conn": conn, "folder": str(folder), "name": "proj"}


def _snap(project, filename, lines):
    path = os.path.join(project["folder"], filename)
    with open(path, "w") as f:
        f.writelines(lines)
    return snapshot_file(project["conn"], project["name"], project["folder"], path)


def _reg_uid(conn, file_uid):
    row = conn.execute("SELECT file_registry_uid FROM file WHERE uid = ?", (file_uid,)).fetchone()
    return row["file_registry_uid"]


def test_rewind_to_first(project):
    v1 = ["original\n"]
    v2 = ["modified\n"]
    s1 = _snap(project, "f.py", v1)
    _snap(project, "f.py", v2)
    assert reconstruct(project["conn"], _reg_uid(project["conn"], s1), s1) == v1


def test_rewind_to_middle_of_chain(project):
    versions = [
        ["v1\n"],
        ["v1\n", "v2\n"],
        ["v1\n", "v2\n", "v3\n"],
        ["v1\n", "v2\n", "v3\n", "v4\n"],
    ]
    ids = [_snap(project, "chain.py", v) for v in versions]
    reg_uid = _reg_uid(project["conn"], ids[0])
    for i, (sid, expected) in enumerate(zip(ids, versions)):
        result = reconstruct(project["conn"], reg_uid, sid)
        assert result == expected, f"Failed at index {i}"


def test_rewind_after_delete_line(project):
    v1 = ["keep\n", "delete-me\n", "keep2\n"]
    v2 = ["keep\n", "keep2\n"]
    s1 = _snap(project, "del.py", v1)
    _snap(project, "del.py", v2)
    assert reconstruct(project["conn"], _reg_uid(project["conn"], s1), s1) == v1


def test_reconstruct_missing_snapshot_raises(project):
    with pytest.raises(ValueError, match="No base snapshot"):
        reconstruct(project["conn"], 999, 999)
