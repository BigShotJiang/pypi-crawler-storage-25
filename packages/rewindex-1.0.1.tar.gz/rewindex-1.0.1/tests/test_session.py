# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

"""Tests for session grouping logic."""

from rewindex.session import group_into_sessions


def _row(id, agent, created_at, filepath="a.py", note=""):
    return {
        "id": id,
        "agent": agent,
        "created_at": created_at,
        "filepath": filepath,
        "note": note,
    }


def test_single_snapshot_is_one_session():
    rows = [_row(1, "Claude Code", "2026-01-01T14:00:00")]
    sessions = group_into_sessions(rows, gap_seconds=20)
    assert len(sessions) == 1
    assert sessions[0]["file_count"] == 1


def test_same_agent_within_gap_is_one_session():
    rows = [
        _row(1, "Claude Code", "2026-01-01T14:00:00", "a.py"),
        _row(2, "Claude Code", "2026-01-01T14:00:05", "b.py"),
        _row(3, "Claude Code", "2026-01-01T14:00:10", "c.py"),
    ]
    sessions = group_into_sessions(rows, gap_seconds=20)
    assert len(sessions) == 1
    assert sessions[0]["file_count"] == 3


def test_same_agent_exceeding_gap_splits_session():
    rows = [
        _row(1, "Claude Code", "2026-01-01T14:00:00", "a.py"),
        _row(2, "Claude Code", "2026-01-01T14:00:30", "b.py"),  # 30s gap > 20s
    ]
    sessions = group_into_sessions(rows, gap_seconds=20)
    assert len(sessions) == 2


def test_different_agent_within_gap_is_one_session():
    rows = [
        _row(1, "Claude Code", "2026-01-01T14:00:00", "a.py"),
        _row(2, "Aider",       "2026-01-01T14:00:05", "b.py"),  # 5s gap — same session
    ]
    sessions = group_into_sessions(rows, gap_seconds=20)
    assert len(sessions) == 1
    assert sessions[0]["file_count"] == 2


def test_sessions_returned_oldest_first():
    rows = [
        _row(1, "Claude Code", "2026-01-01T14:00:00", "a.py"),
        _row(2, "Claude Code", "2026-01-01T14:05:00", "b.py"),
    ]
    sessions = group_into_sessions(rows, gap_seconds=20)
    assert len(sessions) == 2
    assert sessions[0]["snapshots"][0]["id"] == 1  # oldest first
    assert sessions[1]["snapshots"][0]["id"] == 2


def test_duplicate_files_counted_once():
    rows = [
        _row(1, "Claude Code", "2026-01-01T14:00:00", "a.py"),
        _row(2, "Claude Code", "2026-01-01T14:00:05", "a.py"),
        _row(3, "Claude Code", "2026-01-01T14:00:10", "b.py"),
    ]
    sessions = group_into_sessions(rows, gap_seconds=20)
    assert len(sessions) == 1
    assert sessions[0]["file_count"] == 2  # a.py + b.py, not 3


def test_empty_rows_returns_empty():
    assert group_into_sessions([], gap_seconds=20) == []


def test_complex_gap_scenario():
    rows = [
        _row(1, "Claude Code", "2026-01-01T14:00:00", "a.py"),
        _row(2, "Claude Code", "2026-01-01T14:00:05", "b.py"),
        _row(3, "Aider",       "2026-01-01T14:00:10", "c.py"),   # 5s gap — same session
        _row(4, "Aider",       "2026-01-01T14:00:15", "d.py"),
        _row(5, "Claude Code", "2026-01-01T14:01:00", "e.py"),   # 45s gap > 20s → new session
    ]
    sessions = group_into_sessions(rows, gap_seconds=20)
    assert len(sessions) == 2
    assert sessions[0]["file_count"] == 4  # a.py, b.py, c.py, d.py
    assert sessions[1]["file_count"] == 1  # e.py


def test_session_ids_are_sequential():
    rows = [
        _row(1, "Claude Code", "2026-01-01T14:00:00", "a.py"),
        _row(2, "Aider",       "2026-01-01T14:00:05", "b.py"),  # 5s gap → same session
        _row(3, "Claude Code", "2026-01-01T14:01:00", "c.py"),  # 55s gap → new session
    ]
    sessions = group_into_sessions(rows, gap_seconds=20)
    ids = [s["id"] for s in sessions]
    assert ids == [1, 2]  # oldest first, id assigned from oldest
