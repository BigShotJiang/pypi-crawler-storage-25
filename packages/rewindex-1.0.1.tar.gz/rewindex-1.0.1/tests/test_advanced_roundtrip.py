# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

"""
Advanced roundtrip tests:
  - Move project folder (rename on disk), then move back
  - Edit top / middle / bottom of a 100-line file independently
  - Rewind through 5+ versions with edits in different sections
"""

import os
import shutil

import pytest

from rewindex.db.connection import get_connection
from rewindex.db.queries import get_or_create_file_registry
from rewindex.snapshot.engine import snapshot_file
from rewindex.snapshot.reconstruct import reconstruct


# ── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture()
def proj(tmp_path, monkeypatch):
    rewindex_dir = tmp_path / ".rewindex"
    rewindex_dir.mkdir()
    monkeypatch.setattr("rewindex.config.defaults.REWINDEX_DIR", str(rewindex_dir))
    monkeypatch.setattr("rewindex.config.defaults.SNAPSHOTS_DIR", str(rewindex_dir / "snapshots"))

    folder = tmp_path / "project"
    folder.mkdir()
    conn = get_connection("adv")
    return {"name": "adv", "folder": folder, "conn": conn, "tmp": tmp_path}


def _write(folder, filename, lines):
    path = folder / filename
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(lines), encoding="utf-8")
    return str(path)


def _snap(proj, filename, lines):
    path = _write(proj["folder"], filename, lines)
    return snapshot_file(proj["conn"], proj["name"], str(proj["folder"]), path)


def _registry_uid_from_file(conn, file_uid):
    """Get registry_uid from a file version uid."""
    row = conn.execute("SELECT file_registry_uid FROM file WHERE uid = ?", (file_uid,)).fetchone()
    return row["file_registry_uid"]


def _reconstruct(proj, filename, sid):
    reg_uid = _registry_uid_from_file(proj["conn"], sid)
    return reconstruct(proj["conn"], reg_uid, sid)


# ── Move project folder ───────────────────────────────────────────────────────

def test_move_folder_snapshots_still_reconstructable(proj):
    """
    Snapshots are keyed by relative filepath in DB and stored in SNAPSHOTS_DIR
    (not inside the project folder). Moving the project folder does not affect
    the ability to reconstruct from DB.
    """
    lines_v1 = [f"line{i}\n" for i in range(20)]
    sid1 = _snap(proj, "src/main.py", lines_v1)

    lines_v2 = list(lines_v1)
    lines_v2[5] = "# modified line 5\n"
    sid2 = _snap(proj, "src/main.py", lines_v2)

    old_folder = proj["folder"]
    new_folder = proj["tmp"] / "project_moved"
    shutil.move(str(old_folder), str(new_folder))
    proj["folder"] = new_folder

    assert _reconstruct(proj, "src/main.py", sid1) == lines_v1
    assert _reconstruct(proj, "src/main.py", sid2) == lines_v2


def test_move_folder_and_back(proj):
    """Move folder away then move it back — both v1 and v2 reconstruct correctly."""
    lines_v1 = ["original\n"] * 10
    sid1 = _snap(proj, "app.py", lines_v1)

    lines_v2 = list(lines_v1)
    lines_v2[0] = "modified first line\n"
    sid2 = _snap(proj, "app.py", lines_v2)

    original_folder = proj["folder"]
    tmp = proj["tmp"]

    shutil.move(str(original_folder), str(tmp / "temp_location"))
    shutil.move(str(tmp / "temp_location"), str(original_folder))
    proj["folder"] = original_folder

    assert _reconstruct(proj, "app.py", sid1) == lines_v1
    assert _reconstruct(proj, "app.py", sid2) == lines_v2


def test_continue_snapshotting_after_folder_move(proj):
    """After moving folder, new snapshots from the new path reconstruct correctly."""
    lines_v1 = [f"v1 line {i}\n" for i in range(10)]
    sid1 = _snap(proj, "mod.py", lines_v1)

    new_folder = proj["tmp"] / "relocated"
    shutil.move(str(proj["folder"]), str(new_folder))
    proj["folder"] = new_folder

    lines_v2 = list(lines_v1)
    lines_v2[3] = "# edited after move\n"
    path = _write(proj["folder"], "mod.py", lines_v2)
    sid2 = snapshot_file(proj["conn"], proj["name"], str(proj["folder"]), path)

    assert _reconstruct(proj, "mod.py", sid1) == lines_v1
    assert _reconstruct(proj, "mod.py", sid2) == lines_v2


# ── Edit top / middle / bottom of 100-line file ──────────────────────────────

def _make_100_lines():
    return [f"line {i:03d}\n" for i in range(100)]


def test_edit_top_only(proj):
    """Edit lines 0–9 only — bottom 90 lines unchanged."""
    v1 = _make_100_lines()
    sid1 = _snap(proj, "big.py", v1)

    v2 = list(v1)
    for i in range(10):
        v2[i] = f"TOP EDIT {i}\n"
    sid2 = _snap(proj, "big.py", v2)

    assert _reconstruct(proj, "big.py", sid1) == v1
    assert _reconstruct(proj, "big.py", sid2) == v2
    assert _reconstruct(proj, "big.py", sid2)[50] == v1[50]
    assert _reconstruct(proj, "big.py", sid2)[99] == v1[99]


def test_edit_middle_only(proj):
    """Edit lines 45–54 only — top and bottom unchanged."""
    v1 = _make_100_lines()
    sid1 = _snap(proj, "big.py", v1)

    v2 = list(v1)
    for i in range(45, 55):
        v2[i] = f"MIDDLE EDIT {i}\n"
    sid2 = _snap(proj, "big.py", v2)

    assert _reconstruct(proj, "big.py", sid1) == v1
    assert _reconstruct(proj, "big.py", sid2) == v2
    assert _reconstruct(proj, "big.py", sid2)[0] == v1[0]
    assert _reconstruct(proj, "big.py", sid2)[99] == v1[99]


def test_edit_bottom_only(proj):
    """Edit lines 90–99 only — top 90 lines unchanged."""
    v1 = _make_100_lines()
    sid1 = _snap(proj, "big.py", v1)

    v2 = list(v1)
    for i in range(90, 100):
        v2[i] = f"BOTTOM EDIT {i}\n"
    sid2 = _snap(proj, "big.py", v2)

    assert _reconstruct(proj, "big.py", sid1) == v1
    assert _reconstruct(proj, "big.py", sid2) == v2
    assert _reconstruct(proj, "big.py", sid2)[0] == v1[0]
    assert _reconstruct(proj, "big.py", sid2)[49] == v1[49]


def test_sequential_edits_top_middle_bottom(proj):
    """Three sequential snapshots each editing a different section."""
    v1 = _make_100_lines()
    sid1 = _snap(proj, "seq.py", v1)

    v2 = list(v1)
    v2[5] = "EDIT TOP\n"
    sid2 = _snap(proj, "seq.py", v2)

    v3 = list(v2)
    v3[50] = "EDIT MIDDLE\n"
    sid3 = _snap(proj, "seq.py", v3)

    v4 = list(v3)
    v4[95] = "EDIT BOTTOM\n"
    sid4 = _snap(proj, "seq.py", v4)

    assert _reconstruct(proj, "seq.py", sid1) == v1
    assert _reconstruct(proj, "seq.py", sid2) == v2
    assert _reconstruct(proj, "seq.py", sid3) == v3
    assert _reconstruct(proj, "seq.py", sid4) == v4


# ── Rewind through 5+ versions with edits in different sections ──────────────

def test_rewind_5_versions_different_sections(proj):
    """
    5 snapshots each touching a different part of the file.
    Reconstruct every version in both forward and reverse order.
    """
    base = _make_100_lines()

    versions = [list(base)]
    edits = [
        (2,  "# v2: top section change\n"),
        (50, "# v3: middle section change\n"),
        (90, "# v4: bottom section change\n"),
        (25, "# v5: upper-middle change\n"),
        (75, "# v6: lower-middle change\n"),
    ]

    sid = _snap(proj, "rewind.py", base)
    snap_ids = [sid]

    for line_no, new_content in edits:
        v = list(versions[-1])
        v[line_no] = new_content
        versions.append(v)
        snap_ids.append(_snap(proj, "rewind.py", v))

    for i, (sid, expected) in enumerate(zip(snap_ids, versions)):
        result = _reconstruct(proj, "rewind.py", sid)
        assert result == expected, f"Forward check failed at version {i + 1}"

    for i in reversed(range(len(snap_ids))):
        result = _reconstruct(proj, "rewind.py", snap_ids[i])
        assert result == versions[i], f"Reverse check failed at version {i + 1}"


def test_rewind_interleaved_multifile(proj):
    """
    Two files snapshotted alternately. Rewinding file A to any version
    must not be contaminated by file B's history.
    """
    lines_a = [f"A line {i}\n" for i in range(50)]
    lines_b = [f"B line {i}\n" for i in range(50)]

    sid_a = [_snap(proj, "a.py", lines_a)]
    sid_b = [_snap(proj, "b.py", lines_b)]

    versions_a = [list(lines_a)]
    versions_b = [list(lines_b)]

    for step in range(4):
        lines_a = list(lines_a)
        lines_a[step * 10] = f"A edit step {step}\n"
        versions_a.append(list(lines_a))
        sid_a.append(_snap(proj, "a.py", lines_a))

        lines_b = list(lines_b)
        lines_b[step * 10 + 5] = f"B edit step {step}\n"
        versions_b.append(list(lines_b))
        sid_b.append(_snap(proj, "b.py", lines_b))

    for i, (sid, expected) in enumerate(zip(sid_a, versions_a)):
        assert _reconstruct(proj, "a.py", sid) == expected, f"File A version {i} wrong"
    for i, (sid, expected) in enumerate(zip(sid_b, versions_b)):
        assert _reconstruct(proj, "b.py", sid) == expected, f"File B version {i} wrong"


def test_rewind_add_and_remove_lines(proj):
    """
    Mix of line additions and deletions across versions — verifies diff chain
    reconstructs correctly even when line count changes at each step.
    """
    v = [f"line {i}\n" for i in range(20)]
    versions = [list(v)]
    sid = _snap(proj, "mut.py", v)
    snap_ids = [sid]

    # v2: add 5 lines at top
    v = ["# NEW TOP\n"] * 5 + v
    versions.append(list(v)); snap_ids.append(_snap(proj, "mut.py", v))

    # v3: delete 3 lines from middle
    del v[10:13]
    versions.append(list(v)); snap_ids.append(_snap(proj, "mut.py", v))

    # v4: replace last 2 lines
    v[-2] = "# REPLACED -2\n"
    v[-1] = "# REPLACED -1\n"
    versions.append(list(v)); snap_ids.append(_snap(proj, "mut.py", v))

    # v5: add 10 lines at bottom
    v += [f"# APPENDED {i}\n" for i in range(10)]
    versions.append(list(v)); snap_ids.append(_snap(proj, "mut.py", v))

    for i, (sid, expected) in enumerate(zip(snap_ids, versions)):
        result = _reconstruct(proj, "mut.py", sid)
        assert result == expected, (
            f"Version {i + 1}: expected {len(expected)} lines, got {len(result)}\n"
            f"First diff at: {next((j for j in range(min(len(result),len(expected))) if result[j] != expected[j]), 'end')}"
        )
