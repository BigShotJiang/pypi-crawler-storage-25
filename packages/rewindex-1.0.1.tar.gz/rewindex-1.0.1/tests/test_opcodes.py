# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import pytest
from rewindex.snapshot.opcodes import apply, generate


def roundtrip(old: list[str], new: list[str]) -> None:
    ops = generate(old, new)
    result = apply(old, ops)
    assert result == new, f"Roundtrip failed.\nExpected: {new}\nGot: {result}"


def test_no_change():
    lines = ["a\n", "b\n", "c\n"]
    roundtrip(lines, lines)


def test_append_line():
    old = ["a\n", "b\n"]
    new = ["a\n", "b\n", "c\n"]
    roundtrip(old, new)


def test_insert_middle():
    old = ["a\n", "c\n"]
    new = ["a\n", "b\n", "c\n"]
    roundtrip(old, new)


def test_delete_line():
    old = ["a\n", "b\n", "c\n"]
    new = ["a\n", "c\n"]
    roundtrip(old, new)


def test_replace_line():
    old = ["a\n", "b\n", "c\n"]
    new = ["a\n", "X\n", "c\n"]
    roundtrip(old, new)


def test_empty_to_content():
    old = []
    new = ["hello\n", "world\n"]
    roundtrip(old, new)


def test_content_to_empty():
    old = ["hello\n", "world\n"]
    new = []
    roundtrip(old, new)


def test_large_insert_middle():
    old = [f"line{i}\n" for i in range(100)]
    new = old[:50] + ["inserted\n"] + old[50:]
    roundtrip(old, new)
    # Verify the diff is small — only 1 insert op + 2 eq ops
    ops = generate(old, new)
    assert len(ops) <= 3


def test_generate_op_types():
    old = ["a\n", "b\n", "c\n"]
    new = ["a\n", "X\n", "c\n"]
    ops = generate(old, new)
    tags = [op[0] for op in ops]
    assert "rep" in tags
    assert "del" not in tags
