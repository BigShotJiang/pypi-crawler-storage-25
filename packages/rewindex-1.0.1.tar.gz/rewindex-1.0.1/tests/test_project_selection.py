# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

"""
Tests for project selection helpers:
  - _detect_project_from_cwd
  - resolve_project
  - `rewindex project` (no subcommand) → list
"""

import os

import pytest
from click.testing import CliRunner
from unittest.mock import patch

from rewindex.commands._project import _detect_project_from_cwd, resolve_project


# ── _detect_project_from_cwd ──────────────────────────────────────────────────

def test_detect_exact_match(tmp_path):
    """CWD == project folder → detected."""
    folder = str(tmp_path / "my-app")
    os.makedirs(folder)
    projects = [{"name": "my-app", "folders": [folder]}]

    with patch("rewindex.commands._project.os.getcwd", return_value=folder):
        assert _detect_project_from_cwd(projects) == "my-app"


def test_detect_subdir_match(tmp_path):
    """CWD is a subdirectory of a project folder → detected."""
    folder = str(tmp_path / "my-app")
    subdir = str(tmp_path / "my-app" / "src" / "utils")
    os.makedirs(subdir)
    projects = [{"name": "my-app", "folders": [folder]}]

    with patch("rewindex.commands._project.os.getcwd", return_value=subdir):
        assert _detect_project_from_cwd(projects) == "my-app"


def test_detect_no_match(tmp_path):
    """CWD outside all project folders → None."""
    folder = str(tmp_path / "my-app")
    other = str(tmp_path / "other-dir")
    os.makedirs(folder)
    os.makedirs(other)
    projects = [{"name": "my-app", "folders": [folder]}]

    with patch("rewindex.commands._project.os.getcwd", return_value=other):
        assert _detect_project_from_cwd(projects) is None


def test_detect_prefix_false_positive(tmp_path):
    """CWD that starts with folder path as prefix but is NOT a subdir → no match."""
    # e.g. folder = /tmp/app, cwd = /tmp/app-copy — should NOT match
    folder = str(tmp_path / "app")
    not_subdir = str(tmp_path / "app-copy")
    os.makedirs(folder)
    os.makedirs(not_subdir)
    projects = [{"name": "app", "folders": [folder]}]

    with patch("rewindex.commands._project.os.getcwd", return_value=not_subdir):
        assert _detect_project_from_cwd(projects) is None


def test_detect_multiple_projects_picks_correct(tmp_path):
    """With multiple projects, only the matching one is returned."""
    folder_a = str(tmp_path / "proj-a")
    folder_b = str(tmp_path / "proj-b")
    os.makedirs(folder_a)
    os.makedirs(folder_b)
    projects = [
        {"name": "proj-a", "folders": [folder_a]},
        {"name": "proj-b", "folders": [folder_b]},
    ]

    with patch("rewindex.commands._project.os.getcwd", return_value=folder_b):
        assert _detect_project_from_cwd(projects) == "proj-b"


def test_detect_multi_folder_project(tmp_path):
    """Project with multiple folders → detected from any of them."""
    folder_1 = str(tmp_path / "folder-1")
    folder_2 = str(tmp_path / "folder-2")
    os.makedirs(folder_1)
    os.makedirs(folder_2)
    projects = [{"name": "big-app", "folders": [folder_1, folder_2]}]

    with patch("rewindex.commands._project.os.getcwd", return_value=folder_2):
        assert _detect_project_from_cwd(projects) == "big-app"


# ── resolve_project ───────────────────────────────────────────────────────────

def _projects(tmp_path):
    names = ["alpha", "beta", "gamma"]
    result = []
    for n in names:
        f = str(tmp_path / n)
        os.makedirs(f, exist_ok=True)
        result.append({"name": n, "folders": [f]})
    return result


def test_resolve_by_name_found(tmp_path):
    projects = _projects(tmp_path)
    assert resolve_project(projects, "beta") == "beta"


def test_resolve_by_name_not_found(tmp_path):
    projects = _projects(tmp_path)
    result = resolve_project(projects, "nonexistent")
    assert result is None


def test_resolve_cwd_detected(tmp_path):
    """No name given, CWD inside project folder → auto-detected."""
    projects = _projects(tmp_path)
    folder = str(tmp_path / "alpha")

    with patch("rewindex.commands._project.os.getcwd", return_value=folder):
        assert resolve_project(projects, None) == "alpha"


def test_resolve_single_project_no_cwd(tmp_path, capsys):
    """Single project, CWD outside project → auto-selects the only project."""
    folder = str(tmp_path / "solo")
    os.makedirs(folder)
    projects = [{"name": "solo", "folders": [folder]}]

    outside = str(tmp_path / "elsewhere")
    os.makedirs(outside)

    with patch("rewindex.commands._project.os.getcwd", return_value=outside):
        result = resolve_project(projects, None)
    assert result == "solo"


def test_resolve_multi_project_no_cwd(tmp_path):
    """Multiple projects, no CWD match → shows hint and returns None."""
    projects = _projects(tmp_path)
    outside = str(tmp_path / "elsewhere")
    os.makedirs(outside)

    with patch("rewindex.commands._project.os.getcwd", return_value=outside):
        result = resolve_project(projects, None)
    assert result is None


def test_resolve_multi_project_non_interactive(tmp_path):
    """Multiple projects, no CWD match, interactive=False → returns None."""
    projects = _projects(tmp_path)
    outside = str(tmp_path / "elsewhere")
    os.makedirs(outside)

    with patch("rewindex.commands._project.os.getcwd", return_value=outside):
        result = resolve_project(projects, None, interactive=False)
    assert result is None


def test_resolve_multi_project_picker(tmp_path):
    """Multiple projects, no CWD match → returns None (picker removed)."""
    projects = _projects(tmp_path)
    outside = str(tmp_path / "elsewhere")
    os.makedirs(outside)

    with patch("rewindex.commands._project.os.getcwd", return_value=outside):
        result = resolve_project(projects, None, interactive=True)

    assert result is None


def test_resolve_picker_cancelled(tmp_path):
    """CWD outside all projects → None returned."""
    projects = _projects(tmp_path)
    outside = str(tmp_path / "elsewhere")
    os.makedirs(outside)

    with patch("rewindex.commands._project.os.getcwd", return_value=outside):
        result = resolve_project(projects, None)

    assert result is None


# ── `rewindex project` (no subcommand) → list ────────────────────────────────

def test_project_list_single_folder(tmp_path, monkeypatch):
    """project with no subcommand lists projects with single folder."""
    import rewindex.config.loader as cl
    config_path = tmp_path / "config.yaml"
    config_path.write_text(f"""
projects:
  - name: my-app
    folders:
      - {tmp_path / "my-app"}
""")
    monkeypatch.setattr(cl, "CONFIG_PATH", str(config_path))

    from rewindex.commands.project import project_cmd
    runner = CliRunner()
    result = runner.invoke(project_cmd, [])

    assert result.exit_code == 0
    assert "my-app" in result.output


def test_project_list_multi_folder(tmp_path, monkeypatch):
    """project with no subcommand shows both folders for multi-folder project."""
    import rewindex.config.loader as cl
    folder_1 = tmp_path / "folder-1"
    folder_2 = tmp_path / "folder-2"
    config_path = tmp_path / "config.yaml"
    config_path.write_text(f"""
projects:
  - name: big-app
    folders:
      - {folder_1}
      - {folder_2}
""")
    monkeypatch.setattr(cl, "CONFIG_PATH", str(config_path))

    from rewindex.commands.project import project_cmd
    runner = CliRunner()
    result = runner.invoke(project_cmd, [])

    assert result.exit_code == 0
    assert "big-app" in result.output
    assert str(folder_1) in result.output


def test_project_list_empty(tmp_path, monkeypatch):
    """project with no subcommand shows 'No projects' when none configured."""
    import rewindex.config.loader as cl
    config_path = tmp_path / "config.yaml"
    config_path.write_text("projects: []\n")
    monkeypatch.setattr(cl, "CONFIG_PATH", str(config_path))

    from rewindex.commands.project import project_cmd
    runner = CliRunner()
    result = runner.invoke(project_cmd, [])

    assert result.exit_code == 0
    assert "no projects" in result.output.lower()
