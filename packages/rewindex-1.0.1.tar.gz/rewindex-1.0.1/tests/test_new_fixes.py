# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

"""
Tests for A5, A6, A16, §5.2 fixes.
"""

import gzip
import json
import os
import tempfile
import threading
import time

import pytest

from rewindex.config.defaults import (
    MAX_CONFIG_FILE_BYTES,
    MAX_GZIP_READ_BYTES,
    MAX_PENDING_EVENTS,
)


# ── A5: YAML bomb ─────────────────────────────────────────────────────────────

def test_yaml_bomb_rejected(tmp_path, monkeypatch):
    """Config file > MAX_CONFIG_FILE_BYTES falls back to defaults, not OOM."""
    from rewindex.config import defaults as d
    config_path = tmp_path / "config.yaml"
    # Write a file just over the limit
    config_path.write_bytes(b"x: y\n" * ((MAX_CONFIG_FILE_BYTES // 5) + 1))

    monkeypatch.setattr(d, "CONFIG_PATH", str(config_path))
    monkeypatch.setattr(d, "CONFIG_BACKUP_PATH", str(tmp_path / "backup.yaml"))

    from rewindex.config import loader
    monkeypatch.setattr(loader, "CONFIG_PATH", str(config_path))
    monkeypatch.setattr(loader, "CONFIG_BACKUP_PATH", str(tmp_path / "backup.yaml"))

    config = loader.load_config()
    assert config["projects"] == []  # fell back to defaults


def test_yaml_normal_size_loads(tmp_path, monkeypatch):
    """Config file within limit loads normally."""
    import yaml
    from rewindex.config import defaults as d, loader

    config_path = tmp_path / "config.yaml"
    data = {"projects": [{"name": "p", "folders": ["/tmp/x"]}], "global_exclude": []}
    config_path.write_text(yaml.dump(data))

    monkeypatch.setattr(d, "CONFIG_PATH", str(config_path))
    monkeypatch.setattr(d, "CONFIG_BACKUP_PATH", str(tmp_path / "backup.yaml"))
    monkeypatch.setattr(loader, "CONFIG_PATH", str(config_path))
    monkeypatch.setattr(loader, "CONFIG_BACKUP_PATH", str(tmp_path / "backup.yaml"))

    config = loader.load_config()
    assert config["projects"][0]["name"] == "p"


# ── A6: Gzip bomb ─────────────────────────────────────────────────────────────

def test_gzip_bomb_rejected(tmp_path):
    """Gzip file decompressing beyond MAX_GZIP_READ_BYTES raises ValueError."""
    from rewindex.snapshot.storage import read_full

    bomb_path = tmp_path / "bomb.full.gz"
    # Write gzip content larger than limit
    big_content = b"A" * (MAX_GZIP_READ_BYTES + 1024)
    with gzip.open(str(bomb_path), "wb") as f:
        f.write(big_content)

    with pytest.raises(ValueError, match="exceeds"):
        read_full(str(bomb_path))


def test_gzip_normal_size_reads(tmp_path):
    """Normal gzip file reads fine."""
    from rewindex.snapshot.storage import read_full

    normal_path = tmp_path / "normal.full.gz"
    content = "line 1\nline 2\nline 3\n"
    with gzip.open(str(normal_path), "wb") as f:
        f.write(content.encode("utf-8"))

    lines = read_full(str(normal_path))
    assert lines == ["line 1\n", "line 2\n", "line 3\n"]


def test_gzip_diff_bomb_rejected(tmp_path):
    """Gzip diff file decompressing beyond limit raises ValueError."""
    from rewindex.snapshot.storage import read_diff

    bomb_path = tmp_path / "bomb.diff.gz"
    big_ops = [["eq", 0, i] for i in range(1000000)]
    payload = json.dumps({"v": 1, "ops": big_ops}).encode("utf-8")
    # Pad to exceed limit
    big_content = payload + b" " * (MAX_GZIP_READ_BYTES + 1024)
    with gzip.open(str(bomb_path), "wb") as f:
        f.write(big_content)

    with pytest.raises(ValueError, match="exceeds"):
        read_diff(str(bomb_path))


# ── A16: Event flood / _pending cap ───────────────────────────────────────────

def test_pending_cap_drops_oldest(tmp_path):
    """_pending dict drops oldest entry when cap is reached."""
    from unittest.mock import MagicMock
    from rewindex.daemon.watcher import _SnapshotHandler

    handler = _SnapshotHandler(
        project_name="test",
        project_folder=str(tmp_path),
        exclude=[],
        debounce_seconds=999,
    )
    handler._worker = MagicMock()

    for i in range(MAX_PENDING_EVENTS):
        path = str(tmp_path / f"file{i}.py")
        open(path, "w").close()
        with handler._lock:
            handler._pending[path] = float(i)

    assert len(handler._pending) == MAX_PENDING_EVENTS

    new_file = str(tmp_path / "new_file.py")
    open(new_file, "w").close()
    oldest = str(tmp_path / "file0.py")

    handler._schedule(new_file)

    assert len(handler._pending) == MAX_PENDING_EVENTS
    assert oldest not in handler._pending
    assert new_file in handler._pending


def test_pending_update_existing_no_drop(tmp_path):
    """Updating an existing path in _pending does not drop anything."""
    from unittest.mock import MagicMock
    from rewindex.daemon.watcher import _SnapshotHandler

    handler = _SnapshotHandler(
        project_name="test",
        project_folder=str(tmp_path),
        exclude=[],
        debounce_seconds=999,
    )
    handler._worker = MagicMock()

    existing = str(tmp_path / "existing.py")
    open(existing, "w").close()
    with handler._lock:
        handler._pending[existing] = 1.0

    for i in range(MAX_PENDING_EVENTS - 1):
        path = str(tmp_path / f"file{i}.py")
        open(path, "w").close()
        with handler._lock:
            handler._pending[path] = float(i + 2)

    assert len(handler._pending) == MAX_PENDING_EVENTS

    handler._schedule(existing)
    assert len(handler._pending) == MAX_PENDING_EVENTS
    assert existing in handler._pending


# ── §5.2: folders migration cleanup ───────────────────────────────────────────

def test_legacy_folder_key_removed_after_migrate(tmp_path, monkeypatch):
    """Legacy 'folder' key is always removed after migration."""
    import yaml
    from rewindex.config import defaults as d, loader

    config_path = tmp_path / "config.yaml"
    # Config with legacy 'folder' key
    data = {
        "projects": [{"name": "p", "folder": "/tmp/x"}],
        "global_exclude": [],
    }
    config_path.write_text(yaml.dump(data))

    monkeypatch.setattr(d, "CONFIG_PATH", str(config_path))
    monkeypatch.setattr(d, "CONFIG_BACKUP_PATH", str(tmp_path / "backup.yaml"))
    monkeypatch.setattr(loader, "CONFIG_PATH", str(config_path))
    monkeypatch.setattr(loader, "CONFIG_BACKUP_PATH", str(tmp_path / "backup.yaml"))

    config = loader.load_config()
    project = config["projects"][0]
    assert "folder" not in project
    assert project["folders"] == ["/tmp/x"]


def test_both_folder_and_folders_legacy_key_removed(tmp_path, monkeypatch):
    """If both 'folder' and 'folders' exist, 'folder' is removed."""
    import yaml
    from rewindex.config import defaults as d, loader

    config_path = tmp_path / "config.yaml"
    data = {
        "projects": [{"name": "p", "folder": "/tmp/old", "folders": ["/tmp/new"]}],
        "global_exclude": [],
    }
    config_path.write_text(yaml.dump(data))

    monkeypatch.setattr(d, "CONFIG_PATH", str(config_path))
    monkeypatch.setattr(d, "CONFIG_BACKUP_PATH", str(tmp_path / "backup.yaml"))
    monkeypatch.setattr(loader, "CONFIG_PATH", str(config_path))
    monkeypatch.setattr(loader, "CONFIG_BACKUP_PATH", str(tmp_path / "backup.yaml"))

    config = loader.load_config()
    project = config["projects"][0]
    assert "folder" not in project
    assert project["folders"] == ["/tmp/new"]
