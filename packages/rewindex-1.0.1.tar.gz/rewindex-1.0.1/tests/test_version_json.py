# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import json
import os

import pytest

import rewindex.version as version_module


@pytest.fixture(autouse=True)
def isolated_rewindex_json(tmp_path, monkeypatch):
    json_path = str(tmp_path / "rewindex.json")
    monkeypatch.setattr(version_module, "REWINDEX_JSON_PATH", json_path)
    return json_path


def _write_json(path, data):
    with open(path, "w") as f:
        json.dump(data, f)


def _read_json(path):
    with open(path) as f:
        return json.load(f)


# --- fresh install ---

def test_creates_file_when_missing(isolated_rewindex_json):
    version_module.init_rewindex_json()
    assert os.path.exists(isolated_rewindex_json)
    data = _read_json(isolated_rewindex_json)
    assert data["rewindex_version"] == version_module._DEFAULT["rewindex_version"]
    assert data["skill_version"] == version_module._DEFAULT["skill_version"]
    assert data["readme_version"] == version_module._DEFAULT["readme_version"]
    assert "plugins" not in data


# --- upgrade from old version with plugins field ---

def test_removes_legacy_plugins_on_upgrade(isolated_rewindex_json):
    _write_json(isolated_rewindex_json, {
        "rewindex_version": "0.1.4",
        "skill_version": "0.1.4",
        "config_schema": "1.0.0",
        "plugins": {
            "claude_code": "0.1.4",
            "cursor": "0.1.4",
        },
    })
    version_module.init_rewindex_json()
    data = _read_json(isolated_rewindex_json)
    assert "plugins" not in data


def test_updates_version_on_upgrade(isolated_rewindex_json):
    _write_json(isolated_rewindex_json, {
        "rewindex_version": "0.1.0",
        "skill_version": "0.1.0",
        "config_schema": "1.0.0",
    })
    version_module.init_rewindex_json()
    data = _read_json(isolated_rewindex_json)
    assert data["rewindex_version"] == version_module._DEFAULT["rewindex_version"]


def test_adds_missing_fields_on_upgrade(isolated_rewindex_json):
    _write_json(isolated_rewindex_json, {
        "rewindex_version": "0.1.5",
        "skill_version": "0.1.5",
        "config_schema": "1.0.0",
        # readme_version missing
    })
    version_module.init_rewindex_json()
    data = _read_json(isolated_rewindex_json)
    assert "readme_version" in data


# --- corrupted file ---

def test_recreates_file_when_corrupted(isolated_rewindex_json):
    with open(isolated_rewindex_json, "w") as f:
        f.write("not valid json {{{{")
    version_module.init_rewindex_json()
    data = _read_json(isolated_rewindex_json)
    assert data["rewindex_version"] == version_module._DEFAULT["rewindex_version"]
    assert "plugins" not in data


# --- no-op when already up to date ---

def test_no_write_when_already_current(isolated_rewindex_json):
    version_module.init_rewindex_json()
    mtime_after_init = os.path.getmtime(isolated_rewindex_json)

    version_module.init_rewindex_json()
    mtime_after_second = os.path.getmtime(isolated_rewindex_json)

    assert mtime_after_init == mtime_after_second
