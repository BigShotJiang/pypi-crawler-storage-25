# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

"""Tests for v2 orphan sweep (daemon/maintenance) and trash cleanup."""

import os
import shutil
import sqlite3

import pytest
from click.testing import CliRunner


@pytest.fixture()
def env(tmp_path, monkeypatch):
    snapshots_dir = tmp_path / "snapshots"
    snapshots_dir.mkdir()
    trash_dir = tmp_path / "trash"
    trash_dir.mkdir()
    monkeypatch.setattr("rewindex.config.defaults.SNAPSHOTS_DIR", str(snapshots_dir))
    monkeypatch.setattr("rewindex.config.defaults.TRASH_DIR", str(trash_dir))
    return {"snapshots_dir": snapshots_dir, "trash_dir": trash_dir, "tmp": tmp_path}


# ── _orphan_sweep: removes files with no DB record ──────────────────────────

def test_orphan_sweep_removes_unreferenced_files(env, monkeypatch):
    """_orphan_sweep deletes snapshot files not referenced in the DB."""
    import rewindex.daemon.maintenance as maint

    monkeypatch.setattr(maint, "_last_orphan_sweep", 0.0)
    monkeypatch.setattr(maint, "SNAPSHOTS_DIR", str(env["snapshots_dir"]))

    proj_dir = env["snapshots_dir"] / "myproj"
    proj_dir.mkdir()
    snap_subdir = proj_dir / "snapshots"
    snap_subdir.mkdir()

    orphan = snap_subdir / "orphan.full.gz"
    orphan.write_bytes(b"x" * 100)

    db_path = proj_dir / "rewindex.db"
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    conn.execute("CREATE TABLE file (uid INTEGER PRIMARY KEY, storage_path TEXT)")
    conn.execute("CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT)")
    conn.commit()
    conn.close()

    from unittest.mock import patch
    with patch("rewindex.db.connection.get_connection", side_effect=lambda name: _simple_conn(str(db_path))):
        config = {"projects": [{"name": "myproj", "folders": ["/tmp"]}]}
        maint._orphan_sweep(config)

    assert not orphan.exists(), "Orphan file should be removed"


def test_orphan_sweep_keeps_referenced_files(env, monkeypatch):
    """_orphan_sweep keeps files that are referenced in the DB."""
    import rewindex.daemon.maintenance as maint

    monkeypatch.setattr(maint, "_last_orphan_sweep", 0.0)
    monkeypatch.setattr(maint, "SNAPSHOTS_DIR", str(env["snapshots_dir"]))

    proj_dir = env["snapshots_dir"] / "myproj"
    proj_dir.mkdir()
    snap_subdir = proj_dir / "snapshots"
    snap_subdir.mkdir()

    kept = snap_subdir / "valid.full.gz"
    kept.write_bytes(b"x" * 100)

    db_path = proj_dir / "rewindex.db"
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    conn.execute("CREATE TABLE file (uid INTEGER PRIMARY KEY, storage_path TEXT)")
    conn.execute("CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT)")
    conn.execute("INSERT INTO file VALUES (1, ?)", (str(kept.resolve()),))
    conn.commit()
    conn.close()

    from unittest.mock import patch
    with patch("rewindex.db.connection.get_connection", side_effect=lambda name: _simple_conn(str(db_path))):
        config = {"projects": [{"name": "myproj", "folders": ["/tmp"]}]}
        maint._orphan_sweep(config)

    assert kept.exists(), "Referenced file should be kept"


# ── cleanup --trash ─────────────────────────────────────────────────────────

def test_cleanup_trash_empty(env, monkeypatch):
    monkeypatch.setattr("rewindex.commands.cleanup.load_config", lambda: {"projects": []})
    monkeypatch.setattr("rewindex.commands.cleanup.TRASH_DIR", str(env["trash_dir"]))

    from rewindex.commands.cleanup import cleanup_cmd
    runner = CliRunner()
    result = runner.invoke(cleanup_cmd, ["--trash"])

    assert result.exit_code == 0
    assert "empty" in result.output.lower()


def test_cleanup_trash_lists_items(env, monkeypatch):
    trashed = env["trash_dir"] / "old-project"
    trashed.mkdir()
    (trashed / "snap.gz").write_bytes(b"x" * 1024)

    monkeypatch.setattr("rewindex.commands.cleanup.load_config", lambda: {"projects": []})
    monkeypatch.setattr("rewindex.commands.cleanup.TRASH_DIR", str(env["trash_dir"]))

    from rewindex.commands.cleanup import cleanup_cmd
    runner = CliRunner()
    result = runner.invoke(cleanup_cmd, ["--trash"])

    assert result.exit_code == 0
    assert "old-project" in result.output


def test_cleanup_trash_yes_deletes(env, monkeypatch):
    trashed = env["trash_dir"] / "old-project"
    trashed.mkdir()
    (trashed / "snap.gz").write_bytes(b"x" * 1024)

    monkeypatch.setattr("rewindex.commands.cleanup.load_config", lambda: {"projects": []})
    monkeypatch.setattr("rewindex.commands.cleanup.TRASH_DIR", str(env["trash_dir"]))

    from rewindex.commands.cleanup import cleanup_cmd
    runner = CliRunner()
    result = runner.invoke(cleanup_cmd, ["--trash", "--yes"])

    assert result.exit_code == 0
    assert not trashed.exists(), "Trashed project should be deleted"


# ── status command (v2: no orphan warnings, just project info) ──────────────

def test_status_shows_project_info(env, monkeypatch):
    monkeypatch.setattr("rewindex.commands.status.load_config", lambda: {
        "projects": [{"name": "myproject", "folders": ["/some/folder"]}]
    })
    monkeypatch.setattr("rewindex.commands.status.is_running", lambda: True)
    monkeypatch.setattr("rewindex.commands.status.read_pid", lambda: 12345)

    proj_dir = env["snapshots_dir"] / "myproject"
    proj_dir.mkdir()
    monkeypatch.setattr(
        "rewindex.db.connection.get_db_path",
        lambda name: str(proj_dir / "rewindex.db"),
    )
    from rewindex.db.connection import get_connection
    conn = get_connection("myproject")
    conn.close()

    from rewindex.commands.status import status_cmd
    runner = CliRunner()
    result = runner.invoke(status_cmd)

    assert result.exit_code == 0
    assert "myproject" in result.output


def _simple_conn(db_path):
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn
