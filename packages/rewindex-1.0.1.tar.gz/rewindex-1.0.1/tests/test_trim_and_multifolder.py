# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

"""
Tests for:
  1. Trim with small limits (10–15 sessions) + fullbase creation during trim
  2. Multi-folder project management (up to 5 folders)
"""

import os
import sqlite3

import pytest
from click.testing import CliRunner
from unittest.mock import patch

from rewindex.db.connection import get_connection
from rewindex.db.queries import (
    get_or_create_file_registry,
    get_or_create_session,
    get_all_tracked_files,
    get_session_count,
    get_file_versions_since,
    get_full_base_for_file,
    create_forced_session,
)
from rewindex.snapshot.engine import snapshot_file
from rewindex.snapshot.reconstruct import reconstruct


# ══════════════════════════════════════════════════════════════════════════════
# 1. Trim with small limits
# ══════════════════════════════════════════════════════════════════════════════

@pytest.fixture()
def trim_env(tmp_path, monkeypatch):
    rewindex_dir = tmp_path / ".rewindex"
    rewindex_dir.mkdir()
    snaps = rewindex_dir / "snapshots"
    snaps.mkdir()
    monkeypatch.setattr("rewindex.config.defaults.REWINDEX_DIR", str(rewindex_dir))
    monkeypatch.setattr("rewindex.config.defaults.SNAPSHOTS_DIR", str(snaps))

    folder = tmp_path / "project"
    folder.mkdir()
    conn = get_connection("trimtest")
    return {"conn": conn, "folder": folder, "name": "trimtest", "tmp": tmp_path}


def _snap_with_session(env, filename, content, session_uid):
    """Write file and snapshot it into a specific session."""
    abs_path = env["folder"] / filename
    abs_path.parent.mkdir(parents=True, exist_ok=True)
    abs_path.write_text(content)
    return snapshot_file(
        env["conn"], env["name"], str(env["folder"]), str(abs_path),
        session_uid=session_uid,
    )


def _snap_auto(env, filename, content):
    abs_path = env["folder"] / filename
    abs_path.parent.mkdir(parents=True, exist_ok=True)
    abs_path.write_text(content)
    return snapshot_file(env["conn"], env["name"], str(env["folder"]), str(abs_path))


def test_trim_reduces_session_count(trim_env, monkeypatch):
    """With max=12, safe=5, trim should cut oldest sessions when count hits max."""
    from rewindex.snapshot.trim import _run_trim

    env = trim_env
    conn = env["conn"]
    project = env["name"]

    file_uids = []
    for i in range(15):
        ts = f"2026-01-{i+1:02d}T00:00:00+00:00"
        session_uid = create_forced_session(conn, project, ts)
        uid = _snap_with_session(env, "code.py", f"version {i+1}\n" * 10, session_uid)
        file_uids.append(uid)

    assert get_session_count(conn, project) == 15

    _run_trim(conn, project, cut=8)

    remaining = get_session_count(conn, project)
    assert remaining <= 15 - 8 + 1


def test_trim_creates_fullbase_for_first_kept(trim_env, monkeypatch):
    """After trim, the first kept version should be a fullbase."""
    from rewindex.snapshot.trim import _run_trim

    env = trim_env
    conn = env["conn"]
    project = env["name"]

    for i in range(12):
        ts = f"2026-01-{i+1:02d}T00:00:00+00:00"
        session_uid = create_forced_session(conn, project, ts)
        _snap_with_session(env, "data.py", f"line {i}\nstatic\n" * 5, session_uid)

    _run_trim(conn, project, cut=7)

    tracked = get_all_tracked_files(conn, project)
    for reg in tracked:
        base = get_full_base_for_file(conn, reg["uid"])
        assert base is not None, f"File {reg['filepath']} has no fullbase after trim"
        assert base["is_full"] == 1
        assert base["promoted_by"] == "trim", "Fullbase created by trim should have promoted_by='trim'"


def test_trim_preserves_reconstructability(trim_env, monkeypatch):
    """After trim, all remaining versions must still reconstruct correctly."""
    from rewindex.snapshot.trim import _run_trim

    env = trim_env
    conn = env["conn"]
    project = env["name"]

    versions = {}
    for i in range(12):
        ts = f"2026-01-{i+1:02d}T00:00:00+00:00"
        session_uid = create_forced_session(conn, project, ts)
        content = f"v{i+1}\n" + f"line {i}\n" * 5
        uid = _snap_with_session(env, "app.py", content, session_uid)
        versions[uid] = content.splitlines(keepends=True)

    _run_trim(conn, project, cut=7)

    tracked = get_all_tracked_files(conn, project)
    for reg in tracked:
        remaining = get_file_versions_since(conn, reg["uid"], 0)
        for ver in remaining:
            if ver["uid"] in versions:
                result = reconstruct(conn, reg["uid"], ver["uid"])
                assert result == versions[ver["uid"]], \
                    f"Reconstruction failed for uid={ver['uid']} after trim"


def test_trim_multifile_independent(trim_env, monkeypatch):
    """Trim works correctly when multiple files are tracked independently."""
    from rewindex.snapshot.trim import _run_trim

    env = trim_env
    conn = env["conn"]
    project = env["name"]

    for i in range(10):
        ts = f"2026-01-{i+1:02d}T00:00:00+00:00"
        session_uid = create_forced_session(conn, project, ts)
        _snap_with_session(env, "a.py", f"a-v{i+1}\n" * 3, session_uid)
        _snap_with_session(env, "b.py", f"b-v{i+1}\n" * 3, session_uid)
        _snap_with_session(env, "c.py", f"c-v{i+1}\n" * 3, session_uid)

    assert get_session_count(conn, project) == 10

    _run_trim(conn, project, cut=6)

    tracked = get_all_tracked_files(conn, project)
    assert len(tracked) == 3

    for reg in tracked:
        base = get_full_base_for_file(conn, reg["uid"])
        assert base is not None, f"No fullbase for {reg['filepath']}"
        remaining = get_file_versions_since(conn, reg["uid"], 0)
        for ver in remaining:
            result = reconstruct(conn, reg["uid"], ver["uid"])
            assert len(result) > 0


def test_trim_with_deletion_that_spans_boundary(trim_env, monkeypatch):
    """Trim works when a file was deleted after the cut boundary."""
    from rewindex.snapshot.trim import _run_trim
    from rewindex.snapshot.engine import record_deletion

    env = trim_env
    conn = env["conn"]
    project = env["name"]

    for i in range(12):
        ts = f"2026-01-{i+1:02d}T00:00:00+00:00"
        s = create_forced_session(conn, project, ts)
        _snap_with_session(env, "alive.py", f"v{i+1}\n", s)
        if i < 5:
            _snap_with_session(env, "later_deleted.py", f"d-v{i+1}\n", s)
        elif i == 8:
            abs_path = str(env["folder"] / "later_deleted.py")
            if os.path.exists(abs_path):
                os.remove(abs_path)
            record_deletion(conn, project, str(env["folder"]), abs_path, session_uid=s)

    _run_trim(conn, project, cut=3)

    tracked = get_all_tracked_files(conn, project)
    for reg in tracked:
        remaining = get_file_versions_since(conn, reg["uid"], 0)
        for ver in remaining:
            if not ver["is_deleted"]:
                result = reconstruct(conn, reg["uid"], ver["uid"])
                assert result is not None


def test_trim_ephemeral_file_entirely_before_boundary(trim_env, monkeypatch):
    """Trim handles files whose entire lifecycle falls before the cut boundary (FK edge case)."""
    from rewindex.snapshot.trim import _run_trim
    from rewindex.snapshot.engine import record_deletion

    env = trim_env
    conn = env["conn"]
    project = env["name"]

    for i in range(10):
        ts = f"2026-01-{i+1:02d}T00:00:00+00:00"
        s = create_forced_session(conn, project, ts)
        _snap_with_session(env, "alive.py", f"v{i+1}\n", s)
        if i < 3:
            _snap_with_session(env, "ephemeral.py", f"e-v{i+1}\n", s)
        elif i == 3:
            abs_path = str(env["folder"] / "ephemeral.py")
            if os.path.exists(abs_path):
                os.remove(abs_path)
            record_deletion(conn, project, str(env["folder"]), abs_path, session_uid=s)

    # cut=6 means sessions 1-6 are trimmed; ephemeral.py lives entirely in sessions 1-4
    _run_trim(conn, project, cut=6)

    remaining_sessions = get_session_count(conn, project)
    assert remaining_sessions <= 4

    tracked = get_all_tracked_files(conn, project)
    for reg in tracked:
        remaining = get_file_versions_since(conn, reg["uid"], 0)
        for ver in remaining:
            if not ver["is_deleted"]:
                result = reconstruct(conn, reg["uid"], ver["uid"])
                assert result is not None


def test_trim_repeated_does_not_break(trim_env, monkeypatch):
    """Running trim twice in a row doesn't corrupt data."""
    from rewindex.snapshot.trim import _run_trim

    env = trim_env
    conn = env["conn"]
    project = env["name"]

    for i in range(15):
        ts = f"2026-01-{i+1:02d}T00:00:00+00:00"
        s = create_forced_session(conn, project, ts)
        _snap_with_session(env, "repeat.py", f"v{i}\n" * 3, s)

    _run_trim(conn, project, cut=5)
    count1 = get_session_count(conn, project)

    _run_trim(conn, project, cut=3)
    count2 = get_session_count(conn, project)

    assert count2 <= count1

    tracked = get_all_tracked_files(conn, project)
    for reg in tracked:
        remaining = get_file_versions_since(conn, reg["uid"], 0)
        for ver in remaining:
            result = reconstruct(conn, reg["uid"], ver["uid"])
            assert len(result) > 0


# ══════════════════════════════════════════════════════════════════════════════
# 2. Multi-folder project management (up to 5 folders)
# ══════════════════════════════════════════════════════════════════════════════

@pytest.fixture()
def multi_env(tmp_path, monkeypatch):
    config_path = tmp_path / "config.yaml"
    config_path.write_text("projects:\n  - name: myapp\n    folders: []\n")

    import rewindex.config.loader as cl
    monkeypatch.setattr(cl, "CONFIG_PATH", str(config_path))
    monkeypatch.setattr(cl, "CONFIG_BACKUP_PATH", str(tmp_path / "backup.yaml"))

    folders = []
    for i in range(6):
        f = tmp_path / f"folder-{i}"
        f.mkdir()
        folders.append(f)

    return {"config_path": config_path, "folders": folders, "tmp": tmp_path}


def test_add_5_folders_pro(multi_env, monkeypatch):
    """Pro plan allows adding up to 5 folders to a project."""
    from rewindex.commands.project import project_add_folder
    import rewindex.config.loader as cl

    monkeypatch.setattr(cl, "CONFIG_PATH", str(multi_env["config_path"]))
    monkeypatch.setattr("rewindex.commands.project.restart_daemon", lambda c: None)

    runner = CliRunner()
    for i in range(5):
        with patch("rewindex.license.is_pro", return_value=True):
            result = runner.invoke(project_add_folder, ["myapp", str(multi_env["folders"][i])])
        assert result.exit_code == 0, f"Failed adding folder {i}: {result.output}"
        assert "Error" not in result.output, f"Error adding folder {i}: {result.output}"

    config = cl.load_config()
    project = next(p for p in config["projects"] if p["name"] == "myapp")
    assert len(project["folders"]) == 5


def test_6th_folder_rejected_pro(multi_env, monkeypatch):
    """Pro plan rejects 6th folder (max 5)."""
    import yaml
    import rewindex.config.loader as cl
    from rewindex.commands.project import project_add_folder

    five_folders = [str(multi_env["folders"][i]) for i in range(5)]
    multi_env["config_path"].write_text(yaml.dump({
        "projects": [{"name": "myapp", "folders": five_folders}]
    }))
    monkeypatch.setattr(cl, "CONFIG_PATH", str(multi_env["config_path"]))
    monkeypatch.setattr("rewindex.commands.project.restart_daemon", lambda c: None)

    runner = CliRunner()
    with patch("rewindex.license.is_pro", return_value=True):
        result = runner.invoke(project_add_folder, ["myapp", str(multi_env["folders"][5])])

    assert "Error" in result.output or "error" in result.output.lower()

    config = cl.load_config()
    project = next(p for p in config["projects"] if p["name"] == "myapp")
    assert len(project["folders"]) == 5


def test_free_plan_limited_to_1_folder(multi_env, monkeypatch):
    """Free plan allows only 1 folder per project."""
    import yaml
    import rewindex.config.loader as cl
    from rewindex.commands.project import project_add_folder

    multi_env["config_path"].write_text(yaml.dump({
        "projects": [{"name": "myapp", "folders": [str(multi_env["folders"][0])]}]
    }))
    monkeypatch.setattr(cl, "CONFIG_PATH", str(multi_env["config_path"]))
    monkeypatch.setattr("rewindex.commands.project.restart_daemon", lambda c: None)

    runner = CliRunner()
    with patch("rewindex.license.is_pro", return_value=False):
        result = runner.invoke(project_add_folder, ["myapp", str(multi_env["folders"][1])])

    assert "Error" in result.output or "error" in result.output.lower()
    assert "1" in result.output or "Free" in result.output

    config = cl.load_config()
    project = next(p for p in config["projects"] if p["name"] == "myapp")
    assert len(project["folders"]) == 1


def test_duplicate_folder_rejected(multi_env, monkeypatch):
    """Adding the same folder twice is rejected."""
    import yaml
    import rewindex.config.loader as cl
    from rewindex.commands.project import project_add_folder

    folder = str(multi_env["folders"][0])
    multi_env["config_path"].write_text(yaml.dump({
        "projects": [{"name": "myapp", "folders": [folder]}]
    }))
    monkeypatch.setattr(cl, "CONFIG_PATH", str(multi_env["config_path"]))
    monkeypatch.setattr("rewindex.commands.project.restart_daemon", lambda c: None)

    runner = CliRunner()
    with patch("rewindex.license.is_pro", return_value=True):
        result = runner.invoke(project_add_folder, ["myapp", folder])

    assert "already" in result.output.lower()


def test_remove_folder_from_multifolder_project(multi_env, monkeypatch):
    """Removing a folder from a multi-folder project works."""
    import yaml
    import rewindex.config.loader as cl
    from rewindex.commands.project import project_cmd

    folders = [str(multi_env["folders"][i]) for i in range(3)]
    multi_env["config_path"].write_text(yaml.dump({
        "projects": [{"name": "myapp", "folders": folders}]
    }))
    monkeypatch.setattr(cl, "CONFIG_PATH", str(multi_env["config_path"]))
    monkeypatch.setattr("rewindex.commands.project.restart_daemon", lambda c: None)

    runner = CliRunner()
    result = runner.invoke(project_cmd, ["remove-folder", "myapp", folders[1], "--yes"])

    assert result.exit_code == 0

    config = cl.load_config()
    project = next(p for p in config["projects"] if p["name"] == "myapp")
    assert len(project["folders"]) == 2
    assert folders[1] not in project["folders"]


def test_snapshot_from_multiple_folders(tmp_path, monkeypatch):
    """Files from different folders in the same project create independent registries."""
    rewindex_dir = tmp_path / ".rewindex"
    rewindex_dir.mkdir()
    monkeypatch.setattr("rewindex.config.defaults.REWINDEX_DIR", str(rewindex_dir))
    monkeypatch.setattr("rewindex.config.defaults.SNAPSHOTS_DIR", str(rewindex_dir / "snapshots"))

    folder_a = tmp_path / "folder-a"
    folder_b = tmp_path / "folder-b"
    folder_a.mkdir()
    folder_b.mkdir()

    conn = get_connection("multidir")

    file_a = folder_a / "main.py"
    file_a.write_text("from folder a\n")
    uid_a = snapshot_file(conn, "multidir", str(folder_a), str(file_a))
    assert uid_a is not None

    file_b = folder_b / "main.py"
    file_b.write_text("from folder b\n")
    uid_b = snapshot_file(conn, "multidir", str(folder_b), str(file_b))
    assert uid_b is not None

    reg_a = conn.execute("SELECT file_registry_uid FROM file WHERE uid = ?", (uid_a,)).fetchone()
    reg_b = conn.execute("SELECT file_registry_uid FROM file WHERE uid = ?", (uid_b,)).fetchone()
    assert reg_a["file_registry_uid"] != reg_b["file_registry_uid"], \
        "Same filename in different folders should get different registries"

    lines_a = reconstruct(conn, reg_a["file_registry_uid"], uid_a)
    lines_b = reconstruct(conn, reg_b["file_registry_uid"], uid_b)
    assert lines_a == ["from folder a\n"]
    assert lines_b == ["from folder b\n"]

    conn.close()


def test_folder_alt_syntax_add(multi_env, monkeypatch):
    """project folder add <name> <path> works with positional args."""
    import rewindex.config.loader as cl
    from rewindex.commands.project import project_cmd

    monkeypatch.setattr(cl, "CONFIG_PATH", str(multi_env["config_path"]))
    monkeypatch.setattr("rewindex.commands.project.restart_daemon", lambda c: None)

    runner = CliRunner()
    folder = str(multi_env["folders"][0])
    with patch("rewindex.license.is_pro", return_value=True):
        result = runner.invoke(project_cmd, ["folder", "add", "myapp", folder])

    assert result.exit_code == 0
    assert "Error" not in result.output

    config = cl.load_config()
    project = next(p for p in config["projects"] if p["name"] == "myapp")
    assert folder in project["folders"]
