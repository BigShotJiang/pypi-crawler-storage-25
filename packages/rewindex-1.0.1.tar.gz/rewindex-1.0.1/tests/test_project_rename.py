# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import os
import sqlite3
import tempfile

import pytest
from click.testing import CliRunner

import rewindex.config.loader as cl
import rewindex.config.defaults as d
from rewindex.commands.project import project_cmd


@pytest.fixture
def env(tmp_path, monkeypatch):
    """Set up isolated config + snapshots dir with two projects."""
    config_path = tmp_path / "config.yaml"
    snap_dir = tmp_path / "snapshots"
    snap_dir.mkdir()

    folder_a = tmp_path / "proj-a"
    folder_a.mkdir()
    folder_b = tmp_path / "proj-b"
    folder_b.mkdir()

    config_yaml = f"""
projects:
  - name: proj-a
    folders:
      - {folder_a}
  - name: proj-b
    folders:
      - {folder_b}
"""
    config_path.write_text(config_yaml)

    monkeypatch.setattr(cl, "CONFIG_PATH", str(config_path))
    monkeypatch.setattr(d, "SNAPSHOTS_DIR", str(snap_dir))

    # Create snapshot dirs + DBs with v2 schema
    monkeypatch.setattr(
        "rewindex.db.connection.get_db_path",
        lambda name: str(snap_dir / name / "rewindex.db"),
    )
    for name in ["proj-a", "proj-b"]:
        proj_snap = snap_dir / name
        proj_snap.mkdir()
        from rewindex.db.connection import get_connection
        conn = get_connection(name)
        conn.execute(
            "INSERT INTO file_registry (file_id, project, folder_path, filepath, filename) VALUES (?, ?, ?, ?, ?)",
            ("A1B2", name, "/tmp", "src/main.py", "main.py"),
        )
        conn.commit()
        conn.close()

    return {
        "config_path": config_path,
        "snap_dir": snap_dir,
        "folder_a": folder_a,
        "folder_b": folder_b,
    }


def test_rename_updates_config(env):
    runner = CliRunner()
    result = runner.invoke(project_cmd, ["rename", "proj-a", "proj-renamed", "--yes"])
    assert result.exit_code == 0
    assert "proj-renamed" in result.output

    config = cl.load_config()
    names = [p["name"] for p in config["projects"]]
    assert "proj-renamed" in names
    assert "proj-a" not in names


def test_rename_moves_snapshot_dir(env):
    runner = CliRunner()
    runner.invoke(project_cmd, ["rename", "proj-a", "proj-renamed", "--yes"])

    snap_dir = env["snap_dir"]
    assert (snap_dir / "proj-renamed").is_dir()
    assert not (snap_dir / "proj-a").exists()


def test_rename_updates_db_rows(env):
    runner = CliRunner()
    runner.invoke(project_cmd, ["rename", "proj-a", "proj-renamed", "--yes"])

    db_path = env["snap_dir"] / "proj-renamed" / "rewindex.db"
    conn = sqlite3.connect(str(db_path))
    rows = conn.execute("SELECT project FROM file_registry").fetchall()
    conn.close()

    assert all(r[0] == "proj-renamed" for r in rows)


def test_rename_nonexistent_project(env):
    runner = CliRunner()
    result = runner.invoke(project_cmd, ["rename", "no-such", "new-name", "--yes"])
    assert result.exit_code == 0
    assert "not found" in result.output


def test_rename_to_existing_name(env):
    runner = CliRunner()
    result = runner.invoke(project_cmd, ["rename", "proj-a", "proj-b", "--yes"])
    assert result.exit_code == 0
    assert "already exists" in result.output

    # proj-a should still exist in config
    config = cl.load_config()
    names = [p["name"] for p in config["projects"]]
    assert "proj-a" in names


def test_rename_invalid_name(env):
    runner = CliRunner()
    result = runner.invoke(project_cmd, ["rename", "proj-a", "invalid name!", "--yes"])
    assert result.exit_code == 0
    assert "Error" in result.output

    # Config unchanged
    config = cl.load_config()
    names = [p["name"] for p in config["projects"]]
    assert "proj-a" in names
