# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

"""
Tests for Phase 1 security fixes:
  A17 — validate project name in init
  A18 — chmod 700 on REWINDEX_DIR
  A19 — _validate_bin() in autostart
  B8  — _sanitize() log output
  A21 — confirm before pip install
"""

import os
import stat
from unittest.mock import MagicMock, call, patch

import pytest
from click.testing import CliRunner


# ── B8: _sanitize() ──────────────────────────────────────────────────────────

from rewindex.utils.formatting import sanitize as _sanitize


def test_sanitize_strips_ansi():
    assert _sanitize("\x1b[31mred\x1b[0m") == "red"


def test_sanitize_strips_newlines():
    assert _sanitize("line1\nline2") == "line1 line2"


def test_sanitize_strips_carriage_return():
    assert _sanitize("line1\rline2") == "line1 line2"


def test_sanitize_combined_ansi_and_newline():
    # ANSI stripped → "Bold", newline → space, result = "Bold Injected"
    assert _sanitize("\x1b[1mBold\x1b[0m\nInjected") == "Bold Injected"


def test_sanitize_passthrough_clean_value():
    assert _sanitize("Claude Code") == "Claude Code"


def test_sanitize_empty_string():
    assert _sanitize("") == ""


# ── A19: _validate_bin() ─────────────────────────────────────────────────────

from rewindex.autostart.linux import _validate_bin as linux_validate_bin
from rewindex.autostart.macos import _validate_bin as macos_validate_bin


@pytest.mark.parametrize("validate_bin", [linux_validate_bin, macos_validate_bin])
def test_validate_bin_rejects_relative_path(validate_bin):
    with pytest.raises(RuntimeError, match="not absolute"):
        validate_bin("relative/path/rewindex")


@pytest.mark.parametrize("validate_bin", [linux_validate_bin, macos_validate_bin])
def test_validate_bin_rejects_nonexistent_path(validate_bin, tmp_path):
    with pytest.raises(RuntimeError, match="Cannot stat"):
        validate_bin(str(tmp_path / "nonexistent_bin"))


@pytest.mark.parametrize("validate_bin", [linux_validate_bin, macos_validate_bin])
def test_validate_bin_accepts_owner_binary(validate_bin, tmp_path):
    binary = tmp_path / "rewindex"
    binary.write_text("#!/bin/sh\n")
    binary.chmod(0o755)
    # File is owned by current user — should not raise
    validate_bin(str(binary))


@pytest.mark.parametrize("validate_bin", [linux_validate_bin, macos_validate_bin])
def test_validate_bin_rejects_foreign_owner(validate_bin, tmp_path):
    binary = tmp_path / "rewindex"
    binary.write_text("#!/bin/sh\n")
    binary.chmod(0o755)

    foreign_uid = 9999
    mock_stat = MagicMock()
    mock_stat.st_uid = foreign_uid

    with patch("os.stat", return_value=mock_stat), \
         patch("os.getuid", return_value=1000):
        with pytest.raises(RuntimeError, match="owned by uid"):
            validate_bin(str(binary))


# ── A18: chmod 700 on REWINDEX_DIR ───────────────────────────────────────────

def test_init_sets_rewindex_dir_permissions(tmp_path, monkeypatch):
    rewindex_dir = str(tmp_path / ".rewindex")
    snapshots_dir = str(tmp_path / ".rewindex" / "snapshots")

    monkeypatch.setattr("rewindex.config.defaults.REWINDEX_DIR", rewindex_dir)
    monkeypatch.setattr("rewindex.config.defaults.SNAPSHOTS_DIR", snapshots_dir)
    monkeypatch.setattr("rewindex.commands.init.REWINDEX_DIR", rewindex_dir)
    monkeypatch.setattr("rewindex.commands.init.SNAPSHOTS_DIR", snapshots_dir)

    project_folder = str(tmp_path / "src")
    os.makedirs(project_folder)

    with patch("rewindex.commands.init.save_config"), \
         patch("rewindex.commands.init.config_exists", return_value=False), \
         patch("rewindex.commands.init.restart_daemon", lambda c: None), \
         patch("rewindex.version.init_rewindex_json"):
        from rewindex.commands.init import _run_init
        _run_init("myproject", project_folder, interactive=False)

    mode = stat.S_IMODE(os.stat(rewindex_dir).st_mode)
    assert mode == 0o700, f"Expected 0o700, got {oct(mode)}"


# ── A17: validate project name ───────────────────────────────────────────────

def test_init_rejects_project_name_with_null_byte(tmp_path, monkeypatch):
    rewindex_dir = str(tmp_path / ".rewindex")
    snapshots_dir = str(tmp_path / ".rewindex" / "snapshots")
    monkeypatch.setattr("rewindex.config.defaults.REWINDEX_DIR", rewindex_dir)
    monkeypatch.setattr("rewindex.config.defaults.SNAPSHOTS_DIR", snapshots_dir)
    monkeypatch.setattr("rewindex.commands.init.REWINDEX_DIR", rewindex_dir)
    monkeypatch.setattr("rewindex.commands.init.SNAPSHOTS_DIR", snapshots_dir)

    project_folder = str(tmp_path / "src")
    os.makedirs(project_folder)

    from click.testing import CliRunner
    runner = CliRunner()

    with patch("rewindex.commands.init.save_config") as mock_save, \
         patch("rewindex.commands.init.config_exists", return_value=False), \
         patch("rewindex.commands.init.restart_daemon"):
        from rewindex.commands.init import _run_init
        _run_init("bad\x00name", project_folder, interactive=False)
        mock_save.assert_not_called()


def test_init_rejects_project_name_too_long(tmp_path, monkeypatch):
    rewindex_dir = str(tmp_path / ".rewindex")
    snapshots_dir = str(tmp_path / ".rewindex" / "snapshots")
    monkeypatch.setattr("rewindex.config.defaults.REWINDEX_DIR", rewindex_dir)
    monkeypatch.setattr("rewindex.config.defaults.SNAPSHOTS_DIR", snapshots_dir)
    monkeypatch.setattr("rewindex.commands.init.REWINDEX_DIR", rewindex_dir)
    monkeypatch.setattr("rewindex.commands.init.SNAPSHOTS_DIR", snapshots_dir)

    project_folder = str(tmp_path / "src")
    os.makedirs(project_folder)

    with patch("rewindex.commands.init.save_config") as mock_save, \
         patch("rewindex.commands.init.config_exists", return_value=False), \
         patch("rewindex.commands.init.restart_daemon"):
        from rewindex.commands.init import _run_init
        _run_init("x" * 300, project_folder, interactive=False)
        mock_save.assert_not_called()


def test_init_rejects_project_name_with_spaces(tmp_path, monkeypatch):
    rewindex_dir = str(tmp_path / ".rewindex")
    snapshots_dir = str(tmp_path / ".rewindex" / "snapshots")
    monkeypatch.setattr("rewindex.config.defaults.REWINDEX_DIR", rewindex_dir)
    monkeypatch.setattr("rewindex.config.defaults.SNAPSHOTS_DIR", snapshots_dir)
    monkeypatch.setattr("rewindex.commands.init.REWINDEX_DIR", rewindex_dir)
    monkeypatch.setattr("rewindex.commands.init.SNAPSHOTS_DIR", snapshots_dir)

    project_folder = str(tmp_path / "src")
    os.makedirs(project_folder)

    with patch("rewindex.commands.init.save_config") as mock_save, \
         patch("rewindex.commands.init.config_exists", return_value=False), \
         patch("rewindex.commands.init.restart_daemon"):
        from rewindex.commands.init import _run_init
        _run_init("my project", project_folder, interactive=False)
        mock_save.assert_not_called()


def test_init_rejects_project_name_with_special_chars(tmp_path, monkeypatch):
    rewindex_dir = str(tmp_path / ".rewindex")
    snapshots_dir = str(tmp_path / ".rewindex" / "snapshots")
    monkeypatch.setattr("rewindex.config.defaults.REWINDEX_DIR", rewindex_dir)
    monkeypatch.setattr("rewindex.config.defaults.SNAPSHOTS_DIR", snapshots_dir)
    monkeypatch.setattr("rewindex.commands.init.REWINDEX_DIR", rewindex_dir)
    monkeypatch.setattr("rewindex.commands.init.SNAPSHOTS_DIR", snapshots_dir)

    project_folder = str(tmp_path / "src")
    os.makedirs(project_folder)

    with patch("rewindex.commands.init.save_config") as mock_save, \
         patch("rewindex.commands.init.config_exists", return_value=False), \
         patch("rewindex.commands.init.restart_daemon"):
        from rewindex.commands.init import _run_init
        _run_init("../../evil", project_folder, interactive=False)
        mock_save.assert_not_called()


def test_validate_project_name_accepts_valid_names():
    from rewindex.utils.validation import validate_project_name
    for name in ["myproject", "my-project", "my_project", "my.project", "Project123", "a"]:
        validate_project_name(name)  # should not raise


def test_validate_project_name_rejects_invalid_names():
    from rewindex.utils.validation import validate_project_name
    import pytest
    for name in ["", " ", "my project", "../evil", "a/b", "émoji", "-start", ".start"]:
        with pytest.raises(ValueError):
            validate_project_name(name)


# ── A21: confirm before pip install ──────────────────────────────────────────

def test_upgrade_aborts_when_user_declines():
    from rewindex.commands.update import _upgrade

    with patch("rewindex.commands.update._get_latest_version", return_value="99.0.0"), \
         patch("questionary.confirm") as mock_confirm, \
         patch("rewindex.commands.update.subprocess.run") as mock_run:
        mock_confirm.return_value.ask.return_value = False
        _upgrade()
        mock_run.assert_not_called()


def test_upgrade_runs_pip_when_user_confirms():
    from rewindex.commands.update import _upgrade

    mock_result = MagicMock()
    mock_result.returncode = 0

    with patch("rewindex.commands.update._get_latest_version", return_value="99.0.0"), \
         patch("questionary.confirm") as mock_confirm, \
         patch("rewindex.commands.update.subprocess.run", return_value=mock_result) as mock_run, \
         patch("rewindex.daemon.runner.is_running", return_value=False):
        mock_confirm.return_value.ask.return_value = True
        _upgrade()
        mock_run.assert_called_once()
        cmd = mock_run.call_args[0][0]
        assert "pip" in cmd
        assert "install" in cmd
        assert "--upgrade" in cmd
        assert "rewindex" in cmd
