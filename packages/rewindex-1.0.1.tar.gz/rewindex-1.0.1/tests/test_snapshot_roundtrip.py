# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

# CRITICAL: Verifies that apply(diff, N layers) == original at every step.
# This test must pass before any release.

import os
import tempfile

import pytest

from rewindex.db.connection import get_connection
from rewindex.snapshot.engine import snapshot_file
from rewindex.snapshot.reconstruct import reconstruct


@pytest.fixture()
def tmp_project(tmp_path, monkeypatch):
    """Set up isolated ~/.rewindex and a temp project folder."""
    rewindex_dir = tmp_path / ".rewindex"
    rewindex_dir.mkdir()
    monkeypatch.setattr("rewindex.config.defaults.REWINDEX_DIR", str(rewindex_dir))
    monkeypatch.setattr("rewindex.config.defaults.SNAPSHOTS_DIR", str(rewindex_dir / "snapshots"))

    project_dir = tmp_path / "my-project"
    project_dir.mkdir()

    return {
        "name": "test",
        "folder": str(project_dir),
        "conn": get_connection("test"),
    }


def _write(project_dir: str, filename: str, lines: list[str]) -> str:
    path = os.path.join(project_dir, filename)
    with open(path, "w") as f:
        f.writelines(lines)
    return path


def _reg_uid(conn, file_uid):
    row = conn.execute("SELECT file_registry_uid FROM file WHERE uid = ?", (file_uid,)).fetchone()
    return row["file_registry_uid"]


def test_single_full_snapshot(tmp_project):
    folder = tmp_project["folder"]
    conn = tmp_project["conn"]
    lines = ["hello\n", "world\n"]
    path = _write(folder, "file.py", lines)

    sid = snapshot_file(conn, "test", folder, path)
    assert sid is not None

    result = reconstruct(conn, _reg_uid(conn, sid), sid)
    assert result == lines


def test_two_snapshots_roundtrip(tmp_project):
    folder = tmp_project["folder"]
    conn = tmp_project["conn"]

    v1 = ["a\n", "b\n", "c\n"]
    v2 = ["a\n", "B\n", "c\n", "d\n"]

    path = _write(folder, "auth.py", v1)
    s1 = snapshot_file(conn, "test", folder, path)

    _write(folder, "auth.py", v2)
    s2 = snapshot_file(conn, "test", folder, path)

    reg_uid = _reg_uid(conn, s1)
    assert reconstruct(conn, reg_uid, s1) == v1
    assert reconstruct(conn, reg_uid, s2) == v2


def test_ten_layer_roundtrip(tmp_project):
    folder = tmp_project["folder"]
    conn = tmp_project["conn"]

    versions = []
    lines = [f"line{i}\n" for i in range(20)]
    versions.append(list(lines))

    path = _write(folder, "code.py", lines)
    ids = [snapshot_file(conn, "test", folder, path)]

    for step in range(9):
        lines[10] = f"changed-{step}\n"
        lines.append(f"extra-{step}\n")
        versions.append(list(lines))
        _write(folder, "code.py", lines)
        ids.append(snapshot_file(conn, "test", folder, path))

    reg_uid = _reg_uid(conn, ids[0])
    for i, (sid, expected) in enumerate(zip(ids, versions)):
        result = reconstruct(conn, reg_uid, sid)
        assert result == expected, f"Layer {i} mismatch"


def test_insert_middle_stays_small(tmp_project):
    folder = tmp_project["folder"]
    conn = tmp_project["conn"]

    lines = [f"line{i}\n" for i in range(200)]
    path = _write(folder, "big.py", lines)
    snapshot_file(conn, "test", folder, path)

    lines.insert(100, "NEW LINE\n")
    _write(folder, "big.py", lines)
    s2 = snapshot_file(conn, "test", folder, path)

    snap = conn.execute("SELECT file_size FROM file WHERE uid = ?", (s2,)).fetchone()
    assert snap["file_size"] < 500, f"Diff too large: {snap['file_size']} bytes"


def test_no_snapshot_when_unchanged(tmp_project):
    folder = tmp_project["folder"]
    conn = tmp_project["conn"]

    path = _write(folder, "same.py", ["no change\n"])
    snapshot_file(conn, "test", folder, path)
    result = snapshot_file(conn, "test", folder, path)
    assert result is None
