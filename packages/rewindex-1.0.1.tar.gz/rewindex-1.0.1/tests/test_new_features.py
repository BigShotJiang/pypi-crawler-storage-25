# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

"""Tests for DEL-1 (deletion detection), DEL-2 (full state rewind), VER-1 (per-file ID/version)."""

import os
import pytest


# ── helpers ────────────────────────────────────────────────────────────────────

def _make_project(tmp_path, name="proj"):
    import rewindex.config.defaults as d
    d.SNAPSHOTS_DIR = str(tmp_path / "snapshots")
    d.REWINDEX_DIR = str(tmp_path / ".rewindex")
    from rewindex.db.connection import get_connection
    conn = get_connection(name)
    return conn, str(tmp_path / "project")


def _snap(conn, project, project_folder, filepath, content):
    """Write a real file and snapshot it."""
    abs_path = os.path.join(project_folder, filepath)
    os.makedirs(os.path.dirname(abs_path), exist_ok=True)
    with open(abs_path, "w") as f:
        f.write(content)
    from rewindex.snapshot.engine import snapshot_file
    return snapshot_file(conn, project, project_folder, abs_path)


# ── DEL-1: Deletion Detection ──────────────────────────────────────────────────

def test_record_deletion_basic(tmp_path):
    """record_deletion creates is_deleted snapshot for a tracked file."""
    from rewindex.snapshot.engine import record_deletion
    from rewindex.db.queries import get_file_version

    conn, project_folder = _make_project(tmp_path)
    project = "proj"

    snap_id = _snap(conn, project, project_folder, "src/auth.py", "def login(): pass")
    assert snap_id is not None

    abs_path = os.path.join(project_folder, "src/auth.py")
    del_id = record_deletion(conn, project, project_folder, abs_path)
    assert del_id is not None

    snap = get_file_version(conn, del_id)
    assert snap["is_deleted"] == 1
    assert snap["hash"] == "__deleted__"
    assert snap["is_full"] == 1
    conn.close()


def test_record_deletion_untracked_file(tmp_path):
    """record_deletion returns None for a file never snapshotted."""
    from rewindex.snapshot.engine import record_deletion

    conn, project_folder = _make_project(tmp_path)
    abs_path = os.path.join(project_folder, "ghost.py")
    result = record_deletion(conn, "proj", project_folder, abs_path)
    assert result is None
    conn.close()


def test_record_deletion_already_deleted(tmp_path):
    """record_deletion returns None if file is already marked deleted."""
    from rewindex.snapshot.engine import record_deletion

    conn, project_folder = _make_project(tmp_path)
    project = "proj"

    _snap(conn, project, project_folder, "x.py", "x = 1")
    abs_path = os.path.join(project_folder, "x.py")

    first = record_deletion(conn, project, project_folder, abs_path)
    assert first is not None
    second = record_deletion(conn, project, project_folder, abs_path)
    assert second is None
    conn.close()


def test_snapshot_after_deletion_is_full(tmp_path):
    """After deletion, recreating the file produces a full snapshot (not diff)."""
    from rewindex.snapshot.engine import record_deletion, snapshot_file
    from rewindex.db.queries import get_file_version

    conn, project_folder = _make_project(tmp_path)
    project = "proj"

    _snap(conn, project, project_folder, "a.py", "v1")
    abs_path = os.path.join(project_folder, "a.py")
    record_deletion(conn, project, project_folder, abs_path)

    with open(abs_path, "w") as f:
        f.write("v2")
    new_id = snapshot_file(conn, project, project_folder, abs_path)
    assert new_id is not None

    snap = get_file_version(conn, new_id)
    assert snap["is_full"] == 1
    assert snap["is_deleted"] == 0
    conn.close()


def test_snapshot_deleted_file_calls_record_deletion(tmp_path):
    """snapshot_file on a missing tracked file records a deletion."""
    from rewindex.snapshot.engine import snapshot_file
    from rewindex.db.queries import get_latest_file_version, get_or_create_file_registry

    conn, project_folder = _make_project(tmp_path)
    project = "proj"

    _snap(conn, project, project_folder, "b.py", "hello")
    abs_path = os.path.join(project_folder, "b.py")
    os.remove(abs_path)

    del_id = snapshot_file(conn, project, project_folder, abs_path)
    assert del_id is not None

    reg_uid, _, _ = get_or_create_file_registry(conn, project, project_folder, "b.py")
    snap = get_latest_file_version(conn, reg_uid)
    assert snap["is_deleted"] == 1
    conn.close()


# ── VER-1: Per-file ID + Version Counter ──────────────────────────────────────

def test_file_id_generated_on_first_snapshot(tmp_path):
    """First snapshot of a file generates a non-empty file_id and file_version=1."""
    from rewindex.db.queries import get_or_create_file_registry, get_latest_file_version

    conn, project_folder = _make_project(tmp_path)

    _snap(conn, "proj", project_folder, "foo.py", "x = 1")
    reg_uid, file_id, _ = get_or_create_file_registry(conn, "proj", project_folder, "foo.py")
    assert file_id != ""
    assert len(file_id) >= 2

    snap = get_latest_file_version(conn, reg_uid)
    assert snap["file_version"] == 1
    conn.close()


def test_file_version_increments(tmp_path):
    """Each new snapshot of the same file increments file_version."""
    from rewindex.db.queries import get_or_create_file_registry, get_latest_file_version

    conn, project_folder = _make_project(tmp_path)
    project = "proj"

    _snap(conn, project, project_folder, "counter.py", "v1")
    _snap(conn, project, project_folder, "counter.py", "v2")
    _snap(conn, project, project_folder, "counter.py", "v3")

    reg_uid, _, _ = get_or_create_file_registry(conn, project, project_folder, "counter.py")
    snap = get_latest_file_version(conn, reg_uid)
    assert snap["file_version"] == 3
    conn.close()


def test_file_id_consistent_across_snapshots(tmp_path):
    """Same file always gets the same file_id across multiple snapshots."""
    conn, project_folder = _make_project(tmp_path)
    project = "proj"

    _snap(conn, project, project_folder, "stable.py", "v1")
    _snap(conn, project, project_folder, "stable.py", "v2")

    rows = conn.execute(
        "SELECT DISTINCT file_id FROM file_registry WHERE project=? AND filepath=?",
        (project, "stable.py")
    ).fetchall()
    assert len(rows) == 1
    assert rows[0]["file_id"] != ""
    conn.close()


def test_different_files_get_different_ids(tmp_path):
    """Two different files always get different file_ids."""
    from rewindex.db.queries import get_or_create_file_registry

    conn, project_folder = _make_project(tmp_path)
    project = "proj"

    _snap(conn, project, project_folder, "a.py", "a")
    _snap(conn, project, project_folder, "b.py", "b")

    _, id_a, _ = get_or_create_file_registry(conn, project, project_folder, "a.py")
    _, id_b, _ = get_or_create_file_registry(conn, project, project_folder, "b.py")
    assert id_a != id_b
    conn.close()


def test_fmt_snap():
    """fmt_snap formats snap IDs without zero-padding."""
    from rewindex.utils.id_parse import fmt_snap
    assert fmt_snap(42) == "SN42"
    assert fmt_snap(1) == "SN1"


def test_fmt_session():
    """fmt_session formats session IDs without zero-padding."""
    from rewindex.utils.id_parse import fmt_session
    assert fmt_session(3) == "SS3"
    assert fmt_session(12) == "SS12"


def test_parse_snap_id_global_format():
    """parse_snap_id requires SN prefix — rejects bare numbers and # shorthand."""
    import pytest
    from rewindex.utils.id_parse import parse_snap_id

    assert parse_snap_id("SN1") == 1
    assert parse_snap_id("SN42") == 42

    with pytest.raises(ValueError):
        parse_snap_id("1")
    with pytest.raises(ValueError):
        parse_snap_id("#0001")
    with pytest.raises(ValueError):
        parse_snap_id("SN0")


def test_parse_file_id_version():
    """parse_file_id_version parses 4-char FileID and optional version."""
    from rewindex.utils.id_parse import parse_file_id_version

    file_id, ver = parse_file_id_version("D1VS", "v3")
    assert file_id == "D1VS"
    assert ver == 3

    file_id, ver = parse_file_id_version("D1VS", "latest")
    assert file_id == "D1VS"
    assert ver is None

    file_id, ver = parse_file_id_version("D1VS")
    assert file_id == "D1VS"
    assert ver is None


# ── DEL-2: Full Project-State Rewind ─────────────────────────────────────────

def test_full_state_rewind_restores_deleted_file(tmp_path):
    """Reconstruct at a file version restores content even if later deleted."""
    from rewindex.snapshot.engine import record_deletion
    from rewindex.db.queries import get_file_version
    from rewindex.snapshot.reconstruct import reconstruct

    conn, project_folder = _make_project(tmp_path)
    project = "proj"

    snap_id = _snap(conn, project, project_folder, "keep.py", "important")
    assert snap_id is not None

    abs_path = os.path.join(project_folder, "keep.py")
    os.remove(abs_path)
    record_deletion(conn, project, project_folder, abs_path)
    assert not os.path.exists(abs_path)

    reg_uid = conn.execute("SELECT file_registry_uid FROM file WHERE uid = ?", (snap_id,)).fetchone()["file_registry_uid"]
    lines = reconstruct(conn, reg_uid, snap_id)
    os.makedirs(os.path.dirname(abs_path), exist_ok=True)
    with open(abs_path, "w", encoding="utf-8") as f:
        f.writelines(lines)

    assert os.path.exists(abs_path)
    with open(abs_path) as f:
        assert f.read() == "important"
    conn.close()


def test_full_state_rewind_removes_file_added_after(tmp_path):
    """A file added after a target version can be detected and removed."""
    from rewindex.db.queries import (
        get_or_create_file_registry, create_forced_session,
    )

    conn, project_folder = _make_project(tmp_path)
    project = "proj"

    # First file in session 1
    created_at_1 = "2026-01-01T00:00:00+00:00"
    session_1 = create_forced_session(conn, project, created_at_1)
    from rewindex.snapshot.engine import snapshot_file
    abs_orig = os.path.join(project_folder, "original.py")
    os.makedirs(os.path.dirname(abs_orig), exist_ok=True)
    with open(abs_orig, "w") as f:
        f.write("v1")
    snapshot_file(conn, project, project_folder, abs_orig, session_uid=session_1)

    # Second file in session 2
    created_at_2 = "2026-01-02T00:00:00+00:00"
    session_2 = create_forced_session(conn, project, created_at_2)
    abs_new = os.path.join(project_folder, "new_file.py")
    with open(abs_new, "w") as f:
        f.write("added later")
    snapshot_file(conn, project, project_folder, abs_new, session_uid=session_2)

    assert os.path.exists(abs_new)

    from rewindex.db.queries import get_latest_version_at_session
    reg_uid, _, _ = get_or_create_file_registry(conn, project, project_folder, "new_file.py")
    ver = get_latest_version_at_session(conn, reg_uid, session_1)
    if ver is None:
        os.remove(abs_new)

    assert not os.path.exists(abs_new)
    conn.close()


def test_full_state_rewind_restores_modified_file(tmp_path):
    """Reconstruct at an earlier version restores original content."""
    from rewindex.db.queries import create_forced_session
    from rewindex.snapshot.reconstruct import reconstruct

    conn, project_folder = _make_project(tmp_path)
    project = "proj"

    # v1 in session 1
    created_at_1 = "2026-01-01T00:00:00+00:00"
    session_1 = create_forced_session(conn, project, created_at_1)
    from rewindex.snapshot.engine import snapshot_file
    abs_path = os.path.join(project_folder, "mod.py")
    os.makedirs(os.path.dirname(abs_path), exist_ok=True)
    with open(abs_path, "w") as f:
        f.write("original content\n")
    snap_v1 = snapshot_file(conn, project, project_folder, abs_path, session_uid=session_1)

    # v2 in session 2
    created_at_2 = "2026-01-02T00:00:00+00:00"
    session_2 = create_forced_session(conn, project, created_at_2)
    with open(abs_path, "w") as f:
        f.write("modified content\n")
    snapshot_file(conn, project, project_folder, abs_path, session_uid=session_2)

    reg_uid = conn.execute("SELECT file_registry_uid FROM file WHERE uid = ?", (snap_v1,)).fetchone()["file_registry_uid"]
    lines = reconstruct(conn, reg_uid, snap_v1)

    with open(abs_path, "w", encoding="utf-8") as f:
        f.writelines(lines)

    with open(abs_path) as f:
        assert f.read() == "original content\n"
    conn.close()


def test_full_state_rewind_does_not_touch_untracked_files(tmp_path):
    """Full state rewind leaves files that were never tracked alone."""
    conn, project_folder = _make_project(tmp_path)
    project = "proj"

    _snap(conn, project, project_folder, "tracked.py", "v1")

    untracked = os.path.join(project_folder, "untracked.py")
    with open(untracked, "w") as f:
        f.write("leave me alone")

    assert os.path.exists(untracked)
    conn.close()


def test_get_all_tracked_files(tmp_path):
    """get_all_tracked_files returns all distinct file registries."""
    from rewindex.db.queries import get_all_tracked_files

    conn, project_folder = _make_project(tmp_path)
    project = "proj"

    _snap(conn, project, project_folder, "a.py", "a")
    _snap(conn, project, project_folder, "b.py", "b")
    _snap(conn, project, project_folder, "a.py", "a2")

    files = get_all_tracked_files(conn, project)
    filepaths = sorted([r["filepath"] for r in files])
    assert filepaths == ["a.py", "b.py"]
    conn.close()
