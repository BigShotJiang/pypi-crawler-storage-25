# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

"""
Tests for same_folder() — verifies all path aliasing methods are detected.
"""

import os
import tempfile

import pytest

from rewindex.utils.validation import same_folder


# ── Basic cases ───────────────────────────────────────────────────────────────

def test_identical_paths_are_same(tmp_path):
    path = str(tmp_path / "project")
    os.makedirs(path)
    assert same_folder(path, path)


def test_different_paths_are_not_same(tmp_path):
    a = str(tmp_path / "proj-a"); os.makedirs(a)
    b = str(tmp_path / "proj-b"); os.makedirs(b)
    assert not same_folder(a, b)


# ── Trailing slash / double slash ─────────────────────────────────────────────

def test_trailing_slash_same(tmp_path):
    path = str(tmp_path / "project"); os.makedirs(path)
    assert same_folder(path, path + "/")
    assert same_folder(path + "/", path)


def test_double_slash_same(tmp_path):
    parent = str(tmp_path)
    path = parent + "/project"; os.makedirs(path)
    assert same_folder(path, parent + "//project")


# ── Dot / dotdot ──────────────────────────────────────────────────────────────

def test_dot_resolved(tmp_path):
    path = str(tmp_path / "project"); os.makedirs(path)
    dotted = path + "/subdir/.."; os.makedirs(path + "/subdir")
    assert same_folder(path, dotted)


def test_dotdot_resolved(tmp_path):
    parent = str(tmp_path)
    path = parent + "/project"; os.makedirs(path)
    via_parent = parent + "/other/../project"; os.makedirs(parent + "/other")
    assert same_folder(path, via_parent)


# ── Symlink ───────────────────────────────────────────────────────────────────

def test_symlink_to_same_dir(tmp_path):
    real = str(tmp_path / "real"); os.makedirs(real)
    link = str(tmp_path / "link"); os.symlink(real, link)
    assert same_folder(real, link)


def test_symlink_to_different_dir(tmp_path):
    real_a = str(tmp_path / "real-a"); os.makedirs(real_a)
    real_b = str(tmp_path / "real-b"); os.makedirs(real_b)
    link = str(tmp_path / "link"); os.symlink(real_a, link)
    assert not same_folder(link, real_b)


def test_nested_symlink(tmp_path):
    real = str(tmp_path / "a" / "b" / "project")
    os.makedirs(real)
    link1 = str(tmp_path / "link1"); os.symlink(str(tmp_path / "a"), link1)
    # link1/b/project → tmp/a/b/project
    assert same_folder(real, link1 + "/b/project")


# ── Bind mount (inode+device) ─────────────────────────────────────────────────

def test_bind_mount_detected_via_inode(tmp_path):
    """
    Simulate bind-mount identity by patching os.stat to return the same
    inode+device for two different real paths.
    This tests the fallback branch of same_folder().
    """
    from unittest.mock import patch, MagicMock

    real_a = str(tmp_path / "proj-a"); os.makedirs(real_a)
    real_b = str(tmp_path / "proj-b"); os.makedirs(real_b)

    # Both paths have different realpaths, but same inode+dev (simulate bind mount)
    mock_stat = MagicMock()
    mock_stat.st_ino = 12345
    mock_stat.st_dev = 99

    with patch("os.stat", return_value=mock_stat):
        assert same_folder(real_a, real_b), \
            "Bind-mounted directories with same inode+dev must be detected as same"


def test_different_inodes_are_not_same(tmp_path):
    """Two dirs with different inode+dev are genuinely different."""
    a = str(tmp_path / "proj-a"); os.makedirs(a)
    b = str(tmp_path / "proj-b"); os.makedirs(b)
    # real stat — different inodes
    st_a = os.stat(a)
    st_b = os.stat(b)
    # On same filesystem they share dev but have different ino
    assert not (st_a.st_ino == st_b.st_ino and st_a.st_dev == st_b.st_dev)
    assert not same_folder(a, b)


# ── Nonexistent path (graceful) ───────────────────────────────────────────────

def test_nonexistent_path_returns_false(tmp_path):
    real = str(tmp_path / "real"); os.makedirs(real)
    ghost = str(tmp_path / "ghost")  # does not exist
    assert not same_folder(real, ghost)


def test_both_nonexistent_returns_false(tmp_path):
    a = str(tmp_path / "ghost-a")
    b = str(tmp_path / "ghost-b")
    assert not same_folder(a, b)
