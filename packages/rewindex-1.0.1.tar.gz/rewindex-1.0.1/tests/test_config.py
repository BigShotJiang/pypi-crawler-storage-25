# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import os

import pytest
import yaml

from rewindex.config.validator import ConfigState, check_config, auto_restore_if_needed


@pytest.fixture(autouse=True)
def isolated_config(tmp_path, monkeypatch):
    config_path = str(tmp_path / ".rewindex.config.yaml")
    backup_path = str(tmp_path / ".rewindex.config.backup.yaml")
    monkeypatch.setattr("rewindex.config.defaults.CONFIG_PATH", config_path)
    monkeypatch.setattr("rewindex.config.defaults.CONFIG_BACKUP_PATH", backup_path)
    monkeypatch.setattr("rewindex.config.loader.CONFIG_PATH", config_path)
    monkeypatch.setattr("rewindex.config.loader.CONFIG_BACKUP_PATH", backup_path)
    monkeypatch.setattr("rewindex.config.validator.CONFIG_PATH", config_path)
    monkeypatch.setattr("rewindex.config.validator.CONFIG_BACKUP_PATH", backup_path)
    return {"config": config_path, "backup": backup_path}


def test_missing_config(isolated_config):
    assert check_config() == ConfigState.MISSING


def test_valid_config(isolated_config):
    from rewindex.config.loader import save_config
    save_config({"projects": [], "global_exclude": [], "cloud_backup": {"enabled": False, "auth_token": ""}})
    assert check_config() == ConfigState.OK


def test_corrupted_config_with_backup(isolated_config):
    from rewindex.config.loader import save_config
    # Write valid backup first
    save_config({"projects": [], "global_exclude": []})
    # Corrupt the main config
    with open(isolated_config["config"], "w") as f:
        f.write("{{ invalid yaml ::::")
    assert check_config() == ConfigState.CORRUPTED_WITH_BACKUP


def test_corrupted_config_no_backup(isolated_config):
    with open(isolated_config["config"], "w") as f:
        f.write("{{ invalid yaml ::::")
    assert check_config() == ConfigState.CORRUPTED_NO_BACKUP


def test_auto_restore_fixes_corrupted(isolated_config):
    from rewindex.config.loader import load_config, save_config
    save_config({"projects": [{"name": "x", "folder": "/tmp"}]})
    with open(isolated_config["config"], "w") as f:
        f.write("not: valid: yaml:::")

    restored, msg = auto_restore_if_needed()
    assert restored is True
    assert "restored" in msg.lower()

    config = load_config()
    assert config["projects"][0]["name"] == "x"
