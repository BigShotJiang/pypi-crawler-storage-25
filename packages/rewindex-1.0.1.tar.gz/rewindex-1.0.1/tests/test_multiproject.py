# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

"""
Tests for multi-project scenarios:
  - New project + new folder (independent)
  - New project + same folder (should be blocked)
  - Rewind across projects alternating
"""

import os

import pytest
from click.testing import CliRunner

from rewindex.db.connection import get_connection
from rewindex.snapshot.engine import snapshot_file
from rewindex.snapshot.reconstruct import reconstruct


# ── Fixture ───────────────────────────────────────────────────────────────────

@pytest.fixture()
def env(tmp_path, monkeypatch):
    rewindex_dir = tmp_path / ".rewindex"
    rewindex_dir.mkdir()
    snapshots_dir = rewindex_dir / "snapshots"
    snapshots_dir.mkdir()
    monkeypatch.setattr("rewindex.config.defaults.REWINDEX_DIR", str(rewindex_dir))
    monkeypatch.setattr("rewindex.config.defaults.SNAPSHOTS_DIR", str(snapshots_dir))

    folder_a = tmp_path / "project-a"
    folder_a.mkdir()
    folder_b = tmp_path / "project-b"
    folder_b.mkdir()

    conn_a = get_connection("proj-a")
    conn_b = get_connection("proj-b")

    return {
        "tmp": tmp_path,
        "folder_a": folder_a,
        "folder_b": folder_b,
        "conn_a": conn_a,
        "conn_b": conn_b,
    }


def _snap(conn, project_name, folder, filename, lines):
    path = folder / filename
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(lines))
    return snapshot_file(conn, project_name, str(folder), str(path))


def _reg_uid(conn, file_uid):
    row = conn.execute("SELECT file_registry_uid FROM file WHERE uid = ?", (file_uid,)).fetchone()
    return row["file_registry_uid"]


def _reconstruct_file(conn, project_name, folder, filename, target_uid):
    reg_uid = _reg_uid(conn, target_uid)
    return reconstruct(conn, reg_uid, target_uid)


def _rewind_file(conn, project_name, folder, filename, target_uid):
    """Simulate rewind by reconstructing and writing to disk."""
    lines = _reconstruct_file(conn, project_name, folder, filename, target_uid)
    abs_path = folder / filename
    os.makedirs(os.path.dirname(abs_path), exist_ok=True)
    with open(abs_path, "w", encoding="utf-8") as f:
        f.writelines(lines)


def _read(folder, filename):
    return (folder / filename).read_text().splitlines(keepends=True)


# ── New project + new folder: fully independent ───────────────────────────────

def test_two_projects_different_folders_independent_snapshots(env):
    """Each project sees only its own snapshots — no cross-contamination."""
    lines_a = ["# project A\n", "x = 1\n"]
    lines_b = ["# project B\n", "y = 2\n"]

    sid_a = _snap(env["conn_a"], "proj-a", env["folder_a"], "main.py", lines_a)
    sid_b = _snap(env["conn_b"], "proj-b", env["folder_b"], "main.py", lines_b)

    assert _reconstruct_file(env["conn_a"], "proj-a", env["folder_a"], "main.py", sid_a) == lines_a
    assert _reconstruct_file(env["conn_b"], "proj-b", env["folder_b"], "main.py", sid_b) == lines_b

    rows_a = env["conn_a"].execute(
        "SELECT * FROM file_registry WHERE project = 'proj-b'"
    ).fetchall()
    assert rows_a == []


def test_two_projects_same_filename_no_interference(env):
    """Same filename in two different project folders → separate snapshot chains."""
    v1_a = [f"A line {i}\n" for i in range(10)]
    v2_a = list(v1_a); v2_a[5] = "A MODIFIED\n"

    v1_b = [f"B line {i}\n" for i in range(10)]
    v2_b = list(v1_b); v2_b[5] = "B MODIFIED\n"

    sid_a1 = _snap(env["conn_a"], "proj-a", env["folder_a"], "shared_name.py", v1_a)
    sid_b1 = _snap(env["conn_b"], "proj-b", env["folder_b"], "shared_name.py", v1_b)
    sid_a2 = _snap(env["conn_a"], "proj-a", env["folder_a"], "shared_name.py", v2_a)
    sid_b2 = _snap(env["conn_b"], "proj-b", env["folder_b"], "shared_name.py", v2_b)

    assert _reconstruct_file(env["conn_a"], "proj-a", env["folder_a"], "shared_name.py", sid_a1) == v1_a
    assert _reconstruct_file(env["conn_a"], "proj-a", env["folder_a"], "shared_name.py", sid_a2) == v2_a
    assert _reconstruct_file(env["conn_b"], "proj-b", env["folder_b"], "shared_name.py", sid_b1) == v1_b
    assert _reconstruct_file(env["conn_b"], "proj-b", env["folder_b"], "shared_name.py", sid_b2) == v2_b


# ── Same folder: should be blocked ───────────────────────────────────────────

def test_init_blocks_duplicate_folder(env, monkeypatch):
    """_run_init must refuse to add a second project pointing to an already-watched folder."""
    folder = str(env["folder_a"])

    existing_config = {
        "projects": [{"name": "proj-a", "folders": [folder]}]
    }
    monkeypatch.setattr("rewindex.commands.init.config_exists", lambda: True)
    monkeypatch.setattr("rewindex.commands.init.load_config", lambda: existing_config)
    monkeypatch.setattr("rewindex.commands.init.save_config", lambda c: None)
    monkeypatch.setattr("rewindex.commands.init.restart_daemon", lambda c: None)
    monkeypatch.setattr("rewindex.version.init_rewindex_json", lambda: None)
    monkeypatch.setattr("rewindex.commands.init.REWINDEX_DIR", str(env["tmp"] / ".rewindex"))
    monkeypatch.setattr("rewindex.commands.init.SNAPSHOTS_DIR", str(env["tmp"] / ".rewindex" / "snapshots"))

    from click.testing import CliRunner
    from rewindex.commands.init import _run_init

    saved = []
    monkeypatch.setattr("rewindex.commands.init.save_config", lambda c: saved.append(c))

    _run_init("proj-duplicate", folder, interactive=False)

    assert saved == [], "save_config should not be called when folder is already in use"


def test_project_add_blocks_duplicate_folder(env, monkeypatch):
    """project add must refuse a folder already watched by another project."""
    folder = str(env["folder_a"])

    existing_config = {
        "projects": [{"name": "proj-a", "folders": [folder]}]
    }
    monkeypatch.setattr("rewindex.commands.project.load_config", lambda: existing_config)

    saved = []
    monkeypatch.setattr("rewindex.commands.project.save_config", lambda c: saved.append(c))

    from rewindex.commands.project import project_add
    runner = CliRunner()
    result = runner.invoke(project_add, ["proj-new", folder])

    assert saved == [], "save_config should not be called when folder is already in use"
    assert "already" in result.output.lower() or "in use" in result.output.lower()


def test_same_project_name_different_folder_updates_folder(env, monkeypatch):
    """Re-init with same project name but different folder → updates folder, no duplicate."""
    folder_a = str(env["folder_a"])
    folder_b = str(env["folder_b"])

    existing_config = {
        "projects": [{"name": "myproject", "folders": [folder_a]}]
    }
    monkeypatch.setattr("rewindex.commands.init.config_exists", lambda: True)
    monkeypatch.setattr("rewindex.commands.init.load_config", lambda: existing_config)
    monkeypatch.setattr("rewindex.commands.init.restart_daemon", lambda c: None)
    monkeypatch.setattr("rewindex.version.init_rewindex_json", lambda: None)
    monkeypatch.setattr("rewindex.commands.init.REWINDEX_DIR", str(env["tmp"] / ".rewindex"))
    monkeypatch.setattr("rewindex.commands.init.SNAPSHOTS_DIR", str(env["tmp"] / ".rewindex" / "snapshots"))

    saved = []
    monkeypatch.setattr("rewindex.commands.init.save_config", lambda c: saved.append(c))

    from rewindex.commands.init import _run_init
    _run_init("myproject", folder_b, interactive=False)

    assert len(saved) == 1
    projects = saved[0]["projects"]
    assert len(projects) == 1, "Should still be 1 project, not 2"
    assert folder_b in projects[0].get("folders", [projects[0].get("folder")])


# ── Rewind across projects alternating ───────────────────────────────────────

def test_rewind_alternating_projects(env):
    """
    Alternately rewind proj-a and proj-b to different versions.
    Each rewind must only affect its own project's files.
    """
    va = [[f"A-v{v} line {i}\n" for i in range(10)] for v in range(1, 5)]
    vb = [[f"B-v{v} line {i}\n" for i in range(10)] for v in range(1, 5)]

    ids_a = [_snap(env["conn_a"], "proj-a", env["folder_a"], "f.py", v) for v in va]
    ids_b = [_snap(env["conn_b"], "proj-b", env["folder_b"], "f.py", v) for v in vb]

    sequence = [
        ("a", 0), ("b", 2), ("a", 3), ("b", 0), ("a", 1), ("b", 3),
    ]

    for proj, version_idx in sequence:
        if proj == "a":
            _rewind_file(env["conn_a"], "proj-a", env["folder_a"], "f.py", ids_a[version_idx])
            assert _read(env["folder_a"], "f.py") == va[version_idx], \
                f"proj-a: expected v{version_idx + 1}"
        else:
            _rewind_file(env["conn_b"], "proj-b", env["folder_b"], "f.py", ids_b[version_idx])
            assert _read(env["folder_b"], "f.py") == vb[version_idx], \
                f"proj-b: expected v{version_idx + 1}"


def test_rewind_one_project_does_not_affect_other(env):
    """Rewinding proj-a never changes files in proj-b's folder."""
    lines_a = [f"A {i}\n" for i in range(5)]
    lines_b = [f"B {i}\n" for i in range(5)]

    ids_a = [_snap(env["conn_a"], "proj-a", env["folder_a"], "code.py", lines_a)]
    modified_a = list(lines_a); modified_a[0] = "A MODIFIED\n"
    ids_a.append(_snap(env["conn_a"], "proj-a", env["folder_a"], "code.py", modified_a))

    _snap(env["conn_b"], "proj-b", env["folder_b"], "code.py", lines_b)

    _rewind_file(env["conn_a"], "proj-a", env["folder_a"], "code.py", ids_a[0])

    assert _read(env["folder_a"], "code.py") == lines_a, "proj-a should be v1"
    assert _read(env["folder_b"], "code.py") == lines_b, "proj-b should be untouched"


def test_snapshot_history_per_project_independent(env):
    """
    After all operations, snapshot history of each project is fully intact
    and independent — no IDs shared, no cross-project reconstruct.
    """
    versions_a = [[f"A{v}-{i}\n" for i in range(8)] for v in range(5)]
    versions_b = [[f"B{v}-{i}\n" for i in range(8)] for v in range(5)]

    ids_a = [_snap(env["conn_a"], "proj-a", env["folder_a"], "app.py", v) for v in versions_a]
    ids_b = [_snap(env["conn_b"], "proj-b", env["folder_b"], "app.py", v) for v in versions_b]

    _rewind_file(env["conn_a"], "proj-a", env["folder_a"], "app.py", ids_a[2])
    _rewind_file(env["conn_b"], "proj-b", env["folder_b"], "app.py", ids_b[4])
    _rewind_file(env["conn_a"], "proj-a", env["folder_a"], "app.py", ids_a[0])
    _rewind_file(env["conn_b"], "proj-b", env["folder_b"], "app.py", ids_b[1])

    for i, (sid, expected) in enumerate(zip(ids_a, versions_a)):
        result = _reconstruct_file(env["conn_a"], "proj-a", env["folder_a"], "app.py", sid)
        assert result == expected, f"proj-a history v{i+1} corrupted"

    for i, (sid, expected) in enumerate(zip(ids_b, versions_b)):
        result = _reconstruct_file(env["conn_b"], "proj-b", env["folder_b"], "app.py", sid)
        assert result == expected, f"proj-b history v{i+1} corrupted"
