# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import pytest

from rewindex.db.connection import get_connection
from rewindex.db.queries import (
    get_or_create_file_registry,
    get_or_create_session,
    insert_file_version,
    finalize_file_version,
    get_file_version,
    get_latest_file_version,
    mark_corrupted,
)


@pytest.fixture()
def conn(tmp_path, monkeypatch):
    monkeypatch.setattr(
        "rewindex.config.defaults.SNAPSHOTS_DIR", str(tmp_path / "snapshots")
    )
    monkeypatch.setattr(
        "rewindex.db.connection.get_db_path",
        lambda name: str(tmp_path / f"{name}.db"),
    )
    c = get_connection("test")
    yield c
    c.close()


def _insert(conn, filepath="src/auth.py", is_full=True, idx=1):
    registry_uid, file_id, next_ver = get_or_create_file_registry(
        conn, "test", "/tmp/project", filepath
    )
    session_uid = get_or_create_session(conn, "test", "2026-04-13T10:00:00+00:00")
    file_uid = insert_file_version(
        conn,
        file_registry_uid=registry_uid,
        file_version=next_ver,
        created_at="2026-04-13T10:00:00+00:00",
        hash=f"hash{idx}",
        is_full=is_full,
        session_uid=session_uid,
    )
    finalize_file_version(conn, file_uid, f"/tmp/snap/{idx}/{filepath}.gz", 100 * idx)
    return file_uid


def test_insert_and_get(conn):
    uid = _insert(conn)
    row = get_file_version(conn, uid)
    assert row is not None
    assert row["is_full"] == 1
    assert row["hash"] == "hash1"


def test_get_latest_for_file(conn):
    _insert(conn, idx=1)
    uid2 = _insert(conn, is_full=False, idx=2)
    registry_uid, _, _ = get_or_create_file_registry(
        conn, "test", "/tmp/project", "src/auth.py"
    )
    latest = get_latest_file_version(conn, registry_uid)
    assert latest["uid"] == uid2


def test_mark_corrupted_excludes_from_queries(conn):
    uid = _insert(conn)
    mark_corrupted(conn, uid)
    row = get_file_version(conn, uid)
    assert row["is_corrupted"] == 1
    registry_uid, _, _ = get_or_create_file_registry(
        conn, "test", "/tmp/project", "src/auth.py"
    )
    assert get_latest_file_version(conn, registry_uid) is None
