# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

"""
Tests for non-linear rewind navigation:
  - Rewind back, change mind, rewind back to latest
  - Jump to N-3, then to latest, then to N-6, then to N-2
  - Arbitrary back-and-forth across many versions
"""

import os

import pytest

from rewindex.db.connection import get_connection
from rewindex.snapshot.engine import snapshot_file
from rewindex.snapshot.reconstruct import reconstruct


# ── Fixture ───────────────────────────────────────────────────────────────────

@pytest.fixture()
def proj(tmp_path, monkeypatch):
    rewindex_dir = tmp_path / ".rewindex"
    rewindex_dir.mkdir()
    monkeypatch.setattr("rewindex.config.defaults.REWINDEX_DIR", str(rewindex_dir))
    monkeypatch.setattr("rewindex.config.defaults.SNAPSHOTS_DIR", str(rewindex_dir / "snapshots"))

    folder = tmp_path / "project"
    folder.mkdir()
    conn = get_connection("nav")
    return {
        "name": "nav",
        "folder": folder,
        "conn": conn,
    }


def _snap(proj, filename, lines):
    path = proj["folder"] / filename
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(lines))
    return snapshot_file(proj["conn"], proj["name"], str(proj["folder"]), str(path))


def _reg_uid(conn, file_uid):
    row = conn.execute("SELECT file_registry_uid FROM file WHERE uid = ?", (file_uid,)).fetchone()
    return row["file_registry_uid"]


def _rewind_to(proj, filename, target_uid):
    """Simulate `rewindex rewind` — reconstruct and write file to disk."""
    reg_uid = _reg_uid(proj["conn"], target_uid)
    lines = reconstruct(proj["conn"], reg_uid, target_uid)
    abs_path = proj["folder"] / filename
    os.makedirs(os.path.dirname(abs_path), exist_ok=True)
    with open(abs_path, "w", encoding="utf-8") as f:
        f.writelines(lines)


def _read(proj, filename):
    return (proj["folder"] / filename).read_text().splitlines(keepends=True)


def _make_versions(n=7):
    """Generate n distinct versions of a file."""
    versions = []
    base = [f"line {i:03d}\n" for i in range(30)]
    versions.append(list(base))
    for step in range(1, n):
        v = list(versions[-1])
        v[step * 4 % 30] = f"# version {step + 1} edit (pos {step * 4 % 30})\n"
        versions.append(v)
    return versions


def _reconstruct(proj, filename, sid):
    reg_uid = _reg_uid(proj["conn"], sid)
    return reconstruct(proj["conn"], reg_uid, sid)


# ── Rewind back, change mind, return to latest ────────────────────────────────

def test_rewind_then_change_mind_back_to_latest(proj):
    versions = _make_versions(4)
    ids = [_snap(proj, "f.py", v) for v in versions]

    _rewind_to(proj, "f.py", ids[1])
    assert _read(proj, "f.py") == versions[1], "After rewind to v2: mismatch"

    _rewind_to(proj, "f.py", ids[3])
    assert _read(proj, "f.py") == versions[3], "After rewind back to latest (v4): mismatch"


def test_rewind_back_3_then_return_to_latest(proj):
    versions = _make_versions(7)
    ids = [_snap(proj, "f.py", v) for v in versions]

    _rewind_to(proj, "f.py", ids[3])
    assert _read(proj, "f.py") == versions[3], "After rewind to v4: mismatch"

    _rewind_to(proj, "f.py", ids[6])
    assert _read(proj, "f.py") == versions[6], "After return to latest (v7): mismatch"


# ── Complex non-linear navigation ─────────────────────────────────────────────

def test_rewind_n3_then_latest_then_n6_then_n2(proj):
    versions = _make_versions(8)
    ids = [_snap(proj, "nav.py", v) for v in versions]

    _rewind_to(proj, "nav.py", ids[4])
    assert _read(proj, "nav.py") == versions[4], "Step 1 (→v5): mismatch"

    _rewind_to(proj, "nav.py", ids[7])
    assert _read(proj, "nav.py") == versions[7], "Step 2 (→v8 latest): mismatch"

    _rewind_to(proj, "nav.py", ids[1])
    assert _read(proj, "nav.py") == versions[1], "Step 3 (→v2): mismatch"

    _rewind_to(proj, "nav.py", ids[5])
    assert _read(proj, "nav.py") == versions[5], "Step 4 (→v6): mismatch"


def test_random_order_navigation(proj):
    versions = _make_versions(10)
    ids = [_snap(proj, "rnd.py", v) for v in versions]

    nav_order = [4, 0, 8, 2, 9, 6, 1, 5, 7, 3]

    for step, idx in enumerate(nav_order):
        _rewind_to(proj, "rnd.py", ids[idx])
        actual = _read(proj, "rnd.py")
        assert actual == versions[idx], (
            f"Navigation step {step + 1}: expected v{idx + 1}, "
            f"first diff at line {next((i for i,(a,b) in enumerate(zip(actual, versions[idx])) if a != b), 'end')}"
        )


def test_rewind_preserves_other_file(proj):
    va_versions = _make_versions(5)
    vb = [f"B stable line {i}\n" for i in range(10)]

    ids_a = [_snap(proj, "a.py", v) for v in va_versions]
    _snap(proj, "b.py", vb)

    _rewind_to(proj, "a.py", ids_a[1])
    assert _read(proj, "b.py") == vb, "b.py changed after rewinding a.py to v2"

    _rewind_to(proj, "a.py", ids_a[4])
    assert _read(proj, "b.py") == vb, "b.py changed after rewinding a.py back to v5"

    _rewind_to(proj, "a.py", ids_a[0])
    assert _read(proj, "b.py") == vb, "b.py changed after rewinding a.py to v1"


def test_rewind_snapshot_history_intact_after_navigation(proj):
    versions = _make_versions(6)
    ids = [_snap(proj, "hist.py", v) for v in versions]

    _rewind_to(proj, "hist.py", ids[1])
    _rewind_to(proj, "hist.py", ids[5])
    _rewind_to(proj, "hist.py", ids[0])
    _rewind_to(proj, "hist.py", ids[3])

    for i, (sid, expected) in enumerate(zip(ids, versions)):
        result = _reconstruct(proj, "hist.py", sid)
        assert result == expected, f"History corrupted at v{i + 1} after navigation"
