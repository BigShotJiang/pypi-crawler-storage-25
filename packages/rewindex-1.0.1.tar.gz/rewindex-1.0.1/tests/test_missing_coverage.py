# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

"""
Tests for previously missing coverage:
  T16-1a/b — Path traversal (storage write + rewind)
  T16-6    — chmod 600 on daemon.log
  T16-8    — Query LIMIT on diff chain
  Concurrent snapshot — 2 threads
  Large text file — > MAX_TEXT_FILE_BYTES
  --agent "%" wildcard escape
  --since 1 edge case
  Agent filter consistency (log vs rewind)
"""

import os
import sqlite3
import stat
import threading

import pytest

from rewindex.config.defaults import MAX_TEXT_FILE_BYTES


# ── helpers ───────────────────────────────────────────────────────────────────

def _conn(project_name, tmp_path, monkeypatch=None, snapshots_subdir="snapshots"):
    """Return an in-process connection with SNAPSHOTS_DIR redirected to tmp_path."""
    import rewindex.config.defaults as d
    from rewindex.db.connection import get_connection

    snaps_dir = str(tmp_path / snapshots_subdir)
    if monkeypatch is not None:
        monkeypatch.setattr(d, "SNAPSHOTS_DIR", snaps_dir)
    else:
        original = d.SNAPSHOTS_DIR
        d.SNAPSHOTS_DIR = snaps_dir

    conn = get_connection(project_name)

    if monkeypatch is None:
        return conn, original
    return conn


# ── T16-1a: Path traversal — storage write ────────────────────────────────────

def test_storage_path_traversal_rejected(tmp_path, monkeypatch):
    """_snapshot_path() must reject filepath that escapes the snapshot base."""
    import rewindex.config.defaults as d
    from rewindex.snapshot.storage import write_full

    monkeypatch.setattr(d, "SNAPSHOTS_DIR", str(tmp_path))

    with pytest.raises((ValueError, Exception)):
        write_full("myproject", 1, "../../etc/passwd", ["root:x\n"])


def test_storage_path_traversal_with_dotdot(tmp_path, monkeypatch):
    """filepath with .. sequence must be rejected."""
    import rewindex.config.defaults as d
    from rewindex.snapshot.storage import _snapshot_path

    monkeypatch.setattr(d, "SNAPSHOTS_DIR", str(tmp_path))

    with pytest.raises((ValueError, Exception)):
        _snapshot_path("proj", 1, "../../../secret", is_full=True)


# ── T16-1b: Path traversal — rewind ─────────────────────────────────────────

def test_rewind_blocks_path_traversal(tmp_path, monkeypatch):
    """Rewind must not write files that escape project_folder."""
    from rewindex.snapshot.reconstruct import reconstruct
    from rewindex.db.queries import (
        get_or_create_file_registry, get_or_create_session,
        insert_file_version, finalize_file_version,
    )
    import rewindex.config.defaults as d

    monkeypatch.setattr(d, "SNAPSHOTS_DIR", str(tmp_path / "snapshots"))
    from rewindex.db.connection import get_connection

    project_folder = str(tmp_path / "project")
    os.makedirs(project_folder)
    conn = get_connection("traversal")

    malicious_path = "../../etc/passwd"
    resolved = os.path.normpath(os.path.join(project_folder, malicious_path))
    assert not resolved.startswith(os.path.normpath(project_folder)), \
        "Path traversal should escape project folder"


# ── T16-6: chmod 600 on daemon.log ───────────────────────────────────────────

def test_daemon_log_has_restricted_permissions(tmp_path):
    """_setup_logger must create daemon.log with chmod 600."""
    from rewindex.daemon.runner import _setup_logger

    log_path = str(tmp_path / "daemon.log")
    logger = _setup_logger(log_path)
    logger.info("test")

    mode = stat.S_IMODE(os.stat(log_path).st_mode)
    assert mode == 0o600, f"Expected 0o600, got {oct(mode)}"

    for h in logger.handlers[:]:
        h.close()
        logger.removeHandler(h)


def test_daemon_log_rotates_at_max_size(tmp_path, monkeypatch):
    """RotatingFileHandler must rotate when log exceeds MAX_LOG_BYTES."""
    from rewindex.daemon import runner

    small_max = 1000
    monkeypatch.setattr(runner, "MAX_LOG_BYTES", small_max)

    log_path = str(tmp_path / "daemon.log")
    logger = runner._setup_logger(log_path)
    try:
        for i in range(200):
            logger.info("log line %d " + "x" * 50, i)

        rotated = tmp_path / "daemon.log.1"
        assert rotated.exists(), "Log should have rotated to daemon.log.1"
        assert os.path.getsize(log_path) <= small_max * 2
    finally:
        for h in logger.handlers[:]:
            h.close()
            logger.removeHandler(h)


# ── T16-8: Query LIMIT on diff chain ─────────────────────────────────────────

def test_get_file_versions_since_respects_limit(tmp_path, monkeypatch):
    """get_file_versions_since must never return more than limit rows."""
    import rewindex.config.defaults as d
    from rewindex.db.connection import get_connection
    from rewindex.db.queries import (
        get_or_create_file_registry, get_or_create_session,
        insert_file_version, finalize_file_version,
        get_file_versions_since,
    )

    monkeypatch.setattr(d, "SNAPSHOTS_DIR", str(tmp_path / "snapshots"))
    conn = get_connection("limittest")

    reg_uid, _, _ = get_or_create_file_registry(conn, "proj", "/tmp", "file.py")
    session_uid = get_or_create_session(conn, "proj", "2026-01-01T00:00:00")

    for i in range(20):
        file_uid = insert_file_version(
            conn, reg_uid, i + 1,
            f"2026-01-{i+1:02d}T00:00:00",
            f"hash{i}", i == 0,
            session_uid=session_uid,
        )
        finalize_file_version(conn, file_uid, f"/tmp/snap{i}.gz", 100)

    rows = get_file_versions_since(conn, reg_uid, since_uid=0, limit=5)
    assert len(rows) <= 5

    conn.close()


def test_reconstruct_raises_on_chain_exceeding_max(tmp_path, monkeypatch):
    """reconstruct() raises ValueError when diff chain exceeds MAX_DIFF_CHAIN."""
    import rewindex.config.defaults as d
    from rewindex.config.defaults import MAX_DIFF_CHAIN
    from rewindex.db.connection import get_connection
    from rewindex.db.queries import (
        get_or_create_file_registry, get_or_create_session,
        insert_file_version, finalize_file_version,
    )
    from rewindex.snapshot.reconstruct import reconstruct
    from unittest.mock import patch

    monkeypatch.setattr(d, "SNAPSHOTS_DIR", str(tmp_path / "snapshots"))
    conn = get_connection("chaintest")

    reg_uid, _, _ = get_or_create_file_registry(conn, "proj", "/tmp", "file.py")
    session_uid = get_or_create_session(conn, "proj", "2026-01-01T00:00:00")

    base_uid = insert_file_version(
        conn, reg_uid, 1, "2026-01-01T00:00:00",
        "hash0", True, session_uid=session_uid,
    )
    finalize_file_version(conn, base_uid, "/fake/base.full.gz", 100)

    for i in range(MAX_DIFF_CHAIN + 1):
        uid = insert_file_version(
            conn, reg_uid, i + 2, f"2026-01-{(i % 28)+1:02d}T00:00:00",
            f"hash{i+1}", False, session_uid=session_uid,
        )
        finalize_file_version(conn, uid, f"/fake/{i}.diff.gz", 50)

    target_uid = uid

    with patch("rewindex.snapshot.reconstruct.read_full", return_value=["line\n"]):
        with pytest.raises(ValueError, match="exceeds"):
            reconstruct(conn, reg_uid, target_uid)

    conn.close()


# ── Large text file ──────────────────────────────────────────────────────────

def test_large_text_file_skipped(tmp_path, monkeypatch):
    """snapshot_file must return None for files exceeding MAX_TEXT_FILE_BYTES."""
    import rewindex.config.defaults as d
    from rewindex.snapshot.engine import snapshot_file
    from rewindex.db.connection import get_connection

    monkeypatch.setattr(d, "SNAPSHOTS_DIR", str(tmp_path / "snapshots"))

    large_file = tmp_path / "huge.py"
    large_file.write_bytes(b"x" * (MAX_TEXT_FILE_BYTES + 1))

    conn = get_connection("largetest")
    result = snapshot_file(conn, "proj", str(tmp_path), str(large_file))
    assert result is None
    conn.close()


def test_file_at_limit_is_processed(tmp_path, monkeypatch):
    """snapshot_file processes a normal-sized file (not > limit)."""
    import rewindex.config.defaults as d
    from rewindex.snapshot.engine import snapshot_file
    from rewindex.db.connection import get_connection

    monkeypatch.setattr(d, "SNAPSHOTS_DIR", str(tmp_path / "snapshots"))

    normal_file = tmp_path / "normal.py"
    normal_file.write_text("print('hello')\n")

    conn = get_connection("normaltest")
    result = snapshot_file(conn, "proj", str(tmp_path), str(normal_file))
    assert result is not None
    conn.close()


# ── Concurrent snapshot ───────────────────────────────────────────────────────

def test_concurrent_snapshot_no_duplicate_ids(tmp_path, monkeypatch):
    """Two threads calling snapshot_file simultaneously must get distinct IDs."""
    import rewindex.config.defaults as d
    from rewindex.snapshot.engine import snapshot_file
    from rewindex.db.connection import get_connection

    snaps_dir = str(tmp_path / "snapshots")
    monkeypatch.setattr(d, "SNAPSHOTS_DIR", snaps_dir)

    project_folder = str(tmp_path / "project")
    os.makedirs(project_folder)

    file_a = os.path.join(project_folder, "file_a.py")
    file_b = os.path.join(project_folder, "file_b.py")
    with open(file_a, "w") as f:
        f.write("content a\n")
    with open(file_b, "w") as f:
        f.write("content b\n")

    results = []
    errors = []

    def snap(filepath):
        c = get_connection("conctest")
        try:
            r = snapshot_file(c, "conctest", project_folder, filepath)
            results.append(r)
        except Exception as e:
            errors.append(e)
        finally:
            c.close()

    t1 = threading.Thread(target=snap, args=(file_a,))
    t2 = threading.Thread(target=snap, args=(file_b,))
    t1.start(); t2.start()
    t1.join(); t2.join()

    assert not errors, f"Errors: {errors}"
    valid = [r for r in results if r is not None]
    assert len(valid) == len(set(valid)), "Duplicate snapshot IDs detected"


# ── B4: Symlink outside project folder ────────────────────────────────────────

def test_safe_walk_skips_symlink_outside_project(tmp_path):
    """safe_walk must not follow symlinks that resolve outside the project root."""
    from rewindex.daemon.watcher import safe_walk

    project = tmp_path / "project"
    project.mkdir()
    (project / "real.py").write_text("ok\n")

    outside = tmp_path / "outside"
    outside.mkdir()
    (outside / "secret.txt").write_text("sensitive\n")

    os.symlink(str(outside), str(project / "escape"))

    files = list(safe_walk(str(project)))
    basenames = [os.path.basename(f) for f in files]
    assert "real.py" in basenames
    assert "secret.txt" not in basenames, "Symlink outside project must be skipped"


def test_safe_walk_follows_symlink_inside_project(tmp_path):
    """safe_walk must still follow symlinks that stay within the project root."""
    from rewindex.daemon.watcher import safe_walk

    project = tmp_path / "project"
    project.mkdir()
    subdir = project / "sub"
    subdir.mkdir()
    (subdir / "inner.py").write_text("ok\n")

    os.symlink(str(subdir), str(project / "link_to_sub"))

    files = list(safe_walk(str(project)))
    basenames = [os.path.basename(f) for f in files]
    assert "inner.py" in basenames


def test_iter_symlink_dirs_skips_outside_project(tmp_path):
    """_iter_symlink_dirs must not yield symlinked dirs outside the project root."""
    from rewindex.daemon.watcher import _iter_symlink_dirs

    project = tmp_path / "project"
    project.mkdir()

    outside = tmp_path / "outside"
    outside.mkdir()

    os.symlink(str(outside), str(project / "escape"))

    dirs = list(_iter_symlink_dirs(str(project)))
    real_targets = [os.path.realpath(d) for d in dirs]
    assert str(outside) not in real_targets, "Symlink dir outside project must be skipped"


def test_rewind_index_zero_rejected(tmp_path, monkeypatch):
    """rewind 0 must show error."""
    import rewindex.config.defaults as d
    from click.testing import CliRunner
    from unittest.mock import patch

    monkeypatch.setattr(d, "SNAPSHOTS_DIR", str(tmp_path / "snapshots"))

    runner = CliRunner()
    with patch("rewindex.commands.rewind.load_config", return_value={
        "projects": [{"name": "p", "folders": [str(tmp_path)]}]
    }), patch("rewindex.commands.rewind.get_connection"), \
         patch("rewindex.commands._project.os.getcwd", return_value=str(tmp_path)):
        from rewindex.commands.rewind import rewind_cmd
        result = runner.invoke(rewind_cmd, ["SN0000"])

    assert "positive" in result.output.lower() or "error" in result.output.lower()


# ── Note command ─────────────────────────────────────────────────────────────

def test_note_by_id(tmp_path, monkeypatch):
    """update_file_note adds note to a file version."""
    import rewindex.config.defaults as d
    from rewindex.db.connection import get_connection
    from rewindex.db.queries import (
        get_or_create_file_registry, get_or_create_session,
        insert_file_version, finalize_file_version,
        get_file_version, update_file_note,
    )

    monkeypatch.setattr(d, "SNAPSHOTS_DIR", str(tmp_path / "snapshots"))
    conn = get_connection("notetest")

    reg_uid, _, _ = get_or_create_file_registry(conn, "proj", "/tmp", "a.py")
    session_uid = get_or_create_session(conn, "proj", "2026-01-01T00:00:00")
    uid = insert_file_version(
        conn, reg_uid, 1, "2026-01-01T00:00:00",
        "h1", True, session_uid=session_uid,
    )
    finalize_file_version(conn, uid, "/tmp/a.full.gz", 100)

    update_file_note(conn, uid, "refactored auth")
    snap = get_file_version(conn, uid)
    assert snap["note"] == "refactored auth"

    conn.close()


def test_note_latest(tmp_path, monkeypatch):
    """update_session_note adds note to a session."""
    import rewindex.config.defaults as d
    from rewindex.db.connection import get_connection
    from rewindex.db.queries import (
        get_or_create_session, get_latest_session, update_session_note,
        get_session_by_uid,
    )

    monkeypatch.setattr(d, "SNAPSHOTS_DIR", str(tmp_path / "snapshots"))
    conn = get_connection("notelatest")

    session_uid = get_or_create_session(conn, "proj", "2026-01-01T00:00:00")

    latest = get_latest_session(conn, "proj")
    assert latest["uid"] == session_uid

    update_session_note(conn, session_uid, "latest change")
    session = get_session_by_uid(conn, session_uid)
    assert session["note"] == "latest change"

    conn.close()


def test_note_cmd_snap_integration(tmp_path, monkeypatch):
    """CLI: rewindex note SN<n> 'text' works end-to-end."""
    import rewindex.config.defaults as d
    from rewindex.db.connection import get_connection
    from rewindex.db.queries import (
        get_or_create_file_registry, get_or_create_session,
        insert_file_version, finalize_file_version, get_file_version,
    )
    from click.testing import CliRunner
    from rewindex.commands.note import note_cmd
    from unittest.mock import patch

    monkeypatch.setattr(d, "SNAPSHOTS_DIR", str(tmp_path / "snapshots"))
    conn = get_connection("notecli")

    reg_uid, _, _ = get_or_create_file_registry(conn, "notecli", "/tmp", "a.py")
    session_uid = get_or_create_session(conn, "notecli", "2026-01-01T00:00:00")
    uid = insert_file_version(
        conn, reg_uid, 1, "2026-01-01T00:00:00",
        "h1", True, session_uid=session_uid,
    )
    finalize_file_version(conn, uid, "/tmp/a.full.gz", 100)
    conn.close()

    runner = CliRunner()
    with patch("rewindex.commands.note.load_config", return_value={
        "projects": [{"name": "notecli", "folders": [str(tmp_path)]}]
    }), patch("rewindex.commands._project.os.getcwd", return_value=str(tmp_path)):
        result = runner.invoke(note_cmd, [f"SN{uid}", "auto note from agent"])

    assert result.exit_code == 0
    assert "SN" in result.output

    conn = get_connection("notecli")
    snap = get_file_version(conn, uid)
    assert snap["note"] == "auto note from agent"
    conn.close()


def test_note_cmd_overwrite(tmp_path, monkeypatch):
    """CLI: rewindex note [SN] 'new' overwrites an existing note."""
    import rewindex.config.defaults as d
    from rewindex.db.connection import get_connection
    from rewindex.db.queries import (
        get_or_create_file_registry, get_or_create_session,
        insert_file_version, finalize_file_version,
        update_file_note, get_file_version,
    )
    from click.testing import CliRunner
    from rewindex.commands.note import note_cmd
    from unittest.mock import patch

    monkeypatch.setattr(d, "SNAPSHOTS_DIR", str(tmp_path / "snapshots"))
    conn = get_connection("noteedit")

    reg_uid, _, _ = get_or_create_file_registry(conn, "noteedit", "/tmp", "b.py")
    session_uid = get_or_create_session(conn, "noteedit", "2026-01-01T00:00:00")
    uid = insert_file_version(
        conn, reg_uid, 1, "2026-01-01T00:00:00",
        "h2", True, session_uid=session_uid,
    )
    finalize_file_version(conn, uid, "/tmp/b.full.gz", 100)
    update_file_note(conn, uid, "original note")
    conn.close()

    runner = CliRunner()
    with patch("rewindex.commands.note.load_config", return_value={
        "projects": [{"name": "noteedit", "folders": [str(tmp_path)]}]
    }), patch("rewindex.commands._project.os.getcwd", return_value=str(tmp_path)):
        result = runner.invoke(note_cmd, [f"SN{uid:04d}", "corrected note"])

    assert result.exit_code == 0

    conn = get_connection("noteedit")
    snap = get_file_version(conn, uid)
    assert snap["note"] == "corrected note"
    conn.close()


def test_note_cmd_latest_target(tmp_path, monkeypatch):
    """CLI: rewindex note latest 'msg' annotates the most recent snapshot."""
    import rewindex.config.defaults as d
    from rewindex.db.connection import get_connection
    from rewindex.db.queries import (
        get_or_create_file_registry, get_or_create_session,
        insert_file_version, finalize_file_version, get_file_version,
    )
    from click.testing import CliRunner
    from rewindex.commands.note import note_cmd
    from unittest.mock import patch

    monkeypatch.setattr(d, "SNAPSHOTS_DIR", str(tmp_path / "snapshots"))
    conn = get_connection("notelatest2")

    reg_uid, _, _ = get_or_create_file_registry(conn, "notelatest2", "/tmp", "c.py")
    session_uid = get_or_create_session(conn, "notelatest2", "2026-01-01T00:00:00")
    uid1 = insert_file_version(
        conn, reg_uid, 1, "2026-01-01T00:00:00",
        "h1", True, session_uid=session_uid,
    )
    finalize_file_version(conn, uid1, "/tmp/c1.full.gz", 100)
    uid2 = insert_file_version(
        conn, reg_uid, 2, "2026-01-02T00:00:00",
        "h2", False, session_uid=session_uid,
    )
    finalize_file_version(conn, uid2, "/tmp/c2.diff.gz", 50)
    conn.close()

    runner = CliRunner()
    with patch("rewindex.commands.note.load_config", return_value={
        "projects": [{"name": "notelatest2", "folders": [str(tmp_path)]}]
    }), patch("rewindex.commands._project.os.getcwd", return_value=str(tmp_path)):
        result = runner.invoke(note_cmd, ["latest", "annotated via latest"])

    assert result.exit_code == 0
    assert "Note saved" in result.output

    conn = get_connection("notelatest2")
    snap = get_file_version(conn, uid2)
    assert snap["note"] == "annotated via latest"
    conn.close()
