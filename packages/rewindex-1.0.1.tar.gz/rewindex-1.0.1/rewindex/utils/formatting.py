# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import re
from datetime import datetime, timezone


def sanitize(value: str) -> str:
    """Strip ANSI escape codes and newlines to prevent log injection."""
    value = re.sub(r"\x1b\[[0-9;]*[a-zA-Z]", "", value)
    return value.replace("\n", " ").replace("\r", " ")


def fmt_date(utc_iso: str) -> str:
    """Progressive date format per v2 spec:
    Same day → HH:MM / Same year, different day → DD/MM HH:MM / Different year → DD/MM/YY HH:MM
    All times are UTC+0."""
    try:
        dt = datetime.fromisoformat(utc_iso.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        dt_utc = dt.astimezone(timezone.utc)
        now_utc = datetime.now(timezone.utc)

        if dt_utc.date() == now_utc.date():
            return dt_utc.strftime("%H:%M")
        elif dt_utc.year == now_utc.year:
            return dt_utc.strftime("%d/%m %H:%M")
        else:
            return dt_utc.strftime("%d/%m/%y %H:%M")
    except Exception:
        return utc_iso[:16].replace("T", " ")


def fmt_date_header() -> str:
    """Return date format hint: '(DD/MM/YY UTC+0)'."""
    return "(DD/MM/YY UTC+0)"


def fmt_date_full(utc_iso: str) -> str:
    """Full date for display: DD/MM/YY HH:MM always."""
    try:
        dt = datetime.fromisoformat(utc_iso.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        dt_utc = dt.astimezone(timezone.utc)
        return dt_utc.strftime("%d/%m/%y %H:%M")
    except Exception:
        return utc_iso[:16].replace("T", " ")
