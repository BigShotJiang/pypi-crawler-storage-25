# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

"""
ID parsing helpers for Rewindex v2 CLI.

Accepted formats:
  Snap ID    — SN42 (file.uid, no zero-padding)
  FileID     — D1VS (4-char alphanumeric, stable for file lifetime)
  Session ID — SS3 (sessions.uid, no zero-padding)
  Project    — PJ1 or project name
  Relative   — SN -1, SN -5 (relative snap rewind)
"""

import re
import sqlite3
from typing import Optional


def parse_snap_id(value: str) -> int:
    """Parse Snap ID: SN42 → 42. No zero-padding in v2."""
    s = str(value).strip()
    if not s.upper().startswith("SN"):
        raise ValueError(f'Invalid Snap ID "{value}". Expected format: SN42')
    inner = s[2:]
    try:
        n = int(inner)
    except ValueError:
        raise ValueError(f'Invalid Snap ID "{value}". Expected format: SN42')
    if n < 1:
        raise ValueError(f'Invalid Snap ID "{value}". Snap IDs start at SN1.')
    return n


def parse_relative_snap(value: str) -> Optional[int]:
    """Parse relative snap: 'SN -3' or '-3' → 3 (how many back). Returns None if not relative."""
    s = str(value).strip()
    m = re.match(r'^SN\s*-(\d+)$', s, re.IGNORECASE)
    if m:
        n = int(m.group(1))
        if n < 1:
            raise ValueError('Relative snap must be at least SN -1.')
        return n
    return None


def parse_session_id(value: str) -> int:
    """Parse session ID: SS3 → 3. No zero-padding in v2."""
    s = str(value).strip()
    if not s.upper().startswith("SS"):
        raise ValueError(f'Invalid session ID "{value}". Expected format: SS3')
    try:
        n = int(s[2:])
    except ValueError:
        raise ValueError(f'Invalid session ID "{value}". Expected format: SS3')
    if n < 1:
        raise ValueError(f'Invalid session ID "{value}". Session IDs start at SS1.')
    return n


def parse_file_id_version(value: str, version_str: Optional[str] = None) -> tuple[str, Optional[int]]:
    """Parse FileID and optional version.
    Returns (file_id, version) where version is None if 'latest' or not specified."""
    file_id = value.strip().upper()
    if not re.match(r'^[A-Z0-9]{4}$', file_id):
        raise ValueError(f'Invalid FileID "{value}". Expected 4-char alphanumeric (e.g. D1VS).')

    if version_str is None:
        return file_id, None

    vs = version_str.strip().lower()
    if vs == "latest":
        return file_id, None

    m = re.match(r'^v?(\d+)$', vs)
    if m:
        return file_id, int(m.group(1))

    raise ValueError(f'Invalid version "{version_str}". Expected vN or "latest".')


def parse_project_ref(value: str, projects: list) -> str | None:
    """Parse project reference: PJ1 → project name. No zero-padding in v2."""
    s = str(value).strip()
    if s.upper().startswith("PJ"):
        try:
            idx = int(s[2:]) - 1
        except ValueError:
            return value
        if 0 <= idx < len(projects):
            return projects[idx]["name"]
        return None
    return value


def is_session_target(value: str) -> bool:
    """Check if a string looks like a session target (SS...)."""
    return value.strip().upper().startswith("SS")


def is_snap_target(value: str) -> bool:
    """Check if a string looks like a snap target (SN...)."""
    return value.strip().upper().startswith("SN")


def is_file_id(value: str) -> bool:
    """Check if a string looks like a 4-char FileID."""
    return bool(re.match(r'^[A-Za-z0-9]{4}$', value.strip()))


# --- Display formatters (no zero-padding in v2) ---

def fmt_snap(snap_id: int) -> str:
    """Format Snap ID for display: 42 → 'SN42'."""
    return f"SN{snap_id}"


def fmt_session(session_id: int) -> str:
    """Format Session ID for display: 3 → 'SS3'."""
    return f"SS{session_id}"


def fmt_project(index: int) -> str:
    """Format project ID for display: 1 → 'PJ1' (1-based)."""
    return f"PJ{index}"
