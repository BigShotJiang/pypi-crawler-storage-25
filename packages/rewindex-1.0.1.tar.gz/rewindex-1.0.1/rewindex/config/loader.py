# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import os
import shutil
import yaml

from .defaults import CONFIG_PATH, CONFIG_BACKUP_PATH, DEFAULT_CONFIG, MAX_CONFIG_FILE_BYTES


def load_config() -> dict:
    try:
        if os.path.getsize(CONFIG_PATH) > MAX_CONFIG_FILE_BYTES:
            raise yaml.YAMLError("Config file too large")
        with open(CONFIG_PATH, "r") as f:
            data = yaml.safe_load(f) or {}
        return _merge_defaults(data)
    except (OSError, yaml.YAMLError):
        if backup_exists():
            return restore_from_backup()
        return _merge_defaults({})


def save_config(config: dict) -> None:
    os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
    with open(CONFIG_PATH, "w") as f:
        yaml.dump(config, f, default_flow_style=False, allow_unicode=True)
    os.chmod(CONFIG_PATH, 0o600)
    # overwrite backup on every successful save
    shutil.copy2(CONFIG_PATH, CONFIG_BACKUP_PATH)
    os.chmod(CONFIG_BACKUP_PATH, 0o600)


def config_exists() -> bool:
    return os.path.exists(CONFIG_PATH)


def backup_exists() -> bool:
    return os.path.exists(CONFIG_BACKUP_PATH)


def load_backup() -> dict:
    with open(CONFIG_BACKUP_PATH, "r") as f:
        data = yaml.safe_load(f) or {}
    return _merge_defaults(data)


def restore_from_backup() -> dict:
    config = load_backup()
    save_config(config)
    return config


def _merge_defaults(data: dict) -> dict:
    merged = dict(DEFAULT_CONFIG)
    merged.update(data)
    # Migrate legacy single-folder projects to folders array
    for project in merged.get("projects", []):
        if "folder" in project and "folders" not in project:
            project["folders"] = [project["folder"]]
        project.pop("folder", None)  # always remove legacy key
    return merged
