# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import yaml

from .defaults import CONFIG_PATH, CONFIG_BACKUP_PATH
from .loader import backup_exists, restore_from_backup


class ConfigState:
    OK = "ok"
    MISSING = "missing"
    CORRUPTED_WITH_BACKUP = "corrupted_with_backup"
    CORRUPTED_NO_BACKUP = "corrupted_no_backup"


def check_config() -> str:
    from .loader import config_exists

    if not config_exists():
        return ConfigState.MISSING

    if not _is_valid_yaml(CONFIG_PATH):
        if backup_exists() and _is_valid_yaml(CONFIG_BACKUP_PATH):
            return ConfigState.CORRUPTED_WITH_BACKUP
        return ConfigState.CORRUPTED_NO_BACKUP

    return ConfigState.OK


def _is_valid_yaml(path: str) -> bool:
    try:
        with open(path, "r") as f:
            data = yaml.safe_load(f)
        return isinstance(data, dict)
    except Exception:
        return False


def auto_restore_if_needed() -> tuple[bool, str]:
    """
    Returns (restored: bool, message: str).
    Call this in main() before running any command.
    """
    state = check_config()

    if state == ConfigState.OK:
        return False, ""

    if state == ConfigState.MISSING:
        return False, "Rewindex is not set up yet. Run `rewindex init` to get started."

    if state == ConfigState.CORRUPTED_WITH_BACKUP:
        restore_from_backup()
        return True, "Config was corrupted — restored from backup automatically."

    return False, "Config corrupted and no backup found. Run `rewindex init` to reconfigure."
