# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

try:
    from importlib.metadata import version as _pkg_version
    __version__ = _pkg_version("rewindex")
except Exception:
    from rewindex.version import _DEFAULT
    __version__ = _DEFAULT.get("rewindex_version", "0.0.0")
