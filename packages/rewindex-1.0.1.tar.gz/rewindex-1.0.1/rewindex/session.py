# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

from datetime import datetime, timezone


def group_into_sessions(
    rows: list,
    gap_seconds: float = 20.0,
    break_times: list[str] | None = None,
) -> list[dict]:
    """
    Group snapshot rows into sessions based on time gap.
    Rules:
      - gap > threshold → new session
      - A recorded session break (from snap --session) between two snapshots → new session

    Returns list of session dicts (oldest first, newest at end):
      {
        "id": int (session number, 1-based from oldest),
        "start": str (ISO),
        "end": str (ISO),
        "files": list[str] (unique filepaths),
        "snapshots": list[Row],
        "file_count": int,
      }
    """
    if not rows:
        return []

    sorted_rows = sorted(rows, key=lambda r: r["id"])
    parsed_breaks = sorted(_parse_time(t) for t in (break_times or []))

    sessions = []
    current = {
        "start": sorted_rows[0]["created_at"],
        "end": sorted_rows[0]["created_at"],
        "files": [],
        "snapshots": [sorted_rows[0]],
    }
    _add_file(current, sorted_rows[0]["filepath"])

    for row in sorted_rows[1:]:
        prev_time = _parse_time(current["end"])
        curr_time = _parse_time(row["created_at"])
        gap = (curr_time - prev_time).total_seconds()

        forced_break = any(prev_time < bt <= curr_time for bt in parsed_breaks)

        if forced_break or gap > gap_seconds:
            sessions.append(current)
            current = {
                "start": row["created_at"],
                "end": row["created_at"],
                "files": [],
                "snapshots": [row],
            }
            _add_file(current, row["filepath"])
        else:
            current["end"] = row["created_at"]
            current["snapshots"].append(row)
            _add_file(current, row["filepath"])

    sessions.append(current)

    for i, s in enumerate(sessions, 1):
        s["id"] = i
        s["file_count"] = len(s["files"])

    return sessions


def _add_file(session: dict, filepath: str) -> None:
    if filepath not in session["files"]:
        session["files"].append(filepath)


def _parse_time(iso: str) -> datetime:
    dt = datetime.fromisoformat(iso)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt
