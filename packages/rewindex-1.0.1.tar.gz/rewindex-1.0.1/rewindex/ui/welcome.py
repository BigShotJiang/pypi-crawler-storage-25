# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text


_LOGO_LINES = [
    "██████╗ ███████╗██╗    ██╗██╗███╗   ██╗██████╗ ███████╗██╗  ██╗",
    "██╔══██╗██╔════╝██║    ██║██║████╗  ██║██╔══██╗██╔════╝╚██╗██╔╝",
    "██████╔╝█████╗  ██║ █╗ ██║██║██╔██╗ ██║██║  ██║█████╗   ╚███╔╝ ",
    "██╔══██╗██╔══╝  ██║███╗██║██║██║╚██╗██║██║  ██║██╔══╝   ██╔██╗ ",
    "██║  ██║███████╗╚███╔███╔╝██║██║ ╚████║██████╔╝███████╗██╔╝ ██╗",
    "╚═╝  ╚═╝╚══════╝ ╚══╝╚══╝ ╚═╝╚═╝  ╚═══╝╚═════╝ ╚══════╝╚═╝  ╚═╝",
]

_LOGO_COLORS = [
    "bold bright_cyan",
    "bold bright_cyan",
    "bold cyan",
    "bold cyan",
    "bold blue",
    "bold blue",
]

_COMMANDS = [
    ("  rewindex log", "view snapshot history"),
    ("  rewindex diff [N]", "inspect a change"),
    ("  rewindex rewind [N]", "restore a file"),
    ('  rewindex note latest "…"', "annotate what you changed"),
    ("  rewindex status", "daemon status + disk usage"),
    ("  rewindex snap", "manual checkpoint"),
    ("  rewindex project", "list watched projects"),
    ("  rewindex --help", "full command reference"),
]


def _build_logo() -> Text:
    logo = Text()
    for line, style in zip(_LOGO_LINES, _LOGO_COLORS):
        logo.append(line + "\n", style=style)
    return logo


def _build_info_panel(project_name: str, version: str) -> Panel:
    content = Text()
    content.append(">_ Rewindex", style="bold bright_green")
    content.append(f"  (v{version})\n\n", style="dim")
    content.append("Watching: ", style="dim")
    content.append(project_name + "\n\n", style="bold white")
    content.append("Version control for AI agents.\n", style="dim italic")
    content.append("Every change saved. Every mistake undone.", style="dim italic")
    return Panel(content, border_style="cyan", padding=(0, 2))


def _build_ref_table() -> Table:
    ref = Table(show_header=False, box=None, padding=(0, 1))
    ref.add_column(style="bold cyan", no_wrap=True, min_width=28)
    ref.add_column(style="dim")
    for cmd, desc in _COMMANDS:
        ref.add_row(cmd, f"— {desc}")
    return ref


def show_logo() -> None:
    console = Console()
    console.print()
    console.print(_build_logo())
    try:
        from importlib.metadata import version as pkg_version
        ver = pkg_version("rewindex")
    except Exception:
        from rewindex.version import _DEFAULT
        ver = _DEFAULT.get("rewindex_version", "?")
    console.print(f"  [dim]v{ver}  •  File snapshot tool  •  rewindex.org[/dim]")
    console.print()


def show_welcome(project_name: str) -> None:
    try:
        from importlib.metadata import version as pkg_version
        ver = pkg_version("rewindex")
    except Exception:
        from rewindex.version import _DEFAULT
        ver = _DEFAULT.get("rewindex_version", "?")

    console = Console()

    console.print()

    # Responsive: side-by-side on wide terminals, stacked on narrow
    if console.width >= 115:
        grid = Table.grid(padding=(0, 2))
        grid.add_column(no_wrap=True)
        grid.add_column(no_wrap=False, min_width=44)
        grid.add_row(_build_logo(), _build_info_panel(project_name, ver))
        console.print(grid)
    else:
        console.print(_build_logo())
        console.print(_build_info_panel(project_name, ver))

    console.print()
    console.print(_build_ref_table())
    console.print()
    console.print("  [dim]Git = milestones.  Rewindex = safety net in between.[/dim]")
    console.print()
