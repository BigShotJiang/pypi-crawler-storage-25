# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

# v2: rewind is always non-interactive (--yes required).
# This module is kept for potential future interactive use.
