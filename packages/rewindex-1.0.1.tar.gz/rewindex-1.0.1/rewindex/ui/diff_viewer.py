# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import difflib
import re

import click
from rich.console import Console
from rich.text import Text

_console = Console(highlight=False)


def print_diff(
    old_lines: list[str], new_lines: list[str],
    file_id: str = "", filepath: str = "",
    from_ver: int = 0, to_ver: int = 0,
) -> None:
    """v2 diff output: FileID filepath v_from → v_to."""
    old = [l.rstrip("\n") for l in old_lines]
    new = [l.rstrip("\n") for l in new_lines]

    diff = list(difflib.unified_diff(old, new, lineterm="", n=2))

    if not diff:
        click.echo(f"  {file_id}  {filepath}  v{from_ver} → v{to_ver}  — no changes")
        return

    added = sum(1 for l in diff if l.startswith("+") and not l.startswith("+++"))
    removed = sum(1 for l in diff if l.startswith("-") and not l.startswith("---"))

    parts = []
    if added:
        parts.append(click.style(f"Added {added} line{'s' if added != 1 else ''}", fg="green"))
    if removed:
        parts.append(click.style(f"Removed {removed} line{'s' if removed != 1 else ''}", fg="red"))
    summary = "   " + ", ".join(parts) if parts else ""

    click.echo(f"\n⎿  {file_id}  {filepath}  v{from_ver} → v{to_ver}{summary}\n")

    old_lineno = new_lineno = 0

    for line in diff:
        if line.startswith("---") or line.startswith("+++"):
            continue
        if line.startswith("@@"):
            m = re.search(r"-(\d+).*\+(\d+)", line)
            if m:
                old_lineno = int(m.group(1))
                new_lineno = int(m.group(2))
            continue
        if line.startswith("+"):
            t = Text(style="on rgb(0,48,0)")
            t.append(f"{new_lineno:>4}  +    ", style="bold green")
            t.append(line[1:], style="bold")
            t.pad_right(_console.width)
            _console.print(t)
            new_lineno += 1
        elif line.startswith("-"):
            t = Text(style="on rgb(64,0,0)")
            t.append(f"{old_lineno:>4}  -    ", style="bold red")
            t.append(line[1:], style="bold")
            t.pad_right(_console.width)
            _console.print(t)
            old_lineno += 1
        else:
            t = Text(f"{new_lineno:>4}   {line[1:]}", style="dim")
            _console.print(t)
            old_lineno += 1
            new_lineno += 1

    click.echo()


def show_diff(filepath: str, old_lines: list[str], new_lines: list[str], index: int) -> None:
    """Render diff with full-width background highlights using rich."""
    old = [l.rstrip("\n") for l in old_lines]
    new = [l.rstrip("\n") for l in new_lines]

    diff = list(difflib.unified_diff(old, new, lineterm="", n=2))

    if not diff:
        from rewindex.utils.id_parse import fmt_snap
        click.echo(f"  {fmt_snap(index)}  {filepath}  — no changes")
        return

    added = sum(1 for l in diff if l.startswith("+") and not l.startswith("+++"))
    removed = sum(1 for l in diff if l.startswith("-") and not l.startswith("---"))

    parts = []
    if added:
        parts.append(click.style(f"Added {added} line{'s' if added != 1 else ''}", fg="green"))
    if removed:
        parts.append(click.style(f"Removed {removed} line{'s' if removed != 1 else ''}", fg="red"))
    summary = "  " + ", ".join(parts) if parts else ""

    from rewindex.utils.id_parse import fmt_snap
    click.echo(f"\n⎿  {fmt_snap(index)}  {filepath}{summary}\n")

    old_lineno = new_lineno = 0

    for line in diff:
        if line.startswith("---") or line.startswith("+++"):
            continue

        if line.startswith("@@"):
            m = re.search(r"-(\d+).*\+(\d+)", line)
            if m:
                old_lineno = int(m.group(1))
                new_lineno = int(m.group(2))
            continue

        if line.startswith("+"):
            t = Text(style="on rgb(0,48,0)")
            t.append(f"{new_lineno:>4}  +    ", style="bold green")
            t.append(line[1:], style="bold")
            t.pad_right(_console.width)
            _console.print(t)
            new_lineno += 1
        elif line.startswith("-"):
            t = Text(style="on rgb(64,0,0)")
            t.append(f"{old_lineno:>4}  -    ", style="bold red")
            t.append(line[1:], style="bold")
            t.pad_right(_console.width)
            _console.print(t)
            old_lineno += 1
        else:
            t = Text(f"{new_lineno:>4}   {line[1:]}", style="dim")
            _console.print(t)
            old_lineno += 1
            new_lineno += 1

    click.echo()
