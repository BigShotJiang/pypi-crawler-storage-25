# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import os
import sqlite3

from .schema import (
    CREATE_FILE,
    CREATE_FILE_REGISTRY,
    CREATE_META,
    CREATE_SESSIONS,
    SCHEMA_VERSION,
)


def get_db_path(project_name: str) -> str:
    from rewindex.config.defaults import SNAPSHOTS_DIR
    return os.path.join(SNAPSHOTS_DIR, project_name, "rewindex.db")


def get_connection(project_name: str) -> sqlite3.Connection:
    db_path = get_db_path(project_name)
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA foreign_keys=ON;")
    _init_schema(conn)
    return conn


def _init_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(CREATE_META)
    row = conn.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
    current = int(row["value"]) if row else 0

    if current < SCHEMA_VERSION:
        conn.executescript(CREATE_SESSIONS)
        conn.executescript(CREATE_FILE_REGISTRY)
        conn.executescript(CREATE_FILE)

        if current == 3:
            try:
                conn.execute("ALTER TABLE file ADD COLUMN promoted_by TEXT DEFAULT NULL")
            except sqlite3.OperationalError:
                pass

        if current <= 4:
            try:
                conn.execute("ALTER TABLE file ADD COLUMN filepath TEXT DEFAULT NULL")
            except sqlite3.OperationalError:
                pass
            conn.execute(
                "UPDATE file SET filepath = ("
                "  SELECT fr.filepath FROM file_registry fr"
                "  WHERE fr.uid = file.file_registry_uid"
                ") WHERE filepath IS NULL"
            )

        conn.execute(
            "INSERT OR REPLACE INTO meta(key, value) VALUES('schema_version', ?)",
            (str(SCHEMA_VERSION),),
        )
        conn.commit()
