# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

SCHEMA_VERSION = 5

CREATE_FILE_REGISTRY = """
CREATE TABLE IF NOT EXISTS file_registry (
    uid         INTEGER PRIMARY KEY,
    file_id     TEXT    NOT NULL,
    project     TEXT    NOT NULL,
    folder_path TEXT    NOT NULL,
    filepath    TEXT    NOT NULL,
    filename    TEXT    NOT NULL,
    UNIQUE(project, folder_path, filepath),
    UNIQUE(project, file_id)
);

CREATE INDEX IF NOT EXISTS idx_registry_project ON file_registry(project, file_id);
"""

CREATE_FILE = """
CREATE TABLE IF NOT EXISTS file (
    uid               INTEGER PRIMARY KEY,
    file_registry_uid INTEGER NOT NULL REFERENCES file_registry(uid),
    file_version      INTEGER NOT NULL DEFAULT 0,
    created_at        TEXT    NOT NULL,
    hash              TEXT    NOT NULL,
    status            TEXT    NOT NULL DEFAULT 'CHANGE',
    is_full           INTEGER NOT NULL DEFAULT 0,
    storage_path      TEXT    NOT NULL DEFAULT '',
    file_size         INTEGER NOT NULL DEFAULT 0,
    is_corrupted      INTEGER NOT NULL DEFAULT 0,
    is_compressed     INTEGER NOT NULL DEFAULT 0,
    note              TEXT    DEFAULT '',
    is_deleted        INTEGER NOT NULL DEFAULT 0,
    session_uid       INTEGER REFERENCES sessions(uid),
    promoted_by       TEXT    DEFAULT NULL,
    filepath          TEXT    DEFAULT NULL
);

CREATE INDEX IF NOT EXISTS idx_file_registry ON file(file_registry_uid, uid);
CREATE INDEX IF NOT EXISTS idx_file_session ON file(session_uid, uid);
"""

CREATE_SESSIONS = """
CREATE TABLE IF NOT EXISTS sessions (
    uid        INTEGER PRIMARY KEY,
    project    TEXT    NOT NULL,
    created_at TEXT    NOT NULL,
    updated_at TEXT    NOT NULL,
    note       TEXT    DEFAULT '',
    is_forced  INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_session_project ON sessions(project, uid);
"""


CREATE_META = """
CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
"""
