# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import hashlib
import logging
import os
import sqlite3

from rewindex.config.defaults import DEFAULT_SESSION_MAX, DEFAULT_SESSION_SAFE

logger = logging.getLogger("rewindex.daemon")


def maybe_precompute(conn: sqlite3.Connection, project: str, session_uid: int) -> None:
    """Called after snapshot is done. If conditions met, run precompute synchronously."""
    from rewindex.config.loader import load_config

    config = load_config()
    if not config.get("precompute_enabled", False):
        return

    from rewindex.license import is_pro
    if not is_pro():
        return

    safe = config.get("session_safe", DEFAULT_SESSION_SAFE)
    max_val = config.get("session_max", DEFAULT_SESSION_MAX)
    cut = max_val - safe
    if cut < 1:
        return

    if session_uid % cut != 0:
        return

    _run_precompute(conn, project, session_uid, cut)


def _run_precompute(conn: sqlite3.Connection, project: str, session_uid: int, cut: int) -> None:
    """Write fullbase for all tracked files at this session point."""
    from rewindex.db.queries import get_all_tracked_files, get_latest_version_at_session
    from rewindex.snapshot.reconstruct import reconstruct
    from rewindex.snapshot.storage import write_full

    try:
        tracked = get_all_tracked_files(conn, project)

        # Phase 1: reconstruct + write .full.gz alongside existing .diff (I/O, outside transaction)
        # Each entry: (uid, full_path, full_size, old_diff_path, old_is_compressed)
        promote_batch: list[tuple[int, str, int, str, int]] = []
        for reg in tracked:
            ver = get_latest_version_at_session(conn, reg["uid"], session_uid)
            if ver is None or ver["is_deleted"]:
                continue
            if ver["is_full"]:
                continue

            try:
                lines = reconstruct(conn, reg["uid"], ver["uid"])
            except ValueError:
                continue

            expected_hash = ver["hash"]
            if expected_hash and expected_hash != "__deleted__":
                actual_hash = hashlib.sha256("".join(lines).encode("utf-8")).hexdigest()
                if actual_hash != expected_hash:
                    from rewindex.db.queries import mark_corrupted
                    logger.error(
                        "[precompute] Hash mismatch for uid=%d: expected %s, got %s",
                        ver["uid"], expected_hash[:12], actual_hash[:12],
                    )
                    mark_corrupted(conn, ver["uid"])
                    continue

            old_diff_path = ver["storage_path"]
            old_is_compressed = ver["is_compressed"]
            storage_path, file_size = write_full(project, ver["uid"], reg["filepath"], lines)
            promote_batch.append((ver["uid"], storage_path, file_size, old_diff_path, old_is_compressed))

        # Phase 2: update DB in single transaction
        if promote_batch:
            conn.execute("BEGIN IMMEDIATE")
            try:
                for uid, storage_path, file_size, _, _ in promote_batch:
                    conn.execute(
                        "UPDATE file SET is_full = 1, is_compressed = 1, storage_path = ?, file_size = ?, promoted_by = 'precompute' WHERE uid = ?",
                        (storage_path, file_size, uid),
                    )
                conn.commit()
            except Exception:
                conn.rollback()
                raise

        _cleanup_old_fullbase2(conn, project, session_uid)

    except Exception as e:
        logger.error("[precompute] Error for %s at SS%d: %s", project, session_uid, e)


def _cleanup_old_fullbase2(conn: sqlite3.Connection, project: str, new_session_uid: int) -> None:
    """Revert old precompute bases back to their original diff files.

    Both .diff/.diff.gz and .full.gz coexist on disk after promote (write_full
    does not delete the original diff).  So we can safely revert: point the DB
    back to the diff, delete the .full.gz, and clear promoted_by.
    """
    from rewindex.db.queries import get_all_tracked_files

    fullgz_to_delete: list[str] = []
    tracked = get_all_tracked_files(conn, project)

    conn.execute("BEGIN IMMEDIATE")
    try:
        for reg in tracked:
            rows = conn.execute(
                """SELECT uid, storage_path FROM file
                   WHERE file_registry_uid = ? AND promoted_by = 'precompute'
                         AND is_full = 1 AND session_uid < ?""",
                (reg["uid"], new_session_uid),
            ).fetchall()

            for row in rows:
                full_path = row["storage_path"]
                if not full_path or not full_path.endswith(".full.gz"):
                    conn.execute(
                        "UPDATE file SET promoted_by = NULL WHERE uid = ?",
                        (row["uid"],),
                    )
                    continue

                base = full_path[:-len(".full.gz")]
                diff_gz = base + ".diff.gz"
                diff_plain = base + ".diff"

                if os.path.isfile(diff_gz):
                    diff_path = diff_gz
                    is_compressed = 1
                elif os.path.isfile(diff_plain):
                    diff_path = diff_plain
                    is_compressed = 0
                else:
                    conn.execute(
                        "UPDATE file SET promoted_by = NULL WHERE uid = ?",
                        (row["uid"],),
                    )
                    continue

                diff_size = os.path.getsize(diff_path)
                conn.execute(
                    """UPDATE file SET is_full = 0, is_compressed = ?, storage_path = ?,
                       file_size = ?, promoted_by = NULL WHERE uid = ?""",
                    (is_compressed, diff_path, diff_size, row["uid"]),
                )
                fullgz_to_delete.append(full_path)

        conn.commit()
    except Exception:
        conn.rollback()
        raise

    for p in fullgz_to_delete:
        try:
            if os.path.isfile(p):
                os.remove(p)
        except OSError:
            pass
