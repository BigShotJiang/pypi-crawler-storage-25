# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import hashlib
import io
import os
import shutil
import sqlite3
from datetime import datetime, timezone

from .opcodes import generate
from .storage import read_full, write_diff, write_full
from rewindex.config.defaults import (
    DISK_FULL_BYTES,
    DISK_WARN_BYTES,
    DISK_WARN_RATIO,
    DISK_WARNING_FILE,
    MAX_TEXT_FILE_BYTES,
    REWINDEX_DIR,
)
from rewindex.db.queries import (
    finalize_file_version,
    get_latest_file_version,
    get_or_create_file_registry,
    get_or_create_session,
    insert_file_version,
)

_O_NOATIME = getattr(os, "O_NOATIME", 0)


def _check_disk() -> str | None:
    try:
        usage = shutil.disk_usage(REWINDEX_DIR)
        free = usage.free
        total = usage.total
        warn_threshold = max(DISK_WARN_BYTES, int(total * DISK_WARN_RATIO))

        if free < DISK_FULL_BYTES:
            _write_disk_warning(f"Disk full: {free // 1024}KB free")
            return "full"
        elif free < warn_threshold:
            _write_disk_warning(f"Low disk space: {free // (1024 * 1024)}MB free")
            return "warn"
        else:
            _clear_disk_warning()
            return None
    except OSError:
        return None


def _write_disk_warning(message: str) -> None:
    os.makedirs(REWINDEX_DIR, exist_ok=True)
    fd = os.open(DISK_WARNING_FILE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        os.write(fd, (message + "\n").encode())
    finally:
        os.close(fd)


def _clear_disk_warning() -> None:
    try:
        os.remove(DISK_WARNING_FILE)
    except FileNotFoundError:
        pass


def read_disk_warning() -> str | None:
    try:
        with open(DISK_WARNING_FILE) as f:
            return f.read().strip()
    except FileNotFoundError:
        return None


def _open_rb_noatime(filepath: str):
    if _O_NOATIME:
        try:
            fd = os.open(filepath, os.O_RDONLY | _O_NOATIME)
            return io.open(fd, "rb")
        except OSError:
            pass
    return open(filepath, "rb")


def _open_text_noatime(filepath: str):
    if _O_NOATIME:
        try:
            fd = os.open(filepath, os.O_RDONLY | _O_NOATIME)
            return io.open(fd, "r", encoding="utf-8", errors="replace")
        except OSError:
            pass
    return open(filepath, "r", encoding="utf-8", errors="replace")


def hash_file(filepath: str) -> str:
    h = hashlib.sha256()
    with _open_rb_noatime(filepath) as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def is_binary(filepath: str) -> bool:
    try:
        with _open_rb_noatime(filepath) as f:
            return b"\x00" in f.read(8192)
    except OSError:
        return False


def record_deletion(
    conn: sqlite3.Connection,
    project: str,
    project_folder: str,
    abs_filepath: str,
    session_uid: int | None = None,
    gap_seconds: float = 20.0,
) -> int | None:
    """Record a deletion event for a tracked file. Returns file version uid or None."""
    filepath = os.path.relpath(abs_filepath, project_folder)
    registry_uid, file_id, next_ver = get_or_create_file_registry(conn, project, project_folder, filepath)

    latest = get_latest_file_version(conn, registry_uid)
    if latest is None or latest["is_deleted"]:
        return None

    created_at = datetime.now(timezone.utc).isoformat()

    if session_uid is None:
        session_uid = get_or_create_session(conn, project, created_at, gap_seconds)

    file_uid = insert_file_version(
        conn,
        file_registry_uid=registry_uid,
        file_version=next_ver,
        created_at=created_at,
        hash="__deleted__",
        is_full=True,
        is_deleted=True,
        session_uid=session_uid,
        status="DELETE",
    )

    path, file_size = write_full(project, file_uid, filepath, [])
    finalize_file_version(conn, file_uid, path, file_size)
    return file_uid


def record_move(
    conn: sqlite3.Connection,
    project: str,
    project_folder: str,
    abs_filepath: str,
    old_filepath: str,
    session_uid: int | None = None,
    gap_seconds: float = 20.0,
) -> int | None:
    """Record a MOVE or RENAME event: new version pointing to same content."""
    filepath = os.path.relpath(abs_filepath, project_folder)
    registry_uid, file_id, next_ver = get_or_create_file_registry(conn, project, project_folder, filepath)

    latest = get_latest_file_version(conn, registry_uid)
    if latest is None:
        return None

    old_dir = os.path.dirname(old_filepath)
    new_dir = os.path.dirname(filepath)
    is_rename = old_dir == new_dir

    if is_rename:
        old_name = os.path.basename(old_filepath)
        status = "RENAME"
        note = f"renamed from {old_name}"
    else:
        status = "MOVE"
        note = f"moved from {old_filepath}"

    created_at = datetime.now(timezone.utc).isoformat()

    if session_uid is None:
        session_uid = get_or_create_session(conn, project, created_at, gap_seconds)

    file_uid = insert_file_version(
        conn,
        file_registry_uid=registry_uid,
        file_version=next_ver,
        created_at=created_at,
        hash=latest["hash"],
        is_full=latest["is_full"],
        is_compressed=latest["is_compressed"],
        session_uid=session_uid,
        status=status,
    )

    finalize_file_version(conn, file_uid, latest["storage_path"], latest["file_size"])

    from rewindex.db.queries import update_file_note
    update_file_note(conn, file_uid, note)

    return file_uid


def snapshot_file(
    conn: sqlite3.Connection,
    project: str,
    project_folder: str,
    abs_filepath: str,
    session_uid: int | None = None,
    gap_seconds: float = 20.0,
) -> int | None:
    """
    Hash → compare → write full or diff → insert DB.
    Returns new file version uid, or None if unchanged/binary/skipped.
    """
    if not os.path.isfile(abs_filepath):
        return record_deletion(conn, project, project_folder, abs_filepath, session_uid, gap_seconds)

    if is_binary(abs_filepath):
        return None

    from rewindex.utils.validation import validate_filepath, validate_project_name
    try:
        validate_filepath(abs_filepath)
        validate_project_name(project)
    except ValueError:
        return None

    if os.path.getsize(abs_filepath) > MAX_TEXT_FILE_BYTES:
        return None

    disk_status = _check_disk()
    if disk_status == "full":
        return None

    current_hash = hash_file(abs_filepath)
    filepath = os.path.relpath(abs_filepath, project_folder)

    registry_uid, file_id, next_ver = get_or_create_file_registry(conn, project, project_folder, filepath)
    latest = get_latest_file_version(conn, registry_uid)

    if latest and latest["hash"] == current_hash:
        return None

    with _open_text_noatime(abs_filepath) as f:
        new_lines = f.readlines()

    created_at = datetime.now(timezone.utc).isoformat()
    is_full = latest is None or bool(latest["is_deleted"])

    if session_uid is None:
        session_uid = get_or_create_session(conn, project, created_at, gap_seconds)

    status = "CREATE" if is_full else "CHANGE"

    file_uid = insert_file_version(
        conn,
        file_registry_uid=registry_uid,
        file_version=next_ver,
        created_at=created_at,
        hash=current_hash,
        is_full=is_full,
        session_uid=session_uid,
        status=status,
    )

    try:
        if is_full:
            storage_path, file_size = write_full(project, file_uid, filepath, new_lines)
            finalize_file_version(conn, file_uid, storage_path, file_size)
        else:
            from .reconstruct import reconstruct
            try:
                old_lines = reconstruct(conn, registry_uid, latest["uid"])
            except ValueError:
                conn.execute("DELETE FROM file WHERE uid = ?", (file_uid,))
                conn.commit()
                # Corrupt chain — write as new fullbase
                file_uid = insert_file_version(
                    conn,
                    file_registry_uid=registry_uid,
                    file_version=next_ver,
                    created_at=created_at,
                    hash=current_hash,
                    is_full=True,
                    session_uid=session_uid,
                    status="CREATE",
                )
                storage_path, file_size = write_full(project, file_uid, filepath, new_lines)
                finalize_file_version(conn, file_uid, storage_path, file_size)
                return file_uid

            ops = generate(old_lines, new_lines)
            storage_path, file_size, is_compressed = write_diff(project, file_uid, filepath, ops)
            if is_compressed:
                conn.execute("UPDATE file SET is_compressed = 1 WHERE uid = ?", (file_uid,))
                conn.commit()
            finalize_file_version(conn, file_uid, storage_path, file_size)
    except Exception:
        conn.execute("DELETE FROM file WHERE uid = ?", (file_uid,))
        conn.commit()
        raise

    from .precompute import maybe_precompute
    maybe_precompute(conn, project, session_uid)

    from .trim import maybe_trim
    maybe_trim(conn, project)

    return file_uid
