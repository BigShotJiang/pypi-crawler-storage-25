# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import gzip
import json
import os

from rewindex.config.defaults import (
    DIFF_COMPRESS_THRESHOLD,
    MAX_GZIP_READ_BYTES,
    SNAPSHOTS_DIR,
)


def _snapshot_path(project: str, uid: int, filepath: str, ext: str) -> str:
    from rewindex.utils.validation import validate_filepath
    validate_filepath(filepath)
    base = os.path.realpath(os.path.join(SNAPSHOTS_DIR, project, "snapshots"))
    full = os.path.realpath(os.path.join(base, f"{uid:04d}", filepath + ext))
    if not full.startswith(base + os.sep):
        raise ValueError(f"Path traversal detected: {filepath}")
    return full


def write_full(project: str, uid: int, filepath: str, lines: list[str]) -> tuple[str, int]:
    """Write fullbase snapshot (always gzipped). Returns (path, file_size)."""
    path = _snapshot_path(project, uid, filepath, ".full.gz")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    content = "".join(lines).encode("utf-8")
    with gzip.open(path, "wb") as f:
        f.write(content)
    return path, os.path.getsize(path)


def write_diff(project: str, uid: int, filepath: str, opcodes: list) -> tuple[str, int, bool]:
    """Write diff snapshot. Compress only when > DIFF_COMPRESS_THRESHOLD.
    Returns (path, file_size, is_compressed)."""
    payload = json.dumps({"v": 1, "ops": opcodes}, ensure_ascii=False).encode("utf-8")
    compressed = len(payload) > DIFF_COMPRESS_THRESHOLD
    ext = ".diff.gz" if compressed else ".diff"
    path = _snapshot_path(project, uid, filepath, ext)
    os.makedirs(os.path.dirname(path), exist_ok=True)

    if compressed:
        with gzip.open(path, "wb") as f:
            f.write(payload)
    else:
        with open(path, "wb") as f:
            f.write(payload)

    return path, os.path.getsize(path), compressed


def _read_gzip_bounded(storage_path: str) -> bytes:
    with gzip.open(storage_path, "rb") as f:
        data = f.read(MAX_GZIP_READ_BYTES + 1)
    if len(data) > MAX_GZIP_READ_BYTES:
        raise ValueError(f"Decompressed content exceeds {MAX_GZIP_READ_BYTES} bytes: {storage_path}")
    return data


def read_full(storage_path: str) -> list[str]:
    content = _read_gzip_bounded(storage_path).decode("utf-8")
    return content.splitlines(keepends=True)


def read_diff(storage_path: str, is_compressed: bool = True) -> list:
    if is_compressed:
        raw = _read_gzip_bounded(storage_path)
    else:
        with open(storage_path, "rb") as f:
            raw = f.read(MAX_GZIP_READ_BYTES + 1)
        if len(raw) > MAX_GZIP_READ_BYTES:
            raise ValueError(f"Diff content exceeds {MAX_GZIP_READ_BYTES} bytes: {storage_path}")
    payload = json.loads(raw.decode("utf-8"))
    return payload["ops"]
