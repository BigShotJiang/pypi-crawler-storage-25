# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import difflib


def generate(old_lines: list[str], new_lines: list[str]) -> list:
    """
    Convert difflib opcodes to compact serializable format:
      ["eq",  i1, i2]              — copy old_lines[i1:i2] unchanged
      ["ins", [lines...]]          — insert new lines (no old lines consumed)
      ["rep", i1, i2, [lines...]]  — replace old_lines[i1:i2] with new lines
      ["del", i1, i2]              — delete old_lines[i1:i2]

    i1/i2 stored on rep/del so apply() knows exactly which old lines to skip.
    """
    matcher = difflib.SequenceMatcher(None, old_lines, new_lines, autojunk=False)
    ops = []
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            ops.append(["eq", i1, i2])
        elif tag == "insert":
            ops.append(["ins", new_lines[j1:j2]])
        elif tag == "replace":
            ops.append(["rep", i1, i2, new_lines[j1:j2]])
        elif tag == "delete":
            ops.append(["del", i1, i2])
    return ops


def apply(old_lines: list[str], ops: list) -> list[str]:
    """
    Reconstruct new_lines by replaying opcodes against old_lines.
    """
    result = []
    for op in ops:
        tag = op[0]
        if tag == "eq":
            result.extend(old_lines[op[1]:op[2]])
        elif tag == "ins":
            result.extend(op[1])
        elif tag == "rep":
            result.extend(op[3])   # op[1]:op[2] are old lines to discard
        elif tag == "del":
            pass                   # op[1]:op[2] are old lines to discard
    return result
