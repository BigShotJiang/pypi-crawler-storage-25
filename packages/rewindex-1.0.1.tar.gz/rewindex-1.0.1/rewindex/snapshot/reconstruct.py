# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import sqlite3

from .opcodes import apply
from .storage import read_diff, read_full
from rewindex.config.defaults import MAX_DIFF_CHAIN
from rewindex.db.queries import (
    get_file_versions_since,
    get_full_base_for_file,
    mark_corrupted,
)


def reconstruct(
    conn: sqlite3.Connection,
    registry_uid: int,
    target_uid: int,
) -> list[str]:
    """
    Reconstruct file content at target_uid.
    Chain: load fullbase → apply each diff in order up to target_uid.
    Returns list of lines (with newlines).
    Raises ValueError if chain is broken.
    """
    base = get_full_base_for_file(conn, registry_uid)
    if base is None:
        raise ValueError(f"No base snapshot found for file_registry uid={registry_uid}")

    if base["uid"] > target_uid:
        raise ValueError(
            f"Base snapshot #{base['uid']} is newer than target #{target_uid}"
        )

    try:
        lines = read_full(base["storage_path"])
    except Exception as e:
        mark_corrupted(conn, base["uid"])
        raise ValueError(f"Base snapshot #{base['uid']} is unreadable: {e}") from e

    if base["uid"] == target_uid:
        return lines

    diffs = get_file_versions_since(conn, registry_uid, base["uid"] + 1, limit=MAX_DIFF_CHAIN + 1)

    if len(diffs) > MAX_DIFF_CHAIN:
        raise ValueError(
            f"Diff chain for file_registry uid={registry_uid} exceeds {MAX_DIFF_CHAIN} entries."
        )

    for snap in diffs:
        if snap["uid"] > target_uid:
            break
        if snap["is_full"]:
            try:
                lines = read_full(snap["storage_path"])
            except Exception as e:
                mark_corrupted(conn, snap["uid"])
                raise ValueError(f"Snapshot #{snap['uid']} is unreadable: {e}") from e
        else:
            try:
                ops = read_diff(snap["storage_path"], is_compressed=bool(snap["is_compressed"]))
                lines = apply(lines, ops)
            except Exception as e:
                mark_corrupted(conn, snap["uid"])
                raise ValueError(f"Snapshot #{snap['uid']} is unreadable: {e}") from e

    return lines
