# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import hashlib
import logging
import os
import sqlite3
import traceback

logger = logging.getLogger("rewindex.daemon")

from rewindex.config.defaults import DEFAULT_EXCLUDE, SECURITY_EXCLUDE
from rewindex.db.connection import get_connection
from rewindex.db.queries import get_latest_file_version, get_all_tracked_files, mark_corrupted
from rewindex.snapshot.engine import snapshot_file


def _get_nested_excludes(current_folder: str, all_projects: list[dict]) -> list[str]:
    nested = []
    for p in all_projects:
        for folder in p.get("folders", []):
            other = os.path.realpath(os.path.expanduser(folder))
            if other == current_folder:
                continue
            if other.startswith(current_folder + os.sep):
                nested.append(other)
    return nested


def startup_reconcile(config: dict) -> None:
    """
    On daemon start:
    1. Integrity check: mark DB entries whose storage file is missing as corrupted.
    2. Missed-change catch-up: snapshot any watched file whose hash differs
       from its last recorded snapshot.
    """
    projects: list[dict] = config.get("projects", [])
    global_exclude: list[str] = config.get("global_exclude", DEFAULT_EXCLUDE)

    for project in projects:
        name = project["name"]
        folders = project.get("folders", [])
        for folder in folders:
            folder = os.path.realpath(os.path.expanduser(folder))
            nested_excludes = _get_nested_excludes(folder, projects)
            exclude = global_exclude + project.get("project_exclude", [])
            conn = get_connection(name)
            try:
                _check_integrity(conn, name)
                _catch_up_missed_changes(conn, name, folder, exclude, nested_excludes)
            finally:
                conn.close()


def _check_integrity(conn: sqlite3.Connection, project_name: str) -> None:
    from rewindex.snapshot.storage import read_diff, read_full

    tracked = get_all_tracked_files(conn, project_name)
    for reg in tracked:
        rows = conn.execute(
            "SELECT uid, storage_path, is_full, is_compressed FROM file "
            "WHERE file_registry_uid = ? AND is_corrupted = 0",
            (reg["uid"],),
        ).fetchall()

        for row in rows:
            if not row["storage_path"] or not os.path.exists(row["storage_path"]):
                mark_corrupted(conn, row["uid"])
                continue
            try:
                if row["is_full"]:
                    read_full(row["storage_path"])
                else:
                    read_diff(row["storage_path"], is_compressed=bool(row["is_compressed"]))
            except Exception:
                mark_corrupted(conn, row["uid"])


def _catch_up_missed_changes(
    conn: sqlite3.Connection,
    project_name: str,
    project_folder: str,
    exclude: list[str],
    nested_excludes: list[str] | None = None,
) -> None:
    if not os.path.isdir(project_folder):
        return

    _nested = nested_excludes or []
    from rewindex.daemon.watcher import _matches_exclude, safe_walk

    for abs_path in safe_walk(project_folder):
        if _matches_exclude(abs_path, SECURITY_EXCLUDE) or _matches_exclude(abs_path, exclude):
            continue
        if any(abs_path == n or abs_path.startswith(n + os.sep) for n in _nested):
            continue
        try:
            filepath = os.path.relpath(abs_path, project_folder)
            row = conn.execute(
                "SELECT fr.uid FROM file_registry fr WHERE fr.project = ? AND fr.folder_path = ? AND fr.filepath = ?",
                (project_name, project_folder, filepath),
            ).fetchone()

            if row is None:
                snapshot_file(conn, project_name, project_folder, abs_path)
                continue

            latest = get_latest_file_version(conn, row["uid"])
            if latest is None:
                snapshot_file(conn, project_name, project_folder, abs_path)
                continue

            current_hash = _hash_file(abs_path)
            if current_hash != latest["hash"]:
                snapshot_file(conn, project_name, project_folder, abs_path)
        except MemoryError:
            raise
        except sqlite3.DatabaseError as e:
            logger.error("[reconcile] DB error on %s: %s", abs_path, e)
        except OSError as e:
            logger.error("[reconcile] File error on %s: %s", abs_path, e)
        except Exception:
            logger.error("[reconcile] Unexpected error on %s:\n%s", abs_path, traceback.format_exc())


def _hash_file(filepath: str) -> str:
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()
