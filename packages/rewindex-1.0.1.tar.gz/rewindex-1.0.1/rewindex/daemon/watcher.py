# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import logging
import os
import time
import threading
from typing import Callable

from watchdog.events import FileSystemEvent, FileSystemEventHandler
from watchdog.observers import Observer

from rewindex.config.defaults import DEFAULT_EXCLUDE, MAX_PENDING_EVENTS, SECURITY_EXCLUDE
from rewindex.db.connection import get_connection
from rewindex.snapshot.engine import snapshot_file

logger = logging.getLogger("rewindex.daemon")

def _matches_exclude(path: str, exclude_patterns: list[str]) -> bool:
    import fnmatch
    for pattern in exclude_patterns:
        if fnmatch.fnmatch(os.path.basename(path), pattern):
            return True
        if pattern.endswith("/") and (pattern[:-1] in path.split(os.sep)):
            return True
    return False


class _SnapshotHandler(FileSystemEventHandler):
    def __init__(
        self,
        project_name: str,
        project_folder: str,
        exclude: list[str],
        debounce_seconds: float = 0.0,
        observer: "Observer | None" = None,
        nested_excludes: list[str] | None = None,
    ):
        self.project_name = project_name
        self.project_folder = project_folder
        self.exclude = exclude
        self.debounce_seconds = debounce_seconds
        self._observer = observer
        self._nested_excludes: list[str] = nested_excludes or []
        self._symlink_dirs: dict[str, str] = {}
        self._pending: dict[str, float] = {}
        self._lock = threading.Lock()
        self._worker = threading.Thread(target=self._debounce_loop, daemon=True)
        self._worker.start()

    def register_symlink_dir(self, symlink_path: str) -> None:
        if self._observer is None:
            return
        real = os.path.realpath(symlink_path)
        with self._lock:
            if real in self._symlink_dirs:
                return
            self._symlink_dirs[real] = symlink_path
        try:
            self._observer.schedule(self, real, recursive=True)
        except OSError as e:
            logger.warning(
                "Cannot watch %s: %s — some file changes may not be detected. "
                "If inotify limit is full, increase it with: "
                "sudo sysctl fs.inotify.max_user_watches=524288",
                symlink_path, e,
            )

    def _remap_path(self, abs_path: str) -> str:
        with self._lock:
            for real_prefix, sym_prefix in self._symlink_dirs.items():
                if abs_path == real_prefix or abs_path.startswith(real_prefix + os.sep):
                    return sym_prefix + abs_path[len(real_prefix):]
        return abs_path

    def on_modified(self, event: FileSystemEvent) -> None:
        if event.is_directory:
            return
        self._schedule(event.src_path)

    def on_created(self, event: FileSystemEvent) -> None:
        if event.is_directory:
            return
        path = event.src_path
        if os.path.islink(path) and os.path.isdir(path):
            self.register_symlink_dir(path)
            return
        self._schedule(path)

    def on_deleted(self, event: FileSystemEvent) -> None:
        if event.is_directory:
            self._schedule_directory_rescan(event.src_path)
            return
        self._schedule(event.src_path)

    def on_moved(self, event: FileSystemEvent) -> None:
        src_inside = event.src_path.startswith(self.project_folder + os.sep)
        dest_inside = event.dest_path.startswith(self.project_folder + os.sep)

        if event.is_directory:
            if src_inside and dest_inside:
                self._rename_directory(event.src_path, event.dest_path)
            elif src_inside:
                self._schedule_directory_rescan(event.src_path)
            return

        if src_inside and dest_inside:
            renamed = self._rename_file(event.src_path, event.dest_path)
            if not renamed:
                # src was not a tracked file (e.g. atomic write via temp→final rename)
                self._schedule(event.dest_path)
        elif src_inside:
            self._schedule(event.src_path)
        elif dest_inside:
            self._schedule(event.dest_path)

    def _rename_file(self, old_abs: str, new_abs: str) -> bool:
        """Update registry + record move/rename immediately. Returns True if a tracked file was renamed."""
        from rewindex.db.queries import rename_tracked_file
        from rewindex.snapshot.engine import record_move
        old_rel = os.path.relpath(old_abs, self.project_folder)
        new_rel = os.path.relpath(new_abs, self.project_folder)
        new_filename = os.path.basename(new_abs)
        conn = get_connection(self.project_name)
        try:
            renamed = rename_tracked_file(
                conn, self.project_name, self.project_folder,
                old_rel, new_rel, new_filename,
            )
            if renamed:
                record_move(
                    conn, self.project_name, self.project_folder,
                    new_abs, old_rel,
                )
            return bool(renamed)
        except Exception:
            return False
        finally:
            conn.close()

    def _rename_directory(self, old_dir: str, new_dir: str) -> None:
        """Update registry + record move/rename for all files immediately."""
        from rewindex.db.queries import get_all_tracked_files, rename_tracked_file
        from rewindex.snapshot.engine import record_move
        conn = get_connection(self.project_name)
        try:
            tracked = get_all_tracked_files(conn, self.project_name)
            for reg in tracked:
                abs_path = os.path.join(self.project_folder, reg["filepath"])
                if abs_path.startswith(old_dir + os.sep):
                    new_abs = new_dir + abs_path[len(old_dir):]
                    old_rel = os.path.relpath(abs_path, self.project_folder)
                    new_rel = os.path.relpath(new_abs, self.project_folder)
                    new_filename = os.path.basename(new_abs)
                    rename_tracked_file(
                        conn, self.project_name, self.project_folder,
                        old_rel, new_rel, new_filename,
                    )
                    record_move(
                        conn, self.project_name, self.project_folder,
                        new_abs, old_rel,
                    )
        except Exception:
            pass
        finally:
            conn.close()

    def _schedule_directory_rescan(self, dir_path: str) -> None:
        """Schedule snapshots for all tracked files that were in a deleted/moved-out directory."""
        conn = get_connection(self.project_name)
        try:
            from rewindex.db.queries import get_all_tracked_files
            tracked = get_all_tracked_files(conn, self.project_name)
            for reg in tracked:
                abs_path = os.path.join(self.project_folder, reg["filepath"])
                if abs_path.startswith(dir_path + os.sep) or abs_path == dir_path:
                    self._schedule(abs_path)
        finally:
            conn.close()

    def _schedule(self, abs_path: str) -> None:
        abs_path = self._remap_path(os.path.normpath(abs_path))
        if _matches_exclude(abs_path, SECURITY_EXCLUDE) or _matches_exclude(abs_path, self.exclude):
            return
        for nested in self._nested_excludes:
            if abs_path == nested or abs_path.startswith(nested + os.sep):
                return
        with self._lock:
            if abs_path not in self._pending and len(self._pending) >= MAX_PENDING_EVENTS:
                oldest = min(self._pending, key=self._pending.__getitem__)
                del self._pending[oldest]
            self._pending[abs_path] = time.monotonic()

    def _debounce_loop(self) -> None:
        while True:
            time.sleep(0.5)
            now = time.monotonic()
            to_snap: list[str] = []
            with self._lock:
                for path, last_time in list(self._pending.items()):
                    if now - last_time >= self.debounce_seconds:
                        to_snap.append(path)
                        del self._pending[path]
            for path in to_snap:
                self._do_snapshot(path)

    def _do_snapshot(self, abs_path: str) -> None:
        conn = get_connection(self.project_name)
        try:
            snapshot_file(
                conn=conn,
                project=self.project_name,
                project_folder=self.project_folder,
                abs_filepath=abs_path,
            )
        except Exception:
            pass
        finally:
            conn.close()


def safe_walk(path: str, visited: set | None = None, depth: int = 0, _root_real: str | None = None):
    if depth > 10:
        return
    if visited is None:
        visited = set()
    real = os.path.realpath(path)
    if _root_real is None:
        _root_real = real
    if real in visited:
        return
    visited.add(real)
    try:
        for entry in os.scandir(path):
            if entry.is_symlink():
                entry_real = os.path.realpath(entry.path)
                if not entry_real.startswith(_root_real + os.sep) and entry_real != _root_real:
                    continue
                if entry.is_dir(follow_symlinks=True):
                    yield from safe_walk(entry.path, visited, depth + 1, _root_real)
                elif entry.is_file(follow_symlinks=True):
                    yield entry.path
            elif entry.is_dir(follow_symlinks=False):
                yield from safe_walk(entry.path, visited, depth + 1, _root_real)
            elif entry.is_file(follow_symlinks=False):
                yield entry.path
    except OSError:
        pass


def _iter_symlink_dirs(root: str, visited: set | None = None, depth: int = 0, _root_real: str | None = None):
    if depth > 10:
        return
    if visited is None:
        visited = set()
    if _root_real is None:
        _root_real = os.path.realpath(root)
    try:
        for entry in os.scandir(root):
            if entry.is_symlink() and entry.is_dir(follow_symlinks=True):
                real = os.path.realpath(entry.path)
                if not real.startswith(_root_real + os.sep) and real != _root_real:
                    continue
                if real not in visited:
                    visited.add(real)
                    yield entry.path
                    yield from _iter_symlink_dirs(entry.path, visited, depth + 1, _root_real)
            elif entry.is_dir(follow_symlinks=False):
                yield from _iter_symlink_dirs(entry.path, visited, depth + 1, _root_real)
    except OSError:
        pass


def _get_nested_excludes(current_folder: str, all_projects: list[dict]) -> list[str]:
    nested = []
    for p in all_projects:
        for folder in p.get("folders", []):
            other = os.path.realpath(os.path.expanduser(folder))
            if other == current_folder:
                continue
            if other.startswith(current_folder + os.sep):
                nested.append(other)
    return nested


def start_watching(config: dict) -> None:
    projects: list[dict] = config.get("projects", [])
    global_exclude: list[str] = config.get("global_exclude", DEFAULT_EXCLUDE)
    debounce_seconds: float = 0.0

    observer = Observer()

    for project in projects:
        name = project["name"]
        folders = project.get("folders", [])
        exclude = global_exclude + project.get("project_exclude", [])

        for folder in folders:
            folder = os.path.realpath(os.path.expanduser(folder))
            if not os.path.isdir(folder):
                continue
            nested_excludes = _get_nested_excludes(folder, projects)
            handler = _SnapshotHandler(name, folder, exclude, debounce_seconds,
                                       observer=observer, nested_excludes=nested_excludes)
            try:
                observer.schedule(handler, folder, recursive=True)
            except OSError as e:
                logger.warning(
                    "Cannot watch project '%s' at %s: %s — "
                    "increase inotify limit with: sudo sysctl fs.inotify.max_user_watches=524288",
                    name, folder, e,
                )
                continue
            for symlink_dir in _iter_symlink_dirs(folder):
                handler.register_symlink_dir(symlink_dir)

    observer.start()
    observer.join()
