# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

"""
License management via Cloudflare Worker proxy + encrypted local file.

The client never contacts the payment provider directly.
All validation goes through our Worker which returns a unified LicenseResult.

Stores license data in ~/.rewindex/.license, encrypted with a key
derived from the machine's MAC address.
"""

import hashlib
import hmac
import json
import os
import socket
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone

from rewindex.config.defaults import REWINDEX_DIR
from rewindex.config.urls import VALIDATE_URL


@dataclass
class LicenseResult:
    valid: bool
    plan: str
    expires_at: str

_LICENSE_FILE = os.path.join(REWINDEX_DIR, ".license")
_SALT = b"rewindex-license-v2"


def _get_machine_key() -> bytes:
    mac = uuid.getnode().to_bytes(6, "big")
    return hashlib.sha256(_SALT + mac).digest()


def _encrypt(data: bytes) -> bytes:
    key = _get_machine_key()
    # XOR stream cipher with HMAC-SHA256 keystream
    stream = b""
    block = 0
    while len(stream) < len(data):
        stream += hashlib.sha256(key + block.to_bytes(4, "big")).digest()
        block += 1
    encrypted = bytes(a ^ b for a, b in zip(data, stream))
    tag = hmac.new(key, encrypted, hashlib.sha256).digest()[:16]
    return tag + encrypted


def _decrypt(blob: bytes) -> bytes | None:
    if len(blob) < 17:
        return None
    key = _get_machine_key()
    tag = blob[:16]
    encrypted = blob[16:]
    expected_tag = hmac.new(key, encrypted, hashlib.sha256).digest()[:16]
    if not hmac.compare_digest(tag, expected_tag):
        return None
    stream = b""
    block = 0
    while len(stream) < len(encrypted):
        stream += hashlib.sha256(key + block.to_bytes(4, "big")).digest()
        block += 1
    return bytes(a ^ b for a, b in zip(encrypted, stream))


def _read_license_data() -> dict:
    try:
        with open(_LICENSE_FILE, "rb") as f:
            blob = f.read()
        data = _decrypt(blob)
        if data is None:
            return {}
        return json.loads(data.decode("utf-8"))
    except (OSError, json.JSONDecodeError, ValueError):
        return {}


def _write_license_data(data: dict) -> None:
    os.makedirs(REWINDEX_DIR, exist_ok=True)
    raw = json.dumps(data).encode("utf-8")
    blob = _encrypt(raw)
    fd = os.open(_LICENSE_FILE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        os.write(fd, blob)
    finally:
        os.close(fd)


def get_membership() -> dict:
    data = _read_license_data()
    plan = data.get("plan", "Free")
    expires = data.get("expires_at", "")
    status = "active"

    if plan == "Pro" and expires:
        try:
            exp_dt = datetime.fromisoformat(expires)
            if exp_dt < datetime.now(timezone.utc):
                status = "expired"
                plan = "Free"
        except ValueError:
            pass

    return {
        "plan": plan,
        "status": status,
        "expires_at": expires,
    }


def is_pro() -> bool:
    m = get_membership()
    return m["plan"] == "Pro" and m["status"] == "active"


def _validate_with_server(license_key: str) -> LicenseResult:
    """Send license key to Cloudflare Worker for validation.
    The Worker handles provider-specific logic (LemonSqueezy, Paddle, etc.)
    and returns a unified response. Raises ConnectionError or ValueError."""
    import urllib.request

    hostname = socket.gethostname()
    payload = json.dumps({
        "license_key": license_key,
        "instance_name": hostname,
    }).encode("utf-8")

    req = urllib.request.Request(
        VALIDATE_URL,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            resp_data = json.loads(resp.read().decode("utf-8"))
    except (urllib.error.URLError, OSError) as e:
        raise ConnectionError(f"Cannot reach validation server: {e}")

    valid = resp_data.get("valid", False)
    if not valid:
        status = resp_data.get("license_key", {}).get("status", "unknown")
        if status == "expired":
            raise ValueError("License key has expired.")
        elif status in ("inactive", "disabled"):
            raise ValueError("License key is inactive.")
        raise ValueError("License key is not valid.")

    return LicenseResult(
        valid=True,
        plan=resp_data.get("plan", "Pro"),
        expires_at=resp_data.get("expires_at", ""),
    )


def activate_license(license_key: str) -> LicenseResult:
    """Validate and activate a license key. Raises ConnectionError or ValueError."""
    result = _validate_with_server(license_key)

    _write_license_data({
        "license_key": license_key,
        "plan": result.plan,
        "expires_at": result.expires_at,
        "validated_at": datetime.now(timezone.utc).isoformat(),
    })

    return result


def clear_license() -> None:
    try:
        os.remove(_LICENSE_FILE)
    except FileNotFoundError:
        pass
