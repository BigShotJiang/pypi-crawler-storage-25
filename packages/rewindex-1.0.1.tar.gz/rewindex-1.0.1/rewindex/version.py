# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import json
import os

from rewindex.config.defaults import REWINDEX_DIR

REWINDEX_JSON_PATH = os.path.join(REWINDEX_DIR, "rewindex.json")

_DEFAULT = {
    "rewindex_version": "1.0.1",
    "skill_version": "1.0.0",
    "readme_version": "1.0.0",
    "config_schema": "1.0.0",
}


def load_rewindex_json() -> dict:
    if not os.path.exists(REWINDEX_JSON_PATH):
        return dict(_DEFAULT)
    try:
        with open(REWINDEX_JSON_PATH) as f:
            return json.load(f)
    except Exception:
        return dict(_DEFAULT)


def save_rewindex_json(data: dict) -> None:
    os.makedirs(REWINDEX_DIR, exist_ok=True)
    with open(REWINDEX_JSON_PATH, "w") as f:
        json.dump(data, f, indent=2)


def init_rewindex_json() -> None:
    """Write rewindex.json if missing or corrupted; fill in any missing fields."""
    existing: dict | None = None
    if os.path.exists(REWINDEX_JSON_PATH):
        try:
            with open(REWINDEX_JSON_PATH) as f:
                existing = json.load(f)
        except Exception:
            pass  # corrupted — recreate below

    if existing is None:
        save_rewindex_json(dict(_DEFAULT))
        return

    # Merge: fill in top-level keys and nested plugin keys that are missing
    updated = {**_DEFAULT, **existing}
    updated.pop("plugins", None)  # remove legacy plugins field if present
    updated["rewindex_version"] = _DEFAULT["rewindex_version"]  # always update version
    if updated != existing:
        save_rewindex_json(updated)
