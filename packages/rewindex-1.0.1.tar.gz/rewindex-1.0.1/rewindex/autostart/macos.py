# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import os
import shutil
import subprocess

_PLIST_LABEL = "com.rewindex.daemon"
_PLIST_DIR = os.path.expanduser("~/Library/LaunchAgents")
_PLIST_PATH = os.path.join(_PLIST_DIR, f"{_PLIST_LABEL}.plist")

_PLIST_TEMPLATE = """\
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
    "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>{label}</string>
    <key>ProgramArguments</key>
    <array>
        <string>{rewindex_bin}</string>
        <string>start</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>{log_dir}/rewindex.out.log</string>
    <key>StandardErrorPath</key>
    <string>{log_dir}/rewindex.err.log</string>
</dict>
</plist>
"""


def _validate_bin(path: str) -> None:
    if not os.path.isabs(path):
        raise RuntimeError(f"rewindex binary path is not absolute: {path}")
    try:
        stat = os.stat(path)
        if stat.st_uid not in (os.getuid(), 0):
            raise RuntimeError(
                f"rewindex binary at {path} is owned by uid {stat.st_uid} — refusing to register"
            )
    except OSError as e:
        raise RuntimeError(f"Cannot stat rewindex binary: {e}")


def install() -> None:
    rewindex_bin = shutil.which("rewindex")
    if not rewindex_bin:
        raise RuntimeError("rewindex binary not found in PATH")
    _validate_bin(rewindex_bin)

    log_dir = os.path.expanduser("~/.rewindex")
    os.makedirs(_PLIST_DIR, exist_ok=True)

    with open(_PLIST_PATH, "w") as f:
        f.write(_PLIST_TEMPLATE.format(
            label=_PLIST_LABEL,
            rewindex_bin=rewindex_bin,
            log_dir=log_dir,
        ))

    subprocess.run(["launchctl", "load", _PLIST_PATH], check=True)


def uninstall() -> None:
    if os.path.exists(_PLIST_PATH):
        subprocess.run(["launchctl", "unload", _PLIST_PATH], check=False)
        os.remove(_PLIST_PATH)
