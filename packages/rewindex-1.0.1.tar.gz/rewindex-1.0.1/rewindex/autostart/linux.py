# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import os
import shutil
import subprocess

_SERVICE_NAME = "rewindex.service"
_SERVICE_DIR = os.path.expanduser("~/.config/systemd/user")
_SERVICE_PATH = os.path.join(_SERVICE_DIR, _SERVICE_NAME)

_UNIT_TEMPLATE = """\
[Unit]
Description=Rewindex file snapshot daemon
After=default.target

[Service]
Type=simple
ExecStart={rewindex_bin} start
Restart=on-failure
RestartSec=5

[Install]
WantedBy=default.target
"""


def _validate_bin(path: str) -> None:
    if not os.path.isabs(path):
        raise RuntimeError(f"rewindex binary path is not absolute: {path}")
    try:
        stat = os.stat(path)
        if stat.st_uid not in (os.getuid(), 0):
            raise RuntimeError(
                f"rewindex binary at {path} is owned by uid {stat.st_uid} — refusing to register"
            )
    except OSError as e:
        raise RuntimeError(f"Cannot stat rewindex binary: {e}")


def install() -> None:
    rewindex_bin = shutil.which("rewindex")
    if not rewindex_bin:
        raise RuntimeError("rewindex binary not found in PATH")
    _validate_bin(rewindex_bin)

    os.makedirs(_SERVICE_DIR, exist_ok=True)
    with open(_SERVICE_PATH, "w") as f:
        f.write(_UNIT_TEMPLATE.format(rewindex_bin=rewindex_bin))

    subprocess.run(["systemctl", "--user", "daemon-reload"], check=True)
    subprocess.run(["systemctl", "--user", "enable", _SERVICE_NAME], check=True)
    subprocess.run(["systemctl", "--user", "start", _SERVICE_NAME], check=True)


def uninstall() -> None:
    subprocess.run(["systemctl", "--user", "stop", _SERVICE_NAME], check=False)
    subprocess.run(["systemctl", "--user", "disable", _SERVICE_NAME], check=False)
    if os.path.exists(_SERVICE_PATH):
        os.remove(_SERVICE_PATH)
    subprocess.run(["systemctl", "--user", "daemon-reload"], check=False)
