# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import click

from rewindex.daemon.runner import stop_daemon


@click.command()
def stop_cmd() -> None:
    """Stop the daemon."""
    stop_daemon()
