# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import os
import sys

import click


def _is_case_sensitive_fs() -> bool:
    return sys.platform != "win32" and sys.platform != "darwin"


def _normalize(path: str) -> str:
    return path if _is_case_sensitive_fs() else os.path.normcase(path)


def _detect_project_from_cwd(projects: list) -> str | None:
    """Return project name whose watched folder best matches CWD (longest prefix = most specific)."""
    cwd = _normalize(os.path.realpath(os.getcwd()))
    best_name: str | None = None
    best_len: int = -1
    for p in projects:
        for folder in p.get("folders", []):
            folder_real = _normalize(os.path.realpath(os.path.expanduser(folder)))
            if cwd == folder_real or cwd.startswith(folder_real + os.sep):
                if len(folder_real) > best_len:
                    best_len = len(folder_real)
                    best_name = p["name"]
    return best_name


def _print_no_project_hint(projects: list) -> None:
    click.echo("Not inside any watched project folder.")
    click.echo("Available projects:")
    for i, p in enumerate(projects):
        click.echo(f"  PJ{i+1}  {p['name']}")
    click.echo("")
    click.echo("Use -p to specify:  rewindex log -p PJ1")


def _print_project_header(name: str, projects: list) -> None:
    pj_id = next((f"PJ{i+1}" for i, p in enumerate(projects) if p["name"] == name), "")
    click.echo(f"\nCurrent Project : {pj_id} | {name}")


def resolve_project(projects: list, name: str | None, interactive: bool = True, show_header: bool = True) -> str | None:
    """
    Resolve project name from CLI input.
    - name provided   → find matching project or print error
    - name is None    → detect from CWD (longest match); if no match, print hint and return None
    Returns project name, or None if caller should exit.
    """
    if name is not None:
        from rewindex.utils.id_parse import parse_project_ref
        resolved_name = parse_project_ref(name, projects)
        if resolved_name is None:
            click.echo(f"Project '{name}' not found.")
            click.echo("Available: " + ", ".join(f"PJ{i+1} {p['name']}" for i, p in enumerate(projects)))
            return None
        for p in projects:
            if p["name"] == resolved_name:
                if show_header:
                    _print_project_header(resolved_name, projects)
                return resolved_name
        click.echo(f"Project '{name}' not found.")
        click.echo("Available: " + ", ".join(f"PJ{i+1} {p['name']}" for i, p in enumerate(projects)))
        return None

    detected = _detect_project_from_cwd(projects)
    if detected:
        if show_header:
            _print_project_header(detected, projects)
        return detected

    if len(projects) == 1:
        resolved_name = projects[0]["name"]
        if show_header:
            _print_project_header(resolved_name, projects)
        return resolved_name

    _print_no_project_hint(projects)
    return None
