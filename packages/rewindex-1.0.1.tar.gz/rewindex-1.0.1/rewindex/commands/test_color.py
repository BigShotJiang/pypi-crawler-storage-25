# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import click


def s(text, **kwargs):
    return click.style(str(text), **kwargs)


@click.command()
def test_color_cmd() -> None:
    """Demo: color output preview for session log view."""

    # — color palette (matching website) —
    ACCENT = dict(fg="cyan", bold=True)       # SN IDs, SS IDs
    MUTED = dict(fg="bright_black")           # secondary info, file IDs
    GREEN = dict(fg="green")                  # CREATE, success
    YELLOW = dict(fg="yellow")                # CHANGE
    RED = dict(fg="red")                      # DELETE, REMOVED
    WHITE_B = dict(bold=True)                  # command names, headers
    DIM = dict(dim=True)                      # separators

    click.echo()
    click.echo(s("Current Project : ", **MUTED) + s("PJ1", **ACCENT) + s(" | 8", **MUTED))
    click.echo()
    click.echo(s("Sessions", **WHITE_B) + s("  (DD/MM/YY UTC+0)", **MUTED))

    # ── SS003 ──
    click.echo(
        s("SS3", **ACCENT) + s(" | ", **MUTED)
        + s("14:30", **WHITE_B) + s("   Claude Code", **MUTED)
        + s("       3 files", fg="cyan")
    )
    click.echo("─" * 64)

    # file rows
    click.echo(
        s("  SN2J", **ACCENT) + s("   14:30", **MUTED)
        + s("   v3", **WHITE_B)
        + s("   src/auth.py")
        + s("   ", **MUTED) + s("[CHANGE]", **YELLOW)
    )
    click.echo(
        s("  SNND", **ACCENT) + s("   14:30", **MUTED)
        + s("   v1", **WHITE_B)
        + s("   src/middleware.py")
        + s("   ", **MUTED) + s("[CREATE]", **GREEN)
    )
    click.echo(
        s("  SNPQ", **ACCENT) + s("   14:30", **MUTED)
        + s("   v3", **WHITE_B)
        + s("   src/config.py")
        + s("   ", **MUTED) + s("[CHANGE]", **YELLOW)
    )

    # notes
    click.echo(
        s("         ", **MUTED)
        + s("— refactored auth to JWT", fg="green")
    )
    click.echo(
        s("  ", **MUTED)
        + s("# checkpoint before deploy", fg="green", dim=True)
    )

    click.echo()

    # ── SS002 ──
    click.echo(
        s("SS2", **ACCENT) + s(" | ", **MUTED)
        + s("14:15", **WHITE_B) + s("   manual", **MUTED)
        + s("             1 file", fg="cyan")
    )
    click.echo("─" * 64)

    click.echo(
        s("  SNND", **ACCENT) + s("   14:15", **MUTED)
        + s("   v1", **WHITE_B)
        + s("   config.py")
        + s("   ", **MUTED) + s("[CHANGE]", **YELLOW)
    )

    click.echo()

    # ── SS001 ──
    click.echo(
        s("SS1", **ACCENT) + s(" | ", **MUTED)
        + s("14:00", **WHITE_B) + s("   Cursor", **MUTED)
        + s("              5 files", fg="cyan")
    )
    click.echo("─" * 64)

    click.echo(
        s("  SN2J", **ACCENT) + s("   14:00", **MUTED)
        + s("   v1", **WHITE_B)
        + s("   src/auth.py")
        + s("   ", **MUTED) + s("[CREATE]", **GREEN)
    )
    click.echo(
        s("  SNPQ", **ACCENT) + s("   14:00", **MUTED)
        + s("   v1", **WHITE_B)
        + s("   src/config.py")
        + s("   ", **MUTED) + s("[CREATE]", **GREEN)
    )
    click.echo(
        s("  SNRS", **ACCENT) + s("   14:00", **MUTED)
        + s("   v1", **WHITE_B)
        + s("   src/routes.py")
        + s("   ", **MUTED) + s("[CREATE]", **GREEN)
    )
    click.echo(
        s("  SNTU", **ACCENT) + s("   14:00", **MUTED)
        + s("   v1", **WHITE_B)
        + s("   tests/test_auth.py")
        + s("   ", **MUTED) + s("[CREATE]", **GREEN)
    )
    click.echo(
        s("  SN8K", **ACCENT) + s("   14:00", **MUTED)
        + s("   v1", **WHITE_B)
        + s("   README.md")
        + s("   ", **MUTED) + s("[CREATE]", **GREEN)
    )

    # delete example
    click.echo()
    click.echo(
        s("         ", **MUTED)
        + s("— initial project setup", fg="green")
    )

    click.echo()

    # ── Demo: rewind output ──
    click.echo("─" * 64)
    click.echo(s("  Demo: rewind output", **WHITE_B))
    click.echo("─" * 64)
    click.echo()

    click.echo(
        s("$ ", fg="cyan", bold=True)
        + s("rewindex rewind", **WHITE_B)
        + s(" SS2 ", **ACCENT)
        + s("--yes", fg="cyan")
    )
    click.echo()

    click.echo(
        s("  SNND", **ACCENT) + s("   v1", **WHITE_B)
        + s("   config.py")
        + s("   ", **MUTED) + s("[RESTORE]", **GREEN)
    )
    click.echo(
        s("  SNPQ", **ACCENT) + s("   v3→v2", **MUTED)
        + s("   src/config.py")
        + s("   ", **MUTED) + s("[REVERT]", **YELLOW)
    )
    click.echo(
        s("  SN8K", **ACCENT) + s("   v1", **WHITE_B)
        + s("   README.md")
        + s("   ", **MUTED) + s("[DELETE]", **RED)
        + s("  (move → old-path/README.md)", fg="bright_black")
    )

    click.echo()
    click.echo(s("  3 file(s) rewound to SS2.", fg="green", bold=True))
    click.echo(s("  Full project state restored.", fg="green"))

    click.echo()
