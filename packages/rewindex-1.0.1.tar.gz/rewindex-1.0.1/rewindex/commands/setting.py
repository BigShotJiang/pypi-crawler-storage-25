# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import click

from rewindex.config.defaults import DEFAULT_SESSION_MAX, DEFAULT_SESSION_SAFE
from rewindex.config.urls import LINK_PRICING


@click.command()
@click.argument("subcommand", default=None, required=False)
@click.argument("subarg", default=None, required=False)
@click.option("--safe", type=int, default=None, help="Sessions kept safe from trim.")
@click.option("--max", "max_val", type=int, default=None, help="Trim triggers at this session count.")
def setting_cmd(subcommand: str | None, subarg: str | None, safe: int | None, max_val: int | None) -> None:
    """Show or update session limit settings.

    \b
    rewindex setting                          show current settings
    rewindex setting --safe <n>               update safe limit
    rewindex setting --max <n>                update max limit
    rewindex setting --safe <n> --max <n>     update both
    rewindex setting precompute on|off        toggle pre-compute fullbase (Pro)
    """
    from rewindex.config.loader import load_config, save_config

    # Handle precompute subcommand
    if subcommand and subcommand.lower() == "precompute":
        _handle_precompute(subarg)
        return

    config = load_config()
    current_safe = config.get("session_safe", DEFAULT_SESSION_SAFE)
    current_max = config.get("session_max", DEFAULT_SESSION_MAX)

    # Show current settings (no flags)
    if safe is None and max_val is None:
        cut = current_max - current_safe
        click.echo("\nSetting — Session limits")
        click.echo("─" * 56)
        click.echo(f"  safe : {current_safe}   sessions kept safe from trim")
        click.echo(f"  max  : {current_max}   trim triggers when reached")
        click.echo(f"  cut  : {cut}   oldest sessions removed per trim (max - safe)")
        click.echo()
        click.echo(f"Your history keeps up to {current_max} sessions.")
        click.echo(f"When full, the oldest {cut} are trimmed — the latest {current_safe} stay safe.")
        click.echo()
        click.echo("To change the limits, go with: rewindex setting --safe <New_Number> --max <New_Number>")
        click.echo()
        return

    # Update
    new_safe = safe if safe is not None else current_safe
    new_max = max_val if max_val is not None else current_max

    # Validate
    if new_safe < 1:
        click.echo("\nError: safe must be at least 1.")
        click.echo("  safe = sessions kept safe from trim, will not be deleted")
        click.echo("  max  = session count that triggers trim, must be higher than safe")
        click.echo()
        click.echo("  (max - safe = cut) cut = sessions removed per trim, fullbase pre-computed every cut sessions")
        click.echo("  Recommended cut: 50–200 sessions (e.g. --safe 500 --max 600)")
        click.echo()
        click.echo("Usage: rewindex setting --safe N --max M")
        click.echo()
        return

    if new_max <= new_safe:
        click.echo("\nError: max must be greater than safe.")
        click.echo("  safe = sessions kept safe from trim, will not be deleted")
        click.echo("  max  = session count that triggers trim, must be higher than safe")
        click.echo()
        click.echo("  (max - safe = cut) cut = sessions removed per trim, fullbase pre-computed every cut sessions")
        click.echo("  Recommended cut: 50–200 sessions (e.g. --safe 500 --max 600)")
        click.echo()
        click.echo("Usage: rewindex setting --safe N --max M")
        click.echo()
        return

    cut = new_max - new_safe

    # Save to config.yaml (global)
    config["session_safe"] = new_safe
    config["session_max"] = new_max
    save_config(config)

    click.echo("\nSettings updated.")
    click.echo("─" * 56)
    click.echo(f"  safe : {new_safe}   sessions kept safe from trim — will not be deleted")
    click.echo(f"  max  : {new_max}   trim triggers when session count reaches this")
    click.echo(f"  cut  : {cut}    (max - safe = cut) sessions removed per trim, fullbase pre-computed every cut sessions")

    if cut < 50:
        click.echo()
        click.echo(f"Warning: cut is too small ({cut}) — trim and fullbase will run very frequently.")
        click.echo("Recommended cut: 50–200 sessions (e.g. --safe 500 --max 600)")
    elif cut > 200:
        click.echo()
        click.echo(f"Warning: cut is large ({cut}) — rewind may be slow (worst case: {cut} diffs to reconstruct).")
        click.echo("Recommended cut: 50–200 sessions (e.g. --safe 500 --max 600)")
    click.echo()


def _handle_precompute(arg: str | None) -> None:
    from rewindex.license import get_membership
    from rewindex.config.loader import load_config, save_config

    membership = get_membership()
    if membership.get("plan") != "Pro":
        click.echo(f"\nYou're on the Free plan.")
        click.echo(f"Pre-compute Fullbase is only available on the Pro plan.")
        click.echo(f"\nUpgrade at {LINK_PRICING}")
        click.echo()
        return

    config = load_config()
    current_safe = config.get("session_safe", DEFAULT_SESSION_SAFE)
    current_max = config.get("session_max", DEFAULT_SESSION_MAX)
    cut = current_max - current_safe

    if arg and arg.lower() == "on":
        config["precompute_enabled"] = True
        save_config(config)
        click.echo("\nPre-compute fullbase enabled.")
        click.echo(f"Interval : every {cut} sessions  (= cut)")
        click.echo()
        return

    if arg and arg.lower() == "off":
        config["precompute_enabled"] = False
        save_config(config)
        click.echo("\nPre-compute fullbase disabled.")
        click.echo()
        return

    # Show current state + interactive toggle
    enabled = config.get("precompute_enabled", False)
    state = "on" if enabled else "off"
    click.echo(f"\nPre-compute fullbase  : {state}")
    click.echo(f"Interval              : every {cut} sessions  (= cut)")

    if not click.get_text_stream("stdin").isatty():
        return

    import questionary
    prompt = "Disable faster rewind?" if enabled else "Enable faster rewind?"
    click.echo()
    if questionary.confirm(prompt, default=False).ask():
        config["precompute_enabled"] = not enabled
        save_config(config)
        new_state = "enabled" if not enabled else "disabled"
        click.echo(f"Pre-compute fullbase {new_state}.")
