# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import click

from rewindex.config.urls import LINK_PRICING, LINK_SUBSCRIPTION


@click.command()
@click.option("--license", "license_key", default=None, help="Validate and activate a Pro license key.")
def member_cmd(license_key: str | None) -> None:
    """Show current plan or activate a Pro license key.

    \b
    rewindex member                    show membership info
    rewindex member --license <key>    activate a Pro license key
    """
    from rewindex.license import get_membership, activate_license

    if license_key:
        _activate(license_key)
        return

    membership = get_membership()
    _show_membership(membership)


def _activate(license_key: str) -> None:
    from rewindex.license import activate_license, get_membership

    try:
        result = activate_license(license_key)
    except ConnectionError:
        click.echo("\nError: could not reach validation server.")
        click.echo("Check your connection and try again.")
        click.echo()
        return
    except ValueError as e:
        err = str(e)
        if "expired" in err.lower():
            click.echo("\nError: license key has expired.")
            click.echo(f"Renew at {LINK_SUBSCRIPTION}")
        elif "inactive" in err.lower():
            click.echo("\nError: license key is inactive.")
            click.echo(f"Contact support or visit {LINK_SUBSCRIPTION}")
        else:
            click.echo("\nError: license key is not valid.")
            click.echo(f"Check the key and try again, or visit {LINK_SUBSCRIPTION}")
        click.echo()
        return

    click.echo("\nLicense activated successfully.")
    click.echo("─" * 54)
    membership = get_membership()
    _show_membership(membership)
    _prompt_precompute()


def _show_membership(membership: dict) -> None:
    from rewindex.config.loader import load_config
    from rewindex.config.defaults import DEFAULT_SESSION_MAX
    from rewindex.utils.formatting import fmt_date

    plan = membership.get("plan", "Free")
    is_pro = plan == "Pro"

    config = load_config()
    current_max = config.get("session_max", DEFAULT_SESSION_MAX)

    click.echo("\nMembership")
    click.echo("─" * 54)
    click.echo(f"Plan      : {plan}")

    projects = config.get("projects", [])
    project_count = len(projects)
    max_folders = max((len(p.get("folders", [])) for p in projects), default=0)

    if is_pro:
        status = membership.get("status", "active")
        expires_raw = membership.get("expires_at", "")
        expires = fmt_date(expires_raw) if expires_raw else "—"
        click.echo(f"Status    : {status}")
        click.echo(f"Expires   : {expires}")
        click.echo()
        click.echo(f"Projects  : Unlimited ({project_count}/Unlimited)")
        click.echo(f"Folders   : Up to 5 per project ({max_folders}/5)")
    else:
        click.echo()
        click.echo(f"Projects  : 1 max ({project_count}/1)")
        click.echo(f"Folders   : 1 per project max ({max_folders}/1)")

    click.echo(f"History   : Unlimited sessions (currently keeping {current_max})")

    if is_pro:
        click.echo()
        click.echo(f"Manage plan  : {LINK_SUBSCRIPTION}")
    else:
        click.echo()
        click.echo(f"License   : rewindex member --license [key]")
        click.echo(f"Upgrade   : {LINK_PRICING}")
    click.echo()


def _prompt_precompute() -> None:
    from rewindex.config.loader import load_config, save_config

    config = load_config()
    if config.get("precompute_enabled", False):
        return

    click.echo()
    click.echo("Pro feature: Pre-compute fullbase")
    click.echo("Speeds up rewind by pre-computing full snapshots periodically.")
    import questionary
    enable = questionary.confirm("Enable pre-compute fullbase?", default=True).ask()

    if enable:
        config["precompute_enabled"] = True
        save_config(config)
        click.echo("Pre-compute fullbase enabled.")
    else:
        click.echo("You can enable it later with: rewindex setting precompute on")
