# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import click

from rewindex.config.loader import load_config
from rewindex.db.connection import get_connection
from rewindex.commands._project import resolve_project


@click.command()
@click.argument("target")
@click.argument("arg2", default=None, required=False)
@click.argument("arg3", default=None, required=False)
@click.option("--project", "-p", default=None, help="Project name or PJ ID.")
def note_cmd(target: str, arg2: str | None, arg3: str | None, project: str | None) -> None:
    """Annotate a session, file version, or snap.

    \b
    rewindex note <FileID> [version] "msg"   annotate file version (latest if omitted)
    rewindex note SS [id|latest] "msg"       annotate session
    rewindex note <SN> "msg"                 annotate snap
    """
    from rewindex.utils.id_parse import (
        is_session_target, is_snap_target, is_file_id,
        parse_session_id, parse_snap_id, fmt_session, fmt_snap,
    )
    from rewindex.utils.formatting import fmt_date, fmt_date_header
    from rewindex.utils.validation import validate_string
    from rewindex.db.queries import (
        get_session_by_uid, get_latest_session, get_oldest_session,
        get_file_registry_by_id, get_file_version_range,
        resolve_file_version, get_latest_file_version, get_file_version,
        get_files_in_session, update_session_note, update_file_note,
    )

    config = load_config()
    all_projects = config.get("projects", [])
    if not all_projects:
        click.echo("No projects configured.")
        return

    resolved = resolve_project(all_projects, project or None)
    if resolved is None:
        return

    conn = get_connection(resolved)
    try:
        # Parse: rewindex note SS [latest|n] "msg"
        if target.upper() == "SS":
            message = arg3 if arg3 else arg2
            session_ref = arg2 if arg3 else "latest"
            if not message:
                _show_note_usage()
                return
            _note_session(conn, resolved, session_ref, message)
            return

        # Parse: rewindex note SS3 "msg"
        if is_session_target(target):
            message = arg2
            if not message:
                _show_note_usage()
                return
            try:
                ss_uid = parse_session_id(target)
            except ValueError as e:
                click.echo(f"Error: {e}")
                return
            _note_session(conn, resolved, str(ss_uid), message)
            return

        # Parse: rewindex note SN [latest|n] "msg"
        if target.upper() == "SN":
            message = arg3 if arg3 else arg2
            snap_ref = arg2 if arg3 else "latest"
            if not message:
                _show_note_usage()
                return
            if snap_ref.lower() == "latest":
                latest_snap = conn.execute(
                    """SELECT f.uid FROM file f
                       JOIN file_registry r ON f.file_registry_uid = r.uid
                       WHERE r.project = ? AND f.is_corrupted = 0
                       ORDER BY f.uid DESC LIMIT 1""",
                    (resolved,),
                ).fetchone()
                if not latest_snap:
                    click.echo("No snapshots found.")
                    return
                _note_snap(conn, resolved, latest_snap["uid"], message)
            else:
                try:
                    sn_uid = int(snap_ref)
                except ValueError:
                    click.echo(f"Error: invalid snap reference '{snap_ref}'.")
                    return
                _note_snap(conn, resolved, sn_uid, message)
            return

        # Parse: rewindex note SN42 "msg"
        if is_snap_target(target):
            message = arg2
            if not message:
                _show_note_usage()
                return
            try:
                sn_uid = parse_snap_id(target)
            except ValueError as e:
                click.echo(f"Error: {e}")
                return
            _note_snap(conn, resolved, sn_uid, message)
            return

        # Parse: rewindex note latest "msg"
        if target.lower() == "latest":
            message = arg2
            if not message:
                _show_note_usage()
                return
            latest_snap = conn.execute(
                """SELECT f.uid FROM file f
                   JOIN file_registry r ON f.file_registry_uid = r.uid
                   WHERE r.project = ? AND f.is_corrupted = 0
                   ORDER BY f.uid DESC LIMIT 1""",
                (resolved,),
            ).fetchone()
            if not latest_snap:
                click.echo("No snapshots found.")
                return
            _note_snap(conn, resolved, latest_snap["uid"], message)
            return

        # Parse: rewindex note D1VS [v3] "msg"
        if is_file_id(target):
            if arg3:
                version_str = arg2
                message = arg3
            elif arg2:
                import re
                if re.match(r'^v?\d+$', arg2.strip()) or arg2.strip().lower() == "latest":
                    _show_note_usage()
                    return
                message = arg2
                version_str = None
            else:
                _show_note_usage()
                return
            _note_file(conn, resolved, target, version_str, message)
            return

        # If target looks like a message but no proper target given
        _show_note_usage()
    finally:
        conn.close()


def _note_session(conn, project: str, ref: str, message: str) -> None:
    from rewindex.utils.id_parse import fmt_session
    from rewindex.utils.formatting import fmt_date, fmt_date_header
    from rewindex.utils.validation import validate_string
    from rewindex.db.queries import (
        get_session_by_uid, get_latest_session, get_oldest_session,
        get_files_in_session, update_session_note,
    )

    try:
        validate_string(message, "message")
    except ValueError as e:
        click.echo(f"Error: {e}")
        return

    if ref.lower() == "latest":
        session = get_latest_session(conn, project)
        if not session:
            click.echo("No sessions found.")
            return
    else:
        try:
            uid = int(ref)
        except ValueError:
            click.echo(f"Error: invalid session reference '{ref}'.")
            return
        session = get_session_by_uid(conn, uid)

    if not session:
        oldest = get_oldest_session(conn, project)
        latest = get_latest_session(conn, project)
        if oldest and latest:
            click.echo(f"Error: SS{ref} not found — may have been trimmed.")
            click.echo(f"Available: {fmt_session(oldest['uid'])} (oldest) → {fmt_session(latest['uid'])} (latest)")
        else:
            click.echo(f"Error: session not found.")
        return

    update_session_note(conn, session["uid"], message)

    files = get_files_in_session(conn, session["uid"])
    unique = {}
    for f in files:
        unique[f["file_id"]] = f
    file_count = len(unique)
    file_word = "file" if file_count == 1 else "files"

    click.echo(f"\nUpdate note to {fmt_session(session['uid'])}")
    click.echo("─" * 54)
    for f in unique.values():
        click.echo(f"  {f['file_id']}   {f['filepath']:<30} v{f['file_version']}")
    click.echo(f"\n  # \"{message}\"")
    click.echo(f"\nNote saved.")
    click.echo()


def _note_snap(conn, project: str, snap_uid: int, message: str) -> None:
    from rewindex.utils.id_parse import fmt_snap
    from rewindex.utils.formatting import fmt_date, fmt_date_header
    from rewindex.utils.validation import validate_string
    from rewindex.db.queries import get_file_version, update_file_note

    try:
        validate_string(message, "message")
    except ValueError as e:
        click.echo(f"Error: {e}")
        return

    snap = get_file_version(conn, snap_uid)
    if not snap:
        click.echo(f"Error: {fmt_snap(snap_uid)} not found.")
        return

    update_file_note(conn, snap_uid, message)

    reg = conn.execute("SELECT * FROM file_registry WHERE uid = ?", (snap["file_registry_uid"],)).fetchone()

    click.echo(f"\nUpdate note to {reg['file_id']} v{snap['file_version']}")
    click.echo("─" * 54)
    click.echo(f"  {fmt_snap(snap_uid)}   {reg['file_id']}   {reg['filepath']}   v{snap['file_version']}   # \"{message}\"")
    click.echo(f"\nNote saved.")
    click.echo()


def _note_file(conn, project: str, file_id_str: str, version_str: str | None, message: str) -> None:
    from rewindex.utils.validation import validate_string
    from rewindex.db.queries import (
        get_file_registry_by_id, get_file_version_range,
        resolve_file_version, get_latest_file_version, update_file_note,
    )
    import re

    try:
        validate_string(message, "message")
    except ValueError as e:
        click.echo(f"Error: {e}")
        return

    reg = get_file_registry_by_id(conn, project, file_id_str)
    if not reg:
        click.echo(f'Error: unknown FileID "{file_id_str}".')
        return

    min_v, max_v = get_file_version_range(conn, reg["uid"])
    if min_v is None:
        click.echo(f"No versions found for {file_id_str}.")
        return

    if version_str is None or version_str.strip().lower() == "latest":
        target_ver = max_v
    else:
        m = re.match(r'^v?(\d+)$', version_str.strip())
        if m:
            target_ver = int(m.group(1))
        else:
            click.echo(f'Error: invalid version "{version_str}". Use vN or "latest".')
            return

    row = resolve_file_version(conn, project, file_id_str, target_ver)
    if not row:
        click.echo(f"Error: {file_id_str} v{target_ver} not found — version may have been trimmed.")
        click.echo(f"Available: v{min_v} (oldest) → v{max_v} (latest)")
        return

    from rewindex.utils.formatting import fmt_date
    from rewindex.utils.id_parse import fmt_snap
    update_file_note(conn, row["uid"], message)

    click.echo(f"\nUpdate note to {reg['file_id']} v{target_ver}")
    click.echo("─" * 54)
    click.echo(f"  {fmt_snap(row['uid'])}   {reg['file_id']}   {reg['filepath']}   v{target_ver}   # \"{message}\"")
    click.echo(f"\nNote saved.")
    click.echo()


def _show_note_usage() -> None:
    click.echo("\nError: missing target.")
    click.echo("Usage:")
    click.echo('  rewindex note <FileID> [version] "message"   # e.g. rewindex note D1VS v3 "fix: ..."')
    click.echo('  rewindex note SS [id|latest] "message"       # e.g. rewindex note SS latest "..."')
    click.echo('  rewindex note SN<n> "message"                # e.g. rewindex note SN42 "..."')
    click.echo()
