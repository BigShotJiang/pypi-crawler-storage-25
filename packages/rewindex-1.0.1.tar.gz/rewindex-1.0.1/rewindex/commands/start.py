# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import time

import click

from rewindex.config.loader import load_config
from rewindex.daemon.runner import is_running, start_daemon


@click.command()
def start_cmd() -> None:
    """Start the daemon."""
    config = load_config()

    try:
        start_daemon(config)
    except Exception as e:
        click.echo(f"\nError: failed to start daemon — {e}")
        return

    time.sleep(1)

    if not is_running():
        click.echo("\nError: daemon did not start.")
        click.echo("Check logs at ~/.rewindex/daemon.log")
