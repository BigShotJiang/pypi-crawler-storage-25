# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import subprocess
import sys

import click

from rewindex import __version__


@click.command()
@click.option("--latest", is_flag=True, help="Upgrade to latest version from PyPI")
@click.option("--sync", is_flag=True, help="Sync config with current version defaults")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt")
def update_cmd(latest: bool, sync: bool, yes: bool) -> None:
    """Update Rewindex to the latest version.

    \b
    rewindex update                check for updates
    rewindex update --latest       upgrade from PyPI
    rewindex update --latest --yes upgrade without confirmation
    rewindex update --sync         sync config with current version defaults
    """
    if latest:
        _upgrade(yes)
    elif sync:
        _sync_config()
    else:
        _check_version()


def _get_latest_version() -> str | None:
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "index", "versions", "rewindex"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0 and result.stdout:
            return result.stdout.strip().split("(")[-1].rstrip(")")
    except Exception:
        pass
    return None


def _check_version() -> None:
    latest = _get_latest_version()
    if latest is None:
        click.echo("\nError: could not reach update server.")
        click.echo("Check your connection and try again.")
        click.echo()
        return

    if latest and latest != __version__:
        click.echo(f"\nCurrent version : {__version__}")
        click.echo(f"Latest version  : {latest}")
        click.echo()
    else:
        click.echo(f"\nRewindex {__version__} is up to date.")
        click.echo()


def _upgrade(yes: bool = False) -> None:
    latest = _get_latest_version()

    if latest is None:
        click.echo("\nError: could not reach update server.")
        click.echo("Check your connection and try again.")
        click.echo()
        return

    if latest == __version__:
        click.echo(f"\nRewindex {__version__} is up to date.")
        click.echo()
        return

    if not yes:
        import questionary
        confirm = questionary.confirm(
            f"Upgrade rewindex from {__version__} to {latest}?"
        ).ask()
        if not confirm:
            click.echo("Upgrade cancelled.")
            return

    click.echo(f"\nCurrent version : {__version__}")
    click.echo(f"Latest version  : {latest}")
    click.echo()

    from rewindex.daemon.runner import stop_daemon, is_running
    was_running = is_running()
    if was_running:
        click.echo("Stopping daemon...")
    click.echo("Updating...")

    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", "--upgrade", "rewindex"],
        capture_output=False,
    )
    if result.returncode != 0:
        click.echo("\nError: upgrade failed. Try: pip install --upgrade rewindex")
        click.echo()
        return

    if was_running:
        click.echo("Restarting daemon...")
        from rewindex.config.loader import load_config
        from rewindex.daemon.runner import restart_daemon
        config = load_config()
        restart_daemon(config)

    click.echo(f"\nUpdated to {latest}. Daemon restarted.")
    click.echo()


def _sync_config() -> None:
    import yaml
    from rewindex.config.loader import load_config, save_config
    from rewindex.config.defaults import CONFIG_PATH, DEFAULT_CONFIG, DEFAULT_EXCLUDE

    try:
        with open(CONFIG_PATH) as f:
            raw = yaml.safe_load(f) or {}
    except Exception:
        raw = {}

    config = load_config()
    added = []

    for key in DEFAULT_CONFIG:
        if key not in raw:
            added.append(key)

    for pattern in DEFAULT_EXCLUDE:
        if pattern not in raw.get("global_exclude", []):
            added.append(f"global_exclude: {pattern}")

    save_config(config)

    if added:
        click.echo(f"Config synced — added: {', '.join(added)}")
    else:
        click.echo("Config is already up to date.")
