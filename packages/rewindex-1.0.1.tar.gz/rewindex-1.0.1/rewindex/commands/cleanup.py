# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import os
import shutil

import click

from rewindex.config.loader import load_config, save_config
from rewindex.config.defaults import SNAPSHOTS_DIR, TRASH_DIR
from rewindex.daemon.runner import restart_daemon


@click.command()
@click.option("--trash", is_flag=True, help="Show or manage trashed projects.")
@click.option("--yes", is_flag=True, help="Permanently delete all trashed projects.")
@click.argument("action", default=None, required=False)
@click.argument("target", default=None, required=False)
def cleanup_cmd(trash: bool, yes: bool, action: str | None, target: str | None) -> None:
    """Clean up snapshot data.

    \b
    rewindex cleanup --trash                         show trashed projects
    rewindex cleanup --trash --yes                   permanently delete all
    rewindex cleanup --trash restore <name|PJID>     restore a trashed project
    """
    if not trash:
        click.echo("Usage: rewindex cleanup --trash")
        click.echo("  --trash              show trashed projects")
        click.echo("  --trash --yes        permanently delete all")
        click.echo("  --trash restore <name>  restore a project")
        return

    if action and action.lower() == "restore":
        if not target:
            click.echo("Error: specify a project name to restore.")
            return
        _restore_project(target)
        return

    trashed = _list_trash()
    if not trashed:
        click.echo("\nTrash is empty.")
        click.echo()
        return

    if yes:
        _delete_all_trash(trashed)
        return

    click.echo("\nTrash contents")
    click.echo("─" * 54)
    for name, snap_count, trashed_at in trashed:
        click.echo(f"  {name:<20} {snap_count} snaps   trashed {trashed_at}")
    click.echo()
    click.echo("To restore: rewindex cleanup --trash restore <name>")
    click.echo("To delete permanently: rewindex cleanup --trash --yes")
    click.echo()


def _list_trash() -> list[tuple[str, int, str]]:
    if not os.path.isdir(TRASH_DIR):
        return []
    result = []
    for name in sorted(os.listdir(TRASH_DIR)):
        path = os.path.join(TRASH_DIR, name)
        if not os.path.isdir(path):
            continue
        snap_count = sum(1 for _ in _iter_files(path))
        mtime = os.path.getmtime(path)
        from rewindex.utils.formatting import fmt_date
        from datetime import datetime, timezone
        trashed_at = fmt_date(datetime.fromtimestamp(mtime, tz=timezone.utc).isoformat())
        result.append((name, snap_count, trashed_at))
    return result


def _iter_files(path: str):
    for root, dirs, files in os.walk(path):
        for f in files:
            yield os.path.join(root, f)


def _delete_all_trash(trashed: list) -> None:
    click.echo()
    for name, snap_count, _ in trashed:
        path = os.path.join(TRASH_DIR, name)
        shutil.rmtree(path, ignore_errors=True)
        click.echo(f"Deleted: {name} ({snap_count} snaps)")
    click.echo("\nTrash cleared.")
    click.echo()


def _restore_project(name: str) -> None:
    if not os.path.isdir(TRASH_DIR):
        click.echo(f'\nError: "{name}" not found in trash.')
        click.echo()
        return

    trash_path = os.path.join(TRASH_DIR, name)
    if not os.path.isdir(trash_path):
        click.echo(f'\nError: "{name}" not found in trash.')
        click.echo()
        return

    dest = os.path.join(SNAPSHOTS_DIR, name)
    shutil.move(trash_path, dest)

    config = load_config()
    existing_names = [p["name"] for p in config.get("projects", [])]
    if name not in existing_names:
        config["projects"].append({"name": name, "folders": []})
        save_config(config)

    proj = next((p for p in config["projects"] if p["name"] == name), None)
    folders = proj.get("folders", []) if proj else []

    click.echo(f'\nProject "{name}" restored.')
    if folders:
        click.echo("Daemon now watching:")
        for f in folders:
            click.echo(f"  {f}")
    else:
        click.echo("Note: you may need to re-add watched folders with `rewindex project add-folder`.")
    click.echo()
    restart_daemon(config)
