# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import os

import click

from rewindex.config.loader import load_config
from rewindex.db.connection import get_connection
from rewindex.snapshot.engine import snapshot_file, read_disk_warning
from rewindex.commands._project import resolve_project


@click.command()
@click.argument("message", default="")
@click.option("--project", "-p", default=None, help="Project name or PJ ID.")
def snap_cmd(message: str, project: str | None) -> None:
    """Snap all changed files into a session.

    \b
    rewindex snap                    snap all changed files
    rewindex snap "message"          snap with a session note
    """
    from rewindex.utils.validation import validate_string
    from rewindex.daemon.watcher import safe_walk, _matches_exclude
    from rewindex.config.defaults import DEFAULT_EXCLUDE, SECURITY_EXCLUDE
    from rewindex.db.queries import (
        close_session,
        create_forced_session,
        get_files_in_session,
        get_latest_session,
        update_session_note,
    )
    from rewindex.utils.formatting import fmt_date, fmt_date_header
    from rewindex.utils.id_parse import fmt_session
    from datetime import datetime, timezone

    config = load_config()
    projects = config.get("projects", [])

    if not projects:
        click.echo("No projects configured.")
        return

    project_name = resolve_project(projects, project, interactive=False)
    if project_name is None:
        return

    proj = next(p for p in projects if p["name"] == project_name)

    disk_warn = read_disk_warning()
    if disk_warn:
        click.echo(f"WARNING: {disk_warn} — snapshots may be skipped")

    if message:
        try:
            validate_string(message, "message")
        except ValueError as e:
            click.echo(f"Error: {e}")
            return

    global_exclude = config.get("global_exclude", DEFAULT_EXCLUDE)
    exclude = global_exclude + proj.get("project_exclude", [])
    folders = proj.get("folders", [])

    conn = get_connection(project_name)
    try:
        created_at = datetime.now(timezone.utc).isoformat()
        session_uid = create_forced_session(conn, project_name, created_at)

        new_snap_ids = []
        for folder in folders:
            folder = os.path.realpath(os.path.expanduser(folder))
            if not os.path.isdir(folder):
                continue
            for filepath in safe_walk(folder):
                if _matches_exclude(filepath, SECURITY_EXCLUDE) or _matches_exclude(filepath, exclude):
                    continue
                result = snapshot_file(
                    conn=conn,
                    project=project_name,
                    project_folder=folder,
                    abs_filepath=filepath,
                    session_uid=session_uid,
                )
                if result is not None:
                    new_snap_ids.append(result)

        total = len(new_snap_ids)

        if total == 0:
            conn.execute("DELETE FROM sessions WHERE uid = ?", (session_uid,))
            conn.commit()
            latest = get_latest_session(conn, project_name)
            if latest:
                display_time = fmt_date(latest["created_at"])
                if message:
                    update_session_note(conn, latest["uid"], message)
                close_session(conn, latest["uid"])

                files = get_files_in_session(conn, latest["uid"])
                unique = {}
                for f in files:
                    unique[f["file_id"]] = f
                file_count = len(unique)
                file_word = "file" if file_count == 1 else "files"

                click.echo(f"\nSaved successfully — {fmt_session(latest['uid'])} | {display_time}   {file_count} {file_word}")
                click.echo("─" * 56)
                for f in unique.values():
                    click.echo(f"  {f['file_id']}   {f['filepath']:<30} v{f['file_version']}")
                if message:
                    click.echo(f"\n# Note: \"{message}\"")
                click.echo(f"\nSnap session successfully. This session: {fmt_session(latest['uid'])}")
            else:
                click.echo("\nSaved successfully — no changes detected")
            click.echo()
            return

        if message:
            update_session_note(conn, session_uid, message)

        close_session(conn, session_uid)

        files = get_files_in_session(conn, session_uid)
        file_word = "file" if total == 1 else "files"
        header = fmt_date_header()

        click.echo(f"\n{fmt_session(session_uid)} | {fmt_date(created_at)}   {total} {file_word}  {header}")
        click.echo("─" * 56)
        for f in files:
            click.echo(f"  {f['file_id']}   {f['filepath']:<30} v{f['file_version']}")

        if message:
            click.echo(f"\n# Note: \"{message}\"")

        click.echo(f"\nSnap session successfully. This session: {fmt_session(session_uid)}")
        click.echo()
    finally:
        conn.close()
