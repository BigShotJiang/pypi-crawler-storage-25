# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import re

import click

from rewindex.config.loader import load_config
from rewindex.db.connection import get_connection
from rewindex.commands._project import resolve_project


@click.command()
@click.argument("file_id", default=None, required=False)
@click.argument("v_from", default=None, required=False)
@click.argument("v_to", default=None, required=False)
@click.option("--project", "-p", default=None, help="Project name or PJ ID.")
def diff_cmd(file_id: str | None, v_from: str | None, v_to: str | None, project: str | None) -> None:
    """Show diff between file versions.

    \b
    rewindex diff <FileID>                 previous → latest
    rewindex diff <FileID> <v>             v → latest
    rewindex diff <FileID> <v_from> <v_to> v_from → v_to

    v = version number (v3), latest, or oldest
    """
    if not file_id:
        click.echo("\nMissing target. Usage:")
        click.echo("  rewindex diff <FileID>                 previous → latest")
        click.echo("  rewindex diff <FileID> <v>             v → latest")
        click.echo("  rewindex diff <FileID> <v_from> <v_to> v_from → v_to")
        click.echo("  rewindex diff <SS>                     compare current state vs session")
        click.echo("  rewindex diff <SS_from> <SS_to>        compare two sessions")
        click.echo()
        click.echo("  v = version number (v3), latest, or oldest")
        click.echo()
        click.echo("Optional: -p <ProjectName|PJ1>  (auto-detected from current directory)")
        click.echo()
        return

    from rewindex.utils.id_parse import is_session_target, parse_session_id
    from rewindex.db.queries import (
        get_file_registry_by_id,
        get_file_version_range,
        resolve_file_version,
    )
    from rewindex.snapshot.reconstruct import reconstruct
    from rewindex.ui.diff_viewer import print_diff

    config = load_config()
    all_projects = config.get("projects", [])
    if not all_projects:
        click.echo("No projects configured.")
        return

    resolved = resolve_project(all_projects, project or None)
    if resolved is None:
        return

    conn = get_connection(resolved)
    try:
        if is_session_target(file_id):
            try:
                ss_from = parse_session_id(file_id)
            except ValueError as e:
                click.echo(f"Error: {e}")
                return
            ss_to = None
            if v_from and is_session_target(v_from):
                try:
                    ss_to = parse_session_id(v_from)
                except ValueError as e:
                    click.echo(f"Error: {e}")
                    return
            _diff_sessions(conn, resolved, ss_from, ss_to)
            return

        reg = get_file_registry_by_id(conn, resolved, file_id)
        if not reg:
            click.echo(f'\nError: unknown FileID "{file_id}".')
            click.echo("Use `rewindex log` to list available sessions and files.")
            click.echo()
            return

        min_v, max_v = get_file_version_range(conn, reg["uid"])
        if min_v is None:
            click.echo(f"No versions found for {file_id}.")
            return

        to_ver = _parse_version(v_to, max_v, min_v) if v_to else max_v
        if v_from:
            from_ver = _parse_version(v_from, max_v, min_v)
        elif v_to:
            from_ver = to_ver - 1 if to_ver > min_v else min_v
        else:
            from_ver = to_ver - 1 if to_ver > min_v else None

        if from_ver is None or from_ver < min_v:
            click.echo(f"\nError: {file_id} v{min_v} has no previous version to diff against.")
            click.echo(f"Oldest available: v{min_v}")
            click.echo()
            return

        from_row = resolve_file_version(conn, resolved, file_id, from_ver)
        to_row = resolve_file_version(conn, resolved, file_id, to_ver)

        if from_row is None:
            click.echo(f"\nError: {file_id} v{from_ver} not found — version may have been trimmed.")
            click.echo(f"Available: v{min_v} (oldest) → v{max_v} (latest)")
            click.echo()
            return
        if to_row is None:
            click.echo(f"\nError: {file_id} v{to_ver} not found — version may have been trimmed.")
            click.echo(f"Available: v{min_v} (oldest) → v{max_v} (latest)")
            click.echo()
            return

        old_lines = reconstruct(conn, reg["uid"], from_row["uid"])
        new_lines = reconstruct(conn, reg["uid"], to_row["uid"])

        print_diff(
            old_lines, new_lines,
            file_id=reg["file_id"],
            filepath=reg["filepath"],
            from_ver=from_ver,
            to_ver=to_ver,
        )

        click.echo()
        click.echo("This is a preview only — no files were changed.")
        click.echo()
        click.echo("To actually revert, use: rewindex rewind")
        click.echo("How to use: rewindex rewind -h")
        click.echo()
    finally:
        conn.close()


def _diff_sessions(conn, project: str, ss_from: int, ss_to: int | None) -> None:
    import os
    from rewindex.utils.id_parse import fmt_session
    from rewindex.utils.formatting import fmt_date, fmt_date_header
    from rewindex.snapshot.engine import hash_file
    from rewindex.db.queries import (
        get_session_by_uid, get_oldest_session, get_latest_session,
        get_all_tracked_files, get_latest_version_at_session,
    )

    session_from = get_session_by_uid(conn, ss_from)
    if not session_from:
        oldest = get_oldest_session(conn, project)
        latest = get_latest_session(conn, project)
        if oldest and latest:
            click.echo(f"\nError: {fmt_session(ss_from)} not found — may have been trimmed.")
            click.echo(f"Available: {fmt_session(oldest['uid'])} (oldest) → {fmt_session(latest['uid'])} (latest)")
        else:
            click.echo(f"\nError: {fmt_session(ss_from)} not found.")
        click.echo()
        return

    if ss_to is not None:
        session_to = get_session_by_uid(conn, ss_to)
        if not session_to:
            oldest = get_oldest_session(conn, project)
            latest = get_latest_session(conn, project)
            if oldest and latest:
                click.echo(f"\nError: {fmt_session(ss_to)} not found — may have been trimmed.")
                click.echo(f"Available: {fmt_session(oldest['uid'])} (oldest) → {fmt_session(latest['uid'])} (latest)")
            else:
                click.echo(f"\nError: {fmt_session(ss_to)} not found.")
            click.echo()
            return

    tracked = get_all_tracked_files(conn, project)

    if ss_to is not None:
        header = fmt_date_header()
        click.echo(f"\nCompare {fmt_session(ss_from)} → {fmt_session(ss_to)}  {header}")
        click.echo("─" * 56)
        for reg in tracked:
            ver_from = get_latest_version_at_session(conn, reg["uid"], ss_from)
            ver_to = get_latest_version_at_session(conn, reg["uid"], ss_to)

            if ver_from is None and ver_to is None:
                continue

            fp_from = ver_from["filepath"] if ver_from and ver_from["filepath"] else reg["filepath"]
            fp_to = ver_to["filepath"] if ver_to and ver_to["filepath"] else reg["filepath"]
            filepath = fp_to if ver_to else fp_from
            move_str = f"  (was {fp_from})" if fp_from != fp_to and ver_from and ver_to else ""

            if ver_from is None or ver_from["is_deleted"]:
                if ver_to and not ver_to["is_deleted"]:
                    click.echo(f"  {reg['file_id']}   {filepath:<30} added (v{ver_to['file_version']})")
                else:
                    click.echo(f"  {reg['file_id']}   {filepath:<30} unchanged")
            elif ver_to is None or ver_to["is_deleted"]:
                click.echo(f"  {reg['file_id']}   {fp_from:<30} removed (was v{ver_from['file_version']})")
            elif ver_from["hash"] == ver_to["hash"] and fp_from == fp_to:
                click.echo(f"  {reg['file_id']}   {filepath:<30} unchanged")
            elif ver_from["hash"] == ver_to["hash"]:
                click.echo(f"  {reg['file_id']}   {fp_to:<30} moved{move_str}")
            else:
                click.echo(f"  {reg['file_id']}   {filepath:<30} changed v{ver_from['file_version']} → v{ver_to['file_version']}{move_str}")
    else:
        from rewindex.config.loader import load_config
        from rewindex.commands.rewind import _resolve_abs_path

        config = load_config()
        all_projects = config.get("projects", [])
        proj = next(p for p in all_projects if p["name"] == project)
        folders = proj.get("folders", [])

        header = fmt_date_header()
        click.echo(f"\nCompare current state vs {fmt_session(ss_from)}  {header}")
        click.echo("─" * 56)
        for reg in tracked:
            ver = get_latest_version_at_session(conn, reg["uid"], ss_from)
            latest_ver = conn.execute(
                "SELECT * FROM file WHERE file_registry_uid = ? AND is_corrupted = 0 ORDER BY uid DESC LIMIT 1",
                (reg["uid"],)
            ).fetchone()

            if ver is None and latest_ver is None:
                continue

            filepath = reg["filepath"]
            target_filepath = ver["filepath"] if ver and ver["filepath"] else filepath
            abs_path = _resolve_abs_path(reg, folders)
            move_str = f"  (move → {target_filepath})" if target_filepath != filepath else ""

            if ver is None or ver["is_deleted"]:
                if latest_ver and not latest_ver["is_deleted"]:
                    if abs_path and os.path.exists(abs_path):
                        click.echo(f"  {reg['file_id']}   {filepath:<30} will be removed (v{latest_ver['file_version']})")
                    else:
                        click.echo(f"  {reg['file_id']}   {filepath:<30} unchanged")
                else:
                    click.echo(f"  {reg['file_id']}   {filepath:<30} unchanged")
            else:
                disk_hash = None
                if abs_path and os.path.exists(abs_path):
                    try:
                        disk_hash = hash_file(abs_path)
                    except OSError:
                        pass
                if disk_hash == ver["hash"] and not move_str:
                    click.echo(f"  {reg['file_id']}   {filepath:<30} unchanged")
                else:
                    cur_v = f"v{latest_ver['file_version']}" if latest_ver else ""
                    click.echo(f"  {reg['file_id']}   {filepath:<30} differs {cur_v} → v{ver['file_version']}{move_str}")

    click.echo()
    click.echo("To see file-level diff:")
    click.echo("  rewindex diff <FileID> <v_from> <v_to>")
    click.echo("  Example: rewindex diff XULK v27 v1")
    click.echo()
    click.echo("This is a preview only — no files were changed.")
    click.echo()
    click.echo("To actually revert, use: rewindex rewind")
    click.echo("How to use: rewindex rewind -h")
    click.echo()
    click.echo("Optional: -p <ProjectName|PJ1>  (auto-detected from current directory)")
    click.echo()


def _parse_version(val: str, max_ver: int, min_ver: int = 1) -> int:
    if val is None:
        return max_ver
    v = val.strip().lower()
    if v == "latest":
        return max_ver
    if v == "oldest":
        return min_ver
    m = re.match(r'^v?(\d+)$', v)
    if m:
        return int(m.group(1))
    raise click.BadParameter(f'Invalid version "{val}". Use vN, "latest", or "oldest".')
