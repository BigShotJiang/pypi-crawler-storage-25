# Copyright (c) 2026 Rewindex. All rights reserved.
# Proprietary and confidential. Unauthorized use prohibited.

import os
import shutil
import sys

import click


@click.command()
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt")
def uninstall_cmd(yes: bool) -> None:
    """Uninstall Rewindex and remove daemon.

    \b
    rewindex uninstall           interactive — asks about data removal
    rewindex uninstall --yes     skip confirmation (keeps snapshot data)
    """
    from rewindex.daemon.runner import stop_daemon, is_running, read_pid
    from rewindex.config.defaults import REWINDEX_DIR

    if not yes:
        click.echo("This will stop the daemon and remove the Rewindex CLI.")
        click.echo("Snapshot data at ~/.rewindex/ will NOT be deleted unless you confirm.")
        click.echo()
        import questionary
        remove_data = questionary.confirm("Remove snapshot data as well?", default=False).ask()
    else:
        remove_data = False

    click.echo("\nStopping daemon...")
    stop_daemon()

    platform = sys.platform
    try:
        if platform == "darwin":
            from rewindex.autostart.macos import uninstall
        elif platform == "linux":
            from rewindex.autostart.linux import uninstall
        else:
            pass
        uninstall()
    except Exception:
        pass

    if remove_data and os.path.isdir(REWINDEX_DIR):
        shutil.rmtree(REWINDEX_DIR, ignore_errors=True)
        click.echo("Snapshot data deleted.")

    click.echo("Rewindex uninstalled.")

    if not remove_data:
        click.echo()
        click.echo("Snapshot data kept at ~/.rewindex/")
        click.echo("To remove manually: rm -rf ~/.rewindex/")
