"""twat-text: Text processing utilities for the twat ecosystem."""

from __future__ import annotations
from .__version__ import __version__


from .twat_text import (
    Config,
    chunk_text,
    classify,
    clean_text,
    context_window_chunks,
    convert_text,
    estimate_tokens,
    extract_emails,
    extract_numbers,
    extract_structured,
    extract_urls,
    html_to_plain,
    main,
    markdown_to_plain,
    normalize_text,
    plain_to_html,
    process_data,
    rewrite,
    summarize,
)

__all__ = [
    "Config",
    "__version__",
    "chunk_text",
    "classify",
    "clean_text",
    "context_window_chunks",
    "convert_text",
    "estimate_tokens",
    "extract_emails",
    "extract_numbers",
    "extract_structured",
    "extract_urls",
    "html_to_plain",
    "main",
    "markdown_to_plain",
    "normalize_text",
    "plain_to_html",
    "process_data",
    "rewrite",
    "summarize",
]
