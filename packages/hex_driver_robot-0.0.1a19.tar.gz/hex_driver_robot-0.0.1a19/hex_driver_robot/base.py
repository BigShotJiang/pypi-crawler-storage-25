#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-03-26
################################################################

import multiprocessing as mp
from dataclasses import dataclass
from abc import ABC, abstractmethod
from multiprocessing.synchronize import Event as MpEvent
from typing import Optional


def _hex_robot_worker_main(robot: "HexRobotBase") -> None:
    """Worker process main function."""
    try:
        robot.init_robot()
        robot.work_loop()
    except KeyboardInterrupt:
        pass
    finally:
        robot.deinit_robot()


@dataclass
class HexRobotBaseParams:
    host: str = "192.168.1.100"
    port: int = 8439
    ctrl_rate: float = 1000
    state_buffer_size: int = 200
    sens_ts: bool = True


class HexRobotBase(ABC):

    def __init__(self) -> None:
        self._worker_process: Optional[mp.Process] = None
        self._stop_event = mp.Event()
        self._init_event = mp.Event()

    def __del__(self):
        self.deinit_robot()

    def is_working(self) -> bool:
        """Check if the worker process is running."""
        p = self._worker_process
        return p is not None and p.is_alive()

    @property
    def stop_event(self) -> MpEvent:
        """Set by `stop`; subclasses should exit `work_loop` when this is set."""
        return self._stop_event

    def start(self, *, daemon: bool = True) -> None:
        """Spawn a subprocess that runs `work_loop` until `stop_event` is set."""
        if self._worker_process is not None and self._worker_process.is_alive(
        ):
            return
        self._stop_event.clear()
        self._worker_process = mp.Process(
            target=_hex_robot_worker_main,
            args=(self, ),
            daemon=daemon,
        )
        self._worker_process.start()
        self._init_event.wait()

    def stop(self, timeout: Optional[float] = 5.0) -> None:
        """Signal the worker to stop, then join. Uses `terminate` if join times out."""
        self._stop_event.set()
        proc = self._worker_process
        if proc is None:
            return
        proc.join(timeout=timeout)
        if proc.is_alive():
            proc.terminate()
            proc.join()
        self._worker_process = None

    @abstractmethod
    def init_vars(self):
        raise NotImplementedError(
            "`init_vars` should be implemented by the child class")

    @abstractmethod
    def init_robot(self):
        raise NotImplementedError(
            "`init_robot` should be implemented by the child class")

    @abstractmethod
    def deinit_robot(self):
        raise NotImplementedError(
            "`deinit_robot` should be implemented by the child class")

    @abstractmethod
    def work_loop(self):
        raise NotImplementedError(
            "`work_loop` should be implemented by the child class")
