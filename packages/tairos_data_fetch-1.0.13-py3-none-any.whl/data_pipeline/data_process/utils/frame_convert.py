import base64
from io import BytesIO
from typing import Dict, Any, List
from concurrent.futures import ThreadPoolExecutor, as_completed
import msgpack
import numpy as np
from PIL import Image


def convert_compressed_image(message):
    unpacked_message = msgpack.unpackb(base64.b64decode(message["message_bytes"]), raw=False, strict_map_key=False)
    return np.array(Image.open(BytesIO(unpacked_message["Data"])))


def convert_component_observation(message, type):
    unpacked_message = msgpack.unpackb(base64.b64decode(message["message_bytes"]), raw=False, strict_map_key=False)
    if type == "pose":
        pose = unpacked_message["MultibodyPose"]["Pose"]
        return np.array([
            pose["Position"]["X"], pose["Position"]["Y"], pose["Position"]["Z"],
            pose["Orientation"]["X"], pose["Orientation"]["Y"], pose["Orientation"]["Z"], pose["Orientation"]["W"]
        ])
    if type == "joint":
        return np.array([state_msg["Q"] for state_msg in unpacked_message["MultibodyState"]["States"]])
    if type == "ft":
        wrench = unpacked_message["ForceTorques"][0]["Wrench"]
        return np.array([wrench["Force"]["X"], wrench["Force"]["Y"], wrench["Force"]["Z"],
                         wrench["Torque"]["X"], wrench["Torque"]["Y"], wrench["Torque"]["Z"]])
    raise ValueError(f"type {type} not supported")


def convert_component_action(message, type):
    unpacked_message = msgpack.unpackb(base64.b64decode(message["message_bytes"]), raw=False, strict_map_key=False)
    if type == "pose":
        pose = unpacked_message["PoseCommand"]["Pose"]
        return np.array([
            pose["Position"]["X"], pose["Position"]["Y"], pose["Position"]["Z"],
            pose["Orientation"]["X"], pose["Orientation"]["Y"], pose["Orientation"]["Z"], pose["Orientation"]["W"],
        ])
    if type == "joint":
        joint_commands = unpacked_message["JointCommands"]
        if isinstance(joint_commands, list):
            return np.array(unpacked_message["JointCommands"])

        return None
    raise ValueError(f"type {type} not supported")


def convert_joint_state(message):
    unpacked_message = msgpack.unpackb(base64.b64decode(message["message_bytes"]), raw=False, strict_map_key=False)
    return np.array(unpacked_message["Position"])


def convert_pose_stamped(message):
    unpacked_message = msgpack.unpackb(base64.b64decode(message["message_bytes"]), raw=False, strict_map_key=False)
    pose = unpacked_message["Pose"]
    return np.array([pose["Position"]["X"], pose["Position"]["Y"], pose["Position"]["Z"], pose["Orientation"]["X"],
                     pose["Orientation"]["Y"], pose["Orientation"]["Z"], pose["Orientation"]["W"]])


def convert_timestamped_messages(messages, topic_type, topic_name):
    data = []
    type = "pose"
    if "/joint" in topic_name:
        type = "joint"
    if "/ft" in topic_name:
        type = "ft"

    for message in messages:
        converted = None
        if topic_type == "sensor_msgs/CompressedImage":
            converted = convert_compressed_image(message)
        if topic_type == "data_msgs/ComponentObservation":
            converted = convert_component_observation(message, type)
        if topic_type == "data_msgs/ComponentAction":
            converted = convert_component_action(message, type)
        if topic_type == "sensor_msgs/JointState":
            converted = convert_joint_state(message)
        if topic_type == "geometry_msgs/PoseStamped":
            converted = convert_pose_stamped(message)

        if converted is not None:
            data.append(converted)

    if len(data) == 0:
        return None
    return np.stack(data, axis=0)


def convert_file_content_to_frame(file_content: Dict[str, Any], frame_structure: List[Dict[str, Any]]):
    """
    Convert the response to a frame.
    Example of converted frame:
        {
            "head/camera/color": np.array,
            "left_wrist/pose/state": np.array,
            "left_wrist/pose/state_reverse": np.array,
            "right_wrist/pose/state": np.array,
            "right_wrist/pose/state_reverse": np.array,
            "episode_state": str,
            "valid": bool,
            "error_message": str,
        }
    """
    if file_content['successful'] is False:
        return {
            "valid": False,
            "error_message": file_content['error_message'],
        }

    if len(file_content["topic_contents"]) != len(frame_structure):
        return {
            "valid": False,
            "error_message": f"Topic content length in file_content should be {len(frame_structure)}, \
                but is {len(file_content['topic_contents'])}",
        }

    frame = {
        "valid": True,
    }
    for index, topic_content in enumerate(file_content["topic_contents"]):
        # Skip episode_state topic as it is in the metadata.
        if topic_content["name"] == "episode_state":
            continue

        if frame_structure[index]["name"] != topic_content["name"]:
            return {
                "valid": False,
                "error_message": f"Topic name in file_content at {index} should be {frame_structure[index]['name']}, \
                    but is {topic_content['name']}",
            }

        if len(topic_content["timestamped_messages"]) != frame_structure[index]["count"]:
            return {
                "valid": False,
                "error_message": f"Topic {frame_structure[index]['name']} should has {frame_structure[index]['count']} \
                    samples, but has {len(topic_content['timestamped_messages'])}",
            }

        try:
            topic_msgs = convert_timestamped_messages(
                topic_content["timestamped_messages"], topic_content["type"], topic_content["name"])
        except Exception as e:  # pylint: disable=broad-except
            return {
                "valid": False,
                "error_message": f"Error converting topic {frame_structure[index]['name']}: {e}",
            }

        if topic_msgs is None:
            return {
                "valid": False,
                "error_message": f"Topic {frame_structure[index]['name']} is None",
            }

        if topic_msgs.shape[0] != frame_structure[index]["count"]:
            return {
                "valid": False,
                "error_message": f"Topic {frame_structure[index]['name']} should has {frame_structure[index]['count']} \
                    samples, but has {len(topic_msgs)}",
            }

        key = frame_structure[index]["name"]
        if "override_key" in frame_structure[index]:
            key = frame_structure[index]["override_key"]
        frame[key] = topic_msgs

    return frame


def convert_response_to_frames(response: Dict[str, Any], frame_structure: List[Dict[str, Any]]):
    frames = []
    for file_content in response.get("file_contents", []):
        frame = convert_file_content_to_frame(file_content, frame_structure)
        frames.append(frame)
    return frames


def convert_response_to_frames_parallel(response: Dict[str, Any], frame_structure: List[Dict[str, Any]]):
    file_contents = response.get("file_contents", [])
    frames = [None] * len(file_contents)
    with ThreadPoolExecutor(max_workers=32) as executor:
        future_to_file_content = {
            executor.submit(
                convert_file_content_to_frame, file_content, frame_structure
            ): i for i, file_content in enumerate(file_contents)
        }
        for future in as_completed(future_to_file_content):
            index = future_to_file_content[future]
            frames[index] = future.result()
    return frames
