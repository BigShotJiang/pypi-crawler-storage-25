from typing import Any, Dict, List
import time
from loguru import logger
import requests
import numpy as np

from data_pipeline.py_api.api_utils import batch_get_vla_training_info_by_query
from data_pipeline.data_process.utils.frame_convert import convert_response_to_frames

FETCH_SERVICE_URL = 'https://roboticsx-data.woa.com/trpc.data_pipeline.fetching.DataFetching/FetchV2'


def timestamp_nsec_to_ms(timestamp_nsec: Dict[str, Any]) -> int:
    return int(timestamp_nsec.get('sec') * 1000) + int(timestamp_nsec.get('nsec') / 1000000)


def timestamp_ms_to_nsec(timestamp_ms: int) -> Dict[str, Any]:
    return {
        'sec': int(timestamp_ms // 1000),
        'nsec': int(timestamp_ms % 1000 * 1000000)
    }


class DataFetchWorker:
    def __init__(self, config: Dict[str, Any], metadatas: List[Dict[str, Any]] = None, batch_size: int = 32):
        self.service_url = FETCH_SERVICE_URL
        self.batch_size = batch_size
        self.config = config
        self._check_config()
        self._parse_config()

        # Prepare metadatas for sampling.
        self.metadatas = metadatas
        if metadatas is None:
            self._load_metadatas_from_config()
        self._filter_metadatas()
        self._extract_weights()

        # Prepare other tools for fetching data.
        self.session = requests.Session()
        self.rng = np.random.default_rng()
        self.sample_indices = []
        self.current_sample_indices_index = 0

    def fetch_data(self):
        '''
        Example of a frame:
        {
            "head/camera/color": np.array,
            "left_wrist/pose/state": np.array,
            "left_wrist/pose/state_reverse": np.array,
            "right_wrist/pose/state": np.array,
            "right_wrist/pose/state_reverse": np.array,
            "episode_state": str,

            "valid": bool,
            "error_message": str,
            "sample_index": int,
            "sample_relative_timestamp_ms": int,
        }
        '''
        sample_indices, relative_timestamps_ms = self._sample_indices_and_relative_timestamps_ms()
        request = self._build_request(sample_indices, relative_timestamps_ms)

        try:
            response = self.session.post(self.service_url, json=request)
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            return [{"valid": False, "error_message": str(e)}]

        response_json = response.json()
        frames = convert_response_to_frames(response_json, self.config.get("frame_structure"))

        for i, frame in enumerate(frames):
            frame["sample_index"] = sample_indices[i]
            frame["sample_relative_timestamp_ms"] = relative_timestamps_ms[i]

            if self.fetch_episode_state:
                self._populate_episode_state(frame, sample_indices[i], relative_timestamps_ms[i])

        return frames

    def fetch_data_with_debug_info(self):
        fetch_start_time = time.time()
        debug_info = {}

        now = time.time()
        sample_indices, relative_timestamps_ms = self._sample_indices_and_relative_timestamps_ms()
        debug_info["sampling_time"] = time.time() - now

        now = time.time()
        request = self._build_request(sample_indices, relative_timestamps_ms)
        debug_info["building_request_time"] = time.time() - now

        try:
            now = time.time()
            response = self.session.post(self.service_url, json=request)
            debug_info["post_time"] = time.time() - now
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            return [{"valid": False, "error_message": str(e)}]

        now = time.time()
        response_json = response.json()
        debug_info["deserialize_time"] = time.time() - now

        now = time.time()
        frames = convert_response_to_frames(response_json, self.config.get("frame_structure"))
        debug_info["convert_time"] = time.time() - now

        now = time.time()
        for i, frame in enumerate(frames):
            frame["sample_index"] = sample_indices[i]
            frame["sample_relative_timestamp_ms"] = relative_timestamps_ms[i]

            if self.fetch_episode_state:
                self._populate_episode_state(frame, sample_indices[i], relative_timestamps_ms[i])
        debug_info["populate_episode_state_time"] = time.time() - now

        debug_info["total_time"] = time.time() - fetch_start_time
        return frames, debug_info

    def set_rng(self, rng: np.random.Generator):
        self.rng = rng

    def get_metadatas(self):
        return self.metadatas

    def _check_config(self):
        if not self.config.get("frame_structure"):
            raise ValueError("配置中未设置frame_structure")

        names = set()
        can_auto_sampling = True
        for item in self.config.get("frame_structure"):
            if not item.get("name"):
                raise ValueError("配置中未设置frame_structure.name")
            if not item.get("count"):
                raise ValueError("配置中未设置frame_structure.count")

            if item.get("fixed_rate", {}).get("fps", 0) <= 0:
                can_auto_sampling = False

            name = item.get("name")
            if "override_key" in item:
                name = item.get("override_key")
            if name in names:
                raise ValueError(f"配置中frame_structure.name重复: {name}, 请使用并检查override_key是否正确配置")
            names.add(name)
        if not can_auto_sampling:
            raise ValueError("auto_sampling 模式下, 所有topic的fps必须大于0")

        if "data_filter" in self.config:
            filter_exists = False
            if self.config.get("data_filter").get("dataset_ids"):
                filter_exists = True
            if self.config.get("data_filter").get("query"):
                filter_exists = True

            if not filter_exists:
                raise ValueError("配置中未设置data_filter.dataset_ids或data_filter.query")

    def _parse_config(self):
        self.topic_infos = []
        self.fetch_episode_state = False
        self.episode_state_frame_structures = []
        for item in self.config.get("frame_structure"):
            if item.get("name") == "episode_state":
                self.fetch_episode_state = True
                self.episode_state_frame_structures.append(item)
                continue

            topic_info = {
                "name": item.get("name"),
            }

            if 'fixed_rate' in item:
                topic_info['fixed_rate_topic_info'] = {
                    "fps": item['fixed_rate']['fps'],
                    "number_of_messages": item['count'],
                    "reverse_time_order": item['fixed_rate'].get("reverse", False),
                }
            else:
                topic_info['timestamps_topic_info'] = {
                    "number_of_messages": item['count'],
                }

            self.topic_infos.append(topic_info)

        self.config["frame_structure"] = [item for item in self.config.get(
            "frame_structure") if item.get("name") != "episode_state"]

        self.backward_time_range_ms = 0
        self.forward_time_range_ms = 0
        for item in self.config.get("frame_structure"):
            if 'fixed_rate' in item:
                backward_time_range_ms = int(1000 / item['fixed_rate']['fps'] * (item['count'] - 1))
                forward_time_range_ms = int(1000 / item['fixed_rate']['fps'] * (item['count'] - 1))
                self.backward_time_range_ms = max(self.backward_time_range_ms, backward_time_range_ms)
                self.forward_time_range_ms = max(self.forward_time_range_ms, forward_time_range_ms)

    def _load_metadatas_from_config(self):
        self.metadatas = []
        dataset_ids = self.config.get("data_filter").get("dataset_ids", [])
        if len(dataset_ids) > 0:
            for dataset_id in dataset_ids:
                query = {
                    "set_associations.set_id": dataset_id
                }
                self.metadatas.extend(batch_get_vla_training_info_by_query(query))
            logger.info(f"Selected {len(self.metadatas)} data from datasets {dataset_ids}")
            return

        query = self.config.get("data_filter").get("query", {})
        self.metadatas = batch_get_vla_training_info_by_query(query)
        logger.info(f"Selected {len(self.metadatas)} data by query {query}")

    def _filter_metadatas(self):
        filtered_metadatas = []
        for item in self.metadatas:
            metadata = item.get("metadata", {})
            if metadata.get("statistics", {}).get("start_moving_relative_time", None) is None:
                logger.warning(f"Invalid metadata, missing start_moving_relative_time: {item}")
                continue
            if metadata.get("statistics", {}).get("time_duration", None) is None:
                logger.warning(f"Invalid metadata, missing time_duration: {item}")
                continue
            if self.fetch_episode_state and len(metadata.get("recording_events", [])) == 0:
                logger.warning(f"Invalid metadata, missing recording_events: {item}")
                continue
            metadata["recording_events"] = sorted(metadata.get(
                "recording_events", []), key=lambda x: x.get("timestamp_ms"))

            filtered_metadatas.append(item)

        self.metadatas = filtered_metadatas
        if len(self.metadatas) == 0:
            raise ValueError("No valid metadatas after filtering")
        logger.info(f"Got {len(self.metadatas)} valid metadatas")

    def _extract_weights(self):
        weights = []
        for item in self.metadatas:
            weights.append(timestamp_nsec_to_ms(item.get("metadata", {}).get("statistics", {}).get("time_duration")))
        weights = np.array(weights)
        self.weights = weights / weights.sum()

    def _sample_indices_and_relative_timestamps_ms(self):
        if self.current_sample_indices_index >= len(self.sample_indices):
            self.current_sample_indices_index = 0
            self.sample_indices = self.rng.choice(len(self.metadatas), size=self.batch_size * 1000, p=self.weights)

        sample_indices = self.sample_indices[self.current_sample_indices_index:
                                             self.current_sample_indices_index + self.batch_size]
        self.current_sample_indices_index += self.batch_size
        relative_timestamps_ms = []
        for index in sample_indices:
            metadata = self.metadatas[index]
            relative_timestamps_ms.append(self._sample_relative_timestamp_ms_from_metadata(metadata))

        return sample_indices, relative_timestamps_ms

    def _build_request(self, sample_indices: List[int], relative_timestamps_ms: List[int]):
        file_infos = []

        for index, relative_timestamp_ms in zip(sample_indices, relative_timestamps_ms):
            metadata = self.metadatas[index]
            file_info = {
                "key": metadata.get("cos_storage", {}).get("files", [])[0].get("key"),
            }
            topic_specific_file_infos = []
            for topic_info in self.topic_infos:
                topic_specific_file_infos.append({
                    "name": topic_info.get("name"),
                    "fixed_rate_file_info": {
                        "relative_timestamp": timestamp_ms_to_nsec(relative_timestamp_ms),
                    },
                })
            file_info["topic_specific_file_infos"] = topic_specific_file_infos
            file_infos.append(file_info)

        return {"topic_infos": self.topic_infos, "file_infos": file_infos}

    def _sample_relative_timestamp_ms_from_metadata(self, metadata: Dict[str, Any]) -> int:
        statistics = metadata.get("metadata", {}).get("statistics", {})
        range_start = max(timestamp_nsec_to_ms(statistics.get(
            "start_moving_relative_time")), self.backward_time_range_ms)
        range_end = timestamp_nsec_to_ms(statistics.get("time_duration")) - self.forward_time_range_ms
        return self.rng.integers(range_start, range_end)

    def _populate_episode_state(self, frame: Dict[str, Any], sample_index: int, relative_timestamp_ms: int):
        episode_state = self._get_episode_state(sample_index, relative_timestamp_ms)
        for item in self.episode_state_frame_structures:
            key = "episode_state"
            if "override_key" in item:
                key = item.get("override_key")
            frame[key] = episode_state

    def _get_episode_state(self, sample_index: int, relative_timestamp_ms: int) -> str:
        metadata = self.metadatas[sample_index]
        recording_events = metadata.get("metadata", {}).get("recording_events", [])

        started_events = []
        for event in recording_events:
            if event.get("event_type") == "step_started":
                started_events.append(event)
        finished_events = []
        for event in recording_events:
            if event.get("event_type") == "step_finished":
                finished_events.append(event)

        bag_start_time_ms = timestamp_nsec_to_ms(metadata.get(
            "metadata", {}).get("statistics", {}).get("bag_start_time"))
        timestamp_ms = bag_start_time_ms + int(relative_timestamp_ms)

        if len(started_events) > 0:
            last_event = started_events[0]
            for event in started_events:
                if int(event.get("timestamp_ms")) <= timestamp_ms:
                    last_event = event
                    continue
                break
            return last_event.get("event_detail")
        if len(finished_events) > 0:
            for event in finished_events:
                if int(event.get("timestamp_ms")) > timestamp_ms:
                    return event.get("event_detail")
            return finished_events[-1].get("event_detail")

        return None
