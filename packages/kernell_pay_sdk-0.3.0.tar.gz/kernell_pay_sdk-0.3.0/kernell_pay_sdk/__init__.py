"""
Kernell OS Pay SDK
"""

__version__ = "0.1.0"

class EscrowTransaction:
    def __init__(self, sender: str, receiver: str, amount: float, currency: str, condition: str):
        self.sender = sender
        self.receiver = receiver
        self.amount = amount
        self.currency = currency
        self.condition = condition

class LedgerClient:
    def __init__(self, api_key: str):
        self.api_key = api_key
        
    def create_escrow(self, escrow: EscrowTransaction):
        print(f"Creating Escrow: {escrow.amount} {escrow.currency} from {escrow.sender} to {escrow.receiver}")
        return True
