# ⚠️ Deprecation Notice

**`kernell-pay-sdk` has been merged into the monolithic `kernell-os-sdk`.**

Please install the full suite instead:

```bash
pip install kernell-os-sdk
```

The wallet, $KERN M2M commerce, and escrow functionalities are now part of `kernell_os_sdk.wallet`. This package now serves as a proxy that automatically installs `kernell-os-sdk`.

Visit the new repository: [Kernell OS SDK](https://github.com/Greco-Italico/kernell-os-sdk)
