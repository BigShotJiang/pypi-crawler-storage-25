# Initialization for libs
