import typer
import subprocess
import os
import time
from mn_cli.shared import console
from mn_cli.error_handler import handle_cli_error
from mn_cli.server_cmds import _start_server, kill_tree, BEAM_PID_FILE, API_PID_FILE, WEB_UI_PID_FILE

def start():
    """Start MirrorNeuron services"""
    _start_server()

def stop():
    """Stop MirrorNeuron services"""
    console.print("=> Stopping MirrorNeuron Services...")
    
    console.print("   Stopping Core Service (Docker: mirror-neuron-core)...")
    subprocess.run(["docker", "stop", "mirror-neuron-core"], stderr=subprocess.DEVNULL, stdout=subprocess.DEVNULL)
    subprocess.run(["docker", "rm", "mirror-neuron-core"], stderr=subprocess.DEVNULL, stdout=subprocess.DEVNULL)

    for pid_file, name in [
        (WEB_UI_PID_FILE, "Web UI"),
        (API_PID_FILE, "REST API"),
        (BEAM_PID_FILE, "Legacy Core Service"),
    ]:
        if pid_file.exists():
            try:
                pid = int(pid_file.read_text().strip())
                try:
                    os.kill(pid, 0)
                    console.print(f"   Stopping {name} (PID: {pid})...")
                    kill_tree(pid)
                    time.sleep(1)
                except OSError:
                    pass
            except ValueError:
                pass
            pid_file.unlink()
    console.print("=> [green]All services stopped.[/green]")

def join(ip: str):
    """Join a MirrorNeuron cluster using the IP"""
    _start_server(ip)

def leave(node_name: str):
    """Remove a node from the cluster by its node name (e.g. mirror_neuron@192.168.4.173)"""
    from mn_cli.shared import client, console
    try:
        status = client.remove_node(node_name)
        console.print(f"[green]Successfully requested {node_name} to leave. Status: {status}[/green]")
    except Exception as e:
        handle_cli_error(e, console, 'leave')
