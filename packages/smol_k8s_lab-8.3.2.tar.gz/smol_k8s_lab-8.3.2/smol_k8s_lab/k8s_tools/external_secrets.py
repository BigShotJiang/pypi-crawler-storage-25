# internal libraries
from smol_k8s_lab.bitwarden.bw_cli import BwCLI, create_custom_field
from smol_k8s_lab.k8s_apps.identity_provider.zitadel_api import Zitadel
from smol_k8s_lab.k8s_apps.operators.minio import create_minio_alias
from smol_k8s_lab.k8s_tools.argocd_util import ArgoCD
from smol_k8s_lab.utils.passwords import create_password
from smol_k8s_lab.utils.value_from import process_backup_vals, extract_secret

# external libraries
import logging as log
# only needed for MAS
from ulid import ULID


class CreateCredentials():
    """
    class for creating most credentials
    """

    def __init__(self,
                 app: str,
                 app_dict: dict,
                 zitadel: Zitadel = None,
                 bitwarden: BwCLI = None,
                 argocd: ArgoCD = None):
        """
        class for creating most credentials, including
        db, admin, valkey, smtp, s3, and s3 backups
        """
        self.app = app
        self.app_dict = app_dict
        self.namespace = app_dict["argo"]["namespace"]
        self.hostname = app_dict["hostnames"][app]
        self.bw = bitwarden
        self.bw_ids = {}
        self.k8s = argocd.k8s
        self.backup_vals = process_backup_vals(app_dict.get("backups", {}))
        self.zitadel = zitadel
        self.bitwarden = bitwarden

    def create_all_credentials(self) -> dict:
        # these are all pretty generic and easy to setup credentials
        for cred_type in ["db", "admin", "valkey", "smtp"]:
            if self.app_dict.get(cred_type, {}):
                creds_output = self.create_generic_credentials(cred_type)
                if creds_output:
                    self.bw_ids[f'{cred_type}Credentials'] = creds_output

        # create admin and app S3 credentials
        if self.app_dict.get("s3", {}):
            for subtype in ["admin", "app", "db"]:
                creds_output = self.create_generic_credentials("s3", "admin")
                if creds_output:
                    key = f's3{subtype.title()}Credentials'
                    self.bw_ids[key] = creds_output

        # create S3 backups credentials
        if self.backup_vals:
            creds_output = self.create_generic_credentials("s3", "backups")
            if creds_output:
                self.bw_ids['s3BackupsCredentials'] = creds_output

        if self.zitadel:
            creds_output = self.create_zitadel_credentails(self.zitadel)
            if creds_output:
                self.bw_ids['oidcCredentials'] = creds_output

        if self.bitwarden:
            # reload the bitwarden ESO provider
            try:
                self.argocd.k8s.reload_deployment('bitwarden-eso-provider',
                                                  'external-secrets')
            except Exception as e:
                log.error("Couldn't scale down the [magenta]"
                          "bitwarden-eso-provider[/] deployment in [green]"
                          f"external-secrets[/] namespace. Recieved: {e}")
        return self.bw_ids

    def create_generic_credentials(self,
                                   cred_type: str,
                                   subtype: str = "") -> str | None:
        """
        create credentials of type for app with hostname either in bitwarden
        or via Kubernetes Secret directly in app's namspace.

        Useful for types: db (postgresql or mysql), valkey, admin, smtp
        """
        # determine the password or make one up
        password = create_password()

        # sometimes we have a special username in mind, and sometimes we don't
        if cred_type == "admin":
            username = self.app_dict['admin'].get("username", "admin")
        if cred_type == "smtp":
            username = extract_secret(self.app_dict['smtp'].get("username",
                                                                "admin"))
            password = extract_secret(self.app_dict['smtp'].get("password",
                                                                "testing123"))
        elif cred_type == "s3":
            if subtype == "backups":
                password = self.backup_vals["s3"]["access_key_id"]
                username = self.backup_vals["s3"]["secret_access_key"]
            if subtype == "admin":
                # create a local alias to make sure forgejo is functional
                create_minio_alias(self.app,
                                   self.app_dict['s3']['endpoint'],
                                   self.app,
                                   password)
        else:
            username = self.app

        if self.bw:
            # create custom fields for bitwarden items if needed
            fields_list = self.extra_bitwarden_fields(cred_type, subtype)

            # sometimes we generate multiple for a given type of credentials
            if subtype:
                item_name = f'{self.app}-{cred_type}-{subtype}-credentials'
            else:
                item_name = f'{self.app}-{cred_type}-credentials'

            # create bitwarden item with credentials
            bitwarden_id = self.bw.create_login(
                    name=item_name,
                    item_url=self.hostname,
                    user=username,
                    password=password,
                    fields=fields_list)
            return bitwarden_id
        else:
            secret_data = {"username": username, "password": password}
            # add any extra special keys we need per special credentials type
            secret_dict = self.extra_secret_keys(secret_data,
                                                 cred_type,
                                                 subtype)
            # create k8s secret with credentials
            self.k8s.create_secret(f'{self.app}-{cred_type}-credentials',
                                   self.namespace,
                                   secret_dict)
            return None

    def extra_secret_keys(self,
                          secret_data: dict,
                          cred_type: str,
                          subtype: str = "") -> {}:
        """
        add extra secret keys for a k8s secret
        """
        if "db" in cred_type:
            db_type = self.app_dict['db'].get("type", "postgres")
            if db_type == "postgres":
                secret_data["port"] = "5432"
            else:
                secret_data["port"] = "3306"
            secret_data["database"] = self.app
            password = create_password()
            secret_data[f"{db_type}Password"] = password

        # for smtp credentials, we need hostname and port
        if cred_type == "smtp":
            secret_data["host"] = self.app_dict['smtp']['host']
            secret_data["port"] = self.app_dict['smtp'].get('port', 25)

        # for admin credentials, we need the email address
        if cred_type == "admin":
            secret_data["email"] = self.app_dict['admin'].get('email',
                                                              "no@test.com")

        # for s3 backups credentials, we need the endpoint
        if cred_type == "s3" and subtype == "backups":
            secret_data["endpoint"] = self.backup_vals['s3'].get(
                    'endpoint', "beepboop.com")
            secret_data["restic_repo_pass"] = self.backup_vals[
                    "restic_repo_pass"]

        return secret_data

    def extra_bitwarden_fields(self, cred_type: str, subtype: str = "") -> []:
        """
        create all extra bitwarden fields if needed per credentials type
        """
        fields_list = []

        # for postgresql credentials, we need an admin password
        if cred_type == "db":
            db_type = self.app_dict['db'].get("type", "postgres")
            fields_list.append(create_custom_field(f"{db_type}Password",
                                                   create_password()))
            if db_type == "postgres":
                fields_list.append(create_custom_field("port", "5432"))
            else:
                fields_list.append(create_custom_field("port", "3306"))

            fields_list.append(create_custom_field("database", self.app))

        elif cred_type == "smtp":
            smtp_obj = self.app_dict['smtp']
            host = extract_secret(smtp_obj.get("host", "test.com"))
            port = extract_secret(smtp_obj.get("port", "25"))
            protocol = extract_secret(smtp_obj.get("protocol", "SMTP"))
            from_addr = extract_secret(smtp_obj.get("from_address",
                                                    "noreply@no.com"))
            fields_list.append(create_custom_field("smtpHostname", host))
            fields_list.append(create_custom_field("smtpPort", port))
            fields_list.append(create_custom_field("smtpFromAddress",
                                                   from_addr))
            fields_list.append(create_custom_field("smtpProtocol", protocol))

        # for admin credentials, we need the email address
        elif cred_type == "admin":
            email = self.app_dict['admin'].get('email', "notinuse@test.com")
            fields_list.append(create_custom_field("email", email))

        # for s3 backups credentials, we need the endpoint
        elif cred_type == "s3" and subtype == "backups":
            endpoint = self.backup_vals['s3'].get('endpoint', "beepboop.com")
            fields_list.append(create_custom_field("endpoint", endpoint))
            restic_repo_pass = self.backup_vals.get('restic_repo_pass',
                                                    create_password())
            fields_list.append(create_custom_field("resticRepoPassword",
                                                   restic_repo_pass))

        return fields_list

    def create_zitadel_credentails(self, zitadel: Zitadel) -> str | None:
        """
        create zitadel app and roles then return bitwarden ID if using bw
        """
        log.debug(f"Creating a {self.app} OIDC application in Zitadel...")
        redirect_uri_base = f"https://{self.hostname}"
        all_fields = [create_custom_field("issuer", zitadel.hostname)]

        if self.app == "forgejo":
            redirect_uri = redirect_uri_base + "/user/oauth2/Zitadel/callback"
        if self.app == "matrix":
            # this is for matrix authenticaion service
            mas_provider_ulid = str(ULID())
            all_fields.append(create_custom_field("providerId", ))
            redirect_uri = f"upstream/callback/{mas_provider_ulid}"
        else:
            redirect_uri = redirect_uri_base + "/auth/callback"

        # create a zitadel application for the app
        logout_uris = [f"https://{self.hostname}"]
        oidc_creds = zitadel.create_application(
                self.app,
                redirect_uri,
                logout_uris)

        # create roles AKA groups for zitadel
        zitadel.create_role(f"{self.app}_users",
                            f"{self.app} Users",
                            f"{self.app}_users")
        zitadel.create_role(f"{self.app}_admins",
                            f"{self.app} Admins",
                            f"{self.app}_admins")

        # grant the main zitadel user the admin role (add them to admin group)
        zitadel.update_user_grant([f'{self.app}_admins'])

        if self.bw:
            # create the oidc bitwarden item with credentials
            bitwarden_id = self.bw.create_login(
                    name=f'{self.app}-oidc-credentials',
                    item_url=self.hostname,
                    user=oidc_creds['client_id'],
                    password=oidc_creds['client_secret'],
                    fields=all_fields
                    )
            return bitwarden_id
        else:
            # create oidc k8s secret with credentials
            secret_data = {"clientId": oidc_creds['client_id'],
                           "password": oidc_creds['client_secret'],
                           "issuer": zitadel.hostname}

            self.k8s.create_secret(f'{self.app}-oidc-credentials',
                                   self.namespace,
                                   secret_data)
            return None
