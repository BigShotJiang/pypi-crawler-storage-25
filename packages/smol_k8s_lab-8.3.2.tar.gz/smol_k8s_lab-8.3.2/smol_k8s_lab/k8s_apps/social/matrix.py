# internal libraries
from smol_k8s_lab.bitwarden.bw_cli import BwCLI, create_custom_field
from smol_k8s_lab.k8s_apps.identity_provider.zitadel_api import Zitadel
from smol_k8s_lab.k8s_tools.argocd_util import ArgoCD
from smol_k8s_lab.k8s_tools.external_secrets import CreateCredentials
from smol_k8s_lab.k8s_tools.restores import Restore
from smol_k8s_lab.utils.value_from import extract_secret
from smol_k8s_lab.utils.rich_cli.console_logging import sub_header, header

# external libraries
import asyncio
from base64 import b64encode
from cryptography.hazmat.primitives.asymmetric import rsa
import logging as log
import secrets


async def configure_matrix(argocd: ArgoCD,
                           cfg: dict,
                           pvc_storage_class: str,
                           zitadel: Zitadel,
                           bitwarden: BwCLI = BwCLI("test", "test", "test")
                           ) -> bool:
    """
    creates a matrix app and initializes it with secrets if you'd like :)

    required:
        argocd            - ArgoCD() object for Argo CD operations
        cfg               - dict, with at least argocd key and init key
        pvc_storage_class - str, storage class of PVC

    optional:
        zitadel     - Zitadel() object to create zitadel oidc app and roles
        bitwarden   - BwCLI() object to create bitwarden items
    """
    # verify immediately if matrix is installed
    app_installed = argocd.check_if_app_exists('matrix')

    # verify if initialization is enabled
    init = cfg.get('init', {'enabled': True, 'restore': {'enabled': False}})
    init_enabled = init.get('enabled', True)
    init_values = init.get('values', {})

    # check if we're restoring and get values for that
    restore_dict = init.get('restore', {"enabled": False})
    restore_enabled = restore_dict['enabled']

    # figure out what header to print
    if restore_enabled:
        header_start = "Restoring"
    else:
        if app_installed:
            header_start = "[green]Matrix[/] Syncing"
        else:
            header_start = "[green]Matrix[/] Setting up"

    header(f"{header_start}, so you can self host your own chat", '💬')

    hostname = cfg['hostnames']['matrix']

    # always declare matrix namespace immediately
    matrix_namespace = cfg['argo']['namespace']

    if init_enabled:
        if zitadel:
            # configure OIDC
            cfg['zitadel_hostname'] = "https://" + zitadel.hostname

        if app_installed or restore_enabled:
            # first we grab existing bitwarden items if they exist
            if bitwarden:
                external_secret_items = refresh_bweso(argocd,
                                                      hostname,
                                                      bitwarden)
                cfg['externalSecrets'] = {'bitwarden': external_secret_items}

    # initial secrets to deploy this app from scratch
    if init_enabled and not app_installed:
        argocd.k8s.create_namespace(matrix_namespace)

        # if the user has bitwarden enabled
        if bitwarden and not restore_enabled:
            if "bridges" in cfg['argo']['path'] and init_enabled:
                # github stuff
                gh_app_id = extract_secret(init_values.get("github_app_id",
                                                           "not applicable"))
                gh_webhook_secret = extract_secret(
                    init_values.get("github_webhook_secret",
                                    "not applicable"))
                gh_client_id = extract_secret(
                    init_values.get("github_client_id", "not applicable"))
                gh_client_secret = extract_secret(
                    init_values.get("github_client_secret",
                                    "not applicable"))
                gh_private_key = extract_secret(
                        init_values.get("github_private_key",
                                        "not applicable"))

            external_secret_items = setup_bitwarden_items(
                    cfg,
                    zitadel,
                    argocd,
                    hostname,
                    gh_app_id,
                    gh_webhook_secret,
                    gh_client_id,
                    gh_client_secret,
                    gh_private_key,
                    bitwarden)
            cfg['externalSecrets'] = {'bitwarden': external_secret_items}

    if init_enabled:
        create_trusted_key_secrets(matrix_namespace, init_values, argocd)

    if not app_installed:
        # if the user is restoring, the process is a little different
        if init_enabled:
            if restore_enabled:
                Restore("matrix",
                        argocd,
                        hostname,
                        matrix_namespace,
                        cfg,
                        pvc_storage_class,
                        True,
                        bitwarden)
            else:
                argocd.install_init_app('matrix', cfg, 4, True)


def setup_bitwarden_items(cfg: dict,
                          zitadel: Zitadel,
                          argocd: ArgoCD,
                          hostname: str,
                          github_app_id: str,
                          github_webhook_secret: str,
                          github_client_id: str,
                          github_client_secret: str,
                          github_private_key: str,
                          bitwarden: BwCLI) -> dict:
    """
    setup all the required secrets as items in bitwarden
    """
    sub_header("Creating matrix secrets in Bitwarden")

    return_dict = CreateCredentials("matrix",
                                    cfg,
                                    zitadel,
                                    bitwarden,
                                    argocd).create_all_credentials()

    # registration key
    matrix_registration_key = bitwarden.generate()
    reg_id = bitwarden.create_login(
            name='matrix-registration-key',
            item_url=hostname,
            user="admin",
            password=matrix_registration_key
            )

    # alert manager bot as_token + hs_token
    alertmanager_as_token = bitwarden.generate()
    alertmanager_as_token_obj = create_custom_field("as_token",
                                                    alertmanager_as_token)
    alertmanager_hs_token = bitwarden.generate()
    alertmanager_hs_token_obj = create_custom_field("hs_token",
                                                    alertmanager_hs_token)
    alertmanager_id = bitwarden.create_login(
            name='matrix-alertmanager-bridge',
            item_url=hostname,
            user="none",
            fields=[alertmanager_as_token_obj, alertmanager_hs_token_obj]
            )

    # add MAS encryption key
    mas_encyrption_key = secrets.token_hex(32)
    # add MAS RSA private key for signing stuff
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
    )
    b64_private_key = b64encode(bytes(private_key)).decode("utf-8")
    mas_id = bitwarden.create_login(
            name='matrix-mas',
            item_url=hostname,
            user="admin",
            password=mas_encyrption_key,
            fields=create_custom_field("rsa", b64_private_key)
            )

    return_dict['registrationSecret'] = reg_id
    return_dict['alertmanagerCredentials'] = alertmanager_id
    return_dict['masCredentials'] = mas_id

    return return_dict


def refresh_bweso(argocd: ArgoCD, hostname: str, bitwarden: BwCLI) -> dict:
    """
    refresh the bitwarden item IDs for use with argocd-appset-secret-plugin
    """
    # update the matrix values for the argocd appset
    log.debug("making sure matrix bitwarden IDs are in memory ")
    bw_items = bitwarden.list_items(hostname)

    reg_id = bw_items[f"matrix-registration-key-{hostname}"]

    smtp_id = bw_items[f"matrix-smtp-credentials-{hostname}"]

    s3_admin_id = bw_items[f"matrix-admin-s3-credentials-{hostname}"]

    s3_db_id = bw_items[f"matrix-postgres-s3-credentials-{hostname}"]

    s3_id = bw_items[f"matrix-user-s3-credentials-{hostname}"]

    s3_backups_id = bw_items[f"matrix-backups-s3-credentials-{hostname}"]

    db_id = bw_items[f"matrix-pgsql-credentials-{hostname}"]

    # matrix authentication service
    mas_id = bw_items[f"matrix-mas-{hostname}"]
    oidc_id = bw_items[f"matrix-oidc-credentials-{hostname}"]

    # alertmanager bridge
    alertmanager_id = bw_items.get(f"matrix-alertmanager-bridge-{hostname}",
                                   "Not Applicable")

    return {'registrationSecret': reg_id,
            'smtpCredentials': smtp_id,
            's3AdminCredentials': s3_admin_id,
            's3PostgresCredentials': s3_db_id,
            's3AppCredentials': s3_id,
            's3BackupCredentials': s3_backups_id,
            'postgresCredentials': db_id,
            'oidcCredentials': oidc_id,
            'masCredentials': mas_id,
            'alertmanagerCredentials': alertmanager_id}


def create_trusted_key_secrets(namespace: str,
                               init_values: dict,
                               argocd: ArgoCD) -> None:
    """
    if there's trusted key servers in the init values, create a secret for them
    """
    trusted_key_servers = init_values.get("trusted_key_servers", [])

    # if init is enabled, always create trusted_key_servers secret
    if trusted_key_servers:
        try:
            argocd.k8s.create_secret(
                    name="trusted-key-servers",
                    namespace=namespace,
                    str_data={"trusted_key_servers": trusted_key_servers},
                    inline_key="trustedKeyServers")
        except Exception as e:
            log.debug(e)
            argocd.k8s.delete_secret(name="trusted-key-servers",
                                     namespace=namespace)
            argocd.k8s.create_secret(
                    name="trusted-key-servers",
                    namespace=namespace,
                    str_data={"trusted_key_servers": trusted_key_servers},
                    inline_key="trustedKeyServers")
