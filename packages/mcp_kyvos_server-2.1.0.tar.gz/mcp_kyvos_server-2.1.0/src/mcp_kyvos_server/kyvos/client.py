"""Base client module for Kyvos API interactions."""
from typing import Any, Dict, List, Optional
import json
import ssl
import truststore
import httpx
from httpx import BasicAuth

from .config import KyvosConfig
from ..exceptions import ConfigurationError, AuthenticationError
from ..utils.constants import KyvosEndpoints, DebugLogs, ExceptionMessages, ErrorLogs, InfoLogs, HeaderKeys, Tools
from mcp_kyvos_server.utils.logging import setup_logger

logger, log_path = setup_logger()

class KyvosClient:
    """Base client for Kyvos API interactions."""

    def __init__(self, config: KyvosConfig | None = None) -> None:
        """Initialize the Kyvos client with configuration options.

        Args:
            config: Optional configuration object (will use env vars if not provided)

        Raises:
            ValueError: If configuration is invalid or required credentials are missing
        """
        try:
            # Load configuration from environment variables if not provided
            self.config = config or KyvosConfig.from_env()
            self.auth_type = self.config.auth_type
            # Store the base URL and authentication credentials
            self.base_url = self.config.url.rstrip("/")
            if self.config.username and self.config.personal_access_token:
                self.auth = BasicAuth(username=self.config.username, password=self.config.personal_access_token)
            else:
                self.auth = None
            self.default_folder = self.config.default_folder
            self.version = self.config.version
            self.verify_ssl = self.config.verify_ssl
            self.max_rows=self.config.max_rows

            
            logger.debug(DebugLogs.KYVOS_CLIENT_INITIALIZED.format(url=self.base_url))

        except ValueError as ve:
            logger.error(ErrorLogs.INVALID_KYVOS_CONFIG.format(error=ve), exc_info=True)
            raise ConfigurationError(ExceptionMessages.INVALID_CONFIG_EXCEPTION) from ve
        
        except Exception as e:
            logger.error(ErrorLogs.UNEXPECTED_KYVOS_ERROR.format(error=e), exc_info=True)
            raise ConfigurationError(ExceptionMessages.INIT_CLIENT_EXCEPTION) from e

    def _resolve_auth_header(self, auth_token: Optional[str]) -> tuple[str, bool]:
        """Return (header_value, set_public_app_type) for outgoing requests.

        Raises:
            AuthenticationError: If neither a request-level token nor server-level
                                  credentials are available.
        """
        if auth_token and self.auth_type != "no_auth":
            return auth_token, True
        if self.auth is not None:
            return self.auth._auth_header, False
        logger.error(ErrorLogs.MISSING_AUTH_CREDENTIALS)
        raise AuthenticationError(ErrorLogs.MISSING_AUTH_CREDENTIALS)

    async def list_semantic_models_from_space(self, folder_name_or_id: Optional[str] = None,space_name_or_id: Optional[str] = None, auth_token: Optional[str] = None) -> List[Dict[str, Any]]:
        """List all tables from a specified space in Kyvos.

        Args:
            folder_name_or_id: The name or ID of the folder to list tables from.
                               Defaults to the configured default folder.

        Returns:
            List of table objects with their metadata

        Raises:
            httpx.HTTPError: If the API request fails
        """

        folder = folder_name_or_id or self.default_folder
        space_name = space_name_or_id
        if not folder:
            raise ValueError("Folder name is missing. Please provide folder name.")
        if not space_name_or_id:
            raise ValueError("Space name is missing. Please provide space name.")
        logger.info(InfoLogs.SPACE_FOLDER.format(folder=folder))
        logger.info(InfoLogs.SPACE_NAME.format(space_name=space_name))
        version = self.version
        url = f"{self.base_url}{KyvosEndpoints.ENTITY_SEARCH.format(folder=folder, version=version)}"

        headers = {
            "Accept": "application/json",
            "Content-Type": "application/x-www-form-urlencoded"
        }
        params = {
            "maxRows": 1000,

            "filterJSON": json.dumps([{"fieldName": "entityType","value": "SPACE","operation": "EQUAL_TO"},
            {"fieldName":"folderName","value":f"{folder}","operation": "EQUAL_TO"},
            {"fieldName": "name", "value" : f"{space_name}","operation": "EQUAL_TO"}
            ])
        }

        auth_header, is_public = self._resolve_auth_header(auth_token)
        headers[HeaderKeys.AUTHORIZATION] = auth_header
        if is_public:
            headers["appType"] = "PUBLIC"

        logger.debug(InfoLogs.KYVOS_API_REQUEST_URL.format(tool=Tools.LIST_SEMANTIC_MODELS, url=url))
        logger.info(InfoLogs.FETCHING_TABLES.format(folder=folder))

        ctx = truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT) if self.verify_ssl else False

        try:
            async with httpx.AsyncClient(timeout=None, verify=ctx) as client:
                response = await client.post(
                    url,
                    headers=headers,
                    params=params
                )

                if response.is_error:
                    try:
                        error_json = response.json()
                        error_message = error_json.get("MESSAGE", response.text)
                    except ValueError:
                        error_message = response.text

                    if response.status_code == 401 and "token has expired" in error_message.lower():
                        logger.info(InfoLogs.REFRESHING_ACCESS_TOKEN)
                        return error_message.lower()

                    logger.error(ErrorLogs.CLIENT_ERROR_LOG.format(response_text=response.text))
                    raise ValueError(ErrorLogs.CLIENT_ERROR_EXCEPTION.format(error_message=error_message, url=url))

                data = response.json()
                if not data.get("IROS"):
                    logger.error(f"AI Space not found with name: {space_name}")
                    raise LookupError(f"AI Space name is not present with name: {space_name}")
                filtered_cubes = []
                business_context_ai_space = ""
                querying_context_ai_space = ""
                summary_context_ai_space = ""

                for item in data["IROS"]:
                    if item.get("TYPE") == "SPACE":
                        # Extract space-level context
                        business_context_ai_space = item.get("businessContext", "")
                        querying_context_ai_space = item.get("queryingInstructions", "")
                        summary_context_ai_space = item.get("summaryInstructions", "")

                        # Extract nested semantic models as tables
                        for entity in item.get("spaceEntities", []):
                            cube = {
                                "name": entity["name"],
                                "folder": entity.get("folder", folder),
                                **({"business_context": entity.get("businessContext")} if entity.get(
                                    "businessContext") else {})
                            }
                            filtered_cubes.append(cube)

                result = {
                    "tables": filtered_cubes,
                    **({"business_context_ai_space": business_context_ai_space} if business_context_ai_space else {}),
                    **({"querying_context_ai_space": querying_context_ai_space} if querying_context_ai_space else {}),
                    **({"summary_context_ai_space": summary_context_ai_space} if summary_context_ai_space else {}),
                }
                logger.debug(f"Combined response for AI space metadata: {result}")

                return result
        except (ValueError, LookupError):
            raise
        except httpx.HTTPStatusError as e:
            logger.error(ErrorLogs.HTTP_ERROR_FETCHING_TABLES.format(url=url, error=e), exc_info=True)
            raise ValueError(ExceptionMessages.HTTP_ERROR_FETCHING_TABLES.format(error_message=e.response.text)) from e

        except httpx.RequestError as e:
            logger.error(ErrorLogs.NETWORK_CONNECTION_ERROR.format(url=url, error=e), exc_info=True)
            raise ConnectionError(ExceptionMessages.NETWORK_CONNECTION_ERROR) from e

        except Exception as e:
            logger.error(ErrorLogs.UNEXPECTED_ERROR_LISTING_TABLES, exc_info=True)
            raise RuntimeError(ExceptionMessages.UNEXPECTED_ERROR_LISTING_TABLES) from e

    async def list_semantic_models(self, folder_name_or_id: Optional[str] = None, auth_token: Optional[str] = None, semantic_model_name_or_id: Optional[str] = None,) -> List[Dict[str, Any]]:
        """List all tables from a specified folder in Kyvos.
        
        Args:
            folder_name_or_id: The name or ID of the folder to list tables from.
                               Defaults to the configured default folder.
            
        Returns:
            List of table objects with their metadata
            
        Raises:
            httpx.HTTPError: If the API request fails
        """

        folder = folder_name_or_id or self.default_folder
        if not folder:
            raise ValueError("Folder name is missing. Please provide folder name.")
        version = self.version
        url = f"{self.base_url}{KyvosEndpoints.ENTITY_SEARCH.format(folder=folder, version=version)}"

        headers = {
                    "Accept": "application/json",
                   "Content-Type": "application/x-www-form-urlencoded"
                   }
        filters=[
                {"fieldName": "entityType", "value": "SMODEL", "operation": "EQUAL_TO"},
                {"fieldName": "folderName", "value": f"{folder}", "operation": "EQUAL_TO"}
            ]
        if semantic_model_name_or_id:
            filters.append({"fieldName": "name", "value": f"{semantic_model_name_or_id}", "operation": "EQUAL_TO"})
        params = {
            "maxRows": 1000,
            "filterJSON": json.dumps(filters),
            "fetchProcessedStatus": "true",
            "queryableModelsOnly": "true"
        }
        
        auth_header, is_public = self._resolve_auth_header(auth_token)
        headers[HeaderKeys.AUTHORIZATION] = auth_header
        if is_public:
            headers["appType"] = "PUBLIC"

        logger.debug(InfoLogs.KYVOS_API_REQUEST_URL.format(tool=Tools.LIST_SEMANTIC_MODELS, url=url))
        logger.info(InfoLogs.FETCHING_TABLES.format(folder=folder))

        ctx = truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT) if self.verify_ssl else False  

        try:
            async with httpx.AsyncClient(timeout=None,verify=ctx) as client:
                response = await client.post(
                    url, 
                    headers=headers,
                    params=params
                )
                
                if response.is_error:
                    try:
                        error_json = response.json()
                        error_message = error_json.get("MESSAGE", response.text)
                    except ValueError:
                        error_message = response.text

                    if response.status_code == 401 and "token has expired" in error_message.lower():
                        logger.info(InfoLogs.REFRESHING_ACCESS_TOKEN)
                        return error_message.lower()

                    logger.error(ErrorLogs.CLIENT_ERROR_LOG.format(response_text=response.text))
                    raise ValueError(ErrorLogs.CLIENT_ERROR_EXCEPTION.format(error_message=error_message, url=url))
                                    
                data = response.json()
                if semantic_model_name_or_id and not data.get("IROS"):
                    logger.error(f"Semantic Model not found with name: {semantic_model_name_or_id}")
                    raise LookupError(f"Semantic model is not present with name: {semantic_model_name_or_id}")
                filtered_cubes = [
                    {
                        "name": cube["NAME"],
                        "folder": folder,
                        **({"business_context": cube["BUSINESS_CONTEXT"]} if cube.get("BUSINESS_CONTEXT") else {})
                    }

                    for cube in data["IROS"]
                ]

                filtered_cubes={"tables":filtered_cubes}
                logger.debug(InfoLogs.KYVOS_API_RESPONSE.format(tool=Tools.LIST_SEMANTIC_MODELS, response=data))
                logger.info(InfoLogs.FETCHED_TABLES_FROM_FOLDER.format(count=len(filtered_cubes), folder=folder, filtered_cubes=filtered_cubes))
                return filtered_cubes

        except (ValueError, LookupError):
            raise
        except httpx.HTTPStatusError as e:
            logger.error(ErrorLogs.HTTP_ERROR_FETCHING_TABLES.format(url=url, error=e), exc_info=True)
            raise ValueError(ExceptionMessages.HTTP_ERROR_FETCHING_TABLES.format(error_message=e.response.text)) from e

        except httpx.RequestError as e:
            logger.error(ErrorLogs.NETWORK_CONNECTION_ERROR.format(url=url, error=e), exc_info=True)
            raise ConnectionError(ExceptionMessages.NETWORK_CONNECTION_ERROR) from e

        except Exception as e:
            logger.error(ErrorLogs.UNEXPECTED_ERROR_LISTING_TABLES, exc_info=True)
            raise RuntimeError(ExceptionMessages.UNEXPECTED_ERROR_LISTING_TABLES) from e

    async def list_semantic_model_details(self, table_name: str, folder_name: Optional[str] = None, auth_token: Optional[str] = None) -> Dict[str, Any]:
        """List all columns for a given table and folder in Kyvos.

        Args:
            table_name: Name of the semantic model (table)
            folder_name: Name of the folder containing the semantic model.
                         Defaults to the configured default folder.

        Returns:
            Dictionary containing column metadata for the specified table and summary context for data summarization style.

        Raises:
            httpx.HTTPError: If the API request fails
        """

        folder = folder_name or self.default_folder

        headers = {"Accept": "application/json"}

        auth_header, is_public = self._resolve_auth_header(auth_token)
        headers[HeaderKeys.AUTHORIZATION] = auth_header
        if is_public:
            headers["appType"] = "PUBLIC"

        ctx = truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT) if self.verify_ssl else False

        try:
            async with httpx.AsyncClient(timeout= None,verify=ctx) as client:
                logger.info(InfoLogs.FETCHING_SM_DETAILS.format(table_name=table_name, folder=folder))

                raw_data_query = await self._fetch_raw_data_query_flag(client, headers, table_name, folder)

                #fetch sql metadata
                logger.info(InfoLogs.FETCHING_SM_COLUMNS.format(table_name=table_name, folder=folder))

                metadata_data = await self._fetch_sql_metadata(client, headers, table_name, folder)
                filtered_columns= self._parse_columns(metadata_data, raw_data_query)

                logger.debug(InfoLogs.KYVOS_API_RESPONSE.format(tool=Tools.LIST_SEMANTIC_MODEL_DETAILS, response=metadata_data))
                logger.info(InfoLogs.FETCHED_COLUMNS.format(table_name=table_name, columns=filtered_columns))

                # Fetch AI settings
                logger.info(InfoLogs.FETCHING_SM_AI_SETTINGS.format(table_name=table_name, folder=folder))

                ai_context = await self._fetch_ai_settings(
                    client=client, headers=headers, table_name=table_name, folder=folder
                )
                logger.debug(InfoLogs.KYVOS_API_RESPONSE.format(tool=Tools.LIST_SEMANTIC_MODEL_DETAILS, response=ai_context))
                summary_instructions = ai_context.get("NLSummary", {}).get("summaryPrompt", "")
                querying_instructions = ai_context.get("NLQuerying", {}).get("queryPrompt", "")

                logger.info(
                    InfoLogs.QUERY_CONTEXT.format(table_name=table_name, query_context=querying_instructions)
                    if querying_instructions else
                    InfoLogs.QUERY_CONTEXT_MISSING.format(table_name=table_name)
                )
                logger.info(
                    InfoLogs.SUMMARY_CONTEXT.format(table_name=table_name, summary_context=summary_instructions)
                    if summary_instructions else
                    InfoLogs.SUMMARY_CONTEXT_MISSING.format(table_name=table_name)
                )

                model_type = "flexible" if raw_data_query else "aggregated"
                logger.info(InfoLogs.FETCHING_KYVOS_QUERYING_RULES.format(model_type=model_type))
                query_rules_headers = headers.copy()
                query_rules_headers["Accept"] = "text/plain"
                kyvos_query_generation_rules = await self._fetch_query_rules(client, model_type, query_rules_headers)
                logger.debug(InfoLogs.KYVOS_API_RESPONSE.format(tool=Tools.LIST_SEMANTIC_MODEL_DETAILS, response=kyvos_query_generation_rules))

                result = {
                    "columns": filtered_columns,
                    "kyvos_query_generation_rules": kyvos_query_generation_rules,
                    **({"querying_instructions": querying_instructions} if querying_instructions else {}),
                    **({"summary_instructions": summary_instructions} if summary_instructions else {}),
                }
                logger.info(InfoLogs.COMBINED_TABLE_DETAILS.format(details=result))

                return result

        except httpx.HTTPStatusError as e:
            logger.error(ErrorLogs.HTTP_ERROR_COLUMNS.format(table_name=table_name, error=e), exc_info=True)
            raise ValueError(ExceptionMessages.HTTP_ERROR_COLUMNS.format(details=e.response.text)) from e

        except httpx.RequestError as e:
            logger.error(ErrorLogs.NETWORK_ERROR_COLUMNS.format(table_name=table_name, error=e), exc_info=True)
            raise ConnectionError(ExceptionMessages.NETWORK_ERROR_COLUMNS) from e

        except Exception as e:
            logger.error(ErrorLogs.UNEXPECTED_ERROR_COLUMNS.format(table_name=table_name, error=e), exc_info=True)
            raise RuntimeError(ExceptionMessages.UNEXPECTED_ERROR_COLUMNS) from e

    async def _fetch_raw_data_query_flag(self, client: httpx.AsyncClient, headers: dict, table_name: str, folder: str) -> bool:
        """Fetch the ALLOW_RAW_DATA_QUERY flag for a semantic model via the entity search API."""
        url = f"{self.base_url}{KyvosEndpoints.ENTITY_SEARCH.format(folder=folder, version=self.version)}"

        post_headers = {
            "Accept": "application/json",
            "Content-Type": "application/x-www-form-urlencoded",
            HeaderKeys.AUTHORIZATION: headers[HeaderKeys.AUTHORIZATION],
        }
        if "appType" in headers:
            post_headers["appType"] = headers["appType"]

        params = {
            "maxRows": 1,
            "filterJSON": json.dumps([
                {"fieldName": "entityType", "value": "SMODEL", "operation": "EQUAL_TO"},
                {"fieldName": "folderName", "value": folder, "operation": "EQUAL_TO"},
                {"fieldName": "name", "value": table_name, "operation": "EQUAL_TO"},
            ]),
            "fetchProcessedStatus": "true",
            "queryableModelsOnly": "true",
        }

        logger.debug(DebugLogs.CHECKING_RAW_QUERY_PERMISSION.format(table_name))
        response = await client.post(url, headers=post_headers, params=params)

        if response.is_error:
            logger.debug(DebugLogs.RAW_QUERY_DEFAULT_VALUE)
            return False

        data = response.json()
        iros = data.get("IROS", [])
        if not iros:
            logger.debug(DebugLogs.RAW_QUERY_DEFAULT_VALUE)
            return False

        value = iros[0].get("ALLOW_RAW_DATA_QUERY")
        if not isinstance(value, bool):
            logger.debug(DebugLogs.RAW_QUERY_UNEXPECTED_VALUE.format(value=repr(value)))
            return False

        logger.debug(DebugLogs.TABLE_MATCHED_WITH_FLAG.format(table_name=table_name, value=repr(value)))
        logger.info(DebugLogs.RAW_QUERY_PERMISSION_SET.format(table_name=table_name, raw_data_query=value))
        return value

    def _parse_columns(self, metadata_data: list, raw_data_query: bool) -> list:
        """Filter and transform raw column metadata into the expected output format."""
        filtered_columns = []
        for column in metadata_data:
            if column.get("visible", False):
                filtered_column = {
                    "name": column["name"]
                }
                description = column.get("description", "").strip()
                tags = column.get("tags", "")
                # Normalize tags to string if it's a list
                if isinstance(tags, list):
                    tags = ", ".join(tags)
                parts = [
                    description.strip() if description else None,
                    f"Tags: {tags.strip()}" if tags else None,
                ]
                filtered_column["description"] = " | ".join(part for part in parts if part)

                summary_function = column.get("summaryFunction", "")
                if not raw_data_query:
                    if summary_function.strip():  # Only add if non-empty and not just whitespace
                        if summary_function == "DISTCOUNT":
                            filtered_column["use_aggregate_function"] = f"COUNT(DISTINCT `{column['name']}`)"
                        else:
                            filtered_column["use_aggregate_function"] = f"{summary_function}(`{column['name']}`)"
                data_type = column.get("dataType", "")
                if data_type.strip():  # Only add if non-empty and not just whitespace
                    filtered_column["dataType"] = data_type

                field_type = column.get("associationType")
                if field_type == "MEASURE" and column["summaryFunction"] == '':
                    filtered_column["field_type"] = "CALCULATED_MEASURE"
                else:
                    filtered_column["field_type"] = field_type
                filtered_columns.append(filtered_column)
        return filtered_columns

    async def _fetch_sql_metadata(self, client: httpx.AsyncClient, headers: dict, table_name: str, folder: str,) -> list:
        """Fetch column metadata for a semantic model via the SQL metadata endpoint."""
        url = f"{self.base_url}{KyvosEndpoints.SQL_METADATA.format(version=self.version)}"
        params = {
            "smodelName": table_name,
            "folderName": folder,
            "isAIUsecase": True,
        }
        return await self._get(client, url, headers, params)

    async def _fetch_ai_settings(self, client: httpx.AsyncClient, headers: dict, table_name: str, folder: str,) -> dict:
        """Fetch AI configuration settings for a semantic model."""
        url = f"{self.base_url}{KyvosEndpoints.AI_SETTINGS.format(version=self.version)}"
        params = {
            "smodelName": table_name,
            "folderName": folder,
        }
        return await self._get(client, url, headers, params)

    async def _fetch_query_rules(self, client: httpx.AsyncClient, model_type: str, headers: dict) -> dict:
        """Fetch kyvos query generation rules for a given model type."""
        url = f"{self.base_url}{KyvosEndpoints.KYVOS_RULES}"
        params = {
            "component": "olapengine",
            "metadata": f"service?service=getQueryGenerationRules$%$type={model_type}"
        }
        return await self._get(client, url, headers, params)

    async def _get(self, client: httpx.AsyncClient, url: str, headers: dict, params: dict,) -> Any:
        """Shared GET request handler with consistent error logging."""
        logger.debug(InfoLogs.KYVOS_API_REQUEST_URL.format(tool=Tools.LIST_SEMANTIC_MODEL_DETAILS, url=url))
        response = await client.get(url, params=params, headers=headers)
        if response.is_error:
            logger.error(
                ErrorLogs.CLIENT_ERROR_EXCEPTION.format(error_message=response.text, url=url),
                exc_info=True,
            )
            raise ValueError(
                ErrorLogs.CLIENT_ERROR_EXCEPTION.format(error_message=response.text, url=url)
            )
        accept_header = headers.get("Accept", "").lower()
        if accept_header == "text/plain":
            return response.text
        else:
            return response.json()



    async def execute_query(self, query: str, auth_token: Optional[str] = None) -> Dict[str, Any]:
        """Execute an SQL query on Kyvos.
        
        Args:
            query: SQL query to execute
            auth_token: Optional authentication token
            
        Returns:
            Dictionary containing the query results
            
        Raises:
            httpx.HTTPError: If the API request fails
        """
        version=self.version
        url = f"{self.base_url}{KyvosEndpoints.EXPORT_QUERY.format(version=version)}"
        headers = {
                "Accept": "application/json",
                "Content-Type": "application/x-www-form-urlencoded"
            }
        
        auth_header, is_public = self._resolve_auth_header(auth_token)
        headers[HeaderKeys.AUTHORIZATION] = auth_header
        if is_public:
            headers["appType"] = "PUBLIC"

        max_rows= self.max_rows
        data = {
            "queryType": "SQL",
            "outputFormat" : "JSON",
            "query": query,
            "maxRows": max_rows
        }

        logger.debug(InfoLogs.KYVOS_API_REQUEST_URL.format(tool=Tools.EXECUTE_QUERY, url=url))
        logger.debug(InfoLogs.KYVOS_API_REQUEST_PAYLOAD.format(tool=Tools.EXECUTE_QUERY, payload=data))
        logger.info(InfoLogs.QUERY_EXECUTING.format(query=query))

        ctx = truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT) if self.verify_ssl else False 
        
        try:
            async with httpx.AsyncClient(timeout=None,verify=ctx) as client:
                response = await client.post(
                    url, 
                    data=data, 
                    headers=headers, 
                )

                if response.is_error:
                    error_json = response.json()
                    error_message = error_json.get("MESSAGE", response.text)
                    
                    if response.status_code == 401 and "token has expired" in error_message.lower():
                        logger.info(InfoLogs.REFRESHING_ACCESS_TOKEN)
                        return error_message.lower()
                    
                    logger.error(ErrorLogs.SQL_ERROR_WITH_RESPONSE.format(response=response.text, query=query))
                    logger.error(ErrorLogs.QUERY_EXECUTION_FAILED)
                    return f"Last time the SQL you generated failed with error : '{response.text}'. Please generate another spark SQL that works as per guidance."
                
                try:
                    result = response.json()
                    logger.debug(InfoLogs.KYVOS_API_RESPONSE.format(tool=Tools.EXECUTE_QUERY, response=result))
                    logger.info(InfoLogs.QUERY_SUCCESS)
                    return result
                except Exception:
                    raise ValueError("Failed to parse response JSON.")
                 
        except httpx.HTTPStatusError as e:
            logger.error(ErrorLogs.HTTP_ERROR_EXECUTING_QUERY.format(query=query, error=e.response.text), exc_info=True)
            raise ValueError(ExceptionMessages.HTTP_STATUS_ERROR.format(code=e.response.status_code, text=e.response.text)) from e

        except httpx.RequestError as e:
            logger.error(ErrorLogs.NETWORK_ERROR_EXECUTING_QUERY.format(query=query, error=e), exc_info=True)
            raise ConnectionError(ExceptionMessages.NETWORK_ERROR) from e

        except Exception as e:
            logger.error(ErrorLogs.UNEXPECTED_ERROR_EXECUTING_QUERY.format(query=query, error=e), exc_info=True)
            raise RuntimeError(ExceptionMessages.UNEXPECTED_ERROR) from e