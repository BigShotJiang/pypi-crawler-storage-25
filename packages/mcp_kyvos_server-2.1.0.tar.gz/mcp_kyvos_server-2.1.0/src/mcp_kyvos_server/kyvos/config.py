"""Configuration module for Kyvos API interactions."""

import os
from dataclasses import dataclass, field
from typing import Optional
from mcp_kyvos_server.utils.logging import setup_logger
from ..utils.constants import ErrorLogs, EnvironmentVariables

logger, log_path = setup_logger()

@dataclass
class KyvosConfig:
    """
    Kyvos API configuration.
    Handles authentication for Kyvos REST API using basic authentication.
    """

    url: str                                                              # Base URL for Kyvos
    default_folder: str                                                   # Default folder for queries
    version: int
    max_rows: int
    auth_type: str
    username: Optional[str] = None                                        # Username for authentication
    personal_access_token: Optional[str] = None                          # Personal access token for authentication
    verify_ssl: bool = True


    @classmethod
    def from_env(cls) -> "KyvosConfig":
        """Create configuration from environment variables.

        Returns:
            KyvosConfig with values from environment variables

        Raises:
            ValueError: If required environment variables are missing
        """
        url = os.getenv(EnvironmentVariables.KYVOS_URL)
        if not url:
            logger.error(ErrorLogs.MISSING_URL)
            raise ValueError(ErrorLogs.MISSING_URL)

        auth_type = os.getenv("AUTH_TYPE", "basic")

        # Get authentication credentials — required only for no_auth mode
        username = os.getenv(EnvironmentVariables.KYVOS_USERNAME)
        personal_access_token = os.getenv(EnvironmentVariables.KYVOS_PERSONAL_ACCESS_TOKEN)

        if auth_type == "no_auth":
            if not username:
                logger.error(ErrorLogs.MISSING_USERNAME)
                raise ValueError(ErrorLogs.MISSING_USERNAME)
            if not personal_access_token:
                logger.error(ErrorLogs.MISSING_PERSONAL_ACCESS_TOKEN)
                raise ValueError(ErrorLogs.MISSING_PERSONAL_ACCESS_TOKEN)

        # Get default folder if specified
        default_folder = os.getenv(EnvironmentVariables.KYVOS_DEFAULT_FOLDER)
        version_str = os.getenv("KYVOS_VERSION")
        try:
            version = int(version_str) if version_str else 2
        except ValueError:
            logger.warning(f"Invalid version '{version_str}', defaulting to 2.")
            version = 2

        verify_ssl = os.getenv(EnvironmentVariables.VERIFY_SSL, "true").lower() in ("true", "1", "yes")
        max_rows = int(os.getenv('MAX_ROWS', "1000"))
        return cls(
            url=url,
            username=username,
            personal_access_token=personal_access_token,
            default_folder=default_folder,
            verify_ssl=verify_ssl,
            version=version,
            auth_type=auth_type,
            max_rows=max_rows
        )