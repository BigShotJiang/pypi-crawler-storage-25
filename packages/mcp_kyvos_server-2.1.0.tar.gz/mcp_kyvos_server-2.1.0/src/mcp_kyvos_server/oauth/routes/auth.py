import asyncio
import os
import uuid
import urllib.parse
from pydantic import ValidationError

from fastapi.templating import Jinja2Templates
from fastapi import APIRouter, HTTPException, Header, status
from fastapi.requests import Request
from fastapi.responses import RedirectResponse

from mcp_kyvos_server.utils.logging import setup_logger
from mcp_kyvos_server.kyvos.auth_config import config
from mcp_kyvos_server.utils.constants import WarningLogs, ErrorLogs, InfoLogs

from mcp_kyvos_server.oauth.services.kyvos_services import OAuthMetadataService
from mcp_kyvos_server.oauth.services.kyvos_services import ClientRegistrationService
from mcp_kyvos_server.oauth.services.kyvos_services import AuthService
from mcp_kyvos_server.oauth.services.kyvos_services import client_auth_service
from mcp_kyvos_server.oauth.services.models import PKCEManager

import time
from mcp_kyvos_server.kyvos.mcp_server_url import mcp_server_url
logger, log_path = setup_logger()

auth_type = os.getenv("AUTH_TYPE")
auth_router = APIRouter()
metadata_service = OAuthMetadataService()
client_service = ClientRegistrationService()
auth_service = AuthService(auth_type)

# In-memory store for PKCE state during the browser round-trip.
_token_cache: dict = {}


# ----------------------------------------------------------------------------
# Well-Known API to return protected resource metadata
# ----------------------------------------------------------------------------
@auth_router.get("/.well-known/oauth-protected-resource")
async def protected_resource_metadata(request: Request, mcp_version_protocol: str = Header(None)):
    logger.debug("protected_resource_metadata method invoked")
    metadata = {
        "resource": f"{mcp_server_url}",
        "authorization_servers": [f"{mcp_server_url}"],
        "bearer_methods_supported": ["header"],
        "scopes_supported": ["read", "write"]  # adjust to your scopes
    }
    return metadata


# ----------------------------------------------------------------------------
# Well-Known API to return authorization server metadata.
# ----------------------------------------------------------------------------
@auth_router.get("/.well-known/oauth-authorization-server")
async def authorization_server_metadata(request: Request, mcp_version_protocol: str = Header(None)):
    if auth_type=="oauth":
        metadata = await asyncio.to_thread(metadata_service.fetch_openid_configuration)
        logger.debug("authorization_server_metadata method invoked")
        if not metadata:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                            detail="Failed to fetch OpenID configuration from upstream.")
        return metadata

    elif auth_type=="no_auth":
        #Prepare dummay metadata
        config.KYVOS_CLIENT_ID = "DUMMY_CLIENT"
        config.KYVOS_SCOPE = "offline_access openid email profile"
        config.KYVOS_AUTHORIZE_URL = f"{mcp_server_url}/dologin"
        config.KYVOS_TOKEN_URL = f""

        metadata = {
            "issuer": f"{mcp_server_url}/",
            "authorization_endpoint": f"{mcp_server_url}/authorize",
            "token_endpoint": f"{mcp_server_url}/token",
            "registration_endpoint": f"{mcp_server_url}/register",
            "scopes_supported": ["read", "write"],
            "response_types_supported": ["code"],
            "code_challenge_methods_supported": ["S256"],
            "grant_types_supported": ["authorization_code", "refresh_token"]
        }
        return metadata


# ----------------------------------------------------------------------------
# Register API to register the client and get its callback URL.
# ----------------------------------------------------------------------------
@auth_router.post("/register")
async def register_client(request: Request):
    try:
        body = await request.json()
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=e.errors())
    except Exception:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid JSON payload.")

    try:
        client_resp = client_service.register_client(body)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

    return client_resp


# ----------------------------------------------------------------------------
# Authorize API to construct authorization url and redirect user to browser.
# ----------------------------------------------------------------------------
@auth_router.get("/authorize")
async def authorize(request: Request):
    params = request.query_params
    state = params.get("state") or str(uuid.uuid4())
    client_id = params.get("client_id")
    redirect_uri = params.get("redirect_uri")

    client = client_service.get_client(client_id)
    if client is None:
        logger.warning(WarningLogs.CLIENT_NOT_REGISTERED)
        client_redirect_uri = redirect_uri
    else:
        client_redirect_uri = redirect_uri or client["redirect_uris"][0]

    # Generate PKCE code challenge pair if not present
    code_verifier, code_challenge = await PKCEManager.create_code_challenge_pair()

    _token_cache[state] = {
        "code_verifier": code_verifier,
        "code_challenge": code_challenge,
        "client_redirect_uri": client_redirect_uri,
        "expires_at": time.time() + 600,  # 10 min for user to complete login
    }

    login_hint = "username"

    # Construct authorization URL
    auth_url = (
        f"{config.KYVOS_AUTHORIZE_URL}?"
        f"response_type=code&client_id={config.KYVOS_CLIENT_ID}"
        f"&redirect_uri={config.REDIRECT_URI}"
        f"&scope={config.KYVOS_SCOPE}"
        f"&state={state}"
        f"&code_challenge={code_challenge}"
        f"&code_challenge_method=S256"
        f"&prompt=login&login_hint={login_hint}"
    )

    logger.info(InfoLogs.CLIENT_REDIRECTING_TO_AUTH_URL)
    return RedirectResponse(auth_url)


# ----------------------------------------------------------------------------
# Callback URL for dummy login.
# ----------------------------------------------------------------------------
@auth_router.get("/dologin")
async def dologin(request: Request):
    params = request.query_params
    state = params.get("state")
    code = params.get("code_challenge")
    redirect_uri = params.get("redirect_uri")

    if not code:
        logger.error(ErrorLogs.AUTH_CODE_MISSING)
        raise HTTPException(status_code=400, detail="Missing challenge code.")

    if not state:
        logger.error(ErrorLogs.STATE_PARAM_MISSING)
        raise HTTPException(status_code=400, detail="Missing state identifier.")

    if not redirect_uri:
        logger.error("Missing redirect_uri")
        raise HTTPException(status_code=400, detail="Missing redirect_uri.")

    redirect_url = f"{redirect_uri}?code={code}&state={state}"
    return RedirectResponse(redirect_url)


# ----------------------------------------------------------------------------
# Callback URL to receive authorization code and exchange it for access token.
# ----------------------------------------------------------------------------
@auth_router.get("/auth/callback")
async def callback(request: Request):
    params = request.query_params
    state = params.get("state")
    code = params.get("code")

    if not code:
        logger.error(ErrorLogs.AUTH_CODE_MISSING)
        raise HTTPException(status_code=400, detail="Missing authorization code.")

    if not state:
        logger.error(ErrorLogs.STATE_PARAM_MISSING)
        raise HTTPException(status_code=400, detail="Missing state identifier.")

    pkce_data = _token_cache.pop(state, None)
    if not pkce_data or not pkce_data.get("code_verifier") or time.time() > pkce_data.get("expires_at", 0):
        logger.error(ErrorLogs.CODE_VERIFIER_MISSING)
        raise HTTPException(status_code=400, detail="Missing or expired PKCE state.")

    try:
        token_data = await auth_service.handle_callback(code, pkce_data["code_verifier"])
    except Exception as e:
        logger.error(ErrorLogs.TOKEN_EXCHANGE_OR_BOUND_TOKEN_ERROR.format(exception=e))
        error_message = urllib.parse.quote("Token exchange failed. Please try again.")
        return RedirectResponse(f"/?error={error_message}")

    client_redirect_uri = pkce_data["client_redirect_uri"]
    redirect_uri = f"{client_redirect_uri}?code={token_data['bound_code']}&state={state}"
    logger.info(InfoLogs.CLIENT_REDIRECTING_TO_CALLBACK)

    return RedirectResponse(redirect_uri)


# ----------------------------------------------------------------------------
# Token API to receive bound code from client and return it access token.
# ----------------------------------------------------------------------------
@auth_router.post("/token")
async def generate_client_access_token(request: Request):
    logger.info(InfoLogs.GENERATING_CLIENT_ACCESS_TOKEN)
    body = await request.body()
    parsed = urllib.parse.parse_qs(body.decode())

    bound_auth_code = parsed.get("code", [None])[0]
    refresh_token = parsed.get("refresh_token", [None])[0]

    if refresh_token:
        logger.info(InfoLogs.CLIENT_REFRESH_TOKEN_FLOW_STARTED)
        return await auth_service.refresh_client_access_token(refresh_token)

    if not bound_auth_code:
        logger.error(ErrorLogs.CODE_PARAM_MISSING)
        raise HTTPException(status_code=400, detail="Missing authorization code")

    logger.debug(InfoLogs.BOUND_CODE_PROCESSING_STARTED)
    tokens = await client_auth_service.consume_bound_code(bound_auth_code)
    if not tokens:
        raise HTTPException(status_code=400, detail="Invalid or expired authorization code")
    logger.info(InfoLogs.OAUTH_FLOW_SUCCESS)
    return {
        "access_token": tokens["access_token"],
        "token_type": "bearer",
        "expires_in": tokens["expires_in"],
        "refresh_token": tokens["refresh_token"],
    }


# ----------------------------------------------------------------------------
# Error page redirection, if the token exchange fails.
# ----------------------------------------------------------------------------
base_dir = os.path.dirname(os.path.dirname(__file__))
templates_dir = os.path.join(base_dir, "templates")
templates = Jinja2Templates(directory=templates_dir)

@auth_router.get("/")
async def home(request: Request):
    error_message = request.query_params.get("error")
    return templates.TemplateResponse("index.html", {"request": request, "error": error_message})
