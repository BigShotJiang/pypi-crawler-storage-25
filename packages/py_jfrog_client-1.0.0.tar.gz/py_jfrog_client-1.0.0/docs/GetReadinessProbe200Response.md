# GetReadinessProbe200Response


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **str** |  | [optional] 

## Example

```python
from jfrog_client.models.get_readiness_probe200_response import GetReadinessProbe200Response

# TODO update the JSON string below
json = "{}"
# create an instance of GetReadinessProbe200Response from a JSON string
get_readiness_probe200_response_instance = GetReadinessProbe200Response.from_json(json)
# print the JSON string representation of the object
print(GetReadinessProbe200Response.to_json())

# convert the object into a dict
get_readiness_probe200_response_dict = get_readiness_probe200_response_instance.to_dict()
# create an instance of GetReadinessProbe200Response from a dict
get_readiness_probe200_response_from_dict = GetReadinessProbe200Response.from_dict(get_readiness_probe200_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


