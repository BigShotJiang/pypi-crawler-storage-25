"""OOM (Out-Of-Memory) predictor for MemScale.

Predicts OOM risk before training starts and during training.
Helps users avoid wasted compute on doomed runs.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum
from typing import Optional

import torch
import torch.nn as nn

from memscale.utils import estimate_training_memory, get_gpu_memory_info, get_model_size
from memscale._quota import require_quota

logger = logging.getLogger(__name__)


class OOMRisk(Enum):
    """Risk level of OOM during training."""

    SAFE = "safe"  # < 70% of available
    CAUTION = "caution"  # 70-85%
    HIGH = "high"  # 85-95%
    CRITICAL = "critical"  # > 95% — likely OOM


@dataclass
class OOMPrediction:
    """Result of OOM risk prediction."""

    risk: OOMRisk
    estimated_memory_gb: float
    available_memory_gb: float
    utilization_pct: float
    confidence: float  # 0-1, how confident the prediction is
    recommendations: list[str]  # Actionable suggestions

    @property
    def will_oom(self) -> bool:
        """Whether OOM is likely (HIGH or CRITICAL risk)."""
        return self.risk in [OOMRisk.HIGH, OOMRisk.CRITICAL]

    def __str__(self) -> str:
        emoji = {
            OOMRisk.SAFE: "✓",
            OOMRisk.CAUTION: "⚠",
            OOMRisk.HIGH: "⚠⚠",
            OOMRisk.CRITICAL: "✗",
        }
        return (
            f"{emoji[self.risk]} OOM Risk: {self.risk.value.upper()}\n"
            f"  Estimated: {self.estimated_memory_gb:.2f} GB / "
            f"Available: {self.available_memory_gb:.2f} GB "
            f"({self.utilization_pct:.0f}% utilization)\n"
            f"  Confidence: {self.confidence:.0%}\n"
            f"  Recommendations:\n"
            + "\n".join(f"    - {rec}" for rec in self.recommendations)
        )


class OOMPredictor:
    """Predicts OOM risk before and during training.

    Two prediction modes:
    1. Pre-training: Estimate based on model size + batch + optimizer
    2. Runtime: Track memory growth and predict if pattern continues

    Usage:
        from memscale import OOMPredictor

        predictor = OOMPredictor()

        # Before training
        prediction = predictor.predict_pretraining(
            model=model,
            batch_size=32,
            sequence_length=512,
            optimizer="adamw",
        )

        if prediction.will_oom:
            print(prediction)
            # Apply recommendations or reduce batch size
    """

    def __init__(self):
        self._memory_history: list[float] = []
        self._step_count = 0

    def predict_pretraining(
        self,
        model: nn.Module,
        batch_size: int,
        sequence_length: int = 512,
        optimizer: str = "adamw",
        gradient_checkpointing: bool = False,
    ) -> OOMPrediction:
        """Predict OOM risk before training starts.

        Args:
            model: PyTorch model
            batch_size: Training batch size
            sequence_length: Sequence length (for transformer models)
            optimizer: Optimizer name (adamw, sgd, adam)
            gradient_checkpointing: Whether gradient checkpointing is enabled

        Returns:
            OOMPrediction with risk level and recommendations
        """
        # Get model size
        _, model_bytes = get_model_size(model)

        # Estimate total training memory
        estimated_bytes = estimate_training_memory(
            model_params_bytes=model_bytes,
            batch_size=batch_size,
            sequence_length=sequence_length,
            optimizer=optimizer,
        )

        # Account for gradient checkpointing (saves ~30% activations)
        if gradient_checkpointing:
            # Activations contribute about 40% of total — checkpointing saves ~70% of that
            estimated_bytes = int(estimated_bytes * 0.72)

        estimated_gb = estimated_bytes / (1024**3)

        # Get available GPU memory
        gpu_info = get_gpu_memory_info()
        available_gb = gpu_info["total"] / (1024**3)

        if available_gb == 0:
            # CPU-only or no GPU detected
            return OOMPrediction(
                risk=OOMRisk.SAFE,
                estimated_memory_gb=estimated_gb,
                available_memory_gb=0.0,
                utilization_pct=0.0,
                confidence=0.3,
                recommendations=[
                    "No GPU detected — running on CPU. OOM risk depends on system RAM.",
                ],
            )

        # Calculate utilization percentage
        utilization_pct = (estimated_gb / available_gb) * 100

        # Determine risk level
        if utilization_pct < 70:
            risk = OOMRisk.SAFE
            recommendations = ["Configuration looks safe."]
        elif utilization_pct < 85:
            risk = OOMRisk.CAUTION
            recommendations = [
                "Memory usage will be high. Consider enabling MemScale.",
                f"Reduce batch size from {batch_size} to {max(1, int(batch_size * 0.7))}",
            ]
        elif utilization_pct < 95:
            risk = OOMRisk.HIGH
            recommendations = [
                "OOM is likely. Strong recommendation to enable MemScale.",
                f"Reduce batch size from {batch_size} to {max(1, int(batch_size * 0.5))}",
                "Enable gradient checkpointing.",
                "Consider using smaller sequence length.",
            ]
        else:
            risk = OOMRisk.CRITICAL
            recommendations = [
                "Training will likely OOM. Action required:",
                f"Reduce batch size from {batch_size} to {max(1, int(batch_size * 0.3))}",
                "Use MemScale with AGGRESSIVE mode",
                "Enable activation checkpointing AND CPU offloading",
                "Or use a larger GPU (more VRAM)",
            ]

        # Estimation confidence depends on model architecture knowledge
        confidence = 0.75 if hasattr(model, "config") else 0.6

        return OOMPrediction(
            risk=risk,
            estimated_memory_gb=estimated_gb,
            available_memory_gb=available_gb,
            utilization_pct=utilization_pct,
            confidence=confidence,
            recommendations=recommendations,
        )

    def update_runtime(self, current_memory_gb: float) -> Optional[OOMPrediction]:
        """Update predictor with current memory usage during training.

        Args:
            current_memory_gb: Current VRAM allocation in GB

        Returns:
            OOMPrediction if risk is detected, None otherwise
        """
        self._memory_history.append(current_memory_gb)
        self._step_count += 1

        # Need at least 5 data points to predict
        if len(self._memory_history) < 5:
            return None

        # Use last 10 measurements
        recent = self._memory_history[-10:]

        # Calculate growth rate (GB per step)
        growth_rate = (recent[-1] - recent[0]) / len(recent)

        # If memory is growing, predict where we'll be in 10 more steps
        gpu_info = get_gpu_memory_info()
        available_gb = gpu_info["total"] / (1024**3)

        if available_gb == 0:
            return None

        # Project 10 steps into future
        projected_memory = recent[-1] + (growth_rate * 10)
        projected_pct = (projected_memory / available_gb) * 100

        # Only warn if we're projecting CRITICAL or HIGH risk
        if projected_pct < 85:
            return None

        if projected_pct >= 95:
            risk = OOMRisk.CRITICAL
            recommendations = [
                f"OOM expected in ~{int((available_gb - recent[-1]) / max(growth_rate, 0.01))} steps",
                "Stop training and investigate memory leak",
                "Check for: tensor accumulation, unfreed buffers, growing batch sizes",
            ]
        else:
            risk = OOMRisk.HIGH
            recommendations = [
                f"Memory growing at {growth_rate*1024:.1f} MB/step",
                "Monitor closely — may OOM in extended training",
                "Consider clearing CUDA cache periodically",
            ]

        return OOMPrediction(
            risk=risk,
            estimated_memory_gb=projected_memory,
            available_memory_gb=available_gb,
            utilization_pct=projected_pct,
            confidence=0.85,  # High confidence — based on actual measurements
            recommendations=recommendations,
        )

    def reset(self) -> None:
        """Reset runtime tracking history."""
        self._memory_history = []
        self._step_count = 0