"""MemScale distributed training module.

Two layers of distributed support:

1. FSDP integration (Phase 5):
   - FSDPAdapter, wrap_fsdp, get_distributed_context, wrap_ddp_model
   - Multi-node training orchestration

2. Custom sharding (Phase G):
   - ShardedParameter (Phase G-1: parameter sharding)
   - ShardedOptimizer (Phase G-2: optimizer state sharding)
   - ZeRO-3 inspired implementation

Usage:
    >>> # FSDP integration
    >>> from memscale.distributed import wrap_fsdp, get_distributed_context
    >>>
    >>> # Custom sharding (Phase G)
    >>> from memscale.distributed import init_distributed, shard_model_parameters
    >>>
    >>> # Multi-GPU launch
    >>> # torchrun --nproc_per_node=2 train.py
"""

# ============================================================
# Existing FSDP integration (preserve all old exports)
# ============================================================
from memscale.distributed.fsdp_adapter import (
    FSDPAdapter,
    FSDPConfig,
    ShardingStrategy,
    MixedPrecisionPolicy,
    BackwardPrefetch,
    DistributedSetup,
    MultiNodeOrchestrator,
    get_distributed_context,
    wrap_ddp_model,
    wrap_fsdp,
)

# Backward compatibility alias
DistributedContext = DistributedSetup


def should_log(rank: int = 0) -> bool:
    """Check if this rank should log (only rank 0 logs by default)."""
    import os
    env_rank = os.environ.get("RANK", "0")
    actual_rank = int(env_rank) if rank == 0 else rank
    return actual_rank == 0


# ============================================================
# NEW Phase G: Custom sharding (ZeRO-3 inspired)
# ============================================================
from memscale.distributed.sharding import (
    is_distributed_available,
    init_distributed,
    ShardedParameter,
    shard_model_parameters,
    estimate_phase_g_savings,
)
from memscale.distributed.sharded_optimizer import (
    ShardedOptimizer,
    estimate_optimizer_sharding_savings,
)


__all__ = [
    # ====== Existing FSDP integration ======
    "FSDPAdapter",
    "FSDPConfig",
    "ShardingStrategy",
    "MixedPrecisionPolicy",
    "BackwardPrefetch",
    "DistributedSetup",
    "DistributedContext",
    "MultiNodeOrchestrator",
    "wrap_fsdp",
    "get_distributed_context",
    "wrap_ddp_model",
    "should_log",
    # ====== Phase G-1: Parameter sharding ======
    "is_distributed_available",
    "init_distributed",
    "ShardedParameter",
    "shard_model_parameters",
    "estimate_phase_g_savings",
    # ====== Phase G-2: Optimizer sharding ======
    "ShardedOptimizer",
    "estimate_optimizer_sharding_savings",
]
