"""MemScale Advisor Module.

Provides recommendations for memory optimization:

- LocalAdvisor: FREE rule-based (no internet, no LLM)
- AIAdvisor: BYOK LLM-based (user provides OpenAI/Anthropic key)
"""

from memscale.advisor.local import LocalAdvisor, Recommendation
from memscale.advisor.byok import AIAdvisor

__all__ = ["LocalAdvisor", "AIAdvisor", "Recommendation"]
