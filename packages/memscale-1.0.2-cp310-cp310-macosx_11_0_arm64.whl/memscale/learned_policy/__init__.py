"""ML-based optimization policy engine for MemScale.

Uses scikit-learn to learn optimal optimization strategies from
historical training run outcomes. Falls back to rule-based decisions
when confidence is low or no training data available.

Status (v1.0):
- Rule-based fallback: PRODUCTION-READY ✓
- ML inference path: PRODUCTION-READY ✓ (when model loaded)
- Synthetic data generator: AVAILABLE for bootstrap
- Real ML training data: PLANNED v1.1 (collected from beta users)

Usage:
    # Quick decision (auto fallback to rules):
    >>> from memscale.learned_policy import make_decision
    >>> decision = make_decision(
    ...     model_params=8_000_000_000,
    ...     batch_size=8,
    ...     gpu_memory_gb=40,
    ... )
    >>> print(decision.mode)  # 'aggressive'
    
    # Train your own model (advanced):
    >>> from memscale.learned_policy import LearnedPolicyEngine
    >>> from memscale.learned_policy.synthetic_data import generate_training_data
    >>> 
    >>> data = generate_training_data(num_samples=1000)
    >>> engine = LearnedPolicyEngine()
    >>> metrics = engine.train(data)
    >>> print(metrics)  # {'status': 'trained', 'mode_accuracy': 0.85, ...}
"""

from memscale.learned_policy.policy_engine import (
    LearnedPolicyEngine,
    TrainingContext,
    OptimizationOutcome,
    PolicyDecision,
    make_decision,
)

# Synthetic data utilities (optional import)
try:
    from memscale.learned_policy.synthetic_data import (
        generate_training_data,
        stats as synthetic_data_stats,
        split_train_test,
    )
    _HAS_SYNTHETIC_DATA = True
except ImportError:
    _HAS_SYNTHETIC_DATA = False

__all__ = [
    "LearnedPolicyEngine",
    "TrainingContext",
    "OptimizationOutcome",
    "PolicyDecision",
    "make_decision",
]

if _HAS_SYNTHETIC_DATA:
    __all__.extend([
        "generate_training_data",
        "synthetic_data_stats",
        "split_train_test",
    ])
