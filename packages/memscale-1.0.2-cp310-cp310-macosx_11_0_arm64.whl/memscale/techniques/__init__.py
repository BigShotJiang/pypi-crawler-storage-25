"""MemScale techniques module - Phase F multi-technique stacking."""

from memscale.techniques.optimizer_8bit import (
    is_bitsandbytes_available,
    wrap_optimizer_to_8bit,
    estimate_optimizer_memory_savings,
)
from memscale.techniques.mixed_precision import (
    cast_model_to_bf16,
    autocast_bf16,
    estimate_mixed_precision_savings,
)

__all__ = [
    # Phase F-1: 8-bit optimizer
    "is_bitsandbytes_available",
    "wrap_optimizer_to_8bit",
    "estimate_optimizer_memory_savings",
    # Phase F-2: Mixed precision
    "cast_model_to_bf16",
    "autocast_bf16",
    "estimate_mixed_precision_savings",
]
