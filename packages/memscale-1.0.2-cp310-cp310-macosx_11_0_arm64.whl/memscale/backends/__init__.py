"""Multi-vendor GPU backend support for MemScale.

Auto-detects and provides unified interface for:
- NVIDIA CUDA
- AMD ROCm
- Apple MPS (Metal)
- CPU fallback
"""

from memscale.backends.manager import (
    Backend,
    BackendType,
    BackendManager,
    DeviceInfo,
    CUDABackend,
    ROCmBackend,
    MPSBackend,
    CPUBackend,
    get_backend,
    print_diagnostic,
)

__all__ = [
    "Backend",
    "BackendType",
    "BackendManager",
    "DeviceInfo",
    "CUDABackend",
    "ROCmBackend",
    "MPSBackend",
    "CPUBackend",
    "get_backend",
    "print_diagnostic",
]