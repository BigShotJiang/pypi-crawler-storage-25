"""Familienfilm Manager – Veröffentlichung von Familienfilmen mit Medienset, Infuse, Web und Archiv."""

__version__ = "0.3.0"
