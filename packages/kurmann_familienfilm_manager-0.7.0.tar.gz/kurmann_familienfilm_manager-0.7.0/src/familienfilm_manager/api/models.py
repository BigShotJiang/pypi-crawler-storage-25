"""Datenmodelle für die öffentliche API."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path
from typing import Callable


# ---------------------------------------------------------------------------
# Event-System
# ---------------------------------------------------------------------------

class FamilienfilmStage(StrEnum):
    """Stabile Stage-IDs für Fortschritts-Events."""

    METADATA_EXTRACTED = "metadata_extracted"
    MEDIASET_CREATED = "mediaset_created"
    INFUSE_DEPLOYED = "infuse_deployed"
    WEB_DEPLOYED = "web_deployed"
    ARCHIVED = "archived"
    PUBLISH_COMPLETED = "publish_completed"
    DIRECTORY_SCANNED = "directory_scanned"
    DIRECTORY_VIDEO_STARTED = "directory_video_started"
    DIRECTORY_VIDEO_UNSTABLE = "directory_video_unstable"
    WATCH_STARTED = "watch_started"
    WATCH_TICK_STARTED = "watch_tick_started"
    WATCH_TICK_COMPLETED = "watch_tick_completed"
    WATCH_STOPPED = "watch_stopped"
    DEPLOY_RETRY = "deploy_retry"          # rclone-Operation wird nach flüchtigem Fehler wiederholt
    DEPLOY_FAILED = "deploy_failed"        # rclone-Operation endgültig fehlgeschlagen (nach allen Retries)
    DEPLOYMENT_VERIFIED = "deployment_verified"  # Post-Deploy Health-Check bestätigt Ziel-Inhalt


@dataclass
class FamilienfilmEvent:
    """Strukturiertes Fortschritts-Event."""

    stage_id: str
    message: str
    paths: dict[str, Path] | None = None


# Typ-Alias für Event-Callback
EventCallback = Callable[[FamilienfilmEvent], None] | None


# ---------------------------------------------------------------------------
# Runtime-Optionen (technisch, getrennt vom fachlichen Request)
# ---------------------------------------------------------------------------

@dataclass
class RuntimeOptions:
    """Technische Laufzeitoptionen, typischerweise aus der Konfiguration geladen."""

    infuse_target: str = ""
    web_target: str = ""
    archive_target: str = ""
    infuse_group_by: str = "year"  # "year" oder "month"
    branding_base_url: str = ""    # Stamm-URL für Web-Mediasets und OG-Tags
    branding_site_name: str = ""   # Site-Name (sichtbar im Header + OG-Meta)
    ffmpeg_path: str = "ffmpeg"
    ffprobe_path: str = "ffprobe"
    rclone_path: str = "rclone"


# ---------------------------------------------------------------------------
# Publish (Gesamtworkflow)
# ---------------------------------------------------------------------------

@dataclass
class PublishRequest:
    """Fachlicher Request für den gesamten Veröffentlichungs-Workflow.

    Ab v0.7.0 kann die Quelle auch ein rclone-URI sein (``remote:path``) —
    dann ``source_uri`` statt ``source_path`` setzen. Intern immer über
    ``get_source_ref()`` auflösen.
    """

    source_path: Path | None = None        # Lokaler Pfad (v0.6.0-kompatibel)
    title: str | None = None
    description: str | None = None
    category: str | None = None
    recording_date: str | None = None  # ISO YYYY-MM-DD
    output_dir: Path | None = None
    work_dir: Path | None = None           # Arbeitsverzeichnis für temporäre Dateien
    force: bool = False
    skip_infuse: bool = False
    skip_web: bool = False
    skip_archive: bool = False
    poster_frame: int | None = None        # Frame-Nummer für Vorschaubild
    poster_at: float | None = None         # Zeitpunkt in Sekunden für Vorschaubild
    poster_crop: str | None = None         # Bildausschnitt (left/center-left/center/center-right/right)
    web_id: str | None = None              # Web-ID für Web-Medienset (12 Zeichen, a-z 0-9; überschreibt Sidecar)
    max_luminance: int | None = None       # Peak-Leuchtdichte in nits für HDR-Metadaten (Default: 1000)
    no_sidecar: bool = False               # Sidecar-Datei nicht lesen/schreiben
    scan_root: Path | str | None = None    # Obere Grenze für familienfilm.toml-Suche (URI oder Pfad)
    source_uri: str | None = None          # URI-Alternative für rclone-Quellen (``nas:/path/foo.mov``)

    def get_source_ref(self):
        """Gibt eine ``SourceRef`` zurück — URI-first, Path als Fallback.

        Genau eines von ``source_uri`` oder ``source_path`` muss gesetzt sein.
        """
        from familienfilm_manager.core.source_ref import SourceRef

        if self.source_uri is not None:
            return SourceRef(self.source_uri)
        if self.source_path is not None:
            return SourceRef(str(self.source_path))
        raise ValueError(
            "PublishRequest braucht entweder source_uri oder source_path"
        )


@dataclass
class PublishResult:
    """Ergebnis des Veröffentlichungs-Workflows."""

    success: bool
    infuse_dir: Path | None = None
    web_dir: Path | None = None
    web_id: str | None = None
    web_url: str | None = None  # Vollständige URL (branding_base_url + web_id), unabhängig vom lokalen web_dir
    infuse_deployed: bool = False
    web_deployed: bool = False
    archived: bool = False
    error_message: str | None = None


# ---------------------------------------------------------------------------
# Deploy (Einzeloperationen)
# ---------------------------------------------------------------------------

@dataclass
class DeployRequest:
    """Request für ein einzelnes Deployment (Infuse oder Web)."""

    source_dir: Path


@dataclass
class DeployResult:
    """Ergebnis eines Deployments."""

    success: bool
    target_path: str | None = None
    error_message: str | None = None


# ---------------------------------------------------------------------------
# Archivierung
# ---------------------------------------------------------------------------

@dataclass
class ArchiveRequest:
    """Request für die Archivierung einer Videodatei."""

    source_path: Path
    recording_date: str | None = None  # ISO YYYY-MM-DD, für ISO-Dateiname
    title: str | None = None           # Titel für ISO-Dateiname und Volume-Name
    work_dir: Path | None = None       # Arbeitsverzeichnis für TAR-Erstellung


@dataclass
class ArchiveResult:
    """Ergebnis der Archivierung."""

    success: bool
    archive_path: Path | None = None
    error_message: str | None = None


# ---------------------------------------------------------------------------
# Verzeichnis-Publish
# ---------------------------------------------------------------------------

class VideoStatusKind(StrEnum):
    """Status eines einzelnen Videos im Batch-Lauf."""

    PUBLISHED = "published"     # Erfolgreich publiziert
    SKIPPED = "skipped"         # Bereits publiziert, übersprungen
    FAILED = "failed"           # Fehler bei Publikation
    PENDING = "pending"         # Würde publiziert (nur im Dry-Run)
    UNSTABLE = "unstable"       # Datei wächst noch (z.B. laufender Export) — erneut versuchen


@dataclass
class VideoStatus:
    """Status eines einzelnen Videos im Batch-Lauf."""

    path: Path
    kind: VideoStatusKind
    publish_result: PublishResult | None = None  # Bei PUBLISHED gesetzt
    error_message: str | None = None             # Bei FAILED gesetzt
    published_at: str | None = None              # Bei SKIPPED gesetzt (ISO-Timestamp)


@dataclass
class DirectoryPublishResult:
    """Ergebnis eines Verzeichnis-Publish-Laufs."""

    success: bool
    directory: Path | str   # Lokaler Pfad oder rclone-URI (ab v0.7.0)
    videos: list[VideoStatus] = field(default_factory=list)
    error_message: str | None = None

    @property
    def published_count(self) -> int:
        return sum(1 for v in self.videos if v.kind == VideoStatusKind.PUBLISHED)

    @property
    def skipped_count(self) -> int:
        return sum(1 for v in self.videos if v.kind == VideoStatusKind.SKIPPED)

    @property
    def failed_count(self) -> int:
        return sum(1 for v in self.videos if v.kind == VideoStatusKind.FAILED)

    @property
    def pending_count(self) -> int:
        return sum(1 for v in self.videos if v.kind == VideoStatusKind.PENDING)

    @property
    def unstable_count(self) -> int:
        return sum(1 for v in self.videos if v.kind == VideoStatusKind.UNSTABLE)


# ---------------------------------------------------------------------------
# Watch (Verzeichnis-Überwachung)
# ---------------------------------------------------------------------------

@dataclass
class WatchRequest:
    """Fachlicher Request für die Verzeichnis-Überwachung.

    Das Timing der Wiederholung wird vom Watch-Modul gesteuert, nicht von den
    einzelnen Ticks — jeder Tick verhält sich identisch zum ``--once``-Modus.
    """

    directories: list[Path | str]           # Lokale Pfade oder rclone-URIs (ab v0.7.0)
    interval_seconds: int = 86400          # Default: 24 h
    stability_window_seconds: int = 60     # Grace-Period für wachsende Dateien
    once: bool = False                     # Nur ein Tick, dann Exit (launchd-kompatibel)
    recursive: bool = False                # Unterverzeichnisse mit einbeziehen
    category: str | None = None            # Default-Kategorie für alle Videos (CLI > Config > None)
    skip_infuse: bool = False
    skip_web: bool = False
    skip_archive: bool = False
    force: bool = False
    work_dir: Path | None = None


@dataclass
class WatchTickResult:
    """Ergebnis eines einzelnen Watch-Ticks (Scan über alle Verzeichnisse)."""

    directory_results: list[DirectoryPublishResult] = field(default_factory=list)
    error_messages: list[str] = field(default_factory=list)

    @property
    def published_count(self) -> int:
        return sum(r.published_count for r in self.directory_results)

    @property
    def failed_count(self) -> int:
        return sum(r.failed_count for r in self.directory_results)

    @property
    def unstable_count(self) -> int:
        return sum(r.unstable_count for r in self.directory_results)

    @property
    def skipped_count(self) -> int:
        return sum(r.skipped_count for r in self.directory_results)


@dataclass
class WatchResult:
    """Gesamtergebnis eines Watch-Laufs (ein oder mehrere Ticks)."""

    tick_count: int = 0
    ticks: list[WatchTickResult] = field(default_factory=list)
    stopped_by_signal: bool = False
