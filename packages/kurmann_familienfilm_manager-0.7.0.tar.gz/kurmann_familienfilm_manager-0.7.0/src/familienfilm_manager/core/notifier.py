"""Benachrichtigung: Protokolliert Publikations-Status in einer HTML-Datei.

Jeder Eintrag erhält eine stabile ``data-video-id`` (SHA1 des absoluten Quell-Pfads)
und wird mit einem HTML-Kommentar ``<!-- /entry -->`` terminiert. Damit kann ein
bestehender Block zuverlässig ersetzt werden — zuerst „wird publiziert…" (pending),
dann beim Abschluss durch „publiziert" oder „fehlgeschlagen".

Die Datei kann in iCloud Drive liegen und wird automatisch auf alle Geräte
synchronisiert. Links sind auf dem iPhone direkt klickbar.
"""

from __future__ import annotations

import hashlib
import re
from datetime import datetime
from html import escape
from pathlib import Path

_HTML_HEADER = """\
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Familienfilme</title>
<style>
  body { font-family: -apple-system, system-ui, sans-serif; background: #000; color: #ccc; padding: 1rem; }
  .entry { border-bottom: 1px solid #333; padding: 1rem 0; }
  .date { font-size: 0.8rem; color: #666; }
  .title { font-size: 1.1rem; font-weight: 600; color: #fff; margin: 0.3rem 0; }
  .meta { font-size: 0.85rem; color: #888; }
  a { color: #4af; }
  .entry.pending .title { color: #fa0; }
  .entry.pending .title::after { content: " — wird publiziert…"; color: #fa0; font-weight: 400; font-size: 0.9rem; }
  .entry.failed .title { color: #f55; }
  .entry.failed .meta { color: #f88; }
  .entry.aborted .title { color: #888; }
  .entry.aborted .title::after { content: " — abgebrochen"; color: #888; font-weight: 400; font-size: 0.9rem; }
</style>
</head>
<body>
"""

_HTML_FOOTER = "</body>\n</html>\n"

_ENTRY_END_MARKER = "<!-- /entry -->"


def derive_video_id(source_path: Path | str) -> str:
    """Stabile Kennung pro Quelldatei (SHA1-Prefix des absoluten Pfades oder URI).

    Wird als ``data-video-id`` ins HTML geschrieben und erlaubt späteres
    Wiederfinden/Ersetzen des Eintrags. Unabhängig von Umbenennungen innerhalb
    der Publikation (Poster-Suffix-Stripping usw.), da direkt aus dem Pfad
    abgeleitet.

    Für rclone-Quellen soll die Original-URI übergeben werden (z.B.
    ``"nas:/Quelle/2026-04-15 foo.mov"``) — nicht der gestagede lokale
    Pfad. Sonst wechselt die ID bei jedem Staging.
    """
    if isinstance(source_path, str):
        # URI-String: direkt als stabile Kennung nutzen (keine resolve())
        return hashlib.sha1(source_path.encode("utf-8")).hexdigest()[:16]
    return hashlib.sha1(str(source_path.resolve()).encode("utf-8")).hexdigest()[:16]


def _now_label() -> str:
    return datetime.now().strftime("%d.%m.%Y, %H:%M")


def _render_entry(
    *,
    video_id: str,
    css_class: str,
    title: str,
    video_url: str | None = None,
    category: str | None = None,
    recording_date: str | None = None,
    error_message: str | None = None,
    date_label: str | None = None,
) -> str:
    """Rendert einen Eintrags-Block (terminiert mit ``<!-- /entry -->``)."""
    title_html = (
        f'<a href="{escape(video_url, quote=True)}">{escape(title)}</a>'
        if video_url
        else escape(title)
    )
    lines: list[str] = []
    lines.append(f'<div class="entry {css_class}" data-video-id="{escape(video_id, quote=True)}">')
    lines.append(f'  <div class="date">{escape(date_label or _now_label())}</div>')
    lines.append(f'  <div class="title">{title_html}</div>')

    meta_parts: list[str] = []
    if category:
        meta_parts.append(escape(category))
    if recording_date:
        meta_parts.append(escape(recording_date))
    if meta_parts:
        lines.append(f'  <div class="meta">{" · ".join(meta_parts)}</div>')
    if error_message:
        lines.append(f'  <div class="meta">Fehler: {escape(error_message)}</div>')

    lines.append("</div>")
    lines.append(_ENTRY_END_MARKER)
    return "\n".join(lines) + "\n"


def _entry_pattern(video_id: str) -> re.Pattern[str]:
    """Regex, der einen kompletten Entry-Block mit passender ``data-video-id`` matcht."""
    return re.compile(
        r'<div class="entry [^"]*" data-video-id="'
        + re.escape(video_id)
        + r'">.*?'
        + re.escape(_ENTRY_END_MARKER)
        + r"\n?",
        re.DOTALL,
    )


def _insert_at_top(content: str, new_entry: str) -> str:
    """Fügt einen neuen Eintrag direkt nach ``<body>`` ein (neuste oben)."""
    insert_pos = content.find("<body>")
    if insert_pos == -1:
        return content + new_entry
    insert_pos = content.find("\n", insert_pos) + 1
    return content[:insert_pos] + new_entry + content[insert_pos:]


def _read_or_init(notification_path: Path) -> str:
    if notification_path.exists():
        return notification_path.read_text(encoding="utf-8")
    return _HTML_HEADER + _HTML_FOOTER


def _write(notification_path: Path, content: str) -> None:
    notification_path.parent.mkdir(parents=True, exist_ok=True)
    notification_path.write_text(content, encoding="utf-8")


def append_pending(
    notification_path: Path,
    *,
    video_id: str,
    title: str,
    category: str | None = None,
    recording_date: str | None = None,
) -> None:
    """Trägt einen „wird publiziert…"-Eintrag ganz oben ein.

    Wenn bereits ein Eintrag mit dieser ``video_id`` existiert, wird er ersetzt
    (vermeidet Duplikate bei Republish).
    """
    entry = _render_entry(
        video_id=video_id,
        css_class="pending",
        title=title,
        category=category,
        recording_date=recording_date,
    )
    content = _read_or_init(notification_path)

    # Falls schon vorhanden: in-place ersetzen, statt zusätzlichen Block einzufügen
    pattern = _entry_pattern(video_id)
    if pattern.search(content):
        content = pattern.sub(entry, content, count=1)
    else:
        content = _insert_at_top(content, entry)

    _write(notification_path, content)


def replace_entry_published(
    notification_path: Path,
    *,
    video_id: str,
    title: str,
    video_url: str | None = None,
    category: str | None = None,
    recording_date: str | None = None,
) -> None:
    """Ersetzt einen bestehenden Eintrag mit der „publiziert"-Variante.

    Fällt auf Einfügen zurück, wenn der Eintrag noch nicht existiert (z.B. wenn
    die Benachrichtigungsdatei zwischen Start und Abschluss gelöscht wurde).
    """
    entry = _render_entry(
        video_id=video_id,
        css_class="published",
        title=title,
        video_url=video_url,
        category=category,
        recording_date=recording_date,
    )
    content = _read_or_init(notification_path)
    pattern = _entry_pattern(video_id)
    if pattern.search(content):
        content = pattern.sub(entry, content, count=1)
    else:
        content = _insert_at_top(content, entry)
    _write(notification_path, content)


def replace_entry_failed(
    notification_path: Path,
    *,
    video_id: str,
    title: str,
    error_message: str,
    category: str | None = None,
    recording_date: str | None = None,
) -> None:
    """Ersetzt einen bestehenden Eintrag mit der „Fehler"-Variante."""
    entry = _render_entry(
        video_id=video_id,
        css_class="failed",
        title=title,
        category=category,
        recording_date=recording_date,
        error_message=error_message,
    )
    content = _read_or_init(notification_path)
    pattern = _entry_pattern(video_id)
    if pattern.search(content):
        content = pattern.sub(entry, content, count=1)
    else:
        content = _insert_at_top(content, entry)
    _write(notification_path, content)


def mark_all_pending_as_aborted(notification_path: Path) -> int:
    """Setzt alle noch-offenen ``entry pending``-Blöcke auf ``entry aborted``.

    Vorgesehen für den Start eines Watch-Prozesses: wenn beim letzten Lauf ein
    Publish mitten drin abgebrochen wurde, bleibt sonst ein pending-Block ewig
    stehen. Gibt die Anzahl der geänderten Einträge zurück.
    """
    if not notification_path.exists():
        return 0
    content = notification_path.read_text(encoding="utf-8")
    pattern = re.compile(r'<div class="entry pending"', re.DOTALL)
    new_content, count = pattern.subn('<div class="entry aborted"', content)
    if count:
        _write(notification_path, new_content)
    return count
