"""Web-Deployment: Web-ID-Verzeichnis via rclone zum Webserver kopieren."""

from __future__ import annotations

import subprocess
from pathlib import Path

from familienfilm_manager.api.models import (
    DeployResult,
    FamilienfilmEvent,
    FamilienfilmStage,
)
from familienfilm_manager.core._rclone import (
    run_rclone_with_retry,
    verify_rclone_target_contains,
)


def deploy_to_web(
    source_dir: Path,
    web_target: str,
    rclone_path: str = "rclone",
    on_event=None,
) -> DeployResult:
    """Kopiert das Web-Medienset-Verzeichnis via rclone zum Webserver.

    Args:
        source_dir: Pfad zum Web-ID-Verzeichnis (vom WebProfile erstellt).
        web_target: rclone-Ziel für den Webserver.
        rclone_path: Pfad zur rclone-Binärdatei.
        on_event: Optionaler Event-Callback.

    Returns:
        DeployResult mit Erfolg/Fehler.
    """
    if not web_target:
        return DeployResult(
            success=False,
            error_message="Kein Web-Ziel konfiguriert (targets.web).",
        )

    if not source_dir.exists():
        return DeployResult(
            success=False,
            error_message=f"Quellverzeichnis nicht gefunden: {source_dir}",
        )

    web_id_name = source_dir.name
    target_dir = f"{web_target.rstrip('/')}/{web_id_name}"

    def _on_retry(attempt: int, max_attempts: int, exc: Exception) -> None:
        if on_event:
            stderr = getattr(exc, "stderr", "") or str(exc)
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.DEPLOY_RETRY,
                message=(
                    f"Web-Deployment fehlgeschlagen (Versuch {attempt}/{max_attempts}), "
                    f"retry: {stderr.strip().splitlines()[-1] if stderr.strip() else exc}"
                ),
            ))

    try:
        run_rclone_with_retry(
            [rclone_path, "copy", str(source_dir), target_dir],
            on_retry=_on_retry,
        )
    except subprocess.CalledProcessError as e:
        msg = f"Web-Deployment fehlgeschlagen: {e.stderr or e}"
        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.DEPLOY_FAILED,
                message=msg,
            ))
        return DeployResult(success=False, error_message=msg)
    except Exception as e:
        msg = f"Web-Deployment fehlgeschlagen: {e}"
        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.DEPLOY_FAILED,
                message=msg,
            ))
        return DeployResult(success=False, error_message=msg)

    if on_event:
        on_event(FamilienfilmEvent(
            stage_id=FamilienfilmStage.WEB_DEPLOYED,
            message=f"Web-Deployment: {web_id_name} → {target_dir}",
        ))

    # Post-Deploy Health-Check: das Web-ID-Verzeichnis muss auf dem Server da sein.
    # Wir prüfen gegen das übergeordnete Verzeichnis (parent), um nach dem web_id_name
    # als Eintrag zu suchen.
    parent_target = web_target.rstrip("/")
    ok, missing = verify_rclone_target_contains(
        parent_target, [web_id_name], rclone_path=rclone_path,
    )
    if not ok:
        msg = (
            f"Web-Deployment ist laut rclone erfolgreich, aber der Health-Check "
            f"findet das Verzeichnis '{web_id_name}' nicht in {parent_target}."
        )
        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.DEPLOY_FAILED,
                message=msg,
            ))
        return DeployResult(success=False, target_path=target_dir, error_message=msg)
    if on_event:
        on_event(FamilienfilmEvent(
            stage_id=FamilienfilmStage.DEPLOYMENT_VERIFIED,
            message=f"Web-Deployment verifiziert: {web_id_name} im Ziel vorhanden",
        ))

    return DeployResult(success=True, target_path=target_dir)
