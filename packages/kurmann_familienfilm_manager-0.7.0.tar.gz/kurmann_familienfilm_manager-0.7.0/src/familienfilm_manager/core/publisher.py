"""Hauptorchestrator: Metadaten → Sidecar → Medienset → Deploy → Archiv."""

from __future__ import annotations

import re
import shutil
import tempfile
from datetime import datetime
from pathlib import Path

from mediaset_creator.api import (
    CreateMediasetRequest,
    InfuseProfile,
    MediasetCreatorEvent,
    MediasetCreatorStage,
    PosterSpec,
    RuntimeOptions as MediasetRuntimeOptions,
    WebProfile,
    create_mediaset,
)

from familienfilm_manager.api.models import (
    FamilienfilmEvent,
    FamilienfilmStage,
    PublishRequest,
    PublishResult,
    RuntimeOptions,
)
from familienfilm_manager.core.archiver import archive_video
from familienfilm_manager.core.infuse_deployer import deploy_to_infuse
from familienfilm_manager.core.metadata_extractor import extract_metadata
from familienfilm_manager.core.sidecar_manager import (
    SidecarSettings,
    compute_source_fingerprint,
    read_sidecar,
    sidecar_path_for,
    write_sidecar,
)
from familienfilm_manager.core.source_ref import SourceRef
from familienfilm_manager.core.source_staging import stage_source
from familienfilm_manager.core.web_deployer import deploy_to_web
from familienfilm_manager.services import config_manager

# Gleiche Regex wie in metadata_extractor für Datumspräfix-Erkennung
_DATE_PREFIX_RE = re.compile(r"^(\d{4}-\d{2}-\d{2})\s*[-–]?\s*(.+)$")


def _create_title_symlink(source_path: Path, title: str) -> Path | None:
    """Erstellt einen Symlink ohne Datumspräfix im gleichen Verzeichnis.

    Wenn der Dateiname bereits ein Datumspräfix hat (z.B. "2025-03-24 Wanderung auf den Napf.mov"),
    wird ein Symlink "Wanderung auf den Napf.mov" erstellt. So generiert der mediaset-creator
    saubere Dateinamen im ZIP (ohne doppeltes Datum).

    Returns:
        Pfad zum Symlink oder None wenn kein Symlink nötig war.
    """
    stem = source_path.stem
    match = _DATE_PREFIX_RE.match(stem)
    if not match:
        return None

    link_name = f"{title}{source_path.suffix}"
    link_path = source_path.parent / link_name

    if link_path.exists():
        return None

    try:
        link_path.symlink_to(source_path.resolve())
        return link_path
    except OSError:
        return None


def run_publish(
    request: PublishRequest,
    runtime: RuntimeOptions | None = None,
    on_event=None,
) -> PublishResult:
    """Führt den gesamten Veröffentlichungs-Workflow aus.

    1. Metadaten extrahieren (oder CLI-Werte nutzen)
    2. Sidecar lesen/schreiben (Poster-Einstellungen)
    3. Symlink ohne Datumspräfix erstellen (für saubere Dateinamen)
    4. Medienset via mediaset-creator erstellen (mit Event-basiertem Deployment)
       - INFUSE_READY → sofort Infuse-Deployment via rclone
       - WEB_READY → sofort Web-Deployment via rclone
    5. Optional: Archivierung (immer mit Originaldatei)

    Args:
        request: Fachlicher Publish-Request.
        runtime: Technische Laufzeitoptionen.
        on_event: Optionaler Event-Callback.

    Returns:
        PublishResult mit Gesamtergebnis.
    """
    rt = runtime or RuntimeOptions()

    # --- 0. Pre-Validation: aktive Profile brauchen konfigurierte Targets ---
    missing_targets: list[str] = []
    if not request.skip_infuse and not rt.infuse_target:
        missing_targets.append("targets.infuse (oder --no-infuse zum Überspringen)")
    if not request.skip_web and not rt.web_target:
        missing_targets.append("targets.web (oder --no-web zum Überspringen)")
    if not request.skip_archive and not rt.archive_target:
        missing_targets.append("targets.archive (oder --no-archive zum Überspringen)")
    if missing_targets:
        return PublishResult(
            success=False,
            error_message=(
                "Konfigurations-Fehler: Folgende Targets sind nicht konfiguriert: "
                + ", ".join(missing_targets)
            ),
        )

    # --- 1. Staging: für rclone-Quellen wird das Video lokal gestaged ---
    # Für lokale Pfade ist stage_source ein Passthrough (kein Kopieren).
    # Für rclone-URIs wird das Video und alle stem-identischen Sidecars
    # via rclone copyto ins work_dir geholt — der Rest des Publishers läuft
    # unverändert auf dem lokalen Pfad.
    source_ref = request.get_source_ref()
    try:
        staged = stage_source(source_ref, request.work_dir, rt, on_event=on_event)
    except Exception as e:
        return PublishResult(
            success=False,
            error_message=f"Quelle konnte nicht gestaged werden: {e}",
        )

    # ab jetzt arbeiten wir durchgängig mit dem lokalen Pfad — entweder Original
    # (lokale Quelle) oder Staging-Kopie (rclone-Quelle)
    local_source_path: Path = staged.local_video_path

    # --- 2. Metadaten extrahieren ---
    try:
        metadata = extract_metadata(local_source_path, rt.ffprobe_path)
    except ValueError as e:
        if request.recording_date is None:
            staged.cleanup()
            return PublishResult(success=False, error_message=str(e))
        from familienfilm_manager.core.metadata_extractor import VideoMetadata, _parse_filename
        # Fallback: Filename parsen damit Poster-Suffix nicht im Titel landet
        _, fallback_title, fallback_poster_at = _parse_filename(local_source_path.stem)
        metadata = VideoMetadata(
            title=request.title or fallback_title,
            recording_date=request.recording_date,
            description=request.description,
            category=request.category,
            poster_at=fallback_poster_at,
        )

    # Sidecar früh lesen — wird für die Category-Auflösung gebraucht
    # (Sidecar-Metadaten haben Vorrang vor Config-Defaults, damit aus dem Archiv
    # extrahierte Videos ihre ursprüngliche Kategorie behalten).
    sidecar_enabled = (
        not request.no_sidecar
        and config_manager.get_with_default("sidecar.enabled").lower() != "false"
    )
    sidecar = SidecarSettings()
    if sidecar_enabled:
        sidecar = read_sidecar(local_source_path)

    # CLI-Parameter überschreiben extrahierte Werte
    title = request.title or metadata.title
    recording_date = request.recording_date or metadata.recording_date
    description = request.description or metadata.description

    # Verzeichnis-Settings (familienfilm.toml) nach oben suchen — eine in einem
    # höheren Verzeichnis gültige Datei dient als Default für alle Videos darunter.
    # Bei Batch-Läufen (publish-dir/watch-dir) begrenzt scan_root die Suche.
    # Für rclone-Quellen wird die Kette am Original-URI entlang gesucht (via
    # rclone cat), NICHT am lokalen Stage-Pfad.
    from familienfilm_manager.core.directory_settings import find_directory_settings

    directory_settings = find_directory_settings(
        start=source_ref.parent_uri(),
        stop_at=request.scan_root,
        rclone_path=rt.rclone_path,
    )

    # Category-Auflösungskette:
    #   1. CLI/Request (expliziter Wille)
    #   2. Sidecar-[metadata].category (selbsttragend, Re-Publish aus Archiv)
    #   3. familienfilm.toml (nächstgelegenes Verzeichnis nach oben)
    #   4. defaults.category aus Config (globaler Fallback)
    #   5. ffprobe-Metadata
    category = (
        request.category
        or (sidecar.category if sidecar_enabled else None)
        or directory_settings.category
        or config_manager.get("defaults.category")
        or metadata.category
    )

    if on_event:
        on_event(FamilienfilmEvent(
            stage_id=FamilienfilmStage.METADATA_EXTRACTED,
            message=f"Metadaten: {title} ({recording_date})",
        ))

    # --- Benachrichtigung: Pending-Block schreiben, sobald wir den Titel kennen ---
    # Der Block wird am Ende durch "publiziert" oder "fehlgeschlagen" ersetzt.
    # Bei Prozess-Crashes bleibt er als pending stehen — ein Watch-Start setzt
    # solche Altlasten via mark_all_pending_as_aborted() auf "abgebrochen".
    notification_file = config_manager.get("notification.file")
    video_id: str | None = None
    pending_title = title or local_source_path.stem
    if notification_file:
        from familienfilm_manager.core.notifier import (
            append_pending,
            derive_video_id,
        )

        # video_id basiert auf dem Original-URI (stabil über Staging hinweg)
        video_id = derive_video_id(source_ref.uri)
        append_pending(
            notification_path=Path(notification_file),
            video_id=video_id,
            title=pending_title,
            category=category,
            recording_date=recording_date,
        )

    def _resolve_notification_failed(error_message: str) -> None:
        if notification_file and video_id:
            from familienfilm_manager.core.notifier import replace_entry_failed

            replace_entry_failed(
                notification_path=Path(notification_file),
                video_id=video_id,
                title=pending_title,
                error_message=error_message,
                category=category,
                recording_date=recording_date,
            )

    # --- 2. Poster-/Web-/Luminance-Werte aus Sidecar auflösen, ggf. Sidecar aktualisieren ---
    # (Sidecar wurde bereits oben für die Category-Auflösung gelesen.)

    # Poster-Werte auflösen: CLI > Filename-Suffix > Sidecar
    # poster_at kann zusätzlich aus dem Dateinamen-Suffix " poster-Xmin Y" stammen
    filename_poster_at = metadata.poster_at
    poster_frame = request.poster_frame or sidecar.frame_number
    poster_at = request.poster_at or filename_poster_at or sidecar.timestamp_seconds
    poster_crop = request.poster_crop or sidecar.crop_position

    # Web-ID auflösen: CLI > Sidecar
    web_id = request.web_id or sidecar.web_id

    # max_luminance auflösen: CLI > Sidecar
    max_luminance = request.max_luminance or sidecar.max_luminance

    # Sidecar aktualisieren wenn CLI oder Filename neue Werte liefert
    cli_has_poster = any(v is not None for v in (request.poster_frame, request.poster_at, request.poster_crop))
    filename_has_new_poster_at = (
        filename_poster_at is not None
        and filename_poster_at != sidecar.timestamp_seconds
    )
    cli_has_updates = cli_has_poster or request.max_luminance is not None or filename_has_new_poster_at
    if sidecar_enabled and cli_has_updates:
        updated = SidecarSettings(
            frame_number=poster_frame,
            timestamp_seconds=poster_at,
            crop_position=poster_crop,
            web_id=web_id,
            max_luminance=max_luminance,
        )
        if updated.has_values():
            write_sidecar(local_source_path, updated)

    # --- 3. Symlink ohne Datumspräfix für mediaset-creator ---
    # Bei rclone-Quellen arbeiten wir im Stage-Dir — Symlink dort funktioniert
    # normal. Das saubere Umbenennen kommt im mediaset-creator-Output an.
    title_symlink = _create_title_symlink(local_source_path, title)
    mediaset_source = title_symlink or local_source_path

    # --- 4. Profile und Request aufbauen ---
    # PosterSpec erstellen wenn Poster-Parameter vorhanden
    poster = None
    if any(v is not None for v in (poster_frame, poster_at, poster_crop)):
        poster = PosterSpec(
            frame_number=poster_frame,
            timestamp_seconds=poster_at,
            crop_position=poster_crop,
        )

    # Basisverzeichnis für temporäre Ausgaben: work_dir > lokales Quellverzeichnis.
    # Bei gestageder Quelle ist local_source_path.parent das Stage-Dir — dort landen
    # Infuse-/Web-Tmp-Dirs als Geschwister, was beim Cleanup automatisch mit aufgeräumt wird.
    base_dir = request.work_dir or local_source_path.parent

    # Infuse-Profil: Arbeitsverzeichnis neben der Quelle, wird nach rclone aufgeräumt
    infuse_tmp_dir: Path | None = None
    infuse_profile: InfuseProfile | None = None
    if not request.skip_infuse and rt.infuse_target:
        infuse_tmp_dir = Path(tempfile.mkdtemp(prefix="familienfilm-infuse-", dir=base_dir))
        infuse_profile = InfuseProfile(output_dir=infuse_tmp_dir)

    # Web-Profil: Web-ID-Unterverzeichnis wird automatisch erstellt
    # Merken ob Verzeichnis temporär (selbst erstellt) oder explizit (--output-dir) ist —
    # nur temporäre werden nach erfolgreichem Deployment aufgeräumt.
    web_profile: WebProfile | None = None
    web_tmp_dir: Path | None = None
    if not request.skip_web:
        if request.output_dir:
            web_output = request.output_dir
        else:
            web_tmp_dir = Path(tempfile.mkdtemp(prefix="familienfilm-web-", dir=base_dir))
            web_output = web_tmp_dir
        web_profile = WebProfile(
            output_dir=web_output,
            include_zip=True,
            enable_og_tags=bool(rt.branding_base_url),
        )

    # Mindestens ein Profil muss aktiv sein
    if infuse_profile is None and web_profile is None:
        msg = "Mindestens ein Profil (Infuse oder Web) muss aktiv sein."
        _resolve_notification_failed(msg)
        return PublishResult(success=False, error_message=msg)

    mediaset_request = CreateMediasetRequest(
        source_path=mediaset_source,
        title=title,
        description=description,
        category=category,
        recording_date=recording_date,
        poster=poster,
        mediaset_title=title,
        work_dir=request.work_dir,
        infuse=infuse_profile,
        web=web_profile,
        web_id=web_id,
        max_luminance=request.max_luminance,
        force=request.force,
    )

    mediaset_runtime = MediasetRuntimeOptions(
        base_url=rt.branding_base_url,
        ffmpeg_path=rt.ffmpeg_path,
        ffprobe_path=rt.ffprobe_path,
    )

    # Result-Objekt, das im Callback befüllt wird
    result = PublishResult(success=True)

    # Per-Kanal Zeitstempel beim jeweils erfolgreichen Deploy — fliesst am Ende
    # ins Sidecar als [web]/[local]/[archive].published_at. Fehlgeschlagene Kanäle
    # bleiben None → beim nächsten Lauf erkennt der Skip-Check den Teilerfolg
    # und holt den fehlenden Kanal nach.
    channel_timestamps: dict[str, str | None] = {
        "web": None,
        "local": None,
        "archive": None,
    }

    def _now_iso() -> str:
        return datetime.now().isoformat(timespec="seconds")

    # Event-Callback mit integriertem Deployment
    # Mutable Flag für den finally-Block: unterscheidet "Deploy nie versucht"
    # (Mediaset-Fehler vor INFUSE_READY → Temp aufräumen) von "Deploy versucht,
    # fehlgeschlagen" (Medienset fertig aufgebaut → erhalten für Nachholen).
    infuse_deploy_attempted = [False]

    def _handle_mediaset_event(event: MediasetCreatorEvent) -> None:
        # Events an den Familienfilm-Manager durchreichen
        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=event.stage_id,
                message=event.message,
                paths=event.paths,
            ))

        # Auf Milestone-Events reagieren → sofort deployen
        if event.stage_id == MediasetCreatorStage.INFUSE_READY and rt.infuse_target:
            infuse_deploy_attempted[0] = True
            deploy_result = deploy_to_infuse(
                source_dir=Path(event.paths["output_dir"]),
                infuse_target=rt.infuse_target,
                rclone_path=rt.rclone_path,
                recording_date=recording_date,
                group_by=rt.infuse_group_by,
                on_event=on_event,
            )
            result.infuse_deployed = deploy_result.success
            if deploy_result.success:
                channel_timestamps["local"] = _now_iso()
            else:
                result.error_message = deploy_result.error_message

        elif event.stage_id == MediasetCreatorStage.WEB_READY and rt.web_target:
            deploy_result = deploy_to_web(
                source_dir=Path(event.paths["output_dir"]),
                web_target=rt.web_target,
                rclone_path=rt.rclone_path,
                on_event=on_event,
            )
            result.web_deployed = deploy_result.success
            if deploy_result.success:
                channel_timestamps["web"] = _now_iso()
            else:
                result.error_message = deploy_result.error_message

    try:
        mediaset_result = create_mediaset(
            mediaset_request,
            mediaset_runtime,
            on_event=_handle_mediaset_event,
        )
    finally:
        # Symlink immer aufräumen
        if title_symlink and title_symlink.is_symlink():
            title_symlink.unlink()
        # Infuse-Temp-Verzeichnis:
        # - Deploy erfolgreich → aufräumen
        # - Deploy versucht und fehlgeschlagen → erhalten, Hinweis ausgeben
        # - Deploy nie versucht (Mediaset-Fehler vor INFUSE_READY) → aufräumen
        if infuse_tmp_dir:
            if result.infuse_deployed or not infuse_deploy_attempted[0]:
                shutil.rmtree(infuse_tmp_dir, ignore_errors=True)
            elif on_event:
                on_event(FamilienfilmEvent(
                    stage_id=FamilienfilmStage.DEPLOY_FAILED,
                    message=(
                        f"Infuse-Medienset erhalten für manuelles Nachdeployment: "
                        f"{infuse_tmp_dir}\n"
                        f"  Retry: familienfilm-manager deploy-infuse '{infuse_tmp_dir}'"
                    ),
                ))

    if not mediaset_result.success:
        msg = f"Medienset-Erstellung fehlgeschlagen: {mediaset_result.error_message}"
        _resolve_notification_failed(msg)
        return PublishResult(success=False, error_message=msg)

    # Result-Felder aus dem Mediaset-Result befüllen
    if mediaset_result.infuse:
        result.infuse_dir = mediaset_result.infuse.output_dir
    if mediaset_result.web:
        result.web_dir = mediaset_result.web.output_dir
        result.web_id = mediaset_result.web.web_id

    if on_event:
        on_event(FamilienfilmEvent(
            stage_id=FamilienfilmStage.MEDIASET_CREATED,
            message=f"Medienset erstellt: {result.web_dir or result.infuse_dir}",
        ))

    # --- 5. Archivierung (immer mit Originaldatei, nicht Symlink) ---
    # Der Archiver packt die lokale Quelldatei (bei rclone-Quelle: Stage-Kopie) +
    # alle stem-identischen Produktions-Sidecars ins TAR. Die .settings.toml geht
    # separat neben das TAR — Zeitstempel dafür wird nach dem finalen
    # Sidecar-Write gesetzt, damit im Archiv die vollständige Sidecar liegt.
    if not request.skip_archive and rt.archive_target:
        archive_result = archive_video(
            source_path=local_source_path,
            archive_target=rt.archive_target,
            rclone_path=rt.rclone_path,
            recording_date=recording_date,
            title=title,
            work_dir=request.work_dir,
            on_event=on_event,
        )
        result.archived = archive_result.success
        if archive_result.success:
            channel_timestamps["archive"] = _now_iso()
        else:
            result.error_message = archive_result.error_message

    # --- 5b. Sidecar finalisieren — ein Write mit allen per-Kanal Zeitstempeln ---
    if sidecar_enabled and (mediaset_result.web or mediaset_result.infuse):
        try:
            source_size, source_head = compute_source_fingerprint(local_source_path)
        except OSError:
            source_size, source_head = None, None

        updated = SidecarSettings(
            frame_number=poster_frame,
            timestamp_seconds=poster_at,
            crop_position=poster_crop,
            web_id=result.web_id,
            max_luminance=max_luminance,
            web_published_at=channel_timestamps["web"],
            local_published_at=channel_timestamps["local"],
            archive_published_at=channel_timestamps["archive"],
            source_size_bytes=source_size,
            source_head_sha1=source_head,
            category=category,
        )
        local_sidecar = write_sidecar(local_source_path, updated)

        # Bei rclone-Quelle: aktualisierte Sidecar zurück an die Original-Location.
        # Für lokale Quellen ist sync_sidecar_back ein No-Op (das Sidecar liegt
        # bereits neben dem Original).
        try:
            staged.sync_sidecar_back(local_sidecar, rt, on_event=on_event)
        except Exception as e:
            # Sidecar-Rücksync-Fehler ist nicht tödlich — Publish war erfolgreich.
            # Wir loggen, aber belassen den Erfolgs-Status.
            if on_event:
                on_event(FamilienfilmEvent(
                    stage_id=FamilienfilmStage.DEPLOY_FAILED,
                    message=(
                        f"Sidecar-Rücksync zur Quelle fehlgeschlagen: {e}\n"
                        f"  Lokale Kopie unter {local_sidecar} — manuell sichern wenn gewollt."
                    ),
                ))

    # --- 6. Web-URL und Benachrichtigung ---
    if result.web_id and rt.branding_base_url:
        base = rt.branding_base_url.rstrip("/")
        result.web_url = f"{base}/{result.web_id}/"

    # Pending-Eintrag in der Benachrichtigungsdatei durch finales Ergebnis ersetzen.
    if notification_file and video_id:
        from familienfilm_manager.core.notifier import (
            replace_entry_failed,
            replace_entry_published,
        )

        if result.error_message and not result.web_deployed and not result.infuse_deployed:
            replace_entry_failed(
                notification_path=Path(notification_file),
                video_id=video_id,
                title=pending_title,
                error_message=result.error_message,
                category=category,
                recording_date=recording_date,
            )
        else:
            replace_entry_published(
                notification_path=Path(notification_file),
                video_id=video_id,
                title=pending_title,
                video_url=result.web_url,
                category=category,
                recording_date=recording_date,
            )
        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.PUBLISH_COMPLETED,
                message=f"Benachrichtigung aktualisiert: {notification_file}",
            ))

    # --- 7. Web-Arbeitsverzeichnis aufräumen (wenn temporär + Web-Deployment erfolgreich) ---
    cleanup_enabled = config_manager.get_with_default("cleanup.web_workdir").lower() != "false"
    if cleanup_enabled and web_tmp_dir and result.web_deployed:
        shutil.rmtree(web_tmp_dir, ignore_errors=True)
        # web_dir im Result auf None setzen, da das Verzeichnis nicht mehr existiert
        result.web_dir = None
        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.PUBLISH_COMPLETED,
                message=f"Arbeitsverzeichnis aufgeräumt: {web_tmp_dir}",
            ))

    # Staging-Verzeichnis aufräumen (rclone-Quelle). Für lokale Quellen: No-Op.
    staged.cleanup()

    if on_event:
        if result.web_url:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.PUBLISH_COMPLETED,
                message=f"Video erreichbar unter: {result.web_url}",
            ))
        on_event(FamilienfilmEvent(
            stage_id=FamilienfilmStage.PUBLISH_COMPLETED,
            message=f"Veröffentlichung abgeschlossen: {source_ref.name}",
        ))

    return result
