"""Staging-Schicht: übersetzt rclone-Quellen in lokale Pfade.

Für lokale Quellen ist ``stage_source()`` ein Passthrough — der Publisher
läuft direkt auf dem Original. Für rclone-Quellen wird das Video (plus
Sidecar und ggf. weitere stem-identische Sidecars wie ``.fcpxml``) in
ein temporäres Unterverzeichnis des ``work_dir`` kopiert. Nach dem
Publish synct die Instanz das aktualisierte Sidecar zurück an die
Original-Location und räumt das Staging-Verzeichnis auf.

Warum existiert das Modul?
    Ein aktiver SMB-Mount zur Quelle blockiert parallele SFTP-Verbindungen
    zum selben NAS (diagnostiziert in v0.6.0). Mit rclone für beide
    Richtungen (lesen via Staging + schreiben zu den Deploy-Zielen) ist
    kein SMB-Mount mehr nötig und das Problem ist vermieden.
"""

from __future__ import annotations

import shutil
import uuid
from dataclasses import dataclass, field
from pathlib import Path

from familienfilm_manager.api.models import (
    FamilienfilmEvent,
    FamilienfilmStage,
    RuntimeOptions,
)
from familienfilm_manager.core._rclone import (
    rclone_copyto,
    rclone_lsjson,
)
from familienfilm_manager.core.source_ref import SourceRef

# Stem-identische Sidecar-Suffixe, die bei Quellen mitkopiert / erkannt werden.
# ``.settings.toml`` ist das Management-Sidecar (wird nach Publish zurückgesynct).
# Andere sind Produktions-Nebenmaterialien, die der Archiver ggf. ins TAR packt.
_SIDECAR_SUFFIXES: tuple[str, ...] = (
    ".settings.toml",
    ".fcpxml",
    ".lfpackage",
    ".lfarchive",
    "-fanart.jpg",
    "-poster.jpg",
    ".nfo",
)


def _is_sidecar_of(name: str, stem: str) -> bool:
    """True wenn ``name`` ein Sidecar zum Video mit gegebenem ``stem`` ist.

    Erlaubt sowohl das `.`-Delimiter-Pattern (``<stem>.settings.toml``) als
    auch `-`-Delimiter (``<stem>-fanart.jpg``). Sicher implementiert:
    nur bekannte Suffixe aus _SIDECAR_SUFFIXES werden akzeptiert, um
    Fehl-Assoziationen mit anderen Videos (z.B. ``2026-04-18 Test2.mov``)
    zu vermeiden.
    """
    return any(name == stem + suffix for suffix in _SIDECAR_SUFFIXES)


@dataclass
class StagedSource:
    """Ergebnis von ``stage_source``: lokaler Arbeitskopie-Zustand.

    Bei lokalen Quellen ist ``is_staged=False`` und ``local_video_path`` zeigt
    auf das Original — alle ``sync_sidecar_back``- und ``cleanup``-Aufrufe
    sind dann No-Ops (das Original liegt schon da, nichts wurde kopiert).

    Bei rclone-Quellen ist ``is_staged=True``, die Dateien liegen im
    ``_stage_dir`` unter dem ``work_dir``, und ``sync_sidecar_back`` lädt
    das aktualisierte Sidecar zurück zum Remote via ``rclone copyto``.
    """

    ref: SourceRef
    local_video_path: Path
    local_sidecar_path: Path | None = None
    extra_sidecars: list[Path] = field(default_factory=list)
    is_staged: bool = False
    _stage_dir: Path | None = None

    def sync_sidecar_back(
        self,
        local_sidecar: Path,
        runtime: RuntimeOptions | None = None,
        on_event=None,
    ) -> None:
        """Schreibt die aktualisierte Sidecar zurück an die Original-Location.

        Für lokale Quellen: No-Op (Sidecar wurde bereits neben der Original-
        Quelldatei geschrieben).

        Für rclone-Quellen: ``rclone copyto <local_sidecar> <original>/<stem>.settings.toml``.
        """
        if not self.is_staged:
            return
        if not local_sidecar.exists():
            return
        rt = runtime or RuntimeOptions()
        # Zielname: gleicher Stem wie die Original-Quelldatei + .settings.toml
        remote_sidecar_uri = self.ref.parent_uri().rstrip("/") + "/" + self.ref.stem + ".settings.toml"
        # parent_uri kann "nas:" oder "nas:/a/b" sein — "rstrip('/')" macht nichts kaputt
        if self.ref.parent_uri().endswith(":"):
            remote_sidecar_uri = self.ref.parent_uri() + self.ref.stem + ".settings.toml"

        def _on_retry(attempt: int, max_attempts: int, exc: Exception) -> None:
            if on_event:
                stderr = getattr(exc, "stderr", "") or str(exc)
                on_event(FamilienfilmEvent(
                    stage_id=FamilienfilmStage.DEPLOY_RETRY,
                    message=(
                        f"Sidecar-Rücksync fehlgeschlagen (Versuch {attempt}/{max_attempts}), "
                        f"retry: {stderr.strip().splitlines()[-1] if stderr.strip() else exc}"
                    ),
                ))

        rclone_copyto(
            str(local_sidecar),
            remote_sidecar_uri,
            rclone_path=rt.rclone_path,
            on_retry=_on_retry,
        )

    def cleanup(self) -> None:
        """Entfernt das Staging-Verzeichnis (nur wenn gestaged wurde)."""
        if self.is_staged and self._stage_dir is not None and self._stage_dir.exists():
            shutil.rmtree(self._stage_dir, ignore_errors=True)


def stage_source(
    ref: SourceRef,
    work_dir: Path | None,
    runtime: RuntimeOptions | None = None,
    on_event=None,
) -> StagedSource:
    """Bereitet eine Quelle für lokale Verarbeitung vor.

    Lokale Quellen werden direkt durchgereicht (Passthrough, kein Kopieren).
    rclone-Quellen werden ins ``work_dir`` kopiert — das Video und alle
    zugehörigen stem-identischen Sidecars.

    Args:
        ref: URI-basierte Referenz auf die Quelle.
        work_dir: Arbeitsverzeichnis, in dem Staging-Unterordner erzeugt
            werden. Bei rclone-Quellen **zwingend erforderlich**; lokale
            Quellen ignorieren den Parameter.
        runtime: Für ``rclone_path`` bei rclone-Quellen.
        on_event: Optionaler Event-Callback für Retry-Meldungen.

    Returns:
        ``StagedSource``-Objekt mit ``local_video_path`` fürs Lesen.

    Raises:
        ValueError: Wenn ``ref`` rclone ist, aber ``work_dir`` None ist.
    """
    rt = runtime or RuntimeOptions()

    # ── Lokale Quelle: Passthrough ──
    if not ref.is_rclone:
        local_video = ref.as_local_path()
        parent = local_video.parent
        sidecar_path = parent / f"{local_video.stem}.settings.toml"
        extras: list[Path] = []
        if parent.exists():
            for p in parent.iterdir():
                if p == local_video or p == sidecar_path:
                    continue
                if p.is_file() and _is_sidecar_of(p.name, local_video.stem):
                    extras.append(p)
        return StagedSource(
            ref=ref,
            local_video_path=local_video,
            local_sidecar_path=sidecar_path if sidecar_path.exists() else None,
            extra_sidecars=sorted(extras),
            is_staged=False,
            _stage_dir=None,
        )

    # ── rclone-Quelle: Staging via copyto ──
    if work_dir is None:
        raise ValueError(
            f"Rclone-Quelle {ref.uri!r} braucht ein work_dir zum Stagen. "
            "Setze paths.work_dir in der Config."
        )

    stage_dir = work_dir / f"stage-{uuid.uuid4().hex[:8]}"
    stage_dir.mkdir(parents=True, exist_ok=True)

    # Video kopieren
    local_video = stage_dir / ref.name
    rclone_copyto(ref.uri, str(local_video), rclone_path=rt.rclone_path)

    # Stem-identische Sidecars entdecken: lsjson im Parent, Name-Filter
    parent_uri = ref.parent_uri()
    try:
        entries = rclone_lsjson(parent_uri, rclone_path=rt.rclone_path)
    except Exception:
        entries = []

    sidecar_local: Path | None = None
    extras: list[Path] = []

    for entry in entries:
        if entry.get("IsDir"):
            continue
        name = entry.get("Name", "")
        if name == ref.name:
            continue  # Video selbst — schon kopiert
        if not _is_sidecar_of(name, ref.stem):
            continue

        child_uri = ref.parent_uri().rstrip("/")
        child_uri = f"{child_uri}/{name}" if not child_uri.endswith(":") else f"{child_uri}{name}"
        local_path = stage_dir / name
        try:
            rclone_copyto(child_uri, str(local_path), rclone_path=rt.rclone_path)
        except Exception:
            # Einzelne Sidecars sind optional — nicht den ganzen Publish abbrechen
            continue

        if name == ref.stem + ".settings.toml":
            sidecar_local = local_path
        else:
            extras.append(local_path)

    return StagedSource(
        ref=ref,
        local_video_path=local_video,
        local_sidecar_path=sidecar_local,
        extra_sidecars=sorted(extras),
        is_staged=True,
        _stage_dir=stage_dir,
    )
