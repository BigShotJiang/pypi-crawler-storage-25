"""Archivierung: TAR-Erstellung aus Originaldateien + Sidecars und rclone move zum Ziel."""

from __future__ import annotations

import re
import subprocess
import tarfile
import unicodedata
from pathlib import Path

from familienfilm_manager.api.models import (
    ArchiveResult,
    FamilienfilmEvent,
    FamilienfilmStage,
)
from familienfilm_manager.core._rclone import (
    run_rclone_with_retry,
    verify_rclone_target_contains,
)

# Deutsche Transliteration für ASCII-sichere Dateinamen
_GERMAN_TRANSLITERATION: dict[str, str] = {
    "ä": "ae", "ö": "oe", "ü": "ue", "ß": "ss",
    "Ä": "Ae", "Ö": "Oe", "Ü": "Ue",
}


def _to_ascii_slug(text: str) -> str:
    """Konvertiert einen Text in einen ASCII-sicheren Slug (Bindestriche statt Leerzeichen).

    Beispiel: "Leah gähnt im Bett" → "Leah-gaehnt-im-Bett"

    macOS speichert Dateinamen in NFD (z.B. "ä" = "a" + Combining Diaeresis).
    Daher zuerst nach NFC normalisieren, sonst greift die Transliteration nicht
    und Umlaute landen als nacktes "a"/"o"/"u" im Slug ("Madchen" statt "Maedchen").
    """
    # 1. NFC-Normalisierung (kombiniert Diakritika zu einem Code-Point)
    text = unicodedata.normalize("NFC", text)

    # 2. Deutsche Sonderzeichen transliterieren
    for char, replacement in _GERMAN_TRANSLITERATION.items():
        text = text.replace(char, replacement)

    # 3. Restliche Diakritika (z.B. é, à) auf ASCII reduzieren
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")

    # 4. Nicht-alphanumerische Zeichen durch Bindestriche ersetzen
    text = re.sub(r"[^a-zA-Z0-9]+", "-", text)

    # 5. Führende/abschliessende Bindestriche entfernen
    return text.strip("-")


def _collect_sidecar_files(source_path: Path) -> list[Path]:
    """Sammelt Sidecar-Dateien mit gleichem Stem (inkl. Compound-Extensions wie .settings.toml)."""
    stem = source_path.stem
    prefix = stem + "."
    parent = source_path.parent
    sidecars = []
    for f in parent.iterdir():
        if f == source_path:
            continue
        if f.is_file() and f.name.startswith(prefix):
            sidecars.append(f)
    return sorted(sidecars)


def _arcname(file_path: Path, source_stem: str, target_stem: str) -> str:
    """Berechnet den TAR-internen Dateinamen mit ersetztem Stem.

    Bewahrt mehrteilige Endungen (z.B. ``.settings.toml``), indem der
    Quell-Stem (vor dem ersten Punkt nach dem Stem) durch den Ziel-Stem
    ersetzt wird.

    Beispiele (source_stem="HDR-Test poster-1s200", target_stem="2026-04-16 HDR-Test"):
        "HDR-Test poster-1s200.mov"            → "2026-04-16 HDR-Test.mov"
        "HDR-Test poster-1s200.settings.toml"  → "2026-04-16 HDR-Test.settings.toml"
        "HDR-Test poster-1s200-poster.jpg"     → "2026-04-16 HDR-Test-poster.jpg"
    """
    name = file_path.name
    if name.startswith(source_stem):
        return target_stem + name[len(source_stem):]
    # Fallback: Original-Name behalten
    return name


def _create_tar(
    source_path: Path,
    sidecars: list[Path],
    tar_path: Path,
    target_stem: str | None = None,
) -> None:
    """Erstellt ein unkomprimiertes TAR-Archiv.

    Dateien werden ohne Verzeichnispfad gespeichert. Wenn target_stem gesetzt
    ist, wird der Stem aller Dateien ersetzt (z.B. für sauberen Namen ohne
    Filename-Suffixe wie ``poster-30s``). Mehrteilige Endungen
    (``.settings.toml``) werden dabei bewahrt.

    Keine Kompression, da Videodateien bereits komprimiert sind.
    """
    source_stem = source_path.stem
    with tarfile.open(tar_path, "w") as tf:
        for f in [source_path, *sidecars]:
            arcname = _arcname(f, source_stem, target_stem) if target_stem else f.name
            tf.add(f, arcname=arcname)


def _rclone_move(
    archive_path: Path,
    target: str,
    rclone_path: str,
    on_event=None,
) -> None:
    """Verschiebt die Archiv-Datei via rclone move zum Ziel (mit Retry-Backoff)."""

    def _on_retry(attempt: int, max_attempts: int, exc: Exception) -> None:
        if on_event:
            stderr = getattr(exc, "stderr", "") or str(exc)
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.DEPLOY_RETRY,
                message=(
                    f"Archivierung fehlgeschlagen (Versuch {attempt}/{max_attempts}), "
                    f"retry: {stderr.strip().splitlines()[-1] if stderr.strip() else exc}"
                ),
            ))

    run_rclone_with_retry(
        [rclone_path, "move", str(archive_path), target],
        on_retry=_on_retry,
    )


def _copy_settings_sidecar_to_archive(
    source_sidecar: Path,
    archive_target: str,
    dest_name: str,
    rclone_path: str,
    on_event=None,
) -> None:
    """Kopiert die ``.settings.toml`` NEBEN das TAR ins Archiv-Ziel.

    Ab v0.6.0 liegt die Settings-Datei nicht mehr IM TAR, sondern daneben —
    so sind Archiv-Metadaten (Kategorie, Publish-Timestamps) ohne Entpacken
    sichtbar, und ``[archive].published_at`` hat eine saubere Beziehung
    zum Archiv-Objekt (statt zirkulär im Archiv selbst zu liegen).

    Nutzt ``rclone copyto`` statt ``copy``, um die Datei direkt mit dem
    normalisierten Zielnamen (ASCII-Slug, wie das TAR) abzulegen.
    """

    def _on_retry(attempt: int, max_attempts: int, exc: Exception) -> None:
        if on_event:
            stderr = getattr(exc, "stderr", "") or str(exc)
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.DEPLOY_RETRY,
                message=(
                    f"Sidecar-Upload fehlgeschlagen (Versuch {attempt}/{max_attempts}), "
                    f"retry: {stderr.strip().splitlines()[-1] if stderr.strip() else exc}"
                ),
            ))

    dest_path = f"{archive_target.rstrip('/')}/{dest_name}"
    run_rclone_with_retry(
        [rclone_path, "copyto", str(source_sidecar), dest_path],
        on_retry=_on_retry,
    )


def archive_video(
    source_path: Path,
    archive_target: str,
    rclone_path: str = "rclone",
    recording_date: str | None = None,
    title: str | None = None,
    work_dir: Path | None = None,
    on_event=None,
) -> ArchiveResult:
    """Archiviert eine Videodatei als TAR und verschiebt sie zum Archiv-Ziel.

    **Ab v0.6.0**:
    - Das TAR wird im ``work_dir`` erstellt (wenn gesetzt), nicht mehr im
      Quellverzeichnis — hält SMB/NAS-Quellen sauber.
    - Die ``.settings.toml`` wird **nicht mehr ins TAR gepackt**, sondern
      separat neben das TAR ins Archiv kopiert (als ``<slug>.settings.toml``).
      Vorteile: Archiv-Metadaten sichtbar ohne TAR zu öffnen, und der Archiv-
      Publish-Zeitstempel (``[archive].published_at``) hat eine saubere
      Beziehung zum Archiv-Objekt.
    - Andere Sidecar-Typen (z.B. ``.lfpackage``, ``.fcpxml``) bleiben weiterhin
      im TAR — das sind Produktions-/Video-Nebenmaterialien.

    Args:
        source_path: Pfad zur Originaldatei.
        archive_target: rclone-Ziel (z.B. nas:/archive/familienfilme/).
        rclone_path: Pfad zur rclone-Binärdatei.
        recording_date: ISO-Datum für den Archiv-Dateinamen.
        title: Titel für den Archiv-Dateinamen.
        work_dir: Arbeitsverzeichnis für die TAR-Erstellung. Standard (None):
            Quellverzeichnis der Videodatei — rückwärtskompatibel.
        on_event: Optionaler Event-Callback.

    Returns:
        ArchiveResult mit Erfolg/Fehler.
    """
    if not archive_target:
        return ArchiveResult(
            success=False,
            error_message="Kein Archiv-Ziel konfiguriert (targets.archive).",
        )

    if not source_path.exists():
        return ArchiveResult(
            success=False,
            error_message=f"Quelldatei nicht gefunden: {source_path}",
        )

    try:
        all_sidecars = _collect_sidecar_files(source_path)
        # .settings.toml wird separat behandelt — nicht ins TAR
        settings_sidecar = next(
            (s for s in all_sidecars if s.name.endswith(".settings.toml")), None,
        )
        tar_sidecars = [s for s in all_sidecars if not s.name.endswith(".settings.toml")]

        # Archiv-Dateiname aus Datum + Titel ableiten (ASCII-sicher)
        # TAR-interner Stem: Datum + Titel im Original-Stil (mit Leerzeichen, Umlauten),
        # ohne Filename-Suffixe wie "poster-30s" — Infuse-/Mensch-freundlich.
        if title and recording_date:
            slug = _to_ascii_slug(title)
            archive_name = f"{recording_date}-{slug}.tar"
            internal_stem = f"{recording_date} {title}"
        elif recording_date:
            slug = _to_ascii_slug(source_path.stem)
            archive_name = f"{recording_date}-{slug}.tar"
            internal_stem = f"{recording_date} {source_path.stem}"
        else:
            slug = _to_ascii_slug(source_path.stem)
            archive_name = f"{slug}.tar"
            internal_stem = source_path.stem

        # Fallback wenn Slug leer ist
        if not slug:
            slug = "archive"
            archive_name = f"{recording_date}-{slug}.tar" if recording_date else f"{slug}.tar"

        # TAR im work_dir erstellen, sonst im Quellverzeichnis (rückwärtskompatibel).
        # Wichtig: bei SMB/NAS-Quellen vermeidet das die Schreiblast auf dem Share
        # und reduziert SMB-Sync-Delays vor dem rclone move.
        if work_dir is not None:
            work_dir.mkdir(parents=True, exist_ok=True)
            archive_path = work_dir / archive_name
        else:
            archive_path = source_path.parent / archive_name

        _create_tar(source_path, tar_sidecars, archive_path, target_stem=internal_stem)

        _rclone_move(archive_path, archive_target, rclone_path, on_event=on_event)

        # Settings-Sidecar separat neben das TAR kopieren (wenn vorhanden).
        sidecar_archive_name: str | None = None
        if settings_sidecar is not None:
            sidecar_archive_name = f"{archive_path.stem}.settings.toml"
            _copy_settings_sidecar_to_archive(
                settings_sidecar,
                archive_target,
                sidecar_archive_name,
                rclone_path,
                on_event=on_event,
            )

        if on_event:
            info_parts = []
            if tar_sidecars:
                info_parts.append(f"{len(tar_sidecars)} Sidecar(s) im TAR")
            if sidecar_archive_name:
                info_parts.append(f"{sidecar_archive_name} daneben")
            extra = (" + " + " + ".join(info_parts)) if info_parts else ""
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.ARCHIVED,
                message=f"Archiviert: {archive_name}{extra} → {archive_target}",
            ))

        # Post-Deploy Health-Check: TAR (und ggf. Sidecar) müssen im Ziel sein.
        expected_names = [archive_name]
        if sidecar_archive_name:
            expected_names.append(sidecar_archive_name)
        ok, missing = verify_rclone_target_contains(
            archive_target, expected_names, rclone_path=rclone_path,
        )
        if not ok:
            msg = (
                f"Archivierung ist laut rclone erfolgreich, aber der Health-Check "
                f"findet {', '.join(missing)} nicht im Ziel {archive_target}."
            )
            if on_event:
                on_event(FamilienfilmEvent(
                    stage_id=FamilienfilmStage.DEPLOY_FAILED,
                    message=msg,
                ))
            return ArchiveResult(success=False, archive_path=archive_path, error_message=msg)
        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.DEPLOYMENT_VERIFIED,
                message=f"Archivierung verifiziert: {archive_name} im Ziel vorhanden",
            ))

        return ArchiveResult(success=True, archive_path=archive_path)

    except subprocess.CalledProcessError as e:
        msg = f"Archivierung fehlgeschlagen: {e.stderr or e}"
        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.DEPLOY_FAILED,
                message=(
                    f"{msg}\n  TAR erhalten für manuelle Archivierung: {archive_path}\n"
                    f"  Retry: rclone move '{archive_path}' '{archive_target}'"
                ),
            ))
        return ArchiveResult(success=False, error_message=msg, archive_path=archive_path)
    except Exception as e:
        msg = f"Archivierung fehlgeschlagen: {e}"
        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.DEPLOY_FAILED,
                message=msg,
            ))
        return ArchiveResult(success=False, error_message=msg)
