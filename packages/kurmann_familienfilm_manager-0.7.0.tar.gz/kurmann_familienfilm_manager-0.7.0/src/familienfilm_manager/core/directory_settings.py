"""Verzeichnis-Settings (``familienfilm.toml``) mit Vererbung.

Eine ``familienfilm.toml`` in einem Verzeichnis liefert Default-Werte für alle
Videos in diesem Verzeichnis und darunter. Wird beim Publish jedes Videos die
Verzeichniskette von der Quelldatei nach oben gelaufen und die **nächstgelegene**
Datei mit dem gewünschten Feld liefert den Wert — Unterverzeichnisse
überschreiben Parents.

Seit v0.7.0 funktioniert die Kette auch auf **rclone-Remotes**: Die Suche
liest ``familienfilm.toml`` via ``rclone cat`` und steigt entlang der
URI-Segmente hoch (``nas:/a/b/c`` → ``nas:/a/b`` → ``nas:/a`` → ``nas:``).

Aktuell wird nur ``category`` gelesen. Die Struktur ist so angelegt, dass
weitere Felder (z.B. ``description``, später ``author``) ohne Breaking
Change ergänzt werden können.
"""

from __future__ import annotations

import tomllib
from dataclasses import dataclass
from pathlib import Path

from familienfilm_manager.core.source_ref import SourceRef

SETTINGS_FILENAME = "familienfilm.toml"


@dataclass
class DirectorySettings:
    """Im Verzeichnis hinterlegte Defaults für Publish-Operationen."""

    category: str | None = None
    source_uri: str | None = None   # URI der gefundenen Datei (Debug/Logging)


def _parse_settings(raw: str, source_uri: str) -> DirectorySettings | None:
    """Parst den TOML-Inhalt. None bei Parse-Fehler."""
    try:
        data = tomllib.loads(raw)
    except tomllib.TOMLDecodeError:
        return None
    category = data.get("category")
    return DirectorySettings(
        category=str(category) if category is not None else None,
        source_uri=source_uri,
    )


def _read_local_settings(path: Path) -> DirectorySettings | None:
    if not path.is_file():
        return None
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError:
        return None
    return _parse_settings(raw, str(path))


def _read_rclone_settings(uri: str, rclone_path: str = "rclone") -> DirectorySettings | None:
    """Liest ``<uri>/familienfilm.toml`` via rclone cat — None wenn nicht vorhanden."""
    from familienfilm_manager.core._rclone import rclone_cat

    # Child-URI für familienfilm.toml berechnen
    base = SourceRef(uri)
    settings_uri = base.child_uri(SETTINGS_FILENAME)
    try:
        raw_bytes = rclone_cat(settings_uri, rclone_path=rclone_path)
    except Exception:
        return None
    if raw_bytes is None:
        return None
    return _parse_settings(raw_bytes.decode("utf-8"), settings_uri)


def find_directory_settings(
    start: str | Path | SourceRef | None = None,
    stop_at: str | Path | SourceRef | None = None,
    *,
    start_dir: str | Path | SourceRef | None = None,
    rclone_path: str = "rclone",
) -> DirectorySettings:
    """Sucht die nächstgelegene ``familienfilm.toml`` ab ``start`` nach oben.

    Läuft die Verzeichniskette von ``start`` nach oben bis:
    - eine ``familienfilm.toml`` mit einem gelesenen Feld gefunden wird, ODER
    - ``stop_at`` erreicht ist (inklusiv), ODER
    - der Root des Filesystems oder des rclone-Remotes erreicht ist.

    Args:
        start: Verzeichnis, ab dem die Suche beginnt. Akzeptiert Path, str oder
            SourceRef — wird intern normalisiert. Typisch: Parent des Videos.
        stop_at: Optionale obere Grenze (z.B. der Scan-Root bei ``publish-dir``).
        rclone_path: Pfad zur rclone-Binary (nur relevant bei rclone-URIs).

    Returns:
        ``DirectorySettings`` mit dem ersten gefundenen Wert.
        Leer wenn nichts gefunden.

    Hinweis zur Grenzlogik: Der Scan-Root selbst wird mitgeprüft — eine
    ``familienfilm.toml`` direkt im ``publish-dir``-Argument greift auch für
    Videos in Unterverzeichnissen. Darüber wird nicht weiter gesucht.

    Das alte Keyword-Argument ``start_dir`` wird akzeptiert (aber bevorzugt
    ``start`` nutzen) — Backward-Kompatibilität für v0.6.0-Aufrufer.
    """
    if start is None and start_dir is None:
        raise TypeError("find_directory_settings() benötigt 'start' oder 'start_dir'")
    start_value = start if start is not None else start_dir
    start_ref = _to_ref(start_value)
    stop_ref = _to_ref(stop_at) if stop_at is not None else None

    # Für lokale Pfade wird ``resolve()`` angewandt, damit stop-at-Vergleich
    # funktioniert. Bei rclone-URIs ist Normalisierung rein stringbasiert.
    if not start_ref.is_rclone:
        current_path = start_ref.as_local_path().resolve()
        stop_path = stop_ref.as_local_path().resolve() if (stop_ref and not stop_ref.is_rclone) else None

        while True:
            found = _read_local_settings(current_path / SETTINGS_FILENAME)
            if found is not None and found.category is not None:
                return found
            if stop_path is not None and current_path == stop_path:
                break
            parent = current_path.parent
            if parent == current_path:
                break
            current_path = parent
        return DirectorySettings()

    # rclone-URI-Kette
    current_ref = start_ref
    stop_uri = stop_ref.uri if stop_ref is not None else None

    while True:
        found = _read_rclone_settings(current_ref.uri, rclone_path=rclone_path)
        if found is not None and found.category is not None:
            return found

        if stop_uri is not None and current_ref.uri == stop_uri:
            break

        if current_ref.is_root():
            break

        current_ref = SourceRef(current_ref.parent_uri())

    return DirectorySettings()


def _to_ref(value: str | Path | SourceRef) -> SourceRef:
    if isinstance(value, SourceRef):
        return value
    return SourceRef(str(value))
