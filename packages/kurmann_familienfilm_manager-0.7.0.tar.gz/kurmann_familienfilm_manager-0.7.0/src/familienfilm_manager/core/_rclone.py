"""rclone-Aufrufe mit Retry-Backoff.

Hintergrund: rclone-Operationen gegen SMB/SFTP-NAS können flüchtig scheitern
(Netzwerk-Hiccup, kurzer Server-Timeout, Filesystem-Sync-Delay unmittelbar
nach einer lokalen Schreib-Operation). Ein kurzer exponentieller Backoff
(1s/3s/9s) deckt solche Einmal-Fehler ab, ohne den kompletten Publish-Workflow
(Minuten für Komprimierung + Upload) wiederholen zu müssen.

Nur ``subprocess.CalledProcessError`` wird retried — andere Exceptions
(FileNotFoundError für rclone-Binary, PermissionError usw.) sind nicht
flüchtig und würden durch Retries nur verzögert.
"""

from __future__ import annotations

import json
import subprocess
import time
from collections.abc import Callable, Sequence

# Wartezeiten zwischen Retry-Versuchen (Sekunden). Die Länge der Sequenz
# bestimmt die maximale Anzahl zusätzlicher Versuche nach dem ersten.
DEFAULT_RETRY_DELAYS: tuple[int, ...] = (1, 3, 9)


def run_rclone_with_retry(
    args: Sequence[str],
    *,
    retry_delays: Sequence[int] = DEFAULT_RETRY_DELAYS,
    on_retry: Callable[[int, int, Exception], None] | None = None,
) -> subprocess.CompletedProcess:
    """Führt einen rclone-Befehl aus und wiederholt bei flüchtigen Fehlern.

    Args:
        args: Komplette Argumentliste inkl. ``rclone``-Binary (z.B.
            ``[rclone_path, "copy", source, target]``).
        retry_delays: Wartezeiten zwischen Versuchen in Sekunden. Default
            ``(1, 3, 9)`` = 3 Retries nach dem ersten Versuch (maximal 4
            Versuche insgesamt).
        on_retry: Optionaler Callback, der vor jedem Retry aufgerufen wird —
            erhält ``(attempt, max_attempts, last_exception)``. Ideal für
            Event-basierte Fortschrittsanzeige.

    Returns:
        ``CompletedProcess`` des erfolgreichen Laufs.

    Raises:
        subprocess.CalledProcessError: Wenn alle Versuche fehlgeschlagen sind.
            Die Exception des letzten Versuchs wird weitergereicht.
        FileNotFoundError: Wenn die rclone-Binary nicht gefunden wurde
            (wird nicht retried — Konfigurationsfehler).
    """
    max_attempts = len(retry_delays) + 1
    last_error: subprocess.CalledProcessError | None = None

    for attempt in range(1, max_attempts + 1):
        try:
            return subprocess.run(
                list(args),
                check=True,
                capture_output=True,
                text=True,
            )
        except subprocess.CalledProcessError as e:
            last_error = e
            if attempt >= max_attempts:
                break
            if on_retry is not None:
                on_retry(attempt, max_attempts, e)
            time.sleep(retry_delays[attempt - 1])

    assert last_error is not None
    raise last_error


def verify_rclone_target_contains(
    target: str,
    expected_names: Sequence[str],
    *,
    rclone_path: str = "rclone",
) -> tuple[bool, list[str]]:
    """Prüft, dass ``expected_names`` (Dateien oder Unterverzeichnisse) im ``target`` existieren.

    Ruft ``rclone lsf <target>`` auf (schnell — nur Namen, keine Metadata) und
    prüft, ob jeder Name in ``expected_names`` in der Ausgabe vorkommt.

    Args:
        target: rclone-Ziel (z.B. ``nas:/Archiv/2026/Videoschnitt``).
        expected_names: Namen, die im Target erwartet werden (z.B. TAR-Name oder
            Web-ID-Verzeichnis).
        rclone_path: Pfad zur rclone-Binary.

    Returns:
        Tuple ``(alle_vorhanden, fehlende_namen)``. Wenn rclone selbst nicht
        ausgeführt werden kann (Remote nicht erreichbar), wird ``(False, expected_names)``
        zurückgegeben — das Ziel gilt als unverifizierbar, gleichbedeutend mit
        „Dateien fehlen".
    """
    try:
        result = subprocess.run(
            [rclone_path, "lsf", target],
            check=True,
            capture_output=True,
            text=True,
        )
    except (subprocess.CalledProcessError, FileNotFoundError, OSError):
        return False, list(expected_names)

    # rclone lsf gibt Namen zeilenweise aus; Verzeichnisse enden mit "/".
    present = {line.rstrip("/").strip() for line in result.stdout.splitlines() if line.strip()}
    missing = [name.rstrip("/") for name in expected_names if name.rstrip("/") not in present]
    return len(missing) == 0, missing


# ---------------------------------------------------------------------------
# Primitives für v0.7.0: rclone als Quell-Backend (Lesen vom Remote).
# ---------------------------------------------------------------------------


def rclone_cat(
    uri: str,
    *,
    rclone_path: str = "rclone",
    retry_delays: Sequence[int] = DEFAULT_RETRY_DELAYS,
    on_retry: Callable[[int, int, Exception], None] | None = None,
) -> bytes | None:
    """Liest eine Datei vom rclone-Remote.

    Nutzt ``rclone cat <uri>``. Für kleine Dateien (Sidecars, familienfilm.toml)
    gedacht. Bei CalledProcessError mit ``not found``/``does not exist``-Text
    wird ``None`` zurückgegeben (als „Datei nicht vorhanden"-Signal — rclone
    hat leider keinen separaten Exit-Code dafür).

    Andere Fehler (Verbindung, Auth) werden nach Retry-Exhaustion re-raised.
    """
    try:
        result = run_rclone_with_retry(
            [rclone_path, "cat", uri],
            retry_delays=retry_delays,
            on_retry=on_retry,
        )
    except subprocess.CalledProcessError as e:
        stderr = (e.stderr or "").lower()
        if "not found" in stderr or "does not exist" in stderr or "no such" in stderr:
            return None
        raise
    # rclone cat liefert Bytes via stdout; run_rclone_with_retry nutzt text=True,
    # also haben wir einen String. Für TOML-Inhalte reicht das. Wir geben
    # Bytes zurück für Roundtrip-Sicherheit.
    return result.stdout.encode("utf-8") if result.stdout else b""


def rclone_lsjson(
    uri: str,
    *,
    recursive: bool = False,
    rclone_path: str = "rclone",
    retry_delays: Sequence[int] = DEFAULT_RETRY_DELAYS,
    on_retry: Callable[[int, int, Exception], None] | None = None,
) -> list[dict]:
    """Listet den Inhalt eines rclone-Remote-Verzeichnisses als JSON.

    Aufruf: ``rclone lsjson [--recursive] <uri>``.

    Returns:
        Liste von Dicts mit mindestens ``Name`` (str), ``Size`` (int),
        ``IsDir`` (bool), ``Path`` (str, relativ zu ``uri``). Leere Liste
        wenn Verzeichnis existiert aber leer.

    Raises:
        subprocess.CalledProcessError: Bei endgültigem Fehler (Verzeichnis
            existiert nicht, Auth-Problem nach Retries etc.).
    """
    args = [rclone_path, "lsjson"]
    if recursive:
        args.append("--recursive")
    args.append(uri)

    result = run_rclone_with_retry(
        args,
        retry_delays=retry_delays,
        on_retry=on_retry,
    )
    if not result.stdout.strip():
        return []
    data = json.loads(result.stdout)
    if not isinstance(data, list):
        raise ValueError(f"Unerwartete rclone-lsjson-Ausgabe: {type(data).__name__}")
    return data


def rclone_copyto(
    src: str,
    dst: str,
    *,
    rclone_path: str = "rclone",
    retry_delays: Sequence[int] = DEFAULT_RETRY_DELAYS,
    on_retry: Callable[[int, int, Exception], None] | None = None,
) -> None:
    """Kopiert eine einzelne Datei mit neuem Namen (``rclone copyto``).

    Unterschied zu ``rclone copy``: copyto nimmt exakt einen Source-File und
    einen Target-File-Pfad, nicht Verzeichnisse. Perfekt für Sidecar-
    Rücksync und Video-Staging mit ggf. umbenannten Zielnamen.

    Quelle oder Ziel können lokal (``/pfad``) oder rclone-URI (``remote:pfad``)
    sein. Beide lokal: rclone tut's trotzdem korrekt (delegiert an OS).
    """
    run_rclone_with_retry(
        [rclone_path, "copyto", src, dst],
        retry_delays=retry_delays,
        on_retry=on_retry,
    )
