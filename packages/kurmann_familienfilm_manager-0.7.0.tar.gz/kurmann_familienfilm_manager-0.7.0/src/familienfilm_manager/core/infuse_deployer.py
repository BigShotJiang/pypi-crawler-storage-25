"""Infuse-Deployment: Dateien via rclone zum Medienserver kopieren."""

from __future__ import annotations

import subprocess
from pathlib import Path

from familienfilm_manager.api.models import (
    DeployResult,
    FamilienfilmEvent,
    FamilienfilmStage,
)
from familienfilm_manager.core._rclone import (
    run_rclone_with_retry,
    verify_rclone_target_contains,
)


def _build_target_subdir(
    target: str,
    recording_date: str,
    group_by: str,
) -> str:
    """Baut den Zielpfad mit Jahr/Monat-Struktur.

    Args:
        target: rclone-Basisziel (z.B. nas:/media/videos/).
        recording_date: ISO-Datum (YYYY-MM-DD).
        group_by: "year" oder "month".

    Returns:
        Zielpfad (z.B. nas:/media/videos/2024/ oder nas:/media/videos/2024/2024-07/).
    """
    target = target.rstrip("/")
    year = recording_date[:4]
    if group_by == "month":
        month = recording_date[:7]  # YYYY-MM
        return f"{target}/{year}/{month}"
    return f"{target}/{year}"


def deploy_to_infuse(
    source_dir: Path,
    infuse_target: str,
    rclone_path: str = "rclone",
    recording_date: str | None = None,
    group_by: str = "year",
    on_event=None,
) -> DeployResult:
    """Kopiert Infuse-Dateien via rclone zum Medienserver.

    Der mediaset-creator v2 schreibt Infuse-Dateien direkt mit korrekten
    Dateinamen in das Quellverzeichnis. Kein ZIP-Entpacken mehr nötig.

    Args:
        source_dir: Verzeichnis mit den Infuse-Dateien.
        infuse_target: rclone-Ziel für Infuse.
        rclone_path: Pfad zur rclone-Binärdatei.
        recording_date: ISO-Datum für Zielstruktur.
        group_by: Gruppierung "year" oder "month".
        on_event: Optionaler Event-Callback.

    Returns:
        DeployResult mit Erfolg/Fehler.
    """
    if not infuse_target:
        return DeployResult(
            success=False,
            error_message="Kein Infuse-Ziel konfiguriert (targets.infuse).",
        )

    if not source_dir.exists():
        return DeployResult(
            success=False,
            error_message=f"Quellverzeichnis nicht gefunden: {source_dir}",
        )

    if recording_date:
        target_dir = _build_target_subdir(infuse_target, recording_date, group_by)
    else:
        target_dir = infuse_target.rstrip("/")

    def _on_retry(attempt: int, max_attempts: int, exc: Exception) -> None:
        if on_event:
            stderr = getattr(exc, "stderr", "") or str(exc)
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.DEPLOY_RETRY,
                message=(
                    f"Infuse-Deployment fehlgeschlagen (Versuch {attempt}/{max_attempts}), "
                    f"retry: {stderr.strip().splitlines()[-1] if stderr.strip() else exc}"
                ),
            ))

    try:
        run_rclone_with_retry(
            [rclone_path, "copy", str(source_dir), target_dir],
            on_retry=_on_retry,
        )
    except subprocess.CalledProcessError as e:
        msg = f"Infuse-Deployment fehlgeschlagen: {e.stderr or e}"
        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.DEPLOY_FAILED,
                message=msg,
            ))
        return DeployResult(success=False, error_message=msg)
    except Exception as e:
        msg = f"Infuse-Deployment fehlgeschlagen: {e}"
        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.DEPLOY_FAILED,
                message=msg,
            ))
        return DeployResult(success=False, error_message=msg)

    if on_event:
        on_event(FamilienfilmEvent(
            stage_id=FamilienfilmStage.INFUSE_DEPLOYED,
            message=f"Infuse-Deployment: {source_dir.name} → {target_dir}",
        ))

    # Post-Deploy Health-Check: die deployten Dateien müssen im Ziel sichtbar sein.
    expected = [p.name for p in source_dir.iterdir() if p.is_file()]
    if expected:
        ok, missing = verify_rclone_target_contains(
            target_dir, expected, rclone_path=rclone_path,
        )
        if not ok:
            msg = (
                f"Infuse-Deployment ist laut rclone erfolgreich, aber der "
                f"Health-Check findet {len(missing)} Datei(en) nicht im Ziel "
                f"({target_dir}): {', '.join(missing[:3])}"
                + ("…" if len(missing) > 3 else "")
            )
            if on_event:
                on_event(FamilienfilmEvent(
                    stage_id=FamilienfilmStage.DEPLOY_FAILED,
                    message=msg,
                ))
            return DeployResult(success=False, target_path=target_dir, error_message=msg)
        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.DEPLOYMENT_VERIFIED,
                message=f"Infuse-Deployment verifiziert: {len(expected)} Datei(en) im Ziel",
            ))

    return DeployResult(success=True, target_path=target_dir)
