"""Scan von rclone-Remotes: findet qualifizierte Videos ohne lokalen Mount.

Analog zu ``_scan_directory`` im ``directory_publisher``, aber mit
``rclone lsjson`` statt Filesystem-Iteration. Gibt URIs zurück, die
später per ``stage_source`` lokal gemacht werden.

Zusätzlich ein **Light-Peek** für die Skip-Logik: bevor das Video (u.U.
mehrere GB) gestaged wird, wird nur die kleine ``.settings.toml``
herangezogen. Stimmen ``published_at`` für alle aktiven Kanäle und
``source_size_bytes`` mit der aktuellen Remote-Size überein, kann der
Publisher das Video überspringen — ohne einen einzigen Byte Video-
Traffic.
"""

from __future__ import annotations

import json
import re
from collections.abc import Sequence
from dataclasses import dataclass

from familienfilm_manager.core._rclone import (
    rclone_cat,
    rclone_lsjson,
)
from familienfilm_manager.core.directory_publisher import (
    _DATE_PREFIX_RE,
    _VIDEO_EXTENSIONS,
)
from familienfilm_manager.core.sidecar_manager import SidecarSettings
from familienfilm_manager.core.source_ref import SourceRef


@dataclass
class RemoteVideoRef:
    """Ergebnis des rclone-Scans: ein qualifiziertes Video auf dem Remote."""

    uri: str                    # Voller rclone-URI zum Video
    name: str                   # Dateiname
    size_bytes: int             # Aktuelle Remote-Dateigröße


def _is_qualified_remote_video(name: str) -> bool:
    """Filterregeln identisch zum lokalen Scan, aber nur namensbasiert
    (kein Filesystem-Zugriff)."""
    if not name or name.startswith("."):
        return False
    # Suffix prüfen
    if "." not in name:
        return False
    suffix = "." + name.rsplit(".", 1)[-1]
    if suffix.lower() not in _VIDEO_EXTENSIONS:
        return False
    # Stem muss das Datum-Präfix erfüllen
    stem = name.rsplit(".", 1)[0]
    return bool(_DATE_PREFIX_RE.match(stem))


def _date_from_remote_name(name: str) -> str:
    """Extrahiert das Datum aus einem Dateinamen (für Sortierung)."""
    stem = name.rsplit(".", 1)[0] if "." in name else name
    match = _DATE_PREFIX_RE.match(stem)
    return match.group(1) if match else "0000-00-00"


def scan_rclone_directory(
    directory_uri: str,
    *,
    recursive: bool = False,
    rclone_path: str = "rclone",
) -> list[RemoteVideoRef]:
    """Listet qualifizierte Videos in einem rclone-Remote-Verzeichnis.

    Sortierung: chronologisch nach Datum im Dateinamen, älteste zuerst.

    Args:
        directory_uri: rclone-URI des Verzeichnisses (z.B.
            ``"lyssach-nas:/Quelle/neu2"``).
        recursive: Wenn True, werden Unterverzeichnisse mitgescannt.
            Hidden-Pfade (mit ``.`` am Anfang) werden übersprungen.
        rclone_path: Pfad zur rclone-Binary.

    Returns:
        Sortierte Liste von ``RemoteVideoRef``.
    """
    base_ref = SourceRef(directory_uri)
    try:
        entries = rclone_lsjson(directory_uri, recursive=recursive, rclone_path=rclone_path)
    except Exception:
        return []

    results: list[RemoteVideoRef] = []
    for entry in entries:
        if entry.get("IsDir"):
            continue
        # Bei recursive=True hat "Path" den relativen Pfad inkl. Unterverzeichnis
        relative_path = entry.get("Path") or entry.get("Name", "")
        name = entry.get("Name", "")

        # Hidden-Unterverzeichnisse überspringen
        if recursive and "/" in relative_path:
            parts = relative_path.split("/")
            if any(p.startswith(".") for p in parts[:-1]):
                continue

        if not _is_qualified_remote_video(name):
            continue

        # Vollen URI konstruieren: directory_uri + relative_path
        video_uri = base_ref.child_uri(relative_path)
        results.append(RemoteVideoRef(
            uri=video_uri,
            name=name,
            size_bytes=int(entry.get("Size", -1)),
        ))

    results.sort(key=lambda r: (_date_from_remote_name(r.name), r.name.lower()))
    return results


def peek_remote_sidecar(
    video_uri: str,
    *,
    rclone_path: str = "rclone",
) -> SidecarSettings | None:
    """Light-Peek: zieht NUR das kleine ``.settings.toml`` vom Remote.

    Spart bei grossen Videos GB-weise Bandbreite, wenn das Video wegen
    bereits vollständigem Publish ohnehin übersprungen werden könnte.

    Returns:
        Geparste ``SidecarSettings`` oder ``None``, wenn keine Sidecar
        vorhanden ist.
    """
    from familienfilm_manager.core.sidecar_manager import read_sidecar
    import tempfile
    from pathlib import Path

    video_ref = SourceRef(video_uri)
    sidecar_uri = video_ref.parent_uri()
    sidecar_name = f"{video_ref.stem}.settings.toml"
    if sidecar_uri.endswith(":"):
        sidecar_full_uri = f"{sidecar_uri}{sidecar_name}"
    else:
        sidecar_full_uri = f"{sidecar_uri.rstrip('/')}/{sidecar_name}"

    raw = rclone_cat(sidecar_full_uri, rclone_path=rclone_path)
    if raw is None:
        return None

    # rclone_cat liefert Bytes — in Tempfile schreiben und via read_sidecar parsen.
    # Wir könnten direkt parsen, aber so bleiben wir bei dem einen Parser.
    with tempfile.TemporaryDirectory() as td:
        td_path = Path(td)
        video_shadow = td_path / video_ref.name
        video_shadow.touch()  # read_sidecar leitet den Sidecar-Pfad aus Video ab
        sidecar_shadow = td_path / sidecar_name
        sidecar_shadow.write_bytes(raw)
        return read_sidecar(video_shadow)


def is_remote_video_already_published(
    video_uri: str,
    size_bytes: int,
    *,
    requires_web: bool = True,
    requires_local: bool = True,
    requires_archive: bool = True,
    rclone_path: str = "rclone",
) -> tuple[bool, str | None]:
    """Light-Peek Skip-Check für Remote-Quellen.

    Prüft (ohne das Video zu stagen):
    - Sidecar existiert und enthält die nötigen ``published_at``-Timestamps
      für alle aktiven Kanäle
    - Sidecar-``source_size_bytes`` stimmt mit aktueller Remote-Size überein

    Head-SHA1-Check entfällt bei Remote-Quellen (wir haben nur die ersten
    1 MB vom Video nach Staging — wäre kontraproduktiv).

    Returns:
        ``(skip_möglich, published_at_oder_None)``.
    """
    sidecar = peek_remote_sidecar(video_uri, rclone_path=rclone_path)
    if sidecar is None:
        return False, None

    # Legacy-Sidecar (nur [web].published_at) → Republish erzwingen
    if sidecar.is_legacy_pre_channels:
        return False, sidecar.web_published_at

    # Fingerprint muss vorhanden sein
    if sidecar.source_size_bytes is None:
        return False, None

    # Aktuelle Remote-Size prüfen
    if size_bytes != sidecar.source_size_bytes:
        return False, None

    # Required published_at pro aktivem Kanal
    timestamps: list[str] = []
    if requires_web:
        if not sidecar.web_published_at:
            return False, None
        timestamps.append(sidecar.web_published_at)
    if requires_local:
        if not sidecar.local_published_at:
            return False, None
        timestamps.append(sidecar.local_published_at)
    if requires_archive:
        if not sidecar.archive_published_at:
            return False, None
        timestamps.append(sidecar.archive_published_at)

    oldest = min(timestamps) if timestamps else None
    return True, oldest
