"""Sidecar-Manager: Lesen/Schreiben von Settings-Dateien neben dem Video."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path

import tomllib

# Grösse des Kopf-Samples für den Fingerprint (SHA1 der ersten N Bytes).
# 1 MB ist ein guter Kompromiss: kollisionssicher genug für Identitätsprüfung
# und schnell genug auch auf langsamen Netzwerk-Shares (~100ms bei SMB).
HEAD_HASH_BYTES = 1 * 1024 * 1024


def compute_source_fingerprint(video_path: Path) -> tuple[int, str]:
    """Berechnet (size_bytes, head_sha1_hex) für die Quelldatei.

    Der Fingerprint wird als Identitätsanker verwendet — robuster als mtime,
    die auf SMB/NAS-Shares unzuverlässig ist.
    """
    size = video_path.stat().st_size
    hasher = hashlib.sha1()
    with video_path.open("rb") as f:
        hasher.update(f.read(HEAD_HASH_BYTES))
    return size, hasher.hexdigest()


@dataclass
class SidecarSettings:
    """Persistierte Einstellungen in einer .settings.toml Datei neben dem Video.

    Jeder der drei Deploy-Kanäle (``web``, ``local``, ``archive``) hat einen
    eigenen ``published_at``-Zeitstempel, der nur nach erfolgreichem Deploy
    dieses Kanals geschrieben wird. Die Skip-Logik bei ``publish-dir`` /
    ``watch-dir`` verlangt, dass **alle aktiven Kanäle** einen Zeitstempel
    haben — Teilerfolge führen zu automatischem Retry beim nächsten Lauf.
    """

    # Poster-Einstellungen
    frame_number: int | None = None
    timestamp_seconds: float | None = None
    crop_position: str | None = None

    # Web-Kanal (Hostpoint / öffentlicher Webserver)
    web_id: str | None = None
    max_luminance: int | None = None
    web_published_at: str | None = None

    # Local-Kanal (Infuse / Medienserver im LAN)
    local_published_at: str | None = None

    # Archive-Kanal (TAR im Langzeit-Archiv)
    archive_published_at: str | None = None

    # Fingerprint der Quelldatei zum Publish-Zeitpunkt
    source_size_bytes: int | None = None
    source_head_sha1: str | None = None

    # Effektive Metadaten (für selbsttragendes Archiv)
    category: str | None = None

    def has_values(self) -> bool:
        """Prüft ob mindestens ein Wert gesetzt ist."""
        return any(v is not None for v in (
            self.frame_number, self.timestamp_seconds, self.crop_position,
            self.web_id, self.max_luminance,
            self.web_published_at, self.local_published_at, self.archive_published_at,
            self.source_size_bytes, self.source_head_sha1,
            self.category,
        ))

    @property
    def is_legacy_pre_channels(self) -> bool:
        """Legacy-Sidecar (≤ 0.6.0 RC) mit ``web_published_at`` aber ohne
        ``local_published_at`` oder ``archive_published_at``.

        Semantik des alten ``[web].published_at``: „irgendwas wurde publiziert",
        aber welcher Kanal ist unklar. Konservative Annahme für die Migration:
        behandeln als „noch nicht vollständig publiziert" → nächster Lauf
        republiziert voll und füllt alle drei Zeitstempel.
        """
        return (
            self.web_published_at is not None
            and self.local_published_at is None
            and self.archive_published_at is None
        )


def sidecar_path_for(video_path: Path) -> Path:
    """Gibt den Pfad zur Sidecar-Datei zurück."""
    return video_path.parent / f"{video_path.stem}.settings.toml"


def read_sidecar(video_path: Path) -> SidecarSettings:
    """Liest die Sidecar-Datei. Gibt leeres SidecarSettings zurück wenn nicht vorhanden."""
    path = sidecar_path_for(video_path)
    if not path.exists():
        return SidecarSettings()

    try:
        data = tomllib.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return SidecarSettings()

    poster = data.get("poster") or {}
    if not isinstance(poster, dict):
        poster = {}

    web = data.get("web") or {}
    if not isinstance(web, dict):
        web = {}

    local = data.get("local") or {}
    if not isinstance(local, dict):
        local = {}

    archive = data.get("archive") or {}
    if not isinstance(archive, dict):
        archive = {}

    source = data.get("source") or {}
    if not isinstance(source, dict):
        source = {}

    metadata = data.get("metadata") or {}
    if not isinstance(metadata, dict):
        metadata = {}

    def _as_int(v):
        return int(v) if v is not None else None

    def _as_float(v):
        return float(v) if v is not None else None

    def _as_str(v):
        return str(v) if v is not None else None

    return SidecarSettings(
        frame_number=_as_int(poster.get("frame_number")),
        timestamp_seconds=_as_float(poster.get("timestamp_seconds")),
        crop_position=_as_str(poster.get("crop_position")),
        web_id=_as_str(web.get("web_id")),
        max_luminance=_as_int(web.get("max_luminance")),
        web_published_at=_as_str(web.get("published_at")),
        local_published_at=_as_str(local.get("published_at")),
        archive_published_at=_as_str(archive.get("published_at")),
        source_size_bytes=_as_int(source.get("size_bytes")),
        source_head_sha1=_as_str(source.get("head_sha1")),
        category=_as_str(metadata.get("category")),
    )


def write_sidecar(video_path: Path, settings: SidecarSettings) -> Path:
    """Schreibt die Sidecar-Datei. Nur gesetzte Felder werden geschrieben.

    Returns:
        Pfad zur geschriebenen Datei.
    """
    path = sidecar_path_for(video_path)
    lines: list[str] = []

    def _append_section(name: str, body: list[str]) -> None:
        if not body:
            return
        if lines:
            lines.append("")
        lines.append(f"[{name}]")
        lines.extend(body)

    # [poster]
    poster_lines: list[str] = []
    if settings.frame_number is not None:
        poster_lines.append(f"frame_number = {settings.frame_number}")
    if settings.timestamp_seconds is not None:
        poster_lines.append(f"timestamp_seconds = {settings.timestamp_seconds}")
    if settings.crop_position is not None:
        poster_lines.append(f'crop_position = "{settings.crop_position}"')
    _append_section("poster", poster_lines)

    # [web]
    web_lines: list[str] = []
    if settings.web_id is not None:
        web_lines.append(f'web_id = "{settings.web_id}"')
    if settings.max_luminance is not None:
        web_lines.append(f"max_luminance = {settings.max_luminance}")
    if settings.web_published_at is not None:
        web_lines.append(f'published_at = "{settings.web_published_at}"')
    _append_section("web", web_lines)

    # [local] (Infuse / LAN-Medienserver)
    local_lines: list[str] = []
    if settings.local_published_at is not None:
        local_lines.append(f'published_at = "{settings.local_published_at}"')
    _append_section("local", local_lines)

    # [archive] (TAR-Langzeit-Archiv)
    archive_lines: list[str] = []
    if settings.archive_published_at is not None:
        archive_lines.append(f'published_at = "{settings.archive_published_at}"')
    _append_section("archive", archive_lines)

    # [source] — Fingerprint
    source_lines: list[str] = []
    if settings.source_size_bytes is not None:
        source_lines.append(f"size_bytes = {settings.source_size_bytes}")
    if settings.source_head_sha1 is not None:
        source_lines.append(f'head_sha1 = "{settings.source_head_sha1}"')
    _append_section("source", source_lines)

    # [metadata] — effektive Metadaten (für selbsttragendes Archiv)
    metadata_lines: list[str] = []
    if settings.category is not None:
        escaped = settings.category.replace('"', '\\"')
        metadata_lines.append(f'category = "{escaped}"')
    _append_section("metadata", metadata_lines)

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path
