"""Tests für source_staging.py."""

import subprocess
from pathlib import Path
from unittest.mock import patch

import pytest

from familienfilm_manager.api.models import RuntimeOptions
from familienfilm_manager.core.source_ref import SourceRef
from familienfilm_manager.core.source_staging import stage_source


# ── Lokale Quelle: Passthrough ──


def test_local_source_is_passthrough(tmp_path: Path):
    """Lokale Quelle: keine Kopie, local_video_path = Original."""
    video = tmp_path / "2026-04-18 Test.mov"
    video.write_bytes(b"video")

    ref = SourceRef(str(video))
    staged = stage_source(ref, work_dir=None)

    assert staged.is_staged is False
    assert staged.local_video_path == video
    assert staged._stage_dir is None


def test_local_source_discovers_sidecar(tmp_path: Path):
    video = tmp_path / "2026-04-18 Test.mov"
    video.write_bytes(b"v")
    sidecar = tmp_path / "2026-04-18 Test.settings.toml"
    sidecar.write_text('[web]\nweb_id = "x"\n', encoding="utf-8")

    staged = stage_source(SourceRef(str(video)), work_dir=None)

    assert staged.local_sidecar_path == sidecar


def test_local_source_discovers_extra_sidecars(tmp_path: Path):
    """fcpxml, lfpackage etc. werden in extra_sidecars gesammelt."""
    video = tmp_path / "2026-04-18 Test.mov"
    video.write_bytes(b"v")
    fcpxml = tmp_path / "2026-04-18 Test.fcpxml"
    fcpxml.write_text("<xml/>", encoding="utf-8")
    fanart = tmp_path / "2026-04-18 Test-fanart.jpg"
    fanart.write_bytes(b"jpg")

    staged = stage_source(SourceRef(str(video)), work_dir=None)

    extras_names = {p.name for p in staged.extra_sidecars}
    assert extras_names == {"2026-04-18 Test.fcpxml", "2026-04-18 Test-fanart.jpg"}


def test_local_source_sync_is_noop(tmp_path: Path):
    """Lokale Quelle: sync_sidecar_back tut nichts (Passthrough)."""
    video = tmp_path / "2026-04-18 Test.mov"
    video.write_bytes(b"v")

    staged = stage_source(SourceRef(str(video)), work_dir=None)

    # Ein Dummy-Sidecar ausserhalb existiert
    dummy = tmp_path / "dummy.toml"
    dummy.write_text("x", encoding="utf-8")

    with patch("familienfilm_manager.core.source_staging.rclone_copyto") as m:
        staged.sync_sidecar_back(dummy)
    m.assert_not_called()


def test_local_source_cleanup_is_noop(tmp_path: Path):
    video = tmp_path / "2026-04-18 Test.mov"
    video.write_bytes(b"v")

    staged = stage_source(SourceRef(str(video)), work_dir=None)
    staged.cleanup()

    assert video.exists()  # Original unangetastet


# ── rclone-Quelle: Staging via copyto ──


def _mock_rclone_calls(copied_files: dict[str, bytes] | None = None, lsjson_entries: list[dict] | None = None):
    """Gibt einen subprocess.run-Mock zurück, der rclone-Befehle simuliert.

    ``copied_files``: Map URI → Bytes, die von copyto an den Ziel-Pfad geschrieben werden.
    ``lsjson_entries``: Liste, die rclone lsjson zurückgibt.
    """
    copied_files = copied_files or {}
    lsjson_entries = lsjson_entries or []

    def fake(args, **kwargs):
        cmd = args[1] if len(args) > 1 else ""
        if cmd == "copyto":
            src, dst = args[2], args[3]
            if src in copied_files:
                Path(dst).parent.mkdir(parents=True, exist_ok=True)
                Path(dst).write_bytes(copied_files[src])
            else:
                # src ist kein bekannter Remote-URI — evtl. Fehler-Signal
                raise subprocess.CalledProcessError(1, args, stderr="not found")
            return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")
        if cmd == "lsjson":
            import json as _json
            return subprocess.CompletedProcess(
                args=args, returncode=0, stdout=_json.dumps(lsjson_entries), stderr="",
            )
        raise AssertionError(f"Unexpected rclone cmd: {args}")

    return fake


def test_rclone_source_requires_work_dir():
    with pytest.raises(ValueError, match="work_dir"):
        stage_source(SourceRef("nas:/foo.mov"), work_dir=None)


def test_rclone_source_copies_video_only(tmp_path: Path):
    """Minimal-Fall: nur Video, keine Sidecars im Parent."""
    ref = SourceRef("nas:/Quelle/2026-04-18 Test.mov")
    work = tmp_path / "work"
    work.mkdir()

    fake = _mock_rclone_calls(
        copied_files={"nas:/Quelle/2026-04-18 Test.mov": b"video-bytes"},
        lsjson_entries=[
            {"Name": "2026-04-18 Test.mov", "Path": "2026-04-18 Test.mov", "Size": 11, "IsDir": False},
        ],
    )

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake):
        staged = stage_source(ref, work_dir=work)

    assert staged.is_staged is True
    assert staged.local_video_path.exists()
    assert staged.local_video_path.read_bytes() == b"video-bytes"
    assert staged.local_video_path.name == "2026-04-18 Test.mov"
    assert staged.local_sidecar_path is None
    assert staged.extra_sidecars == []


def test_rclone_source_copies_video_plus_sidecar(tmp_path: Path):
    """Typischer Fall: Video + settings.toml im Parent."""
    ref = SourceRef("nas:/Quelle/2026-04-18 Test.mov")
    work = tmp_path / "work"
    work.mkdir()

    fake = _mock_rclone_calls(
        copied_files={
            "nas:/Quelle/2026-04-18 Test.mov": b"video-bytes",
            "nas:/Quelle/2026-04-18 Test.settings.toml": b'[web]\nweb_id = "x"\n',
        },
        lsjson_entries=[
            {"Name": "2026-04-18 Test.mov", "IsDir": False},
            {"Name": "2026-04-18 Test.settings.toml", "IsDir": False},
        ],
    )

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake):
        staged = stage_source(ref, work_dir=work)

    assert staged.is_staged is True
    assert staged.local_sidecar_path is not None
    assert staged.local_sidecar_path.exists()
    assert staged.local_sidecar_path.name == "2026-04-18 Test.settings.toml"


def test_rclone_source_copies_extra_sidecars(tmp_path: Path):
    """fcpxml etc. landen in extra_sidecars."""
    ref = SourceRef("nas:/Quelle/2026-04-18 Test.mov")
    work = tmp_path / "work"
    work.mkdir()

    fake = _mock_rclone_calls(
        copied_files={
            "nas:/Quelle/2026-04-18 Test.mov": b"v",
            "nas:/Quelle/2026-04-18 Test.fcpxml": b"<xml/>",
            "nas:/Quelle/2026-04-18 Test-fanart.jpg": b"jpg",
        },
        lsjson_entries=[
            {"Name": "2026-04-18 Test.mov", "IsDir": False},
            {"Name": "2026-04-18 Test.fcpxml", "IsDir": False},
            {"Name": "2026-04-18 Test-fanart.jpg", "IsDir": False},
        ],
    )

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake):
        staged = stage_source(ref, work_dir=work)

    extras_names = {p.name for p in staged.extra_sidecars}
    assert extras_names == {"2026-04-18 Test.fcpxml", "2026-04-18 Test-fanart.jpg"}


def test_rclone_source_ignores_unrelated_files(tmp_path: Path):
    """Andere Videos im Parent werden nicht mitkopiert."""
    ref = SourceRef("nas:/Quelle/2026-04-18 Test.mov")
    work = tmp_path / "work"
    work.mkdir()

    fake = _mock_rclone_calls(
        copied_files={
            "nas:/Quelle/2026-04-18 Test.mov": b"v",
        },
        lsjson_entries=[
            {"Name": "2026-04-18 Test.mov", "IsDir": False},
            {"Name": "2026-04-19 Andere.mov", "IsDir": False},
            {"Name": "subdir", "IsDir": True},
        ],
    )

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake):
        staged = stage_source(ref, work_dir=work)

    assert staged.local_sidecar_path is None
    assert staged.extra_sidecars == []


def test_rclone_source_cleanup_removes_stage_dir(tmp_path: Path):
    ref = SourceRef("nas:/Quelle/2026-04-18 Test.mov")
    work = tmp_path / "work"
    work.mkdir()

    fake = _mock_rclone_calls(
        copied_files={"nas:/Quelle/2026-04-18 Test.mov": b"v"},
        lsjson_entries=[{"Name": "2026-04-18 Test.mov", "IsDir": False}],
    )

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake):
        staged = stage_source(ref, work_dir=work)

    stage_dir = staged._stage_dir
    assert stage_dir is not None and stage_dir.exists()

    staged.cleanup()
    assert not stage_dir.exists()


def test_rclone_source_sync_back_via_copyto(tmp_path: Path):
    """sync_sidecar_back ruft rclone copyto → Remote auf."""
    ref = SourceRef("nas:/Quelle/2026-04-18 Test.mov")
    work = tmp_path / "work"
    work.mkdir()

    initial = _mock_rclone_calls(
        copied_files={"nas:/Quelle/2026-04-18 Test.mov": b"v"},
        lsjson_entries=[{"Name": "2026-04-18 Test.mov", "IsDir": False}],
    )

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=initial):
        staged = stage_source(ref, work_dir=work)

    # Publisher hat inzwischen ein Sidecar geschrieben
    local_sidecar = staged._stage_dir / "updated.settings.toml"
    local_sidecar.write_text('[web]\npublished_at = "t"\n', encoding="utf-8")

    captured_args: list[list[str]] = []

    def fake_run(args, **kwargs):
        captured_args.append(args)
        return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        staged.sync_sidecar_back(local_sidecar, runtime=RuntimeOptions())

    # Genau ein copyto-Call, Ziel ist Remote-URI neben dem Original
    assert len(captured_args) == 1
    assert captured_args[0][1] == "copyto"
    assert captured_args[0][2] == str(local_sidecar)
    # Ziel: nas:/Quelle/2026-04-18 Test.settings.toml (gleicher Stem wie Video)
    assert captured_args[0][3] == "nas:/Quelle/2026-04-18 Test.settings.toml"


def test_rclone_source_sync_back_noop_when_no_local_sidecar(tmp_path: Path):
    """Wenn keine lokale Sidecar-Datei existiert, kein Remote-Call."""
    ref = SourceRef("nas:/Quelle/foo.mov")
    work = tmp_path / "work"
    work.mkdir()

    initial = _mock_rclone_calls(
        copied_files={"nas:/Quelle/foo.mov": b"v"},
        lsjson_entries=[{"Name": "foo.mov", "IsDir": False}],
    )

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=initial):
        staged = stage_source(ref, work_dir=work)

    missing_sidecar = staged._stage_dir / "nonexistent.settings.toml"

    with patch("familienfilm_manager.core.source_staging.rclone_copyto") as m:
        staged.sync_sidecar_back(missing_sidecar)

    m.assert_not_called()
