"""Tests für _to_ascii_slug — insb. macOS NFD-Normalisierung."""

import unicodedata

from familienfilm_manager.core.archiver import _to_ascii_slug


def test_german_umlauts_nfc():
    """Umlaute in NFC werden transliteriert."""
    text = unicodedata.normalize("NFC", "Mädchen Schöni Brücke")
    assert _to_ascii_slug(text) == "Maedchen-Schoeni-Bruecke"


def test_german_umlauts_nfd_macos():
    """Umlaute in NFD (macOS-Style) werden ebenfalls transliteriert."""
    # NFD: ä = a + Combining Diaeresis (U+0308)
    text = unicodedata.normalize("NFD", "Mädchen Schöni Brücke")
    # Sicherstellen dass es wirklich NFD ist
    assert "ä" not in text  # NFC-ä nicht direkt enthalten
    result = _to_ascii_slug(text)
    assert result == "Maedchen-Schoeni-Bruecke"


def test_eszett():
    """ß wird zu ss."""
    assert _to_ascii_slug("Straße") == "Strasse"


def test_capital_umlauts():
    """Grosse Umlaute werden korrekt transliteriert."""
    assert _to_ascii_slug("Ärger Über Österreich") == "Aerger-Ueber-Oesterreich"


def test_other_diacritics_stripped():
    """Andere Diakritika (é, à, ñ) werden auf ASCII reduziert."""
    assert _to_ascii_slug("Café à Paris") == "Cafe-a-Paris"


def test_spaces_to_hyphens():
    """Leerzeichen werden zu Bindestrichen."""
    assert _to_ascii_slug("Hello World") == "Hello-World"


def test_special_chars_removed():
    """Sonderzeichen werden zu Bindestrichen."""
    assert _to_ascii_slug("Test & Foo / Bar!") == "Test-Foo-Bar"


def test_multiple_spaces_collapsed():
    """Mehrere Leerzeichen werden zu einem Bindestrich."""
    assert _to_ascii_slug("Foo   Bar") == "Foo-Bar"


def test_strips_leading_trailing_hyphens():
    """Führende/abschliessende Bindestriche werden entfernt."""
    assert _to_ascii_slug("  -Foo-  ") == "Foo"


def test_real_world_example():
    """Der Bug-Report-Fall: 'Viergewinnt-Mädchen' (NFD aus macOS-Filename)."""
    # Simulation eines macOS-Filename-Stems
    text = unicodedata.normalize("NFD", "Viergewinnt Mädchen")
    assert _to_ascii_slug(text) == "Viergewinnt-Maedchen"
