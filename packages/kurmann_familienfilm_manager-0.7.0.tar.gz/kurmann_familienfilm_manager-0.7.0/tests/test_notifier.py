"""Tests für den HTML-Notifier (pending → published/failed, aborted-Migration)."""

from pathlib import Path

from familienfilm_manager.core.notifier import (
    append_pending,
    derive_video_id,
    mark_all_pending_as_aborted,
    replace_entry_failed,
    replace_entry_published,
)


def test_derive_video_id_stable_per_path(tmp_path: Path):
    a = tmp_path / "video.mov"
    b = tmp_path / "video.mov"
    a.touch()
    assert derive_video_id(a) == derive_video_id(b)


def test_derive_video_id_differs_per_path(tmp_path: Path):
    a = tmp_path / "a.mov"; a.touch()
    b = tmp_path / "b.mov"; b.touch()
    assert derive_video_id(a) != derive_video_id(b)


def test_append_pending_creates_file_with_entry(tmp_path: Path):
    path = tmp_path / "notification.html"
    append_pending(path, video_id="abc123", title="Wanderung")

    content = path.read_text()
    assert '<div class="entry pending" data-video-id="abc123">' in content
    assert "Wanderung" in content
    assert "<!-- /entry -->" in content
    assert content.startswith("<!DOCTYPE html>")


def test_append_pending_replaces_existing_entry_with_same_id(tmp_path: Path):
    path = tmp_path / "notification.html"
    append_pending(path, video_id="abc123", title="Alter Titel")
    append_pending(path, video_id="abc123", title="Neuer Titel")

    content = path.read_text()
    # Nur einmal vorhanden (keine Duplikate)
    assert content.count('data-video-id="abc123"') == 1
    assert "Neuer Titel" in content
    assert "Alter Titel" not in content


def test_replace_entry_published_replaces_pending(tmp_path: Path):
    path = tmp_path / "notification.html"
    append_pending(path, video_id="abc123", title="Wanderung")
    replace_entry_published(
        path,
        video_id="abc123",
        title="Wanderung",
        video_url="https://example.com/abc123/",
        category="Familie",
        recording_date="2026-04-18",
    )

    content = path.read_text()
    assert '<div class="entry pending"' not in content
    assert '<div class="entry published" data-video-id="abc123">' in content
    assert 'href="https://example.com/abc123/"' in content
    assert "Familie" in content
    assert "2026-04-18" in content


def test_replace_entry_failed_replaces_pending_with_error(tmp_path: Path):
    path = tmp_path / "notification.html"
    append_pending(path, video_id="abc123", title="Wanderung")
    replace_entry_failed(
        path,
        video_id="abc123",
        title="Wanderung",
        error_message="rclone fehlgeschlagen",
    )

    content = path.read_text()
    assert '<div class="entry failed" data-video-id="abc123">' in content
    assert "rclone fehlgeschlagen" in content


def test_replace_falls_back_to_insert_when_no_pending_exists(tmp_path: Path):
    path = tmp_path / "notification.html"
    replace_entry_published(path, video_id="xyz", title="Neu", video_url="https://e/xyz/")

    content = path.read_text()
    assert '<div class="entry published" data-video-id="xyz">' in content


def test_mark_all_pending_as_aborted(tmp_path: Path):
    path = tmp_path / "notification.html"
    append_pending(path, video_id="a", title="A")
    append_pending(path, video_id="b", title="B")
    # Eines abschliessen → bleibt publiziert, nicht pending
    replace_entry_published(path, video_id="a", title="A", video_url="https://e/a/")

    count = mark_all_pending_as_aborted(path)
    assert count == 1

    content = path.read_text()
    assert '<div class="entry aborted" data-video-id="b">' in content
    assert '<div class="entry published" data-video-id="a">' in content
    # Kein pending mehr
    assert 'class="entry pending"' not in content


def test_mark_all_pending_noop_when_file_missing(tmp_path: Path):
    path = tmp_path / "notification.html"
    assert mark_all_pending_as_aborted(path) == 0
    assert not path.exists()


def test_html_escapes_title_and_url(tmp_path: Path):
    path = tmp_path / "notification.html"
    replace_entry_published(
        path, video_id="x", title='Evil <script>"&',
        video_url='https://e/?q="&x',
    )

    content = path.read_text()
    # Roh-Tag nicht im Entry (HTML-Header enthält keine <script>)
    assert "<script>" not in content
    assert "&lt;script&gt;" in content
    # Quote im href korrekt escaped
    assert 'href="https://e/?q=&quot;&amp;x"' in content
