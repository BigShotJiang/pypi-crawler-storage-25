"""Tests für die rclone-Variante von find_directory_settings (familienfilm.toml via rclone cat)."""

import subprocess
from unittest.mock import patch

from familienfilm_manager.core.directory_settings import find_directory_settings


def _make_rclone_cat_mock(available: dict[str, str]):
    """Mock für subprocess.run, der rclone-Aufrufe simuliert.

    ``available`` mappt rclone-URI → TOML-Inhalt. Andere URIs liefern 'not found'.
    """
    def fake(args, **kwargs):
        if len(args) < 3 or args[1] != "cat":
            raise AssertionError(f"Unexpected rclone command: {args}")
        uri = args[2]
        if uri in available:
            return subprocess.CompletedProcess(
                args=args, returncode=0, stdout=available[uri], stderr="",
            )
        err = subprocess.CalledProcessError(1, args)
        err.stderr = "file not found"
        raise err
    return fake


def test_rclone_settings_found_at_start():
    """Direkte Trefferquote: familienfilm.toml existiert im Start-URI."""
    available = {
        "nas:/Quelle/familienfilm.toml": 'category = "Familie rclone"\n',
    }
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_make_rclone_cat_mock(available),
    ):
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            result = find_directory_settings("nas:/Quelle")

    assert result.category == "Familie rclone"
    assert result.source_uri == "nas:/Quelle/familienfilm.toml"


def test_rclone_settings_inherited_from_parent():
    """Settings im Parent-URI werden gefunden, wenn Kind-URI keine hat."""
    available = {
        # Kein familienfilm.toml in nas:/Quelle/Arbeit — nur in nas:/Quelle
        "nas:/Quelle/familienfilm.toml": 'category = "Familie Parent"\n',
    }
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_make_rclone_cat_mock(available),
    ):
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            result = find_directory_settings("nas:/Quelle/Arbeit")

    assert result.category == "Familie Parent"


def test_rclone_child_settings_overrides_parent():
    """Nächstgelegenes Verzeichnis gewinnt — Child-URI-Settings überschreiben Parent."""
    available = {
        "nas:/Quelle/familienfilm.toml": 'category = "Familie Parent"\n',
        "nas:/Quelle/Arbeit/familienfilm.toml": 'category = "Firma Child"\n',
    }
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_make_rclone_cat_mock(available),
    ):
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            result = find_directory_settings("nas:/Quelle/Arbeit")

    assert result.category == "Firma Child"


def test_rclone_stop_at_limits_upward_search():
    """stop_at-URI begrenzt die Suche — oberhalb wird nicht mehr gesucht."""
    available = {
        # Settings wären im nas:/Quelle gefunden, sind aber über stop_at hinaus
        "nas:/Quelle/familienfilm.toml": 'category = "Sollte NICHT greifen"\n',
    }
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_make_rclone_cat_mock(available),
    ):
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            result = find_directory_settings(
                "nas:/Quelle/Arbeit",
                stop_at="nas:/Quelle/Arbeit",  # stop_at = start → nur dort suchen
            )

    assert result.category is None


def test_rclone_no_settings_anywhere():
    """Keine familienfilm.toml in der Kette → leeres Ergebnis."""
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_make_rclone_cat_mock({}),
    ):
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            result = find_directory_settings("nas:/Quelle/Deep/Nested")

    assert result.category is None
    assert result.source_uri is None


def test_rclone_stops_at_remote_root():
    """Suche terminiert am Remote-Root (nas:) ohne Unendlichkeits-Schleife."""
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_make_rclone_cat_mock({}),
    ):
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            result = find_directory_settings("nas:/a/b/c")
    assert result.category is None
