"""Tests für die neuen rclone-Primitives (cat, lsjson, copyto)."""

import json
import subprocess
from unittest.mock import patch

import pytest

from familienfilm_manager.core._rclone import (
    rclone_cat,
    rclone_copyto,
    rclone_lsjson,
)


def _mock_run_success(stdout: str = "", stderr: str = ""):
    """Erzeugt einen Mock für subprocess.run, der Erfolg simuliert."""
    def fake(args, **kwargs):
        return subprocess.CompletedProcess(args=args, returncode=0, stdout=stdout, stderr=stderr)
    return fake


def _mock_run_failure(stderr: str, returncode: int = 1):
    """Erzeugt einen Mock, der CalledProcessError wirft."""
    def fake(args, **kwargs):
        err = subprocess.CalledProcessError(returncode, args)
        err.stderr = stderr
        raise err
    return fake


# ── rclone_cat ──


def test_rclone_cat_returns_bytes():
    """Erfolg: Datei-Inhalt als Bytes."""
    payload = 'category = "Familie"\n'
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_mock_run_success(stdout=payload),
    ):
        result = rclone_cat("nas:/dir/familienfilm.toml")
    assert result == payload.encode("utf-8")


def test_rclone_cat_returns_none_on_not_found():
    """404-artige Fehlermeldungen → None (statt Exception)."""
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_mock_run_failure("object not found: familienfilm.toml"),
    ):
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            result = rclone_cat("nas:/dir/missing.toml")
    assert result is None


def test_rclone_cat_returns_none_on_does_not_exist():
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_mock_run_failure("file does not exist"),
    ):
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            result = rclone_cat("nas:/foo.toml")
    assert result is None


def test_rclone_cat_reraises_other_errors():
    """Verbindungsfehler etc. werden nach Retry-Exhaustion weitergereicht."""
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_mock_run_failure("connection refused"),
    ):
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            with pytest.raises(subprocess.CalledProcessError):
                rclone_cat("nas:/foo.toml")


def test_rclone_cat_empty_file():
    """Leere Datei → leere Bytes (nicht None)."""
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_mock_run_success(stdout=""),
    ):
        result = rclone_cat("nas:/empty")
    assert result == b""


# ── rclone_lsjson ──


def test_rclone_lsjson_parses_entries():
    entries = [
        {"Path": "a.mov", "Name": "a.mov", "Size": 123, "IsDir": False, "ModTime": "..."},
        {"Path": "subdir", "Name": "subdir", "Size": -1, "IsDir": True, "ModTime": "..."},
    ]
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_mock_run_success(stdout=json.dumps(entries)),
    ):
        result = rclone_lsjson("nas:/dir")
    assert result == entries


def test_rclone_lsjson_recursive_flag():
    """Mit recursive=True wird --recursive an rclone angehängt."""
    captured_args: list[list[str]] = []

    def fake(args, **kwargs):
        captured_args.append(args)
        return subprocess.CompletedProcess(args=args, returncode=0, stdout="[]", stderr="")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake):
        rclone_lsjson("nas:/dir", recursive=True)

    assert "--recursive" in captured_args[0]


def test_rclone_lsjson_non_recursive_omits_flag():
    captured_args: list[list[str]] = []

    def fake(args, **kwargs):
        captured_args.append(args)
        return subprocess.CompletedProcess(args=args, returncode=0, stdout="[]", stderr="")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake):
        rclone_lsjson("nas:/dir", recursive=False)

    assert "--recursive" not in captured_args[0]


def test_rclone_lsjson_empty_output_returns_empty_list():
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_mock_run_success(stdout=""),
    ):
        result = rclone_lsjson("nas:/empty-dir")
    assert result == []


def test_rclone_lsjson_propagates_errors():
    """Fehler (z.B. Verzeichnis existiert nicht) werden nach Retry weitergereicht."""
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_mock_run_failure("directory not found"),
    ):
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            with pytest.raises(subprocess.CalledProcessError):
                rclone_lsjson("nas:/gone")


def test_rclone_lsjson_invalid_json_raises():
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_mock_run_success(stdout="not json"),
    ):
        with pytest.raises(json.JSONDecodeError):
            rclone_lsjson("nas:/dir")


def test_rclone_lsjson_rejects_non_list():
    """Wenn rclone irgendwie ein Objekt statt einer Liste liefert → Fehler."""
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_mock_run_success(stdout='{"foo": "bar"}'),
    ):
        with pytest.raises(ValueError, match="Unerwartete rclone-lsjson-Ausgabe"):
            rclone_lsjson("nas:/dir")


# ── rclone_copyto ──


def test_rclone_copyto_calls_copyto_subcommand():
    captured_args: list[list[str]] = []

    def fake(args, **kwargs):
        captured_args.append(args)
        return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake):
        rclone_copyto("nas:/src/file.toml", "/local/dest.toml")

    assert captured_args[0] == ["rclone", "copyto", "nas:/src/file.toml", "/local/dest.toml"]


def test_rclone_copyto_retries_on_transient_error():
    """copyto nutzt die gleiche Retry-Logik wie andere rclone-Calls."""
    err = subprocess.CalledProcessError(1, ["rclone", "copyto"])
    err.stderr = "connection refused"
    attempts = iter([err, subprocess.CompletedProcess([], 0, "", "")])

    retries: list[int] = []

    def fake(args, **kwargs):
        nxt = next(attempts)
        if isinstance(nxt, subprocess.CalledProcessError):
            raise nxt
        return nxt

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake):
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            rclone_copyto(
                "nas:/src",
                "/dst",
                on_retry=lambda a, m, e: retries.append(a),
            )

    assert retries == [1]  # genau ein Retry vor Erfolg
