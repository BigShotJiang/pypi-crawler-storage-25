"""Integration: run_publish_directory mit rclone-URI-Quelle."""

import json
import subprocess
from pathlib import Path
from unittest.mock import patch

from familienfilm_manager.api.models import (
    PublishResult,
    RuntimeOptions,
    VideoStatusKind,
)
from familienfilm_manager.core.directory_publisher import run_publish_directory


def _make_rclone_mock(
    lsjson_entries: list[dict],
    available_cats: dict[str, str] | None = None,
):
    """Mock für subprocess.run, der lsjson-Listing + cat-Aufrufe simuliert."""
    available_cats = available_cats or {}

    def fake(args, **kwargs):
        cmd = args[1] if len(args) > 1 else ""
        if cmd == "lsjson":
            return subprocess.CompletedProcess(
                args=args, returncode=0, stdout=json.dumps(lsjson_entries), stderr="",
            )
        if cmd == "cat":
            uri = args[2]
            if uri in available_cats:
                return subprocess.CompletedProcess(
                    args=args, returncode=0, stdout=available_cats[uri], stderr="",
                )
            err = subprocess.CalledProcessError(1, args)
            err.stderr = "file not found"
            raise err
        # copyto etc. sollten in diesem Test nicht aufgerufen werden
        raise AssertionError(f"Unerwarteter rclone-Aufruf: {args}")

    return fake


def test_rclone_scan_returns_empty_when_no_candidates(tmp_path: Path):
    """Kein qualifiziertes Video im Remote → leerer Result."""
    rt = RuntimeOptions(
        infuse_target="nas:/i", web_target="nas:/w", archive_target="nas:/a",
    )
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_make_rclone_mock(lsjson_entries=[]),
    ):
        result = run_publish_directory(
            "nas:/Quelle",
            runtime=rt,
            work_dir=tmp_path,
        )

    assert result.success is True
    assert result.videos == []


def test_rclone_scan_requires_work_dir(tmp_path: Path):
    rt = RuntimeOptions(
        infuse_target="nas:/i", web_target="nas:/w", archive_target="nas:/a",
    )
    result = run_publish_directory(
        "nas:/Quelle",
        runtime=rt,
        work_dir=None,  # <-- fehlt absichtlich
    )
    assert result.success is False
    assert "work_dir" in (result.error_message or "")


def test_rclone_dry_run_lists_pending(tmp_path: Path):
    """Dry-Run: Videos werden als PENDING ohne Staging/Publish gelistet."""
    rt = RuntimeOptions(
        infuse_target="nas:/i", web_target="nas:/w", archive_target="nas:/a",
    )
    entries = [
        {"Name": "2026-04-18 A.mov", "Path": "2026-04-18 A.mov", "Size": 1000, "IsDir": False},
        {"Name": "2026-04-19 B.mov", "Path": "2026-04-19 B.mov", "Size": 2000, "IsDir": False},
    ]
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_make_rclone_mock(entries, available_cats={}),
    ):
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            result = run_publish_directory(
                "nas:/Quelle",
                runtime=rt,
                work_dir=tmp_path,
                dry_run=True,
            )

    assert len(result.videos) == 2
    assert all(v.kind == VideoStatusKind.PENDING for v in result.videos)


def test_rclone_light_peek_skips_already_published(tmp_path: Path):
    """Ein Video mit vollem published_at im Sidecar wird per Light-Peek übersprungen."""
    rt = RuntimeOptions(
        infuse_target="nas:/i", web_target="nas:/w", archive_target="nas:/a",
    )
    entries = [
        {"Name": "2026-04-18 Done.mov", "Path": "2026-04-18 Done.mov", "Size": 500, "IsDir": False},
        {"Name": "2026-04-19 Pending.mov", "Path": "2026-04-19 Pending.mov", "Size": 800, "IsDir": False},
    ]
    done_sidecar = """
[web]
web_id = "abc"
published_at = "t1"

[local]
published_at = "t2"

[archive]
published_at = "t3"

[source]
size_bytes = 500
head_sha1 = "x"
"""
    available_cats = {
        "nas:/Quelle/2026-04-18 Done.settings.toml": done_sidecar,
    }
    fake_runs = []

    def fake_run(args, **kwargs):
        fake_runs.append(args)
        return _make_rclone_mock(entries, available_cats=available_cats)(args, **kwargs)

    # Dry-Run + Light-Peek — kein copyto nötig, aber Publisher wird NICHT aufgerufen
    # für 2026-04-18 Done (übersprungen). Für 2026-04-19 Pending wird der Publisher
    # aber aufgerufen (→ mocken wir).
    from familienfilm_manager.core import directory_publisher

    publish_calls = []

    def fake_run_publish(request, runtime, on_event=None):
        publish_calls.append(request)
        return PublishResult(success=True, web_url="https://example.com/x")

    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=fake_run,
    ):
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            with patch.object(directory_publisher, "run_publish", side_effect=fake_run_publish):
                result = run_publish_directory(
                    "nas:/Quelle",
                    runtime=rt,
                    work_dir=tmp_path,
                )

    # 2026-04-18 Done → SKIPPED, 2026-04-19 Pending → PUBLISHED
    skipped = [v for v in result.videos if v.kind == VideoStatusKind.SKIPPED]
    published = [v for v in result.videos if v.kind == VideoStatusKind.PUBLISHED]
    assert len(skipped) == 1
    assert len(published) == 1
    # Publisher wurde nur für das offene Video aufgerufen
    assert len(publish_calls) == 1
    assert publish_calls[0].source_uri == "nas:/Quelle/2026-04-19 Pending.mov"


def test_rclone_scan_size_mismatch_triggers_republish(tmp_path: Path):
    """Sidecar zeigt alte Size → Light-Peek erkennt Neu-Export → nicht skip."""
    rt = RuntimeOptions(
        infuse_target="nas:/i", web_target="nas:/w", archive_target="nas:/a",
    )
    entries = [
        {"Name": "2026-04-18 Grew.mov", "Path": "2026-04-18 Grew.mov", "Size": 2000, "IsDir": False},
    ]
    old_sidecar = """
[web]
web_id = "abc"
published_at = "t1"

[local]
published_at = "t2"

[archive]
published_at = "t3"

[source]
size_bytes = 500
head_sha1 = "x"
"""
    available_cats = {
        "nas:/Quelle/2026-04-18 Grew.settings.toml": old_sidecar,
    }

    from familienfilm_manager.core import directory_publisher

    publish_calls = []

    def fake_run_publish(request, runtime, on_event=None):
        publish_calls.append(request)
        return PublishResult(success=True)

    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_make_rclone_mock(entries, available_cats=available_cats),
    ):
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            with patch.object(directory_publisher, "run_publish", side_effect=fake_run_publish):
                result = run_publish_directory(
                    "nas:/Quelle",
                    runtime=rt,
                    work_dir=tmp_path,
                )

    # Size hat sich geändert (500 → 2000) → Republish, kein Skip
    assert len(publish_calls) == 1
    published = [v for v in result.videos if v.kind == VideoStatusKind.PUBLISHED]
    assert len(published) == 1
