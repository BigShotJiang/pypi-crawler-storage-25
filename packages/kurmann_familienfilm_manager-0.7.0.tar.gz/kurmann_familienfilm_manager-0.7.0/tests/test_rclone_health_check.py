"""Tests für den Post-Deploy Health-Check (rclone lsf nach jedem Deploy)."""

import subprocess
from pathlib import Path
from unittest.mock import patch

from familienfilm_manager.api.models import FamilienfilmStage
from familienfilm_manager.core._rclone import verify_rclone_target_contains
from familienfilm_manager.core.archiver import archive_video
from familienfilm_manager.core.infuse_deployer import deploy_to_infuse
from familienfilm_manager.core.web_deployer import deploy_to_web


# ── verify_rclone_target_contains ──


def _mock_lsf(stdout: str):
    """Gibt ein subprocess.run-Mock zurück, das lsf-Output simuliert."""
    def fake_run(*args, **kwargs):
        return subprocess.CompletedProcess(args=args[0], returncode=0, stdout=stdout, stderr="")
    return fake_run


def test_verify_all_present():
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_mock_lsf("a.tar\nb.tar\nsubdir/\n"),
    ):
        ok, missing = verify_rclone_target_contains("nas:/target", ["a.tar", "subdir"])
    assert ok is True
    assert missing == []


def test_verify_missing_files_reported():
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_mock_lsf("a.tar\n"),
    ):
        ok, missing = verify_rclone_target_contains("nas:/target", ["a.tar", "b.tar", "c.tar"])
    assert ok is False
    assert set(missing) == {"b.tar", "c.tar"}


def test_verify_rclone_failure_counts_as_missing():
    """Wenn rclone lsf selbst scheitert (Remote offline), gelten alle als fehlend."""
    err = subprocess.CalledProcessError(1, ["rclone"])
    err.stderr = "host unreachable"

    def raise_err(*args, **kwargs):
        raise err

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=raise_err):
        ok, missing = verify_rclone_target_contains("nas:/target", ["a.tar"])
    assert ok is False
    assert missing == ["a.tar"]


def test_verify_trailing_slash_in_target_name_normalized():
    """rclone lsf gibt Verzeichnisse mit '/' aus; expected ohne '/' muss trotzdem matchen."""
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_mock_lsf("abc123/\n"),
    ):
        ok, missing = verify_rclone_target_contains("nas:/", ["abc123"])
    assert ok is True
    assert missing == []


# ── infuse deploy + health check ──


def test_infuse_deploy_verifies_files(tmp_path: Path):
    """Nach erfolgreichem rclone copy wird geprüft ob die Dateien im Ziel sind."""
    from familienfilm_manager.api.models import FamilienfilmEvent

    src = tmp_path / "mediaset"
    src.mkdir()
    (src / "Video.mov").write_text("x")
    (src / "Video.nfo").write_text("x")

    events: list[FamilienfilmEvent] = []

    copy_called = [False]
    lsf_output = "Video.mov\nVideo.nfo\n"

    def fake_run(args, **kwargs):
        if args[1] == "copy":
            copy_called[0] = True
            return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")
        if args[1] == "lsf":
            return subprocess.CompletedProcess(args=args, returncode=0, stdout=lsf_output, stderr="")
        raise AssertionError(f"unexpected args: {args}")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        result = deploy_to_infuse(
            source_dir=src,
            infuse_target="nas:/infuse",
            recording_date="2026-04-18",
            on_event=events.append,
        )

    assert result.success is True
    assert copy_called[0] is True
    verified = [e for e in events if e.stage_id == FamilienfilmStage.DEPLOYMENT_VERIFIED]
    assert len(verified) == 1


def test_infuse_deploy_fails_when_files_missing_in_target(tmp_path: Path):
    """rclone sagt 'ok', aber das Ziel zeigt nur eine von zwei Dateien → DEPLOY_FAILED."""
    from familienfilm_manager.api.models import FamilienfilmEvent

    src = tmp_path / "mediaset"
    src.mkdir()
    (src / "Video.mov").write_text("x")
    (src / "Video.nfo").write_text("x")

    events: list[FamilienfilmEvent] = []

    def fake_run(args, **kwargs):
        if args[1] == "copy":
            return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")
        if args[1] == "lsf":
            return subprocess.CompletedProcess(args=args, returncode=0, stdout="Video.mov\n", stderr="")
        raise AssertionError(f"unexpected args: {args}")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        result = deploy_to_infuse(
            source_dir=src,
            infuse_target="nas:/infuse",
            recording_date="2026-04-18",
            on_event=events.append,
        )

    assert result.success is False
    assert "Video.nfo" in (result.error_message or "")
    failed_events = [e for e in events if e.stage_id == FamilienfilmStage.DEPLOY_FAILED]
    assert len(failed_events) == 1


# ── web deploy + health check ──


def test_web_deploy_verifies_web_id_dir(tmp_path: Path):
    from familienfilm_manager.api.models import FamilienfilmEvent

    src = tmp_path / "abcxyz123"
    src.mkdir()

    events: list[FamilienfilmEvent] = []

    def fake_run(args, **kwargs):
        if args[1] == "copy":
            return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")
        if args[1] == "lsf":
            return subprocess.CompletedProcess(args=args, returncode=0, stdout="abcxyz123/\n", stderr="")
        raise AssertionError(f"unexpected args: {args}")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        result = deploy_to_web(
            source_dir=src,
            web_target="webhost:",
            on_event=events.append,
        )

    assert result.success is True
    assert any(e.stage_id == FamilienfilmStage.DEPLOYMENT_VERIFIED for e in events)


# ── archive + health check ──


def test_archive_verifies_tar_in_target(tmp_path: Path):
    from familienfilm_manager.api.models import FamilienfilmEvent

    source = tmp_path / "2026-04-18 Test.mov"
    source.write_bytes(b"video")

    events: list[FamilienfilmEvent] = []

    def fake_run(args, **kwargs):
        if args[1] == "move":
            return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")
        if args[1] == "lsf":
            return subprocess.CompletedProcess(
                args=args, returncode=0, stdout="2026-04-18-Test.tar\n", stderr="",
            )
        raise AssertionError(f"unexpected args: {args}")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        result = archive_video(
            source_path=source,
            archive_target="nas:/archive",
            recording_date="2026-04-18",
            title="Test",
            on_event=events.append,
        )

    assert result.success is True
    assert any(e.stage_id == FamilienfilmStage.DEPLOYMENT_VERIFIED for e in events)
