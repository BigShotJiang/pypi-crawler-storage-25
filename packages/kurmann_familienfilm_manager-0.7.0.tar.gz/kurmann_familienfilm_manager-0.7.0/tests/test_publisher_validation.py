"""Tests für Pre-Validation: aktive Profile brauchen konfigurierte Targets."""

from pathlib import Path

from familienfilm_manager.api.models import (
    PublishRequest,
    RuntimeOptions,
)
from familienfilm_manager.core.directory_publisher import run_publish_directory
from familienfilm_manager.core.publisher import run_publish


def _make_video(tmp_path: Path) -> Path:
    """Hilfsfunktion: erstellt eine Dummy-Videodatei."""
    video = tmp_path / "2026-04-16 Test.mov"
    video.touch()
    return video


# ── run_publish ──


def test_publish_fails_without_web_target(tmp_path: Path):
    """Aktives Web-Profil ohne web_target → Fehler vor Verarbeitung."""
    video = _make_video(tmp_path)
    request = PublishRequest(
        source_path=video,
        skip_infuse=True,
        skip_web=False,  # Web aktiv
        skip_archive=True,
    )
    runtime = RuntimeOptions()  # Keine Targets konfiguriert
    result = run_publish(request, runtime)
    assert result.success is False
    assert "targets.web" in (result.error_message or "")


def test_publish_fails_without_archive_target(tmp_path: Path):
    """Aktives Archive ohne archive_target → Fehler."""
    video = _make_video(tmp_path)
    request = PublishRequest(
        source_path=video,
        skip_infuse=True,
        skip_web=True,
        skip_archive=False,  # Archive aktiv
    )
    runtime = RuntimeOptions()
    result = run_publish(request, runtime)
    assert result.success is False
    assert "targets.archive" in (result.error_message or "")


def test_publish_fails_without_infuse_target(tmp_path: Path):
    """Aktives Infuse ohne infuse_target → Fehler."""
    video = _make_video(tmp_path)
    request = PublishRequest(
        source_path=video,
        skip_infuse=False,  # Infuse aktiv
        skip_web=True,
        skip_archive=True,
    )
    runtime = RuntimeOptions()
    result = run_publish(request, runtime)
    assert result.success is False
    assert "targets.infuse" in (result.error_message or "")


def test_publish_skip_all_passes_validation(tmp_path: Path):
    """Wenn alle Profile übersprungen → keine Target-Validierung."""
    video = _make_video(tmp_path)
    request = PublishRequest(
        source_path=video,
        skip_infuse=True,
        skip_web=True,
        skip_archive=True,
    )
    runtime = RuntimeOptions()
    result = run_publish(request, runtime)
    # Validation passt, aber Verarbeitung scheitert weiter unten (kein Datum etc.)
    # Wichtig: error_message darf NICHT von Target-Validation kommen
    if result.error_message:
        assert "targets." not in result.error_message


def test_publish_combined_targets_in_error(tmp_path: Path):
    """Bei mehreren fehlenden Targets werden alle aufgelistet."""
    video = _make_video(tmp_path)
    request = PublishRequest(source_path=video)  # Defaults: alle Profile aktiv
    runtime = RuntimeOptions()
    result = run_publish(request, runtime)
    assert result.success is False
    assert "targets.infuse" in (result.error_message or "")
    assert "targets.web" in (result.error_message or "")
    assert "targets.archive" in (result.error_message or "")


# ── run_publish_directory ──


def test_publish_directory_fails_early_without_targets(tmp_path: Path):
    """publish-dir bricht früh ab wenn Targets fehlen — kein Scanning."""
    video = _make_video(tmp_path)  # Wäre qualifiziert
    runtime = RuntimeOptions()  # Keine Targets
    result = run_publish_directory(tmp_path, runtime, skip_infuse=True, skip_archive=True)
    # skip_web=False (Default) und kein web_target → früher Fehler
    assert result.success is False
    assert "targets.web" in (result.error_message or "")
    # Wichtig: keine Videos verarbeitet
    assert len(result.videos) == 0


def test_publish_directory_passes_with_skip_flags(tmp_path: Path):
    """Wenn alle Profile übersprungen → keine Target-Validierung im Batch."""
    runtime = RuntimeOptions()
    result = run_publish_directory(
        tmp_path,
        runtime,
        skip_infuse=True,
        skip_web=True,
        skip_archive=True,
    )
    # Validation passt, leeres Verzeichnis → keine Videos
    assert result.success is True
    assert len(result.videos) == 0
