"""Tests für Fingerprint-Persistierung im Sidecar (Size + Head-SHA1)."""

from pathlib import Path

from familienfilm_manager.core.sidecar_manager import (
    HEAD_HASH_BYTES,
    SidecarSettings,
    compute_source_fingerprint,
    read_sidecar,
    write_sidecar,
)


def test_fingerprint_reflects_size_and_head_hash(tmp_path: Path):
    """Fingerprint enthält korrekte Dateigrösse und SHA1 der ersten 1 MB."""
    import hashlib

    f = tmp_path / "video.mov"
    payload = b"A" * (HEAD_HASH_BYTES + 100)  # 1 MB + Rest
    f.write_bytes(payload)

    size, head = compute_source_fingerprint(f)

    assert size == len(payload)
    assert head == hashlib.sha1(payload[:HEAD_HASH_BYTES]).hexdigest()


def test_fingerprint_small_file(tmp_path: Path):
    """Dateien kleiner als 1 MB: Hash über gesamte Datei."""
    import hashlib

    f = tmp_path / "small.mov"
    f.write_bytes(b"tiny")

    size, head = compute_source_fingerprint(f)
    assert size == 4
    assert head == hashlib.sha1(b"tiny").hexdigest()


def test_sidecar_roundtrip_with_fingerprint(tmp_path: Path):
    """Source-Size + Head-SHA1 werden korrekt ins TOML geschrieben und gelesen."""
    video = tmp_path / "video.mov"
    video.touch()

    original = SidecarSettings(
        web_id="abc123456789",
        web_published_at="2026-04-18T10:00:00",
        source_size_bytes=123456789,
        source_head_sha1="deadbeef" * 5,
    )
    write_sidecar(video, original)

    parsed = read_sidecar(video)
    assert parsed.source_size_bytes == 123456789
    assert parsed.source_head_sha1 == "deadbeef" * 5
    assert parsed.web_id == "abc123456789"
    assert parsed.web_published_at == "2026-04-18T10:00:00"


def test_sidecar_without_fingerprint_is_readable(tmp_path: Path):
    """Altes Sidecar ohne [source]-Sektion liefert None für Fingerprint-Felder."""
    video = tmp_path / "video.mov"
    video.touch()

    legacy_sidecar = video.parent / f"{video.stem}.settings.toml"
    legacy_sidecar.write_text(
        '[web]\nweb_id = "abc123456789"\npublished_at = "2026-04-18T10:00:00"\n',
        encoding="utf-8",
    )

    parsed = read_sidecar(video)
    assert parsed.web_id == "abc123456789"
    assert parsed.web_published_at == "2026-04-18T10:00:00"
    assert parsed.source_size_bytes is None
    assert parsed.source_head_sha1 is None


def test_sidecar_roundtrip_with_metadata_category(tmp_path: Path):
    """[metadata].category wird korrekt geschrieben und gelesen — macht das TAR selbsttragend."""
    video = tmp_path / "video.mov"
    video.touch()

    original = SidecarSettings(
        web_id="abc123456789",
        web_published_at="2026-04-18T10:00:00",
        category="Familie Kurmann-Glück",
    )
    write_sidecar(video, original)

    parsed = read_sidecar(video)
    assert parsed.category == "Familie Kurmann-Glück"


# ── Per-Kanal published_at ──


def test_sidecar_roundtrip_all_three_channels(tmp_path: Path):
    """Alle drei Kanäle [web]/[local]/[archive] werden korrekt gelesen/geschrieben."""
    video = tmp_path / "video.mov"
    video.touch()

    original = SidecarSettings(
        web_id="abc123456789",
        web_published_at="2026-04-18T10:00:00",
        local_published_at="2026-04-18T10:01:00",
        archive_published_at="2026-04-18T10:02:00",
    )
    write_sidecar(video, original)

    parsed = read_sidecar(video)
    assert parsed.web_published_at == "2026-04-18T10:00:00"
    assert parsed.local_published_at == "2026-04-18T10:01:00"
    assert parsed.archive_published_at == "2026-04-18T10:02:00"


def test_legacy_pre_channels_flag(tmp_path: Path):
    """is_legacy_pre_channels erkennt alte Sidecars mit nur [web].published_at."""
    video = tmp_path / "video.mov"
    video.touch()

    legacy = SidecarSettings(
        web_id="abc",
        web_published_at="2026-04-18T10:00:00",
        # keine local/archive
    )
    assert legacy.is_legacy_pre_channels is True

    full = SidecarSettings(
        web_published_at="2026-04-18T10:00:00",
        local_published_at="2026-04-18T10:01:00",
        archive_published_at="2026-04-18T10:02:00",
    )
    assert full.is_legacy_pre_channels is False

    empty = SidecarSettings()
    assert empty.is_legacy_pre_channels is False


def test_sidecar_reads_partial_channels(tmp_path: Path):
    """Wenn nur web + local gesetzt sind, bleibt archive_published_at None."""
    video = tmp_path / "video.mov"
    video.touch()

    write_sidecar(video, SidecarSettings(
        web_published_at="t1",
        local_published_at="t2",
    ))

    parsed = read_sidecar(video)
    assert parsed.web_published_at == "t1"
    assert parsed.local_published_at == "t2"
    assert parsed.archive_published_at is None


def test_sidecar_category_with_quotes_is_escaped(tmp_path: Path):
    """Kategorie-Werte mit Anführungszeichen landen korrekt im TOML (ohne Syntax-Bruch)."""
    video = tmp_path / "video.mov"
    video.touch()

    tricky = 'Familie "Kurmann" & Co'
    write_sidecar(video, SidecarSettings(category=tricky))

    parsed = read_sidecar(video)
    assert parsed.category == tricky


def test_sidecar_without_metadata_section_returns_none(tmp_path: Path):
    """Sidecar ohne [metadata]-Sektion: category ist None."""
    video = tmp_path / "video.mov"
    video.touch()

    legacy = video.parent / f"{video.stem}.settings.toml"
    legacy.write_text('[web]\nweb_id = "x"\n', encoding="utf-8")

    parsed = read_sidecar(video)
    assert parsed.category is None
