"""Tests für die Category-Auflösungskette im Publisher.

Priorität: request.category > sidecar.[metadata].category > config.defaults.category > ffprobe.
"""

from pathlib import Path
from unittest.mock import patch

import pytest

from familienfilm_manager.api.models import PublishRequest, RuntimeOptions
from familienfilm_manager.core.sidecar_manager import SidecarSettings, write_sidecar


def _build_request(video: Path, **overrides) -> PublishRequest:
    # skip_web=False, damit der Workflow bis zu create_mediaset durchläuft
    # (sonst greift die "Mindestens ein Profil muss aktiv sein"-Validation).
    # create_mediaset wird gemockt und bricht direkt ab.
    return PublishRequest(
        source_path=video,
        recording_date=overrides.get("recording_date", "2026-04-18"),
        title=overrides.get("title", "Testvideo"),
        category=overrides.get("category"),
        no_sidecar=overrides.get("no_sidecar", False),
        skip_infuse=True,
        skip_web=False,
        skip_archive=True,
    )


def _runtime() -> RuntimeOptions:
    # skip_* setzt alle Profile ab, daher brauchen wir keine Targets zu konfigurieren.
    # Aber der Publisher validiert trotzdem, also geben wir Dummy-Werte.
    return RuntimeOptions(
        infuse_target="nas:/i",
        web_target="nas:/w",
        archive_target="nas:/a",
        ffprobe_path="ffprobe",
    )


@pytest.fixture
def patched_extract_metadata():
    """Patcht extract_metadata so, dass ein kontrollierbarer category-Wert geliefert wird."""
    from familienfilm_manager.core import publisher as pub_mod
    from familienfilm_manager.core.metadata_extractor import VideoMetadata

    def make(category_from_ffprobe: str | None):
        def fake(_path: Path, _ffprobe: str):
            return VideoMetadata(
                title="Testvideo",
                recording_date="2026-04-18",
                description=None,
                category=category_from_ffprobe,
                poster_at=None,
            )

        return patch.object(pub_mod, "extract_metadata", side_effect=fake)

    return make


def _capture_effective_category(
    video: Path,
    request: PublishRequest,
    config_default: str | None,
    patched_extract_metadata,
    ffprobe_category: str | None = None,
) -> str | None:
    """Führt nur bis zur Category-Auflösung + Pre-Mediaset und liest die finale category
    via Mock von create_mediaset, der die effektiv verwendete category als title zurückspiegelt."""
    from familienfilm_manager.api import publish

    captured: dict = {}

    def fake_create_mediaset(req, runtime, on_event=None):  # noqa: ARG001
        captured["category"] = req.category
        # Failure-Return reicht — wir brauchen nur die Auflösung, nicht den Rest.
        from mediaset_creator.api import CreateMediasetResult

        return CreateMediasetResult(success=False, error_message="stop after resolution")

    with patched_extract_metadata(ffprobe_category):
        with patch(
            "familienfilm_manager.core.publisher.create_mediaset",
            side_effect=fake_create_mediaset,
        ):
            with patch(
                "familienfilm_manager.services.config_manager.get",
                side_effect=lambda key: (
                    config_default if key == "defaults.category" else None
                ),
            ):
                with patch(
                    "familienfilm_manager.services.config_manager.get_with_default",
                    side_effect=lambda key: {
                        "sidecar.enabled": "true",
                        "cleanup.web_workdir": "true",
                    }.get(key, ""),
                ):
                    publish(request, _runtime())

    return captured.get("category")


def test_cli_category_wins_over_sidecar_and_config(tmp_path: Path, patched_extract_metadata):
    video = tmp_path / "2026-04-18 Test.mov"
    video.write_bytes(b"x")
    # Sidecar enthält andere Kategorie — darf nicht gewinnen
    write_sidecar(video, SidecarSettings(category="Familie Sidecar"))

    request = _build_request(video, category="Familie CLI")

    effective = _capture_effective_category(
        video, request,
        config_default="Familie Config",
        patched_extract_metadata=patched_extract_metadata,
        ffprobe_category="Familie ffprobe",
    )
    assert effective == "Familie CLI"


def test_sidecar_wins_over_config_and_ffprobe(tmp_path: Path, patched_extract_metadata):
    """Re-Publish aus Archiv: Sidecar-[metadata].category überschreibt Config-Default."""
    video = tmp_path / "2026-04-18 Test.mov"
    video.write_bytes(b"x")
    write_sidecar(video, SidecarSettings(category="Familie Sidecar"))

    request = _build_request(video)  # kein CLI-Override

    effective = _capture_effective_category(
        video, request,
        config_default="Familie Config",
        patched_extract_metadata=patched_extract_metadata,
        ffprobe_category="Familie ffprobe",
    )
    assert effective == "Familie Sidecar"


def test_config_wins_when_no_cli_and_no_sidecar(tmp_path: Path, patched_extract_metadata):
    video = tmp_path / "2026-04-18 Test.mov"
    video.write_bytes(b"x")
    # Kein Sidecar geschrieben

    request = _build_request(video)

    effective = _capture_effective_category(
        video, request,
        config_default="Familie Config",
        patched_extract_metadata=patched_extract_metadata,
        ffprobe_category="Familie ffprobe",
    )
    assert effective == "Familie Config"


def test_ffprobe_is_last_resort(tmp_path: Path, patched_extract_metadata):
    video = tmp_path / "2026-04-18 Test.mov"
    video.write_bytes(b"x")

    request = _build_request(video)

    effective = _capture_effective_category(
        video, request,
        config_default=None,
        patched_extract_metadata=patched_extract_metadata,
        ffprobe_category="Familie ffprobe",
    )
    assert effective == "Familie ffprobe"


def test_empty_when_no_source_has_category(tmp_path: Path, patched_extract_metadata):
    video = tmp_path / "2026-04-18 Test.mov"
    video.write_bytes(b"x")

    request = _build_request(video)

    effective = _capture_effective_category(
        video, request,
        config_default=None,
        patched_extract_metadata=patched_extract_metadata,
        ffprobe_category=None,
    )
    assert effective is None


def test_directory_settings_wins_over_config(tmp_path: Path, patched_extract_metadata):
    """familienfilm.toml im Scan-Root überschreibt defaults.category."""
    video = tmp_path / "2026-04-18 Test.mov"
    video.write_bytes(b"x")
    (tmp_path / "familienfilm.toml").write_text(
        'category = "Familie TOML"\n', encoding="utf-8",
    )

    request = _build_request(video)  # kein CLI, kein Sidecar

    effective = _capture_effective_category(
        video, request,
        config_default="Familie Config",
        patched_extract_metadata=patched_extract_metadata,
        ffprobe_category="Familie ffprobe",
    )
    assert effective == "Familie TOML"


def test_sidecar_still_wins_over_directory_settings(tmp_path: Path, patched_extract_metadata):
    """Sidecar bleibt stärker als familienfilm.toml (Video kennt sich selbst besser)."""
    video = tmp_path / "2026-04-18 Test.mov"
    video.write_bytes(b"x")
    write_sidecar(video, SidecarSettings(category="Familie Sidecar"))
    (tmp_path / "familienfilm.toml").write_text(
        'category = "Familie TOML"\n', encoding="utf-8",
    )

    request = _build_request(video)

    effective = _capture_effective_category(
        video, request,
        config_default=None,
        patched_extract_metadata=patched_extract_metadata,
    )
    assert effective == "Familie Sidecar"


def test_nearest_directory_settings_wins(tmp_path: Path, patched_extract_metadata):
    """In verschachtelten Verzeichnissen gewinnt die nächstgelegene familienfilm.toml."""
    subdir = tmp_path / "Arbeit"
    subdir.mkdir()
    video = subdir / "2026-04-18 Test.mov"
    video.write_bytes(b"x")

    (tmp_path / "familienfilm.toml").write_text(
        'category = "Familie Parent"\n', encoding="utf-8",
    )
    (subdir / "familienfilm.toml").write_text(
        'category = "Firma Child"\n', encoding="utf-8",
    )

    from familienfilm_manager.api.models import PublishRequest

    request = PublishRequest(
        source_path=video,
        recording_date="2026-04-18",
        title="Testvideo",
        skip_infuse=True,
        skip_web=False,
        skip_archive=True,
        scan_root=tmp_path,   # Grenze beim Scan-Root
    )

    effective = _capture_effective_category(
        video, request,
        config_default=None,
        patched_extract_metadata=patched_extract_metadata,
    )
    assert effective == "Firma Child"


def test_scan_root_limits_directory_settings_search(tmp_path: Path, patched_extract_metadata):
    """scan_root begrenzt die Suche nach oben — Settings oberhalb werden ignoriert."""
    scan_root = tmp_path / "scan-root"
    scan_root.mkdir()
    video = scan_root / "2026-04-18 Test.mov"
    video.write_bytes(b"x")

    # Settings oberhalb des scan_root — dürfen NICHT gefunden werden
    (tmp_path / "familienfilm.toml").write_text(
        'category = "Sollte NICHT greifen"\n', encoding="utf-8",
    )

    from familienfilm_manager.api.models import PublishRequest

    request = PublishRequest(
        source_path=video,
        recording_date="2026-04-18",
        title="Testvideo",
        skip_infuse=True,
        skip_web=False,
        skip_archive=True,
        scan_root=scan_root,
    )

    effective = _capture_effective_category(
        video, request,
        config_default="Familie Config",
        patched_extract_metadata=patched_extract_metadata,
    )
    assert effective == "Familie Config"


def test_no_sidecar_flag_disables_sidecar_lookup(tmp_path: Path, patched_extract_metadata):
    """Mit request.no_sidecar=True wird das Sidecar ignoriert — auch für Category."""
    video = tmp_path / "2026-04-18 Test.mov"
    video.write_bytes(b"x")
    write_sidecar(video, SidecarSettings(category="Familie Sidecar"))

    request = _build_request(video, no_sidecar=True)

    effective = _capture_effective_category(
        video, request,
        config_default="Familie Config",
        patched_extract_metadata=patched_extract_metadata,
        ffprobe_category=None,
    )
    assert effective == "Familie Config", "no_sidecar sollte Sidecar-Kategorie ignorieren"
