"""Tests für den Archiver (TAR-interne Dateinamen, work_dir, Sidecar-Separierung)."""

import subprocess
import tarfile
from pathlib import Path
from unittest.mock import patch

from familienfilm_manager.core.archiver import _arcname, archive_video


def test_arcname_video_extension():
    """Stem wird ersetzt, .mov bleibt."""
    result = _arcname(
        Path("/tmp/HDR-Test poster-1s200.mov"),
        source_stem="HDR-Test poster-1s200",
        target_stem="2026-04-16 HDR-Test",
    )
    assert result == "2026-04-16 HDR-Test.mov"


def test_arcname_settings_toml():
    """Mehrteilige Endung .settings.toml wird bewahrt."""
    result = _arcname(
        Path("/tmp/HDR-Test poster-1s200.settings.toml"),
        source_stem="HDR-Test poster-1s200",
        target_stem="2026-04-16 HDR-Test",
    )
    assert result == "2026-04-16 HDR-Test.settings.toml"


def test_arcname_sidecar_with_suffix():
    """Sidecar mit Suffix nach dem Stem (z.B. -poster.jpg) wird korrekt ersetzt."""
    result = _arcname(
        Path("/tmp/HDR-Test poster-1s200-poster.jpg"),
        source_stem="HDR-Test poster-1s200",
        target_stem="2026-04-16 HDR-Test",
    )
    assert result == "2026-04-16 HDR-Test-poster.jpg"


def test_arcname_no_match_keeps_original():
    """Wenn der Datei-Stem nicht passt, wird der Original-Name behalten."""
    result = _arcname(
        Path("/tmp/AnderesVideo.mp4"),
        source_stem="HDR-Test poster-1s200",
        target_stem="2026-04-16 HDR-Test",
    )
    assert result == "AnderesVideo.mp4"


def test_arcname_preserves_umlauts():
    """Umlaute im target_stem bleiben erhalten (Joliet-Kompatibilität)."""
    result = _arcname(
        Path("/tmp/Wanderung Lobbärg poster-2min.mov"),
        source_stem="Wanderung Lobbärg poster-2min",
        target_stem="2026-04-12 Wanderung Lobbärg",
    )
    assert result == "2026-04-12 Wanderung Lobbärg.mov"


# ── archive_video: work_dir + Sidecar-Separierung ──


def _fake_rclone(*args, **kwargs):
    """Mock für rclone-Aufrufe: tut so als wäre alles erfolgreich."""
    args_list = args[0]
    if args_list[1] == "lsf":
        # Health-Check: simuliere dass die Archiv-Dateien im Ziel sind.
        # Wir geben alle möglichen Namen aus, damit der Check passt.
        return subprocess.CompletedProcess(
            args=args_list, returncode=0,
            stdout="dummy.tar\ndummy.settings.toml\n",  # wird gleich überschrieben
            stderr="",
        )
    # move/copy/copyto: Erfolg
    return subprocess.CompletedProcess(args=args_list, returncode=0, stdout="", stderr="")


def test_tar_created_in_work_dir(tmp_path: Path):
    """Wenn work_dir gesetzt ist, landet das TAR dort — nicht in der Quelle."""
    source = tmp_path / "source-dir"
    source.mkdir()
    video = source / "2026-04-18 Test.mov"
    video.write_bytes(b"video-bytes")

    work = tmp_path / "work"

    tar_paths_captured: list[Path] = []

    def tracking_rclone(*args, **kwargs):
        args_list = args[0]
        if args_list[1] == "move":
            tar_paths_captured.append(Path(args_list[2]))
        if args_list[1] == "lsf":
            names = [p.name for p in tar_paths_captured]
            return subprocess.CompletedProcess(
                args=args_list, returncode=0,
                stdout="\n".join(names) + "\n",
                stderr="",
            )
        return subprocess.CompletedProcess(args=args_list, returncode=0, stdout="", stderr="")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=tracking_rclone):
        result = archive_video(
            source_path=video,
            archive_target="nas:/archive",
            recording_date="2026-04-18",
            title="Test",
            work_dir=work,
        )

    assert result.success is True, result.error_message
    # Das TAR wurde im work_dir erstellt (existiert als Argument von rclone move)
    assert tar_paths_captured[0].parent == work
    # Nicht in der Quelle
    assert not (source / "2026-04-18-Test.tar").exists()


def test_tar_falls_back_to_source_when_no_work_dir(tmp_path: Path):
    """Ohne work_dir landet das TAR im Quellverzeichnis (rückwärtskompatibel)."""
    source = tmp_path / "source-dir"
    source.mkdir()
    video = source / "2026-04-18 Test.mov"
    video.write_bytes(b"x")

    tar_paths_captured: list[Path] = []

    def tracking_rclone(*args, **kwargs):
        args_list = args[0]
        if args_list[1] == "move":
            tar_paths_captured.append(Path(args_list[2]))
        if args_list[1] == "lsf":
            names = [p.name for p in tar_paths_captured]
            return subprocess.CompletedProcess(
                args=args_list, returncode=0,
                stdout="\n".join(names) + "\n",
                stderr="",
            )
        return subprocess.CompletedProcess(args=args_list, returncode=0, stdout="", stderr="")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=tracking_rclone):
        archive_video(
            source_path=video,
            archive_target="nas:/archive",
            recording_date="2026-04-18",
            title="Test",
            work_dir=None,
        )

    assert tar_paths_captured[0].parent == source


def test_settings_sidecar_not_in_tar_but_copied_separately(tmp_path: Path):
    """`.settings.toml` landet NICHT im TAR, sondern wird separat per rclone copyto gesendet."""
    source = tmp_path / "source-dir"
    source.mkdir()
    video = source / "2026-04-18 Test.mov"
    video.write_bytes(b"video")
    settings = source / "2026-04-18 Test.settings.toml"
    settings.write_text('[web]\nweb_id = "abc"\n', encoding="utf-8")

    work = tmp_path / "work"
    tar_created_at: list[Path] = []
    rclone_calls: list[list[str]] = []

    def tracking_rclone(*args, **kwargs):
        args_list = args[0]
        rclone_calls.append(args_list)
        if args_list[1] == "move":
            tar_created_at.append(Path(args_list[2]))
        if args_list[1] == "lsf":
            return subprocess.CompletedProcess(
                args=args_list, returncode=0,
                stdout="2026-04-18-Test.tar\n2026-04-18-Test.settings.toml\n",
                stderr="",
            )
        return subprocess.CompletedProcess(args=args_list, returncode=0, stdout="", stderr="")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=tracking_rclone):
        # Wir müssen das TAR inspizieren bevor rclone es wegbewegt. Also legen wir es
        # parallel an und prüfen nach dem Aufruf. Da unser Mock die Datei nicht
        # wirklich moved, bleibt das TAR im work_dir liegen — können wir inspizieren.
        result = archive_video(
            source_path=video,
            archive_target="nas:/archive",
            recording_date="2026-04-18",
            title="Test",
            work_dir=work,
        )

    assert result.success is True, result.error_message

    # TAR sollte im work_dir liegen (Mock hat kein echtes move gemacht)
    tar_path = work / "2026-04-18-Test.tar"
    assert tar_path.exists(), f"TAR nicht gefunden in {work}"

    # TAR-Inhalt prüfen: NUR das Video, KEINE .settings.toml
    with tarfile.open(tar_path, "r") as tf:
        names = tf.getnames()
    assert "2026-04-18 Test.mov" in names
    assert not any(n.endswith(".settings.toml") for n in names), (
        f"settings.toml darf nicht im TAR sein: {names}"
    )

    # Separater rclone copyto-Aufruf für das Sidecar muss erfolgt sein
    copyto_calls = [c for c in rclone_calls if c[1] == "copyto"]
    assert len(copyto_calls) == 1, f"Genau 1 copyto-Call erwartet, got: {rclone_calls}"
    # Zieldatei ist neben dem TAR mit passenden Namen
    assert copyto_calls[0][3] == "nas:/archive/2026-04-18-Test.settings.toml"


def test_non_settings_sidecars_still_in_tar(tmp_path: Path):
    """Andere Sidecar-Typen (z.B. .fcpxml) bleiben weiter im TAR."""
    source = tmp_path / "source-dir"
    source.mkdir()
    video = source / "2026-04-18 Test.mov"
    video.write_bytes(b"video")
    # Simuliere ein Produktions-Sidecar (nicht .settings.toml)
    fcpxml = source / "2026-04-18 Test.fcpxml"
    fcpxml.write_text("<xml/>", encoding="utf-8")

    work = tmp_path / "work"

    def fake_rclone(*args, **kwargs):
        args_list = args[0]
        if args_list[1] == "lsf":
            return subprocess.CompletedProcess(
                args=args_list, returncode=0, stdout="2026-04-18-Test.tar\n", stderr="",
            )
        return subprocess.CompletedProcess(args=args_list, returncode=0, stdout="", stderr="")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_rclone):
        result = archive_video(
            source_path=video,
            archive_target="nas:/archive",
            recording_date="2026-04-18",
            title="Test",
            work_dir=work,
        )

    assert result.success is True, result.error_message

    tar_path = work / "2026-04-18-Test.tar"
    with tarfile.open(tar_path, "r") as tf:
        names = tf.getnames()
    assert "2026-04-18 Test.mov" in names
    assert "2026-04-18 Test.fcpxml" in names, f"fcpxml sollte im TAR sein: {names}"
