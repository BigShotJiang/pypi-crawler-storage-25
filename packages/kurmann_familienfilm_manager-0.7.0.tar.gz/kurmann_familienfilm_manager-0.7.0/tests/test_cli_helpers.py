"""Tests für CLI-Helfer (_resolve_work_dir, _parse_duration, _resolve_watch_directories)."""

from pathlib import Path
from unittest.mock import patch

import pytest

from familienfilm_manager.cli.main import (
    _parse_duration,
    _resolve_watch_directories,
    _resolve_work_dir,
)


def test_resolve_work_dir_cli_wins():
    """CLI-Wert hat höchste Priorität."""
    cli_dir = Path("/lokal/tmp")
    with patch("familienfilm_manager.cli.main.config_manager.get", return_value="/config/work"):
        result = _resolve_work_dir(cli_dir)
    assert result == cli_dir


def test_resolve_work_dir_falls_back_to_config():
    """Wenn CLI None, wird Config gelesen."""
    with patch("familienfilm_manager.cli.main.config_manager.get", return_value="/config/work"):
        result = _resolve_work_dir(None)
    assert result == Path("/config/work")


def test_resolve_work_dir_expands_user():
    """Tilde im Config-Pfad wird zu Home-Verzeichnis expandiert."""
    with patch("familienfilm_manager.cli.main.config_manager.get", return_value="~/scratch"):
        result = _resolve_work_dir(None)
    assert result is not None
    assert "~" not in str(result)


def test_resolve_work_dir_returns_none_when_neither_set():
    """Ohne CLI und ohne Config → None (Publisher fällt auf Quellverzeichnis)."""
    with patch("familienfilm_manager.cli.main.config_manager.get", return_value=None):
        result = _resolve_work_dir(None)
    assert result is None


def test_resolve_work_dir_empty_config_returns_none():
    """Leerer Config-String wird wie None behandelt."""
    with patch("familienfilm_manager.cli.main.config_manager.get", return_value=""):
        result = _resolve_work_dir(None)
    assert result is None


# ── _parse_duration ──


@pytest.mark.parametrize("value,expected", [
    ("30", 30),
    ("600", 600),
    ("30s", 30),
    ("5m", 300),
    ("1h", 3600),
    ("24h", 86400),
    ("1d", 86400),
    ("0.5h", 1800),
])
def test_parse_duration_valid(value: str, expected: int):
    assert _parse_duration(value) == expected


@pytest.mark.parametrize("value", ["", "abc", "10x", "h", "-"])
def test_parse_duration_rejects_invalid(value: str):
    with pytest.raises(ValueError):
        _parse_duration(value)


# ── _resolve_watch_directories ──


def test_resolve_watch_directories_cli_wins():
    cli_dirs = [Path("/a"), Path("/b")]
    with patch("familienfilm_manager.cli.main.config_manager.get", return_value="/x,/y"):
        result = _resolve_watch_directories(cli_dirs)
    assert result == cli_dirs


def test_resolve_watch_directories_from_config():
    with patch(
        "familienfilm_manager.cli.main.config_manager.get",
        return_value="/one, /two ,/three",
    ):
        result = _resolve_watch_directories(None)
    assert result == [Path("/one"), Path("/two"), Path("/three")]


def test_resolve_watch_directories_empty():
    with patch("familienfilm_manager.cli.main.config_manager.get", return_value=None):
        result = _resolve_watch_directories(None)
    assert result == []


def test_resolve_watch_directories_expands_user():
    with patch("familienfilm_manager.cli.main.config_manager.get", return_value="~/Movies"):
        result = _resolve_watch_directories(None)
    assert len(result) == 1
    assert "~" not in str(result[0])


def test_resolve_watch_directories_accepts_rclone_uri_from_config():
    """rclone-URIs aus Config (ab v0.7.0) bleiben als String erhalten."""
    with patch(
        "familienfilm_manager.cli.main.config_manager.get",
        return_value="lyssach-nas:/Quelle,/lokal/pfad",
    ):
        result = _resolve_watch_directories(None)
    # rclone als String, lokal als Path
    assert result[0] == "lyssach-nas:/Quelle"
    assert isinstance(result[1], Path)
    assert str(result[1]) == "/lokal/pfad"


def test_resolve_watch_directories_accepts_rclone_uri_from_cli():
    """rclone-URIs via CLI (-d) werden als String durchgereicht."""
    result = _resolve_watch_directories(["nas:/Quelle"])
    assert result == ["nas:/Quelle"]


# Category-Auflösung ist jetzt Aufgabe des Publishers (request → sidecar → config → ffprobe);
# die CLI reicht den CLI-Wert einfach durch. Siehe tests/test_publisher_category.py.
