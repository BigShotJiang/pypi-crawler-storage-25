"""Tests, dass Deploy-Fehler aktive Events feuern (statt still zu schlucken)."""

import subprocess
from pathlib import Path
from unittest.mock import patch

from familienfilm_manager.api.models import (
    FamilienfilmEvent,
    FamilienfilmStage,
)
from familienfilm_manager.core.archiver import archive_video
from familienfilm_manager.core.infuse_deployer import deploy_to_infuse
from familienfilm_manager.core.web_deployer import deploy_to_web


def _collect_events():
    events: list[FamilienfilmEvent] = []
    return events, events.append


def _fail_all_rclone_runs(stderr: str = "connection refused"):
    """Patch subprocess.run so each rclone call raises CalledProcessError."""
    err = subprocess.CalledProcessError(1, ["rclone"])
    err.stderr = stderr

    def raise_err(*args, **kwargs):
        raise err

    return patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=raise_err,
    )


# ── infuse ──


def test_deploy_to_infuse_fires_deploy_failed_on_exhausted_retries(tmp_path: Path):
    source = tmp_path / "infuse-src"
    source.mkdir()
    (source / "dummy.nfo").write_text("x")

    events, on_event = _collect_events()

    with _fail_all_rclone_runs():
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            result = deploy_to_infuse(
                source_dir=source,
                infuse_target="nas:/target",
                recording_date="2026-04-18",
                on_event=on_event,
            )

    assert result.success is False
    assert "Infuse-Deployment fehlgeschlagen" in (result.error_message or "")
    # Retry-Events (3x) + 1x DEPLOY_FAILED am Ende
    retry_events = [e for e in events if e.stage_id == FamilienfilmStage.DEPLOY_RETRY]
    failed_events = [e for e in events if e.stage_id == FamilienfilmStage.DEPLOY_FAILED]
    assert len(retry_events) == 3
    assert len(failed_events) == 1
    assert "connection refused" in failed_events[0].message


def test_deploy_to_infuse_retries_then_succeeds(tmp_path: Path):
    """Bei Erfolg im 2. Versuch: DEPLOY_RETRY-Event + INFUSE_DEPLOYED-Event."""
    source = tmp_path / "infuse-src"
    source.mkdir()

    err = subprocess.CalledProcessError(1, ["rclone"])
    err.stderr = "flaky"
    attempts = iter([err, subprocess.CompletedProcess([], 0, "", "")])

    def fake_run(*args, **kwargs):
        r = next(attempts)
        if isinstance(r, subprocess.CalledProcessError):
            raise r
        return r

    events, on_event = _collect_events()

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            result = deploy_to_infuse(
                source_dir=source,
                infuse_target="nas:/target",
                recording_date="2026-04-18",
                on_event=on_event,
            )

    assert result.success is True
    assert any(e.stage_id == FamilienfilmStage.DEPLOY_RETRY for e in events)
    assert any(e.stage_id == FamilienfilmStage.INFUSE_DEPLOYED for e in events)
    assert not any(e.stage_id == FamilienfilmStage.DEPLOY_FAILED for e in events)


# ── web ──


def test_deploy_to_web_fires_deploy_failed_on_exhausted_retries(tmp_path: Path):
    source = tmp_path / "abcxyz"
    source.mkdir()

    events, on_event = _collect_events()

    with _fail_all_rclone_runs():
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            result = deploy_to_web(
                source_dir=source,
                web_target="webhost:",
                on_event=on_event,
            )

    assert result.success is False
    assert any(e.stage_id == FamilienfilmStage.DEPLOY_FAILED for e in events)


# ── archive ──


def test_archive_fires_deploy_failed_and_preserves_tar(tmp_path: Path):
    """Bei fehlgeschlagenem rclone move bleibt das TAR lokal erhalten."""
    source = tmp_path / "2026-04-18 Test.mov"
    source.write_bytes(b"video-bytes")

    events, on_event = _collect_events()

    with _fail_all_rclone_runs():
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            result = archive_video(
                source_path=source,
                archive_target="nas:/archive",
                recording_date="2026-04-18",
                title="Test",
                on_event=on_event,
            )

    assert result.success is False
    failed_events = [e for e in events if e.stage_id == FamilienfilmStage.DEPLOY_FAILED]
    assert len(failed_events) == 1
    # Path zum TAR im Event-Message und im Result
    assert result.archive_path is not None
    assert result.archive_path.exists(), "TAR soll bei Deploy-Fehler lokal erhalten bleiben"
    assert str(result.archive_path) in failed_events[0].message
    assert "rclone move" in failed_events[0].message
