"""Tests für den Verzeichnis-Publisher (Filter, Sortierung, Skip-Logik)."""

from datetime import datetime
from pathlib import Path

from familienfilm_manager.core.directory_publisher import (
    _date_from_filename,
    _filter_stable_videos,
    _is_already_published,
    _is_qualified_video,
    _scan_directory,
)
from familienfilm_manager.core.sidecar_manager import (
    SidecarSettings,
    compute_source_fingerprint,
    write_sidecar,
)


def _write_published_sidecar(video_path: Path, **overrides) -> None:
    """Hilfsfunktion: schreibt ein Sidecar für ein voll publiziertes Video
    (alle drei Kanäle + Fingerprint).

    Ab v0.6.0 braucht der Skip-Check auf allen aktiven Kanälen einen
    ``published_at`` — deshalb werden web/local/archive alle gesetzt.
    """
    size, head = compute_source_fingerprint(video_path)
    now_iso = datetime.now().isoformat(timespec="seconds")
    settings = SidecarSettings(
        web_id=overrides.get("web_id", "a3xk9mn2pqrw"),
        web_published_at=overrides.get("web_published_at", now_iso),
        local_published_at=overrides.get("local_published_at", now_iso),
        archive_published_at=overrides.get("archive_published_at", now_iso),
        source_size_bytes=overrides.get("source_size_bytes", size),
        source_head_sha1=overrides.get("source_head_sha1", head),
    )
    write_sidecar(video_path, settings)


# ── _is_qualified_video: Filter ──


def test_qualified_video_with_date_prefix(tmp_path: Path):
    """Datei mit Datum-Präfix und .mov-Endung ist qualifiziert."""
    f = tmp_path / "2026-04-16 HDR-Test.mov"
    f.touch()
    assert _is_qualified_video(f) is True


def test_qualified_video_mp4(tmp_path: Path):
    """Auch .mp4 ist qualifiziert."""
    f = tmp_path / "2026-04-12 Wanderung.mp4"
    f.touch()
    assert _is_qualified_video(f) is True


def test_unqualified_no_date_prefix(tmp_path: Path):
    """Ohne Datum-Präfix → nicht qualifiziert."""
    f = tmp_path / "HDR-Test.mov"
    f.touch()
    assert _is_qualified_video(f) is False


def test_unqualified_unknown_extension(tmp_path: Path):
    """Unbekannte Endung → nicht qualifiziert."""
    f = tmp_path / "2026-04-16 Test.txt"
    f.touch()
    assert _is_qualified_video(f) is False


def test_unqualified_hidden_file(tmp_path: Path):
    """Hidden Files (mit .) werden ignoriert."""
    f = tmp_path / ".2026-04-16 Test.mov"
    f.touch()
    assert _is_qualified_video(f) is False


def test_unqualified_directory(tmp_path: Path):
    """Verzeichnis ist nicht qualifiziert (auch wenn Name passt)."""
    d = tmp_path / "2026-04-16 Verzeichnis.mov"
    d.mkdir()
    assert _is_qualified_video(d) is False


# ── _date_from_filename ──


def test_date_extraction(tmp_path: Path):
    """Datum wird korrekt aus Stem extrahiert."""
    assert _date_from_filename(Path("/tmp/2026-04-16 Test.mov")) == "2026-04-16"


def test_date_extraction_with_poster_suffix(tmp_path: Path):
    """Auch mit Poster-Suffix wird das Datum korrekt extrahiert."""
    assert _date_from_filename(Path("/tmp/2026-04-12 Test poster-1min30.mov")) == "2026-04-12"


# ── _scan_directory: Sortierung ──


def test_scan_sorts_by_date_oldest_first(tmp_path: Path):
    """Videos werden chronologisch sortiert (älteste zuerst)."""
    (tmp_path / "2026-04-16 C.mov").touch()
    (tmp_path / "2026-04-12 A.mov").touch()
    (tmp_path / "2026-04-14 B.mov").touch()

    result = _scan_directory(tmp_path)
    names = [p.name for p in result]
    assert names == ["2026-04-12 A.mov", "2026-04-14 B.mov", "2026-04-16 C.mov"]


def test_scan_ignores_unqualified_files(tmp_path: Path):
    """Unqualifizierte Dateien werden ignoriert."""
    (tmp_path / "2026-04-16 Valid.mov").touch()
    (tmp_path / "Invalid.mov").touch()
    (tmp_path / "2026-04-15 Notes.txt").touch()

    result = _scan_directory(tmp_path)
    names = [p.name for p in result]
    assert names == ["2026-04-16 Valid.mov"]


def test_scan_empty_directory(tmp_path: Path):
    """Leeres Verzeichnis → leere Liste."""
    assert _scan_directory(tmp_path) == []


def test_scan_same_date_alphabetical(tmp_path: Path):
    """Bei gleichem Datum → alphabetisch."""
    (tmp_path / "2026-04-16 Z-Video.mov").touch()
    (tmp_path / "2026-04-16 A-Video.mov").touch()

    result = _scan_directory(tmp_path)
    names = [p.name for p in result]
    assert names == ["2026-04-16 A-Video.mov", "2026-04-16 Z-Video.mov"]


# ── _scan_directory: recursive ──


def test_recursive_scan_finds_videos_in_subdirectories(tmp_path: Path):
    """Mit recursive=True werden Unterverzeichnisse mitgescannt."""
    (tmp_path / "2026-04-16 Root.mov").touch()
    sub = tmp_path / "2026" / "Q2"
    sub.mkdir(parents=True)
    (sub / "2026-04-17 Deep.mov").touch()

    result_flat = _scan_directory(tmp_path, recursive=False)
    result_recursive = _scan_directory(tmp_path, recursive=True)

    assert {p.name for p in result_flat} == {"2026-04-16 Root.mov"}
    assert {p.name for p in result_recursive} == {
        "2026-04-16 Root.mov",
        "2026-04-17 Deep.mov",
    }


def test_recursive_scan_skips_hidden_subdirectories(tmp_path: Path):
    """Hidden-Verzeichnisse (.Trashes etc.) werden bei recursive=True ignoriert."""
    trashes = tmp_path / ".Trashes"
    trashes.mkdir()
    (trashes / "2026-04-10 Alt.mov").touch()
    (tmp_path / "2026-04-16 Neu.mov").touch()

    result = _scan_directory(tmp_path, recursive=True)
    assert [p.name for p in result] == ["2026-04-16 Neu.mov"]


def test_recursive_scan_sorts_across_subdirectories(tmp_path: Path):
    """Bei recursive werden Videos über Verzeichnisgrenzen chronologisch sortiert."""
    (tmp_path / "2026-04-18 C.mov").touch()
    sub = tmp_path / "Unterverzeichnis"
    sub.mkdir()
    (sub / "2026-04-12 A.mov").touch()
    (sub / "2026-04-15 B.mov").touch()

    result = _scan_directory(tmp_path, recursive=True)
    names = [p.name for p in result]
    assert names == ["2026-04-12 A.mov", "2026-04-15 B.mov", "2026-04-18 C.mov"]


# ── _is_already_published: Skip-Logik ──


def test_not_published_no_sidecar(tmp_path: Path):
    """Ohne Sidecar → noch nicht publiziert."""
    f = tmp_path / "2026-04-16 Test.mov"
    f.touch()
    skip, ts = _is_already_published(f)
    assert skip is False
    assert ts is None


def test_not_published_no_published_at(tmp_path: Path):
    """Sidecar ohne published_at → noch nicht publiziert."""
    f = tmp_path / "2026-04-16 Test.mov"
    f.touch()
    write_sidecar(f, SidecarSettings(web_id="a3xk9mn2pqrw"))
    skip, ts = _is_already_published(f)
    assert skip is False


def test_already_published_unchanged(tmp_path: Path):
    """Sidecar mit published_at + matchendem Fingerprint → skip."""
    f = tmp_path / "2026-04-16 Test.mov"
    f.write_bytes(b"video-bytes-v1")
    _write_published_sidecar(f)

    skip, ts = _is_already_published(f)
    assert skip is True
    assert ts is not None


def test_video_content_changed(tmp_path: Path):
    """Video-Inhalt (Bytes/Size) wurde geändert → republish."""
    f = tmp_path / "2026-04-16 Test.mov"
    f.write_bytes(b"video-bytes-v1")
    _write_published_sidecar(f)

    # Inhalt ändern (unterschiedliche Size)
    f.write_bytes(b"video-bytes-v2-different-length")

    skip, ts = _is_already_published(f)
    assert skip is False


def test_video_head_changed_same_size(tmp_path: Path):
    """Video-Kopf wurde geändert, Size identisch → republish (Hash erkennt Unterschied)."""
    f = tmp_path / "2026-04-16 Test.mov"
    original = b"ORIGINAL-HEAD-content-padding"
    f.write_bytes(original)
    _write_published_sidecar(f)

    # Gleiche Länge, anderer Inhalt am Kopf
    modified = b"MODIFIED-HEAD-content-padding"
    assert len(modified) == len(original)
    f.write_bytes(modified)

    skip, ts = _is_already_published(f)
    assert skip is False


def test_mtime_change_does_not_trigger_republish(tmp_path: Path):
    """Nur mtime ändert sich (z.B. Spotlight, SMB-Resync), Inhalt identisch → skip bleibt."""
    import os as _os

    f = tmp_path / "2026-04-16 Test.mov"
    f.write_bytes(b"video-bytes-v1")
    _write_published_sidecar(f)

    # mtime in die Zukunft setzen (simuliert externe Timestamp-Veränderung)
    future_ts = datetime.now().timestamp() + 3600
    _os.utime(f, (future_ts, future_ts))

    skip, ts = _is_already_published(f)
    assert skip is True, "mtime-Änderung darf keinen Republish auslösen, wenn Inhalt gleich ist"


def test_legacy_sidecar_without_fingerprint(tmp_path: Path):
    """Altes Sidecar ohne Fingerprint (aus ≤ 0.5.0) → einmaliger Republish."""
    f = tmp_path / "2026-04-16 Test.mov"
    f.write_bytes(b"video-bytes-v1")
    # Sidecar wie vor 0.6.0: nur web_published_at, kein source_size/head
    write_sidecar(f, SidecarSettings(
        web_id="a3xk9mn2pqrw",
        web_published_at=datetime.now().isoformat(timespec="seconds"),
    ))

    skip, ts = _is_already_published(f)
    assert skip is False, "Legacy-Sidecars ohne Fingerprint sollen einmalig republizieren"
    assert ts is not None


def test_legacy_sidecar_only_web_channel_triggers_republish(tmp_path: Path):
    """Sidecar aus ≤ 0.6.0-RC (nur [web].published_at, kein [local]/[archive])
    → einmaliger voller Republish, der alle drei Kanäle füllt."""
    from familienfilm_manager.core.sidecar_manager import compute_source_fingerprint

    f = tmp_path / "2026-04-16 Test.mov"
    f.write_bytes(b"x")
    size, head = compute_source_fingerprint(f)

    write_sidecar(f, SidecarSettings(
        web_id="a3xk9mn2pqrw",
        web_published_at=datetime.now().isoformat(timespec="seconds"),
        source_size_bytes=size,
        source_head_sha1=head,
        # Kein local_published_at, kein archive_published_at → Legacy
    ))

    skip, ts = _is_already_published(f)
    assert skip is False
    assert ts is not None, "Alter web-Zeitstempel wird zurückgemeldet (für Info)"


def test_skip_only_when_all_channels_published(tmp_path: Path):
    """Skip greift nur wenn alle drei Kanäle published_at haben."""
    f = tmp_path / "2026-04-16 Test.mov"
    f.write_bytes(b"x")

    # Nur Web + Local, kein Archive → kein Skip
    _write_published_sidecar(f, archive_published_at=None)
    skip, _ = _is_already_published(f)
    assert skip is False

    # Alle drei → Skip
    _write_published_sidecar(f)
    skip, _ = _is_already_published(f)
    assert skip is True


def test_skip_respects_inactive_channels(tmp_path: Path):
    """Wenn ein Kanal deaktiviert ist (skip_*), wird sein published_at nicht verlangt."""
    f = tmp_path / "2026-04-16 Test.mov"
    f.write_bytes(b"x")

    # Nur web und local publiziert, archive fehlt
    _write_published_sidecar(f, archive_published_at=None)

    # Default: archive required → kein Skip
    skip, _ = _is_already_published(f)
    assert skip is False

    # Mit skip_archive: archive nicht required → Skip greift
    skip, _ = _is_already_published(f, requires_archive=False)
    assert skip is True


def test_partial_failure_leads_to_republish(tmp_path: Path):
    """Teilerfolg (Web ok, Local fehlgeschlagen) → beim nächsten Lauf Republish."""
    from familienfilm_manager.core.sidecar_manager import compute_source_fingerprint

    f = tmp_path / "2026-04-16 Test.mov"
    f.write_bytes(b"x")
    size, head = compute_source_fingerprint(f)

    # Simuliere Zustand nach Partial Failure
    write_sidecar(f, SidecarSettings(
        web_id="a3xk9mn2pqrw",
        web_published_at=datetime.now().isoformat(timespec="seconds"),
        # local_published_at FEHLT (Deploy fehlgeschlagen)
        archive_published_at=datetime.now().isoformat(timespec="seconds"),
        source_size_bytes=size,
        source_head_sha1=head,
    ))

    skip, _ = _is_already_published(f)
    assert skip is False, "Partial failure (local fehlt) muss Republish triggern"


# ── _filter_stable_videos ──


def test_stability_filter_disabled_when_window_zero(tmp_path: Path):
    """Bei stability_window_seconds=0 werden alle Kandidaten sofort durchgereicht."""
    a = tmp_path / "2026-04-16 A.mov"
    a.write_bytes(b"x" * 100)
    b = tmp_path / "2026-04-17 B.mov"
    b.write_bytes(b"y" * 200)

    stable, unstable = _filter_stable_videos([a, b], stability_window_seconds=0, on_event=None)
    assert stable == [a, b]
    assert unstable == []


def test_stability_filter_detects_growing_file(tmp_path: Path, monkeypatch):
    """Eine Datei, die zwischen den beiden Messungen wächst, landet in 'unstable'."""
    import familienfilm_manager.core.directory_publisher as dp

    stable_file = tmp_path / "2026-04-16 Stable.mov"
    stable_file.write_bytes(b"x" * 100)

    growing_file = tmp_path / "2026-04-17 Growing.mov"
    growing_file.write_bytes(b"y" * 100)

    def fake_sleep(_seconds: int) -> None:
        # Simuliere, dass während der Wartezeit der Export weitergeschrieben wird.
        growing_file.write_bytes(b"y" * 500)

    monkeypatch.setattr(dp.time, "sleep", fake_sleep)

    stable, unstable = _filter_stable_videos(
        [stable_file, growing_file], stability_window_seconds=60, on_event=None,
    )
    assert stable == [stable_file]
    assert unstable == [growing_file]


def test_stability_filter_handles_empty_list(tmp_path: Path):
    """Leere Kandidatenliste triggert keinen Sleep und kein OS-Aufruf."""
    stable, unstable = _filter_stable_videos([], stability_window_seconds=60, on_event=None)
    assert stable == []
    assert unstable == []


# ── category wird in PublishRequest durchgereicht ──


def test_category_is_passed_through_to_run_publish(tmp_path: Path, monkeypatch):
    """run_publish_directory gibt die Kategorie an jeden PublishRequest weiter."""
    import familienfilm_manager.core.directory_publisher as dp
    from familienfilm_manager.api.models import (
        PublishResult,
        RuntimeOptions,
    )

    video = tmp_path / "2026-04-16 Test.mov"
    video.write_bytes(b"x")

    captured: list[str | None] = []

    def fake_run_publish(request, runtime, on_event=None):  # noqa: ARG001
        captured.append(request.category)
        return PublishResult(success=True)

    monkeypatch.setattr(dp, "run_publish", fake_run_publish)

    runtime = RuntimeOptions(
        infuse_target="nas:/i", web_target="nas:/w", archive_target="nas:/a",
    )

    dp.run_publish_directory(
        directory=tmp_path,
        runtime=runtime,
        category="Familie Kurmann-Glück",
    )

    assert captured == ["Familie Kurmann-Glück"]


def test_category_none_is_passed_through(tmp_path: Path, monkeypatch):
    """Ohne category gibt's None weiter (kein Magic)."""
    import familienfilm_manager.core.directory_publisher as dp
    from familienfilm_manager.api.models import PublishResult, RuntimeOptions

    video = tmp_path / "2026-04-16 Test.mov"
    video.write_bytes(b"x")

    captured: list[str | None] = []

    def fake_run_publish(request, runtime, on_event=None):  # noqa: ARG001
        captured.append(request.category)
        return PublishResult(success=True)

    monkeypatch.setattr(dp, "run_publish", fake_run_publish)

    runtime = RuntimeOptions(
        infuse_target="nas:/i", web_target="nas:/w", archive_target="nas:/a",
    )

    dp.run_publish_directory(directory=tmp_path, runtime=runtime)

    assert captured == [None]
