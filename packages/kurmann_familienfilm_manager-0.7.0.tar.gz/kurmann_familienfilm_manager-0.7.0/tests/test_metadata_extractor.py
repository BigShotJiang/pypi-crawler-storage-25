"""Tests für den Metadaten-Extractor (insb. Filename-Parsing mit Poster-Suffix)."""

from familienfilm_manager.core.metadata_extractor import (
    _parse_filename,
    _parse_poster_suffix,
)


# ── _parse_poster_suffix ──


def test_poster_min_only():
    """poster-2min → 120 Sek."""
    stem, sec = _parse_poster_suffix("HDR-Test poster-2min")
    assert stem == "HDR-Test"
    assert sec == 120.0


def test_poster_short_m_only():
    """poster-2m → 120 Sek (Kurzform)."""
    stem, sec = _parse_poster_suffix("HDR-Test poster-2m")
    assert stem == "HDR-Test"
    assert sec == 120.0


def test_poster_short_m_with_sec_and_ms():
    """poster-1m12s500 → 72.5 Sek (Kurzform, ffmpeg-Stil)."""
    stem, sec = _parse_poster_suffix("HDR-Test poster-1m12s500")
    assert stem == "HDR-Test"
    assert sec == 72.5


def test_poster_min_and_sec():
    """poster-3min12 → 192 Sek."""
    stem, sec = _parse_poster_suffix("HDR-Test poster-3min12")
    assert stem == "HDR-Test"
    assert sec == 192.0


def test_poster_min_and_sec_with_trailing_s():
    """poster-3min11s → 191 Sek (trailing 's' ohne ms-Zahl)."""
    stem, sec = _parse_poster_suffix("HDR-Test poster-3min11s")
    assert stem == "HDR-Test"
    assert sec == 191.0


def test_poster_short_m_with_sec_trailing_s():
    """poster-3m11s → 191 Sek (Kurzform + trailing 's')."""
    stem, sec = _parse_poster_suffix("HDR-Test poster-3m11s")
    assert stem == "HDR-Test"
    assert sec == 191.0


def test_poster_min_sec_ms():
    """poster-1min30s500 → 90.5 Sek."""
    stem, sec = _parse_poster_suffix("HDR-Test poster-1min30s500")
    assert stem == "HDR-Test"
    assert sec == 90.5


def test_poster_seconds_only():
    """poster-30s → 30 Sek."""
    stem, sec = _parse_poster_suffix("HDR-Test poster-30s")
    assert stem == "HDR-Test"
    assert sec == 30.0


def test_poster_seconds_with_ms():
    """poster-30s500 → 30.5 Sek."""
    stem, sec = _parse_poster_suffix("HDR-Test poster-30s500")
    assert stem == "HDR-Test"
    assert sec == 30.5


def test_no_poster_suffix():
    """Ohne Suffix bleibt der Stem unverändert."""
    stem, sec = _parse_poster_suffix("HDR-Test")
    assert stem == "HDR-Test"
    assert sec is None


def test_poster_ambiguous_no_unit():
    """poster-30 ohne Einheit (s/min) ist ungültig — bleibt als Stem."""
    stem, sec = _parse_poster_suffix("HDR-Test poster-30")
    assert stem == "HDR-Test poster-30"
    assert sec is None


def test_poster_must_have_leading_space():
    """Ohne Leerzeichen davor wird nicht geparst."""
    stem, sec = _parse_poster_suffix("HDR-Testposter-30s")
    assert stem == "HDR-Testposter-30s"
    assert sec is None


def test_poster_in_middle_not_matched():
    """poster-30s in der Mitte wird nicht geparst (muss am Ende sein)."""
    stem, sec = _parse_poster_suffix("HDR-Test poster-30s extra")
    assert stem == "HDR-Test poster-30s extra"
    assert sec is None


# ── _parse_filename: Datum + Titel + Poster-Suffix ──


def test_filename_full_format():
    """Datum + Titel + Poster-Suffix."""
    date, title, poster_at = _parse_filename("2026-04-16 HDR-Test poster-1min30")
    assert date == "2026-04-16"
    assert title == "HDR-Test"
    assert poster_at == 90.0


def test_filename_no_poster_suffix():
    """Datum + Titel ohne Suffix."""
    date, title, poster_at = _parse_filename("2026-04-16 HDR-Test")
    assert date == "2026-04-16"
    assert title == "HDR-Test"
    assert poster_at is None


def test_filename_no_date():
    """Nur Titel + Suffix, kein Datum."""
    date, title, poster_at = _parse_filename("HDR-Test poster-30s")
    assert date is None
    assert title == "HDR-Test"
    assert poster_at == 30.0


def test_filename_complex_title():
    """Titel mit Leerzeichen + Suffix."""
    date, title, poster_at = _parse_filename("2026-04-12 Wanderung Lobbärg poster-2min30")
    assert date == "2026-04-12"
    assert title == "Wanderung Lobbärg"
    assert poster_at == 150.0


def test_filename_title_with_dash():
    """Titel mit Bindestrich darf nicht mit poster-Suffix verwechselt werden."""
    date, title, poster_at = _parse_filename("2026-04-16 HDR-Test")
    assert title == "HDR-Test"
    assert poster_at is None


def test_filename_subsecond_precision():
    """Sub-Sekunden-Präzision wird unterstützt."""
    date, title, poster_at = _parse_filename("2026-04-16 Test poster-0min1s500")
    assert date == "2026-04-16"
    assert title == "Test"
    assert poster_at == 1.5
