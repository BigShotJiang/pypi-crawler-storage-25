"""Tests für den rclone-Retry-Mechanismus."""

import subprocess
from unittest.mock import patch

import pytest

from familienfilm_manager.core._rclone import (
    DEFAULT_RETRY_DELAYS,
    run_rclone_with_retry,
)


def _make_error(returncode: int = 1, stderr: str = "nas: connection refused") -> subprocess.CalledProcessError:
    err = subprocess.CalledProcessError(returncode, ["rclone", "copy"])
    err.stderr = stderr
    return err


def _make_success() -> subprocess.CompletedProcess:
    return subprocess.CompletedProcess(["rclone", "copy"], 0, stdout="", stderr="")


def test_first_try_succeeds_no_retry():
    """Bei Erfolg im ersten Versuch wird kein Retry ausgelöst."""
    calls = []
    retries = []

    def fake_run(*args, **kwargs):
        calls.append(args[0])
        return _make_success()

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        result = run_rclone_with_retry(
            ["rclone", "copy", "a", "b"],
            on_retry=lambda a, m, e: retries.append((a, m, e)),
        )

    assert len(calls) == 1
    assert retries == []
    assert result.returncode == 0


def test_retry_on_transient_error_then_success():
    """Flüchtiger Fehler: einmal scheitert, zweiter Versuch klappt."""
    attempts = iter([_make_error(), _make_success()])
    retries = []

    def fake_run(*args, **kwargs):
        r = next(attempts)
        if isinstance(r, subprocess.CalledProcessError):
            raise r
        return r

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        with patch("familienfilm_manager.core._rclone.time.sleep") as sleep_mock:
            result = run_rclone_with_retry(
                ["rclone", "copy", "a", "b"],
                retry_delays=(1, 3, 9),
                on_retry=lambda a, m, e: retries.append((a, m)),
            )

    assert result.returncode == 0
    assert len(retries) == 1
    assert retries[0] == (1, 4)  # Versuch 1 fehlgeschlagen, max 4 Versuche
    sleep_mock.assert_called_once_with(1)  # erstes Backoff-Delay


def test_all_retries_fail_raises_last_error():
    """Nach Erschöpfung aller Retries wird die letzte Exception geworfen."""
    errors = [_make_error(stderr=f"fail {i}") for i in range(4)]
    attempts = iter(errors)
    retries = []

    def fake_run(*args, **kwargs):
        raise next(attempts)

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            with pytest.raises(subprocess.CalledProcessError) as excinfo:
                run_rclone_with_retry(
                    ["rclone", "copy", "a", "b"],
                    retry_delays=(1, 3, 9),
                    on_retry=lambda a, m, e: retries.append(a),
                )

    # Letzte Exception enthält die "fail 3" Meldung
    assert excinfo.value.stderr == "fail 3"
    # 3 Retry-Callbacks (nach Versuch 1, 2, 3; nach Versuch 4 gibt's keinen mehr)
    assert retries == [1, 2, 3]


def test_filenotfound_not_retried():
    """Nicht-flüchtige Fehler (z.B. rclone-Binary nicht gefunden) werden nicht retried."""
    call_count = [0]

    def fake_run(*args, **kwargs):
        call_count[0] += 1
        raise FileNotFoundError("rclone: command not found")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            with pytest.raises(FileNotFoundError):
                run_rclone_with_retry(["rclone", "copy", "a", "b"])

    assert call_count[0] == 1, "FileNotFoundError soll nicht retried werden"


def test_custom_retry_delays_control_count():
    """Die Länge von retry_delays bestimmt die Anzahl Retries."""
    errors = [_make_error() for _ in range(3)]
    attempts = iter(errors)

    def fake_run(*args, **kwargs):
        raise next(attempts)

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        with patch("familienfilm_manager.core._rclone.time.sleep") as sleep_mock:
            with pytest.raises(subprocess.CalledProcessError):
                run_rclone_with_retry(
                    ["rclone", "copy", "a", "b"],
                    retry_delays=(5, 10),   # 2 Retries → max 3 Versuche
                )

    assert sleep_mock.call_count == 2
    assert [c.args[0] for c in sleep_mock.call_args_list] == [5, 10]


def test_default_retry_delays_are_exponential():
    """Default ist (1, 3, 9) — konservatives exponentielles Backoff."""
    assert DEFAULT_RETRY_DELAYS == (1, 3, 9)
