"""
tests/test_tools.py — Phase 10 smoke tests for the tool layer.

Covers:
  1. read_file    — reads with line numbers, rejects relative paths
  2. write_file   — read-before-write gate enforced
  3. edit_file    — unique old_string enforcement, successful edit
  4. multi_edit   — atomic application of multiple edits
  5. ls           — lists files, respects ignore patterns
  6. grep_search  — files_with_matches mode (rg may not be installed, skip gracefully)
  7. glob_search  — finds py files sorted by mtime
  8. todo_write   — creates todos, rejects two in_progress
  9. save_memory  — persists a fact to .beam_memory.txt
 10. guardrails   — blocklist enforcement
"""

from __future__ import annotations

import asyncio
import pytest
from pathlib import Path
from unittest.mock import patch

# Reset the read cache before each test module runs
import beam.tools.file_io as _file_io_mod
import beam.tools.todo as _todo_mod


@pytest.fixture(autouse=True)
def reset_tool_state(tmp_path, monkeypatch):
    """Clear in-memory state between tests."""
    _file_io_mod._read_cache.clear()
    _todo_mod._todo_list.clear()


# ─────────────────────────────────────────────────────────────────────────────
# read_file
# ─────────────────────────────────────────────────────────────────────────────

class TestReadFile:
    @pytest.mark.asyncio
    async def test_reads_with_line_numbers(self, tmp_path):
        f = tmp_path / "hello.py"
        f.write_text("def foo():\n    return 42\n")
        from beam.tools.file_io import read_file
        result = await read_file({"path": str(f)})
        assert "1\t" in result
        assert "def foo" in result

    @pytest.mark.asyncio
    async def test_rejects_relative_path(self):
        from beam.tools.file_io import read_file
        result = await read_file({"path": "relative/path.py"})
        assert "Error" in result

    @pytest.mark.asyncio
    async def test_offset_and_limit(self, tmp_path):
        f = tmp_path / "lines.txt"
        f.write_text("\n".join(f"line{i}" for i in range(1, 11)))
        from beam.tools.file_io import read_file
        result = await read_file({"path": str(f), "offset": 3, "limit": 2})
        assert "line3" in result
        assert "line4" in result
        assert "line5" not in result

    @pytest.mark.asyncio
    async def test_missing_file_returns_error(self, tmp_path):
        from beam.tools.file_io import read_file
        result = await read_file({"path": str(tmp_path / "nope.py")})
        assert "Error" in result


# ─────────────────────────────────────────────────────────────────────────────
# write_file
# ─────────────────────────────────────────────────────────────────────────────

class TestWriteFile:
    @pytest.mark.asyncio
    async def test_write_new_file(self, tmp_path):
        from beam.tools.file_io import write_file
        target = tmp_path / "new.py"
        result = await write_file({"path": str(target), "content": "print('hi')\n"})
        assert target.exists()
        assert result == str(target)

    @pytest.mark.asyncio
    async def test_blocks_write_without_read(self, tmp_path):
        from beam.tools.file_io import write_file
        existing = tmp_path / "existing.py"
        existing.write_text("old content")
        result = await write_file({"path": str(existing), "content": "new"})
        assert "Error" in result
        assert existing.read_text() == "old content"  # unchanged

    @pytest.mark.asyncio
    async def test_allows_write_after_read(self, tmp_path):
        from beam.tools.file_io import read_file, write_file
        f = tmp_path / "code.py"
        f.write_text("original\n")
        await read_file({"path": str(f)})
        result = await write_file({"path": str(f), "content": "updated\n"})
        assert result == str(f)
        assert f.read_text() == "updated\n"


# ─────────────────────────────────────────────────────────────────────────────
# edit_file
# ─────────────────────────────────────────────────────────────────────────────

class TestPatchFile:
    @pytest.mark.asyncio
    async def test_successful_edit(self, tmp_path):
        from beam.tools.file_io import read_file, patch_file
        f = tmp_path / "target.txt"
        f.write_text("hello world")
        await read_file({"path": str(f)})  # mark as read
        
        result = await patch_file({
            "path": str(f),
            "old_str": "world",
            "new_str": "beam"
        })
        assert "Replaced" in result
        assert "hello beam" in f.read_text()

    @pytest.mark.asyncio
    async def test_rejects_non_unique_old_string(self, tmp_path):
        from beam.tools.file_io import read_file, patch_file
        
        f = tmp_path / "target.txt"
        f.write_text("apple\napple")
        await read_file({"path": str(f)})
        
        result = await patch_file({
            "path": str(f),
            "old_str": "apple",
            "new_str": "orange"
        })
        assert "Error: old_str appears 2 times" in result

    @pytest.mark.asyncio
    async def test_replace_all(self, tmp_path):
        from beam.tools.file_io import read_file, patch_file
        
        f = tmp_path / "target.txt"
        f.write_text("apple\napple")
        await read_file({"path": str(f)})
        
        result = await patch_file({
            "path": str(f),
            "old_str": "apple",
            "new_str": "orange",
            "replace_all": True
        })
        assert "Replaced 2" in result
        assert f.read_text().count("orange") == 2


# ─────────────────────────────────────────────────────────────────────────────
# multi_edit
# ─────────────────────────────────────────────────────────────────────────────

class TestMultiEdit:
    @pytest.mark.asyncio
    async def test_applies_edits_atomically(self, tmp_path):
        from beam.tools.file_io import read_file, multi_edit
        f = tmp_path / "multi.py"
        f.write_text("a = 1\nb = 2\nc = 3\n")
        await read_file({"path": str(f)})
        result = await multi_edit({
            "path": str(f),
            "edits": [
                {"old_string": "a = 1", "new_string": "a = 10"},
                {"old_string": "b = 2", "new_string": "b = 20"},
            ],
        })
        assert "2 edit" in result
        assert "a = 10" in f.read_text()
        assert "b = 20" in f.read_text()

    @pytest.mark.asyncio
    async def test_aborts_all_on_bad_edit(self, tmp_path):
        from beam.tools.file_io import read_file, multi_edit
        f = tmp_path / "abort.py"
        original = "a = 1\nb = 2\n"
        f.write_text(original)
        await read_file({"path": str(f)})
        result = await multi_edit({
            "path": str(f),
            "edits": [
                {"old_string": "a = 1", "new_string": "a = 10"},
                {"old_string": "DOES_NOT_EXIST", "new_string": "x"},
            ],
        })
        assert "Error" in result


# ─────────────────────────────────────────────────────────────────────────────
# ls
# ─────────────────────────────────────────────────────────────────────────────

class TestLS:
    @pytest.mark.asyncio
    async def test_lists_contents(self, tmp_path):
        (tmp_path / "alpha.py").touch()
        (tmp_path / "beta.txt").touch()
        from beam.tools.file_io import ls
        result = await ls({"path": str(tmp_path)})
        assert "alpha.py" in result
        assert "beta.txt" in result

    @pytest.mark.asyncio
    async def test_ignore_patterns(self, tmp_path):
        (tmp_path / "keep.py").touch()
        (tmp_path / "__pycache__").mkdir()
        from beam.tools.file_io import ls
        result = await ls({"path": str(tmp_path), "ignore": ["__pycache__"]})
        assert "__pycache__" not in result
        assert "keep.py" in result


# ─────────────────────────────────────────────────────────────────────────────
# glob_search
# ─────────────────────────────────────────────────────────────────────────────

class TestGlobSearch:
    @pytest.mark.asyncio
    async def test_finds_py_files(self, tmp_path):
        (tmp_path / "a.py").write_text("x=1")
        (tmp_path / "b.py").write_text("y=2")
        (tmp_path / "c.txt").write_text("z=3")
        from beam.tools.search import glob_search
        result = await glob_search({"pattern": "*.py", "path": str(tmp_path)})
        assert "a.py" in result
        assert "b.py" in result
        assert "c.txt" not in result

    @pytest.mark.asyncio
    async def test_no_match_returns_message(self, tmp_path):
        from beam.tools.search import glob_search
        result = await glob_search({"pattern": "*.go", "path": str(tmp_path)})
        assert "no files matched" in result


# ─────────────────────────────────────────────────────────────────────────────
# todo_write
# ─────────────────────────────────────────────────────────────────────────────

class TestTodoWrite:
    @pytest.mark.asyncio
    async def test_creates_todos(self):
        from beam.tools.todo import todo_write, get_todo_list
        result = await todo_write({"todos": [
            {"id": "1", "content": "Fix auth bug", "status": "pending", "priority": "high"},
            {"id": "2", "content": "Write tests", "status": "in_progress", "priority": "medium"},
        ]})
        todos = get_todo_list()
        assert len(todos) == 2
        assert todos[0].content == "Fix auth bug"

    @pytest.mark.asyncio
    async def test_rejects_two_in_progress(self):
        from beam.tools.todo import todo_write
        result = await todo_write({"todos": [
            {"id": "1", "content": "Task A", "status": "in_progress", "priority": "high"},
            {"id": "2", "content": "Task B", "status": "in_progress", "priority": "low"},
        ]})
        assert "Error" in result


# ─────────────────────────────────────────────────────────────────────────────
# Guardrails — blocklist enforcement
# ─────────────────────────────────────────────────────────────────────────────

class TestGuardrails:
    def _make_config(self):
        from beam.config import SafetyConfig
        return SafetyConfig(
            blocked_commands=["rm -rf", "DROP TABLE"],
            allowed_paths=["C:/Users/Dell/Downloads/Beam CLI"],
            require_approval_for_writes=False,
            require_approval_for_shell=False,
        )

    @pytest.mark.asyncio
    async def test_blocked_command_raises(self):
        from beam.safety.guardrails import Guardrails, GuardrailViolation
        from beam.tools.registry import ToolRegistry

        config = self._make_config()
        guardrails = Guardrails(config)

        reg = ToolRegistry()

        async def fake_shell(params):
            return "deleted"

        reg.register("run_command", fake_shell, "shell")
        guardrails.wrap_registry(reg)

        wrapped = reg.get("run_command")
        with pytest.raises(GuardrailViolation):
            await wrapped({"command": "rm -rf /important"})

    @pytest.mark.asyncio
    async def test_safe_command_passes(self):
        from beam.safety.guardrails import Guardrails
        from beam.tools.registry import ToolRegistry

        config = self._make_config()
        guardrails = Guardrails(config)
        reg = ToolRegistry()

        async def fake_shell(params):
            return "ok"

        reg.register("run_command", fake_shell, "shell")
        guardrails.wrap_registry(reg)

        wrapped = reg.get("run_command")
        result = await wrapped({"command": "echo hello"})
        assert result == "ok"
