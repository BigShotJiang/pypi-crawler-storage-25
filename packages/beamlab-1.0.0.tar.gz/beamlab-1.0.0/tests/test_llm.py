"""tests/test_llm.py — Tests for LLM providers and orchestrator."""

from __future__ import annotations

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from beam.llm.providers import LongCatProvider, OllamaProvider, ProviderError
from beam.llm.orchestrator import Orchestrator, OrchestratorError
from beam.config import AgentConfig, ModelConfig


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

async def collect(async_gen) -> str:
    """Collect all chunks from an async generator into a string."""
    chunks = []
    async for chunk in async_gen:
        chunks.append(chunk)
    return "".join(chunks)


# ---------------------------------------------------------------------------
# ProviderError
# ---------------------------------------------------------------------------

class TestProviderError:
    def test_message_includes_provider_and_reason(self):
        err = ProviderError("longcat", "rate limited")
        assert "longcat" in str(err)
        assert "rate limited" in str(err)


# ---------------------------------------------------------------------------
# LongCatProvider
# ---------------------------------------------------------------------------

class TestLongCatProvider:
    def test_raises_on_missing_api_key(self):
        with pytest.raises(ValueError, match="API key"):
            LongCatProvider(api_key="")

    @pytest.mark.asyncio
    async def test_streams_chunks(self):
        provider = LongCatProvider(api_key="fake-key")

        mock_chunk1 = MagicMock()
        mock_chunk1.choices = [MagicMock()]
        mock_chunk1.choices[0].delta.content = "Hello"
        mock_chunk2 = MagicMock()
        mock_chunk2.choices = [MagicMock()]
        mock_chunk2.choices[0].delta.content = " world"

        # create(stream=True) is awaited → returns an async iterable.
        # Must be a coroutine (not async generator) that returns an iterable object.
        class FakeAsyncStream:
            def __aiter__(self):
                return self._gen()
            async def _gen(self):
                yield mock_chunk1
                yield mock_chunk2

        async def fake_create(**kwargs):
            return FakeAsyncStream()

        with patch.object(provider._client.chat.completions, "create", side_effect=fake_create):
            result = await collect(provider.chat([{"role": "user", "content": "hi"}], model="LongCat-Flash-Chat"))
        assert result == "Hello world"


# ---------------------------------------------------------------------------
# Orchestrator
# ---------------------------------------------------------------------------

class TestOrchestrator:
    def _make_config(self, primary_key="key", fallback_key="", local_url="") -> AgentConfig:
        config = AgentConfig()
        config.model.primary_api_key = primary_key
        config.model.fallback_api_key = fallback_key
        config.model.local_url = local_url or "http://localhost:11434"
        return config

    def test_from_config_skips_providers_without_keys(self):
        config = self._make_config(primary_key="", fallback_key="")
        orch = Orchestrator.from_config(config)
        # Only Ollama (always added) should remain
        assert "ollama" in orch.active_providers
        assert "longcat" not in orch.active_providers
        assert "gemini" not in orch.active_providers

    def test_from_config_includes_longcat_when_key_set(self):
        config = self._make_config(primary_key="valid-key")
        orch = Orchestrator.from_config(config)
        assert orch.active_providers[0] == "longcat"

    @pytest.mark.asyncio
    async def test_falls_back_to_next_provider_on_error(self):
        """When primary fails, orchestrator should try the next provider."""
        config = self._make_config(primary_key="key")
        orch = Orchestrator.from_config(config)

        call_order = []

        async def failing_provider(*args, **kwargs):
            call_order.append("primary")
            raise ProviderError("longcat", "connection failed")
            yield  # make it an async generator

        async def working_provider(*args, **kwargs):
            call_order.append("fallback")
            yield "response from fallback"

        orch._providers[0].chat = failing_provider  # longcat fails
        if len(orch._providers) > 1:
            orch._providers[1].chat = working_provider  # ollama works

        result = await collect(orch.chat([{"role": "user", "content": "test"}]))
        assert "fallback" in call_order

    @pytest.mark.asyncio
    async def test_raises_orchestrator_error_when_all_fail(self):
        config = self._make_config(primary_key="key")
        orch = Orchestrator.from_config(config)

        async def always_fail(*args, **kwargs):
            raise ProviderError("test", "always fails")
            yield

        for provider in orch._providers:
            provider.chat = always_fail

        with pytest.raises(OrchestratorError):
            await collect(orch.chat([{"role": "user", "content": "test"}]))
