@echo off
:: Beam CLI — Global Entry Point
:: Run from any directory. The agent detects your project root automatically.
C:\Users\Dell\AppData\Local\Programs\Python\Python314\python.exe -m beamlab.main %*
