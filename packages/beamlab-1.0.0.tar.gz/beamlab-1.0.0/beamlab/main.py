"""
beam/main.py — Entry point. Wires all phases together.

Boot sequence:
  1. Load config (.agent.toml + env vars)
  2. Print startup banner
  3. Register tools + apply safety guardrails
  4. Detect project root (git root or cwd)
  5. Run interactive session picker (resume or create)
  6. Index repo (background, non-blocking)
  7. Start REPL shell
"""

from __future__ import annotations

import asyncio
import logging
import sys
from pathlib import Path

from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from beamlab import __version__
from beamlab.config import load_config

console = Console(highlight=False)
logger  = logging.getLogger(__name__)


def main() -> None:
    """Synchronous entry point — delegates to async _main."""
    import sys
    import os
    if sys.platform == "win32":
        # Force UTF-8 for Windows consoles to support elite symbols (BOLT, etc.)
        try:
            sys.stdout.reconfigure(encoding='utf-8')
            sys.stderr.reconfigure(encoding='utf-8')
        except (AttributeError, ValueError):
            pass

    os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")
    os.environ.setdefault("TRANSFORMERS_NO_ADVISORY_WARNINGS", "1")
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

    logging.basicConfig(
        level=logging.ERROR,
        format="%(levelname)s %(name)s: %(message)s",
    )
    # Silence all beam internals and third-party noise
    for noisy in ("beam", "huggingface_hub", "transformers", "sentence_transformers", "faiss"):
        logging.getLogger(noisy).setLevel(logging.ERROR)

    try:
        asyncio.run(_main())
    except KeyboardInterrupt:
        console.print("\n[dim]Interrupted. Goodbye.[/dim]")
        sys.exit(0)


ASCII_LOGO = """
[bold #00d7ff]██████  ███████  █████  ███    ███[/bold #00d7ff]
[bold #00d7ff]██   ██ ██      ██   ██ ████  ████[/bold #00d7ff]
[bold #00d7ff]██████  █████   ███████ ██ ████ ██[/bold #00d7ff]
[bold #00d7ff]██   ██ ██      ██   ██ ██  ██  ██[/bold #00d7ff]
[bold #00d7ff]██████  ███████ ██   ██ ██      ██[/bold #00d7ff]
"""

async def _main() -> None:
    # ── 0. Print Logo ──────────────────────────────────────────────────
    console.print(ASCII_LOGO)

    # ── 1. Detect project root (search upwards for .git or .agent.toml) ──
    from beamlab.agent.memory.session import detect_project_root
    project_root = detect_project_root(Path.cwd())

    # ── 2. Load Config (relative to detected root + Env Vars) ───────────
    from beamlab.config import load_config
    config = load_config(project_root)

    if not config.model.primary_api_key:
        console.print(Panel(
            Text(
                f"No API key found for '{config.model.primary}'.\n"
                "Please set it in your environment variables:\n"
                "  $env:LONGCAT_API_KEY = \"...\"  (PowerShell)\n"
                "  export LONGCAT_API_KEY=\"...\" (Bash/Zsh)\n\n"
                "Or add it to a .agent.toml in your project root.",
                style="bold red",
            ),
            title=" [bold red]⚡ Beam — Missing Configuration[/bold red] ",
            border_style="red",
            box=box.ROUNDED,
        ))
        sys.exit(1)

    # ── 2. Splash animation ─────────────────────────────────────────────
    from beamlab.cli.renderer import splash_animation
    await splash_animation()

    # ── 3. Startup banner ─────────────────────────────────────────────
    info = Table.grid(padding=(0, 2))
    info.add_column(style="dim white",    no_wrap=True)
    info.add_column(style="bold #00d7ff", no_wrap=True)
    info.add_row("Version",  f"v{__version__}")
    info.add_row("Model",    config.model.primary)
    info.add_row("Fallback", config.model.fallback or "—")
    info.add_row("Safety",   f"writes={config.safety.require_approval_for_writes}  shell={config.safety.require_approval_for_shell}")
    info.add_row("Store",    str(Path.home() / ".beam"))
    info.add_row("Author",   "Muhammad Yasir (devxyasir)")

    console.print(Panel(
        info,
        title=" [bold #00d7ff]⚡ BeamLab CLI[/bold #00d7ff] ",
        border_style="#00d7ff",
        box=box.ROUNDED,
        padding=(0, 1),
    ))

    # ── 3. Register tools ─────────────────────────────────────────────
    import beamlab.tools.file_io      # noqa: F401
    import beamlab.tools.diff_patch   # noqa: F401
    import beamlab.tools.search       # noqa: F401
    import beamlab.tools.terminal     # noqa: F401
    import beamlab.tools.test_runner  # noqa: F401
    import beamlab.tools.todo         # noqa: F401
    import beamlab.tools.web          # noqa: F401
    import beamlab.tools.memory       # noqa: F401

    from beamlab.tools.registry import registry

    # ── 4. Guardrails ─────────────────────────────────────────────────
    # Note: Handled by AgentController.initialize() in Shell.run()

    # ── 5. Project root already detected at startup ───────────────

    # ── 6. Session picker ─────────────────────────────────────────────
    from beamlab.agent.memory.session import SessionStore
    from beamlab.cli.session_picker import pick_session

    store   = SessionStore()
    session = pick_session(store, project_root)

    # ── 7. Controller ────────────────────────────────────────────────
    from beamlab.agent.controller import AgentController
    from beamlab.agent.memory.vector import VectorStore

    # Shared store: background indexer writes, controller reads
    vector_store = VectorStore()

    controller = AgentController.from_config(
        config=config,
        tool_registry=registry,
        project_root=project_root,
        vector_store=vector_store,
        initial_history=session.messages, # Inject session history
        session=session,
    )

    # ── 8. Background indexing ──────────────────────────────────────────
    if config.indexing.auto_index_on_start:
        asyncio.create_task(_index_background(project_root, vector_store))

    # ── 9. REPL ───────────────────────────────────────────────────────
    from beamlab.cli.renderer import print_footer
    from beamlab.cli.shell import Shell
    shell = Shell(
        controller=controller,
        session=session,
        store=store,
        project_root=project_root,
    )
    await shell.run()

    store.save(shell.session)
    
    # ── 10. Footer ─────────────────────────────────────────────────────
    print_footer()


async def _index_background(project_root: Path, vector_store) -> None:
    """Index repo chunks into the shared VectorStore (runs concurrently with REPL)."""
    try:
        from beamlab.intelligence.repo_walker import RepoWalker
        from beamlab.agent.memory.chunker import Chunker

        walker = RepoWalker(root=project_root, chunker=Chunker())
        chunks = walker.index()
        if chunks:
            vector_store.add(chunks)
        logger.debug("Indexed %d chunks from %s into VectorStore", len(chunks), project_root)
    except Exception as e:
        logger.warning("Background indexing failed: %s", e)


if __name__ == "__main__":
    main()
