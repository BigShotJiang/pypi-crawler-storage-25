---
source: Production Claude Code CLI tool definition
extracted: 2025-08-03
name: WebSearch
input_schema:
  type: object
  properties:
    query:
      type: string
      minLength: 2
      description: The search query to use
    allowed_domains:
      type: array
      items:
        type: string
      description: Only include search results from these domains
    blocked_domains:
      type: array
      items:
        type: string
      description: Never include search results from these domains
  required:
    - query
  additionalProperties: false
---

- Allows Claude to search the web and use the results to inform responses
- Provides up-to-date information for current events and recent data
- Returns search result information formatted as search result blocks
- Use this tool for accessing information beyond Claude's knowledge cutoff
- Searches are performed automatically within a single API call

Usage notes:
  - Domain filtering is supported to include or block specific websites
  - Web search is only available in the US
  - Account for "Today's date" in <env>. For example, if <env> says "Today's date: 2025-07-01", and the user wants the latest docs, do not use 2024 in the search query. Use 2025.
