# TodoWrite Instructions

Manage a task list for the current session. **IMPORTANT**: Only use for tasks requiring 3+ distinct steps. Avoid micro-management or redundant updates.

## Rules:
1. **Initialize Once**: Create the full plan at the start of a complex task.
2. **Limit Updates**: Only update when a task starts (`in_progress`) or finishes (`completed`).
3. **Single Active Task**: Only ONE task should be `in_progress` at any time.
4. **Completion**: Only mark `completed` after successful verification (testing/linting).
5. **Skip for Triviality**: Do not use for simple file edits, searches, or single-turn fixes.

## Schema:
- `todos`: array of `{id: string, content: string, status: "pending"|"in_progress"|"completed", priority: "high"|"medium"|"low"}`

## Example Usage:
- Start of feature: `todo_write(todos=[...])`
- Task complete: `todo_write(todos=[... updated status ...])`
- Final cleanup: `todo_write(todos=[... all completed ...])`
