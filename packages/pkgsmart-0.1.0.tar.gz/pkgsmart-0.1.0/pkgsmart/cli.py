#!/usr/bin/env python3

import sys
import json
import shutil
import subprocess
import time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
from typing import Optional

import typer
from rapidfuzz import fuzz
from rich import print
from rich.table import Table
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

console = Console()
app = typer.Typer(help="Smart cross-source package installer for Linux.")

# --- CONFIG ---
CACHE_PATH = Path.home() / ".cache/pkgsmart/index.json"
HISTORY_PATH = Path.home() / ".cache/pkgsmart/history.json"
MAX_RESULTS = 8
CACHE_MAX_AGE_DAYS = 3
SCORE_THRESHOLD = 40
CHUNK_SIZE = 2000  # for parallel scoring
SMALL_DATASET_THRESHOLD = 5000
APT_SOURCE_BONUS = 5
PREFERRED_SOURCE_BONUS = 10
SOURCE_PRIORITY = {"APT": 2, "Flatpak": 1, "Snap": 0}


# --- UTIL ---

def run_cmd(cmd, timeout=30):
    try:
        result = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=timeout,
        )
        return result.stdout.strip().split("\n")
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return []


def normalize(text):
    return text.lower().replace("com.", "").replace("org.", "").replace(".", " ").strip()


def cache_is_stale():
    if not CACHE_PATH.exists():
        return True
    age = time.time() - CACHE_PATH.stat().st_mtime
    return age > CACHE_MAX_AGE_DAYS * 86400


def ensure_normalized_fields(index):
    for pkg in index:
        if "name_n" not in pkg:
            pkg["name_n"] = normalize(pkg.get("name", ""))
        if "desc_n" not in pkg:
            pkg["desc_n"] = normalize(pkg.get("desc", ""))
    return index


def load_history():
    if not HISTORY_PATH.exists():
        return {}

    try:
        with open(HISTORY_PATH) as f:
            history = json.load(f)
            return history if isinstance(history, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def save_history(history):
    HISTORY_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = HISTORY_PATH.with_suffix(".tmp")
    with open(tmp, "w") as f:
        json.dump(history, f)
    tmp.rename(HISTORY_PATH)


def remember_install_preference(query, source):
    history = load_history()
    history[normalize(query)] = source
    save_history(history)


def preferred_source_for(query):
    return load_history().get(normalize(query))


def source_priority(source, preferred_source=None):
    priority = SOURCE_PRIORITY.get(source, 0)
    if preferred_source and source == preferred_source:
        priority += 3
    return priority


# --- SOURCE FETCHERS ---

def fetch_apt():
    packages = []
    for line in run_cmd(["apt-cache", "search", "."]):
        if " - " in line:
            name, desc = line.split(" - ", 1)
            packages.append({"source": "APT", "name": name.strip(), "desc": desc.strip()})
    return packages


def fetch_flatpak():
    if not shutil.which("flatpak"):
        return []
    packages = []
    for line in run_cmd(["flatpak", "remote-ls", "--app", "flathub", "--columns=application,description"]):
        parts = line.split("\t")
        if len(parts) >= 2:
            name, desc = parts[0].strip(), parts[1].strip()
            if name:
                packages.append({"source": "Flatpak", "name": name, "desc": desc})
    return packages


def fetch_snap():
    if not shutil.which("snap"):
        return []
    packages = []
    for line in run_cmd(["snap", "find", ""], timeout=20):
        if not line or line.startswith("Name"):
            continue
        parts = line.split()
        if len(parts) >= 4:
            name = parts[0]
            desc = " ".join(parts[4:]) if len(parts) > 4 else ""
            packages.append({"source": "Snap", "name": name, "desc": desc})
    return packages


# --- INDEX BUILDING ---

def build_index(quiet=False):
    if not quiet:
        console.print("[yellow]Building package index in parallel...[/yellow]")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
        console=console,
    ) as progress:
        task = progress.add_task("Fetching from APT, Flatpak, Snap...", total=None)

        with ThreadPoolExecutor(max_workers=3) as executor:
            futures = [
                executor.submit(fetch_apt),
                executor.submit(fetch_flatpak),
                executor.submit(fetch_snap),
            ]
            index = []
            for future in futures:
                try:
                    index.extend(future.result())
                except Exception as e:
                    console.print(f"[red]Source fetch error: {e}[/red]")

            index = ensure_normalized_fields(index)
            progress.update(task, completed=True)

    CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = CACHE_PATH.with_suffix(".tmp")
    with open(tmp, "w") as f:
        json.dump(index, f)
    tmp.rename(CACHE_PATH)

    if not quiet:
        console.print(f"[green]Index built: {len(index):,} packages cached.[/green]")


# --- LOAD INDEX ---

def load_index(auto_rebuild=True):
    if cache_is_stale():
        if auto_rebuild:
            console.print(
                f"[yellow]Cache missing or older than {CACHE_MAX_AGE_DAYS}d — rebuilding...[/yellow]"
            )
            build_index(quiet=True)
        else:
            console.print("[red]Index not found. Run: pkgsmart --rebuild[/red]")
            sys.exit(1)

    with open(CACHE_PATH) as f:
        index = json.load(f)

    return ensure_normalized_fields(index)


# --- SCORING (runs in worker processes for parallelism) ---

def _score_chunk(args):
    """Score a chunk of packages. Runs in a separate process."""
    chunk, query_n, threshold, preferred_source = args
    results = []
    for pkg in chunk:
        name_n = pkg.get("name_n") or normalize(pkg.get("name", ""))
        desc_n = pkg.get("desc_n") or normalize(pkg.get("desc", ""))

        name_score = max(
            fuzz.partial_ratio(query_n, name_n),
            fuzz.token_set_ratio(query_n, name_n),
        ) * 1.4

        desc_score = fuzz.partial_ratio(query_n, desc_n)

        s = max(name_score, desc_score)

        if pkg["source"] == "APT":
            s += APT_SOURCE_BONUS

        if preferred_source and pkg["source"] == preferred_source:
            s += PREFERRED_SOURCE_BONUS

        if name_n.startswith(query_n):
            s += 30

        if s > threshold:
            results.append((s, pkg))

    return results


def sort_results(results, preferred_source=None):
    return sorted(
        results,
        key=lambda item: (
            item[0],
            source_priority(item[1]["source"], preferred_source),
            len(item[1]["name"]),
        ),
        reverse=True,
    )


def search(query, index, sources=None):
    query_n = normalize(query)
    preferred_source = preferred_source_for(query)

    if sources:
        index = [p for p in index if p["source"].lower() in sources]

    results = []

    if len(index) < SMALL_DATASET_THRESHOLD:
        results.extend(_score_chunk((index, query_n, SCORE_THRESHOLD, preferred_source)))
    else:
        chunks = [index[i : i + CHUNK_SIZE] for i in range(0, len(index), CHUNK_SIZE)]
        args = [(chunk, query_n, SCORE_THRESHOLD, preferred_source) for chunk in chunks]

        with ProcessPoolExecutor() as executor:
            for chunk_results in executor.map(_score_chunk, args):
                results.extend(chunk_results)

    return sort_results(results, preferred_source=preferred_source)[:MAX_RESULTS]


# --- INSTALL COMMAND ---

def install_cmd(pkg):
    source = pkg["source"]
    name = pkg["name"]
    if source == "APT":
        return f"sudo apt install -y {name}"
    if source == "Flatpak":
        return f"flatpak install flathub {name} -y"
    if source == "Snap":
        return f"sudo snap install {name}"
    return None


# --- DISPLAY + INTERACTIVE INSTALL ---

def display_and_prompt(query, results):
    if not results:
        console.print(f"[red]No results for '{query}'[/red]")
        return

    table = Table(title=f"Results for '[bold]{query}[/bold]'", show_lines=True)
    table.add_column("#", style="dim", width=3)
    table.add_column("Source", style="cyan", width=8)
    table.add_column("Package", style="bold")
    table.add_column("Description")
    table.add_column("Score", style="dim", width=6)

    for i, (s, pkg) in enumerate(results, 1):
        source_color = {"APT": "green", "Flatpak": "blue", "Snap": "magenta"}.get(
            pkg["source"], "white"
        )
        table.add_row(
            str(i),
            f"[{source_color}]{pkg['source']}[/{source_color}]",
            pkg["name"],
            pkg["desc"][:60] + ("…" if len(pkg["desc"]) > 60 else ""),
            f"{int(s)}",
        )

    console.print(table)

    try:
        choice = input("\nInstall which? (1-{} or Enter to skip): ".format(len(results))).strip()
    except (KeyboardInterrupt, EOFError):
        print()
        return

    if choice.isdigit():
        idx = int(choice) - 1
        if 0 <= idx < len(results):
            _, pkg = results[idx]
            cmd = install_cmd(pkg)
            if cmd:
                console.print(f"\n[bold]Running:[/bold] [cyan]{cmd}[/cyan]\n")
                completed = subprocess.run(cmd, shell=True)
                if completed.returncode == 0:
                    remember_install_preference(query, pkg["source"])
            else:
                console.print("[red]Unknown install method.[/red]")
        else:
            console.print("[red]Invalid choice.[/red]")


def self_test():
    candidates = [
        (100, {"source": "Snap", "name": "snap-code"}),
        (100, {"source": "APT", "name": "apt-code"}),
        (100, {"source": "Flatpak", "name": "flatpak-code"}),
    ]

    ranked = sort_results(candidates, preferred_source="Flatpak")

    assert ranked[0][1]["source"] == "Flatpak", ranked
    assert ranked[1][1]["source"] == "APT", ranked

    console.print("[green]pkgsmart self-test passed[/green]")


# --- CLI COMMANDS (Typer) ---

@app.command()
def install(
    query: str = typer.Argument(..., help="Package name or search term."),
    sources: Optional[str] = typer.Option(
        None,
        "--sources",
        "-s",
        help="Comma-separated list of sources: apt,flatpak,snap",
    ),
):
    """Search for and install a package interactively."""
    source_set = None
    if sources:
        source_set = set(sources.lower().split(","))

    index = load_index()

    with console.status(f"[bold green]Searching for '{query}'...[/bold green]"):
        results = search(query, index, sources=source_set)

    display_and_prompt(query, results)


@app.command()
def rebuild():
    """Rebuild the local package index from all sources."""
    build_index()


@app.command(name="self-test")
def self_test_cmd():
    """Verify the ranking tie-break behavior."""
    self_test()


def run():
    app()


if __name__ == "__main__":
    run()
