import io
import os

from setuptools import setup, find_packages

PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))


def read(fname):
    with io.open(fname) as fp:
        return fp.read()


long_description = read("README.md")


REQUIREMENTS_FILE = "requirements.txt"
REQUIREMENTS = open(os.path.join(PROJECT_DIR, REQUIREMENTS_FILE)).readlines()

REQUIREMENTS_TESTS_FILE = "requirements-test.txt"
REQUIREMENTS_TESTS = open(
    os.path.join(PROJECT_DIR, REQUIREMENTS_TESTS_FILE)
).readlines()

EXTRAS_REQUIRE = {
    "enum": ["marshmallow-enum"],
    "union": ["marshmallow-union"],
    "oneofschema": ["marshmallow-oneofschema"],
}


setup(
    name="marshmallow-jsonschema",
    version="0.16.0",
    description="JSON Schema Draft v7 (http://json-schema.org/)"
    " formatting with marshmallow",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Stephen Fuhry",
    author_email="fuhrysteve@gmail.com",
    url="https://github.com/fuhrysteve/marshmallow-jsonschema",
    packages=find_packages(exclude=("test*",)),
    include_package_data=True,
    install_requires=REQUIREMENTS,
    tests_require=REQUIREMENTS_TESTS,
    extras_require=EXTRAS_REQUIRE,
    license="MIT License",
    zip_safe=False,
    keywords=(
        "marshmallow-jsonschema marshmallow schema serialization "
        "jsonschema validation"
    ),
    python_requires=">=3.9",
    classifiers=[
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Natural Language :: English",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
    ],
    test_suite="tests",
)
