from __future__ import annotations

from pathlib import Path
import sqlite3


class TestReindexFile:
    def test_reindex_file_replaces_existing_rows_and_tracks_deletes(self, tmp_path, monkeypatch):
        from trailhead.services.indexing.sqlite_store import reindex_file

        source = tmp_path / "example.py"
        db = tmp_path / "graph.db"
        source.write_text("def alpha():\n    pass\n")

        monkeypatch.setattr(
            "trailhead.services.indexing.sqlite_store.generate_embeddings",
            lambda texts, model_name, cache_folder=None: [[0.1, 0.2, 0.3] for _ in texts],
        )
        monkeypatch.setattr(
            "trailhead.services.indexing.sqlite_store._try_initialize_sqlite_vector",
            lambda conn, dimension: True,
        )

        vertex_count, embedding_count = reindex_file(db, source, model_name="model-a")
        assert vertex_count == 2
        assert embedding_count == 2

        source.write_text("def beta():\n    pass\n")
        vertex_count, embedding_count = reindex_file(db, source, model_name="model-a")
        assert vertex_count == 2
        assert embedding_count == 2

        with sqlite3.connect(db) as conn:
            names = [
                row[0]
                for row in conn.execute(
                    "SELECT json_extract(properties_json, '$.name') FROM vertices WHERE label = 'function'"
                ).fetchall()
            ]
            indexed_files = conn.execute("SELECT path FROM indexed_files").fetchall()

        assert names == ["beta"]
        assert indexed_files == [(str(source.resolve()),)]

        source.unlink()
        vertex_count, embedding_count = reindex_file(db, source, model_name="model-a")
        assert vertex_count == 0
        assert embedding_count == 0

        with sqlite3.connect(db) as conn:
            remaining = conn.execute(
                "SELECT COUNT(*) FROM vertices WHERE json_extract(properties_json, '$.path') = ?",
                (str(source.resolve()),),
            ).fetchone()[0]
            indexed_files = conn.execute("SELECT COUNT(*) FROM indexed_files").fetchone()[0]

        assert remaining == 0
        assert indexed_files == 0


class TestLiveIndexerThreading:
    def test_start_launches_separate_watcher_and_worker_threads(self, tmp_path, monkeypatch):
        from trailhead.services.indexing.live_indexer import LiveIndexer

        root = tmp_path / "src"
        root.mkdir()
        db = tmp_path / "graph.db"

        # Prevent real file watching from running
        monkeypatch.setattr(
            "trailhead.services.indexing.live_indexer.watch",
            lambda *a, **kw: iter([]),
        )

        service = LiveIndexer(root=root, db_path=db)
        service.start()

        try:
            assert service._watch_thread is not None
            assert service._worker_thread is not None
            assert service._watch_thread is not service._worker_thread
            assert service._watch_thread.name == "trailhead-indexer-watcher"
            assert service._worker_thread.name == "trailhead-indexer-worker"
        finally:
            service.stop()

    def test_watcher_enqueues_changes_for_worker(self, tmp_path, monkeypatch):
        from trailhead.services.indexing.live_indexer import LiveIndexer

        root = tmp_path / "src"
        root.mkdir()
        db = tmp_path / "graph.db"

        reindexed: list[set] = []

        def fake_reindex_paths(paths):
            reindexed.append(paths)

        # Simulate the watcher detecting one change then stopping
        changed_path = str(root / "foo.py")
        fake_changes = [[(1, changed_path)]]  # Change.added = 1

        monkeypatch.setattr(
            "trailhead.services.indexing.live_indexer.watch",
            lambda *a, **kw: iter(fake_changes),
        )

        service = LiveIndexer(root=root, db_path=db)
        monkeypatch.setattr(service, "reindex_paths", fake_reindex_paths)
        service.start()

        # Allow worker time to drain the queue
        service._change_queue.join()
        service.stop()

        assert len(reindexed) == 1
        assert any(p.name == "foo.py" for p in reindexed[0])

    def test_watcher_ignores_ignore_file_updates(self, tmp_path, monkeypatch):
        from trailhead.services.indexing.live_indexer import LiveIndexer

        root = tmp_path / "src"
        root.mkdir()
        db = tmp_path / "graph.db"

        reindexed: list[set] = []

        def fake_reindex_paths(paths):
            reindexed.append(paths)

        fake_changes = [[(1, str(root / ".trailheadignore")), (1, str(root / ".gitignore"))]]

        monkeypatch.setattr(
            "trailhead.services.indexing.live_indexer.watch",
            lambda *a, **kw: iter(fake_changes),
        )

        service = LiveIndexer(root=root, db_path=db)
        monkeypatch.setattr(service, "reindex_paths", fake_reindex_paths)
        service.start()
        if service._watch_thread is not None:
            service._watch_thread.join(timeout=5)
        service.stop()

        assert reindexed == []


class TestLiveIndexer:
    def test_synchronize_reindexes_changed_new_and_deleted_files(self, tmp_path, monkeypatch):
        from trailhead.services.indexing.live_indexer import LiveIndexer
        from trailhead.services.indexing.sqlite_store import SCHEMA_SQL

        root = tmp_path / "src"
        root.mkdir()
        changed_file = root / "changed.py"
        new_file = root / "new.py"
        deleted_file = root / "deleted.py"
        changed_file.write_text("def changed():\n    pass\n")
        new_file.write_text("def fresh():\n    pass\n")

        db = tmp_path / "graph.db"
        with sqlite3.connect(db) as conn:
            conn.executescript(SCHEMA_SQL)
            conn.execute(
                "INSERT INTO indexed_files(path, mtime_ns) VALUES (?, ?)",
                (str(changed_file.resolve()), 0),
            )
            conn.execute(
                "INSERT INTO indexed_files(path, mtime_ns) VALUES (?, ?)",
                (str(deleted_file.resolve()), 123),
            )

        seen_paths: list[Path] = []

        def fake_reindex_file(db_path, path, **kwargs):
            seen_paths.append(path.resolve())
            return (0, 0)

        monkeypatch.setattr("trailhead.services.indexing.live_indexer.reindex_file", fake_reindex_file)

        service = LiveIndexer(root=root, db_path=db, model_name="model-a")
        service.synchronize()

        assert set(seen_paths) == {
            changed_file.resolve(),
            new_file.resolve(),
            deleted_file.resolve(),
        }

    def test_reindex_paths_skips_ignored_files_using_current_rules(self, tmp_path, monkeypatch):
        from trailhead.services.indexing.live_indexer import LiveIndexer

        root = tmp_path / "src"
        root.mkdir()
        keep = root / "keep.py"
        ignored = root / "ignored.py"
        keep.write_text("def keep():\n    pass\n")
        ignored.write_text("def ignored():\n    pass\n")
        (root / ".gitignore").write_text("*.py\n")
        (root / ".trailheadignore").write_text("!keep.py\n")

        seen_paths: list[Path] = []

        def fake_reindex_file(db_path, path, **kwargs):
            seen_paths.append(path.resolve())
            return (0, 0)

        monkeypatch.setattr("trailhead.services.indexing.live_indexer.reindex_file", fake_reindex_file)

        service = LiveIndexer(root=root, db_path=tmp_path / "graph.db")
        service.reindex_paths({keep, ignored})

        assert seen_paths == [keep.resolve()]
