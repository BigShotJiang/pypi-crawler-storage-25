import json
from pydantic import BaseModel, Field, model_validator, field_validator
from typing import Union, Optional, Any, List, Type
from chemgraph.schemas.atomsdata import AtomsData

try:
    from chemgraph.schemas.calculators.tblite_calc import TBLiteCalc
except ImportError:
    TBLiteCalc = None
from chemgraph.schemas.calculators.emt_calc import EMTCalc
from chemgraph.schemas.calculators.nwchem_calc import NWChemCalc
from chemgraph.schemas.calculators.orca_calc import OrcaCalc

try:
    from chemgraph.schemas.calculators.aimnet2_calc import AIMNET2Calc
except ImportError:
    AIMNET2Calc = None


# Attempt to import optional calculators
try:
    from chemgraph.schemas.calculators.fairchem_calc import FAIRChemCalc
except ImportError:
    FAIRChemCalc = None

try:
    from chemgraph.schemas.calculators.mace_calc import MaceCalc
except ImportError:
    MaceCalc = None


# Define all possible calculator classes
_all_calculator_classes: List[Optional[Type[BaseModel]]] = [
    FAIRChemCalc,
    MaceCalc,
    NWChemCalc,
    TBLiteCalc,
    OrcaCalc,
    EMTCalc,
    AIMNET2Calc,
]

# Filter out unavailable calculators
available_calculator_classes: List[Type[BaseModel]] = [
    calc for calc in _all_calculator_classes if calc
]

# Create a union for type hinting
CalculatorUnion = Union[tuple(available_calculator_classes)]

# Determine default calculator and names string
if FAIRChemCalc:
    default_calculator = FAIRChemCalc
elif MaceCalc:
    default_calculator = MaceCalc
else:
    default_calculator = NWChemCalc

_calculator_names = ", ".join([calc.__name__ for calc in available_calculator_classes])


class ASEInputSchema(BaseModel):
    """
    Schema for defining input parameters used in ASE-based molecular simulations.

    Attributes
    ----------
    input_structure_file : str
        Path to the input coordinate file (e.g., CIF, XYZ, POSCAR) containing
        the atomic structure for the simulation.
    output_results_file: str
        Path to a JSON file where simulation results will be saved.
    driver : str
        Specifies the type of simulation to perform. Options:
        - 'energy': Single-point electronic energy calculation.
        - 'opt': Geometry optimization.
        - 'vib': Vibrational frequency analysis.
        - 'ir': Infrared spectrum calculation.
        - 'thermo': Thermochemical property calculation (enthalpy, entropy, Gibbs free energy).
    optimizer : str
        Optimization algorithm for geometry optimization. Options:
        - 'bfgs', 'lbfgs', 'gpmin', 'fire', 'mdmin'.
    calculator : Union[FAIRChemCalc, MaceCalc, NWChemCalc, OrcaCalc, TBLiteCalc, EMTCalc, AIMNET2Calc]
        ASE-compatible calculator used for the simulation. Supported types are determined
        by installed packages and may include:
        - FAIRChem, MACE, NWChem, Orca, TBLite and EMT. The order determines the priority of the calculators.
        - Use MACE or FAIRChem if the calculator is not specified.
    fmax : float
        Force convergence criterion in eV/Å. Optimization stops when all force components fall below this threshold.
    steps : int
        Maximum number of steps for geometry optimization.
    temperature : Optional[float]
        Temperature in Kelvin, required for thermochemical calculations (e.g., when using 'thermo' as the driver).
    pressure : float
        Pressure in Pascal (Pa), used in thermochemistry calculations (default is 1 atm).
    """

    input_structure_file: str = Field(
        description="Path to the input coordinate file (e.g., CIF, XYZ, POSCAR) containing the atomic structure for the simulation."
    )
    output_results_file: str = Field(
        default="output.json",
        description="Path to a JSON file where simulation results will be saved.",
    )
    driver: str = Field(
        default=None,
        description="Specifies the type of simulation to run. Options: 'energy' for electronic energy calculations, 'dipole' for dipole moment calculation, 'opt' for geometry optimization, 'vib' for vibrational frequency analysis, 'ir' for calculating infrared spectrum, and 'thermo' for thermochemical properties (including enthalpy, entropy, and Gibbs free energy). Use 'thermo' when the query involves enthalpy, entropy, or Gibbs free energy calculations.",
    )
    optimizer: str = Field(
        default="bfgs",
        description="The optimization algorithm used for geometry optimization. Options are 'bfgs', 'lbfgs', 'gpmin', 'fire', 'mdmin'",
    )
    calculator: CalculatorUnion = Field(
        default_factory=default_calculator,
        description=f"The ASE calculator to be used. Support {_calculator_names}. Use {default_calculator.__name__} if not specified.",
    )
    fmax: float = Field(
        default=0.01,
        description="The convergence criterion for forces (in eV/Å). Optimization stops when all force components are smaller than this value.",
    )
    steps: int = Field(
        default=1000,
        description="Maximum number of optimization steps. Internally 'vib', 'thermo' and 'ir' run geometry optimization before performing their respective calculations.",
    )
    temperature: Optional[float] = Field(
        default=None,
        description="Temperature for thermochemistry calculations in Kelvin (K).",
    )
    pressure: float = Field(
        default=101325.0,
        description="Pressure for thermochemistry calculations in Pascal (Pa).",
    )

    @model_validator(mode="before")
    @classmethod
    def _validate_calculator_type(cls, data: Any):
        if not isinstance(data, dict):
            return data

        calc = data.get("calculator")
        if calc is None:
            calc = default_calculator()
            data["calculator"] = calc

        available_calcs = [c.__name__[:4].lower() for c in available_calculator_classes]

        if isinstance(calc, dict):
            calc_name = calc.get("calculator_type")
            if not calc_name:
                raise ValueError("Calculator dictionary must have a 'calculator_type' key.")

            if calc_name[:4].lower() not in available_calcs:
                raise ValueError(
                    f"Calculator {calc_name} is not an allowed or available calculator. "
                    f"Available calculators are: {available_calcs}"
                )

            for c in available_calculator_classes:
                if c.__name__[:4].lower() == calc_name[:4].lower():
                    init_args = calc.copy()
                    init_args.pop("calculator_type", None)
                    data["calculator"] = c(**init_args)
                    return data

        elif hasattr(calc, "__class__"):
            calc_type_name = calc.__class__.__name__
            if calc_type_name[:4].lower() not in available_calcs:
                raise ValueError(
                    f"Calculator {calc_type_name} is not an allowed or available calculator. "
                    f"Available calculators are: {available_calcs}"
                )
        return data


class ASEOutputSchema(BaseModel):
    """
    Schema for defining outputs from ASE-based molecular simulations.
    """

    input_structure_file: str = Field(
        description=(
            "Path to the input coordinate file (e.g., CIF, XYZ, POSCAR) "
            "containing the initial atomic structure for the simulation."
        )
    )
    converged: bool = Field(
        default=False,
        description="Indicates if the optimization successfully converged.",
    )
    final_structure: AtomsData = Field(description="Final structure.")
    simulation_input: ASEInputSchema = Field(
        description="Simulation input for Atomic Simulation Environment."
    )
    single_point_energy: float = Field(
        default=None, description="Single-point energy/Potential energy"
    )
    energy_unit: str = Field(default="eV", description="The unit of the energy reported.")
    dipole_value: List[Optional[float]] = Field(
        default=[None, None, None],
        description="The value of the dipole moment reported.",
    )
    dipole_unit: str = Field(
        default=" e * angstrom", description="The unit of the dipole moment reported."
    )
    vibrational_frequencies: dict = Field(
        default={},
        description="Vibrational frequencies (in cm-1) and energies (in eV).",
    )
    ir_data: dict = Field(
        default={},
        description="Infrared spectrum related data.",
    )
    thermochemistry: dict = Field(default={}, description="Thermochemistry data in eV.")
    success: bool = Field(
        default=False, description="Indicates if the simulation finished correctly."
    )
    error: str = Field(default="", description="Error captured during the simulation")
    wall_time: float = Field(
        default=None,
        description="Total wall time (in seconds) taken to complete the simulation.",
    )

    @field_validator("vibrational_frequencies", "ir_data", "thermochemistry", mode="before")
    @classmethod
    def _coerce_json_string_to_dict(cls, v: Any) -> dict:
        """Accept dict-like payloads serialized as JSON strings."""
        if v is None:
            return {}
        if isinstance(v, dict):
            return v
        if isinstance(v, str):
            text = v.strip()
            if not text:
                return {}
            try:
                parsed = json.loads(text)
                return parsed if isinstance(parsed, dict) else {}
            except json.JSONDecodeError:
                return {}
        return {}

    @field_validator("error", mode="before")
    @classmethod
    def _coerce_error_to_string(cls, v: Any) -> str:
        """Allow null/non-string error fields from intermediate tool payloads."""
        if v is None:
            return ""
        return v if isinstance(v, str) else str(v)
