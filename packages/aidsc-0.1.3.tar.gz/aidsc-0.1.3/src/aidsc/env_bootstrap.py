from __future__ import annotations

import os
import subprocess
from pathlib import Path


def find_git_root(start: Path | None = None) -> Path | None:
    start = start or Path.cwd()
    try:
        out = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            cwd=start,
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
        if out.returncode != 0 or not out.stdout.strip():
            return None
        return Path(out.stdout.strip()).resolve()
    except (OSError, subprocess.SubprocessError):
        return None


def ensure_gitignore_env(git_root: Path | None = None) -> bool:
    """
    If ``git_root`` is a repo root, ensure ``.gitignore`` contains a ``.env`` entry.

    Returns True if ``.gitignore`` was created or updated.
    """
    root = git_root or find_git_root()
    if root is None:
        return False
    gi = root / ".gitignore"
    marker = "# aidsc: keep secrets out of git"
    block = f"{marker}\n.env\n"

    if not gi.is_file():
        gi.write_text(block, encoding="utf-8")
        return True

    text = gi.read_text(encoding="utf-8")
    if ".env" in text.splitlines():
        return False
    with gi.open("a", encoding="utf-8") as f:
        if text and not text.endswith("\n"):
            f.write("\n")
        f.write("\n" + block)
    return True


def load_dotenv_if_present(path: str | os.PathLike[str] | None = None) -> None:
    """Load ``.env`` from *path* or cwd (no-op if python-dotenv missing file)."""
    from dotenv import load_dotenv

    load_dotenv(path)
