from __future__ import annotations

from typing import Literal

from pydantic import AliasChoices, BaseModel, Field


class LanguageArgs(BaseModel):
    """Arguments for a language-model Zeus job."""

    model: str
    questions: list[str] = Field(min_length=1)


class LanguageInferenceRequest(BaseModel):
    """
    Public inference payload (aligned with data/sample_payload.json).

    Only ``type=\"language\"`` is supported for now; other types may be added later.

    ``max_model_len`` is accepted as a legacy alias for ``max_context_length`` when parsing JSON.
    """

    type: Literal["language"] = "language"
    args: LanguageArgs
    max_context_length: int = Field(
        default=8192,
        ge=1,
        validation_alias=AliasChoices("max_context_length", "max_model_len"),
    )
    max_server_uptime: int = Field(default=604_800, ge=1)
    max_new_tokens: int = Field(default=512, ge=1)
    total_concurrent_models: int = Field(default=1, ge=1)
    max_num_seqs: int = Field(default=8, ge=1)
