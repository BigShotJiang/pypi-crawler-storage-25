"""aidsc — Zeus orchestration client (payload models, health, inference)."""

from aidsc.client import aidsc
from aidsc.models import LanguageArgs, LanguageInferenceRequest

__all__ = ["aidsc", "LanguageArgs", "LanguageInferenceRequest"]
