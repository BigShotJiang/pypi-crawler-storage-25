from __future__ import annotations

import json
from typing import Any

import httpx

ZEUS_HEALTH_PATH = "/api/zeus-health"
ZEUS_REQUESTS_PATH = "/api/requests"


def parse_zeus_health(body: str) -> bool:
    try:
        data = json.loads(body)
    except json.JSONDecodeError:
        return False
    return isinstance(data, dict) and data.get("healthy") is True


class ZeusHttpClient:
    """Minimal HTTP client for Zeus control plane."""

    def __init__(self, base_url: str, timeout: float = 30.0) -> None:
        self._base = base_url.rstrip("/")
        self._timeout = timeout

    def get_zeus_health(self) -> bool:
        url = f"{self._base}{ZEUS_HEALTH_PATH}"
        try:
            with httpx.Client(timeout=self._timeout) as client:
                r = client.get(url)
                if r.status_code != 200:
                    return False
                return parse_zeus_health(r.text)
        except (httpx.ConnectError, httpx.RequestError):
            return False

    def post_requests(self, body: dict[str, Any]) -> dict[str, Any]:
        url = f"{self._base}{ZEUS_REQUESTS_PATH}"
        with httpx.Client(timeout=self._timeout) as client:
            r = client.post(url, json=body)
            r.raise_for_status()
            return r.json()
