from __future__ import annotations

import os
import shlex
import subprocess
from dataclasses import dataclass

from aidsc.zeus_client import ZeusHttpClient, parse_zeus_health


@dataclass
class ConnectivityResult:
    ok: bool
    mode: str  # "local" | "remote_ssh"
    detail: str


def check_local_zeus(base_url: str, timeout: float = 10.0) -> tuple[bool, str]:
    try:
        ok = ZeusHttpClient(base_url, timeout=timeout).get_zeus_health()
        return ok, "" if ok else "invalid health response from zeus"
    except Exception as e:
        return False, str(e)


def _remote_zeus_url() -> str:
    return os.environ.get("aidsc_ZEUS_REMOTE_URL", "http://144.174.11.196:32553").rstrip("/")
