"""Observability — structured logging configuration."""
