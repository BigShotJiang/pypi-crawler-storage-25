"""Tests for pyadf package."""
