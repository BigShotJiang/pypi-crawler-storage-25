from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.error_response import ErrorResponse
from ...models.replay_email_webhooks_response_200 import ReplayEmailWebhooksResponse200
from typing import cast
from uuid import UUID



def _get_kwargs(
    id: UUID,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/emails/{id}/replay".format(id=quote(str(id), safe=""),),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ErrorResponse | ReplayEmailWebhooksResponse200 | None:
    if response.status_code == 200:
        response_200 = ReplayEmailWebhooksResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = ErrorResponse.from_dict(response.json())



        return response_401

    if response.status_code == 404:
        response_404 = ErrorResponse.from_dict(response.json())



        return response_404

    if response.status_code == 429:
        response_429 = ErrorResponse.from_dict(response.json())



        return response_429

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ErrorResponse | ReplayEmailWebhooksResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,

) -> Response[ErrorResponse | ReplayEmailWebhooksResponse200]:
    """ Replay email webhooks

     Re-delivers the webhook payload for this email to all active
    endpoints matching the email's domain. Rate limited per-email
    (short cooldown between successive replays of the same email)
    and per-org (burst + sustained windows), sharing an org-wide
    budget with delivery replays.

    Args:
        id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | ReplayEmailWebhooksResponse200]
     """


    kwargs = _get_kwargs(
        id=id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,

) -> ErrorResponse | ReplayEmailWebhooksResponse200 | None:
    """ Replay email webhooks

     Re-delivers the webhook payload for this email to all active
    endpoints matching the email's domain. Rate limited per-email
    (short cooldown between successive replays of the same email)
    and per-org (burst + sustained windows), sharing an org-wide
    budget with delivery replays.

    Args:
        id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | ReplayEmailWebhooksResponse200
     """


    return sync_detailed(
        id=id,
client=client,

    ).parsed

async def asyncio_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,

) -> Response[ErrorResponse | ReplayEmailWebhooksResponse200]:
    """ Replay email webhooks

     Re-delivers the webhook payload for this email to all active
    endpoints matching the email's domain. Rate limited per-email
    (short cooldown between successive replays of the same email)
    and per-org (burst + sustained windows), sharing an org-wide
    budget with delivery replays.

    Args:
        id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | ReplayEmailWebhooksResponse200]
     """


    kwargs = _get_kwargs(
        id=id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,

) -> ErrorResponse | ReplayEmailWebhooksResponse200 | None:
    """ Replay email webhooks

     Re-delivers the webhook payload for this email to all active
    endpoints matching the email's domain. Rate limited per-email
    (short cooldown between successive replays of the same email)
    and per-org (burst + sustained windows), sharing an org-wide
    budget with delivery replays.

    Args:
        id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | ReplayEmailWebhooksResponse200
     """


    return (await asyncio_detailed(
        id=id,
client=client,

    )).parsed
