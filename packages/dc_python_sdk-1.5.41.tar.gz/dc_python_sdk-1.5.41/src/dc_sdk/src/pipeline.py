import json, io, math, re
import time
from .services.environment import PipelineEnvironment
from .services.api import DataConnectorAPI
from .models.log_templates import LogTemplates
from .services.aws import AwsService
from .models import errors
from .services.loader import load_connector

TEMP_UPLOADS = 'temporary-files'
SUB_FOLDER = 'etlJobHistory'


class PipelineConductor:
    def __init__(self, 
        task, 
        mode="prod", 
        api=None, 
        aws=None, 
        azure=None, 
        connector=None,
        **kwargs
    ) -> None:
        self.task = task
        self.mode = mode
        self.pipeline_id = kwargs.get("pipeline_id")
        self.pipeline_run_history_id = kwargs.get("pipeline_run_history_id")
        self.batch_index = 0
        self.bytes_transferred = 0
        self.authentication_tries = 0
        self.filters = kwargs.get("filters")
        self.object_id = kwargs.get("object_id")
        self.prefix = kwargs.get("prefix")
        self.update_method = kwargs.get("update_method")
        self.mapping = kwargs.get("mapping")
        self.pipeline_object_id = kwargs.get("pipeline_mapping_id")
        self.successful_keys = []
        self.config = PipelineEnvironment
        self.api = api or DataConnectorAPI()
        self.aws = aws or AwsService(PipelineEnvironment.aws_s3_bucket)

        # Set Pipeline Details
        self.pipeline_details = self._get_pipeline_details()

        self.credentials = self._get_credentials() if mode == "prod" else kwargs.get('credentials')
        
        # get connector credentials
        Connector = load_connector()
        self.connector = Connector(self.credentials)

        self.row_count = 0
        self.log_templates = self._get_log_messages()

    def _attempt_authentication(self):
        return self.connector.authenticate()

    def authenticate_source(self):
        if not self.credentials:
            raise errors.AuthenticationError("Credentials are not set, please update your credentials.")

        self.log(self.log_templates.AUTHENTICATION_START.format(self.pipeline_details.source_credential_nm, self.pipeline_details.source_object_id))
        authenticated = False
        while self.authentication_tries <= 3 and not authenticated:
            try:
                authenticated = self.connector.authenticate()
            except Exception as e:
                if self.authentication_tries == 3 or "firewall" in str(e): # todo: fix add retry flg in raised errors
                    raise e
                self.authentication_tries += 1
                self._refresh_credentials()
                time.sleep(10)

        if authenticated and self.mode == "prod":
            self.api.send_new_credentials(True, self.pipeline_id, self.connector.credentials)
            self.log(self.log_templates.AUTHENTICATION_FINISH.format(self.pipeline_details.source_credential_nm))
    
    def _refresh_credentials(self):
        response = self.api.get_credential_updates(True, self.pipeline_id)

        creds = self.aws.decrypt_customer_data_object(response['credential'], response['organization'])
        
        self.connector.credentials = creds
    
    def authenticate_destination(self):
        if not self.credentials:
            raise errors.AuthenticationError("Credentials are not set, please update your credentials.")

        self.log(self.log_templates.AUTHENTICATION_START.format(self.pipeline_details.destination_credential_nm, self.pipeline_details.destination_object_id))
        self.connector.authenticate()
        self.log(self.log_templates.AUTHENTICATION_FINISH.format(self.pipeline_details.destination_credential_nm))

    def get_data(self):
        # Determine batch size

        self.log(self.log_templates.GET_DATA_START.format(
            self.pipeline_details.source_object_id,
            ", ".join(str(fid) for fid in self._get_field_ids())
        ))
        
        nrows = self._get_batch_row_count()
        max_allowed = self.pipeline_details.max_allowed_retrieval

        results = self.connector.get_data(self.pipeline_details.source_object_id, self._get_field_ids(), n_rows=nrows, filters=self._get_filters(), options=self.pipeline_details.options)

        while "next_page" in results and results["next_page"] != None:
            if "data" in results and results["data"] != None and results["data"] != []:
                limit_reached = self._process_rows(results["data"], max_allowed)
                if limit_reached:
                    break
            elif results["data"] != []:
                self.internal_log(self.log_templates.INTERNAL_GET_DATA_FETCHED.format(0))
            
            # Check if we've reached the limit before fetching next page
            if max_allowed is not None and self.row_count >= max_allowed:
                break
                
            if "next_page" in results and results["next_page"] != None:
                results = self.connector.get_data(self.pipeline_details.source_object_id, self._get_field_ids(), n_rows=nrows, filters=self._get_filters(), options=self.pipeline_details.options, next_page=results["next_page"])
        
        if "data" in results and results["data"] != None and results["data"] != []:
            self._process_rows(results["data"], max_allowed)
        elif results["data"] != []:
            self.internal_log(self.log_templates.INTERNAL_GET_DATA_FETCHED.format(0))

        self.log(self.log_templates.GET_DATA_FINISH.format(self.row_count, self.pipeline_details.source_object_id))

    def load_data(self, batch_start):
        self.log(self.log_templates.LOAD_DATA_START.format(self.pipeline_details.destination_object_id, len(self._get_field_ids())))
        
        keys = []
        if PipelineEnvironment.platform == "aws":
            keys = self.aws.get_keys(self.pipeline_run_history_id)
        elif PipelineEnvironment.platform == "azure":
            keys = self.azure.get_keys(self.pipeline_run_history_id)

        if not keys:
            # Call load_data with empty data when there are no keys
            loaded = self.connector.load_data([], self.pipeline_details.destination_object_id, self._get_mapping(), self.pipeline_details.update_method_cd, 0, 0)
            if not loaded:
                raise errors.LoadDataError("Loading data failed.")
        else:
            for index, key in enumerate(keys):
                file_object = None
                if PipelineEnvironment.platform == "aws":
                    file_object = self.aws.download_object(key)
                elif PipelineEnvironment.platform == "azure":
                    file_object = self.azure.download_object(key)

                
                data = json.load(file_object)
                self.log(self.log_templates.LOAD_DATA_LOADED.format(len(data), self.pipeline_details.destination_object_id))
                loaded = self.connector.load_data(data, self.pipeline_details.destination_object_id, self._get_mapping(), self.pipeline_details.update_method_cd, index, len(keys))
                if loaded:
                    self.row_count += len(data)
                    if self.mode == "prod":
                        self.update_history({"updateAction": "ROWS_INSERTED", "RowsRetrievedNBR": self.row_count})
                    if PipelineEnvironment.platform == "azure":
                        self.azure.delete_object(key)
                    elif PipelineEnvironment.platform == "aws":
                        self.aws.delete_object(key)
                else:
                    raise errors.LoadDataError("Loading data failed.")
        self.log(self.log_templates.LOAD_DATA_FINISHED.format(self.row_count, self.pipeline_details.destination_object_id))

    def start_next_connector(self):
        self.internal_log(self.log_templates.INTERNAL_START_NEXT_CONNECTOR.format(self.pipeline_details.destination_connector_nm, self.pipeline_details.destination_object_id))

        if PipelineEnvironment.platform == "aws" and not PipelineEnvironment.connected_container:
            return self.aws.start_ecs_task(self.pipeline_details.destination_ecs_task_nm, str(self.pipeline_details.destination_ecs_task_version_nbr), str(self.pipeline_id), str(self.pipeline_run_history_id))
        elif PipelineEnvironment.platform == "azure":
            return self.azure.start_container_task(self.pipeline_details.destination_ecs_task_nm, str(self.pipeline_details.destination_ecs_task_version_nbr), str(self.pipeline_id), str(self.pipeline_run_history_id))
        
        if PipelineEnvironment.connected_container:
            return PipelineEnvironment.task_id

    def log(self, message):
        if self.mode == "prod":
            self.api.log(message, self.pipeline_details.stage, self.task)
        else:
            print(message)

    def internal_log(self, message):
        if self.mode == "prod":
            self.api.log(message, self.pipeline_details.stage, self.task, internal=True)
        else:
            print(message)

    def error(self, message, error: object):
        if self.mode == "prod":
            self.api.log(message, self.pipeline_details.stage, self.task, error=error)
        else:
            print(message)

    def internal_error(self, message, error: object, unhandled=False):
        if self.mode == "prod":
            self.api.log(message, self.pipeline_details.stage, self.task, error=error, internal=True)
            if unhandled:
                self.api.log("An unrecognized issue has occurred on our side. Our team will be in contact within 24-48 hours, or try emailing support@dataconnector.com.", self.pipeline_details.stage, self.task, error)
            else:
                self.api.log(message, self.pipeline_details.stage, self.task, error=error)
        else:
            print(message)
            if unhandled:
                print("An unrecognized issue has occurred on our side. Our team will be in contact within 24-48 hours, or try emailing support@dataconnector.com.")

    def update_history(self, payload):
        self.api.put("{0}/history".format(self.pipeline_run_history_id), payload)

    def configure_fields(self):
        # get fields from connector
        fields = self.connector.get_fields(self.pipeline_details.source_object_id)

        if not fields:
            raise errors.NoFieldsFoundError(self.pipeline_details.source_object_id)


        mapping = self._build_auto_field_mapping(fields)

        self.pipeline_details.pipeline_mapping_json = json.dumps(mapping)

        self.api.create_pipeline_mapping(self.pipeline_id, self.pipeline_details.pipeline_mapping_json)

    def _process_rows(self, rows, max_allowed=None):
        # Check if we have a limit and need to truncate rows
        limit_reached = False
        if max_allowed is not None:
            remaining = max_allowed - self.row_count
            if remaining <= 0:
                # Already at or over limit, don't process any rows
                limit_reached = True
                self.log("You have reached your free trial row limit. Please upgrade to continue retrieving data.")
                return limit_reached
            elif len(rows) > remaining:
                # Truncate rows to fit within limit
                rows = rows[:remaining]
                limit_reached = True
        
        # set row count
        self.row_count += len(rows)
        # set bytes
        self.batch_index += 1
        # convert rows to json
        rows_json = json.dumps(rows)

        # Upload to s3
        json_buffer = io.StringIO(rows_json)

        key_name = f"e{self.pipeline_run_history_id}-b{self.batch_index}.json" if self.mode == 'prod' else f"devTransfers/e{self.prefix}-b{self.batch_index}.json"

        if PipelineEnvironment.platform == "aws":
            key_name = f"transfers/{key_name}"
            self.aws.upload_object(key_name, json_buffer=json_buffer)
        elif PipelineEnvironment.platform == "azure":
            key_name = f"{PipelineEnvironment.app_env}/{key_name}"
            self.azure.upload_object(key_name, json_buffer=json_buffer)

        self.successful_keys.append(key_name)

        if PipelineEnvironment.platform == "aws":
            self.bytes_transferred += self.aws.get_object_size(key_name)
        elif PipelineEnvironment.platform == "azure":
            self.bytes_transferred += self.azure.get_object_size(key_name)

        self.internal_log(self.log_templates.INTERNAL_GET_DATA_FETCHED.format(self.row_count))
        self.internal_log(self.log_templates.INTERNAL_S3_UPLOAD_LOG.format(key_name))

        if self.mode == 'prod':
            self.update_history({"updateAction": "ROWS_RETRIEVED", "RowsRetrievedNBR": self.row_count})
        
        # Log limit reached message if we hit the limit
        if limit_reached:
            self.log("You have reached your free trial row limit. Please upgrade to continue retrieving data.")
        
        return limit_reached

    def _get_credentials(self):
        encyption_txt = self.pipeline_details.source_encryption_credential_txt if self.task == "SOURCE" else self.pipeline_details.destination_encryption_credential_txt

        if not encyption_txt:
            return None

        # Set Connector Credentials
        return self.aws.decrypt_customer_data_object(encyption_txt, self.pipeline_details.customer_metadata_uuid)

    def _get_pipeline_details(self):
        return self.api.get_pipeline_details(str(self.pipeline_id), self.task, str(self.pipeline_run_history_id), pipeline_mapping_id=self.pipeline_object_id)

    def _get_batch_row_count(self):
        results = self.connector.get_data(
            self.pipeline_details.source_object_id,
            self._get_field_ids(),
            n_rows=32,
            filters=self._get_filters(),
            options=self.pipeline_details.options
        )

        rows = json.dumps(results.get('data', []))
        if not results.get('data'):  # No data returned
            self.internal_log("No data returned from connector. Defaulting batch row count to 1000.")
            return 1000  # or any sensible default

        json_buffer = io.StringIO(rows)

        key_name = (
            f"{TEMP_UPLOADS}/{self.pipeline_details.pipeline_run_history_id}.json"
            if self.mode == "prod"
            else f"devTransfers/{self.prefix}.json"
        )

        if PipelineEnvironment.platform == "aws":
            self.aws.upload_object(key_name, json_buffer=json_buffer)
            file_size = self.aws.get_object_size(key_name)
            self.aws.delete_object(key_name)
        elif PipelineEnvironment.platform == "azure":
            key_name = f"{PipelineEnvironment.app_env}/{key_name}"
            self.azure.upload_object(key_name, json_buffer=json_buffer)
            file_size = self.azure.get_object_size(key_name)
            self.azure.delete_object(key_name)

        self.internal_log(self.log_templates.INTERNAL_S3_UPLOAD_LOG.format(key_name))

        if file_size == 0:
            self.internal_log("File size is 0. Defaulting batch row count to 1000.")
            return 1000

        row_size = math.floor(file_size / 32)
        if row_size == 0:
            self.internal_log("Row size calculated as 0. Defaulting to minimum batch size of 1.")
            return 1

        batch_size = math.floor(5000000 / row_size)

        print("32 row byte size:", file_size)
        print("Row size:", row_size)
        print("Batch row count:", batch_size)

        return batch_size

    def _get_filters(self):
        if self.mode == "prod":
            return {
                "filtered_column_nm": self.pipeline_details.filtered_column_nm,
                "start_selection_nm": self.pipeline_details.start_selection_nm,
                "end_selection_nm": self.pipeline_details.end_selection_nm,
                "start_value_txt": self.pipeline_details.start_value_txt,
                "end_value_txt": self.pipeline_details.end_value_txt,
                "timezone_offset_nbr": self.pipeline_details.timezone_offset_nbr
            }
        else: 
            return self.filters

    def _get_field_ids(self):
        if not self.pipeline_details.pipeline_mapping_json:
            return []
        
        mapping_data = json.loads(self.pipeline_details.pipeline_mapping_json)
        field_ids = [x["mapped"] for x in mapping_data]

        return field_ids

    
    def _get_mapping(self):
        if self.mode == "prod":
            if not self.pipeline_details.pipeline_mapping_json:
                return []
            return json.loads(self.pipeline_details.pipeline_mapping_json)
        else:
            if not self.mapping:
                return []
            return json.loads(self.mapping)

    def _get_log_messages(self):
        # TODO: Make logs more dynamic
        # logs = self.api.get("log/templates")
        return LogTemplates(task=self.task)

    def _sanitize_pipeline_column_name(self, label, field_id):
        """Destination-safe name: letters, digits, underscores only; no leading digit."""
        if label is None:
            text = ""
        else:
            text = str(label).strip()
        if not text:
            text = str(field_id) if field_id is not None else ""
        text = str(text).strip()
        safe = re.sub(r"[^A-Za-z0-9]+", "_", text).strip("_")
        if not safe:
            fid = str(field_id) if field_id is not None else "field"
            safe = re.sub(r"[^A-Za-z0-9]+", "_", fid).strip("_") or "field"
        if safe[0].isdigit():
            safe = "c_" + safe
        return safe[:120]


    def _build_auto_field_mapping(self, fields):
        """
        Build pipeline mapping: mapped = source field_id (row keys from get_data),
        column = safe destination identifier derived from field_name / field_label.
        """
        seen = {}
        mapping = []
        for field in fields:
            fid = field["field_id"]
            label = field.get("field_name") or field.get("field_label") or fid
            base = self._sanitize_pipeline_column_name(label, fid)
            name = base
            i = 2
            while name in seen:
                suffix = f"_{i}"
                trim = max(1, 120 - len(suffix))
                name = base[:trim] + suffix
                i += 1
            seen[name] = True
            mapping.append({"column": name, "mapped": fid})
        return mapping