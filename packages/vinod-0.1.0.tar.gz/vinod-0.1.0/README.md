# vinod

**A stateful personal agent that learns how you work.**

Vinod passively observes your work patterns — file changes, coding sessions, task completions — and builds an episodic + semantic memory of your behavior over time.

> pip install vinod is currently a name reservation. Full release coming soon.

## What it will do

- Passive observation: watches file changes, Claude Code sessions, Google Sheets task tracker
- Episodic memory: append-only log of everything it sees
- Belief formation: weekly consolidation from episodic → stable behavioral patterns
- Personal model: fine-tuned on your own behavioral corpus (Day 75+)

## Status

Pre-alpha. Observer pipeline being built. ETA: mid-2026.

## Author

Arunabh Majumdar — arunabh.majumdar@gmail.com
