"""Vinod CLI — vinod init / status"""
from __future__ import annotations

import click


@click.group()
@click.version_option()
def cli() -> None:
    """Vinod: a stateful personal agent that learns how you work."""


@cli.command()
def init() -> None:
    """Initialise Vinod in the current user's home directory."""
    click.echo("Vinod: initialising observer pipeline... (coming soon)")


@cli.command()
def status() -> None:
    """Show current observer and memory status."""
    click.echo("Vinod: status check... (coming soon)")
