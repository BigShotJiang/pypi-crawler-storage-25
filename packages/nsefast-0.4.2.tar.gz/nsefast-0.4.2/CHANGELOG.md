# Changelog

All notable changes to **nsefast** are documented in this file.
The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and the project adheres to [Semantic Versioning](https://semver.org/).

## [0.4.2] - 2026-05-07

### Fixed — `daily_bhavcopy` now fully crash-proof; targeted tests for the 0.4.1 dual-URL fix

Architect review of 0.4.1 flagged two gaps which this patch closes:

* `daily_bhavcopy` parsed the input date eagerly outside any safety
  wrapper, so `daily_bhavcopy("2026/05/07")` (or any malformed input)
  raised `ValueError` instead of returning the canonical empty
  DataFrame. This violated the library-wide "never raises" contract.
  The function is now decorated with `@safe_dataframe(pl.DataFrame)`,
  bringing it back into compliance.
* The 0.4.1 dual-URL bhavcopy fix shipped without targeted tests —
  the highest-stakes change of the release was relying on a single
  manual smoke. Added `tests/test_bhavcopy_dual_url.py` (8 cases)
  using monkeypatched sessions and synthetic in-memory ZIPs:
  new-URL-first ordering, legacy fallback on 404, both-404 → empty,
  `FinInstrmTp == "STK"` filtering, new-schema → legacy → canonical
  round-trip, garbage-bytes safety, and the public-API contract for
  malformed / `None` inputs.

## [0.4.1] - 2026-05-07

### Fixed — daily bhavcopy 404 for all dates after mid-2024

NSE retired the legacy `archives.nseindia.com/content/historical/EQUITIES/<YYYY>/<MMM>/cm<DDMMMYYYY>bhav.csv.zip`
URL in mid-2024. Every `daily_bhavcopy(date)` call for a recent
trading day was returning HTTP 404 → empty DataFrame, with no
indication that the URL itself was the problem.

`daily_bhavcopy` now tries the modern path first
(`nsearchives.nseindia.com/content/cm/BhavCopy_NSE_CM_0_0_0_<YYYYMMDD>_F_0000.csv.zip`)
and falls back to the legacy path for older dates. The new
schema has different column names (`TckrSymb`, `OpnPric`,
`ClsPric`, `TtlTradgVol`, etc.) and includes derivatives rows;
the new helper `_parse_bhavcopy_zip` filters to `FinInstrmTp == 'STK'`
and renames the headers to the legacy form so downstream
`normalize_bhavcopy` works unchanged. The canonical
lowercase schema (`symbol, series, trade_date, open, high, low,
close, prev_close, volume, turnover`) is preserved end-to-end.

`normalize_bhavcopy` also gained defensive aliases for the new
uppercase headers in case raw new-schema files reach it without
going through the equity collector.

Both legacy and new bhavcopies now round-trip cleanly through
`daily_bhavcopy → normalize_bhavcopy → save_bhavcopy → load_range`.

## [0.4.0] - 2026-05-07

### Added — three quality-of-life features

**1. `nsefast doctor` — environment diagnostics CLI.**

`nsefast doctor` (or `nsefast doctor --offline`) runs ~13 checks and
prints a green/yellow/red health report. Covers Python version, every
required dependency (`polars`, `pyarrow`, `duckdb`, `requests`,
`typer`, `rich`) with version reporting, optional extras (`postgres`
+ `psycopg2`, the PyO3 rust core), filesystem writability for
`data/{raw,parquet}`, count of equity_bhavcopy parquet partitions,
NSE warm-up cookie reachability, and `robots.txt` permission. Each
check returns a structured `Check(name, status, detail, hint)` so JSON
mode (`nsefast --json doctor`) is pipeable. Exit code 1 if any check
failed. New module: `nsefast/doctor.py`. Tests: `tests/test_doctor.py`.

**2. Realistic transaction-cost model in the backtest engine.**

`BacktestConfig` gains three new knobs that materially improve the
credibility of backtest results:

* `min_brokerage_rs` — flat ₹ floor per side. Models the
  "₹20 or 0.03% whichever is lower" structure used by Indian discount
  brokers (Zerodha, Upstox). Default 0.0 (off).
* `commission_per_trade_rs` — flat ₹ fee added each side **on top of**
  the percentage brokerage. Useful for rolling regulatory turnover
  charges + GST on brokerage into one number. Default 0.0.
* `impact_bps` — extra adverse fill (basis points) per side, summed
  with `slippage_pct`. Model market impact for larger positions /
  mid-caps. Default 0.0.

All three default to zero so existing backtests reproduce bit-for-bit.
Tests: `tests/test_backtest_costs.py` covers each knob plus a
default-cost regression to lock in the no-change behaviour.

**3. `@safe_dataframe(empty_factory)` decorator.**

New module `nsefast/safe.py`. Replaces the
`try/except: log.warning; return empty()` boilerplate that's repeated
across the library. The decorator catches all exceptions (but not
`KeyboardInterrupt`), logs a warning with the function name, and
returns `empty_factory()`. Also coerces `None` returns to the canonical
empty frame. Used to retrofit `merge_overlapping_signals` and
`apply_portfolio_caps` — both already had the right behaviour, but
the decorator removes the boilerplate and makes the contract obvious
to readers. Tests: `tests/test_safe_decorator.py` (5 cases including
metadata preservation and KeyboardInterrupt pass-through).

## [0.3.3] - 2026-05-07

### Fixed — three architect-flagged contract-conformance violations

The whole library is built on one architectural guarantee:
**graceful failure with canonical empty outputs instead of leaking
partial/broken state.** A v0.3.2 audit found three places that
violated it. All three are now fixed and have explicit regression tests.

**1. `merge_overlapping_signals` leaked the original input on exception (SEVERE)**

`nsefast/strategies/_base.py::merge_overlapping_signals` returned the
unmodified input frame from its `except` block. If the caller passed a
malformed frame (wrong dtypes, missing columns, junk schema) the bug
hid the failure and let downstream code consume it — which then
crashed in non-obvious ways or, worse, persisted the broken rows.

Fix: the exception path now returns `empty_signals()` (canonical
14-column `SIGNAL_SCHEMA` empty frame). Test:
`test_merge_overlapping_signals_returns_canonical_empty_on_exception`
asserts both empty-ness *and* exact `SIGNAL_SCHEMA` dtype match.

**2. `apply_portfolio_caps` leaked unprocessed signals on exception (SEVERE)**

`nsefast/portfolio/risk_engine.py::apply_portfolio_caps` returned the
input frame on any internal failure, completely bypassing every
configured cap (max positions, sector exposure, cluster, drawdown
kill-switch). A silent failure here means uncapped positions reach
the executor.

Fix: exception path now returns an empty frame whose schema mirrors
the input so `.vstack` / `.concat` callers stay safe. Tests:
`test_apply_portfolio_caps_returns_empty_on_exception` and
`test_apply_portfolio_caps_none_input_returns_empty`.

**3. `walk_forward` aborted the entire sweep on one bad window (IMPORTANT)**

`nsefast/backtest/walkforward.py::walk_forward` wrapped the whole
window loop in a single `try`. An exception from `run_backtest`,
`to_backtest_signals`, or any sibling helper inside one window threw
away every prior window's results and returned an empty frame.

Fix: every window now runs in its own isolated `try` block. A failed
window logs a warning, appends a zero-metric row tagged with the
window id and date range, and the sweep continues. Tests:
`test_walk_forward_isolates_run_backtest_failures_per_window` (uses
`monkeypatch` to make `run_backtest` raise on every window and asserts
the sweep still produces rows with the canonical result schema) and
`test_walk_forward_result_schema_strict` (asserts dtypes for
`window_id`, `win_rate_pct`, `train_start`).

## [0.3.2] - 2026-05-07

### Added — regime layer, portfolio risk engine, walk-forward, HTML reporting

**1. `nsefast/regime/` — live market regime classifier**

New package: `classify_market` (bullish/bearish/sideways from NIFTY 50/200
DMA stack + 20-bar return + 50-DMA slope), `classify_volatility`
(low/normal/high from VIX percentiles, falls back to NIFTY realised
vol), `classify_breadth` (risk_on/neutral/risk_off from advance-decline
+ delivery + sector strength + FII/DII), and `classify_regime` which
fuses the three into a `Regime` dataclass with a composite label
(`bullish_low_vol_risk_on`) and confidence score. `apply_regime_sizing`
scales capital and stop-distance by regime via the `REGIME_SIZING`
table — high vol → wider stops, smaller capital; risk_off → cash-heavy.
All paths return canonical defaults on failure.

**2. Regime-aware `run_all`**

Each strategy now declares an `ALLOWED_REGIMES` tuple (e.g.
`momentum_52w` is bullish-only, `volume_breakout` works in any tape).
`run_all(..., regime=...)` skips strategies whose regime envelope
doesn't include the current market label. New helper
`allowed_regimes(name)` exposes the envelope.

**3. Cross-strategy `merge_overlapping_signals`**

When multiple strategies fire the same `(symbol, direction)` trade,
collapse them into one composite row. Confidence is boosted by
`+8 pp` per additional contributing strategy (capped at 100), and the
`reason` column lists every contributor (`composite[3]: a, b, c`).
Wired into `run_all(..., merge_overlap=True)`.

**4. `nsefast/portfolio/risk_engine.py`**

`PortfolioCaps` + `apply_portfolio_caps` greedy-trims a signal frame
by confidence to honour `max_positions`, `max_sector_exposure_pct`,
`max_correlated` (per cluster), and `max_portfolio_drawdown_pct`
(kill-switch). Sector exposure is computed against the fully-deployed
portfolio so the first pick of a sector isn't trivially rejected at
100% concentration. `portfolio_summary` rolls up per-sector and
per-cluster exposure for the report layer.

**5. `nsefast/backtest/walkforward.py`**

`walk_forward(history, signal_fn, *, start, end, config)` runs a
rolling out-of-sample sweep — splits the calendar into
(train, validate) windows, calls `signal_fn` on each validation date
with the in-sample slice, runs the resulting signals through
`run_backtest`, and returns one row of metrics per window. Per-date
exceptions in `signal_fn` are swallowed so a single bad date never
aborts the sweep.

**6. `nsefast/reporting/` — single-file HTML reports**

`build_report` / `write_report` produce a self-contained HTML page
with inline CSS and inline SVG charts (`equity_curve_svg`,
`drawdown_svg`, `sparkline_svg`) — zero JS, zero CDN deps. Sections:
header (date + regime composite + confidence chip), equity curve &
drawdown, strategy leaderboard, win-rate-by-regime breakdown, top
signals table.

**7. CLI**

* `nsefast regime show --date YYYY-MM-DD` — print classified regime.
* `nsefast report run --date YYYY-MM-DD --out report.html` — build a
  full HTML report.
* `nsefast strategy run all` gains `--regime` (filter by current
  market regime) and `--merge-overlap` (composite-merge agreed
  signals).

## [0.3.1] - 2026-05-07

### Fixed — two architect-flagged correctness bugs from 0.3.0

**1. NaN leak through `pl.max_horizontal` / `pl.min_horizontal` (SEVERE)**

`momentum_52w` (and `delivery_breakout`) computed the protective stop as
`max_horizontal(lo_20, entry × (1 - stop_pct/100))`. Polars NaN is
sticky — when `lo_20` was NaN (dirty history, missing partition,
freshly-listed symbol), the horizontal aggregator returned NaN even
though the fallback operand was finite. `finalize_signals` only
filtered nulls via `is_not_null`, so NaN-stop rows survived and would
land in parquet, JSON output, and the backtest engine.

Fix: (a) `finalize_signals` now scrubs `entry`/`stop_loss`/`target_1`/
`target_2`/`confidence_score`/`risk_reward` with `fill_nan(None)`
*before* the executable-row filter, so any NaN leak from any strategy
gets caught at the contract boundary; (b) both stop computations now
`coalesce(lo_20, pct_stop)` first so NaN can never reach the horizontal
aggregator.

**2. Delivery-breakout sector gate silently zero-rated unusable maps (SEVERE)**

When `sector_meta` covered none of the candidate symbols (mismatched
taxonomy, stale master, freshly listed names), the sector-strength
gate dropped every candidate without explanation. The priority
strategy could go silent operationally even though every other gate
passed.

Fix: when `sector_meta` covers 0 candidates the gate now logs a
warning and *passes through* (degrades gracefully). When coverage
exists but no covered sector intersects a positive index, the strategy
still drops all rows (correct behaviour) but emits an info log so
operators can investigate textual taxonomy mismatches.

### Tests

- `test_finalize_signals_scrubs_nan_leak_in_stop_loss` — pins the
  finalize-time NaN scrub.
- `test_delivery_breakout_skips_unusable_sector_gate` — pins the
  graceful-degrade behaviour.

## [0.3.0] - 2026-05-07

### Added — production strategy layer (`nsefast.strategies`)

A new top-level package that turns single-day bhavcopies (with optional
multi-day history) into ranked, executable swing-trading signals. Six
strategies ship in this release, all sharing the same crash-proof
contract and a single canonical 14-column `SIGNAL_SCHEMA`
(`trade_date, strategy_id, setup_name, symbol, direction, entry,
stop_loss, target_1, target_2, confidence_score, risk_reward, sector,
reason, signal_rank`).

**Strategies:**

- `delivery_breakout` (priority): price breakout + volume spike +
  delivery % above threshold + sector strength positive, with ASM /
  GSM / T2T / F&O-ban exclusion. Long-only.
- `volume_breakout`: directional unusual-volume spike (long if up,
  short if down) with a configurable percent-move floor.
- `sector_rotation`: long the top-N momentum names inside the strongest
  sectors, gated by `sector_strength` + `sector_meta` context.
- `momentum_52w`: long names within X% of their 252-bar high with
  volume confirmation. Requires `history` in context.
- `gap_breakout`: directional gap-and-hold (gap up + close ≥ open ⇒
  long; gap down + close ≤ open ⇒ short).
- `corporate_action_momentum`: post-action drift on names whose
  ex-date or announcement falls in the trailing window.

**Plumbing:**

- `_base.py` ships shared helpers: `prefilter_universe`,
  `enrich_from_history`, `normalize_score_0_100` (cross-sectional
  percentile rank → 0-100), `compute_levels` (1.5R / 3.0R targets),
  `finalize_signals` (rank + schema coercion + drop unexecutable rows),
  `dedupe_signals` (keep highest-confidence per `(symbol, direction)`),
  and `to_backtest_signals` (adapter to `run_backtest`).
- `_persist.py`: `save_signals` upserts to
  `data/parquet/strategy_signals/trade_date=YYYY-MM-DD/` with PK
  `(strategy_id, symbol, direction)` — re-running a date is idempotent.
- Registry + dispatcher: `REGISTRY`, `list_strategies`, `run_strategy`,
  `run_all` (concat + dedupe across strategies; re-ranks).

**CLI:**

- `nsefast strategy list` — show registered strategies (also via
  `--json` for piping).
- `nsefast strategy run <name> --date YYYY-MM-DD [--persist/--no-persist]`
  runs a single strategy. Hyphenated names accepted
  (`delivery-breakout` ≡ `delivery_breakout`).
- `nsefast strategy run all --date YYYY-MM-DD` fans out across every
  strategy and emits the deduped union.
- Auto-loads the optional context (ASM/GSM/F&O-ban, sector strength,
  symbol-master sector meta, corporate actions) from saved parquet.

### Quality

- 53 new tests (schema invariants, six-strategy registry,
  delivery-breakout gate matrix, volume-spike directionality,
  cross-strategy dedup, NaN-safety on every strategy, CLI smoke
  including end-to-end parquet persistence into a `tmp_path` root).
- Every public function returns the canonical empty
  `SIGNAL_SCHEMA` frame on failure — no exceptions escape, NaN never
  leaks into emitted scores or levels (`fill_nan(None)` everywhere).

## [0.2.15] - 2026-05-07

### Fixed — two architect-flagged correctness bugs from 0.2.14

**1. Notifier dropped posts on NaN/inf cells (HIGH)**

``nsefast.notify._format_value`` called ``int(v)`` for floats *before*
checking finiteness. ``int(float('nan'))`` and ``int(float('inf'))``
raise ``ValueError``, which was swallowed by the broad ``except`` in
``slack`` / ``discord`` / ``webhook`` and returned ``False``. Cron-
scheduled scans containing any NaN/inf cell silently dropped to chat.
Now non-finite floats render as ``"—"`` and the post goes through.

**2. Swing CLI silently mixed dates on missing partition (HIGH)**

``_load_bhavcopy_for(date)`` previously fell back to the unpartitioned
``daily_bhavcopy`` dataset when the requested date partition was
absent. Result: ``nsefast swing top-upside --date 2026-05-07`` could
emit a ranking built from any earlier saved bhavcopy with no warning.
Now strict-by-date: missing partition surfaces a clear "no bhavcopy"
error instead of corrupting the scan output.

### Deferred (acknowledged, scoped to follow-ups)

- Wiring ``cached_get(profile=...)`` into individual collector modules
  (currently the surface exists; collector adoption is a 0.2.16 item).
- Including ``rust-core/nsefast_core.pyi`` inside the wheel (the stub
  lives next to the Rust source it documents and applies when users
  ``maturin develop`` the optional native core; no runtime impact).

### Added tests (5 new, **303 total**)

- ``test_swing_strict_date_does_not_silently_fall_back``
- ``test_slack_handles_nan_inf``
- ``test_discord_handles_nan_inf``
- ``test_webhook_handles_nan_inf``
- ``test_format_value_handles_nan_inf_directly``

## [0.2.14] - 2026-05-07

### Added — operability bundle

**1. `nsefast swing` CLI subcommand (long requested)**

EOD scans no longer need a Python REPL. New commands read the saved
bhavcopy parquet for a given date and emit ranked Polars frames:

```
nsefast swing top-upside    --date 2026-05-07 --n 25
nsefast swing top-downside  --date 2026-05-07 --n 25
nsefast swing avoid         --date 2026-05-07 --max-volatility-pct 15
nsefast swing sector-leaders --date 2026-05-07 --n-per-sector 3
nsefast swing breakouts     --date 2026-05-07 --kind volume   # or delivery
```

Each command auto-loads ASM / GSM / FO-ban surveillance lists from
parquet (when present) and applies them as universe filters. Ready for
cron-scheduled EOD scans.

**2. Global `--json` output mode on every command**

```
nsefast --json swing top-upside --date 2026-05-07 --n 10 | jq '.rows[].symbol'
nsefast --json verify
nsefast --json cache profiles
```

Emits one JSON object per command suitable for piping into Slack /
email / Notion ingestion or any other downstream tooling. The flag is
declared once at the root and inherited by every subcommand including
``collect.*``, ``features.*``, ``export.*``, ``swing.*``, ``cache.*``,
``verify``, and ``version``.

**3. `nsefast.notify` — webhook formatters**

```
from nsefast.notify import slack, discord, webhook
slack(top_upside_df, webhook_url=os.environ["SLACK_WEBHOOK"],
      title="EOD Top Upside — 2026-05-07", top_n=10)
```

Posts a Polars DataFrame as Slack Blocks (header + section + mrkdwn
fixed-width table), Discord embeds, or a generic JSON webhook. All
three return ``True``/``False`` and never raise — empty frames post a
"no rows" placeholder so cron silence isn't mistaken for a network
failure. Missing columns are dropped silently rather than crashing.

**4. Per-collector cache TTL profiles**

The single ``DEFAULT_TTL_SECONDS = 300`` is replaced by a tunable
``TTL_PROFILES`` map keyed by collector class:

```
bhavcopy_closed   1 year      # daily bhavcopy is final after EOD
fo_bhavcopy       1 year
delivery          1 year
symbol_master     1 day
sector_strength   5 min
all_indices       5 min
deals             30 min
surveillance      1 hour
live_indices      60 s        # nifty/banknifty quote
option_chain      30 s
```

Use ``cached_get(session, url, profile="bhavcopy_closed")`` instead of
hard-coded TTLs. Operators can override at runtime via
``set_profile()`` or inspect the table with ``nsefast cache profiles
[--json]``. Backwards-compatible: existing ``ttl_seconds=`` callers
still work.

**5. Hypothesis property tests on scoring + filter helpers**

Added 7 property tests across ``swing.scoring`` and ``swing.filters``
generating random Polars frames (including NaN/+inf/-inf inputs) and
asserting:

- `momentum_score`/`volume_score` outputs always finite, in [0, 100]
- `composite_score` never raises and never leaks inf/NaN
- `momentum_zscore`/`volume_zscore` outputs always finite
- `liquid_universe`/`price_band` survive any input shape

The properties **caught a real bug**: NaN inputs were poisoning the
score columns (Polars NaN ≠ null), which corrupted Slack tables and
non-deterministically reordered scanner ranks. Fixed by normalizing
NaN→null on every scoring output (`fill_nan(None)`) before clipping.

**6. Type stubs for the optional Rust core**

New ``rust-core/nsefast_core.pyi`` documents ``fast_hash``, ``dedup``,
``snake_case``. Editors (PyCharm, Pylance) get full autocomplete and
hover docs even when the compiled extension isn't on the analysis
path.

### Fixed (caught by property tests)

- ``swing.scoring._scale_to_100`` now collapses NaN→null before
  clipping; previously a single NaN input column poisoned the
  composite score and produced non-deterministic scanner ranks.
- ``composite_score`` and ``_zscore_over`` apply the same NaN→null
  normalization.

### Tests

- 32 new tests (8 CLI / 9 notify / 8 cache TTL / 7 property), **298 total**.

## [0.2.13] - 2026-05-07

### Fixed — three architect-flagged issues from the 0.2.12 review

**1. `profit_factor = float('inf')` parquet round-trip risk (MEDIUM)**

When a strategy had wins but zero losses, ``compute_results`` emitted
``float('inf')`` into a Polars ``Float64`` column. Round-tripping
through parquet/JSON is undefined territory and downstream consumers
hit NaN/inf handling traps. Now emits ``None`` (parquet-safe null) for
the no-losses case; consumers can render "undefined / infinite" however
they prefer.

**2. Quality `partial_failure` flag missed degraded runs (MEDIUM)**

Engine flagged ``partial_failure=True`` only when *all* signals failed.
Now flags it when *any* signal is dropped (missing future bars, bad
OHLC, zero qty, gap blew the risk budget). Surfaces silent universe
issues that previously went unnoticed in successful-looking runs.

**3. `read_trades` schema drift on re-runs (MEDIUM)**

Hive partition columns (``year``, ``month``) could come back as
``Int64`` or ``Utf8`` from older partitions, drifting away from
``TRADE_SCHEMA``'s ``Int32``. Now defensively re-casts on read.

### Known limitations (deferred — fundamental design questions)

- **Orphan partial legs on re-run.** If run #1 wrote legs ``[0, 1]``
  with partials enabled and run #2 disables partials and writes only
  leg ``0``, the leg-1 row from run #1 stays in the ledger (upsert is
  per-PK, not "delete-keys-not-in-batch"). For now: re-runs that
  toggle partials should use a different ``strategy_id``.
- **Same-bar partial-then-target is optimistic.** EOD bars don't
  carry intra-day order; the engine assumes partial fills first
  within a bar. Realistic worst-case fix needs intra-bar simulation.

### Added tests (2 new, **266 total**)

- ``test_metrics_profit_factor_none_when_no_losses``
- ``test_quality_flags_partial_failure_on_any_bad_signal``
- (re-cast safety covered by the existing rerunnable-upsert tests)

## [0.2.12] - 2026-05-07

### Added — backtest engine foundation (`nsefast.backtest`)

The execution kernel that the v0.3.0 strategy modules will plug into.
Designed for daily Indian-equity swing trading; intentionally narrow
public surface, every function crash-proof.

**Position model** (`nsefast.backtest.Position`)

- Long/short, entry/stop/target/qty/capital_allocated/risk_rs.
- Mutable status enum: `open` → `closed | stopped | target_hit | expired | partial`.
- Re-derives qty at the actual fill price (so risk-per-trade stays
  honest under slippage and gap fills).

**Execution model** (`nsefast.backtest.engine.run_backtest`)

- EOD bar processing.
- Configurable entry rule: `next_open` (realistic; default) or `same_close`.
- Per-bar event ordering: gap-through-stop → intraday stop → gap-through-target
  → partial → intraday target → max-holding → end-of-history.
- Gap-up/gap-down honored at the open (the standard "honor the open"
  convention — gap-down through stop fills *worse* than stop, gap-up
  through target fills *better* than target).
- Partial exits via `partial_qty_pct` + `partial_target_r` (off the
  initial 1R risk leg by default).
- Slippage as a fraction of fill price (worsens both legs); brokerage
  as a fraction of notional on each side. PnL net of both.

**Trade ledger** (`nsefast.backtest.ledger`)

- `save_trades(df, mode="append")` — cheap one-shot writes via
  `append_partition`.
- `save_trades(df, mode="upsert")` — re-runnable backtests via
  `upsert_partition`. PK = `(strategy_id, symbol, entry_date, setup_name, leg)`.
  Running the same backtest twice produces the same ledger, not duplicates.
- `read_trades(strategy_id=...)` — filtered reads.
- Stored under dataset `backtest_trades`, hive-partitioned by
  `year/month` of `entry_date`.

**Result schema** (`nsefast.backtest.metrics.compute_results`)

Per-`strategy_id` aggregation: `total_trades`, `wins`, `losses`,
`win_rate`, `average_return`, `max_drawdown` (equity-curve), `profit_factor`,
`expectancy`, `average_holding_days`, `total_pnl_rs`, `gross_profit_rs`,
`gross_loss_rs`. Partial legs excluded from win/loss counting but their
PnL still contributes to gross/total.

**Quality tracking**

Engine wraps each run in `track_quality("backtest_engine", strategy_id)`
recording row count, content hash, latency, and partial-failure flag
when signals are dropped (missing future bars, bad OHLC, zero qty,
risk-budget gaps).

**Tests** (18 new, **264 total**)

Lifecycle (entry/exit), stop hit, target hit, max-holding expiry,
end-of-history force-close, gap-down through stop, gap-up through target,
short side, partial exit then target, next-open entry pricing, bad-OHLC
filtering, empty-input contract, no-future-bars graceful drop, metrics
math (win-rate / profit-factor / drawdown / expectancy), append-then-read,
upsert is rerunnable (no dupes on re-run), upsert overwrites changed
rows, quality audit row recorded.

## [0.2.11] - 2026-05-07

### Fixed — three architect-flagged issues from the 0.2.10 review

**1. `upsert_partition` atomicity (CRITICAL)**

The previous ordering deleted stale part files *before* the
``os.replace(tmp, part.parquet)``. A crash mid-delete could leave the
partition with no readable file — silent data loss. Reordered to
``write tmp → os.replace → sweep stale parts``: a crash before the
swap leaves the original partition intact; a crash after the swap
leaves stale parts that produce duplicate PK rows on read (re-running
the same idempotent upsert cleans them up). Strictly safer.

**2. `_meta` polluting the SQL namespace (MEDIUM)**

The audit table lives under ``data/parquet/_meta/quality/`` so
``register_all`` was registering ``_meta`` as a top-level DuckDB view,
showing up in ``list_views()`` next to the user's real datasets. Now
``register_all`` skips dirs whose name starts with ``_`` — internal
namespace stays out of the user surface. ``read_quality()`` is the
canonical way to query the audit table; users who want raw SQL access
can still ``register_dataset(con, "_meta")`` explicitly.

**3. `append_partition` filename collisions (MEDIUM)**

Was using a truncated 8-char UUID suffix (32 bits) plus 1-second
timestamp. Now uses the full 32-char ``uuid.uuid4().hex`` (128 bits)
— collision risk goes from "rare" to "won't happen in this universe".

### Added tests

- ``test_upsert_leaves_authoritative_part_file`` — after seeding a
  partition with two appends and one upsert, only ``part.parquet``
  remains. Catches the stale-sweep regression.
- ``test_register_all_skips_underscore_prefixed_dirs`` — recording a
  quality row creates ``_meta/quality/`` but ``list_views()`` does not
  expose ``_meta``.

**246 tests pass** (was 244, +2 regression tests).

## [0.2.10] - 2026-05-07

### Added — storage & query layer

Three additions targeting the daily friction points of running a parquet
store against a flaky upstream feed.

**1. SQL surface (`nsefast.swing.sql`)**

DuckDB is now first-class for ad-hoc queries against the parquet store.
``scan(query)`` registers every dataset directory as a SQL view and
runs the query, returning a Polars DataFrame. Hive partition columns
(``year``, ``month``, ``day``) are queryable as regular columns.

```python
from nsefast.swing.sql import scan
scan('''
    SELECT symbol, AVG(close) AS avg_close
    FROM daily_bhavcopy
    WHERE year = 2026 AND month >= 4
    GROUP BY symbol ORDER BY avg_close DESC LIMIT 20
''')
```

Crash-proof contract: any failure (bad SQL, missing dataset, parquet
read error) returns an empty DataFrame. ``list_views()`` enumerates
queryable datasets.

**2. Incremental writes (`nsefast.storage.parquet_store`)**

Until now every parquet save rewrote the entire partition. Two new
helpers:

- ``append_partition(df, dataset, by)`` — writes new ``part-<ts>-<uuid>.parquet``
  files into matching partition dirs without touching existing files.
  Reads transparently union all part files via DuckDB ``union_by_name``.
  Best for tick / ledger writes, audit logs, and the new quality table.
- ``upsert_partition(df, dataset, by, primary_key, keep="last")`` —
  read-modify-write per touched partition: concat with existing,
  dedup on ``primary_key``, atomically replace via tmp-file + rename.
  Best for idempotent collectors that may re-fetch the same date.

**3. Quality / audit table (`nsefast.storage.quality`)**

NSE drops feeds silently. One row per fetch is now recorded in the
``_meta/quality`` parquet partition with: timestamp, dataset, partition,
``row_count``, ``content_hash`` (SHA-256, row/column-order-invariant),
``fetch_latency_ms``, ``partial_failure`` flag, and short ``error``
message. Catches missed days, half-written partitions, and silent
schema drift. Helpers:

- ``record_quality(...)`` — append one row, crash-proof.
- ``track_quality(dataset, partition)`` — context manager that times
  the block, records the metadata on exit, and re-raises any
  exception with ``partial_failure=True``.
- ``read_quality(dataset=None, since=None, only_failures=False)`` —
  query the audit table.
- ``hash_dataframe(df)`` — canonical SHA-256 used for drift detection.

**14 new tests** (244 total): append creates multiple part files,
upsert dedupe with ``keep="last"`` and ``"first"``, missing PK raises,
quality round-trip, ``track_quality`` re-raises with metadata recorded,
hash order invariance, ``sql.scan`` happy + sad paths, scan picks up
appended files transparently. All under an isolated tmp parquet dir.

## [0.2.9] - 2026-05-07

### Fixed — risk-per-trade sizing in `nsefast.swing.setups` (post 0.2.8 review)

0.2.8 shipped the four canonical setups but a code review caught a
real semantic gap: every setup attached an ATR / chandelier stop, yet
``qty`` was computed as ``allocated_rs / entry_price`` — i.e.
*capital-weight* sizing, not *risk-per-trade* sizing. The stop was
attached but never used to size the position. Fixed in 0.2.9:

- New ``risk_pct`` parameter (default ``1.0`` %) on every setup. The
  rupee risk per trade is now ``risk_rs = allocated_rs * risk_pct/100``
  (so a 10% capital allocation at 1% risk-pct ⇒ 0.1% of total capital
  risked on this trade).
- ``qty`` is now ``floor(risk_rs / (entry - stop))`` — a stop-out
  costs exactly ``risk_rs``, the load-bearing invariant of
  position-risk sizing.
- New columns in ``BOOK_SCHEMA``: ``risk_rs`` (rupee risk budget)
  and ``notional_rs`` (= ``qty × entry_price``, the actual rupee
  exposure once shares are integer-rounded). Schema went from 14 to
  16 columns.
- ``portfolio_size``'s sector / cluster / single-name caps still
  govern the ``allocated_pct`` axis — ``risk_pct`` only scales the
  per-trade risk budget *within* that allocation. Caps remain
  load-bearing.

### Added tests

- Risk-per-trade invariant: ``qty * (entry - stop) ≤ risk_rs`` on
  every book row.
- ``risk_pct`` linearity: doubling ``risk_pct`` doubles ``qty`` for
  identical picks (modulo integer-floor rounding).
- Cluster-cap end-to-end: ``max_cluster_pct=25`` on a basket where
  ``correlation_clusters`` actually merges symbols caps the per-cluster
  ``allocated_pct`` at 25%. Closes the architect-flagged coverage gap.

**230 tests pass.**

## [0.2.8] - 2026-05-07

### Added — canonical end-to-end setups (`nsefast.swing.setups`)

Until now the smart-signals (`mom_z`, `rs_score`, `donchian_breakout`,
`consolidation_breakout`, `near_52w_high`) and the risk engine
(`add_atr_stop`, `add_chandelier_stop`, `portfolio_size`,
`correlation_clusters`) were primitives — useful but you had to wire
them together by hand. This release ships **four canonical NSE-swing
setups** that take a long-format OHLCV history and return a
ready-to-trade book in one call:

- `momentum_breakout_setup` — Donchian-N breakout filtered by RS rank
  vs a benchmark, sized with an ATR stop. Defaults: 20-bar Donchian,
  20-bar RS, top-40% RS gate, 2×ATR stop.
- `relative_strength_leaders_setup` — top RS leaders (60-bar default,
  top 20% gate) within 5% of the 52-week high. Minervini / IBD shape.
  Sized with a 2.5×ATR stop.
- `consolidation_breakout_setup` — VCP-style range-expansion
  breakout. Score = ATR-expansion ratio. Sized with a chandelier stop
  so winners can breathe.
- `mean_reversion_setup` — RSI-oversold (≤30) above the 200-SMA, sized
  with a tight 1.5×ATR stop. The contrarian counterpart to the trend
  setups.
- `all_setups` — runs all four with library defaults and concatenates
  the books, splitting capital evenly by default.

All five share the canonical book schema (`BOOK_SCHEMA`) so they
compose: stack them, filter by `setup` column, hand the union to a
broker terminal or a backtester. Every error path returns the same
empty-with-schema frame; setups never raise.

14 new tests cover canonical-empty contract on every input gap (empty
history, missing columns, zero capital, missing benchmark for
RS-leaders), plus end-to-end book emission, sector-cap respect, and
single-name cap respect on synthetic ramp panels. **228 tests pass.**

### Documentation

- `docs/V030_BACKTESTER.md` (the v0.3.0 design doc) gained an
  appendix locking the three open scoping decisions: forward-target
  horizon = **5 days** (10 days also computed); LLM tagger default =
  **OpenAI via the existing AI Integrations proxy** (Anthropic and
  local distilled-BERT also supported); training/backtesting
  universe = **NIFTY 500 active-on-date** by default
  (`universe="all_listed"` override).

## [0.2.7] - 2026-05-07

### Fixed — risk engine correctness (post 0.2.6 architect review)

- **`portfolio_size` is now a true water-fill allocator.** The 0.2.6
  implementation only scaled weights *down* against caps and never
  redistributed the freed weight to uncapped names — so e.g. raw
  weights `80/10/10` with a 60 % single cap produced `60/10/10`
  (only 80 % deployed) when `60/20/20` was feasible. Each pass now
  enforces caps, then redistributes any residual proportionally to
  *available headroom* (the smallest of single / sector / cluster
  room remaining), iterating until no headroom is left or the book
  is fully deployed. Cash residual still appears only when caps
  genuinely make full deployment infeasible.
- **`capped_by` recomputed from final weights.** Labels are no longer
  first-write-wins during iteration. After convergence each row is
  matched against every active constraint with a tight tolerance,
  with precedence **single → cluster → sector** (tightest scope first)
  when more than one cap binds simultaneously.
- **`correlation_clusters` is now pairwise NaN-tolerant.** The 0.2.6
  impl dropped any row containing a NaN across the *whole* sub-panel,
  which caused symbols with staggered listing histories to fall out
  into singleton clusters even when they had plenty of overlapping
  bars. Now each pair is correlated on the rows where both series are
  non-NaN (with a `min_overlap = max(5, lookback//4)` floor).
- **Docs:** `add_trailing_atr_stop` now documents the input-row-order
  monotonicity assumption (sort by `[symbol, trade_date]` first).

2 new regression tests for water-fill, 1 for staggered-NaN clustering.
213 in the suite green.

## [0.2.6] - 2026-05-07

### Added — risk engine

Per-trade sizing was already in v0.2.x; this release adds the
portfolio-level controls real swing desks actually run with.

#### `nsefast.swing.portfolio` (new module)

- `portfolio_size(picks, capital, *, max_positions=10, max_single_pct=10,
  max_sector_pct=30, max_cluster_pct=None, sector_col="sector",
  cluster_col="cluster_id", weight_col=None)` — equal-weight (or
  ``weight_col``-driven) allocation across the top ``max_positions``
  picks, then iteratively water-fills against single-name, sector, and
  optional cluster caps. Output: ``symbol``, ``weight``,
  ``allocated_pct``, ``allocated_rs``, ``capped_by``. Residual
  (cash) when caps bind is intentional.
- `correlation_clusters(history, symbols=None, *, lookback=60,
  threshold=0.7)` — greedy union-find on pairwise daily-log-return
  correlation; returns ``symbol`` / ``cluster_id``. Feed straight into
  ``portfolio_size(..., max_cluster_pct=...)`` so a TCS / INFY / WIPRO
  trio is treated as one cluster, not three independent bets.

#### `nsefast.swing.risk` (extended)

- `add_chandelier_stop(period=22, mult=3.0)` — rolling ``high.max(period)
  - mult * atr``. Tightens after pullbacks but rides trends.
- `add_trailing_atr_stop(period=14, mult=3.0)` — per-symbol cumulative
  max of ``close - mult * atr``. Never moves down once set.
- `add_swing_low_stop(window=10)` — rolling ``low.min(window)``. Pure
  price-action stop, no ATR dependency.
- `add_vol_target_size(capital, target_daily_vol_pct=0.5)` —
  vol-targeted sizing: ``qty = (capital * target_daily_vol_pct/100) / atr``.
  Each position contributes the same daily rupee P&L volatility, the
  way most quant desks actually size book.

All four compute ATR if it isn't already on the frame, and never raise.

#### Dependencies

- Added `numpy>=1.23` (used by `correlation_clusters` for the
  pairwise-correlation matrix).

17 new tests in `tests/test_risk_engine.py`; 211 in the suite green.

## [0.2.5] - 2026-05-07

### Fixed — signal correctness (post 0.2.4 architect review)

- **RSI edge cases.** `add_rsi` previously emitted `null` on zero-loss
  windows, which silently broke RSI in sustained uptrends. Now:
  `avg_loss == 0 & avg_gain > 0 ⇒ 100`,
  `avg_gain == 0 & avg_loss > 0 ⇒ 0`,
  `both zero ⇒ 50`, warm-up still `null`.
- **SuperTrend direction.** `st_dir` was effectively stuck at `+1`
  because it tested `close > st_lower` (lower band sits well below price).
  Corrected: `+1` only when `close > st_upper`, `-1` only when
  `close < st_lower`, otherwise `null`. Documented the basic-band
  semantics clearly.
- **Relative strength row fan-out.** `add_relative_strength` left-joined
  the benchmark by date without enforcing one row per date — duplicate
  benchmark dates would multiply price rows. Now deduplicates the
  benchmark to one row per `trade_date` (`group_by(date).last()`) so the
  output row count always equals the input price row count.

5 new regression tests; 194 in the suite green.

## [0.2.4] - 2026-05-07

### Added — smart signals

A full technical-indicator pack plus the multi-timeframe, relative-strength,
and breakout primitives that turn single-day scores into real swing setups.

#### `nsefast.processing.technicals` — full indicator pack

Each function takes a long-format frame and adds new column(s) per symbol
via `.over("symbol")`. Crash-proof; missing-column → input returned unchanged.

- `add_sma(n)`            → `sma_{n}`
- `add_ema(n)`            → `ema_{n}`
- `add_rsi(n)`            → `rsi_{n}`
- `add_macd(fast, slow, signal)` → `macd`, `macd_signal`, `macd_hist`
- `add_bollinger(n, k)`   → `bb_mid`, `bb_upper`, `bb_lower`
- `add_donchian(n)`       → `dc_upper`, `dc_lower`, `dc_mid`
- `add_supertrend(n, mult)` → `st_upper`, `st_lower`, `st_dir` (fully
  Polars-vectorised approximation; basic ATR bands without the
  path-dependent flip state machine)
- `add_adx(n)`            → `plus_di`, `minus_di`, `adx_{n}`
- `add_obv()`             → `obv` (per-symbol cumulative)
- `add_all_technicals()`  applies the full pack with library defaults
- Backwards-compatible thin wrappers `sma`, `ema`, `rsi`, `macd` retained.

#### `nsefast.swing.scoring` — multi-timeframe Z-scores

- `momentum_zscore(lookback=20)` — Z-score of per-symbol log-returns over
  `lookback` bars, output column `mom_z_{lookback}`.
- `volume_zscore(lookback=20)`   — Z-score of raw volume per symbol,
  `vol_z_{lookback}`.
- `add_multi_timeframe_zscores(lookbacks=(5, 20, 60))` — six-column bundle
  in one call.

These replace single-day `% change` ranking, which drowns in noise across
symbols. `Z > 1.5` is a meaningful move; `Z > 2.5` is exceptional.

#### `nsefast.swing.relative_strength` — leader detection

- `add_relative_strength(prices, benchmark, lookback=20)` — adds
  `rs_{lookback}` = symbol's lookback-day return *minus* the benchmark's,
  in percentage points. Pass NIFTY 50 for absolute leaders, a sector index
  for sector leaders.
- `add_rs_score(rs_col="rs_20")` — cross-sectional 0–100 percentile rank of
  the RS column *within each trade_date*, directly comparable across days.

#### `nsefast.swing.breakouts` — bread-and-butter swing setups

- `add_52w_high_low(window=252)` → `high_52w`, `low_52w` rolling extremes.
- `near_52w_high(within_pct=2.0)` — filter to candidates within `within_pct`
  of their 52-week high; adds `pct_below_52w_high` for ranking.
- `donchian_breakout(n=20)` — close exceeds the prior `n`-bar high (Turtle
  entry), excluding today's bar; adds `dc_prior_high`.
- `consolidation_breakout(atr_period=14, contraction_lookback=20,
  expansion_mult=1.5)` — VCP-style: today's ATR > `expansion_mult` × prior
  min ATR over `contraction_lookback`, AND close makes a 20-bar high.
- `add_gap_pct()` — `(open - prev_close) / prev_close × 100`. Uses the
  bhavcopy `prev_close` column when present, otherwise per-symbol shift.
- `add_range_atr(period=14)` — today's bar range divided by `atr_{period}`;
  values > 1 = expansion days.

26 new unit tests (all 189 in the suite green). Library-wide contract holds:
every function returns a Polars DataFrame and never raises.

## [0.2.3] - 2026-05-07

### Fixed — adjustment correctness

Follow-up to v0.2.2 after architect review:

- **Percentage dividends** (e.g. `"Dividend 250%"`) are now parsed correctly.
  `parse_purpose` returns a new `dividend_pct` action type;
  `compute_adjustment_factors` converts it to rupees using the
  `face_value` column on the corporate-actions row. When `face_value` is
  missing or non-positive, the row is *skipped*, never fabricated.
  `parse_purpose` also now matches `"Dividend 5/- per share"`.
- **Same-day multi-actions consolidated.** When a symbol has multiple
  corporate actions on the same `ex_date` (e.g. bonus + split together),
  `compute_adjustment_factors` now emits one row per `(symbol, ex_date)`
  whose `factor` is the product of all parsed factors and whose
  `action_type` joins the components with `+`. This matches the documented
  one-row-per-key contract and avoids downstream confusion.

### Docs

- Library-wide contract clarified in README: every **collector**,
  **processing**, and **swing** function returns a Polars DataFrame and
  never raises. Helper accessors (`available_dates`, `latest_date`,
  `active_symbols_on`, `is_active`, `delisted_symbols`) intentionally
  return primitives (`list[date]`, `date | None`, `list[str]`, `bool`) for
  ergonomics — they still never raise.

## [0.2.2] - 2026-05-07

### Added — data-quality layer

The single biggest source of "fake alpha" in swing-trading research is bad
history hygiene. v0.2.2 ships the four foundations every backtest needs:

- **`nsefast.history`** — multi-day OHLCV loader.
  - `load_range(start, end, symbols=..., series="EQ")` reads the
    hive-partitioned `equity_bhavcopy` store and returns a long-format frame
    (`symbol, trade_date, open, high, low, close, prev_close, volume,
    turnover`) with consistent dtypes.
  - `load_symbol`, `available_dates`, `latest_date` for point queries.
  - `save_bhavcopy(df, trade_date=...)` normalises raw NSE uppercase columns
    (`SYMBOL`, `TOTTRDQTY`, `TIMESTAMP`, …) and writes the partitioned store
    in one call.
  - `normalize_bhavcopy(df)` is exposed for users with their own pipelines.

- **`nsefast.processing.adjustments`** — split / bonus / dividend handling.
  - `parse_purpose(text)` decodes NSE's free-text `purpose` field
    (`"Stock Split From Rs.10/- to Rs.5/-"`, `"Bonus 1:1"`,
    `"Dividend - Rs 5"`, …) into `(action_type, factor_or_amount)`.
  - `compute_adjustment_factors(actions_df, prices_df=None)` emits one row
    per `(symbol, ex_date)` with the multiplicative `factor`. Dividends are
    skipped when no prior close is available — we never fabricate prices.
  - `apply_adjustments(prices, factors)` adds `adj_open / adj_high / adj_low
    / adj_close / adj_prev_close / adj_volume`. Cumulative factor is the
    product of every factor whose `ex_date` is strictly after the row's
    `trade_date`; volume is divided so per-share units stay comparable.

- **`nsefast.master.symbols_history`** — survivorship.
  - `build_symbols_history()` walks every saved bhavcopy partition and
    persists `(symbol, trade_date, series)` to
    `data/parquet/symbols_history/year=YYYY/`.
  - `active_symbols_on(d)`, `is_active(symbol, d)`, `delisted_symbols(after)`
    give O(1) point-in-time membership queries — so backtests don't
    accidentally see today's universe in 2020.

- **`nsefast.master.index_constituents`** — investable universes.
  - `index_constituents("NIFTY 50")` fetches the live constituent CSV from
    `archives.nseindia.com`, normalised to `symbol, company_name, industry,
    series, isin, index_name, source_url, fetched_at`.
  - `KNOWN_INDICES` covers ~21 NSE indices: NIFTY 50/100/200/500, Next 50,
    Midcap 50/100/150, Smallcap 50/100/250, Microcap 250, Bank, IT, Auto,
    FMCG, Pharma, Metal, Energy, Realty, Financial Services.
  - `historical_index_constituents(...)` is a documented scaffold with the
    final shape; implementation lands with the rebalance crawler in v0.3.0.

26 new unit tests (all 159 in the suite still green). Every new function
follows the library-wide contract: returns a Polars DataFrame on every path
and **never raises**.

## [0.2.1] - 2026-05-07

### Fixed

- `swing.scanner`, `swing.watchlist`, `swing.backtest` empty-frame schemas now
  use the **same dtypes** as the success path (e.g. `score: Float64`,
  `pnl_pct: Float64`, `traded_qty: Int64`). Previous releases returned all-Utf8
  empty frames, which broke downstream `.sort()` / numeric aggregations on
  empty days.
- `swing.risk.add_atr` docstring clarified: TR follows Wilder's definition,
  smoothing is SMA (not Wilder's RMA). Behaviour unchanged.

## [0.2.0] - 2026-05-07

### Added — `nsefast.swing` research layer

A new top-level package that turns collector outputs into ranked swing-trading
research. Architecture stays clean: `collectors/` fetch, `processing/` engineer
features, `swing/` ranks & sizes, `storage/` persists.

- `swing.filters` — `series_eq_only`, `price_band`, `liquid_universe`,
  `min_avg_volume`, `exclude_symbols`, `exclude_surveillance`. Compose via
  `df.pipe(...)`. Each filter is a no-op when its required column is missing.
- `swing.scoring` — `momentum_score`, `volume_score`, `delivery_score`, plus
  `composite_score(weights={...})` which renormalizes when components are
  absent. `add_all_scores(df)` runs the full pipeline.
- `swing.risk` — scalar `position_size`, `risk_reward`; vector helpers
  `add_atr` (Wilder TR over `(symbol, trade_date)`), `add_atr_stop`,
  `add_position_size`. ATR is grouped by symbol when the column is present.
- `swing.scanner` — `top_upside`, `top_downside`, `avoid_list`,
  `sector_leaders`, `delivery_breakout`, `volume_breakout`.
- `swing.watchlist` — `bulk_block_watchlist` (aggregates by symbol),
  `corporate_announcement_watchlist` (keyword-tagged), `combined_watchlist`
  (source-tagged union).
- `swing.backtest` — minimal `run_backtest(history, signal_fn, holding_days)`
  walk-forward simulator + `summary_stats` (trades, win-rate, avg/total/best/
  worst PnL, naive Sharpe). Full backtesting + ML scoring lands in v0.3.0.
- 33 new unit tests (132 total, still no network), covering scoring edge
  cases (zero-divide volume, clipping), filter no-ops, ATR pipeline, scanner
  ranking, watchlist deduplication, backtest forward returns.

### Guarantees

- Every public swing function returns a Polars DataFrame with a canonical
  schema and **never raises** — same crash-proof contract as collectors.
- Empty / malformed inputs produce empty (not failing) outputs, so research
  pipelines that span weekends or missing data continue to run cleanly.

## [0.1.1] - 2026-05-06

### Added

- **Hive-partitioned parquet** — `save_parquet_partitioned(df, dataset, by=[…])`,
  `read_parquet_partitioned(dataset, filters=[(col, op, val), …])`,
  `derive_date_partitions(df, "trade_date", parts=("year","month","day"))`,
  `list_partitions(dataset)`. Pushdown predicates handled by PyArrow.
- **DuckDB analytics helpers** — `connect()`, `register_all(con)` registers
  one view per dataset, plus canned queries `top_gainers`, `top_losers`,
  `daily_summary`, `sector_leaderboard`. All views read with
  `hive_partitioning = true, union_by_name = true`.
- **Request cache layer** — `nsefast.cache.cached_get(session, url, ttl_seconds)`
  is a content-addressed on-disk cache (`data/cache/<sha>.bin` + meta sidecar).
  Default TTL 5 min. Never raises, never caches non-200, expires cleanly.
  CLI: `nsefast cache stats`, `nsefast cache clear`.
- **Structured logging** — `nsefast.logging_setup.setup_logging(level, fmt)`
  with `fmt="json"` emits one-line JSON per record (ts, level, logger, msg,
  plus any `extra={…}`). Configurable via `NSEFAST_LOG_FORMAT=json` and
  `NSEFAST_LOG_LEVEL=DEBUG`.
- **Install verification CLI** — `nsefast verify` smoke-tests imports,
  parquet roundtrip, duckdb in-memory query, and CLI registration. Pass
  `--network` to additionally test NSE warm-up + robots.txt fetch.
  `nsefast version` prints the installed version.
- 22 new unit tests covering all of the above (99 total, still no network).

### Fixed

- DuckDB view registration now inlines the validated parquet glob path
  (DuckDB does not accept prepared parameters alongside `hive_partitioning`).
  Single quotes in the path are SQL-escaped.

## [0.1.0] - 2026-05-06

### Added

- Initial public release.
- Polite HTTP client with warm-up cookie session, retries, and `robots.txt` enforcement.
- Live JSON collectors with full graceful-failure semantics:
  - `deals.bulk_deals(start, end)`, `deals.block_deals(start, end)`
  - `corporate.corporate_announcements(start, end)`, `corporate.corporate_actions(start, end)`
  - `corporate.dividends`, `bonuses`, `splits`, `rights_issues`, `mergers_demergers`, `record_and_ex_dates`
  - `derivatives.option_chain(symbol)`, `option_chain_equity`, `option_chain_index`
  - `indices.all_indices()`, `indices.sector_strength()`, `indices.is_sector_index(name)`
  - `equity.fifty_two_week_high_low()`, `fifty_two_week_high()`, `fifty_two_week_low()`
- Daily archive collectors:
  - `equity.daily_bhavcopy(date)`, `equity.delivery_data(date)`
  - `derivatives.fo_bhavcopy(date)`
  - `master.symbol_master()`
- Polars-first dataframe layer with canonical schemas per collector.
- Parquet canonical storage (`storage.parquet_store`), DuckDB analytics views
  (`storage.duckdb_store`), optional PostgreSQL (`storage.postgres_store`).
- Typer CLI: `nsefast collect …`, `nsefast features swing`, `nsefast export parquet`.
- Optional Rust core (`rust-core/`) exposing `fast_hash`, `dedup`, `snake_case` via PyO3.
- 77 unit tests covering field mapping, alternate field names, malformed payloads,
  network failures, HTTP errors, JSON decode errors, robots.txt blocks, schema
  ordering, chunk-window arithmetic, CE/PE leg flattening, and sector classification.

### Notes

- All public collectors return a Polars DataFrame with the canonical schema on
  **any** failure (network, JSON, malformed payload, polars error, etc.) and
  never raise — pipelines stay crash-proof.
- NSE blocks many datacenter IP ranges; from such hosts, collectors will
  return empty DataFrames rather than crash.
