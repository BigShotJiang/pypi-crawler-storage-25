"""Swing-trading research layer built on top of ``nsefast.collectors``.

This package consumes the canonical Polars DataFrames produced by collectors
and turns them into actionable, ranked research outputs:

- :mod:`nsefast.swing.scanner`   — top upside/downside, avoid list, sector leaders,
                                   delivery & volume breakouts
- :mod:`nsefast.swing.scoring`   — composite 0-100 score (momentum + volume + delivery)
- :mod:`nsefast.swing.risk`      — ATR, stop-loss, position sizing, R:R
- :mod:`nsefast.swing.filters`   — liquidity, price-band, series, surveillance exclusions
- :mod:`nsefast.swing.watchlist` — bulk/block deals, corporate-announcement watchlists
- :mod:`nsefast.swing.backtest`  — minimal walk-forward harness (stub for v0.3.0)

All public functions return Polars DataFrames and **never raise**: any
unexpected input or runtime error returns an empty DataFrame whose schema
matches the success path. This keeps research pipelines crash-proof.
"""

from nsefast.swing.scanner import (
    avoid_list,
    delivery_breakout,
    sector_leaders,
    top_downside,
    top_upside,
    volume_breakout,
)
from nsefast.swing.watchlist import (
    bulk_block_watchlist,
    combined_watchlist,
    corporate_announcement_watchlist,
)
from nsefast.swing.scoring import (
    add_multi_timeframe_zscores,
    momentum_zscore,
    volume_zscore,
)
from nsefast.swing.relative_strength import (
    add_relative_strength,
    add_rs_score,
)
from nsefast.swing.breakouts import (
    add_52w_high_low,
    add_gap_pct,
    add_range_atr,
    consolidation_breakout,
    donchian_breakout,
    near_52w_high,
)
from nsefast.swing.risk import (
    add_chandelier_stop,
    add_swing_low_stop,
    add_trailing_atr_stop,
    add_vol_target_size,
)
from nsefast.swing.portfolio import (
    correlation_clusters,
    portfolio_size,
)
from nsefast.swing.setups import (
    BOOK_SCHEMA,
    all_setups,
    consolidation_breakout_setup,
    mean_reversion_setup,
    momentum_breakout_setup,
    relative_strength_leaders_setup,
)
from nsefast.swing.sql import list_views, scan

__all__ = [
    "top_upside",
    "top_downside",
    "avoid_list",
    "sector_leaders",
    "delivery_breakout",
    "volume_breakout",
    "bulk_block_watchlist",
    "corporate_announcement_watchlist",
    "combined_watchlist",
    "momentum_zscore",
    "volume_zscore",
    "add_multi_timeframe_zscores",
    "add_relative_strength",
    "add_rs_score",
    "add_52w_high_low",
    "near_52w_high",
    "donchian_breakout",
    "consolidation_breakout",
    "add_gap_pct",
    "add_range_atr",
    "add_chandelier_stop",
    "add_trailing_atr_stop",
    "add_swing_low_stop",
    "add_vol_target_size",
    "correlation_clusters",
    "portfolio_size",
    "BOOK_SCHEMA",
    "momentum_breakout_setup",
    "relative_strength_leaders_setup",
    "consolidation_breakout_setup",
    "mean_reversion_setup",
    "all_setups",
    "scan",
    "list_views",
]
