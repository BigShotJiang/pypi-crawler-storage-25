"""SQL surface over the partitioned parquet store.

Most swing-research questions are easier to express in SQL than in
chained ``.pipe()`` calls — e.g. *"top-10 symbols by 20-day return
where avg turnover > 5cr"*. This module is the thin convenience layer
that wires DuckDB onto the parquet store and registers every dataset
directory as a view.

Usage::

    from nsefast.swing.sql import scan
    df = scan('''
        SELECT symbol, AVG(close) AS avg_close
        FROM daily_bhavcopy
        WHERE year = 2026 AND month >= 4
        GROUP BY symbol ORDER BY avg_close DESC LIMIT 20
    ''')

Crash-proof contract: any failure (missing dataset, bad SQL, parquet
read error, DuckDB unavailable) returns an empty Polars DataFrame.
Never raises.
"""

from __future__ import annotations

from typing import Iterable

import polars as pl

from nsefast.logging_setup import get_logger
from nsefast.storage.duckdb_store import connect, register_all, register_dataset

log = get_logger(__name__)


def scan(
    query: str,
    *,
    datasets: Iterable[str] | None = None,
    db_path: str | None = None,
) -> pl.DataFrame:
    """Run a SQL ``query`` over the partitioned parquet store.

    Parameters
    ----------
    query
        Any DuckDB SQL. Reference datasets by their directory name under
        ``data/parquet/`` (e.g. ``daily_bhavcopy``, ``bulk_deals``).
        Hive partition columns (``year``, ``month``, ``day``) are
        available as regular columns thanks to ``hive_partitioning``.
    datasets
        Optional explicit allow-list of dataset views to register. By
        default every dataset directory is registered (cheap — they're
        lazy views). Pass an explicit list when you want fast startup
        on a store with many datasets.
    db_path
        Override the DuckDB file path. Defaults to ``DUCKDB_PATH`` from
        ``nsefast.config``. Pass ``":memory:"`` for an ephemeral session.

    Returns
    -------
    pl.DataFrame
        Query result, or an empty DataFrame on any failure.
    """
    try:
        con = connect(db_path) if db_path else connect()
        try:
            if datasets is None:
                register_all(con)
            else:
                for d in datasets:
                    try:
                        register_dataset(con, d)
                    except Exception as exc:  # noqa: BLE001
                        log.warning(
                            "scan: skipped dataset",
                            extra={"dataset": d, "err": str(exc)},
                        )
            arrow_tbl = con.execute(query).arrow()
            return pl.from_arrow(arrow_tbl)
        finally:
            con.close()
    except Exception as exc:  # noqa: BLE001
        log.warning("sql.scan failed", extra={"err": str(exc)})
        return pl.DataFrame()


def list_views(*, db_path: str | None = None) -> list[str]:
    """Return the names of every dataset registered as a SQL view.

    Useful for discovery: ``scan('SELECT 1')`` first, then
    ``list_views()`` to see what tables are queryable.
    """
    try:
        con = connect(db_path) if db_path else connect()
        try:
            return register_all(con)
        finally:
            con.close()
    except Exception as exc:  # noqa: BLE001
        log.warning("list_views failed", extra={"err": str(exc)})
        return []
