"""Canonical schema, scoring, and finalization helpers for strategies.

Every strategy module under ``nsefast.strategies`` exposes a
``generate_signals(trade_date, universe, context)`` function whose return
value matches :data:`SIGNAL_SCHEMA` exactly. This module supplies the
shared building blocks so each strategy stays focused on its own logic.

Design rules
------------
* **Polars-native end to end.** No pandas; no Python loops over rows.
* **Crash-proof.** Every helper returns the canonical empty signal frame
  on failure (never raises). Strategies follow the same contract.
* **Score normalization to 0-100.** ``normalize_score_0_100`` is a
  cross-sectional percentile rank within the produced batch — directly
  comparable across strategies once concatenated.
* **Levels are derived once, in one place.** Targets and risk-reward
  come from :func:`compute_levels` so every strategy emits consistent
  geometry (target_1 = 1.5 R, target_2 = 3.0 R by default).
"""
from __future__ import annotations

from datetime import date, datetime
from typing import Mapping

import polars as pl

from nsefast.logging_setup import get_logger
from nsefast.safe import safe_dataframe

log = get_logger(__name__)


SIGNAL_SCHEMA: Mapping[str, pl.DataType] = {
    "trade_date":       pl.Date,
    "strategy_id":      pl.Utf8,
    "setup_name":       pl.Utf8,
    "symbol":           pl.Utf8,
    "direction":        pl.Utf8,    # "long" | "short"
    "entry":            pl.Float64,
    "stop_loss":        pl.Float64,
    "target_1":         pl.Float64,
    "target_2":         pl.Float64,
    "confidence_score": pl.Float64,  # 0-100
    "risk_reward":      pl.Float64,  # to target_1
    "sector":           pl.Utf8,
    "reason":           pl.Utf8,
    "signal_rank":      pl.Int64,    # 1 = highest confidence within strategy
}


def empty_signals() -> pl.DataFrame:
    """Canonical empty signals frame — same dtypes as the success path."""
    return pl.DataFrame(schema=dict(SIGNAL_SCHEMA))


def to_date(d: date | str) -> date | None:
    """Parse YYYY-MM-DD strings to ``date``; pass through ``date`` inputs."""
    try:
        if isinstance(d, date):
            return d
        return datetime.strptime(str(d), "%Y-%m-%d").date()
    except Exception as exc:  # noqa: BLE001
        log.warning("to_date(%r) failed: %s", d, exc)
        return None


# ---------- universe pre-filter shared by every strategy --------------------

def prefilter_universe(
    universe: pl.DataFrame,
    context: dict | None = None,
    *,
    require_eq: bool = True,
) -> pl.DataFrame:
    """Drop non-EQ series, ASM, GSM, T2T, and F&O-ban symbols.

    Looks up ``context["asm" | "gsm" | "fo_ban"]`` for surveillance lists
    (each must have a ``symbol`` column). T2T is handled via the
    ``series`` column (bhavcopy provides ``BE`` / ``BZ`` / ``T2T`` for
    trade-to-trade names) — ``require_eq=True`` keeps only ``EQ``.
    Missing inputs are no-ops, never failures.
    """
    ctx = context or {}
    if universe is None or universe.is_empty():
        return universe if universe is not None else pl.DataFrame()
    df = universe
    try:
        if require_eq and "series" in df.columns:
            df = df.filter(pl.col("series").cast(pl.Utf8).str.to_uppercase() == "EQ")
        if "symbol" not in df.columns:
            return df
        for key in ("asm", "gsm", "fo_ban"):
            sl = ctx.get(key)
            if sl is None or sl.is_empty() or "symbol" not in sl.columns:
                continue
            bad = sl["symbol"].cast(pl.Utf8).drop_nulls().unique().to_list()
            if bad:
                df = df.filter(~pl.col("symbol").cast(pl.Utf8).is_in(bad))
        return df
    except Exception as exc:  # noqa: BLE001
        log.warning("prefilter_universe failed: %s", exc)
        return universe


# ---------- 0-100 score normalization ---------------------------------------

def normalize_score_0_100(
    df: pl.DataFrame,
    raw_col: str,
    *,
    out_col: str = "confidence_score",
) -> pl.DataFrame:
    """Cross-sectional percentile rank of ``raw_col`` → ``[0, 100]``.

    Higher raw value ⇒ higher percentile. NaN/null inputs become null
    in the output (so a strategy that produces all-NaN raw scores
    surfaces explicitly rather than poisoning the rank).
    """
    if df is None or df.is_empty():
        return df.with_columns(pl.lit(None, dtype=pl.Float64).alias(out_col)) \
            if df is not None else pl.DataFrame()
    if raw_col not in df.columns:
        return df.with_columns(pl.lit(None, dtype=pl.Float64).alias(out_col))
    try:
        clean = pl.col(raw_col).cast(pl.Float64, strict=False).fill_nan(None)
        n = clean.count()
        # rank is 1..N; map to 0..100 such that the worst gets 0 and the
        # best gets 100. A single-symbol batch defaults to 50 (neutral).
        rank = clean.rank(method="average")
        score = (
            pl.when(n > 1)
              .then((rank - 1.0) / (n - 1.0) * 100.0)
              .otherwise(pl.lit(50.0, dtype=pl.Float64))
        )
        return df.with_columns(score.fill_nan(None).clip(0.0, 100.0).alias(out_col))
    except Exception as exc:  # noqa: BLE001
        log.warning("normalize_score_0_100 failed: %s", exc)
        return df.with_columns(pl.lit(None, dtype=pl.Float64).alias(out_col))


# ---------- target / risk-reward computation -------------------------------

def compute_levels(
    df: pl.DataFrame,
    *,
    direction_col: str = "direction",
    entry_col: str = "entry",
    stop_col: str = "stop_loss",
    rr1: float = 1.5,
    rr2: float = 3.0,
) -> pl.DataFrame:
    """Add ``target_1`` / ``target_2`` / ``risk_reward`` from entry & stop.

    Long: target = entry + rr × |entry − stop|.
    Short: target = entry − rr × |entry − stop|.

    ``risk_reward`` is the multiple to ``target_1`` (= ``rr1``) when the
    trade is geometrically valid, else ``0.0``.
    """
    if df is None or df.is_empty():
        return df if df is not None else pl.DataFrame()
    needed = {direction_col, entry_col, stop_col}
    if not needed.issubset(df.columns):
        return df
    try:
        risk = (pl.col(entry_col).cast(pl.Float64, strict=False)
                - pl.col(stop_col).cast(pl.Float64, strict=False)).abs()
        is_long = pl.col(direction_col).cast(pl.Utf8) == "long"
        t1 = pl.when(is_long).then(pl.col(entry_col) + rr1 * risk) \
                              .otherwise(pl.col(entry_col) - rr1 * risk)
        t2 = pl.when(is_long).then(pl.col(entry_col) + rr2 * risk) \
                              .otherwise(pl.col(entry_col) - rr2 * risk)
        rr_val = pl.when(risk > 0).then(pl.lit(rr1, dtype=pl.Float64)) \
                                    .otherwise(pl.lit(0.0, dtype=pl.Float64))
        return df.with_columns([
            t1.fill_nan(None).alias("target_1"),
            t2.fill_nan(None).alias("target_2"),
            rr_val.alias("risk_reward"),
        ])
    except Exception as exc:  # noqa: BLE001
        log.warning("compute_levels failed: %s", exc)
        return df


# ---------- finalization ----------------------------------------------------

def finalize_signals(
    df: pl.DataFrame,
    *,
    trade_date: date | str,
    strategy_id: str,
    setup_name: str,
    sector_meta: pl.DataFrame | None = None,
) -> pl.DataFrame:
    """Stamp metadata, attach sector, rank, and coerce to canonical schema.

    ``df`` must already carry: ``symbol``, ``direction``, ``entry``,
    ``stop_loss``, ``target_1``, ``target_2``, ``confidence_score``,
    ``risk_reward``. Missing optional columns (``sector``, ``reason``)
    are filled with nulls. ``signal_rank`` is computed as the 1-based
    position when sorted by ``confidence_score`` descending.

    Rows that are missing entry/stop_loss/symbol are dropped — they
    cannot be backtested or executed.
    """
    if df is None or df.is_empty():
        return empty_signals()
    try:
        td = to_date(trade_date)
        if td is None:
            return empty_signals()

        out = df.with_columns([
            pl.lit(td, dtype=pl.Date).alias("trade_date"),
            pl.lit(strategy_id, dtype=pl.Utf8).alias("strategy_id"),
            pl.lit(setup_name, dtype=pl.Utf8).alias("setup_name"),
        ])

        # Optional sector attach
        if "sector" not in out.columns:
            if sector_meta is not None and not sector_meta.is_empty() \
                    and {"symbol", "sector"}.issubset(sector_meta.columns):
                out = out.join(
                    sector_meta.select([
                        pl.col("symbol").cast(pl.Utf8),
                        pl.col("sector").cast(pl.Utf8),
                    ]).unique(subset=["symbol"]),
                    on="symbol", how="left",
                )
            else:
                out = out.with_columns(pl.lit(None, dtype=pl.Utf8).alias("sector"))
        if "reason" not in out.columns:
            out = out.with_columns(pl.lit(None, dtype=pl.Utf8).alias("reason"))

        # NaN sanitation: convert any numeric NaN to null *before* the
        # executable-row filter. ``pl.max_horizontal`` and a few arithmetic
        # paths can leak NaN even when one operand is finite (NaN is sticky).
        # Without this scrub, NaN entry/stop/target rows would survive the
        # is_not_null check and poison parquet, JSON, and the backtest engine.
        numeric_safe = []
        for col in ("entry", "stop_loss", "target_1", "target_2",
                    "confidence_score", "risk_reward"):
            if col in out.columns:
                numeric_safe.append(
                    pl.col(col).cast(pl.Float64, strict=False)
                              .fill_nan(None).alias(col)
                )
        if numeric_safe:
            out = out.with_columns(numeric_safe)

        # Drop rows that fail the minimum bar for an executable signal
        out = out.filter(
            pl.col("symbol").is_not_null()
            & pl.col("entry").is_not_null()
            & pl.col("stop_loss").is_not_null()
            & (pl.col("entry") != pl.col("stop_loss"))
        )
        if out.is_empty():
            return empty_signals()

        # Rank by confidence (highest = 1)
        out = out.sort("confidence_score", descending=True, nulls_last=True)
        out = out.with_columns(
            pl.int_range(1, pl.len() + 1, dtype=pl.Int64).alias("signal_rank")
        )

        # Coerce to canonical schema and column order
        casts = []
        for col, dtype in SIGNAL_SCHEMA.items():
            if col in out.columns:
                casts.append(pl.col(col).cast(dtype, strict=False).alias(col))
            else:
                casts.append(pl.lit(None, dtype=dtype).alias(col))
        return out.select(casts).select(list(SIGNAL_SCHEMA.keys()))
    except Exception as exc:  # noqa: BLE001
        log.warning("finalize_signals(%s) failed: %s", strategy_id, exc)
        return empty_signals()


# ---------- cross-strategy deduplication -----------------------------------

@safe_dataframe(empty_signals, name="merge_overlapping_signals")
def merge_overlapping_signals(
    df: pl.DataFrame,
    *,
    on: tuple[str, ...] = ("symbol", "direction"),
    boost_pct_per_extra: float = 8.0,
    cap: float = 100.0,
) -> pl.DataFrame:
    """Composite signals where multiple strategies agree on the same trade.

    For each ``(symbol, direction)`` group:

    * Pick the row with the highest ``confidence_score`` as the seed.
    * Boost its score by ``boost_pct_per_extra`` for every *additional*
      strategy that fired the same side (capped at ``cap``).
    * Replace ``strategy_id`` / ``setup_name`` with ``"composite"`` when
      ≥ 2 strategies contributed; otherwise leave the original alone.
    * Rewrite ``reason`` to ``"composite[N]: id1, id2, ..."``.

    Schema is preserved exactly. Rank is recomputed afterwards.
    """
    if df is None or df.is_empty():
        return df if df is not None else empty_signals()
    sort_cols = list(on)
    # Most-confident-first within each group, plus stable ordering of contributors.
    ranked = df.sort(["confidence_score", "strategy_id"],
                     descending=[True, False], nulls_last=True)
    groups = (ranked.group_by(sort_cols, maintain_order=True)
                    .agg([
                        pl.len().alias("_n"),
                        pl.col("strategy_id").alias("_ids"),
                    ]))
    seed = ranked.unique(subset=sort_cols, keep="first", maintain_order=True)
    merged = seed.join(groups, on=sort_cols, how="left")

    boost = (pl.col("_n").cast(pl.Float64) - 1.0).clip(lower_bound=0.0) \
            * boost_pct_per_extra
    new_conf = (pl.col("confidence_score").cast(pl.Float64, strict=False)
                + boost).clip(upper_bound=cap)

    is_composite = pl.col("_n") >= 2
    new_strategy = pl.when(is_composite).then(pl.lit("composite")) \
                     .otherwise(pl.col("strategy_id"))
    new_setup = pl.when(is_composite).then(pl.lit("composite")) \
                  .otherwise(pl.col("setup_name"))
    # reason: "composite[N]: a, b, c" when N>=2 else original
    ids_str = pl.col("_ids").list.unique().list.sort().list.join(", ")
    new_reason = pl.when(is_composite) \
        .then(pl.format("composite[{}]: {}", pl.col("_n"), ids_str)) \
        .otherwise(pl.col("reason"))

    out = merged.with_columns([
        new_conf.alias("confidence_score"),
        new_strategy.alias("strategy_id"),
        new_setup.alias("setup_name"),
        new_reason.alias("reason"),
    ]).drop(["_n", "_ids"])
    # Re-rank
    out = out.sort("confidence_score", descending=True, nulls_last=True)
    out = out.with_columns(
        pl.int_range(1, pl.len() + 1, dtype=pl.Int64).alias("signal_rank")
    )
    # Cast back to canonical schema column order
    return out.select(list(SIGNAL_SCHEMA.keys()))


def dedupe_signals(
    df: pl.DataFrame,
    *,
    on: tuple[str, ...] = ("symbol", "direction"),
) -> pl.DataFrame:
    """Drop duplicate signals across strategies, keeping the highest-confidence.

    A symbol that fires from two different strategies on the same side
    is reduced to one row whose ``confidence_score`` is the maximum.
    Long and short signals for the same symbol are kept distinct.
    Re-ranks ``signal_rank`` after deduplication.
    """
    if df is None or df.is_empty():
        return df if df is not None else empty_signals()
    try:
        out = (df.sort("confidence_score", descending=True, nulls_last=True)
                 .unique(subset=list(on), keep="first"))
        # Re-rank within the deduped frame
        out = out.sort("confidence_score", descending=True, nulls_last=True)
        out = out.with_columns(
            pl.int_range(1, pl.len() + 1, dtype=pl.Int64).alias("signal_rank")
        )
        return out
    except Exception as exc:  # noqa: BLE001
        log.warning("dedupe_signals failed: %s", exc)
        return df


# ---------- backtest engine adapter ----------------------------------------

def to_backtest_signals(
    df: pl.DataFrame,
    *,
    capital: float = 100_000.0,
    risk_pct: float = 1.0,
    target: str = "target_1",
) -> pl.DataFrame:
    """Map canonical signals to the column names ``run_backtest`` expects.

    The engine reads ``symbol``, ``as_of``, ``entry_price``, ``stop_loss``,
    ``qty``, ``risk_rs``, optional ``side`` / ``target`` / ``setup``.
    Sizing here is a fixed-fractional risk model: each row gets
    ``capital × risk_pct/100`` rupees of risk, then qty = floor(risk / |entry-stop|).
    """
    if df is None or df.is_empty():
        return pl.DataFrame()
    try:
        risk_rs = capital * (max(float(risk_pct), 0.0) / 100.0)
        diff = (pl.col("entry").cast(pl.Float64, strict=False)
                - pl.col("stop_loss").cast(pl.Float64, strict=False)).abs()
        qty = pl.when(diff > 0) \
                .then((pl.lit(risk_rs) / diff).cast(pl.Int64, strict=False)) \
                .otherwise(pl.lit(0, dtype=pl.Int64))
        return df.with_columns([
            pl.col("trade_date").alias("as_of"),
            pl.col("entry").cast(pl.Float64).alias("entry_price"),
            pl.col(target).cast(pl.Float64).alias("target"),
            pl.col("direction").alias("side"),
            pl.col("setup_name").alias("setup"),
            qty.alias("qty"),
            pl.lit(risk_rs, dtype=pl.Float64).alias("risk_rs"),
            (pl.col("entry").cast(pl.Float64) * qty.cast(pl.Float64))
                .alias("notional_rs"),
        ])
    except Exception as exc:  # noqa: BLE001
        log.warning("to_backtest_signals failed: %s", exc)
        return pl.DataFrame()


# ---------- enrichment from multi-day history -------------------------------

def enrich_from_history(
    universe: pl.DataFrame,
    history: pl.DataFrame | None,
    trade_date: date | str,
    *,
    lookback: int = 20,
) -> pl.DataFrame:
    """Add ``hi_20``, ``lo_20``, ``vol_avg_20``, ``high_252`` from history.

    No-op if ``history`` is missing or doesn't have the required OHLCV
    columns. Existing columns on ``universe`` win — we never overwrite
    a value the caller already attached.
    """
    if universe is None or universe.is_empty():
        return universe if universe is not None else pl.DataFrame()
    if history is None or history.is_empty():
        return universe
    needed = {"symbol", "trade_date", "high", "low", "close", "volume"}
    if not needed.issubset(history.columns):
        return universe
    td = to_date(trade_date)
    if td is None:
        return universe
    try:
        hist = (history
                .with_columns(pl.col("trade_date").cast(pl.Date, strict=False))
                .filter(pl.col("trade_date") < td)
                .sort(["symbol", "trade_date"]))
        if hist.is_empty():
            return universe
        stats = (hist.group_by("symbol")
                 .agg([
                     pl.col("high").tail(lookback).max().alias("hi_20"),
                     pl.col("low").tail(lookback).min().alias("lo_20"),
                     pl.col("volume").tail(lookback).mean().alias("vol_avg_20"),
                     pl.col("high").tail(252).max().alias("high_252"),
                 ]))
        new_cols = [c for c in ("hi_20", "lo_20", "vol_avg_20", "high_252")
                    if c not in universe.columns]
        if not new_cols:
            return universe
        keep = ["symbol"] + new_cols
        return universe.join(stats.select(keep), on="symbol", how="left")
    except Exception as exc:  # noqa: BLE001
        log.warning("enrich_from_history failed: %s", exc)
        return universe
