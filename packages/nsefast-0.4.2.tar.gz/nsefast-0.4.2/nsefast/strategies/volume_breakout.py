"""Volume-spike breakout — direction-aware (long if up, short if down).

A symbol fires when its day's traded volume is at least ``min_ratio`` times
its 20-day average AND the bar closes in a clear direction (vs prev_close
or open). This is the canonical "unusual volume" scan used by every
swing screener.
"""
from __future__ import annotations

from datetime import date

import polars as pl

from nsefast.logging_setup import get_logger
from nsefast.strategies._base import (
    compute_levels,
    empty_signals,
    enrich_from_history,
    finalize_signals,
    normalize_score_0_100,
    prefilter_universe,
)

log = get_logger(__name__)

STRATEGY_ID = "volume_breakout"
SETUP_NAME = "unusual_volume_breakout"
# Direction-aware: works in any tape.
ALLOWED_REGIMES = ("bullish", "sideways", "bearish")


def generate_signals(
    trade_date: str | date,
    universe: pl.DataFrame,
    context: dict | None = None,
    *,
    min_ratio: float = 2.5,
    min_move_pct: float = 1.0,
    stop_pct: float = 3.5,
    rr1: float = 1.5,
    rr2: float = 3.0,
) -> pl.DataFrame:
    """Generate volume-spike directional signals for ``trade_date``."""
    ctx = context or {}
    try:
        if universe is None or universe.is_empty():
            return empty_signals()
        df = prefilter_universe(universe, ctx)
        if df.is_empty() or not {"symbol", "close"}.issubset(df.columns):
            return empty_signals()

        df = enrich_from_history(df, ctx.get("history"), trade_date)

        # Volume ratio
        avg_col = ("vol_avg_20" if "vol_avg_20" in df.columns
                   else "avg_volume_20" if "avg_volume_20" in df.columns
                   else None)
        if "volume" not in df.columns or avg_col is None:
            return empty_signals()

        vol = pl.col("volume").cast(pl.Float64, strict=False)
        avg = pl.col(avg_col).cast(pl.Float64, strict=False)
        vol_ratio = vol / pl.when(avg > 0).then(avg).otherwise(None)

        # Direction & move size
        close = pl.col("close").cast(pl.Float64, strict=False)
        if "prev_close" in df.columns:
            ref = pl.col("prev_close").cast(pl.Float64, strict=False)
        elif "open" in df.columns:
            ref = pl.col("open").cast(pl.Float64, strict=False)
        else:
            return empty_signals()
        safe_ref = pl.when(ref > 0).then(ref).otherwise(None)
        move_pct = ((close / safe_ref - 1.0) * 100.0).fill_nan(None)

        df = df.with_columns([
            vol_ratio.fill_nan(None).alias("_vol_ratio"),
            move_pct.alias("_move_pct"),
        ])
        df = df.filter(
            (pl.col("_vol_ratio") >= min_ratio)
            & (pl.col("_move_pct").abs() >= min_move_pct)
        )
        if df.is_empty():
            return empty_signals()

        df = df.with_columns(
            pl.when(pl.col("_move_pct") > 0).then(pl.lit("long"))
              .otherwise(pl.lit("short"))
              .alias("direction")
        )

        # Stop is a fixed-percent buffer in the *opposite* direction
        entry = close
        long_stop = entry * (1.0 - stop_pct / 100.0)
        short_stop = entry * (1.0 + stop_pct / 100.0)
        stop = pl.when(pl.col("direction") == "long").then(long_stop).otherwise(short_stop)

        # Raw score blends volume surprise and move size
        raw = pl.col("_vol_ratio").fill_null(0.0) + pl.col("_move_pct").abs().fill_null(0.0)

        df = df.with_columns([
            entry.alias("entry"),
            stop.alias("stop_loss"),
            raw.alias("_raw_score"),
            pl.format(
                "vol={}× move={}%", pl.col("_vol_ratio").round(2),
                pl.col("_move_pct").round(2),
            ).alias("reason"),
        ])

        df = normalize_score_0_100(df, "_raw_score", out_col="confidence_score")
        df = compute_levels(df, rr1=rr1, rr2=rr2)
        return finalize_signals(
            df, trade_date=trade_date,
            strategy_id=STRATEGY_ID, setup_name=SETUP_NAME,
            sector_meta=ctx.get("sector_meta"),
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("volume_breakout.generate_signals failed: %s", exc)
        return empty_signals()
