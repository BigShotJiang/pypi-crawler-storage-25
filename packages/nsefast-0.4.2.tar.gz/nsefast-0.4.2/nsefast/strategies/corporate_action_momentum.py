"""Corporate-action momentum — ride the move after earnings/dividends/splits.

Looks at ``context["corporate_actions"]`` for symbols whose ex-date /
announcement date falls in the trailing ``lookback_days`` window ending
at ``trade_date``. From those, keeps the ones showing a clean up-bar on
``trade_date`` itself (close > prev_close × (1 + min_move_pct/100)) with
volume ≥ 20-day average × ``volume_ratio``.

Requires ``corporate_actions`` to have a ``symbol`` column and *some*
date column — we try ``ex_date``, ``ex_dt``, ``recorddate``,
``announcement_date`` in that order and fall back to no-date filtering
when none are present.
"""
from __future__ import annotations

from datetime import date, timedelta

import polars as pl

from nsefast.logging_setup import get_logger
from nsefast.strategies._base import (
    compute_levels,
    empty_signals,
    enrich_from_history,
    finalize_signals,
    normalize_score_0_100,
    prefilter_universe,
    to_date,
)

log = get_logger(__name__)

STRATEGY_ID = "corporate_action_momentum"
SETUP_NAME = "post_action_drift"
# Post-action drift is event-driven; allow in any non-bearish tape.
ALLOWED_REGIMES = ("bullish", "sideways")

_DATE_COL_CANDIDATES = (
    "ex_date", "ex_dt", "exdate", "recorddate", "record_date",
    "announcement_date", "announcedate", "date",
)


def generate_signals(
    trade_date: str | date,
    universe: pl.DataFrame,
    context: dict | None = None,
    *,
    lookback_days: int = 5,
    min_move_pct: float = 1.0,
    volume_ratio: float = 1.3,
    stop_pct: float = 4.0,
    rr1: float = 1.5,
    rr2: float = 3.0,
) -> pl.DataFrame:
    """Long-only post-corporate-action momentum signals for ``trade_date``."""
    ctx = context or {}
    try:
        ca = ctx.get("corporate_actions")
        if ca is None or ca.is_empty() or "symbol" not in ca.columns:
            return empty_signals()
        if universe is None or universe.is_empty():
            return empty_signals()

        df = prefilter_universe(universe, ctx)
        if df.is_empty() or not {"symbol", "close"}.issubset(df.columns):
            return empty_signals()

        td = to_date(trade_date)
        if td is None:
            return empty_signals()

        # Build the set of recently-actioned symbols
        wanted = _recent_action_symbols(ca, td, lookback_days)
        if not wanted:
            return empty_signals()

        df = df.filter(pl.col("symbol").cast(pl.Utf8).is_in(wanted))
        if df.is_empty():
            return empty_signals()

        df = enrich_from_history(df, ctx.get("history"), trade_date)

        # Move filter
        cl = pl.col("close").cast(pl.Float64, strict=False)
        if "prev_close" in df.columns:
            ref = pl.col("prev_close").cast(pl.Float64, strict=False)
        elif "open" in df.columns:
            ref = pl.col("open").cast(pl.Float64, strict=False)
        else:
            return empty_signals()
        safe_ref = pl.when(ref > 0).then(ref).otherwise(None)
        move = ((cl / safe_ref - 1.0) * 100.0).fill_nan(None)

        # Volume ratio (graceful when no avg present)
        avg_col = ("vol_avg_20" if "vol_avg_20" in df.columns
                   else "avg_volume_20" if "avg_volume_20" in df.columns
                   else None)
        if avg_col is not None and "volume" in df.columns:
            vr = (pl.col("volume").cast(pl.Float64, strict=False)
                  / pl.when(pl.col(avg_col).cast(pl.Float64) > 0)
                      .then(pl.col(avg_col).cast(pl.Float64))
                      .otherwise(None)).fill_nan(None)
        else:
            vr = pl.lit(1.0, dtype=pl.Float64)
        df = df.with_columns([move.alias("_move_pct"), vr.alias("_vol_ratio")])
        df = df.filter(
            (pl.col("_move_pct") >= min_move_pct)
            & (pl.col("_vol_ratio") >= volume_ratio)
        )
        if df.is_empty():
            return empty_signals()

        entry = cl
        stop = entry * (1.0 - stop_pct / 100.0)
        raw = pl.col("_move_pct").fill_null(0.0) + pl.col("_vol_ratio").fill_null(0.0)

        df = df.with_columns([
            entry.alias("entry"),
            stop.alias("stop_loss"),
            pl.lit("long", dtype=pl.Utf8).alias("direction"),
            raw.alias("_raw_score"),
            pl.format(
                "post-action move={}% vol={}×",
                pl.col("_move_pct").round(2),
                pl.col("_vol_ratio").round(2),
            ).alias("reason"),
        ])
        df = normalize_score_0_100(df, "_raw_score", out_col="confidence_score")
        df = compute_levels(df, rr1=rr1, rr2=rr2)
        return finalize_signals(
            df, trade_date=trade_date,
            strategy_id=STRATEGY_ID, setup_name=SETUP_NAME,
            sector_meta=ctx.get("sector_meta"),
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("corporate_action_momentum.generate_signals failed: %s", exc)
        return empty_signals()


def _recent_action_symbols(
    ca: pl.DataFrame, trade_date: date, lookback_days: int,
) -> list[str]:
    """Symbols whose ex-date / record-date is in [trade_date - N, trade_date]."""
    try:
        date_col = next((c for c in _DATE_COL_CANDIDATES if c in ca.columns), None)
        if date_col is None:
            # No usable date column — fall back to *all* symbols in the table.
            return (ca.select(pl.col("symbol").cast(pl.Utf8))
                      .drop_nulls().unique().to_series().to_list())

        start = trade_date - timedelta(days=lookback_days)
        # Cast date_col to Date when it's a string (NSE returns DD-MMM-YYYY etc.)
        col = pl.col(date_col)
        if ca[date_col].dtype == pl.Utf8:
            col = (col.str.strptime(pl.Date, format=None, strict=False))
        else:
            col = col.cast(pl.Date, strict=False)
        recent = (ca
                  .with_columns(col.alias("_dt"))
                  .filter(pl.col("_dt").is_not_null()
                          & (pl.col("_dt") >= start)
                          & (pl.col("_dt") <= trade_date)))
        return (recent.select(pl.col("symbol").cast(pl.Utf8))
                       .drop_nulls().unique().to_series().to_list())
    except Exception as exc:  # noqa: BLE001
        log.warning("_recent_action_symbols failed: %s", exc)
        return []
