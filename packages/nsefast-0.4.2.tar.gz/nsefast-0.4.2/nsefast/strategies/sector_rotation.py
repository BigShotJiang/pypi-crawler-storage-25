"""Sector-rotation strategy — long the strongest names in the strongest sectors.

Requires both ``context["sector_strength"]`` (e.g. output of
``indices.sector_strength``) and ``context["sector_meta"]`` (a symbol →
sector mapping; ``symbol_master`` from collectors works). When either is
missing the strategy returns an empty signal frame — there's no
sensible single-day fallback for *which sectors are leading*.
"""
from __future__ import annotations

from datetime import date

import polars as pl

from nsefast.logging_setup import get_logger
from nsefast.strategies._base import (
    compute_levels,
    empty_signals,
    finalize_signals,
    normalize_score_0_100,
    prefilter_universe,
)

log = get_logger(__name__)

STRATEGY_ID = "sector_rotation"
SETUP_NAME = "sector_leader_rotation"
# Rotation needs internal dispersion — bullish or sideways tape.
ALLOWED_REGIMES = ("bullish", "sideways")


def generate_signals(
    trade_date: str | date,
    universe: pl.DataFrame,
    context: dict | None = None,
    *,
    top_n_sectors: int = 3,
    min_sector_change_pct: float = 0.5,
    n_per_sector: int = 5,
    stop_pct: float = 4.0,
    rr1: float = 1.5,
    rr2: float = 3.0,
) -> pl.DataFrame:
    """Long signals on top symbols inside the top-``top_n_sectors`` sectors."""
    ctx = context or {}
    try:
        sector_strength = ctx.get("sector_strength")
        sector_meta = ctx.get("sector_meta")
        if sector_strength is None or sector_strength.is_empty():
            return empty_signals()
        if sector_meta is None or sector_meta.is_empty():
            return empty_signals()
        if universe is None or universe.is_empty():
            return empty_signals()
        if not {"index_name", "percent_change"}.issubset(sector_strength.columns):
            return empty_signals()
        if not {"symbol", "sector"}.issubset(sector_meta.columns):
            return empty_signals()

        df = prefilter_universe(universe, ctx)
        if df.is_empty() or not {"symbol", "close"}.issubset(df.columns):
            return empty_signals()

        # 1) Rank sectors by percent_change desc, keep top-N positives
        top = (sector_strength
               .with_columns(pl.col("percent_change").cast(pl.Float64, strict=False))
               .filter(pl.col("percent_change") >= min_sector_change_pct)
               .sort("percent_change", descending=True, nulls_last=True)
               .head(top_n_sectors))
        if top.is_empty():
            return empty_signals()

        positive_keywords = (top.select(
            pl.col("index_name").cast(pl.Utf8).str.to_uppercase()
        ).to_series().to_list())

        # 2) Tag universe symbols with their sector via sector_meta
        meta = sector_meta.select([
            pl.col("symbol").cast(pl.Utf8),
            pl.col("sector").cast(pl.Utf8).alias("sector"),
        ]).unique(subset=["symbol"])
        df = df.join(meta, on="symbol", how="left")
        df = df.filter(pl.col("sector").is_not_null())
        if df.is_empty():
            return empty_signals()

        def _in_top(sec: str | None) -> bool:
            if sec is None:
                return False
            s = sec.strip().upper()
            return any(s and (s in idx or idx in s) for idx in positive_keywords)

        df = df.with_columns(
            pl.col("sector").map_elements(_in_top, return_dtype=pl.Boolean)
              .alias("_in_top")
        ).filter(pl.col("_in_top")).drop("_in_top")
        if df.is_empty():
            return empty_signals()

        # 3) Within each kept sector, take top-n by percent_change
        if "percent_change" in df.columns:
            move = pl.col("percent_change").cast(pl.Float64, strict=False)
        elif "prev_close" in df.columns:
            ref = pl.col("prev_close").cast(pl.Float64, strict=False)
            safe_ref = pl.when(ref > 0).then(ref).otherwise(None)
            move = ((pl.col("close").cast(pl.Float64, strict=False) / safe_ref - 1.0)
                    * 100.0).fill_nan(None)
        else:
            return empty_signals()

        df = df.with_columns(move.alias("_move_pct"))
        df = df.filter(pl.col("_move_pct") > 0)
        if df.is_empty():
            return empty_signals()
        df = (df.sort(["sector", "_move_pct"], descending=[False, True],
                      nulls_last=True)
                .with_columns(
                    pl.int_range(1, pl.len() + 1).over("sector")
                      .alias("_sector_rank")
                )
                .filter(pl.col("_sector_rank") <= n_per_sector)
                .drop("_sector_rank"))
        if df.is_empty():
            return empty_signals()

        # 4) Levels & score
        entry = pl.col("close").cast(pl.Float64, strict=False)
        stop = entry * (1.0 - stop_pct / 100.0)
        raw = pl.col("_move_pct").fill_null(0.0)

        df = df.with_columns([
            entry.alias("entry"),
            stop.alias("stop_loss"),
            pl.lit("long", dtype=pl.Utf8).alias("direction"),
            raw.alias("_raw_score"),
            pl.format(
                "top sector ({}) move={}%", pl.col("sector"),
                pl.col("_move_pct").round(2),
            ).alias("reason"),
        ])
        df = normalize_score_0_100(df, "_raw_score", out_col="confidence_score")
        df = compute_levels(df, rr1=rr1, rr2=rr2)
        return finalize_signals(
            df, trade_date=trade_date,
            strategy_id=STRATEGY_ID, setup_name=SETUP_NAME,
            sector_meta=sector_meta,
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("sector_rotation.generate_signals failed: %s", exc)
        return empty_signals()
