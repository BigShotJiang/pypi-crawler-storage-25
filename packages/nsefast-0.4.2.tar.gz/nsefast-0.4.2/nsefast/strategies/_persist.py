"""Persist strategy signals to ``strategy_signals/trade_date=YYYY-MM-DD/``.

Idempotent: re-running the same date for the same strategy/symbol/direction
overwrites prior rows (PK-merge). The dataset is hive-partitioned by
``trade_date`` so a simple Spark/DuckDB scan can pull a single day's
signals fast.
"""
from __future__ import annotations

from pathlib import Path

import polars as pl

from nsefast.config import PARQUET_DIR
from nsefast.logging_setup import get_logger
from nsefast.storage.parquet_store import upsert_partition

log = get_logger(__name__)


SIGNALS_DATASET = "strategy_signals"
SIGNAL_PK = ["strategy_id", "symbol", "direction"]


def save_signals(df: pl.DataFrame, *, dataset: str = SIGNALS_DATASET) -> str:
    """Upsert canonical signals into ``data/parquet/<dataset>/trade_date=*/``.

    Empty input is a no-op (returns the dataset path). Re-running the
    same trade_date for the same (strategy_id, symbol, direction)
    triplet overwrites the prior row — the latest scan wins.
    """
    if df is None or df.is_empty():
        return str(Path(PARQUET_DIR) / dataset)
    try:
        # Hive partition value must be a string ("trade_date=2026-05-07/").
        # pyarrow can serialize Date directly, but going through Utf8 makes
        # the on-disk layout deterministic regardless of pyarrow version.
        out = df.with_columns(
            pl.col("trade_date").cast(pl.Utf8).alias("trade_date")
        )
        return upsert_partition(
            out, dataset=dataset, by=["trade_date"], primary_key=SIGNAL_PK,
            keep="last",
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("save_signals failed: %s", exc)
        return str(Path(PARQUET_DIR) / dataset)
