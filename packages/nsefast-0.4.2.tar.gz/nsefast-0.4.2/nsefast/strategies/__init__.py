"""Production swing-trading strategy layer.

Each strategy module exposes::

    generate_signals(trade_date: str | date,
                     universe: pl.DataFrame,
                     context: dict | None = None) -> pl.DataFrame

Returning a DataFrame matching :data:`SIGNAL_SCHEMA` exactly. The
canonical signal contract:

* ``trade_date, strategy_id, setup_name, symbol, direction, entry,
  stop_loss, target_1, target_2, confidence_score (0-100),
  risk_reward, sector, reason, signal_rank``

Use :func:`run_strategy` to dispatch by name (hyphenated CLI form
accepted), :func:`run_all` to fan out across every registered strategy
and dedupe across them, and ``REGISTRY`` to introspect the available
list. Outputs are crash-proof — every strategy returns the canonical
empty frame on failure.
"""
from __future__ import annotations

from datetime import date
from typing import Callable

import polars as pl

from nsefast.logging_setup import get_logger
from nsefast.strategies import (
    corporate_action_momentum,
    delivery_breakout,
    gap_breakout,
    momentum_52w,
    sector_rotation,
    volume_breakout,
)
from nsefast.strategies._base import (
    SIGNAL_SCHEMA,
    compute_levels,
    dedupe_signals,
    empty_signals,
    enrich_from_history,
    finalize_signals,
    merge_overlapping_signals,
    normalize_score_0_100,
    prefilter_universe,
    to_backtest_signals,
    to_date,
)
from nsefast.strategies._persist import save_signals

log = get_logger(__name__)


GenerateFn = Callable[..., pl.DataFrame]

REGISTRY: dict[str, GenerateFn] = {
    delivery_breakout.STRATEGY_ID:           delivery_breakout.generate_signals,
    volume_breakout.STRATEGY_ID:             volume_breakout.generate_signals,
    sector_rotation.STRATEGY_ID:             sector_rotation.generate_signals,
    momentum_52w.STRATEGY_ID:                momentum_52w.generate_signals,
    gap_breakout.STRATEGY_ID:                gap_breakout.generate_signals,
    corporate_action_momentum.STRATEGY_ID:   corporate_action_momentum.generate_signals,
}


def _normalize_name(name: str) -> str:
    """Accept ``delivery-breakout`` / ``delivery_breakout`` / ``DeliveryBreakout``."""
    return str(name).strip().lower().replace("-", "_")


def list_strategies() -> list[str]:
    """Names of every registered strategy, in registration order."""
    return list(REGISTRY.keys())


def run_strategy(
    name: str,
    trade_date: str | date,
    universe: pl.DataFrame,
    context: dict | None = None,
    **overrides,
) -> pl.DataFrame:
    """Dispatch to a single strategy by name. Returns canonical signals."""
    key = _normalize_name(name)
    fn = REGISTRY.get(key)
    if fn is None:
        log.warning("run_strategy: unknown name %r", name)
        return empty_signals()
    try:
        return fn(trade_date, universe, context, **overrides)
    except Exception as exc:  # noqa: BLE001
        log.warning("run_strategy(%s) failed: %s", key, exc)
        return empty_signals()


def _strategy_module(key: str):
    return {
        "delivery_breakout": delivery_breakout,
        "volume_breakout": volume_breakout,
        "sector_rotation": sector_rotation,
        "momentum_52w": momentum_52w,
        "gap_breakout": gap_breakout,
        "corporate_action_momentum": corporate_action_momentum,
    }.get(key)


def allowed_regimes(name: str) -> tuple[str, ...]:
    """The ``ALLOWED_REGIMES`` declared by strategy ``name`` (or empty)."""
    mod = _strategy_module(_normalize_name(name))
    return tuple(getattr(mod, "ALLOWED_REGIMES", ()) or ())


def run_all(
    trade_date: str | date,
    universe: pl.DataFrame,
    context: dict | None = None,
    *,
    dedupe: bool = True,
    merge_overlap: bool = False,
    regime: object | None = None,
) -> pl.DataFrame:
    """Run every registered strategy and concatenate the results.

    * When ``regime`` is provided, strategies whose ``ALLOWED_REGIMES``
      doesn't include the regime's market label are skipped. Pass a
      :class:`~nsefast.regime.Regime` or any object with a ``market``
      attribute / dict with ``"market"`` key.
    * When ``merge_overlap=True`` overlapping signals across strategies
      are collapsed into a single composite row whose confidence is
      boosted by every additional contributing strategy. (This is a
      richer dedup — turn ``dedupe`` off when using it.)
    * When ``dedupe=True`` (default) the same ``(symbol, direction)``
      pair is reduced to the single highest-confidence row.
    """
    market_label = None
    if regime is not None:
        if hasattr(regime, "market"):
            market_label = getattr(regime, "market", None)
        elif isinstance(regime, dict):
            market_label = regime.get("market")
        elif isinstance(regime, str):
            market_label = regime

    parts: list[pl.DataFrame] = []
    for key, fn in REGISTRY.items():
        if market_label and market_label != "unknown":
            allowed = allowed_regimes(key)
            if allowed and market_label not in allowed:
                log.debug("run_all: skipping %s (regime=%s not in %s)",
                          key, market_label, allowed)
                continue
        try:
            sig = fn(trade_date, universe, context)
            if sig is not None and not sig.is_empty():
                parts.append(sig)
        except Exception as exc:  # noqa: BLE001
            log.warning("run_all(%s) failed: %s", key, exc)
    if not parts:
        return empty_signals()
    out = pl.concat(parts, how="vertical_relaxed")
    if merge_overlap:
        return merge_overlapping_signals(out)
    return dedupe_signals(out) if dedupe else out


__all__ = [
    "SIGNAL_SCHEMA",
    "REGISTRY",
    "allowed_regimes",
    "list_strategies",
    "run_strategy",
    "run_all",
    "save_signals",
    "empty_signals",
    "dedupe_signals",
    "merge_overlapping_signals",
    "finalize_signals",
    "normalize_score_0_100",
    "compute_levels",
    "prefilter_universe",
    "enrich_from_history",
    "to_backtest_signals",
    "to_date",
]
