"""Delivery-confirmed breakout — the priority production strategy.

Setup
-----
A long-only EOD signal that fires when **all** of the following are true:

1. **Price breakout** — ``close > prior 20-bar high`` (uses ``hi_20`` from
   ``enrich_from_history`` when present; falls back to ``close > prev_close
   * (1 + price_gain_pct/100)`` otherwise).
2. **Volume breakout** — ``volume / vol_avg_20 >= volume_ratio``.
3. **Delivery > threshold** — ``delivery_pct >= min_delivery_pct``
   (sticky-money confirmation; the move was bought, not just churned).
4. **Sector strength positive** — sector index up on the day, when
   ``context["sector_strength"]`` and ``context["sector_meta"]`` are
   supplied. Skipped (treated as positive) when either is missing.
5. **Not under surveillance** — ASM / GSM / T2T / F&O ban excluded via
   :func:`prefilter_universe`.

Risk model
----------
Stop = ``min(prior 20-bar low, entry × (1 - stop_buffer_pct/100))``.
Targets at 1.5 R and 3.0 R via :func:`compute_levels`. Confidence is the
percentile rank of a composite raw score combining the volume ratio,
delivery %, and breakout strength (close / hi_20 - 1).
"""
from __future__ import annotations

from datetime import date

import polars as pl

from nsefast.logging_setup import get_logger
from nsefast.strategies._base import (
    compute_levels,
    empty_signals,
    enrich_from_history,
    finalize_signals,
    normalize_score_0_100,
    prefilter_universe,
)

log = get_logger(__name__)

STRATEGY_ID = "delivery_breakout"
SETUP_NAME = "delivery_confirmed_breakout"
# Long-only delivery confirmation only fires meaningfully in trending tapes.
ALLOWED_REGIMES = ("bullish", "sideways")


def generate_signals(
    trade_date: str | date,
    universe: pl.DataFrame,
    context: dict | None = None,
    *,
    min_delivery_pct: float = 55.0,
    volume_ratio: float = 1.8,
    price_gain_pct: float = 1.5,
    stop_buffer_pct: float = 4.0,
    rr1: float = 1.5,
    rr2: float = 3.0,
) -> pl.DataFrame:
    """Generate delivery-confirmed breakout signals for ``trade_date``."""
    ctx = context or {}
    try:
        if universe is None or universe.is_empty():
            return empty_signals()

        df = prefilter_universe(universe, ctx)
        if df.is_empty() or "symbol" not in df.columns or "close" not in df.columns:
            return empty_signals()

        # Enrich with rolling stats from history if available
        df = enrich_from_history(df, ctx.get("history"), trade_date)

        # ---- price breakout flag ------------------------------------------
        close = pl.col("close").cast(pl.Float64, strict=False)
        if "hi_20" in df.columns:
            price_brk = close > pl.col("hi_20").cast(pl.Float64, strict=False)
            brk_strength = (close / pl.col("hi_20") - 1.0).fill_nan(None) * 100.0
        elif "prev_close" in df.columns:
            prev = pl.col("prev_close").cast(pl.Float64, strict=False)
            safe_prev = pl.when(prev > 0).then(prev).otherwise(None)
            price_brk = close > safe_prev * (1.0 + price_gain_pct / 100.0)
            brk_strength = ((close / safe_prev - 1.0) * 100.0).fill_nan(None)
        else:
            return empty_signals()

        # ---- volume ratio --------------------------------------------------
        if {"volume", "vol_avg_20"}.issubset(df.columns):
            vol_ratio = (pl.col("volume").cast(pl.Float64, strict=False)
                         / pl.when(pl.col("vol_avg_20").cast(pl.Float64) > 0)
                             .then(pl.col("vol_avg_20").cast(pl.Float64))
                             .otherwise(None))
        elif {"volume", "avg_volume_20"}.issubset(df.columns):
            vol_ratio = (pl.col("volume").cast(pl.Float64, strict=False)
                         / pl.when(pl.col("avg_volume_20").cast(pl.Float64) > 0)
                             .then(pl.col("avg_volume_20").cast(pl.Float64))
                             .otherwise(None))
        else:
            # No avg-volume reference — gracefully degrade to a single-day
            # volume cross-section (vol vs median(vol) on the day).
            vol_ratio = (pl.col("volume").cast(pl.Float64, strict=False)
                         / pl.when(pl.col("volume").median() > 0)
                             .then(pl.col("volume").median())
                             .otherwise(None))

        df = df.with_columns([
            price_brk.alias("_price_brk"),
            vol_ratio.fill_nan(None).alias("_vol_ratio"),
            brk_strength.alias("_brk_strength"),
        ])

        # ---- delivery filter ----------------------------------------------
        if "delivery_pct" not in df.columns:
            log.debug("delivery_breakout: no delivery_pct column in universe")
            return empty_signals()

        df = df.filter(
            pl.col("_price_brk")
            & (pl.col("_vol_ratio") >= volume_ratio)
            & (pl.col("delivery_pct").cast(pl.Float64, strict=False)
               >= min_delivery_pct)
        )
        if df.is_empty():
            return empty_signals()

        # ---- sector strength gate -----------------------------------------
        sector_meta = ctx.get("sector_meta")
        sector_strength = ctx.get("sector_strength")
        df = _apply_sector_strength(df, sector_meta, sector_strength)
        if df.is_empty():
            return empty_signals()

        # ---- entry / stop / score -----------------------------------------
        entry = close
        pct_stop = entry * (1.0 - stop_buffer_pct / 100.0)
        if "lo_20" in df.columns:
            lo20_safe = pl.col("lo_20").cast(pl.Float64, strict=False) \
                          .fill_nan(None)
            # min_horizontal of (NaN, finite) returns NaN — coalesce first so
            # a missing 20-bar low silently falls back to the fixed % stop.
            stop = pl.min_horizontal(pl.coalesce(lo20_safe, pct_stop), pct_stop)
        else:
            stop = pct_stop

        # Composite raw score = vol_ratio + delivery_pct/10 + brk_strength.
        # Each component is on a similar order; percentile-rank flattens
        # any remaining unit mismatch.
        raw = (pl.col("_vol_ratio").fill_null(0.0)
               + pl.col("delivery_pct").cast(pl.Float64, strict=False).fill_null(0.0) / 10.0
               + pl.col("_brk_strength").fill_null(0.0))

        df = df.with_columns([
            entry.alias("entry"),
            stop.alias("stop_loss"),
            pl.lit("long", dtype=pl.Utf8).alias("direction"),
            raw.alias("_raw_score"),
            pl.lit(
                f"price_brk + vol≥{volume_ratio:.1f}× + deliv≥{min_delivery_pct:.0f}% "
                "+ sector positive",
                dtype=pl.Utf8,
            ).alias("reason"),
        ])

        df = normalize_score_0_100(df, "_raw_score", out_col="confidence_score")
        df = compute_levels(df, rr1=rr1, rr2=rr2)
        return finalize_signals(
            df, trade_date=trade_date,
            strategy_id=STRATEGY_ID, setup_name=SETUP_NAME,
            sector_meta=sector_meta,
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("delivery_breakout.generate_signals failed: %s", exc)
        return empty_signals()


def _apply_sector_strength(
    df: pl.DataFrame,
    sector_meta: pl.DataFrame | None,
    sector_strength: pl.DataFrame | None,
) -> pl.DataFrame:
    """Keep only symbols whose sector index is *up* on the day.

    No-op when either DataFrame is missing or doesn't carry the expected
    columns — the strategy stays usable on minimal context. Matching is
    case-insensitive substring (sector_meta.sector ⊆ index_name) so that
    'BANK' matches 'NIFTY BANK', 'IT' matches 'NIFTY IT', etc.
    """
    if sector_meta is None or sector_meta.is_empty():
        return df
    if sector_strength is None or sector_strength.is_empty():
        return df
    if not {"symbol", "sector"}.issubset(sector_meta.columns):
        return df
    idx_col = "index_name" if "index_name" in sector_strength.columns else None
    chg_col = "percent_change" if "percent_change" in sector_strength.columns else None
    if idx_col is None or chg_col is None:
        return df
    try:
        # Build positive-sector keyword set
        positive = (sector_strength
                    .filter(pl.col(chg_col).cast(pl.Float64, strict=False) > 0)
                    .select(pl.col(idx_col).cast(pl.Utf8).str.to_uppercase())
                    .unique()
                    .to_series().to_list())
        if not positive:
            return df.head(0)

        # Attach sector to df
        meta = sector_meta.select([
            pl.col("symbol").cast(pl.Utf8),
            pl.col("sector").cast(pl.Utf8).str.to_uppercase().alias("_sector_up"),
        ]).unique(subset=["symbol"])
        joined = df.join(meta, on="symbol", how="left")

        # Keep rows whose sector keyword appears in any positive index name.
        # This is a list-of-substrings filter; build it in Python since
        # sector_meta is small (≤ a few dozen sectors).
        def _matches(sec: str | None) -> bool:
            if sec is None:
                return False
            s = sec.strip().upper()
            return any(s and (s in idx or idx in s) for idx in positive)

        symbol_sector = (joined.select(["symbol", "_sector_up"]).unique())
        # First pass: how many of our universe symbols have *any* known
        # sector at all? (i.e. sector_meta covers them with a non-null value).
        covered = symbol_sector.filter(pl.col("_sector_up").is_not_null())
        if covered.is_empty():
            # sector_meta covers none of the candidates — gate is unusable.
            # Pass through rather than silently zero out the strategy.
            log.warning(
                "delivery_breakout: sector_meta covers 0/%d candidate "
                "symbols; skipping sector-strength gate",
                symbol_sector.height,
            )
            return joined.drop("_sector_up")

        keep_syms = (covered
                     .filter(pl.col("_sector_up").map_elements(
                         _matches, return_dtype=pl.Boolean))
                     ["symbol"].to_list())
        if not keep_syms:
            # Coverage exists but no covered symbol's sector matches a
            # positive index — this is a real "no aligned sector" outcome,
            # so dropping all rows is the correct behaviour. Still log it
            # so an operator can investigate textual mismatches quickly.
            log.info(
                "delivery_breakout: no candidate sector intersects positive "
                "indices (%d positives, %d covered candidates) — dropping all",
                len(positive), covered.height,
            )
            return df.head(0)
        return joined.filter(pl.col("symbol").is_in(keep_syms)).drop("_sector_up")
    except Exception as exc:  # noqa: BLE001
        log.warning("_apply_sector_strength failed: %s", exc)
        return df
