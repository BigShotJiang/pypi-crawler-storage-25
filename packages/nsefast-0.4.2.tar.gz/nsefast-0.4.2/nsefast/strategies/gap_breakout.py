"""Gap breakout — directional gap that holds through the close.

Long if the bar gaps up by ≥ ``min_gap_pct`` *and* closes ≥ open
(the gap was bought, not faded). Short on the symmetric setup.

This is the cleanest EOD-only strategy: it needs nothing more than
``open``, ``close``, and ``prev_close`` from the bhavcopy.
"""
from __future__ import annotations

from datetime import date

import polars as pl

from nsefast.logging_setup import get_logger
from nsefast.strategies._base import (
    compute_levels,
    empty_signals,
    enrich_from_history,
    finalize_signals,
    normalize_score_0_100,
    prefilter_universe,
)

log = get_logger(__name__)

STRATEGY_ID = "gap_breakout"
SETUP_NAME = "directional_gap_holds"
# Gap-and-go fires in any tape; direction handles bias.
ALLOWED_REGIMES = ("bullish", "sideways", "bearish")


def generate_signals(
    trade_date: str | date,
    universe: pl.DataFrame,
    context: dict | None = None,
    *,
    min_gap_pct: float = 2.0,
    min_volume_ratio: float = 1.0,
    stop_pct: float = 3.0,
    rr1: float = 1.5,
    rr2: float = 3.0,
) -> pl.DataFrame:
    """Generate gap-and-hold directional signals for ``trade_date``."""
    ctx = context or {}
    try:
        if universe is None or universe.is_empty():
            return empty_signals()
        df = prefilter_universe(universe, ctx)
        needed = {"symbol", "open", "close", "prev_close"}
        if df.is_empty() or not needed.issubset(df.columns):
            return empty_signals()

        df = enrich_from_history(df, ctx.get("history"), trade_date)

        op = pl.col("open").cast(pl.Float64, strict=False)
        cl = pl.col("close").cast(pl.Float64, strict=False)
        pc = pl.col("prev_close").cast(pl.Float64, strict=False)
        safe_pc = pl.when(pc > 0).then(pc).otherwise(None)
        gap_pct = ((op / safe_pc - 1.0) * 100.0).fill_nan(None)

        df = df.with_columns(gap_pct.alias("_gap_pct"))

        # Direction: gap-up + close ≥ open ⇒ long; gap-down + close ≤ open ⇒ short
        long_mask = (pl.col("_gap_pct") >= min_gap_pct) & (cl >= op)
        short_mask = (pl.col("_gap_pct") <= -min_gap_pct) & (cl <= op)
        df = df.with_columns(
            pl.when(long_mask).then(pl.lit("long"))
              .when(short_mask).then(pl.lit("short"))
              .otherwise(pl.lit(None, dtype=pl.Utf8))
              .alias("direction")
        ).filter(pl.col("direction").is_not_null())
        if df.is_empty():
            return empty_signals()

        # Optional volume confirmation
        avg_col = ("vol_avg_20" if "vol_avg_20" in df.columns
                   else "avg_volume_20" if "avg_volume_20" in df.columns
                   else None)
        if avg_col is not None and "volume" in df.columns:
            vr = (pl.col("volume").cast(pl.Float64, strict=False)
                  / pl.when(pl.col(avg_col).cast(pl.Float64) > 0)
                      .then(pl.col(avg_col).cast(pl.Float64))
                      .otherwise(None))
            df = df.with_columns(vr.fill_nan(None).alias("_vol_ratio"))
            df = df.filter(pl.col("_vol_ratio") >= min_volume_ratio)
        else:
            df = df.with_columns(pl.lit(None, dtype=pl.Float64).alias("_vol_ratio"))
        if df.is_empty():
            return empty_signals()

        entry = cl
        long_stop = entry * (1.0 - stop_pct / 100.0)
        short_stop = entry * (1.0 + stop_pct / 100.0)
        stop = pl.when(pl.col("direction") == "long").then(long_stop).otherwise(short_stop)

        raw = pl.col("_gap_pct").abs().fill_null(0.0) \
              + pl.col("_vol_ratio").fill_null(0.0)

        df = df.with_columns([
            entry.alias("entry"),
            stop.alias("stop_loss"),
            raw.alias("_raw_score"),
            pl.format("gap={}%", pl.col("_gap_pct").round(2)).alias("reason"),
        ])
        df = normalize_score_0_100(df, "_raw_score", out_col="confidence_score")
        df = compute_levels(df, rr1=rr1, rr2=rr2)
        return finalize_signals(
            df, trade_date=trade_date,
            strategy_id=STRATEGY_ID, setup_name=SETUP_NAME,
            sector_meta=ctx.get("sector_meta"),
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("gap_breakout.generate_signals failed: %s", exc)
        return empty_signals()
