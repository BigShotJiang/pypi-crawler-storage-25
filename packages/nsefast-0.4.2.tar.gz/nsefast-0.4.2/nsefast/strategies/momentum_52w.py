"""52-week-high momentum — buy the strongest names making new highs.

Requires multi-day history in ``context["history"]`` to compute a real
52-week (252-bar) rolling high. Without history this returns an empty
signal frame — there's no honest single-day proxy for "near 52w high".

A symbol qualifies on ``trade_date`` when:
  * close ≥ 0.97 × 252-bar rolling high, AND
  * volume / 20-bar avg ≥ ``volume_ratio``, AND
  * close > prev_close (up day on the breakout).
"""
from __future__ import annotations

from datetime import date

import polars as pl

from nsefast.logging_setup import get_logger
from nsefast.strategies._base import (
    compute_levels,
    empty_signals,
    enrich_from_history,
    finalize_signals,
    normalize_score_0_100,
    prefilter_universe,
)

log = get_logger(__name__)

STRATEGY_ID = "momentum_52w"
SETUP_NAME = "near_52w_high_momentum"
# 52w highs only make sense in a confirmed uptrend.
ALLOWED_REGIMES = ("bullish",)


def generate_signals(
    trade_date: str | date,
    universe: pl.DataFrame,
    context: dict | None = None,
    *,
    within_pct: float = 3.0,
    volume_ratio: float = 1.3,
    stop_pct: float = 5.0,
    rr1: float = 1.5,
    rr2: float = 3.0,
) -> pl.DataFrame:
    """Generate near-52w-high momentum signals for ``trade_date``."""
    ctx = context or {}
    try:
        history = ctx.get("history")
        if history is None or history.is_empty():
            return empty_signals()
        if universe is None or universe.is_empty():
            return empty_signals()

        df = prefilter_universe(universe, ctx)
        if df.is_empty() or not {"symbol", "close"}.issubset(df.columns):
            return empty_signals()

        df = enrich_from_history(df, history, trade_date)
        if "high_252" not in df.columns:
            return empty_signals()

        close = pl.col("close").cast(pl.Float64, strict=False)
        hi = pl.col("high_252").cast(pl.Float64, strict=False)
        within = pl.when(hi > 0).then(close / hi).otherwise(None)

        # Volume confirmation
        avg_col = ("vol_avg_20" if "vol_avg_20" in df.columns
                   else "avg_volume_20" if "avg_volume_20" in df.columns
                   else None)
        if "volume" not in df.columns or avg_col is None:
            return empty_signals()
        vol_ratio = (pl.col("volume").cast(pl.Float64, strict=False)
                     / pl.when(pl.col(avg_col).cast(pl.Float64) > 0)
                         .then(pl.col(avg_col).cast(pl.Float64))
                         .otherwise(None))

        # Up-day filter
        if "prev_close" in df.columns:
            ref = pl.col("prev_close").cast(pl.Float64, strict=False)
        else:
            ref = pl.col("open").cast(pl.Float64, strict=False)
        up_day = close > ref

        df = df.with_columns([
            within.alias("_within_ratio"),
            vol_ratio.fill_nan(None).alias("_vol_ratio"),
            up_day.alias("_up_day"),
        ])
        df = df.filter(
            pl.col("_within_ratio").is_not_null()
            & (pl.col("_within_ratio") >= (1.0 - within_pct / 100.0))
            & (pl.col("_vol_ratio") >= volume_ratio)
            & pl.col("_up_day")
        )
        if df.is_empty():
            return empty_signals()

        entry = close
        # Stop = max(entry × (1 - stop_pct/100), 20-bar low) — give the
        # breakout some room but don't sit beneath the recent base.
        # NaN-safe stop: coalesce lo_20 to the fixed-percent fallback before
        # max_horizontal so a missing/NaN lo_20 cannot leak NaN into stop_loss.
        pct_stop = entry * (1.0 - stop_pct / 100.0)
        if "lo_20" in df.columns:
            lo20_safe = pl.col("lo_20").cast(pl.Float64, strict=False) \
                          .fill_nan(None)
            stop = pl.max_horizontal(pl.coalesce(lo20_safe, pct_stop), pct_stop)
        else:
            stop = pct_stop

        # Score: closer to high + higher vol ratio is better
        raw = pl.col("_within_ratio").fill_null(0.0) * 100.0 \
              + pl.col("_vol_ratio").fill_null(0.0)

        df = df.with_columns([
            entry.alias("entry"),
            stop.alias("stop_loss"),
            pl.lit("long", dtype=pl.Utf8).alias("direction"),
            raw.alias("_raw_score"),
            pl.format(
                "{}% of 52w high, vol={}×",
                (pl.col("_within_ratio") * 100.0).round(1),
                pl.col("_vol_ratio").round(2),
            ).alias("reason"),
        ])
        df = normalize_score_0_100(df, "_raw_score", out_col="confidence_score")
        df = compute_levels(df, rr1=rr1, rr2=rr2)
        return finalize_signals(
            df, trade_date=trade_date,
            strategy_id=STRATEGY_ID, setup_name=SETUP_NAME,
            sector_meta=ctx.get("sector_meta"),
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("momentum_52w.generate_signals failed: %s", exc)
        return empty_signals()
