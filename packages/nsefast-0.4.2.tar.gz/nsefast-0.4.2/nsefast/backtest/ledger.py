"""Trade ledger persistence — the parquet-backed source of truth.

Two write modes:

- ``mode="append"`` (default): every call writes a new part file via
  :func:`nsefast.storage.parquet_store.append_partition`. Cheapest for
  one-shot runs; reads transparently union all part files.
- ``mode="upsert"``: idempotent merge on
  ``(strategy_id, symbol, entry_date, setup_name, leg)`` — re-running
  the same backtest over the same date range produces the same ledger
  rather than duplicates.

Reads via :func:`read_trades` go through the partitioned reader and
return a Polars DataFrame matching :data:`TRADE_SCHEMA`.

Crash-proof: write failures are logged and return ``False``;
read failures return an empty trades frame.
"""

from __future__ import annotations

import polars as pl

from nsefast.backtest._schema import TRADE_PK, empty_trades
from nsefast.logging_setup import get_logger
from nsefast.storage.parquet_store import (
    append_partition,
    read_parquet_partitioned,
    upsert_partition,
)

log = get_logger(__name__)

LEDGER_DATASET = "backtest_trades"


def save_trades(
    trades: pl.DataFrame,
    *,
    mode: str = "append",
    dataset: str = LEDGER_DATASET,
) -> bool:
    """Persist `trades` to the parquet ledger. Returns True on success."""
    if trades is None or trades.is_empty():
        log.debug("save_trades: empty df, skipping")
        return False
    try:
        # Ensure year/month partition cols exist.
        if "year" not in trades.columns or "month" not in trades.columns:
            trades = trades.with_columns([
                pl.col("entry_date").dt.year().cast(pl.Int32).alias("year"),
                pl.col("entry_date").dt.month().cast(pl.Int32).alias("month"),
            ])
        if mode == "append":
            append_partition(trades, dataset, by=["year", "month"])
        elif mode == "upsert":
            upsert_partition(
                trades, dataset,
                by=["year", "month"],
                primary_key=TRADE_PK,
                keep="last",
            )
        else:
            raise ValueError(f"unknown save mode {mode!r} (use 'append'|'upsert')")
        return True
    except Exception as exc:  # noqa: BLE001
        log.warning("save_trades failed", extra={"err": str(exc), "mode": mode})
        return False


def read_trades(
    *,
    strategy_id: str | None = None,
    dataset: str = LEDGER_DATASET,
) -> pl.DataFrame:
    """Read the trade ledger, optionally filtered by ``strategy_id``."""
    try:
        df = read_parquet_partitioned(dataset)
        if df.is_empty():
            return empty_trades()
        if strategy_id is not None:
            df = df.filter(pl.col("strategy_id") == strategy_id)
        # Defensively re-cast hive-partition columns to the canonical
        # schema dtypes — partition cols can come back as Int64 or even
        # Utf8 from older partitions, which causes schema drift across
        # re-runs. Best-effort: skip silently if a col is missing.
        from nsefast.backtest._schema import TRADE_SCHEMA
        casts = []
        for col in ("year", "month"):
            if col in df.columns:
                casts.append(pl.col(col).cast(TRADE_SCHEMA[col],
                                              strict=False).alias(col))
        if casts:
            df = df.with_columns(casts)
        return df
    except Exception as exc:  # noqa: BLE001
        log.warning("read_trades failed", extra={"err": str(exc)})
        return empty_trades()
