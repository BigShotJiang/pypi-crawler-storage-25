"""Walk-forward (rolling out-of-sample) backtest harness.

Splits the calendar into a sequence of (train, validate) windows and
calls a user-supplied ``signal_fn`` once per validation date. Trades
that the signal_fn produces during validation are passed through the
existing :func:`nsefast.backtest.engine.run_backtest` to score
out-of-sample performance.

Returns a frame with one row per window:

* ``window_id, train_start, train_end, val_start, val_end, n_signals,
  n_trades, win_rate_pct, profit_factor, expectancy_rs, equity_pnl_rs``

The harness is deliberately schema-light — it does not persist
individual trades. Use :func:`nsefast.backtest.engine.run_backtest`
directly if you need full trade-level output.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta
from typing import Callable, Iterable

import polars as pl

from nsefast.backtest.engine import BacktestConfig, run_backtest
from nsefast.logging_setup import get_logger
from nsefast.strategies._base import to_backtest_signals, to_date

log = get_logger(__name__)


@dataclass(frozen=True)
class WalkForwardConfig:
    train_days: int = 60
    validate_days: int = 20
    step_days: int = 20
    min_train_bars: int = 30


SignalFn = Callable[[date, pl.DataFrame], pl.DataFrame]


_RESULT_SCHEMA = {
    "window_id":        pl.Int64,
    "train_start":      pl.Date,
    "train_end":        pl.Date,
    "val_start":        pl.Date,
    "val_end":          pl.Date,
    "n_signals":        pl.Int64,
    "n_trades":         pl.Int64,
    "win_rate_pct":     pl.Float64,
    "profit_factor":    pl.Float64,
    "expectancy_rs":    pl.Float64,
    "equity_pnl_rs":    pl.Float64,
}


def _empty_results() -> pl.DataFrame:
    return pl.DataFrame(schema=_RESULT_SCHEMA)


def _windows(start: date, end: date, cfg: WalkForwardConfig) -> Iterable[tuple[int, date, date, date, date]]:
    cur = start
    wid = 0
    while True:
        train_start = cur
        train_end = train_start + timedelta(days=cfg.train_days - 1)
        val_start = train_end + timedelta(days=1)
        val_end = val_start + timedelta(days=cfg.validate_days - 1)
        if val_end > end:
            return
        yield wid, train_start, train_end, val_start, val_end
        cur = cur + timedelta(days=cfg.step_days)
        wid += 1


def walk_forward(
    history: pl.DataFrame,
    signal_fn: SignalFn,
    *,
    start: date | str,
    end: date | str,
    config: WalkForwardConfig | None = None,
    capital: float = 100_000.0,
    risk_pct: float = 1.0,
    max_holding_days: int = 20,
) -> pl.DataFrame:
    """Run a rolling out-of-sample evaluation.

    ``history`` is a multi-symbol OHLCV frame with at least
    ``symbol, trade_date, open, high, low, close``. ``signal_fn(d, train_df)``
    is called once per validation date — it receives the in-sample slice
    and must return a canonical signal frame for that single date. Any
    exception inside ``signal_fn`` is logged and treated as zero signals
    so a single bad date never aborts the sweep.
    """
    cfg = config or WalkForwardConfig()
    start_d = to_date(start)
    end_d = to_date(end)
    if start_d is None or end_d is None or end_d <= start_d:
        log.warning("walk_forward: bad date range %s..%s", start, end)
        return _empty_results()
    if history is None or history.is_empty() or "trade_date" not in history.columns:
        return _empty_results()

    rows: list[dict] = []
    try:
        hist = history.sort(["symbol", "trade_date"]) \
            if "symbol" in history.columns else history.sort("trade_date")
        windows_iter = list(_windows(start_d, end_d, cfg))
    except Exception as exc:  # noqa: BLE001
        log.warning("walk_forward setup failed: %s", exc)
        return _empty_results()

    for wid, t0, t1, v0, v1 in windows_iter:
        # Each window is fully isolated — a failure in one (signal_fn,
        # to_backtest_signals, run_backtest, compute_results, or anything
        # in between) logs a warning and appends a zero-metric row so the
        # sweep continues and the caller can still see which windows
        # broke. We never abort the entire sweep over one bad window.
        n_signals = 0
        n_trades = 0
        win_rate = 0.0
        pf = 0.0
        expectancy = 0.0
        equity_pnl = 0.0
        try:
            train = hist.filter(
                (pl.col("trade_date") >= t0) & (pl.col("trade_date") <= t1)
            )
            if train.height < cfg.min_train_bars:
                continue
            val_dates = sorted({d for d in
                                hist.filter(
                                    (pl.col("trade_date") >= v0)
                                    & (pl.col("trade_date") <= v1))["trade_date"].to_list()})

            sig_parts: list[pl.DataFrame] = []
            for d in val_dates:
                try:
                    s = signal_fn(d, train)
                    if s is not None and not s.is_empty():
                        sig_parts.append(s)
                except Exception as exc:  # noqa: BLE001
                    log.warning(
                        "walk_forward: signal_fn(%s) raised in window %d: %s",
                        d, wid, exc)
            n_signals = sum(p.height for p in sig_parts)

            if sig_parts:
                try:
                    signals = pl.concat(sig_parts, how="vertical_relaxed")
                    bt_sigs = to_backtest_signals(
                        signals, capital=capital, risk_pct=risk_pct)
                    bars = hist.filter(
                        (pl.col("trade_date") >= v0)
                        & (pl.col("trade_date") <= v1
                           + timedelta(days=max_holding_days * 2)))
                    cfg_bt = BacktestConfig(max_holding_days=max_holding_days)
                    bundle = run_backtest(bt_sigs, bars, config=cfg_bt)
                    trades = bundle.get("trades") if isinstance(bundle, dict) else None
                    res = bundle.get("results") if isinstance(bundle, dict) else None
                    if trades is not None and not trades.is_empty():
                        n_trades = trades.height
                        if res is not None and not res.is_empty():
                            def _safe(col: str) -> float:
                                try:
                                    return float(res[col][0] or 0.0) \
                                        if col in res.columns else 0.0
                                except Exception:
                                    return 0.0
                            win_rate = _safe("win_rate_pct")
                            pf = _safe("profit_factor")
                            expectancy = _safe("expectancy_rs")
                            equity_pnl = _safe("equity_pnl_rs")
                except Exception as exc:  # noqa: BLE001
                    log.warning(
                        "walk_forward: backtest failed in window %d (%s..%s): %s",
                        wid, v0, v1, exc)
        except Exception as exc:  # noqa: BLE001
            log.warning(
                "walk_forward: window %d (%s..%s) failed: %s",
                wid, v0, v1, exc)

        rows.append({
            "window_id": wid,
            "train_start": t0, "train_end": t1,
            "val_start": v0, "val_end": v1,
            "n_signals": n_signals, "n_trades": n_trades,
            "win_rate_pct": win_rate, "profit_factor": pf,
            "expectancy_rs": expectancy, "equity_pnl_rs": equity_pnl,
        })

    if not rows:
        return _empty_results()
    return pl.DataFrame(rows, schema=_RESULT_SCHEMA)
