"""Canonical schemas + status enum + config for the backtest engine."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Mapping

import polars as pl


class BacktestStatus(str, Enum):
    """Closed-trade exit reason. Open positions live as :class:`Position`
    objects in memory and are never written to the ledger until they close."""
    CLOSED       = "closed"        # generic close (e.g. forced end-of-data)
    STOPPED      = "stopped"       # stop-loss hit (intraday low <= stop)
    TARGET_HIT   = "target_hit"    # target hit (intraday high >= target)
    EXPIRED      = "expired"       # max_holding_days reached
    PARTIAL      = "partial"       # partial exit leg (remainder still open)
    OPEN         = "open"          # unrealized; only on `Position`, not ledger


# ---------- canonical Polars schemas ------------------------------------------

# One row per *exit event*. Partial exits emit one row with status="partial"
# and the final exit emits a second row with the remaining qty.
TRADE_SCHEMA: Mapping[str, pl.DataType] = {
    "strategy_id":       pl.Utf8,    # e.g. "momentum_v1"
    "setup_name":        pl.Utf8,    # e.g. "momentum_breakout"
    "symbol":            pl.Utf8,
    "side":              pl.Utf8,    # "long" | "short"
    "entry_date":        pl.Date,
    "entry_price":       pl.Float64,
    "exit_date":         pl.Date,
    "exit_price":        pl.Float64,
    "qty":               pl.Int64,
    "capital_allocated": pl.Float64,
    "risk_rs":           pl.Float64,
    "stop_loss":         pl.Float64,
    "target":            pl.Float64, # nullable
    "status":            pl.Utf8,    # one of BacktestStatus values
    "exit_reason":       pl.Utf8,    # short human note
    "leg":               pl.Int32,   # 0 = single/final, 1..N = partials
    "holding_days":      pl.Int64,
    "pnl_rs":            pl.Float64,
    "return_pct":        pl.Float64,
    "slippage_rs":       pl.Float64,
    "brokerage_rs":      pl.Float64,
    # Hive partition cols (derived from entry_date)
    "year":              pl.Int32,
    "month":             pl.Int32,
}

# The "trade-group" key as the user spec: a backtest run with the same
# strategy_id should be re-runnable on the same date range and produce
# the same rows. The `leg` discriminator is added so a partial exit and
# its final exit are distinct upsert keys.
TRADE_PK: list[str] = [
    "strategy_id", "symbol", "entry_date", "setup_name", "leg",
]

RESULT_SCHEMA: Mapping[str, pl.DataType] = {
    "strategy_id":          pl.Utf8,
    "total_trades":         pl.Int64,
    "wins":                 pl.Int64,
    "losses":               pl.Int64,
    "win_rate":             pl.Float64,
    "average_return":       pl.Float64,    # mean(return_pct)
    "max_drawdown":         pl.Float64,    # equity-curve drawdown, decimal
    "profit_factor":        pl.Float64,    # gross_profit / |gross_loss|
    "expectancy":           pl.Float64,    # mean(pnl_rs) per trade
    "average_holding_days": pl.Float64,
    "total_pnl_rs":         pl.Float64,
    "gross_profit_rs":      pl.Float64,
    "gross_loss_rs":        pl.Float64,
}


def empty_trades() -> pl.DataFrame:
    return pl.DataFrame(schema=dict(TRADE_SCHEMA))


def empty_results() -> pl.DataFrame:
    return pl.DataFrame(schema=dict(RESULT_SCHEMA))


# ---------- execution config --------------------------------------------------

@dataclass
class BacktestConfig:
    """Knobs controlling the EOD execution model.

    Defaults are conservative and match common Indian-equity swing
    practice: enter on next bar's open, 5bps slippage, 3bps brokerage,
    20-bar max holding, no partials.
    """

    strategy_id: str = "default"

    # Entry timing: "next_open" (the open of the bar AFTER entry_date)
    # or "same_close" (the close of entry_date itself). Most realistic
    # is next_open — by EOD you've seen the close, so the earliest you
    # can transact is the next session.
    entry_rule: str = "next_open"

    # Slippage applied as a fraction of fill price, deducted from PnL on
    # both entry and exit. 0.0005 = 5 bps each side.
    slippage_pct: float = 0.0005

    # Brokerage applied as a fraction of *notional* (qty × price), each side.
    brokerage_pct: float = 0.0003

    # Flat brokerage floor in ₹, applied per side. Models the
    # "₹20 or 0.03% whichever is lower" charge structure used by Indian
    # discount brokers (Zerodha, Upstox, etc) — set ``min_brokerage_rs``
    # > 0 to enable the floor. Default 0.0 (no floor).
    min_brokerage_rs: float = 0.0

    # Flat per-trade commission in ₹, applied each side **in addition to**
    # the percentage brokerage. Set this to model a fixed-fee broker
    # (e.g. Indian regulatory turnover charges, GST on brokerage, etc.
    # rolled into one number). Default 0.0.
    commission_per_trade_rs: float = 0.0

    # Market-impact bps applied as additional adverse slippage on each
    # side, on top of ``slippage_pct``. Useful for sizing-aware
    # backtests (e.g. add 5-15 bps for mid-caps to penalise larger
    # positions). 0.0 = no extra impact (default).
    impact_bps: float = 0.0

    # Hard cap on bars held before forced exit at close.
    max_holding_days: int = 20

    # Partial exit: take ``partial_qty_pct`` of the position off at
    # ``partial_target_r`` × initial-risk above entry (long) / below
    # entry (short). Set ``partial_qty_pct = 0`` to disable.
    partial_qty_pct: float = 0.0
    partial_target_r: float = 1.0

    # If signals don't carry a `target` column, derive one as
    # ``entry_price ± target_r × initial_risk``. Set to None to disable
    # target-based exits (only stops / max_holding apply).
    target_r: float | None = 2.0

    # Gap handling: when a gap-down opens through the stop, fill at the
    # open (= worse than stop). When a gap-up opens through the target,
    # fill at the open (= better than target). This is the standard
    # "honor the open" convention and what real fills look like.
    honor_gap_at_open: bool = True
