"""Backtest engine — v0.3.0 foundation.

Public surface (intentionally narrow):

- :class:`BacktestConfig` — execution knobs (entry rule, slippage,
  brokerage, max holding, partials).
- :class:`Position` — one in-flight trade's mutable state.
- :data:`TRADE_SCHEMA` / :data:`RESULT_SCHEMA` — canonical Polars schemas.
- :func:`run_backtest` — driver: takes a signals book + OHLCV history,
  returns ``{trades, results}``.
- :func:`compute_results` — aggregate a trades frame into per-strategy
  metrics.
- :func:`save_trades` — write trades to the parquet ledger via
  ``append_partition`` (default) or ``upsert_partition`` (rerunnable).

Crash-proof contract: every public function returns a Polars DataFrame
or dict of DataFrames matching the documented schema, even on failure.
Never raises.
"""

from nsefast.backtest._schema import (
    RESULT_SCHEMA,
    TRADE_SCHEMA,
    TRADE_PK,
    BacktestConfig,
    BacktestStatus,
    empty_results,
    empty_trades,
)
from nsefast.backtest.engine import Position, run_backtest
from nsefast.backtest.ledger import read_trades, save_trades
from nsefast.backtest.metrics import compute_results

__all__ = [
    "BacktestConfig",
    "BacktestStatus",
    "Position",
    "TRADE_SCHEMA",
    "RESULT_SCHEMA",
    "TRADE_PK",
    "empty_trades",
    "empty_results",
    "run_backtest",
    "compute_results",
    "save_trades",
    "read_trades",
]
