"""Per-strategy performance metrics from a closed-trade ledger."""

from __future__ import annotations

import polars as pl

from nsefast.backtest._schema import RESULT_SCHEMA, empty_results
from nsefast.logging_setup import get_logger

log = get_logger(__name__)


def compute_results(trades: pl.DataFrame) -> pl.DataFrame:
    """Aggregate `trades` into per-strategy metrics.

    Skips ``status="partial"`` legs in win/loss accounting (they are
    intermediate exits, not closed positions); ``pnl_rs`` from partial
    legs is still summed into total/gross numbers.

    Crash-proof: returns empty :data:`RESULT_SCHEMA` frame on failure.
    """
    if trades is None or trades.is_empty():
        return empty_results()

    try:
        # Equity curve for max-drawdown is per-strategy, ordered by
        # exit_date then symbol so partial legs stay grouped.
        out_rows = []
        for sid_tuple, sub in trades.group_by("strategy_id"):
            sid = sid_tuple[0] if isinstance(sid_tuple, tuple) else sid_tuple
            sub_sorted = sub.sort(["exit_date", "symbol", "leg"])

            total_pnl = float(sub_sorted["pnl_rs"].sum())
            # Closed positions for win/loss = anything that's not a partial leg.
            closed = sub_sorted.filter(pl.col("status") != "partial")
            n_total = closed.height
            wins_df = closed.filter(pl.col("pnl_rs") > 0)
            losses_df = closed.filter(pl.col("pnl_rs") < 0)
            n_wins = wins_df.height
            n_losses = losses_df.height

            gross_profit = float(wins_df["pnl_rs"].sum()) if n_wins else 0.0
            gross_loss = float(losses_df["pnl_rs"].sum()) if n_losses else 0.0
            win_rate = (n_wins / n_total) if n_total else 0.0
            avg_return = (float(closed["return_pct"].mean())
                          if n_total else 0.0)
            avg_hold = (float(closed["holding_days"].mean())
                        if n_total else 0.0)
            expectancy = (float(closed["pnl_rs"].mean())
                          if n_total else 0.0)
            # NB: when there are wins but zero losses, profit factor is
            # mathematically infinite. Emit ``None`` (parquet-safe null)
            # rather than ``float('inf')`` so the column round-trips
            # through parquet/JSON and downstream consumers can decide
            # how to render "undefined / no losing trades".
            if gross_loss == 0 and gross_profit > 0:
                profit_factor: float | None = None
            elif gross_loss != 0:
                profit_factor = gross_profit / abs(gross_loss)
            else:
                profit_factor = 0.0

            # Equity curve drawdown from cumulative pnl.
            equity = sub_sorted.with_columns(
                pl.col("pnl_rs").cum_sum().alias("equity")
            )
            equity = equity.with_columns(
                pl.col("equity").cum_max().alias("peak")
            )
            equity = equity.with_columns(
                (pl.col("peak") - pl.col("equity")).alias("dd")
            )
            max_dd_rs = float(equity["dd"].max() or 0.0)
            peak_rs = float(equity["peak"].max() or 0.0)
            max_drawdown = (max_dd_rs / peak_rs) if peak_rs > 0 else 0.0

            out_rows.append({
                "strategy_id":          str(sid),
                "total_trades":         int(n_total),
                "wins":                 int(n_wins),
                "losses":               int(n_losses),
                "win_rate":             float(win_rate),
                "average_return":       float(avg_return),
                "max_drawdown":         float(max_drawdown),
                "profit_factor":        (None if profit_factor is None
                                         else float(profit_factor)),
                "expectancy":           float(expectancy),
                "average_holding_days": float(avg_hold),
                "total_pnl_rs":         float(total_pnl),
                "gross_profit_rs":      float(gross_profit),
                "gross_loss_rs":        float(gross_loss),
            })

        return (pl.DataFrame(out_rows, schema=dict(RESULT_SCHEMA))
                if out_rows else empty_results())
    except Exception as exc:  # noqa: BLE001
        log.warning("compute_results failed", extra={"err": str(exc)})
        return empty_results()
