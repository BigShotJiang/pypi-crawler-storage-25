"""EOD backtest engine.

One signal row in -> zero or more trade rows out.

The execution model is intentionally simple but realistic for daily
Indian-equity swing trading:

1. **Entry** on ``entry_rule`` (default: next bar's open after the
   signal date). Slippage is applied to the fill.
2. Each subsequent bar is checked in this order (long; mirror for short):

   * **Gap-down through the stop** → exit at the bar's open
     (``honor_gap_at_open=True``).
   * **Intraday low ≤ stop** → exit at the stop price.
   * **Gap-up through the target** → exit at the bar's open.
   * **Intraday high ≥ partial-target** → take ``partial_qty_pct`` off
     at the partial-target price; the remainder stays open.
   * **Intraday high ≥ target** → exit remainder at the target price.

3. **Max-holding** reached → forced exit at the bar's close,
   ``status="expired"``.
4. **End of available history** with the position still open → forced
   exit at the last bar's close, ``status="closed"``.

Slippage is applied as a fraction of fill price (worse for the trader
on each side). Brokerage is applied as a fraction of notional on both
sides. PnL and return_pct are net of both.

Crash-proof: ``run_backtest`` swallows per-signal exceptions
(logged + skipped) and returns a canonical empty trades frame on
catastrophic failure.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import date
from typing import Optional

import polars as pl

from nsefast.backtest._schema import (
    BacktestConfig,
    BacktestStatus,
    TRADE_SCHEMA,
    empty_trades,
)
from nsefast.logging_setup import get_logger
from nsefast.storage.quality import track_quality

log = get_logger(__name__)


# ---------- Position ----------------------------------------------------------

@dataclass
class Position:
    """In-flight trade state. Mutated by the engine; never persisted directly."""
    strategy_id: str
    setup_name: str
    symbol: str
    side: str                       # "long" | "short"
    entry_date: date
    entry_price: float
    qty: int                        # remaining (may shrink after partials)
    initial_qty: int                # never mutated — for sizing math
    capital_allocated: float
    risk_rs: float
    stop_loss: float
    target: Optional[float]
    partial_target: Optional[float]
    partial_qty: int                # how many shares to take off on partial
    status: BacktestStatus = BacktestStatus.OPEN
    bars_held: int = 0
    partial_done: bool = False
    closed_legs: list[dict] = field(default_factory=list)

    @property
    def is_long(self) -> bool:
        return self.side == "long"


# ---------- helpers -----------------------------------------------------------

def _apply_slippage(price: float, side: str, leg: str, slip_pct: float) -> float:
    """Worsen the fill by `slip_pct` on the appropriate side."""
    if side == "long":
        return price * (1 + slip_pct) if leg == "entry" else price * (1 - slip_pct)
    # short
    return price * (1 - slip_pct) if leg == "entry" else price * (1 + slip_pct)


def _brokerage(qty: int, price: float, brokerage_pct: float) -> float:
    return abs(qty) * price * brokerage_pct


def _pnl_for_leg(
    pos: Position, exit_price: float, qty_closed: int,
) -> float:
    """Gross PnL for a single closed leg (before slippage/brokerage)."""
    delta = exit_price - pos.entry_price
    return (qty_closed * delta) if pos.is_long else (qty_closed * -delta)


def _emit_leg(
    pos: Position,
    *,
    exit_date: date,
    exit_price_raw: float,
    qty_closed: int,
    status: BacktestStatus,
    exit_reason: str,
    leg: int,
    cfg: BacktestConfig,
) -> dict:
    """Build the trade-row dict for one closed leg, applying costs."""
    # Total adverse-fill bps each side = configured slippage + market
    # impact. Both worsen the fill in the same direction, so we just sum
    # them and apply once.
    total_slip_pct = cfg.slippage_pct + (cfg.impact_bps / 10_000.0)
    fill_exit = _apply_slippage(exit_price_raw, pos.side, "exit", total_slip_pct)
    fill_entry = _apply_slippage(pos.entry_price, pos.side, "entry", total_slip_pct)

    gross_pnl = (qty_closed * (fill_exit - fill_entry)) if pos.is_long \
        else (qty_closed * (fill_entry - fill_exit))

    # Brokerage = max(percent_of_notional, min_floor) + flat_commission, per side.
    def _side_cost(price: float) -> float:
        pct_cost = _brokerage(qty_closed, price, cfg.brokerage_pct)
        floored = max(pct_cost, cfg.min_brokerage_rs) if cfg.min_brokerage_rs > 0 else pct_cost
        return floored + cfg.commission_per_trade_rs

    brokerage = _side_cost(fill_entry) + _side_cost(fill_exit)
    slippage_rs = abs(qty_closed) * (
        abs(fill_entry - pos.entry_price) + abs(fill_exit - exit_price_raw)
    )
    pnl_rs = gross_pnl - brokerage

    notional_entry = qty_closed * pos.entry_price
    return_pct = (pnl_rs / notional_entry * 100.0) if notional_entry > 0 else 0.0

    return {
        "strategy_id":       pos.strategy_id,
        "setup_name":        pos.setup_name,
        "symbol":            pos.symbol,
        "side":              pos.side,
        "entry_date":        pos.entry_date,
        "entry_price":       float(pos.entry_price),
        "exit_date":         exit_date,
        "exit_price":        float(exit_price_raw),
        "qty":               int(qty_closed),
        "capital_allocated": float(pos.capital_allocated),
        "risk_rs":           float(pos.risk_rs),
        "stop_loss":         float(pos.stop_loss),
        "target":            None if pos.target is None else float(pos.target),
        "status":            status.value,
        "exit_reason":       exit_reason,
        "leg":               int(leg),
        "holding_days":      int(pos.bars_held),
        "pnl_rs":            float(pnl_rs),
        "return_pct":        float(return_pct),
        "slippage_rs":       float(slippage_rs),
        "brokerage_rs":      float(brokerage),
        "year":              int(pos.entry_date.year),
        "month":             int(pos.entry_date.month),
    }


def _validate_ohlc(bars: pl.DataFrame) -> tuple[pl.DataFrame, int]:
    """Drop bars with bad OHLC; return (clean, dropped_count)."""
    if bars.is_empty():
        return bars, 0
    needed = {"trade_date", "open", "high", "low", "close"}
    missing = needed - set(bars.columns)
    if missing:
        return bars.head(0), bars.height
    before = bars.height
    clean = bars.filter(
        pl.col("open").is_not_null()
        & pl.col("high").is_not_null()
        & pl.col("low").is_not_null()
        & pl.col("close").is_not_null()
        & (pl.col("high") >= pl.col("low"))
        & (pl.col("high") >= pl.col("open"))
        & (pl.col("high") >= pl.col("close"))
        & (pl.col("low") <= pl.col("open"))
        & (pl.col("low") <= pl.col("close"))
        & (pl.col("open") > 0)
    )
    return clean, before - clean.height


def _simulate_one(
    pos: Position,
    bars: pl.DataFrame,                  # bars STRICTLY AFTER entry signal day
    cfg: BacktestConfig,
) -> list[dict]:
    """Walk forward bar-by-bar until the position closes. Returns trade rows."""
    rows: list[dict] = []

    # ---- entry fill --------------------------------------------------
    if cfg.entry_rule == "next_open":
        if bars.is_empty():
            return rows                    # no future bars → drop signal
        entry_bar = bars.row(0, named=True)
        pos.entry_price = float(entry_bar["open"])
        # Recompute qty from risk_rs / risk-per-share at the *actual* fill,
        # so qty stays honest under slippage. (Position arrives pre-sized
        # at the signal price; we only re-derive if risk_rs > 0.)
        rps = abs(pos.entry_price - pos.stop_loss)
        if rps > 0 and pos.risk_rs > 0:
            new_qty = int(pos.risk_rs // rps)
            if new_qty <= 0:
                return rows                # gap blew the risk budget
            pos.qty = new_qty
            pos.initial_qty = new_qty
            if cfg.partial_qty_pct > 0:
                pos.partial_qty = max(int(new_qty * cfg.partial_qty_pct), 0)
        forward = bars.slice(1, bars.height - 1)
    else:                                   # "same_close" — fill at signal-day close
        forward = bars

    # Re-derive target if not pre-set on the position.
    if pos.target is None and cfg.target_r is not None:
        rps = abs(pos.entry_price - pos.stop_loss)
        if rps > 0:
            pos.target = (pos.entry_price + cfg.target_r * rps) if pos.is_long \
                else (pos.entry_price - cfg.target_r * rps)

    if pos.partial_qty > 0 and pos.partial_target is None:
        rps = abs(pos.entry_price - pos.stop_loss)
        if rps > 0:
            pos.partial_target = (pos.entry_price + cfg.partial_target_r * rps) \
                if pos.is_long else (pos.entry_price - cfg.partial_target_r * rps)

    # ---- forward simulation -----------------------------------------
    leg_idx = 0
    for i in range(forward.height):
        bar = forward.row(i, named=True)
        pos.bars_held = i + 1
        bdate = bar["trade_date"]
        bopen, bhigh, blow, bclose = (
            float(bar["open"]), float(bar["high"]),
            float(bar["low"]),  float(bar["close"])
        )

        # ---- gap-through-stop --------------------------------------
        if cfg.honor_gap_at_open:
            if pos.is_long and bopen <= pos.stop_loss:
                rows.append(_emit_leg(
                    pos, exit_date=bdate, exit_price_raw=bopen,
                    qty_closed=pos.qty, status=BacktestStatus.STOPPED,
                    exit_reason="gap_down_through_stop", leg=leg_idx, cfg=cfg,
                ))
                pos.status = BacktestStatus.STOPPED
                return rows
            if (not pos.is_long) and bopen >= pos.stop_loss:
                rows.append(_emit_leg(
                    pos, exit_date=bdate, exit_price_raw=bopen,
                    qty_closed=pos.qty, status=BacktestStatus.STOPPED,
                    exit_reason="gap_up_through_stop", leg=leg_idx, cfg=cfg,
                ))
                pos.status = BacktestStatus.STOPPED
                return rows

        # ---- stop hit (intraday) -----------------------------------
        if pos.is_long and blow <= pos.stop_loss:
            rows.append(_emit_leg(
                pos, exit_date=bdate, exit_price_raw=pos.stop_loss,
                qty_closed=pos.qty, status=BacktestStatus.STOPPED,
                exit_reason="stop_hit", leg=leg_idx, cfg=cfg,
            ))
            pos.status = BacktestStatus.STOPPED
            return rows
        if (not pos.is_long) and bhigh >= pos.stop_loss:
            rows.append(_emit_leg(
                pos, exit_date=bdate, exit_price_raw=pos.stop_loss,
                qty_closed=pos.qty, status=BacktestStatus.STOPPED,
                exit_reason="stop_hit", leg=leg_idx, cfg=cfg,
            ))
            pos.status = BacktestStatus.STOPPED
            return rows

        # ---- gap-through-target ------------------------------------
        if pos.target is not None and cfg.honor_gap_at_open:
            if pos.is_long and bopen >= pos.target:
                rows.append(_emit_leg(
                    pos, exit_date=bdate, exit_price_raw=bopen,
                    qty_closed=pos.qty, status=BacktestStatus.TARGET_HIT,
                    exit_reason="gap_up_through_target", leg=leg_idx, cfg=cfg,
                ))
                pos.status = BacktestStatus.TARGET_HIT
                return rows
            if (not pos.is_long) and bopen <= pos.target:
                rows.append(_emit_leg(
                    pos, exit_date=bdate, exit_price_raw=bopen,
                    qty_closed=pos.qty, status=BacktestStatus.TARGET_HIT,
                    exit_reason="gap_down_through_target", leg=leg_idx, cfg=cfg,
                ))
                pos.status = BacktestStatus.TARGET_HIT
                return rows

        # ---- partial exit ------------------------------------------
        if (not pos.partial_done
                and pos.partial_target is not None
                and pos.partial_qty > 0
                and pos.partial_qty < pos.qty):
            hit_partial = (pos.is_long and bhigh >= pos.partial_target) \
                or ((not pos.is_long) and blow <= pos.partial_target)
            if hit_partial:
                rows.append(_emit_leg(
                    pos, exit_date=bdate, exit_price_raw=pos.partial_target,
                    qty_closed=pos.partial_qty, status=BacktestStatus.PARTIAL,
                    exit_reason="partial_target", leg=leg_idx, cfg=cfg,
                ))
                pos.qty -= pos.partial_qty
                pos.partial_done = True
                leg_idx += 1
                # don't return — remainder may still hit target this bar

        # ---- target hit (intraday) ---------------------------------
        if pos.target is not None:
            if pos.is_long and bhigh >= pos.target:
                rows.append(_emit_leg(
                    pos, exit_date=bdate, exit_price_raw=pos.target,
                    qty_closed=pos.qty, status=BacktestStatus.TARGET_HIT,
                    exit_reason="target_hit", leg=leg_idx, cfg=cfg,
                ))
                pos.status = BacktestStatus.TARGET_HIT
                return rows
            if (not pos.is_long) and blow <= pos.target:
                rows.append(_emit_leg(
                    pos, exit_date=bdate, exit_price_raw=pos.target,
                    qty_closed=pos.qty, status=BacktestStatus.TARGET_HIT,
                    exit_reason="target_hit", leg=leg_idx, cfg=cfg,
                ))
                pos.status = BacktestStatus.TARGET_HIT
                return rows

        # ---- max holding -------------------------------------------
        if pos.bars_held >= cfg.max_holding_days:
            rows.append(_emit_leg(
                pos, exit_date=bdate, exit_price_raw=bclose,
                qty_closed=pos.qty, status=BacktestStatus.EXPIRED,
                exit_reason="max_holding_days", leg=leg_idx, cfg=cfg,
            ))
            pos.status = BacktestStatus.EXPIRED
            return rows

    # End of history with position still open → force close at last bar.
    if forward.height > 0:
        last = forward.row(forward.height - 1, named=True)
        rows.append(_emit_leg(
            pos, exit_date=last["trade_date"],
            exit_price_raw=float(last["close"]),
            qty_closed=pos.qty, status=BacktestStatus.CLOSED,
            exit_reason="end_of_history", leg=leg_idx, cfg=cfg,
        ))
        pos.status = BacktestStatus.CLOSED
    return rows


# ---------- public driver -----------------------------------------------------

def run_backtest(
    signals: pl.DataFrame,
    history: pl.DataFrame,
    *,
    config: BacktestConfig | None = None,
    setup_name: str = "unknown",
    symbol_col: str = "symbol",
    date_col: str = "trade_date",
) -> dict:
    """Run an EOD backtest over `signals` against `history`.

    Parameters
    ----------
    signals
        Frame matching the setups :data:`BOOK_SCHEMA` shape, at minimum:
        ``symbol``, ``as_of`` (signal date), ``entry_price``, ``stop_loss``,
        ``qty``, ``capital_allocated`` (or ``allocated_rs``), ``risk_rs``.
        Optional: ``side`` (default "long"), ``target``.
    history
        Long-format OHLCV panel (one row per ``symbol``/``trade_date``).
    config
        Execution config; defaults to :class:`BacktestConfig()`.
    setup_name
        Stamped onto every emitted trade row for downstream filtering.

    Returns
    -------
    dict
        ``{"trades": pl.DataFrame, "results": pl.DataFrame}`` — both
        match the canonical schemas. On any catastrophic failure both
        are empty (with the right schemas) and the error is logged.
    """
    cfg = config or BacktestConfig()
    try:
        if signals is None or history is None or signals.is_empty():
            return {"trades": empty_trades(), "results": _empty_results_for(cfg)}

        all_rows: list[dict] = []

        with track_quality("backtest_engine", cfg.strategy_id) as q:
            bad_signals = 0
            for sig in signals.iter_rows(named=True):
                try:
                    sym = sig[symbol_col]
                    sig_date = sig.get("as_of") or sig.get(date_col)
                    if sym is None or sig_date is None:
                        bad_signals += 1
                        continue

                    bars = history.filter(
                        (pl.col(symbol_col) == sym)
                        & (pl.col(date_col) > sig_date)
                    ).sort(date_col)
                    bars, dropped = _validate_ohlc(bars)
                    if dropped:
                        log.debug(
                            "ohlc rows dropped",
                            extra={"symbol": sym, "dropped": dropped},
                        )
                    if bars.is_empty():
                        bad_signals += 1
                        continue

                    qty = int(sig.get("qty") or 0)
                    if qty <= 0:
                        bad_signals += 1
                        continue

                    capital_allocated = float(
                        sig.get("notional_rs")
                        or sig.get("allocated_rs")
                        or sig.get("capital_allocated")
                        or 0.0
                    )
                    risk_rs = float(sig.get("risk_rs") or 0.0)

                    partial_qty = int(qty * cfg.partial_qty_pct) \
                        if cfg.partial_qty_pct > 0 else 0

                    pos = Position(
                        strategy_id=cfg.strategy_id,
                        setup_name=str(sig.get("setup") or setup_name),
                        symbol=str(sym),
                        side=str(sig.get("side") or "long"),
                        entry_date=sig_date,           # provisional; engine
                                                       # rewrites to fill date
                        entry_price=float(sig["entry_price"]),
                        qty=qty,
                        initial_qty=qty,
                        capital_allocated=capital_allocated,
                        risk_rs=risk_rs,
                        stop_loss=float(sig["stop_loss"]),
                        target=(float(sig["target"]) if sig.get("target") is not None
                                else None),
                        partial_target=None,
                        partial_qty=partial_qty,
                    )
                    # Set entry_date to the actual fill date.
                    if cfg.entry_rule == "next_open":
                        pos.entry_date = bars.row(0, named=True)["trade_date"]

                    legs = _simulate_one(pos, bars, cfg)
                    all_rows.extend(legs)
                except Exception as exc:  # noqa: BLE001
                    log.warning(
                        "signal sim failed",
                        extra={"symbol": sig.get(symbol_col), "err": str(exc)},
                    )
                    bad_signals += 1

            trades = (pl.DataFrame(all_rows, schema=dict(TRADE_SCHEMA))
                      if all_rows else empty_trades())
            q.row_count = trades.height
            from nsefast.storage.quality import hash_dataframe
            q.content_hash = hash_dataframe(trades)
            # Flag the run as degraded if ANY signal was dropped — this
            # surfaces silent universe issues (missing future bars, bad
            # OHLC, zero qty, gap blew the risk budget) instead of only
            # raising the alarm when the entire run produced zero trades.
            q.partial_failure = (bad_signals > 0)

        from nsefast.backtest.metrics import compute_results
        results = compute_results(trades)
        return {"trades": trades, "results": results}
    except Exception as exc:  # noqa: BLE001
        log.warning("run_backtest failed", extra={"err": str(exc)})
        return {"trades": empty_trades(), "results": _empty_results_for(cfg)}


def _empty_results_for(cfg: BacktestConfig) -> pl.DataFrame:
    from nsefast.backtest._schema import empty_results
    return empty_results()
