"""Decorator for crash-proof public functions returning Polars DataFrames.

Every public ``nsefast`` helper that returns a DataFrame is contractually
required to return a *canonical empty frame* (correct schema, zero rows)
on failure rather than raising or — worse — leaking partial input.

The boilerplate that contract demands::

    def my_helper(df):
        try:
            ...
            return out
        except Exception as exc:                  # noqa: BLE001
            log.warning("my_helper failed: %s", exc)
            return empty_my_helper()

…is repeated dozens of times across the library. ``@safe_dataframe``
replaces it with::

    @safe_dataframe(empty_my_helper)
    def my_helper(df):
        ...
        return out

Behaviour
---------
* Any exception raised by the wrapped function is caught, logged at
  WARNING with the function name and exception message, and the result
  of ``empty_factory()`` is returned.
* If the wrapped function returns ``None``, ``empty_factory()`` is also
  returned. (None is never a valid public return value in this library.)
* The decorator is type-friendly: ``functools.wraps`` preserves
  ``__name__`` / ``__doc__`` / ``__wrapped__`` so docs and tests still
  see the original.

Notes
-----
This decorator deliberately catches **all** exceptions including
``KeyboardInterrupt``-adjacent ``BaseException`` subclasses are *not*
caught (we still allow the user to ^C out of a long run).
"""
from __future__ import annotations

import functools
from typing import Callable, TypeVar

import polars as pl

from nsefast.logging_setup import get_logger

log = get_logger(__name__)

F = TypeVar("F", bound=Callable[..., pl.DataFrame])


def safe_dataframe(
    empty_factory: Callable[[], pl.DataFrame],
    *,
    name: str | None = None,
) -> Callable[[F], F]:
    """Decorator: wrap a DataFrame-returning function with the canonical-empty contract.

    Parameters
    ----------
    empty_factory
        Zero-argument callable that returns the canonical empty
        DataFrame (correct schema, zero rows). This is called on
        exception, when the wrapped function returns ``None``, and is
        the single source of truth for "what does empty look like".
    name
        Override the function name used in the warning log line.
        Defaults to the wrapped function's ``__name__``.

    Examples
    --------
    >>> from nsefast.strategies._base import empty_signals
    >>> @safe_dataframe(empty_signals)
    ... def my_strategy(date, universe):
    ...     ...
    """
    def deco(fn: F) -> F:
        label = name or fn.__name__

        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            try:
                out = fn(*args, **kwargs)
            except Exception as exc:  # noqa: BLE001 — that's the whole point
                log.warning("%s failed: %s", label, exc)
                return empty_factory()
            if out is None:
                log.warning("%s returned None — replacing with canonical empty", label)
                return empty_factory()
            return out

        return wrapper  # type: ignore[return-value]

    return deco


__all__ = ["safe_dataframe"]
