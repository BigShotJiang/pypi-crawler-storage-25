"""Webhook notifiers — push DataFrames into Slack / Discord / generic webhooks.

Designed for cron'd EOD scans: pipe top-upside / top-downside / avoid-list
straight into a Slack channel without writing glue code each time.

The library has no hard dependency on any chat product — every function
takes a webhook URL and posts plain JSON via ``requests``. All functions
return ``True`` on success, ``False`` on failure. **Never raises.**

Example::

    from nsefast.notify import slack
    slack(top_upside_df, webhook_url=os.environ["SLACK_WEBHOOK"],
          title="EOD Top Upside — 2026-05-07", top_n=10)
"""

from __future__ import annotations

from typing import Iterable, Mapping

import polars as pl
import requests

from nsefast.config import REQUEST_TIMEOUT_SECONDS
from nsefast.logging_setup import get_logger

log = get_logger(__name__)

# Sensible default columns for swing scanner outputs. Extra/missing
# columns degrade gracefully — only existing columns are rendered.
_DEFAULT_COLS: tuple[str, ...] = (
    "symbol", "close", "percent_change", "score", "volume",
)


def _select_render_cols(
    df: pl.DataFrame, columns: Iterable[str] | None,
) -> list[str]:
    requested = list(columns) if columns else list(_DEFAULT_COLS)
    return [c for c in requested if c in df.columns]


def _format_value(v) -> str:
    if v is None:
        return "—"
    if isinstance(v, float):
        # Guard non-finite *before* any arithmetic; ``int(float('nan'))`` and
        # ``int(float('inf'))`` raise ``ValueError`` and would otherwise
        # bubble up through the broad ``except`` and silently fail the post.
        import math
        if not math.isfinite(v):
            return "—"
        # Compact 4-sig-fig rendering; integers print clean.
        if v == int(v) and abs(v) < 1e9:
            return f"{int(v):,}"
        return f"{v:,.2f}"
    if isinstance(v, int):
        return f"{v:,}"
    return str(v)


def _markdown_table(df: pl.DataFrame, cols: list[str]) -> str:
    """Render `df` as a Slack-friendly mrkdwn fixed-width table."""
    if df.is_empty() or not cols:
        return "_No rows._"
    # Compute column widths
    widths = {c: max(len(c), 4) for c in cols}
    rows: list[list[str]] = []
    for r in df.iter_rows(named=True):
        row = []
        for c in cols:
            cell = _format_value(r.get(c))
            row.append(cell)
            widths[c] = max(widths[c], len(cell))
        rows.append(row)
    header = "  ".join(c.ljust(widths[c]) for c in cols)
    sep = "  ".join("-" * widths[c] for c in cols)
    body = "\n".join(
        "  ".join(cell.ljust(widths[c]) for c, cell in zip(cols, row))
        for row in rows
    )
    return "```\n" + header + "\n" + sep + "\n" + body + "\n```"


def _slack_blocks(
    df: pl.DataFrame,
    *,
    title: str,
    cols: list[str],
    footer: str | None,
) -> list[dict]:
    blocks: list[dict] = [
        {"type": "header",
         "text": {"type": "plain_text", "text": title[:150]}},
        {"type": "section",
         "text": {"type": "mrkdwn", "text": _markdown_table(df, cols)}},
    ]
    if footer:
        blocks.append({"type": "context",
                       "elements": [{"type": "mrkdwn", "text": footer}]})
    return blocks


def slack(
    df: pl.DataFrame,
    *,
    webhook_url: str,
    title: str = "nsefast scan",
    top_n: int = 10,
    columns: Iterable[str] | None = None,
    footer: str | None = None,
    timeout: int = REQUEST_TIMEOUT_SECONDS,
) -> bool:
    """Post a Polars DataFrame to a Slack incoming webhook.

    Renders ``top_n`` rows as a fixed-width table inside a Slack block.
    Empty DataFrames post a "no rows" placeholder so cron silence
    doesn't get mistaken for a network failure.
    """
    if not webhook_url:
        log.warning("slack: missing webhook_url")
        return False
    try:
        cols = _select_render_cols(df, columns)
        body = df.head(top_n) if not df.is_empty() else df
        payload = {
            "text": title,                      # plain-text fallback
            "blocks": _slack_blocks(body, title=title, cols=cols, footer=footer),
        }
        resp = requests.post(webhook_url, json=payload, timeout=timeout)
        if resp.status_code >= 300:
            log.warning("slack post failed",
                        extra={"status": resp.status_code,
                               "body": resp.text[:200]})
            return False
        return True
    except Exception as exc:  # noqa: BLE001
        log.warning("slack post error", extra={"err": str(exc)})
        return False


def discord(
    df: pl.DataFrame,
    *,
    webhook_url: str,
    title: str = "nsefast scan",
    top_n: int = 10,
    columns: Iterable[str] | None = None,
    timeout: int = REQUEST_TIMEOUT_SECONDS,
) -> bool:
    """Post a Polars DataFrame to a Discord webhook (embed + code block)."""
    if not webhook_url:
        return False
    try:
        cols = _select_render_cols(df, columns)
        body = df.head(top_n) if not df.is_empty() else df
        payload = {
            "embeds": [{
                "title": title[:256],
                "description": _markdown_table(body, cols)[:4000],
            }],
        }
        resp = requests.post(webhook_url, json=payload, timeout=timeout)
        return resp.status_code < 300
    except Exception as exc:  # noqa: BLE001
        log.warning("discord post error", extra={"err": str(exc)})
        return False


def webhook(
    df: pl.DataFrame,
    *,
    url: str,
    extra: Mapping[str, object] | None = None,
    top_n: int | None = None,
    timeout: int = REQUEST_TIMEOUT_SECONDS,
) -> bool:
    """Post raw JSON ``{rows: [...], extra: {...}}`` to a generic webhook.

    Use this when piping into a custom downstream (Notion ingest,
    n8n, internal Slack bot, etc.). Rows are rendered via Polars
    ``write_json`` for type fidelity.
    """
    if not url:
        return False
    try:
        body = df.head(top_n) if (top_n and not df.is_empty()) else df
        payload = {
            "rows": body.to_dicts(),
            "row_count": int(body.height),
            "extra": dict(extra) if extra else {},
        }
        resp = requests.post(url, json=payload, timeout=timeout)
        return resp.status_code < 300
    except Exception as exc:  # noqa: BLE001
        log.warning("webhook post error", extra={"err": str(exc)})
        return False
