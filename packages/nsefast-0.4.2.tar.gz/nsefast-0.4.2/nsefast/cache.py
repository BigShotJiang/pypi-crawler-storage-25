"""On-disk request cache for repeated NSE fetches.

The cache is a content-addressed store under ``data/cache/<sha>.bin`` with a
sidecar ``<sha>.meta.json`` carrying the URL, status, headers, expiry, and
fetch timestamp.

**Per-collector TTL profiles.** Different NSE datasets have wildly
different freshness needs. A closed-day bhavcopy never changes; a live
index quote moves every second. Use :func:`cached_get` with a
``profile=`` to pick a sensible default, or override with explicit
``ttl_seconds=``::

    cached_get(session, url, profile="bhavcopy_closed")    # 1 year
    cached_get(session, url, profile="live_indices")       # 60 s
    cached_get(session, url, profile="option_chain")       # 30 s
    cached_get(session, url, profile="symbol_master")      # 1 day

Available profiles are exposed via :data:`TTL_PROFILES`. Adding a new
collector? Add its profile to the dict rather than hard-coding a number
at the call site — that way operators can tune TTLs centrally.

Usage::

    from nsefast.cache import cached_get
    resp_bytes = cached_get(session, url, profile="bhavcopy_closed")

The cache is read/write but is *crash-proof*: a corrupt or unreadable cache
entry is silently ignored and refetched. The cache is opt-in — collectors
must explicitly call ``cached_get`` to use it.
"""

from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Mapping

import requests

from nsefast.config import REQUEST_TIMEOUT_SECONDS
from nsefast.logging_setup import get_logger

CACHE_DIR = "data/cache"
DEFAULT_TTL_SECONDS = 300

log = get_logger(__name__)

# ---------- per-collector TTL profiles ----------------------------------------
#
# Keys are stable identifiers cited at call sites; values are seconds.
# Treat this dict as the operator-tunable surface. Operators can override
# any value at runtime via ``set_profile()`` without touching collector
# code.
TTL_PROFILES: dict[str, int] = {
    # ----- archival (immutable once published) -----
    "bhavcopy_closed":  60 * 60 * 24 * 365,    # 1 year — daily bhavcopy is final
    "fo_bhavcopy":      60 * 60 * 24 * 365,    # F&O bhavcopy is final after EOD
    "delivery":         60 * 60 * 24 * 365,    # delivery report is final after EOD
    "report_links":     60 * 60 * 24,          # report index — daily refresh

    # ----- daily-refresh (universe / metadata) -----
    "symbol_master":    60 * 60 * 24,          # equity master — once a day
    "index_constituents": 60 * 60 * 12,        # index members — twice a day
    "trading_holidays": 60 * 60 * 24 * 7,      # holidays calendar — weekly
    "corporate_actions": 60 * 60 * 6,          # split/bonus/dividend feed
    "corporate_announcements": 60 * 60,        # filings — hourly is plenty

    # ----- intraday (medium freshness) -----
    "deals":            60 * 30,               # bulk/block deals — every 30 min
    "surveillance":     60 * 60,               # ASM/GSM/FO-ban — hourly
    "sector_strength":  60 * 5,                # sector performance — 5 min
    "all_indices":      60 * 5,                # full indices snapshot — 5 min

    # ----- live (highest freshness) -----
    "live_indices":     60,                    # nifty/banknifty quote — 60 s
    "option_chain":     30,                    # option chain ticks — 30 s
    "fifty_two_week":   60 * 5,                # 52w H/L — 5 min
    "market_breadth":   60 * 2,                # adv/dec/circuits — 2 min

    # generic fallback — kept for backwards compat with old call sites
    "default":          DEFAULT_TTL_SECONDS,
}


def set_profile(name: str, ttl_seconds: int) -> None:
    """Override or add a TTL profile at runtime. Useful for tests / ops."""
    if ttl_seconds < 0:
        raise ValueError("ttl_seconds must be >= 0")
    TTL_PROFILES[name] = int(ttl_seconds)


def get_profile(name: str) -> int:
    """Lookup a TTL profile by name; falls back to the default if unknown."""
    return TTL_PROFILES.get(name, TTL_PROFILES["default"])


def _key(url: str, params: Mapping[str, str] | None) -> str:
    parts = [url]
    if params:
        for k in sorted(params):
            parts.append(f"{k}={params[k]}")
    return hashlib.sha256("\x1f".join(parts).encode("utf-8")).hexdigest()


def _paths(key: str) -> tuple[Path, Path]:
    base = Path(CACHE_DIR)
    return base / f"{key}.bin", base / f"{key}.meta.json"


def _read_cache(key: str) -> bytes | None:
    body_path, meta_path = _paths(key)
    if not body_path.exists() or not meta_path.exists():
        return None
    try:
        meta = json.loads(meta_path.read_text())
        if meta.get("expires_at", 0) < time.time():
            return None
        if int(meta.get("status", 0)) != 200:
            return None
        return body_path.read_bytes()
    except Exception as exc:  # noqa: BLE001 — never let cache crash a fetch
        log.debug("cache read miss for %s: %s", key, exc)
        return None


def _write_cache(
    key: str, url: str, status: int, body: bytes, ttl_seconds: int,
    profile: str | None = None,
) -> None:
    body_path, meta_path = _paths(key)
    try:
        body_path.parent.mkdir(parents=True, exist_ok=True)
        body_path.write_bytes(body)
        meta_path.write_text(
            json.dumps(
                {
                    "url": url,
                    "status": status,
                    "fetched_at": time.time(),
                    "expires_at": time.time() + ttl_seconds,
                    "size_bytes": len(body),
                    "profile": profile,
                }
            )
        )
    except Exception as exc:  # noqa: BLE001
        log.debug("cache write failed for %s: %s", key, exc)


def cached_get(
    session: requests.Session,
    url: str,
    *,
    params: Mapping[str, str] | None = None,
    ttl_seconds: int | None = None,
    profile: str | None = None,
    timeout: int = REQUEST_TIMEOUT_SECONDS,
) -> bytes | None:
    """Return response body bytes, served from cache when fresh.

    Resolution order for the TTL:

    1. explicit ``ttl_seconds=`` argument (wins, even if 0)
    2. ``profile=`` name looked up in :data:`TTL_PROFILES`
    3. fallback: :data:`DEFAULT_TTL_SECONDS`

    Returns ``None`` on network failure or non-200 responses. Never raises.
    """
    if ttl_seconds is None:
        ttl_seconds = get_profile(profile) if profile else DEFAULT_TTL_SECONDS

    key = _key(url, params)
    cached = _read_cache(key)
    if cached is not None:
        log.debug("cache hit", extra={"url": url, "profile": profile})
        return cached

    try:
        resp = session.get(url, params=params, timeout=timeout)
    except Exception as exc:  # noqa: BLE001
        log.warning("fetch failed", extra={"url": url, "err": str(exc)})
        return None

    if resp.status_code != 200:
        log.warning(
            "non-200", extra={"url": url, "status": resp.status_code}
        )
        return None

    _write_cache(key, url, resp.status_code, resp.content, ttl_seconds, profile)
    return resp.content


def clear_cache() -> int:
    """Delete all cached entries. Returns the number of files removed."""
    base = Path(CACHE_DIR)
    if not base.exists():
        return 0
    count = 0
    for f in base.glob("*"):
        try:
            f.unlink()
            count += 1
        except OSError:
            pass
    return count


def cache_stats() -> dict:
    """Return ``{entries, size_bytes, oldest_age_seconds}``."""
    base = Path(CACHE_DIR)
    if not base.exists():
        return {"entries": 0, "size_bytes": 0, "oldest_age_seconds": 0}
    bin_files = list(base.glob("*.bin"))
    size = sum(f.stat().st_size for f in bin_files)
    now = time.time()
    oldest = max((now - f.stat().st_mtime for f in bin_files), default=0)
    return {
        "entries": len(bin_files),
        "size_bytes": size,
        "oldest_age_seconds": int(oldest),
    }
