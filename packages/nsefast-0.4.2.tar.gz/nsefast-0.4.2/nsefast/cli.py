"""Typer CLI entry point: ``nsefast ...``"""

from __future__ import annotations

import json as _json
import os
import sys
import tempfile
from datetime import date, datetime
from pathlib import Path
from typing import Any

import polars as pl
import typer
from rich import print as rprint

from nsefast import __version__
from nsefast.cache import cache_stats, clear_cache
from nsefast.collectors import (
    calendar as cal,
    corporate,
    deals,
    derivatives,
    equity,
    indices,
    market_breadth,
    master,
    surveillance,
)
from nsefast.collectors.report_links import collect_report_links
from nsefast.logging_setup import get_logger, setup_logging
from nsefast.processing.features import swing_features
from nsefast.processing.normalize import normalize_columns
from nsefast.storage.parquet_store import read_parquet, save_parquet
from nsefast.swing import (
    avoid_list,
    delivery_breakout,
    sector_leaders,
    top_downside,
    top_upside,
    volume_breakout,
)

# NSE bhavcopy columns -> canonical names used by feature helpers.
_BHAV_RENAMES = {
    "tottrdqty": "total_traded_qty",
    "tottrdval": "total_traded_value",
    "open": "open",
    "high": "high",
    "low": "low",
    "close": "close",
}

setup_logging(level="INFO", fmt=os.environ.get("NSEFAST_LOG_FORMAT", "rich"))
log = get_logger(__name__)

app = typer.Typer(help="Fast NSE India data collector.")
collect_app = typer.Typer(help="Run a single collector.")
features_app = typer.Typer(help="Build feature sets.")
export_app = typer.Typer(help="Export data to other formats.")
swing_app = typer.Typer(help="Swing-trading scans (read saved bhavcopy).")
strategy_app = typer.Typer(help="Run swing-trading strategies (EOD signals).")
regime_app = typer.Typer(help="Classify the current market / volatility / breadth regime.")
report_app = typer.Typer(help="Build HTML reports.")
app.add_typer(collect_app, name="collect")
app.add_typer(features_app, name="features")
app.add_typer(export_app, name="export")
app.add_typer(swing_app, name="swing")
app.add_typer(strategy_app, name="strategy")
app.add_typer(regime_app, name="regime")
app.add_typer(report_app, name="report")


# ---- shared output mode --------------------------------------------------

# Global ``--json`` toggles structured output for piping into Slack/email/Notion
# and other downstream tooling. Stored on the Typer context so subcommands
# don't need to declare the option themselves. A module-level mirror keeps
# top-level ``@app.command`` handlers (which run before any subapp callback)
# in sync.
_OUTPUT = {"json": False}


def _is_json(ctx: typer.Context | None = None) -> bool:
    if ctx is not None and ctx.obj and ctx.obj.get("json"):
        return True
    return bool(_OUTPUT.get("json"))


def _emit_df(
    df: pl.DataFrame,
    *,
    title: str = "",
    head: int = 50,
    saved_path: str | os.PathLike | None = None,
    ctx: typer.Context | None = None,
) -> None:
    """Render a DataFrame either as JSON (for piping) or rich text."""
    if _is_json(ctx):
        payload: dict[str, Any] = {
            "title": title,
            "rows": df.head(head).to_dicts() if not df.is_empty() else [],
            "row_count": int(df.height),
        }
        if saved_path is not None:
            payload["saved_path"] = str(saved_path)
        sys.stdout.write(_json.dumps(payload, default=str) + "\n")
        return
    if title:
        rprint(f"[bold]{title}[/bold]")
    if df.is_empty():
        rprint("[yellow]no rows[/yellow]")
    else:
        rprint(df.head(head))
    if saved_path is not None:
        rprint(f"[green]Saved[/green] {saved_path}  rows={df.height}")
    else:
        rprint(f"rows={df.height}")


def _emit_msg(
    msg: str, *, level: str = "info", ctx: typer.Context | None = None,
) -> None:
    if _is_json(ctx):
        sys.stdout.write(_json.dumps({"level": level, "message": msg}) + "\n")
        return
    color = {"error": "red", "warn": "yellow", "info": "green"}.get(level, "")
    if color:
        rprint(f"[{color}]{msg}[/{color}]")
    else:
        rprint(msg)


@app.callback()
def _root_callback(
    ctx: typer.Context,
    json_out: bool = typer.Option(
        False, "--json",
        help="Emit machine-readable JSON instead of rich text "
             "(set globally for any subcommand).",
    ),
) -> None:
    ctx.ensure_object(dict)
    ctx.obj["json"] = json_out
    _OUTPUT["json"] = json_out


def _parse_date(s: str) -> date:
    return datetime.strptime(s, "%Y-%m-%d").date()


# ---- top-level shortcuts -------------------------------------------------

@app.command("collect-reports")
def cmd_collect_reports(ctx: typer.Context) -> None:
    """Discover all downloadable report links from NSE public pages."""
    df = collect_report_links()
    if df.is_empty():
        _emit_msg("No report links found", level="error", ctx=ctx)
        return
    path = save_parquet(df, dataset="report_links")
    _emit_df(df, title="report_links", head=10, saved_path=path, ctx=ctx)


@app.command("collect-all")
def cmd_collect_all(
    ctx: typer.Context,
    date_str: str = typer.Option(None, "--date", help="Trade date YYYY-MM-DD"),
) -> None:
    """Run the full scaffold."""
    _emit_msg("Starting NSE full collection scaffold...", level="warn", ctx=ctx)
    cmd_collect_reports(ctx)
    if date_str:
        cmd_equity_bhavcopy(ctx, date_str)
        cmd_fo_bhavcopy(ctx, date_str)
    _emit_msg("Done", level="info", ctx=ctx)


# ---- collect.<dataset> ---------------------------------------------------

def _save_and_emit(
    ctx: typer.Context, df: pl.DataFrame, *, dataset: str,
    partition: str | None = None, empty_msg: str = "no rows",
) -> None:
    if df.is_empty():
        _emit_msg(empty_msg, level="warn", ctx=ctx)
        return
    path = save_parquet(df, dataset=dataset, partition=partition)
    _emit_df(df, title=dataset, head=10, saved_path=path, ctx=ctx)


@collect_app.command("equity-bhavcopy")
def cmd_equity_bhavcopy(
    ctx: typer.Context, date_str: str = typer.Option(..., "--date"),
) -> None:
    df = equity.daily_bhavcopy(_parse_date(date_str))
    _save_and_emit(ctx, df, dataset="daily_bhavcopy", partition=date_str,
                   empty_msg="No bhavcopy data")


@collect_app.command("fo-bhavcopy")
def cmd_fo_bhavcopy(
    ctx: typer.Context, date_str: str = typer.Option(..., "--date"),
) -> None:
    df = derivatives.fo_bhavcopy(_parse_date(date_str))
    _save_and_emit(ctx, df, dataset="fo_bhavcopy", partition=date_str,
                   empty_msg="No F&O bhavcopy data")


@collect_app.command("delivery")
def cmd_delivery(
    ctx: typer.Context, date_str: str = typer.Option(..., "--date"),
) -> None:
    df = equity.delivery_data(_parse_date(date_str))
    _save_and_emit(ctx, df, dataset="delivery", partition=date_str,
                   empty_msg="No delivery data")


@collect_app.command("symbol-master")
def cmd_symbol_master(ctx: typer.Context) -> None:
    df = master.symbol_master()
    _save_and_emit(ctx, df, dataset="symbol_master",
                   empty_msg="No symbol master data")


@collect_app.command("corporate-announcements")
def cmd_corp_ann(
    ctx: typer.Context,
    start: str = typer.Option(..., "--start"),
    end: str = typer.Option(..., "--end"),
) -> None:
    df = corporate.corporate_announcements(_parse_date(start), _parse_date(end))
    _save_and_emit(ctx, df, dataset="corporate_announcements",
                   partition=f"{start}_{end}",
                   empty_msg="No corporate announcements returned")


@collect_app.command("bulk-deals")
def cmd_bulk_deals(
    ctx: typer.Context,
    start: str = typer.Option(..., "--start"),
    end: str = typer.Option(..., "--end"),
) -> None:
    df = deals.bulk_deals(_parse_date(start), _parse_date(end))
    _save_and_emit(ctx, df, dataset="bulk_deals", partition=f"{start}_{end}",
                   empty_msg="No bulk deals returned")


@collect_app.command("block-deals")
def cmd_block_deals(
    ctx: typer.Context,
    start: str = typer.Option(..., "--start"),
    end: str = typer.Option(..., "--end"),
) -> None:
    df = deals.block_deals(_parse_date(start), _parse_date(end))
    _save_and_emit(ctx, df, dataset="block_deals", partition=f"{start}_{end}",
                   empty_msg="No block deals returned")


@collect_app.command("indices")
def cmd_indices(ctx: typer.Context) -> None:
    df = indices.nifty_50()
    _save_and_emit(ctx, df, dataset="indices",
                   empty_msg="No data (collector is a scaffold)")


@collect_app.command("asm")
def cmd_asm(ctx: typer.Context) -> None:
    df = surveillance.asm_list()
    _save_and_emit(ctx, df, dataset="asm_list",
                   empty_msg="No data (collector is a scaffold)")


@collect_app.command("gsm")
def cmd_gsm(ctx: typer.Context) -> None:
    df = surveillance.gsm_list()
    _save_and_emit(ctx, df, dataset="gsm_list",
                   empty_msg="No data (collector is a scaffold)")


@collect_app.command("fo-ban")
def cmd_fo_ban(ctx: typer.Context) -> None:
    df = surveillance.fo_ban()
    _save_and_emit(ctx, df, dataset="fo_ban",
                   empty_msg="No data (collector is a scaffold)")


@collect_app.command("market-breadth")
def cmd_market_breadth(ctx: typer.Context) -> None:
    """Advances/declines, 52w H/L, circuits, gainers, losers, most active."""
    snap = market_breadth.market_snapshot()
    _save_and_emit(ctx, snap, dataset="market_breadth",
                   empty_msg="No data (market-breadth collectors are scaffolds)")


@collect_app.command("currency-bhavcopy")
def cmd_currency_bhavcopy(
    ctx: typer.Context, date_str: str = typer.Option(..., "--date"),
) -> None:
    df = derivatives.currency_derivatives_bhavcopy(_parse_date(date_str))
    _save_and_emit(ctx, df, dataset="currency_bhavcopy", partition=date_str,
                   empty_msg="No data (collector is a scaffold)")


@collect_app.command("commodity-bhavcopy")
def cmd_commodity_bhavcopy(
    ctx: typer.Context, date_str: str = typer.Option(..., "--date"),
) -> None:
    df = derivatives.commodity_derivatives_bhavcopy(_parse_date(date_str))
    _save_and_emit(ctx, df, dataset="commodity_bhavcopy", partition=date_str,
                   empty_msg="No data (collector is a scaffold)")


@collect_app.command("ird-bhavcopy")
def cmd_ird_bhavcopy(
    ctx: typer.Context, date_str: str = typer.Option(..., "--date"),
) -> None:
    df = derivatives.interest_rate_derivatives_bhavcopy(_parse_date(date_str))
    _save_and_emit(ctx, df, dataset="ird_bhavcopy", partition=date_str,
                   empty_msg="No data (collector is a scaffold)")


@collect_app.command("corporate-actions")
def cmd_corp_actions(
    ctx: typer.Context,
    start: str = typer.Option(..., "--start"),
    end: str = typer.Option(..., "--end"),
) -> None:
    df = corporate.corporate_actions(_parse_date(start), _parse_date(end))
    _save_and_emit(ctx, df, dataset="corporate_actions",
                   partition=f"{start}_{end}",
                   empty_msg="No corporate actions returned")


@collect_app.command("sector-strength")
def cmd_sector_strength(ctx: typer.Context) -> None:
    df = indices.sector_strength()
    _save_and_emit(ctx, df, dataset="sector_strength",
                   empty_msg="No sector strength data returned")


@collect_app.command("all-indices")
def cmd_all_indices(ctx: typer.Context) -> None:
    df = indices.all_indices()
    _save_and_emit(ctx, df, dataset="all_indices",
                   empty_msg="No indices data returned")


@collect_app.command("52w")
def cmd_52w(ctx: typer.Context) -> None:
    df = equity.fifty_two_week_high_low()
    _save_and_emit(ctx, df, dataset="fifty_two_week",
                   empty_msg="No 52-week high/low data returned")


@collect_app.command("option-chain")
def cmd_option_chain(
    ctx: typer.Context,
    symbol: str = typer.Option(..., "--symbol",
                               help="Equity ticker or NIFTY/BANKNIFTY/FINNIFTY"),
) -> None:
    df = derivatives.option_chain(symbol)
    _save_and_emit(ctx, df, dataset="option_chain", partition=symbol.upper(),
                   empty_msg=f"No option chain returned for {symbol!r}")


@collect_app.command("holidays")
def cmd_holidays(ctx: typer.Context) -> None:
    df = cal.trading_holidays()
    _save_and_emit(ctx, df, dataset="trading_holidays",
                   empty_msg="No data (collector is a scaffold)")


# ---- features ------------------------------------------------------------

@features_app.command("swing")
def cmd_features_swing(
    ctx: typer.Context, date_str: str = typer.Option(..., "--date"),
) -> None:
    df = read_parquet(f"daily_bhavcopy/{date_str}")
    if df.is_empty():
        df = read_parquet("daily_bhavcopy")
    if df.is_empty():
        _emit_msg("No source data — run `collect equity-bhavcopy` first",
                  level="error", ctx=ctx)
        return

    df = normalize_columns(df)
    rename_map = {src: dst for src, dst in _BHAV_RENAMES.items() if src in df.columns}
    if rename_map:
        df = df.rename(rename_map)
    if "total_traded_qty" in df.columns and "volume" not in df.columns:
        df = df.with_columns(pl.col("total_traded_qty").alias("volume"))

    out = swing_features(df)
    path = save_parquet(out, dataset="features_swing", partition=date_str)
    _emit_df(out, title="features_swing", head=10, saved_path=path, ctx=ctx)


# ---- swing scans ---------------------------------------------------------

def _load_bhavcopy_for(date_str: str) -> pl.DataFrame:
    """Load + normalize the daily bhavcopy for *exactly* ``date_str``.

    Strict-by-date: previously this fell back to the unpartitioned
    ``daily_bhavcopy`` dataset, which silently mixed all available dates
    into a single ranking — a correctness landmine for EOD cron jobs
    that would emit a "scan for 2026-05-07" containing rows from any
    earlier saved bhavcopy. Now we require the requested partition.
    """
    df = read_parquet(f"daily_bhavcopy/{date_str}")
    if df.is_empty():
        return df
    df = normalize_columns(df)
    rename_map = {src: dst for src, dst in _BHAV_RENAMES.items() if src in df.columns}
    if rename_map:
        df = df.rename(rename_map)
    if "total_traded_qty" in df.columns and "volume" not in df.columns:
        df = df.with_columns(pl.col("total_traded_qty").alias("volume"))
    return df


def _load_optional_parquet(dataset: str) -> pl.DataFrame | None:
    df = read_parquet(dataset)
    return None if df.is_empty() else df


@swing_app.command("top-upside")
def cmd_swing_top_upside(
    ctx: typer.Context,
    date_str: str = typer.Option(..., "--date", help="Trade date YYYY-MM-DD"),
    n: int = typer.Option(25, "--n", help="Number of rows"),
    min_turnover: float = typer.Option(1e7, "--min-turnover"),
    min_price: float = typer.Option(20.0, "--min-price"),
    max_price: float = typer.Option(10000.0, "--max-price"),
) -> None:
    """Top swing-long candidates ranked by composite score."""
    bhav = _load_bhavcopy_for(date_str)
    if bhav.is_empty():
        _emit_msg("No bhavcopy — run `collect equity-bhavcopy --date "
                  f"{date_str}` first", level="error", ctx=ctx)
        return
    out = top_upside(
        bhav, n=n, min_turnover=min_turnover,
        min_price=min_price, max_price=max_price,
        asm_df=_load_optional_parquet("asm_list"),
        gsm_df=_load_optional_parquet("gsm_list"),
        fo_ban_df=_load_optional_parquet("fo_ban"),
    )
    _emit_df(out, title=f"top_upside {date_str} (n={n})", head=n, ctx=ctx)


@swing_app.command("top-downside")
def cmd_swing_top_downside(
    ctx: typer.Context,
    date_str: str = typer.Option(..., "--date"),
    n: int = typer.Option(25, "--n"),
    min_turnover: float = typer.Option(1e7, "--min-turnover"),
    min_price: float = typer.Option(20.0, "--min-price"),
    max_price: float = typer.Option(10000.0, "--max-price"),
) -> None:
    """Weakest swing-short candidates by composite score."""
    bhav = _load_bhavcopy_for(date_str)
    if bhav.is_empty():
        _emit_msg(f"No bhavcopy for {date_str}", level="error", ctx=ctx)
        return
    out = top_downside(
        bhav, n=n, min_turnover=min_turnover,
        min_price=min_price, max_price=max_price,
        asm_df=_load_optional_parquet("asm_list"),
        gsm_df=_load_optional_parquet("gsm_list"),
        fo_ban_df=_load_optional_parquet("fo_ban"),
    )
    _emit_df(out, title=f"top_downside {date_str} (n={n})", head=n, ctx=ctx)


@swing_app.command("avoid")
def cmd_swing_avoid(
    ctx: typer.Context,
    date_str: str = typer.Option(..., "--date"),
    max_volatility_pct: float = typer.Option(15.0, "--max-volatility-pct"),
) -> None:
    """Symbols to avoid: surveillance lists + extreme single-day moves."""
    bhav = _load_bhavcopy_for(date_str)
    if bhav.is_empty():
        _emit_msg(f"No bhavcopy for {date_str}", level="error", ctx=ctx)
        return
    out = avoid_list(
        bhav,
        asm_df=_load_optional_parquet("asm_list"),
        gsm_df=_load_optional_parquet("gsm_list"),
        fo_ban_df=_load_optional_parquet("fo_ban"),
        max_volatility_pct=max_volatility_pct,
    )
    _emit_df(out, title=f"avoid {date_str}", head=200, ctx=ctx)


@swing_app.command("sector-leaders")
def cmd_swing_sector_leaders(
    ctx: typer.Context,
    date_str: str = typer.Option(..., "--date"),
    n_per_sector: int = typer.Option(3, "--n-per-sector"),
) -> None:
    """Top symbols per sector by composite score."""
    bhav = _load_bhavcopy_for(date_str)
    if bhav.is_empty():
        _emit_msg(f"No bhavcopy for {date_str}", level="error", ctx=ctx)
        return
    out = sector_leaders(bhav, n_per_sector=n_per_sector)
    _emit_df(out, title=f"sector_leaders {date_str}", head=200, ctx=ctx)


@swing_app.command("breakouts")
def cmd_swing_breakouts(
    ctx: typer.Context,
    date_str: str = typer.Option(..., "--date"),
    kind: str = typer.Option(
        "volume", "--kind", help="volume | delivery",
    ),
    n: int = typer.Option(25, "--n"),
) -> None:
    """Volume or delivery breakouts on the saved bhavcopy."""
    bhav = _load_bhavcopy_for(date_str)
    if bhav.is_empty():
        _emit_msg(f"No bhavcopy for {date_str}", level="error", ctx=ctx)
        return
    if kind == "volume":
        out = volume_breakout(bhav, n=n)
        title = f"volume_breakout {date_str}"
    elif kind == "delivery":
        out = delivery_breakout(bhav, n=n)
        title = f"delivery_breakout {date_str}"
    else:
        _emit_msg(f"Unknown --kind {kind!r}; use volume|delivery",
                  level="error", ctx=ctx)
        return
    _emit_df(out, title=title, head=n, ctx=ctx)


# ---- export --------------------------------------------------------------

@export_app.command("parquet")
def cmd_export_parquet(
    ctx: typer.Context, dataset: str = typer.Option(..., "--dataset"),
) -> None:
    df = read_parquet(dataset)
    if df.is_empty():
        _emit_msg(f"Dataset {dataset!r} not found", level="error", ctx=ctx)
        return
    _emit_df(df, title=dataset, head=20, ctx=ctx)


# ---- verify --------------------------------------------------------------

@app.command("version")
def cmd_version(ctx: typer.Context) -> None:
    """Print the installed nsefast version."""
    if _is_json(ctx):
        sys.stdout.write(_json.dumps({"version": __version__}) + "\n")
    else:
        rprint(f"nsefast {__version__}")


@app.command("verify")
def cmd_verify(
    ctx: typer.Context,
    network: bool = typer.Option(
        False, "--network", help="Also test a live NSE warm-up + robots.txt fetch"
    ),
) -> None:
    """Smoke-test the install: imports, parquet roundtrip, duckdb, optional network.

    Exits non-zero if any check fails. Run after ``pip install nsefast``.
    """
    failures: list[str] = []
    json_mode = _is_json(ctx)
    results: list[dict[str, Any]] = []

    def _ok(name: str, msg: str) -> None:
        results.append({"check": name, "ok": True, "detail": msg})
        if not json_mode:
            rprint(f"[green]✓[/green] {msg}")

    def _fail(name: str, msg: str) -> None:
        failures.append(msg)
        results.append({"check": name, "ok": False, "detail": msg})
        if not json_mode:
            rprint(f"[red]✗[/red] {msg}")

    if not json_mode:
        rprint(f"[bold]nsefast {__version__}[/bold] — install verification\n")

    try:
        import duckdb, polars, pyarrow, requests, typer  # noqa: F401
        _ok("imports", f"core deps importable "
                       f"(polars {polars.__version__}, duckdb {duckdb.__version__})")
    except Exception as exc:  # noqa: BLE001
        _fail("imports", f"core import failed: {exc}")

    try:
        with tempfile.TemporaryDirectory() as tmp:
            df = pl.DataFrame({"a": [1, 2, 3], "b": ["x", "y", "z"]})
            p = Path(tmp) / "verify.parquet"
            df.write_parquet(p)
            back = pl.read_parquet(p)
            assert back.height == 3
        _ok("parquet", "parquet write/read roundtrip")
    except Exception as exc:  # noqa: BLE001
        _fail("parquet", f"parquet roundtrip failed: {exc}")

    try:
        import duckdb
        v = duckdb.connect(":memory:").execute("SELECT 1+1 AS x").fetchone()
        assert v[0] == 2
        _ok("duckdb", "duckdb in-memory query")
    except Exception as exc:  # noqa: BLE001
        _fail("duckdb", f"duckdb failed: {exc}")

    if not (collect_app and features_app and export_app and swing_app):
        _fail("cli", "CLI subcommands missing")
    else:
        _ok("cli", "CLI subcommands registered "
                   "(collect / features / export / swing / cache / verify)")

    if network:
        try:
            from nsefast.http_client import create_session
            from nsefast.robots import can_fetch
            sess = create_session()
            ok = can_fetch("https://www.nseindia.com/api/allIndices")
            _ok("robots", f"robots.txt fetched (allIndices allowed = {ok})")
            _ok("session", f"HTTP session warmed up: cookies={len(sess.cookies)}")
        except Exception as exc:  # noqa: BLE001
            _fail("network", f"network check failed (often expected from "
                             f"datacenter IPs): {exc}")

    if json_mode:
        sys.stdout.write(_json.dumps({
            "version": __version__,
            "passed": len([r for r in results if r["ok"]]),
            "failed": len(failures),
            "results": results,
        }) + "\n")
    else:
        rprint()
        if failures:
            rprint(f"[red]FAILED[/red] — {len(failures)} check(s) failed")
        else:
            rprint("[green]All checks passed[/green]")
    if failures:
        raise typer.Exit(1)


# ---- cache ---------------------------------------------------------------

cache_app = typer.Typer(help="Inspect / clear the on-disk request cache.")
app.add_typer(cache_app, name="cache")


@cache_app.command("stats")
def cmd_cache_stats(ctx: typer.Context) -> None:
    s = cache_stats()
    if _is_json(ctx):
        sys.stdout.write(_json.dumps(s) + "\n")
        return
    rprint(f"entries: {s['entries']}")
    rprint(f"size:    {s['size_bytes'] / 1024:.1f} KB")
    rprint(f"oldest:  {s['oldest_age_seconds']} s")


@cache_app.command("clear")
def cmd_cache_clear(ctx: typer.Context) -> None:
    n = clear_cache()
    if _is_json(ctx):
        sys.stdout.write(_json.dumps({"removed": n}) + "\n")
        return
    rprint(f"[green]Removed[/green] {n} cache file(s)")


@cache_app.command("profiles")
def cmd_cache_profiles(ctx: typer.Context) -> None:
    """List the per-collector TTL profiles used by ``cached_get``."""
    from nsefast.cache import TTL_PROFILES
    if _is_json(ctx):
        sys.stdout.write(_json.dumps(TTL_PROFILES) + "\n")
        return
    rprint("[bold]TTL profiles (seconds)[/bold]")
    for k in sorted(TTL_PROFILES):
        rprint(f"  {k:<28} {TTL_PROFILES[k]:>10}")


# ---- strategy runner -----------------------------------------------------

def _build_strategy_context() -> dict:
    """Assemble the optional context dict each strategy can consume."""
    return {
        "asm":               _load_optional_parquet("asm_list"),
        "gsm":               _load_optional_parquet("gsm_list"),
        "fo_ban":            _load_optional_parquet("fo_ban"),
        "sector_strength":   _load_optional_parquet("sector_strength"),
        "sector_meta":       _load_optional_parquet("symbol_master"),
        "corporate_actions": _load_optional_parquet("corporate_actions"),
    }


@strategy_app.command("list")
def cmd_strategy_list(ctx: typer.Context) -> None:
    """List every registered strategy id."""
    from nsefast.strategies import REGISTRY
    names = list(REGISTRY.keys())
    if _is_json(ctx):
        sys.stdout.write(_json.dumps({"strategies": names}) + "\n")
        return
    rprint("[bold]Registered strategies[/bold]")
    for n in names:
        rprint(f"  {n}")


@strategy_app.command("run")
def cmd_strategy_run(
    ctx: typer.Context,
    name: str = typer.Argument(
        ..., help="Strategy id (or 'all'). Hyphens accepted."
    ),
    date_str: str = typer.Option(..., "--date", help="Trade date YYYY-MM-DD"),
    persist: bool = typer.Option(
        True, "--persist/--no-persist",
        help="Write signals to data/parquet/strategy_signals/trade_date=.../",
    ),
    head: int = typer.Option(50, "--head", help="Rows shown in pretty output."),
    use_regime: bool = typer.Option(
        False, "--regime/--no-regime",
        help="Filter strategies by current market regime (run_all only).",
    ),
    merge_overlap: bool = typer.Option(
        False, "--merge-overlap/--no-merge-overlap",
        help="Composite-merge signals when multiple strategies fire same trade.",
    ),
) -> None:
    """Run a single strategy or `all` of them, optionally persisting to parquet."""
    from nsefast.strategies import REGISTRY, run_all, run_strategy, save_signals

    bhav = _load_bhavcopy_for(date_str)
    if bhav.is_empty():
        _emit_msg(
            f"No bhavcopy for {date_str} — run "
            f"`nsefast collect equity-bhavcopy --date {date_str}` first",
            level="error", ctx=ctx,
        )
        return

    context = _build_strategy_context()
    key = name.strip().lower().replace("-", "_")
    if key == "all":
        regime = _classify_regime_from_disk(date_str) if use_regime else None
        out = run_all(date_str, bhav, context,
                      regime=regime, merge_overlap=merge_overlap,
                      dedupe=not merge_overlap)
        title = f"signals all_strategies {date_str}"
    elif key in REGISTRY:
        out = run_strategy(key, date_str, bhav, context)
        title = f"signals {key} {date_str}"
    else:
        _emit_msg(
            f"Unknown strategy {name!r}. Try `nsefast strategy list`.",
            level="error", ctx=ctx,
        )
        return

    saved = save_signals(out) if (persist and not out.is_empty()) else None
    _emit_df(out, title=title, head=head, saved_path=saved, ctx=ctx)


# ---- regime --------------------------------------------------------------

def _classify_regime_from_disk(date_str: str):
    from nsefast.regime import classify_regime
    return classify_regime(
        nifty_history=_load_optional_parquet("nifty_history"),
        vix_history=_load_optional_parquet("vix_history"),
        bhav=_load_bhavcopy_for(date_str),
        sector_strength=_load_optional_parquet("sector_strength"),
        fii_dii=_load_optional_parquet("fii_dii"),
        as_of=date_str,
    )


@regime_app.command("show")
def cmd_regime_show(
    ctx: typer.Context,
    date_str: str = typer.Option(..., "--date", help="Trade date YYYY-MM-DD"),
) -> None:
    """Classify market / volatility / breadth regime for a date."""
    r = _classify_regime_from_disk(date_str)
    payload = r.as_dict()
    if _is_json(ctx):
        sys.stdout.write(_json.dumps(payload) + "\n")
        return
    rprint(f"[bold]Regime {date_str}[/bold]")
    rprint(f"  market     : [cyan]{r.market}[/cyan]")
    rprint(f"  volatility : [cyan]{r.volatility}[/cyan]")
    rprint(f"  breadth    : [cyan]{r.breadth}[/cyan]")
    rprint(f"  composite  : [bold green]{r.composite}[/bold green]")
    rprint(f"  confidence : {r.confidence:.0%}")


# ---- report --------------------------------------------------------------

@report_app.command("run")
def cmd_report_run(
    ctx: typer.Context,
    date_str: str = typer.Option(..., "--date", help="Trade date YYYY-MM-DD"),
    out_path: str = typer.Option(
        "report.html", "--out", help="Output HTML file path."
    ),
    use_regime: bool = typer.Option(
        True, "--regime/--no-regime",
        help="Annotate report with classified regime.",
    ),
) -> None:
    """Build a single-page HTML report for a trade date."""
    from nsefast.reporting import write_report
    from nsefast.strategies import run_all, save_signals  # noqa: F401

    bhav = _load_bhavcopy_for(date_str)
    if bhav.is_empty():
        _emit_msg(f"No bhavcopy for {date_str}", level="error", ctx=ctx)
        return
    regime = _classify_regime_from_disk(date_str) if use_regime else None
    signals = run_all(date_str, bhav, _build_strategy_context(), regime=regime)
    out = write_report(
        out_path,
        title=f"nsefast report {date_str}",
        as_of=date_str,
        regime=regime,
        signals=signals,
    )
    _emit_msg(f"wrote {out}", level="info", ctx=ctx)


# ---- doctor --------------------------------------------------------------

@app.command("doctor")
def cmd_doctor(
    ctx: typer.Context,
    skip_network: bool = typer.Option(
        False, "--offline", help="Skip NSE warm-up and robots.txt checks.",
    ),
) -> None:
    """Run environment / install diagnostics and print a health report."""
    from nsefast.doctor import FAIL, OK, WARN, run_diagnostics, summarize
    rows = run_diagnostics(skip_network=skip_network)
    summary = summarize(rows)

    if _is_json(ctx):
        sys.stdout.write(_json.dumps({
            "checks":  [r.to_dict() for r in rows],
            "summary": summary,
        }) + "\n")
        return

    style = {OK: "green", WARN: "yellow", FAIL: "red"}
    glyph = {OK: "✓", WARN: "!", FAIL: "✗"}
    rprint(f"[bold]nsefast doctor[/bold]  v{__version__}")
    for r in rows:
        s = style.get(r.status, "white")
        g = glyph.get(r.status, "?")
        line = f"  [{s}]{g} {r.name:24}[/{s}] {r.detail}"
        rprint(line)
        if r.hint and r.status != OK:
            rprint(f"      [dim]hint: {r.hint}[/dim]")
    rprint(
        f"\nSummary: [green]{summary['ok']} ok[/green]  "
        f"[yellow]{summary['warn']} warn[/yellow]  "
        f"[red]{summary['fail']} fail[/red]  "
        + ("[bold green]healthy[/bold green]"
           if summary["healthy"] else "[bold red]issues found[/bold red]")
    )
    if not summary["healthy"]:
        raise typer.Exit(code=1)


if __name__ == "__main__":
    app()
