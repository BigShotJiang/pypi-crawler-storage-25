"""HTML reporting layer — equity, drawdown, leaderboard, regime context."""
from __future__ import annotations

from nsefast.reporting.charts import (
    drawdown_svg,
    equity_curve_svg,
    sparkline_svg,
)
from nsefast.reporting.html import build_report, write_report

__all__ = [
    "build_report", "write_report",
    "equity_curve_svg", "drawdown_svg", "sparkline_svg",
]
