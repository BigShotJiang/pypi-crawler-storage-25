"""Tiny zero-dependency SVG chart helpers.

Avoids matplotlib / plotly so the report works in any deployment.
Each function takes a ``Sequence[float]`` and returns an inline SVG
string ready to embed in HTML. All return a benign placeholder when
the input is empty so the report still renders.
"""
from __future__ import annotations

from typing import Sequence

_PLACEHOLDER = ('<svg xmlns="http://www.w3.org/2000/svg" width="320" height="60">'
                '<text x="10" y="35" font-family="monospace" font-size="12" '
                'fill="#888">no data</text></svg>')


def _scale(values: Sequence[float], width: int, height: int,
           padding: int = 4) -> list[tuple[float, float]]:
    if not values:
        return []
    vmin = min(values)
    vmax = max(values)
    if vmax == vmin:
        vmax = vmin + 1.0
    xs = [(i / max(1, len(values) - 1)) * (width - 2 * padding) + padding
          for i in range(len(values))]
    ys = [height - padding - ((v - vmin) / (vmax - vmin)) * (height - 2 * padding)
          for v in values]
    return list(zip(xs, ys))


def sparkline_svg(values: Sequence[float], *, width: int = 320, height: int = 60,
                  stroke: str = "#0a7d3a") -> str:
    """A bare polyline sparkline."""
    if not values:
        return _PLACEHOLDER
    pts = _scale(values, width, height)
    path = " ".join(f"{x:.1f},{y:.1f}" for x, y in pts)
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" '
            f'height="{height}" viewBox="0 0 {width} {height}">'
            f'<polyline fill="none" stroke="{stroke}" stroke-width="1.5" '
            f'points="{path}"/></svg>')


def equity_curve_svg(equity: Sequence[float], *, width: int = 640,
                     height: int = 200) -> str:
    """Equity curve with a baseline at the starting value."""
    if not equity:
        return _PLACEHOLDER
    pts = _scale(equity, width, height)
    path = " ".join(f"{x:.1f},{y:.1f}" for x, y in pts)
    start = equity[0]
    end = equity[-1]
    color = "#0a7d3a" if end >= start else "#b3261e"
    base_y = pts[0][1]
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" '
            f'height="{height}" viewBox="0 0 {width} {height}">'
            f'<line x1="0" y1="{base_y:.1f}" x2="{width}" y2="{base_y:.1f}" '
            f'stroke="#ccc" stroke-dasharray="2,2"/>'
            f'<polyline fill="none" stroke="{color}" stroke-width="2" '
            f'points="{path}"/></svg>')


def drawdown_svg(equity: Sequence[float], *, width: int = 640,
                 height: int = 160) -> str:
    """Filled drawdown chart from a running-max series."""
    if not equity:
        return _PLACEHOLDER
    peak = equity[0]
    dd = []
    for v in equity:
        if v > peak:
            peak = v
        dd.append(((v - peak) / peak) * 100.0 if peak != 0 else 0.0)
    pts = _scale(dd, width, height)
    if not pts:
        return _PLACEHOLDER
    # Build a closed path back to the baseline at y=0
    base_y = _scale([min(dd), max(dd, default=0.0), 0.0], width, height)[-1][1]
    path = "M " + " L ".join(f"{x:.1f},{y:.1f}" for x, y in pts)
    path += f" L {pts[-1][0]:.1f},{base_y:.1f} L {pts[0][0]:.1f},{base_y:.1f} Z"
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" '
            f'height="{height}" viewBox="0 0 {width} {height}">'
            f'<path d="{path}" fill="#b3261e" fill-opacity="0.3" '
            f'stroke="#b3261e" stroke-width="1.2"/></svg>')
