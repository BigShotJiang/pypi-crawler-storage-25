"""Self-contained HTML report builder.

The report is a single static HTML file with inline SVG charts and
inline CSS — no JS, no CDN deps, fully shareable.

Sections (each renders only when its input is supplied):

* Header — date, regime composite, regime confidence.
* Equity curve & drawdown — from a list of cumulative equity values.
* Strategy leaderboard — table from a per-strategy results frame.
* Win-rate by regime — table from optional ``regime_breakdown``.
* Open signals — top-N rows from a canonical signal frame.
"""
from __future__ import annotations

from datetime import date
from html import escape
from pathlib import Path
from typing import Any, Sequence

import polars as pl

from nsefast.logging_setup import get_logger
from nsefast.reporting.charts import drawdown_svg, equity_curve_svg

log = get_logger(__name__)


_CSS = """
body { font-family: -apple-system, Segoe UI, Helvetica, Arial, sans-serif;
       margin: 24px; color: #1d1b20; background: #fafafa; }
h1 { margin: 0 0 4px 0; font-size: 22px; }
h2 { margin: 24px 0 8px 0; font-size: 16px; color: #444;
     border-bottom: 1px solid #e0e0e0; padding-bottom: 4px; }
.regime { font-family: monospace; font-size: 13px; color: #555;
          background: #efe; padding: 2px 8px; border-radius: 4px;
          display: inline-block; }
.unknown { background: #eee; color: #777; }
table { border-collapse: collapse; font-size: 13px; margin-top: 8px; }
th, td { padding: 6px 12px; text-align: left;
         border-bottom: 1px solid #e7e7e7; }
th { background: #f3f3f3; font-weight: 600; }
td.num { text-align: right; font-variant-numeric: tabular-nums; }
.sub { color: #777; font-size: 12px; }
.card { background: #fff; padding: 16px; border-radius: 8px;
        box-shadow: 0 1px 2px rgba(0,0,0,0.04); margin-bottom: 16px; }
"""


def _fmt_num(v: Any, dp: int = 2) -> str:
    if v is None:
        return ""
    try:
        f = float(v)
        if f != f:                  # NaN guard
            return ""
        return f"{f:,.{dp}f}"
    except Exception:                # noqa: BLE001
        return escape(str(v))


def _df_to_table(df: pl.DataFrame, *, num_cols: Sequence[str] = (),
                 max_rows: int = 50) -> str:
    if df is None or df.is_empty():
        return '<p class="sub">no rows</p>'
    df = df.head(max_rows)
    head = "".join(f"<th>{escape(c)}</th>" for c in df.columns)
    body = []
    num_set = set(num_cols)
    for row in df.iter_rows(named=True):
        cells = []
        for c in df.columns:
            v = row.get(c)
            if c in num_set:
                cells.append(f'<td class="num">{_fmt_num(v)}</td>')
            else:
                cells.append(f'<td>{escape(str(v)) if v is not None else ""}</td>')
        body.append("<tr>" + "".join(cells) + "</tr>")
    return f"<table><thead><tr>{head}</tr></thead><tbody>{''.join(body)}</tbody></table>"


def build_report(
    *,
    title: str = "nsefast strategy report",
    as_of: date | str | None = None,
    regime: Any = None,                        # nsefast.regime.Regime or dict
    equity_curve: Sequence[float] | None = None,
    leaderboard: pl.DataFrame | None = None,   # per-strategy metrics
    regime_breakdown: pl.DataFrame | None = None,
    signals: pl.DataFrame | None = None,
) -> str:
    """Render a complete HTML report as a single string."""
    try:
        as_of_str = ""
        if as_of is not None:
            as_of_str = as_of.isoformat() if isinstance(as_of, date) else str(as_of)

        # Regime card
        if regime is None:
            regime_html = '<span class="regime unknown">regime: unknown</span>'
        else:
            if hasattr(regime, "composite"):
                composite = regime.composite
                conf = float(regime.confidence)
                known = regime.is_known
            else:
                composite = str(regime.get("composite", "unknown"))
                conf = float(regime.get("confidence", 0.0))
                known = regime.get("market", "unknown") != "unknown"
            klass = "regime" if known else "regime unknown"
            regime_html = (f'<span class="{klass}">{escape(composite)}'
                           f' (conf {conf:.0%})</span>')

        # Equity / drawdown
        if equity_curve:
            chart_html = (
                f'<div class="card"><h2>Equity curve</h2>'
                f'{equity_curve_svg(list(equity_curve))}'
                f'<h2>Drawdown</h2>'
                f'{drawdown_svg(list(equity_curve))}'
                f'</div>'
            )
        else:
            chart_html = ""

        # Leaderboard
        leader_html = ""
        if leaderboard is not None and not leaderboard.is_empty():
            num_cols = [c for c in leaderboard.columns
                        if c not in ("strategy_id", "name", "regime")]
            leader_html = (f'<div class="card"><h2>Strategy leaderboard</h2>'
                           f'{_df_to_table(leaderboard, num_cols=num_cols)}'
                           f'</div>')

        # Regime breakdown
        breakdown_html = ""
        if regime_breakdown is not None and not regime_breakdown.is_empty():
            num_cols = [c for c in regime_breakdown.columns
                        if c not in ("regime", "market", "strategy_id")]
            breakdown_html = (f'<div class="card"><h2>Win-rate by regime</h2>'
                              f'{_df_to_table(regime_breakdown, num_cols=num_cols)}'
                              f'</div>')

        # Signals
        signals_html = ""
        if signals is not None and not signals.is_empty():
            sig_view = signals.select([c for c in signals.columns
                                       if c in ("trade_date", "strategy_id", "symbol",
                                                "direction", "entry", "stop_loss",
                                                "target_1", "confidence_score",
                                                "signal_rank", "sector")])
            num_cols = ["entry", "stop_loss", "target_1", "confidence_score",
                        "signal_rank"]
            signals_html = (f'<div class="card"><h2>Top signals</h2>'
                            f'{_df_to_table(sig_view, num_cols=num_cols, max_rows=25)}'
                            f'</div>')

        return (
            f"<!doctype html><html><head><meta charset='utf-8'>"
            f"<title>{escape(title)}</title><style>{_CSS}</style></head><body>"
            f"<div class='card'><h1>{escape(title)}</h1>"
            f"<div class='sub'>as of {escape(as_of_str)}</div>"
            f"<div style='margin-top:8px'>{regime_html}</div></div>"
            f"{chart_html}{leader_html}{breakdown_html}{signals_html}"
            f"</body></html>"
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("build_report failed: %s", exc)
        return f"<!doctype html><html><body><pre>report failed: {escape(str(exc))}</pre></body></html>"


def write_report(path: str | Path, **kwargs: Any) -> Path:
    """Render and write to disk, returning the resolved Path."""
    out = Path(path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(build_report(**kwargs), encoding="utf-8")
    return out
