"""``nsefast doctor`` — environment / install diagnostics.

Single command that tells a new user (or an existing user diagnosing a
broken install) exactly what's wrong with their environment in one
glance. Inspired by ``brew doctor`` / ``flutter doctor``.

Checks performed
----------------
1.  Python version >= 3.10
2.  Required runtime deps are importable & report their version:
    ``polars``, ``pyarrow``, ``duckdb``, ``requests``, ``typer``, ``rich``.
3.  Optional extras importable: ``sqlalchemy`` + ``psycopg2``, the
    ``nsefast._rust`` PyO3 module, ``hypothesis`` (for users who want
    property tests).
4.  Filesystem: ``data/{raw,parquet}`` directories exist and are writable.
5.  Parquet store: count of partitions found under ``equity_bhavcopy``.
6.  NSE reachability: a one-shot warm-up GET to ``nseindia.com`` with the
    polite session, capturing whether cookies were set.
7.  ``robots.txt`` is fetchable AND allows the bhavcopy URL pattern.

Each check returns a :class:`Check` row with status (``ok`` / ``warn``
/ ``fail``), a one-line message, and an optional remediation hint. The
public entry point :func:`run_diagnostics` returns a list of rows so
the CLI can render either Rich text or JSON.

Crash-proof: every check is individually wrapped — a failure in one
check never aborts the rest.
"""
from __future__ import annotations

import importlib
import os
import platform
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable

from nsefast.logging_setup import get_logger

log = get_logger(__name__)


# Statuses are deliberately printable strings so JSON output is readable.
OK   = "ok"
WARN = "warn"
FAIL = "fail"


@dataclass
class Check:
    name: str
    status: str          # "ok" | "warn" | "fail"
    detail: str          # short human message
    hint: str = ""       # optional remediation

    def to_dict(self) -> dict:
        return asdict(self)


# ---------- individual check helpers -----------------------------------------

def _check_python() -> Check:
    v = sys.version_info
    label = f"Python {v.major}.{v.minor}.{v.micro} on {platform.system()}"
    if v >= (3, 10):
        return Check("python", OK, label)
    return Check(
        "python", FAIL, label,
        hint="nsefast requires Python >= 3.10",
    )


def _check_import(
    name: str, *, required: bool, install_hint: str = "",
) -> Check:
    try:
        mod = importlib.import_module(name)
    except Exception as exc:  # noqa: BLE001
        status = FAIL if required else WARN
        return Check(
            f"import:{name}", status,
            f"not importable ({exc.__class__.__name__})",
            hint=install_hint,
        )
    version = getattr(mod, "__version__", "?")
    return Check(f"import:{name}", OK, f"v{version}")


def _check_storage_paths() -> Check:
    try:
        from nsefast.config import PARQUET_DIR, RAW_DIR
        ok = True
        details = []
        for label, p in (("raw", RAW_DIR), ("parquet", PARQUET_DIR)):
            path = Path(p)
            try:
                path.mkdir(parents=True, exist_ok=True)
                test = path / ".nsefast_doctor_write_check"
                test.write_text("ok")
                test.unlink()
                details.append(f"{label}: {path} (writable)")
            except Exception as exc:  # noqa: BLE001
                ok = False
                details.append(f"{label}: {path} ({exc})")
        return Check(
            "storage", OK if ok else FAIL, "; ".join(details),
            hint="" if ok else "Check disk space and permissions.",
        )
    except Exception as exc:  # noqa: BLE001
        return Check("storage", FAIL, f"could not load paths: {exc}")


def _check_parquet_partitions() -> Check:
    try:
        from nsefast.config import PARQUET_DIR
        root = Path(PARQUET_DIR) / "equity_bhavcopy"
        if not root.exists():
            return Check(
                "equity_bhavcopy", WARN,
                "no equity_bhavcopy data found",
                hint="Run `nsefast collect equity-bhavcopy --date YYYY-MM-DD`.",
            )
        n = sum(1 for _ in root.rglob("*.parquet"))
        return Check(
            "equity_bhavcopy", OK if n else WARN,
            f"{n} parquet partition file(s) under {root}",
            hint="" if n else "Run a collect to populate.",
        )
    except Exception as exc:  # noqa: BLE001
        return Check("equity_bhavcopy", WARN, f"check failed: {exc}")


def _check_nse_reachability() -> Check:
    """Best-effort warm-up against NSE; never blocks longer than a few seconds."""
    try:
        from nsefast.http_client import create_session
        sess = create_session()
        cookies = len(sess.cookies)
        if cookies > 0:
            return Check(
                "nse_warmup", OK,
                f"warm-up cookies set ({cookies})",
            )
        return Check(
            "nse_warmup", WARN,
            "no warm-up cookies returned",
            hint="NSE may be blocking your IP or rate-limiting you.",
        )
    except Exception as exc:  # noqa: BLE001
        return Check(
            "nse_warmup", WARN, f"warm-up failed: {exc}",
            hint="Check internet connectivity / firewall.",
        )


def _check_robots() -> Check:
    try:
        from nsefast.robots import can_fetch
        sample = "https://www.nseindia.com/api/equity-stockIndices?index=NIFTY%2050"
        ok = can_fetch(sample)
        if ok:
            return Check("robots", OK, "robots.txt allows public endpoints")
        return Check(
            "robots", WARN,
            "robots.txt currently disallows the sampled endpoint",
            hint="Some collectors will return empty. This is by design.",
        )
    except Exception as exc:  # noqa: BLE001
        return Check("robots", WARN, f"robots check failed: {exc}")


def _check_postgres_extra() -> Check:
    try:
        importlib.import_module("sqlalchemy")
    except Exception:  # noqa: BLE001
        return Check(
            "extras:postgres", WARN, "sqlalchemy not installed",
            hint="`pip install nsefast[postgres]` to enable Postgres sink.",
        )
    try:
        importlib.import_module("psycopg2")
        return Check("extras:postgres", OK, "sqlalchemy + psycopg2 ready")
    except Exception:  # noqa: BLE001
        return Check(
            "extras:postgres", WARN,
            "sqlalchemy ok but psycopg2 missing",
            hint="`pip install psycopg2-binary` (or full `nsefast[postgres]`).",
        )


def _check_rust_core() -> Check:
    try:
        importlib.import_module("nsefast._rust")
        return Check("extras:rust_core", OK, "PyO3 module loaded")
    except Exception:  # noqa: BLE001
        return Check(
            "extras:rust_core", WARN, "rust core not built (optional)",
            hint="`cd rust-core && maturin develop --release` to enable.",
        )


# ---------- public driver -----------------------------------------------------

# Each entry is (canonical_check_name, callable, is_network).
_CHECKS: tuple[tuple[str, Callable[[], Check], bool], ...] = (
    ("python",                 _check_python,                                       False),
    ("import:polars",          lambda: _check_import("polars",   required=True),   False),
    ("import:pyarrow",         lambda: _check_import("pyarrow",  required=True),   False),
    ("import:duckdb",          lambda: _check_import("duckdb",   required=True),   False),
    ("import:requests",        lambda: _check_import("requests", required=True),   False),
    ("import:typer",           lambda: _check_import("typer",    required=True),   False),
    ("import:rich",            lambda: _check_import("rich",     required=True),   False),
    ("storage",                _check_storage_paths,                                False),
    ("equity_bhavcopy",        _check_parquet_partitions,                           False),
    ("robots",                 _check_robots,                                       True),
    ("nse_warmup",             _check_nse_reachability,                             True),
    ("extras:postgres",        _check_postgres_extra,                               False),
    ("extras:rust_core",       _check_rust_core,                                    False),
)


def run_diagnostics(
    *,
    skip_network: bool = False,
) -> list[Check]:
    """Run every diagnostic check and return the structured results.

    Parameters
    ----------
    skip_network
        If True, skip the NSE warm-up + robots.txt checks. Useful for
        offline environments and CI. Skipped checks still appear in
        the result list with status=OK and detail="skipped (offline mode)".
    """
    results: list[Check] = []
    for name, check_fn, is_network in _CHECKS:
        if skip_network and is_network:
            results.append(Check(name, OK, "skipped (offline mode)"))
            continue
        try:
            row = check_fn()
        except Exception as exc:  # noqa: BLE001
            # Outer safety net so one bad check never sinks the report.
            row = Check(name, FAIL, f"check raised: {exc}")
        results.append(row)
    return results


def summarize(results: list[Check]) -> dict:
    """Roll up checks into ``{ok, warn, fail, healthy}``."""
    counts = {OK: 0, WARN: 0, FAIL: 0}
    for r in results:
        counts[r.status] = counts.get(r.status, 0) + 1
    return {
        "ok":      counts[OK],
        "warn":    counts[WARN],
        "fail":    counts[FAIL],
        "healthy": counts[FAIL] == 0,
    }


__all__ = ["Check", "run_diagnostics", "summarize", "OK", "WARN", "FAIL"]
