"""Market trend classifier — bullish / bearish / sideways from NIFTY.

Pure function over a NIFTY OHLC history frame. The classifier is
intentionally simple and explainable so a discretionary trader can
audit it on a chart in five seconds:

* **bullish** — close > 50-DMA AND 50-DMA > 200-DMA AND 50-DMA slope ≥ 0
  AND 20-bar return > +2 %.
* **bearish** — close < 50-DMA AND 50-DMA < 200-DMA AND 50-DMA slope ≤ 0
  AND 20-bar return < -2 %.
* **sideways** — anything else (chop, transition, low-conviction tape).

When history is too short (< 200 bars) we degrade to the 50/20 stack and
mark ``confidence = 0.5``. Returns a dict with ``regime`` and
``confidence`` keys plus the supporting numerics so the report layer can
render an explanation.
"""
from __future__ import annotations

from datetime import date
from typing import Any

import polars as pl

from nsefast.logging_setup import get_logger

log = get_logger(__name__)

UNKNOWN: dict[str, Any] = {
    "regime": "unknown", "confidence": 0.0,
    "close": None, "sma_20": None, "sma_50": None, "sma_200": None,
    "return_20d_pct": None, "slope_50": None,
}


def _to_date(d: date | str | None) -> date | None:
    if d is None:
        return None
    if isinstance(d, date):
        return d
    try:
        return date.fromisoformat(str(d))
    except Exception:  # noqa: BLE001
        return None


def classify_market(
    nifty_history: pl.DataFrame | None,
    as_of: date | str | None = None,
    *,
    bull_return_pct: float = 2.0,
    bear_return_pct: float = -2.0,
) -> dict[str, Any]:
    """Classify NIFTY trend at ``as_of``.

    ``nifty_history`` is expected to carry ``trade_date`` and ``close``
    columns sorted ascending. Extra columns are ignored. The function
    is fully tolerant of missing/short data and returns
    :data:`UNKNOWN` on any failure path.
    """
    try:
        if nifty_history is None or nifty_history.is_empty():
            return dict(UNKNOWN)
        if "close" not in nifty_history.columns:
            return dict(UNKNOWN)

        df = nifty_history
        if "trade_date" in df.columns:
            df = df.sort("trade_date")
        as_of_d = _to_date(as_of)
        if as_of_d is not None and "trade_date" in df.columns:
            try:
                df = df.filter(pl.col("trade_date") <= as_of_d)
            except Exception:  # noqa: BLE001
                pass
        if df.is_empty():
            return dict(UNKNOWN)

        n = df.height
        close = float(df["close"][-1])
        sma20 = float(df["close"].tail(min(20, n)).mean() or close)
        sma50 = float(df["close"].tail(min(50, n)).mean() or close)
        sma200 = float(df["close"].tail(min(200, n)).mean() or close) if n >= 50 else None
        ret20 = ((close / float(df["close"][max(0, n - 21)])) - 1.0) * 100.0 if n >= 21 else 0.0
        # Slope of last-50 SMA approximated as (sma50_today - sma50_5d_ago)/5
        slope50 = 0.0
        if n >= 55:
            sma50_prev = float(df["close"].tail(55).head(50).mean() or sma50)
            slope50 = (sma50 - sma50_prev) / 5.0

        confidence = 1.0 if n >= 200 else 0.5
        regime = "sideways"
        if sma200 is not None:
            if (close > sma50 > sma200 and slope50 >= 0 and ret20 > bull_return_pct):
                regime = "bullish"
            elif (close < sma50 < sma200 and slope50 <= 0 and ret20 < bear_return_pct):
                regime = "bearish"
        else:
            # Degraded: only 50/20 stack available
            if close > sma50 > sma20 and ret20 > bull_return_pct:
                regime = "bullish"
            elif close < sma50 < sma20 and ret20 < bear_return_pct:
                regime = "bearish"

        return {
            "regime": regime, "confidence": confidence,
            "close": close, "sma_20": sma20, "sma_50": sma50,
            "sma_200": sma200, "return_20d_pct": ret20, "slope_50": slope50,
        }
    except Exception as exc:  # noqa: BLE001
        log.warning("classify_market failed: %s", exc)
        return dict(UNKNOWN)
