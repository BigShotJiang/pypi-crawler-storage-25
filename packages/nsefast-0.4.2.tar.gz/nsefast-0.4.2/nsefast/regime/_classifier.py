"""Composite regime — single object combining market + vol + breadth."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Any

import polars as pl

from nsefast.logging_setup import get_logger
from nsefast.regime.breadth_regime import classify_breadth
from nsefast.regime.market_regime import classify_market
from nsefast.regime.volatility_regime import classify_volatility

log = get_logger(__name__)


@dataclass(frozen=True)
class Regime:
    """A point-in-time market regime classification.

    Composite string is ``f"{market}_{volatility}_vol_{breadth}"`` — e.g.
    ``"bullish_low_vol_risk_on"``. Use :meth:`as_dict` for JSON / parquet.
    """
    market: str = "unknown"          # bullish | bearish | sideways | unknown
    volatility: str = "unknown"      # high | normal | low | unknown
    breadth: str = "unknown"         # risk_on | neutral | risk_off | unknown
    confidence: float = 0.0
    as_of: date | None = None
    details: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def unknown(cls) -> "Regime":
        return cls()

    @property
    def composite(self) -> str:
        return f"{self.market}_{self.volatility}_vol_{self.breadth}"

    @property
    def is_known(self) -> bool:
        return self.market != "unknown"

    def allows(self, allowed: list[str] | tuple[str, ...] | None) -> bool:
        """True when this regime's market label is in ``allowed``.

        ``None`` / empty means "no filter" — always True. The unknown
        market label always passes (we never block on a missing input).
        """
        if not allowed:
            return True
        if self.market == "unknown":
            return True
        return self.market in tuple(allowed)

    def as_dict(self) -> dict[str, Any]:
        return {
            "market": self.market, "volatility": self.volatility,
            "breadth": self.breadth, "composite": self.composite,
            "confidence": self.confidence,
            "as_of": self.as_of.isoformat() if self.as_of else None,
            "details": self.details,
        }


def classify_regime(
    nifty_history: pl.DataFrame | None = None,
    vix_history: pl.DataFrame | None = None,
    bhav: pl.DataFrame | None = None,
    sector_strength: pl.DataFrame | None = None,
    fii_dii: pl.DataFrame | None = None,
    *,
    as_of: date | str | None = None,
) -> Regime:
    """Build a :class:`Regime` from whatever inputs are available.

    Every input is optional. Missing inputs degrade the corresponding
    sub-classifier to ``"unknown"`` rather than raising. The resulting
    :class:`Regime` is always safe to consume.
    """
    try:
        m = classify_market(nifty_history, as_of=as_of)
        v = classify_volatility(vix_history, nifty_history, as_of=as_of)
        b = classify_breadth(bhav, sector_strength, fii_dii)

        # Composite confidence = mean of the three sub-confidences, but
        # ignore any sub that came back unknown (its confidence is 0).
        confs = [c for c in (m["confidence"], v["confidence"], b["confidence"]) if c > 0]
        composite_conf = sum(confs) / len(confs) if confs else 0.0

        as_of_d: date | None
        if isinstance(as_of, date):
            as_of_d = as_of
        elif isinstance(as_of, str):
            try:
                as_of_d = date.fromisoformat(as_of)
            except Exception:  # noqa: BLE001
                as_of_d = None
        else:
            as_of_d = None

        return Regime(
            market=m["regime"], volatility=v["regime"], breadth=b["regime"],
            confidence=composite_conf, as_of=as_of_d,
            details={"market": m, "volatility": v, "breadth": b},
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("classify_regime failed: %s", exc)
        return Regime.unknown()
