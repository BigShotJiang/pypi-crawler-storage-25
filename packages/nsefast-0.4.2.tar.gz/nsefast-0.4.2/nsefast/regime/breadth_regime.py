"""Breadth & flow regime — risk_on / neutral / risk_off.

Combines up to four breadth proxies into a single -1..+1 score:

* **Advances/declines ratio** — (#advances - #declines) / total.
* **Sector breadth** — fraction of indices closing positive.
* **Delivery trend** — mean delivery_pct vs trailing window.
* **FII/DII net** — net cash equity flow in ₹ crore (sign matters,
  magnitude normalised by trailing 20-bar abs mean).

Each available signal contributes equally to the composite score, then
we threshold at ±0.25 to pick a regime label.
"""
from __future__ import annotations

from typing import Any

import polars as pl

from nsefast.logging_setup import get_logger

log = get_logger(__name__)

UNKNOWN: dict[str, Any] = {
    "regime": "unknown", "confidence": 0.0,
    "score": None, "components": {}, "n_signals": 0,
}


def _ad_score(bhav: pl.DataFrame | None) -> float | None:
    if bhav is None or bhav.is_empty():
        return None
    if "percent_change" not in bhav.columns:
        return None
    pc = bhav["percent_change"].cast(pl.Float64, strict=False).fill_nan(None).drop_nulls()
    n = pc.len()
    if n < 10:
        return None
    adv = int((pc > 0).sum())
    dec = int((pc < 0).sum())
    total = adv + dec
    if total == 0:
        return None
    return (adv - dec) / total  # -1..+1


def _sector_score(sector_strength: pl.DataFrame | None) -> float | None:
    if sector_strength is None or sector_strength.is_empty():
        return None
    if "percent_change" not in sector_strength.columns:
        return None
    pc = sector_strength["percent_change"].cast(pl.Float64, strict=False).fill_nan(None).drop_nulls()
    if pc.len() == 0:
        return None
    pos = int((pc > 0).sum())
    return (2.0 * pos / pc.len()) - 1.0  # 1=all green, -1=all red


def _delivery_score(bhav: pl.DataFrame | None, baseline: float = 45.0) -> float | None:
    if bhav is None or bhav.is_empty():
        return None
    if "delivery_pct" not in bhav.columns:
        return None
    d = bhav["delivery_pct"].cast(pl.Float64, strict=False).fill_nan(None).drop_nulls()
    if d.len() < 10:
        return None
    mean_d = float(d.mean())
    # Map (baseline-15) .. (baseline+15) → -1..+1
    return max(-1.0, min(1.0, (mean_d - baseline) / 15.0))


def _flow_score(fii_dii: pl.DataFrame | None) -> float | None:
    if fii_dii is None or fii_dii.is_empty():
        return None
    if "net" not in fii_dii.columns:
        return None
    df = fii_dii.sort("trade_date") if "trade_date" in fii_dii.columns else fii_dii
    series = df["net"].cast(pl.Float64, strict=False).fill_nan(None).drop_nulls()
    if series.len() == 0:
        return None
    cur = float(series[-1])
    window = series.tail(min(20, series.len()))
    abs_mean = float(window.abs().mean() or 1.0)
    if abs_mean <= 0.0:
        return 0.0
    return max(-1.0, min(1.0, cur / abs_mean))


def classify_breadth(
    bhav: pl.DataFrame | None = None,
    sector_strength: pl.DataFrame | None = None,
    fii_dii: pl.DataFrame | None = None,
    *,
    risk_on_threshold: float = 0.25,
    risk_off_threshold: float = -0.25,
    delivery_baseline: float = 45.0,
) -> dict[str, Any]:
    """Aggregate breadth proxies into a single regime label."""
    try:
        components: dict[str, float] = {}
        ad = _ad_score(bhav)
        if ad is not None:
            components["adv_decl"] = ad
        sec = _sector_score(sector_strength)
        if sec is not None:
            components["sector_breadth"] = sec
        deliv = _delivery_score(bhav, delivery_baseline)
        if deliv is not None:
            components["delivery"] = deliv
        flow = _flow_score(fii_dii)
        if flow is not None:
            components["fii_dii"] = flow

        if not components:
            return dict(UNKNOWN)
        score = sum(components.values()) / len(components)
        if score >= risk_on_threshold:
            regime = "risk_on"
        elif score <= risk_off_threshold:
            regime = "risk_off"
        else:
            regime = "neutral"
        return {
            "regime": regime,
            "confidence": min(1.0, len(components) / 4.0),
            "score": score, "components": components,
            "n_signals": len(components),
        }
    except Exception as exc:  # noqa: BLE001
        log.warning("classify_breadth failed: %s", exc)
        return dict(UNKNOWN)
