"""Volatility regime — high / normal / low.

Primary input is INDIA VIX. We classify the latest VIX vs its trailing
percentile distribution:

* **high** — current VIX ≥ 80th percentile of the trailing 252 bars.
* **low**  — current VIX ≤ 20th percentile.
* **normal** — anywhere in between.

If VIX history is missing we fall back to NIFTY realised volatility
(annualised stdev of daily returns over the last 21 bars) and apply the
same percentile logic over its own trailing window.
"""
from __future__ import annotations

from datetime import date
from typing import Any

import polars as pl

from nsefast.logging_setup import get_logger

log = get_logger(__name__)

UNKNOWN: dict[str, Any] = {
    "regime": "unknown", "confidence": 0.0,
    "value": None, "p20": None, "p80": None, "source": None,
}


def _percentile(series: pl.Series, q: float) -> float | None:
    try:
        return float(series.drop_nulls().quantile(q))
    except Exception:  # noqa: BLE001
        return None


def _from_vix(vix: pl.DataFrame, hi_q: float, lo_q: float) -> dict[str, Any] | None:
    if vix is None or vix.is_empty() or "close" not in vix.columns:
        return None
    df = vix.sort("trade_date") if "trade_date" in vix.columns else vix
    series = df["close"].cast(pl.Float64, strict=False).fill_nan(None)
    if series.drop_nulls().len() < 20:
        return None
    window = series.tail(min(252, series.len()))
    p_hi = _percentile(window, hi_q)
    p_lo = _percentile(window, lo_q)
    cur = float(series.drop_nulls()[-1])
    if p_hi is None or p_lo is None:
        return None
    if cur >= p_hi:
        regime = "high"
    elif cur <= p_lo:
        regime = "low"
    else:
        regime = "normal"
    return {
        "regime": regime, "confidence": 1.0,
        "value": cur, "p20": p_lo, "p80": p_hi, "source": "vix",
    }


def _from_nifty_realised(nifty: pl.DataFrame, hi_q: float, lo_q: float) -> dict[str, Any] | None:
    if nifty is None or nifty.is_empty() or "close" not in nifty.columns:
        return None
    df = nifty.sort("trade_date") if "trade_date" in nifty.columns else nifty
    if df.height < 30:
        return None
    rets = (df["close"].cast(pl.Float64, strict=False).pct_change()
              .fill_nan(None).drop_nulls())
    # Rolling 21-bar realised vol annualised (×sqrt(252))
    if rets.len() < 21:
        return None
    series = rets.rolling_std(window_size=21) * (252 ** 0.5) * 100.0
    series = series.fill_nan(None).drop_nulls()
    if series.len() < 20:
        return None
    window = series.tail(min(252, series.len()))
    p_hi = _percentile(window, hi_q)
    p_lo = _percentile(window, lo_q)
    cur = float(series[-1])
    if p_hi is None or p_lo is None:
        return None
    if cur >= p_hi:
        regime = "high"
    elif cur <= p_lo:
        regime = "low"
    else:
        regime = "normal"
    return {
        "regime": regime, "confidence": 0.6,
        "value": cur, "p20": p_lo, "p80": p_hi, "source": "nifty_realised",
    }


def classify_volatility(
    vix_history: pl.DataFrame | None = None,
    nifty_history: pl.DataFrame | None = None,
    *,
    hi_q: float = 0.80,
    lo_q: float = 0.20,
    as_of: date | str | None = None,  # noqa: ARG001 — accepted for API symmetry
) -> dict[str, Any]:
    """Classify volatility regime from VIX (preferred) or realised NIFTY vol."""
    try:
        out = _from_vix(vix_history, hi_q, lo_q)
        if out is not None:
            return out
        out = _from_nifty_realised(nifty_history, hi_q, lo_q)
        if out is not None:
            return out
        return dict(UNKNOWN)
    except Exception as exc:  # noqa: BLE001
        log.warning("classify_volatility failed: %s", exc)
        return dict(UNKNOWN)
