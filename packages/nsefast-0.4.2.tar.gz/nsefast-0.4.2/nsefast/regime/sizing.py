"""Regime-aware dynamic position sizing.

Each regime maps to three multipliers:

* ``capital`` — fraction of base capital we deploy (0..1).
* ``risk`` — fraction of base risk-per-trade we allow.
* ``stop`` — multiplier applied to the per-trade stop *distance* (so
  stop_loss moves further from entry in risk-off / high-vol tapes).

These factors compound so a high-vol risk-off bullish tape sizes much
smaller than a low-vol risk-on bullish tape, even though both are
labelled bullish. Pass through the registry; missing labels resolve to
the conservative default.
"""
from __future__ import annotations

from typing import Any

import polars as pl

from nsefast.logging_setup import get_logger

log = get_logger(__name__)


# (market, volatility, breadth) -> (capital, risk, stop_distance)
REGIME_SIZING: dict[tuple[str, str, str], dict[str, float]] = {
    # Best tape — risk-on, low vol, uptrend
    ("bullish", "low",    "risk_on"):  {"capital": 1.00, "risk": 1.00, "stop": 1.00},
    ("bullish", "normal", "risk_on"):  {"capital": 0.90, "risk": 0.90, "stop": 1.00},
    ("bullish", "high",   "risk_on"):  {"capital": 0.65, "risk": 0.75, "stop": 1.30},
    ("bullish", "low",    "neutral"):  {"capital": 0.85, "risk": 0.90, "stop": 1.00},
    ("bullish", "normal", "neutral"):  {"capital": 0.75, "risk": 0.85, "stop": 1.10},
    ("bullish", "high",   "neutral"):  {"capital": 0.50, "risk": 0.65, "stop": 1.40},
    ("bullish", "low",    "risk_off"): {"capital": 0.60, "risk": 0.65, "stop": 1.20},
    ("bullish", "normal", "risk_off"): {"capital": 0.45, "risk": 0.55, "stop": 1.30},
    ("bullish", "high",   "risk_off"): {"capital": 0.25, "risk": 0.40, "stop": 1.50},
    # Sideways — defensive
    ("sideways", "low",    "risk_on"):  {"capital": 0.60, "risk": 0.70, "stop": 1.10},
    ("sideways", "normal", "risk_on"):  {"capital": 0.50, "risk": 0.60, "stop": 1.20},
    ("sideways", "high",   "risk_on"):  {"capital": 0.30, "risk": 0.45, "stop": 1.40},
    ("sideways", "low",    "neutral"):  {"capital": 0.50, "risk": 0.60, "stop": 1.20},
    ("sideways", "normal", "neutral"):  {"capital": 0.40, "risk": 0.55, "stop": 1.25},
    ("sideways", "high",   "neutral"):  {"capital": 0.20, "risk": 0.35, "stop": 1.50},
    ("sideways", "low",    "risk_off"): {"capital": 0.30, "risk": 0.45, "stop": 1.30},
    ("sideways", "normal", "risk_off"): {"capital": 0.20, "risk": 0.35, "stop": 1.50},
    ("sideways", "high",   "risk_off"): {"capital": 0.10, "risk": 0.25, "stop": 1.70},
    # Bearish — minimum exposure on the long side
    ("bearish", "low",    "risk_on"):  {"capital": 0.30, "risk": 0.45, "stop": 1.30},
    ("bearish", "normal", "risk_on"):  {"capital": 0.20, "risk": 0.35, "stop": 1.40},
    ("bearish", "high",   "risk_on"):  {"capital": 0.10, "risk": 0.25, "stop": 1.60},
    ("bearish", "low",    "neutral"):  {"capital": 0.20, "risk": 0.35, "stop": 1.40},
    ("bearish", "normal", "neutral"):  {"capital": 0.15, "risk": 0.30, "stop": 1.50},
    ("bearish", "high",   "neutral"):  {"capital": 0.05, "risk": 0.20, "stop": 1.80},
    ("bearish", "low",    "risk_off"): {"capital": 0.10, "risk": 0.25, "stop": 1.60},
    ("bearish", "normal", "risk_off"): {"capital": 0.05, "risk": 0.20, "stop": 1.80},
    ("bearish", "high",   "risk_off"): {"capital": 0.00, "risk": 0.00, "stop": 2.00},
}

DEFAULT_FACTORS = {"capital": 0.50, "risk": 0.50, "stop": 1.20}


def regime_sizing_factors(regime: Any) -> dict[str, float]:
    """Return the (capital, risk, stop) multipliers for ``regime``.

    Accepts either a :class:`~nsefast.regime.Regime` or a plain dict
    with ``market`` / ``volatility`` / ``breadth`` keys. Unknown or
    missing labels return :data:`DEFAULT_FACTORS`.
    """
    try:
        if regime is None:
            return dict(DEFAULT_FACTORS)
        if hasattr(regime, "market"):
            key = (regime.market, regime.volatility, regime.breadth)
        elif isinstance(regime, dict):
            key = (regime.get("market", "unknown"),
                   regime.get("volatility", "unknown"),
                   regime.get("breadth", "unknown"))
        else:
            return dict(DEFAULT_FACTORS)
        return dict(REGIME_SIZING.get(key, DEFAULT_FACTORS))
    except Exception as exc:  # noqa: BLE001
        log.warning("regime_sizing_factors failed: %s", exc)
        return dict(DEFAULT_FACTORS)


def apply_regime_sizing(
    signals: pl.DataFrame,
    regime: Any,
    *,
    base_capital: float = 100_000.0,
    base_risk_pct: float = 1.0,
) -> pl.DataFrame:
    """Adjust each signal's stop_loss and attach ``qty`` / ``risk_rs``.

    Adds three columns to a canonical signal frame:

    * ``regime_capital`` — adjusted capital actually deployed.
    * ``risk_rs`` — adjusted ₹ risk per trade.
    * ``qty`` — integer share count = floor(risk_rs / |entry-stop_adj|).

    The ``stop_loss`` column is widened (long: pushed lower; short:
    pushed higher) by ``stop`` × the original |entry-stop| distance so
    a high-vol tape gives positions more room to breathe. Crash-proof:
    on any failure returns ``signals`` unchanged.
    """
    if signals is None or signals.is_empty():
        return signals if signals is not None else pl.DataFrame()
    try:
        f = regime_sizing_factors(regime)
        capital = max(0.0, float(base_capital) * float(f["capital"]))
        risk_rs = max(0.0, capital * (float(base_risk_pct) / 100.0))
        stop_mult = max(0.5, float(f["stop"]))

        entry = pl.col("entry").cast(pl.Float64, strict=False)
        stop = pl.col("stop_loss").cast(pl.Float64, strict=False)
        # Widen the stop in the direction of the trade
        diff = (entry - stop).abs() * stop_mult
        adj_stop = pl.when(pl.col("direction") == "long") \
                     .then(entry - diff) \
                     .otherwise(entry + diff)
        risk_per_share = (entry - adj_stop).abs()
        qty = pl.when(risk_per_share > 0) \
                .then((pl.lit(risk_rs) / risk_per_share).floor().cast(pl.Int64, strict=False)) \
                .otherwise(pl.lit(0, dtype=pl.Int64))
        return signals.with_columns([
            adj_stop.alias("stop_loss"),
            qty.alias("qty"),
            pl.lit(risk_rs, dtype=pl.Float64).alias("risk_rs"),
            pl.lit(capital, dtype=pl.Float64).alias("regime_capital"),
        ])
    except Exception as exc:  # noqa: BLE001
        log.warning("apply_regime_sizing failed: %s", exc)
        return signals
