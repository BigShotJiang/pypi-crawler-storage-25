"""Live market regime classification layer.

Combines four orthogonal signals into a composite regime tuple:

* **Market regime** (``bullish`` / ``bearish`` / ``sideways``) — trend
  classification driven primarily by NIFTY moving-average stack.
* **Volatility regime** (``high`` / ``normal`` / ``low``) — INDIA VIX
  percentile vs trailing window, with a NIFTY-realised-vol fallback when
  VIX history is missing.
* **Breadth regime** (``risk_on`` / ``neutral`` / ``risk_off``) —
  advances/declines, sector breadth, delivery trend, and FII/DII flows.
* **Composite** — single underscore-joined string e.g.
  ``bullish_low_vol_risk_on`` for filter wiring.

All public functions return a populated :class:`Regime` dataclass. On
failure they return :class:`Regime.unknown()` rather than raising — this
matches the rest of nsefast's never-crash contract so a missing input
file never silently breaks a live trading workflow.
"""
from __future__ import annotations

from nsefast.regime._classifier import Regime, classify_regime
from nsefast.regime.breadth_regime import classify_breadth
from nsefast.regime.market_regime import classify_market
from nsefast.regime.sizing import (
    REGIME_SIZING,
    apply_regime_sizing,
    regime_sizing_factors,
)
from nsefast.regime.volatility_regime import classify_volatility

__all__ = [
    "Regime",
    "classify_regime",
    "classify_market",
    "classify_volatility",
    "classify_breadth",
    "REGIME_SIZING",
    "apply_regime_sizing",
    "regime_sizing_factors",
]
