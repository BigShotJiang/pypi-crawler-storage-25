"""Multi-day historical OHLCV loader.

Reads from hive-partitioned parquet under ``data/parquet/<dataset>`` and
returns a long-format Polars DataFrame: one row per ``(symbol, trade_date)``.

Convention used by the rest of the library:

- Default dataset name: ``equity_bhavcopy``
- Canonical lowercase columns: ``symbol, series, trade_date, open, high, low,
  close, prev_close, volume, turnover``. NSE's uppercase columns
  (``SYMBOL``, ``OPEN``, ``CLOSE``, ``TOTTRDQTY``, ``TOTTRDVAL``,
  ``TIMESTAMP``) are rewritten to this canonical form.

All functions return canonical empty DataFrames on failure — they never
raise. Use :func:`save_bhavcopy` to write a single day into the partitioned
store, or just persist your own way and pass ``dataset=...``.
"""

from __future__ import annotations

from datetime import date, datetime
from pathlib import Path
from typing import Iterable

import polars as pl

from nsefast.config import PARQUET_DIR
from nsefast.logging_setup import get_logger
from nsefast.storage.parquet_store import (
    derive_date_partitions,
    read_parquet_partitioned,
    save_parquet_partitioned,
)

log = get_logger(__name__)


CANONICAL_COLUMNS = [
    "symbol", "series", "trade_date",
    "open", "high", "low", "close", "prev_close",
    "volume", "turnover",
]

CANONICAL_SCHEMA: dict[str, pl.DataType] = {
    "symbol":     pl.Utf8,
    "series":     pl.Utf8,
    "trade_date": pl.Date,
    "open":       pl.Float64,
    "high":       pl.Float64,
    "low":        pl.Float64,
    "close":      pl.Float64,
    "prev_close": pl.Float64,
    "volume":     pl.Float64,
    "turnover":   pl.Float64,
}


# Aliases from raw NSE bhavcopy CSV headers to canonical lowercase columns.
_RAW_TO_CANONICAL = {
    # Legacy NSE bhavcopy headers (pre-July-2024).
    "SYMBOL":     "symbol",
    "SERIES":     "series",
    "TIMESTAMP":  "trade_date",
    "DATE":       "trade_date",
    "OPEN":       "open",
    "HIGH":       "high",
    "LOW":        "low",
    "CLOSE":      "close",
    "PREVCLOSE":  "prev_close",
    "TOTTRDQTY":  "volume",
    "TOTTRDVAL":  "turnover",
    # New BhavCopy headers — mapped here as a defensive fallback in case
    # raw new-schema files reach the normaliser without going through
    # ``collectors.equity._parse_bhavcopy_zip`` first.
    "TCKRSYMB":     "symbol",
    "SCTYSRS":      "series",
    "TRADDT":       "trade_date",
    "OPNPRIC":      "open",
    "HGHPRIC":      "high",
    "LWPRIC":       "low",
    "CLSPRIC":      "close",
    "PRVSCLSGPRIC": "prev_close",
    "TTLTRADGVOL":  "volume",
    "TTLTRFVAL":    "turnover",
}


def _empty() -> pl.DataFrame:
    return pl.DataFrame(schema=CANONICAL_SCHEMA)


def _to_date(d: date | str) -> date | None:
    try:
        if isinstance(d, str):
            return datetime.strptime(d, "%Y-%m-%d").date()
        return d
    except Exception as exc:  # noqa: BLE001
        log.warning("invalid date %r: %s", d, exc)
        return None


def normalize_bhavcopy(df: pl.DataFrame, *, trade_date: date | None = None) -> pl.DataFrame:
    """Rewrite a raw NSE bhavcopy DataFrame to the canonical schema.

    Unknown columns are kept; canonical columns are coerced to the right
    dtype. ``trade_date`` is filled from the argument when the source has no
    date column. Empty / malformed input → canonical empty DataFrame.
    """
    if df is None or df.is_empty():
        return _empty()
    try:
        # Strip whitespace some NSE files leave on header names.
        rename_map = {c: _RAW_TO_CANONICAL.get(c.strip().upper(), c.strip().lower())
                      for c in df.columns}
        out = df.rename(rename_map)

        if "trade_date" not in out.columns and trade_date is not None:
            out = out.with_columns(pl.lit(trade_date).alias("trade_date"))

        casts: list[pl.Expr] = []
        for col, dtype in CANONICAL_SCHEMA.items():
            if col not in out.columns:
                continue
            if dtype == pl.Date:
                casts.append(
                    pl.col(col).cast(pl.Utf8, strict=False)
                    .str.strptime(pl.Date, format=None, strict=False)
                    .alias(col)
                )
            else:
                casts.append(pl.col(col).cast(dtype, strict=False).alias(col))
        if casts:
            out = out.with_columns(casts)

        # Fill missing canonical columns with nulls so the schema is stable.
        for col, dtype in CANONICAL_SCHEMA.items():
            if col not in out.columns:
                out = out.with_columns(pl.lit(None, dtype=dtype).alias(col))
        keep = list(CANONICAL_SCHEMA) + [c for c in out.columns if c not in CANONICAL_SCHEMA]
        return out.select(keep)
    except Exception as exc:  # noqa: BLE001
        log.warning("normalize_bhavcopy failed: %s", exc)
        return _empty()


def save_bhavcopy(
    df: pl.DataFrame,
    *,
    trade_date: date | str | None = None,
    dataset: str = "equity_bhavcopy",
) -> str:
    """Persist a single day's bhavcopy into the hive-partitioned store.

    The DataFrame is normalised first, then partitioned by ``year/month``.
    Returns the dataset directory path; logs and skips empty frames.
    """
    td = _to_date(trade_date) if trade_date is not None else None
    norm = normalize_bhavcopy(df, trade_date=td)
    if norm.is_empty():
        log.info("save_bhavcopy: empty frame, nothing to write", extra={"date": str(td)})
        return str(Path(PARQUET_DIR) / dataset)
    try:
        with_parts = derive_date_partitions(norm, "trade_date", parts=("year", "month"))
        return save_parquet_partitioned(with_parts, dataset, by=["year", "month"])
    except Exception as exc:  # noqa: BLE001
        log.warning("save_bhavcopy failed: %s", exc)
        return str(Path(PARQUET_DIR) / dataset)


def load_range(
    start: date | str,
    end: date | str,
    *,
    symbols: Iterable[str] | None = None,
    series: str | tuple[str, ...] | None = "EQ",
    dataset: str = "equity_bhavcopy",
) -> pl.DataFrame:
    """Long-format OHLCV history for ``[start, end]`` (inclusive).

    Reads the hive-partitioned parquet at ``data/parquet/<dataset>``, then
    filters by date / symbol / series. ``symbols=None`` returns the full
    universe; ``series=None`` skips the series filter.

    Returns one row per ``(symbol, trade_date)`` with columns from
    :data:`CANONICAL_COLUMNS`. Empty DataFrame when the dataset is missing,
    the range is empty, or any error occurs.
    """
    s, e = _to_date(start), _to_date(end)
    if s is None or e is None or s > e:
        return _empty()

    try:
        # Push down year/month bounds to skip irrelevant partitions.
        filters: list[tuple[str, str, object]] = [
            ("year", ">=", s.year), ("year", "<=", e.year),
        ]
        if s.year == e.year:
            filters += [("month", ">=", s.month), ("month", "<=", e.month)]

        df = read_parquet_partitioned(dataset, filters=filters)
        if df.is_empty():
            log.info("load_range: no data in %s..%s", s, e)
            return _empty()

        df = normalize_bhavcopy(df)

        df = df.filter(
            (pl.col("trade_date") >= s) & (pl.col("trade_date") <= e)
        )

        if series is not None and "series" in df.columns:
            keep = (series,) if isinstance(series, str) else tuple(series)
            df = df.filter(pl.col("series").is_in(list(keep)))

        if symbols is not None:
            wanted = [str(x) for x in symbols]
            if wanted:
                df = df.filter(pl.col("symbol").is_in(wanted))

        return df.sort(["symbol", "trade_date"])
    except Exception as exc:  # noqa: BLE001
        log.warning("load_range failed: %s", exc)
        return _empty()


def load_symbol(
    symbol: str,
    start: date | str,
    end: date | str,
    *,
    dataset: str = "equity_bhavcopy",
) -> pl.DataFrame:
    """Convenience: ``load_range`` for a single symbol."""
    return load_range(start, end, symbols=[symbol], dataset=dataset)


def available_dates(
    *,
    dataset: str = "equity_bhavcopy",
    start: date | str | None = None,
    end: date | str | None = None,
) -> list[date]:
    """Distinct trade dates present in the dataset, sorted ascending."""
    try:
        if start is not None and end is not None:
            df = load_range(start, end, dataset=dataset, series=None)
        else:
            df = read_parquet_partitioned(dataset)
            if df.is_empty():
                return []
            df = normalize_bhavcopy(df)
        if df.is_empty() or "trade_date" not in df.columns:
            return []
        return sorted(set(df["trade_date"].drop_nulls().to_list()))
    except Exception as exc:  # noqa: BLE001
        log.warning("available_dates failed: %s", exc)
        return []


def latest_date(*, dataset: str = "equity_bhavcopy") -> date | None:
    dates = available_dates(dataset=dataset)
    return dates[-1] if dates else None
