"""Partitioned Parquet storage.

Two partitioning modes:

1. **Manual partition** (legacy, backward compatible)::

       save_parquet(df, dataset="bulk_deals", partition="2026-05-07")
       # -> data/parquet/bulk_deals/2026-05-07/part.parquet

2. **Hive partitioning** by columns (recommended for large datasets)::

       save_parquet_partitioned(df, dataset="daily_bhavcopy",
                                by=["year", "month"])
       # -> data/parquet/daily_bhavcopy/year=2026/month=05/*.parquet

Hive-partitioned reads support pushdown predicates via ``read_parquet_partitioned``.
"""

from __future__ import annotations

import os
import time
import uuid
from pathlib import Path

import polars as pl
import pyarrow as pa
import pyarrow.dataset as pads
import pyarrow.parquet as pq

from nsefast.config import PARQUET_DIR
from nsefast.logging_setup import get_logger

log = get_logger(__name__)


def save_parquet(
    df: pl.DataFrame,
    dataset: str,
    partition: str | None = None,
) -> str:
    """Write `df` under ``data/parquet/<dataset>[/<partition>]/part.parquet``."""
    base = Path(PARQUET_DIR) / dataset
    if partition:
        base = base / partition
    base.mkdir(parents=True, exist_ok=True)

    path = base / "part.parquet"
    df.write_parquet(path)
    log.info(
        "parquet write",
        extra={"dataset": dataset, "partition": partition,
               "rows": df.height, "path": str(path)},
    )
    return str(path)


def save_parquet_partitioned(
    df: pl.DataFrame,
    dataset: str,
    by: list[str],
) -> str:
    """Write `df` as a hive-partitioned dataset.

    The partition columns must already exist in the DataFrame. Use
    ``derive_date_partitions`` to add ``year``/``month``/``day`` from a
    date column.
    """
    if df.is_empty():
        log.debug("partitioned write skipped — empty df", extra={"dataset": dataset})
        return str(Path(PARQUET_DIR) / dataset)

    missing = [c for c in by if c not in df.columns]
    if missing:
        raise ValueError(
            f"partition columns {missing} not present in df columns {df.columns}"
        )

    base = Path(PARQUET_DIR) / dataset
    base.mkdir(parents=True, exist_ok=True)

    table: pa.Table = df.to_arrow()
    pq.write_to_dataset(
        table,
        root_path=str(base),
        partition_cols=by,
        existing_data_behavior="overwrite_or_ignore",
    )
    log.info(
        "parquet hive write",
        extra={"dataset": dataset, "by": by,
               "rows": df.height, "path": str(base)},
    )
    return str(base)


def derive_date_partitions(
    df: pl.DataFrame,
    date_col: str,
    parts: tuple[str, ...] = ("year", "month"),
) -> pl.DataFrame:
    """Add ``year``/``month``/``day`` integer columns derived from ``date_col``.

    Only columns named in ``parts`` are added. ``date_col`` may be a
    Polars Date/Datetime, or a string in ``YYYY-MM-DD`` format.
    """
    if date_col not in df.columns:
        raise ValueError(f"date column {date_col!r} not in df.columns={df.columns}")

    dt = df[date_col]
    if dt.dtype == pl.Utf8:
        dt = dt.str.strptime(pl.Date, format="%Y-%m-%d", strict=False)

    add: list[pl.Expr] = []
    if "year" in parts:
        add.append(dt.dt.year().alias("year"))
    if "month" in parts:
        add.append(dt.dt.month().alias("month"))
    if "day" in parts:
        add.append(dt.dt.day().alias("day"))
    return df.with_columns(add)


def read_parquet(dataset: str) -> pl.DataFrame:
    """Read every parquet file under a dataset directory (recursive)."""
    path = Path(PARQUET_DIR) / dataset
    if not path.exists():
        return pl.DataFrame()
    return pl.scan_parquet(str(path / "**/*.parquet")).collect()


def read_parquet_partitioned(
    dataset: str,
    filters: list[tuple[str, str, object]] | None = None,
) -> pl.DataFrame:
    """Read a hive-partitioned dataset with optional pushdown predicates.

    ``filters`` is a list of ``(column, op, value)`` tuples, e.g.::

        [("year", "==", 2026), ("month", ">=", 4)]
    """
    path = Path(PARQUET_DIR) / dataset
    if not path.exists():
        return pl.DataFrame()

    try:
        ds = pads.dataset(str(path), format="parquet", partitioning="hive")
        expr = None
        if filters:
            for col, op, val in filters:
                f = pads.field(col)
                clause = {
                    "==": f == val, "!=": f != val,
                    "<": f < val, "<=": f <= val,
                    ">": f > val, ">=": f >= val,
                }[op]
                expr = clause if expr is None else expr & clause
        table = ds.to_table(filter=expr)
        return pl.from_arrow(table)
    except Exception as exc:  # noqa: BLE001
        log.warning("partitioned read failed", extra={"dataset": dataset, "err": str(exc)})
        return pl.DataFrame()


def append_partition(
    df: pl.DataFrame,
    dataset: str,
    by: list[str],
) -> str:
    """Append `df` to a hive-partitioned dataset *without rewriting* existing files.

    Each call writes a new ``part-<ts>-<uuid>.parquet`` file under each
    matching partition directory. Reads via ``read_parquet_partitioned``
    (or DuckDB's ``read_parquet(..., union_by_name=true)``) transparently
    union all part files in a partition, so appends are eventually
    consistent with no compaction step required.

    Use this for high-frequency tick/ledger writes, audit logs, and the
    quality metadata table. For one-shot daily loads where you want a
    single canonical file per partition, prefer ``save_parquet_partitioned``.
    """
    if df.is_empty():
        log.debug("append skipped — empty df", extra={"dataset": dataset})
        return str(Path(PARQUET_DIR) / dataset)

    missing = [c for c in by if c not in df.columns]
    if missing:
        raise ValueError(
            f"partition columns {missing} not present in df columns {df.columns}"
        )

    base = Path(PARQUET_DIR) / dataset
    base.mkdir(parents=True, exist_ok=True)

    # Stable, sortable file name so listing order roughly matches write
    # order. Full uuid4 hex (128 bits) — truncating risks collisions on
    # bursty writes within the same second.
    stamp = time.strftime("%Y%m%dT%H%M%S")
    suffix = uuid.uuid4().hex

    table: pa.Table = df.to_arrow()
    pq.write_to_dataset(
        table,
        root_path=str(base),
        partition_cols=by,
        existing_data_behavior="overwrite_or_ignore",
        basename_template=f"part-{stamp}-{suffix}-{{i}}.parquet",
    )
    log.info(
        "parquet append",
        extra={"dataset": dataset, "by": by,
               "rows": df.height, "path": str(base)},
    )
    return str(base)


def upsert_partition(
    df: pl.DataFrame,
    dataset: str,
    by: list[str],
    primary_key: list[str],
    *,
    keep: str = "last",
) -> str:
    """Idempotent write: merge `df` into existing partitions on ``primary_key``.

    Algorithm (per touched partition):

    1. Read existing rows in the partition.
    2. Concatenate with the new rows (new rows last).
    3. Drop duplicates on ``primary_key`` keeping ``keep="last"`` (the
       new rows win) or ``"first"`` (existing rows win).
    4. Atomically rewrite the partition's data files.

    Use this when re-running an idempotent collector — you don't want
    duplicate rows after re-fetching the same date. For pure append-only
    streams (audit logs, quality records), prefer ``append_partition``
    which avoids the read-modify-write cost.
    """
    if df.is_empty():
        log.debug("upsert skipped — empty df", extra={"dataset": dataset})
        return str(Path(PARQUET_DIR) / dataset)

    missing_part = [c for c in by if c not in df.columns]
    if missing_part:
        raise ValueError(
            f"partition columns {missing_part} not present in df columns {df.columns}"
        )
    missing_pk = [c for c in primary_key if c not in df.columns]
    if missing_pk:
        raise ValueError(
            f"primary key columns {missing_pk} not present in df columns {df.columns}"
        )
    if keep not in {"first", "last"}:
        raise ValueError(f"keep must be 'first' or 'last', got {keep!r}")

    base = Path(PARQUET_DIR) / dataset
    base.mkdir(parents=True, exist_ok=True)

    # Group new rows by partition tuple, then merge each touched partition.
    touched = df.select(by).unique().to_dicts()
    for part_keys in touched:
        new_slice = df.filter(
            _all_eq(part_keys)
        )
        existing = _read_single_partition(dataset, part_keys)
        if existing.is_empty():
            merged = new_slice
        else:
            # Align schemas (existing partition may be missing newly-added cols).
            all_cols = list(dict.fromkeys(list(existing.columns) + list(new_slice.columns)))
            existing_a = _add_missing_cols(existing, all_cols, new_slice.schema)
            new_a = _add_missing_cols(new_slice, all_cols, existing.schema)
            merged = pl.concat([existing_a, new_a], how="vertical_relaxed")
            merged = merged.unique(subset=primary_key, keep=keep)

        # Atomically replace the partition's files.
        part_dir = base
        for col in by:
            part_dir = part_dir / f"{col}={part_keys[col]}"
        _atomic_replace_partition(part_dir, merged.drop(by))

    log.info(
        "parquet upsert",
        extra={"dataset": dataset, "by": by, "pk": primary_key,
               "rows": df.height, "partitions": len(touched), "keep": keep},
    )
    return str(base)


def _all_eq(keys: dict) -> pl.Expr:
    """Build a compound equality predicate: col1==v1 AND col2==v2 …"""
    expr: pl.Expr | None = None
    for k, v in keys.items():
        clause = pl.col(k) == v
        expr = clause if expr is None else expr & clause
    return expr if expr is not None else pl.lit(True)


def _add_missing_cols(
    df: pl.DataFrame,
    all_cols: list[str],
    other_schema: dict,
) -> pl.DataFrame:
    """Add columns missing from ``df`` as nulls, typed per ``other_schema``."""
    out = df
    for c in all_cols:
        if c not in out.columns:
            dtype = other_schema.get(c, pl.Utf8)
            out = out.with_columns(pl.lit(None, dtype=dtype).alias(c))
    return out.select(all_cols)


def _read_single_partition(dataset: str, part_keys: dict) -> pl.DataFrame:
    """Read all part files in one specific partition directory."""
    base = Path(PARQUET_DIR) / dataset
    part_dir = base
    for col, val in part_keys.items():
        part_dir = part_dir / f"{col}={val}"
    if not part_dir.exists():
        return pl.DataFrame()
    files = sorted(part_dir.glob("*.parquet"))
    if not files:
        return pl.DataFrame()
    return pl.concat(
        [pl.read_parquet(str(f)) for f in files],
        how="vertical_relaxed",
    )


def _atomic_replace_partition(part_dir: Path, df: pl.DataFrame) -> None:
    """Write `df` to a temp file, atomically swap in via ``os.replace``,
    then sweep stale part files.

    Failure modes (worst → best, all reasoned about):

    * crash *before* ``os.replace``: tmp file is orphaned; original
      partition (multiple ``part-*.parquet`` files) is untouched and
      still readable. Re-running ``upsert_partition`` is idempotent.
    * crash *between* ``os.replace`` and the cleanup loop: ``part.parquet``
      contains the new merged data, but stale ``part-*.parquet`` files
      from previous appends may still be present. Reads via
      ``_read_single_partition`` will then *over-count* duplicate PK
      rows. This is a soft failure — re-running the same upsert (PK is
      idempotent) cleans it up.
    * normal exit: only ``part.parquet`` remains.

    The earlier ordering (delete-before-replace) was strictly worse —
    a crash mid-delete could leave the partition empty (data loss).
    """
    part_dir.mkdir(parents=True, exist_ok=True)
    final = part_dir / "part.parquet"
    tmp = part_dir / f".part-{uuid.uuid4().hex}.parquet.tmp"

    # 1. Stage the new payload off to the side.
    df.write_parquet(tmp)

    # 2. Atomic swap. After this line, readers see the new data.
    #    `os.replace` is atomic on POSIX (single inode swap) and on
    #    Windows (since 3.3, MoveFileEx with REPLACE_EXISTING).
    os.replace(tmp, final)

    # 3. Best-effort sweep of stale part files left over from prior
    #    `append_partition` calls. Failures here are non-fatal — the
    #    new `part.parquet` is already authoritative for the merged set.
    for old in part_dir.glob("*.parquet"):
        if old.name == final.name:
            continue
        try:
            old.unlink()
        except OSError:
            pass


def list_partitions(dataset: str) -> list[str]:
    """List partition subdirectories under a dataset (one level deep)."""
    path = Path(PARQUET_DIR) / dataset
    if not path.exists():
        return []
    return sorted(p.name for p in path.iterdir() if p.is_dir())
