"""Per-(dataset, partition) data-quality metadata table.

NSE drops feeds silently — a missing column, a half-written CSV, or a
partial response will land in your parquet store as if it were a clean
day. This module records one row per fetch with enough metadata to
catch silent drift:

- ``ts``                — UTC timestamp of the fetch
- ``dataset``           — dataset name (matches parquet dir)
- ``partition``         — partition key (e.g. ``"2026-05-07"`` or
                          ``"year=2026/month=05"``)
- ``row_count``         — rows landed
- ``content_hash``      — SHA-256 of the canonicalized row payload
- ``fetch_latency_ms``  — wall-clock latency of the fetch
- ``partial_failure``   — boolean: collector returned but flagged
                          missing columns / empty result on a non-holiday
- ``error``             — short error message (or empty string)

Records are written to ``data/parquet/_meta/quality/`` as a hive-
partitioned dataset by ``(year, month)``. Everything is crash-proof:
``record_quality`` and ``read_quality`` swallow exceptions and return
sensible defaults.

Quick start::

    from nsefast.storage.quality import track_quality, read_quality

    with track_quality("daily_bhavcopy", partition="2026-05-07") as q:
        df = collect_bhavcopy(...)
        q.row_count = df.height
        q.content_hash = q.hash_of(df)
        q.partial_failure = df.is_empty()

    # later
    audit = read_quality(dataset="daily_bhavcopy")
"""

from __future__ import annotations

import hashlib
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Mapping

import polars as pl

from nsefast.config import PARQUET_DIR
from nsefast.logging_setup import get_logger
from nsefast.storage.parquet_store import (
    derive_date_partitions,
    read_parquet_partitioned,
    save_parquet_partitioned,
)

log = get_logger(__name__)

QUALITY_DATASET = "_meta/quality"

QUALITY_SCHEMA: Mapping[str, pl.DataType] = {
    "ts":               pl.Datetime("us", time_zone="UTC"),
    "dataset":          pl.Utf8,
    "partition":        pl.Utf8,
    "row_count":        pl.Int64,
    "content_hash":     pl.Utf8,
    "fetch_latency_ms": pl.Float64,
    "partial_failure":  pl.Boolean,
    "error":            pl.Utf8,
    "year":             pl.Int32,
    "month":            pl.Int32,
}


def _empty_quality() -> pl.DataFrame:
    return pl.DataFrame(schema=dict(QUALITY_SCHEMA))


def hash_dataframe(df: pl.DataFrame) -> str:
    """SHA-256 of a canonicalized row payload.

    Sorts columns alphabetically and rows by all columns to make the
    hash insensitive to row/column ordering. Empty frames hash to a
    fixed sentinel.
    """
    if df is None or df.is_empty():
        return "sha256:empty"
    try:
        cols = sorted(df.columns)
        sig = df.select(cols).sort(cols).write_csv().encode("utf-8")
        return "sha256:" + hashlib.sha256(sig).hexdigest()
    except Exception as exc:  # noqa: BLE001
        log.warning("hash_dataframe failed", extra={"err": str(exc)})
        return "sha256:error"


def record_quality(
    dataset: str,
    partition: str,
    *,
    row_count: int = 0,
    content_hash: str = "",
    fetch_latency_ms: float = 0.0,
    partial_failure: bool = False,
    error: str = "",
    ts: datetime | None = None,
) -> bool:
    """Append one quality row to the metadata partition. Crash-proof."""
    try:
        when = (ts or datetime.now(timezone.utc)).astimezone(timezone.utc)
        row = pl.DataFrame(
            [{
                "ts": when,
                "dataset": str(dataset),
                "partition": str(partition),
                "row_count": int(row_count),
                "content_hash": str(content_hash),
                "fetch_latency_ms": float(fetch_latency_ms),
                "partial_failure": bool(partial_failure),
                "error": str(error)[:500],
            }],
            schema={
                "ts": pl.Datetime("us", time_zone="UTC"),
                "dataset": pl.Utf8,
                "partition": pl.Utf8,
                "row_count": pl.Int64,
                "content_hash": pl.Utf8,
                "fetch_latency_ms": pl.Float64,
                "partial_failure": pl.Boolean,
                "error": pl.Utf8,
            },
        ).with_columns([
            pl.lit(when.year, dtype=pl.Int32).alias("year"),
            pl.lit(when.month, dtype=pl.Int32).alias("month"),
        ])
        # Use the new append_partition path so concurrent records don't
        # clobber each other.
        from nsefast.storage.parquet_store import append_partition
        append_partition(row, QUALITY_DATASET, by=["year", "month"])
        return True
    except Exception as exc:  # noqa: BLE001
        log.warning("record_quality failed",
                    extra={"dataset": dataset, "partition": partition,
                           "err": str(exc)})
        return False


def read_quality(
    *,
    dataset: str | None = None,
    since: datetime | None = None,
    only_failures: bool = False,
) -> pl.DataFrame:
    """Read the quality table, optionally filtered.

    Returns an empty DataFrame (with canonical schema) when nothing has
    been recorded yet or on read failure.
    """
    try:
        df = read_parquet_partitioned(QUALITY_DATASET)
        if df.is_empty():
            return _empty_quality()
        out = df
        if dataset:
            out = out.filter(pl.col("dataset") == dataset)
        if since is not None:
            since_utc = (since.astimezone(timezone.utc)
                         if since.tzinfo else since.replace(tzinfo=timezone.utc))
            out = out.filter(pl.col("ts") >= since_utc)
        if only_failures:
            out = out.filter(
                pl.col("partial_failure")
                | (pl.col("error") != "")
                | (pl.col("row_count") == 0)
            )
        return out.sort("ts", descending=True)
    except Exception as exc:  # noqa: BLE001
        log.warning("read_quality failed", extra={"err": str(exc)})
        return _empty_quality()


@dataclass
class QualityTracker:
    """Mutable record built up inside a ``track_quality`` block."""
    dataset: str
    partition: str
    row_count: int = 0
    content_hash: str = ""
    partial_failure: bool = False
    error: str = ""
    _t0: float = field(default_factory=time.monotonic)

    @staticmethod
    def hash_of(df: pl.DataFrame) -> str:
        return hash_dataframe(df)


@contextmanager
def track_quality(dataset: str, partition: str):
    """Context manager: time the block, record one quality row on exit.

    Exceptions inside the block are caught, recorded as ``error``, and
    re-raised — the metadata still lands. Using this everywhere means
    a missed-day audit is always one query away.
    """
    q = QualityTracker(dataset=dataset, partition=partition)
    raised: BaseException | None = None
    try:
        yield q
    except BaseException as exc:  # noqa: BLE001
        q.error = f"{type(exc).__name__}: {exc}"
        q.partial_failure = True
        raised = exc
    finally:
        latency_ms = (time.monotonic() - q._t0) * 1000.0
        record_quality(
            q.dataset, q.partition,
            row_count=q.row_count,
            content_hash=q.content_hash,
            fetch_latency_ms=latency_ms,
            partial_failure=q.partial_failure,
            error=q.error,
        )
        if raised is not None:
            raise raised


# Re-export for symmetry with parquet_store.
_ = derive_date_partitions
_ = save_parquet_partitioned
