"""DuckDB analytics layer over the Parquet store.

Quick start::

    from nsefast.storage.duckdb_store import connect, register_all, top_gainers
    con = connect()
    register_all(con)                   # one view per dataset directory
    top_gainers(con, dataset="all_indices", n=10)
"""

from __future__ import annotations

import re
from pathlib import Path

import duckdb
import polars as pl

from nsefast.config import DUCKDB_PATH, PARQUET_DIR
from nsefast.logging_setup import get_logger

log = get_logger(__name__)

_VALID_IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _validate_identifier(name: str) -> str:
    if not _VALID_IDENT.match(name):
        raise ValueError(
            f"invalid dataset identifier {name!r}; "
            "must match ^[A-Za-z_][A-Za-z0-9_]*$"
        )
    return name


def connect(path: str = DUCKDB_PATH) -> duckdb.DuckDBPyConnection:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    return duckdb.connect(path)


def register_dataset(con: duckdb.DuckDBPyConnection, dataset: str) -> str:
    """Create a view named `dataset` over its parquet files.

    DuckDB doesn't accept prepared parameters alongside ``hive_partitioning``,
    so the path is inlined as a SQL string literal. Safety: the dataset name
    is validated against ``^[A-Za-z_][A-Za-z0-9_]*$`` and the base
    ``PARQUET_DIR`` is config-controlled — single quotes in the resulting
    path are doubled per SQL escaping rules.
    """
    safe = _validate_identifier(dataset)
    glob = str(Path(PARQUET_DIR) / safe / "**/*.parquet")
    glob_lit = glob.replace("'", "''")
    con.execute(
        f'CREATE OR REPLACE VIEW "{safe}" AS '
        f"SELECT * FROM read_parquet('{glob_lit}', "
        f"hive_partitioning = true, union_by_name = true)"
    )
    return safe


def register_all(con: duckdb.DuckDBPyConnection) -> list[str]:
    """Register one view per dataset directory under ``data/parquet/``.

    Returns the list of registered view names.
    """
    base = Path(PARQUET_DIR)
    if not base.exists():
        return []
    registered: list[str] = []
    for d in sorted(base.iterdir()):
        if not d.is_dir() or not _VALID_IDENT.match(d.name):
            continue
        # Skip internal/system dirs (e.g. ``_meta`` for the quality table)
        # so they don't pollute the user-facing SQL namespace. Users who
        # genuinely need SQL on internal datasets can register them by
        # name via ``register_dataset``.
        if d.name.startswith("_"):
            continue
        try:
            register_dataset(con, d.name)
            registered.append(d.name)
        except Exception as exc:  # noqa: BLE001
            log.warning("register skipped", extra={"dataset": d.name, "err": str(exc)})
    return registered


def query(sql: str, path: str = DUCKDB_PATH) -> pl.DataFrame:
    """Run ad-hoc SQL and return a Polars DataFrame.

    Returns an empty DataFrame on any failure (consistent with collectors).
    """
    try:
        con = connect(path)
        register_all(con)
        arrow_tbl = con.execute(sql).arrow()
        return pl.from_arrow(arrow_tbl)
    except Exception as exc:  # noqa: BLE001
        log.warning("duckdb query failed", extra={"err": str(exc)})
        return pl.DataFrame()


# ---------- canned analytics --------------------------------------------------


def top_gainers(
    con: duckdb.DuckDBPyConnection,
    dataset: str = "all_indices",
    n: int = 20,
    pct_col: str = "percent_change",
    name_col: str = "index_name",
) -> pl.DataFrame:
    """Top `n` rows by `pct_col` desc."""
    safe = _validate_identifier(dataset)
    sql = (
        f'SELECT "{name_col}", "{pct_col}" '
        f'FROM "{safe}" '
        f'WHERE "{pct_col}" IS NOT NULL '
        f'ORDER BY "{pct_col}" DESC LIMIT ?'
    )
    return pl.from_arrow(con.execute(sql, [n]).arrow())


def top_losers(
    con: duckdb.DuckDBPyConnection,
    dataset: str = "all_indices",
    n: int = 20,
    pct_col: str = "percent_change",
    name_col: str = "index_name",
) -> pl.DataFrame:
    """Bottom `n` rows by `pct_col` asc."""
    safe = _validate_identifier(dataset)
    sql = (
        f'SELECT "{name_col}", "{pct_col}" '
        f'FROM "{safe}" '
        f'WHERE "{pct_col}" IS NOT NULL '
        f'ORDER BY "{pct_col}" ASC LIMIT ?'
    )
    return pl.from_arrow(con.execute(sql, [n]).arrow())


def daily_summary(
    con: duckdb.DuckDBPyConnection,
    dataset: str = "daily_bhavcopy",
) -> pl.DataFrame:
    """Per-date summary: rows, unique symbols, total turnover."""
    safe = _validate_identifier(dataset)
    sql = (
        f'SELECT timestamp AS trade_date, '
        f'       COUNT(*) AS rows, '
        f'       COUNT(DISTINCT symbol) AS symbols, '
        f'       SUM(tottrdval) AS total_turnover '
        f'FROM "{safe}" GROUP BY timestamp ORDER BY timestamp DESC'
    )
    try:
        return pl.from_arrow(con.execute(sql).arrow())
    except Exception as exc:  # noqa: BLE001
        log.warning("daily_summary failed", extra={"err": str(exc)})
        return pl.DataFrame()


def sector_leaderboard(
    con: duckdb.DuckDBPyConnection,
    dataset: str = "sector_strength",
) -> pl.DataFrame:
    """Sectors ordered by % change desc with an up/down flag."""
    safe = _validate_identifier(dataset)
    sql = (
        f'SELECT index_name, percent_change, '
        f'       CASE WHEN percent_change >= 0 THEN \'up\' ELSE \'down\' END AS direction '
        f'FROM "{safe}" '
        f'WHERE percent_change IS NOT NULL '
        f'ORDER BY percent_change DESC'
    )
    try:
        return pl.from_arrow(con.execute(sql).arrow())
    except Exception as exc:  # noqa: BLE001
        log.warning("sector_leaderboard failed", extra={"err": str(exc)})
        return pl.DataFrame()
