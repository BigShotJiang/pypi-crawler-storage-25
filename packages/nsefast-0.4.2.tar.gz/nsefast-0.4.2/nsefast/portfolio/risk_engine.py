"""Portfolio-level risk engine.

Takes a (regime-sized) signal frame and trims it to honour
portfolio-wide caps before it reaches the executor:

* ``max_positions``                — hard cap on open trades.
* ``max_sector_exposure_pct``      — % of deployed capital per sector.
* ``max_correlated``               — per correlation cluster.
* ``max_portfolio_drawdown_pct``   — kill switch on equity drawdown.

Caps are applied greedy by ``confidence_score`` descending so the
strongest signals always survive a cull. Crash-proof: any failure
returns the input frame unchanged with a warning logged.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import polars as pl

from nsefast.logging_setup import get_logger
from nsefast.safe import safe_dataframe

log = get_logger(__name__)


def _empty_caps_frame() -> pl.DataFrame:
    """Canonical empty result for ``apply_portfolio_caps`` failures.

    A bare ``pl.DataFrame()`` is acceptable because callers always check
    ``.is_empty()`` first; downstream consumers tolerate any zero-row
    frame.
    """
    return pl.DataFrame()


@dataclass(frozen=True)
class PortfolioCaps:
    """Configuration for :func:`apply_portfolio_caps`."""
    max_positions: int = 10
    max_sector_exposure_pct: float = 30.0       # % of total deployed notional
    max_correlated: int = 3                     # per correlation cluster
    max_portfolio_drawdown_pct: float | None = 15.0
    sector_col: str = "sector"
    cluster_col: str = "cluster_id"             # optional, only enforced if present
    notional_col: str = "notional_rs"           # falls back to entry*qty


def _ensure_notional(df: pl.DataFrame, notional_col: str) -> pl.DataFrame:
    if notional_col in df.columns:
        return df
    if "entry" in df.columns and "qty" in df.columns:
        return df.with_columns(
            (pl.col("entry").cast(pl.Float64, strict=False)
             * pl.col("qty").cast(pl.Float64, strict=False))
                .alias(notional_col)
        )
    return df.with_columns(pl.lit(0.0, dtype=pl.Float64).alias(notional_col))


@safe_dataframe(_empty_caps_frame, name="apply_portfolio_caps")
def apply_portfolio_caps(
    signals: pl.DataFrame,
    caps: PortfolioCaps | None = None,
    *,
    current_drawdown_pct: float = 0.0,
    open_positions: pl.DataFrame | None = None,
) -> pl.DataFrame:
    """Trim ``signals`` greedy-by-confidence so all caps are honoured.

    ``current_drawdown_pct`` is the live equity drawdown (positive %)
    — if it exceeds ``max_portfolio_drawdown_pct`` the engine returns
    an empty frame (kill switch). ``open_positions`` is an optional
    frame of already-open trades whose count and sector counts are
    added to the new candidates' headroom.
    """
    caps = caps or PortfolioCaps()
    if signals is None or signals.is_empty():
        return signals if signals is not None else pl.DataFrame()
    try:
        # Drawdown kill-switch
        if (caps.max_portfolio_drawdown_pct is not None
                and current_drawdown_pct >= caps.max_portfolio_drawdown_pct):
            log.warning(
                "apply_portfolio_caps: drawdown %.2f%% >= cap %.2f%% — "
                "blocking all new signals",
                current_drawdown_pct, caps.max_portfolio_drawdown_pct)
            return signals.head(0)

        df = _ensure_notional(signals, caps.notional_col)
        df = df.sort("confidence_score", descending=True, nulls_last=True)

        # Seed open-position counts so headroom respects what's live.
        open_count = 0
        sector_open: dict[str, float] = {}
        cluster_open: dict[Any, int] = {}
        if open_positions is not None and not open_positions.is_empty():
            open_count = open_positions.height
            if caps.sector_col in open_positions.columns and caps.notional_col in open_positions.columns:
                grp = (open_positions.group_by(caps.sector_col)
                        .agg(pl.col(caps.notional_col).sum().alias("n")))
                for row in grp.iter_rows(named=True):
                    sector_open[str(row[caps.sector_col])] = float(row["n"] or 0.0)
            if caps.cluster_col in open_positions.columns:
                grp = (open_positions.group_by(caps.cluster_col)
                        .agg(pl.len().alias("n")))
                for row in grp.iter_rows(named=True):
                    cluster_open[row[caps.cluster_col]] = int(row["n"])

        kept_idx: list[int] = []
        # Sector cap is checked against the *fully-deployed* portfolio
        # denominator (open + all candidate notional). This stops the
        # first pick of a sector being trivially rejected at 100%
        # concentration before any diversifying picks are seen.
        candidate_total = float(df[caps.notional_col].sum() or 0.0)
        deployed_denom = float(sum(sector_open.values())) + candidate_total
        sector_used = dict(sector_open)
        cluster_used = dict(cluster_open)
        new_count = 0

        rows = df.to_dicts()
        for i, row in enumerate(rows):
            if open_count + new_count >= caps.max_positions:
                break
            sector = str(row.get(caps.sector_col) or "UNKNOWN")
            cluster = row.get(caps.cluster_col)
            notional = float(row.get(caps.notional_col) or 0.0)
            # Cluster cap
            if cluster is not None and cluster_used.get(cluster, 0) >= caps.max_correlated:
                continue
            # Sector cap — keep cumulative sector exposure ≤ cap of the
            # fully-deployed portfolio.
            if deployed_denom > 0:
                sector_proj = sector_used.get(sector, 0.0) + notional
                if (sector_proj / deployed_denom) * 100.0 > caps.max_sector_exposure_pct:
                    continue
            # Accept
            kept_idx.append(i)
            new_count += 1
            sector_used[sector] = sector_used.get(sector, 0.0) + notional
            if cluster is not None:
                cluster_used[cluster] = cluster_used.get(cluster, 0) + 1

        if not kept_idx:
            return df.head(0)
        out = df[kept_idx]
        if "signal_rank" in out.columns:
            out = out.with_columns(
                pl.int_range(1, pl.len() + 1, dtype=pl.Int64).alias("signal_rank")
            )
        return out
    except Exception as exc:  # noqa: BLE001
        log.warning("apply_portfolio_caps failed: %s", exc)
        # Contract: never leak unprocessed input on failure — return an
        # empty frame whose schema mirrors the input so downstream code
        # can still concatenate / iterate safely.
        try:
            return signals.head(0) if signals is not None else pl.DataFrame()
        except Exception:  # noqa: BLE001
            return pl.DataFrame()


def portfolio_summary(signals: pl.DataFrame, caps: PortfolioCaps | None = None) -> dict[str, Any]:
    """Quick post-cap rollup used by the report layer."""
    caps = caps or PortfolioCaps()
    if signals is None or signals.is_empty():
        return {"n_positions": 0, "total_notional": 0.0, "sectors": {}, "clusters": {}}
    try:
        df = _ensure_notional(signals, caps.notional_col)
        sectors = {}
        if caps.sector_col in df.columns:
            grp = (df.group_by(caps.sector_col)
                     .agg(pl.col(caps.notional_col).sum().alias("n")))
            for row in grp.iter_rows(named=True):
                sectors[str(row[caps.sector_col] or "UNKNOWN")] = float(row["n"] or 0.0)
        clusters = {}
        if caps.cluster_col in df.columns:
            grp = (df.group_by(caps.cluster_col).agg(pl.len().alias("n")))
            for row in grp.iter_rows(named=True):
                clusters[row[caps.cluster_col]] = int(row["n"])
        return {
            "n_positions": df.height,
            "total_notional": float(df[caps.notional_col].sum() or 0.0),
            "sectors": sectors,
            "clusters": clusters,
        }
    except Exception as exc:  # noqa: BLE001
        log.warning("portfolio_summary failed: %s", exc)
        return {"n_positions": 0, "total_notional": 0.0, "sectors": {}, "clusters": {}}
