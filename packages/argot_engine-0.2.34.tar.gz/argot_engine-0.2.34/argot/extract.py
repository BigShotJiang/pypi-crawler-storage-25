from __future__ import annotations

import argparse
import json
import os
import sys
from dataclasses import asdict
from pathlib import Path

import pygit2

from argot.dataset import HunkRecord
from argot.git_walk import _resolve_shas, walk_commits, walk_repo
from argot.tokenize import language_for_path

CONTEXT_LINES = 50


def _extract_context(
    source_lines: list[str],
    hunk_start: int,
    hunk_end: int,
) -> tuple[list[str], list[str], list[str]]:
    before_start = max(0, hunk_start - CONTEXT_LINES)
    after_end = min(len(source_lines), hunk_end + CONTEXT_LINES)
    return (
        source_lines[before_start:hunk_start],
        source_lines[hunk_start:hunk_end],
        source_lines[hunk_end:after_end],
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Extract dataset from git history")
    parser.add_argument("repo_path", help="Path to git repository")
    parser.add_argument(
        "ref",
        nargs="?",
        default="",
        help="Optional git ref or range (e.g. abc1234 or a..b). Defaults to full history.",
    )
    parser.add_argument("--out", default=".argot/dataset.jsonl", help="Output JSONL path")
    parser.add_argument("--limit", type=int, default=None, help="Max number of records to emit")
    args = parser.parse_args()

    repo_path = args.repo_path
    out_path = Path(args.out)

    try:
        repo = pygit2.Repository(repo_path)
    except pygit2.GitError:
        print(f"error: repository not found at {repo_path!r}", file=sys.stderr)
        sys.exit(2)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    # Atomic write: stream to a per-PID tmp file, then rename. Allows multiple
    # worktrees to share a destination (e.g. via symlink to a cache dir) without
    # corrupting each other or leaving half-written output on Ctrl-C.
    tmp_path = out_path.with_name(f"{out_path.name}.tmp.{os.getpid()}")

    count = 0
    limit_reached = False

    # Choose walk strategy based on the optional ref argument.
    if args.ref:
        try:
            shas = _resolve_shas(repo, args.ref)
        except (pygit2.GitError, KeyError):
            shas = set()
        if not shas:
            tmp_path.unlink(missing_ok=True)
            print(
                f"error: no commits found for ref {args.ref!r} — try a wider range",
                file=sys.stderr,
            )
            sys.exit(2)
        walk = walk_commits(repo_path, shas)
    else:
        walk = walk_repo(repo_path)

    try:
        with open(tmp_path, "w") as fh:
            for commit, file_path, post_blob, hunks in walk:
                lang = language_for_path(file_path)
                if lang is None:
                    continue

                try:
                    source_lines = post_blob.decode("utf-8", errors="replace").splitlines()
                except Exception:
                    continue

                parent_sha = str(commit.parents[0].id) if commit.parents else None
                author_date_iso = commit.author.time

                for hunk in hunks:
                    hunk_start = hunk.new_start - 1  # convert to 0-indexed
                    hunk_end = hunk_start + hunk.new_lines

                    if hunk_start < 0 or hunk_end > len(source_lines):
                        continue

                    ctx_before_lines, hunk_lines, ctx_after_lines = _extract_context(
                        source_lines, hunk_start, hunk_end
                    )

                    before_start_abs = max(0, hunk_start - CONTEXT_LINES)
                    after_start_abs = hunk_end

                    from argot.tokenize import tokenize_lines

                    context_before = tokenize_lines(
                        source_lines, lang, before_start_abs, hunk_start
                    )
                    hunk_tokens = tokenize_lines(source_lines, lang, hunk_start, hunk_end)
                    context_after = tokenize_lines(
                        source_lines,
                        lang,
                        after_start_abs,
                        min(len(source_lines), after_start_abs + CONTEXT_LINES),
                    )

                    record = HunkRecord(
                        commit_sha=str(commit.id),
                        file_path=file_path,
                        language=lang,
                        hunk_start_line=hunk_start,
                        hunk_end_line=hunk_end,
                        context_before=context_before,
                        hunk_tokens=hunk_tokens,
                        context_after=context_after,
                        parent_sha=parent_sha,
                        author_date_iso=str(author_date_iso),
                    )

                    fh.write(json.dumps(asdict(record)))
                    fh.write("\n")
                    count += 1

                    if args.limit is not None and count >= args.limit:
                        limit_reached = True
                        break

                if limit_reached:
                    break
    except BaseException:
        tmp_path.unlink(missing_ok=True)
        raise

    if count == 0:
        tmp_path.unlink(missing_ok=True)
        print("error: no hunks found — repository may have no history", file=sys.stderr)
        sys.exit(2)

    tmp_path.replace(out_path)

    if limit_reached:
        print(f"Reached limit of {args.limit} records", file=sys.stderr)
    print(f"Wrote {count} records to {out_path}")


if __name__ == "__main__":
    main()
