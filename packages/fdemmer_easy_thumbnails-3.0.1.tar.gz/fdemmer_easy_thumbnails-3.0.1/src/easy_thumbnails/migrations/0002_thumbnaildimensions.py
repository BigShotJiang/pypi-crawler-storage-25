from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('easy_thumbnails', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='ThumbnailDimensions',
            fields=[
                (
                    'id',
                    models.AutoField(
                        verbose_name='ID',
                        serialize=False,
                        auto_created=True,
                        primary_key=True,
                    ),
                ),
                (
                    'thumbnail',
                    models.OneToOneField(
                        on_delete=models.CASCADE,
                        related_name='dimensions',
                        to='easy_thumbnails.Thumbnail',
                    ),
                ),
                ('width', models.PositiveIntegerField(null=True)),
                ('height', models.PositiveIntegerField(null=True)),
            ],
            options={},
            bases=(models.Model,),
        ),
    ]
