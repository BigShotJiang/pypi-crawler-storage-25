import datetime as dt
import subprocess
from pathlib import Path


def get_version(version=None):
    """Returns a PEP 386-compliant version number from VERSION."""
    if version is None:
        from easy_thumbnails import VERSION as version
    else:
        assert len(version) == 5
        assert version[3] in ('alpha', 'beta', 'rc', 'final')

    # Now build the two parts of the version number:
    # main = X.Y[.Z]
    # sub = .devN - for pre-alpha releases
    #     | {a|b|c}N - for alpha, beta and rc releases

    parts = 2 if version[2] == 0 else 3
    main = '.'.join(str(x) for x in version[:parts])

    sub = ''
    if version[3] == 'post':
        sub_v = version[4] or get_git_changeset()
        sub = f'.post{sub_v}'

    elif version[3] == 'alpha' and version[4] == 0:
        git_changeset = get_git_changeset()
        if git_changeset:
            sub = f'.dev{git_changeset}'

    elif version[3] != 'final':
        mapping = {'alpha': '.a', 'beta': '.b', 'rc': '.rc'}
        sub = mapping[version[3]] + str(version[4])

    return str(main + sub)


def get_git_changeset():
    """
    Returns a numeric identifier of the latest git changeset.

    The result is the UTC timestamp of the changeset in YYYYMMDDHHMMSS format.
    This value isn't guaranteed to be unique, but collisions are very unlikely,
    so it's sufficient for generating the development version numbers.
    """
    repo_dir = Path(__file__).resolve().parent.parent
    git_log = subprocess.Popen(
        'git log --pretty=format:%ct --quiet -1 HEAD',
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        shell=True,
        cwd=repo_dir,
        universal_newlines=True,
    )
    timestamp = git_log.communicate()[0]
    try:
        timestamp = dt.datetime.fromtimestamp(int(timestamp), dt.UTC)
    except ValueError:
        return None
    return timestamp.strftime('%Y%m%d%H%M%S')
