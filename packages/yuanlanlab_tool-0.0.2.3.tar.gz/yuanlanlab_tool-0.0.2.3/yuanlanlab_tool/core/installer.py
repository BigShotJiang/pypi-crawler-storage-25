import os

from . import downloader
from . import unpacker
from . import utils


class Install:
    def __init__(
            self,
            url,
            target=None,
            max_retries=3,
            overwrite=True,
            delete_zip=True,
            entry_func='run',
            entry_kwargs=None):
        self.url = url
        self.target = target
        self.max_retries = max_retries
        self.overwrite = overwrite
        self.delete_zip = delete_zip
        self.entry_func = entry_func
        self.entry_kwargs = entry_kwargs or {}

        self.package_path = utils.get_package_path()
        self.print_help = utils.PrettyPrint()

    def _build_downloader(self):
        download = downloader.Download(
            url=self.url,
            target=self.target,
            max_retries=self.max_retries,
            overwrite=self.overwrite,
        )
        return download

    def _run_entry(self, module_filename):
        module = utils.load_module(module_filename, reload=True)
        if not hasattr(module, self.entry_func):
            raise AttributeError(f'Module "{module_filename}" does not have function "{self.entry_func}"')

        func = getattr(module, self.entry_func)
        if not callable(func):
            raise TypeError(f'Attribute "{self.entry_func}" in module "{module_filename}" is not callable')

        self.print_help.print_info('[INSTALL] Step 3/3: Execute bootstrap...')
        print('-' * 50)

        result = func(self.url, **self.entry_kwargs)
        print('-' * 50)

        self.print_help.print_success('[INSTALL] Bootstrap execution completed')

        return result

    def run(self):
        downloader = self._build_downloader()
        zip_path = downloader._resolve_dest_path()

        self.print_help.print_info('[INSTALL] Step 1/3: Download bootstrap module...')

        ok = downloader.download_file(zip_path)
        if not ok:
            self.print_help.print_error('[INSTALL] Download failed, operation aborted!')
            return None

        try:
            self.print_help.print_info('[INSTALL] Step 2/3: Extract bootstrap module...')

            unpack = unpacker.Unpack(zip_path=zip_path, overwrite=self.overwrite)
            module_filename = unpack.run()

            result = self._run_entry(module_filename)

            if self.delete_zip and os.path.exists(zip_path):
                os.remove(zip_path)

            self.print_help.print_success('[INSTALL] Installation completed successfully.')
            return result

        except Exception:
            self.print_help.print_error('[INSTALL] Bootstrap execution failed, downloaded ZIP file has been retained.')
            raise


def install(
        url,
        target=None,
        entry_func='run',
        entry_kwargs=None,
        *args,
        **kwargs):
    handler = Install(
        url=url,
        target=target,
        entry_func=entry_func,
        entry_kwargs=entry_kwargs,
        *args,
        **kwargs,
    )
    return handler.run()
