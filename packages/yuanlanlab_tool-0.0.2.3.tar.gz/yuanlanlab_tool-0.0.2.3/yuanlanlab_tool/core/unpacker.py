import os
import shutil
import zipfile

from . import utils


class Unpack:
    def __init__(self, zip_path, overwrite=True):
        self.zip_path = os.path.abspath(zip_path)
        self.overwrite = overwrite

        self.package_path = utils.get_package_path()
        self.print_help = utils.PrettyPrint()

    def _check_zip_path(self):
        if not os.path.exists(self.zip_path):
            raise FileNotFoundError(f'ZIP file does not exist: {self.zip_path}')

        if not zipfile.is_zipfile(self.zip_path):
            raise ValueError(f'Invalid ZIP file: {self.zip_path}')

    def _get_py_members(self, zf):
        py_members = []

        for info in zf.infolist():
            if info.is_dir():
                continue

            name = info.filename
            if name.lower().endswith('.py'):
                py_members.append(info)

        return py_members

    def _select_target_member(self, py_members):
        if not py_members:
            raise FileNotFoundError('No Python file found in the ZIP archive.')

        if len(py_members) == 1:
            return py_members[0]

        # 优先选择“最内层”的 .py：
        # 目录层级越深越优先；若层级相同，则文件名更短者优先，再按完整路径排序
        def sort_key(info):
            normalized = info.filename.replace('\\', '/').strip('/')
            depth = normalized.count('/')
            basename = os.path.basename(normalized)
            return (-depth, len(basename), normalized.lower())

        sorted_members = sorted(py_members, key=sort_key)
        target = sorted_members[0]

        self.print_help.print_warning(f'Multiple Python files found in ZIP, selected the deepest one: {target.filename}')
        return target

    def _resolve_dest_path(self, filename):
        dest_path = os.path.join(self.package_path, filename)
        dest_path = os.path.abspath(dest_path)

        root = os.path.abspath(self.package_path)
        if os.path.commonpath([root, dest_path]) != root:
            raise ValueError(f'Invalid destination path: {dest_path}')

        return dest_path

    def _copy_member_to_package_root(self, zf, member):
        filename = os.path.basename(member.filename)
        if not filename:
            raise ValueError(f'Invalid Python file name in ZIP: {member.filename}')

        dest_path = self._resolve_dest_path(filename)

        if os.path.exists(dest_path) and not self.overwrite:
            self.print_help.print_warning(f'Target file already exists and overwrite=False, skipping: {dest_path}')
            return filename

        os.makedirs(os.path.dirname(dest_path), exist_ok=True)

        with zf.open(member, 'r') as src, open(dest_path, 'wb') as dst:
            shutil.copyfileobj(src, dst)

        return filename

    def run(self):
        self._check_zip_path()

        with zipfile.ZipFile(self.zip_path, 'r') as zf:
            py_members = self._get_py_members(zf)
            target_member = self._select_target_member(py_members)

            # self.print_help.print_info(f'Found Python file in ZIP: {target_member.filename}')
            return self._copy_member_to_package_root(zf, target_member)


def unpack(zip_path, *args, **kwargs):
    handler = Unpack(zip_path=zip_path, *args, **kwargs)
    return handler.run()
