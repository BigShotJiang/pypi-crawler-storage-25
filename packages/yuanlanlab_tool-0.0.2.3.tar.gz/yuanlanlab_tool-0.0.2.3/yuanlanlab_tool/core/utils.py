import importlib
import os
import sys


class PrettyPrint:
    # 颜色定义
    COLOR_RESET = '\033[0m'
    COLOR_RED = '\033[91m'
    COLOR_GREEN = '\033[92m'
    COLOR_YELLOW = '\033[93m'
    COLOR_BLUE = '\033[94m'

    def print_error(self, message):
        print(f'{self.COLOR_RED}[ERROR] {message}{self.COLOR_RESET}')

    def print_success(self, message):
        print(f'{self.COLOR_GREEN}[SUCCESS] {message}{self.COLOR_RESET}')

    def print_warning(self, message):
        print(f'{self.COLOR_YELLOW}[WARNING] {message}{self.COLOR_RESET}')

    def print_info(self, message):
        print(f'{self.COLOR_BLUE}[INFO] {message}{self.COLOR_RESET}')


HELP_TXT = """
本包系元蓝先生为教学专门构建，提供教学所需的工具和资源。

作者：
- 元蓝先生
- 其活跃于B站，分享编程、数据分析和人工智能相关教学内容。
- https://space.bilibili.com/3546564903569609
"""


def show_help():
    print(HELP_TXT)


def get_package_path():
    path = __file__
    path = os.path.split(path)[0]
    path = os.path.dirname(path)
    return path


def get_package_name():
    path = get_package_path()
    path = os.path.normpath(path)
    return os.path.basename(path)


def load_module(file, reload=False):
    filename = os.path.basename(file)
    module_name, ext = os.path.splitext(filename)
    if ext.lower() != '.py':
        raise ValueError(f'Only Python files can be loaded, got: {file}')

    package_name = get_package_name()
    full_module_name = f'{package_name}.{module_name}'

    if reload and full_module_name in sys.modules:
        return importlib.reload(sys.modules[full_module_name])

    return importlib.import_module(full_module_name)
