import os
import time
import urllib.request
from urllib.parse import urlparse, unquote

from . import utils


class Download:
    def __init__(self, url, target=None, max_retries=3, overwrite=True):

        self.url = url
        self.target = target
        self.max_retries = max_retries
        self.overwrite = overwrite

        self.package_path = utils.get_package_path()
        self.print_help = utils.PrettyPrint()

    # ---------- path helpers ----------
    def _get_filename(self):
        try:
            parsed = urlparse(self.url)
            name = os.path.basename(parsed.path.rstrip('/'))
            name = unquote(name) if name else ''
        except Exception:
            name = ''

        return name or f'download_{int(time.time())}.bin'

    def _resolve_dest_path(self):
        if self.target:
            filename = self.target
        else:
            filename = self._get_filename()

        dest_path = os.path.join(self.package_path, filename)
        dest_path = os.path.abspath(dest_path)

        root = os.path.abspath(self.package_path)
        if os.path.commonpath([root, dest_path]) != root:
            raise ValueError(f'Invalid filename, target path escapes package directory: {filename}')

        return dest_path

    # ---------- download ----------
    def download_file(self, dest_path):
        headers = {'User-Agent': 'yuanlanlab-python'}
        os.makedirs(os.path.dirname(dest_path), exist_ok=True)

        if os.path.exists(dest_path) and not self.overwrite:
            self.print_help.print_warning(f'Target already exists and overwrite=False, skipping: {dest_path}')
            return True

        tmp_path = dest_path + '.part'

        for attempt in range(1, self.max_retries + 1):
            try:
                req = urllib.request.Request(self.url, headers=headers)
                with urllib.request.urlopen(req) as resp:
                    data = resp.read()

                with open(tmp_path, 'wb') as f:
                    f.write(data)

                os.replace(tmp_path, dest_path)
                return True

            except Exception as e:
                # 清理临时文件（如果存在）
                try:
                    if os.path.exists(tmp_path):
                        os.remove(tmp_path)
                except Exception:
                    pass

                self.print_help.print_warning(f'Download failed (attempt {attempt}): {e}')

                # 等待：错误次数 * 3 秒
                wait_s = attempt * 3
                if attempt < self.max_retries:
                    time.sleep(wait_s)

        return False

    def run(self):
        dest_path = self._resolve_dest_path()

        ok = self.download_file(dest_path)
        if not ok:
            self.print_help.print_error('Error occurred, operation aborted!')
            return None

        return dest_path


def download(url, target=None, *args, **kwargs):
    downloader = Download(url=url, target=target, *args, **kwargs)
    return downloader.run()
