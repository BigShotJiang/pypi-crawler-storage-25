"""Package for logging utilities."""

from __future__ import annotations

from .formats import Formatter, formatter, message, prefix
from .handlers import StreamHandler, stream_handler
from .logger_mixin import LoggerMixin
from .logging import INFO, basicConfig

basicConfig(
    level=INFO,
    handlers=[stream_handler],
)

__all__ = [
    "Formatter",
    "LoggerMixin",
    "StreamHandler",
    "formatter",
    "message",
    "prefix",
    "stream_handler",
]
