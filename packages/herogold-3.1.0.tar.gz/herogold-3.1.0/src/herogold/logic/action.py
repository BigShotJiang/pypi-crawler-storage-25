"""Defines an Action class and a decorator to create actions from functions."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Callable


class Action[T]:
    """An action to be executed."""

    __slots__ = ("func",)

    def __init__(self, func: Callable[[], T]) -> None:
        """Initialize the action with a callable function."""
        self.func = func

    def __call__(self) -> T:
        """Execute the action and return its result."""
        return self.func()


def action[T](func: Callable[[], T]) -> Action[T]:
    """Decorate a method to create an Action instance from it."""
    return Action(func)
