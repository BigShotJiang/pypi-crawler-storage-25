"""Advanced diff planner tests for complex interleaving and upgrade logic.

Covers: multiple unmatched blocks between anchors, blocks before first and
after last anchor, DELETE+INSERT upgrade to UPDATE/REPLACE, full-overwrite
fallback threshold, and async executor mirror operations.
"""
import pytest

from notionify.config import NotionifyConfig
from notionify.diff.executor import AsyncDiffExecutor, DiffExecutor
from notionify.diff.planner import DiffPlanner
from notionify.models import DiffOp, DiffOpType


def _para(text: str, block_id: str | None = None) -> dict:
    block = {
        "type": "paragraph",
        "paragraph": {
            "rich_text": [{"type": "text", "text": {"content": text}, "plain_text": text}],
            "color": "default",
        },
    }
    if block_id:
        block["id"] = block_id
    return block


def _heading(text: str, block_id: str | None = None) -> dict:
    block = {
        "type": "heading_1",
        "heading_1": {
            "rich_text": [{"type": "text", "text": {"content": text}, "plain_text": text}],
            "color": "default",
            "is_toggleable": False,
        },
    }
    if block_id:
        block["id"] = block_id
    return block


def _table_row(cells: list[list[str]], block_id: str | None = None) -> dict:
    """Build a minimal table_row block from a list of cell text lists."""
    block = {
        "type": "table_row",
        "table_row": {
            "cells": [
                [{"plain_text": text} for text in cell_texts]
                for cell_texts in cells
            ],
        },
    }
    if block_id:
        block["id"] = block_id
    return block


def _code(text: str, block_id: str | None = None) -> dict:
    block = {
        "type": "code",
        "code": {
            "rich_text": [{"type": "text", "text": {"content": text}, "plain_text": text}],
            "language": "python",
        },
    }
    if block_id:
        block["id"] = block_id
    return block


class TestPlannerInterleaving:
    """Test complex interleaving patterns in _build_ops."""

    def _plan(self, existing, new):
        planner = DiffPlanner(NotionifyConfig(token="test"))
        return planner.plan(existing, new)

    def test_multiple_deletes_between_anchors(self):
        """Multiple existing blocks between two matching anchors should all be deleted."""
        existing = [
            _para("A", "e1"),  # anchor
            _para("X", "e2"),  # delete
            _para("Y", "e3"),  # delete
            _para("Z", "e4"),  # delete
            _para("B", "e5"),  # anchor
        ]
        new = [_para("A"), _para("B")]

        ops = self._plan(existing, new)
        keeps = [o for o in ops if o.op_type == DiffOpType.KEEP]
        deletes = [o for o in ops if o.op_type == DiffOpType.DELETE]
        assert len(keeps) == 2  # A and B matched
        assert len(deletes) == 3  # X, Y, Z deleted

    def test_multiple_inserts_between_anchors(self):
        """Multiple new blocks between two matching anchors should all be inserted."""
        existing = [_para("A", "e1"), _para("B", "e2")]
        new = [_para("A"), _para("X"), _para("Y"), _para("Z"), _para("B")]

        ops = self._plan(existing, new)
        keeps = [o for o in ops if o.op_type == DiffOpType.KEEP]
        inserts = [o for o in ops if o.op_type == DiffOpType.INSERT]
        assert len(keeps) == 2
        assert len(inserts) == 3

    def test_blocks_before_first_anchor(self):
        """Unmatched blocks before the first anchor: existing ones deleted, new ones inserted."""
        existing = [
            _para("X", "e0"),  # unmatched existing → delete
            _para("A", "e1"),  # anchor
        ]
        new = [
            _para("Y"),  # unmatched new → insert
            _para("A"),  # anchor
        ]

        ops = self._plan(existing, new)
        op_types = [o.op_type for o in ops]
        # Should have a delete for X, insert for Y (or upgrade to UPDATE/REPLACE), and KEEP for A
        assert DiffOpType.KEEP in op_types
        total_writes = sum(
            1 for o in ops if o.op_type in (DiffOpType.DELETE, DiffOpType.INSERT,
                                             DiffOpType.UPDATE, DiffOpType.REPLACE)
        )
        assert total_writes >= 1

    def test_blocks_after_last_anchor(self):
        """Unmatched blocks after the last anchor."""
        existing = [
            _para("A", "e1"),  # anchor
            _para("X", "e2"),  # unmatched → delete
        ]
        new = [
            _para("A"),  # anchor
            _para("Y"),  # unmatched → insert
        ]

        ops = self._plan(existing, new)
        keeps = [o for o in ops if o.op_type == DiffOpType.KEEP]
        assert len(keeps) == 1  # A
        # X→Y should become UPDATE (same type) or DELETE+INSERT
        non_keeps = [o for o in ops if o.op_type != DiffOpType.KEEP]
        assert len(non_keeps) >= 1

    def test_mixed_before_and_after_anchor(self):
        """With only 1 anchor out of 4 blocks, match ratio 0.25 < 0.3 triggers full overwrite."""
        existing = [
            _para("X1", "e0"),
            _para("X2", "e1"),
            _para("A", "e2"),  # would be sole anchor
            _para("X3", "e3"),
        ]
        new = [
            _para("Y1"),
            _para("A"),  # would match
            _para("Y2"),
            _para("Y3"),
        ]

        ops = self._plan(existing, new)
        # Match ratio 1/4 = 0.25 < 0.3 → full overwrite
        deletes = [o for o in ops if o.op_type == DiffOpType.DELETE]
        inserts = [o for o in ops if o.op_type == DiffOpType.INSERT]
        assert len(deletes) == 4
        assert len(inserts) == 4

    def test_mixed_before_and_after_with_sufficient_anchors(self):
        """With enough anchors to exceed match ratio, diff logic applies."""
        existing = [
            _para("X1", "e0"),      # unmatched
            _para("A", "e1"),       # anchor 1
            _para("B", "e2"),       # anchor 2
            _para("C", "e3"),       # anchor 3
            _para("X2", "e4"),      # unmatched
        ]
        new = [
            _para("Y1"),            # unmatched
            _para("A"),             # anchor 1
            _para("B"),             # anchor 2
            _para("C"),             # anchor 3
            _para("Y2"),            # unmatched
        ]

        ops = self._plan(existing, new)
        keeps = [o for o in ops if o.op_type == DiffOpType.KEEP]
        assert len(keeps) == 3  # A, B, C


class TestUpgradeToUpdates:
    """Test the DELETE+INSERT → UPDATE/REPLACE upgrade logic.

    The upgrade logic in _upgrade_to_updates only runs when the diff path
    is used (match ratio >= 0.3). Tests must include enough matching anchors.
    """

    def _plan(self, existing, new):
        planner = DiffPlanner(NotionifyConfig(token="test"))
        return planner.plan(existing, new)

    def test_same_type_change_becomes_update(self):
        """Changing paragraph text with enough anchors should produce UPDATE."""
        existing = [
            _para("unchanged-1", "e0"),  # anchor
            _para("old text", "e1"),     # changed
            _para("unchanged-2", "e2"),  # anchor
        ]
        new = [
            _para("unchanged-1"),
            _para("new text"),           # changed same type
            _para("unchanged-2"),
        ]

        ops = self._plan(existing, new)
        updates = [o for o in ops if o.op_type == DiffOpType.UPDATE]
        assert len(updates) == 1
        assert updates[0].existing_id == "e1"

    def test_different_type_becomes_replace(self):
        """Changing block type with enough anchors should produce REPLACE."""
        existing = [
            _para("unchanged-1", "e0"),  # anchor
            _para("some text", "e1"),    # will be replaced
            _para("unchanged-2", "e2"),  # anchor
        ]
        new = [
            _para("unchanged-1"),
            _heading("some text"),       # different type
            _para("unchanged-2"),
        ]

        ops = self._plan(existing, new)
        replaces = [o for o in ops if o.op_type == DiffOpType.REPLACE]
        assert len(replaces) == 1
        assert replaces[0].existing_id == "e1"

    def test_multiple_changes_in_gap(self):
        """Multiple unmatched blocks in a gap: DELETEs emitted first, then INSERTs.

        The upgrade logic only pairs the boundary DELETE+INSERT, so with 3
        changed blocks in a gap, we get: 2 DELETEs + 1 UPDATE + 2 INSERTs.
        """
        existing = [
            _para("anchor-1", "e0"),  # anchor
            _para("A", "e1"),         # changed
            _para("B", "e2"),         # changed
            _para("C", "e3"),         # changed
            _para("anchor-2", "e4"),  # anchor
        ]
        new = [
            _para("anchor-1"),
            _para("A-modified"),
            _para("B-modified"),
            _para("C-modified"),
            _para("anchor-2"),
        ]

        ops = self._plan(existing, new)
        keeps = [o for o in ops if o.op_type == DiffOpType.KEEP]
        updates = [o for o in ops if o.op_type == DiffOpType.UPDATE]
        deletes = [o for o in ops if o.op_type == DiffOpType.DELETE]
        inserts = [o for o in ops if o.op_type == DiffOpType.INSERT]
        assert len(keeps) == 2  # anchor-1, anchor-2
        # The boundary DELETE+INSERT pair becomes an UPDATE
        assert len(updates) == 1
        # Remaining are unpaired deletes and inserts
        assert len(deletes) == 2
        assert len(inserts) == 2

    def test_single_change_in_gap_fully_upgraded(self):
        """A single changed block between anchors produces exactly one UPDATE."""
        existing = [
            _para("anchor-1", "e0"),
            _para("old", "e1"),
            _para("anchor-2", "e2"),
        ]
        new = [
            _para("anchor-1"),
            _para("new"),
            _para("anchor-2"),
        ]

        ops = self._plan(existing, new)
        keeps = [o for o in ops if o.op_type == DiffOpType.KEEP]
        updates = [o for o in ops if o.op_type == DiffOpType.UPDATE]
        assert len(keeps) == 2
        assert len(updates) == 1

    def test_low_match_ratio_skips_upgrade(self):
        """When match ratio < 0.3, full overwrite is used (no upgrade)."""
        existing = [_para("old text", "e1")]
        new = [_para("new text")]

        ops = self._plan(existing, new)
        # 0 matches / 1 = 0.0 < 0.3 → full overwrite → DELETE + INSERT
        assert len(ops) == 2
        assert ops[0].op_type == DiffOpType.DELETE
        assert ops[1].op_type == DiffOpType.INSERT


class TestFullOverwriteFallback:
    """Test the match ratio threshold for full overwrite."""

    def test_low_match_ratio_triggers_overwrite(self):
        """When match ratio < 0.3, planner falls back to full overwrite."""
        # 10 completely different existing blocks
        existing = [_para(f"old-{i}", f"e{i}") for i in range(10)]
        # 10 completely different new blocks
        new = [_heading(f"new-{i}") for i in range(10)]

        planner = DiffPlanner(NotionifyConfig(token="test"))
        ops = planner.plan(existing, new)

        # Full overwrite: 10 deletes + 10 inserts
        deletes = [o for o in ops if o.op_type == DiffOpType.DELETE]
        inserts = [o for o in ops if o.op_type == DiffOpType.INSERT]
        assert len(deletes) == 10
        assert len(inserts) == 10

    def test_high_match_ratio_uses_diff(self):
        """When match ratio is high, planner uses diff strategy."""
        # 10 blocks, 8 identical
        existing = [_para(f"text-{i}", f"e{i}") for i in range(10)]
        new = [_para(f"text-{i}") for i in range(10)]
        new[0] = _para("changed-0")
        new[9] = _para("changed-9")

        planner = DiffPlanner(NotionifyConfig(token="test"))
        ops = planner.plan(existing, new)

        keeps = [o for o in ops if o.op_type == DiffOpType.KEEP]
        assert len(keeps) >= 6  # most blocks should be kept


class TestAsyncExecutorMirror:
    """Verify the async executor mirrors sync executor behavior."""

    @pytest.fixture
    def mock_api(self):
        class AsyncMockBlockAPI:
            def __init__(self):
                self.updates = []
                self.deletes = []
                self.appends = []
                self._counter = 0

            async def update(self, block_id, payload):
                self.updates.append((block_id, payload))
                return {"id": block_id}

            async def delete(self, block_id):
                self.deletes.append(block_id)
                return {"id": block_id}

            async def append_children(self, parent_id, children, after=None):
                self.appends.append((parent_id, children, after))
                results = []
                for _ in children:
                    results.append({"id": f"new-{self._counter}"})
                    self._counter += 1
                return {"results": results}

        return AsyncMockBlockAPI()

    @pytest.mark.asyncio
    async def test_async_keep_and_delete(self, mock_api):
        config = NotionifyConfig(token="test")
        executor = AsyncDiffExecutor(mock_api, config)
        ops = [
            DiffOp(op_type=DiffOpType.KEEP, existing_id="blk-1"),
            DiffOp(op_type=DiffOpType.DELETE, existing_id="blk-2"),
        ]
        result = await executor.execute("page-1", ops)
        assert result.blocks_kept == 1
        assert result.blocks_deleted == 1
        assert "blk-2" in mock_api.deletes

    @pytest.mark.asyncio
    async def test_async_update(self, mock_api):
        config = NotionifyConfig(token="test")
        executor = AsyncDiffExecutor(mock_api, config)
        ops = [
            DiffOp(
                op_type=DiffOpType.UPDATE,
                existing_id="blk-1",
                new_block=_para("updated"),
            )
        ]
        result = await executor.execute("page-1", ops)
        assert len(mock_api.updates) == 1
        assert result.blocks_inserted == 1

    @pytest.mark.asyncio
    async def test_async_replace(self, mock_api):
        config = NotionifyConfig(token="test")
        executor = AsyncDiffExecutor(mock_api, config)
        ops = [
            DiffOp(
                op_type=DiffOpType.REPLACE,
                existing_id="blk-old",
                new_block=_para("replacement"),
            )
        ]
        result = await executor.execute("page-1", ops)
        assert "blk-old" in mock_api.deletes
        assert len(mock_api.appends) == 1
        assert result.blocks_replaced == 1

    @pytest.mark.asyncio
    async def test_async_consecutive_inserts(self, mock_api):
        config = NotionifyConfig(token="test")
        executor = AsyncDiffExecutor(mock_api, config)
        ops = [
            DiffOp(op_type=DiffOpType.INSERT, new_block=_para(f"p{i}"))
            for i in range(5)
        ]
        result = await executor.execute("page-1", ops)
        assert result.blocks_inserted == 5
        assert len(mock_api.appends) == 1


class TestSyncExecutor:
    """Verify the sync DiffExecutor edge cases."""

    @pytest.fixture
    def mock_api(self):
        class SyncMockBlockAPI:
            def __init__(self):
                self.updates = []
                self.deletes = []
                self.appends = []
                self._counter = 0

            def update(self, block_id, payload):
                self.updates.append((block_id, payload))
                return {"id": block_id}

            def delete(self, block_id):
                self.deletes.append(block_id)
                return {"id": block_id}

            def append_children(self, parent_id, children, after=None):
                self.appends.append((parent_id, children, after))
                results = []
                for _ in children:
                    results.append({"id": f"new-{self._counter}"})
                    self._counter += 1
                return {"results": results}

        return SyncMockBlockAPI()

    def test_empty_ops_returns_zero_counts(self, mock_api):
        """Empty operation list produces zero counts."""
        config = NotionifyConfig(token="test")
        executor = DiffExecutor(mock_api, config)
        result = executor.execute("page-1", [])
        assert result.blocks_kept == 0
        assert result.blocks_inserted == 0
        assert result.blocks_deleted == 0
        assert result.blocks_replaced == 0
        assert result.strategy_used == "diff"

    def test_keep_updates_last_block_id(self, mock_api):
        """KEEP operations advance last_block_id for correct insert positioning."""
        config = NotionifyConfig(token="test")
        executor = DiffExecutor(mock_api, config)
        ops = [
            DiffOp(op_type=DiffOpType.KEEP, existing_id="blk-1"),
            DiffOp(op_type=DiffOpType.INSERT, new_block=_para("new")),
        ]
        executor.execute("page-1", ops)
        # INSERT should be positioned after blk-1
        assert mock_api.appends[0][2] == "blk-1"  # after=blk-1

    def test_replace_tracks_new_block_id(self, mock_api):
        """REPLACE updates last_block_id from the newly inserted block."""
        config = NotionifyConfig(token="test")
        executor = DiffExecutor(mock_api, config)
        ops = [
            DiffOp(
                op_type=DiffOpType.REPLACE,
                existing_id="old-1",
                new_block=_para("replacement"),
            ),
            DiffOp(op_type=DiffOpType.INSERT, new_block=_para("after-replace")),
        ]
        executor.execute("page-1", ops)
        assert "old-1" in mock_api.deletes
        # Second append (the INSERT) should be after the replace's new block
        assert mock_api.appends[1][2] == "new-0"

    def test_update_with_none_existing_id_skips_api_call(self, mock_api):
        """UPDATE with None existing_id skips the API call but still advances."""
        config = NotionifyConfig(token="test")
        executor = DiffExecutor(mock_api, config)
        ops = [
            DiffOp(op_type=DiffOpType.UPDATE, existing_id=None, new_block=_para("x")),
        ]
        result = executor.execute("page-1", ops)
        assert len(mock_api.updates) == 0
        assert result.blocks_inserted == 1  # still counted as write

    def test_update_with_none_new_block_skips_api_call(self, mock_api):
        """UPDATE with None new_block skips the API call."""
        config = NotionifyConfig(token="test")
        executor = DiffExecutor(mock_api, config)
        ops = [
            DiffOp(op_type=DiffOpType.UPDATE, existing_id="blk-1", new_block=None),
        ]
        _result = executor.execute("page-1", ops)
        assert len(mock_api.updates) == 0

    def test_delete_with_none_existing_id(self, mock_api):
        """DELETE with None existing_id skips the API call but counts it."""
        config = NotionifyConfig(token="test")
        executor = DiffExecutor(mock_api, config)
        ops = [
            DiffOp(op_type=DiffOpType.DELETE, existing_id=None),
        ]
        result = executor.execute("page-1", ops)
        assert len(mock_api.deletes) == 0
        assert result.blocks_deleted == 1  # still counted

    def test_replace_with_none_new_block(self, mock_api):
        """REPLACE with None new_block still deletes the existing block."""
        config = NotionifyConfig(token="test")
        executor = DiffExecutor(mock_api, config)
        ops = [
            DiffOp(op_type=DiffOpType.REPLACE, existing_id="old-1", new_block=None),
        ]
        result = executor.execute("page-1", ops)
        assert "old-1" in mock_api.deletes
        assert result.blocks_deleted == 1
        assert result.blocks_replaced == 0  # no insert happened

    def test_insert_with_none_new_block_skipped(self, mock_api):
        """INSERT ops with None new_block are silently filtered out."""
        config = NotionifyConfig(token="test")
        executor = DiffExecutor(mock_api, config)
        ops = [
            DiffOp(op_type=DiffOpType.INSERT, new_block=None),
            DiffOp(op_type=DiffOpType.INSERT, new_block=_para("real")),
        ]
        result = executor.execute("page-1", ops)
        assert result.blocks_inserted == 1
        assert len(mock_api.appends) == 1

    def test_append_response_without_results_key(self, mock_api):
        """If append_children returns no 'results', last_block_id stays None."""
        mock_api.append_children = lambda pid, ch, after=None: {}
        config = NotionifyConfig(token="test")
        executor = DiffExecutor(mock_api, config)
        ops = [
            DiffOp(op_type=DiffOpType.INSERT, new_block=_para("a")),
            DiffOp(op_type=DiffOpType.INSERT, new_block=_para("b")),
        ]
        result = executor.execute("page-1", ops)
        assert result.blocks_inserted == 2

    def test_mixed_ops_sequence(self, mock_api):
        """Full scenario: KEEP → UPDATE → DELETE → INSERT → REPLACE."""
        config = NotionifyConfig(token="test")
        executor = DiffExecutor(mock_api, config)
        ops = [
            DiffOp(op_type=DiffOpType.KEEP, existing_id="blk-1"),
            DiffOp(op_type=DiffOpType.UPDATE, existing_id="blk-2", new_block=_para("updated")),
            DiffOp(op_type=DiffOpType.DELETE, existing_id="blk-3"),
            DiffOp(op_type=DiffOpType.INSERT, new_block=_para("inserted")),
            DiffOp(op_type=DiffOpType.REPLACE, existing_id="blk-4", new_block=_heading("title")),
        ]
        result = executor.execute("page-1", ops)
        assert result.blocks_kept == 1
        assert result.blocks_inserted == 2  # UPDATE + INSERT both counted
        assert result.blocks_deleted == 2  # DELETE + REPLACE's delete
        assert result.blocks_replaced == 1


class TestPlannerEdgeCases:
    """Test edge cases in planner logic."""

    def _plan(self, existing, new):
        planner = DiffPlanner(NotionifyConfig(token="test"))
        return planner.plan(existing, new)

    def test_existing_blocks_missing_id_field(self):
        """Blocks without 'id' should produce ops with existing_id=None."""
        existing = [
            {
                "type": "paragraph",
                "paragraph": {
                    "rich_text": [{"plain_text": "A"}],
                    "color": "default",
                },
            },
        ]
        new = []
        ops = self._plan(existing, new)
        assert len(ops) == 1
        assert ops[0].op_type == DiffOpType.DELETE
        assert ops[0].existing_id is None

    def test_upgrade_delete_insert_with_mismatched_types(self):
        """DELETE paragraph + INSERT heading → REPLACE (type differs)."""
        existing = [
            _para("anchor-1", "e0"),
            _para("text", "e1"),
            _para("anchor-2", "e2"),
        ]
        new = [
            _para("anchor-1"),
            _heading("text"),  # different type
            _para("anchor-2"),
        ]
        ops = self._plan(existing, new)
        replaces = [o for o in ops if o.op_type == DiffOpType.REPLACE]
        assert len(replaces) == 1
        assert replaces[0].existing_id == "e1"
        assert replaces[0].new_block["type"] == "heading_1"

    def test_upgrade_with_children_uses_replace(self):
        """Same-type block with children must REPLACE, not UPDATE.

        The Notion PATCH API ignores children in the payload, so blocks
        with nested children must be deleted and re-inserted.
        """
        existing = [
            _para("anchor-1", "e0"),
            {
                "type": "bulleted_list_item",
                "id": "e1",
                "bulleted_list_item": {
                    "rich_text": [{"plain_text": "item"}],
                    "color": "default",
                },
                "has_children": True,
            },
            _para("anchor-2", "e2"),
        ]
        new = [
            _para("anchor-1"),
            {
                "type": "bulleted_list_item",
                "bulleted_list_item": {
                    "rich_text": [{"plain_text": "item modified"}],
                    "color": "default",
                    "children": [_para("nested child")],
                },
            },
            _para("anchor-2"),
        ]
        ops = self._plan(existing, new)
        replaces = [o for o in ops if o.op_type == DiffOpType.REPLACE]
        updates = [o for o in ops if o.op_type == DiffOpType.UPDATE]
        assert len(replaces) == 1, f"Expected REPLACE for block with children, got: {ops}"
        assert len(updates) == 0
        assert replaces[0].existing_id == "e1"

    def test_full_overwrite_preserves_block_order(self):
        """Full overwrite produces DELETEs before INSERTs in order."""
        existing = [_para("A", "e1"), _para("B", "e2")]
        new = [_heading("X"), _heading("Y")]
        ops = self._plan(existing, new)
        deletes = [o for o in ops if o.op_type == DiffOpType.DELETE]
        # All deletes come before all inserts
        last_delete_idx = max(i for i, o in enumerate(ops) if o.op_type == DiffOpType.DELETE)
        first_insert_idx = min(i for i, o in enumerate(ops) if o.op_type == DiffOpType.INSERT)
        assert last_delete_idx < first_insert_idx
        assert deletes[0].existing_id == "e1"
        assert deletes[1].existing_id == "e2"


class TestSyncExecutorBranchCoverage:
    """Branch coverage for DiffExecutor._exec_replace and _exec_insert_batch."""

    @pytest.fixture
    def mock_api(self):
        class SyncMockBlockAPI:
            def __init__(self):
                self.updates = []
                self.deletes = []
                self.appends = []
                self._counter = 0

            def update(self, block_id, payload):
                self.updates.append((block_id, payload))
                return {"id": block_id}

            def delete(self, block_id):
                self.deletes.append(block_id)
                return {"id": block_id}

            def append_children(self, parent_id, children, after=None):
                self.appends.append((parent_id, children, after))
                results = [{"id": f"new-{self._counter + i}"} for i in range(len(children))]
                self._counter += len(children)
                return {"results": results}

        return SyncMockBlockAPI()

    def test_replace_with_none_existing_id_skips_delete(self, mock_api):
        """REPLACE with existing_id=None skips delete API call — covers 122->125."""
        config = NotionifyConfig(token="test")
        executor = DiffExecutor(mock_api, config)
        ops = [
            DiffOp(
                op_type=DiffOpType.REPLACE,
                existing_id=None,
                new_block=_para("new-content"),
            ),
        ]
        result = executor.execute("page-1", ops)
        assert len(mock_api.deletes) == 0  # no delete API call
        assert result.blocks_replaced == 1  # new block was inserted

    def test_replace_empty_append_response_no_crash(self, mock_api):
        """REPLACE where append_children returns no IDs — covers 130->132."""
        mock_api.append_children = lambda pid, ch, after=None: {}  # no results key
        config = NotionifyConfig(token="test")
        executor = DiffExecutor(mock_api, config)
        ops = [
            DiffOp(
                op_type=DiffOpType.REPLACE,
                existing_id="old-1",
                new_block=_para("replacement"),
            ),
        ]
        result = executor.execute("page-1", ops)
        assert "old-1" in mock_api.deletes
        assert result.blocks_replaced == 1

    def test_insert_all_none_blocks_no_api_call(self, mock_api):
        """All INSERT ops with None new_block → empty insert_blocks → 146->155."""
        config = NotionifyConfig(token="test")
        executor = DiffExecutor(mock_api, config)
        ops = [
            DiffOp(op_type=DiffOpType.INSERT, new_block=None),
            DiffOp(op_type=DiffOpType.INSERT, new_block=None),
        ]
        result = executor.execute("page-1", ops)
        assert len(mock_api.appends) == 0  # no API call made
        assert result.blocks_inserted == 0

    def test_unknown_op_type_is_skipped(self, mock_api):
        """An op with an unknown type falls through to the else clause (line 104)."""
        config = NotionifyConfig(token="test")
        executor = DiffExecutor(mock_api, config)

        class _FakeOpType:
            value = "UNKNOWN"

        fake_op = DiffOp(op_type=_FakeOpType(), existing_id="blk-x")  # type: ignore[arg-type]
        executor.execute("page-1", [fake_op])
        # Should not crash; no API calls made
        assert len(mock_api.deletes) == 0


class TestAsyncExecutorBranchCoverage:
    """Branch coverage for AsyncDiffExecutor edge cases."""

    @pytest.fixture
    def mock_api(self):
        class AsyncMockBlockAPI:
            def __init__(self):
                self.updates = []
                self.deletes = []
                self.appends = []
                self._counter = 0

            async def update(self, block_id, payload):
                self.updates.append((block_id, payload))
                return {"id": block_id}

            async def delete(self, block_id):
                self.deletes.append(block_id)
                return {"id": block_id}

            async def append_children(self, parent_id, children, after=None):
                self.appends.append((parent_id, children, after))
                results = [{"id": f"new-{self._counter + i}"} for i in range(len(children))]
                self._counter += len(children)
                return {"results": results}

        return AsyncMockBlockAPI()

    @pytest.mark.asyncio
    async def test_async_delete_with_none_id_skips_api(self, mock_api):
        """Async DELETE with existing_id=None skips delete API — covers 221->223."""
        config = NotionifyConfig(token="test")
        executor = AsyncDiffExecutor(mock_api, config)
        ops = [DiffOp(op_type=DiffOpType.DELETE, existing_id=None)]
        result = await executor.execute("page-1", ops)
        assert len(mock_api.deletes) == 0
        assert result.blocks_deleted == 1

    @pytest.mark.asyncio
    async def test_async_replace_with_none_existing_id(self, mock_api):
        """Async REPLACE with existing_id=None skips delete — covers 245->248."""
        config = NotionifyConfig(token="test")
        executor = AsyncDiffExecutor(mock_api, config)
        ops = [
            DiffOp(
                op_type=DiffOpType.REPLACE,
                existing_id=None,
                new_block=_para("replacement"),
            ),
        ]
        result = await executor.execute("page-1", ops)
        assert len(mock_api.deletes) == 0
        assert result.blocks_replaced == 1

    @pytest.mark.asyncio
    async def test_async_replace_with_none_new_block(self, mock_api):
        """Async REPLACE with new_block=None skips insert — covers 248->exit."""
        config = NotionifyConfig(token="test")
        executor = AsyncDiffExecutor(mock_api, config)
        ops = [
            DiffOp(
                op_type=DiffOpType.REPLACE,
                existing_id="old-1",
                new_block=None,
            ),
        ]
        result = await executor.execute("page-1", ops)
        assert "old-1" in mock_api.deletes
        assert result.blocks_replaced == 0

    @pytest.mark.asyncio
    async def test_async_replace_empty_append_response(self, mock_api):
        """Async REPLACE where append returns no IDs — covers 253->255."""
        mock_api.append_children = (
            lambda pid, ch, after=None: __import__('asyncio').coroutine(lambda: {})()
        )

        async def empty_append(pid, ch, after=None):
            return {}

        mock_api.append_children = empty_append
        config = NotionifyConfig(token="test")
        executor = AsyncDiffExecutor(mock_api, config)
        ops = [
            DiffOp(
                op_type=DiffOpType.REPLACE,
                existing_id="old-1",
                new_block=_para("new"),
            ),
        ]
        result = await executor.execute("page-1", ops)
        assert result.blocks_replaced == 1

    @pytest.mark.asyncio
    async def test_async_insert_with_none_block_skipped(self, mock_api):
        """Async INSERT with None block doesn't add to insert_blocks — covers 265->267."""
        config = NotionifyConfig(token="test")
        executor = AsyncDiffExecutor(mock_api, config)
        ops = [
            DiffOp(op_type=DiffOpType.INSERT, new_block=None),
            DiffOp(op_type=DiffOpType.INSERT, new_block=_para("real")),
        ]
        result = await executor.execute("page-1", ops)
        assert result.blocks_inserted == 1

    @pytest.mark.asyncio
    async def test_async_insert_all_none_blocks(self, mock_api):
        """All async INSERT ops with None → empty insert_blocks — covers 269->278."""
        config = NotionifyConfig(token="test")
        executor = AsyncDiffExecutor(mock_api, config)
        ops = [
            DiffOp(op_type=DiffOpType.INSERT, new_block=None),
            DiffOp(op_type=DiffOpType.INSERT, new_block=None),
        ]
        result = await executor.execute("page-1", ops)
        assert len(mock_api.appends) == 0
        assert result.blocks_inserted == 0

    @pytest.mark.asyncio
    async def test_async_insert_empty_append_response(self, mock_api):
        """Async INSERT where append returns no IDs — covers 275->270."""
        async def empty_append(pid, ch, after=None):
            return {}

        mock_api.append_children = empty_append
        config = NotionifyConfig(token="test")
        executor = AsyncDiffExecutor(mock_api, config)
        ops = [
            DiffOp(op_type=DiffOpType.INSERT, new_block=_para("a")),
        ]
        result = await executor.execute("page-1", ops)
        assert result.blocks_inserted == 1

    @pytest.mark.asyncio
    async def test_async_update_with_none_existing_id(self, mock_api):
        """Async UPDATE with existing_id=None skips API — covers 204->209."""
        config = NotionifyConfig(token="test")
        executor = AsyncDiffExecutor(mock_api, config)
        ops = [
            DiffOp(op_type=DiffOpType.UPDATE, existing_id=None, new_block=_para("x")),
        ]
        result = await executor.execute("page-1", ops)
        assert len(mock_api.updates) == 0
        assert result.blocks_inserted == 1

    @pytest.mark.asyncio
    async def test_async_unknown_op_type_skipped(self, mock_api):
        """Unknown op type falls to else clause (line 227)."""
        config = NotionifyConfig(token="test")
        executor = AsyncDiffExecutor(mock_api, config)

        class _FakeOpType:
            value = "UNKNOWN"

        fake_op = DiffOp(op_type=_FakeOpType(), existing_id="blk-x")  # type: ignore[arg-type]
        await executor.execute("page-1", [fake_op])
        assert len(mock_api.deletes) == 0


class TestUpgradeToUpdatesBlockWithNoId:
    """Branch coverage for _upgrade_to_updates (planner.py 223->220).

    Covers the False branch of ``if bid and btype:`` when an existing block
    lacks an ``id`` field so it is silently skipped in the id_to_type map.
    """

    def test_existing_block_without_id_skipped_in_id_map(self):
        """Existing block without 'id' triggers False branch at 223->220."""
        # existing[0] has no 'id'; existing[1] is the LCS anchor.
        existing = [
            _para("changed"),           # no id → triggers 223->220 False branch
            _para("anchor", "e2"),       # has id, matches new[1]
        ]
        new = [
            _heading("changed"),        # different type → DELETE+INSERT → REPLACE
            _para("anchor"),            # matches existing[1] → KEEP
        ]
        planner = DiffPlanner(NotionifyConfig(token="test"))
        ops = planner.plan(existing, new)
        # Should produce a REPLACE for the changed block and KEEP for the anchor
        op_types = {o.op_type for o in ops}
        assert DiffOpType.REPLACE in op_types or DiffOpType.DELETE in op_types

    def test_existing_block_with_id_but_no_type_treated_as_unknown(self):
        """Existing block with 'id' but no 'type' skips id_to_type insertion.

        When bid is truthy but btype is falsy, the block is silently omitted
        from id_to_type.  A DELETE+INSERT pair for that block is therefore
        treated as REPLACE (different or unknown type).
        """
        existing = [
            {"id": "e1"},               # has id, NO type → btype is None → skipped
            _para("anchor", "e2"),
        ]
        new = [
            _heading("changed"),        # DELETE+INSERT against id-only block
            _para("anchor"),
        ]
        planner = DiffPlanner(NotionifyConfig(token="test"))
        ops = planner.plan(existing, new)
        op_types = {o.op_type for o in ops}
        assert DiffOpType.REPLACE in op_types or DiffOpType.DELETE in op_types


class TestTableRowDiffing:
    """Planner-level tests for table_row block diff correctness.

    Validates that cell-content changes in table_row blocks are detected by
    the diff planner (relying on the fixed _normalize_table_row_cells
    signature logic).
    """

    def test_unchanged_table_rows_produce_keep(self):
        """Two identical table_row blocks → KEEP (no change)."""
        existing = [_table_row([["A"], ["B"]], "r1")]
        new = [_table_row([["A"], ["B"]])]
        planner = DiffPlanner(NotionifyConfig(token="test"))
        ops = planner.plan(existing, new)
        assert len(ops) == 1
        assert ops[0].op_type == DiffOpType.KEEP

    def test_changed_cell_content_produces_replace(self):
        """A table_row with different cell content triggers REPLACE, not KEEP."""
        existing = [_table_row([["Old value"], ["B"]], "r1")]
        new = [_table_row([["New value"], ["B"]])]
        planner = DiffPlanner(NotionifyConfig(token="test"))
        ops = planner.plan(existing, new)
        op_types = {o.op_type for o in ops}
        # Must detect the change — cannot be a KEEP
        assert DiffOpType.KEEP not in op_types
        assert DiffOpType.DELETE in op_types or DiffOpType.REPLACE in op_types

    def test_added_column_produces_replace(self):
        """Adding a column (more cells) triggers REPLACE, not KEEP."""
        existing = [_table_row([["A"], ["B"]], "r1")]
        new = [_table_row([["A"], ["B"], ["C"]])]
        planner = DiffPlanner(NotionifyConfig(token="test"))
        ops = planner.plan(existing, new)
        op_types = {o.op_type for o in ops}
        assert DiffOpType.KEEP not in op_types

    def test_reordered_cells_produces_replace(self):
        """Swapping two cells (["A","B"] → ["B","A"]) triggers REPLACE."""
        existing = [_table_row([["A"], ["B"]], "r1")]
        new = [_table_row([["B"], ["A"]])]
        planner = DiffPlanner(NotionifyConfig(token="test"))
        ops = planner.plan(existing, new)
        op_types = {o.op_type for o in ops}
        assert DiffOpType.KEEP not in op_types

    def test_multiple_rows_partial_change(self):
        """In a sequence of rows, only the changed row differs; others are KEEP."""
        existing = [
            _table_row([["H1"], ["H2"]], "r1"),
            _table_row([["original"], ["data"]], "r2"),
            _table_row([["footer"], ["end"]], "r3"),
        ]
        new = [
            _table_row([["H1"], ["H2"]]),
            _table_row([["updated"], ["data"]]),  # changed
            _table_row([["footer"], ["end"]]),
        ]
        planner = DiffPlanner(NotionifyConfig(token="test"))
        ops = planner.plan(existing, new)
        keep_ops = [o for o in ops if o.op_type == DiffOpType.KEEP]
        # At least the unchanged rows (H1/H2 and footer) must be KEEPs
        assert len(keep_ops) >= 2
