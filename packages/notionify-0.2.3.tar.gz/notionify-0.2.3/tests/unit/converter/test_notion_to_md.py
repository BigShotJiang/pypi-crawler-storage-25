"""Tests for NotionToMarkdownRenderer.

PRD test IDs: U-NM-001 through U-NM-022.
"""

import pytest

from notionify.config import NotionifyConfig
from notionify.converter.notion_to_md import NotionToMarkdownRenderer
from notionify.errors import NotionifyUnsupportedBlockError


def make_config(**kwargs):
    return NotionifyConfig(token="test-token", **kwargs)


def _make_annotations(
    bold=False, italic=False, code=False,
    strikethrough=False, underline=False, color="default",
):
    return {
        "bold": bold,
        "italic": italic,
        "code": code,
        "strikethrough": strikethrough,
        "underline": underline,
        "color": color,
    }


def _make_text_segment(content, **ann_kwargs):
    """Build a single rich_text text segment."""
    return {
        "type": "text",
        "text": {"content": content},
        "plain_text": content,
        "annotations": _make_annotations(**ann_kwargs),
        "href": None,
    }


def _make_link_segment(content, url):
    """Build a rich_text segment with a link."""
    return {
        "type": "text",
        "text": {"content": content, "link": {"url": url}},
        "plain_text": content,
        "annotations": _make_annotations(),
        "href": url,
    }


def _make_equation_segment(expression):
    """Build a rich_text equation segment."""
    return {
        "type": "equation",
        "equation": {"expression": expression},
        "plain_text": expression,
        "annotations": _make_annotations(),
        "href": None,
    }


def make_heading(level, text):
    return {
        "type": f"heading_{level}",
        f"heading_{level}": {
            "rich_text": [_make_text_segment(text)],
        },
    }


def make_paragraph(rich_text_segments, children=None):
    block = {
        "type": "paragraph",
        "paragraph": {
            "rich_text": rich_text_segments,
        },
    }
    if children:
        block["paragraph"]["children"] = children
    return block


def make_code_block(code, language="python"):
    return {
        "type": "code",
        "code": {
            "rich_text": [_make_text_segment(code)],
            "language": language,
        },
    }


def make_divider():
    return {
        "type": "divider",
        "divider": {},
    }


def make_equation_block(expression):
    return {
        "type": "equation",
        "equation": {
            "expression": expression,
        },
    }


def make_bulleted_list_item(text, children=None):
    block = {
        "type": "bulleted_list_item",
        "bulleted_list_item": {
            "rich_text": [_make_text_segment(text)],
        },
    }
    if children:
        block["bulleted_list_item"]["children"] = children
    return block


def make_numbered_list_item(text, children=None):
    block = {
        "type": "numbered_list_item",
        "numbered_list_item": {
            "rich_text": [_make_text_segment(text)],
        },
    }
    if children:
        block["numbered_list_item"]["children"] = children
    return block


def make_to_do(text, checked=False):
    return {
        "type": "to_do",
        "to_do": {
            "rich_text": [_make_text_segment(text)],
            "checked": checked,
        },
    }


def make_quote(text, children=None):
    block = {
        "type": "quote",
        "quote": {
            "rich_text": [_make_text_segment(text)],
        },
    }
    if children:
        block["quote"]["children"] = children
    return block


def make_image_external(url, caption=""):
    block = {
        "type": "image",
        "image": {
            "type": "external",
            "external": {"url": url},
        },
    }
    if caption:
        block["image"]["caption"] = [_make_text_segment(caption)]
    else:
        block["image"]["caption"] = []
    return block


def make_table_block(header_cells, body_rows, has_column_header=True, has_row_header=False):
    """Build a Notion table block with rows as children.

    header_cells: list of strings for the header row
    body_rows: list of list of strings for body rows
    """
    col_count = len(header_cells)
    rows = []

    # Header row
    header_row = {
        "type": "table_row",
        "table_row": {
            "cells": [
                [_make_text_segment(cell)] for cell in header_cells
            ],
        },
    }
    rows.append(header_row)

    # Body rows
    for row_data in body_rows:
        row = {
            "type": "table_row",
            "table_row": {
                "cells": [
                    [_make_text_segment(cell)] for cell in row_data
                ],
            },
        }
        rows.append(row)

    return {
        "type": "table",
        "table": {
            "table_width": col_count,
            "has_column_header": has_column_header,
            "has_row_header": has_row_header,
            "children": rows,
        },
    }


# =========================================================================
# U-NM-001: heading_1/2/3 -> #/##/###
# =========================================================================

class TestHeadingRendering:
    """U-NM-001: Notion headings render to Markdown headings."""

    @pytest.mark.parametrize(("level", "prefix", "text"), [
        (1, "#", "Title"),
        (2, "##", "Subtitle"),
        (3, "###", "Section"),
    ])
    def test_heading_level(self, level: int, prefix: str, text: str):
        r = NotionToMarkdownRenderer(make_config())
        md = r.render_blocks([make_heading(level, text)])
        assert md.strip() == f"{prefix} {text}"

    def test_multiple_headings(self):
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_heading(1, "H1"), make_heading(2, "H2"), make_heading(3, "H3")]
        md = r.render_blocks(blocks)
        assert "# H1" in md
        assert "## H2" in md
        assert "### H3" in md

    def test_toggle_heading_renders_children(self):
        """Toggle headings (is_toggleable=True) must render their children."""
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "heading_2",
            "heading_2": {
                "rich_text": [_make_text_segment("Toggle Section")],
                "is_toggleable": True,
                "color": "default",
            },
            "children": [
                {
                    "type": "paragraph",
                    "paragraph": {"rich_text": [_make_text_segment("Hidden content")]},
                }
            ],
        }
        md = r.render_blocks([block])
        assert "## Toggle Section" in md
        assert "Hidden content" in md

    def test_non_toggle_heading_no_children(self):
        """Regular headings without children render only the heading text."""
        r = NotionToMarkdownRenderer(make_config())
        block = make_heading(1, "Plain Heading")
        md = r.render_blocks([block])
        assert "# Plain Heading" in md
        lines = [ln for ln in md.strip().split("\n") if ln.strip()]
        assert len(lines) == 1


# =========================================================================
# U-NM-002: paragraph with bold
# =========================================================================

class TestParagraphAnnotation:
    """U-NM-002/003: Paragraph with bold/italic annotations."""

    @pytest.mark.parametrize(("annotation", "text", "expected"), [
        ("bold", "hello", "**hello**"),
        ("italic", "world", "_world_"),
    ])
    def test_annotation_rendering(self, annotation: str, text: str, expected: str):
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_paragraph([_make_text_segment(text, **{annotation: True})])]
        md = r.render_blocks(blocks)
        assert expected in md


# =========================================================================
# U-NM-004: link
# =========================================================================

class TestLinkRendering:
    """U-NM-004: Links render as [text](url)."""

    def test_link(self):
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_paragraph([_make_link_segment("click", "https://example.com")])]
        md = r.render_blocks(blocks)
        assert "[click](https://example.com)" in md


# =========================================================================
# U-NM-005: inline equation
# =========================================================================

class TestInlineEquation:
    """U-NM-005: Inline equation renders as $expression$."""

    def test_inline_equation(self):
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_paragraph([
            _make_text_segment("The formula "),
            _make_equation_segment("E=mc^2"),
            _make_text_segment(" is famous."),
        ])]
        md = r.render_blocks(blocks)
        assert "$E=mc^2$" in md


# =========================================================================
# U-NM-006: nested bulleted_list_item
# =========================================================================

class TestNestedBulletedList:
    """U-NM-006: Bulleted list items with children render nested."""

    def test_nested_bullet_list(self):
        r = NotionToMarkdownRenderer(make_config())
        child = make_bulleted_list_item("child")
        parent = make_bulleted_list_item("parent", children=[child])
        md = r.render_blocks([parent])
        assert "- parent" in md
        assert "- child" in md

    def test_flat_bullet_list(self):
        r = NotionToMarkdownRenderer(make_config())
        blocks = [
            make_bulleted_list_item("first"),
            make_bulleted_list_item("second"),
        ]
        md = r.render_blocks(blocks)
        assert "- first" in md
        assert "- second" in md


# =========================================================================
# U-NM-007: numbered_list_item
# =========================================================================

class TestNumberedList:
    """U-NM-007: Numbered list items render with numbers."""

    def test_numbered_list(self):
        r = NotionToMarkdownRenderer(make_config())
        blocks = [
            make_numbered_list_item("first"),
            make_numbered_list_item("second"),
            make_numbered_list_item("third"),
        ]
        md = r.render_blocks(blocks)
        assert "1. first" in md
        assert "2. second" in md
        assert "3. third" in md

    def test_numbered_list_resets_after_other_block(self):
        r = NotionToMarkdownRenderer(make_config())
        blocks = [
            make_numbered_list_item("first"),
            make_paragraph([_make_text_segment("break")]),
            make_numbered_list_item("restart"),
        ]
        md = r.render_blocks(blocks)
        assert "1. first" in md
        # After a paragraph, numbering should restart
        assert "1. restart" in md

    def test_two_numbered_lists_separated_by_heading(self):
        """Two separate numbered lists separated by heading each start at 1."""
        r = NotionToMarkdownRenderer(make_config())
        blocks = [
            make_numbered_list_item("alpha"),
            make_numbered_list_item("beta"),
            make_heading(2, "Section"),
            make_numbered_list_item("gamma"),
            make_numbered_list_item("delta"),
        ]
        md = r.render_blocks(blocks)
        assert "1. alpha" in md
        assert "2. beta" in md
        assert "1. gamma" in md
        assert "2. delta" in md

    def test_long_numbered_list_counts_correctly(self):
        """Numbered lists with many items count correctly beyond 9."""
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_numbered_list_item(f"item {i}") for i in range(12)]
        md = r.render_blocks(blocks)
        assert "10. item 9" in md
        assert "11. item 10" in md
        assert "12. item 11" in md


# =========================================================================
# U-NM-008: to_do checked
# =========================================================================

class TestToDoRendering:
    """U-NM-008/009: To-do items render with checkbox markers."""

    @pytest.mark.parametrize(("text", "checked", "marker"), [
        ("done", True, "- [x] done"),
        ("pending", False, "- [ ] pending"),
    ])
    def test_todo_checkbox(self, text: str, checked: bool, marker: str):
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_to_do(text, checked=checked)]
        md = r.render_blocks(blocks)
        assert marker in md


# =========================================================================
# U-NM-010: code block python
# =========================================================================

class TestCodeBlockRendering:
    """U-NM-010: Code blocks render with fenced syntax and language."""

    def test_code_block_python(self):
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_code_block("print('hello')", language="python")]
        md = r.render_blocks(blocks)
        assert "```python" in md
        assert "print('hello')" in md
        assert "```" in md

    def test_code_block_plain_text(self):
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_code_block("some code", language="plain text")]
        md = r.render_blocks(blocks)
        # plain text language should render as empty info string
        assert "```\n" in md
        assert "some code" in md

    def test_code_block_latex_detect(self):
        """With detect_latex_code=True, code blocks with language=latex become math."""
        r = NotionToMarkdownRenderer(make_config(detect_latex_code=True))
        blocks = [make_code_block("E=mc^2", language="latex")]
        md = r.render_blocks(blocks)
        assert "$$" in md
        assert "E=mc^2" in md
        assert "```" not in md

    def test_code_block_latex_no_detect(self):
        """With detect_latex_code=False, latex code blocks stay as code."""
        r = NotionToMarkdownRenderer(make_config(detect_latex_code=False))
        blocks = [make_code_block("E=mc^2", language="latex")]
        md = r.render_blocks(blocks)
        assert "```latex" in md
        assert "E=mc^2" in md

    def test_code_block_with_caption(self):
        """Code block captions render as blockquote below the fence."""
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "code",
            "code": {
                "rich_text": [_make_text_segment("x = 1")],
                "language": "python",
                "caption": [_make_text_segment("Example assignment")],
            },
        }
        md = r.render_blocks([block])
        assert "```python" in md
        assert "x = 1" in md
        assert "> Example assignment" in md

    def test_code_block_multiline_caption_fully_blockquoted(self):
        """Multi-line captions must have every line prefixed with '> '."""
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "code",
            "code": {
                "rich_text": [_make_text_segment("x = 1")],
                "language": "python",
                "caption": [_make_text_segment("Line 1\nLine 2\nLine 3")],
            },
        }
        md = r.render_blocks([block])
        assert "> Line 1" in md
        assert "> Line 2" in md
        assert "> Line 3" in md
        # No unquoted lines between caption lines
        lines = md.strip().split("\n")
        caption_started = False
        for line in lines:
            if line.startswith("> Line 1"):
                caption_started = True
            if caption_started and line.startswith("Line"):
                # Found an unquoted caption line
                raise AssertionError(f"Unquoted caption line: {line!r}")

    def test_code_block_without_caption_no_blockquote(self):
        """Code blocks without caption do not emit a blockquote line."""
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_code_block("x = 1", language="python")]
        md = r.render_blocks(blocks)
        assert ">" not in md


# =========================================================================
# U-NM-011: divider
# =========================================================================

class TestDividerRendering:
    """U-NM-011: Divider blocks render as ---."""

    def test_divider(self):
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_divider()]
        md = r.render_blocks(blocks)
        assert "---" in md


# =========================================================================
# U-NM-012: equation block
# =========================================================================

class TestEquationBlockRendering:
    """U-NM-012: Equation blocks render as $$...$$."""

    def test_equation_block(self):
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_equation_block("\\int_0^1 x dx")]
        md = r.render_blocks(blocks)
        assert "$$" in md
        assert "\\int_0^1 x dx" in md


# =========================================================================
# U-NM-013: table 3x3
# =========================================================================

class TestTableRendering:
    """U-NM-013: Table blocks render as GFM tables."""

    def test_table_3x3(self):
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_table_block(
            header_cells=["A", "B", "C"],
            body_rows=[["1", "2", "3"], ["4", "5", "6"]],
        )]
        md = r.render_blocks(blocks)
        assert "| A | B | C |" in md
        assert "|---|---|---|" in md
        assert "| 1 | 2 | 3 |" in md
        assert "| 4 | 5 | 6 |" in md

    def test_table_cell_with_pipe_character(self):
        """Pipe character in cell content should not break table syntax."""
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_table_block(
            header_cells=["Command", "Output"],
            body_rows=[["echo a", "a"]],
        )]
        md = r.render_blocks(blocks)
        assert "Command" in md
        assert "Output" in md
        # Table structure should be valid (has header separator)
        assert "|---" in md

    def test_table_cell_with_bold_annotation(self):
        """Table cell with bold annotation should render correctly."""
        r = NotionToMarkdownRenderer(make_config())
        bold_cell = _make_text_segment("important", bold=True)
        blocks = [{
            "type": "table",
            "table": {
                "table_width": 2,
                "has_column_header": True,
                "has_row_header": False,
                "children": [
                    {"type": "table_row", "table_row": {
                        "cells": [[_make_text_segment("Header")], [_make_text_segment("Info")]],
                    }},
                    {"type": "table_row", "table_row": {
                        "cells": [[bold_cell], [_make_text_segment("text")]],
                    }},
                ],
            },
        }]
        md = r.render_blocks(blocks)
        assert "**important**" in md
        assert "text" in md

    def test_table_cell_newline_replaced_with_br(self):
        """Newlines in cell content must become <br> to preserve GFM row structure."""
        r = NotionToMarkdownRenderer(make_config())
        blocks = [{
            "type": "table",
            "table": {
                "table_width": 2,
                "has_column_header": True,
                "has_row_header": False,
                "children": [
                    {"type": "table_row", "table_row": {
                        "cells": [[_make_text_segment("Col")], [_make_text_segment("Info")]],
                    }},
                    {"type": "table_row", "table_row": {
                        "cells": [
                            [_make_text_segment("line1\nline2")],
                            [_make_text_segment("ok")],
                        ],
                    }},
                ],
            },
        }]
        md = r.render_blocks(blocks)
        assert "line1<br>line2" in md
        # Each row must be a single line
        table_lines = [ln for ln in md.strip().split("\n") if ln.startswith("|")]
        for line in table_lines:
            assert "\n" not in line

    def test_table_empty_cell(self):
        """Table with empty cells should render without crashing."""
        r = NotionToMarkdownRenderer(make_config())
        blocks = [{
            "type": "table",
            "table": {
                "table_width": 2,
                "has_column_header": True,
                "has_row_header": False,
                "children": [
                    {"type": "table_row", "table_row": {
                        "cells": [[_make_text_segment("A")], [_make_text_segment("B")]],
                    }},
                    {"type": "table_row", "table_row": {
                        "cells": [[], [_make_text_segment("value")]],
                    }},
                ],
            },
        }]
        md = r.render_blocks(blocks)
        assert "value" in md
        assert "|---" in md


# =========================================================================
# U-NM-014: image external
# =========================================================================

class TestImageRendering:
    """U-NM-014: Image blocks render as ![caption](url)."""

    def test_external_image(self):
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_image_external("https://example.com/img.png", caption="my image")]
        md = r.render_blocks(blocks)
        assert "![my image](https://example.com/img.png)" in md

    def test_external_image_no_caption(self):
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_image_external("https://example.com/img.png")]
        md = r.render_blocks(blocks)
        assert "![](https://example.com/img.png)" in md

    def test_image_file_upload_renders_empty_url(self):
        """file_upload images have no public URL; renders ![]()."""
        r = NotionToMarkdownRenderer(make_config())
        blocks = [{
            "type": "image",
            "image": {
                "type": "file_upload",
                "file_upload": {"id": "upload-img-1"},
                "caption": [_make_text_segment("uploaded pic")],
            },
        }]
        md = r.render_blocks(blocks)
        assert "![uploaded pic]()" in md

    def test_notion_hosted_image_expiry_warning(self):
        r = NotionToMarkdownRenderer(make_config(image_expiry_warnings=True))
        blocks = [{
            "type": "image",
            "id": "block-123",
            "image": {
                "type": "file",
                "file": {
                    "url": "https://prod-files.notion.so/image.png",
                    "expiry_time": "2026-03-01T00:00:00.000Z",
                },
                "caption": [],
            },
        }]
        md = r.render_blocks(blocks)
        assert "notion-image-expiry" in md
        assert len(r.warnings) == 1
        assert r.warnings[0].code == "IMAGE_EXPIRY"



# =========================================================================
# U-NM-015: quote block
# =========================================================================

class TestQuoteRendering:
    """U-NM-015: Quote blocks render with > prefix."""

    def test_quote(self):
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_quote("quoted text")]
        md = r.render_blocks(blocks)
        assert "> quoted text" in md


# =========================================================================
# U-NM-016: inline code
# =========================================================================

class TestInlineCodeRendering:
    """U-NM-016: Inline code renders with backticks."""

    def test_inline_code(self):
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_paragraph([
            _make_text_segment("use "),
            _make_text_segment("code", code=True),
            _make_text_segment(" here"),
        ])]
        md = r.render_blocks(blocks)
        assert "`code`" in md


# =========================================================================
# U-NM-017: unsupported block policy "comment"
# =========================================================================

class TestUnsupportedBlockComment:
    """U-NM-017: Unsupported blocks with comment policy emit HTML comment."""

    def test_unsupported_comment(self):
        r = NotionToMarkdownRenderer(make_config(unsupported_block_policy="comment"))
        blocks = [{"type": "alien_block", "id": "abc123", "alien_block": {}}]
        md = r.render_blocks(blocks)
        assert "<!-- notion:alien_block -->" in md


# =========================================================================
# U-NM-018: unsupported block policy "skip"
# =========================================================================

class TestUnsupportedBlockSkip:
    """U-NM-018: Unsupported blocks with skip policy produce empty output."""

    def test_unsupported_skip(self):
        r = NotionToMarkdownRenderer(make_config(unsupported_block_policy="skip"))
        blocks = [{"type": "alien_block", "id": "abc123", "alien_block": {}}]
        md = r.render_blocks(blocks)
        assert md == ""


# =========================================================================
# U-NM-019: unsupported block policy "raise"
# =========================================================================

class TestUnsupportedBlockRaise:
    """U-NM-019: Unsupported blocks with raise policy throw an exception."""

    def test_unsupported_raise(self):
        r = NotionToMarkdownRenderer(make_config(unsupported_block_policy="raise"))
        blocks = [{"type": "alien_block", "id": "abc123", "alien_block": {}}]
        with pytest.raises(NotionifyUnsupportedBlockError) as exc_info:
            r.render_blocks(blocks)
        assert "alien_block" in str(exc_info.value)
        assert exc_info.value.context["block_type"] == "alien_block"


# =========================================================================
# U-NM-020: strikethrough rendering
# =========================================================================

class TestStrikethroughRendering:
    """U-NM-020: Strikethrough annotation renders as ~~text~~."""

    def test_strikethrough(self):
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_paragraph([_make_text_segment("deleted", strikethrough=True)])]
        md = r.render_blocks(blocks)
        assert "~~deleted~~" in md


# =========================================================================
# U-NM-021: combined annotations
# =========================================================================

class TestCombinedAnnotations:
    """U-NM-021: Multiple annotations combine correctly."""

    def test_bold_italic(self):
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_paragraph([_make_text_segment("both", bold=True, italic=True)])]
        md = r.render_blocks(blocks)
        # Should contain both bold and italic markers
        assert "**" in md
        assert "_" in md
        assert "both" in md

    def test_bold_code_stays_code(self):
        """Code annotation takes precedence - bold is not applied inside code."""
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_paragraph([_make_text_segment("snippet", code=True, bold=True)])]
        md = r.render_blocks(blocks)
        assert "`snippet`" in md


# =========================================================================
# U-NM-022: empty blocks
# =========================================================================

class TestEmptyBlocks:
    """U-NM-022: Empty block lists render empty string."""

    def test_empty_block_list(self):
        r = NotionToMarkdownRenderer(make_config())
        md = r.render_blocks([])
        assert md == ""

    def test_empty_paragraph(self):
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_paragraph([])]
        md = r.render_blocks(blocks)
        # Empty paragraph should render as just whitespace/newlines
        assert md.strip() == ""


# =========================================================================
# Additional edge-case tests
# =========================================================================

class TestBreadcrumbAndTocOmitted:
    """Breadcrumb and TOC blocks are silently omitted."""

    def test_breadcrumb_omitted(self):
        r = NotionToMarkdownRenderer(make_config())
        blocks = [{"type": "breadcrumb", "breadcrumb": {}}]
        md = r.render_blocks(blocks)
        assert md == ""

    def test_toc_omitted(self):
        r = NotionToMarkdownRenderer(make_config())
        blocks = [{"type": "table_of_contents", "table_of_contents": {}}]
        md = r.render_blocks(blocks)
        assert md == ""


class TestPassthroughBlocks:
    """Layout wrappers pass through their children."""

    def test_synced_block_passthrough(self):
        r = NotionToMarkdownRenderer(make_config())
        inner = make_paragraph([_make_text_segment("inner")])
        blocks = [{"type": "synced_block", "synced_block": {}, "children": [inner]}]
        md = r.render_blocks(blocks)
        assert "inner" in md

    def test_template_passthrough(self):
        r = NotionToMarkdownRenderer(make_config())
        inner = make_paragraph([_make_text_segment("templated content")])
        blocks = [{"type": "template", "template": {}, "children": [inner]}]
        md = r.render_blocks(blocks)
        assert "templated content" in md


class TestUnderlineRendering:
    """Underline renders as <u>text</u>."""

    def test_underline(self):
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_paragraph([_make_text_segment("underlined", underline=True)])]
        md = r.render_blocks(blocks)
        assert "<u>" in md
        assert "underlined" in md
        assert "</u>" in md


# =========================================================================
# Additional coverage tests for previously uncovered paths
# =========================================================================


class TestRenderBlockPublicMethod:
    """render_block() is a public single-block method (line 105)."""

    def test_render_single_block(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "paragraph",
            "paragraph": {"rich_text": [_make_text_segment("hello")]},
        }
        md = r.render_block(block)
        assert "hello" in md


class TestMediaBlockRendering:
    """Media types (video, audio, pdf) use _render_media (line 147)."""

    def test_video_external(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "video",
            "video": {"type": "external", "external": {"url": "https://youtube.com/v/123"}},
        }
        md = r.render_blocks([block])
        assert "[Video]" in md or "youtube.com" in md

    def test_audio_file(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "audio",
            "audio": {"type": "file", "file": {"url": "https://cdn.example.com/sound.mp3"}},
        }
        md = r.render_blocks([block])
        assert "[Audio]" in md or "sound.mp3" in md

    def test_media_no_url(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {"type": "video", "video": {"type": "external", "external": {}}}
        md = r.render_blocks([block])
        assert "[Video]" in md

    def test_video_file_upload_renders_empty_url(self):
        """file_upload media blocks have no public URL; renders empty link."""
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "video",
            "video": {"type": "file_upload", "file_upload": {"id": "upload-vid-1"}},
        }
        md = r.render_blocks([block])
        assert "[Video]" in md
        assert "()" in md

    def test_video_with_caption(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "video",
            "video": {
                "type": "external",
                "external": {"url": "https://youtube.com/v/123"},
                "caption": [_make_text_segment("Tutorial video")],
            },
        }
        md = r.render_blocks([block])
        assert "[Video]" in md
        assert "> Tutorial video" in md

    def test_audio_without_caption_no_blockquote(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "audio",
            "audio": {
                "type": "file",
                "file": {"url": "https://cdn.example.com/sound.mp3"},
                "caption": [],
            },
        }
        md = r.render_blocks([block])
        assert ">" not in md

    def test_pdf_file_upload_renders_empty_url(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "pdf",
            "pdf": {"type": "file_upload", "file_upload": {"id": "upload-pdf-1"}},
        }
        md = r.render_blocks([block])
        assert "[PDF]" in md
        assert "()" in md

    def test_video_file_hosted(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "video",
            "video": {"type": "file", "file": {"url": "https://cdn.notion.so/vid.mp4"}},
        }
        md = r.render_blocks([block])
        assert "[Video]" in md
        assert "cdn.notion.so/vid.mp4" in md

    def test_audio_external(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "audio",
            "audio": {"type": "external", "external": {"url": "https://example.com/song.mp3"}},
        }
        md = r.render_blocks([block])
        assert "[Audio]" in md
        assert "song.mp3" in md

    def test_audio_file_upload_renders_empty_url(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "audio",
            "audio": {"type": "file_upload", "file_upload": {"id": "upload-aud-1"}},
        }
        md = r.render_blocks([block])
        assert "[Audio]" in md
        assert "()" in md

    def test_pdf_external(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "pdf",
            "pdf": {"type": "external", "external": {"url": "https://example.com/doc.pdf"}},
        }
        md = r.render_blocks([block])
        assert "[PDF]" in md
        assert "doc.pdf" in md

    def test_pdf_file_hosted(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "pdf",
            "pdf": {"type": "file", "file": {"url": "https://cdn.notion.so/doc.pdf"}},
        }
        md = r.render_blocks([block])
        assert "[PDF]" in md
        assert "cdn.notion.so/doc.pdf" in md


class TestNestedChildrenRendering:
    """Nested children in quote, bulleted, numbered, to_do (lines 193-202, 228, 241)."""

    def test_quote_with_children(self):
        r = NotionToMarkdownRenderer(make_config())
        child = {
            "type": "paragraph",
            "paragraph": {"rich_text": [_make_text_segment("nested")]},
        }
        block = {
            "type": "quote",
            "quote": {
                "rich_text": [_make_text_segment("outer")],
                "children": [child],
            },
        }
        md = r.render_blocks([block])
        assert "outer" in md
        assert "nested" in md

    def test_quote_empty_child_line(self):
        """Empty lines in children get > prefix (line 387)."""
        r = NotionToMarkdownRenderer(make_config())
        child = {
            "type": "paragraph",
            "paragraph": {"rich_text": [_make_text_segment("line1")]},
        }
        block = {
            "type": "quote",
            "quote": {
                "rich_text": [],
                "children": [child],
            },
        }
        md = r.render_blocks([block])
        assert "line1" in md

    def test_bulleted_with_children(self):
        r = NotionToMarkdownRenderer(make_config())
        child = {
            "type": "bulleted_list_item",
            "bulleted_list_item": {"rich_text": [_make_text_segment("child")]},
        }
        block = {
            "type": "bulleted_list_item",
            "bulleted_list_item": {
                "rich_text": [_make_text_segment("parent")],
                "children": [child],
            },
        }
        md = r.render_blocks([block])
        assert "parent" in md
        assert "child" in md

    def test_numbered_with_children(self):
        r = NotionToMarkdownRenderer(make_config())
        child = {
            "type": "paragraph",
            "paragraph": {"rich_text": [_make_text_segment("sub")]},
        }
        block = {
            "type": "numbered_list_item",
            "numbered_list_item": {
                "rich_text": [_make_text_segment("item")],
                "children": [child],
            },
        }
        md = r.render_blocks([block])
        assert "item" in md
        assert "sub" in md

    def test_todo_with_children(self):
        r = NotionToMarkdownRenderer(make_config())
        child = {
            "type": "paragraph",
            "paragraph": {"rich_text": [_make_text_segment("detail")]},
        }
        block = {
            "type": "to_do",
            "to_do": {
                "rich_text": [_make_text_segment("task")],
                "checked": False,
                "children": [child],
            },
        }
        md = r.render_blocks([block])
        assert "task" in md
        assert "detail" in md


class TestToggleRendering:
    """Toggle block with children (lines 393-401)."""

    def test_toggle_with_children(self):
        r = NotionToMarkdownRenderer(make_config())
        child = {
            "type": "paragraph",
            "paragraph": {"rich_text": [_make_text_segment("hidden content")]},
        }
        block = {
            "type": "toggle",
            "toggle": {
                "rich_text": [_make_text_segment("Click to expand")],
                "children": [child],
            },
        }
        md = r.render_blocks([block])
        assert "Click to expand" in md
        assert "hidden content" in md


class TestColumnPassthroughBlocks:
    """column_list / column blocks pass through children (lines 492-493)."""

    def test_column_list_passthrough(self):
        r = NotionToMarkdownRenderer(make_config())
        child = {
            "type": "paragraph",
            "paragraph": {"rich_text": [_make_text_segment("col content")]},
        }
        block = {
            "type": "column_list",
            "column_list": {"children": [child]},
        }
        md = r.render_blocks([block])
        assert "col content" in md

    def test_column_passthrough(self):
        r = NotionToMarkdownRenderer(make_config())
        inner = make_paragraph([_make_text_segment("column content")])
        block = {"type": "column", "column": {}, "children": [inner]}
        md = r.render_blocks([block])
        assert "column content" in md

    def test_passthrough_no_children(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {"type": "column_list", "column_list": {}}
        md = r.render_blocks([block])
        assert md == ""

    def test_nested_column_passthrough(self):
        """column_list → column → paragraph renders inner content."""
        r = NotionToMarkdownRenderer(make_config())
        inner = make_paragraph([_make_text_segment("nested")])
        column = {"type": "column", "column": {}, "children": [inner]}
        column_list = {"type": "column_list", "column_list": {}, "children": [column]}
        md = r.render_blocks([column_list])
        assert "nested" in md


class TestUnsupportedBlockWithText:
    """_render_unsupported comment mode with non-empty text (line 524)."""

    def test_unsupported_comment_with_text(self):
        r = NotionToMarkdownRenderer(make_config(unsupported_block_policy="comment"))
        # Use a completely custom type not in any dispatch table
        block = {
            "type": "custom_widget",
            "custom_widget": {
                "rich_text": [{"plain_text": "widget text", "type": "text"}]
            },
        }
        md = r.render_blocks([block])
        assert "<!-- notion:custom_widget -->" in md
        assert "widget text" in md


class TestExtractPlainTextHelper:
    """_extract_plain_text helper (line 581)."""

    def test_extracts_from_rich_text(self):
        from notionify.converter.notion_to_md import _extract_plain_text
        block = {
            "type": "paragraph",
            "paragraph": {
                "rich_text": [
                    {"plain_text": "Hello ", "type": "text"},
                    {"plain_text": "world", "type": "text"},
                ]
            },
        }
        assert _extract_plain_text(block) == "Hello world"

    def test_empty_block_returns_empty(self):
        from notionify.converter.notion_to_md import _extract_plain_text
        assert _extract_plain_text({}) == ""


class TestNestedQuoteMarkerCount:
    """Nested blockquotes produce exactly the right number of > markers."""

    def test_double_nested_quote_has_two_markers(self):
        """Inner quote at depth 2 has exactly two > markers."""
        r = NotionToMarkdownRenderer(make_config())
        inner = {"type": "quote", "quote": {"rich_text": [_make_text_segment("inner")]}}
        outer = {
            "type": "quote",
            "quote": {"rich_text": [_make_text_segment("outer")], "children": [inner]},
        }
        md = r.render_blocks([outer])
        for line in md.splitlines():
            if "inner" in line:
                assert line.count(">") == 2
            elif "outer" in line:
                assert line.count(">") == 1

    def test_triple_nested_quote_has_three_markers(self):
        """Innermost quote at depth 3 has exactly three > markers."""
        r = NotionToMarkdownRenderer(make_config())
        l3 = {"type": "quote", "quote": {"rich_text": [_make_text_segment("L3")]}}
        l2 = {"type": "quote", "quote": {"rich_text": [_make_text_segment("L2")], "children": [l3]}}
        l1 = {"type": "quote", "quote": {"rich_text": [_make_text_segment("L1")], "children": [l2]}}
        md = r.render_blocks([l1])
        for line in md.splitlines():
            if "L3" in line:
                assert line.count(">") == 3
            elif "L2" in line:
                assert line.count(">") == 2
            elif "L1" in line:
                assert line.count(">") == 1

    def test_quote_with_paragraph_child_one_marker(self):
        """Paragraph inside a quote gets exactly one > prefix."""
        r = NotionToMarkdownRenderer(make_config())
        child = {"type": "paragraph", "paragraph": {"rich_text": [_make_text_segment("child")]}}
        block = {
            "type": "quote",
            "quote": {"rich_text": [_make_text_segment("parent")], "children": [child]},
        }
        md = r.render_blocks([block])
        for line in md.splitlines():
            if "child" in line:
                assert line.count(">") == 1


class TestQuoteEmptyChildLineBranch:
    """Quote children with multiple blocks produce internal empty lines (line 201)."""

    def test_quote_two_children_hits_empty_line_branch(self):
        """Two children create blank line between them, hitting prefix.rstrip() branch."""
        r = NotionToMarkdownRenderer(make_config())
        child1 = {
            "type": "paragraph",
            "paragraph": {"rich_text": [_make_text_segment("first")]},
        }
        child2 = {
            "type": "paragraph",
            "paragraph": {"rich_text": [_make_text_segment("second")]},
        }
        block = {
            "type": "quote",
            "quote": {
                "rich_text": [_make_text_segment("outer")],
                "children": [child1, child2],
            },
        }
        md = r.render_blocks([block])
        assert "first" in md
        assert "second" in md


class TestCalloutEmptyChildLineBranch:
    """Callout children with multiple blocks produce internal empty lines (line 387)."""

    def test_callout_two_children_hits_empty_line_branch(self):
        """Two children create blank line, hitting '>'  empty branch in callout."""
        r = NotionToMarkdownRenderer(make_config())
        child1 = {
            "type": "paragraph",
            "paragraph": {"rich_text": [_make_text_segment("alpha")]},
        }
        child2 = {
            "type": "paragraph",
            "paragraph": {"rich_text": [_make_text_segment("beta")]},
        }
        block = {
            "type": "callout",
            "callout": {
                "rich_text": [_make_text_segment("note")],
                "icon": {"type": "emoji", "emoji": "💡"},
                "children": [child1, child2],
            },
        }
        md = r.render_blocks([block])
        assert "alpha" in md
        assert "beta" in md


class TestMarkdownEscapeCodeContext:
    """markdown_escape with context='code' returns text unchanged (line 41)."""

    def test_code_context_no_escaping(self):
        from notionify.converter.inline_renderer import markdown_escape
        text = "**bold** and `code` and [link](url)"
        assert markdown_escape(text, context="code") == text

    def test_url_context_encodes_parens(self):
        from notionify.converter.inline_renderer import markdown_escape
        assert markdown_escape("a(b)c", context="url") == "a%28b%29c"


class TestEquationWithHref:
    """Equation segment with href renders as linked equation (line 88)."""

    def test_equation_with_link(self):
        from notionify.converter.inline_renderer import render_rich_text
        seg = {
            "type": "equation",
            "equation": {"expression": "E=mc^2"},
            "href": "https://example.com",
            "annotations": {},
        }
        result = render_rich_text([seg])
        assert "$E=mc^2$" in result
        assert "https://example.com" in result


class TestBookmarkRendering:
    """_render_bookmark produces a Markdown link with optional caption."""

    def test_bookmark_basic_url(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "bookmark",
            "bookmark": {"url": "https://example.com", "caption": []},
        }
        md = r.render_blocks([block])
        assert "https://example.com" in md

    def test_bookmark_with_caption(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "bookmark",
            "bookmark": {
                "url": "https://example.com",
                "caption": [_make_text_segment("My caption")],
            },
        }
        md = r.render_blocks([block])
        assert "https://example.com" in md
        assert "My caption" in md

    def test_bookmark_empty_url(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "bookmark",
            "bookmark": {"url": "", "caption": []},
        }
        md = r.render_blocks([block])
        # Should render without crashing; link text will be empty
        assert md is not None

    def test_bookmark_url_with_parens(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "bookmark",
            "bookmark": {"url": "https://example.com/path(1)", "caption": []},
        }
        md = r.render_blocks([block])
        # Parens in URL must be percent-encoded so the MD link is valid
        assert "example.com" in md
        assert "(" not in md.split("](")[1] if "](" in md else True


    def test_bookmark_url_with_brackets_escaped(self):
        """URL containing ] is escaped in the display text to prevent broken link."""
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "bookmark",
            "bookmark": {"url": "https://example.com/page]test", "caption": []},
        }
        md = r.render_blocks([block])
        # The ] in display text must be escaped
        assert "\\]" in md
        # The URL target should NOT have the backslash
        assert "](https://example.com/page]test)" in md


class TestFileBlockRendering:
    """_render_file produces a Markdown link for external/hosted files."""

    def test_file_external_url(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "file",
            "file": {
                "type": "external",
                "external": {"url": "https://example.com/doc.pdf"},
                "name": "doc.pdf",
                "caption": [],
            },
        }
        md = r.render_blocks([block])
        assert "https://example.com/doc.pdf" in md
        assert "doc.pdf" in md

    def test_file_hosted_url(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "file",
            "file": {
                "type": "file",
                "file": {"url": "https://cdn.notion.so/file.zip?token=abc"},
                "name": "archive.zip",
                "caption": [],
            },
        }
        md = r.render_blocks([block])
        assert "cdn.notion.so" in md

    def test_file_caption_overrides_name(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "file",
            "file": {
                "type": "external",
                "external": {"url": "https://example.com/report.pdf"},
                "name": "report.pdf",
                "caption": [_make_text_segment("Annual Report")],
            },
        }
        md = r.render_blocks([block])
        assert "Annual Report" in md

    def test_file_no_name_falls_back_to_url_basename(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "file",
            "file": {
                "type": "external",
                "external": {"url": "https://example.com/data.csv"},
                "name": "",
                "caption": [],
            },
        }
        md = r.render_blocks([block])
        assert "data.csv" in md

    def test_file_upload_renders_name_with_empty_url(self):
        """file_upload file blocks have no public URL; renders [name]()."""
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "file",
            "file": {
                "type": "file_upload",
                "file_upload": {"id": "upload-file-1"},
                "name": "document.docx",
                "caption": [],
            },
        }
        md = r.render_blocks([block])
        assert "[document.docx]()" in md

    def test_file_no_url_renders_file_label(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "file",
            "file": {
                "type": "external",
                "external": {"url": ""},
                "name": "",
                "caption": [],
            },
        }
        md = r.render_blocks([block])
        assert "File" in md

    def test_file_name_with_brackets_escaped(self):
        """File name containing ] should not break link syntax."""
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "file",
            "file": {
                "type": "external",
                "external": {"url": "https://example.com/f.txt"},
                "name": "file[1].txt",
                "caption": [],
            },
        }
        md = r.render_blocks([block])
        assert r"file\[1\].txt" in md
        assert "https://example.com/f.txt" in md

    def test_file_caption_with_brackets_not_double_escaped(self):
        """Caption from render_rich_text is already escaped; no double-escaping."""
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "file",
            "file": {
                "type": "external",
                "external": {"url": "https://example.com/f.txt"},
                "name": "ignored.txt",
                "caption": [_make_text_segment("Report [v2]")],
            },
        }
        md = r.render_blocks([block])
        # render_rich_text escapes [ to \[  — _escape_link_text must NOT re-escape
        assert r"Report \[v2\]" in md
        assert r"\\\[" not in md  # no triple-backslash from double-escaping


class TestEmbedRendering:
    """_render_embed produces [Embed](url)."""

    def test_embed_url_included(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "embed",
            "embed": {"url": "https://youtube.com/watch?v=abc"},
        }
        md = r.render_blocks([block])
        assert "youtube.com" in md
        assert "Embed" in md

    def test_embed_empty_url(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {"type": "embed", "embed": {"url": ""}}
        md = r.render_blocks([block])
        assert "[Embed]" in md

    def test_embed_with_caption(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "embed",
            "embed": {
                "url": "https://youtube.com/watch?v=abc",
                "caption": [_make_text_segment("Watch this video")],
            },
        }
        md = r.render_blocks([block])
        assert "Embed" in md
        assert "youtube.com" in md
        assert "> Watch this video" in md

    def test_embed_without_caption_no_blockquote(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "embed",
            "embed": {"url": "https://example.com", "caption": []},
        }
        md = r.render_blocks([block])
        assert ">" not in md

    def test_embed_url_with_parens_encoded(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "embed",
            "embed": {"url": "https://example.com/page(1)"},
        }
        md = r.render_blocks([block])
        assert "example.com" in md


class TestLinkPreviewRendering:
    """_render_link_preview produces [url](escaped_url)."""

    def test_link_preview_url(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "link_preview",
            "link_preview": {"url": "https://example.com/article"},
        }
        md = r.render_blocks([block])
        assert "https://example.com/article" in md

    def test_link_preview_empty_url(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {"type": "link_preview", "link_preview": {"url": ""}}
        md = r.render_blocks([block])
        assert md is not None


    def test_link_preview_url_with_brackets_escaped(self):
        """URL containing [] is escaped in the display text."""
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "link_preview",
            "link_preview": {"url": "https://example.com/[test]"},
        }
        md = r.render_blocks([block])
        assert "\\[" in md
        assert "\\]" in md


class TestLinkToPageRendering:
    """_render_link_to_page produces a Notion URL link."""

    def test_page_id_link(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "link_to_page",
            "link_to_page": {"type": "page_id", "page_id": "abc-123-def"},
        }
        md = r.render_blocks([block])
        assert "notion.so/" in md
        assert "abc123def" in md
        assert "[page_id]" in md

    def test_database_id_link(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "link_to_page",
            "link_to_page": {"type": "database_id", "database_id": "db-456"},
        }
        md = r.render_blocks([block])
        assert "notion.so/" in md
        assert "db456" in md

    def test_empty_link_to_page(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "link_to_page",
            "link_to_page": {"type": "page_id", "page_id": ""},
        }
        md = r.render_blocks([block])
        assert md.strip() == ""

    def test_missing_type_field(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {"type": "link_to_page", "link_to_page": {}}
        md = r.render_blocks([block])
        assert md.strip() == ""


class TestChildPageAndDatabaseRendering:
    """_render_child_page and _render_child_database produce links."""

    def test_child_page_title(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "child_page",
            "id": "abc123",
            "child_page": {"title": "My Subpage"},
        }
        md = r.render_blocks([block])
        assert "My Subpage" in md
        assert "Page:" in md

    def test_child_page_no_title_uses_untitled(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "child_page",
            "id": "abc123",
            "child_page": {},
        }
        md = r.render_blocks([block])
        assert "Untitled" in md

    def test_child_database_title(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "child_database",
            "id": "def456",
            "child_database": {"title": "My DB"},
        }
        md = r.render_blocks([block])
        assert "My DB" in md
        assert "Database:" in md

    def test_child_database_no_title(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "child_database",
            "id": "def456",
            "child_database": {},
        }
        md = r.render_blocks([block])
        assert "Untitled" in md

    def test_child_page_title_with_brackets_escaped(self):
        """Brackets in child page title should be escaped in link text."""
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "child_page",
            "id": "abc123",
            "child_page": {"title": "My [Sub] Page"},
        }
        md = r.render_blocks([block])
        assert r"My \[Sub\] Page" in md

    def test_child_database_title_with_brackets_escaped(self):
        """Brackets in child database title should be escaped in link text."""
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "child_database",
            "id": "def456",
            "child_database": {"title": "DB [v2]"},
        }
        md = r.render_blocks([block])
        assert r"DB \[v2\]" in md

    def test_child_page_missing_id_produces_base_notion_url(self):
        """Child page without 'id' produces https://notion.so/ as URL base."""
        r = NotionToMarkdownRenderer(make_config())
        block = {"type": "child_page", "child_page": {"title": "Orphan"}}
        md = r.render_blocks([block])
        assert "Orphan" in md
        assert "https://notion.so/" in md

    def test_child_page_empty_title_string_renders_empty_label(self):
        """Child page with title='' renders without Untitled fallback."""
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "child_page",
            "id": "abc123",
            "child_page": {"title": ""},
        }
        md = r.render_blocks([block])
        assert "[Page: ]" in md


# =========================================================================
# Branch coverage tests
# =========================================================================

class TestNotionToMdBranchCoverage:
    """Branch coverage for notion_to_md.py (313->317, 326->342, 355->358, 464->467, 576->584)."""

    def test_image_unknown_type_renders_empty_url(self):
        """Image block with unknown type leaves url empty (branch 313->317)."""
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "image",
            "image": {"type": "unknown", "caption": []},
        }
        md = r.render_blocks([block])
        assert "![]()" in md

    def test_notion_hosted_image_no_expiry_time_no_warning(self):
        """Notion-hosted image without expiry_time skips warning (branch 326->342)."""
        r = NotionToMarkdownRenderer(make_config(image_expiry_warnings=True))
        block = {
            "type": "image",
            "image": {
                "type": "file",
                "file": {"url": "https://prod-files.notion.so/image.png"},
                "caption": [],
            },
        }
        md = r.render_blocks([block])
        assert "notion-image-expiry" not in md
        assert len(r.warnings) == 0

    def test_callout_icon_unknown_type_produces_no_icon_str(self):
        """Callout with icon of unknown type skips icon prefix (branch 355->358)."""
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "callout",
            "callout": {
                "rich_text": [_make_text_segment("Note")],
                "icon": {"type": "unknown_type"},
            },
        }
        md = r.render_blocks([block])
        assert "Note" in md

    def test_media_unknown_type_renders_empty_url(self):
        """Media block with unknown type leaves url empty (branch 464->467)."""
        r = NotionToMarkdownRenderer(make_config())
        block = {"type": "video", "video": {"type": "unknown"}}
        md = r.render_blocks([block])
        assert "[Video]" in md
        assert "()" in md

    def test_extract_plain_text_non_dict_block_data(self):
        """block_data is not a dict returns empty string (branch 576->584)."""
        from notionify.converter.notion_to_md import _extract_plain_text
        block = {"type": "paragraph", "paragraph": None}
        assert _extract_plain_text(block) == ""


# =========================================================================
# U-NM-023: table has_row_header support
# =========================================================================

class TestTableRowHeaderRendering:
    """U-NM-023: Table blocks with has_row_header bold the first column."""

    def test_table_row_header_bolds_first_cell(self):
        """has_row_header=True wraps each first cell in **...**."""
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_table_block(
            header_cells=["Name", "Value"],
            body_rows=[["Alpha", "1"], ["Beta", "2"]],
            has_row_header=True,
        )]
        md = r.render_blocks(blocks)
        assert "| **Name** | Value |" in md
        assert "| **Alpha** | 1 |" in md
        assert "| **Beta** | 2 |" in md

    def test_table_no_row_header_no_bold(self):
        """has_row_header=False (default) leaves cells unmodified."""
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_table_block(
            header_cells=["Name", "Value"],
            body_rows=[["Alpha", "1"]],
            has_row_header=False,
        )]
        md = r.render_blocks(blocks)
        assert "| Name | Value |" in md
        assert "| Alpha | 1 |" in md
        assert "**" not in md

    def test_table_row_header_empty_first_cell_not_double_bolded(self):
        """An empty first cell with has_row_header is not wrapped in ****."""
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_table_block(
            header_cells=["", "Value"],
            body_rows=[["", "Data"]],
            has_row_header=True,
        )]
        md = r.render_blocks(blocks)
        # Empty cell stays empty — no "****" artefact
        assert "****" not in md

    def test_table_row_header_single_column(self):
        """Single-column table with has_row_header bolds every cell."""
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_table_block(
            header_cells=["Label"],
            body_rows=[["Row1"], ["Row2"]],
            has_row_header=True,
        )]
        md = r.render_blocks(blocks)
        assert "| **Label** |" in md
        assert "| **Row1** |" in md
        assert "| **Row2** |" in md

    def test_table_row_header_with_column_header(self):
        """Both has_row_header and has_column_header work together."""
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_table_block(
            header_cells=["Category", "Q1", "Q2"],
            body_rows=[["Sales", "100", "200"], ["Costs", "50", "80"]],
            has_column_header=True,
            has_row_header=True,
        )]
        md = r.render_blocks(blocks)
        # Separator row present (column header)
        assert "|---|---|---|" in md
        # First column bolded (row header)
        assert "| **Category** |" in md
        assert "| **Sales** |" in md
        assert "| **Costs** |" in md
        # Non-first columns not bolded
        assert "| Q1 |" in md
        assert "| 100 |" in md

    def test_table_row_header_missing_key_defaults_false(self):
        """Table block without has_row_header key defaults to no bolding."""
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "table",
            "table": {
                "table_width": 2,
                # has_row_header intentionally absent
                "children": [
                    {"type": "table_row", "table_row": {"cells": [
                        [_make_text_segment("X")], [_make_text_segment("Y")],
                    ]}},
                ],
            },
        }
        md = r.render_blocks([block])
        assert "| X | Y |" in md
        assert "**" not in md


# =========================================================================
# Code fence collision (backtick-in-code-content)
# =========================================================================


class TestCodeFenceCollision:
    """Code blocks whose content contains backtick fences must use longer fences."""

    def test_triple_backtick_in_code_uses_four(self):
        """Content with ``` triggers a 4-backtick fence."""
        r = NotionToMarkdownRenderer(make_config())
        code = 'Show markdown:\n```python\nprint("hi")\n```'
        blocks = [make_code_block(code, language="markdown")]
        md = r.render_blocks(blocks)
        assert md.startswith("````markdown\n")
        assert md.endswith("\n````\n\n")
        assert code in md

    def test_quad_backtick_in_code_uses_five(self):
        """Content with ```` triggers a 5-backtick fence."""
        r = NotionToMarkdownRenderer(make_config())
        code = "nested:\n````\ninner\n````"
        blocks = [make_code_block(code, language="")]
        md = r.render_blocks(blocks)
        assert "`````\n" in md
        # Triple backtick should NOT appear as the opening fence
        lines = md.strip().split("\n")
        assert lines[0] == "`````"
        assert lines[-1] == "`````"

    def test_no_backtick_content_uses_triple(self):
        """Normal code without backticks still uses triple backtick fence."""
        r = NotionToMarkdownRenderer(make_config())
        blocks = [make_code_block("print('hello')", language="python")]
        md = r.render_blocks(blocks)
        assert md.startswith("```python\n")

    def test_backtick_midline_still_escapes(self):
        """Backtick sequences anywhere in the content trigger longer fences."""
        r = NotionToMarkdownRenderer(make_config())
        code = "Use ``` for code fences"
        blocks = [make_code_block(code, language="")]
        md = r.render_blocks(blocks)
        # Fence must be longer than the triple backtick in content
        lines = md.strip().split("\n")
        assert len(lines[0]) >= 4
        assert code in md

    def test_code_content_preserved_with_longer_fence(self):
        """Round-trip: code content is preserved exactly between longer fences."""
        r = NotionToMarkdownRenderer(make_config())
        code = "```\nsome\n```\nmore\n````"
        blocks = [make_code_block(code, language="text")]
        md = r.render_blocks(blocks)
        assert code in md
        # Fence must be at least 5 backticks (content has ````)
        opening_line = md.strip().split("\n")[0]
        backtick_count = len(opening_line) - len(opening_line.lstrip("`"))
        assert backtick_count >= 5


# =========================================================================
# Table separator with missing/zero table_width
# =========================================================================


class TestTableWidthFallback:
    """Table rendering when table_width is 0 or missing."""

    def test_table_width_zero_uses_actual_cell_count(self):
        """table_width=0 derives column count from actual cell data."""
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "table",
            "table": {
                "table_width": 0,
                "has_column_header": True,
                "has_row_header": False,
                "children": [
                    {"type": "table_row", "table_row": {"cells": [
                        [_make_text_segment("A")], [_make_text_segment("B")],
                    ]}},
                    {"type": "table_row", "table_row": {"cells": [
                        [_make_text_segment("1")], [_make_text_segment("2")],
                    ]}},
                ],
            },
        }
        md = r.render_blocks([block])
        assert "| A | B |" in md
        assert "|---|---|" in md
        assert "| 1 | 2 |" in md

    def test_table_width_missing_uses_actual_cell_count(self):
        """Missing table_width key derives column count from actual cell data."""
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "table",
            "table": {
                # table_width intentionally absent
                "children": [
                    {"type": "table_row", "table_row": {"cells": [
                        [_make_text_segment("X")], [_make_text_segment("Y")],
                        [_make_text_segment("Z")],
                    ]}},
                ],
            },
        }
        md = r.render_blocks([block])
        assert "| X | Y | Z |" in md
        assert "|---|---|---|" in md

    def test_table_width_zero_single_column(self):
        """table_width=0 with single-column rows produces valid separator."""
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "table",
            "table": {
                "table_width": 0,
                "has_column_header": True,
                "children": [
                    {"type": "table_row", "table_row": {"cells": [
                        [_make_text_segment("Only")],
                    ]}},
                ],
            },
        }
        md = r.render_blocks([block])
        assert "| Only |" in md
        assert "|---|" in md


class TestBlockColorIgnoredInOutput:
    """Block-level color is a Notion attribute not represented in Markdown output."""

    def test_paragraph_with_color_renders_text_only(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "paragraph",
            "paragraph": {
                "rich_text": [_make_text_segment("hello world")],
                "color": "pink",
            },
        }
        md = r.render_blocks([block])
        assert "hello world" in md
        assert "pink" not in md

    def test_bulleted_list_item_with_color_renders_correctly(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "bulleted_list_item",
            "bulleted_list_item": {
                "rich_text": [_make_text_segment("list item text")],
                "color": "purple",
            },
        }
        md = r.render_blocks([block])
        assert "- list item text" in md
        assert "purple" not in md

    def test_numbered_list_item_with_color_renders_correctly(self):
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "numbered_list_item",
            "numbered_list_item": {
                "rich_text": [_make_text_segment("numbered item text")],
                "color": "orange",
            },
        }
        md = r.render_blocks([block])
        assert "1. numbered item text" in md
        assert "orange" not in md


class TestDeeplyNestedLists:
    """Three or more levels of list nesting render with increasing indentation."""

    def test_three_level_nested_bulleted_list(self):
        r = NotionToMarkdownRenderer(make_config())
        level3 = make_bulleted_list_item("level3")
        level2 = make_bulleted_list_item("level2", children=[level3])
        level1 = make_bulleted_list_item("level1", children=[level2])
        md = r.render_blocks([level1])
        assert "- level1" in md
        assert "- level2" in md
        assert "- level3" in md
        # Each nesting level adds indentation
        lines = [line for line in md.splitlines() if line.strip().startswith("-")]
        assert len(lines) == 3
        # level1 is least indented, level3 is most indented
        indent_counts = [len(line) - len(line.lstrip()) for line in lines]
        assert indent_counts[0] < indent_counts[1] < indent_counts[2]

    def test_three_level_numbered_list(self):
        r = NotionToMarkdownRenderer(make_config())
        level3 = make_numbered_list_item("inner")
        level2 = make_numbered_list_item("middle", children=[level3])
        level1 = make_numbered_list_item("outer", children=[level2])
        md = r.render_blocks([level1])
        assert "outer" in md
        assert "middle" in md
        assert "inner" in md


class TestQuoteWithListChildren:
    """Quote blocks containing list items render with > prefix on all lines."""

    def test_quote_with_bulleted_list_child(self):
        r = NotionToMarkdownRenderer(make_config())
        bullet = make_bulleted_list_item("list item")
        block = make_quote("intro", children=[bullet])
        md = r.render_blocks([block])
        assert "> intro" in md
        assert "list item" in md

    def test_quote_with_three_paragraph_children_all_prefixed(self):
        r = NotionToMarkdownRenderer(make_config())
        children = [
            make_paragraph([_make_text_segment("first")]),
            make_paragraph([_make_text_segment("second")]),
            make_paragraph([_make_text_segment("third")]),
        ]
        block = make_quote("header", children=children)
        md = r.render_blocks([block])
        assert "> header" in md
        assert "first" in md
        assert "second" in md
        assert "third" in md


class TestParagraphWithChildren:
    """Paragraph blocks may contain children (line 201 branch)."""

    def test_paragraph_with_child_paragraph_renders_both(self):
        r = NotionToMarkdownRenderer(make_config())
        child = make_paragraph([_make_text_segment("child text")])
        block = {
            "type": "paragraph",
            "paragraph": {
                "rich_text": [_make_text_segment("parent text")],
                "children": [child],
            },
        }
        md = r.render_blocks([block])
        assert "parent text" in md
        assert "child text" in md


class TestTableEdgeCases:
    """Edge cases in _render_table (lines 321, 326, 355)."""

    def test_table_with_no_children_returns_empty(self):
        """Table block with no children renders as empty string (line 321)."""
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "table",
            "table": {
                "table_width": 2,
                "has_column_header": False,
                "has_row_header": False,
            },
        }
        md = r.render_blocks([block])
        assert md == ""

    def test_table_with_non_row_children_returns_empty(self):
        """Table children that aren't table_row blocks render as empty string (line 326)."""
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "table",
            "table": {
                "table_width": 2,
                "has_column_header": False,
                "has_row_header": False,
                "children": [
                    {"type": "paragraph", "paragraph": {"rich_text": []}},
                ],
            },
        }
        md = r.render_blocks([block])
        assert md == ""

    def test_table_row_shorter_than_col_count_padded(self):
        """Rows shorter than table_width are padded with empty cells (line 355)."""
        r = NotionToMarkdownRenderer(make_config())
        block = {
            "type": "table",
            "table": {
                "table_width": 3,
                "has_column_header": False,
                "has_row_header": False,
                "children": [
                    {"type": "table_row", "table_row": {"cells": [
                        [_make_text_segment("A")],
                    ]}},
                ],
            },
        }
        md = r.render_blocks([block])
        # Row has only 1 cell but table_width=3; output should have 3 columns
        assert "| A |  |  |" in md
