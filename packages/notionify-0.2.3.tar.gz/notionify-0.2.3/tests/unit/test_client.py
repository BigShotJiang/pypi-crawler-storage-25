"""Tests for NotionifyClient (sync) and AsyncNotionifyClient (async).

All Notion API calls are mocked so that these tests run entirely offline.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from notionify.async_client import AsyncNotionifyClient
from notionify.client import NotionifyClient
from notionify.errors import NotionifyImageNotFoundError
from notionify.models import (
    AppendResult,
    BlockUpdateResult,
    ConversionResult,
    ImageSourceType,
    InsertResult,
    PageCreateResult,
    PendingImage,
    UpdateResult,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_sync_client() -> NotionifyClient:
    """Create a NotionifyClient with a mocked transport."""
    return NotionifyClient(token="test-token")


def _page_create_response(page_id: str = "page-1", url: str = "https://notion.so/page-1") -> dict:
    return {"id": page_id, "url": url}


def _append_response(*block_ids: str) -> dict:
    return {"results": [{"id": bid} for bid in block_ids]}


def _block_dict(
    block_type: str = "paragraph",
    block_id: str = "blk-1",
    text: str = "hello",
) -> dict:
    return {
        "id": block_id,
        "type": block_type,
        "has_children": False,
        block_type: {
            "rich_text": [{"type": "text", "text": {"content": text}, "plain_text": text}],
        },
    }


# ===========================================================================
# Sync client tests
# ===========================================================================


class TestNotionifyClientInit:
    def test_creates_all_components(self):
        from notionify.config import NotionifyConfig
        from notionify.converter.md_to_notion import MarkdownToNotionConverter
        from notionify.converter.notion_to_md import NotionToMarkdownRenderer
        from notionify.diff.executor import DiffExecutor
        from notionify.diff.planner import DiffPlanner
        from notionify.notion_api.blocks import BlockAPI
        from notionify.notion_api.files import FileAPI
        from notionify.notion_api.pages import PageAPI
        from notionify.notion_api.transport import NotionTransport

        client = NotionifyClient(token="test-token")
        assert isinstance(client._config, NotionifyConfig)
        assert client._config.token == "test-token"
        assert isinstance(client._transport, NotionTransport)
        assert isinstance(client._pages, PageAPI)
        assert isinstance(client._blocks, BlockAPI)
        assert isinstance(client._files, FileAPI)
        assert isinstance(client._converter, MarkdownToNotionConverter)
        assert isinstance(client._renderer, NotionToMarkdownRenderer)
        assert isinstance(client._diff_planner, DiffPlanner)
        assert isinstance(client._diff_executor, DiffExecutor)
        client.close()

    def test_forwards_kwargs_to_config(self):
        client = NotionifyClient(
            token="test-token",
            base_url="https://custom.api/v1",
            retry_max_attempts=10,
        )
        assert client._config.base_url == "https://custom.api/v1"
        assert client._config.retry_max_attempts == 10
        client.close()

    def test_context_manager(self):
        with NotionifyClient(token="test-token") as client:
            assert client._config.token == "test-token"


class TestCreatePageWithMarkdown:
    def test_basic_page_creation(self):
        client = _make_sync_client()
        client._pages.create = MagicMock(return_value=_page_create_response())
        client._blocks.append_children = MagicMock(return_value=_append_response())

        result = client.create_page_with_markdown(
            parent_id="parent-1",
            title="Test Page",
            markdown="Hello world",
        )

        assert isinstance(result, PageCreateResult)
        assert result.page_id == "page-1"
        assert result.url == "https://notion.so/page-1"
        assert result.blocks_created >= 1
        assert result.images_uploaded == 0

        # Verify page was created with correct parent
        call_kwargs = client._pages.create.call_args
        assert call_kwargs[1]["parent"] == {"page_id": "parent-1"} or \
               call_kwargs.kwargs.get("parent") == {"page_id": "parent-1"} or \
               (call_kwargs[0][0] if call_kwargs[0] else None) == {"page_id": "parent-1"}

        client.close()

    def test_create_page_database_parent_uses_data_source_id_on_2025_api(self):
        client = _make_sync_client()
        client._transport.request = MagicMock(side_effect=[
            {"data_sources": [{"id": "ds-1", "name": "Default"}]},
            {"properties": {"Name": {"type": "title", "title": {}}}},
        ])
        client._pages.create = MagicMock(return_value=_page_create_response())

        client.create_page_with_markdown(
            parent_id="db-1",
            title="DB Page",
            markdown="Content",
            parent_type="database",
        )

        call_args = client._pages.create.call_args
        parent = call_args.kwargs.get("parent") or call_args[0][0]
        assert parent == {"type": "data_source_id", "data_source_id": "ds-1"}
        client.close()

    def test_create_page_database_parent_loads_schema_from_data_source(self):
        client = _make_sync_client()
        client._transport.request = MagicMock(side_effect=[
            {"data_sources": [{"id": "ds-1", "name": "Default"}]},
            {"properties": {"Name": {"type": "title", "title": {}}}},
        ])
        client._pages.create = MagicMock(return_value=_page_create_response())

        client.create_page_with_markdown(
            parent_id="db-1",
            title="DB Page",
            markdown="Content",
            parent_type="database",
        )

        client._transport.request.assert_any_call("GET", "/databases/db-1")
        client._transport.request.assert_any_call("GET", "/data_sources/ds-1")
        client.close()

    def test_create_page_database_parent_uses_actual_title_property_name(self):
        client = _make_sync_client()
        client._transport.request = MagicMock(side_effect=[
            {"data_sources": [{"id": "ds-1", "name": "Default"}]},
            {
                "properties": {
                    "Tag": {"type": "multi_select", "multi_select": {}},
                    "标题": {"type": "title", "title": {}},
                }
            },
        ])
        client._pages.create = MagicMock(return_value=_page_create_response())

        client.create_page_with_markdown(
            parent_id="db-1",
            title="DB Page",
            markdown="Content",
            parent_type="database",
        )

        call_args = client._pages.create.call_args
        properties = call_args.kwargs.get("properties") or call_args[0][1]
        assert properties["标题"] == {
            "title": [{"text": {"content": "DB Page"}}]
        }
        assert "title" not in properties
        client.close()

    def test_invalid_parent_type_raises(self):
        client = _make_sync_client()
        with pytest.raises(ValueError, match="parent_type must be"):
            client.create_page_with_markdown(
                parent_id="p-1",
                title="T",
                markdown="M",
                parent_type="invalid",
            )
        client.close()

    def test_title_from_h1(self):
        client = _make_sync_client()
        client._pages.create = MagicMock(return_value=_page_create_response())
        client._blocks.append_children = MagicMock(return_value=_append_response())

        _result = client.create_page_with_markdown(
            parent_id="parent-1",
            title="Fallback Title",
            markdown="# My Real Title\n\nSome content.",
            title_from_h1=True,
        )

        call_args = client._pages.create.call_args
        properties = call_args.kwargs.get("properties") or call_args[0][1]
        title_content = properties["title"][0]["text"]["content"]
        assert title_content == "My Real Title"
        client.close()

    def test_large_content_chunked(self):
        """Verify that >100 blocks are chunked into multiple API calls."""
        client = _make_sync_client()

        # Generate markdown that produces >100 blocks
        lines = [f"Paragraph {i}" for i in range(120)]
        markdown = "\n\n".join(lines)

        client._pages.create = MagicMock(return_value=_page_create_response())
        client._blocks.append_children = MagicMock(return_value=_append_response())

        result = client.create_page_with_markdown(
            parent_id="parent-1",
            title="Big Page",
            markdown=markdown,
        )

        assert result.blocks_created == 120
        # First batch goes via create, remaining via append_children
        assert client._blocks.append_children.call_count >= 1
        client.close()

    def test_custom_properties_merged(self):
        client = _make_sync_client()
        client._pages.create = MagicMock(return_value=_page_create_response())

        client.create_page_with_markdown(
            parent_id="p-1",
            title="Title",
            markdown="text",
            properties={"custom_prop": "value"},
        )

        call_args = client._pages.create.call_args
        properties = call_args.kwargs.get("properties") or call_args[0][1]
        assert "title" in properties
        assert properties["custom_prop"] == "value"
        client.close()


class TestAppendMarkdown:
    def test_basic_append(self):
        client = _make_sync_client()
        client._blocks.append_children = MagicMock(return_value=_append_response("b1"))

        result = client.append_markdown(
            target_id="page-1",
            markdown="New paragraph",
        )

        assert isinstance(result, AppendResult)
        assert result.blocks_appended >= 1
        assert result.images_uploaded == 0
        client.close()


class TestOverwritePageContent:
    def test_overwrite_archives_existing(self):
        client = _make_sync_client()
        existing_blocks = [
            _block_dict(block_id="old-1"),
            _block_dict(block_id="old-2"),
        ]
        client._blocks.get_children = MagicMock(return_value=existing_blocks)
        client._blocks.delete = MagicMock(return_value={})
        client._blocks.append_children = MagicMock(return_value=_append_response())

        result = client.overwrite_page_content(
            page_id="page-1",
            markdown="Replacement content",
        )

        assert isinstance(result, UpdateResult)
        assert result.strategy_used == "overwrite"
        assert result.blocks_deleted == 2
        assert result.blocks_inserted >= 1
        assert result.blocks_kept == 0
        assert client._blocks.delete.call_count == 2
        client.close()


class TestUpdatePageFromMarkdown:
    def test_invalid_strategy_raises(self):
        client = _make_sync_client()
        with pytest.raises(ValueError, match="strategy must be"):
            client.update_page_from_markdown(
                page_id="p-1", markdown="M", strategy="invalid"
            )
        client.close()

    def test_invalid_on_conflict_raises(self):
        client = _make_sync_client()
        with pytest.raises(ValueError, match="on_conflict must be"):
            client.update_page_from_markdown(
                page_id="p-1", markdown="M", on_conflict="invalid"
            )
        client.close()

    def test_overwrite_strategy_delegates(self):
        client = _make_sync_client()
        client._blocks.get_children = MagicMock(return_value=[])
        client._blocks.delete = MagicMock(return_value={})
        client._blocks.append_children = MagicMock(return_value=_append_response())

        result = client.update_page_from_markdown(
            page_id="page-1",
            markdown="Content",
            strategy="overwrite",
        )

        assert result.strategy_used == "overwrite"
        client.close()

    def test_diff_strategy(self):
        client = _make_sync_client()
        existing = [_block_dict(block_id="b1", text="hello")]
        page_obj = {"last_edited_time": "2024-01-15T10:00:00.000Z"}
        client._pages.retrieve = MagicMock(return_value=page_obj)
        client._blocks.get_children = MagicMock(return_value=existing)
        client._blocks.delete = MagicMock(return_value={})
        client._blocks.append_children = MagicMock(
            return_value=_append_response("new-1")
        )
        client._blocks.update = MagicMock(return_value={})

        result = client.update_page_from_markdown(
            page_id="page-1",
            markdown="New content entirely different",
            strategy="diff",
        )

        assert isinstance(result, UpdateResult)
        assert result.strategy_used == "diff"
        client.close()

    def test_diff_debug_dump_diff(self, capsys):
        """debug_dump_diff prints the diff plan to stderr."""
        client = NotionifyClient(token="test-token", debug_dump_diff=True)
        existing = [_block_dict(block_id="b1", text="hello")]
        page_obj = {"last_edited_time": "2024-01-15T10:00:00.000Z"}
        client._pages.retrieve = MagicMock(return_value=page_obj)
        client._blocks.get_children = MagicMock(return_value=existing)
        client._blocks.delete = MagicMock(return_value={})
        client._blocks.append_children = MagicMock(
            return_value=_append_response("new-1")
        )
        client._blocks.update = MagicMock(return_value={})

        client.update_page_from_markdown(
            page_id="page-1",
            markdown="Different text",
            strategy="diff",
        )

        captured = capsys.readouterr()
        assert "[notionify] Diff plan:" in captured.err
        client.close()

    def test_diff_conflict_raises(self):
        """on_conflict='raise' raises NotionifyDiffConflictError on conflict."""
        from notionify.errors import NotionifyDiffConflictError

        client = _make_sync_client()
        existing = [_block_dict(block_id="b1", text="hello")]
        # First retrieve returns old timestamp, second returns new (conflict)
        client._pages.retrieve = MagicMock(side_effect=[
            {"last_edited_time": "2024-01-15T10:00:00.000Z"},
            {"last_edited_time": "2024-01-15T10:05:00.000Z"},
        ])
        client._blocks.get_children = MagicMock(return_value=existing)

        with pytest.raises(NotionifyDiffConflictError):
            client.update_page_from_markdown(
                page_id="page-1",
                markdown="New text",
                strategy="diff",
                on_conflict="raise",
            )
        client.close()

    def test_diff_conflict_overwrite_fallback(self):
        """on_conflict='overwrite' falls back to full overwrite on conflict."""
        client = _make_sync_client()
        existing = [_block_dict(block_id="b1", text="hello")]
        client._pages.retrieve = MagicMock(side_effect=[
            {"last_edited_time": "2024-01-15T10:00:00.000Z"},
            {"last_edited_time": "2024-01-15T10:05:00.000Z"},
        ])
        client._blocks.get_children = MagicMock(return_value=existing)
        client._blocks.delete = MagicMock(return_value={})
        client._blocks.append_children = MagicMock(
            return_value=_append_response("new-1")
        )

        result = client.update_page_from_markdown(
            page_id="page-1",
            markdown="New text",
            strategy="diff",
            on_conflict="overwrite",
        )

        assert result.strategy_used == "overwrite"
        client.close()


class TestUpdateBlock:
    def test_basic_update(self):
        client = _make_sync_client()
        client._blocks.update = MagicMock(return_value={})

        result = client.update_block(
            block_id="block-1",
            markdown_fragment="Updated text",
        )

        assert isinstance(result, BlockUpdateResult)
        assert result.block_id == "block-1"
        assert client._blocks.update.called
        client.close()

    def test_empty_markdown(self):
        client = _make_sync_client()
        client._blocks.update = MagicMock(return_value={})

        result = client.update_block(block_id="b-1", markdown_fragment="")
        assert result.block_id == "b-1"
        client.close()


class TestDeleteBlock:
    def test_delete_calls_api(self):
        client = _make_sync_client()
        client._blocks.delete = MagicMock(return_value={})

        client.delete_block(block_id="block-1")
        client._blocks.delete.assert_called_once_with("block-1")
        client.close()


class TestInsertAfter:
    def test_basic_insert(self):
        client = _make_sync_client()
        client._blocks.retrieve = MagicMock(return_value={
            "id": "block-1",
            "parent": {"page_id": "page-1"},
        })
        client._blocks.append_children = MagicMock(
            return_value=_append_response("new-1", "new-2")
        )

        result = client.insert_after(
            block_id="block-1",
            markdown_fragment="First\n\nSecond",
        )

        assert isinstance(result, InsertResult)
        assert len(result.inserted_block_ids) >= 1
        client.close()


class TestPageToMarkdown:
    def test_basic_export(self):
        client = _make_sync_client()
        client._blocks.get_children = MagicMock(return_value=[
            _block_dict(block_type="paragraph", block_id="p1", text="Hello world"),
        ])

        md = client.page_to_markdown(page_id="page-1")
        assert "Hello world" in md
        client.close()

    def test_recursive_export(self):
        parent_block = _block_dict(block_type="paragraph", block_id="p1", text="Parent")
        parent_block["has_children"] = True

        child_block = _block_dict(block_type="paragraph", block_id="c1", text="Child")

        client = _make_sync_client()
        call_count = [0]
        def mock_get_children(block_id):
            call_count[0] += 1
            if block_id == "page-1":
                return [parent_block]
            if block_id == "p1":
                return [child_block]
            return []

        client._blocks.get_children = MagicMock(side_effect=mock_get_children)

        md = client.page_to_markdown(page_id="page-1", recursive=True)
        assert "Parent" in md
        assert "Child" in md
        client.close()

    def test_recursive_max_depth(self):
        """Ensure recursion stops at max_depth."""
        parent = _block_dict(block_type="paragraph", block_id="p1", text="Level 0")
        parent["has_children"] = True

        child = _block_dict(block_type="paragraph", block_id="c1", text="Level 1")
        child["has_children"] = True

        grandchild = _block_dict(block_type="paragraph", block_id="g1", text="Level 2")

        client = _make_sync_client()
        children_map = {
            "page-1": [parent],
            "p1": [child],
            "c1": [grandchild],
        }
        def mock_get_children(block_id):
            return children_map.get(block_id, [])

        client._blocks.get_children = MagicMock(side_effect=mock_get_children)

        # max_depth=1 means only fetch children of the top-level blocks
        md = client.page_to_markdown(page_id="page-1", recursive=True, max_depth=1)
        assert "Level 0" in md
        assert "Level 1" in md
        # Level 2 should NOT be fetched because depth=1 stops recursion
        # at depth >= max_depth
        assert "Level 2" not in md
        client.close()


class TestBlockToMarkdown:
    def test_basic_block_export(self):
        client = _make_sync_client()
        client._blocks.get_children = MagicMock(return_value=[
            _block_dict(block_type="heading_1", block_id="h1", text="Title"),
            _block_dict(block_type="paragraph", block_id="p1", text="Body"),
        ])

        md = client.block_to_markdown(block_id="some-block")
        assert "Title" in md
        assert "Body" in md
        client.close()


class TestProcessImages:
    def test_no_images_returns_zero(self):
        client = _make_sync_client()
        conversion = ConversionResult(blocks=[{"type": "paragraph"}], images=[], warnings=[])
        count = client._process_images(conversion)
        assert count == 0
        client.close()

    def test_external_url_skipped(self):
        client = _make_sync_client()
        conversion = ConversionResult(
            blocks=[{"type": "image"}],
            images=[PendingImage(
                src="https://example.com/img.png",
                source_type=ImageSourceType.EXTERNAL_URL,
                block_index=0,
            )],
            warnings=[],
        )
        count = client._process_images(conversion)
        assert count == 0
        client.close()

    def test_unknown_source_skipped(self):
        client = _make_sync_client()
        conversion = ConversionResult(
            blocks=[{"type": "paragraph"}],
            images=[PendingImage(src="???", source_type=ImageSourceType.UNKNOWN, block_index=0)],
            warnings=[],
        )
        count = client._process_images(conversion)
        assert count == 0
        client.close()

    def test_local_file_not_found_skip_policy(self):
        client = NotionifyClient(token="test-token", image_fallback="skip")
        conversion = ConversionResult(
            blocks=[{"type": "image"}],
            images=[PendingImage(
                src="/nonexistent/image.png",
                source_type=ImageSourceType.LOCAL_FILE,
                block_index=0,
            )],
            warnings=[],
        )
        count = client._process_images(conversion)
        assert count == 0
        # Block should have been removed (None cleaned up)
        assert len(conversion.blocks) == 0
        assert any(w.code == "IMAGE_SKIPPED" for w in conversion.warnings)
        client.close()

    def test_local_file_not_found_placeholder_policy(self):
        client = NotionifyClient(token="test-token", image_fallback="placeholder")
        conversion = ConversionResult(
            blocks=[{"type": "image"}],
            images=[PendingImage(
                src="/nonexistent/image.png",
                source_type=ImageSourceType.LOCAL_FILE,
                block_index=0,
            )],
            warnings=[],
        )
        count = client._process_images(conversion)
        assert count == 0
        assert len(conversion.blocks) == 1
        assert "[image:" in conversion.blocks[0]["paragraph"]["rich_text"][0]["text"]["content"]
        client.close()

    def test_local_file_not_found_raise_policy(self):
        client = NotionifyClient(token="test-token", image_fallback="raise")
        conversion = ConversionResult(
            blocks=[{"type": "image"}],
            images=[PendingImage(
                src="/nonexistent/image.png",
                source_type=ImageSourceType.LOCAL_FILE,
                block_index=0,
            )],
            warnings=[],
        )
        with pytest.raises(NotionifyImageNotFoundError):
            client._process_images(conversion)
        client.close()

    def test_upload_disabled(self):
        client = NotionifyClient(token="test-token", image_upload=False)
        conversion = ConversionResult(
            blocks=[{"type": "image"}],
            images=[PendingImage(
                src="/some/image.png",
                source_type=ImageSourceType.LOCAL_FILE,
                block_index=0,
            )],
            warnings=[],
        )
        count = client._process_images(conversion)
        assert count == 0
        client.close()

    def test_local_file_upload_success(self, tmp_path):
        """Test successful upload of a local file."""
        # Create a temporary PNG-like file
        img_file = tmp_path / "test.png"
        # Minimal PNG header
        png_header = b"\x89PNG\r\n\x1a\n" + b"\x00" * 100
        img_file.write_bytes(png_header)

        client = _make_sync_client()
        # Mock the file upload
        client._files.create_upload = MagicMock(return_value={
            "id": "upload-123",
            "upload_url": "https://upload.example.com/123",
        })
        client._files.send_part = MagicMock(return_value=None)

        conversion = ConversionResult(
            blocks=[{"type": "image", "image": {}}],
            images=[PendingImage(
                src=str(img_file),
                source_type=ImageSourceType.LOCAL_FILE,
                block_index=0,
            )],
            warnings=[],
        )

        count = client._process_images(conversion)
        assert count == 1
        # The block should have been replaced with an uploaded image block
        assert conversion.blocks[0]["image"]["type"] == "file_upload"
        assert conversion.blocks[0]["image"]["file_upload"]["id"] == "upload-123"
        client.close()

    def test_data_uri_upload_success(self):
        """Test successful upload of a data URI image."""
        import base64
        # Create a small PNG data URI
        png_bytes = b"\x89PNG\r\n\x1a\n" + b"\x00" * 50
        encoded = base64.b64encode(png_bytes).decode()
        data_uri = f"data:image/png;base64,{encoded}"

        client = _make_sync_client()
        client._files.create_upload = MagicMock(return_value={
            "id": "upload-456",
            "upload_url": "https://upload.example.com/456",
        })
        client._files.send_part = MagicMock(return_value=None)

        conversion = ConversionResult(
            blocks=[{"type": "image", "image": {}}],
            images=[PendingImage(
                src=data_uri,
                source_type=ImageSourceType.DATA_URI,
                block_index=0,
            )],
            warnings=[],
        )

        count = client._process_images(conversion)
        assert count == 1
        assert conversion.blocks[0]["image"]["type"] == "file_upload"
        assert conversion.blocks[0]["image"]["file_upload"]["id"] == "upload-456"
        client.close()


class TestFetchBlocksRecursive:
    def test_no_children(self):
        client = _make_sync_client()
        blocks = [_block_dict(block_id="b1")]
        client._blocks.get_children = MagicMock(return_value=[])

        client._fetch_blocks_recursive(blocks, current_depth=0, max_depth=None)
        # get_children should NOT be called since has_children is False
        client._blocks.get_children.assert_not_called()
        client.close()

    def test_with_children(self):
        client = _make_sync_client()
        parent = _block_dict(block_id="p1", text="Parent")
        parent["has_children"] = True

        child = _block_dict(block_id="c1", text="Child")

        client._blocks.get_children = MagicMock(return_value=[child])

        blocks = [parent]
        client._fetch_blocks_recursive(blocks, current_depth=0, max_depth=None)

        assert "children" in blocks[0].get("paragraph", {}) or "children" in blocks[0]
        client.close()

    def test_respects_max_depth(self):
        client = _make_sync_client()
        blocks = [_block_dict(block_id="b1")]
        blocks[0]["has_children"] = True

        client._blocks.get_children = MagicMock(return_value=[])

        client._fetch_blocks_recursive(blocks, current_depth=5, max_depth=5)
        # Should not fetch because current_depth >= max_depth
        client._blocks.get_children.assert_not_called()
        client.close()


# ===========================================================================
# Async client tests
# ===========================================================================


class TestAsyncNotionifyClientInit:
    def test_creates_all_components(self):
        from notionify.config import NotionifyConfig
        from notionify.diff.executor import AsyncDiffExecutor
        from notionify.diff.planner import DiffPlanner
        from notionify.notion_api.blocks import AsyncBlockAPI
        from notionify.notion_api.files import AsyncFileAPI
        from notionify.notion_api.pages import AsyncPageAPI
        from notionify.notion_api.transport import AsyncNotionTransport

        client = AsyncNotionifyClient(token="test-token")
        assert isinstance(client._config, NotionifyConfig)
        assert client._config.token == "test-token"
        assert isinstance(client._transport, AsyncNotionTransport)
        assert isinstance(client._pages, AsyncPageAPI)
        assert isinstance(client._blocks, AsyncBlockAPI)
        assert isinstance(client._files, AsyncFileAPI)
        assert isinstance(client._diff_planner, DiffPlanner)
        assert isinstance(client._diff_executor, AsyncDiffExecutor)

    def test_forwards_kwargs_to_config(self):
        client = AsyncNotionifyClient(
            token="test-token",
            base_url="https://custom.api/v1",
        )
        assert client._config.base_url == "https://custom.api/v1"


class TestAsyncCreatePageWithMarkdown:
    @pytest.mark.asyncio
    async def test_invalid_parent_type_raises(self):
        client = AsyncNotionifyClient(token="test-token")
        with pytest.raises(ValueError, match="parent_type must be"):
            await client.create_page_with_markdown(
                parent_id="p-1", title="T", markdown="M", parent_type="bad"
            )
        await client.close()

    @pytest.mark.asyncio
    async def test_basic_page_creation(self):
        client = AsyncNotionifyClient(token="test-token")
        client._pages.create = AsyncMock(return_value=_page_create_response())
        client._blocks.append_children = AsyncMock(return_value=_append_response())

        result = await client.create_page_with_markdown(
            parent_id="parent-1",
            title="Test Page",
            markdown="Hello world",
        )

        assert isinstance(result, PageCreateResult)
        assert result.page_id == "page-1"
        assert result.blocks_created >= 1
        await client.close()

    @pytest.mark.asyncio
    async def test_title_from_h1(self):
        client = AsyncNotionifyClient(token="test-token")
        client._pages.create = AsyncMock(return_value=_page_create_response())
        client._blocks.append_children = AsyncMock(return_value=_append_response())

        await client.create_page_with_markdown(
            parent_id="parent-1",
            title="Fallback",
            markdown="# Extracted Title\n\nContent",
            title_from_h1=True,
        )

        call_args = client._pages.create.call_args
        properties = call_args.kwargs.get("properties") or call_args[0][1]
        assert properties["title"][0]["text"]["content"] == "Extracted Title"
        await client.close()

    @pytest.mark.asyncio
    async def test_large_content_chunked(self):
        """Verify that >100 blocks are chunked into multiple API calls (async)."""
        client = AsyncNotionifyClient(token="test-token")

        lines = [f"Paragraph {i}" for i in range(120)]
        markdown = "\n\n".join(lines)

        client._pages.create = AsyncMock(return_value=_page_create_response())
        client._blocks.append_children = AsyncMock(return_value=_append_response())

        result = await client.create_page_with_markdown(
            parent_id="parent-1",
            title="Big Page",
            markdown=markdown,
        )

        assert result.blocks_created == 120
        assert client._blocks.append_children.await_count >= 1
        await client.close()

    @pytest.mark.asyncio
    async def test_custom_properties_merged(self):
        """Custom properties are merged alongside the title property (async)."""
        client = AsyncNotionifyClient(token="test-token")
        client._pages.create = AsyncMock(return_value=_page_create_response())

        await client.create_page_with_markdown(
            parent_id="p-1",
            title="Title",
            markdown="text",
            properties={"custom_prop": "value"},
        )

        call_args = client._pages.create.call_args
        properties = call_args.kwargs.get("properties") or call_args[0][1]
        assert "title" in properties
        assert properties["custom_prop"] == "value"
        await client.close()


class TestAsyncAppendMarkdown:
    @pytest.mark.asyncio
    async def test_basic_append(self):
        client = AsyncNotionifyClient(token="test-token")
        client._blocks.append_children = AsyncMock(return_value=_append_response("b1"))

        result = await client.append_markdown(
            target_id="page-1",
            markdown="New content",
        )

        assert isinstance(result, AppendResult)
        assert result.blocks_appended >= 1
        await client.close()


class TestAsyncOverwritePageContent:
    @pytest.mark.asyncio
    async def test_overwrite(self):
        client = AsyncNotionifyClient(token="test-token")
        client._blocks.get_children = AsyncMock(return_value=[
            _block_dict(block_id="old-1"),
        ])
        client._blocks.delete = AsyncMock(return_value={})
        client._blocks.append_children = AsyncMock(return_value=_append_response())

        result = await client.overwrite_page_content(
            page_id="page-1",
            markdown="New content",
        )

        assert result.strategy_used == "overwrite"
        assert result.blocks_deleted == 1
        await client.close()


class TestAsyncUpdatePageFromMarkdown:
    @pytest.mark.asyncio
    async def test_invalid_strategy_raises(self):
        client = AsyncNotionifyClient(token="test-token")
        with pytest.raises(ValueError, match="strategy must be"):
            await client.update_page_from_markdown(
                page_id="p-1", markdown="M", strategy="bad"
            )
        await client.close()

    @pytest.mark.asyncio
    async def test_invalid_on_conflict_raises(self):
        client = AsyncNotionifyClient(token="test-token")
        with pytest.raises(ValueError, match="on_conflict must be"):
            await client.update_page_from_markdown(
                page_id="p-1", markdown="M", on_conflict="bad"
            )
        await client.close()

    @pytest.mark.asyncio
    async def test_diff_strategy(self):
        client = AsyncNotionifyClient(token="test-token")
        page_obj = {"last_edited_time": "2024-01-15T10:00:00.000Z"}
        client._pages.retrieve = AsyncMock(return_value=page_obj)
        client._blocks.get_children = AsyncMock(return_value=[
            _block_dict(block_id="b1", text="old"),
        ])
        client._blocks.delete = AsyncMock(return_value={})
        client._blocks.append_children = AsyncMock(return_value=_append_response("new-1"))
        client._blocks.update = AsyncMock(return_value={})

        result = await client.update_page_from_markdown(
            page_id="page-1",
            markdown="New text",
            strategy="diff",
        )

        assert result.strategy_used == "diff"
        await client.close()

    @pytest.mark.asyncio
    async def test_diff_debug_dump_diff(self, capsys):
        """debug_dump_diff prints the diff plan to stderr (async)."""
        client = AsyncNotionifyClient(token="test-token", debug_dump_diff=True)
        page_obj = {"last_edited_time": "2024-01-15T10:00:00.000Z"}
        client._pages.retrieve = AsyncMock(return_value=page_obj)
        client._blocks.get_children = AsyncMock(return_value=[
            _block_dict(block_id="b1", text="old"),
        ])
        client._blocks.delete = AsyncMock(return_value={})
        client._blocks.append_children = AsyncMock(return_value=_append_response("new-1"))
        client._blocks.update = AsyncMock(return_value={})

        await client.update_page_from_markdown(
            page_id="page-1",
            markdown="New text",
            strategy="diff",
        )

        captured = capsys.readouterr()
        assert "[notionify] Diff plan:" in captured.err
        await client.close()

    @pytest.mark.asyncio
    async def test_diff_conflict_raises(self):
        """on_conflict='raise' raises NotionifyDiffConflictError (async)."""
        from notionify.errors import NotionifyDiffConflictError

        client = AsyncNotionifyClient(token="test-token")
        existing = [_block_dict(block_id="b1", text="old")]
        client._pages.retrieve = AsyncMock(side_effect=[
            {"last_edited_time": "2024-01-15T10:00:00.000Z"},
            {"last_edited_time": "2024-01-15T10:05:00.000Z"},
        ])
        client._blocks.get_children = AsyncMock(return_value=existing)

        with pytest.raises(NotionifyDiffConflictError):
            await client.update_page_from_markdown(
                page_id="page-1",
                markdown="New text",
                strategy="diff",
                on_conflict="raise",
            )
        await client.close()

    @pytest.mark.asyncio
    async def test_diff_conflict_overwrite_fallback(self):
        """on_conflict='overwrite' falls back on conflict (async)."""
        client = AsyncNotionifyClient(token="test-token")
        existing = [_block_dict(block_id="b1", text="old")]
        client._pages.retrieve = AsyncMock(side_effect=[
            {"last_edited_time": "2024-01-15T10:00:00.000Z"},
            {"last_edited_time": "2024-01-15T10:05:00.000Z"},
        ])
        client._blocks.get_children = AsyncMock(return_value=existing)
        client._blocks.delete = AsyncMock(return_value={})
        client._blocks.append_children = AsyncMock(return_value=_append_response("new-1"))

        result = await client.update_page_from_markdown(
            page_id="page-1",
            markdown="New text",
            strategy="diff",
            on_conflict="overwrite",
        )

        assert result.strategy_used == "overwrite"
        await client.close()


class TestAsyncUpdateBlock:
    @pytest.mark.asyncio
    async def test_basic_update(self):
        client = AsyncNotionifyClient(token="test-token")
        client._blocks.update = AsyncMock(return_value={})

        result = await client.update_block(
            block_id="block-1",
            markdown_fragment="Updated",
        )

        assert isinstance(result, BlockUpdateResult)
        assert result.block_id == "block-1"
        await client.close()


class TestAsyncDeleteBlock:
    @pytest.mark.asyncio
    async def test_delete(self):
        client = AsyncNotionifyClient(token="test-token")
        client._blocks.delete = AsyncMock(return_value={})

        await client.delete_block(block_id="block-1")
        client._blocks.delete.assert_awaited_once_with("block-1")
        await client.close()


class TestAsyncInsertAfter:
    @pytest.mark.asyncio
    async def test_basic_insert(self):
        client = AsyncNotionifyClient(token="test-token")
        client._blocks.retrieve = AsyncMock(return_value={
            "id": "block-1",
            "parent": {"page_id": "page-1"},
        })
        client._blocks.append_children = AsyncMock(
            return_value=_append_response("new-1")
        )

        result = await client.insert_after(
            block_id="block-1",
            markdown_fragment="Inserted text",
        )

        assert isinstance(result, InsertResult)
        assert len(result.inserted_block_ids) >= 1
        await client.close()


class TestAsyncPageToMarkdown:
    @pytest.mark.asyncio
    async def test_basic_export(self):
        client = AsyncNotionifyClient(token="test-token")
        client._blocks.get_children = AsyncMock(return_value=[
            _block_dict(block_type="paragraph", block_id="p1", text="Exported text"),
        ])

        md = await client.page_to_markdown(page_id="page-1")
        assert "Exported text" in md
        await client.close()

    @pytest.mark.asyncio
    async def test_recursive_export(self):
        parent_block = _block_dict(block_type="paragraph", block_id="p1", text="Parent")
        parent_block["has_children"] = True

        child_block = _block_dict(block_type="paragraph", block_id="c1", text="Child")

        client = AsyncNotionifyClient(token="test-token")

        async def mock_get_children(block_id):
            if block_id == "page-1":
                return [parent_block]
            if block_id == "p1":
                return [child_block]
            return []

        client._blocks.get_children = AsyncMock(side_effect=mock_get_children)

        md = await client.page_to_markdown(page_id="page-1", recursive=True)
        assert "Parent" in md
        assert "Child" in md
        await client.close()

    @pytest.mark.asyncio
    async def test_recursive_max_depth(self):
        """Ensure recursion stops at max_depth (async)."""
        parent = _block_dict(block_type="paragraph", block_id="p1", text="Level 0")
        parent["has_children"] = True

        child = _block_dict(block_type="paragraph", block_id="c1", text="Level 1")
        child["has_children"] = True

        grandchild = _block_dict(block_type="paragraph", block_id="g1", text="Level 2")

        client = AsyncNotionifyClient(token="test-token")
        children_map = {
            "page-1": [parent],
            "p1": [child],
            "c1": [grandchild],
        }

        async def mock_get_children(block_id):
            return children_map.get(block_id, [])

        client._blocks.get_children = AsyncMock(side_effect=mock_get_children)

        md = await client.page_to_markdown(page_id="page-1", recursive=True, max_depth=1)
        assert "Level 0" in md
        assert "Level 1" in md
        assert "Level 2" not in md
        await client.close()


class TestAsyncBlockToMarkdown:
    @pytest.mark.asyncio
    async def test_block_export(self):
        client = AsyncNotionifyClient(token="test-token")
        client._blocks.get_children = AsyncMock(return_value=[
            _block_dict(block_type="heading_1", block_id="h1", text="Heading"),
        ])

        md = await client.block_to_markdown(block_id="blk-root")
        assert "Heading" in md
        await client.close()


class TestAsyncProcessImages:
    @pytest.mark.asyncio
    async def test_no_images(self):
        client = AsyncNotionifyClient(token="test-token")
        conversion = ConversionResult(blocks=[], images=[], warnings=[])
        count = await client._process_images(conversion)
        assert count == 0
        await client.close()

    @pytest.mark.asyncio
    async def test_concurrent_uploads(self, tmp_path):
        """Test that multiple images are uploaded with concurrency control."""
        # Create temp files
        img_files = []
        for i in range(3):
            img_file = tmp_path / f"test{i}.png"
            img_file.write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 50)
            img_files.append(img_file)

        client = AsyncNotionifyClient(token="test-token", image_max_concurrent=2)
        client._files.create_upload = AsyncMock(side_effect=[
            {"id": f"upload-{i}", "upload_url": f"https://upload.example.com/{i}"}
            for i in range(3)
        ])
        client._files.send_part = AsyncMock(return_value=None)

        conversion = ConversionResult(
            blocks=[{"type": "image"} for _ in range(3)],
            images=[
                PendingImage(src=str(f), source_type=ImageSourceType.LOCAL_FILE, block_index=i)
                for i, f in enumerate(img_files)
            ],
            warnings=[],
        )

        count = await client._process_images(conversion)
        assert count == 3
        await client.close()


class TestAsyncContextManager:
    @pytest.mark.asyncio
    async def test_aenter_aexit(self):
        async with AsyncNotionifyClient(token="test-token") as client:
            assert client._config.token == "test-token"


class TestAsyncFetchBlocksRecursive:
    @pytest.mark.asyncio
    async def test_respects_max_depth(self):
        client = AsyncNotionifyClient(token="test-token")
        blocks = [_block_dict(block_id="b1")]
        blocks[0]["has_children"] = True

        client._blocks.get_children = AsyncMock(return_value=[])

        await client._fetch_blocks_recursive(blocks, current_depth=3, max_depth=3)
        client._blocks.get_children.assert_not_called()
        await client.close()

    @pytest.mark.asyncio
    async def test_unlimited_depth(self):
        client = AsyncNotionifyClient(token="test-token")

        parent = _block_dict(block_id="p1", text="Parent")
        parent["has_children"] = True

        child = _block_dict(block_id="c1", text="Child")

        async def mock_get_children(block_id):
            if block_id == "p1":
                return [child]
            return []

        client._blocks.get_children = AsyncMock(side_effect=mock_get_children)

        blocks = [parent]
        await client._fetch_blocks_recursive(blocks, current_depth=0, max_depth=None)

        # Children should be attached
        block_type = parent["type"]
        assert "children" in parent.get(block_type, {}) or "children" in parent
        await client.close()


# ===========================================================================
# Additional async_client coverage tests
# ===========================================================================


class TestMimeToExtension:
    def test_known_types(self):
        from notionify.image.detect import mime_to_extension
        assert mime_to_extension("image/jpeg") == ".jpg"
        assert mime_to_extension("image/png") == ".png"
        assert mime_to_extension("image/gif") == ".gif"
        assert mime_to_extension("image/webp") == ".webp"
        assert mime_to_extension("image/svg+xml") == ".svg"
        assert mime_to_extension("image/bmp") == ".bmp"
        assert mime_to_extension("image/tiff") == ".tiff"

    def test_unknown_type_returns_bin(self):
        from notionify.image.detect import mime_to_extension
        assert mime_to_extension("application/octet-stream") == ".bin"


class TestHandleImageError:
    @pytest.mark.asyncio
    async def test_raise_policy_reraises(self):
        from notionify.errors import NotionifyImageError
        client = AsyncNotionifyClient(token="test-token", image_fallback="raise")
        exc = NotionifyImageError(message="fail", context={})
        pending = PendingImage(src="img.png", source_type=ImageSourceType.LOCAL_FILE, block_index=0)
        blocks = [{"type": "image"}]
        warnings = []
        with pytest.raises(NotionifyImageError):
            client._handle_image_error(pending, blocks, warnings, exc)
        await client.close()

    @pytest.mark.asyncio
    async def test_placeholder_policy_replaces_block(self):
        from notionify.errors import NotionifyImageError
        client = AsyncNotionifyClient(token="test-token", image_fallback="placeholder")
        exc = NotionifyImageError(message="upload fail", context={})
        pending = PendingImage(src="img.png", source_type=ImageSourceType.LOCAL_FILE, block_index=0)
        blocks = [{"type": "image"}]
        warnings = []
        client._handle_image_error(pending, blocks, warnings, exc)
        assert blocks[0]["type"] == "paragraph"
        assert len(warnings) == 1
        assert warnings[0].code == "IMAGE_UPLOAD_FAILED"
        await client.close()

    @pytest.mark.asyncio
    async def test_skip_policy_marks_sentinel(self):
        from notionify.errors import NotionifyImageError
        client = AsyncNotionifyClient(token="test-token", image_fallback="skip")
        exc = NotionifyImageError(message="upload fail", context={})
        pending = PendingImage(src="img.png", source_type=ImageSourceType.LOCAL_FILE, block_index=0)
        sentinel = {"_notionify_skip": True}
        blocks = [{"type": "image"}]
        warnings = []
        client._handle_image_error(pending, blocks, warnings, exc, skip_sentinel=sentinel)
        assert blocks[0] is sentinel
        assert len(warnings) == 1
        assert warnings[0].code == "IMAGE_SKIPPED"
        await client.close()


class TestAsyncProcessSingleImage:
    @pytest.mark.asyncio
    async def test_external_url_returns_zero(self):
        client = AsyncNotionifyClient(token="test-token")
        pending = PendingImage(src="https://example.com/img.png",
                               source_type=ImageSourceType.EXTERNAL_URL, block_index=0)
        result = await client._process_single_image(pending, [], [])
        assert result == 0
        await client.close()

    @pytest.mark.asyncio
    async def test_unknown_source_returns_zero(self):
        client = AsyncNotionifyClient(token="test-token")
        pending = PendingImage(src="???", source_type=ImageSourceType.UNKNOWN, block_index=0)
        result = await client._process_single_image(pending, [], [])
        assert result == 0
        await client.close()


class TestAsyncDoUpload:
    @pytest.mark.asyncio
    async def test_large_file_uses_multi_part(self):
        """Files larger than image_max_size_bytes use multi-part upload."""
        client = AsyncNotionifyClient(token="test-token", image_max_size_bytes=10)
        client._files.create_upload = AsyncMock(return_value={
            "id": "upload-mp",
            "upload_urls": [{"upload_url": "https://s3/p1"}, {"upload_url": "https://s3/p2"}],
        })
        client._files.send_part = AsyncMock(return_value=None)
        client._files.complete_upload = AsyncMock(return_value={})

        big_data = b"x" * 20  # > image_max_size_bytes=10
        result = await client._do_upload("big.png", "image/png", big_data)
        assert result == "upload-mp"
        client._files.create_upload.assert_called_once()
        await client.close()


class TestAsyncUploadDataUri:
    @pytest.mark.asyncio
    async def test_data_uri_upload(self):
        import base64
        client = AsyncNotionifyClient(token="test-token")
        # Create a valid PNG data URI
        png_data = b"\x89PNG\r\n\x1a\n" + b"\x00" * 20
        b64 = base64.b64encode(png_data).decode()
        data_uri = f"data:image/png;base64,{b64}"

        pending = PendingImage(src=data_uri, source_type=ImageSourceType.DATA_URI, block_index=0)
        blocks = [{"type": "image"}]

        with patch("notionify.async_client.validate_image") as mock_validate:
            mock_validate.return_value = ("image/png", png_data)
            with patch(
                "notionify.async_client.async_upload_single",
                new=AsyncMock(return_value="upload-uri"),
            ):
                result = await client._process_single_image(pending, blocks, [])

        assert result == 1
        assert blocks[0]["type"] == "image"
        await client.close()


class TestAsyncCreatePageDatabase:
    @pytest.mark.asyncio
    async def test_create_page_with_database_parent(self):
        client = AsyncNotionifyClient(token="test-token")
        client._pages.create = AsyncMock(return_value={"id": "pg-db", "url": "https://notion.so/p"})
        client._blocks.append_children = AsyncMock(return_value={"results": []})
        client._transport.request = AsyncMock(side_effect=[
            {"data_sources": [{"id": "ds-123", "name": "Default"}]},
            {"properties": {"Name": {"type": "title", "title": {}}}},
        ])

        result = await client.create_page_with_markdown(
            parent_id="db-123",
            title="Hello",
            markdown="# Hello",
            parent_type="database",
        )
        assert result.page_id == "pg-db"
        call_args = client._pages.create.call_args
        assert call_args.kwargs["parent"] == {
            "type": "data_source_id",
            "data_source_id": "ds-123",
        }
        assert call_args.kwargs["properties"]["Name"] == {
            "title": [{"text": {"content": "Hello"}}]
        }
        await client.close()


class TestFetchBlocksRecursiveElseBranch:
    @pytest.mark.asyncio
    async def test_block_type_not_in_block_uses_children_key(self):
        """When block_type not in block dict, children go under block['children']."""
        client = AsyncNotionifyClient(token="test-token")
        # block_type is "paragraph" but block dict doesn't have "paragraph" key
        block = {"id": "b1", "type": "paragraph", "has_children": True}
        child = {"id": "c1", "type": "paragraph", "has_children": False}
        client._blocks.get_children = AsyncMock(return_value=[child])

        await client._fetch_blocks_recursive([block], current_depth=0, max_depth=1)
        assert block.get("children") == [child]
        await client.close()


# =========================================================================
# Additional async_client tests for remaining coverage gaps
# =========================================================================


class TestAsyncCreatePageMultipleBatches:
    """create_page appends remaining batches when blocks > 100 (line 172)."""

    @pytest.mark.asyncio
    async def test_large_markdown_appends_batches(self):
        """More than 100 blocks causes append_children for extra batches."""
        client = AsyncNotionifyClient(token="test-token")
        client._pages.create = AsyncMock(return_value={"id": "pg-1", "url": "https://n.so/p"})
        client._blocks.append_children = AsyncMock(return_value={"results": []})

        # 101 paragraphs → first batch of 100, second batch of 1
        big_markdown = "\n\n".join(f"Paragraph {i}" for i in range(101))
        result = await client.create_page_with_markdown(
            parent_id="p-parent", title="Big Page", markdown=big_markdown,
        )
        assert result.page_id == "pg-1"
        client._blocks.append_children.assert_awaited_once()  # second batch
        await client.close()


class TestAsyncUpdatePageOverwriteStrategy:
    """update_page_from_markdown with strategy='overwrite' delegates (line 309)."""

    @pytest.mark.asyncio
    async def test_overwrite_strategy(self):
        client = AsyncNotionifyClient(token="test-token")
        client._blocks.get_children = AsyncMock(return_value=[])
        client._blocks.delete = AsyncMock(return_value={})
        client._blocks.append_children = AsyncMock(return_value={"results": []})

        result = await client.update_page_from_markdown(
            page_id="page-1",
            markdown="New content",
            strategy="overwrite",
        )
        assert result.strategy_used == "overwrite"
        await client.close()


class TestAsyncUpdateBlockEmpty:
    """update_block with empty markdown returns early (line 361)."""

    @pytest.mark.asyncio
    async def test_empty_markdown_returns_early(self):
        client = AsyncNotionifyClient(token="test-token")
        result = await client.update_block(block_id="b-1", markdown_fragment="")
        assert isinstance(result, BlockUpdateResult)
        assert result.block_id == "b-1"
        await client.close()


class TestAsyncInsertAfterEmpty:
    """insert_after with empty markdown returns early (line 413)."""

    @pytest.mark.asyncio
    async def test_empty_markdown_returns_early(self):
        client = AsyncNotionifyClient(token="test-token")
        result = await client.insert_after(block_id="b-1", markdown_fragment="")
        assert isinstance(result, InsertResult)
        assert result.inserted_block_ids == []
        await client.close()


class TestAsyncProcessImagesExceptionHandling:
    """_process_images catches NotionifyImageError (lines 550-555)."""

    @pytest.mark.asyncio
    async def test_image_error_caught_and_handled(self, tmp_path):
        from notionify.errors import NotionifyImageError
        from notionify.models import ConversionResult

        client = AsyncNotionifyClient(token="test-token", image_fallback="placeholder")

        # Create a real file that fails validation
        bad_file = tmp_path / "bad.png"
        bad_file.write_bytes(b"not a valid image")

        conversion = ConversionResult(
            blocks=[{"type": "image"}],
            images=[
                PendingImage(
                    src=str(bad_file),
                    source_type=ImageSourceType.LOCAL_FILE,
                    block_index=0,
                )
            ],
            warnings=[],
        )

        # Mock upload to raise NotionifyImageError
        with patch("notionify.async_client.validate_image",
                   side_effect=NotionifyImageError(message="bad image", context={})):
            count = await client._process_images(conversion)

        # Should handle the error gracefully (placeholder policy)
        assert count == 0
        await client.close()


class TestAsyncUploadLocalFileEdgeCases:
    """Edge cases in _upload_local_file (lines 597-600, 607, 623)."""

    @pytest.mark.asyncio
    async def test_file_not_found_raises(self, tmp_path):
        from notionify.errors import NotionifyImageNotFoundError

        client = AsyncNotionifyClient(token="test-token")
        pending = PendingImage(
            src=str(tmp_path / "nonexistent.png"),
            source_type=ImageSourceType.LOCAL_FILE,
            block_index=0,
        )
        with pytest.raises(NotionifyImageNotFoundError):
            await client._upload_local_file(pending, [], [])
        await client.close()

    @pytest.mark.asyncio
    async def test_validate_returns_none_data_uses_raw(self, tmp_path):
        """When validate_image returns None for data, raw bytes are used."""
        from unittest.mock import AsyncMock as AM
        from unittest.mock import patch

        img_data = b"\x89PNG\r\n\x1a\n" + b"\x00" * 20
        img_file = tmp_path / "test.png"
        img_file.write_bytes(img_data)

        client = AsyncNotionifyClient(token="test-token")

        # validate_image returns (mime, None) → raw bytes should be used
        with (
            patch("notionify.async_client.validate_image", return_value=("image/png", None)),
            patch("notionify.async_client.async_upload_single", new=AM(return_value="uid-1")),
        ):
            pending = PendingImage(
                src=str(img_file),
                source_type=ImageSourceType.LOCAL_FILE,
                block_index=0,
            )
            blocks = [{"type": "image"}]
            result = await client._upload_local_file(pending, blocks, [])

        assert result == 1
        await client.close()


class TestAsyncUploadDataUriNone:
    """_upload_data_uri returns 0 when decoded_data is None (line 649)."""

    @pytest.mark.asyncio
    async def test_none_decoded_data_returns_zero(self):
        from unittest.mock import patch

        client = AsyncNotionifyClient(token="test-token")
        pending = PendingImage(
            src="data:image/png;base64,INVALID",
            source_type=ImageSourceType.DATA_URI,
            block_index=0,
        )

        # validate_image returns None decoded data
        with patch("notionify.async_client.validate_image", return_value=("image/png", None)):
            result = await client._upload_data_uri(pending, [], [])

        assert result == 0
        await client.close()


class TestFetchBlocksRecursiveNoId:
    """Blocks without id are skipped in _fetch_blocks_recursive (line 747)."""

    @pytest.mark.asyncio
    async def test_block_without_id_is_skipped(self):
        client = AsyncNotionifyClient(token="test-token")
        # Block has has_children=True but no "id" key
        block = {"type": "paragraph", "has_children": True}
        client._blocks.get_children = AsyncMock(return_value=[])

        await client._fetch_blocks_recursive([block], current_depth=0, max_depth=5)
        client._blocks.get_children.assert_not_awaited()
        await client.close()


# ---- Metrics emission tests ------------------------------------------------


class TestMetricsEmission:
    """Verify that metrics are emitted via the MetricsHook protocol."""

    def _make_client_with_mock_metrics(self):
        client = NotionifyClient(token="test-token")
        metrics = MagicMock()
        client._metrics = metrics
        return client, metrics

    def test_blocks_created_total_emitted(self):
        client, metrics = self._make_client_with_mock_metrics()
        client._pages.create = MagicMock(return_value={"id": "page-1", "url": ""})
        client._blocks.append_children = MagicMock(return_value={"results": []})

        client.create_page_with_markdown("parent-1", "Title", "# Hello")

        # Check that blocks_created_total was called
        increment_calls = [
            c for c in metrics.increment.call_args_list
            if c[0][0] == "notionify.blocks_created_total"
        ]
        assert len(increment_calls) > 0

    def test_conversion_warnings_total_emitted(self):
        """Emit conversion_warnings_total when conversion produces warnings."""
        client, metrics = self._make_client_with_mock_metrics()
        client._pages.create = MagicMock(return_value={"id": "page-1", "url": ""})
        client._blocks.append_children = MagicMock(return_value={"results": []})

        # HTML blocks produce an HTML_BLOCK_SKIPPED warning
        client.create_page_with_markdown(
            "parent-1", "Title", "<div>html content</div>",
        )

        warning_calls = [
            c for c in metrics.increment.call_args_list
            if c[0][0] == "notionify.conversion_warnings_total"
        ]
        assert len(warning_calls) > 0

    def test_page_export_duration_ms_emitted(self):
        client, metrics = self._make_client_with_mock_metrics()
        client._blocks.get_children = MagicMock(return_value=[])

        client.page_to_markdown("page-1")

        timing_calls = [
            c for c in metrics.timing.call_args_list
            if c[0][0] == "notionify.page_export_duration_ms"
        ]
        assert len(timing_calls) == 1
        assert timing_calls[0][1]["tags"]["recursive"] == "false"

    def test_page_export_duration_ms_recursive(self):
        client, metrics = self._make_client_with_mock_metrics()
        client._blocks.get_children = MagicMock(return_value=[])

        client.page_to_markdown("page-1", recursive=True)

        timing_calls = [
            c for c in metrics.timing.call_args_list
            if c[0][0] == "notionify.page_export_duration_ms"
        ]
        assert len(timing_calls) == 1
        assert timing_calls[0][1]["tags"]["recursive"] == "true"

    def test_block_to_markdown_emits_timing(self):
        client, metrics = self._make_client_with_mock_metrics()
        client._blocks.get_children = MagicMock(return_value=[])

        client.block_to_markdown("block-1")

        timing_calls = [
            c for c in metrics.timing.call_args_list
            if c[0][0] == "notionify.page_export_duration_ms"
        ]
        assert len(timing_calls) == 1

    def test_upload_success_total_emitted(self):
        client, metrics = self._make_client_with_mock_metrics()

        with patch("notionify.client.upload_single", return_value="upload-id"):
            result = client._do_upload("img.png", "image/png", b"data")

        assert result == "upload-id"
        success_calls = [
            c for c in metrics.increment.call_args_list
            if c[0][0] == "notionify.upload_success_total"
        ]
        assert len(success_calls) == 1
        assert success_calls[0][1]["tags"]["mode"] == "single"

    def test_upload_failure_total_emitted(self):
        from notionify.errors import NotionifyImageError
        from notionify.models import ConversionWarning, PendingImage

        client, metrics = self._make_client_with_mock_metrics()
        pending = PendingImage(
            src="test.png", source_type=ImageSourceType.LOCAL_FILE,
            block_index=0,
        )
        exc = NotionifyImageError(message="fail", context={})
        blocks: list[dict] = [{"type": "image"}]
        warnings: list[ConversionWarning] = []

        client._handle_image_error(pending, blocks, warnings, exc)

        failure_calls = [
            c for c in metrics.increment.call_args_list
            if c[0][0] == "notionify.upload_failure_total"
        ]
        assert len(failure_calls) == 1


class TestAsyncMetricsEmission:
    """Verify async client metrics emission."""

    @pytest.mark.asyncio
    async def test_page_export_duration_ms_emitted(self):
        client = AsyncNotionifyClient(token="test-token")
        metrics = MagicMock()
        client._metrics = metrics
        client._blocks.get_children = AsyncMock(return_value=[])

        await client.page_to_markdown("page-1")

        timing_calls = [
            c for c in metrics.timing.call_args_list
            if c[0][0] == "notionify.page_export_duration_ms"
        ]
        assert len(timing_calls) == 1
        await client.close()

    @pytest.mark.asyncio
    async def test_blocks_created_total_emitted(self):
        client = AsyncNotionifyClient(token="test-token")
        metrics = MagicMock()
        client._metrics = metrics
        client._pages.create = AsyncMock(return_value={"id": "page-1", "url": ""})
        client._blocks.append_children = AsyncMock(return_value={"results": []})

        await client.create_page_with_markdown("parent-1", "Title", "# Hello")

        increment_calls = [
            c for c in metrics.increment.call_args_list
            if c[0][0] == "notionify.blocks_created_total"
        ]
        assert len(increment_calls) > 0
        await client.close()

    @pytest.mark.asyncio
    async def test_conversion_warnings_total_emitted(self):
        client = AsyncNotionifyClient(token="test-token")
        metrics = MagicMock()
        client._metrics = metrics
        client._pages.create = AsyncMock(return_value={"id": "page-1", "url": ""})
        client._blocks.append_children = AsyncMock(return_value={"results": []})

        # HTML blocks produce an HTML_BLOCK_SKIPPED warning
        await client.create_page_with_markdown(
            "parent-1", "Title", "<div>html content</div>",
        )

        warning_calls = [
            c for c in metrics.increment.call_args_list
            if c[0][0] == "notionify.conversion_warnings_total"
        ]
        assert len(warning_calls) > 0
        await client.close()


# =========================================================================
# Sync client branch coverage tests
# =========================================================================

class TestSyncClientBranchCoverage:
    """Branch coverage for client.py (148->158, 150->155, 265->263, 488->482,
    560->563, 681->688, 709->712, 737->740, 786->789)."""

    def test_title_from_h1_first_block_not_heading(self):
        """title_from_h1=True but first block is not heading_1 (branch 148->158)."""
        client = _make_sync_client()
        client._pages.create = MagicMock(return_value=_page_create_response())
        client._blocks.append_children = MagicMock(return_value=_append_response("b1"))

        result = client.create_page_with_markdown(
            parent_id="parent-1",
            title="Fallback",
            markdown="A paragraph first.\n\n# Heading later",
            title_from_h1=True,
        )
        call_args = client._pages.create.call_args
        properties = call_args.kwargs.get("properties") or call_args[0][1]
        title_content = properties["title"][0]["text"]["content"]
        assert title_content == "Fallback"
        assert isinstance(result, PageCreateResult)
        client.close()

    def test_title_from_h1_heading_with_empty_rich_text(self):
        """heading_1 block with empty rich_text leaves title unchanged (branch 150->155)."""
        from notionify.models import ConversionResult as CR
        client = _make_sync_client()
        client._pages.create = MagicMock(return_value=_page_create_response())
        client._blocks.append_children = MagicMock(return_value=_append_response("b1"))

        empty_heading = {
            "object": "block", "type": "heading_1",
            "heading_1": {"rich_text": [], "color": "default", "is_toggleable": False},
        }
        client._converter.convert = MagicMock(
            return_value=CR(blocks=[empty_heading], images=[], warnings=[]),
        )
        client.create_page_with_markdown(
            parent_id="parent-1", title="Original", markdown="# \n",
            title_from_h1=True,
        )
        call_args = client._pages.create.call_args
        properties = call_args.kwargs.get("properties") or call_args[0][1]
        title_content = properties["title"][0]["text"]["content"]
        assert title_content == "Original"
        client.close()

    def test_overwrite_block_without_id_skipped(self):
        """Block without 'id' skipped in overwrite delete (branch 265->263)."""
        client = _make_sync_client()
        client._blocks.get_children = MagicMock(return_value=[
            {"type": "paragraph", "paragraph": {}},  # no 'id'
        ])
        client._blocks.delete = MagicMock()
        client._blocks.append_children = MagicMock(return_value=_append_response("b1"))

        client.overwrite_page_content(page_id="page-1", markdown="New content")
        client._blocks.delete.assert_not_called()
        client.close()

    def test_insert_after_empty_new_ids_after_id_unchanged(self):
        """append_children returns no new_ids, after_id stays unchanged (branch 488->482)."""
        client = _make_sync_client()
        client._blocks.retrieve = MagicMock(return_value={
            "id": "block-1", "parent": {"page_id": "page-1"},
        })
        client._blocks.append_children = MagicMock(return_value={"results": []})

        result = client.insert_after(block_id="block-1", markdown_fragment="Hello")
        assert isinstance(result, InsertResult)
        client.close()

    def test_block_to_markdown_recursive_false(self):
        """block_to_markdown with recursive=False skips fetch (branch 560->563)."""
        client = _make_sync_client()
        parent_block = _block_dict(block_type="paragraph", block_id="p1", text="Parent")
        parent_block["has_children"] = True
        parent_block["paragraph"]["color"] = "default"
        client._blocks.get_children = MagicMock(return_value=[parent_block])

        md = client.block_to_markdown(block_id="p1", recursive=False)
        assert "Parent" in md
        # get_children called only once (no recursive fetch)
        client._blocks.get_children.assert_called_once()
        client.close()

    def test_upload_local_file_within_base_dir(self, tmp_path):
        """File within image_base_dir proceeds to upload (branch 681->688)."""
        img_file = tmp_path / "photo.png"
        img_file.write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 100)

        client = NotionifyClient(token="test-token", image_base_dir=str(tmp_path))
        client._files.create_upload = MagicMock(return_value={
            "id": "upload-1", "upload_url": "https://upload.example.com/1",
        })
        client._files.send_part = MagicMock(return_value=None)

        pending = PendingImage(
            src="photo.png",
            source_type=ImageSourceType.LOCAL_FILE,
            block_index=0,
        )
        blocks = [{"type": "image"}]
        result = client._upload_local_file(pending, blocks, [])
        assert result == 1
        client.close()

    def test_upload_local_file_block_index_out_of_range(self, tmp_path):
        """block_index OOB skips block update in _upload_local_file (branch 709->712)."""
        img_file = tmp_path / "photo.png"
        img_file.write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 100)

        client = _make_sync_client()
        client._files.create_upload = MagicMock(return_value={
            "id": "upload-1", "upload_url": "https://upload.example.com/1",
        })
        client._files.send_part = MagicMock(return_value=None)

        pending = PendingImage(
            src=str(img_file),
            source_type=ImageSourceType.LOCAL_FILE,
            block_index=99,  # out of range
        )
        blocks = [{"type": "image"}]
        result = client._upload_local_file(pending, blocks, [])
        assert result == 1
        assert blocks[0]["type"] == "image"  # not replaced
        client.close()

    def test_upload_data_uri_block_index_out_of_range(self):
        """block_index OOB skips block update in _upload_data_uri (branch 737->740)."""
        import base64
        png_bytes = b"\x89PNG\r\n\x1a\n" + b"\x00" * 50
        data_uri = "data:image/png;base64," + base64.b64encode(png_bytes).decode()

        client = _make_sync_client()
        client._files.create_upload = MagicMock(return_value={
            "id": "upload-1", "upload_url": "https://upload.example.com/1",
        })
        client._files.send_part = MagicMock(return_value=None)

        pending = PendingImage(
            src=data_uri,
            source_type=ImageSourceType.DATA_URI,
            block_index=99,  # out of range
        )
        blocks = [{"type": "image"}]
        result = client._upload_data_uri(pending, blocks, [])
        assert result == 1
        assert blocks[0]["type"] == "image"  # not replaced
        client.close()

    def test_handle_image_error_placeholder_block_index_oob(self):
        """block_index OOB in placeholder fallback skips block update (branch 786->789)."""
        from notionify.errors import NotionifyImageNotFoundError

        client = NotionifyClient(token="test-token", image_fallback="placeholder")
        pending = PendingImage(
            src="img.png", source_type=ImageSourceType.LOCAL_FILE, block_index=99,
        )
        blocks = [{"type": "image"}]
        warnings_list: list = []
        exc = NotionifyImageNotFoundError(message="not found", context={})

        client._handle_image_error(pending, blocks, warnings_list, exc)
        assert blocks[0]["type"] == "image"  # not replaced
        assert any(w.code == "IMAGE_UPLOAD_FAILED" for w in warnings_list)
        client.close()


# =========================================================================
# Async client branch coverage tests
# =========================================================================

class TestAsyncClientBranchCoverage:
    """Branch coverage for async_client.py (152->162, 154->159, 168->170,
    269->267, 486->480, 560->565, 687->694, 718->721, 745->748, 794->797,
    806->809)."""

    @pytest.mark.asyncio
    async def test_title_from_h1_first_block_not_heading(self):
        """title_from_h1=True but first block is not heading_1 (branch 152->162)."""
        client = AsyncNotionifyClient(token="test-token")
        client._pages.create = AsyncMock(return_value={"id": "pg-1", "url": ""})
        client._blocks.append_children = AsyncMock(return_value={"results": []})

        await client.create_page_with_markdown(
            parent_id="parent-1",
            title="Fallback",
            markdown="A paragraph first.\n\n# Heading later",
            title_from_h1=True,
        )
        call_args = client._pages.create.call_args
        properties = call_args.kwargs.get("properties") or call_args[0][1]
        title_content = properties["title"][0]["text"]["content"]
        assert title_content == "Fallback"
        await client.close()

    @pytest.mark.asyncio
    async def test_title_from_h1_heading_with_empty_rich_text(self):
        """heading_1 block with empty rich_text leaves title unchanged (branch 154->159)."""
        from notionify.models import ConversionResult as CR
        client = AsyncNotionifyClient(token="test-token")
        client._pages.create = AsyncMock(return_value={"id": "pg-1", "url": ""})
        client._blocks.append_children = AsyncMock(return_value={"results": []})

        empty_heading = {
            "object": "block", "type": "heading_1",
            "heading_1": {"rich_text": [], "color": "default", "is_toggleable": False},
        }
        client._converter.convert = MagicMock(
            return_value=CR(blocks=[empty_heading], images=[], warnings=[]),
        )
        await client.create_page_with_markdown(
            parent_id="parent-1", title="Original", markdown="# \n",
            title_from_h1=True,
        )
        call_args = client._pages.create.call_args
        properties = call_args.kwargs.get("properties") or call_args[0][1]
        title_content = properties["title"][0]["text"]["content"]
        assert title_content == "Original"
        await client.close()

    @pytest.mark.asyncio
    async def test_create_page_with_explicit_properties_dict(self):
        """properties is not None skips assignment at line 169 (branch 168->170)."""
        client = AsyncNotionifyClient(token="test-token")
        client._pages.create = AsyncMock(return_value={"id": "pg-1", "url": ""})
        client._blocks.append_children = AsyncMock(return_value={"results": []})

        result = await client.create_page_with_markdown(
            parent_id="parent-1",
            title="Title",
            markdown="Hello",
            properties={"custom_prop": [{"text": {"content": "val"}}]},
        )
        assert result.page_id == "pg-1"
        call_args = client._pages.create.call_args
        properties = call_args.kwargs.get("properties") or call_args[0][1]
        assert "custom_prop" in properties
        await client.close()

    @pytest.mark.asyncio
    async def test_async_overwrite_block_without_id_skipped(self):
        """Block without 'id' skipped in async overwrite delete (branch 269->267)."""
        client = AsyncNotionifyClient(token="test-token")
        client._blocks.get_children = AsyncMock(return_value=[
            {"type": "paragraph", "paragraph": {}},  # no 'id'
        ])
        client._blocks.delete = AsyncMock()
        client._blocks.append_children = AsyncMock(return_value={"results": []})

        await client.overwrite_page_content(page_id="page-1", markdown="New")
        client._blocks.delete.assert_not_awaited()
        await client.close()

    @pytest.mark.asyncio
    async def test_async_insert_after_empty_new_ids(self):
        """append_children returns no new_ids, after_id stays (branch 486->480)."""
        client = AsyncNotionifyClient(token="test-token")
        client._blocks.retrieve = AsyncMock(return_value={
            "id": "block-1", "parent": {"page_id": "page-1"},
        })
        client._blocks.append_children = AsyncMock(return_value={"results": []})

        result = await client.insert_after(block_id="block-1", markdown_fragment="Hello")
        assert isinstance(result, InsertResult)
        await client.close()

    @pytest.mark.asyncio
    async def test_async_block_to_markdown_recursive_true(self):
        """async block_to_markdown with recursive=False skips fetch (branch 560->565)."""
        client = AsyncNotionifyClient(token="test-token")
        parent_block = _block_dict(block_type="paragraph", block_id="p1", text="Parent")
        parent_block["has_children"] = True
        parent_block["paragraph"]["color"] = "default"
        client._blocks.get_children = AsyncMock(return_value=[parent_block])

        md = await client.block_to_markdown(block_id="p1", recursive=False)
        assert "Parent" in md
        # get_children called only once (no recursive fetch)
        client._blocks.get_children.assert_awaited_once()
        await client.close()

    @pytest.mark.asyncio
    async def test_async_upload_local_file_within_base_dir(self, tmp_path):
        """File within image_base_dir proceeds to upload (branch 687->694)."""
        img_file = tmp_path / "photo.png"
        img_file.write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 100)

        client = AsyncNotionifyClient(token="test-token", image_base_dir=str(tmp_path))
        _upload_mock = AsyncMock(return_value="uid-1")
        with (
            patch("notionify.async_client.validate_image",
                  return_value=("image/png", b"\x89PNG\r\n\x1a\n" + b"\x00" * 100)),
            patch("notionify.async_client.async_upload_single", new=_upload_mock),
        ):
            pending = PendingImage(
                src="photo.png",
                source_type=ImageSourceType.LOCAL_FILE,
                block_index=0,
            )
            blocks = [{"type": "image"}]
            result = await client._upload_local_file(pending, blocks, [])
        assert result == 1
        await client.close()

    @pytest.mark.asyncio
    async def test_async_upload_local_file_block_index_oob(self, tmp_path):
        """block_index OOB skips block update in async _upload_local_file (718->721)."""
        img_file = tmp_path / "photo.png"
        img_file.write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 100)

        client = AsyncNotionifyClient(token="test-token")
        _upload_mock2 = AsyncMock(return_value="uid-1")
        with (
            patch("notionify.async_client.validate_image",
                  return_value=("image/png", b"\x89PNG\r\n\x1a\n" + b"\x00" * 100)),
            patch("notionify.async_client.async_upload_single", new=_upload_mock2),
        ):
            pending = PendingImage(
                src=str(img_file),
                source_type=ImageSourceType.LOCAL_FILE,
                block_index=99,  # OOB
            )
            blocks = [{"type": "image"}]
            result = await client._upload_local_file(pending, blocks, [])
        assert result == 1
        assert blocks[0]["type"] == "image"  # not replaced
        await client.close()

    @pytest.mark.asyncio
    async def test_async_upload_data_uri_block_index_oob(self):
        """block_index OOB skips block update in async _upload_data_uri (745->748)."""
        import base64
        png_bytes = b"\x89PNG\r\n\x1a\n" + b"\x00" * 50
        data_uri = "data:image/png;base64," + base64.b64encode(png_bytes).decode()

        client = AsyncNotionifyClient(token="test-token")
        _up = AsyncMock(return_value="uid-1")
        with patch("notionify.async_client.async_upload_single", new=_up):
            pending = PendingImage(
                src=data_uri,
                source_type=ImageSourceType.DATA_URI,
                block_index=99,  # OOB
            )
            blocks = [{"type": "image"}]
            result = await client._upload_data_uri(pending, blocks, [])
        assert result == 1
        assert blocks[0]["type"] == "image"  # not replaced
        await client.close()

    @pytest.mark.asyncio
    async def test_async_handle_image_error_placeholder_block_index_oob(self):
        """block_index OOB in async placeholder fallback (branch 794->797)."""
        from notionify.errors import NotionifyImageNotFoundError

        client = AsyncNotionifyClient(token="test-token", image_fallback="placeholder")
        pending = PendingImage(
            src="img.png", source_type=ImageSourceType.LOCAL_FILE, block_index=99,
        )
        blocks = [{"type": "image"}]
        warnings_list: list = []
        exc = NotionifyImageNotFoundError(message="not found", context={})

        client._handle_image_error(pending, blocks, warnings_list, exc)
        assert blocks[0]["type"] == "image"  # not replaced
        assert any(w.code == "IMAGE_UPLOAD_FAILED" for w in warnings_list)
        await client.close()

    @pytest.mark.asyncio
    async def test_async_handle_image_error_skip_with_none_sentinel(self):
        """skip_sentinel=None skips block update in skip fallback (branch 806->809)."""
        from notionify.errors import NotionifyImageNotFoundError

        client = AsyncNotionifyClient(token="test-token", image_fallback="skip")
        pending = PendingImage(
            src="img.png", source_type=ImageSourceType.LOCAL_FILE, block_index=0,
        )
        blocks = [{"type": "image"}]
        warnings_list: list = []
        exc = NotionifyImageNotFoundError(message="not found", context={})

        # skip_sentinel=None → False branch of `if skip_sentinel is not None and ...`
        client._handle_image_error(pending, blocks, warnings_list, exc, skip_sentinel=None)
        assert blocks[0]["type"] == "image"  # not replaced
        assert any(w.code == "IMAGE_SKIPPED" for w in warnings_list)
        await client.close()


# =========================================================================
# target_type validation in append_markdown
# =========================================================================


class TestAppendMarkdownTargetTypeValidation:
    """append_markdown rejects invalid target_type values."""

    def test_sync_invalid_target_type_raises(self):
        client = _make_sync_client()
        with pytest.raises(ValueError, match="target_type must be 'page' or 'block'"):
            client.append_markdown(
                target_id="page-1",
                markdown="hello",
                target_type="invalid",
            )
        client.close()

    def test_sync_valid_page_target_type_accepted(self):
        client = _make_sync_client()
        client._blocks.append_children = MagicMock(return_value=_append_response("b1"))
        result = client.append_markdown(
            target_id="page-1", markdown="hello", target_type="page",
        )
        assert isinstance(result, AppendResult)
        client.close()

    def test_sync_valid_block_target_type_accepted(self):
        client = _make_sync_client()
        client._blocks.append_children = MagicMock(return_value=_append_response("b1"))
        result = client.append_markdown(
            target_id="block-1", markdown="hello", target_type="block",
        )
        assert isinstance(result, AppendResult)
        client.close()

    @pytest.mark.asyncio
    async def test_async_invalid_target_type_raises(self):
        client = AsyncNotionifyClient(token="test-token")
        with pytest.raises(ValueError, match="target_type must be 'page' or 'block'"):
            await client.append_markdown(
                target_id="page-1",
                markdown="hello",
                target_type="database",
            )
        await client.close()

    @pytest.mark.asyncio
    async def test_async_valid_block_target_type_accepted(self):
        client = AsyncNotionifyClient(token="test-token")
        client._blocks.append_children = AsyncMock(return_value=_append_response("b1"))
        result = await client.append_markdown(
            target_id="block-1", markdown="hello", target_type="block",
        )
        assert isinstance(result, AppendResult)
        await client.close()


# =========================================================================
# Empty / edge-case input tests for public API methods
# =========================================================================


class TestEmptyMarkdownInputs:
    """Public API methods handle empty and whitespace-only Markdown gracefully."""

    def test_create_page_empty_markdown(self):
        client = _make_sync_client()
        client._pages.create = MagicMock(return_value=_page_create_response())
        result = client.create_page_with_markdown(
            parent_id="parent-1", title="Empty", markdown="",
        )
        assert isinstance(result, PageCreateResult)
        assert result.blocks_created == 0
        client.close()

    def test_create_page_whitespace_only_markdown(self):
        client = _make_sync_client()
        client._pages.create = MagicMock(return_value=_page_create_response())
        result = client.create_page_with_markdown(
            parent_id="parent-1", title="Whitespace", markdown="   \n\n  ",
        )
        assert isinstance(result, PageCreateResult)
        client.close()

    def test_append_empty_markdown(self):
        client = _make_sync_client()
        result = client.append_markdown(target_id="page-1", markdown="")
        assert isinstance(result, AppendResult)
        assert result.blocks_appended == 0
        client.close()

    def test_overwrite_with_empty_markdown(self):
        client = _make_sync_client()
        client._blocks.get_children = MagicMock(return_value=[
            {"id": "blk-1", "type": "paragraph"},
        ])
        client._blocks.delete = MagicMock()
        result = client.overwrite_page_content(page_id="page-1", markdown="")
        assert isinstance(result, UpdateResult)
        assert result.blocks_inserted == 0
        assert result.blocks_deleted == 1
        client.close()

    def test_update_block_empty_markdown(self):
        client = _make_sync_client()
        result = client.update_block(block_id="blk-1", markdown_fragment="")
        assert isinstance(result, BlockUpdateResult)
        assert result.block_id == "blk-1"
        client.close()

    @pytest.mark.asyncio
    async def test_async_create_page_empty_markdown(self):
        client = AsyncNotionifyClient(token="test-token")
        client._pages.create = AsyncMock(return_value=_page_create_response())
        result = await client.create_page_with_markdown(
            parent_id="parent-1", title="Empty", markdown="",
        )
        assert isinstance(result, PageCreateResult)
        assert result.blocks_created == 0
        await client.close()

    @pytest.mark.asyncio
    async def test_async_append_empty_markdown(self):
        client = AsyncNotionifyClient(token="test-token")
        result = await client.append_markdown(target_id="page-1", markdown="")
        assert isinstance(result, AppendResult)
        assert result.blocks_appended == 0
        await client.close()
