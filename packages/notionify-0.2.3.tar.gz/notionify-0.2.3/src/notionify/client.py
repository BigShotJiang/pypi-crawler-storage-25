"""Synchronous Notion SDK client.

:class:`NotionifyClient` is the primary entry point for the notionify SDK.
It orchestrates the full pipeline: parse Markdown, handle images (detect,
validate, upload), chunk blocks into API-compliant batches, call the Notion
API, and return typed result objects.

Usage::

    from notionify import NotionifyClient

    with NotionifyClient(token="secret_xxx") as client:
        result = client.create_page_with_markdown(
            parent_id="<page_id>",
            title="My Page",
            markdown="# Hello\\n\\nWorld",
        )
        print(result.page_id)
"""

from __future__ import annotations

import time
from collections import Counter
from pathlib import Path
from typing import Any, Literal

from notionify.config import NotionifyConfig
from notionify.converter.md_to_notion import MarkdownToNotionConverter
from notionify.converter.notion_to_md import NotionToMarkdownRenderer
from notionify.diff.conflict import detect_conflict, take_snapshot
from notionify.diff.executor import DiffExecutor
from notionify.diff.planner import DiffPlanner
from notionify.errors import (
    NotionifyDiffConflictError,
    NotionifyImageDownloadError,
    NotionifyImageError,
    NotionifyImageNotFoundError,
)
from notionify.image import (
    build_image_block_external,
    build_image_block_uploaded,
    download_image,
    upload_multi,
    upload_single,
    validate_image,
)
from notionify.image.detect import mime_to_extension
from notionify.models import (
    AppendResult,
    BlockUpdateResult,
    ConversionResult,
    ConversionWarning,
    ImageSourceType,
    InsertResult,
    PageCreateResult,
    PendingImage,
    PlanResult,
    UpdateResult,
)
from notionify.notion_api.blocks import BlockAPI, extract_block_ids
from notionify.notion_api.files import FileAPI
from notionify.notion_api.pages import PageAPI
from notionify.notion_api.transport import NotionTransport
from notionify.observability import NoopMetricsHook
from notionify.utils.chunk import chunk_children


def _uses_data_source_api(notion_version: str) -> bool:
    """Return whether the configured Notion API version uses data sources."""
    return notion_version >= "2025-09-03"


def _find_title_property_name(properties: dict[str, Any]) -> str:
    """Return the schema property name whose Notion type is ``title``."""
    for name, schema in properties.items():
        if isinstance(schema, dict) and schema.get("type") == "title":
            return name
    raise ValueError("Database/data source schema does not contain a title property")


class NotionifyClient:
    """Synchronous Notion SDK client.

    Parameters
    ----------
    token:
        Notion integration token.  **Required.**
    **kwargs:
        All remaining keyword arguments are forwarded to
        :class:`NotionifyConfig`.
    """

    def __init__(self, token: str, **kwargs: Any) -> None:
        """Create client.  All kwargs are forwarded to NotionifyConfig."""
        self._config = NotionifyConfig(token=token, **kwargs)
        self._transport = NotionTransport(self._config)
        self._pages = PageAPI(self._transport)
        self._blocks = BlockAPI(self._transport)
        self._files = FileAPI(self._transport)
        self._converter = MarkdownToNotionConverter(self._config)
        self._renderer = NotionToMarkdownRenderer(self._config)
        self._diff_planner = DiffPlanner(self._config)
        self._diff_executor = DiffExecutor(self._blocks, self._config)
        metrics = self._config.metrics
        self._metrics = metrics if metrics is not None else NoopMetricsHook()

    # ------------------------------------------------------------------
    # Page creation
    # ------------------------------------------------------------------

    def create_page_with_markdown(
        self,
        parent_id: str,
        title: str,
        markdown: str,
        parent_type: Literal["page", "database"] = "page",
        properties: dict[str, Any] | None = None,
        title_from_h1: bool = False,
    ) -> PageCreateResult:
        """Create a new Notion page from Markdown content.

        Parameters
        ----------
        parent_id:
            ID of the parent page or database.
        title:
            Page title.  Ignored if *title_from_h1* is ``True`` and the
            Markdown starts with a level-1 heading.
        markdown:
            Raw Markdown text to convert.
        parent_type:
            ``"page"`` or ``"database"``.
        properties:
            Optional extra page properties dict (merged with the generated
            title property).
        title_from_h1:
            If ``True``, extract the title from the first H1 heading and
            remove that heading from the block list.

        Returns
        -------
        PageCreateResult

        Raises
        ------
        ValueError
            If *parent_type* is not ``"page"`` or ``"database"``.
        NotionifyImageError
            If an image in the Markdown cannot be validated or uploaded.
        NotionifyAPIError
            If the Notion API returns an error response.
        NotionifyRetryExhaustedError
            If all retry attempts are exhausted.
        """
        if parent_type not in ("page", "database"):
            msg = f"parent_type must be 'page' or 'database', got {parent_type!r}"
            raise ValueError(msg)

        # 1. Convert markdown to blocks
        conversion = self._converter.convert(markdown)
        blocks = conversion.blocks
        warnings = list(conversion.warnings)

        # 2. Handle images
        images_uploaded = self._process_images(conversion)
        warnings.extend(
            w for w in conversion.warnings if w not in warnings
        )
        self._emit_conversion_metrics(conversion)

        # 3. Extract title from H1 if requested
        effective_title = title
        if title_from_h1 and blocks:
            first = blocks[0]
            if first.get("type") == "heading_1":
                rich_text = first.get("heading_1", {}).get("rich_text", [])
                if rich_text:
                    effective_title = "".join(
                        seg.get("plain_text") or (seg.get("text") or {}).get("content") or ""
                        for seg in rich_text
                    )
                blocks = blocks[1:]

        # 4. Build parent dict
        if parent_type == "database":
            parent, title_prop_name = self._database_page_parent_and_title_property(parent_id)
        else:
            parent = {"page_id": parent_id}
            title_prop_name = "title"

        # 5. Build properties with title
        if properties is None:
            properties = {}
        if parent_type == "database":
            properties.setdefault(title_prop_name, {
                "title": [{"text": {"content": effective_title}}]
            })
        else:
            properties.setdefault(title_prop_name, [{"text": {"content": effective_title}}])

        # 6. Chunk blocks into batches of 100
        batches = chunk_children(blocks)

        # 7. Create page with first batch
        first_batch = batches[0] if batches else []
        page_response = self._pages.create(
            parent=parent,
            properties=properties,
            children=first_batch,
        )
        page_id = page_response["id"]
        page_url = page_response.get("url", "")

        # 8. Append remaining batches
        for batch in batches[1:]:
            self._blocks.append_children(page_id, batch)

        # 9. Return result
        return PageCreateResult(
            page_id=page_id,
            url=page_url,
            blocks_created=len(blocks),
            images_uploaded=images_uploaded,
            warnings=warnings,
        )

    def _database_page_parent_and_title_property(
        self,
        database_id: str,
    ) -> tuple[dict[str, Any], str]:
        """Resolve the page parent and title property for a database target."""
        if _uses_data_source_api(self._config.notion_version):
            database = self._transport.request("GET", f"/databases/{database_id}")
            data_sources = database.get("data_sources") or []
            if not data_sources:
                raise ValueError(f"Database {database_id!r} does not contain any data sources")

            data_source_id = data_sources[0]["id"]
            data_source = self._transport.request("GET", f"/data_sources/{data_source_id}")
            title_prop_name = _find_title_property_name(data_source.get("properties") or {})
            return (
                {"type": "data_source_id", "data_source_id": data_source_id},
                title_prop_name,
            )

        database = self._transport.request("GET", f"/databases/{database_id}")
        title_prop_name = _find_title_property_name(database.get("properties") or {})
        return {"database_id": database_id}, title_prop_name

    # ------------------------------------------------------------------
    # Append
    # ------------------------------------------------------------------

    def append_markdown(
        self,
        target_id: str,
        markdown: str,
        target_type: Literal["page", "block"] = "page",
    ) -> AppendResult:
        """Append Markdown content to a page or after a block.

        Parameters
        ----------
        target_id:
            ID of the page or block to append to.
        markdown:
            Raw Markdown text to convert and append.
        target_type:
            ``"page"`` or ``"block"``.

        Returns
        -------
        AppendResult

        Raises
        ------
        NotionifyImageError
            If an image in the Markdown cannot be validated or uploaded.
        NotionifyAPIError
            If the Notion API returns an error response.
        ValueError
            If *target_type* is not ``"page"`` or ``"block"``.
        NotionifyRetryExhaustedError
            If all retry attempts are exhausted.
        """
        if target_type not in ("page", "block"):
            msg = f"target_type must be 'page' or 'block', got {target_type!r}"
            raise ValueError(msg)

        conversion = self._converter.convert(markdown)
        warnings = list(conversion.warnings)
        images_uploaded = self._process_images(conversion)
        self._emit_conversion_metrics(conversion)

        blocks = conversion.blocks
        batches = chunk_children(blocks)

        for batch in batches:
            self._blocks.append_children(target_id, batch)

        return AppendResult(
            blocks_appended=len(blocks),
            images_uploaded=images_uploaded,
            warnings=warnings,
        )

    # ------------------------------------------------------------------
    # Overwrite
    # ------------------------------------------------------------------

    def overwrite_page_content(
        self,
        page_id: str,
        markdown: str,
    ) -> UpdateResult:
        """Full overwrite: archive all existing children, write new blocks.

        Parameters
        ----------
        page_id:
            The Notion page ID.
        markdown:
            New Markdown content.

        Returns
        -------
        UpdateResult
        """
        # 1. Get existing children
        existing = self._blocks.get_children(page_id)

        # 2. Archive all existing
        deleted_count = 0
        for block in existing:
            block_id = block.get("id")
            if block_id:
                self._blocks.delete(block_id)
                deleted_count += 1

        # 3. Convert new markdown
        conversion = self._converter.convert(markdown)
        warnings = list(conversion.warnings)
        images_uploaded = self._process_images(conversion)

        # 4. Chunk and append
        blocks = conversion.blocks
        batches = chunk_children(blocks)

        for batch in batches:
            self._blocks.append_children(page_id, batch)

        return UpdateResult(
            strategy_used="overwrite",
            blocks_kept=0,
            blocks_inserted=len(blocks),
            blocks_deleted=deleted_count,
            blocks_replaced=0,
            images_uploaded=images_uploaded,
            warnings=warnings,
        )

    # ------------------------------------------------------------------
    # Update (diff or overwrite) methods
    # ------------------------------------------------------------------

    def plan_page_update(
        self,
        page_id: str,
        markdown: str,
    ) -> PlanResult:
        """Plan a page update without applying changes or processing images.

        Parameters
        ----------
        page_id:
            The Notion page ID to diff against.
        markdown:
            The desired Markdown content.

        Returns
        -------
        PlanResult
            Diff operations, conversion warnings, and pending image count.
        """
        existing_blocks = self._blocks.get_children(page_id)
        conversion = self._converter.convert(markdown)
        ops = self._diff_planner.plan(existing_blocks, conversion.blocks)

        return PlanResult(
            ops=ops,
            warnings=list(conversion.warnings),
            images_to_upload=len(conversion.images),
        )

    def update_page_from_markdown(
        self,
        page_id: str,
        markdown: str,
        strategy: Literal["diff", "overwrite"] = "diff",
        on_conflict: Literal["raise", "overwrite"] = "raise",
    ) -> UpdateResult:
        """Update page with diff or overwrite strategy.

        Parameters
        ----------
        page_id:
            The Notion page ID to update.
        markdown:
            The desired Markdown content.
        strategy:
            ``"diff"`` (default) or ``"overwrite"``.
        on_conflict:
            Conflict resolution policy: ``"raise"`` (default) or
            ``"overwrite"``.  When ``"raise"``, a
            :exc:`NotionifyDiffConflictError` is raised if the page was
            modified between fetch and apply.

        Returns
        -------
        UpdateResult

        Raises
        ------
        ValueError
            If *strategy* or *on_conflict* is not a recognised value.
        NotionifyDiffConflictError
            If *on_conflict* is ``"raise"`` and the page was concurrently
            modified before the diff could be applied.
        NotionifyImageError
            If an image in the Markdown cannot be validated or uploaded.
        NotionifyAPIError
            If the Notion API returns an error response.
        NotionifyRetryExhaustedError
            If all retry attempts are exhausted.
        """
        if strategy not in ("diff", "overwrite"):
            msg = f"strategy must be 'diff' or 'overwrite', got {strategy!r}"
            raise ValueError(msg)
        if on_conflict not in ("raise", "overwrite"):
            msg = f"on_conflict must be 'raise' or 'overwrite', got {on_conflict!r}"
            raise ValueError(msg)

        if strategy == "overwrite":
            return self.overwrite_page_content(page_id, markdown)

        # 1. Fetch existing page + blocks and take a snapshot.
        page = self._pages.retrieve(page_id)
        existing_blocks = self._blocks.get_children(page_id)
        snapshot = take_snapshot(page_id, page, existing_blocks)

        # 2. Convert new markdown
        conversion = self._converter.convert(markdown)
        warnings = list(conversion.warnings)
        images_uploaded = self._process_images(conversion)

        new_blocks = conversion.blocks

        # 3. Plan diff
        ops = self._diff_planner.plan(existing_blocks, new_blocks)

        # Debug: dump diff plan
        if self._config.debug_dump_diff:
            import json
            import sys

            dump = [
                {"op": op.op_type.value, "existing_id": op.existing_id, "depth": op.depth}
                for op in ops
            ]
            print(
                "[notionify] Diff plan:",
                json.dumps(dump, indent=2, ensure_ascii=False),
                file=sys.stderr,
            )

        # 4. Conflict detection: re-fetch page state and compare.
        current_page = self._pages.retrieve(page_id)
        current_blocks = self._blocks.get_children(page_id)
        current_snapshot = take_snapshot(page_id, current_page, current_blocks)

        if detect_conflict(snapshot, current_snapshot):
            if on_conflict == "overwrite":
                return self.overwrite_page_content(page_id, markdown)
            raise NotionifyDiffConflictError(
                message=f"Page {page_id} was modified since snapshot",
                context={
                    "page_id": page_id,
                    "snapshot_time": str(snapshot.last_edited),
                    "detected_time": str(current_snapshot.last_edited),
                },
            )

        # 5. Execute diff ops
        result = self._diff_executor.execute(page_id, ops)

        # Merge warnings and image count
        result.images_uploaded = images_uploaded
        result.warnings.extend(warnings)

        return result

    # ------------------------------------------------------------------
    # Single-block operations
    # ------------------------------------------------------------------

    def update_block(
        self,
        block_id: str,
        markdown_fragment: str,
    ) -> BlockUpdateResult:
        """Update a single block with a markdown fragment.

        Parameters
        ----------
        block_id:
            The UUID of the block to update.
        markdown_fragment:
            Markdown text to convert into the block's new content.

        Returns
        -------
        BlockUpdateResult
        """
        conversion = self._converter.convert(markdown_fragment)
        warnings = list(conversion.warnings)
        self._process_images(conversion)

        if not conversion.blocks:
            return BlockUpdateResult(block_id=block_id, warnings=warnings)

        # Use the first converted block's type-specific data as the update
        # payload.
        new_block = conversion.blocks[0]
        block_type = new_block.get("type", "")
        type_data = new_block.get(block_type, {})
        payload = {block_type: type_data}

        self._blocks.update(block_id, payload)

        return BlockUpdateResult(block_id=block_id, warnings=warnings)

    def delete_block(
        self,
        block_id: str,
        archive: bool = True,
    ) -> None:
        """Delete (archive) a block.

        Parameters
        ----------
        block_id:
            The UUID of the block to delete.
        archive:
            If ``True`` (default), the block is archived rather than
            permanently deleted.  Notion does not expose permanent
            deletion via the API.  The *archive* parameter is accepted
            for API symmetry but has no effect on behaviour.

        Raises
        ------
        NotionifyAPIError
            If the Notion API returns an error response (e.g. the block
            does not exist or the token lacks permission).
        NotionifyRetryExhaustedError
            If all retry attempts are exhausted.
        """
        self._blocks.delete(block_id)

    def insert_after(
        self,
        block_id: str,
        markdown_fragment: str,
    ) -> InsertResult:
        """Insert new blocks after a given block.

        Parameters
        ----------
        block_id:
            The UUID of the block after which to insert.
        markdown_fragment:
            Markdown text to convert and insert.

        Returns
        -------
        InsertResult
        """
        conversion = self._converter.convert(markdown_fragment)
        warnings = list(conversion.warnings)
        self._process_images(conversion)

        blocks = conversion.blocks
        if not blocks:
            return InsertResult(inserted_block_ids=[], warnings=warnings)

        # We need to find the parent of block_id to append after it.
        # Retrieve the block to get its parent.
        block_info = self._blocks.retrieve(block_id)
        parent = block_info.get("parent") or {}
        parent_id = parent.get("page_id") or parent.get("block_id", "")

        inserted_ids: list[str] = []
        batches = chunk_children(blocks)

        # The first batch is inserted after block_id; subsequent batches
        # are inserted after the last block of the previous batch.
        after_id: str | None = block_id
        for batch in batches:
            response = self._blocks.append_children(
                parent_id, batch, after=after_id
            )
            new_ids = extract_block_ids(response)
            inserted_ids.extend(new_ids)
            if new_ids:
                after_id = new_ids[-1]

        return InsertResult(inserted_block_ids=inserted_ids, warnings=warnings)

    # ------------------------------------------------------------------
    # Export (Notion -> Markdown)
    # ------------------------------------------------------------------

    def page_to_markdown(
        self,
        page_id: str,
        recursive: bool = False,
        max_depth: int | None = None,
    ) -> str:
        """Export a Notion page to Markdown.

        Parameters
        ----------
        page_id:
            The Notion page ID.
        recursive:
            If ``True``, recursively fetch and render children of child
            blocks.
        max_depth:
            Maximum recursion depth when *recursive* is ``True``.
            ``None`` means unlimited.

        Returns
        -------
        str
            The rendered Markdown text.

        Raises
        ------
        NotionifyAPIError
            If the Notion API returns an error response (e.g. page not
            found or insufficient permissions).
        NotionifyRetryExhaustedError
            If all retry attempts are exhausted while fetching blocks.
        """
        t0 = time.monotonic()
        blocks = self._blocks.get_children(page_id)

        if recursive:
            self._fetch_blocks_recursive(blocks, current_depth=0, max_depth=max_depth)

        result = self._renderer.render_blocks(blocks)
        elapsed_ms = (time.monotonic() - t0) * 1000
        self._metrics.timing(
            "notionify.page_export_duration_ms", elapsed_ms,
            tags={"recursive": str(recursive).lower()},
        )
        return result

    def block_to_markdown(
        self,
        block_id: str,
        recursive: bool = True,
        max_depth: int | None = 3,
    ) -> str:
        """Export a block subtree to Markdown.

        Parameters
        ----------
        block_id:
            The UUID of the root block.
        recursive:
            If ``True`` (default), recursively fetch children.
        max_depth:
            Maximum recursion depth.  Defaults to 3.

        Returns
        -------
        str
            The rendered Markdown text.

        Raises
        ------
        NotionifyAPIError
            If the Notion API returns an error response (e.g. block not
            found or insufficient permissions).
        NotionifyRetryExhaustedError
            If all retry attempts are exhausted while fetching children.
        """
        t0 = time.monotonic()
        blocks = self._blocks.get_children(block_id)

        if recursive:
            self._fetch_blocks_recursive(blocks, current_depth=0, max_depth=max_depth)

        result = self._renderer.render_blocks(blocks)
        elapsed_ms = (time.monotonic() - t0) * 1000
        self._metrics.timing(
            "notionify.page_export_duration_ms", elapsed_ms,
            tags={"recursive": str(recursive).lower()},
        )
        return result

    # ------------------------------------------------------------------
    # Resource management
    # ------------------------------------------------------------------

    def close(self) -> None:
        """Close the HTTP transport."""
        self._transport.close()

    def __enter__(self) -> NotionifyClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _emit_conversion_metrics(self, conversion: ConversionResult) -> None:
        """Emit blocks_created_total and conversion_warnings_total metrics."""
        block_counts: Counter[str] = Counter()
        for block in conversion.blocks:
            block_counts[block.get("type", "unknown")] += 1
        for block_type, count in block_counts.items():
            self._metrics.increment(
                "notionify.blocks_created_total", count,
                tags={"block_type": block_type},
            )
        warning_counts: Counter[str] = Counter()
        for w in conversion.warnings:
            warning_counts[w.code] += 1
        for code, count in warning_counts.items():
            self._metrics.increment(
                "notionify.conversion_warnings_total", count,
                tags={"code": code},
            )

    def _process_images(self, conversion: ConversionResult) -> int:
        """Process pending images: upload local/data-URI images, replace
        placeholder blocks with the uploaded image blocks.

        Parameters
        ----------
        conversion:
            The conversion result containing blocks and pending images.

        Returns
        -------
        int
            Number of images successfully uploaded.
        """
        if not conversion.images or not self._config.image_upload:
            return 0

        uploaded_count = 0

        _SKIP_SENTINEL = {"_notionify_skip": True}

        for pending in conversion.images:
            try:
                uploaded_count += self._process_single_image(
                    pending, conversion.blocks, conversion.warnings
                )
            except NotionifyImageError as exc:  # noqa: PERF203
                self._handle_image_error(
                    pending, conversion.blocks, conversion.warnings, exc,
                    skip_sentinel=_SKIP_SENTINEL,
                )

        # Remove skip sentinels in a single pass (preserves indices during processing).
        conversion.blocks[:] = [
            b for b in conversion.blocks if b is not _SKIP_SENTINEL
        ]

        return uploaded_count

    def _process_single_image(
        self,
        pending: PendingImage,
        blocks: list[dict[str, Any]],
        warnings: list[ConversionWarning],
    ) -> int:
        """Process a single pending image.  Returns 1 if uploaded, 0 otherwise."""
        if pending.source_type == ImageSourceType.EXTERNAL_URL:
            if self._config.remote_image_upload:
                return self._download_and_upload_remote(pending, blocks, warnings)
            return 0

        if pending.source_type == ImageSourceType.UNKNOWN:
            # Already handled by image_fallback policy in block_builder.
            return 0

        if pending.source_type == ImageSourceType.LOCAL_FILE:
            return self._upload_local_file(pending, blocks, warnings)

        if pending.source_type == ImageSourceType.DATA_URI:
            return self._upload_data_uri(pending, blocks, warnings)

        return 0

    def _upload_local_file(
        self,
        pending: PendingImage,
        blocks: list[dict[str, Any]],
        warnings: list[ConversionWarning],
    ) -> int:
        """Read, validate, upload a local file image and replace the block."""
        base = self._config.image_base_dir
        if base is not None:
            base_path = Path(base).resolve()
            file_path = (base_path / pending.src).resolve()
            if not file_path.is_relative_to(base_path):
                raise NotionifyImageNotFoundError(
                    message=f"Image path escapes base directory: {pending.src}",
                    context={"src": pending.src, "resolved_path": str(file_path)},
                )
        else:
            file_path = Path(pending.src).expanduser().resolve()
        if not file_path.is_file():
            raise NotionifyImageNotFoundError(
                message=f"Image file not found: {pending.src}",
                context={"src": pending.src, "resolved_path": str(file_path)},
            )

        data = file_path.read_bytes()
        mime_type, validated_data = validate_image(
            pending.src,
            pending.source_type,
            data,
            self._config,
        )
        if validated_data is None:
            validated_data = data

        file_name = file_path.name

        upload_id = self._do_upload(file_name, mime_type, validated_data)
        new_block = build_image_block_uploaded(upload_id)

        if 0 <= pending.block_index < len(blocks):
            blocks[pending.block_index] = new_block

        return 1

    def _upload_data_uri(
        self,
        pending: PendingImage,
        blocks: list[dict[str, Any]],
        warnings: list[ConversionWarning],
    ) -> int:
        """Decode, validate, upload a data-URI image and replace the block."""
        mime_type, decoded_data = validate_image(
            pending.src,
            pending.source_type,
            None,  # validate_image decodes data URIs internally
            self._config,
        )
        if decoded_data is None:
            return 0

        # Generate a synthetic file name from the MIME type.
        ext = mime_to_extension(mime_type)
        file_name = f"image{ext}"

        upload_id = self._do_upload(file_name, mime_type, decoded_data)
        new_block = build_image_block_uploaded(upload_id)

        if 0 <= pending.block_index < len(blocks):
            blocks[pending.block_index] = new_block

        return 1

    def _download_and_upload_remote(
        self,
        pending: PendingImage,
        blocks: list[dict[str, Any]],
        warnings: list[ConversionWarning],
    ) -> int:
        """Download a remote image, validate, upload, and replace the block.

        On any failure, fall back to the original external URL and emit
        a warning.
        """
        url = pending.src
        try:
            data, _content_type = download_image(url, self._config)
        except NotionifyImageDownloadError:
            self._metrics.increment(
                "notionify.download_failure_total",
                tags={"reason": "download"},
            )
            # Fallback: keep the original external URL block.
            if 0 <= pending.block_index < len(blocks):
                blocks[pending.block_index] = build_image_block_external(url)
            warnings.append(
                ConversionWarning(
                    code="IMG_REMOTE_DOWNLOAD_FAILED",
                    message=f"Failed to download remote image, using original URL: {url}",
                    context={"url": url},
                )
            )
            return 0

        self._metrics.increment("notionify.download_success_total")

        try:
            mime_type, validated_data = validate_image(
                url, ImageSourceType.LOCAL_FILE, data, self._config,
            )
            if validated_data is None:
                validated_data = data

            ext = mime_to_extension(mime_type)
            file_name = f"remote_image{ext}"

            upload_id = self._do_upload(file_name, mime_type, validated_data)
            new_block = build_image_block_uploaded(upload_id)

            if 0 <= pending.block_index < len(blocks):
                blocks[pending.block_index] = new_block

            return 1
        except Exception:
            # Best-effort fallback: any failure during validate/upload
            # reverts to the original external URL so conversion succeeds.
            self._metrics.increment(
                "notionify.download_failure_total",
                tags={"reason": "upload"},
            )
            if 0 <= pending.block_index < len(blocks):
                blocks[pending.block_index] = build_image_block_external(url)
            warnings.append(
                ConversionWarning(
                    code="IMG_REMOTE_UPLOAD_FAILED",
                    message=f"Failed to upload remote image, using original URL: {url}",
                    context={"url": url},
                )
            )
            return 0

    def _do_upload(self, name: str, mime_type: str, data: bytes) -> str:
        """Choose single or multi-part upload based on data size."""
        if len(data) <= self._config.image_max_size_bytes:
            upload_id = upload_single(self._files, name, mime_type, data)
            self._metrics.increment(
                "notionify.upload_success_total", tags={"mode": "single"},
            )
            return upload_id
        upload_id = upload_multi(self._files, name, mime_type, data)
        self._metrics.increment(
            "notionify.upload_success_total", tags={"mode": "multi"},
        )
        return upload_id

    def _handle_image_error(
        self,
        pending: PendingImage,
        blocks: list[dict[str, Any]],
        warnings: list[ConversionWarning],
        exc: NotionifyImageError,
        skip_sentinel: dict[str, Any] | None = None,
    ) -> None:
        """Apply the configured image_fallback policy on error."""
        self._metrics.increment(
            "notionify.upload_failure_total",
            tags={"reason": type(exc).__name__},
        )
        fallback = self._config.image_fallback

        if fallback == "raise":
            raise exc

        if fallback == "placeholder":
            placeholder_block = {
                "type": "paragraph",
                "paragraph": {
                    "rich_text": [
                        {
                            "type": "text",
                            "text": {"content": f"[image: {pending.src}]"},
                        }
                    ],
                },
            }
            if 0 <= pending.block_index < len(blocks):
                blocks[pending.block_index] = placeholder_block

            warnings.append(
                ConversionWarning(
                    code="IMAGE_UPLOAD_FAILED",
                    message=f"Image upload failed: {exc.message}",
                    context={"src": pending.src, "error": str(exc)},
                )
            )
        else:
            # "skip" -- mark with sentinel (cleaned up after all images processed).
            if skip_sentinel is not None and 0 <= pending.block_index < len(blocks):
                blocks[pending.block_index] = skip_sentinel

            warnings.append(
                ConversionWarning(
                    code="IMAGE_SKIPPED",
                    message=f"Image skipped: {exc.message}",
                    context={"src": pending.src, "error": str(exc)},
                )
            )

    def _fetch_blocks_recursive(
        self,
        blocks: list[dict[str, Any]],
        current_depth: int,
        max_depth: int | None,
    ) -> None:
        """Recursively fetch children for blocks that have them.

        Modifies *blocks* in place, attaching fetched children under the
        block's type-specific data key or a top-level ``"children"`` key.

        Parameters
        ----------
        blocks:
            List of block dicts (already fetched) to enrich with children.
        current_depth:
            The current recursion depth.
        max_depth:
            Maximum depth.  ``None`` means unlimited.
        """
        if max_depth is not None and current_depth >= max_depth:
            return

        for block in blocks:
            if not block.get("has_children", False):
                continue

            block_id = block.get("id")
            if not block_id:
                continue

            children = self._blocks.get_children(block_id)

            # Attach children under the block's type-specific key so the
            # renderer can find them.
            block_type = block.get("type", "")
            if block_type and block_type in block and isinstance(block[block_type], dict):
                block[block_type]["children"] = children
            else:
                block["children"] = children

            # Recurse into the children.
            self._fetch_blocks_recursive(
                children,
                current_depth=current_depth + 1,
                max_depth=max_depth,
            )
