from .funbase import FunBase

__all__ = ["FunBase"]