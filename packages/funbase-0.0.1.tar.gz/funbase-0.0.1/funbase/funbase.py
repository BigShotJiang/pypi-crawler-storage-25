import json
import os
import sys
from typing import Any, Dict, List, Optional

# ↓↓↓ ТОЛЬКО ЭТО МЕСТО МОЖНО МЕНЯТЬ НА СВОЙ ШИФР ↓↓↓
from cryptography.fernet import Fernet  # pip install cryptography


class FunBase:
    """
    Файловая база FunBase.
    Файлы: *.fb (funbase format).
    Шифрование вынесено в отдельный метод — его можно заменить.
    """

    def __init__(self, db_path: str, key: Optional[bytes] = None):
        if not db_path.endswith(".fb"):
            raise ValueError("FunBase file must have extension .fb")

        self.db_path = db_path
        self.key = key or Fernet.generate_key()
        self.cipher = Fernet(self.key)  # одно место с шифром

        self.data: Dict[str, List[Dict]] = {}
        self._load()

    def _encrypt(self, data: bytes) -> bytes:
        """Здесь можно поменять шифрацию на свою."""
        return self.cipher.encrypt(data)

    def _decrypt(self, data: bytes) -> bytes:
        """Здесь можно поменять дешифрацию на свою."""
        return self.cipher.decrypt(data)

    def _load(self):
        if not os.path.exists(self.db_path):
            self.data = {}
            self._save()
            return

        with open(self.db_path, "rb") as f:
            encrypted = f.read()

        decrypted = self._decrypt(encrypted)
        self.data = json.loads(decrypted.decode("utf-8"))

    def _save(self):
        raw = json.dumps(self.data, ensure_ascii=False).encode("utf-8")
        encrypted = self._encrypt(raw)

        with open(self.db_path, "wb") as f:
            f.write(encrypted)

    def create_table(self, table_name: str) -> "FunBase":
        if table_name not in self.data:
            self.data[table_name] = []
            self._save()
        return self

    def insert(self, table_name: str, record: Dict[str, Any]) -> "FunBase":
        table = self.data.setdefault(table_name, [])
        table.append(record)
        self._save()
        return self

    def select_all(self, table_name: str) -> List[Dict]:
        return self.data.get(table_name, [])

    def delete_table(self, table_name: str) -> "FunBase":
        if table_name in self.data:
            del self.data[table_name]
            self._save()
        return self

    def get_key(self) -> bytes:
        """Вернуть ключ; его нужно сохранить отдельно."""
        return self.key