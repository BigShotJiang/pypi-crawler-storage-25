# funbase

FunBase — простая файловая база данных с шифрованием и расширением `.fb`.

## Установка

```bash
pip install funbase
```

## Использование

```python
from funbase import FunBase
from cryptography.fernet import Fernet

# ключ один раз создать и сохранить
key = Fernet.generate_key()
db = FunBase("data.fb", key)

db.create_table("users")
db.insert("users", {"id": 1, "name": "Alice"})
print(db.select_all("users"))
```

Файлы базы данных имеют расширение `.fb` и зашифрованы с помощью `cryptography.fernet`.  
Шифрование можно заменить, правя методы `_encrypt` и `_decrypt` в `FunBase`.