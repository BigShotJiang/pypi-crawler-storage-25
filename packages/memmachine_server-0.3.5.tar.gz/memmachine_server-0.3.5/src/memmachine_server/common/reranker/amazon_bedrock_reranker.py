"""Amazon Bedrock-based reranker implementation."""

import asyncio
import logging
from typing import Any
from uuid import uuid4

from pydantic import BaseModel, Field, InstanceOf

from memmachine_server.common.data_types import ExternalServiceAPIError
from memmachine_server.common.metrics_factory import MetricsFactory, OperationTracker

from .reranker import Reranker

logger = logging.getLogger(__name__)


class AmazonBedrockRerankerParams(BaseModel):
    """Parameters for AmazonBedrockReranker."""

    client: Any = Field(
        ...,
        description=(
            "Boto3 Agents for Amazon Bedrock Runtime client to use for making API calls"
        ),
    )
    region: str = Field(
        ...,
        description="AWS region where the Bedrock model is hosted",
    )
    model_id: str = Field(
        ...,
        description=(
            "ID of the Bedrock model to use for reranking "
            "(e.g. 'amazon.rerank-v1:0', 'cohere.rerank-v3-5:0')"
        ),
    )
    additional_model_request_fields: dict[str, Any] = Field(
        default_factory=dict,
        description=(
            "Keys are request fields for the model "
            "and values are values for those fields"
        ),
    )
    metrics_factory: InstanceOf[MetricsFactory] | None = Field(
        None,
        description="An instance of MetricsFactory for collecting usage metrics",
    )


class AmazonBedrockReranker(Reranker):
    """Reranker that uses Amazon Bedrock models to score candidate relevance."""

    def __init__(self, params: AmazonBedrockRerankerParams) -> None:
        """
        Initialize the Bedrock reranker with client parameters.

        See https://docs.aws.amazon.com/bedrock/latest/APIReference/API_agent-runtime_Rerank.html.

        Args:
            params (AmazonBedrockRerankerParams):
                Configuration for the reranker.

        """
        super().__init__()

        self._client = params.client

        additional_model_request_fields = params.additional_model_request_fields

        self._model_id = params.model_id
        model_arn = (
            f"arn:aws:bedrock:{params.region}::foundation-model/{self._model_id}"
        )

        self._model_configuration = {
            "additionalModelRequestFields": additional_model_request_fields,
            "modelArn": model_arn,
        }

        self._tracker = OperationTracker(
            params.metrics_factory, prefix="reranker_amazon_bedrock"
        )

    async def score(self, query: str, candidates: list[str]) -> list[float]:
        async with self._tracker("score"):
            """Score candidates for a query using the Bedrock reranker."""
            rerank_kwargs = {
                "queries": [
                    {
                        "textQuery": {
                            "text": AmazonBedrockReranker._sanitize_query(query)
                        },
                        "type": "TEXT",
                    },
                ],
                "rerankingConfiguration": {
                    "bedrockRerankingConfiguration": {
                        "modelConfiguration": self._model_configuration,
                        "numberOfResults": len(candidates),
                    },
                    "type": "BEDROCK_RERANKING_MODEL",
                },
                "sources": [
                    {
                        "inlineDocumentSource": {
                            "textDocument": {
                                "text": AmazonBedrockReranker._sanitize_document(
                                    candidate
                                )
                            },
                            "type": "TEXT",
                        },
                        "type": "INLINE",
                    }
                    for candidate in candidates
                ],
            }

            score_call_uuid = uuid4()

            results: list = []
            next_token = ""
            while len(results) < len(candidates) and next_token is not None:
                if len(results) == 0:
                    logger.debug(
                        "[call uuid: %s] "
                        "Scoring %d candidates for query using %s Amazon Bedrock model",
                        score_call_uuid,
                        len(candidates),
                        self._model_id,
                    )
                else:
                    logger.debug(
                        "[call uuid: %s] Retrieving next batch of scoring results",
                        score_call_uuid,
                    )

                try:
                    response = await asyncio.to_thread(
                        self._client.rerank,
                        **rerank_kwargs,
                    )
                except Exception as e:
                    if len(results) == 0:
                        error_message = (
                            f"[call uuid: {score_call_uuid}] "
                            "Failed to score candidates "
                            f"due to {type(e).__name__}"
                        )
                    else:
                        error_message = (
                            f"[call uuid: {score_call_uuid}] "
                            "Failed to retrieve next batch of scoring results "
                            f"due to {type(e).__name__}"
                        )
                    logger.exception(error_message)
                    raise ExternalServiceAPIError(error_message) from e

                next_token = response.get("nextToken")
                rerank_kwargs["nextToken"] = next_token

                batch_results = response["results"]
                logger.debug(
                    "[call uuid: %s] Received %d %s scores in batch",
                    score_call_uuid,
                    len(batch_results),
                    "initial" if len(results) == 0 else "additional",
                )

                results += batch_results

            if len(results) != len(candidates):
                error_message = (
                    f"Expected {len(candidates)} total scores, but got {len(results)}"
                )
                logger.exception(error_message)
                raise ExternalServiceAPIError(error_message)

            scores = [0.0] * len(candidates)
            for result in results:
                scores[result["index"]] = result["relevanceScore"]

            return scores

    @staticmethod
    def _sanitize_query(query: str) -> str:
        # Not documented in AWS documentation, but the query length is limited at 9000 UTF-16 code units.
        query_length_limit = 9000
        return (
            query.encode("utf-16-le")[:query_length_limit].decode(
                "utf-16-le", errors="ignore"
            )
            if query
            else "."
        )

    @staticmethod
    def _sanitize_document(document: str) -> str:
        # Text must be between 1 and 32000 characters, inclusive.
        # https://docs.aws.amazon.com/bedrock/latest/APIReference/API_agent-runtime_RerankTextDocument.html
        document_length_limit = 32000
        return document[:document_length_limit] if document else "."
