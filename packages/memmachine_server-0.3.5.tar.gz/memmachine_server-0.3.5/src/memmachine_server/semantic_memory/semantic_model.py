"""Core data models for semantic memory features and retrieval."""

from collections.abc import Awaitable, Callable, Mapping, MutableMapping, Sequence
from dataclasses import dataclass
from enum import Enum
from typing import Any, Literal, Protocol, runtime_checkable

from pydantic import BaseModel, InstanceOf, field_validator

from memmachine_server.common.embedder import Embedder
from memmachine_server.common.episode_store import EpisodeIdT
from memmachine_server.common.language_model import LanguageModel
from memmachine_server.semantic_memory.util import semantic_prompt_template

SetIdT = str
FeatureIdT = str
CategoryIdT = str
TagIdT = str


class SemanticCommandType(Enum):
    """Semantic memory actions that can be applied to a feature."""

    ADD = "add"
    DELETE = "delete"


class SemanticCommand(BaseModel):
    """Normalized instruction emitted by the LLM to mutate semantic features."""

    command: SemanticCommandType
    feature: str
    tag: str
    value: str

    @field_validator("feature", "tag", "value", mode="after")
    @classmethod
    def strip_null_bytes(cls, v: str) -> str:
        if "\x00" in v:
            return v.replace("\x00", "")
        return v


@dataclass
class RawSemanticPrompt:
    """Pair of prompt templates driving update and consolidation LLM calls."""

    update_prompt: str
    consolidation_prompt: str


class StructuredSemanticPrompt(BaseModel):
    """Pair of prompt templates driving update and consolidation LLM calls."""

    tags: Mapping[str, str]
    description: str | None = None

    @property
    def update_prompt(self) -> str:
        return semantic_prompt_template.build_update_prompt(
            tags=self.tags,
            description=self.description or "",
        )

    @property
    def consolidation_prompt(self) -> str:
        return semantic_prompt_template.build_consolidation_prompt(tags=self.tags)


class SemanticFeature(BaseModel):
    """Semantic memory entry composed of category, tag, feature name, and textual value."""

    class Metadata(BaseModel):
        """Storage metadata for a semantic feature, including id and citations."""

        citations: Sequence[EpisodeIdT] | None = None
        id: FeatureIdT | None = None
        other: Mapping[str, Any] | None = None

    set_id: SetIdT | None = None
    category: str
    tag: str
    feature_name: str
    value: str
    metadata: Metadata = Metadata()

    @staticmethod
    def group_features(
        features: Sequence["SemanticFeature"],
    ) -> Mapping[tuple[str, str, str], Sequence["SemanticFeature"]]:
        grouped_features: MutableMapping[
            tuple[str, str, str], list[SemanticFeature]
        ] = {}

        for f in features:
            key = (f.category, f.tag, f.feature_name)

            if key not in grouped_features:
                grouped_features[key] = []

            grouped_features[key].append(f)

        return grouped_features

    @staticmethod
    def group_features_by_tag(
        features: Sequence["SemanticFeature"],
    ) -> Mapping[str, Sequence["SemanticFeature"]]:
        grouped_features: MutableMapping[str, list[SemanticFeature]] = {}

        for f in features:
            key = f.tag

            if key not in grouped_features:
                grouped_features[key] = []

            grouped_features[key].append(f)

        return grouped_features


@runtime_checkable
class SemanticPrompt(Protocol):
    """Protocol describing prompt templates for semantic extraction."""

    @property
    def update_prompt(self) -> str:
        raise NotImplementedError

    @property
    def consolidation_prompt(self) -> str:
        raise NotImplementedError


class SemanticCategory(BaseModel):
    """Defines a semantic feature category, its allowed tags, and prompt strategy."""

    id: CategoryIdT | None = None

    origin_type: Literal["set_id", "set_type"] | None = None
    origin_id: str | None = None
    inherited: bool | None = None

    name: str
    prompt: InstanceOf[SemanticPrompt]


class Resources(BaseModel):
    """Resource bundle (embedder, language model, semantic categories) for a set_id."""

    embedder: InstanceOf[Embedder]
    language_model: InstanceOf[LanguageModel]
    semantic_categories: Sequence[InstanceOf[SemanticCategory]]


class SetTypeEntry(BaseModel):
    """Persisted entry describing an org/project set type."""

    id: str | None = None
    is_org_level: bool
    tags: Sequence[str]
    name: str | None = None
    description: str | None = None


ResourceRetrieverT = Callable[[SetIdT], Awaitable[Resources]]
