"""Cluster state storage implementations."""
