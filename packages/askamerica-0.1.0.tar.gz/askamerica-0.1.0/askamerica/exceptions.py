class AskAmericaError(Exception):
    pass


class AuthError(AskAmericaError):
    pass


class QuotaExceededError(AskAmericaError):
    def __init__(self, remaining_bytes: int, period: str):
        self.remaining_bytes = remaining_bytes
        self.period = period
        super().__init__(
            f"Monthly quota exceeded for {period}. "
            f"Upgrade at https://askamerica.ai/upgrade"
        )


class QueryError(AskAmericaError):
    pass
