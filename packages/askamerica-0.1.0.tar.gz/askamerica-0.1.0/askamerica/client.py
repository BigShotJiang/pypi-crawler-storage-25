import time
import uuid
import duckdb
from typing import Any, Optional

from .config import get_api_key
from .exceptions import AuthError, QueryError
from .quota import check_quota, report_usage

ICEBERG_CATALOG_URL = "https://api.askamerica.ai/v1/catalog"


def _get_connection(api_key: str) -> duckdb.DuckDBPyConnection:
    con = duckdb.connect()
    con.execute("INSTALL iceberg; LOAD iceberg;")
    con.execute("INSTALL httpfs; LOAD httpfs;")
    con.execute(f"""
        CREATE SECRET askamerica_r2 (
            TYPE S3,
            PROVIDER CREDENTIAL_CHAIN,
            ENDPOINT 'api.askamerica.ai/v1/catalog/credentials',
            EXTRA_HTTP_HEADERS MAP {{
                'X-API-Key': '{api_key}'
            }}
        )
    """)
    return con


def query(
    sql: str,
    api_key: Optional[str] = None,
    return_type: str = "df",
) -> Any:
    key = api_key or get_api_key()
    if not key:
        raise AuthError("No API key configured. Run: askamerica login")

    quota = check_quota(key)

    query_id = str(uuid.uuid4())
    start_ms = time.time() * 1000

    try:
        con = duckdb.connect()
        con.execute("INSTALL httpfs; LOAD httpfs;")

        result = con.execute(sql)

        duration_ms = int(time.time() * 1000 - start_ms)

        if return_type == "df":
            df = result.df()
            row_count = len(df)
            actual_bytes = df.memory_usage(deep=True).sum()
        elif return_type == "arrow":
            df = result.arrow()
            row_count = df.num_rows
            actual_bytes = df.nbytes
        else:
            raise QueryError(f"Unknown return_type: {return_type}. Use 'df' or 'arrow'.")

        report_usage(
            query_id=query_id,
            table=_extract_table(sql),
            planned_bytes=actual_bytes,
            actual_bytes=actual_bytes,
            row_count=row_count,
            duration_ms=duration_ms,
            query_text=sql,
            api_key=key,
        )

        _print_quota_reminder(quota, actual_bytes)
        return df

    except duckdb.Error as e:
        raise QueryError(str(e)) from e


def _extract_table(sql: str) -> str:
    import re
    match = re.search(r'\bFROM\s+([\w.]+)', sql, re.IGNORECASE)
    return match.group(1) if match else "unknown"


def _print_quota_reminder(quota: dict, used_bytes: int) -> None:
    remaining = quota["remaining_bytes"] - used_bytes
    limit = quota["limit_bytes"]
    pct_used = ((limit - remaining) / limit) * 100
    remaining_gb = remaining / (1024 ** 3)
    if pct_used >= 80:
        print(
            f"[askamerica] {pct_used:.0f}% of monthly quota used. "
            f"{remaining_gb:.2f} GB remaining. "
            f"Upgrade at https://askamerica.ai/upgrade"
        )
