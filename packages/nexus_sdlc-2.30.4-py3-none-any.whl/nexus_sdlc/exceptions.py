"""
nexus_sdlc exception hierarchy.

SOLE OWNER: api-routes-builder.
All other modules (python-developer-agent, cli-tool-builder, queue-worker-builder,
library-sdk-builder) import from this file — they do NOT define exception classes.

Cross-spec import map:
  SubprocessLauncher:   SubprocessError, SubprocessNotFound, RecursionError
  ConversationRegistry: SessionError, SessionCorruptError
  NexusConfigLoader:    ConfigError, EnvParseError
  NexusMCPServer:       MCPError, MCPAuthError, FilesystemBoundaryError, MCPDepthError
  ValkeyConsumer:       ValkeyError, ValkeyDegradedError
  cli/guards.py:        RecursionError as NexusRecursionError

INV-12: this file MUST NOT import from nexus_sdlc.* or import nexus_sdlc.
"""


# ---------------------------------------------------------------------------
# Base
# ---------------------------------------------------------------------------

class NexusError(Exception):
    """Base class for all nexus-sdlc exceptions."""


# ---------------------------------------------------------------------------
# MCP layer
# ---------------------------------------------------------------------------

class MCPError(NexusError):
    """Base for MCP server errors."""


class MCPAuthError(MCPError):
    """NEXUS_MCP_SECRET validation failed. Message must not include the provided secret value."""


class MCPAlreadyRunningError(MCPError):
    """A running MCP server instance was detected. Include PID: 'nexus: MCP server already running (pid={n})'."""


class MCPToolError(MCPError):
    """Tool handler raised an error."""


class FilesystemBoundaryError(MCPError):
    """Resolved path is outside registered project boundaries. Include resolved path in message."""


class MCPDepthError(MCPError):
    """NEXUS_MCP_DEPTH exceeded — circular MCP invocation detected."""


# ---------------------------------------------------------------------------
# Bridge layer
# ---------------------------------------------------------------------------

class BridgeError(NexusError):
    """Base for director-bridge.sh errors."""


class BridgeCommandError(BridgeError):
    """Bridge exited non-zero. Include exit code and stderr."""


class BridgeTimeoutError(BridgeError):
    """Bridge subprocess exceeded timeout."""


class BridgeNotFoundError(BridgeError):
    """director-bridge.sh not found at any resolution path."""


# ---------------------------------------------------------------------------
# Valkey layer
# ---------------------------------------------------------------------------

class ValkeyError(NexusError):
    """Base for Valkey consumer errors."""


class ValkeyConnectionError(ValkeyError):
    """Could not connect to Valkey."""


class ValkeyMaxRetriesExceeded(ValkeyError):
    """Backoff exhausted after max retries."""


class ValkeyDegradedError(ValkeyError):
    """Valkey max retries (5) exhausted — consumer in degraded state. Perception events will not be delivered until connectivity is restored."""


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

class RegistryError(NexusError):
    """ConversationRegistry I/O failure."""


# ---------------------------------------------------------------------------
# Setup
# ---------------------------------------------------------------------------

class SetupError(NexusError):
    """nexus setup command failure."""


class SetupSettingsNotFoundError(SetupError):
    """~/.claude/settings.json not found."""


class SetupSecretWriteError(SetupError):
    """Could not write ~/.nexus-env."""


# ---------------------------------------------------------------------------
# Config / env
# ---------------------------------------------------------------------------

class ConfigError(NexusError):
    """Config loading, validation, or parsing failure."""


class EnvParseError(ConfigError):
    """~/.nexus-env parse failure — malformed line or forbidden shell construct."""


# ---------------------------------------------------------------------------
# Subprocess
# ---------------------------------------------------------------------------

class SubprocessError(NexusError):
    """Claude subprocess lifecycle failure."""


class SubprocessNotFound(SubprocessError):
    """claude binary not found or not authenticated at startup."""


# ---------------------------------------------------------------------------
# Recursion guard
# ---------------------------------------------------------------------------

class RecursionError(NexusError):
    """NEXUS_CLI=1 detected — recursive nexus invocation attempted.

    Import with alias to avoid shadowing Python built-in:
        from nexus_sdlc.exceptions import RecursionError as NexusRecursionError
    """


# ---------------------------------------------------------------------------
# Session
# ---------------------------------------------------------------------------

class SessionError(NexusError):
    """ConversationRegistry session failure."""


class SessionCorruptError(SessionError):
    """JSONL session file corrupt — skip this line and load previous rotation file."""
