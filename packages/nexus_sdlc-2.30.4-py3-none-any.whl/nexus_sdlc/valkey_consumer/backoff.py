"""
Exponential backoff state machine for Valkey reconnection.

OWNER: queue-worker-builder (nexus-cli-tui-001)
"""

import asyncio

from nexus_sdlc.exceptions import ValkeyMaxRetriesExceeded


class ExponentialBackoff:
    """Exponential backoff state machine for Valkey reconnection.

    Schedule: 1s → 2s → 4s → 8s → 16s (max 5 attempts, base_seconds=1.0).
    After max_retries consecutive failures, raises ValkeyMaxRetriesExceeded so
    the caller can enter degraded state rather than continuing to retry.

    Parameters
    ----------
    base_seconds : float
        Initial delay in seconds. Subsequent delays double each attempt.
    max_retries : int
        Maximum number of retry attempts before raising ValkeyMaxRetriesExceeded.
    """

    def __init__(self, *, base_seconds: float = 1.0, max_retries: int = 5) -> None:
        self._base = base_seconds
        self._max_retries = max_retries
        self._retry_count = 0

    async def wait(self) -> None:
        """Sleep for the current backoff duration, then increment retry counter.

        Raises
        ------
        ValkeyMaxRetriesExceeded
            When retry_count has already reached max_retries before this call.
            That is, raises when this would be the (max_retries+1)th attempt.
        """
        if self._retry_count >= self._max_retries:
            raise ValkeyMaxRetriesExceeded(
                f"Valkey backoff exhausted after {self._max_retries} retries"
            )
        delay = self._base * (2 ** self._retry_count)
        self._retry_count += 1
        await asyncio.sleep(delay)

    def reset(self) -> None:
        """Reset retry counter to 0. Call on successful connection."""
        self._retry_count = 0

    @property
    def exhausted(self) -> bool:
        """True when retry_count >= max_retries."""
        return self._retry_count >= self._max_retries

    @property
    def retry_count(self) -> int:
        """Current retry count (0 = no failures yet)."""
        return self._retry_count
