"""
Data models for the Valkey stream consumer.

OWNER: queue-worker-builder (nexus-cli-tui-001)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class StreamEvent:
    """A single decoded event from the nexus:events Valkey stream.

    Attributes
    ----------
    stream_id : str
        Valkey stream message ID (e.g. "1713500000000-0").
    event_type : str
        Value of the 'type' field in the message payload.
    payload : dict
        Full decoded message data (bytes keys/values decoded to str).
    received_at : datetime
        UTC wall-clock time the event was decoded by the consumer loop.
    """

    stream_id: str
    event_type: str
    payload: dict
    received_at: datetime = field(default_factory=datetime.utcnow)
