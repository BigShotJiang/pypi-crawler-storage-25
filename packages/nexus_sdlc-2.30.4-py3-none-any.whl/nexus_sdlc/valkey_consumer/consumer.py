"""
Asyncio-based Valkey Stream consumer for Nexus SDLC events.

OWNER: queue-worker-builder (nexus-cli-tui-001)

Reads from stream "nexus:events" using XREAD BLOCK (xreadgroup).
Consumer group: "nexus-tui-perception" (NOT "nexus-perception" — that belongs
to the perception daemon).

Anti-requirements enforced:
  AR-6: NEVER uses SUBSCRIBE or PSUBSCRIBE — XREAD BLOCK only.
  AR-7: Valkey reads run in an asyncio background task, not on the event loop thread directly.
  AR-8: Reconnects use ExponentialBackoff (1→2→4→8→16s, max 5 retries, then degraded).
"""

from __future__ import annotations

import asyncio
import logging
import os
import socket
from collections import deque
from datetime import datetime
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import TYPE_CHECKING

import redis.asyncio as aioredis
import redis.exceptions as redis_exc

from nexus_sdlc.exceptions import ValkeyConnectionError, ValkeyDegradedError, ValkeyMaxRetriesExceeded
from nexus_sdlc.valkey_consumer.backoff import ExponentialBackoff
from nexus_sdlc.valkey_consumer.models import StreamEvent

if TYPE_CHECKING:
    pass


# ---------------------------------------------------------------------------
# Module-level logger (RotatingFileHandler, 10 MB / 3 backups, chmod 600)
# ---------------------------------------------------------------------------

def _build_logger() -> logging.Logger:
    log_dir = Path.home() / ".nexus" / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / "valkey-consumer.log"

    logger = logging.getLogger("nexus.valkey_consumer")
    if not logger.handlers:
        handler = RotatingFileHandler(
            log_path,
            maxBytes=10 * 1024 * 1024,  # 10 MB
            backupCount=3,
            encoding="utf-8",
        )
        # chmod 600 after creation
        try:
            log_path.chmod(0o600)
        except OSError:
            pass
        handler.setFormatter(
            logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
        )
        logger.addHandler(handler)
        logger.setLevel(logging.DEBUG)
    return logger


_logger = _build_logger()


# ---------------------------------------------------------------------------
# ValkeyConsumer
# ---------------------------------------------------------------------------

class ValkeyConsumer:
    """Asyncio-based Valkey Stream consumer for Nexus SDLC events.

    Reads from stream "nexus:events" using XREAD BLOCK 5000ms via
    xreadgroup.  Consumer group is always "nexus-tui-perception".

    Runs as asyncio background task inside the MCP server process.
    On connection failure: applies ExponentialBackoff (1→2→4→8→16s, max 5).
    After 5 failures: enters degraded state and stops reconnecting.
    Degraded state is surfaced via is_degraded property; ValkeyDegradedError
    is raised if check_degraded() is called explicitly (used by health_check).

    Parameters
    ----------
    host : str
        Valkey server hostname.
    port : int
        Valkey server port.
    stream : str
        Stream name to consume from (default: "nexus:events").
    group : str
        Consumer group name (default: "nexus-tui-perception").
    consumer_name : str | None
        Consumer identifier. Derived as "nexus-tui-{hostname}-{pid}" when None.
    """

    STREAM_NAME: str = "nexus:events"
    CONSUMER_GROUP: str = "nexus-tui-perception"
    BLOCK_MS: int = 5000
    ACK_BATCH_SIZE: int = 100
    # Maximum buffered events returned via get_events (prevents unbounded growth)
    _BUFFER_MAXLEN: int = 1000

    def __init__(
        self,
        host: str,
        port: int,
        *,
        stream: str = "nexus:events",
        group: str = "nexus-tui-perception",
        consumer_name: str | None = None,
    ) -> None:
        self._host = host
        self._port = port
        self._stream = stream
        self._group = group
        self._consumer_name: str = consumer_name or (
            f"nexus-tui-{socket.gethostname()}-{os.getpid()}"
        )

        self._client: aioredis.Redis | None = None
        self._task: asyncio.Task | None = None
        self._stop_event = asyncio.Event()

        # Degraded state
        self._degraded: bool = False

        # Connectivity flag — True only while the consume loop is running normally
        self._connected: bool = False

        # Event buffer (bounded deque)
        self._buffer: deque[dict] = deque(maxlen=self._BUFFER_MAXLEN)

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Create consumer group (if absent) and start the background consume task.

        The background task is created via asyncio.create_task so it runs
        concurrently without blocking the caller.

        Raises
        ------
        ValkeyConnectionError
            If the initial connection attempt fails before the task is scheduled.
        """
        self._stop_event.clear()
        self._task = asyncio.create_task(self._run_with_backoff(), name="valkey-consumer")
        _logger.info("ValkeyConsumer started (stream=%s group=%s consumer=%s)",
                     self._stream, self._group, self._consumer_name)

    async def stop(self) -> None:
        """Signal the consume task to stop and await its completion (up to 3s)."""
        self._stop_event.set()
        if self._task and not self._task.done():
            try:
                await asyncio.wait_for(asyncio.shield(self._task), timeout=3.0)
            except (asyncio.TimeoutError, asyncio.CancelledError):
                self._task.cancel()
                try:
                    await self._task
                except (asyncio.CancelledError, Exception):
                    pass
        self._connected = False
        _logger.info("ValkeyConsumer stopped.")

    async def get_events(self, count: int = 10) -> list[dict]:
        """Return up to `count` buffered events (consuming them from the buffer).

        Parameters
        ----------
        count : int
            Maximum number of events to return.

        Returns
        -------
        list[dict]
            Each dict is the decoded payload from a StreamEvent, plus
            "__stream_id__" and "__event_type__" metadata keys.
        """
        result: list[dict] = []
        for _ in range(min(count, len(self._buffer))):
            if not self._buffer:
                break
            result.append(self._buffer.popleft())
        return result

    @property
    def is_degraded(self) -> bool:
        """True after max retries exhausted — consumer no longer attempts reconnection."""
        return self._degraded

    @property
    def is_connected(self) -> bool:
        """True when the client is connected and the consume loop is running."""
        return self._connected

    @property
    def consumer_name(self) -> str:
        """Consumer name string: "nexus-tui-{hostname}-{pid}"."""
        return self._consumer_name

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    async def _run_with_backoff(self) -> None:
        """Reconnection loop with ExponentialBackoff.

        On each ValkeyConnectionError the backoff machine delays before
        retrying.  After max_retries the consumer enters degraded state
        and exits the loop without raising (unhandled task exceptions are
        logged via asyncio's exception handler instead).
        """
        backoff = ExponentialBackoff(base_seconds=1.0, max_retries=5)

        while not self._stop_event.is_set():
            try:
                await self._connect_and_consume()
                # Successful completion (stop event set) — exit cleanly
                break
            except asyncio.CancelledError:
                _logger.info("ValkeyConsumer task cancelled.")
                raise
            except ValkeyConnectionError as exc:
                self._connected = False
                if backoff.exhausted:
                    # This branch handles exhaustion detected *before* wait()
                    self._degraded = True
                    _logger.warning(
                        "ValkeyConsumer degraded: max retries exhausted. "
                        "Perception events will not be delivered until connectivity is restored."
                    )
                    return
                _logger.warning(
                    "ValkeyConsumer connection error (attempt %d/%d): %s. "
                    "Retrying in %.1fs …",
                    backoff.retry_count + 1,
                    5,
                    exc,
                    1.0 * (2 ** backoff.retry_count),
                )
                try:
                    await backoff.wait()
                except ValkeyMaxRetriesExceeded:
                    self._degraded = True
                    _logger.warning(
                        "ValkeyConsumer degraded: max retries exceeded. "
                        "Perception events will not be delivered until connectivity is restored."
                    )
                    return
            except Exception as exc:
                _logger.error("ValkeyConsumer unexpected error: %s", exc, exc_info=True)
                self._connected = False
                return

    async def _connect_and_consume(self) -> None:
        """Open a Redis connection, ensure consumer group, run consume loop."""
        self._client = aioredis.Redis(
            host=self._host,
            port=self._port,
            decode_responses=False,  # handle bytes manually for correctness
        )
        try:
            # Ping to verify connectivity before group creation
            await self._client.ping()
        except (redis_exc.ConnectionError, redis_exc.TimeoutError) as exc:
            raise ValkeyConnectionError(str(exc)) from exc

        # Ensure consumer group exists — ignore BUSYGROUP if already present
        try:
            await self._client.xgroup_create(
                self._stream, self._group, id="$", mkstream=True
            )
            _logger.info("Consumer group '%s' created on stream '%s'.", self._group, self._stream)
        except redis_exc.ResponseError as exc:
            if "BUSYGROUP" in str(exc):
                _logger.debug("Consumer group '%s' already exists — skipping create.", self._group)
            else:
                raise ValkeyConnectionError(str(exc)) from exc

        await self._consume_loop()

    async def _consume_loop(self) -> None:
        """Main XREADGROUP BLOCK loop.

        AR-6: Uses xreadgroup (XREAD BLOCK) only — no SUBSCRIBE/PSUBSCRIBE.
        AR-7: Runs entirely inside this asyncio task.
        """
        assert self._client is not None  # guaranteed by _connect_and_consume

        self._connected = True
        pending_ids: list[bytes] = []

        try:
            while not self._stop_event.is_set():
                try:
                    # XREADGROUP with BLOCK — yields control to event loop during wait
                    results = await self._client.xreadgroup(
                        groupname=self._group,
                        consumername=self._consumer_name,
                        streams={self._stream: ">"},
                        count=10,
                        block=self.BLOCK_MS,
                    )
                except (redis_exc.ConnectionError, redis_exc.TimeoutError) as exc:
                    self._connected = False
                    raise ValkeyConnectionError(str(exc)) from exc

                if not results:
                    # BLOCK timeout — no new messages; loop again
                    continue

                for _stream_name, entries in results:
                    for entry_id, fields in entries:
                        # Decode bytes → str
                        decoded: dict[str, str] = {
                            (k.decode() if isinstance(k, bytes) else k): (
                                v.decode() if isinstance(v, bytes) else v
                            )
                            for k, v in fields.items()
                        }
                        event = StreamEvent(
                            stream_id=(
                                entry_id.decode() if isinstance(entry_id, bytes) else entry_id
                            ),
                            event_type=decoded.get("type", ""),
                            payload=decoded,
                            received_at=datetime.utcnow(),
                        )
                        # Log payload at DEBUG only (AR per spec — never at INFO+)
                        _logger.debug("Event received: stream_id=%s type=%s",
                                      event.stream_id, event.event_type)

                        # Buffer for get_events() callers
                        enriched = dict(decoded)
                        enriched["__stream_id__"] = event.stream_id
                        enriched["__event_type__"] = event.event_type
                        self._buffer.append(enriched)

                        pending_ids.append(
                            entry_id if isinstance(entry_id, bytes) else entry_id.encode()
                        )

                        # Batch ACK
                        if len(pending_ids) >= self.ACK_BATCH_SIZE:
                            await self._client.xack(self._stream, self._group, *pending_ids)
                            pending_ids.clear()

        except asyncio.CancelledError:
            # Flush remaining pending ACKs before exiting
            if pending_ids and self._client:
                try:
                    await self._client.xack(self._stream, self._group, *pending_ids)
                except Exception:
                    pass
            self._connected = False
            raise
        finally:
            self._connected = False
            if self._client:
                try:
                    await self._client.aclose()
                except Exception:
                    pass
                self._client = None
