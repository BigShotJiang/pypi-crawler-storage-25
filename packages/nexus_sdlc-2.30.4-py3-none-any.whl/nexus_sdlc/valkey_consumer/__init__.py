"""
nexus_sdlc.valkey_consumer — Asyncio Valkey Stream consumer.

Public surface:
  ValkeyConsumer   — background XREAD BLOCK consumer task
  ExponentialBackoff — reconnection backoff state machine
  StreamEvent      — decoded stream event dataclass
"""

from nexus_sdlc.valkey_consumer.backoff import ExponentialBackoff
from nexus_sdlc.valkey_consumer.consumer import ValkeyConsumer
from nexus_sdlc.valkey_consumer.models import StreamEvent

__all__ = ["ValkeyConsumer", "ExponentialBackoff", "StreamEvent"]
