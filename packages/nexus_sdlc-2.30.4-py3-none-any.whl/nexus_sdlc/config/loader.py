"""
nexus_sdlc.config.loader — 4-tier configuration resolution.

Resolution priority (highest to lowest):
  1. Environment variable  (e.g. NEXUS_VALKEY_HOST)
  2. Project  .nexus/config.yaml
  3. Workspace .nexus/config.yaml  (followed via workspace.registry_path)
  4. Hardcoded default

INV-07: MUST NOT use eval, exec, subprocess, or os.system.
INV-08: MUST check _FORBIDDEN_CONSTRUCTS in _parse_nexus_env.
"""
from __future__ import annotations

import logging
import os
import re
from pathlib import Path
from typing import Any

import yaml

from nexus_sdlc.exceptions import ConfigError, EnvParseError

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Env file parser — regex + forbidden-construct guard
# ---------------------------------------------------------------------------

_NEXUS_ENV_LINE_RE = re.compile(
    r'^export\s+([A-Z_][A-Z0-9_]*)\s*=\s*(?:"(.*)"|\'(.*)\'|(.*?))\s*$'
)

_FORBIDDEN_CONSTRUCTS = ("|", "$(", "`")

# ---------------------------------------------------------------------------
# Hardcoded defaults
# ---------------------------------------------------------------------------

_DEFAULTS: dict[str, Any] = {
    "valkey.host": "127.0.0.1",
    "valkey.port": 6379,
    "mcp.port": 9337,
    "mcp.pid_file": "~/.nexus/run/nexus-mcp.pid",
    "mcp.max_recursion_depth": 3,
    "sessions.dir": "~/.nexus/sessions",
    "sessions.retention_days": 30,
    "sessions.rotation_mb": 10,
    "subprocess.stream_buffer_mb": 10,
    "subprocess.sigterm_wait_seconds": 2.0,
    "cli.log_level": "info",
    "cli.enabled": True,
}

# ENV VAR mapping: dotted key -> env var name
_ENV_VAR_MAP: dict[str, str] = {
    "valkey.host": "NEXUS_VALKEY_HOST",
    "valkey.port": "NEXUS_VALKEY_PORT",
    "mcp.port": "NEXUS_MCP_PORT",
    "mcp.max_recursion_depth": "NEXUS_MCP_DEPTH",
    "sessions.rotation_mb": "NEXUS_SESSION_ROTATION_MB",
    "subprocess.stream_buffer_mb": "NEXUS_STREAM_BUFFER_MB",
}


def _nested_get(data: dict[str, Any], dotted_key: str) -> Any:
    """Traverse a nested dict using a dotted key like 'mcp.port'."""
    keys = dotted_key.split(".")
    node: Any = data
    for k in keys:
        if not isinstance(node, dict):
            return None
        node = node.get(k)
    return node


class NexusConfigLoader:
    """
    4-tier configuration resolver for nexus-sdlc.

    Instantiate with the project directory; call get(key) for any config value.
    The loader is stateless — no caching — so it always reflects the current state
    of the environment and YAML files.
    """

    def __init__(self, project_dir: str | Path | None = None) -> None:
        self._project_dir = Path(project_dir) if project_dir else None
        self._project_config: dict[str, Any] | None = None
        self._workspace_config: dict[str, Any] | None = None
        self._loaded = False

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get(self, key: str, default: Any = None) -> Any:
        """
        Resolve a config key through all 4 tiers.

        Parameters
        ----------
        key:
            Dotted config key, e.g. "mcp.port" or "sessions.rotation_mb".
        default:
            Returned only if the key is not found in any tier.  When the key
            has a hardcoded default, that is returned before this fallback.
        """
        self._ensure_loaded()

        # Tier 1 — environment variable
        env_var = _ENV_VAR_MAP.get(key)
        if env_var and (val := os.environ.get(env_var)) is not None:
            return self._coerce(key, val)

        # Tier 2 — project .nexus/config.yaml
        if self._project_config is not None:
            val = _nested_get(self._project_config, key)
            if val is not None:
                return val

        # Tier 3 — workspace .nexus/config.yaml
        if self._workspace_config is not None:
            val = _nested_get(self._workspace_config, key)
            if val is not None:
                return val

        # Tier 4 — hardcoded default
        if key in _DEFAULTS:
            return _DEFAULTS[key]

        return default

    def load_nexus_env(self, path: Path | None = None) -> dict[str, str]:
        """
        Parse ~/.nexus-env (or the given path) and return {KEY: value} pairs.

        The parsed values are NOT automatically applied to os.environ — callers
        decide what to do with them.  Raises EnvParseError on forbidden
        shell constructs.  Non-matching lines (comments, blanks) are silently
        skipped.
        """
        env_path = path or Path("~/.nexus-env").expanduser()
        if not env_path.exists():
            logger.debug("~/.nexus-env not found at %s — skipping", env_path)
            return {}
        return self._parse_nexus_env(env_path)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _ensure_loaded(self) -> None:
        if self._loaded:
            return
        self._loaded = True

        if self._project_dir is not None:
            self._project_config = self._load_yaml(
                self._project_dir / ".nexus" / "config.yaml"
            )
            # Tier 3: follow workspace.registry_path
            if self._project_config is not None:
                workspace_path = _nested_get(
                    self._project_config, "workspace.registry_path"
                )
                if workspace_path:
                    workspace_config_path = (
                        Path(workspace_path).expanduser() / ".nexus" / "config.yaml"
                    )
                    self._workspace_config = self._load_yaml(workspace_config_path)

    def _load_yaml(self, path: Path) -> dict[str, Any] | None:
        """Load a YAML file, returning None if missing or unparseable."""
        if not path.exists():
            logger.debug("Config file not found: %s", path)
            return None
        try:
            with path.open("r", encoding="utf-8") as fh:
                data = yaml.safe_load(fh)
            if not isinstance(data, dict):
                logger.warning("Config file %s did not parse to a dict — ignoring", path)
                return None
            return data
        except yaml.YAMLError as exc:
            raise ConfigError(f"Failed to parse YAML at {path}: {exc}") from exc
        except OSError as exc:
            raise ConfigError(f"Could not read config file {path}: {exc}") from exc

    def _parse_nexus_env(self, path: Path) -> dict[str, str]:
        """
        Strict ~/.nexus-env parser.

        - Uses _NEXUS_ENV_LINE_RE for line matching.
        - Rejects values containing _FORBIDDEN_CONSTRUCTS (|, $(, backtick).
        - Skips blank lines and comment lines (#…).
        - Non-matching non-comment lines are silently skipped (not an error).
        - MUST NOT use eval, exec, subprocess, or os.system.
        """
        result: dict[str, str] = {}
        try:
            text = path.read_text(encoding="utf-8")
        except OSError as exc:
            raise EnvParseError(f"Cannot read {path}: {exc}") from exc

        for lineno, line in enumerate(text.splitlines(), 1):
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue

            m = _NEXUS_ENV_LINE_RE.match(stripped)
            if not m:
                # Non-matching lines are silently skipped per spec
                logger.debug(
                    "~/.nexus-env line %d: no match — skipped: %r", lineno, stripped
                )
                continue

            # Groups: (1) KEY, (2) double-quoted value, (3) single-quoted value, (4) bare value
            value = m.group(2) if m.group(2) is not None else (
                m.group(3) if m.group(3) is not None else (m.group(4) or "")
            )

            for forbidden in _FORBIDDEN_CONSTRUCTS:
                if forbidden in value:
                    raise EnvParseError(
                        f"Forbidden shell construct {forbidden!r} in {path} line {lineno}"
                    )

            result[m.group(1)] = value

        return result

    @staticmethod
    def _coerce(key: str, raw: str) -> Any:
        """Coerce an env var string to the type implied by the hardcoded default."""
        default = _DEFAULTS.get(key)
        if isinstance(default, bool):
            return raw.lower() in ("1", "true", "yes")
        if isinstance(default, int):
            try:
                return int(raw)
            except ValueError:
                logger.warning(
                    "Config env var for %r has non-integer value %r — using default %r",
                    key,
                    raw,
                    default,
                )
                return default
        if isinstance(default, float):
            try:
                return float(raw)
            except ValueError:
                return default
        return raw
