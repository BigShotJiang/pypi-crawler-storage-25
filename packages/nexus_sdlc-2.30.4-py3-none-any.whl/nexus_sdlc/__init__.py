"""nexus_sdlc — AI SDLC Orchestration Framework CLI and MCP server."""

__version__ = "2.30.1"
__all__ = ["__version__"]
