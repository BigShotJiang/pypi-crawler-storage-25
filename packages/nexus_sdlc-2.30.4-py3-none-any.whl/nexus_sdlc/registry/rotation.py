"""
nexus_sdlc.registry.rotation — RotationConfig and 3-file rotation logic.

Rotation files:
    sessions.jsonl          <- active write target
    sessions.1.jsonl        <- one generation old
    sessions.2.jsonl        <- two generations old (oldest, dropped on next rotate)

On rotate:
    1. Unlink sessions.2.jsonl if it exists  (drop oldest)
    2. Rename sessions.1.jsonl -> sessions.2.jsonl
    3. Rename sessions.jsonl   -> sessions.1.jsonl
    (sessions.jsonl is now absent — caller creates it fresh)
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass
class RotationConfig:
    """
    Configuration for JSONL session file rotation.

    Attributes
    ----------
    max_bytes:
        Rotate when the active file reaches this size. Default: 10 MiB.
    max_files:
        Maximum number of rotation files to retain (including the active
        file). Default: 3 (sessions.jsonl, sessions.1.jsonl,
        sessions.2.jsonl).
    """

    max_bytes: int = 10 * 1024 * 1024  # 10 MiB
    max_files: int = 3

    def should_rotate(self, path: Path) -> bool:
        """
        Return True if *path* exists and its size is >= max_bytes.

        Parameters
        ----------
        path:
            Path to the active JSONL file (typically ``sessions.jsonl``).
        """
        try:
            return path.exists() and path.stat().st_size >= self.max_bytes
        except OSError:
            return False

    def rotate(self, path: Path) -> None:
        """
        Perform a 3-file ring rotation rooted at *path*.

        *path* is expected to be ``<dir>/sessions.jsonl``.  After rotation
        *path* no longer exists — the caller should open it fresh.

        The rotation is performed in reverse order to avoid overwriting:
            1. Drop sessions.2.jsonl  (if present)
            2. sessions.1.jsonl -> sessions.2.jsonl
            3. sessions.jsonl   -> sessions.1.jsonl
        """
        base_dir = path.parent
        stem = path.stem  # "sessions"
        suffix = path.suffix  # ".jsonl"

        # Build generation paths: [sessions.1.jsonl, sessions.2.jsonl]
        rotations = [
            base_dir / f"{stem}.{i}{suffix}"
            for i in range(1, self.max_files)
        ]

        # Step 1: drop the oldest
        oldest = rotations[-1]
        if oldest.exists():
            oldest.unlink()

        # Step 2: shift each generation up (in reverse so no overwrites)
        for i in range(len(rotations) - 1, 0, -1):
            src = rotations[i - 1]  # e.g. sessions.1.jsonl
            dst = rotations[i]      # e.g. sessions.2.jsonl
            if src.exists():
                src.rename(dst)

        # Step 3: rename active file to sessions.1.jsonl
        first_rotation = rotations[0]
        if path.exists():
            path.rename(first_rotation)
