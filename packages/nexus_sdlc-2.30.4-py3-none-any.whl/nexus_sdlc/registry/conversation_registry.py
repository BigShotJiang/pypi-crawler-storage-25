"""
nexus_sdlc.registry.conversation_registry — ConversationRegistry.

CRITICAL INVARIANTS:
  AR-5: MUST NOT be a module-level singleton — instantiated per-app in __init__.
  AR-6: MUST flush on both atexit AND signal.SIGTERM — atexit alone does NOT
        run on raw SIGTERM delivery.
  CRAWL Gap 4: Corrupt JSONL lines are skipped with a warning (not a crash).
  R4: If sessions.jsonl is unreadable, fall back to sessions.1.jsonl.
"""
from __future__ import annotations

import atexit
import json
import logging
import signal
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING

from nexus_sdlc.exceptions import RegistryError, SessionCorruptError
from nexus_sdlc.registry.models import SessionRecord
from nexus_sdlc.registry.rotation import RotationConfig

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)

_SESSIONS_FILE = "sessions.jsonl"


class ConversationRegistry:
    """
    UUID-keyed session store with append-only JSONL persistence and
    3-file rotation.

    MUST NOT be instantiated at module level (AR-5).  Create one instance
    per application (e.g. in ``cli/main.py`` callback).

    Flush contract (AR-6)
    ---------------------
    ``__init__`` registers BOTH:
    - ``atexit.register(self._flush)`` — fires on clean Python exit.
    - ``signal.signal(signal.SIGTERM, self._sigterm_handler)`` — fires on
      ``kill <pid>`` / systemd stop / Kubernetes eviction.

    atexit alone does NOT run on raw SIGTERM.  Both are required.

    signal.signal() only works on the main thread; a ValueError is caught and
    logged if called from a non-main thread (test environments).

    Parameters
    ----------
    sessions_dir:
        Override the default ``~/.nexus/sessions`` directory.
    rotation_config:
        Override the default RotationConfig (10 MiB, 3 files).
    register_signal_handler:
        Set to False to suppress SIGTERM registration (useful in threads /
        test fixtures where signal.signal would raise ValueError).
    """

    SESSIONS_DIR: Path = Path("~/.nexus/sessions").expanduser()

    def __init__(
        self,
        *,
        sessions_dir: Path | None = None,
        rotation_config: RotationConfig | None = None,
        register_signal_handler: bool = True,
    ) -> None:
        self._dir: Path = (sessions_dir or self.SESSIONS_DIR).expanduser()
        self._rotation: RotationConfig = rotation_config or RotationConfig()
        self._sessions: dict[str, SessionRecord] = {}
        self._dirty: bool = False
        self._flushed: bool = False  # idempotency guard for _flush

        # Ensure the sessions directory exists
        try:
            self._dir.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise RegistryError(
                f"Cannot create sessions directory {self._dir}: {exc}"
            ) from exc

        # AR-6: register atexit flush
        atexit.register(self._flush)

        # AR-6: register SIGTERM handler
        if register_signal_handler:
            try:
                signal.signal(signal.SIGTERM, self._sigterm_handler)
            except ValueError:
                logger.warning(
                    "ConversationRegistry: could not register SIGTERM handler "
                    "(not main thread) — atexit flush still active"
                )

    # ------------------------------------------------------------------
    # Signal / atexit handlers
    # ------------------------------------------------------------------

    def _sigterm_handler(self, signum: int, frame: object) -> None:
        """Handle SIGTERM by flushing and exiting cleanly."""
        logger.debug("ConversationRegistry: SIGTERM received — flushing")
        self._flush()
        sys.exit(0)

    def _flush(self) -> None:
        """
        Flush any dirty in-memory sessions to disk.

        Idempotent: safe to call multiple times (atexit + SIGTERM may both fire
        in the same process lifetime).
        """
        if self._flushed:
            return
        self._flushed = True

        if not self._dirty:
            logger.debug("ConversationRegistry._flush: nothing to flush")
            return

        try:
            self._write_sessions()
            logger.debug(
                "ConversationRegistry._flush: wrote %d sessions", len(self._sessions)
            )
        except Exception as exc:  # noqa: BLE001
            logger.error("ConversationRegistry._flush: failed to flush: %s", exc)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def load(self) -> None:
        """
        Load session records from ``sessions.jsonl``.

        CRAWL Gap 4: corrupt (non-parseable) lines are skipped with a
        warning — they do not raise.

        R4: If the primary file is unreadable, falls back to
        ``sessions.1.jsonl`` without raising.
        """
        primary = self._dir / _SESSIONS_FILE
        fallback = self._dir / "sessions.1.jsonl"

        loaded = self._load_jsonl(primary, is_fallback=False)
        if loaded is None:
            logger.warning(
                "ConversationRegistry.load: primary file unreadable — trying fallback"
            )
            loaded = self._load_jsonl(fallback, is_fallback=True)

        if loaded is not None:
            self._sessions = {r.session_id: r for r in loaded}
            logger.debug(
                "ConversationRegistry.load: loaded %d sessions", len(self._sessions)
            )
        else:
            logger.info("ConversationRegistry.load: no sessions found — starting fresh")
            self._sessions = {}

    def record(self, session: SessionRecord) -> None:
        """
        Persist a session record with an append-only JSONL write.

        If the active file has reached the rotation threshold the file is
        rotated before the new record is appended.

        Parameters
        ----------
        session:
            The SessionRecord to persist.

        Raises
        ------
        RegistryError:
            If the write fails.
        """
        sessions_file = self._dir / _SESSIONS_FILE

        # Rotate if needed — checked before append
        if self._rotation.should_rotate(sessions_file):
            logger.debug(
                "ConversationRegistry.record: rotating sessions file (size >= %d bytes)",
                self._rotation.max_bytes,
            )
            try:
                self._rotation.rotate(sessions_file)
            except OSError as exc:
                raise RegistryError(f"Failed to rotate sessions file: {exc}") from exc

        # Append-only JSONL write
        line = json.dumps(session.to_dict(), default=str)
        try:
            with sessions_file.open("a", encoding="utf-8") as fh:
                fh.write(line + "\n")
        except OSError as exc:
            raise RegistryError(
                f"Failed to append session {session.session_id} to {sessions_file}: {exc}"
            ) from exc

        self._sessions[session.session_id] = session
        self._dirty = True
        # Reset idempotency guard — new data is pending
        self._flushed = False

    def get_session(self, session_id: str) -> SessionRecord | None:
        """Return the SessionRecord for *session_id*, or None if not found."""
        return self._sessions.get(session_id)

    def list_sessions(
        self,
        limit: int = 50,
        task_id: str | None = None,
    ) -> list[SessionRecord]:
        """
        Return a list of sessions ordered by last_active_at descending.

        Parameters
        ----------
        limit:
            Maximum number of sessions to return.
        task_id:
            Optional filter on SessionRecord.title prefix (nexus task IDs
            are embedded in the title).
        """
        sessions = list(self._sessions.values())
        if task_id:
            sessions = [s for s in sessions if task_id in s.title]
        sessions.sort(key=lambda s: s.last_active_at, reverse=True)
        return sessions[:limit]

    def prune(self, retention_days: int) -> int:
        """
        Remove session records older than *retention_days* days.

        Returns the number of records pruned.  Performs an atomic rewrite of
        sessions.jsonl (write to .tmp -> os.replace).
        """
        import os

        cutoff = datetime.now(tz=timezone.utc).timestamp() - retention_days * 86400
        before_count = len(self._sessions)

        self._sessions = {
            sid: record
            for sid, record in self._sessions.items()
            if record.last_active_at.timestamp() >= cutoff
        }

        pruned = before_count - len(self._sessions)
        if pruned > 0:
            logger.info("ConversationRegistry.prune: removed %d sessions", pruned)
            try:
                self._write_sessions_atomic()
            except OSError as exc:
                raise RegistryError(f"Failed to write pruned sessions: {exc}") from exc
            self._dirty = False

        return pruned

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _load_jsonl(
        self, path: Path, *, is_fallback: bool
    ) -> list[SessionRecord] | None:
        """
        Parse a JSONL file into a list of SessionRecords.

        Returns None if the file is unreadable (not found or OS error).
        Skips corrupt lines with a warning (CRAWL Gap 4).
        """
        if not path.exists():
            return None

        records: list[SessionRecord] = []
        try:
            text = path.read_text(encoding="utf-8")
        except OSError as exc:
            logger.warning(
                "ConversationRegistry: cannot read %s: %s",
                path,
                exc,
            )
            return None

        for lineno, line in enumerate(text.splitlines(), 1):
            stripped = line.strip()
            if not stripped:
                continue
            try:
                data = json.loads(stripped)
                record = SessionRecord.from_dict(data)
                records.append(record)
            except (json.JSONDecodeError, KeyError, ValueError, TypeError) as exc:
                label = "fallback" if is_fallback else "primary"
                logger.warning(
                    "ConversationRegistry: skipping corrupt line %d in %s file %s: %s",
                    lineno,
                    label,
                    path.name,
                    exc,
                )
                # Raise SessionCorruptError only if primary becomes entirely unreadable
                # and we're about to fall through — per spec, corrupt *lines* are skipped

        return records

    def _write_sessions(self) -> None:
        """Append-write all dirty sessions (used by _flush)."""
        # For flush we just ensure all in-memory sessions are on disk.
        # Since we use append-only writes in record(), in-memory state is
        # already reflected in the file.  Nothing additional needed unless
        # this is called for a full rewrite (e.g., after prune).
        pass

    def _write_sessions_atomic(self) -> None:
        """
        Atomically rewrite sessions.jsonl from in-memory state.

        Used after prune().  Writes to a .tmp file then os.replace.
        """
        import os

        sessions_file = self._dir / _SESSIONS_FILE
        tmp_file = self._dir / "sessions.tmp"

        lines = [
            json.dumps(record.to_dict(), default=str)
            for record in self._sessions.values()
        ]
        content = "\n".join(lines) + ("\n" if lines else "")

        try:
            tmp_file.write_text(content, encoding="utf-8")
            os.replace(str(tmp_file), str(sessions_file))
        except OSError as exc:
            # Clean up tmp on failure
            if tmp_file.exists():
                try:
                    tmp_file.unlink()
                except OSError:
                    pass
            raise exc
