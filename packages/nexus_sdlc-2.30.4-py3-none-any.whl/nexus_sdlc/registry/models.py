"""
nexus_sdlc.registry.models — SessionRecord dataclass.

AR-4: MUST NOT store credentials (NEXUS_MCP_SECRET, ANTHROPIC_API_KEY) in any field.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from nexus_sdlc.exceptions import SessionError

# Credentials that must never appear in session record fields
_FORBIDDEN_SESSION_STRINGS = ("NEXUS_MCP_SECRET", "ANTHROPIC_API_KEY")


@dataclass
class SessionRecord:
    """
    Immutable session record — append to JSONL, never mutate in place.

    Fields
    ------
    session_id:
        UUID4 string.
    project_dir:
        Absolute path to the project directory for this conversation.
    created_at:
        Timestamp of session creation.
    last_active_at:
        Timestamp of most recent activity.
    turn_count:
        Number of completed prompt/response turns.
    title:
        First user message, truncated to 80 characters.

    Security
    --------
    ``__post_init__`` rejects any record whose ``session_id`` or ``title``
    fields contain the literal strings ``NEXUS_MCP_SECRET`` or
    ``ANTHROPIC_API_KEY`` — AR-4 enforcement.
    """

    session_id: str          # UUID4
    project_dir: str         # absolute path
    created_at: datetime
    last_active_at: datetime
    turn_count: int = 0
    title: str = field(default="")  # first user message, truncated to 80 chars

    def __post_init__(self) -> None:
        for forbidden in _FORBIDDEN_SESSION_STRINGS:
            if forbidden in self.session_id or forbidden in self.title:
                raise SessionError(
                    f"Credential string {forbidden!r} found in session record field — "
                    "refusing to persist."
                )

    def to_dict(self) -> dict:
        """Serialise to a JSON-compatible dict for JSONL persistence."""
        return {
            "session_id": self.session_id,
            "project_dir": self.project_dir,
            "created_at": self.created_at.isoformat(),
            "last_active_at": self.last_active_at.isoformat(),
            "turn_count": self.turn_count,
            "title": self.title,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "SessionRecord":
        """Deserialise from a JSONL-parsed dict."""
        return cls(
            session_id=data["session_id"],
            project_dir=data["project_dir"],
            created_at=datetime.fromisoformat(data["created_at"]),
            last_active_at=datetime.fromisoformat(data["last_active_at"]),
            turn_count=int(data.get("turn_count", 0)),
            title=data.get("title", ""),
        )
