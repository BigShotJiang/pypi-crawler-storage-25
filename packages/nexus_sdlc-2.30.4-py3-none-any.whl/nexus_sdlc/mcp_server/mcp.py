"""MCP client for nexus-sdlc — talks to the local NexusMCPServer.

This module provides a typed async client for callers who want to communicate
with the running NexusMCPServer via JSON-RPC over TCP (127.0.0.1:NEXUS_MCP_PORT).

It is NOT the server itself — that lives in server.py.
"""

from __future__ import annotations

import asyncio
import json
import os
import hmac
from typing import Any


class NexusMCPClient:
    """JSON-RPC client for the local NexusMCPServer.

    Connects to the server that nexus mcp-server has started on 127.0.0.1.
    Authenticates every call with NEXUS_MCP_SECRET.

    Typical usage::

        client = NexusMCPClient()
        status = await client.get_workflow_status("task-abc123")

    Parameters
    ----------
    port : int | None
        Port the local MCP server is listening on. Defaults to the value of
        ``NEXUS_MCP_PORT`` environment variable, or 9337 if unset.
    secret : str | None
        NEXUS_MCP_SECRET value used to authenticate each call. Defaults to
        ``NEXUS_MCP_SECRET`` environment variable. Empty string if unset
        (calls will fail with MCPAuthError on the server side).
    """

    def __init__(self, *, port: int | None = None, secret: str | None = None) -> None:
        self._port = port or int(os.environ.get("NEXUS_MCP_PORT", "9337"))
        self._secret = secret or os.environ.get("NEXUS_MCP_SECRET", "")

    async def call(self, method: str, params: dict | None = None) -> Any:
        """Send a JSON-RPC request to the local MCP server.

        Opens a new TCP connection for each call (stateless). Sends the
        request, reads the response, and returns the ``result`` field.

        Parameters
        ----------
        method : str
            MCP tool name to invoke (e.g. ``"health_check"``).
        params : dict | None
            Tool parameters. ``secret`` is injected automatically — callers
            must NOT include it here.

        Returns
        -------
        Any
            The ``result`` field from the JSON-RPC response.

        Raises
        ------
        ConnectionRefusedError
            If the MCP server is not running on the configured port.
        ValueError
            If the server returns a JSON-RPC error response.
        asyncio.TimeoutError
            If the request does not complete within 30 seconds.
        """
        payload: dict[str, Any] = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": method,
            "params": {**(params or {}), "secret": self._secret},
        }
        encoded = json.dumps(payload).encode() + b"\n"

        reader, writer = await asyncio.wait_for(
            asyncio.open_connection("127.0.0.1", self._port),
            timeout=30.0,
        )
        try:
            writer.write(encoded)
            await writer.drain()
            raw = await asyncio.wait_for(reader.readline(), timeout=30.0)
        finally:
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass

        response = json.loads(raw.decode())
        if "error" in response:
            raise ValueError(f"MCP error: {response['error']}")
        return response.get("result")

    async def health_check(self) -> dict:
        """Call the ``health_check`` MCP tool.

        Returns
        -------
        dict
            Health status dict with ``status``, ``components``, and
            ``timestamp`` keys. See ``tools/system.py`` for the full schema.
        """
        result = await self.call("health_check")
        return result if isinstance(result, dict) else {}

    async def list_conversations(self) -> list[dict]:
        """Call the ``list_conversations`` MCP tool with default parameters.

        Returns
        -------
        list[dict]
            List of session summary dicts. Empty list if no sessions exist.
        """
        result = await self.call("list_conversations")
        if isinstance(result, dict):
            return result.get("sessions", [])
        return []

    async def get_workflow_status(self, task_id: str) -> dict:
        """Call the ``get_workflow_status`` MCP tool.

        Parameters
        ----------
        task_id : str
            Temporal workflow ID. Must match ``[a-zA-Z0-9_-]+`` (max 128 chars).

        Returns
        -------
        dict
            Workflow status dict with ``workflow_id``, ``status``, and
            ``raw`` keys.

        Raises
        ------
        ValueError
            If the MCP server returns an error (e.g. invalid workflow_id,
            bridge not found, bridge timeout).
        """
        result = await self.call("get_workflow_status", {"workflow_id": task_id})
        return result if isinstance(result, dict) else {}
