"""MCP tool handlers for Temporal workflow management.

Tools: get_workflow_status, list_workflows.

Both tools shell out to director-bridge.sh via asyncio.create_subprocess_exec.
shell=True is NEVER used (AR-1).
"""

from __future__ import annotations

import asyncio
import importlib.util
import json
import logging
import os
import re
import shutil
from pathlib import Path

from nexus_sdlc.exceptions import (
    BridgeCommandError,
    BridgeNotFoundError,
    BridgeTimeoutError,
    MCPToolError,
)

logger = logging.getLogger(__name__)

_WORKFLOW_ID_RE = re.compile(r'^[a-zA-Z0-9_-]{1,128}$')

_VALID_STATUS_FILTERS = frozenset({
    "running", "completed", "failed", "terminated", "cancelled", "timed_out"
})

_BRIDGE_TIMEOUT_SECONDS = 30.0


def _resolve_bridge() -> str:
    """Resolve the director-bridge.sh path.

    Resolution order:
    1. NEXUS_BRIDGE env var
    2. {package_install_dir}/../../core/director-bridge.sh (relative to package)
    3. "director-bridge.sh" on $PATH

    Raises
    ------
    BridgeNotFoundError
        If bridge script not found at any resolution path.
    """
    # 1. NEXUS_BRIDGE env var
    nexus_bridge = os.environ.get("NEXUS_BRIDGE")
    if nexus_bridge and Path(nexus_bridge).is_file():
        return nexus_bridge

    # 2. Relative to installed package directory
    try:
        spec = importlib.util.find_spec("nexus_sdlc")
        if spec and spec.origin:
            pkg_dir = Path(spec.origin).parent
            candidate = (pkg_dir / ".." / ".." / "core" / "director-bridge.sh").resolve()
            if candidate.is_file():
                return str(candidate)
    except (ValueError, AttributeError):
        pass

    # 3. $PATH
    found = shutil.which("director-bridge.sh")
    if found:
        return found

    raise BridgeNotFoundError(
        "director-bridge.sh not found. Set NEXUS_BRIDGE env var or ensure it is on $PATH."
    )


async def _run_bridge(args: list[str]) -> tuple[str, str, int]:
    """Run director-bridge.sh with the given arguments.

    Returns
    -------
    tuple[str, str, int]
        (stdout, stderr, returncode)

    Raises
    ------
    BridgeNotFoundError : bridge not found.
    BridgeTimeoutError  : subprocess exceeded 30s.
    BridgeCommandError  : non-zero exit from bridge.
    """
    bridge_path = _resolve_bridge()

    # AR-1: never use shell=True
    proc = await asyncio.create_subprocess_exec(
        bridge_path,
        *args,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )

    try:
        stdout_bytes, stderr_bytes = await asyncio.wait_for(
            proc.communicate(), timeout=_BRIDGE_TIMEOUT_SECONDS
        )
    except asyncio.TimeoutError:
        proc.kill()
        await proc.communicate()
        raise BridgeTimeoutError(
            f"director-bridge.sh exceeded {_BRIDGE_TIMEOUT_SECONDS}s timeout"
        )

    stdout = stdout_bytes.decode(errors="replace")
    stderr = stderr_bytes.decode(errors="replace")
    returncode = proc.returncode or 0

    if returncode != 0:
        raise BridgeCommandError(
            f"director-bridge.sh exited {returncode}: {stderr.strip()}"
        )

    return stdout, stderr, returncode


async def get_workflow_status(
    secret: str,
    workflow_id: str,
    *,
    _ctx: dict,
) -> dict:
    """Return status of a Temporal workflow via director-bridge.sh.

    Shells to: director-bridge.sh workflow status {workflow_id}
    Timeout: 30 seconds.

    Bridge path resolution (in order):
    1. NEXUS_BRIDGE env var
    2. {package_install_dir}/../../core/director-bridge.sh (relative to package)
    3. "director-bridge.sh" on $PATH

    Returns
    -------
    dict
        {
          "workflow_id": str,
          "status": str,
          "raw": str   # full stdout for passthrough
        }

    Errors
    ------
    BridgeTimeoutError : subprocess exceeds 30s.
    BridgeCommandError : non-zero exit from director-bridge.sh.
    BridgeNotFoundError : bridge script not found at any resolution path.
    MCPToolError("invalid workflow_id") : workflow_id fails validation.

    Constraints
    -----------
    - asyncio.create_subprocess_exec — no shell=True.
    - workflow_id must match regex [a-zA-Z0-9_-]+ (max 128 chars).
    """
    if not _WORKFLOW_ID_RE.match(workflow_id):
        raise MCPToolError("invalid workflow_id")

    stdout, _stderr, _rc = await _run_bridge(["workflow", "status", workflow_id])

    # Attempt to parse JSON from bridge stdout
    parsed: dict = {}
    try:
        parsed = json.loads(stdout)
    except json.JSONDecodeError:
        pass

    status = parsed.get("status", "unknown") if isinstance(parsed, dict) else "unknown"

    return {
        "workflow_id": workflow_id,
        "status": status,
        "raw": stdout,
    }


async def list_workflows(
    secret: str,
    limit: int = 20,
    status_filter: str | None = None,
    *,
    _ctx: dict,
) -> dict:
    """List recent Temporal workflows via director-bridge.sh.

    Shells to: director-bridge.sh workflow list [--status {status_filter}]
    Timeout: 30 seconds.

    Returns
    -------
    dict
        {
          "workflows": [...],   # parsed from bridge stdout
          "total": int,
          "raw": str
        }

    Errors
    ------
    BridgeTimeoutError, BridgeCommandError, BridgeNotFoundError : same as get_workflow_status.
    MCPToolError : invalid status_filter.

    Constraints
    -----------
    - limit clamped to [1, 100].
    - status_filter must be one of: "running", "completed", "failed",
      "terminated", "cancelled", "timed_out".
    - No shell=True.
    """
    limit = max(1, min(100, limit))

    if status_filter is not None and status_filter not in _VALID_STATUS_FILTERS:
        raise MCPToolError(
            f"invalid status_filter '{status_filter}'; "
            f"must be one of: {', '.join(sorted(_VALID_STATUS_FILTERS))}"
        )

    args = ["workflow", "list"]
    if status_filter is not None:
        args += ["--status", status_filter]

    stdout, _stderr, _rc = await _run_bridge(args)

    workflows: list = []
    try:
        parsed = json.loads(stdout)
        if isinstance(parsed, list):
            workflows = parsed[:limit]
        elif isinstance(parsed, dict):
            workflows = parsed.get("workflows", [])[:limit]
    except json.JSONDecodeError:
        pass

    return {
        "workflows": workflows,
        "total": len(workflows),
        "raw": stdout,
    }
