"""MCP tool handlers for conversation sessions.

Tools: list_conversations, get_conversation, tail_events.

Dependencies:
  ConversationRegistry — from nexus_sdlc.registry.conversation_registry
  FilesystemBoundary   — injected via NexusMCPServer

These dependencies are injected at runtime through the server's tool context.
Tool functions accept a `_ctx` dict carrying {registry, boundary} so that
the MCP server can inject them without module-level singletons (AR-5).
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import TYPE_CHECKING

from nexus_sdlc.exceptions import FilesystemBoundaryError, MCPToolError, RegistryError

if TYPE_CHECKING:
    from nexus_sdlc.mcp_server.boundary import FilesystemBoundary

logger = logging.getLogger(__name__)

# Secret field names that must be redacted when tail_events reads JSONL payloads
_SECRET_FIELD_NAMES = frozenset({"secret", "password", "token", "key"})

_REDACTED = "***REDACTED***"


def _redact_event(event: dict) -> dict:
    """Return a copy of event with sensitive field values replaced."""
    return {
        k: _REDACTED if any(s in k.lower() for s in _SECRET_FIELD_NAMES) else v
        for k, v in event.items()
    }


async def list_conversations(
    secret: str,
    limit: int = 50,
    task_id: str | None = None,
    *,
    _ctx: dict,
) -> dict:
    """List recent conversation sessions from ConversationRegistry.

    Returns
    -------
    dict
        {
          "sessions": [
            {
              "session_id": str,      # UUID
              "task_id": str | null,
              "started_at": str,      # ISO-8601
              "status": str,          # "running" | "completed" | "terminated"
              "project_dir": str      # absolute path string
            },
            ...
          ],
          "total": int
        }

    Errors
    ------
    MCPToolError : registry unavailable or RegistryError raised internally.

    Constraints
    -----------
    - limit clamped to [1, 200].
    - Returns empty list if registry has no sessions — not an error.
    - Does not include JSONL raw content in response.
    """
    registry = _ctx.get("registry")
    if registry is None:
        return {"error": {"code": -32001, "message": "Service not available"}}

    limit = max(1, min(200, limit))
    try:
        sessions = await registry.list_sessions(limit=limit, task_id=task_id)
    except RegistryError as exc:
        raise MCPToolError(f"registry error: {exc}") from exc
    except Exception as exc:
        raise MCPToolError(f"unexpected registry error: {exc}") from exc

    session_list = []
    for s in sessions:
        session_list.append({
            "session_id": getattr(s, "session_id", str(s)),
            "task_id": getattr(s, "task_id", None),
            "started_at": (
                s.created_at.isoformat()
                if hasattr(s, "created_at") and s.created_at is not None
                else None
            ),
            "status": getattr(s, "status", "unknown"),
            "project_dir": getattr(s, "project_dir", ""),
        })

    return {"sessions": session_list, "total": len(session_list)}


async def get_conversation(
    secret: str,
    session_id: str,
    *,
    _ctx: dict,
) -> dict:
    """Return full session record for a specific session UUID.

    Returns
    -------
    dict
        {
          "session_id": str,
          "task_id": str | null,
          "started_at": str,
          "ended_at": str | null,
          "status": str,
          "project_dir": str,
          "exit_code": int | null,
          "events_count": int
        }

    Errors
    ------
    MCPToolError("session not found: {session_id}") : session_id does not exist.
    MCPToolError : registry unavailable.
    """
    registry = _ctx.get("registry")
    if registry is None:
        return {"error": {"code": -32001, "message": "Service not available"}}

    try:
        session = await registry.get_session(session_id)
    except RegistryError as exc:
        raise MCPToolError(f"registry error: {exc}") from exc
    except Exception as exc:
        raise MCPToolError(f"unexpected registry error: {exc}") from exc

    if session is None:
        raise MCPToolError(f"session not found: {session_id}")

    return {
        "session_id": getattr(session, "session_id", session_id),
        "task_id": getattr(session, "task_id", None),
        "started_at": (
            session.created_at.isoformat()
            if hasattr(session, "created_at") and session.created_at is not None
            else None
        ),
        "ended_at": (
            session.ended_at.isoformat()
            if hasattr(session, "ended_at") and session.ended_at is not None
            else None
        ),
        "status": getattr(session, "status", "unknown"),
        "project_dir": getattr(session, "project_dir", ""),
        "exit_code": getattr(session, "exit_code", None),
        "events_count": getattr(session, "turn_count", 0),
    }


async def tail_events(
    secret: str,
    session_id: str,
    n: int = 20,
    *,
    _ctx: dict,
) -> dict:
    """Return the last N JSONL events from a session's log file.

    Uses FilesystemBoundary.check() on the session's JSONL path before
    reading. The JSONL path is derived from session_id and the registry's
    sessions_dir — it must be within ~/.nexus/sessions/.

    Returns
    -------
    dict
        {
          "session_id": str,
          "events": [
            {"event_type": str, "timestamp": str, ...},
            ...
          ],
          "truncated": bool   # true if file has more than n lines
        }

    Errors
    ------
    FilesystemBoundaryError : path escapes allowed root.
    MCPToolError("session not found: {session_id}") : session does not exist.
    MCPToolError : file unreadable or corrupt.

    Constraints
    -----------
    - n clamped to [1, 100].
    - Skips corrupt JSONL lines (same recovery as ConversationRegistry).
    - Does NOT include raw event payloads that contain secret/password/token/key fields.
    """
    registry = _ctx.get("registry")
    boundary: FilesystemBoundary | None = _ctx.get("boundary")

    if registry is None:
        return {"error": {"code": -32001, "message": "Service not available"}}

    n = max(1, min(100, n))

    try:
        session = await registry.get_session(session_id)
    except RegistryError as exc:
        raise MCPToolError(f"registry error: {exc}") from exc

    if session is None:
        raise MCPToolError(f"session not found: {session_id}")

    # Derive the JSONL path from the registry sessions directory
    sessions_dir = getattr(registry, "_dir", None) or getattr(registry, "SESSIONS_DIR", None)
    if sessions_dir is None:
        sessions_dir = Path.home() / ".nexus" / "sessions"

    jsonl_path = Path(sessions_dir) / f"{session_id}.jsonl"

    # Boundary check before reading
    if boundary is not None:
        try:
            jsonl_path = boundary.check(jsonl_path)
        except FilesystemBoundaryError:
            raise
        except MCPToolError:
            raise MCPToolError(f"session not found: {session_id}")

    if not jsonl_path.exists():
        raise MCPToolError(f"session not found: {session_id}")

    try:
        raw_lines = jsonl_path.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        raise MCPToolError(f"file unreadable: {exc}") from exc

    truncated = len(raw_lines) > n
    tail_lines = raw_lines[-n:] if n < len(raw_lines) else raw_lines

    events = []
    for line in tail_lines:
        line = line.strip()
        if not line:
            continue
        try:
            event = json.loads(line)
            events.append(_redact_event(event))
        except json.JSONDecodeError:
            logger.warning("skipping corrupt JSONL line in session %s", session_id)

    return {
        "session_id": session_id,
        "events": events,
        "truncated": truncated,
    }
