"""MCP tool handler for Nexus configuration.

Tool: get_config
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from nexus_sdlc.exceptions import MCPToolError

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)

# Key names whose values must always be redacted.
# "key" alone is intentionally excluded — it is too broad and would redact
# legitimate non-sensitive keys like "normal_key" or "existing_key".
# Specific compound patterns are used instead.
_SENSITIVE_SUBSTRINGS = frozenset({"secret", "password", "token", "api_key", "private_key"})

_REDACTED = "***REDACTED***"

# NEXUS_MCP_SECRET must never appear regardless of filtering
_NEVER_EXPOSE_KEYS = frozenset({"NEXUS_MCP_SECRET"})


def _should_redact(key: str) -> bool:
    """Return True if the key name indicates a sensitive value."""
    key_lower = key.lower()
    return any(sub in key_lower for sub in _SENSITIVE_SUBSTRINGS)


async def get_config(
    secret: str,
    project_dir: str,
    keys: "list[str] | None" = None,
    *,
    _ctx: dict,
) -> dict:
    """Read Nexus configuration via 4-tier loader with secret redaction.

    4-tier resolution order (same as director-bridge.sh::_resolve_infra):
    1. NEXUS_* env vars (sourced from ~/.nexus-env)
    2. {project_dir}/.nexus/config.yaml
    3. {workspace}/.nexus/config.yaml
    4. Hardcoded defaults in NexusConfigLoader

    Secret key redaction: any config key whose name contains "secret",
    "password", "token", or "key" (case-insensitive) is replaced with
    "***REDACTED***" in the response.

    Returns
    -------
    dict
        {
          "config": {
            "key": value_or_redacted,
            ...
          },
          "tier_sources": {
            "key": "env" | "project" | "workspace" | "default"
          }
        }

    Errors
    ------
    MCPToolError("project_dir must be absolute path") : relative path provided.
    MCPToolError("config.yaml not found") : project has no .nexus/config.yaml.

    Constraints
    -----------
    - Secrets resolve ONLY from Tier 1 (env vars) — never from YAML files.
    - If keys list provided, return only those keys. If key absent, include
      with value null.
    - The raw value of NEXUS_MCP_SECRET must never appear in the response
      regardless of key filtering.
    - Read-only — no writes.
    """
    if not project_dir.startswith("/"):
        raise MCPToolError("project_dir must be absolute path")

    config_loader = _ctx.get("config_loader")
    if config_loader is None:
        return {"error": {"code": -32001, "message": "Service not available"}}

    # Verify the project has a config.yaml
    from pathlib import Path
    config_yaml = Path(project_dir) / ".nexus" / "config.yaml"
    if not config_yaml.exists():
        raise MCPToolError("config.yaml not found")

    # Use the config loader to get all configuration
    try:
        raw_config: dict = {}
        tier_sources: dict = {}

        if hasattr(config_loader, "get_all"):
            raw_config, tier_sources = config_loader.get_all(project_dir=project_dir)
        elif hasattr(config_loader, "load"):
            raw_config = config_loader.load(project_dir=project_dir)
        else:
            # Minimal fallback: read config.yaml directly
            import yaml  # type: ignore[import]
            with open(config_yaml) as f:
                raw_config = yaml.safe_load(f) or {}
    except Exception as exc:
        raise MCPToolError(f"config load error: {exc}") from exc

    # Filter to requested keys if provided
    if keys is not None:
        filtered = {k: raw_config.get(k) for k in keys}
    else:
        filtered = dict(raw_config)

    # Apply redaction rules
    result_config = {}
    for k, v in filtered.items():
        if k in _NEVER_EXPOSE_KEYS or _should_redact(k):
            result_config[k] = _REDACTED
        else:
            result_config[k] = v

    # Filter tier_sources to match the returned keys
    result_tier_sources = {k: tier_sources.get(k, "unknown") for k in result_config}

    return {
        "config": result_config,
        "tier_sources": result_tier_sources,
    }
