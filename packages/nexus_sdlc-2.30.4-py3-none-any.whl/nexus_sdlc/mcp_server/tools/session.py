"""MCP tool handler for Nexus session state files.

Tool: get_session_state
"""

from __future__ import annotations

import datetime
import logging
from pathlib import Path
from typing import TYPE_CHECKING

from nexus_sdlc.exceptions import FilesystemBoundaryError, MCPToolError

if TYPE_CHECKING:
    from nexus_sdlc.mcp_server.boundary import FilesystemBoundary

logger = logging.getLogger(__name__)

_MAX_SESSION_STATE_BYTES = 1024 * 1024  # 1 MB


async def get_session_state(
    secret: str,
    project_dir: str,
    *,
    _ctx: dict,
) -> dict:
    """Read .nexus/session-state.md from the given project directory.

    Uses FilesystemBoundary.check() on the resolved path of
    {project_dir}/.nexus/session-state.md before reading.

    Returns
    -------
    dict
        {
          "project_dir": str,
          "session_state_path": str,     # resolved absolute path
          "content": str,                # raw markdown content
          "size_bytes": int,
          "last_modified": str           # ISO-8601
        }

    Errors
    ------
    FilesystemBoundaryError : resolved path outside registered project boundary.
    MCPToolError("session-state.md not found in {project_dir}/.nexus/") : file absent.
    MCPToolError("project_dir must be absolute path") : relative path provided.

    Constraints
    -----------
    - project_dir must be an absolute path string (starts with "/").
    - FilesystemBoundary must receive the fully resolved path of session-state.md,
      not just project_dir.
    - File size limit: 1 MB. If file > 1 MB, return truncated content with
      "truncated": true in response.
    """
    if not project_dir.startswith("/"):
        raise MCPToolError("project_dir must be absolute path")

    session_state_path = Path(project_dir) / ".nexus" / "session-state.md"

    boundary: FilesystemBoundary | None = _ctx.get("boundary")
    if boundary is not None:
        # Boundary check uses strict=True; MCPToolError raised if file absent
        try:
            resolved_path = boundary.check(session_state_path)
        except FilesystemBoundaryError:
            raise
        except MCPToolError:
            raise MCPToolError(
                f"session-state.md not found in {project_dir}/.nexus/"
            )
    else:
        if not session_state_path.exists():
            raise MCPToolError(
                f"session-state.md not found in {project_dir}/.nexus/"
            )
        resolved_path = session_state_path.resolve()

    size_bytes = resolved_path.stat().st_size
    truncated = size_bytes > _MAX_SESSION_STATE_BYTES

    try:
        raw = resolved_path.read_bytes()
        if truncated:
            raw = raw[:_MAX_SESSION_STATE_BYTES]
        content = raw.decode("utf-8", errors="replace")
    except OSError as exc:
        raise MCPToolError(f"file unreadable: {exc}") from exc

    mtime = resolved_path.stat().st_mtime
    last_modified = datetime.datetime.fromtimestamp(
        mtime, tz=datetime.timezone.utc
    ).isoformat()

    result = {
        "project_dir": project_dir,
        "session_state_path": str(resolved_path),
        "content": content,
        "size_bytes": size_bytes,
        "last_modified": last_modified,
    }
    if truncated:
        result["truncated"] = True
    return result
