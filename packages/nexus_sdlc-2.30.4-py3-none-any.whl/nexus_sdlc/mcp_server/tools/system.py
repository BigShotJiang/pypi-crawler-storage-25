"""MCP tool handlers for system-level operations.

Tools: tail_events (Valkey-based), health_check.
"""

from __future__ import annotations

import asyncio
import datetime
import logging
import shutil
import time
from typing import TYPE_CHECKING

from nexus_sdlc.exceptions import MCPToolError, RegistryError

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)

_HEALTH_CHECK_TIMEOUT_SECONDS = 5.0


async def tail_events(
    secret: str,
    count: int = 10,
    *,
    _ctx: dict,
) -> dict:
    """Return recent events from ValkeyConsumer if available.

    Reads from ValkeyConsumer if available, else returns empty events list
    with degraded flag.

    Returns
    -------
    dict
        {
          "events": [...],
          "count": int,
          "degraded": bool
        }
    """
    consumer = _ctx.get("valkey_consumer")

    if consumer is None:
        return {
            "events": [],
            "count": 0,
            "degraded": True,
        }

    is_degraded = getattr(consumer, "is_degraded", False)
    if is_degraded:
        return {
            "events": [],
            "count": 0,
            "degraded": True,
        }

    # Attempt to read recent events from consumer buffer if available
    recent_events: list = []
    if hasattr(consumer, "recent_events"):
        try:
            recent_events = list(consumer.recent_events)[-count:]
        except Exception:
            pass

    return {
        "events": recent_events,
        "count": len(recent_events),
        "degraded": False,
    }


async def health_check(
    secret: str,
    *,
    _ctx: dict,
) -> dict:
    """Check health of Nexus system components.

    Checks (run concurrently via asyncio.gather, 5s total timeout):
    1. claude binary: shutil.which("claude") is not None
    2. ConversationRegistry: call registry.list_sessions(limit=1) and measure latency
    3. Valkey: if ValkeyConsumer is present, check consumer.is_connected property

    Returns
    -------
    dict
        {
          "status": "healthy" | "degraded" | "unhealthy",
          "components": {
            "claude_binary": {
              "status": "ok" | "missing",
              "path": str | null
            },
            "registry": {
              "status": "ok" | "error",
              "latency_ms": float | null,
              "error": str | null
            },
            "valkey": {
              "status": "ok" | "disconnected" | "degraded" | "unavailable",
              "error": str | null
            }
          },
          "timestamp": str   # ISO-8601
        }

    Rules for overall status:
    - "healthy": all components ok
    - "degraded": valkey disconnected/degraded but registry and claude ok
    - "unhealthy": claude missing OR registry error

    Constraints
    -----------
    - Total timeout: 5 seconds. Components that exceed their timeout report "error".
    - Never raises — always returns dict, even on partial failures.
    - Valkey status "unavailable" if ValkeyConsumer was not injected into server.
    """
    registry = _ctx.get("registry")
    valkey_consumer = _ctx.get("valkey_consumer")

    async def check_claude() -> dict:
        try:
            path = shutil.which("claude")
            if path:
                return {"status": "ok", "path": path}
            return {"status": "missing", "path": None}
        except Exception as exc:
            return {"status": "error", "path": None, "error": str(exc)}

    async def check_registry() -> dict:
        if registry is None:
            return {"status": "error", "latency_ms": None, "error": "registry not available"}
        start = time.monotonic()
        try:
            await registry.list_sessions(limit=1)
            latency_ms = (time.monotonic() - start) * 1000.0
            return {"status": "ok", "latency_ms": round(latency_ms, 2), "error": None}
        except RegistryError as exc:
            return {"status": "error", "latency_ms": None, "error": str(exc)}
        except Exception as exc:
            return {"status": "error", "latency_ms": None, "error": str(exc)}

    async def check_valkey() -> dict:
        if valkey_consumer is None:
            return {"status": "unavailable", "error": None}
        try:
            if getattr(valkey_consumer, "is_degraded", False):
                return {"status": "degraded", "error": "consumer in degraded state"}
            if getattr(valkey_consumer, "is_connected", False):
                return {"status": "ok", "error": None}
            return {"status": "disconnected", "error": None}
        except Exception as exc:
            return {"status": "error", "error": str(exc)}

    try:
        claude_result, registry_result, valkey_result = await asyncio.wait_for(
            asyncio.gather(
                check_claude(),
                check_registry(),
                check_valkey(),
                return_exceptions=False,
            ),
            timeout=_HEALTH_CHECK_TIMEOUT_SECONDS,
        )
    except asyncio.TimeoutError:
        claude_result = {"status": "error", "path": None, "error": "timeout"}
        registry_result = {"status": "error", "latency_ms": None, "error": "timeout"}
        valkey_result = {"status": "error", "error": "timeout"}
    except Exception as exc:
        # Never raises — catch-all safety net
        logger.error("health_check gather failed: %s", exc)
        claude_result = {"status": "error", "path": None, "error": str(exc)}
        registry_result = {"status": "error", "latency_ms": None, "error": str(exc)}
        valkey_result = {"status": "error", "error": str(exc)}

    # Determine overall status
    claude_ok = claude_result.get("status") == "ok"
    registry_ok = registry_result.get("status") == "ok"
    valkey_status = valkey_result.get("status", "unavailable")
    valkey_ok_or_unavailable = valkey_status in ("ok", "unavailable")
    valkey_degraded = valkey_status in ("disconnected", "degraded")

    if not claude_ok or not registry_ok:
        overall_status = "unhealthy"
    elif valkey_degraded:
        overall_status = "degraded"
    else:
        overall_status = "healthy"

    timestamp = datetime.datetime.now(tz=datetime.timezone.utc).isoformat()

    return {
        "status": overall_status,
        "components": {
            "claude_binary": claude_result,
            "registry": registry_result,
            "valkey": valkey_result,
        },
        "timestamp": timestamp,
    }
