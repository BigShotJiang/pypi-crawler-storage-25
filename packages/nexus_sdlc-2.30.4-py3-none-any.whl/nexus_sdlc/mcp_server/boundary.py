"""FilesystemBoundary — enforces MCP file access within registered project directories."""

from pathlib import Path

from nexus_sdlc.exceptions import FilesystemBoundaryError, MCPToolError


class FilesystemBoundary:
    """Enforces that all file access via MCP tools stays within registered
    project directories.

    Resolves symlinks before the boundary check. This prevents symlink
    traversal attacks where a symlink inside the allowed tree points
    outside it.
    """

    def __init__(self, allowed_roots: list[Path]) -> None:
        """
        Parameters
        ----------
        allowed_roots : list[Path]
            Absolute resolved paths of all registered project directories.
            Each element must already be resolved (no symlinks, absolute).
        """
        self._allowed_roots: list[Path] = list(allowed_roots)

    def check(self, path: "Path | str") -> Path:
        """Resolve `path` and verify it is inside an allowed root.

        Parameters
        ----------
        path : Path | str
            The path to check. May be relative or contain symlinks.

        Returns
        -------
        Path
            The fully resolved absolute path, confirmed within boundary.

        Raises
        ------
        FilesystemBoundaryError
            If the resolved path is not under any allowed_root.
        MCPToolError
            If Path.resolve(strict=True) raises FileNotFoundError
            (i.e., the path does not exist).
        """
        try:
            resolved = Path(path).resolve(strict=True)
        except FileNotFoundError as exc:
            raise MCPToolError(f"path does not exist: {path}") from exc

        for root in self._allowed_roots:
            try:
                if resolved.is_relative_to(root):
                    return resolved
            except TypeError:
                # Python < 3.9 fallback: is_relative_to added in 3.9
                # Project requires >=3.11, so this branch should never execute
                try:
                    resolved.relative_to(root)
                    return resolved
                except ValueError:
                    continue

        raise FilesystemBoundaryError(
            f"path '{resolved}' is outside all registered project boundaries"
        )
