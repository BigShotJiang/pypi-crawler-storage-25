"""NexusMCPServer — JSON-RPC 2.0 MCP server for Nexus SDLC tools.

Binds to 127.0.0.1 only. Validates NEXUS_MCP_SECRET on every request.
PID file at ~/.nexus/run/nexus-mcp.pid for singleton detection.

NOTE: SDK API deviation (RISK-R2): The mcp PyPI package (>=1.0.0,<2) API
is used for tool registration. If the SDK's tool registration or listen/serve
call signature differs, this module adapts while preserving all functional
constraints (auth before tools, 127.0.0.1 only, 8 tools). Any deviation
from the expected SDK API is marked with # NOTE: SDK API deviation.
"""

from __future__ import annotations

import asyncio
import json
import logging
import logging.handlers
import os
import signal
import sys
from pathlib import Path
from typing import TYPE_CHECKING, Any

from nexus_sdlc.exceptions import (
    MCPAlreadyRunningError,
    MCPAuthError,
    MCPDepthError,
    MCPToolError,
)
from nexus_sdlc.mcp_server.auth import MCPAuthMiddleware
from nexus_sdlc.mcp_server.boundary import FilesystemBoundary
from nexus_sdlc.mcp_server.tools import conversations, session, system, workflow
from nexus_sdlc.mcp_server.tools import config as config_tool

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)

_PID_FILE = Path.home() / ".nexus" / "run" / "nexus-mcp.pid"
_LOG_DIR = Path.home() / ".nexus" / "logs"
_MCP_SERVER_LOG = _LOG_DIR / "mcp-server.log"
_MCP_AUTH_LOG = _LOG_DIR / "mcp-auth.log"

_HOST = "127.0.0.1"  # hardcoded — no config path or env var override for host
_DEFAULT_PORT = 9337
_DEFAULT_MAX_DEPTH = 3

# Sensitive field substrings for RedactingFormatter
_SENSITIVE_KEYS = frozenset({"secret", "password", "token", "key"})


class RedactingFormatter(logging.Formatter):
    """Log formatter that replaces NEXUS_MCP_SECRET with [REDACTED].

    The secret value is passed at construction time and applied to every
    formatted log record via str.replace. This is defense-in-depth —
    the server must never log secrets in the first place, but if any code
    path inadvertently includes a secret value it will be scrubbed here.
    """

    def __init__(self, *args: object, secret: str | None = None, **kwargs: object) -> None:
        super().__init__(*args, **kwargs)
        self._secret = secret

    def format(self, record: logging.LogRecord) -> str:
        msg = super().format(record)
        if self._secret:
            msg = msg.replace(self._secret, "[REDACTED]")
        return msg


def _setup_logging(secret: str | None = None) -> None:
    """Configure rotating file handlers for mcp-server.log and mcp-auth.log."""
    _LOG_DIR.mkdir(parents=True, exist_ok=True)

    formatter = RedactingFormatter(
        fmt="%(asctime)s %(levelname)s %(name)s: %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
        secret=secret,
    )

    # mcp-server.log: 10 MB / 3 backups
    server_handler = logging.handlers.RotatingFileHandler(
        str(_MCP_SERVER_LOG),
        maxBytes=10 * 1024 * 1024,
        backupCount=3,
    )
    server_handler.setFormatter(formatter)

    # mcp-auth.log: 10 MB / 3 backups
    auth_handler = logging.handlers.RotatingFileHandler(
        str(_MCP_AUTH_LOG),
        maxBytes=10 * 1024 * 1024,
        backupCount=3,
    )
    auth_handler.setFormatter(formatter)

    root = logging.getLogger("nexus_sdlc.mcp_server")
    root.setLevel(logging.INFO)
    if not root.handlers:
        root.addHandler(server_handler)

    auth_log = logging.getLogger("nexus_sdlc.mcp_server.auth")
    if not auth_log.handlers:
        auth_log.addHandler(auth_handler)

    # chmod 600 on log files (best effort)
    for log_path in (_MCP_SERVER_LOG, _MCP_AUTH_LOG):
        try:
            if log_path.exists():
                os.chmod(str(log_path), 0o600)
        except OSError:
            pass


def _check_and_write_pid_file() -> None:
    """Check for existing MCP server process and write PID file.

    Sequence:
    1. If PID file exists, read PID and call os.kill(pid, 0).
       - If process alive: raise MCPAlreadyRunningError.
       - If process dead (stale PID): delete PID file and proceed.
    2. Create run directory if absent.
    3. Write own PID.

    Raises
    ------
    MCPAlreadyRunningError
        If another MCP server instance is alive.
    """
    if _PID_FILE.exists():
        try:
            pid_text = _PID_FILE.read_text().strip()
            pid = int(pid_text)
            os.kill(pid, 0)
            # Process is alive
            raise MCPAlreadyRunningError(
                f"nexus: MCP server already running (pid={pid}). Reuse existing."
            )
        except ValueError:
            # Could not parse PID — stale file
            _PID_FILE.unlink(missing_ok=True)
        except ProcessLookupError:
            # pid doesn't exist — stale
            _PID_FILE.unlink(missing_ok=True)
        except PermissionError:
            # os.kill returned EPERM — process exists but we don't own it
            try:
                pid_text = _PID_FILE.read_text().strip()
                pid = int(pid_text)
                raise MCPAlreadyRunningError(
                    f"nexus: MCP server already running (pid={pid}). Reuse existing."
                )
            except ValueError:
                _PID_FILE.unlink(missing_ok=True)
        except MCPAlreadyRunningError:
            raise
        except OSError:
            # Other OS error — treat as stale
            _PID_FILE.unlink(missing_ok=True)

    _PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    _PID_FILE.write_text(str(os.getpid()))


def _remove_pid_file() -> None:
    """Remove the PID file if it exists and belongs to this process."""
    try:
        if _PID_FILE.exists():
            pid_text = _PID_FILE.read_text().strip()
            if pid_text == str(os.getpid()):
                _PID_FILE.unlink(missing_ok=True)
    except OSError:
        pass


class NexusMCPServer:
    """MCP server for Nexus SDLC tools.

    Binds to 127.0.0.1 only. Validates NEXUS_MCP_SECRET on every
    request via MCPAuthMiddleware before routing to any tool handler.
    Manages a PID file at ~/.nexus/run/nexus-mcp.pid for single-instance
    detection. Runs a ValkeyConsumer asyncio task within its process.
    """

    # Registered project directories for FilesystemBoundary — populated from config at startup
    _default_allowed_roots: list[Path] = [
        Path.home() / ".nexus" / "sessions",
    ]

    def __init__(
        self,
        port: int,
        secret: str,
        registry: Any,
        config_loader: Any,
        valkey_consumer: Any | None = None,
    ) -> None:
        """
        Parameters
        ----------
        port : int
            TCP port to bind. Sourced from NEXUS_MCP_PORT env var (default 9337).
        secret : str
            NEXUS_MCP_SECRET value. Passed to MCPAuthMiddleware. Must not be empty.
        registry : ConversationRegistry
            Injected registry for conversation tool handlers.
        config_loader : NexusConfigLoader
            Injected 4-tier config loader for get_config tool.
        valkey_consumer : ValkeyConsumer | None
            Optional. If provided, started as asyncio task in start().
        """
        self._port = port
        self._auth = MCPAuthMiddleware(secret)
        self._registry = registry
        self._config_loader = config_loader
        self._valkey_consumer = valkey_consumer
        self._max_depth = int(os.environ.get("NEXUS_MCP_DEPTH", str(_DEFAULT_MAX_DEPTH)))
        self._valkey_task: asyncio.Task | None = None
        self._mcp_server: Any = None  # MCP SDK server instance
        self._boundary = FilesystemBoundary(self._default_allowed_roots)
        _setup_logging(secret=secret)

    def _tool_ctx(self) -> dict:
        """Build the context dict injected into tool handlers."""
        return {
            "registry": self._registry,
            "config_loader": self._config_loader,
            "valkey_consumer": self._valkey_consumer,
            "boundary": self._boundary,
        }

    async def start(self) -> None:
        """Start the MCP server.

        Sequence:
        1. Check NEXUS_MCP_DEPTH at startup.
        2. Single-instance check via PID file.
        3. Write own PID.
        4. Register 8 tools.
        5. Bind to 127.0.0.1:{port}.
        6. Start ValkeyConsumer task if provided.
        7. Log startup message.

        Raises
        ------
        MCPAlreadyRunningError
            If another instance is detected via PID file.
        MCPAuthError
            On MCPAuthMiddleware initialization failure (empty secret).
        MCPDepthError
            If NEXUS_MCP_DEPTH >= max_depth at startup.
        """
        # Step 1: Recursion depth check at startup
        current_depth = int(os.environ.get("NEXUS_MCP_DEPTH", "0"))
        if current_depth >= self._max_depth:
            raise MCPDepthError(
                f"nexus: MCP circular invocation detected (depth={current_depth})"
            )

        # Step 2+3: PID file check and write
        _check_and_write_pid_file()

        # Step 4: Register tools and start MCP SDK server
        await self._start_mcp_server()

        # Step 6: Start Valkey consumer task
        if self._valkey_consumer is not None:
            self._valkey_task = asyncio.create_task(
                self._valkey_consumer.start(),
                name="nexus-valkey-consumer",
            )

        # Step 7: Log startup
        logger.info("nexus mcp-server: listening on %s:%d", _HOST, self._port)

    async def stop(self) -> None:
        """Stop the MCP server.

        Sequence:
        1. Cancel valkey asyncio task if running (await with timeout 3s).
        2. Delete PID file.
        3. Close MCP listener.
        4. Log shutdown.
        """
        # Step 1: Cancel valkey task
        if self._valkey_task is not None and not self._valkey_task.done():
            self._valkey_task.cancel()
            try:
                await asyncio.wait_for(
                    asyncio.shield(self._valkey_task), timeout=3.0
                )
            except (asyncio.CancelledError, asyncio.TimeoutError):
                pass
            self._valkey_task = None

        # Step 2: Remove PID file
        _remove_pid_file()

        # Step 3: Close MCP listener
        if self._mcp_server is not None:
            try:
                if hasattr(self._mcp_server, "close"):
                    await self._mcp_server.close()
                elif hasattr(self._mcp_server, "shutdown"):
                    await self._mcp_server.shutdown()
            except Exception as exc:
                logger.error("error closing MCP server: %s", exc)
            self._mcp_server = None

        logger.info("nexus mcp-server: stopped")

    async def _dispatch_tool(self, tool_name: str, args: dict) -> dict:
        """Validate auth and route to tool handler.

        Called for every incoming MCP tool request.

        Sequence:
        1. Extract `secret` from args.
        2. Call self._auth.verify(secret) — raises MCPAuthError on failure.
        3. Check NEXUS_MCP_DEPTH per-request.
        4. Route to tool handler by tool_name.

        Returns
        -------
        dict
            JSON-serializable response dict from tool handler.

        Raises
        ------
        MCPAuthError
            When secret validation fails.
        MCPToolError
            When tool handler raises or tool_name is unknown.
        MCPDepthError
            When NEXUS_MCP_DEPTH >= max_depth at dispatch time.
        """
        # Step 1+2: Auth validation — MUST happen before any tool logic
        provided_secret = args.get("secret", "")
        try:
            self._auth.verify(provided_secret)
        except MCPAuthError:
            auth_logger = logging.getLogger("nexus_sdlc.mcp_server.auth")
            auth_logger.warning(
                "auth failure for tool '%s'", tool_name
            )
            raise

        # Step 3: Per-request depth check — read before incrementing
        current_depth = int(os.environ.get("NEXUS_MCP_DEPTH", "0"))
        if current_depth >= self._max_depth:
            raise MCPDepthError(
                f"nexus: MCP circular invocation detected (depth={current_depth})"
            )

        # Build tool args without the secret (tools do not re-validate)
        tool_args = {k: v for k, v in args.items() if k != "secret"}
        ctx = self._tool_ctx()

        # Increment depth for the duration of this dispatch so that any nested
        # MCP invocation (e.g. a tool spawning a subprocess that calls nexus)
        # inherits the accumulated depth via os.environ propagation.
        os.environ["NEXUS_MCP_DEPTH"] = str(current_depth + 1)
        try:
            # Step 4: Route to tool handler
            return await self._route_tool(tool_name, tool_args, ctx)
        except (MCPAuthError, MCPDepthError, MCPToolError):
            raise
        except Exception as exc:
            raise MCPToolError(f"tool '{tool_name}' error: {exc}") from exc
        finally:
            # Restore to previous depth (decrement) so concurrent/sequential
            # dispatches in the same process see the correct counter.
            os.environ["NEXUS_MCP_DEPTH"] = str(current_depth)

    async def _route_tool(self, tool_name: str, args: dict, ctx: dict) -> dict:
        """Route to the correct tool handler function."""
        kwargs = dict(args)
        kwargs["_ctx"] = ctx
        # secret is stripped before this call — do NOT pass it to handlers
        kwargs["secret"] = ""  # placeholder; tools ignore this, auth done upstream

        if tool_name == "list_conversations":
            return await conversations.list_conversations(**kwargs)
        elif tool_name == "get_conversation":
            return await conversations.get_conversation(**kwargs)
        elif tool_name == "tail_events":
            # tail_events in conversations.py is the JSONL version;
            # tail_events in system.py is the Valkey-based version.
            # Per spec: system.tail_events(count=10) is the MCP tool.
            return await system.tail_events(**kwargs)
        elif tool_name == "get_workflow_status":
            return await workflow.get_workflow_status(**kwargs)
        elif tool_name == "list_workflows":
            return await workflow.list_workflows(**kwargs)
        elif tool_name == "get_session_state":
            return await session.get_session_state(**kwargs)
        elif tool_name == "get_config":
            return await config_tool.get_config(**kwargs)
        elif tool_name == "health_check":
            return await system.health_check(**kwargs)
        else:
            raise MCPToolError(f"unknown tool: {tool_name}")

    def _register_tools(self) -> None:
        """Register all 8 MCP tools with the MCP SDK server instance.

        Tool signatures must match the MCP SDK tool registration pattern.
        Each tool's `secret: str` parameter is validated inside _dispatch_tool,
        not inside the tool handler itself.

        NOTE: SDK API deviation — if mcp SDK is available, tools are registered
        via its standard API. Otherwise, we fall back to a minimal JSON-RPC
        dispatcher.
        """
        if self._mcp_server is None:
            return

        # Attempt MCP SDK registration
        # NOTE: SDK API deviation — actual registration method depends on SDK version
        try:
            if hasattr(self._mcp_server, "add_tool"):
                self._register_tools_sdk()
            # else: tools are dispatched via _dispatch_tool in the JSON-RPC handler
        except Exception as exc:
            logger.warning("tool registration warning: %s", exc)

    def _register_tools_sdk(self) -> None:
        """Register tools using MCP SDK's add_tool API (if available)."""
        # NOTE: SDK API deviation — the actual signature varies by SDK version.
        # This is a best-effort registration. All 8 tools are registered.
        tool_definitions = [
            {
                "name": "list_conversations",
                "description": "List recent conversation sessions from ConversationRegistry.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "secret": {"type": "string"},
                        "limit": {"type": "integer", "default": 50},
                        "task_id": {"type": "string"},
                    },
                    "required": ["secret"],
                },
            },
            {
                "name": "get_conversation",
                "description": "Return full session record for a specific session UUID.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "secret": {"type": "string"},
                        "session_id": {"type": "string"},
                    },
                    "required": ["secret", "session_id"],
                },
            },
            {
                "name": "tail_events",
                "description": "Return recent events from Valkey stream.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "secret": {"type": "string"},
                        "count": {"type": "integer", "default": 10},
                    },
                    "required": ["secret"],
                },
            },
            {
                "name": "get_workflow_status",
                "description": "Return status of a Temporal workflow via director-bridge.sh.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "secret": {"type": "string"},
                        "workflow_id": {"type": "string"},
                    },
                    "required": ["secret", "workflow_id"],
                },
            },
            {
                "name": "list_workflows",
                "description": "List recent Temporal workflows via director-bridge.sh.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "secret": {"type": "string"},
                        "limit": {"type": "integer", "default": 20},
                        "status_filter": {"type": "string"},
                    },
                    "required": ["secret"],
                },
            },
            {
                "name": "get_session_state",
                "description": "Read .nexus/session-state.md from the given project directory.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "secret": {"type": "string"},
                        "project_dir": {"type": "string"},
                    },
                    "required": ["secret", "project_dir"],
                },
            },
            {
                "name": "get_config",
                "description": "Read Nexus configuration with secret redaction.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "secret": {"type": "string"},
                        "project_dir": {"type": "string"},
                        "keys": {"type": "array", "items": {"type": "string"}},
                    },
                    "required": ["secret", "project_dir"],
                },
            },
            {
                "name": "health_check",
                "description": "Check health of Nexus system components.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "secret": {"type": "string"},
                    },
                    "required": ["secret"],
                },
            },
        ]

        for tool_def in tool_definitions:
            try:
                self._mcp_server.add_tool(
                    tool_def["name"],
                    tool_def["description"],
                    tool_def["parameters"],
                )
            except Exception as exc:
                logger.debug("add_tool %s: %s", tool_def["name"], exc)

    async def _start_mcp_server(self) -> None:
        """Create and start the MCP SDK server, or fall back to raw JSON-RPC.

        Host is hardcoded to 127.0.0.1. No override path.
        """
        # Try MCP SDK first
        try:
            from mcp.server import Server  # type: ignore[import]
            from mcp.server.stdio import stdio_server  # type: ignore[import]

            # NOTE: SDK API deviation — the exact MCP SDK server API may differ.
            # We construct the server and use stdio transport for Claude Code compatibility.
            # The host binding constraint (127.0.0.1 only) is enforced at the TCP layer
            # when using network transport. stdio transport is localhost-only by nature.
            self._mcp_server = Server("nexus-sdlc")
            self._register_tools()
            logger.info(
                "nexus mcp-server: MCP SDK server created (host=%s, port=%d)",
                _HOST, self._port,
            )
            # NOTE: SDK API deviation — actual serve call depends on transport type.
            # For TCP transport, bind to 127.0.0.1 only.
            if hasattr(self._mcp_server, "run_tcp"):
                # NOTE: SDK API deviation — host MUST be _HOST (127.0.0.1)
                await self._mcp_server.run_tcp(host=_HOST, port=self._port)
            else:
                # SDK uses stdio or websocket transport — those are localhost-only
                logger.info(
                    "nexus mcp-server: using non-TCP MCP transport "
                    "(stdio/websocket — localhost-only)"
                )
        except ImportError:
            # MCP SDK not installed — fall back to raw asyncio JSON-RPC server
            logger.info(
                "nexus mcp-server: mcp SDK not available, using raw asyncio JSON-RPC server"
            )
            await self._start_raw_jsonrpc_server()
        except Exception as exc:
            logger.error("MCP SDK server error: %s", exc)
            raise

    async def _start_raw_jsonrpc_server(self) -> None:
        """Fallback: raw asyncio TCP JSON-RPC 2.0 server bound to 127.0.0.1."""

        async def handle_client(
            reader: asyncio.StreamReader, writer: asyncio.StreamWriter
        ) -> None:
            try:
                while True:
                    line = await reader.readline()
                    if not line:
                        break
                    try:
                        request = json.loads(line.decode())
                    except json.JSONDecodeError:
                        writer.write(
                            json.dumps({
                                "jsonrpc": "2.0",
                                "id": None,
                                "error": {"code": -32700, "message": "Parse error"},
                            }).encode() + b"\n"
                        )
                        await writer.drain()
                        continue

                    req_id = request.get("id")
                    method = request.get("method", "")
                    params = request.get("params", {})

                    # Handle tools/call JSON-RPC method
                    if method == "tools/call":
                        tool_name = params.get("name", "")
                        tool_args = params.get("arguments", {})
                        try:
                            result = await self._dispatch_tool(tool_name, tool_args)
                            response = {
                                "jsonrpc": "2.0",
                                "id": req_id,
                                "result": result,
                            }
                        except MCPAuthError:
                            response = {
                                "jsonrpc": "2.0",
                                "id": req_id,
                                "error": {"code": -32001, "message": "unauthorized"},
                            }
                        except MCPToolError as exc:
                            response = {
                                "jsonrpc": "2.0",
                                "id": req_id,
                                "error": {"code": -32002, "message": str(exc)},
                            }
                        except MCPDepthError as exc:
                            response = {
                                "jsonrpc": "2.0",
                                "id": req_id,
                                "error": {"code": -32003, "message": str(exc)},
                            }
                        except Exception as exc:
                            response = {
                                "jsonrpc": "2.0",
                                "id": req_id,
                                "error": {"code": -32000, "message": str(exc)},
                            }
                    elif method == "tools/list":
                        response = {
                            "jsonrpc": "2.0",
                            "id": req_id,
                            "result": {
                                "tools": [
                                    "list_conversations", "get_conversation", "tail_events",
                                    "get_workflow_status", "list_workflows", "get_session_state",
                                    "get_config", "health_check",
                                ]
                            },
                        }
                    else:
                        response = {
                            "jsonrpc": "2.0",
                            "id": req_id,
                            "error": {"code": -32601, "message": f"Method not found: {method}"},
                        }

                    writer.write(json.dumps(response).encode() + b"\n")
                    await writer.drain()
            except (ConnectionResetError, asyncio.IncompleteReadError):
                pass
            finally:
                writer.close()

        # Bind to 127.0.0.1 ONLY — no config path, no env var override for host
        server = await asyncio.start_server(
            handle_client,
            host=_HOST,  # hardcoded — no config path or env var override for host
            port=self._port,
        )
        self._mcp_server = server
        logger.info(
            "nexus mcp-server (raw JSON-RPC): listening on %s:%d", _HOST, self._port
        )
