"""MCPAuthMiddleware — NEXUS_MCP_SECRET constant-time validation."""

import hmac

from nexus_sdlc.exceptions import MCPAuthError


class MCPAuthMiddleware:
    """Validates NEXUS_MCP_SECRET on every MCP request.

    Uses hmac.compare_digest for constant-time comparison.
    Must be called before any tool logic — the server dispatcher
    invokes this before routing to tool handlers.

    Raises MCPAuthError if secret is missing, empty, or does not match.
    Never logs the provided secret value.
    """

    def __init__(self, expected_secret: str) -> None:
        """
        Parameters
        ----------
        expected_secret : str
            The NEXUS_MCP_SECRET value loaded at server startup.
            Must not be empty. Raises ValueError if empty string.
        """
        if not expected_secret:
            raise ValueError("expected_secret must not be empty")
        # Store as bytes for constant-time comparison; never log this value.
        self._expected: bytes = expected_secret.encode()

    def verify(self, provided: str) -> None:
        """Verify that `provided` matches the expected secret.

        Parameters
        ----------
        provided : str
            The secret value from the MCP tool call's `secret` parameter.

        Raises
        ------
        MCPAuthError
            Always when provided does not match expected, including when
            provided is empty string or None.
        """
        if not provided:
            raise MCPAuthError("authentication failed")
        try:
            provided_bytes = provided.encode()
        except AttributeError:
            # provided was not a string — treat as authentication failure
            raise MCPAuthError("authentication failed")
        if not hmac.compare_digest(provided_bytes, self._expected):
            raise MCPAuthError("authentication failed")
