"""
nexus_sdlc.subprocess_launcher.launcher — SubprocessLauncher.

CRITICAL INVARIANTS (verified by INV-01, INV-02, INV-04):
  - AR-1: CLAUDECODE stripped with a single .pop("CLAUDECODE", None) in __init__.
          No conditional check, no second strip site anywhere.
  - AR-7: NEXUS_CLI=1 set in __init__ before any spawn.
  - AR-2: asyncio.create_subprocess_exec — shell=True NEVER used.
"""
from __future__ import annotations

import asyncio
import logging
import os
import shutil
import signal
from pathlib import Path
from typing import TYPE_CHECKING

from nexus_sdlc.exceptions import ConfigError, SubprocessError, SubprocessNotFound

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)

_CLAUDE_BINARY = "claude"
_SIGTERM_WAIT_SECONDS = 2.0
_DEFAULT_BUFFER_MB = 10
_BUFFER_MB_MIN = 1
_BUFFER_MB_MAX = 100


class SubprocessLauncher:
    """
    Wraps asyncio.create_subprocess_exec to launch ``claude -p --output-format
    stream-json`` subprocesses.

    CRITICAL: ``CLAUDECODE`` env var MUST be stripped in ``__init__``, not at
    call sites — AR-1 enforcement point.  Single pop() call, unconditional.

    ``NEXUS_CLI=1`` MUST be set in the child environment before any spawn —
    AR-7 enforcement point (recursion guard).

    Parameters
    ----------
    project_dir:
        Working directory injected into every spawn call (used as default cwd).
    buffer_mb:
        Stream buffer ceiling in MB.  If None, falls back to
        ``NEXUS_STREAM_BUFFER_MB`` env var, then defaults to 10.  Clamped
        to [1, 100].
    """

    def __init__(
        self,
        project_dir: str | Path,
        *,
        buffer_mb: int | None = None,
    ) -> None:
        self._project_dir = str(project_dir)

        # ----------------------------------------------------------------
        # Build base environment — AR-1 + AR-7
        # ----------------------------------------------------------------
        self._base_env: dict[str, str] = os.environ.copy()
        self._base_env.pop("CLAUDECODE", None)          # AR-1: single pop, unconditional
        self._base_env["NEXUS_CLI"] = "1"               # AR-7: recursion guard

        # ----------------------------------------------------------------
        # Buffer: NEXUS_STREAM_BUFFER_MB -> clamp 1-100 -> default 10
        # ----------------------------------------------------------------
        raw_mb: int
        if buffer_mb is not None:
            raw_mb = buffer_mb
        else:
            raw_env = os.environ.get("NEXUS_STREAM_BUFFER_MB", str(_DEFAULT_BUFFER_MB))
            try:
                raw_mb = int(raw_env)
            except ValueError as exc:
                raise ConfigError(
                    f"NEXUS_STREAM_BUFFER_MB={raw_env!r} is not a valid integer"
                ) from exc

        clamped = max(_BUFFER_MB_MIN, min(_BUFFER_MB_MAX, raw_mb))
        if clamped != raw_mb:
            logger.warning(
                "NEXUS_STREAM_BUFFER_MB=%d clamped to %d (range [%d, %d])",
                raw_mb,
                clamped,
                _BUFFER_MB_MIN,
                _BUFFER_MB_MAX,
            )
        self._buffer_bytes: int = clamped * 1024 * 1024

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def spawn(
        self,
        session_id: str,
        prompt: str,
        *,
        cwd: str | None = None,
    ) -> asyncio.subprocess.Process:
        """
        Spawn one ``claude`` subprocess for the given session UUID.

        Uses ``asyncio.create_subprocess_exec`` — AR-2 (shell=True never used).

        Parameters
        ----------
        session_id:
            UUID4 string identifying this conversation.  Passed as
            ``NEXUS_SESSION_ID`` env var to the child for correlation.
        prompt:
            The prompt string forwarded to ``claude -p``.
        cwd:
            Working directory for the subprocess.  Defaults to project_dir.

        Raises
        ------
        SubprocessNotFound:
            claude binary not found on PATH or exits non-zero on preflight.
        SubprocessError:
            Any other launch failure.
        """
        working_dir = cwd or self._project_dir

        # Per-spawn env copy — never mutate _base_env by reference
        env = self._base_env.copy()
        env["NEXUS_SESSION_ID"] = session_id

        cmd = [
            _CLAUDE_BINARY,
            "-p",
            "--verbose",
            "--output-format",
            "stream-json",
            "--",
            prompt,
        ]

        logger.debug(
            "Spawning claude subprocess: session=%s cwd=%s", session_id, working_dir
        )

        try:
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=env,
                cwd=working_dir,
                limit=self._buffer_bytes,
            )
        except FileNotFoundError as exc:
            raise SubprocessNotFound(
                "claude binary not found on PATH. "
                "Install Claude Code and ensure it is on your PATH."
            ) from exc
        except OSError as exc:
            raise SubprocessError(
                f"Failed to launch claude subprocess: {exc}"
            ) from exc

        logger.debug("claude subprocess started: pid=%s session=%s", process.pid, session_id)
        return process

    async def terminate(self, process: asyncio.subprocess.Process) -> None:
        """
        Graceful termination: SIGTERM -> 2 s grace period -> SIGKILL.

        CRAWL Gap 1 implementation — prevents zombie processes on tab close.

        Does nothing if the process has already exited.
        """
        if process.returncode is not None:
            logger.debug("Process pid=%s already exited (rc=%s)", process.pid, process.returncode)
            return

        pid = process.pid
        logger.debug("Sending SIGTERM to pid=%s", pid)
        try:
            process.send_signal(signal.SIGTERM)
        except ProcessLookupError:
            logger.debug("Process pid=%s already gone before SIGTERM", pid)
            return

        try:
            await asyncio.wait_for(process.wait(), timeout=_SIGTERM_WAIT_SECONDS)
            logger.debug("Process pid=%s exited cleanly after SIGTERM", pid)
        except asyncio.TimeoutError:
            logger.warning(
                "Process pid=%s did not exit within %.1fs — sending SIGKILL",
                pid,
                _SIGTERM_WAIT_SECONDS,
            )
            try:
                process.send_signal(signal.SIGKILL)
            except ProcessLookupError:
                logger.debug("Process pid=%s gone before SIGKILL", pid)
                return
            await process.wait()
            logger.debug("Process pid=%s killed with SIGKILL", pid)

    async def preflight_claude(self) -> None:
        """
        Verify that the ``claude`` binary exists and is authenticated.

        Runs ``claude --version`` in a subprocess (no shell=True).

        CRAWL Gap 6 implementation.

        Raises
        ------
        SubprocessNotFound:
            claude binary missing from PATH, or exits non-zero (unauthenticated).
        """
        if shutil.which(_CLAUDE_BINARY) is None:
            raise SubprocessNotFound(
                "claude binary not found on PATH. "
                "Install Claude Code: https://claude.ai/download"
            )

        try:
            proc = await asyncio.create_subprocess_exec(
                _CLAUDE_BINARY,
                "--version",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=self._base_env.copy(),
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=10.0)
        except FileNotFoundError as exc:
            raise SubprocessNotFound(
                "claude binary not found on PATH."
            ) from exc
        except asyncio.TimeoutError as exc:
            raise SubprocessNotFound(
                "claude --version timed out — claude may be unauthenticated or frozen."
            ) from exc
        except OSError as exc:
            raise SubprocessNotFound(
                f"Failed to run claude --version: {exc}"
            ) from exc

        if proc.returncode != 0:
            stderr_text = stderr.decode(errors="replace").strip()
            raise SubprocessNotFound(
                f"claude --version exited {proc.returncode}. "
                f"Claude may not be authenticated. stderr: {stderr_text}"
            )

        version_text = stdout.decode(errors="replace").strip()
        logger.debug("claude preflight OK: %s", version_text)

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def buffer_bytes(self) -> int:
        """Stream buffer ceiling in bytes."""
        return self._buffer_bytes

    @property
    def project_dir(self) -> str:
        """Project directory used as the default cwd for spawned processes."""
        return self._project_dir
