"""
nexus_sdlc.subprocess_launcher.stream_reader — StreamJsonReader.

CRAWL Gap 5: partial lines MUST be accumulated across reads, never discarded.

Design:
- Reads raw bytes from the asyncio StreamReader in chunks.
- Maintains a bytearray buffer; splits on b'\\n'.
- Applies ANSI escape sanitization to each line text before json.loads.
- Skips malformed JSON with a warning (does not raise).
- Yields parsed dicts.
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
from typing import AsyncIterator

logger = logging.getLogger(__name__)

_CHUNK_SIZE = 4096  # bytes per read call


class StreamJsonReader:
    """
    Line-buffered reader for ``claude --output-format stream-json`` output.

    ANSI escape codes are stripped before JSON parsing so that terminal colour
    codes injected by claude do not corrupt the JSON payload.

    Partial lines spanning chunk boundaries are accumulated in an internal
    bytearray until the newline arrives — CRAWL Gap 5 compliance.
    """

    # Matches common ANSI CSI sequences: ESC [ <params> <final-byte>
    ANSI_ESCAPE_RE: re.Pattern[str] = re.compile(r"\x1b\[[0-9;]*[mGKH]")

    async def read_lines(
        self,
        stream: asyncio.StreamReader,
        *,
        buffer_bytes: int,
    ) -> AsyncIterator[dict]:  # type: ignore[override]
        """
        Asynchronously yield parsed JSON objects from *stream*.

        Parameters
        ----------
        stream:
            The ``asyncio.StreamReader`` attached to the subprocess stdout.
        buffer_bytes:
            Maximum number of bytes to hold in the internal line buffer.
            If a single line exceeds this, a warning is logged and the
            oversized partial line is discarded (rare in practice given
            stream-json lines are compact).

        Yields
        ------
        dict:
            Parsed stream-json event objects.  Malformed lines are logged
            and skipped — never raised as exceptions.
        """
        buf = bytearray()

        while True:
            try:
                chunk: bytes = await stream.read(_CHUNK_SIZE)
            except Exception as exc:  # noqa: BLE001
                logger.warning("StreamJsonReader: read error — %s", exc)
                break

            if not chunk:
                # EOF
                break

            buf.extend(chunk)

            # Guard against runaway buffers (e.g. a line without a newline)
            if len(buf) > buffer_bytes:
                logger.warning(
                    "StreamJsonReader: buffer exceeded %d bytes — discarding %d bytes",
                    buffer_bytes,
                    len(buf),
                )
                buf.clear()
                continue

            # Process all complete lines in the buffer
            while b"\n" in buf:
                newline_idx = buf.index(b"\n")
                raw_line = bytes(buf[:newline_idx])
                buf = buf[newline_idx + 1 :]

                parsed = self._parse_line(raw_line)
                if parsed is not None:
                    yield parsed

        # Process any remaining bytes after EOF (no trailing newline)
        if buf:
            parsed = self._parse_line(bytes(buf))
            if parsed is not None:
                yield parsed

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _parse_line(self, raw: bytes) -> dict | None:
        """
        Decode, ANSI-sanitize, and JSON-parse a single line.

        Returns None (with a warning log) for blank lines or malformed JSON.
        """
        text = raw.decode("utf-8", errors="replace").strip()
        if not text:
            return None

        # ANSI sanitization before json.loads — AR-20 compliance
        text = self.ANSI_ESCAPE_RE.sub("", text)

        if not text:
            return None

        try:
            result = json.loads(text)
        except json.JSONDecodeError as exc:
            logger.warning(
                "StreamJsonReader: skipping malformed JSON line (%s): %r",
                exc,
                text[:120],
            )
            return None

        if not isinstance(result, dict):
            logger.warning(
                "StreamJsonReader: skipping non-dict JSON value: %r", text[:120]
            )
            return None

        return result
