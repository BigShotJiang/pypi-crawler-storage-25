"""
nexus_sdlc.subprocess_launcher.lifecycle — ProcessLifecycleManager.

Thin coordination layer that ties SubprocessLauncher + StreamJsonReader
together for a single session: spawn, stream, terminate.

Consumers (e.g. TUI conversation tab, CLI run command) use this class
rather than calling SubprocessLauncher and StreamJsonReader directly.
"""
from __future__ import annotations

import asyncio
import logging
from typing import AsyncIterator, Callable, Awaitable

from nexus_sdlc.subprocess_launcher.launcher import SubprocessLauncher
from nexus_sdlc.subprocess_launcher.stream_reader import StreamJsonReader
from nexus_sdlc.exceptions import SubprocessError

logger = logging.getLogger(__name__)


class ProcessLifecycleManager:
    """
    Manages the full lifecycle of a single ``claude`` subprocess session.

    Responsibilities:
    - Spawn subprocess via SubprocessLauncher.
    - Stream stdout via StreamJsonReader, yielding parsed dicts.
    - Capture stderr for error reporting.
    - Terminate subprocess cleanly on context exit or explicit stop.
    - Expose is_running / pid properties.

    Usage::

        mgr = ProcessLifecycleManager(launcher, reader, session_id="<uuid>")
        async with mgr.run(prompt, cwd="/path/to/project") as events:
            async for event in events:
                process(event)
    """

    def __init__(
        self,
        launcher: SubprocessLauncher,
        reader: StreamJsonReader | None = None,
    ) -> None:
        self._launcher = launcher
        self._reader = reader or StreamJsonReader()
        self._process: asyncio.subprocess.Process | None = None

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def is_running(self) -> bool:
        """True if a subprocess has been spawned and has not yet exited."""
        return (
            self._process is not None
            and self._process.returncode is None
        )

    @property
    def pid(self) -> int | None:
        """PID of the active subprocess, or None if not running."""
        if self._process is not None:
            return self._process.pid
        return None

    # ------------------------------------------------------------------
    # Primary interface
    # ------------------------------------------------------------------

    async def run(
        self,
        session_id: str,
        prompt: str,
        *,
        cwd: str | None = None,
        on_event: Callable[[dict], Awaitable[None]] | None = None,
    ) -> None:
        """
        Spawn a subprocess, stream all events, and return.

        If *on_event* is provided it is awaited for every parsed event dict.
        Otherwise events are silently consumed (useful when the caller only
        needs side effects via on_event or just wants process exit).

        Ensures the subprocess is terminated even if an exception is raised
        mid-stream.
        """
        if self.is_running:
            raise SubprocessError(
                f"ProcessLifecycleManager already has a running process (pid={self.pid}). "
                "Call stop() before launching a new subprocess."
            )

        self._process = await self._launcher.spawn(session_id, prompt, cwd=cwd)
        assert self._process.stdout is not None, "subprocess stdout must be PIPE"

        try:
            async for event in self._reader.read_lines(
                self._process.stdout,
                buffer_bytes=self._launcher.buffer_bytes,
            ):
                if on_event is not None:
                    await on_event(event)
        finally:
            await self._launcher.terminate(self._process)

    async def stop(self) -> None:
        """Terminate the active subprocess if running."""
        if self._process is not None:
            await self._launcher.terminate(self._process)

    async def stream_events(
        self,
        session_id: str,
        prompt: str,
        *,
        cwd: str | None = None,
    ) -> AsyncIterator[dict]:
        """
        Async generator variant — yields parsed event dicts.

        Terminates the subprocess on StopAsyncIteration or any exception.
        """
        if self.is_running:
            raise SubprocessError(
                f"ProcessLifecycleManager already has a running process (pid={self.pid})."
            )

        self._process = await self._launcher.spawn(session_id, prompt, cwd=cwd)
        assert self._process.stdout is not None, "subprocess stdout must be PIPE"

        try:
            async for event in self._reader.read_lines(
                self._process.stdout,
                buffer_bytes=self._launcher.buffer_bytes,
            ):
                yield event
        finally:
            await self._launcher.terminate(self._process)
