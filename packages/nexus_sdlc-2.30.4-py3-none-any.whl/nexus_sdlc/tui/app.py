"""
nexus_sdlc.tui.app — NexusTUIApp(App), the Nexus 8-tab terminal interface.

Architecture
------------
Single-screen layout: NexusTUIApp composes TabbedContent (8 panes) + StatusBar
directly.  There is no separate Screen subclass — this is idiomatic Textual for
sibling views that share persistent chrome (StatusBar, F-key bindings).

See: nexus-cli-tui-001-arch-frontend.md §1.1 for rationale.

Anti-requirements enforced
--------------------------
TUI-1: No asyncio.run() anywhere in this file.
TUI-2: ValkeyConsumer buffer drained only in _valkey_poll_loop() (asyncio task).
TUI-3: ConversationRegistry instantiated exactly once in on_mount().
TUI-4: No signal.signal(SIGTERM, ...) in this file.
TUI-8: All F-key and Ctrl+digit/Ctrl+T/Ctrl+W bindings have priority=True.
"""
from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import TYPE_CHECKING

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.reactive import reactive
from textual.widgets import Static, TabbedContent, TabPane

from nexus_sdlc.config.loader import NexusConfigLoader
from nexus_sdlc.exceptions import SubprocessNotFound
from nexus_sdlc.registry.conversation_registry import ConversationRegistry
from nexus_sdlc.tui.messages import ValkeyDegradedDetected, ValkeyEventReceived
from nexus_sdlc.tui.widgets.status_bar import StatusBar
from nexus_sdlc.valkey_consumer.consumer import ValkeyConsumer

# ---------------------------------------------------------------------------
# Optional tab imports — parallel agents (Agent 2 + 3) own these files.
# Guard with try/except so AC-1 ("from nexus_sdlc.tui.app import NexusTUIApp")
# succeeds even before the tab modules are created.
# ---------------------------------------------------------------------------

try:
    from nexus_sdlc.tui.tabs.conversation import ConversationTab
except ImportError:  # pragma: no cover
    ConversationTab = None  # type: ignore[assignment, misc]

try:
    from nexus_sdlc.tui.tabs.pipeline import PipelineTab
except ImportError:  # pragma: no cover
    PipelineTab = None  # type: ignore[assignment, misc]

try:
    from nexus_sdlc.tui.tabs.workspace import WorkspaceTab
except ImportError:  # pragma: no cover
    WorkspaceTab = None  # type: ignore[assignment, misc]

try:
    from nexus_sdlc.tui.tabs.agent_monitor import AgentMonitorTab
except ImportError:  # pragma: no cover
    AgentMonitorTab = None  # type: ignore[assignment, misc]

try:
    from nexus_sdlc.tui.tabs.perception import PerceptionTab
except ImportError:  # pragma: no cover
    PerceptionTab = None  # type: ignore[assignment, misc]

try:
    from nexus_sdlc.tui.tabs.memory import MemoryTab
except ImportError:  # pragma: no cover
    MemoryTab = None  # type: ignore[assignment, misc]

try:
    from nexus_sdlc.tui.tabs.health import HealthTab
except ImportError:  # pragma: no cover
    HealthTab = None  # type: ignore[assignment, misc]

try:
    from nexus_sdlc.tui.tabs.config import ConfigTab
except ImportError:  # pragma: no cover
    ConfigTab = None  # type: ignore[assignment, misc]

try:
    from nexus_sdlc.subprocess_launcher.launcher import SubprocessLauncher
except ImportError:  # pragma: no cover
    SubprocessLauncher = None  # type: ignore[assignment, misc]

if TYPE_CHECKING:
    from nexus_sdlc.tui.tabs.conversation import ConversationTab as ConversationTabType

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# CSS path — Agent 3 creates nexus.css; graceful if absent during parallel build
# ---------------------------------------------------------------------------

_CSS_PATH = Path(__file__).parent / "css" / "nexus.css"


def _make_placeholder(label: str) -> Static:
    """Return a Static widget placeholder for tabs not yet built by parallel agents."""
    return Static(f"[dim]{label} (not yet available)[/dim]")


# ---------------------------------------------------------------------------
# NexusTUIApp
# ---------------------------------------------------------------------------


class NexusTUIApp(App):
    """Nexus TUI — 8-tab terminal interface.

    Holds single instances of ConversationRegistry and ValkeyConsumer.
    All tabs access shared infrastructure via self.app.registry and
    self.app.consumer.
    """

    CSS_PATH = _CSS_PATH if _CSS_PATH.exists() else None  # type: ignore[assignment]

    # TUI-8: ALL F-key and Ctrl+digit/Ctrl+T/Ctrl+W bindings MUST have priority=True
    # so that Input widgets do not capture them when focused.
    BINDINGS = [
        # F1–F8: tab switching (priority=True enforced by TUI-8)
        Binding("f1", "switch_tab('conversations')", "Conversations", priority=True),
        Binding("f2", "switch_tab('pipeline')", "Pipeline", priority=True),
        Binding("f3", "switch_tab('workspace')", "Workspace", priority=True),
        Binding("f4", "switch_tab('agents')", "Agents", priority=True),
        Binding("f5", "switch_tab('perception')", "Perception", priority=True),
        Binding("f6", "switch_tab('memory')", "Memory", priority=True),
        Binding("f7", "switch_tab('health')", "Health", priority=True),
        Binding("f8", "switch_tab('config')", "Config", priority=True),
        # macOS alias: Ctrl+1–8 (show=False — not displayed in help bar)
        Binding("ctrl+1", "switch_tab('conversations')", show=False, priority=True),
        Binding("ctrl+2", "switch_tab('pipeline')", show=False, priority=True),
        Binding("ctrl+3", "switch_tab('workspace')", show=False, priority=True),
        Binding("ctrl+4", "switch_tab('agents')", show=False, priority=True),
        Binding("ctrl+5", "switch_tab('perception')", show=False, priority=True),
        Binding("ctrl+6", "switch_tab('memory')", show=False, priority=True),
        Binding("ctrl+7", "switch_tab('health')", show=False, priority=True),
        Binding("ctrl+8", "switch_tab('config')", show=False, priority=True),
        # Conversation controls — priority=True so Input does not swallow them
        Binding("ctrl+t", "new_conversation", "New conversation", priority=True),
        Binding("ctrl+w", "close_conversation", "Close conversation", priority=True),
        # Quit — low priority so 'q' remains typeable in Input widgets
        Binding("q", "quit", "Quit", priority=False),
    ]

    # App-level reactive state — shared across all tabs via self.app.*
    # Drives StatusBar re-renders and tab badge updates.
    _perception_badge_count: reactive[int] = reactive(0)
    _pipeline_error_flag: reactive[bool] = reactive(False)
    _infra_error_flag: reactive[bool] = reactive(False)
    _wil_today: reactive[float] = reactive(0.0)
    _health_dots: reactive[dict] = reactive(dict)

    def __init__(self, config: NexusConfigLoader) -> None:
        """
        Parameters
        ----------
        config:
            Pre-constructed NexusConfigLoader instance (created by tui_cmd before
            calling app.run()).  Stored as self.config; all tabs access via self.app.config.
        """
        super().__init__()
        self.config = config

        # TUI-3: ConversationRegistry instantiated exactly once — here in __init__
        # so it is available during compose() (which runs before on_mount).
        # register_signal_handler=True — registry owns SIGTERM (TUI-4).
        self.registry = ConversationRegistry(register_signal_handler=True)
        self.registry.load()

        # ValkeyConsumer type annotation — instance created in on_mount after
        # async startup (requires awaiting consumer.start()).
        self.consumer: ValkeyConsumer

        # Bridge poll task handle — created in on_mount, cancelled in on_unmount.
        self._valkey_poll_task: asyncio.Task | None = None

        # Reference to the ConversationTab widget — set in compose() after yield.
        self._conversation_tab: ConversationTabType | None = None  # type: ignore[type-arg]

    # -------------------------------------------------------------------------
    # Layout composition
    # -------------------------------------------------------------------------

    def compose(self) -> ComposeResult:
        """Build the 8-tab layout.  Tabs owned by parallel agents use placeholders
        when their modules are not yet present (for AC-1 import test isolation).
        """
        with TabbedContent(id="main-tabs"):
            with TabPane("F1 Conversations", id="conversations"):
                if ConversationTab is not None:
                    tab = ConversationTab(config=self.config, registry=self.registry)
                    self._conversation_tab = tab
                    yield tab
                else:
                    yield _make_placeholder("Conversations")

            with TabPane("F2 Pipeline", id="pipeline"):
                if PipelineTab is not None:
                    yield PipelineTab(self.config)
                else:
                    yield _make_placeholder("Pipeline")

            with TabPane("F3 Workspace", id="workspace"):
                if WorkspaceTab is not None:
                    yield WorkspaceTab()
                else:
                    yield _make_placeholder("Workspace")

            with TabPane("F4 Agents", id="agents"):
                if AgentMonitorTab is not None:
                    yield AgentMonitorTab()
                else:
                    yield _make_placeholder("Agents")

            with TabPane("F5 Perception", id="perception"):
                if PerceptionTab is not None:
                    yield PerceptionTab()
                else:
                    yield _make_placeholder("Perception")

            with TabPane("F6 Memory", id="memory"):
                if MemoryTab is not None:
                    yield MemoryTab()
                else:
                    yield _make_placeholder("Memory")

            with TabPane("F7 Health", id="health"):
                if HealthTab is not None:
                    yield HealthTab(self.config)
                else:
                    yield _make_placeholder("Health")

            with TabPane("F8 Config", id="config"):
                if ConfigTab is not None:
                    yield ConfigTab(config=self.config)
                else:
                    yield _make_placeholder("Config")

        yield StatusBar(id="status-bar")

    # -------------------------------------------------------------------------
    # Lifecycle: on_mount
    # -------------------------------------------------------------------------

    async def on_mount(self) -> None:
        """App startup — infrastructure instantiation sequence.

        Enforcement:
        - TUI-3: ConversationRegistry instantiated exactly once in __init__ (not here).
        - TUI-4: MUST NOT register SIGTERM handler here; registry owns it.
        - TUI-1: MUST NOT call asyncio.run(); use asyncio.create_task() only.
        """
        # Step 1: ConversationRegistry was instantiated in __init__ (TUI-3: exactly once)
        # so that compose() can pass it to ConversationTab at construction time.
        # Nothing to do here for the registry.

        # Step 2: Instantiate ValkeyConsumer.
        # Graceful degraded start: if Valkey is unreachable, mark degraded and continue.
        valkey_host: str = self.config.get("valkey.host", "localhost")
        valkey_port: int = int(self.config.get("valkey.port", 6379))
        self.consumer = ValkeyConsumer(host=valkey_host, port=valkey_port)
        try:
            await self.consumer.start()
        except Exception as exc:
            logger.warning("ValkeyConsumer failed to start: %s — running in degraded mode", exc)
            self.post_message(ValkeyDegradedDetected())

        # Step 3: Start bridge poll task (TUI-2: drains buffer off render thread).
        self._valkey_poll_task = asyncio.create_task(
            self._valkey_poll_loop(),
            name="valkey-bridge-poll",
        )

        # Step 4: Non-blocking claude preflight (failure posts toast, never crashes app).
        asyncio.create_task(
            self._preflight_claude(),
            name="claude-preflight",
        )

        # Step 5: Restore last-active tab from config.
        last_tab: str = self.config.get("tui.last_tab", "conversations")
        try:
            self.query_one(TabbedContent).active = last_tab
        except Exception:
            logger.debug("Could not restore last tab '%s'", last_tab)

    # -------------------------------------------------------------------------
    # Lifecycle: on_unmount
    # -------------------------------------------------------------------------

    async def on_unmount(self) -> None:
        """App shutdown — teardown sequence (order matters).

        1. Terminate all live claude subprocesses (so final bytes reach registry).
        2. Cancel bridge poll task with 1s timeout.
        3. Stop ValkeyConsumer (drains pending ACKs).

        NOT called: registry._flush() — ConversationRegistry's atexit hook handles
        this on clean Python exit.  SIGTERM is handled by registry._sigterm_handler.
        TUI-4: MUST NOT register a second SIGTERM handler here.
        """
        # Step 1: Terminate all live conversation subprocesses.
        if self._conversation_tab is not None:
            try:
                await self._conversation_tab.terminate_all_sessions()
            except Exception as exc:
                logger.warning("Error during terminate_all_sessions: %s", exc)

        # Step 2: Cancel the bridge poll task.
        if self._valkey_poll_task is not None and not self._valkey_poll_task.done():
            self._valkey_poll_task.cancel()
            try:
                await asyncio.wait_for(
                    asyncio.shield(self._valkey_poll_task), timeout=1.0
                )
            except (asyncio.TimeoutError, asyncio.CancelledError):
                pass

        # Step 3: Stop ValkeyConsumer (drains pending ACKs, closes Redis connection).
        if hasattr(self, "consumer"):
            try:
                await self.consumer.stop()
            except Exception as exc:
                logger.warning("Error stopping ValkeyConsumer: %s", exc)

        # NOTE: Do NOT call self.registry._flush() — atexit handles it.
        # TUI-4: Do NOT register signal.SIGTERM here.

    # -------------------------------------------------------------------------
    # Bridge poll loop (arch-frontend.md §3.2)
    # -------------------------------------------------------------------------

    async def _valkey_poll_loop(self) -> None:
        """Drain ValkeyConsumer buffer; post ValkeyEventReceived per event.

        Polls every 150ms.  Runs as an asyncio.create_task — NOT a thread.
        post_message() is safe to call directly (same event loop as the App).

        TUI-2: This is the ONLY place ValkeyConsumer._buffer is drained.
        """
        POLL_INTERVAL = 0.15  # seconds — below P3 500ms first-token target

        try:
            while True:
                await asyncio.sleep(POLL_INTERVAL)

                # Check degraded transition FIRST — before draining buffer.
                if self.consumer.is_degraded:
                    self.post_message(ValkeyDegradedDetected())
                    return  # Stop polling — consumer will not recover without restart.

                events = await self.consumer.get_events(count=20)
                for event_dict in events:
                    self.post_message(
                        ValkeyEventReceived(
                            stream_id=event_dict.get("__stream_id__", ""),
                            event_type=event_dict.get("__event_type__", ""),
                            payload=event_dict,
                        )
                    )

        except asyncio.CancelledError:
            pass  # Normal shutdown path — swallow and exit cleanly.

    # -------------------------------------------------------------------------
    # Actions (bound to BINDINGS above)
    # -------------------------------------------------------------------------

    def action_switch_tab(self, tab_id: str) -> None:
        """Switch the active TabbedContent pane."""
        try:
            self.query_one(TabbedContent).active = tab_id
        except Exception:
            logger.debug("action_switch_tab: tab '%s' not found", tab_id)

    def action_new_conversation(self) -> None:
        """Open the new-conversation picker in ConversationTab."""
        if self._conversation_tab is not None:
            self._conversation_tab.open_new_conversation_picker()

    def action_close_conversation(self) -> None:
        """Close the currently active conversation in ConversationTab."""
        if self._conversation_tab is not None:
            self._conversation_tab.close_active_conversation()

    # -------------------------------------------------------------------------
    # Preflight: check claude binary availability
    # -------------------------------------------------------------------------

    async def _preflight_claude(self) -> None:
        """Non-blocking claude binary preflight check.

        On SubprocessNotFound: posts sticky error toast and marks ConversationTab
        as unavailable.  Never raises — failure is contained to a toast notification
        so the other 7 tabs continue working (arch-frontend.md §5.6).
        """
        if SubprocessLauncher is None:
            logger.debug("SubprocessLauncher not available — skipping preflight")
            return

        try:
            launcher = SubprocessLauncher(project_dir=Path.cwd())
            await launcher.preflight_claude()

        except SubprocessNotFound as exc:
            # Sticky toast (timeout=0) — user must restart or fix PATH.
            self.notify(
                f"claude not found or unauthenticated: {exc}\n"
                "Run: claude auth",
                severity="error",
                timeout=0,
            )
            if self._conversation_tab is not None:
                try:
                    self._conversation_tab.mark_claude_unavailable(str(exc))
                except Exception:
                    pass

        except asyncio.CancelledError:
            raise  # Always re-raise CancelledError (arch-frontend.md §5.1)

        except Exception as exc:
            logger.exception("Unexpected error in _preflight_claude")
            self.notify(
                f"Claude preflight failed: {exc}",
                severity="warning",
            )
