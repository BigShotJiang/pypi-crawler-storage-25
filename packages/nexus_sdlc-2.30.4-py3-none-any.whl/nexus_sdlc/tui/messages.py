"""
nexus_sdlc.tui.messages — Textual Message classes for the Nexus TUI bridge.

All messages posted between the ValkeyConsumer bridge task and TUI widgets
are defined here.  Do NOT define message classes in individual tab/widget files.

Classes
-------
ValkeyEventReceived     — new Valkey stream event from the bridge poll task
ValkeyDegradedDetected  — one-shot signal that ValkeyConsumer entered degraded state
SessionTokenReceived    — parsed stream-json token from a claude subprocess
HealthUpdate            — infra service health status from HealthTab checker
ConversationTabClosed   — session cleanup signal from ConversationTab
"""
from __future__ import annotations

from textual.message import Message


class ValkeyEventReceived(Message):
    """Fired by the app-level bridge task when a new Valkey stream event is buffered.

    Parameters
    ----------
    stream_id:
        Raw Redis stream entry ID (e.g. "1714500000000-0").
    event_type:
        Semantic event type (e.g. "perception.alert", "pipeline.complete").
    payload:
        Decoded stream fields dict; may include large content blobs.
    """

    def __init__(
        self,
        stream_id: str,
        event_type: str,
        payload: dict,
    ) -> None:
        super().__init__()
        self.stream_id = stream_id
        self.event_type = event_type
        self.payload = payload


class ValkeyDegradedDetected(Message):
    """Fired once when ValkeyConsumer.is_degraded transitions to True.

    No payload — presence of this message IS the signal.  The bridge poll task
    posts this and then exits; no further ValkeyEventReceived messages will arrive.
    Recovery requires a TUI restart.
    """


class SessionTokenReceived(Message):
    """Fired by the stdout reader task when a parsed JSON token arrives from claude subprocess.

    Parameters
    ----------
    session_id:
        UUID of the conversation session that produced this token.
    token_type:
        Stream-JSON type field: "text" | "result" | "error" | "system" | "usage".
    content:
        ANSI-stripped, displayable text content (see TokenStreamWidget.strip_ansi).
    raw_json:
        Full parsed stream-json object — used for token/cost tracking.
    """

    def __init__(
        self,
        session_id: str,
        token_type: str,
        content: str,
        raw_json: dict,
    ) -> None:
        super().__init__()
        self.session_id = session_id
        self.token_type = token_type
        self.content = content
        self.raw_json = raw_json


class HealthUpdate(Message):
    """Fired by HealthTab's interval checker with current infra service status.

    Parameters
    ----------
    service_name:
        One of: "temporal" | "nebula" | "valkey" | "postgres" | "pm".
    status:
        One of: "healthy" | "degraded" | "error" | "unknown".
    latency_ms:
        Round-trip latency in milliseconds, or None if the check timed out.
    """

    def __init__(
        self,
        service_name: str,
        status: str,
        latency_ms: float | None,
    ) -> None:
        super().__init__()
        self.service_name = service_name
        self.status = status
        self.latency_ms = latency_ms


class ConversationTabClosed(Message):
    """Fired by ConversationTab when a sub-tab is closed, for app-level cleanup.

    Parameters
    ----------
    session_id:
        UUID of the session whose tab was closed.
    """

    def __init__(self, session_id: str) -> None:
        super().__init__()
        self.session_id = session_id
