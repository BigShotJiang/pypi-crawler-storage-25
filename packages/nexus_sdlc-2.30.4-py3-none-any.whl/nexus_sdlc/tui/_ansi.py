"""Canonical ANSI escape sequence stripping for the Nexus TUI.

Single sanitization site — all TUI modules import from here.
"""
import re

# Full CSI + Fe escape sequence pattern (broader than SGR-only)
# Covers: CSI sequences (all final bytes @-~), 2-byte Fe sequences (@-Z, \-_)
_ANSI_RE = re.compile(r"\x1B[@-Z\\-_]|\x1B\[[0-?]*[ -/]*[@-~]")


def strip_ansi(text: str) -> str:
    """Remove all ANSI escape sequences from text."""
    return _ANSI_RE.sub("", text)
