"""
nexus_sdlc.tui.widgets.token_stream — TokenStreamWidget.

Wraps Textual RichLog to display stream-json tokens from the claude subprocess.

ANSI sanitization
-----------------
TUI-5: ``strip_ansi()`` is the SINGLE ANSI sanitization site in the TUI.
All code paths that receive raw subprocess output MUST pass through this method
before writing to any RichLog or widget.

The module-level ``_ANSI_RE`` pattern matches ANSI Select Graphic Rendition (SGR)
sequences: ESC [ ... m.  This covers all color and style codes emitted by claude.

Token type → Rich markup map
-----------------------------
"text"   → content rendered as-is
"result" → [bold green]content[/]
"error"  → [bold red]content[/]
"system" → [dim]content[/]
"usage"  → [dim yellow]content[/]
other    → content rendered as-is
"""
from __future__ import annotations

from textual.app import ComposeResult
from textual.widget import Widget
from textual.widgets import RichLog

from nexus_sdlc.tui._ansi import _ANSI_RE, strip_ansi as _strip_ansi_fn


class TokenStreamWidget(Widget):
    """Display widget for claude subprocess stream-json token output.

    Wraps a Textual ``RichLog`` with a max of 2000 lines.  Content is rendered
    with Rich markup enabled; raw ANSI escape codes must be stripped via
    ``strip_ansi()`` before calling ``append_token()`` or ``write()`` directly.

    Usage
    -----
    In ConversationTab's ``on_session_token_received`` handler::

        stream = self.query_one(TokenStreamWidget)
        stream.append_token(message.token_type, message.content)

    ``message.content`` is assumed already ANSI-stripped (done in
    ``ConversationTab._read_stdout()``).  ``append_token`` does not re-sanitize
    to avoid double processing.
    """

    DEFAULT_CSS = """
    TokenStreamWidget {
        height: 1fr;
        width: 100%;
    }
    """

    def compose(self) -> ComposeResult:
        """Yield the inner RichLog."""
        yield RichLog(
            id="token-log",
            highlight=False,
            markup=True,
            max_lines=2000,
        )

    # -------------------------------------------------------------------------
    # Public API
    # -------------------------------------------------------------------------

    def strip_ansi(self, text: str) -> str:
        """Strip ANSI escape codes from *text*.

        TUI-5: This is the SINGLE ANSI sanitization site.  All raw subprocess
        output must pass through here before being written to any RichLog.
        Delegates to the canonical nexus_sdlc.tui._ansi.strip_ansi to ensure
        full CSI coverage (not SGR-only).

        Parameters
        ----------
        text:
            Raw string potentially containing ANSI escape sequences.

        Returns
        -------
        str
            Text with all ANSI escape sequences removed.

        Examples
        --------
        >>> widget.strip_ansi("\\x1b[32mhello\\x1b[0m world")
        'hello world'
        >>> widget.strip_ansi("\\x1b[2J")
        ''
        """
        return _strip_ansi_fn(text)

    def append_token(self, token_type: str, content: str) -> None:
        """Append a stream-json token to the RichLog with type-appropriate markup.

        Parameters
        ----------
        token_type:
            One of "text", "result", "error", "system", "usage", or any other
            string (rendered as-is).
        content:
            Text content to display.  Assumed to be already ANSI-stripped.
            (``ConversationTab._read_stdout`` strips ANSI before posting
            ``SessionTokenReceived``.)
        """
        if token_type == "result":
            formatted = f"[bold green]{content}[/bold green]"
        elif token_type == "error":
            formatted = f"[bold red]{content}[/bold red]"
        elif token_type == "system":
            formatted = f"[dim]{content}[/dim]"
        elif token_type == "usage":
            formatted = f"[dim yellow]{content}[/dim yellow]"
        else:
            # "text" and any unknown types rendered verbatim
            formatted = content

        self.query_one(RichLog).write(formatted)

    def clear(self) -> None:
        """Clear all content from the RichLog."""
        self.query_one(RichLog).clear()
