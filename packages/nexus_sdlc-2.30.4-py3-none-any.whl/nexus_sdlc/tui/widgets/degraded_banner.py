"""
nexus_sdlc.tui.widgets.degraded_banner — DegradedBanner widget.

Mounts at the top of a tab's content area to signal that a service is
degraded or unreachable.

Usage examples
--------------
# Dismissible (default) — user can press D to remove it:
self.mount(DegradedBanner(service="NebulaGraph", message="Memory graph unreachable"))

# Non-dismissible — for states that cannot self-resolve (e.g. Valkey degraded):
self.mount(DegradedBanner(service="Valkey", message="Restart nexus tui to reconnect.", dismissible=False))

Nested message
--------------
``DegradedBanner.Dismissed`` is posted to the parent when the user presses D
(only when dismissible=True).  The widget also removes itself.
"""
from __future__ import annotations

from textual import events
from textual.app import ComposeResult
from textual.message import Message
from textual.widget import Widget
from textual.widgets import Label


class DegradedBanner(Widget):
    """Yellow warning banner indicating a degraded service.

    Parameters
    ----------
    service:
        Name of the degraded service, e.g. "Valkey", "NebulaGraph".
    message:
        Human-readable explanation of the degraded state.
    dismissible:
        If True (default), the user can press D to dismiss and remove the banner.
        Set to False for conditions that cannot self-resolve without a restart.
    """

    DEFAULT_CSS = """
    DegradedBanner {
        height: auto;
        padding: 0 1;
    }
    DegradedBanner.degraded-banner {
        border: solid yellow;
        background: $surface;
    }
    """

    class Dismissed(Message):
        """Fired when the user presses D to dismiss the banner."""

    def __init__(
        self,
        service: str,
        message: str,
        dismissible: bool = True,
    ) -> None:
        super().__init__()
        self._service = service
        self._message = message
        self._dismissible = dismissible
        self.add_class("degraded-banner")

    def compose(self) -> ComposeResult:
        """Render service name + message, optionally with dismiss hint."""
        text = f"[yellow bold]⚠ {self._service} degraded:[/yellow bold] {self._message}"
        if self._dismissible:
            text += " [dim](D to dismiss)[/dim]"
        yield Label(text)

    def on_key(self, event: events.Key) -> None:
        """Handle D keypress for dismissal (only when dismissible=True)."""
        if event.key == "d" and self._dismissible:
            self.post_message(DegradedBanner.Dismissed())
            self.remove()
