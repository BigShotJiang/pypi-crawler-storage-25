"""
nexus_sdlc.tui.widgets.status_bar — StatusBar widget.

Renders the persistent bottom chrome:
  ● T  ● N  ● V  ● P  ◐ PM │ {slug}·workspace │ HH:MM:SS │ WIL: $x.xx/day │ budget: $x.xx │ v{version}

Health dot glyphs
-----------------
● (U+25CF)  healthy   → [green]
⚠ (U+26A0)  degraded  → [yellow]
○ (U+25CB)  unknown   → [dim]

The widget reads app-level reactive state (self.app._health_dots, self.app._wil_today)
so it re-renders whenever those reactives change.
"""
from __future__ import annotations

from datetime import datetime

from textual.app import RenderResult
from textual.widget import Widget


# ---------------------------------------------------------------------------
# Service name → abbreviation map
# ---------------------------------------------------------------------------

_ABBREV: dict[str, str] = {
    "temporal": "T",
    "nebula": "N",
    "valkey": "V",
    "postgres": "P",
    "pm": "PM",
}

# Ordered display sequence
_SERVICE_ORDER = ("temporal", "nebula", "valkey", "postgres", "pm")

# Glyph → Rich markup
_GLYPH_MARKUP: dict[str, str] = {
    "●": "[green]●[/green]",
    "⚠": "[yellow]⚠[/yellow]",
    "○": "[dim]○[/dim]",
}

_DEFAULT_GLYPH = "○"


class StatusBar(Widget):
    """Persistent status bar docked at the bottom of the TUI.

    Reads from app-level reactive attributes:
    - ``self.app._health_dots``   — dict[str, str]: service name → glyph character
    - ``self.app._wil_today``     — float: today's WIL spend in USD
    - ``self.app._perception_badge_count`` — drives F5 badge (not rendered here)

    The clock ticks once per second via ``set_interval(1.0, self.refresh)``.
    """

    DEFAULT_CSS = "StatusBar { dock: bottom; height: 1; width: 100%; }"

    def on_mount(self) -> None:
        """Start 1-second clock tick."""
        self.set_interval(1.0, self.refresh)

    def render(self) -> RenderResult:
        """Build and return the Rich-markup status bar string."""
        # --- Health dots ---
        health_dots: dict[str, str] = {}
        try:
            health_dots = dict(self.app._health_dots)  # type: ignore[attr-defined]
        except AttributeError:
            pass

        dot_parts: list[str] = []
        for service in _SERVICE_ORDER:
            glyph = health_dots.get(service, _DEFAULT_GLYPH)
            markup = _GLYPH_MARKUP.get(glyph, f"[dim]{glyph}[/dim]")
            abbrev = _ABBREV.get(service, service.upper())
            dot_parts.append(f"{markup} {abbrev}")

        dots_str = "  ".join(dot_parts)

        # --- Workspace slug ---
        slug = "nexus"
        try:
            slug = self.app.config.get("workspace.slug", "nexus")  # type: ignore[attr-defined]
        except Exception:
            pass

        # --- Clock ---
        now = datetime.now().strftime("%H:%M:%S")

        # --- WIL budget ---
        wil_today: float = 0.0
        try:
            wil_today = float(self.app._wil_today)  # type: ignore[attr-defined]
        except (AttributeError, TypeError, ValueError):
            pass

        budget: float = 10.0
        try:
            budget = float(self.app.config.get("tui.daily_budget_usd", 10.0))  # type: ignore[attr-defined]
        except Exception:
            pass

        # WIL color: yellow if > 80% of budget, red if > 95%
        if wil_today > budget * 0.95:
            wil_markup = f"[bold red]WIL: ${wil_today:.2f}/day[/bold red]"
        elif wil_today > budget * 0.80:
            wil_markup = f"[yellow]WIL: ${wil_today:.2f}/day[/yellow]"
        else:
            wil_markup = f"WIL: ${wil_today:.2f}/day"

        budget_markup = f"budget: ${budget:.2f}"

        # --- Version ---
        version = "unknown"
        try:
            from nexus_sdlc import __version__  # type: ignore[attr-defined]
            version = __version__
        except Exception:
            try:
                # Fallback: read from pyproject.toml not available at runtime;
                # use importlib.metadata
                import importlib.metadata
                version = importlib.metadata.version("nexus-sdlc")
            except Exception:
                pass

        return (
            f" {dots_str} │ {slug}·workspace │ {now} │ {wil_markup} │ {budget_markup} │ v{version}"
        )
