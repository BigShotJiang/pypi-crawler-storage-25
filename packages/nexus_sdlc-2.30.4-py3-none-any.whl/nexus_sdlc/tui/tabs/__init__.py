"""
nexus_sdlc.tui.tabs — TUI tab widgets for the Nexus CLI TUI.

Exports
-------
ConversationTab   — multi-session conversation manager (F1)
PipelineTab       — pipeline status with 15s polling (F2)
WorkspaceTab      — workspace project card grid (F3)
AgentMonitorTab   — live agent activity feed (F4)
PerceptionTab     — perception event queue with badge (F5)
MemoryTab         — NebulaGraph memory browser (F6)
HealthTab         — infrastructure health with 30s checks (F7)
ConfigTab         — read-only configuration viewer, TUI-6 (F8)
"""
from nexus_sdlc.tui.tabs.conversation import ConversationTab
from nexus_sdlc.tui.tabs.pipeline import PipelineTab
from nexus_sdlc.tui.tabs.agent_monitor import AgentMonitorTab
from nexus_sdlc.tui.tabs.workspace import WorkspaceTab
from nexus_sdlc.tui.tabs.perception import PerceptionTab
from nexus_sdlc.tui.tabs.memory import MemoryTab
from nexus_sdlc.tui.tabs.health import HealthTab
from nexus_sdlc.tui.tabs.config import ConfigTab

__all__ = [
    "ConversationTab",
    "PipelineTab",
    "AgentMonitorTab",
    "WorkspaceTab",
    "PerceptionTab",
    "MemoryTab",
    "HealthTab",
    "ConfigTab",
]
