"""
nexus_sdlc.tui.tabs.conversation — Multi-session conversation tab.

Manages a set of named conversation sessions, each backed by a ``claude``
subprocess launched via SubprocessLauncher.  Renders per-session token
streams, status glyphs, and usage tracking.

Architecture constraints
------------------------
AR-1: CLAUDECODE stripped by SubprocessLauncher.__init__ — not here.
AR-2: asyncio.create_subprocess_exec via SubprocessLauncher.spawn — no shell=True.
AR-7: NEXUS_CLI=1 set by SubprocessLauncher — not here.
AR-19: No sync I/O on the event loop — all subprocess I/O in async tasks.
C-1:   Use set_interval for periodic tasks — no while-True/asyncio.sleep loops.
TUI-4: ConversationRegistry owns SIGTERM — do NOT register a second handler here.
TUI-5: ANSI codes stripped before posting SessionTokenReceived.
TUI-7: One SubprocessLauncher per project_dir (not per session UUID) — keyed
       by str(project_dir) in _launchers dict.
CRAWL Gap 5: Accumulate bytes until \\n before JSON parsing.

Session status glyphs (arch-tui Section 3):
  ●  running   (cyan)
  ◐  streaming (blue)
  ○  idle      (dim)
  ⚠  error     (red)
  ✓  success   (green)

ConversationSession
-------------------
A dataclass holding the per-session mutable state.  The SubprocessLauncher
instance is shared across all sessions with the same project_dir (TUI-7);
the process handle and reader_task are exclusive per session.
"""
from __future__ import annotations

import asyncio
import json
import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING

from rich.markup import escape as markup_escape
from textual.app import ComposeResult
from textual.widget import Widget
from textual.widgets import Input, Label, RichLog, Static

from nexus_sdlc.tui._ansi import strip_ansi as _strip_ansi

if TYPE_CHECKING:
    from nexus_sdlc.config.loader import NexusConfigLoader
    from nexus_sdlc.registry.conversation_registry import ConversationRegistry
    from nexus_sdlc.subprocess_launcher.launcher import SubprocessLauncher

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# ConversationSession dataclass
# ---------------------------------------------------------------------------


@dataclass
class ConversationSession:
    """
    Per-session mutable state.

    Parameters
    ----------
    session_id:
        UUID4 string (generated externally).
    name:
        Human-readable label shown in the tab header.
    project_slug:
        Nexus project slug for display.
    project_dir:
        Absolute path to the project directory — used to key SubprocessLauncher.
    launcher:
        Shared SubprocessLauncher for project_dir (TUI-7).
    """

    session_id: str
    name: str
    project_slug: str
    project_dir: str
    launcher: "SubprocessLauncher"
    process: asyncio.subprocess.Process | None = field(default=None, repr=False)
    reader_task: asyncio.Task | None = field(default=None, repr=False)
    status: str = "idle"           # idle | running | streaming | error | success
    token_count: int = 0
    cost_usd: float = 0.0
    turn_count: int = 0
    title: str = ""                # first message, truncated to 80 chars
    created_at: datetime = field(default_factory=lambda: datetime.now(tz=timezone.utc))
    last_active_at: datetime = field(default_factory=lambda: datetime.now(tz=timezone.utc))


# ---------------------------------------------------------------------------
# Session log panel widget
# ---------------------------------------------------------------------------


class _SessionPanel(Static):
    """
    Inner panel rendered per ConversationSession — shows the token stream.

    Hidden until its session is selected in the tab list.
    """

    DEFAULT_CSS = """
    _SessionPanel {
        height: 1fr;
        display: none;
        layout: vertical;
    }
    _SessionPanel.active {
        display: block;
    }
    _SessionPanel #session-log {
        height: 1fr;
        border: solid $panel-darken-1;
    }
    _SessionPanel #session-status {
        height: 1;
        color: $text-muted;
    }
    _SessionPanel #session-input {
        dock: bottom;
        height: 3;
        margin: 0 0 0 0;
    }
    """

    def __init__(self, session: ConversationSession) -> None:
        super().__init__(id=f"panel-{session.session_id}")
        self.session = session

    def compose(self) -> ComposeResult:
        yield Label("", id="session-status")
        yield RichLog(
            id="session-log",
            highlight=False,
            markup=True,
            wrap=True,
        )
        yield Input(
            placeholder="Type a message and press Enter…",
            id="session-input",
        )

    def focus_input(self) -> None:
        """Focus the input field for this panel."""
        try:
            self.query_one("#session-input", Input).focus()
        except Exception:
            pass

    def append_token(self, content: str, token_type: str) -> None:
        """Append *content* to the session log.

        For "assistant" and "user_echo" types the content is already pre-formatted
        Rich markup (safe labels + markup_escape'd body) — write directly.
        For all other types, escape first to prevent injection.
        """
        log = self.query_one("#session-log", RichLog)
        if token_type in ("assistant", "user_echo"):
            # Pre-formatted Rich markup — write as-is
            log.write(content)
        elif token_type == "error":
            log.write(f"[red]{markup_escape(content)}[/red]")
        elif token_type == "system":
            log.write(f"[dim]{markup_escape(content)}[/dim]")
        elif token_type == "result":
            log.write(f"[green]{markup_escape(content)}[/green]")
        else:
            log.write(markup_escape(content))

    def update_status_line(self, session: ConversationSession) -> None:
        """Refresh the status line from session state."""
        glyph_map = {
            "running": ("●", "cyan"),
            "streaming": ("◐", "blue"),
            "idle": ("○", "white dim"),
            "error": ("⚠", "red"),
            "success": ("✓", "green"),
        }
        glyph, color = glyph_map.get(session.status, ("○", "white dim"))
        tokens = session.token_count
        cost = session.cost_usd
        safe_name = markup_escape(session.name)
        status_label = self.query_one("#session-status", Label)
        status_label.update(
            f"[{color}]{glyph}[/{color}]  {safe_name}  "
            f"[dim]tokens:{tokens}  ${cost:.4f}  turns:{session.turn_count}[/dim]"
        )


# ---------------------------------------------------------------------------
# ConversationTab
# ---------------------------------------------------------------------------


class ConversationTab(Widget):
    """
    Multi-session conversation manager tab.

    Maintains a dict of ConversationSession objects, each backed by an async
    subprocess running ``claude -p --output-format stream-json``.  Token streams
    are read via async reader tasks (AR-19, C-1).

    One SubprocessLauncher per project_dir is cached in ``_launchers`` (TUI-7).
    The ConversationRegistry is injected at construction; the TUI does NOT
    register a SIGTERM handler — that belongs to the registry (TUI-4).

    Parameters
    ----------
    config:
        NexusConfigLoader for project metadata.
    registry:
        ConversationRegistry instance (NOT module-level singleton — AR-5).
    """

    # Must be True so on_key fires even when no child widget has focus
    # (e.g. when the session list is empty at startup).
    can_focus = True

    DEFAULT_CSS = """
    ConversationTab {
        layout: vertical;
        height: 100%;
    }
    ConversationTab #conv-header {
        height: 1;
        padding: 0 1;
        color: $text-muted;
    }
    ConversationTab #conv-session-bar {
        height: 1;
        padding: 0 1;
        background: $panel;
        overflow-x: auto;
    }
    ConversationTab #conv-body {
        height: 1fr;
        padding: 1;
    }
    ConversationTab #conv-no-sessions {
        height: 1fr;
        content-align: center middle;
        color: $text-muted;
    }
    """

    def __init__(
        self,
        config: "NexusConfigLoader",
        registry: "ConversationRegistry",
        *,
        name: str | None = None,
        id: str | None = None,
        classes: str | None = None,
    ) -> None:
        super().__init__(name=name, id=id, classes=classes)
        self._config = config
        self._registry = registry

        # session_id -> ConversationSession
        self._sessions: dict[str, ConversationSession] = {}
        # project_dir -> SubprocessLauncher (TUI-7)
        self._launchers: dict[str, "SubprocessLauncher"] = {}
        self._active_session_id: str | None = None

    # ------------------------------------------------------------------
    # Compose
    # ------------------------------------------------------------------

    def compose(self) -> ComposeResult:
        yield Label(
            "Conversations  [dim]new: n  close: d  send: enter[/dim]",
            id="conv-header",
        )
        yield Label("", id="conv-session-bar")
        with Static(id="conv-body"):
            yield Label(
                "No active sessions — press [bold]n[/bold] to start one",
                id="conv-no-sessions",
            )

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def on_mount(self) -> None:
        """Restore sessions from registry on mount."""
        self._refresh_session_bar()
        # Focus self so keyboard shortcuts (n / d / tab) work immediately,
        # even before any session (and its Input widget) is created.
        self.focus()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def new_session(
        self,
        project_dir: str | Path,
        project_slug: str,
        initial_prompt: str | None = None,
        *,
        name: str | None = None,
    ) -> str:
        """
        Create a new conversation session.

        If *initial_prompt* is given the subprocess is spawned immediately with
        that prompt.  If omitted (the common case when the user opens a new
        session manually) the UI is created and the Input widget is focused —
        the subprocess is spawned only when the user submits their first message.

        Parameters
        ----------
        project_dir:
            Absolute path to the project directory.
        project_slug:
            Nexus slug (display only).
        initial_prompt:
            First message to send.  If None, session starts without spawning.
        name:
            Optional human-readable session name.

        Returns
        -------
        str
            The new session_id (UUID4).
        """
        from nexus_sdlc.subprocess_launcher.launcher import SubprocessLauncher

        project_dir = str(Path(project_dir).resolve())
        session_id = str(uuid.uuid4())
        default_name = "New session"
        session_name = name or (
            (initial_prompt[:40] + "…" if len(initial_prompt) > 40 else initial_prompt)
            if initial_prompt else default_name
        )

        # TUI-7: one launcher per project_dir
        if project_dir not in self._launchers:
            self._launchers[project_dir] = SubprocessLauncher(project_dir)
        launcher = self._launchers[project_dir]

        session = ConversationSession(
            session_id=session_id,
            name=session_name,
            project_slug=project_slug,
            project_dir=project_dir,
            launcher=launcher,
            title=(initial_prompt[:80] if initial_prompt else ""),
        )
        self._sessions[session_id] = session

        # Add panel to DOM
        body = self.query_one("#conv-body", Static)
        try:
            self.query_one("#conv-no-sessions", Label).remove()
        except Exception:  # noqa: BLE001
            pass
        panel = _SessionPanel(session)
        await body.mount(panel)  # await so panel is in DOM before _activate_session

        # Activate new session
        self._activate_session(session_id)

        # Only spawn if an initial_prompt was provided; otherwise just focus
        # the input and wait for the user to type their first message.
        if initial_prompt:
            self._append_to_panel(
                session_id,
                f"[bold cyan]You:[/bold cyan] {markup_escape(initial_prompt)}",
                "user_echo",
            )
            await self._start_session_process(session, initial_prompt)

        return session_id

    async def send_message(self, session_id: str, message: str) -> None:
        """
        Send a follow-up message to an existing session by spawning a new process.

        Each ``send_message`` call terminates any existing process for the session
        and spawns a fresh one.  The claude CLI is stateless per-invocation.
        """
        session = self._sessions.get(session_id)
        if session is None:
            logger.warning("ConversationTab.send_message: unknown session %s", session_id)
            return

        # Echo the user's message into the panel so they can see it
        self._append_to_panel(session_id, f"[bold cyan]You:[/bold cyan] {markup_escape(message)}", "user_echo")

        # Terminate existing process if one is still running (e.g. prior turn)
        if session.process is not None:
            await self._terminate_process(session)

        await self._start_session_process(session, message)
        session.turn_count += 1
        session.name = message[:40] + ("…" if len(message) > 40 else "")
        self._refresh_session_bar()

    async def close_session(self, session_id: str) -> None:
        """
        Close a session, terminating its subprocess and recording to registry.
        """
        session = self._sessions.get(session_id)
        if session is None:
            return

        await self._close_session(session)

    async def terminate_all_sessions(self) -> None:
        """
        Terminate all active subprocesses.

        Called by the app on shutdown — does NOT flush the registry (TUI-4).
        The registry handles its own SIGTERM/atexit flush.
        """
        for session_id in list(self._sessions.keys()):
            session = self._sessions[session_id]
            if session.process is not None:
                try:
                    await self._terminate_process(session)
                except Exception as exc:  # noqa: BLE001
                    logger.warning(
                        "ConversationTab.terminate_all_sessions: error closing %s: %s",
                        session_id,
                        exc,
                    )

    # ------------------------------------------------------------------
    # Internal: session activation
    # ------------------------------------------------------------------

    def _activate_session(self, session_id: str) -> None:
        """Show the panel for session_id and hide all others."""
        self._active_session_id = session_id

        for sid, session in self._sessions.items():
            panel_id = f"panel-{sid}"
            try:
                panel = self.query_one(f"#{panel_id}", _SessionPanel)
                if sid == session_id:
                    panel.add_class("active")
                else:
                    panel.remove_class("active")
            except Exception:  # noqa: BLE001
                pass

        self._refresh_session_bar()

        # Focus the input field of the newly active panel
        try:
            active_panel = self.query_one(f"#panel-{session_id}", _SessionPanel)
            active_panel.focus_input()
        except Exception:
            pass

    def _refresh_session_bar(self) -> None:
        """Rebuild the session bar label."""
        bar = self.query_one("#conv-session-bar", Label)
        if not self._sessions:
            bar.update("[dim]no sessions[/dim]")
            return

        parts: list[str] = []
        for sid, session in self._sessions.items():
            glyph_map = {
                "running": ("●", "cyan"),
                "streaming": ("◐", "blue"),
                "idle": ("○", "white dim"),
                "error": ("⚠", "red"),
                "success": ("✓", "green"),
            }
            g, c = glyph_map.get(session.status, ("○", "white dim"))
            is_active = sid == self._active_session_id
            label_text = markup_escape(session.name[:20])
            if is_active:
                parts.append(f"[bold][{c}]{g}[/{c}] {label_text}[/bold]")
            else:
                parts.append(f"[dim][{c}]{g}[/{c}] {label_text}[/dim]")

        bar.update("  ".join(parts))

    # ------------------------------------------------------------------
    # Internal: subprocess management
    # ------------------------------------------------------------------

    async def _start_session_process(
        self, session: ConversationSession, prompt: str
    ) -> None:
        """
        Spawn a subprocess for *session* with *prompt*.

        Sets session.status = "running", creates the reader task.
        """
        from nexus_sdlc.exceptions import SubprocessNotFound

        session.status = "running"
        session.last_active_at = datetime.now(tz=timezone.utc)
        self._update_panel_status(session)

        try:
            process = await session.launcher.spawn(session.session_id, prompt)
        except SubprocessNotFound as exc:
            logger.error("ConversationTab: claude not found: %s", exc)
            session.status = "error"
            self._update_panel_status(session)
            self._append_to_panel(
                session.session_id,
                f"[red]⚠  claude binary not found: {markup_escape(str(exc))}[/red]",
                "error",
            )
            return
        except Exception as exc:  # noqa: BLE001
            logger.error("ConversationTab: spawn failed: %s", exc)
            session.status = "error"
            self._update_panel_status(session)
            self._append_to_panel(
                session.session_id,
                f"[red]⚠  subprocess error: {markup_escape(str(exc))}[/red]",
                "error",
            )
            return

        session.process = process

        # Cancel any previous reader task
        if session.reader_task is not None and not session.reader_task.done():
            session.reader_task.cancel()

        # Start stdout reader task (AR-19, C-1: task not while-loop)
        session.reader_task = asyncio.create_task(
            self._read_stdout(session),
            name=f"reader-{session.session_id[:8]}",
        )

    async def _read_stdout(self, session: ConversationSession) -> None:
        """
        Read stream-json lines from the subprocess stdout.

        CRAWL Gap 5: Accumulates bytes until \\n before parsing each line.
        TUI-5: ANSI codes stripped via _strip_ansi before posting.
        AR-19: asyncio reader — no sync reads.

        Posts SessionTokenReceived to the app message bus for each parsed token.
        """
        process = session.process
        if process is None or process.stdout is None:
            return

        session.status = "streaming"
        self._update_panel_status(session)

        buffer = b""
        try:
            while True:
                chunk = await process.stdout.read(4096)
                if not chunk:
                    break
                buffer += chunk
                # CRAWL Gap 5: split on newline
                while b"\n" in buffer:
                    line_bytes, buffer = buffer.split(b"\n", 1)
                    line = line_bytes.decode("utf-8", errors="replace").strip()
                    if not line:
                        continue
                    self._handle_stream_line(session, line)
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            logger.warning("ConversationTab._read_stdout: %s: %s", session.session_id, exc)
            session.status = "error"
        else:
            session.status = "success"
        finally:
            session.last_active_at = datetime.now(tz=timezone.utc)
            self._update_panel_status(session)
            self._refresh_session_bar()
            # Re-focus the input so the user can type a follow-up immediately
            if self._active_session_id == session.session_id:
                try:
                    panel = self.query_one(f"#panel-{session.session_id}", _SessionPanel)
                    panel.focus_input()
                except Exception:
                    pass

    def _handle_stream_line(self, session: ConversationSession, line: str) -> None:
        """
        Parse a single stream-json line and dispatch to the panel and message bus.

        claude -p --verbose --output-format stream-json emits JSON-L events:
          {"type":"system","subtype":"init",...}
          {"type":"assistant","message":{"content":[{"type":"text","text":"..."}],...},...}
          {"type":"result","result":"...","total_cost_usd":0.004,"usage":{...},...}

        TUI-5: ANSI stripped before posting SessionTokenReceived.
        """
        try:
            data = json.loads(line)
        except json.JSONDecodeError:
            # Skip unparseable lines (not stream-json)
            return

        event_type = data.get("type", "")

        # ── assistant message ─────────────────────────────────────────────────
        if event_type == "assistant":
            message = data.get("message") or {}
            content_blocks = message.get("content") or []
            raw_text = ""
            for block in content_blocks:
                if isinstance(block, dict) and block.get("type") == "text":
                    raw_text += block.get("text", "")

            if raw_text:
                content = _strip_ansi(raw_text)
                self._append_to_panel(
                    session.session_id,
                    f"[bold green]Claude:[/bold green] {markup_escape(content)}",
                    "assistant",
                )
                if not session.title:
                    session.title = content[:80]

            # Accumulate token counts from inline usage (per-turn)
            usage = message.get("usage") or {}
            tokens = (
                (usage.get("input_tokens") or 0)
                + (usage.get("output_tokens") or 0)
                + (usage.get("cache_read_input_tokens") or 0)
                + (usage.get("cache_creation_input_tokens") or 0)
            )
            if tokens:
                session.token_count += tokens

        # ── result event (turn complete — final cost + usage) ─────────────────
        elif event_type == "result":
            cost = data.get("total_cost_usd") or 0.0
            if cost:
                session.cost_usd = float(cost)  # result is authoritative; replace

            usage = data.get("usage") or {}
            tokens = (
                (usage.get("input_tokens") or 0)
                + (usage.get("output_tokens") or 0)
                + (usage.get("cache_read_input_tokens") or 0)
                + (usage.get("cache_creation_input_tokens") or 0)
            )
            if tokens:
                session.token_count = tokens  # authoritative; replace

            # Update status line immediately so cost shows without waiting for
            # the finally block of _read_stdout.
            self._update_panel_status(session)
            self._refresh_session_bar()

        # ── system / hook / rate_limit_event / user echo: skip ────────────────
        # (noise — do not render in the conversation log)

        # Always post to the message bus (StatusBar reactives, perception, etc.)
        from nexus_sdlc.tui.messages import SessionTokenReceived  # deferred import
        self.post_message(
            SessionTokenReceived(
                session_id=session.session_id,
                token_type=event_type,
                content="",
                raw_json=data,
            )
        )

    def _update_usage(self, session: ConversationSession, usage: dict) -> None:
        """Extract token count and cost from a usage dict."""
        if not isinstance(usage, dict):
            return
        # Claude stream-json usage fields
        tokens = (
            (usage.get("input_tokens") or 0)
            + (usage.get("output_tokens") or 0)
            + (usage.get("cache_read_input_tokens") or 0)
            + (usage.get("cache_creation_input_tokens") or 0)
        )
        if tokens:
            session.token_count += tokens
        cost = usage.get("cost_usd") or usage.get("total_cost_usd") or 0.0
        if cost:
            session.cost_usd += float(cost)

    def _append_to_panel(
        self, session_id: str, content: str, token_type: str
    ) -> None:
        """Append *content* to the session's _SessionPanel."""
        try:
            panel = self.query_one(f"#panel-{session_id}", _SessionPanel)
            panel.append_token(content, token_type)
        except Exception:  # noqa: BLE001
            pass

    def _update_panel_status(self, session: ConversationSession) -> None:
        """Refresh the status line on the session panel."""
        try:
            panel = self.query_one(f"#panel-{session.session_id}", _SessionPanel)
            panel.update_status_line(session)
        except Exception:  # noqa: BLE001
            pass

    # ------------------------------------------------------------------
    # Internal: process teardown
    # ------------------------------------------------------------------

    async def _terminate_process(self, session: ConversationSession) -> None:
        """
        Terminate the process for *session* using SubprocessLauncher.terminate.
        """
        if session.reader_task is not None and not session.reader_task.done():
            session.reader_task.cancel()
            try:
                await session.reader_task
            except (asyncio.CancelledError, Exception):
                pass
            session.reader_task = None

        if session.process is not None:
            try:
                await session.launcher.terminate(session.process)
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "ConversationTab: terminate failed for %s: %s",
                    session.session_id,
                    exc,
                )
            session.process = None

    async def _close_session(self, session: ConversationSession) -> None:
        """
        Terminate subprocess, record to registry, remove from _sessions.

        TUI-4: Does NOT register SIGTERM — registry owns that.
        """
        await self._terminate_process(session)

        # Record to registry
        from nexus_sdlc.registry.models import SessionRecord  # deferred import
        try:
            record = SessionRecord(
                session_id=session.session_id,
                project_dir=session.project_dir,
                created_at=session.created_at,
                last_active_at=datetime.now(tz=timezone.utc),
                turn_count=session.turn_count,
                title=session.title,
            )
            self._registry.record(record)
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "ConversationTab._close_session: registry record failed: %s", exc
            )

        # Remove panel from DOM
        try:
            panel = self.query_one(f"#panel-{session.session_id}", _SessionPanel)
            panel.remove()
        except Exception:  # noqa: BLE001
            pass

        del self._sessions[session.session_id]

        # Post close message
        from nexus_sdlc.tui.messages import ConversationTabClosed  # deferred import
        self.post_message(ConversationTabClosed(session_id=session.session_id))

        # Activate another session if available
        remaining = list(self._sessions.keys())
        if remaining:
            self._activate_session(remaining[-1])
        else:
            self._active_session_id = None
            body = self.query_one("#conv-body", Static)
            body.mount(
                Label(
                    "No active sessions — press [bold]n[/bold] to start one",
                    id="conv-no-sessions",
                )
            )
            self._refresh_session_bar()

    # ------------------------------------------------------------------
    # App-level action hooks (called by NexusTUIApp action_* methods)
    # ------------------------------------------------------------------

    def open_new_conversation_picker(self) -> None:
        """Start a new session — called by app Ctrl+T binding.

        v1: spawns immediately with a blank opening so Claude awaits input.
        project_dir and project_slug are resolved from app.config.
        """
        try:
            project_dir = self.app.config.get("project.path") or str(Path.cwd())
            project_slug = self.app.config.get("project.slug") or "nexus"
        except Exception:
            project_dir = str(Path.cwd())
            project_slug = "nexus"

        asyncio.create_task(
            self.new_session(
                project_dir=project_dir,
                project_slug=project_slug,
                # No initial_prompt — user types the first message themselves
            ),
            name="new-session",
        )

    def close_active_conversation(self) -> None:
        """Close the currently active session — called by app Ctrl+W binding."""
        if self._active_session_id:
            asyncio.create_task(
                self.close_session(self._active_session_id),
                name=f"close-{self._active_session_id[:8]}",
            )

    # ------------------------------------------------------------------
    # Message handlers
    # ------------------------------------------------------------------

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Send the typed message to the active session subprocess.

        Fires when the user presses Enter in any #session-input field.
        Clears the input after sending.
        """
        message = event.value.strip()
        if not message or not self._active_session_id:
            return

        event.input.clear()

        session_id = self._active_session_id
        asyncio.create_task(
            self.send_message(session_id, message),
            name=f"send-{session_id[:8]}",
        )

    def on_key(self, event) -> None:
        """Handle keyboard shortcuts for session management."""
        if event.key == "n":
            # Only open a new session if the input widget does NOT have focus
            # (prevents 'n' from being swallowed when typing in the input box)
            self.open_new_conversation_picker()
        elif event.key == "d":
            if self._active_session_id:
                asyncio.create_task(
                    self.close_session(self._active_session_id),
                    name=f"close-{self._active_session_id[:8]}",
                )
        elif event.key == "tab":
            # Cycle through sessions
            ids = list(self._sessions.keys())
            if len(ids) <= 1:
                return
            try:
                current_idx = ids.index(self._active_session_id)
                next_idx = (current_idx + 1) % len(ids)
                self._activate_session(ids[next_idx])
            except (ValueError, IndexError):
                pass
