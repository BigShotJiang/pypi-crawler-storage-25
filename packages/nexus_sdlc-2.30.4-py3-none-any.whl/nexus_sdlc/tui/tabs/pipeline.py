"""
nexus_sdlc.tui.tabs.pipeline — Pipeline status monitoring tab.

Polls the Nexus director-bridge.sh every 15 seconds to fetch pipeline state
for the active project.  Renders stage rows with status glyphs, agent names,
and timing.

Bridge path resolution (walk-up 5 levels from this file):
  tabs/ → tui/ → nexus_sdlc/ → src/ → Nexus/ → core/director-bridge.sh
  Falls back to config key "nexus.bridge_path" if env walk fails.

Anti-requirements
-----------------
TUI-2:  No blocking I/O on the render loop.
AR-2:   asyncio.create_subprocess_exec only — shell=True NEVER used.
AR-19:  No sync I/O on the event loop.
C-1:    set_interval, not while-loop sleep.

Status glyphs (arch-tui Section 3):
  ✓  success  (green)
  ●  running  (cyan)
  ○  pending  (dim)
  ⚠  error    (red)
  ◐  partial  (yellow)
"""
from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import TYPE_CHECKING

from nexus_sdlc.tui._ansi import strip_ansi

from textual.app import ComposeResult
from textual.widget import Widget
from textual.widgets import Label, RichLog, Static

if TYPE_CHECKING:
    from nexus_sdlc.config.loader import NexusConfigLoader

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_POLL_INTERVAL_SECONDS = 15.0
_BRIDGE_TIMEOUT_SECONDS = 10.0

_GLYPH_STATUS = {
    "success": ("✓", "green"),
    "complete": ("✓", "green"),
    "running": ("●", "cyan"),
    "in_progress": ("●", "cyan"),
    "pending": ("○", "white dim"),
    "waiting": ("○", "white dim"),
    "error": ("⚠", "red"),
    "failed": ("⚠", "red"),
    "partial": ("◐", "yellow"),
    "degraded": ("◐", "yellow"),
}


def _resolve_bridge_path(config: "NexusConfigLoader") -> Path | None:
    """
    Resolve the director-bridge.sh path.

    Priority:
    1. Config key "nexus.bridge_path"
    2. Walk 5 levels up from this file to find Nexus/core/director-bridge.sh
    """
    # Config override
    cfg_path = config.get("nexus.bridge_path")
    if cfg_path:
        p = Path(cfg_path).expanduser()
        if p.is_file():
            return p

    # Walk-up: tabs/ → tui/ → nexus_sdlc/ → src/ → Nexus/
    candidate = Path(__file__).parent.parent.parent.parent.parent / "core" / "director-bridge.sh"
    if candidate.is_file():
        return candidate

    logger.warning("PipelineTab: director-bridge.sh not found at %s", candidate)
    return None


# ---------------------------------------------------------------------------
# PipelineTab
# ---------------------------------------------------------------------------


class PipelineTab(Widget):
    """
    Pipeline status monitoring tab.

    Calls ``director-bridge.sh status`` every 15 seconds and parses the
    JSON output to display stage rows with status glyphs, agent names,
    timing, and a summary header.

    If the bridge script is not found, displays a degraded banner and
    retries on the next poll interval.

    Parameters
    ----------
    config:
        NexusConfigLoader providing bridge_path and project metadata.
    """

    DEFAULT_CSS = """
    PipelineTab {
        layout: vertical;
        height: 100%;
        padding: 1 2;
    }
    PipelineTab #pipeline-header {
        height: 1;
        margin-bottom: 1;
    }
    PipelineTab #pipeline-log {
        height: 1fr;
        border: solid $panel-darken-1;
    }
    PipelineTab #pipeline-footer {
        height: 1;
        color: $text-muted;
        margin-top: 1;
    }
    """

    def __init__(
        self,
        config: "NexusConfigLoader",
        *,
        name: str | None = None,
        id: str | None = None,
        classes: str | None = None,
    ) -> None:
        super().__init__(name=name, id=id, classes=classes)
        self._config = config
        self._poll_count = 0
        self._bridge_path: Path | None = None

    # ------------------------------------------------------------------
    # Compose
    # ------------------------------------------------------------------

    def compose(self) -> ComposeResult:
        yield Label("Pipeline Status  [dim]polls every 15s[/dim]", id="pipeline-header")
        yield RichLog(id="pipeline-log", highlight=True, markup=True, wrap=False)
        yield Label("", id="pipeline-footer")

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def on_mount(self) -> None:
        """Resolve bridge path and start the 15-second poll interval (C-1)."""
        self._bridge_path = _resolve_bridge_path(self._config)
        if self._bridge_path is None:
            log = self.query_one("#pipeline-log", RichLog)
            log.write(
                "[red]⚠[/red]  director-bridge.sh not found — "
                "pipeline polling unavailable"
            )

        self.set_interval(_POLL_INTERVAL_SECONDS, self._poll_pipeline)
        # Fire an immediate poll (non-blocking)
        asyncio.get_event_loop().call_soon(
            lambda: asyncio.ensure_future(self._poll_pipeline())
        )

    # ------------------------------------------------------------------
    # Polling
    # ------------------------------------------------------------------

    async def _poll_pipeline(self) -> None:
        """
        Poll director-bridge.sh for pipeline state.

        AR-2: asyncio.create_subprocess_exec — never shell=True.
        TUI-2: runs in async task, never blocks the render loop.
        """
        self._poll_count += 1
        footer = self.query_one("#pipeline-footer", Label)
        footer.update(f"[dim]polling… (#{self._poll_count})[/dim]")

        if self._bridge_path is None:
            # Re-attempt resolution on each poll in case script was installed later
            self._bridge_path = _resolve_bridge_path(self._config)
            if self._bridge_path is None:
                footer.update("[red]bridge not found — retrying in 15s[/red]")
                return

        project_slug = self._config.get("project.slug") or ""
        task_id = self._config.get("nexus.active_task_id") or ""

        cmd = [str(self._bridge_path), "status"]
        if project_slug:
            cmd += ["--project", project_slug]
        if task_id:
            cmd += ["--task", task_id]

        try:
            proc = await asyncio.wait_for(
                asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                ),
                timeout=_BRIDGE_TIMEOUT_SECONDS,
            )
        except asyncio.TimeoutError:
            footer.update("[red]bridge timed out — retrying in 15s[/red]")
            return
        except OSError as exc:
            logger.warning("PipelineTab: failed to launch bridge: %s", exc)
            footer.update(f"[red]bridge error: {exc}[/red]")
            return

        try:
            stdout_bytes, stderr_bytes = await asyncio.wait_for(
                proc.communicate(),
                timeout=_BRIDGE_TIMEOUT_SECONDS,
            )
        except asyncio.TimeoutError:
            proc.kill()
            footer.update("[red]bridge response timed out[/red]")
            return

        stdout = stdout_bytes.decode("utf-8", errors="replace")
        stderr = stderr_bytes.decode("utf-8", errors="replace")

        if proc.returncode != 0:
            logger.debug(
                "PipelineTab: bridge returned %d; stderr=%s", proc.returncode, stderr[:200]
            )

        self._render_pipeline_output(stdout, stderr, proc.returncode or 0)
        footer.update(f"[dim]last poll: #{self._poll_count}[/dim]")

    def _render_pipeline_output(
        self, stdout: str, stderr: str, returncode: int
    ) -> None:
        """
        Parse bridge output and render into the RichLog.

        Accepts both JSON and plain-text output from the bridge.
        CRAWL Gap 5: accumulates partial lines until newline before parsing.
        """
        log = self.query_one("#pipeline-log", RichLog)
        log.clear()

        if not stdout.strip():
            if returncode != 0:
                log.write(f"[red]⚠[/red]  Bridge exited {returncode}")
                if stderr.strip():
                    log.write(f"[dim]{strip_ansi(stderr.strip()[:300])}[/dim]")
            else:
                log.write("[dim]No pipeline data available[/dim]")
            return

        # Attempt JSON parsing first
        parsed: dict | None = None
        for line in stdout.splitlines():
            stripped = line.strip()
            if not stripped:
                continue
            try:
                parsed = json.loads(stripped)
                break
            except json.JSONDecodeError:
                pass

        if parsed is not None:
            self._render_pipeline_json(log, parsed)
        else:
            # Plain-text fallback — strip ANSI before rendering
            for line in stdout.splitlines():
                stripped = line.strip()
                if stripped:
                    log.write(strip_ansi(stripped))

    def _render_pipeline_json(self, log: RichLog, data: dict) -> None:
        """Render structured pipeline JSON into the RichLog."""
        # Header summary
        task_id = data.get("task_id", "—")
        phase = data.get("phase", "—")
        overall = data.get("status", "unknown")
        glyph, color = _GLYPH_STATUS.get(overall, ("○", "white dim"))

        log.write(
            f"[bold]Task[/bold] {task_id}  "
            f"[bold]Phase[/bold] {phase}  "
            f"[{color}]{glyph} {overall}[/{color}]"
        )
        log.write("")

        # Stage rows
        stages = data.get("stages", [])
        if not stages:
            log.write("[dim]No stage data[/dim]")
            return

        for stage in stages:
            name = stage.get("name", "?")
            agent = stage.get("agent", "")
            status = stage.get("status", "unknown")
            duration = stage.get("duration_s")

            g, c = _GLYPH_STATUS.get(status, ("○", "white dim"))
            duration_str = f"  [dim]{duration:.1f}s[/dim]" if duration is not None else ""
            agent_str = f"  [dim]{agent}[/dim]" if agent else ""

            log.write(f"  [{c}]{g}[/{c}]  {name}{agent_str}{duration_str}")

        # Footer metadata
        log.write("")
        if "updated_at" in data:
            log.write(f"[dim]Updated: {data['updated_at']}[/dim]")
