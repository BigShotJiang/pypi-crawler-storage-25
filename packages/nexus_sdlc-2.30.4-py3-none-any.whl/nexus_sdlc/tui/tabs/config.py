"""
nexus_sdlc.tui.tabs.config — Read-only configuration viewer tab.

TUI-6: ConfigTab MUST NOT write to any config files.  No Input widgets,
no Button widgets, no write methods.  All values are display-only.

Sections
--------
Eight logical sections expose the most relevant config keys:
  1. Autonomous Mode
  2. Release Manager
  3. Workspace Settings
  4. Budget & WIL
  5. Perception Config
  6. Model Routing
  7. Infrastructure
  8. Debug & Logging
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from textual.app import ComposeResult
from textual.widget import Widget
from textual.widgets import Label, ListItem, ListView, Static

if TYPE_CHECKING:
    from nexus_sdlc.config.loader import NexusConfigLoader

# ---------------------------------------------------------------------------
# Section definitions: (display_name, [(label, config_key), ...])
# ---------------------------------------------------------------------------
_SECTIONS: list[tuple[str, list[tuple[str, str]]]] = [
    (
        "Autonomous Mode",
        [
            ("mode", "autonomous.mode"),
            ("safety.require_approval", "autonomous.safety.require_approval"),
            ("safety.max_retries", "autonomous.safety.max_retries"),
        ],
    ),
    (
        "Release Manager",
        [
            ("nexus_plugin_version", "nexus_plugin_version"),
            ("workspace_root", "workspace.root"),
        ],
    ),
    (
        "Workspace Settings",
        [
            ("registry_path", "workspace.registry_path"),
            ("project.slug", "project.slug"),
            ("project.name", "project.name"),
        ],
    ),
    (
        "Budget & WIL",
        [
            ("wil.min_budget_floor", "wil.min_budget_floor"),
            ("wil.hotfix_ceiling", "wil.hotfix_ceiling"),
            ("wil.max_validation_loops", "wil.max_validation_loops"),
        ],
    ),
    (
        "Perception Config",
        [
            ("perception.enabled", "perception.enabled"),
            ("perception.authority", "perception.authority"),
            ("perception.consumer_group", "perception.consumer_group"),
        ],
    ),
    (
        "Model Routing",
        [
            ("models.default", "models.default"),
            ("models.fast", "models.fast"),
            ("models.large", "models.large"),
        ],
    ),
    (
        "Infrastructure",
        [
            ("infrastructure.mode", "infrastructure.mode"),
            ("infrastructure.temporal_host", "infrastructure.temporal_host"),
            ("infrastructure.valkey_host", "infrastructure.valkey_host"),
        ],
    ),
    (
        "Debug & Logging",
        [
            ("execution.log_level", "execution.log_level"),
            ("execution.debug_mode", "execution.debug_mode"),
            ("execution.trace_enabled", "execution.trace_enabled"),
        ],
    ),
]


class ConfigTab(Widget):
    """
    Read-only configuration viewer.

    Renders a two-panel layout: a list of config sections on the left and
    a detail panel on the right showing key=value pairs for the selected
    section.

    TUI-6 enforcement
    -----------------
    - No Input widgets
    - No Button widgets
    - No write methods
    - All displayed values come from NexusConfigLoader.get() (read-only)
    - Header label explicitly states read-only intent

    Parameters
    ----------
    config:
        NexusConfigLoader instance providing 4-tier key resolution.
    """

    DEFAULT_CSS = """
    ConfigTab {
        layout: vertical;
        height: 100%;
    }
    ConfigTab #config-header {
        background: $panel;
        color: $text-muted;
        padding: 0 1;
        height: 1;
    }
    ConfigTab #config-body {
        layout: horizontal;
        height: 1fr;
    }
    ConfigTab #config-sections {
        width: 26;
        border-right: solid $primary-darken-2;
    }
    ConfigTab #config-detail {
        width: 1fr;
        padding: 1 2;
    }
    """

    def __init__(
        self,
        config: "NexusConfigLoader",
        *,
        name: str | None = None,
        id: str | None = None,
        classes: str | None = None,
    ) -> None:
        super().__init__(name=name, id=id, classes=classes)
        self._config = config
        # Index of keys per section — matches _SECTIONS order
        self._section_keys: list[list[tuple[str, str]]] = [
            keys for _, keys in _SECTIONS
        ]

    # ------------------------------------------------------------------
    # Compose
    # ------------------------------------------------------------------

    def compose(self) -> ComposeResult:
        yield Label(
            "Read-only — use .nexus/config.yaml to modify",
            id="config-header",
        )
        with Static(id="config-body"):
            with ListView(id="config-sections"):
                for section_name, _ in _SECTIONS:
                    yield ListItem(Label(section_name))
            yield Label("", id="config-detail")

    # ------------------------------------------------------------------
    # Event handlers
    # ------------------------------------------------------------------

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Update the detail panel when a section is selected."""
        # Determine which section index was selected
        list_view = self.query_one("#config-sections", ListView)
        children = list(list_view.query(ListItem))
        try:
            index = children.index(event.item)
        except ValueError:
            return

        if index >= len(self._section_keys):
            return

        keys = self._section_keys[index]
        section_name = _SECTIONS[index][0]

        lines: list[str] = [f"[bold]{section_name}[/bold]", ""]
        for label, config_key in keys:
            value = self._config.get(config_key)
            display = repr(value) if value is not None else "[dim]— not set —[/dim]"
            lines.append(f"[dim]{label}[/dim]  {display}")

        detail_label = self.query_one("#config-detail", Label)
        detail_label.update("\n".join(lines))
