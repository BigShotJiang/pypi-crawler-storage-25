"""
nexus_sdlc.tui.tabs.perception — PerceptionTab widget.

Displays the Nexus perception event queue — Valkey events filtered by
level and event_type. L2+ events increment the F5 badge on the StatusBar.

Architecture
------------
- Subscribes to ValkeyEventReceived messages posted by the app-level bridge.
- Subscribes to ValkeyDegradedDetected to show non-dismissible banner.
- Badge management: increments on L2+ event arrival, decrements on acknowledge.
- Level 3 events receive the `.flashing` CSS class for visual prominence.
- Never reads ValkeyConsumer directly (AR-11, TUI-2).

Anti-requirements enforced
--------------------------
AR-11: No direct Valkey access — message handler only.
TUI-2: Message handler subscription only — no SUBSCRIBE/PSUBSCRIBE.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from textual import events
from textual.app import ComposeResult
from textual.containers import Container, Horizontal
from textual.widget import Widget
from textual.widgets import Label, ListItem, ListView

from nexus_sdlc.tui.messages import ValkeyDegradedDetected, ValkeyEventReceived
from nexus_sdlc.tui.widgets.degraded_banner import DegradedBanner

logger = logging.getLogger(__name__)


@dataclass
class PerceptionEvent:
    """A single perception event received from Valkey."""

    event_id: str
    level: int                          # 1, 2, or 3
    event_type: str
    project: str
    summary: str
    timestamp: datetime
    acknowledged: bool = False
    dismissed: bool = False
    payload: dict = field(default_factory=dict)


# Level badge glyphs for the list
_LEVEL_GLYPHS = {1: "[dim]L1[/dim]", 2: "[yellow]L2[/yellow]", 3: "[red bold]L3[/red bold]"}


class PerceptionTab(Widget):
    """F5 Perception tab — event queue with acknowledge/dismiss/surface actions.

    Layout (horizontal split):
    - Left 25%: ListView — event queue (level, project, summary)
    - Right 75%: Detail pane (event body, related events, actions)

    Badge: self.app._perception_badge_count increments on L2+ arrival,
           decrements on acknowledge, clamps to 0.
    """

    DEFAULT_CSS = """
    PerceptionTab {
        layout: vertical;
    }
    #perception-header {
        height: 1;
        padding: 0 1;
        background: $surface-darken-1;
    }
    #perception-split {
        layout: horizontal;
        height: 1fr;
    }
    #perception-event-queue {
        width: 25%;
        height: 100%;
        border: solid $primary-darken-2;
    }
    #perception-content {
        width: 75%;
        height: 100%;
        padding: 0 1;
    }
    #perception-event-detail {
        height: 1fr;
        border: solid $primary-darken-2;
        padding: 1;
    }
    #perception-related {
        height: 4;
        padding: 0 1;
    }
    #perception-actions {
        height: 1;
        padding: 0 1;
        background: $surface-darken-1;
    }
    .flashing {
        background: $error 20%;
    }
    """

    def __init__(self) -> None:
        super().__init__()
        self._events: list[PerceptionEvent] = []
        self._selected_idx: int = 0

    def compose(self) -> ComposeResult:
        yield Label(
            "PERCEPTION   Briefing queue: 0 unread   [dim]A: Acknowledge  D: Dismiss  S: Surface[/dim]",
            id="perception-header",
        )
        with Horizontal(id="perception-split"):
            yield ListView(id="perception-event-queue")
            with Container(id="perception-content"):
                yield Label(
                    "[dim]Select an event to view details.[/dim]",
                    id="perception-event-detail",
                )
                yield Label("", id="perception-related")
                yield Label(
                    "[dim]A[/dim] Acknowledge   [dim]D[/dim] Dismiss   [dim]S[/dim] Surface to Director",
                    id="perception-actions",
                )

    # -------------------------------------------------------------------------
    # Valkey event handler (TUI-2: message-only subscription, AR-11)
    # -------------------------------------------------------------------------

    def on_valkey_event_received(self, message: ValkeyEventReceived) -> None:
        """Accept perception events and high-level events from the Valkey bridge."""
        event_type = message.event_type
        payload = message.payload

        # Filter: accept perception.* events OR level >= 2 events
        try:
            level = int(payload.get("level", 1))
        except (ValueError, TypeError):
            level = 1

        is_perception = event_type.startswith("perception.")
        is_high_level = level >= 2

        if not (is_perception or is_high_level):
            return

        # Build PerceptionEvent
        event_id = payload.get("event_id", message.stream_id or f"evt-{len(self._events)}")
        pevent = PerceptionEvent(
            event_id=event_id,
            level=level,
            event_type=event_type,
            project=payload.get("project", "?"),
            summary=payload.get("summary", payload.get("message", event_type)),
            timestamp=datetime.now(tz=timezone.utc),
            payload=dict(payload),
        )
        self._events.append(pevent)
        self._add_list_item(pevent)

        # Increment badge for L2+ events
        if level >= 2:
            try:
                self.app._perception_badge_count += 1
            except Exception:
                pass
            self._update_header()

        # Level 3: apply flashing CSS class to the new ListItem
        if level >= 3:
            try:
                queue = self.query_one("#perception-event-queue", ListView)
                # The last item added corresponds to this event
                items = list(queue.query(ListItem))
                if items:
                    items[-1].add_class("flashing")
            except Exception:
                pass

    def on_valkey_degraded_detected(self, message: ValkeyDegradedDetected) -> None:
        """Show a non-dismissible banner when Valkey becomes unreachable."""
        try:
            # Avoid duplicate banners
            existing = self.query(DegradedBanner)
            if existing:
                return
        except Exception:
            pass

        try:
            content = self.query_one("#perception-content", Container)
            content.mount(
                DegradedBanner(
                    service="Valkey",
                    message=(
                        "Perception events unavailable. Valkey unreachable after "
                        "5 retries. Restart nexus tui to reconnect."
                    ),
                    dismissible=False,
                ),
                before=self.query_one("#perception-event-detail", Label),
            )
        except Exception as exc:
            logger.debug("Failed to mount Valkey degraded banner: %s", exc)
        # Badge count freezes — do not clear

    # -------------------------------------------------------------------------
    # ListView selection tracking
    # -------------------------------------------------------------------------

    def on_list_view_highlighted(self, event: ListView.Highlighted) -> None:
        """Track which item is highlighted so key handlers can act on it."""
        try:
            queue = self.query_one("#perception-event-queue", ListView)
            items = list(queue.query(ListItem))
            for idx, item in enumerate(items):
                if item is event.item:
                    self._selected_idx = idx
                    self._populate_detail(idx)
                    break
        except Exception:
            pass

    # -------------------------------------------------------------------------
    # Key handlers (A / D / S)
    # -------------------------------------------------------------------------

    def on_key(self, event: events.Key) -> None:
        """Handle A (acknowledge), D (dismiss), S (surface) key presses."""
        key = event.key
        if key == "a":
            self._acknowledge_selected()
        elif key == "d":
            self._dismiss_selected()
        elif key == "s":
            self._surface_selected()

    def _acknowledge_selected(self) -> None:
        """Acknowledge the currently selected event."""
        pevent = self._get_selected_event()
        if pevent is None or pevent.acknowledged:
            return

        pevent.acknowledged = True

        # Remove .flashing class from the corresponding ListItem
        try:
            queue = self.query_one("#perception-event-queue", ListView)
            items = list(queue.query(ListItem))
            if 0 <= self._selected_idx < len(items):
                items[self._selected_idx].remove_class("flashing")
        except Exception:
            pass

        # Decrement badge count (clamp to 0)
        if pevent.level >= 2:
            try:
                self.app._perception_badge_count = max(
                    0, self.app._perception_badge_count - 1
                )
            except Exception:
                pass
            self._update_header()

        # Refresh the detail pane to reflect acknowledged state
        self._populate_detail(self._selected_idx)

    def _dismiss_selected(self) -> None:
        """Dismiss (remove) the currently selected event."""
        pevent = self._get_selected_event()
        if pevent is None:
            return

        pevent.dismissed = True

        # Remove from the ListView
        try:
            queue = self.query_one("#perception-event-queue", ListView)
            items = list(queue.query(ListItem))
            if 0 <= self._selected_idx < len(items):
                items[self._selected_idx].remove()
        except Exception:
            pass

        # Adjust selected index
        if self._selected_idx >= len(self._events):
            self._selected_idx = max(0, len(self._events) - 1)

        # Clear detail pane
        try:
            self.query_one("#perception-event-detail", Label).update(
                "[dim]Event dismissed.[/dim]"
            )
        except Exception:
            pass

    def _surface_selected(self) -> None:
        """Surface the selected event to the Director via app.notify()."""
        pevent = self._get_selected_event()
        if pevent is None:
            return
        try:
            self.app.notify(
                f"Perception event surfaced: {pevent.summary}",
                severity="warning",
            )
        except Exception:
            pass

    # -------------------------------------------------------------------------
    # Internal helpers
    # -------------------------------------------------------------------------

    def _get_selected_event(self) -> PerceptionEvent | None:
        """Return the active (non-dismissed) event at _selected_idx."""
        active = [e for e in self._events if not e.dismissed]
        if 0 <= self._selected_idx < len(active):
            return active[self._selected_idx]
        return None

    def _add_list_item(self, pevent: PerceptionEvent) -> None:
        """Append a ListItem for a new PerceptionEvent."""
        try:
            queue = self.query_one("#perception-event-queue", ListView)
            level_badge = _LEVEL_GLYPHS.get(pevent.level, f"L{pevent.level}")
            ts = pevent.timestamp.strftime("%H:%M:%S")
            label_text = f"{level_badge} {pevent.project} — {pevent.summary[:30]}"
            item = ListItem(Label(f"[dim]{ts}[/dim] {label_text}"))
            queue.append(item)
        except Exception as exc:
            logger.debug("Failed to add perception list item: %s", exc)

    def _populate_detail(self, idx: int) -> None:
        """Fill the detail pane for the event at index idx."""
        active = [e for e in self._events if not e.dismissed]
        if not (0 <= idx < len(active)):
            return

        pevent = active[idx]
        level_badge = _LEVEL_GLYPHS.get(pevent.level, f"L{pevent.level}")
        ack_text = "[green]Acknowledged[/green]" if pevent.acknowledged else "[dim]Unacknowledged[/dim]"
        ts = pevent.timestamp.strftime("%Y-%m-%d %H:%M:%S UTC")

        detail_text = (
            f"[bold]{pevent.event_type}[/bold]  {level_badge}  {ack_text}\n"
            f"Project: {pevent.project}   ID: {pevent.event_id}\n"
            f"Time: {ts}\n\n"
            f"{pevent.summary}\n"
        )

        # Add payload keys if present (excluding internal keys)
        extra = {k: v for k, v in pevent.payload.items()
                 if not k.startswith("__") and k not in ("summary", "message", "level")}
        if extra:
            detail_text += "\n[dim]Payload:[/dim]\n"
            for k, v in list(extra.items())[:8]:
                detail_text += f"  {k}: {v}\n"

        try:
            self.query_one("#perception-event-detail", Label).update(detail_text)
        except Exception:
            pass

    def _update_header(self) -> None:
        """Refresh the header label with current unread count."""
        try:
            count = self.app._perception_badge_count
            header = self.query_one("#perception-header", Label)
            header.update(
                f"PERCEPTION   Briefing queue: {count} unread   "
                "[dim]A: Acknowledge  D: Dismiss  S: Surface[/dim]"
            )
        except Exception:
            pass
