"""
nexus_sdlc.tui.tabs.workspace — WorkspaceTab widget.

Displays a live card grid of all registered projects in the workspace,
reading from the workspace registry YAML file.

Architecture
------------
- Reads workspace registry from path in app config (workspace.registry_path).
- All file I/O dispatched to thread pool via asyncio.to_thread() (AR-19).
- Refresh timer fires every 30s via set_interval() (C-1 compliance).
- Read-only — never writes to the registry (TUI-6 spirit).

Anti-requirements enforced
--------------------------
AR-19: No synchronous I/O on the event loop — YAML load via asyncio.to_thread().
TUI-6: WorkspaceTab reads workspace.yaml read-only. No writes to registry.
C-1:   Timer polling via set_interval(), not asyncio.sleep().
"""
from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any

import yaml
from textual.app import ComposeResult
from textual.widget import Widget
from textual.widgets import Label

from nexus_sdlc.tui.widgets.degraded_banner import DegradedBanner

logger = logging.getLogger(__name__)

# Project status glyphs
_STATUS_GLYPHS: dict[str, str] = {
    "active": "◉",
    "idle": "○",
    "running": "◐",
    "error": "⚠",
    "blocked": "✗",
}
_GLYPH_DEFAULT = "○"


class WorkspaceTab(Widget):
    """F3 Workspace tab — card grid of registered projects.

    Layout (vertical):
    - Header bar: project count, active pipelines, total spend
    - Card grid: one card per project (slug, status, task, spend)

    Refresh: project cards updated every 30s via set_interval().
    Read-only: never writes to the workspace registry.
    """

    DEFAULT_CSS = """
    WorkspaceTab {
        layout: vertical;
    }
    #workspace-header {
        height: 1;
        padding: 0 1;
        background: $surface-darken-1;
    }
    #workspace-cards {
        layout: vertical;
        height: 1fr;
        overflow-y: auto;
        padding: 1;
    }
    .workspace-card {
        height: auto;
        padding: 0 1;
        margin-bottom: 1;
        border: solid $primary-darken-2;
    }
    """

    def __init__(self) -> None:
        super().__init__()
        self._projects: list[dict[str, Any]] = []
        self._selected_idx: int = 0
        self._registry_path: Path | None = None

    def compose(self) -> ComposeResult:
        yield Label(
            "WORKSPACE OVERVIEW — Loading...",
            id="workspace-header",
        )
        yield Label("", id="workspace-cards")

    def on_mount(self) -> None:
        """Load registry and start refresh timer (C-1)."""
        asyncio.create_task(self._load_projects(), name="workspace-load")
        self.set_interval(30.0, self._refresh_workspace)

    # -------------------------------------------------------------------------
    # Data loading (AR-19: all file I/O via asyncio.to_thread)
    # -------------------------------------------------------------------------

    async def _load_projects(self) -> None:
        """Load workspace registry YAML asynchronously.

        AR-19 compliance: both read_text() and yaml.safe_load() are executed
        inside a single sync helper passed to asyncio.to_thread() — neither
        operation touches the event loop.
        """
        try:
            raw_path: str = self.app.config.get("workspace.registry_path", "")
        except Exception:
            raw_path = ""

        registry_path = Path(raw_path) if raw_path else Path("")

        # Resolve ~ if present
        if raw_path.startswith("~"):
            registry_path = registry_path.expanduser()

        self._registry_path = registry_path

        if not raw_path or not registry_path.exists():
            self._show_degraded(
                f"Workspace registry not found: {registry_path}"
            )
            return

        try:
            data: dict[str, Any] = await asyncio.to_thread(
                _load_registry_sync, registry_path
            )
        except Exception as exc:
            logger.warning("Failed to load workspace registry: %s", exc)
            self._show_degraded(f"Failed to load registry: {exc}")
            return

        self._projects = list(data.get("projects", {}).values())
        self._render_projects()

    def _refresh_workspace(self) -> None:
        """Timer callback — trigger async reload (C-1: set_interval fires this)."""
        asyncio.create_task(self._load_projects(), name="workspace-refresh")

    # -------------------------------------------------------------------------
    # Rendering
    # -------------------------------------------------------------------------

    def _render_projects(self) -> None:
        """Render project cards into the workspace-cards container."""
        cards_widget = self.query_one("#workspace-cards", Label)

        if not self._projects:
            cards_widget.update(
                "[dim]No projects registered in workspace.[/dim]"
            )
            self._update_header(0, 0)
            return

        # Count active pipelines
        active_pipelines = sum(
            1 for p in self._projects
            if p.get("status", "idle") in ("active", "running")
        )

        self._update_header(len(self._projects), active_pipelines)

        # Build card text for all projects
        lines: list[str] = []
        for project in self._projects:
            card_text = _format_project_card(project)
            lines.append(card_text)
            lines.append("")  # blank line between cards

        cards_widget.update("\n".join(lines))

    def _update_header(self, project_count: int, active_pipelines: int) -> None:
        """Update the workspace header label."""
        try:
            header = self.query_one("#workspace-header", Label)
            header.update(
                f"WORKSPACE OVERVIEW — {project_count} projects   "
                f"Active pipelines: {active_pipelines}   "
                f"[dim]R to refresh[/dim]"
            )
        except Exception:
            pass

    def _show_degraded(self, reason: str) -> None:
        """Mount a DegradedBanner when the registry is unavailable."""
        try:
            # Avoid duplicate banners
            from nexus_sdlc.tui.widgets.degraded_banner import DegradedBanner as _DB
            existing = self.query(_DB)
            if existing:
                return
        except Exception:
            pass

        try:
            self.mount(
                DegradedBanner(
                    service="Workspace Registry",
                    message=reason,
                    dismissible=True,
                )
            )
        except Exception as exc:
            logger.debug("Failed to mount DegradedBanner: %s", exc)

        # Update header to reflect degraded state
        try:
            header = self.query_one("#workspace-header", Label)
            header.update(
                "[yellow]WORKSPACE OVERVIEW — Registry unavailable[/yellow]"
            )
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _load_registry_sync(path: Path) -> dict[str, Any]:
    """Sync helper — called via asyncio.to_thread() only.

    Executes both read_text() and yaml.safe_load() off the event loop
    (AR-19 compliance — neither call must touch the asyncio event loop).
    """
    content = path.read_text(encoding="utf-8")
    result = yaml.safe_load(content)
    return result if isinstance(result, dict) else {}


def _format_project_card(project: dict[str, Any]) -> str:
    """Format a single project as a Rich-markup card string."""
    slug = project.get("slug", project.get("name", "unknown"))
    status = project.get("status", "idle")
    task_id = project.get("current_task", project.get("task_id", "—"))
    spend = project.get("spend_today", project.get("spend", 0.0))
    budget = project.get("budget", "—")
    last_event = project.get("last_event", "—")
    path = project.get("path", "—")

    glyph = _STATUS_GLYPHS.get(status, _GLYPH_DEFAULT)

    # Build the card using box-drawing characters
    width = 62
    slug_header = f" {slug} "
    top_line = "┌─" + slug_header + "─" * max(0, width - 2 - len(slug_header) - 1) + "┐"
    sep_line = "└" + "─" * (width - 0) + "┘"

    status_line = f"│  {glyph} {status:<10}  Task: {task_id:<30}│"
    spend_line  = f"│  Spend today: ${spend:<8}  Budget: {budget:<20}│"
    event_line  = f"│  Last event: {last_event:<45}│"
    path_line   = f"│  Path: {path:<53}│"
    action_line = f"│  [ Open Pipeline — F2 ]  [ Open Conversation — F1 ]{' ' * 9}│"

    # Truncate lines that exceed width + 2 (for the │ chars)
    card_lines = [
        top_line[:width + 2],
        status_line[:width + 2],
        spend_line[:width + 2],
        event_line[:width + 2],
        path_line[:width + 2],
        action_line[:width + 2],
        sep_line[:width + 2],
    ]
    return "\n".join(card_lines)
