"""
nexus_sdlc.tui.tabs.health — Infrastructure health monitoring tab.

Checks 5 services every 30 seconds via direct async TCP probes (Temporal,
PostgreSQL, NebulaGraph) and Valkey PING (via asyncio TCP).  Displays a
health card per service with status glyph, latency, and a 10-point sparkline.

Status glyphs (arch-tui Section 3 Tab F7):
  ●  healthy    (green)
  ◐  degraded   (yellow)
  ○  unknown    (dim)
  ⚠  error      (red)

Anti-requirements
-----------------
TUI-2: No blocking I/O on the render loop — all checks in asyncio tasks.
AR-19: No sync I/O on the event loop — use asyncio.open_connection.
C-1:   set_interval, not while-loop sleep.
"""
from __future__ import annotations

import asyncio
import logging
import time
from collections import deque
from typing import TYPE_CHECKING

from textual.app import ComposeResult
from textual.widget import Widget
from textual.widgets import Label, Static

if TYPE_CHECKING:
    from nexus_sdlc.config.loader import NexusConfigLoader

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_CHECK_INTERVAL_SECONDS = 30.0
_PROBE_TIMEOUT_SECONDS = 5.0
_SPARKLINE_LEN = 10

_GLYPH_MAP = {
    "healthy": "●",
    "degraded": "◐",
    "error": "⚠",
    "unknown": "○",
}

_COLOR_MAP = {
    "healthy": "green",
    "degraded": "yellow",
    "error": "red",
    "unknown": "white dim",
}

# Sparkline characters ordered by magnitude (0 = no data, 1-8 = latency bucket)
_SPARK_CHARS = " ▁▂▃▄▅▆▇█"

# Service definitions: (name, display_label, default_host_key, default_port_key, fallback_host, fallback_port)
_SERVICE_DEFS: list[tuple[str, str, str, str, str, int]] = [
    ("temporal", "Temporal", "infrastructure.temporal_host", "infrastructure.temporal_port", "127.0.0.1", 7233),
    ("postgres", "PostgreSQL", "infrastructure.postgres_host", "infrastructure.postgres_port", "127.0.0.1", 5433),
    ("valkey", "Valkey", "valkey.host", "valkey.port", "127.0.0.1", 6379),
    ("nebula", "NebulaGraph", "infrastructure.nebula_host", "infrastructure.nebula_port", "127.0.0.1", 9669),
    ("pm", "Process Mgr", "infrastructure.pm_host", "infrastructure.pm_port", "127.0.0.1", 9337),
]


# ---------------------------------------------------------------------------
# Service health card widget
# ---------------------------------------------------------------------------


class _ServiceCard(Static):
    """A single-service health card showing glyph + label + latency + sparkline."""

    DEFAULT_CSS = """
    _ServiceCard {
        height: 3;
        padding: 0 1;
        border: solid $panel-darken-1;
        margin-bottom: 1;
    }
    _ServiceCard.healthy {
        border: solid green;
    }
    _ServiceCard.degraded {
        border: solid yellow;
    }
    _ServiceCard.error {
        border: solid red;
    }
    """

    def __init__(self, service_name: str, display_label: str) -> None:
        super().__init__()
        self.service_name = service_name
        self.display_label = display_label
        self._status = "unknown"
        self._latency_ms: float | None = None
        self._history: deque[float | None] = deque(maxlen=_SPARKLINE_LEN)

    def _build_sparkline(self) -> str:
        """Build a 10-char sparkline from latency history (ms)."""
        chars: list[str] = []
        for v in self._history:
            if v is None:
                chars.append("×")
            else:
                # Bucket: 0–9 maps to 0–512ms (log2 scale roughly)
                bucket = min(8, max(1, int(v / 64) + 1))
                chars.append(_SPARK_CHARS[bucket])
        # Pad left with spaces if history is short
        return "".join(chars).rjust(_SPARKLINE_LEN)

    def update_status(self, status: str, latency_ms: float | None) -> None:
        """Called by HealthTab when a check result arrives."""
        self._status = status
        self._latency_ms = latency_ms
        self._history.append(latency_ms)

        # Update CSS classes for border color
        self.remove_class("healthy", "degraded", "error", "unknown")
        self.add_class(status)

        glyph = _GLYPH_MAP.get(status, "○")
        color = _COLOR_MAP.get(status, "white dim")

        latency_str = f"{latency_ms:.0f}ms" if latency_ms is not None else "—"
        sparkline = self._build_sparkline()

        self.update(
            f"[{color}]{glyph}[/{color}]  [{color}]{self.display_label}[/{color}]"
            f"  [dim]{latency_str}[/dim]  [dim]{sparkline}[/dim]"
        )


# ---------------------------------------------------------------------------
# HealthTab
# ---------------------------------------------------------------------------


class HealthTab(Widget):
    """
    Infrastructure health monitoring tab.

    Probes 5 services (Temporal, PostgreSQL, Valkey, NebulaGraph, Process Mgr)
    every 30 seconds using asyncio TCP connections.  Each service has a card
    showing status glyph, latency in ms, and a 10-point latency sparkline.

    Posted messages
    ---------------
    HealthUpdate(service_name, status, latency_ms) — posted to app after
    each check so other widgets (e.g., DegradedBanner) can react.

    Parameters
    ----------
    config:
        NexusConfigLoader providing host/port values for each service.
    """

    DEFAULT_CSS = """
    HealthTab {
        layout: vertical;
        height: 100%;
        padding: 1 2;
    }
    HealthTab #health-header {
        height: 1;
        color: $text-muted;
        margin-bottom: 1;
    }
    HealthTab #health-cards {
        layout: vertical;
        height: 1fr;
        overflow-y: auto;
    }
    HealthTab #health-footer {
        height: 1;
        color: $text-muted;
        margin-top: 1;
    }
    """

    def __init__(
        self,
        config: "NexusConfigLoader",
        *,
        name: str | None = None,
        id: str | None = None,
        classes: str | None = None,
    ) -> None:
        super().__init__(name=name, id=id, classes=classes)
        self._config = config
        self._cards: dict[str, _ServiceCard] = {}
        self._check_count = 0

    # ------------------------------------------------------------------
    # Compose
    # ------------------------------------------------------------------

    def compose(self) -> ComposeResult:
        yield Label("Infrastructure Health  [dim]checks every 30s[/dim]", id="health-header")
        with Static(id="health-cards"):
            for svc_name, display_label, _, _, _, _ in _SERVICE_DEFS:
                card = _ServiceCard(svc_name, display_label)
                self._cards[svc_name] = card
                yield card
        yield Label("", id="health-footer")

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def on_mount(self) -> None:
        """Start the 30-second health check interval (C-1: set_interval)."""
        # Run an immediate check, then every 30s
        self.set_interval(_CHECK_INTERVAL_SECONDS, self._run_all_checks)
        # Fire an initial check immediately (non-blocking task)
        asyncio.get_event_loop().call_soon(
            lambda: asyncio.ensure_future(self._run_all_checks())
        )

    # ------------------------------------------------------------------
    # Health checking
    # ------------------------------------------------------------------

    async def _run_all_checks(self) -> None:
        """Run all service health checks concurrently (TUI-2, AR-19)."""
        self._check_count += 1
        footer = self.query_one("#health-footer", Label)
        footer.update(f"[dim]checking… ({self._check_count})[/dim]")

        tasks = []
        for svc_name, _, host_key, port_key, fallback_host, fallback_port in _SERVICE_DEFS:
            host = self._config.get(host_key) or fallback_host
            port = int(self._config.get(port_key) or fallback_port)
            tasks.append(self._check_service(svc_name, str(host), port))

        results = await asyncio.gather(*tasks, return_exceptions=True)

        for (svc_name, _, _, _, _, _), result in zip(_SERVICE_DEFS, results):
            if isinstance(result, BaseException):
                status, latency_ms = "error", None
                logger.warning("HealthTab: check for %s raised: %s", svc_name, result)
            else:
                status, latency_ms = result

            # Update the card
            if svc_name in self._cards:
                self._cards[svc_name].update_status(status, latency_ms)

            # Post HealthUpdate for other widgets to consume
            from nexus_sdlc.tui.messages import HealthUpdate  # deferred import
            self.post_message(HealthUpdate(svc_name, status, latency_ms))

        footer.update(f"[dim]last checked: check #{self._check_count}[/dim]")

    async def _check_service(
        self, service_name: str, host: str, port: int
    ) -> tuple[str, float | None]:
        """
        Probe a service via TCP connect + optional protocol handshake.

        Returns (status, latency_ms).  Never raises — returns ("error", None)
        on any exception.

        AR-19: asyncio.open_connection only — no sync socket calls.
        """
        t0 = time.monotonic()
        try:
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(host, port),
                timeout=_PROBE_TIMEOUT_SECONDS,
            )
        except (OSError, asyncio.TimeoutError) as exc:
            logger.debug("HealthTab: %s unreachable (%s:%d): %s", service_name, host, port, exc)
            return "error", None

        latency_ms = (time.monotonic() - t0) * 1000.0

        try:
            # Valkey: send PING and verify +PONG
            if service_name == "valkey":
                writer.write(b"PING\r\n")
                await writer.drain()
                try:
                    response = await asyncio.wait_for(reader.read(128), timeout=2.0)
                    if b"PONG" not in response and b"+PONG" not in response:
                        return "degraded", latency_ms
                except asyncio.TimeoutError:
                    return "degraded", latency_ms

        finally:
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:  # noqa: BLE001
                pass

        return "healthy", latency_ms

    # ------------------------------------------------------------------
    # Latency sparkline helper (used by external callers if needed)
    # ------------------------------------------------------------------

    def get_sparkline(self, service_name: str) -> str:
        """Return the current sparkline string for *service_name*."""
        card = self._cards.get(service_name)
        if card is None:
            return " " * _SPARKLINE_LEN
        return card._build_sparkline()
