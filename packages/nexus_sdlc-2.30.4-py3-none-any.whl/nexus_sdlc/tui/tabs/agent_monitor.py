"""
nexus_sdlc.tui.tabs.agent_monitor — AgentMonitorTab widget.

Displays a live feed of all dispatched agent runs, with a detail pane
showing token counts, cost, and a tail of the live output.

Architecture
------------
- Subscribes to ValkeyEventReceived messages posted by the app-level bridge task.
- Handles event types: "agent.started", "agent.completed", "agent.failed".
- Refreshes elapsed timers every 5s via set_interval() (C-1 compliance).
- Never reads ValkeyConsumer directly (AR-11, TUI-2).

Anti-requirements enforced
--------------------------
AR-19: No synchronous I/O on the event loop.
TUI-2: Message handler only — no direct Valkey access.
C-1:   Timer polling via set_interval(), not asyncio.sleep().
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from rich.markup import escape as markup_escape
from textual import events
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal
from textual.widget import Widget
from textual.widgets import DataTable, Label, RichLog, Static

from nexus_sdlc.tui.messages import ValkeyEventReceived

logger = logging.getLogger(__name__)

# Status badge glyphs (plain unicode — no Rich markup in the glyph itself)
_GLYPH_QUEUED = "○"
_GLYPH_RUNNING = "◐"
_GLYPH_DONE = "●"
_GLYPH_FAILED = "⚠"


class AgentMonitorTab(Widget):
    """F4 Agents tab — live agent activity feed across all projects.

    Layout (horizontal split):
    - Left 30%: DataTable with agent rows (type, project:task, time, elapsed)
    - Right 70%: Detail pane for selected agent (header, stats, live output tail)

    Badge: _unread drives the [·] dot badge on F4 when the tab is not active.
    Refresh: elapsed timers updated every 5s via set_interval().
    """

    DEFAULT_CSS = """
    AgentMonitorTab {
        layout: vertical;
    }
    #agent-filter-bar {
        height: 1;
        padding: 0 1;
        background: $surface-darken-1;
    }
    #agent-split {
        layout: horizontal;
        height: 1fr;
    }
    #agent-feed {
        width: 30%;
        height: 100%;
    }
    #agent-detail {
        width: 70%;
        height: 100%;
        padding: 0 1;
    }
    #agent-live-output {
        height: 1fr;
        border: solid $primary-darken-2;
    }
    """

    BINDINGS = [
        Binding("r", "refresh", "Refresh", show=True),
    ]

    def __init__(self) -> None:
        super().__init__()
        # Keyed by run_id; value: agent data dict
        self._agents: dict[str, dict[str, Any]] = {}
        self._filter_project: str = "all"
        self._filter_status: str = "all"
        self._show_running_only: bool = False
        # Drives [·] badge on F4 tab when content arrives while not focused
        self._unread: bool = False
        # Track selected run_id for detail pane
        self._selected_run_id: str | None = None
        # DataTable column keys — stored after add_columns() so update_cell
        # uses the actual ColumnKey objects rather than label strings.
        self._col_status: Any = None
        self._col_elapsed: Any = None

    def compose(self) -> ComposeResult:
        yield Label(
            "Filter: [ All projects ]  [ All stages ]  [ Running only: OFF ]   "
            "Auto-refresh: ON",
            id="agent-filter-bar",
        )
        with Horizontal(id="agent-split"):
            table = DataTable(id="agent-feed")
            table.cursor_type = "row"
            yield table
            with Container(id="agent-detail"):
                yield Label("No agent selected", id="agent-detail-header")
                yield Label("", id="agent-detail-stats")
                yield RichLog(id="agent-live-output", max_lines=20, highlight=True)

    def on_mount(self) -> None:
        """Set up DataTable columns and refresh timer (C-1)."""
        table = self.query_one("#agent-feed", DataTable)
        table.add_columns("Status", "Agent Type", "Project:Task", "Started", "Elapsed")
        # Refresh elapsed timers every 5s — uses set_interval per C-1
        self.set_interval(5.0, self._refresh_display)

    # -------------------------------------------------------------------------
    # Valkey event handler (TUI-2: message-only subscription)
    # -------------------------------------------------------------------------

    def on_valkey_event_received(self, message: ValkeyEventReceived) -> None:
        """Handle agent lifecycle events from the Valkey bridge."""
        event_type = message.event_type
        if event_type not in ("agent.started", "agent.completed", "agent.failed"):
            return

        payload = message.payload
        run_id: str = payload.get("run_id", message.stream_id or f"anon-{len(self._agents)}")

        if event_type == "agent.started":
            self._agents[run_id] = {
                "run_id": run_id,
                "agent_type": payload.get("agent_type", "unknown"),
                "project": payload.get("project", "?"),
                "task_id": payload.get("task_id", "?"),
                "model": payload.get("model", "?"),
                "status": "running",
                "glyph": _GLYPH_RUNNING,
                "started_at": datetime.now(tz=timezone.utc),
                "completed_at": None,
                "tokens_in": payload.get("tokens_in", 0),
                "tokens_out": payload.get("tokens_out", 0),
                "cost_usd": payload.get("cost_usd", 0.0),
                "retries": payload.get("retries", 0),
                "output_lines": [],
            }
            self._add_table_row(run_id)

        elif event_type == "agent.completed":
            if run_id in self._agents:
                agent = self._agents[run_id]
                agent["status"] = "done"
                agent["glyph"] = _GLYPH_DONE
                agent["completed_at"] = datetime.now(tz=timezone.utc)
                agent["tokens_in"] = payload.get("tokens_in", agent["tokens_in"])
                agent["tokens_out"] = payload.get("tokens_out", agent["tokens_out"])
                agent["cost_usd"] = payload.get("cost_usd", agent["cost_usd"])
                self._update_table_row(run_id)
            else:
                # Completed event arrived without a corresponding started event
                self._agents[run_id] = {
                    "run_id": run_id,
                    "agent_type": payload.get("agent_type", "unknown"),
                    "project": payload.get("project", "?"),
                    "task_id": payload.get("task_id", "?"),
                    "model": payload.get("model", "?"),
                    "status": "done",
                    "glyph": _GLYPH_DONE,
                    "started_at": None,
                    "completed_at": datetime.now(tz=timezone.utc),
                    "tokens_in": payload.get("tokens_in", 0),
                    "tokens_out": payload.get("tokens_out", 0),
                    "cost_usd": payload.get("cost_usd", 0.0),
                    "retries": payload.get("retries", 0),
                    "output_lines": [],
                }
                self._add_table_row(run_id)

        elif event_type == "agent.failed":
            if run_id in self._agents:
                agent = self._agents[run_id]
                agent["status"] = "failed"
                agent["glyph"] = _GLYPH_FAILED
                agent["completed_at"] = datetime.now(tz=timezone.utc)
                self._update_table_row(run_id)
            else:
                self._agents[run_id] = {
                    "run_id": run_id,
                    "agent_type": payload.get("agent_type", "unknown"),
                    "project": payload.get("project", "?"),
                    "task_id": payload.get("task_id", "?"),
                    "model": payload.get("model", "?"),
                    "status": "failed",
                    "glyph": _GLYPH_FAILED,
                    "started_at": None,
                    "completed_at": datetime.now(tz=timezone.utc),
                    "tokens_in": 0,
                    "tokens_out": 0,
                    "cost_usd": 0.0,
                    "retries": 0,
                    "output_lines": [],
                }
                self._add_table_row(run_id)

        # Set unread badge if F4 is not the active tab
        try:
            from textual.widgets import TabbedContent
            tc = self.app.query_one(TabbedContent)
            if tc.active != "agents":
                self._unread = True
        except Exception:
            self._unread = True

    # -------------------------------------------------------------------------
    # DataTable interaction
    # -------------------------------------------------------------------------

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        """Populate detail pane when user selects a row."""
        table = self.query_one("#agent-feed", DataTable)
        try:
            # Row key is the run_id stored as the row_key
            run_id_key = str(event.row_key.value) if event.row_key else None
        except Exception:
            run_id_key = None

        if run_id_key and run_id_key in self._agents:
            self._selected_run_id = run_id_key
            self._populate_detail(run_id_key)

    # -------------------------------------------------------------------------
    # Timer refresh
    # -------------------------------------------------------------------------

    def _refresh_display(self) -> None:
        """Update elapsed time column for running agents and filter display."""
        table = self.query_one("#agent-feed", DataTable)
        now = datetime.now(tz=timezone.utc)

        for run_id, agent in self._agents.items():
            if agent["status"] == "running" and agent["started_at"]:
                elapsed = int((now - agent["started_at"]).total_seconds())
                elapsed_str = _format_elapsed(elapsed)
                try:
                    # Update the Elapsed column (index 4) for this row
                    table.update_cell(run_id, "Elapsed", elapsed_str)
                except Exception:
                    pass

    def action_refresh(self) -> None:
        """Force-refresh the display (R key)."""
        self._refresh_display()

    # -------------------------------------------------------------------------
    # Internal helpers
    # -------------------------------------------------------------------------

    def _add_table_row(self, run_id: str) -> None:
        """Add a new row to the DataTable for run_id."""
        agent = self._agents[run_id]
        table = self.query_one("#agent-feed", DataTable)
        project_task = f"{agent['project']}:{agent['task_id']}"
        started_str = (
            agent["started_at"].strftime("%H:%M:%S") if agent["started_at"] else "?"
        )
        elapsed_str = "0s" if agent["started_at"] else "?"
        try:
            table.add_row(
                agent["glyph"],
                agent["agent_type"],
                project_task,
                started_str,
                elapsed_str,
                key=run_id,
            )
        except Exception as exc:
            logger.debug("Failed to add DataTable row for %s: %s", run_id, exc)

    def _update_table_row(self, run_id: str) -> None:
        """Update an existing row's status glyph and elapsed time."""
        agent = self._agents[run_id]
        table = self.query_one("#agent-feed", DataTable)
        now = datetime.now(tz=timezone.utc)
        if agent["completed_at"] and agent["started_at"]:
            elapsed = int((agent["completed_at"] - agent["started_at"]).total_seconds())
            elapsed_str = _format_elapsed(elapsed)
        else:
            elapsed_str = "?"
        try:
            table.update_cell(run_id, "Status", agent["glyph"])
            table.update_cell(run_id, "Elapsed", elapsed_str)
        except Exception as exc:
            logger.debug("Failed to update DataTable row for %s: %s", run_id, exc)

    def _populate_detail(self, run_id: str) -> None:
        """Fill the detail pane widgets for the selected agent."""
        agent = self._agents[run_id]
        header = self.query_one("#agent-detail-header", Label)
        stats = self.query_one("#agent-detail-stats", Label)
        output = self.query_one("#agent-live-output", RichLog)

        header.update(
            f"Agent: {agent['agent_type']}  Project: {agent['project']}  "
            f"Model: {agent['model']}  Run ID: {run_id}"
        )
        stats.update(
            f"Tokens in: {agent['tokens_in']}  out: {agent['tokens_out']}  "
            f"Cost: ${agent['cost_usd']:.4f}  Retries: {agent['retries']}"
        )
        output.clear()
        for line in agent.get("output_lines", []):
            output.write(markup_escape(str(line)))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _format_elapsed(seconds: int) -> str:
    """Format elapsed seconds as Xm Ys or Xs."""
    if seconds >= 60:
        minutes, secs = divmod(seconds, 60)
        return f"{minutes}m{secs}s"
    return f"{seconds}s"
