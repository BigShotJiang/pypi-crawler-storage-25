"""
nexus_sdlc.tui.tabs.memory — MemoryTab widget.

Displays the NebulaGraph memory graph — project-scoped nodes grouped by
type (DECISIONS, PATTERNS, ISSUES, OBSERVATIONS), with a detail pane and
an optional ASCII graph view (G key).

Architecture
------------
- NebulaGraph access via HTTP REST API (no nebula3-python required).
- All HTTP calls dispatched to thread pool via asyncio.to_thread() (AR-19, C-5).
- Refresh timer fires every 30s via set_interval() (C-1 compliance).
- On unreachable: DegradedBanner + HealthUpdate posted + _infra_error_flag set.

Anti-requirements enforced
--------------------------
AR-19: No synchronous HTTP/network calls on the event loop.
C-5:   NebulaGraph calls use asyncio.to_thread() — not asyncio.run().
AR-6:  _execute_ngql() is sync — MUST be called via asyncio.to_thread() only.
"""
from __future__ import annotations

import asyncio
import json
import logging
import re as _re
import urllib.request
from typing import Any

_SLUG_RE = _re.compile(r'^[a-zA-Z][a-zA-Z0-9_-]{0,63}$')

from textual import events
from textual.app import ComposeResult
from textual.containers import Container, Horizontal
from textual.widget import Widget
from textual.widgets import Label, ListItem, ListView

from nexus_sdlc.tui.messages import HealthUpdate
from nexus_sdlc.tui.widgets.degraded_banner import DegradedBanner

logger = logging.getLogger(__name__)

# Node type groupings for the list view
_NODE_TYPE_ORDER = ["DECISION", "PATTERN", "ISSUE", "OBSERVATION"]
_NODE_TYPE_DISPLAY: dict[str, str] = {
    "DECISION": "DECISIONS",
    "PATTERN": "PATTERNS",
    "ISSUE": "ISSUES",
    "OBSERVATION": "OBSERVATIONS",
}


class MemoryTab(Widget):
    """F6 Memory tab — NebulaGraph project memory browser.

    Layout (horizontal split):
    - Left 30%: ListView — nodes grouped by type
    - Right 70%: Detail pane (node content, relationships, actions)

    G key toggles ASCII graph view.
    """

    DEFAULT_CSS = """
    MemoryTab {
        layout: vertical;
    }
    #memory-header {
        height: 1;
        padding: 0 1;
        background: $surface-darken-1;
    }
    #memory-split {
        layout: horizontal;
        height: 1fr;
    }
    #memory-node-list {
        width: 30%;
        height: 100%;
        border: solid $primary-darken-2;
    }
    #memory-node-detail {
        width: 70%;
        height: 100%;
        padding: 1;
        border: solid $primary-darken-2;
    }
    """

    def __init__(self) -> None:
        super().__init__()
        # HTTP client config — set during on_mount from app.config
        self._nebula_host: str = "localhost"
        self._nebula_port: int = 9669
        self._nebula_reachable: bool = True
        self._memory_nodes: list[dict[str, Any]] = []
        self._selected_node: dict[str, Any] | None = None
        self._graph_view: bool = False

    def compose(self) -> ComposeResult:
        yield Label(
            "MEMORY   NebulaGraph: unknown   Space: —   Scope: —",
            id="memory-header",
        )
        with Horizontal(id="memory-split"):
            yield ListView(id="memory-node-list")
            yield Label(
                "[dim]Select a node to view details. Press G to toggle graph view.[/dim]",
                id="memory-node-detail",
            )

    def on_mount(self) -> None:
        """Configure NebulaGraph connection and start loading nodes (C-1)."""
        try:
            self._nebula_host = self.app.config.get("nebula.host", "localhost")
            self._nebula_port = int(self.app.config.get("nebula.port", 9669))
        except Exception:
            pass

        asyncio.create_task(self._connect_nebula(), name="nebula-connect")
        self.set_interval(30.0, self._refresh_nodes)

    # -------------------------------------------------------------------------
    # NebulaGraph connection (HTTP REST — no nebula3-python)
    # -------------------------------------------------------------------------

    async def _connect_nebula(self) -> None:
        """Verify NebulaGraph HTTP endpoint reachability and load nodes.

        Uses urllib (sync) via asyncio.to_thread() — AR-19 / C-5 compliance.
        """
        url = f"http://{self._nebula_host}:{self._nebula_port}/api/v1/status"
        try:
            status = await asyncio.to_thread(_check_nebula_http, url)
            if status:
                self._nebula_reachable = True
                self._update_header("healthy")
                asyncio.create_task(self._load_nodes(), name="nebula-load-nodes")
            else:
                self._handle_nebula_unreachable("HTTP endpoint returned non-OK status")
        except Exception as exc:
            self._handle_nebula_unreachable(str(exc))

    def _refresh_nodes(self) -> None:
        """Timer callback — trigger async reload (C-1: set_interval fires this)."""
        if self._nebula_reachable:
            asyncio.create_task(self._load_nodes(), name="nebula-refresh")

    async def _load_nodes(self) -> None:
        """Query NebulaGraph for nodes in the current project space.

        AR-19 / C-5 / AR-6: _execute_ngql() is sync, called via to_thread().
        """
        try:
            space = self.app.config.get("project.slug", "nexus")
        except Exception:
            space = "nexus"

        if not _SLUG_RE.match(str(space)):
            space = "nexus"  # safe default — reject invalid slug before nGQL interpolation

        ngql = f"USE {space}; MATCH (n) RETURN n LIMIT 100;"

        try:
            raw_result = await asyncio.to_thread(
                self._execute_ngql,
                ngql,
                space,
            )
            self._memory_nodes = self._parse_nodes(raw_result)
            self._render_node_list()
        except Exception as exc:
            logger.warning("Failed to load NebulaGraph nodes: %s", exc)
            self._handle_nebula_unreachable(str(exc))

    # -------------------------------------------------------------------------
    # Sync helpers — called via asyncio.to_thread() ONLY (AR-6, AR-19)
    # -------------------------------------------------------------------------

    def _execute_ngql(self, ngql: str, space: str = "nexus") -> dict[str, Any]:
        """Execute an nGQL statement via NebulaGraph HTTP API.

        SYNC — must be called via asyncio.to_thread() only (AR-6).
        Uses the NebulaGraph HTTP API endpoint.

        Parameters
        ----------
        ngql:
            The nGQL query string to execute.
        space:
            NebulaGraph graph space name.

        Returns
        -------
        dict
            Parsed JSON response from the NebulaGraph HTTP API.
        """
        url = f"http://{self._nebula_host}:{self._nebula_port}/api/v1/execute"
        payload = json.dumps({"gql": ngql}).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            raw = resp.read()
        return json.loads(raw) if raw else {}

    def _parse_nodes(self, result: dict[str, Any]) -> list[dict[str, Any]]:
        """Parse NebulaGraph HTTP response into a list of node dicts.

        SYNC — called from _load_nodes via asyncio.to_thread result processing.
        Handles the NebulaGraph REST response structure gracefully.
        """
        nodes: list[dict[str, Any]] = []
        try:
            # NebulaGraph HTTP API returns results under "results" key
            results = result.get("results", [result]) if isinstance(result, dict) else []
            for result_block in results:
                rows = result_block.get("data", {}).get("rows", [])
                columns = result_block.get("data", {}).get("columns", [])
                for row in rows:
                    node: dict[str, Any] = {}
                    for col_idx, col_name in enumerate(columns):
                        if col_idx < len(row):
                            node[col_name] = row[col_idx]
                    # Extract standard node fields if available
                    raw_node = node.get("n", node)
                    if isinstance(raw_node, dict):
                        nodes.append({
                            "id": raw_node.get("id", raw_node.get("vid", "?")),
                            "type": _infer_node_type(raw_node),
                            "props": raw_node.get("props", raw_node),
                            "summary": _extract_summary(raw_node),
                            "tags": raw_node.get("tags", []),
                        })
        except Exception as exc:
            logger.debug("Node parse error: %s", exc)
        return nodes

    # -------------------------------------------------------------------------
    # Rendering
    # -------------------------------------------------------------------------

    def _render_node_list(self) -> None:
        """Populate the ListView with nodes grouped by type."""
        try:
            node_list = self.query_one("#memory-node-list", ListView)
            node_list.clear()

            if not self._memory_nodes:
                node_list.append(ListItem(Label("[dim]No nodes found.[/dim]")))
                self._update_header("healthy")
                return

            # Group nodes by type
            grouped: dict[str, list[dict[str, Any]]] = {}
            for node in self._memory_nodes:
                ntype = node.get("type", "OBSERVATION").upper()
                grouped.setdefault(ntype, []).append(node)

            # Render in canonical order, then any extras
            rendered_types: list[str] = []
            for ntype in _NODE_TYPE_ORDER:
                if ntype in grouped:
                    rendered_types.append(ntype)
            for ntype in grouped:
                if ntype not in rendered_types:
                    rendered_types.append(ntype)

            for ntype in rendered_types:
                nodes_of_type = grouped[ntype]
                display_name = _NODE_TYPE_DISPLAY.get(ntype, ntype)
                # Section header
                node_list.append(
                    ListItem(Label(f"[bold dim]── {display_name} ({len(nodes_of_type)}) ──[/bold dim]"))
                )
                for node in nodes_of_type:
                    summary = node.get("summary", str(node.get("id", "?")))
                    node_list.append(
                        ListItem(Label(f"  {summary[:50]}"))
                    )

            self._update_header("healthy")
        except Exception as exc:
            logger.debug("Failed to render node list: %s", exc)

    def _update_header(self, nebula_status: str) -> None:
        """Update the memory tab header with current NebulaGraph status."""
        try:
            space = self.app.config.get("project.slug", "nexus")
        except Exception:
            space = "nexus"

        status_markup = {
            "healthy": "[green]healthy[/green]",
            "error": "[red]unreachable[/red]",
            "unknown": "[dim]unknown[/dim]",
        }.get(nebula_status, f"[dim]{nebula_status}[/dim]")

        try:
            header = self.query_one("#memory-header", Label)
            header.update(
                f"MEMORY   NebulaGraph: {status_markup}   "
                f"Space: {space}   Scope: {space}   "
                f"[dim]G: toggle graph view[/dim]"
            )
        except Exception:
            pass

    # -------------------------------------------------------------------------
    # ListView selection
    # -------------------------------------------------------------------------

    def on_list_view_highlighted(self, event: ListView.Highlighted) -> None:
        """Show detail for the highlighted node."""
        try:
            node_list = self.query_one("#memory-node-list", ListView)
            items = list(node_list.query(ListItem))
            for idx, item in enumerate(items):
                if item is event.item:
                    # Map list index back to node — account for section headers
                    node = self._node_for_list_idx(idx)
                    if node is not None:
                        self._selected_node = node
                        self._populate_detail(node)
                    break
        except Exception:
            pass

    def _node_for_list_idx(self, list_idx: int) -> dict[str, Any] | None:
        """Map a ListView item index to the corresponding node dict.

        Section header items don't correspond to nodes — return None for them.
        """
        if not self._memory_nodes:
            return None

        # Rebuild the same grouping order used in _render_node_list
        grouped: dict[str, list[dict[str, Any]]] = {}
        for node in self._memory_nodes:
            ntype = node.get("type", "OBSERVATION").upper()
            grouped.setdefault(ntype, []).append(node)

        rendered_types: list[str] = []
        for ntype in _NODE_TYPE_ORDER:
            if ntype in grouped:
                rendered_types.append(ntype)
        for ntype in grouped:
            if ntype not in rendered_types:
                rendered_types.append(ntype)

        cursor = 0
        for ntype in rendered_types:
            nodes_of_type = grouped[ntype]
            # Section header occupies one index
            if cursor == list_idx:
                return None  # header row — no node
            cursor += 1
            for node in nodes_of_type:
                if cursor == list_idx:
                    return node
                cursor += 1
        return None

    def _populate_detail(self, node: dict[str, Any]) -> None:
        """Fill the detail pane for the selected node."""
        if self._graph_view:
            self._render_graph()
            return

        node_id = node.get("id", "?")
        ntype = node.get("type", "?")
        summary = node.get("summary", "—")
        props = node.get("props", {})
        tags = node.get("tags", [])

        detail = (
            f"[bold]{ntype}[/bold]   ID: {node_id}\n\n"
            f"{summary}\n"
        )
        if tags:
            detail += f"\n[dim]Tags:[/dim] {', '.join(str(t) for t in tags)}\n"
        if isinstance(props, dict):
            detail += "\n[dim]Properties:[/dim]\n"
            for k, v in list(props.items())[:10]:
                if not k.startswith("__"):
                    detail += f"  {k}: {v}\n"

        try:
            self.query_one("#memory-node-detail", Label).update(detail)
        except Exception:
            pass

    # -------------------------------------------------------------------------
    # Key handler — G toggles graph view
    # -------------------------------------------------------------------------

    def on_key(self, event: events.Key) -> None:
        """Toggle ASCII graph view on G keypress."""
        if event.key == "g":
            self._graph_view = not self._graph_view
            if self._graph_view:
                self._render_graph()
            elif self._selected_node is not None:
                self._populate_detail(self._selected_node)
            else:
                try:
                    self.query_one("#memory-node-detail", Label).update(
                        "[dim]Select a node to view details.[/dim]"
                    )
                except Exception:
                    pass

    def _render_graph(self) -> None:
        """Render a simple ASCII graph of loaded nodes and their relationships.

        Uses box-drawing characters. This is in-terminal ASCII art only —
        no GUI graph library is used.
        """
        if not self._memory_nodes:
            try:
                self.query_one("#memory-node-detail", Label).update(
                    "[dim]No nodes to display in graph view.[/dim]"
                )
            except Exception:
                pass
            return

        lines: list[str] = ["[bold]ASCII Graph View[/bold]  (G to return to detail)\n"]

        # Group by type for a simple tier layout
        grouped: dict[str, list[dict[str, Any]]] = {}
        for node in self._memory_nodes:
            ntype = node.get("type", "OBSERVATION").upper()
            grouped.setdefault(ntype, []).append(node)

        for tier_idx, ntype in enumerate(_NODE_TYPE_ORDER):
            nodes_of_type = grouped.get(ntype, [])
            if not nodes_of_type:
                continue

            display_name = _NODE_TYPE_DISPLAY.get(ntype, ntype)
            lines.append(f"[bold dim]┌── {display_name} ──────────────────────────┐[/bold dim]")

            for node in nodes_of_type[:8]:  # Cap at 8 nodes per tier for readability
                summary = node.get("summary", str(node.get("id", "?")))
                node_id = str(node.get("id", "?"))[:10]
                lines.append(f"│  ● [{node_id}] {summary[:40]}")

            lines.append("[dim]└──────────────────────────────────────────┘[/dim]")

            # Draw connector to next tier if nodes exist below
            remaining_types = _NODE_TYPE_ORDER[tier_idx + 1:]
            has_next = any(grouped.get(t) for t in remaining_types)
            if has_next:
                lines.append("         │")
                lines.append("         └──────────────────────────────►")

        try:
            self.query_one("#memory-node-detail", Label).update("\n".join(lines))
        except Exception:
            pass

    # -------------------------------------------------------------------------
    # Degraded state handling (arch-frontend.md §5.5)
    # -------------------------------------------------------------------------

    def _handle_nebula_unreachable(self, reason: str) -> None:
        """Handle NebulaGraph unreachability per arch-frontend.md §5.5.

        1. Mount DegradedBanner replacing node list area.
        2. Post HealthUpdate(service_name="nebula", status="error").
        3. Set self.app._infra_error_flag = True.
        """
        self._nebula_reachable = False
        self._update_header("error")

        # 1. Mount DegradedBanner
        try:
            existing = self.query(DegradedBanner)
            if not existing:
                self.mount(
                    DegradedBanner(
                        service="NebulaGraph",
                        message=f"Memory graph unavailable — NebulaGraph unreachable: {reason}",
                        dismissible=True,
                    )
                )
        except Exception as exc:
            logger.debug("Failed to mount NebulaGraph DegradedBanner: %s", exc)

        # 2. Post HealthUpdate
        try:
            self.app.post_message(
                HealthUpdate(service_name="nebula", status="error", latency_ms=None)
            )
        except Exception as exc:
            logger.debug("Failed to post HealthUpdate: %s", exc)

        # 3. Set _infra_error_flag
        try:
            self.app._infra_error_flag = True
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Module-level sync helpers (called via asyncio.to_thread() only)
# ---------------------------------------------------------------------------

def _check_nebula_http(url: str) -> bool:
    """Check NebulaGraph HTTP endpoint reachability.

    SYNC — called via asyncio.to_thread() only (AR-19).
    Returns True if HTTP 200 OK, False otherwise.
    """
    try:
        req = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(req, timeout=3) as resp:
            return resp.status == 200
    except Exception:
        return False


def _infer_node_type(node: dict[str, Any]) -> str:
    """Infer the node type from tags or properties.

    Tries node["tags"] first, then falls back to node["type"] or "OBSERVATION".
    """
    tags = node.get("tags", [])
    if tags:
        tag = tags[0] if isinstance(tags, list) and tags else str(tags)
        return str(tag).upper()
    return str(node.get("type", node.get("label", "OBSERVATION"))).upper()


def _extract_summary(node: dict[str, Any]) -> str:
    """Extract a human-readable summary from a node dict.

    Checks common property names: summary, title, content, description.
    Falls back to the node ID.
    """
    props = node.get("props", node)
    if isinstance(props, dict):
        for key in ("summary", "title", "content", "description", "name"):
            val = props.get(key)
            if val and isinstance(val, str):
                return val[:80]
    return str(node.get("id", node.get("vid", "?")))
