"""
nexus_sdlc.cli.main — Typer application entry point.

Entry point registered in pyproject.toml:
    nexus = "nexus_sdlc.cli.main:app"

Startup order (enforced):
  1. check_recursive_invocation()  — AR-7: always first, before any logging
  2. _configure_logging()          — sets up RedactingFormatter on all handlers
  3. load ~/.nexus-env             — non-blocking if absent

INV-09: RedactingFormatter applied to ALL logging handlers.
"""
from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import ClassVar, Optional

import typer

from nexus_sdlc.cli.guards import check_recursive_invocation
from nexus_sdlc.cli.commands import health, run, sessions, setup, version
from nexus_sdlc.cli.commands import tui as tui_cmd_module
from nexus_sdlc.config.loader import NexusConfigLoader

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Typer app
# ---------------------------------------------------------------------------

app = typer.Typer(
    name="nexus",
    help="Nexus SDLC CLI — structured AI software development.",
    add_completion=True,
    no_args_is_help=True,
)

# Register sub-apps
app.add_typer(sessions.app, name="sessions", help="Manage pipeline sessions.")
app.command("dispatch")(run.dispatch_cmd)
app.command("discover")(run.discover_cmd)
app.command("health")(health.health_cmd)
app.command("setup")(setup.setup_cmd)
app.command("version")(version.version_cmd)
app.command("tui")(tui_cmd_module.tui_cmd)


# ---------------------------------------------------------------------------
# Secret-redacting log formatter
# ---------------------------------------------------------------------------


class RedactingFormatter(logging.Formatter):
    """
    Log formatter that redacts ``NEXUS_MCP_SECRET`` from all output.

    Applied to every handler attached to the root logger — AR-10 enforcement.
    The secret is set once at startup from the environment; it is class-level
    (shared across all formatter instances) so a single assignment protects
    every handler.
    """

    _secret: ClassVar[Optional[str]] = None

    def format(self, record: logging.LogRecord) -> str:
        msg = super().format(record)
        if self._secret:
            msg = msg.replace(self._secret, "[REDACTED]")
        return msg


# ---------------------------------------------------------------------------
# Logging configuration
# ---------------------------------------------------------------------------


def _configure_logging(level: str = "WARNING") -> None:
    """
    Configure the root logger with :class:`RedactingFormatter` on all handlers.

    If ``NEXUS_MCP_SECRET`` is present in the environment, its value is
    registered with :class:`RedactingFormatter` so it is never emitted in any
    log line (INV-09).

    Parameters
    ----------
    level:
        Log level string (e.g. "INFO", "DEBUG").  Defaults to WARNING so the
        CLI is quiet unless ``--verbose`` is passed.
    """
    secret = os.environ.get("NEXUS_MCP_SECRET")
    if secret:
        RedactingFormatter._secret = secret

    root = logging.getLogger()

    numeric_level = getattr(logging, level.upper(), logging.WARNING)
    root.setLevel(numeric_level)

    # If no handlers exist yet, add a stderr StreamHandler
    if not root.handlers:
        handler = logging.StreamHandler()
        root.addHandler(handler)

    fmt = RedactingFormatter(
        fmt="%(asctime)s %(levelname)s %(name)s: %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )
    for handler in root.handlers:
        handler.setFormatter(fmt)


# ---------------------------------------------------------------------------
# App callback — runs before every command
# ---------------------------------------------------------------------------


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Enable debug logging."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress all output except errors."),
    no_color: bool = typer.Option(
        False,
        "--no-color",
        envvar="NO_COLOR",
        help="Disable colour output (accessibility).",
    ),
) -> None:
    """Nexus SDLC CLI — structured AI software development."""
    # STEP 1: recursion guard — must be FIRST (AR-7)
    check_recursive_invocation()

    # STEP 2: configure logging with RedactingFormatter
    if verbose:
        log_level = "DEBUG"
    elif quiet:
        log_level = "ERROR"
    else:
        log_level = "WARNING"
    _configure_logging(level=log_level)

    # STEP 3: load ~/.nexus-env (non-blocking if absent)
    _load_nexus_env()

    # STEP 4: refresh formatter secret now that ~/.nexus-env is loaded
    _refresh_formatter_secret()

    if no_color:
        os.environ["NO_COLOR"] = "1"


def _refresh_formatter_secret() -> None:
    """Update RedactingFormatter._secret after ~/.nexus-env has been loaded.

    This must be called after _load_nexus_env() — not before — so that the
    NEXUS_MCP_SECRET loaded from ~/.nexus-env is captured by the formatter.
    """
    secret = os.environ.get("NEXUS_MCP_SECRET")
    if secret:
        RedactingFormatter._secret = secret


def _load_nexus_env() -> None:
    """
    Load ``~/.nexus-env`` into ``os.environ`` (non-blocking if absent).

    Values already set in the environment are NOT overwritten — the environment
    takes precedence over the file, consistent with 4-tier resolution order.
    """
    loader = NexusConfigLoader()
    try:
        parsed = loader.load_nexus_env()
    except Exception as exc:  # noqa: BLE001
        logger.debug("~/.nexus-env load failed (ignored): %s", exc)
        return

    for key, value in parsed.items():
        if key not in os.environ:
            os.environ[key] = value
            logger.debug("Loaded from ~/.nexus-env: %s", key)


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------


def cli() -> None:
    """Package entry point — delegates to the Typer app."""
    app()


if __name__ == "__main__":
    cli()
