"""
nexus_sdlc.cli.commands.setup — ``nexus setup`` command.

Actions (``nexus setup``):
  1. Generate NEXUS_MCP_SECRET if not already set in env or ~/.nexus-env.
  2. Write ~/.nexus-env with NEXUS_MCP_SECRET and NEXUS_MCP_PORT.
     chmod 600 immediately after write — file contains a secret.
  3. Atomically update mcpServers.nexus in ~/.claude/settings.json.
     Write to .tmp file first, then os.replace() — POSIX atomic.
  4. Create ~/.nexus/run/ directory.
  5. Warn if nexus-cli.sh appears earlier in PATH than the nexus binary.
  6. Print confirmation.

``nexus setup --remove-mcp``:
  Atomically remove the mcpServers.nexus entry from settings.json.

Anti-requirements:
  INV-10: os.replace() used for atomic settings.json write.
  MUST NOT use shell=True.
  MUST chmod 600 ~/.nexus-env after every write.
"""
from __future__ import annotations

import json
import logging
import os
import secrets
import shutil
import stat
from pathlib import Path
from typing import Any

import typer

from nexus_sdlc.exceptions import SetupError, SetupSecretWriteError

logger = logging.getLogger(__name__)

_NEXUS_ENV_PATH = Path("~/.nexus-env").expanduser()
_SETTINGS_JSON_PATH = Path("~/.claude/settings.json").expanduser()
_NEXUS_RUN_DIR = Path("~/.nexus/run").expanduser()
_DEFAULT_MCP_PORT = 9337


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _read_settings(path: Path) -> dict[str, Any]:
    """Read settings.json, returning {} if absent or unparseable."""
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        logger.warning("Could not read %s: %s — starting with empty settings", path, exc)
        return {}


def _write_settings_atomic(path: Path, data: dict[str, Any]) -> None:
    """
    Write *data* to *path* atomically via a .tmp intermediate file.

    Uses os.replace() for the rename — POSIX atomic (INV-10).
    """
    tmp = path.with_suffix(".json.tmp")
    try:
        tmp.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
        os.replace(str(tmp), str(path))
    except OSError as exc:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass
        raise SetupError(f"Failed to write {path}: {exc}") from exc


def _get_or_generate_secret(nexus_env_path: Path) -> tuple[str, bool]:
    """
    Return (secret, generated).

    If NEXUS_MCP_SECRET is in the environment, use it (generated=False).
    If ~/.nexus-env exists and contains NEXUS_MCP_SECRET, parse it (generated=False).
    Otherwise generate a new 32-byte hex secret (generated=True).
    """
    # Tier 1: environment
    if env_secret := os.environ.get("NEXUS_MCP_SECRET"):
        return env_secret, False

    # Tier 2: existing ~/.nexus-env file
    if nexus_env_path.exists():
        try:
            from nexus_sdlc.config.loader import NexusConfigLoader
            loader = NexusConfigLoader()
            parsed = loader.load_nexus_env(nexus_env_path)
            if existing := parsed.get("NEXUS_MCP_SECRET"):
                return existing, False
        except Exception as exc:  # noqa: BLE001
            logger.debug("Could not parse existing ~/.nexus-env: %s", exc)

    # Generate new secret
    return secrets.token_hex(32), True


def _write_nexus_env(path: Path, secret: str, port: int) -> None:
    """
    Write ~/.nexus-env with NEXUS_MCP_SECRET and NEXUS_MCP_PORT.
    Immediately chmod 600 — file contains a secret (AR-4 enforcement).

    Raises
    ------
    SetupSecretWriteError:
        If the file cannot be written.
    """
    content = (
        f'export NEXUS_MCP_SECRET="{secret}"\n'
        f'export NEXUS_MCP_PORT="{port}"\n'
    )
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        # CRITICAL: chmod 600 immediately after write
        os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)
    except OSError as exc:
        raise SetupSecretWriteError(
            f"Could not write {path}: {exc}"
        ) from exc


def _build_mcp_entry(secret: str, port: int) -> dict[str, Any]:
    """Return the mcpServers.nexus JSON block."""
    return {
        "command": "python3",
        "args": ["-m", "nexus_sdlc.mcp_server.server"],
        "env": {
            "NEXUS_MCP_SECRET": secret,
            "NEXUS_MCP_PORT": str(port),
        },
    }


def _check_path_conflict() -> None:
    """
    Warn if nexus-cli.sh appears earlier in PATH than the nexus binary.
    CRAWL Gap 3 detection.
    """
    nexus_cli_path = shutil.which("nexus-cli.sh")
    nexus_bin_path = shutil.which("nexus")

    if nexus_cli_path is None or nexus_bin_path is None:
        return

    path_dirs = os.environ.get("PATH", "").split(os.pathsep)
    cli_sh_dir = str(Path(nexus_cli_path).parent)
    nexus_dir = str(Path(nexus_bin_path).parent)

    cli_sh_idx = next((i for i, d in enumerate(path_dirs) if d == cli_sh_dir), None)
    nexus_idx = next((i for i, d in enumerate(path_dirs) if d == nexus_dir), None)

    if cli_sh_idx is not None and nexus_idx is not None and cli_sh_idx < nexus_idx:
        typer.echo(
            "WARNING: nexus-cli.sh found earlier in PATH — may shadow nexus binary.\n"
            f"  nexus-cli.sh: {nexus_cli_path}\n"
            f"  nexus binary: {nexus_bin_path}\n"
            "  Reorder your PATH or remove nexus-cli.sh to resolve.",
            err=True,
        )


# ---------------------------------------------------------------------------
# Command
# ---------------------------------------------------------------------------


def setup_cmd(
    remove_mcp: bool = typer.Option(
        False,
        "--remove-mcp",
        help="Remove the mcpServers.nexus entry from ~/.claude/settings.json.",
    ),
) -> None:
    """Configure nexus: write ~/.nexus-env and register MCP server in Claude settings."""

    # ----------------------------------------------------------------
    # --remove-mcp path: atomically remove mcpServers.nexus
    # ----------------------------------------------------------------
    if remove_mcp:
        settings = _read_settings(_SETTINGS_JSON_PATH)
        mcp_servers: dict = settings.get("mcpServers", {})
        if "nexus" not in mcp_servers:
            typer.echo("mcpServers.nexus is not present in settings.json — nothing to remove.")
            return

        del mcp_servers["nexus"]
        settings["mcpServers"] = mcp_servers

        try:
            _SETTINGS_JSON_PATH.parent.mkdir(parents=True, exist_ok=True)
            _write_settings_atomic(_SETTINGS_JSON_PATH, settings)
        except SetupError as exc:
            typer.echo(f"nexus setup: {exc}", err=True)
            raise typer.Exit(code=1) from exc

        typer.echo("mcpServers.nexus removed from ~/.claude/settings.json.")
        return

    # ----------------------------------------------------------------
    # Normal setup path
    # ----------------------------------------------------------------

    port: int = int(os.environ.get("NEXUS_MCP_PORT", str(_DEFAULT_MCP_PORT)))

    # Step 1: get or generate secret
    secret, generated = _get_or_generate_secret(_NEXUS_ENV_PATH)

    # Step 2: write ~/.nexus-env (chmod 600 is inside _write_nexus_env)
    try:
        _write_nexus_env(_NEXUS_ENV_PATH, secret, port)
    except SetupSecretWriteError as exc:
        typer.echo(f"nexus setup: {exc}", err=True)
        raise typer.Exit(code=1) from exc

    action = "Generated" if generated else "Using existing"
    typer.echo(f"{action} NEXUS_MCP_SECRET — written to {_NEXUS_ENV_PATH} (mode 600).")

    # Step 3: atomically update mcpServers.nexus in ~/.claude/settings.json
    settings = _read_settings(_SETTINGS_JSON_PATH)
    if "mcpServers" not in settings:
        settings["mcpServers"] = {}
    settings["mcpServers"]["nexus"] = _build_mcp_entry(secret, port)

    try:
        _SETTINGS_JSON_PATH.parent.mkdir(parents=True, exist_ok=True)
        _write_settings_atomic(_SETTINGS_JSON_PATH, settings)
    except SetupError as exc:
        typer.echo(f"nexus setup: {exc}", err=True)
        raise typer.Exit(code=1) from exc

    typer.echo(f"mcpServers.nexus written to {_SETTINGS_JSON_PATH}.")

    # Step 4: create ~/.nexus/run/ directory
    try:
        _NEXUS_RUN_DIR.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        typer.echo(
            f"nexus setup: warning — could not create {_NEXUS_RUN_DIR}: {exc}", err=True
        )

    # Step 5: PATH conflict detection
    _check_path_conflict()

    # Step 6: confirmation
    typer.echo("nexus setup complete. Run `nexus dispatch` to start a pipeline.")
