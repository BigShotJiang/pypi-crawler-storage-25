"""
nexus_sdlc.cli.commands.run — ``nexus dispatch`` and ``nexus discover`` commands.

Design notes:
- ``_invoke_claude`` is async; Typer commands are sync — wrapped with asyncio.run().
- StreamJsonReader yields dicts (parsed stream-json events); ``_render_event``
  extracts human-readable text from assistant/result events and prints them.
- SIGINT (Ctrl-C) is handled cleanly: launcher.terminate() sends SIGTERM -> SIGKILL
  to the child process to prevent zombie processes.
- CLAUDECODE stripping and NEXUS_CLI=1 are handled by SubprocessLauncher.__init__.
"""
from __future__ import annotations

import asyncio
import logging
import os
import sys
from typing import AsyncIterator, Optional
from uuid import uuid4

import typer

from nexus_sdlc.exceptions import SubprocessNotFound
from nexus_sdlc.subprocess_launcher.launcher import SubprocessLauncher
from nexus_sdlc.subprocess_launcher.stream_reader import StreamJsonReader

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Stream-json event renderer
# ---------------------------------------------------------------------------


def _render_event(event: dict) -> str | None:
    """
    Extract a human-readable text string from a claude stream-json event.

    Returns None for events that produce no visible output (tool calls,
    internal metadata, etc.).  Unknown event types are logged at DEBUG level.
    """
    event_type = event.get("type")

    if event_type == "assistant":
        # Extract text from content blocks
        parts: list[str] = []
        message = event.get("message", {})
        for block in message.get("content", []):
            if isinstance(block, dict) and block.get("type") == "text":
                text = block.get("text", "")
                if text:
                    parts.append(text)
        return "".join(parts) if parts else None

    if event_type == "result":
        # Final result — print the result text if present
        result_text = event.get("result", "")
        if result_text:
            return result_text
        return None

    if event_type in ("user", "system"):
        # Internal events — suppress from output
        return None

    # Unknown event — log at debug, suppress from stdout
    logger.debug("_render_event: unknown event type %r — suppressed", event_type)
    return None


# ---------------------------------------------------------------------------
# Core async streaming helper
# ---------------------------------------------------------------------------


async def _invoke_claude(
    prompt: str,
    *,
    project_dir: str,
    cwd: str | None = None,
) -> None:
    """
    Spawn a claude subprocess via SubprocessLauncher, stream output to stdout.

    Handles SIGINT (Ctrl-C) gracefully by sending SIGTERM → SIGKILL to the
    child process before re-raising KeyboardInterrupt.

    Parameters
    ----------
    prompt:
        Full prompt string forwarded to ``claude -p``.
    project_dir:
        Project directory — becomes SubprocessLauncher.project_dir.
    cwd:
        Working directory for the subprocess.  Defaults to project_dir.

    Raises
    ------
    SubprocessNotFound:
        claude binary missing from PATH or unauthenticated.
    SystemExit:
        If the subprocess exits with a non-zero return code.
    """
    session_id = str(uuid4())
    launcher = SubprocessLauncher(project_dir=project_dir)
    reader = StreamJsonReader()

    try:
        process = await launcher.spawn(session_id=session_id, prompt=prompt, cwd=cwd)
    except SubprocessNotFound:
        raise

    try:
        assert process.stdout is not None
        async for event in reader.read_lines(
            process.stdout, buffer_bytes=launcher.buffer_bytes
        ):
            rendered = _render_event(event)
            if rendered is not None:
                sys.stdout.write(rendered)
                sys.stdout.flush()

        await process.wait()
    except KeyboardInterrupt:
        print("\nnexus: interrupt received — terminating subprocess...", file=sys.stderr)
        await launcher.terminate(process)
        raise

    if process.returncode not in (0, None):
        logger.debug(
            "claude subprocess exited %s (session=%s)", process.returncode, session_id
        )
        raise SystemExit(process.returncode)


# ---------------------------------------------------------------------------
# dispatch command
# ---------------------------------------------------------------------------


def dispatch_cmd(
    pipeline_type: str = typer.Argument(..., help="Pipeline type (e.g. feature, bugfix)."),
    task_description: str = typer.Argument(..., help="Short description of the task."),
    plan: Optional[str] = typer.Option(None, "--plan", help="Plan file path to pass to dispatch."),
    project: Optional[str] = typer.Option(None, "--project", help="Target project slug."),
) -> None:
    """Run /nexus:dispatch via a claude -p subprocess."""
    parts = ["/nexus:dispatch"]
    if plan:
        parts += ["--plan", plan]
    if project:
        parts += ["--project", project]
    parts += [pipeline_type, f'"{task_description}"']
    prompt = " ".join(parts)

    project_dir = os.getcwd()

    try:
        asyncio.run(_invoke_claude(prompt, project_dir=project_dir))
    except SubprocessNotFound as exc:
        typer.echo(f"nexus: {exc}", err=True)
        raise typer.Exit(code=1) from exc
    except KeyboardInterrupt:
        raise typer.Exit(code=130)


# ---------------------------------------------------------------------------
# discover command
# ---------------------------------------------------------------------------


def discover_cmd(
    goal: str = typer.Argument(..., help="Goal description for discovery."),
    project: Optional[str] = typer.Option(None, "--project", help="Target project slug."),
) -> None:
    """Run /nexus:discover via a claude -p subprocess."""
    parts = ["/nexus:discover"]
    if project:
        parts += ["--project", project]
    parts.append(f'"{goal}"')
    prompt = " ".join(parts)

    project_dir = os.getcwd()

    try:
        asyncio.run(_invoke_claude(prompt, project_dir=project_dir))
    except SubprocessNotFound as exc:
        typer.echo(f"nexus: {exc}", err=True)
        raise typer.Exit(code=1) from exc
    except KeyboardInterrupt:
        raise typer.Exit(code=130)
