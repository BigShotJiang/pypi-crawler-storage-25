"""
nexus_sdlc.cli.commands.tui — ``nexus tui`` Typer command.

Launches the Nexus 8-tab Textual TUI.

Textual is an optional dependency.  Import is deferred so that
``nexus tui --help`` works even without ``pip install 'nexus-sdlc[tui]'``
(AC-1).

TUI-1: MUST NOT call asyncio.run() in this file.  app.run() starts the
Textual event loop.  Any nested asyncio.run() would raise RuntimeError.
"""
from __future__ import annotations

from pathlib import Path

import typer

from nexus_sdlc.config.loader import NexusConfigLoader


def tui_cmd(
    project_dir: Path = typer.Option(
        Path.cwd(),
        "--project-dir",
        "-p",
        help="Project directory for config resolution. Defaults to cwd.",
        exists=False,  # do not require existence — workspace root may be parent
    ),
    no_color: bool = typer.Option(
        False,
        "--no-color",
        envvar="NO_COLOR",
        help="Disable colour output.",
    ),
) -> None:
    """Launch the Nexus TUI — 8-tab terminal interface.

    Requires the optional [tui] extra:

        pip install 'nexus-sdlc[tui]'

    Key bindings once running:

    \\b
        F1–F8 / Ctrl+1–8  Switch tabs
        Ctrl+T             New conversation
        Ctrl+W             Close conversation
        q                  Quit
    """
    # Deferred import — textual is an optional dependency.
    # Fail with an actionable error message rather than a bare ImportError.
    try:
        from nexus_sdlc.tui.app import NexusTUIApp
    except ImportError as exc:
        typer.echo(
            f"Error: Textual not installed. Run: pip install 'nexus-sdlc[tui]'\n{exc}",
            err=True,
        )
        raise typer.Exit(1)

    config = NexusConfigLoader(project_dir=project_dir)

    app = NexusTUIApp(config=config)

    # app.run() starts the Textual event loop — blocks until TUI exits.
    # TUI-1: NEVER call asyncio.run() here; Textual's app.run() handles the
    # event loop internally.
    app.run()


# AC-4 alias — the acceptance test imports this name:
#   python3.11 -c "from nexus_sdlc.cli.commands.tui import tui_command"
tui_command = tui_cmd
