"""
nexus_sdlc.cli.commands.version — ``nexus version`` command.
"""
from __future__ import annotations

import typer

import nexus_sdlc


def version_cmd() -> None:
    """Print the nexus-sdlc version string."""
    typer.echo(f"nexus-sdlc {nexus_sdlc.__version__}")
