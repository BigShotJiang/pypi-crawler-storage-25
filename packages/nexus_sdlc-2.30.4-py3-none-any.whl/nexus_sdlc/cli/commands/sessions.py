"""
nexus_sdlc.cli.commands.sessions — ``nexus sessions`` sub-commands.

Commands:
  nexus sessions list               List all recorded sessions.
  nexus sessions show <session_id>  Show details for a single session.
  nexus sessions clear              Remove all session records (with confirmation).
"""
from __future__ import annotations

import shutil
import sys
from pathlib import Path

import typer

from nexus_sdlc.exceptions import RegistryError
from nexus_sdlc.registry.conversation_registry import ConversationRegistry

app = typer.Typer(help="Manage pipeline sessions.", no_args_is_help=True)


def _make_registry() -> ConversationRegistry:
    """Instantiate a ConversationRegistry and load existing sessions."""
    # register_signal_handler=False avoids double-registration when the
    # CLI is run in a subprocess context (e.g. test runner).
    registry = ConversationRegistry(register_signal_handler=False)
    registry.load()
    return registry


@app.command("list")
def list_cmd(
    limit: int = typer.Option(50, "--limit", "-n", help="Maximum sessions to show."),
    task_id: str = typer.Option("", "--task", "-t", help="Filter by task ID substring."),
) -> None:
    """List recorded sessions ordered by most-recently-active."""
    try:
        registry = _make_registry()
    except RegistryError as exc:
        typer.echo(f"nexus sessions: registry error — {exc}", err=True)
        raise typer.Exit(code=1) from exc

    sessions = registry.list_sessions(limit=limit, task_id=task_id or None)

    if not sessions:
        typer.echo("No sessions found.")
        return

    # Header
    typer.echo(f"{'SESSION ID':<38}  {'CREATED':<20}  {'TURNS':>5}  TITLE")
    typer.echo("-" * 90)

    for s in sessions:
        created = s.created_at.strftime("%Y-%m-%d %H:%M:%S")
        title = s.title[:40] if s.title else "(no title)"
        typer.echo(f"{s.session_id:<38}  {created:<20}  {s.turn_count:>5}  {title}")


@app.command("show")
def show_cmd(
    session_id: str = typer.Argument(..., help="Session UUID to display."),
) -> None:
    """Show details for a single session."""
    try:
        registry = _make_registry()
    except RegistryError as exc:
        typer.echo(f"nexus sessions: registry error — {exc}", err=True)
        raise typer.Exit(code=1) from exc

    record = registry.get_session(session_id)
    if record is None:
        typer.echo(f"nexus sessions: session {session_id!r} not found.", err=True)
        raise typer.Exit(code=1)

    typer.echo(f"Session ID  : {record.session_id}")
    typer.echo(f"Project dir : {record.project_dir}")
    typer.echo(f"Created     : {record.created_at.isoformat()}")
    typer.echo(f"Last active : {record.last_active_at.isoformat()}")
    typer.echo(f"Turns       : {record.turn_count}")
    typer.echo(f"Title       : {record.title or '(none)'}")


@app.command("clear")
def clear_cmd(
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt."),
) -> None:
    """Remove all session records (irreversible)."""
    sessions_dir = Path("~/.nexus/sessions").expanduser()

    if not yes:
        confirmed = typer.confirm(
            f"This will delete all session records in {sessions_dir}. Continue?"
        )
        if not confirmed:
            typer.echo("Aborted.")
            raise typer.Exit(code=0)

    if sessions_dir.exists():
        try:
            shutil.rmtree(sessions_dir)
            sessions_dir.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            typer.echo(f"nexus sessions: failed to clear sessions — {exc}", err=True)
            raise typer.Exit(code=1) from exc

    typer.echo("Sessions cleared.")
