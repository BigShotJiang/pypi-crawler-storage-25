"""
nexus_sdlc.cli.commands.health — ``nexus health`` command.

Probes each infrastructure component directly using the config resolved by
NexusConfigLoader, then prints a summary table.

Components checked:
  - Valkey / Redis TCP reachability
  - NebulaGraph bridge (director-bridge.sh --health)
  - Temporal client connect
  - MCP server (PID file check)

Exit codes:
  0 — all components healthy
  1 — one or more components degraded or unhealthy
"""
from __future__ import annotations

import asyncio
import logging
import os
import socket
from pathlib import Path

import typer

from nexus_sdlc.config.loader import NexusConfigLoader

logger = logging.getLogger(__name__)

# Status labels
_HEALTHY = "healthy"
_DEGRADED = "degraded"
_UNHEALTHY = "unhealthy"
_UNKNOWN = "unknown"


# ---------------------------------------------------------------------------
# Individual probes
# ---------------------------------------------------------------------------


def _probe_tcp(host: str, port: int, timeout: float = 3.0) -> tuple[str, str]:
    """Return (status, detail) for a plain TCP connection attempt."""
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return _HEALTHY, f"{host}:{port} reachable"
    except ConnectionRefusedError:
        return _UNHEALTHY, f"{host}:{port} — connection refused"
    except socket.timeout:
        return _DEGRADED, f"{host}:{port} — timed out"
    except OSError as exc:
        return _UNHEALTHY, f"{host}:{port} — {exc}"


def _probe_mcp_pid(pid_file: Path) -> tuple[str, str]:
    """Check if the MCP server PID file exists and the PID is alive."""
    if not pid_file.exists():
        return _UNKNOWN, "MCP server not started (no PID file)"

    try:
        pid_text = pid_file.read_text(encoding="utf-8").strip()
        pid = int(pid_text)
    except (ValueError, OSError) as exc:
        return _DEGRADED, f"PID file unreadable: {exc}"

    try:
        os.kill(pid, 0)  # signal 0 — existence check
        return _HEALTHY, f"MCP server running (pid={pid})"
    except ProcessLookupError:
        return _UNHEALTHY, f"Stale PID file — process {pid} not found"
    except PermissionError:
        # Process exists but we don't own it
        return _HEALTHY, f"MCP server running (pid={pid}, owned by another user)"


async def _probe_nebula_bridge() -> tuple[str, str]:
    """
    Run director-bridge.sh --health to check NebulaGraph reachability.

    Gracefully degrades if the script is not installed.
    """
    bridge_candidates = [
        Path(__file__).parents[5] / "core" / "director-bridge.sh",
        Path.home() / ".nexus" / "bin" / "director-bridge.sh",
    ]
    bridge = next((p for p in bridge_candidates if p.exists()), None)
    if bridge is None:
        return _UNKNOWN, "director-bridge.sh not found — NebulaGraph check skipped"

    try:
        proc = await asyncio.create_subprocess_exec(
            str(bridge),
            "--health",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await asyncio.wait_for(proc.communicate(), timeout=10.0)
    except FileNotFoundError:
        return _UNKNOWN, "director-bridge.sh not executable"
    except asyncio.TimeoutError:
        return _DEGRADED, "director-bridge.sh --health timed out"

    if proc.returncode == 0:
        return _HEALTHY, "NebulaGraph bridge reachable"
    stderr_text = stderr.decode(errors="replace").strip()
    return _UNHEALTHY, f"bridge exited {proc.returncode}: {stderr_text[:80]}"


# ---------------------------------------------------------------------------
# Command
# ---------------------------------------------------------------------------


def health_cmd() -> None:
    """Check connectivity to Valkey, NebulaGraph bridge, Temporal, and MCP server."""
    loader = NexusConfigLoader(project_dir=os.getcwd())

    valkey_host: str = loader.get("valkey.host", "127.0.0.1")
    valkey_port: int = loader.get("valkey.port", 6379)
    temporal_host: str = os.environ.get("NEXUS_TEMPORAL_HOST", "127.0.0.1")
    temporal_port: int = int(os.environ.get("NEXUS_TEMPORAL_PORT", "7233"))
    pid_file = Path(loader.get("mcp.pid_file", "~/.nexus/run/nexus-mcp.pid")).expanduser()

    results: list[tuple[str, str, str]] = []

    # Valkey TCP probe
    status, detail = _probe_tcp(valkey_host, valkey_port)
    results.append(("Valkey", status, detail))

    # Temporal TCP probe
    status, detail = _probe_tcp(temporal_host, temporal_port)
    results.append(("Temporal", status, detail))

    # MCP server PID check
    status, detail = _probe_mcp_pid(pid_file)
    results.append(("MCP server", status, detail))

    # NebulaGraph bridge (async)
    status, detail = asyncio.run(_probe_nebula_bridge())
    results.append(("NebulaGraph", status, detail))

    # Render table
    typer.echo(f"\n{'COMPONENT':<16}  {'STATUS':<12}  DETAIL")
    typer.echo("-" * 72)
    all_ok = True
    for component, status, detail in results:
        typer.echo(f"{component:<16}  {status:<12}  {detail}")
        if status not in (_HEALTHY, _UNKNOWN):
            all_ok = False
    typer.echo()

    if not all_ok:
        raise typer.Exit(code=1)
