"""
nexus_sdlc.cli.guards — Recursion guard and Claude preflight checks.

INV-03: check_recursive_invocation() uses exact string comparison == "1".
         NOT truthy, NOT in ("1", "true").  AR-7 enforcement point.
"""
from __future__ import annotations

import asyncio
import logging
import os
import sys

from nexus_sdlc.exceptions import SubprocessNotFound

logger = logging.getLogger(__name__)


def check_recursive_invocation() -> None:
    """
    Detect and abort recursive ``nexus`` invocations.

    MUST be called first in ``cli/main.py`` before any other initialisation —
    AR-7 enforcement point.  Uses an exact ``== "1"`` comparison, never truthy.

    Exits with code 78 (EX_CONFIG) if ``NEXUS_CLI=1`` is set in the environment.
    """
    if os.environ.get("NEXUS_CLI") == "1":  # exact "1" — not truthy
        print(
            "nexus: recursive invocation detected (NEXUS_CLI=1 is set).\n"
            "You cannot run nexus from inside a nexus-managed subprocess.\n"
            "If this is unexpected, unset NEXUS_CLI and try again.",
            file=sys.stderr,
        )
        sys.exit(78)  # EX_CONFIG


def preflight_claude() -> None:
    """
    Verify that the ``claude`` binary exists and is reachable.

    Runs ``claude --version`` via asyncio.create_subprocess_exec (no shell=True).
    On failure raises :class:`~nexus_sdlc.exceptions.SubprocessNotFound`.

    CRAWL Gap 6 implementation.

    Raises
    ------
    SubprocessNotFound:
        claude binary not found on PATH, or exits non-zero.
    """

    async def _check() -> None:
        try:
            proc = await asyncio.create_subprocess_exec(
                "claude",
                "--version",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=10.0)
        except FileNotFoundError as exc:
            raise SubprocessNotFound(
                "claude binary not found on PATH. "
                "Install Claude Code (https://claude.ai/download) and ensure it is on your PATH."
            ) from exc
        except asyncio.TimeoutError as exc:
            raise SubprocessNotFound(
                "claude --version timed out — claude may be unauthenticated or frozen."
            ) from exc
        except OSError as exc:
            raise SubprocessNotFound(
                f"Failed to run claude --version: {exc}"
            ) from exc

        if proc.returncode != 0:
            stderr_text = stderr.decode(errors="replace").strip()
            raise SubprocessNotFound(
                f"claude --version exited {proc.returncode}. "
                f"Claude may not be authenticated. stderr: {stderr_text}"
            )

        version_text = stdout.decode(errors="replace").strip()
        logger.debug("claude preflight OK: %s", version_text)

    asyncio.run(_check())
