# hledger-tools

## make-loan-entries
Make loan entries in the specified journal which include interest expense and liability decrements for each entry.

An example:
```
> hledger-tools loan-journal-entries output.journal
Loan Description: Test Loan for $10,000 over 3 Years at 8%
Beginning Date (YYYY-MM-DD): 2026-03-17
Loan Term in Years: 3
Annual Interest Rate (ex: 0.02): 0.08
Currency Code: USD
Loan Amount: 10000
Cash Account: assets:cash
Interest Expense Account: expenses:interest
Liability Account: liabilities:loan

Loan(name='Test Loan for $10,000 over 3 Years at 8%', begin=datetime.date(2026, 3, 17), term_months=36, annual_interest=Decimal('0.080'), principal=Money('0E-25', 'USD'))

2026-03-17 Opening Loan: $10,000.00 ; Opening Loan
   assets:cash  $10,000.00
   liabilities:loan  $-10,000.00

2026-03-17 Test Loan for $10,000 over 3 Years at 8%
   assets:cash  $-313.37
   expenses:interest  $66.67
   liabilities:loan  $246.70

2026-04-17 Test Loan for $10,000 over 3 Years at 8%
   assets:cash  $-313.36
   expenses:interest  $65.02
   liabilities:loan  $248.34

....

2029-01-17 Test Loan for $10,000 over 3 Years at 8%
   assets:cash  $-313.37
   expenses:interest  $4.14
   liabilities:loan  $309.23

2029-02-17 Test Loan for $10,000 over 3 Years at 8%
   assets:cash  $-313.37
   expenses:interest  $2.08
   liabilities:loan  $311.29

2029-03-17 Test Loan for $10,000 over 3 Years at 8%
   assets:cash  $-0.00
   expenses:interest  $0.00
   liabilities:loan  $0.00
```
