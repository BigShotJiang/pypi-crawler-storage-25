import shlex
import shutil
import subprocess
from pathlib import Path
from importlib.resources import files


def _get_jar_path() -> Path:
    jar = files("fastkpcv").joinpath("resources/POSE-1.0-SNAPSHOT.jar")

    if not jar.is_file():
        raise FileNotFoundError(
            "Bundled jar not found: fastkpcv/resources/POSE-1.0-SNAPSHOT.jar"
        )

    return Path(str(jar))


def _check_java() -> None:
    if shutil.which("java") is None:
        raise RuntimeError(
            "Java is not installed or not available in PATH."
        )


def _validate_inputs(
    datapath: str,
    nrows: int,
    x_res: int,
    y_res: int,
    outpath: str,
) -> tuple[Path, Path]:

    if not isinstance(datapath, str) or not datapath.strip():
        raise ValueError("datapath must be a non-empty string.")

    if not isinstance(outpath, str) or not outpath.strip():
        raise ValueError("outpath must be a non-empty string.")

    if not isinstance(nrows, int) or nrows <= 0:
        raise ValueError("nrows must be a positive integer.")

    if not isinstance(x_res, int) or x_res <= 0:
        raise ValueError("x_res must be a positive integer.")

    if not isinstance(y_res, int) or y_res <= 0:
        raise ValueError("y_res must be a positive integer.")

    data_path_obj = Path(datapath).expanduser().resolve()
    out_path_obj = Path(outpath).expanduser().resolve()

    if not data_path_obj.exists():
        raise FileNotFoundError(f"Input file not found: {data_path_obj}")

    out_path_obj.parent.mkdir(parents=True, exist_ok=True)

    return data_path_obj, out_path_obj


def run_java_kpcv(
    datapath: str,
    nrows: int,
    x_res: int,
    y_res: int,
    outpath: str,
) -> None:

    _check_java()

    data_path_obj, out_path_obj = _validate_inputs(
        datapath, nrows, x_res, y_res, outpath
    )

    jar = _get_jar_path()

    cmd = [
        "java",
        "-jar",
        str(jar),
        "--datasetName",
        str(data_path_obj),
        "--outName",
        str(out_path_obj),
        "--nrows",
        str(nrows),
        "--x_res",
        str(x_res),
        "--y_res",
        str(y_res),
    ]

    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        check=False,
    )

    if result.returncode != 0:
        pretty_cmd = " ".join(shlex.quote(x) for x in cmd)
        raise RuntimeError(
            "Java execution failed.\n\n"
            f"Command:\n{pretty_cmd}\n\n"
            f"STDOUT:\n{result.stdout}\n\n"
            f"STDERR:\n{result.stderr}"
        )