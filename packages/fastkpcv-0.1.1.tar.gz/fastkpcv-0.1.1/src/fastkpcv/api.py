from .runner import run_java_kpcv


def run(
    datapath: str,
    nrows: int,
    x_res: int,
    y_res: int,
    outpath: str,
) -> str:
    run_java_kpcv(
        datapath=datapath,
        nrows=nrows,
        x_res=x_res,
        y_res=y_res,
        outpath=outpath,
    )
    return outpath