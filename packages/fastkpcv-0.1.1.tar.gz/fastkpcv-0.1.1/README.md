# fastkpcv

**fastkpcv** is a lightweight Python wrapper for fast density computation for Kernelized Parallel Coordinates Visualization (KPCV).

This package provides an efficient way to compute density results through a simple Python interface.  
The current version focuses on **fast density computation** and outputs the computed results as a **JSON file**.

---

## ✨ Features

- 🚀 High-performance backend implemented in Java
- 🐍 Simple Python interface (`kpcv.run(...)`)
- 📦 Bundled `.jar` — no need to manage Java files manually
- 🔧 Minimal user inputs
- ⚡ Fast density computation for large-scale and high-resolution settings
- 📄 Outputs density computation results as a JSON file

---

## 📦 Installation

Install from PyPI:

```bash
pip install fastkpcv
```
---

## ⚠️ Requirements

- Python >= 3.9
- Java (JRE or JDK) must be installed and available in your system `PATH`

Verify Java installation:

```bash
java -version
```

JDK version 1.8 is suggested.

## Quick Example

```python
import fastkpcv as kpcv

# 1. Specify the input dataset path and output path
data_path = "dataset/diabetes.xlsx"
out_path = "output/diabetes.json"

# 2. Run fastkpcv with the desired resolution and number of rows
kpcv.run(
    datapath=data_path,
    nrows=768,
    x_res=1920,
    y_res=1080,
    outpath=out_path
)

# 3. The visualization result will be written to the output path
print(f"Result saved to: {out_path}")
```

## Notes

- The current release is designed for fast density computation.
- Visualization functionality will be integrated in future versions.
