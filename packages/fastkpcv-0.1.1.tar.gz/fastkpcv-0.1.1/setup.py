import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="fastkpcv",
    version="0.1.1",
    author="fastkpcv-group",
    author_email="156131342@qq.com",
    long_description=long_description,
    long_description_content_type="text/markdown",
    package_dir={"": "src"},
    packages=setuptools.find_packages(where="src"),
    python_requires=">=3.9",
    description="High-performance kernelized parallel coordinates visualization tool in Python",
)




