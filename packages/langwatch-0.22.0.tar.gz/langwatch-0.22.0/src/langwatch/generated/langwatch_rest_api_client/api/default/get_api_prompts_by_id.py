from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_api_prompts_by_id_response_200 import GetApiPromptsByIdResponse200
from ...models.get_api_prompts_by_id_response_400 import GetApiPromptsByIdResponse400
from ...models.get_api_prompts_by_id_response_401 import GetApiPromptsByIdResponse401
from ...models.get_api_prompts_by_id_response_404 import GetApiPromptsByIdResponse404
from ...models.get_api_prompts_by_id_response_422 import GetApiPromptsByIdResponse422
from ...models.get_api_prompts_by_id_response_500 import GetApiPromptsByIdResponse500
from ...types import UNSET, Response, Unset


def _get_kwargs(
    id: str,
    *,
    version: int | Unset = UNSET,
    tag: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["version"] = version

    params["tag"] = tag

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/prompts/{id}".format(
            id=quote(str(id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    GetApiPromptsByIdResponse200
    | GetApiPromptsByIdResponse400
    | GetApiPromptsByIdResponse401
    | GetApiPromptsByIdResponse404
    | GetApiPromptsByIdResponse422
    | GetApiPromptsByIdResponse500
    | None
):
    if response.status_code == 200:
        response_200 = GetApiPromptsByIdResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = GetApiPromptsByIdResponse400.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = GetApiPromptsByIdResponse401.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = GetApiPromptsByIdResponse404.from_dict(response.json())

        return response_404

    if response.status_code == 422:
        response_422 = GetApiPromptsByIdResponse422.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = GetApiPromptsByIdResponse500.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    GetApiPromptsByIdResponse200
    | GetApiPromptsByIdResponse400
    | GetApiPromptsByIdResponse401
    | GetApiPromptsByIdResponse404
    | GetApiPromptsByIdResponse422
    | GetApiPromptsByIdResponse500
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    version: int | Unset = UNSET,
    tag: str | Unset = UNSET,
) -> Response[
    GetApiPromptsByIdResponse200
    | GetApiPromptsByIdResponse400
    | GetApiPromptsByIdResponse401
    | GetApiPromptsByIdResponse404
    | GetApiPromptsByIdResponse422
    | GetApiPromptsByIdResponse500
]:
    r"""Get a specific prompt by slug, with optional shorthand syntax for tags and versions. Pass a bare
    slug like \"pizza-prompt\" to get the latest version, \"pizza-prompt:production\" to resolve a
    tagged version, or \"pizza-prompt:2\" to fetch version 2. Alternatively, use the tag or version
    query parameters with a bare slug.

    Args:
        id (str):
        version (int | Unset):
        tag (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetApiPromptsByIdResponse200 | GetApiPromptsByIdResponse400 | GetApiPromptsByIdResponse401 | GetApiPromptsByIdResponse404 | GetApiPromptsByIdResponse422 | GetApiPromptsByIdResponse500]
    """

    kwargs = _get_kwargs(
        id=id,
        version=version,
        tag=tag,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    version: int | Unset = UNSET,
    tag: str | Unset = UNSET,
) -> (
    GetApiPromptsByIdResponse200
    | GetApiPromptsByIdResponse400
    | GetApiPromptsByIdResponse401
    | GetApiPromptsByIdResponse404
    | GetApiPromptsByIdResponse422
    | GetApiPromptsByIdResponse500
    | None
):
    r"""Get a specific prompt by slug, with optional shorthand syntax for tags and versions. Pass a bare
    slug like \"pizza-prompt\" to get the latest version, \"pizza-prompt:production\" to resolve a
    tagged version, or \"pizza-prompt:2\" to fetch version 2. Alternatively, use the tag or version
    query parameters with a bare slug.

    Args:
        id (str):
        version (int | Unset):
        tag (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetApiPromptsByIdResponse200 | GetApiPromptsByIdResponse400 | GetApiPromptsByIdResponse401 | GetApiPromptsByIdResponse404 | GetApiPromptsByIdResponse422 | GetApiPromptsByIdResponse500
    """

    return sync_detailed(
        id=id,
        client=client,
        version=version,
        tag=tag,
    ).parsed


async def asyncio_detailed(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    version: int | Unset = UNSET,
    tag: str | Unset = UNSET,
) -> Response[
    GetApiPromptsByIdResponse200
    | GetApiPromptsByIdResponse400
    | GetApiPromptsByIdResponse401
    | GetApiPromptsByIdResponse404
    | GetApiPromptsByIdResponse422
    | GetApiPromptsByIdResponse500
]:
    r"""Get a specific prompt by slug, with optional shorthand syntax for tags and versions. Pass a bare
    slug like \"pizza-prompt\" to get the latest version, \"pizza-prompt:production\" to resolve a
    tagged version, or \"pizza-prompt:2\" to fetch version 2. Alternatively, use the tag or version
    query parameters with a bare slug.

    Args:
        id (str):
        version (int | Unset):
        tag (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetApiPromptsByIdResponse200 | GetApiPromptsByIdResponse400 | GetApiPromptsByIdResponse401 | GetApiPromptsByIdResponse404 | GetApiPromptsByIdResponse422 | GetApiPromptsByIdResponse500]
    """

    kwargs = _get_kwargs(
        id=id,
        version=version,
        tag=tag,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    version: int | Unset = UNSET,
    tag: str | Unset = UNSET,
) -> (
    GetApiPromptsByIdResponse200
    | GetApiPromptsByIdResponse400
    | GetApiPromptsByIdResponse401
    | GetApiPromptsByIdResponse404
    | GetApiPromptsByIdResponse422
    | GetApiPromptsByIdResponse500
    | None
):
    r"""Get a specific prompt by slug, with optional shorthand syntax for tags and versions. Pass a bare
    slug like \"pizza-prompt\" to get the latest version, \"pizza-prompt:production\" to resolve a
    tagged version, or \"pizza-prompt:2\" to fetch version 2. Alternatively, use the tag or version
    query parameters with a bare slug.

    Args:
        id (str):
        version (int | Unset):
        tag (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetApiPromptsByIdResponse200 | GetApiPromptsByIdResponse400 | GetApiPromptsByIdResponse401 | GetApiPromptsByIdResponse404 | GetApiPromptsByIdResponse422 | GetApiPromptsByIdResponse500
    """

    return (
        await asyncio_detailed(
            id=id,
            client=client,
            version=version,
            tag=tag,
        )
    ).parsed
