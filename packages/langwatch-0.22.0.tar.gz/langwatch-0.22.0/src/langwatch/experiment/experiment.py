from __future__ import annotations
import asyncio
from contextlib import contextmanager
from contextvars import ContextVar, Token
from dataclasses import dataclass
import json
import sys
import threading
import time
import traceback
import httpx
import pandas as pd
from opentelemetry import trace, context as otel_context
from opentelemetry.trace import Span
from pydantic import BaseModel, Field
from typing import (
    Any,
    Callable,
    Dict,
    Hashable,
    Iterable,
    Iterator,
    List,
    Literal,
    Optional,
    TypeVar,
    TypedDict,
    Sized,
    Union,
    cast,
)

from tenacity import retry, stop_after_attempt, wait_exponential
from tqdm.auto import tqdm

import langwatch
from langwatch.attributes import AttributeKey
from langwatch.domain import Money, TypedValueJson
from langwatch.experiment.platform_run import (
    EvaluatorStats,
    ExperimentRunResult,
    ExperimentRunSummary,
    TargetStats,
    _is_notebook,
    _print_summary,
)
from langwatch.telemetry.tracing import LangWatchTrace
from langwatch.utils.auth import build_auth_headers
from langwatch.utils.exceptions import better_raise_for_status
from langwatch.utils.transformation import SerializableWithStringFallback

from coolname import generate_slug  # type: ignore
import urllib.parse
from concurrent.futures import Future, ThreadPoolExecutor, as_completed

_tracer = trace.get_tracer(__name__)


@dataclass
class TargetContext:
    """Context for the current target() execution."""

    target_id: str
    index: int
    trace_id: str
    predicted: Optional[Dict[str, Any]] = None  # Set via log_response()


@dataclass
class IterationContext:
    """Context for the current iteration (index + item)."""

    index: int
    item: Any
    started_at: float = 0.0


# ContextVar for target context isolation (works across threads)
_target_context: ContextVar[Optional[TargetContext]] = ContextVar(
    "_target_context", default=None
)

# ContextVar for iteration context (index + item) - thread-safe
_iteration_context: ContextVar[Optional[IterationContext]] = ContextVar(
    "_iteration_context", default=None
)

# Active iteration trace, per iteration context. Stored in a ContextVar
# (rather than on the Experiment instance) so concurrent async tasks don't
# step on each other — otherwise task A's log_response / target() call would
# close task B's iteration trace, leaving OTel context tokens dangling and
# raising "Failed to detach context: Token was created in a different
# Context" during async-gen cleanup.
_active_iteration_trace_ctx: ContextVar[Optional[Any]] = ContextVar(
    "_active_iteration_trace_ctx", default=None
)


def _scalar_or_json_entry(item: Any) -> Dict[str, Any]:
    """Shape a loop item as a dataset ``entry`` payload.

    Plain scalars (str/int/float/bool) are stored unwrapped — `"New York"`
    comes back as `"New York"`, not the doubly-quoted `'"New York"'`.
    Everything else is JSON-stringified with the fallback encoder.
    """
    if isinstance(item, (str, int, float, bool)) or item is None:
        return {"entry": item}
    return {"entry": json.dumps(item, cls=SerializableWithStringFallback)}

ItemT = TypeVar("ItemT")


class EvaluationResult(BaseModel):
    name: str
    evaluator: str
    trace_id: str
    status: Literal["processed", "error", "skipped"]
    data: Optional[Dict[str, Any]] = None
    score: Optional[float] = Field(default=None, description="No description provided")
    passed: Optional[bool] = None
    details: Optional[str] = Field(
        default=None, description="Short human-readable description of the result"
    )
    index: Optional[int] = None
    label: Optional[str] = None
    cost: Optional[float] = None
    duration: Optional[int] = None
    error_type: Optional[str] = None
    traceback: Optional[List[str]] = Field(
        description="Traceback information for debugging", default=None
    )
    target_id: Optional[str] = Field(
        default=None, description="ID of the target this evaluation is for"
    )


class TargetInfo(BaseModel):
    """Represents a registered target with its metadata."""

    id: str
    name: str
    type: Literal["prompt", "agent", "custom"] = "custom"
    metadata: Optional[Dict[str, Union[str, int, float, bool]]] = None


class Batch(TypedDict):
    dataset: List[BatchEntry]
    evaluations: List[EvaluationResult]
    targets: List[TargetInfo]


class BatchEntry(BaseModel):
    index: int
    entry: Any
    duration: int
    error: Optional[str] = None
    trace_id: str
    target_id: Optional[str] = None
    cost: Optional[float] = None
    predicted: Optional[Dict[str, Any]] = None


class IterationInfo(TypedDict):
    index: int
    trace: LangWatchTrace
    item: Any
    duration: int
    error: Optional[Exception]


class Experiment:
    _executor: ThreadPoolExecutor
    _futures: List[Future[Any]]
    _current_index: int
    _current_item: Any

    def __init__(self, name: str, *, run_id: Optional[str] = None):
        self.name: str = name or generate_slug(3)
        self.experiment_slug: str = self.name
        self.run_id: str = run_id or generate_slug(3)
        self.total: int = 0
        self.progress: int = 0
        self.created_at_nano: int = int(time.time() * 1000)
        self._futures: List[Future[Any]] = []
        # Async-native execution state (used by aloop / asubmit). The threading
        # path keeps these empty, so every check downstream is a no-op for it.
        self._async_tasks: List["asyncio.Task[Any]"] = []
        self._async_semaphore: Optional[asyncio.Semaphore] = None

        # Sending results
        self.lock = threading.Lock()
        self.batch: Batch = {"dataset": [], "evaluations": [], "targets": []}
        self.last_sent = 0
        self.debounce_interval = 1  # 1 second
        self.threads: List[threading.Thread] = []
        self.initialized = False

        # Target registry - tracks registered targets and their metadata
        self._targets: Dict[str, TargetInfo] = {}

        # Track whether with_target() was used in the current iteration
        # If so, we don't create row-level dataset entries
        self._current_iteration_used_with_target = False

        # Track whether target() has EVER been used in this evaluation
        # Once set to True, we stop creating iteration-level traces
        self._evaluation_uses_targets: bool = False

        # Active iteration trace is stored in `_active_iteration_trace_ctx`
        # (a module-level ContextVar) so concurrent asyncio tasks each see
        # their OWN iteration trace — not a shared last-writer-wins field on
        # the Experiment instance.

        self._finished: bool = False
        self._run_url: Optional[str] = None
        self._cached_results_df: Optional[pd.DataFrame] = None

    def init(self):
        if not langwatch.get_api_key():
            raise ValueError(
                "API key was not detected, please set LANGWATCH_API_KEY or call langwatch.login() to login"
            )
        langwatch.ensure_setup()

        with httpx.Client(timeout=60) as client:
            response = client.post(
                f"{langwatch.get_endpoint()}/api/experiment/init",
                headers=build_auth_headers(langwatch.get_api_key() or ""),
                json={
                    "experiment_name": self.name,
                    "experiment_slug": self.experiment_slug,
                    "experiment_type": "BATCH_EVALUATION_V2",
                },
            )
        if response.status_code == 401:
            langwatch.setup(api_key=None)
            raise ValueError(
                "API key is not valid, please try to login again with langwatch.login()"
            )
        better_raise_for_status(response)
        response_json = response.json()
        experiment_path = response_json["path"]
        self.experiment_slug = response_json["slug"]

        url_encoded_run_id = urllib.parse.quote(self.run_id)
        self._run_url = f"{langwatch.get_endpoint()}{experiment_path}?runId={url_encoded_run_id}"
        print(f"Follow the results at: {self._run_url}")
        self.initialized = True

    @property
    def results(self) -> pd.DataFrame:
        """
        Per-row evaluation results as a pandas DataFrame, fetched from the platform.

        Each row corresponds to one dataset entry (or one entry per target in
        multi-target experiments). Columns include the input data, output,
        trace_id, duration_ms, cost, plus one column per evaluation metric.

        The platform is the single source of truth — costs are computed from
        traces, durations are accurate, and all data is consistent.

        Example::

            evaluation.results                    # renders as table in Jupyter
            evaluation.results.describe()         # summary statistics
            evaluation.results["my_metric"].mean() # aggregate a metric
            evaluation.results.groupby("target")["quality"].mean()
        """
        if self._cached_results_df is not None:
            return self._cached_results_df

        df = self._fetch_results_as_df()
        self._cached_results_df = df
        return df

    def _fetch_results_as_df(self, retries: int = 5, delay: float = 3.0) -> pd.DataFrame:
        """Fetch per-row results from the platform and build a DataFrame."""
        endpoint = langwatch.get_endpoint()
        api_key = langwatch.get_api_key() or ""

        url = (
            f"{endpoint}/api/evaluations/v3/runs/"
            f"{urllib.parse.quote(self.run_id)}/results"
            f"?experimentSlug={urllib.parse.quote(self.experiment_slug)}"
        )

        for attempt in range(retries):
            try:
                with httpx.Client(timeout=30) as client:
                    response = client.get(url, headers=build_auth_headers(api_key))

                if response.status_code == 404:
                    if attempt < retries - 1:
                        time.sleep(delay)
                        continue
                    return pd.DataFrame()

                if response.is_success:
                    data = response.json()
                    return self._build_df_from_platform(data)

            except Exception:
                if attempt < retries - 1:
                    time.sleep(delay)
                    continue

        return pd.DataFrame()

    @staticmethod
    def _build_df_from_platform(data: Dict[str, Any]) -> pd.DataFrame:
        """Build a DataFrame from the platform API response (ExperimentRunWithItems)."""
        dataset_entries = data.get("dataset", [])
        evaluations = data.get("evaluations", [])

        if not dataset_entries:
            return pd.DataFrame()

        # Build base rows from dataset entries
        rows: List[Dict[str, Any]] = []
        for entry in dataset_entries:
            row: Dict[str, Any] = {"index": entry.get("index", 0)}
            # Flatten entry data
            entry_data = entry.get("entry", {})
            if isinstance(entry_data, dict):
                for k, v in entry_data.items():
                    row[k] = v
            # Output from the target
            predicted = entry.get("predicted")
            if predicted:
                row["output"] = predicted.get("output", predicted) if isinstance(predicted, dict) else predicted
            row["trace_id"] = entry.get("traceId", "")
            row["duration_ms"] = entry.get("duration", 0)
            cost = entry.get("cost")
            if cost is not None:
                row["cost"] = cost
            error = entry.get("error")
            if error:
                row["error"] = error
            target_id = entry.get("targetId")
            if target_id:
                row["target"] = target_id
            rows.append(row)

        df = pd.DataFrame(rows)
        if df.empty:
            return df

        # Pivot evaluation scores into columns
        for ev in evaluations:
            idx = ev.get("index")
            name = ev.get("name") or ev.get("evaluator", "")
            if idx is None or not name:
                continue
            mask = df["index"] == idx
            target_id = ev.get("targetId")
            if target_id and "target" in df.columns:
                mask = mask & (df["target"] == target_id)
            score = ev.get("score")
            if score is not None:
                df.loc[mask, name] = score
            passed = ev.get("passed")
            if passed is not None:
                df.loc[mask, f"{name}_passed"] = passed

        # Set up proper indexing
        if "target" in df.columns and len(df["target"].unique()) > 1:
            # Multi-target: use (target, index) MultiIndex for natural grouping
            if "index" in df.columns:
                df = df.set_index(["target", "index"]).sort_index()
        elif "index" in df.columns:
            df = df.set_index("index")

        return df

    def _auto_display_results(self) -> None:
        """Fetch and display results after loop completion."""
        try:
            # Wait for platform to process final batch + traces
            time.sleep(5)

            df = self._fetch_results_as_df()
            if df.empty:
                if self._run_url:
                    print(f"\n  View details: {self._run_url}\n")
                return

            self._cached_results_df = df
            print()
            self._display_df(df)

            if self._run_url:
                print(f"\n  View details: {self._run_url}")
            print(f"  Explore with: `evaluation.results`\n")
        except Exception:
            # Non-fatal: don't crash the experiment if result display fails
            if self._run_url:
                print(f"\n  View details: {self._run_url}\n")

    @staticmethod
    def _display_df(df: pd.DataFrame) -> None:
        try:
            from IPython.display import display
            from IPython import get_ipython
            if get_ipython() is not None:
                display(df)
                return
        except (ImportError, AttributeError):
            # IPython not available — fall through to text display
            pass
        print(df.to_string())

    def print_summary(self, exit_on_failure: Optional[bool] = None) -> None:
        """
        Print a CI-friendly summary of the experiment and optionally exit with code 1 on failure.

        Mirrors ``ExperimentRunResult.print_summary`` for parity — SDK-driven
        experiments (``langwatch.experiment.init(...)`` + ``loop`` + ``evaluate``) can
        now fail CI builds the same way platform experiments (``langwatch.experiment.run(slug)``) do.

        Args:
            exit_on_failure: If True, calls ``sys.exit(1)`` when there are failures.
                             If False, never exits. If None (default), auto-detects:
                             exits in scripts/CI, doesn't in Jupyter notebooks.

        Example::

            experiment = langwatch.experiment.init("ci-quality-check")
            for idx, row in experiment.loop(dataset.iterrows()):
                response = my_llm(row["input"])
                experiment.evaluate("ragas/faithfulness", index=idx, data={...})

            experiment.print_summary()
        """
        result = self._build_run_result()
        _print_summary(result)

        should_exit = exit_on_failure if exit_on_failure is not None else not _is_notebook()
        if should_exit and (result.failed > 0 or result.summary.failed_cells > 0):
            sys.exit(1)

    def _build_run_result(self) -> ExperimentRunResult:
        """Build an ExperimentRunResult from the current results DataFrame."""
        run_url = self._run_url or ""
        df = self.results

        if df is None or df.empty:
            empty_summary = ExperimentRunSummary(
                run_id=self.run_id,
                total_cells=0,
                completed_cells=0,
                failed_cells=0,
                duration=0,
                run_url=run_url,
            )
            return ExperimentRunResult(
                run_id=self.run_id,
                status="completed",
                passed=0,
                failed=0,
                pass_rate=0.0,
                duration=0,
                run_url=run_url,
                summary=empty_summary,
            )

        # Flatten any MultiIndex so we can access columns uniformly.
        flat = df.reset_index() if df.index.names and any(n is not None for n in df.index.names) else df

        passed_cols = [c for c in flat.columns if isinstance(c, str) and c.endswith("_passed")]

        total_passed = 0
        total_failed = 0
        evaluators: List[EvaluatorStats] = []
        for pcol in passed_cols:
            name = pcol[: -len("_passed")]
            col = flat[pcol].dropna()
            passed = int((col == True).sum())  # noqa: E712 — pandas comparison
            failed = int((col == False).sum())  # noqa: E712
            total_passed += passed
            total_failed += failed

            avg_score: Optional[float] = None
            if name in flat.columns:
                numeric = pd.to_numeric(flat[name], errors="coerce").dropna()
                if not numeric.empty:
                    avg_score = float(numeric.mean())

            subtotal = passed + failed
            eval_pass_rate = (passed / subtotal * 100.0) if subtotal > 0 else 0.0
            evaluators.append(
                EvaluatorStats(
                    evaluator_id=name,
                    name=name,
                    passed=passed,
                    failed=failed,
                    pass_rate=eval_pass_rate,
                    avg_score=avg_score,
                )
            )

        targets: List[TargetStats] = []
        if "target" in flat.columns:
            for target_id, sub in flat.groupby("target"):
                t_passed = 0
                t_failed = 0
                for pcol in passed_cols:
                    if pcol not in sub.columns:
                        continue
                    sub_col = sub[pcol].dropna()
                    t_passed += int((sub_col == True).sum())  # noqa: E712
                    t_failed += int((sub_col == False).sum())  # noqa: E712

                avg_latency = 0.0
                if "duration_ms" in sub.columns:
                    dur_numeric = pd.to_numeric(sub["duration_ms"], errors="coerce").dropna()
                    if not dur_numeric.empty:
                        avg_latency = float(dur_numeric.mean())

                t_cost = 0.0
                if "cost" in sub.columns:
                    cost_numeric = pd.to_numeric(sub["cost"], errors="coerce").dropna()
                    if not cost_numeric.empty:
                        t_cost = float(cost_numeric.sum())

                targets.append(
                    TargetStats(
                        target_id=str(target_id),
                        name=str(target_id),
                        passed=t_passed,
                        failed=t_failed,
                        avg_latency=avg_latency,
                        total_cost=t_cost,
                    )
                )

        overall_total = total_passed + total_failed
        pass_rate = (total_passed / overall_total * 100.0) if overall_total > 0 else 0.0

        duration = 0
        if "duration_ms" in flat.columns:
            dur_all = pd.to_numeric(flat["duration_ms"], errors="coerce").dropna()
            if not dur_all.empty:
                duration = int(dur_all.sum())

        total_cost = 0.0
        if "cost" in flat.columns:
            cost_all = pd.to_numeric(flat["cost"], errors="coerce").dropna()
            if not cost_all.empty:
                total_cost = float(cost_all.sum())

        # Count rows whose target/loop execution errored out (non-null error column).
        # These are execution failures distinct from evaluator failures — CI must
        # treat them as failures too, not just evaluator mismatches.
        failed_cells = 0
        if "error" in flat.columns:
            failed_cells = int(flat["error"].notna().sum())

        summary = ExperimentRunSummary(
            run_id=self.run_id,
            total_cells=len(flat),
            completed_cells=len(flat) - failed_cells,
            failed_cells=failed_cells,
            duration=duration,
            run_url=run_url,
            targets=targets,
            evaluators=evaluators,
            total_passed=total_passed,
            total_failed=total_failed,
            pass_rate=pass_rate,
            total_cost=total_cost,
        )

        has_failures = total_failed > 0 or failed_cells > 0
        return ExperimentRunResult(
            run_id=self.run_id,
            status="failed" if has_failures else "completed",
            passed=total_passed,
            failed=total_failed,
            pass_rate=pass_rate,
            duration=duration,
            run_url=run_url,
            summary=summary,
        )

    def __repr__(self) -> str:
        status = "finished" if self._finished else "running" if self.initialized else "not started"
        parts = [f"Experiment(name={self.name!r}, status={status}"]
        if self.initialized:
            parts.append(f"run_id={self.run_id!r}")
        if self.total > 0:
            parts.append(f"progress={self.progress}/{self.total}")
        parts_str = ", ".join(parts)
        return parts_str + ")"

    def loop(
        self,
        iterable: Union[Iterable[ItemT], pd.DataFrame],
        *,
        threads: int = 4,
        total: Optional[int] = None,
    ) -> Iterable[ItemT]:
        if not self.initialized:
            self.init()

        try:
            total_ = (
                total
                if total
                else (
                    len(cast(Sized, iterable)) if hasattr(iterable, "__len__") else None
                )
            )
            if total_ is None and "DataFrame.iterrows" in str(iterable):
                iterable = cast(Iterable[ItemT], list(iterable))
                total_ = len(cast(Sized, iterable))
            progress_bar = tqdm(total=total_, desc="Evaluating")

            # Supports direct pandas df being passed in
            if isinstance(iterable, pd.DataFrame):
                iterable = cast(Iterable[ItemT], iterable.iterrows())  # type: ignore

            with ThreadPoolExecutor(max_workers=threads) as executor:
                self._executor = executor
                for index, item in enumerate(iterable):
                    self._current_index = index
                    self._current_item = item

                    with self._execute_item_iteration(
                        index,
                        item,
                        in_thread=False,
                    ):
                        yield item
                    if len(self._futures) == 0:
                        progress_bar.update(1)

                if len(self._futures) > 0:
                    for _ in as_completed(self._futures):
                        progress_bar.update(1)

                executor.submit(self._wait_for_completion).result()
                progress_bar.close()
                self._finished = True

                # Auto-fetch and display results after completion
                self._auto_display_results()

        except Exception as e:
            self._finished = True
            Experiment._log_results(
                langwatch.get_api_key() or "",
                {
                    "experiment_slug": self.experiment_slug,
                    "run_id": self.run_id,
                    "timestamps": {
                        "finished_at": int(time.time() * 1000),
                        "stopped_at": int(time.time() * 1000),
                    },
                },
            )
            raise e

    def submit(self, func: Callable[..., Any], /, *args: Any, **kwargs: Any):
        _current_index = self._current_index
        _current_item = self._current_item

        def wrapper():
            with self._execute_item_iteration(
                _current_index, _current_item, in_thread=True
            ):
                if asyncio.iscoroutinefunction(func):
                    func_result = asyncio.run(func(*args, **kwargs))
                else:
                    func_result = func(*args, **kwargs)

            return func_result

        future = self._executor.submit(wrapper)
        self._futures.append(future)
        return future

    async def aloop(
        self,
        iterable: Union[Iterable[ItemT], pd.DataFrame],
        *,
        concurrency: int = 4,
        total: Optional[int] = None,
    ):
        """Async-native sibling of ``loop()``.

        All submitted work runs on the caller's event loop, so loop-bound singletons
        (gRPC channels, Firestore clients, ADK InMemoryRunner, etc.) stay usable
        across items. Use together with :meth:`asubmit` to schedule per-item work.

        Cleanup is guaranteed on normal completion and when the caller breaks out
        of the ``async for`` **and** explicitly calls ``aclose()`` on the generator.
        Python's ``async for`` does not auto-close iterators on ``break``, so for
        deterministic cancellation of in-flight ``asubmit`` tasks, hold the
        generator in a variable and ``await generator.aclose()`` after the
        early exit. If you iterate to completion the finally block runs on the
        last ``__anext__`` automatically and no extra call is needed.
        """
        if concurrency < 1:
            raise ValueError(
                f"concurrency must be >= 1, got {concurrency!r}"
            )
        if not self.initialized:
            # init() does a blocking httpx.post — run it off-loop.
            await asyncio.to_thread(self.init)

        progress_bar: Optional[tqdm] = None
        try:
            total_ = (
                total
                if total
                else (
                    len(cast(Sized, iterable)) if hasattr(iterable, "__len__") else None
                )
            )
            if total_ is None and "DataFrame.iterrows" in str(iterable):
                iterable = cast(Iterable[ItemT], list(iterable))
                total_ = len(cast(Sized, iterable))
            progress_bar = tqdm(total=total_, desc="Evaluating")

            if isinstance(iterable, pd.DataFrame):
                iterable = cast(Iterable[ItemT], iterable.iterrows())  # type: ignore

            self._async_semaphore = asyncio.Semaphore(concurrency)
            self._async_tasks = []

            for index, item in enumerate(iterable):
                self._current_index = index
                self._current_item = item

                with self._execute_item_iteration(index, item, in_thread=False):
                    yield item
                if len(self._async_tasks) == 0 and len(self._futures) == 0:
                    progress_bar.update(1)

            if len(self._async_tasks) > 0:
                for coro in asyncio.as_completed(self._async_tasks):
                    try:
                        await coro
                    except Exception:
                        # Per-item errors are already recorded via
                        # _execute_item_iteration; swallow so siblings finish.
                        pass
                    progress_bar.update(1)

            await self._await_completion()
            self._finished = True
            # _auto_display_results sleeps for several seconds and issues
            # synchronous HTTP — keep it off the event loop.
            await asyncio.to_thread(self._auto_display_results)

        except Exception as e:
            self._finished = True
            Experiment._log_results(
                langwatch.get_api_key() or "",
                {
                    "experiment_slug": self.experiment_slug,
                    "run_id": self.run_id,
                    "timestamps": {
                        "finished_at": int(time.time() * 1000),
                        "stopped_at": int(time.time() * 1000),
                    },
                },
            )
            raise e
        finally:
            # Guarantee cleanup on normal completion, early `break`, or
            # exception. Without this, a consumer that breaks out of `async
            # for` leaves _async_semaphore dangling (stale asubmit calls),
            # background tasks running, and the tqdm bar open.
            pending = [t for t in self._async_tasks if not t.done()]
            for task in pending:
                task.cancel()
            if pending:
                await asyncio.gather(*pending, return_exceptions=True)
            self._async_tasks = []
            self._async_semaphore = None
            if progress_bar is not None:
                progress_bar.close()

    def asubmit(
        self, func: Callable[..., Any], /, *args: Any, **kwargs: Any
    ) -> "asyncio.Task[Any]":
        """Async-native sibling of :meth:`submit`.

        Captures the current loop iteration's index/item, enters the per-item
        iteration context inside the spawned task, then awaits ``func``. Sync
        callables are offloaded to ``asyncio.to_thread`` so they do not block the
        event loop for concurrent async siblings.
        """
        if self._async_semaphore is None:
            raise RuntimeError(
                "asubmit() must be called from inside an `async for item in "
                "experiment.aloop(...):` block"
            )
        _current_index = self._current_index
        _current_item = self._current_item
        semaphore = self._async_semaphore

        async def wrapper() -> Any:
            async with semaphore:
                with self._execute_item_iteration(
                    _current_index, _current_item, in_thread=True
                ):
                    if asyncio.iscoroutinefunction(func):
                        return await func(*args, **kwargs)
                    return await asyncio.to_thread(func, *args, **kwargs)

        task = asyncio.create_task(wrapper())
        self._async_tasks.append(task)
        return task

    async def _await_completion(self) -> None:
        """Async-mode counterpart of ``_wait_for_completion``.

        Sends any remaining batch and joins fire-and-forget batch-sender threads
        without nesting ``asyncio.run`` inside a running loop.
        """
        self._send_batch(finished=True)
        for thread in self.threads:
            await asyncio.to_thread(thread.join)

    @contextmanager
    def _execute_item_iteration(
        self,
        index: int,
        item: Any,
        in_thread: bool = False,
    ) -> Iterator[Any]:
        # Reset with_target tracking for this iteration
        self._current_iteration_used_with_target = False

        # Set iteration context (thread-safe via contextvars).
        # `started_at` lets implicit-target paths (log_response) compute a
        # real duration instead of reporting 0.
        iter_ctx = IterationContext(
            index=index, item=item, started_at=time.time()
        )
        iter_token = _iteration_context.set(iter_ctx)

        # Reset target context at the start of each iteration to prevent pollution
        # from previous iterations (especially important for implicit Output targets)
        _target_context.set(None)

        # Determine if we should create an iteration trace:
        # - Don't create if evaluation uses targets (each target creates its own trace)
        # - Don't create if we're collecting submit() / asubmit() calls (not in_thread yet)
        has_pending_submissions = (
            len(self._futures) > 0 or len(self._async_tasks) > 0
        )
        should_create_iteration_trace = (
            not self._evaluation_uses_targets
            and (in_thread or not has_pending_submissions)
        )

        iteration: Optional[IterationInfo] = None
        _active_trace_token: Optional[Token[Optional[Any]]] = None
        if should_create_iteration_trace:
            iteration = IterationInfo(
                trace=langwatch.trace(
                    name="evaluation.loop_iteration",
                    metadata={
                        "thread_id": self.run_id,
                        "loop.index": str(index),
                    },
                ),
                index=index,
                item=item,
                duration=0,
                error=None,
            )
            iteration["trace"].__enter__()
            if iteration["trace"].root_span:
                iteration["trace"].root_span.set_attributes(
                    {"langwatch.origin": "evaluation"}
                )
            # Store for target() to potentially close early — in the current
            # (per-task) contextvar copy so sibling tasks don't see it.
            _active_trace_token = _active_iteration_trace_ctx.set(
                iteration["trace"]
            )

        start_time = time.time()
        try:
            yield
        except Exception as e:
            if iteration is not None:
                iteration["error"] = e
            print(f"\n[Evaluation Error] index={index}")
            traceback.print_exc()
        finally:
            # Reset iteration context
            _iteration_context.reset(iter_token)
            # Reset target context to prevent pollution to next iteration
            _target_context.set(None)

        # Handle iteration trace cleanup
        # Note: If target() was used, it may have already closed the trace
        if iteration is not None and not self._evaluation_uses_targets:
            try:
                iteration["duration"] = int((time.time() - start_time) * 1000)

                # If we just started the parallel loop, we need to skip the first iteration
                # from being added to the batch and change the trace name
                if not in_thread and (
                    len(self._futures) > 0 or len(self._async_tasks) > 0
                ):
                    iteration["trace"].update(name="evaluation.loop")
                # Only add row-level entry if with_target was NOT used
                # When with_target is used, it creates per-target dataset entries instead
                elif not self._current_iteration_used_with_target:
                    self._add_to_batch(iteration)

                if iteration["error"] is not None:
                    iteration["trace"].update(error=iteration["error"])
            except Exception as e:
                raise e
            finally:
                # Only exit the trace if target()/log_response() didn't close
                # it early (which resets the contextvar to None as its
                # signal). If still active, close it here.
                if _active_iteration_trace_ctx.get() is iteration["trace"]:
                    iteration["trace"].__exit__(None, None, None)

        # Clear active iteration trace reference for this task's context.
        if _active_trace_token is not None:
            try:
                _active_iteration_trace_ctx.reset(_active_trace_token)
            except (LookupError, ValueError):
                # Swallowed intentionally: `_active_trace_token` is created
                # via `set()` in the same asyncio task, so `reset()` should
                # always succeed. But if Python GCs an async generator in a
                # different task's context during teardown, the token can
                # look "from a different Context" and raise ValueError —
                # that's a cleanup edge case, not a user-visible failure,
                # so we don't let it mask the real iteration result.
                pass

    def _add_to_batch(self, iteration: IterationInfo):
        entry: Any = (
            iteration["item"].to_dict()
            if hasattr(iteration["item"], "to_dict")
            else (
                iteration["item"].__dict__
                if hasattr(iteration["item"], "__dict__")
                else (
                    iteration["item"][1].to_dict()
                    if type(iteration["item"]) == tuple
                    and hasattr(iteration["item"][1], "to_dict")
                    else (
                        iteration["item"][1].__dict__
                        if type(iteration["item"]) == tuple
                        and hasattr(iteration["item"][1], "__dict__")
                        else _scalar_or_json_entry(iteration["item"])
                    )
                )
            )
        )
        batch_entry = BatchEntry(
            index=iteration["index"],
            entry=entry,
            duration=iteration["duration"],
            error=str(iteration["error"]) if iteration["error"] else None,
            trace_id=iteration["trace"].trace_id or "",
        )
        with self.lock:
            self.batch["dataset"].append(batch_entry)

        if time.time() - self.last_sent >= self.debounce_interval:
            self._send_batch()

    def _send_batch(self, finished: bool = False):
        with self.lock:
            if (
                len(self.batch["dataset"]) == 0
                and len(self.batch["evaluations"]) == 0
                and len(self.batch["targets"]) == 0
                and not finished
            ):
                return

            # TODO: it is called `inputs` on the api still, unfortunately, so we need to map data back to inputs
            evaluations = []
            for eval in self.batch["evaluations"]:
                eval_ = eval.model_dump(exclude_none=True, exclude_unset=True)
                eval_["inputs"] = eval_["data"]
                if "data" in eval_:
                    del eval_["data"]
                evaluations.append(eval_)

            # Build targets array for API
            targets = [
                target.model_dump(exclude_none=True, exclude_unset=True)
                for target in self.batch["targets"]
            ]

            body: Dict[str, Any] = {
                "experiment_slug": self.experiment_slug,
                "name": f"{self.name}",
                "run_id": self.run_id,
                "dataset": [
                    entry.model_dump(exclude_none=True, exclude_unset=True)
                    for entry in self.batch["dataset"]
                ],
                "evaluations": evaluations,
                "progress": self.progress,
                "total": self.total,
                "timestamps": {
                    "created_at": self.created_at_nano,
                },
            }

            # Only include targets if we have any
            if len(targets) > 0:
                body["targets"] = targets

            if finished:
                if not isinstance(body["timestamps"], dict):
                    body["timestamps"] = {}
                body["timestamps"]["finished_at"] = int(time.time() * 1000)

            # Start a new thread to send the batch
            thread = threading.Thread(
                target=Experiment._log_results,
                args=(langwatch.get_api_key(), body),
            )
            thread.start()
            self.threads.append(thread)

            # Clear the batch and update the last sent time
            self.batch = {"dataset": [], "evaluations": [], "targets": []}
            self.last_sent = time.time()

    @classmethod
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        reraise=True,
    )
    def _log_results(cls, api_key: str, body: Dict[str, Any]):
        response = httpx.post(
            f"{langwatch.get_endpoint()}/api/evaluations/batch/log_results",
            headers={
                **build_auth_headers(api_key),
                "Content-Type": "application/json",
            },
            data=json.dumps(body, cls=SerializableWithStringFallback),  # type: ignore
            timeout=60,
        )
        better_raise_for_status(response)

    def _wait_for_completion(self):
        async def wait_for_completion(self: Experiment):
            # Send any remaining batch
            self._send_batch(finished=True)

            for thread in self.threads:
                await asyncio.sleep(0)
                thread.join()

        asyncio.run(wait_for_completion(self))

    def _register_target(
        self,
        target: str,
        metadata: Optional[Dict[str, Union[str, int, float, bool]]] = None,
    ) -> str:
        """
        Register a target with its metadata. Returns the target ID.

        If the target was already registered:
        - If no new metadata is provided, the existing target is used
        - If new metadata is provided and differs from existing, raises an error

        Args:
            target: The target name/ID
            metadata: Optional metadata for this target (model, temperature, etc.)

        Returns:
            The target ID
        """
        with self.lock:
            if target in self._targets:
                existing = self._targets[target]
                if metadata is not None:
                    # Check if metadata matches
                    existing_meta = existing.metadata or {}
                    if existing_meta != metadata:
                        raise ValueError(
                            f"Target '{target}' was previously registered with different metadata.\n"
                            f"Original: {existing_meta}\n"
                            f"New: {metadata}\n"
                            f"If you want to use different metadata, please use a different target name."
                        )
                return target

            # Register new target
            target_info = TargetInfo(
                id=target,
                name=target,
                type="custom",
                metadata=metadata,
            )
            self._targets[target] = target_info
            self.batch["targets"].append(target_info)
            return target

    @contextmanager
    def target(
        self,
        name: str,
        metadata: Optional[Dict[str, Union[str, int, float, bool]]] = None,
    ) -> Iterator[None]:
        """
        Context manager for executing code within a target context.

        Creates a dataset entry for this specific target execution, capturing
        duration automatically. This enables proper per-target latency tracking
        when comparing multiple models/configurations.

        Each target() call creates its own independent trace, allowing you to
        view execution details separately for each model/configuration.

        Inside this context, log() calls will automatically use this target
        unless an explicit target is provided.

        Args:
            name: Unique identifier for the target
            metadata: Optional metadata for comparison (e.g., {"model": "gpt-4"})

        Example:
            ```python
            for index, row in evaluation.loop(df.iterrows()):
                def task(index, row):
                    # Compare GPT-4 and Claude
                    with evaluation.target("gpt-4", {"model": "openai/gpt-4"}):
                        response = call_gpt4(row["question"])
                        # target auto-inferred, use data= to record output
                        evaluation.log("quality", index=index, score=0.95,
                                       data={"output": response})

                    with evaluation.target("claude", {"model": "anthropic/claude"}):
                        response = call_claude(row["question"])
                        evaluation.log("quality", index=index, score=0.85,
                                       data={"output": response})

                evaluation.submit(task, index, row)
            ```
        """
        # On FIRST target() call ever in this evaluation:
        # - Set flag to skip creating iteration-level traces going forward
        # - Close the active iteration trace if any (it won't have useful content)
        if not self._evaluation_uses_targets:
            self._evaluation_uses_targets = True
        # Close the active iteration trace early — per-task via contextvar so
        # we only touch the trace belonging to the task calling target().
        active_trace = _active_iteration_trace_ctx.get()
        if active_trace is not None:
            active_trace.__exit__(None, None, None)
            _active_iteration_trace_ctx.set(None)

        # Mark that target() was used in this iteration (for dataset entry logic)
        self._current_iteration_used_with_target = True

        # Register target
        self._register_target(name, metadata)

        # Get index and item from iteration context (thread-safe via contextvars)
        # This prevents race conditions when multiple threads are running evaluations
        iter_ctx = _iteration_context.get()
        if iter_ctx is not None:
            index = iter_ctx.index
            current_item = iter_ctx.item
        else:
            # Fallback to instance variables (for backwards compatibility / direct usage)
            index = self._current_index
            current_item = self._current_item

        target_trace: Optional[LangWatchTrace] = None
        start_time = time.time()
        error_occurred: Optional[Exception] = None
        trace_id = ""

        # Set up context for log() inference
        ctx = TargetContext(
            target_id=name,
            index=index,
            trace_id="",  # Will be set after entering trace
        )
        target_context_token = _target_context.set(ctx)

        try:
            # Create an INDEPENDENT root trace for this target
            # We use a new tracer without any parent context to get a unique trace_id
            # The key is using the tracer directly with context=None to prevent
            # parent context inheritance
            from opentelemetry.sdk.trace import TracerProvider
            from opentelemetry.trace import INVALID_SPAN_CONTEXT

            tracer = trace.get_tracer("langwatch")

            # Start a new root span with no parent by passing an empty context
            # This ensures each target gets a unique trace_id
            root_context = otel_context.Context()

            with tracer.start_as_current_span(
                f"evaluation.target.{name}",
                context=root_context,
                attributes={
                    "langwatch.origin": "evaluation",
                    "evaluation.run_id": self.run_id,
                    "evaluation.index": index,
                    "evaluation.target": name,
                },
            ) as span:
                span_context = span.get_span_context()
                trace_id = format(span_context.trace_id, "032x")
                ctx.trace_id = trace_id

                try:
                    yield
                except Exception as e:
                    error_occurred = e
                    raise

        except Exception as e:
            if error_occurred is None:
                error_occurred = e
            raise
        finally:
            duration_ms = int((time.time() - start_time) * 1000)

            # Create dataset entry for this target
            # Use the captured current_item, NOT self._current_item (which may have changed)
            entry_data: Any = (
                current_item.to_dict()
                if hasattr(current_item, "to_dict")
                else (
                    current_item.__dict__
                    if hasattr(current_item, "__dict__")
                    else (
                        current_item[1].to_dict()
                        if type(current_item) == tuple
                        and hasattr(current_item[1], "to_dict")
                        else (
                            current_item[1].__dict__
                            if type(current_item) == tuple
                            and hasattr(current_item[1], "__dict__")
                            else _scalar_or_json_entry(current_item)
                        )
                    )
                )
            )

            # Get predicted output from context (set via log_response())
            predicted = ctx.predicted

            batch_entry = BatchEntry(
                index=index,
                entry=entry_data,
                duration=duration_ms,
                error=str(error_occurred) if error_occurred else None,
                trace_id=trace_id,
                target_id=name,
                predicted=predicted,
            )

            with self.lock:
                self.batch["dataset"].append(batch_entry)

            # Reset target context
            _target_context.reset(target_context_token)

            # Schedule send
            if time.time() - self.last_sent >= self.debounce_interval:
                self._send_batch()

    def log_response(self, response: Union[str, Dict[str, Any]]) -> None:
        """
        Log the model's response/output for the current target.

        Can be called inside a `target()` context, or outside of one. When called
        outside a target context, an implicit "Output" target is created automatically.
        The response will be stored in the dataset entry's `predicted` field, which
        is displayed in the results table.

        Args:
            response: The model's output. Can be a string (will be wrapped as
                     {"output": response}) or a dict with named outputs.

        Example:
            ```python
            # With explicit target
            with evaluation.target("gpt-4", {"model": "openai/gpt-4"}):
                response = call_gpt4(row["question"])
                evaluation.log_response(response)  # Store the output
                evaluation.log("quality", index=index, score=0.95)  # Log metrics

            # Without explicit target (creates implicit "Output" target)
            for index, row in evaluation.loop(df.iterrows()):
                response = my_model(row["question"])
                evaluation.log_response(response)  # Creates "Output" target
                evaluation.log("quality", index=index, score=0.95)
            ```
        """
        ctx = _target_context.get()

        # Normalize response to dict format
        if isinstance(response, str):
            predicted = {"output": response}
        elif isinstance(response, dict):
            predicted = response
        else:
            # Try to convert to string for other types
            predicted = {"output": str(response)}

        if ctx is None:
            # Create implicit "Output" target and dataset entry immediately
            self._create_implicit_output_target(predicted)
        else:
            # Inside explicit target context - just set predicted
            ctx.predicted = predicted

    def _create_implicit_output_target(self, predicted: Dict[str, Any]) -> None:
        """
        Create an implicit "Output" target when log_response() is called outside
        a target() context. This enables a simpler API for single-target evaluations.

        Creates the dataset entry immediately with the predicted response.
        """
        target_name = "Output"

        # Mark that targets are being used
        if not self._evaluation_uses_targets:
            self._evaluation_uses_targets = True

        # If an iteration trace is still open for this task, reuse its
        # trace_id so the dataset row points at the trace that actually
        # contains the ADK / OpenAI / LangChain instrumentor spans recorded
        # during the iteration. Capture the id BEFORE closing, then close.
        trace_id: Optional[str] = None
        active_trace = _active_iteration_trace_ctx.get()
        if active_trace is not None:
            try:
                root_span = getattr(active_trace, "root_span", None)
                otel_span = (
                    getattr(root_span, "_span", None)
                    if root_span is not None
                    else None
                )
                if otel_span is not None:
                    sc = otel_span.get_span_context()
                    if sc and sc.trace_id:
                        trace_id = format(sc.trace_id, "032x")
            except Exception:
                trace_id = None
            active_trace.__exit__(None, None, None)
            _active_iteration_trace_ctx.set(None)

        self._current_iteration_used_with_target = True

        # Register the target
        self._register_target(target_name, None)

        # Get index and item from iteration context
        iter_ctx = _iteration_context.get()
        if iter_ctx is not None:
            index = iter_ctx.index
            current_item = iter_ctx.item
            iter_started_at = iter_ctx.started_at
        else:
            index = self._current_index
            current_item = self._current_item
            iter_started_at = 0.0

        # Fallback: if we didn't capture a trace id from the iteration trace
        # (e.g. log_response() was called outside an aloop/loop), open a
        # fresh root trace so we still record *something* addressable.
        if trace_id is None:
            tracer = trace.get_tracer("langwatch")
            root_context = otel_context.Context()
            with tracer.start_span(
                f"evaluation.target.{target_name}",
                context=root_context,
                attributes={
                    "langwatch.origin": "evaluation",
                    "evaluation.run_id": self.run_id,
                    "evaluation.index": index,
                    "evaluation.target": target_name,
                },
            ) as span:
                span_context = span.get_span_context()
                trace_id = format(span_context.trace_id, "032x")

        # Create and set target context (for subsequent log() calls)
        ctx = TargetContext(
            target_id=target_name,
            index=index,
            trace_id=trace_id,
            predicted=predicted,
        )
        _target_context.set(ctx)

        # Create dataset entry immediately
        entry_data: Any = (
            current_item.to_dict()
            if hasattr(current_item, "to_dict")
            else (
                current_item.__dict__
                if hasattr(current_item, "__dict__")
                else (
                    current_item[1].to_dict()
                    if type(current_item) == tuple
                    and hasattr(current_item[1], "to_dict")
                    else (
                        current_item[1].__dict__
                        if type(current_item) == tuple
                        and hasattr(current_item[1], "__dict__")
                        else _scalar_or_json_entry(current_item)
                    )
                )
            )
        )

        # Duration from iteration start (set in _execute_item_iteration) to
        # this log_response() call. Falls back to 0 if we somehow have no
        # iteration context (shouldn't happen in normal flow).
        duration_ms = (
            int((time.time() - iter_started_at) * 1000)
            if iter_started_at
            else 0
        )
        batch_entry = BatchEntry(
            index=index,
            entry=entry_data,
            duration=duration_ms,
            error=None,
            trace_id=trace_id,
            target_id=target_name,
            predicted=predicted,
        )

        with self.lock:
            self.batch["dataset"].append(batch_entry)

    def log(
        self,
        metric: str,
        index: Union[int, Hashable],
        data: Dict[str, Any] = {},
        score: Optional[float] = None,
        passed: Optional[bool] = None,
        label: Optional[str] = None,
        details: Optional[str] = None,
        status: Literal["processed", "error", "skipped"] = "processed",
        duration: Optional[int] = None,
        cost: Optional[Money] = None,
        error: Optional[Exception] = None,
        target: Optional[str] = None,
        metadata: Optional[Dict[str, Union[str, int, float, bool]]] = None,
    ):
        """
        Log an evaluation metric result.

        Args:
            metric: Name of the metric being logged
            index: Row index in the dataset (must be an integer)
            data: Additional data/inputs for the evaluation
            score: Numeric score (0-1 typically)
            passed: Whether the evaluation passed
            label: Label/category for the result
            details: Human-readable description of the result
            status: Status of the evaluation ("processed", "error", "skipped")
            duration: Duration in milliseconds
            cost: Cost of the evaluation
            error: Exception if an error occurred
            target: Optional target name for multi-target comparisons.
                    First call with a target name registers it with the provided metadata.
                    Subsequent calls with the same target can omit metadata.
                    If called inside with_target(), the target is auto-inferred from context.
            metadata: Optional metadata for the target (model, temperature, etc.).
                      Only used on the first call for each target.
                      Raises error if conflicting metadata is provided for same target.
        """
        try:
            index_ = int(cast(Any, index))
        except Exception:
            raise ValueError(f"Index must be an integer, got {index}")

        # Get target context (if inside with_target)
        ctx = _target_context.get()

        # Use context target if not explicitly provided
        effective_target = target if target is not None else (ctx.target_id if ctx else None)

        # Register target if provided (explicit or from context)
        target_id: Optional[str] = None
        if effective_target is not None:
            target_id = self._register_target(effective_target, metadata)

        # Use trace_id from context if available
        trace_id = (
            ctx.trace_id
            if ctx
            else format(trace.get_current_span().get_span_context().trace_id, "x")
        )

        eval = EvaluationResult(
            trace_id=trace_id,
            name=metric,
            evaluator=metric,
            status=status if status else "error" if error else "processed",
            data=data,
            score=score,
            passed=passed,
            index=index_,
            label=label,
            cost=cost.amount if cost else None,
            duration=duration,
            details=details if details else str(error) if error else None,
            error_type=type(error).__name__ if error else None,
            traceback=(
                list(traceback.TracebackException.from_exception(error).format())
                if error
                else None
            ),
            target_id=target_id,
        )

        with self.lock:
            self.batch["evaluations"].append(eval)

    def evaluate(
        self,
        evaluator_id: str,
        index: Union[int, Hashable],
        data: Dict[str, Any],
        settings: Dict[str, Any],
        name: Optional[str] = None,
        as_guardrail: bool = False,
    ):
        """
        Run an evaluator on the current row.

        Args:
            evaluator_id: The evaluator type/slug (e.g., "langevals/exact_match", "ragas/faithfulness")
            index: The row index for this evaluation
            data: Data to pass to the evaluator (e.g., {"input": ..., "output": ..., "expected_output": ...})
            settings: Evaluator-specific settings
            name: Optional display name for the evaluation (defaults to evaluator_id)
            as_guardrail: Whether to run as a guardrail (stricter pass/fail)
        """
        duration: Optional[int] = None

        start_time = time.time()
        result = langwatch.evaluations.evaluate(
            span=langwatch.get_current_span(),
            slug=evaluator_id,
            name=name or evaluator_id,
            settings=settings,
            as_guardrail=as_guardrail,
            data=data,
        )
        duration = int((time.time() - start_time) * 1000)

        self.log(
            metric=name or evaluator_id,
            index=index,
            data=data,
            status=result.status,
            score=result.score,
            passed=result.passed,
            details=result.details,
            label=result.label,
            duration=duration,
            cost=result.cost,
        )

    def run(
        self,
        evaluator_id: str,
        index: Union[int, Hashable],
        data: Dict[str, Any],
        settings: Dict[str, Any],
        name: Optional[str] = None,
        as_guardrail: bool = False,
    ):
        """
        Deprecated: Use `evaluate()` instead.
        """
        import warnings

        warnings.warn(
            "evaluation.run() is deprecated, use evaluation.evaluate() instead",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.evaluate(
            evaluator_id=evaluator_id,
            index=index,
            data=data,
            settings=settings,
            name=name,
            as_guardrail=as_guardrail,
        )
