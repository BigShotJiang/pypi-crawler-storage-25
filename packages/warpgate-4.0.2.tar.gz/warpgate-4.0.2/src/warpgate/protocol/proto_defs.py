"""Constants for the warpgate traversal signalling protocol."""
from aionetiface import dict_child, NET_CONF, IP4, IP6, EXT_BIND, NIC_BIND

MQTT_CONF = dict_child({"con_timeout": 4, "recv_timeout": 4}, NET_CONF)

# Wire-level message identification is now done by string names
# ("core.ConMsg", "tcp_punch.PunchMsg", "udp_punch.UdpPunchMsg", ...).
# Each ProtoMsg subclass carries a WIRE_NAME class attribute and the
# pack/unpack framing reads/writes a length-prefixed name. Plugins
# auto-register their messages via PROTO_MESSAGES on plugin load with
# names derived from "<plugin_name>.<MsgClassName>" -- no integer
# enum allocation needed.
P2P_PIPE_CONF = {
    "addr_families": [IP4, IP6],
    "addr_types": [EXT_BIND, NIC_BIND],
    "return_msg": False,
}

P2P_DIRECT = 1
P2P_REVERSE = 2
P2P_PUNCH = 3
P2P_RELAY = 4
P2P_RANDOM_PROBE = 5


DIRECT_FAIL = 11
REVERSE_FAIL = 12
PUNCH_FAIL = 13
RELAY_FAIL = 14
RANDOM_PROBE_FAIL = 15

# TURN is not included as a default strategy because it uses UDP.
# It will need a special explanation for the developer.
# SOCKS might be a better protocol for relaying in the future.
P2P_STRATEGIES = [P2P_DIRECT, P2P_REVERSE, P2P_PUNCH]
