from open_data_contract_standard.model import OpenDataContractStandard

from datacontract.model.exceptions import DataContractException


def check_that_datacontract_contains_valid_server_configuration(
    data_contract: OpenDataContractStandard, server_name: str | None
):
    if data_contract.servers is None or len(data_contract.servers) == 0:
        raise DataContractException(
            type="lint",
            name="Check that data contract contains valid server configuration",
            result="warning",
            reason="Servers block is missing. Skip executing tests.",
            engine="datacontract",
        )
    if len(data_contract.servers) > 1 and server_name is None:
        raise DataContractException(
            type="lint",
            name="Check that data contract contains valid server configuration",
            result="warning",
            reason="Data contract contains multiple server configurations. Specify the server you want to test. Skip executing tests.",
            engine="datacontract",
        )
    if server_name is not None:
        # Check if server_name exists in the servers list
        server_names = [s.server for s in data_contract.servers if s.server]
        if server_name not in server_names:
            raise DataContractException(
                type="lint",
                name="Check that data contract contains valid servers configuration",
                result="failed",
                reason=f"Server '{server_name}' not found in data contract. Available servers: {', '.join(sorted(server_names))}",
                engine="datacontract",
            )


#     TODO check for server.type, if all required fields are present
