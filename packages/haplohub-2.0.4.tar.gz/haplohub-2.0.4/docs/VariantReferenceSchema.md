# VariantReferenceSchema


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**chromosome** | **str** |  | 
**position_38** | **int** |  | 
**reference** | **str** |  | 
**alternates** | **List[str]** |  | 

## Example

```python
from haplohub.models.variant_reference_schema import VariantReferenceSchema

# TODO update the JSON string below
json = "{}"
# create an instance of VariantReferenceSchema from a JSON string
variant_reference_schema_instance = VariantReferenceSchema.from_json(json)
# print the JSON string representation of the object
print(VariantReferenceSchema.to_json())

# convert the object into a dict
variant_reference_schema_dict = variant_reference_schema_instance.to_dict()
# create an instance of VariantReferenceSchema from a dict
variant_reference_schema_from_dict = VariantReferenceSchema.from_dict(variant_reference_schema_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


