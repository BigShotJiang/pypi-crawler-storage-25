# VariantReferenceLookupResult


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rs_id** | **str** |  | 
**variants** | [**List[VariantReferenceSchema]**](VariantReferenceSchema.md) |  | 

## Example

```python
from haplohub.models.variant_reference_lookup_result import VariantReferenceLookupResult

# TODO update the JSON string below
json = "{}"
# create an instance of VariantReferenceLookupResult from a JSON string
variant_reference_lookup_result_instance = VariantReferenceLookupResult.from_json(json)
# print the JSON string representation of the object
print(VariantReferenceLookupResult.to_json())

# convert the object into a dict
variant_reference_lookup_result_dict = variant_reference_lookup_result_instance.to_dict()
# create an instance of VariantReferenceLookupResult from a dict
variant_reference_lookup_result_from_dict = VariantReferenceLookupResult.from_dict(variant_reference_lookup_result_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


