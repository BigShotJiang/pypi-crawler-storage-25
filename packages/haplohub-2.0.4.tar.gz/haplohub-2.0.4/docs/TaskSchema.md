# TaskSchema


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | 
**sample_id** | **str** |  | [optional] 
**upload_request_id** | **str** |  | [optional] 
**steps** | **List[object]** |  | 
**kind** | **str** |  | 
**status** | **str** |  | [optional] [default to 'pending']
**current_step** | **str** |  | [optional] 
**temporal_workflow_id** | **str** |  | [optional] 
**started_at** | **datetime** |  | [optional] 
**completed_at** | **datetime** |  | [optional] 
**error_message** | **str** |  | [optional] 
**params** | **object** |  | [optional] 
**created** | **datetime** |  | [optional] 
**modified** | **datetime** |  | [optional] 

## Example

```python
from haplohub.models.task_schema import TaskSchema

# TODO update the JSON string below
json = "{}"
# create an instance of TaskSchema from a JSON string
task_schema_instance = TaskSchema.from_json(json)
# print the JSON string representation of the object
print(TaskSchema.to_json())

# convert the object into a dict
task_schema_dict = task_schema_instance.to_dict()
# create an instance of TaskSchema from a dict
task_schema_from_dict = TaskSchema.from_dict(task_schema_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


