# ResultListResponseVariantReferenceLookupResult


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **str** |  | [optional] [default to 'success']
**items** | [**List[VariantReferenceLookupResult]**](VariantReferenceLookupResult.md) |  | 

## Example

```python
from haplohub.models.result_list_response_variant_reference_lookup_result import ResultListResponseVariantReferenceLookupResult

# TODO update the JSON string below
json = "{}"
# create an instance of ResultListResponseVariantReferenceLookupResult from a JSON string
result_list_response_variant_reference_lookup_result_instance = ResultListResponseVariantReferenceLookupResult.from_json(json)
# print the JSON string representation of the object
print(ResultListResponseVariantReferenceLookupResult.to_json())

# convert the object into a dict
result_list_response_variant_reference_lookup_result_dict = result_list_response_variant_reference_lookup_result_instance.to_dict()
# create an instance of ResultListResponseVariantReferenceLookupResult from a dict
result_list_response_variant_reference_lookup_result_from_dict = ResultListResponseVariantReferenceLookupResult.from_dict(result_list_response_variant_reference_lookup_result_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


