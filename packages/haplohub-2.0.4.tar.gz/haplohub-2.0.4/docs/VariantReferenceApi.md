# haplohub.VariantReferenceApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**lookup_variant_references_by_rsid**](VariantReferenceApi.md#lookup_variant_references_by_rsid) | **POST** /api/v1/variant-reference/rsid/ | Lookup variant references by rsID


# **lookup_variant_references_by_rsid**
> ResultListResponseVariantReferenceLookupResult lookup_variant_references_by_rsid(variant_reference_lookup_request)

Lookup variant references by rsID

### Example

* Api Key Authentication (ApiKeyAuth):
* Bearer Authentication (JWTBearer):

```python
import haplohub
from haplohub.models.result_list_response_variant_reference_lookup_result import ResultListResponseVariantReferenceLookupResult
from haplohub.models.variant_reference_lookup_request import VariantReferenceLookupRequest
from haplohub.rest import ApiException
from pprint import pprint

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization: 
configuration = haplohub.Configuration(
    access_token=os.environ["API_KEY"]
)
# Enter a context with an instance of the API client
with haplohub.ApiClient(configuration) as api_client:
    variant_reference_lookup_request = haplohub.VariantReferenceLookupRequest() # VariantReferenceLookupRequest | 

    try:
        # Lookup variant references by rsID
        api_response = api_client.variant_reference_api.lookup_variant_references_by_rsid(variant_reference_lookup_request)
        print("The response of VariantReferenceApi->lookup_variant_references_by_rsid:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling VariantReferenceApi->lookup_variant_references_by_rsid: %s\n" % e)
```


### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **variant_reference_lookup_request** | [**VariantReferenceLookupRequest**](VariantReferenceLookupRequest.md)|  | 

### Return type

[**ResultListResponseVariantReferenceLookupResult**](ResultListResponseVariantReferenceLookupResult.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth), [JWTBearer](../README.md#JWTBearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

