# VariantReferenceLookupRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rs_ids** | **List[str]** |  | 

## Example

```python
from haplohub.models.variant_reference_lookup_request import VariantReferenceLookupRequest

# TODO update the JSON string below
json = "{}"
# create an instance of VariantReferenceLookupRequest from a JSON string
variant_reference_lookup_request_instance = VariantReferenceLookupRequest.from_json(json)
# print the JSON string representation of the object
print(VariantReferenceLookupRequest.to_json())

# convert the object into a dict
variant_reference_lookup_request_dict = variant_reference_lookup_request_instance.to_dict()
# create an instance of VariantReferenceLookupRequest from a dict
variant_reference_lookup_request_from_dict = VariantReferenceLookupRequest.from_dict(variant_reference_lookup_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


