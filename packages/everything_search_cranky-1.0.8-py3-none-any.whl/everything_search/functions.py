import hashlib
import os
import re
import subprocess
import tempfile
from typing import Optional

import pandas as pd
from ext_pathlib import Path

from .classes import EverythingFilelist


def check_everything() -> bool | Exception:
    """
    Check if Everything search is running.

    Returns:
        bool: True if Everything search is running, False otherwise.
    """
    wh = subprocess.run(
        "where es",
        shell=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=True,
    )
    if wh.returncode == 0:
        return True
    else:
        raise EnvironmentError("es not found on PATH or Everything search not running.")


def md5_hash(string: str) -> str:
    """
    Calculate the MD5 hash of a string.

    Args:
        string (str): The string to hash.

    Returns:
        str: The MD5 hash of the string.
    """
    return hashlib.md5(string.encode()).hexdigest()


def windows_escape(string: str) -> str:
    """
    Escape special characters for Windows.

    Args:
        string (str): The string to escape.

    Returns:
        str: The escaped string.
    """
    return re.sub(r"([&\^\|><])", r"^\1", string)


def command_to_df1(command_list: list[str]) -> pd.DataFrame:
    # build the command
    command = " ".join(command_list)
    command = windows_escape(command)

    # run the command
    sp = subprocess.run(
        command,
        shell=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=True,
    )

    # get the output
    stdout = sp.stdout.decode("utf-8", "ignore")
    # stdout = sp.stdout.decode("cp1252")

    # parse the output into temporary file for pandas
    with tempfile.NamedTemporaryFile() as f:
        f.write(stdout.encode("utf-8"))
        f.seek(0)
        df = pd.read_csv(f)

    # convert the date columns to datetime
    df["Date Accessed"] = pd.to_datetime(df["Date Accessed"])
    df["Date Created"] = pd.to_datetime(df["Date Created"])
    df["Date Modified"] = pd.to_datetime(df["Date Modified"])

    # convert the filename column to a Path object
    df["Filename"] = df["Filename"].apply(Path)

    return df


def command_to_df2(command_list: list[str]) -> pd.DataFrame:
    search_hash: str = md5_hash(" ".join(command_list))
    command_list.append(f"-export-csv {search_hash}.csv")
    output: Path = Path(search_hash + ".csv")

    # build the command
    command = " ".join(command_list)
    command = windows_escape(command)

    # run the command
    sp = subprocess.run(
        command,
        shell=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=True,
    )

    # get the output
    with open(output, "r", encoding="utf-8") as f:
        # read the csv as text
        csv_text = f.read()

    # remove the temporary file
    output.unlink()

    # the default columns
    default_columns: list[str] = [
        "Date Accessed",
        "Date Created",
        "Date Modified",
        "Size",
        "Filename",
    ]

    # return if there is no output
    if not csv_text.split("\n")[1]:
        return pd.DataFrame(columns=default_columns)

    # parse the output for pandas
    cols_rows = [re.split(",", line, maxsplit=4) for line in csv_text.split("\n")]

    # split the columns and rows
    cols, rows = cols_rows[0], cols_rows[1:]

    # create the dataframe
    df = pd.DataFrame(rows, columns=cols)

    # remove empty rows
    df = df.loc[df["Date Created"].apply(bool)]

    date_fmt: str = "%m/%d/%Y %H:%M"

    # convert the date columns to datetime
    df["Date Accessed"] = pd.to_datetime(df["Date Accessed"], format=date_fmt)
    df["Date Created"] = pd.to_datetime(df["Date Created"], format=date_fmt)
    df["Date Modified"] = pd.to_datetime(df["Date Modified"], format=date_fmt)

    # convert the filename column to a Path object
    df["Filename"] = df["Filename"].apply(lambda x: Path(x.strip('"')))

    return df


def everything_search(
    search_term: str | list[str],
    regex: Optional[str] = None,
    audio: Optional[bool] = False,
    video: Optional[bool] = False,
    pic: Optional[bool] = False,
    doc: Optional[bool] = False,
    zip_: Optional[bool] = False,
    exe: Optional[bool] = False,
    file: Optional[bool] = False,
    folder: Optional[bool] = False,
    empty: Optional[bool] = False,
    dateaccessed: Optional[str] = None,
    datemodified: Optional[str] = None,
    datecreated: Optional[str] = None,
    size: Optional[int | str] = None,
    depth: Optional[int] = None,
    ext: Optional[str] = None,
    len_: Optional[int] = None,
    length: Optional[int] = None,
) -> EverythingFilelist:
    """
    Run Everything search.

    The Everything search documentation can be found at:
    https://www.voidtools.com/support/everything/searching/

    The Everything CLI documentation can be found at:
    https://www.voidtools.com/support/everything/command_line_interface/

    Args:
        search_term (str | list[str]): The search term(s).
        regex (str, optional): The regex pattern. Defaults to None.
        audio (bool, optional): Limit to audio files. Defaults to False.
        video (bool, optional): Limit to video files. Defaults to False.
        pic (bool, optional): Limit to picture files. Defaults to False.
        doc (bool, optional): Limit to document files. Defaults to False.
        zip_ (bool, optional): Limit to zip files. Defaults to False.
        exe (bool, optional): Limit to executable files. Defaults to False.
        file (bool, optional): Limit to files. Defaults to False.
        folder (bool, optional): Limit to folders. Defaults to False.
        empty (bool, optional): Limit to empty folders. Defaults to False.
        dateaccessed (str, optional): Search by date accessed. Defaults to None.
        datemodified (str, optional): Search by date modified. Defaults to None.
        datecreated (str, optional): Search by date created. Defaults to None.
        size (int | str, optional): Search by size. Defaults to None.
        depth (int, optional): Search by depth. Defaults to None.
        ext (str, optional): Search by extension. Defaults to None.
        len_ (int, optional): Search by filename length. Defaults to None.
        length (int, optional): Search by media length. Defaults to None.

    Returns:
        list[EverythingFile]: A list of `EverythingFile` objects.
    """
    # check if everything is running
    check_everything()

    # build the command
    command_list = [
        "es -instance 1.5a",  # set the instance to v1.5a
        "-dc -dm -da -size -full-path-and-name -csv",  # set the output view flags
    ]

    # add the search terms
    if regex:
        command_list.append(rf"regex:{regex}")
    if audio:
        command_list.append("audio:")
    if video:
        command_list.append("video:")
    if pic:
        command_list.append("pic:")
    if doc:
        command_list.append("doc:")
    if zip_:
        command_list.append("zip:")
    if exe:
        command_list.append("exe:")
    if file:
        command_list.append("file:")
    if folder:
        command_list.append("folder:")
    if empty:
        command_list.append("empty:")
    if dateaccessed:
        command_list.append(f"da:{dateaccessed}")
    if datemodified:
        command_list.append(f"dm:{datemodified}")
    if datecreated:
        command_list.append(f"dc:{datecreated}")
    if size:
        command_list.append(f"size:{size}")
    if depth:
        command_list.append(f"depth:{depth}")
    if ext:
        command_list.append(f"ext:{ext}")
    if len_:
        command_list.append(f"len:{len_}")
    if length:
        command_list.append(f"length:{length}")

    # add the search terms
    if isinstance(search_term, list):
        command_list.extend(search_term)
    elif isinstance(search_term, str):
        command_list.append(search_term)

    # df = command_to_df1(command_list)
    df = command_to_df2(command_list)

    # create the EverythingFilelist object
    return EverythingFilelist(df)
