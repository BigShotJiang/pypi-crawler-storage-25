import datetime
import pandas as pd
from ext_pathlib import Path
from typing import Any, Union


class size:
    """
    A class to represent file size in bytes, kilobytes, megabytes, or gigabytes.

    Args:
        size (int | float | size): The size in bytes.

    Attributes:
        size (int): The size in bytes.
        bytes (int): The size in bytes.
        kb (float): The size in kilobytes.
        mb (float): The size in megabytes.
        gb (float): The size in gigabytes.

    Methods:
        __repr__(self)
        __str__(self)
        __int__(self)
        __add__(self, other)
        __sub__(self, other)
        __mul__(self, other)
        __truediv__(self, other)
        __lt__(self, other)
        __le__(self, other)
        __gt__(self, other)
        __ge__(self, other)
        __eq__(self, other)
        __ne__(self, other)
        __hash__(self)
    """

    def __init__(self, size_bytes: Union[int, float, "size"]):
        self.size: int = int(size_bytes)
        self.bytes: int = int(size_bytes)
        self.kb: int | float = round(self.bytes / 1024, 2)
        self.mb: int | float = round(self.bytes / 1024 / 1024, 2)
        self.gb: int | float = round(self.bytes / 1024 / 1024 / 1024, 2)

    def __repr__(self) -> str:
        # return f"<{self.size} bytes>"
        if self.kb < 1024:
            return f"<{self.kb} kb>"
        elif self.mb < 1024:
            return f"<{self.mb} mb>"
        else:
            return f"<{self.gb} gb>"

    def __str__(self) -> str:
        if self.kb < 1024:
            return f"{self.kb} kb"
        elif self.mb < 1024:
            return f"{self.mb} mb"
        else:
            return f"{self.gb} gb"

    def __int__(self):
        return self.bytes

    def __float__(self):
        return self.bytes

    def __add__(self, other):
        if isinstance(other, size):
            return size(self.bytes + other.bytes)
        else:
            return size(self.bytes + other)

    def __sub__(self, other):
        if isinstance(other, size):
            return size(self.bytes - other.bytes)
        else:
            return size(self.bytes - other)

    def __mul__(self, other):
        if isinstance(other, size):
            return size(self.bytes * other.bytes)
        else:
            return size(self.bytes * other)

    def __truediv__(self, other):
        if isinstance(other, size):
            return size(self.bytes / other.bytes)
        else:
            return size(self.bytes / other)

    def __lt__(self, other):
        if isinstance(other, size):
            return self.bytes < other.bytes
        else:
            return self.bytes < other

    def __gt__(self, other):
        if isinstance(other, size):
            return self.bytes > other.bytes
        else:
            return self.bytes > other

    def __eq__(self, other):
        if isinstance(other, size):
            return self.bytes == other.bytes
        else:
            return self.bytes == other

    def __ne__(self, other):
        if isinstance(other, size):
            return self.bytes != other.bytes
        else:
            return self.bytes != other

    def __le__(self, other):
        if isinstance(other, size):
            return self.bytes <= other.bytes
        else:
            return self.bytes <= other

    def __ge__(self, other):
        if isinstance(other, size):
            return self.bytes >= other.bytes
        else:
            return self.bytes >= other

    def __neg__(self):
        return size(-self.bytes)

    def __abs__(self):
        return size(abs(self.bytes))

    def __round__(self, ndigits=None):
        return size(round(self.bytes, ndigits))

    def __pos__(self):
        return size(+self.bytes)

    def __invert__(self):
        return size(~self.bytes)

    def __and__(self, other):
        if isinstance(other, size):
            return self.bytes & other.bytes
        else:
            return self.bytes & other

    def __or__(self, other):
        if isinstance(other, size):
            return self.bytes | other.bytes
        else:
            return self.bytes | other

    def __xor__(self, other):
        if isinstance(other, size):
            return self.bytes ^ other.bytes
        else:
            return self.bytes ^ other

    def __lshift__(self, other):
        if isinstance(other, size):
            return self.bytes << other.bytes
        else:
            return self.bytes << other

    def __rshift__(self, other):
        if isinstance(other, size):
            return self.bytes >> other.bytes
        else:
            return self.bytes >> other

    def __mod__(self, other):
        if isinstance(other, size):
            return size(self.bytes % other.bytes)
        else:
            return size(self.bytes % other)

    def __floordiv__(self, other):
        if isinstance(other, size):
            return size(self.bytes // other.bytes)
        else:
            return size(self.bytes // other)

    def __pow__(self, other):
        if isinstance(other, size):
            return size(self.bytes**other.bytes)
        else:
            return size(self.bytes**other)


class EverythingFile:
    """
    A class to represent an `Everything` file.

    Args:
        series (pd.Series): A pandas series containing the file information.

    Attributes:
        filename (Path): The path to the file.
        size (size): The size of the file.
        date_created (datetime.datetime): The date the file was created.
        date_modified (datetime.datetime): The date the file was last modified.
        date_accessed (datetime.datetime): The date the file was last accessed.
        bytes (int): The size in bytes.
        kb (float): The size in kilobytes.
        mb (float): The size in megabytes.
        gb (float): The size in gigabytes.

    Methods:
        is_recent(self, length, unit, date_type)
        copy(self, dest)
        move(self, dest)
        delete(self)
        __repr__(self)
        __str__(self)
        __eq__(self, other)
        __ne__(self, other)
        __hash__(self)
    """

    def __init__(self, series: pd.Series):
        self.filename: Path = Path(series["Filename"]).resolve()
        self.size: size = size(series["Size"])
        self.date_created: datetime.datetime = series["Date Created"].to_pydatetime()
        self.date_modified: datetime.datetime = series["Date Modified"].to_pydatetime()
        self.date_accessed: datetime.datetime = series["Date Accessed"].to_pydatetime()

        self.bytes: int = self.size.bytes
        self.kb: int | float = self.size.kb
        self.mb: int | float = self.size.mb
        self.gb: int | float = self.size.gb

    def is_recent(self, length: int, unit: str, date_type: str = "created") -> bool:
        """
        Check if the file is recent.

        Args:
            length (int): The length of time in the past.
            unit (str): The unit of time.
            date_type (str, optional): The type of date to check. Defaults to "created".

        Returns:
            bool: True if the file is recent, False otherwise.
        """

        # Check if date_type is valid
        date_type = date_type.strip().capitalize()
        if date_type not in ["Created", "Modified", "Accessed"]:
            raise ValueError(
                "date_type must be one of 'Created', 'Modified', or 'Accessed'"
            )

        # Get the date and compare it to now
        date = getattr(self, f"date_{date_type}")

        # Check if the date is recent
        return date > datetime.datetime.now() - datetime.timedelta(**{unit: length})

    def copy(self, dest: Path):
        self.filename.copy(dest)

    def move(self, dest: Path):
        self.filename.move(dest)

    def copy2(self, dest: Path):
        self.filename.copy2(dest)

    def move2(self, dest: Path):
        self.filename.move2(dest)

    def move_helper(self, dst: Path):
        return self.filename.move_helper(dst)

    def __repr__(self):
        return f"<{self.filename.parent.name}/{self.filename.name} | {self.size}>"

    def __str__(self) -> str:
        return str(self.filename)

    def __hash__(self):
        return hash(self.filename)

    def __eq__(self, other):
        return self.filename == other.filename

    def __ne__(self, other):
        return self.filename != other.filename


class EverythingFilelist:
    """
    A class to represent a list of `Everything` files.

    Args:
        df (pd.DataFrame): A pandas dataframe containing the file information.

    Attributes:
        files (list[EverythingFile]): A list of `EverythingFile` objects.
        df (pd.DataFrame): A pandas dataframe containing the file information.
        filenames (pd.Series): A pandas series containing the filenames.
        size (pd.Series): A pandas series containing the sizes.
        date_created (pd.Series): A pandas series containing the dates created.
        date_modified (pd.Series): A pandas series containing the dates modified.
        date_accessed (pd.Series): A pandas series containing the dates accessed.

    Methods:
        before(self, date, date_type="created")
        after(self, date, date_type="created")
        between(self, start, end, date_type="created")
        __add__(self, other)
        __repr__(self)
        __str__(self)
    """

    def __init__(self, df: pd.DataFrame):
        # Check if the dataframe is empty
        if not df.empty:
            # Convert the dataframe to a list of `EverythingFile` objects
            self.files: list = list(df.apply(EverythingFile, axis=1))

            # Store the dataframe
            self.df: pd.DataFrame = df

        # If the dataframe is empty, create an empty list and dataframe
        else:
            # Create an empty list
            self.files: list = []

            # Store the dataframe
            self.df: pd.DataFrame = df

        # Store the series
        self.filenames: pd.Series = self.df["Filename"]
        self.size: pd.Series = self.df["Size"]
        self.date_created: pd.Series = self.df["Date Created"]
        self.date_modified: pd.Series = self.df["Date Modified"]
        self.date_accessed: pd.Series = self.df["Date Accessed"]

    def before(
        self,
        date: datetime.datetime | tuple[int] | list[int],
        date_type: str = "created",
    ) -> "EverythingFilelist":
        """
        Returns all files that were created/modified/accessed before `date`.
        """

        # Check if date_type is valid
        date_type = date_type.strip().capitalize()
        if date_type not in ["Created", "Modified", "Accessed"]:
            raise ValueError(
                "date_type must be one of 'Created', 'Modified', or 'Accessed'"
            )

        # Convert the date to a datetime object
        if isinstance(date, datetime.datetime):
            date_obj = date
        elif isinstance(date, (tuple, list)):
            date_obj = datetime.datetime(*date)

        # Return the files that were created/modified/accessed before the date
        return EverythingFilelist(self.df[self.df[f"Date {date_type}"] < date_obj])

    def after(
        self,
        date: datetime.datetime | tuple[int] | list[int],
        date_type: str = "created",
    ) -> "EverythingFilelist":
        """
        Returns all files that were created/modified/accessed after `date`.
        """

        # Check if date_type is valid
        date_type = date_type.strip().capitalize()
        if date_type not in ["Created", "Modified", "Accessed"]:
            raise ValueError(
                "date_type must be one of 'Created', 'Modified', or 'Accessed'"
            )

        # Convert the date to a datetime object
        if isinstance(date, datetime.datetime):
            date_obj = date
        elif isinstance(date, (tuple, list)):
            date_obj = datetime.datetime(*date)

        # Return the files that were created/modified/accessed after the date
        return EverythingFilelist(self.df[self.df[f"Date {date_type}"] > date_obj])

    def between(
        self,
        start: datetime.datetime | tuple[int] | list[int],
        end: datetime.datetime | tuple[int] | list[int],
        date_type: str = "created",
    ) -> "EverythingFilelist":
        """
        Returns all files that were created/modified/accessed between `start` and `end`.
        """

        # Check if date_type is valid
        date_type = date_type.strip().capitalize()
        if date_type not in ["Created", "Modified", "Accessed"]:
            raise ValueError(
                "date_type must be one of 'Created', 'Modified', or 'Accessed'"
            )

        # Convert the start date to datetime object
        if isinstance(start, datetime.datetime):
            start_obj = start
        elif isinstance(start, (tuple, list)):
            start_obj = datetime.datetime(*start)

        # Convert the end date to datetime object
        if isinstance(end, datetime.datetime):
            end_obj = end
        elif isinstance(end, (tuple, list)):
            end_obj = datetime.datetime(*end)

        # Return the files that were created/modified/accessed between the start and end dates
        return EverythingFilelist(
            self.df[
                (self.df[f"Date {date_type}"] > start_obj)
                & (self.df[f"Date {date_type}"] < end_obj)
            ]
        )

    def recent(
        self, length: int, unit: str, date_type: str = "created"
    ) -> "EverythingFilelist":
        """
        Returns all files that were created/modified/accessed in the last `length` `unit`."
        """

        return self.after(
            datetime.datetime.now() - datetime.timedelta(**{unit: length}),
            date_type=date_type,
        )

    def sort(
        self, by: str | list[str], ascending: bool | list[bool] = True
    ) -> "EverythingFilelist":
        """
        Returns a new `EverythingFilelist` object with the files sorted by `by`.
        """

        # Sort the files and return the new `EverythingFilelist` object
        return EverythingFilelist(self.df.sort_values(by=by, ascending=ascending))

    def __getitem__(
        self, index: Any
    ) -> Union[list["EverythingFile"], "EverythingFile", "EverythingFilelist"]:
        """
        Returns a list of `EverythingFile` objects, a `EverythingFile` object, or a `EverythingFilelist` object
        depending on the type of `index`.
        """
        if isinstance(index, (int, slice)):
            return self.files[index]
        else:
            return EverythingFilelist(self.df[index])

    def __repr__(self) -> str:
        # if len(self.files) > 5:
        #     string = "[\n"
        #     for f in self.files[:3]:
        #         string += "  " + repr(f) + ",\n"
        #     string += "  ...\n"
        #     string += f"  <{len(self.files) - 3} more items>"
        #     string += "\n]"
        #     return string
        # else:
        #     string = "[\n"
        #     for f in self.files:
        #         string += "  " + repr(f) + ",\n"
        #     string += "]"
        #     return string
        return f"<EverythingFilelist: {len(self.files)} items>"

    def __str__(self) -> str:
        return str(self.files)

    def __len__(self) -> int:
        return len(self.files)

    def __iter__(self):
        return iter(self.files)

    def __next__(self):
        return next(self.files)

    def __add__(self, other):
        return EverythingFilelist(pd.concat([self.df, other.df]))

    def __radd__(self, other):
        return self + other

    def __sub__(self, other):
        return EverythingFilelist(
            pd.concat([self.df, other.df]).drop_duplicates(keep=False)
        )

    def __rsub__(self, other):
        return self - other


if __name__ == "__main__":
    print(size(size(1000)) > 999)
    pass
