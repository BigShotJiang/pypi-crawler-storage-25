import logging
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

import cleanup_schema as cw
import schema_import as iw


def process_run_result(stdout: str, stderr: str, returncode: int):
    return SimpleNamespace(stdout=stdout, stderr=stderr, returncode=returncode)


def process_popen_result(stdout_lines, returncode: int):
    wait_called = {"value": False}

    def wait():
        wait_called["value"] = True

    proc = Mock()
    proc.stdout = stdout_lines
    proc.returncode = returncode
    proc.wait.side_effect = wait
    proc.wait_called = wait_called
    return proc


class CleanupSchemaSuite(unittest.TestCase):
    def setUp(self):
        config = iw.PostgresConfig(host="localhost", port="5432", database="myapp_db", user="postgres", password="")
        self.adapter = iw.PostgresAdapter(config)
        self.logger = logging.getLogger("cleanup-test")
        self.logger.handlers.clear()
        self.logger.addHandler(logging.NullHandler())

    def _cleanup(self, dry_run=False):
        return cw.SchemaCleanup(
            adapter=self.adapter,
            logger=self.logger,
            target_db="myapp_db",
            schemas=["myapp", "myapp_vector"],
            dry_run=dry_run,
            confirm_callback=lambda: True,
        )

    def test_validate_identifier_accepts_valid_name(self):
        self.assertEqual("myapp_db", cw.validate_identifier("myapp_db"))

    def test_validate_identifier_rejects_invalid_name(self):
        with self.assertRaises(ValueError):
            cw.validate_identifier("schema-db")

    def test_parse_schema_list(self):
        self.assertEqual(["myapp", "myapp_vector"], cw.parse_schema_list("myapp, myapp_vector"))

    def test_parse_schema_list_rejects_empty(self):
        with self.assertRaises(ValueError):
            cw.parse_schema_list(" , ")

    def test_sql_literal_escapes_quotes(self):
        self.assertEqual("'ab''cd'", cw.sql_literal("ab'cd"))

    def test_parse_args(self):
        args = cw.parse_args(
            ["--target-db", "myapp_db", "--schemas", "myapp", "--dry-run", "--config-file", "cleanup.ini"]
        )
        self.assertEqual("myapp_db", args.target_db)
        self.assertEqual("myapp", args.schemas)
        self.assertTrue(args.dry_run)
        self.assertEqual("cleanup.ini", args.config_file)

    def test_parse_args_default_target_db(self):
        args = cw.parse_args([])
        self.assertIsNone(args.target_db)

    def test_ensure_target_db_is_safe_accepts_schema(self):
        self.assertEqual("myapp_db", cw.ensure_target_db_is_safe("myapp_db"))

    def test_ensure_target_db_is_safe_rejects_postgres(self):
        with self.assertRaises(ValueError):
            cw.ensure_target_db_is_safe("postgres")

    def test_run_dry_run(self):
        cleanup = self._cleanup(dry_run=True)
        self.assertEqual(0, cleanup.run())

    @patch.object(cw.SchemaCleanup, "_run_psql_command", side_effect=[0, 0, 0])
    @patch.object(cw.SchemaCleanup, "_database_exists", return_value=True)
    @patch.object(iw.PostgresAdapter, "_resolve_psql_executable", return_value="psql")
    def test_run_when_database_exists(self, _resolve_mock: Mock, _exists_mock: Mock, run_mock: Mock):
        cleanup = self._cleanup(dry_run=False)

        rc = cleanup.run()

        self.assertEqual(0, rc)
        self.assertEqual(3, run_mock.call_count)
        self.assertEqual("myapp_db", run_mock.call_args_list[0].args[1])
        self.assertEqual("postgres", run_mock.call_args_list[1].args[1])
        self.assertEqual("postgres", run_mock.call_args_list[2].args[1])

    @patch.object(cw.SchemaCleanup, "_run_psql_command", side_effect=[0, 0])
    @patch.object(cw.SchemaCleanup, "_database_exists", return_value=False)
    @patch.object(iw.PostgresAdapter, "_resolve_psql_executable", return_value="psql")
    def test_run_when_database_missing(self, _resolve_mock: Mock, _exists_mock: Mock, run_mock: Mock):
        cleanup = self._cleanup(dry_run=False)

        rc = cleanup.run()

        self.assertEqual(0, rc)
        self.assertEqual(2, run_mock.call_count)
        self.assertEqual("postgres", run_mock.call_args_list[0].args[1])
        self.assertEqual("postgres", run_mock.call_args_list[1].args[1])

    @patch.object(cw.SchemaCleanup, "_run_psql_command", side_effect=[9])
    @patch.object(cw.SchemaCleanup, "_database_exists", return_value=True)
    @patch.object(iw.PostgresAdapter, "_resolve_psql_executable", return_value="psql")
    def test_run_stops_on_schema_error(self, _resolve_mock: Mock, _exists_mock: Mock, run_mock: Mock):
        cleanup = self._cleanup(dry_run=False)

        rc = cleanup.run()

        self.assertEqual(9, rc)
        self.assertEqual(1, run_mock.call_count)

    @patch.object(cw.SchemaCleanup, "_run_psql_command")
    @patch.object(cw.SchemaCleanup, "_database_exists")
    @patch.object(iw.PostgresAdapter, "_resolve_psql_executable")
    def test_run_cancelled_when_confirmation_rejected(
        self,
        resolve_mock: Mock,
        exists_mock: Mock,
        run_mock: Mock,
    ):
        cleanup = cw.SchemaCleanup(
            adapter=self.adapter,
            logger=self.logger,
            target_db="myapp_db",
            schemas=["myapp", "myapp_vector"],
            dry_run=False,
            confirm_callback=lambda: False,
        )

        rc = cleanup.run()

        self.assertEqual(2, rc)
        resolve_mock.assert_not_called()
        exists_mock.assert_not_called()
        run_mock.assert_not_called()

    @patch("schema_cleanup.schema_cleanup_service.input", return_value="YES")
    @patch("schema_cleanup.schema_cleanup_service.print")
    def test_confirm_cleanup_accepts_yes(self, _print_mock: Mock, _input_mock: Mock):
        cleanup = cw.SchemaCleanup(
            adapter=self.adapter,
            logger=self.logger,
            target_db="myapp_db",
            schemas=["myapp", "myapp_vector"],
            dry_run=False,
        )

        self.assertTrue(cleanup._confirm_cleanup())

    @patch("schema_cleanup.schema_cleanup_service.input", return_value="no")
    @patch("schema_cleanup.schema_cleanup_service.print")
    def test_confirm_cleanup_rejects_non_yes(self, _print_mock: Mock, _input_mock: Mock):
        cleanup = cw.SchemaCleanup(
            adapter=self.adapter,
            logger=self.logger,
            target_db="myapp_db",
            schemas=["myapp", "myapp_vector"],
            dry_run=False,
        )

        self.assertFalse(cleanup._confirm_cleanup())

    @patch("schema_cleanup.schema_cleanup_service.subprocess.run")
    def test_database_exists_true(self, run_mock: Mock):
        run_mock.return_value = process_run_result(stdout="1\n", stderr="", returncode=0)
        cleanup = self._cleanup()
        exists = cleanup._database_exists("psql", {})
        self.assertTrue(exists)

    @patch("schema_cleanup.schema_cleanup_service.subprocess.run")
    def test_database_exists_raises_on_error(self, run_mock: Mock):
        run_mock.return_value = process_run_result(stdout="", stderr="boom", returncode=1)
        cleanup = self._cleanup()
        with self.assertRaises(RuntimeError):
            cleanup._database_exists("psql", {})

    @patch("schema_cleanup.schema_cleanup_service.subprocess.Popen")
    @patch("builtins.print")
    def test_run_psql_command_streams_output(self, print_mock: Mock, popen_mock: Mock):
        proc = process_popen_result(["ok\n"], 0)
        popen_mock.return_value = proc

        cleanup = self._cleanup()
        rc = cleanup._run_psql_command("psql", "postgres", "SELECT 1;", {})

        self.assertEqual(0, rc)
        self.assertTrue(proc.wait_called["value"])
        self.assertEqual(1, print_mock.call_count)

    def test_schema_cleanup_sql_contains_both_schemas(self):
        cleanup = self._cleanup()
        sql = cleanup._schema_cleanup_sql()
        self.assertIn('DROP SCHEMA IF EXISTS "myapp" CASCADE;', sql)
        self.assertIn('DROP SCHEMA IF EXISTS "myapp_vector" CASCADE;', sql)

    def test_drop_database_sql_targets_database(self):
        cleanup = self._cleanup()
        sql = cleanup._drop_database_sql()
        self.assertIn('DROP DATABASE IF EXISTS "myapp_db";', sql)

    def test_terminate_sessions_sql_targets_database(self):
        cleanup = self._cleanup()
        sql = cleanup._terminate_sessions_sql()
        self.assertIn("pg_terminate_backend", sql)

    @patch("schema_cleanup.main.SchemaCleanup")
    @patch("schema_cleanup.main.setup_logging")
    @patch("schema_cleanup.main.parse_args")
    @patch("schema_cleanup.main.load_dotenv")
    def test_main_happy_path(
        self,
        _load_dotenv_mock: Mock,
        parse_args_mock: Mock,
        setup_logging_mock: Mock,
        cleanup_cls_mock: Mock,
    ):
        parse_args_mock.return_value = type(
            "Args", (), {"target_db": "myapp_db", "schemas": "myapp", "dry_run": True, "config_file": None, "config_section": "DEFAULT"}
        )
        setup_logging_mock.return_value = logging.getLogger("cleanup-main-test")
        cleanup_instance = cleanup_cls_mock.return_value
        cleanup_instance.run.return_value = 0

        with tempfile.TemporaryDirectory() as tmp, patch.dict(
            "os.environ",
            {
                "PGHOST": "localhost",
                "PGPORT": "5432",
                "PGUSER": "postgres",
                "LOG_LEVEL": "INFO",
            },
            clear=False,
        ), patch("schema_cleanup.main.Path.cwd", return_value=Path(tmp)):
            rc = cw.main(["--dry-run"])

        self.assertEqual(0, rc)
        cleanup_instance.run.assert_called_once()
