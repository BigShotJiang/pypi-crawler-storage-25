import logging
import tempfile
import unittest
from argparse import Namespace
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

import schema_import as iw


def make_dummy_adapter(return_code: int = 0):
    state = {"last_wrapper": None, "last_dry_run": None}

    def execute(wrapper_sql: Path, logger: logging.Logger, dry_run: bool) -> int:
        _ = logger
        state["last_wrapper"] = wrapper_sql
        state["last_dry_run"] = dry_run
        return return_code

    return SimpleNamespace(name="dummy", execute=execute, state=state)


def make_process_mock(stdout_lines, return_code: int):
    wait_called = {"value": False}

    def wait():
        wait_called["value"] = True

    process = Mock()
    process.stdout = stdout_lines
    process.returncode = return_code
    process.wait.side_effect = wait
    process.wait_called = wait_called
    return process


def make_logger(name: str) -> logging.Logger:
    logger = logging.getLogger(name)
    logger.handlers.clear()
    logger.addHandler(logging.NullHandler())
    return logger


class ImportWizardSuite(unittest.TestCase):
    def test_rewrite_includes_to_absolute_posix_path(self):
        transformer = iw.SqlTransformer()
        with tempfile.TemporaryDirectory() as tmp:
            base_dir = Path(tmp) / "sql"
            staging = Path(tmp) / "staging"
            base_dir.mkdir(parents=True)
            staging.mkdir(parents=True)

            sql = "\\i './child.sql'"
            rewritten, changes = transformer.rewrite_includes(sql, base_dir, staging)

            self.assertIn("/child.sql'", rewritten)
            self.assertEqual(1, len(changes))

    def test_patch_csv_paths_collects_names(self):
        transformer = iw.SqlTransformer()
        with tempfile.TemporaryDirectory() as tmp:
            staging = Path(tmp) / "staging"
            staging.mkdir(parents=True)

            sql = "\\copy t FROM 'inputs/prompts.csv' WITH (FORMAT csv)"
            patched, changes, names = transformer.patch_csv_paths(sql, staging)

            self.assertIn("prompts.csv", names)
            self.assertEqual(1, len(changes))
            self.assertIn((staging / "prompts.csv").resolve().as_posix(), patched)

    def test_warn_if_server_copy_logs_warning(self):
        transformer = iw.SqlTransformer()
        logger = logging.getLogger("copy-warning-test")
        with self.assertLogs("copy-warning-test", level="WARNING") as capture:
            transformer.warn_if_server_copy("COPY my_table FROM '/tmp/a.csv'", logger)
        self.assertTrue(any("Prefer \\copy" in line for line in capture.output))

    def test_warn_if_server_copy_no_warning_for_psql_copy(self):
        transformer = iw.SqlTransformer()
        logger = logging.getLogger("copy-no-warning-test")
        with patch.object(logger, "warning") as warning_mock:
            transformer.warn_if_server_copy("\\copy my_table FROM '/tmp/a.csv'", logger)
        warning_mock.assert_not_called()

    def test_abstract_property_raises_not_implemented(self):
        with self.assertRaises(NotImplementedError):
            iw.DatabaseAdapter.name.fget(object())

    def test_abstract_execute_raises_not_implemented(self):
        with self.assertRaises(NotImplementedError):
            iw.DatabaseAdapter.execute(object(), Path("master.sql"), logging.getLogger("x"), False)

    def test_postgres_adapter_name_and_command(self):
        cfg = iw.PostgresConfig(host="localhost", port="5432", database="db", user="user", password="pw")
        adapter = iw.PostgresAdapter(cfg)

        self.assertEqual("postgres", adapter.name)
        command = adapter._command(Path("master.sql"))
        self.assertEqual("psql", command[0])
        self.assertIn("-d", command)
        self.assertIn("master.sql", " ".join(command))

    def test_postgres_adapter_execute_dry_run(self):
        cfg = iw.PostgresConfig(host="localhost", port="5432", database="db", user="user", password="pw")
        adapter = iw.PostgresAdapter(cfg)

        rc = adapter.execute(Path("master.sql"), make_logger("postgres-dry-run"), dry_run=True)
        self.assertEqual(0, rc)

    @patch("schema_importer.postgres_adapter.shutil.which", return_value="psql")
    @patch("schema_importer.postgres_adapter.subprocess.Popen")
    @patch("builtins.print")
    def test_execute_runs_process_and_logs_output(self, print_mock: Mock, popen_mock: Mock, _which_mock: Mock):
        cfg = iw.PostgresConfig(host="localhost", port="5432", database="db", user="user", password="pw")
        adapter = iw.PostgresAdapter(cfg)
        proc = make_process_mock(["line1\n", "line2\n"], 7)
        popen_mock.return_value = proc

        rc = adapter.execute(Path("master.sql"), make_logger("postgres-run"), dry_run=False)

        self.assertEqual(7, rc)
        self.assertTrue(proc.wait_called["value"])
        self.assertEqual(2, print_mock.call_count)
        env = popen_mock.call_args.kwargs["env"]
        self.assertEqual("pw", env["PGPASSWORD"])

    @patch("schema_importer.postgres_adapter.shutil.which", return_value="psql")
    @patch("schema_importer.postgres_adapter.subprocess.Popen")
    @patch("builtins.print")
    def test_execute_retries_against_postgres_when_db_missing(
        self, print_mock: Mock, popen_mock: Mock, _which_mock: Mock
    ):
        cfg = iw.PostgresConfig(host="localhost", port="5432", database="db", user="user", password="pw")
        adapter = iw.PostgresAdapter(cfg)
        first = make_process_mock(['psql: error: FATAL:  database "db" does not exist\n'], 2)
        second = make_process_mock(["ok\n"], 0)
        popen_mock.side_effect = [first, second]

        rc = adapter.execute(Path("master.sql"), make_logger("postgres-retry-db"), dry_run=False)

        self.assertEqual(0, rc)
        self.assertEqual(2, popen_mock.call_count)
        second_call_command = popen_mock.call_args_list[1].args[0]
        self.assertEqual("postgres", second_call_command[second_call_command.index("-d") + 1])
        self.assertGreaterEqual(print_mock.call_count, 1)

    @patch("schema_importer.postgres_adapter.shutil.which", return_value="psql")
    @patch("schema_importer.postgres_adapter.subprocess.Popen")
    @patch("builtins.print")
    def test_execute_retries_without_pgvector_when_enabled(
        self, print_mock: Mock, popen_mock: Mock, _which_mock: Mock
    ):
        cfg = iw.PostgresConfig(host="localhost", port="5432", database="db", user="user", password="pw")
        adapter = iw.PostgresAdapter(cfg)
        first = make_process_mock(['psql:pg_vector.sql:4: ERROR:  extension "vector" is not available\n'], 3)
        second = make_process_mock(["ok\n"], 0)
        popen_mock.side_effect = [first, second]

        with tempfile.TemporaryDirectory() as tmp, patch.dict(
            "os.environ", {"ALLOW_MISSING_PGVECTOR": "true"}, clear=False
        ):
            wrapper = Path(tmp) / "master.sql"
            wrapper.write_text("\\set ON_ERROR_STOP on\n\\i 'schema_setup.sql'\n\\i 'pg_vector.sql'\n", encoding="utf-8")

            rc = adapter.execute(wrapper, make_logger("postgres-retry-vector"), dry_run=False)

        self.assertEqual(0, rc)
        self.assertEqual(2, popen_mock.call_count)
        second_call_command = popen_mock.call_args_list[1].args[0]
        self.assertIn("master_no_pgvector.sql", second_call_command[second_call_command.index("-f") + 1])
        self.assertGreaterEqual(print_mock.call_count, 1)

    @patch("schema_importer.postgres_adapter.shutil.which", return_value="psql")
    @patch("schema_importer.postgres_adapter.subprocess.Popen")
    def test_execute_handles_none_stdout(self, popen_mock: Mock, _which_mock: Mock):
        cfg = iw.PostgresConfig(host="localhost", port="5432", database="db", user="user", password="pw")
        adapter = iw.PostgresAdapter(cfg)
        proc = make_process_mock(None, 0)
        popen_mock.return_value = proc

        rc = adapter.execute(Path("master.sql"), make_logger("postgres-none-stdout"), dry_run=False)

        self.assertEqual(0, rc)
        self.assertTrue(proc.wait_called["value"])

    @patch("schema_importer.postgres_adapter.shutil.which", return_value=None)
    def test_execute_raises_clear_error_when_psql_missing(self, _which_mock: Mock):
        cfg = iw.PostgresConfig(host="localhost", port="5432", database="db", user="user", password="pw")
        adapter = iw.PostgresAdapter(cfg)

        with self.assertRaises(FileNotFoundError) as exc:
            adapter.execute(Path("master.sql"), make_logger("postgres-no-psql"), dry_run=False)

        self.assertIn("Install psql", str(exc.exception))

    def test_resolve_psql_executable_with_explicit_path(self):
        cfg = iw.PostgresConfig(host="localhost", port="5432", database="db", user="user", password="pw")
        adapter = iw.PostgresAdapter(cfg)
        with tempfile.TemporaryDirectory() as tmp:
            fake_psql = Path(tmp) / "psql.exe"
            fake_psql.write_text("", encoding="utf-8")
            with patch.dict("os.environ", {"PSQL_BIN": str(fake_psql)}, clear=False):
                self.assertEqual(str(fake_psql), adapter._resolve_psql_executable())

    def test_resolve_psql_executable_explicit_path_missing(self):
        cfg = iw.PostgresConfig(host="localhost", port="5432", database="db", user="user", password="pw")
        adapter = iw.PostgresAdapter(cfg)
        with patch.dict("os.environ", {"PSQL_BIN": "C:/missing/psql.exe"}, clear=False):
            with self.assertRaises(FileNotFoundError) as exc:
                adapter._resolve_psql_executable()
        self.assertIn("PSQL_BIN is set but not found", str(exc.exception))

    def test_should_retry_with_postgres_false_on_success(self):
        cfg = iw.PostgresConfig(host="localhost", port="5432", database="db", user="user", password="pw")
        adapter = iw.PostgresAdapter(cfg)
        self.assertFalse(adapter._should_retry_with_postgres(0, []))

    def test_should_retry_with_postgres_false_when_already_postgres_db(self):
        adapter = iw.PostgresAdapter(iw.PostgresConfig(host="h", port="5432", database="postgres", user="u", password="p"))
        self.assertFalse(adapter._should_retry_with_postgres(2, ['database "postgres" does not exist']))

    def test_allow_missing_pgvector_flag_values(self):
        cfg = iw.PostgresConfig(host="localhost", port="5432", database="db", user="user", password="pw")
        adapter = iw.PostgresAdapter(cfg)
        with patch.dict("os.environ", {"ALLOW_MISSING_PGVECTOR": "true"}, clear=False):
            self.assertTrue(adapter._allow_missing_pgvector())
        with patch.dict("os.environ", {"ALLOW_MISSING_PGVECTOR": "0"}, clear=False):
            self.assertFalse(adapter._allow_missing_pgvector())

    def test_should_retry_without_pgvector_detection(self):
        cfg = iw.PostgresConfig(host="localhost", port="5432", database="db", user="user", password="pw")
        adapter = iw.PostgresAdapter(cfg)
        self.assertTrue(adapter._should_retry_without_pgvector(3, ['ERROR: extension "vector" is not available']))
        self.assertFalse(adapter._should_retry_without_pgvector(0, []))

    def test_build_wrapper_without_pgvector(self):
        cfg = iw.PostgresConfig(host="localhost", port="5432", database="db", user="user", password="pw")
        adapter = iw.PostgresAdapter(cfg)
        with tempfile.TemporaryDirectory() as tmp:
            wrapper = Path(tmp) / "master.sql"
            wrapper.write_text("\\i 'a.sql'\n\\i 'pg_vector.sql'\n", encoding="utf-8")
            result = adapter._build_wrapper_without_pgvector(wrapper)
            self.assertIsNotNone(result)
            self.assertIn("a.sql", result.read_text(encoding="utf-8"))
            self.assertNotIn("pg_vector.sql", result.read_text(encoding="utf-8"))

    def test_build_wrapper_without_pgvector_no_change(self):
        cfg = iw.PostgresConfig(host="localhost", port="5432", database="db", user="user", password="pw")
        adapter = iw.PostgresAdapter(cfg)
        with tempfile.TemporaryDirectory() as tmp:
            wrapper = Path(tmp) / "master.sql"
            wrapper.write_text("\\i 'a.sql'\n", encoding="utf-8")
            result = adapter._build_wrapper_without_pgvector(wrapper)
            self.assertIsNone(result)

    def test_mysql_adapter_contract(self):
        adapter = iw.MySqlAdapter()
        self.assertEqual("mysql", adapter.name)
        with self.assertRaises(NotImplementedError):
            adapter.execute(Path("master.sql"), logging.getLogger("x"), False)

    def test_mongodb_adapter_contract(self):
        adapter = iw.MongoDbAdapter()
        self.assertEqual("mongodb", adapter.name)
        with self.assertRaises(NotImplementedError):
            adapter.execute(Path("master.sql"), logging.getLogger("x"), False)

    def test_factory_creates_postgres_adapter(self):
        with patch.dict(
            "os.environ",
            {
                "PGHOST": "localhost",
                "PGPORT": "5432",
                "PGDATABASE": "db",
                "PGUSER": "user",
                "PGPASSWORD": "pw",
            },
            clear=False,
        ):
            adapter = iw.AdapterFactory.create("postgres")
            self.assertIsInstance(adapter, iw.PostgresAdapter)

    def test_factory_rejects_unknown_database(self):
        with self.assertRaises(ValueError):
            iw.AdapterFactory.create("oracle")

    def test_factory_creates_mysql_adapter(self):
        self.assertIsInstance(iw.AdapterFactory.create("mysql"), iw.MySqlAdapter)

    def test_factory_creates_mongodb_adapter(self):
        self.assertIsInstance(iw.AdapterFactory.create("mongodb"), iw.MongoDbAdapter)

    def test_run_stages_sql_and_returns_adapter_code(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "inputs"
            root.mkdir(parents=True)
            (root / "prompts.csv").write_text("id,name\n1,sample\n", encoding="utf-8")
            (root / "init.sql").write_text(
                "\\copy schema.prompt FROM 'prompts.csv' WITH (FORMAT csv, HEADER true);\n",
                encoding="utf-8",
            )

            config = iw.RuntimeConfig(root=root, sql_order=["init.sql"], log_level="INFO", target_db="postgres", dry_run=True)
            adapter = make_dummy_adapter(return_code=0)
            wizard = iw.ImportWizard(config, adapter, make_logger("wizard-test"))

            rc = wizard.run()

            self.assertEqual(0, rc)
            self.assertTrue((wizard.staging_dir / "init.sql").exists())
            self.assertTrue((wizard.staging_dir / "prompts.csv").exists())
            self.assertTrue((wizard.staging_dir / "master.sql").exists())
            self.assertTrue(adapter.state["last_wrapper"].exists())
            self.assertTrue(adapter.state["last_dry_run"])

    def test_run_fails_on_ambiguous_csv(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "inputs"
            (root / "a").mkdir(parents=True)
            (root / "b").mkdir(parents=True)
            (root / "a" / "prompts.csv").write_text("id\n1\n", encoding="utf-8")
            (root / "b" / "prompts.csv").write_text("id\n2\n", encoding="utf-8")
            (root / "init.sql").write_text(
                "\\copy schema.prompt FROM 'prompts.csv' WITH (FORMAT csv, HEADER true);\n",
                encoding="utf-8",
            )

            config = iw.RuntimeConfig(root=root, sql_order=["init.sql"], log_level="INFO", target_db="postgres", dry_run=True)
            wizard = iw.ImportWizard(config, make_dummy_adapter(0), make_logger("wizard-ambiguous"))

            with self.assertRaises(ValueError):
                wizard.run()

    def test_run_fails_on_missing_sql_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "inputs"
            root.mkdir(parents=True)

            config = iw.RuntimeConfig(root=root, sql_order=["missing.sql"], log_level="INFO", target_db="postgres", dry_run=True)
            wizard = iw.ImportWizard(config, make_dummy_adapter(0), make_logger("wizard-missing-sql"))

            with self.assertRaises(FileNotFoundError):
                wizard.run()

    def test_run_fails_on_missing_csv(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "inputs"
            root.mkdir(parents=True)
            (root / "init.sql").write_text(
                "\\copy schema.prompt FROM 'missing.csv' WITH (FORMAT csv, HEADER true);\n",
                encoding="utf-8",
            )

            config = iw.RuntimeConfig(root=root, sql_order=["init.sql"], log_level="INFO", target_db="postgres", dry_run=True)
            wizard = iw.ImportWizard(config, make_dummy_adapter(0), make_logger("wizard-missing-csv"))

            with self.assertRaises(FileNotFoundError):
                wizard.run()

    def test_run_logs_failure_when_adapter_returns_non_zero(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "inputs"
            root.mkdir(parents=True)
            (root / "init.sql").write_text("SELECT 1;\n", encoding="utf-8")

            config = iw.RuntimeConfig(root=root, sql_order=["init.sql"], log_level="INFO", target_db="postgres", dry_run=False)
            logger = logging.getLogger("wizard-failure-test")

            with self.assertLogs("wizard-failure-test", level="ERROR") as capture:
                wizard = iw.ImportWizard(config, make_dummy_adapter(5), logger)
                rc = wizard.run()

            self.assertEqual(5, rc)
            self.assertTrue(any("Import failed with code=5" in line for line in capture.output))

    def test_include_rewrite_debug_path_is_executed(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "inputs"
            root.mkdir(parents=True)
            (root / "child.sql").write_text("SELECT 1;\n", encoding="utf-8")
            (root / "init.sql").write_text("\\i './child.sql'\n", encoding="utf-8")

            config = iw.RuntimeConfig(root=root, sql_order=["init.sql"], log_level="DEBUG", target_db="postgres", dry_run=True)

            logger = logging.getLogger("wizard-include-debug-test")
            with self.assertLogs("wizard-include-debug-test", level="DEBUG") as capture:
                wizard = iw.ImportWizard(config, make_dummy_adapter(0), logger)
                wizard.run()

            self.assertTrue(any("Include rewrite:" in line for line in capture.output))

    def test_setup_logging_creates_handlers(self):
        with tempfile.TemporaryDirectory() as tmp:
            logger = iw.setup_logging(Path(tmp) / "import.log", "DEBUG")
            self.assertGreaterEqual(len(logger.handlers), 2)
            for handler in list(logger.handlers):
                handler.close()
                logger.removeHandler(handler)

    def test_env_required_success_and_failure(self):
        with patch.dict("os.environ", {"REQ": "x"}, clear=False):
            self.assertEqual("x", iw.env_required("REQ"))

        with patch.dict("os.environ", {}, clear=True):
            with self.assertRaises(ValueError):
                iw.env_required("REQ")

    def test_normalize_sql_order(self):
        self.assertEqual(["a.sql", "b.sql"], iw.normalize_sql_order("a.sql, b.sql,   "))

    def test_timestamp_returns_non_empty(self):
        self.assertTrue(iw.timestamp())

    def test_parse_args(self):
        args = iw.parse_args(["--dry-run", "--target-db", "mongodb", "--config-file", "import_schema.ini"])
        self.assertTrue(args.dry_run)
        self.assertEqual("mongodb", args.target_db)
        self.assertEqual("import_schema.ini", args.config_file)

    def test_build_runtime_config_success(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "inputs"
            root.mkdir(parents=True)
            with patch.dict(
                "os.environ",
                {
                    "SCHEMA_IMPORT_ROOT": str(root),
                    "SQL_ORDER": "a.sql,b.sql",
                    "LOG_LEVEL": "DEBUG",
                },
                clear=False,
            ):
                cfg = iw.build_runtime_config(Namespace(target_db="postgres", dry_run=True))
                self.assertEqual(root.resolve(), cfg.root)
                self.assertEqual(["a.sql", "b.sql"], cfg.sql_order)
                self.assertEqual("DEBUG", cfg.log_level)

    def test_build_runtime_config_missing_directory(self):
        with patch.dict(
            "os.environ",
            {
                "SCHEMA_IMPORT_ROOT": "C:/definitely/not/real/dir",
                "SQL_ORDER": "a.sql",
            },
            clear=False,
        ):
            with self.assertRaises(FileNotFoundError):
                iw.build_runtime_config(Namespace(target_db="postgres", dry_run=True))

    def test_build_runtime_config_empty_sql_order(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "inputs"
            root.mkdir(parents=True)
            with patch.dict(
                "os.environ",
                {
                    "SCHEMA_IMPORT_ROOT": str(root),
                    "SQL_ORDER": " , ",
                },
                clear=False,
            ):
                with self.assertRaises(ValueError):
                    iw.build_runtime_config(Namespace(target_db="postgres", dry_run=True))

    @patch("schema_importer.main.ImportWizard")
    @patch("schema_importer.main.AdapterFactory.create")
    @patch("schema_importer.main.setup_logging")
    @patch("schema_importer.main.build_runtime_config")
    @patch("schema_importer.main.parse_args")
    @patch("schema_importer.main.load_dotenv")
    def test_main_with_explicit_argv(
        self,
        load_dotenv_mock: Mock,
        parse_args_mock: Mock,
        build_runtime_config_mock: Mock,
        setup_logging_mock: Mock,
        factory_mock: Mock,
        wizard_cls_mock: Mock,
    ):
        parse_args_mock.return_value = Namespace(config_file=None, config_section="DEFAULT", target_db="postgres")
        runtime_cfg = iw.RuntimeConfig(
            root=Path.cwd(),
            sql_order=["a.sql"],
            log_level="INFO",
            target_db="postgres",
            dry_run=True,
        )
        build_runtime_config_mock.return_value = runtime_cfg
        setup_logging_mock.return_value = logging.getLogger("main-test")
        factory_mock.return_value = make_dummy_adapter(return_code=0)
        wizard_instance = wizard_cls_mock.return_value
        wizard_instance.run.return_value = 0

        rc = iw.main(["--dry-run"])

        self.assertEqual(0, rc)
        load_dotenv_mock.assert_called_once()
        parse_args_mock.assert_called_once_with(["--dry-run"])
        build_runtime_config_mock.assert_called_once()
        setup_logging_mock.assert_called_once()
        factory_mock.assert_called_once_with("postgres")
        wizard_instance.run.assert_called_once()

    @patch("schema_import.main", return_value=0)
    def test_module_entrypoint_line_is_excluded_from_coverage(self, _main_mock: Mock):
        self.assertTrue(True)
