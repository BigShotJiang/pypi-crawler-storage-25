import tempfile
import textwrap
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from schema_importer.mcp_tools import handle_check_connection, handle_cleanup_schema, handle_import_schema


class McpToolsSuite(unittest.TestCase):
    def _write_ini(self, content: str) -> str:
        with tempfile.NamedTemporaryFile("w", suffix=".ini", delete=False, encoding="utf-8") as fh:
            fh.write(textwrap.dedent(content).strip() + "\n")
            return fh.name

    @patch("schema_importer.mcp_tools.ImportWizard.run", return_value=0)
    def test_import_schema_dry_run_success(self, _run_mock: Mock):
        with tempfile.TemporaryDirectory() as tmp, patch.dict(
            "os.environ",
            {"PGPASSWORD": "pw"},
            clear=False,
        ):
            root = Path(tmp) / "inputs"
            root.mkdir(parents=True)

            result = handle_import_schema(
                {
                    "connection": {
                        "host": "localhost",
                        "port": 5432,
                        "user": "postgres",
                        "database": "postgres",
                    },
                    "importConfig": {
                        "schemaImportRoot": str(root),
                        "sqlOrder": ["schema_setup.sql"],
                        "targetDbAdapter": "postgres",
                        "dryRun": True,
                    },
                }
            )

        self.assertTrue(result["ok"])
        self.assertTrue(result["dryRun"])
        self.assertEqual("postgres", result["targetDbAdapter"])
        self.assertEqual(["schema_setup.sql"], result["plannedSqlFiles"])

    @patch("schema_importer.mcp_tools.SchemaCleanup.run", return_value=0)
    def test_cleanup_schema_requires_confirm_when_non_dry_run(self, _run_mock: Mock):
        with self.assertRaises(ValueError):
            handle_cleanup_schema(
                {
                    "connection": {
                        "host": "localhost",
                        "port": 5432,
                        "user": "postgres",
                        "database": "myapp_db",
                        "password": "pw",
                    },
                    "cleanupConfig": {
                        "targetDb": "myapp_db",
                        "schemas": ["myapp"],
                        "dryRun": False,
                    },
                }
            )

    @patch("schema_importer.mcp_tools.SchemaCleanup.run", return_value=0)
    def test_cleanup_schema_dry_run_success(self, _run_mock: Mock):
        result = handle_cleanup_schema(
            {
                "connection": {
                    "host": "localhost",
                    "port": 5432,
                    "user": "postgres",
                    "database": "myapp_db",
                    "password": "pw",
                },
                "cleanupConfig": {
                    "targetDb": "myapp_db",
                    "schemas": ["myapp", "myapp_vector"],
                    "dryRun": True,
                },
            }
        )

        self.assertTrue(result["ok"])
        self.assertTrue(result["dryRun"])
        self.assertEqual("myapp_db", result["targetDb"])

    @patch("schema_importer.mcp_tools.ConnectionChecker.run", return_value=0)
    def test_check_connection_success_contract(self, _run_mock: Mock):
        result = handle_check_connection(
            {
                "connection": {
                    "host": "localhost",
                    "port": 5432,
                    "user": "postgres",
                    "database": "postgres",
                    "password": "pw",
                },
                "authorizationChecks": {"mode": "import", "schemas": ["myapp"]},
            }
        )

        self.assertTrue(result["ok"])
        self.assertTrue(result["connected"])
        self.assertTrue(result["authorized"])
        self.assertEqual("import", result["mode"])
        self.assertTrue(any(item["name"] == "connect" for item in result["checks"]))

    @patch("schema_importer.mcp_tools.ConnectionChecker.run", return_value=2)
    def test_check_connection_unauthorized_contract(self, _run_mock: Mock):
        result = handle_check_connection(
            {
                "connection": {
                    "host": "localhost",
                    "port": 5432,
                    "user": "postgres",
                    "database": "postgres",
                    "password": "pw",
                },
                "authorizationChecks": {"mode": "cleanup", "schemas": ["myapp"]},
            }
        )

        self.assertFalse(result["ok"])
        self.assertTrue(result["connected"])
        self.assertFalse(result["authorized"])
        self.assertEqual("cleanup", result["mode"])

    @patch("schema_importer.mcp_tools.ConnectionChecker.run", return_value=0)
    def test_check_connection_can_use_ini_config_source(self, _run_mock: Mock):
        ini_path = self._write_ini(
            """
            [DEFAULT]
            db_type = postgres
            host = localhost
            port = 5432
            user = postgres
            database = postgres
            check_mode = import
            check_schemas = myapp,myapp_vector
            """
        )

        with patch.dict("os.environ", {"PGPASSWORD": "pw"}, clear=False):
            result = handle_check_connection({"configSource": {"type": "ini", "path": ini_path, "section": "DEFAULT"}})

        self.assertTrue(result["connected"])
        self.assertEqual("import", result["mode"])

    def test_cleanup_rejects_non_postgres_ini_profile(self):
        ini_path = self._write_ini(
            """
            [MSSQL]
            db_type = sql server
            """
        )

        with self.assertRaises(ValueError):
            handle_cleanup_schema(
                {
                    "configSource": {"type": "ini", "path": ini_path, "section": "MSSQL"},
                    "connection": {"host": "localhost", "port": 5432, "user": "postgres", "password": "pw"},
                    "cleanupConfig": {"targetDb": "myapp_db", "schemas": ["myapp"], "dryRun": True},
                }
            )
