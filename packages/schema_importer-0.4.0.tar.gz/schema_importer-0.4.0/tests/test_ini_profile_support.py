import tempfile
import textwrap
import unittest
from argparse import Namespace
from pathlib import Path
from unittest.mock import Mock, patch

import check_connection as cc
import cleanup_schema as cw
import schema_import as iw
from schema_importer.ini_profile import (
    apply_profile_to_environment,
    load_ini_profile,
    normalize_db_engine,
    profile_db_engine,
    resolve_value,
)


class IniProfileSupportSuite(unittest.TestCase):
    def _write_ini(self, content: str) -> str:
        tmp = tempfile.NamedTemporaryFile("w", suffix=".ini", delete=False, encoding="utf-8")
        tmp.write(textwrap.dedent(content).strip() + "\n")
        tmp.close()
        return tmp.name

    def test_load_ini_profile_merges_defaults_and_selected_section(self):
        ini_path = self._write_ini(
            """
            [DEFAULT]
            log_level = INFO

            [STAGE_POSTGRES]
            host = stage-db
            db_type = postgres
            """
        )

        profile = load_ini_profile(ini_path, "STAGE_POSTGRES")

        self.assertEqual("INFO", profile["log_level"])
        self.assertEqual("stage-db", profile["host"])
        self.assertEqual("postgres", profile["db_type"])

    def test_load_ini_profile_raises_for_missing_section(self):
        ini_path = self._write_ini(
            """
            [DEFAULT]
            log_level = INFO
            """
        )

        with self.assertRaises(ValueError):
            load_ini_profile(ini_path, "NOPE")

    def test_normalize_db_engine_aliases(self):
        self.assertEqual("postgres", normalize_db_engine("PostgreSQL"))
        self.assertEqual("sqlserver", normalize_db_engine("sql server"))
        self.assertEqual("mongodb", normalize_db_engine("mongo"))
        self.assertEqual("sqlite", normalize_db_engine("sqlite3"))

    def test_apply_profile_to_environment_maps_keys(self):
        env: dict[str, str] = {}
        apply_profile_to_environment(
            {
                "host": "localhost",
                "port": "5432",
                "user": "postgres",
                "password": "pw",
                "database": "myapp_db",
                "schema_import_root": "./inputs",
                "sql_order": "a.sql,b.sql",
                "db_type": "postgres",
            },
            environ=env,
        )

        self.assertEqual("localhost", env["PGHOST"])
        self.assertEqual("5432", env["PGPORT"])
        self.assertEqual("postgres", env["PGUSER"])
        self.assertEqual("pw", env["PGPASSWORD"])
        self.assertEqual("myapp_db", env["PGDATABASE"])
        self.assertEqual("./inputs", env["SCHEMA_IMPORT_ROOT"])
        self.assertEqual("a.sql,b.sql", env["SQL_ORDER"])
        self.assertEqual("postgres", env["TARGET_DB"])

    def test_profile_db_engine_and_resolve_value(self):
        profile = {"db_type": "sql server", "cleanup_target_db": "myapp_db"}
        self.assertEqual("sqlserver", profile_db_engine(profile))
        self.assertEqual("cli", resolve_value("cli", profile, ("cleanup_target_db",), "fallback"))
        self.assertEqual("myapp_db", resolve_value(None, profile, ("cleanup_target_db",), "fallback"))
        self.assertEqual("fallback", resolve_value(None, profile, ("none",), "fallback"))

    @patch("schema_importer.main.ImportWizard")
    @patch("schema_importer.main.AdapterFactory.create")
    @patch("schema_importer.main.setup_logging")
    @patch("schema_importer.main.build_runtime_config")
    @patch("schema_importer.main.parse_args")
    @patch("schema_importer.main.load_dotenv")
    def test_import_main_uses_ini_target_db_when_cli_missing(
        self,
        _load_dotenv_mock: Mock,
        parse_args_mock: Mock,
        build_runtime_config_mock: Mock,
        setup_logging_mock: Mock,
        factory_mock: Mock,
        wizard_cls_mock: Mock,
    ):
        ini_path = self._write_ini(
            """
            [STAGE_POSTGRES]
            db_type = PostgreSQL
            """
        )
        parse_args_mock.return_value = Namespace(
            dry_run=True,
            target_db=None,
            config_file=ini_path,
            config_section="STAGE_POSTGRES",
        )
        runtime_cfg = iw.RuntimeConfig(root=Path.cwd(), sql_order=["a.sql"], log_level="INFO", target_db="postgres", dry_run=True)
        build_runtime_config_mock.return_value = runtime_cfg
        setup_logging_mock.return_value = Mock()
        factory_mock.return_value = Mock()
        wizard_cls_mock.return_value.run.return_value = 0

        rc = iw.main(["--config-file", ini_path, "--config-section", "STAGE_POSTGRES"])

        self.assertEqual(0, rc)
        self.assertEqual("postgres", parse_args_mock.return_value.target_db)

    @patch("schema_cleanup.main.parse_args")
    @patch("schema_cleanup.main.load_dotenv")
    def test_cleanup_main_rejects_non_postgres_profile(self, _load_dotenv_mock: Mock, parse_args_mock: Mock):
        ini_path = self._write_ini(
            """
            [MSSQL]
            db_type = sql server
            """
        )
        parse_args_mock.return_value = type(
            "Args",
            (),
            {
                "target_db": None,
                "schemas": None,
                "dry_run": True,
                "config_file": ini_path,
                "config_section": "MSSQL",
            },
        )

        with self.assertRaises(ValueError):
            cw.main(["--config-file", ini_path, "--config-section", "MSSQL"])

    @patch("schema_importer.check_connection_main.parse_args")
    @patch("schema_importer.check_connection_main.load_dotenv")
    def test_check_connection_main_rejects_non_postgres_profile(
        self,
        _load_dotenv_mock: Mock,
        parse_args_mock: Mock,
    ):
        ini_path = self._write_ini(
            """
            [MONGO]
            db_type = mongodb
            """
        )
        parse_args_mock.return_value = type(
            "Args",
            (),
            {
                "target_db": None,
                "schemas": None,
                "mode": None,
                "config_file": ini_path,
                "config_section": "MONGO",
            },
        )

        with self.assertRaises(ValueError):
            cc.main(["--config-file", ini_path, "--config-section", "MONGO"])
