import logging
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

import check_connection as cc
import schema_import as iw


def run_result(stdout: str, stderr: str, returncode: int):
    return SimpleNamespace(stdout=stdout, stderr=stderr, returncode=returncode)


class CheckConnectionSuite(unittest.TestCase):
    def setUp(self):
        config = iw.PostgresConfig(host="localhost", port="5432", database="myapp_db", user="postgres", password="")
        self.adapter = iw.PostgresAdapter(config)
        self.logger = logging.getLogger("check-connection-test")
        self.logger.handlers.clear()
        self.logger.addHandler(logging.NullHandler())

    def _checker(self, mode: str = "import"):
        return cc.ConnectionChecker(
            adapter=self.adapter,
            logger=self.logger,
            target_db="myapp_db",
            schemas=["myapp", "myapp_vector"],
            mode=mode,
        )

    def test_parse_args_defaults(self):
        args = cc.parse_args([])

        self.assertIsNone(args.mode)
        self.assertIsNone(args.target_db)
        self.assertIsNone(args.schemas)

    def test_parse_args_custom(self):
        args = cc.parse_args(
            ["--mode", "cleanup", "--target-db", "custom_db", "--schemas", "a,b", "--config-file", "import_schema.ini"]
        )
        self.assertEqual("cleanup", args.mode)
        self.assertEqual("custom_db", args.target_db)
        self.assertEqual("a,b", args.schemas)
        self.assertEqual("import_schema.ini", args.config_file)

    @patch.object(cc.ConnectionChecker, "_check_import_authorization", return_value=True)
    @patch.object(cc.ConnectionChecker, "_check_connectivity", return_value=True)
    @patch.object(iw.PostgresAdapter, "_resolve_psql_executable", return_value="psql")
    def test_run_import_success(self, _resolve_mock: Mock, _conn_mock: Mock, _auth_mock: Mock):
        checker = self._checker(mode="import")
        self.assertEqual(0, checker.run())

    @patch.object(cc.ConnectionChecker, "_check_import_authorization", return_value=False)
    @patch.object(cc.ConnectionChecker, "_check_connectivity", return_value=True)
    @patch.object(iw.PostgresAdapter, "_resolve_psql_executable", return_value="psql")
    def test_run_import_returns_two_when_not_authorized(self, _resolve_mock: Mock, _conn_mock: Mock, _auth_mock: Mock):
        checker = self._checker(mode="import")
        self.assertEqual(2, checker.run())

    @patch.object(cc.ConnectionChecker, "_check_cleanup_authorization", return_value=True)
    @patch.object(cc.ConnectionChecker, "_check_connectivity", return_value=True)
    @patch.object(iw.PostgresAdapter, "_resolve_psql_executable", return_value="psql")
    def test_run_cleanup_uses_cleanup_authorization(self, _resolve_mock: Mock, _conn_mock: Mock, auth_mock: Mock):
        checker = self._checker(mode="cleanup")
        self.assertEqual(0, checker.run())
        auth_mock.assert_called_once()

    @patch.object(cc.ConnectionChecker, "_check_connectivity", return_value=False)
    @patch.object(iw.PostgresAdapter, "_resolve_psql_executable", return_value="psql")
    def test_run_returns_one_when_connectivity_fails(self, _resolve_mock: Mock, _conn_mock: Mock):
        checker = self._checker(mode="import")
        self.assertEqual(1, checker.run())

    @patch.object(cc.ConnectionChecker, "_run_psql_text", return_value=(True, "t"))
    def test_query_bool_parses_true(self, _run_mock: Mock):
        checker = self._checker()
        self.assertTrue(checker._query_bool("psql", "myapp_db", "SELECT 1", {}, "demo"))

    @patch.object(cc.ConnectionChecker, "_run_psql_text", return_value=(True, "f"))
    def test_query_bool_parses_false(self, _run_mock: Mock):
        checker = self._checker()
        self.assertFalse(checker._query_bool("psql", "myapp_db", "SELECT 1", {}, "demo"))

    @patch.object(cc.ConnectionChecker, "_run_psql_text", return_value=(False, "error"))
    def test_query_bool_raises_when_query_fails(self, _run_mock: Mock):
        checker = self._checker()
        with self.assertRaises(RuntimeError):
            checker._query_bool("psql", "myapp_db", "SELECT 1", {}, "demo")

    @patch("schema_importer.check_connection_service.subprocess.run")
    def test_run_psql_text_success(self, run_mock: Mock):
        run_mock.return_value = run_result(stdout="ok\n", stderr="", returncode=0)
        checker = self._checker()
        success, output = checker._run_psql_text("psql", "myapp_db", "SELECT 1", {})
        self.assertTrue(success)
        self.assertEqual("ok", output)

    @patch("schema_importer.check_connection_service.subprocess.run")
    def test_run_psql_text_failure(self, run_mock: Mock):
        run_mock.return_value = run_result(stdout="", stderr="boom", returncode=1)
        checker = self._checker()
        success, output = checker._run_psql_text("psql", "myapp_db", "SELECT 1", {})
        self.assertFalse(success)
        self.assertIn("boom", output)

    @patch("schema_importer.check_connection_main.ConnectionChecker")
    @patch("schema_importer.check_connection_main.setup_logging")
    @patch("schema_importer.check_connection_main.parse_args")
    @patch("schema_importer.check_connection_main.load_dotenv")
    def test_main_happy_path(
        self,
        _load_dotenv_mock: Mock,
        parse_args_mock: Mock,
        setup_logging_mock: Mock,
        checker_cls_mock: Mock,
    ):
        parse_args_mock.return_value = type(
            "Args", (), {"target_db": "myapp_db", "schemas": "myapp", "mode": "import", "config_file": None, "config_section": "DEFAULT"}
        )
        setup_logging_mock.return_value = logging.getLogger("check-connection-main-test")
        checker_instance = checker_cls_mock.return_value
        checker_instance.run.return_value = 0

        with tempfile.TemporaryDirectory() as tmp, patch.dict(
            "os.environ",
            {
                "PGHOST": "localhost",
                "PGPORT": "5432",
                "PGUSER": "postgres",
                "LOG_LEVEL": "INFO",
            },
            clear=False,
        ), patch("schema_importer.check_connection_main.Path.cwd", return_value=Path(tmp)):
            rc = cc.main(["--mode", "import"])

        self.assertEqual(0, rc)
        checker_instance.run.assert_called_once()
