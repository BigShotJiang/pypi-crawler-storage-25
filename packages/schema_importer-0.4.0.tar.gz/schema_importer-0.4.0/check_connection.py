#!/usr/bin/env python3
"""Compatibility entrypoint for Schema connection checks."""

from __future__ import annotations

from schema_importer.check_connection_cli_args import parse_args
from schema_importer.check_connection_main import main
from schema_importer.check_connection_service import ConnectionChecker

__all__ = ["ConnectionChecker", "main", "parse_args"]


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
