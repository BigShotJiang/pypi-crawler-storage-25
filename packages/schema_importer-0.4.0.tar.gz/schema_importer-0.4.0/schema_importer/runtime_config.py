from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class RuntimeConfig:
    root: Path
    sql_order: list[str]
    log_level: str
    target_db: str
    dry_run: bool
