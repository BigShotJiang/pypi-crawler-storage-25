from __future__ import annotations

import argparse
import os
from pathlib import Path

from schema_importer.env_utils import env_required, normalize_sql_order
from schema_importer.runtime_config import RuntimeConfig


def build_runtime_config(args: argparse.Namespace) -> RuntimeConfig:
    root = Path(env_required("SCHEMA_IMPORT_ROOT")).resolve()
    if not root.exists() or not root.is_dir():
        raise FileNotFoundError(f"SCHEMA_IMPORT_ROOT is not a directory: {root}")

    sql_order = normalize_sql_order(env_required("SQL_ORDER"))
    if not sql_order:
        raise ValueError("SQL_ORDER cannot be empty")

    return RuntimeConfig(
        root=root,
        sql_order=sql_order,
        log_level=os.getenv("LOG_LEVEL", "INFO"),
        target_db=args.target_db or os.getenv("TARGET_DB", "postgres"),
        dry_run=args.dry_run,
    )
