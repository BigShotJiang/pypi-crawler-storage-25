from __future__ import annotations

import logging
from pathlib import Path

from schema_importer.database_adapter import DatabaseAdapter


class MongoDbAdapter(DatabaseAdapter):
    @property
    def name(self) -> str:
        return "mongodb"

    def execute(self, wrapper_sql: Path, logger: logging.Logger, dry_run: bool) -> int:
        _ = (wrapper_sql, logger, dry_run)
        raise NotImplementedError("MongoDB adapter is not implemented yet")
