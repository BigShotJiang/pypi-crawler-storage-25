from __future__ import annotations

import argparse


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Check PostgreSQL connectivity and required authorization for import/cleanup flows"
    )
    parser.add_argument(
        "--config-file",
        help="Optional INI profile file path used to resolve connection and check settings",
    )
    parser.add_argument(
        "--config-section",
        default="DEFAULT",
        help="INI section/profile name to load (default: DEFAULT)",
    )
    parser.add_argument(
        "--mode",
        choices=["import", "cleanup"],
        default=None,
        help="Authorization profile to validate (default: import)",
    )
    parser.add_argument(
        "--target-db",
        default=None,
        help="Target PostgreSQL database for checks (default: PGDATABASE or myapp_db)",
    )
    parser.add_argument(
        "--schemas",
        default=None,
        help="Comma-separated schema names used for cleanup authorization checks",
    )
    return parser.parse_args(argv)
