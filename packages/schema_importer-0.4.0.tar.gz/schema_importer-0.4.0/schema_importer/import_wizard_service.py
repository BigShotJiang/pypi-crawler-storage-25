from __future__ import annotations

import logging
import shutil
from pathlib import Path
from typing import Iterable

from schema_importer.database_adapter import DatabaseAdapter
from schema_importer.runtime_config import RuntimeConfig
from schema_importer.sql_transformer import SqlTransformer
from schema_importer.time_utils import timestamp


class ImportWizard:
    """Coordinates staging, transformation, and execution."""

    def __init__(self, config: RuntimeConfig, adapter: DatabaseAdapter, logger: logging.Logger):
        self.config = config
        self.adapter = adapter
        self.logger = logger
        self.transformer = SqlTransformer()
        self.staging_dir = Path.cwd() / ".schema_staging" / timestamp()

    def run(self) -> int:
        self.logger.info("=== Import started (%s) ===", self.adapter.name)
        self.staging_dir.mkdir(parents=True, exist_ok=True)
        self.logger.info("Staging dir: %s", self.staging_dir)

        staged_files: list[Path] = []
        referenced_csv_names: set[str] = set()

        for sql_name in self.config.sql_order:
            src = (self.config.root / sql_name).resolve()
            if not src.exists():
                raise FileNotFoundError(f"SQL file not found: {src}")

            dst = self.staging_dir / sql_name
            dst.parent.mkdir(parents=True, exist_ok=True)

            sql_text = src.read_text(encoding="utf-8")
            sql_text, include_changes = self.transformer.rewrite_includes(sql_text, src.parent, self.staging_dir)
            for change in include_changes:
                self.logger.debug("Include rewrite: %s", change)

            sql_text, csv_changes, found_csv = self.transformer.patch_csv_paths(sql_text, self.staging_dir)
            referenced_csv_names.update(found_csv)
            for change in csv_changes:
                self.logger.debug("CSV patch: %s", change)

            self.transformer.warn_if_server_copy(sql_text, self.logger)

            dst.write_text(sql_text, encoding="utf-8")
            staged_files.append(dst)

        self._copy_referenced_csv(referenced_csv_names)
        wrapper_sql = self._build_wrapper_sql(staged_files)

        return_code = self.adapter.execute(wrapper_sql, self.logger, self.config.dry_run)
        if return_code == 0:
            self.logger.info("Import completed successfully")
        else:
            self.logger.error("Import failed with code=%s", return_code)
        return return_code

    def _copy_referenced_csv(self, csv_names: Iterable[str]) -> None:
        for csv_name in sorted(csv_names):
            matches = list(self.config.root.rglob(csv_name))
            if not matches:
                raise FileNotFoundError(f"CSV file not found under import root: {csv_name}")
            if len(matches) > 1:
                options = ", ".join(str(path) for path in matches)
                raise ValueError(f"Ambiguous CSV reference '{csv_name}'. Matches: {options}")

            src = matches[0]
            dst = self.staging_dir / csv_name
            shutil.copy2(src, dst)
            self.logger.info("Copied CSV: %s", csv_name)

    def _build_wrapper_sql(self, staged_files: list[Path]) -> Path:
        wrapper_sql = self.staging_dir / "master.sql"
        lines = ["\\set ON_ERROR_STOP on", f"\\cd '{self.staging_dir.as_posix()}'"]
        for sql_file in staged_files:
            relative_name = sql_file.relative_to(self.staging_dir).as_posix()
            lines.append(f"\\i '{relative_name}'")

        wrapper_sql.write_text("\n".join(lines), encoding="utf-8")
        self.logger.info("Wrapper SQL created: %s", wrapper_sql)
        return wrapper_sql
