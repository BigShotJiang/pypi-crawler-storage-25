from __future__ import annotations

import time


def timestamp() -> str:
    return time.strftime("%Y%m%d_%H%M%S")
