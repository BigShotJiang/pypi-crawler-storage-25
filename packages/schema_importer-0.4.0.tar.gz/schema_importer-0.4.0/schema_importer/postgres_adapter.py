from __future__ import annotations

import logging
import os
import shutil
import subprocess
from pathlib import Path

from schema_importer.database_adapter import DatabaseAdapter
from schema_importer.postgres_config import PostgresConfig


class PostgresAdapter(DatabaseAdapter):
    def __init__(self, config: PostgresConfig):
        self.config = config

    @property
    def name(self) -> str:
        return "postgres"

    def _command(self, wrapper_sql: Path) -> list[str]:
        return [
            "psql",
            "-h",
            self.config.host,
            "-p",
            self.config.port,
            "-U",
            self.config.user,
            "-d",
            self.config.database,
            "-v",
            "ON_ERROR_STOP=1",
            "-f",
            str(wrapper_sql),
        ]

    def _resolve_psql_executable(self) -> str:
        configured = os.getenv("PSQL_BIN", "psql").strip() or "psql"

        if any(sep in configured for sep in ("/", "\\")):
            candidate = Path(configured)
            if candidate.exists():
                return str(candidate)
            raise FileNotFoundError(
                f"PSQL_BIN is set but not found: {configured}. "
                "Install PostgreSQL client tools or set PSQL_BIN to psql executable path."
            )

        resolved = shutil.which(configured)
        if resolved:
            return resolved

        raise FileNotFoundError(
            "PostgreSQL client executable was not found. "
            "Install psql and add it to PATH, or set PSQL_BIN to the psql executable path."
        )

    def execute(self, wrapper_sql: Path, logger: logging.Logger, dry_run: bool) -> int:
        command = self._command(wrapper_sql)
        if dry_run:
            logger.info("DRY RUN enabled, skipping command execution")
            return 0

        command[0] = self._resolve_psql_executable()
        logger.info("Executing PostgreSQL import")
        logger.debug("Command: %s", " ".join(command))

        env = os.environ.copy()
        if self.config.password:
            env["PGPASSWORD"] = self.config.password

        return_code, output_lines = self._run_psql_command(command, env, logger)

        if self._should_retry_with_postgres(return_code, output_lines):
            retry_command = command.copy()
            db_arg_index = retry_command.index("-d") + 1
            retry_command[db_arg_index] = "postgres"
            logger.warning(
                "Configured database '%s' was not found. Retrying once against 'postgres' for bootstrap.",
                self.config.database,
            )
            return_code, _ = self._run_psql_command(retry_command, env, logger)

        if self._allow_missing_pgvector() and self._should_retry_without_pgvector(return_code, output_lines):
            wrapper_without_pgvector = self._build_wrapper_without_pgvector(wrapper_sql)
            if wrapper_without_pgvector is not None:
                retry_command = command.copy()
                file_arg_index = retry_command.index("-f") + 1
                retry_command[file_arg_index] = str(wrapper_without_pgvector)
                logger.warning(
                    "pgvector extension is unavailable on this PostgreSQL server. "
                    "Retrying import without pg_vector.sql because ALLOW_MISSING_PGVECTOR is enabled."
                )
                return_code, _ = self._run_psql_command(retry_command, env, logger)

        return return_code

    def _run_psql_command(self, command: list[str], env: dict[str, str], logger: logging.Logger) -> tuple[int, list[str]]:
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            env=env,
        )

        output_lines: list[str] = []
        if process.stdout is not None:
            for line in process.stdout:
                clean_line = line.rstrip()
                output_lines.append(clean_line)
                print(clean_line)
                logger.info(clean_line)

        process.wait()
        return process.returncode, output_lines

    def _should_retry_with_postgres(self, return_code: int, output_lines: list[str]) -> bool:
        if return_code == 0:
            return False
        if self.config.database.lower() == "postgres":
            return False

        missing_db_message = f'database "{self.config.database}" does not exist'.lower()
        return any(missing_db_message in line.lower() for line in output_lines)

    def _allow_missing_pgvector(self) -> bool:
        value = os.getenv("ALLOW_MISSING_PGVECTOR", "false").strip().lower()
        return value in {"1", "true", "yes", "on"}

    def _should_retry_without_pgvector(self, return_code: int, output_lines: list[str]) -> bool:
        if return_code == 0:
            return False

        return any('extension "vector" is not available' in line.lower() for line in output_lines)

    def _build_wrapper_without_pgvector(self, wrapper_sql: Path) -> Path | None:
        lines = wrapper_sql.read_text(encoding="utf-8").splitlines()
        filtered = [line for line in lines if "pg_vector.sql" not in line.lower()]

        if len(filtered) == len(lines):
            return None

        retry_wrapper = wrapper_sql.with_name("master_no_pgvector.sql")
        retry_wrapper.write_text("\n".join(filtered), encoding="utf-8")
        return retry_wrapper
