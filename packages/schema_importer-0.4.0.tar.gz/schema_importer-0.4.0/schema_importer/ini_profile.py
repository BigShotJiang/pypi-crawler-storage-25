from __future__ import annotations

import configparser
import os
import re
from pathlib import Path


DB_ENGINE_ALIASES = {
    "postgres": "postgres",
    "postgresql": "postgres",
    "pg": "postgres",
    "psql": "postgres",
    "mysql": "mysql",
    "mongodb": "mongodb",
    "mongo": "mongodb",
    "sqlserver": "sqlserver",
    "mssql": "sqlserver",
    "oracle": "oracle",
    "db2": "db2",
    "sqlite": "sqlite",
    "sqlite3": "sqlite",
}


def load_ini_profile(config_file: str, section: str | None) -> dict[str, str]:
    config_path = Path(config_file).expanduser().resolve()
    if not config_path.exists() or not config_path.is_file():
        raise FileNotFoundError(f"INI config file not found: {config_path}")

    parser = configparser.ConfigParser()
    parser.read(config_path, encoding="utf-8")

    selected = (section or "DEFAULT").strip() or "DEFAULT"
    if selected != "DEFAULT" and selected not in parser:
        raise ValueError(f"INI section not found: {selected}")

    profile: dict[str, str] = {}
    for key, value in parser.defaults().items():
        text = value.strip()
        if text:
            profile[key.lower().strip()] = text

    if selected != "DEFAULT":
        for key, value in parser[selected].items():
            text = value.strip()
            if text:
                profile[key.lower().strip()] = text

    return profile


def normalize_db_engine(raw_value: str | None) -> str | None:
    if not raw_value:
        return None

    normalized_key = re.sub(r"[^a-z0-9]+", "", raw_value.strip().lower())
    if not normalized_key:
        return None
    return DB_ENGINE_ALIASES.get(normalized_key, raw_value.strip().lower())


def profile_db_engine(profile: dict[str, str]) -> str | None:
    for key in ("target_db_adapter", "db_type", "database_type", "engine"):
        value = profile.get(key)
        if value:
            return normalize_db_engine(value)
    return None


def resolve_value(cli_value: str | None, profile: dict[str, str], profile_keys: tuple[str, ...], default: str) -> str:
    if cli_value:
        return cli_value

    for key in profile_keys:
        value = profile.get(key)
        if value:
            return value

    return default


def apply_profile_to_environment(profile: dict[str, str], environ: dict[str, str] | None = None) -> None:
    target_env = os.environ if environ is None else environ

    mapping: dict[str, tuple[str, ...]] = {
        "PGHOST": ("host", "hostname", "server", "postgres_host", "pg_host"),
        "PGPORT": ("port", "postgres_port", "pg_port"),
        "PGUSER": ("user", "username", "uid", "postgres_user", "pg_user"),
        "PGPASSWORD": ("password", "passwd", "pwd", "postgres_password", "pg_password"),
        "PGDATABASE": ("database", "db", "db_name", "dbname"),
        "SCHEMA_IMPORT_ROOT": ("schema_import_root", "import_root", "input_root", "schema_root"),
        "SQL_ORDER": ("sql_order", "sql_files", "sql_file_order"),
        "LOG_LEVEL": ("log_level",),
        "PSQL_BIN": ("psql_bin",),
    }

    for env_key, profile_keys in mapping.items():
        for key in profile_keys:
            value = profile.get(key)
            if value:
                target_env[env_key] = value
                break

    db_engine = profile_db_engine(profile)
    if db_engine:
        target_env["TARGET_DB"] = db_engine
