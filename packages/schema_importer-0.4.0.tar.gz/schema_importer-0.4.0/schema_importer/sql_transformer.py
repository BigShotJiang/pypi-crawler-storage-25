from __future__ import annotations

import logging
import re
from pathlib import Path


INCLUDE_REGEX = re.compile(r"^\s*\\(i|ir)\s+(.*)$", re.IGNORECASE)
CSV_REGEX = re.compile(r"(?i)\b(\\copy|copy)\b.*?\bfrom\s+['\"](.*?\.csv)['\"]")


class SqlTransformer:
    """Applies SQL file transformations before execution."""

    def rewrite_includes(self, sql_text: str, base_dir: Path, staging_dir: Path) -> tuple[str, list[str]]:
        _ = staging_dir
        new_lines: list[str] = []
        changes: list[str] = []

        for line in sql_text.splitlines():
            match = INCLUDE_REGEX.match(line)
            if not match:
                new_lines.append(line)
                continue

            command, include_path = match.groups()
            include_path = include_path.strip().strip("'\"")
            resolved = (base_dir / include_path).resolve()
            new_line = f"\\{command} '{resolved.as_posix()}'"
            changes.append(f"{line.strip()} -> {new_line}")
            new_lines.append(new_line)

        return "\n".join(new_lines), changes

    def patch_csv_paths(self, sql_text: str, staging_dir: Path) -> tuple[str, list[str], set[str]]:
        changes: list[str] = []
        referenced_csv_names: set[str] = set()

        def replace(match: re.Match[str]) -> str:
            original = match.group(2)
            csv_name = Path(original).name
            referenced_csv_names.add(csv_name)
            new_path = (staging_dir / csv_name).resolve().as_posix()
            changes.append(f"{original} -> {new_path}")
            return match.group(0).replace(original, new_path)

        new_sql = CSV_REGEX.sub(replace, sql_text)
        return new_sql, changes, referenced_csv_names

    def warn_if_server_copy(self, sql_text: str, logger: logging.Logger) -> None:
        if "COPY " in sql_text and "\\copy" not in sql_text:
            logger.warning("Detected COPY (server-side). Prefer \\copy for portability")
