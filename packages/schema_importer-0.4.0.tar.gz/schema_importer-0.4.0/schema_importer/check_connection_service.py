from __future__ import annotations

import logging
import os
import subprocess

from schema_cleanup.identifier_utils import sql_literal
from schema_importer.postgres_adapter import PostgresAdapter


class ConnectionChecker:
    """Validates PostgreSQL connectivity and operation-specific privileges."""

    def __init__(
        self,
        adapter: PostgresAdapter,
        logger: logging.Logger,
        target_db: str,
        schemas: list[str],
        mode: str,
    ):
        self.adapter = adapter
        self.logger = logger
        self.target_db = target_db
        self.schemas = schemas
        self.mode = mode

    def run(self) -> int:
        self.logger.info("=== Connection check started (mode=%s, target db=%s) ===", self.mode, self.target_db)
        if self.schemas:
            self.logger.info("Schemas for authorization checks: %s", ", ".join(self.schemas))

        try:
            psql_bin = self.adapter._resolve_psql_executable()
            env = os.environ.copy()
            if self.adapter.config.password:
                env["PGPASSWORD"] = self.adapter.config.password

            if not self._check_connectivity(psql_bin, env):
                self.logger.error("Connectivity check failed")
                return 1

            if self.mode == "import":
                authorized = self._check_import_authorization(psql_bin, env)
            else:
                authorized = self._check_cleanup_authorization(psql_bin, env)
        except Exception as exc:
            self.logger.error("Connection check failed: %s", exc)
            return 1

        if authorized:
            self.logger.info("Connection and authorization checks passed")
            return 0

        self.logger.error("Connection succeeded but required authorization checks failed")
        return 2

    def _check_connectivity(self, psql_bin: str, env: dict[str, str]) -> bool:
        sql = "SELECT current_user || '@' || current_database();"
        success, output = self._run_psql_text(psql_bin, self.target_db, sql, env)
        if not success:
            self.logger.error("Unable to connect to target database '%s': %s", self.target_db, output)
            return False

        self.logger.info("Connected successfully as %s", output)
        return True

    def _check_import_authorization(self, psql_bin: str, env: dict[str, str]) -> bool:
        db_literal = sql_literal(self.target_db)

        connect_ok = self._query_bool(
            psql_bin,
            self.target_db,
            f"SELECT has_database_privilege(current_user, {db_literal}, 'CONNECT');",
            env,
            "import.connect",
        )
        create_ok = self._query_bool(
            psql_bin,
            self.target_db,
            f"SELECT has_database_privilege(current_user, {db_literal}, 'CREATE');",
            env,
            "import.create",
        )
        return connect_ok and create_ok

    def _check_cleanup_authorization(self, psql_bin: str, env: dict[str, str]) -> bool:
        target_db_literal = sql_literal(self.target_db)

        connect_ok = self._query_bool(
            psql_bin,
            "postgres",
            "SELECT has_database_privilege(current_user, 'postgres', 'CONNECT');",
            env,
            "cleanup.connect_postgres",
        )

        drop_db_ok = self._query_bool(
            psql_bin,
            "postgres",
            " ".join(
                [
                    "SELECT CASE",
                    f"WHEN EXISTS (SELECT 1 FROM pg_database WHERE datname = {target_db_literal}) THEN",
                    f"((SELECT pg_get_userbyid(datdba) = current_user FROM pg_database WHERE datname = {target_db_literal})",
                    "OR (SELECT rolsuper FROM pg_roles WHERE rolname = current_user))",
                    "ELSE true END;",
                ]
            ),
            env,
            "cleanup.drop_database",
        )

        drop_schema_ok = True
        for schema in self.schemas:
            schema_literal = sql_literal(schema)
            schema_ok = self._query_bool(
                psql_bin,
                self.target_db,
                " ".join(
                    [
                        "SELECT CASE",
                        f"WHEN EXISTS (SELECT 1 FROM pg_namespace WHERE nspname = {schema_literal}) THEN",
                        f"((SELECT pg_get_userbyid(nspowner) = current_user FROM pg_namespace WHERE nspname = {schema_literal})",
                        "OR (SELECT rolsuper FROM pg_roles WHERE rolname = current_user))",
                        "ELSE true END;",
                    ]
                ),
                env,
                f"cleanup.drop_schema.{schema}",
            )
            drop_schema_ok = drop_schema_ok and schema_ok

        return connect_ok and drop_db_ok and drop_schema_ok

    def _query_bool(
        self,
        psql_bin: str,
        database: str,
        sql: str,
        env: dict[str, str],
        check_name: str,
    ) -> bool:
        success, output = self._run_psql_text(psql_bin, database, sql, env)
        if not success:
            raise RuntimeError(f"{check_name} query failed: {output}")

        normalized = output.strip().lower()
        if normalized in {"t", "true", "1", "yes", "on"}:
            self.logger.info("Authorization check passed: %s", check_name)
            return True
        if normalized in {"f", "false", "0", "no", "off"}:
            self.logger.warning("Authorization check failed: %s", check_name)
            return False

        raise ValueError(f"{check_name} returned non-boolean value: {output!r}")

    def _run_psql_text(self, psql_bin: str, database: str, sql: str, env: dict[str, str]) -> tuple[bool, str]:
        command = [
            psql_bin,
            "-h",
            self.adapter.config.host,
            "-p",
            self.adapter.config.port,
            "-U",
            self.adapter.config.user,
            "-d",
            database,
            "-tA",
            "-c",
            sql,
        ]

        completed = subprocess.run(command, capture_output=True, text=True, env=env, check=False)
        if completed.returncode != 0:
            combined = ((completed.stdout or "") + (completed.stderr or "")).strip()
            return False, combined

        return True, (completed.stdout or "").strip()
