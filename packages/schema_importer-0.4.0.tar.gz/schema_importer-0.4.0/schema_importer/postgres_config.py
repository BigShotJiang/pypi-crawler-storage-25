from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class PostgresConfig:
    host: str
    port: str
    database: str
    user: str
    password: str
