from __future__ import annotations

import os


def env_required(key: str) -> str:
    value = os.getenv(key)
    if not value:
        raise ValueError(f"Missing env: {key}")
    return value


def normalize_sql_order(raw_value: str) -> list[str]:
    return [item.strip() for item in raw_value.split(",") if item.strip()]
