from __future__ import annotations

import os
import sys
from pathlib import Path

from dotenv import load_dotenv

from schema_importer.adapter_factory import AdapterFactory
from schema_importer.cli_args import parse_args
from schema_importer.import_wizard_service import ImportWizard
from schema_importer.ini_profile import apply_profile_to_environment, load_ini_profile, normalize_db_engine
from schema_importer.logging_setup import setup_logging
from schema_importer.runtime_config_builder import build_runtime_config
from schema_importer.time_utils import timestamp


def main(argv: list[str] | None = None) -> int:
    load_dotenv()
    args = parse_args(sys.argv[1:] if argv is None else argv)

    profile: dict[str, str] = {}
    if args.config_file:
        profile = load_ini_profile(args.config_file, args.config_section)
        apply_profile_to_environment(profile)

    if not args.target_db:
        profile_target = profile.get("target_db_adapter") or profile.get("db_type") or profile.get("database_type")
        args.target_db = normalize_db_engine(profile_target or "") or normalize_db_engine(os.getenv("TARGET_DB"))
        if not args.target_db:
            args.target_db = "postgres"
    else:
        args.target_db = normalize_db_engine(args.target_db) or args.target_db

    runtime_config = build_runtime_config(args)

    staging_for_log = Path.cwd() / ".schema_staging" / timestamp()
    staging_for_log.mkdir(parents=True, exist_ok=True)
    log_file = staging_for_log / "import.log"
    logger = setup_logging(log_file, runtime_config.log_level)

    adapter = AdapterFactory.create(runtime_config.target_db)
    wizard = ImportWizard(runtime_config, adapter, logger)
    wizard.staging_dir = staging_for_log
    return wizard.run()
