from __future__ import annotations

import logging
from pathlib import Path

from schema_importer.database_adapter import DatabaseAdapter


class MySqlAdapter(DatabaseAdapter):
    @property
    def name(self) -> str:
        return "mysql"

    def execute(self, wrapper_sql: Path, logger: logging.Logger, dry_run: bool) -> int:
        _ = (wrapper_sql, logger, dry_run)
        raise NotImplementedError("MySQL adapter is not implemented yet")
