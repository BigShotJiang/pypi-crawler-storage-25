from __future__ import annotations

import argparse


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Database import wizard")
    parser.add_argument("--dry-run", action="store_true", help="Prepare staged SQL but do not execute")
    parser.add_argument(
        "--config-file",
        help="Optional INI profile file path used to resolve connection and runtime settings",
    )
    parser.add_argument(
        "--config-section",
        default="DEFAULT",
        help="INI section/profile name to load (default: DEFAULT)",
    )
    parser.add_argument(
        "--target-db",
        default=None,
        help="Database adapter key. Supported: postgres (default), mysql, mongodb",
    )
    return parser.parse_args(argv)
