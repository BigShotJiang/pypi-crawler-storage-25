from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from pathlib import Path


class DatabaseAdapter(ABC):
    """Base adapter for database-specific execution behavior."""

    @property
    @abstractmethod
    def name(self) -> str:
        raise NotImplementedError

    @abstractmethod
    def execute(self, wrapper_sql: Path, logger: logging.Logger, dry_run: bool) -> int:
        raise NotImplementedError
