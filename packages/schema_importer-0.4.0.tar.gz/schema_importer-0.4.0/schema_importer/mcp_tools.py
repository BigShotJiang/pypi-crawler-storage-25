from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

from schema_cleanup.identifier_utils import ensure_target_db_is_safe, parse_schema_list, validate_identifier
from schema_cleanup.schema_cleanup_service import SchemaCleanup
from schema_importer.adapter_factory import AdapterFactory
from schema_importer.check_connection_service import ConnectionChecker
from schema_importer.import_wizard_service import ImportWizard
from schema_importer.ini_profile import load_ini_profile, normalize_db_engine, profile_db_engine
from schema_importer.postgres_adapter import PostgresAdapter
from schema_importer.postgres_config import PostgresConfig
from schema_importer.runtime_config import RuntimeConfig
from schema_importer.time_utils import timestamp


def _as_dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _split_csv(raw: str | None, default: list[str] | None = None) -> list[str]:
    if not raw:
        return [] if default is None else default
    return [item.strip() for item in raw.split(",") if item.strip()]


def _mask_secret(value: str | None) -> str:
    if not value:
        return ""
    if len(value) <= 4:
        return "****"
    return f"{value[:2]}***{value[-2:]}"


def _secret_ref_to_env_key(secret_ref: str) -> str:
    token = re.sub(r"[^A-Za-z0-9]", "_", secret_ref).upper()
    return f"SECRET_{token}"


def _resolve_password(connection: dict[str, Any], profile: dict[str, str]) -> str:
    secret_ref = connection.get("passwordSecretRef") or profile.get("password_secret_ref")
    if secret_ref:
        env_key = _secret_ref_to_env_key(str(secret_ref))
        resolved = os.getenv(env_key)
        if resolved:
            return resolved
        raise ValueError(
            f"Unable to resolve passwordSecretRef '{secret_ref}'. "
            f"Set server-side env var '{env_key}' or provide connection.password for local development."
        )

    direct_password = connection.get("password") or profile.get("password")
    if direct_password:
        return str(direct_password)

    return os.getenv("PGPASSWORD", "")


def _load_profile(request: dict[str, Any]) -> dict[str, str]:
    config_source = _as_dict(request.get("configSource"))
    if not config_source:
        return {}

    source_type = str(config_source.get("type", "")).strip().lower()
    if source_type and source_type != "ini":
        raise ValueError(f"Unsupported configSource.type '{source_type}'. Supported: ini")

    ini_path = config_source.get("path")
    if not ini_path:
        raise ValueError("configSource.path is required when configSource is provided")

    section = config_source.get("section", "DEFAULT")
    return load_ini_profile(str(ini_path), str(section))


def _resolve_host_port_user_db(
    connection: dict[str, Any],
    profile: dict[str, str],
    *,
    default_database: str | None = None,
) -> tuple[str, str, str, str]:
    host = str(connection.get("host") or profile.get("host") or os.getenv("PGHOST", "")).strip()
    port_raw = connection.get("port") or profile.get("port") or os.getenv("PGPORT", "")
    user = str(connection.get("user") or profile.get("user") or os.getenv("PGUSER", "")).strip()
    database = str(
        connection.get("database")
        or profile.get("database")
        or os.getenv("PGDATABASE", "")
        or (default_database or "")
    ).strip()

    if not host:
        raise ValueError("Missing required connection.host (or PGHOST)")
    if not user:
        raise ValueError("Missing required connection.user (or PGUSER)")
    if not database:
        raise ValueError("Missing required connection.database (or PGDATABASE)")

    if port_raw in (None, ""):
        raise ValueError("Missing required connection.port (or PGPORT)")

    try:
        port_int = int(str(port_raw).strip())
    except ValueError as exc:
        raise ValueError("connection.port must be an integer") from exc

    if port_int < 1 or port_int > 65535:
        raise ValueError("connection.port must be between 1 and 65535")

    return host, str(port_int), user, database


def _resolve_logger(name: str):
    import logging

    logger = logging.getLogger(name)
    if not logger.handlers:
        logger.addHandler(logging.NullHandler())
    return logger


def handle_import_schema(request: dict[str, Any]) -> dict[str, Any]:
    profile = _load_profile(request)
    connection = _as_dict(request.get("connection"))
    import_config = _as_dict(request.get("importConfig"))

    target_adapter = normalize_db_engine(
        str(
            import_config.get("targetDbAdapter")
            or profile.get("target_db_adapter")
            or profile.get("db_type")
            or os.getenv("TARGET_DB", "postgres")
        )
    )
    if target_adapter not in {"postgres", "mysql", "mongodb"}:
        raise ValueError("importConfig.targetDbAdapter must be one of: postgres, mysql, mongodb")

    dry_run = bool(import_config.get("dryRun", True))
    log_level = str(import_config.get("logLevel") or profile.get("log_level") or os.getenv("LOG_LEVEL", "INFO"))

    schema_root_value = str(
        import_config.get("schemaImportRoot")
        or profile.get("schema_import_root")
        or os.getenv("SCHEMA_IMPORT_ROOT", "")
    ).strip()
    if not schema_root_value:
        raise ValueError("Missing importConfig.schemaImportRoot (or SCHEMA_IMPORT_ROOT)")
    root = Path(schema_root_value).resolve()
    if not root.exists() or not root.is_dir():
        raise FileNotFoundError(f"SCHEMA_IMPORT_ROOT is not a directory: {root}")

    sql_order = import_config.get("sqlOrder")
    if isinstance(sql_order, list):
        resolved_sql_order = [str(item).strip() for item in sql_order if str(item).strip()]
    else:
        resolved_sql_order = _split_csv(profile.get("sql_order") or os.getenv("SQL_ORDER"))
    if not resolved_sql_order:
        raise ValueError("SQL_ORDER cannot be empty")

    runtime_config = RuntimeConfig(
        root=root,
        sql_order=resolved_sql_order,
        log_level=log_level,
        target_db=target_adapter,
        dry_run=dry_run,
    )

    if target_adapter == "postgres":
        host, port, user, database = _resolve_host_port_user_db(connection, profile)
        password = _resolve_password(connection, profile)
        adapter = PostgresAdapter(
            PostgresConfig(
                host=host,
                port=port,
                database=database,
                user=user,
                password=password,
            )
        )
    else:
        # For non-Postgres adapters, keep compatibility with existing adapter factory behavior.
        adapter = AdapterFactory.create(target_adapter)

    staging_dir = Path.cwd() / ".schema_staging" / timestamp()
    wizard = ImportWizard(runtime_config, adapter, _resolve_logger("schema-import-mcp"))
    wizard.staging_dir = staging_dir
    exit_code = wizard.run()

    return {
        "ok": exit_code == 0,
        "exitCode": exit_code,
        "dryRun": dry_run,
        "targetDbAdapter": target_adapter,
        "plannedSqlFiles": resolved_sql_order,
        "stagingDir": str(staging_dir),
        "connection": {
            "host": connection.get("host") or profile.get("host") or os.getenv("PGHOST", ""),
            "port": connection.get("port") or profile.get("port") or os.getenv("PGPORT", ""),
            "user": connection.get("user") or profile.get("user") or os.getenv("PGUSER", ""),
            "database": connection.get("database") or profile.get("database") or os.getenv("PGDATABASE", ""),
            "password": _mask_secret(_resolve_password(connection, profile)),
        },
        "message": "Preview generated. No database changes were made." if dry_run else "Import execution finished.",
    }


def handle_cleanup_schema(request: dict[str, Any]) -> dict[str, Any]:
    profile = _load_profile(request)
    connection = _as_dict(request.get("connection"))
    cleanup_config = _as_dict(request.get("cleanupConfig"))

    db_engine = profile_db_engine(profile)
    if db_engine and db_engine != "postgres":
        raise ValueError(f"cleanup_schema currently supports PostgreSQL only. Profile engine '{db_engine}' is not supported.")

    dry_run = bool(cleanup_config.get("dryRun", True))
    confirm = bool(cleanup_config.get("confirm", False))
    if not dry_run and not confirm:
        raise ValueError("cleanup_schema with dryRun=false requires cleanupConfig.confirm=true")

    raw_target_db = str(
        cleanup_config.get("targetDb")
        or profile.get("cleanup_target_db")
        or connection.get("database")
        or profile.get("database")
        or os.getenv("PGDATABASE", "myapp_db")
    )
    raw_schemas = cleanup_config.get("schemas")
    if isinstance(raw_schemas, list):
        schema_list = [str(item).strip() for item in raw_schemas if str(item).strip()]
    else:
        schema_list = _split_csv(profile.get("cleanup_schemas") or os.getenv("CLEANUP_SCHEMAS") or "myapp,myapp_vector")

    target_db = ensure_target_db_is_safe(validate_identifier(raw_target_db))
    schemas = parse_schema_list(",".join(schema_list))

    host, port, user, _database = _resolve_host_port_user_db(connection, profile, default_database=target_db)
    password = _resolve_password(connection, profile)

    adapter = PostgresAdapter(
        PostgresConfig(
            host=host,
            port=port,
            database=target_db,
            user=user,
            password=password,
        )
    )

    cleanup = SchemaCleanup(
        adapter=adapter,
        logger=_resolve_logger("schema-cleanup-mcp"),
        target_db=target_db,
        schemas=schemas,
        dry_run=dry_run,
        confirm_callback=(lambda: bool(confirm)),
    )
    exit_code = cleanup.run()

    return {
        "ok": exit_code == 0,
        "exitCode": exit_code,
        "dryRun": dry_run,
        "targetDb": target_db,
        "schemas": schemas,
        "connection": {
            "host": host,
            "port": port,
            "user": user,
            "password": _mask_secret(password),
        },
        "message": "Preview generated. No database changes were made." if dry_run else "Cleanup execution finished.",
    }


def handle_check_connection(request: dict[str, Any]) -> dict[str, Any]:
    profile = _load_profile(request)
    connection = _as_dict(request.get("connection"))
    checks = _as_dict(request.get("authorizationChecks"))

    db_engine = profile_db_engine(profile)
    if db_engine and db_engine != "postgres":
        raise ValueError(
            f"check_connection currently supports PostgreSQL only. Profile engine '{db_engine}' is not supported."
        )

    mode = str(checks.get("mode") or profile.get("check_mode") or "import").strip().lower()
    if mode not in {"import", "cleanup"}:
        raise ValueError("authorizationChecks.mode must be one of: import, cleanup")

    raw_target_db = str(
        connection.get("database")
        or profile.get("check_target_db")
        or profile.get("database")
        or os.getenv("PGDATABASE", "myapp_db")
    )
    raw_schemas = checks.get("schemas")
    if isinstance(raw_schemas, list):
        schema_list = [str(item).strip() for item in raw_schemas if str(item).strip()]
    else:
        schema_list = _split_csv(profile.get("check_schemas") or profile.get("cleanup_schemas") or "myapp,myapp_vector")

    target_db = validate_identifier(raw_target_db)
    schemas = parse_schema_list(",".join(schema_list))

    host, port, user, _database = _resolve_host_port_user_db(connection, profile, default_database=target_db)
    password = _resolve_password(connection, profile)

    adapter = PostgresAdapter(
        PostgresConfig(
            host=host,
            port=port,
            database=target_db,
            user=user,
            password=password,
        )
    )

    checker = ConnectionChecker(
        adapter=adapter,
        logger=_resolve_logger("schema-check-connection-mcp"),
        target_db=target_db,
        schemas=schemas,
        mode=mode,
    )
    exit_code = checker.run()
    connected = exit_code in {0, 2}
    authorized = exit_code == 0

    matrix: list[dict[str, Any]] = []
    if connected:
        matrix.append({"name": "connect", "ok": True, "detail": "Connection established"})
        if mode == "import":
            matrix.append(
                {
                    "name": "create_privilege",
                    "ok": authorized,
                    "detail": "CREATE allowed" if authorized else "CREATE privilege missing",
                }
            )
        else:
            matrix.append(
                {
                    "name": "drop_privilege",
                    "ok": authorized,
                    "detail": "DROP privileges allowed" if authorized else "DROP privilege missing",
                }
            )
    else:
        matrix.append({"name": "connect", "ok": False, "detail": "Connection failed"})

    return {
        "ok": exit_code == 0,
        "exitCode": exit_code,
        "connected": connected,
        "authorized": authorized,
        "mode": mode,
        "targetDb": target_db,
        "schemas": schemas,
        "checks": matrix,
        "connection": {
            "host": host,
            "port": port,
            "user": user,
            "password": _mask_secret(password),
        },
        "message": (
            "Connection and authorization checks passed."
            if authorized
            else "Connection check completed with failures."
        ),
    }
