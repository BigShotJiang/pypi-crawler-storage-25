from __future__ import annotations

import os

from schema_importer.database_adapter import DatabaseAdapter
from schema_importer.env_utils import env_required
from schema_importer.mongodb_adapter import MongoDbAdapter
from schema_importer.mysql_adapter import MySqlAdapter
from schema_importer.postgres_adapter import PostgresAdapter
from schema_importer.postgres_config import PostgresConfig


class AdapterFactory:
    @staticmethod
    def create(target_db: str) -> DatabaseAdapter:
        normalized = target_db.lower().strip()
        if normalized == "postgres":
            return PostgresAdapter(
                PostgresConfig(
                    host=env_required("PGHOST"),
                    port=env_required("PGPORT"),
                    database=env_required("PGDATABASE"),
                    user=env_required("PGUSER"),
                    password=os.getenv("PGPASSWORD", ""),
                )
            )
        if normalized == "mysql":
            return MySqlAdapter()
        if normalized == "mongodb":
            return MongoDbAdapter()
        raise ValueError(f"Unsupported TARGET_DB value: {target_db}")
