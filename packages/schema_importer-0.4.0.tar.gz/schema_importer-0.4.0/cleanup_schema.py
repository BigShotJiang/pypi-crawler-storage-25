#!/usr/bin/env python3
"""Compatibility entrypoint for Schema cleanup CLI."""

from __future__ import annotations

from schema_cleanup import (
    PROTECTED_DATABASES,
    SchemaCleanup,
    ensure_target_db_is_safe,
    parse_args,
    parse_schema_list,
    quote_ident,
    sql_literal,
    validate_identifier,
)
from schema_cleanup.main import main

__all__ = [
    "PROTECTED_DATABASES",
    "SchemaCleanup",
    "ensure_target_db_is_safe",
    "main",
    "parse_args",
    "parse_schema_list",
    "quote_ident",
    "sql_literal",
    "validate_identifier",
]


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
