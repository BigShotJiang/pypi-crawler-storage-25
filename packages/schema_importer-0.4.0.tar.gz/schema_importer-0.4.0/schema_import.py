#!/usr/bin/env python3
"""Schema import CLI entrypoint."""

from __future__ import annotations

from schema_importer import (
    AdapterFactory,
    DatabaseAdapter,
    ImportWizard,
    MongoDbAdapter,
    MySqlAdapter,
    PostgresAdapter,
    PostgresConfig,
    RuntimeConfig,
    SqlTransformer,
    build_runtime_config,
    env_required,
    normalize_sql_order,
    setup_logging,
    timestamp,
)
from schema_importer.cli_args import parse_args
from schema_importer.main import main

__all__ = [
    "AdapterFactory",
    "DatabaseAdapter",
    "ImportWizard",
    "MongoDbAdapter",
    "MySqlAdapter",
    "PostgresAdapter",
    "PostgresConfig",
    "RuntimeConfig",
    "SqlTransformer",
    "build_runtime_config",
    "env_required",
    "main",
    "normalize_sql_order",
    "parse_args",
    "setup_logging",
    "timestamp",
]


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
