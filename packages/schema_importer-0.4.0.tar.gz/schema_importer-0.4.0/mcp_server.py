#!/usr/bin/env python3
"""MCP server for schema importer tools."""

from __future__ import annotations

from typing import Any

from schema_importer.mcp_tools import handle_check_connection, handle_cleanup_schema, handle_import_schema


def _require_request(request: dict[str, Any] | None) -> dict[str, Any]:
    if request is None:
        return {}
    if not isinstance(request, dict):
        raise ValueError("Tool input must be a JSON object")
    return request


def _register_tools(app: Any) -> None:
    @app.tool(name="import_schema", description="Stage and execute (or preview) schema import operations")
    def import_schema(request: dict[str, Any] | None = None) -> dict[str, Any]:
        return handle_import_schema(_require_request(request))

    @app.tool(
        name="cleanup_schema",
        description="Drop selected schemas and then drop target PostgreSQL database (with dry-run support)",
    )
    def cleanup_schema(request: dict[str, Any] | None = None) -> dict[str, Any]:
        return handle_cleanup_schema(_require_request(request))

    @app.tool(
        name="check_connection",
        description="Check connectivity and required authorization for import or cleanup context",
    )
    def check_connection(request: dict[str, Any] | None = None) -> dict[str, Any]:
        return handle_check_connection(_require_request(request))


def main() -> int:
    try:
        from mcp.server.fastmcp import FastMCP
    except ImportError as exc:
        raise RuntimeError(
            "MCP runtime dependency is missing. Install package 'mcp' to run mcp_server.py"
        ) from exc

    app = FastMCP("schema-importer-mcp")
    _register_tools(app)
    app.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
