PROTECTED_DATABASES = {"postgres", "template0", "template1"}
