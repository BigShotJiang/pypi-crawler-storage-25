from __future__ import annotations

import re

from schema_cleanup.protected_databases import PROTECTED_DATABASES


def validate_identifier(name: str) -> str:
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name):
        raise ValueError(
            f"Invalid identifier '{name}'. Use PostgreSQL-safe names with letters, digits, and underscores only."
        )
    return name


def quote_ident(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def sql_literal(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def ensure_target_db_is_safe(target_db: str) -> str:
    if target_db.lower() in PROTECTED_DATABASES:
        raise ValueError(
            f"Refusing to cleanup protected PostgreSQL database '{target_db}'. "
            "Use a non-system database such as myapp_db."
        )
    return target_db


def parse_schema_list(raw_schemas: str) -> list[str]:
    parsed = [item.strip() for item in raw_schemas.split(",") if item.strip()]
    if not parsed:
        raise ValueError("--schemas cannot be empty")
    return [validate_identifier(item) for item in parsed]
