from __future__ import annotations

import logging
import os
import subprocess
from typing import Callable

from schema_cleanup.identifier_utils import quote_ident, sql_literal
from schema_importer.postgres_adapter import PostgresAdapter


class SchemaCleanup:
    """Drops selected schemas and then drops a target PostgreSQL database."""

    def __init__(
        self,
        adapter: PostgresAdapter,
        logger: logging.Logger,
        target_db: str,
        schemas: list[str],
        dry_run: bool,
        confirm_callback: Callable[[], bool] | None = None,
    ):
        self.adapter = adapter
        self.logger = logger
        self.target_db = target_db
        self.schemas = schemas
        self.dry_run = dry_run
        self.confirm_callback = confirm_callback

    def run(self) -> int:
        self.logger.info("=== Cleanup started (target db: %s) ===", self.target_db)
        self.logger.info("Target schemas: %s", ", ".join(self.schemas))

        if self.dry_run:
            self.logger.info("DRY RUN enabled, no database changes will be applied")
            self.logger.info("Would execute schema cleanup SQL: %s", self._schema_cleanup_sql())
            self.logger.info("Would execute terminate sessions SQL: %s", self._terminate_sessions_sql())
            self.logger.info("Would execute database cleanup SQL: %s", self._drop_database_sql())
            return 0

        if not self._confirm_cleanup():
            self.logger.warning("Cleanup cancelled by user confirmation response")
            return 2

        psql_bin = self.adapter._resolve_psql_executable()
        env = os.environ.copy()
        if self.adapter.config.password:
            env["PGPASSWORD"] = self.adapter.config.password

        db_exists = self._database_exists(psql_bin, env)
        if db_exists:
            schema_rc = self._run_psql_command(psql_bin, self.target_db, self._schema_cleanup_sql(), env)
            if schema_rc != 0:
                self.logger.error("Schema cleanup failed with code=%s", schema_rc)
                return schema_rc
        else:
            self.logger.warning("Database '%s' does not exist. Skipping schema cleanup.", self.target_db)

        terminate_rc = self._run_psql_command(psql_bin, "postgres", self._terminate_sessions_sql(), env)
        if terminate_rc != 0:
            self.logger.error("Session termination failed with code=%s", terminate_rc)
            return terminate_rc

        drop_rc = self._run_psql_command(psql_bin, "postgres", self._drop_database_sql(), env)
        if drop_rc == 0:
            self.logger.info("Cleanup completed successfully")
        else:
            self.logger.error("Database cleanup failed with code=%s", drop_rc)
        return drop_rc

    def _database_exists(self, psql_bin: str, env: dict[str, str]) -> bool:
        query = f"SELECT 1 FROM pg_database WHERE datname = {sql_literal(self.target_db)};"
        command = [
            psql_bin,
            "-h",
            self.adapter.config.host,
            "-p",
            self.adapter.config.port,
            "-U",
            self.adapter.config.user,
            "-d",
            "postgres",
            "-tA",
            "-c",
            query,
        ]

        self.logger.debug("Checking DB existence: %s", " ".join(command))
        completed = subprocess.run(command, capture_output=True, text=True, env=env, check=False)
        if completed.returncode != 0:
            combined = (completed.stdout or "") + (completed.stderr or "")
            self.logger.error("Failed to check database existence: %s", combined.strip())
            raise RuntimeError("Unable to determine whether target database exists")
        return completed.stdout.strip() == "1"

    def _run_psql_command(self, psql_bin: str, database: str, sql: str, env: dict[str, str]) -> int:
        command = [
            psql_bin,
            "-h",
            self.adapter.config.host,
            "-p",
            self.adapter.config.port,
            "-U",
            self.adapter.config.user,
            "-d",
            database,
            "-v",
            "ON_ERROR_STOP=1",
            "-c",
            sql,
        ]

        self.logger.info("Executing cleanup SQL on database '%s'", database)
        self.logger.debug("Command: %s", " ".join(command))

        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            env=env,
        )

        if process.stdout is not None:
            for line in process.stdout:
                clean_line = line.rstrip()
                print(clean_line)
                self.logger.info(clean_line)

        process.wait()
        return process.returncode

    def _schema_cleanup_sql(self) -> str:
        return " ".join(f"DROP SCHEMA IF EXISTS {quote_ident(name)} CASCADE;" for name in self.schemas)

    def _terminate_sessions_sql(self) -> str:
        db_literal = sql_literal(self.target_db)
        return " ".join(
            [
                "SELECT pg_terminate_backend(pid)",
                "FROM pg_stat_activity",
                f"WHERE datname = {db_literal} AND pid <> pg_backend_pid();",
            ]
        )

    def _drop_database_sql(self) -> str:
        db_ident = quote_ident(self.target_db)
        return f"DROP DATABASE IF EXISTS {db_ident};"

    def _confirm_cleanup(self) -> bool:
        if self.confirm_callback is not None:
            return self.confirm_callback()

        print("WARNING: This action is destructive.")
        print(f"Target database: {self.target_db}")
        print(f"Schemas to drop first: {', '.join(self.schemas)}")
        response = input("Type YES to continue cleanup: ").strip()
        return response == "YES"
