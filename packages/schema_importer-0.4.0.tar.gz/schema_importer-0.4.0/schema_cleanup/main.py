from __future__ import annotations

import os
import sys
from pathlib import Path

from dotenv import load_dotenv

from schema_cleanup.cli_args import parse_args
from schema_cleanup.identifier_utils import ensure_target_db_is_safe, parse_schema_list, validate_identifier
from schema_cleanup.schema_cleanup_service import SchemaCleanup
from schema_importer.env_utils import env_required
from schema_importer.ini_profile import apply_profile_to_environment, load_ini_profile, profile_db_engine, resolve_value
from schema_importer.logging_setup import setup_logging
from schema_importer.postgres_adapter import PostgresAdapter
from schema_importer.postgres_config import PostgresConfig
from schema_importer.time_utils import timestamp


def main(argv: list[str] | None = None) -> int:
    load_dotenv()
    args = parse_args(sys.argv[1:] if argv is None else argv)

    profile: dict[str, str] = {}
    if args.config_file:
        profile = load_ini_profile(args.config_file, args.config_section)
        apply_profile_to_environment(profile)

    db_engine = profile_db_engine(profile)
    if db_engine and db_engine != "postgres":
        raise ValueError(
            f"cleanup_schema currently supports PostgreSQL only. Profile engine '{db_engine}' is not supported."
        )

    raw_target_db = resolve_value(
        args.target_db,
        profile,
        ("cleanup_target_db", "database", "db", "db_name", "dbname"),
        os.getenv("PGDATABASE", "myapp_db"),
    )
    raw_schemas = resolve_value(
        args.schemas,
        profile,
        ("cleanup_schemas",),
        os.getenv("CLEANUP_SCHEMAS", "myapp,myapp_vector"),
    )

    target_db = ensure_target_db_is_safe(validate_identifier(raw_target_db))
    schemas = parse_schema_list(raw_schemas)

    log_dir = Path.cwd() / ".schema_staging" / timestamp()
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "cleanup.log"
    logger = setup_logging(log_file, os.getenv("LOG_LEVEL", "INFO"))

    adapter = PostgresAdapter(
        PostgresConfig(
            host=env_required("PGHOST"),
            port=env_required("PGPORT"),
            database=target_db,
            user=env_required("PGUSER"),
            password=os.getenv("PGPASSWORD", ""),
        )
    )

    cleanup = SchemaCleanup(
        adapter=adapter,
        logger=logger,
        target_db=target_db,
        schemas=schemas,
        dry_run=args.dry_run,
    )
    return cleanup.run()
