from __future__ import annotations

import argparse


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Cleanup Schema PostgreSQL schemas and database")
    parser.add_argument(
        "--config-file",
        help="Optional INI profile file path used to resolve connection and cleanup settings",
    )
    parser.add_argument(
        "--config-section",
        default="DEFAULT",
        help="INI section/profile name to load (default: DEFAULT)",
    )
    parser.add_argument(
        "--target-db",
        default=None,
        help="Database to cleanup and drop (default: myapp_db)",
    )
    parser.add_argument(
        "--schemas",
        default=None,
        help="Comma-separated schemas to drop inside target database before dropping the database",
    )
    parser.add_argument("--dry-run", action="store_true", help="Print actions without executing")
    return parser.parse_args(argv)
