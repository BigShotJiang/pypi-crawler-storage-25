#!/usr/bin/env python3
"""Cross-platform bootstrap for this repository.

Default behavior:
1. Create .venv if missing
2. Upgrade pip in .venv
3. Install dependencies from requirements.txt (if present)
4. Run unit tests
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path


def run(command: list[str], cwd: Path) -> None:
    print("+", " ".join(command))
    result = subprocess.run(command, cwd=str(cwd), check=False)
    if result.returncode != 0:
        raise SystemExit(result.returncode)


def venv_python_path(venv_dir: Path) -> Path:
    if sys.platform.startswith("win"):
        return venv_dir / "Scripts" / "python.exe"
    return venv_dir / "bin" / "python"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Cross-platform bootstrap for schema_importer")
    parser.add_argument("--venv-dir", default=".venv", help="Virtual environment directory")
    parser.add_argument("--recreate-venv", action="store_true", help="Delete and recreate virtual environment")
    parser.add_argument("--skip-install", action="store_true", help="Skip dependency installation")
    parser.add_argument("--skip-tests", action="store_true", help="Skip running tests")
    parser.add_argument("--coverage", action="store_true", help="Run tests with coverage and generate htmlcov report")
    parser.add_argument(
        "--cov-fail-under",
        type=int,
        default=100,
        help="Minimum required line coverage percentage when --coverage is enabled",
    )
    parser.add_argument("--python", default=sys.executable, help="Python executable used only to create venv")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    project_root = Path(__file__).resolve().parent
    venv_dir = (project_root / args.venv_dir).resolve()

    if args.recreate_venv and venv_dir.exists():
        print(f"Removing existing venv: {venv_dir}")
        shutil.rmtree(venv_dir)

    if not venv_dir.exists():
        print(f"Creating venv: {venv_dir}")
        run([args.python, "-m", "venv", str(venv_dir)], cwd=project_root)

    py = venv_python_path(venv_dir)
    if not py.exists():
        print(f"ERROR: virtual environment python not found at {py}")
        return 1

    run([str(py), "-m", "pip", "install", "--upgrade", "pip"], cwd=project_root)

    if not args.skip_install:
        req = project_root / "requirements.txt"
        if req.exists():
            run([str(py), "-m", "pip", "install", "-r", str(req)], cwd=project_root)
        else:
            print("requirements.txt not found, installing baseline dependencies")
            run([str(py), "-m", "pip", "install", "python-dotenv", "coverage"], cwd=project_root)

    if args.coverage and args.skip_tests:
        print("ERROR: --coverage cannot be combined with --skip-tests")
        return 2

    if args.cov_fail_under < 0 or args.cov_fail_under > 100:
        print("ERROR: --cov-fail-under must be between 0 and 100")
        return 2

    if args.coverage:
        run(
            [
                str(py),
                "-m",
                "coverage",
                "run",
                "--source=schema_import",
                "-m",
                "unittest",
                "discover",
                "-s",
                "tests",
                "-p",
                "test_*.py",
            ],
            cwd=project_root,
        )
        run([str(py), "-m", "coverage", "report", "-m", f"--fail-under={args.cov_fail_under}"], cwd=project_root)
        run([str(py), "-m", "coverage", "html", "-d", "htmlcov"], cwd=project_root)
    elif not args.skip_tests:
        run([str(py), "-m", "unittest", "discover", "-s", "tests", "-p", "test_*.py"], cwd=project_root)

    print("Bootstrap completed successfully.")
    print(f"Virtual environment: {venv_dir}")
    print(f"Interpreter used: {py}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
