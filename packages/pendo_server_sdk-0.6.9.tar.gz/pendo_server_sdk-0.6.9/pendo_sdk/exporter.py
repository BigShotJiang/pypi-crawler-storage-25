"""
Custom Span Exporter for Pendo Agent SDK

Converts OTel ReadableSpan objects into Pendo's agentic event format and
exports them to Pendo's ingestion pipeline.

The exporter is wired into the pipeline by init():
    TracerProvider -> BatchSpanProcessor -> PendoSpanExporter -> HTTP POST

Wire format follows the ingestion spec (APP-146809):
  - Endpoint: POST /data/agentic/<apiKey>?v=<version>&ct=<time>&s=<size>
  - Body: { "events": "<jzb>" }  (JZB = JSON → zlib → URL-safe base64)
  - Event type: "agent_trace" with trace fields in props
  - Source: "api" (set by the endpoint, not the SDK)

OTel span attribute → Pendo event field mapping:
    pendo.span.type              → props.agentTraceType
    llm.model_name               → props.modelUsed
    pendo.conversation_id        → props.conversationId
    message.content              → props.agentTraceContent
    tool.name                    → props.toolsUsed
    OTel trace_id                → props.agentTraceId
    OTel span_id                 → props.agentSpanId
    OTel parent.span_id          → props.agentParentSpanId
"""

import ast
import base64
import json
import logging
import re
import time
import uuid
import zlib
from typing import Any, Dict, List, Optional, Sequence

from opentelemetry.sdk.trace import ReadableSpan
from opentelemetry.sdk.trace.export import SpanExporter, SpanExportResult
from opentelemetry.trace import StatusCode

from .schema import (
    AgentEvent,
    EventBatch,
    EventProps,
    SpanStatusCode,
    SpanType,
)

logger = logging.getLogger("pendo_sdk")

from importlib.metadata import version as _pkg_version

try:
    _SDK_VERSION = _pkg_version("pendo-server-sdk")
except Exception:
    _SDK_VERSION = "0.4.9"

# PII redaction patterns applied before network export.
_PII_PATTERNS = [
    (re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b"), "[EMAIL_REDACTED]"),
    (re.compile(r"\b\d{3}[-.]?\d{3}[-.]?\d{4}\b"), "[PHONE_REDACTED]"),
    (re.compile(r"\b\d{3}-\d{2}-\d{4}\b"), "[SSN_REDACTED]"),
]

# Maps OTel span attribute keys → EventProps field names.
# Attributes not in this map go into props.extra.
_ATTR_TO_PROP: Dict[str, str] = {
    "llm.model_name": "model",
    "llm.token_count.prompt": "prompt_tokens",
    "llm.token_count.completion": "completion_tokens",
    "llm.token_count.total": "total_tokens",
    "llm.cost_usd": "cost_usd",
    "tool.name": "tool_name",
    "tool.input": "tool_input",
    "tool.output": "tool_output",
    "tool.status": "tool_status",
    "message.role": "role",
    "message.content": "content",
    "message.suggested_prompt": "suggested_prompt",
    "message.file_uploaded": "file_uploaded",
    "signal.name": "signal_name",
    "reaction.type": "reaction_type",
    "reaction.feedback_comment": "feedback_comment",
    "reaction.message_span_id": "message_span_id",
}

# Attribute keys consumed at the event level (not forwarded to props).
_EVENT_LEVEL_ATTRS = {"pendo.span.type", "pendo.conversation_id", "pendo.event_type", "pendo.tags", "pendo.visitor_id", "pendo.account_id", "message.trace_content", "message.response_content", "langsmith.span.kind"}

# All "known" attribute keys — anything else goes to props.extra.
_KNOWN_ATTRS = set(_ATTR_TO_PROP.keys()) | _EVENT_LEVEL_ATTRS

# Map our SpanType to the agentTraceType values the backend expects.
_SPAN_TYPE_TO_TRACE_TYPE: Dict[str, str] = {
    "USER_MESSAGE": "user_prompt",
    "TOOL_REQUEST": "tool_request",
    "TOOL_RESPONSE": "tool_response",
    "AGENT_REQUEST": "agent_request",
    "AGENT_RESPONSE": "agent_response",
    "LLM_REQUEST": "llm_request",
    "LLM_RESPONSE": "llm_response",
}

# Map LangSmith OTel span kinds to our trace types.
# When LANGSMITH_OTEL_ENABLED=true, LangChain emits OTel spans with
# langsmith.span.kind instead of pendo.span.type.
_LANGSMITH_KIND_TO_TRACE_TYPE: Dict[str, str] = {
    "LLM": "llm_request",
    "TOOL": "tool_request",
    "CHAIN": "agent_request",    # chains = agent orchestration
    "RETRIEVER": "tool_request",
    "EMBEDDING": "tool_request",
    "PROMPT": "llm_request",
    "PARSER": "llm_response",
}


# ---------------------------------------------------------------------------
# JZB encoding (JSON → zlib → URL-safe base64, strip padding)
# ---------------------------------------------------------------------------

def _to_jzb(obj: Any) -> str:
    """Encode a Python object as a JZB string.

    JZB = JSON → zlib compress → URL-safe base64 (padding stripped).
    This is Pendo's standard wire encoding for event payloads.
    """
    json_bytes = json.dumps(obj, separators=(",", ":"), default=str).encode("utf-8")
    compressed = zlib.compress(json_bytes)
    b64 = base64.urlsafe_b64encode(compressed).decode("ascii")
    # Strip trailing '=' padding (decoder restores it)
    return b64.rstrip("=")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _redact(value: str) -> str:
    """Apply all PII redaction patterns to a string."""
    for pattern, replacement in _PII_PATTERNS:
        value = pattern.sub(replacement, value)
    return value


# Attribute keys that must never be redacted — these are identity fields,
# not user-generated content.
_REDACT_SKIP = {"pendo.visitor_id", "pendo.account_id", "pendo.conversation_id"}


def _redact_attributes(attrs: dict) -> dict:
    """Redact PII from all string values in an attributes dict."""
    redacted = {}
    for key, value in attrs.items():
        if isinstance(value, str) and key not in _REDACT_SKIP:
            redacted[key] = _redact(value)
        else:
            redacted[key] = value
    return redacted


def _ns_to_ms(ns: Optional[int]) -> Optional[int]:
    """Convert nanosecond OTel timestamp to epoch milliseconds."""
    if ns is None:
        return None
    return ns // 1_000_000


def _parse_list_attr(raw: Any) -> List[str]:
    """Normalize a span attribute into a list of string elements.

    Older callers (or third-party instrumentation) sometimes stringify
    lists via ``str(list)`` before calling ``span.set_attribute``, which
    produces a single-quoted Python-repr string like ``"['foo']"`` that
    ``json.loads`` cannot parse. Try JSON first, then ``ast.literal_eval``
    as a safety net, then fall back to wrapping the raw scalar in a list.
    """
    if raw is None:
        return []
    if isinstance(raw, (list, tuple)):
        return [str(x) for x in raw if x]
    if isinstance(raw, str):
        s = raw.strip()
        if not s:
            return []
        try:
            parsed = json.loads(s)
        except (json.JSONDecodeError, TypeError):
            parsed = None
        if parsed is None and (s.startswith("[") or s.startswith("(")):
            try:
                parsed = ast.literal_eval(s)
            except (ValueError, SyntaxError):
                parsed = None
        if isinstance(parsed, (list, tuple)):
            return [str(x) for x in parsed if x]
        return [s]
    return [str(raw)]


def _otel_status_to_schema(status_code: StatusCode) -> SpanStatusCode:
    """Map OTel StatusCode to our schema's SpanStatusCode."""
    mapping = {
        StatusCode.UNSET: SpanStatusCode.UNSET,
        StatusCode.OK: SpanStatusCode.OK,
        StatusCode.ERROR: SpanStatusCode.ERROR,
    }
    return mapping.get(status_code, SpanStatusCode.UNSET)


def _resolve_span_type(raw: Any) -> SpanType:
    """Resolve a raw pendo.span.type attribute value to a SpanType enum."""
    if raw is None:
        return SpanType.UNKNOWN
    try:
        return SpanType(str(raw))
    except ValueError:
        return SpanType.UNKNOWN


class PendoSpanExporter(SpanExporter):
    """
    Exports spans to Pendo's ingestion endpoint as agent_trace events.

    Converts OTel ReadableSpan objects into Pendo's agentic event format,
    JZB-encodes them, and POSTs to /data/agentic/<apiKey>.

    Called by BatchSpanProcessor when its buffer flushes. This runs on
    the BatchSpanProcessor's background thread, so the agent's main
    thread never blocks.

    Args:
        api_key: Pendo integration key (also used in the URL path).
        endpoint: Base URL for the ingestion endpoint.
        redact_pii: Whether to run PII regex redaction before export.
        visitor_id: Pendo visitor ID stamped on every event.
        account_id: Pendo account ID stamped on every event.
    """

    def __init__(
        self,
        api_key: str,
        endpoint: str,
        redact_pii: bool = True,
        visitor_id: Optional[str] = None,
        account_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        url: Optional[str] = None,
    ):
        self._api_key = api_key
        self._endpoint = endpoint.rstrip("/")
        self._redact_pii = redact_pii
        self._visitor_id = visitor_id
        self._account_id = account_id
        self._agent_id = agent_id
        self._url = url
        self._suppressed_root_span_id: Optional[str] = None

    def set_identity(
        self,
        visitor_id: Optional[str] = None,
        account_id: Optional[str] = None,
    ) -> None:
        """Update identity after construction (e.g. when user logs in)."""
        if visitor_id is not None:
            self._visitor_id = visitor_id
        if account_id is not None:
            self._account_id = account_id

    def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        """
        Called by OTel BatchSpanProcessor when the buffer flushes.

        Flow: OTel spans → Pendo wire events → JZB encode → HTTP GET
        """
        try:
            logger.debug(
                "[OTel → Pendo] BatchSpanProcessor flushed %d span(s)", len(spans)
            )
            wire_events = []
            for seq, span in enumerate(spans, start=1):
                attrs = dict(span.attributes or {})
                span_type = attrs.get("pendo.span.type", "UNKNOWN")
                logger.debug(
                    "  Span %d: %s (%s) trace=%s",
                    seq, span.name, span_type,
                    format(span.context.trace_id, "032x")[:12] + "...",
                )
                if self._redact_pii:
                    attrs = _redact_attributes(attrs)
                wire_events.extend(self._build_wire_events(span, attrs, sequence=seq))

            if wire_events:
                self._send_jzb(wire_events)

            return SpanExportResult.SUCCESS
        except Exception:
            logger.exception("Failed to export %d spans", len(spans))
            return SpanExportResult.FAILURE

    def _build_event(self, span: ReadableSpan, attrs: dict) -> AgentEvent:
        """Convert an OTel span + redacted attributes into an AgentEvent.

        Kept for backward compatibility (dry-run exporter uses this).
        """
        prop_fields: Dict[str, Any] = {}
        extra: Dict[str, Any] = {}

        for key, value in attrs.items():
            if key in _EVENT_LEVEL_ATTRS:
                continue
            elif key in _ATTR_TO_PROP:
                mapped_key = _ATTR_TO_PROP[key]
                # model needs to be a list now
                if mapped_key == "model" and isinstance(value, str):
                    value = [value]
                prop_fields[mapped_key] = value
            else:
                extra[key] = value

        if extra:
            prop_fields["extra"] = extra

        props = EventProps(**prop_fields)

        start_ms = _ns_to_ms(span.start_time)
        end_ms = _ns_to_ms(span.end_time)
        duration_ms = None
        if start_ms is not None and end_ms is not None:
            duration_ms = round(end_ms - start_ms, 1)

        error_message = None
        if span.status.status_code == StatusCode.ERROR:
            error_message = span.status.description

        # Extract tags from span attributes
        tags = None
        raw_tags = attrs.get("pendo.tags")
        if raw_tags and isinstance(raw_tags, str):
            try:
                tags = json.loads(raw_tags)
            except (json.JSONDecodeError, TypeError):
                pass
        elif raw_tags and isinstance(raw_tags, dict):
            tags = raw_tags

        return AgentEvent(
            visitor_id=attrs.get("pendo.visitor_id") or self._visitor_id or "anonymous",
            account_id=attrs.get("pendo.account_id") or self._account_id,
            trace_id=format(span.context.trace_id, "032x"),
            span_id=format(span.context.span_id, "016x"),
            parent_span_id=(
                format(span.parent.span_id, "016x")
                if span.parent else None
            ),
            conversation_id=attrs.get("pendo.conversation_id"),
            event_type=attrs.get("pendo.event_type"),
            type=_resolve_span_type(attrs.get("pendo.span.type")),
            name=span.name,
            status=_otel_status_to_schema(span.status.status_code),
            error_message=error_message,
            start_time=start_ms,
            end_time=end_ms,
            duration_ms=duration_ms,
            props=props,
            tags=tags,
        )

    def _build_wire_events(self, span: ReadableSpan, attrs: dict, sequence: int) -> List[dict]:
        """Convert an OTel span into Pendo wire events.

        Returns a list of events:
        - For USER_MESSAGE/REACTION spans: one conversation event (prompt/user_reaction)
        - For all spans: one agent_trace event with full trace fields
        - Conversation events only carry agentTraceId for linking
        - Trace events carry all trace fields + agentTraceContent
        """
        span_type_raw = str(attrs.get("pendo.span.type", "UNKNOWN"))
        langsmith_kind = str(attrs.get("langsmith.span.kind", ""))
        role = attrs.get("message.role", "")

        # Skip the root conversation.turn span — it's just a container for
        # grouping child spans under one trace ID, not a real trace event.
        # Track its span ID so children can clear their parent reference.
        if role == "system" and span.name == "conversation.turn":
            self._suppressed_root_span_id = format(span.context.span_id, "016x")
            return []

        # Resolve trace type from either pendo.span.type or langsmith.span.kind
        is_pendo_span = span_type_raw in _SPAN_TYPE_TO_TRACE_TYPE or span_type_raw == "GENERATION"
        is_langsmith_span = langsmith_kind in _LANGSMITH_KIND_TO_TRACE_TYPE

        # Skip spans we can't classify from either source
        if not is_pendo_span and not is_langsmith_span:
            return []

        conversation_id = attrs.get("pendo.conversation_id", "")
        # Extract fields — check pendo attrs first, then LangSmith/GenAI attrs as fallback
        model_name = (attrs.get("llm.model_name", "")
                      or attrs.get("gen_ai.request.model", "")
                      or attrs.get("ls_model_name", ""))
        content = attrs.get("message.content", "")
        trace_content = attrs.get("message.trace_content", "")

        # For LangSmith OTel spans, extract content from inputs/outputs
        if is_langsmith_span and not content:
            content = (attrs.get("langsmith.inputs", "")
                       or attrs.get("gen_ai.prompt", "")
                       or span.name)
        ls_output = attrs.get("langsmith.outputs", "") if is_langsmith_span else ""
        suggested_prompt = bool(attrs.get("message.suggested_prompt", False))
        file_uploaded = bool(attrs.get("message.file_uploaded", False))
        feedback_comment = attrs.get("reaction.feedback_comment", "")
        reaction_type = attrs.get("reaction.type", "")

        tool_names = []
        tool_name = attrs.get("tool.name") or (span.name if langsmith_kind == "TOOL" else "")
        if tool_name:
            tool_names.append(tool_name)

        # Determine trace type: pendo.span.type takes priority, then langsmith.span.kind
        if is_pendo_span:
            trace_type = _SPAN_TYPE_TO_TRACE_TYPE.get(span_type_raw, "generation")
        else:
            trace_type = _LANGSMITH_KIND_TO_TRACE_TYPE.get(langsmith_kind, "generation")

        trace_id = format(span.context.trace_id, "032x")
        span_id = format(span.context.span_id, "016x")

        # Resolve parent span ID. The conversation.turn root span is suppressed
        # from events, so any span whose parent is the root should have an empty
        # parent — they become top-level nodes in the visible trace tree.
        parent_span_id = ""
        if span.parent:
            parent_span_id = format(span.parent.span_id, "016x")
            # Check if parent is the suppressed root span by comparing to
            # the root span ID tracked on the exporter (set by callback handler)
            if parent_span_id == self._suppressed_root_span_id:
                parent_span_id = ""

        browser_time = _ns_to_ms(span.start_time) or int(time.time() * 1000)
        message_id = str(uuid.uuid4())
        # Prefer per-span identity (stamped at creation time on the request thread)
        # over exporter instance state (which may be overwritten by concurrent requests).
        visitor_id = attrs.get("pendo.visitor_id") or self._visitor_id or "anonymous"
        account_id = attrs.get("pendo.account_id") or self._account_id or ""
        url = self._url or ""

        # Response content from on_llm_end / on_tool_end
        response_content = attrs.get("message.response_content", "")
        is_assistant = role == "assistant"

        events = []

        # --- Conversation event (prompt / agent_response / user_reaction) ---
        is_user_message = role == "user" or span_type_raw == "USER_MESSAGE"
        is_reaction = span_type_raw == "REACTION" or reaction_type

        if is_user_message or is_reaction or is_assistant:
            if is_reaction:
                conv_type = "user_reaction"
            elif is_assistant:
                conv_type = "agent_response"
            else:
                conv_type = "prompt"

            conv_content = content
            if is_reaction:
                conv_content = reaction_type
            elif is_assistant and response_content:
                conv_content = response_content
            elif conv_content:
                conv_content = str(conv_content)

            conv_props: Dict[str, Any] = {
                "agentId": self._agent_id or "",
                "agentType": "conversation",
                "conversationId": conversation_id or "",
                "messageId": message_id,
                "content": conv_content or "",
                "modelUsed": str(model_name) if model_name else "",
                "suggestedPrompt": suggested_prompt,
                "toolsUsed": tool_names,
                "fileUploaded": file_uploaded,
                # Only agentTraceId for linking to trace — no other trace fields
                "agentTraceId": trace_id,
                "visitorId": visitor_id,
                "accountId": account_id,
            }
            if feedback_comment:
                conv_props["feedbackComment"] = feedback_comment

            events.append({
                "type": conv_type,
                "visitor_id": visitor_id,
                "account_id": account_id,
                "url": url,
                "timestamp": browser_time,
                "props": conv_props,
            })

        # --- Trace event(s) (agent_trace) ---
        # USER_MESSAGE and AGENT_RESPONSE only emit conversation events — no trace event.
        # USER_MESSAGE: the prompt conversation event already captures the user's message.
        # AGENT_RESPONSE: the merged response conversation event; the llm_response trace
        #   already shows the same content in the trace tree.
        if span_type_raw in ("USER_MESSAGE", "AGENT_RESPONSE"):
            return events

        tool_input = attrs.get("tool.input", "")
        tool_output = attrs.get("tool.output", "")

        # For LangSmith OTel spans, use langsmith.inputs/outputs
        if is_langsmith_span:
            ls_inputs = attrs.get("langsmith.inputs", "")
            ls_outputs = attrs.get("langsmith.outputs", "")
            if not tool_input and langsmith_kind == "TOOL":
                tool_input = str(ls_inputs) if ls_inputs else span.name
            if not tool_output and langsmith_kind == "TOOL":
                tool_output = str(ls_outputs) if ls_outputs else ""
            if not trace_content and langsmith_kind == "LLM":
                trace_content = str(ls_inputs) if ls_inputs else content
            if not response_content and langsmith_kind == "LLM":
                response_content = str(ls_outputs) if ls_outputs else ""

        is_tool = trace_type in ("tool_request", "agent_request")

        # Common props shared by all trace events from this span
        common_trace_props: Dict[str, Any] = {
            "agentId": self._agent_id or "",
            "agentType": "conversation",
            "agentParentSpanId": parent_span_id,
            "agentTraceId": trace_id,
            "conversationId": conversation_id or "",
            "modelUsed": str(model_name) if model_name else "",
            "suggestedPrompt": suggested_prompt,
            "toolsUsed": tool_names,
            "fileUploaded": file_uploaded,
            "visitorId": visitor_id,
            "accountId": account_id,
        }

        # Token usage — populated by the LangChain callback's on_llm_end (for
        # GENERATION spans) or by the OpenAI patchers (for direct SDK callers).
        # Surface as top-level props so ingestion's `agentInputTokenCount` /
        # `agentOutputTokenCount` columns can pick them up off llm_request /
        # llm_response events. Separate fields let the UI match the LangSmith
        # cost breakdown (cache-read input, reasoning output).
        prompt_tokens = attrs.get("llm.token_count.prompt")
        completion_tokens = attrs.get("llm.token_count.completion")
        total_tokens = attrs.get("llm.token_count.total")
        if prompt_tokens is not None:
            common_trace_props["agentInputTokenCount"] = prompt_tokens
        if completion_tokens is not None:
            common_trace_props["agentOutputTokenCount"] = completion_tokens
        if total_tokens is not None:
            common_trace_props["agentTotalTokenCount"] = total_tokens
        cache_read_tokens = attrs.get("llm.token_count.prompt_cache_read")
        if cache_read_tokens is not None:
            common_trace_props["agentCacheReadTokenCount"] = cache_read_tokens
        reasoning_tokens = attrs.get("llm.token_count.completion_reasoning")
        if reasoning_tokens is not None:
            common_trace_props["agentReasoningTokenCount"] = reasoning_tokens

        # Subagents invoked during the turn — stamped by the LangChain callback
        # on the parent AGENT or AGENT_REQUEST span. Propagate to the wire so
        # ingestion's `agentSubagentsUsed` column populates on agent_request.
        raw_subagents = attrs.get("pendo.subagents_used")
        if raw_subagents:
            subagents = _parse_list_attr(raw_subagents)
            if subagents:
                common_trace_props["agentSubagentsUsed"] = subagents

        raw_tags = attrs.get("pendo.tags")
        if raw_tags:
            if isinstance(raw_tags, str):
                try:
                    common_trace_props["tags"] = json.loads(raw_tags)
                except (json.JSONDecodeError, TypeError):
                    pass
            elif isinstance(raw_tags, dict):
                common_trace_props["tags"] = raw_tags

        is_generation = span_type_raw == "GENERATION"
        is_langsmith_llm = is_langsmith_span and langsmith_kind == "LLM"

        if is_generation or is_langsmith_llm:
            # Split LLM call into llm_request + llm_response trace events.
            # Shows the decision chain: input → LLM → output (which tool/route to take).
            # No conversation events — the merged AGENT_RESPONSE handles that.
            request_span_id = span_id
            response_span_id = span_id[:12] + "resp"

            # llm_request — what was sent to the LLM
            req_content = str(trace_content) if trace_content else (str(content) if content else span.name)
            req_props = {
                **common_trace_props,
                "agentSpanId": request_span_id,
                "agentTraceType": "llm_request",
                "agentTraceContent": req_content,
                "messageId": message_id,
            }
            events.append({
                "type": "agent_trace",
                "visitor_id": visitor_id,
                "account_id": account_id,
                "url": url,
                "timestamp": browser_time,
                "props": req_props,
            })

            # llm_response — what came back (text or tool decision)
            resp_content = str(response_content) if response_content else ""
            if resp_content:
                resp_props = {
                    **common_trace_props,
                    "agentSpanId": response_span_id,
                    "agentParentSpanId": request_span_id,
                    "agentTraceType": "llm_response",
                    "agentTraceContent": resp_content,
                    "messageId": str(uuid.uuid4()),
                }
                events.append({
                    "type": "agent_trace",
                    "visitor_id": visitor_id,
                    "account_id": account_id,
                    "url": url,
                    "timestamp": _ns_to_ms(span.end_time) or browser_time,
                    "props": resp_props,
                })

        elif is_tool:
            # Split tool span into two trace events: tool_request + tool_response
            # Each gets its own spanId so the UI can render them as separate nodes
            request_span_id = span_id
            response_span_id = span_id[:12] + "resp"  # Derived ID for the response half

            # tool_request — input
            req_props = {
                **common_trace_props,
                "agentSpanId": request_span_id,
                "agentTraceType": trace_type,  # "tool_request" or "agent_request"
                "agentTraceContent": str(tool_input) if tool_input else span.name,
                "messageId": message_id,
            }
            events.append({
                "type": "agent_trace",
                "visitor_id": visitor_id,
                "account_id": account_id,
                "url": url,
                "timestamp": browser_time,
                "props": req_props,
            })

            # tool_response — output (only if we have output)
            if tool_output:
                resp_props = {
                    **common_trace_props,
                    "agentSpanId": response_span_id,
                    "agentParentSpanId": request_span_id,  # Response is child of request
                    "agentTraceType": "agent_response" if trace_type == "agent_request" else "tool_response",
                    "agentTraceContent": str(tool_output),
                    "messageId": str(uuid.uuid4()),
                }
                events.append({
                    "type": "agent_trace",
                    "visitor_id": visitor_id,
                    "account_id": account_id,
                    "url": url,
                    "timestamp": _ns_to_ms(span.end_time) or browser_time,
                    "props": resp_props,
                })
        else:
            # Non-tool trace events — resolve content based on type:
            #   generation    → the full prompt context (what was sent to the LLM)
            #   llm_request   → the prompt context
            #   llm_response  → the actual LLM response text
            #   agent_response→ the actual response text
            #   user_prompt   → the user's message
            if trace_type in ("llm_response", "agent_response"):
                resolved_content = str(response_content) if response_content else (str(content) if content else "")
            else:
                resolved_content = str(trace_content) if trace_content else (str(content) if content else span.name)

            trace_props = {
                **common_trace_props,
                "agentSpanId": span_id,
                "agentTraceType": trace_type,
                "agentTraceContent": resolved_content,
                "messageId": message_id,
            }

            events.append({
                "type": "agent_trace",
                "visitor_id": visitor_id,
                "account_id": account_id,
                "url": url,
                "timestamp": browser_time,
                "props": trace_props,
            })

        return events

    def _send_jzb(self, events: List[dict]) -> None:
        """
        JZB-encode events and send to the Pendo ingestion endpoint.

        Uses GET with JZB as query param (matching the Go agentic-send tool):
        GET /data/agentic/<apiKey>?v=<version>&ct=<time>&jzb=<jzb>

        Falls back to POST for large payloads (JZB > 8000 chars).
        """
        import urllib.error
        import urllib.request

        # Populate bytes field on each event
        for evt in events:
            evt["bytes"] = len(json.dumps(evt, separators=(",", ":")).encode("utf-8"))

        jzb = _to_jzb(events)
        ct = int(time.time() * 1000)

        base_path = f"{self._endpoint}/data/agentic/{self._api_key}"

        # GET is preferred; POST for large payloads
        if len(jzb) <= 8000:
            url = f"{base_path}?v={_SDK_VERSION}&ct={ct}&jzb={jzb}"
            req = urllib.request.Request(url, method="GET")
        else:
            url = f"{base_path}?v={_SDK_VERSION}&ct={ct}&s={len(jzb)}"
            body = jzb.encode("utf-8")
            req = urllib.request.Request(
                url,
                data=body,
                headers={"Content-Type": "text/plain"},
                method="POST",
            )

        num_events = len(events)
        log_url = base_path
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                if resp.status >= 400:
                    logger.warning(
                        "Ingestion returned %d for %d event(s)",
                        resp.status,
                        num_events,
                    )
                else:
                    logger.info(
                        "Exported %d event(s) to %s [%d]",
                        num_events,
                        log_url,
                        resp.status,
                    )
        except urllib.error.HTTPError as exc:
            logger.warning(
                "Ingestion returned HTTP %d for %d event(s) to %s: %s",
                exc.code,
                num_events,
                log_url,
                exc.reason,
            )
        except Exception as exc:
            logger.warning(
                "Failed to send %d event(s) to %s: %s",
                num_events,
                log_url,
                exc,
            )

    def shutdown(self) -> None:
        """Clean up resources. Called when the TracerProvider shuts down."""
        pass

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        """Force-flush is handled by BatchSpanProcessor, not the exporter."""
        return True
