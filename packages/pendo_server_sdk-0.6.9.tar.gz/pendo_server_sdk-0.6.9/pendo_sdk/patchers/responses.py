"""
OpenAI Responses API Patcher

Monkey-patches openai.resources.responses.Responses.create (sync) and
openai.resources.responses.AsyncResponses.create (async) to wrap each call
in a GENERATION span with model name and token usage.

The Responses API is a distinct code path from Chat Completions and is used
by newer OpenAI reasoning models (o1/o3/gpt-5.x) and by LangChain's
ChatOpenAI when use_responses_api is enabled. Token fields are named
input_tokens / output_tokens (not prompt_tokens / completion_tokens).

Only patches if the `openai` package is importable.
"""

import functools
import logging
from typing import Any, Callable, Optional

from opentelemetry import trace
from opentelemetry.trace import StatusCode

logger = logging.getLogger("pendo_sdk")

_SDK_NAME = "pendo_sdk"

_original_sync_create: Optional[Callable] = None
_original_async_create: Optional[Callable] = None


def _extract_attributes(span: trace.Span, result: Any) -> None:
    """Extract model name and token usage from an OpenAI Responses API result."""
    model = getattr(result, "model", None)
    if model is not None:
        span.set_attribute("llm.model_name", str(model))

    usage = getattr(result, "usage", None)
    if usage is not None:
        # Responses API: input_tokens / output_tokens / total_tokens.
        # Map to the same llm.token_count.* attributes the Chat Completions
        # patcher emits so ingestion doesn't need a separate code path.
        input_tokens = getattr(usage, "input_tokens", None)
        if input_tokens is not None:
            span.set_attribute("llm.token_count.prompt", input_tokens)
        output_tokens = getattr(usage, "output_tokens", None)
        if output_tokens is not None:
            span.set_attribute("llm.token_count.completion", output_tokens)
        total_tokens = getattr(usage, "total_tokens", None)
        if total_tokens is not None:
            span.set_attribute("llm.token_count.total", total_tokens)


def _make_sync_wrapper(original: Callable) -> Callable:
    """Wrap the sync Responses.create method."""
    from .openai import _langchain_owns_this_call, _stamp_identity

    @functools.wraps(original)
    def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
        if _langchain_owns_this_call():
            return original(self, *args, **kwargs)

        model = kwargs.get("model") or (args[0] if args else "unknown")
        span_name = "openai.responses.create"
        tracer = trace.get_tracer(_SDK_NAME)

        with tracer.start_as_current_span(span_name) as span:
            span.set_attribute("pendo.span.type", "GENERATION")
            span.set_attribute("llm.model_name", str(model))
            _stamp_identity(span)
            try:
                result = original(self, *args, **kwargs)
            except Exception as exc:
                span.set_status(StatusCode.ERROR, str(exc))
                span.record_exception(exc)
                raise
            _extract_attributes(span, result)
            return result

    return wrapper


def _make_async_wrapper(original: Callable) -> Callable:
    """Wrap the async AsyncResponses.create method."""
    from .openai import _langchain_owns_this_call, _stamp_identity

    @functools.wraps(original)
    async def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
        if _langchain_owns_this_call():
            return await original(self, *args, **kwargs)

        model = kwargs.get("model") or (args[0] if args else "unknown")
        span_name = "openai.responses.create"
        tracer = trace.get_tracer(_SDK_NAME)

        with tracer.start_as_current_span(span_name) as span:
            span.set_attribute("pendo.span.type", "GENERATION")
            span.set_attribute("llm.model_name", str(model))
            _stamp_identity(span)
            try:
                result = await original(self, *args, **kwargs)
            except Exception as exc:
                span.set_status(StatusCode.ERROR, str(exc))
                span.record_exception(exc)
                raise
            _extract_attributes(span, result)
            return result

    return wrapper


def patch_responses() -> Optional[Callable[[], None]]:
    """Patch openai.resources.responses.Responses.create and async variant.

    Returns an unpatch callable, or None if the Responses module is not
    present in the installed openai version.
    """
    global _original_sync_create, _original_async_create

    try:
        import openai.resources.responses as responses_mod
    except ImportError:
        logger.debug("openai.resources.responses not available, skipping patch")
        return None

    sync_cls = getattr(responses_mod, "Responses", None)
    if sync_cls is not None:
        _original_sync_create = sync_cls.create
        sync_cls.create = _make_sync_wrapper(_original_sync_create)

    async_cls = getattr(responses_mod, "AsyncResponses", None)
    if async_cls is not None:
        _original_async_create = async_cls.create
        async_cls.create = _make_async_wrapper(_original_async_create)

    if sync_cls is None and async_cls is None:
        logger.debug("openai.resources.responses has no Responses classes")
        return None

    logger.debug("OpenAI Responses patched")

    def _unpatch() -> None:
        global _original_sync_create, _original_async_create
        if sync_cls is not None and _original_sync_create is not None:
            sync_cls.create = _original_sync_create
            _original_sync_create = None
        if async_cls is not None and _original_async_create is not None:
            async_cls.create = _original_async_create
            _original_async_create = None
        logger.debug("OpenAI Responses unpatched")

    return _unpatch
