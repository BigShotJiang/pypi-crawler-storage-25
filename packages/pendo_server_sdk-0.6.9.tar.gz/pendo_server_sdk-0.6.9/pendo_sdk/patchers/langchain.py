"""
LangChain Patcher

Registers a configure hook with LangChain's callback system so that
the PendoCallbackHandler is automatically injected into every chain,
agent, and LLM invocation — no manual ``callbacks=[handler]`` needed.

Uses ``langchain_core.tracers.context.register_configure_hook`` with a
ContextVar. When the contextvar holds a handler (set by
``pendo_sdk.set_context``), LangChain auto-includes it. When the
contextvar is None (outside a request context), nothing is injected.

Only patches if ``langchain_core`` is importable.
"""

import contextvars
import logging
from typing import Any, Callable, Optional

logger = logging.getLogger("pendo_sdk")

# ContextVar that LangChain reads via the registered configure hook.
# When set to a PendoCallbackHandler, it's auto-injected into every
# CallbackManager.configure() call. When None, nothing happens.
pendo_callback_var: contextvars.ContextVar[Optional[Any]] = contextvars.ContextVar(
    "pendo_callback_var", default=None
)

# Set to True by PendoCallbackHandler.on_llm_start and reset in on_llm_end /
# on_llm_error. The OpenAI Completions and Responses patchers check this and
# skip span creation while it's True — the LangChain callback is already
# creating a GENERATION span for this LLM call, and a second one from the
# low-level patcher would double-count the event.
langchain_llm_active: contextvars.ContextVar[bool] = contextvars.ContextVar(
    "pendo_langchain_llm_active", default=False
)


def patch_langchain() -> Optional[Callable[[], None]]:
    """Register a LangChain configure hook to auto-inject PendoCallbackHandler.

    Returns an unpatch callable, or None if langchain_core is not installed.
    """
    try:
        from langchain_core.tracers.context import (
            register_configure_hook,
            _configure_hooks,
        )
    except ImportError:
        logger.debug("langchain_core not installed, skipping patch")
        return None

    # Check if we've already registered (idempotent)
    for hook in _configure_hooks:
        if hook[0] is pendo_callback_var:
            logger.debug("LangChain Pendo hook already registered, skipping")
            return lambda: None

    register_configure_hook(
        context_var=pendo_callback_var,
        inheritable=True,  # propagates to sub-chains and sub-agents
        handle_class=None,  # no env-var-based auto-creation
        env_var=None,
    )

    logger.debug("LangChain Pendo configure hook registered")

    def _unpatch() -> None:
        # Remove our hook from the list
        hooks_to_remove = [h for h in _configure_hooks if h[0] is pendo_callback_var]
        for hook in hooks_to_remove:
            _configure_hooks.remove(hook)
        logger.debug("LangChain Pendo configure hook removed")

    return _unpatch
