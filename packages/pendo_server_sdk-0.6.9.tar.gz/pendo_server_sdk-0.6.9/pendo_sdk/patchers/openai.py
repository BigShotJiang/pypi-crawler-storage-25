"""
OpenAI Patcher

Monkey-patches openai.resources.chat.completions.Completions.create (sync)
and openai.resources.chat.completions.AsyncCompletions.create (async) to
wrap each call in a GENERATION span with model name and token usage.

Only patches if the `openai` package is importable.
"""

import functools
import logging
from typing import Any, Callable, Optional

from opentelemetry import trace
from opentelemetry.trace import StatusCode

logger = logging.getLogger("pendo_sdk")

_SDK_NAME = "pendo_sdk"

# Stash originals for unpatching.
_original_sync_create: Optional[Callable] = None
_original_async_create: Optional[Callable] = None


def _stamp_identity(span: trace.Span) -> None:
    """Stamp visitor/account identity on a patcher-created span.

    Reads the active ``PendoCallbackHandler`` from ``pendo_callback_var`` for
    per-request identity (set by ``pendo_sdk.set_context``), falling back to
    the init-time defaults on ``pendo_sdk.core``. Without this, spans the
    patcher creates for non-LangChain callers export with empty visitor_id
    and account_id.
    """
    visitor = ""
    account = ""
    try:
        from .langchain import pendo_callback_var
        handler = pendo_callback_var.get()
        if handler is not None:
            visitor = getattr(handler, "_visitor_id", "") or ""
            account = getattr(handler, "_account_id", "") or ""
    except Exception:
        pass
    if not visitor or not account:
        try:
            from .. import core as _core
            visitor = visitor or (_core._visitor_id or "")
            account = account or (_core._account_id or "")
        except Exception:
            pass
    if visitor:
        span.set_attribute("pendo.visitor_id", visitor)
    if account:
        span.set_attribute("pendo.account_id", account)


def _extract_attributes(span: trace.Span, result: Any) -> None:
    """Extract model name and token usage from an OpenAI response."""
    model = getattr(result, "model", None)
    if model is not None:
        span.set_attribute("llm.model_name", str(model))

    usage = getattr(result, "usage", None)
    if usage is not None:
        # OpenAI uses prompt_tokens / completion_tokens
        prompt_tokens = getattr(usage, "prompt_tokens", None)
        if prompt_tokens is not None:
            span.set_attribute("llm.token_count.prompt", prompt_tokens)
        completion_tokens = getattr(usage, "completion_tokens", None)
        if completion_tokens is not None:
            span.set_attribute("llm.token_count.completion", completion_tokens)
        total_tokens = getattr(usage, "total_tokens", None)
        if total_tokens is not None:
            span.set_attribute("llm.token_count.total", total_tokens)


def _langchain_owns_this_call() -> bool:
    """Check the LangChain patcher's ``langchain_llm_active`` ContextVar.

    When True, the PendoCallbackHandler is already mid-flight for this LLM
    call and creating its own GENERATION span via the LangChain callback
    chain. The low-level patcher must skip span creation to avoid emitting
    duplicate llm_request / llm_response events for a single call.
    """
    try:
        from .langchain import langchain_llm_active
        return langchain_llm_active.get()
    except Exception:
        return False


def _make_sync_wrapper(original: Callable) -> Callable:
    """Wrap the sync Completions.create method."""

    @functools.wraps(original)
    def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
        if _langchain_owns_this_call():
            return original(self, *args, **kwargs)

        model = kwargs.get("model") or (args[0] if args else "unknown")
        span_name = "openai.chat.completions.create"
        tracer = trace.get_tracer(_SDK_NAME)

        with tracer.start_as_current_span(span_name) as span:
            span.set_attribute("pendo.span.type", "GENERATION")
            span.set_attribute("llm.model_name", str(model))
            _stamp_identity(span)
            try:
                result = original(self, *args, **kwargs)
            except Exception as exc:
                span.set_status(StatusCode.ERROR, str(exc))
                span.record_exception(exc)
                raise
            _extract_attributes(span, result)
            return result

    return wrapper


def _make_async_wrapper(original: Callable) -> Callable:
    """Wrap the async AsyncCompletions.create method."""

    @functools.wraps(original)
    async def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
        if _langchain_owns_this_call():
            return await original(self, *args, **kwargs)

        model = kwargs.get("model") or (args[0] if args else "unknown")
        span_name = "openai.chat.completions.create"
        tracer = trace.get_tracer(_SDK_NAME)

        with tracer.start_as_current_span(span_name) as span:
            span.set_attribute("pendo.span.type", "GENERATION")
            span.set_attribute("llm.model_name", str(model))
            _stamp_identity(span)
            try:
                result = await original(self, *args, **kwargs)
            except Exception as exc:
                span.set_status(StatusCode.ERROR, str(exc))
                span.record_exception(exc)
                raise
            _extract_attributes(span, result)
            return result

    return wrapper


def patch_openai() -> Optional[Callable[[], None]]:
    """Patch openai.chat.completions.Completions.create and async variant.

    Returns an unpatch callable, or None if openai is not installed.
    """
    global _original_sync_create, _original_async_create

    try:
        import openai.resources.chat.completions as completions_mod
    except ImportError:
        logger.debug("openai not installed, skipping patch")
        return None

    # Patch sync
    sync_cls = getattr(completions_mod, "Completions", None)
    if sync_cls is not None:
        _original_sync_create = sync_cls.create
        sync_cls.create = _make_sync_wrapper(_original_sync_create)

    # Patch async
    async_cls = getattr(completions_mod, "AsyncCompletions", None)
    if async_cls is not None:
        _original_async_create = async_cls.create
        async_cls.create = _make_async_wrapper(_original_async_create)

    logger.debug("OpenAI patched")

    def _unpatch() -> None:
        global _original_sync_create, _original_async_create
        if sync_cls is not None and _original_sync_create is not None:
            sync_cls.create = _original_sync_create
            _original_sync_create = None
        if async_cls is not None and _original_async_create is not None:
            async_cls.create = _original_async_create
            _original_async_create = None
        logger.debug("OpenAI unpatched")

    return _unpatch
