import logging
import inspect
import functools
from typing import Any, Dict, Optional, Callable, List, Union, NamedTuple

import jinja2

from . import util
from . import postprocess
from . import client as _client
from . import channel as _channel
from .model import LLMDirectRequest, Message, MediaContent, LLMModuleResult, LLMModuleRequest, FinishReason


logger = logging.getLogger(__name__)


class ModuleConfig(NamedTuple):
    """模块配置"""
    name: str
    description: str
    model: str
    templates: Dict[str, str] = {}
    tools: Dict[str, Dict[str, Any]] = {}
    stream: bool = False
    post_processor: Optional[str] = None
    options: Dict[str, Any] = {}


class ConfigTemplateLoader(jinja2.BaseLoader):
    """自定义Jinja2模板加载器，支持全局和模块模板交叉引用"""

    def __init__(self, config_dict: Dict[str, Any]):
        self.global_templates = config_dict.get('template', {})
        self.modules = config_dict.get('module', {})

    def get_source(self, environment, template):
        """
        获取模板源码
        template 可以是:
        - 'header' -> 全局模板
        - 'module/task_planner/user' -> 模块task_planner的user模板
        """
        if template in self.global_templates:
            source = self.global_templates[template]
            return source, template, lambda: True
        elif template.startswith('module/'):
            # 模块模板: module/{module_name}/{template_name}
            parts = template.split('/')
            module_name = parts[1]
            template_name = parts[2]
            module_config = self.modules.get(module_name, {})
            if template_name in module_config.get('template', {}):
                source = module_config['template'][template_name]
                return source, template, lambda: True
        raise jinja2.TemplateNotFound(template)

    def __contains__(self, item):
        if item in self.global_templates:
            return True
        elif item.startswith('module/'):
            parts = item.split('/')
            module_name = parts[1]
            template_name = parts[2]
            return template_name in self.modules.get(module_name, {}).get('template', {})
        return False

    def list_templates(self):
        """列出所有可用模板（调试用）"""
        templates = list(self.global_templates.keys())
        for module_name, module_config in self.modules.items():
            for template_name in module_config.get('template', {}).keys():
                templates.append(f"module/{module_name}/{template_name}")
        return templates


class _LLMModule(NamedTuple):
    app: 'LLMApplication'
    module_name: str

    async def __call__(
            self, *,
            _model_name: Optional[str] = None,
            _context_messages: Optional[List[Message]] = None,
            _media_content: Optional[List[MediaContent]] = None,
            _output_channel: Optional[_channel.ChannelWriter] = None,
            **kwargs
    ) -> LLMModuleResult:
        return await self.app.call(LLMModuleRequest(
            module_name=self.module_name,
            template_params=kwargs,
            model_name=_model_name,
            context_messages=_context_messages,
            media_content=_media_content,
            output_channel=_output_channel
        ))


class LLMApplication:
    """LLM应用上下文"""

    def __init__(
        self,
        client: _client.LLMClient,
        config_dict: Optional[Dict[str, Any]] = None,
        processors: Optional[Dict[str, Callable[[str], Any]]] = None,
        context_id: Optional[str] = None
    ):
        self.client: _client.LLMClient = client
        self.context_id: str = context_id or util.get_id()
        self.vars: Dict[str, Any] = {}
        self.processors: Dict[str, Callable[[str], Any]] = postprocess.DEFAULT_PROCESSORS.copy()

        # 加载全局工具定义
        self.global_tools: Dict[str, Any] = {}

        # 配置初始化
        self.config = (config_dict or {}).copy()
        self.config.setdefault('module', {})
        self.config.setdefault('template', {})
        self.config.setdefault('tools', {})

        # 加载应用层模型别名配置
        self.model_alias: Dict[str, str] = self.config.get('model_alias', {})

        # 加载全局工具
        self.global_tools = self.config.get('tools', {})

        # 初始化Jinja2环境，使用自定义loader
        self.template_loader = ConfigTemplateLoader(config_dict)
        self.jinja_env: jinja2.Environment = jinja2.Environment(
            loader=self.template_loader,
            autoescape=False
        )

        if processors:
            self.processors.update(processors)

        self.module_default: ModuleConfig = self._parse_module_config(
            '', self.config.get('module_default', {}))
        self.module_configs: Dict[str, ModuleConfig] = {}
        for module_name in self.config['module'].keys():
            self.module_configs[module_name] = self.load_module_config(module_name)

    def _parse_module_config(self, module_name, config) -> ModuleConfig:
        # 处理工具配置（支持全局工具引用）
        tools_config = config.get('tools', {})
        resolved_tools = {}

        for tool_name, tool_config in tools_config.items():
            # 如果工具配置为空dict，表示引用全局工具
            if isinstance(tool_config, dict) and not tool_config:
                if tool_name in self.global_tools:
                    resolved_tools[tool_name] = self.global_tools[tool_name]
                else:
                    raise ValueError(f"Module '{module_name}' referenced undefined global tool '{tool_name}'.")
            else:
                # 使用模块自定义配置（覆盖全局配置）
                resolved_tools[tool_name] = tool_config

        # 创建模块配置对象
        return ModuleConfig(
            name=module_name,
            description=config.get('description', ''),
            model=config.get('model', ''),
            templates=config.get('template', {}),
            tools=resolved_tools,
            stream=config.get('stream', False),
            post_processor=config.get('post_processor'),
            options=config.get('options', {})
        )

    def load_module_config(self, module_name) -> ModuleConfig:
        # raise KeyError
        module_config = self.config['module'][module_name]
        config = self.config.get('module_default', {}).copy()
        config.update(module_config)
        return self._parse_module_config(module_name, config)

    def __getitem__(self, name: str) -> _LLMModule:
        """通过下标访问的方式调用模块"""
        if name in self.module_configs:
            return _LLMModule(self, name)
        raise KeyError(f"No LLM module named '{name}'")

    def add_processor(self, name: str, processor: Callable):
        """添加后处理器"""
        self.processors[name] = processor

    def get_processor(self, name: str) -> Optional[Callable]:
        """获取后处理器"""
        return self.processors.get(name)

    def has_template(self, template_name: str) -> bool:
        return template_name in self.template_loader

    def render_template(self, template_name: str, **kwargs) -> str:
        """渲染命名模板"""
        all_vars = {**self.vars, **kwargs}
        return self.jinja_env.get_template(template_name).render(**all_vars)

    def add_module(self, module_config: ModuleConfig):
        """添加LLM模块"""
        self.module_configs[module_config.name] = module_config

    async def audit_event(self, event_type: str, **kwargs):
        """触发用户自定义审计事件"""
        await self.client.audit_event(self.context_id, event_type, **kwargs)

    def render_direct_request(
            self, module_request: Union[LLMModuleRequest, LLMDirectRequest]
    ) -> LLMDirectRequest:
        if isinstance(module_request, LLMDirectRequest):
            return module_request
        messages = []
        if module_request.context_messages:
            messages.extend(module_request.context_messages)
        elif self.has_template("module/%s/system" % module_request.module_name):
            messages.append(Message.from_content(self.render_template(
                "module/%s/system" % module_request.module_name,
                **module_request.template_params
            ), role='system'))
        messages.append(Message.from_content(self.render_template(
            "module/%s/user" % module_request.module_name,
            **module_request.template_params
        ), role='user', media_content=module_request.media_content))
        config = self.module_configs[module_request.module_name]
        if module_request.output_channel is not None:
            output_channel = module_request.output_channel
        else:
            output_channel = _channel.NullChannel()
        return LLMDirectRequest(
            model_name=(module_request.model_name or config.model),
            messages=messages,
            tools=(module_request.tools if module_request.tools is not None else config.tools),
            options=(module_request.options if module_request.options is not None else config.options),
            stream=(module_request.stream if module_request.stream is not None else config.stream),
            output_channel=output_channel,
            post_processor=(module_request.post_processor if module_request.post_processor is not None else config.post_processor),
        )

    async def _send_request(self, direct_request: LLMDirectRequest) -> LLMModuleResult:
        """直接发送LLM请求"""
        if direct_request.output_channel is not None:
            output_channel = direct_request.output_channel
        else:
            output_channel = _channel.NullChannel()
        model_name = direct_request.model_name
        if model_name in self.model_alias:
            model_name = self.model_alias[model_name]
        request = await self.client.request(
            model_name=model_name,
            messages=direct_request.messages,
            tools=direct_request.tools,
            options=direct_request.options,
            stream=direct_request.stream,
            context_id=self.context_id,
            output_channel=output_channel
        )
        response = await request.response
        return LLMModuleResult.from_response(direct_request, response)

    async def _post_process(
            self, result: LLMModuleResult,
            post_processor: Union[str, Callable[[str], Any], None],
            request: Union[LLMDirectRequest, LLMModuleRequest]
    ):
        if result.status == FinishReason.stop:
            if post_processor is not None:
                if isinstance(post_processor, str):
                    post_processor_fn = self.processors[post_processor]
                else:
                    post_processor_fn = post_processor
                try:
                    data = post_processor_fn(result.response_text)
                    if inspect.isawaitable(data):
                        result.data = await data
                    else:
                        result.data = data
                except Exception:
                    logger.exception("Post-process failed: %s", request)
                    result.status = FinishReason.error_format
            else:
                result.data = result.response_text
        return result

    async def call(self, request: Union[LLMModuleRequest, LLMDirectRequest]) -> LLMModuleResult:
        if isinstance(request, LLMModuleRequest):
            direct_req = self.render_direct_request(request)
        else:
            direct_req = request
        result = await self._send_request(direct_req)
        if isinstance(request, LLMModuleRequest):
            result.module_name = request.module_name
            result.request_params = request.template_params
        result = await self._post_process(result, direct_req.post_processor, request)
        return result

    @classmethod
    def factory(
            cls,
            client: _client.LLMClient,
            config_dict: Optional[Dict[str, Any]] = None,
            processors: Optional[Dict[str, Callable[[str], Any]]] = None
    ) -> Callable[..., 'LLMApplication']:
        """创建应用工厂函数"""
        return functools.partial(
            cls,
            client=client,
            config_dict=config_dict,
            processors=processors
        )

