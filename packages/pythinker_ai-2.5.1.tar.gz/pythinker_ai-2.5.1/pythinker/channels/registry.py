"""Auto-discovery for built-in channel modules and external plugins."""

from __future__ import annotations

import importlib
import pkgutil
from typing import TYPE_CHECKING

from loguru import logger

if TYPE_CHECKING:
    from pythinker.channels.base import BaseChannel

_INTERNAL = frozenset({"base", "manager", "registry"})


def discover_channel_names() -> list[str]:
    """Return all built-in channel module names by scanning the package (zero imports).

    Channels may be either flat modules (``pythinker/channels/telegram.py``) or
    packages (``pythinker/channels/websocket/``); the websocket carve-out moved
    one of the built-ins from the former shape into the latter, so we accept
    both ``ispkg`` cases here.
    """
    import pythinker.channels as pkg

    return [
        name
        for _, name, _ispkg in pkgutil.iter_modules(pkg.__path__)
        if name not in _INTERNAL
    ]


def load_channel_class(module_name: str) -> type[BaseChannel]:
    """Import *module_name* and return the first BaseChannel subclass found."""
    from pythinker.channels.base import BaseChannel as _Base

    mod = importlib.import_module(f"pythinker.channels.{module_name}")
    for attr in dir(mod):
        obj = getattr(mod, attr)
        if isinstance(obj, type) and issubclass(obj, _Base) and obj is not _Base:
            return obj
    raise ImportError(f"No BaseChannel subclass in pythinker.channels.{module_name}")


def discover_plugins() -> dict[str, type[BaseChannel]]:
    """Discover external channel plugins registered via entry_points."""
    from importlib.metadata import entry_points

    plugins: dict[str, type[BaseChannel]] = {}
    for ep in entry_points(group="pythinker.channels"):
        try:
            cls = ep.load()
            plugins[ep.name] = cls
        except Exception as e:
            logger.warning("Failed to load channel plugin '{}': {}", ep.name, e)
    return plugins


def discover_all() -> dict[str, type[BaseChannel]]:
    """Return all channels: built-in (pkgutil) merged with external (entry_points).

    Built-in channels take priority — an external plugin cannot shadow a built-in name.
    """
    builtin: dict[str, type[BaseChannel]] = {}
    for modname in discover_channel_names():
        try:
            builtin[modname] = load_channel_class(modname)
        except ImportError as e:
            logger.debug("Skipping built-in channel '{}': {}", modname, e)

    external = discover_plugins()
    shadowed = set(external) & set(builtin)
    if shadowed:
        logger.warning("Plugin(s) shadowed by built-in channels (ignored): {}", shadowed)

    return {**external, **builtin}


def get_channel_config_fields(name: str) -> dict[str, object] | None:
    """Return optional config workbench metadata exported by a channel module."""
    try:
        channel_cls = load_channel_class(name)
    except ImportError:
        return None
    module = importlib.import_module(channel_cls.__module__)
    metadata = getattr(module, "CONFIG_FIELDS", None)
    return metadata if isinstance(metadata, dict) else None
