"""Shared execution loop for tool-using agents."""

from __future__ import annotations

import asyncio
import inspect
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Protocol

from loguru import logger

from pythinker.agent.budget import BudgetPolicy
from pythinker.agent.hook import AgentHook, AgentHookContext
from pythinker.agent.tools.registry import ToolRegistry
from pythinker.providers.base import LLMProvider, LLMResponse, ToolCallRequest
from pythinker.utils.helpers import (
    build_assistant_message,
    estimate_message_tokens,
    estimate_prompt_tokens_chain,
    find_legal_message_start,
    maybe_persist_tool_result,
    truncate_text,
)
from pythinker.utils.prompt_templates import render_template
from pythinker.utils.runtime import (
    EMPTY_FINAL_RESPONSE_MESSAGE,
    build_finalization_retry_message,
    build_length_recovery_message,
    ensure_nonempty_tool_result,
    is_blank_text,
    repeated_external_lookup_error,
)

if TYPE_CHECKING:
    from pythinker.runtime.context import RequestContext


class EgressGateway(Protocol):
    """Structural type for the egress chokepoint AgentRunner routes through.

    Defining this here (instead of importing ToolEgressGateway directly)
    keeps the runner free of a runtime import on pythinker.runtime.* and
    avoids the import cycle (runtime.egress already imports
    agent.tools.registry). Any object with this method signature satisfies
    the contract — the production wiring uses ToolEgressGateway, tests
    can use a stub.

    Intentionally NOT @runtime_checkable. Static-only structural typing is
    enough here; isinstance(x, EgressGateway) checks would be slow (Protocol
    runtime checks scan every method) and would tempt callers into ad-hoc
    type narrowing instead of explicit None checks. If a future caller
    needs isinstance support, add `from typing import runtime_checkable`
    and decorate this class — and document the use case it enables.
    """

    async def execute(
        self,
        ctx: "RequestContext",
        name: str,
        params: dict[str, Any],
    ) -> Any: ...


_DEFAULT_ERROR_MESSAGE = "Sorry, I encountered an error calling the AI model."
_PERSISTED_MODEL_ERROR_PLACEHOLDER = "[Assistant reply unavailable due to model error.]"
_MAX_EMPTY_RETRIES = 2
_MAX_LENGTH_RECOVERIES = 3
_MAX_INJECTIONS_PER_TURN = 3
_MAX_INJECTION_CYCLES = 5
_SNIP_SAFETY_BUFFER = 1024
_MIN_SNIP_PROMPT_BUDGET = 128
_MICROCOMPACT_KEEP_RECENT = 10
_MICROCOMPACT_MIN_CHARS = 500
_BACKFILL_CONTENT = "[Tool result unavailable — call was interrupted or lost]"



@dataclass(slots=True)
class AgentRunSpec:
    """Configuration for a single agent execution."""

    initial_messages: list[dict[str, Any]]
    tools: ToolRegistry
    model: str
    max_iterations: int
    max_tool_result_chars: int
    temperature: float | None = None
    max_tokens: int | None = None
    reasoning_effort: str | None = None
    hook: AgentHook | None = None
    error_message: str | None = _DEFAULT_ERROR_MESSAGE
    max_iterations_message: str | None = None
    concurrent_tools: bool = False
    fail_on_tool_error: bool = False
    workspace: Path | None = None
    session_key: str | None = None
    context_window_tokens: int | None = None
    context_block_limit: int | None = None
    encoding: str = "cl100k_base"
    provider_retry_mode: str = "standard"
    progress_callback: Any | None = None
    retry_wait_callback: Any | None = None
    checkpoint_callback: Any | None = None
    injection_callback: Any | None = None
    llm_timeout_s: float | None = None
    # Governed-execution wiring. When `egress` is set, _run_tool uses
    # `egress.execute(request_context, name, params)` instead of
    # `tools.execute(name, params)`. `request_context` is required when
    # egress is set; both default to None to preserve legacy behaviour.
    egress: "EgressGateway | None" = None
    request_context: "RequestContext | None" = None
    # Phase 5 of `.agents/plans/2026-05-05-coding-prompt-uplift.md` — when
    # set, ``DynamicInjectionProvider.get_injections`` is consulted before
    # each LLM call and any results are woven into ``messages_for_model``
    # via ``apply_injections``. Default ``None`` keeps legacy behavior.
    dynamic_injection_provider: Any = None

    def __post_init__(self) -> None:
        # Governed-execution invariant: egress + request_context are wired
        # together. Setting egress without a context (or vice versa) would
        # silently bypass the chokepoint at dispatch time — fail loudly here.
        if (self.egress is None) != (self.request_context is None):
            raise ValueError(
                "AgentRunSpec.egress and AgentRunSpec.request_context must be set together; "
                f"got egress={'set' if self.egress is not None else 'None'}, "
                f"request_context={'set' if self.request_context is not None else 'None'}"
            )


@dataclass(slots=True)
class AgentRunResult:
    """Outcome of a shared agent execution."""

    final_content: str | None
    messages: list[dict[str, Any]]
    tools_used: list[str] = field(default_factory=list)
    usage: dict[str, int] = field(default_factory=dict)
    stop_reason: str = "completed"
    error: str | None = None
    tool_events: list[dict[str, str]] = field(default_factory=list)
    had_injections: bool = False


class AgentRunner:
    """Run a tool-capable LLM loop without product-layer concerns."""

    def __init__(self, provider: LLMProvider):
        self.provider = provider
        self._tool_is_compactable: Callable[[str], bool] = lambda _name: True
        self._last_context_stats: dict[str, int | bool] = {}

    def bind_tool_registry(self, registry: ToolRegistry) -> None:
        """Use a tool registry to decide whether results may be microcompacted."""
        def _lookup(name: str) -> bool:
            tool = registry.get(name)
            return bool(tool and getattr(tool, "compactable", True))

        self._tool_is_compactable = _lookup

    @staticmethod
    def _merge_message_content(left: Any, right: Any) -> str | list[dict[str, Any]]:
        if isinstance(left, str) and isinstance(right, str):
            return f"{left}\n\n{right}" if left else right

        def _to_blocks(value: Any) -> list[dict[str, Any]]:
            if isinstance(value, list):
                return [
                    item if isinstance(item, dict) else {"type": "text", "text": str(item)}
                    for item in value
                ]
            if value is None:
                return []
            return [{"type": "text", "text": str(value)}]

        return _to_blocks(left) + _to_blocks(right)

    @classmethod
    def _append_injected_messages(
        cls,
        messages: list[dict[str, Any]],
        injections: list[dict[str, Any]],
    ) -> None:
        """Append injected user messages while preserving role alternation."""
        for injection in injections:
            if (
                messages
                and injection.get("role") == "user"
                and messages[-1].get("role") == "user"
            ):
                merged = dict(messages[-1])
                merged["content"] = cls._merge_message_content(
                    merged.get("content"),
                    injection.get("content"),
                )
                messages[-1] = merged
                continue
            messages.append(injection)

    async def _try_drain_injections(
        self,
        spec: AgentRunSpec,
        messages: list[dict[str, Any]],
        assistant_message: dict[str, Any] | None,
        injection_cycles: int,
        *,
        phase: str = "after error",
        iteration: int | None = None,
    ) -> tuple[bool, int]:
        """Drain pending injections. Returns (should_continue, updated_cycles).

        If injections are found and we haven't exceeded _MAX_INJECTION_CYCLES,
        append them to *messages* (and emit a checkpoint if *assistant_message*
        and *iteration* are both provided) and return (True, cycles+1) so the
        caller continues the iteration loop.  Otherwise return (False, cycles).
        """
        if injection_cycles >= _MAX_INJECTION_CYCLES:
            return False, injection_cycles
        injections = await self._drain_injections(spec)
        if not injections:
            return False, injection_cycles
        injection_cycles += 1
        if assistant_message is not None:
            messages.append(assistant_message)
            if iteration is not None:
                await self._emit_checkpoint(
                    spec,
                    {
                        "phase": "final_response",
                        "iteration": iteration,
                        "model": spec.model,
                        "assistant_message": assistant_message,
                        "completed_tool_results": [],
                        "pending_tool_calls": [],
                    },
                )
        self._append_injected_messages(messages, injections)
        logger.info(
            "Injected {} follow-up message(s) {} ({}/{})",
            len(injections), phase, injection_cycles, _MAX_INJECTION_CYCLES,
        )
        return True, injection_cycles

    async def _drain_injections(self, spec: AgentRunSpec) -> list[dict[str, Any]]:
        """Drain pending user messages via the injection callback.

        Returns normalized user messages (capped by
        ``_MAX_INJECTIONS_PER_TURN``), or an empty list when there is
        nothing to inject. Messages beyond the cap are logged so they
        are not silently lost.
        """
        if spec.injection_callback is None:
            return []
        try:
            signature = inspect.signature(spec.injection_callback)
            accepts_limit = (
                "limit" in signature.parameters
                or any(
                    parameter.kind is inspect.Parameter.VAR_KEYWORD
                    for parameter in signature.parameters.values()
                )
            )
            if accepts_limit:
                items = await spec.injection_callback(limit=_MAX_INJECTIONS_PER_TURN)
            else:
                items = await spec.injection_callback()
        except Exception:
            logger.exception("injection_callback failed")
            return []
        if not items:
            return []
        injected_messages: list[dict[str, Any]] = []
        for item in items:
            if isinstance(item, dict) and item.get("role") == "user" and "content" in item:
                injected_messages.append(item)
                continue
            text = getattr(item, "content", str(item))
            if text.strip():
                injected_messages.append({"role": "user", "content": text})
        if len(injected_messages) > _MAX_INJECTIONS_PER_TURN:
            dropped = len(injected_messages) - _MAX_INJECTIONS_PER_TURN
            logger.warning(
                "Injection callback returned {} messages, capping to {} ({} dropped)",
                len(injected_messages), _MAX_INJECTIONS_PER_TURN, dropped,
            )
            injected_messages = injected_messages[:_MAX_INJECTIONS_PER_TURN]
        return injected_messages

    async def run(self, spec: AgentRunSpec) -> AgentRunResult:
        hook = spec.hook or AgentHook()
        messages = list(spec.initial_messages)
        final_content: str | None = None
        tools_used: list[str] = []
        usage: dict[str, int] = {"prompt_tokens": 0, "completion_tokens": 0}
        error: str | None = None
        stop_reason = "completed"
        tool_events: list[dict[str, str]] = []
        external_lookup_counts: dict[str, int] = {}
        empty_content_retries = 0
        length_recovery_count = 0
        had_injections = False
        injection_cycles = 0

        for iteration in range(spec.max_iterations):
            messages_for_model = self._prepare_messages_for_model(spec, messages, iteration)
            messages_for_model = self._apply_dynamic_injections(
                spec, messages_for_model, iteration,
            )
            context = AgentHookContext(iteration=iteration, messages=messages)
            await hook.before_iteration(context)
            response = await self._request_model(spec, messages_for_model, hook, context)
            raw_usage = self._usage_dict(response.usage)
            context.response = response
            context.usage = dict(raw_usage)
            context.tool_calls = list(response.tool_calls)
            self._accumulate_usage(usage, raw_usage)

            if response.should_execute_tools:
                action, injection_cycles, drained, reset_retry_counters, terminal = (
                    await self._handle_tool_iteration(
                        spec,
                        hook,
                        context,
                        response,
                        iteration,
                        messages,
                        tools_used,
                        tool_events,
                        external_lookup_counts,
                        injection_cycles,
                    )
                )
                if drained:
                    had_injections = True
                if reset_retry_counters:
                    empty_content_retries = 0
                    length_recovery_count = 0
                if terminal is not None:
                    final_content, error, stop_reason = terminal
                if action == "continue":
                    continue
                break

            if response.has_tool_calls:
                logger.warning(
                    "Ignoring tool calls under finish_reason='{}' for {}",
                    response.finish_reason,
                    spec.session_key or "default",
                )

            clean = hook.finalize_content(context, response.content)
            if response.finish_reason != "error" and is_blank_text(clean):
                empty_content_retries += 1
                if empty_content_retries < _MAX_EMPTY_RETRIES:
                    logger.warning(
                        "Empty response on turn {} for {} ({}/{}); retrying",
                        iteration,
                        spec.session_key or "default",
                        empty_content_retries,
                        _MAX_EMPTY_RETRIES,
                    )
                    if hook.wants_streaming():
                        await hook.on_stream_end(context, resuming=False)
                    await hook.after_iteration(context)
                    continue
                logger.warning(
                    "Empty response on turn {} for {} after {} retries; attempting finalization",
                    iteration,
                    spec.session_key or "default",
                    empty_content_retries,
                )
                if hook.wants_streaming():
                    await hook.on_stream_end(context, resuming=False)
                response = await self._request_finalization_retry(spec, messages_for_model)
                retry_usage = self._usage_dict(response.usage)
                self._accumulate_usage(usage, retry_usage)
                raw_usage = self._merge_usage(raw_usage, retry_usage)
                context.response = response
                context.usage = dict(raw_usage)
                context.tool_calls = list(response.tool_calls)
                clean = hook.finalize_content(context, response.content)

            if response.finish_reason == "length" and not is_blank_text(clean):
                length_recovery_count += 1
                if length_recovery_count <= _MAX_LENGTH_RECOVERIES:
                    logger.info(
                        "Output truncated on turn {} for {} ({}/{}); continuing",
                        iteration,
                        spec.session_key or "default",
                        length_recovery_count,
                        _MAX_LENGTH_RECOVERIES,
                    )
                    if hook.wants_streaming():
                        await hook.on_stream_end(context, resuming=True)
                    messages.append(build_assistant_message(
                        clean,
                        reasoning_content=response.reasoning_content,
                        thinking_blocks=response.thinking_blocks,
                    ))
                    messages.append(build_length_recovery_message())
                    await hook.after_iteration(context)
                    continue

            assistant_message: dict[str, Any] | None = None
            if response.finish_reason != "error" and not is_blank_text(clean):
                assistant_message = build_assistant_message(
                    clean,
                    reasoning_content=response.reasoning_content,
                    thinking_blocks=response.thinking_blocks,
                )

            # Check for mid-turn injections BEFORE signaling stream end.
            # If injections are found we keep the stream alive (resuming=True)
            # so streaming channels don't prematurely finalize the card.
            should_continue, injection_cycles = await self._try_drain_injections(
                spec, messages, assistant_message, injection_cycles,
                phase="after final response",
                iteration=iteration,
            )
            if should_continue:
                had_injections = True

            if hook.wants_streaming():
                await hook.on_stream_end(context, resuming=should_continue)

            if should_continue:
                await hook.after_iteration(context)
                continue

            if response.finish_reason == "error":
                final_content = clean or spec.error_message or _DEFAULT_ERROR_MESSAGE
                stop_reason = "error"
                error = final_content
                self._append_model_error_placeholder(messages)
                context.final_content = final_content
                context.error = error
                context.stop_reason = stop_reason
                await hook.after_iteration(context)
                should_continue, injection_cycles = await self._try_drain_injections(
                    spec, messages, None, injection_cycles,
                    phase="after LLM error",
                )
                if should_continue:
                    had_injections = True
                    continue
                break
            if is_blank_text(clean):
                final_content = EMPTY_FINAL_RESPONSE_MESSAGE
                stop_reason = "empty_final_response"
                error = final_content
                self._append_final_message(messages, final_content)
                context.final_content = final_content
                context.error = error
                context.stop_reason = stop_reason
                await hook.after_iteration(context)
                should_continue, injection_cycles = await self._try_drain_injections(
                    spec, messages, None, injection_cycles,
                    phase="after empty response",
                )
                if should_continue:
                    had_injections = True
                    continue
                break

            messages.append(assistant_message or build_assistant_message(
                clean,
                reasoning_content=response.reasoning_content,
                thinking_blocks=response.thinking_blocks,
            ))
            await self._emit_checkpoint(
                spec,
                {
                    "phase": "final_response",
                    "iteration": iteration,
                    "model": spec.model,
                    "assistant_message": messages[-1],
                    "completed_tool_results": [],
                    "pending_tool_calls": [],
                },
            )
            final_content = clean
            context.final_content = final_content
            context.stop_reason = stop_reason
            await hook.after_iteration(context)
            break
        else:
            stop_reason = "max_iterations"
            final_content = self._resolve_max_iterations_message(spec)
            self._append_final_message(messages, final_content)
            # Drain any remaining injections so they are appended to the
            # conversation history instead of being re-published as
            # independent inbound messages by _dispatch's finally block.
            # We ignore should_continue here because the for-loop has already
            # exhausted all iterations.
            drained_after_max_iterations, injection_cycles = await self._try_drain_injections(
                spec, messages, None, injection_cycles,
                phase="after max_iterations",
            )
            if drained_after_max_iterations:
                had_injections = True

        usage.update(self._last_context_stats)
        usage.setdefault("prompt_est", 0)
        return AgentRunResult(
            final_content=final_content,
            messages=messages,
            tools_used=tools_used,
            usage=usage,
            stop_reason=stop_reason,
            error=error,
            tool_events=tool_events,
            had_injections=had_injections,
        )

    def _build_request_kwargs(
        self,
        spec: AgentRunSpec,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None,
    ) -> dict[str, Any]:
        kwargs: dict[str, Any] = {
            "messages": messages,
            "tools": tools,
            "model": spec.model,
            "retry_mode": spec.provider_retry_mode,
            "on_retry_wait": spec.retry_wait_callback,
        }
        if spec.temperature is not None:
            kwargs["temperature"] = spec.temperature
        if spec.max_tokens is not None:
            kwargs["max_tokens"] = spec.max_tokens
        if spec.reasoning_effort is not None:
            kwargs["reasoning_effort"] = spec.reasoning_effort
        return kwargs

    def _apply_dynamic_injections(
        self,
        spec: AgentRunSpec,
        messages_for_model: list[dict[str, Any]],
        iteration: int,
    ) -> list[dict[str, Any]]:
        """Phase 5 hook: prepend / append dynamic-injection content if a provider is wired.

        Default ``None`` provider returns the input unchanged so legacy
        behavior is preserved. Any exception in the provider drops the
        injection and lets the turn proceed — a buggy injector must not
        break the turn.
        """
        provider = spec.dynamic_injection_provider
        if provider is None:
            return messages_for_model
        try:
            from pythinker.agent.dynamic_injection import apply_injections

            injections = provider.get_injections(
                messages_for_model,
                iteration=iteration,
                session_key=spec.session_key,
            )
        except Exception as exc:
            logger.warning(
                "Dynamic-injection provider raised on turn {} for {}: {}; "
                "continuing without injections",
                iteration,
                spec.session_key or "default",
                exc,
            )
            return messages_for_model
        return apply_injections(messages_for_model, injections or [])

    def _prepare_messages_for_model(
        self,
        spec: AgentRunSpec,
        messages: list[dict[str, Any]],
        iteration: int,
    ) -> list[dict[str, Any]]:
        """Apply context governance for the next provider call.

        Keep the persisted conversation untouched. Context governance may
        repair or compact historical messages for the model, but those
        synthetic edits must not shift the append boundary used later when
        the caller saves only the new turn. On any governance failure, fall
        back to a minimal repair (orphan-drop + backfill); if even that
        fails, return the raw messages.
        """
        try:
            messages_for_model = self._drop_orphan_tool_results(messages)
            messages_for_model = self._backfill_missing_tool_results(messages_for_model)
            messages_for_model = self._microcompact(messages_for_model)
            microcompact_count = sum(
                1 for msg in messages_for_model
                if isinstance(msg.get("content"), str)
                and "result omitted" in msg["content"]
            )
            messages_for_model = self._apply_tool_result_budget(spec, messages_for_model)
            before_snip_len = len(messages_for_model)
            messages_for_model = self._snip_history(spec, messages_for_model)
            self._last_context_stats = {
                "microcompact_count": microcompact_count,
                "snip_fired": len(messages_for_model) < before_snip_len,
            }
            # Snipping may have created new orphans; clean them up.
            messages_for_model = self._drop_orphan_tool_results(messages_for_model)
            messages_for_model = self._backfill_missing_tool_results(messages_for_model)
            return messages_for_model
        except Exception as exc:
            logger.warning(
                "Context governance failed on turn {} for {}: {}; applying minimal repair",
                iteration,
                spec.session_key or "default",
                exc,
            )
            try:
                messages_for_model = self._drop_orphan_tool_results(messages)
                return self._backfill_missing_tool_results(messages_for_model)
            except Exception:
                return messages

    @staticmethod
    def _resolve_max_iterations_message(spec: AgentRunSpec) -> str:
        """Pick the max-iterations message — caller-supplied or default template."""
        if spec.max_iterations_message:
            return spec.max_iterations_message.format(max_iterations=spec.max_iterations)
        return render_template(
            "agent/max_iterations_message.md",
            strip=True,
            max_iterations=spec.max_iterations,
        )

    async def _handle_tool_iteration(
        self,
        spec: AgentRunSpec,
        hook: AgentHook,
        context: AgentHookContext,
        response: LLMResponse,
        iteration: int,
        messages: list[dict[str, Any]],
        tools_used: list[str],
        tool_events: list[dict[str, str]],
        external_lookup_counts: dict[str, int],
        injection_cycles: int,
    ) -> tuple[
        str,
        int,
        bool,
        bool,
        tuple[str | None, str | None, str] | None,
    ]:
        """Run the tool-execution branch of one iteration.

        Returns ``(action, injection_cycles, drained, reset_retry_counters,
        terminal)``:

        - ``action`` is ``"continue"`` or ``"break"`` — the orchestrator
          performs the actual loop control so the for/else on
          ``run()``'s outer loop stays intact.
        - ``injection_cycles`` is the updated counter.
        - ``drained`` is True when any injection cycle ran in this branch
          (so the orchestrator can flip ``had_injections``).
        - ``reset_retry_counters`` is True on the tool-success path; it
          tells the orchestrator to clear ``empty_content_retries`` and
          ``length_recovery_count`` (which only this branch resets).
        - ``terminal`` is ``(final_content, error, stop_reason)`` on a
          fatal-tool-error exit, otherwise ``None``.

        Mutates ``messages``, ``tools_used``, ``tool_events``, and
        ``external_lookup_counts`` in place — same lifecycle as the
        original inline block.
        """
        if hook.wants_streaming():
            await hook.on_stream_end(context, resuming=True)

        assistant_message = build_assistant_message(
            response.content or "",
            tool_calls=[tc.to_openai_tool_call() for tc in response.tool_calls],
            reasoning_content=response.reasoning_content,
            thinking_blocks=response.thinking_blocks,
        )
        messages.append(assistant_message)
        tools_used.extend(tc.name for tc in response.tool_calls)
        await self._emit_checkpoint(
            spec,
            {
                "phase": "awaiting_tools",
                "iteration": iteration,
                "model": spec.model,
                "assistant_message": assistant_message,
                "completed_tool_results": [],
                "pending_tool_calls": [tc.to_openai_tool_call() for tc in response.tool_calls],
            },
        )

        await hook.before_execute_tools(context)

        results, new_events, fatal_error = await self._execute_tools(
            spec,
            response.tool_calls,
            external_lookup_counts,
        )
        tool_events.extend(new_events)
        context.tool_results = list(results)
        context.tool_events = list(new_events)
        await hook.after_execute_tools(context, list(results))
        completed_tool_results: list[dict[str, Any]] = []
        for tool_call, result in zip(response.tool_calls, results):
            tool_message = {
                "role": "tool",
                "tool_call_id": tool_call.id,
                "name": tool_call.name,
                "content": self._normalize_tool_result(
                    spec,
                    tool_call.id,
                    tool_call.name,
                    result,
                ),
            }
            messages.append(tool_message)
            completed_tool_results.append(tool_message)
        if fatal_error is not None:
            error = f"Error: {type(fatal_error).__name__}: {fatal_error}"
            final_content = error
            stop_reason = "tool_error"
            self._append_final_message(messages, final_content)
            context.final_content = final_content
            context.error = error
            context.stop_reason = stop_reason
            await hook.after_iteration(context)
            should_continue, injection_cycles = await self._try_drain_injections(
                spec, messages, None, injection_cycles,
                phase="after tool error",
            )
            terminal = (final_content, error, stop_reason)
            if should_continue:
                return "continue", injection_cycles, True, False, terminal
            return "break", injection_cycles, False, False, terminal

        await self._emit_checkpoint(
            spec,
            {
                "phase": "tools_completed",
                "iteration": iteration,
                "model": spec.model,
                "assistant_message": assistant_message,
                "completed_tool_results": completed_tool_results,
                "pending_tool_calls": [],
            },
        )
        # Checkpoint 1: drain injections after tools, before next LLM call
        drained, injection_cycles = await self._try_drain_injections(
            spec, messages, None, injection_cycles,
            phase="after tool execution",
        )
        await hook.after_iteration(context)
        return "continue", injection_cycles, drained, True, None

    async def _request_model(
        self,
        spec: AgentRunSpec,
        messages: list[dict[str, Any]],
        hook: AgentHook,
        context: AgentHookContext,
    ):
        timeout_s: float | None = spec.llm_timeout_s
        if timeout_s is None:
            # Default to a finite timeout to avoid per-session lock starvation when an LLM
            # request hangs indefinitely (e.g. gateway/network stall).
            # Set PYTHINKER_LLM_TIMEOUT_S=0 to disable.
            raw = os.environ.get("PYTHINKER_LLM_TIMEOUT_S", "300").strip()
            try:
                timeout_s = float(raw)
            except (TypeError, ValueError):
                timeout_s = 300.0
        if timeout_s is not None and timeout_s <= 0:
            timeout_s = None

        kwargs = self._build_request_kwargs(
            spec,
            messages,
            tools=spec.tools.get_definitions(),
        )
        if hook.wants_streaming():
            async def _stream(delta: str) -> None:
                await hook.on_stream(context, delta)

            coro = self.provider.chat_stream_with_retry(
                **kwargs,
                on_content_delta=_stream,
            )
        else:
            coro = self.provider.chat_with_retry(**kwargs)

        if timeout_s is None:
            return await coro
        try:
            return await asyncio.wait_for(coro, timeout=timeout_s)
        except asyncio.TimeoutError:
            return LLMResponse(
                content=f"Error calling LLM: timed out after {timeout_s:g}s",
                finish_reason="error",
                error_kind="timeout",
            )

    async def _request_finalization_retry(
        self,
        spec: AgentRunSpec,
        messages: list[dict[str, Any]],
    ):
        retry_messages = list(messages)
        retry_messages.append(build_finalization_retry_message())
        kwargs = self._build_request_kwargs(spec, retry_messages, tools=None)
        return await self.provider.chat_with_retry(**kwargs)

    @staticmethod
    def _usage_dict(usage: dict[str, Any] | None) -> dict[str, int]:
        if not usage:
            return {}
        result: dict[str, int] = {}
        for key, value in usage.items():
            try:
                result[key] = int(value or 0)
            except (TypeError, ValueError):
                continue
        return result

    @staticmethod
    def _accumulate_usage(target: dict[str, int], addition: dict[str, int]) -> None:
        for key, value in addition.items():
            target[key] = target.get(key, 0) + value

    @staticmethod
    def _merge_usage(left: dict[str, int], right: dict[str, int]) -> dict[str, int]:
        merged = dict(left)
        for key, value in right.items():
            merged[key] = merged.get(key, 0) + value
        return merged

    async def _execute_tools(
        self,
        spec: AgentRunSpec,
        tool_calls: list[ToolCallRequest],
        external_lookup_counts: dict[str, int],
    ) -> tuple[list[Any], list[dict[str, str]], BaseException | None]:
        batches = self._partition_tool_batches(spec, tool_calls)
        tool_results: list[tuple[Any, dict[str, str], BaseException | None]] = []
        for batch in batches:
            if spec.concurrent_tools and len(batch) > 1:
                tool_results.extend(await asyncio.gather(*(
                    self._run_tool(spec, tool_call, external_lookup_counts)
                    for tool_call in batch
                )))
            else:
                for tool_call in batch:
                    tool_results.append(await self._run_tool(spec, tool_call, external_lookup_counts))

        results: list[Any] = []
        events: list[dict[str, str]] = []
        fatal_error: BaseException | None = None
        for result, event, error in tool_results:
            results.append(result)
            events.append(event)
            if error is not None and fatal_error is None:
                fatal_error = error
        return results, events, fatal_error

    async def _run_tool(
        self,
        spec: AgentRunSpec,
        tool_call: ToolCallRequest,
        external_lookup_counts: dict[str, int],
    ) -> tuple[Any, dict[str, str], BaseException | None]:
        hint = "\n\n[Analyze the error above and try a different approach.]"
        lookup_error = repeated_external_lookup_error(
            tool_call.name,
            tool_call.arguments,
            external_lookup_counts,
        )
        if lookup_error:
            event = {
                "name": tool_call.name,
                "status": "error",
                "detail": "repeated external lookup blocked",
            }
            if spec.fail_on_tool_error:
                return lookup_error + hint, event, RuntimeError(lookup_error)
            return lookup_error + hint, event, None
        prepare_call = getattr(spec.tools, "prepare_call", None)
        tool, params, prep_error = None, tool_call.arguments, None
        if spec.egress is None and callable(prepare_call):
            try:
                prepared = prepare_call(tool_call.name, tool_call.arguments)
                if isinstance(prepared, tuple) and len(prepared) == 3:
                    tool, params, prep_error = prepared
            except Exception:
                pass
        if spec.egress is None and prep_error:
            event = {
                "name": tool_call.name,
                "status": "error",
                "detail": prep_error.split(": ", 1)[-1][:120],
            }
            return prep_error + hint, event, RuntimeError(prep_error) if spec.fail_on_tool_error else None
        try:
            if spec.egress is not None and spec.request_context is not None:
                # Egress is the single chokepoint. Pass raw args; ToolRegistry.execute()
                # (called inside ToolEgressGateway.execute) handles cast/validate/error
                # hints exactly as before.
                result = await spec.egress.execute(
                    spec.request_context, tool_call.name, tool_call.arguments,
                )
            elif tool is not None:
                result = await tool.execute(**params)
            else:
                result = await spec.tools.execute(tool_call.name, params)
        except asyncio.CancelledError:
            raise
        except BaseException as exc:
            event = {
                "name": tool_call.name,
                "status": "error",
                "detail": str(exc),
            }
            if spec.fail_on_tool_error:
                return f"Error: {type(exc).__name__}: {exc}", event, exc
            return f"Error: {type(exc).__name__}: {exc}", event, None

        if isinstance(result, str) and result.startswith("Error"):
            event = {
                "name": tool_call.name,
                "status": "error",
                "detail": result.replace("\n", " ").strip()[:120],
            }
            if spec.fail_on_tool_error:
                return result + hint, event, RuntimeError(result)
            return result + hint, event, None

        detail = "" if result is None else str(result)
        detail = detail.replace("\n", " ").strip()
        if not detail:
            detail = "(empty)"
        elif len(detail) > 120:
            detail = detail[:120] + "..."
        return result, {"name": tool_call.name, "status": "ok", "detail": detail}, None

    async def _emit_checkpoint(
        self,
        spec: AgentRunSpec,
        payload: dict[str, Any],
    ) -> None:
        callback = spec.checkpoint_callback
        if callback is not None:
            await callback(payload)

    @staticmethod
    def _append_final_message(messages: list[dict[str, Any]], content: str | None) -> None:
        if not content:
            return
        if (
            messages
            and messages[-1].get("role") == "assistant"
            and not messages[-1].get("tool_calls")
        ):
            if messages[-1].get("content") == content:
                return
            messages[-1] = build_assistant_message(content)
            return
        messages.append(build_assistant_message(content))

    @staticmethod
    def _append_model_error_placeholder(messages: list[dict[str, Any]]) -> None:
        if messages and messages[-1].get("role") == "assistant" and not messages[-1].get("tool_calls"):
            return
        messages.append(build_assistant_message(_PERSISTED_MODEL_ERROR_PLACEHOLDER))

    def _normalize_tool_result(
        self,
        spec: AgentRunSpec,
        tool_call_id: str,
        tool_name: str,
        result: Any,
    ) -> Any:
        result = ensure_nonempty_tool_result(tool_name, result)
        try:
            content = maybe_persist_tool_result(
                spec.workspace,
                spec.session_key,
                tool_call_id,
                result,
                max_chars=spec.max_tool_result_chars,
            )
        except Exception as exc:
            logger.warning(
                "Tool result persist failed for {} in {}: {}; using raw result",
                tool_call_id,
                spec.session_key or "default",
                exc,
            )
            content = result
        if isinstance(content, str) and len(content) > spec.max_tool_result_chars:
            return truncate_text(content, spec.max_tool_result_chars)
        return content

    @staticmethod
    def _drop_orphan_tool_results(
        messages: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Drop tool results that have no matching assistant tool_call earlier in the history."""
        declared: set[str] = set()
        updated: list[dict[str, Any]] | None = None
        for idx, msg in enumerate(messages):
            role = msg.get("role")
            if role == "assistant":
                for tc in msg.get("tool_calls") or []:
                    if isinstance(tc, dict) and tc.get("id"):
                        declared.add(str(tc["id"]))
            if role == "tool":
                tid = msg.get("tool_call_id")
                if tid and str(tid) not in declared:
                    if updated is None:
                        updated = [dict(m) for m in messages[:idx]]
                    continue
            if updated is not None:
                updated.append(dict(msg))

        if updated is None:
            return messages
        return updated

    @staticmethod
    def _backfill_missing_tool_results(
        messages: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Insert synthetic error results for orphaned tool_use blocks."""
        declared: list[tuple[int, str, str]] = []  # (assistant_idx, call_id, name)
        fulfilled: set[str] = set()
        for idx, msg in enumerate(messages):
            role = msg.get("role")
            if role == "assistant":
                for tc in msg.get("tool_calls") or []:
                    if isinstance(tc, dict) and tc.get("id"):
                        name = ""
                        func = tc.get("function")
                        if isinstance(func, dict):
                            name = func.get("name", "")
                        declared.append((idx, str(tc["id"]), name))
            elif role == "tool":
                tid = msg.get("tool_call_id")
                if tid:
                    fulfilled.add(str(tid))

        missing = [(ai, cid, name) for ai, cid, name in declared if cid not in fulfilled]
        if not missing:
            return messages

        updated = list(messages)
        offset = 0
        for assistant_idx, call_id, name in missing:
            insert_at = assistant_idx + 1 + offset
            while insert_at < len(updated) and updated[insert_at].get("role") == "tool":
                insert_at += 1
            updated.insert(insert_at, {
                "role": "tool",
                "tool_call_id": call_id,
                "name": name,
                "content": _BACKFILL_CONTENT,
            })
            offset += 1
        return updated

    def _tool_is_compactable_default(self, name: str) -> bool:
        return True

    @staticmethod
    def _microcompact_with_filter(
        messages: list[dict[str, Any]],
        is_compactable: Callable[[str], bool],
    ) -> list[dict[str, Any]]:
        """Replace old compactable tool results with one-line summaries."""
        compactable_indices: list[int] = []
        for idx, msg in enumerate(messages):
            if msg.get("role") != "tool":
                continue
            if is_compactable(str(msg.get("name", ""))):
                compactable_indices.append(idx)

        if len(compactable_indices) <= _MICROCOMPACT_KEEP_RECENT:
            return messages

        stale = compactable_indices[: len(compactable_indices) - _MICROCOMPACT_KEEP_RECENT]
        updated: list[dict[str, Any]] | None = None
        for idx in stale:
            msg = messages[idx]
            content = msg.get("content")
            if not isinstance(content, str) or len(content) < _MICROCOMPACT_MIN_CHARS:
                continue
            name = msg.get("name", "tool")
            summary = f"[{name} result omitted from context]"
            if updated is None:
                updated = [dict(m) for m in messages]
            updated[idx]["content"] = summary

        return updated if updated is not None else messages

    def _microcompact(self, messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        return self._microcompact_with_filter(messages, self._tool_is_compactable)

    def _apply_tool_result_budget(
        self,
        spec: AgentRunSpec,
        messages: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        updated = messages
        for idx, message in enumerate(messages):
            if message.get("role") != "tool":
                continue
            normalized = self._normalize_tool_result(
                spec,
                str(message.get("tool_call_id") or f"tool_{idx}"),
                str(message.get("name") or "tool"),
                message.get("content"),
            )
            if normalized != message.get("content"):
                if updated is messages:
                    updated = [dict(m) for m in messages]
                updated[idx]["content"] = normalized
        return updated

    @staticmethod
    def _truncate_text_to_token_budget(text: str, token_count: int, token_budget: int) -> str:
        marker = "\n... (truncated to fit context window)"
        if token_budget <= 0:
            return "[system prompt truncated to fit context window]"
        if token_count <= token_budget:
            return text
        max_chars = int(len(text) * (token_budget / max(token_count, 1))) - len(marker)
        if max_chars <= 0:
            return "[system prompt truncated to fit context window]"
        return text[:max_chars] + marker

    @classmethod
    def _fit_system_messages(
        cls,
        system_messages: list[dict[str, Any]],
        token_budget: int,
    ) -> list[dict[str, Any]]:
        if not system_messages:
            return system_messages
        remaining = token_budget
        fitted: list[dict[str, Any]] = []
        for message in system_messages:
            msg_tokens = estimate_message_tokens(message)
            if msg_tokens <= remaining:
                fitted.append(message)
                remaining -= msg_tokens
                continue
            content = message.get("content")
            if isinstance(content, str):
                trimmed = dict(message)
                trimmed["content"] = cls._truncate_text_to_token_budget(
                    content,
                    msg_tokens,
                    remaining,
                )
                fitted.append(trimmed)
            elif not fitted:
                fitted.append(message)
            break
        return fitted

    def _snip_history(
        self,
        spec: AgentRunSpec,
        messages: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        if not messages or not spec.context_window_tokens:
            return messages

        provider_max_tokens = getattr(getattr(self.provider, "generation", None), "max_tokens", 4096)
        max_output = spec.max_tokens if isinstance(spec.max_tokens, int) else (
            provider_max_tokens if isinstance(provider_max_tokens, int) else 4096
        )
        policy = BudgetPolicy.for_model(
            window=spec.context_window_tokens,
            output_reserve=max_output,
        )
        budget = spec.context_block_limit or policy.hard
        budget = max(_MIN_SNIP_PROMPT_BUDGET, budget)

        estimate, _ = estimate_prompt_tokens_chain(
            self.provider,
            spec.model,
            messages,
            spec.tools.get_definitions(),
            encoding=spec.encoding,
        )
        if estimate <= budget:
            return messages

        system_messages = [dict(msg) for msg in messages if msg.get("role") == "system"]
        non_system = [dict(msg) for msg in messages if msg.get("role") != "system"]
        if not non_system:
            return messages

        system_tokens = sum(estimate_message_tokens(msg) for msg in system_messages)
        remaining_budget = max(128, budget - system_tokens)
        kept: list[dict[str, Any]] = []
        kept_tokens = 0
        for message in reversed(non_system):
            msg_tokens = estimate_message_tokens(message)
            if kept and kept_tokens + msg_tokens > remaining_budget:
                break
            kept.append(message)
            kept_tokens += msg_tokens
        kept.reverse()

        if kept:
            for i, message in enumerate(kept):
                if message.get("role") == "user":
                    kept = kept[i:]
                    break
            else:
                # Recover nearest user message from outside the kept window;
                # GLM rejects system→assistant (error 1214).  Budget is
                # intentionally exceeded — oversized beats invalid.
                for idx in range(len(non_system) - 1, -1, -1):
                    if non_system[idx].get("role") == "user":
                        kept = non_system[idx:]
                        break
                # If no user exists at all, _enforce_role_alternation
                # will insert a synthetic one as a safety net.
            start = find_legal_message_start(kept)
            if start:
                kept = kept[start:]
        if not kept:
            kept = non_system[-min(len(non_system), 4) :]
            start = find_legal_message_start(kept)
            if start:
                kept = kept[start:]
        kept_tokens = sum(estimate_message_tokens(msg) for msg in kept)
        system_budget = max(_MIN_SNIP_PROMPT_BUDGET, budget - kept_tokens)
        system_messages = self._fit_system_messages(system_messages, system_budget)
        return system_messages + kept

    def _partition_tool_batches(
        self,
        spec: AgentRunSpec,
        tool_calls: list[ToolCallRequest],
    ) -> list[list[ToolCallRequest]]:
        if not spec.concurrent_tools:
            return [[tool_call] for tool_call in tool_calls]

        batches: list[list[ToolCallRequest]] = []
        current: list[ToolCallRequest] = []
        for tool_call in tool_calls:
            get_tool = getattr(spec.tools, "get", None)
            tool = get_tool(tool_call.name) if callable(get_tool) else None
            can_batch = bool(tool and tool.concurrency_safe)
            if can_batch:
                current.append(tool_call)
                continue
            if current:
                batches.append(current)
                current = []
            batches.append([tool_call])
        if current:
            batches.append(current)
        return batches
