#!/usr/bin/env node
/**
 * pythinker WhatsApp Bridge
 * 
 * This bridge connects WhatsApp Web to pythinker's Python backend
 * via WebSocket. It handles authentication, message forwarding,
 * and reconnection logic.
 * 
 * Usage:
 *   npm run build && npm start
 *   
 * Or with custom settings:
 *   BRIDGE_PORT=3001 AUTH_DIR=~/.pythinker/whatsapp npm start
 *
 * To avoid the large terminal QR code, provide a digits-only phone number:
 *   WHATSAPP_PAIRING_PHONE=15551234567 npm start
 */

// Polyfill crypto for Baileys in ESM
import { webcrypto } from 'crypto';
if (!globalThis.crypto) {
  (globalThis as any).crypto = webcrypto;
}

import { BridgeServer } from './server.js';
import { homedir } from 'os';
import { join } from 'path';

const PORT = parseInt(process.env.BRIDGE_PORT || '3001', 10);
const AUTH_DIR = process.env.AUTH_DIR || join(homedir(), '.pythinker', 'whatsapp-auth');
const TOKEN = process.env.BRIDGE_TOKEN?.trim();
const PAIRING_PHONE = process.env.WHATSAPP_PAIRING_PHONE?.replace(/\D/g, '') || undefined;

const parsePositiveInt = (raw: string | undefined): number | undefined => {
  if (!raw) return undefined;
  const n = parseInt(raw, 10);
  return Number.isFinite(n) && n > 0 ? n : undefined;
};

const TUNING = {
  keepAliveIntervalMs: parsePositiveInt(process.env.BRIDGE_KEEPALIVE_MS),
  connectTimeoutMs: parsePositiveInt(process.env.BRIDGE_CONNECT_TIMEOUT_MS),
  defaultQueryTimeoutMs: parsePositiveInt(process.env.BRIDGE_QUERY_TIMEOUT_MS),
};

if (!TOKEN) {
  console.error('BRIDGE_TOKEN is required. Start the bridge via pythinker so it can provision a local secret automatically.');
  process.exit(1);
}

console.log('🤖 pythinker WhatsApp Bridge');
console.log('========================\n');

const server = new BridgeServer(PORT, AUTH_DIR, TOKEN, PAIRING_PHONE, TUNING);

// Handle graceful shutdown
process.on('SIGINT', async () => {
  console.log('\n\nShutting down...');
  await server.stop();
  process.exit(0);
});

process.on('SIGTERM', async () => {
  await server.stop();
  process.exit(0);
});

// Start the server
server.start().catch((error) => {
  console.error('Failed to start bridge:', error);
  process.exit(1);
});
