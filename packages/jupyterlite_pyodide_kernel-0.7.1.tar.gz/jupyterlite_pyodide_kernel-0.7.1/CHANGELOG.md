# Changelog

<!-- <START NEW CHANGELOG ENTRY> -->

## 0.7.1

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.7.0...89d84366b5bbf2ee198574f05cc6da6ee1ea689a))

### Enhancements made

- Update to Pyodide 0.29.3 for 0.7.x series (backport of #259) [#260](https://github.com/jupyterlite/pyodide-kernel/pull/260) ([@agriyakhetarpal](https://github.com/agriyakhetarpal), [@bollwyvl](https://github.com/bollwyvl))

### Maintenance and upkeep improvements

- [0.7.x] update to jupyterlite-core 0.7.3 [#266](https://github.com/jupyterlite/pyodide-kernel/pull/266) ([@bollwyvl](https://github.com/bollwyvl), [@jtpio](https://github.com/jtpio))
- update to pyodide 0.29.1 [#248](https://github.com/jupyterlite/pyodide-kernel/pull/248) ([@bollwyvl](https://github.com/bollwyvl), [@jtpio](https://github.com/jtpio))

### Contributors to this release

The following people contributed discussions, new ideas, code and documentation contributions, and review.
See [our definition of contributors](https://github-activity.readthedocs.io/en/latest/use/#how-does-this-tool-define-contributions-in-the-reports).

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2025-11-26&to=2026-03-03&type=c))

@agriyakhetarpal ([activity](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Aagriyakhetarpal+updated%3A2025-11-26..2026-03-03&type=Issues)) | @bollwyvl ([activity](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2025-11-26..2026-03-03&type=Issues)) | @jtpio ([activity](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2025-11-26..2026-03-03&type=Issues))

<!-- <END NEW CHANGELOG ENTRY> -->

## 0.7.0

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.6.1...4b130dff2aecfe94c766841852272a15f65a5c88))

### Enhancements made

- Reject kernel ready promise when disposed [#238](https://github.com/jupyterlite/pyodide-kernel/pull/238) ([@bollwyvl](https://github.com/bollwyvl))
- update to pyodide 0.28.3 [#223](https://github.com/jupyterlite/pyodide-kernel/pull/223) ([@bollwyvl](https://github.com/bollwyvl))
- Update to jupyterlite-core 0.7.x, pyodide 0.28.1, micropip 0.10.1 [#203](https://github.com/jupyterlite/pyodide-kernel/pull/203) ([@bollwyvl](https://github.com/bollwyvl))

### Bugs fixed

- Test with the prod build, revert `terser` update [#231](https://github.com/jupyterlite/pyodide-kernel/pull/231) ([@jtpio](https://github.com/jtpio))
- Update to JupyterLite `0.7.0a3` [#207](https://github.com/jupyterlite/pyodide-kernel/pull/207) ([@jtpio](https://github.com/jtpio))
- Fix reinstall arg [#204](https://github.com/jupyterlite/pyodide-kernel/pull/204) ([@jtpio](https://github.com/jtpio))

### Maintenance and upkeep improvements

- Update to JupyterLite 0.7.0 final [#245](https://github.com/jupyterlite/pyodide-kernel/pull/245) ([@jtpio](https://github.com/jtpio))
- Update to JupyterLite 0.7.0rc2 [#244](https://github.com/jupyterlite/pyodide-kernel/pull/244) ([@jtpio](https://github.com/jtpio))
- Remove `liteExtension` from `package.json` [#243](https://github.com/jupyterlite/pyodide-kernel/pull/243) ([@jtpio](https://github.com/jtpio))
- use eslint consistent-type-imports [#242](https://github.com/jupyterlite/pyodide-kernel/pull/242) ([@bollwyvl](https://github.com/bollwyvl))
- Update to JupyterLite 0.7.0rc0 [#240](https://github.com/jupyterlite/pyodide-kernel/pull/240) ([@jtpio](https://github.com/jtpio))
- Update to jupyterlite-core 0.7.0b1 [#237](https://github.com/jupyterlite/pyodide-kernel/pull/237) ([@bollwyvl](https://github.com/bollwyvl))
- Update to JupyterLite 0.7.0b0 [#235](https://github.com/jupyterlite/pyodide-kernel/pull/235) ([@jtpio](https://github.com/jtpio))
- Update minimum supported python to 3.10 [#234](https://github.com/jupyterlite/pyodide-kernel/pull/234) ([@bollwyvl](https://github.com/bollwyvl))
- update to pyodide 0.29.0 [#233](https://github.com/jupyterlite/pyodide-kernel/pull/233) ([@bollwyvl](https://github.com/bollwyvl))
- Bump vega from 5.30.0 to 5.33.0 in /ui-tests [#229](https://github.com/jupyterlite/pyodide-kernel/pull/229) ([@dependabot](https://github.com/dependabot))
- Bump systeminformation from 5.22.11 to 5.27.11 in /ui-tests [#228](https://github.com/jupyterlite/pyodide-kernel/pull/228) ([@dependabot](https://github.com/dependabot))
- Bump nanoid from 3.3.7 to 3.3.11 in /ui-tests [#227](https://github.com/jupyterlite/pyodide-kernel/pull/227) ([@dependabot](https://github.com/dependabot))
- Manual dependabot updates [#226](https://github.com/jupyterlite/pyodide-kernel/pull/226) ([@jtpio](https://github.com/jtpio))
- Update to JupyterLite 0.7.0a7 [#225](https://github.com/jupyterlite/pyodide-kernel/pull/225) ([@jtpio](https://github.com/jtpio))
- Update to JupyterLite `0.7.0a6` [#224](https://github.com/jupyterlite/pyodide-kernel/pull/224) ([@jtpio](https://github.com/jtpio))
- Update to JupyterLite 0.7.0a5 [#212](https://github.com/jupyterlite/pyodide-kernel/pull/212) ([@jtpio](https://github.com/jtpio))
- Set proper `stdout` and `stderr` callbacks in `loadPyodide` [#206](https://github.com/jupyterlite/pyodide-kernel/pull/206) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2025-06-05&to=2025-11-26&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2025-06-05..2025-11-26&type=Issues) | [@Carreau](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3ACarreau+updated%3A2025-06-05..2025-11-26&type=Issues) | [@dependabot](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Adependabot+updated%3A2025-06-05..2025-11-26&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2025-06-05..2025-11-26&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2025-06-05..2025-11-26&type=Issues)

## 0.7.0rc1

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.7.0-rc.0...47db767045df9e1a1f750e11831f2c3fe27f55ef))

### Maintenance and upkeep improvements

- Update to JupyterLite 0.7.0rc2 [#244](https://github.com/jupyterlite/pyodide-kernel/pull/244) ([@jtpio](https://github.com/jtpio))
- Remove `liteExtension` from `package.json` [#243](https://github.com/jupyterlite/pyodide-kernel/pull/243) ([@jtpio](https://github.com/jtpio))
- use eslint consistent-type-imports [#242](https://github.com/jupyterlite/pyodide-kernel/pull/242) ([@bollwyvl](https://github.com/bollwyvl))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2025-11-20&to=2025-11-25&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2025-11-20..2025-11-25&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2025-11-20..2025-11-25&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2025-11-20..2025-11-25&type=Issues)

## 0.7.0rc0

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.7.0-beta.0...6a748d7440f0f17f6af1c54926073a4ca89f1a04))

### Enhancements made

- Reject kernel ready promise when disposed [#238](https://github.com/jupyterlite/pyodide-kernel/pull/238) ([@bollwyvl](https://github.com/bollwyvl))

### Maintenance and upkeep improvements

- Update to JupyterLite 0.7.0rc0 [#240](https://github.com/jupyterlite/pyodide-kernel/pull/240) ([@jtpio](https://github.com/jtpio))
- Update to jupyterlite-core 0.7.0b1 [#237](https://github.com/jupyterlite/pyodide-kernel/pull/237) ([@bollwyvl](https://github.com/bollwyvl))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2025-10-23&to=2025-11-20&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2025-10-23..2025-11-20&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2025-10-23..2025-11-20&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2025-10-23..2025-11-20&type=Issues)

## 0.7.0b0

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.7.0-alpha.5...47a31daaf306ed0e90712f8989854e63489c4e02))

### Maintenance and upkeep improvements

- Update to JupyterLite 0.7.0b0 [#235](https://github.com/jupyterlite/pyodide-kernel/pull/235) ([@jtpio](https://github.com/jtpio))
- Update minimum supported python to 3.10 [#234](https://github.com/jupyterlite/pyodide-kernel/pull/234) ([@bollwyvl](https://github.com/bollwyvl))
- update to pyodide 0.29.0 [#233](https://github.com/jupyterlite/pyodide-kernel/pull/233) ([@bollwyvl](https://github.com/bollwyvl))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2025-10-13&to=2025-10-23&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2025-10-13..2025-10-23&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2025-10-13..2025-10-23&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2025-10-13..2025-10-23&type=Issues)

## 0.7.0a5

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.7.0-alpha.4...21ad9d45d2c0aa0759e7b5295fb1df532a110400))

### Bugs fixed

- Test with the prod build, revert `terser` update [#231](https://github.com/jupyterlite/pyodide-kernel/pull/231) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2025-10-10&to=2025-10-13&type=c))

[@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2025-10-10..2025-10-13&type=Issues)

## 0.7.0a4

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.7.0-alpha.3...29a5f1647aa266e8b030cedc55610ea427d14305))

### Maintenance and upkeep improvements

- Bump vega from 5.30.0 to 5.33.0 in /ui-tests [#229](https://github.com/jupyterlite/pyodide-kernel/pull/229) ([@dependabot](https://github.com/dependabot))
- Bump systeminformation from 5.22.11 to 5.27.11 in /ui-tests [#228](https://github.com/jupyterlite/pyodide-kernel/pull/228) ([@dependabot](https://github.com/dependabot))
- Bump nanoid from 3.3.7 to 3.3.11 in /ui-tests [#227](https://github.com/jupyterlite/pyodide-kernel/pull/227) ([@dependabot](https://github.com/dependabot))
- Manual dependabot updates [#226](https://github.com/jupyterlite/pyodide-kernel/pull/226) ([@jtpio](https://github.com/jtpio))
- Update to JupyterLite 0.7.0a7 [#225](https://github.com/jupyterlite/pyodide-kernel/pull/225) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2025-09-24&to=2025-10-10&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2025-09-24..2025-10-10&type=Issues) | [@Carreau](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3ACarreau+updated%3A2025-09-24..2025-10-10&type=Issues) | [@dependabot](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Adependabot+updated%3A2025-09-24..2025-10-10&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2025-09-24..2025-10-10&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2025-09-24..2025-10-10&type=Issues)

## 0.7.0a3

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.7.0-alpha.2...c3ad60426ead3176e42b961a2ff5dccf08ce8b41))

### Enhancements made

- update to pyodide 0.28.3 [#223](https://github.com/jupyterlite/pyodide-kernel/pull/223) ([@bollwyvl](https://github.com/bollwyvl))

### Maintenance and upkeep improvements

- Update to JupyterLite `0.7.0a6` [#224](https://github.com/jupyterlite/pyodide-kernel/pull/224) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2025-09-08&to=2025-09-24&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2025-09-08..2025-09-24&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2025-09-08..2025-09-24&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2025-09-08..2025-09-24&type=Issues)

## 0.7.0a2

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.7.0-alpha.1...b07e8fd57809dcd6b6436a652a213d9a4f5bf2e8))

### Maintenance and upkeep improvements

- Update to JupyterLite 0.7.0a5 [#212](https://github.com/jupyterlite/pyodide-kernel/pull/212) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2025-08-13&to=2025-09-08&type=c))

[@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2025-08-13..2025-09-08&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2025-08-13..2025-09-08&type=Issues)

## 0.7.0a1

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.7.0-alpha.0...c94f3c0c8fb4f16d36dad6c4176f84f4b012e9c2))

### Bugs fixed

- Update to JupyterLite `0.7.0a3` [#207](https://github.com/jupyterlite/pyodide-kernel/pull/207) ([@jtpio](https://github.com/jtpio))

### Maintenance and upkeep improvements

- Set proper `stdout` and `stderr` callbacks in `loadPyodide` [#206](https://github.com/jupyterlite/pyodide-kernel/pull/206) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2025-08-07&to=2025-08-13&type=c))

[@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2025-08-07..2025-08-13&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2025-08-07..2025-08-13&type=Issues)

## 0.7.0a0

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.6.1...7de6a58f42706b9656173e279451c60c0cc670ae))

### Enhancements made

- Update to jupyterlite-core 0.7.x, pyodide 0.28.1, micropip 0.10.1 [#203](https://github.com/jupyterlite/pyodide-kernel/pull/203) ([@bollwyvl](https://github.com/bollwyvl))

### Bugs fixed

- Fix reinstall arg [#204](https://github.com/jupyterlite/pyodide-kernel/pull/204) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2025-06-05&to=2025-08-07&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2025-06-05..2025-08-07&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2025-06-05..2025-08-07&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2025-06-05..2025-08-07&type=Issues)

## 0.6.1

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.6.0...85dc7975cd3cf576345cbf38c29ac03c6f89f797))

### Enhancements made

- Report filesystem availability in the log console [#196](https://github.com/jupyterlite/pyodide-kernel/pull/196) ([@jtpio](https://github.com/jtpio))

### Documentation improvements

- Update compat table in the README [#193](https://github.com/jupyterlite/pyodide-kernel/pull/193) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2025-06-02&to=2025-06-05&type=c))

[@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2025-06-02..2025-06-05&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2025-06-02..2025-06-05&type=Issues)

## 0.6.0

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.5.1...eaad8737f5a18a16d900e21cd3df8565866c445a))

### Enhancements made

- Log Pyodide fatal errors [#188](https://github.com/jupyterlite/pyodide-kernel/pull/188) ([@jtpio](https://github.com/jtpio))
- Support stdin via service worker [#183](https://github.com/jupyterlite/pyodide-kernel/pull/183) ([@ianthomas23](https://github.com/ianthomas23))
- Surface the Pyodide logs to the UI [#177](https://github.com/jupyterlite/pyodide-kernel/pull/177) ([@jtpio](https://github.com/jtpio))
- Re-enable jedi for code completion [#168](https://github.com/jupyterlite/pyodide-kernel/pull/168) ([@qqdaiyu55](https://github.com/qqdaiyu55))
- use a list for piplite_urls [#161](https://github.com/jupyterlite/pyodide-kernel/pull/161) ([@bollwyvl](https://github.com/bollwyvl))

### Bugs fixed

- Log messages to the dev tools console [#187](https://github.com/jupyterlite/pyodide-kernel/pull/187) ([@jtpio](https://github.com/jtpio))
- Remove dependency on `IBroadcastChannelWrapper`, use `browsingContextId` [#182](https://github.com/jupyterlite/pyodide-kernel/pull/182) ([@jtpio](https://github.com/jtpio))
- Depend on jupyterlite 0.6.0-alpha.2 to include https://github.com/jupyterlite/jupyterlite/pull/1568 [#173](https://github.com/jupyterlite/pyodide-kernel/pull/173) ([@juntyr](https://github.com/juntyr))

### Maintenance and upkeep improvements

- Update to JupyterLite 0.6.0 final [#192](https://github.com/jupyterlite/pyodide-kernel/pull/192) ([@jtpio](https://github.com/jtpio))
- bump lab versions in pyproject [#191](https://github.com/jupyterlite/pyodide-kernel/pull/191) ([@bollwyvl](https://github.com/bollwyvl))
- Update to JupyterLite 0.6.0rc0 [#190](https://github.com/jupyterlite/pyodide-kernel/pull/190) ([@jtpio](https://github.com/jtpio))
- Update to Pyodide 0.27.6 [#189](https://github.com/jupyterlite/pyodide-kernel/pull/189) ([@jtpio](https://github.com/jtpio))
- Update to JupyterLite 0.6.0b0 [#185](https://github.com/jupyterlite/pyodide-kernel/pull/185) ([@jtpio](https://github.com/jtpio))
- update to pyodide 0.27.5 [#181](https://github.com/jupyterlite/pyodide-kernel/pull/181) ([@bollwyvl](https://github.com/bollwyvl))
- Bump to JupyterLite 0.6.0a4 [#176](https://github.com/jupyterlite/pyodide-kernel/pull/176) ([@jtpio](https://github.com/jtpio))
- Update to JupyterLite 0.6.0a3 [#175](https://github.com/jupyterlite/pyodide-kernel/pull/175) ([@jtpio](https://github.com/jtpio))
- Bump to Pyodide 0.27.4 [#174](https://github.com/jupyterlite/pyodide-kernel/pull/174) ([@agriyakhetarpal](https://github.com/agriyakhetarpal))
- pyodide 0.27.3 [#171](https://github.com/jupyterlite/pyodide-kernel/pull/171) ([@bollwyvl](https://github.com/bollwyvl))
- Update to pyodide 0.27.2 [#163](https://github.com/jupyterlite/pyodide-kernel/pull/163) ([@bollwyvl](https://github.com/bollwyvl))
- Update to JupyterLite 0.6.0a0 [#160](https://github.com/jupyterlite/pyodide-kernel/pull/160) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2025-01-15&to=2025-06-02&type=c))

[@agriyakhetarpal](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Aagriyakhetarpal+updated%3A2025-01-15..2025-06-02&type=Issues) | [@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2025-01-15..2025-06-02&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2025-01-15..2025-06-02&type=Issues) | [@ianthomas23](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Aianthomas23+updated%3A2025-01-15..2025-06-02&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2025-01-15..2025-06-02&type=Issues) | [@juntyr](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajuntyr+updated%3A2025-01-15..2025-06-02&type=Issues) | [@lesteve](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Alesteve+updated%3A2025-01-15..2025-06-02&type=Issues) | [@qqdaiyu55](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Aqqdaiyu55+updated%3A2025-01-15..2025-06-02&type=Issues)

## 0.6.0rc0

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.6.0-beta.1...ec12a7573d15854ab3c68b029f08cd62186a13e6))

### Maintenance and upkeep improvements

- Update to JupyterLite 0.6.0rc0 [#190](https://github.com/jupyterlite/pyodide-kernel/pull/190) ([@jtpio](https://github.com/jtpio))
- Update to Pyodide 0.27.6 [#189](https://github.com/jupyterlite/pyodide-kernel/pull/189) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2025-05-15&to=2025-05-28&type=c))

[@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2025-05-15..2025-05-28&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2025-05-15..2025-05-28&type=Issues)

## 0.6.0b1

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.6.0-beta.0...dd2e9fe130d857f3f0f202552a0702a088ea68b5))

### Enhancements made

- Log Pyodide fatal errors [#188](https://github.com/jupyterlite/pyodide-kernel/pull/188) ([@jtpio](https://github.com/jtpio))

### Bugs fixed

- Log messages to the dev tools console [#187](https://github.com/jupyterlite/pyodide-kernel/pull/187) ([@jtpio](https://github.com/jtpio))

### Maintenance and upkeep improvements

- Update to JupyterLite 0.6.0b0 [#185](https://github.com/jupyterlite/pyodide-kernel/pull/185) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2025-05-12&to=2025-05-15&type=c))

[@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2025-05-12..2025-05-15&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2025-05-12..2025-05-15&type=Issues) | [@lesteve](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Alesteve+updated%3A2025-05-12..2025-05-15&type=Issues)

## 0.6.0b0

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.6.0-alpha.6...f02ceab56b178b483fc395cc93a229129900643a))

### Enhancements made

- Surface the Pyodide logs to the UI [#177](https://github.com/jupyterlite/pyodide-kernel/pull/177) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2025-05-07&to=2025-05-12&type=c))

[@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2025-05-07..2025-05-12&type=Issues)

## 0.6.0a6

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.6.0-alpha.5...5668ec5078db592a4d14a66c75d12ea55894ad94))

### Enhancements made

- Support stdin via service worker [#183](https://github.com/jupyterlite/pyodide-kernel/pull/183) ([@ianthomas23](https://github.com/ianthomas23))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2025-04-15&to=2025-05-07&type=c))

[@ianthomas23](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Aianthomas23+updated%3A2025-04-15..2025-05-07&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2025-04-15..2025-05-07&type=Issues)

## 0.6.0a5

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.6.0-alpha.4...22bbd1aecaad87dca8841f1943f040513952a650))

### Bugs fixed

- Remove dependency on `IBroadcastChannelWrapper`, use `browsingContextId` [#182](https://github.com/jupyterlite/pyodide-kernel/pull/182) ([@jtpio](https://github.com/jtpio))

### Maintenance and upkeep improvements

- update to pyodide 0.27.5 [#181](https://github.com/jupyterlite/pyodide-kernel/pull/181) ([@bollwyvl](https://github.com/bollwyvl))
- Bump to JupyterLite 0.6.0a4 [#176](https://github.com/jupyterlite/pyodide-kernel/pull/176) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2025-03-19&to=2025-04-15&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2025-03-19..2025-04-15&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2025-03-19..2025-04-15&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2025-03-19..2025-04-15&type=Issues)

## 0.6.0a4

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.6.0-alpha.3...a986ecd3f3e2a28aed89cd0d3c9bcfb03ebe74e4))

### Bugs fixed

- Depend on jupyterlite 0.6.0-alpha.2 to include https://github.com/jupyterlite/jupyterlite/pull/1568 [#173](https://github.com/jupyterlite/pyodide-kernel/pull/173) ([@juntyr](https://github.com/juntyr))

### Maintenance and upkeep improvements

- Update to JupyterLite 0.6.0a3 [#175](https://github.com/jupyterlite/pyodide-kernel/pull/175) ([@jtpio](https://github.com/jtpio))
- Bump to Pyodide 0.27.4 [#174](https://github.com/jupyterlite/pyodide-kernel/pull/174) ([@agriyakhetarpal](https://github.com/agriyakhetarpal))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2025-02-26&to=2025-03-19&type=c))

[@agriyakhetarpal](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Aagriyakhetarpal+updated%3A2025-02-26..2025-03-19&type=Issues) | [@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2025-02-26..2025-03-19&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2025-02-26..2025-03-19&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2025-02-26..2025-03-19&type=Issues) | [@juntyr](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajuntyr+updated%3A2025-02-26..2025-03-19&type=Issues)

## 0.6.0a3

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.6.0-alpha.2...3de3a6e4ddfbf0e0ce1952701050e79b64f642f3))

### Maintenance and upkeep improvements

- pyodide 0.27.3 [#171](https://github.com/jupyterlite/pyodide-kernel/pull/171) ([@bollwyvl](https://github.com/bollwyvl))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2025-02-11&to=2025-02-26&type=c))

[@agriyakhetarpal](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Aagriyakhetarpal+updated%3A2025-02-11..2025-02-26&type=Issues) | [@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2025-02-11..2025-02-26&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2025-02-11..2025-02-26&type=Issues)

## 0.6.0a2

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.6.0-alpha.1...069521d06f69331b7e8ae40b976092d0f0df659e))

### Enhancements made

- Re-enable jedi for code completion [#168](https://github.com/jupyterlite/pyodide-kernel/pull/168) ([@qqdaiyu55](https://github.com/qqdaiyu55))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2025-02-03&to=2025-02-11&type=c))

[@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2025-02-03..2025-02-11&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2025-02-03..2025-02-11&type=Issues) | [@qqdaiyu55](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Aqqdaiyu55+updated%3A2025-02-03..2025-02-11&type=Issues)

## 0.6.0a1

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.6.0-alpha.0...37d011a1f9f068bb938e3eff80e8a497ac27618a))

### Maintenance and upkeep improvements

- Update to pyodide 0.27.2 [#163](https://github.com/jupyterlite/pyodide-kernel/pull/163) ([@bollwyvl](https://github.com/bollwyvl))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2025-01-17&to=2025-02-03&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2025-01-17..2025-02-03&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2025-01-17..2025-02-03&type=Issues)

## 0.6.0a0

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.5.1...bf25ce67078171ddce4443a7f4346d7724dd1b07))

### Enhancements made

- use a list for piplite_urls [#161](https://github.com/jupyterlite/pyodide-kernel/pull/161) ([@bollwyvl](https://github.com/bollwyvl))

### Maintenance and upkeep improvements

- Update to JupyterLite 0.6.0a0 [#160](https://github.com/jupyterlite/pyodide-kernel/pull/160) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2025-01-15&to=2025-01-17&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2025-01-15..2025-01-17&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2025-01-15..2025-01-17&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2025-01-15..2025-01-17&type=Issues)

## 0.5.1

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.5.0...5e8c970b213debc695ff7f3c41ce21ec8a9bb2db))

### Maintenance and upkeep improvements

- Update to Pyodide 0.27.1 [#159](https://github.com/jupyterlite/pyodide-kernel/pull/159) ([@bollwyvl](https://github.com/bollwyvl))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2025-01-09&to=2025-01-15&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2025-01-09..2025-01-15&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2025-01-09..2025-01-15&type=Issues)

## 0.5.0

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.4.6...e06d2cff9385f6910861bc977603b82e19e3604d))

### Enhancements made

- Support Pyodide 0.27 [#156](https://github.com/jupyterlite/pyodide-kernel/pull/156) ([@jtpio](https://github.com/jtpio))
- Update to JupyterLite 0.5.0 [#149](https://github.com/jupyterlite/pyodide-kernel/pull/149) ([@jtpio](https://github.com/jtpio))

### Maintenance and upkeep improvements

- Update to JupyterLite 0.5.0 [#157](https://github.com/jupyterlite/pyodide-kernel/pull/157) ([@jtpio](https://github.com/jtpio))
- Drop Python 3.8 [#151](https://github.com/jupyterlite/pyodide-kernel/pull/151) ([@jtpio](https://github.com/jtpio))
- Update `jupyterlite-core` dependency [#150](https://github.com/jupyterlite/pyodide-kernel/pull/150) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2024-12-17&to=2025-01-09&type=c))

[@agriyakhetarpal](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Aagriyakhetarpal+updated%3A2024-12-17..2025-01-09&type=Issues) | [@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2024-12-17..2025-01-09&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2024-12-17..2025-01-09&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2024-12-17..2025-01-09&type=Issues)

## 0.5.0b0

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.5.0-alpha.1...534574d3ecd8afefc98d139a8888e36e1e9fc5ab))

### Enhancements made

- Support Pyodide 0.27 [#156](https://github.com/jupyterlite/pyodide-kernel/pull/156) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2024-12-18&to=2025-01-02&type=c))

[@agriyakhetarpal](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Aagriyakhetarpal+updated%3A2024-12-18..2025-01-02&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2024-12-18..2025-01-02&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2024-12-18..2025-01-02&type=Issues)

## 0.5.0a1

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.5.0-alpha.0...2bd084d00ea336ab2bd2b92b23beef73e683e37c))

### Maintenance and upkeep improvements

- Drop Python 3.8 [#151](https://github.com/jupyterlite/pyodide-kernel/pull/151) ([@jtpio](https://github.com/jtpio))
- Update `jupyterlite-core` dependency [#150](https://github.com/jupyterlite/pyodide-kernel/pull/150) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2024-12-17&to=2024-12-18&type=c))

[@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2024-12-17..2024-12-18&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2024-12-17..2024-12-18&type=Issues)

## 0.5.0a0

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.4.6...31e4202bf2112df1ce5dfd94033713be571c15b5))

### Enhancements made

- Update to JupyterLite 0.5.0 [#149](https://github.com/jupyterlite/pyodide-kernel/pull/149) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2024-12-17&to=2024-12-17&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2024-12-17..2024-12-17&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2024-12-17..2024-12-17&type=Issues)

## 0.4.6

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.4.5...0164b5924ba964dfd79e89a95f1d3e610f127956))

### Bugs fixed

- Use postMessage instead of a comlink produced MessageChannel [#148](https://github.com/jupyterlite/pyodide-kernel/pull/148) ([@martenrichter](https://github.com/martenrichter))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2024-12-09&to=2024-12-17&type=c))

[@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2024-12-09..2024-12-17&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2024-12-09..2024-12-17&type=Issues) | [@martenrichter](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Amartenrichter+updated%3A2024-12-09..2024-12-17&type=Issues)

## 0.4.5

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.4.4...501bb6d5ee3a94c61a1f365c2cbf7263eabb9fc1))

### Bugs fixed

- Bump to jupyterlite deps to v0.4.5 [#146](https://github.com/jupyterlite/pyodide-kernel/pull/146) ([@juntyr](https://github.com/juntyr))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2024-11-18&to=2024-12-09&type=c))

[@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2024-11-18..2024-12-09&type=Issues) | [@juntyr](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajuntyr+updated%3A2024-11-18..2024-12-09&type=Issues)

## 0.4.4

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.4.3...d6841ce4de87f5683adc6e3e70c03a070b7ccdc7))

### Maintenance and upkeep improvements

- Bump to pyodide 0.26.4 [#142](https://github.com/jupyterlite/pyodide-kernel/pull/142) ([@bollwyvl](https://github.com/bollwyvl))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2024-10-21&to=2024-11-18&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2024-10-21..2024-11-18&type=Issues)

## 0.4.3

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.4.2...71c61d3bbebe937eb285a1ec7ffdd25dcda8078e))

### Maintenance and upkeep improvements

- Update to pyodide 0.26.3 [#139](https://github.com/jupyterlite/pyodide-kernel/pull/139) ([@bollwyvl](https://github.com/bollwyvl))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2024-09-03&to=2024-10-21&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2024-09-03..2024-10-21&type=Issues)

## 0.4.2

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.4.1...9673f2a8bb945a309884e22f766409a1b244ba31))

### Maintenance and upkeep improvements

- bump mock widget package versions [#135](https://github.com/jupyterlite/pyodide-kernel/pull/135) ([@bollwyvl](https://github.com/bollwyvl))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2024-07-30&to=2024-09-03&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2024-07-30..2024-09-03&type=Issues)

## 0.4.1

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.4.0...a299c95a635b3f6ff3a3a7d625a78d01e817cdba))

### Enhancements made

- Update to Pyodide 0.26.2 [#132](https://github.com/jupyterlite/pyodide-kernel/pull/132) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2024-07-25&to=2024-07-30&type=c))

[@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2024-07-25..2024-07-30&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2024-07-25..2024-07-30&type=Issues)

## 0.4.0

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.3.1...0803e075ea5960ef40486728a8f32ce83bb93280))

### Enhancements made

- Update to pyodide 0.26.1 [#116](https://github.com/jupyterlite/pyodide-kernel/pull/116) ([@bollwyvl](https://github.com/bollwyvl))
- Switch from using comlink to coincident [#115](https://github.com/jupyterlite/pyodide-kernel/pull/115) ([@martinRenou](https://github.com/martinRenou))
- FileSystem calls over Atomics.wait instead of service worker when available [#114](https://github.com/jupyterlite/pyodide-kernel/pull/114) ([@martinRenou](https://github.com/martinRenou))
- update to pyodide 0.26.0 [#113](https://github.com/jupyterlite/pyodide-kernel/pull/113) ([@bollwyvl](https://github.com/bollwyvl))
- Update to JupyterLite 0.4.0 [#106](https://github.com/jupyterlite/pyodide-kernel/pull/106) ([@jtpio](https://github.com/jtpio))

### Bugs fixed

- Fix `mountDrive` check [#129](https://github.com/jupyterlite/pyodide-kernel/pull/129) ([@jtpio](https://github.com/jtpio))
- Use `coincident` if `crossOriginIsolated`, `comlink` otherwise [#126](https://github.com/jupyterlite/pyodide-kernel/pull/126) ([@jtpio](https://github.com/jtpio))

### Maintenance and upkeep improvements

- Update to JupyterLite 0.4.0 final [#131](https://github.com/jupyterlite/pyodide-kernel/pull/131) ([@jtpio](https://github.com/jtpio))
- Add UI tests [#130](https://github.com/jupyterlite/pyodide-kernel/pull/130) ([@jtpio](https://github.com/jtpio))
- Bump `widgetsnbextension` to 4.0.11 [#110](https://github.com/jupyterlite/pyodide-kernel/pull/110) ([@jtpio](https://github.com/jtpio))
- Update `actions/setup-python` [#107](https://github.com/jupyterlite/pyodide-kernel/pull/107) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2024-03-30&to=2024-07-25&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2024-03-30..2024-07-25&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2024-03-30..2024-07-25&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2024-03-30..2024-07-25&type=Issues) | [@martinRenou](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3AmartinRenou+updated%3A2024-03-30..2024-07-25&type=Issues)

## 0.4.0rc0

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.4.0-beta.0...79cf7632dc31d97ea461104cef3ed8eaebfb2743))

### Bugs fixed

- Fix `mountDrive` check [#129](https://github.com/jupyterlite/pyodide-kernel/pull/129) ([@jtpio](https://github.com/jtpio))
- Use `coincident` if `crossOriginIsolated`, `comlink` otherwise [#126](https://github.com/jupyterlite/pyodide-kernel/pull/126) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2024-06-21&to=2024-07-23&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2024-06-21..2024-07-23&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2024-06-21..2024-07-23&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2024-06-21..2024-07-23&type=Issues) | [@martinRenou](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3AmartinRenou+updated%3A2024-06-21..2024-07-23&type=Issues)

## 0.4.0b0

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.4.0-alpha.2...ae20dc725fccc990c87253e659ed6aa1eba5969b))

### Enhancements made

- Update to pyodide 0.26.1 [#116](https://github.com/jupyterlite/pyodide-kernel/pull/116) ([@bollwyvl](https://github.com/bollwyvl))
- Switch from using comlink to coincident [#115](https://github.com/jupyterlite/pyodide-kernel/pull/115) ([@martinRenou](https://github.com/martinRenou))
- FileSystem calls over Atomics.wait instead of service worker when available [#114](https://github.com/jupyterlite/pyodide-kernel/pull/114) ([@martinRenou](https://github.com/martinRenou))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2024-06-05&to=2024-06-21&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2024-06-05..2024-06-21&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2024-06-05..2024-06-21&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2024-06-05..2024-06-21&type=Issues) | [@martinRenou](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3AmartinRenou+updated%3A2024-06-05..2024-06-21&type=Issues)

## 0.4.0a2

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.4.0-alpha.1...6696a9e63706b37f5f0c4162ccb420ac6fc22b01))

### Enhancements made

- update to pyodide 0.26.0 [#113](https://github.com/jupyterlite/pyodide-kernel/pull/113) ([@bollwyvl](https://github.com/bollwyvl))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2024-06-04&to=2024-06-05&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2024-06-04..2024-06-05&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2024-06-04..2024-06-05&type=Issues)

## 0.4.0a1

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.4.0-alpha.0...75235dc448595bd130c1b9c28c785122c7ef6443))

### Maintenance and upkeep improvements

- Bump `widgetsnbextension` to 4.0.11 [#110](https://github.com/jupyterlite/pyodide-kernel/pull/110) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2024-05-22&to=2024-06-04&type=c))

[@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2024-05-22..2024-06-04&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2024-05-22..2024-06-04&type=Issues)

## 0.4.0a0

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.3.1...5e073acf5ee9cf6b013ab596d0f5908bda739b3f))

### Enhancements made

- Update to JupyterLite 0.4.0 [#106](https://github.com/jupyterlite/pyodide-kernel/pull/106) ([@jtpio](https://github.com/jtpio))

### Maintenance and upkeep improvements

- Update `actions/setup-python` [#107](https://github.com/jupyterlite/pyodide-kernel/pull/107) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2024-03-30&to=2024-05-22&type=c))

[@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2024-03-30..2024-05-22&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2024-03-30..2024-05-22&type=Issues)

## 0.3.1

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.3.0...8c2c62a9b75c3ca80262d511cc15c0d4ce849c11))

### Enhancements made

- Fix URL rewriting in `loadPyodideOptions` [#105](https://github.com/jupyterlite/pyodide-kernel/pull/105) ([@bollwyvl](https://github.com/bollwyvl))

### Documentation improvements

- Update compat table in README.md [#104](https://github.com/jupyterlite/pyodide-kernel/pull/104) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2024-03-27&to=2024-03-30&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2024-03-27..2024-03-30&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2024-03-27..2024-03-30&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2024-03-27..2024-03-30&type=Issues)

## 0.3.0

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.3.0-alpha.0...d9b41b8a9052f4991a81031eee8919b25c87467e))

### Enhancements made

- Support `loadPyodide` options [#103](https://github.com/jupyterlite/pyodide-kernel/pull/103) ([@bollwyvl](https://github.com/bollwyvl))

### Maintenance and upkeep improvements

- Fix lint [#102](https://github.com/jupyterlite/pyodide-kernel/pull/102) ([@jtpio](https://github.com/jtpio))
- Update releaser workflows [#101](https://github.com/jupyterlite/pyodide-kernel/pull/101) ([@jtpio](https://github.com/jtpio))
- Bump `@jupyterlite` packages [#100](https://github.com/jupyterlite/pyodide-kernel/pull/100) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2024-02-16&to=2024-03-27&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2024-02-16..2024-03-27&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2024-02-16..2024-03-27&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2024-02-16..2024-03-27&type=Issues)

## 0.3.0a0

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.2.3...2546b47c1ec3cfe30d9b1fa27a0f67b007e1b654))

### Enhancements made

- Update to JupyterLite `0.3.0a0` [#93](https://github.com/jupyterlite/pyodide-kernel/pull/93) ([@jtpio](https://github.com/jtpio))

### Documentation improvements

- docs: add information on compatibility with pyodide versions [#92](https://github.com/jupyterlite/pyodide-kernel/pull/92) ([@ManonMarchand](https://github.com/ManonMarchand))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2024-02-12&to=2024-02-16&type=c))

[@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2024-02-12..2024-02-16&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2024-02-12..2024-02-16&type=Issues) | [@ManonMarchand](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3AManonMarchand+updated%3A2024-02-12..2024-02-16&type=Issues)

## 0.2.3

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.2.2...a74b99d282528b2b5f695f8e06def456d1edacc3))

### Maintenance and upkeep improvements

- Bump widgetsnbextension shim to 4.0.10 [#86](https://github.com/jupyterlite/pyodide-kernel/pull/86) ([@bollwyvl](https://github.com/bollwyvl))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2024-02-05&to=2024-02-12&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2024-02-05..2024-02-12&type=Issues)

## 0.2.2

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.2.1...adab8acaa7a4c4eee2097da00ea9d49d847bf0d6))

### Maintenance and upkeep improvements

- pin to jupyterlab \<4.1.0 for now in build-system and dev [#84](https://github.com/jupyterlite/pyodide-kernel/pull/84) ([@bollwyvl](https://github.com/bollwyvl))
- Update to pyodide 0.25.0 [#82](https://github.com/jupyterlite/pyodide-kernel/pull/82) ([@bollwyvl](https://github.com/bollwyvl))
- Enable PyPI trusted publisher [#80](https://github.com/jupyterlite/pyodide-kernel/pull/80) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2024-01-17&to=2024-02-05&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2024-01-17..2024-02-05&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2024-01-17..2024-02-05&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2024-01-17..2024-02-05&type=Issues)

## 0.2.1

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.2.0...5f0ba870fb92baa96c1c847e6ae1fdae608409df))

### Bugs fixed

- Install ssl before other packages to allow fetching of https content through urllib [#79](https://github.com/jupyterlite/pyodide-kernel/pull/79) ([@jobovy](https://github.com/jobovy))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2023-10-27&to=2024-01-17&type=c))

[@jobovy](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajobovy+updated%3A2023-10-27..2024-01-17&type=Issues)

## 0.2.0

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.1.1...93c654a48b31cf830bfaf77709b29e83d2808b43))

### Enhancements made

- Update to Pyodide 0.24.1 [#69](https://github.com/jupyterlite/pyodide-kernel/pull/69) ([@jtpio](https://github.com/jtpio))
- \[0.1.x\] pyodide 0.24.0, widget shim patches [#62](https://github.com/jupyterlite/pyodide-kernel/pull/62) ([@bollwyvl](https://github.com/bollwyvl))
- Support jupyterlite-core 0.2.0a0 [#58](https://github.com/jupyterlite/pyodide-kernel/pull/58) ([@bollwyvl](https://github.com/bollwyvl))

### Maintenance and upkeep improvements

- Update versions for 0.2.0 release [#74](https://github.com/jupyterlite/pyodide-kernel/pull/74) ([@bollwyvl](https://github.com/bollwyvl))
- Bump to jupyterlite-core 0.2.0a4, handle more log warnings [#72](https://github.com/jupyterlite/pyodide-kernel/pull/72) ([@bollwyvl](https://github.com/bollwyvl))
- bootstrap removed [#71](https://github.com/jupyterlite/pyodide-kernel/pull/71) ([@savakarrohan](https://github.com/savakarrohan))

### Documentation improvements

- Fix Github URL in doc header [#64](https://github.com/jupyterlite/pyodide-kernel/pull/64) ([@pierre-haessig](https://github.com/pierre-haessig))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2023-08-22&to=2023-10-27&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2023-08-22..2023-10-27&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2023-08-22..2023-10-27&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2023-08-22..2023-10-27&type=Issues) | [@lumberbot-app](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Alumberbot-app+updated%3A2023-08-22..2023-10-27&type=Issues) | [@meeseeksmachine](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ameeseeksmachine+updated%3A2023-08-22..2023-10-27&type=Issues) | [@michaelweinold](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Amichaelweinold+updated%3A2023-08-22..2023-10-27&type=Issues) | [@pierre-haessig](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Apierre-haessig+updated%3A2023-08-22..2023-10-27&type=Issues) | [@savakarrohan](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Asavakarrohan+updated%3A2023-08-22..2023-10-27&type=Issues)

## 0.2.0a2

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/v0.2.0a1...e223074ae9576e441affdee6ae5a53c44804ebe5))

### Enhancements made

- Update to Pyodide 0.24.1 [#69](https://github.com/jupyterlite/pyodide-kernel/pull/69) ([@jtpio](https://github.com/jtpio))

### Documentation improvements

- Fix Github URL in doc header [#64](https://github.com/jupyterlite/pyodide-kernel/pull/64) ([@pierre-haessig](https://github.com/pierre-haessig))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2023-09-21&to=2023-09-28&type=c))

[@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2023-09-21..2023-09-28&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2023-09-21..2023-09-28&type=Issues) | [@lumberbot-app](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Alumberbot-app+updated%3A2023-09-21..2023-09-28&type=Issues) | [@pierre-haessig](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Apierre-haessig+updated%3A2023-09-21..2023-09-28&type=Issues)

## 0.2.0a1

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.1.1...57ec58cb6bde410f858b16889282116c4867e21b))

### Enhancements made

- pyodide 0.24.0, widget shim patches [#62](https://github.com/jupyterlite/pyodide-kernel/pull/62) ([@bollwyvl](https://github.com/bollwyvl))
- Support jupyterlite-core 0.2.0a0 [#58](https://github.com/jupyterlite/pyodide-kernel/pull/58) ([@bollwyvl](https://github.com/bollwyvl))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2023-08-22&to=2023-09-21&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2023-08-22..2023-09-21&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2023-08-22..2023-09-21&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2023-08-22..2023-09-21&type=Issues) | [@meeseeksmachine](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ameeseeksmachine+updated%3A2023-08-22..2023-09-21&type=Issues) | [@michaelweinold](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Amichaelweinold+updated%3A2023-08-22..2023-09-21&type=Issues)

## 0.1.1

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.1.0...9912cad66e4457604642d64daf11d6c93f8e3d4c))

### Maintenance and upkeep improvements

- Bumped @jupyterlite packages [#55](https://github.com/jupyterlite/pyodide-kernel/pull/55) ([@andeplane](https://github.com/andeplane))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2023-08-03&to=2023-08-22&type=c))

[@andeplane](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Aandeplane+updated%3A2023-08-03..2023-08-22&type=Issues)

## 0.1.0

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/v0.0.10...55d21e05415108123c8908722ae1b70b925eebac))

### Maintenance and upkeep improvements

- Make use of the new Comm package [#54](https://github.com/jupyterlite/pyodide-kernel/pull/54) ([@martinRenou](https://github.com/martinRenou))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2023-08-03&to=2023-08-03&type=c))

[@martinRenou](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3AmartinRenou+updated%3A2023-08-03..2023-08-03&type=Issues)

## 0.0.10

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.0.9...0df94b5439914fbc4a40a133f6de9f753ba5f2d7))

### Bugs fixed

- Add `version_info` to the `ipykernel` mock [#53](https://github.com/jupyterlite/pyodide-kernel/pull/53) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2023-08-02&to=2023-08-03&type=c))

[@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2023-08-02..2023-08-03&type=Issues)

## 0.0.9

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.0.8...80dde027d0f1e9f2c4f4cd4f2679675ebd8da499))

### Enhancements made

- Update to Pyodide 0.23.4 [#50](https://github.com/jupyterlite/pyodide-kernel/pull/50) ([@jtpio](https://github.com/jtpio))

### Maintenance and upkeep improvements

- Add `before-bump-version` hook [#51](https://github.com/jupyterlite/pyodide-kernel/pull/51) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2023-05-04&to=2023-08-02&type=c))

[@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2023-05-04..2023-08-02&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2023-05-04..2023-08-02&type=Issues)

## 0.0.8

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.0.7...55f8602a1ff83cc199ec6a45c440d0566ff727a4))

### Enhancements made

- pyodide 0.23.2 [#46](https://github.com/jupyterlite/pyodide-kernel/pull/46) ([@bollwyvl](https://github.com/bollwyvl))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2023-04-24&to=2023-05-04&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2023-04-24..2023-05-04&type=Issues)

## 0.0.7

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.0.6...6af9a12b844dae5d5ac1b7ad703bc0d20b2c8e19))

### Enhancements made

- Update to Pyodide `0.23.1` [#45](https://github.com/jupyterlite/pyodide-kernel/pull/45) ([@jtpio](https://github.com/jtpio))
- 🎛 added `pipliteWheelUrl` option [#42](https://github.com/jupyterlite/pyodide-kernel/pull/42) ([@stevejpurves](https://github.com/stevejpurves))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2023-03-31&to=2023-04-24&type=c))

[@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2023-03-31..2023-04-24&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2023-03-31..2023-04-24&type=Issues) | [@stevejpurves](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Astevejpurves+updated%3A2023-03-31..2023-04-24&type=Issues)

## 0.0.6

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.0.5...55d8df5291d586255b5cd3e92c1d54bff4c32c8f))

### Maintenance and upkeep improvements

- Update to Pyodide 0.23, update mocks [#39](https://github.com/jupyterlite/pyodide-kernel/pull/39) ([@bollwyvl](https://github.com/bollwyvl))

### Documentation improvements

- Update instructions in the README [#31](https://github.com/jupyterlite/pyodide-kernel/pull/31) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2023-03-15&to=2023-03-31&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2023-03-15..2023-03-31&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2023-03-15..2023-03-31&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2023-03-15..2023-03-31&type=Issues)

## 0.0.5

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.0.4...61c29231d8bb9b32cf1bfde7d60e9f0971901341))

### Maintenance and upkeep improvements

- Depend on `jupyterlite-core >=0.1.0b19` [#30](https://github.com/jupyterlite/pyodide-kernel/pull/30) ([@jtpio](https://github.com/jtpio))
- Releaser: support bumping versions with `next` as the spec [#26](https://github.com/jupyterlite/pyodide-kernel/pull/26) ([@jtpio](https://github.com/jtpio))
- Install `lint` extra on Gitpod [#25](https://github.com/jupyterlite/pyodide-kernel/pull/25) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2023-03-10&to=2023-03-15&type=c))

[@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2023-03-10..2023-03-15&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2023-03-10..2023-03-15&type=Issues)

## 0.0.4

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.0.3...794b132092f7965becd018e00b9f188dc182963a))

### Maintenance and upkeep improvements

- Depend on `jupyterlite-core` [#23](https://github.com/jupyterlite/pyodide-kernel/pull/23) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2023-03-10&to=2023-03-10&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2023-03-10..2023-03-10&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2023-03-10..2023-03-10&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2023-03-10..2023-03-10&type=Issues)

## 0.0.3

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/@jupyterlite/pyodide-kernel-extension@0.0.2...ea540d9568afaca516b6ac85b6dc29eaf20ce917))

### Maintenance and upkeep improvements

- Restore more python tools and tests [#19](https://github.com/jupyterlite/pyodide-kernel/pull/19) ([@bollwyvl](https://github.com/bollwyvl))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2023-03-06&to=2023-03-10&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2023-03-06..2023-03-10&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2023-03-06..2023-03-10&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2023-03-06..2023-03-10&type=Issues)

## 0.0.2

([Full Changelog](https://github.com/jupyterlite/pyodide-kernel/compare/first-commit...96fe906b11689daff7c0737a0d35cb25d54d6cc9))

### Maintenance and upkeep improvements

- Fix direct dependency [#17](https://github.com/jupyterlite/pyodide-kernel/pull/17) ([@jtpio](https://github.com/jtpio))
- Releaser fixes [#16](https://github.com/jupyterlite/pyodide-kernel/pull/16) ([@jtpio](https://github.com/jtpio))
- Update Jupyter Releaser hooks [#13](https://github.com/jupyterlite/pyodide-kernel/pull/13) ([@jtpio](https://github.com/jtpio))
- Add Gitpod config [#12](https://github.com/jupyterlite/pyodide-kernel/pull/12) ([@jtpio](https://github.com/jtpio))
- Remove Binder files [#7](https://github.com/jupyterlite/pyodide-kernel/pull/7) ([@jtpio](https://github.com/jtpio))
- Add releaser workflows to the repo [#4](https://github.com/jupyterlite/pyodide-kernel/pull/4) ([@jtpio](https://github.com/jtpio))
- Add the Pyodide kernel from the JupyterLite repository [#2](https://github.com/jupyterlite/pyodide-kernel/pull/2) ([@jtpio](https://github.com/jtpio))
- Bootstrap the repo from the cookiecutter [#1](https://github.com/jupyterlite/pyodide-kernel/pull/1) ([@jtpio](https://github.com/jtpio))

### Documentation improvements

- Minor README edits [#11](https://github.com/jupyterlite/pyodide-kernel/pull/11) ([@jtpio](https://github.com/jtpio))
- Add ReadTheDocs preview CI workflow [#10](https://github.com/jupyterlite/pyodide-kernel/pull/10) ([@jtpio](https://github.com/jtpio))
- Add files for ReadTheDocs, enable Python tests, maintenance [#8](https://github.com/jupyterlite/pyodide-kernel/pull/8) ([@bollwyvl](https://github.com/bollwyvl))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlite/pyodide-kernel/graphs/contributors?from=2022-12-01&to=2023-03-06&type=c))

[@bollwyvl](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Abollwyvl+updated%3A2022-12-01..2023-03-06&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Agithub-actions+updated%3A2022-12-01..2023-03-06&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyterlite%2Fpyodide-kernel+involves%3Ajtpio+updated%3A2022-12-01..2023-03-06&type=Issues)
