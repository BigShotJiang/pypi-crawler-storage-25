#!/usr/bin/env python3
"""Install Bob Fleet hooks into Claude Code settings."""

import json
import os
import sys
from pathlib import Path


def get_hook_script_path() -> str:
    """Return the absolute path to fleet_hook.py."""
    return str(Path(__file__).parent / "fleet_hook.py")


def generate_hooks_config() -> dict:
    """Generate the Claude Code hooks configuration for bob-fleet."""
    hook_script = get_hook_script_path()
    python = sys.executable

    return {
        "hooks": {
            "SessionStart": [
                {
                    "type": "command",
                    "command": f"{python} {hook_script} session_start",
                    "timeout": 10,
                }
            ],
            "Stop": [
                {
                    "type": "command",
                    "command": f"{python} {hook_script} session_end",
                    "timeout": 10,
                }
            ],
            "PreToolUse": [
                {
                    "matcher": "Agent",
                    "type": "command",
                    "command": f"{python} {hook_script} agent_launch",
                    "timeout": 10,
                }
            ],
            "PostToolUse": [
                {
                    "matcher": "Agent",
                    "type": "command",
                    "command": f"{python} {hook_script} agent_complete",
                    "timeout": 10,
                }
            ],
        }
    }


def install_hooks(settings_path: str | None = None, merge: bool = True) -> str:
    """Install hooks into Claude Code settings.

    Args:
        settings_path: Path to settings.local.json. If None, uses .claude/settings.local.json in cwd.
        merge: If True, merge with existing hooks. If False, overwrite hooks section.

    Returns:
        Path to the settings file that was modified.
    """
    if settings_path is None:
        settings_path = os.path.join(os.getcwd(), ".claude", "settings.local.json")

    settings_dir = os.path.dirname(settings_path)
    os.makedirs(settings_dir, exist_ok=True)

    # Load existing settings
    existing = {}
    if os.path.exists(settings_path):
        with open(settings_path) as f:
            existing = json.load(f)

    new_hooks = generate_hooks_config()["hooks"]

    if merge and "hooks" in existing:
        # Merge: add bob-fleet hooks alongside existing ones
        for event, hooks_list in new_hooks.items():
            if event in existing["hooks"]:
                # Don't duplicate — check if fleet_hook.py is already there
                existing_commands = [h.get("command", "") for h in existing["hooks"][event]]
                for hook in hooks_list:
                    if not any("fleet_hook.py" in cmd for cmd in existing_commands):
                        existing["hooks"][event].append(hook)
            else:
                existing["hooks"][event] = hooks_list
    else:
        existing["hooks"] = new_hooks

    with open(settings_path, "w") as f:
        json.dump(existing, f, indent=2)
        f.write("\n")

    return settings_path


def main():
    """CLI entry point for hook installation."""
    import argparse
    parser = argparse.ArgumentParser(description="Install Bob Fleet hooks into Claude Code")
    parser.add_argument("--settings", help="Path to settings.local.json")
    parser.add_argument("--no-merge", action="store_true", help="Overwrite hooks instead of merging")
    args = parser.parse_args()

    path = install_hooks(args.settings, merge=not args.no_merge)
    print(f"Bob Fleet hooks installed at {path}")
    print()
    print("Hooks configured:")
    print("  SessionStart  -> session_start")
    print("  Stop          -> session_end")
    print("  PreToolUse    -> agent_launch (Agent tool)")
    print("  PostToolUse   -> agent_complete (Agent tool)")
    print()
    print("Restart Claude Code for hooks to take effect.")


if __name__ == "__main__":
    main()
