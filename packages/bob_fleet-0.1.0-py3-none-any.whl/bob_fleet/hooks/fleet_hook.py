#!/usr/bin/env python3
"""Bob Fleet hook for Claude Code.

Reads hook data from stdin (JSON) and forwards it to the local bob-fleet server.
If the server isn't running, auto-starts it as a daemon.

Sessions are self-healing: if agent_launch finds a stale/deleted session,
it creates a new one on-demand so Bobs always appear on the galaxy map.

Actions: session_start, session_end, agent_launch, agent_complete
"""

import hashlib
import json
import logging
import os
import re
import sys
import subprocess
import tempfile
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime

SERVER_URL = os.environ.get("BOB_FLEET_URL", "http://127.0.0.1:7777")
API = f"{SERVER_URL}/api/v1"

# Session mapping directory — persists bob-fleet session keys across hook calls
# Keyed by Claude Code's session_id (available in stdin JSON for all hook events)
SESSION_MAP_DIR = os.path.expanduser("~/.bob-fleet/session_map")
os.makedirs(SESSION_MAP_DIR, exist_ok=True)

# --- Logging ---
LOG_DIR = os.path.expanduser("~/.bob-fleet/logs")
os.makedirs(LOG_DIR, exist_ok=True)
LOG_FILE = os.path.join(LOG_DIR, "fleet_hook.log")

logger = logging.getLogger("fleet_hook")
logger.setLevel(logging.DEBUG)
_handler = logging.FileHandler(LOG_FILE, encoding="utf-8")
_handler.setFormatter(logging.Formatter(
    "%(asctime)s [%(levelname)s] %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
))
logger.addHandler(_handler)


def _read_stdin():
    """Read and parse JSON from stdin (Claude Code hook protocol)."""
    try:
        if not sys.stdin.isatty():
            raw = sys.stdin.read()
            if raw.strip():
                data = json.loads(raw)
                logger.debug("stdin: %s", json.dumps(data, default=str)[:500])
                return data
            else:
                logger.warning("stdin was empty")
        else:
            logger.warning("stdin is a tty (no piped data)")
    except (json.JSONDecodeError, TypeError, OSError) as e:
        logger.error("stdin parse failed: %s", e)
    return {}


def _post(path, data=None):
    """POST JSON to the fleet server. Returns parsed response or None."""
    url = f"{API}{path}"
    body = json.dumps(data or {}).encode()
    req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"})
    try:
        resp = urllib.request.urlopen(req, timeout=5)
        result = json.loads(resp.read())
        logger.info("POST %s → %s", path, json.dumps(result, default=str)[:300])
        return result
    except urllib.error.HTTPError as e:
        # Return the status code so callers can check for 404
        logger.warning("POST %s → HTTP %d", path, e.code)
        return {"_http_error": e.code}
    except urllib.error.URLError as e:
        logger.warning("POST %s failed (server down?): %s — auto-starting", path, e)
        _auto_start()
        try:
            resp = urllib.request.urlopen(req, timeout=10)
            result = json.loads(resp.read())
            logger.info("POST %s → %s (after auto-start)", path, json.dumps(result, default=str)[:300])
            return result
        except Exception as e2:
            logger.error("POST %s failed after auto-start: %s", path, e2)
            return None
    except Exception as e:
        logger.error("POST %s unexpected error: %s", path, e)
        return None


def _patch(path, data=None):
    """PATCH to the fleet server."""
    url = f"{API}{path}"
    body = json.dumps(data or {}).encode()
    req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"}, method="PATCH")
    try:
        resp = urllib.request.urlopen(req, timeout=5)
        result = json.loads(resp.read())
        logger.info("PATCH %s → %s", path, json.dumps(result, default=str)[:300])
        return result
    except Exception as e:
        logger.error("PATCH %s failed: %s", path, e)
        return None


def _delete(path):
    """DELETE to the fleet server."""
    url = f"{API}{path}"
    req = urllib.request.Request(url, method="DELETE")
    try:
        resp = urllib.request.urlopen(req, timeout=5)
        result = json.loads(resp.read())
        logger.info("DELETE %s → %s", path, json.dumps(result, default=str)[:300])
        return result
    except Exception as e:
        logger.error("DELETE %s failed: %s", path, e)
        return None


def _auto_start():
    """Start the bob-fleet server as a daemon."""
    try:
        subprocess.Popen(
            [sys.executable, "-m", "bob_fleet", "serve", "--daemon"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        import time
        time.sleep(2)  # Wait for server to bind
    except Exception:
        pass


def _save_session_key(claude_session_id: str, fleet_session_key: str, mission_key: str = ""):
    """Persist fleet session key and coordinator mission key."""
    if not claude_session_id:
        logger.warning("Cannot save session key — no claude_session_id")
        return
    try:
        path = os.path.join(SESSION_MAP_DIR, f"{claude_session_id}.key")
        with open(path, "w") as f:
            f.write(fleet_session_key)
        if mission_key:
            mpath = os.path.join(SESSION_MAP_DIR, f"{claude_session_id}.mission")
            with open(mpath, "w") as f:
                f.write(mission_key)
        logger.debug("Saved map file: %s → %s (mission=%s)", claude_session_id[:12], fleet_session_key[:12], mission_key or "none")
    except OSError as e:
        logger.error("Failed to save session map: %s", e)


def _load_mission_key(claude_session_id: str) -> str:
    """Load the coordinator mission key for a Claude session."""
    if not claude_session_id:
        return ""
    try:
        path = os.path.join(SESSION_MAP_DIR, f"{claude_session_id}.mission")
        with open(path) as f:
            return f.read().strip()
    except (OSError, FileNotFoundError):
        return ""


def _load_session_key(claude_session_id: str) -> str:
    """Load fleet session key for a Claude session_id."""
    if not claude_session_id:
        fallback = os.environ.get("BOB_FLEET_SESSION", "")
        if fallback:
            logger.debug("No claude_session_id, using env BOB_FLEET_SESSION=%s", fallback[:12])
        else:
            logger.warning("No claude_session_id and no BOB_FLEET_SESSION env")
        return fallback
    try:
        path = os.path.join(SESSION_MAP_DIR, f"{claude_session_id}.key")
        with open(path) as f:
            key = f.read().strip()
        logger.debug("Loaded map: %s → %s", claude_session_id[:12], key[:12] if key else "EMPTY")
        return key
    except (OSError, FileNotFoundError):
        fallback = os.environ.get("BOB_FLEET_SESSION", "")
        logger.warning("Map file missing for %s, fallback=%s", claude_session_id[:12], fallback[:12] if fallback else "NONE")
        return fallback


def _create_session(claude_session_id: str, project_dir: str = "") -> str:
    """Create a new fleet session and save the key. Returns the fleet session key or empty string."""
    if not project_dir:
        project_dir = os.getcwd()

    worktree = None
    if "worktree" in project_dir.lower() or ".claude/worktrees/" in project_dir:
        worktree = os.path.basename(project_dir)

    result = _post("/sessions", {
        "project_dir": project_dir,
        "worktree": worktree,
    })
    if result and "_http_error" not in result:
        fleet_key = result.get("session_id", "")
        mission_key = result.get("mission_key", "")
        if fleet_key:
            _save_session_key(claude_session_id, fleet_key, mission_key)
            logger.info("Session created: claude=%s → fleet=%s mission=%s",
                       claude_session_id[:12] if claude_session_id else "?",
                       fleet_key[:12], mission_key)
        return fleet_key
    return ""


def _ensure_session(claude_session_id: str, project_dir: str = "") -> str:
    """Get a valid fleet session key, creating one if needed.

    Self-healing: if the stored key points to a deleted/expired session,
    creates a new one transparently. This handles:
    - Server restarts (sessions lost)
    - SessionEnd already deleted the session
    - Stale key files from previous runs
    """
    # Try loading existing key
    session_key = _load_session_key(claude_session_id)

    if not session_key:
        # No key at all — create a new session
        logger.info("No session key found — creating new session")
        return _create_session(claude_session_id, project_dir)

    # Verify the session still exists by trying a lightweight operation
    # We'll use a dummy agent POST — if it 404s, the session is gone
    # Actually, let's just try using it and handle 404 in the caller
    # For now, return what we have — the caller handles 404
    return session_key


def session_start(stdin_data):
    """Create session + coordinator mission."""
    project_dir = stdin_data.get("cwd", os.getcwd())
    claude_session_id = stdin_data.get("session_id", "")

    logger.info("=== SESSION START === claude_id=%s cwd=%s", claude_session_id[:12] if claude_session_id else "?", project_dir)

    fleet_key = _create_session(claude_session_id, project_dir)

    if fleet_key:
        # Also write to CLAUDE_ENV_FILE if available (CLI fallback)
        env_file = os.environ.get("CLAUDE_ENV_FILE")
        if env_file:
            try:
                with open(env_file, "a") as f:
                    f.write(f"BOB_FLEET_SESSION={fleet_key}\n")
            except OSError:
                pass
        # Find the mission key from the session
        print(json.dumps({
            "systemMessage": "\U0001f680 Fleet session active. Bob is on the bridge."
        }))
    else:
        logger.error("SESSION START FAILED — no result from POST /sessions")


def agent_launch(stdin_data):
    """Pick a Bob and assign to a mission. Self-heals if session is stale."""
    claude_session_id = stdin_data.get("session_id", "")
    project_dir = stdin_data.get("cwd", os.getcwd())
    session_key = _ensure_session(claude_session_id, project_dir)
    if not session_key:
        logger.error("AGENT LAUNCH — could not get/create session for claude_id=%s", claude_session_id[:12] if claude_session_id else "?")
        return

    tool_input = stdin_data.get("tool_input", {})
    description = tool_input.get("description", "")
    prompt = tool_input.get("prompt", "")[:80]

    if not description and not prompt:
        logger.warning("AGENT LAUNCH — empty description and prompt, skipping")
        return

    logger.info("AGENT LAUNCH: desc=%r fleet_session=%s", description, session_key[:12])

    result = _post(f"/sessions/{session_key}/agents", {
        "description": description,
        "prompt": prompt,
    })

    # Self-heal: if 404, session was deleted — create new and retry
    if result and result.get("_http_error") == 404:
        logger.warning("Session %s not found (404) — creating new session and retrying", session_key[:12])
        session_key = _create_session(claude_session_id, project_dir)
        if session_key:
            result = _post(f"/sessions/{session_key}/agents", {
                "description": description,
                "prompt": prompt,
            })

    if result and "_http_error" not in result:
        bob = result.get("bob_name", "")
        system = result.get("system", "")
        logger.info("Bob deployed: %s → system=%s", bob, system)
    else:
        logger.error("AGENT LAUNCH FAILED — desc=%r", description)


def agent_complete(stdin_data):
    """Mark a Bob as done. Self-heals if session is stale.

    IMPORTANT: PostToolUse fires for Agent tool on BOTH background agent
    launches (tool returns immediately with agentId) and foreground agent
    completions. We must skip background launches — those agents are still
    running; they'll get a separate PostToolUse when they actually finish
    and return their result via task-notification → SendMessage flow.
    """
    tool_input = stdin_data.get("tool_input", {})

    # Background agents: PostToolUse fires at launch time, not completion.
    # The tool_input contains run_in_background=true for these.
    if tool_input.get("run_in_background"):
        description = tool_input.get("description", "?")
        logger.info("AGENT COMPLETE — SKIPPED (background agent still running): %r", description)
        return

    claude_session_id = stdin_data.get("session_id", "")
    project_dir = stdin_data.get("cwd", os.getcwd())
    session_key = _ensure_session(claude_session_id, project_dir)
    if not session_key:
        logger.error("AGENT COMPLETE — no session key for claude_id=%s", claude_session_id[:12] if claude_session_id else "?")
        return

    description = tool_input.get("description", "")

    if not description:
        logger.warning("AGENT COMPLETE — empty description, skipping")
        return

    logger.info("AGENT COMPLETE: desc=%r fleet_session=%s", description, session_key[:12])
    result = _patch(f"/sessions/{session_key}/agents/{urllib.parse.quote(description)}")

    # If the session was recreated, the agent won't exist — that's OK
    if result is None:
        logger.warning("AGENT COMPLETE — agent not found (session may have been recreated)")


def session_end(stdin_data):
    """Complete all missions and deactivate session."""
    claude_session_id = stdin_data.get("session_id", "")
    session_key = _load_session_key(claude_session_id)

    logger.info("=== SESSION END === claude_id=%s fleet_key=%s", claude_session_id[:12] if claude_session_id else "?", session_key[:12] if session_key else "MISSING")

    if not session_key:
        logger.error("SESSION END — no session key, cannot deactivate")
        return

    result = _delete(f"/sessions/{session_key}")
    if result:
        count = result.get("missions_completed", 0)
        logger.info("Session ended: %d mission(s) completed", count)
        print(json.dumps({
            "systemMessage": f"\u2705 {count} mission(s) completed. All Bobs returned to Replicator."
        }))
    else:
        logger.error("SESSION END — DELETE failed for fleet_key=%s (may already be gone)", session_key[:12])

    # Clean up session map files
    if claude_session_id:
        for ext in (".key", ".mission"):
            try:
                os.remove(os.path.join(SESSION_MAP_DIR, f"{claude_session_id}{ext}"))
            except OSError:
                pass
        logger.info("Cleaned up map files for claude_id=%s", claude_session_id[:12])


# ---------------------------------------------------------------------------
# Build tracking (Drydock Station)
# ---------------------------------------------------------------------------

_BUILD_PATTERN = re.compile(
    r"flutter\s+(build\s+(ios|apk|appbundle|ipa|web)|run\s+.*-d\s+\S+)"
)
_DRYDOCK_TMP_DIR = os.path.join(tempfile.gettempdir(), "drydock")


def _detect_platform(command: str) -> tuple[str, str]:
    """Return (ship_class, platform) from a flutter command."""
    cmd = command.lower()
    if "apk" in cmd or "appbundle" in cmd:
        return "Android Frigate", "android"
    return "iOS Cruiser", "ios"


def _parse_build_number(cwd: str) -> str:
    """Extract build number from pubspec.yaml version line (X.Y.Z+NN)."""
    for subdir in ("app", "."):
        pubspec = os.path.join(cwd, subdir, "pubspec.yaml")
        if os.path.isfile(pubspec):
            try:
                with open(pubspec) as f:
                    for line in f:
                        m = re.match(r"version:\s*\S+\+(\d+)", line)
                        if m:
                            return m.group(1)
            except OSError:
                pass
    return "?"


def _drydock_state_path(session_id: str) -> str:
    """Temp file to pass mission_key from build_start → build_complete."""
    os.makedirs(_DRYDOCK_TMP_DIR, exist_ok=True)
    return os.path.join(_DRYDOCK_TMP_DIR, f"{session_id}.json")


def _ensure_drydock_system():
    """Create the drydock system if it doesn't exist (409 = already there)."""
    _post("/systems", {
        "slug": "drydock",
        "name": "Drydock Station",
        "type": "shipyard",
        "visual": "drydock",
        "color": "#ff8c00",
        "position_x": 0.85,
        "position_y": 0.15,
        "scale": 0.85,
        "depth": 50,
    })


def build_start(stdin_data):
    """PreToolUse handler — detect flutter build/run and create a drydock mission."""
    tool_input = stdin_data.get("tool_input", {})
    command = tool_input.get("command", "")

    if not _BUILD_PATTERN.search(command):
        return  # fast exit for non-build Bash calls

    claude_session_id = stdin_data.get("session_id", "")
    cwd = stdin_data.get("cwd", os.getcwd())

    logger.info("=== BUILD START === cmd=%r", command[:80])

    session_key = _ensure_session(claude_session_id, cwd)
    if not session_key:
        logger.error("BUILD START — no session key")
        return

    # Ensure drydock system exists
    _ensure_drydock_system()

    ship_class, platform = _detect_platform(command)
    build_num = _parse_build_number(cwd)
    mission_name = f"{ship_class} #{build_num}"

    # Create mission at drydock
    result = _post("/missions", {
        "name": mission_name,
        "system": "drydock",
        "description": command[:120],
    })

    if not result or "_http_error" in result:
        logger.error("BUILD START — failed to create mission")
        return

    mission_key = result.get("mission_key", "")
    logger.info("Build mission created: %s at drydock", mission_key)

    # Add pipeline steps
    for step, status in [("compile", "in_progress"), ("link", "pending"), ("deploy", "pending")]:
        _post(f"/missions/{mission_key}/pipeline", {
            "step_name": step,
            "status": status,
        })

    # Add a Bob to the mission
    _post(f"/missions/{mission_key}/bobs", {
        "name": "Riker",
        "emoji": "\U0001f527",
        "role": "Shipwright",
    })

    # Save state for build_complete
    state = {
        "mission_key": mission_key,
        "platform": platform,
        "ship_class": ship_class,
        "build_num": build_num,
        "started_at": datetime.now().isoformat(),
    }
    try:
        with open(_drydock_state_path(claude_session_id), "w") as f:
            json.dump(state, f)
    except OSError as e:
        logger.error("Failed to save drydock state: %s", e)


_PR_PATTERN = re.compile(r"gh\s+pr\s+create")


def build_complete(stdin_data):
    """PostToolUse handler — mark drydock mission complete/failed, or ship on PR create."""
    tool_input = stdin_data.get("tool_input", {})
    command = tool_input.get("command", "")

    # --- PR creation = mission shipped ---
    if _PR_PATTERN.search(command):
        claude_session_id = stdin_data.get("session_id", "")
        mission_key = _load_mission_key(claude_session_id)
        if mission_key:
            tool_result = stdin_data.get("tool_result", {})
            output = tool_result.get("output", tool_result.get("stdout", ""))
            # Extract PR URL from output
            pr_url = ""
            for line in (output or "").split("\n"):
                if "github.com" in line and "/pull/" in line:
                    pr_url = line.strip()
                    break
            logger.info("=== PR CREATED === mission=%s pr=%s", mission_key, pr_url or "unknown")
            name_update = {}
            if pr_url:
                name_update["name"] = f"PR: {pr_url.split('/')[-1]}" if "/" in pr_url else None
            _patch(f"/missions/{mission_key}", {"status": "complete"})
        return

    # --- Flutter build tracking ---
    if not _BUILD_PATTERN.search(command):
        return  # fast exit

    claude_session_id = stdin_data.get("session_id", "")
    state_path = _drydock_state_path(claude_session_id)

    # Load state from build_start
    try:
        with open(state_path) as f:
            state = json.load(f)
    except (OSError, json.JSONDecodeError):
        logger.warning("BUILD COMPLETE — no drydock state found, skipping")
        return

    mission_key = state.get("mission_key", "")
    if not mission_key:
        return

    # Get result info
    tool_result = stdin_data.get("tool_result", {})
    # Handle different field name conventions
    output = tool_result.get("output", tool_result.get("stdout", ""))
    exit_code = tool_result.get("exit_code", tool_result.get("exitCode", -1))

    # Determine success
    success = (exit_code == 0)

    logger.info("=== BUILD COMPLETE === mission=%s success=%s exit_code=%s",
                mission_key, success, exit_code)

    if success:
        # All steps pass
        for step in ("compile", "link", "deploy"):
            _post(f"/missions/{mission_key}/pipeline", {
                "step_name": step,
                "status": "pass",
            })
        _patch(f"/missions/{mission_key}", {"status": "complete"})
    else:
        # Detect which step failed from output
        output_lower = (output or "").lower()
        if "error:" in output_lower and ("compiler" in output_lower or "lib/" in output_lower or ".dart" in output_lower):
            failed_step = "compile"
        elif "ld:" in output_lower or "linker" in output_lower or "undefined symbol" in output_lower:
            failed_step = "link"
        else:
            failed_step = "deploy"  # default — install/sign/deploy failure

        steps = ["compile", "link", "deploy"]
        for step in steps:
            if step == failed_step:
                _post(f"/missions/{mission_key}/pipeline", {
                    "step_name": step,
                    "status": "fail",
                })
                break
            else:
                _post(f"/missions/{mission_key}/pipeline", {
                    "step_name": step,
                    "status": "pass",
                })

        _patch(f"/missions/{mission_key}", {"status": "failed"})

    # Clean up temp file
    try:
        os.remove(state_path)
    except OSError:
        pass


# Dispatcher
ACTIONS = {
    "session_start": session_start,
    "session_end": session_end,
    "agent_launch": agent_launch,
    "agent_complete": agent_complete,
    "build_start": build_start,
    "build_complete": build_complete,
}


def main():
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} <action>", file=sys.stderr)
        sys.exit(1)

    action = sys.argv[1]
    handler = ACTIONS.get(action)
    if handler is None:
        print(f"Unknown action: {action}", file=sys.stderr)
        sys.exit(1)

    try:
        stdin_data = _read_stdin()
        handler(stdin_data)
    except Exception as e:
        # Hooks must NEVER crash — it blocks Claude
        logger.error("fleet_hook [%s] CRASHED: %s", action, e, exc_info=True)
        print(f"fleet_hook [{action}] error: {e}", file=sys.stderr)


if __name__ == "__main__":
    main()
