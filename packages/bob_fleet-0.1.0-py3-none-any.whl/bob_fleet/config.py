"""Configuration for the Bob Fleet server."""

import os
from pathlib import Path

# Data directory — shared across all worktrees/sessions
DATA_DIR = Path(os.environ.get("BOB_FLEET_DATA_DIR", Path.home() / ".bob-fleet"))

# Server
HOST = os.environ.get("BOB_FLEET_HOST", "0.0.0.0")
PORT = int(os.environ.get("BOB_FLEET_PORT", "7777"))

# Database
DB_PATH = DATA_DIR / "fleet.db"

# PID file for daemon management
PID_FILE = DATA_DIR / "bob-fleet.pid"

# Auto-shutdown after N minutes of inactivity (0 = disabled)
AUTO_SHUTDOWN_MINUTES = int(os.environ.get("BOB_FLEET_AUTO_SHUTDOWN", "30"))

# Stale session reaper — sessions older than this are auto-completed (0 = disabled)
SESSION_TTL_MINUTES = int(os.environ.get("BOB_FLEET_SESSION_TTL", "240"))
