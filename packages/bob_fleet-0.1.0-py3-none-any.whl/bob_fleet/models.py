"""Pydantic models for Bob Fleet API request/response validation."""

from typing import Optional

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Session lifecycle
# ---------------------------------------------------------------------------

class CreateSessionRequest(BaseModel):
    """Start a new Claude Code session and its coordinator mission."""
    project_dir: str
    project_name: Optional[str] = None
    project_subtitle: Optional[str] = None
    worktree: Optional[str] = None


class CreateSessionResponse(BaseModel):
    """Returned after a session is created."""
    session_id: str
    mission_key: str
    project_key: str


# ---------------------------------------------------------------------------
# Agent (Bob) lifecycle
# ---------------------------------------------------------------------------

class AgentLaunchRequest(BaseModel):
    """Register a new sub-agent within the current session."""
    description: str
    prompt: str = ""


class AgentLaunchResponse(BaseModel):
    """Returned after a Bob is assigned to a sub-agent."""
    bob_name: str
    bob_emoji: str
    mission_key: str
    system: str


class AgentCompleteRequest(BaseModel):
    """Mark a sub-agent as finished."""
    description: str


# ---------------------------------------------------------------------------
# Missions
# ---------------------------------------------------------------------------

class CreateMissionRequest(BaseModel):
    """Create a standalone mission (outside the session auto-flow)."""
    name: str
    system: str
    description: str = ""


class UpdateMissionRequest(BaseModel):
    """Partial update to an existing mission."""
    status: Optional[str] = None
    system: Optional[str] = None
    name: Optional[str] = None


# ---------------------------------------------------------------------------
# Bobs on a mission
# ---------------------------------------------------------------------------

class AddBobRequest(BaseModel):
    """Add a Bob to a mission manually."""
    name: str
    emoji: str = ""
    role: str = ""
    status: str = "in_progress"


class UpdateBobRequest(BaseModel):
    """Update a Bob's status on a mission."""
    status: str


# ---------------------------------------------------------------------------
# Pipeline steps
# ---------------------------------------------------------------------------

class PipelineStepRequest(BaseModel):
    """Create or update a pipeline step on a mission."""
    step_name: str
    status: str  # pending | pass | fail | in_progress


# ---------------------------------------------------------------------------
# Import / migration
# ---------------------------------------------------------------------------

class ImportRequest(BaseModel):
    """Import a full bob_fleet_log.json structure into the database."""
    data: dict


# ---------------------------------------------------------------------------
# Health / status
# ---------------------------------------------------------------------------

class HealthResponse(BaseModel):
    """Server health check response."""
    status: str = "ok"
    version: str
    uptime_seconds: float
    active_sessions: int
