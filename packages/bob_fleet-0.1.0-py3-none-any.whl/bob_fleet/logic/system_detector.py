"""Task and path based system detection for galaxy-map placement.

Maps free-text task descriptions and file paths to system slugs used by
the galaxy map.  Falls back to ``"replicator"`` (task) or ``None`` (path)
when no pattern matches.
"""

from __future__ import annotations

import re

# Each entry is (regex_pattern, system_slug).  Patterns are matched against
# lowercased input via ``re.search``.

DEFAULT_TASK_SYSTEM_MAP: list[tuple[str, str]] = [
    # Drydock — Flutter builds and device deploys (before imaging to avoid "bundle" overlap)
    (r"flutter.?build|flutter.?run\s+-d|\.apk|\.ipa|appbundle|drydock", "drydock"),
    # Sky panorama & star maps → Atlas Nebula
    (r"panorama|starmap|sky.?background|tile.?render|healpix|deep.?star|nasa.?star|gaia|\b[0-9]+k\b.*(?:base|tile|panorama)", "atlas"),
    # Imaging & DSO pipeline
    (r"imaging|camera|capture|photo|gallery|fits|histogram|stretch|stack|allsky|download|bundle|image.?service|dso.?image|survey|hips", "imaging"),
    # Sequencing
    (r"autorun|sequence|sequencing|checkpoint|target list", "sequencing"),
    # Focus
    (r"focus|autofocus|bahtinov|hfr", "focus"),
    # Hardware & NINA
    (r"mount|focuser|rotator|guider|flat.?panel|power.?box|device.?setting|equipment|hardware|d-?pad|slew|meridian|dither|nina|ascom|indi|websocket|pier|settling|backlash|move.?axis", "hardware"),
    # Fleet SDK & galaxy map
    (r"galaxy.?map|dashboard|fleet|bob_|mission|hook|fleet.?server", "fleet-sdk"),
    # Polar alignment
    (r"polar|alignment", "polar-alignment"),
    # Auth & accounts → Genesis Station
    (r"auth|login|sign.?in|account|user.?registration|anonymous|oauth", "genesis"),
    # Calibration & planning
    (r"plan.?screen|sky.?atlas|dso|catalog|celestial|nebula|target.?list|object.?list", "calibration"),
    # Cloud & Firebase infrastructure → Cloud Citadel
    (r"firebase|firestore|cloud|remote.?config|shorebird|storage.?bucket|deploy|sync.?service", "cloud"),
    # Resilience & performance
    (r"memory.?leak|optimization|performance|throttle|debug.?print|profil|crash|zero.?cost", "resilience"),
    # Code quality & maintenance → Forge
    (r"provider|model|service|mock|test|lint|warning|refactor|cleanup|dart.?fix|dependency|dep.?upgrade|architecture|code.?quality|migrate|opacity|dead.?code|duplication|scroll|fix|bug|polish|codebase|analyze|startup|release.?build|ci\b", "forge"),
    # UI/layout/branding
    (r"layout|widget|screen.?design|responsive|dark.?mode|theme|icon|logo|branding|ui.?polish|safe.?area|app.?bar|draggable|overlay", "ui-systems"),
]

DEFAULT_PATH_SYSTEM_MAP: list[tuple[str, str]] = [
    (r"screens/imaging|services/imaging|widgets/imaging|models/camera|screens/capture|screens/gallery", "imaging"),
    (r"screens/planning|services/sequencing", "sequencing"),
    (r"screens/focus|services/focus", "focus"),
    (r"screens/device_control|services/device_api", "hardware"),
    (r"bob_galaxy_map|bob_dashboard|bob_fleet_log|scripts/fleet", "fleet-sdk"),
    (r"screens/polar", "polar-alignment"),
    (r"providers/", "forge"),
    (r"models/", "forge"),
    (r"NINAPlugin", "hardware"),
]


def detect_system(
    text: str,
    system_map: list[tuple[str, str]] | None = None,
) -> str:
    """Detect the galaxy-map system from a task description.

    Iterates through *system_map* in order and returns the slug for the
    first pattern that matches the lowercased *text*.

    Parameters
    ----------
    text:
        Free-text task description, prompt, or combined string.
    system_map:
        Optional custom map. Falls back to :data:`DEFAULT_TASK_SYSTEM_MAP`.

    Returns
    -------
    str
        A system slug (e.g. ``"imaging"``, ``"forge"``), or ``"replicator"``
        if nothing matches.
    """
    if system_map is None:
        system_map = DEFAULT_TASK_SYSTEM_MAP

    lowered = text.lower()
    for pattern, system in system_map:
        if re.search(pattern, lowered):
            return system

    return "replicator"


def detect_system_from_path(
    file_path: str,
    path_map: list[tuple[str, str]] | None = None,
) -> str | None:
    """Detect the galaxy-map system from a file path.

    Iterates through *path_map* in order and returns the slug for the
    first pattern that matches the lowercased *file_path*.

    Parameters
    ----------
    file_path:
        Absolute or relative file path to check.
    path_map:
        Optional custom map. Falls back to :data:`DEFAULT_PATH_SYSTEM_MAP`.

    Returns
    -------
    str | None
        A system slug, or ``None`` if no pattern matches.
    """
    if path_map is None:
        path_map = DEFAULT_PATH_SYSTEM_MAP

    lowered = file_path.lower()
    for pattern, system in path_map:
        if re.search(pattern, lowered):
            return system

    return None
