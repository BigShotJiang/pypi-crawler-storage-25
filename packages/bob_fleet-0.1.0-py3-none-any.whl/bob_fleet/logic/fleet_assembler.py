"""Build the full fleet data JSON from SQLite.

Produces the exact same structure as bob_fleet_log.json so the
galaxy-map dashboard can consume it without changes.
"""

from __future__ import annotations

import json
import sqlite3
from typing import Any


def assemble_fleet_data(db_conn: sqlite3.Connection, project_key: str) -> dict[str, Any]:
    """Build the full fleet data JSON from SQLite.

    Args:
        db_conn: SQLite connection with Row factory enabled.
        project_key: The project key to query.

    Returns:
        A dict matching the bob_fleet_log.json structure for backward
        compatibility with the galaxy-map dashboard.

    Raises:
        ValueError: If the project_key is not found in the database.
    """
    # Ensure Row factory for dict-like access
    prev_factory = db_conn.row_factory
    db_conn.row_factory = sqlite3.Row
    cur = db_conn.cursor()

    try:
        # -------------------------------------------------------------------
        # Project
        # -------------------------------------------------------------------
        row = cur.execute(
            "SELECT id, name, subtitle FROM projects WHERE key = ?",
            (project_key,),
        ).fetchone()
        # Fall back to the first project if the requested key isn't found
        if row is None:
            row = cur.execute(
                "SELECT id, name, subtitle FROM projects ORDER BY id LIMIT 1",
            ).fetchone()
        if row is None:
            raise ValueError(f"No projects found in database")

        project_id = row["id"]
        project = {"name": row["name"], "subtitle": row["subtitle"]}

        # -------------------------------------------------------------------
        # Systems
        # -------------------------------------------------------------------
        systems = []
        for r in cur.execute(
            """
            SELECT slug, name, type, description, color,
                   position_x, position_y, scale, depth, visual,
                   date_range, commits
            FROM systems
            WHERE project_id = ?
            ORDER BY id
            """,
            (project_id,),
        ):
            systems.append({
                "id": r["slug"],
                "name": r["name"],
                "type": r["type"],
                "description": r["description"],
                "color": r["color"],
                "position": {"x": r["position_x"], "y": r["position_y"]},
                "scale": r["scale"],
                "depth": r["depth"],
                "visual": r["visual"],
                "dateRange": r["date_range"],
                "commits": r["commits"],
            })

        # -------------------------------------------------------------------
        # Travel path
        # -------------------------------------------------------------------
        travel_path = [
            r["system_slug"]
            for r in cur.execute(
                "SELECT system_slug FROM travel_path WHERE project_id = ? ORDER BY sort_order",
                (project_id,),
            )
        ]

        # -------------------------------------------------------------------
        # Dependencies
        # -------------------------------------------------------------------
        dependencies = [
            {"from": r["from_system"], "to": r["to_system"], "label": r["label"]}
            for r in cur.execute(
                "SELECT from_system, to_system, label FROM dependencies WHERE project_id = ? ORDER BY id",
                (project_id,),
            )
        ]

        # -------------------------------------------------------------------
        # Missions (with bobs + pipeline)
        # -------------------------------------------------------------------
        missions = []
        mission_rows = cur.execute(
            """
            SELECT id, mission_key, name, system_slug, date, status, description
            FROM missions
            WHERE project_id = ?
            ORDER BY date, id
            """,
            (project_id,),
        ).fetchall()

        for m in mission_rows:
            mission_id = m["id"]

            bobs = [
                {
                    "name": b["bob_name"],
                    "emoji": b["bob_emoji"],
                    "role": b["role"],
                    "status": b["status"],
                    "scope": b["scope"],
                    "started_at": b["started_at"],
                    "completed_at": b["completed_at"],
                    "duration_ms": b["duration_ms"],
                }
                for b in cur.execute(
                    "SELECT bob_name, bob_emoji, role, status, scope, started_at, completed_at, duration_ms "
                    "FROM mission_bobs WHERE mission_id = ? ORDER BY id",
                    (mission_id,),
                )
            ]

            pipeline = []
            for idx, p in enumerate(
                cur.execute(
                    "SELECT step_name, status FROM pipeline_steps WHERE mission_id = ? ORDER BY id",
                    (mission_id,),
                ),
                start=1,
            ):
                pipeline.append({
                    "step": idx,
                    "name": p["step_name"],
                    "status": p["status"],
                })

            missions.append({
                "id": m["mission_key"],
                "name": m["name"],
                "system": m["system_slug"],
                "date": m["date"],
                "status": m["status"],
                "description": m["description"],
                "bobs": bobs,
                "pipeline": pipeline,
            })

        # -------------------------------------------------------------------
        # Bobs roster (list format for dashboard compatibility)
        # -------------------------------------------------------------------
        bobs: list[dict[str, Any]] = []
        for r in cur.execute(
            "SELECT name, emoji, color FROM bobs_roster WHERE project_id = ? ORDER BY id",
            (project_id,),
        ):
            bobs.append({"name": r["name"], "emoji": r["emoji"], "color": r["color"]})

        # -------------------------------------------------------------------
        # Active session bobs (all bobs across all active sessions)
        # Combines coordinator bobs + agent bobs via UNION
        # -------------------------------------------------------------------
        active_session_bobs = []
        for r in cur.execute(
            """
            SELECT mb.bob_name, mb.bob_emoji, mb.role, mb.status,
                   mb.scope, mb.started_at, mb.completed_at, mb.duration_ms,
                   m.name AS mission_name, m.system_slug, m.mission_key
            FROM sessions s
            JOIN missions m ON m.id = s.coordinator_mission_id
            JOIN mission_bobs mb ON mb.mission_id = m.id
            WHERE s.project_id = ? AND s.active = 1
            UNION
            SELECT mb.bob_name, mb.bob_emoji, mb.role, mb.status,
                   mb.scope, mb.started_at, mb.completed_at, mb.duration_ms,
                   m.name AS mission_name, m.system_slug, m.mission_key
            FROM session_agents sa
            JOIN sessions s ON s.id = sa.session_id
            JOIN mission_bobs mb ON mb.mission_id = sa.mission_id AND mb.bob_name = sa.bob_name
            JOIN missions m ON m.id = sa.mission_id
            WHERE s.project_id = ? AND s.active = 1
            ORDER BY mb.started_at
            """,
            (project_id, project_id),
        ):
            active_session_bobs.append({
                "name": r["bob_name"],
                "emoji": r["bob_emoji"],
                "role": r["role"],
                "status": r["status"],
                "scope": r["scope"],
                "started_at": r["started_at"],
                "completed_at": r["completed_at"],
                "duration_ms": r["duration_ms"],
                "mission_name": r["mission_name"],
                "system": r["system_slug"],
                "mission_key": r["mission_key"],
            })

        # -------------------------------------------------------------------
        # Lifetime stats (computed from actual data)
        # -------------------------------------------------------------------
        stats = cur.execute(
            """
            SELECT
                COUNT(DISTINCT m.id) AS total_missions,
                COUNT(mb.id) AS total_bobs_deployed,
                COALESCE(SUM(mb.duration_ms), 0) AS total_duration_ms
            FROM missions m
            LEFT JOIN mission_bobs mb ON mb.mission_id = m.id
            WHERE m.project_id = ?
            """,
            (project_id,),
        ).fetchone()

        session_stats = cur.execute(
            "SELECT COUNT(*) AS total_sessions, "
            "COALESCE(SUM(duration_ms), 0) AS session_duration_ms "
            "FROM sessions WHERE project_id = ?",
            (project_id,),
        ).fetchone()

        lifetime_stats = {
            "total_missions": stats["total_missions"] or 0,
            "total_bobs_deployed": stats["total_bobs_deployed"] or 0,
            "total_duration_ms": stats["total_duration_ms"] or 0,
            "total_sessions": session_stats["total_sessions"] or 0,
            "session_duration_ms": session_stats["session_duration_ms"] or 0,
        }

        return {
            "project": project,
            "systems": systems,
            "travelPath": travel_path,
            "dependencies": dependencies,
            "missions": missions,
            "bobs": bobs,
            "active_session_bobs": active_session_bobs,
            "lifetime_stats": lifetime_stats,
        }

    finally:
        db_conn.row_factory = prev_factory
