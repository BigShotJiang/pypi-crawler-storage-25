"""Keyword-based Bob assignment for fleet subagents.

Scores each available Bob by keyword hits against the task description and
prompt, then picks the best match. Falls back to round-robin when there are
no keyword hits or when candidates tie.
"""

from __future__ import annotations

DEFAULT_ROSTER: dict[str, dict] = {
    # --- Original crew ---
    "Riker": {
        "emoji": "\U0001f916",
        "keywords": [
            "build", "implement", "fix", "create", "write",
            "refactor", "adapter", "code", "wire",
        ],
    },
    "Homer": {
        "emoji": "\U0001f37a",
        "keywords": [
            "test", "navigation", "wiring", "sound", "gallery", "run",
        ],
    },
    "Trillian": {
        "emoji": "\U0001f52d",
        "keywords": [
            "explore", "research", "analyze", "plan", "inspect",
            "model", "design", "investigate",
        ],
    },
    "Mario": {
        "emoji": "\U0001f3ae",
        "keywords": [
            "save", "session", "commit", "todo", "lesson", "memory", "git",
        ],
    },
    "Bridget": {
        "emoji": "\U0001f4cb",
        "keywords": [
            "review", "document", "organize", "track", "list",
            "audit", "simplify",
        ],
    },
    "Garfield": {
        "emoji": "\u2699\ufe0f",
        "keywords": [
            "config", "setup", "infrastructure", "deploy", "ci",
            "hook", "server",
        ],
    },
    # --- Expanded Bobiverse roster ---
    "Bill": {
        "emoji": "\U0001f9e0",
        "keywords": [
            "architect", "strategy", "system", "design", "high-level",
        ],
    },
    "Milo": {
        "emoji": "\U0001f680",
        "keywords": [
            "deploy", "launch", "release", "ship", "publish", "push",
        ],
    },
    "Charles": {
        "emoji": "\U0001f393",
        "keywords": [
            "database", "schema", "migration", "sql", "firestore", "data",
        ],
    },
    "Linus": {
        "emoji": "\U0001f427",
        "keywords": [
            "linux", "shell", "script", "bash", "terminal", "cli",
        ],
    },
    "Khan": {
        "emoji": "\u2694\ufe0f",
        "keywords": [
            "security", "auth", "permission", "token", "encrypt", "credential",
        ],
    },
    "Icarus": {
        "emoji": "\u2600\ufe0f",
        "keywords": [
            "performance", "optimize", "speed", "cache", "profile", "benchmark",
        ],
    },
    "Mulder": {
        "emoji": "\U0001f50d",
        "keywords": [
            "debug", "trace", "error", "log", "diagnose", "crash", "bug",
        ],
    },
    "Herschel": {
        "emoji": "\U0001f320",
        "keywords": [
            "astronomy", "star", "sky", "panorama", "tile", "dso", "catalog",
        ],
    },
    "Thor": {
        "emoji": "\u26a1",
        "keywords": [
            "api", "endpoint", "http", "rest", "websocket", "network",
        ],
    },
    "Ferb": {
        "emoji": "\U0001f527",
        "keywords": [
            "widget", "ui", "screen", "layout", "component", "flutter",
        ],
    },
    "Spike": {
        "emoji": "\U0001f3af",
        "keywords": [
            "focus", "guider", "mount", "tracking", "alignment", "calibration",
        ],
    },
    "Gandalf": {
        "emoji": "\U0001f9d9",
        "keywords": [
            "transform", "convert", "parse", "format", "serialize", "decode",
        ],
    },
    "Luke": {
        "emoji": "\U0001f5fa\ufe0f",
        "keywords": [
            "map", "galaxy", "dashboard", "fleet", "visualization", "chart",
        ],
    },
    "Bender": {
        "emoji": "\U0001f4e6",
        "keywords": [
            "package", "bundle", "import", "dependency", "library", "upgrade",
        ],
    },
    # --- Extended Bobiverse roster ---
    "Howard": {
        "emoji": "\U0001f6f0\ufe0f",
        "keywords": [
            "satellite", "orbit", "remote", "sensor", "telemetry",
        ],
    },
    "Ralph": {
        "emoji": "\U0001f52c",
        "keywords": [
            "science", "analysis", "experiment", "data", "measurement",
        ],
    },
    "Bert": {
        "emoji": "\U0001f3d7\ufe0f",
        "keywords": [
            "construct", "scaffold", "frame", "assemble", "structure",
        ],
    },
    "Claude": {
        "emoji": "\U0001f9ee",
        "keywords": [
            "compute", "calculate", "algorithm", "math", "logic",
        ],
    },
    "Jacques": {
        "emoji": "\U0001f3a8",
        "keywords": [
            "style", "theme", "color", "design", "visual", "css", "paint",
        ],
    },
    "Verne": {
        "emoji": "\U0001f30a",
        "keywords": [
            "deep", "scan", "survey", "sweep", "search", "discover",
        ],
    },
    "Daedalus": {
        "emoji": "\U0001f529",
        "keywords": [
            "hardware", "device", "driver", "sensor", "connect",
        ],
    },
    "Archimedes": {
        "emoji": "\U0001f4d0",
        "keywords": [
            "geometry", "position", "coordinate", "distance", "angle",
        ],
    },
    "Butterworth": {
        "emoji": "\U0001f373",
        "keywords": [
            "cook", "build", "compile", "bundle", "bake", "process",
        ],
    },
    "Oscar": {
        "emoji": "\U0001f3c6",
        "keywords": [
            "quality", "test", "verify", "validate", "check", "assert",
        ],
    },
    "Cranston": {
        "emoji": "\U0001f4e1",
        "keywords": [
            "network", "connect", "sync", "stream", "broadcast",
        ],
    },
    "Elmer": {
        "emoji": "\U0001f517",
        "keywords": [
            "link", "merge", "join", "combine", "integrate", "bridge",
        ],
    },
    "Skippy": {
        "emoji": "\U0001f608",
        "keywords": [
            "chaos", "break", "stress", "edge", "limit", "boundary",
        ],
    },
    "Spikey": {
        "emoji": "\U0001f994",
        "keywords": [
            "sharp", "precise", "exact", "pixel", "detail", "fine",
        ],
    },
    "Bob-2": {
        "emoji": "\U0001f31f",
        "keywords": [],
    },
}


def pick_bob(
    description: str,
    prompt: str,
    bobs_added: dict[str, str],
    bob_counter: int,
    roster: dict[str, dict] | None = None,
) -> tuple[str, str]:
    """Pick a Bob name and emoji for a new subagent.

    Combines *description* and *prompt*, lowercases the result, then scores
    every available Bob by how many of their keywords appear in the text.

    Parameters
    ----------
    description:
        Short task description (e.g. ``"Fix camera adapter"``).
    prompt:
        Full prompt or instructions for the subagent.
    bobs_added:
        Mapping of Bob names already assigned in this session to their roles.
        Used to avoid duplicates until the roster is exhausted.
    bob_counter:
        Monotonically increasing counter used for round-robin tie-breaking.
    roster:
        Optional custom roster. Falls back to :data:`DEFAULT_ROSTER`.

    Returns
    -------
    tuple[str, str]
        ``(name, emoji)`` for the chosen Bob.
    """
    if roster is None:
        roster = DEFAULT_ROSTER

    text = f"{description} {prompt}".lower()

    # Prefer Bobs not yet assigned; if all taken, reuse the full roster.
    available = [name for name in roster if name not in bobs_added]
    if not available:
        available = list(roster.keys())

    # Score each candidate by keyword hits.
    scores: dict[str, int] = {}
    for name in available:
        score = sum(1 for kw in roster[name]["keywords"] if kw in text)
        scores[name] = score

    max_score = max(scores.values())

    if max_score == 0:
        # No keyword matches -- round-robin.
        idx = bob_counter % len(available)
        pick = available[idx]
    else:
        tied = [n for n, s in scores.items() if s == max_score]
        if len(tied) == 1:
            pick = tied[0]
        else:
            # Tie-break via round-robin among tied candidates.
            idx = bob_counter % len(tied)
            pick = tied[idx]

    return pick, roster[pick]["emoji"]
