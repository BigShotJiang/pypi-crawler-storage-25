"""Import bob_fleet_log.json data into the SQLite database.

Handles one-time migration from the legacy JSON fleet log format
into the normalized SQLite schema used by the Bob Fleet server.
"""

from __future__ import annotations

import json
import sqlite3
from typing import Any

# ---------------------------------------------------------------------------
# Default keyword → Bob mapping (used to populate bobs_roster)
# ---------------------------------------------------------------------------

DEFAULT_ROSTER_KEYWORDS: dict[str, list[str]] = {
    "Riker": ["build", "implement", "fix", "create", "write", "refactor", "adapter", "code", "wire"],
    "Homer": ["test", "navigation", "wiring", "sound", "gallery", "run"],
    "Trillian": ["explore", "research", "analyze", "plan", "inspect", "model", "design", "investigate"],
    "Mario": ["save", "session", "commit", "todo", "lesson", "memory", "git"],
    "Bridget": ["review", "document", "organize", "track", "list", "audit", "simplify"],
    "Garfield": ["config", "setup", "infrastructure", "deploy", "ci", "hook", "server"],
    "Bill": ["architect", "strategy", "system", "design", "high-level"],
    "Milo": ["deploy", "launch", "release", "ship", "publish", "push"],
    "Charles": ["database", "schema", "migration", "sql", "firestore", "data"],
    "Linus": ["linux", "shell", "script", "bash", "terminal", "cli"],
    "Khan": ["security", "auth", "permission", "token", "encrypt", "credential"],
    "Icarus": ["performance", "optimize", "speed", "cache", "profile", "benchmark"],
    "Mulder": ["debug", "trace", "error", "log", "diagnose", "crash", "bug"],
    "Herschel": ["astronomy", "star", "sky", "panorama", "tile", "dso", "catalog"],
    "Thor": ["api", "endpoint", "http", "rest", "websocket", "network"],
    "Ferb": ["widget", "ui", "screen", "layout", "component", "flutter"],
    "Spike": ["focus", "guider", "mount", "tracking", "alignment", "calibration"],
    "Gandalf": ["transform", "convert", "parse", "format", "serialize", "decode"],
    "Luke": ["map", "galaxy", "dashboard", "fleet", "visualization", "chart"],
    "Bender": ["package", "bundle", "import", "dependency", "library", "upgrade"],
}


def import_fleet_log(db_conn: sqlite3.Connection, data: dict[str, Any], project_key: str) -> int:
    """Import a bob_fleet_log.json structure into the database.

    Args:
        db_conn: SQLite connection (WAL mode + foreign keys should already be set).
        data: The parsed JSON data matching the fleet log schema.
        project_key: Project key (e.g., "/Users/tdd/Dev/ARIS" or "ARIS").

    Returns:
        Number of missions imported.
    """
    cur = db_conn.cursor()

    try:
        # ---------------------------------------------------------------
        # 1. Project
        # ---------------------------------------------------------------
        project_info = data.get("project", {})
        cur.execute(
            """
            INSERT INTO projects (key, name, subtitle)
            VALUES (?, ?, ?)
            ON CONFLICT(key) DO UPDATE SET
                name     = excluded.name,
                subtitle = excluded.subtitle
            """,
            (
                project_key,
                project_info.get("name", project_key),
                project_info.get("subtitle"),
            ),
        )
        project_id = cur.execute(
            "SELECT id FROM projects WHERE key = ?", (project_key,)
        ).fetchone()[0]

        # ---------------------------------------------------------------
        # 2. Systems
        # ---------------------------------------------------------------
        for sys in data.get("systems", []):
            pos = sys.get("position", {})
            cur.execute(
                """
                INSERT INTO systems
                    (project_id, slug, name, type, description, color,
                     position_x, position_y, scale, depth, visual,
                     date_range, commits)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(project_id, slug) DO UPDATE SET
                    name        = excluded.name,
                    type        = excluded.type,
                    description = excluded.description,
                    color       = excluded.color,
                    position_x  = excluded.position_x,
                    position_y  = excluded.position_y,
                    scale       = excluded.scale,
                    depth       = excluded.depth,
                    visual      = excluded.visual,
                    date_range  = excluded.date_range,
                    commits     = excluded.commits
                """,
                (
                    project_id,
                    sys["id"],
                    sys["name"],
                    sys.get("type", "unexplored"),
                    sys.get("description"),
                    sys.get("color"),
                    pos.get("x"),
                    pos.get("y"),
                    sys.get("scale", 0.7),
                    sys.get("depth", 0),
                    sys.get("visual", "star"),
                    sys.get("dateRange"),
                    sys.get("commits"),
                ),
            )

        # ---------------------------------------------------------------
        # 3. Travel path
        # ---------------------------------------------------------------
        cur.execute("DELETE FROM travel_path WHERE project_id = ?", (project_id,))
        for order, slug in enumerate(data.get("travelPath", [])):
            cur.execute(
                "INSERT INTO travel_path (project_id, system_slug, sort_order) VALUES (?, ?, ?)",
                (project_id, slug, order),
            )

        # ---------------------------------------------------------------
        # 4. Dependencies
        # ---------------------------------------------------------------
        cur.execute("DELETE FROM dependencies WHERE project_id = ?", (project_id,))
        for dep in data.get("dependencies", []):
            cur.execute(
                "INSERT INTO dependencies (project_id, from_system, to_system, label) VALUES (?, ?, ?, ?)",
                (project_id, dep["from"], dep["to"], dep.get("label")),
            )

        # ---------------------------------------------------------------
        # 5. Bobs roster
        # ---------------------------------------------------------------
        # "bobs" can be either a dict {name: {emoji, color}} or a list [{name, emoji, color}]
        raw_bobs = data.get("bobs", {})
        if isinstance(raw_bobs, list):
            bobs_dict = {b["name"]: b for b in raw_bobs}
        else:
            bobs_dict = raw_bobs

        for bob_name, info in bobs_dict.items():
            keywords = DEFAULT_ROSTER_KEYWORDS.get(bob_name, [])
            cur.execute(
                """
                INSERT INTO bobs_roster (project_id, name, emoji, color, keywords)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(project_id, name) DO UPDATE SET
                    emoji    = excluded.emoji,
                    color    = excluded.color,
                    keywords = excluded.keywords
                """,
                (
                    project_id,
                    bob_name,
                    info.get("emoji"),
                    info.get("color"),
                    json.dumps(keywords),
                ),
            )

        # Also add any roster names that weren't in the JSON bobs dict
        for bob_name, keywords in DEFAULT_ROSTER_KEYWORDS.items():
            if bob_name not in bobs_dict:
                cur.execute(
                    """
                    INSERT OR IGNORE INTO bobs_roster
                        (project_id, name, emoji, color, keywords)
                    VALUES (?, ?, NULL, NULL, ?)
                    """,
                    (project_id, bob_name, json.dumps(keywords)),
                )

        # ---------------------------------------------------------------
        # 6. Missions (with bobs + pipeline)
        # ---------------------------------------------------------------
        missions = data.get("missions", [])
        missions_imported = 0

        for mission in missions:
            mission_key = mission["id"]
            cur.execute(
                """
                INSERT INTO missions
                    (project_id, mission_key, name, system_slug, date, status, description)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(project_id, mission_key) DO UPDATE SET
                    name        = excluded.name,
                    system_slug = excluded.system_slug,
                    date        = excluded.date,
                    status      = excluded.status,
                    description = excluded.description
                """,
                (
                    project_id,
                    mission_key,
                    mission["name"],
                    mission.get("system", ""),
                    mission.get("date", ""),
                    mission.get("status", "in_progress"),
                    mission.get("description"),
                ),
            )
            mission_id = cur.execute(
                "SELECT id FROM missions WHERE project_id = ? AND mission_key = ?",
                (project_id, mission_key),
            ).fetchone()[0]

            # Mission bobs
            for bob in mission.get("bobs", []):
                cur.execute(
                    """
                    INSERT INTO mission_bobs (mission_id, bob_name, bob_emoji, role, status)
                    VALUES (?, ?, ?, ?, ?)
                    ON CONFLICT(mission_id, bob_name) DO UPDATE SET
                        bob_emoji = excluded.bob_emoji,
                        role      = excluded.role,
                        status    = excluded.status
                    """,
                    (
                        mission_id,
                        bob["name"],
                        bob.get("emoji"),
                        bob.get("role"),
                        bob.get("status", "in_progress"),
                    ),
                )

            # Pipeline steps — clear + reinsert to maintain order
            cur.execute("DELETE FROM pipeline_steps WHERE mission_id = ?", (mission_id,))
            for step in mission.get("pipeline", []):
                # "name" field is canonical, but some entries use "step" as the name
                step_name = step.get("name") or str(step.get("step", ""))
                cur.execute(
                    "INSERT INTO pipeline_steps (mission_id, step_name, status) VALUES (?, ?, ?)",
                    (mission_id, step_name, step.get("status", "pending")),
                )

            missions_imported += 1

        # ---------------------------------------------------------------
        # 7. Lifetime stats
        # ---------------------------------------------------------------
        stats = data.get("lifetime_stats", {})
        if stats:
            bugs_fixed = stats.get("bugs_fixed", [])
            cur.execute(
                """
                INSERT INTO lifetime_stats
                    (project_id, total_bobs_deployed, total_files_touched, bugs_fixed)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(project_id) DO UPDATE SET
                    total_bobs_deployed = excluded.total_bobs_deployed,
                    total_files_touched = excluded.total_files_touched,
                    bugs_fixed          = excluded.bugs_fixed
                """,
                (
                    project_id,
                    stats.get("total_bobs_deployed", 0),
                    stats.get("total_files_touched", 0),
                    json.dumps(bugs_fixed) if isinstance(bugs_fixed, list) else bugs_fixed,
                ),
            )

        db_conn.commit()
        return missions_imported

    except Exception:
        db_conn.rollback()
        raise
