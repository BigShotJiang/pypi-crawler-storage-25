"""Bob Fleet CLI entry point — ``python3 -m bob_fleet``."""

import argparse
import json
import sys


def main():
    parser = argparse.ArgumentParser(
        description="Bob Fleet -- Fleet Command for Claude Code",
    )
    sub = parser.add_subparsers(dest="command")

    # serve -----------------------------------------------------------
    serve_parser = sub.add_parser("serve", help="Start the fleet server")
    serve_parser.add_argument("--host", default=None)
    serve_parser.add_argument("--port", type=int, default=None)
    serve_parser.add_argument(
        "--daemon", action="store_true", help="Run as background daemon"
    )

    # status ----------------------------------------------------------
    sub.add_parser("status", help="Check server status")

    # stop ------------------------------------------------------------
    sub.add_parser("stop", help="Stop the server")

    # import ----------------------------------------------------------
    import_parser = sub.add_parser("import", help="Import bob_fleet_log.json")
    import_parser.add_argument("file", help="Path to bob_fleet_log.json")
    import_parser.add_argument("--project", default="default")

    # install-hooks ----------------------------------------------------
    hooks_parser = sub.add_parser(
        "install-hooks", help="Install Claude Code hooks for fleet tracking"
    )
    hooks_parser.add_argument(
        "--settings", help="Path to settings.local.json (default: .claude/settings.local.json)"
    )
    hooks_parser.add_argument(
        "--no-merge", action="store_true", help="Overwrite hooks instead of merging"
    )

    args = parser.parse_args()

    if args.command == "serve":
        _cmd_serve(args)
    elif args.command == "status":
        _cmd_status()
    elif args.command == "stop":
        _cmd_stop()
    elif args.command == "import":
        _cmd_import(args)
    elif args.command == "install-hooks":
        _cmd_install_hooks(args)
    else:
        parser.print_help()
        sys.exit(1)


# ---------------------------------------------------------------------------
# Sub-commands
# ---------------------------------------------------------------------------

def _cmd_serve(args):
    import uvicorn
    from bob_fleet.config import HOST, PORT

    host = args.host or HOST
    port = args.port or PORT

    if args.daemon:
        import os
        from bob_fleet.config import PID_FILE, DATA_DIR

        pid = os.fork()
        if pid > 0:
            # Parent — record PID and exit
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            PID_FILE.write_text(str(pid))
            print(f"Bob Fleet server started (PID {pid}) on http://{host}:{port}")
            sys.exit(0)
        # Child — detach from terminal
        os.setsid()

    from bob_fleet.server import create_app

    app = create_app()
    uvicorn.run(app, host=host, port=port, log_level="info")


def _cmd_status():
    import urllib.request
    from bob_fleet.config import PORT

    try:
        resp = urllib.request.urlopen(
            f"http://127.0.0.1:{PORT}/api/v1/health", timeout=2
        )
        data = json.loads(resp.read())
        print(f"Bob Fleet is running -- {data}")
    except Exception:
        print("Bob Fleet is not running")


def _cmd_stop():
    import urllib.request
    from bob_fleet.config import PORT

    try:
        urllib.request.urlopen(
            urllib.request.Request(
                f"http://127.0.0.1:{PORT}/api/v1/shutdown", method="POST"
            ),
            timeout=2,
        )
        print("Shutdown signal sent")
    except Exception:
        print("Server not running or already stopped")


def _cmd_import(args):
    from bob_fleet.db import init_db, get_db, close_db
    from bob_fleet.logic.migration import import_fleet_log

    init_db()
    db = get_db()
    with open(args.file) as f:
        data = json.load(f)
    count = import_fleet_log(db, data, args.project)
    close_db()
    print(f"Imported {count} missions into project '{args.project}'")


def _cmd_install_hooks(args):
    from bob_fleet.hooks.install import install_hooks

    path = install_hooks(args.settings, merge=not args.no_merge)
    print(f"Bob Fleet hooks installed at {path}")
    print()
    print("Hooks configured:")
    print("  SessionStart  -> session_start")
    print("  Stop          -> session_end")
    print("  PreToolUse    -> agent_launch (Agent tool)")
    print("  PostToolUse   -> agent_complete (Agent tool)")
    print()
    print("Restart Claude Code for hooks to take effect.")


if __name__ == "__main__":
    main()
