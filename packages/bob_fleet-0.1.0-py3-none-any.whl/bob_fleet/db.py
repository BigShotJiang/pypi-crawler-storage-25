"""SQLite database layer for Bob Fleet.

Uses WAL mode for concurrent read access from the dashboard while
the API writes session/mission data.  All queries use raw sqlite3 —
no ORM.
"""

import sqlite3
import threading
from pathlib import Path

from bob_fleet.config import DATA_DIR, DB_PATH

# ---------------------------------------------------------------------------
# Thread-local storage for connections (one per FastAPI worker thread)
# ---------------------------------------------------------------------------
_local = threading.local()

# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------

_TABLES = """
-- Projects tracked by the fleet
CREATE TABLE IF NOT EXISTS projects (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    key         TEXT UNIQUE NOT NULL,
    name        TEXT NOT NULL,
    subtitle    TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Star systems on the galaxy map (features / areas of work)
CREATE TABLE IF NOT EXISTS systems (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id  INTEGER NOT NULL REFERENCES projects(id),
    slug        TEXT NOT NULL,
    name        TEXT NOT NULL,
    type        TEXT NOT NULL DEFAULT 'unexplored',
    description TEXT,
    color       TEXT,
    position_x  REAL,
    position_y  REAL,
    scale       REAL DEFAULT 0.7,
    depth       INTEGER DEFAULT 0,
    visual      TEXT DEFAULT 'star',
    date_range  TEXT,
    commits     INTEGER,
    UNIQUE(project_id, slug)
);

-- Edges between systems (galaxy map hyperlanes)
CREATE TABLE IF NOT EXISTS dependencies (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id  INTEGER NOT NULL REFERENCES projects(id),
    from_system TEXT NOT NULL,
    to_system   TEXT NOT NULL,
    label       TEXT
);

-- Ordered travel path across systems
CREATE TABLE IF NOT EXISTS travel_path (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id  INTEGER NOT NULL REFERENCES projects(id),
    system_slug TEXT NOT NULL,
    sort_order  INTEGER NOT NULL
);

-- Missions (one per Claude Code session or manual creation)
CREATE TABLE IF NOT EXISTS missions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id  INTEGER NOT NULL REFERENCES projects(id),
    mission_key TEXT NOT NULL,
    name        TEXT NOT NULL,
    system_slug TEXT NOT NULL,
    date        TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'in_progress',
    description TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(project_id, mission_key)
);

-- Bobs assigned to missions
CREATE TABLE IF NOT EXISTS mission_bobs (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    mission_id   INTEGER NOT NULL REFERENCES missions(id),
    bob_name     TEXT NOT NULL,
    bob_emoji    TEXT,
    role         TEXT,
    status       TEXT NOT NULL DEFAULT 'in_progress',
    scope        TEXT,
    started_at   TEXT,
    completed_at TEXT,
    duration_ms  INTEGER,
    UNIQUE(mission_id, bob_name)
);

-- Pipeline steps for a mission (build, test, deploy, etc.)
CREATE TABLE IF NOT EXISTS pipeline_steps (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    mission_id  INTEGER NOT NULL REFERENCES missions(id),
    step_name   TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'pending'
);

-- Active Claude Code sessions
CREATE TABLE IF NOT EXISTS sessions (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id              INTEGER NOT NULL REFERENCES projects(id),
    session_key             TEXT UNIQUE NOT NULL,
    worktree                TEXT,
    coordinator_mission_id  INTEGER REFERENCES missions(id),
    bob_counter             INTEGER DEFAULT 0,
    active                  INTEGER DEFAULT 1,
    created_at              TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Sub-agents spawned within a session
CREATE TABLE IF NOT EXISTS session_agents (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id  INTEGER NOT NULL REFERENCES sessions(id),
    description TEXT NOT NULL,
    bob_name    TEXT,
    mission_id  INTEGER REFERENCES missions(id)
);

-- Reusable Bob roster per project (name → emoji/color/keywords mapping)
CREATE TABLE IF NOT EXISTS bobs_roster (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id  INTEGER NOT NULL REFERENCES projects(id),
    name        TEXT NOT NULL,
    emoji       TEXT,
    color       TEXT,
    keywords    TEXT,
    UNIQUE(project_id, name)
);

-- Lifetime aggregate stats per project
CREATE TABLE IF NOT EXISTS lifetime_stats (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id          INTEGER NOT NULL REFERENCES projects(id) UNIQUE,
    total_bobs_deployed INTEGER DEFAULT 0,
    total_files_touched INTEGER DEFAULT 0,
    bugs_fixed          TEXT DEFAULT '[]'
);
"""

_INDEXES = """
CREATE INDEX IF NOT EXISTS idx_missions_project_date
    ON missions(project_id, date);

CREATE INDEX IF NOT EXISTS idx_missions_project_status
    ON missions(project_id, status);

CREATE INDEX IF NOT EXISTS idx_mission_bobs_mission
    ON mission_bobs(mission_id);

CREATE INDEX IF NOT EXISTS idx_sessions_project_active
    ON sessions(project_id, active);
"""


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def init_db() -> None:
    """Create the data directory and initialise the database schema.

    Safe to call multiple times — uses IF NOT EXISTS throughout.
    """
    Path(DATA_DIR).mkdir(parents=True, exist_ok=True)

    conn = sqlite3.connect(str(DB_PATH))
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.executescript(_TABLES)
    conn.executescript(_INDEXES)
    # Migrate: add new columns to existing tables (safe if already present)
    for col, typ in [("scope", "TEXT"), ("started_at", "TEXT"),
                     ("completed_at", "TEXT"), ("duration_ms", "INTEGER")]:
        try:
            conn.execute(f"ALTER TABLE mission_bobs ADD COLUMN {col} {typ}")
        except sqlite3.OperationalError:
            pass  # Column already exists
    # Migrate: add session duration tracking columns
    for col, typ in [("completed_at", "TEXT"), ("duration_ms", "INTEGER")]:
        try:
            conn.execute(f"ALTER TABLE sessions ADD COLUMN {col} {typ}")
        except sqlite3.OperationalError:
            pass  # Column already exists
    conn.commit()
    conn.close()


def get_db() -> sqlite3.Connection:
    """Return a thread-local database connection.

    Creates the connection on first call per thread.  Enables WAL mode,
    foreign keys, and ``Row`` factory so results behave like dicts.
    """
    conn: sqlite3.Connection | None = getattr(_local, "conn", None)
    if conn is None:
        conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.row_factory = sqlite3.Row
        _local.conn = conn
    return conn


def close_db() -> None:
    """Close the thread-local connection if one is open."""
    conn: sqlite3.Connection | None = getattr(_local, "conn", None)
    if conn is not None:
        conn.close()
        _local.conn = None
