"""Fleet data endpoint and SSE stream for live dashboard updates."""

import asyncio
import json

from fastapi import APIRouter, Depends, Request
from sse_starlette.sse import EventSourceResponse

from bob_fleet.db import get_db

router = APIRouter()

# ---------------------------------------------------------------------------
# SSE subscriber management
# ---------------------------------------------------------------------------

# Subscribers keyed by project_key.  The special key ``"*"`` receives
# notifications for *every* project (useful for global dashboards).
_subscribers: dict[str, list[asyncio.Queue]] = {}
_main_loop: asyncio.AbstractEventLoop | None = None


def notify_subscribers(project_key: str = "*") -> None:
    """Push an update event to SSE clients watching *project_key*.

    Sync route handlers run in a threadpool, so we need
    ``call_soon_threadsafe`` to safely enqueue to the asyncio queues
    that the SSE generator awaits on.
    """
    targets: list[asyncio.Queue] = []
    targets.extend(_subscribers.get(project_key, []))
    if project_key != "*":
        targets.extend(_subscribers.get("*", []))
    if not targets:
        return
    for q in targets:
        if _main_loop is not None:
            _main_loop.call_soon_threadsafe(q.put_nowait, "update")
        else:
            q.put_nowait("update")


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@router.get("/fleet-data")
def get_fleet_data(project: str = "default", db=Depends(get_db)):
    """Return the full fleet data JSON.

    Backward-compatible with the old ``bob_fleet_log.json`` shape so
    existing dashboards keep working.
    """
    from bob_fleet.logic.fleet_assembler import assemble_fleet_data
    return assemble_fleet_data(db, project)


@router.get("/events")
async def events(request: Request, project: str = "*"):
    """Server-Sent Events endpoint for live dashboard updates.

    Clients receive an ``update`` event whenever fleet data changes.
    Pass ``?project=ARIS`` to only receive notifications for that project,
    or omit / pass ``*`` for all projects.
    """
    global _main_loop
    if _main_loop is None:
        _main_loop = asyncio.get_running_loop()

    queue: asyncio.Queue = asyncio.Queue()
    bucket = _subscribers.setdefault(project, [])
    bucket.append(queue)

    async def event_generator():
        try:
            while True:
                if await request.is_disconnected():
                    break
                data = await queue.get()
                yield {"event": "fleet-update", "data": json.dumps({"type": data})}
        except asyncio.CancelledError:
            pass
        finally:
            bucket = _subscribers.get(project, [])
            if queue in bucket:
                bucket.remove(queue)
            # Clean up empty buckets
            if not bucket and project in _subscribers:
                _subscribers.pop(project, None)

    return EventSourceResponse(event_generator())
