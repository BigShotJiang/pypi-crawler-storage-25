"""Admin endpoints — health, import, shutdown, projects."""

import os
import signal
import time

from fastapi import APIRouter, Depends

from bob_fleet.db import get_db
from bob_fleet.models import ImportRequest, HealthResponse
from bob_fleet.routes.fleet_data import notify_subscribers

router = APIRouter()

_start_time: float = time.time()


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@router.get("/health", response_model=HealthResponse)
def health(db=Depends(get_db)):
    """Health check — returns version, uptime, and active session count."""
    from bob_fleet import __version__

    row = db.execute(
        "SELECT COUNT(*) FROM sessions WHERE active = 1"
    ).fetchone()
    active_sessions = row[0] if row else 0

    return HealthResponse(
        status="ok",
        version=__version__,
        uptime_seconds=round(time.time() - _start_time, 1),
        active_sessions=active_sessions,
    )


@router.post("/import")
def import_data(
    request: ImportRequest,
    project: str = "default",
    db=Depends(get_db),
):
    """Import a ``bob_fleet_log.json`` structure into the database."""
    from bob_fleet.logic.migration import import_fleet_log

    count = import_fleet_log(db, request.data, project)
    notify_subscribers(project)
    return {"imported_missions": count}


@router.post("/shutdown")
def shutdown():
    """Graceful shutdown — sends SIGTERM to the current process."""
    os.kill(os.getpid(), signal.SIGTERM)
    return {"status": "shutting_down"}


@router.get("/projects")
def list_projects(db=Depends(get_db)):
    """List all known projects."""
    rows = db.execute("SELECT key, name, subtitle FROM projects").fetchall()
    return [{"key": r["key"], "name": r["name"], "subtitle": r["subtitle"]} for r in rows]
