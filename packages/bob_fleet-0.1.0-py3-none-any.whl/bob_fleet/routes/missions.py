"""Mission CRUD endpoints."""

from __future__ import annotations

from datetime import date

from fastapi import APIRouter, Depends, HTTPException, Query

from bob_fleet.db import get_db
from bob_fleet.models import (
    AddBobRequest,
    CreateMissionRequest,
    PipelineStepRequest,
    UpdateBobRequest,
    UpdateMissionRequest,
)
from bob_fleet.routes.fleet_data import notify_subscribers

router = APIRouter()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get_project_id(db, project_key: str) -> int:
    row = db.execute("SELECT id FROM projects WHERE key = ?", (project_key,)).fetchone()
    if row is None:
        row = db.execute("SELECT id FROM projects ORDER BY id LIMIT 1").fetchone()
    if row is None:
        raise HTTPException(404, "No projects found")
    return row["id"]


def _next_mission_key(db, project_id: int) -> str:
    row = db.execute(
        "SELECT mission_key FROM missions WHERE project_id = ? ORDER BY id DESC LIMIT 1",
        (project_id,),
    ).fetchone()
    if row is None:
        return "M-001"
    try:
        num = int(row["mission_key"].split("-", 1)[1])
    except (IndexError, ValueError):
        num = 0
    return f"M-{num + 1:03d}"


def _get_mission(db, project_id: int, mission_key: str):
    """Fetch a mission row or raise 404."""
    row = db.execute(
        "SELECT * FROM missions WHERE project_id = ? AND mission_key = ?",
        (project_id, mission_key),
    ).fetchone()
    if row is None:
        raise HTTPException(404, f"Mission {mission_key} not found")
    return row


def _mission_to_dict(db, mission_row) -> dict:
    """Build a full mission dict with nested bobs and pipeline steps."""
    mid = mission_row["id"]
    m = dict(mission_row)

    bobs = db.execute(
        "SELECT bob_name, bob_emoji, role, status FROM mission_bobs WHERE mission_id = ?",
        (mid,),
    ).fetchall()
    m["bobs"] = [dict(b) for b in bobs]

    steps = db.execute(
        "SELECT step_name, status FROM pipeline_steps WHERE mission_id = ?",
        (mid,),
    ).fetchall()
    m["pipeline"] = [dict(s) for s in steps]

    return m


def _ensure_system(db, project_id: int, slug: str) -> None:
    exists = db.execute(
        "SELECT 1 FROM systems WHERE project_id = ? AND slug = ?",
        (project_id, slug),
    ).fetchone()
    if exists is None:
        display = slug.replace("-", " ").title()
        db.execute(
            "INSERT INTO systems (project_id, slug, name, type) VALUES (?, ?, ?, 'unexplored')",
            (project_id, slug, display),
        )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@router.get("/missions")
def list_missions(
    project: str = "default",
    status: str | None = None,
    system: str | None = None,
    date_filter: str | None = Query(None, alias="date"),
    db=Depends(get_db),
):
    """List missions, optionally filtered by status, system, and/or date."""
    project_id = _get_project_id(db, project)

    query = "SELECT * FROM missions WHERE project_id = ?"
    params: list = [project_id]

    if status is not None:
        query += " AND status = ?"
        params.append(status)
    if system is not None:
        query += " AND system_slug = ?"
        params.append(system)
    if date_filter is not None:
        query += " AND date = ?"
        params.append(date_filter)

    query += " ORDER BY id DESC"
    rows = db.execute(query, params).fetchall()

    return [_mission_to_dict(db, row) for row in rows]


@router.post("/missions")
def create_mission(
    request: CreateMissionRequest,
    project: str = "default",
    db=Depends(get_db),
):
    """Create a standalone mission."""
    project_id = _get_project_id(db, project)
    mission_key = _next_mission_key(db, project_id)
    today = date.today().isoformat()

    _ensure_system(db, project_id, request.system)

    db.execute(
        "INSERT INTO missions (project_id, mission_key, name, system_slug, date, status, description) "
        "VALUES (?, ?, ?, ?, ?, 'in_progress', ?)",
        (project_id, mission_key, request.name, request.system, today, request.description),
    )
    db.commit()

    notify_subscribers(project)

    mission = db.execute(
        "SELECT * FROM missions WHERE project_id = ? AND mission_key = ?",
        (project_id, mission_key),
    ).fetchone()
    return _mission_to_dict(db, mission)


@router.get("/missions/{mission_key}")
def get_mission(mission_key: str, project: str = "default", db=Depends(get_db)):
    """Get a single mission by key."""
    project_id = _get_project_id(db, project)
    mission = _get_mission(db, project_id, mission_key)
    return _mission_to_dict(db, mission)


@router.patch("/missions/{mission_key}")
def update_mission(
    mission_key: str,
    request: UpdateMissionRequest,
    project: str = "default",
    db=Depends(get_db),
):
    """Partially update a mission."""
    project_id = _get_project_id(db, project)
    mission = _get_mission(db, project_id, mission_key)

    updates: list[str] = []
    params: list = []

    if request.status is not None:
        updates.append("status = ?")
        params.append(request.status)
    if request.system is not None:
        _ensure_system(db, project_id, request.system)
        updates.append("system_slug = ?")
        params.append(request.system)
    if request.name is not None:
        updates.append("name = ?")
        params.append(request.name)

    if not updates:
        return _mission_to_dict(db, mission)

    params.append(mission["id"])
    db.execute(
        f"UPDATE missions SET {', '.join(updates)} WHERE id = ?",
        params,
    )
    db.commit()

    notify_subscribers(project)

    updated = _get_mission(db, project_id, mission_key)
    return _mission_to_dict(db, updated)


@router.post("/missions/{mission_key}/bobs")
def add_bob(
    mission_key: str,
    request: AddBobRequest,
    project: str = "default",
    db=Depends(get_db),
):
    """Add a Bob to a mission."""
    project_id = _get_project_id(db, project)
    mission = _get_mission(db, project_id, mission_key)

    try:
        db.execute(
            "INSERT INTO mission_bobs (mission_id, bob_name, bob_emoji, role, status) "
            "VALUES (?, ?, ?, ?, ?)",
            (mission["id"], request.name, request.emoji, request.role, request.status),
        )
        db.commit()
    except Exception:
        raise HTTPException(409, f"Bob '{request.name}' already exists on mission {mission_key}")

    notify_subscribers(project)

    return {"status": "ok", "bob_name": request.name, "mission_key": mission_key}


@router.patch("/missions/{mission_key}/bobs/{bob_name}")
def update_bob(
    mission_key: str,
    bob_name: str,
    request: UpdateBobRequest,
    project: str = "default",
    db=Depends(get_db),
):
    """Update a Bob's status on a mission."""
    project_id = _get_project_id(db, project)
    mission = _get_mission(db, project_id, mission_key)
    mid = mission["id"]

    bob = db.execute(
        "SELECT id FROM mission_bobs WHERE mission_id = ? AND bob_name = ?",
        (mid, bob_name),
    ).fetchone()
    if bob is None:
        raise HTTPException(404, f"Bob '{bob_name}' not found on mission {mission_key}")

    db.execute(
        "UPDATE mission_bobs SET status = ? WHERE id = ?",
        (request.status, bob["id"]),
    )

    # Auto-complete mission if all bobs are done
    if request.status == "complete":
        incomplete = db.execute(
            "SELECT COUNT(*) FROM mission_bobs WHERE mission_id = ? AND status != 'complete'",
            (mid,),
        ).fetchone()
        if incomplete[0] == 0:
            db.execute("UPDATE missions SET status = 'complete' WHERE id = ?", (mid,))

    db.commit()
    notify_subscribers(project)

    return {"status": "ok", "bob_name": bob_name, "mission_key": mission_key}


@router.post("/missions/{mission_key}/pipeline")
def upsert_pipeline_step(
    mission_key: str,
    request: PipelineStepRequest,
    project: str = "default",
    db=Depends(get_db),
):
    """Create or update a pipeline step on a mission."""
    project_id = _get_project_id(db, project)
    mission = _get_mission(db, project_id, mission_key)
    mid = mission["id"]

    existing = db.execute(
        "SELECT id FROM pipeline_steps WHERE mission_id = ? AND step_name = ?",
        (mid, request.step_name),
    ).fetchone()

    if existing is not None:
        db.execute(
            "UPDATE pipeline_steps SET status = ? WHERE id = ?",
            (request.status, existing["id"]),
        )
    else:
        db.execute(
            "INSERT INTO pipeline_steps (mission_id, step_name, status) VALUES (?, ?, ?)",
            (mid, request.step_name, request.status),
        )

    db.commit()
    notify_subscribers(project)

    return {"status": "ok", "step_name": request.step_name, "mission_key": mission_key}
