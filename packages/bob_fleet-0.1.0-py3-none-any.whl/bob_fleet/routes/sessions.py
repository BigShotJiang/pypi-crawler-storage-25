"""Session lifecycle endpoints."""

from __future__ import annotations

import uuid
from datetime import date

from fastapi import APIRouter, Depends, HTTPException, Query

from bob_fleet.db import get_db
from bob_fleet.logic.bob_picker import pick_bob
from bob_fleet.logic.system_detector import detect_system
from bob_fleet.models import (
    AgentLaunchRequest,
    AgentLaunchResponse,
    CreateSessionRequest,
    CreateSessionResponse,
)
from bob_fleet.routes.fleet_data import notify_subscribers

router = APIRouter()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _resolve_project_dir(project_dir: str) -> str:
    """Resolve worktree paths back to the parent project directory.

    Worktree paths like ``/foo/ARIS/.claude/worktrees/some-name`` are
    collapsed to ``/foo/ARIS`` so that all sessions (main and worktree)
    group under the same project.
    """
    cleaned = project_dir.rstrip("/")
    marker = "/.claude/worktrees/"
    idx = cleaned.find(marker)
    if idx != -1:
        cleaned = cleaned[:idx]
    return cleaned


def _get_or_create_project(db, project_dir: str, name: str | None, subtitle: str | None) -> tuple[int, str]:
    """Return (project_id, project_key), creating the project if needed."""
    project_key = _resolve_project_dir(project_dir).rsplit("/", 1)[-1]
    row = db.execute("SELECT id FROM projects WHERE key = ?", (project_key,)).fetchone()
    if row is not None:
        pid = row["id"]
        # Update name/subtitle if provided
        if name:
            db.execute("UPDATE projects SET name = ? WHERE id = ?", (name, pid))
        if subtitle:
            db.execute("UPDATE projects SET subtitle = ? WHERE id = ?", (subtitle, pid))
        db.commit()
        return pid, project_key

    db.execute(
        "INSERT INTO projects (key, name, subtitle) VALUES (?, ?, ?)",
        (project_key, name or project_key, subtitle or ""),
    )
    db.commit()
    pid = db.execute("SELECT last_insert_rowid()").fetchone()[0]
    return pid, project_key


def _next_mission_key(db, project_id: int) -> str:
    """Generate the next sequential mission key like M-001, M-002, etc."""
    row = db.execute(
        "SELECT mission_key FROM missions WHERE project_id = ? ORDER BY id DESC LIMIT 1",
        (project_id,),
    ).fetchone()
    if row is None:
        return "M-001"
    last_key: str = row["mission_key"]
    # Parse the numeric suffix
    try:
        num = int(last_key.split("-", 1)[1])
    except (IndexError, ValueError):
        num = 0
    return f"M-{num + 1:03d}"


def _ensure_system(db, project_id: int, slug: str) -> None:
    """Create the system row if it doesn't already exist."""
    exists = db.execute(
        "SELECT 1 FROM systems WHERE project_id = ? AND slug = ?",
        (project_id, slug),
    ).fetchone()
    if exists is None:
        display = slug.replace("-", " ").title()
        db.execute(
            "INSERT INTO systems (project_id, slug, name, type) VALUES (?, ?, ?, 'unexplored')",
            (project_id, slug, display),
        )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@router.post("/sessions", response_model=CreateSessionResponse)
def create_session(request: CreateSessionRequest, db=Depends(get_db)):
    """Create a new session with a coordinator mission."""
    project_id, project_key = _get_or_create_project(
        db, request.project_dir, request.project_name, request.project_subtitle,
    )

    session_key = str(uuid.uuid4())
    mission_key = _next_mission_key(db, project_id)
    today = date.today().isoformat()

    # Count today's missions for the sequence label
    seq_row = db.execute(
        "SELECT COUNT(*) FROM missions WHERE project_id = ? AND date = ?",
        (project_id, today),
    ).fetchone()
    seq = (seq_row[0] if seq_row else 0) + 1

    mission_name = f"Session {today} #{seq}"

    # Ensure the replicator system exists
    _ensure_system(db, project_id, "replicator")

    # Create coordinator mission
    db.execute(
        "INSERT INTO missions (project_id, mission_key, name, system_slug, date, status, description) "
        "VALUES (?, ?, ?, 'replicator', ?, 'in_progress', 'Coordinator mission')",
        (project_id, mission_key, mission_name, today),
    )
    db.commit()
    mission_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]

    # Coordinator is always "Bob" — the original, the one running the show
    db.execute(
        "INSERT INTO mission_bobs (mission_id, bob_name, bob_emoji, role, status) "
        "VALUES (?, 'Bob', '⭐', 'Coordinator', 'in_progress')",
        (mission_id,),
    )

    # Create session record
    db.execute(
        "INSERT INTO sessions (project_id, session_key, worktree, coordinator_mission_id, bob_counter, active) "
        "VALUES (?, ?, ?, ?, 0, 1)",
        (project_id, session_key, request.worktree, mission_id),
    )
    db.commit()

    notify_subscribers(project_key)

    return CreateSessionResponse(
        session_id=session_key,
        mission_key=mission_key,
        project_key=project_key,
    )


@router.delete("/sessions/{session_key}")
def end_session(session_key: str, db=Depends(get_db)):
    """End a session and complete all its missions."""
    session = db.execute(
        "SELECT s.id, s.coordinator_mission_id, p.key AS project_key "
        "FROM sessions s JOIN projects p ON p.id = s.project_id "
        "WHERE s.session_key = ?",
        (session_key,),
    ).fetchone()
    if session is None:
        raise HTTPException(404, f"Session {session_key} not found")

    session_id = session["id"]
    coordinator_mid = session["coordinator_mission_id"]

    # Gather all mission IDs tied to this session
    mission_ids: set[int] = set()
    if coordinator_mid is not None:
        mission_ids.add(coordinator_mid)

    agent_rows = db.execute(
        "SELECT mission_id FROM session_agents WHERE session_id = ?",
        (session_id,),
    ).fetchall()
    for row in agent_rows:
        if row["mission_id"] is not None:
            mission_ids.add(row["mission_id"])

    # Mark all incomplete missions and their bobs as complete
    completed_count = 0
    for mid in mission_ids:
        m = db.execute("SELECT status FROM missions WHERE id = ?", (mid,)).fetchone()
        if m and m["status"] not in ("complete", "completed"):
            db.execute(
                "UPDATE missions SET status = 'complete' WHERE id = ?", (mid,),
            )
            completed_count += 1
        db.execute(
            "UPDATE mission_bobs SET status = 'complete' WHERE mission_id = ? AND status != 'complete'",
            (mid,),
        )

    # Deactivate session with duration tracking
    db.execute(
        "UPDATE sessions SET active = 0, completed_at = datetime('now'), "
        "duration_ms = CAST((julianday('now') - julianday(created_at)) * 86400000 AS INTEGER) "
        "WHERE id = ?",
        (session_id,),
    )
    db.commit()

    notify_subscribers(session["project_key"])
    return {"status": "ok", "missions_completed": completed_count}


@router.post("/sessions/{session_key}/agents", response_model=AgentLaunchResponse)
def agent_launch(session_key: str, request: AgentLaunchRequest, db=Depends(get_db)):
    """Register an agent launch within a session."""
    session = db.execute(
        "SELECT s.id, s.project_id, s.coordinator_mission_id, s.bob_counter, p.key AS project_key "
        "FROM sessions s JOIN projects p ON p.id = s.project_id "
        "WHERE s.session_key = ? AND s.active = 1",
        (session_key,),
    ).fetchone()
    if session is None:
        raise HTTPException(404, f"Active session {session_key} not found")

    session_id = session["id"]
    project_id = session["project_id"]
    coordinator_mid = session["coordinator_mission_id"]
    bob_counter = session["bob_counter"]

    # Build bobs_added from ALL bobs on the current mission (any status).
    # This prevents name collisions where a completed Bob gets re-picked
    # and INSERT OR IGNORE silently drops the new agent.
    # Also include in-progress bobs from other active sessions for cross-session dedup.
    bobs_added: dict[str, str] = {}

    # 1) All bobs on this session's mission (regardless of status)
    if coordinator_mid is not None:
        mission_bobs = db.execute(
            "SELECT bob_name, role FROM mission_bobs WHERE mission_id = ?",
            (coordinator_mid,),
        ).fetchall()
        for row in mission_bobs:
            if row["bob_name"]:
                bobs_added[row["bob_name"]] = row["role"] or ""

    # 2) In-progress bobs from OTHER active sessions (cross-session dedup)
    other_agent_rows = db.execute(
        """SELECT sa.bob_name, sa.description
           FROM session_agents sa
           JOIN sessions s ON s.id = sa.session_id
           JOIN mission_bobs mb ON mb.mission_id = sa.mission_id AND mb.bob_name = sa.bob_name
           WHERE s.active = 1 AND s.id != ? AND mb.status IN ('in_progress', 'queued')""",
        (session_id,),
    ).fetchall()
    for row in other_agent_rows:
        if row["bob_name"] and row["bob_name"] not in bobs_added:
            bobs_added[row["bob_name"]] = row["description"]

    # Pick a Bob
    bob_name, bob_emoji = pick_bob(
        request.description, request.prompt, bobs_added, bob_counter,
    )

    # Detect system
    combined_text = f"{request.description} {request.prompt}"
    system_slug = detect_system(combined_text)

    # Ensure the system exists
    _ensure_system(db, project_id, system_slug)

    # On first agent launch, move coordinator mission to match this agent's system
    if system_slug != "replicator" and coordinator_mid is not None and bob_counter == 0:
        db.execute(
            "UPDATE missions SET system_slug = ? WHERE id = ? AND system_slug = 'replicator'",
            (system_slug, coordinator_mid),
        )

    # Always add agents as bobs on the coordinator mission (single mission per session)
    target_mission_id: int | None = None
    mission_key: str | None = None

    if coordinator_mid is not None:
        target_mission_id = coordinator_mid
        mk_row = db.execute(
            "SELECT mission_key FROM missions WHERE id = ?", (coordinator_mid,),
        ).fetchone()
        mission_key = mk_row["mission_key"] if mk_row else None

    # Fallback: create a new mission only if no coordinator exists
    if target_mission_id is None:
        mission_key = _next_mission_key(db, project_id)
        today = date.today().isoformat()
        db.execute(
            "INSERT INTO missions (project_id, mission_key, name, system_slug, date, status, description) "
            "VALUES (?, ?, ?, ?, ?, 'in_progress', ?)",
            (project_id, mission_key, request.description, system_slug, today, request.description),
        )
        db.commit()
        target_mission_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]

    # Add Bob to the mission (ignore conflict if already there)
    db.execute(
        "INSERT OR IGNORE INTO mission_bobs (mission_id, bob_name, bob_emoji, role, status, scope, started_at) "
        "VALUES (?, ?, ?, ?, 'in_progress', ?, datetime('now'))",
        (target_mission_id, bob_name, bob_emoji, request.description, request.description),
    )

    # Record in session_agents
    db.execute(
        "INSERT INTO session_agents (session_id, description, bob_name, mission_id) "
        "VALUES (?, ?, ?, ?)",
        (session_id, request.description, bob_name, target_mission_id),
    )

    # Increment bob_counter
    db.execute(
        "UPDATE sessions SET bob_counter = ? WHERE id = ?",
        (bob_counter + 1, session_id),
    )
    db.commit()

    notify_subscribers(session["project_key"])

    return AgentLaunchResponse(
        bob_name=bob_name,
        bob_emoji=bob_emoji,
        mission_key=mission_key,
        system=system_slug,
    )


@router.patch("/sessions/{session_key}/agents/{description}")
def agent_complete(
    session_key: str,
    description: str,
    db=Depends(get_db),
):
    """Mark an agent as complete."""
    session = db.execute(
        "SELECT s.id, p.key AS project_key "
        "FROM sessions s JOIN projects p ON p.id = s.project_id "
        "WHERE s.session_key = ?",
        (session_key,),
    ).fetchone()
    if session is None:
        raise HTTPException(404, f"Session {session_key} not found")

    agent = db.execute(
        "SELECT bob_name, mission_id FROM session_agents WHERE session_id = ? AND description = ?",
        (session["id"], description),
    ).fetchone()
    if agent is None:
        raise HTTPException(404, f"Agent '{description}' not found in session")

    bob_name = agent["bob_name"]
    mission_id = agent["mission_id"]
    mission_key: str | None = None

    if mission_id is not None:
        # Mark Bob as complete with timing
        db.execute(
            """UPDATE mission_bobs SET status = 'complete',
               completed_at = datetime('now'),
               duration_ms = CASE WHEN started_at IS NOT NULL
                   THEN CAST((julianday('now') - julianday(started_at)) * 86400000 AS INTEGER)
                   ELSE NULL END
            WHERE mission_id = ? AND bob_name = ?""",
            (mission_id, bob_name),
        )

        # Check if all bobs in this mission are now complete
        incomplete = db.execute(
            "SELECT COUNT(*) FROM mission_bobs WHERE mission_id = ? AND status != 'complete'",
            (mission_id,),
        ).fetchone()
        if incomplete[0] == 0:
            db.execute(
                "UPDATE missions SET status = 'complete' WHERE id = ?", (mission_id,),
            )

        mk_row = db.execute(
            "SELECT mission_key FROM missions WHERE id = ?", (mission_id,),
        ).fetchone()
        mission_key = mk_row["mission_key"] if mk_row else None

    db.commit()
    notify_subscribers(session["project_key"])

    return {"status": "ok", "bob_name": bob_name, "mission_key": mission_key}
