"""System CRUD endpoints."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel

from bob_fleet.db import get_db
from bob_fleet.routes.fleet_data import notify_subscribers

router = APIRouter()


# ---------------------------------------------------------------------------
# Request models
# ---------------------------------------------------------------------------

class CreateSystemRequest(BaseModel):
    slug: str
    name: str
    type: str = "unexplored"
    description: str | None = None
    color: str | None = None
    position_x: float | None = None
    position_y: float | None = None
    scale: float = 0.7
    depth: int = 0
    visual: str = "star"


class UpdateSystemRequest(BaseModel):
    name: str | None = None
    type: str | None = None
    description: str | None = None
    color: str | None = None
    position_x: float | None = None
    position_y: float | None = None
    scale: float | None = None
    depth: int | None = None
    visual: str | None = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get_project_id(db, project_key: str) -> int:
    row = db.execute("SELECT id FROM projects WHERE key = ?", (project_key,)).fetchone()
    if row is None:
        row = db.execute("SELECT id FROM projects ORDER BY id LIMIT 1").fetchone()
    if row is None:
        raise HTTPException(404, "No projects found")
    return row["id"]


def _get_system(db, project_id: int, slug: str):
    row = db.execute(
        "SELECT * FROM systems WHERE project_id = ? AND slug = ?",
        (project_id, slug),
    ).fetchone()
    if row is None:
        raise HTTPException(404, f"System '{slug}' not found")
    return row


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@router.get("/systems")
def list_systems(project: str = "default", db=Depends(get_db)):
    """List all systems for a project."""
    project_id = _get_project_id(db, project)
    rows = db.execute(
        "SELECT * FROM systems WHERE project_id = ? ORDER BY slug",
        (project_id,),
    ).fetchall()
    return [dict(r) for r in rows]


@router.post("/systems")
def create_system(
    request: CreateSystemRequest,
    project: str = "default",
    db=Depends(get_db),
):
    """Create a new system."""
    project_id = _get_project_id(db, project)

    existing = db.execute(
        "SELECT 1 FROM systems WHERE project_id = ? AND slug = ?",
        (project_id, request.slug),
    ).fetchone()
    if existing is not None:
        raise HTTPException(409, f"System '{request.slug}' already exists")

    db.execute(
        "INSERT INTO systems (project_id, slug, name, type, description, color, "
        "position_x, position_y, scale, depth, visual) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (
            project_id, request.slug, request.name, request.type,
            request.description, request.color,
            request.position_x, request.position_y,
            request.scale, request.depth, request.visual,
        ),
    )
    db.commit()

    notify_subscribers(project)

    system = _get_system(db, project_id, request.slug)
    return dict(system)


@router.get("/systems/{slug}")
def get_system(slug: str, project: str = "default", db=Depends(get_db)):
    """Get a single system by slug."""
    project_id = _get_project_id(db, project)
    system = _get_system(db, project_id, slug)
    return dict(system)


@router.patch("/systems/{slug}")
def update_system(
    slug: str,
    request: UpdateSystemRequest,
    project: str = "default",
    db=Depends(get_db),
):
    """Update a system."""
    project_id = _get_project_id(db, project)
    system = _get_system(db, project_id, slug)

    updates: list[str] = []
    params: list = []

    for field in ("name", "type", "description", "color", "position_x", "position_y", "scale", "depth", "visual"):
        value = getattr(request, field)
        if value is not None:
            updates.append(f"{field} = ?")
            params.append(value)

    if not updates:
        return dict(system)

    params.append(system["id"])
    db.execute(
        f"UPDATE systems SET {', '.join(updates)} WHERE id = ?",
        params,
    )
    db.commit()

    notify_subscribers(project)

    updated = _get_system(db, project_id, slug)
    return dict(updated)


@router.delete("/systems/{slug}")
def delete_system(slug: str, project: str = "default", db=Depends(get_db)):
    """Delete a system."""
    project_id = _get_project_id(db, project)
    system = _get_system(db, project_id, slug)

    db.execute("DELETE FROM systems WHERE id = ?", (system["id"],))
    db.commit()

    notify_subscribers(project)

    return {"status": "ok", "slug": slug}
