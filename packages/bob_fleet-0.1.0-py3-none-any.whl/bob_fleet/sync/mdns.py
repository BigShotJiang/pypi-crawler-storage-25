"""mDNS service advertisement for Bob Fleet server.

Advertises the server as `_bobfleet._tcp.local.` so the Bob Fleet Flutter
app can auto-discover it on the local network.
"""

import logging
import socket
import threading

from zeroconf import ServiceInfo, Zeroconf

logger = logging.getLogger(__name__)

_zeroconf: Zeroconf | None = None
_service_info: ServiceInfo | None = None
_thread: threading.Thread | None = None


def _register_in_background(port: int, project_key: str) -> None:
    """Run mDNS registration in a background thread to avoid blocking startup."""
    global _zeroconf, _service_info

    try:
        hostname = socket.gethostname()
        # Get local IPv4 addresses (skip loopback)
        addresses = []
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
            addresses = [socket.inet_aton(local_ip)]
        except Exception:
            # Try hostname resolution as fallback
            try:
                for info in socket.getaddrinfo(hostname, None, socket.AF_INET):
                    addr = info[4][0]
                    if not addr.startswith("127."):
                        addresses.append(socket.inet_aton(addr))
            except socket.gaierror:
                pass

        if not addresses:
            logger.warning("Could not determine local IP for mDNS")
            return

        _service_info = ServiceInfo(
            type_="_bobfleet._tcp.local.",
            name=f"Bob Fleet ({hostname})._bobfleet._tcp.local.",
            addresses=addresses,
            port=port,
            properties={
                "project": project_key,
                "version": "0.1.0",
            },
            server=f"{hostname}.local.",
        )

        _zeroconf = Zeroconf(interfaces=["0.0.0.0"])
        _zeroconf.register_service(_service_info, cooperating_responders=True)
        logger.info(
            "mDNS: advertising _bobfleet._tcp on port %d (project=%s)",
            port,
            project_key,
        )
    except Exception as e:
        logger.warning("mDNS registration failed: %s", e)


def start_mdns(port: int, project_key: str = "ARIS") -> None:
    """Start mDNS advertisement in a background thread (non-blocking)."""
    global _thread
    _thread = threading.Thread(
        target=_register_in_background,
        args=(port, project_key),
        daemon=True,
    )
    _thread.start()


def stop_mdns() -> None:
    """Unregister the mDNS service and close zeroconf."""
    global _zeroconf, _service_info, _thread

    if _thread is not None:
        _thread.join(timeout=2)
        _thread = None

    if _zeroconf is not None and _service_info is not None:
        try:
            _zeroconf.unregister_service(_service_info)
            _zeroconf.close()
            logger.info("mDNS: service unregistered")
        except Exception:
            pass
        _zeroconf = None
        _service_info = None
