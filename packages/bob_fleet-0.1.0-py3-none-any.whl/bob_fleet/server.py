"""Bob Fleet — FastAPI application factory."""

import asyncio
import sqlite3
import sys
import time
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from bob_fleet.config import HOST, PORT, AUTO_SHUTDOWN_MINUTES, SESSION_TTL_MINUTES
from bob_fleet.db import init_db, close_db, DB_PATH

# ---------------------------------------------------------------------------
# Activity tracking for auto-shutdown
# ---------------------------------------------------------------------------

_last_activity: float = time.time()


def touch_activity() -> None:
    """Record the timestamp of the most recent API call."""
    global _last_activity
    _last_activity = time.time()


# ---------------------------------------------------------------------------
# Auto-shutdown background task
# ---------------------------------------------------------------------------

async def _auto_shutdown_watchdog(timeout_minutes: int) -> None:
    """Exit the process if no API activity for *timeout_minutes*."""
    timeout_seconds = timeout_minutes * 60
    while True:
        await asyncio.sleep(60)
        idle = time.time() - _last_activity
        if idle >= timeout_seconds:
            print(
                f"[bob-fleet] No activity for {timeout_minutes}m — shutting down."
            )
            sys.exit(0)


# ---------------------------------------------------------------------------
# Stale session reaper
# ---------------------------------------------------------------------------

async def _stale_session_reaper(ttl_minutes: int) -> None:
    """Periodically complete sessions that have been active beyond the TTL.

    Catches orphans from crashed sessions, missed SessionEnd hooks, or
    self-healing key mismatches.
    """
    interval = max(ttl_minutes * 60 // 4, 300)  # check 4x per TTL, min 5 min
    while True:
        await asyncio.sleep(interval)
        try:
            conn = sqlite3.connect(str(DB_PATH))
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA foreign_keys=ON")
            conn.row_factory = sqlite3.Row
            try:
                stale = conn.execute(
                    "SELECT s.id, s.coordinator_mission_id, p.key AS project_key "
                    "FROM sessions s JOIN projects p ON p.id = s.project_id "
                    "WHERE s.active = 1 "
                    "AND s.created_at < datetime('now', ?)",
                    (f"-{ttl_minutes} minutes",),
                ).fetchall()

                if not stale:
                    continue

                project_keys: set[str] = set()
                for session in stale:
                    sid = session["id"]
                    # Gather all missions for this session
                    mission_ids: set[int] = set()
                    if session["coordinator_mission_id"] is not None:
                        mission_ids.add(session["coordinator_mission_id"])
                    for row in conn.execute(
                        "SELECT mission_id FROM session_agents WHERE session_id = ?",
                        (sid,),
                    ).fetchall():
                        if row["mission_id"] is not None:
                            mission_ids.add(row["mission_id"])

                    # Complete all incomplete missions and bobs
                    for mid in mission_ids:
                        conn.execute(
                            "UPDATE missions SET status = 'complete' "
                            "WHERE id = ? AND status NOT IN ('complete', 'completed')",
                            (mid,),
                        )
                        conn.execute(
                            "UPDATE mission_bobs SET status = 'complete' "
                            "WHERE mission_id = ? AND status != 'complete'",
                            (mid,),
                        )

                    conn.execute(
                        "UPDATE sessions SET active = 0, completed_at = datetime('now'), "
                        "duration_ms = CAST((julianday('now') - julianday(created_at)) * 86400000 AS INTEGER) "
                        "WHERE id = ?",
                        (sid,),
                    )
                    project_keys.add(session["project_key"])

                conn.commit()
                print(
                    f"[bob-fleet] Reaper: completed {len(stale)} stale session(s) "
                    f"older than {ttl_minutes}m"
                )

                # Notify dashboards
                from bob_fleet.routes.fleet_data import notify_subscribers
                for pk in project_keys:
                    notify_subscribers(pk)

            finally:
                conn.close()
        except Exception as exc:
            print(f"[bob-fleet] Reaper error: {exc}")


# ---------------------------------------------------------------------------
# Lifespan
# ---------------------------------------------------------------------------

@asynccontextmanager
async def _lifespan(app: FastAPI):
    # Startup
    init_db()

    # Advertise on local network via mDNS so the Bob Fleet app can find us
    try:
        from .sync.mdns import start_mdns, stop_mdns
        start_mdns(port=PORT)
    except Exception as e:
        logging.getLogger(__name__).warning("mDNS init failed: %s", e)
        stop_mdns = None  # type: ignore[assignment]

    shutdown_task = None
    if AUTO_SHUTDOWN_MINUTES > 0:
        shutdown_task = asyncio.create_task(
            _auto_shutdown_watchdog(AUTO_SHUTDOWN_MINUTES)
        )

    reaper_task = None
    if SESSION_TTL_MINUTES > 0:
        reaper_task = asyncio.create_task(
            _stale_session_reaper(SESSION_TTL_MINUTES)
        )

    yield

    # Shutdown
    if reaper_task is not None:
        reaper_task.cancel()
    if shutdown_task is not None:
        shutdown_task.cancel()
    if stop_mdns is not None:
        try:
            stop_mdns()
        except Exception:
            pass
    close_db()


# ---------------------------------------------------------------------------
# App factory
# ---------------------------------------------------------------------------

def create_app() -> FastAPI:
    """Build and return the configured FastAPI application."""
    app = FastAPI(
        title="Bob Fleet",
        description="Fleet Command dashboard API for Claude Code",
        version="0.1.0",
        lifespan=_lifespan,
    )

    # --- CORS (local-server permissive) ---
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # --- Activity-tracking middleware ---
    @app.middleware("http")
    async def _track_activity(request, call_next):
        touch_activity()
        return await call_next(request)

    # --- Routers ---
    from bob_fleet.routes import fleet_data, admin, sessions, missions, systems

    app.include_router(fleet_data.router, prefix="/api/v1")
    app.include_router(admin.router, prefix="/api/v1")
    app.include_router(sessions.router, prefix="/api/v1")
    app.include_router(missions.router, prefix="/api/v1")
    app.include_router(systems.router, prefix="/api/v1")

    # --- Static files (dashboard HTML) ---
    static_dir = Path(__file__).parent / "static"
    if static_dir.exists():
        app.mount("/static", StaticFiles(directory=static_dir), name="static")

    # --- Clean URLs for dashboard pages ---
    @app.get("/galaxy")
    def serve_galaxy():
        return FileResponse(static_dir / "galaxy_map.html")

    @app.get("/dashboard")
    def serve_dashboard():
        return FileResponse(static_dir / "bob_dashboard.html")

    return app
