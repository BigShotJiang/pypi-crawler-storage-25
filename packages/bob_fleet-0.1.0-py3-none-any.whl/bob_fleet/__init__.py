"""Bob Fleet — Fleet Command dashboard for Claude Code."""

__version__ = "0.1.0"
