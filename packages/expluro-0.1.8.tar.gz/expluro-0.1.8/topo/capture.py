"""
EventCapture — records every event in the session as a delta_event.
Writes a local JSONL append-log for crash safety and streams to the backend.

Three event sources:
  1. User messages     — record_user_message() called from session.py before send()
  2. Assistant text    — record_driver_event() called from session.py for each DriverEvent
  3. Tool calls        — pre/post hooks registered on the driver (fire mid-response)

Each event gets a uuid + parent_event_id forming a linked list, so the full
conversation can be reconstructed in order and branching points are precise.

All events hit the local JSONL log first, then the backend — local log is
the source of truth on crash.
"""
from __future__ import annotations

import json
import logging
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any

from .constants import APP_DIR

if TYPE_CHECKING:
    from .backend import BackendClient
    from .drivers.base import BaseDriver, DriverEvent, ToolHookPayload

logger = logging.getLogger(__name__)

# Tools that mutate filesystem state and warrant a world-state snapshot
SIDE_EFFECTING_TOOLS = {
    "Edit", "Write", "MultiEdit", "NotebookEdit",
    "Bash",  # conservative — not all Bash calls are side-effecting,
             # but we snapshot after all of them and let SnapshotManager dedupe
}

SESSIONS_DIR = Path.home() / APP_DIR / "sessions"


class EventCapture:
    """
    Observes every tool call the driver makes and records it as a delta_event.

    Usage:
        capture = EventCapture(backend, graph_id, node_id)
        capture.register(driver)   # before driver.connect()
        # ... run session ...
        capture.close()
    """

    def __init__(
        self,
        backend: "BackendClient",
        graph_id: str,
        node_id: str,
    ) -> None:
        self._backend = backend
        self._graph_id = graph_id
        self._node_id = node_id
        self._last_event_id: str | None = None
        # Accumulated streaming text for the current turn.
        # Flushed as message_ai on turn_result if text_complete never fires
        # (e.g. when a tool is denied mid-response).
        self._streamed_text_buffer: str = ""
        self._text_complete_fired: bool = False

        SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
        self._log_file = self._open_log(node_id)
        logger.debug("EventCapture initialized — log: %s", SESSIONS_DIR / f"{node_id}.jsonl")

    @property
    def node_id(self) -> str:
        return self._node_id

    def register(self, driver: "BaseDriver") -> None:
        """Wire pre/post tool hooks onto the driver."""
        driver.register_pre_tool_hook(self._on_pre_tool)
        driver.register_post_tool_hook(self._on_post_tool)

    def switch_node(self, new_node_id: str) -> None:
        """Switch all future events to a new node. Opens a new per-node log file."""
        logger.info("EventCapture switching from node %s to %s", self._node_id, new_node_id)
        self._log_file.close()
        self._node_id = new_node_id
        self._last_event_id = None
        self._streamed_text_buffer = ""
        self._text_complete_fired = False
        self._log_file = self._open_log(new_node_id)

    def close(self) -> None:
        self._log_file.close()

    def _open_log(self, node_id: str):
        path = SESSIONS_DIR / f"{node_id}.jsonl"
        return path.open("a", encoding="utf-8")

    # ------------------------------------------------------------------
    # Public recording methods — called from session.py
    # ------------------------------------------------------------------

    async def record_branch(self, branched_from_event_id: str) -> None:
        """Record a branch event. Called by NodeManager when the current node is frozen
        and a new child node is created. branched_from_event_id is the exact event in
        the parent node's chain where the split happened."""
        event = self._build_event(
            event_type="branch",
            tool_name="",
            tool_use_id="",
            data={},
            branched_from_event_id=branched_from_event_id,
        )
        await self._record(event)

    async def record_user_message(self, text: str) -> None:
        """Record a user prompt as a durable event on the current node.

        Called *after* the auto-branch decision is resolved (or after the first
        non-branch_signal event arrives, when no branch fires). At that point
        capture.node_id already points at the correct destination — parent if
        no branch fired, child if it did — so the durable record always lands
        on the node that actually owns this message.

        For the live browser bubble, see broadcast_user_message_live() — that
        runs *before* the driver send and is non-persistent.
        """
        event = self._build_event(
            event_type="message_user",
            tool_name="",
            tool_use_id="",
            data={"text": text},
        )
        backend_id = await self._record(event)
        # Use backend-assigned ID if available; fall back to CLI-generated UUID.
        # The backend generates its own PK — the CLI UUID is never stored in the DB.
        self._last_user_message_event_id = backend_id or event["id"]

    async def broadcast_user_message_live(self, text: str) -> None:
        """Live (non-persistent) broadcast of the user's just-typed message.

        Mirrors the message_ai_chunk pattern in record_driver_event: the backend
        relays this through the channel layer to the browser but does NOT write
        a DB row or local jsonl line. The durable record is written later via
        record_user_message once we know which node owns the message.

        Why split? With auto-branching, we don't know at send time whether the
        message will land on the current node or a fresh child. Persisting it
        eagerly forces a later move (mutates an append-only log). Deferring the
        durable write avoids the move; this live broadcast keeps the browser
        bubble appearing instantly so UX matches a non-branching session.
        """
        try:
            await self._backend.append_delta_event(self._node_id, {
                "type": "message_user_chunk",
                "text": text,
            })
        except Exception:
            pass  # non-critical — only affects live display

    @property
    def last_user_message_event_id(self) -> str | None:
        return getattr(self, '_last_user_message_event_id', None)

    async def record_driver_event(self, event: "DriverEvent") -> None:
        """Record a DriverEvent from the response stream (text, result, etc.)."""
        # Tool calls are captured via hooks (pre/post_tool_use) — skip here to avoid duplication
        if event.type in ("tool_use", "tool_result"):
            return

        if event.type == "text":
            # Streaming chunk — broadcast to browser for live display, not persisted
            text = event.data.get("text", "")
            self._streamed_text_buffer += text
            try:
                await self._backend.append_delta_event(self._node_id, {
                    "type": "message_ai_chunk",
                    "text": text,
                })
            except Exception:
                pass  # non-critical — only affects live display
            return

        if event.type == "text_complete":
            # Full assembled text from AssistantMessage — persist as one event.
            # This is the authoritative source; clear the streamed buffer since
            # AssistantMessage text is already complete and deduplicated.
            text = event.data.get("text", "")
            self._streamed_text_buffer = ""
            self._text_complete_fired = True
            if text:
                recorded = self._build_event(
                    event_type="message_ai",
                    tool_name="",
                    tool_use_id="",
                    data={"text": text},
                )
                await self._record(recorded)
            return

        if event.type == "result":
            # If text_complete never fired (e.g. tool denial — SDK emits StreamEvents
            # for Claude's follow-up but skips AssistantMessage), flush the buffer now
            # so the browser sees the response.
            if self._streamed_text_buffer and not self._text_complete_fired:
                flushed = self._build_event(
                    event_type="message_ai",
                    tool_name="",
                    tool_use_id="",
                    data={"text": self._streamed_text_buffer},
                )
                await self._record(flushed)
            self._streamed_text_buffer = ""
            self._text_complete_fired = False
            recorded = self._build_event(
                event_type="turn_result",
                tool_name="",
                tool_use_id="",
                data=event.data,
            )
            await self._record(recorded)
            return

        # thinking, rate_limit, error — record as-is
        type_map = {
            "thinking": "message_ai_thinking",
            "rate_limit": "rate_limit",
            "error": "error",
        }
        event_type = type_map.get(event.type, event.type)
        recorded = self._build_event(
            event_type=event_type,
            tool_name="",
            tool_use_id="",
            data=event.data,
        )
        await self._record(recorded)

    # ------------------------------------------------------------------
    # Hook callbacks — fired by the driver for tool calls
    # ------------------------------------------------------------------

    async def _on_pre_tool(self, payload: "ToolHookPayload") -> None:
        event = self._build_event(
            event_type="pre_tool_use",
            tool_name=payload.tool_name,
            tool_use_id=payload.tool_use_id,
            data={"tool_input": payload.tool_input},
        )
        await self._record(event)

    async def _on_post_tool(self, payload: "ToolHookPayload") -> None:
        is_side_effecting = payload.tool_name in SIDE_EFFECTING_TOOLS
        event = self._build_event(
            event_type="post_tool_use",
            tool_name=payload.tool_name,
            tool_use_id=payload.tool_use_id,
            data={
                "tool_output": _truncate(payload.tool_output),
                "is_error": payload.is_error,
                "is_side_effecting": is_side_effecting,
            },
        )
        await self._record(event)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _build_event(
        self,
        event_type: str,
        tool_name: str,
        tool_use_id: str,
        data: dict[str, Any],
        branched_from_event_id: str | None = None,
    ) -> dict[str, Any]:
        # event_type strings must match EventType constants in
        # backend/nodes/event_types.py — that file is the single source of truth.
        event_id = str(uuid.uuid4())
        event = {
            "id": event_id,
            "parent_event_id": self._last_event_id,
            "branched_from_event_id": branched_from_event_id,  # set by NodeManager on branch events
            "type": event_type,
            "tool_name": tool_name,
            "tool_use_id": tool_use_id,
            "graph_id": self._graph_id,
            "node_id": self._node_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            **data,
        }
        self._last_event_id = event_id
        return event

    async def _record(self, event: dict[str, Any]) -> str | None:
        """Persist event locally then to backend. Returns backend-assigned event ID, or None on failure."""
        # 1. Write locally first — crash safe
        self._log_file.write(json.dumps(event) + "\n")
        self._log_file.flush()

        # 2. Send to backend — best effort, never crash the session on failure
        try:
            resp = await self._backend.append_delta_event(self._node_id, event)
            return resp.get("id") if isinstance(resp, dict) else None
        except Exception as exc:
            logger.warning("Failed to send event to backend: %s", exc)
            return None


def _truncate(value: Any, max_len: int = 500) -> Any:
    """Keep tool output in the log but don't let huge file reads bloat it."""
    if isinstance(value, str) and len(value) > max_len:
        return value[:max_len] + f"…[{len(value) - max_len} chars truncated]"
    return value
