"""``flow cluster`` — manage Slurm overlay clusters on Flow instances.

Wraps the Click group defined in :mod:`flow.cli.commands.cluster.commands`
in a :class:`BaseCommand` subclass so it can be discovered by the standard
CLI command loader.
"""

from __future__ import annotations

import click

from flow.cli.commands.base import BaseCommand
from flow.cli.commands.cluster.commands import cluster_group

__all__ = ["ClusterCommand", "cluster_group", "command"]


class ClusterCommand(BaseCommand):
    """``flow cluster`` — Slurm overlay management."""

    @property
    def name(self) -> str:
        return "cluster"

    @property
    def help(self) -> str:
        return "Manage Slurm overlay clusters on instances"

    def get_command(self) -> click.Command:
        return cluster_group


command = ClusterCommand()
