class Resumed:
    pass
