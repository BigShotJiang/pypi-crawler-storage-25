"""Tests for netcoredbg-mcp."""
