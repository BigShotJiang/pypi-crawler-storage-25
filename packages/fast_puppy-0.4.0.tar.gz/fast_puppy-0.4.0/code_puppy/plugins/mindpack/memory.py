"""MindPack memory — ReportStore for expert report buffering.

Provides a structured, session-scoped memory surface that:
  - Accepts expert reports as they arrive.
  - Allows the judge to read all reports for a given session.
  - Supports basic queries (by expert, by session, latest).
  - Clears per-session state after a consultation round completes.
"""

import logging
import time
from typing import Dict, List, Optional

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Expert report model
# ---------------------------------------------------------------------------


class ExpertReport(BaseModel):
    """A single expert's advisory report produced during a consultation."""

    expert_name: str = Field(..., description="Identifier of the expert")
    session_id: str = Field(
        ..., description="Consultation session this report belongs to"
    )
    timestamp: float = Field(default_factory=time.time, description="Unix timestamp")
    analysis: str = Field(..., description="The expert's detailed analysis")
    recommendations: List[str] = Field(
        default_factory=list,
        description="Key recommendations from this expert",
    )
    risks: List[str] = Field(default_factory=list, description="Risks identified")
    files_to_inspect: List[str] = Field(
        default_factory=list,
        description="Files this expert recommends inspecting",
    )
    confidence: float = Field(
        default=0.5,
        ge=0,
        le=1,
        description="Expert's confidence in their own analysis",
    )
    disagrees_with: List[str] = Field(
        default_factory=list,
        description="Names of other experts this one disagrees with",
    )


# ---------------------------------------------------------------------------
# ReportStore
# ---------------------------------------------------------------------------


class ReportStore:
    """In-memory, session-scoped store for expert reports.

    Thread-safety is not yet guaranteed — single-threaded orchestration
    for now. If concurrency is introduced later, add locking around
    `_store` and `_session_index`.
    """

    def __init__(self) -> None:
        # session_id -> list of ExpertReport
        self._store: Dict[str, List[ExpertReport]] = {}
        # session_id -> original problem statement (for judge context)
        self._session_context: Dict[str, str] = {}

    # -- write operations ---------------------------------------------------

    def add_report(self, report: ExpertReport) -> None:
        """Append an expert report to its session bucket."""
        sid = report.session_id
        if sid not in self._store:
            self._store[sid] = []
        self._store[sid].append(report)
        logger.debug(
            "ReportStore: added report from '%s' to session '%s' (total: %d)",
            report.expert_name,
            sid,
            len(self._store[sid]),
        )

    def set_session_context(self, session_id: str, problem_statement: str) -> None:
        """Store the original problem statement for a session."""
        self._session_context[session_id] = problem_statement

    # -- read operations ----------------------------------------------------

    def get_reports(self, session_id: str) -> List[ExpertReport]:
        """Return all reports for a session, in insertion order."""
        return list(self._store.get(session_id, []))

    def get_report_by_expert(
        self, session_id: str, expert_name: str
    ) -> Optional[ExpertReport]:
        """Return the latest report from a specific expert in a session."""
        for report in reversed(self._store.get(session_id, [])):
            if report.expert_name == expert_name:
                return report
        return None

    def get_session_context(self, session_id: str) -> Optional[str]:
        """Return the original problem statement for a session."""
        return self._session_context.get(session_id)

    def session_report_count(self, session_id: str) -> int:
        """Number of reports filed for a session."""
        return len(self._store.get(session_id, []))

    # -- lifecycle -----------------------------------------------------------

    def clear_session(self, session_id: str) -> None:
        """Remove all reports and context for a completed session."""
        self._store.pop(session_id, None)
        self._session_context.pop(session_id, None)
        logger.debug("ReportStore: cleared session '%s'", session_id)

    def clear_all(self) -> None:
        """Remove all session data (e.g. on shutdown)."""
        self._store.clear()
        self._session_context.clear()
        logger.debug("ReportStore: cleared all sessions")
