"""MindPack schemas — shared Pydantic models for cross-module use.

Breaks the circular dependency between ``orchestration.py`` and ``tools.py``
by keeping pure data models in a single importable location.

These models carry no logic — they are plain data contracts.
"""

from typing import List, Literal, Optional

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Expert descriptor
# ---------------------------------------------------------------------------


class ExpertDescriptor(BaseModel):
    """Metadata describing an expert that may be consulted."""

    name: str = Field(..., description="Unique expert identifier")
    speciality: str = Field(..., description="Domain of expertise")
    system_prompt_fragment: str = Field(
        default="",
        description="Prompt fragment injected into the expert's context",
    )
    max_experts_override: Optional[int] = Field(
        default=None,
        description="If set, caps how many experts of this type to spawn",
    )
    model: Optional[str] = Field(
        default=None,
        description="Optional custom model override for this specific expert",
    )


# ---------------------------------------------------------------------------
# AskMindPack I/O models
# ---------------------------------------------------------------------------


class MindPackRankedOption(BaseModel):
    """A single ranked option produced by the MindPack judge."""

    rank: int = Field(..., description="Ranking position (1 = best)")
    title: str = Field(..., description="Short title for this option")
    source_experts: List[str] = Field(
        default_factory=list,
        description="Expert names that contributed to this option",
    )
    summary: str = Field(..., description="One-paragraph summary of the option")
    pros: List[str] = Field(default_factory=list, description="Advantages")
    cons: List[str] = Field(default_factory=list, description="Disadvantages")
    risk: Literal["low", "medium", "high"] = Field(
        default="medium", description="Risk level"
    )
    confidence: float = Field(
        default=0.5, ge=0, le=1, description="Confidence score 0–1"
    )


class AskMindPackInput(BaseModel):
    """Input model for the ask_mindpack tool.

    Carries the executor's problem context so MindPack can spin up
    an appropriate expert pool.
    """

    problem_statement: str = Field(..., description="The specific problem to solve")
    current_goal: str = Field(
        ..., description="What the executor is currently trying to achieve"
    )
    current_plan: Optional[str] = Field(
        default=None, description="Current plan, if any"
    )
    what_has_been_tried: List[str] = Field(
        default_factory=list,
        description="Approaches already attempted",
    )
    relevant_files: List[str] = Field(
        default_factory=list,
        description="File paths relevant to the problem",
    )
    observed_errors: List[str] = Field(
        default_factory=list,
        description="Error messages or unexpected behaviours observed",
    )
    uncertainty: Optional[str] = Field(
        default=None,
        description="What the executor is uncertain about",
    )
    desired_output: Literal[
        "plan",
        "review",
        "debug_strategy",
        "architecture_decision",
        "test_strategy",
        "compare_options",
    ] = Field(
        default="plan",
        description="Kind of advisory output the executor wants",
    )
    max_experts: Optional[int] = Field(
        default=None,
        description="Cap on number of experts to consult",
    )


class AskMindPackOutput(BaseModel):
    """Output model for the ask_mindpack tool.

    Returns a merged, judge-vetted advisory response that the
    executor can use to continue its work.
    """

    summary: str = Field(..., description="High-level summary of the advisory")
    recommended_plan: str = Field(..., description="The judge-merged recommended plan")
    ranked_options: List[MindPackRankedOption] = Field(
        default_factory=list,
        description="Ranked alternative options from the expert pool",
    )
    risks: List[str] = Field(
        default_factory=list,
        description="Risks identified across all experts",
    )
    tests_to_run: List[str] = Field(
        default_factory=list,
        description="Suggested tests to validate the plan",
    )
    files_to_inspect_or_change: List[str] = Field(
        default_factory=list,
        description="Files the experts recommend inspecting or changing",
    )
    expert_consensus: str = Field(..., description="Summary of what experts agreed on")
    disagreements: List[str] = Field(
        default_factory=list,
        description="Key disagreements between experts",
    )
    confidence: float = Field(
        default=0.5,
        ge=0,
        le=1,
        description="Overall confidence in the recommendation",
    )
