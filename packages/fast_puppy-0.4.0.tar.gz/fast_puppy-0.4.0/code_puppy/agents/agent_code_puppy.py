"""Code-Puppy - The default code generation agent."""

from code_puppy.config import get_owner_name, get_puppy_name

from .base_agent import BaseAgent
from .prompt_v3 import autonomy_base_prompt, code_puppy_overlay, repository_addendum
from .. import callbacks


class CodePuppyAgent(BaseAgent):
    """Code-Puppy - The default loyal digital puppy code agent."""

    @property
    def name(self) -> str:
        return "code-puppy"

    @property
    def display_name(self) -> str:
        return "Code-Puppy 🐶"

    @property
    def description(self) -> str:
        return "The most loyal digital puppy, helping with all coding tasks"

    def get_available_tools(self) -> list[str]:
        """Get the list of tools available to Code-Puppy."""
        return [
            "list_agents",
            "invoke_agent",
            "list_files",
            "read_file",
            "grep",
            "create_file",
            "replace_in_file",
            "delete_snippet",
            "delete_file",
            "agent_run_shell_command",
            "ask_user_question",
            "activate_skill",
            "list_or_search_skills",
            "load_image_for_analysis",
        ]

    def _get_reasoning_prompt_sections(self) -> dict[str, str]:
        """Return prompt sections describing the expected think-act loop."""
        return {
            "pre_tool_rule": (
                "- Before major tool use, think through your approach "
                "and planned next steps"
            ),
            "loop_rule": (
                "- You're encouraged to loop between reasoning, file "
                "tools, and run_shell_command to test output in order "
                "to write programs"
            ),
        }

    def get_system_prompt(self) -> str:
        """Get Code-Puppy's full system prompt — v3 architecture."""
        puppy_name = get_puppy_name()
        owner_name = get_owner_name()
        r = self._get_reasoning_prompt_sections()

        result = (
            autonomy_base_prompt()
            + "\n\n"
            + code_puppy_overlay(puppy_name, owner_name)
            + "\n\n"
            + repository_addendum()
        )

        # Reasoning prompt sections (pre_tool_rule, loop_rule) come after overlays
        if r:
            result += "\n" + r.get("pre_tool_rule", "")
            result += "\n" + r.get("loop_rule", "")

        result += "\n" + "\n".join(callbacks.on_load_prompt())
        return result
