# Copyright 2026 (c) o6 Automation GmbH
from __future__ import annotations
from typing import Any, TYPE_CHECKING, Optional
import asyncio

import o6
import numpy as np
from o6 import MaybeAwaitable, HasNodeId, NodeIdLike

if TYPE_CHECKING:
    from o6.client import Client


def _node_from_node_class(
    client: Client, nodeid: NodeIdLike, node_class: o6.NodeClass
) -> Node:
    T: type[Node]
    if node_class == o6.NodeClass.Object:
        T = ObjectNode
    elif node_class == o6.NodeClass.Variable:
        T = VariableNode
    elif node_class == o6.NodeClass.Method:
        T = MethodNode
    elif node_class == o6.NodeClass.ObjectType:
        T = ObjectTypeNode
    elif node_class == o6.NodeClass.VariableType:
        T = VariableTypeNode
    elif node_class == o6.NodeClass.ReferenceType:
        T = ReferenceTypeNode
    elif node_class == o6.NodeClass.DataType:
        T = DataTypeNode
    elif node_class == o6.NodeClass.View:
        T = ViewNode
    else:
        raise Exception("Unknown NodeClass")
    return T(client, node_class, nodeid)


class Node(HasNodeId):
    def __init__(
        self, client: Client, node_class: o6.NodeClass, nodeid: NodeIdLike
    ) -> None:
        self._client = client
        self._nodeid: o6.NodeId = o6.NodeId(nodeid)
        self._node_class = node_class
        self._children = None

    # Call Syntax
    def __call__(
        self, value: Optional[Any] = None, attr: Optional[o6.AttributeId | str] = None
    ) -> MaybeAwaitable[Any]:
        async def call():
            if value != None:
                res = await self._client.write(
                    self._nodeid, value=value, attributeid=attr
                )
                if res.code != 0:
                    raise Exception(f"Write failed with status {res}")
                return
            if attr == o6.AttributeId.NODEID:
                return self._nodeid
            if attr == o6.AttributeId.NODECLASS:
                return self._node_class
            return await self._client.read(target=self._nodeid, attributeid=attr)

        return self._client._maybe_async(call())

    # Dot Syntax
    async def _get_children(self):
        if self._children != None:
            return
        mask = o6.BrowseResultMask.BrowseName | o6.BrowseResultMask.NodeClass
        self._children = await self._client.browse(self._nodeid, result_mask=mask)

    async def _resolve_child(self, name: str) -> Node:
        if self._children is None:
            await self._get_children()
        assert self._children is not None
        name_lower = name.lower()
        matches = [
            c for c in self._children if c.browse_name.name.lower() == name_lower
        ]
        if len(matches) == 0:
            raise Exception(f"Child-node {name} not found")
        if len(matches) > 1:
            raise Exception(f"Not unique, {len(matches)} child-nodes match {name}")
        child = matches[0]
        return _node_from_node_class(self._client, str(child.nodeid), child.node_class)

    def __dir__(self):
        super_dir = super().__dir__()

        async def _dir():
            if self._children == None:
                await self._get_children()
            return super_dir + [c.browse_name.name for c in self._children]

        fut = asyncio.run_coroutine_threadsafe(_dir(), self._client._loop)
        return fut.result()

    def __getattr__(self, name: str) -> Node | AwaitableNode:
        if name.startswith("_"):
            raise AttributeError(name)
        r = self._client._maybe_async(self._resolve_child(name))
        if isinstance(r, Node):
            return r
        return AwaitableNode(self._client, r)

    # Index Syntax
    def __getitem__(self, key: str | o6.RelativePath) -> MaybeAwaitable[list[Any]]:
        async def _getitem() -> list[Any]:
            # Prepare the request
            bp = o6.BrowsePath()
            bp.starting_node = self._nodeid
            if isinstance(key, o6.RelativePath):
                bp.relative_path = key
            else:
                bp.relative_path = o6.RelativePath(key)  # type: ignore[call-arg]
            request = o6.TranslateBrowsePathsToNodeIdsRequest()
            request.browse_paths = [bp]

            # Call the service and check the result
            response = await self._client._service_translateBrowsePathsToNodeIds(
                request
            )
            if response.response_header.service_result.code != 0:
                raise Exception(
                    f"TranslateBrowsePathsToNodeIds failed: {response.response_header.service_result}"
                )
            result = response.results[0]
            if result.status_code.code != 0:
                raise KeyError(
                    f"Could not resolve browse path {key!r}: {result.status_code}"
                )
            if not result.targets:
                raise KeyError(f"No node found for browse path {key!r}")

            # Resolve the results and return
            async def browse_path_result_to_node(bpr):
                if bpr.remaining_path_index != np.iinfo(np.uint32).max:
                    return bpr
                target = bpr.targetid
                if len(target.nsu) > 0 or target.svr != 0:
                    return target
                return await self._client[str(target)]

            return [await browse_path_result_to_node(x) for x in result.targets]

        return self._client._maybe_async(_getitem())


class AwaitableNode:

    def __init__(self, client: Client, awaitable: Any) -> None:
        self._client = client
        self._awaitable = awaitable

    def __await__(self):
        return self._awaitable.__await__()

    def __getattr__(self, name: str) -> AwaitableNode:
        if name.startswith("_"):
            raise AttributeError(name)
        parent = self._awaitable
        client = self._client

        async def chain() -> Node:
            node = await parent
            return await node._resolve_child(name)

        return AwaitableNode(client, chain())

    def __call__(self, *args: Any, **kwargs: Any) -> AwaitableNode:
        parent = self._awaitable
        client = self._client

        async def chain() -> Any:
            node = await parent
            result = node(*args, **kwargs)
            if hasattr(result, "__await__"):
                return await result
            return result

        return AwaitableNode(client, chain())


class ObjectNode(Node):
    pass


class VariableNode(Node):
    def __call__(
        self, value: Optional[Any] = None, attr: Optional[o6.AttributeId | str] = None
    ) -> MaybeAwaitable[Any]:
        if attr == None:
            attr = o6.AttributeId.VALUE
        return super().__call__(attr=attr, value=value)


class VariableTypeNode(Node):
    def __call__(
        self, value: Optional[Any] = None, attr: Optional[o6.AttributeId | str] = None
    ) -> MaybeAwaitable[Any]:
        if attr == None:
            attr = o6.AttributeId.VALUE
        return super().__call__(attr=attr, value=value)


class MethodNode(Node):
    _default_object: o6.NodeId

    def __call__(
        self,
        *args: Any,
        objectid: Optional[o6.NodeId] = None,
        attr: Optional[o6.AttributeId | str] = None,
        value: Optional[Any] = None,
    ) -> MaybeAwaitable[Any]:
        if attr is not None or value is not None:
            if len(args) != 0:
                raise Exception(
                    "Method-call syntax and attribute-access syntax do not mix"
                )
            if attr is None:
                attr = o6.AttributeId.VALUE
            return super().__call__(attr=attr, value=value)
        if objectid is None:
            objectid = self._default_object
        return self._client.call(objectid, self._nodeid, list(args))


class ObjectTypeNode(Node):
    pass


class ReferenceTypeNode(Node):
    pass


class DataTypeNode(Node):
    pass


class ViewNode(Node):
    pass
