"""
context_manager.py — Global shared codebase context.

Accumulates cross-file intelligence as worker agents complete.
Persisted to CodeReportAi/context.json after each update.
"""

from __future__ import annotations

import json
import threading
from pathlib import Path
from typing import Any, Dict, List, Set


# ---------------------------------------------------------------------------
# Default schema
# ---------------------------------------------------------------------------

def _empty_context() -> Dict[str, Any]:
    return {
        "project_language_stack": [],
        "processed_files": [],
        "common_patterns": [],
        "shared_utilities": [],
        "entry_points": [],
        "dependency_graph": {},
        "cross_file_insights": [],
    }


class ContextManager:
    """
    Thread-safe store for the global codebase context.

    The context dict is incrementally enriched by each Worker and passed
    (as a read-only JSON snapshot) into every subsequent Gemini prompt.
    """

    def __init__(self) -> None:
        self._ctx: Dict[str, Any] = _empty_context()
        self._lock = threading.Lock()
        self._processed_set: Set[str] = set()   # fast membership lookup

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def load(self, context_path: Path) -> None:
        """Load an existing context.json (resume mode)."""
        if not context_path.exists():
            return
        try:
            with open(context_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            with self._lock:
                self._ctx.update(data)
                self._processed_set = set(self._ctx.get("processed_files", []))
        except (json.JSONDecodeError, OSError) as exc:
            # Corrupted file — start fresh
            print(f"[warning] Could not load context.json: {exc}. Starting fresh.")

    def save(self, context_path: Path) -> None:
        """Atomically write the current context to disk."""
        context_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = context_path.with_suffix(".json.tmp")
        with self._lock:
            snapshot = json.dumps(self._ctx, indent=2, ensure_ascii=False)
        try:
            tmp.write_text(snapshot, encoding="utf-8")
            tmp.replace(context_path)
        except OSError:
            pass  # non-fatal; context will be regenerated on next run

    # ------------------------------------------------------------------
    # State queries
    # ------------------------------------------------------------------

    def is_processed(self, file_path: Path | str) -> bool:
        """Return True if this file has already been analysed."""
        key = str(file_path)
        with self._lock:
            return key in self._processed_set

    def snapshot(self) -> Dict[str, Any]:
        """Return a deep copy of the current context (safe to serialise)."""
        with self._lock:
            return json.loads(json.dumps(self._ctx))

    # ------------------------------------------------------------------
    # Mutation
    # ------------------------------------------------------------------

    def mark_processed(self, file_path: Path | str) -> None:
        """Record that a file has been successfully processed."""
        key = str(file_path)
        with self._lock:
            if key not in self._processed_set:
                self._processed_set.add(key)
                self._ctx["processed_files"].append(key)

    def update(self, context_update: Dict[str, Any], file_path: Path | str) -> None:
        """
        Merge a Worker's context_update payload into the global context.

        Expected keys in *context_update* (all optional):
          language_stack_additions: list[str]
          patterns_found:           list[str]
          shared_utilities:         list[str]
          entry_point:              bool
          dependencies:             dict  (stored in dependency_graph)
          cross_file_insight:       str   (free-text insight)
        """
        if not context_update:
            return

        with self._lock:
            # Language stack
            for lang in context_update.get("language_stack_additions", []):
                if lang and lang not in self._ctx["project_language_stack"]:
                    self._ctx["project_language_stack"].append(lang)

            # Common patterns
            for pat in context_update.get("patterns_found", []):
                if pat and pat not in self._ctx["common_patterns"]:
                    self._ctx["common_patterns"].append(pat)

            # Shared utilities
            for util in context_update.get("shared_utilities", []):
                if util and util not in self._ctx["shared_utilities"]:
                    self._ctx["shared_utilities"].append(util)

            # Entry points
            if context_update.get("entry_point"):
                fp = str(file_path)
                if fp not in self._ctx["entry_points"]:
                    self._ctx["entry_points"].append(fp)

            # Dependency graph
            deps = context_update.get("dependencies")
            if deps:
                self._ctx["dependency_graph"][str(file_path)] = deps

            # Free-text cross-file insight
            insight = context_update.get("cross_file_insight")
            if insight:
                self._ctx["cross_file_insights"].append(
                    {"file": str(file_path), "insight": insight}
                )

    def summary_for_prompt(self) -> str:
        """Return a compact JSON string suitable for embedding in a Gemini prompt."""
        snap = self.snapshot()
        # Limit size: keep only last 20 cross-file insights to avoid huge prompts
        snap["cross_file_insights"] = snap["cross_file_insights"][-20:]
        # Limit dependency_graph keys to last 30 files
        if len(snap["dependency_graph"]) > 30:
            keys = list(snap["dependency_graph"])[-30:]
            snap["dependency_graph"] = {k: snap["dependency_graph"][k] for k in keys}
        return json.dumps(snap, indent=2, ensure_ascii=False)
