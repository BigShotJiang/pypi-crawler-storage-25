"""
CodeReportAI — Terminal-based codebase analysis tool powered by Google Gemini.
"""

__version__ = "1.0.0"
__author__ = "CodeReportAI"
