"""
supervisor.py — Supervisor Agent (Orchestrator).

Drives the full analysis pipeline:
  1. Prioritises and batches file list
  2. Dispatches Worker calls concurrently
  3. Updates global context after each result
  4. Saves context.json and writes HTML reports
  5. Handles retries, failures, and resumability
"""

from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor, Future, as_completed
from pathlib import Path
from typing import List, Optional

from rich.console import Console
from rich.progress import (
    Progress, SpinnerColumn, BarColumn,
    TaskProgressColumn, TextColumn, TimeElapsedColumn, TimeRemainingColumn,
)
from rich.panel import Panel

from .api_manager import APIManager, NoKeysAvailableError
from .context_manager import ContextManager
from .html_renderer import render_report
from .worker import Worker, RateLimitError

console = Console()

MAX_RETRIES = 3
RETRY_DELAY = 2.0   # seconds between retries (non-rate-limit failures)


class Supervisor:
    """
    Orchestrates the full codebase analysis pipeline.

    Parameters
    ----------
    root:           Root directory being scanned
    output_root:    CodeReportAi/ output directory
    api_manager:    Shared APIManager instance
    ctx_manager:    Shared ContextManager instance
    model_name:     Gemini model to use
    concurrency:    Number of parallel workers
    resume:         If True, skip already-processed files
    """

    def __init__(
        self,
        root: Path,
        output_root: Path,
        api_manager: APIManager,
        ctx_manager: ContextManager,
        model_name: str = "gemini-3.1-flash-lite-preview",
        concurrency: int = 4,
        resume: bool = False,
    ) -> None:
        self.root = root
        self.output_root = output_root
        self.api_manager = api_manager
        self.ctx_manager = ctx_manager
        self.model_name = model_name
        self.concurrency = concurrency
        self.resume = resume
        self.context_path = output_root / "context.json"

        self._worker = Worker(model_name=model_name)
        self._stats = {"processed": 0, "skipped": 0, "errors": 0}

    # ------------------------------------------------------------------
    # Entry point
    # ------------------------------------------------------------------

    def run(self, file_list: List[Path]) -> None:
        """Run the full analysis pipeline over *file_list*."""
        to_process: List[Path] = []
        for fp in file_list:
            if self.resume and self.ctx_manager.is_processed(fp):
                self._stats["skipped"] += 1
            else:
                to_process.append(fp)

        total = len(to_process)
        skipped = self._stats["skipped"]
        console.print(
            Panel(
                f"[bold cyan]Files to analyse:[/bold cyan] {total}  "
                f"[dim](skipped {skipped} already processed)[/dim]",
                title="[bold]CodeReportAI -- Starting Analysis[/bold]",
                border_style="cyan",
            )
        )

        if total == 0:
            console.print("[green]All files already processed. Use --no-resume to reprocess.[/green]")
            return

        with Progress(
            SpinnerColumn(),
            TextColumn("[bold blue]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            TimeElapsedColumn(),
            TimeRemainingColumn(),
            console=console,
            transient=False,
        ) as progress:
            task_id = progress.add_task("Analysing files...", total=total)

            with ThreadPoolExecutor(max_workers=self.concurrency) as executor:
                future_map: dict[Future, Path] = {}
                pending = list(to_process)

                # Submit initial batch
                for fp in pending[: self.concurrency * 2]:
                    fut = executor.submit(self._process_file_with_retry, fp)
                    future_map[fut] = fp
                submitted_count = len(future_map)

                for future in as_completed(future_map):
                    fp = future_map[future]
                    try:
                        result = future.result()
                    except Exception as exc:
                        console.print(f"[red]Unhandled error for {fp.name}: {exc}[/red]")
                        self._stats["errors"] += 1
                        result = None

                    if result and not result.get("error"):
                        self._on_success(result)
                    elif result and result.get("error"):
                        console.print(
                            f"[red]FAIL {result['relative_path']}: {result['error']}[/red]"
                        )
                        self._stats["errors"] += 1

                    # Rotate to next API key after EVERY file, regardless of outcome.
                    # This guarantees: File1->Key1, File2->Key2, File3->Key3, ...
                    self.api_manager.advance()

                    progress.advance(task_id)

                    # Submit next file (streaming submission keeps workers busy)
                    if submitted_count < len(pending):
                        next_fp = pending[submitted_count]
                        fut = executor.submit(self._process_file_with_retry, next_fp)
                        future_map[fut] = next_fp
                        submitted_count += 1

        self._print_summary()

    # ------------------------------------------------------------------
    # Per-file processing
    # ------------------------------------------------------------------

    def _process_file_with_retry(self, file_path: Path) -> dict:
        """Process one file with retry logic and key rotation."""
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                api_key = self.api_manager.get_key()
                context_summary = self.ctx_manager.summary_for_prompt()
                result = self._worker.process(
                    file_path=file_path,
                    root=self.root,
                    api_key=api_key,
                    context_summary=context_summary,
                )
                return result

            except RateLimitError:
                self.api_manager.mark_rate_limited(api_key)
                # Immediately retry with a different key
                continue

            except NoKeysAvailableError as exc:
                return {
                    "file_path": file_path,
                    "relative_path": str(file_path.relative_to(self.root)),
                    "error": str(exc),
                    "html_sections": {},
                    "context_update": {},
                }

            except Exception as exc:
                if attempt < MAX_RETRIES:
                    time.sleep(RETRY_DELAY * attempt)
                else:
                    return {
                        "file_path": file_path,
                        "relative_path": str(file_path.relative_to(self.root)),
                        "error": f"Failed after {MAX_RETRIES} attempts: {exc}",
                        "html_sections": {},
                        "context_update": {},
                    }

        # Exhausted retries (all rate-limit)
        return {
            "file_path": file_path,
            "relative_path": str(file_path.relative_to(self.root)),
            "error": "All retries exhausted (rate limits).",
            "html_sections": {},
            "context_update": {},
        }

    def _on_success(self, result: dict) -> None:
        """Post-process a successful worker result."""
        fp: Path = result["file_path"]
        relative = result["relative_path"]

        # 1. Update global context
        self.ctx_manager.update(result.get("context_update", {}), fp)
        self.ctx_manager.mark_processed(fp)

        # 2. Save context snapshot to disk
        self.ctx_manager.save(self.context_path)

        # 3. Render and write HTML report
        html = render_report(result)
        out_path = self._html_output_path(fp)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(html, encoding="utf-8")

        self._stats["processed"] += 1
        rel_safe = str(out_path.relative_to(self.output_root.parent)).encode("ascii", errors="replace").decode("ascii")
        console.print(f"[green]OK[/green] {relative} -> {rel_safe}")

    def _html_output_path(self, file_path: Path) -> Path:
        """Mirror file_path into the output directory with .html extension."""
        rel = file_path.relative_to(self.root)
        return self.output_root / rel.with_suffix(".html")

    def _print_summary(self) -> None:
        s = self._stats
        console.print(
            Panel(
                f"[bold green]Done:[/bold green] {s['processed']}   "
                f"[bold yellow]Skipped:[/bold yellow] {s['skipped']}   "
                f"[bold red]Errors:[/bold red] {s['errors']}\n"
                f"[dim]Reports written to:[/dim] {self.output_root}",
                title="[bold]CodeReportAI -- Run Complete[/bold]",
                border_style="green",
            )
        )
