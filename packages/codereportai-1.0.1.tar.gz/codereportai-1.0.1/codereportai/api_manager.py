"""
api_manager.py — Thread-safe multi-key Gemini API manager.

Implements round-robin distribution and automatic cooldown rotation
when a key hits a 429 rate-limit error.
"""

from __future__ import annotations

import threading
import time
from collections import deque
from typing import Deque, Dict, List, Optional

from rich.console import Console

console = Console()

COOLDOWN_SECONDS: int = 65  # how long to back-off a rate-limited key


class NoKeysAvailableError(RuntimeError):
    """Raised when every API key is in cooldown and we've exhausted retries."""


class APIManager:
    """
    Manages a pool of Gemini API keys with:
    - Round-robin distribution
    - Automatic 429 cooldown per key
    - Blocking wait when all keys are cooling down
    """

    def __init__(self, keys: List[str]) -> None:
        if not keys:
            raise ValueError("At least one GEMINI_API_KEY must be provided.")
        self._keys: List[str] = list(keys)
        self._queue: Deque[str] = deque(keys)
        self._cooldowns: Dict[str, float] = {}   # key -> cooldown_until timestamp
        self._lock = threading.Lock()
        console.print(f"[green]Loaded {len(keys)} API key(s).[/green]")

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def get_key(self, timeout: float = 300.0) -> str:
        """
        Return the next available (non-cooling) API key.
        Blocks until a key is available or *timeout* seconds elapse.
        """
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            with self._lock:
                key = self._next_available()
                if key:
                    return key
                wait_for = self._soonest_recovery()

            if wait_for is None:
                # No keys at all — shouldn't happen
                raise NoKeysAvailableError("No API keys configured.")

            sleep_time = min(wait_for - time.monotonic(), 5.0)
            if sleep_time > 0:
                console.print(
                    f"[yellow]All keys cooling down. Waiting {sleep_time:.1f}s...[/yellow]"
                )
                time.sleep(sleep_time)

        raise NoKeysAvailableError(
            "All API keys are rate-limited and timeout expired."
        )

    def mark_rate_limited(self, key: str) -> None:
        """Put *key* into cooldown for COOLDOWN_SECONDS."""
        with self._lock:
            until = time.monotonic() + COOLDOWN_SECONDS
            self._cooldowns[key] = until
            console.print(
                f"[yellow]WARNING: Key ...{key[-6:]} rate-limited. "
                f"Cooling down for {COOLDOWN_SECONDS}s.[/yellow]"
            )

    def advance(self) -> None:
        """
        Explicitly rotate to the next key in the pool.
        Call this after EVERY file is processed (success or failure)
        to guarantee strict round-robin: File1->Key1, File2->Key2, etc.
        """
        with self._lock:
            self._queue.rotate(-1)
            next_key = self._queue[0]
            console.print(
                f"[dim]Key rotated -> using ...{next_key[-6:]} for next file[/dim]"
            )

    def all_cooling_down(self) -> bool:
        """Return True if every key is currently in cooldown."""
        now = time.monotonic()
        with self._lock:
            return all(
                self._cooldowns.get(k, 0) > now for k in self._keys
            )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _next_available(self) -> Optional[str]:
        """
        Rotate through the deque and return the first non-cooling key.
        Returns None if all keys are cooling down.
        """
        now = time.monotonic()
        for _ in range(len(self._queue)):
            key = self._queue[0]
            self._queue.rotate(-1)   # move front to back
            if self._cooldowns.get(key, 0) <= now:
                return key
        return None

    def _soonest_recovery(self) -> Optional[float]:
        """
        Return the monotonic timestamp when the soonest key will recover.
        Returns None if there are no keys.
        """
        if not self._keys:
            return None
        now = time.monotonic()
        return min(
            max(self._cooldowns.get(k, now), now) for k in self._keys
        )
