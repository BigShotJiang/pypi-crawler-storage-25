"""
html_renderer.py — Renders a structured analysis dict into a full HTML report.

Uses Jinja2 with the bundled report.html.j2 template.
Falls back to a minimal inline HTML if the template is unavailable.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict

from jinja2 import Environment, FileSystemLoader, select_autoescape

_TEMPLATE_DIR = Path(__file__).parent / "templates"
_TEMPLATE_NAME = "report.html.j2"

# Lazy singleton
_env: Environment | None = None


def _get_env() -> Environment:
    global _env
    if _env is None:
        _env = Environment(
            loader=FileSystemLoader(str(_TEMPLATE_DIR)),
            autoescape=select_autoescape(["html"]),
            trim_blocks=True,
            lstrip_blocks=True,
        )
    return _env


def render_report(result: Dict[str, Any]) -> str:
    """
    Render *result* (as returned by Worker.process) into a complete HTML string.

    Parameters
    ----------
    result : dict with keys:
        relative_path, language, content, html_sections, error
    """
    sections: Dict[str, Any] = result.get("html_sections", {}) or {}
    error: str | None = result.get("error")

    template_data = {
        "relative_path": result.get("relative_path", "unknown"),
        "language": result.get("language", "Unknown"),
        "content": result.get("content", ""),

        # Parsed sections (with safe defaults)
        "file_overview":         sections.get("file_overview", {}),
        "algorithms":            sections.get("algorithms", []),
        "design_decisions":      sections.get("design_decisions", []),
        "alternative_approaches":sections.get("alternative_approaches", []),
        "notable_patterns":      sections.get("notable_patterns", []),
        "potential_improvements":sections.get("potential_improvements", []),
        "cross_file_context":    sections.get("cross_file_context", []),
        "risks_and_warnings":    sections.get("risks_and_warnings", []),

        "error": error,
    }

    try:
        env = _get_env()
        template = env.get_template(_TEMPLATE_NAME)
        return template.render(**template_data)
    except Exception as exc:
        # Fallback: minimal self-contained HTML
        return _fallback_html(template_data, str(exc))


def _fallback_html(data: Dict[str, Any], template_error: str) -> str:
    path = data["relative_path"]
    error = data.get("error") or template_error
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>CodeReportAI — {path}</title>
<style>
  body {{ font-family: monospace; background: #0d1117; color: #c9d1d9; padding: 2rem; }}
  h1 {{ color: #f85149; }}
  pre {{ background: #161b22; padding: 1rem; border-radius: 6px; overflow-x: auto; }}
</style>
</head>
<body>
<h1>⚠ Report Generation Error</h1>
<p><strong>File:</strong> {path}</p>
<p><strong>Error:</strong> {error}</p>
</body>
</html>"""
