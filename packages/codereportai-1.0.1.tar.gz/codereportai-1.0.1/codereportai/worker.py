"""
worker.py — Worker Agent that calls Gemini and returns structured analysis.

Each call is stateless: Worker.process() takes everything it needs as arguments
and returns a dict containing the HTML report and a context_update payload.
"""

from __future__ import annotations

import json
import re
import time
from pathlib import Path
from typing import Any, Dict, Optional

from rich.console import Console

console = Console()

# ---------------------------------------------------------------------------
# Language detection (extension → display name)
# ---------------------------------------------------------------------------

LANG_MAP: Dict[str, str] = {
    ".py":   "Python",
    ".js":   "JavaScript",
    ".ts":   "TypeScript",
    ".jsx":  "JavaScript (React)",
    ".tsx":  "TypeScript (React)",
    ".go":   "Go",
    ".rs":   "Rust",
    ".c":    "C",
    ".cpp":  "C++",
    ".cc":   "C++",
    ".h":    "C/C++ Header",
    ".hpp":  "C++ Header",
    ".java": "Java",
    ".kt":   "Kotlin",
    ".swift": "Swift",
    ".rb":   "Ruby",
    ".php":  "PHP",
    ".cs":   "C#",
    ".fs":   "F#",
    ".scala": "Scala",
    ".lua":  "Lua",
    ".r":    "R",
    ".m":    "Objective-C / MATLAB",
    ".sh":   "Shell",
    ".bash": "Bash",
    ".zsh":  "Zsh",
    ".ps1":  "PowerShell",
    ".yml":  "YAML",
    ".yaml": "YAML",
    ".json": "JSON",
    ".toml": "TOML",
    ".xml":  "XML",
    ".html": "HTML",
    ".css":  "CSS",
    ".scss": "SCSS",
    ".sass": "Sass",
    ".sql":  "SQL",
    ".md":   "Markdown",
    ".rst":  "reStructuredText",
    ".tf":   "Terraform",
    ".dart": "Dart",
    ".ex":   "Elixir",
    ".exs":  "Elixir Script",
    ".hs":   "Haskell",
    ".clj":  "Clojure",
    ".vim":  "Vimscript",
    ".dockerfile": "Dockerfile",
}


# ---------------------------------------------------------------------------
# Prompt builder
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """You are a world-class senior software engineer performing deep,
thorough static code analysis. Your analysis is used to generate professional
documentation reports. Be precise, insightful, and technically rigorous."""


def _build_prompt(
    relative_path: str,
    language: str,
    content: str,
    global_context: str,
) -> str:
    return f"""You are performing deep code analysis for a codebase report.

FILE: {relative_path}
LANGUAGE: {language}
LINES: {content.count(chr(10)) + 1}

--- FILE CONTENT START ---
{content}
--- FILE CONTENT END ---

--- GLOBAL CODEBASE CONTEXT (accumulated so far) ---
{global_context}
--- GLOBAL CONTEXT END ---

Analyse the file thoroughly and return ONLY a single valid JSON object with
exactly this schema (no markdown fences, no extra text, just JSON):

{{
  "file_overview": {{
    "language": "<detected language>",
    "purpose": "<concise description of what this file does>",
    "size_lines": <integer>,
    "key_imports": ["<import1>", "..."]
  }},
  "algorithms": [
    {{
      "name": "<algorithm name>",
      "role": "<how it is used in this file>",
      "time_complexity": "<Big-O or N/A>",
      "space_complexity": "<Big-O or N/A>"
    }}
  ],
  "design_decisions": [
    "<decision 1>",
    "<decision 2>"
  ],
  "alternative_approaches": [
    {{
      "alternative": "<what else could have been done>",
      "reason_rejected": "<why this approach was likely not chosen>"
    }}
  ],
  "notable_patterns": [
    "<pattern or idiom observed>"
  ],
  "potential_improvements": [
    "<concrete improvement suggestion>"
  ],
  "cross_file_context": [
    "<how this file relates to others seen in the global context>"
  ],
  "risks_and_warnings": [
    {{
      "severity": "high|medium|low",
      "description": "<risk description>"
    }}
  ],
  "context_update": {{
    "language_stack_additions": ["<language or tech>"],
    "patterns_found": ["<pattern name>"],
    "shared_utilities": ["<utility function or class name>"],
    "entry_point": true,
    "dependencies": {{
      "imports": ["<module or file>"],
      "imported_by_hints": ["<file that likely imports this>"]
    }},
    "cross_file_insight": "<one-sentence insight about cross-file relationships>"
  }}
}}

Rules:
- entry_point should be true only if this file is clearly a main entry point.
- If no algorithms are identifiable, return an empty array [].
- Every string value must be non-empty unless the array itself is empty.
- Return ONLY the JSON object. No markdown. No explanations outside JSON.
"""


# ---------------------------------------------------------------------------
# Worker
# ---------------------------------------------------------------------------

class RateLimitError(Exception):
    """Raised when Gemini returns a 429 / ResourceExhausted error."""


class Worker:
    """Stateless worker: call process() once per file."""

    def __init__(self, model_name: str = "gemini-3-flash-preview") -> None:
        self.model_name = model_name

    def process(
        self,
        file_path: Path,
        root: Path,
        api_key: str,
        context_summary: str,
    ) -> Dict[str, Any]:
        """
        Analyse *file_path* and return::

            {
                "file_path":       Path,
                "relative_path":   str,
                "html_sections":   dict,   # parsed analysis
                "context_update":  dict,
                "error":           str | None,
            }
        """
        relative_path = str(file_path.relative_to(root))
        language = LANG_MAP.get(file_path.suffix.lower(), "Unknown")

        # Read content
        try:
            content = file_path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            return self._error_result(file_path, relative_path, f"Could not read file: {exc}")

        # Build prompt
        prompt = _build_prompt(relative_path, language, content, context_summary)

        # Call Gemini
        analysis = self._call_gemini(prompt, api_key, relative_path)
        if isinstance(analysis, str):
            # Error string returned
            return self._error_result(file_path, relative_path, analysis)

        return {
            "file_path": file_path,
            "relative_path": relative_path,
            "language": language,
            "content": content,
            "html_sections": analysis,
            "context_update": analysis.get("context_update", {}),
            "error": None,
        }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _call_gemini(
        self, prompt: str, api_key: str, label: str
    ) -> Dict[str, Any] | str:
        """
        Call the Gemini API and return parsed JSON analysis.
        Returns a string error message on failure.
        Raises RateLimitError on 429.
        """
        try:
            import google.generativeai as genai
            from google.api_core.exceptions import ResourceExhausted, GoogleAPIError
        except ImportError:
            return "google-generativeai is not installed."

        try:
            genai.configure(api_key=api_key)
            model = genai.GenerativeModel(
                model_name=self.model_name,
                system_instruction=SYSTEM_PROMPT,
            )
            response = model.generate_content(
                prompt,
                generation_config=genai.GenerationConfig(
                    temperature=0.2,
                    response_mime_type="application/json",
                ),
            )
            raw = response.text.strip()
            return self._parse_json(raw, label)

        except ResourceExhausted:
            raise RateLimitError(f"Rate limited on key for: {label}")
        except Exception as exc:
            err_str = str(exc)
            # Some SDK versions wrap 429 differently
            if "429" in err_str or "quota" in err_str.lower() or "rate" in err_str.lower():
                raise RateLimitError(f"Rate limited (detected from message): {label}")
            return f"Gemini API error: {exc}"

    @staticmethod
    def _parse_json(raw: str, label: str) -> Dict[str, Any] | str:
        """Extract and parse the JSON object from the model response."""
        # Strip accidental markdown fences
        raw = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.MULTILINE)
        raw = re.sub(r"\s*```$", "", raw, flags=re.MULTILINE)
        raw = raw.strip()

        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            # Try to find any JSON object in the response
            match = re.search(r"\{.*\}", raw, re.DOTALL)
            if match:
                try:
                    return json.loads(match.group())
                except json.JSONDecodeError:
                    pass
            return f"Could not parse JSON response for {label}"

    @staticmethod
    def _error_result(
        file_path: Path, relative_path: str, error: str
    ) -> Dict[str, Any]:
        return {
            "file_path": file_path,
            "relative_path": relative_path,
            "language": "Unknown",
            "content": "",
            "html_sections": {},
            "context_update": {},
            "error": error,
        }
