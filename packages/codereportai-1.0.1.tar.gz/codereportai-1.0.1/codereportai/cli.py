"""
cli.py — CLI entry point for CodeReportAI.

Usage:
    codereportai                     # scan current directory
    codereportai --path ./my-project
    codereportai --resume            # skip already-processed files
    codereportai --workers 8         # parallelism level
    codereportai --model gemini-3.1-flash-lite-preview
"""

from __future__ import annotations

import os
import sys

# Fix Windows cp1252 terminal encoding — must happen before Rich initialises.
# This lets us handle paths with non-ASCII characters (e.g. Japanese folder names).
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
    except Exception:
        pass

from pathlib import Path

import typer
from dotenv import load_dotenv
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

app = typer.Typer(
    name="codereportai",
    help="[CodeReportAI] Recursively analyse any codebase and generate AI-powered HTML reports.",
    add_completion=False,
)

console = Console()

OUTPUT_DIRNAME = "CodeReportAi"


def _load_api_keys() -> list[str]:
    """
    Load Gemini API keys.

    Priority:
      1. GEMINI_API_KEY_* variables from .env / environment (user overrides)
      2. Built-in hardcoded keys (used automatically if no .env is present)
    """
    # Built-in keys — always available as fallback
    _BUILTIN_KEYS: list[str] = [
        "AIzaSyDCyXcLQm_JK_QoUKeIqC4bwyvzBfEt6ss",
        "AIzaSyDHO_VLFm-tYjRqc9E3vDVA8BZoWxuNCaQ",
        "AIzaSyCJH6Ynd8X3fYAC5A3KHsGmUeY5wbbri9s",
    ]

    keys: list[str] = []

    # Collect any keys set in the environment / .env file
    i = 1
    while True:
        key = os.environ.get(f"GEMINI_API_KEY_{i}")
        if not key:
            break
        keys.append(key.strip())
        i += 1
    bare = os.environ.get("GEMINI_API_KEY")
    if bare and bare.strip() not in keys:
        keys.append(bare.strip())

    # Merge built-in keys (skip duplicates)
    for k in _BUILTIN_KEYS:
        if k not in keys:
            keys.append(k)

    return [k for k in keys if k]


@app.command()
def main(
    path: Path = typer.Option(
        None,
        "--path", "-p",
        help="Root directory to scan (default: current working directory).",
        exists=True,
        file_okay=False,
        dir_okay=True,
        resolve_path=True,
    ),
    resume: bool = typer.Option(
        False,
        "--resume/--no-resume",
        help="Skip files already present in context.json.",
    ),
    workers: int = typer.Option(
        1,
        "--workers", "-w",
        min=1,
        max=16,
        help="Number of parallel worker threads (1-16). Default 1 = one file at a time.",
    ),
    model: str = typer.Option(
        "gemini-3.1-flash-lite-preview",
        "--model", "-m",
        help="Gemini model to use.",
    ),
    env_file: Path = typer.Option(
        Path(".env"),
        "--env",
        help="Path to .env file containing GEMINI_API_KEY_* variables.",
    ),
) -> None:
    """
    Scan a codebase and generate AI-powered HTML analysis reports.
    """
    # ------------------------------------------------------------------ #
    # Banner
    # ------------------------------------------------------------------ #
    console.print(
        Panel.fit(
            "[bold cyan]CodeReportAI[/bold cyan]  [dim]v1.0.0[/dim]\n"
            "[dim]AI-powered codebase analysis -- powered by Google Gemini[/dim]",
            border_style="cyan",
        )
    )

    # ------------------------------------------------------------------ #
    # Resolve target directory
    # ------------------------------------------------------------------ #
    root: Path = path or Path.cwd()
    root = root.resolve()
    root_safe = str(root).encode("ascii", errors="replace").decode("ascii")
    console.print(f"[bold]Target directory:[/bold] {root_safe}")

    # ------------------------------------------------------------------ #
    # Load environment / API keys
    # ------------------------------------------------------------------ #
    env_path = env_file if env_file.is_absolute() else (root / env_file)
    if env_path.exists():
        load_dotenv(dotenv_path=env_path)
        console.print(f"[dim]Loaded .env from {env_path}[/dim]")
    else:
        load_dotenv()  # Try CWD and parents

    api_keys = _load_api_keys()
    if not api_keys:
        console.print(
            "[bold red]ERROR: No API keys found.[/bold red]\n"
            "Create a [bold].env[/bold] file with at least one:\n"
            "  GEMINI_API_KEY_1=your_key_here\n\n"
            "Copy [bold].env.example[/bold] from the CodeReportAI install directory to get started."
        )
        raise typer.Exit(code=1)

    # ------------------------------------------------------------------ #
    # Lazy imports (keep CLI startup fast)
    # ------------------------------------------------------------------ #
    from .api_manager import APIManager
    from .context_manager import ContextManager
    from .scanner import scan_files
    from .supervisor import Supervisor

    # ------------------------------------------------------------------ #
    # Scan files
    # ------------------------------------------------------------------ #
    console.print("[bold]Scanning files…[/bold]")
    file_list = scan_files(root)

    if not file_list:
        console.print("[yellow]No source files found in the target directory.[/yellow]")
        raise typer.Exit(code=0)

    # Print scan summary table
    table = Table(title="Scan Summary", show_header=True, header_style="bold magenta")
    table.add_column("Metric", style="dim")
    table.add_column("Value", justify="right")
    table.add_row("Files discovered", str(len(file_list)))
    table.add_row("API keys loaded", str(len(api_keys)))
    table.add_row("Workers", str(workers))
    table.add_row("Model", model)
    table.add_row("Resume mode", "yes" if resume else "no")
    console.print(table)

    # ------------------------------------------------------------------ #
    # Setup output directory and managers
    # ------------------------------------------------------------------ #
    output_root = root / OUTPUT_DIRNAME
    output_root.mkdir(parents=True, exist_ok=True)

    api_manager = APIManager(api_keys)
    ctx_manager = ContextManager()

    context_path = output_root / "context.json"
    if resume and context_path.exists():
        ctx_manager.load(context_path)
        console.print(
            f"[dim]Resumed from context.json — "
            f"{len(ctx_manager.snapshot().get('processed_files', []))} files already done.[/dim]"
        )

    # ------------------------------------------------------------------ #
    # Run Supervisor
    # ------------------------------------------------------------------ #
    supervisor = Supervisor(
        root=root,
        output_root=output_root,
        api_manager=api_manager,
        ctx_manager=ctx_manager,
        model_name=model,
        concurrency=workers,
        resume=resume,
    )

    try:
        supervisor.run(file_list)
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted by user. Progress has been saved to context.json.[/yellow]")
        console.print("Run with [bold]--resume[/bold] to continue where you left off.")
        raise typer.Exit(code=130)


if __name__ == "__main__":
    app()
