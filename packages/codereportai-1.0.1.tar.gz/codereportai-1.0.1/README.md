# CodeReportAI

> 🧠 Terminal-based codebase analysis tool powered by **Google Gemini**

CodeReportAI recursively scans any codebase, sends each source file to Gemini for deep analysis, and generates a mirrored folder of **beautiful, self-contained HTML reports**.

---

## Features

- 🔍 **Deep AI Analysis** — Algorithms, design decisions, patterns, risks, and improvements per file
- 🔗 **Cross-File Intelligence** — Global context accumulates as files are processed (later files get richer analysis)
- ⚡ **Concurrent Processing** — Configurable multi-threaded workers
- 🔑 **Multi-Key Load Balancing** — Round-robin across multiple Gemini API keys with automatic cooldown on `429` errors
- ⏸ **Resume Support** — Interrupted runs resume from where they left off
- 📊 **Rich Progress UI** — Live terminal progress bar with per-file status
- 🎨 **Beautiful Reports** — Dark-mode, self-contained HTML (no CDN needed, offline-capable)

---

## Installation

```bash
# 1. Clone or navigate to the CodeReportAi directory
cd /path/to/CodeReportAi

# 2. Install (creates the `codereportai` CLI command)
pip install -e .
```

---

## Setup

Create a `.env` file in your **project folder** (or anywhere on `sys.path`):

```env
GEMINI_API_KEY_1=your_first_key_here
GEMINI_API_KEY_2=your_second_key_here   # optional, enables rotation
GEMINI_API_KEY_3=your_third_key_here    # optional
```

Copy `.env.example` to get started:

```bash
cp .env.example /path/to/your/project/.env
# then edit with your actual keys
```

---

## Usage

```bash
# Scan current directory
cd /path/to/your/project
codereportai

# Scan a specific path
codereportai --path ./my-project

# Resume an interrupted run (skips already-processed files)
codereportai --resume

# Use more workers for faster processing
codereportai --workers 8

# Use a more powerful model
codereportai --model gemini-3.1-flash-lite-preview

# All options
codereportai --path ./my-project --workers 6 --model gemini-3-flash-preview --resume
```

---

## Output Structure

Given:

```
ProjectFolder/
  ├── src/
  │     └── main.py
  └── utils/
        └── helpers.ts
```

CodeReportAI produces:

```
ProjectFolder/
  ├── src/
  │     └── main.py
  ├── utils/
  │     └── helpers.ts
  └── CodeReportAi/              ← created automatically
        ├── src/
        │     └── main.html      ← full AI analysis report
        ├── utils/
        │     └── helpers.html
        └── context.json         ← global context (enables --resume)
```

---

## CLI Options

| Flag               | Default                  | Description                       |
| ------------------ | ------------------------ | --------------------------------- |
| `--path` / `-p`    | CWD                      | Root directory to scan            |
| `--resume`         | off                      | Skip already-processed files      |
| `--workers` / `-w` | `4`                      | Number of parallel workers (1–16) |
| `--model` / `-m`   | `gemini-3-flash-preview` | Gemini model name                 |
| `--env`            | `.env`                   | Path to env file                  |

---

## What Each Report Contains

| Section                    | Description                                                |
| -------------------------- | ---------------------------------------------------------- |
| **File Overview**          | Language, purpose, line count, key imports                 |
| **Algorithms Used**        | Named algorithms with time/space complexity                |
| **Key Design Decisions**   | Architectural choices and rationale                        |
| **Alternative Approaches** | What else could have been done (and why it wasn't)         |
| **Notable Code Patterns**  | Design patterns, idioms, and anti-patterns                 |
| **Potential Improvements** | Concrete refactor and upgrade suggestions                  |
| **Cross-File Context**     | Relationships to the rest of the codebase                  |
| **Risks & Warnings**       | Security issues, performance bottlenecks, deprecated usage |

---

## Files Skipped

- Binary files, images, audio, video, archives
- `node_modules/`, `.git/`, `__pycache__/`, `dist/`, `build/`, `.venv/`
- Lock files (`package-lock.json`, `yarn.lock`, etc.)
- Minified files (`*.min.js`, `*.min.css`)
- Files larger than ~120 KB
- The `CodeReportAi/` output directory itself

---

## Requirements

- Python ≥ 3.9
- A valid Google Gemini API key ([Get one free](https://aistudio.google.com/app/apikey))

---

## License

MIT
