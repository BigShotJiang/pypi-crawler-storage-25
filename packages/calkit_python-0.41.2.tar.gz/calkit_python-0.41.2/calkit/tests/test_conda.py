"""Tests for the ``conda`` module."""

import os
import shutil
import subprocess

import pytest

import calkit
from calkit.conda import (
    _check_list,
    _check_single,
    _enrich_pip_deps_from_freeze,
    _get_pip_dependency_list,
    _split_env_dependencies,
    check_env,
)

ENV_NAME = "main"


def test_check_single():
    assert _check_single(
        "python=3.12", "python=3.12.18", env_spec_dir=".", conda=True
    )
    assert _check_single(
        "python=3", "python=3.12.18", env_spec_dir=".", conda=True
    )
    assert _check_single(
        "python=3.12.18", "python=3.12.18", env_spec_dir=".", conda=True
    )
    assert _check_single(
        "python>=3.12,<3.13", "python==3.12.18", env_spec_dir=".", conda=False
    )
    # PEP 508 git direct reference in req matches plain installed version
    assert _check_single(
        "pyxdsm @ git+https://github.com/rebeccamccabe/pyXDSM.git@fc0b49b",
        "pyxdsm==0.4.0",
        env_spec_dir=".",
        conda=False,
    )
    # Different package name must not match
    assert not _check_single(
        "pyxdsm @ git+https://github.com/rebeccamccabe/pyXDSM.git@fc0b49b",
        "other==1.0",
        env_spec_dir=".",
        conda=False,
    )
    # Both sides git: same ref → match
    assert _check_single(
        "pyxdsm @ git+https://github.com/rebeccamccabe/pyXDSM.git@fc0b49b",
        "pyxdsm @ git+https://github.com/rebeccamccabe/pyXDSM.git@fc0b49b",
        env_spec_dir=".",
        conda=False,
    )
    # Both sides git: short spec ref matches long installed ref (prefix)
    assert _check_single(
        "pyxdsm @ git+https://github.com/rebeccamccabe/pyXDSM.git@fc0b49b",
        "pyxdsm @ git+https://github.com/rebeccamccabe/pyXDSM.git@fc0b49b07ca1234",
        env_spec_dir=".",
        conda=False,
    )
    # Both sides git: different refs → no match
    assert not _check_single(
        "pyxdsm @ git+https://github.com/rebeccamccabe/pyXDSM.git@fc0b49b",
        "pyxdsm @ git+https://github.com/rebeccamccabe/pyXDSM.git@aabbcc1",
        env_spec_dir=".",
        conda=False,
    )


def test_enrich_pip_deps_from_freeze():
    pip_freeze = [
        "numpy==1.24.3",
        "pyxdsm @ git+https://github.com/rebeccamccabe/pyXDSM.git@fc0b49b07ca",
        "scipy==1.11.0",
    ]
    spec_deps = [
        "numpy==1.24.3",
        "pyxdsm @ git+https://github.com/rebeccamccabe/pyXDSM.git@fc0b49b",
        "scipy",
    ]
    result = _enrich_pip_deps_from_freeze(spec_deps, pip_freeze)
    # numpy and scipy get the exact freeze version
    assert "numpy==1.24.3" in result
    assert "scipy==1.11.0" in result
    # pyxdsm gets the full git URL from freeze
    assert any("fc0b49b07ca" in r for r in result)
    # Editable installs are kept unchanged
    editable = ["-e ../mypackage", "numpy==1.24.3"]
    result2 = _enrich_pip_deps_from_freeze(editable, pip_freeze)
    assert result2[0] == "-e ../mypackage"


def test_check_list():
    installed = ["python=3.12.1", "numpy=1.0.11"]
    assert _check_list("python=3", installed, env_spec_dir=".", conda=True)
    assert _check_list("numpy", installed, env_spec_dir=".", conda=True)
    assert not _check_list("pandas", installed, env_spec_dir=".", conda=True)
    installed = ["python==3.12.1", "numpy==1.0.11"]
    assert _check_list("python>=3", installed, env_spec_dir=".", conda=False)
    assert _check_list("numpy", installed, env_spec_dir=".", conda=False)
    assert not _check_list("pandas", installed, env_spec_dir=".", conda=False)


def test_split_env_dependencies():
    dependencies = [
        "python=3.12",
        "pip",
        "numpy=2",
        {"pip": ["sqlalchemy==2.0.39"]},
    ]
    conda_deps, pip_deps = _split_env_dependencies(dependencies)
    assert conda_deps == ["python=3.12", "pip", "numpy=2"]
    assert pip_deps == ["sqlalchemy==2.0.39"]


def test_get_pip_dependency_list():
    dependencies = ["python=3.12", "pip", {"pip": "sqlalchemy==2.0.39"}]
    pip_deps = _get_pip_dependency_list(dependencies)
    assert pip_deps == ["sqlalchemy==2.0.39"]
    assert dependencies[-1]["pip"] == ["sqlalchemy==2.0.39"]


def delete_env(name: str):
    subprocess.check_call(["conda", "env", "remove", "-y", "-n", name])


@pytest.fixture
def conda_env_name():
    name = calkit.to_kebab_case(os.path.basename(os.getcwd())) + "." + ENV_NAME
    yield name
    # Teardown code
    delete_env(name)


def test_check_env(tmp_dir, conda_env_name):
    subprocess.check_call(["calkit", "init"])
    subprocess.check_call(
        [
            "calkit",
            "new",
            "conda-env",
            "-n",
            ENV_NAME,
            "--no-check",
            "python=3.13",
            "pip",
            "h5py",
            "--pip",
            "pxl",
        ]
    )
    res = check_env()
    print("Res before env exists:", res)
    assert not res.env_exists
    res = check_env(log_func=print)
    print("Res after env created:", res)
    assert res.env_exists
    assert not res.env_needs_export
    assert not res.env_needs_rebuild
    # Now let's update the env spec so it needs a rebuild
    subprocess.check_call(
        [
            "calkit",
            "new",
            "conda-env",
            "--overwrite",
            "-n",
            ENV_NAME,
            "--no-check",
            "python=3.11.0",
            "pip",
            "--pip",
            "pxl",
        ]
    )
    res = check_env()
    assert res.env_exists
    assert res.env_needs_export
    assert res.env_needs_rebuild
    res = check_env()
    assert not res.env_needs_rebuild
    assert not res.env_needs_export
    # Check relaxed mode, where we allow dependencies to be in either the pip
    # or conda section
    subprocess.check_call(
        [
            "calkit",
            "new",
            "conda-env",
            "--overwrite",
            "-n",
            ENV_NAME,
            "--no-check",
            "python=3.11.0",
            "pip",
            "sqlalchemy",
        ]
    )
    subprocess.check_call(
        [
            "conda",
            "run",
            "-n",
            conda_env_name,
            "pip",
            "install",
            "--upgrade",
            "sqlalchemy",
        ]
    )
    res = check_env()
    assert res.env_needs_rebuild
    subprocess.check_call(
        [
            "calkit",
            "new",
            "conda-env",
            "--overwrite",
            "-n",
            ENV_NAME,
            "--no-check",
            "python=3.11.0",
            "pip",
            "sqlalchemy",
        ]
    )
    res = check_env(relaxed=True)
    assert not res.env_needs_rebuild
    subprocess.check_call(
        [
            "calkit",
            "new",
            "conda-env",
            "--overwrite",
            "-n",
            ENV_NAME,
            "--no-check",
            "python=3.11.0",
            "pip",
            "--pip",
            "sqlalchemy",
        ]
    )
    res = check_env(relaxed=True)
    assert not res.env_needs_rebuild
    # Make sure we can handle other ways of specifying versions
    subprocess.check_call(
        [
            "calkit",
            "new",
            "conda-env",
            "--overwrite",
            "-n",
            ENV_NAME,
            "--no-check",
            "python=3.12",
            "--pip",
            "numpy>=1",
        ]
    )
    res = check_env()
    assert res.env_needs_rebuild
    res = check_env()
    assert not res.env_needs_export
    assert not res.env_needs_rebuild


@pytest.fixture
def conda_env_prefix():
    prefix = ".conda-envs/my-conda-env"
    yield prefix
    subprocess.check_call(["conda", "env", "remove", "-y", "--prefix", prefix])


def test_check_prefix_env(tmp_dir, conda_env_prefix):
    subprocess.check_call(["calkit", "init"])
    # Test we can use a local prefix
    subprocess.check_call(
        [
            "calkit",
            "new",
            "conda-env",
            "-n",
            "my-conda-env",
            "python=3.12",
            "--prefix",
            conda_env_prefix,
            "--no-check",
        ]
    )
    res = check_env()
    assert not res.env_exists
    assert res.env_needs_export
    assert os.path.isfile(os.path.join(conda_env_prefix, "env-export.yml"))
    res = check_env()
    assert res.env_exists
    # Env will need to be exported a second time since we save it inside the
    # prefix folder, so the mtime will be slightly after creation of the
    # initial environment
    assert res.env_needs_export
    assert not res.env_needs_rebuild
    # Now the env should be exported okay
    res = check_env()
    assert res.env_exists
    assert not res.env_needs_export
    assert not res.env_needs_rebuild
    subprocess.check_call(
        ["calkit", "xenv", "-n", "my-conda-env", "python", "--version"]
    )
    # Test that we can add a new dependency
    with open("environment.yml") as f:
        env = calkit.ryaml.load(f)
    env["dependencies"].append("requests")
    with open("environment.yml", "w") as f:
        calkit.ryaml.dump(env, f)
    res = check_env()
    assert res.env_exists
    assert res.env_needs_export
    assert res.env_needs_rebuild
    subprocess.check_call(
        [
            "calkit",
            "xenv",
            "-n",
            "my-conda-env",
            "python",
            "-c",
            "import requests",
        ]
    )
    # Test that we can specify --wdir
    os.makedirs("subdir")
    subprocess.check_call(
        [
            "calkit",
            "xenv",
            "--wdir",
            "subdir",
            "-n",
            "my-conda-env",
            "python",
            "-c",
            "import requests",
        ]
    )


def test_check_env_editable(tmp_dir, conda_env_name):
    subprocess.check_call(["calkit", "init"])
    # Create a dummy package named 'src' to install in editable mode
    os.makedirs("src", exist_ok=True)
    with open("src/__init__.py", "w") as f:
        f.write("def hello():\n    return 'Hello, World!'\n")
    with open("setup.py", "w") as f:
        f.write(
            """from setuptools import setup, find_packages
setup(
    name="src",
    version="0.0.1",
    packages=find_packages(),
)
"""
        )
    subprocess.check_call(
        [
            "calkit",
            "new",
            "conda-env",
            "-n",
            ENV_NAME,
            "--no-check",
            "python=3.12",
            "pip",
            "h5py",
            "--pip",
            "-e .",
        ]
    )
    res = check_env()
    assert not res.env_exists
    # Make sure we actually installed in editable mode by checking for
    # src.egg-info
    assert os.path.isdir("src.egg-info")
    res = check_env()
    assert res.env_exists
    assert not res.env_needs_rebuild
    # Check that the lock file has the editable syntax, not the package name
    with open("environment-lock.yml") as f:
        lock = calkit.ryaml.load(f)
    pip_deps = lock["dependencies"][-1]["pip"]
    assert "-e ." in pip_deps
    # Now let's make sure we get proper output if the editable package is
    # has an invalid pyproject.toml
    os.remove("setup.py")
    shutil.rmtree("src.egg-info")
    toml_txt = """[build-system]
requires = ["setuptools>=61.0.0", "wheel", "setuptools-scm>=8"]
build-backend = "setuptools.build_meta"

[project]
name = "src-thing"
dynamic = ["version"]
authors = [
  {name = "Someone"}
]
description = "Test"

dependencies = [
    "numpy>=1.21",
    "scipy>=1.7",
    "pandas>=1.5",
    "matplotlib>=3.5",
    "h5netcdf>=0.12",
    "h5py>=3.0",
    "xarray>=2023.0",
    "streamlit>=1.0"
]

[tool.setuptools]
package-dir = {"" = "src"}
packages = ["src-thing"]

[tool.setuptools.packages.find]
where = ["src"]

[tool.setuptools.package-data]
"src-thing" = [] # Explicitly state no package data

[tool.setuptools_scm]
local_scheme = "no-local-version"
fallback_version = "0+unknown"
"""
    with open("pyproject.toml", "w") as f:
        f.write(toml_txt)
    with pytest.raises(Exception, match="Failed to load pyproject.toml"):
        res = check_env()
    # Fix it and make sure it runs with relaxed mode
    toml_txt = """[build-system]
requires = ["setuptools>=61.0.0", "wheel", "setuptools-scm>=8"]
build-backend = "setuptools.build_meta"

[project]
name = "src-thing"
dynamic = ["version"]
authors = [
  {name = "Someone"}
]
description = "Test"

dependencies = []

[tool.setuptools]
packages = ["src"]

[tool.setuptools_scm]
local_scheme = "no-local-version"
fallback_version = "0+unknown"
"""
    with open("pyproject.toml", "w") as f:
        f.write(toml_txt)
    res = check_env(relaxed=True)
    assert res.env_exists
    assert res.env_needs_rebuild
    assert res.env_needs_export
    # Make sure we can import the editable package
    os.makedirs("subdir")
    subprocess.check_call(
        [
            "conda",
            "run",
            "-n",
            conda_env_name,
            "python",
            "-c",
            "import src; print('src file:', src.__file__);",
        ],
        cwd="subdir",
    )
    # Check again and make sure we don't need a rebuild since the editable
    # package is still valid
    res = check_env(relaxed=True)
    assert res.env_exists
    assert not res.env_needs_rebuild


def test_find_conda_exe():
    conda_exe = calkit.conda.find_conda_exe()
    assert conda_exe is not None
    assert os.path.isfile(conda_exe)


def test_find_mamba_exe():
    mamba_exe = calkit.conda.find_mamba_exe()
    # Mamba may not be installed, so we just check that it returns None or a
    # valid path
    if mamba_exe is not None:
        assert os.path.isfile(mamba_exe)
