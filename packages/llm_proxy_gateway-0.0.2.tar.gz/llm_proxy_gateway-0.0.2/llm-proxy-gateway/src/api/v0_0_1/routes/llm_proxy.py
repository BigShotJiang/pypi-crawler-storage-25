from fastapi import APIRouter, Request
from fastapi.responses import StreamingResponse

from schemas.llm_proxy import (
    AnthropicMessagesRequest,
    AnthropicMessagesResponse,
    ChatCompletionRequest,
    ChatCompletionResponse,
    ResponsesRequest,
    ResponsesResponse,
)
from services.llm_proxy_service import (
    handle_anthropic_messages,
    handle_chat_completions,
    handle_responses,
)

router = APIRouter(tags=["LLM Proxy"])


@router.post(
    "/v1/chat/completions",
    response_model=ChatCompletionResponse,
    summary="OpenAI-compatible chat completions proxy",
    description="Accepts OpenAI chat completion style requests and forwards them to the configured upstream LLM service.",
)
async def chat_completions(
    _: ChatCompletionRequest,
    request: Request,
) -> ChatCompletionResponse | StreamingResponse:
    return await handle_chat_completions(request)


@router.post(
    "/v1/responses",
    response_model=ResponsesResponse,
    summary="OpenAI Responses API compatible proxy",
    description="Accepts OpenAI Responses API style payloads and returns a normalized response from the upstream LLM service.",
)
async def responses(
    _: ResponsesRequest,
    request: Request,
) -> ResponsesResponse | StreamingResponse:
    return await handle_responses(request)


@router.post(
    "/v1/messages",
    response_model=AnthropicMessagesResponse,
    summary="Anthropic messages compatible proxy",
    description="Accepts Anthropic messages API style requests and maps them to the configured upstream LLM service.",
)
async def anthropic_messages(
    _: AnthropicMessagesRequest,
    request: Request,
) -> AnthropicMessagesResponse | StreamingResponse:
    return await handle_anthropic_messages(request)