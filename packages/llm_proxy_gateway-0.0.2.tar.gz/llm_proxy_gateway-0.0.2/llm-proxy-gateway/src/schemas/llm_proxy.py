from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class ChatMessage(BaseModel):
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "role": "user",
                "content": "Explain microservice architecture in simple terms."
            }
        }
    )

    role: Literal["system", "user"]
    content: str | list[dict[str, Any]]


class ChatCompletionRequest(BaseModel):
    model_config = ConfigDict(
        extra="allow",
        json_schema_extra={
            "example": {
                "model": "gpt-4.1",
                "messages": [
                    {"role": "system", "content": "You are a helpful assistant."},
                    {"role": "user", "content": "Write a hello world in Python."}
                ],
                "stream": False
            }
        },
    )

    model: str = Field(description="Target upstream LLM model name.", examples=["gpt-4.1"])
    messages: list[ChatMessage] = Field(description="OpenAI-style conversation messages.")
    stream: bool = Field(default=False, description="Whether to stream partial tokens as server-sent events.")


class ChatCompletionChoiceMessage(BaseModel):
    role: Literal["assistant"] = "assistant"
    content: str


class ChatCompletionChoice(BaseModel):
    index: int
    message: ChatCompletionChoiceMessage
    finish_reason: str


class ChatCompletionUsage(BaseModel):
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


class ChatCompletionResponse(BaseModel):
    id: str
    object: Literal["chat.completion"]
    created: int
    model: str
    choices: list[ChatCompletionChoice]
    usage: ChatCompletionUsage


class ResponseContentPart(BaseModel):
    model_config = ConfigDict(
        extra="allow",
        json_schema_extra={
            "example": {
                "type": "input_text",
                "text": "Summarize this document."
            }
        },
    )

    type: str = Field(description="Content part type, for example `input_text` or `text`.")
    text: str | None = Field(default=None, description="Plain text value for the content part.")


class ResponseInputItem(BaseModel):
    model_config = ConfigDict(
        extra="allow",
        json_schema_extra={
            "example": {
                "role": "user",
                "content": [
                    {"type": "input_text", "text": "List three benefits of FastAPI."}
                ]
            }
        },
    )

    role: str | None = Field(default=None, description="Logical role of the input item, usually `user`.")
    content: str | list[ResponseContentPart] | list[dict[str, Any]] | None = Field(
        default=None,
        description="Either plain text input or structured content parts.",
    )


class ResponsesRequest(BaseModel):
    model_config = ConfigDict(
        extra="allow",
        json_schema_extra={
            "examples": [
                {
                    "model": "gpt-4.1",
                    "input": "Write a short poem about APIs.",
                    "stream": False,
                    "instructions": "Be concise"
                },
                {
                    "model": "gpt-4.1",
                    "input": [
                        {
                            "role": "user",
                            "content": [
                                {"type": "input_text", "text": "Explain SSE streaming."}
                            ]
                        }
                    ],
                    "stream": True
                }
            ]
        },
    )

    model: str = Field(description="Target upstream LLM model name.", examples=["gpt-4.1"])
    input: str | list[ResponseInputItem] = Field(description="OpenAI Responses API style input payload.")
    stream: bool = Field(default=False, description="Whether to stream response deltas as server-sent events.")
    instructions: str | None = Field(default=None, description="Optional high-level system instruction.")
    max_output_tokens: int | None = Field(default=None, description="Optional max output token override.")


class OutputTextContent(BaseModel):
    type: Literal["output_text"]
    text: str
    annotations: list[dict[str, Any]] = Field(default_factory=list)


class ResponseOutputItem(BaseModel):
    id: str
    type: Literal["message"]
    status: Literal["completed"]
    role: Literal["assistant"]
    content: list[OutputTextContent]


class ResponseTextFormat(BaseModel):
    type: Literal["text"]


class ResponseText(BaseModel):
    format: ResponseTextFormat


class InputTokensDetails(BaseModel):
    cached_tokens: int


class OutputTokensDetails(BaseModel):
    reasoning_tokens: int


class ResponsesUsage(BaseModel):
    input_tokens: int
    output_tokens: int
    total_tokens: int
    input_tokens_details: InputTokensDetails
    output_tokens_details: OutputTokensDetails


class ResponsesResponse(BaseModel):
    id: str
    object: Literal["response"]
    created_at: int
    status: Literal["completed"]
    error: None = None
    incomplete_details: None = None
    instructions: str | None = None
    max_output_tokens: int
    model: str
    output: list[ResponseOutputItem]
    parallel_tool_calls: bool
    temperature: float
    top_p: float
    text: ResponseText
    usage: ResponsesUsage


class AnthropicTextPart(BaseModel):
    model_config = ConfigDict(
        extra="allow",
        json_schema_extra={
            "example": {
                "type": "text",
                "text": "How do I build a FastAPI app?"
            }
        },
    )

    type: str = Field(description="Anthropic content part type, usually `text`.")
    text: str | None = Field(default=None, description="Text content for the part.")


class AnthropicMessageInput(BaseModel):
    model_config = ConfigDict(
        extra="allow",
        json_schema_extra={
            "example": {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Give me a deployment checklist."}
                ]
            }
        },
    )

    role: Literal["user", "assistant"] = Field(description="Anthropic message role.")
    content: str | list[AnthropicTextPart] | list[dict[str, Any]] = Field(
        description="Anthropic-style message content as plain text or typed parts."
    )


class AnthropicMessagesRequest(BaseModel):
    model_config = ConfigDict(
        extra="allow",
        json_schema_extra={
            "example": {
                "model": "claude-sonnet-4",
                "system": "You are a concise assistant.",
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": "Summarize event-driven architecture."}
                        ]
                    }
                ],
                "stream": False
            }
        },
    )

    model: str = Field(description="Target upstream model name.", examples=["claude-sonnet-4"])
    messages: list[AnthropicMessageInput] = Field(description="Anthropic-style conversation messages.")
    system: str | list[AnthropicTextPart] | list[dict[str, Any]] | None = Field(
        default=None,
        description="Optional system prompt as string or content parts.",
    )
    stream: bool = Field(default=False, description="Whether to stream Anthropic-style SSE events.")


class AnthropicResponseContent(BaseModel):
    type: Literal["text"]
    text: str


class AnthropicUsage(BaseModel):
    input_tokens: int
    output_tokens: int


class AnthropicMessagesResponse(BaseModel):
    id: str
    type: Literal["message"]
    role: Literal["assistant"]
    model: str
    content: list[AnthropicResponseContent]
    stop_reason: Literal["end_turn"]
    stop_sequence: None = None
    usage: AnthropicUsage