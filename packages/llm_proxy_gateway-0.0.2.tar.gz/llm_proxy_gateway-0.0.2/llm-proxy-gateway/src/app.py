from logging import Logger

import uvicorn
from fastapi import FastAPI

from api.v0_0_1.routes.health import router as health_router
from api.v0_0_1.routes.llm_proxy import router as llm_proxy_router
from utils.app_config import AppConfig
from utils.logger import get_logger

logger: Logger | None = None


def create_app() -> FastAPI:
    app = FastAPI(title="LLM Proxy Gateway")
    app.include_router(health_router)
    app.include_router(llm_proxy_router)
    return app


app = create_app()


def main() -> None:
    global logger

    try:
        logger = get_logger(__name__)
    except Exception as e:
        print(f"Error setting up logging: {e}")
        return

    logger.debug("Starting LLM Proxy Gateway...")

    config = AppConfig()
    provider = config.LLM_PROVIDER or ""
    port = int(config.API_SERVER_PORT or "8000")

    logger.info("starting provider=%s port=%s", provider, port)

    uvicorn.run("app:app", host="0.0.0.0", port=port, log_level=(config.LOG_LEVEL or "info").lower())