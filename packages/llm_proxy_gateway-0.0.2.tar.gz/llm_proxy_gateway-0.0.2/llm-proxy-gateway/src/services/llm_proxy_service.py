import json
import logging
import time
import uuid
from typing import Any, Mapping, Sequence

from fastapi import HTTPException, Request
from fastapi.responses import StreamingResponse
from langchain_core.messages import AIMessage, AIMessageChunk, HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI
from pydantic import SecretStr

from schemas.llm_proxy import (
    AnthropicMessagesRequest,
    AnthropicMessagesResponse,
    AnthropicResponseContent,
    AnthropicUsage,
    ChatCompletionChoice,
    ChatCompletionChoiceMessage,
    ChatCompletionRequest,
    ChatCompletionResponse,
    ChatCompletionUsage,
    InputTokensDetails,
    OutputTextContent,
    OutputTokensDetails,
    ResponseOutputItem,
    ResponseText,
    ResponseTextFormat,
    ResponsesRequest,
    ResponsesResponse,
    ResponsesUsage,
)
from utils.app_config import AppConfig

logger = logging.getLogger("llm_proxy_gateway.proxy")


def get_llm_config() -> AppConfig:
    return AppConfig()


def create_client(model: str) -> ChatOpenAI:
    config = get_llm_config()
    api_key = config.OPENAI_API_KEY
    base_url = config.OPENAI_BASE_URL

    if not api_key:
        raise HTTPException(status_code=500, detail="OPENAI_API_KEY is required")

    kwargs: dict[str, Any] = {
        "model": model,
        "api_key": SecretStr(api_key),
        "streaming": True,
    }
    if base_url:
        kwargs["base_url"] = base_url

    return ChatOpenAI(**kwargs)


async def parse_request_json(request: Request) -> dict[str, Any]:
    try:
        body = await request.json()
    except json.JSONDecodeError as exc:
        raise HTTPException(
            status_code=400,
            detail={
                "message": "Invalid JSON body.",
                "hint": "Remove trailing commas and ensure all property names use double quotes.",
                "upstream": str(exc),
            },
        ) from exc

    if not isinstance(body, dict):
        raise HTTPException(status_code=400, detail="JSON body must be an object")
    return body


def log_request(endpoint: str, body: Any) -> None:
    logger.info("request endpoint=%s body=%s", endpoint, json.dumps(body, default=str))


def log_response(endpoint: str, response_body: Any) -> None:
    logger.info("response endpoint=%s body=%s", endpoint, json.dumps(response_body, default=str))


def log_stream_event(endpoint: str, event_type: str, payload: Any) -> None:
    logger.info(
        "stream endpoint=%s event=%s body=%s",
        endpoint,
        event_type,
        json.dumps(payload, default=str),
    )


def to_langchain_messages(messages: list[dict[str, Any]]) -> list[SystemMessage | HumanMessage]:
    converted: list[SystemMessage | HumanMessage] = []
    for message in messages:
        role = message.get("role")
        content = message.get("content")

        if not isinstance(content, str):
            raise HTTPException(status_code=400, detail=f"Unsupported content for role: {role}")

        if role == "system":
            converted.append(SystemMessage(content=content))
        elif role == "user":
            converted.append(HumanMessage(content=content))
        else:
            raise HTTPException(status_code=400, detail=f"Unsupported role: {role}")

    return converted


def extract_responses_input_text(input_items: list[dict[str, Any]]) -> str:
    parts: list[str] = []

    for item in input_items:
        content = item.get("content")

        if isinstance(content, str):
            parts.append(content)
            continue

        if isinstance(content, list):
            for part in content:
                if isinstance(part, dict) and part.get("type") in {"input_text", "text"} and isinstance(part.get("text"), str):
                    parts.append(part["text"])

    return "\n".join(parts)


def extract_anthropic_system(system_value: Any) -> str | None:
    if isinstance(system_value, str):
        return system_value

    if isinstance(system_value, list):
        parts: list[str] = []
        for item in system_value:
            if isinstance(item, dict) and item.get("type") == "text" and isinstance(item.get("text"), str):
                parts.append(item["text"])
        return "\n".join(parts) if parts else None

    return None


def to_langchain_messages_from_anthropic(system_value: Any, messages: list[dict[str, Any]]) -> list[SystemMessage | HumanMessage | AIMessage]:
    converted: list[SystemMessage | HumanMessage | AIMessage] = []
    system_text = extract_anthropic_system(system_value)

    if system_text:
        converted.append(SystemMessage(content=system_text))

    for message in messages:
        role = message.get("role")
        content = message.get("content")

        if isinstance(content, str):
            text_content = content
        elif isinstance(content, list):
            text_parts: list[str] = []
            for part in content:
                if isinstance(part, dict) and part.get("type") == "text" and isinstance(part.get("text"), str):
                    text_parts.append(part["text"])
            text_content = "\n".join(text_parts)
        else:
            text_content = None

        if not text_content:
            continue

        if role == "user":
            converted.append(HumanMessage(content=text_content))
        elif role == "assistant":
            converted.append(AIMessage(content=text_content))
        else:
            raise HTTPException(status_code=400, detail=f"Unsupported role: {role}")

    return converted


def estimate_token_count(text: str) -> int:
    stripped = text.strip()
    if not stripped:
        return 0
    return max(1, len(stripped.split()))


def messages_text_for_usage(messages: list[dict[str, Any]]) -> str:
    parts: list[str] = []

    for message in messages:
        content = message.get("content")
        if isinstance(content, str):
            parts.append(content)
        elif isinstance(content, list):
            for part in content:
                if isinstance(part, dict) and isinstance(part.get("text"), str):
                    parts.append(part["text"])

    return "\n".join(parts)


def extract_chunk_text(chunk: Any) -> str:
    if not isinstance(chunk, AIMessageChunk) or not chunk.content:
        return ""

    if isinstance(chunk.content, str):
        return chunk.content

    return "".join(part.get("text", "") for part in chunk.content if isinstance(part, dict))


def get_event_chunk(event: Mapping[str, Any]) -> Any | None:
    data = event.get("data")
    if not isinstance(data, dict):
        return None
    return data.get("chunk")


async def collect_agent_text(
    client: ChatOpenAI,
    messages: Sequence[SystemMessage | HumanMessage | AIMessage],
) -> str:
    result = await client.ainvoke(messages)
    if isinstance(result.content, str):
        return result.content
    if isinstance(result.content, list):
        return "".join(part.get("text", "") for part in result.content if isinstance(part, dict))
    return str(result.content)


async def handle_chat_completions(request: Request):
    endpoint = "/v1/chat/completions"
    raw_body = await parse_request_json(request)
    body = ChatCompletionRequest.model_validate(raw_body)
    log_request(endpoint, body)
    model = body.model
    messages = [message.model_dump() for message in body.messages]
    stream_requested = body.stream

    client = create_client(model)
    lc_messages = to_langchain_messages(messages)

    if stream_requested:
        async def event_generator():
            created = int(time.time())
            chunk_id = f"chatcmpl-{uuid.uuid4().hex}"
            try:
                async for chunk in client.astream(lc_messages):
                    text = extract_chunk_text(chunk)
                    if not text:
                        continue
                    payload = {
                        "id": chunk_id,
                        "object": "chat.completion.chunk",
                        "created": created,
                        "model": model,
                        "choices": [{"index": 0, "delta": {"content": text}, "finish_reason": None}],
                    }
                    log_stream_event(endpoint, "chat.completion.chunk", payload)
                    yield f"data: {json.dumps(payload)}\n\n"

                final_payload = {
                    "id": chunk_id,
                    "object": "chat.completion.chunk",
                    "created": created,
                    "model": model,
                    "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}],
                }
                log_stream_event(endpoint, "chat.completion.chunk", final_payload)
                yield f"data: {json.dumps(final_payload)}\n\n"
                yield "data: [DONE]\n\n"
            except Exception as exc:
                error_payload = {"error": {"message": "Upstream request failed.", "upstream": str(exc)}}
                log_stream_event(endpoint, "error", error_payload)
                yield f"data: {json.dumps(error_payload)}\n\n"

        return StreamingResponse(event_generator(), media_type="text/event-stream")

    try:
        content = await collect_agent_text(client, lc_messages)
    except Exception as exc:
        raise HTTPException(status_code=502, detail={"message": "Request failed", "upstream": str(exc)}) from exc

    created = int(time.time())
    prompt_tokens = estimate_token_count(messages_text_for_usage(messages))
    completion_tokens = estimate_token_count(content)
    total_tokens = prompt_tokens + completion_tokens

    response_body = ChatCompletionResponse(
        id=f"chatcmpl-{uuid.uuid4().hex}",
        object="chat.completion",
        created=created,
        model=model,
        choices=[
            ChatCompletionChoice(
                index=0,
                message=ChatCompletionChoiceMessage(role="assistant", content=content),
                finish_reason="stop",
            )
        ],
        usage=ChatCompletionUsage(
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
        ),
    )
    log_response(endpoint, response_body)
    return response_body


async def handle_responses(request: Request):
    endpoint = "/v1/responses"
    config = get_llm_config()
    raw_body = await parse_request_json(request)
    body = ResponsesRequest.model_validate(raw_body)
    log_request(endpoint, body)
    model = body.model
    input_items = body.input
    stream_requested = body.stream

    if not input_items:
        raise HTTPException(status_code=400, detail="No input provided")

    if isinstance(input_items, str):
        messages = [{"role": "user", "content": input_items}]
    elif isinstance(input_items, list):
        input_text = extract_responses_input_text([item.model_dump() for item in input_items])
        if not input_text:
            raise HTTPException(status_code=400, detail="Unsupported input content")
        messages = [{"role": "user", "content": input_text}]
    else:
        raise HTTPException(status_code=400, detail="Unsupported input format")

    if body.instructions:
        messages.insert(0, {"role": "system", "content": body.instructions})

    client = create_client(model)
    lc_messages = to_langchain_messages(messages)

    if stream_requested:
        async def event_generator():
            response_id = f"resp_{uuid.uuid4().hex}"
            try:
                async for chunk in client.astream(lc_messages):
                    text = extract_chunk_text(chunk)
                    if not text:
                        continue
                    payload = {"type": "response.output_text.delta", "delta": text}
                    log_stream_event(endpoint, "response.output_text.delta", payload)
                    yield f"data: {json.dumps(payload)}\n\n"

                completed_payload = {
                    "type": "response.completed",
                    "response": {"id": response_id, "object": "response", "model": model, "status": "completed"},
                }
                log_stream_event(endpoint, "response.completed", completed_payload)
                yield f"data: {json.dumps(completed_payload)}\n\n"
                yield "data: [DONE]\n\n"
            except Exception as exc:
                error_payload = {"error": {"message": "Upstream request failed.", "upstream": str(exc)}}
                log_stream_event(endpoint, "error", error_payload)
                yield f"data: {json.dumps(error_payload)}\n\n"

        return StreamingResponse(event_generator(), media_type="text/event-stream")

    try:
        content = await collect_agent_text(client, lc_messages)
    except Exception as exc:
        raise HTTPException(status_code=502, detail={"message": "Request failed", "upstream": str(exc)}) from exc

    created = int(time.time())
    input_tokens = estimate_token_count(messages_text_for_usage(messages))
    output_tokens = estimate_token_count(content)
    total_tokens = input_tokens + output_tokens

    response_body = ResponsesResponse(
        id=f"resp_{uuid.uuid4().hex}",
        object="response",
        created_at=created,
        status="completed",
        error=None,
        incomplete_details=None,
        instructions=body.instructions,
        max_output_tokens=body.max_output_tokens or 0,
        model=model,
        output=[
            ResponseOutputItem(
                id=f"msg_{uuid.uuid4().hex}",
                type="message",
                status="completed",
                role="assistant",
                content=[OutputTextContent(type="output_text", text=content, annotations=[])],
            )
        ],
        parallel_tool_calls=False,
        temperature=0,
        top_p=1,
        text=ResponseText(format=ResponseTextFormat(type="text")),
        usage=ResponsesUsage(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=total_tokens,
            input_tokens_details=InputTokensDetails(cached_tokens=0),
            output_tokens_details=OutputTokensDetails(reasoning_tokens=0),
        ),
    )
    log_response(endpoint, response_body)
    return response_body


async def handle_anthropic_messages(request: Request):
    endpoint = "/v1/messages"
    raw_body = await parse_request_json(request)
    body = AnthropicMessagesRequest.model_validate(raw_body)
    log_request(endpoint, body)
    model = body.model
    messages = [message.model_dump() for message in body.messages]
    system_value = body.system
    stream_requested = body.stream

    client = create_client(model)
    lc_messages = to_langchain_messages_from_anthropic(system_value, messages)

    if stream_requested:
        async def event_generator():
            message_id = f"msg_{uuid.uuid4().hex}"
            try:
                start_payload = {
                    "type": "message_start",
                    "message": {
                        "id": message_id,
                        "type": "message",
                        "role": "assistant",
                        "model": model,
                        "content": [],
                        "stop_reason": None,
                        "stop_sequence": None,
                        "usage": {"input_tokens": 0, "output_tokens": 0},
                    },
                }
                log_stream_event(endpoint, "message_start", start_payload)
                yield f"event: message_start\ndata: {json.dumps(start_payload)}\n\n"

                async for chunk in client.astream(lc_messages):
                    text = extract_chunk_text(chunk)
                    if not text:
                        continue
                    delta_payload = {
                        "type": "content_block_delta",
                        "index": 0,
                        "delta": {"type": "text_delta", "text": text},
                    }
                    log_stream_event(endpoint, "content_block_delta", delta_payload)
                    yield f"event: content_block_delta\ndata: {json.dumps(delta_payload)}\n\n"

                stop_payload = {"type": "message_stop"}
                log_stream_event(endpoint, "message_stop", stop_payload)
                yield f"event: message_stop\ndata: {json.dumps(stop_payload)}\n\n"
            except Exception as exc:
                error_payload = {"error": {"message": "Upstream request failed.", "upstream": str(exc)}}
                log_stream_event(endpoint, "error", error_payload)
                yield f"event: error\ndata: {json.dumps(error_payload)}\n\n"

        return StreamingResponse(event_generator(), media_type="text/event-stream")

    try:
        content = await collect_agent_text(client, lc_messages)
    except Exception as exc:
        raise HTTPException(status_code=502, detail={"message": "Request failed", "upstream": str(exc)}) from exc

    input_parts: list[str] = []
    system_text = extract_anthropic_system(system_value)
    if system_text:
        input_parts.append(system_text)
    input_parts.append(messages_text_for_usage(messages))
    input_tokens = estimate_token_count("\n".join(part for part in input_parts if part))
    output_tokens = estimate_token_count(content)

    response_body = AnthropicMessagesResponse(
        id=f"msg_{uuid.uuid4().hex}",
        type="message",
        role="assistant",
        model=model,
        content=[AnthropicResponseContent(type="text", text=content)],
        stop_reason="end_turn",
        stop_sequence=None,
        usage=AnthropicUsage(input_tokens=input_tokens, output_tokens=output_tokens),
    )
    log_response(endpoint, response_body)
    return response_body