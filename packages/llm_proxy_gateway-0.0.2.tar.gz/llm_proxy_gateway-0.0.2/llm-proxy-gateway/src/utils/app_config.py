import importlib
import os


def load_dotenv() -> bool:
    dotenv = importlib.import_module("dotenv")
    return bool(dotenv.load_dotenv())

class AppConfig:
    def __init__(self):
        try:
            load_dotenv()
        except ModuleNotFoundError:
            pass
        
        self.LOG_LEVEL = os.getenv('LOG_LEVEL')
        self.LLM_PROVIDER = os.getenv('LLM_PROVIDER')
        self.API_SERVER_PORT = os.getenv('API_SERVER_PORT')
        self.OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
        self.OPENAI_MODEL = os.getenv('OPENAI_MODEL')
        self.OPENAI_BASE_URL = os.getenv('OPENAI_BASE_URL')
