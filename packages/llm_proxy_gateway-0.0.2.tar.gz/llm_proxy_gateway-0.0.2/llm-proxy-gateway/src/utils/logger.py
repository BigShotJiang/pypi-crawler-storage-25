import logging
import sys
from importlib import import_module
from .app_config import AppConfig

UvicornDefaultFormatter = None

try:
    uvicorn_logging = import_module("uvicorn.logging")
    UvicornDefaultFormatter = getattr(uvicorn_logging, "DefaultFormatter", None)
except ModuleNotFoundError:
    pass


def get_logger(name: str) -> logging.Logger:
    config = AppConfig()
    logger = logging.getLogger(name)

    if logger.handlers:
        return logger

    level_name = str(config.LOG_LEVEL).upper()
    level = getattr(logging, level_name, logging.INFO)
    logger.setLevel(level)

    handler = logging.StreamHandler(sys.stdout)
    if UvicornDefaultFormatter is not None:
        try:
            handler.setFormatter(UvicornDefaultFormatter("%(levelprefix)s %(message)s"))
        except Exception:
            handler.setFormatter(logging.Formatter("%(levelname)s %(message)s"))
    else:
        handler.setFormatter(logging.Formatter("%(levelname)s %(message)s"))

    logger.addHandler(handler)
    logger.propagate = False
    return logger
