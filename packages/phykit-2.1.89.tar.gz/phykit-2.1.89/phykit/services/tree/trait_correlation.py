"""
Phylogenetic trait correlation: compute phylogenetic correlations between
all pairs of traits and display them as a heatmap with significance
indicators.
"""
from typing import Dict, List

import numpy as np
from scipy.stats import t as t_dist

from .base import Tree
from ...helpers.json_output import print_json
from ...helpers.plot_config import PlotConfig
from ...helpers.trait_parsing import parse_multi_trait_file
from ...errors import PhykitUserError


class TraitCorrelation(Tree):
    def __init__(self, args) -> None:
        parsed = self.process_args(args)
        super().__init__(tree_file_path=parsed["tree_file_path"])
        self.trait_data_path = parsed["trait_data_path"]
        self.output_path = parsed["output_path"]
        self.alpha = parsed["alpha"]
        self.cluster = parsed["cluster"]
        self.gene_trees_path = parsed["gene_trees_path"]
        self.json_output = parsed["json_output"]
        self.plot_config = parsed["plot_config"]

    def run(self) -> None:
        from .vcv_utils import build_vcv_matrix, build_discordance_vcv, parse_gene_trees

        tree = self.read_tree_file()
        self.validate_tree(tree, min_tips=3, require_branch_lengths=True, context="trait correlation analysis")

        tree_tips = self.get_tip_names_from_tree(tree)
        trait_names, traits = parse_multi_trait_file(
            self.trait_data_path, tree_tips, min_columns=3
        )

        ordered_names = sorted(traits.keys())

        if self.gene_trees_path:
            gene_trees = parse_gene_trees(self.gene_trees_path)
            vcv, vcv_meta = build_discordance_vcv(tree, gene_trees, ordered_names)
            shared = vcv_meta["shared_taxa"]
            if set(shared) != set(ordered_names):
                traits = {k: traits[k] for k in shared}
                ordered_names = shared
            vcv_type = "discordance"
        else:
            vcv = build_vcv_matrix(tree, ordered_names)
            vcv_meta = None
            vcv_type = "BM"

        n = len(ordered_names)
        p = len(trait_names)

        Y = np.array([[traits[name][j] for j in range(p)] for name in ordered_names])

        # GLS-centered data
        C_inv = np.linalg.inv(vcv)
        ones = np.ones(n)
        denom = ones @ C_inv @ ones
        a_hat = np.array([(ones @ C_inv @ Y[:, j]) / denom for j in range(p)])
        Y_centered = Y - a_hat  # broadcast subtraction

        # Phylogenetic covariance matrix
        phylo_cov = (Y_centered.T @ C_inv @ Y_centered) / (n - 1)

        # Convert to correlation matrix
        std_devs = np.sqrt(np.diag(phylo_cov))
        corr_matrix = phylo_cov / np.outer(std_devs, std_devs)
        np.fill_diagonal(corr_matrix, 1.0)

        # Compute p-values
        p_matrix = np.ones((p, p))
        for i in range(p):
            for j in range(i + 1, p):
                r = corr_matrix[i, j]
                if abs(r) >= 1.0 - 1e-10:
                    pval = 0.0
                else:
                    t_stat = r * np.sqrt((n - 2) / (1 - r ** 2))
                    pval = 2.0 * t_dist.sf(abs(t_stat), df=n - 2)
                p_matrix[i, j] = pval
                p_matrix[j, i] = pval

        # Plot heatmap
        self._plot_heatmap(
            corr_matrix, p_matrix, trait_names, self.output_path
        )

        # Output
        if self.json_output:
            self._print_json(
                n, p, trait_names, vcv_type, corr_matrix, p_matrix
            )
        else:
            self._print_text(
                n, p, trait_names, vcv_type, corr_matrix, p_matrix,
                self.trait_data_path,
            )

    def process_args(self, args) -> Dict:
        return dict(
            tree_file_path=args.tree,
            trait_data_path=args.trait_data,
            output_path=args.output,
            alpha=getattr(args, "alpha", 0.05),
            cluster=getattr(args, "cluster", False),
            gene_trees_path=getattr(args, "gene_trees", None),
            json_output=getattr(args, "json", False),
            plot_config=PlotConfig.from_args(args),
        )

    def _significance_stars(self, pval: float) -> str:
        if pval < 0.001:
            return "***"
        elif pval < 0.01:
            return "**"
        elif pval < self.alpha:
            return "*"
        return ""

    def _plot_heatmap(
        self,
        corr_matrix: np.ndarray,
        p_matrix: np.ndarray,
        trait_names: List[str],
        output_path: str,
    ) -> None:
        try:
            import matplotlib
            matplotlib.use("Agg")
            import matplotlib.pyplot as plt
        except ImportError:
            print("matplotlib is required. Install matplotlib and retry.")
            raise SystemExit(2)

        config = self.plot_config
        p = len(trait_names)
        config.resolve(n_rows=p, n_cols=p)

        if self.cluster and p >= 2:
            self._plot_clustered_heatmap(
                corr_matrix, p_matrix, trait_names, output_path, config, plt
            )
        else:
            self._plot_simple_heatmap(
                corr_matrix, p_matrix, trait_names, output_path, config, plt
            )

    def _plot_simple_heatmap(
        self, corr_matrix, p_matrix, trait_names, output_path, config, plt
    ) -> None:
        p = len(trait_names)
        fig, ax = plt.subplots(figsize=(config.fig_width, config.fig_height))

        im = ax.imshow(
            corr_matrix, cmap="RdBu_r", vmin=-1, vmax=1,
            aspect="auto", interpolation="nearest",
        )

        # Add significance stars
        for i in range(p):
            for j in range(p):
                if i != j:
                    stars = self._significance_stars(p_matrix[i, j])
                    if stars:
                        ax.text(
                            j, i, stars,
                            ha="center", va="center",
                            fontsize=8, color="black",
                        )

        ax.set_xticks(np.arange(p))
        ax.set_yticks(np.arange(p))
        xlabel_fs = config.xlabel_fontsize if config.xlabel_fontsize and config.xlabel_fontsize > 0 else 9
        ylabel_fs = config.ylabel_fontsize if config.ylabel_fontsize and config.ylabel_fontsize > 0 else 9
        ax.set_xticklabels(trait_names, rotation=45, ha="right", fontsize=xlabel_fs)
        ax.set_yticklabels(trait_names, fontsize=ylabel_fs)

        cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        cbar.set_label("Phylogenetic correlation (r)")

        if config.show_title:
            ax.set_title(
                config.title or "Phylogenetic Trait Correlation",
                fontsize=config.title_fontsize,
            )

        fig.savefig(output_path, dpi=config.dpi, bbox_inches="tight")
        plt.close(fig)

    def _plot_clustered_heatmap(
        self, corr_matrix, p_matrix, trait_names, output_path, config, plt
    ) -> None:
        from scipy.cluster.hierarchy import linkage, dendrogram, leaves_list
        from scipy.spatial.distance import squareform

        p = len(trait_names)

        # Distance: 1 - |r|, ensure symmetric for squareform
        dist_matrix = 1.0 - np.abs(corr_matrix)
        dist_matrix = (dist_matrix + dist_matrix.T) / 2.0
        np.fill_diagonal(dist_matrix, 0.0)
        condensed = squareform(dist_matrix, checks=False)
        Z = linkage(condensed, method="average")
        leaf_order = list(leaves_list(Z))

        # Reorder matrices
        corr_ordered = corr_matrix[np.ix_(leaf_order, leaf_order)]
        p_ordered = p_matrix[np.ix_(leaf_order, leaf_order)]
        names_ordered = [trait_names[i] for i in leaf_order]

        fig = plt.figure(figsize=(config.fig_width, config.fig_height))

        # Layout: dendrogram on top + left, heatmap center, colorbar right
        # Using add_axes for precise control
        # Leave more space on the left for the dendrogram + label gap
        dendro_top_ax = fig.add_axes([0.22, 0.82, 0.58, 0.12])
        dendro_left_ax = fig.add_axes([0.02, 0.10, 0.10, 0.70])
        heat_ax = fig.add_axes([0.22, 0.10, 0.58, 0.70])
        cbar_ax = fig.add_axes([0.83, 0.10, 0.03, 0.70])

        # Draw top dendrogram (black)
        dendrogram(Z, ax=dendro_top_ax, no_labels=True,
                   color_threshold=0, above_threshold_color="#333333")
        dendro_top_ax.axis("off")

        # Draw left dendrogram (black, rotated)
        dendrogram(Z, ax=dendro_left_ax, no_labels=True,
                   color_threshold=0, above_threshold_color="#333333",
                   orientation="left")
        dendro_left_ax.axis("off")

        # Draw heatmap
        im = heat_ax.imshow(
            corr_ordered, cmap="RdBu_r", vmin=-1, vmax=1,
            aspect="auto", interpolation="nearest",
        )

        # Significance stars
        for i in range(p):
            for j in range(p):
                if i != j:
                    stars = self._significance_stars(p_ordered[i, j])
                    if stars:
                        heat_ax.text(
                            j, i, stars,
                            ha="center", va="center",
                            fontsize=8, color="black",
                        )

        heat_ax.set_xticks(np.arange(p))
        heat_ax.set_yticks(np.arange(p))
        xlabel_fs = config.xlabel_fontsize if config.xlabel_fontsize and config.xlabel_fontsize > 0 else 9
        ylabel_fs = config.ylabel_fontsize if config.ylabel_fontsize and config.ylabel_fontsize > 0 else 9
        heat_ax.set_xticklabels(names_ordered, rotation=45, ha="right", fontsize=xlabel_fs)
        heat_ax.set_yticklabels(names_ordered, fontsize=ylabel_fs)

        cbar = fig.colorbar(im, cax=cbar_ax)
        cbar.set_label("Phylogenetic correlation (r)")

        if config.show_title:
            fig.suptitle(
                config.title or "Phylogenetic Trait Correlation",
                fontsize=config.title_fontsize,
                y=0.97,
            )

        fig.savefig(output_path, dpi=config.dpi, bbox_inches="tight")
        plt.close(fig)

    def _print_text(
        self, n, p, trait_names, vcv_type, corr_matrix, p_matrix,
        tree_path,
    ) -> None:
        print("Phylogenetic Trait Correlation")
        print(f"Tree: {tree_path}")
        print(f"Taxa: {n}")
        print(f"Traits: {p}")
        print(f"VCV: {vcv_type} ({'standard' if vcv_type == 'BM' else 'discordance-aware'})")
        print(f"Alpha: {self.alpha}")

        # Determine column width
        max_name_len = max(len(name) for name in trait_names)
        col_width = max(max_name_len, 12)

        # Header
        header = " " * (max_name_len + 2)
        for name in trait_names:
            header += name.rjust(col_width) + "  "
        print(f"\n{header}")

        # Rows
        for i, name in enumerate(trait_names):
            row = name.ljust(max_name_len + 2)
            for j in range(p):
                if i == j:
                    cell = "1.0000"
                else:
                    stars = self._significance_stars(p_matrix[i, j])
                    cell = f"{corr_matrix[i, j]:.4f}{stars}"
                row += cell.rjust(col_width) + "  "
            print(row)

        # Count significant pairs
        n_sig = 0
        n_total = 0
        for i in range(p):
            for j in range(i + 1, p):
                n_total += 1
                if p_matrix[i, j] < self.alpha:
                    n_sig += 1
        print(f"\nSignificant pairs (p < {self.alpha}): {n_sig} of {n_total}")
        print(f"Output: {self.output_path}")

    def _print_json(
        self, n, p, trait_names, vcv_type, corr_matrix, p_matrix
    ) -> None:
        sig_pairs = []
        for i in range(p):
            for j in range(i + 1, p):
                if p_matrix[i, j] < self.alpha:
                    sig_pairs.append({
                        "trait_i": trait_names[i],
                        "trait_j": trait_names[j],
                        "r": round(float(corr_matrix[i, j]), 6),
                        "p": round(float(p_matrix[i, j]), 6),
                    })

        payload = {
            "n_taxa": n,
            "n_traits": p,
            "trait_names": trait_names,
            "vcv_type": vcv_type,
            "alpha": self.alpha,
            "correlation_matrix": [
                [round(float(corr_matrix[i, j]), 6) for j in range(p)]
                for i in range(p)
            ],
            "p_value_matrix": [
                [round(float(p_matrix[i, j]), 6) for j in range(p)]
                for i in range(p)
            ],
            "significant_pairs": sig_pairs,
            "output_file": self.output_path,
        }
        print_json(payload)
