import sys
from typing import Dict, List, Tuple

import numpy as np
from scipy.stats import t as t_dist
from scipy.stats import f as f_dist

from .base import Tree
from ...helpers.json_output import print_json
from ...helpers.trait_parsing import parse_multi_trait_file
from ...helpers.pgls_utils import (
    max_lambda as compute_max_lambda,
    estimate_lambda,
    pgls_log_likelihood,
    fit_gls,
    apply_lambda,
)
from ...errors import PhykitUserError


class PhylogeneticRegression(Tree):
    def __init__(self, args) -> None:
        parsed = self.process_args(args)
        super().__init__(tree_file_path=parsed["tree_file_path"])
        self.trait_data_path = parsed["trait_data_path"]
        self.response = parsed["response"]
        self.predictors = parsed["predictors"]
        self.method = parsed["method"]
        self.json_output = parsed["json_output"]
        self.gene_trees_path = parsed["gene_trees_path"]

    def run(self) -> None:
        from .vcv_utils import build_vcv_matrix, build_discordance_vcv, parse_gene_trees

        tree = self.read_tree_file()
        self.validate_tree(tree, min_tips=3, require_branch_lengths=True, context="phylogenetic regression")

        tree_tips = self.get_tip_names_from_tree(tree)
        trait_names, traits = parse_multi_trait_file(
            self.trait_data_path, tree_tips
        )

        # Validate column names
        all_columns = [self.response] + list(self.predictors)
        for col in all_columns:
            if col not in trait_names:
                raise PhykitUserError(
                    [
                        f"Column '{col}' not found in trait file.",
                        f"Available columns: {', '.join(trait_names)}",
                    ],
                    code=2,
                )

        if self.response in self.predictors:
            raise PhykitUserError(
                [
                    f"Response variable '{self.response}' must not also be a predictor.",
                ],
                code=2,
            )

        ordered_names = sorted(traits.keys())

        if self.gene_trees_path:
            gene_trees = parse_gene_trees(self.gene_trees_path)
            vcv, vcv_meta = build_discordance_vcv(tree, gene_trees, ordered_names)
            shared = vcv_meta["shared_taxa"]
            if set(shared) != set(ordered_names):
                traits = {k: traits[k] for k in shared}
                ordered_names = shared
        else:
            vcv = build_vcv_matrix(tree, ordered_names)
            vcv_meta = None

        n = len(ordered_names)
        k = len(self.predictors)

        if n <= k + 1:
            raise PhykitUserError(
                [
                    f"Insufficient observations: n={n} but need at least {k + 2} "
                    f"(more than k+1={k + 1} parameters).",
                ],
                code=2,
            )

        # Build response vector y and design matrix X (with intercept)
        resp_idx = trait_names.index(self.response)
        pred_indices = [trait_names.index(p) for p in self.predictors]

        y = np.array([traits[name][resp_idx] for name in ordered_names])
        X_pred = np.array(
            [[traits[name][j] for j in pred_indices] for name in ordered_names]
        )
        # Design matrix: intercept + predictors
        X = np.column_stack([np.ones(n), X_pred])

        lambda_val = None
        log_likelihood_lambda = None

        if self.method == "lambda":
            max_lam = compute_max_lambda(tree)
            lambda_val, log_likelihood_lambda = estimate_lambda(
                y, X, vcv, max_lam
            )
            vcv = apply_lambda(vcv, lambda_val)

        try:
            C_inv = np.linalg.inv(vcv)
        except np.linalg.LinAlgError:
            raise PhykitUserError(
                [
                    "Singular VCV matrix: cannot invert.",
                    "Check that the tree has valid branch lengths.",
                ],
                code=2,
            )

        # GLS estimation
        beta_hat, residuals, sigma2, var_beta = fit_gls(y, X, C_inv)

        # Standard errors, t-stats, p-values
        se = np.sqrt(np.diag(var_beta))
        df_resid = n - k - 1
        t_stats = beta_hat / se
        p_values = 2.0 * t_dist.sf(np.abs(t_stats), df=df_resid)

        # Fitted values
        fitted = X @ beta_hat

        # Model statistics
        r_squared, adj_r_squared, f_stat, f_p_value, r2_total, r2_phylo = self._compute_model_stats(
            y, fitted, residuals, C_inv, k, n
        )

        # Log-likelihood and AIC
        sign, logdet_C = np.linalg.slogdet(vcv)
        sigma2_ml = float(residuals @ C_inv @ residuals) / n
        ll = -0.5 * (
            n * np.log(2 * np.pi) + n * np.log(sigma2_ml) + logdet_C + n
        )
        aic = -2.0 * ll + 2.0 * (k + 2)  # k predictors + intercept + sigma2

        # Build result
        coef_names = ["(Intercept)"] + list(self.predictors)
        formula = f"{self.response} ~ {' + '.join(self.predictors)}"

        result = self._format_result(
            coef_names=coef_names,
            beta_hat=beta_hat,
            se=se,
            t_stats=t_stats,
            p_values=p_values,
            sigma2=sigma2,
            df_resid=df_resid,
            r_squared=r_squared,
            adj_r_squared=adj_r_squared,
            f_stat=f_stat,
            f_p_value=f_p_value,
            ll=ll,
            aic=aic,
            formula=formula,
            k=k,
            n=n,
            residuals=residuals,
            fitted=fitted,
            ordered_names=ordered_names,
            lambda_val=lambda_val,
            r2_total=r2_total,
            r2_phylo=r2_phylo,
        )

        if vcv_meta is not None:
            result["vcv_metadata"] = vcv_meta

        if self.json_output:
            print_json(result)
        else:
            self._print_text_output(
                coef_names=coef_names,
                beta_hat=beta_hat,
                se=se,
                t_stats=t_stats,
                p_values=p_values,
                sigma2=sigma2,
                df_resid=df_resid,
                r_squared=r_squared,
                adj_r_squared=adj_r_squared,
                f_stat=f_stat,
                f_p_value=f_p_value,
                ll=ll,
                aic=aic,
                formula=formula,
                k=k,
                n=n,
                lambda_val=lambda_val,
                r2_total=r2_total,
                r2_phylo=r2_phylo,
            )

    def process_args(self, args) -> Dict[str, str]:
        return dict(
            tree_file_path=args.tree,
            trait_data_path=args.trait_data,
            response=args.response,
            predictors=args.predictors,
            method=getattr(args, "method", "BM"),
            json_output=getattr(args, "json", False),
            gene_trees_path=getattr(args, "gene_trees", None),
        )

    def _build_vcv_matrix(
        self, tree, ordered_names: List[str]
    ) -> np.ndarray:
        from .vcv_utils import build_vcv_matrix
        return build_vcv_matrix(tree, ordered_names)

    def _compute_model_stats(
        self,
        y: np.ndarray,
        fitted: np.ndarray,
        residuals: np.ndarray,
        C_inv: np.ndarray,
        k: int,
        n: int,
    ) -> Tuple[float, float, float, float, float, float]:
        """Compute R², adjusted R², F-statistic, F p-value, R²_total, R²_phylo.

        Uses GLS-weighted sums of squares:
          SS_res = e' C_inv e
          SS_tot = (y - y_bar_gls)' C_inv (y - y_bar_gls)
        where y_bar_gls = (1' C_inv y) / (1' C_inv 1)

        Three-way R² variance decomposition:
          R²_pred  = standard GLS R² (predictor contribution given phylogeny)
          R²_total = 1 - σ²_gls_ml / σ²_ols_ml (phylogeny + predictor)
          R²_phylo = R²_total - R²_pred (phylogeny's unique contribution)
        """
        ones = np.ones(n)
        y_bar_gls = float(ones @ C_inv @ y) / float(ones @ C_inv @ ones)
        y_centered = y - y_bar_gls

        ss_tot = float(y_centered @ C_inv @ y_centered)
        ss_res = float(residuals @ C_inv @ residuals)

        if ss_tot == 0:
            r_squared = 0.0
        else:
            r_squared = 1.0 - ss_res / ss_tot

        df_resid = n - k - 1
        if n - 1 == 0:
            adj_r_squared = r_squared
        else:
            adj_r_squared = 1.0 - (1.0 - r_squared) * (n - 1) / df_resid

        # F-statistic: (SS_tot - SS_res)/k / (SS_res / df_resid)
        ss_reg = ss_tot - ss_res
        if k == 0 or ss_res == 0:
            f_stat = 0.0
            f_p_value = 1.0
        else:
            ms_reg = ss_reg / k
            ms_res = ss_res / df_resid
            f_stat = ms_reg / ms_res
            f_p_value = float(f_dist.sf(f_stat, dfn=k, dfd=df_resid))

        # Three-way R² variance decomposition
        sig2_gls_ml = float(residuals @ C_inv @ residuals) / n
        sig2_ols_ml = float(np.var(y))
        if sig2_ols_ml == 0:
            r2_total = 0.0
            r2_phylo = 0.0
        else:
            r2_total = 1.0 - sig2_gls_ml / sig2_ols_ml
            r2_phylo = r2_total - r_squared

        return r_squared, adj_r_squared, f_stat, f_p_value, r2_total, r2_phylo

    def _signif_code(self, p: float) -> str:
        if p < 0.001:
            return "***"
        elif p < 0.01:
            return "**"
        elif p < 0.05:
            return "*"
        elif p < 0.1:
            return "."
        else:
            return " "

    def _print_text_output(
        self, *, coef_names, beta_hat, se, t_stats, p_values,
        sigma2, df_resid, r_squared, adj_r_squared,
        f_stat, f_p_value, ll, aic, formula, k, n, lambda_val,
        r2_total, r2_phylo,
    ) -> None:
        print("Phylogenetic Generalized Least Squares (PGLS)")
        print(f"\nFormula: {formula}")

        if lambda_val is not None:
            print(f"\nEstimated lambda: {lambda_val:.4f}")

        print("\nCoefficients:")
        # Header
        print(
            f"{'':20s}{'Estimate':>12s}{'Std.Error':>12s}"
            f"{'t-value':>12s}{'p-value':>12s}"
        )

        for i, name in enumerate(coef_names):
            sig = self._signif_code(p_values[i])
            print(
                f"{name:20s}{beta_hat[i]:12.4f}{se[i]:12.4f}"
                f"{t_stats[i]:12.4f}{p_values[i]:12.6f}    {sig}"
            )

        print("---")
        print("Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1")

        rse = np.sqrt(sigma2)
        print(
            f"\nResidual standard error: {rse:.4f} on {df_resid} degrees of freedom"
        )
        print(
            f"Multiple R-squared: {r_squared:.4f}    "
            f"Adjusted R-squared: {adj_r_squared:.4f}"
        )
        print(f"R-squared (total):   {r2_total:.4f}   (phylo + predictor)")
        print(f"R-squared (phylo):   {r2_phylo:.4f}   (phylogeny contribution)")
        print(
            f"F-statistic: {f_stat:.2f} on {k} and {df_resid} DF    "
            f"p-value: {f_p_value:.6f}"
        )
        print(f"Log-likelihood: {ll:.4f}    AIC: {aic:.4f}")

    def _format_result(
        self, *, coef_names, beta_hat, se, t_stats, p_values,
        sigma2, df_resid, r_squared, adj_r_squared,
        f_stat, f_p_value, ll, aic, formula, k, n,
        residuals, fitted, ordered_names, lambda_val,
        r2_total, r2_phylo,
    ) -> Dict:
        coefficients = {}
        for i, name in enumerate(coef_names):
            coefficients[name] = {
                "estimate": float(beta_hat[i]),
                "std_error": float(se[i]),
                "t_value": float(t_stats[i]),
                "p_value": float(p_values[i]),
            }

        result = {
            "formula": formula,
            "coefficients": coefficients,
            "residual_standard_error": float(np.sqrt(sigma2)),
            "df_residual": df_resid,
            "r_squared": float(r_squared),
            "adj_r_squared": float(adj_r_squared),
            "r_squared_total": float(r2_total),
            "r_squared_phylo": float(r2_phylo),
            "f_statistic": float(f_stat),
            "f_p_value": float(f_p_value),
            "log_likelihood": float(ll),
            "aic": float(aic),
            "n_observations": n,
            "n_predictors": k,
            "residuals": {
                ordered_names[i]: float(residuals[i])
                for i in range(len(ordered_names))
            },
            "fitted_values": {
                ordered_names[i]: float(fitted[i])
                for i in range(len(ordered_names))
            },
        }

        if lambda_val is not None:
            result["lambda"] = float(lambda_val)

        return result
