from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...types import Response


def _get_kwargs() -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/health/deep",
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | None:
    if response.status_code == 200:
        return None

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
) -> Response[Any]:
    r"""Deep Health Check

     Deep readiness check that exercises the SQLAlchemy pool (ORO-1121).

    Acquires a session and runs SELECT 1 with a hard timeout, retrying
    once on failure to ride out transient pool stalls or one-shot
    network blips (ORO-1168). If the pool is wedged (phantom-checked-out
    slots) or RDS is unreachable across both attempts, the check fails
    and the ALB pulls the task out of rotation after its own
    unhealthy_threshold_count consecutive failures.

    On final failure we return 503 directly via `JSONResponse` instead
    of raising `HTTPException`. The status to the ALB is identical, but
    the Sentry FastAPI integration only captures *exceptions* — so this
    path no longer triggers the \"new unhandled error\" PD rule on a
    transient blip. Sustained DB-unreachable is correctly surfaced by
    the ALB target-health alarm, not the Sentry new-issue rule.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
    """

    kwargs = _get_kwargs()

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
) -> Response[Any]:
    r"""Deep Health Check

     Deep readiness check that exercises the SQLAlchemy pool (ORO-1121).

    Acquires a session and runs SELECT 1 with a hard timeout, retrying
    once on failure to ride out transient pool stalls or one-shot
    network blips (ORO-1168). If the pool is wedged (phantom-checked-out
    slots) or RDS is unreachable across both attempts, the check fails
    and the ALB pulls the task out of rotation after its own
    unhealthy_threshold_count consecutive failures.

    On final failure we return 503 directly via `JSONResponse` instead
    of raising `HTTPException`. The status to the ALB is identical, but
    the Sentry FastAPI integration only captures *exceptions* — so this
    path no longer triggers the \"new unhandled error\" PD rule on a
    transient blip. Sustained DB-unreachable is correctly surfaced by
    the ALB target-health alarm, not the Sentry new-issue rule.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
    """

    kwargs = _get_kwargs()

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)
