from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.validator_failures_response import ValidatorFailuresResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    validator_hotkey: str,
    *,
    limit: int | Unset = 25,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["limit"] = limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/admin/analytics/validator-failures/{validator_hotkey}".format(
            validator_hotkey=quote(str(validator_hotkey), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | ValidatorFailuresResponse | None:
    if response.status_code == 200:
        response_200 = ValidatorFailuresResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | ValidatorFailuresResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    validator_hotkey: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 25,
) -> Response[HTTPValidationError | ValidatorFailuresResponse]:
    """Recent failed/timed-out runs for a single validator

     Returns the most recent FAILED and TIMED_OUT evaluation runs for the given validator, ordered by
    completed_at DESC. Powers the expandable failure-history view on the admin analytics dashboard
    (ORO-676).

    Args:
        validator_hotkey (str): Validator SS58 hotkey
        limit (int | Unset): Maximum number of failures to return Default: 25.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | ValidatorFailuresResponse]
    """

    kwargs = _get_kwargs(
        validator_hotkey=validator_hotkey,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    validator_hotkey: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 25,
) -> HTTPValidationError | ValidatorFailuresResponse | None:
    """Recent failed/timed-out runs for a single validator

     Returns the most recent FAILED and TIMED_OUT evaluation runs for the given validator, ordered by
    completed_at DESC. Powers the expandable failure-history view on the admin analytics dashboard
    (ORO-676).

    Args:
        validator_hotkey (str): Validator SS58 hotkey
        limit (int | Unset): Maximum number of failures to return Default: 25.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | ValidatorFailuresResponse
    """

    return sync_detailed(
        validator_hotkey=validator_hotkey,
        client=client,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    validator_hotkey: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 25,
) -> Response[HTTPValidationError | ValidatorFailuresResponse]:
    """Recent failed/timed-out runs for a single validator

     Returns the most recent FAILED and TIMED_OUT evaluation runs for the given validator, ordered by
    completed_at DESC. Powers the expandable failure-history view on the admin analytics dashboard
    (ORO-676).

    Args:
        validator_hotkey (str): Validator SS58 hotkey
        limit (int | Unset): Maximum number of failures to return Default: 25.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | ValidatorFailuresResponse]
    """

    kwargs = _get_kwargs(
        validator_hotkey=validator_hotkey,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    validator_hotkey: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 25,
) -> HTTPValidationError | ValidatorFailuresResponse | None:
    """Recent failed/timed-out runs for a single validator

     Returns the most recent FAILED and TIMED_OUT evaluation runs for the given validator, ordered by
    completed_at DESC. Powers the expandable failure-history view on the admin analytics dashboard
    (ORO-676).

    Args:
        validator_hotkey (str): Validator SS58 hotkey
        limit (int | Unset): Maximum number of failures to return Default: 25.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | ValidatorFailuresResponse
    """

    return (
        await asyncio_detailed(
            validator_hotkey=validator_hotkey,
            client=client,
            limit=limit,
        )
    ).parsed
