from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="ValidatorFailureEntry")


@_attrs_define
class ValidatorFailureEntry:
    """A single FAILED/TIMED_OUT evaluation run from a validator.

    Attributes:
        eval_run_id (UUID): Evaluation run identifier
        agent_version_id (UUID): Agent version that was being evaluated
        status (str): Terminal status — FAILED or TIMED_OUT
        failure_reason (None | str | Unset): Reason the run failed (free-form string)
        completed_at (datetime.datetime | None | Unset): When the run completed (UTC)
    """

    eval_run_id: UUID
    agent_version_id: UUID
    status: str
    failure_reason: None | str | Unset = UNSET
    completed_at: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        eval_run_id = str(self.eval_run_id)

        agent_version_id = str(self.agent_version_id)

        status = self.status

        failure_reason: None | str | Unset
        if isinstance(self.failure_reason, Unset):
            failure_reason = UNSET
        else:
            failure_reason = self.failure_reason

        completed_at: None | str | Unset
        if isinstance(self.completed_at, Unset):
            completed_at = UNSET
        elif isinstance(self.completed_at, datetime.datetime):
            completed_at = self.completed_at.isoformat()
        else:
            completed_at = self.completed_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "eval_run_id": eval_run_id,
                "agent_version_id": agent_version_id,
                "status": status,
            }
        )
        if failure_reason is not UNSET:
            field_dict["failure_reason"] = failure_reason
        if completed_at is not UNSET:
            field_dict["completed_at"] = completed_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        eval_run_id = UUID(d.pop("eval_run_id"))

        agent_version_id = UUID(d.pop("agent_version_id"))

        status = d.pop("status")

        def _parse_failure_reason(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        failure_reason = _parse_failure_reason(d.pop("failure_reason", UNSET))

        def _parse_completed_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                completed_at_type_0 = isoparse(data)

                return completed_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        completed_at = _parse_completed_at(d.pop("completed_at", UNSET))

        validator_failure_entry = cls(
            eval_run_id=eval_run_id,
            agent_version_id=agent_version_id,
            status=status,
            failure_reason=failure_reason,
            completed_at=completed_at,
        )

        validator_failure_entry.additional_properties = d
        return validator_failure_entry

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
