from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.validator_failure_entry import ValidatorFailureEntry


T = TypeVar("T", bound="ValidatorFailuresResponse")


@_attrs_define
class ValidatorFailuresResponse:
    """Recent failures for a single validator, ordered by completed_at DESC.

    Attributes:
        validator_hotkey (str): Validator whose failures these are
        failures (list[ValidatorFailureEntry]): Recent failure entries
        total (int): Number of entries returned
    """

    validator_hotkey: str
    failures: list[ValidatorFailureEntry]
    total: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        validator_hotkey = self.validator_hotkey

        failures = []
        for failures_item_data in self.failures:
            failures_item = failures_item_data.to_dict()
            failures.append(failures_item)

        total = self.total

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "validator_hotkey": validator_hotkey,
                "failures": failures,
                "total": total,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.validator_failure_entry import ValidatorFailureEntry

        d = dict(src_dict)
        validator_hotkey = d.pop("validator_hotkey")

        failures = []
        _failures = d.pop("failures")
        for failures_item_data in _failures:
            failures_item = ValidatorFailureEntry.from_dict(failures_item_data)

            failures.append(failures_item)

        total = d.pop("total")

        validator_failures_response = cls(
            validator_hotkey=validator_hotkey,
            failures=failures,
            total=total,
        )

        validator_failures_response.additional_properties = d
        return validator_failures_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
