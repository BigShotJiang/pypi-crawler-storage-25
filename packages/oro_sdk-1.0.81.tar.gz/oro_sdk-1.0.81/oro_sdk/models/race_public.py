from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="RacePublic")


@_attrs_define
class RacePublic:
    """
    Attributes:
        race_id (UUID): Race ID
        suite_id (int): Problem suite ID
        status (str): Current race status
        race_number (int | None | Unset):
        qualifying_closes_at (datetime.datetime | None | Unset):
        race_started_at (datetime.datetime | None | Unset):
        race_completed_at (datetime.datetime | None | Unset):
        winner_agent_version_id (None | Unset | UUID):
        winner_score (float | None | Unset):
        qualifying_threshold (float | None | Unset): Score threshold for qualifying
        winner_agent_name (None | str | Unset): Name of the winning agent
        qualifier_count (int | Unset): Number of qualifiers in this race Default: 0.
        top50_mean (float | None | Unset): Arithmetic mean of race_score across the top half (by race_score desc) of
            qualifiers with non-null race_score. Null when the race has no scored qualifiers. Pre-computed so Frontend
            doesn't have to fan out per-race detail fetches for the Challenge History chart's tooltip distribution stats.
        top50_std (float | None | Unset): Population standard deviation of race_score across the same top-half slice as
            top50_mean. Null when the race has no scored qualifiers; 0.0 when the top half contains a single row.
        created_at (datetime.datetime | None | Unset): When the race was created
        projected_completion_at (datetime.datetime | None | Unset): Projected UTC timestamp when the race will complete.
            Set only on RACE_RUNNING races; null otherwise or when there is insufficient evaluation history or no active
            validators.
    """

    race_id: UUID
    suite_id: int
    status: str
    race_number: int | None | Unset = UNSET
    qualifying_closes_at: datetime.datetime | None | Unset = UNSET
    race_started_at: datetime.datetime | None | Unset = UNSET
    race_completed_at: datetime.datetime | None | Unset = UNSET
    winner_agent_version_id: None | Unset | UUID = UNSET
    winner_score: float | None | Unset = UNSET
    qualifying_threshold: float | None | Unset = UNSET
    winner_agent_name: None | str | Unset = UNSET
    qualifier_count: int | Unset = 0
    top50_mean: float | None | Unset = UNSET
    top50_std: float | None | Unset = UNSET
    created_at: datetime.datetime | None | Unset = UNSET
    projected_completion_at: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        race_id = str(self.race_id)

        suite_id = self.suite_id

        status = self.status

        race_number: int | None | Unset
        if isinstance(self.race_number, Unset):
            race_number = UNSET
        else:
            race_number = self.race_number

        qualifying_closes_at: None | str | Unset
        if isinstance(self.qualifying_closes_at, Unset):
            qualifying_closes_at = UNSET
        elif isinstance(self.qualifying_closes_at, datetime.datetime):
            qualifying_closes_at = self.qualifying_closes_at.isoformat()
        else:
            qualifying_closes_at = self.qualifying_closes_at

        race_started_at: None | str | Unset
        if isinstance(self.race_started_at, Unset):
            race_started_at = UNSET
        elif isinstance(self.race_started_at, datetime.datetime):
            race_started_at = self.race_started_at.isoformat()
        else:
            race_started_at = self.race_started_at

        race_completed_at: None | str | Unset
        if isinstance(self.race_completed_at, Unset):
            race_completed_at = UNSET
        elif isinstance(self.race_completed_at, datetime.datetime):
            race_completed_at = self.race_completed_at.isoformat()
        else:
            race_completed_at = self.race_completed_at

        winner_agent_version_id: None | str | Unset
        if isinstance(self.winner_agent_version_id, Unset):
            winner_agent_version_id = UNSET
        elif isinstance(self.winner_agent_version_id, UUID):
            winner_agent_version_id = str(self.winner_agent_version_id)
        else:
            winner_agent_version_id = self.winner_agent_version_id

        winner_score: float | None | Unset
        if isinstance(self.winner_score, Unset):
            winner_score = UNSET
        else:
            winner_score = self.winner_score

        qualifying_threshold: float | None | Unset
        if isinstance(self.qualifying_threshold, Unset):
            qualifying_threshold = UNSET
        else:
            qualifying_threshold = self.qualifying_threshold

        winner_agent_name: None | str | Unset
        if isinstance(self.winner_agent_name, Unset):
            winner_agent_name = UNSET
        else:
            winner_agent_name = self.winner_agent_name

        qualifier_count = self.qualifier_count

        top50_mean: float | None | Unset
        if isinstance(self.top50_mean, Unset):
            top50_mean = UNSET
        else:
            top50_mean = self.top50_mean

        top50_std: float | None | Unset
        if isinstance(self.top50_std, Unset):
            top50_std = UNSET
        else:
            top50_std = self.top50_std

        created_at: None | str | Unset
        if isinstance(self.created_at, Unset):
            created_at = UNSET
        elif isinstance(self.created_at, datetime.datetime):
            created_at = self.created_at.isoformat()
        else:
            created_at = self.created_at

        projected_completion_at: None | str | Unset
        if isinstance(self.projected_completion_at, Unset):
            projected_completion_at = UNSET
        elif isinstance(self.projected_completion_at, datetime.datetime):
            projected_completion_at = self.projected_completion_at.isoformat()
        else:
            projected_completion_at = self.projected_completion_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "race_id": race_id,
                "suite_id": suite_id,
                "status": status,
            }
        )
        if race_number is not UNSET:
            field_dict["race_number"] = race_number
        if qualifying_closes_at is not UNSET:
            field_dict["qualifying_closes_at"] = qualifying_closes_at
        if race_started_at is not UNSET:
            field_dict["race_started_at"] = race_started_at
        if race_completed_at is not UNSET:
            field_dict["race_completed_at"] = race_completed_at
        if winner_agent_version_id is not UNSET:
            field_dict["winner_agent_version_id"] = winner_agent_version_id
        if winner_score is not UNSET:
            field_dict["winner_score"] = winner_score
        if qualifying_threshold is not UNSET:
            field_dict["qualifying_threshold"] = qualifying_threshold
        if winner_agent_name is not UNSET:
            field_dict["winner_agent_name"] = winner_agent_name
        if qualifier_count is not UNSET:
            field_dict["qualifier_count"] = qualifier_count
        if top50_mean is not UNSET:
            field_dict["top50_mean"] = top50_mean
        if top50_std is not UNSET:
            field_dict["top50_std"] = top50_std
        if created_at is not UNSET:
            field_dict["created_at"] = created_at
        if projected_completion_at is not UNSET:
            field_dict["projected_completion_at"] = projected_completion_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        race_id = UUID(d.pop("race_id"))

        suite_id = d.pop("suite_id")

        status = d.pop("status")

        def _parse_race_number(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        race_number = _parse_race_number(d.pop("race_number", UNSET))

        def _parse_qualifying_closes_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                qualifying_closes_at_type_0 = isoparse(data)

                return qualifying_closes_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        qualifying_closes_at = _parse_qualifying_closes_at(d.pop("qualifying_closes_at", UNSET))

        def _parse_race_started_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                race_started_at_type_0 = isoparse(data)

                return race_started_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        race_started_at = _parse_race_started_at(d.pop("race_started_at", UNSET))

        def _parse_race_completed_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                race_completed_at_type_0 = isoparse(data)

                return race_completed_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        race_completed_at = _parse_race_completed_at(d.pop("race_completed_at", UNSET))

        def _parse_winner_agent_version_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                winner_agent_version_id_type_0 = UUID(data)

                return winner_agent_version_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        winner_agent_version_id = _parse_winner_agent_version_id(d.pop("winner_agent_version_id", UNSET))

        def _parse_winner_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        winner_score = _parse_winner_score(d.pop("winner_score", UNSET))

        def _parse_qualifying_threshold(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        qualifying_threshold = _parse_qualifying_threshold(d.pop("qualifying_threshold", UNSET))

        def _parse_winner_agent_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        winner_agent_name = _parse_winner_agent_name(d.pop("winner_agent_name", UNSET))

        qualifier_count = d.pop("qualifier_count", UNSET)

        def _parse_top50_mean(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        top50_mean = _parse_top50_mean(d.pop("top50_mean", UNSET))

        def _parse_top50_std(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        top50_std = _parse_top50_std(d.pop("top50_std", UNSET))

        def _parse_created_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                created_at_type_0 = isoparse(data)

                return created_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        created_at = _parse_created_at(d.pop("created_at", UNSET))

        def _parse_projected_completion_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                projected_completion_at_type_0 = isoparse(data)

                return projected_completion_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        projected_completion_at = _parse_projected_completion_at(d.pop("projected_completion_at", UNSET))

        race_public = cls(
            race_id=race_id,
            suite_id=suite_id,
            status=status,
            race_number=race_number,
            qualifying_closes_at=qualifying_closes_at,
            race_started_at=race_started_at,
            race_completed_at=race_completed_at,
            winner_agent_version_id=winner_agent_version_id,
            winner_score=winner_score,
            qualifying_threshold=qualifying_threshold,
            winner_agent_name=winner_agent_name,
            qualifier_count=qualifier_count,
            top50_mean=top50_mean,
            top50_std=top50_std,
            created_at=created_at,
            projected_completion_at=projected_completion_at,
        )

        race_public.additional_properties = d
        return race_public

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
