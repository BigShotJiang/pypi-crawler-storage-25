import os
import io
import sys
import pytest
import base64
from PIL import Image
import io
from unittest.mock import patch, mock_open
from pdd.preprocess import preprocess, get_file_path
import subprocess
import importlib
from unittest.mock import MagicMock
import z3
from z3 import String, StringVal, If, And, Or, Not, BoolVal, Implies, Length, PrefixOf, SubString, IndexOf
import re

# Store the original PDD_PATH to restore after tests
_original_pdd_path = os.environ.get('PDD_PATH')

# Helper function to mock environment variable
def set_pdd_path(path: str) -> None:
    """Set the PDD_PATH environment variable to the specified path."""
    os.environ['PDD_PATH'] = path

# Fixture to reset Firecrawl cache singleton for test isolation
@pytest.fixture
def reset_firecrawl_cache():
    """
    Reset the Firecrawl cache singleton before each test.

    This ensures that when tests set FIRECRAWL_CACHE_ENABLE=false,
    a fresh cache instance is created that respects the env var.
    Without this, the singleton created by an earlier test would persist.
    """
    import pdd.firecrawl_cache
    original_instance = pdd.firecrawl_cache._cache_instance
    pdd.firecrawl_cache._cache_instance = None
    yield
    # Restore after test
    pdd.firecrawl_cache._cache_instance = original_instance

# Test for processing includes in triple backticks
def test_process_backtick_includes() -> None:
    """Test processing of includes within triple backticks."""
    set_pdd_path('/mock/path')
    mock_file_content = "Included content"
    prompt = "This is a test ```<include_file.txt>```"
    expected_output = "This is a test ```Included content```"

    with patch('builtins.open', mock_open(read_data=mock_file_content)):
        assert preprocess(prompt, recursive=False, double_curly_brackets=False) == expected_output

# Test for processing XML-like include tags
def test_process_xml_include_tag() -> None:
    """Test processing of XML-like include tags."""
    set_pdd_path('/mock/path')
    mock_file_content = "Included content"
    prompt = "This is a test <include>include_file.txt</include>"
    expected_output = "This is a test Included content"

    with patch('builtins.open', mock_open(read_data=mock_file_content)):
        assert preprocess(prompt, recursive=False, double_curly_brackets=False) == expected_output

# New include-many coverage
def test_process_include_many_mixed_paths() -> None:
    """Include-many should concatenate all referenced files across commas and newlines."""
    prompt = "Start <include-many>file1.txt, file2.txt\nfile3.txt</include-many> End"
    file_map = {
        './file1.txt': 'Content One',
        './file2.txt': 'Content Two',
        './file3.txt': 'Content Three',
    }

    def mocked_open(path, *args, **kwargs):
        if path in file_map:
            return io.StringIO(file_map[path])
        raise FileNotFoundError(path)

    with patch('builtins.open', side_effect=mocked_open):
        result = preprocess(prompt, recursive=False, double_curly_brackets=False)

    expected = "Start Content One\nContent Two\nContent Three End"
    assert result == expected


def test_process_include_many_missing_file() -> None:
    """Include-many should surface placeholders for missing files while keeping other content."""
    prompt = "<include-many>present.txt, missing.txt</include-many>"
    file_map = {'./present.txt': 'Here'}

    def mocked_open(path, *args, **kwargs):
        if path in file_map:
            return io.StringIO(file_map[path])
        raise FileNotFoundError(path)

    with patch('builtins.open', side_effect=mocked_open):
        result = preprocess(prompt, recursive=False, double_curly_brackets=False)

    assert result == "Here\n[File not found: missing.txt]"


def test_process_include_many_recursive_defers() -> None:
    """Recursive pass should leave include-many blocks untouched for later expansion."""
    prompt = "Prefix <include-many>foo.txt</include-many> Suffix"
    result = preprocess(prompt, recursive=True, double_curly_brackets=False)
    assert result == prompt

# Test for processing XML-like pdd tags
def test_process_xml_pdd_tag() -> None:
    """Test processing of XML-like pdd tags."""
    prompt = "This is a test <pdd>This is a comment</pdd>"
    expected_output = "This is a test "

    assert preprocess(prompt, recursive=False, double_curly_brackets=False) == expected_output

# Test for processing XML-like shell tags
def test_process_xml_shell_tag() -> None:
    """Test processing of XML-like shell tags."""
    prompt = "This is a test <shell>echo Hello</shell>"
    expected_output = "This is a test Hello\n"

    with patch('subprocess.run') as mock_run:
        mock_run.return_value.stdout = "Hello\n"
        assert preprocess(prompt, recursive=False, double_curly_brackets=False) == expected_output


def test_recursive_shell_defers_execution() -> None:
    """Ensure recursive pass defers shell execution and keeps the tag in place."""
    prompt = "Check <shell>echo Ready</shell>"
    with patch('subprocess.run') as mock_run:
        result = preprocess(prompt, recursive=True, double_curly_brackets=False)
    assert result == prompt
    mock_run.assert_not_called()


def test_shell_second_pass_executes_after_deferral() -> None:
    """Second pass without recursion should execute the deferred shell block."""
    prompt = "Check <shell>echo Ready</shell>"
    with patch('subprocess.run') as mock_run:
        mock_run.return_value.stdout = "Ready\n"
        first_pass = preprocess(prompt, recursive=True, double_curly_brackets=False)
        assert first_pass == prompt
        processed = preprocess(first_pass, recursive=False, double_curly_brackets=False)
    assert processed == "Check Ready\n"
    mock_run.assert_called_once()


def test_shell_tag_ignored_in_fenced_code_block() -> None:
    """Shell tags inside fenced code blocks should not execute."""
    prompt = "Before\n```xml\n<shell>echo Hello</shell>\n```\nAfter"
    with patch('subprocess.run') as mock_run:
        mock_run.return_value.stdout = ""
        result = preprocess(prompt, recursive=False, double_curly_brackets=False)
    assert result == prompt
    mock_run.assert_not_called()


def test_shell_tag_ignored_in_inline_code() -> None:
    """Shell tags inside inline code spans should not execute."""
    prompt = "Use `<shell>echo Hello</shell>` as an example."
    with patch('subprocess.run') as mock_run:
        mock_run.return_value.stdout = ""
        result = preprocess(prompt, recursive=False, double_curly_brackets=False)
    assert result == prompt
    mock_run.assert_not_called()


def test_shell_tag_spanning_inline_code_is_ignored() -> None:
    """Shell tags whose match spans into inline code should not execute."""
    prompt = "Intro <shell>not a directive. Example: `<shell>noop</shell>` end."
    with patch('subprocess.run') as mock_run:
        mock_run.return_value.stdout = ""
        result = preprocess(prompt, recursive=False, double_curly_brackets=False)
    assert result == prompt
    mock_run.assert_not_called()


def test_include_tag_ignored_in_fenced_code_block() -> None:
    """Include tags inside fenced code blocks should not execute."""
    prompt = "```xml\n<include>file.txt</include>\n```"
    with patch('builtins.open', mock_open(read_data="Included")) as mocked_open:
        result = preprocess(prompt, recursive=False, double_curly_brackets=False)
    assert result == prompt
    mocked_open.assert_not_called()


def test_include_tag_ignored_in_inline_code() -> None:
    """Include tags inside inline code spans should not execute."""
    prompt = "Example `<include>file.txt</include>` in docs."
    with patch('builtins.open', mock_open(read_data="Included")) as mocked_open:
        result = preprocess(prompt, recursive=False, double_curly_brackets=False)
    assert result == prompt
    mocked_open.assert_not_called()


def test_include_many_tag_ignored_in_fenced_code_block() -> None:
    """Include-many tags inside fenced code blocks should not execute."""
    prompt = "```xml\n<include-many>one.txt, two.txt</include-many>\n```"
    with patch('builtins.open', mock_open(read_data="Content")) as mocked_open:
        result = preprocess(prompt, recursive=False, double_curly_brackets=False)
    assert result == prompt
    mocked_open.assert_not_called()


def test_shell_tag_spanning_fence_is_ignored(tmp_path, monkeypatch) -> None:
    """Shell tags that overlap fenced code should not execute."""
    guide = (
        "Intro <shell>not a directive.\n"
        "```mermaid\n"
        "P --> C\n"
        "P --> E\n"
        "P --> T\n"
        "</shell>\n"
        "```\n"
    )
    guide_path = tmp_path / "guide.md"
    guide_path.write_text(guide)
    monkeypatch.chdir(tmp_path)
    prompt = "<include>guide.md</include>"

    def fake_run(*_args, **_kwargs):
        for name in ("C", "E", "T"):
            (tmp_path / name).write_text("")
        completed = MagicMock()
        completed.stdout = ""
        completed.returncode = 0
        return completed

    with patch('subprocess.run', side_effect=fake_run) as mock_run:
        result = preprocess(prompt, recursive=False, double_curly_brackets=False)

    assert result == guide
    assert not (tmp_path / "C").exists()
    assert not (tmp_path / "E").exists()
    assert not (tmp_path / "T").exists()
    mock_run.assert_not_called()

# Test for doubling curly brackets
def test_double_curly_brackets() -> None:
    """Test doubling of curly brackets."""
    prompt = "This is a test {key}"
    expected_output = "This is a test {{key}}"

    assert preprocess(prompt, recursive=False, double_curly_brackets=True) == expected_output

def test_include_js_doubles_curly_braces() -> None:
    """Including a JS file with {x} should result in {{x}} after preprocess.

    This simulates the case where an included renderer.js/main.js introduces
    a single-brace placeholder that must be escaped before PromptTemplate.
    """
    prompt = "Before <include>./renderer.js</include> After"
    js_content = "function f(x) { return {x}; }\nconst obj = { a: 1, b: 2 };\n"
    expected_inner = "function f(x) {{ return {{x}}; }}\nconst obj = {{ a: 1, b: 2 }};\n"
    expected = f"Before {expected_inner} After"

    with patch('builtins.open', mock_open(read_data=js_content)):
        result = preprocess(prompt, recursive=False, double_curly_brackets=True)

    assert result == expected

# Test for excluding keys from doubling curly brackets
def test_exclude_keys_from_doubling() -> None:
    """Test excluding specific keys from doubling curly brackets."""
    prompt = "This is a test {key} and {exclude} {}"
    expected_output = "This is a test {{key}} and {exclude} {{}}"

    assert preprocess(prompt, recursive=False, double_curly_brackets=True, exclude_keys=['exclude']) == expected_output


def test_exclude_keys_requires_exact_match() -> None:
    """Exclude list should only skip doubling when the inner text is an exact match."""
    prompt = "Values {exclude_suffix} and {exclude}"
    expected = "Values {{exclude_suffix}} and {exclude}"
    result = preprocess(prompt, recursive=False, double_curly_brackets=True, exclude_keys=['exclude'])
    assert result == expected

# Test for recursive processing
def test_recursive_processing() -> None:
    """Test recursive processing of includes."""
    set_pdd_path('/mock/path')
    mock_file_content = "Nested include ```<nested_file.txt>```"
    nested_file_content = "Nested content"
    prompt = "This is a test ```<include_file.txt>```"
    expected_output = "This is a test ```Nested include ```Nested content``````"

    with patch('builtins.open', mock_open(read_data=mock_file_content)) as mock_file:
        mock_file.side_effect = [mock_open(read_data=mock_file_content).return_value,
                                 mock_open(read_data=nested_file_content).return_value]
        assert preprocess(prompt, recursive=True, double_curly_brackets=False) == expected_output


def test_recursive_backtick_missing_file_preserves_tag() -> None:
    """Recursive pass should keep unresolved backtick includes for later resolution."""
    prompt = "```<missing.txt>```"
    with patch('builtins.open', side_effect=FileNotFoundError):
        result = preprocess(prompt, recursive=True, double_curly_brackets=False)
    assert result == prompt


def test_recursive_xml_missing_file_preserves_tag() -> None:
    """Recursive pass should keep unresolved XML includes for later resolution."""
    prompt = "<include>missing.txt</include>"
    with patch('builtins.open', side_effect=FileNotFoundError):
        result = preprocess(prompt, recursive=True, double_curly_brackets=False)
    assert result == prompt

# Test for handling file not found
def test_file_not_found() -> None:
    """Test handling of file not found error."""
    set_pdd_path('/mock/path')
    prompt = "This is a test ```<missing_file.txt>```"
    expected_output = "This is a test ```[File not found: missing_file.txt]```"

    with patch('builtins.open', side_effect=FileNotFoundError):
        assert preprocess(prompt, recursive=False, double_curly_brackets=False) == expected_output


def test_optional_context_example_missing_is_silent() -> None:
    """Optional context/example.prompt should not leak a [File not found: ...] marker into prompts."""
    prompt = "<include optional>./context/example.prompt</include>"

    # Simulate missing file; include should resolve to empty string (but still warn on console).
    with patch('builtins.open', side_effect=FileNotFoundError):
        result = preprocess(prompt, recursive=False, double_curly_brackets=False)

    assert result == ""

# Test for handling shell command error
def test_shell_command_error() -> None:
    """Test handling of shell command error."""
    prompt = "This is a test <shell>invalid_command</shell>"
    expected_output = "This is a test Error: Command 'invalid_command' returned non-zero exit status 1."

    with patch('subprocess.run', side_effect=subprocess.CalledProcessError(1, 'invalid_command')):
        assert preprocess(prompt, recursive=False, double_curly_brackets=False) == expected_output


def test_recursive_web_defers_scrape() -> None:
    """Recursive pass should not attempt to import or scrape during web processing."""
    prompt = "Start <web>https://example.com</web> End"
    original_import = __import__

    def raising_import(name, *args, **kwargs):
        if name == 'firecrawl':
            raise AssertionError('firecrawl import should be deferred')
        return original_import(name, *args, **kwargs)

    with patch('builtins.__import__', side_effect=raising_import):
        result = preprocess(prompt, recursive=True, double_curly_brackets=False)

    assert result == prompt


def test_web_second_pass_executes_after_deferral(reset_firecrawl_cache) -> None:
    """Second pass without recursion should execute the deferred web scrape."""
    prompt = "Start <web>https://example.com</web> End"
    mock_firecrawl = MagicMock()
    mock_firecrawl.Firecrawl.return_value.scrape_url.return_value = {'markdown': "# Content"}

    with patch.dict('sys.modules', {'firecrawl': mock_firecrawl}):
        with patch.dict('os.environ', {'FIRECRAWL_API_KEY': 'key', 'FIRECRAWL_CACHE_ENABLE': 'false'}):
            result = preprocess(prompt, recursive=False, double_curly_brackets=False)

    assert result == "Start # Content End"

# Ensure to clean up the environment variable after tests
def teardown_module(module) -> None:
    """Restore the original PDD_PATH environment variable after tests."""
    if _original_pdd_path is not None:
        os.environ['PDD_PATH'] = _original_pdd_path
    elif 'PDD_PATH' in os.environ:
        del os.environ['PDD_PATH']

def test_double_curly_brackets_in_javascript() -> None:
    """
    Test to ensure that curly brackets in JavaScript code blocks are doubled correctly.
    """
    input_text = (
        """5. **Configure Tailwind CSS**:\n\n"
        "   Update your `tailwind.config.js` with the paths to all of your template files:\n\n"
        "   ```javascript\n"
        "   module.exports = {\n"
        "     content: [\n"
        "       \"./src/**/*.{js,jsx,ts,tsx}\",\n"
        "       \"./public/index.html\",\n"
        "       // Add any other paths where Tailwind CSS classes are used\n"
        "     ],\n"
        "     theme: {\n"
        "       extend: {},\n"
        "     },\n"
        "     plugins: [],\n"
        "   }\n"
        "   ```"""
    )

    expected_output = (
        """5. **Configure Tailwind CSS**:\n\n"
        "   Update your `tailwind.config.js` with the paths to all of your template files:\n\n"
        "   ```javascript\n"
        "   module.exports = {{\n"
        "     content: [\n"
        "       \"./src/**/*.{{js,jsx,ts,tsx}}\",\n"
        "       \"./public/index.html\",\n"
        "       // Add any other paths where Tailwind CSS classes are used\n"
        "     ],\n"
        "     theme: {{\n"
        "       extend: {{}},\n"
        "     }},\n"
        "     plugins: [],\n"
        "   }}\n"
        "   ```"""
    )

    # Call the preprocess function with the input text
    result = preprocess(input_text, recursive=False, double_curly_brackets=True)

    # Assert that the result matches the expected output
    assert result == expected_output, f"Expected:\n{expected_output}\n\nGot:\n{result}"

def test_double_curly_brackets_json() -> None:
    """
    Test to ensure that the preprocess function correctly doubles curly brackets
    within a JSON object without adding extra brackets around the entire object.
    """
    # Input prompt
    prompt = """### Error Handling

All endpoints return standard HTTP status codes. In case of an error, the response will include an error object:

```json
{
  "error": {
    "code": "string",
    "message": "string"
  }
}
```"""

    # Expected output
    expected_output = """### Error Handling

All endpoints return standard HTTP status codes. In case of an error, the response will include an error object:

```json
{{
  "error": {{
    "code": "string",
    "message": "string"
  }}
}}
```"""

    # Process the prompt
    processed = preprocess(prompt, recursive=False, double_curly_brackets=True)

    # Assert that the processed output matches the expected output
    assert processed.strip() == expected_output.strip(), \
        f"Expected:\n{expected_output}\n\nGot:\n{processed}"

    # Additional check to ensure no extra curly brackets are added around the entire JSON
    assert processed.count('{{') == expected_output.count('{{'), \
        "Extra curly brackets were added around the entire JSON object"


def test_double_curly_brackets_python_code_block() -> None:
    """Ensure Python code blocks are processed without disturbing existing double braces."""
    prompt = (
        """```python
def build_config():
    template = "{{ already }}"
    return {"key": value}
```"""
    )

    expected = (
        """```python
def build_config():
    template = "{{ already }}"
    return {{"key": value}}
```"""
    )

    processed = preprocess(prompt, recursive=False, double_curly_brackets=True)
    assert processed == expected

def test_double_curly_brackets_javascript_code_block_destructuring_jsx() -> None:
    """Ensure JS code blocks handle destructuring, object literals, and JSX."""
    prompt = (
        """```javascript
const { x, y } = obj;
const obj = { a: 1, b: 2 };
function C() { return <div>{x}</div>; }
```"""
    )

    expected = (
        """```javascript
const {{ x, y }} = obj;
const obj = {{ a: 1, b: 2 }};
function C() {{ return <div>{{x}}</div>; }}
```"""
    )

    processed = preprocess(prompt, recursive=False, double_curly_brackets=True)
    assert processed == expected

def test_double_curly_brackets_javascript_template_literals() -> None:
    """Ensure simple ${x} is preserved and complex ${x + 1} is doubled safely."""
    prompt = (
        """```javascript
const a = `Hello ${x}`;
const b = `Sum ${x + 1}`;
```"""
    )

    expected = (
        """```javascript
const a = `Hello ${{x}}`;
const b = `Sum ${{x + 1}}`;
```"""
    )

    processed = preprocess(prompt, recursive=False, double_curly_brackets=True)
    assert processed == expected

def test_unfenced_template_literal_should_be_doubled_but_is_not():
    """BUG REPRO: ${x} outside code fences is restored unchanged, leaving {x}.

    Expected behavior (to avoid PromptTemplate errors): `${x}` should become `${{x}}`
    when double_curly_brackets=True even outside fenced code blocks.

    Current behavior: preprocess protects and restores ${x} unchanged, so this test
    should FAIL until we harden double_curly to handle unfenced template literals.
    """
    prompt = "const a = `Hello ${x}`;"
    expected = "const a = `Hello ${{x}}`;"
    processed = preprocess(prompt, recursive=False, double_curly_brackets=True)
    assert processed == expected
def test_double_curly_preserves_braced_env_placeholders_as_escaped() -> None:
    """Ensure ${IDENT} placeholders are restored as ${{IDENT}} to avoid formatting issues."""
    prompt = "This has ${FOO} and {bar}"
    expected_output = "This has ${{FOO}} and {{bar}}"
    processed = preprocess(prompt, recursive=False, double_curly_brackets=True)
    assert processed == expected_output

def test_preprocess_double_curly_brackets():
    """
    Test that the preprocess function correctly doubles curly brackets
    in the provided prompt, matching the desired output.
    """
    # Input prompt with single curly brackets
    prompt = """    mock_db = {
            "1": {"id": "1", "name": "Resource One"},
            "2": {"id": "2", "name": "Resource Two"}
        }"""

    # Desired output with doubled curly brackets
    desired_output = """    mock_db = {{
            "1": {{"id": "1", "name": "Resource One"}},
            "2": {{"id": "2", "name": "Resource Two"}}
        }}"""

    # Call the preprocess function with appropriate parameters
    processed = preprocess(prompt, recursive=False, double_curly_brackets=True)

    # Assert that the processed output matches the desired output
    assert processed == desired_output, "The preprocess function did not double the curly brackets as expected."

# Test for processing XML-like web tags
def test_process_xml_web_tag(reset_firecrawl_cache) -> None:
    """Test processing of XML-like web tags."""
    mock_markdown_content = "# Webpage Content\n\nThis is the scraped content."
    prompt = "This is a test <web>https://example.com</web>"
    expected_output = f"This is a test {mock_markdown_content}"

    # Since Firecrawl is imported inside the function, we need to patch the module
    mock_firecrawl = MagicMock()
    mock_app = MagicMock()
    mock_app.scrape_url.return_value = {'markdown': mock_markdown_content}
    mock_firecrawl.Firecrawl.return_value = mock_app

    # Patch the import at the module level
    with patch.dict('sys.modules', {'firecrawl': mock_firecrawl}):
        # Mock the environment variable for API key and disable cache
        with patch.dict('os.environ', {'FIRECRAWL_API_KEY': 'fake_api_key', 'FIRECRAWL_CACHE_ENABLE': 'false'}):
            result = preprocess(prompt, recursive=False, double_curly_brackets=False)
            assert result == expected_output

def test_process_xml_web_tag_firecrawl_app_fallback(reset_firecrawl_cache) -> None:
    """The pinned firecrawl-py SDK exposes FirecrawlApp rather than Firecrawl."""
    mock_markdown_content = "# Webpage Content from FirecrawlApp"
    prompt = "This is a test <web>https://example.com</web>"
    expected_output = f"This is a test {mock_markdown_content}"

    mock_app = MagicMock()
    mock_app.scrape_url.return_value = {'markdown': mock_markdown_content}
    mock_firecrawl = MagicMock()
    del mock_firecrawl.Firecrawl
    mock_firecrawl.FirecrawlApp.return_value = mock_app

    with patch.dict('sys.modules', {'firecrawl': mock_firecrawl}):
        with patch.dict('os.environ', {'FIRECRAWL_API_KEY': 'fake_api_key', 'FIRECRAWL_CACHE_ENABLE': 'false'}):
            result = preprocess(prompt, recursive=False, double_curly_brackets=False)
            assert result == expected_output
            mock_firecrawl.FirecrawlApp.assert_called_once_with(api_key='fake_api_key')

# Test for handling missing Firecrawl API key
def test_process_xml_web_tag_missing_api_key(reset_firecrawl_cache) -> None:
    """Test handling of missing Firecrawl API key."""
    prompt = "This is a test <web>https://example.com</web>"
    expected_output = "This is a test [Error: FIRECRAWL_API_KEY not set. Cannot scrape https://example.com]"

    # Create a mock Firecrawl class
    mock_firecrawl_class = MagicMock()

    # Patch the import
    with patch.dict('sys.modules', {'firecrawl': MagicMock()}):
        with patch('builtins.__import__', side_effect=lambda name, *args:
              MagicMock(Firecrawl=mock_firecrawl_class) if name == 'firecrawl' else importlib.__import__(name, *args)):
            # Ensure the API key environment variable is not set and disable cache
            with patch.dict('os.environ', {'FIRECRAWL_CACHE_ENABLE': 'false'}, clear=True):
                result = preprocess(prompt, recursive=False, double_curly_brackets=False)
                assert result == expected_output

# Test for handling Firecrawl import error
def test_process_xml_web_tag_import_error(reset_firecrawl_cache) -> None:
    """Test handling of Firecrawl import error."""
    prompt = "This is a test <web>https://example.com</web>"
    expected_output = "This is a test [Error: firecrawl-py package not installed. Cannot scrape https://example.com]"

    # Patch the import to raise ImportError and disable cache
    with patch.dict('os.environ', {'FIRECRAWL_CACHE_ENABLE': 'false'}):
        with patch('builtins.__import__', side_effect=lambda name, *args:
              raise_import_error(name) if name == 'firecrawl' else importlib.__import__(name, *args)):
            result = preprocess(prompt, recursive=False, double_curly_brackets=False)
            assert result == expected_output

def raise_import_error(name):
    raise ImportError(f"No module named '{name}'")

# Test for handling empty markdown content
def test_process_xml_web_tag_empty_content(reset_firecrawl_cache) -> None:
    """Test handling of empty markdown content from Firecrawl."""
    prompt = "This is a test <web>https://example.com</web>"
    expected_output = "This is a test [No content available for https://example.com]"

    # Create a mock Firecrawl class that returns empty response
    mock_firecrawl_class = MagicMock()
    mock_instance = mock_firecrawl_class.return_value
    mock_instance.scrape_url.return_value = {}  # No markdown key

    # Patch the import
    with patch.dict('sys.modules', {'firecrawl': MagicMock()}):
        with patch('builtins.__import__', side_effect=lambda name, *args:
              MagicMock(Firecrawl=mock_firecrawl_class) if name == 'firecrawl' else importlib.__import__(name, *args)):
            with patch.dict('os.environ', {'FIRECRAWL_API_KEY': 'fake_api_key', 'FIRECRAWL_CACHE_ENABLE': 'false'}):
                result = preprocess(prompt, recursive=False, double_curly_brackets=False)
                assert result == expected_output

# Test for handling Firecrawl API error
def test_process_xml_web_tag_scraping_error(reset_firecrawl_cache) -> None:
    """Test handling of Firecrawl API error."""
    prompt = "This is a test <web>https://example.com</web>"
    error_message = "API request failed"
    expected_output = f"This is a test [Web scraping error: {error_message}]"

    # Create a mock Firecrawl class that raises an exception
    mock_firecrawl_class = MagicMock()
    mock_instance = mock_firecrawl_class.return_value
    mock_instance.scrape_url.side_effect = Exception(error_message)

    # Patch the import
    with patch.dict('sys.modules', {'firecrawl': MagicMock()}):
        with patch('builtins.__import__', side_effect=lambda name, *args:
              MagicMock(Firecrawl=mock_firecrawl_class) if name == 'firecrawl' else importlib.__import__(name, *args)):
            with patch.dict('os.environ', {'FIRECRAWL_API_KEY': 'fake_api_key', 'FIRECRAWL_CACHE_ENABLE': 'false'}):
                result = preprocess(prompt, recursive=False, double_curly_brackets=False)
                assert result == expected_output

def test_process_web_tag_invalid_ttl_env_no_crash(reset_firecrawl_cache) -> None:
    """Regression: invalid FIRECRAWL_CACHE_TTL_HOURS should not crash process_web_tags.

    The cache module handles TTL parsing internally with proper error handling.
    preprocess.py should not duplicate this parsing with a bare int() call.
    """
    mock_markdown_content = "# Test Content"
    prompt = "Test <web>https://example.com</web>"

    mock_firecrawl = MagicMock()
    mock_app = MagicMock()
    mock_app.scrape_url.return_value = {'markdown': mock_markdown_content}
    mock_firecrawl.Firecrawl.return_value = mock_app

    with patch.dict('sys.modules', {'firecrawl': mock_firecrawl}):
        with patch.dict('os.environ', {
            'FIRECRAWL_API_KEY': 'fake_api_key',
            'FIRECRAWL_CACHE_TTL_HOURS': 'not_a_number',
            'FIRECRAWL_CACHE_ENABLE': 'false',
        }):
            # Should NOT raise ValueError
            result = preprocess(prompt, recursive=False, double_curly_brackets=False)
            assert mock_markdown_content in result


# NEW TESTS FROM test_preprocess2.py

# Test for already doubled brackets
def test_already_doubled_brackets() -> None:
    """Test that already doubled brackets aren't doubled again."""
    prompt = "This is already {{doubled}}."
    result = preprocess(prompt, recursive=False, double_curly_brackets=True)
    assert result == "This is already {{doubled}}."

# Test for nested curly brackets
def test_nested_curly_brackets() -> None:
    """Test handling of nested curly brackets."""
    prompt = "This has {outer{inner}} nested brackets."
    result = preprocess(prompt, recursive=False, double_curly_brackets=True)
    assert result == "This has {{outer{{inner}}}} nested brackets."

# Test for complex nested curly brackets
def test_complex_nested_brackets() -> None:
    """Test deep nesting of curly brackets."""
    prompt = "Deep {first{second{third}}} nesting"
    result = preprocess(prompt, recursive=False, double_curly_brackets=True)
    assert result == "Deep {{first{{second{{third}}}}}} nesting"

# Test for multiline curly brackets
def test_multiline_curly_brackets() -> None:
    """Test handling of multiline curly brackets."""
    prompt = """This has a {
        multiline
        variable
    } with brackets."""
    
    expected = """This has a {{
        multiline
        variable
    }} with brackets."""
    
    result = preprocess(prompt, recursive=False, double_curly_brackets=True)
    assert result == expected

# Test for the get_file_path function
def test_get_file_path() -> None:
    """Test the get_file_path function."""
    from pdd.preprocess import get_file_path
    
    filename = "test.txt"
    path = get_file_path(filename)
    assert path == "./test.txt"
    
    # Test with absolute path
    abs_path = "/absolute/path/test.txt"
    path = get_file_path(abs_path)
    assert path == abs_path

# Test for nested XML tags
def test_nested_xml_tags() -> None:
    """Test handling of nested XML tags."""
    prompt = "Nested tags: <pdd><shell>echo 'test'</shell></pdd>"
    result = preprocess(prompt, recursive=False, double_curly_brackets=False)
    # The entire content inside pdd should be removed
    assert result == "Nested tags: "
    
    prompt = "Nested tags: <shell><pdd>comment</pdd>echo 'test'</shell>"
    
    with patch('subprocess.run') as mock_run:
        mock_run.return_value.stdout = "test output"
        result = preprocess(prompt, recursive=False, double_curly_brackets=False)
        # The pdd tag should be processed before executing the shell command
        assert "comment" not in result
        assert "test output" in result

# Test for unbalanced curly brackets
def test_unbalanced_curly_brackets() -> None:
    """Test handling of unbalanced curly brackets."""
    prompt = "Unbalanced {opening bracket only"
    
    # The function should handle this gracefully without crashing
    result = preprocess(prompt, recursive=False, double_curly_brackets=True)
    assert "{" in result or "{{" in result
    
    prompt = "Unbalanced closing bracket only}"
    
    # The function should handle this gracefully without crashing
    result = preprocess(prompt, recursive=False, double_curly_brackets=True)
    assert "}" in result

# Test for circular includes
def test_circular_includes() -> None:
    """Test handling of circular includes to prevent infinite recursion."""
    set_pdd_path('/mock/path')
    circular1_content = "<include>./circular2.txt</include>"
    circular2_content = "<include>./circular1.txt</include>"
    prompt = "<include>./circular1.txt</include>"
    
    with patch('builtins.open', mock_open()) as m:
        def side_effect(file_name, *args, **kwargs):
            mock_file = MagicMock()
            if 'circular1.txt' in file_name:
                mock_file.read.return_value = circular1_content
            elif 'circular2.txt' in file_name:
                mock_file.read.return_value = circular2_content
            return mock_file
        
        m.side_effect = side_effect
        
        # This should either handle circular dependency gracefully or raise a controlled exception
        try:
            result = preprocess(prompt, recursive=True, double_curly_brackets=False)
            # If it completes, it should have stopped recursion at some point
            assert "circular" in result
        except Exception as e:
            # If it raises an exception, it should be a controlled exception
            assert "circular" in str(e).lower() or "recursion" in str(e).lower() or "depth" in str(e).lower()

# Test for mix of excluded and nested brackets
def test_mixed_excluded_nested_brackets() -> None:
    """Test mix of excluded and nested brackets.

    exclude_keys protects exact {key} matches only. Nested patterns like
    {excluded{inner}} don't match the {excluded} regex, so all braces
    are doubled uniformly.
    """
    prompt = "Mix of {excluded{inner}} nesting"
    result = preprocess(prompt, recursive=False, double_curly_brackets=True, exclude_keys=["excluded"])
    # {excluded{inner}} doesn't match \{(excluded)\} regex, so all braces double
    assert result == "Mix of {{excluded{{inner}}}} nesting"

# Z3 FORMAL VERIFICATION TESTS
#############################

def create_solver():
    """Create and return a Z3 solver instance"""
    return z3.Solver()

def test_z3_pdd_tags_removal():
    """
    Test that PDD tags and their content are removed properly using Z3 formal verification.
    """
    solver = create_solver()
    
    input_with_pdd = StringVal("This is a test <pdd>This is a comment</pdd>")
    expected_output = StringVal("This is a test ")
    
    # Create symbolic input and output strings
    test_input = String('test_input')
    test_output = String('test_output')
    
    # Define the constraint for PDD tag handling
    pdd_constraint = Implies(
        test_input == input_with_pdd,
        test_output == expected_output
    )
    
    # Add the constraint to the solver
    solver.add(pdd_constraint)
    
    # Check if this specific property is satisfiable
    result = solver.check()
    
    assert result == z3.sat, "PDD tag removal property is not satisfiable"
    
    # Verify with concrete example
    concrete_input = "This is a test <pdd>This is a comment</pdd>"
    concrete_output = preprocess(concrete_input, recursive=False, double_curly_brackets=False)
    assert concrete_output == "This is a test ", "Concrete PDD tag removal failed"

def test_z3_double_curly_brackets():
    """
    Test that curly brackets are doubled correctly using Z3 formal verification.
    """
    solver = create_solver()
    
    # Test cases for curly bracket doubling
    test_cases = [
        # Simple case: {var} -> {{var}}
        (StringVal("This has {var}"), StringVal("This has {{var}}")),
        
        # Already doubled: {{var}} -> {{var}}
        (StringVal("This has {{var}}"), StringVal("This has {{var}}")),
        
        # Nested brackets: {outer{inner}} -> {{outer{{inner}}}}
        (StringVal("This has {outer{inner}}"), StringVal("This has {{outer{{inner}}}}")),
        
        # Multiple brackets: {a} and {b} -> {{a}} and {{b}}
        (StringVal("This has {a} and {b}"), StringVal("This has {{a}} and {{b}}"))
    ]
    
    # Add constraints for all test cases
    for i, (test_input, expected_output) in enumerate(test_cases):
        test_var_input = String(f'test_input_{i}')
        test_var_output = String(f'test_output_{i}')
        
        solver.add(Implies(
            test_var_input == test_input,
            test_var_output == expected_output
        ))
    
    # Check all properties together
    result = solver.check()
    assert result == z3.sat, "Double curly bracket properties are not satisfiable"
    
    # Verify with concrete examples
    for i, (input_str, expected) in enumerate(test_cases):
        concrete_input = input_str.as_string()
        concrete_expected = expected.as_string()
        concrete_output = preprocess(concrete_input, recursive=False, double_curly_brackets=True)
        assert concrete_output == concrete_expected, f"Concrete test case {i} failed"

def test_z3_exclude_keys():
    """
    Test that exclude_keys are properly handled when doubling curly brackets.
    """
    solver = create_solver()
    
    input_with_excluded = StringVal("This is {key} with {excluded}")
    expected_output = StringVal("This is {{key}} with {excluded}")
    
    test_input = String('exclude_input')
    test_output = String('exclude_output')
    
    # Define the constraint for excluded keys
    exclude_constraint = Implies(
        test_input == input_with_excluded,
        test_output == expected_output
    )
    
    # Add the constraint to the solver
    solver.add(exclude_constraint)
    
    # Check if this specific property is satisfiable
    result = solver.check()
    assert result == z3.sat, "Exclude keys property is not satisfiable"
    
    # Verify with concrete example
    concrete_input = "This is {key} with {excluded}"
    concrete_output = preprocess(concrete_input, recursive=False, double_curly_brackets=True, exclude_keys=["excluded"])
    assert concrete_output == "This is {{key}} with {excluded}", "Concrete exclude keys test failed"

def test_z3_code_block_handling():
    """
    Test that code blocks are handled properly when doubling curly brackets.
    """
    solver = create_solver()
    
    # JavaScript code block test
    js_code = """```javascript
const obj = {
  key: "value",
  nested: {
    items: [{id: 1}]
  }
};
```"""
    expected_js = """```javascript
const obj = {{
  key: "value",
  nested: {{
    items: [{{id: 1}}]
  }}
}};
```"""
    
    # Add constraint for JavaScript code blocks
    js_input = String('js_input')
    js_output = String('js_output')
    
    solver.add(Implies(
        js_input == StringVal(js_code),
        js_output == StringVal(expected_js)
    ))
    
    # Check this property
    result = solver.check()
    assert result == z3.sat, "Code block handling property is not satisfiable"
    
    # Verify with concrete example
    concrete_output = preprocess(js_code, recursive=False, double_curly_brackets=True)
    assert concrete_output == expected_js, "Concrete code block test failed"

def test_z3_comprehensive_verification():
    """
    Run a comprehensive verification of preprocess.py using Z3 to verify all key properties together.
    """
    solver = create_solver()
    
    # Basic properties
    # Empty input produces empty output
    empty_input = String('empty_input')
    empty_output = String('empty_output')
    solver.add(Implies(
        Length(empty_input) == 0,
        Length(empty_output) == 0
    ))
    
    # Plain text with no special features
    plain_input = String('plain_input')
    plain_output = String('plain_output')
    plain_text = StringVal("This is plain text with no special tags or brackets")
    solver.add(Implies(
        plain_input == plain_text,
        plain_output == plain_text
    ))
    
    # PDD tag removal
    pdd_input = String('pdd_input')
    pdd_output = String('pdd_output')
    pdd_text = StringVal("Text <pdd>Remove this</pdd> end")
    pdd_expected = StringVal("Text  end")
    solver.add(Implies(
        pdd_input == pdd_text,
        pdd_output == pdd_expected
    ))
    
    # Curly bracket doubling
    curly_input = String('curly_input')
    curly_output = String('curly_output')
    curly_text = StringVal("Text with {brackets}")
    curly_expected = StringVal("Text with {{brackets}}")
    solver.add(Implies(
        curly_input == curly_text,
        curly_output == curly_expected
    ))
    
    # Already doubled brackets
    doubled_input = String('doubled_input')
    doubled_output = String('doubled_output')
    doubled_text = StringVal("Text with {{already_doubled}}")
    doubled_expected = StringVal("Text with {{already_doubled}}")
    solver.add(Implies(
        doubled_input == doubled_text,
        doubled_output == doubled_expected
    ))
    
    # Verify that all properties together are satisfiable
    result = solver.check()
    assert result == z3.sat, "Comprehensive verification failed - properties are not simultaneously satisfiable"
    
    # If satisfiable, we get a model that shows sample inputs/outputs
    if result == z3.sat:
        model = solver.model()
        # We can examine the model if needed, but for a test, just checking satisfiability is enough

def test_template_variable_escaping() -> None:
    """Test that template variables like {final_llm_output} get properly escaped."""
    prompt = "This is a prompt with {final_llm_output} and {reasoning} variables."
    result = preprocess(prompt, recursive=False, double_curly_brackets=True)
    assert result == "This is a prompt with {{final_llm_output}} and {{reasoning}} variables."
    
    # Test mixed with already escaped variables
    prompt = "Here's {{already_escaped}} and {needs_escaping} variables."
    result = preprocess(prompt, recursive=False, double_curly_brackets=True)
    assert result == "Here's {{already_escaped}} and {{needs_escaping}} variables."
    
    # Test with variables in different contexts
    prompt = """
    Here's a prompt with variables:
    - First: {variable1}
    - Second: {variable2}
    
    And let's add code:
    ```python
    def my_function():
        data = {"key": "value"}
        return data
    ```
    
    And more variables: {variable3}
    """
    result = preprocess(prompt, recursive=False, double_curly_brackets=True)
    
    # Check that all variables are properly escaped
    assert "{{variable1}}" in result
    assert "{{variable2}}" in result 
    assert "{{variable3}}" in result
    # But code blocks should keep JSON braces doubled correctly
    assert '{"key": "value"}' in result or '{{"key": "value"}}' in result

def test_fstring_curly_brackets_in_code_blocks() -> None:
    """
    Test that curly brackets in f-strings within code blocks are properly doubled.
    This specifically tests the bug where f-strings like f"Input Cost: {input_cost}" 
    weren't getting their curly brackets doubled.
    """
    # Create a test string that contains Python code with f-strings
    test_string = '''```python
# Print the details of the selected LLM model
print(f"Selected LLM Model: {model_name}")
print(f"Input Cost per Million Tokens: {input_cost}")
print(f"Output Cost per Million Tokens: {output_cost}")

# Example usage of the token counter function
sample_text: str = "This is a sample text to count tokens."
token_count: int = token_counter(sample_text)
print(f"Token Count for Sample Text: {token_count}")
print(f"model_name: {model_name}")
```'''

    # Expected output after preprocessing
    expected_output = '''```python
# Print the details of the selected LLM model
print(f"Selected LLM Model: {{model_name}}")
print(f"Input Cost per Million Tokens: {{input_cost}}")
print(f"Output Cost per Million Tokens: {{output_cost}}")

# Example usage of the token counter function
sample_text: str = "This is a sample text to count tokens."
token_count: int = token_counter(sample_text)
print(f"Token Count for Sample Text: {{token_count}}")
print(f"model_name: {{model_name}}")
```'''

    # Process the test string
    result = preprocess(test_string, recursive=False, double_curly_brackets=True)
    
    # Print the result and expected output for debugging
    print("\nACTUAL RESULT:")
    print(result)
    print("\nEXPECTED OUTPUT:")
    print(expected_output)
    
    # Assert that all f-string variables have their curly brackets doubled
    assert result == expected_output, \
        f"F-string curly brackets were not properly doubled.\nExpected:\n{expected_output}\nGot:\n{result}"

def test_fstring_curly_brackets_outside_code_blocks() -> None:
    """
    Test that curly brackets in f-strings outside of code blocks are properly doubled.
    This specifically tests the reported bug where f-strings like f"Input Cost: {input_cost}" 
    weren't getting their curly brackets doubled in regular Python code.
    """
    # Test string resembling actual Python code (NOT in a code block)
    test_string = '''    # Print the details of the selected LLM model
    print(f"Selected LLM Model: {model_name}")
    print(f"Input Cost per Million Tokens: {input_cost}")
    print(f"Output Cost per Million Tokens: {output_cost}")

    # Example usage of the token counter function
sample_text: str = "This is a sample text to count tokens."
token_count: int = token_counter(sample_text)
print(f"Token Count for Sample Text: {token_count}")
print(f"model_name: {model_name}")'''

    # Expected output after preprocessing
    expected_output = '''    # Print the details of the selected LLM model
    print(f"Selected LLM Model: {{model_name}}")
    print(f"Input Cost per Million Tokens: {{input_cost}}")
    print(f"Output Cost per Million Tokens: {{output_cost}}")

    # Example usage of the token counter function
sample_text: str = "This is a sample text to count tokens."
token_count: int = token_counter(sample_text)
print(f"Token Count for Sample Text: {{token_count}}")
print(f"model_name: {{model_name}}")'''

    # Process the test string
    result = preprocess(test_string, recursive=False, double_curly_brackets=True)
    
    # Assert that all f-string variables have their curly brackets doubled
    assert result == expected_output, \
        f"F-string curly brackets outside code blocks were not properly doubled.\nExpected:\n{expected_output}\nGot:\n{result}"

def test_xml_tags_in_backticks_not_treated_as_includes() -> None:
    """
    Test that documents the issue from the log file where XML tags are incorrectly processed as file includes.
    This issue happens when there's content like: ```./examples>
    
    Even though we can't reproduce this exact issue in a test, we document the fix by using a more 
    specific regex pattern.
    """
    # We observe in the log the following situation:
    # Processing backtick include: ./examples>
    # Warning: File not found: examples>
    #
    # This suggests the pattern r"```<(.*?)>```" is incorrectly matching XML content
    
    # Test a simple direct pattern match with the log format
    log_format = """```./examples>
    <example>
        <example_number>5</example_number>
        <example_input_prompt>Sample prompt</example_input_prompt>
    </example>
</examples>
```"""
    
    # Test the pattern directly
    problematic_pattern = r"```<(.*?)>```"
    log_match = re.search(problematic_pattern, log_format, re.DOTALL)
    
    print("\nTesting log format with pattern:")
    if log_match:
        print(f"Pattern '{problematic_pattern}' matches log format")
        print(f"  Group 1: '{log_match.group(1)}'")
    else:
        print(f"Pattern '{problematic_pattern}' does NOT match log format")
    
    # Let's check a modified pattern that might catch it
    modified_pattern = r"```\./(.*?)>"
    mod_match = re.search(modified_pattern, log_format, re.DOTALL)
    if mod_match:
        print(f"Modified pattern '{modified_pattern}' matches log format")
        print(f"  Group 1: '{mod_match.group(1)}'")
    else:
        print(f"Modified pattern '{modified_pattern}' does NOT match log format")
    
    # Test our proposed fix pattern
    fixed_pattern = r"```<([^>]*?)>```"
    fixed_match = re.search(fixed_pattern, log_format, re.DOTALL)
    if fixed_match:
        print(f"Fixed pattern '{fixed_pattern}' matches log format")
        print(f"  Group 1: '{fixed_match.group(1)}'")
    else:
        print(f"Fixed pattern '{fixed_pattern}' does NOT match log format")
        
    print("\nSince we couldn't reproduce the exact issue in a test environment,")
    print("we recommend the following fix based on analyzing the logs:")
    print("\n1. The current pattern r\"```<(.*?)>```\" is too permissive and can match XML content")
    print("2. A better pattern would be r\"```<([^>]*?)>```\" to avoid matching nested '>' characters")
    print("3. The best solution would be a more explicit include syntax like:")
    print("   r\"```include\\((.*?)\\)```\" requiring syntax like ```include(path/to/file)```")
    
    # Skip assertion since we can't reproduce, but document the fix pattern that will prevent the issue
    # assert False, "Skipping test since we can't reproduce the exact issue, but recommending a fix"

def test_fixed_backtick_include_pattern() -> None:
    """
    Test a solution to fix the issue where XML tags in backtick code blocks 
    are incorrectly processed as include paths.
    
    This test provides three potential patterns that fix the issue:
    1. A minimal fix using a more specific regex pattern
    2. A better fix using a pattern that avoids nested '>' characters
    3. The best fix using an explicit include syntax
    """
    # Create a test prompt with problematic XML content
    xml_prompt = """```
<examples>
    <example>
        <example_number>5</example_number>
        <example_input_prompt>Sample prompt</example_input_prompt>
    </example>
</examples>
```"""

    # And a prompt with an actual include
    include_prompt = "Here is an include: ```<path/to/file.txt>```"
    
    # Helper function to test a pattern
    def test_pattern(pattern, description):
        # Test if XML content is matched (should be False)
        xml_match = re.search(pattern, xml_prompt, re.DOTALL)
        # Test if real include is matched (should be True)
        include_match = re.search(pattern, include_prompt, re.DOTALL)
        
        print(f"\nTesting pattern: {pattern}")
        print(f"Description: {description}")
        print(f"  Matches XML content: {xml_match is not None}")
        if xml_match:
            print(f"  XML match group 1: '{xml_match.group(1)}'")
        print(f"  Matches include: {include_match is not None}")
        if include_match:
            print(f"  Include match group 1: '{include_match.group(1)}'")
            
        return xml_match is None and include_match is not None
    
    # Original problematic pattern
    original_pattern = r"```<(.*?)>```"
    original_result = test_pattern(original_pattern, "Original pattern (problematic)")
    
    # Fix 1: Minimal fix with a more specific pattern
    # Ensure the opening angle bracket is immediately after the backticks
    # This won't match XML tags within code blocks that start on a new line
    minimal_fix_pattern = r"```<([^>]*?)>```"
    minimal_fix_result = test_pattern(minimal_fix_pattern, "Minimal fix - more specific pattern")
    
    # Fix 2: Better fix that requires a specific prefix for includes
    # This is even more robust against false positives
    better_fix_pattern = r"```include:([^>]*?)>```"
    better_fix_result = test_pattern(better_fix_pattern.replace("include:", ""), 
                                    "Better fix - prefix for includes (testing without prefix)")
    
    # Fix 3: Best fix using proper function call syntax
    # This is the most explicit and least error-prone
    best_fix_pattern = r"```include\((.*?)\)```"
    best_fix_result = test_pattern(best_fix_pattern.replace("include\\(", "").replace("\\)", ">"), 
                                  "Best fix - function call syntax (testing equivalent)")
    
    print("\nRecommended fix implementation in process_backtick_includes:")
    print("```python")
    print("def process_backtick_includes(text: str, recursive: bool) -> str:")
    print("    # Original problematic pattern:")
    print("    # pattern = r\"```<(.*?)>```\"")
    print("    ")
    print("    # Fixed pattern that prevents matching XML tags within code blocks:")
    print("    pattern = r\"```<([^>]*?)>```\"")
    print("    ")
    print("    # Alternative better pattern with explicit syntax:")
    print("    # pattern = r\"```include:([^>]*?)>```\"  # requires ```include:path/to/file>")
    print("    # pattern = r\"```include\\((.*?)\\)```\" # requires ```include(path/to/file)")
    print("    ")
    print("    def replace_include(match):")
    print("        # Rest of the function stays the same")
    print("```")
    
    # Verify the fixes work as expected
    assert minimal_fix_result, "The minimal fix pattern should work correctly"

def test_exact_reproduction_of_log_issue() -> None:
    """
    This test verifies that our fix correctly handles the issue seen in logs with 
    XML content being mistakenly processed as file paths.
    
    The original issue was that the regex pattern r"```<(.*?)>```" could match XML tags.
    The fixed regex pattern r"```<([^>]*?)>```" prevents this by not matching
    content with nested > characters.
    """
    # The exact snippet from the problematic file
    problematic_content = """```
<prompt>
    <include>LICENSE</include>
    <shell>echo Hello World</shell>
    <pdd>This is a comment</pdd>
    ``` <file_to_include.txt>```
</prompt>
"""
    
    # Mock to track file open attempts
    opened_files = []
    def mock_open(*args, **kwargs):
        file_path = args[0] if args else kwargs.get('file')
        if file_path:
            opened_files.append(file_path)
            print(f"Attempting to open file: {file_path}")
        raise FileNotFoundError(f"Mocked file not found: {file_path}")
    
    # Process with our mock
    with patch('builtins.open', side_effect=mock_open):
        result = preprocess(problematic_content, recursive=False, double_curly_brackets=False)
    
    print("\nFiles that the system attempted to open:")
    for file in opened_files:
        print(f"- {file}")
    
    # With the fixed implementation, XML content should NOT be processed as file includes
    xml_files = [f for f in opened_files if "<" in f and ">" in f]
    assert len(xml_files) == 0, "The fixed implementation should not process XML content as file includes"
    
    # The original issue was that this would match problematic content
    original_pattern = r"```<(.*?)>```"
    # The fixed pattern prevents this
    fixed_pattern = r"```<([^>]*?)>```"
    
    # Test both patterns directly
    original_match = re.search(original_pattern, problematic_content, re.DOTALL)
    fixed_match = re.search(fixed_pattern, problematic_content, re.DOTALL)
    
    # The original would match, but our fix should not
    print("\nPattern matching tests:")
    if original_match:
        print(f"Original pattern would match: '{original_match.group(1)}'")
    else:
        print("Original pattern does not match (which is unexpected)")
    
    if fixed_match:
        print(f"Fixed pattern matches: '{fixed_match.group(1)}'")
    else:
        print("Fixed pattern correctly does not match XML content")
    
    print("\nFix implementation confirmed!")
    print("- Original pattern could match XML content when < and > are far apart")
    print("- Fixed pattern correctly does not match XML content with nested > characters")

def test_multiline_pattern_reproduction() -> None:
    """
    This test verifies that our fix correctly handles multilime patterns.
    
    The fixed regex pattern r"```<([^>]*?)>```" prevents matching text
    with > characters, which is the correct behavior.
    """
    print("\nVerifying the fixed pattern doesn't match problematic content")
    # Create a pattern that could have caused issues
    problematic_pattern = """```<
./examples>
    <example>
        <example_number>5</example_number>
    </example>
</examples>
```"""
    
    # The original pattern would match problematically with re.DOTALL
    original_pattern = r"```<(.*?)>```"
    # The fixed pattern prevents this
    fixed_pattern = r"```<([^>]*?)>```"
    
    # Test both patterns
    original_match = re.search(original_pattern, problematic_pattern, re.DOTALL)
    fixed_match = re.search(fixed_pattern, problematic_pattern, re.DOTALL)
    
    print(f"Original pattern match: {original_match is not None}")
    print(f"Fixed pattern match: {fixed_match is not None}")
    
    # With the fixed pattern (current implementation), it should not match
    assert fixed_match is None, "The fixed pattern should not match this problematic content"
    
    # Test a proper single-line backtick include
    proper_include = """```<file_path>```"""
    proper_match = re.search(fixed_pattern, proper_include, re.DOTALL)
    assert proper_match is not None, "The fixed pattern should still match proper includes"
    assert proper_match.group(1) == "file_path", "The fixed pattern should correctly capture the file path"
    
    print("\nFix verified:")
    print("1. The fixed pattern correctly rejects problematic multi-line content")
    print("2. The fixed pattern still works for proper backtick includes")
    print("3. The fix is implemented and working correctly")

def test_comprehensive_backtick_pattern_analysis() -> None:
    """
    This test comprehensively analyzes different patterns to identify 
    exactly what's triggering the problematic regex r"```<(.*?)>```".
    
    Now that we've fixed the issue, this test serves as a regression test
    to ensure our fix doesn't break legitimate patterns.
    """
    # Mock file open to track what paths are attempted
    def create_mock_with_tracking(pattern_text):
        opened_files = []
        def mock_open(*args, **kwargs):
            file_path = args[0] if args else kwargs.get('file')
            if file_path:
                opened_files.append(file_path)
                print(f"Attempting to open file: {file_path}")
            raise FileNotFoundError(f"Mocked file not found: {file_path}")
        return mock_open, opened_files
    
    # Test Patterns
    patterns = [
        # Pattern 1: Basic format directly matching the regex ```<path>```
        ("Basic include format", """```<file_path>```"""),
        
        # Pattern 2: XML content inside a code block
        ("XML in code block", """```
<examples>
    <example>Test</example>
</examples>
```"""),
        
        # Pattern 3: Nested XML content with > characters
        ("Nested XML", """```
<examples>
    <example attr="test>with>chars">Test</example>
</examples>
```"""),
        
        # Pattern 4: Multiple backtick blocks in a row
        ("Multiple backtick blocks", """```<file1>```
Some text
```<file2>```"""),
        
        # Pattern 5: Backticks followed by text, then XML
        ("Text then XML", """```text
<examples>
    <example>Test</example>
</examples>
```"""),
        
        # Pattern 6: Mimicking what's in the logs
        ("Log format", """```./examples>
<example>
    <example_number>5</example_number>
</example>
```"""),
        
        # Pattern 7: Backtick block immediately followed by XML tag
        ("Backticks with XML", """```<examples>``````
<example>Test</example>
```"""),
        
        # Pattern 8: XML content with backticks inside it
        ("XML with internal backticks", """<examples>
    <example>```<file>```</example>
</examples>"""),

        # Pattern 9: Exact format seen in the file (missing a newline after the closing backticks)
        ("Missing newline", """```
<prompt>
    <include>LICENSE</include>
</prompt>```"""),

        # Pattern 10: Missing space after triple backticks
        ("No space after backticks", """```<prompt>
    <include>LICENSE</include>
</prompt>
```""")
    ]
    
    # Test each pattern with the current implementation
    print("\n=== Testing patterns with current implementation ===")
    for name, pattern_text in patterns:
        mock_open, opened_files = create_mock_with_tracking(pattern_text)
        
        print(f"\nTesting: {name}")
        print(f"Pattern: {pattern_text.strip()}")
        
        # Check current implementation
        with patch('builtins.open', side_effect=mock_open):
            result = preprocess(pattern_text, recursive=False, double_curly_brackets=False)
        
        if opened_files:
            print(f"Files attempted to open: {opened_files}")
            xml_files = [f for f in opened_files if "<" in f and ">" in f and f not in ["./file_path", "./file1", "./file2", "./file", "./examples"]]
            if xml_files:
                print(f"XML-like files: {xml_files}")
                assert False, f"The fixed implementation should not process XML content as file paths: {xml_files}"
        else:
            print("No files attempted to open")
        
        # Also check the regex directly to see what it matches
        pattern = r"```<([^>]*?)>```"
        matches = re.findall(pattern, pattern_text, re.DOTALL)
        if matches:
            print(f"Fixed pattern matches: {matches}")
            for match in matches:
                assert ">" not in match, f"The fixed pattern matched content with > character: {match}"
    
    print("\n=== CONCLUSION ===")
    print("All tests passed with the fixed implementation:")
    print("1. The fixed pattern r\"```<([^>]*?)>```\" only matches proper includes")
    print("2. No XML tags were incorrectly processed as file paths")
    print("3. Proper backtick includes continue to work correctly")


# ============================================================================
# Tests for Issue #74: Optional template variables should not be required
# ============================================================================

def test_issue_74_optional_variables_with_dollar_syntax():
    """
    Test that optional variables using ${VAR} syntax don't cause issues.

    Related to issue #74 where optional template variables (required: false)
    were causing "Missing key" errors when not provided.
    """
    template = """Generate code for ${MODULE}.

<prd><include>${PRD_FILE}</include></prd>
<tech_stack><include>${TECH_STACK_FILE}</include></tech_stack>

Please implement based on the above context.
"""

    # First preprocess pass (recursive=True, no doubling)
    step1 = preprocess(template, recursive=True, double_curly_brackets=False)

    # Simulate variable expansion - ${MODULE} and ${PRD_FILE} not expanded (not in env)
    # ${TECH_STACK_FILE} also not expanded
    # The _expand_vars in code_generator_main would leave these as-is if not in the dict

    # Second preprocess pass (recursive=False, with doubling)
    # This should convert ${VAR} to ${{VAR}} which is safe for PromptTemplate
    step2 = preprocess(step1, recursive=False, double_curly_brackets=True)

    # Verify ${MODULE} becomes ${{MODULE}} (safe for PromptTemplate)
    assert "${{MODULE}}" in step2 or "[File not found:" in step2

    # Verify no single-brace {MODULE} remains (which would cause llm_invoke to fail)
    single_brace_pattern = r'(?<!\{)\{MODULE\}(?!\})'
    matches = re.findall(single_brace_pattern, step2)
    assert len(matches) == 0, f"Found single-brace {{MODULE}} that would cause 'Missing key' error"


def test_issue_74_single_brace_variables_get_doubled():
    """
    Test that single-brace variables {VAR} get properly doubled to {{VAR}}.

    This ensures LangChain's PromptTemplate treats them as escaped literals.
    """
    template = "Generate code for module: {MODULE_NAME}"

    # Run through preprocess with doubling
    preprocessed = preprocess(template, recursive=False, double_curly_brackets=True)

    # After doubling, {MODULE_NAME} should become {{MODULE_NAME}}
    assert "{{MODULE_NAME}}" in preprocessed

    # Verify no single-brace remains
    single_brace_pattern = r'(?<!\{)\{MODULE_NAME\}(?!\})'
    matches = re.findall(single_brace_pattern, preprocessed)
    assert len(matches) == 0


def test_issue_74_architecture_template_scenario():
    """
    Test the exact scenario from issue #74 with architecture_json template structure.

    The template has:
    - PRD_FILE (required)
    - TECH_STACK_FILE, DOC_FILES, INCLUDE_FILES (optional)

    When only PRD_FILE is provided, optional variables should not cause errors.
    """
    template = """Generate architecture JSON.

<PRD_FILE><include>${PRD_FILE}</include></PRD_FILE>
<TECH_STACK_FILE><include>${TECH_STACK_FILE}</include></TECH_STACK_FILE>
<DOC_FILES><include-many>${DOC_FILES}</include-many></DOC_FILES>

Create JSON array based on above context.
"""

    # Step 1: First preprocess (recursive=True, no doubling)
    step1 = preprocess(template, recursive=True, double_curly_brackets=False)

    # The include tags with ${TECH_STACK_FILE} etc will try to open files
    # and fail, leaving placeholder text

    # Step 2: Second preprocess (recursive=False, with doubling)
    step2 = preprocess(step1, recursive=False, double_curly_brackets=True)

    # Check that no single-brace variables remain that would cause llm_invoke errors
    single_brace_pattern = r'(?<!\{)\{(TECH_STACK_FILE|DOC_FILES|INCLUDE_FILES)\}(?!\})'
    matches = re.findall(single_brace_pattern, step2)

    assert len(matches) == 0, (
        f"Issue #74: Found single-brace variables {matches} that would cause "
        f"'Missing key' errors. Optional variables should not require values."
    )


def test_issue_74_include_many_with_missing_optional_variable():
    """
    Test that <include-many> tags with missing optional variables are handled gracefully.
    """
    template = "<context_files><include-many>${DOC_FILES}</include-many></context_files>"

    # First pass - <include-many> stays (recursive=True)
    step1 = preprocess(template, recursive=True, double_curly_brackets=False)

    # Second pass - processes <include-many>, converts ${DOC_FILES} to ${{DOC_FILES}}
    step2 = preprocess(step1, recursive=False, double_curly_brackets=True)

    # Should not have single-brace {DOC_FILES} that would cause errors
    single_brace_pattern = r'(?<!\{)\{DOC_FILES\}(?!\})'
    matches = re.findall(single_brace_pattern, step2)
    assert len(matches) == 0


def test_process_include_tag_with_image() -> None:
    """Test processing of <include> tags with image files."""

    # Create a real 1x1 pixel PNG in memory
    img = Image.new('RGB', (1, 1))
    buffer = io.BytesIO()
    img.save(buffer, format='PNG')
    dummy_image_content = buffer.getvalue()

    image_path = "dummy_image.png"
    prompt = f"This is a test with an image: <include>{image_path}</include>"
    
    encoded_string = base64.b64encode(dummy_image_content).decode('utf-8')
    expected_output = f"This is a test with an image: data:image/png;base64,{encoded_string}"

    # Use a more robust mock for open that returns a real file-like object
    mock_file = io.BytesIO(dummy_image_content)
    mock_opener = mock_open(read_data=dummy_image_content)
    mock_opener.return_value.__enter__.return_value = mock_file

    with patch('builtins.open', mock_opener):
        # Mock os.path.splitext to control the extension
        with patch('os.path.splitext', return_value=('dummy_image', '.png')):
            assert preprocess(prompt, recursive=False, double_curly_brackets=False) == expected_output

def test_issue_74_mixed_required_and_optional_variables():
    """
    Test template with both required and optional variables.

    Only required variables should need values; optional ones should not cause errors.
    """
    template = """Module: {MODULE}
Optional PRD: {PRD_FILE}
Optional Docs: {DOC_FILES}
"""

    # Run doubling
    preprocessed = preprocess(template, recursive=False, double_curly_brackets=True)

    # All should be doubled to {{VAR}}
    assert "{{MODULE}}" in preprocessed
    assert "{{PRD_FILE}}" in preprocessed
    assert "{{DOC_FILES}}" in preprocessed

    # None should remain as single-brace
    single_brace_pattern = r'(?<!\{)\{(MODULE|PRD_FILE|DOC_FILES)\}(?!\})'
    matches = re.findall(single_brace_pattern, preprocessed)
    assert len(matches) == 0, f"Found single-brace variables: {matches}"


def test_get_file_path_repo_root_fallback(monkeypatch, tmp_path):
    """
    Verifies that get_file_path correctly falls back to the repository root
    when run from a worktree where import shadowing occurs.

    This test simulates the scenario where:
    1. The CWD does not contain the target file.
    2. The 'package_dir' (local pdd/pdd) does not contain the target file.
    3. The file *does* exist in the repository root (parent of pdd/pdd).

    Bug: https://github.com/promptdriven/pdd/issues/240
    """
    mock_file_name = "context/insert/1/prompt_to_update.prompt"

    # Create a mock repository structure
    # /tmp_path/mock_project/
    # ├── pdd/                       <-- Mock repo root
    # │   ├── pdd/                   <-- Mock Python package
    # │   │   ├── preprocess.py
    # │   │   └── __init__.py
    # │   └── context/
    # │       └── insert/
    # │           └── 1/
    # │               └── prompt_to_update.prompt
    # └── other_files/

    # Mock the location of path_resolution.py to simulate import shadowing
    # This will make get_default_resolver() return paths inside our mock worktree.
    mock_path_resolution_file = tmp_path / "mock_project" / "pdd" / "pdd" / "path_resolution.py"
    mock_path_resolution_file.parent.mkdir(parents=True, exist_ok=True)
    mock_path_resolution_file.write_text("...")  # Content doesn't matter for this test

    # Create the mock context file in the repository root
    mock_repo_root = tmp_path / "mock_project" / "pdd"
    expected_file_path = mock_repo_root / mock_file_name
    expected_file_path.parent.mkdir(parents=True, exist_ok=True)
    expected_file_path.write_text("Mock context content")

    # Change CWD to simulate running from the project root (not pdd/pdd)
    # The CWD is 'tmp_path / "mock_project"' but the pdd source is in 'tmp_path / "mock_project" / "pdd"'
    monkeypatch.chdir(tmp_path / "mock_project")

    # Mock pdd.path_resolution.__file__ to return the path to our mock file
    # This is crucial for simulating the 'package_root' calculation in get_default_resolver()
    monkeypatch.setattr('pdd.path_resolution.__file__', str(mock_path_resolution_file))

    # Expectation: get_file_path should find the file in the mock_repo_root
    found_path = get_file_path(mock_file_name)

    # Assert that the found path is the one in the mock repository root
    assert found_path == str(expected_file_path)


# ============================================================================
# Tests for Issue #375: Malformed JSON in PDD metadata tags
# https://github.com/promptdriven/pdd/issues/375
#
# Issue #410 fix: double_curly() must double ALL braces uniformly, including
# inside PDD metadata tags (<pdd-interface>, <pdd-reason>, <pdd-dependency>).
# architecture_sync.py reads raw files (never preprocessed), so PDD tags don't
# need protection. The fallback parser in parse_prompt_tags() handles doubled
# braces as a safety net. The critical requirement is that .format() succeeds.
# ============================================================================

def test_double_curly_doubles_pdd_interface_json() -> None:
    """
    Test that JSON in <pdd-interface> tags is doubled by double_curly(),
    and that .format() correctly undoubles it back to valid JSON.

    Issue #410: PDD tag protection caused .format() to raise KeyError
    because single-braced JSON was interpreted as format placeholders.
    """
    import json

    prompt = '''<pdd-interface>
{
  "type": "module",
  "module": {
    "functions": [
      {"name": "fix_architecture", "signature": "(arch: str)", "returns": "str"}
    ]
  }
}
</pdd-interface>
% This is a template with {variable} placeholder.'''

    processed = preprocess(prompt, recursive=False, double_curly_brackets=True)

    # All braces should be doubled (including inside PDD tags)
    assert "{{variable}}" in processed, "Template variables should be doubled"
    assert '{{' in processed, "Braces inside PDD tags should also be doubled"
    # JSON opening brace is on its own line, so check for {{ at start of line
    assert '"type": "module"' not in processed or '{{' in processed, \
        "JSON braces inside PDD tags should be doubled"

    # After .format(**{}), the JSON should be valid again (undoubled back)
    # In production, llm_invoke calls prompt.format(**input_data) where input_data={}
    formatted = processed.format()
    import re
    interface_match = re.search(r'<pdd-interface>(.*?)</pdd-interface>', formatted, re.DOTALL)
    assert interface_match is not None
    parsed = json.loads(interface_match.group(1).strip())
    assert parsed['type'] == 'module'
    assert len(parsed['module']['functions']) == 1


def test_double_curly_doubles_pdd_reason_braces() -> None:
    """
    Test that braces in <pdd-reason> tags are doubled like all other braces.

    Issue #410: All braces must be doubled so .format() can undouble them.
    """
    prompt = '''<pdd-reason>Handles JSON objects like {"key": "value"}</pdd-reason>
Normal text with {placeholder}.'''

    processed = preprocess(prompt, recursive=False, double_curly_brackets=True)

    # All braces should be doubled
    import re
    reason_match = re.search(r'<pdd-reason>(.*?)</pdd-reason>', processed, re.DOTALL)
    assert reason_match is not None
    reason_content = reason_match.group(1)
    assert '{{' in reason_content, "Braces in <pdd-reason> should be doubled"

    assert "{{placeholder}}" in processed

    # After .format(), content is undoubled back to original
    formatted = processed.format()
    reason_match2 = re.search(r'<pdd-reason>(.*?)</pdd-reason>', formatted, re.DOTALL)
    assert '{"key": "value"}' in reason_match2.group(1)


def test_double_curly_doubles_pdd_dependency_content() -> None:
    """
    Test that <pdd-dependency> content is processed by double_curly().

    Dependencies typically contain filenames (no braces), so doubling
    has no visible effect, but the tag structure is preserved.
    """
    prompt = '''<pdd-dependency>some_module.prompt</pdd-dependency>
Text with {variable}.'''

    processed = preprocess(prompt, recursive=False, double_curly_brackets=True)

    # Dependency tag content has no braces, so it's unchanged
    assert '<pdd-dependency>some_module.prompt</pdd-dependency>' in processed

    # Variable outside should be doubled
    assert "{{variable}}" in processed


def test_double_curly_doubles_multiple_pdd_tags() -> None:
    """
    Test that all PDD tags have their braces doubled uniformly.

    Issue #410: All braces everywhere must be doubled for .format() safety.
    """
    prompt = '''<pdd-reason>Provides unified LLM invocation with {options}</pdd-reason>
<pdd-interface>
{
  "type": "module",
  "module": {"functions": [{"name": "invoke", "returns": "str"}]}
}
</pdd-interface>
<pdd-dependency>base_module.prompt</pdd-dependency>
% Template with {input} and {output} variables.'''

    processed = preprocess(prompt, recursive=False, double_curly_brackets=True)

    # All braces doubled
    import re
    reason_match = re.search(r'<pdd-reason>(.*?)</pdd-reason>', processed, re.DOTALL)
    assert reason_match is not None
    assert '{{options}}' in reason_match.group(1), "Braces in <pdd-reason> should be doubled"

    assert "{{input}}" in processed
    assert "{{output}}" in processed

    # After .format(), everything undoubles correctly
    formatted = processed.format()
    import json
    interface_match = re.search(r'<pdd-interface>(.*?)</pdd-interface>', formatted, re.DOTALL)
    assert interface_match is not None
    parsed = json.loads(interface_match.group(1).strip())
    assert parsed['type'] == 'module'


def test_double_curly_doubles_nested_json_in_pdd_interface() -> None:
    """
    Test that deeply nested JSON in <pdd-interface> is doubled and
    survives the .format() round-trip.

    Issue #410: Nested JSON structures must survive double_curly → .format().
    """
    import json

    nested_json = {
        "type": "module",
        "module": {
            "functions": [
                {
                    "name": "process",
                    "signature": "(data: Dict[str, Any])",
                    "returns": "Dict[str, List[Dict[str, str]]]"
                }
            ],
            "classes": [
                {
                    "name": "Handler",
                    "methods": [{"name": "handle", "args": "{}"}]
                }
            ]
        }
    }

    prompt = f'''<pdd-interface>
{json.dumps(nested_json, indent=2)}
</pdd-interface>
% Use this with {{already_escaped}} and {{variable}}.'''

    processed = preprocess(prompt, recursive=False, double_curly_brackets=True)

    # After .format(), nested JSON should be intact
    formatted = processed.format()
    import re
    interface_match = re.search(r'<pdd-interface>(.*?)</pdd-interface>', formatted, re.DOTALL)
    assert interface_match is not None
    parsed = json.loads(interface_match.group(1).strip())
    assert parsed == nested_json, "Nested JSON structure was altered after round-trip"


def test_double_curly_still_doubles_outside_pdd_tags() -> None:
    """
    Regression test: Ensure normal brace doubling still works outside PDD tags.

    double_curly() must escape all braces for safe use with .format().
    """
    prompt = '''<pdd-interface>{"valid": "json"}</pdd-interface>
Normal text with {variable1} and {variable2}.
Code example: const obj = {key: value};
Template literal ${FOO} should become ${{FOO}}.'''

    processed = preprocess(prompt, recursive=False, double_curly_brackets=True)

    # All braces doubled (including PDD tag content)
    assert '{{"valid": "json"}}' in processed, "PDD tag JSON braces should be doubled"

    # Variables outside should be doubled
    assert "{{variable1}}" in processed
    assert "{{variable2}}" in processed

    # Code braces outside PDD tags should be doubled
    assert "{{key: value}}" in processed

    # Template literals should become ${{...}}
    assert "${{FOO}}" in processed


def test_double_curly_integration_with_parse_prompt_tags() -> None:
    """
    Integration test: parse_prompt_tags() can handle preprocessed content
    via its fallback double-brace parser.

    In production, architecture_sync.py reads raw files. But the fallback
    parser (commit 6a1d77c4) can also handle doubled braces as a safety net.
    """
    from pdd.architecture_sync import parse_prompt_tags

    prompt = '''<pdd-reason>Handles authentication flows</pdd-reason>
<pdd-interface>
{
  "type": "module",
  "module": {
    "functions": [
      {"name": "authenticate", "signature": "(user: str, pass: str)", "returns": "bool"},
      {"name": "validate_token", "signature": "(token: str)", "returns": "Dict"}
    ]
  }
}
</pdd-interface>
<pdd-dependency>base_auth.prompt</pdd-dependency>
% Template with {user_input} placeholder.'''

    # parse_prompt_tags on RAW content (the production path)
    raw_result = parse_prompt_tags(prompt)
    assert raw_result['interface']['type'] == 'module'
    assert len(raw_result['interface']['module']['functions']) == 2

    # parse_prompt_tags on PREPROCESSED content (safety net via fallback parser)
    processed = preprocess(prompt, recursive=False, double_curly_brackets=True)
    processed_result = parse_prompt_tags(processed)
    assert processed_result['interface'] is not None, \
        f"Fallback parser should handle doubled braces: {processed_result.get('interface_parse_error')}"
    assert processed_result['interface']['type'] == 'module'

    # Verify dependencies were extracted in both cases
    assert 'base_auth.prompt' in raw_result.get('dependencies', [])


def test_double_curly_real_world_prompt_format_roundtrip() -> None:
    """
    Test with a real-world prompt: double_curly → .format() round-trip.

    Issue #410: This is the exact flow that was broken. The prompt has PDD
    metadata tags with JSON AND template variables. After preprocessing,
    .format(**input_data) must work without KeyError.
    """
    import json

    prompt = '''<pdd-reason>Fixes validation errors in architecture.json: resolves circular deps, priority violations, missing fields.</pdd-reason>
<pdd-interface>
{
  "type": "module",
  "module": {
    "functions": [
      {"name": "fix_architecture", "signature": "(current_architecture: str, step7_output: str)", "returns": "str (corrected JSON array)"}
    ]
  }
}
</pdd-interface>
<pdd-dependency>agentic_arch_step7_validate_LLM.prompt</pdd-dependency>
% You are an expert software architect. Your task is to fix validation errors.

% Inputs
- Issue URL: {issue_url}
- Repository: {repo_owner}/{repo_name}
- Issue Number: {issue_number}

% Current Architecture
<architecture_json>
{current_architecture}
</architecture_json>'''

    processed = preprocess(prompt, recursive=False, double_curly_brackets=True)

    # Template variables outside PDD tags SHOULD be doubled
    assert "{{issue_url}}" in processed
    assert "{{repo_owner}}" in processed
    assert "{{current_architecture}}" in processed

    # .format(**{}) should succeed (issue #410) — this is the production call
    # In production, llm_invoke calls prompt.format(**input_data) where
    # input_data is typically {} for pdd sync. All {{...}} get undoubled to {...}.
    formatted = processed.format()

    # After formatting, PDD tags should contain valid JSON (undoubled back)
    import re
    interface_match = re.search(r'<pdd-interface>(.*?)</pdd-interface>', formatted, re.DOTALL)
    assert interface_match is not None, "Lost <pdd-interface> tag"
    interface_json = json.loads(interface_match.group(1).strip())
    assert interface_json['type'] == 'module'
    assert interface_json['module']['functions'][0]['name'] == 'fix_architecture'

    # Template variables should be undoubled back to original single-brace form
    assert "{issue_url}" in formatted
    assert "{repo_owner}" in formatted
    assert "{current_architecture}" in formatted


# ============================================================================
# Issue #410: Preprocessed prompts with PDD tags must survive str.format()
# The double_curly() → .format() pipeline is how all prompts reach the LLM.
# PDD tags containing JSON must be doubled so .format() undoubles them safely.
# ============================================================================

def test_pdd_tags_survive_format() -> None:
    """
    Regression test for issue #410: pdd sync fails with KeyError when prompts
    contain <pdd-interface> tags with JSON.

    The preprocessing pipeline is:
      1. double_curly() doubles all { → {{
      2. llm_invoke calls prompt.format(**input_data) which undoubles {{ → {

    If PDD tag content is protected from doubling (step 1), .format() in step 2
    interprets the single braces as format placeholders and raises KeyError.
    """
    prompt = '''<pdd-reason>Defines the User data model with Firestore serialization.</pdd-reason>
<pdd-interface>
{
  "type": "module",
  "module": {
    "functions": [
      {"name": "User", "signature": "@dataclass class", "returns": "User"},
      {"name": "User.to_dict", "signature": "(self) -> Dict[str, Any]", "returns": "Dict[str, Any]"},
      {"name": "User.from_dict", "signature": "(cls, data: Dict[str, Any]) -> User", "returns": "User"}
    ]
  }
}
</pdd-interface>

You are an expert Python engineer. Write the User data model.'''

    processed = preprocess(prompt, recursive=False, double_curly_brackets=True)

    # This is the exact operation that llm_invoke.py:1238 performs.
    # It must not raise KeyError.
    try:
        formatted = processed.format()
    except KeyError as e:
        pytest.fail(
            f"Issue #410: preprocessed prompt with PDD tags failed .format(): {e}\n"
            f"This means double_curly() did not escape braces inside PDD tags.\n"
            f"Preprocessed content (first 500 chars):\n{processed[:500]}"
        )

    # After .format() undoubles {{ → {, the JSON should be valid
    assert '"type": "module"' in formatted
    assert '{"name": "User"' in formatted
    assert '<pdd-interface>' in formatted
    assert '</pdd-interface>' in formatted


# ============================================================================
# DETAILED TEST PLAN
# ============================================================================
# 1. Attribute Parsing (_parse_attrs):
#    - Unit test: Verify that `_parse_attrs` correctly extracts key-value pairs
#      from XML-like attribute strings, handling both single and double quotes.
# 2. Semantic Query Extraction (<include query="...">):
#    - Unit test: Mock `IncludeQueryExtractor` to verify that when the `query`
#      attribute is present, the extraction is delegated to the extractor and
#      bypasses standard file reading.
# 3. Content Selection (<include select="..." lines="...">):
#    - Unit test: Mock `ContentSelector` to verify that `select`, `lines`, and
#      `mode` attributes are correctly parsed and passed to the selector.
# 4. Self-Closing Include Tags (<include path="..." />):
#    - Unit test: Verify that self-closing tags are correctly matched and processed
#      using the `path` attribute.
# 5. Debug Report Generation (_write_debug_report):
#    - Unit test: Set `PDD_PREPROCESS_DEBUG` and `PDD_PREPROCESS_DEBUG_FILE` env
#      vars, run preprocess, and verify the debug file is written to disk.
#
# Note on Z3 Formal Verification:
# The core string manipulation properties (PDD tag removal, curly brace doubling,
# exclude keys) are already covered by Z3 tests in the existing suite. The new
# features being tested here (attribute parsing, delegating to external classes
# like ContentSelector/IncludeQueryExtractor) involve side-effects, mocking, and
# dictionary manipulations which are better suited for standard unit tests rather
# than symbolic execution.
# ============================================================================


def test_parse_attrs_internal() -> None:
    """Test the internal _parse_attrs function for correct attribute extraction."""
    from pdd.preprocess import _parse_attrs
    
    # Test empty string
    assert _parse_attrs("") == {}
    
    # Test double quotes
    assert _parse_attrs('path="file.txt" select="def:main"') == {'path': 'file.txt', 'select': 'def:main'}
    
    # Test single quotes
    assert _parse_attrs("path='file.txt' mode='interface'") == {'path': 'file.txt', 'mode': 'interface'}
    
    # Test mixed quotes and spacing
    assert _parse_attrs('  path="a.txt"   query=\'find stuff\' ') == {'path': 'a.txt', 'query': 'find stuff'}

def test_process_include_with_semantic_query(monkeypatch) -> None:
    """Test that <include query="..."> delegates to IncludeQueryExtractor."""
    prompt = '<include query="extract the main logic">source.py</include>'
    expected_output = "Extracted semantic content"
    
    # Create a mock extractor class
    class MockExtractor:
        def extract(self, file_path, query):
            assert query == "extract the main logic"
            assert "source.py" in file_path
            return expected_output
            
    # Mock the import of IncludeQueryExtractor
    mock_module = MagicMock()
    mock_module.IncludeQueryExtractor = MockExtractor
    monkeypatch.setitem(sys.modules, 'pdd.include_query_extractor', mock_module)
    
    # Mock get_file_path to just return the filename
    monkeypatch.setattr(sys.modules['pdd.preprocess'], 'get_file_path', lambda x: x)
    
    result = preprocess(prompt, recursive=False, double_curly_brackets=False)
    assert result == expected_output

def test_process_include_with_content_selector(monkeypatch) -> None:
    """Test that <include select="..." lines="..."> delegates to ContentSelector."""
    prompt = '<include select="def:main,class:App" lines="10-20" mode="interface">source.py</include>'
    mock_file_content = "Full file content"
    expected_output = "Selected content only"
    
    # Create a mock selector class
    class MockSelector:
        def select(self, content, selectors, file_path, mode):
            assert content == mock_file_content
            assert "def:main" in selectors
            assert "class:App" in selectors
            assert "lines:10-20" in selectors
            assert mode == "interface"
            return expected_output
            
    # Mock the import of ContentSelector
    mock_module = MagicMock()
    mock_module.ContentSelector = MockSelector
    monkeypatch.setitem(sys.modules, 'pdd.content_selector', mock_module)
    
    # Mock file reading
    monkeypatch.setattr('builtins.open', mock_open(read_data=mock_file_content))
    monkeypatch.setattr(sys.modules['pdd.preprocess'], 'get_file_path', lambda x: x)
    monkeypatch.setattr('os.path.realpath', lambda x: x)
    
    result = preprocess(prompt, recursive=False, double_curly_brackets=False)
    assert result == expected_output

def test_process_self_closing_include_tag(monkeypatch) -> None:
    """Test that self-closing <include path="..." /> tags are processed correctly."""
    prompt = 'Prefix <include path="target.txt" /> Suffix'
    mock_file_content = "Target Content"
    
    monkeypatch.setattr('builtins.open', mock_open(read_data=mock_file_content))
    monkeypatch.setattr(sys.modules['pdd.preprocess'], 'get_file_path', lambda x: x)
    monkeypatch.setattr('os.path.realpath', lambda x: x)
    
    result = preprocess(prompt, recursive=False, double_curly_brackets=False)
    assert result == f"Prefix {mock_file_content} Suffix"

def test_debug_report_generation(monkeypatch, tmp_path) -> None:
    """Test that setting debug environment variables generates a debug report file."""
    debug_file = tmp_path / "preprocess_debug.log"
    
    # Enable debug mode and set output file
    monkeypatch.setenv("PDD_PREPROCESS_DEBUG", "1")
    monkeypatch.setenv("PDD_PREPROCESS_DEBUG_FILE", str(debug_file))
    
    prompt = "Simple prompt with {var}"
    
    # Run preprocess
    preprocess(prompt, recursive=False, double_curly_brackets=True)
    
    # Verify the debug file was created and contains expected content
    assert debug_file.exists()
    content = debug_file.read_text(encoding="utf-8")
    assert "Preprocess Debug Report" in content
    assert "Start preprocess" in content
    assert "Initial length" in content
    assert "Final length" in content


# ===================================================================
# Tests for <include select="..." mode="..."> (ContentSelector)
# ===================================================================

def test_include_select_delegates_to_content_selector(tmp_path, monkeypatch) -> None:
    """<include select="def:foo"> should delegate to ContentSelector.select()."""
    monkeypatch.chdir(tmp_path)
    src = tmp_path / "module.py"
    src.write_text("def foo():\n    return 42\n\ndef bar():\n    return 99\n")

    prompt = '<include select="def:foo">module.py</include>'

    with patch('pdd.content_selector.ContentSelector') as MockCS:
        MockCS.return_value.select.return_value = "def foo():\n    return 42"
        result = preprocess(prompt, recursive=False, double_curly_brackets=False)

    MockCS.return_value.select.assert_called_once()
    call_kwargs = MockCS.return_value.select.call_args
    assert call_kwargs.kwargs['selectors'] == ['def:foo']
    assert call_kwargs.kwargs['mode'] == 'full'
    assert result == "def foo():\n    return 42"


def test_include_select_with_mode_interface(tmp_path, monkeypatch) -> None:
    """<include select="class:Foo" mode="interface"> should pass mode to ContentSelector."""
    monkeypatch.chdir(tmp_path)
    src = tmp_path / "module.py"
    src.write_text("class Foo:\n    def method(self): ...\n")

    prompt = '<include select="class:Foo" mode="interface">module.py</include>'

    with patch('pdd.content_selector.ContentSelector') as MockCS:
        MockCS.return_value.select.return_value = "class Foo:\n    def method(self): ..."
        result = preprocess(prompt, recursive=False, double_curly_brackets=False)

    call_kwargs = MockCS.return_value.select.call_args
    assert call_kwargs.kwargs['mode'] == 'interface'


def test_include_select_multiple_selectors(tmp_path, monkeypatch) -> None:
    """Comma-separated selectors should all be passed to ContentSelector."""
    monkeypatch.chdir(tmp_path)
    src = tmp_path / "module.py"
    src.write_text("def a(): ...\ndef b(): ...\n")

    prompt = '<include select="def:a,def:b">module.py</include>'

    with patch('pdd.content_selector.ContentSelector') as MockCS:
        MockCS.return_value.select.return_value = "def a(): ...\ndef b(): ..."
        result = preprocess(prompt, recursive=False, double_curly_brackets=False)

    call_kwargs = MockCS.return_value.select.call_args
    assert call_kwargs.kwargs['selectors'] == ['def:a', 'def:b']


def test_include_select_fallback_on_import_error(tmp_path, monkeypatch) -> None:
    """If ContentSelector can't be imported, fall back to full file content with a warning."""
    monkeypatch.chdir(tmp_path)
    src = tmp_path / "module.py"
    full_content = "def foo():\n    return 42\n"
    src.write_text(full_content)

    prompt = '<include select="def:foo">module.py</include>'

    with patch.dict('sys.modules', {'pdd.content_selector': None}):
        with pytest.warns(UserWarning, match="ContentSelector not importable.*def:foo.*module.py"):
            result = preprocess(prompt, recursive=False, double_curly_brackets=False)

    assert result == full_content


def test_include_select_fallback_on_selector_error(tmp_path, monkeypatch) -> None:
    """If ContentSelector raises, fall back to full file content with a warning."""
    monkeypatch.chdir(tmp_path)
    src = tmp_path / "module.py"
    full_content = "def foo():\n    return 42\n"
    src.write_text(full_content)

    prompt = '<include select="def:nonexistent">module.py</include>'

    with patch('pdd.content_selector.ContentSelector') as MockCS:
        MockCS.return_value.select.side_effect = ValueError("function 'nonexistent' not found")
        with pytest.warns(UserWarning, match="ContentSelector failed.*def:nonexistent.*module.py"):
            result = preprocess(prompt, recursive=False, double_curly_brackets=False)

    assert result == full_content


def test_include_select_inside_code_block_not_processed(tmp_path, monkeypatch) -> None:
    """<include select=...> inside a fenced code block should NOT be processed."""
    monkeypatch.chdir(tmp_path)
    src = tmp_path / "module.py"
    src.write_text("content")

    prompt = '```xml\n<include select="def:foo">module.py</include>\n```'

    with patch('pdd.content_selector.ContentSelector') as MockCS:
        result = preprocess(prompt, recursive=False, double_curly_brackets=False)

    MockCS.assert_not_called()
    assert result == prompt


# ===================================================================
# Tests for <include query="..."> (IncludeQueryExtractor)
# ===================================================================

def test_include_query_delegates_to_extractor(tmp_path, monkeypatch) -> None:
    """<include query="...">file</include> should delegate to IncludeQueryExtractor.extract()."""
    monkeypatch.chdir(tmp_path)
    src = tmp_path / "data.py"
    src.write_text("x = 1\n")

    prompt = '<include query="What does x do?">data.py</include>'

    with patch('pdd.include_query_extractor.IncludeQueryExtractor') as MockExt:
        MockExt.return_value.extract.return_value = "x is set to 1."
        result = preprocess(prompt, recursive=False, double_curly_brackets=False)

    MockExt.return_value.extract.assert_called_once()
    call_kwargs = MockExt.return_value.extract.call_args
    assert call_kwargs.kwargs['query'] == 'What does x do?'
    assert 'data.py' in call_kwargs.kwargs['file_path']
    assert result == "x is set to 1."


def test_include_query_deferred_when_recursive(tmp_path, monkeypatch) -> None:
    """When recursive=True, <include query=...> should be left intact (deferred)."""
    monkeypatch.chdir(tmp_path)
    src = tmp_path / "data.py"
    src.write_text("x = 1\n")

    prompt = '<include query="What does x do?">data.py</include>'

    with patch('pdd.include_query_extractor.IncludeQueryExtractor') as MockExt:
        result = preprocess(prompt, recursive=True, double_curly_brackets=False)

    MockExt.return_value.extract.assert_not_called()
    assert result == prompt


def test_include_query_executed_on_second_pass(tmp_path, monkeypatch) -> None:
    """Deferred query tag should execute on the non-recursive second pass."""
    monkeypatch.chdir(tmp_path)
    src = tmp_path / "data.py"
    src.write_text("x = 1\n")

    prompt = '<include query="What does x do?">data.py</include>'

    with patch('pdd.include_query_extractor.IncludeQueryExtractor') as MockExt:
        MockExt.return_value.extract.return_value = "x is set to 1."
        first = preprocess(prompt, recursive=True, double_curly_brackets=False)
        assert first == prompt
        second = preprocess(first, recursive=False, double_curly_brackets=False)

    assert second == "x is set to 1."
    MockExt.return_value.extract.assert_called_once()


def test_include_query_import_error_returns_error_message(tmp_path, monkeypatch) -> None:
    """If IncludeQueryExtractor can't be imported, return an error placeholder."""
    monkeypatch.chdir(tmp_path)
    src = tmp_path / "data.py"
    src.write_text("x = 1\n")

    prompt = '<include query="What is x?">data.py</include>'

    with patch.dict('sys.modules', {'pdd.include_query_extractor': None}):
        result = preprocess(prompt, recursive=False, double_curly_brackets=False)

    assert "Error" in result
    assert "include_query_extractor" in result


def test_include_query_extractor_exception_returns_error(tmp_path, monkeypatch) -> None:
    """If IncludeQueryExtractor.extract() raises, return an error placeholder."""
    monkeypatch.chdir(tmp_path)
    src = tmp_path / "data.py"
    src.write_text("x = 1\n")

    prompt = '<include query="What is x?">data.py</include>'

    with patch('pdd.include_query_extractor.IncludeQueryExtractor') as MockExt:
        MockExt.return_value.extract.side_effect = RuntimeError("LLM unavailable")
        result = preprocess(prompt, recursive=False, double_curly_brackets=False)

    assert "Error" in result
    assert "LLM unavailable" in result


def test_include_query_inside_code_block_not_processed(tmp_path, monkeypatch) -> None:
    """<include query=...> inside a fenced code block should NOT be processed."""
    monkeypatch.chdir(tmp_path)
    src = tmp_path / "data.py"
    src.write_text("x = 1\n")

    prompt = '```xml\n<include query="What is x?">data.py</include>\n```'

    with patch('pdd.include_query_extractor.IncludeQueryExtractor') as MockExt:
        result = preprocess(prompt, recursive=False, double_curly_brackets=False)

    MockExt.assert_not_called()
    assert result == prompt


# ===================================================================
# Tests for processing order (pdd → include → include-many → shell → web)
# ===================================================================

def test_pdd_tags_processed_before_includes(tmp_path, monkeypatch) -> None:
    """PDD tags should be stripped before include tags are resolved."""
    monkeypatch.chdir(tmp_path)
    src = tmp_path / "file.txt"
    src.write_text("included content")

    # The pdd tag wraps an include — the include should NOT be processed
    prompt = "<pdd><include>file.txt</include></pdd>After"
    result = preprocess(prompt, recursive=False, double_curly_brackets=False)
    assert result == "After"


def test_includes_processed_before_shell(tmp_path, monkeypatch) -> None:
    """Include tags are resolved before shell tags execute."""
    monkeypatch.chdir(tmp_path)
    src = tmp_path / "cmd.txt"
    src.write_text("echo included")

    prompt = "<shell><include>cmd.txt</include></shell>"
    with patch('subprocess.run') as mock_run:
        mock_run.return_value.stdout = "included\n"
        result = preprocess(prompt, recursive=False, double_curly_brackets=False)

    # The include should resolve first, then shell should execute the result
    # (Though shell sees "echo included" as the command after include resolves)
    mock_run.assert_called_once()
    assert "included" in result


# =============================================================================
# Issue #1261: Exception handlers missing recursive guard
#
# The FileNotFoundError handler in process_include_tags correctly preserves
# original text when recursive=True (return match.group(0)), but the ValueError
# (non-circular) and generic Exception handlers unconditionally replace the
# matched span with "[Error processing include: ...]" error markers — even
# during the recursive pass where unresolved tags should be left intact.
# The same bug exists in process_backtick_includes.
# =============================================================================


def test_xml_include_oserror_recursive_preserves_tag() -> None:
    """OSError during recursive pass should preserve the original XML include tag.

    This is the primary bug from issue #1261: when a bare <include> in prose
    causes the regex to capture >255 bytes as a 'filename', open() raises
    OSError('File name too long'). The generic Exception handler (line 427-430)
    unconditionally replaces the match with an error marker instead of
    preserving the original text like the FileNotFoundError handler does.
    """
    prompt = "<include>somefile.txt</include>"
    with patch('builtins.open', side_effect=OSError(36, "File name too long")):
        result = preprocess(prompt, recursive=True, double_curly_brackets=False)
    # BUG: returns "[Error processing include: somefile.txt]"
    # FIX: should return original text when recursive=True
    assert result == prompt


# Scope addition: covers expansion item "process_include_tags ValueError
# non-circular handler (line 426) missing recursive guard" identified by Step 6
def test_xml_include_valueerror_non_circular_recursive_preserves_tag() -> None:
    """Non-circular ValueError during recursive pass should preserve the original XML include tag.

    The ValueError handler at line 421-426 re-raises circular-include errors but
    unconditionally returns an error marker for all other ValueErrors, even when
    recursive=True. It should preserve the original tag like FileNotFoundError does.
    """
    prompt = "<include>somefile.txt</include>"
    with patch('pdd.preprocess.get_file_path', side_effect=ValueError("Invalid path encoding")):
        result = preprocess(prompt, recursive=True, double_curly_brackets=False)
    # BUG: returns "[Error processing include: somefile.txt]"
    # FIX: should return original text when recursive=True
    assert result == prompt


# Scope addition: covers expansion item "process_backtick_includes Exception
# handler (line 216) missing recursive guard" identified by Step 6
def test_backtick_include_oserror_recursive_preserves_tag() -> None:
    """OSError during recursive pass should preserve the original backtick include tag.

    The generic Exception handler in process_backtick_includes (line 213-216)
    unconditionally returns an error marker instead of preserving the original
    text when recursive=True.
    """
    prompt = "```<somefile.txt>```"
    with patch('builtins.open', side_effect=OSError(36, "File name too long")):
        result = preprocess(prompt, recursive=True, double_curly_brackets=False)
    # BUG: returns "```[Error processing include: somefile.txt]```"
    # FIX: should return original text when recursive=True
    assert result == prompt


# Scope addition: covers expansion item "process_backtick_includes ValueError
# non-circular handler (line 212) missing recursive guard" identified by Step 6
def test_backtick_include_valueerror_non_circular_recursive_preserves_tag() -> None:
    """Non-circular ValueError during recursive pass should preserve the original backtick include tag.

    The ValueError handler in process_backtick_includes (line 207-212) re-raises
    circular-include errors but unconditionally returns an error marker for all
    other ValueErrors, even when recursive=True.
    """
    prompt = "```<somefile.txt>```"
    with patch('pdd.preprocess.get_file_path', side_effect=ValueError("Invalid path encoding")):
        result = preprocess(prompt, recursive=True, double_curly_brackets=False)
    # BUG: returns "```[Error processing include: somefile.txt]```"
    # FIX: should return original text when recursive=True
    assert result == prompt


def test_bare_include_in_prose_over_255_bytes_preserves_content(tmp_path, monkeypatch) -> None:
    """Realistic reproduction: bare <include> in prose with >255 bytes to next </include>.

    This is the exact scenario from issue #1261. A prompt mentions <include> in
    prose text (without backtick escaping). The preprocessing regex captures the
    text between the bare <include> and the next real </include> as a 'filename'.
    When that text exceeds 255 bytes, open() raises OSError('File name too long'),
    and the generic Exception handler destructively replaces the entire matched
    span with an error marker — eating all the requirement text in between.
    """
    monkeypatch.chdir(tmp_path)
    padding = "A" * 300
    # The regex will match from <include> to </include>, capturing the 300+ byte
    # "filename" (the prose text + padding). open() raises OSError for the
    # overlong filename component.
    prompt = f"The system parses <include> tags from files {padding}</include> and more text."
    result = preprocess(prompt, recursive=True, double_curly_brackets=False)
    # BUG: the error marker replaces the entire matched span, eating the padding
    # FIX: recursive=True should preserve the original text
    assert "[Error processing include:" not in result
    assert padding in result


def test_two_pass_xml_include_oserror_preserves_content(tmp_path, monkeypatch) -> None:
    """Two-pass pipeline: bare <include> in prose survives both passes.

    Exercises the real code_generator_main.py flow: pass 1 (recursive=True)
    then pass 2 (recursive=False). Both passes must preserve the original text
    when the regex false-matches prose as a filename.
    """
    monkeypatch.chdir(tmp_path)
    padding = "A" * 300
    prompt = f"The system parses <include> tags from files {padding}</include> and more text."
    pass1 = preprocess(prompt, recursive=True, double_curly_brackets=False)
    pass2 = preprocess(pass1, recursive=False, double_curly_brackets=False)
    assert "[Error processing include:" not in pass2
    assert padding in pass2
    assert "and more text." in pass2


def test_two_pass_backtick_include_oserror_preserves_content(tmp_path, monkeypatch) -> None:
    """Two-pass pipeline: backtick-escaped prose survives both passes."""
    monkeypatch.chdir(tmp_path)
    padding = "B" * 300
    prompt = f"Use regex `r'<include>(.*?)</include>'` to parse {padding} from files."
    pass1 = preprocess(prompt, recursive=True, double_curly_brackets=False)
    pass2 = preprocess(pass1, recursive=False, double_curly_brackets=False)
    assert "[Error processing include:" not in pass2
    assert padding in pass2


# ---------------------------------------------------------------------------
# Issue #616 — unresolved-include surfacing (loud-failure)
# ---------------------------------------------------------------------------


def test_unresolved_include_warning_surfaced(tmp_path, monkeypatch, capsys) -> None:
    """Final non-recursive pass: [File not found:] placeholders trigger a loud
    warning naming each unresolved path."""
    monkeypatch.chdir(tmp_path)
    out = preprocess(
        "<x><include>context/missing_example.py</include></x>",
        recursive=False, double_curly_brackets=False,
    )
    assert "[File not found: context/missing_example.py]" in out
    captured = capsys.readouterr().out
    assert "Unresolved include" in captured
    assert "context/missing_example.py" in captured
    assert "example_output_path" in captured


def _normalize(s: str) -> str:
    """Collapse whitespace — Rich console may wrap long lines mid-word."""
    return " ".join(s.split())


def test_unresolved_include_warning_includes_actionable_alt_location(tmp_path, monkeypatch, capsys) -> None:
    """When the missing file's first component is context/examples and the swap
    location has the file, the warning names that alternative path."""
    monkeypatch.chdir(tmp_path)
    (tmp_path / "examples" / "prisma").mkdir(parents=True)
    (tmp_path / "examples" / "prisma" / "schema_example.prisma").write_text("// here\n")
    preprocess(
        "<x><include>context/prisma/schema_example.prisma</include></x>",
        recursive=False, double_curly_brackets=False,
    )
    captured = _normalize(capsys.readouterr().out)
    assert "Unresolved include" in captured
    assert "Found at:" in captured
    assert "examples/prisma/schema_example.prisma" in captured


def test_unresolved_include_actionable_inverse(tmp_path, monkeypatch, capsys) -> None:
    """Inverse: <include>examples/...</include> missing, file under context/."""
    monkeypatch.chdir(tmp_path)
    (tmp_path / "context" / "shared").mkdir(parents=True)
    (tmp_path / "context" / "shared" / "thing.py").write_text("# here\n")
    preprocess(
        "<x><include>examples/shared/thing.py</include></x>",
        recursive=False, double_curly_brackets=False,
    )
    captured = _normalize(capsys.readouterr().out)
    assert "Found at:" in captured
    assert "context/shared/thing.py" in captured


def test_unresolved_include_warning_not_emitted_when_resolved(tmp_path, monkeypatch, capsys) -> None:
    """When the include file exists, no unresolved-include warning fires."""
    monkeypatch.chdir(tmp_path)
    (tmp_path / "examples").mkdir()
    (tmp_path / "examples" / "real.py").write_text("# real\n")
    out = preprocess(
        "<x><include>examples/real.py</include></x>",
        recursive=False, double_curly_brackets=False,
    )
    assert "[File not found:" not in out
    assert "Unresolved include" not in capsys.readouterr().out


def test_unresolved_include_warning_silenced_in_quiet_mode(tmp_path, monkeypatch, capsys) -> None:
    """PDD_QUIET=1 suppresses the unresolved-include console warning."""
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("PDD_QUIET", "1")
    preprocess(
        "<x><include>context/missing.py</include></x>",
        recursive=False, double_curly_brackets=False,
    )
    assert "Unresolved include" not in capsys.readouterr().out


def test_unresolved_include_no_warning_on_recursive_pass(tmp_path, monkeypatch, capsys) -> None:
    """Recursive passes must not warn — placeholders may resolve later."""
    monkeypatch.chdir(tmp_path)
    preprocess(
        "<x><include>context/missing.py</include></x>",
        recursive=True, double_curly_brackets=False,
    )
    assert "Unresolved include" not in capsys.readouterr().out


def test_unresolved_include_warning_emits_via_logger(tmp_path, monkeypatch, caplog) -> None:
    """The unresolved-include warning must also reach the standard logger so
    callers that capture logs (CI, log-aggregation pipelines) see the signal,
    not just Rich console output (#616)."""
    import logging
    monkeypatch.chdir(tmp_path)
    with caplog.at_level(logging.WARNING, logger="pdd.preprocess"):
        preprocess(
            "<x><include>context/missing_example.py</include></x>",
            recursive=False, double_curly_brackets=False,
        )
    matches = [r for r in caplog.records if "Unresolved include" in r.getMessage()]
    assert matches, "expected logger.warning for unresolved include"
    assert matches[0].levelno == logging.WARNING
    assert "context/missing_example.py" in matches[0].getMessage()


def test_unresolved_include_warning_logger_fires_in_quiet_mode(tmp_path, monkeypatch, caplog, capsys) -> None:
    """PDD_QUIET=1 silences Rich console output but the logger warning still
    fires — quiet mode is for terminal noise, not for hiding signals from
    log capture."""
    import logging
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("PDD_QUIET", "1")
    with caplog.at_level(logging.WARNING, logger="pdd.preprocess"):
        preprocess(
            "<x><include>context/missing.py</include></x>",
            recursive=False, double_curly_brackets=False,
        )
    assert "Unresolved include" not in capsys.readouterr().out
    assert any("Unresolved include" in r.getMessage() for r in caplog.records)


def test_unresolved_include_warning_no_false_positive_on_documentation(tmp_path, monkeypatch, caplog, capsys) -> None:
    """The unresolved-include warning must NOT fire when the literal text
    `[File not found: ...]` appears in documentation, prompt specs, or other
    non-include content. Greg's #1354 review repro: running preprocess on
    `pdd/prompts/preprocess_python.prompt` (which documents the warning's
    behavior using `[File not found: path]` and `[File not found: ...]` as
    illustrative examples) used to emit false-positive warnings for `path`
    and `...`. The fix tracks include-processor failures directly rather
    than regex-scanning the final prompt."""
    import logging
    monkeypatch.chdir(tmp_path)
    # A prompt that documents the warning marker as content, with no actual
    # failing <include>/<include-many> tags. This must NOT trip the warning.
    doc_prompt = (
        "Documentation example:\n"
        "When an include fails, preprocess emits a placeholder like\n"
        "`[File not found: path]` or `[File not found: ...]` for missing files.\n"
        "End of doc.\n"
    )
    with caplog.at_level(logging.WARNING, logger="pdd.preprocess"):
        out = preprocess(doc_prompt, recursive=False, double_curly_brackets=False)
    captured = capsys.readouterr().out
    assert "Unresolved include" not in captured, (
        f"False-positive warning fired on documentation content. Output:\n{captured}"
    )
    assert not any("Unresolved include" in r.getMessage() for r in caplog.records), (
        "False-positive warning logged on documentation content."
    )
    # The documentation text must pass through unchanged (no mutation).
    assert "[File not found: path]" in out
    assert "[File not found: ...]" in out


def test_unresolved_include_warning_no_false_positive_on_real_prompt_spec(tmp_path, monkeypatch, capsys) -> None:
    """End-to-end repro of Greg's #1354 review: preprocess the actual
    preprocess_python.prompt spec — which contains documented `[File not
    found: ...]` examples in its Error Handling section — and assert no
    Unresolved-include warnings fire on its non-include content."""
    monkeypatch.chdir(tmp_path)
    from pathlib import Path as _P
    spec_path = _P(__file__).resolve().parent.parent / "pdd" / "prompts" / "preprocess_python.prompt"
    if not spec_path.exists():
        import pytest
        pytest.skip(f"spec not present at {spec_path}")
    text = spec_path.read_text(encoding="utf-8")
    preprocess(text, recursive=False, double_curly_brackets=False)
    captured = capsys.readouterr().out
    # The spec genuinely <include>s context/python_preamble.prompt etc; those
    # may fail when run from tmp_path. We assert specifically that the
    # documented placeholder examples (`path`, `...`) do NOT generate warnings.
    for fake in ("Unresolved include in preprocessed prompt: path.",
                 "Unresolved include in preprocessed prompt: ...."):
        assert fake not in captured, (
            f"False-positive warning fired for documented example '{fake}'. "
            f"Output:\n{captured}"
        )


def test_split_prompt_include_selectors_resolve_without_fallback(monkeypatch, capsys, recwarn) -> None:
    """The split prompt's selected includes must resolve cleanly.

    Regression for Greg's #1354 review: `split_python.prompt` selected
    `def:preprocess` from `context/preprocess_example.py`, which only defines
    `main()`. The failed selector fell back to full-file inclusion and caused
    literal example `<include>` / `<shell>` tags in that source to be processed.
    """
    from pathlib import Path as _P

    repo_root = _P(__file__).resolve().parent.parent
    monkeypatch.chdir(repo_root)
    text = (repo_root / "pdd" / "prompts" / "split_python.prompt").read_text(
        encoding="utf-8"
    )
    preprocess(text, recursive=False, double_curly_brackets=False)
    captured = capsys.readouterr().out
    selector_warnings = [
        warning for warning in recwarn if "ContentSelector failed" in str(warning.message)
    ]
    assert selector_warnings == []
    assert "ContentSelector failed" not in captured
    assert "Executing shell command" not in captured


def test_prompt_files_do_not_select_implementation_symbols_from_example_files() -> None:
    """Symbol selectors must target files that actually define the symbol.

    The original `forbidden_selectors` list pinned the case from Greg's #1354
    review where prompts selected symbols not present in the example files.
    A selector is only forbidden as long as the named example file does not
    define a matching top-level `def`/`class`. We resolve each tuple at test
    time so adding a real `def preprocess(...)` wrapper to
    `context/preprocess_example.py` (Issue #814 codex iter-7 fix) lifts the
    ban automatically — selectors that DO resolve are not regressions.
    """
    from pathlib import Path as _P
    import ast as _ast

    repo_root = _P(__file__).resolve().parent.parent

    candidate_selectors = (
        ("def:preprocess", "context/preprocess_example.py", "preprocess", "def"),
        ("def:llm_invoke", "context/llm_invoke_example.py", "llm_invoke", "def"),
        (
            "class:ContentSelector",
            "context/content_selector_example.py",
            "ContentSelector",
            "class",
        ),
        (
            "class:IncludeQueryExtractor",
            "context/include_query_extractor_example.py",
            "IncludeQueryExtractor",
            "class",
        ),
    )

    def _has_top_level_symbol(file_path: _P, name: str, kind: str) -> bool:
        try:
            tree = _ast.parse(file_path.read_text(encoding="utf-8"))
        except (FileNotFoundError, SyntaxError):
            return False
        node_type = _ast.FunctionDef if kind == "def" else _ast.ClassDef
        return any(
            isinstance(node, node_type) and node.name == name
            for node in tree.body
        )

    forbidden_selectors = tuple(
        f'<include select="{selector}">{example_rel}'
        for selector, example_rel, name, kind in candidate_selectors
        if not _has_top_level_symbol(repo_root / example_rel, name, kind)
    )

    offenders = [
        str(path.relative_to(repo_root))
        for path in (repo_root / "pdd" / "prompts").glob("*.prompt")
        if any(
            forbidden in path.read_text(encoding="utf-8")
            for forbidden in forbidden_selectors
        )
    ]

    assert offenders == []


def test_changed_prompt_selected_includes_resolve() -> None:
    """Selected includes in touched prompt specs must not fall back to full files."""
    from pathlib import Path as _P

    from pdd.content_selector import ContentSelector

    repo_root = _P(__file__).resolve().parent.parent
    prompt_paths = [
        "pdd/prompts/agentic_change_orchestrator_python.prompt",
        "pdd/prompts/agentic_common_python.prompt",
        "pdd/prompts/agentic_split_orchestrator_python.prompt",
        "pdd/prompts/change_python.prompt",
        "pdd/prompts/code_generator_main_python.prompt",
        "pdd/prompts/commands/which_python.prompt",
        "pdd/prompts/construct_paths_python.prompt",
        "pdd/prompts/context_generator_main_python.prompt",
        "pdd/prompts/detect_change_python.prompt",
        "pdd/prompts/fix_errors_from_unit_tests_python.prompt",
        "pdd/prompts/generate_output_paths_python.prompt",
        "pdd/prompts/generate_test_python.prompt",
        "pdd/prompts/include_query_extractor_python.prompt",
        "pdd/prompts/insert_includes_python.prompt",
        "pdd/prompts/main_gen_prompt.prompt",
        "pdd/prompts/one_session_sync_python.prompt",
        "pdd/prompts/preprocess_main_python.prompt",
        "pdd/prompts/preprocess_python.prompt",
        "pdd/prompts/split_python.prompt",
        "pdd/prompts/sync_determine_operation_python.prompt",
        "pdd/prompts/trace_python.prompt",
        "pdd/prompts/update_prompt_python.prompt",
    ]
    include_pattern = re.compile(r'<include\s+([^>]*)>(.*?)</include>', re.DOTALL)
    select_pattern = re.compile(r'select="([^"]+)"')
    failures: list[str] = []

    for prompt_rel in prompt_paths:
        prompt_text = (repo_root / prompt_rel).read_text(encoding="utf-8")
        for match in include_pattern.finditer(prompt_text):
            select_match = select_pattern.search(match.group(1))
            if select_match is None:
                continue
            include_target = match.group(2).strip()
            if include_target in {"file", "..."} or "{" in include_target:
                continue
            include_path = (repo_root / include_target).resolve()
            selectors = [
                selector.strip()
                for selector in select_match.group(1).split(",")
                if selector.strip()
            ]
            try:
                include_text = include_path.read_text(encoding="utf-8")
                ContentSelector.select(
                    include_text,
                    selectors,
                    file_path=str(include_path),
                )
            except Exception as exc:  # noqa: BLE001 - report all selector failures together
                failures.append(
                    f"{prompt_rel}: {include_target} select={selectors!r}: {exc}"
                )

    assert failures == []


def test_unresolved_include_warning_still_fires_on_real_failure(tmp_path, monkeypatch, capsys) -> None:
    """Sanity check that direct-failure tracking didn't break the positive
    case: the warning MUST still fire when an include genuinely fails."""
    monkeypatch.chdir(tmp_path)
    preprocess(
        "<x><include>context/genuinely_missing_example.py</include></x>",
        recursive=False, double_curly_brackets=False,
    )
    captured = capsys.readouterr().out
    assert "Unresolved include" in captured
    assert "context/genuinely_missing_example.py" in captured


def test_unresolved_include_no_false_positive_on_included_source_with_literal_tags(
    tmp_path, monkeypatch, capsys
) -> None:
    """Regression for #1354 codex pass-2: when an include resolves to a Python
    source file that contains literal `<include>` syntax in docstrings, regex
    patterns, or comments, those nested matches must NOT be reported as
    unresolved-include failures. Only user-intent includes from the original
    prompt should trigger warnings.
    """
    monkeypatch.chdir(tmp_path)
    src = tmp_path / "decoy.py"
    src.write_text(
        '"""Module docstring referencing literal <include>some/path.py</include>.\n'
        "Pattern: r'<include(?P<attrs>\\\\s+[^>]*?)?>(?P<content>.*?)</include>'\n"
        "Backtick: ```<another/path.py>``` and <include-many>blob</include-many>.\n"
        '"""\n'
        "x = 1\n"
    )
    preprocess(
        f"<wrap><include>{src.name}</include></wrap>",
        recursive=False, double_curly_brackets=False,
    )
    captured_out = capsys.readouterr().out
    assert "Unresolved include" not in captured_out
    assert "File not found: some/path.py" not in captured_out
    assert "File not found: another/path.py" not in captured_out
    assert "File not found: blob" not in captured_out


def test_optional_include_missing_file_is_silent(tmp_path, monkeypatch, capsys) -> None:
    """Regression for #1354 codex pass-2: <include optional="true"> with a
    missing path must NOT print a `File not found` console warning, must NOT
    leak a `[File not found: ...]` marker into the output, and must NOT
    surface as an unresolved-include warning.
    """
    monkeypatch.chdir(tmp_path)
    out = preprocess(
        '<wrap><include optional="true">${UNSET_OPTIONAL_FILE}</include></wrap>',
        recursive=False, double_curly_brackets=False,
    )
    captured = capsys.readouterr().out
    assert "File not found" not in captured
    assert "Unresolved include" not in captured
    assert "[File not found:" not in out


def test_optional_include_many_missing_files_are_silent(tmp_path, monkeypatch, capsys) -> None:
    """Regression for #1354 codex pass-2: <include-many optional="true"> with
    paths that don't resolve (e.g. an unset ${VAR} placeholder) must be silent
    and must not leak `[File not found: ...]` markers.
    """
    monkeypatch.chdir(tmp_path)
    out = preprocess(
        '<wrap><include-many optional="true">${UNSET_LIST}</include-many></wrap>',
        recursive=False, double_curly_brackets=False,
    )
    captured = capsys.readouterr().out
    assert "File not found" not in captured
    assert "Unresolved include" not in captured
    assert "[File not found:" not in out


def test_required_include_missing_still_warns(tmp_path, monkeypatch, capsys) -> None:
    """Sanity: removing the optional flag must still produce a real
    File-not-found warning so users notice required-but-missing includes."""
    monkeypatch.chdir(tmp_path)
    preprocess(
        '<wrap><include>required_but_missing.txt</include></wrap>',
        recursive=False, double_curly_brackets=False,
    )
    captured = capsys.readouterr().out
    assert "File not found: required_but_missing.txt" in captured


def test_unresolved_include_no_false_positive_in_two_pass_production_flow(
    tmp_path, monkeypatch, capsys, caplog
) -> None:
    """Regression for #1354 codex pass-3: production callers (e.g.
    `code_generator_main`) preprocess in two passes — `recursive=True`,
    then variable expansion, then `recursive=False`. When pass 1 expands
    a raw `.py` source whose docstrings or regex strings contain literal
    `<include>` syntax, pass 2 sees those as iteration-0 matches in its
    own input. The path-shape heuristic must keep the warning silent for
    those parser artifacts.
    """
    monkeypatch.chdir(tmp_path)
    decoy = tmp_path / "decoy_source.py"
    decoy.write_text(
        '"""Module that documents include syntax in its docstring.\n'
        "Pattern: r'<include(?P<attrs>\\\\s+[^>]*?)?>(?P<content>.*?)</include>'\n"
        "Examples:\n"
        "    <include>some/example.py</include>\n"
        "    <include path=\"explicit/path.py\" />\n"
        "    <include-many>list, of, things</include-many>\n"
        '"""\n'
        "x = 1\n"
    )
    original_prompt = f"<wrap><include>{decoy.name}</include></wrap>"

    from pdd.preprocess import compute_user_intent_paths
    intent = compute_user_intent_paths(original_prompt)
    pass1 = preprocess(original_prompt, recursive=True, double_curly_brackets=False)
    # No env var expansion needed — the decoy include resolved fully on pass 1.
    pass2 = preprocess(pass1, recursive=False, double_curly_brackets=True, _user_intent_paths=intent)

    captured_out = capsys.readouterr().out
    # No false positives from the decoy's docstring contents.
    for fragment in (
        "some/example.py",
        "explicit/path.py",
        "list",
        "of",
        "things",
    ):
        assert f"File not found: {fragment}" not in captured_out, (
            f"unexpected warning for parser-artifact '{fragment}' in two-pass output"
        )
    assert "Unresolved include in preprocessed prompt" not in captured_out, (
        "unresolved-include warning leaked from expanded source"
    )
    # logger.warning path also clean.
    assert not any(
        rec.levelname == "WARNING" and "Unresolved include" in rec.message
        for rec in caplog.records
    )
    # Sanity: the decoy contents made it through (proves we processed, not skipped).
    assert "x = 1" in pass2


def test_compute_user_intent_paths_handles_path_attribute_and_self_closing(
    tmp_path,
) -> None:
    """Regression for #1354 codex pass-4 finding 1: `compute_user_intent_paths`
    must walk the same `<include>` grammar that `process_include_tags` accepts —
    body form, body form with `path=`, and self-closing `<include path="..." />`.
    Otherwise pass-2 silently swallows real failures of `path=`-style includes
    because the user-intent set is empty.
    """
    from pdd.preprocess import compute_user_intent_paths
    text = (
        '<a><include>body_only.py</include></a>\n'
        '<b><include path="attr_with_body.py">ignored</include></b>\n'
        '<c><include path="self_closing.py" /></c>\n'
        '<d><include-many>list_a.py, list_b.py</include-many></d>\n'
        '<e>```<backtick.py>```</e>\n'
    )
    paths = compute_user_intent_paths(text)
    assert paths == {
        "body_only.py",
        "attr_with_body.py",
        "self_closing.py",
        "list_a.py",
        "list_b.py",
        "backtick.py",
    }


def test_path_attribute_missing_file_warns_in_two_pass_flow(
    tmp_path, monkeypatch, capsys
) -> None:
    """Regression for #1354 codex pass-4 finding 1: a real missing
    `<include path="..." />` in user-authored prompt content must still
    produce a `File not found` warning when the caller supplies an intent
    set computed via `compute_user_intent_paths()`.
    """
    from pdd.preprocess import compute_user_intent_paths
    monkeypatch.chdir(tmp_path)
    original = '<wrap><include path="user_authored_missing.py" /></wrap>'
    intent = compute_user_intent_paths(original)
    assert "user_authored_missing.py" in intent, (
        "compute_user_intent_paths must extract path= attribute"
    )
    pass1 = preprocess(original, recursive=True, double_curly_brackets=False)
    pass2 = preprocess(
        pass1, recursive=False, double_curly_brackets=False, _user_intent_paths=intent
    )
    captured = capsys.readouterr().out
    assert "File not found: user_authored_missing.py" in captured
    assert "[File not found: user_authored_missing.py]" in pass2


def test_extensionless_required_include_warns_with_intent_set(
    tmp_path, monkeypatch, capsys
) -> None:
    """Regression for #1354 codex pass-4 finding 2: when the caller supplies
    an authoritative `_user_intent_paths` set, extensionless filenames like
    `Makefile`, `Dockerfile`, `LICENSE` must still fail loudly when the user
    authored them and they're missing. The path-shape heuristic must NOT
    layer on top of the caller-supplied set.
    """
    from pdd.preprocess import compute_user_intent_paths
    # Use clearly synthetic extensionless names that don't exist in the repo or
    # any well-known location. Real names like `Makefile` collide with files in
    # the package/repo root that PathResolver finds.
    monkeypatch.chdir(tmp_path)
    for bare in (
        "DefinitelyMissingMakefile",
        "BogusDockerfile",
        "NonexistentLICENSE",
    ):
        original = f'<wrap><include>{bare}</include></wrap>'
        intent = compute_user_intent_paths(original)
        assert bare in intent, (
            f"compute_user_intent_paths must extract bare name {bare!r}"
        )
        out = preprocess(
            original,
            recursive=False,
            double_curly_brackets=False,
            _user_intent_paths=intent,
        )
        captured = capsys.readouterr().out
        assert f"File not found: {bare}" in captured, (
            f"required missing extensionless include {bare!r} must warn loudly "
            f"when caller supplied an authoritative intent set"
        )
        assert f"[File not found: {bare}]" in out


def test_looks_like_user_intent_path_heuristic() -> None:
    """Direct unit-test of the heuristic that gates warning emission for
    parser-artifact include matches.
    """
    from pdd.preprocess import _looks_like_user_intent_path as f
    # Real paths
    assert f("context/foo_example.py")
    assert f("README.md")
    assert f("pdd/preprocess.py")
    assert f("${PRD_FILE}")
    assert f("./relative/path.txt")
    # Parser artifacts that have appeared in real false-positive reports
    assert not f("path")  # bare word, no path-y characters
    assert not f("blob")
    assert not f("path set from the original prompt")  # has spaces
    assert not f("# comment line that mentions <include>x</include>")  # starts with #
    assert not f("in a docstring).")  # has space
    assert not f("")
    assert not f("\n")
    assert not f("a" * 300)  # too long
