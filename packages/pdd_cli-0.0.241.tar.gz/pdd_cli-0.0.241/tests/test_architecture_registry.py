"""Tests for pdd.architecture_registry module."""

import json
import sys
from pathlib import Path

# Add project root to sys.path
project_root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(project_root))

import pytest

from pdd.architecture_registry import (
    find_architecture_for_project,
    find_git_toplevel,
    find_project_root,
    get_modules_for_issue,
    load_registry,
    merge_architecture,
    record_generation,
    save_registry,
)


# --- Merge Tests ---


def test_merge_no_overlap():
    """Disjoint modules merge correctly — all new modules are added."""
    existing = [
        {"filename": "auth_Python.prompt", "priority": 1, "dependencies": []},
    ]
    new = [
        {"filename": "billing_Python.prompt", "priority": 1, "dependencies": []},
    ]

    merged, report = merge_architecture(existing, new, issue_number=42, issue_url="https://github.com/o/r/issues/42")

    assert len(merged) == 2
    filenames = {m["filename"] for m in merged}
    assert filenames == {"auth_Python.prompt", "billing_Python.prompt"}
    assert report["added"] == ["billing_Python.prompt"]
    assert report["updated"] == []
    assert report["unchanged"] == ["auth_Python.prompt"]

    # New module should have origin
    billing = [m for m in merged if m["filename"] == "billing_Python.prompt"][0]
    assert billing["origin"]["issue_number"] == 42

    # Existing module should NOT have origin added
    auth = [m for m in merged if m["filename"] == "auth_Python.prompt"][0]
    assert "origin" not in auth


def test_merge_with_overlap():
    """Overlapping modules update, not duplicate."""
    existing = [
        {"filename": "auth_Python.prompt", "priority": 1, "dependencies": [], "description": "old"},
        {"filename": "db_Python.prompt", "priority": 2, "dependencies": ["auth_Python.prompt"]},
    ]
    new = [
        {"filename": "auth_Python.prompt", "priority": 1, "dependencies": [], "description": "updated"},
        {"filename": "billing_Python.prompt", "priority": 2, "dependencies": ["auth_Python.prompt"]},
    ]

    merged, report = merge_architecture(existing, new, issue_number=43, issue_url="https://github.com/o/r/issues/43")

    assert len(merged) == 3
    assert report["updated"] == ["auth_Python.prompt"]
    assert report["added"] == ["billing_Python.prompt"]
    assert report["unchanged"] == ["db_Python.prompt"]

    # Updated module should have new description and origin
    auth = [m for m in merged if m["filename"] == "auth_Python.prompt"][0]
    assert auth["description"] == "updated"
    assert auth["origin"]["issue_number"] == 43

    # No duplicates
    auth_count = sum(1 for m in merged if m["filename"] == "auth_Python.prompt")
    assert auth_count == 1


def test_merge_preserves_legacy():
    """Modules without origin are preserved unchanged."""
    existing = [
        {"filename": "legacy_Python.prompt", "priority": 1, "dependencies": []},
    ]
    new = [
        {"filename": "new_Python.prompt", "priority": 1, "dependencies": []},
    ]

    merged, report = merge_architecture(existing, new, issue_number=1, issue_url="https://github.com/o/r/issues/1")

    legacy = [m for m in merged if m["filename"] == "legacy_Python.prompt"][0]
    assert "origin" not in legacy
    assert report["unchanged"] == ["legacy_Python.prompt"]


def test_priority_renumbering():
    """Priorities are renumbered after merge to form valid topological order."""
    existing = [
        {"filename": "a_Python.prompt", "priority": 1, "dependencies": []},
        {"filename": "b_Python.prompt", "priority": 2, "dependencies": ["a_Python.prompt"]},
    ]
    new = [
        {"filename": "c_Python.prompt", "priority": 1, "dependencies": ["b_Python.prompt"]},
    ]

    merged, _ = merge_architecture(existing, new, issue_number=10, issue_url="https://github.com/o/r/issues/10")

    # After merge: a(no deps) -> b(deps on a) -> c(deps on b)
    # Priorities should be sequential: 1, 2, 3
    priorities = {m["filename"]: m["priority"] for m in merged}
    assert priorities["a_Python.prompt"] < priorities["b_Python.prompt"]
    assert priorities["b_Python.prompt"] < priorities["c_Python.prompt"]
    assert set(priorities.values()) == {1, 2, 3}


def test_merge_empty_existing():
    """Merging into empty existing produces all new modules."""
    new = [
        {"filename": "a_Python.prompt", "priority": 1, "dependencies": []},
        {"filename": "b_Python.prompt", "priority": 2, "dependencies": ["a_Python.prompt"]},
    ]

    merged, report = merge_architecture([], new, issue_number=1, issue_url="url")

    assert len(merged) == 2
    assert sorted(report["added"]) == ["a_Python.prompt", "b_Python.prompt"]
    assert report["updated"] == []
    assert report["unchanged"] == []


def test_merge_empty_new():
    """Merging empty new preserves all existing modules."""
    existing = [
        {"filename": "a_Python.prompt", "priority": 1, "dependencies": []},
    ]

    merged, report = merge_architecture(existing, [], issue_number=1, issue_url="url")

    assert len(merged) == 1
    assert report["unchanged"] == ["a_Python.prompt"]
    assert report["added"] == []


# --- Registry Tests ---


def test_registry_record_and_load(tmp_path):
    """Registry round-trips correctly."""
    record_generation(
        project_root=tmp_path,
        issue_number=42,
        issue_url="https://github.com/o/r/issues/42",
        modules_added=["auth_Python.prompt"],
        modules_updated=[],
        target_dir=".",
    )

    registry = load_registry(tmp_path)
    assert registry["version"] == 1
    assert len(registry["generations"]) == 1
    gen = registry["generations"][0]
    assert gen["issue_number"] == 42
    assert gen["modules_added"] == ["auth_Python.prompt"]
    assert gen["modules_updated"] == []
    assert gen["target_dir"] == "."
    assert "timestamp" in gen


def test_registry_multiple_generations(tmp_path):
    """Multiple generations are appended."""
    record_generation(tmp_path, 1, "url1", ["a.prompt"], [])
    record_generation(tmp_path, 2, "url2", ["b.prompt"], ["a.prompt"])

    registry = load_registry(tmp_path)
    assert len(registry["generations"]) == 2
    assert registry["generations"][0]["issue_number"] == 1
    assert registry["generations"][1]["issue_number"] == 2


def test_load_registry_missing_file(tmp_path):
    """Loading from non-existent file returns empty registry."""
    registry = load_registry(tmp_path)
    assert registry == {"version": 1, "generations": []}


def test_save_and_load_registry(tmp_path):
    """Save and load registry round-trip."""
    data = {"version": 1, "generations": [{"issue_number": 5}]}
    save_registry(tmp_path, data)

    loaded = load_registry(tmp_path)
    assert loaded == data


# --- Discovery Tests ---


def test_find_architecture_files_root_only(tmp_path):
    """Finds architecture.json at root."""
    (tmp_path / "architecture.json").write_text("[]")

    result = find_architecture_for_project(tmp_path)
    assert len(result) == 1
    assert result[0] == tmp_path / "architecture.json"


def test_find_architecture_files_subdirs(tmp_path):
    """Finds architecture.json in subdirectories."""
    (tmp_path / "architecture.json").write_text("[]")
    sub = tmp_path / "subproject"
    sub.mkdir()
    (sub / "architecture.json").write_text("[]")

    result = find_architecture_for_project(tmp_path)
    assert len(result) == 2
    assert result[0] == tmp_path / "architecture.json"
    assert result[1] == sub / "architecture.json"


def test_find_architecture_files_ignores_hidden(tmp_path):
    """Ignores hidden directories."""
    hidden = tmp_path / ".hidden"
    hidden.mkdir()
    (hidden / "architecture.json").write_text("[]")

    result = find_architecture_for_project(tmp_path)
    assert len(result) == 0


def test_find_architecture_files_none(tmp_path):
    """Returns empty list when no architecture files exist."""
    result = find_architecture_for_project(tmp_path)
    assert result == []


# --- Filter by Issue Tests ---


def test_get_modules_for_issue():
    """Filtering by origin works."""
    arch = [
        {"filename": "a.prompt", "origin": {"issue_number": 42, "issue_url": "url"}},
        {"filename": "b.prompt", "origin": {"issue_number": 43, "issue_url": "url"}},
        {"filename": "c.prompt"},  # No origin (legacy)
        {"filename": "d.prompt", "origin": {"issue_number": 42, "issue_url": "url"}},
    ]

    result = get_modules_for_issue(arch, 42)
    filenames = [m["filename"] for m in result]
    assert filenames == ["a.prompt", "d.prompt"]


def test_get_modules_for_issue_no_match():
    """Returns empty list when no modules match."""
    arch = [
        {"filename": "a.prompt", "origin": {"issue_number": 1}},
    ]
    assert get_modules_for_issue(arch, 999) == []


def test_get_modules_for_issue_no_origin():
    """Legacy modules (no origin) are not matched."""
    arch = [
        {"filename": "a.prompt"},
        {"filename": "b.prompt", "origin": None},
    ]
    assert get_modules_for_issue(arch, 1) == []


# --- Issue #1010: Nested architecture.json discovery tests ---


def test_find_architecture_depth_2(tmp_path):
    """architecture.json at depth 2+ must be discovered (primary bug reproduction).

    The bug: find_architecture_for_project() only scans 1 level deep,
    missing files like backend/functions/architecture.json.
    """
    # Root architecture.json
    (tmp_path / "architecture.json").write_text("[]")
    # Depth 1: frontend/architecture.json
    (tmp_path / "frontend").mkdir()
    (tmp_path / "frontend" / "architecture.json").write_text("[]")
    # Depth 2: backend/functions/architecture.json (MISSED by buggy code)
    (tmp_path / "backend" / "functions").mkdir(parents=True)
    (tmp_path / "backend" / "functions" / "architecture.json").write_text("[]")
    # Depth 2: extensions/github_pdd_app/architecture.json (MISSED by buggy code)
    (tmp_path / "extensions" / "github_pdd_app").mkdir(parents=True)
    (tmp_path / "extensions" / "github_pdd_app" / "architecture.json").write_text("[]")

    result = find_architecture_for_project(tmp_path)

    # Should find all 4 files; buggy code only finds 2 (root + frontend)
    assert len(result) == 4, (
        f"Expected 4 architecture files (root + 3 nested), got {len(result)}: {result}"
    )
    # Root should be first
    assert result[0] == tmp_path / "architecture.json"
    # All nested files should be present
    found_paths = {str(p.relative_to(tmp_path)) for p in result}
    assert "backend/functions/architecture.json" in found_paths
    assert "extensions/github_pdd_app/architecture.json" in found_paths


def test_find_architecture_depth_3(tmp_path):
    """architecture.json at depth 3+ must also be discovered."""
    (tmp_path / "architecture.json").write_text("[]")
    # Depth 3: a/b/c/architecture.json
    (tmp_path / "a" / "b" / "c").mkdir(parents=True)
    (tmp_path / "a" / "b" / "c" / "architecture.json").write_text("[]")

    result = find_architecture_for_project(tmp_path)

    assert len(result) == 2, (
        f"Expected 2 architecture files (root + depth-3), got {len(result)}: {result}"
    )
    found_paths = {str(p.relative_to(tmp_path)) for p in result}
    assert "a/b/c/architecture.json" in found_paths


def test_find_architecture_skips_excluded_but_finds_valid_nested(tmp_path):
    """Recursive discovery must skip excluded dirs but still find valid nested files.

    This tests that exclusion rules (hidden, node_modules, __pycache__) work
    at all depths while still discovering valid architecture files at depth 2+.
    """
    # Valid nested architecture at depth 2 (should be found)
    (tmp_path / "backend" / "functions").mkdir(parents=True)
    (tmp_path / "backend" / "functions" / "architecture.json").write_text("[]")
    # Excluded: nested hidden dir
    (tmp_path / "backend" / ".hidden").mkdir(parents=True)
    (tmp_path / "backend" / ".hidden" / "architecture.json").write_text("[]")
    # Excluded: nested node_modules
    (tmp_path / "backend" / "node_modules").mkdir(parents=True)
    (tmp_path / "backend" / "node_modules" / "architecture.json").write_text("[]")
    # Excluded: nested __pycache__
    (tmp_path / "backend" / "__pycache__").mkdir(parents=True)
    (tmp_path / "backend" / "__pycache__" / "architecture.json").write_text("[]")

    result = find_architecture_for_project(tmp_path)

    # Buggy code: finds 0 (can't reach depth 2 at all)
    # Fixed code: finds 1 (backend/functions only, excludes the rest)
    assert len(result) == 1, (
        f"Expected 1 architecture file (backend/functions only), got {len(result)}: {result}"
    )
    assert result[0] == tmp_path / "backend" / "functions" / "architecture.json"


def test_load_architecture_includes_depth_2_modules(tmp_path):
    """_load_architecture_json must include modules from depth-2 architecture files.

    This tests the caller integration: even if find_architecture_for_project
    returns depth-2 files, the combined architecture must contain their entries.
    """
    import json as _json
    from pdd.agentic_sync import _load_architecture_json

    # Root architecture with one module
    (tmp_path / "architecture.json").write_text(
        _json.dumps([{"filename": "auth_Python.prompt", "priority": 1, "dependencies": []}])
    )
    # Depth-2 architecture with a different module
    (tmp_path / "backend" / "functions").mkdir(parents=True)
    (tmp_path / "backend" / "functions" / "architecture.json").write_text(
        _json.dumps([{"filename": "admin_approve_user_Python.prompt", "priority": 1, "dependencies": []}])
    )

    combined, _ = _load_architecture_json(tmp_path)

    # Buggy code: combined has only 1 entry (root only, depth-2 missed)
    # Fixed code: combined has 2 entries
    assert combined is not None
    filenames = [e["filename"] for e in combined]
    assert "admin_approve_user_Python.prompt" in filenames, (
        f"Depth-2 module 'admin_approve_user_Python.prompt' missing from combined architecture. "
        f"Got: {filenames}"
    )
    assert len(combined) == 2


def test_filter_invalid_basenames_with_complete_architecture(tmp_path):
    """_filter_invalid_basenames must accept modules from depth-2 architecture files.

    End-to-end: discover nested architecture → build combined list →
    validate basenames. This is the exact failure path from issue #1010.
    """
    import json as _json
    from pdd.agentic_sync import _filter_invalid_basenames, _load_architecture_json

    # Root architecture
    (tmp_path / "architecture.json").write_text(
        _json.dumps([{"filename": "auth_Python.prompt", "priority": 1, "dependencies": []}])
    )
    # Depth-1 architecture
    (tmp_path / "frontend").mkdir()
    (tmp_path / "frontend" / "architecture.json").write_text(
        _json.dumps([{"filename": "dashboard_Python.prompt", "priority": 1, "dependencies": []}])
    )
    # Depth-2 architecture (contains the module that was being rejected)
    (tmp_path / "backend" / "functions").mkdir(parents=True)
    (tmp_path / "backend" / "functions" / "architecture.json").write_text(
        _json.dumps([{"filename": "admin_approve_user_Python.prompt", "priority": 1, "dependencies": []}])
    )

    combined, _ = _load_architecture_json(tmp_path)

    # This is the exact input that was failing in issue #1010
    valid, invalid = _filter_invalid_basenames(
        ["backend/admin_approve_user"], combined
    )

    # Buggy code: admin_approve_user is in invalid (depth-2 file not discovered)
    # Fixed code: admin_approve_user is in valid (tail matches unique basename)
    assert "backend/admin_approve_user" in valid, (
        f"'backend/admin_approve_user' should be valid but was rejected. "
        f"Valid: {valid}, Invalid: {invalid}"
    )
    assert len(invalid) == 0


def test_find_architecture_caller_update_main(tmp_path):
    """update_main.py caller gets depth-2 architecture files from find_architecture_for_project.

    Verifies the other caller also benefits from recursive discovery.
    """
    # Create nested architecture at depth 2
    (tmp_path / "backend" / "functions").mkdir(parents=True)
    (tmp_path / "backend" / "functions" / "architecture.json").write_text(
        json.dumps([{"filename": "nested_module_Python.prompt", "priority": 1}])
    )

    result = find_architecture_for_project(tmp_path)

    # Buggy code: returns [] because depth-2 file is missed
    # Fixed code: returns the depth-2 file
    assert len(result) >= 1, (
        f"Expected at least 1 architecture file (depth-2), got {len(result)}"
    )
    # Verify we can actually load the file (simulating what update_main does)
    arch_data = json.loads(result[0].read_text())
    assert len(arch_data) == 1
    assert arch_data[0]["filename"] == "nested_module_Python.prompt"


def test_find_architecture_max_depth_limit(tmp_path):
    """Architecture files beyond max depth (4) must NOT be discovered."""
    # Depth 4: a/b/c/d/architecture.json (at the limit, should be skipped)
    deep = tmp_path / "a" / "b" / "c" / "d"
    deep.mkdir(parents=True)
    (deep / "architecture.json").write_text("[]")
    # Depth 3: a/b/c/architecture.json (within limit, should be found)
    (tmp_path / "a" / "b" / "c" / "architecture.json").write_text("[]")

    result = find_architecture_for_project(tmp_path)

    assert len(result) == 1, (
        f"Expected 1 architecture file (depth-3 only), got {len(result)}: {result}"
    )
    found_paths = {str(p.relative_to(tmp_path)) for p in result}
    assert "a/b/c/architecture.json" in found_paths
    assert "a/b/c/d/architecture.json" not in found_paths


def test_find_architecture_skips_venv_directories(tmp_path):
    """Virtual environment directories must be excluded from discovery."""
    # Valid nested architecture
    (tmp_path / "backend" / "api").mkdir(parents=True)
    (tmp_path / "backend" / "api" / "architecture.json").write_text("[]")
    # venv directory (should be excluded)
    (tmp_path / "venv" / "lib").mkdir(parents=True)
    (tmp_path / "venv" / "lib" / "architecture.json").write_text("[]")
    # .venv directory (should be excluded)
    (tmp_path / ".venv" / "lib").mkdir(parents=True)
    (tmp_path / ".venv" / "lib" / "architecture.json").write_text("[]")
    # env directory (should be excluded)
    (tmp_path / "env" / "lib").mkdir(parents=True)
    (tmp_path / "env" / "lib" / "architecture.json").write_text("[]")

    result = find_architecture_for_project(tmp_path)

    assert len(result) == 1, (
        f"Expected 1 architecture file (backend/api only), got {len(result)}: {result}"
    )
    assert result[0] == tmp_path / "backend" / "api" / "architecture.json"


# --- Issue #1256: Tolerant architecture.json loader tests ---


def test_extract_modules_bare_array():
    """extract_modules returns modules from bare array input (Test 1)."""
    from pdd.architecture_registry import extract_modules

    data = [{"filename": "auth_Python.prompt", "priority": 1, "dependencies": []}]
    result = extract_modules(data)
    assert len(result) == 1
    assert result[0]["filename"] == "auth_Python.prompt"
    assert result[0]["priority"] == 1


def test_extract_modules_object_format():
    """extract_modules returns modules from object-format {prd_files, modules} input (Test 2)."""
    from pdd.architecture_registry import extract_modules

    data = {
        "prd_files": ["docs/prd.md"],
        "modules": [{"filename": "auth_Python.prompt", "priority": 1, "dependencies": []}],
    }
    result = extract_modules(data)
    assert len(result) == 1
    assert result[0]["filename"] == "auth_Python.prompt"


def test_extract_modules_unknown_shapes_return_empty():
    """extract_modules returns [] for unknown shapes without raising (Test 3)."""
    from pdd.architecture_registry import extract_modules

    for bad_input in ["just a string", 42, None, {"random_key": "value"}, {"modules": "not_a_list"}]:
        result = extract_modules(bad_input)
        assert result == [], f"Expected [] for input {bad_input!r}, got {result!r}"


def test_extract_modules_filters_non_dict_entries():
    """extract_modules filters out non-dict entries from the modules list (Test 4)."""
    from pdd.architecture_registry import extract_modules

    data = [{"filename": "a.prompt"}, "stray_string", 42, {"filename": "b.prompt"}]
    result = extract_modules(data)
    assert len(result) == 2
    assert result[0]["filename"] == "a.prompt"
    assert result[1]["filename"] == "b.prompt"


def test_extract_prd_files_object_format():
    """extract_prd_files returns prd_files from object-format input (Test 5)."""
    from pdd.architecture_registry import extract_prd_files

    data = {
        "prd_files": ["docs/prd.md", "docs/spec.md"],
        "modules": [{"filename": "auth_Python.prompt"}],
    }
    result = extract_prd_files(data)
    assert result == ["docs/prd.md", "docs/spec.md"]


def test_extract_prd_files_returns_empty_for_non_object():
    """extract_prd_files returns [] for bare array, unknown shapes, and dicts without prd_files (Test 6)."""
    from pdd.architecture_registry import extract_prd_files

    for input_data in [
        [{"filename": "a.prompt"}],
        "string",
        42,
        None,
        {"modules": [{"filename": "a.prompt"}]},
    ]:
        result = extract_prd_files(input_data)
        assert result == [], f"Expected [] for input {input_data!r}, got {result!r}"


def test_load_combined_mixed_formats_returns_combined_modules(tmp_path):
    """load_combined_architecture_data with mixed formats returns modules from both files (Test 7).

    Root architecture.json uses bare-array format; subdir uses object-format.
    Both should contribute modules to the combined result.
    """
    from pdd.architecture_registry import load_combined_architecture_data

    # Root architecture.json: bare array format
    root_arch = [{"filename": "mod_a_Python.prompt", "priority": 1, "dependencies": []}]
    (tmp_path / "architecture.json").write_text(json.dumps(root_arch), encoding="utf-8")

    # Subdir architecture.json: object format
    subdir = tmp_path / "backend"
    subdir.mkdir()
    subdir_arch = {
        "prd_files": ["prd.md"],
        "modules": [{"filename": "mod_b_Python.prompt", "priority": 2, "dependencies": []}],
    }
    (subdir / "architecture.json").write_text(json.dumps(subdir_arch), encoding="utf-8")

    combined, primary_path = load_combined_architecture_data(tmp_path)

    assert combined is not None, (
        "load_combined_architecture_data returned None — dict-format architecture.json "
        "was silently dropped by isinstance(data, list) check at architecture_registry.py:271"
    )
    filenames = {m["filename"] for m in combined}
    assert "mod_a_Python.prompt" in filenames, "Bare-array module should be in combined result"
    assert "mod_b_Python.prompt" in filenames, (
        "Object-format module should be in combined result but was silently dropped "
        "by isinstance(data, list) check at architecture_registry.py:271"
    )


def test_load_combined_preserves_object_format_on_write_back(tmp_path):
    """Write-back of object-format architecture.json preserves {prd_files, modules} shape (Test 8)."""
    from pdd.architecture_registry import extract_modules, extract_prd_files

    original_data = {
        "prd_files": ["docs/prd.md", "docs/spec.md"],
        "modules": [
            {"filename": "auth_Python.prompt", "priority": 1, "dependencies": []},
            {"filename": "api_Python.prompt", "priority": 2, "dependencies": ["auth_Python.prompt"]},
        ],
    }
    arch_path = tmp_path / "architecture.json"
    arch_path.write_text(json.dumps(original_data, indent=2), encoding="utf-8")

    # Load, extract modules, modify one
    raw = json.loads(arch_path.read_text(encoding="utf-8"))
    modules = extract_modules(raw)
    assert len(modules) == 2, "extract_modules should return 2 modules from object-format"

    # Modify a module
    modules[0]["priority"] = 99

    # Reconstruct and write back (preserving object-format shape)
    prd_files = extract_prd_files(raw)
    written_data = {"prd_files": prd_files, "modules": modules}
    arch_path.write_text(json.dumps(written_data, indent=2), encoding="utf-8")

    # Verify object-format is preserved
    reloaded = json.loads(arch_path.read_text(encoding="utf-8"))
    assert isinstance(reloaded, dict), "On-disk file should remain object-format (dict)"
    assert "prd_files" in reloaded, "prd_files key should be preserved on write-back"
    assert reloaded["prd_files"] == ["docs/prd.md", "docs/spec.md"]
    assert reloaded["modules"][0]["priority"] == 99


# --- find_project_root Tier Precedence Tests (issue 815) ---


class TestFindProjectRootTiers:
    """Tier-precedence tests for the project-root resolver.

    Verifies the contract from architecture_registry_python.prompt:
      Tier A (PDD-explicit) `.pddrc` / `.pdd/`, Tier B (PDD-conventional)
      `sources/` + PRD/spec markdown, and Tier C (`.git`) are project
      boundaries. The nearest boundary found while walking upward wins.
      `Path.home()` is skipped for the PDD-marker check so that `~/.pdd`
      (user-global config from `pdd setup`) does not anchor a project root
      at `$HOME`.
    """

    def test_tier_a_pddrc_file(self, tmp_path: Path) -> None:
        (tmp_path / ".pddrc").touch()
        deep = tmp_path / "src" / "sub"
        deep.mkdir(parents=True)
        assert find_project_root(deep) == tmp_path.resolve()

    def test_tier_a_pdd_directory(self, tmp_path: Path) -> None:
        (tmp_path / ".pdd").mkdir()
        deep = tmp_path / "deep"
        deep.mkdir()
        assert find_project_root(deep) == tmp_path.resolve()

    def test_tier_b_sources_plus_prd_markdown(self, tmp_path: Path) -> None:
        (tmp_path / "sources").mkdir()
        (tmp_path / "PRD.md").write_text("# Product spec", encoding="utf-8")
        sub = tmp_path / "sub"
        sub.mkdir()
        assert find_project_root(sub) == tmp_path.resolve()

    def test_tier_b_negative_sources_only_no_markdown(self, tmp_path: Path) -> None:
        # `sources/` alone, no PRD/spec markdown -> Tier B does NOT match.
        (tmp_path / "sources").mkdir()
        (tmp_path / "notes.md").write_text("not a prd", encoding="utf-8")
        sub = tmp_path / "sub"
        sub.mkdir()
        # No markers anywhere -> falls through to start.resolve().
        assert find_project_root(sub) == sub.resolve()

    @pytest.mark.parametrize("name", ["PRD.md", "prd.md", "feature_prd.md", "Spec.md", "service_spec.md", "spec_overview.md"])
    def test_tier_b_case_insensitive_globs(self, tmp_path: Path, name: str) -> None:
        (tmp_path / "sources").mkdir()
        (tmp_path / name).write_text("x", encoding="utf-8")
        assert find_project_root(tmp_path) == tmp_path.resolve()

    def test_tier_c_git_fallback(self, tmp_path: Path) -> None:
        (tmp_path / ".git").mkdir()
        assert find_project_root(tmp_path) == tmp_path.resolve()

    def test_no_markers_returns_start_resolved(self, tmp_path: Path) -> None:
        deep = tmp_path / "a" / "b"
        deep.mkdir(parents=True)
        assert find_project_root(deep) == deep.resolve()

    def test_tier_a_beats_enclosing_git(self, tmp_path: Path) -> None:
        # The #1403 bug fix: nested .pddrc inside an outer .git resolves to the
        # inner self-contained PDD project.
        outer = tmp_path / "outer"
        outer.mkdir()
        (outer / ".git").mkdir()
        inner = outer / "projects" / "service-a"
        inner.mkdir(parents=True)
        (inner / ".pddrc").touch()
        deep = inner / "src" / "sub"
        deep.mkdir(parents=True)
        assert find_project_root(deep) == inner.resolve()

    def test_tier_b_beats_enclosing_git(self, tmp_path: Path) -> None:
        # Same nearest-boundary rule for conventional PDD projects: a
        # sources/ + PRD marker inside an outer git repo resolves to the inner
        # PDD project.
        outer = tmp_path / "outer"
        outer.mkdir()
        (outer / ".git").mkdir()
        inner = outer / "projects" / "service-b"
        inner.mkdir(parents=True)
        (inner / "sources").mkdir()
        (inner / "prd.md").write_text("x", encoding="utf-8")
        deep = inner / "src" / "sub"
        deep.mkdir(parents=True)
        assert find_project_root(deep) == inner.resolve()

    def test_innermost_pdd_marker_wins_across_tier_a_and_b(self, tmp_path: Path) -> None:
        # Tier A (outer) and Tier B (inner) are a single PDD-marker pool; the
        # innermost directory carrying *any* PDD marker wins, regardless of which
        # tier matched. This is what makes a self-contained PDD project inside an
        # outer PDD project resolve to itself.
        (tmp_path / ".pddrc").touch()  # Tier A at outer
        inner = tmp_path / "inner"
        inner.mkdir()
        (inner / "sources").mkdir()
        (inner / "prd.md").write_text("x", encoding="utf-8")  # Tier B at inner
        sub = inner / "sub"
        sub.mkdir()
        assert find_project_root(sub) == inner.resolve()

    def test_nearer_git_beats_enclosing_pdd_marker(self, tmp_path: Path) -> None:
        # A real nested git repo is also a project boundary. An outer PDD marker
        # must not capture work under a nearer inner git repository.
        (tmp_path / ".pddrc").touch()
        inner_repo = tmp_path / "vendor" / "repo"
        inner_repo.mkdir(parents=True)
        (inner_repo / ".git").mkdir()
        sub = inner_repo / "src"
        sub.mkdir()
        assert find_project_root(sub) == inner_repo.resolve()

    def test_innermost_within_tier_wins(self, tmp_path: Path) -> None:
        # Two `.pddrc` files at different depths -> innermost wins.
        (tmp_path / ".pddrc").touch()
        inner = tmp_path / "inner"
        inner.mkdir()
        (inner / ".pddrc").touch()
        sub = inner / "sub"
        sub.mkdir()
        assert find_project_root(sub) == inner.resolve()

    def test_walk_capped_at_20_ancestors(self, tmp_path: Path) -> None:
        # Build a deep tree where the marker is more than 20 levels above.
        deep = tmp_path
        for i in range(25):
            deep = deep / f"d{i}"
        deep.mkdir(parents=True)
        (tmp_path / ".pddrc").touch()  # 25 levels above `deep`
        # Should fall through (cap stops the walk before reaching tmp_path).
        assert find_project_root(deep) == deep.resolve()

    def test_default_uses_cwd(self, tmp_path: Path, monkeypatch) -> None:
        (tmp_path / ".pddrc").touch()
        sub = tmp_path / "sub"
        sub.mkdir()
        monkeypatch.chdir(sub)
        assert find_project_root() == tmp_path.resolve()

    def test_home_pdd_directory_is_not_a_project_marker(
        self, tmp_path: Path, monkeypatch
    ) -> None:
        # Regression: `pdd setup` creates ~/.pdd for user-global config.
        # find_project_root must NOT treat that as a Tier A marker, otherwise
        # any repo under $HOME without a closer marker resolves to $HOME.
        fake_home = (tmp_path / "home").resolve()
        fake_home.mkdir()
        (fake_home / ".pdd").mkdir()  # user-global config
        repo = fake_home / "code" / "myrepo"
        repo.mkdir(parents=True)
        (repo / ".git").mkdir()
        sub = repo / "src" / "deep"
        sub.mkdir(parents=True)

        monkeypatch.setattr(Path, "home", classmethod(lambda cls: fake_home))

        # Repo's own .git (Tier C) wins because the home .pdd marker is skipped.
        assert find_project_root(sub) == repo.resolve()

    def test_home_pddrc_file_is_not_a_project_marker(
        self, tmp_path: Path, monkeypatch
    ) -> None:
        # Same regression for `~/.pddrc`: must not anchor a project root at $HOME.
        fake_home = (tmp_path / "home").resolve()
        fake_home.mkdir()
        (fake_home / ".pddrc").write_text("global: 1", encoding="utf-8")
        repo_dir = fake_home / "projects" / "service"
        repo_dir.mkdir(parents=True)
        (repo_dir / ".git").mkdir()

        monkeypatch.setattr(Path, "home", classmethod(lambda cls: fake_home))

        assert find_project_root(repo_dir) == repo_dir.resolve()

    def test_temp_root_pdd_directory_is_not_a_project_marker(
        self, tmp_path: Path, monkeypatch
    ) -> None:
        # CI/test runners may create shared .pdd cache/config under the system
        # temp root. That ambient marker must not make unrelated pytest temp
        # children resolve to the temp root.
        fake_tmp = (tmp_path / "tmp-root").resolve()
        fake_tmp.mkdir()
        (fake_tmp / ".pdd").mkdir()
        child = fake_tmp / "pytest-case" / "orphan"
        child.mkdir(parents=True)

        monkeypatch.setattr(
            "pdd.architecture_registry.tempfile.gettempdir",
            lambda: str(fake_tmp),
        )
        assert find_project_root(child) == child.resolve()


# --- find_git_toplevel Tests (issue 815) ---


class TestFindGitToplevel:
    """Tests for the path-based .git ancestor walker."""

    def test_returns_directory_containing_git(self, tmp_path: Path) -> None:
        (tmp_path / ".git").mkdir()
        deep = tmp_path / "a" / "b"
        deep.mkdir(parents=True)
        assert find_git_toplevel(deep) == tmp_path.resolve()

    def test_returns_start_when_start_has_git(self, tmp_path: Path) -> None:
        (tmp_path / ".git").mkdir()
        assert find_git_toplevel(tmp_path) == tmp_path.resolve()

    def test_returns_none_when_no_git(self, tmp_path: Path) -> None:
        sub = tmp_path / "x" / "y"
        sub.mkdir(parents=True)
        # tmp_path is under /tmp which is not a git repo -> None.
        assert find_git_toplevel(sub) is None

    def test_default_uses_cwd(self, tmp_path: Path, monkeypatch) -> None:
        (tmp_path / ".git").mkdir()
        sub = tmp_path / "sub"
        sub.mkdir()
        monkeypatch.chdir(sub)
        assert find_git_toplevel() == tmp_path.resolve()
