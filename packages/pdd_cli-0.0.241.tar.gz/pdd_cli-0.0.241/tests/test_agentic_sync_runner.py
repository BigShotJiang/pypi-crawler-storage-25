"""Tests for pdd.agentic_sync_runner module."""
from __future__ import annotations

import io
import json
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Tuple
from unittest.mock import MagicMock, patch

import pytest

# Cap per-test runtime for this real-LLM heavy module. Individual hot tests
# may carry their own @pytest.mark.timeout override.
pytestmark = pytest.mark.timeout(450)

from pdd.agentic_sync_runner import (
    GITHUB_COMMENT_BODY_LIMIT,
    MAX_WORKERS,
    STATE_FILE_PATH,
    AsyncSyncRunner,
    ModuleState,
    _BOX_CHARS_RE,
    _format_duration,
    _parse_conformance_failure,
    _parse_cost_from_csv,
    build_dep_graph_from_architecture,
    build_dep_graph_from_architecture_data,
)


def _make_mock_popen(stdout_text: str = "", stderr_text: str = "", exit_code: int = 0):
    """Create a mock Popen object with file-like stdout/stderr streams."""
    mock_proc = MagicMock()
    mock_proc.stdout = io.StringIO(stdout_text)
    mock_proc.stderr = io.StringIO(stderr_text)
    mock_proc.wait.return_value = exit_code
    mock_proc.pid = 99999  # Prevent os.killpg(MagicMock) from resolving to pgid 1
    return mock_proc


# ---------------------------------------------------------------------------
# ModuleState
# ---------------------------------------------------------------------------

class TestModuleState:
    def test_defaults(self):
        state = ModuleState()
        assert state.status == "pending"
        assert state.start_time is None
        assert state.end_time is None
        assert state.cost == 0.0
        assert state.error is None
        assert state.current_phase is None
        assert state.completed_phases == []

    def test_completed_phases_independent(self):
        """Verify each ModuleState gets its own completed_phases list."""
        a = ModuleState()
        b = ModuleState()
        a.completed_phases.append("generate")
        assert b.completed_phases == []


# ---------------------------------------------------------------------------
# _format_duration
# ---------------------------------------------------------------------------

class TestFormatDuration:
    def test_none_values(self):
        assert _format_duration(None, None) == "-"
        assert _format_duration(1.0, None) == "-"
        assert _format_duration(None, 2.0) == "-"

    def test_seconds(self):
        assert _format_duration(100.0, 145.0) == "45s"

    def test_minutes_and_seconds(self):
        assert _format_duration(0.0, 125.0) == "2m 5s"


# ---------------------------------------------------------------------------
# _parse_cost_from_csv
# ---------------------------------------------------------------------------

class TestParseCostFromCsv:
    def test_parses_csv(self, tmp_path):
        csv_path = tmp_path / "cost.csv"
        csv_path.write_text(
            "timestamp,model,command,cost,input_files,output_files\n"
            "2024-01-01,gpt-4,sync,0.05,a.py,b.py\n"
            "2024-01-01,gpt-4,sync,0.10,c.py,d.py\n"
        )
        assert _parse_cost_from_csv(str(csv_path)) == pytest.approx(0.15)

    def test_missing_file(self, tmp_path):
        assert _parse_cost_from_csv(str(tmp_path / "nonexistent.csv")) == 0.0

    def test_empty_cost_values(self, tmp_path):
        csv_path = tmp_path / "cost.csv"
        csv_path.write_text(
            "timestamp,model,command,cost,input_files,output_files\n"
            "2024-01-01,gpt-4,sync,,a.py,b.py\n"
        )
        assert _parse_cost_from_csv(str(csv_path)) == 0.0


# ---------------------------------------------------------------------------
# AsyncSyncRunner._get_ready_modules
# ---------------------------------------------------------------------------

class TestGetReadyModules:
    def _make_runner(self, basenames, dep_graph, states=None):
        runner = AsyncSyncRunner(
            basenames=basenames,
            dep_graph=dep_graph,
            sync_options={},
            github_info=None,
            quiet=True,
        )
        if states:
            for name, status in states.items():
                runner.module_states[name].status = status
        return runner

    def test_no_deps_all_ready(self):
        runner = self._make_runner(["a", "b"], {"a": [], "b": []})
        ready = runner._get_ready_modules()
        assert set(ready) == {"a", "b"}

    def test_dep_blocks_module(self):
        runner = self._make_runner(
            ["a", "b"],
            {"a": [], "b": ["a"]},
        )
        ready = runner._get_ready_modules()
        assert ready == ["a"]

    def test_dep_satisfied_unblocks(self):
        runner = self._make_runner(
            ["a", "b"],
            {"a": [], "b": ["a"]},
            states={"a": "success"},
        )
        ready = runner._get_ready_modules()
        assert ready == ["b"]

    def test_running_module_not_ready(self):
        runner = self._make_runner(
            ["a", "b"],
            {"a": [], "b": []},
            states={"a": "running"},
        )
        ready = runner._get_ready_modules()
        assert ready == ["b"]

    def test_failed_dep_blocks(self):
        runner = self._make_runner(
            ["a", "b"],
            {"a": [], "b": ["a"]},
            states={"a": "failed"},
        )
        ready = runner._get_ready_modules()
        assert ready == []

    def test_external_dep_assumed_ok(self):
        """Dependencies not in basenames are assumed already synced."""
        runner = self._make_runner(
            ["b"],
            {"b": ["external"]},
        )
        ready = runner._get_ready_modules()
        assert ready == ["b"]


# ---------------------------------------------------------------------------
# AsyncSyncRunner._get_blocked_modules
# ---------------------------------------------------------------------------

class TestGetBlockedModules:
    def test_blocked_by_failed_dep(self):
        runner = AsyncSyncRunner(
            basenames=["a", "b"],
            dep_graph={"a": [], "b": ["a"]},
            sync_options={},
            github_info=None,
            quiet=True,
        )
        runner.module_states["a"].status = "failed"
        blocked = runner._get_blocked_modules()
        assert blocked == ["b"]

    def test_not_blocked_when_dep_pending(self):
        runner = AsyncSyncRunner(
            basenames=["a", "b"],
            dep_graph={"a": [], "b": ["a"]},
            sync_options={},
            github_info=None,
            quiet=True,
        )
        blocked = runner._get_blocked_modules()
        assert blocked == []

    def test_blocked_by_transitive_failed_dep(self):
        runner = AsyncSyncRunner(
            basenames=["a", "b", "c"],
            dep_graph={"a": [], "b": ["a"], "c": ["b"]},
            sync_options={},
            github_info=None,
            quiet=True,
        )
        runner.module_states["a"].status = "failed"
        blocked = runner._get_blocked_modules()
        assert blocked == ["b", "c"]


# ---------------------------------------------------------------------------
# AsyncSyncRunner._build_comment_body
# ---------------------------------------------------------------------------

class TestBuildCommentBody:
    def test_all_pending(self):
        runner = AsyncSyncRunner(
            basenames=["a", "b"],
            dep_graph={"a": [], "b": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )
        body = runner._build_comment_body(42)
        assert "## PDD Agentic Sync Progress" in body
        assert "Issue: #42" in body
        assert "Pending" in body
        assert "In Progress (0/2 complete)" in body
        assert "| Phase |" in body

    def test_mixed_states(self):
        runner = AsyncSyncRunner(
            basenames=["a", "b", "c"],
            dep_graph={"a": [], "b": [], "c": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )
        runner.module_states["a"].status = "success"
        runner.module_states["a"].start_time = 100.0
        runner.module_states["a"].end_time = 145.0
        runner.module_states["a"].cost = 0.12
        runner.module_states["b"].status = "running"
        runner.module_states["b"].start_time = 110.0

        body = runner._build_comment_body(10)
        assert "Success" in body
        assert "Running" in body
        assert "Pending" in body

    def test_failure_shows_paused(self):
        runner = AsyncSyncRunner(
            basenames=["a", "b"],
            dep_graph={"a": [], "b": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )
        runner.module_states["a"].status = "failed"
        runner.module_states["a"].start_time = 0.0
        runner.module_states["a"].end_time = 10.0
        runner.module_states["b"].status = "success"
        runner.module_states["b"].start_time = 0.0
        runner.module_states["b"].end_time = 10.0

        body = runner._build_comment_body(5)
        assert "Paused" in body
        assert "`a` failed" in body

    def test_failure_includes_state_error_details(self):
        """#865: GitHub progress comment must surface the structured
        conformance error for each failed module (missing symbols, the
        ``Reproduce locally:`` line, and env fingerprint), not just the
        ``Paused: <module> failed`` footer."""
        runner = AsyncSyncRunner(
            basenames=["alpha", "beta"],
            dep_graph={"alpha": [], "beta": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )
        runner.module_states["alpha"].status = "failed"
        runner.module_states["alpha"].start_time = 0.0
        runner.module_states["alpha"].end_time = 10.0
        runner.module_states["alpha"].error = (
            "Architecture conformance failure\n"
            "\n"
            "=== architecture conformance failure ===\n"
            "prompt: alpha_python.prompt\n"
            "output: pdd/alpha.py\n"
            "expected: foo, bar\n"
            "found: foo\n"
            "missing: bar\n"
            "\n"
            "Reproduce locally: pdd sync alpha\n"
            "\n"
            "--- env ---\n"
            "pdd.__file__: /tmp/pdd/__init__.py\n"
        )
        runner.module_states["beta"].status = "success"
        runner.module_states["beta"].start_time = 0.0
        runner.module_states["beta"].end_time = 10.0

        body = runner._build_comment_body(7)
        assert "### Failed module details" in body
        assert "<details><summary><code>alpha</code></summary>" in body
        assert "missing: bar" in body
        assert "Reproduce locally: pdd sync alpha" in body
        assert "--- env ---" in body
        # Successful module should not get a details block
        assert "<code>beta</code>" not in body

    def test_failure_details_comment_has_total_size_cap(self):
        """Progress comments must stay under GitHub's 65,536 char limit."""
        basenames = [f"mod_{i}" for i in range(10)]
        runner = AsyncSyncRunner(
            basenames=basenames,
            dep_graph={name: [] for name in basenames},
            sync_options={},
            github_info=None,
            quiet=True,
        )
        long_error = (
            "Architecture conformance failure\n"
            "=== architecture conformance failure ===\n"
            "missing: MissingExport\n"
            + ("x" * 10000)
        )
        for basename in basenames:
            state = runner.module_states[basename]
            state.status = "failed"
            state.start_time = 0.0
            state.end_time = 1.0
            state.error = long_error

        body = runner._build_comment_body(7)

        assert len(body) <= GITHUB_COMMENT_BODY_LIMIT
        assert "### Failed module details" in body
        assert "truncated" in body

    def test_failure_with_running_modules_shows_continuing(self):
        runner = AsyncSyncRunner(
            basenames=["a", "b"],
            dep_graph={"a": [], "b": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )
        runner.module_states["a"].status = "failed"
        runner.module_states["a"].start_time = 0.0
        runner.module_states["a"].end_time = 10.0
        runner.module_states["b"].status = "running"
        runner.module_states["b"].start_time = 0.0

        body = runner._build_comment_body(5)
        assert "Continuing independent module(s)" in body
        assert "Paused" not in body
        assert "`a` failed" in body

    def test_all_success(self):
        runner = AsyncSyncRunner(
            basenames=["x"],
            dep_graph={"x": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )
        runner.module_states["x"].status = "success"
        runner.module_states["x"].start_time = 0.0
        runner.module_states["x"].end_time = 10.0
        runner.module_states["x"].cost = 0.5

        body = runner._build_comment_body(1)
        assert "All 1 modules synced successfully" in body

    def test_phase_column_running_with_phase(self):
        """Running module shows current phase with done count."""
        runner = AsyncSyncRunner(
            basenames=["m"],
            dep_graph={"m": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )
        runner.module_states["m"].status = "running"
        runner.module_states["m"].start_time = 100.0
        runner.module_states["m"].current_phase = "test"
        runner.module_states["m"].completed_phases = ["generate", "auto-deps"]

        body = runner._build_comment_body(1)
        assert "`test` (2 done)" in body

    def test_phase_column_running_no_phase(self):
        """Running module with no phase yet shows dash."""
        runner = AsyncSyncRunner(
            basenames=["m"],
            dep_graph={"m": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )
        runner.module_states["m"].status = "running"
        runner.module_states["m"].start_time = 100.0

        body = runner._build_comment_body(1)
        # The row for 'm' should have "- |" for phase (between Running and duration)
        for line in body.splitlines():
            if "| m |" in line:
                # Split into columns
                cols = [c.strip() for c in line.split("|")]
                # cols: ['', 'm', 'Running', '-', duration, '-', '']
                phase_col = cols[3]  # Phase column
                assert phase_col == "-"

    def test_phase_column_success_with_phases(self):
        """Completed module shows total phase count."""
        runner = AsyncSyncRunner(
            basenames=["m"],
            dep_graph={"m": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )
        runner.module_states["m"].status = "success"
        runner.module_states["m"].start_time = 0.0
        runner.module_states["m"].end_time = 60.0
        runner.module_states["m"].cost = 0.10
        runner.module_states["m"].completed_phases = ["generate", "test", "verify"]

        body = runner._build_comment_body(1)
        assert "3 phases" in body

    def test_phase_column_success_no_phases(self):
        """Completed module with no tracked phases shows dash."""
        runner = AsyncSyncRunner(
            basenames=["m"],
            dep_graph={"m": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )
        runner.module_states["m"].status = "success"
        runner.module_states["m"].start_time = 0.0
        runner.module_states["m"].end_time = 10.0
        runner.module_states["m"].cost = 0.05

        body = runner._build_comment_body(1)
        for line in body.splitlines():
            if "| m |" in line:
                cols = [c.strip() for c in line.split("|")]
                phase_col = cols[3]
                assert phase_col == "-"

    def test_phase_column_skip_shows_tilde(self):
        """Running module in a skip phase shows tilde prefix."""
        runner = AsyncSyncRunner(
            basenames=["m"],
            dep_graph={"m": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )
        runner.module_states["m"].status = "running"
        runner.module_states["m"].start_time = 100.0
        runner.module_states["m"].current_phase = "skip:verify"
        runner.module_states["m"].completed_phases = ["generate"]

        body = runner._build_comment_body(1)
        assert "`~verify` (1 done)" in body


# ---------------------------------------------------------------------------
# AsyncSyncRunner._on_phase_change
# ---------------------------------------------------------------------------

class TestOnPhaseChange:
    def _make_runner(self, basenames):
        runner = AsyncSyncRunner(
            basenames=basenames,
            dep_graph={b: [] for b in basenames},
            sync_options={},
            github_info=None,
            quiet=True,
        )
        return runner

    def test_first_phase_sets_current(self):
        runner = self._make_runner(["a"])
        runner.module_states["a"].status = "running"
        runner._on_phase_change("a", "generate")
        assert runner.module_states["a"].current_phase == "generate"
        assert runner.module_states["a"].completed_phases == []

    def test_phase_transition_moves_old_to_completed(self):
        runner = self._make_runner(["a"])
        runner.module_states["a"].status = "running"
        runner._on_phase_change("a", "generate")
        runner._on_phase_change("a", "test")
        assert runner.module_states["a"].current_phase == "test"
        assert runner.module_states["a"].completed_phases == ["generate"]

    def test_skip_phase_not_added_to_completed(self):
        """Phases prefixed with skip: should not appear in completed_phases."""
        runner = self._make_runner(["a"])
        runner.module_states["a"].status = "running"
        runner._on_phase_change("a", "generate")
        runner._on_phase_change("a", "skip:test")
        runner._on_phase_change("a", "verify")
        assert runner.module_states["a"].current_phase == "verify"
        assert runner.module_states["a"].completed_phases == ["generate"]

    def test_same_phase_again_no_duplicate(self):
        """Setting same phase repeatedly doesn't add duplicates."""
        runner = self._make_runner(["a"])
        runner.module_states["a"].status = "running"
        runner._on_phase_change("a", "generate")
        runner._on_phase_change("a", "generate")
        assert runner.module_states["a"].completed_phases == []

    def test_multiple_transitions(self):
        """Full lifecycle through multiple phases."""
        runner = self._make_runner(["a"])
        runner.module_states["a"].status = "running"
        runner._on_phase_change("a", "auto-deps")
        runner._on_phase_change("a", "generate")
        runner._on_phase_change("a", "test")
        runner._on_phase_change("a", "verify")
        runner._on_phase_change("a", "synced")
        assert runner.module_states["a"].current_phase == "synced"
        assert runner.module_states["a"].completed_phases == [
            "auto-deps", "generate", "test", "verify"
        ]


# ---------------------------------------------------------------------------
# AsyncSyncRunner._update_github_comment_throttled
# ---------------------------------------------------------------------------

class TestUpdateGithubCommentThrottled:
    def test_throttle_respects_interval(self):
        """Comment updates are skipped when called faster than interval."""
        runner = AsyncSyncRunner(
            basenames=["a"],
            dep_graph={"a": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )
        runner._comment_update_interval = 10.0
        call_count = [0]
        original = runner._update_github_comment

        def counting_update():
            call_count[0] += 1

        runner._update_github_comment = counting_update

        # First call should go through (last_update=0.0, now>15.0)
        runner._update_github_comment_throttled()
        assert call_count[0] == 1

        # Immediately after, should be throttled
        runner._update_github_comment_throttled()
        assert call_count[0] == 1  # Still 1

    def test_throttle_allows_after_interval(self):
        """After interval passes, update goes through again."""
        runner = AsyncSyncRunner(
            basenames=["a"],
            dep_graph={"a": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )
        runner._comment_update_interval = 0.0  # No throttle
        call_count = [0]

        def counting_update():
            call_count[0] += 1

        runner._update_github_comment = counting_update

        runner._update_github_comment_throttled()
        runner._update_github_comment_throttled()
        assert call_count[0] == 2


# ---------------------------------------------------------------------------
# AsyncSyncRunner._update_github_comment
# ---------------------------------------------------------------------------

class TestUpdateGithubComment:
    def _make_runner(self) -> AsyncSyncRunner:
        return AsyncSyncRunner(
            basenames=["a"],
            dep_graph={"a": []},
            sync_options={},
            github_info={
                "owner": "owner",
                "repo": "repo",
                "issue_number": 12,
            },
            quiet=True,
        )

    @patch("pdd.agentic_sync_runner._run_gh_command")
    def test_reuses_newest_existing_progress_comment(self, mock_gh):
        """A fresh runner should patch the existing progress comment, not post a duplicate."""
        comments = [
            {
                "id": 100,
                "body": "## PDD Agentic Sync Progress\nIssue: #11\nold issue",
            },
            {
                "id": 101,
                "body": "## PDD Agentic Sync Progress\nIssue: #12\nolder",
            },
            {
                "id": 102,
                "body": "## PDD Agentic Sync Progress\nIssue: #12\nnewer",
            },
        ]

        def fake_gh(args, timeout=30):
            if args == [
                "api", "repos/owner/repo/issues/12/comments", "--paginate", "--slurp",
            ]:
                return True, json.dumps([comments])
            if args[:3] == ["api", "repos/owner/repo/issues/comments/102", "-X"]:
                assert "PATCH" in args
                return True, "{}"
            raise AssertionError(f"unexpected gh args: {args}")

        mock_gh.side_effect = fake_gh
        runner = self._make_runner()

        runner._update_github_comment()

        assert runner.comment_id == 102
        calls = [call.args[0] for call in mock_gh.call_args_list]
        assert all("POST" not in call for call in calls)

    @patch("pdd.agentic_sync_runner._run_gh_command")
    def test_posts_when_no_existing_progress_comment(self, mock_gh):
        """No existing progress comment still creates one."""
        def fake_gh(args, timeout=30):
            if args == [
                "api", "repos/owner/repo/issues/12/comments", "--paginate", "--slurp",
            ]:
                return True, json.dumps([[]])
            if args[:3] == ["api", "repos/owner/repo/issues/12/comments", "-X"]:
                assert "POST" in args
                return True, json.dumps({"id": 555})
            raise AssertionError(f"unexpected gh args: {args}")

        mock_gh.side_effect = fake_gh
        runner = self._make_runner()

        runner._update_github_comment()

        assert runner.comment_id == 555


# ---------------------------------------------------------------------------
# AsyncSyncRunner._record_result phase finalization
# ---------------------------------------------------------------------------

class TestRecordResultPhaseFinalization:
    def test_record_result_finalizes_current_phase(self):
        """When recording result, current_phase is moved to completed and cleared."""
        runner = AsyncSyncRunner(
            basenames=["a"],
            dep_graph={"a": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )
        runner.module_states["a"].status = "running"
        runner.module_states["a"].current_phase = "verify"
        runner.module_states["a"].completed_phases = ["generate", "test"]

        runner._record_result("a", True, 0.10, "")

        assert runner.module_states["a"].current_phase is None
        assert runner.module_states["a"].completed_phases == ["generate", "test", "verify"]

    def test_record_result_skip_phase_not_finalized(self):
        """A skip: phase is not added to completed when recording result."""
        runner = AsyncSyncRunner(
            basenames=["a"],
            dep_graph={"a": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )
        runner.module_states["a"].status = "running"
        runner.module_states["a"].current_phase = "skip:test"
        runner.module_states["a"].completed_phases = ["generate"]

        runner._record_result("a", True, 0.05, "")

        assert runner.module_states["a"].current_phase is None
        assert runner.module_states["a"].completed_phases == ["generate"]

    def test_record_result_no_phase(self):
        """Recording result with no current_phase doesn't crash."""
        runner = AsyncSyncRunner(
            basenames=["a"],
            dep_graph={"a": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )
        runner.module_states["a"].status = "running"

        runner._record_result("a", True, 0.05, "")

        assert runner.module_states["a"].current_phase is None
        assert runner.module_states["a"].completed_phases == []


# ---------------------------------------------------------------------------
# AsyncSyncRunner.run (mocked subprocess)
# ---------------------------------------------------------------------------

class TestAsyncSyncRunnerRun:
    @patch.object(AsyncSyncRunner, "_sync_one_module")
    @patch.object(AsyncSyncRunner, "_update_github_comment")
    def test_single_module_success(self, mock_comment, mock_sync):
        mock_sync.return_value = (True, 0.05, "")

        runner = AsyncSyncRunner(
            basenames=["foo"],
            dep_graph={"foo": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )

        success, msg, cost = runner.run()
        assert success
        assert cost == pytest.approx(0.05)
        mock_sync.assert_called_once_with("foo")

    @patch.object(AsyncSyncRunner, "_sync_one_module")
    @patch.object(AsyncSyncRunner, "_update_github_comment")
    def test_dep_ordering_respected(self, mock_comment, mock_sync):
        """Module b depends on a; a should complete before b starts."""
        call_order = []

        def fake_sync(basename):
            call_order.append(basename)
            return (True, 0.01, "")

        mock_sync.side_effect = fake_sync

        runner = AsyncSyncRunner(
            basenames=["a", "b"],
            dep_graph={"a": [], "b": ["a"]},
            sync_options={},
            github_info=None,
            quiet=True,
        )

        success, msg, cost = runner.run()
        assert success
        assert call_order.index("a") < call_order.index("b")

    @patch.object(AsyncSyncRunner, "_sync_one_module")
    @patch.object(AsyncSyncRunner, "_update_github_comment")
    def test_failure_pauses_new_modules(self, mock_comment, mock_sync):
        """When a dependency fails, dependent modules should not start."""

        def fake_sync(basename):
            if basename == "a":
                return (False, 0.01, "compilation error")
            return (True, 0.02, "")

        mock_sync.side_effect = fake_sync

        runner = AsyncSyncRunner(
            basenames=["a", "b"],
            dep_graph={"a": [], "b": ["a"]},
            sync_options={},
            github_info=None,
            quiet=True,
        )

        success, msg, cost = runner.run()
        assert not success
        assert runner.module_states["a"].status == "failed"
        # b should remain pending (blocked by failed a)
        assert runner.module_states["b"].status == "pending"

    @patch.object(AsyncSyncRunner, "_sync_one_module")
    @patch.object(AsyncSyncRunner, "_update_github_comment")
    def test_failure_does_not_block_independent_ready_modules(
        self, mock_comment, mock_sync
    ):
        """Regression for #798: an unrelated failure must not strand ready work.

        In the #798 run, ``cli_detector`` failed architecture conformance while
        ``agentic_common`` was still running. ``setup_tool`` was genuinely
        blocked by ``cli_detector``, but ``agentic_update`` only depended on
        the successful ``agentic_common`` module. The runner should still start
        that independent dependent once its own dependency succeeds.
        """
        calls = []

        def fake_sync(basename):
            calls.append(basename)
            if basename == "cli_detector":
                return (False, 0.01, "Architecture conformance error")
            if basename == "agentic_common":
                time.sleep(0.05)
                return (True, 0.02, "")
            if basename == "agentic_update":
                return (True, 0.03, "")
            raise AssertionError(f"{basename} should remain blocked")

        mock_sync.side_effect = fake_sync

        runner = AsyncSyncRunner(
            basenames=[
                "cli_detector",
                "agentic_common",
                "setup_tool",
                "agentic_update",
            ],
            dep_graph={
                "cli_detector": [],
                "agentic_common": [],
                "setup_tool": ["cli_detector"],
                "agentic_update": ["agentic_common"],
            },
            sync_options={},
            github_info=None,
            quiet=True,
        )

        success, msg, cost = runner.run()

        assert not success
        assert cost == pytest.approx(0.06)
        assert runner.module_states["cli_detector"].status == "failed"
        assert runner.module_states["agentic_common"].status == "success"
        assert runner.module_states["agentic_update"].status == "success"
        assert runner.module_states["setup_tool"].status == "pending"
        assert "agentic_update" in calls
        assert "setup_tool" not in calls
        assert "Skipped (blocked): ['setup_tool']" in msg
        assert "agentic_update" not in msg.split("Skipped (blocked):", 1)[-1]

    @patch.object(AsyncSyncRunner, "_sync_one_module")
    @patch.object(AsyncSyncRunner, "_update_github_comment")
    def test_parallel_independent_modules(self, mock_comment, mock_sync):
        """Independent modules can run in parallel."""
        sync_times = {}

        def fake_sync(basename):
            sync_times[basename] = time.time()
            time.sleep(0.05)  # Brief sleep to allow parallel overlap
            return (True, 0.01, "")

        mock_sync.side_effect = fake_sync

        runner = AsyncSyncRunner(
            basenames=["a", "b", "c"],
            dep_graph={"a": [], "b": [], "c": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )

        success, msg, cost = runner.run()
        assert success
        assert len(sync_times) == 3

    @patch.object(AsyncSyncRunner, "_sync_one_module")
    @patch.object(AsyncSyncRunner, "_update_github_comment")
    def test_total_budget_runs_sequentially_and_stops_after_exhaustion(
        self, mock_comment, mock_sync
    ):
        """total_budget should not queue later modules before cost feedback."""
        mock_sync.return_value = (True, 1.0, "")

        runner = AsyncSyncRunner(
            basenames=["a", "b", "c"],
            dep_graph={"a": [], "b": [], "c": []},
            sync_options={"total_budget": 1.0},
            github_info=None,
            quiet=True,
        )

        success, msg, cost = runner.run()

        assert not success
        assert "Budget exhausted" in msg
        assert cost == pytest.approx(1.0)
        mock_sync.assert_called_once_with("a")
        assert runner.module_states["a"].status == "success"
        assert runner.module_states["b"].status == "pending"
        assert runner.module_states["c"].status == "pending"

    @patch.object(AsyncSyncRunner, "_sync_one_module")
    @patch.object(AsyncSyncRunner, "_update_github_comment")
    def test_total_budget_exhaustion_after_failed_module_stops_new_modules(
        self, mock_comment, mock_sync
    ):
        """A failed module's cost can exhaust the global budget."""
        calls = []

        def fake_sync(basename):
            calls.append(basename)
            if basename == "a":
                return (False, 1.0, "sync failed after spending budget")
            return (True, 0.5, "")

        mock_sync.side_effect = fake_sync

        runner = AsyncSyncRunner(
            basenames=["a", "b"],
            dep_graph={"a": [], "b": []},
            sync_options={"total_budget": 1.0},
            github_info=None,
            quiet=True,
        )

        success, msg, cost = runner.run()

        assert not success
        assert runner.budget_exhausted is True
        assert calls == ["a"]
        assert cost == pytest.approx(1.0)
        assert "Budget exhausted" in msg
        assert runner.module_states["a"].status == "failed"
        assert runner.module_states["b"].status == "pending"

    @patch.object(AsyncSyncRunner, "_sync_one_module")
    @patch.object(AsyncSyncRunner, "_update_github_comment")
    def test_empty_basenames(self, mock_comment, mock_sync):
        runner = AsyncSyncRunner(
            basenames=[],
            dep_graph={},
            sync_options={},
            github_info=None,
            quiet=True,
        )

        success, msg, cost = runner.run()
        assert success
        assert cost == 0.0

    @patch.object(AsyncSyncRunner, "_sync_one_module")
    @patch.object(AsyncSyncRunner, "_update_github_comment")
    def test_exception_in_sync_recorded_as_failure(self, mock_comment, mock_sync):
        mock_sync.side_effect = RuntimeError("unexpected crash")

        runner = AsyncSyncRunner(
            basenames=["x"],
            dep_graph={"x": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )

        success, msg, cost = runner.run()
        assert not success
        assert runner.module_states["x"].status == "failed"


# ---------------------------------------------------------------------------
# AsyncSyncRunner._sync_one_module (subprocess mock)
# ---------------------------------------------------------------------------

class TestSyncOneModule:
    def test_parse_conformance_failure_with_output_field(self):
        stderr = (
            "Architecture conformance error for foo_python.prompt: "
            "declared symbols missing from generated code: "
            "AsyncSyncRunner.run. "
            "Output: pdd/agentic_sync_runner.py. "
            "Expected: ['AsyncSyncRunner', 'AsyncSyncRunner.run']. "
            "Found: ['AsyncSyncRunner']."
        )

        parsed = _parse_conformance_failure("", stderr)

        assert parsed is not None
        repair_directive, missing_symbols = parsed
        assert missing_symbols == ("AsyncSyncRunner.run",)
        assert "- AsyncSyncRunner.run" in repair_directive
        assert "Output:" not in repair_directive

    def test_parse_conformance_failure_without_symbols_is_not_repairable(self):
        stderr = (
            "Architecture conformance error for foo_python.prompt: "
            "declared symbols missing from generated code\n"
        )

        assert _parse_conformance_failure("", stderr) is None

    def test_parse_conformance_failure_pdd_interface_param_shape(self):
        # New shape emitted by code_generator_main._verify_pdd_interface_signatures
        # when the prompt's <pdd-interface> declares a parameter the generated
        # code is missing (#928). The conformance parser must recognize this
        # so _sync_one_module retries with the repair directive.
        stderr = (
            "Architecture conformance error for update_main_python.prompt: "
            "the prompt's <pdd-interface> declares parameter(s) missing "
            "from the generated code: update_main.sync_metadata. "
            "Output: pdd/update_main.py."
        )

        parsed = _parse_conformance_failure("", stderr)

        assert parsed is not None, "new <pdd-interface> shape must be parseable"
        repair_directive, missing_symbols = parsed
        assert missing_symbols == ("update_main.sync_metadata",)
        # Directive must target ``update_main`` as the function to fix, not
        # ask the model to add an export named ``update_main.sync_metadata``.
        assert "On `update_main`" in repair_directive
        assert "`sync_metadata`" in repair_directive

    def test_parse_conformance_failure_pdd_interface_multiple_params(self):
        stderr = (
            "Architecture conformance error for foo_python.prompt: "
            "the prompt's <pdd-interface> declares parameter(s) missing "
            "from the generated code: foo.bar, foo.baz. "
            "Output: pdd/foo.py."
        )

        parsed = _parse_conformance_failure("", stderr)

        assert parsed is not None
        _, missing_symbols = parsed
        assert missing_symbols == ("foo.bar", "foo.baz")

    def test_parse_conformance_failure_pdd_interface_directive_targets_params(self):
        """The repair directive for pdd-interface failures must tell the model
        to add a *parameter* to a *function*, not to add an export named
        ``func.param``. The previous generic 'Required missing exports'
        directive was misleading the LLM into creating top-level exports
        named ``update_main.sync_metadata`` instead of adding the kwarg.
        """
        stderr = (
            "Architecture conformance error for update_main_python.prompt: "
            "the prompt's <pdd-interface> declares parameter(s) missing "
            "from the generated code: update_main.sync_metadata. "
            "Output: pdd/update_main.py."
        )

        directive, _ = _parse_conformance_failure("", stderr)

        assert "Required missing exports" not in directive
        assert "On `update_main`" in directive
        assert "missing parameter(s)" in directive
        assert "`sync_metadata`" in directive

    def test_parse_conformance_failure_pdd_interface_directive_dotted_method(self):
        """Dotted method names like ``ContentSelector.select.mode`` must be
        regrouped via rsplit so the directive targets
        ``ContentSelector.select`` with parameter ``mode``, not
        ``ContentSelector`` with parameter ``select.mode``.
        """
        stderr = (
            "Architecture conformance error for content_selector_python.prompt: "
            "the prompt's <pdd-interface> declares parameter(s) missing "
            "from the generated code: ContentSelector.select.mode. "
            "Output: pdd/content_selector.py."
        )

        directive, missing = _parse_conformance_failure("", stderr)

        assert missing == ("ContentSelector.select.mode",)
        assert "On `ContentSelector.select`" in directive
        assert "`mode`" in directive
        assert "select.mode" not in directive.replace("ContentSelector.select.mode", "")

    def test_parse_conformance_failure_pdd_interface_directive_bare_function(self):
        """A bare missing function name (no dot) must surface as a missing
        function directive, not a parameter directive — the prompt-only
        missing-function path emits these.
        """
        stderr = (
            "Architecture conformance error for foo_python.prompt: "
            "the prompt's <pdd-interface> declares parameter(s) missing "
            "from the generated code: update_main. "
            "Output: pdd/foo.py."
        )

        directive, missing = _parse_conformance_failure("", stderr)

        assert missing == ("update_main",)
        assert "missing function(s)/method(s)" in directive
        assert "`update_main`" in directive

    def test_parse_conformance_failure_pdd_interface_bare_dotted_missing_method(self):
        """A bare dotted method name (``ContentSelector.select``) emitted by
        the missing-function shape MUST NOT be split into
        ("ContentSelector", "select") under the parameter directive. The
        previous implementation routed any dotted symbol to the parameter
        bucket and rpartition'd it, producing 'On ContentSelector, add
        parameter select' — which is wrong for a missing method.
        """
        stderr = (
            "Architecture conformance error for content_selector_python.prompt: "
            "the prompt's <pdd-interface> declares function(s)/method(s) "
            "missing from the generated code: ContentSelector.select. "
            "Output: pdd/content_selector.py."
        )

        directive, missing = _parse_conformance_failure("", stderr)

        assert missing == ("ContentSelector.select",)
        assert "missing function(s)/method(s)" in directive
        assert "`ContentSelector.select`" in directive
        # Must NOT split into a class+parameter directive.
        assert "On `ContentSelector`," not in directive
        assert "parameter(s) to the signature" not in directive

    def test_parse_conformance_failure_pdd_interface_signature_drift(self):
        """Annotation/default drift entries carry their parenthesised
        diagnostic verbatim and route to an 'update parameter' directive.
        Issue #928's 'type drift' acceptance case.
        """
        stderr = (
            "Architecture conformance error for update_main_python.prompt: "
            "the prompt's <pdd-interface> declares parameter(s) whose "
            "signature drifted in the generated code: "
            "update_main.sync_metadata (annotation: declared `bool`, "
            "found `str`), update_main.sync_metadata "
            "(default: declared `False`, found `True`). "
            "Output: pdd/update_main.py."
        )

        directive, missing = _parse_conformance_failure("", stderr)

        # ``missing`` is the canonical dotted symbol used for the short-
        # circuit comparison, so the parenthesised drift diagnostic is
        # stripped from the missing-symbol set.
        assert "update_main.sync_metadata" in missing
        assert "Update the generated code so parameter" in directive
        assert "annotation: declared `bool`, found `str`" in directive
        assert "default: declared `False`, found `True`" in directive

    def test_parse_conformance_failure_mixed_legacy_and_pdd_interface(self):
        """When both legacy-export and pdd-interface shapes appear in the
        output, the directive must contain both sections so the model gets
        both kinds of repair instructions in one retry attempt.
        """
        combined = (
            "Architecture conformance error for foo_python.prompt: "
            "declared symbols missing from generated code: SomeClass. "
            "Output: pdd/foo.py.\n"
            "Architecture conformance error for foo_python.prompt: "
            "the prompt's <pdd-interface> declares parameter(s) missing "
            "from the generated code: update_main.sync_metadata. "
            "Output: pdd/foo.py."
        )

        directive, missing = _parse_conformance_failure("", combined)

        assert "SomeClass" in missing
        assert "update_main.sync_metadata" in missing
        assert "Required missing exports" in directive
        assert "On `update_main`" in directive

    def test_conformance_hard_failure_includes_structured_fields(self):
        runner = AsyncSyncRunner(
            basenames=["foo"],
            dep_graph={"foo": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )
        stderr = (
            "Architecture conformance error for foo_python.prompt: "
            "declared symbols missing from generated code: Foo.run. "
            "Output: pdd/foo.py. "
            "Expected: ['Foo', 'Foo.run']. "
            "Found: ['Foo']."
        )

        block = runner._build_conformance_hard_failure(
            "foo", "Overall status: Failed", "", stderr
        )

        assert "=== architecture conformance failure ===" in block
        assert "prompt: foo_python.prompt" in block
        assert "output: pdd/foo.py" in block
        assert "expected: ['Foo', 'Foo.run']" in block
        assert "found: ['Foo']" in block
        assert "missing: Foo.run" in block

    @patch("pdd.agentic_sync_runner.os.unlink")
    @patch("pdd.agentic_sync_runner._parse_cost_from_csv", return_value=0.0)
    @patch("pdd.agentic_sync_runner.subprocess.Popen")
    @patch("pdd.agentic_sync_runner._find_pdd_executable", return_value="/usr/bin/pdd")
    def test_conformance_failure_retries_with_repair_directive(
        self, mock_find, mock_popen, mock_cost, mock_unlink
    ):
        conformance_error = (
            "Architecture conformance error for foo_python.prompt: "
            "declared symbols missing from generated code: Foo.run. "
            "Output: pdd/foo.py. "
            "Expected: ['Foo', 'Foo.run']. Found: ['Foo']."
        )
        mock_popen.side_effect = [
            _make_mock_popen(stderr_text=conformance_error, exit_code=1),
            _make_mock_popen(stdout_text="Overall status: Success\n", exit_code=0),
        ]
        runner = AsyncSyncRunner(
            basenames=["foo"],
            dep_graph={"foo": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )

        success, cost, error = runner._sync_one_module("foo")

        assert success
        assert cost == pytest.approx(0.0)
        assert error == ""
        assert mock_popen.call_count == 2
        first_env = mock_popen.call_args_list[0].kwargs["env"]
        second_env = mock_popen.call_args_list[1].kwargs["env"]
        assert "PDD_REPAIR_DIRECTIVE" not in first_env
        assert "- Foo.run" in second_env["PDD_REPAIR_DIRECTIVE"]

    @patch("pdd.agentic_sync_runner.os.unlink")
    @patch("pdd.agentic_sync_runner._parse_cost_from_csv", side_effect=[0.6, 0.1])
    @patch("pdd.agentic_sync_runner.subprocess.Popen")
    @patch("pdd.agentic_sync_runner._find_pdd_executable", return_value="/usr/bin/pdd")
    def test_conformance_retry_shrinks_total_budget(
        self, mock_find, mock_popen, mock_cost, mock_unlink
    ):
        conformance_error = (
            "Architecture conformance error for foo_python.prompt: "
            "declared symbols missing from generated code: Foo.run. "
            "Output: pdd/foo.py. "
            "Expected: ['Foo', 'Foo.run']. Found: ['Foo']."
        )
        mock_popen.side_effect = [
            _make_mock_popen(stderr_text=conformance_error, exit_code=1),
            _make_mock_popen(stdout_text="Overall status: Success\n", exit_code=0),
        ]
        runner = AsyncSyncRunner(
            basenames=["foo"],
            dep_graph={"foo": []},
            sync_options={"total_budget": 1.0},
            github_info=None,
            quiet=True,
        )

        success, cost, error = runner._sync_one_module("foo")

        assert success
        assert cost == pytest.approx(0.7)
        assert error == ""
        assert mock_popen.call_count == 2
        first_cmd = mock_popen.call_args_list[0][0][0]
        second_cmd = mock_popen.call_args_list[1][0][0]
        assert float(first_cmd[first_cmd.index("--budget") + 1]) == pytest.approx(1.0)
        assert float(second_cmd[second_cmd.index("--budget") + 1]) == pytest.approx(0.4)

    @patch("pdd.agentic_sync_runner._env_fingerprint", return_value="--- env ---")
    @patch("pdd.agentic_sync_runner.os.unlink")
    @patch("pdd.agentic_sync_runner._parse_cost_from_csv", return_value=1.0)
    @patch("pdd.agentic_sync_runner.subprocess.Popen")
    @patch("pdd.agentic_sync_runner._find_pdd_executable", return_value="/usr/bin/pdd")
    def test_conformance_retry_stops_when_total_budget_exhausted(
        self, mock_find, mock_popen, mock_cost, mock_unlink, _mock_env
    ):
        conformance_error = (
            "Architecture conformance error for foo_python.prompt: "
            "declared symbols missing from generated code: Foo.run. "
            "Output: pdd/foo.py. "
            "Expected: ['Foo', 'Foo.run']. Found: ['Foo']."
        )
        mock_popen.return_value = _make_mock_popen(
            stderr_text=conformance_error,
            exit_code=1,
        )
        runner = AsyncSyncRunner(
            basenames=["foo"],
            dep_graph={"foo": []},
            sync_options={"total_budget": 1.0},
            github_info=None,
            quiet=True,
        )

        success, cost, error = runner._sync_one_module("foo")

        assert not success
        assert cost == pytest.approx(1.0)
        assert mock_popen.call_count == 1
        assert "Budget exhausted during architecture conformance repair" in error
        assert "=== architecture conformance failure ===" in error

    @patch("pdd.agentic_sync_runner.os.unlink")
    @patch("pdd.agentic_sync_runner._parse_cost_from_csv", return_value=0.15)
    @patch("pdd.agentic_sync_runner.subprocess.Popen")
    @patch("pdd.agentic_sync_runner._find_pdd_executable", return_value="/usr/bin/pdd")
    def test_successful_sync(self, mock_find, mock_popen, mock_cost, mock_unlink):
        mock_popen.return_value = _make_mock_popen(
            stdout_text="Overall status: Success\n",
            exit_code=0,
        )

        runner = AsyncSyncRunner(
            basenames=["foo"],
            dep_graph={"foo": []},
            sync_options={"agentic": True, "no_steer": True, "budget": 5.0},
            github_info=None,
            quiet=True,
        )

        success, cost, error = runner._sync_one_module("foo")
        assert success
        assert cost == pytest.approx(0.15)
        assert error == ""

        # Verify command construction
        cmd = mock_popen.call_args[0][0]
        assert "/usr/bin/pdd" in cmd[0]
        assert "--force" in cmd
        assert "sync" in cmd
        assert "foo" in cmd
        assert "--agentic" in cmd
        assert "--no-steer" in cmd
        assert "--budget" in cmd

    @patch("pdd.agentic_sync_runner.os.unlink")
    @patch("pdd.agentic_sync_runner._parse_cost_from_csv", return_value=0.15)
    @patch("pdd.agentic_sync_runner.subprocess.Popen")
    @patch("pdd.agentic_sync_runner._find_pdd_executable", return_value="/usr/bin/pdd")
    def test_local_mode_is_forwarded_to_child_sync(
        self, mock_find, mock_popen, mock_cost, mock_unlink
    ):
        """Global sync children must preserve the top-level --local flag."""
        mock_popen.return_value = _make_mock_popen(
            stdout_text="Overall status: Success\n",
            exit_code=0,
        )

        runner = AsyncSyncRunner(
            basenames=["foo"],
            dep_graph={"foo": []},
            sync_options={"local": True},
            github_info=None,
            quiet=True,
        )

        success, _, _ = runner._sync_one_module("foo")

        assert success
        cmd = mock_popen.call_args[0][0]
        assert cmd[:4] == ["/usr/bin/pdd", "--force", "--local", "sync"]
        assert cmd[4] == "foo"

    @patch("pdd.agentic_sync_runner.os.unlink")
    @patch("pdd.agentic_sync_runner._parse_cost_from_csv", return_value=0.15)
    @patch("pdd.agentic_sync_runner.subprocess.Popen")
    @patch("pdd.agentic_sync_runner._find_pdd_executable", return_value="/usr/bin/pdd")
    def test_target_coverage_is_forwarded_to_child_sync(
        self, mock_find, mock_popen, mock_cost, mock_unlink
    ):
        """Global sync children must use the same coverage threshold as planning."""
        mock_popen.return_value = _make_mock_popen(
            stdout_text="Overall status: Success\n",
            exit_code=0,
        )

        runner = AsyncSyncRunner(
            basenames=["foo"],
            dep_graph={"foo": []},
            sync_options={"target_coverage": 95.0},
            github_info=None,
            quiet=True,
        )

        success, _, _ = runner._sync_one_module("foo")

        assert success
        cmd = mock_popen.call_args[0][0]
        coverage_index = cmd.index("--target-coverage")
        assert cmd[coverage_index + 1] == "95.0"

    @patch("pdd.agentic_sync_runner.os.unlink")
    @patch("pdd.agentic_sync_runner._parse_cost_from_csv", return_value=0.10)
    @patch("pdd.agentic_sync_runner.subprocess.Popen")
    @patch("pdd.agentic_sync_runner._find_pdd_executable", return_value="/usr/bin/pdd")
    def test_total_budget_passes_remaining_budget(
        self, mock_find, mock_popen, mock_cost, mock_unlink
    ):
        mock_popen.return_value = _make_mock_popen(
            stdout_text="Overall status: Success\n",
            exit_code=0,
        )

        runner = AsyncSyncRunner(
            basenames=["foo"],
            dep_graph={"foo": []},
            sync_options={"total_budget": 1.50},
            github_info=None,
            quiet=True,
            initial_cost=0.50,
        )

        success, _, _ = runner._sync_one_module("foo")

        assert success
        cmd = mock_popen.call_args[0][0]
        budget_index = cmd.index("--budget")
        assert float(cmd[budget_index + 1]) == pytest.approx(1.0)

    @patch("pdd.agentic_sync_runner.os.unlink")
    @patch("pdd.agentic_sync_runner._parse_cost_from_csv", return_value=0.0)
    @patch("pdd.agentic_sync_runner.subprocess.Popen")
    @patch("pdd.agentic_sync_runner._find_pdd_executable", return_value="/usr/bin/pdd")
    def test_failed_sync_nonzero_exit(self, mock_find, mock_popen, mock_cost, mock_unlink):
        mock_popen.return_value = _make_mock_popen(
            stderr_text="Error: compilation failed\n",
            exit_code=1,
        )

        runner = AsyncSyncRunner(
            basenames=["bar"],
            dep_graph={"bar": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )

        success, cost, error = runner._sync_one_module("bar")
        assert not success
        assert "compilation failed" in error

    @patch("pdd.agentic_sync_runner.os.unlink")
    @patch("pdd.agentic_sync_runner._parse_cost_from_csv", return_value=0.0)
    @patch("pdd.agentic_sync_runner.subprocess.Popen")
    @patch("pdd.agentic_sync_runner._find_pdd_executable", return_value="/usr/bin/pdd")
    def test_failed_sync_overall_status_check(self, mock_find, mock_popen, mock_cost, mock_unlink):
        mock_popen.return_value = _make_mock_popen(
            stdout_text="Step 1 done\nOverall status: Failed\n",
            exit_code=0,
        )

        runner = AsyncSyncRunner(
            basenames=["baz"],
            dep_graph={"baz": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )

        success, cost, error = runner._sync_one_module("baz")
        assert not success

    @patch("pdd.agentic_sync_runner.os.unlink")
    @patch("pdd.agentic_sync_runner._parse_cost_from_csv", return_value=0.0)
    @patch("pdd.agentic_sync_runner.subprocess.Popen")
    @patch("pdd.agentic_sync_runner._find_pdd_executable", return_value=None)
    def test_fallback_to_python_m_pdd(self, mock_find, mock_popen, mock_cost, mock_unlink):
        mock_popen.return_value = _make_mock_popen(stdout_text="OK\n", exit_code=0)

        runner = AsyncSyncRunner(
            basenames=["mod"],
            dep_graph={"mod": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )

        runner._sync_one_module("mod")
        cmd = mock_popen.call_args[0][0]
        assert "-m" in cmd
        assert "pdd" in cmd

    @patch("pdd.agentic_sync_runner.os.unlink")
    @patch("pdd.agentic_sync_runner._parse_cost_from_csv", return_value=0.0)
    @patch("pdd.agentic_sync_runner.subprocess.Popen")
    @patch("pdd.agentic_sync_runner._find_pdd_executable", return_value="/usr/bin/pdd")
    def test_timeout_terminates_process(self, mock_find, mock_popen, mock_cost, mock_unlink):
        """Verify timeout handling with Popen."""
        timeout_exc = __import__("subprocess").TimeoutExpired(cmd="pdd", timeout=900)
        mock_proc = _make_mock_popen()
        # First wait() (heartbeat poll) raises TimeoutExpired, then cleanup wait() returns 0
        mock_proc.wait.side_effect = [timeout_exc, 0]
        mock_popen.return_value = mock_proc

        runner = AsyncSyncRunner(
            basenames=["slow"],
            dep_graph={"slow": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )

        # Mock time so elapsed_total immediately exceeds MODULE_TIMEOUT
        # after the first heartbeat poll TimeoutExpired
        from pdd.agentic_sync_runner import MODULE_TIMEOUT as _module_timeout
        call_count = [0]
        base_time = 1000.0

        def fake_time():
            call_count[0] += 1
            if call_count[0] <= 2:
                return base_time
            return base_time + _module_timeout + 100  # Well past MODULE_TIMEOUT

        with patch("pdd.agentic_sync_runner.time.time", side_effect=fake_time):
            success, cost, error = runner._sync_one_module("slow")
        assert not success
        assert "Timeout" in error

    @patch("pdd.agentic_sync_runner.os.unlink")
    @patch("pdd.agentic_sync_runner._parse_cost_from_csv", return_value=0.0)
    @patch("pdd.agentic_sync_runner.subprocess.Popen")
    @patch("pdd.agentic_sync_runner._find_pdd_executable", return_value="/usr/bin/pdd")
    def test_timeout_adder_extends_module_timeout(
        self, mock_find, mock_popen, mock_cost, mock_unlink
    ):
        """`sync_options['timeout_adder']` (forwarded from `--timeout-adder`)
        must extend the per-module wall-clock cap so users can stretch the
        budget for individual large modules without redefining
        ``PDD_MODULE_TIMEOUT_SECONDS`` globally. Without this, the CLI flag is
        a silent no-op for the agentic-sync workflow."""
        from pdd.agentic_sync_runner import MODULE_TIMEOUT as _module_timeout

        timeout_exc = __import__("subprocess").TimeoutExpired(cmd="pdd", timeout=900)
        mock_proc = _make_mock_popen()
        mock_proc.wait.side_effect = [timeout_exc, 0]
        mock_popen.return_value = mock_proc

        adder = 600.0
        runner = AsyncSyncRunner(
            basenames=["slow"],
            dep_graph={"slow": []},
            sync_options={"timeout_adder": adder},
            github_info=None,
            quiet=True,
        )

        # Tick the clock to between MODULE_TIMEOUT and MODULE_TIMEOUT+adder so
        # we can prove the cap was extended (not exceeded) by the adder.
        call_count = [0]
        base_time = 1000.0

        def fake_time():
            call_count[0] += 1
            if call_count[0] <= 2:
                return base_time
            # Just past MODULE_TIMEOUT but well within MODULE_TIMEOUT + adder.
            return base_time + _module_timeout + (adder / 2)

        with patch("pdd.agentic_sync_runner.time.time", side_effect=fake_time):
            success, cost, error = runner._sync_one_module("slow")

        # The runner did NOT abort at MODULE_TIMEOUT; either it kept polling
        # (no error returned with a "Timeout" message) or, if the side_effect
        # ran out, surfaced a different failure. Both prove the adder extended
        # the cap above MODULE_TIMEOUT.
        if error:
            assert "Timeout after" not in error or str(int(_module_timeout)) not in error, (
                f"timeout_adder=600s should have extended the cap above "
                f"MODULE_TIMEOUT={_module_timeout}s, got error={error!r}"
            )

    @patch("pdd.agentic_sync_runner.os.unlink")
    @patch("pdd.agentic_sync_runner._parse_cost_from_csv", return_value=0.0)
    @patch("pdd.agentic_sync_runner.subprocess.Popen")
    @patch("pdd.agentic_sync_runner._find_pdd_executable", return_value="/usr/bin/pdd")
    def test_negative_timeout_adder_does_not_shrink_cap(
        self, mock_find, mock_popen, mock_cost, mock_unlink
    ):
        """A negative or non-numeric `timeout_adder` must clamp to 0 — an
        over-eager flag must never *shrink* the per-module wall-clock cap."""
        from pdd.agentic_sync_runner import MODULE_TIMEOUT as _module_timeout

        timeout_exc = __import__("subprocess").TimeoutExpired(cmd="pdd", timeout=900)
        mock_proc = _make_mock_popen()
        mock_proc.wait.side_effect = [timeout_exc, 0]
        mock_popen.return_value = mock_proc

        runner = AsyncSyncRunner(
            basenames=["slow"],
            dep_graph={"slow": []},
            sync_options={"timeout_adder": -100.0},
            github_info=None,
            quiet=True,
        )

        # Clock just past MODULE_TIMEOUT — the cap MUST still be MODULE_TIMEOUT
        # (not MODULE_TIMEOUT - 100), so the timeout fires.
        call_count = [0]
        base_time = 1000.0

        def fake_time():
            call_count[0] += 1
            if call_count[0] <= 2:
                return base_time
            return base_time + _module_timeout + 5

        with patch("pdd.agentic_sync_runner.time.time", side_effect=fake_time):
            success, cost, error = runner._sync_one_module("slow")
        assert not success
        assert "Timeout" in error
        # Effective cap should equal MODULE_TIMEOUT (not the truncated value).
        assert str(int(_module_timeout)) in error

    @patch("pdd.agentic_sync_runner.os.unlink")
    @patch("pdd.agentic_sync_runner._parse_cost_from_csv", return_value=0.05)
    @patch("pdd.agentic_sync_runner.subprocess.Popen")
    @patch("pdd.agentic_sync_runner._find_pdd_executable", return_value="/usr/bin/pdd")
    def test_phase_markers_parsed_from_stdout(self, mock_find, mock_popen, mock_cost, mock_unlink):
        """PDD_PHASE markers in stdout are parsed and update module phase state."""
        mock_popen.return_value = _make_mock_popen(
            stdout_text=(
                "Starting sync...\n"
                "PDD_PHASE: generate\n"
                "Generating code...\n"
                "PDD_PHASE: test\n"
                "Running tests...\n"
                "PDD_PHASE: verify\n"
                "Verifying...\n"
                "PDD_PHASE: synced\n"
                "Overall status: Success\n"
            ),
            exit_code=0,
        )

        runner = AsyncSyncRunner(
            basenames=["foo"],
            dep_graph={"foo": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )
        runner.module_states["foo"].status = "running"
        runner.module_states["foo"].start_time = time.time()

        success, cost, error = runner._sync_one_module("foo")
        assert success

        # After sync completes, phases should have been tracked
        state = runner.module_states["foo"]
        # _read_stream saw: generate -> test -> verify -> synced
        # So completed_phases should have: generate, test, verify
        # and current_phase should be "synced" (last seen)
        assert "generate" in state.completed_phases
        assert "test" in state.completed_phases
        assert "verify" in state.completed_phases
        assert state.current_phase == "synced"

    @patch("pdd.agentic_sync_runner.os.unlink")
    @patch("pdd.agentic_sync_runner._parse_cost_from_csv", return_value=0.0)
    @patch("pdd.agentic_sync_runner.subprocess.Popen")
    @patch("pdd.agentic_sync_runner._find_pdd_executable", return_value="/usr/bin/pdd")
    def test_heartbeat_prefers_phase_state_over_stale_stdout(
        self, mock_find, mock_popen, mock_cost, mock_unlink, capsys
    ):
        """Heartbeat must surface parsed `PDD_PHASE` state instead of the
        last raw stdout line, otherwise the parent stays stuck on lines like
        ``Preprocessing complete`` for the whole run while later phases
        (test/fix) are quietly progressing — a recurring symptom that hid
        real work behind the cap (#1344)."""
        from pdd.agentic_sync_runner import MODULE_TIMEOUT as _module_timeout

        # Pretend the child has reached the `test` phase (via _read_stream's
        # PDD_PHASE markers) but the latest non-box stdout line is still
        # ``Preprocessing complete``. The heartbeat must prefer the phase.
        timeout_exc = __import__("subprocess").TimeoutExpired(cmd="pdd", timeout=900)
        mock_proc = _make_mock_popen()
        mock_proc.wait.side_effect = [timeout_exc, 0]
        mock_popen.return_value = mock_proc

        runner = AsyncSyncRunner(
            basenames=["slow"],
            dep_graph={"slow": []},
            sync_options={},
            github_info=None,
            quiet=False,  # heartbeats only print when not quiet
        )
        # Pre-populate phase state (as _read_stream would) so the heartbeat
        # block has something to find on the first poll.
        runner.module_states["slow"].current_phase = "test"
        runner.module_states["slow"].completed_phases = ["generate", "crash"]
        runner.module_states["slow"].status = "running"

        # Two _on_phase_change-style synthetic stdout lines that look stale.
        # The heartbeat must NOT echo the box-drawing or the
        # ``Preprocessing complete`` line — it must use the phase.
        # We seed them indirectly by having Popen yield them, but the
        # simplest path is to monkeypatch the heartbeat poll to return
        # a single tick before completion.
        call_count = [0]
        base_time = 1000.0

        def fake_time():
            call_count[0] += 1
            # Calls 1-2: start_wall + last_heartbeat captured at base_time.
            # Calls 3-5: first poll iteration — elapsed=75s (past the 60s
            # heartbeat threshold but well under MODULE_TIMEOUT) so the
            # heartbeat block fires and prints the phase line.
            # Call 6+: jump past MODULE_TIMEOUT to terminate the loop
            # without spinning forever.
            if call_count[0] <= 2:
                return base_time
            if call_count[0] <= 5:
                return base_time + 75
            return base_time + _module_timeout + 5

        # Pre-set start_time so line 739's `or time.time()` does not consume
        # one of our fake_time slots.
        runner.module_states["slow"].start_time = base_time

        with patch("pdd.agentic_sync_runner.time.time", side_effect=fake_time):
            runner._sync_one_module("slow")

        captured = capsys.readouterr()
        out = captured.out + captured.err

        assert "phase: test (2 done)" in out, (
            f"heartbeat must surface PDD_PHASE state when present; got:\n{out!r}"
        )
        assert "Preprocessing complete" not in out, (
            "heartbeat must not echo stale stdout lines once a phase is known"
        )

    @patch("pdd.agentic_sync_runner.os.unlink")
    @patch("pdd.agentic_sync_runner._parse_cost_from_csv", return_value=0.05)
    @patch("pdd.agentic_sync_runner.subprocess.Popen")
    @patch("pdd.agentic_sync_runner._find_pdd_executable", return_value="/usr/bin/pdd")
    def test_env_has_pythonunbuffered(self, mock_find, mock_popen, mock_cost, mock_unlink):
        """Child process environment includes PYTHONUNBUFFERED=1."""
        mock_popen.return_value = _make_mock_popen(stdout_text="OK\n", exit_code=0)

        runner = AsyncSyncRunner(
            basenames=["foo"],
            dep_graph={"foo": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )

        runner._sync_one_module("foo")
        env = mock_popen.call_args[1]["env"]
        assert env.get("PYTHONUNBUFFERED") == "1"

    @patch("pdd.agentic_sync_runner.os.unlink")
    @patch("pdd.agentic_sync_runner._parse_cost_from_csv", return_value=0.15)
    @patch("pdd.agentic_sync_runner.subprocess.Popen")
    @patch("pdd.agentic_sync_runner._find_pdd_executable", return_value="/usr/bin/pdd")
    def test_example_submitted_message_forwarded(self, mock_find, mock_popen, mock_cost, mock_unlink, capsys):
        """When child stdout contains 'Successfully submitted example', parent prints confirmation."""
        mock_popen.return_value = _make_mock_popen(
            stdout_text="Overall status: Success\nSuccessfully submitted example\n",
            exit_code=0,
        )

        runner = AsyncSyncRunner(
            basenames=["foo"],
            dep_graph={"foo": []},
            sync_options={},
            github_info=None,
            quiet=False,
        )

        success, cost, error = runner._sync_one_module("foo")
        assert success

        captured = capsys.readouterr()
        assert "Example submitted to cloud" in captured.out

    # ------------------------------------------------------------------
    # Regression tests for issue #1399:
    # AsyncSyncRunner._sync_one_module() must not promote nonfatal
    # `ContentSelector failed` warnings to the headline error string,
    # hiding the real child-process failure cause.
    # ------------------------------------------------------------------

    @patch("pdd.agentic_sync_runner.os.unlink")
    @patch("pdd.agentic_sync_runner._parse_cost_from_csv", return_value=0.0)
    @patch("pdd.agentic_sync_runner.subprocess.Popen")
    @patch("pdd.agentic_sync_runner._find_pdd_executable", return_value="/usr/bin/pdd")
    def test_real_error_preferred_over_content_selector_warning(
        self, mock_find, mock_popen, mock_cost, mock_unlink
    ):
        """Real RuntimeError + ContentSelector warning: warning must NOT
        be the headline error. Real traceback must dominate."""
        mock_popen.return_value = _make_mock_popen(
            stdout_text=(
                'Warning: ContentSelector failed for select='
                '"class:AsyncSyncRunner,def:_find_pdd_executable" '
                '\u2014 falling back to full content\n'
            ),
            stderr_text=(
                "Traceback (most recent call last):\n"
                '  File "x.py", line 1, in <module>\n'
                "RuntimeError: generation step failed\n"
            ),
            exit_code=1,
        )

        runner = AsyncSyncRunner(
            basenames=["foo"],
            dep_graph={"foo": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )

        success, cost, error = runner._sync_one_module("foo")
        assert not success
        # Real error must be present in headline summary
        assert "RuntimeError: generation step failed" in error, (
            f"Real RuntimeError must appear in headline error; got:\n{error!r}"
        )
        # Nonfatal ContentSelector warning must NOT pollute the headline
        assert "ContentSelector failed for select=" not in error, (
            "ContentSelector warning must not be promoted to headline; got:\n"
            f"{error!r}"
        )

    @patch("pdd.agentic_sync_runner.os.unlink")
    @patch("pdd.agentic_sync_runner._parse_cost_from_csv", return_value=0.0)
    @patch("pdd.agentic_sync_runner.subprocess.Popen")
    @patch("pdd.agentic_sync_runner._find_pdd_executable", return_value="/usr/bin/pdd")
    def test_only_nonfatal_warning_contains_failed_keyword(
        self, mock_find, mock_popen, mock_cost, mock_unlink
    ):
        """Nonzero child exit where only the ContentSelector warning
        contains the word `failed`. Headline must NOT be the warning;
        must surface exit code or the real `PDD command failed` line.
        Verbatim cloud-run output from issue #1399."""
        mock_popen.return_value = _make_mock_popen(
            stdout_text=(
                'Warning: ContentSelector failed for select='
                '"def:build_dependency_graph,def:extract_module_from_include,'
                'def:topological_sort" \u2014 falling back\n'
                "PDD command failed with exit code 1\n"
            ),
            exit_code=1,
        )

        runner = AsyncSyncRunner(
            basenames=["bar"],
            dep_graph={"bar": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )

        success, cost, error = runner._sync_one_module("bar")
        assert not success
        # The ContentSelector warning must not be the headline
        assert "ContentSelector failed for select=" not in error, (
            f"Warning must not appear in headline; got:\n{error!r}"
        )
        # An actionable failure reason (exit code or PDD command line) must remain
        assert (
            "Exit code 1" in error
            or "exit code 1" in error
            or "PDD command failed with exit code 1" in error
        ), (
            "Headline must surface real failure cause (exit code or PDD command "
            f"failed line); got:\n{error!r}"
        )

    @patch("pdd.agentic_sync_runner.os.unlink")
    @patch("pdd.agentic_sync_runner._parse_cost_from_csv", return_value=0.0)
    @patch("pdd.agentic_sync_runner.subprocess.Popen")
    @patch("pdd.agentic_sync_runner._find_pdd_executable", return_value="/usr/bin/pdd")
    def test_overall_status_failed_in_summary(
        self, mock_find, mock_popen, mock_cost, mock_unlink
    ):
        """Headline error for an `Overall status: Failed` run (with a
        ContentSelector warning) must include the Overall status marker
        and exclude the warning."""
        mock_popen.return_value = _make_mock_popen(
            stdout_text=(
                'Warning: ContentSelector failed for select="class:Foo" '
                "\u2014 falling back\n"
                "Overall status: Failed\n"
            ),
            exit_code=0,
        )

        runner = AsyncSyncRunner(
            basenames=["baz"],
            dep_graph={"baz": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )

        success, cost, error = runner._sync_one_module("baz")
        assert not success
        assert "Overall status: Failed" in error, (
            f"Headline must include Overall status: Failed; got:\n{error!r}"
        )
        assert "ContentSelector failed for select=" not in error, (
            f"Warning must not appear in headline; got:\n{error!r}"
        )

    @patch("pdd.agentic_sync_runner.os.unlink")
    @patch("pdd.agentic_sync_runner._parse_cost_from_csv", return_value=0.0)
    @patch("pdd.agentic_sync_runner.subprocess.Popen")
    @patch("pdd.agentic_sync_runner._find_pdd_executable", return_value="/usr/bin/pdd")
    def test_labeled_tails_when_no_high_signal_line(
        self, mock_find, mock_popen, mock_cost, mock_unlink
    ):
        """When no high-signal error line exists, the headline must NOT
        be just the ContentSelector warning. It must surface either the
        nonzero exit code or surrounding stderr/stdout context."""
        mock_popen.return_value = _make_mock_popen(
            stdout_text=(
                'Warning: ContentSelector failed for select='
                '"def:topological_sort" \u2014 falling back\n'
                "Working on module foo\n"
                "Done preprocessing\n"
            ),
            stderr_text="some stderr context line\n",
            exit_code=2,
        )

        runner = AsyncSyncRunner(
            basenames=["foo"],
            dep_graph={"foo": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )

        success, cost, error = runner._sync_one_module("foo")
        assert not success
        # The warning must not be the only/dominant content
        assert "ContentSelector failed for select=" not in error, (
            f"Warning must not be the headline; got:\n{error!r}"
        )
        # Headline must lead with the deterministic failure reason
        assert "Exit code 2" in error, (
            f"Headline must include `Exit code 2` failure reason; got:\n{error!r}"
        )
        # Labeled stderr/stdout tail blocks must be present so operators see
        # surrounding context (acceptance criterion for issue #1399).
        assert "--- stderr tail ---" in error, (
            f"Headline must include `--- stderr tail ---` label; got:\n{error!r}"
        )
        assert "--- stdout tail ---" in error, (
            f"Headline must include `--- stdout tail ---` label; got:\n{error!r}"
        )
        # Actual context lines must be in the tails
        assert "some stderr context line" in error, (
            f"stderr context line must appear in tail; got:\n{error!r}"
        )
        assert "Working on module foo" in error or "Done preprocessing" in error, (
            f"stdout context line must appear in tail; got:\n{error!r}"
        )

    @patch("pdd.agentic_sync_runner.os.unlink")
    @patch("pdd.agentic_sync_runner._parse_cost_from_csv", return_value=0.0)
    @patch("pdd.agentic_sync_runner.subprocess.Popen")
    @patch("pdd.agentic_sync_runner._find_pdd_executable", return_value="/usr/bin/pdd")
    def test_multiple_content_selector_warnings_with_real_error(
        self, mock_find, mock_popen, mock_cost, mock_unlink
    ):
        """Two ContentSelector warnings + real RuntimeError traceback:
        the real traceback must dominate; warnings must be filtered."""
        mock_popen.return_value = _make_mock_popen(
            stdout_text=(
                'Warning: ContentSelector failed for select="class:Foo" '
                "\u2014 falling back\n"
                'Warning: ContentSelector failed for select="def:bar,def:baz" '
                "\u2014 falling back\n"
            ),
            stderr_text=(
                "Traceback (most recent call last):\n"
                '  File "y.py", line 5, in foo\n'
                "RuntimeError: real failure\n"
            ),
            exit_code=1,
        )

        runner = AsyncSyncRunner(
            basenames=["foo"],
            dep_graph={"foo": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )

        success, cost, error = runner._sync_one_module("foo")
        assert not success
        assert "RuntimeError: real failure" in error, (
            f"Real RuntimeError must dominate headline; got:\n{error!r}"
        )
        assert "ContentSelector failed for select=" not in error, (
            f"ContentSelector warnings must be filtered out; got:\n{error!r}"
        )

    @patch("pdd.agentic_sync_runner.os.unlink")
    @patch("pdd.agentic_sync_runner._parse_cost_from_csv", return_value=0.0)
    @patch("pdd.agentic_sync_runner.subprocess.Popen")
    @patch("pdd.agentic_sync_runner._find_pdd_executable", return_value="/usr/bin/pdd")
    def test_content_selector_warnings_do_not_break_success(
        self, mock_find, mock_popen, mock_cost, mock_unlink
    ):
        """Regression guard: ContentSelector warnings on a successful run
        must not flip success to failure or populate the error string."""
        mock_popen.return_value = _make_mock_popen(
            stdout_text=(
                'Warning: ContentSelector failed for select="class:Foo" '
                "\u2014 falling back\n"
                "Overall status: Success\n"
            ),
            exit_code=0,
        )

        runner = AsyncSyncRunner(
            basenames=["foo"],
            dep_graph={"foo": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )

        success, cost, error = runner._sync_one_module("foo")
        assert success
        assert error == "", (
            f"Success path must produce empty error string; got:\n{error!r}"
        )

    @patch("pdd.agentic_sync_runner.os.unlink")
    @patch("pdd.agentic_sync_runner._parse_cost_from_csv", return_value=0.0)
    @patch("pdd.agentic_sync_runner.subprocess.Popen")
    @patch("pdd.agentic_sync_runner._find_pdd_executable", return_value="/usr/bin/pdd")
    def test_overall_status_failed_not_duplicated_in_summary(
        self, mock_find, mock_popen, mock_cost, mock_unlink
    ):
        """When `Overall status: Failed` is the failure reason, it must
        appear exactly once in the headline — not duplicated by the
        keyword-line selector that also matches `failed`."""
        mock_popen.return_value = _make_mock_popen(
            stdout_text=(
                'Warning: ContentSelector failed for select="class:Foo" '
                "— falling back\n"
                "Overall status: Failed\n"
            ),
            exit_code=0,
        )

        runner = AsyncSyncRunner(
            basenames=["baz"],
            dep_graph={"baz": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )

        success, cost, error = runner._sync_one_module("baz")
        assert not success
        assert error.count("Overall status: Failed") == 1, (
            "`Overall status: Failed` must appear exactly once in headline; "
            f"got:\n{error!r}"
        )


# ---------------------------------------------------------------------------
# Resumability: state file persistence
# ---------------------------------------------------------------------------

class TestResumability:
    def _make_runner(self, basenames, dep_graph=None, issue_url=None, tmp_path=None):
        """Create a runner, optionally with a custom project_root."""
        runner = AsyncSyncRunner(
            basenames=basenames,
            dep_graph=dep_graph or {b: [] for b in basenames},
            sync_options={},
            github_info=None,
            quiet=True,
            issue_url=issue_url,
        )
        if tmp_path:
            runner.project_root = tmp_path
        return runner

    def test_save_and_load_state(self, tmp_path):
        """State file is written and can be loaded by a new runner."""
        url = "https://github.com/o/r/issues/1"
        runner = self._make_runner(["a", "b"], issue_url=url, tmp_path=tmp_path)
        runner.project_root = tmp_path

        # Simulate a successful module
        runner._record_result("a", True, 0.12, "")

        state_path = tmp_path / STATE_FILE_PATH
        assert state_path.exists()

        data = json.loads(state_path.read_text())
        assert data["issue_url"] == url
        assert data["modules"]["a"]["status"] == "success"
        assert data["modules"]["a"]["cost"] == pytest.approx(0.12)
        assert data["modules"]["b"]["status"] == "pending"

    def test_resume_skips_succeeded_modules(self, tmp_path):
        """A new runner loading state skips already-succeeded modules."""
        url = "https://github.com/o/r/issues/2"

        # Write a state file with 'a' succeeded
        state_dir = tmp_path / ".pdd"
        state_dir.mkdir(parents=True)
        state_file = state_dir / "agentic_sync_state.json"
        state_file.write_text(json.dumps({
            "issue_url": url,
            "modules": {
                "a": {"status": "success", "cost": 0.10},
                "b": {"status": "pending", "cost": 0.0},
            },
            "total_cost": 0.10,
            "comment_id": 999,
        }))

        runner = self._make_runner(["a", "b"], issue_url=url, tmp_path=tmp_path)
        runner.project_root = tmp_path
        # Re-trigger load since project_root was set after init
        runner._load_state()

        assert runner.module_states["a"].status == "success"
        assert runner.module_states["a"].cost == pytest.approx(0.10)
        assert runner.module_states["b"].status == "pending"
        assert "a" in runner._resumed_modules
        assert runner.comment_id == 999

    def test_no_resume_without_issue_url(self, tmp_path):
        """No state loading when issue_url is None."""
        state_dir = tmp_path / ".pdd"
        state_dir.mkdir(parents=True)
        state_file = state_dir / "agentic_sync_state.json"
        state_file.write_text(json.dumps({
            "issue_url": "https://github.com/o/r/issues/3",
            "modules": {"a": {"status": "success", "cost": 0.10}},
        }))

        runner = self._make_runner(["a"], issue_url=None, tmp_path=tmp_path)
        runner.project_root = tmp_path
        runner._load_state()

        assert runner.module_states["a"].status == "pending"

    def test_no_resume_different_issue_url(self, tmp_path):
        """State file for a different issue URL is ignored."""
        state_dir = tmp_path / ".pdd"
        state_dir.mkdir(parents=True)
        state_file = state_dir / "agentic_sync_state.json"
        state_file.write_text(json.dumps({
            "issue_url": "https://github.com/o/r/issues/99",
            "modules": {"a": {"status": "success", "cost": 0.10}},
        }))

        runner = self._make_runner(
            ["a"], issue_url="https://github.com/o/r/issues/100", tmp_path=tmp_path
        )
        runner.project_root = tmp_path
        runner._load_state()

        assert runner.module_states["a"].status == "pending"

    def test_partial_resume_different_module_list(self, tmp_path):
        """State file with different module list still resumes overlapping succeeded modules."""
        url = "https://github.com/o/r/issues/4"
        state_dir = tmp_path / ".pdd"
        state_dir.mkdir(parents=True)
        state_file = state_dir / "agentic_sync_state.json"
        state_file.write_text(json.dumps({
            "issue_url": url,
            "modules": {
                "a": {"status": "success", "cost": 0.10},
                "c": {"status": "pending", "cost": 0.0},  # not in current list
            },
        }))

        runner = self._make_runner(["a", "b"], issue_url=url, tmp_path=tmp_path)
        runner.project_root = tmp_path
        runner._load_state()

        # 'a' was successful in saved state and is in current list — should be restored
        assert runner.module_states["a"].status == "success"
        assert runner.module_states["a"].cost == pytest.approx(0.10)
        assert "a" in runner._resumed_modules
        # 'b' is new — should remain pending
        assert runner.module_states["b"].status == "pending"

    @patch.object(AsyncSyncRunner, "_sync_one_module")
    @patch.object(AsyncSyncRunner, "_update_github_comment")
    def test_state_deleted_on_full_success(self, mock_comment, mock_sync, tmp_path):
        """State file is deleted when all modules succeed."""
        url = "https://github.com/o/r/issues/5"
        mock_sync.return_value = (True, 0.05, "")

        runner = self._make_runner(["a"], issue_url=url, tmp_path=tmp_path)
        runner.project_root = tmp_path

        runner.run()

        state_path = tmp_path / STATE_FILE_PATH
        assert not state_path.exists()

    @patch.object(AsyncSyncRunner, "_sync_one_module")
    @patch.object(AsyncSyncRunner, "_update_github_comment")
    def test_state_kept_on_failure(self, mock_comment, mock_sync, tmp_path):
        """State file is preserved when a module fails."""
        url = "https://github.com/o/r/issues/6"
        mock_sync.return_value = (False, 0.03, "error")

        runner = self._make_runner(["a"], issue_url=url, tmp_path=tmp_path)
        runner.project_root = tmp_path

        runner.run()

        state_path = tmp_path / STATE_FILE_PATH
        assert state_path.exists()
        data = json.loads(state_path.read_text())
        assert data["modules"]["a"]["status"] == "failed"

    def test_delete_state_noop_when_missing(self, tmp_path):
        """Deleting state when no file exists does not raise."""
        runner = self._make_runner(
            ["a"], issue_url="https://github.com/o/r/issues/7", tmp_path=tmp_path
        )
        runner.project_root = tmp_path
        runner._delete_state()  # Should not raise


# ---------------------------------------------------------------------------
# build_dep_graph_from_architecture
# ---------------------------------------------------------------------------

class TestBuildDepGraphFromArchitecture:
    """Tests for build_dep_graph_from_architecture()."""

    def test_basic_deps(self, tmp_path):
        """Modules with dependencies are correctly linked."""
        arch = [
            {"filename": "module_a_Python.prompt", "dependencies": ["module_b_Python.prompt"]},
            {"filename": "module_b_Python.prompt", "dependencies": []},
        ]
        arch_path = tmp_path / "architecture.json"
        arch_path.write_text(json.dumps(arch))

        result = build_dep_graph_from_architecture(
            arch_path, ["module_a_Python", "module_b_Python"]
        )
        assert result.graph == {"module_a_Python": ["module_b_Python"], "module_b_Python": []}
        assert result.warnings == []

    def test_missing_file_returns_empty_deps(self, tmp_path):
        """Non-existent architecture.json gives empty deps for all."""
        result = build_dep_graph_from_architecture(
            tmp_path / "nonexistent.json", ["x", "y"]
        )
        assert result.graph == {"x": [], "y": []}
        assert result.warnings == []

    def test_language_suffix_targets(self, tmp_path):
        """Target basenames with language suffix (e.g. crm_models_Python)
        correctly match architecture entries that strip the suffix."""
        arch = [
            {"filename": "crm_models_Python.prompt", "dependencies": ["base_config_Python.prompt"]},
            {"filename": "base_config_Python.prompt", "dependencies": []},
            {"filename": "api_client_Python.prompt", "dependencies": ["crm_models_Python.prompt"]},
        ]
        arch_path = tmp_path / "architecture.json"
        arch_path.write_text(json.dumps(arch))

        targets = ["crm_models_Python", "base_config_Python", "api_client_Python"]
        result = build_dep_graph_from_architecture(arch_path, targets)

        assert result.graph["crm_models_Python"] == ["base_config_Python"]
        assert result.graph["base_config_Python"] == []
        assert result.graph["api_client_Python"] == ["crm_models_Python"]
        assert result.warnings == []

    def test_frontend_react_language_suffixes_use_language_catalog(self, tmp_path):
        """TypeScriptReact/JavaScriptReact suffixes must resolve like Python."""
        arch = [
            {
                "filename": "tasks_page_TypeScriptReact.prompt",
                "dependencies": ["shared_ui_JavaScriptReact.prompt"],
            },
            {"filename": "shared_ui_JavaScriptReact.prompt", "dependencies": []},
        ]

        result = build_dep_graph_from_architecture_data(
            arch,
            ["tasks_page", "shared_ui"],
            source_name="architecture.json",
        )

        assert result.graph == {"tasks_page": ["shared_ui"], "shared_ui": []}
        assert result.warnings == []

    def test_only_target_deps_included(self, tmp_path):
        """Dependencies outside the target set are excluded."""
        arch = [
            {"filename": "mod_a_Python.prompt", "dependencies": ["mod_b_Python.prompt", "mod_c_Python.prompt"]},
            {"filename": "mod_b_Python.prompt", "dependencies": []},
            {"filename": "mod_c_Python.prompt", "dependencies": []},
        ]
        arch_path = tmp_path / "architecture.json"
        arch_path.write_text(json.dumps(arch))

        result = build_dep_graph_from_architecture(
            arch_path, ["mod_a_Python", "mod_b_Python"]
        )
        # mod_c_Python is not in target set, so mod_a's dep on it is excluded
        assert result.graph == {"mod_a_Python": ["mod_b_Python"], "mod_b_Python": []}
        assert any("mod_c" in w and "not in the sync target set" in w for w in result.warnings)

    def test_self_dep_excluded(self, tmp_path):
        """A module depending on itself is not included in its deps."""
        arch = [
            {"filename": "mod_a_Python.prompt", "dependencies": ["mod_a_Python.prompt"]},
        ]
        arch_path = tmp_path / "architecture.json"
        arch_path.write_text(json.dumps(arch))

        result = build_dep_graph_from_architecture(arch_path, ["mod_a_Python"])
        assert result.graph == {"mod_a_Python": []}
        assert result.warnings == []

    def test_warns_orphan_dependency_filename(self, tmp_path):
        """Dependency string not matching any architecture entry is reported."""
        arch = [
            {
                "filename": "mod_a_Python.prompt",
                "dependencies": ["missing_module_python.prompt", "mod_b_Python.prompt"],
            },
            {"filename": "mod_b_Python.prompt", "dependencies": []},
        ]
        arch_path = tmp_path / "architecture.json"
        arch_path.write_text(json.dumps(arch))

        result = build_dep_graph_from_architecture(
            arch_path, ["mod_a_Python", "mod_b_Python"]
        )
        assert result.graph["mod_a_Python"] == ["mod_b_Python"]
        assert any(
            "missing_module_python.prompt" in w and "orphan" in w.lower() for w in result.warnings
        ), result.warnings

    def test_builds_graph_from_combined_architecture_data(self):
        """Already-loaded architecture data preserves nested architecture deps."""
        arch = [
            {"filename": "root_module_Python.prompt", "dependencies": []},
            {
                "filename": "nested/app_Python.prompt",
                "dependencies": ["nested/lib_Python.prompt"],
            },
            {"filename": "nested/lib_Python.prompt", "dependencies": []},
        ]

        result = build_dep_graph_from_architecture_data(
            arch,
            ["nested/app", "nested/lib"],
            source_name="combined architecture data",
        )

        assert result.graph == {"nested/app": ["nested/lib"], "nested/lib": []}
        assert result.warnings == []


# ---------------------------------------------------------------------------
# _BOX_CHARS_RE — heartbeat line filtering
# ---------------------------------------------------------------------------

class TestBoxCharsRegex:
    """Verify _BOX_CHARS_RE matches Rich box-drawing lines and skips real content."""

    @pytest.mark.parametrize("line", [
        "╰──────────────────────────────────────────────────────────────────────────────╯",
        "╭───────────────────────────────────────╮",
        "│                                       │",
        "├───┼───┤",
        "┌────┐",
        "└────┘",
        "═══════════",
        "  ╭──╮  ",
        "---+---+---",
        "| | |",
        "",
        "   ",
    ])
    def test_matches_box_drawing_lines(self, line):
        assert _BOX_CHARS_RE.match(line.strip() if line.strip() else line) is not None or line.strip() == ""

    @pytest.mark.parametrize("line", [
        "Attempting provider: anthropic for task 'agentic_crash_explore'",
        "Successfully loaded prompt: agentic_test_generate_LLM",
        "Overall status: Success",
        "PDD_PHASE: generate",
        "Step 3/5 complete",
        "│ some actual content │",
    ])
    def test_does_not_match_content_lines(self, line):
        assert _BOX_CHARS_RE.match(line.strip()) is None


class TestHeartbeatLineFiltering:
    """Verify heartbeat skips box-drawing lines and finds informative content."""

    def _last_informative_line(self, stdout_lines: list) -> str:
        """Replicate the heartbeat line-finding logic."""
        for line in reversed(stdout_lines):
            stripped = line.strip()
            if stripped and not _BOX_CHARS_RE.match(stripped):
                return stripped
        return ""

    def test_skips_trailing_box_chars(self):
        lines = [
            "Attempting provider: anthropic\n",
            "╭──────────────────────╮\n",
            "│                      │\n",
            "╰──────────────────────╯\n",
        ]
        assert self._last_informative_line(lines) == "Attempting provider: anthropic"

    def test_returns_last_real_line(self):
        lines = [
            "Step 1\n",
            "Step 2\n",
            "Step 3\n",
        ]
        assert self._last_informative_line(lines) == "Step 3"

    def test_empty_list(self):
        assert self._last_informative_line([]) == ""

    def test_only_box_chars(self):
        lines = [
            "╭───╮\n",
            "│   │\n",
            "╰───╯\n",
        ]
        assert self._last_informative_line(lines) == ""

    def test_mixed_content_and_boxes(self):
        lines = [
            "╭───╮\n",
            "│   │\n",
            "╰───╯\n",
            "Successfully loaded prompt: agentic_test_generate_LLM\n",
            "╭──────────────────────╮\n",
            "╰──────────────────────╯\n",
        ]
        assert self._last_informative_line(lines) == "Successfully loaded prompt: agentic_test_generate_LLM"


# ---------------------------------------------------------------------------
# AsyncSyncRunner per-module cwd (module_cwds)
# ---------------------------------------------------------------------------

class TestModuleCwds:
    @patch("pdd.agentic_sync_runner.os.unlink")
    @patch("pdd.agentic_sync_runner._parse_cost_from_csv", return_value=0.0)
    @patch("pdd.agentic_sync_runner.subprocess.Popen")
    @patch("pdd.agentic_sync_runner._find_pdd_executable", return_value="/usr/bin/pdd")
    def test_module_cwds_respected(self, mock_find, mock_popen, mock_cost, mock_unlink):
        """Popen uses module-specific cwd when module_cwds is provided."""
        mock_popen.return_value = _make_mock_popen(stdout_text="OK\n", exit_code=0)

        custom_cwd = Path("/project/examples/hello")
        runner = AsyncSyncRunner(
            basenames=["greeting"],
            dep_graph={"greeting": []},
            sync_options={},
            github_info=None,
            quiet=True,
            module_cwds={"greeting": custom_cwd},
        )

        runner._sync_one_module("greeting")
        popen_kwargs = mock_popen.call_args[1]
        assert popen_kwargs["cwd"] == str(custom_cwd)

    @patch("pdd.agentic_sync_runner.os.unlink")
    @patch("pdd.agentic_sync_runner._parse_cost_from_csv", return_value=0.0)
    @patch("pdd.agentic_sync_runner.subprocess.Popen")
    @patch("pdd.agentic_sync_runner._find_pdd_executable", return_value="/usr/bin/pdd")
    def test_missing_module_falls_back_to_project_root(self, mock_find, mock_popen, mock_cost, mock_unlink):
        """Module not in module_cwds falls back to project_root."""
        mock_popen.return_value = _make_mock_popen(stdout_text="OK\n", exit_code=0)

        runner = AsyncSyncRunner(
            basenames=["foo"],
            dep_graph={"foo": []},
            sync_options={},
            github_info=None,
            quiet=True,
            module_cwds={"other": Path("/project/other")},
        )

        runner._sync_one_module("foo")
        popen_kwargs = mock_popen.call_args[1]
        assert popen_kwargs["cwd"] == str(runner.project_root)

    @patch("pdd.agentic_sync_runner.os.unlink")
    @patch("pdd.agentic_sync_runner._parse_cost_from_csv", return_value=0.0)
    @patch("pdd.agentic_sync_runner.subprocess.Popen")
    @patch("pdd.agentic_sync_runner._find_pdd_executable", return_value="/usr/bin/pdd")
    def test_module_targets_map_display_key_to_sync_basename(
        self, mock_find, mock_popen, mock_cost, mock_unlink
    ):
        """Scoped global-sync keys should execute the plain basename in the scoped cwd."""
        mock_popen.return_value = _make_mock_popen(
            stdout_text="Overall status: Success\n",
            exit_code=0,
        )

        custom_cwd = Path("/project/examples/prompts_linter")
        runner = AsyncSyncRunner(
            basenames=["examples/prompts_linter:report"],
            dep_graph={"examples/prompts_linter:report": []},
            sync_options={},
            github_info=None,
            quiet=True,
            module_cwds={"examples/prompts_linter:report": custom_cwd},
            module_targets={"examples/prompts_linter:report": "report"},
        )

        runner._sync_one_module("examples/prompts_linter:report")

        cmd = mock_popen.call_args[0][0]
        popen_kwargs = mock_popen.call_args[1]
        assert cmd[-1] == "report"
        assert "examples/prompts_linter:report" not in cmd
        assert popen_kwargs["cwd"] == str(custom_cwd)


# ---------------------------------------------------------------------------
# Issue #745: initial_cost (LLM module analysis cost) tracking
# ---------------------------------------------------------------------------

class TestInitialCostTracking:
    """Tests for issue #745: AsyncSyncRunner must include initial_cost
    (the LLM module analysis cost) in both _build_comment_body and run() return."""

    def test_build_comment_body_includes_initial_cost(self):
        """_build_comment_body total cost should include initial_cost."""
        runner = AsyncSyncRunner(
            basenames=["a"],
            dep_graph={"a": []},
            sync_options={},
            github_info=None,
            quiet=True,
            initial_cost=0.25,
        )
        runner.module_states["a"].status = "success"
        runner.module_states["a"].start_time = 0.0
        runner.module_states["a"].end_time = 10.0
        runner.module_states["a"].cost = 0.10

        body = runner._build_comment_body(1)
        # Total should be 0.25 (initial) + 0.10 (module) = 0.35
        assert "$0.35" in body

    @patch.object(AsyncSyncRunner, "_sync_one_module")
    @patch.object(AsyncSyncRunner, "_update_github_comment")
    def test_run_return_cost_includes_initial_cost(self, mock_comment, mock_sync):
        """run() return cost should include initial_cost."""
        mock_sync.return_value = (True, 0.10, "")

        runner = AsyncSyncRunner(
            basenames=["a"],
            dep_graph={"a": []},
            sync_options={},
            github_info=None,
            quiet=True,
            initial_cost=0.25,
        )

        success, msg, cost = runner.run()
        assert success
        # Cost should be 0.25 (initial) + 0.10 (module) = 0.35
        assert cost == pytest.approx(0.35)

    def test_default_initial_cost_is_zero(self):
        """When initial_cost is not provided, it defaults to 0.0 (backward compat)."""
        runner = AsyncSyncRunner(
            basenames=["a"],
            dep_graph={"a": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )
        assert runner.initial_cost == 0.0

    def test_initial_cost_visible_with_zero_module_costs(self):
        """When no modules have cost yet, initial_cost alone should appear in total."""
        runner = AsyncSyncRunner(
            basenames=["a"],
            dep_graph={"a": []},
            sync_options={},
            github_info=None,
            quiet=True,
            initial_cost=0.50,
        )
        # All modules pending (cost=0.0)
        body = runner._build_comment_body(1)
        assert "$0.50" in body


# --- Issue #1256: Dict-format architecture tolerance ---


def test_dep_graph_from_dict_format_architecture(tmp_path):
    """build_dep_graph_from_architecture with dict-format architecture.json builds correct graph (Test 10).

    Bug: isinstance(arch, list) at agentic_sync_runner.py:120 returns False for
    dict-format {"modules": [...]}, returning an empty dependency graph instead of
    extracting and processing the modules.
    """
    arch = {
        "modules": [
            {"filename": "a_python.prompt", "dependencies": ["b_python.prompt"]},
            {"filename": "b_python.prompt", "dependencies": []},
        ]
    }
    arch_path = tmp_path / "architecture.json"
    arch_path.write_text(json.dumps(arch))

    result = build_dep_graph_from_architecture(arch_path, ["a", "b"])

    assert result.graph["a"] == ["b"], (
        "Dict-format architecture should produce a dependency graph, "
        "but isinstance(arch, list) at agentic_sync_runner.py:120 rejects it "
        f"and returns empty graph: {result.graph}"
    )


# ---------------------------------------------------------------------------
# End-to-end (real subprocess) regression tests for issue #1399
#
# Unlike `TestSyncOneModule` which mocks `subprocess.Popen`, these tests
# exercise the full `_sync_one_module` path with a real child process so
# that pipe reading, thread joining, exit-code propagation, and
# stdout/stderr accumulation are all proven to compose with the new
# failure-summary contract.
# ---------------------------------------------------------------------------

import textwrap


def _make_fake_pdd_shim(tmp_path, stdout_text: str, stderr_text: str, exit_code: int) -> Path:
    """Write a tiny Python script with a shebang that ignores its argv,
    emits the given stdout/stderr, and exits with `exit_code`. The shim
    can be invoked directly so the runner spawns it the same way it
    would spawn the real `pdd` CLI."""
    shim = tmp_path / "fake_pdd"
    shim.write_text(
        f"#!{sys.executable}\n"
        + textwrap.dedent(
            f"""\
            import sys as _s
            _s.stdout.write({stdout_text!r})
            _s.stdout.flush()
            _s.stderr.write({stderr_text!r})
            _s.stderr.flush()
            _s.exit({int(exit_code)})
            """
        )
    )
    shim.chmod(0o755)
    return shim


def _make_issue_798_scheduler_shim(tmp_path) -> Path:
    """Fake pdd executable that reproduces the #798 sync schedule."""
    shim = tmp_path / "fake_pdd_issue_798"
    shim.write_text(
        f"#!{sys.executable}\n"
        + textwrap.dedent(
            """\
            import sys
            import time

            basename = ""
            if "sync" in sys.argv:
                idx = sys.argv.index("sync")
                if idx + 1 < len(sys.argv):
                    basename = sys.argv[idx + 1]

            if basename == "cli_detector":
                sys.stdout.write("Overall status: Failed\\n")
                sys.stderr.write(
                    "Architecture conformance error for "
                    "cli_detector_python.prompt: declared symbols missing "
                    "from generated code\\n"
                )
                sys.exit(1)
            if basename == "agentic_common":
                time.sleep(0.2)
                sys.stdout.write("Overall status: Success\\n")
                sys.exit(0)
            if basename == "agentic_update":
                sys.stdout.write("Overall status: Success\\n")
                sys.exit(0)
            if basename == "setup_tool":
                sys.stderr.write("setup_tool should have stayed blocked\\n")
                sys.exit(9)

            sys.stderr.write(f"unexpected basename: {basename}\\n")
            sys.exit(8)
            """
        )
    )
    shim.chmod(0o755)
    return shim


class TestAsyncSyncRunnerRunE2E:
    """End-to-end scheduler coverage with real child subprocesses."""

    def test_issue_798_failure_only_blocks_failed_dependency_dependents(self, tmp_path):
        shim = _make_issue_798_scheduler_shim(tmp_path)
        runner = AsyncSyncRunner(
            basenames=[
                "cli_detector",
                "agentic_common",
                "setup_tool",
                "agentic_update",
            ],
            dep_graph={
                "cli_detector": [],
                "agentic_common": [],
                "setup_tool": ["cli_detector"],
                "agentic_update": ["agentic_common"],
            },
            sync_options={},
            github_info=None,
            quiet=True,
        )

        with patch(
            "pdd.agentic_sync_runner._find_pdd_executable",
            return_value=str(shim),
        ):
            success, msg, cost = runner.run()

        assert not success
        assert cost == pytest.approx(0.0)
        assert runner.module_states["cli_detector"].status == "failed"
        assert runner.module_states["agentic_common"].status == "success"
        assert runner.module_states["agentic_update"].status == "success"
        assert runner.module_states["setup_tool"].status == "pending"
        assert "Skipped (blocked): ['setup_tool']" in msg
        assert "agentic_update" not in msg.split("Skipped (blocked):", 1)[-1]


class TestSyncOneModuleE2E:
    """End-to-end coverage of `_sync_one_module` with a real child process."""

    def _run(self, tmp_path, stdout_text, stderr_text, exit_code):
        shim = _make_fake_pdd_shim(tmp_path, stdout_text, stderr_text, exit_code)

        runner = AsyncSyncRunner(
            basenames=["foo"],
            dep_graph={"foo": []},
            sync_options={},
            github_info=None,
            quiet=True,
        )
        runner.module_cwds = {"foo": tmp_path}

        # `_find_pdd_executable` returns the shim → the runner spawns it
        # via real `subprocess.Popen` with all the usual args appended;
        # the shim ignores them and emits the scenario stdout/stderr.
        with patch(
            "pdd.agentic_sync_runner._find_pdd_executable",
            return_value=str(shim),
        ):
            return runner._sync_one_module("foo")

    def test_e2e_cloud_run_pattern_from_issue_1399(self, tmp_path):
        """Verbatim cloud-run output from issue #1399 with a real
        subprocess. Headline must NOT be the ContentSelector warning."""
        success, cost, error = self._run(
            tmp_path,
            stdout_text=(
                'Warning: ContentSelector failed for select='
                '"class:AsyncSyncRunner,def:_find_pdd_executable" — falling back\n'
                'Warning: ContentSelector failed for select='
                '"def:build_dependency_graph,def:extract_module_from_include,'
                'def:topological_sort" — falling back\n'
                "PDD command failed with exit code 1\n"
            ),
            stderr_text="",
            exit_code=1,
        )
        assert not success
        assert "ContentSelector failed for select=" not in error, (
            f"E2E: warning must not pollute headline; got:\n{error!r}"
        )
        assert "Exit code 1" in error, (
            f"E2E: deterministic failure reason must lead headline; got:\n{error!r}"
        )
        assert "PDD command failed with exit code 1" in error, (
            f"E2E: real failure line must be preserved; got:\n{error!r}"
        )

    def test_e2e_real_traceback_in_stderr(self, tmp_path):
        """Real Python traceback in stderr + ContentSelector warning in
        stdout, with a real subprocess. Traceback must dominate."""
        success, cost, error = self._run(
            tmp_path,
            stdout_text=(
                'Warning: ContentSelector failed for select="class:Foo" — falling back\n'
            ),
            stderr_text=(
                "Traceback (most recent call last):\n"
                '  File "x.py", line 1, in <module>\n'
                "RuntimeError: e2e generation step failed\n"
            ),
            exit_code=1,
        )
        assert not success
        assert "RuntimeError: e2e generation step failed" in error
        assert "ContentSelector failed for select=" not in error
        assert error.startswith("Exit code 1"), (
            f"E2E: headline must lead with deterministic failure reason; got:\n{error!r}"
        )

    def test_e2e_overall_status_failed_not_duplicated(self, tmp_path):
        """End-to-end dedupe guard: `Overall status: Failed` appears
        exactly once even with a real child process."""
        success, cost, error = self._run(
            tmp_path,
            stdout_text=(
                'Warning: ContentSelector failed for select="class:Foo" — falling back\n'
                "Overall status: Failed\n"
            ),
            stderr_text="",
            exit_code=0,
        )
        assert not success
        assert error.count("Overall status: Failed") == 1, (
            f"E2E: must appear exactly once; got:\n{error!r}"
        )

    def test_e2e_labeled_tails_when_no_high_signal_line(self, tmp_path):
        """End-to-end fallback: when no high-signal line exists, output
        must include labeled stderr/stdout tail blocks."""
        success, cost, error = self._run(
            tmp_path,
            stdout_text=(
                'Warning: ContentSelector failed for select="def:topological_sort" — falling back\n'
                "Working on module foo\n"
                "Done preprocessing\n"
            ),
            stderr_text="some stderr context line\n",
            exit_code=2,
        )
        assert not success
        assert "ContentSelector failed for select=" not in error
        assert "Exit code 2" in error
        assert "--- stderr tail ---" in error
        assert "--- stdout tail ---" in error
        assert "some stderr context line" in error
        assert "Working on module foo" in error or "Done preprocessing" in error

    def test_e2e_success_with_warning_does_not_set_error(self, tmp_path):
        """End-to-end success path: a benign ContentSelector warning on
        a successful child run must NOT flip success or pollute error."""
        success, cost, error = self._run(
            tmp_path,
            stdout_text=(
                'Warning: ContentSelector failed for select="class:Foo" — falling back\n'
                "Overall status: Success\n"
            ),
            stderr_text="",
            exit_code=0,
        )
        assert success
        assert error == ""
