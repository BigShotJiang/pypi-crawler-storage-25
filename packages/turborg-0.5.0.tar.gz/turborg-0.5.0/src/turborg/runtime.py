# SPDX-License-Identifier: Apache-2.0
"""Runtime builder — assemble a runnable agent from settings.

Used by ``turborg run`` and any caller who wants the same default wiring
without re-deriving it. The agent works **standalone** (only IRC env
vars set); LLM-backed commands like ``!ask`` register only when an
Anthropic API key is configured, so the bot never crashes for lack of
one.
"""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from typing import Any

from turborg import __version__
from turborg.config.settings import Settings
from turborg.connectors.irc.bouncer import Bouncer
from turborg.connectors.irc.connector import IRCConnector
from turborg.connectors.irc.ratelimit import RateLimiter
from turborg.connectors.irc.settings import IRCSettings
from turborg.core.agent import Agent
from turborg.core.envelope import InboundEnvelope, OutboundEnvelope
from turborg.llm.anthropic import AnthropicProvider

logger = logging.getLogger(__name__)


_ASK_SYSTEM_PROMPT = (
    "You are turborg, an IRC chatbot. Keep replies short and conversational — "
    "most IRC clients show one line at a time. Avoid markdown."
)


def build_agent_from_settings(
    settings: Settings | None = None,
    irc_settings: IRCSettings | None = None,
) -> Agent:
    """Build a fully-wired :class:`Agent` from environment-derived settings.

    Behavior:

    - Always registers the IRC connector and built-in commands (``!ping``,
      ``!version``).
    - If ``settings.anthropic_api_key`` is set, also wires
      :class:`AnthropicProvider` and registers the LLM-backed ``!ask``
      command. Otherwise the agent runs in **standalone** mode with no LLM.

    Pass explicit ``settings`` / ``irc_settings`` to override env loading
    (handy in tests).
    """
    settings = settings or Settings()
    # mypy doesn't know pydantic-settings loads required fields from env at runtime.
    irc_settings = irc_settings or IRCSettings()  # type: ignore[call-arg]

    llm: AnthropicProvider | None = None
    if settings.anthropic_api_key is not None:
        llm = AnthropicProvider.from_settings(settings)

    bouncer: Bouncer | None = None
    if irc_settings.bouncer_password is not None:
        rate_limiter: RateLimiter | None = None
        if irc_settings.bouncer_ratelimit_enabled:
            rate_limiter = RateLimiter(
                max_failures=irc_settings.bouncer_max_failed_attempts,
                window_seconds=irc_settings.bouncer_failure_window_seconds,
                lockout_seconds=irc_settings.bouncer_lockout_seconds,
            )
        bouncer = Bouncer(
            password=irc_settings.bouncer_password.get_secret_value(),
            host=irc_settings.bouncer_host,
            port=irc_settings.bouncer_port,
            rate_limiter=rate_limiter,
        )

    agent = Agent(command_prefix=settings.command_prefix, llm=llm)
    agent.add_connector(IRCConnector(irc_settings, bouncer=bouncer, events=agent.events))
    register_builtin_commands(agent)
    return agent


def build_web_gateway(agent: Agent, settings: Settings) -> object | None:
    """Build a :class:`turborg.web.gateway.WebGateway` if a web password is
    configured. Returns ``None`` to disable the gateway.

    Imported lazily so the ``[web]`` extra is only required when the gateway
    is actually enabled — installing turborg without ``fastapi``/``uvicorn``
    must still let ``turborg run`` start a bouncer/IRC-only agent.
    """
    if settings.web_password is None:
        return None
    from turborg.connectors.irc.connector import IRCConnector
    from turborg.web.auth import StaticPasswordVerifier
    from turborg.web.gateway import WebGateway

    irc = agent.get_connector("irc")
    if not isinstance(irc, IRCConnector):
        return None
    verifier = StaticPasswordVerifier(settings.web_password.get_secret_value())
    rate_limiter = RateLimiter(
        max_failures=settings.web_max_failed_attempts,
        window_seconds=settings.web_failure_window_seconds,
        lockout_seconds=settings.web_lockout_seconds,
    )
    # Idle shutdown: when configured, the agent + gateway both wind down
    # after ``web_idle_shutdown_seconds`` of zero connected WS clients. The
    # CLI's TaskGroup observes both stopping and the process exits.
    on_idle_shutdown: Callable[[], Awaitable[None]] | None = None
    if settings.web_idle_shutdown_seconds is not None:
        gateway_ref: list[Any] = []  # filled in below

        async def _shutdown_for_idle() -> None:
            await agent.stop()
            if gateway_ref:
                await gateway_ref[0].stop()

        on_idle_shutdown = _shutdown_for_idle

    gateway = WebGateway(
        agent=agent,
        irc_connector=irc,
        verifier=verifier,
        host=settings.web_host,
        port=settings.web_port,
        rate_limiter=rate_limiter,
        idle_shutdown_seconds=settings.web_idle_shutdown_seconds,
        on_idle_shutdown=on_idle_shutdown,
    )
    if on_idle_shutdown is not None:
        gateway_ref.append(gateway)
    return gateway


def register_builtin_commands(agent: Agent) -> None:
    """Register turborg's always-on commands and, when an LLM is wired,
    the ``!ask`` command."""

    @agent.on_command("ping")
    async def _ping(envelope: InboundEnvelope) -> OutboundEnvelope:
        return OutboundEnvelope.reply(envelope, "pong")

    @agent.on_command("version")
    async def _version(envelope: InboundEnvelope) -> OutboundEnvelope:
        return OutboundEnvelope.reply(envelope, f"turborg {__version__}")

    if agent.llm is not None:
        llm = agent.llm

        @agent.on_command("ask")
        async def _ask(envelope: InboundEnvelope) -> OutboundEnvelope:
            question = " ".join(envelope.args).strip()
            if not question:
                return OutboundEnvelope.reply(envelope, "usage: !ask <question>")
            try:
                answer = await llm.ask(question, system=_ASK_SYSTEM_PROMPT, max_tokens=512)
            except Exception as exc:
                logger.exception("LLM call failed")
                return OutboundEnvelope.reply(envelope, f"sorry, that broke: {exc}")
            return OutboundEnvelope.reply(envelope, " ".join(answer.split()))
