# SPDX-License-Identifier: Apache-2.0
"""IRC numeric replies and standard commands.

Numerics defined by RFC 1459 / 2812 are referenced by enum members rather
than magic strings throughout the connector. We only enumerate the codes
turborg actually inspects — there are hundreds of others, and the parser
keeps them as raw strings.
"""

from __future__ import annotations

from enum import StrEnum


class IRCNumeric(StrEnum):
    """Numeric replies the connector recognizes during the protocol handshake."""

    RPL_WELCOME = "001"
    RPL_YOURHOST = "002"
    RPL_CREATED = "003"
    RPL_MYINFO = "004"
    RPL_WHOISUSER = "311"
    RPL_WHOISSERVER = "312"
    RPL_WHOISOPERATOR = "313"
    RPL_WHOISIDLE = "317"
    RPL_ENDOFWHOIS = "318"
    RPL_WHOISCHANNELS = "319"
    RPL_NOTOPIC = "331"
    RPL_TOPIC = "332"
    RPL_TOPICWHOTIME = "333"
    RPL_WHOISACCOUNT = "330"
    RPL_NAMREPLY = "353"
    RPL_ENDOFNAMES = "366"
    RPL_ENDOFMOTD = "376"
    RPL_WHOISSECURE = "671"

    ERR_NOSUCHNICK = "401"
    ERR_NOMOTD = "422"
    ERR_NICKNAMEINUSE = "433"
    ERR_NOTREGISTERED = "451"
    ERR_PASSWDMISMATCH = "464"


class IRCCommand(StrEnum):
    """Commands turborg sends or recognizes on the wire."""

    PRIVMSG = "PRIVMSG"
    NOTICE = "NOTICE"
    JOIN = "JOIN"
    PART = "PART"
    QUIT = "QUIT"
    NICK = "NICK"
    USER = "USER"
    PASS = "PASS"  # noqa: S105 — IRC command name, not a literal password
    PING = "PING"
    PONG = "PONG"
    MODE = "MODE"
    TOPIC = "TOPIC"
    KICK = "KICK"
    NAMES = "NAMES"
    CAP = "CAP"
    WHOIS = "WHOIS"
    INVITE = "INVITE"
    AWAY = "AWAY"


HANDSHAKE_COMPLETE: frozenset[str] = frozenset({IRCNumeric.RPL_ENDOFMOTD, IRCNumeric.ERR_NOMOTD})
"""Numerics that signal the server has finished sending its MOTD and the
connection is ready for normal traffic."""
