# SPDX-License-Identifier: Apache-2.0
"""Optional IRC bouncer.

Lets IRC clients (HexChat, irssi, mIRC, ...) connect to the agent as if it
were an IRC server. After PASS auth, the client gets a state replay
(synthetic JOIN, RPL_TOPIC, RPL_NAMREPLY for every channel the bot is
currently in), then the client's messages are forwarded upstream and every
line received from upstream is broadcast to all connected clients. The
agent stays in control while a human can lurk and send alongside it.

IRCv3 capability negotiation is handled minimally: ``CAP LS`` returns an
empty capability list and ``CAP REQ`` is NAKed, so clients fall back to
plain RFC 1459 registration. No SASL, no channel keys, no PRIVMSG
backlog yet — those are future work.
"""

from __future__ import annotations

import asyncio
import logging
from asyncio import StreamReader, StreamWriter
from collections.abc import Awaitable, Callable

from turborg.connectors.irc.codes import IRCCommand
from turborg.connectors.irc.protocol import IRCMessage, parse
from turborg.connectors.irc.ratelimit import RateLimiter
from turborg.connectors.irc.state import ChannelState
from turborg.core.exceptions import ConnectorError

logger = logging.getLogger(__name__)


def _peer_ip(client: BouncerClient) -> str | None:
    """Best-effort IP for ``client``. ``peername`` is a (host, port) tuple
    on TCP sockets; ``None`` for transports that don't expose one."""
    addr = client.address
    if isinstance(addr, tuple) and addr:
        return str(addr[0])
    return None


_REQUIRES_TARGET: frozenset[str] = frozenset(
    {
        IRCCommand.PRIVMSG,
        IRCCommand.NOTICE,
        IRCCommand.JOIN,
        IRCCommand.PART,
        IRCCommand.MODE,
        IRCCommand.TOPIC,
        IRCCommand.KICK,
        IRCCommand.NAMES,
    }
)
"""Forwardable commands that need a target (channel/user). NICK is the
exception — it carries the new nick as its single param."""


def _is_well_formed(message: IRCMessage) -> bool:
    """Reject forwardable commands that would obviously error upstream.

    Mostly catches irssi's habit of sending an empty ``JOIN :`` after
    reconnect, which Libera answers with a 403 that then lands in every
    bouncer client's window. Better to drop on the way out.
    """
    if message.command == IRCCommand.NICK:
        return bool(message.params or message.trailing)
    if message.command in _REQUIRES_TARGET:
        return bool(message.params and message.params[0])
    return True


_FORWARDABLE_COMMANDS: frozenset[str] = frozenset(
    {
        IRCCommand.PRIVMSG,
        IRCCommand.NOTICE,
        IRCCommand.JOIN,
        IRCCommand.PART,
        IRCCommand.MODE,
        IRCCommand.TOPIC,
        IRCCommand.KICK,
        IRCCommand.NICK,
        IRCCommand.NAMES,
    }
)
"""Commands that bouncer clients are allowed to forward upstream."""


class BouncerClient:
    """One TCP client connected to the bouncer."""

    def __init__(self, reader: StreamReader, writer: StreamWriter) -> None:
        self._reader = reader
        self._writer = writer
        self.authenticated = False
        self.address = writer.get_extra_info("peername")

    async def send_line(self, line: str) -> None:
        if self._writer.is_closing():
            return
        self._writer.write(f"{line.rstrip()}\r\n".encode())
        await self._writer.drain()

    async def read_line(self) -> str | None:
        raw = await self._reader.readline()
        if not raw:
            return None
        return raw.decode("utf-8", errors="replace").rstrip("\r\n")

    async def close(self) -> None:
        if not self._writer.is_closing():
            self._writer.close()
        try:
            await self._writer.wait_closed()
        except Exception:
            logger.debug("Error closing bouncer client", exc_info=True)


class Bouncer:
    """A TCP server that bridges IRC clients into the agent's connection."""

    def __init__(
        self,
        *,
        password: str,
        host: str = "127.0.0.1",
        port: int = 31337,
        rate_limiter: RateLimiter | None = None,
    ) -> None:
        if not password:
            raise ConnectorError("Bouncer password cannot be empty.")
        self.host = host
        self.port = port
        self._password = password
        self._rate_limiter = rate_limiter
        self._clients: set[BouncerClient] = set()
        self._server: asyncio.Server | None = None
        self._send_upstream: Callable[[str], Awaitable[None]] | None = None
        self._on_forwarded_message: Callable[[str, str, str, str], Awaitable[None]] | None = None
        self._channel_state: ChannelState | None = None
        self._upstream_nick: str = ""
        self._upstream_ident: str = ""
        self._upstream_host: str = "turborg"

    @property
    def clients(self) -> frozenset[BouncerClient]:
        return frozenset(self._clients)

    def attach_upstream(self, send: Callable[[str], Awaitable[None]]) -> None:
        """Wire the function used to forward authenticated client lines to
        the real IRC server."""
        self._send_upstream = send

    def attach_outbound_observer(
        self, callback: Callable[[str, str, str, str], Awaitable[None]]
    ) -> None:
        """Register ``callback`` to fire when a bouncer client tunnels a
        PRIVMSG/NOTICE upstream. Args: ``(channel, sender, text, kind)``.

        The connector uses this to re-publish the message on the agent's
        EventBus as ``MESSAGE_SENT`` so subscribers (e.g. the WS gateway)
        see what bouncer clients send — IRC servers don't echo your own
        traffic back, so without this hook those messages would be
        invisible to anything that isn't another bouncer client.
        """
        self._on_forwarded_message = callback

    def attach_state(
        self,
        state: ChannelState,
        *,
        nick: str,
        ident: str,
        host: str = "turborg",
    ) -> None:
        """Bind a live :class:`ChannelState` plus the upstream identity used
        when crafting synthetic JOIN lines for state replay. Connect-time
        only — the connector calls this before :meth:`start`.
        """
        self._channel_state = state
        self._upstream_nick = nick
        self._upstream_ident = ident
        self._upstream_host = host

    def update_upstream_nick(self, nick: str) -> None:
        """Notify the bouncer that the bot's upstream nick changed (e.g. a
        connected client did ``/nick``, which got forwarded and accepted by
        the server). Subsequent prefix-prepended broadcasts use the new
        nick so other clients see the message attributed to the right user.
        """
        self._upstream_nick = nick

    def update_upstream_identity(self, *, ident: str, host: str) -> None:
        """Pin the ident/host the network actually assigned to the bot.

        The connector calls this after observing a self-prefixed message —
        the very first echo of our JOIN/PRIVMSG/etc. carries the real
        ``nick!ident@host``. Using the real values here means that when
        the bouncer fans out a message to other clients (or echoes the
        bot's own PRIVMSG via :meth:`broadcast_as_self`), the prefix
        matches what the client expects to see for its own user. Without
        this, clients like HexChat misroute self-PRIVMSGs because the
        ``ident@host`` doesn't match their own user record.
        """
        self._upstream_ident = ident
        self._upstream_host = host

    async def start(self) -> None:
        self._server = await asyncio.start_server(self._handle_client, self.host, self.port)
        logger.info("Bouncer listening on %s:%d", self.host, self.port)

    async def stop(self) -> None:
        # Close clients BEFORE the listener. asyncio.Server.wait_closed()
        # blocks until every active connection drains, so leaving sockets
        # open at this point makes shutdown hang until the OS times out
        # (which can be minutes). Same gotcha CLAUDE.md flags for the fake
        # IRC server tests.
        for client in list(self._clients):
            await client.close()
        self._clients.clear()
        if self._server is not None:
            self._server.close()
            try:
                await self._server.wait_closed()
            except Exception:
                logger.debug("Error closing bouncer server", exc_info=True)
            self._server = None

    async def broadcast(self, line: str, *, exclude: object = None) -> None:
        """Send ``line`` to every authenticated client except ``exclude``."""
        if not self._clients:
            return
        for client in list(self._clients):
            if client is exclude or not client.authenticated:
                continue
            try:
                await client.send_line(line)
            except Exception:
                logger.debug("Dropping disconnected bouncer client", exc_info=True)
                self._clients.discard(client)

    async def broadcast_as_self(self, line: str, *, exclude: object = None) -> None:
        """Broadcast ``line`` with the bot's prefix prepended.

        IRC servers don't echo the sender's own PRIVMSG/NOTICE back, so the
        bouncer needs to fan out outgoing messages itself — both for traffic
        the bot initiates (e.g. ``!ping`` reply) and for traffic a connected
        client sends through the bouncer (one HexChat user typing while
        another irssi client is also connected). Without the prefix, clients
        render the line as if it came from the server.
        """
        if self._upstream_nick:
            prefix = f":{self._upstream_nick}!{self._upstream_ident}@{self._upstream_host}"
            line = f"{prefix} {line}"
        await self.broadcast(line, exclude=exclude)

    async def _handle_client(self, reader: StreamReader, writer: StreamWriter) -> None:
        client = BouncerClient(reader, writer)
        self._clients.add(client)
        logger.info("Bouncer client connected: %s", client.address)
        try:
            while True:
                line = await client.read_line()
                if line is None:
                    break
                await self._handle_line(client, line)
        except Exception:
            logger.debug("Bouncer client errored", exc_info=True)
        finally:
            self._clients.discard(client)
            await client.close()
            logger.info("Bouncer client disconnected: %s", client.address)

    async def _handle_line(self, client: BouncerClient, line: str) -> None:
        message = parse(line)
        logger.debug(
            "Bouncer recv (auth=%s) cmd=%r params=%r raw=%r",
            client.authenticated,
            message.command,
            message.params,
            line,
        )
        if message.command == IRCCommand.PASS:
            await self._handle_pass(client, message.params)
            return
        if message.command == IRCCommand.PING:
            # Reply locally — never forward upstream. Without this, clients
            # like irssi disconnect after ~5 min waiting for a PONG. Works
            # pre- and post-auth; PING-PONG does not gate on registration.
            cookie = message.trailing or (message.params[0] if message.params else "")
            await client.send_line(f":turborg-bouncer PONG turborg-bouncer :{cookie}")
            return
        if not client.authenticated:
            if message.command == IRCCommand.CAP:
                await self._handle_cap(client, message)
            # Silently drop everything else pre-auth. Real clients (irssi,
            # HexChat, weechat) all send a slightly different bag of pre-auth
            # commands — JOIN, NICK, USER, MODE, WHOIS, ... — before PASS lands.
            # Closing the link on the first one rejected too many of them.
            # The connection stays open until PASS arrives or the client hangs
            # up. With the default bind on 127.0.0.1 the DoS surface is moot.
            return
        if message.command in _FORWARDABLE_COMMANDS and self._send_upstream is not None:
            if not _is_well_formed(message):
                # E.g. irssi's empty 'JOIN :' that produced 461/403 noise.
                # Drop it instead of forwarding garbage upstream.
                return
            await self._send_upstream(line)
            # PRIVMSG / NOTICE aren't echoed back by the upstream server, so
            # other connected clients would never see the line otherwise.
            # Other forwardable commands (JOIN/PART/MODE/...) are echoed by
            # the server and reach clients via the normal _after_raw path.
            if message.command in {IRCCommand.PRIVMSG, IRCCommand.NOTICE}:
                await self.broadcast_as_self(line, exclude=client)
                # Notify non-bouncer subscribers (WS gateway, agent handlers)
                # via MESSAGE_SENT — they're not on the broadcast list.
                if self._on_forwarded_message is not None and message.params:
                    channel = message.params[0]
                    text = message.trailing
                    sender = self._upstream_nick or "*"
                    await self._on_forwarded_message(channel, sender, text, str(message.command))

    async def _handle_pass(self, client: BouncerClient, params: tuple[str, ...]) -> None:
        ip = _peer_ip(client)
        ip_label = ip or "unknown"
        if self._rate_limiter is not None and ip is not None:
            remaining = self._rate_limiter.time_until_unlock(ip)
            if remaining is not None:
                logger.warning(
                    "bouncer.auth ip=%s result=blocked remaining=%.0fs",
                    ip,
                    remaining,
                    extra={
                        "event": "bouncer.auth",
                        "ip": ip,
                        "result": "blocked",
                        "remaining_seconds": round(remaining, 1),
                    },
                )
                await client.send_line("ERROR :Closing Link (Too many attempts)")
                await client.close()
                return
        if params and params[0] == self._password:
            client.authenticated = True
            if self._rate_limiter is not None and ip is not None:
                self._rate_limiter.record_success(ip)
            logger.info(
                "bouncer.auth ip=%s result=success",
                ip_label,
                extra={"event": "bouncer.auth", "ip": ip_label, "result": "success"},
            )
            target = self._upstream_nick or "*"
            await client.send_line(f":turborg-bouncer 001 {target} :Welcome to the turborg bouncer")
            await self._replay_state(client)
            return
        if self._rate_limiter is not None and ip is not None:
            outcome = self._rate_limiter.record_failure(ip)
            if outcome.locked:
                logger.warning(
                    "bouncer.auth ip=%s result=lockout duration=%.0fs",
                    ip,
                    self._rate_limiter.lockout_seconds,
                    extra={
                        "event": "bouncer.auth",
                        "ip": ip,
                        "result": "lockout",
                        "lockout_seconds": int(self._rate_limiter.lockout_seconds),
                    },
                )
            else:
                logger.info(
                    "bouncer.auth ip=%s result=fail count=%d/%d window=%ds",
                    ip,
                    outcome.count,
                    self._rate_limiter.max_failures,
                    int(self._rate_limiter.window_seconds),
                    extra={
                        "event": "bouncer.auth",
                        "ip": ip,
                        "result": "fail",
                        "fail_count": outcome.count,
                        "fail_threshold": self._rate_limiter.max_failures,
                        "window_seconds": int(self._rate_limiter.window_seconds),
                    },
                )
        else:
            logger.info(
                "bouncer.auth ip=%s result=fail",
                ip_label,
                extra={"event": "bouncer.auth", "ip": ip_label, "result": "fail"},
            )
        await client.send_line("ERROR :Closing Link (Bad password)")
        await client.close()

    async def _replay_state(self, client: BouncerClient) -> None:
        """Bring a freshly-authenticated client up to speed: synthetic JOIN
        for every channel the bot is in, plus cached topic and member list.

        Without this, the client connects to a "blank" server and only sees
        live messages — no idea what channels we're in, who's there, or what
        the topic is. With it, irssi/HexChat behave as if they had been
        connected the whole time.
        """
        state = self._channel_state
        if state is None or not self._upstream_nick:
            return
        prefix = f":{self._upstream_nick}!{self._upstream_ident}@{self._upstream_host}"
        for info in state.joined_channels():
            await client.send_line(f"{prefix} JOIN {info.name}")
            if info.topic is not None:
                await client.send_line(
                    f":turborg-bouncer 332 {self._upstream_nick} {info.name} :{info.topic}"
                )
                if info.topic_set_by is not None and info.topic_set_at is not None:
                    await client.send_line(
                        f":turborg-bouncer 333 {self._upstream_nick} {info.name} "
                        f"{info.topic_set_by} {info.topic_set_at}"
                    )
            if info.members:
                names = " ".join(f"{p}{n}" for n, p in info.members.items())
                await client.send_line(
                    f":turborg-bouncer 353 {self._upstream_nick} = {info.name} :{names}"
                )
            await client.send_line(
                f":turborg-bouncer 366 {self._upstream_nick} {info.name} :End of /NAMES list"
            )

    async def _handle_cap(self, client: BouncerClient, message: IRCMessage) -> None:
        """Reply to CAP so IRCv3 clients don't stall waiting for the bouncer.

        We advertise no capabilities — clients fall back to plain RFC 1459
        registration (PASS/NICK/USER) which is what the bouncer supports.
        """
        sub = message.params[0].upper() if message.params else ""
        if sub == "LS":
            await client.send_line(":turborg-bouncer CAP * LS :")
        elif sub == "REQ":
            requested = message.trailing or (
                " ".join(message.params[1:]) if len(message.params) > 1 else ""
            )
            await client.send_line(f":turborg-bouncer CAP * NAK :{requested}")
        # CAP END / LIST / ACK from clients have no meaningful pre-auth reply.
