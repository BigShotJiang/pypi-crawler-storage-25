# SPDX-License-Identifier: Apache-2.0
"""IRC-specific settings, loaded from ``TURBORG_IRC_*`` env vars."""

from __future__ import annotations

from pydantic import Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class IRCSettings(BaseSettings):
    """Per-connector IRC settings.

    ``hostname`` and ``nick`` are required; everything else has sensible
    defaults. Channel names without a leading ``#`` are normalized.
    """

    model_config = SettingsConfigDict(
        env_prefix="TURBORG_IRC_",
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    hostname: str
    port: int = 6697
    use_tls: bool = True

    nick: str
    """The nickname turborg registers with the server."""

    username: str | None = None
    """USER ident; defaults to :attr:`nick` if omitted."""

    real_name: str = "turborg agent"
    """The free-form 'real name' field shown on WHOIS."""

    server_password: SecretStr | None = None
    """Optional PASS sent during registration."""

    nickserv_password: SecretStr | None = None
    """If set, ``PRIVMSG NickServ :IDENTIFY <password>`` is sent right after
    the handshake completes (before joining channels). Use this on networks
    where the bot's nick is registered."""

    channels: list[str] = Field(default_factory=list)
    """Channels to join after handshake completes. ``#`` prefix added if missing."""

    handshake_timeout: float = 30.0
    """Seconds to wait for RPL_ENDOFMOTD / ERR_NOMOTD before giving up."""

    bouncer_password: SecretStr | None = None
    """If set, the IRC connector starts a turborg bouncer (a small TCP server)
    alongside the upstream connection. Local clients can connect, authenticate
    with this password, and tunnel through the bot's session — the bot stays
    in control while you can lurk and send lines from your own client.
    ``None`` disables the bouncer."""

    bouncer_host: str = "127.0.0.1"
    """Interface the bouncer listens on. ``127.0.0.1`` keeps it local-only
    (recommended); ``0.0.0.0`` exposes it on every interface."""

    bouncer_port: int = 31337
    """Port the bouncer listens on."""

    bouncer_ratelimit_enabled: bool = True
    """When the bouncer is enabled, limit per-IP PASS attempts. Turn this
    off only for tests against the bouncer or behind a network you fully
    trust."""

    bouncer_max_failed_attempts: int = 5
    """Failed PASS attempts allowed within ``bouncer_failure_window_seconds``
    before the source IP is locked out."""

    bouncer_failure_window_seconds: int = 60
    """Sliding-window duration for counting PASS failures."""

    bouncer_lockout_seconds: int = 300
    """How long an IP stays locked out after exceeding the failure threshold."""

    def normalized_channels(self) -> list[str]:
        """Return channels with the ``#`` prefix added where missing."""
        return [c if c.startswith(("#", "&", "+", "!")) else f"#{c}" for c in self.channels]

    def effective_username(self) -> str:
        return self.username or self.nick
