# SPDX-License-Identifier: Apache-2.0
"""IRC connector — translates IRC messages to/from turborg envelopes.

Handshake flow:

1. ``start()`` opens the TCP connection.
2. Sends optional ``PASS``, then ``NICK`` and ``USER``.
3. Reads lines until it sees ``RPL_ENDOFMOTD`` (376) or ``ERR_NOMOTD`` (422).
4. Joins configured channels.
5. Spawns a background reader task; ``start()`` returns.

After ``start()`` returns, the connector behaves as an async iterator that
yields :class:`InboundEnvelope` per ``PRIVMSG`` received. Server pings are
answered automatically, never seen by the agent. ``stop()`` closes the
connection and unblocks any pending iteration.

If a :class:`~turborg.connectors.irc.bouncer.Bouncer` is supplied, every
raw line received is broadcast to bouncer clients, and lines from
authenticated bouncer clients are forwarded upstream.
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, ClassVar

from turborg.connectors.base import Connector
from turborg.connectors.irc.client import IRCClient
from turborg.connectors.irc.codes import HANDSHAKE_COMPLETE, IRCCommand, IRCNumeric
from turborg.connectors.irc.protocol import IRCMessage, format_command, parse
from turborg.connectors.irc.settings import IRCSettings
from turborg.connectors.irc.state import ChannelState
from turborg.core.envelope import InboundEnvelope, OutboundEnvelope
from turborg.core.events import EventBus, EventType
from turborg.core.exceptions import ConnectorError

if TYPE_CHECKING:
    from turborg.connectors.irc.bouncer import Bouncer

logger = logging.getLogger(__name__)


_WELCOME_NUMERICS: frozenset[str] = frozenset({"001", "002", "003", "004", "005"})
_LUSER_NUMERICS: frozenset[str] = frozenset({"251", "252", "253", "254", "255", "265", "266"})
_MOTD_NUMERICS: frozenset[str] = frozenset({"372", "375", "376", "422"})
_ERROR_NUMERICS: frozenset[str] = frozenset({"433", "451", "464"})


def _server_notice_kind(message: IRCMessage) -> str | None:
    """Return a ``SERVER_NOTICE`` kind for ``message`` if it's server-level
    chatter the UI's "server" tab should render — else ``None``.

    Targeted whitelist: RPL_WELCOME family, LUSER counts, MOTD lines, and
    a few ERR_* numerics worth flagging. Plus any NOTICE whose source is
    a server name (no ``!`` in the prefix). Channel/topic numerics are
    deliberately excluded — those have their own typed events."""
    cmd = message.command
    if cmd in _WELCOME_NUMERICS:
        return "welcome"
    if cmd in _LUSER_NUMERICS:
        return "info"
    if cmd in _MOTD_NUMERICS:
        return "motd"
    if cmd in _ERROR_NUMERICS:
        return "error"
    if cmd == IRCCommand.NOTICE and message.prefix and "!" not in message.prefix:
        return "notice"
    return None


class IRCConnector(Connector):
    """:class:`Connector` implementation for IRC."""

    name: ClassVar[str] = "irc"

    def __init__(
        self,
        settings: IRCSettings,
        *,
        instance: str = "default",
        bouncer: Bouncer | None = None,
        client: IRCClient | None = None,
        events: EventBus | None = None,
    ) -> None:
        self.settings = settings
        self.instance = instance
        self.bouncer = bouncer
        self._client: IRCClient = client or IRCClient(
            host=settings.hostname, port=settings.port, use_tls=settings.use_tls
        )
        self._inbox: asyncio.Queue[InboundEnvelope | None] = asyncio.Queue()
        self._reader_task: asyncio.Task[None] | None = None
        self._stopped = False
        self._state: ChannelState = ChannelState()
        self._current_nick: str = settings.nick
        self._events: EventBus | None = events
        # Pending WHOIS replies — accumulated until RPL_ENDOFWHOIS arrives.
        # Keyed by lowercased nick to be case-insensitive across networks.
        self._whois_pending: dict[str, dict[str, object]] = {}

    @property
    def current_nick(self) -> str:
        """The bot's currently-active nick. Equals ``settings.nick`` until a
        NICK change is observed on the wire (e.g. a connected bouncer client
        renamed us)."""
        return self._current_nick

    @property
    def channel_state(self) -> ChannelState:
        """Live channel-state cache observed from server messages — joined
        channels, topics, and member lists. The bouncer replays this to new
        clients on auth."""
        return self._state

    @property
    def client(self) -> IRCClient:
        return self._client

    async def start(self) -> None:
        if self._reader_task is not None:
            raise ConnectorError("IRCConnector is already started.")
        if self.bouncer is not None:
            self.bouncer.attach_upstream(self._client.send_line)
            self.bouncer.attach_state(
                self._state,
                nick=self.settings.nick,
                ident=self.settings.effective_username(),
            )
            self.bouncer.attach_outbound_observer(self._on_bouncer_outbound)
            await self.bouncer.start()
        await self._publish(
            EventType.SERVER_NOTICE,
            f"Connecting to {self.settings.hostname}:{self.settings.port}"
            f" (TLS={self.settings.use_tls})",
            "info",
        )
        await self._client.connect()
        await self._register()
        await asyncio.wait_for(self._await_handshake(), timeout=self.settings.handshake_timeout)
        await self._publish(
            EventType.SERVER_NOTICE,
            f"Connected to {self.settings.hostname} as {self._current_nick}",
            "info",
        )
        if self.settings.nickserv_password is not None:
            await self._client.send_line(
                format_command(
                    IRCCommand.PRIVMSG,
                    "NickServ",
                    trailing=f"IDENTIFY {self.settings.nickserv_password.get_secret_value()}",
                )
            )
        for channel in self.settings.normalized_channels():
            await self._client.send_line(format_command(IRCCommand.JOIN, channel))
        self._reader_task = asyncio.create_task(self._read_loop(), name=f"irc:{self.instance}:read")

    async def stop(self) -> None:
        if self._stopped:
            return
        self._stopped = True
        if self._client.connected:
            try:
                await self._client.send_line(
                    format_command(IRCCommand.QUIT, trailing="turborg shutting down")
                )
            except Exception:
                logger.debug("QUIT send failed", exc_info=True)
        # Cancel the reader BEFORE disconnect. Otherwise the reader is parked
        # in readline() on a TLS socket that disconnect() is about to tear
        # down, and Python 3.12's SSL stack raises APPLICATION_DATA_AFTER_
        # CLOSE_NOTIFY when the server has already pushed bytes past close.
        # Cancelling first makes the reader exit via CancelledError, cleanly.
        if self._reader_task is not None:
            self._reader_task.cancel()
            try:
                await self._reader_task
            except asyncio.CancelledError:
                pass  # expected — we cancelled it
            except Exception:
                logger.debug("Reader task ended with unexpected error", exc_info=True)
        await self._client.disconnect()
        if self.bouncer is not None:
            await self.bouncer.stop()
        self._inbox.put_nowait(None)

    async def send(self, envelope: OutboundEnvelope) -> None:
        if not self._client.connected:
            raise ConnectorError("IRCConnector is not connected.")
        command = IRCCommand.NOTICE if envelope.metadata.get("notice") else IRCCommand.PRIVMSG
        line = format_command(command, envelope.channel, trailing=envelope.text)
        await self._client.send_line(line)
        if self.bouncer is not None:
            await self.bouncer.broadcast_as_self(line, exclude=envelope.metadata.get("source"))
        await self._publish(
            EventType.MESSAGE_SENT,
            envelope.channel,
            self._current_nick,
            envelope.text,
            command.value,
        )

    def __aiter__(self) -> IRCConnector:
        return self

    async def __anext__(self) -> InboundEnvelope:
        envelope = await self._inbox.get()
        if envelope is None:
            raise StopAsyncIteration
        return envelope

    async def _register(self) -> None:
        if self.settings.server_password is not None:
            await self._client.send_line(
                format_command(IRCCommand.PASS, self.settings.server_password.get_secret_value())
            )
        await self._client.send_line(
            format_command(
                IRCCommand.USER,
                self.settings.effective_username(),
                "0",
                "*",
                trailing=self.settings.real_name,
            )
        )
        await self._client.send_line(format_command(IRCCommand.NICK, self.settings.nick))

    async def _await_handshake(self) -> None:
        while True:
            line = await self._client.read_line()
            if line is None:
                raise ConnectorError("Server closed connection during handshake.")
            await self._after_raw(line)
            message = parse(line)
            await self._observe(message)
            if message.command == IRCCommand.PING:
                await self._handle_ping(message)
                continue
            if message.command in HANDSHAKE_COMPLETE:
                logger.info("IRC handshake complete (%s).", message.command)
                return

    async def _read_loop(self) -> None:
        try:
            while not self._stopped:
                line = await self._client.read_line()
                if line is None:
                    logger.info("IRC connection closed by server.")
                    break
                await self._after_raw(line)
                message = parse(line)
                if not message.command:
                    continue
                await self._observe(message)
                if message.command == IRCCommand.PING:
                    await self._handle_ping(message)
                    continue
                if message.command == IRCCommand.PRIVMSG:
                    self._inbox.put_nowait(self._envelope_from(message))
        except asyncio.CancelledError:
            raise
        except Exception:
            if self._stopped:
                # Half-closed sockets and SSL races are expected here.
                logger.debug("Read loop exited during shutdown")
                return
            logger.exception("IRC read loop crashed")
            raise
        finally:
            self._inbox.put_nowait(None)

    async def _handle_ping(self, message: IRCMessage) -> None:
        token = message.trailing or (message.params[0] if message.params else "")
        await self._client.send_line(format_command(IRCCommand.PONG, trailing=token))

    async def _observe(self, message: IRCMessage) -> None:
        """Update :attr:`channel_state` and publish higher-level events
        (USER_JOIN/LEAVE/NICK_CHANGE/TOPIC_CHANGED) from one server message."""
        cmd = message.command
        nick = message.source_nick
        own_nick = self._current_nick

        # Capture the upstream-assigned ident@host the first time we see a
        # message from ourselves with a full prefix. The bouncer needs this
        # so its broadcast_as_self prefix matches what the network really
        # uses — without it, clients like HexChat treat synthetic echoes as
        # "messages from a different user with my nick" and route them to
        # the wrong window.
        if (
            self.bouncer is not None
            and nick
            and nick == own_nick
            and "!" in message.prefix
            and "@" in message.prefix
        ):
            full = message.prefix.split("!", 1)[1]
            ident, _, host = full.partition("@")
            if ident and host:
                self.bouncer.update_upstream_identity(ident=ident, host=host)

        if cmd == IRCCommand.JOIN:
            target = message.params[0] if message.params else message.trailing
            if not target:
                return
            if nick == own_nick:
                self._state.on_self_join(target)
            else:
                self._state.on_member_join(target, nick)
            await self._publish(EventType.USER_JOIN, target, nick)
        elif cmd == IRCCommand.PART:
            target = message.params[0] if message.params else ""
            if not target:
                return
            reason = message.trailing
            if nick == own_nick:
                self._state.on_self_part(target)
            else:
                self._state.on_member_part(target, nick)
            await self._publish(EventType.USER_LEAVE, target, nick, reason)
        elif cmd == IRCCommand.QUIT:
            reason = message.trailing
            if nick == own_nick:
                channels = [info.name for info in self._state.joined_channels()]
                for channel in channels:
                    self._state.on_self_part(channel)
                    await self._publish(EventType.USER_LEAVE, channel, nick, reason)
            else:
                channels = [
                    info.name for info in self._state.joined_channels() if nick in info.members
                ]
                self._state.on_member_quit(nick)
                for channel in channels:
                    await self._publish(EventType.USER_LEAVE, channel, nick, reason)
        elif cmd == IRCCommand.KICK:
            if len(message.params) >= 2:
                channel, target_nick = message.params[0], message.params[1]
                self._state.on_member_kick(channel, target_nick)
                await self._publish(
                    EventType.USER_KICKED, channel, target_nick, nick, message.trailing
                )
        elif cmd == IRCCommand.NICK:
            new_nick = message.params[0] if message.params else message.trailing
            if new_nick:
                if nick == own_nick:
                    self._current_nick = new_nick
                    if self.bouncer is not None:
                        self.bouncer.update_upstream_nick(new_nick)
                self._state.on_nick_change(nick, new_nick)
                await self._publish(EventType.USER_NICK_CHANGE, nick, new_nick)
        elif cmd == IRCCommand.TOPIC:
            if message.params:
                channel = message.params[0]
                topic = message.trailing or None
                self._state.on_topic(channel, topic, set_by=nick)
                await self._publish(EventType.TOPIC_CHANGED, channel, topic, nick)
        elif cmd == IRCCommand.MODE:
            if len(message.params) >= 2:
                target = message.params[0]
                modes = message.params[1]
                args = " ".join(message.params[2:])
                # Channel-targeted MODEs may have moved a member into op/voice
                # etc. We don't reimplement the full mode-set model client-side;
                # instead, ask the server for a fresh NAMES so the canonical
                # prefixes flow back through RPL_NAMREPLY -> CHANNEL_NAMES.
                if target.startswith(("#", "&", "+", "!")) and self._client.connected:
                    try:
                        await self._client.send_line(format_command(IRCCommand.NAMES, target))
                    except Exception:
                        logger.debug("NAMES refresh after MODE failed", exc_info=True)
                await self._publish(EventType.MODE_CHANGED, target, modes, args, nick)
        elif cmd == IRCNumeric.RPL_TOPIC:
            # :server 332 mynick #channel :topic
            if len(message.params) >= 2:
                channel = message.params[1]
                topic = message.trailing or None
                self._state.on_topic(channel, topic)
                await self._publish(EventType.TOPIC_CHANGED, channel, topic, None)
        elif cmd == IRCNumeric.RPL_NOTOPIC:
            if len(message.params) >= 2:
                channel = message.params[1]
                self._state.on_topic(channel, None)
                await self._publish(EventType.TOPIC_CHANGED, channel, None, None)
        elif cmd == IRCNumeric.RPL_TOPICWHOTIME:
            # :server 333 mynick #channel setter unixtime
            if len(message.params) >= 4:
                try:
                    set_at = int(message.params[3])
                except ValueError:
                    set_at = None
                self._state.on_topic(message.params[1], set_by=message.params[2], set_at=set_at)
        elif cmd == IRCNumeric.RPL_NAMREPLY:
            # :server 353 mynick = #channel :nick1 nick2 @nick3
            if len(message.params) >= 3 and message.trailing:
                self._state.on_names_reply(message.params[2], message.trailing.split())
        elif cmd == IRCNumeric.RPL_ENDOFNAMES:
            if len(message.params) >= 2:
                channel = message.params[1]
                self._state.on_names_end(channel)
                info = self._state.get(channel)
                if info is not None:
                    members = list(info.members.items())
                    await self._publish(EventType.CHANNEL_NAMES, channel, members)
        elif cmd == IRCNumeric.RPL_WHOISUSER:
            # 311: <client> <nick> <user> <host> * :<realname>
            if len(message.params) >= 4:
                rec = self._whois_for(message.params[1])
                rec["nick"] = message.params[1]
                rec["user"] = message.params[2]
                rec["host"] = message.params[3]
                rec["realName"] = message.trailing
        elif cmd == IRCNumeric.RPL_WHOISSERVER:
            # 312: <client> <nick> <server> :<server info>
            if len(message.params) >= 3:
                rec = self._whois_for(message.params[1])
                rec["server"] = message.params[2]
                rec["serverInfo"] = message.trailing
        elif cmd == IRCNumeric.RPL_WHOISOPERATOR:
            if len(message.params) >= 2:
                rec = self._whois_for(message.params[1])
                rec["isOperator"] = True
        elif cmd == IRCNumeric.RPL_WHOISIDLE:
            # 317: <client> <nick> <seconds> [<signon>] :seconds idle, signon time
            if len(message.params) >= 3:
                rec = self._whois_for(message.params[1])
                try:
                    rec["idleSeconds"] = int(message.params[2])
                except ValueError:
                    rec["idleSeconds"] = None
                if len(message.params) >= 4:
                    try:
                        rec["signonAt"] = int(message.params[3])
                    except ValueError:
                        rec["signonAt"] = None
        elif cmd == IRCNumeric.RPL_WHOISCHANNELS:
            # 319: <client> <nick> :@#chan +#chan2
            if len(message.params) >= 2 and message.trailing:
                rec = self._whois_for(message.params[1])
                existing = rec.get("channels")
                channel_list: list[str] = list(existing) if isinstance(existing, list) else []
                channel_list.extend(message.trailing.split())
                rec["channels"] = channel_list
        elif cmd == IRCNumeric.RPL_WHOISACCOUNT:
            # 330: <client> <nick> <account> :is logged in as
            if len(message.params) >= 3:
                rec = self._whois_for(message.params[1])
                rec["account"] = message.params[2]
        elif cmd == IRCNumeric.RPL_WHOISSECURE:
            if len(message.params) >= 2:
                rec = self._whois_for(message.params[1])
                rec["secure"] = True
        elif cmd == IRCNumeric.ERR_NOSUCHNICK:
            # 401: <client> <nick> :No such nick/channel
            if len(message.params) >= 2:
                rec = self._whois_for(message.params[1])
                rec["nick"] = message.params[1]
                rec["error"] = message.trailing or "No such nick"
                await self._flush_whois(message.params[1])
        elif cmd == IRCNumeric.RPL_ENDOFWHOIS:
            if len(message.params) >= 2:
                await self._flush_whois(message.params[1])

        # Server-level surface — RPL_WELCOME family, MOTD, LUSER counts,
        # and NOTICE messages whose source is a server (no '!' in prefix).
        kind = _server_notice_kind(message)
        if kind is not None:
            text = message.trailing or " ".join(message.params[1:])
            if text:
                await self._publish(EventType.SERVER_NOTICE, text, kind)

    async def _publish(self, event_type: EventType, *args: object) -> None:
        if self._events is not None:
            await self._events.publish(event_type, *args)

    async def _on_bouncer_outbound(self, channel: str, sender: str, text: str, kind: str) -> None:
        """Re-publish a bouncer-client-tunneled PRIVMSG/NOTICE on the bus
        as MESSAGE_SENT so non-bouncer subscribers (WS gateway, etc.) see
        what other clients are saying."""
        await self._publish(EventType.MESSAGE_SENT, channel, sender, text, kind)

    def _whois_for(self, nick: str) -> dict[str, object]:
        """Return the in-progress WHOIS accumulator for ``nick`` (lowercased
        key), creating it with sensible defaults on first access."""
        key = nick.lower()
        rec = self._whois_pending.get(key)
        if rec is None:
            rec = {
                "nick": nick,
                "user": None,
                "host": None,
                "realName": None,
                "server": None,
                "serverInfo": None,
                "channels": [],
                "idleSeconds": None,
                "signonAt": None,
                "secure": False,
                "account": None,
                "isOperator": False,
                "error": None,
            }
            self._whois_pending[key] = rec
        return rec

    async def _flush_whois(self, nick: str) -> None:
        rec = self._whois_pending.pop(nick.lower(), None)
        if rec is not None:
            await self._publish(EventType.WHOIS_RESULT, rec)

    async def _after_raw(self, line: str) -> None:
        if self.bouncer is not None:
            await self.bouncer.broadcast(line)

    def _envelope_from(self, message: IRCMessage) -> InboundEnvelope:
        target = message.params[0] if message.params else ""
        is_direct = not target.startswith(("#", "&", "+", "!"))
        return InboundEnvelope(
            connector=self.name,
            connector_instance=self.instance,
            channel=message.source_nick if is_direct else target,
            sender=message.source_nick,
            text=message.trailing,
            is_direct=is_direct,
            raw=message.raw,
            metadata={"prefix": message.prefix, "tags": dict(message.tags)},
        )
