# SPDX-License-Identifier: Apache-2.0
"""IRC message parser.

Implements RFC 1459/2812 message format with IRCv3 tag support::

    [@tags ][:prefix ]command[ params...][ :trailing]

The parser is forgiving: malformed input yields an :class:`IRCMessage` with
``command=""`` rather than raising, so a single bad line does not crash the
connector.
"""

from __future__ import annotations

from dataclasses import dataclass, field

# IRCv3 tag-value escape sequences (https://ircv3.net/specs/extensions/message-tags)
_TAG_UNESCAPE = {
    r"\:": ";",
    r"\s": " ",
    r"\\": "\\",
    r"\r": "\r",
    r"\n": "\n",
}


def _unescape_tag_value(value: str) -> str:
    out: list[str] = []
    i = 0
    while i < len(value):
        if value[i] == "\\" and i + 1 < len(value):
            seq = value[i : i + 2]
            out.append(_TAG_UNESCAPE.get(seq, value[i + 1]))
            i += 2
        else:
            out.append(value[i])
            i += 1
    return "".join(out)


@dataclass(frozen=True, slots=True)
class IRCMessage:
    """A parsed IRC line."""

    raw: str
    """The original line as received, with trailing CR/LF stripped."""

    tags: dict[str, str] = field(default_factory=dict)
    """IRCv3 tags. A tag with no value is stored with an empty string value."""

    prefix: str = ""
    """The source prefix (``Nick!Ident@Host`` or server name), without the
    leading colon. Empty if absent."""

    command: str = ""
    """Uppercased command or numeric reply. Empty if the line was unparseable."""

    params: tuple[str, ...] = ()
    """Whitespace-separated parameters before the trailing argument."""

    trailing: str = ""
    """Trailing argument (everything after ``" :"``), or empty."""

    @property
    def source_nick(self) -> str:
        """Nickname extracted from :attr:`prefix`, or the prefix itself."""
        return self.prefix.split("!", 1)[0] if "!" in self.prefix else self.prefix


def parse(line: str) -> IRCMessage:
    """Parse a raw IRC line into an :class:`IRCMessage`."""
    raw = line.rstrip("\r\n")
    remaining = raw
    tags: dict[str, str] = {}
    prefix = ""

    if remaining.startswith("@"):
        tag_segment, _, remaining = remaining.partition(" ")
        for tag in tag_segment[1:].split(";"):
            if not tag:
                continue
            key, sep, value = tag.partition("=")
            tags[key] = _unescape_tag_value(value) if sep else ""
        remaining = remaining.lstrip(" ")

    if remaining.startswith(":"):
        prefix, _, remaining = remaining.partition(" ")
        prefix = prefix[1:]
        remaining = remaining.lstrip(" ")

    if not remaining:
        return IRCMessage(raw=raw, tags=tags, prefix=prefix)

    head, _, tail = remaining.partition(" :")
    parts = head.split()
    if not parts:
        return IRCMessage(raw=raw, tags=tags, prefix=prefix, trailing=tail)

    command = parts[0].upper()
    params = tuple(parts[1:])
    return IRCMessage(
        raw=raw,
        tags=tags,
        prefix=prefix,
        command=command,
        params=params,
        trailing=tail,
    )


def format_command(command: str, *params: str, trailing: str | None = None) -> str:
    """Format a command + params + optional trailing into a wire-ready line.

    The caller is responsible for not embedding ``\\r`` or ``\\n`` in the
    arguments — IRC has no escape mechanism for those in normal commands.
    """
    pieces: list[str] = [command, *params]
    if trailing is not None:
        pieces.append(":" + trailing)
    return " ".join(pieces)
