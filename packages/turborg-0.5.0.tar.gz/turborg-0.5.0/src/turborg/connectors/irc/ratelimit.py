# SPDX-License-Identifier: Apache-2.0
"""Per-IP sliding-window rate limiter for the IRC bouncer's PASS auth.

Attempts are tracked in-memory because the state is short-lived (lockouts
are typically minutes) and a single turborg process owns one TCP listener;
process restart is itself a reset. If the bouncer ever shards across
instances, replace the in-memory dicts with a shared store (Redis / DDB)
behind the same interface.
"""

from __future__ import annotations

import time
from collections import deque
from collections.abc import Callable
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class FailureResult:
    """Outcome of recording one PASS failure."""

    count: int
    """Number of failures within the active window after this one."""

    locked: bool
    """``True`` if this failure pushed the IP over the threshold."""


class RateLimiter:
    """Sliding-window per-IP failure counter with a lockout tail.

    Once an IP exceeds ``max_failures`` within any rolling ``window_seconds``,
    it is locked out for ``lockout_seconds``. Successful auth clears the
    counter for that IP.
    """

    def __init__(
        self,
        *,
        max_failures: int,
        window_seconds: float,
        lockout_seconds: float,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        if max_failures < 1:
            raise ValueError("max_failures must be >= 1")
        if window_seconds <= 0:
            raise ValueError("window_seconds must be > 0")
        if lockout_seconds <= 0:
            raise ValueError("lockout_seconds must be > 0")
        self.max_failures = max_failures
        self.window_seconds = window_seconds
        self.lockout_seconds = lockout_seconds
        self._clock = clock
        self._failures: dict[str, deque[float]] = {}
        self._locked_until: dict[str, float] = {}

    def time_until_unlock(self, ip: str) -> float | None:
        """Seconds remaining on this IP's lockout, or ``None`` if free.

        Side effect: clears the lockout entry once it has expired.
        """
        until = self._locked_until.get(ip)
        if until is None:
            return None
        remaining = until - self._clock()
        if remaining <= 0:
            del self._locked_until[ip]
            return None
        return remaining

    def is_locked(self, ip: str) -> bool:
        return self.time_until_unlock(ip) is not None

    def record_success(self, ip: str) -> None:
        """Reset all state for ``ip`` after a successful auth."""
        self._failures.pop(ip, None)
        self._locked_until.pop(ip, None)

    def record_failure(self, ip: str) -> FailureResult:
        """Record one failed attempt. Lock the IP out if it crosses the
        threshold within the active window."""
        now = self._clock()
        bucket = self._failures.setdefault(ip, deque())
        cutoff = now - self.window_seconds
        while bucket and bucket[0] < cutoff:
            bucket.popleft()
        bucket.append(now)
        count = len(bucket)
        if count >= self.max_failures:
            self._locked_until[ip] = now + self.lockout_seconds
            self._failures.pop(ip, None)
            return FailureResult(count=count, locked=True)
        return FailureResult(count=count, locked=False)
