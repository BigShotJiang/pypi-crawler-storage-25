# SPDX-License-Identifier: Apache-2.0
"""Low-level IRC TCP client.

Manages the socket, line buffering, and TLS. Knows nothing about IRC
semantics — :class:`~turborg.connectors.irc.connector.IRCConnector` builds
the protocol on top.
"""

from __future__ import annotations

import asyncio
import logging
import ssl as ssl_module
from asyncio import StreamReader, StreamWriter

from turborg.core.exceptions import ConnectorNotConnectedError

logger = logging.getLogger(__name__)


class IRCClient:
    """Asyncio-based IRC connection with optional TLS."""

    def __init__(self, host: str, port: int, *, use_tls: bool = True) -> None:
        self.host = host
        self.port = port
        self.use_tls = use_tls
        self._reader: StreamReader | None = None
        self._writer: StreamWriter | None = None

    @property
    def connected(self) -> bool:
        return self._writer is not None and not self._writer.is_closing()

    async def connect(self) -> None:
        """Open the TCP (and TLS) connection."""
        ssl_ctx: ssl_module.SSLContext | None = (
            ssl_module.create_default_context() if self.use_tls else None
        )
        logger.info("Connecting to %s:%d (TLS=%s)", self.host, self.port, self.use_tls)
        self._reader, self._writer = await asyncio.open_connection(
            host=self.host, port=self.port, ssl=ssl_ctx
        )

    async def disconnect(self) -> None:
        """Close the connection. Idempotent."""
        if self._writer is None:
            return
        if not self._writer.is_closing():
            self._writer.close()
        try:
            await self._writer.wait_closed()
        except ssl_module.SSLError:
            # Python 3.12's SSL stack races during transport close — if the
            # server pushed bytes past close_notify (Libera does, briefly),
            # _do_shutdown raises APPLICATION_DATA_AFTER_CLOSE_NOTIFY here.
            # The connection is going away anyway; suppress without trace.
            pass
        except Exception:
            logger.debug("Error during wait_closed", exc_info=True)
        self._writer = None
        self._reader = None

    async def send_line(self, line: str) -> None:
        """Write ``line`` followed by ``\\r\\n`` to the server."""
        if self._writer is None or self._writer.is_closing():
            raise ConnectorNotConnectedError("IRC client is not connected.")
        logger.debug(">> %s", line)
        self._writer.write(f"{line}\r\n".encode())
        await self._writer.drain()

    async def read_line(self) -> str | None:
        """Return the next line from the server, or ``None`` at EOF."""
        if self._reader is None:
            raise ConnectorNotConnectedError("IRC client is not connected.")
        raw = await self._reader.readline()
        if not raw:
            return None
        line = raw.decode("utf-8", errors="replace").rstrip("\r\n")
        logger.debug("<< %s", line)
        return line
