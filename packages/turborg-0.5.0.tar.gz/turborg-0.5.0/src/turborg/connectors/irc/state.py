# SPDX-License-Identifier: Apache-2.0
"""In-memory IRC channel state.

The connector observes server messages and feeds them into :class:`ChannelState`,
which the bouncer then replays to newly-connected clients so they can pick up
the bot's view of the network instead of starting from a blank slate.

State is intentionally minimal — channels we are currently in, their topic,
and their member list. No PRIVMSG backlog, no who/whois cache, no ban lists.
Channel names are case-insensitive on most networks, so they are stored
lower-cased; the original casing is preserved for replay.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class ChannelInfo:
    """Per-channel state cached from server messages."""

    name: str
    """Original-cased channel name (``#XSHELLZ-Test2``)."""

    topic: str | None = None
    topic_set_by: str | None = None
    topic_set_at: int | None = None
    members: dict[str, str] = field(default_factory=dict)
    """Member nick → mode prefix (``""`` / ``"@"`` / ``"+"`` / ``"%"`` / ``"&"`` / ``"~"``)."""

    names_complete: bool = False
    """``True`` once a full RPL_NAMREPLY/RPL_ENDOFNAMES sequence has been seen."""


_MEMBER_PREFIXES = "@+%&~"


def _split_prefix(member: str) -> tuple[str, str]:
    if member and member[0] in _MEMBER_PREFIXES:
        return member[0], member[1:]
    return "", member


_UNSET: object = object()
"""Sentinel for "leave this field as it is" in :meth:`ChannelState.on_topic`."""


class ChannelState:
    """All channels the bot is currently in, plus their cached state."""

    def __init__(self) -> None:
        self._channels: dict[str, ChannelInfo] = {}

    def joined_channels(self) -> list[ChannelInfo]:
        """Return channels the bot has joined, in insertion order."""
        return list(self._channels.values())

    def get(self, channel: str) -> ChannelInfo | None:
        return self._channels.get(channel.lower())

    def on_self_join(self, channel: str) -> ChannelInfo:
        """Record that the bot joined ``channel``. Idempotent."""
        key = channel.lower()
        info = self._channels.get(key)
        if info is None:
            info = ChannelInfo(name=channel)
            self._channels[key] = info
        return info

    def on_self_part(self, channel: str) -> None:
        self._channels.pop(channel.lower(), None)

    def on_topic(
        self,
        channel: str,
        topic: str | None | object = _UNSET,
        *,
        set_by: str | None = None,
        set_at: int | None = None,
    ) -> None:
        """Update a channel's topic and/or its setter/timestamp.

        Pass ``topic=...`` to change the topic (use ``None`` to clear it for
        RPL_NOTOPIC). Omit it to leave the topic unchanged — useful when
        RPL_TOPICWHOTIME (numeric 333) only carries setter info.
        """
        info = self._channels.get(channel.lower())
        if info is None:
            return
        if topic is not _UNSET:
            info.topic = topic  # type: ignore[assignment]
        if set_by is not None:
            info.topic_set_by = set_by
        if set_at is not None:
            info.topic_set_at = set_at

    def on_names_reply(self, channel: str, members: list[str]) -> None:
        """Append a single RPL_NAMREPLY chunk. Multiple chunks may arrive
        before RPL_ENDOFNAMES."""
        info = self._channels.get(channel.lower())
        if info is None:
            info = self.on_self_join(channel)
        if not info.names_complete:
            # If a previous round was complete, start fresh on the next reply.
            pass
        for entry in members:
            prefix, nick = _split_prefix(entry)
            if nick:
                info.members[nick] = prefix

    def on_names_end(self, channel: str) -> None:
        info = self._channels.get(channel.lower())
        if info is not None:
            info.names_complete = True

    def on_member_join(self, channel: str, nick: str) -> None:
        info = self._channels.get(channel.lower())
        if info is not None and nick:
            info.members.setdefault(nick, "")

    def on_member_part(self, channel: str, nick: str) -> None:
        info = self._channels.get(channel.lower())
        if info is not None:
            info.members.pop(nick, None)

    def on_member_quit(self, nick: str) -> None:
        for info in self._channels.values():
            info.members.pop(nick, None)

    def on_member_kick(self, channel: str, nick: str) -> None:
        self.on_member_part(channel, nick)

    def on_nick_change(self, old: str, new: str) -> None:
        for info in self._channels.values():
            if old in info.members:
                info.members[new] = info.members.pop(old)
