# SPDX-License-Identifier: Apache-2.0
"""Pluggable transport connectors (IRC, Discord, web, ...).

Each connector implements :class:`turborg.connectors.base.Connector`
and translates its native protocol to/from a normalized
:class:`turborg.core.envelope.Envelope`.
"""

from turborg.connectors.base import Connector

__all__ = ["Connector"]
