# SPDX-License-Identifier: Apache-2.0
"""Connector abstract base class.

Every transport (IRC, Discord, web, ...) implements this interface. The
agent talks to connectors only through this surface — never through
transport-specific types.

A connector is an async iterator of inbound envelopes: ``async for envelope
in connector`` yields :class:`~turborg.core.envelope.InboundEnvelope` as they
arrive. To send, the agent calls :meth:`Connector.send`. Lifecycle is
``start`` → iterate → ``stop``.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import ClassVar

from turborg.core.envelope import InboundEnvelope, OutboundEnvelope


class Connector(ABC):
    """Transport-agnostic interface every connector implements."""

    name: ClassVar[str]
    """Short identifier used in :class:`InboundEnvelope.connector` (e.g.
    ``"irc"``, ``"discord"``). Must be unique across loaded connectors."""

    instance: str = "default"
    """Distinguishes multiple instances of the same connector running side
    by side (e.g. two IRC networks). Set by the agent at registration."""

    @abstractmethod
    async def start(self) -> None:
        """Open the connection and begin streaming inbound envelopes.

        Must be safe to call once; subsequent calls before :meth:`stop`
        should be no-ops or raise :class:`~turborg.core.exceptions.ConnectorError`.
        """

    @abstractmethod
    async def stop(self) -> None:
        """Close the connection and stop yielding envelopes.

        Must complete in finite time and be idempotent.
        """

    @abstractmethod
    async def send(self, envelope: OutboundEnvelope) -> None:
        """Deliver ``envelope`` over the underlying transport."""

    @abstractmethod
    def __aiter__(self) -> Connector:
        """Return ``self`` — the connector is its own async iterator."""

    @abstractmethod
    async def __anext__(self) -> InboundEnvelope:
        """Yield the next inbound envelope.

        Raise :class:`StopAsyncIteration` when the connector has stopped.
        """
