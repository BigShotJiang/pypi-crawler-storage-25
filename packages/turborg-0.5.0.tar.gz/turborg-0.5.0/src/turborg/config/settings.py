# SPDX-License-Identifier: Apache-2.0
"""Cross-cutting settings loaded from environment + ``.env`` files.

Connector-specific settings live next to their connectors (e.g.
``turborg.connectors.irc.settings``) so installing turborg without a
particular connector does not require setting that connector's variables.

All variables are namespaced with the ``TURBORG_`` prefix to avoid
collisions in shared environments.
"""

from __future__ import annotations

from typing import Literal

from pydantic import Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict

LogLevel = Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
LogFormat = Literal["text", "json"]


class Settings(BaseSettings):
    """Top-level turborg settings.

    Values are read, in order of precedence, from:

    1. arguments passed to the constructor;
    2. environment variables prefixed ``TURBORG_``;
    3. a ``.env`` file in the current working directory;
    4. the defaults declared below.
    """

    model_config = SettingsConfigDict(
        env_prefix="TURBORG_",
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    log_level: LogLevel = "INFO"
    """Root log level for ``turborg.*`` loggers."""

    log_format: LogFormat = "text"
    """``text`` for human-readable logs (default); ``json`` to emit one JSON
    object per line, suitable for ingestion by CloudWatch Logs Insights,
    Loki, Datadog, or any structured-log backend without regex parsing."""

    command_prefix: str = Field(default="!", min_length=1)
    """Single character or short string that triggers command parsing in
    inbound messages (e.g. ``!ping`` if prefix is ``!``)."""

    anthropic_api_key: SecretStr | None = None
    """API key for the default Anthropic LLM provider. Optional — only
    required if you actually use :class:`turborg.llm.anthropic.AnthropicProvider`."""

    anthropic_model: str = "claude-sonnet-4-6"
    """Model identifier passed to the Anthropic SDK."""

    hive_enabled: bool = False
    """Toggle for the future ``hive.xshellz.com`` integration. Off in v0.1."""

    hive_url: str | None = None
    """Override URL for the hive endpoint. ``None`` uses the public default
    once the hive ships."""

    web_password: SecretStr | None = None
    """If set, ``turborg run`` also starts the WebSocket gateway. Clients
    authenticate by passing this token via ``?token=`` (or
    ``Authorization: Bearer``). ``None`` disables the gateway."""

    web_host: str = "127.0.0.1"
    """Interface the WS gateway listens on. ``127.0.0.1`` keeps it local;
    bind to ``0.0.0.0`` only behind a TLS-terminating reverse proxy."""

    web_port: int = 8765
    """Port the WS gateway listens on."""

    web_max_failed_attempts: int = 5
    """Failed WS auth attempts allowed within the window before lockout."""

    web_failure_window_seconds: int = 60
    """Sliding-window length for counting WS auth failures."""

    web_lockout_seconds: int = 300
    """How long an IP stays locked out after exceeding the threshold."""

    web_idle_shutdown_seconds: int | None = None
    """If set, the agent shuts itself down after the WS gateway has had
    zero connected clients for this many seconds. Useful for SaaS
    deployments where free-tier instances should release resources when
    the user closes their browser. ``None`` (default) keeps the agent
    running indefinitely — the always-on bouncer mode."""
