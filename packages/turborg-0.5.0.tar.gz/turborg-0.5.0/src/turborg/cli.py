# SPDX-License-Identifier: Apache-2.0
"""Command-line interface for turborg."""

import asyncio
import logging

import typer

from turborg import __version__
from turborg.config.settings import Settings
from turborg.logging import configure_logging
from turborg.runtime import build_agent_from_settings, build_web_gateway

app = typer.Typer(
    name="turborg",
    no_args_is_help=True,
    help="turborg — modular AI agent framework.",
    add_completion=False,
)


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(__version__)
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        False,
        "--version",
        "-V",
        callback=_version_callback,
        is_eager=True,
        help="Show the turborg version and exit.",
    ),
) -> None:
    """turborg — modular AI agent framework."""


@app.command()
def run() -> None:
    """Run a turborg IRC bot from environment-derived settings.

    Required: ``TURBORG_IRC_HOSTNAME``, ``TURBORG_IRC_NICK``,
    ``TURBORG_IRC_CHANNELS``. Optional: ``TURBORG_ANTHROPIC_API_KEY``
    enables the ``!ask`` command. Without it the bot runs standalone
    (``!ping``, ``!version`` still work).
    """
    settings = Settings()
    configure_logging(level=settings.log_level, fmt=settings.log_format)
    agent = build_agent_from_settings(settings=settings)
    gateway = build_web_gateway(agent, settings)
    mode = "llm" if agent.llm is not None else "standalone"
    irc = agent.get_connector("irc")
    bouncer = getattr(irc, "bouncer", None)
    bouncer_state = f"on@{bouncer.host}:{bouncer.port}" if bouncer is not None else "off"
    web_state = f"on@{settings.web_host}:{settings.web_port}" if gateway is not None else "off"
    logging.getLogger("turborg.cli").info(
        "turborg %s starting (mode=%s, bouncer=%s, web=%s)",
        __version__,
        mode,
        bouncer_state,
        web_state,
    )
    asyncio.run(_run(agent, gateway))


async def _run(agent: object, gateway: object | None) -> None:
    """Run the agent (and optional web gateway) until interrupted."""
    try:
        if gateway is None:
            await agent.start()  # type: ignore[attr-defined]
            return
        async with asyncio.TaskGroup() as tg:
            tg.create_task(agent.start(), name="agent")  # type: ignore[attr-defined]
            tg.create_task(gateway.serve(), name="web-gateway")  # type: ignore[attr-defined]
    except KeyboardInterrupt:
        logging.getLogger("turborg.cli").info("Interrupted by user; shutting down.")
        if gateway is not None:
            await gateway.stop()  # type: ignore[attr-defined]
        await agent.stop()  # type: ignore[attr-defined]


if __name__ == "__main__":
    app()
