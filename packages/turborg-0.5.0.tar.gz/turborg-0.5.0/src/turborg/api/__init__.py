# SPDX-License-Identifier: Apache-2.0
"""Control-plane HTTP+WebSocket API.

Placeholder package for v0.1. The real surface — a FastAPI app exposing
agent state, connector control, and event streams to a React/Angular
admin UI — lands in v0.2+. Install the optional ``turborg[web]`` extra
to pull in the FastAPI/uvicorn/websockets dependencies.
"""
