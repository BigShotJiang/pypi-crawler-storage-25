# SPDX-License-Identifier: Apache-2.0
"""Token verification for the WebSocket gateway.

Self-host uses :class:`StaticPasswordVerifier` against a single env-var
secret. SaaS deployments implement :class:`TokenVerifier` themselves
(e.g. validate a Laravel broadcasting JWT, hit an auth service, check
a session cookie). The gateway holds the verifier behind the Protocol
so swapping is a one-line constructor change.
"""

from __future__ import annotations

import secrets
from typing import Protocol


class TokenVerifier(Protocol):
    """Plug point for ``WebGateway`` auth.

    Implementations must return ``True`` only if the token authenticates
    the caller. Constant-time comparison is the implementation's job —
    the gateway treats any truthy/falsy return as the only signal.
    """

    async def verify(self, token: str) -> bool: ...


class StaticPasswordVerifier:
    """Compare the WS-supplied token against a single shared secret.

    Used when ``TURBORG_WEB_PASSWORD`` is set and no custom verifier has
    been wired in. Compares with :func:`secrets.compare_digest` to avoid
    timing-leak side channels.
    """

    def __init__(self, password: str) -> None:
        if not password:
            raise ValueError("StaticPasswordVerifier requires a non-empty password.")
        self._password = password

    async def verify(self, token: str) -> bool:
        if not token:
            return False
        return secrets.compare_digest(token, self._password)
