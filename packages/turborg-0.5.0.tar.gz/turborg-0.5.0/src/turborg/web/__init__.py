# SPDX-License-Identifier: Apache-2.0
"""WebSocket gateway — turn turborg into a real-time web service.

Activated by the ``[web]`` install extra. Subscribes to the agent's
:class:`~turborg.core.events.EventBus`, mirrors IRC traffic out as JSON
messages over WebSocket, and lets connected clients send messages back.

The auth surface is pluggable (:class:`~turborg.web.auth.TokenVerifier`):
local self-host typically uses a pre-shared password; SaaS deployments
swap in their own verifier (e.g. a Laravel broadcast token check) without
touching the wire protocol.
"""
