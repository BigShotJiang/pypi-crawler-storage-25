# SPDX-License-Identifier: Apache-2.0
"""WebSocket gateway — JSON event stream for web frontends.

Wire protocol (one JSON object per WS message):

Server → client (after the client passes ``?token=`` auth):

- ``{"op":"state","nick","channels":[{"name","topic","members":[{"nick","mode"}]}]}``
- ``{"op":"message","channel","nick","text","ts"}``
- ``{"op":"join","channel","nick"}``
- ``{"op":"part","channel","nick","reason"}``
- ``{"op":"kick","channel","nick","kicker","reason"}``
- ``{"op":"nick","old","new"}``
- ``{"op":"topic","channel","topic","setBy"}``
- ``{"op":"names","channel","members":[{"nick","mode"}]}``
- ``{"op":"server","text","kind"}``
- ``{"op":"mode_changed","channel","modes","args","setBy"}``
- ``{"op":"whois_result", ...}`` — see :class:`EventType.WHOIS_RESULT`
  for the full key list

Client → server (post-auth):

- ``{"op":"say","channel","text"}``
- ``{"op":"join","channel"}``
- ``{"op":"part","channel"}``
- ``{"op":"nick","nick"}``
- ``{"op":"mode","channel","modes","target"}``
- ``{"op":"kick","channel","nick","reason"}``
- ``{"op":"whois","nick"}``
- ``{"op":"topic","channel","topic"}`` — ``topic`` omitted to query
- ``{"op":"raw","line"}`` — escape hatch; sent verbatim, leading "/" stripped

The gateway is connector-aware (state replay reads ``IRCConnector
.channel_state``; outbound ``join``/``part``/``nick`` send raw IRC) but
does not otherwise leak IRC concepts into the JSON protocol — channel
names with ``#`` are part of the value, not the schema.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import time
from collections.abc import Awaitable, Callable, Iterator
from pathlib import Path
from typing import TYPE_CHECKING, Any
from urllib.parse import parse_qs

import uvicorn
from fastapi import FastAPI, WebSocket
from fastapi.staticfiles import StaticFiles
from starlette.websockets import WebSocketState

from turborg.connectors.irc.codes import IRCCommand
from turborg.connectors.irc.protocol import format_command
from turborg.connectors.irc.ratelimit import RateLimiter
from turborg.core.envelope import OutboundEnvelope
from turborg.core.events import EventType
from turborg.web.auth import TokenVerifier

if TYPE_CHECKING:
    from turborg.connectors.irc.connector import IRCConnector
    from turborg.core.agent import Agent

logger = logging.getLogger(__name__)


_WS_CLOSE_AUTH_FAILED = 4401
"""Application-defined WS close code for failed auth (1000-2999 are reserved)."""

_WS_CLOSE_RATE_LIMITED = 4429
"""Application-defined WS close code for rate-limited / locked-out IPs."""


class WebGateway:
    """FastAPI app + uvicorn server pair that bridges turborg to web clients."""

    def __init__(
        self,
        agent: Agent,
        irc_connector: IRCConnector,
        verifier: TokenVerifier,
        *,
        host: str = "127.0.0.1",
        port: int = 8765,
        rate_limiter: RateLimiter | None = None,
        idle_shutdown_seconds: int | None = None,
        on_idle_shutdown: Callable[[], Awaitable[None]] | None = None,
    ) -> None:
        self.host = host
        self.port = port
        self._agent = agent
        self._connector = irc_connector
        self._verifier = verifier
        self._rate_limiter = rate_limiter
        self._clients: set[WebSocket] = set()
        self._app: FastAPI = self._build_app()
        self._server: uvicorn.Server | None = None
        self._idle_shutdown_seconds = idle_shutdown_seconds
        self._on_idle_shutdown = on_idle_shutdown
        self._idle_task: asyncio.Task[None] | None = None

    @property
    def app(self) -> FastAPI:
        return self._app

    @property
    def clients(self) -> frozenset[WebSocket]:
        return frozenset(self._clients)

    @property
    def client_count(self) -> int:
        """Number of currently-connected (authenticated) WS clients."""
        return len(self._clients)

    async def serve(self) -> None:
        """Run the uvicorn server until cancelled. Subscribes to the agent's
        EventBus on entry; unsubscribes on exit."""
        self._subscribe_events()
        config = uvicorn.Config(
            self._app,
            host=self.host,
            port=self.port,
            log_config=None,  # let turborg's root logger handle output
            access_log=False,
        )
        self._server = uvicorn.Server(config)
        try:
            await self._server.serve()
        finally:
            self._unsubscribe_events()
            self._server = None

    async def stop(self) -> None:
        """Trigger uvicorn graceful shutdown."""
        self._cancel_idle_timer()
        if self._server is not None:
            self._server.should_exit = True

    def _cancel_idle_timer(self) -> None:
        """Cancel any pending idle-shutdown task. Called when a new client
        connects (so the deadline doesn't fire while someone's watching) and
        on :meth:`stop`."""
        if self._idle_task is not None and not self._idle_task.done():
            self._idle_task.cancel()
        self._idle_task = None

    def _schedule_idle_shutdown(self) -> None:
        """Start the idle deadline. Caller has already verified the client
        set is empty; if it stays empty for ``idle_shutdown_seconds`` the
        ``on_idle_shutdown`` callback fires and this gateway stops itself.
        No-op when the feature isn't configured."""
        if self._idle_shutdown_seconds is None or self._on_idle_shutdown is None:
            return
        self._idle_task = asyncio.create_task(
            self._wait_then_shutdown(self._idle_shutdown_seconds), name="web-idle-shutdown"
        )

    async def _wait_then_shutdown(self, seconds: int) -> None:
        try:
            await asyncio.sleep(seconds)
        except asyncio.CancelledError:
            return
        if self._clients:
            return  # someone reconnected during the await — bail
        logger.info(
            "web.idle_shutdown reason=no_clients_for_%ds",
            seconds,
            extra={
                "event": "web.idle_shutdown",
                "idle_seconds": seconds,
            },
        )
        try:
            assert self._on_idle_shutdown is not None
            await self._on_idle_shutdown()
        except Exception:
            logger.exception("idle shutdown callback failed")

    def _build_app(self) -> FastAPI:
        app = FastAPI()

        @app.websocket("/ws")
        async def ws(websocket: WebSocket) -> None:
            await self._handle_ws(websocket)

        # Reference UI — served only if the bundled static directory exists.
        # Mounted last so the /ws route takes precedence; everything else
        # (including /) falls through to index.html.
        static_dir = Path(__file__).parent / "static"
        if static_dir.is_dir():
            app.mount("/", StaticFiles(directory=static_dir, html=True), name="static")

        return app

    async def _handle_ws(self, websocket: WebSocket) -> None:
        ip = websocket.client.host if websocket.client is not None else "unknown"
        token = self._extract_token(websocket)
        if self._rate_limiter is not None:
            remaining = self._rate_limiter.time_until_unlock(ip)
            if remaining is not None:
                logger.warning(
                    "web.auth ip=%s result=blocked remaining=%.0fs",
                    ip,
                    remaining,
                    extra={
                        "event": "web.auth",
                        "ip": ip,
                        "result": "blocked",
                        "remaining_seconds": round(remaining, 1),
                    },
                )
                await websocket.close(code=_WS_CLOSE_RATE_LIMITED, reason="Too many attempts")
                return
        if not await self._verifier.verify(token):
            if self._rate_limiter is not None:
                outcome = self._rate_limiter.record_failure(ip)
                if outcome.locked:
                    logger.warning(
                        "web.auth ip=%s result=lockout duration=%.0fs",
                        ip,
                        self._rate_limiter.lockout_seconds,
                        extra={
                            "event": "web.auth",
                            "ip": ip,
                            "result": "lockout",
                            "lockout_seconds": int(self._rate_limiter.lockout_seconds),
                        },
                    )
                else:
                    logger.info(
                        "web.auth ip=%s result=fail count=%d/%d",
                        ip,
                        outcome.count,
                        self._rate_limiter.max_failures,
                        extra={
                            "event": "web.auth",
                            "ip": ip,
                            "result": "fail",
                            "fail_count": outcome.count,
                            "fail_threshold": self._rate_limiter.max_failures,
                        },
                    )
            else:
                logger.info(
                    "web.auth ip=%s result=fail",
                    ip,
                    extra={"event": "web.auth", "ip": ip, "result": "fail"},
                )
            await websocket.close(code=_WS_CLOSE_AUTH_FAILED, reason="Invalid token")
            return

        if self._rate_limiter is not None:
            self._rate_limiter.record_success(ip)
        await websocket.accept()
        self._clients.add(websocket)
        self._cancel_idle_timer()
        connected_at = time.monotonic()
        logger.info(
            "web.auth ip=%s result=success",
            ip,
            extra={"event": "web.auth", "ip": ip, "result": "success"},
        )
        try:
            await self._send_state(websocket)
            await self._read_loop(websocket)
        finally:
            self._clients.discard(websocket)
            session_seconds = int(time.monotonic() - connected_at)
            logger.info(
                "web.disconnect ip=%s session_seconds=%d remaining_clients=%d",
                ip,
                session_seconds,
                len(self._clients),
                extra={
                    "event": "web.disconnect",
                    "ip": ip,
                    "session_seconds": session_seconds,
                    "remaining_clients": len(self._clients),
                },
            )
            if not self._clients:
                self._schedule_idle_shutdown()
            if websocket.client_state != WebSocketState.DISCONNECTED:
                with _suppress_disconnect():
                    await websocket.close()

    @staticmethod
    def _extract_token(websocket: WebSocket) -> str:
        # Browsers can't easily set custom headers on WS, so we use a query
        # param. Servers that prefer a header (e.g. for proxies) can still
        # send Authorization: Bearer <token>; we read both, query first.
        raw_query = websocket.scope.get("query_string", b"")
        query = parse_qs(raw_query.decode() if isinstance(raw_query, bytes) else raw_query)
        token_values = query.get("token") or []
        if token_values:
            return str(token_values[0])
        auth = websocket.headers.get("authorization", "")
        if auth.lower().startswith("bearer "):
            return auth.split(" ", 1)[1].strip()
        return ""

    async def _send_state(self, websocket: WebSocket) -> None:
        channels: list[dict[str, Any]] = []
        for info in self._connector.channel_state.joined_channels():
            channels.append(
                {
                    "name": info.name,
                    "topic": info.topic,
                    "topicSetBy": info.topic_set_by,
                    "topicSetAt": info.topic_set_at,
                    "members": [
                        {"nick": nick, "mode": prefix} for nick, prefix in info.members.items()
                    ],
                }
            )
        await self._send(
            websocket,
            {
                "op": "state",
                "nick": self._connector.current_nick,
                "channels": channels,
            },
        )

    async def _read_loop(self, websocket: WebSocket) -> None:
        while True:
            try:
                raw = await websocket.receive_text()
            except Exception:
                return
            try:
                payload = json.loads(raw)
            except json.JSONDecodeError:
                logger.debug("web: dropped non-JSON frame from client")
                continue
            await self._dispatch_inbound(payload)

    async def _dispatch_inbound(self, payload: dict[str, Any]) -> None:
        op = payload.get("op")
        if op == "say":
            channel = payload.get("channel", "")
            text = payload.get("text", "")
            if channel and text:
                envelope = OutboundEnvelope(
                    connector=self._connector.name,
                    connector_instance=self._connector.instance,
                    channel=channel,
                    text=text,
                )
                await self._agent.send(envelope)
        elif op == "join":
            channel = payload.get("channel", "")
            if channel:
                await self._connector.client.send_line(format_command(IRCCommand.JOIN, channel))
        elif op == "part":
            channel = payload.get("channel", "")
            if channel:
                await self._connector.client.send_line(format_command(IRCCommand.PART, channel))
        elif op == "nick":
            new_nick = payload.get("nick", "")
            if new_nick:
                await self._connector.client.send_line(format_command(IRCCommand.NICK, new_nick))
        elif op == "mode":
            channel = payload.get("channel", "")
            modes = payload.get("modes", "")
            target = payload.get("target", "")
            if channel and modes:
                args = [channel, modes] + ([target] if target else [])
                await self._connector.client.send_line(format_command(IRCCommand.MODE, *args))
        elif op == "kick":
            channel = payload.get("channel", "")
            target = payload.get("nick", "")
            reason = payload.get("reason", "")
            if channel and target:
                await self._connector.client.send_line(
                    format_command(IRCCommand.KICK, channel, target, trailing=reason or None)
                )
        elif op == "whois":
            target = payload.get("nick", "")
            if target:
                await self._connector.client.send_line(format_command(IRCCommand.WHOIS, target))
        elif op == "topic":
            channel = payload.get("channel", "")
            new_topic = payload.get("topic")
            if channel:
                if new_topic is None:
                    # No topic in the payload: query the current topic.
                    await self._connector.client.send_line(
                        format_command(IRCCommand.TOPIC, channel)
                    )
                else:
                    await self._connector.client.send_line(
                        format_command(IRCCommand.TOPIC, channel, trailing=new_topic)
                    )
        elif op == "raw":
            line = payload.get("line", "")
            if line and "\r" not in line and "\n" not in line:
                # Strip leading slash if a /raw command was passed verbatim.
                if line.startswith("/"):
                    line = line[1:]
                await self._connector.client.send_line(line)

    # --- EventBus subscriptions ----------------------------------------------

    def _subscribe_events(self) -> None:
        events = self._agent.events
        events.subscribe(EventType.MESSAGE, self._on_message)
        events.subscribe(EventType.MESSAGE_SENT, self._on_message_sent)
        events.subscribe(EventType.USER_JOIN, self._on_user_join)
        events.subscribe(EventType.USER_LEAVE, self._on_user_leave)
        events.subscribe(EventType.USER_KICKED, self._on_user_kicked)
        events.subscribe(EventType.USER_NICK_CHANGE, self._on_user_nick)
        events.subscribe(EventType.TOPIC_CHANGED, self._on_topic)
        events.subscribe(EventType.CHANNEL_NAMES, self._on_names)
        events.subscribe(EventType.SERVER_NOTICE, self._on_server_notice)
        events.subscribe(EventType.MODE_CHANGED, self._on_mode_changed)
        events.subscribe(EventType.WHOIS_RESULT, self._on_whois_result)

    def _unsubscribe_events(self) -> None:
        events = self._agent.events
        events.unsubscribe(EventType.MESSAGE, self._on_message)
        events.unsubscribe(EventType.MESSAGE_SENT, self._on_message_sent)
        events.unsubscribe(EventType.USER_JOIN, self._on_user_join)
        events.unsubscribe(EventType.USER_LEAVE, self._on_user_leave)
        events.unsubscribe(EventType.USER_KICKED, self._on_user_kicked)
        events.unsubscribe(EventType.USER_NICK_CHANGE, self._on_user_nick)
        events.unsubscribe(EventType.TOPIC_CHANGED, self._on_topic)
        events.unsubscribe(EventType.CHANNEL_NAMES, self._on_names)
        events.unsubscribe(EventType.SERVER_NOTICE, self._on_server_notice)
        events.unsubscribe(EventType.MODE_CHANGED, self._on_mode_changed)
        events.unsubscribe(EventType.WHOIS_RESULT, self._on_whois_result)

    async def _on_message(self, envelope: Any) -> None:
        # Only PRIVMSG-shaped envelopes (skip parsed-command duplicates).
        await self._broadcast(
            {
                "op": "message",
                "channel": envelope.channel,
                "nick": envelope.sender,
                "text": envelope.text,
                "ts": int(time.time()),
            }
        )

    async def _on_message_sent(self, channel: str, sender: str, text: str, kind: str) -> None:
        # Outgoing PRIVMSG/NOTICE — either from agent.send() or a bouncer
        # client tunneling through. The gateway's WS listeners need to see
        # these too; the IRC server doesn't echo them upstream.
        await self._broadcast(
            {
                "op": "message",
                "channel": channel,
                "nick": sender,
                "text": text,
                "ts": int(time.time()),
            }
        )

    async def _on_user_join(self, channel: str, nick: str) -> None:
        await self._broadcast({"op": "join", "channel": channel, "nick": nick})

    async def _on_user_leave(self, channel: str, nick: str, reason: str = "") -> None:
        await self._broadcast({"op": "part", "channel": channel, "nick": nick, "reason": reason})

    async def _on_user_kicked(self, channel: str, nick: str, kicker: str, reason: str = "") -> None:
        await self._broadcast(
            {
                "op": "kick",
                "channel": channel,
                "nick": nick,
                "kicker": kicker,
                "reason": reason,
            }
        )

    async def _on_user_nick(self, old: str, new: str) -> None:
        await self._broadcast({"op": "nick", "old": old, "new": new})

    async def _on_topic(self, channel: str, topic: str | None, set_by: str | None) -> None:
        await self._broadcast({"op": "topic", "channel": channel, "topic": topic, "setBy": set_by})

    async def _on_server_notice(self, text: str, kind: str) -> None:
        await self._broadcast({"op": "server", "text": text, "kind": kind})

    async def _on_mode_changed(self, channel: str, modes: str, args: str, set_by: str) -> None:
        await self._broadcast(
            {
                "op": "mode_changed",
                "channel": channel,
                "modes": modes,
                "args": args,
                "setBy": set_by,
            }
        )

    async def _on_whois_result(self, info: dict[str, Any]) -> None:
        await self._broadcast({"op": "whois_result", **info})

    async def _on_names(self, channel: str, members: list[tuple[str, str]]) -> None:
        # RPL_ENDOFNAMES — typically right after the bot joins a channel.
        # Clients that connected before turborg's IRC handshake otherwise
        # miss the member list: USER_JOIN brings the channel into existence
        # in their UI, but the existing members never JOIN again so without
        # this they never see anyone.
        await self._broadcast(
            {
                "op": "names",
                "channel": channel,
                "members": [{"nick": n, "mode": m} for n, m in members],
            }
        )

    # --- Wire helpers --------------------------------------------------------

    async def _broadcast(self, payload: dict[str, Any]) -> None:
        if not self._clients:
            return
        for ws in list(self._clients):
            await self._send(ws, payload)

    async def _send(self, websocket: WebSocket, payload: dict[str, Any]) -> None:
        if websocket.client_state != WebSocketState.CONNECTED:
            self._clients.discard(websocket)
            return
        try:
            await websocket.send_text(json.dumps(payload))
        except Exception:
            logger.debug("web: dropping disconnected client", exc_info=True)
            self._clients.discard(websocket)


@contextlib.contextmanager
def _suppress_disconnect() -> Iterator[None]:
    """Swallow exceptions while closing an already-broken WebSocket. We only
    reach this path on shutdown of an unauth/dead client where a duplicate
    close would otherwise raise — the connection is going away regardless."""
    with contextlib.suppress(Exception):
        yield
