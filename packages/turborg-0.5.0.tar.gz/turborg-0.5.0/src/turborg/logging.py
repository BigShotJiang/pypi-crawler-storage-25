# SPDX-License-Identifier: Apache-2.0
"""Logging helpers for turborg.

Two output formats, selected via ``TURBORG_LOG_FORMAT``:

- ``text`` (default): the human-readable
  ``YYYY-mm-dd HH:MM:SS [LEVEL] logger.name: message`` line.
- ``json``: one JSON object per line with stable keys ``ts``, ``level``,
  ``logger``, ``msg`` (plus ``exc_info`` if there's an exception, plus any
  ``extra={...}`` fields the caller passed). Suitable for ingestion by
  CloudWatch Logs Insights, Loki, Datadog, etc., without regex parsing.

Logs always go to stdout/stderr — turborg follows the 12-factor pattern of
letting the deployment layer aggregate. No file rotation, no remote shipping
in turborg itself; that's the operator's job.
"""

from __future__ import annotations

import json
import logging
import sys
from typing import Literal

LogFormat = Literal["text", "json"]


_TEXT_FORMAT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"

_RESERVED_RECORD_ATTRS: frozenset[str] = frozenset(
    {
        "args",
        "asctime",
        "created",
        "exc_info",
        "exc_text",
        "filename",
        "funcName",
        "levelname",
        "levelno",
        "lineno",
        "message",
        "module",
        "msecs",
        "msg",
        "name",
        "pathname",
        "process",
        "processName",
        "relativeCreated",
        "stack_info",
        "taskName",
        "thread",
        "threadName",
    }
)


class JSONFormatter(logging.Formatter):
    """Render ``LogRecord``\\ s as one-line JSON objects.

    Caller-supplied ``extra={...}`` fields are merged into the top level so
    they are first-class queryable. Reserved ``LogRecord`` attributes (the
    framework's own bookkeeping) are skipped to keep the payload tight.
    """

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, object] = {
            "ts": self.formatTime(record, "%Y-%m-%dT%H:%M:%S"),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        for key, value in record.__dict__.items():
            if key in _RESERVED_RECORD_ATTRS or key.startswith("_"):
                continue
            payload[key] = value
        if record.exc_info:
            payload["exc_info"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str)


def configure_logging(*, level: str, fmt: LogFormat) -> None:
    """Configure the root logger for ``turborg run``.

    Replaces any existing handlers so re-running the CLI in tests doesn't
    accumulate them. Logs go to stderr (Python's default for the root
    StreamHandler), which most container runtimes treat the same as stdout.
    """
    formatter: logging.Formatter = (
        JSONFormatter() if fmt == "json" else logging.Formatter(_TEXT_FORMAT)
    )
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(formatter)
    root = logging.getLogger()
    for existing in list(root.handlers):
        root.removeHandler(existing)
    root.addHandler(handler)
    root.setLevel(level)
