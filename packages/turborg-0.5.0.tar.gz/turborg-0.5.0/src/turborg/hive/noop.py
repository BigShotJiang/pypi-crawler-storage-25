# SPDX-License-Identifier: Apache-2.0
"""No-op hive client.

The default in v0.1. Implements every method as a no-op so the agent
can be wired against ``HiveClient`` today without depending on a real
hive.xshellz.com endpoint that doesn't exist yet.
"""

from __future__ import annotations

from turborg.hive.base import HiveClient


class NoopHive(HiveClient):
    """Hive client that does nothing. Always reports as connected."""

    @property
    def connected(self) -> bool:
        return True

    async def connect(self) -> None:
        return None

    async def disconnect(self) -> None:
        return None

    async def heartbeat(self) -> None:
        return None
