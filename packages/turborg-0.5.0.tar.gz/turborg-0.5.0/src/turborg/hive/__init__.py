# SPDX-License-Identifier: Apache-2.0
"""Hive client — extension point for hive.xshellz.com.

In v0.1, only :class:`turborg.hive.noop.NoopHive` is provided.
A real client connecting to hive.xshellz.com will land in a future release.
"""

from turborg.hive.base import HiveClient
from turborg.hive.noop import NoopHive

__all__ = ["HiveClient", "NoopHive"]
