# SPDX-License-Identifier: Apache-2.0
"""Hive client abstraction.

The hive is turborg's future shared-intelligence layer at
``hive.xshellz.com`` (see :doc:`/docs/hive` for the roadmap). v0.1 ships
only the interface and a no-op default; the real client lands in a later
release.

Why an interface today? Because the place a hive client plugs into the
:class:`~turborg.core.agent.Agent` is small and stable, and freezing it
now lets v0.1 users wire their bots to "the hive slot" without code
changes when the real client ships. They flip a setting, swap the noop
for the real implementation, done.
"""

from __future__ import annotations

from abc import ABC, abstractmethod


class HiveClient(ABC):
    """Surface every hive client implements.

    Implementations are async-only. Lifecycle is ``connect`` → use →
    ``disconnect``. ``heartbeat`` is called periodically by the agent to
    keep registration alive.
    """

    @abstractmethod
    async def connect(self) -> None:
        """Open the connection to the hive and register this agent."""

    @abstractmethod
    async def disconnect(self) -> None:
        """Cleanly leave the hive."""

    @abstractmethod
    async def heartbeat(self) -> None:
        """Tell the hive this agent is still alive.

        Called periodically by the agent. Implementations should be
        cheap and idempotent — failing one heartbeat is normal.
        """

    @property
    @abstractmethod
    def connected(self) -> bool:
        """Whether the client is currently registered with the hive."""
