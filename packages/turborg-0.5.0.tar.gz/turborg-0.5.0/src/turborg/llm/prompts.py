# SPDX-License-Identifier: Apache-2.0
"""Cache-friendly system prompt construction.

Anthropic prompt caching is a prefix match: any byte change anywhere in the
prefix invalidates everything after it. The agent's system prompt is the
single biggest cacheable prefix in a typical turborg call, so it pays to
construct it deterministically.

:func:`system_blocks` returns the structured ``system`` argument expected
by ``client.messages.create()`` / ``messages.stream()``: a list with one
text block per segment, with ``cache_control`` on the last segment so the
whole system prefix gets cached.
"""

from __future__ import annotations

from typing import Any


def system_blocks(text: str, *, cache: bool = True) -> list[dict[str, Any]]:
    """Wrap ``text`` as the structured ``system`` argument with caching.

    If ``cache`` is ``True`` (the default), the block carries
    ``cache_control={"type": "ephemeral"}`` so the system prefix is cached
    across calls (~5 minute TTL). Disable caching only for short, volatile
    prompts where the cache write would never amortize.
    """
    block: dict[str, Any] = {"type": "text", "text": text}
    if cache:
        block["cache_control"] = {"type": "ephemeral"}
    return [block]
