# SPDX-License-Identifier: Apache-2.0
"""Anthropic Claude provider — turborg's default brain.

Uses the official ``anthropic`` SDK with prompt caching enabled by default.
Designed for asyncio: every call is awaitable; streaming yields tokens as
they arrive.

Defaults are tuned for chat-bot use: ``claude-sonnet-4-6`` for a
speed/intelligence balance, ``max_tokens=4096`` for typical answers, and
top-level prompt caching of the system prompt. Override per-call when you
need more thinking, more tokens, or a different model.
"""

from __future__ import annotations

import logging
from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import anthropic
from pydantic import SecretStr

from turborg.config.settings import Settings
from turborg.core.exceptions import ConfigError, LLMError
from turborg.llm.base import LLMProvider
from turborg.llm.prompts import system_blocks

if TYPE_CHECKING:
    from anthropic import AsyncAnthropic

logger = logging.getLogger(__name__)


_DEFAULT_MAX_TOKENS = 4096


class AnthropicProvider(LLMProvider):
    """Anthropic Claude provider built on top of :class:`anthropic.AsyncAnthropic`."""

    def __init__(
        self,
        *,
        api_key: SecretStr | str,
        model: str = "claude-sonnet-4-6",
        max_tokens: int = _DEFAULT_MAX_TOKENS,
        system_prompt: str | None = None,
        cache_system_prompt: bool = True,
        client: AsyncAnthropic | None = None,
    ) -> None:
        key_value = api_key.get_secret_value() if isinstance(api_key, SecretStr) else api_key
        if not key_value:
            raise ConfigError("Anthropic API key is empty.")
        self._model = model
        self._max_tokens = max_tokens
        self._system_prompt = system_prompt
        self._cache_system_prompt = cache_system_prompt
        self._client: AsyncAnthropic = client or anthropic.AsyncAnthropic(api_key=key_value)

    @classmethod
    def from_settings(cls, settings: Settings) -> AnthropicProvider:
        """Build a provider from a :class:`Settings` instance.

        Raises :class:`ConfigError` if ``TURBORG_ANTHROPIC_API_KEY`` is unset.
        """
        if settings.anthropic_api_key is None:
            raise ConfigError(
                "TURBORG_ANTHROPIC_API_KEY is not set. Export it or pass an explicit api_key=..."
            )
        return cls(api_key=settings.anthropic_api_key, model=settings.anthropic_model)

    @property
    def model(self) -> str:
        return self._model

    @property
    def client(self) -> AsyncAnthropic:
        return self._client

    async def ask(
        self,
        prompt: str,
        *,
        system: str | None = None,
        max_tokens: int | None = None,
    ) -> str:
        """Send ``prompt`` to Claude and return the assembled text response.

        Streams under the hood via :meth:`AsyncAnthropic.messages.stream` so
        large outputs don't time out the request.
        """
        kwargs = self._build_kwargs(prompt, system=system, max_tokens=max_tokens)
        try:
            async with self._client.messages.stream(**kwargs) as stream:
                message = await stream.get_final_message()
        except anthropic.APIError as exc:
            raise LLMError(f"Anthropic API error: {exc}") from exc
        return _join_text(message.content)

    async def stream(
        self,
        prompt: str,
        *,
        system: str | None = None,
        max_tokens: int | None = None,
    ) -> AsyncIterator[str]:
        """Yield text deltas as Claude generates them."""
        kwargs = self._build_kwargs(prompt, system=system, max_tokens=max_tokens)
        try:
            async with self._client.messages.stream(**kwargs) as stream:
                async for chunk in stream.text_stream:
                    yield chunk
        except anthropic.APIError as exc:
            raise LLMError(f"Anthropic API error: {exc}") from exc

    def _build_kwargs(
        self,
        prompt: str,
        *,
        system: str | None,
        max_tokens: int | None,
    ) -> dict[str, Any]:
        effective_system = system if system is not None else self._system_prompt
        kwargs: dict[str, Any] = {
            "model": self._model,
            "max_tokens": max_tokens or self._max_tokens,
            "messages": [{"role": "user", "content": prompt}],
        }
        if effective_system is not None:
            kwargs["system"] = system_blocks(effective_system, cache=self._cache_system_prompt)
        return kwargs


def _join_text(content: list[Any]) -> str:
    """Concatenate the text of every ``text``-type block in a response."""
    parts: list[str] = []
    for block in content:
        if getattr(block, "type", None) == "text":
            parts.append(block.text)
    return "".join(parts)
