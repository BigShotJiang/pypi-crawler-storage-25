# SPDX-License-Identifier: Apache-2.0
"""LLM provider abstraction.

Concrete providers implement :class:`LLMProvider`; the agent and handlers
talk to providers only through this interface so the underlying SDK can
be swapped (Anthropic Claude by default, OpenAI as an optional extra,
custom in-house models if you fork).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator


class LLMProvider(ABC):
    """Minimal contract every LLM provider implements.

    Providers are async-only. Synchronous wrappers can be added on top, but
    the framework itself is asyncio-native and uses providers from inside
    async handlers.
    """

    @property
    @abstractmethod
    def model(self) -> str:
        """The model identifier this provider is currently using
        (e.g. ``"claude-sonnet-4-6"``)."""

    @abstractmethod
    async def ask(
        self,
        prompt: str,
        *,
        system: str | None = None,
        max_tokens: int | None = None,
    ) -> str:
        """Send ``prompt`` and return the full text response.

        The default implementation in concrete providers should use streaming
        under the hood when ``max_tokens`` is large, to avoid request
        timeouts, but expose a non-streaming API surface here for ergonomics.
        """

    @abstractmethod
    def stream(
        self,
        prompt: str,
        *,
        system: str | None = None,
        max_tokens: int | None = None,
    ) -> AsyncIterator[str]:
        """Yield text deltas as they arrive from the upstream model."""
