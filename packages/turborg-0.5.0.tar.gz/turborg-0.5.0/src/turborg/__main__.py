# SPDX-License-Identifier: Apache-2.0
"""Entry point for `python -m turborg`."""

from turborg.cli import app

if __name__ == "__main__":
    app()
