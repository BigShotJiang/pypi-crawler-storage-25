# SPDX-License-Identifier: Apache-2.0
"""Event bus.

The agent publishes high-level events (``BOOT``, ``MESSAGE``, ``USER_JOIN``,
...) on an in-process :class:`EventBus`. Handlers are async callables;
multiple handlers can subscribe to the same event and they run concurrently.

This is intentionally simple: no priorities, no filtering DSL, no remote
delivery. If a handler raises, the bus logs and continues — one bad
subscriber must not kill the agent.
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Awaitable, Callable
from enum import StrEnum
from typing import Any

logger = logging.getLogger(__name__)


class EventType(StrEnum):
    """Connector-agnostic events the agent publishes."""

    BOOT = "BOOT"
    """Agent has finished startup; connectors are connected and ready."""

    READY = "READY"
    """A specific connector reports it has finished its handshake."""

    SHUTDOWN = "SHUTDOWN"
    """Agent is shutting down. Last chance to flush state."""

    MESSAGE = "MESSAGE"
    """An :class:`~turborg.core.envelope.InboundEnvelope` was received."""

    MESSAGE_SENT = "MESSAGE_SENT"
    """A PRIVMSG/NOTICE was sent BY this turborg agent — either via
    ``agent.send()`` or via a bouncer client tunneling through. Args:
    ``(channel: str, sender: str, text: str, kind: str)`` where ``kind``
    is ``"PRIVMSG"`` or ``"NOTICE"``. Subscribers receive the bot's
    outgoing traffic without command handlers being re-triggered by it."""

    COMMAND = "COMMAND"
    """An inbound message was parsed as a command and dispatched."""

    USER_JOIN = "USER_JOIN"
    """Someone joined a channel. Args: ``(channel: str, nick: str)``."""

    USER_LEAVE = "USER_LEAVE"
    """Someone parted or quit a channel. Args:
    ``(channel: str, nick: str, reason: str)`` — ``reason`` is the
    PART/QUIT message text (empty string if none)."""

    USER_KICKED = "USER_KICKED"
    """Someone was kicked from a channel. Args:
    ``(channel: str, nick: str, kicker: str, reason: str)``. Distinct
    from USER_LEAVE so UIs can render this differently — kicks are not
    voluntary departures."""

    USER_NICK_CHANGE = "USER_NICK_CHANGE"
    """A user renamed. Args: ``(old_nick: str, new_nick: str)``."""

    TOPIC_CHANGED = "TOPIC_CHANGED"
    """A channel's topic was set or cleared. Args:
    ``(channel: str, topic: str | None, set_by: str | None)``."""

    CHANNEL_NAMES = "CHANNEL_NAMES"
    """A complete NAMES list arrived for a channel — typically right after
    we (or someone) joined it, or after an explicit ``NAMES`` query. Args:
    ``(channel: str, members: list[tuple[str, str]])`` where each member
    tuple is ``(nick, mode_prefix)`` (mode is ``""``, ``"@"``, ``"+"``, etc.)."""

    SERVER_NOTICE = "SERVER_NOTICE"
    """A server-level message — connection events, MOTD lines, RPL_WELCOME-
    family numerics, server NOTICEs. Args: ``(text: str, kind: str)`` where
    ``kind`` is one of ``"info"`` (lifecycle), ``"motd"``, ``"welcome"``,
    ``"notice"``, ``"error"``."""

    MODE_CHANGED = "MODE_CHANGED"
    """A MODE was applied to a channel (or user). Args:
    ``(channel: str, modes: str, args: str, set_by: str)`` — ``modes`` is
    the raw mode string (``"+o-v"`` etc.), ``args`` is whitespace-joined
    parameters (target nicks, masks, keys), ``set_by`` is the prefix that
    issued it. The connector follows up with a NAMES query so subscribers
    will receive a fresh CHANNEL_NAMES event with updated member prefixes."""

    WHOIS_RESULT = "WHOIS_RESULT"
    """A WHOIS query completed (RPL_ENDOFWHOIS arrived). Args: ``(info:
    dict)`` containing keys ``nick``, ``user``, ``host``, ``realName``,
    ``server``, ``serverInfo``, ``channels`` (list of channel-with-prefix),
    ``idleSeconds`` (int|None), ``signonAt`` (unix int|None), ``secure``
    (bool), ``account`` (str|None), ``isOperator`` (bool), ``error``
    (str|None for ERR_NOSUCHNICK)."""

    ERROR = "ERROR"
    """A handler or connector raised. Argument: the exception."""

    RAW = "RAW"
    """Low-level connector raw data (debugging / bouncer-style relay)."""


EventHandler = Callable[..., Awaitable[None]]


class EventBus:
    """Async pub/sub bus for :class:`EventType` events."""

    def __init__(self) -> None:
        self._handlers: dict[EventType, list[EventHandler]] = {}

    def subscribe(self, event_type: EventType, handler: EventHandler) -> EventHandler:
        """Register ``handler`` for ``event_type``. Returns ``handler`` so it
        can be used as a decorator."""
        self._handlers.setdefault(event_type, []).append(handler)
        return handler

    def unsubscribe(self, event_type: EventType, handler: EventHandler) -> None:
        """Remove ``handler`` from ``event_type``. No-op if not registered."""
        handlers = self._handlers.get(event_type)
        if handlers and handler in handlers:
            handlers.remove(handler)

    def on(self, event_type: EventType) -> Callable[[EventHandler], EventHandler]:
        """Decorator form of :meth:`subscribe`."""

        def decorator(handler: EventHandler) -> EventHandler:
            return self.subscribe(event_type, handler)

        return decorator

    async def publish(self, event_type: EventType, *args: Any, **kwargs: Any) -> None:
        """Invoke every handler registered for ``event_type`` concurrently.

        Exceptions raised by handlers are logged and the bus keeps going —
        one bad subscriber must not block the rest.
        """
        handlers = list(self._handlers.get(event_type, ()))
        if not handlers:
            return
        results = await asyncio.gather(
            *(handler(*args, **kwargs) for handler in handlers),
            return_exceptions=True,
        )
        for handler, result in zip(handlers, results, strict=True):
            if isinstance(result, BaseException):
                logger.error(
                    "Event handler %s for %s raised: %s",
                    getattr(handler, "__qualname__", repr(handler)),
                    event_type,
                    result,
                    exc_info=result,
                )

    def handlers_for(self, event_type: EventType) -> list[EventHandler]:
        """Return a copy of registered handlers — useful for introspection
        and tests."""
        return list(self._handlers.get(event_type, ()))
