# SPDX-License-Identifier: Apache-2.0
"""Command registry and dispatch.

A "command" is a message that starts with the configured prefix (default
``!``). The :class:`CommandRegistry` matches the command name to a registered
handler and runs it.

Handlers receive the :class:`~turborg.core.envelope.InboundEnvelope` and may
return ``None`` (the bus publishes a ``COMMAND`` event automatically) or an
:class:`~turborg.core.envelope.OutboundEnvelope` to send a direct reply.
"""

from __future__ import annotations

import logging
import shlex
from collections.abc import Awaitable, Callable

from turborg.core.envelope import InboundEnvelope, OutboundEnvelope

logger = logging.getLogger(__name__)


CommandHandler = Callable[[InboundEnvelope], Awaitable[OutboundEnvelope | None]]


class CommandRegistry:
    """Map command names → handlers, with alias support."""

    def __init__(self, prefix: str = "!") -> None:
        if not prefix:
            raise ValueError("Command prefix cannot be empty.")
        self.prefix = prefix
        self._handlers: dict[str, CommandHandler] = {}

    def register(
        self,
        name: str,
        handler: CommandHandler,
        *,
        aliases: tuple[str, ...] = (),
    ) -> CommandHandler:
        """Register ``handler`` under ``name`` and any ``aliases``.

        Names are case-insensitive. Re-registering the same name overwrites
        the previous handler.
        """
        for key in (name, *aliases):
            if not key:
                raise ValueError("Command names cannot be empty.")
            self._handlers[key.lower()] = handler
        return handler

    def command(
        self,
        name: str,
        *,
        aliases: tuple[str, ...] = (),
    ) -> Callable[[CommandHandler], CommandHandler]:
        """Decorator form of :meth:`register`."""

        def decorator(handler: CommandHandler) -> CommandHandler:
            return self.register(name, handler, aliases=aliases)

        return decorator

    def get(self, name: str) -> CommandHandler | None:
        """Return the handler for ``name``, or ``None`` if unregistered."""
        return self._handlers.get(name.lower())

    def names(self) -> list[str]:
        """All registered command names and aliases (lowercased)."""
        return sorted(self._handlers.keys())

    def parse(self, envelope: InboundEnvelope) -> InboundEnvelope:
        """Return ``envelope`` annotated with parsed ``command`` and ``args``.

        If the text does not start with the prefix, returns ``envelope``
        unchanged (a frozen pydantic model is cheap to share).
        """
        text = envelope.text.lstrip()
        if not text.startswith(self.prefix):
            return envelope
        body = text[len(self.prefix) :]
        if not body or body[0].isspace():
            return envelope
        try:
            parts = shlex.split(body)
        except ValueError:
            parts = body.split()
        if not parts:
            return envelope
        cmd, *args = parts
        return envelope.model_copy(update={"command": cmd.lower(), "args": tuple(args)})

    async def dispatch(self, envelope: InboundEnvelope) -> OutboundEnvelope | None:
        """Run the handler for ``envelope.command``, if any.

        ``envelope`` should already have been passed through :meth:`parse`.
        Returns the handler's :class:`OutboundEnvelope` reply, or ``None``.
        """
        if envelope.command is None:
            return None
        handler = self.get(envelope.command)
        if handler is None:
            logger.debug("No handler registered for command %r", envelope.command)
            return None
        return await handler(envelope)
