# SPDX-License-Identifier: Apache-2.0
"""Exception hierarchy for turborg.

All exceptions raised by turborg code inherit from :class:`TurborgError`,
so users can catch the whole framework with one ``except``.
"""


class TurborgError(Exception):
    """Base class for every error raised by turborg."""


class ConfigError(TurborgError):
    """Configuration is missing, malformed, or contradictory."""


class ConnectorError(TurborgError):
    """A connector failed to start, send, or otherwise misbehaved."""


class ConnectorNotConnectedError(ConnectorError):
    """Operation requires a live connection that does not exist."""


class CommandError(TurborgError):
    """A registered command handler raised, or dispatch failed."""


class LLMError(TurborgError):
    """The LLM provider returned an error or unparseable response."""


class HiveError(TurborgError):
    """The hive client could not register or sync."""
