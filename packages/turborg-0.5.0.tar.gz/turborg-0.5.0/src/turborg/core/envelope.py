# SPDX-License-Identifier: Apache-2.0
"""Normalized message envelope shared by all connectors.

Connectors translate transport-specific messages (IRC PRIVMSG, Discord
``Message`` objects, WhatsApp webhooks, ...) into :class:`InboundEnvelope`
instances. The agent then dispatches handlers and produces
:class:`OutboundEnvelope` instances, which connectors translate back to
their native protocol.

The envelope is the single source of truth for "what does it mean for
turborg to receive or send a message" — handlers should never reach into
connector-specific types.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any
from uuid import UUID, uuid4

from pydantic import BaseModel, ConfigDict, Field


class _EnvelopeBase(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")


class InboundEnvelope(_EnvelopeBase):
    """A message received from a connector and normalized for the agent."""

    id: UUID = Field(default_factory=uuid4)
    connector: str
    """Name of the connector that produced this envelope (e.g. ``"irc"``)."""

    connector_instance: str = "default"
    """Stable identifier when several instances of the same connector run side
    by side (e.g. two IRC networks). Defaults to ``"default"``."""

    channel: str
    """Where the message was sent. Format is connector-specific
    (``"#channel"`` for IRC, snowflake id for Discord, etc.)."""

    sender: str
    """Who sent the message. Format is connector-specific (nick for IRC,
    user id for Discord, phone number for WhatsApp)."""

    text: str
    """The human-readable message body, stripped of protocol noise."""

    is_direct: bool = False
    """``True`` if this is a 1:1 / DM-style message, ``False`` if it was
    sent in a multi-user channel."""

    command: str | None = None
    """Parsed command name (without prefix) if :attr:`text` starts with the
    configured command prefix, else ``None``."""

    args: tuple[str, ...] = ()
    """Whitespace-split arguments after the command, empty tuple if none."""

    raw: str = ""
    """Original raw line/payload, kept for debugging and tests."""

    metadata: dict[str, Any] = Field(default_factory=dict)
    """Connector-specific extras (e.g. IRC ``hostmask``, Discord ``message_id``)."""

    received_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class OutboundEnvelope(_EnvelopeBase):
    """A message the agent wants a connector to send."""

    connector: str
    """Name of the connector that should deliver this message."""

    connector_instance: str = "default"

    channel: str
    """Destination channel/user for the connector to address."""

    text: str
    """Human-readable message body to send."""

    reply_to: UUID | None = None
    """If set, the :attr:`InboundEnvelope.id` this message is replying to.
    Useful for tracing and for connectors that support threaded replies."""

    metadata: dict[str, Any] = Field(default_factory=dict)
    """Connector-specific options (e.g. ``{"notice": True}`` for IRC NOTICE,
    ``{"ephemeral": True}`` for Discord)."""

    @classmethod
    def reply(cls, inbound: InboundEnvelope, text: str, **metadata: Any) -> OutboundEnvelope:
        """Build a reply targeted at the channel where ``inbound`` came from."""
        return cls(
            connector=inbound.connector,
            connector_instance=inbound.connector_instance,
            channel=inbound.sender if inbound.is_direct else inbound.channel,
            text=text,
            reply_to=inbound.id,
            metadata=metadata,
        )
