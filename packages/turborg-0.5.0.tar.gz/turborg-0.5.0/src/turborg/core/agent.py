# SPDX-License-Identifier: Apache-2.0
"""Agent — the orchestrator that ties connectors, events, and commands together.

A typical user-facing flow looks like this::

    agent = Agent()
    agent.add_connector(IRCConnector(...))

    @agent.on_command("ping")
    async def ping(envelope: InboundEnvelope) -> OutboundEnvelope:
        return OutboundEnvelope.reply(envelope, text="pong")

    @agent.on_event(EventType.BOOT)
    async def joined(agent: Agent) -> None:
        print("we're live")

    agent.run()

The agent itself is connector-agnostic and LLM-agnostic — those plug in
through :class:`~turborg.connectors.base.Connector` and (in later phases)
:class:`~turborg.llm.base.LLMProvider`.
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Callable
from typing import TYPE_CHECKING

from turborg.core.commands import CommandHandler, CommandRegistry
from turborg.core.envelope import InboundEnvelope, OutboundEnvelope
from turborg.core.events import EventBus, EventHandler, EventType
from turborg.core.exceptions import ConnectorError

if TYPE_CHECKING:
    from turborg.connectors.base import Connector
    from turborg.hive.base import HiveClient
    from turborg.llm.base import LLMProvider

logger = logging.getLogger(__name__)


class Agent:
    """Coordinates connectors, the event bus, and the command registry."""

    def __init__(
        self,
        *,
        command_prefix: str = "!",
        llm: LLMProvider | None = None,
        hive: HiveClient | None = None,
    ) -> None:
        self.events: EventBus = EventBus()
        self.commands: CommandRegistry = CommandRegistry(prefix=command_prefix)
        self.llm: LLMProvider | None = llm
        self.hive: HiveClient | None = hive
        self._connectors: dict[tuple[str, str], Connector] = {}
        self._stop_event: asyncio.Event = asyncio.Event()

    @property
    def connectors(self) -> list[Connector]:
        """Read-only view of the registered connectors."""
        return list(self._connectors.values())

    def add_connector(self, connector: Connector) -> None:
        """Register ``connector`` with this agent.

        Two connectors with the same ``(name, instance)`` pair cannot coexist;
        the second registration raises :class:`ConnectorError`.
        """
        key = (connector.name, connector.instance)
        if key in self._connectors:
            raise ConnectorError(f"Connector {key[0]!r} instance {key[1]!r} is already registered.")
        self._connectors[key] = connector

    def get_connector(self, name: str, instance: str = "default") -> Connector:
        """Return a previously registered connector or raise."""
        try:
            return self._connectors[(name, instance)]
        except KeyError as exc:
            raise ConnectorError(
                f"No connector named {name!r} (instance {instance!r}) is registered."
            ) from exc

    def on_command(
        self,
        name: str,
        *,
        aliases: tuple[str, ...] = (),
    ) -> Callable[[CommandHandler], CommandHandler]:
        """Decorator: register ``handler`` as a command. Shortcut for
        ``agent.commands.command(...)``."""
        return self.commands.command(name, aliases=aliases)

    def on_event(self, event_type: EventType) -> Callable[[EventHandler], EventHandler]:
        """Decorator: register ``handler`` for ``event_type``. Shortcut for
        ``agent.events.on(...)``."""
        return self.events.on(event_type)

    async def send(self, envelope: OutboundEnvelope) -> None:
        """Deliver ``envelope`` via the connector named on it."""
        connector = self.get_connector(envelope.connector, envelope.connector_instance)
        await connector.send(envelope)

    async def dispatch(self, envelope: InboundEnvelope) -> None:
        """Run command + event handlers for one inbound envelope."""
        parsed = self.commands.parse(envelope)
        await self.events.publish(EventType.MESSAGE, parsed)
        if parsed.command is None:
            return
        try:
            reply = await self.commands.dispatch(parsed)
        except Exception as exc:
            logger.exception("Command %r raised", parsed.command)
            await self.events.publish(EventType.ERROR, exc)
            return
        await self.events.publish(EventType.COMMAND, parsed)
        if reply is not None:
            await self.send(reply)

    async def start(self) -> None:
        """Start every connector, fire ``BOOT``, then drain envelopes until
        :meth:`stop` is called."""
        if not self._connectors:
            raise ConnectorError("No connectors registered. Call add_connector() first.")
        self._stop_event.clear()
        for connector in self._connectors.values():
            await connector.start()
        await self.events.publish(EventType.BOOT, self)
        try:
            async with asyncio.TaskGroup() as tg:
                for connector in self._connectors.values():
                    tg.create_task(self._drain(connector), name=f"drain:{connector.name}")
                tg.create_task(self._wait_for_stop(), name="wait_for_stop")
        finally:
            await self._shutdown()

    async def stop(self) -> None:
        """Signal the dispatch loop to wind down."""
        self._stop_event.set()

    def run(self) -> None:
        """Synchronous convenience wrapper around :meth:`start`."""
        try:
            asyncio.run(self.start())
        except KeyboardInterrupt:
            logger.info("Interrupted by user; shutting down.")

    async def _drain(self, connector: Connector) -> None:
        try:
            async for envelope in connector:
                await self.dispatch(envelope)
        except Exception as exc:
            logger.exception("Connector %r failed", connector.name)
            await self.events.publish(EventType.ERROR, exc)

    async def _wait_for_stop(self) -> None:
        await self._stop_event.wait()
        # Tell each connector to wind down; drain tasks exit when iterators raise.
        for connector in self._connectors.values():
            try:
                await connector.stop()
            except Exception:
                logger.exception("Error stopping connector %r", connector.name)

    async def _shutdown(self) -> None:
        await self.events.publish(EventType.SHUTDOWN, self)
        # Idempotent re-stop in case _wait_for_stop never ran (e.g. a drain
        # task crashed before stop_event was set).
        for connector in self._connectors.values():
            try:
                await connector.stop()
            except Exception:
                logger.exception("Error stopping connector %r", connector.name)
