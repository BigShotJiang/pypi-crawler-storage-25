"""Rate limiting wrapper around slowapi.

Sets sensible defaults on signup/login that block credential-stuffing and the
sort of accidental DDOS that runs up a fly.io bill. Per-route overrides come
straight from :class:`ParbakedConfig` so you can dial them per environment.
"""

from __future__ import annotations

from fastapi import FastAPI, Request
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded

from parbaked._clientip import client_ip
from parbaked.config import ParbakedConfig


def install_rate_limiting(app: FastAPI, config: ParbakedConfig) -> Limiter:
    """Wire a per-IP rate limiter onto ``app``. Idempotent.

    Returns the configured :class:`Limiter` so the caller can pass it into
    :func:`build_auth_router` for the per-route signup/login overrides.

    The bucket key is :func:`parbaked._clientip.client_ip`, which honours
    ``X-Forwarded-For`` when ``config.trust_proxy_headers`` is True. Without
    this, every request behind fly.io / Cloudflare / nginx shares one bucket
    (the proxy's IP) and ``ratelimit_signup`` becomes a global cap rather
    than per-client (#131).
    """
    limiter = getattr(app.state, "limiter", None)
    if limiter is None:
        def key_func(request: Request) -> str:
            # Fall back to the proxy's IP rather than None — slowapi keys must
            # be strings. An anonymous "unknown" bucket is still safer than
            # crashing the limiter or letting un-IP'd requests bypass it.
            return client_ip(request, config) or "unknown"

        limiter = Limiter(
            key_func=key_func,
            default_limits=[config.ratelimit_global],
            headers_enabled=True,
        )
        app.state.limiter = limiter
        app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
    return limiter
