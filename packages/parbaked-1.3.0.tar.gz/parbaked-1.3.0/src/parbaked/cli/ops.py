"""parbaked dev / tunnel / deploy / logs / secrets.

One cross-platform path for every dev / deploy operation. ``make`` doesn't
ship on Windows by default, so we don't use it anywhere — the same
``parbaked <command>`` works on every supported OS.
"""

from __future__ import annotations

import os
import re
import shutil
import socket
import subprocess
import threading
import time
import tomllib
from pathlib import Path

import typer

from parbaked.cli._console import (
    console,
    error,
    info,
    stderr_console,
    success,
)

# Match the ``https://*.trycloudflare.com`` quick-tunnel URLs cloudflared
# prints on stdout/stderr a few seconds after launch. The URL goes into a
# bordered "panel" that includes leading whitespace and surrounding text —
# anchor on the scheme so we capture the URL regardless of decoration.
_TRYCLOUDFLARE_URL_RE = re.compile(
    r"https://[a-z0-9-]+\.trycloudflare\.com"
)

_CLOUDFLARED_INSTALL_HINT = (
    "Install cloudflared:\n"
    "  macOS:    brew install cloudflared\n"
    "  Windows:  winget install --id Cloudflare.cloudflared\n"
    "  Linux:    https://github.com/cloudflare/cloudflared/releases"
)


def _require(binary: str, install_hint: str) -> None:
    """Exit with a friendly error if ``binary`` is not on PATH."""
    if shutil.which(binary) is None:
        error(f"{binary} not found on PATH.")
        # Multi-line install hint contains literal bracketed text in some
        # cases — keep markup off so the URLs/braces render as-is.
        stderr_console.print(install_hint, markup=False, highlight=False)
        raise typer.Exit(1)


def _run(cmd: list[str], *, env: dict[str, str] | None = None) -> int:
    """Run a subprocess inheriting stdio. Returns the exit code.

    Uses ``shell=False`` everywhere — argument values come from the user's
    own typer args, so we want them treated as a single token, not parsed
    by a shell.
    """
    try:
        return subprocess.run(cmd, env=env, check=False).returncode
    except KeyboardInterrupt:
        # Ctrl-C while the subprocess was running. Treat it as a clean exit
        # — the user told the process to stop, no traceback needed.
        return 0


def _user_set_app_url() -> bool:
    """True if the user has configured ``app_url`` anywhere parbaked respects.

    We check env, ``.env``, and ``parbaked.toml`` because pydantic-settings
    will load from all three. If any of them sets ``app_url``, ``parbaked
    dev`` must not clobber it with its localhost-port default — the user
    might be pointing at a cloudflared tunnel, a custom hostname, etc.
    """
    if "PARBAKED_APP_URL" in os.environ:
        return True
    env_file = Path(".env")
    if env_file.exists():
        try:
            for raw in env_file.read_text().splitlines():
                line = raw.strip()
                if not line or line.startswith("#"):
                    continue
                # python-dotenv (which pydantic-settings uses) accepts an
                # optional ``export`` prefix. Strip it before key-matching,
                # otherwise an ``export PARBAKED_APP_URL=...`` line would
                # silently get clobbered by our injected default.
                if line.startswith("export "):
                    line = line[len("export "):].lstrip()
                key = line.split("=", 1)[0].strip()
                if key == "PARBAKED_APP_URL":
                    return True
        except OSError:
            pass
    toml_file = Path("parbaked.toml")
    if toml_file.exists():
        try:
            if "app_url" in tomllib.loads(toml_file.read_text()):
                return True
        except (OSError, tomllib.TOMLDecodeError):
            pass
    return False


# Path the running ``parbaked dev`` writes its bound port to so URL-minting
# commands in OTHER shells (``parbaked admin signin``, ``parbaked users
# issue-reset``) can target the actual server rather than the
# ``config.app_url`` default (#333). Written on dev startup, removed on
# exit (best-effort — a SIGKILL'd dev leaves a stale file behind, hence
# the read-side staleness check via ``os.kill(pid, 0)``).
_DEV_PORT_FILE = Path(".parbaked/dev_port")


def _read_dev_port() -> int | None:
    """Return the port a sibling ``parbaked dev`` is bound to, if any.

    Reads ``.parbaked/dev_port`` written by ``dev`` on startup. The file
    contains ``<pid>\\n<port>`` so we can also check the process is still
    alive — a SIGKILL'd dev or a crashed reload leaves the file behind.

    Returns ``None`` when:
    - the file doesn't exist (no dev running, or pre-#333 dev),
    - the file is malformed,
    - the pid in the file is no longer a live process on this machine.

    Caller falls back to ``config.app_url`` when ``None``.

    Process-liveness check is best-effort cross-platform: ``os.kill(pid,
    0)`` raises ``ProcessLookupError`` for dead pids and
    ``PermissionError`` for live-but-not-ours (treat as live — same user
    typically, and false-positive "live" just means we use the cached
    port, which is the right behaviour). On Windows, ``os.kill(pid, 0)``
    also raises ``ProcessLookupError`` for dead pids via the underlying
    ``TerminateProcess`` shim.
    """
    if not _DEV_PORT_FILE.exists():
        return None
    try:
        raw = _DEV_PORT_FILE.read_text().strip()
    except OSError:
        return None
    lines = [ln.strip() for ln in raw.splitlines() if ln.strip()]
    if len(lines) < 2:
        # Pre-#333 (or hand-written) port-only file — still honour it
        # since we have no pid to liveness-check anyway.
        if len(lines) == 1 and lines[0].isdigit():
            port = int(lines[0])
            if 1 <= port <= 65535:
                return port
        return None
    pid_str, port_str = lines[0], lines[1]
    if not pid_str.isdigit() or not port_str.isdigit():
        return None
    pid, port = int(pid_str), int(port_str)
    if not (1 <= port <= 65535):
        return None
    # Liveness: signal 0 is a no-op probe.
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return None
    except (PermissionError, OSError):
        # Live but owned by another user (PermissionError), or the OS
        # rejected the probe for an unrelated reason. Trust the file —
        # the wrong call here is to ignore a still-running dev server.
        pass
    return port


def _write_dev_port(port: int) -> Path | None:
    """Record this dev process's bound port for sibling CLI commands (#333).

    Writes ``<pid>\\n<port>\\n`` to ``.parbaked/dev_port``. Returns the
    path written (so the caller can delete it on exit) or ``None`` if
    the write failed — a missing port file just degrades to the
    pre-#333 ``config.app_url`` behaviour, never crashes ``dev``.
    """
    try:
        _DEV_PORT_FILE.parent.mkdir(parents=True, exist_ok=True)
        _DEV_PORT_FILE.write_text(f"{os.getpid()}\n{port}\n")
    except OSError:
        return None
    return _DEV_PORT_FILE


def resolved_localhost_base_url(config) -> str:  # noqa: ANN001 — duck-typed
    """Return the base URL URL-minting CLI commands should use (#333).

    Precedence:
    1. ``PARBAKED_APP_URL`` env (or ``.env`` / ``parbaked.toml`` ``app_url``)
       — the user has been explicit, never override.
    2. ``.parbaked/dev_port`` written by a running ``parbaked dev`` in
       this project — substitute its actual port into ``localhost``.
    3. ``config.app_url`` default (``http://localhost:8000``).

    Used by ``parbaked admin signin``, ``parbaked users issue-reset``,
    and their MCP siblings — every shell-minted URL routes through here
    so the ``parbaked dev --port 8765`` case yields URLs that actually
    resolve to the running server.
    """
    base = config.app_url.rstrip("/")
    if _user_set_app_url():
        # User has been explicit somewhere parbaked respects — never
        # override even when we could detect a different running port.
        return base
    port = _read_dev_port()
    if port is None:
        return base
    return f"http://localhost:{port}"


def _start_cloudflared(port: int) -> tuple[subprocess.Popen, str]:
    """Spawn ``cloudflared tunnel --url http://localhost:<port>`` and wait
    for it to print its ``*.trycloudflare.com`` URL.

    Returns the running ``Popen`` handle and the captured tunnel URL. The
    caller is responsible for terminating the process when done — usually
    in a try/finally around the uvicorn run.

    cloudflared prints the tunnel URL on stderr inside a bordered panel a
    few seconds after launch; we tail combined stdout/stderr from a thread
    and scan each line for the URL. Output is mirrored back to the user's
    terminal so they still see cloudflared's startup logs (handy when DNS
    or signature checks fail and we'd otherwise eat the error).

    Raises ``typer.Exit(1)`` if cloudflared dies before printing a URL, or
    if we time out waiting (~30s — generous for slow CI / first-launch
    cert fetch but short enough that a misconfigured local network surfaces
    quickly rather than hanging forever).
    """
    proc = subprocess.Popen(  # noqa: S603 — argv is hard-coded
        ["cloudflared", "tunnel", "--url", f"http://localhost:{port}"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
    )

    tunnel_url: list[str | None] = [None]

    def _tail() -> None:
        # Drain cloudflared's combined output: mirror every line back to the
        # operator's stderr (so they see startup progress / errors) AND scan
        # for the trycloudflare URL the moment it lands.
        assert proc.stdout is not None
        for line in proc.stdout:
            # Subprocess output is arbitrary — must not be parsed as rich
            # markup. ``stderr_console.print(..., markup=False)`` is the
            # rich-equivalent of ``typer.echo(..., err=True)``.
            stderr_console.print(line.rstrip(), markup=False, highlight=False)
            if tunnel_url[0] is None:
                match = _TRYCLOUDFLARE_URL_RE.search(line)
                if match:
                    tunnel_url[0] = match.group(0)

    tail = threading.Thread(target=_tail, daemon=True)
    tail.start()

    # Poll for the URL. cloudflared usually prints within 2-5s; cap at 30s
    # to keep CI / debug-loop pain bounded.
    deadline = time.monotonic() + 30.0
    while tunnel_url[0] is None and time.monotonic() < deadline:
        if proc.poll() is not None:
            error(
                "cloudflared exited before printing a tunnel URL. "
                "See the output above for the reason."
            )
            raise typer.Exit(1)
        time.sleep(0.1)

    if tunnel_url[0] is None:
        proc.terminate()
        error(
            "Timed out (30s) waiting for cloudflared to print its "
            "trycloudflare.com URL. Try `parbaked tunnel` standalone "
            "to debug."
        )
        raise typer.Exit(1)

    return proc, tunnel_url[0]


def _port_in_use(host: str, port: int) -> bool:
    """Return ``True`` if something is already listening on ``host:port`` (#315).

    Pre-flight check before we hand control to uvicorn. We use
    ``connect_ex`` rather than ``bind`` because ``bind`` on a non-loopback
    interface (e.g. ``0.0.0.0``) can succeed for a fleeting moment on
    macOS even when another process already holds the port via SO_REUSEPORT
    games, and we'd then race uvicorn to the same error. ``connect_ex``
    asks "is there a listener?" directly and is the same probe industry
    tools (Vite, Streamlit) use.

    ``host=0.0.0.0`` means "all interfaces", which isn't a valid connect
    target — substitute the loopback so the probe asks "is anyone
    listening on the local box at this port?". That's the right
    question: uvicorn's bind on 0.0.0.0 would conflict with a listener
    on 127.0.0.1 just as much as with one on 0.0.0.0.
    """
    probe_host = "127.0.0.1" if host in ("0.0.0.0", "") else host
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(0.5)
            return sock.connect_ex((probe_host, port)) == 0
    except OSError:
        # IPv6 hosts (``::``, ``::1``) raise ``socket.gaierror`` against
        # an ``AF_INET`` socket — also any other "we can't probe this
        # safely" error. Returning False means "we couldn't determine
        # the port was in use" which lets uvicorn handle its own
        # binding errors as a fallback rather than blocking a valid
        # config (#315 Devin).
        return False


def _identify_port_holder(port: int) -> tuple[int | None, str | None]:
    """Best-effort: return ``(pid, process_name)`` of the listener on ``port``.

    Tries ``lsof -i :PORT -sTCP:LISTEN -P -n`` and parses the first
    matching line. Defensive: ``lsof`` is not installed on every box
    (some minimal Linux images, all stock Windows) — we swallow the
    ``FileNotFoundError`` and return ``(None, None)`` so the caller
    can still surface a useful "port in use" error without the PID.

    Output format (whitespace-aligned columns):

        COMMAND  PID  USER  FD  TYPE  DEVICE  SIZE/OFF  NODE  NAME
        Python  4823  sam   3u  IPv4  …       0t0       TCP   *:8000 (LISTEN)

    We pull the second token (PID) and the first (COMMAND). The header
    row is skipped by matching only lines whose second token is an
    integer.
    """
    try:
        result = subprocess.run(
            ["lsof", "-i", f":{port}", "-sTCP:LISTEN", "-P", "-n"],
            capture_output=True,
            text=True,
            check=False,
            timeout=2.0,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return (None, None)
    for line in result.stdout.splitlines():
        parts = line.split()
        if len(parts) < 2:
            continue
        try:
            pid = int(parts[1])
        except ValueError:
            continue
        return (pid, parts[0])
    return (None, None)


def dev(
    port: int = typer.Option(8000, "--port", "-p", help="Port to bind"),
    host: str = typer.Option(
        "127.0.0.1",
        "--host",
        help="Host interface (default 127.0.0.1; use 0.0.0.0 for LAN access)",
    ),
    reload: bool = typer.Option(
        True, "--reload/--no-reload", help="Auto-reload on source changes (default on)"
    ),
    tunnel: bool = typer.Option(
        False,
        "--tunnel",
        help=(
            "Expose the app via a cloudflared quick tunnel and pre-wire "
            "PARBAKED_APP_URL + PARBAKED_TRUST_PROXY_HEADERS for you. "
            "Replaces the four-step ``parbaked tunnel`` + env-var dance "
            "with a single command. Requires cloudflared on PATH."
        ),
    ),
) -> None:
    """Run the app locally with uvicorn auto-reload.

    The kernel runtime (``parbaked.runtime:create_app``) is the only
    supported entry point (#150). The pre-v1.3 ``--app`` override flag
    has been removed — AGENTS.md is explicit that the kernel runtime
    is the supported path, and the override turned out to be a
    vestigial backdoor (its own help text described it as "for unusual
    layouts"). Devs needing custom ASGI plumbing point their own server
    at a 2-line ``wsgi.py`` instead — see AGENTS.md "Advanced".

    ``--tunnel`` bundles cloudflared + uvicorn into one terminal: parbaked
    starts cloudflared as a subprocess, captures the
    ``https://*.trycloudflare.com`` URL it prints, sets
    ``PARBAKED_APP_URL`` + ``PARBAKED_TRUST_PROXY_HEADERS=true`` for the
    uvicorn child, and runs the server in the foreground. Ctrl-C tears
    down both. ``parbaked tunnel`` stays as the tunnel-only path for
    when uvicorn already runs somewhere else.
    """
    # Kernel runtime is the canonical (and only) entry point.
    if not Path("parbaked.toml").exists():
        error(
            "No parbaked.toml in this directory.\n"
            "  Run `parbaked new <name>` to scaffold a project, "
            "or cd into one."
        )
        raise typer.Exit(1)
    # ``--tunnel`` precondition (#212): check cloudflared exists before we
    # touch uvicorn / spawn anything. Without this, the uvicorn-missing
    # branch below fires first and the operator sees "uvicorn not found"
    # despite passing --tunnel — confusing and wrong.
    if tunnel:
        _require("cloudflared", _CLOUDFLARED_INSTALL_HINT)
    # Pre-flight port check (#315). Without this, uvicorn boots, fails
    # with a bare ``[Errno 48] Address already in use``, and dumps a
    # Python traceback + a ``coroutine ... was never awaited`` warning.
    # Probe the port ourselves, identify the holder via lsof when we can,
    # and surface a friendly message before uvicorn ever runs.
    if _port_in_use(host, port):
        pid, name = _identify_port_holder(port)
        if pid is not None:
            holder = f"{name} (pid {pid})" if name else f"pid {pid}"
            error(
                f"Port {port} is already in use by {holder}.\n"
                f"  Stop it with: kill {pid}\n"
                f"  Or pick a different port: parbaked dev --port {port + 1}"
            )
        else:
            # lsof missing / unparseable (Windows, minimal Linux images).
            # Skip the holder identification but still give the operator
            # an actionable next step.
            error(
                f"Port {port} is already in use.\n"
                f"  Pick a different port: parbaked dev --port {port + 1}"
            )
        raise typer.Exit(1)
    app = "parbaked.runtime:create_app"

    cmd = ["uvicorn", app, "--port", str(port), "--host", host, "--factory"]
    if reload:
        cmd.append("--reload")
        # Default uvicorn reload only watches ``*.py``. Add the TOML so
        # editing parbaked.toml triggers a restart — the config change
        # shows up immediately, not "next time you ctrl-c".
        cmd.extend(["--reload-include", "*.py", "--reload-include", "parbaked.toml"])
    # Prefer ``uv run uvicorn`` when uv is on PATH. This pins uvicorn +
    # parbaked to the project's pyproject.toml/.venv rather than whatever
    # ``uvicorn`` happens to be first on $PATH — a half-broken system
    # uvicorn (e.g. missing ``click``) used to trip parbaked dev because
    # ``shutil.which("uvicorn")`` resolved to it. ``uv run`` auto-syncs
    # the project venv on first run, so this is also the "post-clone,
    # haven't run uv sync yet" recovery path.
    if shutil.which("uv") is not None:
        cmd = ["uv", "run", *cmd]
    elif shutil.which("uvicorn") is None:
        _require("uvicorn", "Install with: pip install uvicorn (or use uv)")
    # Sync app_url to the bind port so the boot banner + magic-link emails
    # point at the actual server. Without this, `parbaked dev --port 8765`
    # would email links pointing at port 8000 (the config default), and the
    # user clicking them in their terminal hits "site can't be reached."
    # Only set when the user hasn't configured app_url elsewhere — never
    # clobber an explicit env / .env / parbaked.toml value.
    env = os.environ.copy()

    # ``--tunnel``: start cloudflared first, capture its URL, then point the
    # uvicorn child at it via PARBAKED_APP_URL + flip the trust-proxy header
    # flag (#212). cloudflared keeps running in the background; we tear it
    # down once uvicorn exits.
    cloudflared_proc: subprocess.Popen | None = None
    if tunnel:
        cloudflared_proc, tunnel_url = _start_cloudflared(port)
        info("")
        # ``soft_wrap=True`` so the trycloudflare URL prints intact even
        # when stdout is captured at 80-cols (#221 CI gotcha).
        console.print(
            f"[green]✓[/green] Tunnel ready: [cyan]{tunnel_url}[/cyan]",
            soft_wrap=True,
        )
        info("")
        # Tunnel URL beats the localhost default AND any user-configured
        # PARBAKED_APP_URL — the operator passed --tunnel because they want
        # the public hostname in their emails / banner, not whatever was in
        # .env. If they'd wanted .env to win they'd run dev + tunnel
        # separately.
        env["PARBAKED_APP_URL"] = tunnel_url
        env["PARBAKED_TRUST_PROXY_HEADERS"] = "true"
    elif not _user_set_app_url():
        display_host = "localhost" if host in ("127.0.0.1", "0.0.0.0") else host
        env["PARBAKED_APP_URL"] = f"http://{display_host}:{port}"

    # Record the bound port so sibling CLI shells (``parbaked admin
    # signin``, ``parbaked users issue-reset``) can mint URLs that
    # actually resolve to this server instead of the
    # ``http://localhost:8000`` default (#333). Skip when ``--tunnel`` is
    # active — the public trycloudflare URL is what those commands
    # should target then, and ``env["PARBAKED_APP_URL"]`` already wins
    # over the dev-port path via ``_user_set_app_url``.
    port_file: Path | None = None
    if not tunnel:
        port_file = _write_dev_port(port)

    try:
        rc = _run(cmd, env=env)
    finally:
        if cloudflared_proc is not None:
            cloudflared_proc.terminate()
            try:
                cloudflared_proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                cloudflared_proc.kill()
        # Best-effort cleanup. A SIGKILL'd ``dev`` can't run this — the
        # read side's pid-liveness check (``_read_dev_port``) is the
        # braces for that case.
        if port_file is not None:
            import contextlib as _contextlib

            with _contextlib.suppress(OSError):
                port_file.unlink()
    raise typer.Exit(rc)


def tunnel(
    port: int | None = typer.Option(
        None,
        "--port",
        "-p",
        help=(
            "Local port to expose. Defaults to the port a sibling "
            "``parbaked dev`` is bound to (via ``.parbaked/dev_port``), "
            "falling back to 8000."
        ),
    ),
) -> None:
    """Expose http://localhost:<port> via a cloudflared quick tunnel.

    Prints a *.trycloudflare.com URL — set ``PARBAKED_APP_URL`` to it before
    signing up so magic links resolve correctly. The URL is ephemeral and
    dies when you Ctrl-C this command.

    Sets ``PARBAKED_TRUST_PROXY_HEADERS=true`` for the cloudflared
    subprocess only — but that's a no-op (cloudflared doesn't read parbaked
    env vars). The real point of doing it here is documentation: the
    operator running ``parbaked tunnel`` is implicitly putting cloudflared
    in front of their app, so the parbaked process behind the tunnel
    *should* be started with that env var too. We can't reach across to
    the user's already-running ``parbaked dev`` to flip it, so we surface
    a reminder in the boot banner instead.

    Port resolution (#333):
    1. ``--port`` if passed,
    2. the port from a running sibling ``parbaked dev`` (``.parbaked/dev_port``),
    3. ``8000`` as the legacy default.

    So ``parbaked dev --port 8765`` + ``parbaked tunnel`` in another shell
    Just Works without manually re-passing the port.
    """
    _require("cloudflared", _CLOUDFLARED_INSTALL_HINT)
    if port is None:
        detected = _read_dev_port()
        if detected is not None:
            port = detected
            info(f"Auto-detected `parbaked dev` on port {port}.")
        else:
            port = 8000
    info(
        "Tunnel starting — copy the trycloudflare.com URL and set "
        "PARBAKED_APP_URL to it."
    )
    info(
        "  Tip: `parbaked dev --tunnel` bundles both in one terminal "
        "(#212) — no env-var copy-paste needed."
    )
    info(
        "  Tip: restart `parbaked dev` with PARBAKED_TRUST_PROXY_HEADERS=true "
        "so audit logs / rate limits see the real client IP through the tunnel."
    )
    env = os.environ.copy()
    env["PARBAKED_TRUST_PROXY_HEADERS"] = "true"
    # #342: spawn cloudflared as a managed subprocess so Ctrl-C from the
    # parent reliably tears the child down. Using ``_run`` (which wraps
    # ``subprocess.run``) leaked orphans on some platforms — the child
    # didn't always see the SIGINT, and the python parent exited while
    # cloudflared kept running with a live ``*.trycloudflare.com`` URL
    # pointing at localhost. Wrap Popen with try/finally: on
    # KeyboardInterrupt, terminate; if the child doesn't exit within 5s,
    # kill -9. This matches the pattern already used for ``--tunnel``
    # bundled mode in ``dev()``.
    proc = subprocess.Popen(  # noqa: S603 — argv is hard-coded
        ["cloudflared", "tunnel", "--url", f"http://localhost:{port}"],
        env=env,
    )
    try:
        rc = proc.wait()
    except KeyboardInterrupt:
        rc = 0  # user-initiated stop is a clean exit
    finally:
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
    raise typer.Exit(rc)


def _require_onboarded(action: str) -> None:
    """Exit with a friendly pointer at ``parbaked init`` when the project
    hasn't been onboarded to fly.io yet (#193).

    The fly-shelling commands (``deploy`` / ``logs`` / ``push-secrets`` /
    ``destroy``) all need a fly app name. Before ``parbaked init``, there
    is none — and ``flyctl`` returns a cryptic "could not find app" error
    that doesn't mention parbaked at all. The dev's first interaction
    with these commands becomes a fly error instead of a parbaked-flavored
    pointer at the right next step.
    """
    from parbaked.cli.deploy_wizard import already_onboarded

    if already_onboarded():
        return
    error(
        f"Can't `{action}` — this project hasn't been onboarded to fly.io yet.\n\n"
        "  Run `parbaked init` first — the wizard installs flyctl,\n"
        "  signs you in, claims a unique fly app name, pushes secrets,\n"
        "  and runs the first deploy.\n\n"
        "  After that, `parbaked deploy` is the zero-prompt re-deploy."
    )
    raise typer.Exit(1)


def deploy() -> None:
    """Run ``fly deploy``, generating Dockerfile + fly.toml from parbaked.toml.

    v1.0 behaviour: if neither ``Dockerfile`` nor ``fly.toml`` exists at
    project root, parbaked renders both from templates into ``.parbaked/build/``
    (driven by ``parbaked.toml``) and points ``fly deploy`` at them. The
    generated ``fly.toml`` carries the volume mount + env vars for SQLite
    persistence.

    If you have a hand-written ``Dockerfile`` or ``fly.toml`` at project root
    (v0.7-era projects, or post-eject custom setups), parbaked defers to your
    files — never clobbers them.

    Orchestration lives in ``parbaked.operations.deploy.run_deploy``;
    this command is the typer wrapper that prints progress banners and
    translates exceptions to ``typer.Exit``. The MCP ``tool_deploy``
    tool calls the same operation directly so the two surfaces don't
    drift.
    """
    _require(
        "fly",
        "Install flyctl: https://fly.io/docs/flyctl/install/ "
        "(or `brew install flyctl` on macOS).",
    )

    from parbaked.cli.deploy_gen import user_owns_deploy_files
    from parbaked.config import ParbakedConfig
    from parbaked.operations.deploy import generate_deploy_files

    if user_owns_deploy_files():
        info("Using your Dockerfile / fly.toml at project root.")
        raise typer.Exit(_run(["fly", "deploy"]))

    if not Path("parbaked.toml").exists():
        error(
            "No parbaked.toml and no Dockerfile/fly.toml found. "
            "Run `parbaked new <name>` to scaffold a project."
        )
        raise typer.Exit(1)

    # Precondition (#153): generating from parbaked.toml only works after
    # `parbaked init` has claimed the unique fly app name. Without it,
    # ``deploy_gen.generate`` falls back to ``config.app_name`` and
    # ``fly deploy`` errors with a cryptic "could not find app" that
    # doesn't mention parbaked at all — the dev's first deploy interaction
    # is a fly error and their conclusion is "parbaked deploy is broken."
    _require_onboarded("deploy")

    # ``ParbakedConfig()`` (unknown toml keys) raises
    # ``ParbakedConfigError``; ``generate_deploy_files()``
    # (``frontend.source_dir`` outside project root, #121) raises
    # ``ParbakedDeployError``. Both subclass ``ValueError`` so callers
    # from before #221 still work, but the specific catch documents the
    # contract — without a catch, typer/Python prints the raw traceback
    # and the friendly text gets buried under stack frames (#193).
    from parbaked.exceptions import ParbakedError

    try:
        config = ParbakedConfig()
        files = generate_deploy_files(config)
    except (ParbakedError, ValueError) as exc:
        # ``ValueError`` covers malformed parbaked.toml — pydantic-settings'
        # toml source raises ``tomllib.TOMLDecodeError`` (a ``ValueError``
        # subclass) on syntax errors. ``ParbakedError`` covers the
        # generator's own friendly-error path (#193 Devin: narrowing to
        # only ParbakedError dropped TOMLDecodeError back into a raw
        # traceback).
        error(str(exc))
        raise typer.Exit(1) from None

    info(f"Generated {files.dockerfile}")
    info(f"Generated {files.fly_toml}")
    if files.dockerignore_written is not None:
        info(f"Generated {files.dockerignore_written}")
    if files.volume_ready:
        success(f"fly volume parbaked_data ({config.fly_region}) ready")

    raise typer.Exit(
        _run(
            [
                "fly", "deploy",
                "--config", str(files.fly_toml),
                "--dockerfile", str(files.dockerfile),
            ]
        )
    )


def logs() -> None:
    """Tail fly.io application logs."""
    _require("fly", "Install flyctl: https://fly.io/docs/flyctl/install/")
    # #193: before `parbaked init`, there's no fly app to tail logs from —
    # ``fly logs`` would surface a cryptic "no app specified" error. Point
    # at the right next command instead.
    _require_onboarded("logs")
    # #339: pass ``-a <fly_app_name>`` explicitly. flyctl otherwise looks
    # for ``fly.toml`` in cwd to derive the app name, but parbaked's
    # generated fly.toml lives at ``.parbaked/build/fly.toml`` — flyctl
    # can't find it and bails with "Error: the config for your app is
    # missing an app name." Read the cached app name from the same
    # ``.parbaked/deploy.json`` the wizard wrote (which ``_require_onboarded``
    # has already proven exists), so this keeps working even if
    # ``.parbaked/build`` was cleaned.
    from parbaked.cli.deploy_wizard import load_state

    fly_app_name = load_state().get("fly_app_name")
    raise typer.Exit(_run(["fly", "logs", "-a", fly_app_name]))


def secrets(
    env_file: Path = typer.Option(
        Path(".env"), "--env-file", "-e", help="Path to env file (default ./.env)"
    ),
) -> None:
    """Push every line of ``.env`` to fly secrets in one shot.

    Wraps ``fly secrets import`` which reads ``KEY=VALUE`` lines from stdin.
    """
    _require("fly", "Install flyctl: https://fly.io/docs/flyctl/install/")
    # #193: before `parbaked init`, there's no fly app to push secrets to.
    # ``fly secrets import`` would error with "no app specified" — point
    # at the right next command instead.
    _require_onboarded("push-secrets")
    if not env_file.exists():
        error(
            f"{env_file} not found — copy .env.example to .env and fill in your secrets."
        )
        raise typer.Exit(1)

    # #340: pass ``-a <fly_app_name>`` explicitly — same root cause as
    # #339 (logs). flyctl looks for ``fly.toml`` in cwd to derive the app
    # name, but parbaked's fly.toml is at ``.parbaked/build/fly.toml``,
    # so flyctl errors with "Error: the config for your app is missing
    # an app name." Read the cached app name from
    # ``.parbaked/deploy.json`` — ``_require_onboarded`` has already
    # proven it exists.
    from parbaked.cli.deploy_wizard import load_state

    fly_app_name = load_state().get("fly_app_name")
    info(f"Pushing {env_file} → fly secrets…")
    # `fly secrets import` reads from stdin
    try:
        with env_file.open("rb") as fh:
            rc = subprocess.run(
                ["fly", "secrets", "import", "-a", fly_app_name],
                stdin=fh,
                check=False,
            ).returncode
    except KeyboardInterrupt:
        rc = 130
    raise typer.Exit(rc)


def destroy(
    app: str | None = typer.Option(
        None,
        "--app",
        help=(
            "Override the fly app to destroy. Defaults to the project's "
            "app — read from ``parbaked.toml`` (or ``.parbaked/deploy.json`` "
            "if the wizard wrote one). Use for orphan cleanup when the "
            "project is gone but the fly app is still hanging around."
        ),
    ),
) -> None:
    """Destroy the fly app for this project.

    Closes the lifecycle — ``deploy / logs / secrets / destroy`` all
    via parbaked. No more raw ``flyctl`` for the indie path.

    Requires you to type the app name to confirm. The type-to-confirm
    UX matches what ``fly apps destroy --yes`` skips on purpose — this
    command exists because we want the confirmation, not in spite of it.

    Cleans up ``.parbaked/deploy.json`` after a successful destroy so
    the next ``parbaked deploy`` re-runs the wizard.
    """
    import json as _json

    _require(
        "fly",
        "Install flyctl: https://fly.io/docs/flyctl/install/ "
        "(or `brew install flyctl` on macOS).",
    )

    # #193: when ``--app NAME`` is passed, the user is explicitly cleaning
    # up an orphan fly app whose project may be long gone — the explicit
    # flag IS their override and we skip the onboarding check. Without
    # ``--app`` though, we're operating on the current project; if that
    # project never made it through ``parbaked init``, fly would error
    # with a cryptic "could not find app" rather than the friendly
    # parbaked pointer.
    if app is None:
        _require_onboarded("destroy")

    target = app
    if target is None:
        # Read the project's fly app name from .parbaked/deploy.json
        # first (the wizard's cache), falling back to parbaked.toml's
        # app_name field.
        deploy_state = Path(".parbaked/deploy.json")
        if deploy_state.exists():
            try:
                target = _json.loads(deploy_state.read_text()).get("fly_app_name")
            except (OSError, _json.JSONDecodeError):
                target = None
        if target is None and Path("parbaked.toml").exists():
            try:
                target = tomllib.loads(Path("parbaked.toml").read_text()).get("app_name")
            except (OSError, tomllib.TOMLDecodeError):
                target = None

    if not target:
        error(
            "Couldn't determine the fly app to destroy. Pass --app NAME, "
            "or run from a parbaked project directory."
        )
        raise typer.Exit(1)

    info("")
    console.print(f"  [yellow]⚠  This will permanently destroy: {target}[/yellow]")
    info("     All machines, volumes, secrets, and the app will be gone.")
    info("     This cannot be undone. fly does NOT keep backups.")
    info("")
    confirmation = typer.prompt(f"  Type the app name ({target}) to confirm")
    if confirmation.strip() != target:
        error("Confirmation didn't match. Nothing destroyed.")
        raise typer.Exit(1)

    rc = subprocess.run(
        ["fly", "apps", "destroy", target, "--yes"],
        check=False,
    ).returncode
    if rc != 0:
        error("fly apps destroy failed — see above for fly's output.")
        raise typer.Exit(rc)

    # Clear the wizard's onboarding cache so the next `parbaked deploy`
    # re-runs the wizard (otherwise it'd point at the now-gone app).
    state_path = Path(".parbaked/deploy.json")
    if state_path.exists():
        state_path.unlink()
    success(f"destroyed fly app `{target}`")
