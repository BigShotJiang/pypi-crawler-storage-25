"""Shared rich Console singletons + thin helpers for the CLI (#221).

Every parbaked CLI command imports ``console`` / ``stderr_console`` from
this module rather than constructing its own ``rich.Console`` so the
output style (theme, width, force-terminal, etc.) stays consistent across
the CLI surface. Tests + the typer ``CliRunner`` capture rich output
identically to ``typer.echo`` — rich detects a non-TTY stream and turns
off colour automatically, so plain assertions like ``"✓ approved" in
output`` keep working.

Helpers are intentionally minimal — ``success`` / ``error`` / ``warn`` /
``info`` / ``plain`` cover the three or four shapes the CLI actually
emits. Anything fancier (tables, panels, prompts) imports rich directly
in the command module so this file stays under "thin abstraction".

The success/error/warn helpers PREPEND the project's house glyph
(``✓`` / ``✗`` / ``⚠``) so callers can pass the message body alone —
the few existing call sites that already include the glyph have been
trimmed to match.
"""

from __future__ import annotations

from rich.console import Console

# Singletons. ``stderr=True`` swaps the underlying stream — ``rich``
# still picks up the same TTY/non-TTY detection so colour falls off
# cleanly when the operator pipes the output somewhere.
console = Console()
stderr_console = Console(stderr=True)


def _print_with_glyph(
    target: Console, glyph: str, style: str, message: str
) -> None:
    """Render ``<colored-glyph> <message>`` with markup parsing OFF.

    Critical: parbaked CLI messages routinely contain literal square
    brackets — ``parbaked[mcp]``, JSON paths, pip extras, regex
    snippets — that would silently get parsed as rich markup tags and
    eaten if we just ``print(f"... {message}")``. Render the message as
    plain text and use ``Console.print`` directly for the glyph so we
    can colour it.
    """
    # ``end=""`` joins the glyph and the message on one logical line.
    # ``markup=False`` on the message side keeps brackets in user-facing
    # strings (extras, JSON keys) verbatim. ``soft_wrap=True`` so long
    # single-line messages (URLs in hints, paths) don't get reflowed by
    # rich's terminal-width detection — the CI gotcha in #221.
    target.print(f"[{style}]{glyph}[/{style}]", end=" ", soft_wrap=True)
    target.print(message, markup=False, highlight=False, soft_wrap=True)


def success(message: str) -> None:
    """Print a green ✓ + the message to stdout."""
    _print_with_glyph(console, "✓", "green", message)


def error(message: str) -> None:
    """Print a red ✗ + the message to stderr.

    Does NOT exit — the caller decides whether to ``raise typer.Exit(1)``
    after surfacing the error (the same pattern the pre-rich code used
    with ``typer.echo(..., err=True)``).
    """
    _print_with_glyph(stderr_console, "✗", "red", message)


def warn(message: str) -> None:
    """Print a yellow ⚠ + the message to stderr."""
    _print_with_glyph(stderr_console, "⚠", "yellow", message)


def info(message: str) -> None:
    """Print an uncoloured info line to stdout.

    Use for plain status messages that don't carry a ✓/✗/⚠ semantic —
    "Pushing .env → fly secrets…" and friends. Kept as a helper so the
    CLI codepath has a single import surface even for the boring case.

    Renders with rich markup enabled — callers that need bracketed
    literal text in their message (rare; e.g. ``parbaked[mcp]``) should
    use ``console.print(..., markup=False)`` directly.
    """
    console.print(message)


def plain(message: str = "") -> None:
    """Print a literal line with rich's markup parsing disabled.

    Used for fixed-width banner/divider lines and for any user-supplied
    text that might contain rich markup tokens (``[foo]``) — we want
    them rendered verbatim, not interpreted.
    """
    console.print(message, markup=False, highlight=False)
