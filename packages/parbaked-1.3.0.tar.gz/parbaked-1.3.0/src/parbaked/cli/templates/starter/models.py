"""Your app's SQLModel tables go here. See AGENTS.md."""

# Example — uncomment and edit:
#
# from uuid import UUID
# from sqlmodel import Field, SQLModel
#
# class Note(SQLModel, table=True):
#     id: int | None = Field(default=None, primary_key=True)
#     user_id: UUID = Field(foreign_key="users.id")
#     body: str
