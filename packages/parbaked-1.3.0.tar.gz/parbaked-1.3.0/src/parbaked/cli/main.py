"""parbaked CLI.

Commands:

- ``parbaked new <name>`` — scaffold a kernel-runtime PoC (parbaked.toml +
  routes/ + models.py + vanilla-JS web/index.html, ready for ``parbaked dev``).
- ``parbaked dev`` / ``tunnel`` / ``deploy`` / ``logs`` /
  ``push-secrets`` — dev and deploy entry points.
- ``parbaked status`` — print a one-screen summary of the current project.
- ``parbaked version`` — print the installed version.
"""

from __future__ import annotations

import contextlib
import re
import shutil
import sys
from pathlib import Path

import typer

from parbaked import __version__
from parbaked.cli import ops
from parbaked.cli._console import console, error, info, success, warn
from parbaked.cli.admin import admin_app
from parbaked.cli.email import email_app
from parbaked.cli.users import users_app
from parbaked.operations.scaffold import (
    _starter_templates_dir,
    scaffold_project,
)


def _ensure_utf8_stdout() -> None:
    """Reconfigure stdout/stderr to UTF-8 on legacy Windows consoles.

    The parbaked CLI prints Unicode glyphs (``✓``, ``✗``, ``⚠``, ``→``)
    throughout its output. On Windows consoles that default to
    ``cp1252`` these characters cause ``UnicodeEncodeError`` at write
    time. Calling ``reconfigure(encoding="utf-8", errors="replace")``
    on Python 3.7+ flips the stream to UTF-8 in place, fixes the crash,
    and is a no-op on macOS/Linux where stdout is already UTF-8.

    Wrapped in a defensive try/except because ``reconfigure`` is only
    available on real ``TextIOWrapper`` streams — if stdout has been
    redirected to e.g. a ``StringIO`` (in tests) the attribute is
    missing, and we simply leave the stream as-is.

    See issue #192.
    """
    for stream in (sys.stdout, sys.stderr):
        encoding = (getattr(stream, "encoding", None) or "").lower()
        if encoding.replace("-", "") in {"utf8", ""}:
            continue
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is None:
            continue
        # If reconfigure raises (rare — e.g. a detached console), give up
        # silently rather than crash the CLI before it has even started.
        with contextlib.suppress(OSError, ValueError):
            reconfigure(encoding="utf-8", errors="replace")


_ensure_utf8_stdout()


app = typer.Typer(
    name="parbaked",
    help="Signup + admin approval + fly.io deploy for indie FastAPI PoCs. Agent-friendly.",
    add_completion=False,
    no_args_is_help=True,
)


def _version_callback(value: bool) -> None:
    """Print the parbaked version and exit when ``--version`` / ``-V`` is passed.

    Wired as an eager typer ``Option`` callback so it fires before any
    subcommand parsing — ``parbaked --version`` shouldn't require a
    project on disk, a DB, or any other context the subcommands assume.

    The existing ``parbaked version`` subcommand stays (it's free to grow
    extra context like python version / install path later); this flag
    just prints the bare version string for parity with ``git``,
    ``python``, ``uv``, ``ruff``, etc. (#317).
    """
    if value:
        typer.echo(f"parbaked {__version__}")
        raise typer.Exit()


@app.callback()
def _root_callback(
    version: bool = typer.Option(  # noqa: ARG001 — consumed by the callback
        None,
        "--version",
        "-V",
        callback=_version_callback,
        is_eager=True,
        help="Show the parbaked version and exit.",
    ),
) -> None:
    """Top-level options for ``parbaked``.

    Exists solely so typer registers ``--version`` / ``-V`` as a
    root-level flag (#317). Subcommands are dispatched as before.
    """


# --------------------------------------------------------------------- helpers
# (defined before commands so the decorated functions below can reference them
# without forward-declaration acrobatics)
#
# The template-walk lives in ``parbaked.operations.scaffold.scaffold_project``
# (#228) — shared between this command and the MCP ``tool_scaffold`` entry
# point. ``_starter_templates_dir`` is re-exported above for the precondition
# check in :func:`new`.


def _bootstrap_project_venv(target: Path) -> None:
    """Run ``uv sync`` in the freshly-scaffolded project so the first
    ``parbaked dev`` is instant and pins exactly the parbaked the CLI
    came from (via the ``parbaked=={{PARBAKED_VERSION}}`` line written
    into ``pyproject.toml``).

    Also runs ``uv lock`` to materialise ``uv.lock`` next to
    ``pyproject.toml``. The generated Dockerfile does
    ``uv sync --frozen`` against the lockfile, so projects need
    to *ship* with one — otherwise the first ``parbaked deploy`` would
    silently float versions and reintroduce the "deploy broke on a
    Tuesday because a transitive dep cut a release" footgun.

    Silent when ``uv`` isn't on PATH — the user clearly installed
    parbaked some other way; we surface a hint they can run later.
    """
    import subprocess as _sp

    if shutil.which("uv") is None:
        info(
            "ℹ uv not found on PATH — skipping ``uv sync``. "
            "Run ``uv sync`` (or ``pip install -e .``) "
            f"in {target} before ``parbaked dev``."
        )
        return
    info("Installing project dependencies (uv sync)…")
    rc = _sp.run(["uv", "sync"], cwd=target, check=False).returncode
    if rc != 0:
        # Non-fatal — the scaffold is still on disk, the user can rerun.
        warn(
            "uv sync failed. Scaffold is in place; "
            f"run ``uv sync`` manually in {target} before ``parbaked dev``."
        )
        return
    # Belt-and-braces: ``uv sync`` already writes uv.lock on a fresh
    # project, but explicit ``uv lock`` makes the contract obvious and
    # is a no-op when the lock is already in sync. Failure here is
    # non-fatal — the project still works, just without a pinned lock.
    if not (target / "uv.lock").exists():
        _sp.run(["uv", "lock"], cwd=target, check=False)
    success("dependencies installed")


# Conservative-safe-everywhere subset . Names must work as:
#  - a directory name on every supported FS
#  - a fly.io app name (lowercase, hyphen-separated, leading letter,
#    no trailing hyphen — fly's exact rules)
#  - a shell argument that is NEVER parseable as a flag (no leading "-")
#  - a Python model name fragment via MCP scaffolds (lowercase tokens)
#  - a Docker image tag fragment (no dots, no spaces, no uppercase)
_APP_NAME_RE = re.compile(r"[a-z][a-z0-9-]*[a-z0-9]")


def _validate_app_name(name: str) -> None:
    """Reject names that would break fly / Dockerfile / shell tooling .

    The pre-v1.3 check only blocked path traversal (``..``, ``/``, leading
    ``.``) which let through names like ``"with space"`` (breaks the
    Dockerfile + shell tooling) and ``"-leadinghyphen"`` (parsed as a
    flag by ``cd``, ``git``, ``fly``). We tighten to the
    conservative-safe-everywhere subset: lowercase, leading letter,
    letters/digits/hyphens only, no trailing hyphen. Length must be
    ≥ 2 (the regex requires both a leading letter AND a trailing
    letter/digit) so single-character names also get rejected — fly
    refuses them anyway.

    Also re-used by the MCP ``tool_scaffold`` path so the same rules
    apply whether a human or an agent runs the scaffold.
    """
    if not name:
        raise typer.BadParameter("Project name required")
    if not _APP_NAME_RE.fullmatch(name):
        raise typer.BadParameter(
            "Project name must be lowercase, start with a letter, "
            "use only letters/digits/hyphens, no trailing hyphen."
        )


# Top-level commands are registered in user-journey order :
# scaffold → run → onboard → ship → operate → wind down. Typer renders
# `--help` in definition order, so this order is what users see.


@app.command()
def new(
    name: str = typer.Argument(..., help="Project name (becomes the directory)"),
    parent: Path = typer.Option(
        Path("."), "--parent", "-p", help="Parent directory for the new project"
    ),
    force: bool = typer.Option(
        False, "--force", "-f", help="Overwrite an existing directory of the same name"
    ),
    deploy: bool = typer.Option(
        False,
        "--deploy",
        help=(
            "After scaffolding, walk through the first-run fly.io onboarding "
            "wizard: install flyctl, sign in, claim the app, push secrets, "
            "deploy. Use ``parbaked init`` from an existing project."
        ),
    ),
    skip_onboarding: bool = typer.Option(
        False,
        "--skip-onboarding",
        help=(
            "Requires ``--deploy``. Scaffolds the project but skips the "
            "deploy wizard. Passing this without ``--deploy`` is a usage "
            "error and exits non-zero."
        ),
    ),
    open_browser: bool = typer.Option(
        False,
        "--open",
        help="With ``--deploy``: open the live URL when deploy completes.",
    ),
    no_install: bool = typer.Option(
        False,
        "--no-install",
        help=(
            "Don't run ``uv sync`` after scaffolding. Useful for offline "
            "scaffolds or CI scenarios where you'll install separately."
        ),
    ),
) -> None:
    """Scaffold a complete runnable PoC under PARENT/NAME.

    Creates a kernel-runtime project with ``parbaked.toml``, ``routes/``,
    ``models.py``, a vanilla-JS ``web/index.html`` placeholder, and
    ``pyproject.toml``. After running:

        cd NAME && parbaked dev

    working signup + admin approval at http://localhost:8000.
    """
    _validate_app_name(name)
    # ``--skip-onboarding`` only makes sense in tandem with ``--deploy`` —
    # without the deploy wizard there's nothing to skip. Typer can't express
    # this conditional in its option declarations, so we validate at command
    # entry. Without this guard, ``parbaked new myapp --skip-onboarding``
    # silently behaved as if the flag weren't there (#178/3).
    if skip_onboarding and not deploy:
        raise typer.BadParameter(
            "--skip-onboarding requires --deploy (the flag suppresses the "
            "post-scaffold deploy wizard; without --deploy there's no wizard "
            "to skip)."
        )
    target = (parent / name).resolve()
    if target.exists() and not force:
        error(f"{target} already exists. Use --force to overwrite.")
        raise typer.Exit(1)

    src = _starter_templates_dir()
    if not src.exists():
        error(f"Starter templates not found at {src}. parbaked install is broken?")
        raise typer.Exit(1)

    if target.exists():
        shutil.rmtree(target)
    target.mkdir(parents=True)

    # Template walk (#188 item 3, #228) — shared with mcp.tool_scaffold via
    # ``parbaked.operations.scaffold.scaffold_project``.
    scaffold_project(target, name)

    success(f"created {target}")

    if not no_install:
        _bootstrap_project_venv(target)

    if deploy and not skip_onboarding:
        # Hand off to the onboarding wizard from inside the new project
        # dir so .parbaked/deploy.json + the generated build files land
        # next to parbaked.toml.
        import os as _os

        from parbaked.cli.deploy_wizard import pick_fly_app_name, run_wizard
        prev_cwd = Path.cwd()
        try:
            _os.chdir(target)
            run_wizard(pick_fly_app_name(name), open_browser=open_browser)
        finally:
            _os.chdir(prev_cwd)
        return

    info("")
    info("[bold]Next:[/bold]")
    info(f"  cd {name}")
    info("  parbaked dev")
    info("")
    info("Open [cyan]http://localhost:8000/auth/admin[/cyan] and sign in")
    info("with the password from the terminal banner.")
    info("")
    info("Add routes in routes/. Add SQLModel tables in models.py.")
    info("Replacing [cyan]web/[/cyan]? See AGENTS.md → \"Replacing the starter\" (#316).")
    info("Ship to fly.io when ready: `parbaked init` walks you through it.")


# `dev` runs the kernel runtime via uvicorn. Defined in ops.py so it can
# share helpers with the other ops commands.
app.command(name="dev", help="Run the app locally with uvicorn auto-reload.")(ops.dev)


@app.command()
def init(
    open_browser: bool = typer.Option(
        False,
        "--open",
        help="Open the live URL in the browser once the deploy completes.",
    ),
) -> None:
    """Walk through the first-run fly.io onboarding wizard.

    Run this from inside an existing parbaked project that wasn't
    scaffolded with ``parbaked new --deploy``. The wizard detects
    flyctl, drives ``fly auth`` / ``fly launch``, pushes secrets, and
    deploys. After the first successful run, ``parbaked deploy`` is the
    one-shot redeploy command — no prompts.
    """
    if not Path("parbaked.toml").exists():
        error("No parbaked.toml found. Run `parbaked init` at your project root.")
        raise typer.Exit(1)

    from parbaked.cli.deploy_wizard import pick_fly_app_name, run_wizard
    from parbaked.config import ParbakedConfig

    config = ParbakedConfig()
    # First init: build a globally-unique fly app name from app_name +
    # 5-char random suffix. Subsequent inits (state file present) re-use
    # the cached name so the redeploy targets the same app.
    candidate = pick_fly_app_name(config.app_name)
    run_wizard(candidate, open_browser=open_browser)


app.command(name="deploy")(ops.deploy)
app.command(name="logs", help="Tail `fly logs`.")(ops.logs)
app.command(
    name="push-secrets",
    help="Push .env entries to fly secrets (one-way local → fly).",
)(ops.secrets)


# Deprecation alias for the old `parbaked secrets` name . Kept
# hidden from --help so tutorials migrate, but still functional for one
# release so any existing scripts / docs that call ``parbaked secrets``
# keep working. Emits a deprecation notice on stderr so the user
# notices the rename.
@app.command(
    name="secrets",
    hidden=True,
    help="Deprecated alias for `parbaked push-secrets`.",
)
def secrets_alias(
    env_file: Path = typer.Option(
        Path(".env"), "--env-file", "-e", help="Path to env file (default ./.env)"
    ),
) -> None:
    """Forward to ``parbaked push-secrets`` after printing a deprecation
    notice on stderr.

    The rename is verb-first : ``push-secrets`` is honest about
    being one-way local → fly, ``secrets`` reads like a subcommand
    group (compare ``parbaked users``) that doesn't exist. Kept hidden
    so the rename actually lands in tab-completion + ``--help``.
    """
    warn("`parbaked secrets` is deprecated — use `parbaked push-secrets` instead.")
    ops.secrets(env_file=env_file)


app.command(name="tunnel", help="Expose localhost via a cloudflared quick tunnel.")(
    ops.tunnel
)
app.command(name="destroy", help="Permanently destroy this project's fly.io app.")(
    ops.destroy
)


@app.command(name="eject", help="Export parbaked data + deploy files (off-board).")
def eject_cmd(
    output: Path = typer.Option(
        Path("parbaked-export"),
        "--output", "-o",
        help=(
            "Directory to write the export into. Refuses to overwrite "
            "a non-empty directory unless it's a prior parbaked-export "
            "or --force is passed."
        ),
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help=(
            "Overwrite a non-empty output directory even when it isn't "
            "a prior parbaked-export. Files are still written by name "
            "(no rmtree)."
        ),
    ),
) -> None:
    """Produce a self-contained export the operator can take anywhere.

    Writes schema.sql + data/*.csv + Dockerfile + fly.toml + .env.example
    + MANIFEST.md. The MANIFEST points at the Data Format Guarantees
    doc — the contract every byte in the export is built against.

    Idempotent over a prior export — running ``parbaked eject`` again
    against the default ``parbaked-export/`` directory recognises the
    prior MANIFEST.md sentinel and overwrites in place. Pointing at a
    non-empty arbitrary directory is refused unless you pass
    ``--force`` (#290).
    """
    from parbaked.config import ParbakedConfig
    from parbaked.eject import eject as _eject
    from parbaked.exceptions import EjectError

    if not Path("parbaked.toml").exists():
        error("No parbaked.toml found. parbaked eject must run at the project root.")
        raise typer.Exit(1)

    config = ParbakedConfig()
    try:
        out = _eject(output, config=config, force=force)
    except EjectError as exc:
        error(str(exc))
        raise typer.Exit(1) from exc
    success(f"exported parbaked data to {out}")
    info("")
    info("Read MANIFEST.md inside for the file map + format details.")


@app.command()
def status() -> None:
    """Print a one-screen summary of the current parbaked project .

    Pulls config + deploy state + migration status + secrets presence into
    a single text screen so the operator can answer "is everything wired
    up?" without grepping three files. Reuses the same data sources the
    MCP server's ``email_setup_status`` / ``deploy_status`` tools return,
    so the human read-out matches what the agent sees.

    Names of secrets in ``.parbaked.json`` are listed, but values are
    never printed — even partial values give attackers a head start on
    brute-forcing the rest, and admin tooling that prints secrets is
    how secrets leak into shell history / screenshots / pair sessions.
    """
    import json as _json

    if not Path("parbaked.toml").exists():
        error("No parbaked.toml found. Run `parbaked status` at your project root.")
        raise typer.Exit(1)

    from parbaked.cli._db import load_config

    config = load_config()

    # ``markup=False`` because user-supplied values (database URLs with
    # square-bracketed IPv6 hosts, app names containing brackets, etc.)
    # must not be parsed as rich markup.
    def _row(label: str, value: str) -> None:
        console.print(f"{label:13s}{value}", markup=False, highlight=False)

    _row("parbaked", str(__version__))
    _row("app_name", config.app_name)
    _row("app_url", config.app_url)
    _row("env", config.env)
    _row("database", str(config.database_url))
    info("")

    # Email mode — mirrors mcp.tool_email_setup_status.
    if not config.email_enabled:
        _row("email", "disabled (dashboard-only)")
    elif config.resend_key:
        _row("email", "resend")
        _row("  from", str(config.effective_mail_from()))
        _row("  admin", str(config.admin_email))
    else:
        _row("email", "console (stdout)")
        _row("  admin", str(config.admin_email))
    info("")

    # Deploy state — mirrors mcp.tool_deploy_status.
    state_path = Path(".parbaked/deploy.json")
    if state_path.exists():
        try:
            state = _json.loads(state_path.read_text())
        except (OSError, _json.JSONDecodeError):
            state = {}
        fly_app_name = state.get("fly_app_name")
        if fly_app_name:
            _row("deploy", "onboarded")
            _row("  fly app", fly_app_name)
            _row("  url", f"https://{fly_app_name}.fly.dev")
            first = state.get("first_deploy_at")
            if first:
                _row("  first", first)
        else:
            _row("deploy", "not yet (no fly_app_name cached)")
    else:
        _row("deploy", "not yet (no .parbaked/deploy.json)")
    info("")

    # Migration status — read SchemaVersion if the DB exists. Best-effort:
    # a brand-new project that hasn't booted yet has no DB, and that's
    # fine — we just say "no DB yet" rather than crashing.
    try:
        from parbaked.migrations import LATEST_VERSION

        latest = LATEST_VERSION() if callable(LATEST_VERSION) else LATEST_VERSION
    except ImportError:
        latest = None
    try:
        from sqlalchemy import inspect as _sa_inspect
        from sqlmodel import select

        from parbaked.auth.models import SchemaVersion
        from parbaked.cli._db import open_engine

        engine = open_engine()
        inspector = _sa_inspect(engine)
        if inspector.has_table("_parbaked_schema_version"):
            from sqlmodel import Session

            with Session(engine) as session:
                row = session.exec(select(SchemaVersion)).first()
                current = row.version if row else 0
            if latest is None:
                _row("migrations", f"applied version {current}")
            else:
                _row(
                    "migrations",
                    f"applied {current} / latest {latest}"
                    + ("  (up to date)" if current == latest else "  (pending)"),
                )
        else:
            _row("migrations", "no DB yet (run `parbaked dev` once)")
    except Exception as exc:  # noqa: BLE001 — status must never crash
        _row("migrations", f"unknown ({exc.__class__.__name__})")
    info("")

    # Local secrets — names only, never values .
    secrets_path = Path(".parbaked.json")
    if secrets_path.exists():
        try:
            stored = _json.loads(secrets_path.read_text())
        except (OSError, _json.JSONDecodeError):
            stored = {}
        names = sorted(stored.keys())
        if names:
            _row("secrets", ".parbaked.json")
            for n in names:
                _row("", f"  - {n}")
        else:
            _row("secrets", ".parbaked.json (empty)")
    else:
        _row("secrets", "no .parbaked.json")


# Subcommand groups: scoped by domain, ordered after the top-level
# verbs so users see the journey commands first.
app.add_typer(users_app, name="users", help="Inspect and manage users.")
app.add_typer(
    admin_app,
    name="admin",
    help="Manage the admin password, invite admins, run pending DB migrations.",
)
app.add_typer(email_app, name="email", help="Set up real email delivery.")


@app.command()
def mcp() -> None:
    """Run the parbaked MCP server (AI tool surface).

    Speaks the Model Context Protocol over stdio so AI agents (Claude
    Desktop, Cursor, Codex, etc.) can scaffold, develop, and deploy a
    parbaked project as tool calls. Requires the ``mcp`` extra::

        pip install 'parbaked[mcp]'

    See AGENTS.md for the Claude Desktop config snippet.
    """
    try:
        from parbaked.mcp.server import run as _run
    except ImportError:
        error(
            "parbaked MCP server requires the optional 'mcp' extra.\n"
            "  Install with: uv add 'parbaked[mcp]'\n"
            "  Or, for a tool install: uv tool install 'parbaked[mcp]' --prerelease=allow"
        )
        raise typer.Exit(1) from None
    try:
        _run()
    except ImportError:
        # build_server() raises ImportError when ``mcp`` isn't installed
        # — same friendly hint as the top-level import failure.
        error(
            "parbaked MCP server requires the optional 'mcp' extra.\n"
            "  Install with: uv add 'parbaked[mcp]'\n"
            "  Or, for a tool install: uv tool install 'parbaked[mcp]' --prerelease=allow"
        )
        raise typer.Exit(1) from None


@app.command()
def version() -> None:
    """Print the installed parbaked version."""
    # ``markup=False`` so any future version string containing brackets
    # round-trips verbatim.
    console.print(__version__, markup=False, highlight=False)


if __name__ == "__main__":
    app()
