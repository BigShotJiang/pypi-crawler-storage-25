"""Lifecycle hooks.

Pass callbacks to :class:`Parbaked` to react to signup events (analytics,
Slack notifications, etc.). Callbacks are invoked synchronously after the
database has been updated; exceptions are logged and swallowed so user code
can't break the auth flow.

**Hooks run on the request path.** A 200ms network call inside ``on_signup``
adds 200ms to every signup response. Keep hooks fast (in-process state
updates, lightweight queue dispatches) or fire-and-forget. For genuine
fire-and-forget, prefer ``BackgroundTasks`` in a route over swallowing the
work in a hook. For genuinely async work — analytics, notifications — push
the event to a queue inside the hook and process it elsewhere, or wrap the
network call in ``threading.Thread(target=..., daemon=True).start()``.
"Exceptions are swallowed" means your hook can't crash the auth flow; it
does **not** mean your hook is decoupled from response latency.

Example::

    def notify_slack(user):
        # Fire-and-forget so signup doesn't wait on Slack.
        threading.Thread(
            target=lambda: requests.post(
                SLACK_URL, json={"text": f"{user.email} signed up"}
            ),
            daemon=True,
        ).start()

    parbaked = Parbaked(app, on_signup=notify_slack)
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from parbaked.auth.models import User

logger = logging.getLogger("parbaked.hooks")


UserCallback = Callable[[User], None]


@dataclass
class Hooks:
    """Bundle of optional lifecycle callbacks.

    All hooks receive the :class:`User` after the relevant DB mutation has been
    committed, so any state you read off ``user`` reflects the new reality.
    """

    on_signup: UserCallback | None = None
    """Fires when a new signup is created (status=pending, unverified)."""

    on_verify: UserCallback | None = None
    """Fires when a user clicks their verify link (email_verified_at set)."""

    on_approve: UserCallback | None = None
    """Fires when admin approves (status=active). Triggered by both the magic
    link AND the admin-dashboard button."""

    on_reject: UserCallback | None = None
    """Fires when admin rejects (status=rejected). Same triggers as on_approve."""

    on_delete: UserCallback | None = None
    """Fires after a user self-deletes via DELETE /auth/me (#275, GDPR Article 17).

    The passed-in :class:`User` is the **scrubbed** row: ``email`` is the
    ``deleted-{uuid}@parbaked.invalid`` sentinel, ``name`` is empty,
    ``password_hash`` is poisoned, ``status`` is ``rejected``, and
    ``revoked_at`` is set. The UUID stays stable so consumer code can
    cascade-delete (or anonymize) its own rows keyed on ``users.id``.
    parbaked never touches consumer tables — wiring the cascade is your
    responsibility (see AGENTS.md "GDPR account self-service")."""

    def fire(self, event: str, user: User) -> None:
        """Invoke the named hook if present. Swallows + logs exceptions.

        ``event`` is one of "signup", "verify", "approve", "reject", "delete".
        """
        hook = getattr(self, f"on_{event}", None)
        if hook is None:
            return
        try:
            hook(user)
        except Exception:  # noqa: BLE001 — user code must not break the auth flow
            logger.exception(
                "Lifecycle hook on_%s raised; swallowed so parbaked can continue.",
                event,
            )


def load_consumer_hooks(project_root: Path | None = None) -> Hooks:
    """Build a :class:`Hooks` instance pre-wired with the consumer's
    ``hooks.py`` callables (#332, #356).

    ``runtime.create_app`` does this on the HTTP path; surfaces that run
    in a separate process (the CLI ``parbaked users approve|reject``
    commands, the MCP ``tool_users_approve`` / ``tool_users_reject``
    tools) would otherwise instantiate an empty :class:`Hooks` and
    silently drop the consumer's ``on_approve`` / ``on_reject``.

    Lazy import: :mod:`parbaked.runtime` drags in FastAPI/uvicorn, so we
    defer it to the command that actually mutates user state rather than
    paying the cost on every ``parbaked --help`` invocation or every
    ``parbaked mcp`` boot when no project is loaded.

    Shared by :mod:`parbaked.cli.users` and :mod:`parbaked.mcp.server`
    so the CLI and MCP surfaces fire hooks identically — fixing one
    surface without the other (the #356 regression after #332) can't
    happen by construction now that there's one helper.
    """
    from parbaked.runtime import _autoload_consumer_hooks

    root = project_root if project_root is not None else Path.cwd()
    return Hooks(**_autoload_consumer_hooks(root))
