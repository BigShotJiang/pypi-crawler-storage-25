import os
import sys
import types
import unittest
from unittest.mock import patch

sys.path.insert(0, os.path.abspath("src"))

if "ultralytics" not in sys.modules:
    ultralytics = types.ModuleType("ultralytics")

    class _DummyYOLO:
        def __init__(self, *args, **kwargs):
            pass

    ultralytics.YOLO = _DummyYOLO
    sys.modules["ultralytics"] = ultralytics

if "cv2" not in sys.modules:
    cv2 = types.ModuleType("cv2")
    cv2.imwrite = lambda *args, **kwargs: True
    sys.modules["cv2"] = cv2

from netkiller.yoloutils.yoloutils import YoloUtils


class YoloUtilsLabelHelpTest(unittest.TestCase):
    def test_label_without_options_prints_help(self):
        runner = YoloUtils()

        with patch.object(sys, "argv", ["yoloutils.py", "label"]), patch.object(
            runner.label, "print_help"
        ) as print_help, patch(
            "netkiller.yoloutils.yoloutils.YoloLabel.main"
        ) as label_main:
            with self.assertRaises(SystemExit):
                runner.main()

        print_help.assert_called_once()
        label_main.assert_not_called()

    def test_label_without_action_prints_help(self):
        runner = YoloUtils()

        with patch.object(
            sys, "argv", ["yoloutils.py", "label", "--source", "/tmp/images"]
        ), patch.object(runner.label, "print_help") as print_help, patch(
            "netkiller.yoloutils.yoloutils.YoloLabel.main"
        ) as label_main:
            with self.assertRaises(SystemExit):
                runner.main()

        print_help.assert_called_once()
        label_main.assert_not_called()

    def test_label_with_source_and_action_runs_label_handler(self):
        runner = YoloUtils()

        with patch.object(
            sys, "argv", ["yoloutils.py", "label", "--source", "/tmp/images", "--total"]
        ), patch.object(runner.label, "print_help") as print_help, patch(
            "netkiller.yoloutils.yoloutils.YoloLabel.main"
        ) as label_main:
            with self.assertRaises(SystemExit):
                runner.main()

        print_help.assert_not_called()
        label_main.assert_called_once()


if __name__ == "__main__":
    unittest.main()
