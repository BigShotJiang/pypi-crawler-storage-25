import argparse
import os
import shutil
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

sys.path.insert(0, os.path.abspath("src"))

if "ultralytics" not in sys.modules:
    ultralytics = types.ModuleType("ultralytics")

    class _DummyYOLO:
        def __init__(self, *args, **kwargs):
            pass

    ultralytics.YOLO = _DummyYOLO
    sys.modules["ultralytics"] = ultralytics

if "cv2" not in sys.modules:
    cv2 = types.ModuleType("cv2")
    cv2.imwrite = lambda *args, **kwargs: True
    sys.modules["cv2"] = cv2

from netkiller.yoloutils.labelimg import YoloLabelimg


class YoloLabelimgCleanConfirmTest(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="yoloutils-labelimg-")
        self.source = os.path.join(self.tmpdir, "source")
        self.target = os.path.join(self.tmpdir, "target")
        os.makedirs(self.source, exist_ok=True)
        os.makedirs(self.target, exist_ok=True)

        with open(os.path.join(self.source, "classes.txt"), "w", encoding="utf-8") as file:
            file.write("cat\n")
        with open(os.path.join(self.source, "sample.txt"), "w", encoding="utf-8") as file:
            file.write("0 0.5 0.5 0.2 0.2\n")
        with open(os.path.join(self.source, "sample.jpg"), "wb") as file:
            file.write(b"\x00")

        self.old_file = os.path.join(self.target, "old.txt")
        with open(self.old_file, "w", encoding="utf-8") as file:
            file.write("old")

        parser = argparse.ArgumentParser(add_help=False)
        args = argparse.Namespace(
            source=self.source,
            target=self.target,
            clean=True,
            classes=None,
            val=10,
            uuid=False,
            check=False,
        )
        self.runner = YoloLabelimg(parser, args)

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_clean_confirm_yes_cleans_target_and_creates_structure(self):
        with patch("builtins.input", return_value="y"):
            self.runner.input()

        self.assertFalse(os.path.exists(self.old_file))
        self.assertTrue(os.path.isdir(os.path.join(self.target, "train/images")))
        self.assertEqual(len(self.runner.files), 1)

    def test_clean_confirm_no_exits_and_keeps_target(self):
        with patch("builtins.input", return_value="n"):
            with self.assertRaises(SystemExit):
                self.runner.input()

        self.assertTrue(os.path.exists(self.old_file))
        self.assertFalse(os.path.exists(os.path.join(self.target, "train/images")))


if __name__ == "__main__":
    unittest.main()
