import argparse
import ntpath
import os
import sys
import types
import unittest
from unittest.mock import patch

sys.path.insert(0, os.path.abspath("src"))

if "ultralytics" not in sys.modules:
    ultralytics = types.ModuleType("ultralytics")

    class _DummyYOLO:
        def __init__(self, *args, **kwargs):
            pass

    ultralytics.YOLO = _DummyYOLO
    sys.modules["ultralytics"] = ultralytics

from netkiller.yoloutils.test import YoloTestDiff


class _DummyTqdm:
    def __init__(self, *args, **kwargs):
        pass

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def set_postfix_str(self, value):
        return None

    def update(self, value):
        return None


class _Box:
    cls = 0
    conf = 0.93


class _Result:
    def __init__(self, saved_paths):
        self.names = {0: "cat"}
        self.boxes = [_Box()]
        self._saved_paths = saved_paths

    def save(self, path):
        self._saved_paths.append(path)


class _Model:
    def __init__(self, saved_paths):
        self._saved_paths = saved_paths

    def predict(self, _file, verbose=False):
        return [_Result(self._saved_paths)]


class YoloTestDiffWindowsOutputTest(unittest.TestCase):
    def _build_runner(self):
        parser = argparse.ArgumentParser(add_help=False)
        args = argparse.Namespace(
            source=r"C:\dataset",
            clean=False,
            model=["best.pt"],
            label=None,
            output=r"D:\out",
            csv=None,
        )
        runner = YoloTestDiff(parser, args)
        runner.source_root = ntpath.normpath(args.source)
        return runner

    def test_process_model_writes_under_output_dir_on_windows_paths(self):
        runner = self._build_runner()
        saved_paths = []
        target_file = r"C:\dataset\sub\img.jpg"
        expected = r"D:\out\best.pt\sub\img.jpg"

        with patch("netkiller.yoloutils.test.tqdm", _DummyTqdm), patch(
            "netkiller.yoloutils.test.os.path.join", new=ntpath.join
        ), patch("netkiller.yoloutils.test.os.path.dirname", new=ntpath.dirname), patch(
            "netkiller.yoloutils.test.os.path.basename", new=ntpath.basename
        ), patch("netkiller.yoloutils.test.os.path.relpath", new=ntpath.relpath), patch(
            "netkiller.yoloutils.test.os.path.normpath", new=ntpath.normpath
        ), patch(
            "netkiller.yoloutils.test.os.path.abspath", side_effect=lambda path: path
        ), patch(
            "netkiller.yoloutils.test.os.makedirs"
        ) as makedirs:
            _, scores, labels = runner._process_model(
                "best.pt", _Model(saved_paths), [target_file], position=0
            )

        self.assertEqual(saved_paths, [expected])
        makedirs.assert_called_once_with(ntpath.dirname(expected), exist_ok=True)
        self.assertEqual(scores[target_file], "0.93")
        self.assertEqual(labels[target_file], {"cat"})

    def test_relative_file_falls_back_to_basename_on_relpath_error(self):
        runner = self._build_runner()
        target_file = r"E:\other\img.jpg"

        with patch("netkiller.yoloutils.test.os.path.relpath", side_effect=ValueError), patch(
            "netkiller.yoloutils.test.os.path.basename", new=ntpath.basename
        ):
            rel = runner._relative_file(target_file)

        self.assertEqual(rel, "img.jpg")


if __name__ == "__main__":
    unittest.main()
