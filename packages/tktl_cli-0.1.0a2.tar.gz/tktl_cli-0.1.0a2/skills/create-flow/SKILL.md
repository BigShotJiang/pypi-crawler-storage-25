---
name: create-flow
description: >
  Build a Taktile decision flow from scratch using the tktl CLI.
  Use when creating a new flow from a natural-language domain description.
  Handles design, bootstrap, node building, testing, and reporting.
compatibility: Requires Python 3.11+ and the tktl-cli package (pip install tktl-cli)
metadata:
  author: taktile-org
  version: "1.0"
---

# create-flow — Build a Taktile Decision Flow from Scratch

Creates a new decision flow inside a new dedicated folder. Uses parallel
subagents at every split branch and during smoke-testing to minimise wall-clock
build time.

**Arguments:** `$ARGUMENTS` is a natural-language description of the decision
domain — what the flow should decide, for whom, and roughly what the output
should look like.

Examples:
- `"credit underwriting for SMEs — approve/decline + approved limit"`
- `"fraud detection for online card payments — risk score + block/allow"`
- `"insurance quote pricing for small businesses — premium tier + monthly rate"`
- `"lead scoring for SaaS sales — hot/warm/cold + recommended action"`

---

## Phase 1 — Design (you, sequential)

### 1.1 Parse the domain description

Extract from `$ARGUMENTS`:
- **Entity** — what object is being evaluated (applicant, merchant, claim, lead…)
- **Decision** — what the flow outputs (approve/decline, score, tier, price…)
- **Key signals** — the inputs that drive the decision
- **Hard stops** — any absolute KO criteria that bypass scoring entirely

### 1.2 Ask clarifying questions (all at once, never in rounds)

If any of the following are ambiguous, list all questions in a single message
and wait for one reply before continuing:

- What are the hard-stop disqualifiers (e.g. minimum tenure, blacklist, etc.)?
- What are the 3–6 risk/quality scoring factors and their relative importance?
- What tiers or outcome buckets should exist (e.g. prime/standard/near-prime)?
- What are the offer/output parameters? (amount, rate, term, limit, premium…)
- Are there any thresholds or ranges already decided?

If the description is rich enough to answer all of these, skip ahead.

### 1.3 Choose a flow pattern

Consult `skills/flow-builder/references/flow-patterns.md`. Common mappings:

| Domain type | Pattern |
|---|---|
| Hard stops + approve/decline | Pattern 2: Gated pipeline |
| Score → tiered offer | Pattern 3: Scored pipeline |
| Discrete lookup grid | Pattern 4/5: Decision or matrix table |
| Multiple sequential stages | Pattern 6: Multi-stage pipeline |

### 1.4 Design input and output schemas

List every field with its type and whether it is required.

**Type constraints for the Taktile execution engine:**
- Use `"type": "number"` for boolean flags — the engine rejects `"type": "boolean"`. Callers pass `0` or `1`.
- Wrap any output field that can be `null` on some paths with `anyOf`:
  ```json
  {"anyOf": [{"type": "number"}, {"type": "null"}]}
  ```
- Use `anyOf` even for string outputs that are null on declined paths.

### 1.5 Plan the full node sequence

Write out every node: name, type, purpose, key config values. Resolve all
thresholds and field names now — subagents will need fully-specified configs
and cannot fill in unknowns.

Use `skills/flow-builder/references/node-configs.md` for exact config shapes and gotchas per node type.

**Rule-node invariant:** every field listed in `default_effects` must also
appear in every `branch.effects`. The API enforces this; mismatches return 409.

### 1.6 Render the Mermaid diagram and wait for approval

Follow the visual conventions in `skills/flow-builder/SKILL.md` (classDefs, `<br/>` not `\n`, Legend
subgraph). Use `:::open` nodes for any part of the design still undecided.

```bash
tktl render --text "flowchart TD ..."
open <path>        # opens in macOS Preview
```

**Do not call `tktl nodes add` or `tktl versions duplicate` until the user has
approved the diagram.**

---

## Phase 2 — Bootstrap (you, strictly sequential)

Each step depends on the previous. Run them one at a time.

### 2.1 Create the folder

```bash
tktl folders list                          # check for duplicates first
tktl folders create "<Domain> Decisions"   # note the returned id
```

If the folder already exists, reuse its id and skip creation.

### 2.2 Create the flow

Derive a URL-safe slug from the domain name (lowercase, hyphens, no specials):
`"SME Credit Underwriting"` → `sme-credit-underwriting`

```bash
tktl flows create <slug> "<Display Name>" \
  --folder <folder-id> \
  --version-name v1
```

The response includes `default_sandbox_version` — this is the version UUID.
Keep it; you will need it if you ever have to reference the version by ID.

### 2.3 Apply input and output schemas

```bash
tktl update apply <slug> v1 \
  --schema-in  '<json>' \
  --schema-out '<json>'
```

The response contains the full graph. Extract the **input node ID** from
`response.graph.nodes` where `"type": "input"`. This is the `--after` anchor
for all subsequent node additions.

---

## Phase 3 — Build the full sequential backbone (you, sequential)

Walk the entire trunk of the flow — every node that must be added in series —
before dispatching any subagents. This includes nodes on intermediate branches
that lead to further splits. The goal is to reach all leaf branches from the
main agent so that Phase 4 can fire a single, flat parallel wave with no
nesting.

For each node:
```bash
# Add the node
tktl nodes add <slug> v1 --type <type> --name "<Name>" --after <prev_id>
# → note the returned id

# Configure it immediately
tktl update apply <slug> v1 --node <node_id> --node-config '<json>'
```

For complex configs (scorecards, matrix tables), write JSON to a temp file and
use `--config @file.json` instead of inline to avoid shell-quoting issues.

After adding **each split** node, run:
```bash
tktl nodes list <slug> v1
```

Record all three auto-created IDs:
- `Branch 1` — fires when the split clause is true
- `Default Branch` — fires when no clause matches (the "else" path)
- `Merge Node` — where both paths reconnect

Then immediately continue building down whichever branch leads to the next
split (the "trunk branch"). Repeat until every split has been added and every
leaf branch node ID has been captured.

**Example for a two-level flow** (eligibility gate → scoring → refer gate):
1. Add Eligibility Check, add Eligibility Gate split, list → record Branch 1
   (decline leaf), Default Branch (trunk), outer Merge
2. Continue from Default Branch: add Risk Scorecard, Risk Tier, Refer Gate
   split, list → record Branch 1 (refer leaf), Default Branch (approve leaf),
   inner Merge
3. All leaf branch node IDs are now known — proceed to Phase 4

---

## Phase 4 — Build leaf branches (one flat parallel wave)

Fire **one subagent per leaf branch** in a single parallel message. Never nest
subagents. Because the full backbone was walked in Phase 3, every branch node
ID is already known and no subagent needs to add sequential trunk nodes or
dispatch further agents.

**Trivial-branch rule:** if a leaf branch contains only a single assignment
node (≤ 3 CLI calls total), build it inline in the main agent rather than
paying subagent startup overhead. Launch it as `run_in_background: true` so it
doesn't block the others.

### 4.1 Subagent brief template

Compose a full, self-contained brief for each subagent. Include everything it
needs — do not leave anything open-ended:

> **Context:** You are building part of a Taktile decision flow. Flow slug:
> `<slug>`, version: `v1`.
>
> **Your branch:** `<branch name>` of the `<split name>` split.
> Start after node ID `<branch_node_id>`.
>
> **Nodes to add, in order:**
>
> 1. Name: `<name>`, type: `<type>`, after: `<branch_node_id>`
>    Config:
>    ```json
>    <full node-config JSON>
>    ```
> 2. Name: `<name>`, type: `<type>`, after: *(ID returned in step 1)*
>    Config:
>    ```json
>    <full node-config JSON>
>    ```
> *(repeat for each node in the branch)*
>
> **For each node:** run `tktl nodes add ...` then immediately
> `tktl update apply ... --node <id> --node-config '<json>'`.
>
> **When done:** run `tktl nodes list <slug> v1`, confirm all your nodes are
> present, and return the ID of the last node you added.

### 4.2 Collect results

After all subagents return, run `tktl nodes list <slug> v1` to confirm the
full node list. Merge Node IDs were recorded in Phase 3 — use them as
`--after` anchors for any post-merge nodes in the main flow.

### 4.3 Group related nodes

After all nodes are placed, organize the canvas with node groups. Groups are
visual containers — they don't affect execution but make large flows navigable.

**When to group (all conditions must be met):**
- Flow has **6+ logic nodes** (exclude input, output, merge, and branch nodes)
- At least one proposed group would contain **2+ nodes**

**Grouping heuristics — apply in order of priority:**

| Priority | Heuristic | Group name | What goes in |
|---|---|---|---|
| 1 | **Gate / Knockout cluster** | "Eligibility Checks" | All rule nodes + assignment nodes that set rejection reasons, up to (but not including) the first split |
| 2 | **Scoring cluster** | "Scoring" | Scorecard nodes, score-transform nodes, and the rule/DT that maps score → tier |
| 3 | **Data enrichment cluster** | "Data Enrichment" | Connection nodes (custom_connection, webhook, data_integration) and any transform that normalizes their responses |
| 4 | **Decision / Output mapping** | "Decision" | The final assignment(s) that map tier → output fields (approved_amount, rate, etc.) |
| 5 | **Stacked same-type nodes** | Use a descriptive name | 3+ consecutive nodes of the same type (e.g., 3 rule nodes → "Validation Rules") |
| 6 | **Semantic similarity** | Use a descriptive name | Nodes that read/write the same field cluster (e.g., all nodes touching `credit_score`) |

**Rules:**
- A node can only belong to one group
- Don't group input/output nodes — they anchor the flow edges
- Don't group split or merge nodes — they define flow structure
- Prefer fewer, larger groups over many small ones
- Name groups after their *purpose*, not their node types

**Execution:**
```bash
# List nodes to get IDs
tktl nodes list <slug> v1

# Create each group
tktl groups create <slug> v1 --name "Eligibility Checks" --node-ids <id1>,<id2>,<id3>
tktl groups create <slug> v1 --name "Scoring" --node-ids <id4>,<id5>
```

Alternatively, use `--group <group_id>` when adding nodes in Phase 4.1 to assign
them to groups as they're created:
```bash
# Create the group first (empty or with initial nodes)
tktl groups create <slug> v1 --name "Scoring" --node-ids <first_node_id>
# Add subsequent nodes directly into the group
tktl nodes add <slug> v1 --type scorecard --name "Risk Score" --after <id> --group <group_id> --config @/tmp/config.json
```

---

## Phase 5 — Smoke tests (parallel subagents)

### 5.1 Design test cases

Cover every decision path. For a gated + scored pipeline, the minimum set is:

| # | Scenario | What it exercises |
|---|---|---|
| T1 | Fails a hard-stop criterion | Branch 1 of the eligibility split |
| T2 | Passes hard stops, fails risk gate | Branch 1 of the risk split |
| T3 | Lowest approved tier | Default branch → weakest offer terms |
| T4 | Highest approved tier | Default branch → best offer terms |

Add more scenarios for additional splits or intermediate tiers. Include one test
per tier so pricing/rate logic is verified for every matrix cell used.

For each scenario, compute the **expected outputs by hand** before running —
this lets you catch logic errors, not just crashes.

### 5.2 Write payload files

```bash
cat > /tmp/<slug>-t1.json << 'EOF'
{ ... }
EOF
```

### 5.3 Launch test subagents concurrently

Dispatch all test subagents in a single message. Each runs one decision and
returns the full JSON response:

> **Task:** Run one flow decision and return the complete JSON response.
> ```bash
> tktl flows run <slug> --version v1 --file /tmp/<slug>-tN.json
> ```

### 5.4 Verify results

For each test:
- Check `"status": "success"` — if any returns `"error"`, debug using
  `skills/flow-builder/references/debugging.md` before reporting.
- Check `decision` matches the expected value.
- Check `decline_reason` on rejected paths.
- Verify numeric outputs (amounts, rates, totals) match your hand-calculations.

Fix any failures before proceeding to the report.

---

## Phase 6 — Report

### 6.0 Render the final flow preview

```bash
tktl versions describe <slug> v1 --preview
open <png-path>             # opens in macOS Preview
```

Always render the built flow and open the PNG before presenting the text summary.

### 6.1 Present a concise summary with four sections:

**1. Flow coordinates**
- Slug, version name, folder name
- Taktile URL: `https://app.stg.taktile.com/decide/org/<org_id>/ws/<ws_id>/flow/<flow_id>/version/<version_id>`

**2. Architecture table**

| # | Node | Type | Purpose |
|---|---|---|---|
| 1 | … | rule | … |

**3. Pricing / tier table** (if the flow uses a matrix or tier-based rates)

| Tier | Term A | Term B | … |
|---|---|---|---|

**4. Test results table**

| Test | Scenario | Decision | Key output | Status |
|---|---|---|---|---|
| T1 | … | DECLINED | reason = … | ✓ |
| T3 | … | APPROVED | amount = …, rate = … | ✓ |

---

## Concurrency map

```
Phase 1  Design + approval                          [you, sequential]
Phase 2  Folder → Flow → Schemas                    [you, sequential]
Phase 3  Full backbone: walk every trunk node and   [you, sequential]
         every split until all leaf branch IDs
         are known (no subagents yet)

Phase 4  One flat parallel wave — all leaf branches:
         ├── Leaf A subagent ──────────────────────[parallel] ──┐
         ├── Leaf B subagent ──────────────────────[parallel] ──┤
         └── Leaf C subagent ──────────────────────[parallel] ──┘
         (trivial single-assignment leaf: inline,
          run_in_background, skip subagent overhead)
         After all done ────────────────────────────────────────┘
         Post-merge nodes                            [you, sequential]

Phase 5  T1 subagent ────────────────────────────────[parallel] ──┐
         T2 subagent ────────────────────────────────[parallel] ──┤
         T3 subagent ────────────────────────────────[parallel] ──┤
         T4 subagent ────────────────────────────────[parallel] ──┘
         Verify all results                          [you, sequential]

Phase 6  Report                                      [you, sequential]
```

Key principle: **never nest subagents**. Every layer of nesting adds a full
agent-startup + sequential-CLI round trip before the inner work can begin.
Walk the trunk in the main agent; delegate only pure leaf branches.

---

## Quick-reference: known gotchas

| Symptom | Fix |
|---|---|
| `"type": "boolean"` schema validation error | Change to `"type": "number"`; callers pass `0`/`1` |
| `data: {}` in every response | Set `--schema-out` on the version |
| 409 `rule effects mismatch` | Every field in `default_effects` must appear in every `branch.effects` |
| Compile error `value is not a valid uuid` | Pass `""` for every `id`/`id_left`/`id_right` field — never short strings |
| Split routes everything the same way | Check type of the comparison: `False` (Python bool) ≠ `"False"` (string) |
| `ConflictError: [validation]` | Read the message — it names the failing field. Fix config, no retry needed |
| `folders create` 409 | Folder exists; use `tktl folders list` and reuse the id |
| `flows create --folder` returns `folder_id: null` | Normal — the Taktile API response omits it; the assignment succeeded |

For full debugging procedures, see `skills/flow-builder/references/debugging.md`.
