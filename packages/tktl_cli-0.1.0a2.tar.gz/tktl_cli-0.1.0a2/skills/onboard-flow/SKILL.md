---
name: onboard-flow
description: >
  Generate an onboarding document for a Taktile flow.
  Use when documenting an existing flow for FDE and CS teams.
  Produces a markdown summary of inputs, outputs, nodes, and example inputs per path.
compatibility: Requires Python 3.11+ and the tktl-cli package (pip install tktl-cli)
metadata:
  author: taktile-org
  version: "1.0"
---

Generate an onboarding document for a Taktile flow. The document helps FDE and CS people quickly understand what the flow does, what data it accepts/returns, and what each node is for.

Arguments: `$ARGUMENTS` should be `<flow-slug> [version-name]`.

## Step 1: Parse arguments

Extract the flow slug and optional version name from `$ARGUMENTS`. If only a slug is provided, you will resolve the version in the next step.

## Step 2: Resolve the version

If a version name was provided, use it directly.

If not, run:
```bash
tktl versions list <slug> --output json
```
Pick the first version with `"status": "PUBLISHED"`. If none is published, use the first version in the list.

## Step 3: Fetch flow and version metadata (including full graph)

Run both:
```bash
tktl flows describe <slug> --output json
tktl versions describe <slug> <version> --full --output json
```

From the flow: extract `name`, `slug`.
From the version: extract `name`, `status`, `input_schema`, `output_schema`, and the full `graph` (nodes with complete meta, edges).

Use the edges to determine execution order via topological sort (start from the `input` node, follow edges). Skip nodes with type `input` or `output`, and skip transform nodes where `meta.is_split_branch_node` or `meta.is_split_merge_node` is true (auto-generated scaffolding).

**List nodes in the document in execution order.**

For nodes that sit inside a split branch, use the edges to determine which branch they belong to. Use indented bullet lists to nest branch nodes under their split. Each split node gets a `###` heading, then its branches are indented bullet lists below it:

```markdown
### Early Rejection (`split_2`)
Description of the split...

- **Branch: decision == "Reject"**
  - **Assign outcomes** (`assignment_node`) -- Sets credit_limit = 0, interest_rate = 0, risk_rating = "N/A".

- **Branch: default (passes)**
  - **Replace KYC Flow Call** (`transform`) -- Stub replacing KYC. Hardcodes kyc_decision = "Accept".
  - **Pass KYC?** (`split_2`) -- Routes based on KYC results.
    - **Branch: kyc_decision == "Reject"**
      - **Assign outcomes** (`assignment_node`) -- Sets rejection defaults.
    - **Branch: default (passes KYC)**
      - **Replace TU Call** (`transform`) -- Stub. Sets bureau_score = 600.
      - **Get Case Details** (`manifest_connection_node`) -- Calls TransUnion TruValidate.
      - **New customer?** (`split_2`) -- Splits on new_customer flag.
        - **Branch: existing customer** (new_customer == false)
          - **Replace Sagemaker Call** (`transform`) -- Stub. Returns pd_score = 0.4.
          - **Weight Bureau and Internal Scores** (`scorecard`) -- 33% bureau, 67% ML.
        - **Branch: new customer** (default)
          - **Mock ML** (`transform`) -- Sets pd_score = 0.99.
          - **Weight Bureau and Internal Scores** (`scorecard`) -- 80% bureau, 20% ML.
```

This indentation makes branch ownership visually obvious. Nested splits just add another indent level. After branches merge, return to `###` headings for nodes on the main path. Do this consistently for every split in the flow.

## Step 4: Generate the onboarding document

Using the data collected, generate a markdown document following this template:

```markdown
# {flow_name}

**Version:** {version_name} ({status})

## Input / Output

**Accepts:**
- `field_name` (type) — required/optional

**Returns:**
- `field_name` (type)

## Nodes

### {Node Name} (`{type}`)

{Plain-language description of what this node does and why it exists in this flow}

**Key configuration:**
- {relevant config details}
```

### How to interpret each node type

Use the node's `meta` field to generate meaningful descriptions. Here is what to look for per type:

**`decision_table`** — Expresses complex conditions in tabular format. Rows are cases evaluated top-to-bottom (first match wins). White columns are conditions, green columns are results.
- `meta.predicate_fields[].value` — the condition columns (e.g. `data.age`, `data.country`)
- `meta.effect_fields[].value` — the outcome columns (e.g. `data.decision`)
- `meta.cases[]` — each case is a rule. Look at `.name` for the rule label, `.predicates` for conditions (each has `.value` and `.operator`), `.effects` for outcomes
- `meta.fallback` — the default outcome when no case matches
- Operators: `lt`, `le`, `eq`, `ne`, `ge`, `gt`, `is_in`, `is_not_in`, `is_none`, `is_not_none`, `is_any`, `contains`, `does_not_contain`, `matches_regex`
- Describe the business rules: what conditions lead to what decisions, how many rules, what the fallback is

**`matrix_table`** — 2D matrix that maps two input conditions to a single result in a compact grid. Simpler than a decision table but limited to two conditions and one result.
- `meta.condition_a` — row condition field
- `meta.condition_b` — column condition field
- `meta.result_field` — output field
- `meta.rows` / `meta.columns` — the condition values
- `meta.cells` — the result for each combination
- Describe what two dimensions are being crossed and what the output represents

**`scorecard`** — Computes a weighted score from multiple factors. Each factor maps an input field into score buckets, then factors are combined using weights that sum to 100%.
- `meta.assign_field.value` — the output field for the total score (e.g. `weighted_score`)
- `meta.factors[]` — list of scoring factors. Each has:
  - `input_field.value` — what data field is scored
  - `weight.value` — percentage weight (0-100)
  - `fallback.value` — default score if input is missing
  - `cases[]` — score buckets with `predicate` (threshold + operator) and `effect` (score value)
- `meta.extract_scores` — whether individual factor sub-scores are also output
- Describe the scoring model: what factors, their weights, the score ranges, and what the combined score represents

**`rule_2`** — Conditional IF/ELSE IF/ELSE logic that assigns values to output fields based on conditions. Evaluated top-to-bottom, first match wins.
- `meta.default_effects[]` — the ELSE (default) assignments: `target` and `value`
- `meta.branches[]` — each branch has:
  - `clauses[]` — conditions with `left` (field), `operator`, `right` (value)
  - `junction` — how clauses combine: `and` or `or`
  - `effects[]` — assignments when this branch matches: `target` and `value`
- Describe what conditions are checked, what fields are set, and what the default is

**`assignment_node`** — Adds new fields or modifies existing fields on the data object. No conditions — always applies all assignments.
- `meta.default_effects[]` — list of assignments, each with `target` (field name) and `value` (expression)
- Values can be strings, numbers, lists, dicts, None, or Python expressions
- Describe what fields are being set and to what values

**`split_2`** — Routes the request to one of multiple branches based on conditions. Only controls flow direction — does not modify data. Last branch is the default (else).
- `meta.branches[]` — each branch has:
  - `clauses[]` — conditions with `left`, `operator`, `right`
  - `junction` — `and` or `or`
  - `edge_id` — which path to follow
- `meta.default_edge_id` — the default (else) branch
- Describe what condition determines the routing and what each branch represents

**`transform`** (Code Node) — Executes arbitrary Python code. Most flexible node type. Has access to `data`, `params`, `meta` objects and selected packages (boto3, numpy, pandas, requests, etc.).
- `meta.src` — the Python source code
- `meta.is_split_branch_node` — if true, this is auto-generated scaffolding for a split (skip it)
- `meta.is_split_merge_node` — if true, this is auto-generated merge scaffolding (skip it)
- Read the code and summarize what it computes. Mention key fields being set or transformed

**`manifest_connection_node`** (Integration Node) — Connects to a third-party data provider using a pre-built connector (credit bureaus, KYC/KYB, identity verification, etc.).
- `meta.provider_resource.provider` — the provider name (e.g. `transunion_truvalidate`, `experian`, `plaid`)
- `meta.provider_resource.resource` — the specific API resource (e.g. `get_detailed_decision`)
- `meta.provider_resource.manifest_version` — connector version
- `meta.input` — data sent to the provider. Check `singles`, `lists`, `groups` for field mappings
- `meta.output` — response fields. Only describe fields where `active: true` and note their `mapped_to` value. Common outputs: `default` (full response), `score`, `result`, `confidence`
- `meta.config.environments_config` — note if sandbox/authoring uses mock data vs production
- `meta.config.caching` — whether response caching is enabled
- `meta.config.timeout` — custom timeout settings
- Describe which external provider is called, what data is sent, what comes back, and env differences

**`custom_connection_node`** — Flexible integration with any external API via HTTP. Supports various auth methods configured at the connection level.
- `meta.provider_resource` — shows `provider: "custom"`, `resource: "http"`
- `meta.verb` — HTTP method (get, post, put, delete)
- `meta.path.expression` — the URL path (may reference data fields)
- `meta.params` — query parameters
- `meta.headers` — custom headers
- `meta.body.value` — request body (raw JSON or structured)
- `meta.response` — how the response is mapped. Note `active`, `mapped_to`
- `meta.config.environments_config` — sandbox vs production data source
- `meta.config.caching`, `meta.config.timeout`, `meta.config.error` — operational settings
- Describe what HTTP call is being made, to what endpoint, and what data is extracted

**`database_connection_node`** — Connects to an external database for queries and lookups.
- `meta.provider_resource` — database connection details
- `meta.query` or `meta.config` — the query or interaction configuration
- Describe what database is queried and what data is retrieved

**`ml`** — Runs inference on a pre-trained ONNX machine learning model (max 5MB). Supports models from sklearn, XGBoost, PyTorch, TensorFlow, etc.
- `meta.model_id` — the uploaded model identifier
- `meta.description` — model description if provided
- `meta.inputs` / `meta.outputs` — model input/output schema with types and shapes
- Describe what ML model is used and what it predicts

**`ai_node`** — Utilizes an LLM (Claude, GPT, Gemini, etc.) during flow execution for tasks like document extraction, classification, or translation.
- `meta.model` — which LLM model is used
- `meta.prompt` — the prompt template (may reference data fields with $-notation)
- `meta.system_prompt` — system-level instructions
- `meta.output_config` — text or structured (JSON schema) output
- `meta.temperature`, `meta.max_tokens` — generation settings
- Describe what the AI is being asked to do and what output it produces

**`flow_node`** (Decision Flow Node) — Calls another Decision Flow in the same workspace. Enables modular logic reuse.
- `meta.child_flow_id` — the child flow being called
- `meta.input_mapping` — how parent data maps to child input
- `meta.output_mapping` — how child output maps back to parent data
- Describe which child flow is called and what data flows in/out

**`loop_node`** — Iterates the same child flow logic over each item in a collection.
- `meta.collection` — the list being iterated
- `meta.child_flow_id` — the child flow applied to each item
- `meta.break_condition` — optional early exit condition
- Describe what collection is iterated, what logic runs per item, and how results are aggregated

**`manual_review_node`** — Pauses the flow for human review. An operator must make a manual decision before the flow continues.
- Describe that this is a human-in-the-loop checkpoint and what decision the operator is expected to make

**`webhook_connection_node`** (Inbound Webhook) — Pauses the flow until an external webhook notification arrives from a data provider.
- `meta.provider_resource` — the webhook connection and event type
- Describe what external event the flow is waiting for

For any node type not listed above, describe it generically based on the meta keys present.

## Step 5: Generate example inputs per path

After describing all nodes, identify every `split_2` node in the flow. These are the branching points that create different execution paths.

For each distinct end-to-end path (determined by the combination of split outcomes), provide:
1. A short name for the path
2. A JSON input snippet that would trigger that path
3. The expected outcome (1-2 lines)

Format as a compact block per path:

```markdown
### Path: {short name}

**Input:**
```json
{
  "field": "value",
  "field": "value"
}
```

**Outcome:** {decision}, {key output values}
```

Guidelines:
- Cover every branch of every split node at least once across all examples
- Start with the "happy path", then show each rejection/alternative
- JSON inputs should be complete enough to actually run the flow (include all required fields)
- Keep outcome to one line -- just the decision and key numbers
- If stub/mock nodes affect the trace (e.g. hardcoded scores), note it briefly

## Step 6: Offer to add comments to nodes

After saving the document, ask the user if they would like the node descriptions added as comments on the platform. Wait for their confirmation before proceeding.

If confirmed, for each non-trivial node, add the generated description as a comment:

```bash
tktl comments add <slug> <version> "<description>" --node <node_id>
```

- Use the same plain-language description you wrote for the node in the document
- Keep comments concise -- 1-3 sentences max, no markdown formatting
- Skip `input`, `output`, and split branch scaffolding nodes (same ones you skipped in the document)
- Skip merge nodes and other scaffolding transforms with empty `src`

## Step 7: Save the document

Save the generated markdown to a suitable location in the project. Create the directory if it doesn't exist.

After saving, tell the user where the file was written.

## Guidelines

- Write descriptions in plain language for a non-technical audience
- Focus on the "what" and "why", not implementation details
- For decision tables, summarize the business rules rather than listing every case verbatim
- For provider nodes, explain what data is being fetched and from where
- Keep each node description to 2-4 sentences plus key config bullets
