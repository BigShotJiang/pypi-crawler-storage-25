---
name: diff-flow-versions
description: >
  Compare two versions of a Taktile flow and produce a plain-language summary
  organised by parameter, schema, node-logic, and integration changes.
  Use when reviewing what changed between versions before promotion.
---

Compare two versions of a Taktile flow and summarize what changed.

Arguments: `$ARGUMENTS` should be `<flow-slug> <v1>..<v2>`.

## Step 1: Run the diff

```bash
tktl flows diff <slug> <v1>..<v2> --output json
```

## Step 2: Interpret the JSON and write a summary

Read the structured diff JSON and produce a clear, plain-language summary organized by section. Only include sections that have changes.

### Parameter Changes
For each changed parameter, explain what threshold/constant moved and by how much.

### Schema Changes
List fields added/removed from input or output schemas.

### Structural Changes
List nodes added or removed. For type changes, explain what the node was converted to and what that implies (e.g. "replaced a rule-based decision table with an ML model").

### Logic Changes
For each modified node, explain in business terms what changed:
- Decision tables: which rules were added/removed, how the fallback changed
- Scorecards: which factor weights shifted and what that means for scoring
- Rules: which conditions or assignments changed
- Splits: how routing conditions changed
- Transforms: for code node changes, include a fenced diff block showing the old and new code. Use this format:

```diff
- old line
+ new line
```

Only show lines that actually differ -- skip identical lines unless they provide essential context (1 line of context above/below is enough). If the code is very long (>30 lines), summarize what changed in prose and show only the key diff hunks.

### Integration Changes
For each changed connector, explain what provider/resource changed, whether input/output mappings moved, and any config differences.

## Step 3: Save the document

Save the generated markdown to `flows/<slug>-diff-<v1>-vs-<v2>.md` in the project root. Create the `flows/` directory if it doesn't exist.

For example: `flows/credit-scoring-diff-v1-vs-v2-draft.md`

After saving, tell the user where the file was written.

## Guidelines

- Write for an FDE or CS person -- plain language, no raw JSON
- Describe what changed and speculate on business intent where useful, but never label changes as "bug fixes", "improvements", "optimizations", or "corrections". These are version differences, not patches.
  - Good: "min_income changed from 15,000 to 18,000 -- tightens the income eligibility threshold"
  - Bad: "min_income was fixed from 15,000 to 18,000"
- Keep it concise -- 1-2 sentences per change, except code diffs which should be shown in full when short
- If a section has no changes, skip it entirely
- If there are no changes at all, just say "No differences found between v1 and v2."
