---
name: tktl-debug
description: >
  Debug and fix errors in Taktile flows using the tktl CLI. Use this skill whenever
  a flow run fails, errors, or produces unexpected results — whether the error comes
  from a direct `tktl flows run` command, a decision ID or decision URL, a batch run,
  or a test dataset from the Test tab in the Taktile UI. Handles all error categories:
  input schema validation (422), output schema validation (409), runtime node errors
  (Python/expression failures), logic errors (wrong decision output), missing/null
  field values, and type mismatches across version upgrades. Always produces a
  human-readable diagnosis report and proposes specific fixes, then waits for the
  user to approve before applying anything.
---

# tktl Debug Skill

You're a debugging assistant for Taktile flows. Your job is to figure out exactly what
went wrong, explain it clearly, propose a fix, and — only after the user approves —
apply it.

**The golden rule — three stages, no shortcuts:**

1. **Show everything first.** Present the full diagnosis and every proposed fix before doing anything.
2. **Collect confirmations first.** Step through each fix (yes/skip) — no version is created yet.
3. **Final gate.** Show a summary of what will be applied, confirm version name, wait for yes.
4. **Only then** create the DRAFT and apply the confirmed fixes.
5. **No test runs.** The DRAFT is the deliverable — never run verification.

**New versions are always DRAFT. Nothing is ever published by this skill.**

---

## Step 1 — Gather context

Determine the error source from the conversation:

| Source | How to get the error details |
|---|---|
| Direct `tktl flows run` output | Already in the conversation — parse it |
| Decision URL | Parse slug + version from the URL, then reproduce (see below) |
| Decision ID (bare) | Ask for flow slug + version + input data, then reproduce |
| Batch run history | Use `tktl flows history <slug> --run-id <id>` |
| Test dataset (Test tab) | Download dataset via CLI and re-run rows (see below) |
| Input field value (entity, email, etc.) | Download dataset, filter locally, re-run matching row |
| "It's just wrong" (logic error) | Run the flow yourself with the input data provided |

If the user hasn't given you the flow slug or version name yet, ask before proceeding.
You can often infer the slug from a decision URL (e.g. `flow_slug=consumer-loan-underwriting-v2`).

### CLI handles auth — no manual config parsing needed

The CLI reads its own config and credentials automatically. If the user has a local
config directory (e.g. `.tktl-local/`), prefix commands with `TKTL_CONFIG_DIR`:

```bash
TKTL_CONFIG_DIR=.tktl-local tktl flows list
```

If `~/.tktl` is set up, just use `tktl` directly. **Never** parse config.json or
credentials.json manually — let the CLI handle authentication.

### Decision IDs — the CLI cannot fetch past decisions

The CLI has no decision history lookup. When the user provides a decision ID alone:

> The CLI can't fetch past decisions by ID. To debug this, I need:
> 1. The **flow slug** (or a decision URL I can parse it from)
> 2. The **version name**
> 3. The **input data** — point me to a test dataset, paste the JSON, or I'll grab a row from an existing dataset and re-run.

### Decision URLs — parse and reproduce

A Taktile decision URL contains everything needed to identify the flow and version:
```
https://app.dev.taktile.com/decide/org/<org>/ws/<workspace>/flow/<flow_id>/version/<version_id>?...
```

Extract `flow_id` and `version_id` from the URL, then resolve the flow slug and version name:
```bash
tktl flows list                              # match flow_id → slug
tktl versions list <slug>                    # match version_id → version name
```

Then reproduce the error by re-running with sample input (from a dataset or user-provided).

### Looking up decisions by input field value

The CLI has no decision history search. Instead, download a test dataset, filter locally
for the matching input value, and re-run that row to reproduce:

```bash
tktl datasets list <slug>
tktl datasets download <dataset_id> --format json -o /tmp/dataset.json
```

Then filter locally:
```python
import json
rows = json.load(open('/tmp/dataset.json'))
matches = [r for r in rows if r.get('request', {}).get('data', {}).get('<field>') == '<value>']
if matches:
    input_data = matches[0]['request']['data']
    json.dump(input_data, open('/tmp/input.json', 'w'), indent=2)
```

Then reproduce:
```bash
tktl flows run <slug> -v "<version>" -f /tmp/input.json
```

### Fetching test dataset results (Test tab)
```bash
tktl datasets list <slug>                                          # list datasets
tktl datasets download <dataset_id> --format json -o /tmp/dataset.json  # download
```

**Before running any rows, always show a confirmation prompt:**

```
Dataset run confirmation

Running "<dataset_name>" will send <N> API calls to your sandbox endpoint.

This will consume API quota and may trigger any downstream integrations
connected to your sandbox environment.

Type "yes" to proceed, or "cancel" to abort.
```

Do not proceed until the user explicitly confirms. If they cancel, offer to inspect the dataset rows locally without running them.

---

## Step 2 — Fetch the version schema and graph

You'll need the full version object for nearly every error type.

```bash
# List versions to find the right name
tktl versions list <slug>

# Fetch full version with graph (schema + graph + nodes)
tktl versions describe <slug> "<version_name>" --full -o json > /tmp/version.json

# Or just the summary (no graph)
tktl versions describe <slug> "<version_name>" -o json

# Inspect a specific node
tktl nodes describe <slug> "<version_name>" <node_id> -o json

# Inspect only a node's meta section
tktl nodes describe <slug> "<version_name>" <node_id> --section meta -o json
```

Extract key info in one pass:
```python
import json
d = json.load(open('/tmp/version.json'))

# Input schema — types AND required fields
print("INPUT SCHEMA:")
required = d['input_schema'].get('required', [])
for k, v in d['input_schema'].get('properties', {}).items():
    req = " [REQUIRED]" if k in required else ""
    print(f"  {k}: {v.get('type')}{req}")

# Output schema
print("\nOUTPUT SCHEMA:")
for k, v in d['output_schema'].get('properties', {}).items():
    print(f"  {k}: {v.get('type')}")

# All nodes — type, name, id
print("\nNODES:")
for nid, node in d['graph']['nodes'].items():
    print(f"  {nid[:8]}... type={node['type']} name={node.get('name')}")
```

---

## Step 3 — Diagnose the error

Match the error to one of these categories:

### A. Input schema validation (422)
**Signature:** `"Input schema validation failed on field '<X>': [Input value] is not of type '<T>'"` from `detail.msg`

**Root cause:** The input JSON value for field `X` doesn't match the type declared in `input_schema.properties.X.type`.

**Before proposing a fix, consider two possibilities — include both in your diagnosis report:**
- **The schema change is intentional:** the version genuinely requires a new type → coerce the input to match
- **The schema change is a mistake:** the type was incorrectly changed (e.g. a version authoring error) → revert the schema

Compare with the previous version to help determine which is true:
```bash
tktl versions list <slug>                                          # see all versions
tktl versions describe <slug> "<old_version>" -o json > /tmp/old_version.json
tktl versions describe <slug> "<new_version>" -o json > /tmp/new_version.json
# Then compare input schemas between the two
```
If you can't determine intent from context, present both options and let the user decide.

**Check ALL fields and required fields at once** — multiple mismatches are common after version upgrades, and missing required fields cause a second 422 after the first fix:

```python
import json
d = json.load(open('/tmp/version.json'))
input_data = json.load(open('/tmp/input.json'))

required = d['input_schema'].get('required', [])
mismatches = []
missing_required = []

for field, schema in d['input_schema']['properties'].items():
    expected = schema.get('type', [])
    val = input_data.get(field)
    
    if val is None and field in required:
        missing_required.append(field)
        continue
    if val is None:
        continue
    
    mismatch = (
        expected == ['boolean'] and not isinstance(val, bool) or
        expected == ['number'] and not isinstance(val, (int, float)) or
        expected == ['string'] and not isinstance(val, str) or
        expected == ['integer'] and not isinstance(val, int)
    )
    if mismatch:
        mismatches.append((field, expected, val))

print("Type mismatches:", mismatches)
print("Missing required fields:", missing_required)
```

---

### B. Output schema validation (409)
**Signature:** `"Output schema validation failed on field '<X>': [Input value] is not of type '<T>'"` from `detail.msg`

**Root cause:** The flow ran fine but the output validator rejected the result because the
output schema type for field `X` doesn't match what the flow actually produced.

**Before proposing a fix, consider three possibilities:**

1. **The output schema is wrong** — update it to match what the flow actually produces
   → `tktl update apply ... --schema-out @fixed_schema.json`
   → Best when: the schema is stale/hasn't been updated after a node change

2. **A node is incorrectly converting the field** — find the transform/assignment node upstream
   that's changing the field's type and fix the source code or expression
   → `tktl update apply ... --node <id> --node-config '{"src": "..."}'`
   → Best when: the output schema is intentionally typed (e.g. `ID` should always be a string)

3. **The input schema change cascaded** — if the input type changed (e.g. `ID: string → boolean`),
   the value flows through unchanged and breaks the output schema too
   → Fix both input schema and output schema together, or revert both

To trace which node last touched the field, search `meta.default_effects`, `meta.branches[].effects`,
and `meta.src` across all nodes for references to that field name.

---

### C. Runtime node error
**Signature:** A `node_id` in `detail.node_id` plus a Python traceback or expression error
in `detail.msg`.

**Find the failing node:**
```bash
tktl nodes describe <slug> "<version>" <node_id_from_error> -o json
```

Or from the full version JSON if already fetched:
```python
import json
d = json.load(open('/tmp/version.json'))
node_id = "<node_id_from_error>"
node = d['graph']['nodes'].get(node_id, {})
print(json.dumps(node, indent=2))
```

Common node types and their config:
| Node type | Config location | What can go wrong |
|---|---|---|
| `rule_2` | `meta.branches`, `meta.default_effects` | Expression error, missing field reference |
| `assignment_node` | `meta.default_effects` | Bad expression, wrong field name |
| `split_2` | `meta.branches` | Condition references undefined variable |
| `decision_table` | `meta.cases`, `meta.predicate_fields` | Wrong field types, missing fallback |
| `transform` | `meta.src` | Python syntax/runtime error in source code |
| `scorecard` | `meta.factors` | Factor input field missing, bad fallback value |
| `ai_node_v2` | `meta` | Model error, token limit, missing prompt |

Read the node's full `meta` to understand its logic before proposing a fix.

---

### D. Logic error (wrong output, no exception)
**Signature:** The flow returns `status: success` but the decision value is unexpected
(e.g. wrong decision, wrong score, unexpected rejection reason).

**This requires tracing the full execution path.** Work backwards from the wrong output:

1. Identify which output field is wrong (e.g. `decision`, `credit_limit`, a rejection reason)
2. Find which node sets that field — search `effects` / `default_effects` / `assign_field` across nodes
3. Trace the condition that triggered it — check branch clauses and their input field values
4. **Read transform node source code** — bugs are often in `transform` nodes with Python code in `meta.src`. These are easy to miss if you only look at rule/split nodes.

```python
import json
d = json.load(open('/tmp/version.json'))
nodes = d['graph']['nodes']

# Dump ALL transform node source code — logic bugs live here
print("=== TRANSFORM NODE SOURCE CODE ===")
for nid, node in nodes.items():
    if node.get('type') == 'transform':
        src = node.get('meta', {}).get('src', '')
        if src.strip():
            print(f"\n--- {node.get('name')} [{nid}] ---")
            print(src)

# Also dump rule nodes with their branch conditions
print("\n=== RULE NODE CONDITIONS ===")
for nid, node in nodes.items():
    if node.get('type') == 'rule_2':
        meta = node.get('meta', {})
        for branch in meta.get('branches', []):
            for clause in branch.get('clauses', []):
                print(f"{node.get('name')}: {clause.get('left')} {clause.get('operator')} {clause.get('right')}")
        for effect in meta.get('default_effects', []):
            print(f"  default → {effect.get('target')} = {effect.get('value')}")
```

Key things to look for in transform code:
- **Hardcoded test values** that were meant to be temporary (e.g. `pd_score = 0.99`)
- **Wrong field references** that silently return `None` (no error, just null)
- **Off-by-one or inverted logic** in calculations
- **Fallback values in scorecards** — a fallback of `0` on a credit score factor will tank the score when the input data is missing

---

### E. Missing / null field values
**Signature:** A required field is `null` or missing in the output, or an expression fails
because a field evaluates to `None`.

**Check:**
- Is the field present in the input data?
- Does the version's input schema mark it as required?
- Is there a transform node upstream that should populate it but isn't?
- Does a scorecard factor reference a field that's `null`? (check `fallback` values)

---

## Step 4 — Write the diagnosis report

Present the full list of issues found, but **do not apply anything yet**. Show every
proposed fix with its exact before/after values so the user can review each one:

```
## Diagnosis — N issues found

### Fix 1 — [Severity] — [Short title]
**Location:** [node name + ID, or schema field]
**Root cause:** [One clear sentence]
**Change:** `[exact before]` → `[exact after]`

### Fix 2 — [Severity] — [Short title]
**Location:** ...
**Root cause:** ...
**Change:** `[exact before]` → `[exact after]`

...

---
Proposed new version name: **vX.Y**
(All fixes will be applied to a DRAFT duplicate. Nothing will be published.
The original version is not modified.)

Reply with the fixes you want to apply — e.g. "apply all", "apply 1 and 3", or
"apply 1" — and confirm or change the version name. I will ask for your approval
on each fix individually before applying it.
```

---

## Step 5 — Top-level gate

After presenting the full diagnosis, ask a single question before creating anything:

```
[N] fixes identified. Would you like me to apply them?
I'll walk through each one individually and ask for your approval before making any change.

What would you like to name the new version? (suggested: vX.Y)
```

Wait for the user to reply with both a confirmation ("yes", "go ahead", "do it") and a
version name. If they only say yes without a name, use the suggested name. If they only
provide a name without a clear yes, confirm with "Shall I proceed with <name>?"

Do not create the new version or touch anything until this gate is cleared.

---

## Step 6 — Confirm each fix, then create DRAFT, then apply

**Phase A — collect confirmations (no version created yet)**

Step through each fix and collect a yes or skip for every one before touching anything:

```
Fix [N] of [total] — [title]
Location: [node name + ID, or schema field]
Before:   [exact current value]
After:    [exact proposed value]

Include this fix? (yes / skip)
```

- **yes** → mark as included, show next fix
- **skip** → mark as skipped, show next fix

After all fixes have been reviewed, show a summary of what will be applied:

```
Ready to apply:
  ✓ Fix 1 — [title]
  ✓ Fix 3 — [title]
  — Fix 2 — [title]  (skipped)

Create DRAFT version "<name>" and apply 2 fixes? (yes / cancel)
```

**Phase B — comment on faulty nodes (before creating the DRAFT)**

After the user confirms the final summary, add a comment to each faulty node on the
**original version** explaining the root cause and proposed fix. This leaves a paper
trail visible in the Taktile UI so anyone reviewing the flow can see what was found.

```bash
tktl comments add <slug> "<source_version>" \
  "[Diagnosis] <root cause summary>. Fix: <what will change>." \
  --node <node_id>
```

For schema-level fixes (no specific node), comment on the output or input node:
```bash
tktl comments add <slug> "<source_version>" \
  "[Diagnosis] Output schema field 'ID' has wrong type (boolean). Fix: revert to string." \
  --node <output_node_id>
```

Report each comment as it's added:
```
💬 Commented on "Weight Bureau and Internal Scores" [205a7313] — empty predicate on Factor 1
💬 Commented on "Mock ML" [e05c1d6e] — pd_score hardcoded to 0.99
```

If commenting fails (e.g. the version is archived), warn and continue — comments are
informational, not blocking.

**Phase C — create DRAFT and apply (only after comments are posted)**

Only after comments are posted and the user has confirmed the final summary:

```bash
tktl versions duplicate <slug> --from "<source_version>" --name "<confirmed_name>"
# Verify status is DRAFT
tktl versions list <slug>
```

Then apply each confirmed fix in sequence. Report each one as it's applied:
```
✓ Fix 1 — [title] applied
✓ Fix 3 — [title] applied
```

If the CLI returns an error on any fix, report it immediately and ask whether to
continue with remaining fixes or stop.

---

## Step 6 — Apply the approved fix

### Fix A/B: Schema fixes

**Option 1 — Coerce input data** (schema change was intentional):
```python
import json
data = json.load(open('/tmp/input.json'))

# Type coercions:
# boolean: truthy non-empty string → True; "false"/"0"/"" → False
# number: "42" → 42
# string: 42 → "42"
# integer: "10" → 10

data['ID'] = True  # example
json.dump(data, open('/tmp/input_fixed.json', 'w'), indent=2)
```

**Option 2 — Revert the input schema** (schema change was a mistake):
```bash
tktl update apply <slug> "<version>" \
  --schema-in '{"properties": {"ID": {"type": ["string"]}}}'
```

**Patch output schema** (for 409 errors):
```python
import json
d = json.load(open('/tmp/version.json'))
out = d['output_schema']
out['properties']['ID']['type'] = ['boolean']  # example
json.dump(out, open('/tmp/output_schema_fixed.json', 'w'), indent=2)
```
```bash
tktl update apply <slug> "<version>" --schema-out @/tmp/output_schema_fixed.json
```

### Fix C/D: Node config / source code patch

```bash
# Deep-merges into the node's meta — only include fields that change
tktl update apply <slug> "<version>" \
  --node <node_id> \
  --node-config '{"src": "data[\"pd_score\"] = 0.01\ndata[\"output_label\"] = 1"}'
```

For multiline source, write to a file first:
```python
import json
config = {"src": 'data["output_label"] = 1\ndata["pd_score"] = 0.01\n'}
json.dump(config, open('/tmp/node_fix.json', 'w'))
```
```bash
tktl update apply <slug> "<version>" --node <node_id> --node-config @/tmp/node_fix.json
```

For parameter-driven thresholds:
```bash
tktl update apply <slug> "<version>" --params '{"threshold": <new_value>}'
```

**Important:** `--node-config` deep-merges into the existing `meta` — only send the fields that change.

---

## Step 7 — Report and stop

After all fixes are processed, report what happened and stop. Do not run any test or
verification runs — the DRAFT is the deliverable and the user will review it in the
Taktile UI on their own terms.

```
## Done

New version: <name> (DRAFT — not published)
Applied: Fix 1 — [title], Fix 2 — [title], ...
Skipped: Fix 3 — [title]  (or "None skipped")

Ready for your review in the Taktile UI.
```

If the user cancelled mid-way, be clear about which fixes were applied before the
cancellation so they know the exact state of the DRAFT.

---

## Tips

- **Always preserve originals** — write fixed files to new paths (`input_fixed.json`, not `input.json`)
- **DRAFT versions require `-v`** — `tktl flows run <slug> -v "<draft_name>"`, the default published-version lookup fails for drafts
- **Output schemas can be huge** — fetch via `tktl versions describe --full -o json` and patch in-place
- **Check ALL fields at once** — when a version bumps types, multiple fields often change together
- **Read transform node source code** — logic bugs are often hardcoded values or wrong expressions in Python transform nodes, not in rule/split nodes
- **Scorecard fallbacks matter** — a fallback of `0` on a scoring factor silently tanks the score when input data is null
- **`--node-config` is a deep merge** — only include the fields you're changing
- **Use `tktl nodes describe`** — faster than downloading the full version when you only need one node's config
- **No decision history in the CLI** — always reproduce errors by re-running, never try to fetch past decisions
