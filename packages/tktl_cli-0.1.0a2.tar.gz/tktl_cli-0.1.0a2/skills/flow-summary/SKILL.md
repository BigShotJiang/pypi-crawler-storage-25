---
name: flow-summary
description: >
  Analyze Taktile flow JSON files and produce summary documentation.
  Use when the user opens a conversation with flow JSON files or asks
  to summarize, trace variables, or compare flow versions.
compatibility: Requires flow JSON files exported from Taktile
metadata:
  author: taktile-org
  version: "1.0"
---

# Flow Analysis Instructions

When the user opens a conversation in this folder, or asks about a flow, follow these instructions.

## Folder conventions

### Versioning

Files follow the pattern `Flow Name - shad-feb-vX.Y.json`. Multiple versions may exist for the same flow -- the highest version number or most recent date suffix is the latest.

### Requirements

The `reqs/` folder (if present) contains feature requirements (exported from Notion) that describe planned or in-progress changes to the flows.

## On first load / when asked to summarize a flow

Read the flow JSON and produce a **Flow Summary** with the sections below. Output it as a markdown document.

### 1. Overview

- Flow name (from filename and top-level `name` field)
- Status (`status` field -- DRAFT or PUBLISHED)
- Version (`name` at top level)
- Number of nodes, number of edges

### 2. Parameters

List every entry in the top-level `parameters` array:

| Parameter | Value | Description |
|---|---|---|
| name | value | description |

### 3. Input schema

Parse `input_schema`. List each property with its type, and mark which are `required`.

### 4. Output schema

Parse `output_schema`. If it is empty (`{}`), note "passthrough -- returns full data object". Otherwise list properties and types.

### 5. Node inventory

Build a table from `graph.nodes`:

| # | Node name | Type | Purpose (1-liner from code/config) |
|---|---|---|---|

Sort by execution order. To determine execution order, trace `graph.edges` from the `input` node forward. For splits, list the split node, then each branch (indent or note the branch), then the merge node.

Node types you will encounter:
- `input` -- entry point, name is always `data`
- `output` -- exit point, `meta.src` indicates what is returned
- `transform` -- Python code in `meta.src`; special flags: `is_split_branch_node`, `is_split_merge_node`
- `assignment_node` -- sets fields via `meta.default_effects[].target = value`
- `rule_2` -- decision table with `meta.branches[]`, each containing `clauses` (conditions) and `effects` (assignments)
- `split_2` -- conditional branch; `meta.branches[]` with `clauses` and `edge_id` pointing to the branch start
- `custom_connection_node` -- HTTP API call (CC node); see section 7
- `sql_database_connection_node` -- SQL query via a database connection; see section 7

### 6. Execution graph (text diagram)

Produce a simple text flow showing the path from input to output. Use indentation for split branches:

```
data (input)
  -> Node A (transform)
  -> Node B (split_2)
     | Branch 1 -> ...
     | Branch 2 -> ...
     -> Merge Node
  -> output
```

### 7. External connections (CC nodes and SQL nodes)

For each `custom_connection_node` and `sql_database_connection_node`, extract:

| Field | Where to find it |
|---|---|
| Node name | `name` |
| Provider | `meta.provider_resource.provider` (e.g. `custom`, `snowflake`) |
| Resource | `meta.provider_resource.resource` (e.g. `http`, `database`) |
| HTTP verb | `meta.verb` (CC nodes only) |
| Request body | `meta.body.value.raw` -- shows what data is sent |
| SQL query | `meta.query.expression` (SQL nodes only) |
| Query variables | `meta.variables[]` -- key/expression pairs bound into the query |
| Response mapping | `meta.response.mapped_to` (CC nodes) or `meta.response.default.mapped_to` (SQL nodes) |
| Caching | `meta.config.caching.active` |
| Error handling | `meta.config.error` |

**Important**: The `mapped_to` value is the field name on the `data` object where the response lands. Downstream nodes access it as `data.<mapped_to>`. For example, if `mapped_to` is `"linear_output"`, downstream code references `data.linear_output`, `data.linear_output.data.body`, etc.

After the table, for each CC/SQL node, trace which downstream nodes read from `data.<mapped_to>` and list the specific fields accessed. Example:

> **"Get Issues" node** -> response mapped to `data.linear_issues`
> - "Process Issues" (transform): reads `data.linear_issues.data.body.data.issues.nodes` -- iterates over issue list, accesses `.id`, `.identifier`, `.title`, `.state.name`, `.comments.nodes`

## Variable tracing (when asked "what happens if field X changes")

When the user asks about a specific variable or field:

1. **Find all references**: Search every node's `meta.src`, `meta.default_effects`, `meta.branches[].clauses`, `meta.branches[].effects`, `meta.body.value.raw`, `meta.query.expression`, and `meta.variables[].expression` for the field name.

2. **Build a dependency chain**: For each node that references the field, determine:
   - Does this node **read** the field or **write** it?
   - What other fields does this node produce that depend on it?

3. **Trace downstream**: Follow the edges forward from each node that reads the field. Any node that reads a field *produced by* a node that depends on the original field is also affected.

4. **Output a table**:

| Node | Read/Write | Expression | Downstream impact |
|---|---|---|---|
| "Assemble Details" | Read | `data.alarm_name` used in f-string | Produces `data.issue_title`, `data.issue_description` |
| "Prepare Query" | Read (transitive) | Uses `data.issue_title` | Produces `data.linear_ticket_query` |

5. **Summarize**: "Changing `X` directly affects N nodes and transitively affects M more via [list of intermediate fields]."

## CC node response parsing (when asked "what fields does this API return / what do we use from this API")

For each CC node:

1. Identify the `mapped_to` value from `meta.response`.
2. Search all downstream nodes for references to `data.<mapped_to>`.
3. For each reference, extract the full access path (e.g. `data.linear_output.data.body.data.issueCreate.issue.identifier`).
4. Present as:

**Node: "Add Comment"** (POST to Linear API)
- Response mapped to: `data.linear_output`
- Fields accessed downstream:
  - `data.linear_output.data.body.data.issueCreate.issue.identifier` -- used in "Prepare Slack Alert" to build Linear URL
  - `data.linear_output.data.body.data.commentCreate.comment.id` -- used in "Prepare Slack Alert" to build comment link
  - `data.linear_output.data.body.errors` -- checked in "Handle errors" for error responses

## How the user will typically ask for help

- **"Summarize this flow"** -- produce the full summary from sections 1-7 above.
- **"What are the inputs/outputs?"** -- sections 3 and 4.
- **"What does node X do?"** -- read that node's `meta.src` or config and explain the logic.
- **"What happens if field Y changes?"** -- run the variable tracing procedure.
- **"What external APIs does this flow call?"** -- section 7.
- **"What fields do we use from the X API response?"** -- CC node response parsing procedure.
- **"Compare version A and B"** -- load both JSONs, diff the node lists (added/removed/modified nodes), and diff the code within modified nodes.
- **"Write requirements for changing X"** -- use the variable tracing to identify blast radius, then draft requirements referencing specific nodes.

## Tips for reading flow JSON

- The top-level structure contains metadata and a `graph` object with `nodes` and `edges` arrays.
- Each node has `type`, `name`, `id`, and `meta` (which holds all configuration/code).
- Edges connect nodes via `start_node_id` -> `end_node_id`. Split edges have `meta.is_split_edge: true`.
- Transform nodes contain Python code in `meta.src`. This is where most business logic lives.
- The `data` object is the shared state that flows through every node. Nodes read from and write to `data.*` fields.
- `params.*` references come from the top-level `parameters` array -- these are flow-level constants.
- Sub-flow calls reference other flows by name -- cross-reference with other JSON files in the folder.
- When tracing logic, follow edges from `input` to `output` to understand execution order.
