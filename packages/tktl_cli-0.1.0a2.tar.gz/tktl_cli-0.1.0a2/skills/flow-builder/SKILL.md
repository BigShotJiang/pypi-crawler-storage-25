---
name: flow-builder
description: >
  Build, test, and iterate on Taktile decision flows via the tktl CLI.
  Use when creating or modifying flows, adding nodes, running decisions,
  batch testing, managing datasets, or debugging flow execution errors.
  Covers transforms, splits, scorecards, decision tables, connections,
  schemas, datasets, comments, and lifecycle.
compatibility: Requires Python 3.11+ and the tktl-cli package (pip install tktl-cli)
metadata:
  author: taktile-org
  version: "0.1"
---

# Flow Builder Guide

Build, test, and iterate on Taktile decision flows via `tktl`.

**References:** [node-configs.md](references/node-configs.md) · [flow-patterns.md](references/flow-patterns.md) · [debugging.md](references/debugging.md) · [child flows](references/working-with-child-flows-and-loop-nodes.md)

---

## Agent Rules

1. **Clarify before building.** If Chrome tools are present, read the browser URL to extract org/workspace/flow/version/node IDs — don't run `tktl config list`. Only ask the user about undecided business logic.
2. **Render before building.** Always run `tktl render --text "..."` with a Mermaid diagram and get user approval before any `tktl versions duplicate` or `tktl nodes add` calls.
3. **Chrome: read-only.** Inspect state and navigate to show the user something. All edits go through the CLI. Use `open {path}` for local files — Chrome mangles `file://` URLs.
4. **Schema first.** Define `--schema-in` and `--schema-out` before adding logic nodes. Without them, responses return `data: {}`.

---

## Setup

```bash
tktl auth login
tktl config set org       <org-id>
tktl config set workspace <workspace-id>
tktl config set flow_api_url <url>   # e.g. https://flow-api.stg.cp.taktile.com
tktl config set env sandbox          # or live
```

---

## Core Workflow

### 1. Explore

```bash
tktl flows list                                  # all flows
tktl flows describe <slug>                       # metadata + versions
tktl folders list                                # all folders
tktl versions list <slug>                        # versions + statuses
tktl nodes list <slug> <version>                 # node index
tktl nodes describe <slug> <version> <node_id>   # full node config
```

### 2. Design — render a Mermaid diagram first

```bash
tktl render --text "flowchart TD ..."
# → file:///tmp/tktl/<timestamp>.png
```

Get user approval before proceeding. Use `open {png_path}` (macOS) to preview — not Chrome.

**Mermaid label rules:** type + name only, `<br/>` for line breaks (never `\n`), human-readable types (`rule`, `split`, `dt`, `assign` — not API names). See the convention table below.

| Element | Shape | Class |
|---|---|---|
| I/O | `N(["label"])` | `:::io` |
| Assignment | `N["<b>assign</b><br/>Name"]` | `:::assign` |
| Rule | `N[["<b>rule</b><br/>Name"]]` | `:::rule` |
| Decision table | `N[("<b>dt</b><br/>Name")]` | `:::dt` |
| Scorecard | `N["<b>score</b><br/>Name"]` | `:::score` |
| Split | `N{"label"}` | `:::split` |
| Branch | `N>"label"]` | `:::branch` |
| Merge | `N(( ))` | `:::merge` |
| Connection | `N["<b>connection</b><br/>Name"]` | `:::connection` |
| Open/TBD | `N["<b>open</b><br/>desc"]` | `:::open` (dashed) |
| Split edge | `-->\|"score < 50"\|` | condition string |
| Default branch edge | `-->\|"default"\|` | always label default |
| Legend | `subgraph Legend[" "]` | `direction LR`, only types used |

Use `:::open` for nodes needing user input.

**classDef block** (paste at top of every Mermaid diagram):

```
classDef io fill:#ECFDF5,stroke:#059669,color:#1F2537
classDef assign fill:#D1FAE5,stroke:#10B981,color:#1F2537
classDef rule fill:#FFEDD5,stroke:#F97316,color:#1F2537
classDef dt fill:#FEF2F2,stroke:#EF4444,color:#1F2537
classDef score fill:#EEF1FF,stroke:#6A63F1,color:#1F2537
classDef split fill:#FFFBEB,stroke:#F59E0B,color:#1F2537
classDef connection fill:#FEF3C7,stroke:#D97706,color:#1F2537
classDef ai fill:#EEF1FF,stroke:#493FC1,color:#1F2537
classDef branch fill:#FFFBEB,stroke:#F59E0B,color:#1F2537
classDef merge fill:#E5E6EB,stroke:#D1D3DB,color:#6B6F80
classDef open fill:#FEF3C7,stroke:#D97706,color:#1F2537,stroke-dasharray:6 3
```

### 3. Create

```bash
# New flow (creates draft v1 with input + output nodes)
tktl flows create <slug> "Display Name"
tktl flows create <slug> "Display Name" --folder <folder-id>

# Or duplicate an existing version
tktl versions duplicate <slug> <ver> --name my-experiment
```

Set schemas immediately:

```bash
tktl update apply <slug> <ver> \
  --schema-in  @input_schema.json \
  --schema-out @output_schema.json
```

### 4. Build — add nodes in graph order

```bash
tktl nodes list <slug> <ver>                     # get input node ID
tktl nodes add <slug> <ver> --type <type> --name "Name" --after <id> [options]
tktl update apply <slug> <ver> --node <id> --node-config '<JSON>'
```

See [references/node-configs.md](references/node-configs.md) for per-type config and [references/flow-patterns.md](references/flow-patterns.md) for common patterns.

### 5. Test — single first, then batch

```bash
# Single decision (always test this first)
tktl flows run <slug> --version <ver> --input '{"field": "value"}'

# Batch (up to 1000 rows)
tktl flows batch <slug> --version <ver> --file data.csv --concurrency 5
```

Always specify `--version` — without it, the API uses the default published version (404 if none).

### 6. Iterate

```bash
tktl update apply <slug> <ver> --node <id> --node-config '{"src": "..."}'
tktl nodes remove <slug> <ver> <node_id>          # auto-rewires graph
```

### 7. Lifecycle

```bash
tktl versions publish <slug> <ver>                # draft → published
tktl versions archive <slug> <ver>                # retire old version
```

### 8. Comments

```bash
tktl comments list <slug> <version>                        # all version comments
tktl comments list <slug> <version> --node <node_id>       # node-specific
tktl comments add <slug> <version> "Your comment"          # add to version
tktl comments add <slug> <version> "Your comment" --node <node_id>
tktl comments delete <comment_id>
```

### 9. Inspect batch results

```bash
tktl flows history <slug>                                    # list all runs
tktl flows history <slug> --run-id <id>                      # run metadata
tktl flows history <slug> --run-id <id> --query "output.data.decision"
```

---

## Node Type Selector

Prefer structured types over transforms — they're auditable and visualisable.

| Type | Best for | Avoid for |
|:---|:---|:---|
| `assignment` | Fixed values, simple expressions | Complex branching |
| `rule` | If/then with multiple effects | Single-field assignments |
| `split` | Route execution to different paths | — |
| `scorecard` | Weighted multi-factor scoring | Binary pass/fail |
| `decision_table` | Multi-predicate → multi-output lookup | Continuous scoring |
| `matrix_table` | Two-dimensional grid lookup | Single-dimension lookups |
| `transform` | Complex Python: loops, math, string ops | Anything declarative can handle |

Type aliases: `split` → `split_2`, `rule` → `rule_2`, `assignment` → `assignment_node`.

---

## Key Constraints

- **UUIDs only.** Every `id`, `id_left`, `id_right` must be UUID4 or `""` (auto-filled). Short strings like `"f1"` pass the API but fail the execution engine.
- **Operators:** `ge`, `le`, `gt`, `lt`, `eq`, `ne` — not `gte`/`lte`.
- **Rule effects:** Every field in `default_effects` must appear in every `branch.effects`.
- **Nullable fields:** `{"anyOf": [{"type": "number"}, {"type": "null"}]}`.
- **Full graph in PATCH:** Manual PATCH requires all nodes — partial sends get 409. Use `tktl nodes add/remove` instead.
- **Assignment targets are bare names:** `"target": "risk_score"` not `"data.risk_score"`.

---

## Common Gotchas

| # | Symptom | Fix |
|---|---|---|
| 1 | Empty `data: {}` in response | Set `--schema-out` |
| 2 | `{"detail": "Not Found"}` | No published version or wrong `--version` |
| 3 | Stale node list | `tktl cache clear` |
| 4 | `ConflictError: [validation]` | Fix the named field in node config |
| 5 | `ConflictError: modified N times` | Concurrent edit — retry |
| 6 | Split routes everything same way | Check clause type: bool `False` ≠ string `"False"` |
| 7 | Batch empty rows | Lower to `--concurrency 5` |
| 8 | Config subcommand | `tktl config list` (not `show`) |
| 9 | `folders create` 409 | Folder exists — reuse with `tktl folders list` |
| 10 | `flows create --folder` returns null folder_id | Expected — assignment is via Taktile API, not Flow API |

For full debugging procedures, see [references/debugging.md](references/debugging.md).

---

## Dataset Management

### Create

```bash
tktl datasets create <slug> --name "Test Data" --from-schema v1        # from flow schema
tktl datasets create <slug> --name "Manual" --columns '[{"name": "income", "desired_type": "number"}]'
tktl datasets upload <slug> --file data.csv --name "Uploaded Data"     # from file
```

### Inspect

```bash
tktl datasets list <slug>                          # list all datasets
tktl datasets describe <dataset_id>                # metadata + columns
tktl datasets rows <dataset_id> --from 0 --size 50 # paginated rows
tktl datasets download <dataset_id> --format csv
```

### Modify rows

```bash
tktl datasets add-rows <dataset_id> --blank 10
tktl datasets add-rows <dataset_id> --data '[{"income": 50000}]'
tktl datasets add-rows <dataset_id> --file more_data.csv
tktl datasets update-row <dataset_id> <row_id> --data '{"input_data": {"income": 99999}}'
tktl datasets delete-row <dataset_id> <row_id>
```

Row appends auto-batch in groups of 50 (API limit).

### Modify columns

```bash
tktl datasets add-column <dataset_id> --group input_columns --name age --type integer
tktl datasets rename-column <dataset_id> --group input_columns --old income --new annual_income
tktl datasets delete-column <dataset_id> --group input_columns --name old_field
tktl datasets fill-column <dataset_id> --group input_columns --name age --value 30
```

Column groups: `input_columns`, `output_columns`, `mock_columns`, `meta_columns`, `outcome_columns`.

### Schema sync

```bash
tktl datasets sync-schema <slug> <dataset_id> --version v2             # detect drift
tktl datasets sync-schema <slug> <dataset_id> --version v2 --apply     # auto-add missing
```

Reports missing/extra columns and type mismatches. `--apply` adds missing columns but never auto-deletes.

### Delete

```bash
tktl datasets delete <dataset_id>
```

---

## Custom Connections

Custom connections call external APIs from within a flow. Requires a workspace connection configured in the Taktile UI.

```bash
# 1. Find connection + resource config IDs
tktl connections list -o json
# Note: id → connection_id, resource_configs[].id → resource_config_id (pick "http")

# 2. Add to graph
tktl nodes add <slug> <ver> --type custom_connection --name "Fetch Score" \
  --after <id> --config @cc.json
```

**Config file** (`cc.json`):

```json
{
  "provider_resource": {"provider": "custom", "resource": "http"},
  "connection_id": "<connection-uuid>",
  "resource_config_id": "<resource-config-uuid>",
  "config": {
    "error": {"allow_4xx": false, "allow_5xx": false},
    "caching": {"active": false, "max_age_seconds": "86400"},
    "testing": {"use_cached_reports": false, "use_fallback_live_connection": false},
    "timeout": {"active": false, "timeout_seconds": "15"},
    "environments_config": {
      "production": "production",
      "sandbox_mode_data_source": "production",
      "authoring_mode_data_source": "mock_data"
    }
  },
  "verb": "get",
  "path": {"id": "", "expression": ""},
  "params": [],
  "headers": [],
  "body": {"id": "", "value": {"selected": "raw", "raw": "{}"}},
  "response": {"id": "", "active": true, "mapped_to": "api_output"}
}
```

**Key fields:** `verb` (get/post/put/patch/delete), `path.expression` (can use `f"/users/{data.user_id}"`), `body.value.raw` (request body referencing `data.*`), `response.mapped_to` (stores response as `data.<name>`).

**Terminology:** "CC" / "custom connection" / "custom HTTP" / "custom connector" all refer to `custom_connection_node`. For non-HTTP connections, the provider and resource differ but the CLI command is the same.

---

## Batch & Dataset Tips

## The `data` Object

Inside transform nodes and expression fields, `data` is a `Dict` (defined in the runner package) — a subclass of Python's built-in `dict` with attribute-style access.

**How it differs from a plain dict:**

| Feature | `dict` | `data` (`Dict`) |
|:---|:---|:---|
| Read via attribute | No (`AttributeError`) | Yes — `data.income` works |
| Read via key | `d["income"]` | `data["income"]` also works |
| Write via attribute | No | Yes — `data.score = 42` sets the key |
| `.get(key, default)` | Yes | Yes (inherited) |
| Nested dot access | No | Yes — `data.credit_report.score` auto-wraps nested dicts |
| Missing key error | `KeyError` | `KeyError` / `AttributeError` with typo suggestions in authoring mode |

Nested plain dicts and lists returned from lookups are automatically wrapped into `Dict`/`List` instances, so `data.response.items[0].name` works without manual wrapping.

**Prefer `data.foo` over `data["foo"]`** — attribute-style access is the idiomatic convention in Taktile flows. Use dict-style only when the key is dynamic (`data[variable]`) or contains characters invalid in identifiers (spaces, hyphens).

```python
# Good
data.age = app_date.year - dob.year
if data.income < params.min_income:
    data.decision = "Reject"
score = data.credit_report.bureau_score

# Avoid (unless key is dynamic or non-identifier)
data["age"] = app_date.year - dob.year
if data["income"] < params.min_income:
    data["decision"] = "Reject"
```

- Downloaded datasets wrap rows as `{"request": {"data": {...}}}` — CLI unwraps automatically.
- First download triggers an async job (a few seconds). Subsequent runs use ETag cache.
- Clear cache: `rm -rf ~/.tktl/cache/datasets/`
- **Schema-first workflow**: Use `--from-schema` when creating test datasets — ensures columns match flow inputs.
- Use `--concurrency 5` on dev for reliability. Higher values can produce empty responses.

| Concurrency | ~Duration (420 rows) |
|:---:|:---:|
| 5 | 5–10s |
| 10 | 3–7s |
| 20 | 1.5–3s |

---

## Tips for Large Flows

- **Use `--config @file.json` for complex nodes** — inline JSON in shell args gets mangled.
- **Always handle missing fields** — `data.get("field", default)` not `data.field`. Batch inputs may omit fields that single-test inputs include.
- **Test with real batch data early** — single-test inputs often have all fields; datasets may not.
- **More rules ≠ better performance** — extra penalty rules push borderline-good records into rejection. Model the minimum necessary logic.
- **Group related nodes** when the flow has 6+ logic nodes (see below).

---

## Node Groups

Node groups are visual containers that organize the canvas without affecting execution.
Use them when flows grow beyond 5–6 logic nodes.

### CLI Reference

```bash
# List groups
tktl groups list <slug> <version>

# Create a group
tktl groups create <slug> <version> --name "Scoring" --node-ids <id1>,<id2>

# Describe a group
tktl groups describe <slug> <version> <group_id>

# Update name or members
tktl groups update <slug> <version> <group_id> --name "New Name"
tktl groups update <slug> <version> <group_id> --node-ids <id1>,<id2>,<id3>

# Add/remove nodes
tktl groups add-nodes <slug> <version> <group_id> --node-ids <id3>
tktl groups remove-nodes <slug> <version> <group_id> --node-ids <id2>

# Delete a group (keeps the nodes)
tktl groups delete <slug> <version> <group_id>

# Add a node directly into a group
tktl nodes add <slug> <version> --type transform --name "X" \
  --after <id> --src '...' --group <group_id>
```

### Grouping Heuristics

Apply these in priority order when organizing a flow:

| Priority | Heuristic | Group name | Contents |
|---|---|---|---|
| 1 | Gate / Knockout cluster | "Eligibility Checks" | Rule + assignment nodes before the first split |
| 2 | Scoring cluster | "Scoring" | Scorecard, score transforms, score→tier mapping |
| 3 | Data enrichment cluster | "Data Enrichment" | Connection nodes + response transforms |
| 4 | Decision / Output mapping | "Decision" | Final assignments mapping tier→output fields |
| 5 | Stacked same-type nodes | Descriptive name | 3+ consecutive nodes of the same type |
| 6 | Semantic similarity | Descriptive name | Nodes reading/writing the same field cluster |

**Rules:**
- Only group when the flow has 6+ logic nodes (exclude input, output, merge, branch)
- Each group must have 2+ nodes — no single-node groups
- A node belongs to at most one group
- Don't group input, output, split, or merge nodes
- Name groups after their *purpose*, not their node types

### Rendering

Groups appear as subgraphs in Mermaid diagrams and cluster boxes in Graphviz PNGs.
When rendering with `tktl versions describe <slug> <version> --preview`, groups are
automatically shown as dashed containers.

---

## Chrome UI Navigation

When `mcp__claude-in-chrome__*` tools are available. **Read and navigate only — never edit via Chrome.**

```python
from tktl.config import Config, derive_app_url
from tktl.ops.render import build_flow_url

cfg = Config(); cfg.load()
app_url = derive_app_url(cfg.get("flow_api_url"))
url = build_flow_url(app_url, cfg.get("org"), cfg.get("workspace"), flow_id, version_id)
```

| `flow_api_url` contains | `app_url` |
|---|---|
| `dev.cp.taktile.com` | `app.dev.taktile.com` |
| `stg.cp.taktile.com` | `app.stg.taktile.com` |
| `cp.taktile.com` (prod) | `app.taktile.com` |

**URL pattern:** `{app_url}/decide/org/{org_id}/ws/{ws_id}/flow/{flow_id}/version/{version_id}`

| Pane | Query params |
|---|---|
| Input schema | `?left-pane=schema&schema=input` |
| Output schema | `?left-pane=schema&schema=output` |
| Datasets | `?left-pane=datasets` |
| Decision history | `?left-pane=decision-history` |
| Specific run | `?left-pane=decision-history&decision-id={id}` |
| Node logic | `?node={node_id}&right-pane-tab=logic` |

Rules: always `/flow/` (singular), always include `/version/{id}`.

`build_flow_url()` accepts kwargs: `node_id`, `right_pane_tab`, `left_pane`, `decision_id`, `power_tools`.

**When to open the UI:**
- After flow creation → navigate Chrome to the flow URL
- Debugging a node → navigate to `?node={node_id}&right-pane-tab=logic`
- Inspecting schema/params → `?left-pane=schema`
- Reviewing a run → `?left-pane=decision-history&decision-id={id}`

**Opening a node by name (when node_id is unknown):**
Use `tktl nodes list <slug> <version>` to find the node_id, then navigate via URL — never use JavaScript or click the canvas.

**Opening local files (Mermaid PNGs):**
Do NOT use Chrome navigate for `file://` paths — Chrome MCP prepends `https://` and mangles them.
Use `Bash: open {png_path}` instead, which opens the file in macOS Preview.

---

## Lessons Learned

### Graph replacement via PATCH
When you need to replace an entire version's graph (remove all nodes and start fresh), use a direct PATCH with null-delete semantics rather than `nodes remove` one by one. Build a patch body that sets unwanted nodes/edges to `null` and adds a direct input→output edge.

```python
from tktl.api.client import TktlClient
from tktl.api.versions import get_version, patch_version, normalize_graph_response

client = TktlClient()
raw = get_version(client, version_id)
etag = raw['etag']

patch_nodes, patch_edges = {}, {}
for nid, node in raw['graph']['nodes'].items():
    if node['type'] not in ('input', 'output'):
        patch_nodes[nid] = None
for eid in raw['graph']['edges']:
    patch_edges[eid] = None

# Add direct input→output edge
import uuid
new_eid = str(uuid.uuid4())
patch_edges[new_eid] = {'id': new_eid, 'start_node_id': input_id, 'end_node_id': output_id, 'meta': {'is_split_edge': False}}

result = patch_version(client, version_id, {'graph': {'nodes': patch_nodes, 'edges': patch_edges}}, if_match=etag)
```

### Boolean inputs
Taktile's input schema validation does not support `{"type": "boolean"}`. Use `{"type": "integer", "enum": [0, 1]}` instead. Python's `1 == True` evaluates correctly in scorecard predicates.

### Mermaid rendering
Avoid commas and special characters (`&`, `<`, `>`) in Mermaid node labels — they break the Graphviz DOT parser. Use simple labels with type + name only.

### Node names with special characters
The CLI now HTML-escapes node names for Graphviz rendering, so names like "Compute Tier & Offer" work correctly in preview PNGs.

### Inline JSON booleans
When using `-i` / `--input` for flow runs, boolean values may be stringified. Use `-f` with a JSON file instead to preserve types correctly.
