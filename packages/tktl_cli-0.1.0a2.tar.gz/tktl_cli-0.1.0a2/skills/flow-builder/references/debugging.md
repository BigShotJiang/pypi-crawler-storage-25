# debugging.md — Diagnosing Flow Failures

How to find the real error when the CLI surface is unhelpful.

---

## 1. Execution errors: get the full detail

The CLI's `tktl flows run` now surfaces the execution engine's error message directly. If a flow returns a `TktlError`, the message includes the engine's `exc_type`, `msg`, and `node_id`.

For deeper inspection, call the decide endpoint directly:

```python
import json, httpx
from tktl.api.client import TktlClient
import subprocess

config = json.loads(subprocess.check_output(["tktl", "config", "list"]))
client = TktlClient(base_url=config["flow_api_url"])

decide_url = "<workspace decide base URL>"  # from tktl flows describe <slug>
resp = httpx.post(
    f"{decide_url}/run/api/v1/flows/<slug>/sandbox/decide",
    json={"metadata": {}, "data": {"field": "value"}},
    headers={"X-Api-Key": client._api_key},
    timeout=30,
)
print(resp.status_code)
print(json.dumps(resp.json().get("detail", resp.json()), indent=2))
```

The workspace decide URL is in the format `https://<tenant>.stg-decide.taktile.com` and can be found in the flow's `decision_url` from a previous execution.

---

## 2. Interpreting execution error types

| `exc_type` | Meaning | Common cause |
|---|---|---|
| `compile` | Flow graph can't be loaded by the engine | UUID validation failure in node meta |
| `runtime` | Flow ran but a node raised an error | `AttributeError` in transform, output schema mismatch |
| `validation` | Input or output schema check failed | Missing required field, wrong type, null where string expected |

The `node_id` in the error tells you which node failed. Use `tktl nodes describe <slug> <ver> <node_id>` to inspect it.

---

## 3. Empty input schema: `runtime` AttributeError on first real node

If you see `AttributeError: Attribute: 'field_name' not found in the 'data' object`
at a node early in the flow, the input schema is likely empty (`{}`).

An empty input schema means no input fields are mapped to the `data` object.
Even if the decide request includes the field, it won't be available at runtime.

**Fix:** Set the input schema (JSON Schema format with `properties` wrapper):
```bash
tktl update apply <slug> <ver> --schema-in '{"type": "object", "properties": {"field_name": {"type": "number"}}}'
```

---

## 4. UUID validation: `compile` error on scorecard/rule nodes

If you see `compile` errors like `value is not a valid uuid`, a node's meta contains short string IDs instead of UUID4 values. This is now prevented by the CLI (short IDs are auto-replaced), but can still happen if you construct and PATCH node meta directly.

**Fix:** Pass `""` (empty string) for every `id`, `id_left`, `id_right` field — the CLI fills them automatically.

---

## 5. Output schema mismatch: `runtime` or `validation` error at output node

Common pattern: a field is `None` on one branch but the schema declares it as `{"type": "string"}`.

**Fix:** Use `anyOf` for any field that can be null:
```json
{"anyOf": [{"type": "string"}, {"type": "null"}]}
```

---

## 6. ConflictError on `update apply`

The CLI now raises immediately on 422 validation errors (instead of retrying 3 times). If you still see a ConflictError:

- **`[validation] ...`** — node config is invalid. Read the message; it names the failing field.
- **`ETag mismatch`** — a concurrent write happened between your fetch and PATCH. Run the command again; the retry loop re-fetches.
- **`locked`** — another session holds a lock on the node. Use `--force` to break the lock.
- **`modified N times during update`** — genuine concurrent write storm. Try again; if persistent, reduce concurrency.

---

## 7. Split routing silently wrong

If a `split` node routes everything to the same branch, the clause comparison may be broken:

- **Boolean comparison:** `data.eligible == False` requires that `eligible` is a Python `bool`. If an upstream node set it as the string `"False"`, the comparison fails. Use `is_none`/`is_not_none` operators for None checks, or set a string flag explicitly and compare with `eq "False"`.
- **Numeric comparison:** Ensure the upstream node sets the field as a number, not a string (`data.score = float(...)` not `data.score = str(...)`).

**To inspect what a node is actually setting:** add a temporary `transform` after it with `data.debug_score = type(data.score).__name__` and run a single decision.

---

## 8. Graph structure errors

**"Graph not fully connected" (409):** Happens when a manual PATCH sends only a subset of nodes. The API requires all nodes in the graph body. Use `tktl nodes remove` for removals — it handles rewiring. For manual PATCH, always fetch the full version and send all nodes with only the target modified.

**"Merge node missing":** A split node's merge node was removed independently. Use `tktl nodes remove <split_id>` instead of removing individual branch nodes — it cleans up all three (Branch 1, Default Branch, Merge Node).

---

## 9. Cache staleness

If `tktl nodes list` shows stale data after a modification:

```bash
tktl cache clear
```

After rapid sequential updates, the local cache may lag behind the server. Clear and re-fetch.

---

## 10. Org vs workspace: flow not found

If a flow ID returns 404, check whether the CLI is configured with the right org:

```bash
tktl config list   # check org and workspace
tktl config set org <org-id>
tktl flows list    # verify the flow appears
```

Flows live under a specific org. Changing workspace alone won't help if the org is wrong.
