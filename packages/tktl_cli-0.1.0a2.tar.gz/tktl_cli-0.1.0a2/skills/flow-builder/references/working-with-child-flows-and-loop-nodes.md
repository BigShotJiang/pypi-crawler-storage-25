# Working with Child Flows (Subflows) and Loop Nodes

## Overview

Parent flows can contain **flow nodes** (`type: "flow"`) that delegate execution to a
child flow. The parent's graph defines input/output mappings; the child flow runs
independently with its own graph, schemas, and version lifecycle.

Loop nodes (`type: "flow_loop"`) are similar but execute the child flow once per item
in a list.

## How Child Flows Work

When the CLI pushes a flow containing `type: "flow"` nodes:

1. `_upsert_child_flows()` finds or creates each child flow by `child_flow_slug`
2. The node meta is updated with the target workspace's IDs:
   - `child_flow_id` — the child flow UUID
   - `child_flow_version_id` — the child flow version UUID
   - `child_flow_version_known_etag` — the child version's current etag
3. The parent graph is PATCHed with the resolved references

### Input/Output Mappings

Each flow node has `input_mappings` and `output_mappings` in its meta:

```json
{
  "input_mappings": {
    "<uuid>": {
      "id": "<uuid>",
      "source": "data.company_id",
      "destination": "company_id"
    }
  },
  "output_mappings": {
    "<uuid>": {
      "id": "<uuid>",
      "source": "enrichment_result",
      "destination": "company_data"
    }
  }
}
```

- **source** in input_mappings: a field from the parent's data namespace
- **destination** in input_mappings: a field in the child flow's input schema
- **source** in output_mappings: a field from the child flow's output
- **destination** in output_mappings: a field written back into the parent's data namespace

## The "Update to ... — Review changes and remap fields" Error

This UI banner appears when a child flow node is **stale** (`is_stale: true`). The
API computes staleness server-side by comparing the child flow version's state against
what the parent node last acknowledged.

### Root Cause

The `child_flow_version_known_etag` in the parent node must match the child flow
version's actual `etag`. If they diverge, the UI shows the "review changes" banner
for that subflow node.

Common causes:
- **Child flow was modified** after the parent was configured (legitimate staleness)
- **CLI bug (fixed):** `_upsert_child_flows` previously hardcoded `known_etag` as
  `"00000001"`, but newly created child flow versions start at `"00000000"`

### How to Fix

**Option A: Re-push the parent flow via CLI**

```bash
tktl update apply <slug> <version> --file <body.json>
```

This re-runs `_upsert_child_flows`, which fetches the actual child etag and sets
`known_etag` correctly.

**Option B: Fix via the UI**

Click the "Review changes and remap fields" banner on each affected subflow node.
The UI will show the current mappings and let you confirm them, which updates the
`known_etag` to the child's current value.

**Option C: Fix via API**

1. Fetch each child flow version's current etag:
   ```
   GET /api/v2/flow_versions/{child_version_id}
   ```
2. Fetch the parent version graph (v2 format gives dict-keyed nodes):
   ```
   GET /api/v2/flow_versions/{parent_version_id}
   ```
3. Update each flow node's `meta.child_flow_version_known_etag` to match
4. PATCH the parent version with the full graph (all nodes + edges as dicts):
   ```
   PATCH /api/v1/flow_versions/{parent_version_id}
   Headers: if-match: {parent_etag}, session: {any-string}
   Body: {"graph": {"nodes": {...}, "edges": {...}, "node_groups": {...}}}
   ```

**Important:** The PATCH requires ALL nodes/edges in the graph body (not just the
modified ones). Sending partial nodes causes "graph not fully connected" errors.

## API Details

### Flow Node Meta Fields

| Field | Type | Description |
|:---|:---|:---|
| `child_flow_id` | UUID | The child flow's ID on this workspace |
| `child_flow_slug` | string | The child flow's slug |
| `child_flow_version_id` | UUID | The specific child version referenced |
| `child_flow_version_known_etag` | string | Last-acknowledged etag of the child version |
| `is_stale` | bool | **Read-only, server-computed.** True when child has changed |
| `input_mappings` | dict | Parent field → child input field mappings |
| `output_mappings` | dict | Child output field → parent field mappings |

### Flow Loop Node Meta (additional fields)

| Field | Type | Description |
|:---|:---|:---|
| `target_list_expression` | object | Expression producing the list to iterate over |
| `output_destination_list_expression` | object | Where to collect results |
| `break_condition` | object | Optional early-exit condition |

### Child Flow Version Requirements

For the UI to work cleanly, child flow versions **must** have:
- `input_schema` with properties matching the `input_mappings` destination fields
- `output_schema` with properties matching the `output_mappings` source fields

Without these schemas, the UI shows **"To complete the configuration, inputs and
outputs need to be mapped"** even when the mappings are defined in the parent node.
The mappings reference field names that must exist in the child's schemas.

Setting schemas on a child version advances its etag, which will make the parent's
reference stale until re-acknowledged (re-push the parent or confirm in the UI).

## Cross-Workspace Flow Promotion

When pushing a flow exported from one workspace (e.g., prod) to another (e.g., staging):

1. Child flows are created fresh on the target workspace (etag `"00000000"`)
2. The CLI resolves IDs for the target workspace and sets `known_etag` to the
   child's actual current etag
3. Input/output mappings are preserved from the export — field names must exist
   in both environments
4. **Connection nodes** (`custom_connection_node`) reference workspace-specific
   `connection_id` values that won't exist on the target — these need manual
   remapping or removal

### Important: Child Flow Graphs Are NOT Included

The parent flow export (`normalized_body.json` or equivalent) only contains the
**parent's** graph with subflow node references and mappings. It does **not** include
the child flows' internal graphs. After pushing the parent, the child flows on the
target workspace are empty shells (just input + output nodes, no logic).

To replicate a full flow with working child flows:

1. **Export each child flow separately** from the source workspace. You can do this
   via the Taktile UI (flow version → export) or the API:
   ```
   GET /api/v2/flow_versions/{child_version_id}
   ```
   Save the response JSON for each child flow.

2. **Push the parent flow first** — this creates the empty child flows on the target:
   ```bash
   tktl update apply <parent_slug> <version> --file parent_body.json
   ```

3. **Push each child flow graph** using the exported JSON:
   ```bash
   tktl update apply <child_slug> v1.0 --file /path/to/child_export.json
   ```

4. **Re-push the parent** to sync etags (child etags changed after graph push):
   ```bash
   tktl update apply <parent_slug> <version> --file parent_body.json
   ```

### Example: Promoting TomTest with 6 Country Subflows

```bash
# 1. Push parent (creates empty child flows)
tktl update apply tomtest v1.0 --file normalized_body.json

# 2. Push each child flow's graph
tktl update apply data-germany v1.0 --file /tmp/germany.json
tktl update apply data-usa     v1.0 --file /tmp/usa.json
tktl update apply data-spain   v1.0 --file /tmp/spain.json
tktl update apply data-uk      v1.0 --file /tmp/uk.json
tktl update apply data-france  v1.0 --file /tmp/france.json
tktl update apply data-italy   v1.0 --file /tmp/italy.json

# 3. Re-push parent to sync etags
tktl update apply tomtest v1.0 --file normalized_body.json
```

Without step 2, the child flows are empty and the UI shows "To complete the
configuration, inputs and outputs need to be mapped" on each subflow node.

## Testing Flows with Subflows (mock_data API)

The decide API accepts a `mock_data` field in the request body. This lets you
mock subflow outputs and individual connection nodes at execution time — no
graph modifications or separate test versions needed.

### Request Format

```json
{
  "data": { ... },
  "mock_data": {
    "<node_id>": { "field": "value" }
  },
  "metadata": { "version": "v1.0" },
  "control": { "execution_mode": "sync" }
}
```

### Strategy 1: Mock an Entire Subflow

Key format: `{subflow_node_id}`

The engine skips child flow execution entirely and returns the mock data as the
subflow's output. Use this to test the parent flow's routing, merging, and
business logic without depending on child flow internals or external APIs.

```python
# Find the subflow node ID from the parent graph
# (it's the node with type="flow" and meta.child_flow_slug="data-germany")

result = run_flow(
    client, workspace_id, "parent-flow",
    input_data={"company_id": "test-123", ...},
    version="v1.0",
    env="sandbox",
    mock_data={
        "<subflow-node-uuid>": {
            "data_enrichment_results": {
                "company_name": "Mock GmbH",
                "risk_score": 42,
            }
        }
    },
)
```

### Strategy 2: Mock Connection Nodes Inside a Child Flow

Key format: `{subflow_node_id}__{child_connection_node_id}`

The double-underscore separator tells the engine to execute the child flow
normally but intercept specific connection nodes with mock data. This tests
the child flow's internal logic (rules, transforms, splits) while mocking
only the external API calls.

```python
# subflow_node_id: the flow node in the parent graph
# child_cc_node_id: a custom_connection_node inside the child flow

result = run_flow(
    client, workspace_id, "parent-flow",
    input_data={"company_id": "test-123", ...},
    version="v1.0",
    env="sandbox",
    mock_data={
        f"{subflow_node_id}__{child_cc_node_id}": {
            "sample_report": "mocked_response",
        }
    },
)
```

### Finding Node IDs

Use the CLI to find the node IDs you need:

```bash
# Parent graph — find subflow node IDs
tktl nodes list <parent_slug> <version>
# Look for nodes with type="flow"

# Child graph — find connection node IDs
tktl nodes list <child_slug> <version>
# Look for custom_connection_node, webhook_connection_node, etc.
```

Or via the API:
```
GET /api/v2/flow_versions/{version_id}
```

### Sandbox Mock Config on Connection Nodes

Connection nodes also have a per-node `sandbox_mode_data_source` setting in
their config (`meta.config.environments_config.sandbox_mode_data_source`).
When set to `"mock_data"`, the node uses cached responses in sandbox mode
automatically, without needing to pass `mock_data` in the decide request.

### Integration Tests

See `tests/test_integration/test_subflow_mocking.py` for working examples of
both strategies against the TomTest flow on staging.
