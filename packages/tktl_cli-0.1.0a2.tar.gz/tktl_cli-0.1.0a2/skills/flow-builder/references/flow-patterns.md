# flow-patterns.md — Reusable Decision Flow Patterns

Domain-agnostic flow design patterns. Each pattern names the node sequence, what it's good for, and the key wiring decisions. Pick the pattern that fits your domain, then fill in the domain logic.

---

## Pattern 1: Linear enrichment

**Shape:** `input → transform* → assignment → output`

**Use when:** Every record follows the same path. No branching. Simple computations that enrich the input with derived fields, then assign a result.

**Typical nodes:**
1. `transform` — compute derived values (ratios, aggregations, normalise units)
2. `assignment` — set the output decision fields

**Example domains:** Simple eligibility score, price calculation, basic data enrichment.

---

## Pattern 2: Gated pipeline

**Shape:** `input → rule → split → [decline assignment | eligible path → ...] → merge → output`

**Use when:** A set of hard-stop criteria must be evaluated before any further processing. Records that fail go straight to a decline; those that pass continue.

**Key decisions:**
- Put all hard stops in a single `rule` node (one branch = "meets all criteria"). The default fires when any criterion fails.
- The `rule` sets a flag field (e.g. `eligible = True/False`) and a reason field.
- The `split` routes on that flag: `data.eligible == False` → decline branch.
- **Boolean comparison:** pass `False`/`True` unquoted in the clause — they evaluate as Python booleans, not strings.
- The decline `assignment` sets the output decision and nulls any fields that only apply to the approved path.

**Typical nodes:**
1. `rule` — hard stops (minimum tenure, threshold checks, etc.)
2. `split` — `data.eligible == False`
3. `assignment` (Branch 1) — DECLINED + reason
4. `[eligible path nodes]` (Default Branch)
5. `assignment` (end of eligible path) — APPROVED + offer details

---

## Pattern 3: Scored pipeline

**Shape:** `input → [eligibility gate] → scorecard → transform → assignment → output`

**Use when:** The decision depends on a weighted multi-factor risk or quality score. The score then drives the offer or outcome.

**Key decisions:**
- Use a `scorecard` for the weighted scoring. Calibrate factor scores to 0–100 per factor if you want the total to also be 0–100 (with `equal_weights: true`, the total is the average of factors).
- Use a `transform` for offer sizing or any arithmetic that depends on the score.
- Use an `assignment` to set the final decision fields based on the score tiers.

**Typical nodes:**
1. `rule` + `split` — optional gate (see Pattern 2)
2. `scorecard` — produces a score field (e.g. `risk_score`)
3. `transform` — computes offer amount, rate, term using score thresholds
4. `assignment` — sets `decision = "APPROVED"` and clears `decline_reason`

---

## Pattern 4: Lookup-driven decision

**Shape:** `input → transform* → decision_table → assignment → output`

**Use when:** The decision maps discrete input combinations to discrete outputs. Think pricing grids, risk tier lookups, or fee schedules.

**Key decisions:**
- Use a `transform` to normalise inputs into the bucket labels the table expects (e.g. `"high"`, `"medium"`, `"low"`).
- Use a `decision_table` for the multi-predicate → multi-effect mapping.
- Fall back to safe defaults; the fallback in a decision table fires when no case matches.

**Typical nodes:**
1. `transform` — bucket continuous values into categories
2. `decision_table` — maps input categories to output values
3. `assignment` — sets final decision fields

---

## Pattern 5: Two-dimensional rate/tier lookup

**Shape:** `input → transform* → matrix_table → assignment → output`

**Use when:** The output depends on exactly two input dimensions (e.g. risk tier × loan term → interest rate). A `matrix_table` is more readable and maintainable than a decision table for 2D grids.

**Key decisions:**
- Normalise both dimensions to discrete labels in a `transform` before the matrix.
- The matrix's `result_field` must start with `data.`.

---

## Pattern 6: Multi-stage pipeline

**Shape:** `input → gate → [enrich → score → size → decide] → output`

**Use when:** The flow has multiple sequential decision stages (e.g. eligibility check → risk scoring → offer generation → final decision).

**Key decisions:**
- Each stage can be a sub-graph of the patterns above.
- Pass data forward by writing to named fields on the `data` object — every node reads from and writes to the same namespace.
- Keep each node's responsibility narrow. A `scorecard` scores; a `transform` calculates offers; an `assignment` stamps the final decision. Don't collapse multiple concerns into one transform.

---

## Choosing between node types

| Question | Node to use |
|---|---|
| "Set this field to a fixed value or expression" | `assignment` |
| "If condition A, set X; else set Y" | `rule` |
| "Route to different paths based on a flag" | `split` |
| "Score based on multiple weighted factors" | `scorecard` |
| "Map input combinations to outputs" | `decision_table` |
| "Two-dimension grid lookup" | `matrix_table` |
| "Compute derived values (math, string ops, loops)" | `transform` |

Prefer declarative node types (`rule`, `scorecard`, `decision_table`) over `transform`. Transforms are opaque — they can't be visualised or audited as cleanly as structured node types.

---

## Output schema

Always set an output schema. Without it, the decision response returns an empty `data: {}` object.

```bash
tktl update apply <slug> <ver> --schema-out '{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "type": "object",
  "properties": {
    "decision":      {"type": "string", "enum": ["APPROVED", "DECLINED"]},
    "approved_amount": {"anyOf": [{"type": "number"}, {"type": "null"}]},
    "decline_reason":  {"anyOf": [{"type": "string"}, {"type": "null"}]}
  }
}'
```

**Use `anyOf` for nullable fields.** If a field can be `None` (e.g. `approved_amount` on a decline), declare it as `{"anyOf": [{"type": "number"}, {"type": "null"}]}`. A strict `{"type": "number"}` will cause a 409 validation error at execution time when the field is null.
