# node-configs.md — Node Type Reference

Complete configuration reference for every node type. Use this when building or modifying a flow graph.

---

## Common rules that apply to all node types

**IDs must be UUIDs or empty strings.** Every `id`, `id_left`, `id_right` field inside node meta must be a valid UUID4. Pass `""` (empty string) for new objects — the CLI auto-fills them. Do NOT use readable short IDs like `"f1"` or `"ce1"`; they are accepted by the API but rejected by the execution engine at runtime.

**Operators.** Valid comparison operators across all node types:
`lt`, `le`, `eq`, `ne`, `ge`, `gt`, `is_in`, `not_is_in`, `is_none`, `is_not_none`, `contains`, `does_not_contain`, `matches_regex`.
The aliases `gte` and `lte` do NOT exist and will return a 422.

**Assignment targets are bare names.** Use `"target": "risk_score"`, not `"target": "data.risk_score"`. Values are Python expressions: `"'approved'"` for strings, `"42"` for numbers, `"data.x + 1"` for computed, `"None"` to null a field.

---

## transform

Inline Python code. `data` is a mutable namespace — assign fields directly.

```bash
tktl nodes add <slug> <ver> --type transform --name "Score" \
  --after <id> \
  --src 'data.score = round(data.income / 1000, 1)'
```

For multi-line logic, write to a file and use `--src @scorer.py`.

**Gotcha:** `data.field` raises `AttributeError` if the field is absent. Use `data.get("field", default)` in transforms, or ensure upstream nodes always set the field.

---

## assignment

Sets named fields to fixed values or simple expressions. Prefer over transform for any logic that's just "set X to Y".

```bash
tktl nodes add <slug> <ver> --type assignment --name "Set Decision" --after <id>
```

Then configure via `update apply`:
```bash
tktl update apply <slug> <ver> --node <id> --node-config '{
  "default_effects": [
    {"id": "", "target": "decision",      "value": "\"APPROVED\""},
    {"id": "", "target": "decline_reason","value": "None"}
  ]
}'
```

---

## rule (alias: rule_2)

Conditional branches — each branch has clauses (conditions) and effects (field assignments). If no branch matches, `default_effects` fire.

**Critical constraint:** Every field set in `default_effects` must also appear in every `branch.effects`. The API enforces this; mismatches return a 409.

```bash
tktl nodes add <slug> <ver> --type rule --name "Eligibility" --after <id>
```

Configure:
```bash
tktl update apply <slug> <ver> --node <id> --node-config '{
  "default_effects": [
    {"id": "", "target": "eligible",      "value": "False"},
    {"id": "", "target": "decline_reason","value": "\"Ineligible\""}
  ],
  "branches": [{
    "id": "",
    "name": "Passes all checks",
    "junction": "and",
    "clauses": [
      {"id_left":"","id_right":"","left":"data.months_active","right":"6","operator":"ge"},
      {"id_left":"","id_right":"","left":"data.refund_rate",  "right":"0.1","operator":"le"}
    ],
    "effects": [
      {"id": "", "target": "eligible",      "value": "True"},
      {"id": "", "target": "decline_reason","value": "None"}
    ]
  }]
}'
```

---

## split (alias: split_2)

Routes execution into two branches. Creates Branch 1, Default Branch, and Merge Node automatically.

```bash
tktl nodes add <slug> <ver> --type split --name "Decision Gate" \
  --after <id> \
  --clause "data.score < 30"
```

**Clause parsing rules:**
- Numeric values are unquoted: `data.score < 30` → `right: "30"`
- Python literals `True`, `False`, `None` are unquoted and evaluate as their native types: `data.eligible == False` → `right: "False"` (boolean, not string)
- Everything else is auto-quoted as a string: `data.status == APPROVED` → `right: '"APPROVED"'`

To update the clause after creation:
```bash
tktl update apply <slug> <ver> --node <split_id> --node-config '{
  "branches": [
    {
      "id": "<existing-branch-id>",
      "junction": "and",
      "clauses": [{"id_left":"<existing>","id_right":"<existing>","left":"data.score","right":"50","operator":"lt"}],
      "edge_id": "<existing-edge-id>"
    },
    {"id": "<default-branch-id>", "junction": "and", "clauses": [], "edge_id": "<default-edge-id>"}
  ],
  "default_edge_id": "<default-edge-id>"
}'
```
You must preserve the existing branch `id` and `edge_id` values when updating a split — fetch them first with `nodes describe`.

**To add logic on a split branch:** `nodes add` with `--after <Branch 1 node id>` or `--after <Default Branch node id>`.

---

## scorecard

Weighted multi-factor scoring. Each factor evaluates the input against ordered cases and assigns a score. The total is the average across factors (with `equal_weights: true`).

**Scoring calibration:** With `equal_weights: true`, the final score = average of factor scores. If each factor's cases score 0–100, the total is also 0–100. If factors have different max scores, calibrate downstream thresholds accordingly.

```bash
tktl nodes add <slug> <ver> --type scorecard --name "Risk Score" \
  --after <id> \
  --config '{
    "assign_field": {"id": "", "value": "risk_score"},
    "extract_scores": false,
    "equal_weights": true,
    "factors": [
      {
        "id": "", "name": "Factor Name",
        "input_field":  {"id": "", "value": "data.input_field"},
        "output_field": {"id": "", "value": "factor_score"},
        "weight":       {"id": "", "value": "1"},
        "fallback":     {"id": "", "value": "0"},
        "cases": [
          {"id":"","predicate":{"id":"","value":"100","operator":"ge"},"effect":{"id":"","value":"100"}},
          {"id":"","predicate":{"id":"","value":"50", "operator":"ge"},"effect":{"id":"","value":"60"}}
        ]
      }
    ]
  }'
```

Cases are evaluated top-to-bottom; the first match wins. The fallback fires if no case matches.

**Gotcha: PATCH updates.** The server validates `ScoreCardNodeMeta` strictly — all
four required fields (`assign_field`, `extract_scores`, `equal_weights`, `factors`)
must be present even though the CLI deep-merges your patch into existing meta. If
you need to fix a scorecard, prefer `nodes remove` + re-add, or edit via the UI.

---

## decision_table

Lookup table: set of predicate fields × effect fields, matched row by row.

```bash
tktl nodes add <slug> <ver> --type decision_table --name "Risk Lookup" \
  --after <id> \
  --config @table.json
```

```json
{
  "predicate_fields": [
    {"id": "p_score", "value": "data.credit_score"},
    {"id": "p_age",   "value": "data.account_age_months"}
  ],
  "effect_fields": [
    {"id": "e_tier",  "value": "data.risk_tier"},
    {"id": "e_limit", "value": "data.credit_limit"}
  ],
  "cases": [
    {
      "id": "", "name": "Prime",
      "predicates": {
        "p_score": {"id": "", "value": "700", "operator": "ge"},
        "p_age":   {"id": "", "value": "12",  "operator": "ge"}
      },
      "effects": {
        "e_tier":  {"id": "", "value": "'prime'"},
        "e_limit": {"id": "", "value": "25000"}
      }
    }
  ],
  "fallback": {
    "e_tier":  {"id": "", "value": "'subprime'"},
    "e_limit": {"id": "", "value": "5000"}
  }
}
```

Short field IDs like `"p_score"` are auto-converted to UUIDs by the CLI. Case predicate/effect dict keys must match the field IDs exactly.

---

## matrix_table

Two-dimensional lookup: row field × column field → result.

```bash
tktl nodes add <slug> <ver> --type matrix_table --name "Rate Matrix" \
  --after <id> \
  --config @matrix.json
```

```json
{
  "row_field":    {"id": "", "value": "data.risk_tier"},
  "column_field": {"id": "", "value": "data.loan_term"},
  "result_field": {"id": "", "value": "data.interest_rate"},
  "row_predicates": [
    {"id": "", "value": "\"prime\"",    "operator": "eq"},
    {"id": "", "value": "\"standard\"", "operator": "eq"},
    {"id": "", "value": "\"subprime\"", "operator": "eq"}
  ],
  "column_predicates": [
    {"id": "", "value": "\"12m\"", "operator": "eq"},
    {"id": "", "value": "\"24m\"", "operator": "eq"},
    {"id": "", "value": "\"36m\"", "operator": "eq"}
  ],
  "grid_effects": [
    [{"id":"","value":"\"3.9\""},  {"id":"","value":"\"4.5\""},  {"id":"","value":"\"5.0\""}],
    [{"id":"","value":"\"6.5\""},  {"id":"","value":"\"7.2\""},  {"id":"","value":"\"8.0\""}],
    [{"id":"","value":"\"11.0\""}, {"id":"","value":"\"12.5\""}, {"id":"","value":"\"14.0\""}]
  ],
  "fallback": {"id": "", "value": "\"15.0\""}
}
```

`result_field.value` must start with `data.`. Grid is rows × columns; rows and columns are indexed in the same order as their predicates.
