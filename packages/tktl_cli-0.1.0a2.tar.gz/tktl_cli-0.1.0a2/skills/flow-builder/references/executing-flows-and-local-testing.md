# Executing Flows and Local Testing

## Running a Flow

Execute a flow via the workspace Decide API:

```bash
tktl flows run <slug> --input '{"key": "value"}' --version v1.0
```

### Options

| Flag | Short | Description |
|:---|:---|:---|
| `--file` | `-f` | Path to input JSON file |
| `--input` | `-i` | Inline JSON input |
| `--version` | `-v` | Version name (default: published) |
| `--env` | `-e` | Environment: `sandbox` or `live` |
| `--mock-data` | `-m` | Mock data JSON (inline or `@file`) |
| `--async` | | Use async execution mode (polls for result) |
| `--timeout` | `-t` | Async poll timeout in seconds (default: 60) |
| `--output` | `-o` | Output format: `auto`, `json`, `table` |

### Input via File

```bash
tktl flows run my-flow -f input.json -v v1.0
```

### Inline Input

```bash
tktl flows run my-flow -i '{"company_id": "test-123", "revenue": 5000000}'
```

## Sync vs Async Execution

### Sync (default)

The CLI sends the request and waits for the response. Suitable for flows
without webhook or review connection nodes.

```bash
tktl flows run my-flow -i '{"id": "123"}' -v v1.0
```

### Async

For flows containing webhook nodes, review nodes, or other async-only node
types, use `--async`. The CLI submits the request, then polls
`GET /{flow_slug}/{env}/decide/{decision_id}` until the result is ready.

```bash
tktl flows run my-flow -i '{"id": "123"}' -v v1.0 --async -t 120
```

The `--timeout` flag controls how long to poll before giving up (default: 60s).

## Mocking Subflows and Connections

Use `--mock-data` to mock node outputs at execution time. This is essential
for testing parent flows whose child flows contain webhook or review nodes.

### Mock an Entire Subflow

Key: `{subflow_node_id}`

```bash
tktl flows run parent-flow -v v1.0 \
  -i '{"company_id": "test-123"}' \
  -m '{"<subflow-node-uuid>": {"enrichment": {"status": "ok"}}}'
```

### Mock Connection Nodes Inside a Child Flow

Key: `{subflow_node_id}__{child_connection_node_id}` (double underscore)

```bash
tktl flows run parent-flow -v v1.0 \
  -i '{"company_id": "test-123"}' \
  -m '{"<subflow-uuid>__<connection-uuid>": {"report": "mocked"}}'
```

### Mock Data from File

```bash
tktl flows run parent-flow -v v1.0 -i @input.json -m @mock.json
```

### Finding Node IDs

```bash
# Parent graph — find subflow nodes (type=flow)
tktl nodes list <parent_slug> <version> -o json | jq '.[] | select(.type=="flow")'

# Child graph — find connection nodes
tktl nodes list <child_slug> <version> -o json | jq '.[] | select(.type | test("connection"))'
```

## Integration Testing with pytest

Write integration tests that call the tktl-cli ops layer as a Python library.
This is faster than shelling out to the CLI (~3x) and gives native Python
dicts and exceptions instead of JSON parsing and exit codes.

### 1. Create a config directory

```bash
mkdir .tktl-local
```

Create `.tktl-local/config.json`:

```json
{
  "workspace": "<workspace-uuid>",
  "org": "<org-uuid>",
  "flow_api_url": "https://flow-api.stg.cp.taktile.com"
}
```

Create `.tktl-local/credentials.json` (mode 600):

```json
{
  "api_key": "<your-api-key>"
}
```

Or authenticate via the CLI:

```bash
TKTL_CONFIG_DIR=.tktl-local tktl auth login
```

Add `.tktl-local/` to `.gitignore` — it contains credentials.

### 2. Add session-scoped fixtures

In `tests/test_integration/conftest.py`:

```python
import os
from pathlib import Path

import pytest
from tktl.api.client import TktlClient
from tktl.config import Config


@pytest.fixture(scope="session")
def stg_client() -> TktlClient:
    config_dir = os.environ.get("TKTL_CONFIG_DIR")
    if not config_dir:
        pytest.skip("TKTL_CONFIG_DIR not set")
    return TktlClient(config_dir=Path(config_dir))


@pytest.fixture(scope="session")
def stg_workspace_id() -> str:
    config_dir = os.environ.get("TKTL_CONFIG_DIR")
    if not config_dir:
        pytest.skip("TKTL_CONFIG_DIR not set")
    cfg = Config(Path(config_dir))
    cfg.load()
    return cfg.get("workspace")
```

Using `scope="session"` means one HTTP client for the entire test run.

### 3. Write tests

```python
import pytest
from tktl.api.client import TktlClient
from tktl.ops.flows import run_flow

FLOW_SLUG = "my-flow"
VERSION = "v1.0"
MOCK_DATA = {
    "<subflow-node-uuid>": {"enrichment": {"status": "ok"}},
}

pytestmark = [pytest.mark.staging, pytest.mark.integration]


def test_happy_path(stg_client: TktlClient, stg_workspace_id: str) -> None:
    result = run_flow(
        stg_client,
        stg_workspace_id,
        FLOW_SLUG,
        {"company_id": "test-123", "revenue": 5_000_000},
        version=VERSION,
        mock_data=MOCK_DATA,
        execution_mode="async",
        poll_timeout=120.0,
    )
    assert result["status"] == "success"
    assert result["data"]["segment"] == "S"
```

Key points:
- `run_flow` handles boolean coercion (`True` → `"true"`) automatically
- `execution_mode="async"` + `poll_timeout` handles flows with webhook/review nodes
- `mock_data` replaces subflow outputs at execution time (see [Mocking Subflows](#mocking-subflows-and-connections))
- The result dict has the same shape as the CLI JSON output: `status`, `data`, `metadata`, `detail`

### 4. Run tests

```bash
TKTL_CONFIG_DIR=.tktl-local pytest tests/test_integration/ -m staging -v
```

Skip staging tests in CI or when no config is available:

```bash
pytest -m "not staging"
```

### 5. Finding mock node IDs

Use the CLI to discover which nodes to mock:

```bash
# Parent graph — find subflow nodes (type=flow)
tktl nodes list <parent_slug> <version> -o json | jq '.[] | select(.type=="flow")'

# Child graph — find connection nodes
tktl nodes list <child_slug> <version> -o json | jq '.[] | select(.type | test("connection"))'
```

See `tests/test_integration/test_tomtest_flow.py` for a full working example
with 33 tests covering revenue segmentation, country routing, and edge cases.

## Troubleshooting

### Compile Errors

If the response has `status: "error"` with `exc_type: "compile"`, the flow
graph has configuration issues. Common causes:

- **Webhook/review nodes in child flows**: Use `--async` mode, or mock the
  entire subflow with `--mock-data`
- **Broken node references**: Removing nodes in the UI can leave dangling
  references in downstream nodes (e.g., "Field empty or invalid value")
- **Stale subflow references**: Re-push the parent flow to sync child flow etags
- **Empty scorecard factors**: A scorecard node with `factors: []` causes
  "Sum of factor weights is not 100". Remove the node with
  `tktl nodes remove <slug> <ver> <node_id>` or add factors via the UI
  (the API's ScoreCardNodeMeta validation rejects partial PATCH updates)

### Runtime Errors

If `exc_type: "runtime"` with `AttributeError: Attribute '<field>' not found`:

- **Empty input schema**: The flow's `input_schema` must declare all fields.
  See [Input Schema Requirements](#input-schema-requirements)
- **Mock data shape**: When mocking subflows, ensure the mock output contains
  all fields that downstream nodes reference

See also [Debugging](debugging.md) for a full error reference.

## Input Schema Requirements

Flows with an empty `input_schema` (`{}`) will not propagate input fields to the
`data` object. Any downstream node referencing `data.<field>` will fail with
`AttributeError: Attribute: '<field>' not found in the 'data' object`.

**Fix:** Set the input schema with all fields your flow uses. The schema must
be valid JSON Schema with a `type: "object"` and `properties` wrapper:

```bash
tktl update apply my-flow v1.0 --schema-in '{
  "type": "object",
  "properties": {
    "company_id": {"type": "string"},
    "revenue": {"type": "number"},
    "country": {"type": "string"}
  }
}'
```

Or from a file:

```bash
tktl update apply my-flow v1.0 --schema-in @schema.json
```

**Common mistake:** Passing a flat dict like `{"field": {"type": "string"}}` without
the `properties` wrapper will be accepted by the API but won't map fields to the
`data` object at runtime.

## Environment Configuration

### TKTL_CONFIG_DIR

Override the config directory (default: `~/.tktl`):

```bash
export TKTL_CONFIG_DIR=.tktl-local
tktl flows run my-flow -i '{"id": "123"}'
```

The config directory has two files:

**`config.json`** — workspace and API endpoint:

```json
{
  "workspace": "<workspace-uuid>",
  "org": "<org-uuid>",
  "flow_api_url": "https://flow-api.stg.cp.taktile.com",
  "env": "sandbox"
}
```

**`credentials.json`** — API key (created by `tktl auth login`, mode 600):

```json
{
  "api_key": "<key>"
}
```

### Setting Environment Default

The `env` field in `config.json` sets the default environment. Override
per-request with `--env`:

```bash
tktl flows run my-flow -i '{"id": "123"}' --env live
```

## See Also

- [Working with Child Flows and Loop Nodes](working-with-child-flows-and-loop-nodes.md) — subflow mocking strategies, cross-workspace promotion
- [Debugging](debugging.md) — debugging flow execution issues
- [Node Configs](node-configs.md) — per-type node configuration
