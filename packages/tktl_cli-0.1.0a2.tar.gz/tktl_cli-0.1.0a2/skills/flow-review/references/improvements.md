# Improvement Findings

Observations from testing and iterating on decision flows with the tktl CLI.

## CLI Improvements

- [x] **`--version` flag was missing** — Added `tktl --version` / `-V`. Reads from package metadata.
- [ ] **Dataset-flow field mismatch is silent** — Batch summary reports `succeeded: 27` even when all rows return `status: "error"`. Should count flow-level errors as failures, or add a `--validate` flag to check dataset fields against input schema before running.
- [ ] **No accuracy comparison built into batch** — Add `tktl flows batch --expected-field <field> --actual-field <field>` to print accuracy stats, confusion matrix, and mismatched rows.
- [ ] **No `tktl nodes show` command** — `describe` exists but `show` (a common alias) does not. Add `show` as an alias.
- [ ] **Node lookup by name doesn't work** — `nodes describe` requires UUID. Support name-based lookup (fuzzy match) in addition to UUID.
- [ ] **Iterating on decision tables requires remove+add cycle** — Can't update cases in-place via `update apply --node-config`. Support `tktl update apply --node <id> --config @table.json` for decision tables.

## Documentation / Gotchas

- [x] **Decision table string tier comparison is unreliable** — `lt`/`ge` on strings does lexicographic comparison, not semantic tier ordering. Documented in skills/flow-builder/SKILL.md: use numeric predicates instead.
- [x] **Zero-income edge case** — Unemployed applicants with income=0 produce DTI=999, hitting deny rules before employment-based rules. Documented in skills/flow-builder/SKILL.md: order cases carefully.
- [x] **Batch error reporting gotcha** — `succeeded` count is misleading when flow execution errors. Documented in SKILL.md.

## Flow Design Insights

- [x] **Tuned loan-scorer-v1 to 100% accuracy** — v1: 81% (22/27) → v2: 96% (26/27) → v3: 100% (27/27). Key: numeric predicates + careful case ordering + tight credit thresholds.
