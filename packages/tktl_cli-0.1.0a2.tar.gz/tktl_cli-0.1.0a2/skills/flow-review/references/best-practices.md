---
description: Review a Taktile flow against the best practices checklist.
---

# Taktile Flow Good Practices Checklist

Reference document for reviewing decision flows. Each section lists what to check, why it matters, and what violations look like.

---

## How to Use

- Work through each numbered section when reviewing or building a Taktile flow.
- **Best Practices** describe the correct pattern to follow.
- **What to Flag** describes violations to raise in a review comment or fix before deployment.
- Add a new test case for every edge case or flag discovered during review.

---

## 1. Input Validation & Null Handling

All input fields used downstream should be null-safe. If any transform or connection node can produce `None`, every downstream reference must handle it.

**Best Practices**
- Guard every `data.X` reference where `X` comes from a connection, ML, or transform node.
- Add a preceding rule or transform to set a default/fallback before comparisons like `data.score > 500`.
- At the top of the flow, set defaults for all optional input fields.

**What to Flag**
- A rule/split clause references a field that could be null with no upstream null guard.
- A scorecard `input_field` references a connection response with no fallback.
- Optional input schema fields not guarded — check if the flow breaks when they are not provided.

---

## 2. Output Schema Completeness

Every field in the output schema must be assigned on every possible path, including early-exit branches.

**Best Practices**
- Verify all output fields are set on every path, including early rejections.
- Ensure type consistency: a field declared as `number` should never receive a `string` on any path.
- When output is only assigned on one branch, leave a comment asking whether to return `None` or make the field optional.

**What to Flag**
- A path exits the flow without assigning a declared output field.
- An assignment sets an output field to the wrong type.
- Output only assigned on one branch with no comment or fallback on other branches.

---

## 3. Node Structure & Organisation

Nodes should be structured for clarity, minimising unnecessary complexity in the graph.

**Best Practices**
- Combine split/assignment node pairs into a single rule node where possible.
- Extract custom connection response values in a dedicated assignment node rather than referencing them inline.
- Place the reject/false branch on the **left** branch of split nodes consistently.
- Group nodes that relate to the same decision logic check together.
- Knock-out rules should progress from wide criteria to granular.

**What to Flag**
- A split node followed immediately by an assignment that could be a single rule node.
- Connection response values referenced inline rather than extracted in an assignment node.
- Reject/false branch wired to the right side of a split.
- Logically related nodes scattered across the graph with no grouping.

---

## 4. Decision Table Completeness

Cases should be mutually exclusive or ordered correctly. Overlapping predicates with different effects are ambiguous.

**Best Practices**
- Ensure cases are mutually exclusive or deliberately ordered with the most specific first.
- Confirm all predicate fields are non-null before the table is reached.

**What to Flag**
- Predicate ranges that overlap across cases.
- Predicate field sourced from a connection/transform with no null guard.

---

## 5. Scorecard Robustness

Case ranges should cover the full expected domain. Gaps mean some values fall to the fallback unnecessarily.

**Best Practices**
- Ensure case ranges cover the full expected domain with no gaps.
- Document what the combined score represents.
- Ensure input fields for factors have upstream defaults if they could be null.

**What to Flag**
- Scorecard factor with `fallback = 0` when 0 is a meaningful score.
- Gaps in case predicate ranges.
- Input field for a factor that could be null with no upstream default.

---

## 6. Rule & Split Branch Coverage

Avoid unreachable branches. If a prior knockout guarantees a certain state, downstream branches checking for that state are dead code.

**Best Practices**
- Trace upstream logic to confirm all branch conditions are actually reachable.

**What to Flag**
- Branch conditions that can never be true given upstream knockout logic (dead code).

---

## 7. Knockout / Early Exit Patterns

Rejection reasons should accumulate, not overwrite. All early-exit paths must still set all output fields.

**Best Practices**
- Use `[new_reason] + data.rejection_reasons` to accumulate rejection reasons, never `[new_reason]` alone.
- Store decision/status in a dedicated field; store rejection reasons as a list.
- All early-exit paths must set all output fields.
- Update knockout aggregation nodes whenever a new knockout is added upstream.

**What to Flag**
- A knockout rule that overwrites `rejection_reasons` instead of appending.
- A knockout aggregation that misses a knockout status field.
- An early-exit path that skips output field assignment.
- Status/decision stored inline rather than in a dedicated field.

---

## 8. Connection Node Data Flow

Response mapping (`mapped_to`) should match downstream references exactly. Error handling config should match the flow's requirements.

**Best Practices**
- Verify `mapped_to` names match all downstream references exactly (no misspellings).
- Review error handling: `allow_4xx: false` will fail the entire decision on a 404 — consider a graceful fallback.
- Check `environments_config` to understand what data the sandbox uses.

**What to Flag**
- Downstream node references a field name that doesn't match the connection's `mapped_to`.
- Connection with `allow_4xx: false` and no null handling for the response.
- API keys hardcoded in connection config — use secrets instead.

---

## 9. Type Safety in Expressions

Wrong types in comparisons silently fail or produce unexpected results.

**Best Practices**
- Numeric comparisons must use numeric types, not string literals.
- Use consistent casing for string comparisons — they are case-sensitive.
- Use actual booleans (`True`/`False`) not string representations (`"True"`/`"False"`).
- Ensure `True`/`False` vs `true`/`false` matches what the expression engine expects.
- Date comparisons must use consistent formats.

**What to Flag**
- String literal in a comparison where the input schema declares a number.
- Case mismatch between a rule's expected value and likely input values (e.g. `"Student"` vs `"student"`).
- Boolean compared to a string: `data.flag == "False"` instead of `data.flag == False`.
- `True`/`False` used where `true`/`false` is required by the expression engine, or vice versa.

---

## 10. EMI / Financial Calculations

Division by zero, negative values, and float precision are common sources of silent errors in financial flows.

**Best Practices**
- Guard division by zero: DTI = `debt / income` requires an `income != 0` check upstream.
- Validate that loan amounts and income cannot be negative upstream.
- Use consistent precision; avoid floating-point boundary comparisons without tolerance.

**What to Flag**
- Division by a field that could be zero with no guard.
- No check for negative loan amounts or income.
- Floating-point boundary comparisons without tolerance.

---

## 11. Graph Structural Integrity

Every node should be reachable from the input node and every path should terminate at the output node.

**Best Practices**
- Verify every node is reachable from the input node (no orphaned nodes).
- Verify every path terminates at the output node (no dead ends).
- Confirm merge nodes after splits receive all branch edges.

**What to Flag**
- Node with no incoming edge (except the input node) — orphaned node.
- Node with no outgoing edge (except the output node) — dead-end path.
- Split with N branches but merge node only receives N-1 edges.

---

## 12. Input Schema Quality

Poorly-defined input schemas cause silent failures when actual data doesn't match expectations.

**Best Practices**
- Guard all optional fields against absence before use downstream.
- Nested schemas should use precise types (`string`, `integer`, `number`) not generic `object`.
- Validate that schema field types match the actual data structure used in tests.

**What to Flag**
- Optional input field used downstream with no null/absence guard.
- Nested schema field typed as `object` when it should be `string` or `int`.
- Input schema does not match actual payload structure in test cases.

---

## 13. Code Node Best Practices

Code nodes should be lean, secret-safe, and well-tested.

**Best Practices**
- Avoid API calls inside code nodes where possible — use connection nodes instead.
- Never expose API keys in node config; save them as secrets.
- Add a new test case every time a new edge case is discovered.

**What to Flag**
- API call made inside a code node that could instead be a connection node.
- API key or credential hardcoded in node configuration.
- Edge case discovered with no corresponding test case added.
