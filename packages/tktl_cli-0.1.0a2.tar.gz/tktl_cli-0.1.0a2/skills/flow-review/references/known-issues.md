# issues.md — CLI Pain Points from Building a Decision Flow

Recorded after building a merchant capital decision flow from scratch (TomTest flow, April 2026).
These are ordered by how much time each issue cost.

---

## 1. ConflictError masks the real failure (highest impact)

**What happened:** Every `tktl update apply --node-config` call returned:
```
ConflictError: Version "v1.0" has been modified 3 times during update -- giving up.
```

**Actual cause:** The API was returning `422 Unprocessable Entity` (invalid operators in rule clauses: `gte` instead of `ge`). The CLI caught the 422 as a `ConflictError`, then retried it 3 times, then overwrote the real error with the misleading "modified 3 times" message.

**Fixed in:** `api/versions.py` (422 prefix `[validation]`) + `ops/nodes.py` + `ops/versions.py` (re-raise immediately on `[validation]`).

---

## 2. Short ID strings silently break at runtime

**What happened:** Configured a scorecard with readable IDs (`"f1"`, `"af1"`, `"ce1"`). The `nodes add` and `update apply` commands accepted them without complaint. The flow only failed when actually executed:
```
value is not a valid uuid (type=type_error.uuid) at nodes -> 7 -> ScoreCardNode -> meta -> assign_field -> id
```

**Root cause:** `_fill_ids_recursive` only replaced *empty* ID strings (`""`), not non-empty, non-UUID strings. The execution engine enforces UUID4 for all `id`, `id_left`, `id_right` fields.

**Fixed in:** `api/versions.py` — `_fill_ids_recursive` now replaces any string that isn't a valid UUID.

---

## 3. `flows run` showed a traceback instead of the execution error

**What happened:** The CLI raised an unhandled `httpx.HTTPStatusError` with no detail:
```
HTTPStatusError: Server error '500 Internal Server Error'
```

**Actual error in the response body:**
```json
{"detail": {"exc_type": "compile", "msg": "value is not a valid uuid", "node_id": ""}}
```

**Fixed in:** `api/execution.py` — non-200 responses now parse the body and raise `TktlError` with the engine's message.

---

## 4. Split clause `False` compared as a string, not a boolean

**What happened:** `--clause "data.eligible == False"` produced:
```json
{"left": "data.eligible", "right": "\"False\"", "operator": "eq"}
```
The execution engine evaluated `data.eligible == "False"` (Python boolean vs. string), which is always `False`. Both branches always took the default path — the split was silently broken.

**Root cause:** `_parse_clause` auto-quoted anything non-numeric and not already quoted. `False`, `True`, and `None` are not numeric, so they got quoted.

**Fixed in:** `ops/graph.py` — `_UNQUOTED_LITERALS = {"True", "False", "None"}` exempted from auto-quoting.

---

## 5. Rule node operators: `gte`/`lte` rejected silently

The API only accepts `ge`, `le`, `gt`, `lt`, `eq`, `ne`, `is_in`, `not_is_in`, `is_none`, `is_not_none`, `contains`, `does_not_contain`, `matches_regex`. Passing `gte` or `lte` causes a 422 that (before fix #1) appeared as a 3-retry ConflictError.

**Not fixed in code** — the correct operator names are documented in `skills/flow-builder/references/node-configs.md`.

---

## 6. Rule branch effects must mirror default effect targets

The API enforces that every field set in `default_effects` must also appear in every `branch.effects`. Mismatches return:
```
409: Rule node branch 0 has inconsistent effects: branch targets {'eligible'} != default targets {'decline_reason', 'eligible'}
```

**Not fixed in code** — there is no client-side pre-validation. Document this constraint clearly; a future improvement could add it as a `UsageError` before the PATCH.

---

## 7. Scorecard scoring range is unintuitive with `equal_weights: true`

With `equal_weights: true`, the scorecard averages factor scores. If factors have max scores of 30, 40, and 30, the maximum total is 33.3, not 100. This requires calibrating downstream thresholds to the actual scoring range, which is non-obvious.

**Not a bug** — design behaviour. Documented in `skills/flow-builder/references/node-configs.md`.

---

## 8. `org` vs `workspace` — flows can be invisible

A flow exists under a specific `org` ID. The initial `tktl config` sets one org. Flows in a different org are invisible to `flows list` — they return 404 even though the flow ID is correct.

**Not a bug** — multi-org is a valid platform concept. But the error from `flows describe <id>` is `NotFoundError: Flow with slug '690d79a9-...' not found`, which gives no hint that the org is wrong.

---

## 9. The CLI's `update apply` retry loop hits false positives

Even when the API is quiet, consecutive `update apply` calls in quick succession (e.g. schema → node config → schema) occasionally trigger the 3-retry limit. The ETag changes are real — multiple writes in rapid sequence cause legitimate 412s. Waiting briefly between calls avoids this, but there's no guidance on this in the CLI output.

**Partial fix:** The 422 no longer burns retries (#1). True 412 congestion is a separate issue.

---

## 10. Direct API debugging required for execution errors

Before fix #3, the only way to see the actual execution error was to call the decide endpoint directly with `httpx` and inspect the response body. The CLI surface was opaque. This is now fixed, but the debugging path (direct API call) is worth keeping in `skills/debugging.md`.
