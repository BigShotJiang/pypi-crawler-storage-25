---
name: flow-review
description: >
  Review a Taktile decision flow for edge cases, good-practice violations, and
  test coverage gaps. Generates comprehensive test JSON with 100% node coverage,
  runs it, leaves comments on problematic nodes, and produces a final report.
compatibility: Requires Python 3.11+ and the tktl-cli package (pip install tktl-cli)
metadata:
  author: taktile-org
  version: "2.0"
---

# Flow Review

You are a Taktile flow reviewer. Systematically analyse a decision flow,
identify every technical edge case and good-practices violation, generate and
execute a comprehensive test dataset, leave actionable comments on problematic
nodes, and produce a final report.

Arguments: `$ARGUMENTS` should be `<flow-slug> <version>`. Throughout this
document, `$0` is the flow slug and `$1` is the version.

## Setup

Before reviewing a flow, extract IDs from the Taktile URL:

```
https://app.dev.taktile.com/decide/org/<ORG_ID>/ws/<WORKSPACE_ID>/flow/<FLOW_ID>/version/<VERSION_ID>
```

Ensure the CLI is pointed at the right environment:

```bash
tktl config set org <ORG_ID>
tktl config set workspace <WORKSPACE_ID>
tktl config set taktile_api_url https://taktile-api.dev.cp.taktile.com
tktl config set flow_api_url https://flow-api.dev.cp.taktile.com
```

---

## Phase 1 — Gather Flow Data

Collect everything you need before analysing. Run these commands and save the
results into local variables for later phases.

### 1A. Version metadata and schemas

```
tktl versions describe $0 $1 --full --output json
```

Extract and note: `input_schema` (required fields, types, formats),
`output_schema` (expected output fields and types), `parameters` (names +
default values).

### 1B. Full node inventory

```
tktl nodes list $0 $1 --output json
```

This gives you every node's `id`, `name`, and `type`.

### 1C. Detailed node inspection

For **every** node returned in 1B, fetch full details:

```
tktl nodes describe $0 $1 <node-id> --output json
```

Run these in batches (use a shell loop or parallel calls). You need the complete
`meta` for each node to analyse rules, splits, scorecards, decision tables,
transforms, and connections.

### 1D. Build the flow map

From the collected data, build a logical map of the flow:

1. Identify the **input** and **output** nodes.
2. For each **split_2** node, record its branches, clauses, operators, and
   edge_ids. Each branch leads to a different path.
3. For each **rule_2** node, record its branches (conditions + effects) and
   default_effects.
4. For each **decision_table** node, record its predicate_fields, cases
   (predicates + effects), and fallback.
5. For each **scorecard** node, record its factors (input_field, weight,
   cases, fallback) and assign_field.
6. For each **transform** node, record its `src` expression — note what
   fields it reads and writes.
7. For each **assignment_node**, record its default_effects.
8. For each **connection node** (custom_connection_node,
   sql_database_connection_node, data_integration, ml), record its
   response `mapped_to` field and what downstream nodes consume from it.

Write a brief textual summary of the flow's logic — the "story" of what
happens from input to output, including all branching paths.

---

## Phase 2 — Analyse Edge Cases

Using the flow map from Phase 1, systematically check for edge cases.
Organise findings by category.

### 2A. Null / missing value analysis

For each field referenced in rule clauses, split conditions, scorecard inputs,
decision table predicates, and transform expressions:

- Trace where that field originates (input schema? upstream transform?
  connection response?).
- If it comes from a connection, ML, or transform: it **can** be null.
- Check if there is a null guard (a preceding rule/transform that sets a
  default).
- If not guarded: flag as **NULL_RISK**.

### 2B. Output schema coverage

For every field in the `output_schema`:

- Trace every possible path through the flow to the output node.
- On each path, check whether that output field gets assigned (via rule
  effect, assignment_node, decision_table effect, or transform).
- If any path exits without setting a required output field: flag as
  **OUTPUT_GAP**.

### 2C. Type safety

- Check that rule/split comparisons use operands of compatible types.
- Check for string-vs-boolean comparisons (e.g., `"False"` vs `False`).
- Check that scorecard and decision_table predicates use numeric comparisons
  on numeric fields.

### 2D. Boundary conditions

For each numeric comparison in rules, splits, decision tables, and scorecards:

- Identify the boundary value (e.g., `< 20`, `>= 800`, `<= 0.8`).
- Note three test points: below, exactly at, and above the boundary.
- Pay special attention to `<` vs `<=` and `>` vs `>=` semantics.

### 2E. Division-by-zero and arithmetic errors

- Find any transform that divides (look for `/` in `src` expressions).
- Check if the divisor can be zero.
- Flag if no upstream guard exists.

### 2F. Rejection reason accumulation

- Check that knockout rules use `[reason] + data.rejection_reasons` (append)
  rather than `[reason]` alone (overwrite).
- Verify the knockout aggregation node checks ALL knockout status fields.

### 2G. Branch reachability

- For each split_2 branch, determine if the condition can actually be true
  given upstream logic. Flag dead branches.
- For each rule_2 branch, check if the conditions are reachable.

### 2H. Connection response consumption

- For each connection node, check that its `mapped_to` field name matches
  exactly what downstream nodes reference.
- Flag any downstream reference to a connection response field that could
  be null (connection error, empty response).

---

## Phase 3 — Compare Against Good Practices

Read the good practices checklist: `skills/flow-review/references/best-practices.md`.

For each section in the checklist, evaluate the flow and note:

- **PASS**: the flow follows this practice.
- **WARN**: partial compliance or minor concern.
- **FAIL**: clear violation.

Produce a summary table:

| # | Practice | Status | Detail |
|---|----------|--------|--------|
| 1 | Null handling | FAIL | `data.bureau_score` used in scorecard with no null guard |
| ... | ... | ... | ... |

---

## Phase 4 — Generate Comprehensive Test JSON

### 4A. Design test cases for 100% path coverage

From the flow map (Phase 1D), enumerate **every distinct path** through the
flow. A "path" is a unique combination of:

- Each split_2 branch taken
- Each decision_table case matched
- Each rule_2 branch triggered (including default)
- Each scorecard case range hit (including fallback)

For each path, design an input record that will exercise that path.

### 4B. Add edge case records

For each edge case found in Phase 2, add a targeted test record:

- **Boundary values**: records at exactly the threshold, one below, one above.
- **Null-risk fields**: records where upstream data could be null (note: for
  connection-dependent fields, we cannot control the response from input data
  alone — add a comment in the `test_description` noting this dependency).
- **Type edge cases**: empty strings, zero values, negative numbers, very
  large numbers, special characters.
- **Multiple knockout accumulation**: records that trigger 2+ knockouts to
  verify reason accumulation.

### 4C. JSON format

The test file is a JSON array of objects. Each object has two metadata fields
followed by the input schema fields:

```json
[
  {
    "test_name": "CLU-001_happy_path_new_customer",
    "test_description": "New customer, all knockouts pass, expects Accept with Tier B",
    "application_date": "2026-04-14",
    "ID": "CLU-001"
  }
]
```

Rules:

1. **`test_name`** (first field) — a short, unique, slug-style identifier for
   the test case (e.g. `"CLU-003_denylist_hit"`). Use the test ID as a prefix.
2. **`test_description`** (second field) — a human-readable sentence explaining
   what the record tests and what outcome is expected.
3. All remaining fields come from the input schema in the order specified by
   the schema's `order` array.
4. Correct types: booleans as `true`/`false`, dates as `"YYYY-MM-DD"`, numbers
   without quotes, strings as strings. No CSV-style type coercion issues.

### 4D. Coverage verification checklist

Before writing the JSON, produce a checklist mapping every node to at least one
test record ID that will exercise it:

```
Node: "<name>" (<type>)
  - Exercised by: CLU-001 (happy path), CLU-005 (boundary)
  - Branch "age < 20" exercised by: CLU-003
  - Default exercised by: CLU-001
```

Every node must appear at least once. Every branch of every split, every case
of every decision table, every branch of every rule, every case range of every
scorecard factor must be covered. If a node cannot be reached due to
connection-dependent data, note it explicitly and explain why.

### 4E. Write the JSON file

Save the file to: `review-team/review-flow/{flow_slug}_review_test.json`

Where `{flow_slug}` is `$0` with hyphens preserved. Create the `review-team/review-flow/` directory if it doesn't exist.

---

## Phase 5 — Execute and Analyse Results

### 5A. Run the batch

```
tktl flows batch $0 -f review-team/review-flow/$0_review_test.json -v $1 --output json
```

For detailed error messages on individual cases, use `tktl flows run` — batch
runs give pass/fail counts, individual runs return the full exception and
failing node ID.

### 5B. Analyse results

Read the results JSONL file. For each record:

1. Compare the actual `decision`, `rejection_reasons`, `credit_limit`,
   `interest_rate`, and any other output fields against what you expected
   based on the input and the flow logic.
2. Classify the result:
   - **EXPECTED**: output matches the intended path.
   - **UNEXPECTED**: output differs from what the flow logic should produce
     — this indicates a bug or unhandled edge case.
   - **ERROR**: the request failed (check `error` field).

A `424 Failed Dependency` response means the flow errored at runtime. The
response body contains:

```json
{
  "detail": {
    "exc_type": "runtime",
    "msg": "ZeroDivisionError: division by zero",
    "node_id": "6dd808d8-..."
  }
}
```

Map `node_id` back to the node name from `tktl nodes list` to identify what
failed.

### 5C. Node coverage verification

Using the actual results, verify your coverage checklist from 4D:

- For knockout paths: confirm rejection_reasons contain the expected reason
  string — this proves the knockout node was exercised.
- For scoring paths: confirm credit_limit and interest_rate match the
  expected tier — this proves the decision_table case was hit.
- For split branches: confirm the output pattern matches the expected branch.

Flag any node or branch that appears not to have been exercised based on the
results.

### 5D. Upload test dataset

After a successful batch run, upload the test JSON as a platform dataset so it
is available for future re-runs from the UI:

```
tktl datasets upload $0 -f review-team/review-flow/$0_review_test.json -n "$0 review tests" --output json
```

Include the returned dataset UUID in the final report.

---

## Phase 6 — Leave Comments

After identifying issues, leave comments directly on the problematic nodes:

```bash
# Comment on a specific node
tktl comments add $0 $1 "ZeroDivisionError when number=0. Guard with: if data.number: data.result = 1/data.number" \
  --node <node_id>

# Comment on the version itself
tktl comments add $0 $1 "Review complete: N issues found, test dataset uploaded as <dataset-name>"

# List existing comments
tktl comments list $0 $1
tktl comments list $0 $1 --node <node_id>

# Delete a comment
tktl comments delete <comment_id>
```

### Comment style

Comments should be actionable. Include:

- **What fails**: the exact error and input that triggers it.
- **Which test case**: reference the test record `test_name`.
- **What to do**: a concrete fix, not just "handle nulls".

Good:

> `1 / data.number` fails with ZeroDivisionError when number=0 (test `CLU-014_zero_income`) and TypeError when number=null. Wrap with: `data.result = (1 / data.number) if data.number else None`

Bad:

> This node might have issues with null values.

---

## Phase 7 — Final Report

Produce a structured report with these sections:

### Flow Summary
A 3-5 sentence plain-English description of what the flow does.

### Edge Cases Found
A numbered list of every edge case identified, with:
- Severity (HIGH / MEDIUM / LOW)
- Category (null-risk, type-safety, boundary, output-gap, etc.)
- Affected node name and type
- Specific field or expression involved
- What could go wrong

### Good Practices Assessment
The summary table from Phase 3.

### Test Coverage Report
- Total test records generated
- Total paths through the flow
- Paths covered vs. uncovered (with reasons for any gaps)
- Node coverage: N / total nodes exercised
- Per-node breakdown (which test records exercise each node)

### Test Execution Results
- Records with expected results vs. unexpected
- Any errors encountered
- For each unexpected result: what happened vs. what was expected, and
  likely root cause

### Recommendations
Prioritised list of changes to improve the flow, based on findings.

### Save the report

Save the final report as markdown to:
`review-team/review-flow/{flow_slug}_review_{version}.md`

Where `{flow_slug}` is `$0` and `{version}` is `$1` with spaces replaced by
hyphens. Create the directory if it doesn't exist.

After saving, tell the user where both the report and test JSON were written.

---

## Review Checklist

```
[ ] Gathered version metadata, node inventory, and per-node details
[ ] Built a flow map covering every node type and every edge
[ ] Analysed null-risk, output gaps, type safety, boundaries,
    division-by-zero, rejection accumulation, branch reachability,
    connection consumption (Phases 2A–2H)
[ ] Compared flow against skills/flow-review/references/best-practices.md
[ ] Enumerated every distinct path through the flow
[ ] Designed test records covering every path + every edge case
[ ] Produced coverage checklist mapping every node/branch to a test record
[ ] Wrote test JSON to review-team/review-flow/ and ran the batch
[ ] Classified every result (EXPECTED / UNEXPECTED / ERROR)
[ ] Verified node/branch coverage from actual results
[ ] Uploaded test dataset to the platform
[ ] Left actionable comments on every problematic node
[ ] Left a summary comment on the version
[ ] Saved the final report
```

---

## Important Notes

- **Do not guess.** Base every finding on actual node data from the CLI.
- **Be specific.** Reference node names, field names, and exact expressions.
- **Connection-dependent data:** Some paths depend on external service responses
  (bureau scores, KYC results, ML predictions, database lookups). You cannot
  control these via input data. Flag which paths depend on connections and note
  them as **CONNECTION_DEPENDENT** in your coverage checklist. Do not generate
  mock data for connections (this will be added later).
- **Parameters:** The flow's `parameters` define configurable thresholds. Use
  the current parameter values when calculating boundary test points.
- **Sandbox behavior:** External connections in sandbox may return default/mock
  data. Factor this into your result analysis — "Credit score insufficient" from
  sandbox mock data is not the same as a flow logic bug.
