"""Tests for tktl.resolver — slug/name to ID resolution."""

from __future__ import annotations

import pytest

from tktl.models.errors import NotFoundError
from tktl.resolver import Resolver


@pytest.fixture()
def index_data() -> dict:
    """Sample index data matching the SPEC.md index.json structure."""
    return {
        "workspace_id": "ws_abc123",
        "flows": {
            "credit-scoring": {
                "id": "fl_abc",
                "versions": {
                    "v1": "fv_xyz",
                    "v2": "fv_abc",
                },
            },
            "fraud-detection": {
                "id": "fl_def",
                "versions": {
                    "main": "fv_main_001",
                },
            },
        },
    }


@pytest.fixture()
def resolver_with_cache(index_data: dict) -> Resolver:
    """Resolver with pre-populated cache, no fallback lookup."""
    return Resolver(cache=index_data)


@pytest.fixture()
def lookup_calls() -> list:
    """Track calls to the fallback lookup function."""
    return []


class TestResolveFlowId:
    """resolve_flow_id: slug -> flow UUID."""

    def test_cache_hit(self, resolver_with_cache: Resolver):
        assert resolver_with_cache.resolve_flow_id("credit-scoring") == "fl_abc"

    def test_cache_hit_another_flow(self, resolver_with_cache: Resolver):
        assert resolver_with_cache.resolve_flow_id("fraud-detection") == "fl_def"

    def test_not_found_raises(self, resolver_with_cache: Resolver):
        with pytest.raises(NotFoundError, match="no-such-flow"):
            resolver_with_cache.resolve_flow_id("no-such-flow")

    def test_empty_cache_raises(self):
        resolver = Resolver(cache={"flows": {}})
        with pytest.raises(NotFoundError):
            resolver.resolve_flow_id("anything")

    def test_fallback_called_on_cache_miss(self, lookup_calls: list):
        """When cache misses but a fallback lookup is provided, it is called."""
        fallback_data = {
            "credit-scoring": {
                "id": "fl_new",
                "versions": {},
            },
        }

        def fallback_lookup() -> dict:
            lookup_calls.append("called")
            return {"flows": fallback_data}

        resolver = Resolver(cache={"flows": {}}, lookup_fn=fallback_lookup)
        result = resolver.resolve_flow_id("credit-scoring")
        assert result == "fl_new"
        assert len(lookup_calls) == 1

    def test_fallback_not_found_raises(self, lookup_calls: list):
        """When fallback also doesn't have the slug, raises NotFoundError."""

        def fallback_lookup() -> dict:
            lookup_calls.append("called")
            return {"flows": {}}

        resolver = Resolver(cache={"flows": {}}, lookup_fn=fallback_lookup)
        with pytest.raises(NotFoundError, match="missing-flow"):
            resolver.resolve_flow_id("missing-flow")
        assert len(lookup_calls) == 1

    def test_fallback_updates_cache(self, lookup_calls: list):
        """After a fallback hit, subsequent lookups should hit the cache."""
        fallback_data = {
            "new-flow": {
                "id": "fl_fresh",
                "versions": {"v1": "fv_fresh"},
            },
        }

        def fallback_lookup() -> dict:
            lookup_calls.append("called")
            return {"flows": fallback_data}

        resolver = Resolver(cache={"flows": {}}, lookup_fn=fallback_lookup)

        # First call triggers fallback
        assert resolver.resolve_flow_id("new-flow") == "fl_fresh"
        assert len(lookup_calls) == 1

        # Second call should use updated cache, no additional fallback call
        assert resolver.resolve_flow_id("new-flow") == "fl_fresh"
        assert len(lookup_calls) == 1


class TestResolveVersionId:
    """resolve_version_id: flow_slug + version_name -> version UUID."""

    def test_cache_hit(self, resolver_with_cache: Resolver):
        assert resolver_with_cache.resolve_version_id("credit-scoring", "v1") == "fv_xyz"

    def test_cache_hit_another_version(self, resolver_with_cache: Resolver):
        assert resolver_with_cache.resolve_version_id("credit-scoring", "v2") == "fv_abc"

    def test_cache_hit_different_flow(self, resolver_with_cache: Resolver):
        assert resolver_with_cache.resolve_version_id("fraud-detection", "main") == "fv_main_001"

    def test_unknown_flow_raises(self, resolver_with_cache: Resolver):
        with pytest.raises(NotFoundError, match="no-such-flow"):
            resolver_with_cache.resolve_version_id("no-such-flow", "v1")

    def test_unknown_version_raises(self, resolver_with_cache: Resolver):
        with pytest.raises(NotFoundError, match="no-such-version"):
            resolver_with_cache.resolve_version_id("credit-scoring", "no-such-version")

    def test_empty_versions_raises(self):
        resolver = Resolver(
            cache={
                "flows": {
                    "my-flow": {
                        "id": "fl_x",
                        "versions": {},
                    }
                }
            }
        )
        with pytest.raises(NotFoundError):
            resolver.resolve_version_id("my-flow", "v1")

    def test_fallback_called_for_version_miss(self, lookup_calls: list):
        """Fallback is invoked when version is not in cache."""
        fallback_data = {
            "credit-scoring": {
                "id": "fl_abc",
                "versions": {
                    "v1": "fv_xyz",
                    "v3": "fv_new",
                },
            },
        }

        def fallback_lookup() -> dict:
            lookup_calls.append("called")
            return {"flows": fallback_data}

        resolver = Resolver(
            cache={
                "flows": {
                    "credit-scoring": {
                        "id": "fl_abc",
                        "versions": {"v1": "fv_xyz"},
                    }
                }
            },
            lookup_fn=fallback_lookup,
        )
        result = resolver.resolve_version_id("credit-scoring", "v3")
        assert result == "fv_new"
        assert len(lookup_calls) == 1
