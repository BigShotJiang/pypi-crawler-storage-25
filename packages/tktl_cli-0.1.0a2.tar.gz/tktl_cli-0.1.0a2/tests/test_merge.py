"""Tests for tktl.merge — RFC 7396 JSON Merge Patch."""

from __future__ import annotations

import copy

from tktl.merge import deep_merge


class TestDeepMergeBasic:
    """Basic merge operations."""

    def test_add_new_key(self):
        assert deep_merge({"a": 1}, {"b": 2}) == {"a": 1, "b": 2}

    def test_overwrite_existing_key(self):
        assert deep_merge({"a": 1}, {"a": 2}) == {"a": 2}

    def test_null_deletes_key(self):
        assert deep_merge({"a": 1, "b": 2}, {"a": None}) == {"b": 2}

    def test_null_deletes_nonexistent_key_is_noop(self):
        """Deleting a key that doesn't exist is a no-op."""
        assert deep_merge({"a": 1}, {"b": None}) == {"a": 1}

    def test_missing_keys_preserved(self):
        """Keys in base that are not in patch are preserved."""
        assert deep_merge({"a": 1, "b": 2, "c": 3}, {"b": 20}) == {
            "a": 1,
            "b": 20,
            "c": 3,
        }


class TestDeepMergeNested:
    """Nested dict merge operations."""

    def test_nested_merge(self):
        base = {"a": {"x": 1, "y": 2}}
        patch = {"a": {"y": 3, "z": 4}}
        assert deep_merge(base, patch) == {"a": {"x": 1, "y": 3, "z": 4}}

    def test_nested_null_deletes(self):
        base = {"a": {"x": 1, "y": 2}}
        patch = {"a": {"x": None}}
        assert deep_merge(base, patch) == {"a": {"y": 2}}

    def test_deeply_nested_merge(self):
        base = {"a": {"b": {"c": 1, "d": 2}}}
        patch = {"a": {"b": {"c": 3}}}
        assert deep_merge(base, patch) == {"a": {"b": {"c": 3, "d": 2}}}

    def test_three_levels_deep_with_delete(self):
        base = {"l1": {"l2": {"l3": {"keep": True, "remove": "bye"}}}}
        patch = {"l1": {"l2": {"l3": {"remove": None, "add": "hi"}}}}
        assert deep_merge(base, patch) == {"l1": {"l2": {"l3": {"keep": True, "add": "hi"}}}}

    def test_dict_replaces_scalar(self):
        """If base has a scalar and patch has a dict, replace with dict."""
        base = {"a": 1}
        patch = {"a": {"nested": True}}
        assert deep_merge(base, patch) == {"a": {"nested": True}}

    def test_scalar_replaces_dict(self):
        """If base has a dict and patch has a scalar, replace with scalar."""
        base = {"a": {"nested": True}}
        patch = {"a": 42}
        assert deep_merge(base, patch) == {"a": 42}


class TestDeepMergeArrays:
    """Arrays are replaced, not merged — per RFC 7396."""

    def test_array_replaced_not_merged(self):
        base = {"a": [1, 2, 3]}
        patch = {"a": [4, 5]}
        assert deep_merge(base, patch) == {"a": [4, 5]}

    def test_nested_array_replaced(self):
        base = {"a": {"items": [1, 2, 3]}}
        patch = {"a": {"items": [99]}}
        assert deep_merge(base, patch) == {"a": {"items": [99]}}


class TestDeepMergeEdgeCases:
    """Edge cases: empty dicts, no-ops."""

    def test_empty_base(self):
        assert deep_merge({}, {"a": 1}) == {"a": 1}

    def test_empty_patch(self):
        assert deep_merge({"a": 1}, {}) == {"a": 1}

    def test_both_empty(self):
        assert deep_merge({}, {}) == {}

    def test_empty_patch_preserves_nested(self):
        base = {"a": {"b": {"c": 1}}}
        assert deep_merge(base, {}) == {"a": {"b": {"c": 1}}}


class TestDeepMergeImmutability:
    """Verify inputs are not mutated."""

    def test_base_not_mutated(self):
        base = {"a": 1, "b": {"c": 2}}
        base_copy = copy.deepcopy(base)
        patch = {"b": {"c": 3, "d": 4}, "e": 5}
        deep_merge(base, patch)
        assert base == base_copy

    def test_patch_not_mutated(self):
        base = {"a": 1}
        patch = {"b": {"c": 2}}
        patch_copy = copy.deepcopy(patch)
        deep_merge(base, patch)
        assert patch == patch_copy

    def test_result_is_independent_of_inputs(self):
        """Mutations to the result should not affect base or patch."""
        base = {"a": {"nested": [1, 2]}}
        patch = {"b": {"data": [3, 4]}}
        result = deep_merge(base, patch)
        result["a"]["nested"].append(99)
        result["b"]["data"].append(99)
        assert base == {"a": {"nested": [1, 2]}}
        assert patch == {"b": {"data": [3, 4]}}
