"""Tests for ops.versions.replace_version — bulk PUT replace."""

from __future__ import annotations

from tktl.api.client import TktlClient
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.models.version import VersionDetail
from tktl.ops.flows import describe_flow
from tktl.ops.versions import replace_version

WS_ID = "ws_00000000-0000-0000-0000-000000000001"


def _seed_cache(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
) -> None:
    describe_flow(client, cache_index, cache_manager, WS_ID, "credit-scoring")


class TestReplaceVersion:
    def test_replace_entire_version(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        new_body = {
            "name": "v1-replaced",
            "status": "DRAFT",
            "graph": {
                "nodes": {"new_node": {"id": "new_node", "name": "New Node", "type": "input"}},
                "edges": {},
                "node_groups": {},
            },
        }
        result = replace_version(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1", body=new_body)
        assert isinstance(result, VersionDetail)
        assert result.name == "v1-replaced"

    def test_cache_updated_after_replace(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        new_body = {
            "name": "v1-replaced",
            "status": "DRAFT",
            "graph": {
                "nodes": {"new_node": {"id": "new_node", "name": "Replaced Node", "type": "output"}},
                "edges": {},
                "node_groups": {},
            },
        }
        replace_version(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1", body=new_body)

        # Verify cache has the new node
        flow_id = cache_index.resolve_flow_id("credit-scoring")
        version_id = cache_index.resolve_version_id("credit-scoring", "v1")
        assert flow_id is not None
        assert version_id is not None
        node_index = cache_manager.read_node_index(version_id, flow_id)
        assert node_index is not None
        assert len(node_index) == 1
        assert node_index[0]["id"] == "new_node"
