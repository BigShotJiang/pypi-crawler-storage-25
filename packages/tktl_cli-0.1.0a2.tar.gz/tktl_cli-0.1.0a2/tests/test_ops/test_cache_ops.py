"""Tests for cache operations: refresh_cache, clear_cache, cache_status."""

from __future__ import annotations

from pathlib import Path

from tktl.api.client import TktlClient
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.ops.cache_ops import cache_status, clear_cache, refresh_cache
from tktl.ops.flows import describe_flow

WS_ID = "ws_00000000-0000-0000-0000-000000000001"


class TestRefreshCache:
    def test_rebuild_index_and_versions(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        """refresh_cache should rebuild the index and cache all versions."""
        refresh_cache(client, cache_index, cache_manager, WS_ID)

        # Index should have both flows
        cs_id = cache_index.resolve_flow_id("credit-scoring")
        kyc_id = cache_index.resolve_flow_id("kyc-check")
        assert cs_id is not None
        assert kyc_id is not None

        # Version mappings should exist
        v1_id = cache_index.resolve_version_id("credit-scoring", "v1")
        assert v1_id is not None

    def test_versions_are_cached(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        refresh_cache(client, cache_index, cache_manager, WS_ID)

        flow_id = cache_index.resolve_flow_id("credit-scoring")
        version_id = cache_index.resolve_version_id("credit-scoring", "v1")
        assert flow_id is not None
        assert version_id is not None

        # Version should be cached with nodes decomposed
        meta = cache_manager.read_version_metadata(version_id, flow_id)
        assert meta is not None

        node_index = cache_manager.read_node_index(version_id, flow_id)
        assert node_index is not None
        assert len(node_index) > 0


class TestClearCache:
    def test_clears_all_cached_data(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        # First populate the cache
        describe_flow(client, cache_index, cache_manager, WS_ID, "credit-scoring")
        flow_id = cache_index.resolve_flow_id("credit-scoring")
        assert flow_id is not None

        # Clear
        clear_cache(cache_manager)

        # Cache should be empty
        meta = cache_manager.read_flow_metadata(flow_id)
        assert meta is None


class TestCacheStatus:
    def test_returns_status_dict(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        refresh_cache(client, cache_index, cache_manager, WS_ID)
        status = cache_status(cache_manager)
        assert isinstance(status, dict)
        assert "cache_dir" in status
        assert "exists" in status
        assert status["exists"] is True

    def test_empty_cache_status(
        self,
        tmp_path: Path,
    ) -> None:
        """cache_status on non-existent cache dir should report exists=False."""
        empty_cm = CacheManager(tmp_path / "nonexistent_cache")
        status = cache_status(empty_cm)
        assert isinstance(status, dict)
        assert status["exists"] is False
