"""Tests for ops.versions — list_versions, describe_version, list_changes, replace_version."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from tktl.api.client import TktlClient
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.models.version import VersionDetail, VersionSummary
from tktl.ops.flows import describe_flow
from tktl.ops.versions import (
    _build_replace_patch,
    _upsert_child_flows,
    describe_version,
    list_changes,
    list_versions,
    replace_version,
)

if TYPE_CHECKING:
    from tests.fake_api.state import FakeState

WS_ID = "ws_00000000-0000-0000-0000-000000000001"


def _seed_index(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
) -> None:
    """Seed the cache index by describing flows."""
    describe_flow(client, cache_index, cache_manager, WS_ID, "credit-scoring")


class TestListVersions:
    def test_returns_version_summary_list(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        _seed_index(client, cache_index, cache_manager)
        result = list_versions(client, cache_index, cache_manager, WS_ID, "credit-scoring")
        assert isinstance(result, list)
        assert len(result) == 2
        assert all(isinstance(v, VersionSummary) for v in result)

    def test_version_summary_fields(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        _seed_index(client, cache_index, cache_manager)
        result = list_versions(client, cache_index, cache_manager, WS_ID, "credit-scoring")
        names = {v.name for v in result}
        assert "v1" in names
        assert "v2-draft" in names
        for v in result:
            assert v.id
            assert v.status


class TestDescribeVersion:
    def test_returns_version_detail(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        _seed_index(client, cache_index, cache_manager)
        result = describe_version(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1")
        assert isinstance(result, VersionDetail)
        assert result.name == "v1"
        assert result.id
        assert result.etag

    def test_full_false_no_graph(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        """When full=False (default), the result should not contain graph data."""
        _seed_index(client, cache_index, cache_manager)
        result = describe_version(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1", full=False)
        assert isinstance(result, VersionDetail)
        assert result.parameters is not None
        assert result.graph is None

    def test_full_true_includes_graph(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        """When full=True, the result should include graph data with nodes and edges."""
        _seed_index(client, cache_index, cache_manager)
        result = describe_version(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1", full=True)
        assert isinstance(result, VersionDetail)
        assert result.graph is not None
        assert "nodes" in result.graph
        assert len(result.graph["nodes"]) == 4  # credit-scoring v1 has 4 nodes

    def test_caches_version_and_decomposes_nodes(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        _seed_index(client, cache_index, cache_manager)
        describe_version(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1")

        flow_id = cache_index.resolve_flow_id("credit-scoring")
        version_id = cache_index.resolve_version_id("credit-scoring", "v1")
        assert flow_id is not None
        assert version_id is not None

        # Version metadata should be cached
        meta = cache_manager.read_version_metadata(version_id, flow_id)
        assert meta is not None
        assert meta["name"] == "v1"

        # Nodes should be decomposed
        node_index = cache_manager.read_node_index(version_id, flow_id)
        assert node_index is not None
        assert len(node_index) == 4  # credit-scoring v1 has 4 nodes

    def test_version_detail_includes_schemas(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        _seed_index(client, cache_index, cache_manager)
        result = describe_version(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1")
        assert result.input_schema is not None
        assert result.output_schema is not None


class TestListChanges:
    def test_returns_list(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        _seed_index(client, cache_index, cache_manager)
        result = list_changes(client, cache_index, WS_ID, "credit-scoring", "v1")
        assert isinstance(result, list)

    def test_with_params(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        _seed_index(client, cache_index, cache_manager)
        result = list_changes(client, cache_index, WS_ID, "credit-scoring", "v1", after_etag="x", limit=50)
        assert isinstance(result, list)


class TestBuildReplacePatch:
    """Unit tests for _build_replace_patch helper."""

    def test_deletes_old_nodes_adds_new(self) -> None:
        current: dict[str, Any] = {
            "graph": {
                "nodes": {"old1": {"id": "old1"}, "old2": {"id": "old2"}},
                "edges": {"e1": {"id": "e1"}},
                "node_groups": {},
            },
        }
        new_body: dict[str, Any] = {
            "name": "replaced",
            "graph": {
                "nodes": {"new1": {"id": "new1"}, "new2": {"id": "new2"}},
                "edges": {"e2": {"id": "e2"}},
                "node_groups": {},
            },
        }
        patch = _build_replace_patch(current, new_body)

        assert patch["name"] == "replaced"
        # Old nodes should be null-deleted
        assert patch["graph"]["nodes"]["old1"] is None
        assert patch["graph"]["nodes"]["old2"] is None
        # New nodes should be present
        assert patch["graph"]["nodes"]["new1"] == {"id": "new1"}
        assert patch["graph"]["nodes"]["new2"] == {"id": "new2"}
        # Old edge deleted, new added
        assert patch["graph"]["edges"]["e1"] is None
        assert patch["graph"]["edges"]["e2"] == {"id": "e2"}

    def test_shared_nodes_replaced_not_deleted(self) -> None:
        current: dict[str, Any] = {
            "graph": {
                "nodes": {"keep": {"id": "keep", "name": "old"}},
                "edges": {},
                "node_groups": {},
            },
        }
        new_body: dict[str, Any] = {
            "graph": {
                "nodes": {"keep": {"id": "keep", "name": "updated"}},
                "edges": {},
                "node_groups": {},
            },
        }
        patch = _build_replace_patch(current, new_body)
        # Shared node should be updated, not null-deleted
        assert patch["graph"]["nodes"]["keep"] == {"id": "keep", "name": "updated"}

    def test_no_graph_in_body(self) -> None:
        current: dict[str, Any] = {"graph": {"nodes": {"n1": {"id": "n1"}}}}
        new_body: dict[str, Any] = {"name": "updated"}
        patch = _build_replace_patch(current, new_body)
        assert "graph" not in patch
        assert patch["name"] == "updated"

    def test_empty_current_graph(self) -> None:
        current: dict[str, Any] = {"graph": {"nodes": {}, "edges": {}, "node_groups": {}}}
        new_body: dict[str, Any] = {
            "graph": {"nodes": {"n1": {"id": "n1"}}, "edges": {}, "node_groups": {}},
        }
        patch = _build_replace_patch(current, new_body)
        assert patch["graph"]["nodes"] == {"n1": {"id": "n1"}}


class TestReplaceVersion:
    """Integration tests for replace_version using the fake API."""

    def test_replaces_graph(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        fake_state: FakeState,
    ) -> None:
        _seed_index(client, cache_index, cache_manager)
        # v2-draft has 3 nodes (node_input, node_ml, node_output)
        new_body: dict[str, Any] = {
            "name": "v2-draft",
            "graph": {
                "nodes": {
                    "a1": {"id": "a1", "name": "start", "type": "input"},
                    "a2": {"id": "a2", "name": "score", "type": "scorecard"},
                    "a3": {"id": "a3", "name": "end", "type": "output"},
                    "a4": {"id": "a4", "name": "extra", "type": "data_integration"},
                },
                "edges": {
                    "e1": {"id": "e1", "start_node_id": "a1", "end_node_id": "a2"},
                },
                "node_groups": {},
            },
        }
        result = replace_version(
            client,
            cache_index,
            cache_manager,
            WS_ID,
            "credit-scoring",
            "v2-draft",
            new_body,
        )
        assert isinstance(result, VersionDetail)

        # Verify graph was fully replaced via the fake state
        vid = cache_index.resolve_version_id("credit-scoring", "v2-draft")
        assert vid is not None
        version_data = fake_state.versions[vid]
        graph_nodes = version_data["graph"]["nodes"]
        # Old nodes (node_input, node_ml, node_output) should be gone
        assert "node_input" not in graph_nodes
        assert "node_ml" not in graph_nodes
        assert "node_output" not in graph_nodes
        # New nodes should be present
        assert "a1" in graph_nodes
        assert "a2" in graph_nodes
        assert "a3" in graph_nodes
        assert "a4" in graph_nodes
        assert len(graph_nodes) == 4

    def test_accepts_array_format_body(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        fake_state: FakeState,
    ) -> None:
        """Raw API exports use arrays for nodes/edges — replace_version normalizes."""
        _seed_index(client, cache_index, cache_manager)
        new_body: dict[str, Any] = {
            "name": "v2-draft",
            "created_at": "2025-01-01",  # server-only field, should be stripped
            "etag": "stale",  # server-only field, should be stripped
            "graph": {
                "nodes": [
                    {"id": "x1", "name": "in", "type": "input"},
                    {"id": "x2", "name": "out", "type": "output"},
                ],
                "edges": [{"id": "xe1", "start_node_id": "x1", "end_node_id": "x2"}],
                "node_groups": [],
            },
        }
        result = replace_version(
            client,
            cache_index,
            cache_manager,
            WS_ID,
            "credit-scoring",
            "v2-draft",
            new_body,
        )
        assert isinstance(result, VersionDetail)

        vid = cache_index.resolve_version_id("credit-scoring", "v2-draft")
        assert vid is not None
        graph_nodes = fake_state.versions[vid]["graph"]["nodes"]
        assert "x1" in graph_nodes
        assert "x2" in graph_nodes
        # Old nodes deleted
        assert "node_input" not in graph_nodes


class TestUpsertChildFlows:
    """Tests for _upsert_child_flows handling edge cases."""

    def test_skips_null_nodes(self, client: TktlClient) -> None:
        """Null nodes (from merge-patch deletions) should be skipped, not crash."""
        body: dict[str, Any] = {
            "graph": {
                "nodes": {
                    "n1": {"id": "n1", "type": "input", "name": "data", "meta": {}},
                    "n2": None,  # null-deleted node
                    "n3": None,
                    "n4": {"id": "n4", "type": "output", "name": "output", "meta": {}},
                },
            },
        }
        # Should not raise AttributeError
        result = _upsert_child_flows(client, WS_ID, body)
        assert result == {}
