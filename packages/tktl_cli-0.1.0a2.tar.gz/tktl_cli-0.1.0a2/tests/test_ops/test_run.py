"""Tests for ops.flows.run_flow — workspace Decide API execution."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import httpx

from tktl.api.client import TktlClient
from tktl.api.execution import _workspace_base_url_cache
from tktl.ops.flows import _coerce_booleans, run_flow


class TestCoerceBooleans:
    def test_coerces_top_level_booleans_to_strings(self) -> None:
        data = {"success": True, "active": False, "name": "test", "score": 42, "empty": None}
        result = _coerce_booleans(data)
        assert result["success"] == "true"
        assert result["active"] == "false"
        assert result["name"] == "test"
        assert result["score"] == 42
        assert result["empty"] is None

    def test_does_not_modify_original(self) -> None:
        data = {"flag": True}
        result = _coerce_booleans(data)
        assert data["flag"] is True  # original unchanged
        assert result["flag"] == "true"

    def test_coerces_nested_booleans(self) -> None:
        data = {"outer": {"inner": True}, "list_val": [1, 2]}
        result = _coerce_booleans(data)
        assert result["outer"]["inner"] == "true"
        assert result["list_val"] == [1, 2]


class TestRunFlow:
    def setup_method(self):
        _workspace_base_url_cache.clear()

    def test_run_flow_returns_result(self, tmp_path: Path) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            if "/api/v1/workspaces/" in str(request.url):
                return httpx.Response(200, json={"base_url": "https://fake-decide.com"})
            return httpx.Response(500)

        _write_config(tmp_path)
        _write_credentials(tmp_path, "key")
        transport = httpx.MockTransport(handler)
        client = TktlClient(config_dir=tmp_path, base_url="https://fake.com", transport=transport)

        decide_resp = httpx.Response(200, json={"data": {"decision": "approved"}, "status": "success", "metadata": {}})
        with patch("tktl.api.execution.httpx.post", return_value=decide_resp):
            result = run_flow(client, "ws_123", "credit-scoring", {"income": 50000}, version="v1")

        assert result["status"] == "success"
        assert result["data"]["decision"] == "approved"

    def test_run_flow_coerces_booleans(self, tmp_path: Path) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            if "/api/v1/workspaces/" in str(request.url):
                return httpx.Response(200, json={"base_url": "https://fake-decide.com"})
            return httpx.Response(500)

        _write_config(tmp_path)
        _write_credentials(tmp_path, "key")
        transport = httpx.MockTransport(handler)
        client = TktlClient(config_dir=tmp_path, base_url="https://fake.com", transport=transport)

        decide_resp = httpx.Response(200, json={"data": {}, "status": "success", "metadata": {}})
        with patch("tktl.api.execution.httpx.post", return_value=decide_resp) as mock_post:
            run_flow(client, "ws_123", "my-flow", {"success": True, "count": 5})

        call_kwargs = mock_post.call_args[1]
        sent_data = call_kwargs["json"]["data"]
        assert sent_data["success"] == "true"
        assert sent_data["count"] == 5

    def test_run_flow_passes_env(self, tmp_path: Path) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            if "/api/v1/workspaces/" in str(request.url):
                return httpx.Response(200, json={"base_url": "https://fake-decide.com"})
            return httpx.Response(500)

        _write_config(tmp_path)
        _write_credentials(tmp_path, "key")
        transport = httpx.MockTransport(handler)
        client = TktlClient(config_dir=tmp_path, base_url="https://fake.com", transport=transport)

        decide_resp = httpx.Response(200, json={"status": "success"})
        with patch("tktl.api.execution.httpx.post", return_value=decide_resp) as mock_post:
            run_flow(client, "ws_123", "my-flow", {}, env="live")

        args, _ = mock_post.call_args
        assert "/live/decide" in args[0]


# ---- helpers ----


def _write_config(tmp_path: Path) -> None:
    (tmp_path / "config.json").write_text(json.dumps({}))


def _write_credentials(tmp_path: Path, api_key: str) -> None:
    (tmp_path / "credentials.json").write_text(json.dumps({"api_key": api_key}))
