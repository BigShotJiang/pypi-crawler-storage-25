"""Tests for ops.graph: _parse_clause and the 422 non-retry behaviour."""

from __future__ import annotations

from typing import TYPE_CHECKING
from unittest.mock import patch

import pytest

from tktl.api.client import TktlClient
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.models.errors import ConflictError, UsageError
from tktl.ops.flows import describe_flow
from tktl.ops.graph import _parse_clause
from tktl.ops.nodes import update_node
from tktl.ops.versions import describe_version, update_version

if TYPE_CHECKING:
    from tests.fake_api.state import FakeState

WS_ID = "ws_00000000-0000-0000-0000-000000000001"


def _seed_cache(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
) -> None:
    describe_flow(client, cache_index, cache_manager, WS_ID, "credit-scoring")
    describe_version(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1")


# ---------------------------------------------------------------------------
# _parse_clause
# ---------------------------------------------------------------------------


class TestParseClause:
    def test_numeric_right_unquoted(self) -> None:
        result = _parse_clause("data.score < 30")
        assert result["left"] == "data.score"
        assert result["right"] == "30"
        assert result["operator"] == "lt"

    def test_float_right_unquoted(self) -> None:
        result = _parse_clause("data.refund_rate <= 0.10")
        assert result["right"] == "0.10"
        assert result["operator"] == "le"

    def test_string_right_auto_quoted(self) -> None:
        result = _parse_clause("data.status == APPROVED")
        assert result["right"] == '"APPROVED"'
        assert result["operator"] == "eq"

    def test_already_quoted_string_unchanged(self) -> None:
        result = _parse_clause('data.status == "APPROVED"')
        assert result["right"] == '"APPROVED"'

    def test_false_literal_not_quoted(self) -> None:
        """False must pass through unquoted so the engine evaluates it as bool."""
        result = _parse_clause("data.eligible == False")
        assert result["right"] == "False"
        assert result["operator"] == "eq"

    def test_true_literal_not_quoted(self) -> None:
        result = _parse_clause("data.is_active == True")
        assert result["right"] == "True"

    def test_none_literal_not_quoted(self) -> None:
        result = _parse_clause("data.value != None")
        assert result["right"] == "None"
        assert result["operator"] == "ne"

    def test_all_operators_mapped(self) -> None:
        cases = [
            ("data.x < 1", "lt"),
            ("data.x <= 1", "le"),
            ("data.x > 1", "gt"),
            ("data.x >= 1", "ge"),
            ("data.x == 1", "eq"),
            ("data.x != 1", "ne"),
        ]
        for clause, expected_op in cases:
            assert _parse_clause(clause)["operator"] == expected_op

    def test_empty_ids_for_auto_fill(self) -> None:
        result = _parse_clause("data.score > 50")
        assert result["id_left"] == ""
        assert result["id_right"] == ""

    def test_invalid_clause_raises_usage_error(self) -> None:
        with pytest.raises(UsageError):
            _parse_clause("not a valid clause")


# ---------------------------------------------------------------------------
# 422 non-retry: update_node and update_version must re-raise immediately
# ---------------------------------------------------------------------------


class TestValidationErrorNotRetried:
    def test_update_node_422_raises_immediately_not_retried(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        fake_state: FakeState,
    ) -> None:
        """A 422 validation error from patch_version must surface immediately,
        not be swallowed by the ETag retry loop and replaced with a misleading
        'modified N times' message."""
        _seed_cache(client, cache_index, cache_manager)

        patch_call_count = 0

        def counting_patch(*args, **kwargs):
            nonlocal patch_call_count
            patch_call_count += 1
            raise ConflictError("[validation] 1 validation error for RuleNodeMeta")

        with patch("tktl.ops.nodes.api_patch_version", side_effect=counting_patch):
            with pytest.raises(ConflictError, match=r"\[validation\]"):
                update_node(
                    client,
                    cache_index,
                    cache_manager,
                    WS_ID,
                    "credit-scoring",
                    "v1",
                    "node_risk",
                    meta={"branches": []},
                )

        # Must have given up after exactly 1 attempt, not 3
        assert patch_call_count == 1

    def test_update_version_422_raises_immediately(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        """Same guarantee for update_version."""
        _seed_cache(client, cache_index, cache_manager)

        patch_call_count = 0

        def counting_patch(*args, **kwargs):
            nonlocal patch_call_count
            patch_call_count += 1
            raise ConflictError("[validation] bad schema")

        with patch("tktl.ops.versions.api_patch_version", side_effect=counting_patch):
            with pytest.raises(ConflictError, match=r"\[validation\]"):
                update_version(
                    client,
                    cache_index,
                    cache_manager,
                    WS_ID,
                    "credit-scoring",
                    "v1",
                    params=[{"name": "x", "value": 1}],
                )

        assert patch_call_count == 1
