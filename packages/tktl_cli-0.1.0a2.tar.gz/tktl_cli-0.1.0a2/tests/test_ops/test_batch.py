"""Tests for batch run operations — file parsing, execution, and history."""

from __future__ import annotations

import json
from pathlib import Path

import httpx
import pytest

from tktl.api.client import TktlClient
from tktl.api.execution import _workspace_base_url_cache
from tktl.models.batch import BatchRowResult, BatchRunMeta
from tktl.models.errors import NotFoundError, UsageError
from tktl.ops.batch import (
    extract_query,
    get_batch_results,
    get_batch_run,
    list_batch_runs,
    parse_batch_file,
    run_batch,
)


# ---------------------------------------------------------------------------
# parse_batch_file — CSV
# ---------------------------------------------------------------------------


def test_parse_csv(tmp_path: Path):
    csv_file = tmp_path / "input.csv"
    csv_file.write_text("income,age,employed\n50000,30,true\n75000,45,false\n")
    rows = parse_batch_file(csv_file)
    assert len(rows) == 2
    assert rows[0] == {"income": 50000, "age": 30, "employed": True}
    assert rows[1] == {"income": 75000, "age": 45, "employed": False}


def test_parse_csv_float_values(tmp_path: Path):
    csv_file = tmp_path / "input.csv"
    csv_file.write_text("score,name\n0.85,Alice\n1.5,Bob\n")
    rows = parse_batch_file(csv_file)
    assert rows[0] == {"score": 0.85, "name": "Alice"}
    assert rows[1] == {"score": 1.5, "name": "Bob"}


def test_parse_csv_string_values(tmp_path: Path):
    csv_file = tmp_path / "input.csv"
    csv_file.write_text("name,city\nAlice,Berlin\nBob,London\n")
    rows = parse_batch_file(csv_file)
    assert rows[0] == {"name": "Alice", "city": "Berlin"}


# ---------------------------------------------------------------------------
# parse_batch_file — JSON
# ---------------------------------------------------------------------------


def test_parse_json_array(tmp_path: Path):
    json_file = tmp_path / "input.json"
    json_file.write_text(json.dumps([{"a": 1}, {"a": 2}]))
    rows = parse_batch_file(json_file)
    assert len(rows) == 2
    assert rows[0] == {"a": 1}
    assert rows[1] == {"a": 2}


def test_parse_json_single_object(tmp_path: Path):
    json_file = tmp_path / "input.json"
    json_file.write_text(json.dumps({"a": 1, "b": "hello"}))
    rows = parse_batch_file(json_file)
    assert len(rows) == 1
    assert rows[0] == {"a": 1, "b": "hello"}


def test_parse_json_non_object_in_array(tmp_path: Path):
    json_file = tmp_path / "input.json"
    json_file.write_text(json.dumps([{"a": 1}, "not an object"]))
    with pytest.raises(UsageError, match="Item 1.*not an object"):
        parse_batch_file(json_file)


def test_parse_json_invalid(tmp_path: Path):
    json_file = tmp_path / "input.json"
    json_file.write_text("{invalid json")
    with pytest.raises(UsageError, match="Invalid JSON"):
        parse_batch_file(json_file)


# ---------------------------------------------------------------------------
# parse_batch_file — JSONL
# ---------------------------------------------------------------------------


def test_parse_jsonl(tmp_path: Path):
    jsonl_file = tmp_path / "input.jsonl"
    jsonl_file.write_text('{"a": 1}\n{"a": 2}\n{"a": 3}\n')
    rows = parse_batch_file(jsonl_file)
    assert len(rows) == 3
    assert rows[2] == {"a": 3}


def test_parse_ndjson(tmp_path: Path):
    ndjson_file = tmp_path / "input.ndjson"
    ndjson_file.write_text('{"x": 10}\n{"x": 20}\n')
    rows = parse_batch_file(ndjson_file)
    assert len(rows) == 2


def test_parse_jsonl_blank_lines(tmp_path: Path):
    jsonl_file = tmp_path / "input.jsonl"
    jsonl_file.write_text('{"a": 1}\n\n{"a": 2}\n\n')
    rows = parse_batch_file(jsonl_file)
    assert len(rows) == 2


def test_parse_jsonl_invalid_line(tmp_path: Path):
    jsonl_file = tmp_path / "input.jsonl"
    jsonl_file.write_text('{"a": 1}\nnot json\n')
    with pytest.raises(UsageError, match="Invalid JSON on line 2"):
        parse_batch_file(jsonl_file)


def test_parse_jsonl_non_object_line(tmp_path: Path):
    jsonl_file = tmp_path / "input.jsonl"
    jsonl_file.write_text('{"a": 1}\n[1, 2, 3]\n')
    with pytest.raises(UsageError, match="Line 2.*not a JSON object"):
        parse_batch_file(jsonl_file)


# ---------------------------------------------------------------------------
# parse_batch_file — auto-detection
# ---------------------------------------------------------------------------


def test_parse_auto_detect_json_array(tmp_path: Path):
    f = tmp_path / "input.txt"
    f.write_text(json.dumps([{"a": 1}]))
    rows = parse_batch_file(f)
    assert len(rows) == 1


def test_parse_auto_detect_jsonl(tmp_path: Path):
    f = tmp_path / "input.txt"
    f.write_text('{"a": 1}\n{"a": 2}\n')
    rows = parse_batch_file(f)
    assert len(rows) == 2


def test_parse_auto_detect_csv(tmp_path: Path):
    f = tmp_path / "input.txt"
    f.write_text("x,y\n1,2\n3,4\n")
    rows = parse_batch_file(f)
    assert len(rows) == 2
    assert rows[0] == {"x": 1, "y": 2}


# ---------------------------------------------------------------------------
# parse_batch_file — validation
# ---------------------------------------------------------------------------


def test_parse_file_not_found():
    with pytest.raises(UsageError, match="File not found"):
        parse_batch_file(Path("/nonexistent/file.json"))


def test_parse_empty_file(tmp_path: Path):
    f = tmp_path / "empty.json"
    f.write_text("[]")
    with pytest.raises(UsageError, match="empty"):
        parse_batch_file(f)


def test_parse_too_many_rows(tmp_path: Path):
    rows = [{"i": i} for i in range(1001)]
    f = tmp_path / "big.json"
    f.write_text(json.dumps(rows))
    with pytest.raises(UsageError, match="1001 rows.*maximum is 1000"):
        parse_batch_file(f)


def test_parse_exactly_max_rows(tmp_path: Path):
    rows = [{"i": i} for i in range(1000)]
    f = tmp_path / "ok.json"
    f.write_text(json.dumps(rows))
    result = parse_batch_file(f)
    assert len(result) == 1000


# ---------------------------------------------------------------------------
# run_batch — execution
# ---------------------------------------------------------------------------


def _write_config(tmp_path: Path) -> None:
    (tmp_path / "config.json").write_text(json.dumps({}))


def _write_credentials(tmp_path: Path, api_key: str) -> None:
    (tmp_path / "credentials.json").write_text(json.dumps({"api_key": api_key}))


def _make_decide_transport(response_json: dict | None = None) -> httpx.MockTransport:
    """Create a sync MockTransport that returns a decide response (used as async transport)."""

    def handler(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content)
        resp_data = response_json or {"data": body.get("data", {}), "status": "success"}
        return httpx.Response(200, json=resp_data)

    return httpx.MockTransport(handler)


def _make_client(tmp_path: Path) -> TktlClient:
    config_dir = tmp_path / "config"
    config_dir.mkdir(exist_ok=True)
    _write_config(config_dir)
    _write_credentials(config_dir, "test-key")

    def handler(request: httpx.Request) -> httpx.Response:
        if "/api/v1/workspaces/" in str(request.url):
            return httpx.Response(200, json={"base_url": "https://fake-decide.com"})
        return httpx.Response(500)

    transport = httpx.MockTransport(handler)
    return TktlClient(config_dir=config_dir, base_url="https://fake.com", transport=transport)


class TestRunBatch:
    def setup_method(self):
        _workspace_base_url_cache.clear()

    def test_run_batch_all_succeed(self, tmp_path: Path) -> None:
        input_file = tmp_path / "input.json"
        input_file.write_text(json.dumps([{"a": 1}, {"a": 2}, {"a": 3}]))

        client = _make_client(tmp_path)
        runs_dir = tmp_path / "runs"
        decide_transport = _make_decide_transport()

        result = run_batch(
            client,
            "ws_123",
            "credit-scoring",
            file_path=input_file,
            version="v1",
            env="sandbox",
            concurrency=2,
            runs_dir=runs_dir,
            _transport=decide_transport,
        )

        assert result.meta.total_rows == 3
        assert result.meta.succeeded == 3
        assert result.meta.failed == 0
        assert result.meta.flow_slug == "credit-scoring"
        assert result.meta.env == "sandbox"
        assert result.meta.concurrency == 2
        assert result.meta.completed_at is not None
        assert result.meta.duration_ms is not None

        # Check results JSONL was written
        results_path = Path(result.results_path)
        assert results_path.exists()
        lines = results_path.read_text().strip().splitlines()
        assert len(lines) == 3
        first = json.loads(lines[0])
        assert first["output"]["status"] == "success"
        assert first["error"] is None

    def test_run_batch_with_errors(self, tmp_path: Path) -> None:
        input_file = tmp_path / "input.json"
        input_file.write_text(json.dumps([{"a": 1}, {"a": 2}]))

        client = _make_client(tmp_path)
        runs_dir = tmp_path / "runs"

        call_count = 0

        def error_handler(request: httpx.Request) -> httpx.Response:
            nonlocal call_count
            call_count += 1
            if call_count % 2 == 0:
                return httpx.Response(500, json={"error": "Server error"})
            body = json.loads(request.content)
            return httpx.Response(200, json={"data": body.get("data", {}), "status": "success"})

        decide_transport = httpx.MockTransport(error_handler)

        result = run_batch(
            client,
            "ws_123",
            "cs",
            file_path=input_file,
            env="sandbox",
            concurrency=1,
            runs_dir=runs_dir,
            _transport=decide_transport,
        )

        assert result.meta.total_rows == 2
        # Both should succeed since we return JSON for both (500 is still valid JSON)
        # The non-200 response still returns JSON; it's captured as output
        assert result.meta.succeeded + result.meta.failed == 2

    def test_run_batch_writes_meta(self, tmp_path: Path) -> None:
        input_file = tmp_path / "input.json"
        input_file.write_text(json.dumps([{"x": 1}]))

        client = _make_client(tmp_path)
        runs_dir = tmp_path / "runs"
        decide_transport = _make_decide_transport({"status": "ok"})

        result = run_batch(
            client,
            "ws_123",
            "my-flow",
            file_path=input_file,
            env="sandbox",
            concurrency=5,
            runs_dir=runs_dir,
            _transport=decide_transport,
        )

        # Verify meta.json was written
        meta_path = runs_dir / "my-flow" / result.meta.run_id / "meta.json"
        assert meta_path.exists()
        meta = BatchRunMeta.model_validate_json(meta_path.read_text())
        assert meta.run_id == result.meta.run_id
        assert meta.source == str(input_file)

    def test_run_batch_updates_index(self, tmp_path: Path) -> None:
        input_file = tmp_path / "input.json"
        input_file.write_text(json.dumps([{"x": 1}]))

        client = _make_client(tmp_path)
        runs_dir = tmp_path / "runs"
        decide_transport = _make_decide_transport({"status": "ok"})

        run_batch(
            client,
            "ws_123",
            "my-flow",
            file_path=input_file,
            env="sandbox",
            runs_dir=runs_dir,
            _transport=decide_transport,
        )

        # Verify index.json was written
        index_path = runs_dir / "my-flow" / "index.json"
        assert index_path.exists()
        index = json.loads(index_path.read_text())
        assert len(index["runs"]) == 1


# ---------------------------------------------------------------------------
# History — list, get, get_results
# ---------------------------------------------------------------------------


class TestBatchHistory:
    def test_list_batch_runs_empty(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        result = list_batch_runs("my-flow", runs_dir=runs_dir)
        assert result == []

    def test_list_batch_runs_with_data(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        flow_dir = runs_dir / "my-flow"
        flow_dir.mkdir(parents=True)
        index = {
            "runs": [
                {
                    "run_id": "abc",
                    "source_type": "file",
                    "source": "input.csv",
                    "source_hash": "sha256:000",
                    "total_rows": 5,
                    "succeeded": 5,
                    "failed": 0,
                    "started_at": "2026-03-20T10:00:00Z",
                    "duration_ms": 1000,
                }
            ]
        }
        (flow_dir / "index.json").write_text(json.dumps(index))
        result = list_batch_runs("my-flow", runs_dir=runs_dir)
        assert len(result) == 1
        assert result[0].run_id == "abc"

    def test_get_batch_run(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        run_dir = runs_dir / "my-flow" / "run-1"
        run_dir.mkdir(parents=True)
        meta = {
            "run_id": "run-1",
            "flow_slug": "my-flow",
            "env": "sandbox",
            "version": None,
            "source_type": "file",
            "source": "input.csv",
            "source_hash": "sha256:abc",
            "concurrency": 10,
            "total_rows": 3,
            "succeeded": 3,
            "failed": 0,
            "started_at": "2026-03-20T10:00:00Z",
            "completed_at": "2026-03-20T10:00:01Z",
            "duration_ms": 1000,
        }
        (run_dir / "meta.json").write_text(json.dumps(meta))
        result = get_batch_run("my-flow", "run-1", runs_dir=runs_dir)
        assert result.run_id == "run-1"
        assert result.total_rows == 3

    def test_get_batch_run_not_found(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        with pytest.raises(NotFoundError, match="not found"):
            get_batch_run("my-flow", "nonexistent", runs_dir=runs_dir)

    def test_get_batch_results(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        run_dir = runs_dir / "my-flow" / "run-1"
        run_dir.mkdir(parents=True)

        row1 = BatchRowResult(
            row_index=0,
            input={"a": 1},
            output={"b": 2},
            error=None,
            duration_ms=100,
            timestamp="2026-03-20T10:00:00Z",
        )
        row2 = BatchRowResult(
            row_index=1,
            input={"a": 3},
            output=None,
            error="fail",
            duration_ms=50,
            timestamp="2026-03-20T10:00:01Z",
        )
        with open(run_dir / "results.jsonl", "w") as f:
            f.write(row1.model_dump_json() + "\n")
            f.write(row2.model_dump_json() + "\n")

        results = get_batch_results("my-flow", "run-1", runs_dir=runs_dir)
        assert len(results) == 2
        assert results[0].row_index == 0
        assert results[0].output == {"b": 2}
        assert results[1].error == "fail"

    def test_get_batch_results_not_found(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        with pytest.raises(NotFoundError, match="not found"):
            get_batch_results("my-flow", "nonexistent", runs_dir=runs_dir)


# ---------------------------------------------------------------------------
# extract_query — dot/bracket path extraction
# ---------------------------------------------------------------------------


class TestExtractQuery:
    def test_simple_key(self):
        data = {"name": "Alice"}
        assert extract_query(data, "name") == "Alice"

    def test_nested_key(self):
        data = {"data": {"decision": "approve"}}
        assert extract_query(data, "data.decision") == "approve"

    def test_array_index(self):
        data = {"items": ["a", "b", "c"]}
        assert extract_query(data, "items[0]") == "a"
        assert extract_query(data, "items[2]") == "c"

    def test_nested_with_array(self):
        data = {"data": {"scores": [{"value": 0.8}, {"value": 0.9}]}}
        assert extract_query(data, "data.scores[1].value") == 0.9

    def test_deeply_nested(self):
        data = {"a": {"b": {"c": {"d": 42}}}}
        assert extract_query(data, "a.b.c.d") == 42

    def test_missing_key_returns_none(self):
        data = {"name": "Alice"}
        assert extract_query(data, "missing") is None

    def test_missing_nested_key_returns_none(self):
        data = {"a": {"b": 1}}
        assert extract_query(data, "a.c.d") is None

    def test_index_out_of_range_returns_none(self):
        data = {"items": [1, 2]}
        assert extract_query(data, "items[5]") is None

    def test_index_on_non_list_returns_none(self):
        data = {"items": "not a list"}
        assert extract_query(data, "items[0]") is None

    def test_whole_object(self):
        data = {"a": {"b": 1}}
        assert extract_query(data, "a") == {"b": 1}

    def test_none_input(self):
        assert extract_query(None, "a.b") is None
