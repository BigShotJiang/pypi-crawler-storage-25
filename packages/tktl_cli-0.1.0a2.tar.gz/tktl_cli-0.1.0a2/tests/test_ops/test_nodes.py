"""Tests for ops.nodes — list_nodes, get_node."""

from __future__ import annotations

import pytest

from tktl.api.client import TktlClient
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.models.errors import NotFoundError
from tktl.models.node import NodeDetail, NodeSummary
from tktl.ops.flows import describe_flow
from tktl.ops.nodes import get_node, list_nodes
from tktl.ops.versions import describe_version

WS_ID = "ws_00000000-0000-0000-0000-000000000001"


def _seed_cache(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
) -> None:
    """Seed the cache by describing flow and version."""
    describe_flow(client, cache_index, cache_manager, WS_ID, "credit-scoring")
    describe_version(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1")


class TestListNodes:
    def test_returns_node_summary_list(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        result = list_nodes(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1")
        assert isinstance(result, list)
        assert len(result) == 4
        assert all(isinstance(n, NodeSummary) for n in result)

    def test_node_summary_fields(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        result = list_nodes(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1")
        ids = {n.id for n in result}
        assert "node_risk" in ids
        assert "node_input" in ids
        for n in result:
            assert n.id
            assert n.name
            assert n.type

    def test_fetches_version_if_not_cached(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        """list_nodes should fetch and cache the version if node index is empty."""
        describe_flow(client, cache_index, cache_manager, WS_ID, "credit-scoring")
        # Don't call describe_version — nodes not cached yet
        result = list_nodes(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1")
        assert len(result) == 4


class TestGetNode:
    def test_returns_node_detail(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        result = get_node(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1", "node_risk")
        assert isinstance(result, NodeDetail)
        assert result.id == "node_risk"
        assert result.name == "Risk Engine"
        assert result.type == "decision_table"

    def test_node_has_meta(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        result = get_node(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1", "node_risk")
        assert result.meta is not None
        assert result.meta["score_threshold"] == 500

    def test_section_filter_meta(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        """When section='meta', only the meta field should be populated."""
        _seed_cache(client, cache_index, cache_manager)
        result = get_node(
            client,
            cache_index,
            cache_manager,
            WS_ID,
            "credit-scoring",
            "v1",
            "node_risk",
            section="meta",
        )
        assert isinstance(result, NodeDetail)
        assert result.meta is not None

    def test_not_found_raises(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        with pytest.raises(NotFoundError):
            get_node(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1", "nonexistent")

    def test_reads_from_cache(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        """After seeding, get_node should read from cached per-node files."""
        _seed_cache(client, cache_index, cache_manager)
        # First call
        r1 = get_node(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1", "node_risk")
        # Second call should also work (from cache)
        r2 = get_node(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1", "node_risk")
        assert r1.id == r2.id
        assert r1.meta == r2.meta
