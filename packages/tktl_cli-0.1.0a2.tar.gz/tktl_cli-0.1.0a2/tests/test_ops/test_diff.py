"""Tests for ops.diff — compute_diff and per-type diff functions."""

from __future__ import annotations

from typing import Any

from tktl.models.diff import ChangeKind
from tktl.ops.diff import compute_diff


def _make_version(
    *,
    nodes: dict[str, dict[str, Any]] | None = None,
    parameters: list[dict[str, Any]] | None = None,
    input_schema: dict[str, Any] | None = None,
    output_schema: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build a minimal raw version dict for testing."""
    raw: dict[str, Any] = {}
    if parameters is not None:
        raw["parameters"] = parameters
    if input_schema is not None:
        raw["input_schema"] = input_schema
    if output_schema is not None:
        raw["output_schema"] = output_schema
    if nodes is not None:
        raw["graph"] = {"nodes": nodes, "edges": {}}
    return raw


# ---------------------------------------------------------------------------
# Identical versions
# ---------------------------------------------------------------------------


class TestIdenticalVersions:
    def test_empty_versions(self) -> None:
        diff = compute_diff("s", "v1", "v2", {}, {})
        assert not diff.has_changes

    def test_same_content(self) -> None:
        v = _make_version(
            parameters=[{"name": "x", "value": 1}],
            nodes={"n1": {"name": "Risk", "type": "decision_table", "meta": {"cases": []}}},
        )
        diff = compute_diff("s", "v1", "v2", v, v)
        assert not diff.has_changes


# ---------------------------------------------------------------------------
# Parameter changes
# ---------------------------------------------------------------------------


class TestParameterChanges:
    def test_param_added(self) -> None:
        v1 = _make_version(parameters=[])
        v2 = _make_version(parameters=[{"name": "threshold", "value": 0.8}])
        diff = compute_diff("s", "v1", "v2", v1, v2)
        assert len(diff.parameter_changes) == 1
        pc = diff.parameter_changes[0]
        assert pc.name == "threshold"
        assert pc.kind == ChangeKind.added
        assert pc.new_value == 0.8

    def test_param_removed(self) -> None:
        v1 = _make_version(parameters=[{"name": "threshold", "value": 0.8}])
        v2 = _make_version(parameters=[])
        diff = compute_diff("s", "v1", "v2", v1, v2)
        assert len(diff.parameter_changes) == 1
        assert diff.parameter_changes[0].kind == ChangeKind.removed
        assert diff.parameter_changes[0].old_value == 0.8

    def test_param_modified(self) -> None:
        v1 = _make_version(parameters=[{"name": "threshold", "value": 0.8}])
        v2 = _make_version(parameters=[{"name": "threshold", "value": 0.9}])
        diff = compute_diff("s", "v1", "v2", v1, v2)
        assert len(diff.parameter_changes) == 1
        pc = diff.parameter_changes[0]
        assert pc.kind == ChangeKind.modified
        assert pc.old_value == 0.8
        assert pc.new_value == 0.9


# ---------------------------------------------------------------------------
# Schema changes
# ---------------------------------------------------------------------------


class TestSchemaChanges:
    def test_input_field_added(self) -> None:
        v1 = _make_version(input_schema={"properties": {"a": {"type": "string"}}})
        v2 = _make_version(input_schema={"properties": {"a": {"type": "string"}, "b": {"type": "number"}}})
        diff = compute_diff("s", "v1", "v2", v1, v2)
        assert len(diff.schema_changes) == 1
        sc = diff.schema_changes[0]
        assert sc.schema_type == "input"
        assert sc.kind == ChangeKind.added
        assert sc.field == "b"

    def test_output_field_removed(self) -> None:
        v1 = _make_version(output_schema={"properties": {"decision": {"type": "string"}}})
        v2 = _make_version(output_schema={"properties": {}})
        diff = compute_diff("s", "v1", "v2", v1, v2)
        assert len(diff.schema_changes) == 1
        assert diff.schema_changes[0].kind == ChangeKind.removed
        assert diff.schema_changes[0].field == "decision"


# ---------------------------------------------------------------------------
# Structural changes
# ---------------------------------------------------------------------------


class TestStructuralChanges:
    def test_node_added(self) -> None:
        v1 = _make_version(nodes={})
        v2 = _make_version(nodes={"n1": {"name": "New Node", "type": "rule_2", "meta": {}}})
        diff = compute_diff("s", "v1", "v2", v1, v2)
        assert len(diff.structural_changes) == 1
        assert diff.structural_changes[0].kind == ChangeKind.added
        assert diff.structural_changes[0].node_name == "New Node"

    def test_node_removed(self) -> None:
        v1 = _make_version(nodes={"n1": {"name": "Old Node", "type": "rule_2", "meta": {}}})
        v2 = _make_version(nodes={})
        diff = compute_diff("s", "v1", "v2", v1, v2)
        assert len(diff.structural_changes) == 1
        assert diff.structural_changes[0].kind == ChangeKind.removed

    def test_node_type_changed(self) -> None:
        v1 = _make_version(nodes={"n1": {"name": "Risk", "type": "rule_2", "meta": {}}})
        v2 = _make_version(nodes={"n2": {"name": "Risk", "type": "decision_table", "meta": {}}})
        diff = compute_diff("s", "v1", "v2", v1, v2)
        assert any(
            sc.kind == ChangeKind.modified and "type changed" in (sc.detail or "") for sc in diff.structural_changes
        )

    def test_scaffolding_filtered(self) -> None:
        v1 = _make_version(
            nodes={
                "inp": {"name": "Input", "type": "input", "meta": {}},
                "out": {"name": "Output", "type": "output", "meta": {}},
                "br": {"name": "Branch", "type": "transform", "meta": {"is_split_branch_node": True}},
                "mg": {"name": "Merge", "type": "transform", "meta": {"is_split_merge_node": True}},
                "real": {"name": "Real", "type": "rule_2", "meta": {}},
            }
        )
        v2 = _make_version(nodes={})
        diff = compute_diff("s", "v1", "v2", v1, v2)
        names = {sc.node_name for sc in diff.structural_changes}
        assert "Real" in names
        assert "Input" not in names
        assert "Output" not in names
        assert "Branch" not in names
        assert "Merge" not in names

    def test_name_based_matching_different_ids(self) -> None:
        v1 = _make_version(nodes={"id_aaa": {"name": "Risk", "type": "rule_2", "meta": {"x": 1}}})
        v2 = _make_version(nodes={"id_zzz": {"name": "Risk", "type": "rule_2", "meta": {"x": 1}}})
        diff = compute_diff("s", "v1", "v2", v1, v2)
        assert not diff.structural_changes
        assert not diff.logic_changes


# ---------------------------------------------------------------------------
# Logic changes — per-type
# ---------------------------------------------------------------------------


class TestDecisionTableDiff:
    def test_case_count_changed(self) -> None:
        v1 = _make_version(nodes={"n": {"name": "DT", "type": "decision_table", "meta": {"cases": [{"name": "r1"}]}}})
        v2 = _make_version(
            nodes={
                "n": {
                    "name": "DT",
                    "type": "decision_table",
                    "meta": {"cases": [{"name": "r1"}, {"name": "r2"}, {"name": "r3"}]},
                }
            }
        )
        diff = compute_diff("s", "v1", "v2", v1, v2)
        assert len(diff.logic_changes) == 1
        fields = {c.field for c in diff.logic_changes[0].changes}
        assert "rules" in fields

    def test_fallback_changed(self) -> None:
        v1 = _make_version(
            nodes={"n": {"name": "DT", "type": "decision_table", "meta": {"fallback": {"d": "approve"}}}}
        )
        v2 = _make_version(nodes={"n": {"name": "DT", "type": "decision_table", "meta": {"fallback": {"d": "reject"}}}})
        diff = compute_diff("s", "v1", "v2", v1, v2)
        fields = {c.field for c in diff.logic_changes[0].changes}
        assert "fallback" in fields


class TestScorecardDiff:
    def test_weight_changed(self) -> None:
        factor = lambda w: {"input_field": {"value": "bureau"}, "weight": {"value": w}, "cases": []}  # noqa: E731
        v1 = _make_version(nodes={"n": {"name": "SC", "type": "scorecard", "meta": {"factors": [factor(33)]}}})
        v2 = _make_version(nodes={"n": {"name": "SC", "type": "scorecard", "meta": {"factors": [factor(50)]}}})
        diff = compute_diff("s", "v1", "v2", v1, v2)
        assert len(diff.logic_changes) == 1
        fc = diff.logic_changes[0].changes[0]
        assert fc.field == "factor 'bureau' weight"
        assert fc.old == 33
        assert fc.new == 50

    def test_factor_added(self) -> None:
        f1 = {"input_field": {"value": "bureau"}, "weight": {"value": 100}, "cases": []}
        f2_new = {"input_field": {"value": "ml_score"}, "weight": {"value": 50}, "cases": []}
        v1 = _make_version(nodes={"n": {"name": "SC", "type": "scorecard", "meta": {"factors": [f1]}}})
        v2 = _make_version(nodes={"n": {"name": "SC", "type": "scorecard", "meta": {"factors": [f1, f2_new]}}})
        diff = compute_diff("s", "v1", "v2", v1, v2)
        added = [c for c in diff.logic_changes[0].changes if c.kind == ChangeKind.added]
        assert len(added) == 1
        assert "ml_score" in added[0].field


class TestTransformDiff:
    def test_code_changed(self) -> None:
        v1 = _make_version(nodes={"n": {"name": "T", "type": "transform", "meta": {"src": "x = 1\ny = 2"}}})
        v2 = _make_version(nodes={"n": {"name": "T", "type": "transform", "meta": {"src": "x = 1\ny = 2\nz = 3"}}})
        diff = compute_diff("s", "v1", "v2", v1, v2)
        assert len(diff.logic_changes) == 1
        fc = diff.logic_changes[0].changes[0]
        assert fc.field == "code"
        assert fc.old == "x = 1\ny = 2"
        assert fc.new == "x = 1\ny = 2\nz = 3"


# ---------------------------------------------------------------------------
# Integration changes
# ---------------------------------------------------------------------------


class TestIntegrationChanges:
    def test_manifest_routed_to_integration(self) -> None:
        meta1 = {"provider_resource": {"provider": "experian", "resource": "credit_report"}}
        meta2 = {"provider_resource": {"provider": "transunion", "resource": "credit_report"}}
        v1 = _make_version(nodes={"n": {"name": "CB", "type": "manifest_connection_node", "meta": meta1}})
        v2 = _make_version(nodes={"n": {"name": "CB", "type": "manifest_connection_node", "meta": meta2}})
        diff = compute_diff("s", "v1", "v2", v1, v2)
        assert len(diff.logic_changes) == 0
        assert len(diff.integration_changes) == 1
        ic = diff.integration_changes[0]
        assert ic.kind == ChangeKind.modified
        assert ic.provider == "transunion"
        provider_change = [c for c in ic.changes if c.field == "provider"]
        assert len(provider_change) == 1
        assert provider_change[0].old == "experian"

    def test_added_integration_node(self) -> None:
        v1 = _make_version(nodes={})
        v2 = _make_version(
            nodes={
                "n": {
                    "name": "API",
                    "type": "custom_connection_node",
                    "meta": {"provider_resource": {"provider": "custom", "resource": "http"}},
                }
            }
        )
        diff = compute_diff("s", "v1", "v2", v1, v2)
        assert len(diff.integration_changes) == 1
        assert diff.integration_changes[0].kind == ChangeKind.added
        # Also appears in structural
        assert any(sc.node_name == "API" for sc in diff.structural_changes)


# ---------------------------------------------------------------------------
# Generic fallback
# ---------------------------------------------------------------------------


class TestGenericFallback:
    def test_unknown_type_shallow_diff(self) -> None:
        v1 = _make_version(nodes={"n": {"name": "X", "type": "unknown_type", "meta": {"a": 1, "b": 2}}})
        v2 = _make_version(nodes={"n": {"name": "X", "type": "unknown_type", "meta": {"a": 1, "b": 3, "c": 4}}})
        diff = compute_diff("s", "v1", "v2", v1, v2)
        assert len(diff.logic_changes) == 1
        fields = {c.field: c.kind for c in diff.logic_changes[0].changes}
        assert fields["b"] == ChangeKind.modified
        assert fields["c"] == ChangeKind.added
