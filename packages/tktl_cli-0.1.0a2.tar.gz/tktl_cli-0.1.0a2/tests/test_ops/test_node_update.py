"""Tests for ops.nodes.update_node — node-level write with locking."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from tktl.api.client import TktlClient
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.models.errors import ConflictError, NotFoundError
from tktl.models.node import NodeDetail
from tktl.ops.flows import describe_flow
from tktl.ops.nodes import update_node
from tktl.ops.versions import describe_version

if TYPE_CHECKING:
    from tests.fake_api.state import FakeState

WS_ID = "ws_00000000-0000-0000-0000-000000000001"


def _seed_cache(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
) -> None:
    describe_flow(client, cache_index, cache_manager, WS_ID, "credit-scoring")
    describe_version(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1")


class TestUpdateNode:
    def test_basic_meta_update(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        result = update_node(
            client,
            cache_index,
            cache_manager,
            WS_ID,
            "credit-scoring",
            "v1",
            "node_risk",
            meta={"score_threshold": 750},
        )
        assert isinstance(result, NodeDetail)
        assert result.id == "node_risk"
        assert result.meta is not None
        assert result.meta["score_threshold"] == 750

    def test_deep_merges_meta(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        """update_node should deep-merge, preserving existing meta keys."""
        _seed_cache(client, cache_index, cache_manager)
        result = update_node(
            client,
            cache_index,
            cache_manager,
            WS_ID,
            "credit-scoring",
            "v1",
            "node_risk",
            meta={"new_field": "hello"},
        )
        assert result.meta is not None
        # Original field should still be there
        assert result.meta["score_threshold"] == 500
        # New field should be added
        assert result.meta["new_field"] == "hello"

    def test_only_target_node_in_patch(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        fake_state: FakeState,
    ) -> None:
        """The PATCH body should only contain the target node, not all nodes."""
        _seed_cache(client, cache_index, cache_manager)
        update_node(
            client,
            cache_index,
            cache_manager,
            WS_ID,
            "credit-scoring",
            "v1",
            "node_risk",
            meta={"score_threshold": 800},
        )
        # Verify other nodes are unaffected by reading them from state
        version_id = cache_index.resolve_version_id("credit-scoring", "v1")
        assert version_id is not None
        version = fake_state.versions[version_id]
        # The pricing node should still have its original meta
        pricing_node = version["graph"]["nodes"]["node_pricing"]
        assert pricing_node["meta"]["base_rate"] == 0.05

    def test_cache_updated_after_update(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        update_node(
            client,
            cache_index,
            cache_manager,
            WS_ID,
            "credit-scoring",
            "v1",
            "node_risk",
            meta={"score_threshold": 900},
        )
        # Read from cache — should reflect the update
        flow_id = cache_index.resolve_flow_id("credit-scoring")
        version_id = cache_index.resolve_version_id("credit-scoring", "v1")
        assert flow_id is not None
        assert version_id is not None
        cached_node = cache_manager.read_node(version_id, flow_id, "node_risk")
        assert cached_node is not None
        assert cached_node["meta"]["score_threshold"] == 900

    def test_node_not_found_raises(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        with pytest.raises(NotFoundError):
            update_node(
                client,
                cache_index,
                cache_manager,
                WS_ID,
                "credit-scoring",
                "v1",
                "nonexistent",
                meta={"x": 1},
            )

    def test_lock_conflict_raises(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        fake_state: FakeState,
    ) -> None:
        """If the node is locked by another session, update should raise ConflictError."""
        _seed_cache(client, cache_index, cache_manager)

        version_id = cache_index.resolve_version_id("credit-scoring", "v1")
        assert version_id is not None

        # Inject a lock into the fake state
        fake_state.versions[version_id]["locks"] = [
            {
                "id": "existing_lock",
                "owner": "other-user",
                "session": "other-session",
                "resource_type": "node",
                "resource_id": "node_risk",
                "duration_secs": 300,
            }
        ]

        with pytest.raises(ConflictError):
            update_node(
                client,
                cache_index,
                cache_manager,
                WS_ID,
                "credit-scoring",
                "v1",
                "node_risk",
                meta={"x": 1},
            )

    def test_force_breaks_lock(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        fake_state: FakeState,
    ) -> None:
        """With force=True, should proceed even with existing lock."""
        _seed_cache(client, cache_index, cache_manager)

        version_id = cache_index.resolve_version_id("credit-scoring", "v1")
        assert version_id is not None

        # Inject a lock
        fake_state.versions[version_id]["locks"] = [
            {
                "id": "existing_lock",
                "owner": "other-user",
                "session": "other-session",
                "resource_type": "node",
                "resource_id": "node_risk",
                "duration_secs": 300,
            }
        ]

        result = update_node(
            client,
            cache_index,
            cache_manager,
            WS_ID,
            "credit-scoring",
            "v1",
            "node_risk",
            meta={"score_threshold": 999},
            force=True,
        )
        assert result.meta is not None
        assert result.meta["score_threshold"] == 999
