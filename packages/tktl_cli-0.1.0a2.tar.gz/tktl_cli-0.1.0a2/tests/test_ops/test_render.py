"""Tests for ops.render — graph_to_mermaid, extract_mermaid_blocks, render_mermaid_png."""

from __future__ import annotations

import re
import uuid
from datetime import datetime

import graphviz as gv
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from tktl.models.errors import RenderError
from tktl.ops.render import (
    _build_split_edge_labels,
    _format_clause,
    _normalize_newlines,
    build_flow_url,
    extract_mermaid_blocks,
    graph_to_mermaid,
    preview_version_graph,
    render_mermaid_png,
)


def _uid() -> str:
    return str(uuid.uuid4())


def _simple_graph() -> dict[str, Any]:
    """input → assignment → output (3 nodes, 2 edges)."""
    n_input = _uid()
    n_assign = _uid()
    n_output = _uid()
    e1 = _uid()
    e2 = _uid()
    return {
        "nodes": {
            n_input: {"id": n_input, "name": "data", "type": "input", "meta": {}},
            n_assign: {"id": n_assign, "name": "Init", "type": "assignment_node", "meta": {"default_effects": []}},
            n_output: {"id": n_output, "name": "output", "type": "output", "meta": {}},
        },
        "edges": {
            e1: {"id": e1, "start_node_id": n_input, "end_node_id": n_assign, "meta": {"is_split_edge": False}},
            e2: {"id": e2, "start_node_id": n_assign, "end_node_id": n_output, "meta": {"is_split_edge": False}},
        },
    }


def _split_graph() -> dict[str, Any]:
    """input → split → [branch_a, branch_b] → merge → output."""
    n_input = _uid()
    n_split = _uid()
    n_branch_a = _uid()
    n_branch_b = _uid()
    n_merge = _uid()
    n_output = _uid()
    e_in = _uid()
    e_a = _uid()
    e_b = _uid()
    e_ma = _uid()
    e_mb = _uid()
    e_out = _uid()
    return {
        "nodes": {
            n_input: {"id": n_input, "name": "data", "type": "input", "meta": {}},
            n_split: {
                "id": n_split,
                "name": "Score Gate",
                "type": "split_2",
                "meta": {
                    "default_edge_id": e_b,
                    "branches": [
                        {
                            "id": "",
                            "junction": "and",
                            "edge_id": e_a,
                            "clauses": [{"left": "data.score", "right": "30", "operator": "lt"}],
                        },
                        {"id": "", "junction": "and", "edge_id": e_b, "clauses": []},
                    ],
                },
            },
            n_branch_a: {
                "id": n_branch_a,
                "name": "Rejected",
                "type": "transform",
                "meta": {"src": "", "is_split_branch_node": True},
            },
            n_branch_b: {
                "id": n_branch_b,
                "name": "Accepted",
                "type": "transform",
                "meta": {"src": "", "is_split_branch_node": True},
            },
            n_merge: {
                "id": n_merge,
                "name": "Merge Node",
                "type": "transform",
                "meta": {"src": "", "is_split_merge_node": True},
            },
            n_output: {"id": n_output, "name": "output", "type": "output", "meta": {}},
        },
        "edges": {
            e_in: {"id": e_in, "start_node_id": n_input, "end_node_id": n_split, "meta": {"is_split_edge": False}},
            e_a: {"id": e_a, "start_node_id": n_split, "end_node_id": n_branch_a, "meta": {"is_split_edge": True}},
            e_b: {"id": e_b, "start_node_id": n_split, "end_node_id": n_branch_b, "meta": {"is_split_edge": True}},
            e_ma: {"id": e_ma, "start_node_id": n_branch_a, "end_node_id": n_merge, "meta": {"is_split_edge": False}},
            e_mb: {"id": e_mb, "start_node_id": n_branch_b, "end_node_id": n_merge, "meta": {"is_split_edge": False}},
            e_out: {"id": e_out, "start_node_id": n_merge, "end_node_id": n_output, "meta": {"is_split_edge": False}},
        },
    }


class TestGraphToMermaid:
    def test_empty_graph_returns_flowchart_header(self) -> None:
        result = graph_to_mermaid({"nodes": {}, "edges": {}})
        assert result.startswith("flowchart TD")

    def test_classdefs_are_present(self) -> None:
        result = graph_to_mermaid(_simple_graph())
        assert "classDef io" in result
        assert "classDef assign" in result
        assert "classDef split" in result

    def test_open_class_has_dashed_border(self) -> None:
        result = graph_to_mermaid(_simple_graph())
        assert "stroke-dasharray" in result

    def test_simple_graph_io_nodes_have_type_and_name(self) -> None:
        result = graph_to_mermaid(_simple_graph())
        assert "Input" in result
        assert "Output" in result
        assert "<b>data</b>" in result
        assert "<b>output</b>" in result

    def test_simple_graph_assignment_has_rich_label(self) -> None:
        result = graph_to_mermaid(_simple_graph())
        assert "Assignment" in result
        assert "<b>Init</b>" in result

    def test_simple_graph_nodes_have_class_applied(self) -> None:
        result = graph_to_mermaid(_simple_graph())
        assert ":::io" in result
        assert ":::assign" in result

    def test_simple_graph_contains_two_edges(self) -> None:
        result = graph_to_mermaid(_simple_graph())
        assert result.count("-->") >= 2

    def test_split_graph_has_rectangle_with_type(self) -> None:
        result = graph_to_mermaid(_split_graph())
        assert "Split" in result
        assert "<b>Score Gate</b>" in result

    def test_split_graph_branch_nodes_are_rectangles(self) -> None:
        result = graph_to_mermaid(_split_graph())
        assert "Rejected" in result
        assert "Accepted" in result

    def test_split_graph_merge_is_circle(self) -> None:
        result = graph_to_mermaid(_split_graph())
        assert "(( ))" in result

    def test_split_edges_show_condition(self) -> None:
        result = graph_to_mermaid(_split_graph())
        # Clause data.score < 30 → should appear as "score < 30"
        assert "score < 30" in result

    def test_split_default_edge_shows_default(self) -> None:
        result = graph_to_mermaid(_split_graph())
        assert "default" in result

    def test_node_type_rich_labels(self) -> None:
        nid = _uid()
        out_id = _uid()
        eid = _uid()
        for ntype, expected_type in [
            ("rule_2", "Rule"),
            ("decision_table", "Decision Table"),
            ("scorecard", "Scorecard"),
            ("matrix_table", "2D Matrix"),
            ("custom_connection_node", "Connection"),
        ]:
            graph = {
                "nodes": {
                    nid: {"id": nid, "name": "My Node", "type": ntype, "meta": {}},
                    out_id: {"id": out_id, "name": "output", "type": "output", "meta": {}},
                },
                "edges": {
                    eid: {
                        "id": eid,
                        "start_node_id": nid,
                        "end_node_id": out_id,
                        "meta": {"is_split_edge": False},
                    },
                },
            }
            result = graph_to_mermaid(graph)
            assert expected_type in result, f"Expected '{expected_type}' for type '{ntype}'"
            assert "<b>My Node</b>" in result

    def test_ai_node_uses_ui_label(self) -> None:
        nid = _uid()
        out_id = _uid()
        eid = _uid()
        graph = {
            "nodes": {
                nid: {"id": nid, "name": "My Node", "type": "ai_node_v2", "meta": {}},
                out_id: {"id": out_id, "name": "output", "type": "output", "meta": {}},
            },
            "edges": {
                eid: {"id": eid, "start_node_id": nid, "end_node_id": out_id, "meta": {"is_split_edge": False}},
            },
        }
        result = graph_to_mermaid(graph)
        assert "AI" in result

    def test_no_legend_subgraph(self) -> None:
        result = graph_to_mermaid(_simple_graph())
        assert "subgraph Legend" not in result

    def test_missing_graph_keys_dont_crash(self) -> None:
        result = graph_to_mermaid({})
        assert result.startswith("flowchart TD")

    def test_edge_with_none_meta(self) -> None:
        """Edge whose meta is explicitly None should not crash (regression)."""
        n_in = _uid()
        n_out = _uid()
        eid = _uid()
        graph: dict[str, Any] = {
            "nodes": {
                n_in: {"id": n_in, "name": "data", "type": "input", "meta": {}},
                n_out: {"id": n_out, "name": "output", "type": "output", "meta": {}},
            },
            "edges": {
                eid: {"id": eid, "start_node_id": n_in, "end_node_id": n_out, "meta": None},
            },
        }
        result = graph_to_mermaid(graph)
        assert "-->" in result

    def test_edge_with_missing_meta(self) -> None:
        """Edge with no meta key at all should not crash."""
        n_in = _uid()
        n_out = _uid()
        eid = _uid()
        graph: dict[str, Any] = {
            "nodes": {
                n_in: {"id": n_in, "name": "data", "type": "input", "meta": {}},
                n_out: {"id": n_out, "name": "output", "type": "output", "meta": {}},
            },
            "edges": {
                eid: {"id": eid, "start_node_id": n_in, "end_node_id": n_out},
            },
        }
        result = graph_to_mermaid(graph)
        assert "-->" in result

    def test_node_with_none_meta(self) -> None:
        """Node whose meta is explicitly None should not crash."""
        n_in = _uid()
        n_out = _uid()
        eid = _uid()
        graph: dict[str, Any] = {
            "nodes": {
                n_in: {"id": n_in, "name": "data", "type": "input", "meta": None},
                n_out: {"id": n_out, "name": "output", "type": "output", "meta": None},
            },
            "edges": {
                eid: {"id": eid, "start_node_id": n_in, "end_node_id": n_out, "meta": {"is_split_edge": False}},
            },
        }
        result = graph_to_mermaid(graph)
        assert "Input" in result
        assert "-->" in result

    def test_node_with_missing_meta(self) -> None:
        """Node with no meta key at all should not crash."""
        n_in = _uid()
        n_out = _uid()
        eid = _uid()
        graph: dict[str, Any] = {
            "nodes": {
                n_in: {"id": n_in, "name": "data", "type": "input"},
                n_out: {"id": n_out, "name": "output", "type": "output"},
            },
            "edges": {
                eid: {"id": eid, "start_node_id": n_in, "end_node_id": n_out, "meta": {"is_split_edge": False}},
            },
        }
        result = graph_to_mermaid(graph)
        assert "-->" in result

    def test_split_node_with_none_meta(self) -> None:
        """Split node with None meta should not crash _build_split_edge_labels."""
        n_in = _uid()
        n_split = _uid()
        n_out = _uid()
        e1 = _uid()
        e2 = _uid()
        graph: dict[str, Any] = {
            "nodes": {
                n_in: {"id": n_in, "name": "data", "type": "input", "meta": {}},
                n_split: {"id": n_split, "name": "Gate", "type": "split_2", "meta": None},
                n_out: {"id": n_out, "name": "output", "type": "output", "meta": {}},
            },
            "edges": {
                e1: {"id": e1, "start_node_id": n_in, "end_node_id": n_split, "meta": {"is_split_edge": False}},
                e2: {"id": e2, "start_node_id": n_split, "end_node_id": n_out, "meta": {"is_split_edge": True}},
            },
        }
        result = graph_to_mermaid(graph)
        assert "Gate" in result

    def test_edge_referencing_unknown_nodes_skipped(self) -> None:
        """Edges referencing non-existent node IDs should be silently skipped."""
        n_in = _uid()
        n_out = _uid()
        e_good = _uid()
        e_bad = _uid()
        graph: dict[str, Any] = {
            "nodes": {
                n_in: {"id": n_in, "name": "data", "type": "input", "meta": {}},
                n_out: {"id": n_out, "name": "output", "type": "output", "meta": {}},
            },
            "edges": {
                e_good: {"id": e_good, "start_node_id": n_in, "end_node_id": n_out, "meta": {"is_split_edge": False}},
                e_bad: {"id": e_bad, "start_node_id": "ghost", "end_node_id": n_out, "meta": {"is_split_edge": False}},
            },
        }
        result = graph_to_mermaid(graph)
        assert result.count("-->") == 1

    def test_none_nodes_and_edges(self) -> None:
        """Graph with nodes=None and edges=None should not crash."""
        result = graph_to_mermaid({"nodes": None, "edges": None})
        assert result.startswith("flowchart TD")


class TestGroupRendering:
    def _grouped_graph(self) -> dict[str, Any]:
        """Graph with 2 groups: Scoring (assign+rule) and I/O (input+output)."""
        n_input = _uid()
        n_assign = _uid()
        n_rule = _uid()
        n_output = _uid()
        g_scoring = _uid()
        return {
            "nodes": {
                n_input: {"id": n_input, "name": "data", "type": "input", "meta": {}},
                n_assign: {"id": n_assign, "name": "Init", "type": "assignment_node", "meta": {}},
                n_rule: {"id": n_rule, "name": "Check", "type": "rule_2", "meta": {}},
                n_output: {"id": n_output, "name": "output", "type": "output", "meta": {}},
            },
            "edges": {
                _uid(): {"start_node_id": n_input, "end_node_id": n_assign, "meta": {"is_split_edge": False}},
                _uid(): {"start_node_id": n_assign, "end_node_id": n_rule, "meta": {"is_split_edge": False}},
                _uid(): {"start_node_id": n_rule, "end_node_id": n_output, "meta": {"is_split_edge": False}},
            },
            "node_groups": {
                g_scoring: {"id": g_scoring, "name": "Scoring", "node_ids": [n_assign, n_rule]},
            },
        }

    def test_mermaid_contains_subgraph(self) -> None:
        result = graph_to_mermaid(self._grouped_graph())
        assert "subgraph" in result
        assert "Scoring" in result
        assert "end" in result

    def test_mermaid_grouped_nodes_inside_subgraph(self) -> None:
        result = graph_to_mermaid(self._grouped_graph())
        # The subgraph should contain the assignment and rule nodes
        assert "Assignment" in result
        assert "Rule" in result

    def test_mermaid_ungrouped_nodes_outside_subgraph(self) -> None:
        result = graph_to_mermaid(self._grouped_graph())
        # Input and Output should be declared outside subgraphs
        lines = result.split("\n")
        in_subgraph = False
        ungrouped_outside = True
        for line in lines:
            if "subgraph" in line:
                in_subgraph = True
            if line.strip() == "end":
                in_subgraph = False
            if in_subgraph and ("Input" in line or "Output" in line):
                ungrouped_outside = False
        assert ungrouped_outside

    def test_mermaid_subgraph_style(self) -> None:
        result = graph_to_mermaid(self._grouped_graph())
        assert "style G0 fill:#F3F4F6" in result

    def test_mermaid_no_groups_no_subgraph(self) -> None:
        result = graph_to_mermaid(_simple_graph())
        assert "subgraph" not in result

    def test_mermaid_empty_node_groups(self) -> None:
        graph = _simple_graph()
        graph["node_groups"] = {}
        result = graph_to_mermaid(graph)
        assert "subgraph" not in result


class TestNormalizeNewlines:
    def test_literal_backslash_n_in_label_becomes_br(self) -> None:
        code = 'flowchart TD\n    A["rule\\nCredit Check"]'
        result = _normalize_newlines(code)
        assert "<br/>" in result
        assert "\\n" not in result

    def test_actual_newline_in_label_becomes_br(self) -> None:
        code = 'flowchart TD\n    A["rule\nCredit Check"]'
        result = _normalize_newlines(code)
        assert '"rule<br/>Credit Check"' in result

    def test_structural_newlines_preserved(self) -> None:
        code = 'flowchart TD\n    A["hello"] --> B["world"]'
        result = _normalize_newlines(code)
        # Structural newline between lines must survive
        assert "\n" in result
        assert "A" in result and "B" in result

    def test_no_labels_unchanged(self) -> None:
        code = "flowchart TD\n    A --> B"
        assert _normalize_newlines(code) == code


class TestExtractMermaidBlocks:
    def test_no_blocks_returns_empty_list(self) -> None:
        assert extract_mermaid_blocks("# Hello\nNo diagrams here.") == []

    def test_single_block(self) -> None:
        md = "# Flow\n```mermaid\nflowchart TD\n  A --> B\n```\nDone."
        blocks = extract_mermaid_blocks(md)
        assert len(blocks) == 1
        assert "flowchart TD" in blocks[0]
        assert "A --> B" in blocks[0]

    def test_multiple_blocks(self) -> None:
        md = "```mermaid\nflowchart TD\n  A --> B\n```\n\n```mermaid\nflowchart TD\n  C --> D\n```"
        blocks = extract_mermaid_blocks(md)
        assert len(blocks) == 2

    def test_non_mermaid_blocks_ignored(self) -> None:
        md = "```python\nprint('hello')\n```\n```mermaid\nflowchart TD\n  A --> B\n```"
        blocks = extract_mermaid_blocks(md)
        assert len(blocks) == 1

    def test_strips_leading_trailing_whitespace(self) -> None:
        md = "```mermaid\n  flowchart TD\n  A --> B  \n```"
        blocks = extract_mermaid_blocks(md)
        assert blocks[0] == blocks[0].strip()


def _fake_graphviz_render(mock_dot: MagicMock) -> None:
    """Configure a mock Digraph so .render() creates a fake PNG file."""

    def _render(filename: str = "", cleanup: bool = False) -> str:
        Path(f"{filename}.png").write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 100)
        return f"{filename}.png"

    mock_dot.render.side_effect = _render


class TestRenderMermaidPng:
    def test_success_writes_file(self, tmp_path: Path) -> None:
        mock_dot = MagicMock()
        _fake_graphviz_render(mock_dot)
        with patch("tktl.ops.render.graphviz.Digraph", return_value=mock_dot):
            result = render_mermaid_png("flowchart TD\n  A --> B", tmp_path)

        assert result.exists()
        assert result.suffix == ".png"

    def test_timestamp_in_filename(self, tmp_path: Path) -> None:
        mock_dot = MagicMock()
        _fake_graphviz_render(mock_dot)
        with patch("tktl.ops.render.graphviz.Digraph", return_value=mock_dot):
            result = render_mermaid_png("flowchart TD\n  A --> B", tmp_path)

        assert re.match(r"\d{8}_\d{6}(-\d+)?\.png", result.name)

    def test_creates_out_dir_if_missing(self, tmp_path: Path) -> None:
        out_dir = tmp_path / "new" / "dir"
        assert not out_dir.exists()

        mock_dot = MagicMock()
        _fake_graphviz_render(mock_dot)
        with patch("tktl.ops.render.graphviz.Digraph", return_value=mock_dot):
            render_mermaid_png("flowchart TD\n  A --> B", out_dir)

        assert out_dir.exists()

    def test_graphviz_not_found_raises_render_error(self, tmp_path: Path) -> None:
        mock_dot = MagicMock()
        mock_dot.render.side_effect = gv.ExecutableNotFound(args=["dot"])
        with patch("tktl.ops.render.graphviz.Digraph", return_value=mock_dot):
            with pytest.raises(RenderError, match="dot"):
                render_mermaid_png("flowchart TD\n  A --> B", tmp_path)

    def test_collision_appends_suffix(self, tmp_path: Path) -> None:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        (tmp_path / f"{ts}.png").write_bytes(b"existing")

        mock_dot = MagicMock()
        _fake_graphviz_render(mock_dot)
        with patch("tktl.ops.render.graphviz.Digraph", return_value=mock_dot):
            result = render_mermaid_png("flowchart TD\n  A --> B", tmp_path)

        assert result.name == f"{ts}-1.png"

    def test_collision_skips_existing_suffixed_files(self, tmp_path: Path) -> None:
        """When both base and -1 exist, should pick -2."""
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        (tmp_path / f"{ts}.png").write_bytes(b"existing")
        (tmp_path / f"{ts}-1.png").write_bytes(b"existing")

        mock_dot = MagicMock()
        _fake_graphviz_render(mock_dot)
        with patch("tktl.ops.render.graphviz.Digraph", return_value=mock_dot):
            result = render_mermaid_png("flowchart TD\n  A --> B", tmp_path)

        assert result.name == f"{ts}-2.png"


class TestFormatClause:
    def test_standard_clause(self) -> None:
        clause = {"left": "data.score", "operator": "lt", "right": "30"}
        assert _format_clause(clause) == "score < 30"

    def test_empty_left_returns_empty(self) -> None:
        clause = {"left": "", "operator": "lt", "right": "30"}
        assert _format_clause(clause) == ""

    def test_is_none_operator_omits_right(self) -> None:
        clause = {"left": "data.age", "operator": "is_none"}
        assert _format_clause(clause) == "age is null"

    def test_is_not_none_operator_omits_right(self) -> None:
        clause = {"left": "data.status", "operator": "is_not_none"}
        assert _format_clause(clause) == "status not null"

    def test_is_any_operator_omits_right(self) -> None:
        clause = {"left": "data.country", "operator": "is_any"}
        assert _format_clause(clause) == "country any"

    def test_params_prefix_stripped(self) -> None:
        clause = {"left": "params.threshold", "operator": "gt", "right": "50"}
        assert _format_clause(clause) == "threshold > 50"

    def test_unknown_operator_uses_raw(self) -> None:
        clause = {"left": "data.x", "operator": "weird_op", "right": "1"}
        assert _format_clause(clause) == "x weird_op 1"


class TestBuildSplitEdgeLabels:
    def test_branch_without_edge_id_skipped(self) -> None:
        """Branches with empty edge_id are skipped."""
        nid = _uid()
        nodes = {
            nid: {
                "type": "split_2",
                "meta": {
                    "default_edge_id": "",
                    "branches": [
                        {"edge_id": "", "clauses": [{"left": "data.x", "operator": "lt", "right": "5"}]},
                    ],
                },
            },
        }
        labels = _build_split_edge_labels(nodes)
        assert labels == {}


class TestBuildFlowUrl:
    _BASE_ARGS = ("https://app.taktile.com", "org1", "ws1", "flow1", "v1")

    def test_base_url_no_params(self) -> None:
        url = build_flow_url(*self._BASE_ARGS)
        assert url == "https://app.taktile.com/decide/org/org1/ws/ws1/flow/flow1/version/v1"

    def test_power_tools(self) -> None:
        url = build_flow_url(*self._BASE_ARGS, power_tools=True)
        assert "power-tools=true" in url

    def test_left_pane(self) -> None:
        url = build_flow_url(*self._BASE_ARGS, left_pane="datasets")
        assert "left-pane=datasets" in url

    def test_decision_id(self) -> None:
        url = build_flow_url(*self._BASE_ARGS, decision_id="dec-123")
        assert "decision-id=dec-123" in url

    def test_node_id_and_right_pane(self) -> None:
        url = build_flow_url(*self._BASE_ARGS, node_id="n1", right_pane_tab="logic")
        assert "node=n1" in url
        assert "right-pane-tab=logic" in url

    def test_all_params(self) -> None:
        url = build_flow_url(
            *self._BASE_ARGS,
            power_tools=True,
            left_pane="schema",
            decision_id="d1",
            node_id="n1",
            right_pane_tab="settings",
        )
        assert "?" in url
        qs = url.split("?")[1]
        parts = qs.split("&")
        assert len(parts) == 5


class TestPreviewVersionGraph:
    def test_uses_cache_when_available(self, tmp_path: Path) -> None:
        """Should read from cache, convert graph, and render PNG."""
        graph = {"nodes": {}, "edges": {}}
        raw = {"graph": graph}

        mock_client = MagicMock()
        mock_cache_index = MagicMock()
        mock_cache_mgr = MagicMock()
        mock_cache_mgr.read_full_version.return_value = raw

        fake_png = tmp_path / "out.png"
        fake_png.write_bytes(b"PNG")

        with (
            patch("tktl.ops.render._resolve_ids", return_value=("flow-1", "ver-1")),
            patch("tktl.ops.render.render_graph_png", return_value=fake_png) as mock_render,
        ):
            result = preview_version_graph(mock_client, mock_cache_index, mock_cache_mgr, "ws1", "slug", "v1")

        assert result == fake_png
        mock_cache_mgr.read_full_version.assert_called_once_with("ver-1", "flow-1")
        mock_render.assert_called_once()

    def test_fetches_when_cache_miss(self, tmp_path: Path) -> None:
        """Should fetch from API when cache returns None."""
        graph = {"nodes": {}, "edges": {}}
        raw = {"graph": graph}

        mock_client = MagicMock()
        mock_cache_index = MagicMock()
        mock_cache_mgr = MagicMock()
        mock_cache_mgr.read_full_version.return_value = None

        fake_png = tmp_path / "out.png"
        fake_png.write_bytes(b"PNG")

        with (
            patch("tktl.ops.render._resolve_ids", return_value=("flow-1", "ver-1")),
            patch("tktl.ops.render._fetch_and_cache_version", return_value=raw) as mock_fetch,
            patch("tktl.ops.render.render_graph_png", return_value=fake_png),
        ):
            result = preview_version_graph(mock_client, mock_cache_index, mock_cache_mgr, "ws1", "slug", "v1")

        assert result == fake_png
        mock_fetch.assert_called_once_with(mock_client, mock_cache_mgr, "flow-1", "ver-1")
