"""Tests for ops.flows — list_flows, describe_flow, run_flow."""

from __future__ import annotations

from typing import TYPE_CHECKING

from tktl.api.client import TktlClient
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.models.flow import FlowDetail, FlowSummary
from tktl.ops.flows import describe_flow, list_flows

if TYPE_CHECKING:
    from tests.fake_api.state import FakeState

WS_ID = "ws_00000000-0000-0000-0000-000000000001"


class TestListFlows:
    def test_returns_flow_summary_list(
        self,
        client: TktlClient,
        cache_manager: CacheManager,
    ) -> None:
        result = list_flows(client, cache_manager, WS_ID)
        assert isinstance(result, list)
        assert len(result) == 3
        assert all(isinstance(f, FlowSummary) for f in result)

    def test_flow_summary_fields(
        self,
        client: TktlClient,
        cache_manager: CacheManager,
    ) -> None:
        result = list_flows(client, cache_manager, WS_ID)
        slugs = {f.slug for f in result}
        assert "credit-scoring" in slugs
        assert "kyc-check" in slugs
        for f in result:
            assert f.id
            assert f.name


class TestDescribeFlow:
    def test_returns_flow_detail(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        result = describe_flow(client, cache_index, cache_manager, WS_ID, "credit-scoring")
        assert isinstance(result, FlowDetail)
        assert result.slug == "credit-scoring"
        assert result.workspace_id == WS_ID

    def test_updates_cache_index(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        describe_flow(client, cache_index, cache_manager, WS_ID, "credit-scoring")
        # After describe, cache index should have the flow
        flow_id = cache_index.resolve_flow_id("credit-scoring")
        assert flow_id is not None
        # And version mappings
        v1_id = cache_index.resolve_version_id("credit-scoring", "v1")
        assert v1_id is not None

    def test_caches_flow_metadata(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        fake_state: FakeState,
    ) -> None:
        describe_flow(client, cache_index, cache_manager, WS_ID, "credit-scoring")
        flow_id = cache_index.resolve_flow_id("credit-scoring")
        assert flow_id is not None
        cached = cache_manager.read_flow_metadata(flow_id)
        assert cached is not None
        assert cached["slug"] == "credit-scoring"
