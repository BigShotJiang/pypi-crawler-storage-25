"""Tests for PostHog telemetry instrumentation across all ops functions."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import httpx
import pytest

from tktl.api.client import TktlClient
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.models.errors import NotFoundError
from tktl.ops.cache_ops import cache_status, clear_cache, refresh_cache
from tktl.ops.flows import describe_flow, list_flows, run_flow
from tktl.ops.nodes import get_node, list_nodes, update_node
from tktl.ops.versions import (
    archive_version,
    create_version,
    describe_version,
    duplicate_version,
    list_changes,
    list_versions,
    publish_version,
    replace_version,
    update_version,
)
from tktl.telemetry import _state

WS_ID = "ws_00000000-0000-0000-0000-000000000001"


@pytest.fixture(autouse=True)
def _mock_telemetry():
    """Set up a mock PostHog client for all tests in this module."""
    mock_client = MagicMock()
    _state.client = mock_client
    _state.distinct_id = "test-user"
    _state.disabled = False
    _state.source = "library"
    yield mock_client
    _state.client = None
    _state.distinct_id = None
    _state.disabled = False
    _state.source = "library"


def _get_tracked_events(mock_client: MagicMock) -> list[dict]:
    """Extract all tracked events from the mock client."""
    events = []
    for call in mock_client.capture.call_args_list:
        events.append({"event": call[1]["event"], **call[1]["properties"]})
    return events


def _seed_cache(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
) -> None:
    describe_flow(client, cache_index, cache_manager, WS_ID, "credit-scoring")
    describe_version(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1")


# ---- Phase 2: Reads ----


class TestReadOps:
    def test_list_flows_tracks_event(
        self,
        client: TktlClient,
        cache_manager: CacheManager,
        _mock_telemetry: MagicMock,
    ) -> None:
        list_flows(client, cache_manager, WS_ID)
        events = _get_tracked_events(_mock_telemetry)
        op_events = [e for e in events if e.get("op") == "list_flows"]
        assert len(op_events) == 1
        ev = op_events[0]
        assert ev["event"] == "tktl_operation"
        assert ev["success"] is True
        assert isinstance(ev["output_tokens"], int)
        assert ev["output_tokens"] > 0
        assert "duration_ms" in ev

    def test_describe_flow_tracks_event_with_slug(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        _mock_telemetry: MagicMock,
    ) -> None:
        describe_flow(client, cache_index, cache_manager, WS_ID, "credit-scoring")
        events = _get_tracked_events(_mock_telemetry)
        op_events = [e for e in events if e.get("op") == "describe_flow"]
        assert len(op_events) == 1
        assert op_events[0]["flow_slug"] == "credit-scoring"
        assert op_events[0]["success"] is True
        assert op_events[0]["output_tokens"] > 0

    def test_list_versions_tracks_event(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        _mock_telemetry: MagicMock,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        _mock_telemetry.capture.reset_mock()
        list_versions(client, cache_index, cache_manager, WS_ID, "credit-scoring")
        events = _get_tracked_events(_mock_telemetry)
        op_events = [e for e in events if e.get("op") == "list_versions"]
        assert len(op_events) == 1
        assert op_events[0]["flow_slug"] == "credit-scoring"
        assert op_events[0]["success"] is True

    def test_describe_version_tracks_event(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        _mock_telemetry: MagicMock,
    ) -> None:
        describe_flow(client, cache_index, cache_manager, WS_ID, "credit-scoring")
        _mock_telemetry.capture.reset_mock()
        describe_version(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1")
        events = _get_tracked_events(_mock_telemetry)
        op_events = [e for e in events if e.get("op") == "describe_version"]
        assert len(op_events) == 1
        assert op_events[0]["flow_slug"] == "credit-scoring"
        assert op_events[0]["flow_version_name"] == "v1"

    def test_list_changes_tracks_event(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        _mock_telemetry: MagicMock,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        _mock_telemetry.capture.reset_mock()
        list_changes(client, cache_index, WS_ID, "credit-scoring", "v1")
        events = _get_tracked_events(_mock_telemetry)
        op_events = [e for e in events if e.get("op") == "list_changes"]
        assert len(op_events) == 1
        assert op_events[0]["flow_slug"] == "credit-scoring"
        assert op_events[0]["flow_version_name"] == "v1"

    def test_list_nodes_tracks_with_cache_hit(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        _mock_telemetry: MagicMock,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        _mock_telemetry.capture.reset_mock()
        list_nodes(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1")
        events = _get_tracked_events(_mock_telemetry)
        op_events = [e for e in events if e.get("op") == "list_nodes"]
        assert len(op_events) == 1
        assert op_events[0]["cache_hit"] is True

    def test_get_node_tracks_with_cache_miss(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        _mock_telemetry: MagicMock,
    ) -> None:
        # Seed flow but NOT version — so node data won't be cached
        describe_flow(client, cache_index, cache_manager, WS_ID, "credit-scoring")
        _mock_telemetry.capture.reset_mock()
        get_node(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1", "node_risk")
        events = _get_tracked_events(_mock_telemetry)
        op_events = [e for e in events if e.get("op") == "get_node"]
        assert len(op_events) == 1
        assert op_events[0]["cache_hit"] is False
        assert op_events[0]["output_tokens"] > 0

    def test_get_node_not_found_tracks_error(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        _mock_telemetry: MagicMock,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        _mock_telemetry.capture.reset_mock()
        with pytest.raises(NotFoundError):
            get_node(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1", "nonexistent")
        events = _get_tracked_events(_mock_telemetry)
        op_events = [e for e in events if e.get("op") == "get_node"]
        assert len(op_events) == 1
        assert op_events[0]["success"] is False
        assert op_events[0]["error_type"] == "NotFoundError"
        assert op_events[0]["output_tokens"] == 0


# ---- Phase 3: Writes ----


class TestWriteOps:
    def test_update_node_tracks_event(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        _mock_telemetry: MagicMock,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        _mock_telemetry.capture.reset_mock()
        update_node(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1", "node_risk", meta={"x": 1})
        events = _get_tracked_events(_mock_telemetry)
        op_events = [e for e in events if e.get("op") == "update_node"]
        assert len(op_events) == 1
        ev = op_events[0]
        assert ev["success"] is True
        assert ev["output_tokens"] > 0
        assert ev["etag_retries"] == 0
        assert ev["flow_slug"] == "credit-scoring"
        assert ev["flow_version_name"] == "v1"

    def test_update_version_tracks_event(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        _mock_telemetry: MagicMock,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        _mock_telemetry.capture.reset_mock()
        update_version(
            client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1", params=[{"name": "p", "value": 1}]
        )
        events = _get_tracked_events(_mock_telemetry)
        op_events = [e for e in events if e.get("op") == "update_version"]
        assert len(op_events) == 1
        assert op_events[0]["success"] is True
        assert "etag_retries" in op_events[0]

    def test_publish_version_tracks_event(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        _mock_telemetry: MagicMock,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        _mock_telemetry.capture.reset_mock()
        publish_version(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1")
        events = _get_tracked_events(_mock_telemetry)
        op_events = [e for e in events if e.get("op") == "publish_version"]
        assert len(op_events) == 1
        assert op_events[0]["success"] is True
        assert op_events[0]["flow_slug"] == "credit-scoring"

    def test_archive_version_tracks_event(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        _mock_telemetry: MagicMock,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        _mock_telemetry.capture.reset_mock()
        archive_version(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1")
        events = _get_tracked_events(_mock_telemetry)
        op_events = [e for e in events if e.get("op") == "archive_version"]
        assert len(op_events) == 1
        assert op_events[0]["success"] is True

    def test_create_version_tracks_event(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        _mock_telemetry: MagicMock,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        _mock_telemetry.capture.reset_mock()
        create_version(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v99")
        events = _get_tracked_events(_mock_telemetry)
        op_events = [e for e in events if e.get("op") == "create_version"]
        assert len(op_events) == 1
        assert op_events[0]["success"] is True

    def test_duplicate_version_tracks_event(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        _mock_telemetry: MagicMock,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        _mock_telemetry.capture.reset_mock()
        duplicate_version(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1", "v1-copy")
        events = _get_tracked_events(_mock_telemetry)
        op_events = [e for e in events if e.get("op") == "duplicate_version"]
        assert len(op_events) == 1
        assert op_events[0]["success"] is True

    def test_replace_version_tracks_event(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        _mock_telemetry: MagicMock,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        _mock_telemetry.capture.reset_mock()
        replace_version(
            client,
            cache_index,
            cache_manager,
            WS_ID,
            "credit-scoring",
            "v1",
            body={
                "name": "v1-replaced",
                "status": "DRAFT",
                "graph": {
                    "nodes": {"n1": {"id": "n1", "name": "N", "type": "input"}},
                    "edges": {},
                    "node_groups": {},
                },
            },
        )
        events = _get_tracked_events(_mock_telemetry)
        op_events = [e for e in events if e.get("op") == "replace_version"]
        assert len(op_events) == 1
        assert op_events[0]["success"] is True
        assert "etag_retries" in op_events[0]


# ---- Phase 4: Run + Cache ----


class TestE2EWorkflow:
    """End-to-end test: full agent workflow emitting correct telemetry events."""

    def test_full_agent_session(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        _mock_telemetry: MagicMock,
    ) -> None:
        _mock_telemetry.capture.reset_mock()

        # Step 1: list flows
        list_flows(client, cache_manager, WS_ID)

        # Step 2: describe flow
        describe_flow(client, cache_index, cache_manager, WS_ID, "credit-scoring")

        # Step 3: list nodes (first call — should be cache miss since version not yet fetched)
        list_nodes(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1")

        # Step 4: get node (should be cache hit — version was fetched in step 3)
        get_node(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1", "node_risk")

        # Step 5: update node
        update_node(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1", "node_risk", meta={"x": 1})

        events = _get_tracked_events(_mock_telemetry)
        op_names = [e["op"] for e in events]

        assert "list_flows" in op_names
        assert "describe_flow" in op_names
        assert "list_nodes" in op_names
        assert "get_node" in op_names
        assert "update_node" in op_names

        # All events should be successful
        for ev in events:
            assert ev["success"] is True

        # Total output tokens across session should be reasonable
        total_tokens = sum(e.get("output_tokens", 0) for e in events)
        assert total_tokens > 0
        assert total_tokens < 100000

        # Cache hit tracking: get_node should show cache_hit=True (data cached by list_nodes)
        get_node_events = [e for e in events if e["op"] == "get_node"]
        assert get_node_events[0]["cache_hit"] is True


class TestRunAndCacheOps:
    def test_run_flow_tracks_flow_execution(
        self,
        client: TktlClient,
        _mock_telemetry: MagicMock,
    ) -> None:
        decide_resp = httpx.Response(
            200, json={"data": {"decision": "approved"}, "status": "success", "metadata": {"decision_id": "d-1"}}
        )
        # Mock workspace resolution + decide call
        with (
            patch("tktl.api.execution._resolve_workspace_base_url", return_value="https://fake-decide.com"),
            patch("tktl.api.execution.httpx.post", return_value=decide_resp),
        ):
            _mock_telemetry.capture.reset_mock()
            run_flow(client, WS_ID, "credit-scoring", {"income": 50000}, version="v1", env="sandbox")

        events = _get_tracked_events(_mock_telemetry)
        op_events = [e for e in events if e.get("op") == "run_flow"]
        assert len(op_events) == 1
        ev = op_events[0]
        assert ev["event"] == "tktl_flow_execution"
        assert ev["success"] is True
        assert ev["input_tokens"] > 0
        assert ev["output_tokens"] > 0
        assert ev["flow_slug"] == "credit-scoring"
        assert ev["env"] == "sandbox"
        assert ev["decision_id"] == "d-1"

    def test_refresh_cache_tracks_event(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        _mock_telemetry: MagicMock,
    ) -> None:
        _mock_telemetry.capture.reset_mock()
        refresh_cache(client, cache_index, cache_manager, WS_ID)
        events = _get_tracked_events(_mock_telemetry)
        op_events = [e for e in events if e.get("op") == "refresh_cache"]
        assert len(op_events) == 1
        assert op_events[0]["output_tokens"] == 0

    def test_clear_cache_tracks_event(
        self,
        cache_manager: CacheManager,
        _mock_telemetry: MagicMock,
    ) -> None:
        _mock_telemetry.capture.reset_mock()
        clear_cache(cache_manager)
        events = _get_tracked_events(_mock_telemetry)
        op_events = [e for e in events if e.get("op") == "clear_cache"]
        assert len(op_events) == 1
        assert op_events[0]["output_tokens"] == 0

    def test_cache_status_tracks_event(
        self,
        cache_manager: CacheManager,
        _mock_telemetry: MagicMock,
    ) -> None:
        _mock_telemetry.capture.reset_mock()
        cache_status(cache_manager)
        events = _get_tracked_events(_mock_telemetry)
        op_events = [e for e in events if e.get("op") == "cache_status"]
        assert len(op_events) == 1
        assert op_events[0]["output_tokens"] >= 0
