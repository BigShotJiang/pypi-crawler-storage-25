"""Tests for the dataset operations layer."""

from __future__ import annotations

from pathlib import Path

import pytest

import tktl.api.datasets as ds_mod
from tests.conftest import WS_ID
from tests.fake_api.seed import SeedFlow, SeedNode, SeedVersion, build_seed_state
from tests.fake_api.state import FakeDataset, FakeDatasetColumn, FakeDatasetRow, FakeState
from tests.test_api.conftest import FAKE_BASE_URL, make_sync_transport, write_test_config, write_test_credentials
from tests.test_api.test_datasets_crud import _make_httpx_bridge
from tktl.api import execution as _execution
from tktl.api.client import TktlClient
from tktl.ops import datasets as _ds_mod
from tktl.cache.index import CacheIndex
from tktl.models.dataset import ColumnGroup, ColumnType, DatasetColumn
from tktl.models.errors import UsageError
from tktl.ops.datasets import (
    add_blank_rows,
    add_column,
    add_rows,
    create_dataset,
    create_from_schema,
    delete_column,
    delete_dataset,
    delete_row,
    describe_dataset,
    download_dataset,
    fill_column,
    get_rows,
    list_datasets,
    rename_column,
    sync_schema,
    update_row,
)


@pytest.fixture
def ops_state() -> FakeState:
    """State with flows, versions, and a dataset."""
    state = build_seed_state(
        flows=[
            SeedFlow(
                slug="credit-scoring",
                versions=[
                    SeedVersion(
                        name="v1",
                        status="PUBLISHED",
                        nodes=[
                            SeedNode(id="node_input", name="Input", type="input"),
                            SeedNode(id="node_output", name="Output", type="output"),
                        ],
                        input_schema={
                            "type": "object",
                            "properties": {
                                "income": {"type": "number"},
                                "age": {"type": "integer"},
                                "name": {"type": "string"},
                            },
                        },
                    ),
                ],
            ),
        ],
    )

    cs_flow_id = next(f["id"] for f in state.flows.values() if f["slug"] == "credit-scoring")
    ds_id = "ds-test-001"
    state.datasets[ds_id] = FakeDataset(
        dataset_id=ds_id,
        flow_id=cs_flow_id,
        name="Test Dataset",
        etag="etag-ops-1",
        rows=[],
        input_columns=[
            FakeDatasetColumn(name="income", desired_type="number"),
            FakeDatasetColumn(name="old_field", desired_type="string"),
        ],
        mock_columns=[],
        dataset_rows=[
            FakeDatasetRow(id="row-a", input_data={"income": 50000}),
            FakeDatasetRow(id="row-b", input_data={"income": 75000}),
            FakeDatasetRow(id="row-c", input_data={"income": 30000}),
        ],
    )
    return state


@pytest.fixture
def client(tmp_path: Path, ops_state: FakeState) -> TktlClient:
    write_test_config(tmp_path)
    write_test_credentials(tmp_path, "fake-key")
    transport = make_sync_transport(ops_state)
    return TktlClient(config_dir=tmp_path, base_url=FAKE_BASE_URL, transport=transport)


@pytest.fixture
def cache_index(tmp_path: Path) -> CacheIndex:
    return CacheIndex(tmp_path / "cache")


@pytest.fixture(autouse=True)
def _patch_ws_and_httpx(ops_state: FakeState, monkeypatch: pytest.MonkeyPatch) -> None:
    """Monkeypatch workspace auth + route httpx through ASGI."""
    # Patch workspace resolution to return fake-key + fake URL
    monkeypatch.setattr(_ds_mod, "_get_ws_auth", lambda client, ws_id: ("fake-key", FAKE_BASE_URL))

    # Patch httpx in datasets module to go through ASGI bridge
    get, post, patch, put, request = _make_httpx_bridge(ops_state)
    monkeypatch.setattr(ds_mod.httpx, "get", get)
    monkeypatch.setattr(ds_mod.httpx, "post", post)
    monkeypatch.setattr(ds_mod.httpx, "patch", patch)
    monkeypatch.setattr(ds_mod.httpx, "put", put)
    monkeypatch.setattr(ds_mod.httpx, "request", request)
    _execution._workspace_base_url_cache.clear()


class TestListDatasets:
    def test_returns_summaries(self, client: TktlClient, cache_index: CacheIndex) -> None:
        result = list_datasets(client, cache_index, WS_ID, "credit-scoring")
        assert len(result) == 1
        assert result[0].name == "Test Dataset"


class TestCreateDataset:
    def test_creates_with_columns(self, client: TktlClient, cache_index: CacheIndex) -> None:
        cols = [DatasetColumn(name="income", desired_type=ColumnType.number)]
        result = create_dataset(client, cache_index, WS_ID, "credit-scoring", "New DS", cols)
        assert result.name == "New DS"
        assert len(result.input_columns) == 1


class TestCreateFromSchema:
    def test_derives_columns_from_schema(self, client: TktlClient, cache_index: CacheIndex) -> None:
        result = create_from_schema(client, cache_index, WS_ID, "credit-scoring", "v1", "Schema DS")
        assert result.name == "Schema DS"
        col_names = {c.name for c in result.input_columns}
        assert "income" in col_names
        assert "age" in col_names
        assert "name" in col_names

    def test_maps_types_correctly(self, client: TktlClient, cache_index: CacheIndex) -> None:
        result = create_from_schema(client, cache_index, WS_ID, "credit-scoring", "v1", "Typed DS")
        cols_by_name = {c.name: c for c in result.input_columns}
        assert cols_by_name["income"].desired_type == ColumnType.number
        assert cols_by_name["age"].desired_type == ColumnType.integer
        assert cols_by_name["name"].desired_type == ColumnType.string


class TestDescribeDataset:
    def test_returns_dataset(self, client: TktlClient) -> None:
        result = describe_dataset(client, WS_ID, "ds-test-001")
        assert result.name == "Test Dataset"
        assert len(result.input_columns) == 2


class TestGetRows:
    def test_returns_rows(self, client: TktlClient) -> None:
        result = get_rows(client, WS_ID, "ds-test-001", from_=0, size=10)
        assert len(result) == 3
        assert result[0].input_data["income"] == 50000

    def test_pagination(self, client: TktlClient) -> None:
        result = get_rows(client, WS_ID, "ds-test-001", from_=0, size=2)
        assert len(result) == 2


class TestAddBlankRows:
    def test_adds_rows(self, client: TktlClient) -> None:
        result = add_blank_rows(client, WS_ID, "ds-test-001", 3)
        assert len(result) == 3

    def test_auto_batches(self, client: TktlClient) -> None:
        result = add_blank_rows(client, WS_ID, "ds-test-001", 55)
        assert len(result) == 55

    def test_rejects_zero(self, client: TktlClient) -> None:
        with pytest.raises(UsageError):
            add_blank_rows(client, WS_ID, "ds-test-001", 0)


class TestAddRows:
    def test_adds_with_data(self, client: TktlClient) -> None:
        data = [{"income": 100000}, {"income": 200000}]
        result = add_rows(client, WS_ID, "ds-test-001", data)
        assert len(result) == 2
        assert result[0].input_data["income"] == 100000

    def test_empty_raises(self, client: TktlClient) -> None:
        with pytest.raises(UsageError):
            add_rows(client, WS_ID, "ds-test-001", [])


class TestUpdateRow:
    def test_updates(self, client: TktlClient) -> None:
        result = update_row(client, WS_ID, "ds-test-001", "row-a", {"input_data": {"income": 99999}})
        assert result.input_data["income"] == 99999


class TestDeleteRow:
    def test_deletes(self, client: TktlClient) -> None:
        delete_row(client, WS_ID, "ds-test-001", "row-a")
        rows = get_rows(client, WS_ID, "ds-test-001", from_=0, size=50)
        assert len(rows) == 2
        assert all(r.id != "row-a" for r in rows)


class TestDeleteDataset:
    def test_deletes(self, client: TktlClient) -> None:
        delete_dataset(client, WS_ID, "ds-test-001")
        with pytest.raises(Exception):
            describe_dataset(client, WS_ID, "ds-test-001")


class TestAddColumn:
    def test_adds(self, client: TktlClient) -> None:
        result = add_column(client, WS_ID, "ds-test-001", ColumnGroup.input_columns, "age", ColumnType.integer)
        col_names = {c.name for c in result.input_columns}
        assert "age" in col_names


class TestRenameColumn:
    def test_renames(self, client: TktlClient) -> None:
        result = rename_column(client, WS_ID, "ds-test-001", ColumnGroup.input_columns, "income", "annual_income")
        col_names = {c.name for c in result.input_columns}
        assert "annual_income" in col_names
        assert "income" not in col_names


class TestDeleteColumn:
    def test_deletes(self, client: TktlClient) -> None:
        result = delete_column(client, WS_ID, "ds-test-001", ColumnGroup.input_columns, "old_field")
        col_names = {c.name for c in result.input_columns}
        assert "old_field" not in col_names


class TestFillColumn:
    def test_fills(self, client: TktlClient) -> None:
        result = fill_column(client, WS_ID, "ds-test-001", ColumnGroup.input_columns, "income", 42)
        assert result.etag is not None


class TestDownloadDataset:
    def test_download_csv(self, client: TktlClient) -> None:
        content = download_dataset(client, WS_ID, "ds-test-001", fmt="csv")
        assert "income" in content

    def test_download_to_file(self, client: TktlClient, tmp_path: Path) -> None:
        out = tmp_path / "output.csv"
        result = download_dataset(client, WS_ID, "ds-test-001", fmt="csv", output_path=out)
        assert result == str(out)
        assert out.exists()


class TestSyncSchema:
    def test_detects_missing_columns(self, client: TktlClient, cache_index: CacheIndex) -> None:
        diff = sync_schema(client, cache_index, WS_ID, "credit-scoring", "ds-test-001", "v1")
        missing_names = {c.name for c in diff.missing_columns}
        assert "age" in missing_names
        assert "name" in missing_names

    def test_detects_extra_columns(self, client: TktlClient, cache_index: CacheIndex) -> None:
        diff = sync_schema(client, cache_index, WS_ID, "credit-scoring", "ds-test-001", "v1")
        extra_names = {c.name for c in diff.extra_columns}
        assert "old_field" in extra_names

    def test_apply_adds_missing(self, client: TktlClient, cache_index: CacheIndex) -> None:
        diff = sync_schema(client, cache_index, WS_ID, "credit-scoring", "ds-test-001", "v1", apply=True)
        assert len(diff.missing_columns) >= 1

        ds = describe_dataset(client, WS_ID, "ds-test-001")
        col_names = {c.name for c in ds.input_columns}
        assert "age" in col_names
        assert "name" in col_names
