"""Tests for ops.versions.update_version — version-level writes."""

from __future__ import annotations

from tktl.api.client import TktlClient
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.models.version import VersionDetail
from tktl.ops.flows import describe_flow
from tktl.ops.versions import update_version

WS_ID = "ws_00000000-0000-0000-0000-000000000001"


def _seed_cache(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
) -> None:
    describe_flow(client, cache_index, cache_manager, WS_ID, "credit-scoring")


class TestUpdateVersion:
    def test_update_params(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        result = update_version(
            client,
            cache_index,
            cache_manager,
            WS_ID,
            "credit-scoring",
            "v1",
            params=[{"name": "threshold", "value": 0.9}],
        )
        assert isinstance(result, VersionDetail)
        assert result.parameters == [{"name": "threshold", "value": 0.9}]

    def test_update_schema_in(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        new_schema = {"type": "object", "properties": {"age": {"type": "integer"}}}
        result = update_version(
            client,
            cache_index,
            cache_manager,
            WS_ID,
            "credit-scoring",
            "v1",
            schema_in=new_schema,
        )
        assert result.input_schema == new_schema

    def test_update_schema_out(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        new_schema = {"type": "object", "properties": {"result": {"type": "boolean"}}}
        result = update_version(
            client,
            cache_index,
            cache_manager,
            WS_ID,
            "credit-scoring",
            "v1",
            schema_out=new_schema,
        )
        assert result.output_schema == new_schema

    def test_cache_updated_after_update(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        update_version(
            client,
            cache_index,
            cache_manager,
            WS_ID,
            "credit-scoring",
            "v1",
            params=[{"name": "new_param", "value": 42}],
        )
        flow_id = cache_index.resolve_flow_id("credit-scoring")
        version_id = cache_index.resolve_version_id("credit-scoring", "v1")
        assert flow_id is not None
        assert version_id is not None
        cached = cache_manager.read_version_metadata(version_id, flow_id)
        assert cached is not None
        assert cached["parameters"] == [{"name": "new_param", "value": 42}]
