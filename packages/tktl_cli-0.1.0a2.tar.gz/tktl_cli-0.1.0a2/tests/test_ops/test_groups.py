"""Tests for ops.groups: CRUD operations on node groups."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from tktl.api.client import TktlClient
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.models.errors import NotFoundError
from tktl.ops.flows import describe_flow
from tktl.ops.groups import (
    add_nodes_to_group,
    create_group,
    delete_group,
    get_group,
    list_groups,
    remove_nodes_from_group,
    update_group,
)
from tktl.ops.versions import describe_version

if TYPE_CHECKING:
    from tests.fake_api.state import FakeState

WS_ID = "ws_00000000-0000-0000-0000-000000000001"


def _seed_cache(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
) -> None:
    describe_flow(client, cache_index, cache_manager, WS_ID, "credit-scoring")
    describe_version(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1")


class TestListGroups:
    def test_list_returns_seeded_group(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        fake_state: FakeState,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        groups = list_groups(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1")
        assert len(groups) == 1
        assert groups[0].id == "group_scoring"
        assert groups[0].name == "Scoring"
        assert set(groups[0].node_ids) == {"node_risk", "node_pricing"}

    def test_list_empty_when_no_groups(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        fake_state: FakeState,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        describe_flow(client, cache_index, cache_manager, WS_ID, "kyc-check")
        describe_version(client, cache_index, cache_manager, WS_ID, "kyc-check", "v1")
        groups = list_groups(client, cache_index, cache_manager, WS_ID, "kyc-check", "v1")
        assert groups == []


class TestGetGroup:
    def test_get_existing_group(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        fake_state: FakeState,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        group = get_group(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1", "group_scoring")
        assert group.id == "group_scoring"
        assert group.name == "Scoring"
        assert group.node_ids == ["node_risk", "node_pricing"]

    def test_get_nonexistent_raises(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        fake_state: FakeState,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        with pytest.raises(NotFoundError):
            get_group(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1", "nonexistent")


class TestCreateGroup:
    def test_create_group(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        fake_state: FakeState,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        group = create_group(
            client,
            cache_index,
            cache_manager,
            WS_ID,
            "credit-scoring",
            "v1",
            name="Gate Rules",
            node_ids=["node_input"],
        )
        assert group.name == "Gate Rules"
        assert group.node_ids == ["node_input"]
        # Should now have 2 groups total
        groups = list_groups(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1")
        assert len(groups) == 2

    def test_create_validates_node_ids(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        fake_state: FakeState,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        with pytest.raises(NotFoundError, match="not found"):
            create_group(
                client,
                cache_index,
                cache_manager,
                WS_ID,
                "credit-scoring",
                "v1",
                name="Bad",
                node_ids=["nonexistent_node"],
            )


class TestUpdateGroup:
    def test_rename_group(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        fake_state: FakeState,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        group = update_group(
            client,
            cache_index,
            cache_manager,
            WS_ID,
            "credit-scoring",
            "v1",
            "group_scoring",
            name="Risk & Pricing",
        )
        assert group.name == "Risk & Pricing"
        assert group.node_ids == ["node_risk", "node_pricing"]

    def test_update_node_ids(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        fake_state: FakeState,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        group = update_group(
            client,
            cache_index,
            cache_manager,
            WS_ID,
            "credit-scoring",
            "v1",
            "group_scoring",
            node_ids=["node_risk"],
        )
        assert group.node_ids == ["node_risk"]

    def test_update_nonexistent_raises(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        fake_state: FakeState,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        with pytest.raises(NotFoundError):
            update_group(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1", "nonexistent", name="X")


class TestDeleteGroup:
    def test_delete_group(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        fake_state: FakeState,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        remaining = delete_group(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1", "group_scoring")
        assert len(remaining) == 0

    def test_delete_nonexistent_raises(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        fake_state: FakeState,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        with pytest.raises(NotFoundError):
            delete_group(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1", "nonexistent")


class TestAddNodesToGroup:
    def test_add_nodes(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        fake_state: FakeState,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        group = add_nodes_to_group(
            client,
            cache_index,
            cache_manager,
            WS_ID,
            "credit-scoring",
            "v1",
            "group_scoring",
            node_ids=["node_input"],
        )
        assert "node_input" in group.node_ids
        assert "node_risk" in group.node_ids
        assert "node_pricing" in group.node_ids

    def test_add_duplicate_node_no_effect(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        fake_state: FakeState,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        group = add_nodes_to_group(
            client,
            cache_index,
            cache_manager,
            WS_ID,
            "credit-scoring",
            "v1",
            "group_scoring",
            node_ids=["node_risk"],
        )
        assert group.node_ids.count("node_risk") == 1


class TestRemoveNodesFromGroup:
    def test_remove_nodes(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        fake_state: FakeState,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        group = remove_nodes_from_group(
            client,
            cache_index,
            cache_manager,
            WS_ID,
            "credit-scoring",
            "v1",
            "group_scoring",
            node_ids=["node_pricing"],
        )
        assert group.node_ids == ["node_risk"]
