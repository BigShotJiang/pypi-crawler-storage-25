"""Tests for version lifecycle operations: publish, archive, create, duplicate."""

from __future__ import annotations

from tktl.api.client import TktlClient
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.models.version import VersionDetail
from tktl.ops.flows import describe_flow
from tktl.ops.versions import (
    archive_version,
    create_version,
    duplicate_version,
    publish_version,
)

WS_ID = "ws_00000000-0000-0000-0000-000000000001"


def _seed_cache(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
) -> None:
    describe_flow(client, cache_index, cache_manager, WS_ID, "credit-scoring")


class TestPublishVersion:
    def test_publishes_draft(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        result = publish_version(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v2-draft")
        assert isinstance(result, VersionDetail)
        assert result.status == "PUBLISHED"


class TestArchiveVersion:
    def test_archives_version(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        result = archive_version(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1")
        assert isinstance(result, VersionDetail)
        assert result.status == "ARCHIVED"


class TestCreateVersion:
    def test_creates_new_version(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        result = create_version(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v3-new")
        assert isinstance(result, VersionDetail)
        assert result.name == "v3-new"
        assert result.status == "DRAFT"

    def test_updates_cache_index(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        result = create_version(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v3-new")
        # Index should have the new version
        v_id = cache_index.resolve_version_id("credit-scoring", "v3-new")
        assert v_id == result.id


class TestDuplicateVersion:
    def test_duplicates_version(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        result = duplicate_version(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1", "v1-copy")
        assert isinstance(result, VersionDetail)
        assert result.name == "v1-copy"
        assert result.status == "DRAFT"

    def test_updates_cache_index(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
    ) -> None:
        _seed_cache(client, cache_index, cache_manager)
        result = duplicate_version(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1", "v1-copy")
        v_id = cache_index.resolve_version_id("credit-scoring", "v1-copy")
        assert v_id == result.id
