"""Tests for manual review ops helpers."""

from __future__ import annotations

import uuid
from unittest.mock import patch

import pytest

from tktl.models.connection import ConnectionSummary, ResourceConfigSummary
from tktl.models.errors import NotFoundError
from tktl.ops.manual_review import build_default_review_meta, find_manual_review_connection

WS_ID = "ws_00000000-0000-0000-0000-000000000001"


def _make_connections(include_manual_review: bool = True, with_resource_configs: bool = True):
    """Build a list of ConnectionSummary for testing."""
    connections = [
        ConnectionSummary(
            id="conn_00000000-0000-0000-0000-000000000001",
            name="Postman Echo",
            provider="custom",
            resource_configs=[ResourceConfigSummary(id="rc_001", name="HTTP", resource="http")],
        ),
    ]
    if include_manual_review:
        rcs = []
        if with_resource_configs:
            rcs = [
                ResourceConfigSummary(id="rc_00000000-0000-0000-0000-000000000003", name="MR", resource="manual_review")
            ]
        connections.append(
            ConnectionSummary(
                id="conn_00000000-0000-0000-0000-000000000003",
                name="Manual Review",
                provider="manual_review",
                resource_configs=rcs,
            )
        )
    return connections


class TestFindManualReviewConnection:
    @patch("tktl.ops.manual_review.list_connections")
    def test_find_returns_ids(self, mock_list, client):
        mock_list.return_value = _make_connections()
        conn_id, rc_id = find_manual_review_connection(client, WS_ID)
        assert conn_id == "conn_00000000-0000-0000-0000-000000000003"
        assert rc_id == "rc_00000000-0000-0000-0000-000000000003"

    @patch("tktl.ops.manual_review.list_connections")
    def test_not_found_raises(self, mock_list, client):
        mock_list.return_value = _make_connections(include_manual_review=False)
        with pytest.raises(NotFoundError, match="No manual_review connection"):
            find_manual_review_connection(client, WS_ID)

    @patch("tktl.ops.manual_review.list_connections")
    def test_no_resource_configs_raises(self, mock_list, client):
        mock_list.return_value = _make_connections(with_resource_configs=False)
        with pytest.raises(NotFoundError, match="no resource configs"):
            find_manual_review_connection(client, WS_ID)


class TestBuildDefaultReviewMeta:
    def test_default_meta_structure(self):
        meta = build_default_review_meta("conn_123", "rc_456")
        assert meta["provider_resource"] == {"provider": "manual_review", "resource": "manual_review"}
        assert meta["connection_id"] == "conn_123"
        assert meta["resource_config_id"] == "rc_456"
        assert meta["highlights"] == []
        assert meta["reviewer_assign_strategy"] == "ANY"
        assert meta["reviewer_assign_strategy_v2"] == {"type": "ANY"}
        assert meta["response_metadata_key"] is None

        # Default response form has a single boolean approved field
        form = meta["response_form"]
        assert form["description"] == ""
        assert len(form["fields"]) == 1
        field = form["fields"][0]
        assert field["key"] == "approved"
        assert field["type"] == "boolean"
        assert field["required"] is True
        assert field["name"] == "Approved"
        # id should be a valid UUID string
        uuid.UUID(field["id"])

    def test_custom_highlights(self):
        highlights = [{"type": "divider"}, {"type": "description", "id_value": "abc", "value": "Hello"}]
        meta = build_default_review_meta("conn_123", "rc_456", highlights=highlights)
        assert meta["highlights"] == highlights

    def test_custom_response_form(self):
        form = {"description": "Custom form", "fields": []}
        meta = build_default_review_meta("conn_123", "rc_456", response_form=form)
        assert meta["response_form"] == form

    def test_custom_assign_strategy(self):
        meta = build_default_review_meta("conn_123", "rc_456", assign_strategy="REVIEWER_ONLY")
        assert meta["reviewer_assign_strategy"] == "REVIEWER_ONLY"
        assert meta["reviewer_assign_strategy_v2"] == {"type": "REVIEWER_ONLY"}
