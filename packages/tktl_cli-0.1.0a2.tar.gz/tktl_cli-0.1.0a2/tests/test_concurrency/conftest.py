"""Shared fixtures for concurrency tests."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import pytest

from tests.test_api.conftest import FAKE_BASE_URL, make_sync_transport, write_test_config, write_test_credentials
from tktl.api.client import TktlClient
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager

if TYPE_CHECKING:
    from tests.fake_api.state import FakeState

WS_ID = "ws_00000000-0000-0000-0000-000000000001"


@pytest.fixture
def client(tmp_path: Path, fake_state: FakeState) -> TktlClient:
    config_dir = tmp_path / "config"
    config_dir.mkdir()
    write_test_config(config_dir)
    write_test_credentials(config_dir, "test-key")
    transport = make_sync_transport(fake_state)
    return TktlClient(
        config_dir=config_dir,
        base_url=FAKE_BASE_URL,
        transport=transport,
    )


@pytest.fixture
def cache_dir(tmp_path: Path) -> Path:
    d = tmp_path / "cache"
    d.mkdir()
    return d


@pytest.fixture
def cache_manager(cache_dir: Path) -> CacheManager:
    return CacheManager(cache_dir)


@pytest.fixture
def cache_index(cache_dir: Path) -> CacheIndex:
    idx = CacheIndex(cache_dir)
    idx.load()
    return idx
