"""Tests for node-level locking during updates."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from tktl.api.client import TktlClient
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.models.errors import ConflictError
from tktl.ops.flows import describe_flow
from tktl.ops.nodes import update_node
from tktl.ops.versions import describe_version

if TYPE_CHECKING:
    from tests.fake_api.state import FakeState

WS_ID = "ws_00000000-0000-0000-0000-000000000001"


def _seed_cache(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
) -> None:
    describe_flow(client, cache_index, cache_manager, WS_ID, "credit-scoring")
    describe_version(client, cache_index, cache_manager, WS_ID, "credit-scoring", "v1")


class TestLockConflict:
    def test_lock_conflict_from_other_session(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        fake_state: FakeState,
    ) -> None:
        """Another session holding a lock should block the update."""
        _seed_cache(client, cache_index, cache_manager)
        version_id = cache_index.resolve_version_id("credit-scoring", "v1")
        assert version_id is not None

        fake_state.versions[version_id]["locks"] = [
            {
                "id": "lock_other",
                "owner": "other-user",
                "session": "other-session-xyz",
                "resource_type": "node",
                "resource_id": "node_risk",
                "duration_secs": 300,
            }
        ]

        with pytest.raises(ConflictError, match="locked"):
            update_node(
                client,
                cache_index,
                cache_manager,
                WS_ID,
                "credit-scoring",
                "v1",
                "node_risk",
                meta={"x": 1},
            )


class TestForceBreakLock:
    def test_force_overrides_existing_lock(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        fake_state: FakeState,
    ) -> None:
        """--force should break the existing lock and proceed."""
        _seed_cache(client, cache_index, cache_manager)
        version_id = cache_index.resolve_version_id("credit-scoring", "v1")
        assert version_id is not None

        fake_state.versions[version_id]["locks"] = [
            {
                "id": "lock_other",
                "owner": "other-user",
                "session": "other-session-xyz",
                "resource_type": "node",
                "resource_id": "node_risk",
                "duration_secs": 300,
            }
        ]

        result = update_node(
            client,
            cache_index,
            cache_manager,
            WS_ID,
            "credit-scoring",
            "v1",
            "node_risk",
            meta={"score_threshold": 1000},
            force=True,
        )
        assert result.meta is not None
        assert result.meta["score_threshold"] == 1000


class TestLockAlwaysReleased:
    def test_lock_released_on_success(
        self,
        client: TktlClient,
        cache_index: CacheIndex,
        cache_manager: CacheManager,
        fake_state: FakeState,
    ) -> None:
        """After successful update, the lock should be released."""
        _seed_cache(client, cache_index, cache_manager)

        update_node(
            client,
            cache_index,
            cache_manager,
            WS_ID,
            "credit-scoring",
            "v1",
            "node_risk",
            meta={"score_threshold": 800},
            session="my-session",
        )

        # Check that locks are cleared (or at least our lock is gone)
        version_id = cache_index.resolve_version_id("credit-scoring", "v1")
        assert version_id is not None
        version = fake_state.versions[version_id]
        locks = version.get("locks", [])
        # Our lock should be released
        our_locks = [lk for lk in locks if lk.get("session") == "my-session"]
        assert len(our_locks) == 0
