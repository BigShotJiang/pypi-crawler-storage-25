"""Shared pytest fixtures for integration tests."""

from __future__ import annotations

from typing import TYPE_CHECKING

import httpx
import pytest

from tests.fake_api.app import create_fake_app
from tests.fake_api.seed import (
    SeedConnection,
    SeedEdge,
    SeedFlow,
    SeedNode,
    SeedNodeGroup,
    SeedResourceConfig,
    SeedVersion,
    build_seed_state,
)
from tests.fake_api.state import FakeDataset
from tktl.telemetry import _state as _telemetry_state

if TYPE_CHECKING:
    from tests.fake_api.state import FakeState

WS_ID = "ws_00000000-0000-0000-0000-000000000001"
FAKE_BASE_URL = "https://fake-flow-api.taktile.com"


FAKE_DATASET_ID = "ds_00000000-0000-0000-0000-000000000001"


@pytest.fixture(autouse=True)
def _disable_telemetry(monkeypatch: pytest.MonkeyPatch) -> None:
    """Prevent telemetry from hitting the real ~/.tktl config in all tests."""
    monkeypatch.setattr(_telemetry_state, "disabled", True)


@pytest.fixture
def fake_state() -> FakeState:
    """Pre-populated state with 2 flows, multiple versions and node types."""
    state = build_seed_state(
        connections=[
            SeedConnection(
                id="conn_00000000-0000-0000-0000-000000000001",
                name="Postman Echo",
                provider="custom",
                resource_configs=[
                    SeedResourceConfig(
                        id="rc_00000000-0000-0000-0000-000000000001",
                        name="HTTP",
                        resource="http",
                    ),
                ],
            ),
            SeedConnection(
                id="conn_00000000-0000-0000-0000-000000000002",
                name="Credit Bureau",
                provider="custom",
                resource_configs=[
                    SeedResourceConfig(
                        id="rc_00000000-0000-0000-0000-000000000002",
                        name="Credit Check",
                        resource="http",
                    ),
                ],
            ),
            SeedConnection(
                id="conn_00000000-0000-0000-0000-000000000003",
                name="Manual Review",
                provider="manual_review",
                resource_configs=[
                    SeedResourceConfig(
                        id="rc_00000000-0000-0000-0000-000000000003",
                        name="Manual Review",
                        resource="manual_review",
                    ),
                ],
            ),
        ],
        flows=[
            SeedFlow(
                slug="credit-scoring",
                versions=[
                    SeedVersion(
                        name="v1",
                        status="PUBLISHED",
                        nodes=[
                            SeedNode(id="node_input", name="Input", type="input"),
                            SeedNode(
                                id="node_risk",
                                name="Risk Engine",
                                type="decision_table",
                                meta={"score_threshold": 500, "rows": []},
                            ),
                            SeedNode(
                                id="node_pricing",
                                name="Pricing Rule",
                                type="scorecard",
                                meta={"base_rate": 0.05},
                            ),
                            SeedNode(id="node_output", name="Output", type="output"),
                        ],
                        node_groups=[
                            SeedNodeGroup(
                                id="group_scoring",
                                name="Scoring",
                                node_ids=["node_risk", "node_pricing"],
                            ),
                        ],
                        parameters=[{"name": "threshold", "value": 0.8}],
                        input_schema={"type": "object", "properties": {"income": {"type": "number"}}},
                        output_schema={"type": "object", "properties": {"decision": {"type": "string"}}},
                    ),
                    SeedVersion(
                        name="v2-draft",
                        status="DRAFT",
                        nodes=[
                            SeedNode(id="node_input", name="Input", type="input"),
                            SeedNode(id="node_ml", name="ML Scorer", type="ml", meta={"model_id": "m1"}),
                            SeedNode(id="node_output", name="Output", type="output"),
                        ],
                        edges=[
                            SeedEdge(start_node_id="node_input", end_node_id="node_ml"),
                            SeedEdge(start_node_id="node_ml", end_node_id="node_output"),
                        ],
                        node_groups=[
                            SeedNodeGroup(
                                id="group_ml",
                                name="ML Nodes",
                                node_ids=["node_ml"],
                            ),
                        ],
                    ),
                ],
            ),
            SeedFlow(
                slug="kyc-check",
                versions=[
                    SeedVersion(
                        name="v1",
                        status="DRAFT",
                        nodes=[
                            SeedNode(id="node_input", name="Input", type="input"),
                            SeedNode(id="node_verify", name="ID Verification", type="data_integration"),
                            SeedNode(id="node_output", name="Output", type="output"),
                        ],
                    ),
                ],
            ),
            SeedFlow(
                slug="data-enrichment",
                versions=[
                    SeedVersion(
                        name="v1",
                        status="DRAFT",
                        nodes=[
                            SeedNode(id="node_input", name="Input", type="input"),
                            SeedNode(id="node_output", name="Output", type="output"),
                        ],
                        edges=[
                            SeedEdge(start_node_id="node_input", end_node_id="node_output"),
                        ],
                    ),
                ],
            ),
        ],
    )

    # Add a seed dataset for the credit-scoring flow
    cs_flow_id = next(f["id"] for f in state.flows.values() if f["slug"] == "credit-scoring")
    state.datasets[FAKE_DATASET_ID] = FakeDataset(
        dataset_id=FAKE_DATASET_ID,
        flow_id=cs_flow_id,
        name="Test Dataset",
        etag="dataset-etag-1",
        rows=[
            {"request": {"data": {"income": 50000, "age": 30}}},
            {"request": {"data": {"income": 75000, "age": 45}}},
            {"request": {"data": {"income": 25000, "age": 22}}},
        ],
    )

    return state


@pytest.fixture
def fake_transport(fake_state: FakeState) -> httpx.ASGITransport:
    """ASGI transport wired to the fake API."""
    app = create_fake_app(fake_state)
    return httpx.ASGITransport(app=app)
