"""Tests for CacheManager — hierarchical file-based cache."""

from __future__ import annotations

import json
from pathlib import Path

from tktl.cache.manager import CacheManager


def _make_version_data(
    *,
    name: str = "v1",
    version_id: str = "fv_001",
    etag: str = "etag_abc",
    nodes: dict | None = None,
) -> dict:
    """Build a realistic version data dict for testing."""
    if nodes is None:
        nodes = {
            "node_a": {"id": "node_a", "name": "Risk Engine", "type": "decision_table", "meta": {"threshold": 500}},
            "node_b": {"id": "node_b", "name": "Pricing", "type": "scorecard", "meta": {"rate": 0.05}},
        }
    return {
        "name": name,
        "id": version_id,
        "status": "DRAFT",
        "etag": etag,
        "parameters": [{"name": "p1", "value": 42}],
        "input_schema": {"type": "object"},
        "output_schema": {"type": "object"},
        "graph": {
            "nodes": nodes,
            "edges": [{"source": "node_a", "target": "node_b"}],
        },
    }


class TestFlowMetadata:
    """Write and read flow-level metadata."""

    def test_write_and_read_flow_metadata(self, tmp_path: Path) -> None:
        mgr = CacheManager(cache_dir=tmp_path)
        metadata = {"slug": "credit-scoring", "id": "fl_001", "name": "Credit Scoring"}
        mgr.write_flow_metadata("fl_001", metadata)

        result = mgr.read_flow_metadata("fl_001")
        assert result is not None
        assert result["slug"] == "credit-scoring"
        assert result["id"] == "fl_001"
        assert "_cached_at" in result

    def test_read_flow_metadata_missing(self, tmp_path: Path) -> None:
        mgr = CacheManager(cache_dir=tmp_path)
        assert mgr.read_flow_metadata("nonexistent") is None

    def test_write_flow_metadata_creates_directories(self, tmp_path: Path) -> None:
        mgr = CacheManager(cache_dir=tmp_path)
        mgr.write_flow_metadata("fl_001", {"name": "test"})
        assert (tmp_path / "flows" / "fl_001" / "metadata.json").exists()


class TestWriteVersion:
    """write_version decomposes into metadata.json, full.json, and per-node files."""

    def test_creates_metadata_file(self, tmp_path: Path) -> None:
        mgr = CacheManager(cache_dir=tmp_path)
        version_data = _make_version_data()
        mgr.write_version("fv_001", "fl_001", version_data)

        meta_path = tmp_path / "flows" / "fl_001" / "versions" / "fv_001" / "metadata.json"
        assert meta_path.exists()
        meta = json.loads(meta_path.read_text())
        assert meta["name"] == "v1"
        assert meta["etag"] == "etag_abc"
        # metadata.json should NOT contain graph
        assert "graph" not in meta

    def test_creates_full_json(self, tmp_path: Path) -> None:
        mgr = CacheManager(cache_dir=tmp_path)
        version_data = _make_version_data()
        mgr.write_version("fv_001", "fl_001", version_data)

        full_path = tmp_path / "flows" / "fl_001" / "versions" / "fv_001" / "full.json"
        assert full_path.exists()
        full = json.loads(full_path.read_text())
        assert "graph" in full
        assert full["graph"]["nodes"]["node_a"]["name"] == "Risk Engine"

    def test_creates_per_node_files(self, tmp_path: Path) -> None:
        mgr = CacheManager(cache_dir=tmp_path)
        version_data = _make_version_data()
        mgr.write_version("fv_001", "fl_001", version_data)

        nodes_dir = tmp_path / "flows" / "fl_001" / "versions" / "fv_001" / "nodes"
        assert (nodes_dir / "node_a.json").exists()
        assert (nodes_dir / "node_b.json").exists()

        node_a = json.loads((nodes_dir / "node_a.json").read_text())
        assert node_a["name"] == "Risk Engine"
        assert node_a["type"] == "decision_table"

    def test_creates_node_index(self, tmp_path: Path) -> None:
        mgr = CacheManager(cache_dir=tmp_path)
        version_data = _make_version_data()
        mgr.write_version("fv_001", "fl_001", version_data)

        index_path = tmp_path / "flows" / "fl_001" / "versions" / "fv_001" / "nodes" / "_index.json"
        assert index_path.exists()
        index = json.loads(index_path.read_text())
        assert isinstance(index, list)
        assert len(index) == 2
        ids = {n["id"] for n in index}
        assert ids == {"node_a", "node_b"}
        # Each entry should have id, name, type
        for entry in index:
            assert "id" in entry
            assert "name" in entry
            assert "type" in entry

    def test_full_json_has_cached_at(self, tmp_path: Path) -> None:
        mgr = CacheManager(cache_dir=tmp_path)
        mgr.write_version("fv_001", "fl_001", _make_version_data())
        full_path = tmp_path / "flows" / "fl_001" / "versions" / "fv_001" / "full.json"
        full = json.loads(full_path.read_text())
        assert "_cached_at" in full

    def test_metadata_has_cached_at(self, tmp_path: Path) -> None:
        mgr = CacheManager(cache_dir=tmp_path)
        mgr.write_version("fv_001", "fl_001", _make_version_data())
        meta_path = tmp_path / "flows" / "fl_001" / "versions" / "fv_001" / "metadata.json"
        meta = json.loads(meta_path.read_text())
        assert "_cached_at" in meta

    def test_node_files_have_cached_at(self, tmp_path: Path) -> None:
        mgr = CacheManager(cache_dir=tmp_path)
        mgr.write_version("fv_001", "fl_001", _make_version_data())
        node_path = tmp_path / "flows" / "fl_001" / "versions" / "fv_001" / "nodes" / "node_a.json"
        node = json.loads(node_path.read_text())
        assert "_cached_at" in node

    def test_write_version_with_empty_graph(self, tmp_path: Path) -> None:
        mgr = CacheManager(cache_dir=tmp_path)
        version_data = _make_version_data(nodes={})
        mgr.write_version("fv_001", "fl_001", version_data)

        index_path = tmp_path / "flows" / "fl_001" / "versions" / "fv_001" / "nodes" / "_index.json"
        assert index_path.exists()
        index = json.loads(index_path.read_text())
        assert index == []

    def test_write_version_without_graph(self, tmp_path: Path) -> None:
        """Version data might not have a graph key at all."""
        mgr = CacheManager(cache_dir=tmp_path)
        version_data = {
            "name": "v1",
            "id": "fv_001",
            "status": "DRAFT",
            "etag": "etag_abc",
        }
        mgr.write_version("fv_001", "fl_001", version_data)
        # metadata and full should still be written
        meta_path = tmp_path / "flows" / "fl_001" / "versions" / "fv_001" / "metadata.json"
        assert meta_path.exists()
        full_path = tmp_path / "flows" / "fl_001" / "versions" / "fv_001" / "full.json"
        assert full_path.exists()


class TestReadVersionMetadata:
    """Read version metadata (no graph) + etag."""

    def test_read_after_write(self, tmp_path: Path) -> None:
        mgr = CacheManager(cache_dir=tmp_path)
        mgr.write_version("fv_001", "fl_001", _make_version_data())

        meta = mgr.read_version_metadata("fv_001", "fl_001")
        assert meta is not None
        assert meta["name"] == "v1"
        assert meta["etag"] == "etag_abc"
        assert "graph" not in meta

    def test_read_missing(self, tmp_path: Path) -> None:
        mgr = CacheManager(cache_dir=tmp_path)
        assert mgr.read_version_metadata("fv_nonexistent", "fl_001") is None


class TestReadNodeIndex:
    """Read the node index for a version."""

    def test_read_after_write(self, tmp_path: Path) -> None:
        mgr = CacheManager(cache_dir=tmp_path)
        mgr.write_version("fv_001", "fl_001", _make_version_data())

        index = mgr.read_node_index("fv_001", "fl_001")
        assert index is not None
        assert len(index) == 2
        ids = {n["id"] for n in index}
        assert ids == {"node_a", "node_b"}

    def test_read_missing(self, tmp_path: Path) -> None:
        mgr = CacheManager(cache_dir=tmp_path)
        assert mgr.read_node_index("fv_nonexistent", "fl_001") is None


class TestReadNode:
    """Read a single node from the cache."""

    def test_read_after_write(self, tmp_path: Path) -> None:
        mgr = CacheManager(cache_dir=tmp_path)
        mgr.write_version("fv_001", "fl_001", _make_version_data())

        node = mgr.read_node("fv_001", "fl_001", "node_a")
        assert node is not None
        assert node["id"] == "node_a"
        assert node["name"] == "Risk Engine"
        assert node["type"] == "decision_table"
        assert node["meta"]["threshold"] == 500

    def test_read_missing_node(self, tmp_path: Path) -> None:
        mgr = CacheManager(cache_dir=tmp_path)
        mgr.write_version("fv_001", "fl_001", _make_version_data())
        assert mgr.read_node("fv_001", "fl_001", "nonexistent") is None

    def test_read_missing_version(self, tmp_path: Path) -> None:
        mgr = CacheManager(cache_dir=tmp_path)
        assert mgr.read_node("fv_nonexistent", "fl_001", "node_a") is None


class TestWriteNode:
    """Write a single node file."""

    def test_write_and_read_back(self, tmp_path: Path) -> None:
        mgr = CacheManager(cache_dir=tmp_path)
        # First write the version to set up directory structure
        mgr.write_version("fv_001", "fl_001", _make_version_data())

        # Now update a single node
        updated_node = {"id": "node_a", "name": "Risk Engine v2", "type": "decision_table", "meta": {"threshold": 750}}
        mgr.write_node("fv_001", "fl_001", "node_a", updated_node)

        node = mgr.read_node("fv_001", "fl_001", "node_a")
        assert node is not None
        assert node["name"] == "Risk Engine v2"
        assert node["meta"]["threshold"] == 750
        assert "_cached_at" in node

    def test_write_node_creates_dirs(self, tmp_path: Path) -> None:
        mgr = CacheManager(cache_dir=tmp_path)
        # Write node without prior version write — should create dirs
        node_data = {"id": "node_x", "name": "Test", "type": "input"}
        mgr.write_node("fv_001", "fl_001", "node_x", node_data)

        node = mgr.read_node("fv_001", "fl_001", "node_x")
        assert node is not None
        assert node["name"] == "Test"


class TestInvalidateVersion:
    """Delete version cache directory."""

    def test_invalidate_removes_directory(self, tmp_path: Path) -> None:
        mgr = CacheManager(cache_dir=tmp_path)
        mgr.write_version("fv_001", "fl_001", _make_version_data())

        version_dir = tmp_path / "flows" / "fl_001" / "versions" / "fv_001"
        assert version_dir.exists()

        mgr.invalidate_version("fv_001", "fl_001")
        assert not version_dir.exists()

    def test_invalidate_nonexistent_is_safe(self, tmp_path: Path) -> None:
        mgr = CacheManager(cache_dir=tmp_path)
        # Should not raise
        mgr.invalidate_version("fv_nonexistent", "fl_nonexistent")


class TestClearAll:
    """Delete entire cache directory."""

    def test_clear_removes_everything(self, tmp_path: Path) -> None:
        mgr = CacheManager(cache_dir=tmp_path)
        mgr.write_flow_metadata("fl_001", {"name": "test"})
        mgr.write_version("fv_001", "fl_001", _make_version_data())

        assert (tmp_path / "flows").exists()

        mgr.clear_all()

        # The cache_dir itself may or may not exist, but its contents should be gone
        assert not (tmp_path / "flows").exists()
        assert not (tmp_path / "index.json").exists()

    def test_clear_on_empty_cache_is_safe(self, tmp_path: Path) -> None:
        mgr = CacheManager(cache_dir=tmp_path)
        # Should not raise
        mgr.clear_all()
