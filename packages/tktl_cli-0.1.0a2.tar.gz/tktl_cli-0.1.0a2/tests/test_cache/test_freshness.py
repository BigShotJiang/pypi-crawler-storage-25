"""Tests for freshness logic — TTL-based staleness detection."""

from __future__ import annotations

from datetime import datetime, timezone

from tktl.cache.freshness import cached_at_now, is_fresh


class TestIsFresh:
    """Compare _cached_at timestamp against now with TTL."""

    def test_recent_timestamp_is_fresh(self) -> None:
        # A timestamp from right now should be fresh with default 300s TTL
        now = cached_at_now()
        assert is_fresh(now) is True

    def test_old_timestamp_is_stale(self) -> None:
        # A timestamp from 10 minutes ago should be stale with 300s TTL
        old = datetime(2020, 1, 1, 0, 0, 0, tzinfo=timezone.utc).isoformat()
        assert is_fresh(old) is False

    def test_custom_ttl(self) -> None:
        now = cached_at_now()
        # With a TTL of 0 seconds, everything is stale
        assert is_fresh(now, ttl_seconds=0) is False

    def test_exactly_at_boundary(self) -> None:
        # A very old timestamp should always be stale
        old = datetime(2000, 1, 1, tzinfo=timezone.utc).isoformat()
        assert is_fresh(old, ttl_seconds=300) is False

    def test_large_ttl_keeps_old_data_fresh(self) -> None:
        # With a huge TTL (10 years), even a year-old timestamp is "fresh"
        one_year_ago = datetime(2025, 3, 17, tzinfo=timezone.utc).isoformat()
        ten_years_secs = 10 * 365 * 24 * 3600
        assert is_fresh(one_year_ago, ttl_seconds=ten_years_secs) is True


class TestCachedAtNow:
    """cached_at_now() returns a valid ISO timestamp."""

    def test_returns_iso_string(self) -> None:
        ts = cached_at_now()
        assert isinstance(ts, str)
        # Should be parseable as a datetime
        dt = datetime.fromisoformat(ts)
        assert dt.tzinfo is not None  # Should be timezone-aware

    def test_returns_utc(self) -> None:
        ts = cached_at_now()
        dt = datetime.fromisoformat(ts)
        assert dt.tzinfo == timezone.utc
