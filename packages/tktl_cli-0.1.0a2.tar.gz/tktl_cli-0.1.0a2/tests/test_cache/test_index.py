"""Tests for CacheIndex — slug-to-ID resolution and index persistence."""

from __future__ import annotations

import json
from pathlib import Path

from tktl.cache.index import CacheIndex


class TestCacheIndexLoadSave:
    """Create, read, update, and persist index.json."""

    def test_load_missing_file_returns_empty_state(self, tmp_path: Path) -> None:
        idx = CacheIndex(cache_dir=tmp_path)
        idx.load()
        assert idx.workspace_id is None
        assert idx.flows == {}
        assert idx.updated_at is None

    def test_save_creates_index_file(self, tmp_path: Path) -> None:
        idx = CacheIndex(cache_dir=tmp_path)
        idx.workspace_id = "ws_123"
        idx.save()

        index_file = tmp_path / "index.json"
        assert index_file.exists()
        data = json.loads(index_file.read_text())
        assert data["workspace_id"] == "ws_123"
        assert "flows" in data
        assert "updated_at" in data

    def test_round_trip_load_save(self, tmp_path: Path) -> None:
        idx = CacheIndex(cache_dir=tmp_path)
        idx.workspace_id = "ws_abc"
        idx.update_flow("credit-scoring", "fl_001", {"v1": "fv_001", "v2": "fv_002"})
        idx.save()

        idx2 = CacheIndex(cache_dir=tmp_path)
        idx2.load()
        assert idx2.workspace_id == "ws_abc"
        assert idx2.flows["credit-scoring"]["id"] == "fl_001"
        assert idx2.flows["credit-scoring"]["versions"]["v1"] == "fv_001"
        assert idx2.flows["credit-scoring"]["versions"]["v2"] == "fv_002"

    def test_save_creates_parent_directories(self, tmp_path: Path) -> None:
        nested = tmp_path / "a" / "b" / "cache"
        idx = CacheIndex(cache_dir=nested)
        idx.workspace_id = "ws_test"
        idx.save()
        assert (nested / "index.json").exists()

    def test_save_sets_updated_at(self, tmp_path: Path) -> None:
        idx = CacheIndex(cache_dir=tmp_path)
        idx.save()
        data = json.loads((tmp_path / "index.json").read_text())
        assert data["updated_at"] is not None
        # Should be an ISO-format string
        assert "T" in data["updated_at"]


class TestCacheIndexResolve:
    """Slug-to-ID and version-name-to-ID resolution."""

    def test_resolve_flow_id_existing(self, tmp_path: Path) -> None:
        idx = CacheIndex(cache_dir=tmp_path)
        idx.update_flow("credit-scoring", "fl_001", {"v1": "fv_001"})
        assert idx.resolve_flow_id("credit-scoring") == "fl_001"

    def test_resolve_flow_id_missing(self, tmp_path: Path) -> None:
        idx = CacheIndex(cache_dir=tmp_path)
        assert idx.resolve_flow_id("nonexistent") is None

    def test_resolve_version_id_existing(self, tmp_path: Path) -> None:
        idx = CacheIndex(cache_dir=tmp_path)
        idx.update_flow("credit-scoring", "fl_001", {"v1": "fv_001", "v2": "fv_002"})
        assert idx.resolve_version_id("credit-scoring", "v1") == "fv_001"
        assert idx.resolve_version_id("credit-scoring", "v2") == "fv_002"

    def test_resolve_version_id_missing_flow(self, tmp_path: Path) -> None:
        idx = CacheIndex(cache_dir=tmp_path)
        assert idx.resolve_version_id("nonexistent", "v1") is None

    def test_resolve_version_id_missing_version(self, tmp_path: Path) -> None:
        idx = CacheIndex(cache_dir=tmp_path)
        idx.update_flow("credit-scoring", "fl_001", {"v1": "fv_001"})
        assert idx.resolve_version_id("credit-scoring", "v3") is None


class TestCacheIndexUpdate:
    """Incremental updates to the index."""

    def test_update_flow_creates_entry(self, tmp_path: Path) -> None:
        idx = CacheIndex(cache_dir=tmp_path)
        idx.update_flow("my-flow", "fl_999", {"v1": "fv_100"})
        assert idx.flows["my-flow"]["id"] == "fl_999"
        assert idx.flows["my-flow"]["versions"]["v1"] == "fv_100"

    def test_update_flow_overwrites_entry(self, tmp_path: Path) -> None:
        idx = CacheIndex(cache_dir=tmp_path)
        idx.update_flow("my-flow", "fl_old", {"v1": "fv_old"})
        idx.update_flow("my-flow", "fl_new", {"v1": "fv_new", "v2": "fv_200"})
        assert idx.flows["my-flow"]["id"] == "fl_new"
        assert idx.flows["my-flow"]["versions"]["v1"] == "fv_new"
        assert idx.flows["my-flow"]["versions"]["v2"] == "fv_200"

    def test_update_version_adds_to_existing_flow(self, tmp_path: Path) -> None:
        idx = CacheIndex(cache_dir=tmp_path)
        idx.update_flow("my-flow", "fl_001", {"v1": "fv_001"})
        idx.update_version("my-flow", "v2", "fv_002")
        assert idx.flows["my-flow"]["versions"]["v2"] == "fv_002"
        # Existing version untouched
        assert idx.flows["my-flow"]["versions"]["v1"] == "fv_001"

    def test_update_version_overwrites_existing_version(self, tmp_path: Path) -> None:
        idx = CacheIndex(cache_dir=tmp_path)
        idx.update_flow("my-flow", "fl_001", {"v1": "fv_old"})
        idx.update_version("my-flow", "v1", "fv_new")
        assert idx.flows["my-flow"]["versions"]["v1"] == "fv_new"

    def test_update_version_for_unknown_flow_is_noop(self, tmp_path: Path) -> None:
        idx = CacheIndex(cache_dir=tmp_path)
        # Should not raise; silently ignored since the flow isn't in the index
        idx.update_version("unknown-flow", "v1", "fv_001")
        assert "unknown-flow" not in idx.flows
