"""Tests for tktl.telemetry — token estimation, track, tracked decorator."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from pydantic import BaseModel
from typer.testing import CliRunner

from tktl.cli._error_handler import handle_errors
from tktl.cli.main import app
from tktl.models.node import NodeDetail
from tktl.telemetry import _init, _state, disable, estimate_tokens, get_source, identify, set_source, track, tracked


@pytest.fixture(autouse=True)
def _reset_telemetry_state():
    """Reset telemetry state before and after each test."""
    _state.client = None
    _state.distinct_id = None
    _state.disabled = False
    _state.source = "library"
    yield
    _state.client = None
    _state.distinct_id = None
    _state.disabled = False
    _state.source = "library"


class TestEstimateTokens:
    def test_pydantic_model(self):
        class Dummy(BaseModel):
            name: str
            value: int

        m = Dummy(name="hello", value=42)
        tokens = estimate_tokens(m)
        assert tokens > 0

    def test_list_of_models(self):
        class Dummy(BaseModel):
            name: str

        items = [Dummy(name="a"), Dummy(name="bb"), Dummy(name="ccc")]
        tokens = estimate_tokens(items)
        assert tokens > 0

    def test_dict(self):
        d = {"key": "value", "number": 123}
        tokens = estimate_tokens(d)
        assert tokens > 0

    def test_none(self):
        assert estimate_tokens(None) == 0

    def test_empty_list(self):
        tokens = estimate_tokens([])
        assert tokens >= 0  # "[]" is 2 chars → 0 tokens

    def test_string(self):
        tokens = estimate_tokens("hello world this is a test string")
        assert tokens > 0

    def test_node_detail_with_meta(self):
        node = NodeDetail(
            id="node_1",
            name="Risk Engine",
            type="decision_table",
            meta={"score_threshold": 500, "rules": [{"id": "r1", "condition": "x > 5"}]},
        )
        tokens = estimate_tokens(node)
        assert tokens > 10


class TestTrack:
    def test_noop_when_not_initialized(self):
        """track() should be a no-op when telemetry is not initialized."""
        _state.disabled = True
        # Should not raise
        track("operation", {"op": "test"})

    def test_calls_posthog_capture_when_initialized(self):
        mock_client = MagicMock()
        _state.client = mock_client
        _state.distinct_id = "user-123"

        track("operation", {"op": "list_flows"})

        mock_client.capture.assert_called_once()
        call_args = mock_client.capture.call_args
        assert call_args[1]["distinct_id"] == "user-123"
        assert call_args[1]["event"] == "tktl_operation"
        assert call_args[1]["properties"]["op"] == "list_flows"


class TestSourceDetection:
    def test_default_source_is_library(self):
        assert get_source() == "library"

    def test_set_source_changes_source(self):
        set_source("cli")
        assert get_source() == "cli"

    def test_track_includes_source(self):
        mock_client = MagicMock()
        _state.client = mock_client
        _state.distinct_id = "user-123"
        _state.source = "cli"

        track("operation", {"op": "test"})

        props = mock_client.capture.call_args[1]["properties"]
        assert props["source"] == "cli"

    def test_handle_errors_sets_source_cli(self):
        @handle_errors
        def my_cli_func():
            return get_source()

        result = my_cli_func()
        assert result == "cli"


class TestIdentify:
    def test_identify_calls_set(self):
        mock_client = MagicMock()
        _state.client = mock_client
        _state.distinct_id = "old-user"

        identify("new-user", {"email": "test@test.com"})

        mock_client.set.assert_called_once()
        call_kwargs = mock_client.set.call_args[1]
        assert call_kwargs["distinct_id"] == "new-user"
        assert call_kwargs["properties"]["email"] == "test@test.com"
        assert _state.distinct_id == "new-user"

    def test_identify_noop_when_disabled(self):
        _state.disabled = True
        _state.client = MagicMock()

        identify("user", {"email": "x"})
        _state.client.set.assert_not_called()


class TestAuthLoginTelemetry:
    def test_auth_login_tracks_event(self, tmp_path):
        mock_client = MagicMock()
        _state.client = mock_client
        _state.distinct_id = "anon-test"

        login_result = {"user_id": "user-123", "email": "test@example.com"}
        runner = CliRunner()
        monkeypatch_env = {"TKTL_CONFIG_DIR": str(tmp_path)}

        with patch.dict("os.environ", monkeypatch_env):
            with patch("tktl.cli.auth._validate_api_key", return_value=login_result):
                result = runner.invoke(app, ["auth", "login"], input="sk-test-key\n")

        assert result.exit_code == 0

        # Check that track("auth_login", ...) was called
        auth_calls = [c for c in mock_client.capture.call_args_list if c[1].get("event") == "tktl_auth_login"]
        assert len(auth_calls) == 1
        props = auth_calls[0][1]["properties"]
        assert props["email"] == "test@example.com"

        # Check that identify (set) was called
        mock_client.set.assert_called_once()
        set_kwargs = mock_client.set.call_args[1]
        assert set_kwargs["distinct_id"] == "user-123"
        assert set_kwargs["properties"]["email"] == "test@example.com"


class TestOptOutAndPrivacy:
    def test_disable_prevents_tracking(self):
        mock_client = MagicMock()
        _state.client = mock_client
        _state.distinct_id = "user-123"

        disable()
        track("operation", {"op": "test"})
        mock_client.capture.assert_not_called()

    def test_config_telemetry_false_prevents_init(self):
        """When config has telemetry=False, _init() should disable and not create client."""
        _state.client = None
        _state.disabled = False

        mock_cfg = MagicMock()
        mock_cfg.get.side_effect = lambda k: False if k == "telemetry" else None

        with patch("tktl.telemetry.Config", return_value=mock_cfg):
            _init()

        assert _state.disabled is True
        assert _state.client is None

    def test_events_contain_no_pii(self):
        """Verify tracked events only contain safe fields, no content/source code/API keys."""
        mock_client = MagicMock()
        _state.client = mock_client
        _state.distinct_id = "user-123"

        track(
            "operation",
            {
                "op": "get_node",
                "success": True,
                "output_tokens": 312,
                "duration_ms": 100,
                "flow_slug": "credit-scoring",
                "flow_version_name": "v1",
                "cache_hit": True,
            },
        )

        props = mock_client.capture.call_args[1]["properties"]
        # These are all safe fields
        safe_keys = {
            "op",
            "success",
            "output_tokens",
            "duration_ms",
            "flow_slug",
            "flow_version_name",
            "cache_hit",
            "source",
            "tktl_version",
        }
        assert set(props.keys()) == safe_keys
        # No content, no API keys, no source code
        for v in props.values():
            if isinstance(v, str):
                assert "sk-" not in v
                assert "def " not in v
                assert "import " not in v


class TestTrackedDecorator:
    def test_emits_success_event(self):
        mock_client = MagicMock()
        _state.client = mock_client
        _state.distinct_id = "user-123"

        @tracked("test_op")
        def my_func():
            return {"result": "data"}

        result = my_func()
        assert result == {"result": "data"}

        mock_client.capture.assert_called_once()
        props = mock_client.capture.call_args[1]["properties"]
        assert props["op"] == "test_op"
        assert props["success"] is True
        assert props["output_tokens"] > 0
        assert "duration_ms" in props

    def test_emits_error_event(self):
        mock_client = MagicMock()
        _state.client = mock_client
        _state.distinct_id = "user-123"

        @tracked("failing_op")
        def bad_func():
            raise ValueError("boom")

        with pytest.raises(ValueError, match="boom"):
            bad_func()

        mock_client.capture.assert_called_once()
        props = mock_client.capture.call_args[1]["properties"]
        assert props["op"] == "failing_op"
        assert props["success"] is False
        assert props["error_type"] == "ValueError"
        assert props["output_tokens"] == 0
        assert "duration_ms" in props
