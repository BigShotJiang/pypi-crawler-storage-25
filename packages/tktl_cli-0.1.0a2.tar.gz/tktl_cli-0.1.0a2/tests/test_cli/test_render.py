"""Tests for tktl render command."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

from typer.testing import CliRunner

from tktl.cli.main import app
from tktl.models.errors import RenderError

runner = CliRunner()


def _mock_render(tmp_path: Path):
    """Context manager: patches render_mermaid_png to write a fake PNG and return its path."""
    png = tmp_path / "20260101_120000.png"
    png.write_bytes(b"PNG")
    return patch("tktl.cli.render_cmd.render_mermaid_png", return_value=png)


class TestRenderText:
    def test_inline_text_prints_file_url(self, tmp_path: Path) -> None:
        with _mock_render(tmp_path):
            result = runner.invoke(app, ["render", "--text", "flowchart TD\n  A --> B"])
        assert result.exit_code == 0, result.output
        assert "file://" in result.output

    def test_inline_text_passes_code_to_renderer(self, tmp_path: Path) -> None:
        png = tmp_path / "out.png"
        png.write_bytes(b"PNG")
        with patch("tktl.cli.render_cmd.render_mermaid_png", return_value=png) as mock_render:
            runner.invoke(app, ["render", "--text", "flowchart TD\n  A --> B"])
        mock_render.assert_called_once()
        code_arg = mock_render.call_args[0][0]
        assert "flowchart TD" in code_arg

    def test_no_input_exits_with_error(self) -> None:
        result = runner.invoke(app, ["render"])
        assert result.exit_code != 0

    def test_text_and_file_together_exits_with_error(self, tmp_path: Path) -> None:
        md = tmp_path / "plan.md"
        md.write_text("```mermaid\nflowchart TD\n  A --> B\n```")
        result = runner.invoke(app, ["render", "--text", "flowchart TD\n  A --> B", str(md)])
        assert result.exit_code != 0


class TestRenderFile:
    def test_file_with_mermaid_block_prints_url(self, tmp_path: Path) -> None:
        md = tmp_path / "plan.md"
        md.write_text("# Flow\n```mermaid\nflowchart TD\n  A --> B\n```\n")
        with _mock_render(tmp_path):
            result = runner.invoke(app, ["render", str(md)])
        assert result.exit_code == 0, result.output
        assert "file://" in result.output

    def test_file_not_found_exits_with_error(self) -> None:
        result = runner.invoke(app, ["render", "/nonexistent/path/plan.md"])
        assert result.exit_code != 0

    def test_file_with_no_mermaid_blocks_exits_zero(self, tmp_path: Path) -> None:
        md = tmp_path / "plan.md"
        md.write_text("# No diagrams here\nJust text.")
        result = runner.invoke(app, ["render", str(md)])
        assert result.exit_code == 0
        assert "No mermaid" in result.output

    def test_multiple_blocks_prints_multiple_urls(self, tmp_path: Path) -> None:
        md = tmp_path / "plan.md"
        md.write_text("```mermaid\nflowchart TD\n  A --> B\n```\n\n```mermaid\nflowchart TD\n  C --> D\n```\n")
        png1 = tmp_path / "20260101_120000.png"
        png2 = tmp_path / "20260101_120001.png"
        png1.write_bytes(b"PNG")
        png2.write_bytes(b"PNG")
        with patch("tktl.cli.render_cmd.render_mermaid_png", side_effect=[png1, png2]):
            result = runner.invoke(app, ["render", str(md)])
        assert result.exit_code == 0
        assert result.output.count("file://") == 2


class TestRenderStdin:
    def test_stdin_dash_extracts_blocks(self, tmp_path: Path) -> None:
        md_content = "```mermaid\nflowchart TD\n  A --> B\n```\n"
        with _mock_render(tmp_path):
            result = runner.invoke(app, ["render", "-"], input=md_content)
        assert result.exit_code == 0, result.output
        assert "file://" in result.output


class TestRenderError:
    def test_render_error_prints_warning_and_exits_zero(self, tmp_path: Path) -> None:
        with patch("tktl.cli.render_cmd.render_mermaid_png", side_effect=RenderError("timeout")):
            result = runner.invoke(app, ["render", "--text", "flowchart TD\n  A --> B"])
        assert result.exit_code == 0
        assert "render failed" in result.stderr or "render failed" in result.output

    def test_quiet_suppresses_output(self, tmp_path: Path) -> None:
        with _mock_render(tmp_path):
            result = runner.invoke(app, ["render", "--text", "flowchart TD\n  A --> B", "--quiet"])
        assert result.exit_code == 0
        assert result.output.strip() == ""
