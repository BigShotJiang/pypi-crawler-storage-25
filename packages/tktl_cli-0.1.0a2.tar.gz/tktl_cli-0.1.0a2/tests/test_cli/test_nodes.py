"""Tests for CLI nodes commands: list, describe, add."""

from __future__ import annotations

import json

from typer.testing import CliRunner

from tktl.cli.main import app

runner = CliRunner()

CUSTOM_CONNECTION_CONFIG = json.dumps(
    {
        "provider_resource": {"provider": "custom", "resource": "http"},
        "connection_id": "conn_00000000-0000-0000-0000-000000000001",
        "resource_config_id": "rc_00000000-0000-0000-0000-000000000001",
        "config": {
            "error": {"allow_4xx": False, "allow_5xx": False},
            "caching": {"active": False},
            "testing": {"use_cached_reports": False},
            "timeout": {"active": False},
            "environments_config": {
                "production": "production",
                "sandbox_mode_data_source": "production",
                "authoring_mode_data_source": "mock_data",
            },
        },
        "verb": "get",
        "path": {"id": "", "expression": ""},
        "params": [],
        "headers": [],
        "body": {"id": "", "value": {"selected": "raw", "raw": "{}"}},
        "response": {"id": "", "active": True, "mapped_to": "credit_score_output"},
    }
)

MANUAL_REVIEW_CONFIG = json.dumps(
    {
        "provider_resource": {"provider": "manual_review", "resource": "manual_review"},
        "connection_id": "conn_00000000-0000-0000-0000-000000000003",
        "resource_config_id": "rc_00000000-0000-0000-0000-000000000003",
        "highlights": [
            {"type": "divider"},
            {
                "type": "field",
                "id_readable_name": "00000000-0000-0000-0000-000000000001",
                "id_value": "00000000-0000-0000-0000-000000000002",
                "readable_name": "Applicant Name",
                "value": "data.applicant_name",
            },
        ],
        "response_form": {
            "description": "Review the application",
            "fields": [
                {
                    "id": "00000000-0000-0000-0000-000000000010",
                    "key": "approved",
                    "type": "boolean",
                    "required": True,
                    "name": "Approved",
                    "enum": None,
                    "display_as": None,
                },
            ],
        },
        "reviewer_assign_strategy": "ANY",
        "reviewer_assign_strategy_v2": {"type": "ANY"},
        "response_metadata_key": None,
    }
)


class TestNodesList:
    def test_list_json(self, cli_env):
        result = runner.invoke(app, ["nodes", "list", "credit-scoring", "v1", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert isinstance(data, list)
        assert len(data) >= 3
        ids = [n["id"] for n in data]
        assert "node_input" in ids
        assert "node_risk" in ids
        assert "node_pricing" in ids

    def test_list_json_shows_group_annotation(self, cli_env):
        result = runner.invoke(app, ["nodes", "list", "credit-scoring", "v1", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        by_id = {n["id"]: n for n in data}
        # node_risk and node_pricing are in the "Scoring" group
        assert by_id["node_risk"]["group_id"] == "group_scoring"
        assert by_id["node_risk"]["group_name"] == "Scoring"
        assert by_id["node_pricing"]["group_id"] == "group_scoring"
        # node_input is not in any group
        assert by_id["node_input"]["group_id"] is None
        assert by_id["node_input"]["group_name"] is None

    def test_list_table(self, cli_env):
        result = runner.invoke(app, ["nodes", "list", "credit-scoring", "v1", "--output", "table"])
        assert result.exit_code == 0, result.output
        assert "node_input" in result.output
        assert "node_risk" in result.output

    def test_list_quiet(self, cli_env):
        result = runner.invoke(app, ["nodes", "list", "credit-scoring", "v1", "--output", "json", "--quiet"])
        assert result.exit_code == 0
        assert result.output.strip() == ""


class TestNodesDescribe:
    def test_describe_json(self, cli_env):
        result = runner.invoke(app, ["nodes", "describe", "credit-scoring", "v1", "node_risk", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["id"] == "node_risk"
        assert data["name"] == "Risk Engine"
        assert data["type"] == "decision_table"
        assert data["meta"] is not None
        assert data["meta"]["score_threshold"] == 500

    def test_describe_section_meta(self, cli_env):
        result = runner.invoke(
            app,
            ["nodes", "describe", "credit-scoring", "v1", "node_risk", "--section", "meta", "--output", "json"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["id"] == "node_risk"
        assert "meta" in data
        assert data["meta"]["score_threshold"] == 500

    def test_describe_table(self, cli_env):
        result = runner.invoke(app, ["nodes", "describe", "credit-scoring", "v1", "node_risk", "--output", "table"])
        assert result.exit_code == 0, result.output
        assert "node_risk" in result.output

    def test_describe_not_found(self, cli_env):
        result = runner.invoke(app, ["nodes", "describe", "credit-scoring", "v1", "nonexistent", "--output", "json"])
        assert result.exit_code == 4  # NotFoundError


class TestNodesAdd:
    def test_add_node_with_group(self, cli_env):
        """Adding a node with --group should include it in the group's node_ids."""
        result = runner.invoke(
            app,
            [
                "nodes",
                "add",
                "credit-scoring",
                "v2-draft",
                "--type",
                "transform",
                "--name",
                "Normalize",
                "--after",
                "node_input",
                "--src",
                "data.normalized = True",
                "--group",
                "group_ml",
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["name"] == "Normalize"
        # Verify the node was added to the group
        group_result = runner.invoke(
            app, ["groups", "describe", "credit-scoring", "v2-draft", "group_ml", "--output", "json"]
        )
        assert group_result.exit_code == 0, group_result.output
        group_data = json.loads(group_result.output)
        assert data["id"] in group_data["node_ids"]
        assert "node_ml" in group_data["node_ids"]

    def test_add_custom_connection_node(self, cli_env):
        result = runner.invoke(
            app,
            [
                "nodes",
                "add",
                "credit-scoring",
                "v2-draft",
                "--type",
                "custom_connection",
                "--name",
                "Fetch Credit Score",
                "--after",
                "node_input",
                "--config",
                CUSTOM_CONNECTION_CONFIG,
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["name"] == "Fetch Credit Score"
        assert data["type"] == "custom_connection_node"
        assert data["meta"]["connection_id"] == "conn_00000000-0000-0000-0000-000000000001"
        assert data["meta"]["verb"] == "get"

    def test_add_custom_connection_requires_config(self, cli_env):
        result = runner.invoke(
            app,
            [
                "nodes",
                "add",
                "credit-scoring",
                "v2-draft",
                "--type",
                "custom_connection",
                "--name",
                "No Config",
                "--after",
                "node_input",
                "--output",
                "json",
            ],
        )
        assert result.exit_code != 0

    def test_add_manual_review_node(self, cli_env):
        result = runner.invoke(
            app,
            [
                "nodes",
                "add",
                "credit-scoring",
                "v2-draft",
                "--type",
                "manual_review",
                "--name",
                "Review Application",
                "--after",
                "node_input",
                "--config",
                MANUAL_REVIEW_CONFIG,
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["name"] == "Review Application"
        assert data["type"] == "review_connection_node"
        assert data["meta"]["connection_id"] == "conn_00000000-0000-0000-0000-000000000003"
        assert data["meta"]["response_form"]["description"] == "Review the application"
        assert len(data["meta"]["highlights"]) == 2
        assert data["meta"]["highlights"][0]["type"] == "divider"

    def test_add_manual_review_defaults_to_auto(self, cli_env):
        """manual_review without --config or --connection auto-discovers the connection."""
        result = runner.invoke(
            app,
            [
                "nodes",
                "add",
                "credit-scoring",
                "v2-draft",
                "--type",
                "manual_review",
                "--name",
                "Default Review",
                "--after",
                "node_input",
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["type"] == "review_connection_node"
        assert data["meta"]["connection_id"] == "conn_00000000-0000-0000-0000-000000000003"

    def test_add_manual_review_auto_connection(self, cli_env):
        result = runner.invoke(
            app,
            [
                "nodes",
                "add",
                "credit-scoring",
                "v2-draft",
                "--type",
                "manual_review",
                "--name",
                "Auto Review",
                "--after",
                "node_input",
                "--connection",
                "auto",
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["name"] == "Auto Review"
        assert data["type"] == "review_connection_node"
        assert data["meta"]["connection_id"] == "conn_00000000-0000-0000-0000-000000000003"
        assert data["meta"]["resource_config_id"] == "rc_00000000-0000-0000-0000-000000000003"
        assert data["meta"]["provider_resource"] == {"provider": "manual_review", "resource": "manual_review"}
        # Default response form should have the approved field
        assert len(data["meta"]["response_form"]["fields"]) == 1
        assert data["meta"]["response_form"]["fields"][0]["key"] == "approved"

    def test_add_manual_review_explicit_connection_id(self, cli_env):
        result = runner.invoke(
            app,
            [
                "nodes",
                "add",
                "credit-scoring",
                "v2-draft",
                "--type",
                "manual_review",
                "--name",
                "Explicit Review",
                "--after",
                "node_input",
                "--connection",
                "conn_00000000-0000-0000-0000-000000000003",
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["type"] == "review_connection_node"
        assert data["meta"]["connection_id"] == "conn_00000000-0000-0000-0000-000000000003"

    def test_add_subflow_node(self, cli_env):
        """Add a subflow node that references an existing child flow."""
        result = runner.invoke(
            app,
            [
                "nodes",
                "add",
                "credit-scoring",
                "v2-draft",
                "--type",
                "subflow",
                "--name",
                "Enrich Data",
                "--after",
                "node_input",
                "--child-flow",
                "data-enrichment",
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["name"] == "Enrich Data"
        assert data["type"] == "flow"
        meta = data["meta"]
        assert meta["child_flow_slug"] == "data-enrichment"
        assert meta["child_flow_id"] is not None
        assert meta["child_flow_version_id"] is not None
        assert meta["child_flow_version_known_etag"] is not None
        assert meta["is_stale"] is False
        assert meta["input_mappings"] == {}
        assert meta["output_mappings"] == {}

    def test_add_subflow_creates_missing_child_flow(self, cli_env):
        """When child flow doesn't exist, it should be created automatically."""
        result = runner.invoke(
            app,
            [
                "nodes",
                "add",
                "credit-scoring",
                "v2-draft",
                "--type",
                "subflow",
                "--name",
                "New Subflow",
                "--after",
                "node_input",
                "--child-flow",
                "brand-new-flow",
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["type"] == "flow"
        assert data["meta"]["child_flow_slug"] == "brand-new-flow"
        assert data["meta"]["child_flow_id"] is not None

    def test_add_loop_node(self, cli_env):
        """Add a loop node with target and output list expressions."""
        result = runner.invoke(
            app,
            [
                "nodes",
                "add",
                "credit-scoring",
                "v2-draft",
                "--type",
                "loop",
                "--name",
                "Process Items",
                "--after",
                "node_input",
                "--child-flow",
                "data-enrichment",
                "--target-list",
                "data.items",
                "--output-list",
                "data.results",
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["name"] == "Process Items"
        assert data["type"] == "flow_loop"
        meta = data["meta"]
        assert meta["child_flow_slug"] == "data-enrichment"
        assert meta["child_flow_id"] is not None
        assert meta["is_stale"] is False
        assert meta["input_mappings"] == {}
        assert meta["target_list_expression"]["value"] == "data.items"
        assert meta["output_destination_list_expression"]["value"] == "data.results"
        assert meta["break_condition"]["enabled"] is False
        assert meta["break_condition"]["junction"] == "and"

    def test_add_subflow_requires_child_flow(self, cli_env):
        """Subflow without --child-flow or --config should fail."""
        result = runner.invoke(
            app,
            [
                "nodes",
                "add",
                "credit-scoring",
                "v2-draft",
                "--type",
                "subflow",
                "--name",
                "No Child",
                "--after",
                "node_input",
                "--output",
                "json",
            ],
        )
        assert result.exit_code != 0
