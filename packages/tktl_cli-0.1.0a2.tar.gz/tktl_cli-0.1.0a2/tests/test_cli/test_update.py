"""Tests for CLI update commands."""

from __future__ import annotations

import json
from pathlib import Path

from typer.testing import CliRunner

from tktl.cli.main import app

runner = CliRunner()


class TestUpdateNodeConfig:
    def test_update_node_inline_json(self, cli_env):
        config = json.dumps({"score_threshold": 700})
        result = runner.invoke(
            app,
            [
                "update",
                "apply",
                "credit-scoring",
                "v2-draft",
                "--node",
                "node_ml",
                "--node-config",
                config,
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["id"] == "node_ml"

    def test_update_node_from_file(self, cli_env, tmp_path: Path):
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({"model_id": "m2"}))
        result = runner.invoke(
            app,
            [
                "update",
                "apply",
                "credit-scoring",
                "v2-draft",
                "--node",
                "node_ml",
                "--node-config",
                f"@{config_file}",
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["id"] == "node_ml"

    def test_update_node_missing_config(self, cli_env):
        result = runner.invoke(
            app,
            [
                "update",
                "apply",
                "credit-scoring",
                "v2-draft",
                "--node",
                "node_ml",
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 2  # UsageError


class TestUpdateVersionParams:
    def test_update_params_inline(self, cli_env):
        params = json.dumps([{"name": "threshold", "value": 0.9}])
        result = runner.invoke(
            app,
            [
                "update",
                "apply",
                "credit-scoring",
                "v2-draft",
                "--params",
                params,
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert "name" in data

    def test_update_schema_in_from_file(self, cli_env, tmp_path: Path):
        schema_file = tmp_path / "schema.json"
        schema_file.write_text(json.dumps({"type": "object", "properties": {"age": {"type": "number"}}}))
        result = runner.invoke(
            app,
            [
                "update",
                "apply",
                "credit-scoring",
                "v2-draft",
                "--schema-in",
                f"@{schema_file}",
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output

    def test_update_schema_out_inline(self, cli_env):
        schema = json.dumps({"type": "object", "properties": {"result": {"type": "string"}}})
        result = runner.invoke(
            app,
            [
                "update",
                "apply",
                "credit-scoring",
                "v2-draft",
                "--schema-out",
                schema,
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output


class TestUpdateVersionReplace:
    def test_replace_version_from_file(self, cli_env, tmp_path: Path):
        version_file = tmp_path / "version.json"
        version_file.write_text(
            json.dumps(
                {
                    "name": "v2-draft",
                    "status": "DRAFT",
                    "graph": {"nodes": {}},
                }
            )
        )
        result = runner.invoke(
            app,
            [
                "update",
                "apply",
                "credit-scoring",
                "v2-draft",
                "--file",
                str(version_file),
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output


class TestUpdateValidation:
    def test_no_flags_gives_usage_error(self, cli_env):
        result = runner.invoke(
            app,
            ["update", "apply", "credit-scoring", "v2-draft", "--output", "json"],
        )
        assert result.exit_code == 2  # UsageError

    def test_invalid_json_gives_usage_error(self, cli_env):
        result = runner.invoke(
            app,
            [
                "update",
                "apply",
                "credit-scoring",
                "v2-draft",
                "--params",
                "not-valid-json",
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 2  # UsageError

    def test_missing_file_gives_usage_error(self, cli_env):
        result = runner.invoke(
            app,
            [
                "update",
                "apply",
                "credit-scoring",
                "v2-draft",
                "--schema-in",
                "@/nonexistent/file.json",
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 2  # UsageError
