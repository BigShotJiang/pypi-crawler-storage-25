"""Tests for agent-optimized behavior (Phase 14).

- Non-TTY defaults to JSON output
- --quiet suppresses all informational output
- --summary returns minimal output on describe commands
- --section meta on node describe returns only meta
"""

from __future__ import annotations

import json
import sys
from unittest.mock import patch

from typer.testing import CliRunner

from tktl.cli.main import app

runner = CliRunner()


class TestNonTtyDefaults:
    """When stdout is not a TTY, auto format should default to JSON."""

    def test_flows_list_auto_non_tty(self, cli_env):
        """With --output auto and non-TTY stdout, output should be valid JSON."""
        with patch.object(sys.stdout, "isatty", return_value=False):
            result = runner.invoke(app, ["flows", "list", "--output", "auto"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert isinstance(data, list)

    def test_versions_list_auto_non_tty(self, cli_env):
        with patch.object(sys.stdout, "isatty", return_value=False):
            result = runner.invoke(app, ["versions", "list", "credit-scoring", "--output", "auto"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert isinstance(data, list)


class TestQuietMode:
    """--quiet suppresses all informational output across commands."""

    def test_flows_list_quiet(self, cli_env):
        result = runner.invoke(app, ["flows", "list", "--output", "json", "--quiet"])
        assert result.exit_code == 0
        assert result.output.strip() == ""

    def test_versions_list_quiet(self, cli_env):
        result = runner.invoke(app, ["versions", "list", "credit-scoring", "--output", "json", "--quiet"])
        assert result.exit_code == 0
        assert result.output.strip() == ""

    def test_nodes_list_quiet(self, cli_env):
        result = runner.invoke(app, ["nodes", "list", "credit-scoring", "v1", "--output", "json", "--quiet"])
        assert result.exit_code == 0
        assert result.output.strip() == ""

    def test_flows_describe_quiet(self, cli_env):
        result = runner.invoke(app, ["flows", "describe", "credit-scoring", "--output", "json", "--quiet"])
        assert result.exit_code == 0
        assert result.output.strip() == ""

    def test_versions_describe_quiet(self, cli_env):
        result = runner.invoke(app, ["versions", "describe", "credit-scoring", "v1", "--output", "json", "--quiet"])
        assert result.exit_code == 0
        assert result.output.strip() == ""

    def test_cache_status_quiet(self, cli_env):
        result = runner.invoke(app, ["cache", "status", "--output", "json", "--quiet"])
        assert result.exit_code == 0
        assert result.output.strip() == ""


class TestSummaryMode:
    """--summary returns minimal output on describe commands."""

    def test_flows_describe_summary(self, cli_env):
        result = runner.invoke(app, ["flows", "describe", "credit-scoring", "--summary", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        # Summary should only have minimal fields
        assert set(data.keys()) == {"slug", "id", "name"}

    def test_versions_describe_summary(self, cli_env):
        result = runner.invoke(
            app,
            ["versions", "describe", "credit-scoring", "v1", "--summary", "--output", "json"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert set(data.keys()) == {"name", "id", "status"}


class TestSectionFilter:
    """--section on node describe filters output."""

    def test_node_describe_section_meta(self, cli_env):
        result = runner.invoke(
            app,
            ["nodes", "describe", "credit-scoring", "v1", "node_risk", "--section", "meta", "--output", "json"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        # Should have id, name, type, and meta
        assert data["id"] == "node_risk"
        assert data["meta"] is not None
        assert data["meta"]["score_threshold"] == 500

    def test_node_describe_no_section_has_all_fields(self, cli_env):
        result = runner.invoke(
            app,
            ["nodes", "describe", "credit-scoring", "v1", "node_risk", "--output", "json"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["id"] == "node_risk"
        assert data["name"] == "Risk Engine"
        assert data["type"] == "decision_table"
        assert data["meta"] is not None
