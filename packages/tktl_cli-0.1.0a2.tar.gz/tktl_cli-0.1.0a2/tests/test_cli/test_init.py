import json
from unittest.mock import patch

from typer.testing import CliRunner

from tktl.cli.main import app

runner = CliRunner()

MOCK_LOGIN_RESULT = {"user_id": "user-123", "email": "test@example.com"}


def test_init_prod_happy_path(tmp_path, monkeypatch):
    """Prod user: key validates on first try, no URL prompts shown."""
    monkeypatch.setenv("TKTL_CONFIG_DIR", str(tmp_path))
    with patch("tktl.cli.init_cmd._validate_api_key", return_value=MOCK_LOGIN_RESULT):
        result = runner.invoke(
            app,
            ["init"],
            input="sk-test-key\nmy-org-id\nmy-workspace\nsandbox\n",
        )
    assert result.exit_code == 0
    assert "test@example.com" in result.output
    # Should NOT prompt for URLs
    assert "Taktile API URL" not in result.output

    cfg = json.loads((tmp_path / "config.json").read_text())
    assert cfg["org"] == "my-org-id"
    assert cfg["workspace"] == "my-workspace"
    assert cfg["env"] == "sandbox"
    assert cfg["taktile_api_url"] is None
    assert cfg["flow_api_url"] is None

    creds = json.loads((tmp_path / "credentials.json").read_text())
    assert creds["api_key"] == "sk-test-key"
    assert creds["user_id"] == "user-123"


def test_init_custom_env_after_prod_fails(tmp_path, monkeypatch):
    """Internal user: prod fails, user says yes to custom env, re-validates."""
    monkeypatch.setenv("TKTL_CONFIG_DIR", str(tmp_path))

    # First call (prod) fails, second call (custom URL) succeeds
    with patch(
        "tktl.cli.init_cmd._validate_api_key",
        side_effect=[None, MOCK_LOGIN_RESULT],
    ):
        result = runner.invoke(
            app,
            ["init"],
            input=(
                "sk-dev-key\n"  # API key
                "y\n"  # yes, custom environment
                "https://taktile-api.dev.cp.taktile.com\n"  # custom taktile URL
                "https://flow-api.dev.cp.taktile.com\n"  # custom flow URL
                "my-org\n"  # org
                "my-ws\n"  # workspace
                "sandbox\n"  # env
            ),
        )
    assert result.exit_code == 0
    assert "test@example.com" in result.output

    cfg = json.loads((tmp_path / "config.json").read_text())
    assert cfg["taktile_api_url"] == "https://taktile-api.dev.cp.taktile.com"
    assert cfg["flow_api_url"] == "https://flow-api.dev.cp.taktile.com"


def test_init_custom_env_also_fails(tmp_path, monkeypatch):
    """Key is invalid everywhere — exits with error."""
    monkeypatch.setenv("TKTL_CONFIG_DIR", str(tmp_path))

    with patch("tktl.cli.init_cmd._validate_api_key", return_value=None):
        result = runner.invoke(
            app,
            ["init"],
            input=(
                "bad-key\n"  # API key
                "y\n"  # yes, custom environment
                "https://custom-api.example.com\n"  # custom taktile URL
                "https://custom-flow.example.com\n"  # custom flow URL
            ),
        )
    assert result.exit_code != 0


def test_init_prod_fails_user_declines_custom(tmp_path, monkeypatch):
    """Prod fails, user says no to custom env — exits with error."""
    monkeypatch.setenv("TKTL_CONFIG_DIR", str(tmp_path))

    with patch("tktl.cli.init_cmd._validate_api_key", return_value=None):
        result = runner.invoke(
            app,
            ["init"],
            input="bad-key\nn\n",
        )
    assert result.exit_code != 0
    assert "Invalid" in result.output or "invalid" in result.output


def test_init_env_default_sandbox(tmp_path, monkeypatch):
    """Default env is sandbox when user presses enter."""
    monkeypatch.setenv("TKTL_CONFIG_DIR", str(tmp_path))
    with patch("tktl.cli.init_cmd._validate_api_key", return_value=MOCK_LOGIN_RESULT):
        result = runner.invoke(
            app,
            ["init"],
            input="sk-test-key\nmy-org\nmy-ws\n\n",
        )
    assert result.exit_code == 0
    cfg = json.loads((tmp_path / "config.json").read_text())
    assert cfg["env"] == "sandbox"


def test_init_shows_prod_default_info(tmp_path, monkeypatch):
    """Init mentions it's validating against prod."""
    monkeypatch.setenv("TKTL_CONFIG_DIR", str(tmp_path))
    with patch("tktl.cli.init_cmd._validate_api_key", return_value=MOCK_LOGIN_RESULT):
        result = runner.invoke(
            app,
            ["init"],
            input="sk-test-key\nmy-org\nmy-ws\nsandbox\n",
        )
    assert "api.taktile.com" in result.output
