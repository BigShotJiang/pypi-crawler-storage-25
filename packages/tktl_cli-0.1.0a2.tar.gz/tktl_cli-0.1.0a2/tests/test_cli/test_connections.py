"""Tests for tktl connections commands."""

from __future__ import annotations

import json

from typer.testing import CliRunner

from tktl.cli._deps import Deps
from tktl.cli.main import app

runner = CliRunner()


class TestConnectionsList:
    def test_list_json(self, cli_env: Deps) -> None:
        result = runner.invoke(app, ["connections", "list", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert isinstance(data, list)
        assert len(data) == 3

        names = {c["name"] for c in data}
        assert "Postman Echo" in names
        assert "Credit Bureau" in names
        assert "Manual Review" in names

    def test_list_json_has_resource_configs(self, cli_env: Deps) -> None:
        result = runner.invoke(app, ["connections", "list", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)

        postman = next(c for c in data if c["name"] == "Postman Echo")
        assert len(postman["resource_configs"]) == 1
        assert postman["resource_configs"][0]["name"] == "HTTP"
        assert postman["resource_configs"][0]["resource"] == "http"

    def test_list_table(self, cli_env: Deps) -> None:
        result = runner.invoke(app, ["connections", "list", "--output", "table"])
        assert result.exit_code == 0, result.output
        assert "Postman Echo" in result.output
        assert "Credit Bureau" in result.output

    def test_list_filter_by_provider_custom(self, cli_env: Deps) -> None:
        result = runner.invoke(app, ["connections", "list", "--provider", "custom", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert len(data) == 2
        assert all(c["provider"] == "custom" for c in data)

    def test_list_filter_by_provider_manual_review(self, cli_env: Deps) -> None:
        result = runner.invoke(app, ["connections", "list", "--provider", "manual_review", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert len(data) == 1
        assert data[0]["name"] == "Manual Review"
        assert data[0]["provider"] == "manual_review"

    def test_list_filter_by_provider_none_found(self, cli_env: Deps) -> None:
        result = runner.invoke(app, ["connections", "list", "--provider", "nonexistent", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert len(data) == 0

    def test_list_quiet(self, cli_env: Deps) -> None:
        result = runner.invoke(app, ["connections", "list", "--quiet"])
        assert result.exit_code == 0
        assert result.output.strip() == ""


class TestConnectionsCreate:
    def test_create_json(self, cli_env: Deps) -> None:
        result = runner.invoke(
            app,
            [
                "connections",
                "create",
                "--name",
                "Test Conn",
                "--provider",
                "custom",
                "--base-url",
                "https://example.com",
                "--auth-method",
                "no_auth",
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["name"] == "Test Conn"
        assert data["provider"] == "custom"
        assert "id" in data

    def test_create_with_secrets(self, cli_env: Deps) -> None:
        result = runner.invoke(
            app,
            [
                "connections",
                "create",
                "--name",
                "Secret Conn",
                "--provider",
                "custom",
                "--secret",
                "api_key=abc123",
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["name"] == "Secret Conn"
        assert "id" in data

    def test_create_quiet(self, cli_env: Deps) -> None:
        result = runner.invoke(
            app,
            ["connections", "create", "--name", "Quiet Conn", "--provider", "custom", "--quiet"],
        )
        assert result.exit_code == 0
        assert result.output.strip() == ""


class TestConnectionsCreateResource:
    def test_create_resource_json(self, cli_env: Deps) -> None:
        result = runner.invoke(
            app,
            [
                "connections",
                "create-resource",
                "conn_00000000-0000-0000-0000-000000000001",
                "--name",
                "HTTP Resource",
                "--resource",
                "http",
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["name"] == "HTTP Resource"
        assert data["resource"] == "http"
        assert data["connection_config_id"] == "conn_00000000-0000-0000-0000-000000000001"
        assert "id" in data


class TestConnectionsUpdateSecrets:
    def test_update_secrets_json(self, cli_env: Deps) -> None:
        result = runner.invoke(
            app,
            [
                "connections",
                "update-secrets",
                "conn_00000000-0000-0000-0000-000000000001",
                "--secret",
                "api_key=abc123",
                "--env",
                "production",
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert isinstance(data, list)
        assert len(data) == 1
        assert data[0]["key"] == "api_key"
        assert data[0]["value"] == "abc123"
        assert data[0]["environment"] == "production"

    def test_update_multiple_secrets(self, cli_env: Deps) -> None:
        result = runner.invoke(
            app,
            [
                "connections",
                "update-secrets",
                "conn_00000000-0000-0000-0000-000000000001",
                "--secret",
                "key1=val1",
                "--secret",
                "key2=val2",
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert isinstance(data, list)
        assert len(data) == 2
