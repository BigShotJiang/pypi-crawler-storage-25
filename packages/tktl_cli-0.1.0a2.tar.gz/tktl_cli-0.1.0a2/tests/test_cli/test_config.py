from typer.testing import CliRunner

from tktl.cli.main import app

runner = CliRunner()


def test_config_set_and_get(tmp_path, monkeypatch):
    monkeypatch.setenv("TKTL_CONFIG_DIR", str(tmp_path))
    result = runner.invoke(app, ["config", "set", "org", "my-org"])
    assert result.exit_code == 0

    result = runner.invoke(app, ["config", "get", "org"])
    assert result.exit_code == 0
    assert "my-org" in result.output


def test_config_get_default(tmp_path, monkeypatch):
    monkeypatch.setenv("TKTL_CONFIG_DIR", str(tmp_path))
    result = runner.invoke(app, ["config", "get", "env"])
    assert result.exit_code == 0
    assert "sandbox" in result.output


def test_config_list(tmp_path, monkeypatch):
    monkeypatch.setenv("TKTL_CONFIG_DIR", str(tmp_path))
    runner.invoke(app, ["config", "set", "org", "my-org"])
    result = runner.invoke(app, ["config", "list"])
    assert result.exit_code == 0
    assert "org" in result.output
    assert "my-org" in result.output
