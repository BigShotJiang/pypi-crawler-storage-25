"""Tests for CLI versions commands: list, describe."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

from typer.testing import CliRunner

from tktl.cli.main import app
from tktl.models.errors import RenderError

runner = CliRunner()


class TestVersionsList:
    def test_list_json(self, cli_env):
        result = runner.invoke(app, ["versions", "list", "credit-scoring", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert isinstance(data, list)
        assert len(data) == 2
        names = [v["name"] for v in data]
        assert "v1" in names
        assert "v2-draft" in names

    def test_list_table(self, cli_env):
        result = runner.invoke(app, ["versions", "list", "credit-scoring", "--output", "table"])
        assert result.exit_code == 0, result.output
        assert "v1" in result.output
        assert "v2-draft" in result.output

    def test_list_quiet(self, cli_env):
        result = runner.invoke(app, ["versions", "list", "credit-scoring", "--output", "json", "--quiet"])
        assert result.exit_code == 0
        assert result.output.strip() == ""


class TestVersionsDescribe:
    def test_describe_json(self, cli_env):
        result = runner.invoke(app, ["versions", "describe", "credit-scoring", "v1", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["name"] == "v1"
        assert data["status"] == "PUBLISHED"
        assert "id" in data

    def test_describe_summary(self, cli_env):
        result = runner.invoke(app, ["versions", "describe", "credit-scoring", "v1", "--summary", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert set(data.keys()) == {"name", "id", "status"}

    def test_describe_full(self, cli_env):
        result = runner.invoke(app, ["versions", "describe", "credit-scoring", "v1", "--full", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["name"] == "v1"
        assert "graph" in data
        assert "nodes" in data["graph"]
        assert len(data["graph"]["nodes"]) == 4

    def test_describe_default_no_graph(self, cli_env):
        result = runner.invoke(app, ["versions", "describe", "credit-scoring", "v1", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["name"] == "v1"
        assert "graph" not in data or data.get("graph") is None

    def test_describe_table(self, cli_env):
        result = runner.invoke(app, ["versions", "describe", "credit-scoring", "v1", "--output", "table"])
        assert result.exit_code == 0, result.output
        assert "v1" in result.output

    def test_describe_not_found(self, cli_env):
        result = runner.invoke(app, ["versions", "describe", "credit-scoring", "nonexistent", "--output", "json"])
        assert result.exit_code == 4  # NotFoundError

    def test_describe_preview_prints_file_url(self, cli_env):
        fake_png = Path("/tmp/tktl/20260101_120000.png")
        with patch("tktl.cli.versions.preview_version_graph", return_value=fake_png):
            result = runner.invoke(
                app, ["versions", "describe", "credit-scoring", "v1", "--preview", "--output", "table"]
            )
        assert result.exit_code == 0, result.output
        assert "file://" in result.output
        assert "20260101_120000.png" in result.output

    def test_describe_preview_render_error_still_exits_zero(self, cli_env):
        with patch("tktl.cli.versions.preview_version_graph", side_effect=RenderError("timeout")):
            result = runner.invoke(
                app, ["versions", "describe", "credit-scoring", "v1", "--preview", "--output", "table"]
            )
        assert result.exit_code == 0
        assert "render failed" in result.output

    def test_describe_no_preview_by_default(self, cli_env):
        with patch("tktl.cli.versions.preview_version_graph") as mock_preview:
            result = runner.invoke(app, ["versions", "describe", "credit-scoring", "v1", "--output", "table"])
        assert result.exit_code == 0
        mock_preview.assert_not_called()
