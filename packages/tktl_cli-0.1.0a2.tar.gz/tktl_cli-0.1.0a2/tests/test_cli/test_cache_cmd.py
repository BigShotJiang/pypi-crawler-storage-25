"""Tests for CLI cache commands: refresh, clear, status."""

from __future__ import annotations

import json

from typer.testing import CliRunner

from tktl.cli.main import app

runner = CliRunner()


class TestCacheRefresh:
    def test_refresh(self, cli_env):
        result = runner.invoke(app, ["cache", "refresh", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["status"] == "ok"

    def test_refresh_quiet(self, cli_env):
        result = runner.invoke(app, ["cache", "refresh", "--output", "json", "--quiet"])
        assert result.exit_code == 0
        assert result.output.strip() == ""


class TestCacheClear:
    def test_clear(self, cli_env):
        result = runner.invoke(app, ["cache", "clear", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["status"] == "ok"


class TestCacheStatus:
    def test_status(self, cli_env):
        result = runner.invoke(app, ["cache", "status", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert "cache_dir" in data
        assert "exists" in data

    def test_status_after_refresh(self, cli_env):
        # Refresh first to populate cache
        runner.invoke(app, ["cache", "refresh", "--output", "json"])
        result = runner.invoke(app, ["cache", "status", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["exists"] is True
        assert data.get("file_count", 0) > 0
