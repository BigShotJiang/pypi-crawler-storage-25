"""Tests for CLI batch commands."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

from typer.testing import CliRunner

from tktl.cli.main import app
from tktl.models.batch import BatchResult, BatchRowResult, BatchRunMeta
from tktl.ops.batch import parse_batch_file

runner = CliRunner()


def _fake_run_batch_factory(tmp_path: Path):
    """Create a fake run_batch that writes real files (for output testing)."""

    def fake_run_batch(client, workspace_id, flow_slug, file_path, **kwargs):
        runs_dir = kwargs.get("runs_dir") or tmp_path / "runs"
        run_id = "test-run-id"
        run_dir = runs_dir / flow_slug / run_id
        run_dir.mkdir(parents=True, exist_ok=True)

        rows = parse_batch_file(file_path)
        results_path = run_dir / "results.jsonl"
        for i, row in enumerate(rows):
            line = json.dumps(
                {
                    "row_index": i,
                    "input": row,
                    "output": {"status": "success"},
                    "error": None,
                    "duration_ms": 100,
                    "timestamp": "2026-03-20T10:00:00Z",
                }
            )
            with open(results_path, "a") as f:
                f.write(line + "\n")

        meta = BatchRunMeta(
            run_id=run_id,
            flow_slug=flow_slug,
            env=kwargs.get("env", "sandbox"),
            version=kwargs.get("version"),
            source_type="file",
            source=str(file_path),
            source_hash="sha256:fake",
            concurrency=kwargs.get("concurrency", 10),
            total_rows=len(rows),
            succeeded=len(rows),
            failed=0,
            started_at="2026-03-20T10:00:00Z",
            completed_at="2026-03-20T10:00:01Z",
            duration_ms=1000,
        )
        (run_dir / "meta.json").write_text(meta.model_dump_json(indent=2))

        # Update index
        flow_dir = runs_dir / flow_slug
        index_path = flow_dir / "index.json"
        index = {"runs": []}
        if index_path.exists():
            index = json.loads(index_path.read_text())
        index["runs"].append(
            {
                "run_id": run_id,
                "source_type": "file",
                "source": str(file_path),
                "source_hash": "sha256:fake",
                "total_rows": len(rows),
                "succeeded": len(rows),
                "failed": 0,
                "started_at": "2026-03-20T10:00:00Z",
                "duration_ms": 1000,
            }
        )
        index_path.write_text(json.dumps(index))

        return BatchResult(meta=meta, results_path=str(results_path))

    return fake_run_batch


class TestFlowsBatch:
    def test_batch_json_file(self, cli_env, tmp_path: Path):
        input_file = tmp_path / "input.json"
        input_file.write_text(json.dumps([{"income": 50000}, {"income": 75000}]))
        runs_dir = tmp_path / "runs"

        with patch("tktl.cli.flows.run_batch", _fake_run_batch_factory(tmp_path)):
            result = runner.invoke(
                app,
                [
                    "flows",
                    "batch",
                    "credit-scoring",
                    "--file",
                    str(input_file),
                    "--output",
                    "json",
                    "--runs-dir",
                    str(runs_dir),
                ],
            )

        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["meta"]["total_rows"] == 2
        assert data["meta"]["succeeded"] == 2
        assert data["meta"]["failed"] == 0
        assert "results_path" in data

    def test_batch_csv_file(self, cli_env, tmp_path: Path):
        input_file = tmp_path / "input.csv"
        input_file.write_text("income,age\n50000,30\n75000,45\n")
        runs_dir = tmp_path / "runs"

        with patch("tktl.cli.flows.run_batch", _fake_run_batch_factory(tmp_path)):
            result = runner.invoke(
                app,
                [
                    "flows",
                    "batch",
                    "credit-scoring",
                    "--file",
                    str(input_file),
                    "--output",
                    "json",
                    "--runs-dir",
                    str(runs_dir),
                ],
            )

        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["meta"]["total_rows"] == 2

    def test_batch_custom_concurrency(self, cli_env, tmp_path: Path):
        input_file = tmp_path / "input.json"
        input_file.write_text(json.dumps([{"x": 1}]))
        runs_dir = tmp_path / "runs"

        with patch("tktl.cli.flows.run_batch", _fake_run_batch_factory(tmp_path)):
            result = runner.invoke(
                app,
                [
                    "flows",
                    "batch",
                    "credit-scoring",
                    "--file",
                    str(input_file),
                    "--concurrency",
                    "5",
                    "--output",
                    "json",
                    "--runs-dir",
                    str(runs_dir),
                ],
            )

        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["meta"]["concurrency"] == 5

    def test_batch_no_input_gives_error(self, cli_env):
        result = runner.invoke(app, ["flows", "batch", "credit-scoring", "--output", "json"])
        assert result.exit_code == 2  # UsageError

    def test_batch_both_file_and_dataset_gives_error(self, cli_env, tmp_path: Path):
        input_file = tmp_path / "input.json"
        input_file.write_text(json.dumps([{"x": 1}]))
        result = runner.invoke(
            app,
            [
                "flows",
                "batch",
                "credit-scoring",
                "--file",
                str(input_file),
                "--dataset",
                "some-uuid",
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 2  # UsageError

    def test_batch_missing_file_gives_error(self, cli_env, tmp_path: Path):
        with patch("tktl.cli.flows.run_batch", _fake_run_batch_factory(tmp_path)):
            result = runner.invoke(
                app,
                [
                    "flows",
                    "batch",
                    "credit-scoring",
                    "--file",
                    str(tmp_path / "nonexistent.json"),
                    "--output",
                    "json",
                    "--runs-dir",
                    str(tmp_path / "runs"),
                ],
            )
        assert result.exit_code == 2  # UsageError


class TestFlowsBatchHistory:
    def test_list_empty(self, cli_env, tmp_path: Path):
        runs_dir = tmp_path / "runs"
        result = runner.invoke(
            app,
            [
                "flows",
                "history",
                "credit-scoring",
                "--output",
                "json",
                "--runs-dir",
                str(runs_dir),
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data == []

    def test_list_with_runs(self, cli_env, tmp_path: Path):
        runs_dir = tmp_path / "runs"
        flow_dir = runs_dir / "credit-scoring"
        flow_dir.mkdir(parents=True)
        index = {
            "runs": [
                {
                    "run_id": "abc",
                    "source_type": "file",
                    "source": "input.csv",
                    "source_hash": "sha256:000",
                    "total_rows": 5,
                    "succeeded": 5,
                    "failed": 0,
                    "started_at": "2026-03-20T10:00:00Z",
                    "duration_ms": 1000,
                }
            ]
        }
        (flow_dir / "index.json").write_text(json.dumps(index))

        result = runner.invoke(
            app,
            [
                "flows",
                "history",
                "credit-scoring",
                "--output",
                "json",
                "--runs-dir",
                str(runs_dir),
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert len(data) == 1
        assert data[0]["run_id"] == "abc"

    def test_get_run_detail(self, cli_env, tmp_path: Path):
        runs_dir = tmp_path / "runs"
        run_dir = runs_dir / "credit-scoring" / "run-1"
        run_dir.mkdir(parents=True)
        meta = BatchRunMeta(
            run_id="run-1",
            flow_slug="credit-scoring",
            env="sandbox",
            version=None,
            source_type="file",
            source="input.csv",
            source_hash="sha256:abc",
            concurrency=10,
            total_rows=3,
            succeeded=3,
            failed=0,
            started_at="2026-03-20T10:00:00Z",
            completed_at="2026-03-20T10:00:01Z",
            duration_ms=1000,
        )
        (run_dir / "meta.json").write_text(meta.model_dump_json(indent=2))

        result = runner.invoke(
            app,
            [
                "flows",
                "history",
                "credit-scoring",
                "--run-id",
                "run-1",
                "--output",
                "json",
                "--runs-dir",
                str(runs_dir),
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["run_id"] == "run-1"
        assert data["total_rows"] == 3

    def test_query_results(self, cli_env, tmp_path: Path):
        runs_dir = tmp_path / "runs"
        run_dir = runs_dir / "credit-scoring" / "run-q"
        run_dir.mkdir(parents=True)

        # Write meta
        meta = BatchRunMeta(
            run_id="run-q",
            flow_slug="credit-scoring",
            env="sandbox",
            version=None,
            source_type="file",
            source="input.csv",
            source_hash="sha256:abc",
            concurrency=10,
            total_rows=2,
            succeeded=2,
            failed=0,
            started_at="2026-03-20T10:00:00Z",
            completed_at="2026-03-20T10:00:01Z",
            duration_ms=500,
        )
        (run_dir / "meta.json").write_text(meta.model_dump_json(indent=2))

        # Write results
        row1 = BatchRowResult(
            row_index=0,
            input={"income": 50000},
            output={"data": {"decision": "approve", "score": 0.9}},
            error=None,
            duration_ms=100,
            timestamp="2026-03-20T10:00:00Z",
        )
        row2 = BatchRowResult(
            row_index=1,
            input={"income": 25000},
            output={"data": {"decision": "reject", "score": 0.3}},
            error=None,
            duration_ms=100,
            timestamp="2026-03-20T10:00:00Z",
        )
        with open(run_dir / "results.jsonl", "w") as f:
            f.write(row1.model_dump_json() + "\n")
            f.write(row2.model_dump_json() + "\n")

        result = runner.invoke(
            app,
            [
                "flows",
                "history",
                "credit-scoring",
                "--run-id",
                "run-q",
                "--query",
                "output.data.decision",
                "--output",
                "json",
                "--runs-dir",
                str(runs_dir),
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert len(data) == 2
        assert data[0]["value"] == "approve"
        assert data[1]["value"] == "reject"

    def test_get_run_not_found(self, cli_env, tmp_path: Path):
        runs_dir = tmp_path / "runs"
        result = runner.invoke(
            app,
            [
                "flows",
                "history",
                "credit-scoring",
                "--run-id",
                "nonexistent",
                "--output",
                "json",
                "--runs-dir",
                str(runs_dir),
            ],
        )
        assert result.exit_code == 4  # NotFoundError
