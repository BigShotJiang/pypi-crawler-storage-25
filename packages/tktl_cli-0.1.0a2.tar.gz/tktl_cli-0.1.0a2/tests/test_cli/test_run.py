"""Tests for CLI run command."""

from __future__ import annotations

import json
from pathlib import Path

from typer.testing import CliRunner

from tktl.cli.main import app

runner = CliRunner()


class TestRunFlow:
    def test_run_with_file(self, cli_env, tmp_path: Path):
        input_file = tmp_path / "input.json"
        input_file.write_text(json.dumps({"income": 50000}))
        result = runner.invoke(
            app,
            ["flows", "run", "credit-scoring", "--file", str(input_file), "--output", "json"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert isinstance(data, dict)

    def test_run_with_inline_input(self, cli_env):
        result = runner.invoke(
            app,
            ["flows", "run", "credit-scoring", "--input", '{"income": 50000}', "--output", "json"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert isinstance(data, dict)

    def test_run_no_input_gives_error(self, cli_env):
        result = runner.invoke(
            app,
            ["flows", "run", "credit-scoring", "--output", "json"],
        )
        assert result.exit_code == 2  # UsageError

    def test_run_both_inputs_gives_error(self, cli_env, tmp_path: Path):
        input_file = tmp_path / "input.json"
        input_file.write_text(json.dumps({"income": 50000}))
        result = runner.invoke(
            app,
            [
                "flows",
                "run",
                "credit-scoring",
                "--file",
                str(input_file),
                "--input",
                '{"income": 50000}',
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 2  # UsageError


class TestRunExecute:
    """Test the separate run sub-app (tktl run execute)."""

    def test_run_execute_with_inline(self, cli_env):
        result = runner.invoke(
            app,
            ["run", "execute", "credit-scoring", "--input", '{"income": 50000}', "--output", "json"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert isinstance(data, dict)

    def test_run_execute_with_file(self, cli_env, tmp_path: Path):
        input_file = tmp_path / "input.json"
        input_file.write_text(json.dumps({"income": 50000}))
        result = runner.invoke(
            app,
            ["run", "execute", "credit-scoring", "--file", str(input_file), "--output", "json"],
        )
        assert result.exit_code == 0, result.output
