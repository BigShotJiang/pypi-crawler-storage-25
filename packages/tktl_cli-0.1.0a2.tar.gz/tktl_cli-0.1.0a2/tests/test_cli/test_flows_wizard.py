"""Tests for flows wizard command."""

from __future__ import annotations

import json

from typer.testing import CliRunner

from tktl.cli.main import app

runner = CliRunner()


class TestFlowsWizard:
    def test_wizard_creates_flow_with_inputs(self, cli_env):
        """Wizard creates a flow with input and output fields defined."""
        # input: name, slug, input field (income/number), stop, output field (decision/string/N), stop, pattern 1
        user_input = "My Flow\nmy-flow\nincome\nnumber\n\ndecision\nstring\nN\n\n1\n"
        result = runner.invoke(app, ["flows", "wizard", "--output", "json"], input=user_input)
        assert result.exit_code == 0, result.output
        # The JSON output should be the created flow
        lines = result.output.strip().split("\n")
        # Find the JSON output at the end (print_output appends JSON)
        for i, line in enumerate(reversed(lines)):
            if line.startswith("{") or line.startswith("["):
                json_str = "\n".join(reversed(lines[len(lines) - 1 - i :]))
                try:
                    json.loads(json_str)
                    break
                except json.JSONDecodeError:
                    continue
        # The flow should have been created
        assert result.exit_code == 0

    def test_wizard_creates_flow_with_slug_default(self, cli_env):
        """Wizard auto-derives slug from name."""
        # name="Credit Decision", accept default slug, no fields, no pattern
        user_input = "Credit Decision\n\n\n\n\n"
        result = runner.invoke(app, ["flows", "wizard", "--output", "json"], input=user_input)
        assert result.exit_code == 0, result.output

    def test_wizard_skips_pattern(self, cli_env):
        """Wizard works if user skips pattern (presses Enter)."""
        user_input = "Score Flow\nscore-flow\n\n\n\n"
        result = runner.invoke(app, ["flows", "wizard", "--output", "json"], input=user_input)
        assert result.exit_code == 0, result.output

    def test_wizard_no_fields(self, cli_env):
        """Wizard works with no input/output fields (just creates the flow)."""
        user_input = "Simple Flow\nsimple-flow\n\n\n\n"
        result = runner.invoke(app, ["flows", "wizard", "--output", "json"], input=user_input)
        assert result.exit_code == 0, result.output

    def test_wizard_prompts_visible(self, cli_env):
        """Wizard shows the expected prompts."""
        user_input = "My Flow\nmy-flow\n\n\n\n"
        result = runner.invoke(app, ["flows", "wizard"], input=user_input)
        assert "Flow name" in result.output
        assert "Slug" in result.output
        assert "input fields" in result.output.lower()
        assert "output fields" in result.output.lower()
