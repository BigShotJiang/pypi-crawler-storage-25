"""Tests for natural language rule parser."""

from __future__ import annotations

import pytest

from tktl.models.errors import UsageError
from tktl.ops.rule_parser import parse_natural_rule


class TestParseNaturalRule:
    def test_full_rule_with_and(self):
        """Parse rule with 'and' conditions."""
        rule = (
            "if credit_score >= 600 and income >= 20000 "
            "then eligible=True, decline_reason=None "
            "else eligible=False, decline_reason='Low score'"
        )
        result = parse_natural_rule(rule)

        assert "branches" in result
        assert "default_effects" in result
        assert len(result["branches"]) == 1

        branch = result["branches"][0]
        assert branch["junction"] == "and"
        assert len(branch["clauses"]) == 2

        # Check clauses
        clauses = branch["clauses"]
        credit_clause = next(c for c in clauses if "credit_score" in c["left"])
        assert credit_clause["operator"] == "ge"
        assert credit_clause["left"] == "data.credit_score"
        assert credit_clause["right"] == "600"

        income_clause = next(c for c in clauses if "income" in c["left"])
        assert income_clause["operator"] == "ge"
        assert income_clause["left"] == "data.income"
        assert income_clause["right"] == "20000"

        # Check then effects
        effects = branch["effects"]
        eligible_eff = next(e for e in effects if e["target"] == "eligible")
        assert eligible_eff["value"] == "True"

        decline_eff = next(e for e in effects if e["target"] == "decline_reason")
        assert decline_eff["value"] == "None"

        # Check else (default) effects
        default_effs = result["default_effects"]
        eligible_def = next(e for e in default_effs if e["target"] == "eligible")
        assert eligible_def["value"] == "False"

        decline_def = next(e for e in default_effs if e["target"] == "decline_reason")
        # Value should be the string 'Low score'
        assert "Low score" in decline_def["value"]

    def test_rule_with_or(self):
        """Parse rule with 'or' conditions → junction or."""
        rule = "if credit_score < 600 or income < 20000 then eligible=False else eligible=True"
        result = parse_natural_rule(rule)
        branch = result["branches"][0]
        assert branch["junction"] == "or"
        assert len(branch["clauses"]) == 2

    def test_simple_rule(self):
        """Parse simple single-condition rule."""
        rule = "if months_active >= 6 then eligible=True else eligible=False"
        result = parse_natural_rule(rule)
        assert len(result["branches"]) == 1
        branch = result["branches"][0]
        assert len(branch["clauses"]) == 1
        clause = branch["clauses"][0]
        assert clause["left"] == "data.months_active"
        assert clause["operator"] == "ge"
        assert clause["right"] == "6"

        # Then effect
        assert branch["effects"][0]["target"] == "eligible"
        assert branch["effects"][0]["value"] == "True"

        # Else effect
        assert result["default_effects"][0]["target"] == "eligible"
        assert result["default_effects"][0]["value"] == "False"

    def test_missing_else_raises_error(self):
        """Rule without else clause raises UsageError."""
        rule = "if credit_score >= 600 then eligible=True"
        with pytest.raises(UsageError, match="else"):
            parse_natural_rule(rule)

    def test_bad_format_raises_error(self):
        """Completely invalid format raises UsageError."""
        with pytest.raises(UsageError):
            parse_natural_rule("this is not a rule at all")

    def test_operators_lt_le_gt_ne_eq(self):
        """Test various operators."""
        rules = [
            ("if score < 500 then r=1 else r=0", "lt"),
            ("if score <= 500 then r=1 else r=0", "le"),
            ("if score > 500 then r=1 else r=0", "gt"),
            ("if score != 500 then r=1 else r=0", "ne"),
            ("if score == 500 then r=1 else r=0", "eq"),
        ]
        for rule_text, expected_op in rules:
            result = parse_natural_rule(rule_text)
            clause = result["branches"][0]["clauses"][0]
            assert clause["operator"] == expected_op, f"Failed for {rule_text}"

    def test_numeric_value_in_effect(self):
        """Numeric values in effects are preserved as strings."""
        rule = "if score >= 600 then limit=5000 else limit=0"
        result = parse_natural_rule(rule)
        eff = result["branches"][0]["effects"][0]
        assert eff["value"] == "5000"

    def test_string_value_in_effect(self):
        """String values in effects are wrapped in quotes."""
        rule = "if score >= 600 then status=approved else status=rejected"
        result = parse_natural_rule(rule)
        eff = result["branches"][0]["effects"][0]
        assert eff["value"] == '"approved"'

    def test_quoted_string_in_effect(self):
        """Quoted string values in effects have quotes preserved."""
        rule = "if score >= 600 then status='approved' else status='rejected'"
        result = parse_natural_rule(rule)
        eff = result["branches"][0]["effects"][0]
        assert "approved" in eff["value"]
