"""Tests for flows create --template and flows wizard pattern application."""

from __future__ import annotations

import json

from typer.testing import CliRunner

from tktl.cli.main import app
from tktl.ops.templates import TEMPLATES, build_gated, build_linear, build_lookup, build_scored

runner = CliRunner()


class TestTemplateBuilders:
    """Unit tests for template graph builders."""

    def _assert_valid_graph(self, body: dict) -> dict:
        graph = body["graph"]
        nodes = graph["nodes"]
        edges = graph["edges"]
        assert "node_input" in nodes
        assert "node_output" in nodes
        # Every edge references existing nodes
        for e in edges.values():
            assert e["start_node_id"] in nodes, f"Unknown start_node_id: {e['start_node_id']}"
            assert e["end_node_id"] in nodes, f"Unknown end_node_id: {e['end_node_id']}"
        return graph

    def test_linear_structure(self):
        body = build_linear()
        graph = self._assert_valid_graph(body)
        node_types = {n["type"] for n in graph["nodes"].values()}
        assert "transform" in node_types
        assert "assignment_node" in node_types

    def test_gated_structure(self):
        body = build_gated()
        graph = self._assert_valid_graph(body)
        node_types = [n["type"] for n in graph["nodes"].values()]
        assert "split_2" in node_types
        # Two branch transforms + one merge
        assert node_types.count("transform") >= 2

    def test_scored_structure(self):
        body = build_scored()
        graph = self._assert_valid_graph(body)
        node_types = {n["type"] for n in graph["nodes"].values()}
        assert "transform" in node_types
        assert "rule_2" in node_types
        assert "assignment_node" in node_types

    def test_lookup_structure(self):
        body = build_lookup()
        graph = self._assert_valid_graph(body)
        node_types = {n["type"] for n in graph["nodes"].values()}
        assert "transform" in node_types
        assert "decision_table" in node_types
        assert "assignment_node" in node_types

    def test_all_templates_registered(self):
        assert set(TEMPLATES.keys()) == {"linear", "gated", "scored", "lookup"}

    def test_user_id_propagated(self):
        body = build_linear("my-user")
        nodes = body["graph"]["nodes"]
        transform_nodes = [n for n in nodes.values() if n["type"] == "transform"]
        for n in transform_nodes:
            assert n["meta"].get("created_by_id") == "my-user"
            assert n["meta"].get("updated_by_id") == "my-user"


class TestFlowsCreateTemplate:
    def test_create_with_linear_template(self, cli_env):
        result = runner.invoke(
            app,
            ["flows", "create", "tmpl-linear", "Template Linear", "--template", "linear", "--output", "json"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["slug"] == "tmpl-linear"

    def test_create_with_gated_template(self, cli_env):
        result = runner.invoke(
            app,
            ["flows", "create", "tmpl-gated", "Template Gated", "--template", "gated", "--output", "json"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["slug"] == "tmpl-gated"

    def test_create_with_scored_template(self, cli_env):
        result = runner.invoke(
            app,
            ["flows", "create", "tmpl-scored", "Template Scored", "--template", "scored", "--output", "json"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["slug"] == "tmpl-scored"

    def test_create_with_lookup_template(self, cli_env):
        result = runner.invoke(
            app,
            ["flows", "create", "tmpl-lookup", "Template Lookup", "--template", "lookup", "--output", "json"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["slug"] == "tmpl-lookup"

    def test_create_invalid_template(self, cli_env):
        result = runner.invoke(
            app,
            ["flows", "create", "tmpl-bad", "Bad Template", "--template", "nonexistent", "--output", "json"],
        )
        assert result.exit_code != 0

    def test_create_without_template(self, cli_env):
        result = runner.invoke(
            app,
            ["flows", "create", "no-template", "No Template", "--output", "json"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["slug"] == "no-template"
