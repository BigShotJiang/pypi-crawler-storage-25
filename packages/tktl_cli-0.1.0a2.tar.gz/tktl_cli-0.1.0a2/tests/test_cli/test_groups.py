"""Tests for CLI groups commands."""

from __future__ import annotations

import json

from typer.testing import CliRunner

from tktl.cli.main import app

runner = CliRunner()


class TestGroupsList:
    def test_list_json(self, cli_env):
        result = runner.invoke(app, ["groups", "list", "credit-scoring", "v1", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert isinstance(data, list)
        assert len(data) == 1
        assert data[0]["id"] == "group_scoring"
        assert data[0]["name"] == "Scoring"

    def test_list_table(self, cli_env):
        result = runner.invoke(app, ["groups", "list", "credit-scoring", "v1", "--output", "table"])
        assert result.exit_code == 0, result.output
        assert "group_scoring" in result.output
        assert "Scoring" in result.output

    def test_list_empty(self, cli_env):
        result = runner.invoke(app, ["groups", "list", "kyc-check", "v1", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data == []


class TestGroupsDescribe:
    def test_describe_json(self, cli_env):
        result = runner.invoke(app, ["groups", "describe", "credit-scoring", "v1", "group_scoring", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["id"] == "group_scoring"
        assert data["name"] == "Scoring"
        assert set(data["node_ids"]) == {"node_risk", "node_pricing"}

    def test_describe_not_found(self, cli_env):
        result = runner.invoke(app, ["groups", "describe", "credit-scoring", "v1", "nonexistent", "--output", "json"])
        assert result.exit_code == 4  # NotFoundError


class TestGroupsCreate:
    def test_create(self, cli_env):
        result = runner.invoke(
            app,
            [
                "groups",
                "create",
                "credit-scoring",
                "v1",
                "--name",
                "Gate Rules",
                "--node-ids",
                "node_input",
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["name"] == "Gate Rules"
        assert data["node_ids"] == ["node_input"]


class TestGroupsUpdate:
    def test_rename(self, cli_env):
        result = runner.invoke(
            app,
            [
                "groups",
                "update",
                "credit-scoring",
                "v1",
                "group_scoring",
                "--name",
                "Risk & Pricing",
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["name"] == "Risk & Pricing"


class TestGroupsDelete:
    def test_delete(self, cli_env):
        result = runner.invoke(
            app,
            ["groups", "delete", "credit-scoring", "v1", "group_scoring", "--output", "json"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert isinstance(data, list)
        assert len(data) == 0


class TestGroupsAddNodes:
    def test_add_nodes(self, cli_env):
        result = runner.invoke(
            app,
            [
                "groups",
                "add-nodes",
                "credit-scoring",
                "v1",
                "group_scoring",
                "--node-ids",
                "node_input",
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert "node_input" in data["node_ids"]
        assert "node_risk" in data["node_ids"]


class TestGroupsRemoveNodes:
    def test_remove_nodes(self, cli_env):
        result = runner.invoke(
            app,
            [
                "groups",
                "remove-nodes",
                "credit-scoring",
                "v1",
                "group_scoring",
                "--node-ids",
                "node_pricing",
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["node_ids"] == ["node_risk"]
