from __future__ import annotations

import json
import sys
from unittest.mock import patch

import pytest
from pydantic import BaseModel

from tktl.cli.output import OutputFormat, print_error, print_output
from tktl.models.errors import (
    AuthError,
    ConflictError,
    NotFoundError,
    TktlError,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class SampleModel(BaseModel):
    name: str
    value: int


SINGLE_DICT = {"slug": "credit-scoring", "id": "abc-123", "name": "Credit Scoring"}

LIST_OF_DICTS = [
    {"slug": "credit-scoring", "id": "abc-123", "name": "Credit Scoring"},
    {"slug": "fraud-detect", "id": "def-456", "name": "Fraud Detection"},
]


# ---------------------------------------------------------------------------
# JSON output tests
# ---------------------------------------------------------------------------


class TestJsonOutput:
    def test_single_dict(self, capsys):
        print_output(SINGLE_DICT, format=OutputFormat.json)
        captured = capsys.readouterr()
        parsed = json.loads(captured.out)
        assert parsed == SINGLE_DICT
        assert captured.err == ""

    def test_list_of_dicts(self, capsys):
        print_output(LIST_OF_DICTS, format=OutputFormat.json)
        captured = capsys.readouterr()
        parsed = json.loads(captured.out)
        assert parsed == LIST_OF_DICTS
        assert len(parsed) == 2

    def test_pydantic_model(self, capsys):
        model = SampleModel(name="threshold", value=750)
        print_output(model, format=OutputFormat.json)
        captured = capsys.readouterr()
        parsed = json.loads(captured.out)
        assert parsed == {"name": "threshold", "value": 750}

    def test_pydantic_model_list(self, capsys):
        models = [
            SampleModel(name="a", value=1),
            SampleModel(name="b", value=2),
        ]
        print_output(models, format=OutputFormat.json)
        captured = capsys.readouterr()
        parsed = json.loads(captured.out)
        assert parsed == [{"name": "a", "value": 1}, {"name": "b", "value": 2}]

    def test_json_indent(self, capsys):
        """JSON output should be pretty-printed with indent=2."""
        print_output({"k": "v"}, format=OutputFormat.json)
        captured = capsys.readouterr()
        assert "  " in captured.out  # indent present
        assert captured.out.strip() == '{\n  "k": "v"\n}'


# ---------------------------------------------------------------------------
# Table output tests
# ---------------------------------------------------------------------------


class TestTableOutput:
    def test_single_dict_table(self, capsys):
        print_output(SINGLE_DICT, format=OutputFormat.table)
        captured = capsys.readouterr()
        # Key-value table should contain both keys and values
        assert "slug" in captured.out
        assert "credit-scoring" in captured.out
        assert "name" in captured.out
        assert "Credit Scoring" in captured.out

    def test_list_of_dicts_table(self, capsys):
        print_output(LIST_OF_DICTS, format=OutputFormat.table)
        captured = capsys.readouterr()
        # Column headers
        assert "slug" in captured.out
        assert "id" in captured.out
        assert "name" in captured.out
        # Row data
        assert "credit-scoring" in captured.out
        assert "fraud-detect" in captured.out
        assert "Fraud Detection" in captured.out

    def test_empty_list_table(self, capsys):
        """An empty list should not raise and should produce some output."""
        print_output([], format=OutputFormat.table)
        captured = capsys.readouterr()
        # Should not crash; output may be empty or a minimal message
        assert captured.err == ""


# ---------------------------------------------------------------------------
# Auto-detect tests
# ---------------------------------------------------------------------------


class TestAutoDetect:
    def test_auto_tty_uses_table(self, capsys):
        with patch.object(sys.stdout, "isatty", return_value=True):
            print_output(SINGLE_DICT, format=OutputFormat.auto)
        captured = capsys.readouterr()
        # Table mode: contains human-readable key labels, not raw JSON
        assert "slug" in captured.out
        assert "credit-scoring" in captured.out
        # Should NOT be valid JSON (it is a rich table)
        with pytest.raises(json.JSONDecodeError):
            json.loads(captured.out)

    def test_auto_non_tty_uses_json(self, capsys):
        with patch.object(sys.stdout, "isatty", return_value=False):
            print_output(SINGLE_DICT, format=OutputFormat.auto)
        captured = capsys.readouterr()
        parsed = json.loads(captured.out)
        assert parsed == SINGLE_DICT


# ---------------------------------------------------------------------------
# Quiet mode tests
# ---------------------------------------------------------------------------


class TestQuietMode:
    def test_quiet_suppresses_output(self, capsys):
        print_output(SINGLE_DICT, format=OutputFormat.json, quiet=True)
        captured = capsys.readouterr()
        assert captured.out == ""
        assert captured.err == ""

    def test_quiet_suppresses_table(self, capsys):
        print_output(LIST_OF_DICTS, format=OutputFormat.table, quiet=True)
        captured = capsys.readouterr()
        assert captured.out == ""

    def test_quiet_suppresses_auto(self, capsys):
        print_output(SINGLE_DICT, format=OutputFormat.auto, quiet=True)
        captured = capsys.readouterr()
        assert captured.out == ""


# ---------------------------------------------------------------------------
# Error formatting tests
# ---------------------------------------------------------------------------


class TestErrorFormatting:
    def test_error_json_format(self, capsys):
        err = NotFoundError("Flow 'xyz' not found.")
        print_error(err, format=OutputFormat.json)
        captured = capsys.readouterr()
        # Error goes to stderr
        assert captured.out == ""
        parsed = json.loads(captured.err)
        assert parsed["error"]["code"] == 4
        assert parsed["error"]["type"] == "NotFoundError"
        assert parsed["error"]["message"] == "Flow 'xyz' not found."

    def test_error_json_base_tktl_error(self, capsys):
        err = TktlError("Something went wrong.")
        print_error(err, format=OutputFormat.json)
        captured = capsys.readouterr()
        parsed = json.loads(captured.err)
        assert parsed["error"]["code"] == 1
        assert parsed["error"]["type"] == "TktlError"
        assert parsed["error"]["message"] == "Something went wrong."

    def test_error_json_auth_error(self, capsys):
        err = AuthError("Token expired.")
        print_error(err, format=OutputFormat.json)
        captured = capsys.readouterr()
        parsed = json.loads(captured.err)
        assert parsed["error"]["code"] == 3
        assert parsed["error"]["type"] == "AuthError"

    def test_error_json_conflict_error(self, capsys):
        err = ConflictError("ETag mismatch.")
        print_error(err, format=OutputFormat.json)
        captured = capsys.readouterr()
        parsed = json.loads(captured.err)
        assert parsed["error"]["code"] == 5
        assert parsed["error"]["type"] == "ConflictError"

    def test_error_table_format(self, capsys):
        err = NotFoundError("Flow 'xyz' not found.")
        print_error(err, format=OutputFormat.table)
        captured = capsys.readouterr()
        # Error goes to stderr, human-readable
        assert captured.out == ""
        assert "Flow 'xyz' not found." in captured.err
        assert "Error" in captured.err

    def test_error_table_base_error(self, capsys):
        err = TktlError("General failure.")
        print_error(err, format=OutputFormat.table)
        captured = capsys.readouterr()
        assert "General failure." in captured.err

    def test_error_auto_tty_uses_table_format(self, capsys):
        with patch.object(sys.stdout, "isatty", return_value=True):
            err = NotFoundError("Not found.")
            print_error(err, format=OutputFormat.auto)
        captured = capsys.readouterr()
        assert captured.out == ""
        # Should be human-readable, not JSON
        assert "Not found." in captured.err
        with pytest.raises(json.JSONDecodeError):
            json.loads(captured.err)

    def test_error_auto_non_tty_uses_json_format(self, capsys):
        with patch.object(sys.stdout, "isatty", return_value=False):
            err = NotFoundError("Not found.")
            print_error(err, format=OutputFormat.auto)
        captured = capsys.readouterr()
        parsed = json.loads(captured.err)
        assert parsed["error"]["code"] == 4
