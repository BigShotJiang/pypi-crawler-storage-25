"""Shared fixtures for CLI tests that need a fake API backend.

These fixtures set up:
- A temporary config directory with credentials
- A mock transport wired to the fake API
- Monkey-patching of _deps.build_deps to use the test environment
"""

from __future__ import annotations

import json
import uuid
from pathlib import Path
from typing import TYPE_CHECKING

import httpx as _httpx
import pytest

from tests.test_api.conftest import FAKE_BASE_URL, make_sync_transport
from tktl.api import execution as _execution
from tktl.api.client import TktlClient
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.cli import _deps
from tktl.cli._deps import Deps

if TYPE_CHECKING:
    from tests.fake_api.state import FakeState

WS_ID = "ws_00000000-0000-0000-0000-000000000001"


def _write_config(config_dir: Path, workspace_id: str = WS_ID) -> None:
    config_dir.mkdir(parents=True, exist_ok=True)
    (config_dir / "config.json").write_text(json.dumps({"workspace": workspace_id, "flow_api_url": FAKE_BASE_URL}))


def _write_credentials(config_dir: Path, api_key: str = "test-key") -> None:
    config_dir.mkdir(parents=True, exist_ok=True)
    (config_dir / "credentials.json").write_text(json.dumps({"api_key": api_key}))


@pytest.fixture
def cli_env(tmp_path: Path, fake_state: FakeState, monkeypatch: pytest.MonkeyPatch) -> Deps:
    """Set up a complete CLI test environment with mock API backend.

    Returns a Deps tuple and monkey-patches _deps.build_deps so that any
    CLI command invoked via CliRunner uses the test environment.
    """
    config_dir = tmp_path / "config"
    cache_dir = tmp_path / "cache"

    _write_config(config_dir)
    _write_credentials(config_dir)

    transport = make_sync_transport(fake_state)
    client = TktlClient(config_dir=config_dir, base_url=FAKE_BASE_URL, transport=transport)
    cache_manager = CacheManager(cache_dir)
    cache_index = CacheIndex(cache_dir)
    cache_index.load()

    deps = Deps(
        client=client,
        cache_manager=cache_manager,
        cache_index=cache_index,
        workspace_id=WS_ID,
        org_id=None,
        app_url=None,
    )

    # Monkey-patch the build_deps function on the _deps module.
    # Since CLI modules import `_deps` as a module and call `_deps.build_deps()`,
    # patching the module attribute works for all consumers.
    monkeypatch.setattr(_deps, "build_deps", lambda: deps)

    # Mock external httpx calls used by both the Decide API (execution) and
    # the Connect API (connections).  Both modules reference the same httpx
    # module, so we need a single post/get/patch mock that routes by URL.

    def _fake_post(url, **kwargs):
        body = kwargs.get("json", {})
        # Connections: create-resource
        if "/resources" in url:
            parts = url.split("/connections/")[1].split("/resources")[0]
            connection_id = parts
            conn = fake_state.connections.get(connection_id)
            if conn is None:
                return _httpx.Response(404, json={"detail": "Connection not found"})
            rc_id = str(uuid.uuid4())
            rc = {
                "id": rc_id,
                "name": body.get("name", ""),
                "resource": body.get("resource", "http"),
                "connection_config_id": connection_id,
                "configuration": body.get("configuration", {}),
            }
            conn["resource_configs"].append(rc)
            return _httpx.Response(201, json=rc)
        # Connections: create connection
        if "/connect/api/v1/connections" in url:
            conn_id = str(uuid.uuid4())
            conn = {
                "id": conn_id,
                "name": body.get("name", ""),
                "provider": body.get("provider", "custom"),
                "is_sandbox": body.get("is_sandbox", False),
                "configuration": body.get("configuration", {}),
                "resource_configs": [],
            }
            fake_state.connections[conn_id] = conn
            return _httpx.Response(201, json=conn)
        # Decide API (fallback for all other POST URLs)
        return _httpx.Response(
            200,
            json={
                "data": body.get("data", {}),
                "status": "success",
                "metadata": {
                    "environment": "sandbox",
                    "version": body.get("metadata", {}).get("version"),
                    "decision_id": "fake-decision-id",
                },
            },
        )

    def _fake_get(url, **kwargs):
        if "/connect/api/v1/connections" in url:
            return _httpx.Response(200, json=list(fake_state.connections.values()))
        return _httpx.Response(404, json={"detail": "Not found"})

    def _fake_patch(url, **kwargs):
        body = kwargs.get("json", [])
        if "/secrets" in url:
            parts = url.split("/connections/")[1].split("/secrets")[0]
            connection_id = parts
            conn = fake_state.connections.get(connection_id)
            if conn is None:
                return _httpx.Response(404, json={"detail": "Connection not found"})
            conn["secrets"] = body
            return _httpx.Response(200, json=body)
        return _httpx.Response(404, json={"detail": "Not found"})

    # Patch once on the shared httpx module
    monkeypatch.setattr(_execution.httpx, "post", _fake_post)
    monkeypatch.setattr(_execution.httpx, "get", _fake_get)
    monkeypatch.setattr(_execution.httpx, "patch", _fake_patch)

    # Clear the workspace base_url cache between tests
    _execution._workspace_base_url_cache.clear()

    return deps
