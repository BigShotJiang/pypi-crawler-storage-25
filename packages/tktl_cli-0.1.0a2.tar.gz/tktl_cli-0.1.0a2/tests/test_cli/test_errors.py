"""Tests for CLI error handling: verify TktlError subclasses produce correct exit codes.

Each error type should:
- Exit with the correct code
- Print structured error to stderr (which appears in result.output with CliRunner)
"""

from __future__ import annotations

import json

from typer.testing import CliRunner

from tktl.cli import _deps as deps_mod
from tktl.cli.main import app
from tktl.models.errors import (
    AuthError,
    ConflictError,
    NetworkError,
)

runner = CliRunner()


class TestNotFoundError:
    def test_not_found_exit_code(self, cli_env):
        """Describing a nonexistent flow should exit with code 4."""
        result = runner.invoke(app, ["flows", "describe", "nonexistent", "--output", "json"])
        assert result.exit_code == 4

    def test_not_found_error_output(self, cli_env):
        """Error should contain structured JSON with correct code and type."""
        result = runner.invoke(app, ["flows", "describe", "nonexistent", "--output", "json"])
        assert result.exit_code == 4
        # Error JSON is written to stderr but mixed into output by CliRunner
        err = json.loads(result.output)
        assert err["error"]["code"] == 4
        assert err["error"]["type"] == "NotFoundError"


class TestAuthError:
    def test_auth_error_exit_code(self, cli_env, monkeypatch):
        """AuthError should exit with code 3."""

        def raise_auth_error():
            raise AuthError("No API key found")

        monkeypatch.setattr("tktl.cli._deps.build_deps", raise_auth_error)
        result = runner.invoke(app, ["flows", "list", "--output", "json"])
        assert result.exit_code == 3

    def test_auth_error_output(self, cli_env, monkeypatch):
        """AuthError should produce structured JSON error."""

        def raise_auth_error():
            raise AuthError("No API key found")

        monkeypatch.setattr("tktl.cli._deps.build_deps", raise_auth_error)
        result = runner.invoke(app, ["flows", "list", "--output", "json"])
        err = json.loads(result.output)
        assert err["error"]["code"] == 3
        assert err["error"]["type"] == "AuthError"


class TestConflictError:
    def test_conflict_error_exit_code(self, cli_env, monkeypatch):
        """ConflictError should exit with code 5."""

        def patched_list_flows(*args, **kwargs):
            raise ConflictError("ETag mismatch")

        monkeypatch.setattr("tktl.cli.flows.list_flows", patched_list_flows)
        result = runner.invoke(app, ["flows", "list", "--output", "json"])
        assert result.exit_code == 5

    def test_conflict_error_output(self, cli_env, monkeypatch):
        def patched_list_flows(*args, **kwargs):
            raise ConflictError("ETag mismatch")

        monkeypatch.setattr("tktl.cli.flows.list_flows", patched_list_flows)
        result = runner.invoke(app, ["flows", "list", "--output", "json"])
        err = json.loads(result.output)
        assert err["error"]["code"] == 5
        assert err["error"]["type"] == "ConflictError"


class TestNetworkError:
    def test_network_error_exit_code(self, cli_env, monkeypatch):
        """NetworkError should exit with code 6."""

        def patched_list_flows(*args, **kwargs):
            raise NetworkError("Connection refused")

        monkeypatch.setattr("tktl.cli.flows.list_flows", patched_list_flows)
        result = runner.invoke(app, ["flows", "list", "--output", "json"])
        assert result.exit_code == 6

    def test_network_error_output(self, cli_env, monkeypatch):
        def patched_list_flows(*args, **kwargs):
            raise NetworkError("Connection refused")

        monkeypatch.setattr("tktl.cli.flows.list_flows", patched_list_flows)
        result = runner.invoke(app, ["flows", "list", "--output", "json"])
        err = json.loads(result.output)
        assert err["error"]["code"] == 6
        assert err["error"]["type"] == "NetworkError"
        assert "Connection refused" in err["error"]["message"]


class TestUsageError:
    def test_usage_error_exit_code(self, cli_env):
        """UsageError should exit with code 2."""
        # Trigger UsageError: update without any flags
        result = runner.invoke(app, ["update", "apply", "credit-scoring", "v2-draft", "--output", "json"])
        assert result.exit_code == 2

    def test_usage_error_output(self, cli_env):
        """UsageError should produce structured JSON error."""
        result = runner.invoke(app, ["update", "apply", "credit-scoring", "v2-draft", "--output", "json"])
        err = json.loads(result.output)
        assert err["error"]["code"] == 2
        assert err["error"]["type"] == "UsageError"

    def test_missing_workspace_exit_code(self, tmp_path, monkeypatch):
        """Missing workspace config should exit with UsageError (code 2)."""
        config_dir = tmp_path / "config"
        config_dir.mkdir()
        (config_dir / "config.json").write_text(json.dumps({"workspace": None}))
        (config_dir / "credentials.json").write_text(json.dumps({"api_key": "test-key"}))
        monkeypatch.setenv("TKTL_CONFIG_DIR", str(config_dir))

        # Undo the cli_env monkeypatch so build_deps runs the real code
        monkeypatch.setattr(
            deps_mod,
            "build_deps",
            deps_mod.build_deps.__wrapped__ if hasattr(deps_mod.build_deps, "__wrapped__") else deps_mod.build_deps,
        )

        result = runner.invoke(app, ["flows", "list", "--output", "json"])
        assert result.exit_code == 2
        err = json.loads(result.output)
        assert err["error"]["type"] == "UsageError"
        assert "workspace" in err["error"]["message"].lower()
