"""Tests for batch feedback enhancements."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

from typer.testing import CliRunner

from tktl.cli.main import app
from tktl.models.batch import BatchResult, BatchRunMeta
from tktl.ops.batch import parse_batch_file

runner = CliRunner()


def _fake_run_batch_with_decisions(tmp_path: Path, decisions: list[str | None] | None = None):
    """Create a fake run_batch that writes results with decision fields."""

    def fake_run_batch(client, workspace_id, flow_slug, file_path, **kwargs):
        runs_dir = kwargs.get("runs_dir") or tmp_path / "runs"
        run_id = "test-run-id"
        run_dir = runs_dir / flow_slug / run_id
        run_dir.mkdir(parents=True, exist_ok=True)

        rows = parse_batch_file(file_path)
        results_path = run_dir / "results.jsonl"

        for i, row in enumerate(rows):
            decision = decisions[i] if decisions and i < len(decisions) else None
            output_data: dict = {}
            if decision is not None:
                output_data = {"status": "success", "data": {"decision": decision}}
            else:
                output_data = {"status": "success", "data": {}}

            line = json.dumps(
                {
                    "row_index": i,
                    "input": row,
                    "output": output_data,
                    "error": None,
                    "duration_ms": 100,
                    "timestamp": "2026-03-20T10:00:00Z",
                }
            )
            with open(results_path, "a") as f:
                f.write(line + "\n")

        meta = BatchRunMeta(
            run_id=run_id,
            flow_slug=flow_slug,
            env=kwargs.get("env", "sandbox"),
            version=kwargs.get("version"),
            source_type="file",
            source=str(file_path),
            source_hash="sha256:fake",
            concurrency=kwargs.get("concurrency", 10),
            total_rows=len(rows),
            succeeded=len(rows),
            failed=0,
            started_at="2026-03-20T10:00:00Z",
            completed_at="2026-03-20T10:00:01Z",
            duration_ms=1000,
        )
        (run_dir / "meta.json").write_text(meta.model_dump_json(indent=2))

        return BatchResult(meta=meta, results_path=str(results_path))

    return fake_run_batch


class TestBatchFeedback:
    def test_batch_complete_message(self, cli_env, tmp_path: Path):
        """Batch output shows 'Batch complete' in non-JSON mode."""
        input_file = tmp_path / "input.json"
        input_file.write_text(json.dumps([{"income": 50000}, {"income": 75000}]))
        runs_dir = tmp_path / "runs"

        with patch(
            "tktl.cli.flows.run_batch",
            _fake_run_batch_with_decisions(tmp_path, ["approve", "approve"]),
        ):
            result = runner.invoke(
                app,
                [
                    "flows",
                    "batch",
                    "credit-scoring",
                    "--file",
                    str(input_file),
                    "--output",
                    "table",
                    "--runs-dir",
                    str(runs_dir),
                ],
            )

        assert result.exit_code == 0, result.output
        assert "Batch complete" in result.output
        assert "Succeeded" in result.output

    def test_batch_decision_breakdown(self, cli_env, tmp_path: Path):
        """Batch output shows decision breakdown."""
        input_file = tmp_path / "input.json"
        input_file.write_text(json.dumps([{"income": 50000}, {"income": 75000}, {"income": 30000}]))
        runs_dir = tmp_path / "runs"

        with patch(
            "tktl.cli.flows.run_batch",
            _fake_run_batch_with_decisions(tmp_path, ["approve", "approve", "reject"]),
        ):
            result = runner.invoke(
                app,
                [
                    "flows",
                    "batch",
                    "credit-scoring",
                    "--file",
                    str(input_file),
                    "--output",
                    "table",
                    "--runs-dir",
                    str(runs_dir),
                ],
            )

        assert result.exit_code == 0, result.output
        assert "Decisions" in result.output
        assert "approve" in result.output
        assert "reject" in result.output

    def test_batch_json_mode_no_enhanced_summary(self, cli_env, tmp_path: Path):
        """In JSON mode, no enhanced summary is printed."""
        input_file = tmp_path / "input.json"
        input_file.write_text(json.dumps([{"income": 50000}]))
        runs_dir = tmp_path / "runs"

        with patch(
            "tktl.cli.flows.run_batch",
            _fake_run_batch_with_decisions(tmp_path, ["approve"]),
        ):
            result = runner.invoke(
                app,
                [
                    "flows",
                    "batch",
                    "credit-scoring",
                    "--file",
                    str(input_file),
                    "--output",
                    "json",
                    "--runs-dir",
                    str(runs_dir),
                ],
            )

        assert result.exit_code == 0, result.output
        # JSON mode: output should be parseable JSON
        data = json.loads(result.output)
        assert "meta" in data
        assert "results_path" in data
        # No enhanced summary text
        assert "Batch complete" not in result.output

    def test_batch_quiet_mode_no_summary(self, cli_env, tmp_path: Path):
        """In quiet mode, no output is printed."""
        input_file = tmp_path / "input.json"
        input_file.write_text(json.dumps([{"income": 50000}]))
        runs_dir = tmp_path / "runs"

        with patch(
            "tktl.cli.flows.run_batch",
            _fake_run_batch_with_decisions(tmp_path, ["approve"]),
        ):
            result = runner.invoke(
                app,
                [
                    "flows",
                    "batch",
                    "credit-scoring",
                    "--file",
                    str(input_file),
                    "--output",
                    "table",
                    "--quiet",
                    "--runs-dir",
                    str(runs_dir),
                ],
            )

        assert result.exit_code == 0, result.output
        assert result.output.strip() == ""

    def test_batch_accuracy_comparison(self, cli_env, tmp_path: Path):
        """With --expected-field and --actual-field, accuracy is computed."""
        # Input has expected_decision field; output returns same or different
        input_file = tmp_path / "input.json"
        input_file.write_text(
            json.dumps(
                [
                    {"income": 50000, "expected_decision": "approve"},
                    {"income": 25000, "expected_decision": "reject"},
                ]
            )
        )
        runs_dir = tmp_path / "runs"

        with patch(
            "tktl.cli.flows.run_batch",
            _fake_run_batch_with_decisions(tmp_path, ["approve", "approve"]),
        ):
            result = runner.invoke(
                app,
                [
                    "flows",
                    "batch",
                    "credit-scoring",
                    "--file",
                    str(input_file),
                    "--output",
                    "table",
                    "--expected-field",
                    "expected_decision",
                    "--actual-field",
                    "decision",
                    "--runs-dir",
                    str(runs_dir),
                ],
            )

        assert result.exit_code == 0, result.output
        # Accuracy should be shown
        assert "Accuracy" in result.output
