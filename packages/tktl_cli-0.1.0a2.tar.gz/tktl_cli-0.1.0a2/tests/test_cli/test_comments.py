"""Tests for CLI comments commands: list, add, delete."""

from __future__ import annotations

import json

from typer.testing import CliRunner

from tktl.cli.main import app

runner = CliRunner()


class TestCommentsList:
    def test_list_empty(self, cli_env):
        result = runner.invoke(app, ["comments", "list", "credit-scoring", "v1", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data == []

    def test_list_after_add(self, cli_env):
        runner.invoke(app, ["comments", "add", "credit-scoring", "v1", "test comment", "--output", "json"])
        result = runner.invoke(app, ["comments", "list", "credit-scoring", "v1", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert len(data) == 1
        assert data[0]["content"] == "test comment"

    def test_list_filtered_by_node(self, cli_env):
        runner.invoke(
            app,
            ["comments", "add", "credit-scoring", "v1", "on node", "--node", "node_risk", "--output", "json"],
        )
        runner.invoke(app, ["comments", "add", "credit-scoring", "v1", "on version", "--output", "json"])
        result = runner.invoke(
            app,
            ["comments", "list", "credit-scoring", "v1", "--node", "node_risk", "--output", "json"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert len(data) == 1
        assert data[0]["content"] == "on node"


class TestCommentsAdd:
    def test_add_version_comment(self, cli_env):
        result = runner.invoke(app, ["comments", "add", "credit-scoring", "v1", "my comment", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["content"] == "my comment"
        assert "id" in data

    def test_add_node_comment(self, cli_env):
        result = runner.invoke(
            app,
            ["comments", "add", "credit-scoring", "v1", "node comment", "--node", "node_risk", "--output", "json"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["content"] == "node comment"
        assert data["resource_type"] == "node"
        assert data["resource_id"] == "node_risk"


class TestCommentsDelete:
    def test_delete_comment(self, cli_env):
        add_result = runner.invoke(app, ["comments", "add", "credit-scoring", "v1", "to delete", "--output", "json"])
        comment_id = json.loads(add_result.output)["id"]

        result = runner.invoke(app, ["comments", "delete", comment_id, "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["status"] == "deleted"

    def test_delete_nonexistent(self, cli_env):
        result = runner.invoke(app, ["comments", "delete", "nonexistent-id", "--output", "json"])
        assert result.exit_code != 0
