"""Tests for flows explain command."""

from __future__ import annotations

import json

from typer.testing import CliRunner

from tktl.cli.main import app

runner = CliRunner()


class TestFlowsExplain:
    def test_explain_json_output(self, cli_env):
        """Explain returns JSON with summary and nodes keys."""
        result = runner.invoke(
            app,
            ["flows", "explain", "credit-scoring", "v1", "--output", "json"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert "summary" in data
        assert isinstance(data["summary"], str)
        assert len(data["summary"]) > 0
        assert "nodes" in data
        assert isinstance(data["nodes"], list)
        assert len(data["nodes"]) > 0

    def test_explain_has_flow_and_version(self, cli_env):
        """Explain result contains flow slug and version name."""
        result = runner.invoke(
            app,
            ["flows", "explain", "credit-scoring", "v1", "--output", "json"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["flow"] == "credit-scoring"
        assert data["version"] == "v1"

    def test_explain_node_types_in_nodes(self, cli_env):
        """Explain result lists node descriptions with name, type, description."""
        result = runner.invoke(
            app,
            ["flows", "explain", "credit-scoring", "v1", "--output", "json"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        for node in data["nodes"]:
            assert "name" in node
            assert "type" in node
            assert "description" in node

    def test_explain_kyc_flow(self, cli_env):
        """Explain works for kyc-check flow."""
        result = runner.invoke(
            app,
            ["flows", "explain", "kyc-check", "v1", "--output", "json"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["flow"] == "kyc-check"
        assert len(data["nodes"]) >= 2

    def test_explain_not_found(self, cli_env):
        """Explain returns error for non-existent flow."""
        result = runner.invoke(
            app,
            ["flows", "explain", "nonexistent-flow", "v1", "--output", "json"],
        )
        assert result.exit_code != 0
