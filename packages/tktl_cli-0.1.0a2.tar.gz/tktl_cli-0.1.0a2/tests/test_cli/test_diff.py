"""CLI tests for ``tktl flows diff``."""

from __future__ import annotations

import json

from typer.testing import CliRunner

from tktl.cli.main import app

runner = CliRunner()


class TestFlowsDiff:
    def test_json_output(self, cli_env) -> None:  # noqa: ANN001
        """credit-scoring v1 vs v2-draft: Risk Engine + Pricing Rule removed, ML Scorer added."""
        result = runner.invoke(app, ["flows", "diff", "credit-scoring", "v1..v2-draft", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["flow_slug"] == "credit-scoring"
        assert data["v1_name"] == "v1"
        assert data["v2_name"] == "v2-draft"
        # v1 has threshold param, v2-draft has none
        assert any(p["name"] == "threshold" for p in data["parameter_changes"])
        # Structural: Risk Engine removed, ML Scorer added
        names = {s["node_name"] for s in data["structural_changes"]}
        assert "Risk Engine" in names
        assert "ML Scorer" in names

    def test_invalid_range_no_dots(self, cli_env) -> None:  # noqa: ANN001
        result = runner.invoke(app, ["flows", "diff", "credit-scoring", "v1"])
        assert result.exit_code == 2

    def test_invalid_range_empty_side(self, cli_env) -> None:  # noqa: ANN001
        result = runner.invoke(app, ["flows", "diff", "credit-scoring", "v1.."])
        assert result.exit_code == 2

    def test_nonexistent_version(self, cli_env) -> None:  # noqa: ANN001
        result = runner.invoke(app, ["flows", "diff", "credit-scoring", "v1..v999"])
        assert result.exit_code == 4

    def test_same_version_no_changes(self, cli_env) -> None:  # noqa: ANN001
        result = runner.invoke(app, ["flows", "diff", "credit-scoring", "v1..v1", "--output", "json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["parameter_changes"] == []
        assert data["structural_changes"] == []
        assert data["logic_changes"] == []
        assert data["integration_changes"] == []
