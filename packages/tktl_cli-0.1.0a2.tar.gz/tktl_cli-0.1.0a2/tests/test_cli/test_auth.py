from unittest.mock import patch

from typer.testing import CliRunner

from tktl.cli.main import app

runner = CliRunner()

MOCK_LOGIN_RESULT = {"user_id": "user-123", "email": "test@example.com"}


def test_auth_login(tmp_path, monkeypatch):
    monkeypatch.setenv("TKTL_CONFIG_DIR", str(tmp_path))
    with patch("tktl.cli.auth._validate_api_key", return_value=MOCK_LOGIN_RESULT):
        result = runner.invoke(app, ["auth", "login"], input="sk-test-key-123\n")
    assert result.exit_code == 0
    assert "test@example.com" in result.output


def test_auth_login_invalid_key(tmp_path, monkeypatch):
    monkeypatch.setenv("TKTL_CONFIG_DIR", str(tmp_path))
    with patch("tktl.cli.auth._validate_api_key", return_value=None):
        result = runner.invoke(app, ["auth", "login"], input="bad-key\n")
    assert result.exit_code == 3


def test_auth_status_no_key(tmp_path, monkeypatch):
    monkeypatch.setenv("TKTL_CONFIG_DIR", str(tmp_path))
    result = runner.invoke(app, ["auth", "status"])
    assert result.exit_code == 0
    assert "No API key" in result.output or "not" in result.output.lower()


def test_auth_login_then_status(tmp_path, monkeypatch):
    monkeypatch.setenv("TKTL_CONFIG_DIR", str(tmp_path))
    with patch("tktl.cli.auth._validate_api_key", return_value=MOCK_LOGIN_RESULT):
        runner.invoke(app, ["auth", "login"], input="sk-test-key\n")
    result = runner.invoke(app, ["auth", "status"])
    assert result.exit_code == 0
    assert "configured" in result.output.lower() or "sk-test" in result.output


def test_auth_login_stores_user_id(tmp_path, monkeypatch):
    monkeypatch.setenv("TKTL_CONFIG_DIR", str(tmp_path))
    with patch("tktl.cli.auth._validate_api_key", return_value=MOCK_LOGIN_RESULT):
        runner.invoke(app, ["auth", "login"], input="sk-test-key\n")
    result = runner.invoke(app, ["auth", "status"])
    assert "user-123" in result.output


def test_auth_logout(tmp_path, monkeypatch):
    monkeypatch.setenv("TKTL_CONFIG_DIR", str(tmp_path))
    with patch("tktl.cli.auth._validate_api_key", return_value=MOCK_LOGIN_RESULT):
        runner.invoke(app, ["auth", "login"], input="sk-test-key\n")
    result = runner.invoke(app, ["auth", "logout"])
    assert result.exit_code == 0

    result = runner.invoke(app, ["auth", "status"])
    assert "No API key" in result.output or "not" in result.output.lower()
