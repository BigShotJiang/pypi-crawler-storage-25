"""Tests for versions diff command."""

from __future__ import annotations

import json

from typer.testing import CliRunner

from tktl.cli.main import app

runner = CliRunner()


class TestVersionsDiff:
    def test_diff_same_version_no_changes(self, cli_env):
        """Diff of a version against itself produces no changes."""
        result = runner.invoke(
            app,
            ["versions", "diff", "credit-scoring", "v1", "v1", "--output", "json"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["flow_slug"] == "credit-scoring"
        assert data["v1_name"] == "v1"
        assert data["v2_name"] == "v1"
        assert data["parameter_changes"] == []
        assert data["schema_changes"] == []
        assert data["structural_changes"] == []
        assert data["logic_changes"] == []
        assert data["integration_changes"] == []

    def test_diff_between_v1_and_v2draft(self, cli_env):
        """Diff between v1 and v2-draft surfaces at least one change."""
        result = runner.invoke(
            app,
            ["versions", "diff", "credit-scoring", "v1", "v2-draft", "--output", "json"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["flow_slug"] == "credit-scoring"
        assert data["v1_name"] == "v1"
        assert data["v2_name"] == "v2-draft"
        total_changes = (
            len(data["parameter_changes"])
            + len(data["schema_changes"])
            + len(data["structural_changes"])
            + len(data["logic_changes"])
            + len(data["integration_changes"])
        )
        assert total_changes > 0

    def test_diff_summary_text_output(self, cli_env):
        """Diff summary text contains flow slug, version names, and an arrow."""
        result = runner.invoke(
            app,
            ["versions", "diff", "credit-scoring", "v1", "v1", "--output", "table"],
        )
        assert result.exit_code == 0, result.output
        assert "credit-scoring" in result.output
        assert "v1" in result.output
        assert "→" in result.output or "->" in result.output or "no changes" in result.output.lower()

    def test_diff_not_found_flow(self, cli_env):
        """Diff returns error for non-existent flow."""
        result = runner.invoke(
            app,
            ["versions", "diff", "nonexistent-flow", "v1", "v1", "--output", "json"],
        )
        assert result.exit_code != 0

    def test_diff_json_structure(self, cli_env):
        """JSON output has the expected FlowDiff structure."""
        result = runner.invoke(
            app,
            ["versions", "diff", "credit-scoring", "v1", "v2-draft", "--output", "json"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert "flow_slug" in data
        assert "v1_name" in data
        assert "v2_name" in data
        assert "parameter_changes" in data
        assert "schema_changes" in data
        assert "structural_changes" in data
        assert "logic_changes" in data
        assert "integration_changes" in data
