"""Tests for CLI version lifecycle commands: publish, archive, create, duplicate."""

from __future__ import annotations

import json

from typer.testing import CliRunner

from tktl.cli.main import app

runner = CliRunner()


class TestPublish:
    def test_publish_draft(self, cli_env):
        result = runner.invoke(app, ["versions", "publish", "credit-scoring", "v2-draft", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["status"] == "PUBLISHED"

    def test_publish_quiet(self, cli_env):
        result = runner.invoke(
            app, ["versions", "publish", "credit-scoring", "v2-draft", "--output", "json", "--quiet"]
        )
        assert result.exit_code == 0
        assert result.output.strip() == ""


class TestArchive:
    def test_archive_version(self, cli_env):
        result = runner.invoke(app, ["versions", "archive", "credit-scoring", "v1", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["status"] == "ARCHIVED"


class TestCreate:
    def test_create_version(self, cli_env):
        result = runner.invoke(app, ["versions", "create", "credit-scoring", "v3-new", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["name"] == "v3-new"
        assert data["status"] == "DRAFT"


class TestDuplicate:
    def test_duplicate_version(self, cli_env):
        result = runner.invoke(
            app,
            ["versions", "duplicate", "credit-scoring", "v1", "--name", "v1-copy", "--output", "json"],
        )
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["name"] == "v1-copy"
