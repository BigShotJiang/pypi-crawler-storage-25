"""Tests for CLI flows commands: list and describe."""

from __future__ import annotations

import json

from typer.testing import CliRunner

from tktl.cli.main import app

runner = CliRunner()


class TestFlowsList:
    def test_list_json(self, cli_env):
        result = runner.invoke(app, ["flows", "list", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert isinstance(data, list)
        assert len(data) == 3
        slugs = [f["slug"] for f in data]
        assert "credit-scoring" in slugs
        assert "kyc-check" in slugs

    def test_list_table(self, cli_env):
        result = runner.invoke(app, ["flows", "list", "--output", "table"])
        assert result.exit_code == 0, result.output
        assert "credit-scoring" in result.output
        assert "kyc-check" in result.output

    def test_list_quiet(self, cli_env):
        result = runner.invoke(app, ["flows", "list", "--output", "json", "--quiet"])
        assert result.exit_code == 0
        assert result.output.strip() == ""


class TestFlowsDescribe:
    def test_describe_json(self, cli_env):
        result = runner.invoke(app, ["flows", "describe", "credit-scoring", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["slug"] == "credit-scoring"
        assert "id" in data
        assert "name" in data

    def test_describe_summary(self, cli_env):
        result = runner.invoke(app, ["flows", "describe", "credit-scoring", "--summary", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["slug"] == "credit-scoring"
        # Summary should only have slug, id, name
        assert set(data.keys()) == {"slug", "id", "name"}

    def test_describe_table(self, cli_env):
        result = runner.invoke(app, ["flows", "describe", "credit-scoring", "--output", "table"])
        assert result.exit_code == 0, result.output
        assert "credit-scoring" in result.output

    def test_describe_not_found(self, cli_env):
        result = runner.invoke(app, ["flows", "describe", "nonexistent", "--output", "json"])
        assert result.exit_code == 4  # NotFoundError
