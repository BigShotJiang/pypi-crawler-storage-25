"""Tests for CLI changes command."""

from __future__ import annotations

import json

from typer.testing import CliRunner

from tktl.cli.main import app

runner = CliRunner()


class TestChanges:
    def test_changes_json(self, cli_env):
        # First describe the flow to populate cache index with version IDs
        runner.invoke(app, ["flows", "describe", "credit-scoring", "--output", "json"])

        result = runner.invoke(app, ["versions", "changes", "credit-scoring", "v1", "--output", "json"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert isinstance(data, list)

    def test_changes_with_limit(self, cli_env):
        # First describe the flow to populate cache index
        runner.invoke(app, ["flows", "describe", "credit-scoring", "--output", "json"])

        result = runner.invoke(app, ["versions", "changes", "credit-scoring", "v1", "--limit", "5", "--output", "json"])
        assert result.exit_code == 0, result.output

    def test_changes_with_after(self, cli_env):
        # First describe the flow to populate cache index
        runner.invoke(app, ["flows", "describe", "credit-scoring", "--output", "json"])

        result = runner.invoke(
            app,
            ["versions", "changes", "credit-scoring", "v1", "--after", "etag-123", "--output", "json"],
        )
        assert result.exit_code == 0, result.output
