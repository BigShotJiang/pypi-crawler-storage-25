"""Tests for the datasets CLI commands."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING

import pytest
from typer.testing import CliRunner

import tktl.api.datasets as ds_mod
from tests.test_api.conftest import FAKE_BASE_URL
from tests.test_api.test_datasets_crud import _make_httpx_bridge
from tktl.cli.main import app
from tktl.ops import datasets as _ds_mod

if TYPE_CHECKING:
    from tests.fake_api.state import FakeState
    from tktl.cli._deps import Deps

runner = CliRunner()


@pytest.fixture(autouse=True)
def _patch_ds_httpx(cli_env: "Deps", fake_state: "FakeState", monkeypatch: pytest.MonkeyPatch) -> None:
    """Route dataset API httpx calls through the ASGI fake app.

    Depends on cli_env so this runs AFTER the CLI env monkeypatches.
    """
    monkeypatch.setattr(_ds_mod, "_get_ws_auth", lambda client, ws_id: ("fake-key", FAKE_BASE_URL))

    get, post, patch, put, request = _make_httpx_bridge(fake_state)
    monkeypatch.setattr(ds_mod.httpx, "get", get)
    monkeypatch.setattr(ds_mod.httpx, "post", post)
    monkeypatch.setattr(ds_mod.httpx, "patch", patch)
    monkeypatch.setattr(ds_mod.httpx, "put", put)
    monkeypatch.setattr(ds_mod.httpx, "request", request)


class TestDatasetsList:
    def test_list_json(self, cli_env: Deps) -> None:
        result = runner.invoke(app, ["datasets", "list", "credit-scoring", "-o", "json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert isinstance(data, list)

    def test_list_unknown_flow(self, cli_env: Deps) -> None:
        result = runner.invoke(app, ["datasets", "list", "nonexistent"])
        assert result.exit_code != 0


class TestDatasetsCreate:
    def test_create_from_schema(self, cli_env: Deps) -> None:
        result = runner.invoke(
            app, ["datasets", "create", "credit-scoring", "--name", "Test", "--from-schema", "v1", "-o", "json"]
        )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["name"] == "Test"
        col_names = {c["name"] for c in data["input_columns"]}
        assert "income" in col_names

    def test_create_with_columns(self, cli_env: Deps) -> None:
        cols = json.dumps([{"name": "age", "desired_type": "integer"}])
        result = runner.invoke(
            app, ["datasets", "create", "credit-scoring", "--name", "Manual", "--columns", cols, "-o", "json"]
        )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert len(data["input_columns"]) == 1

    def test_create_requires_source(self, cli_env: Deps) -> None:
        result = runner.invoke(app, ["datasets", "create", "credit-scoring", "--name", "No source"])
        assert result.exit_code != 0

    def test_create_rejects_both(self, cli_env: Deps) -> None:
        cols = json.dumps([{"name": "age", "desired_type": "integer"}])
        result = runner.invoke(
            app, ["datasets", "create", "credit-scoring", "--name", "Both", "--from-schema", "v1", "--columns", cols]
        )
        assert result.exit_code != 0


class TestDatasetsDescribe:
    def test_describe_json(self, cli_env: Deps) -> None:
        # First create a dataset
        result = runner.invoke(
            app, ["datasets", "create", "credit-scoring", "--name", "Desc Test", "--from-schema", "v1", "-o", "json"]
        )
        ds_id = json.loads(result.output)["id"]

        result = runner.invoke(app, ["datasets", "describe", ds_id, "-o", "json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["name"] == "Desc Test"


class TestDatasetsRows:
    def test_rows(self, cli_env: Deps) -> None:
        # Create and get rows
        result = runner.invoke(
            app, ["datasets", "create", "credit-scoring", "--name", "Rows Test", "--from-schema", "v1", "-o", "json"]
        )
        ds_id = json.loads(result.output)["id"]

        result = runner.invoke(app, ["datasets", "rows", ds_id, "-o", "json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert isinstance(data, list)


class TestDatasetsAddRows:
    def test_add_blank(self, cli_env: Deps) -> None:
        result = runner.invoke(
            app, ["datasets", "create", "credit-scoring", "--name", "Blank", "--from-schema", "v1", "-o", "json"]
        )
        ds_id = json.loads(result.output)["id"]

        result = runner.invoke(app, ["datasets", "add-rows", ds_id, "--blank", "3", "-o", "json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert len(data) == 3

    def test_add_with_data(self, cli_env: Deps) -> None:
        result = runner.invoke(
            app, ["datasets", "create", "credit-scoring", "--name", "Data", "--from-schema", "v1", "-o", "json"]
        )
        ds_id = json.loads(result.output)["id"]

        rows = json.dumps([{"income": 100000}, {"income": 200000}])
        result = runner.invoke(app, ["datasets", "add-rows", ds_id, "--data", rows, "-o", "json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert len(data) == 2

    def test_rejects_no_source(self, cli_env: Deps) -> None:
        result = runner.invoke(app, ["datasets", "add-rows", "ds-fake"])
        assert result.exit_code != 0


class TestDatasetsColumnOps:
    def test_add_column(self, cli_env: Deps) -> None:
        result = runner.invoke(
            app, ["datasets", "create", "credit-scoring", "--name", "Cols", "--from-schema", "v1", "-o", "json"]
        )
        ds_id = json.loads(result.output)["id"]

        result = runner.invoke(
            app,
            [
                "datasets",
                "add-column",
                ds_id,
                "--group",
                "input_columns",
                "--name",
                "extra",
                "--type",
                "string",
                "-o",
                "json",
            ],
        )
        assert result.exit_code == 0


class TestDatasetsSyncSchema:
    def test_sync(self, cli_env: Deps) -> None:
        # Create a dataset with manual columns (will have drift vs schema)
        cols = json.dumps([{"name": "old_field", "desired_type": "string"}])
        result = runner.invoke(
            app, ["datasets", "create", "credit-scoring", "--name", "Sync Test", "--columns", cols, "-o", "json"]
        )
        ds_id = json.loads(result.output)["id"]

        result = runner.invoke(
            app, ["datasets", "sync-schema", "credit-scoring", ds_id, "--version", "v1", "-o", "json"]
        )
        assert result.exit_code == 0
        data = json.loads(result.output)
        missing_names = {c["name"] for c in data["missing_columns"]}
        assert "income" in missing_names


class TestDatasetsDelete:
    def test_delete(self, cli_env: Deps) -> None:
        result = runner.invoke(
            app, ["datasets", "create", "credit-scoring", "--name", "Delete Me", "--from-schema", "v1", "-o", "json"]
        )
        ds_id = json.loads(result.output)["id"]

        result = runner.invoke(app, ["datasets", "delete", ds_id])
        assert result.exit_code == 0
        assert "Deleted" in result.output


class TestDatasetsDownload:
    def test_download_stdout(self, cli_env: Deps) -> None:
        result = runner.invoke(
            app, ["datasets", "create", "credit-scoring", "--name", "DL", "--from-schema", "v1", "-o", "json"]
        )
        ds_id = json.loads(result.output)["id"]

        result = runner.invoke(app, ["datasets", "download", ds_id, "--format", "json"])
        assert result.exit_code == 0
