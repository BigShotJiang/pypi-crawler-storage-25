import tktl  # noqa: F401
from typer.testing import CliRunner

from tktl.cli.main import app

runner = CliRunner()


def test_help_exits_zero():
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "Taktile decision flows" in result.output


def test_import_tktl():
    assert tktl is not None
