from tktl.models.flow import FlowDetail, FlowSummary


def test_flow_summary_from_dict():
    data = {"slug": "credit-scoring", "id": "fl_abc", "name": "Credit Scoring"}
    s = FlowSummary.model_validate(data)
    assert s.slug == "credit-scoring"
    assert s.id == "fl_abc"
    assert s.name == "Credit Scoring"


def test_flow_summary_ignores_extra_fields():
    data = {"slug": "cs", "id": "fl_1", "name": "CS", "unknown_field": True}
    s = FlowSummary.model_validate(data)
    assert s.slug == "cs"


def test_flow_detail_from_dict():
    data = {
        "slug": "credit-scoring",
        "id": "fl_abc",
        "name": "Credit Scoring",
        "workspace_id": "ws_123",
        "created_at": "2026-01-01T00:00:00Z",
        "updated_at": "2026-03-17T10:00:00Z",
        "default_version": "fv_xyz",
        "default_sandbox_version": "fv_abc",
    }
    d = FlowDetail.model_validate(data)
    assert d.slug == "credit-scoring"
    assert d.workspace_id == "ws_123"
    assert d.default_version == "fv_xyz"


def test_flow_detail_optional_fields():
    data = {
        "slug": "cs",
        "id": "fl_1",
        "name": "CS",
        "workspace_id": "ws_1",
    }
    d = FlowDetail.model_validate(data)
    assert d.default_version is None
    assert d.default_sandbox_version is None
    assert d.created_at is None
    assert d.updated_at is None
