from tktl.models.batch import BatchResult, BatchRowResult, BatchRunMeta, BatchRunSummary


def test_batch_row_result_success():
    data = {
        "row_index": 0,
        "input": {"income": 50000, "age": 30},
        "output": {"decision": "approve", "score": 0.85},
        "error": None,
        "duration_ms": 142,
        "timestamp": "2026-03-20T10:15:30.123Z",
    }
    r = BatchRowResult.model_validate(data)
    assert r.row_index == 0
    assert r.input == {"income": 50000, "age": 30}
    assert r.output == {"decision": "approve", "score": 0.85}
    assert r.error is None
    assert r.duration_ms == 142


def test_batch_row_result_error():
    data = {
        "row_index": 3,
        "input": {"income": 25000},
        "output": None,
        "error": "Connection timeout",
        "duration_ms": 5002,
        "timestamp": "2026-03-20T10:15:31.456Z",
    }
    r = BatchRowResult.model_validate(data)
    assert r.output is None
    assert r.error == "Connection timeout"


def test_batch_row_result_roundtrip():
    r = BatchRowResult(
        row_index=1,
        input={"x": 1},
        output={"y": 2},
        error=None,
        duration_ms=100,
        timestamp="2026-03-20T00:00:00Z",
    )
    data = r.model_dump()
    r2 = BatchRowResult.model_validate(data)
    assert r == r2


def test_batch_run_meta_file_source():
    data = {
        "run_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
        "flow_slug": "credit-scoring",
        "env": "sandbox",
        "version": "v1",
        "source_type": "file",
        "source": "input.csv",
        "source_hash": "sha256:abcdef1234567890",
        "dataset_etag": None,
        "concurrency": 10,
        "total_rows": 50,
        "succeeded": 48,
        "failed": 2,
        "started_at": "2026-03-20T10:15:30Z",
        "completed_at": "2026-03-20T10:15:35Z",
        "duration_ms": 5234,
    }
    m = BatchRunMeta.model_validate(data)
    assert m.source_type == "file"
    assert m.source == "input.csv"
    assert m.source_hash == "sha256:abcdef1234567890"
    assert m.dataset_etag is None


def test_batch_run_meta_dataset_source():
    data = {
        "run_id": "abc",
        "flow_slug": "cs",
        "env": "sandbox",
        "version": None,
        "source_type": "dataset",
        "source": "dataset:9a8b7c6d-e5f6-7890-abcd-ef1234567890",
        "source_hash": "sha256:000",
        "dataset_etag": "etag-123",
        "concurrency": 10,
        "total_rows": 50,
        "succeeded": 50,
        "failed": 0,
        "started_at": "2026-03-20T10:00:00Z",
        "completed_at": "2026-03-20T10:00:05Z",
        "duration_ms": 5000,
    }
    m = BatchRunMeta.model_validate(data)
    assert m.source_type == "dataset"
    assert m.dataset_etag == "etag-123"


def test_batch_run_meta_optional_fields():
    m = BatchRunMeta(
        run_id="abc",
        flow_slug="cs",
        env="sandbox",
        version=None,
        source_type="file",
        source="input.json",
        source_hash="sha256:000",
        concurrency=5,
        total_rows=1,
        succeeded=0,
        failed=0,
        started_at="2026-03-20T10:00:00Z",
        completed_at=None,
        duration_ms=None,
    )
    assert m.version is None
    assert m.completed_at is None
    assert m.duration_ms is None
    assert m.dataset_etag is None


def test_batch_run_summary():
    data = {
        "run_id": "abc",
        "source_type": "file",
        "source": "input.csv",
        "source_hash": "sha256:abcdef",
        "total_rows": 10,
        "succeeded": 9,
        "failed": 1,
        "started_at": "2026-03-20T10:00:00Z",
        "duration_ms": 2000,
    }
    s = BatchRunSummary.model_validate(data)
    assert s.run_id == "abc"
    assert s.source_type == "file"
    assert s.total_rows == 10


def test_batch_run_summary_optional_duration():
    s = BatchRunSummary(
        run_id="abc",
        source_type="file",
        source="input.csv",
        source_hash="sha256:abcdef",
        total_rows=10,
        succeeded=0,
        failed=0,
        started_at="2026-03-20T10:00:00Z",
        duration_ms=None,
    )
    assert s.duration_ms is None


def test_batch_result():
    meta = BatchRunMeta(
        run_id="abc",
        flow_slug="cs",
        env="sandbox",
        version=None,
        source_type="file",
        source="input.csv",
        source_hash="sha256:000",
        concurrency=10,
        total_rows=5,
        succeeded=5,
        failed=0,
        started_at="2026-03-20T10:00:00Z",
        completed_at="2026-03-20T10:00:01Z",
        duration_ms=1000,
    )
    result = BatchResult(meta=meta, results_path="/tmp/results.jsonl")
    assert result.meta.run_id == "abc"
    assert result.results_path == "/tmp/results.jsonl"
