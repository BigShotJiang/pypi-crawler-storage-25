from tktl.models.node import NodeDetail, NodeSummary


def test_node_summary_from_dict():
    data = {"id": "a1b2c3d4-0000-0000-0000-000000000001", "name": "Risk Engine", "type": "decision_table"}
    s = NodeSummary.model_validate(data)
    assert s.id == "a1b2c3d4-0000-0000-0000-000000000001"
    assert s.name == "Risk Engine"
    assert s.type == "decision_table"


def test_node_detail_from_dict():
    data = {
        "id": "a1b2c3d4-0000-0000-0000-000000000001",
        "name": "Risk Engine",
        "type": "decision_table",
        "meta": {"rows": [], "columns": [], "score_threshold": 750},
    }
    d = NodeDetail.model_validate(data)
    assert d.id == "a1b2c3d4-0000-0000-0000-000000000001"
    assert d.meta is not None
    assert d.meta["score_threshold"] == 750


def test_node_detail_meta_optional():
    data = {"id": "n1", "name": "Input", "type": "input"}
    d = NodeDetail.model_validate(data)
    assert d.meta is None
