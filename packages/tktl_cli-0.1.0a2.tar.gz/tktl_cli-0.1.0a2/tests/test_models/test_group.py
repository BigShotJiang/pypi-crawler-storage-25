"""Tests for group models."""

from __future__ import annotations

from tktl.models.group import GroupDetail, GroupSummary


class TestGroupSummary:
    def test_parse_full(self) -> None:
        raw = {"id": "g1", "name": "Scoring", "node_ids": ["n1", "n2"]}
        g = GroupSummary.model_validate(raw)
        assert g.id == "g1"
        assert g.name == "Scoring"
        assert g.node_ids == ["n1", "n2"]

    def test_defaults(self) -> None:
        g = GroupSummary.model_validate({"id": "g2"})
        assert g.name == ""
        assert g.node_ids == []

    def test_extra_fields_ignored(self) -> None:
        raw = {"id": "g3", "name": "X", "node_ids": [], "unknown_field": True}
        g = GroupSummary.model_validate(raw)
        assert g.id == "g3"


class TestGroupDetail:
    def test_parse_with_meta(self) -> None:
        raw = {"id": "g1", "name": "Gate", "node_ids": ["n1"], "meta": {"color": "red"}}
        g = GroupDetail.model_validate(raw)
        assert g.meta == {"color": "red"}

    def test_meta_defaults_to_none(self) -> None:
        g = GroupDetail.model_validate({"id": "g2"})
        assert g.meta is None

    def test_extra_fields_ignored(self) -> None:
        raw = {"id": "g3", "name": "X", "node_ids": [], "meta": {}, "extra": 42}
        g = GroupDetail.model_validate(raw)
        assert g.id == "g3"
