import pytest

from tktl.models.errors import (
    AuthError,
    ConflictError,
    NetworkError,
    NotFoundError,
    TktlError,
    UsageError,
)


def test_tktl_error_is_base():
    err = TktlError("something went wrong")
    assert isinstance(err, Exception)
    assert str(err) == "something went wrong"
    assert err.code == 1


def test_usage_error():
    err = UsageError("bad args")
    assert isinstance(err, TktlError)
    assert err.code == 2


def test_auth_error():
    err = AuthError("bad key")
    assert isinstance(err, TktlError)
    assert err.code == 3


def test_not_found_error():
    err = NotFoundError("no such flow")
    assert isinstance(err, TktlError)
    assert err.code == 4


def test_conflict_error():
    err = ConflictError("etag mismatch")
    assert isinstance(err, TktlError)
    assert err.code == 5


def test_network_error():
    err = NetworkError("connection refused")
    assert isinstance(err, TktlError)
    assert err.code == 6


def test_all_codes_unique():
    errors = [TktlError, UsageError, AuthError, NotFoundError, ConflictError, NetworkError]
    codes = [cls("x").code for cls in errors]
    assert len(codes) == len(set(codes))


def test_catch_base_catches_all():
    for cls in [UsageError, AuthError, NotFoundError, ConflictError, NetworkError]:
        with pytest.raises(TktlError):
            raise cls("test")
