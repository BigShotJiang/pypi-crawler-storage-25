"""Tests for dataset data models."""

from __future__ import annotations

from tktl.models.dataset import (
    ColumnGroup,
    ColumnType,
    Dataset,
    DatasetColumn,
    DatasetFileUpload,
    DatasetPurpose,
    DatasetRow,
    DatasetSource,
    DatasetSummary,
    SchemaDiff,
    TypeMismatch,
)


class TestColumnGroup:
    def test_values(self) -> None:
        assert ColumnGroup.input_columns == "input_columns"
        assert ColumnGroup.output_columns == "output_columns"
        assert ColumnGroup.mock_columns == "mock_columns"
        assert ColumnGroup.meta_columns == "meta_columns"
        assert ColumnGroup.outcome_columns == "outcome_columns"


class TestColumnType:
    def test_all_types(self) -> None:
        expected = {
            "string",
            "boolean",
            "number",
            "integer",
            "object",
            "array",
            "datetime",
            "date",
            "any",
            "enum",
            "files",
        }
        assert {t.value for t in ColumnType} == expected


class TestDatasetColumn:
    def test_basic(self) -> None:
        col = DatasetColumn(name="income", desired_type=ColumnType.number)
        assert col.name == "income"
        assert col.desired_type == ColumnType.number
        assert col.use_subflow_mocks is False

    def test_with_subflow_mocks(self) -> None:
        col = DatasetColumn(name="ext_data", desired_type=ColumnType.object, use_subflow_mocks=True)
        assert col.use_subflow_mocks is True


class TestDatasetRow:
    def test_minimal(self) -> None:
        row = DatasetRow(id="r1", input_data={"income": 50000})
        assert row.id == "r1"
        assert row.input_data == {"income": 50000}
        assert row.output_data is None
        assert row.mock_data is None

    def test_full(self) -> None:
        row = DatasetRow(
            id="r1",
            input_data={"income": 50000},
            output_data={"decision": "approve"},
            mock_data={"api_score": 700},
            meta_data={"tag": "test"},
            outcome_data={"actual": "approve"},
        )
        assert row.output_data == {"decision": "approve"}
        assert row.mock_data == {"api_score": 700}

    def test_ignores_extra_fields(self) -> None:
        row = DatasetRow(id="r1", input_data={}, unknown_field="ignored")  # type: ignore[unknown-argument]
        assert row.id == "r1"


class TestDataset:
    def test_minimal(self) -> None:
        ds = Dataset(
            id="ds1",
            name="Test",
            flow_id="f1",
            etag="e1",
            created_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            source=DatasetSource.scratch,
            input_columns=[DatasetColumn(name="income", desired_type=ColumnType.number)],
            output_columns=[],
            mock_columns=[],
        )
        assert ds.id == "ds1"
        assert ds.purpose == DatasetPurpose.test_run
        assert ds.meta_columns is None
        assert ds.outcome_columns is None
        assert ds.row_count is None

    def test_full(self) -> None:
        ds = Dataset(
            id="ds1",
            name="Test",
            flow_id="f1",
            etag="e1",
            created_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            source=DatasetSource.file,
            purpose=DatasetPurpose.job_source,
            input_columns=[DatasetColumn(name="income", desired_type=ColumnType.number)],
            output_columns=[DatasetColumn(name="decision", desired_type=ColumnType.string)],
            mock_columns=[],
            meta_columns=[DatasetColumn(name="tag", desired_type=ColumnType.string)],
            outcome_columns=[DatasetColumn(name="actual", desired_type=ColumnType.string)],
            row_count=100,
        )
        assert ds.source == DatasetSource.file
        assert ds.row_count == 100

    def test_ignores_extra_fields(self) -> None:
        ds = Dataset(
            id="ds1",
            name="Test",
            flow_id="f1",
            etag="e1",
            created_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            source=DatasetSource.scratch,
            input_columns=[],
            output_columns=[],
            mock_columns=[],
            created_by_id="user1",  # type: ignore[unknown-argument]  # extra field from API
        )
        assert ds.id == "ds1"


class TestDatasetSummary:
    def test_fields(self) -> None:
        s = DatasetSummary(
            id="ds1",
            name="Test",
            flow_id="f1",
            source=DatasetSource.scratch,
            purpose=DatasetPurpose.test_run,
            row_count=10,
            created_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        assert s.name == "Test"
        assert s.row_count == 10


class TestSchemaDiff:
    def test_empty_diff(self) -> None:
        diff = SchemaDiff(missing_columns=[], extra_columns=[], type_mismatches=[])
        assert diff.missing_columns == []

    def test_with_mismatches(self) -> None:
        diff = SchemaDiff(
            missing_columns=[DatasetColumn(name="new_field", desired_type=ColumnType.string)],
            extra_columns=[DatasetColumn(name="old_field", desired_type=ColumnType.number)],
            type_mismatches=[
                TypeMismatch(name="income", dataset_type=ColumnType.string, schema_type=ColumnType.number)
            ],
        )
        assert len(diff.missing_columns) == 1
        assert diff.type_mismatches[0].name == "income"


class TestDatasetFileUpload:
    def test_fields(self) -> None:
        upload = DatasetFileUpload(
            id="u1",
            flow_id="f1",
            file_name="data.csv",
            status="PENDING",
            s3_presigned_url="https://s3.example.com/upload",
            s3_presigned_fields={"key": "value"},
            created_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        assert upload.status == "PENDING"
        assert upload.dataset_id is None

    def test_completed(self) -> None:
        upload = DatasetFileUpload(
            id="u1",
            flow_id="f1",
            file_name="data.csv",
            status="COMPLETED",
            s3_presigned_url="https://s3.example.com/upload",
            s3_presigned_fields={},
            dataset_id="ds1",
            created_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        assert upload.dataset_id == "ds1"
