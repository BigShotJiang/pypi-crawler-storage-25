from tktl.models.version import VersionDetail, VersionSummary


def test_version_summary_from_dict():
    data = {"name": "v1", "id": "fv_xyz", "status": "DRAFT"}
    s = VersionSummary.model_validate(data)
    assert s.name == "v1"
    assert s.id == "fv_xyz"
    assert s.status == "DRAFT"


def test_version_detail_from_dict():
    data = {
        "name": "v1",
        "id": "fv_xyz",
        "status": "DRAFT",
        "etag": "abc123",
        "created_at": "2026-01-01T00:00:00Z",
        "updated_at": "2026-03-17T10:00:00Z",
        "parameters": [{"name": "threshold", "value": 0.8}],
        "input_schema": {"type": "object"},
        "output_schema": {"type": "object"},
    }
    d = VersionDetail.model_validate(data)
    assert d.name == "v1"
    assert d.etag == "abc123"
    assert d.parameters == [{"name": "threshold", "value": 0.8}]
    assert d.input_schema == {"type": "object"}


def test_version_detail_optional_fields():
    data = {"name": "v1", "id": "fv_1", "status": "DRAFT"}
    d = VersionDetail.model_validate(data)
    assert d.etag is None
    assert d.parameters is None
    assert d.input_schema is None
    assert d.output_schema is None
    assert d.graph is None


def test_version_detail_with_graph():
    graph = {
        "nodes": {"n1": {"id": "n1", "name": "Input", "type": "input"}},
        "edges": {"e1": {"id": "e1", "start_node_id": "n1", "end_node_id": "n2"}},
    }
    data = {
        "name": "v1",
        "id": "fv_1",
        "status": "DRAFT",
        "graph": graph,
    }
    d = VersionDetail.model_validate(data)
    assert d.graph is not None
    assert "n1" in d.graph["nodes"]
    assert "e1" in d.graph["edges"]
