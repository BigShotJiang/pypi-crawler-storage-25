"""E2E smoke test: version lifecycle.

create version -> describe it -> publish -> describe (check PUBLISHED) -> archive
-> describe (check ARCHIVED).
"""

from __future__ import annotations

import json

from typer.testing import CliRunner

from tktl.cli.main import app

runner = CliRunner()


class TestVersionLifecycle:
    def test_create_publish_archive(self, cli_env):
        """Full lifecycle: create -> describe -> publish -> describe -> archive -> describe."""
        # Step 1: create a new version
        result = runner.invoke(app, ["versions", "create", "credit-scoring", "v3-lifecycle", "--output", "json"])
        assert result.exit_code == 0, result.output
        created = json.loads(result.output)
        assert created["name"] == "v3-lifecycle"
        assert created["status"] == "DRAFT"

        # Step 2: describe the newly created version
        result = runner.invoke(app, ["versions", "describe", "credit-scoring", "v3-lifecycle", "--output", "json"])
        assert result.exit_code == 0, result.output
        described = json.loads(result.output)
        assert described["name"] == "v3-lifecycle"
        assert described["status"] == "DRAFT"

        # Step 3: publish the version
        result = runner.invoke(app, ["versions", "publish", "credit-scoring", "v3-lifecycle", "--output", "json"])
        assert result.exit_code == 0, result.output
        published = json.loads(result.output)
        assert published["status"] == "PUBLISHED"

        # Step 4: describe again and confirm PUBLISHED
        result = runner.invoke(app, ["versions", "describe", "credit-scoring", "v3-lifecycle", "--output", "json"])
        assert result.exit_code == 0, result.output
        described_pub = json.loads(result.output)
        assert described_pub["status"] == "PUBLISHED"

        # Step 5: archive the version
        result = runner.invoke(app, ["versions", "archive", "credit-scoring", "v3-lifecycle", "--output", "json"])
        assert result.exit_code == 0, result.output
        archived = json.loads(result.output)
        assert archived["status"] == "ARCHIVED"

        # Step 6: describe again and confirm ARCHIVED
        result = runner.invoke(app, ["versions", "describe", "credit-scoring", "v3-lifecycle", "--output", "json"])
        assert result.exit_code == 0, result.output
        described_arch = json.loads(result.output)
        assert described_arch["status"] == "ARCHIVED"

    def test_duplicate_and_modify(self, cli_env):
        """Duplicate a version, update the duplicate, then publish it."""
        # Duplicate v1
        result = runner.invoke(
            app,
            ["versions", "duplicate", "credit-scoring", "v1", "--name", "v1-dup", "--output", "json"],
        )
        assert result.exit_code == 0, result.output
        duplicated = json.loads(result.output)
        assert duplicated["name"] == "v1-dup"

        # Update a node in the duplicate
        config = json.dumps({"score_threshold": 900})
        result = runner.invoke(
            app,
            [
                "update",
                "apply",
                "credit-scoring",
                "v1-dup",
                "--node",
                "node_risk",
                "--node-config",
                config,
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output

        # Verify the update on the duplicate
        result = runner.invoke(app, ["nodes", "describe", "credit-scoring", "v1-dup", "node_risk", "--output", "json"])
        assert result.exit_code == 0, result.output
        node = json.loads(result.output)
        assert node["meta"]["score_threshold"] == 900

        # Original v1 should be unchanged
        result = runner.invoke(app, ["nodes", "describe", "credit-scoring", "v1", "node_risk", "--output", "json"])
        assert result.exit_code == 0, result.output
        orig_node = json.loads(result.output)
        assert orig_node["meta"]["score_threshold"] == 500

    def test_create_appears_in_version_list(self, cli_env):
        """A newly created version should appear when listing versions."""
        # Create a version
        result = runner.invoke(app, ["versions", "create", "credit-scoring", "v-new-list-test", "--output", "json"])
        assert result.exit_code == 0, result.output

        # List versions and verify it appears
        result = runner.invoke(app, ["versions", "list", "credit-scoring", "--output", "json"])
        assert result.exit_code == 0, result.output
        versions = json.loads(result.output)
        names = {v["name"] for v in versions}
        assert "v-new-list-test" in names
