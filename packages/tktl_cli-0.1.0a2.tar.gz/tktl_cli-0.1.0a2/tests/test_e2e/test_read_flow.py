"""E2E smoke test: full read workflow.

list flows -> describe flow -> list versions -> describe version
-> list nodes -> get node.

All via CliRunner. Verify data flows correctly between commands.
"""

from __future__ import annotations

import json

from typer.testing import CliRunner

from tktl.cli.main import app

runner = CliRunner()


class TestReadFlowWorkflow:
    def test_full_read_pipeline(self, cli_env):
        """Walk the entire read path and verify data consistency across commands."""
        # Step 1: list flows
        result = runner.invoke(app, ["flows", "list", "--output", "json"])
        assert result.exit_code == 0, result.output
        flows = json.loads(result.output)
        assert isinstance(flows, list)
        assert len(flows) == 3

        slugs = {f["slug"] for f in flows}
        assert "credit-scoring" in slugs
        assert "kyc-check" in slugs
        assert "data-enrichment" in slugs

        # Step 2: describe a specific flow
        result = runner.invoke(app, ["flows", "describe", "credit-scoring", "--output", "json"])
        assert result.exit_code == 0, result.output
        flow = json.loads(result.output)
        assert flow["slug"] == "credit-scoring"
        flow_id = flow["id"]
        assert flow_id  # non-empty

        # Step 3: list versions for that flow
        result = runner.invoke(app, ["versions", "list", "credit-scoring", "--output", "json"])
        assert result.exit_code == 0, result.output
        versions = json.loads(result.output)
        assert isinstance(versions, list)
        assert len(versions) == 2

        version_names = {v["name"] for v in versions}
        assert "v1" in version_names
        assert "v2-draft" in version_names

        # Step 4: describe a specific version
        result = runner.invoke(app, ["versions", "describe", "credit-scoring", "v1", "--output", "json"])
        assert result.exit_code == 0, result.output
        version = json.loads(result.output)
        assert version["name"] == "v1"
        assert version["status"] == "PUBLISHED"

        # Step 5: list nodes in that version
        result = runner.invoke(app, ["nodes", "list", "credit-scoring", "v1", "--output", "json"])
        assert result.exit_code == 0, result.output
        nodes = json.loads(result.output)
        assert isinstance(nodes, list)
        node_ids = {n["id"] for n in nodes}
        assert "node_input" in node_ids
        assert "node_risk" in node_ids
        assert "node_pricing" in node_ids
        assert "node_output" in node_ids

        # Step 6: describe a specific node
        result = runner.invoke(app, ["nodes", "describe", "credit-scoring", "v1", "node_risk", "--output", "json"])
        assert result.exit_code == 0, result.output
        node = json.loads(result.output)
        assert node["id"] == "node_risk"
        assert node["name"] == "Risk Engine"
        assert node["type"] == "decision_table"
        assert node["meta"]["score_threshold"] == 500

    def test_second_flow_read(self, cli_env):
        """Verify the second flow (kyc-check) is also readable end-to-end."""
        # list -> describe flow -> list versions -> list nodes -> get node
        result = runner.invoke(app, ["flows", "describe", "kyc-check", "--output", "json"])
        assert result.exit_code == 0, result.output
        flow = json.loads(result.output)
        assert flow["slug"] == "kyc-check"

        result = runner.invoke(app, ["versions", "list", "kyc-check", "--output", "json"])
        assert result.exit_code == 0, result.output
        versions = json.loads(result.output)
        assert len(versions) == 1
        assert versions[0]["name"] == "v1"

        result = runner.invoke(app, ["nodes", "list", "kyc-check", "v1", "--output", "json"])
        assert result.exit_code == 0, result.output
        nodes = json.loads(result.output)
        node_ids = {n["id"] for n in nodes}
        assert "node_input" in node_ids
        assert "node_verify" in node_ids
        assert "node_output" in node_ids

        result = runner.invoke(app, ["nodes", "describe", "kyc-check", "v1", "node_verify", "--output", "json"])
        assert result.exit_code == 0, result.output
        node = json.loads(result.output)
        assert node["id"] == "node_verify"
        assert node["name"] == "ID Verification"
        assert node["type"] == "data_integration"
