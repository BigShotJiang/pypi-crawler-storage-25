"""E2E smoke test: ETag retry.

Use the fake state to force a 412 (modify the version etag between describe
and update), verify the update still succeeds via automatic retry.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING

from typer.testing import CliRunner

from tktl.cli.main import app

if TYPE_CHECKING:
    from tests.fake_api.state import FakeState

runner = CliRunner()


class TestEtagRetryViaCli:
    def test_update_succeeds_after_etag_bump(self, cli_env, fake_state: FakeState):
        """When the etag is bumped once between fetches, the retry succeeds."""
        # First, describe the version to populate the cache and discover version_id
        result = runner.invoke(app, ["versions", "describe", "credit-scoring", "v2-draft", "--output", "json"])
        assert result.exit_code == 0, result.output
        version = json.loads(result.output)
        version_id = version["id"]

        # Bump the etag in the fake state to simulate a concurrent edit.
        # The ops layer re-fetches at the start of each retry, so we
        # only bump once. After the re-fetch the etag will be current.
        fake_state.versions[version_id]["etag"] = fake_state.next_etag()

        # Now perform an update. The first PATCH will 412, but the retry
        # will re-fetch the fresh etag and succeed.
        config = json.dumps({"model_id": "m3"})
        result = runner.invoke(
            app,
            [
                "update",
                "apply",
                "credit-scoring",
                "v2-draft",
                "--node",
                "node_ml",
                "--node-config",
                config,
                "--output",
                "json",
            ],
        )
        # The update should succeed because the ops layer re-fetches on each attempt
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["id"] == "node_ml"

    def test_three_consecutive_412s_fails(self, cli_env, fake_state: FakeState):
        """When the etag keeps changing, eventually the CLI gives up with a conflict error."""
        # Describe to populate cache
        result = runner.invoke(app, ["versions", "describe", "credit-scoring", "v2-draft", "--output", "json"])
        assert result.exit_code == 0, result.output
        version = json.loads(result.output)
        version_id = version["id"]

        # Monkey-patch get_version to bump the etag after every GET,
        # so every PATCH attempt will see a stale etag.
        original_get_version = fake_state.get_version

        def bumping_get(vid: str):
            result = original_get_version(vid)
            if result is not None and vid == version_id:
                fake_state.versions[vid]["etag"] = fake_state.next_etag()
            return result

        fake_state.get_version = bumping_get  # type: ignore[method-assign]

        # The update should fail after 3 retries
        config = json.dumps({"model_id": "m99"})
        result = runner.invoke(
            app,
            [
                "update",
                "apply",
                "credit-scoring",
                "v2-draft",
                "--node",
                "node_ml",
                "--node-config",
                config,
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 5  # ConflictError code
