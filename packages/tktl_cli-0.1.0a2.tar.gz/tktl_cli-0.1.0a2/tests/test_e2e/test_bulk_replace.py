"""E2E smoke test: bulk replace version via --file.

Replace an entire version with a JSON file and verify full replacement.
"""

from __future__ import annotations

import json
from pathlib import Path

from typer.testing import CliRunner

from tktl.cli.main import app

runner = CliRunner()


class TestBulkReplace:
    def test_replace_version_via_file(self, cli_env, tmp_path: Path):
        """Replace a version entirely via update apply --file and verify."""
        # Step 1: describe the current version to see its state
        result = runner.invoke(
            app, ["versions", "describe", "credit-scoring", "v2-draft", "--full", "--output", "json"]
        )
        assert result.exit_code == 0, result.output
        original = json.loads(result.output)
        assert original["name"] == "v2-draft"

        # Step 2: build a replacement version body
        replacement = {
            "name": "v2-draft",
            "status": "DRAFT",
            "parameters": [{"name": "new_param", "value": 42}],
            "input_schema": {
                "type": "object",
                "properties": {"x": {"type": "number"}},
            },
            "output_schema": {
                "type": "object",
                "properties": {"y": {"type": "string"}},
            },
            "graph": {
                "nodes": {
                    "node_a": {
                        "id": "node_a",
                        "name": "Node A",
                        "type": "input",
                    },
                    "node_b": {
                        "id": "node_b",
                        "name": "Node B",
                        "type": "output",
                        "meta": {"key": "value"},
                    },
                },
                "edges": {},
                "node_groups": {},
            },
        }

        version_file = tmp_path / "replacement.json"
        version_file.write_text(json.dumps(replacement))

        # Step 3: do the replacement
        result = runner.invoke(
            app,
            [
                "update",
                "apply",
                "credit-scoring",
                "v2-draft",
                "--file",
                str(version_file),
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output
        replaced = json.loads(result.output)
        assert replaced["name"] == "v2-draft"
        assert replaced["parameters"] == [{"name": "new_param", "value": 42}]

        # Step 4: describe the version again and verify full replacement
        result = runner.invoke(
            app, ["versions", "describe", "credit-scoring", "v2-draft", "--full", "--output", "json"]
        )
        assert result.exit_code == 0, result.output
        after = json.loads(result.output)
        assert after["parameters"] == [{"name": "new_param", "value": 42}]
        assert after["input_schema"]["properties"]["x"]["type"] == "number"
        assert after["output_schema"]["properties"]["y"]["type"] == "string"

        # Step 5: list nodes and verify the replacement nodes
        result = runner.invoke(app, ["nodes", "list", "credit-scoring", "v2-draft", "--output", "json"])
        assert result.exit_code == 0, result.output
        nodes = json.loads(result.output)
        node_ids = {n["id"] for n in nodes}
        # The old nodes (node_input, node_ml, node_output) should be gone
        # The new nodes (node_a, node_b) should be present
        assert "node_a" in node_ids
        assert "node_b" in node_ids

        # Verify the new node details
        result = runner.invoke(app, ["nodes", "describe", "credit-scoring", "v2-draft", "node_b", "--output", "json"])
        assert result.exit_code == 0, result.output
        node_b = json.loads(result.output)
        assert node_b["name"] == "Node B"
        assert node_b["type"] == "output"
        assert node_b["meta"]["key"] == "value"
