"""E2E smoke test: node update workflow.

list nodes -> get node -> update node config -> get node again -> verify change persisted.
"""

from __future__ import annotations

import json

from typer.testing import CliRunner

from tktl.cli.main import app

runner = CliRunner()


class TestUpdateNodeWorkflow:
    def test_update_node_and_verify(self, cli_env):
        """Update a node's meta config and verify the change is persisted."""
        # Step 1: list nodes to find our target
        result = runner.invoke(app, ["nodes", "list", "credit-scoring", "v2-draft", "--output", "json"])
        assert result.exit_code == 0, result.output
        nodes = json.loads(result.output)
        node_ids = {n["id"] for n in nodes}
        assert "node_ml" in node_ids

        # Step 2: get the node before update
        result = runner.invoke(app, ["nodes", "describe", "credit-scoring", "v2-draft", "node_ml", "--output", "json"])
        assert result.exit_code == 0, result.output
        node_before = json.loads(result.output)
        assert node_before["id"] == "node_ml"
        assert node_before["meta"]["model_id"] == "m1"

        # Step 3: update the node config
        new_config = json.dumps({"model_id": "m2", "confidence_threshold": 0.95})
        result = runner.invoke(
            app,
            [
                "update",
                "apply",
                "credit-scoring",
                "v2-draft",
                "--node",
                "node_ml",
                "--node-config",
                new_config,
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output
        updated = json.loads(result.output)
        assert updated["id"] == "node_ml"

        # Step 4: get the node again and verify the change persisted
        result = runner.invoke(app, ["nodes", "describe", "credit-scoring", "v2-draft", "node_ml", "--output", "json"])
        assert result.exit_code == 0, result.output
        node_after = json.loads(result.output)
        assert node_after["id"] == "node_ml"
        assert node_after["meta"]["model_id"] == "m2"
        assert node_after["meta"]["confidence_threshold"] == 0.95

    def test_update_preserves_other_nodes(self, cli_env):
        """Updating one node should not affect other nodes in the same version."""
        # Get nodes before update (verify they exist)
        result = runner.invoke(app, ["nodes", "list", "credit-scoring", "v1", "--output", "json"])
        assert result.exit_code == 0, result.output
        assert len(json.loads(result.output)) >= 3

        # Update the risk node
        config = json.dumps({"score_threshold": 750})
        result = runner.invoke(
            app,
            [
                "update",
                "apply",
                "credit-scoring",
                "v1",
                "--node",
                "node_risk",
                "--node-config",
                config,
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output

        # Verify the pricing node is unchanged
        result = runner.invoke(app, ["nodes", "describe", "credit-scoring", "v1", "node_pricing", "--output", "json"])
        assert result.exit_code == 0, result.output
        pricing_node = json.loads(result.output)
        assert pricing_node["meta"]["base_rate"] == 0.05

        # Verify the risk node was actually updated
        result = runner.invoke(app, ["nodes", "describe", "credit-scoring", "v1", "node_risk", "--output", "json"])
        assert result.exit_code == 0, result.output
        risk_node = json.loads(result.output)
        assert risk_node["meta"]["score_threshold"] == 750

    def test_update_deep_merges_meta(self, cli_env):
        """Update should deep-merge, not replace, the node meta."""
        # The risk node starts with meta: {"score_threshold": 500, "rows": []}
        # Update only score_threshold, rows should be preserved
        config = json.dumps({"score_threshold": 600})
        result = runner.invoke(
            app,
            [
                "update",
                "apply",
                "credit-scoring",
                "v1",
                "--node",
                "node_risk",
                "--node-config",
                config,
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output

        # Verify the change AND that the original keys are preserved
        result = runner.invoke(app, ["nodes", "describe", "credit-scoring", "v1", "node_risk", "--output", "json"])
        assert result.exit_code == 0, result.output
        node = json.loads(result.output)
        assert node["meta"]["score_threshold"] == 600
        assert node["meta"]["rows"] == []  # preserved from original
