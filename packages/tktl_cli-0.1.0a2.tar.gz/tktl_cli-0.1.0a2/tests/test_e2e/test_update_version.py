"""E2E smoke test: version-level updates.

update params -> update schema-in -> describe version -> verify changes.
"""

from __future__ import annotations

import json

from typer.testing import CliRunner

from tktl.cli.main import app

runner = CliRunner()


class TestUpdateVersionParams:
    def test_update_params_and_verify(self, cli_env):
        """Update version parameters and verify via describe."""
        # Step 1: describe the version to see current params
        result = runner.invoke(app, ["versions", "describe", "credit-scoring", "v1", "--full", "--output", "json"])
        assert result.exit_code == 0, result.output
        version_before = json.loads(result.output)
        assert version_before["parameters"] == [{"name": "threshold", "value": 0.8}]

        # Step 2: update parameters
        new_params = json.dumps([{"name": "threshold", "value": 0.95}, {"name": "max_retries", "value": 3}])
        result = runner.invoke(
            app,
            [
                "update",
                "apply",
                "credit-scoring",
                "v1",
                "--params",
                new_params,
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output

        # Step 3: describe again and verify the update
        result = runner.invoke(app, ["versions", "describe", "credit-scoring", "v1", "--full", "--output", "json"])
        assert result.exit_code == 0, result.output
        version_after = json.loads(result.output)
        assert version_after["parameters"] == [
            {"name": "threshold", "value": 0.95},
            {"name": "max_retries", "value": 3},
        ]


class TestUpdateVersionSchemaIn:
    def test_update_schema_in_and_verify(self, cli_env):
        """Update input schema and verify via describe."""
        # Step 1: describe to see current input_schema
        result = runner.invoke(app, ["versions", "describe", "credit-scoring", "v1", "--full", "--output", "json"])
        assert result.exit_code == 0, result.output
        version_before = json.loads(result.output)
        assert version_before["input_schema"] == {
            "type": "object",
            "properties": {"income": {"type": "number"}},
        }

        # Step 2: update input schema
        new_schema = json.dumps(
            {
                "type": "object",
                "properties": {
                    "income": {"type": "number"},
                    "age": {"type": "integer"},
                    "employment_status": {"type": "string"},
                },
                "required": ["income"],
            }
        )
        result = runner.invoke(
            app,
            [
                "update",
                "apply",
                "credit-scoring",
                "v1",
                "--schema-in",
                new_schema,
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output

        # Step 3: describe again and verify
        result = runner.invoke(app, ["versions", "describe", "credit-scoring", "v1", "--full", "--output", "json"])
        assert result.exit_code == 0, result.output
        version_after = json.loads(result.output)
        assert "age" in version_after["input_schema"]["properties"]
        assert "employment_status" in version_after["input_schema"]["properties"]
        assert version_after["input_schema"]["required"] == ["income"]


class TestUpdateVersionSchemaOut:
    def test_update_schema_out_and_verify(self, cli_env):
        """Update output schema and verify via describe."""
        new_schema = json.dumps(
            {
                "type": "object",
                "properties": {
                    "decision": {"type": "string"},
                    "score": {"type": "number"},
                },
            }
        )
        result = runner.invoke(
            app,
            [
                "update",
                "apply",
                "credit-scoring",
                "v1",
                "--schema-out",
                new_schema,
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output

        # Verify
        result = runner.invoke(app, ["versions", "describe", "credit-scoring", "v1", "--full", "--output", "json"])
        assert result.exit_code == 0, result.output
        version = json.loads(result.output)
        assert "score" in version["output_schema"]["properties"]
