"""E2E tests using a real flow version (monitoring.json) as seed data.

This exercises the CLI against realistic flow data with 40 nodes,
19 parameters, complex transform code, split branches, and connection nodes.
The v1 format (array-based nodes) is converted to v2 (dict-keyed) on load.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import httpx as _httpx
import pytest
from typer.testing import CliRunner

from tests.fake_api.state import FakeState
from tests.test_api.conftest import FAKE_BASE_URL, make_sync_transport
from tktl.api import execution as _execution
from tktl.api.client import TktlClient
from tktl.api.execution import _workspace_base_url_cache
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.cli import _deps
from tktl.cli._deps import Deps
from tktl.cli.main import app

runner = CliRunner()

DATA_DIR = Path(__file__).resolve().parent.parent / "fake_api" / "data"


def _load_monitoring_v2() -> dict[str, Any]:
    """Load monitoring.json and convert from v1 (array nodes) to v2 (dict-keyed nodes)."""
    with open(DATA_DIR / "monitoring.json") as f:
        raw = json.load(f)

    # Convert graph from v1 (arrays) to v2 (dicts keyed by id)
    graph = raw.get("graph", {})
    nodes_list = graph.get("nodes", [])
    edges_list = graph.get("edges", [])
    node_groups_list = graph.get("node_groups", [])

    nodes_dict = {n["id"]: n for n in nodes_list}
    edges_dict = {e["id"]: e for e in edges_list}
    node_groups_dict = {ng["id"]: ng for ng in node_groups_list} if node_groups_list else {}

    raw["graph"] = {
        "nodes": nodes_dict,
        "edges": edges_dict,
        "node_groups": node_groups_dict,
    }

    # Ensure v2-compatible fields
    raw.setdefault("locks", [])
    return raw


@pytest.fixture
def monitoring_env(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    """Set up a CLI env with the real monitoring flow loaded into the fake API."""
    version_data = _load_monitoring_v2()
    version_id = version_data["id"]
    flow_id = "fl_monitoring_001"
    ws_id = "ws_00000000-0000-0000-0000-000000000001"

    state = FakeState(workspace_id=ws_id)
    state.versions[version_id] = {**version_data, "_flow_id": flow_id}
    state.etag_counter = int(version_data.get("etag", "0"), 16) if version_data.get("etag") else 0
    state.flows[flow_id] = {
        "id": flow_id,
        "slug": "monitoring",
        "name": "Monitoring",
        "workspace_id": ws_id,
        "created_at": "2026-01-01T00:00:00Z",
        "updated_at": "2026-03-17T00:00:00Z",
        "default_version": version_id,
        "_version_ids": [version_id],
    }

    config_dir = tmp_path / "config"
    config_dir.mkdir()
    (config_dir / "config.json").write_text(json.dumps({"workspace": ws_id, "flow_api_url": FAKE_BASE_URL}))
    (config_dir / "credentials.json").write_text(json.dumps({"api_key": "test-key"}))

    transport = make_sync_transport(state)
    client = TktlClient(config_dir=config_dir, base_url=FAKE_BASE_URL, transport=transport)
    cache_dir = tmp_path / "cache"
    cache_manager = CacheManager(cache_dir)
    cache_index = CacheIndex(cache_dir)
    cache_index.load()

    deps = Deps(
        client=client,
        cache_manager=cache_manager,
        cache_index=cache_index,
        workspace_id=ws_id,
        org_id=None,
        app_url=None,
    )
    monkeypatch.setattr(_deps, "build_deps", lambda: deps)

    # Mock decide endpoint
    def _fake_decide(url: str, **kwargs: Any) -> _httpx.Response:
        body = kwargs.get("json", {})
        return _httpx.Response(200, json={"data": body.get("data", {}), "status": "success", "metadata": {}})

    monkeypatch.setattr(_execution.httpx, "post", _fake_decide)
    _workspace_base_url_cache.clear()

    return {"state": state, "version_id": version_id, "flow_id": flow_id, "ws_id": ws_id}


class TestListAndInspect:
    """Browse the monitoring flow — list, describe, inspect nodes."""

    def test_list_flows(self, monitoring_env: dict[str, Any]):
        result = runner.invoke(app, ["flows", "list", "--output", "json"])
        assert result.exit_code == 0, result.output
        flows = json.loads(result.output)
        assert any(f["slug"] == "monitoring" for f in flows)

    def test_describe_flow(self, monitoring_env: dict[str, Any]):
        result = runner.invoke(app, ["flows", "describe", "monitoring", "--output", "json"])
        assert result.exit_code == 0, result.output
        flow = json.loads(result.output)
        assert flow["slug"] == "monitoring"

    def test_list_versions(self, monitoring_env: dict[str, Any]):
        # Seed the index first
        runner.invoke(app, ["flows", "describe", "monitoring", "--output", "json"])
        result = runner.invoke(app, ["versions", "list", "monitoring", "--output", "json"])
        assert result.exit_code == 0, result.output
        versions = json.loads(result.output)
        assert len(versions) == 1
        assert versions[0]["name"] == "8.41"

    def test_describe_version(self, monitoring_env: dict[str, Any]):
        runner.invoke(app, ["flows", "describe", "monitoring", "--output", "json"])
        result = runner.invoke(app, ["versions", "describe", "monitoring", "8.41", "--output", "json"])
        assert result.exit_code == 0, result.output
        version = json.loads(result.output)
        assert version["name"] == "8.41"
        assert version["status"] == "PUBLISHED"

    def test_list_all_40_nodes(self, monitoring_env: dict[str, Any]):
        runner.invoke(app, ["flows", "describe", "monitoring", "--output", "json"])
        result = runner.invoke(app, ["nodes", "list", "monitoring", "8.41", "--output", "json"])
        assert result.exit_code == 0, result.output
        nodes = json.loads(result.output)
        assert len(nodes) == 40
        # Verify all expected types are present
        types = {n["type"] for n in nodes}
        assert "transform" in types
        assert "split_2" in types
        assert "input" in types
        assert "output" in types

    def test_describe_transform_node(self, monitoring_env: dict[str, Any]):
        """Inspect a transform node — verify we get the meta with source code."""
        runner.invoke(app, ["flows", "describe", "monitoring", "--output", "json"])
        # Find a transform node
        list_result = runner.invoke(app, ["nodes", "list", "monitoring", "8.41", "--output", "json"])
        nodes = json.loads(list_result.output)
        transform_node = next(n for n in nodes if n["type"] == "transform")

        result = runner.invoke(
            app, ["nodes", "describe", "monitoring", "8.41", transform_node["id"], "--output", "json"]
        )
        assert result.exit_code == 0, result.output
        node = json.loads(result.output)
        assert node["type"] == "transform"
        assert node["meta"] is not None
        assert "src" in node["meta"]

    def test_describe_split_node(self, monitoring_env: dict[str, Any]):
        """Inspect a split node — verify we get branches in meta."""
        runner.invoke(app, ["flows", "describe", "monitoring", "--output", "json"])
        list_result = runner.invoke(app, ["nodes", "list", "monitoring", "8.41", "--output", "json"])
        nodes = json.loads(list_result.output)
        split_node = next(n for n in nodes if n["type"] == "split_2")

        result = runner.invoke(app, ["nodes", "describe", "monitoring", "8.41", split_node["id"], "--output", "json"])
        assert result.exit_code == 0, result.output
        node = json.loads(result.output)
        assert node["type"] == "split_2"
        assert "branches" in node["meta"]

    def test_describe_node_section_meta(self, monitoring_env: dict[str, Any]):
        """The --section meta flag should return only the meta field."""
        runner.invoke(app, ["flows", "describe", "monitoring", "--output", "json"])
        list_result = runner.invoke(app, ["nodes", "list", "monitoring", "8.41", "--output", "json"])
        nodes = json.loads(list_result.output)
        transform_node = next(n for n in nodes if n["type"] == "transform")

        result = runner.invoke(
            app,
            ["nodes", "describe", "monitoring", "8.41", transform_node["id"], "--section", "meta", "--output", "json"],
        )
        assert result.exit_code == 0, result.output
        node = json.loads(result.output)
        assert "meta" in node


class TestModifyNodes:
    """Modify nodes in the monitoring flow — the core surgical update use case."""

    def test_update_transform_source_code(self, monitoring_env: dict[str, Any]):
        """Update a transform node's source code (the most common edit)."""
        runner.invoke(app, ["flows", "describe", "monitoring", "--output", "json"])
        list_result = runner.invoke(app, ["nodes", "list", "monitoring", "8.41", "--output", "json"])
        nodes = json.loads(list_result.output)
        transform_node = next(n for n in nodes if n["type"] == "transform")
        node_id = transform_node["id"]

        # Get current source
        # Update source code
        new_src = 'data.result = "updated by tktl CLI"'
        result = runner.invoke(
            app,
            [
                "update",
                "apply",
                "monitoring",
                "8.41",
                "--node",
                node_id,
                "--node-config",
                json.dumps({"src": new_src}),
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output

        # Verify the change persisted
        after = runner.invoke(app, ["nodes", "describe", "monitoring", "8.41", node_id, "--output", "json"])
        after_node = json.loads(after.output)
        assert after_node["meta"]["src"] == new_src
        # Other meta fields should be preserved (deep merge)
        assert "created_by_id" in after_node["meta"]

    def test_update_preserves_other_nodes(self, monitoring_env: dict[str, Any]):
        """Updating one node should not affect any other node."""
        runner.invoke(app, ["flows", "describe", "monitoring", "--output", "json"])
        list_result = runner.invoke(app, ["nodes", "list", "monitoring", "8.41", "--output", "json"])
        nodes = json.loads(list_result.output)
        transforms = [n for n in nodes if n["type"] == "transform"]
        assert len(transforms) >= 2

        target_id = transforms[0]["id"]
        other_id = transforms[1]["id"]

        # Get the other node's state before
        before = runner.invoke(app, ["nodes", "describe", "monitoring", "8.41", other_id, "--output", "json"])
        other_before = json.loads(before.output)

        # Update the target node
        runner.invoke(
            app,
            [
                "update",
                "apply",
                "monitoring",
                "8.41",
                "--node",
                target_id,
                "--node-config",
                json.dumps({"src": "data.x = 1"}),
                "--output",
                "json",
            ],
        )

        # Verify the other node is unchanged
        after = runner.invoke(app, ["nodes", "describe", "monitoring", "8.41", other_id, "--output", "json"])
        other_after = json.loads(after.output)
        assert other_after["meta"] == other_before["meta"]

    def test_update_split_branch_condition(self, monitoring_env: dict[str, Any]):
        """Update a split node's branch conditions."""
        runner.invoke(app, ["flows", "describe", "monitoring", "--output", "json"])
        list_result = runner.invoke(app, ["nodes", "list", "monitoring", "8.41", "--output", "json"])
        nodes = json.loads(list_result.output)
        split_node = next(n for n in nodes if n["type"] == "split_2")
        node_id = split_node["id"]

        # Get current branches
        before = runner.invoke(app, ["nodes", "describe", "monitoring", "8.41", node_id, "--output", "json"])
        before_meta = json.loads(before.output)["meta"]
        original_branches = before_meta["branches"]

        # Modify a branch — add a new clause
        modified_branches = json.loads(json.dumps(original_branches))  # deep copy
        if modified_branches:
            modified_branches[0]["clauses"].append(
                {
                    "id_left": "new-left",
                    "id_right": "new-right",
                    "left": "data.new_field",
                    "right": "True",
                    "operator": "eq",
                }
            )

        result = runner.invoke(
            app,
            [
                "update",
                "apply",
                "monitoring",
                "8.41",
                "--node",
                node_id,
                "--node-config",
                json.dumps({"branches": modified_branches}),
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output

        # Verify
        after = runner.invoke(app, ["nodes", "describe", "monitoring", "8.41", node_id, "--output", "json"])
        after_branches = json.loads(after.output)["meta"]["branches"]
        # Branches are replaced entirely (not merged — they're a list)
        assert len(after_branches[0]["clauses"]) == len(original_branches[0]["clauses"]) + 1

    def test_update_node_via_file(self, monitoring_env: dict[str, Any], tmp_path: Path):
        """Update a node using @file syntax."""
        runner.invoke(app, ["flows", "describe", "monitoring", "--output", "json"])
        list_result = runner.invoke(app, ["nodes", "list", "monitoring", "8.41", "--output", "json"])
        nodes = json.loads(list_result.output)
        transform_node = next(n for n in nodes if n["type"] == "transform")
        node_id = transform_node["id"]

        patch_file = tmp_path / "patch.json"
        patch_file.write_text(json.dumps({"src": "data.patched_from_file = True"}))

        result = runner.invoke(
            app,
            [
                "update",
                "apply",
                "monitoring",
                "8.41",
                "--node",
                node_id,
                "--node-config",
                f"@{patch_file}",
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output

        after = runner.invoke(app, ["nodes", "describe", "monitoring", "8.41", node_id, "--output", "json"])
        assert json.loads(after.output)["meta"]["src"] == "data.patched_from_file = True"


class TestModifyVersionLevel:
    """Modify version-level fields: parameters, schemas."""

    def test_update_parameters(self, monitoring_env: dict[str, Any]):
        """Update the version's parameters array."""
        runner.invoke(app, ["flows", "describe", "monitoring", "--output", "json"])

        # Get current params
        before = runner.invoke(app, ["versions", "describe", "monitoring", "8.41", "--output", "json"])
        before_params = json.loads(before.output).get("parameters", [])
        assert len(before_params) == 19

        # Update one parameter
        new_params = json.loads(json.dumps(before_params))
        new_params[4]["value"] = 999  # MAX_NUMBER_OF_ACTIONS was 15

        result = runner.invoke(
            app,
            [
                "update",
                "apply",
                "monitoring",
                "8.41",
                "--params",
                json.dumps(new_params),
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output

        # Verify
        after = runner.invoke(app, ["versions", "describe", "monitoring", "8.41", "--output", "json"])
        after_params = json.loads(after.output)["parameters"]
        assert after_params[4]["value"] == 999

    def test_update_input_schema(self, monitoring_env: dict[str, Any]):
        """Update the version's input schema."""
        runner.invoke(app, ["flows", "describe", "monitoring", "--output", "json"])

        new_schema = {
            "type": "object",
            "required": ["alert_id"],
            "properties": {
                "alert_id": {"type": "string"},
                "severity": {"type": "integer"},
            },
        }

        result = runner.invoke(
            app,
            [
                "update",
                "apply",
                "monitoring",
                "8.41",
                "--schema-in",
                json.dumps(new_schema),
                "--output",
                "json",
            ],
        )
        assert result.exit_code == 0, result.output

        after = runner.invoke(app, ["versions", "describe", "monitoring", "8.41", "--output", "json"])
        after_schema = json.loads(after.output).get("input_schema")
        assert after_schema == new_schema

    def test_node_count_unchanged_after_version_update(self, monitoring_env: dict[str, Any]):
        """Updating version-level params should not affect nodes."""
        runner.invoke(app, ["flows", "describe", "monitoring", "--output", "json"])

        # List nodes before
        before = runner.invoke(app, ["nodes", "list", "monitoring", "8.41", "--output", "json"])
        nodes_before = json.loads(before.output)

        # Update params
        runner.invoke(
            app,
            ["update", "apply", "monitoring", "8.41", "--params", "[]", "--output", "json"],
        )

        # List nodes after
        after = runner.invoke(app, ["nodes", "list", "monitoring", "8.41", "--output", "json"])
        nodes_after = json.loads(after.output)
        assert len(nodes_after) == len(nodes_before)


class TestAgentWorkflow:
    """Simulate the typical agent workflow: orient → drill → modify → verify."""

    def test_full_agent_workflow(self, monitoring_env: dict[str, Any]):
        """
        1. List flows (orient)
        2. Describe flow (find versions)
        3. List nodes (find the right one)
        4. Describe node (read current state)
        5. Update node (make the change)
        6. Describe node again (verify)
        """
        # Step 1: Orient
        r1 = runner.invoke(app, ["flows", "list", "--output", "json"])
        assert r1.exit_code == 0
        flows = json.loads(r1.output)
        assert any(f["slug"] == "monitoring" for f in flows)

        # Step 2: Pick flow
        r2 = runner.invoke(app, ["flows", "describe", "monitoring", "--output", "json"])
        assert r2.exit_code == 0

        # Step 3: Find nodes
        r3 = runner.invoke(app, ["nodes", "list", "monitoring", "8.41", "--output", "json"])
        assert r3.exit_code == 0
        nodes = json.loads(r3.output)
        # An agent would pick based on name
        target = next((n for n in nodes if n["name"] == "Get Linear Issues Query"), None)
        assert target is not None

        # Step 4: Read current state
        r4 = runner.invoke(app, ["nodes", "describe", "monitoring", "8.41", target["id"], "--output", "json"])
        assert r4.exit_code == 0
        current = json.loads(r4.output)
        assert "src" in current["meta"]

        # Step 5: Make a surgical change
        r5 = runner.invoke(
            app,
            [
                "update",
                "apply",
                "monitoring",
                "8.41",
                "--node",
                target["id"],
                "--node-config",
                json.dumps({"src": 'data.linear_issues_query = "UPDATED BY AGENT"'}),
                "--output",
                "json",
            ],
        )
        assert r5.exit_code == 0

        # Step 6: Verify
        r6 = runner.invoke(app, ["nodes", "describe", "monitoring", "8.41", target["id"], "--output", "json"])
        assert r6.exit_code == 0
        updated = json.loads(r6.output)
        assert updated["meta"]["src"] == 'data.linear_issues_query = "UPDATED BY AGENT"'
        # Deep merge preserved other meta fields
        assert updated["meta"]["created_by_id"] == current["meta"]["created_by_id"]
