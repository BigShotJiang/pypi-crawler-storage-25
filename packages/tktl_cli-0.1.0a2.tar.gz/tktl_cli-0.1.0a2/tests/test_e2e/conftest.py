"""Shared fixtures for E2E tests — re-uses the CLI test fixtures."""

from __future__ import annotations

from tests.test_cli.conftest import cli_env  # noqa: F401
