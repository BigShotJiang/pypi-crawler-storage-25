"""Integration tests for the TomTest multi-country KYB/underwriting flow on staging.

Calls ``tktl.ops.flows.run_flow`` directly (no subprocess) with ``mock_data``
to mock all 6 country subflows (they contain review_connection_nodes that
prevent sync execution).

Covers all execution pathways:
- 5 revenue segments: XS (<=1M), S (<=5M), M (<=10M), L (<=50M), XL (>50M)
- 6 country routes: DE, ES, FR, IT, UK, US (default)
- Country code mapping: germany/ger/deutschland/de -> DE, spain/espana/es -> ES, etc.
- Enrichment success/failure branching

Requires:
    TKTL_CONFIG_DIR pointing at a config with workspace + credentials set.

Skip with: pytest -m "not staging"
"""

from __future__ import annotations

from typing import Any

import pytest

from tktl.api.client import TktlClient
from tktl.ops.flows import run_flow

FLOW_SLUG = "tomtest"
VERSION = "v0.1"

# Subflow node IDs (type=flow) + connection nodes in the parent graph.
# Mock all of them to avoid child flow compile errors and external API calls.
_SUBFLOW_MOCK = {
    # Country subflows
    "de3a8200-3926-43f8-89ab-ffe1c4dfd2b3": {"data_enrichment_results": {"status": "ok"}},
    "39075a4f-a5d2-4a2f-80f6-50c7767beb00": {"data_enrichment_results": {"status": "ok"}},
    "c48c01cd-e0d9-46ec-8111-dfcc8e629c69": {"data_enrichment_results": {"status": "ok"}},
    "588bbe33-5bff-4cf3-b9b6-8a64df349e62": {"data_enrichment_results": {"status": "ok"}},
    "e80ad687-485a-4e8d-ae22-6478d0ff8f84": {"data_enrichment_results": {"status": "ok"}},
    "5cfeb5a6-433e-4563-95de-fb903f994d69": {"data_enrichment_results": {"status": "ok"}},
    # Parent flow connection nodes
    "76a3636d-7c9d-40ad-9ac0-274e2a279a6d": {"sanctions_check": "clear"},
}

pytestmark = [pytest.mark.staging, pytest.mark.integration]

_BASE_INPUT: dict[str, Any] = {
    "company_id": "test-123",
    "company_legal_name": "Acme GmbH",
    "company_country_code": "DE",
    "company_registration_nr": "HRB12345",
    "company_vat_id": "DE123456789",
    "self_declared_revenue": 5_000_000,
    "country": "germany",
    "country_code": "DE",
    "credit_score": 750,
    "common_score": 80,
    "company_profile": "active",
    "dob": "1985-03-15",
    "dob_parsed": "1985-03-15",
    "dob_parsed_status": "ok",
    "inputs": "{}",
    "preprocessing_passed": "true",
    "success": "true",
}


def _run(client: TktlClient, workspace_id: str, **overrides: Any) -> dict[str, Any]:
    """Run the TomTest flow via the ops layer."""
    data = {**_BASE_INPUT, **{k: v for k, v in overrides.items() if v is not None}}
    for k, v in overrides.items():
        if v is None:
            data.pop(k, None)

    return run_flow(
        client,
        workspace_id,
        FLOW_SLUG,
        data,
        version=VERSION,
        mock_data=_SUBFLOW_MOCK,
        execution_mode="async",
        poll_timeout=120.0,
    )


def _assert_success(result: dict[str, Any]) -> dict[str, Any]:
    """Assert the flow returned status=success and return the data dict."""
    assert result["status"] == "success", (
        f"Expected success, got {result['status']}: {result.get('detail', {}).get('msg', 'no detail')}"
    )
    return result["data"]


# --- Revenue segmentation ---


class TestRevenueSegmentation:
    """Check company segment rule: XS <=1M, S <=5M, M <=10M, L <=50M, XL >50M."""

    def test_xs_segment(self, stg_client: TktlClient, stg_workspace_id: str) -> None:
        data = _assert_success(_run(stg_client, stg_workspace_id, self_declared_revenue=500_000))
        assert data["segment"] == "XS"

    def test_xs_boundary(self, stg_client: TktlClient, stg_workspace_id: str) -> None:
        data = _assert_success(_run(stg_client, stg_workspace_id, self_declared_revenue=1_000_000))
        assert data["segment"] == "XS"

    def test_s_segment(self, stg_client: TktlClient, stg_workspace_id: str) -> None:
        data = _assert_success(_run(stg_client, stg_workspace_id, self_declared_revenue=3_000_000))
        assert data["segment"] == "S"

    def test_s_boundary(self, stg_client: TktlClient, stg_workspace_id: str) -> None:
        data = _assert_success(_run(stg_client, stg_workspace_id, self_declared_revenue=5_000_000))
        assert data["segment"] == "S"

    def test_m_segment(self, stg_client: TktlClient, stg_workspace_id: str) -> None:
        data = _assert_success(_run(stg_client, stg_workspace_id, self_declared_revenue=7_000_000))
        assert data["segment"] == "M"

    def test_m_boundary(self, stg_client: TktlClient, stg_workspace_id: str) -> None:
        data = _assert_success(_run(stg_client, stg_workspace_id, self_declared_revenue=10_000_000))
        assert data["segment"] == "M"

    def test_l_segment(self, stg_client: TktlClient, stg_workspace_id: str) -> None:
        data = _assert_success(_run(stg_client, stg_workspace_id, self_declared_revenue=25_000_000))
        assert data["segment"] == "L"

    def test_l_boundary(self, stg_client: TktlClient, stg_workspace_id: str) -> None:
        data = _assert_success(_run(stg_client, stg_workspace_id, self_declared_revenue=50_000_000))
        assert data["segment"] == "L"

    def test_xl_segment(self, stg_client: TktlClient, stg_workspace_id: str) -> None:
        data = _assert_success(_run(stg_client, stg_workspace_id, self_declared_revenue=100_000_000))
        assert data["segment"] == "XL"


# --- Country routing ---


class TestCountryRouting:
    """Each country code routes through a different enrichment branch."""

    @pytest.mark.parametrize(
        "country_name,country_code",
        [
            ("germany", "DE"),
            ("spain", "ES"),
            ("france", "FR"),
            ("italy", "IT"),
            ("united kingdom", "UK"),
        ],
    )
    def test_known_country(
        self, stg_client: TktlClient, stg_workspace_id: str, country_name: str, country_code: str
    ) -> None:
        data = _assert_success(_run(stg_client, stg_workspace_id, country=country_name, country_code=country_code))
        assert data is not None

    def test_us_default_route(self, stg_client: TktlClient, stg_workspace_id: str) -> None:
        """US is the default/fallback route in the country split."""
        data = _assert_success(_run(stg_client, stg_workspace_id, country="united states", country_code="US"))
        assert data is not None


# --- Country code mapping (decision table) ---


class TestCountryCodeMapping:
    """The decision table maps country names to ISO codes."""

    @pytest.mark.parametrize(
        "country_name,expected_code",
        [
            ("germany", "DE"),
            ("ger", "DE"),
            ("deutschland", "DE"),
            ("de", "DE"),
            ("spain", "ES"),
            ("espana", "ES"),
            ("es", "ES"),
        ],
    )
    def test_known_mapping(
        self, stg_client: TktlClient, stg_workspace_id: str, country_name: str, expected_code: str
    ) -> None:
        data = _assert_success(_run(stg_client, stg_workspace_id, country=country_name))
        assert data["country_code"] == expected_code

    def test_unknown_country_maps_to_unknown(self, stg_client: TktlClient, stg_workspace_id: str) -> None:
        data = _assert_success(_run(stg_client, stg_workspace_id, country="narnia"))
        assert data["country_code"] == "UNKNOWN"


# --- Enrichment success/failure ---


class TestEnrichmentBranching:
    """The 'Enrichment successful?' split checks data.success != True."""

    def test_success_path(self, stg_client: TktlClient, stg_workspace_id: str) -> None:
        """success="true" takes the 'Yes, continue' branch."""
        data = _assert_success(_run(stg_client, stg_workspace_id, success="true"))
        assert data is not None

    def test_failure_path(self, stg_client: TktlClient, stg_workspace_id: str) -> None:
        """success="false" takes the 'No, log errors' branch."""
        result = _run(stg_client, stg_workspace_id, success="false")
        assert result["status"] == "success"


# --- Full pipeline per country ---


class TestFullPipelineByCountry:
    """Each country goes through: enrichment -> credit score mapping -> merge."""

    @pytest.mark.parametrize(
        "country,country_code",
        [
            ("germany", "DE"),
            ("spain", "ES"),
            ("de", "DE"),
            ("es", "ES"),
        ],
    )
    def test_full_pipeline_success(
        self, stg_client: TktlClient, stg_workspace_id: str, country: str, country_code: str
    ) -> None:
        data = _assert_success(
            _run(
                stg_client,
                stg_workspace_id,
                country=country,
                country_code=country_code,
                credit_score=750,
                success="true",
            )
        )
        assert data["segment"] in ("XS", "S", "M", "L", "XL")
        assert data["country_code"] == country_code


# --- Edge cases ---


class TestEdgeCases:
    """Boundary conditions and unusual inputs."""

    def test_zero_revenue(self, stg_client: TktlClient, stg_workspace_id: str) -> None:
        data = _assert_success(_run(stg_client, stg_workspace_id, self_declared_revenue=0))
        assert data["segment"] == "XS"

    def test_negative_revenue(self, stg_client: TktlClient, stg_workspace_id: str) -> None:
        data = _assert_success(_run(stg_client, stg_workspace_id, self_declared_revenue=-100))
        assert data["segment"] == "XS"

    def test_very_high_revenue(self, stg_client: TktlClient, stg_workspace_id: str) -> None:
        data = _assert_success(_run(stg_client, stg_workspace_id, self_declared_revenue=999_999_999))
        assert data["segment"] == "XL"

    def test_missing_optional_fields(self, stg_client: TktlClient, stg_workspace_id: str) -> None:
        """Run with only required input fields + enrichment fields."""
        result = _run(
            stg_client,
            stg_workspace_id,
            company_profile=None,
            dob=None,
            dob_parsed=None,
            dob_parsed_status=None,
        )
        assert result["status"] in ("success", "error")
