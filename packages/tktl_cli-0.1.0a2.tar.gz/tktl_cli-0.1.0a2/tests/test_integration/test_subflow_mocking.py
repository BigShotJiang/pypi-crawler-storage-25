"""Integration tests for subflow mocking via ``mock_data``.

The Taktile decide API accepts a ``mock_data`` field in the request body.
The CLI exposes this as ``--mock-data`` (``-m``), and the ops layer as
``run_flow(..., mock_data=...)``.

Strategy 1: Mock the entire subflow
    Key: ``{subflow_node_id}``
    Replaces the entire child flow execution with fixed output data.

Strategy 2: Mock specific connection nodes inside a child flow
    Key: ``{subflow_node_id}__{child_connection_node_id}``
    Mocks individual connection nodes inside the child flow while letting
    the rest of the child flow's logic (rules, transforms, splits) run.

Requires:
    TKTL_CONFIG_DIR pointing at a config with workspace + credentials set.
    TKTL_STG_API_KEY for graph introspection tests.

Skip with: pytest -m "not staging"
"""

from __future__ import annotations

from typing import Any

import httpx
import pytest

from tktl.api.client import TktlClient
from tktl.ops.flows import run_flow

from .conftest import STG_API_KEY, STG_FLOW_API_URL, STG_WORKSPACE_ID

PARENT_SLUG = "tomtest"
PARENT_VERSION = "v0.1"
CHILD_SLUG = "data-germany"
CHILD_VERSION = "v1.0"

pytestmark = [pytest.mark.staging, pytest.mark.integration]


CONNECTION_NODE_TYPES = frozenset(
    {
        "custom_connection_node",
        "webhook_connection_node",
        "data_integration",
        "review_connection_node",
    }
)

_BASE_INPUT: dict[str, Any] = {
    "company_id": "test-123",
    "company_legal_name": "Acme GmbH",
    "company_country_code": "DE",
    "company_registration_nr": "HRB12345",
    "company_vat_id": "DE123456789",
    "self_declared_revenue": 5_000_000,
    "country": "germany",
    "country_code": "DE",
    "credit_score": 750,
    "common_score": 80,
    "company_profile": "active",
    "dob": "1985-03-15",
    "dob_parsed": "1985-03-15",
    "dob_parsed_status": "ok",
    "inputs": "{}",
    "preprocessing_passed": "true",
    "success": "true",
}


# --- Helpers ---


@pytest.fixture
def raw_client() -> httpx.Client:
    """Raw httpx client for direct API calls (graph introspection only)."""
    if not STG_API_KEY:
        pytest.skip("TKTL_STG_API_KEY not set")
    return httpx.Client(
        base_url=STG_FLOW_API_URL,
        headers={"X-Api-Key": STG_API_KEY, "X-Workspace-Id": STG_WORKSPACE_ID},
        timeout=30.0,
    )


def _run_flow(
    client: TktlClient,
    workspace_id: str,
    slug: str,
    version: str,
    input_data: dict[str, Any],
    mock_data: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Run a flow via the ops layer and return the result dict."""
    return run_flow(
        client,
        workspace_id,
        slug,
        input_data,
        version=version,
        mock_data=mock_data,
        execution_mode="async",
        poll_timeout=120.0,
    )


def _find_flow_by_slug(client: httpx.Client, slug: str) -> dict[str, Any]:
    """Find a flow by slug from the workspace flow list."""
    r = client.get("/api/v1/flows")
    r.raise_for_status()
    for f in r.json():
        if f.get("slug") == slug:
            return f
    raise ValueError(f"Flow '{slug}' not found in workspace")


def _get_version_detail(client: httpx.Client, version_id: str) -> dict[str, Any]:
    """Fetch a flow version with full graph (v2 dict format)."""
    r = client.get(f"/api/v2/flow_versions/{version_id}")
    r.raise_for_status()
    return r.json()


def _find_version_id(flow: dict[str, Any], version_name: str) -> str:
    """Find a version ID by name from the flow's inline versions list."""
    for v in flow.get("versions", []):
        if v["name"] == version_name:
            return v["id"]
    dsv = flow.get("default_sandbox_version")
    if dsv:
        return dsv
    raise ValueError(f"Version '{version_name}' not found for flow '{flow['slug']}'")


def _find_subflow_node_id(graph: dict[str, Any], child_slug: str) -> str:
    """Find the parent graph node ID for a subflow by child_flow_slug."""
    for nid, n in graph.get("nodes", {}).items():
        if n.get("type") == "flow" and n.get("meta", {}).get("child_flow_slug") == child_slug:
            return nid
    raise ValueError(f"No subflow node for child_flow_slug='{child_slug}'")


def _get_connection_node_ids(graph: dict[str, Any]) -> dict[str, str]:
    """Return {node_id: node_name} for all connection-type nodes in a graph."""
    result = {}
    for nid, n in graph.get("nodes", {}).items():
        if n.get("type") in CONNECTION_NODE_TYPES:
            result[nid] = n.get("name", nid)
    return result


# =============================================================================
# Strategy 1: Mock the entire subflow via mock_data
#
# Key format: ``{subflow_node_id}``
# =============================================================================


class TestMockEntireSubflow:
    """Mock a subflow's output via ``run_flow(..., mock_data=...)``."""

    MOCK_ENRICHMENT = {
        "company_name": "Mock GmbH",
        "risk_score": 42,
        "status": "approved",
    }

    @pytest.fixture(autouse=True)
    def _setup(self, raw_client: httpx.Client):
        """Resolve the subflow node ID in the parent graph."""
        parent_flow = _find_flow_by_slug(raw_client, PARENT_SLUG)
        parent_vid = _find_version_id(parent_flow, PARENT_VERSION)
        parent = _get_version_detail(raw_client, parent_vid)
        self.germany_node_id = _find_subflow_node_id(parent["graph"], CHILD_SLUG)
        # Mock all subflows to avoid review_connection_node compile errors
        self.all_subflow_mock: dict[str, Any] = {}
        for nid, n in parent["graph"]["nodes"].items():
            if n.get("type") == "flow":
                self.all_subflow_mock[nid] = {
                    "data_enrichment_results": self.MOCK_ENRICHMENT,
                }

    def test_parent_with_mocked_subflow(self, stg_client: TktlClient, stg_workspace_id: str) -> None:
        """Parent flow should use mock_data for the subflow node."""
        result = _run_flow(
            stg_client,
            stg_workspace_id,
            PARENT_SLUG,
            PARENT_VERSION,
            _BASE_INPUT,
            mock_data=self.all_subflow_mock,
        )
        assert "data" in result or "detail" in result

    def test_parent_routing_with_mock(self, stg_client: TktlClient, stg_workspace_id: str) -> None:
        """Parent routing logic works with a mocked subflow."""
        result = _run_flow(
            stg_client,
            stg_workspace_id,
            PARENT_SLUG,
            PARENT_VERSION,
            {**_BASE_INPUT, "country": "germany", "country_code": "DE"},
            mock_data=self.all_subflow_mock,
        )
        assert "data" in result or "detail" in result

    def test_empty_mock_data(self, stg_client: TktlClient, stg_workspace_id: str) -> None:
        """Passing empty mock_data should not crash."""
        result = _run_flow(
            stg_client,
            stg_workspace_id,
            PARENT_SLUG,
            PARENT_VERSION,
            _BASE_INPUT,
            mock_data={},
        )
        # Empty mock means subflows run for real — may error, but shouldn't crash
        assert isinstance(result, dict)


# =============================================================================
# Strategy 2: Mock specific connection nodes inside the child flow
#
# Key format: ``{subflow_node_id}__{child_connection_node_id}``
# =============================================================================


class TestMockConnectionsInChild:
    """Mock connection nodes inside a child flow via the __ separator format."""

    @pytest.fixture(autouse=True)
    def _setup(self, raw_client: httpx.Client):
        """Load parent + child graphs, find node IDs for mock_data keys."""
        parent_flow = _find_flow_by_slug(raw_client, PARENT_SLUG)
        parent_vid = _find_version_id(parent_flow, PARENT_VERSION)
        parent = _get_version_detail(raw_client, parent_vid)
        self.subflow_node_id = _find_subflow_node_id(parent["graph"], CHILD_SLUG)

        # Mock all OTHER subflows to avoid compile errors
        self.other_subflow_mock: dict[str, Any] = {}
        for nid, n in parent["graph"]["nodes"].items():
            if n.get("type") == "flow" and nid != self.subflow_node_id:
                self.other_subflow_mock[nid] = {
                    "data_enrichment_results": {"status": "ok"},
                }

        child_flow = _find_flow_by_slug(raw_client, CHILD_SLUG)
        child_vid = _find_version_id(child_flow, CHILD_VERSION)
        self.child_graph = _get_version_detail(raw_client, child_vid)
        self.connection_nodes = _get_connection_node_ids(self.child_graph["graph"])

        self.connection_types: dict[str, int] = {}
        for nid in self.connection_nodes:
            ntype = self.child_graph["graph"]["nodes"][nid]["type"]
            self.connection_types[ntype] = self.connection_types.get(ntype, 0) + 1

        self.has_review_nodes = self.connection_types.get("review_connection_node", 0) > 0

    def _mock_key(self, child_node_id: str) -> str:
        """Build the mock_data key: {subflow_node_id}__{child_node_id}."""
        return f"{self.subflow_node_id}__{child_node_id}"

    def test_connection_inventory(self) -> None:
        """Child flow should have connection nodes that need mocking."""
        assert self.connection_nodes, "Expected connection nodes in child flow"

    def test_cc_nodes_have_sandbox_mock_config(self) -> None:
        """Verify CC nodes have sandbox_mode_data_source configured."""
        for nid, n in self.child_graph["graph"]["nodes"].items():
            if n.get("type") != "custom_connection_node":
                continue
            config = n.get("meta", {}).get("config", {})
            env_config = config.get("environments_config", {})
            sandbox_src = env_config.get("sandbox_mode_data_source", "")
            assert sandbox_src in ("mock_data", "production"), (
                f"Node '{n.get('name', nid)}' has unexpected sandbox_mode_data_source: '{sandbox_src}'"
            )

    def test_mock_individual_connection_in_child(self, stg_client: TktlClient, stg_workspace_id: str) -> None:
        """Mock a specific CC node inside the child flow via __ separator."""
        cc_node_id = None
        for nid, n in self.child_graph["graph"]["nodes"].items():
            if n.get("type") == "custom_connection_node":
                cc_node_id = nid
                break
        if cc_node_id is None:
            pytest.skip("No custom_connection_node in child flow")

        mock_data = {
            **self.other_subflow_mock,
            self._mock_key(cc_node_id): {"sample_report": "mocked_response"},
        }
        result = _run_flow(
            stg_client,
            stg_workspace_id,
            PARENT_SLUG,
            PARENT_VERSION,
            _BASE_INPUT,
            mock_data=mock_data,
        )
        assert "data" in result or "detail" in result

    def test_mock_all_connections_in_child(self, stg_client: TktlClient, stg_workspace_id: str) -> None:
        """Mock all connection nodes inside the child flow."""
        if not self.connection_nodes:
            pytest.skip("No connection nodes in child flow")

        mock_data: dict[str, Any] = {**self.other_subflow_mock}
        for nid in self.connection_nodes:
            mock_data[self._mock_key(nid)] = {"mocked": True}

        result = _run_flow(
            stg_client,
            stg_workspace_id,
            PARENT_SLUG,
            PARENT_VERSION,
            _BASE_INPUT,
            mock_data=mock_data,
        )
        assert "data" in result or "detail" in result
