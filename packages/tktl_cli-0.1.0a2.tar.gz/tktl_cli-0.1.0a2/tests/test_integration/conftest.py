"""Fixtures for integration tests against the real Taktile dev environment.

Reads config from .env file (local) or environment variables (CI).
All tests are marked with @pytest.mark.integration and skipped when
TKTL_DEV_API_KEY is not set.
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest
from dotenv import load_dotenv

from tktl.api.client import TktlClient
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.config import Config

# Load .env from project root (no-op if file doesn't exist)
_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
load_dotenv(_PROJECT_ROOT / ".env")

# Read config from env
DEV_API_KEY = os.environ.get("TKTL_DEV_API_KEY", "")
DEV_FLOW_API_URL = os.environ.get("TKTL_DEV_FLOW_API_URL", "https://flow-api.dev.cp.taktile.com")
DEV_TAKTILE_API_URL = os.environ.get("TKTL_DEV_TAKTILE_API_URL", "https://taktile-api.dev.cp.taktile.com")
DEV_WORKSPACE_ID = os.environ.get("TKTL_DEV_WORKSPACE_ID", "61174b45-d517-417d-87e3-0222d13135d6")
DEV_ORG_ID = os.environ.get("TKTL_DEV_ORG_ID", "9835812b-e5be-4fe1-b5a1-792de7d418bb")
DEV_FLOW_SLUG = os.environ.get("TKTL_DEV_FLOW_SLUG", "no-op-2")
DEV_VERSION_NAME = os.environ.get("TKTL_DEV_VERSION_NAME", "Policy Enforcement v6")


def _skip_if_no_key():
    if not DEV_API_KEY:
        pytest.skip("TKTL_DEV_API_KEY not set — skipping integration test")


@pytest.fixture
def dev_client(tmp_path: Path) -> TktlClient:
    """TktlClient pointed at the real dev Flow API."""
    _skip_if_no_key()
    return TktlClient(
        config_dir=tmp_path,
        base_url=DEV_FLOW_API_URL,
        api_key=DEV_API_KEY,
    )


@pytest.fixture
def dev_cache_dir(tmp_path: Path) -> Path:
    d = tmp_path / "cache"
    d.mkdir()
    return d


@pytest.fixture
def dev_cache_manager(dev_cache_dir: Path) -> CacheManager:
    return CacheManager(dev_cache_dir)


@pytest.fixture
def dev_cache_index(dev_cache_dir: Path) -> CacheIndex:
    idx = CacheIndex(dev_cache_dir)
    idx.load()
    return idx


# --- Staging fixtures (TKTL_CONFIG_DIR-based) ---

STG_API_KEY = os.environ.get("TKTL_STG_API_KEY", "")
STG_FLOW_API_URL = os.environ.get("TKTL_STG_FLOW_API_URL", "https://flow-api.stg.cp.taktile.com")
STG_WORKSPACE_ID = os.environ.get("TKTL_STG_WORKSPACE_ID", "b22b1b8a-efdc-49d9-9bd7-49a00ea9dab8")


@pytest.fixture(scope="session")
def stg_client() -> TktlClient:
    """TktlClient built from TKTL_CONFIG_DIR, shared across the session."""
    config_dir = os.environ.get("TKTL_CONFIG_DIR")
    if not config_dir:
        pytest.skip("TKTL_CONFIG_DIR not set — skipping staging test")
    return TktlClient(config_dir=Path(config_dir))


@pytest.fixture(scope="session")
def stg_workspace_id() -> str:
    """Workspace ID from TKTL_CONFIG_DIR config."""
    config_dir = os.environ.get("TKTL_CONFIG_DIR")
    if not config_dir:
        pytest.skip("TKTL_CONFIG_DIR not set — skipping staging test")

    cfg = Config(Path(config_dir))
    cfg.load()
    ws = cfg.get("workspace")
    if not ws:
        pytest.skip("No workspace configured in TKTL_CONFIG_DIR")
    return ws
