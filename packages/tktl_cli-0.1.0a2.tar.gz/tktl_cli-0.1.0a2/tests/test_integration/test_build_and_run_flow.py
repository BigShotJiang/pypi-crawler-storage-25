"""Integration test: build a functional flow from scratch and execute it.

Duplicates v1.0 (minimal input->output), adds a transform node with scoring
logic, sets schemas and parameters, then executes and verifies the output.

Adding new rule_2/assignment_node types via PATCH is not supported by the API
(fails with 422). Only transform nodes can be added to new versions. For rule
and assignment testing, use the existing Policy Enforcement version (see
test_modify_flow.py).
"""

from __future__ import annotations

import copy
import time
import uuid
from datetime import UTC, datetime
from typing import Any

import pytest

from tktl.api.client import TktlClient
from tktl.api.execution import _workspace_base_url_cache, run_flow as api_run_flow
from tktl.api.versions import delete_version, get_version, patch_version
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.ops.flows import describe_flow
from tktl.ops.nodes import list_nodes
from tktl.ops.versions import describe_version, duplicate_version

from .conftest import DEV_FLOW_SLUG, DEV_WORKSPACE_ID

pytestmark = pytest.mark.integration

# v1.0 is the minimal published version: input -> output, no logic
SOURCE_VERSION = "v1.0"


@pytest.fixture
def built_flow(
    dev_client: TktlClient,
    dev_cache_index: CacheIndex,
    dev_cache_manager: CacheManager,
) -> Any:
    """Build: input -> transform -> output with scoring logic, schema, params."""
    _workspace_base_url_cache.clear()

    describe_flow(dev_client, dev_cache_index, dev_cache_manager, DEV_WORKSPACE_ID, DEV_FLOW_SLUG)

    ts = datetime.now(UTC).strftime("%Y%m%d-%H%M%S")
    version_name = f"cli-build-{ts}"
    version = duplicate_version(
        dev_client,
        dev_cache_index,
        dev_cache_manager,
        DEV_WORKSPACE_ID,
        DEV_FLOW_SLUG,
        SOURCE_VERSION,
        version_name,
    )
    version_id = version.id
    flow_id = dev_cache_index.resolve_flow_id(DEV_FLOW_SLUG)
    assert flow_id is not None

    time.sleep(2)

    raw = get_version(dev_client, version_id)
    assert raw is not None
    nodes = raw["graph"]["nodes"]
    assert isinstance(nodes, dict)
    etag = raw["etag"]
    user_id = dev_client._user_id or "cli-test"

    input_id = next(nid for nid, n in nodes.items() if n["type"] == "input")
    output_id = next(nid for nid, n in nodes.items() if n["type"] == "output")
    old_edge_id = next(iter(raw["graph"]["edges"].keys()))

    # Add a transform node between input and output
    transform_id = str(uuid.uuid4())
    edge_in = str(uuid.uuid4())
    edge_out = str(uuid.uuid4())
    session = str(uuid.uuid4())

    all_nodes = copy.deepcopy(nodes)
    all_nodes[transform_id] = {
        "name": "Score Calculator",
        "type": "transform",
        "meta": {
            "created_by_id": user_id,
            "updated_by_id": user_id,
            "src": (
                'data.score = params.base_score + len(str(data.get("name", "")))\n'
                "data.greeting = f\"Hello {data.get('name', 'stranger')}, score={data.score}\""
            ),
        },
    }
    all_nodes[output_id]["meta"]["src"] = "data"

    body: dict[str, Any] = {
        "graph": {
            "nodes": all_nodes,
            "edges": {
                old_edge_id: None,
                edge_in: {
                    "start_node_id": input_id,
                    "end_node_id": transform_id,
                    "meta": {"is_split_edge": False},
                },
                edge_out: {
                    "start_node_id": transform_id,
                    "end_node_id": output_id,
                    "meta": {"is_split_edge": False},
                },
            },
        },
        "input_schema": {
            "type": "object",
            "required": ["name"],
            "properties": {"name": {"type": "string"}, "age": {"type": "integer"}},
            "$schema": "https://json-schema.org/draft/2020-12/schema",
        },
        "output_schema": {
            "type": "object",
            "properties": {"score": {"type": "number"}, "greeting": {"type": "string"}},
            "$schema": "https://json-schema.org/draft/2020-12/schema",
        },
        "parameters": [
            {"name": "base_score", "value": 50, "expr": "50", "description": "Base score for all applicants"},
        ],
    }

    result = patch_version(dev_client, version_id, body, if_match=etag, session=session)
    new_etag = result["etag"]

    dev_cache_manager.invalidate_version(version_id, flow_id)
    describe_flow(dev_client, dev_cache_index, dev_cache_manager, DEV_WORKSPACE_ID, DEV_FLOW_SLUG)

    yield {
        "version_name": version_name,
        "version_id": version_id,
        "transform_id": transform_id,
        "input_id": input_id,
        "output_id": output_id,
        "etag": new_etag,
    }

    try:
        delete_version(dev_client, version_id)
    except Exception:
        pass


class TestBuildAndRunFlow:
    """Build a flow from empty, add a node, set schema/params, execute."""

    def test_flow_has_three_nodes(
        self,
        built_flow: dict[str, Any],
        dev_client: TktlClient,
        dev_cache_index: CacheIndex,
        dev_cache_manager: CacheManager,
    ) -> None:
        """After building: input, transform, output."""
        describe_flow(dev_client, dev_cache_index, dev_cache_manager, DEV_WORKSPACE_ID, DEV_FLOW_SLUG)
        nodes = list_nodes(
            dev_client,
            dev_cache_index,
            dev_cache_manager,
            DEV_WORKSPACE_ID,
            DEV_FLOW_SLUG,
            built_flow["version_name"],
        )
        assert len(nodes) == 3
        types = {n.type for n in nodes}
        assert types == {"input", "output", "transform"}
        names = {n.name for n in nodes}
        assert "Score Calculator" in names

    def test_transform_has_score_logic(self, built_flow: dict[str, Any], dev_client: TktlClient) -> None:
        raw = get_version(dev_client, built_flow["version_id"])
        assert raw is not None
        nodes = raw["graph"]["nodes"]
        if isinstance(nodes, list):
            nodes = {n["id"]: n for n in nodes}
        src = nodes[built_flow["transform_id"]]["meta"]["src"]
        assert "params.base_score" in src
        assert "data.score" in src

    def test_version_has_input_schema(
        self,
        built_flow: dict[str, Any],
        dev_client: TktlClient,
        dev_cache_index: CacheIndex,
        dev_cache_manager: CacheManager,
    ) -> None:
        describe_flow(dev_client, dev_cache_index, dev_cache_manager, DEV_WORKSPACE_ID, DEV_FLOW_SLUG)
        ver = describe_version(
            dev_client,
            dev_cache_index,
            dev_cache_manager,
            DEV_WORKSPACE_ID,
            DEV_FLOW_SLUG,
            built_flow["version_name"],
        )
        assert ver.input_schema is not None
        assert "name" in ver.input_schema.get("properties", {})

    def test_version_has_output_schema(self, built_flow: dict[str, Any], dev_client: TktlClient) -> None:
        raw = get_version(dev_client, built_flow["version_id"])
        assert raw is not None
        props = raw.get("output_schema", {}).get("properties", {})
        assert "score" in props
        assert "greeting" in props

    def test_version_has_parameters(self, built_flow: dict[str, Any], dev_client: TktlClient) -> None:
        raw = get_version(dev_client, built_flow["version_id"])
        assert raw is not None
        params = raw.get("parameters", [])
        assert any(p["name"] == "base_score" and p["value"] == 50 for p in params)

    def test_execute_computes_score(self, built_flow: dict[str, Any], dev_client: TktlClient) -> None:
        """score = base_score(50) + len("Alice")(5) = 55."""
        result = api_run_flow(
            dev_client,
            DEV_WORKSPACE_ID,
            DEV_FLOW_SLUG,
            input_data={"name": "Alice", "age": 30},
            version=built_flow["version_name"],
            env="sandbox",
        )
        assert result["status"] == "success"
        assert result["data"]["score"] == 55
        assert "Alice" in result["data"]["greeting"]

    def test_execute_different_name(self, built_flow: dict[str, Any], dev_client: TktlClient) -> None:
        """score = 50 + len("Bob")(3) = 53."""
        result = api_run_flow(
            dev_client,
            DEV_WORKSPACE_ID,
            DEV_FLOW_SLUG,
            input_data={"name": "Bob"},
            version=built_flow["version_name"],
            env="sandbox",
        )
        assert result["status"] == "success"
        assert result["data"]["score"] == 53

    def test_execute_empty_name(self, built_flow: dict[str, Any], dev_client: TktlClient) -> None:
        """score = 50 + len("")(0) = 50."""
        result = api_run_flow(
            dev_client,
            DEV_WORKSPACE_ID,
            DEV_FLOW_SLUG,
            input_data={"name": ""},
            version=built_flow["version_name"],
            env="sandbox",
        )
        assert result["status"] == "success"
        assert result["data"]["score"] == 50
