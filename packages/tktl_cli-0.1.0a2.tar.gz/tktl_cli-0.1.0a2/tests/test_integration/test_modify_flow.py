"""Integration tests that CREATE and MODIFY a real flow version on dev.

These tests duplicate an existing version, make changes via the ops layer,
then verify the changes by re-reading from the API. The duplicate version
is deleted at the end (cleanup).

Run locally:
    uv run pytest tests/test_integration/test_modify_flow.py -v
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

import pytest

from tktl.api.client import TktlClient
from tktl.api.versions import delete_version, get_version
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.ops.flows import describe_flow
from tktl.ops.nodes import get_node, list_nodes, update_node
from tktl.ops.versions import describe_version, duplicate_version, update_version

from .conftest import DEV_FLOW_SLUG, DEV_WORKSPACE_ID

pytestmark = pytest.mark.integration

SOURCE_VERSION_NAME = "Policy Enforcement v6"


@pytest.fixture
def test_version(
    dev_client: TktlClient,
    dev_cache_index: CacheIndex,
    dev_cache_manager: CacheManager,
) -> Any:
    """Create a temporary version by duplicating, delete after test."""
    describe_flow(dev_client, dev_cache_index, dev_cache_manager, DEV_WORKSPACE_ID, DEV_FLOW_SLUG)

    ts = datetime.now(UTC).strftime("%Y%m%d-%H%M%S")
    test_name = f"cli-test-{ts}"
    version = duplicate_version(
        dev_client,
        dev_cache_index,
        dev_cache_manager,
        DEV_WORKSPACE_ID,
        DEV_FLOW_SLUG,
        SOURCE_VERSION_NAME,
        test_name,
    )

    yield {"version_detail": version, "name": test_name, "id": version.id}

    try:
        delete_version(dev_client, version.id)
    except Exception:
        pass


class TestModifyVersion:
    def test_duplicate_creates_version(self, test_version: dict[str, Any], dev_client: TktlClient) -> None:
        raw = get_version(dev_client, test_version["id"])
        assert raw is not None
        assert raw["name"] == test_version["name"]
        assert raw["status"] == "DRAFT"

    def test_update_transform_node_src(
        self,
        test_version: dict[str, Any],
        dev_client: TktlClient,
        dev_cache_index: CacheIndex,
        dev_cache_manager: CacheManager,
    ) -> None:
        """Update a transform node's source code and verify via fresh API read."""
        version_name = test_version["name"]
        describe_flow(dev_client, dev_cache_index, dev_cache_manager, DEV_WORKSPACE_ID, DEV_FLOW_SLUG)

        nodes = list_nodes(
            dev_client,
            dev_cache_index,
            dev_cache_manager,
            DEV_WORKSPACE_ID,
            DEV_FLOW_SLUG,
            version_name,
        )

        # Find a plain transform node (not a split branch/merge node)
        target = None
        for n in nodes:
            if n.type == "transform":
                node_detail = get_node(
                    dev_client,
                    dev_cache_index,
                    dev_cache_manager,
                    DEV_WORKSPACE_ID,
                    DEV_FLOW_SLUG,
                    version_name,
                    n.id,
                )
                if (
                    node_detail.meta
                    and not node_detail.meta.get("is_split_branch_node")
                    and not node_detail.meta.get("is_split_merge_node")
                ):
                    target = n
                    break
        assert target is not None, "No plain transform node found"

        # Update the source code
        new_src = f'data.modified_by_cli = "{datetime.now(UTC).isoformat()}"'
        updated = update_node(
            dev_client,
            dev_cache_index,
            dev_cache_manager,
            DEV_WORKSPACE_ID,
            DEV_FLOW_SLUG,
            version_name,
            target.id,
            meta={"src": new_src},
        )
        assert updated.meta is not None
        assert updated.meta.get("src") == new_src

        # Verify via fresh API read
        raw = get_version(dev_client, test_version["id"])
        assert raw is not None
        raw_nodes = raw["graph"]["nodes"]
        if isinstance(raw_nodes, list):
            raw_nodes = {n["id"]: n for n in raw_nodes}
        assert raw_nodes[target.id]["meta"]["src"] == new_src

    def test_update_input_schema(
        self,
        test_version: dict[str, Any],
        dev_client: TktlClient,
        dev_cache_index: CacheIndex,
        dev_cache_manager: CacheManager,
    ) -> None:
        """Set an input schema and verify via fresh API read."""
        version_name = test_version["name"]
        describe_flow(dev_client, dev_cache_index, dev_cache_manager, DEV_WORKSPACE_ID, DEV_FLOW_SLUG)

        new_schema = {
            "type": "object",
            "required": ["test_field"],
            "properties": {
                "test_field": {"type": "string"},
                "score": {"type": "number"},
            },
        }

        updated = update_version(
            dev_client,
            dev_cache_index,
            dev_cache_manager,
            DEV_WORKSPACE_ID,
            DEV_FLOW_SLUG,
            version_name,
            schema_in=new_schema,
        )
        assert updated.input_schema is not None

        raw = get_version(dev_client, test_version["id"])
        assert raw is not None
        api_schema = raw.get("input_schema", {})
        assert "test_field" in api_schema.get("properties", {})

    def test_update_preserves_other_nodes(
        self,
        test_version: dict[str, Any],
        dev_client: TktlClient,
        dev_cache_index: CacheIndex,
        dev_cache_manager: CacheManager,
    ) -> None:
        """Surgical update: changing one transform leaves all other nodes untouched."""
        version_name = test_version["name"]
        describe_flow(dev_client, dev_cache_index, dev_cache_manager, DEV_WORKSPACE_ID, DEV_FLOW_SLUG)

        # Snapshot before
        raw_before = get_version(dev_client, test_version["id"])
        assert raw_before is not None
        nodes_before = raw_before["graph"]["nodes"]
        if isinstance(nodes_before, list):
            nodes_before = {n["id"]: n for n in nodes_before}

        # Find a plain transform
        target_id = None
        for nid, n in nodes_before.items():
            if (
                n["type"] == "transform"
                and not (n.get("meta") or {}).get("is_split_branch_node")
                and not (n.get("meta") or {}).get("is_split_merge_node")
            ):
                target_id = nid
                break
        assert target_id is not None

        update_node(
            dev_client,
            dev_cache_index,
            dev_cache_manager,
            DEV_WORKSPACE_ID,
            DEV_FLOW_SLUG,
            version_name,
            target_id,
            meta={"src": "data.surgical_test = True"},
        )

        # Re-read
        raw_after = get_version(dev_client, test_version["id"])
        assert raw_after is not None
        nodes_after = raw_after["graph"]["nodes"]
        if isinstance(nodes_after, list):
            nodes_after = {n["id"]: n for n in nodes_after}

        # Target should be changed
        assert nodes_after[target_id]["meta"]["src"] == "data.surgical_test = True"

        # All other nodes should be identical
        for nid in nodes_before:
            if nid != target_id:
                assert nodes_after[nid]["meta"] == nodes_before[nid]["meta"], (
                    f"Node {nid} ({nodes_before[nid]['name']}) was modified unexpectedly"
                )

    def test_describe_version_after_update(
        self,
        test_version: dict[str, Any],
        dev_client: TktlClient,
        dev_cache_index: CacheIndex,
        dev_cache_manager: CacheManager,
    ) -> None:
        """After updating a node, describe_version returns the new etag."""
        version_name = test_version["name"]
        describe_flow(dev_client, dev_cache_index, dev_cache_manager, DEV_WORKSPACE_ID, DEV_FLOW_SLUG)

        before = describe_version(
            dev_client,
            dev_cache_index,
            dev_cache_manager,
            DEV_WORKSPACE_ID,
            DEV_FLOW_SLUG,
            version_name,
        )

        nodes = list_nodes(
            dev_client,
            dev_cache_index,
            dev_cache_manager,
            DEV_WORKSPACE_ID,
            DEV_FLOW_SLUG,
            version_name,
        )
        transform = next((n for n in nodes if n.type == "transform"), None)
        assert transform is not None

        update_node(
            dev_client,
            dev_cache_index,
            dev_cache_manager,
            DEV_WORKSPACE_ID,
            DEV_FLOW_SLUG,
            version_name,
            transform.id,
            meta={"src": "data.etag_test = 1"},
        )

        after = describe_version(
            dev_client,
            dev_cache_index,
            dev_cache_manager,
            DEV_WORKSPACE_ID,
            DEV_FLOW_SLUG,
            version_name,
        )
        # Etag should have changed
        assert after.etag != before.etag
