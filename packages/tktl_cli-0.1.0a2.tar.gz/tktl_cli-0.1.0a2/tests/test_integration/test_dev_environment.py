"""Integration tests against the real Taktile dev environment.

Run locally:
    1. Copy .env.example to .env and set TKTL_DEV_API_KEY
    2. uv run pytest tests/test_integration -v

Run in CI:
    Set TKTL_DEV_API_KEY as a GitHub Actions secret.
    uv run pytest tests/test_integration -v

These tests exercise the full stack against the real dev API.
The execution tests use the no-op flow which is safe to call repeatedly.
"""

from __future__ import annotations

import pytest

from tktl.api.client import TktlClient
from tktl.api.execution import _workspace_base_url_cache, _resolve_workspace_base_url, run_flow as api_run_flow
from tktl.api.flows import get_flow_by_slug, list_flows
from tktl.api.versions import get_version
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.models.flow import FlowDetail, FlowSummary
from tktl.models.node import NodeSummary
from tktl.ops.flows import describe_flow, run_flow
from tktl.ops.flows import list_flows as ops_list_flows
from tktl.ops.nodes import get_node, list_nodes
from tktl.ops.versions import describe_version, list_versions

from .conftest import DEV_FLOW_SLUG, DEV_VERSION_NAME, DEV_WORKSPACE_ID

pytestmark = pytest.mark.integration


# ---------------------------------------------------------------------------
# API Layer Tests
# ---------------------------------------------------------------------------


class TestApiLayer:
    """Low-level API client tests against the real dev environment."""

    def test_list_flows(self, dev_client: TktlClient):
        result = list_flows(dev_client, DEV_WORKSPACE_ID)
        assert isinstance(result, list)
        assert len(result) > 0
        assert all("slug" in f for f in result)
        assert all("id" in f for f in result)

    def test_get_flow_by_slug(self, dev_client: TktlClient):
        flow = get_flow_by_slug(dev_client, DEV_WORKSPACE_ID, DEV_FLOW_SLUG)
        assert flow["slug"] == DEV_FLOW_SLUG
        assert "versions" in flow
        assert len(flow["versions"]) > 0
        # Each version should have id, name, status
        for v in flow["versions"]:
            assert "id" in v
            assert "name" in v
            assert "status" in v

    def test_get_version_v2(self, dev_client: TktlClient):
        flow = get_flow_by_slug(dev_client, DEV_WORKSPACE_ID, DEV_FLOW_SLUG)
        version_id = None
        for v in flow["versions"]:
            if v["name"] == DEV_VERSION_NAME:
                version_id = v["id"]
                break
        assert version_id is not None, f"Version '{DEV_VERSION_NAME}' not found"

        version = get_version(dev_client, version_id)
        assert version is not None
        assert version["name"] == DEV_VERSION_NAME
        assert "graph" in version
        assert "nodes" in version["graph"]
        assert isinstance(version["graph"]["nodes"], dict)
        assert "etag" in version

    def test_get_version_has_dict_keyed_nodes(self, dev_client: TktlClient):
        """Verify the v2 API returns nodes as a dict keyed by node ID."""
        flow = get_flow_by_slug(dev_client, DEV_WORKSPACE_ID, DEV_FLOW_SLUG)
        vid = next(v["id"] for v in flow["versions"] if v["name"] == DEV_VERSION_NAME)
        version = get_version(dev_client, vid)
        assert version is not None
        nodes = version["graph"]["nodes"]
        for node_id, node in nodes.items():
            assert node_id == node["id"]
            assert "name" in node
            assert "type" in node


# ---------------------------------------------------------------------------
# Workspace & Execution API Tests
# ---------------------------------------------------------------------------


class TestWorkspaceResolution:
    """Test workspace base_url resolution for the Decide API."""

    def setup_method(self):
        _workspace_base_url_cache.clear()

    def test_resolve_workspace_base_url(self, dev_client: TktlClient):
        base_url = _resolve_workspace_base_url(dev_client, DEV_WORKSPACE_ID)
        assert base_url.startswith("https://")
        assert "decide" in base_url or "taktile" in base_url

    def test_workspace_base_url_is_cached(self, dev_client: TktlClient):
        url1 = _resolve_workspace_base_url(dev_client, DEV_WORKSPACE_ID)
        url2 = _resolve_workspace_base_url(dev_client, DEV_WORKSPACE_ID)
        assert url1 == url2
        assert DEV_WORKSPACE_ID in _workspace_base_url_cache


class TestFlowExecution:
    """Test flow execution via the Decide API (no-op flow, safe to call)."""

    def setup_method(self):
        _workspace_base_url_cache.clear()

    def test_execute_sandbox(self, dev_client: TktlClient):
        """Execute the no-op flow in sandbox mode."""
        result = api_run_flow(
            dev_client,
            DEV_WORKSPACE_ID,
            DEV_FLOW_SLUG,
            input_data={},
            version="v1.0",
            env="sandbox",
        )
        assert result["status"] == "success"
        assert result["metadata"]["environment"] == "sandbox"
        assert "decision_id" in result["metadata"]

    def test_execute_returns_data(self, dev_client: TktlClient):
        """The response should contain data, status, and metadata."""
        result = api_run_flow(dev_client, DEV_WORKSPACE_ID, DEV_FLOW_SLUG, {}, version="v1.0", env="sandbox")
        assert "data" in result
        assert "status" in result
        assert "metadata" in result
        assert result["metadata"]["version"] == "v1.0"

    def test_execute_via_ops_layer(
        self,
        dev_client: TktlClient,
    ):
        """Test execution through the ops layer."""
        result = run_flow(dev_client, DEV_WORKSPACE_ID, DEV_FLOW_SLUG, {}, version="v1.0", env="sandbox")
        assert result["status"] == "success"


# ---------------------------------------------------------------------------
# Ops Layer Tests
# ---------------------------------------------------------------------------


class TestOpsLayer:
    """Ops layer tests — full stack through cache and resolution."""

    def test_list_flows(self, dev_client: TktlClient, dev_cache_manager: CacheManager):
        result = ops_list_flows(dev_client, dev_cache_manager, DEV_WORKSPACE_ID)
        assert isinstance(result, list)
        assert len(result) > 0
        assert all(isinstance(f, FlowSummary) for f in result)
        slugs = {f.slug for f in result}
        assert DEV_FLOW_SLUG in slugs

    def test_describe_flow(self, dev_client: TktlClient, dev_cache_index: CacheIndex, dev_cache_manager: CacheManager):
        result = describe_flow(dev_client, dev_cache_index, dev_cache_manager, DEV_WORKSPACE_ID, DEV_FLOW_SLUG)
        assert isinstance(result, FlowDetail)
        assert result.slug == DEV_FLOW_SLUG

    def test_list_versions(self, dev_client: TktlClient, dev_cache_index: CacheIndex, dev_cache_manager: CacheManager):
        describe_flow(dev_client, dev_cache_index, dev_cache_manager, DEV_WORKSPACE_ID, DEV_FLOW_SLUG)
        result = list_versions(dev_client, dev_cache_index, dev_cache_manager, DEV_WORKSPACE_ID, DEV_FLOW_SLUG)
        assert len(result) > 0
        names = {v.name for v in result}
        assert DEV_VERSION_NAME in names

    def test_describe_version(
        self, dev_client: TktlClient, dev_cache_index: CacheIndex, dev_cache_manager: CacheManager
    ):
        describe_flow(dev_client, dev_cache_index, dev_cache_manager, DEV_WORKSPACE_ID, DEV_FLOW_SLUG)
        result = describe_version(
            dev_client, dev_cache_index, dev_cache_manager, DEV_WORKSPACE_ID, DEV_FLOW_SLUG, DEV_VERSION_NAME
        )
        assert result.name == DEV_VERSION_NAME
        assert result.etag is not None

    def test_list_nodes(self, dev_client: TktlClient, dev_cache_index: CacheIndex, dev_cache_manager: CacheManager):
        describe_flow(dev_client, dev_cache_index, dev_cache_manager, DEV_WORKSPACE_ID, DEV_FLOW_SLUG)
        nodes = list_nodes(
            dev_client, dev_cache_index, dev_cache_manager, DEV_WORKSPACE_ID, DEV_FLOW_SLUG, DEV_VERSION_NAME
        )
        assert len(nodes) > 0
        assert all(isinstance(n, NodeSummary) for n in nodes)
        for n in nodes:
            assert n.id
            assert n.name
            assert n.type

    def test_get_node(self, dev_client: TktlClient, dev_cache_index: CacheIndex, dev_cache_manager: CacheManager):
        describe_flow(dev_client, dev_cache_index, dev_cache_manager, DEV_WORKSPACE_ID, DEV_FLOW_SLUG)
        nodes = list_nodes(
            dev_client, dev_cache_index, dev_cache_manager, DEV_WORKSPACE_ID, DEV_FLOW_SLUG, DEV_VERSION_NAME
        )
        node = get_node(
            dev_client,
            dev_cache_index,
            dev_cache_manager,
            DEV_WORKSPACE_ID,
            DEV_FLOW_SLUG,
            DEV_VERSION_NAME,
            nodes[0].id,
        )
        assert node.id == nodes[0].id

    def test_get_node_section_meta(
        self, dev_client: TktlClient, dev_cache_index: CacheIndex, dev_cache_manager: CacheManager
    ):
        """Test the --section flag equivalent at the ops layer."""
        describe_flow(dev_client, dev_cache_index, dev_cache_manager, DEV_WORKSPACE_ID, DEV_FLOW_SLUG)
        nodes = list_nodes(
            dev_client, dev_cache_index, dev_cache_manager, DEV_WORKSPACE_ID, DEV_FLOW_SLUG, DEV_VERSION_NAME
        )
        node = get_node(
            dev_client,
            dev_cache_index,
            dev_cache_manager,
            DEV_WORKSPACE_ID,
            DEV_FLOW_SLUG,
            DEV_VERSION_NAME,
            nodes[0].id,
            section="meta",
        )
        assert node.id == nodes[0].id

    def test_cache_is_populated(
        self, dev_client: TktlClient, dev_cache_index: CacheIndex, dev_cache_manager: CacheManager
    ):
        """After describe_version, the cache should have per-node files."""
        describe_flow(dev_client, dev_cache_index, dev_cache_manager, DEV_WORKSPACE_ID, DEV_FLOW_SLUG)
        describe_version(
            dev_client, dev_cache_index, dev_cache_manager, DEV_WORKSPACE_ID, DEV_FLOW_SLUG, DEV_VERSION_NAME
        )

        flow_id = dev_cache_index.resolve_flow_id(DEV_FLOW_SLUG)
        version_id = dev_cache_index.resolve_version_id(DEV_FLOW_SLUG, DEV_VERSION_NAME)
        assert flow_id is not None
        assert version_id is not None

        node_index = dev_cache_manager.read_node_index(version_id, flow_id)
        assert node_index is not None
        assert len(node_index) > 0

        for entry in node_index:
            cached = dev_cache_manager.read_node(version_id, flow_id, entry["id"])
            assert cached is not None

    def test_second_read_hits_cache(
        self, dev_client: TktlClient, dev_cache_index: CacheIndex, dev_cache_manager: CacheManager
    ):
        """After first describe, a second list_nodes should read from cache."""
        describe_flow(dev_client, dev_cache_index, dev_cache_manager, DEV_WORKSPACE_ID, DEV_FLOW_SLUG)
        describe_version(
            dev_client, dev_cache_index, dev_cache_manager, DEV_WORKSPACE_ID, DEV_FLOW_SLUG, DEV_VERSION_NAME
        )

        # Second call should be fast (from cache)
        nodes = list_nodes(
            dev_client, dev_cache_index, dev_cache_manager, DEV_WORKSPACE_ID, DEV_FLOW_SLUG, DEV_VERSION_NAME
        )
        assert len(nodes) > 0
