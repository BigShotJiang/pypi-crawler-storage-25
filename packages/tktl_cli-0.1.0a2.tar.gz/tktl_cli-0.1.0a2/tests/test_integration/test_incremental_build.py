"""Integration test: build a flow graph incrementally and execute it.

Replicates the graph from tests/fake_api/data/simple.json step by step:
1. Duplicate v1.0 (minimal input→output)
2. Set parameters (z=100)
3. Add assignment_node (x=1, y=2, z=params.z)
4. Add rule_2 node with Rule 1 (data.x==1 → a="A", b="B")
5. Add Rule 2 branch to the rule (data.z==100 → a="AA", b="BB")
6. Execute and verify output matches expected values

Each step is a separate PATCH, proving the CLI can build graphs incrementally.
"""

from __future__ import annotations

import copy
import time
import uuid
from datetime import UTC, datetime
from typing import Any

import pytest

from tktl.api.client import TktlClient
from tktl.api.execution import _workspace_base_url_cache, run_flow as api_run_flow
from tktl.api.versions import delete_version, get_version, patch_version

from .conftest import DEV_FLOW_SLUG, DEV_WORKSPACE_ID

pytestmark = pytest.mark.integration


@pytest.fixture
def incremental_flow(dev_client: TktlClient) -> Any:
    """Build the simple.json graph incrementally via successive PATCHes."""
    _workspace_base_url_cache.clear()

    ts = datetime.now(UTC).strftime("%Y%m%d-%H%M%S")
    version_name = f"cli-incr-{ts}"
    user_id = dev_client._user_id or "cli-test"
    session = str(uuid.uuid4())

    # Duplicate v1.0 (input → output)
    resp = dev_client.post(
        "/api/v1/flow_versions/1d18a37b-c33e-4ba6-b78c-6019b142e143/duplicate",
        json={"name": version_name, "meta": {"created_by_id": user_id}},
    )
    assert resp.status_code in (200, 201)
    version_id = resp.json()["id"]
    time.sleep(2)

    raw = get_version(dev_client, version_id)
    assert raw is not None
    nodes = raw["graph"]["nodes"]
    assert isinstance(nodes, dict)
    etag = raw["etag"]

    input_id = next(nid for nid, n in nodes.items() if n["type"] == "input")
    output_id = next(nid for nid, n in nodes.items() if n["type"] == "output")
    old_edge_id = next(iter(raw["graph"]["edges"].keys()))

    # ------------------------------------------------------------------
    # Step 1: Add assignment_node + set params
    # Graph: input → assignment → output
    # ------------------------------------------------------------------
    assign_id = str(uuid.uuid4())
    all_nodes = copy.deepcopy(nodes)
    all_nodes[assign_id] = {
        "name": "Multiple fields",
        "type": "assignment_node",
        "meta": {
            "created_by_id": user_id,
            "updated_by_id": user_id,
            "default_effects": [
                {"id": str(uuid.uuid4()), "target": "x", "value": "1"},
                {"id": str(uuid.uuid4()), "target": "y", "value": "2"},
                {"id": str(uuid.uuid4()), "target": "z", "value": "params.z"},
            ],
        },
    }
    all_nodes[output_id]["meta"]["src"] = "data"

    e1, e2 = str(uuid.uuid4()), str(uuid.uuid4())
    result1 = patch_version(
        dev_client,
        version_id,
        {
            "graph": {
                "nodes": all_nodes,
                "edges": {
                    old_edge_id: None,
                    e1: {"start_node_id": input_id, "end_node_id": assign_id, "meta": {"is_split_edge": False}},
                    e2: {"start_node_id": assign_id, "end_node_id": output_id, "meta": {"is_split_edge": False}},
                },
            },
            "parameters": [{"name": "z", "value": 100, "expr": "100", "description": ""}],
        },
        if_match=etag,
        session=session,
    )
    # Use the response from step 1 to get the latest state (avoids etag races)
    r1_nodes = result1["graph"]["nodes"]
    if isinstance(r1_nodes, list):
        r1_nodes = {nd["id"]: nd for nd in r1_nodes}
    r1_edges = result1["graph"]["edges"]
    if isinstance(r1_edges, list):
        r1_edges = {ed["id"]: ed for ed in r1_edges}
    etag = result1["etag"]

    # ------------------------------------------------------------------
    # Step 2: Add rule_2 with Rule 1 between assignment and output
    # Graph: input → assignment → rule → output
    # ------------------------------------------------------------------
    time.sleep(2)
    nodes2 = copy.deepcopy(r1_nodes)
    edges2 = r1_edges
    assign_out_edge = next(eid for eid, e in edges2.items() if e["end_node_id"] == output_id)

    rule_id = str(uuid.uuid4())
    nodes2[rule_id] = {
        "name": "Cases",
        "type": "rule_2",
        "meta": {
            "created_by_id": user_id,
            "updated_by_id": user_id,
            "default_effects": [
                {"id": str(uuid.uuid4()), "target": "a", "value": '"_A_"'},
                {"id": str(uuid.uuid4()), "target": "b", "value": '"_B_"'},
            ],
            "branches": [
                {
                    "id": str(uuid.uuid4()),
                    "name": "Rule 1",
                    "junction": "and",
                    "clauses": [
                        {
                            "id_left": str(uuid.uuid4()),
                            "id_right": str(uuid.uuid4()),
                            "left": "data.x",
                            "right": "1",
                            "operator": "eq",
                        }
                    ],
                    "effects": [
                        {"id": str(uuid.uuid4()), "target": "a", "value": '"A"'},
                        {"id": str(uuid.uuid4()), "target": "b", "value": '"B"'},
                    ],
                }
            ],
        },
    }

    e3, e4 = str(uuid.uuid4()), str(uuid.uuid4())
    result2 = patch_version(
        dev_client,
        version_id,
        {
            "graph": {
                "nodes": nodes2,
                "edges": {
                    assign_out_edge: None,
                    e3: {"start_node_id": assign_id, "end_node_id": rule_id, "meta": {"is_split_edge": False}},
                    e4: {"start_node_id": rule_id, "end_node_id": output_id, "meta": {"is_split_edge": False}},
                },
            },
        },
        if_match=etag,
        session=session,
    )
    r2_nodes = result2["graph"]["nodes"]
    if isinstance(r2_nodes, list):
        r2_nodes = {nd["id"]: nd for nd in r2_nodes}
    etag = result2["etag"]

    # ------------------------------------------------------------------
    # Step 3: Add Rule 2 branch to the rule node
    # ------------------------------------------------------------------
    time.sleep(1)
    rule_node = copy.deepcopy(r2_nodes[rule_id])
    rule_node["meta"]["branches"].append(
        {
            "id": str(uuid.uuid4()),
            "name": "Rule 2",
            "junction": "and",
            "clauses": [
                {
                    "id_left": str(uuid.uuid4()),
                    "id_right": str(uuid.uuid4()),
                    "left": "data.z",
                    "right": "100",
                    "operator": "eq",
                }
            ],
            "effects": [
                {"id": str(uuid.uuid4()), "target": "a", "value": '"AA"'},
                {"id": str(uuid.uuid4()), "target": "b", "value": '"BB"'},
            ],
        }
    )
    result3 = patch_version(
        dev_client,
        version_id,
        {"graph": {"nodes": {rule_id: rule_node}}},
        if_match=etag,
        session=session,
    )
    r3_nodes = result3["graph"]["nodes"]
    if isinstance(r3_nodes, list):
        r3_nodes = {nd["id"]: nd for nd in r3_nodes}
    r3_edges = result3["graph"]["edges"]
    if isinstance(r3_edges, list):
        r3_edges = {ed["id"]: ed for ed in r3_edges}
    etag = result3["etag"]

    # ------------------------------------------------------------------
    # Step 4: Add split_2 with branch nodes between rule and output
    # Graph: input → assign → rule → split → [branch1 / branch2] → merge → output
    # ------------------------------------------------------------------
    time.sleep(1)
    nodes4 = copy.deepcopy(r3_nodes)

    # Find edge from rule -> output
    rule_out_edge = next(
        eid for eid, e in r3_edges.items() if e["start_node_id"] == rule_id and e["end_node_id"] == output_id
    )

    split_id = str(uuid.uuid4())
    branch1_id = str(uuid.uuid4())  # "Z equals 100"
    branch2_id = str(uuid.uuid4())  # "Default Branch"
    merge_id = str(uuid.uuid4())

    e_rule_split = str(uuid.uuid4())
    e_split_b1 = str(uuid.uuid4())  # split edge
    e_split_b2 = str(uuid.uuid4())  # split edge (default)
    e_b1_merge = str(uuid.uuid4())
    e_b2_merge = str(uuid.uuid4())
    e_merge_out = str(uuid.uuid4())

    nodes4[split_id] = {
        "name": "Untitled Node",
        "type": "split_2",
        "meta": {
            "created_by_id": user_id,
            "updated_by_id": user_id,
            "branches": [
                {
                    "junction": "and",
                    "id": str(uuid.uuid4()),
                    "edge_id": e_split_b1,
                    "clauses": [
                        {
                            "id_left": str(uuid.uuid4()),
                            "id_right": str(uuid.uuid4()),
                            "left": "data.z",
                            "right": "100",
                            "operator": "eq",
                        }
                    ],
                },
                {
                    "junction": "and",
                    "id": str(uuid.uuid4()),
                    "edge_id": e_split_b2,
                    "clauses": [],
                },
            ],
            "default_edge_id": e_split_b2,
        },
    }
    nodes4[branch1_id] = {
        "name": "Z equals 100",
        "type": "transform",
        "meta": {"created_by_id": user_id, "updated_by_id": user_id, "src": "", "is_split_branch_node": True},
    }
    nodes4[branch2_id] = {
        "name": "Default Branch",
        "type": "transform",
        "meta": {"created_by_id": user_id, "updated_by_id": user_id, "src": "", "is_split_branch_node": True},
    }
    nodes4[merge_id] = {
        "name": "Merge Node",
        "type": "transform",
        "meta": {"created_by_id": user_id, "updated_by_id": user_id, "src": "", "is_split_merge_node": True},
    }

    patch_version(
        dev_client,
        version_id,
        {
            "graph": {
                "nodes": nodes4,
                "edges": {
                    rule_out_edge: None,
                    e_rule_split: {"start_node_id": rule_id, "end_node_id": split_id, "meta": {"is_split_edge": False}},
                    e_split_b1: {"start_node_id": split_id, "end_node_id": branch1_id, "meta": {"is_split_edge": True}},
                    e_split_b2: {"start_node_id": split_id, "end_node_id": branch2_id, "meta": {"is_split_edge": True}},
                    e_b1_merge: {
                        "start_node_id": branch1_id,
                        "end_node_id": merge_id,
                        "meta": {"is_split_edge": False},
                    },
                    e_b2_merge: {
                        "start_node_id": branch2_id,
                        "end_node_id": merge_id,
                        "meta": {"is_split_edge": False},
                    },
                    e_merge_out: {
                        "start_node_id": merge_id,
                        "end_node_id": output_id,
                        "meta": {"is_split_edge": False},
                    },
                },
            },
        },
        if_match=etag,
        session=session,
    )

    yield {
        "version_name": version_name,
        "version_id": version_id,
        "assign_id": assign_id,
        "rule_id": rule_id,
        "split_id": split_id,
        "branch1_id": branch1_id,
        "branch2_id": branch2_id,
        "merge_id": merge_id,
    }

    try:
        delete_version(dev_client, version_id)
    except Exception:
        pass


class TestIncrementalBuild:
    """Verify the incrementally-built graph matches simple.json semantics."""

    def _nodes(self, incremental_flow: dict[str, Any], dev_client: TktlClient) -> dict[str, Any]:
        raw = get_version(dev_client, incremental_flow["version_id"])
        assert raw is not None
        nodes = raw["graph"]["nodes"]
        if isinstance(nodes, list):
            return {n["id"]: n for n in nodes}
        return nodes

    def test_has_all_8_nodes(self, incremental_flow: dict[str, Any], dev_client: TktlClient) -> None:
        """The full graph should have 8 nodes matching simple.json."""
        nodes = self._nodes(incremental_flow, dev_client)
        assert len(nodes) == 8
        types = {n["type"] for n in nodes.values()}
        assert types == {"input", "output", "assignment_node", "rule_2", "split_2", "transform"}

    def test_has_split_with_two_branches(self, incremental_flow: dict[str, Any], dev_client: TktlClient) -> None:
        nodes = self._nodes(incremental_flow, dev_client)
        split = nodes[incremental_flow["split_id"]]
        assert split["type"] == "split_2"
        assert len(split["meta"]["branches"]) == 2
        # First branch checks z==100
        assert split["meta"]["branches"][0]["clauses"][0]["left"] == "data.z"
        assert split["meta"]["branches"][0]["clauses"][0]["right"] == "100"
        # Second branch is the default (no clauses)
        assert split["meta"]["branches"][1]["clauses"] == []

    def test_has_branch_and_merge_transforms(self, incremental_flow: dict[str, Any], dev_client: TktlClient) -> None:
        nodes = self._nodes(incremental_flow, dev_client)
        branch1 = nodes[incremental_flow["branch1_id"]]
        branch2 = nodes[incremental_flow["branch2_id"]]
        merge = nodes[incremental_flow["merge_id"]]
        assert branch1["name"] == "Z equals 100"
        assert branch1["meta"]["is_split_branch_node"] is True
        assert branch2["name"] == "Default Branch"
        assert branch2["meta"]["is_split_branch_node"] is True
        assert merge["name"] == "Merge Node"
        assert merge["meta"]["is_split_merge_node"] is True

    def test_assignment_has_three_effects(self, incremental_flow: dict[str, Any], dev_client: TktlClient) -> None:
        nodes = self._nodes(incremental_flow, dev_client)
        assign = nodes[incremental_flow["assign_id"]]
        targets = {e["target"] for e in assign["meta"]["default_effects"]}
        assert targets == {"x", "y", "z"}

    def test_rule_has_two_branches(self, incremental_flow: dict[str, Any], dev_client: TktlClient) -> None:
        nodes = self._nodes(incremental_flow, dev_client)
        rule = nodes[incremental_flow["rule_id"]]
        assert len(rule["meta"]["branches"]) == 2
        assert rule["meta"]["branches"][0]["name"] == "Rule 1"
        assert rule["meta"]["branches"][1]["name"] == "Rule 2"

    def test_has_parameter_z(self, incremental_flow: dict[str, Any], dev_client: TktlClient) -> None:
        raw = get_version(dev_client, incremental_flow["version_id"])
        assert raw is not None
        assert any(p["name"] == "z" and p["value"] == 100 for p in raw.get("parameters", []))

    def test_execute_with_default_input(self, incremental_flow: dict[str, Any], dev_client: TktlClient) -> None:
        """Empty input: assignment sets x=1,y=2,z=100. Rule 1 matches (x==1). Split takes z==100 branch."""
        result = api_run_flow(
            dev_client,
            DEV_WORKSPACE_ID,
            DEV_FLOW_SLUG,
            input_data={},
            version=incremental_flow["version_name"],
            env="sandbox",
        )
        assert result["status"] == "success"
        data = result["data"]
        assert data["x"] == 1
        assert data["y"] == 2
        assert data["z"] == 100
        assert data["a"] == "A"
        assert data["b"] == "B"
