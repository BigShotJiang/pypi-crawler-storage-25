"""Integration test: full graph lifecycle — build, modify, execute, remove nodes in a loop.

Tests the complete workflow of programmatically building a decision flow
with transforms and split nodes, modifying it, running batches, and tearing
it down — all via the CLI's library API.

Uses the no-op-2 flow on the dev environment.
"""

from __future__ import annotations

import copy
import json
import time
import uuid
from pathlib import Path
from typing import Any

import pytest

from tktl.api.client import TktlClient
from tktl.api.execution import _workspace_base_url_cache
from tktl.api.versions import delete_version, get_version, patch_version
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.ops.batch import run_batch
from tktl.ops.flows import run_flow
from tktl.ops.versions import duplicate_version

from .conftest import DEV_FLOW_SLUG, DEV_WORKSPACE_ID

pytestmark = pytest.mark.integration

SOURCE_VERSION = "v1.0"


def _uid() -> str:
    return str(uuid.uuid4())


def _nmeta(user_id: str, src: str = "") -> dict[str, Any]:
    return {"created_by_id": user_id, "updated_by_id": user_id, "src": src}


@pytest.fixture
def lifecycle_version(
    dev_client: TktlClient,
    dev_cache_index: CacheIndex,
    dev_cache_manager: CacheManager,
) -> Any:
    """Create a disposable version for lifecycle testing. Cleaned up after test."""
    _workspace_base_url_cache.clear()
    ts = int(time.time())
    name = f"cli-lifecycle-{ts}"

    version = duplicate_version(
        dev_client,
        dev_cache_index,
        dev_cache_manager,
        DEV_WORKSPACE_ID,
        DEV_FLOW_SLUG,
        SOURCE_VERSION,
        name,
    )
    version_id = version.id
    time.sleep(2)

    yield {
        "client": dev_client,
        "version_id": version_id,
        "version_name": name,
        "user_id": dev_client._user_id or "cli-test",
        "cache_index": dev_cache_index,
        "cache_manager": dev_cache_manager,
    }

    # Cleanup
    try:
        delete_version(dev_client, version_id)
    except Exception:
        pass


class TestGraphLifecycle:
    """Full lifecycle: build → execute → modify → execute → add split → execute → remove → execute."""

    def test_full_lifecycle(self, lifecycle_version, tmp_path: Path):
        ctx = lifecycle_version
        client = ctx["client"]
        vid = ctx["version_id"]
        user_id = ctx["user_id"]
        version_name = ctx["version_name"]

        # -- Phase 1: Read the bare graph (input → output) --
        raw = get_version(client, vid)
        assert raw is not None
        etag = raw["etag"]
        nodes = raw["graph"]["nodes"]
        edges = raw["graph"]["edges"]

        input_id = next(nid for nid, n in nodes.items() if n["type"] == "input")
        output_id = next(nid for nid, n in nodes.items() if n["type"] == "output")
        old_edge = next(iter(edges.keys()))

        assert len(nodes) == 2, f"Expected 2 nodes, got {len(nodes)}"

        # -- Phase 2: Add a transform node --
        transform_id = _uid()
        e1, e2 = _uid(), _uid()

        all_nodes = copy.deepcopy(nodes)
        all_nodes[transform_id] = {
            "name": "Score Calculator",
            "type": "transform",
            "meta": _nmeta(user_id, 'data.score = float(data.get("x", 0)) * 10'),
        }
        all_nodes[output_id]["meta"]["src"] = "data"

        r = patch_version(
            client,
            vid,
            {
                "graph": {
                    "nodes": all_nodes,
                    "edges": {
                        old_edge: None,
                        e1: {"start_node_id": input_id, "end_node_id": transform_id, "meta": {"is_split_edge": False}},
                        e2: {"start_node_id": transform_id, "end_node_id": output_id, "meta": {"is_split_edge": False}},
                    },
                },
                "input_schema": {
                    "type": "object",
                    "properties": {"x": {"type": "number"}},
                    "$schema": "https://json-schema.org/draft/2020-12/schema",
                },
                "output_schema": {
                    "type": "object",
                    "properties": {"score": {"type": "number"}, "decision": {"type": "string"}},
                    "$schema": "https://json-schema.org/draft/2020-12/schema",
                },
            },
            if_match=etag,
            session=_uid(),
        )
        etag = r["etag"]

        # Verify: execute single decision
        result = run_flow(client, DEV_WORKSPACE_ID, DEV_FLOW_SLUG, {"x": 5}, version=version_name)
        assert result["data"]["score"] == 50

        # -- Phase 3: Execute a batch --
        batch_file = tmp_path / "batch1.json"
        batch_file.write_text(json.dumps([{"x": i} for i in range(10)]))
        runs_dir = tmp_path / "runs"

        batch_result = run_batch(
            client,
            DEV_WORKSPACE_ID,
            DEV_FLOW_SLUG,
            file_path=batch_file,
            version=version_name,
            concurrency=5,
            runs_dir=runs_dir,
        )
        assert batch_result.meta.total_rows == 10
        assert batch_result.meta.succeeded == 10
        assert batch_result.meta.failed == 0

        # Verify results
        results_lines = Path(batch_result.results_path).read_text().strip().splitlines()
        assert len(results_lines) == 10
        scores = []
        for line in results_lines:
            r = json.loads(line)
            s = r["output"].get("data", {}).get("score")
            if s is not None:
                scores.append(s)
        assert len(scores) == 10
        assert 0.0 in scores  # x=0 → score=0
        assert 90.0 in scores  # x=9 → score=90

        # -- Phase 4: Modify the transform --
        time.sleep(1)
        raw2 = get_version(client, vid)
        assert raw2 is not None
        etag = raw2["etag"]
        nodes2 = raw2["graph"]["nodes"]

        mod_node = copy.deepcopy(nodes2[transform_id])
        mod_node["meta"]["src"] = 'data.score = float(data.get("x", 0)) * 100'

        r2 = patch_version(
            client,
            vid,
            {
                "graph": {"nodes": {transform_id: mod_node}},
            },
            if_match=etag,
            session=_uid(),
        )
        etag = r2["etag"]

        # Verify the modification (allow propagation delay)
        time.sleep(3)
        result2 = run_flow(client, DEV_WORKSPACE_ID, DEV_FLOW_SLUG, {"x": 5}, version=version_name)
        assert result2["data"]["score"] == 500  # was 50, now 500

        # -- Phase 5: Add a split node from scratch --
        time.sleep(1)
        raw3 = get_version(client, vid)
        assert raw3 is not None
        etag = raw3["etag"]
        scorer_out = next(eid for eid, e in raw3["graph"]["edges"].items() if e["end_node_id"] == output_id)

        split_id = _uid()
        branch_a, branch_b, merge_id = _uid(), _uid(), _uid()
        e_split_a, e_split_b = _uid(), _uid()

        r3 = patch_version(
            client,
            vid,
            {
                "graph": {
                    "nodes": {
                        split_id: {
                            "name": "Score Gate",
                            "type": "split_2",
                            "meta": {
                                "branches": [
                                    {
                                        "id": _uid(),
                                        "junction": "and",
                                        "edge_id": e_split_a,
                                        "clauses": [
                                            {
                                                "id_left": _uid(),
                                                "id_right": _uid(),
                                                "left": "data.score",
                                                "right": "500",
                                                "operator": "lt",
                                            }
                                        ],
                                    },
                                    {"id": _uid(), "junction": "and", "edge_id": e_split_b, "clauses": []},
                                ],
                                "default_edge_id": e_split_b,
                            },
                        },
                        branch_a: {
                            "name": "Low Score",
                            "type": "transform",
                            "meta": {"src": 'data.decision = "LOW"', "is_split_branch_node": True},
                        },
                        branch_b: {
                            "name": "High Score",
                            "type": "transform",
                            "meta": {"src": 'data.decision = "HIGH"', "is_split_branch_node": True},
                        },
                        merge_id: {
                            "name": "Merge",
                            "type": "transform",
                            "meta": {"src": "", "is_split_merge_node": True},
                        },
                    },
                    "edges": {
                        scorer_out: None,
                        _uid(): {
                            "start_node_id": transform_id,
                            "end_node_id": split_id,
                            "meta": {"is_split_edge": False},
                        },
                        e_split_a: {
                            "start_node_id": split_id,
                            "end_node_id": branch_a,
                            "meta": {"is_split_edge": True},
                        },
                        e_split_b: {
                            "start_node_id": split_id,
                            "end_node_id": branch_b,
                            "meta": {"is_split_edge": True},
                        },
                        _uid(): {"start_node_id": branch_a, "end_node_id": merge_id, "meta": {"is_split_edge": False}},
                        _uid(): {"start_node_id": branch_b, "end_node_id": merge_id, "meta": {"is_split_edge": False}},
                        _uid(): {"start_node_id": merge_id, "end_node_id": output_id, "meta": {"is_split_edge": False}},
                    },
                },
            },
            if_match=etag,
            session=_uid(),
        )
        etag = r3["etag"]

        # Verify split routing (allow propagation delay)
        time.sleep(3)
        low = run_flow(client, DEV_WORKSPACE_ID, DEV_FLOW_SLUG, {"x": 3}, version=version_name)
        assert low["data"]["decision"] == "LOW"  # 3*100=300 < 500
        assert low["data"]["score"] == 300

        high = run_flow(client, DEV_WORKSPACE_ID, DEV_FLOW_SLUG, {"x": 7}, version=version_name)
        assert high["data"]["decision"] == "HIGH"  # 7*100=700 >= 500
        assert high["data"]["score"] == 700

        # -- Phase 6: Batch with split --
        batch_result2 = run_batch(
            client,
            DEV_WORKSPACE_ID,
            DEV_FLOW_SLUG,
            file_path=batch_file,
            version=version_name,
            concurrency=5,
            runs_dir=runs_dir,
        )
        assert batch_result2.meta.total_rows == 10
        assert batch_result2.meta.succeeded == 10

        results2 = [json.loads(line) for line in Path(batch_result2.results_path).read_text().strip().splitlines()]
        decisions = {}
        for r in results2:
            d = r["output"].get("data", {})
            if "decision" in d:
                decisions[r["input"]["x"]] = d["decision"]

        # x < 5 → score < 500 → LOW, x >= 5 → score >= 500 → HIGH
        for x in range(5):
            assert decisions.get(x) == "LOW", f"x={x} should be LOW, got {decisions.get(x)}"
        for x in range(5, 10):
            assert decisions.get(x) == "HIGH", f"x={x} should be HIGH, got {decisions.get(x)}"

        # -- Phase 7: Modify split threshold --
        time.sleep(1)
        raw4 = get_version(client, vid)
        assert raw4 is not None
        etag = raw4["etag"]
        split_node = copy.deepcopy(raw4["graph"]["nodes"][split_id])
        split_node["meta"]["branches"][0]["clauses"][0]["right"] = "300"

        r4 = patch_version(
            client,
            vid,
            {
                "graph": {"nodes": {split_id: split_node}},
            },
            if_match=etag,
            session=_uid(),
        )
        etag = r4["etag"]

        # Verify threshold change (allow propagation delay)
        time.sleep(3)
        now_high = run_flow(client, DEV_WORKSPACE_ID, DEV_FLOW_SLUG, {"x": 4}, version=version_name)
        assert now_high["data"]["decision"] == "HIGH"  # 4*100=400 >= 300 (was LOW at 500 threshold)

        still_low = run_flow(client, DEV_WORKSPACE_ID, DEV_FLOW_SLUG, {"x": 2}, version=version_name)
        assert still_low["data"]["decision"] == "LOW"  # 2*100=200 < 300

        # -- Phase 8: Remove split, go back to simple transform → output --
        time.sleep(1)
        raw5 = get_version(client, vid)
        assert raw5 is not None
        etag = raw5["etag"]
        nodes5 = raw5["graph"]["nodes"]
        edges5 = raw5["graph"]["edges"]

        # Keep only input, transform, output — null out removed nodes
        keep = {input_id, transform_id, output_id}
        cleaned_nodes: dict[str, Any] = {}
        for nid, n in nodes5.items():
            if nid in keep:
                cleaned_nodes[nid] = copy.deepcopy(n)
            else:
                cleaned_nodes[nid] = None  # explicitly delete via merge-patch

        # Delete ALL existing edges, create new simple chain
        new_edges: dict[str, Any] = {}
        for eid in edges5:
            new_edges[eid] = None

        e_new1 = _uid()
        e_new2 = _uid()
        new_edges[e_new1] = {"start_node_id": input_id, "end_node_id": transform_id, "meta": {"is_split_edge": False}}
        new_edges[e_new2] = {"start_node_id": transform_id, "end_node_id": output_id, "meta": {"is_split_edge": False}}

        r5 = patch_version(
            client,
            vid,
            {
                "graph": {"nodes": cleaned_nodes, "edges": new_edges},
            },
            if_match=etag,
            session=_uid(),
        )
        etag = r5["etag"]

        # Verify: split is gone, just score returned (no decision field)
        time.sleep(3)
        simple = run_flow(client, DEV_WORKSPACE_ID, DEV_FLOW_SLUG, {"x": 5}, version=version_name)
        assert simple["data"]["score"] == 500
        assert "decision" not in simple["data"]  # no split → no decision

        # -- Phase 9: Final batch to confirm clean state --
        batch_result3 = run_batch(
            client,
            DEV_WORKSPACE_ID,
            DEV_FLOW_SLUG,
            file_path=batch_file,
            version=version_name,
            concurrency=5,
            runs_dir=runs_dir,
        )
        assert batch_result3.meta.total_rows == 10
        assert batch_result3.meta.succeeded == 10

        results3 = [json.loads(line) for line in Path(batch_result3.results_path).read_text().strip().splitlines()]
        for r in results3:
            d = r["output"].get("data", {})
            if "score" in d:
                assert "decision" not in d, "Decision should not exist after removing split"

        print(f"\nAll 9 phases passed for version {version_name} ({vid})")
