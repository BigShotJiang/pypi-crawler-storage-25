"""Integration test: batch run against the real Taktile dev environment.

Uses the no-op flow which is safe to call repeatedly.
Exercises: parse_batch_file, run_batch, list_batch_runs, get_batch_run, get_batch_results, extract_query.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from tktl.api.client import TktlClient
from tktl.api.execution import _workspace_base_url_cache
from tktl.ops.batch import (
    extract_query,
    get_batch_results,
    get_batch_run,
    list_batch_runs,
    run_batch,
)

from .conftest import DEV_FLOW_SLUG, DEV_WORKSPACE_ID

pytestmark = pytest.mark.integration


class TestBatchRun:
    """End-to-end batch run against the real dev Decide API."""

    def setup_method(self):
        _workspace_base_url_cache.clear()

    def test_batch_json_array(self, dev_client: TktlClient, tmp_path: Path):
        """Batch run with a JSON array input file."""
        input_file = tmp_path / "input.json"
        rows = [{"data_field": f"test-{i}"} for i in range(3)]
        input_file.write_text(json.dumps(rows))

        runs_dir = tmp_path / "runs"

        result = run_batch(
            dev_client,
            DEV_WORKSPACE_ID,
            DEV_FLOW_SLUG,
            file_path=input_file,
            env="sandbox",
            concurrency=2,
            runs_dir=runs_dir,
        )

        assert result.meta.total_rows == 3
        assert result.meta.succeeded + result.meta.failed == 3
        assert result.meta.flow_slug == DEV_FLOW_SLUG
        assert result.meta.env == "sandbox"
        assert result.meta.concurrency == 2
        assert result.meta.completed_at is not None
        assert result.meta.duration_ms is not None

        # Results file should exist
        results_path = Path(result.results_path)
        assert results_path.exists()
        lines = results_path.read_text().strip().splitlines()
        assert len(lines) == 3

    def test_batch_csv(self, dev_client: TktlClient, tmp_path: Path):
        """Batch run with a CSV input file."""
        input_file = tmp_path / "input.csv"
        input_file.write_text("data_field\ntest-csv-1\ntest-csv-2\n")

        runs_dir = tmp_path / "runs"

        result = run_batch(
            dev_client,
            DEV_WORKSPACE_ID,
            DEV_FLOW_SLUG,
            file_path=input_file,
            env="sandbox",
            runs_dir=runs_dir,
        )

        assert result.meta.total_rows == 2
        assert result.meta.succeeded + result.meta.failed == 2

    def test_batch_jsonl(self, dev_client: TktlClient, tmp_path: Path):
        """Batch run with a JSONL input file."""
        input_file = tmp_path / "input.jsonl"
        input_file.write_text('{"data_field": "jsonl-1"}\n{"data_field": "jsonl-2"}\n')

        runs_dir = tmp_path / "runs"

        result = run_batch(
            dev_client,
            DEV_WORKSPACE_ID,
            DEV_FLOW_SLUG,
            file_path=input_file,
            env="sandbox",
            runs_dir=runs_dir,
        )

        assert result.meta.total_rows == 2
        assert result.meta.succeeded + result.meta.failed == 2


class TestBatchHistory:
    """Test history retrieval after a batch run."""

    def setup_method(self):
        _workspace_base_url_cache.clear()

    def test_history_roundtrip(self, dev_client: TktlClient, tmp_path: Path):
        """Run a batch, then list and inspect its history."""
        input_file = tmp_path / "input.json"
        input_file.write_text(json.dumps([{"data_field": "history-test"}]))

        runs_dir = tmp_path / "runs"

        result = run_batch(
            dev_client,
            DEV_WORKSPACE_ID,
            DEV_FLOW_SLUG,
            file_path=input_file,
            env="sandbox",
            runs_dir=runs_dir,
        )

        # List runs
        runs = list_batch_runs(DEV_FLOW_SLUG, runs_dir=runs_dir)
        assert len(runs) == 1
        assert runs[0].run_id == result.meta.run_id
        assert runs[0].total_rows == 1

        # Get specific run
        meta = get_batch_run(DEV_FLOW_SLUG, result.meta.run_id, runs_dir=runs_dir)
        assert meta.run_id == result.meta.run_id
        assert meta.source == str(input_file)
        assert meta.completed_at is not None

        # Get results
        results = get_batch_results(DEV_FLOW_SLUG, result.meta.run_id, runs_dir=runs_dir)
        assert len(results) == 1
        assert results[0].row_index == 0
        assert results[0].input == {"data_field": "history-test"}

    def test_query_extraction(self, dev_client: TktlClient, tmp_path: Path):
        """Run a batch and extract a specific field from results."""
        input_file = tmp_path / "input.json"
        input_file.write_text(json.dumps([{"data_field": "query-test"}]))

        runs_dir = tmp_path / "runs"

        result = run_batch(
            dev_client,
            DEV_WORKSPACE_ID,
            DEV_FLOW_SLUG,
            file_path=input_file,
            env="sandbox",
            runs_dir=runs_dir,
        )

        results = get_batch_results(DEV_FLOW_SLUG, result.meta.run_id, runs_dir=runs_dir)
        assert len(results) == 1

        # Extract the input field from results
        row = results[0]
        value = extract_query(row.model_dump(), "input.data_field")
        assert value == "query-test"

        # Extract row_index
        assert extract_query(row.model_dump(), "row_index") == 0
