"""Tests for the flows API functions."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import pytest

from tests.test_api.conftest import FAKE_BASE_URL, make_sync_transport, write_test_config, write_test_credentials
from tktl.api.client import TktlClient
from tktl.api.flows import get_flow_by_slug, list_flows
from tktl.models.errors import NotFoundError

if TYPE_CHECKING:
    from tests.fake_api.state import FakeState

WS_ID = "ws_00000000-0000-0000-0000-000000000001"


@pytest.fixture
def client(tmp_path: Path, fake_state: FakeState) -> TktlClient:
    """TktlClient wired to the fake ASGI server via sync bridge transport."""
    write_test_config(tmp_path)
    write_test_credentials(tmp_path, "test-key")
    transport = make_sync_transport(fake_state)
    return TktlClient(
        config_dir=tmp_path,
        base_url=FAKE_BASE_URL,
        transport=transport,
    )


class TestListFlows:
    def test_returns_flow_list(self, client: TktlClient) -> None:
        flows = list_flows(client, workspace_id=WS_ID)
        assert isinstance(flows, list)
        assert len(flows) == 3
        slugs = {f["slug"] for f in flows}
        assert "credit-scoring" in slugs
        assert "kyc-check" in slugs

    def test_flow_has_expected_fields(self, client: TktlClient) -> None:
        flows = list_flows(client, workspace_id=WS_ID)
        flow = flows[0]
        assert "id" in flow
        assert "slug" in flow
        assert "name" in flow
        assert "workspace_id" in flow

    def test_no_internal_fields(self, client: TktlClient) -> None:
        flows = list_flows(client, workspace_id=WS_ID)
        for flow in flows:
            assert not any(k.startswith("_") for k in flow)


class TestGetFlowBySlug:
    def test_found(self, client: TktlClient) -> None:
        flow = get_flow_by_slug(client, workspace_id=WS_ID, slug="credit-scoring")
        assert flow["slug"] == "credit-scoring"
        assert "versions" in flow
        assert len(flow["versions"]) == 2

    def test_not_found_raises(self, client: TktlClient) -> None:
        with pytest.raises(NotFoundError):
            get_flow_by_slug(client, workspace_id=WS_ID, slug="nonexistent")

    def test_version_summaries(self, client: TktlClient) -> None:
        flow = get_flow_by_slug(client, workspace_id=WS_ID, slug="credit-scoring")
        for v in flow["versions"]:
            assert "id" in v
            assert "name" in v
            assert "status" in v
