"""Tests for the dataset upload API functions."""

from __future__ import annotations

from unittest.mock import patch

import httpx
import pytest

from tktl.api.datasets import create_file_upload, get_file_upload_status, upload_to_s3
from tktl.models.errors import NetworkError


def _resp(status_code: int, **kwargs) -> httpx.Response:
    """Create a Response with a dummy request attached (needed for raise_for_status)."""
    r = httpx.Response(status_code, **kwargs)
    r._request = httpx.Request("GET", "https://fake.com")
    return r


class TestCreateFileUpload:
    def test_returns_upload_with_presigned_url(self) -> None:
        resp = _resp(
            200,
            json={
                "id": "upload-1",
                "s3_presigned_url": "https://s3.com/upload",
                "s3_presigned_fields": {"key": "uploads/upload-1"},
                "status": "PENDING",
                "file_name": "test.csv",
            },
        )
        with patch("tktl.api.datasets.httpx.post", return_value=resp):
            result = create_file_upload("key", "https://fake.com", "flow-1", "test.csv")
        assert result["id"] == "upload-1"
        assert result["s3_presigned_url"] == "https://s3.com/upload"
        assert result["status"] == "PENDING"

    def test_with_custom_purpose(self) -> None:
        resp = _resp(200, json={"id": "upload-2", "status": "PENDING"})
        with patch("tktl.api.datasets.httpx.post", return_value=resp) as mock_post:
            create_file_upload("key", "https://fake.com", "flow-1", "data.csv", purpose="job_source")
        call_kwargs = mock_post.call_args
        body = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
        assert body["purpose"] == "job_source"


class TestGetFileUploadStatus:
    def test_returns_status(self) -> None:
        resp = _resp(200, json={"id": "upload-1", "status": "COMPLETED", "dataset_id": "ds-1"})
        with patch("tktl.api.datasets.httpx.get", return_value=resp):
            result = get_file_upload_status("key", "https://fake.com", "upload-1")
        assert result["status"] == "COMPLETED"
        assert result["dataset_id"] == "ds-1"

    def test_404_raises_not_found(self) -> None:
        resp = _resp(404, json={"detail": "Not found"})
        with patch("tktl.api.datasets.httpx.get", return_value=resp):
            with pytest.raises(Exception):
                get_file_upload_status("key", "https://fake.com", "nonexistent")


class TestUploadToS3:
    def test_success_on_204(self) -> None:
        resp = _resp(204)
        with patch("tktl.api.datasets.httpx.post", return_value=resp):
            upload_to_s3("https://s3.com/upload", {"key": "k"}, b"data", "test.csv")

    def test_failure_raises_network_error(self) -> None:
        resp = _resp(403)
        with patch("tktl.api.datasets.httpx.post", return_value=resp):
            with pytest.raises(NetworkError):
                upload_to_s3("https://s3.com/upload", {"key": "k"}, b"data", "test.csv")
