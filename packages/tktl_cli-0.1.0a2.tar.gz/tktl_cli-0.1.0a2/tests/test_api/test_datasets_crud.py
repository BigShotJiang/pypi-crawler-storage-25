"""Tests for the dataset CRUD API layer (raw httpx with api_key + base_url).

Uses monkeypatching to route httpx calls through the fake ASGI app.
"""

from __future__ import annotations

import asyncio
import uuid
from typing import Any

import httpx
import pytest

import tktl.api.datasets as ds_mod
from tests.conftest import WS_ID
from tests.fake_api.app import create_fake_app
from tests.fake_api.state import FakeDataset, FakeDatasetColumn, FakeDatasetRow, FakeState
from tktl.api.datasets import (
    append_rows_api,
    create_dataset_api,
    create_file_upload_api,
    delete_columns_api,
    delete_dataset_api,
    delete_row_api,
    download_dataset_file_api,
    fill_column_api,
    get_dataset_api,
    get_file_upload_api,
    list_datasets_api,
    patch_dataset_api,
    update_row_api,
    upsert_columns_api,
)
from tktl.models.errors import NotFoundError

FAKE_BASE = "https://fake-ws.taktile.com"
API_KEY = "fake-key"


def _make_httpx_bridge(state: FakeState):
    """Create patched httpx functions that route through the ASGI fake app."""
    app = create_fake_app(state)
    transport = httpx.ASGITransport(app=app)

    def _sync_request(method: str, url: str, **kwargs: Any) -> httpx.Response:
        async def _do() -> httpx.Response:
            async with httpx.AsyncClient(transport=transport, base_url=FAKE_BASE) as client:
                return await client.request(method, url, **kwargs)

        loop = asyncio.new_event_loop()
        try:
            resp = loop.run_until_complete(_do())
        finally:
            loop.close()
        r = httpx.Response(status_code=resp.status_code, headers=dict(resp.headers), content=resp.content)
        r._request = httpx.Request(method, url)
        return r

    def get(url: str, **kw: Any) -> httpx.Response:
        return _sync_request("GET", url, **kw)

    def post(url: str, **kw: Any) -> httpx.Response:
        return _sync_request("POST", url, **kw)

    def patch(url: str, **kw: Any) -> httpx.Response:
        return _sync_request("PATCH", url, **kw)

    def put(url: str, **kw: Any) -> httpx.Response:
        return _sync_request("PUT", url, **kw)

    def request(method: str, url: str, **kw: Any) -> httpx.Response:
        return _sync_request(method, url, **kw)

    return get, post, patch, put, request


@pytest.fixture
def ds_state() -> FakeState:
    state = FakeState()
    flow_id = "flow-001"
    state.flows[flow_id] = {
        "id": flow_id,
        "slug": "credit-scoring",
        "name": "Credit Scoring",
        "workspace_id": WS_ID,
        "_version_ids": [],
    }
    ds_id = "ds-001"
    state.datasets[ds_id] = FakeDataset(
        dataset_id=ds_id,
        flow_id=flow_id,
        name="Test Dataset",
        etag="etag-1",
        rows=[],
        input_columns=[FakeDatasetColumn(name="income", desired_type="number")],
        mock_columns=[],
        dataset_rows=[
            FakeDatasetRow(id="row-1", input_data={"income": 50000}),
            FakeDatasetRow(id="row-2", input_data={"income": 75000}),
        ],
    )
    return state


@pytest.fixture(autouse=True)
def _patch_httpx(ds_state: FakeState, monkeypatch: pytest.MonkeyPatch) -> None:
    """Route all raw httpx calls in the datasets module through the fake ASGI app."""
    get, post, patch, put, request = _make_httpx_bridge(ds_state)
    monkeypatch.setattr(ds_mod.httpx, "get", get)
    monkeypatch.setattr(ds_mod.httpx, "post", post)
    monkeypatch.setattr(ds_mod.httpx, "patch", patch)
    monkeypatch.setattr(ds_mod.httpx, "put", put)
    monkeypatch.setattr(ds_mod.httpx, "request", request)


class TestListDatasets:
    def test_returns_list(self) -> None:
        result = list_datasets_api(API_KEY, FAKE_BASE, "flow-001")
        assert isinstance(result, list)
        assert len(result) == 1
        assert result[0]["name"] == "Test Dataset"

    def test_empty_for_unknown_flow(self) -> None:
        result = list_datasets_api(API_KEY, FAKE_BASE, "nonexistent")
        assert result == []


class TestCreateDataset:
    def test_creates_from_scratch(self) -> None:
        body = {
            "name": "New Dataset",
            "flow_id": "flow-001",
            "input_columns": [{"name": "age", "desired_type": "integer"}],
            "mock_columns": [],
        }
        result = create_dataset_api(API_KEY, FAKE_BASE, body)
        assert result["name"] == "New Dataset"
        assert result["source"] == "scratch"


class TestGetDataset:
    def test_returns_dataset_with_rows(self) -> None:
        result = get_dataset_api(API_KEY, FAKE_BASE, "ds-001", from_=0, size=10)
        assert result["name"] == "Test Dataset"
        assert len(result["rows"]) == 2

    def test_pagination(self) -> None:
        result = get_dataset_api(API_KEY, FAKE_BASE, "ds-001", from_=0, size=1)
        assert len(result["rows"]) == 1

    def test_not_found(self) -> None:
        with pytest.raises(NotFoundError):
            get_dataset_api(API_KEY, FAKE_BASE, "nonexistent")


class TestPatchDataset:
    def test_updates_name(self) -> None:
        result = patch_dataset_api(API_KEY, FAKE_BASE, "ds-001", {"name": "Renamed"})
        assert result["name"] == "Renamed"

    def test_not_found(self) -> None:
        with pytest.raises(NotFoundError):
            patch_dataset_api(API_KEY, FAKE_BASE, "nonexistent", {"name": "X"})


class TestDeleteDataset:
    def test_deletes(self) -> None:
        delete_dataset_api(API_KEY, FAKE_BASE, "ds-001")
        with pytest.raises(NotFoundError):
            get_dataset_api(API_KEY, FAKE_BASE, "ds-001")

    def test_not_found(self) -> None:
        with pytest.raises(NotFoundError):
            delete_dataset_api(API_KEY, FAKE_BASE, "nonexistent")


class TestAppendRows:
    def test_append_blank(self) -> None:
        row_ids = [str(uuid.uuid4())]
        result = append_rows_api(API_KEY, FAKE_BASE, "ds-001", {"source": "blank", "new_row_ids": row_ids})
        assert len(result) == 1

    def test_not_found(self) -> None:
        with pytest.raises(NotFoundError):
            append_rows_api(API_KEY, FAKE_BASE, "nonexistent", {"source": "blank", "new_row_ids": [str(uuid.uuid4())]})


class TestUpdateRow:
    def test_updates_input_data(self) -> None:
        result = update_row_api(API_KEY, FAKE_BASE, "ds-001", "row-1", {"input_data": {"income": 99999}})
        assert result["input_data"]["income"] == 99999

    def test_not_found(self) -> None:
        with pytest.raises(NotFoundError):
            update_row_api(API_KEY, FAKE_BASE, "ds-001", "nonexistent", {"input_data": {}})


class TestDeleteRow:
    def test_deletes(self) -> None:
        delete_row_api(API_KEY, FAKE_BASE, "ds-001", "row-1")
        result = get_dataset_api(API_KEY, FAKE_BASE, "ds-001", from_=0, size=50)
        assert len(result["rows"]) == 1

    def test_not_found(self) -> None:
        with pytest.raises(NotFoundError):
            delete_row_api(API_KEY, FAKE_BASE, "ds-001", "nonexistent")


class TestUpsertColumns:
    def test_adds_column(self) -> None:
        body = [{"group": "input_columns", "column": {"name": "age", "desired_type": "integer"}}]
        result = upsert_columns_api(API_KEY, FAKE_BASE, "ds-001", body)
        assert len(result["input_columns"]) == 2

    def test_not_found(self) -> None:
        with pytest.raises(NotFoundError):
            upsert_columns_api(API_KEY, FAKE_BASE, "nonexistent", [])


class TestDeleteColumns:
    def test_deletes_column(self) -> None:
        body = [{"group": "input_columns", "name": "income"}]
        result = delete_columns_api(API_KEY, FAKE_BASE, "ds-001", body)
        assert len(result["input_columns"]) == 0

    def test_not_found(self) -> None:
        with pytest.raises(NotFoundError):
            delete_columns_api(API_KEY, FAKE_BASE, "nonexistent", [])


class TestFillColumn:
    def test_fills_value(self) -> None:
        result = fill_column_api(API_KEY, FAKE_BASE, "ds-001", "input_columns", "income", {"fill_value": 42})
        assert "etag" in result

    def test_not_found(self) -> None:
        with pytest.raises(NotFoundError):
            fill_column_api(API_KEY, FAKE_BASE, "nonexistent", "input_columns", "x", {"fill_value": 0})


class TestFileUpload:
    def test_create_upload(self) -> None:
        result = create_file_upload_api(API_KEY, FAKE_BASE, {"flow_id": "flow-001", "file_name": "data.csv"})
        assert result["status"] == "PENDING"
        assert "s3_presigned_url" in result

    def test_get_upload_status(self) -> None:
        upload = create_file_upload_api(API_KEY, FAKE_BASE, {"flow_id": "flow-001", "file_name": "data.csv"})
        result = get_file_upload_api(API_KEY, FAKE_BASE, upload["id"])
        assert result["status"] == "PENDING"


class TestDownloadDatasetFile:
    def test_download_csv(self) -> None:
        data = download_dataset_file_api(API_KEY, FAKE_BASE, "ds-001", fmt="csv")
        assert isinstance(data, bytes)
        assert b"income" in data

    def test_download_json(self) -> None:
        data = download_dataset_file_api(API_KEY, FAKE_BASE, "ds-001", fmt="json")
        assert isinstance(data, bytes)

    def test_not_found(self) -> None:
        with pytest.raises(NotFoundError):
            download_dataset_file_api(API_KEY, FAKE_BASE, "nonexistent")
