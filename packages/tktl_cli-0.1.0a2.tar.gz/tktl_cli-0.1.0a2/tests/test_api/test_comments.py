"""Tests for the comments API functions."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import pytest

from tests.test_api.conftest import FAKE_BASE_URL, make_sync_transport, write_test_config, write_test_credentials
from tktl.api.client import TktlClient
from tktl.api.comments import create_comment, delete_comment, get_comment_summary, list_comments
from tktl.models.errors import NotFoundError

if TYPE_CHECKING:
    from tests.fake_api.state import FakeState

VERSION_ID = "ver_credit_v1"


@pytest.fixture
def client(tmp_path: Path, fake_state: FakeState) -> TktlClient:
    write_test_config(tmp_path)
    write_test_credentials(tmp_path, "test-key")
    transport = make_sync_transport(fake_state)
    return TktlClient(config_dir=tmp_path, base_url=FAKE_BASE_URL, transport=transport)


class TestListComments:
    def test_empty_initially(self, client: TktlClient) -> None:
        comments = list_comments(client, VERSION_ID)
        assert comments == []

    def test_returns_created_comments(self, client: TktlClient) -> None:
        create_comment(client, VERSION_ID, "first comment")
        create_comment(client, VERSION_ID, "second comment")
        comments = list_comments(client, VERSION_ID)
        assert len(comments) == 2
        assert {c["content"] for c in comments} == {"first comment", "second comment"}

    def test_filter_by_node(self, client: TktlClient) -> None:
        create_comment(client, VERSION_ID, "on node", resource_type="node", resource_id="node_risk")
        create_comment(client, VERSION_ID, "on version")
        comments = list_comments(client, VERSION_ID, resource_type="node", resource_id="node_risk")
        assert len(comments) == 1
        assert comments[0]["content"] == "on node"


class TestCreateComment:
    def test_returns_comment_with_id(self, client: TktlClient) -> None:
        result = create_comment(client, VERSION_ID, "test comment")
        assert "id" in result
        assert result["content"] == "test comment"
        assert result["flow_version"] == VERSION_ID

    def test_node_comment_has_resource(self, client: TktlClient) -> None:
        result = create_comment(client, VERSION_ID, "node comment", resource_type="node", resource_id="node_risk")
        assert result["resource_type"] == "node"
        assert result["resource_id"] == "node_risk"


class TestDeleteComment:
    def test_delete_existing(self, client: TktlClient) -> None:
        created = create_comment(client, VERSION_ID, "to delete")
        delete_comment(client, created["id"])
        comments = list_comments(client, VERSION_ID)
        assert len(comments) == 0

    def test_delete_nonexistent_raises(self, client: TktlClient) -> None:
        with pytest.raises(NotFoundError):
            delete_comment(client, "nonexistent-id")


class TestCommentSummary:
    def test_empty_summary(self, client: TktlClient) -> None:
        summary = get_comment_summary(client, VERSION_ID)
        assert summary == []

    def test_counts_per_node(self, client: TktlClient) -> None:
        create_comment(client, VERSION_ID, "c1", resource_type="node", resource_id="node_risk")
        create_comment(client, VERSION_ID, "c2", resource_type="node", resource_id="node_risk")
        create_comment(client, VERSION_ID, "c3", resource_type="node", resource_id="node_pricing")
        summary = get_comment_summary(client, VERSION_ID)
        by_node = {s["node_id"]: s["comments"] for s in summary}
        assert by_node["node_risk"] == 2
        assert by_node["node_pricing"] == 1
