"""Tests for the execution API (workspace Decide API)."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import httpx

import pytest

from tktl.api.client import TktlClient
from tktl.api.execution import run_flow, _workspace_base_url_cache
from tktl.models.errors import TktlError


class TestRunFlow:
    def setup_method(self):
        _workspace_base_url_cache.clear()

    def test_resolves_workspace_and_executes(self, tmp_path: Path) -> None:
        """run_flow should resolve workspace base_url then POST to decide endpoint."""
        call_log: list[str] = []

        def handler(request: httpx.Request) -> httpx.Response:
            url = str(request.url)
            call_log.append(url)
            # Workspace lookup
            if "/api/v1/workspaces/" in url:
                return httpx.Response(200, json={"base_url": "https://fake-decide.taktile.com"})
            return httpx.Response(500)

        _write_config(tmp_path)
        _write_credentials(tmp_path, "test-key")
        transport = httpx.MockTransport(handler)
        client = TktlClient(config_dir=tmp_path, base_url="https://fake-flow.taktile.com", transport=transport)

        # Mock the httpx.post call to the decide endpoint
        decide_response = httpx.Response(200, json={"data": {}, "status": "success", "metadata": {"version": "v1"}})
        with patch("tktl.api.execution.httpx.post", return_value=decide_response) as mock_post:
            result = run_flow(client, "ws_123", "my-flow", {"income": 50000}, version="v1", env="sandbox")

        assert result["status"] == "success"
        # Verify workspace was resolved
        assert any("/api/v1/workspaces/ws_123" in u for u in call_log)
        # Verify decide endpoint was called correctly
        mock_post.assert_called_once()
        args, kwargs = mock_post.call_args
        assert args[0] == "https://fake-decide.taktile.com/run/api/v1/flows/my-flow/sandbox/decide"
        assert kwargs["json"]["data"] == {"income": 50000}
        assert kwargs["json"]["metadata"]["version"] == "v1"
        assert kwargs["headers"]["X-Api-Key"] == "test-key"

    def test_caches_workspace_base_url(self, tmp_path: Path) -> None:
        """Second call should not re-fetch workspace."""
        workspace_calls = []

        def handler(request: httpx.Request) -> httpx.Response:
            url = str(request.url)
            if "/api/v1/workspaces/" in url:
                workspace_calls.append(url)
                return httpx.Response(200, json={"base_url": "https://fake-decide.taktile.com"})
            return httpx.Response(500)

        _write_config(tmp_path)
        _write_credentials(tmp_path, "test-key")
        transport = httpx.MockTransport(handler)
        client = TktlClient(config_dir=tmp_path, base_url="https://fake-flow.taktile.com", transport=transport)

        decide_response = httpx.Response(200, json={"data": {}, "status": "success", "metadata": {}})
        with patch("tktl.api.execution.httpx.post", return_value=decide_response):
            run_flow(client, "ws_123", "f1", {})
            run_flow(client, "ws_123", "f2", {})

        assert len(workspace_calls) == 1  # Only one workspace lookup

    def test_adds_https_prefix(self, tmp_path: Path) -> None:
        """base_url without scheme should get https:// prefix."""

        def handler(request: httpx.Request) -> httpx.Response:
            if "/api/v1/workspaces/" in str(request.url):
                return httpx.Response(200, json={"base_url": "decide.example.com"})
            return httpx.Response(500)

        _write_config(tmp_path)
        _write_credentials(tmp_path, "test-key")
        transport = httpx.MockTransport(handler)
        client = TktlClient(config_dir=tmp_path, base_url="https://fake.com", transport=transport)

        decide_response = httpx.Response(200, json={"status": "success"})
        with patch("tktl.api.execution.httpx.post", return_value=decide_response) as mock_post:
            run_flow(client, "ws_123", "f1", {})

        args, _ = mock_post.call_args
        assert args[0].startswith("https://decide.example.com/")

    def test_version_omitted_when_none(self, tmp_path: Path) -> None:
        """When version is None, metadata should not contain 'version' key."""

        def handler(request: httpx.Request) -> httpx.Response:
            if "/api/v1/workspaces/" in str(request.url):
                return httpx.Response(200, json={"base_url": "https://fake.com"})
            return httpx.Response(500)

        _write_config(tmp_path)
        _write_credentials(tmp_path, "test-key")
        transport = httpx.MockTransport(handler)
        client = TktlClient(config_dir=tmp_path, base_url="https://fake.com", transport=transport)

        decide_response = httpx.Response(200, json={"status": "success"})
        with patch("tktl.api.execution.httpx.post", return_value=decide_response) as mock_post:
            run_flow(client, "ws_123", "f1", {}, version=None)

        _, kwargs = mock_post.call_args
        assert "version" not in kwargs["json"]["metadata"]

    def test_500_with_dict_detail_raises_tktl_error(self, tmp_path: Path) -> None:
        """A 500 with structured detail body should raise TktlError with the message."""

        def handler(request: httpx.Request) -> httpx.Response:
            if "/api/v1/workspaces/" in str(request.url):
                return httpx.Response(200, json={"base_url": "https://fake.com"})
            return httpx.Response(500)

        _write_config(tmp_path)
        _write_credentials(tmp_path, "test-key")
        transport = httpx.MockTransport(handler)
        client = TktlClient(config_dir=tmp_path, base_url="https://fake.com", transport=transport)

        error_response = httpx.Response(
            500,
            json={
                "status": "error",
                "detail": {
                    "exc_type": "compile",
                    "msg": "value is not a valid uuid",
                    "node_id": "abc-123",
                },
            },
        )
        with patch("tktl.api.execution.httpx.post", return_value=error_response):
            with pytest.raises(TktlError, match="compile"):
                run_flow(client, "ws_123", "my-flow", {}, version="v1")

    def test_409_with_string_detail_raises_tktl_error(self, tmp_path: Path) -> None:
        """A 409 with a plain string detail should include it in the error message."""

        def handler(request: httpx.Request) -> httpx.Response:
            if "/api/v1/workspaces/" in str(request.url):
                return httpx.Response(200, json={"base_url": "https://fake.com"})
            return httpx.Response(500)

        _write_config(tmp_path)
        _write_credentials(tmp_path, "test-key")
        transport = httpx.MockTransport(handler)
        client = TktlClient(config_dir=tmp_path, base_url="https://fake.com", transport=transport)

        error_response = httpx.Response(
            409,
            json={
                "status": "error",
                "detail": "Output schema validation failed on field 'decision': None is not of type 'string'",
            },
        )
        with patch("tktl.api.execution.httpx.post", return_value=error_response):
            with pytest.raises(TktlError, match="Output schema validation failed"):
                run_flow(client, "ws_123", "my-flow", {}, version="v1")


# ---- helpers ----


def _write_config(tmp_path: Path) -> None:
    config_file = tmp_path / "config.json"
    config_file.write_text(json.dumps({}))


def _write_credentials(tmp_path: Path, api_key: str) -> None:
    cred_file = tmp_path / "credentials.json"
    cred_file.write_text(json.dumps({"api_key": api_key}))
