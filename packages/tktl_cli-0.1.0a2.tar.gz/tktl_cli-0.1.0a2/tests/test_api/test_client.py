"""Tests for the TktlClient HTTP wrapper."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any
from unittest.mock import patch

import httpx
import pytest

from tktl.api.client import DEFAULT_BASE_URL, TktlClient
from tktl.models.errors import AuthError, NetworkError


class TestClientConstruction:
    """Verify the client reads config/credentials and sets headers."""

    def test_api_key_header(self, tmp_path: Path) -> None:
        """Client must attach X-Api-Key header from credentials."""
        _write_config(tmp_path)
        _write_credentials(tmp_path, "my-secret-key")

        client = TktlClient(config_dir=tmp_path, transport=_echo_transport())
        resp = client.get("/echo")
        data = resp.json()
        assert data["headers"]["x-api-key"] == "my-secret-key"

    def test_base_url_default(self, tmp_path: Path) -> None:
        """When flow_api_url is None in config, use the default."""
        _write_config(tmp_path, flow_api_url=None)
        _write_credentials(tmp_path, "key")

        client = TktlClient(config_dir=tmp_path, transport=_echo_transport())
        assert client.base_url == DEFAULT_BASE_URL

    def test_base_url_from_config(self, tmp_path: Path) -> None:
        """When flow_api_url is set in config, use that."""
        _write_config(tmp_path, flow_api_url="https://custom-api.example.com")
        _write_credentials(tmp_path, "key")

        client = TktlClient(config_dir=tmp_path, transport=_echo_transport())
        assert client.base_url == "https://custom-api.example.com"

    def test_missing_api_key_raises_auth_error(self, tmp_path: Path) -> None:
        """If no credentials file exists, constructing the client raises AuthError."""
        _write_config(tmp_path)
        # No credentials file

        with pytest.raises(AuthError, match="API key"):
            TktlClient(config_dir=tmp_path)

    def test_explicit_overrides(self, tmp_path: Path) -> None:
        """Explicit base_url, api_key, and transport override config files."""
        _write_config(tmp_path)
        _write_credentials(tmp_path, "file-key")

        client = TktlClient(
            config_dir=tmp_path,
            base_url="https://override.example.com",
            api_key="override-key",
            transport=_echo_transport(),
        )
        assert client.base_url == "https://override.example.com"
        resp = client.get("/echo")
        assert resp.json()["headers"]["x-api-key"] == "override-key"


class TestClientMethods:
    """Verify get/post/patch/put/delete pass through correctly."""

    @pytest.fixture
    def client(self, tmp_path: Path) -> TktlClient:
        _write_config(tmp_path)
        _write_credentials(tmp_path, "test-key")
        return TktlClient(config_dir=tmp_path, transport=_echo_transport())

    def test_get(self, client: TktlClient) -> None:
        resp = client.get("/echo", params={"a": "1"})
        assert resp.status_code == 200
        data = resp.json()
        assert data["method"] == "GET"
        assert "a=1" in data["url"]

    def test_post(self, client: TktlClient) -> None:
        resp = client.post("/echo", json={"foo": "bar"})
        data = resp.json()
        assert data["method"] == "POST"
        assert data["body"] == {"foo": "bar"}

    def test_patch(self, client: TktlClient) -> None:
        resp = client.patch("/echo", json={"x": 1})
        data = resp.json()
        assert data["method"] == "PATCH"
        assert data["body"] == {"x": 1}

    def test_put(self, client: TktlClient) -> None:
        resp = client.put("/echo", json={"y": 2}, params={"etag": "abc"})
        data = resp.json()
        assert data["method"] == "PUT"
        assert data["body"] == {"y": 2}
        assert "etag=abc" in data["url"]

    def test_delete(self, client: TktlClient) -> None:
        resp = client.delete("/echo")
        data = resp.json()
        assert data["method"] == "DELETE"

    def test_custom_headers(self, client: TktlClient) -> None:
        resp = client.get("/echo", headers={"if-none-match": "etag-123"})
        data = resp.json()
        assert data["headers"]["if-none-match"] == "etag-123"
        # api key should still be present
        assert data["headers"]["x-api-key"] == "test-key"


class TestRetryLogic:
    """Verify retry on network errors with exponential backoff."""

    def test_retry_on_network_error(self, tmp_path: Path) -> None:
        """Client retries up to 3 times on network errors, then succeeds."""
        call_count = 0

        def handler(request: httpx.Request) -> httpx.Response:
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise httpx.ConnectError("connection refused")
            return httpx.Response(200, json={"ok": True})

        _write_config(tmp_path)
        _write_credentials(tmp_path, "key")

        transport = httpx.MockTransport(handler)
        with patch("time.sleep"):  # skip actual sleeps
            client = TktlClient(config_dir=tmp_path, transport=transport)
            resp = client.get("/test")

        assert resp.status_code == 200
        assert call_count == 3

    def test_retry_exhausted_raises_network_error(self, tmp_path: Path) -> None:
        """After 3 retries (4 total attempts), raise NetworkError."""
        call_count = 0

        def handler(request: httpx.Request) -> httpx.Response:
            nonlocal call_count
            call_count += 1
            raise httpx.ConnectError("connection refused")

        _write_config(tmp_path)
        _write_credentials(tmp_path, "key")

        transport = httpx.MockTransport(handler)
        with patch("time.sleep"):
            client = TktlClient(config_dir=tmp_path, transport=transport)
            with pytest.raises(NetworkError, match="connection refused"):
                client.get("/test")

        assert call_count == 4  # 1 initial + 3 retries

    def test_no_retry_on_http_errors(self, tmp_path: Path) -> None:
        """HTTP 4xx/5xx errors are NOT retried (only network errors are)."""
        call_count = 0

        def handler(request: httpx.Request) -> httpx.Response:
            nonlocal call_count
            call_count += 1
            return httpx.Response(500, json={"detail": "server error"})

        _write_config(tmp_path)
        _write_credentials(tmp_path, "key")

        transport = httpx.MockTransport(handler)
        client = TktlClient(config_dir=tmp_path, transport=transport)
        resp = client.get("/test")
        assert resp.status_code == 500
        assert call_count == 1  # no retry

    def test_backoff_delays(self, tmp_path: Path) -> None:
        """Verify exponential backoff delays: 1s, 2s, 4s."""
        sleep_calls: list[float] = []

        def handler(request: httpx.Request) -> httpx.Response:
            raise httpx.ConnectError("timeout")

        _write_config(tmp_path)
        _write_credentials(tmp_path, "key")

        transport = httpx.MockTransport(handler)
        with patch("time.sleep", side_effect=lambda s: sleep_calls.append(s)):
            client = TktlClient(config_dir=tmp_path, transport=transport)
            with pytest.raises(NetworkError):
                client.get("/test")

        assert sleep_calls == [1, 2, 4]


class TestErrorMapping:
    """Verify the client maps HTTP status codes to errors when raise_for_status is used."""

    def test_401_response(self, tmp_path: Path) -> None:
        """The client returns the response — error mapping is the caller's job."""
        transport = httpx.MockTransport(lambda r: httpx.Response(401, json={"detail": "unauthorized"}))
        _write_config(tmp_path)
        _write_credentials(tmp_path, "key")
        client = TktlClient(config_dir=tmp_path, transport=transport)
        resp = client.get("/test")
        assert resp.status_code == 401


# ---- helpers ----


def _write_config(tmp_path: Path, flow_api_url: str | None = None) -> None:
    config_file = tmp_path / "config.json"
    config_file.write_text(json.dumps({"flow_api_url": flow_api_url}))


def _write_credentials(tmp_path: Path, api_key: str) -> None:
    cred_file = tmp_path / "credentials.json"
    cred_file.write_text(json.dumps({"api_key": api_key}))


def _echo_transport() -> httpx.MockTransport:
    """Returns a transport that echoes request details back as JSON."""

    def handler(request: httpx.Request) -> httpx.Response:
        body: Any = None
        if request.content:
            try:
                body = json.loads(request.content)
            except (json.JSONDecodeError, UnicodeDecodeError):
                body = request.content.decode()

        return httpx.Response(
            200,
            json={
                "method": request.method,
                "url": str(request.url),
                "headers": dict(request.headers),
                "body": body,
            },
        )

    return httpx.MockTransport(handler)
