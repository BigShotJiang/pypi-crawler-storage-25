"""Tests for the versions API functions."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import pytest

import httpx

from tests.test_api.conftest import FAKE_BASE_URL, make_sync_transport, write_test_config, write_test_credentials
from tktl.api.client import TktlClient
from tktl.api.versions import (
    _fill_ids_recursive,
    create_version,
    delete_version,
    duplicate_version,
    get_changes,
    get_version,
    normalize_body,
    normalize_graph_response,
    patch_version,
    put_version,
)
from tktl.models.errors import ConflictError, NotFoundError

if TYPE_CHECKING:
    from tests.fake_api.state import FakeState


@pytest.fixture
def client(tmp_path: Path, fake_state: FakeState) -> TktlClient:
    write_test_config(tmp_path)
    write_test_credentials(tmp_path, "test-key")
    transport = make_sync_transport(fake_state)
    return TktlClient(
        config_dir=tmp_path,
        base_url=FAKE_BASE_URL,
        transport=transport,
    )


def _first_version_id(fake_state: FakeState) -> str:
    return next(iter(fake_state.versions.keys()))


def _first_flow_id(fake_state: FakeState) -> str:
    return next(iter(fake_state.flows.keys()))


class TestGetVersion:
    def test_returns_version(self, client: TktlClient, fake_state: FakeState) -> None:
        vid = _first_version_id(fake_state)
        result = get_version(client, vid)
        assert result is not None
        assert result["id"] == vid
        assert "graph" in result
        assert "name" in result

    def test_304_returns_none(self, client: TktlClient, fake_state: FakeState) -> None:
        vid = _first_version_id(fake_state)
        etag = fake_state.versions[vid]["etag"]
        result = get_version(client, vid, if_none_match=etag)
        assert result is None

    def test_not_found_raises(self, client: TktlClient) -> None:
        with pytest.raises(NotFoundError):
            get_version(client, "nonexistent-id")


class TestPatchVersion:
    def test_basic_patch(self, client: TktlClient, fake_state: FakeState) -> None:
        vid = _first_version_id(fake_state)
        etag = fake_state.versions[vid]["etag"]
        result = patch_version(client, vid, body={"name": "renamed"}, if_match=etag)
        assert result["name"] == "renamed"
        assert result["etag"] != etag

    def test_stale_etag_raises_conflict(self, client: TktlClient, fake_state: FakeState) -> None:
        vid = _first_version_id(fake_state)
        with pytest.raises(ConflictError):
            patch_version(client, vid, body={"name": "x"}, if_match="stale-etag")

    def test_with_session_header(self, client: TktlClient, fake_state: FakeState) -> None:
        vid = _first_version_id(fake_state)
        etag = fake_state.versions[vid]["etag"]
        result = patch_version(
            client,
            vid,
            body={"name": "updated"},
            if_match=etag,
            session="session-123",
        )
        assert result["name"] == "updated"


class TestPutVersion:
    def test_replace(self, client: TktlClient, fake_state: FakeState) -> None:
        vid = _first_version_id(fake_state)
        etag = fake_state.versions[vid]["etag"]
        body = {
            "name": "v1-replaced",
            "status": "DRAFT",
            "graph": {"nodes": {}, "edges": {}, "node_groups": {}},
        }
        result = put_version(client, vid, body=body, by_etag=etag)
        assert result["name"] == "v1-replaced"

    def test_stale_etag_raises_conflict(self, client: TktlClient, fake_state: FakeState) -> None:
        vid = _first_version_id(fake_state)
        with pytest.raises(ConflictError):
            put_version(client, vid, body={"name": "x"}, by_etag="wrong")


class TestCreateVersion:
    def test_create(self, client: TktlClient, fake_state: FakeState) -> None:
        flow_id = _first_flow_id(fake_state)
        result = create_version(client, flow_id=flow_id, name="v3-new")
        assert result["name"] == "v3-new"
        assert result["status"] == "DRAFT"
        assert "id" in result

    def test_create_with_status(self, client: TktlClient, fake_state: FakeState) -> None:
        flow_id = _first_flow_id(fake_state)
        result = create_version(client, flow_id=flow_id, name="v4", status="DRAFT")
        assert result["status"] == "DRAFT"


class TestDuplicateVersion:
    def test_duplicate(self, client: TktlClient, fake_state: FakeState) -> None:
        vid = _first_version_id(fake_state)
        result = duplicate_version(client, vid, name="v1-copy")
        assert result["name"] == "v1-copy"
        assert result["id"] != vid

    def test_not_found_raises(self, client: TktlClient) -> None:
        with pytest.raises(NotFoundError):
            duplicate_version(client, "nonexistent-id", name="copy")


class TestDeleteVersion:
    def test_delete(self, client: TktlClient, fake_state: FakeState) -> None:
        vid = _first_version_id(fake_state)
        delete_version(client, vid)
        # Verify it's gone
        with pytest.raises(NotFoundError):
            get_version(client, vid)

    def test_not_found_raises(self, client: TktlClient) -> None:
        with pytest.raises(NotFoundError):
            delete_version(client, "nonexistent-id")


class TestNormalizeBody:
    def test_converts_node_list_to_dict(self) -> None:
        body = {
            "graph": {
                "nodes": [{"id": "n1", "name": "A", "type": "input"}, {"id": "n2", "name": "B", "type": "output"}],
                "edges": [{"id": "e1", "start_node_id": "n1", "end_node_id": "n2"}],
                "node_groups": [{"id": "g1", "name": "Group", "node_ids": ["n1"]}],
            },
            "input_schema": {"type": "object"},
        }
        result = normalize_body(body)
        assert isinstance(result["graph"]["nodes"], dict)
        assert "n1" in result["graph"]["nodes"]
        assert "n2" in result["graph"]["nodes"]
        assert isinstance(result["graph"]["edges"], dict)
        assert "e1" in result["graph"]["edges"]
        assert isinstance(result["graph"]["node_groups"], dict)
        assert "g1" in result["graph"]["node_groups"]

    def test_dict_format_unchanged(self) -> None:
        body = {
            "graph": {
                "nodes": {"n1": {"id": "n1", "name": "A", "type": "input"}},
                "edges": {},
            },
        }
        result = normalize_body(body)
        assert result["graph"]["nodes"] == {"n1": {"id": "n1", "name": "A", "type": "input"}}

    def test_strips_server_fields(self) -> None:
        body = {
            "created_at": "2025-01-01",
            "updated_at": "2025-01-02",
            "etag": "00000001",
            "id": "some-id",
            "status": "DRAFT",
            "graph": {
                "id": "graph-id",
                "created_at": "2025-01-01",
                "updated_at": "2025-01-01",
                "meta": {"created_by_id": "x"},
                "nodes": {},
                "edges": {},
            },
            "name": "v1",
            "input_schema": {"type": "object"},
        }
        result = normalize_body(body)
        assert "created_at" not in result
        assert "etag" not in result
        assert "id" not in result
        assert "name" in result
        assert "id" not in result["graph"]
        assert "created_at" not in result["graph"]

    def test_no_graph_is_noop(self) -> None:
        body = {"name": "v1", "input_schema": {"type": "object"}}
        result = normalize_body(body)
        assert result == {"name": "v1", "input_schema": {"type": "object"}}

    def test_put_accepts_array_format(self, client: TktlClient, fake_state: FakeState) -> None:
        """PUT with array-format graph (raw API export) should work after normalization."""
        vid = _first_version_id(fake_state)
        etag = fake_state.versions[vid]["etag"]
        body = {
            "name": "v1-from-export",
            "graph": {
                "nodes": [
                    {"id": "n1", "name": "data", "type": "input", "meta": {}},
                    {"id": "n2", "name": "output", "type": "output", "meta": {"src": "data"}},
                ],
                "edges": [{"id": "e1", "start_node_id": "n1", "end_node_id": "n2", "meta": {}}],
                "node_groups": [],
            },
        }
        result = put_version(client, vid, body=body, by_etag=etag)
        assert result["name"] == "v1-from-export"


class TestNormalizeGraphResponse:
    def test_converts_list_to_dict_without_stripping_fields(self) -> None:
        """normalize_graph_response should convert lists to dicts but preserve id, etag, etc."""
        body = {
            "id": "version-id",
            "etag": "00000001",
            "status": "DRAFT",
            "name": "v1",
            "graph": {
                "nodes": [
                    {"id": "n1", "name": "data", "type": "input"},
                    {"id": "n2", "name": "output", "type": "output"},
                ],
                "edges": [{"id": "e1", "start_node_id": "n1", "end_node_id": "n2"}],
            },
        }
        result = normalize_graph_response(body)
        # Lists converted to dicts
        assert isinstance(result["graph"]["nodes"], dict)
        assert "n1" in result["graph"]["nodes"]
        # Server fields preserved (unlike normalize_body)
        assert result["id"] == "version-id"
        assert result["etag"] == "00000001"
        assert result["status"] == "DRAFT"

    def test_dict_format_unchanged(self) -> None:
        body = {
            "id": "v-id",
            "graph": {
                "nodes": {"n1": {"id": "n1", "type": "input"}},
                "edges": {},
            },
        }
        result = normalize_graph_response(body)
        assert result["graph"]["nodes"] == {"n1": {"id": "n1", "type": "input"}}
        assert result["id"] == "v-id"

    def test_no_graph_is_noop(self) -> None:
        body = {"id": "v-id", "name": "v1"}
        result = normalize_graph_response(body)
        assert result == {"id": "v-id", "name": "v1"}


class TestGetChanges:
    def test_returns_list(self, client: TktlClient, fake_state: FakeState) -> None:
        vid = _first_version_id(fake_state)
        changes = get_changes(client, vid)
        assert isinstance(changes, list)

    def test_with_params(self, client: TktlClient, fake_state: FakeState) -> None:
        vid = _first_version_id(fake_state)
        changes = get_changes(client, vid, after_etag="some-etag", limit=50)
        assert isinstance(changes, list)


class TestFillIdsRecursive:
    def test_fills_empty_string_ids(self) -> None:
        obj = {"id": "", "id_left": "", "id_right": ""}
        _fill_ids_recursive(obj)
        for key in ("id", "id_left", "id_right"):
            assert obj[key] != ""
            assert len(obj[key]) == 36  # UUID format

    def test_replaces_short_non_uuid_ids(self) -> None:
        """Short readable IDs like 'f1', 'ce1' should be replaced with real UUIDs."""
        obj = {"id": "f1", "clauses": [{"id_left": "cl1", "id_right": "cr1"}]}
        _fill_ids_recursive(obj)
        assert obj["id"] != "f1"
        assert len(obj["id"]) == 36
        assert obj["clauses"][0]["id_left"] != "cl1"
        assert obj["clauses"][0]["id_right"] != "cr1"

    def test_preserves_valid_uuids(self) -> None:
        valid = "550e8400-e29b-41d4-a716-446655440000"
        obj = {"id": valid}
        _fill_ids_recursive(obj)
        assert obj["id"] == valid

    def test_nested_structures(self) -> None:
        """Should replace short IDs at any nesting depth."""
        obj = {
            "branches": [
                {
                    "id": "br1",
                    "effects": [{"id": "ef1", "target": "x", "value": "1"}],
                }
            ]
        }
        _fill_ids_recursive(obj)
        assert obj["branches"][0]["id"] != "br1"
        assert obj["branches"][0]["effects"][0]["id"] != "ef1"

    def test_fills_none_ids(self) -> None:
        obj = {"id": None}
        _fill_ids_recursive(obj)
        assert obj["id"] is not None
        assert len(str(obj["id"])) == 36


class TestPatchVersion422:
    def test_422_raises_validation_conflict_error(self, tmp_path: Path) -> None:
        """A 422 from the API should raise ConflictError with [validation] prefix."""

        def handler(request: httpx.Request) -> httpx.Response:
            if "flow_versions" in str(request.url) and request.method == "PATCH":
                return httpx.Response(
                    422,
                    json={"detail": "1 validation error for RuleNodeMeta\nbranches\n  field required"},
                )
            return httpx.Response(404)

        write_test_config(tmp_path)
        write_test_credentials(tmp_path, "test-key")
        transport = httpx.MockTransport(handler)
        client = TktlClient(config_dir=tmp_path, base_url=FAKE_BASE_URL, transport=transport)

        with pytest.raises(ConflictError, match=r"\[validation\]"):
            patch_version(client, "any-version-id", body={"name": "x"})
