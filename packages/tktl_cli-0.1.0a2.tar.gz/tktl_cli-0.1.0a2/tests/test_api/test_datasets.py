"""Tests for dataset API layer."""

from __future__ import annotations

import json
from unittest.mock import patch

import httpx
import pytest

from tktl.api.datasets import create_download_job, download_s3_file, get_dataset_info, get_job_status
from tktl.models.errors import NotFoundError


def _resp(status_code: int, **kwargs) -> httpx.Response:
    """Create a Response with a dummy request attached (needed for raise_for_status)."""
    r = httpx.Response(status_code, **kwargs)
    r._request = httpx.Request("GET", "https://fake.com")
    return r


class TestGetDatasetInfo:
    def test_returns_info_and_etag(self):
        resp = _resp(200, json={"id": "ds-1", "etag": "etag-abc", "rows_total": 10})
        with patch("tktl.api.datasets.httpx.get", return_value=resp):
            info, etag = get_dataset_info("key", "https://fake.com", "ds-1")
        assert info is not None
        assert info["etag"] == "etag-abc"
        assert etag == "etag-abc"

    def test_returns_none_on_304(self):
        resp = _resp(304)
        with patch("tktl.api.datasets.httpx.get", return_value=resp):
            info, etag = get_dataset_info("key", "https://fake.com", "ds-1", etag="old-etag")
        assert info is None
        assert etag == "old-etag"

    def test_404_raises_not_found(self):
        resp = _resp(404, json={"detail": "Not found"})
        with patch("tktl.api.datasets.httpx.get", return_value=resp):
            with pytest.raises(NotFoundError):
                get_dataset_info("key", "https://fake.com", "ds-missing")


class TestCreateDownloadJob:
    def test_returns_job(self):
        resp = _resp(200, json={"id": "job-1", "status": "PENDING", "type": "download"})
        with patch("tktl.api.datasets.httpx.post", return_value=resp):
            job = create_download_job("key", "https://fake.com", "flow-1", "ds-1")
        assert job["id"] == "job-1"
        assert job["status"] == "PENDING"

    def test_404_raises_not_found(self):
        resp = _resp(404, json={"detail": "Not found"})
        with patch("tktl.api.datasets.httpx.post", return_value=resp):
            with pytest.raises(NotFoundError):
                create_download_job("key", "https://fake.com", "flow-1", "ds-missing")


class TestGetJobStatus:
    def test_returns_status(self):
        resp = _resp(
            200,
            json={
                "id": "job-1",
                "status": "COMPLETED",
                "response": {"bucket": "b", "key": "k", "s3_url": "https://s3.com/file"},
            },
        )
        with patch("tktl.api.datasets.httpx.get", return_value=resp):
            job = get_job_status("key", "https://fake.com", "job-1")
        assert job["status"] == "COMPLETED"
        assert job["response"]["s3_url"] == "https://s3.com/file"

    def test_404_raises_not_found(self):
        resp = _resp(404, json={"detail": "Not found"})
        with patch("tktl.api.datasets.httpx.get", return_value=resp):
            with pytest.raises(NotFoundError):
                get_job_status("key", "https://fake.com", "job-missing")


class TestDownloadS3File:
    def test_returns_bytes(self):
        content = json.dumps([{"a": 1}, {"a": 2}]).encode()
        resp = _resp(200, content=content)
        with patch("tktl.api.datasets.httpx.get", return_value=resp):
            result = download_s3_file("https://s3.com/file")
        assert result == content
