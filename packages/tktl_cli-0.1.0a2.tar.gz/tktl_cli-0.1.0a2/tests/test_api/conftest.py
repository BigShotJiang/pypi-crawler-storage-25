"""Shared fixtures for API tests — bridges async fake ASGI app to sync TktlClient."""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import TYPE_CHECKING

import httpx

from tests.fake_api.app import create_fake_app

if TYPE_CHECKING:
    from tests.fake_api.state import FakeState

FAKE_BASE_URL = "https://fake-flow-api.taktile.com"


def make_sync_transport(fake_state: FakeState) -> httpx.MockTransport:
    """Create a sync MockTransport that forwards requests to the async fake ASGI app.

    This bridges the sync httpx.Client used by TktlClient with the async
    Starlette fake API server used in tests.
    """
    app = create_fake_app(fake_state)
    async_transport = httpx.ASGITransport(app=app)

    def handler(request: httpx.Request) -> httpx.Response:
        # Run the async transport handler synchronously
        async def do_request() -> httpx.Response:
            async_client = httpx.AsyncClient(transport=async_transport, base_url=FAKE_BASE_URL)
            resp = await async_client.request(
                method=request.method,
                url=str(request.url),
                headers=dict(request.headers),
                content=request.content,
            )
            return resp

        # Use a fresh event loop since we're in sync context
        loop = asyncio.new_event_loop()
        try:
            resp = loop.run_until_complete(do_request())
        finally:
            loop.close()

        return httpx.Response(
            status_code=resp.status_code,
            headers=dict(resp.headers),
            content=resp.content,
        )

    return httpx.MockTransport(handler)


def write_test_config(tmp_path: Path, flow_api_url: str | None = None) -> None:
    config_file = tmp_path / "config.json"
    config_file.write_text(json.dumps({"flow_api_url": flow_api_url}))


def write_test_credentials(tmp_path: Path, api_key: str) -> None:
    cred_file = tmp_path / "credentials.json"
    cred_file.write_text(json.dumps({"api_key": api_key}))
