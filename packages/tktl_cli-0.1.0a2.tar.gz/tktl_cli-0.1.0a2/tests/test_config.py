from pathlib import Path

from tktl.config import Config, Credentials


class TestConfig:
    def test_default_values(self, tmp_path: Path):
        cfg = Config(config_dir=tmp_path)
        assert cfg.get("env") == "sandbox"
        assert cfg.get("flow_api_url") is None
        assert cfg.get("taktile_api_url") is None

    def test_set_and_get(self, tmp_path: Path):
        cfg = Config(config_dir=tmp_path)
        cfg.set("org", "my-org")
        assert cfg.get("org") == "my-org"

    def test_persistence(self, tmp_path: Path):
        cfg1 = Config(config_dir=tmp_path)
        cfg1.set("org", "my-org")
        cfg1.set("workspace", "my-ws")
        cfg1.save()

        cfg2 = Config(config_dir=tmp_path)
        cfg2.load()
        assert cfg2.get("org") == "my-org"
        assert cfg2.get("workspace") == "my-ws"

    def test_load_missing_file(self, tmp_path: Path):
        cfg = Config(config_dir=tmp_path)
        cfg.load()  # should not raise
        assert cfg.get("env") == "sandbox"

    def test_config_file_path(self, tmp_path: Path):
        cfg = Config(config_dir=tmp_path)
        cfg.set("org", "x")
        cfg.save()
        assert (tmp_path / "config.json").exists()

    def test_get_all(self, tmp_path: Path):
        cfg = Config(config_dir=tmp_path)
        cfg.set("org", "my-org")
        cfg.set("workspace", "my-ws")
        all_config = cfg.get_all()
        assert all_config["org"] == "my-org"
        assert all_config["workspace"] == "my-ws"
        assert "env" in all_config

    def test_telemetry_default_true(self, tmp_path: Path):
        cfg = Config(config_dir=tmp_path)
        assert cfg.get("telemetry") is True

    def test_telemetry_can_be_disabled(self, tmp_path: Path):
        cfg = Config(config_dir=tmp_path)
        cfg.set("telemetry", False)
        assert cfg.get("telemetry") is False

    def test_posthog_api_key_default_none(self, tmp_path: Path):
        cfg = Config(config_dir=tmp_path)
        assert cfg.get("posthog_api_key") is None

    def test_posthog_host_default_none(self, tmp_path: Path):
        cfg = Config(config_dir=tmp_path)
        assert cfg.get("posthog_host") is None


class TestCredentials:
    def test_store_and_load(self, tmp_path: Path):
        creds = Credentials(config_dir=tmp_path)
        creds.store("sk-test-key-123")

        creds2 = Credentials(config_dir=tmp_path)
        creds2.load()
        assert creds2.api_key == "sk-test-key-123"

    def test_delete(self, tmp_path: Path):
        creds = Credentials(config_dir=tmp_path)
        creds.store("sk-test-key")
        creds.delete()
        assert not (tmp_path / "credentials.json").exists()

        creds2 = Credentials(config_dir=tmp_path)
        creds2.load()
        assert creds2.api_key is None

    def test_file_permissions(self, tmp_path: Path):
        creds = Credentials(config_dir=tmp_path)
        creds.store("sk-secret")
        cred_file = tmp_path / "credentials.json"
        mode = oct(cred_file.stat().st_mode & 0o777)
        assert mode == "0o600"

    def test_load_missing_file(self, tmp_path: Path):
        creds = Credentials(config_dir=tmp_path)
        creds.load()  # should not raise
        assert creds.api_key is None

    def test_delete_missing_file(self, tmp_path: Path):
        creds = Credentials(config_dir=tmp_path)
        creds.delete()  # should not raise
