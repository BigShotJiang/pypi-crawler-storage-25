"""In-memory state for the fake Flow API server."""

from __future__ import annotations

import uuid
from copy import deepcopy
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any


@dataclass
class FakeDatasetColumn:
    name: str
    desired_type: str
    use_subflow_mocks: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {"name": self.name, "desired_type": self.desired_type, "use_subflow_mocks": self.use_subflow_mocks}


@dataclass
class FakeDatasetRow:
    id: str
    input_data: dict[str, Any]
    output_data: dict[str, Any] | None = None
    mock_data: dict[str, Any] | None = None
    meta_data: dict[str, Any] | None = None
    outcome_data: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"id": self.id, "input_data": self.input_data}
        if self.output_data is not None:
            d["output_data"] = self.output_data
        if self.mock_data is not None:
            d["mock_data"] = self.mock_data
        if self.meta_data is not None:
            d["meta_data"] = self.meta_data
        if self.outcome_data is not None:
            d["outcome_data"] = self.outcome_data
        return d


@dataclass
class FakeDataset:
    dataset_id: str
    flow_id: str
    name: str
    etag: str
    rows: list[dict[str, Any]]
    # Rich column metadata for CRUD tests
    input_columns: list[FakeDatasetColumn] = field(default_factory=list)
    output_columns: list[FakeDatasetColumn] = field(default_factory=list)
    mock_columns: list[FakeDatasetColumn] = field(default_factory=list)
    meta_columns: list[FakeDatasetColumn] = field(default_factory=list)
    outcome_columns: list[FakeDatasetColumn] = field(default_factory=list)
    source: str = "scratch"
    purpose: str = "test_run"
    created_at: str = "2026-01-01T00:00:00Z"
    updated_at: str = "2026-01-01T00:00:00Z"
    # Structured rows (parallel to legacy rows for CRUD)
    dataset_rows: list[FakeDatasetRow] = field(default_factory=list)

    def to_dataset_dict(self) -> dict[str, Any]:
        return {
            "id": self.dataset_id,
            "name": self.name,
            "flow_id": self.flow_id,
            "etag": self.etag,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "source": self.source,
            "purpose": self.purpose,
            "input_columns": [c.to_dict() for c in self.input_columns],
            "output_columns": [c.to_dict() for c in self.output_columns],
            "mock_columns": [c.to_dict() for c in self.mock_columns],
            "meta_columns": [c.to_dict() for c in self.meta_columns],
            "outcome_columns": [c.to_dict() for c in self.outcome_columns],
            "row_count": len(self.dataset_rows) or len(self.rows),
        }

    def to_summary_dict(self) -> dict[str, Any]:
        return {
            "id": self.dataset_id,
            "name": self.name,
            "flow_id": self.flow_id,
            "source": self.source,
            "purpose": self.purpose,
            "row_count": len(self.dataset_rows) or len(self.rows),
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }


@dataclass
class FakeState:
    workspace_id: str = "ws_00000000-0000-0000-0000-000000000001"
    flows: dict[str, dict[str, Any]] = field(default_factory=dict)  # flow_id -> flow dict
    versions: dict[str, dict[str, Any]] = field(default_factory=dict)  # version_id -> version dict (v2 format)
    datasets: dict[str, FakeDataset] = field(default_factory=dict)  # dataset_id -> FakeDataset
    connections: dict[str, dict[str, Any]] = field(default_factory=dict)  # connection_id -> connection dict
    comments: dict[str, dict[str, Any]] = field(default_factory=dict)  # comment_id -> comment dict
    file_uploads: dict[str, dict[str, Any]] = field(default_factory=dict)  # upload_id -> upload dict
    etag_counter: int = 0

    def next_etag(self) -> str:
        self.etag_counter += 1
        return str(self.etag_counter)

    def get_flow_by_slug(self, workspace_id: str, slug: str) -> dict[str, Any] | None:
        for flow in self.flows.values():
            if flow.get("slug") == slug and flow.get("workspace_id") == workspace_id:
                return deepcopy(flow)
        return None

    def get_flows(self, workspace_id: str) -> list[dict[str, Any]]:
        return [deepcopy(f) for f in self.flows.values() if f.get("workspace_id") == workspace_id]

    def get_version(self, version_id: str) -> dict[str, Any] | None:
        v = self.versions.get(version_id)
        return deepcopy(v) if v else None

    def get_versions_for_flow(self, flow_id: str) -> list[dict[str, Any]]:
        return [deepcopy(v) for v in self.versions.values() if v.get("_flow_id") == flow_id]

    def new_id(self) -> str:
        return str(uuid.uuid4())

    def now(self) -> str:
        return datetime.now(UTC).isoformat()
