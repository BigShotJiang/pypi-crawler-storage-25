"""RFC 7396 JSON Merge Patch implementation."""

from __future__ import annotations

from copy import deepcopy
from typing import Any


def merge_patch(target: dict[str, Any], patch: dict[str, Any]) -> dict[str, Any]:
    """Apply a JSON Merge Patch to a target dict. Returns a new dict."""
    result = deepcopy(target)
    for key, value in patch.items():
        if value is None:
            result.pop(key, None)
        elif isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = merge_patch(result[key], value)
        else:
            result[key] = deepcopy(value)
    return result
