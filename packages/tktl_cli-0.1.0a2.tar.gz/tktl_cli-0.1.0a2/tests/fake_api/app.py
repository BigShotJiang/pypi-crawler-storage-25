"""Fake Flow API Starlette application."""

from __future__ import annotations

from typing import TYPE_CHECKING

from starlette.applications import Starlette
from starlette.routing import Route

from tests.fake_api.routes import (
    append_dataset_rows,
    create_connection,
    create_dataset,
    create_dataset_job,
    create_file_upload,
    create_flow,
    create_flow_version,
    create_resource_config,
    decide_flow,
    delete_comment,
    delete_dataset,
    delete_dataset_columns,
    delete_dataset_row,
    delete_flow_version,
    download_dataset_as_file,
    download_fake_s3_dataset,
    duplicate_flow_version,
    fake_s3_upload,
    fill_dataset_column,
    get_comment_summary,
    get_comments,
    get_connections,
    get_dataset,
    get_dataset_info,
    get_file_upload_status,
    get_flow_by_slug,
    get_flow_version_changes,
    get_flow_version_v2,
    get_flows,
    get_workspace,
    list_datasets,
    patch_dataset,
    patch_flow_version,
    put_comment,
    put_flow_version,
    update_connection_secrets,
    update_dataset_row,
    upsert_dataset_columns,
)

if TYPE_CHECKING:
    from tests.fake_api.state import FakeState


def create_fake_app(state: FakeState) -> Starlette:
    routes = [
        Route("/api/v1/flows", get_flows, methods=["GET"]),
        Route("/api/v1/flows", create_flow, methods=["POST"]),
        Route(
            "/api/v1/flows/workspace_id/{workspace_id}/slug/{slug}",
            get_flow_by_slug,
            methods=["GET"],
        ),
        Route("/api/v2/flow_versions/{id}", get_flow_version_v2, methods=["GET"]),
        Route("/api/v2/flow_versions/{id}", put_flow_version, methods=["PUT"]),
        Route("/api/v1/flow_versions/{id}", patch_flow_version, methods=["PATCH"]),
        Route("/api/v1/flow_versions", create_flow_version, methods=["POST"]),
        Route("/api/v1/flow_versions/{id}/duplicate", duplicate_flow_version, methods=["POST"]),
        Route("/api/v1/flow_versions/{id}", delete_flow_version, methods=["DELETE"]),
        Route("/api/v2/flow_versions/{id}/changes", get_flow_version_changes, methods=["GET"]),
        Route("/api/v1/workspaces/{workspace_id}", get_workspace, methods=["GET"]),
        Route("/connect/api/v1/connections", get_connections, methods=["GET"]),
        Route("/connect/api/v1/connections", create_connection, methods=["POST"]),
        Route("/connect/api/v1/connections/{id}/resources", create_resource_config, methods=["POST"]),
        Route("/connect/api/v1/connections/{id}/secrets", update_connection_secrets, methods=["PATCH"]),
        Route("/run/api/v1/flows/{slug}/{env}/decide", decide_flow, methods=["POST"]),
        # Comment endpoints
        Route("/api/v1/comments", get_comments, methods=["GET"]),
        Route("/api/v1/comments/summary/{flow_version_id}", get_comment_summary, methods=["GET"]),
        Route("/api/v1/comments/{comment_id}", put_comment, methods=["PUT"]),
        Route("/api/v1/comments/{comment_id}", delete_comment, methods=["DELETE"]),
        # Legacy dataset endpoints (for batch download)
        Route("/datasets/api/v1/datasets/info/{dataset_id}", get_dataset_info, methods=["GET"]),
        Route("/datasets/api/v1/dataset_file_uploads", create_file_upload, methods=["POST"]),
        Route(
            "/datasets/api/v1/dataset_file_uploads/{upload_id}",
            get_file_upload_status,
            methods=["GET"],
        ),
        Route("/dataset_jobs/api/v1/dataset_jobs", create_dataset_job, methods=["POST"]),
        # Fake S3 endpoints
        Route("/upload/{upload_id}", fake_s3_upload, methods=["POST"]),
        Route("/datasets/{dataset_id}.json", download_fake_s3_dataset, methods=["GET"]),
        # Dataset CRUD endpoints
        Route("/datasets/api/v1/datasets", list_datasets, methods=["GET"]),
        Route("/datasets/api/v1/datasets", create_dataset, methods=["POST"]),
        Route("/datasets/api/v1/datasets/{dataset_id}", get_dataset, methods=["GET"]),
        Route("/datasets/api/v1/datasets/{dataset_id}", patch_dataset, methods=["PATCH"]),
        Route("/datasets/api/v1/datasets/{dataset_id}", delete_dataset, methods=["DELETE"]),
        # Dataset rows
        Route("/datasets/api/v1/datasets/{dataset_id}/rows", append_dataset_rows, methods=["POST"]),
        Route("/datasets/api/v1/datasets/{dataset_id}/rows/{row_id}", update_dataset_row, methods=["PATCH"]),
        Route("/datasets/api/v1/datasets/{dataset_id}/rows/{row_id}", delete_dataset_row, methods=["DELETE"]),
        # Dataset columns
        Route("/datasets/api/v1/datasets/{dataset_id}/columns", upsert_dataset_columns, methods=["PUT"]),
        Route("/datasets/api/v1/datasets/{dataset_id}/columns", delete_dataset_columns, methods=["DELETE"]),
        Route(
            "/datasets/api/v1/datasets/{dataset_id}/columns/{group}/{name}",
            fill_dataset_column,
            methods=["PATCH"],
        ),
        # Dataset file
        Route("/datasets/api/v1/datasets/{dataset_id}/file", download_dataset_as_file, methods=["GET"]),
    ]

    app = Starlette(routes=routes)
    app.state.fake_state = state
    return app
