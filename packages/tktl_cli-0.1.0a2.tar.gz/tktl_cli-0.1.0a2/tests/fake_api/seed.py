"""Seed data builders for the fake API state."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Any

from tests.fake_api.state import FakeState


@dataclass
class SeedResourceConfig:
    name: str
    resource: str
    id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id or str(uuid.uuid4()),
            "name": self.name,
            "resource": self.resource,
            "configuration": {},
            "created_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
        }


@dataclass
class SeedConnection:
    name: str
    provider: str
    resource_configs: list[SeedResourceConfig] = field(default_factory=list)
    id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id or str(uuid.uuid4()),
            "name": self.name,
            "is_sandbox": False,
            "provider": self.provider,
            "enable_non_prod_configs": False,
            "data_retention": {"seconds": 86400},
            "resource_configs": [rc.to_dict() for rc in self.resource_configs],
            "created_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
        }


@dataclass
class SeedNode:
    id: str
    name: str
    type: str
    meta: dict[str, Any] | None = None

    def to_node_db(self) -> dict[str, Any]:
        node: dict[str, Any] = {"id": self.id, "name": self.name, "type": self.type}
        if self.meta is not None:
            node["meta"] = self.meta
        return node


@dataclass
class SeedEdge:
    start_node_id: str
    end_node_id: str

    def to_edge_db(self) -> dict[str, Any]:
        edge_id = str(uuid.uuid4())
        return {"id": edge_id, "start_node_id": self.start_node_id, "end_node_id": self.end_node_id}


@dataclass
class SeedNodeGroup:
    id: str
    name: str
    node_ids: list[str] = field(default_factory=list)
    meta: dict[str, Any] | None = None

    def to_group_db(self) -> dict[str, Any]:
        group: dict[str, Any] = {"id": self.id, "name": self.name, "node_ids": self.node_ids}
        if self.meta is not None:
            group["meta"] = self.meta
        return group


@dataclass
class SeedVersion:
    name: str
    status: str = "DRAFT"
    nodes: list[SeedNode] = field(default_factory=list)
    edges: list[SeedEdge] = field(default_factory=list)
    node_groups: list[SeedNodeGroup] = field(default_factory=list)
    parameters: list[dict[str, Any]] | None = None
    input_schema: dict[str, Any] | None = None
    output_schema: dict[str, Any] | None = None


@dataclass
class SeedFlow:
    slug: str
    name: str | None = None
    versions: list[SeedVersion] = field(default_factory=list)


def build_seed_state(
    flows: list[SeedFlow],
    workspace_id: str = "ws_00000000-0000-0000-0000-000000000001",
    connections: list[SeedConnection] | None = None,
) -> FakeState:
    state = FakeState(workspace_id=workspace_id)
    etag = 0

    # Seed connections
    for sc in connections or []:
        conn = sc.to_dict()
        state.connections[conn["id"]] = conn

    for sf in flows:
        flow_id = str(uuid.uuid4())
        flow_name = sf.name or sf.slug.replace("-", " ").title()

        version_ids: list[str] = []
        for sv in sf.versions:
            version_id = str(uuid.uuid4())
            version_ids.append(version_id)
            etag += 1

            # Build v2-style graph (dict-keyed)
            nodes_dict: dict[str, Any] = {}
            for sn in sv.nodes:
                nodes_dict[sn.id] = sn.to_node_db()

            edges_dict: dict[str, Any] = {}
            for se in sv.edges:
                edge = se.to_edge_db()
                edges_dict[edge["id"]] = edge

            groups_dict: dict[str, Any] = {}
            for sg in sv.node_groups:
                groups_dict[sg.id] = sg.to_group_db()

            version = {
                "id": version_id,
                "name": sv.name,
                "status": sv.status,
                "etag": str(etag),
                "created_at": "2026-01-01T00:00:00Z",
                "updated_at": "2026-03-17T10:00:00Z",
                "parameters": sv.parameters or [],
                "input_schema": sv.input_schema,
                "output_schema": sv.output_schema,
                "graph": {
                    "nodes": nodes_dict,
                    "edges": edges_dict,
                    "node_groups": groups_dict,
                },
                "locks": [],
                "_flow_id": flow_id,  # internal reference
            }
            state.versions[version_id] = version

        flow = {
            "id": flow_id,
            "slug": sf.slug,
            "name": flow_name,
            "workspace_id": workspace_id,
            "created_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-03-17T10:00:00Z",
            "default_version": version_ids[0] if version_ids else None,
            "default_sandbox_version": version_ids[0] if version_ids else None,
            "_version_ids": version_ids,
        }
        state.flows[flow_id] = flow

    state.etag_counter = etag
    return state
