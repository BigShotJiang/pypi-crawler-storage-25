from tests.fake_api.merge_patch import merge_patch


def test_add_key():
    assert merge_patch({"a": 1}, {"b": 2}) == {"a": 1, "b": 2}


def test_overwrite_key():
    assert merge_patch({"a": 1}, {"a": 2}) == {"a": 2}


def test_null_deletes_key():
    assert merge_patch({"a": 1, "b": 2}, {"a": None}) == {"b": 2}


def test_nested_merge():
    target = {"a": {"x": 1, "y": 2}}
    patch = {"a": {"y": 3, "z": 4}}
    assert merge_patch(target, patch) == {"a": {"x": 1, "y": 3, "z": 4}}


def test_nested_null_deletes():
    target = {"a": {"x": 1, "y": 2}}
    patch = {"a": {"x": None}}
    assert merge_patch(target, patch) == {"a": {"y": 2}}


def test_array_replaced_not_merged():
    target = {"a": [1, 2, 3]}
    patch = {"a": [4, 5]}
    assert merge_patch(target, patch) == {"a": [4, 5]}


def test_empty_patch():
    assert merge_patch({"a": 1}, {}) == {"a": 1}


def test_empty_target():
    assert merge_patch({}, {"a": 1}) == {"a": 1}


def test_deeply_nested():
    target = {"a": {"b": {"c": 1, "d": 2}}}
    patch = {"a": {"b": {"c": 3}}}
    assert merge_patch(target, patch) == {"a": {"b": {"c": 3, "d": 2}}}
