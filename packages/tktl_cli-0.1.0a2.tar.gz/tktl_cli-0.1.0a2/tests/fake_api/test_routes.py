"""Tests for the fake Flow API routes."""

from __future__ import annotations

from typing import TYPE_CHECKING

import httpx
import pytest

from tests.fake_api.app import create_fake_app
from tests.fake_api.seed import SeedFlow, SeedNode, SeedVersion, build_seed_state

if TYPE_CHECKING:
    from tests.fake_api.state import FakeState

BASE = "https://fake-flow-api.taktile.com"
WS = "ws_00000000-0000-0000-0000-000000000001"

pytestmark = pytest.mark.anyio


@pytest.fixture
def state() -> FakeState:
    return build_seed_state(
        flows=[
            SeedFlow(
                slug="credit-scoring",
                versions=[
                    SeedVersion(
                        name="v1",
                        status="PUBLISHED",
                        nodes=[
                            SeedNode(id="node_input", name="Input", type="input"),
                            SeedNode(
                                id="node_risk",
                                name="Risk Engine",
                                type="decision_table",
                                meta={"score_threshold": 500},
                            ),
                            SeedNode(id="node_output", name="Output", type="output"),
                        ],
                        parameters=[{"name": "threshold", "value": 0.8}],
                    ),
                    SeedVersion(name="v2-draft", status="DRAFT", nodes=[]),
                ],
            ),
        ],
    )


@pytest.fixture
def client(state: FakeState) -> httpx.AsyncClient:
    app = create_fake_app(state)
    transport = httpx.ASGITransport(app=app)
    return httpx.AsyncClient(transport=transport, base_url=BASE)


class TestGetFlows:
    async def test_returns_flows(self, client: httpx.AsyncClient):
        resp = await client.get(f"/api/v1/flows?workspace_id={WS}")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 1
        assert data[0]["slug"] == "credit-scoring"

    async def test_no_internal_fields(self, client: httpx.AsyncClient):
        resp = await client.get(f"/api/v1/flows?workspace_id={WS}")
        for flow in resp.json():
            assert not any(k.startswith("_") for k in flow)


class TestGetFlowBySlug:
    async def test_found(self, client: httpx.AsyncClient, state: FakeState):
        resp = await client.get(f"/api/v1/flows/workspace_id/{WS}/slug/credit-scoring")
        assert resp.status_code == 200
        data = resp.json()
        assert data["slug"] == "credit-scoring"
        assert "versions" in data
        assert len(data["versions"]) == 2

    async def test_not_found(self, client: httpx.AsyncClient):
        resp = await client.get(f"/api/v1/flows/workspace_id/{WS}/slug/nonexistent")
        assert resp.status_code == 404


class TestGetFlowVersionV2:
    async def test_returns_version(self, client: httpx.AsyncClient, state: FakeState):
        vid = next(iter(state.versions.keys()))
        resp = await client.get(f"/api/v2/flow_versions/{vid}")
        assert resp.status_code == 200
        data = resp.json()
        assert data["name"] == "v1"
        assert "graph" in data
        assert "node_risk" in data["graph"]["nodes"]

    async def test_304_not_modified(self, client: httpx.AsyncClient, state: FakeState):
        vid = next(iter(state.versions.keys()))
        etag = state.versions[vid]["etag"]
        resp = await client.get(f"/api/v2/flow_versions/{vid}", headers={"if-none-match": etag})
        assert resp.status_code == 304

    async def test_not_found(self, client: httpx.AsyncClient):
        resp = await client.get("/api/v2/flow_versions/nonexistent-id")
        assert resp.status_code == 404


class TestPatchFlowVersion:
    async def test_basic_patch(self, client: httpx.AsyncClient, state: FakeState):
        vid = next(iter(state.versions.keys()))
        etag = state.versions[vid]["etag"]
        resp = await client.patch(
            f"/api/v1/flow_versions/{vid}",
            json={"name": "v1-renamed"},
            headers={"if-match": etag},
        )
        assert resp.status_code == 200
        assert resp.json()["name"] == "v1-renamed"
        assert resp.json()["etag"] != etag

    async def test_graph_merge_patch(self, client: httpx.AsyncClient, state: FakeState):
        vid = next(iter(state.versions.keys()))
        etag = state.versions[vid]["etag"]
        resp = await client.patch(
            f"/api/v1/flow_versions/{vid}",
            json={
                "graph": {
                    "nodes": {
                        "node_risk": {
                            "meta": {"score_threshold": 750},
                        }
                    }
                }
            },
            headers={"if-match": etag},
        )
        assert resp.status_code == 200
        node = resp.json()["graph"]["nodes"]["node_risk"]
        assert node["meta"]["score_threshold"] == 750
        assert "node_input" in resp.json()["graph"]["nodes"]

    async def test_stale_etag_412(self, client: httpx.AsyncClient, state: FakeState):
        vid = next(iter(state.versions.keys()))
        resp = await client.patch(
            f"/api/v1/flow_versions/{vid}",
            json={"name": "updated"},
            headers={"if-match": "stale-etag"},
        )
        assert resp.status_code == 412

    async def test_lock_conflict(self, client: httpx.AsyncClient, state: FakeState):
        vid = next(iter(state.versions.keys()))
        etag = state.versions[vid]["etag"]

        # First: add a lock from session A
        resp1 = await client.patch(
            f"/api/v1/flow_versions/{vid}",
            json={
                "locks": {
                    "lock_1": {
                        "owner": "user_a",
                        "session": "session_a",
                        "resource_type": "node",
                        "resource_id": "node_risk",
                        "duration_secs": 300,
                    }
                }
            },
            headers={"if-match": etag, "session": "session_a"},
        )
        assert resp1.status_code == 200
        new_etag = resp1.json()["etag"]

        # Second: try to lock same node from session B
        resp2 = await client.patch(
            f"/api/v1/flow_versions/{vid}",
            json={
                "locks": {
                    "lock_2": {
                        "owner": "user_b",
                        "session": "session_b",
                        "resource_type": "node",
                        "resource_id": "node_risk",
                        "duration_secs": 300,
                    }
                }
            },
            headers={"if-match": new_etag, "session": "session_b"},
        )
        assert resp2.status_code == 409


class TestPutFlowVersion:
    async def test_replace(self, client: httpx.AsyncClient, state: FakeState):
        vid = next(iter(state.versions.keys()))
        etag = state.versions[vid]["etag"]
        resp = await client.put(
            f"/api/v2/flow_versions/{vid}?by_etag={etag}",
            json={
                "name": "v1-replaced",
                "status": "DRAFT",
                "graph": {"nodes": {}, "edges": {}, "node_groups": {}},
            },
        )
        assert resp.status_code == 200
        assert resp.json()["name"] == "v1-replaced"

    async def test_stale_etag_412(self, client: httpx.AsyncClient, state: FakeState):
        vid = next(iter(state.versions.keys()))
        resp = await client.put(
            f"/api/v2/flow_versions/{vid}?by_etag=wrong",
            json={"name": "x"},
        )
        assert resp.status_code == 412

    async def test_missing_by_etag(self, client: httpx.AsyncClient, state: FakeState):
        vid = next(iter(state.versions.keys()))
        resp = await client.put(f"/api/v2/flow_versions/{vid}", json={"name": "x"})
        assert resp.status_code == 400


class TestCreateFlowVersion:
    async def test_create(self, client: httpx.AsyncClient, state: FakeState):
        flow_id = next(iter(state.flows.keys()))
        resp = await client.post(
            "/api/v1/flow_versions",
            json={"flow_id": flow_id, "name": "v3-new", "status": "DRAFT"},
        )
        assert resp.status_code == 201
        assert resp.json()["name"] == "v3-new"
        assert resp.json()["status"] == "DRAFT"


class TestDuplicateFlowVersion:
    async def test_duplicate(self, client: httpx.AsyncClient, state: FakeState):
        vid = next(iter(state.versions.keys()))
        resp = await client.post(
            f"/api/v1/flow_versions/{vid}/duplicate",
            json={"name": "v1-copy"},
        )
        assert resp.status_code == 201
        assert resp.json()["name"] == "v1-copy"
        assert resp.json()["id"] != vid


class TestDeleteFlowVersion:
    async def test_delete(self, client: httpx.AsyncClient, state: FakeState):
        vid = next(iter(state.versions.keys()))
        resp = await client.delete(f"/api/v1/flow_versions/{vid}")
        assert resp.status_code == 204

        resp2 = await client.get(f"/api/v2/flow_versions/{vid}")
        assert resp2.status_code == 404
