"""Route handlers for the fake Flow API."""

from __future__ import annotations

import csv
import io
import json
import uuid
from copy import deepcopy
from typing import TYPE_CHECKING, Any

from starlette.responses import JSONResponse, Response

from tests.fake_api.merge_patch import merge_patch
from tests.fake_api.state import FakeDataset, FakeDatasetColumn, FakeDatasetRow

if TYPE_CHECKING:
    from starlette.requests import Request

    from tests.fake_api.state import FakeState


async def get_flows(request: Request) -> Response:
    state: FakeState = request.app.state.fake_state
    workspace_id = request.query_params.get("workspace_id", state.workspace_id)
    flows = state.get_flows(workspace_id)
    # Strip internal fields
    result = [{k: v for k, v in f.items() if not k.startswith("_")} for f in flows]
    return JSONResponse(result)


async def create_flow(request: Request) -> Response:
    """Create a new flow with an initial draft version."""
    state: FakeState = request.app.state.fake_state
    body = await request.json()

    flow_id = str(uuid.uuid4())
    workspace_id = body.get("workspace_id", state.workspace_id)
    slug = body.get("slug", "")
    flow_name = body.get("name", slug)
    initial_version_name = body.get("initial_version_name", "v1")

    # Create initial version
    version_id = str(uuid.uuid4())
    etag = state.next_etag()
    version = {
        "id": version_id,
        "name": initial_version_name,
        "status": "DRAFT",
        "etag": etag,
        "created_at": state.now(),
        "updated_at": state.now(),
        "parameters": [],
        "input_schema": None,
        "output_schema": None,
        "graph": {
            "nodes": {
                "node_input": {"id": "node_input", "name": "Input", "type": "input", "meta": {}},
                "node_output": {"id": "node_output", "name": "Output", "type": "output", "meta": {}},
            },
            "edges": {
                str(uuid.uuid4()): {
                    "start_node_id": "node_input",
                    "end_node_id": "node_output",
                    "meta": {"is_split_edge": False},
                },
            },
            "node_groups": {},
        },
        "locks": [],
        "_flow_id": flow_id,
    }
    state.versions[version_id] = version

    flow = {
        "id": flow_id,
        "slug": slug,
        "name": flow_name,
        "workspace_id": workspace_id,
        "created_at": state.now(),
        "updated_at": state.now(),
        "default_version": version_id,
        "default_sandbox_version": version_id,
        "_version_ids": [version_id],
    }
    state.flows[flow_id] = flow

    result = {k: v for k, v in flow.items() if not k.startswith("_")}
    result["versions"] = [{"id": version_id, "name": initial_version_name, "status": "DRAFT", "etag": etag}]
    return JSONResponse(result, status_code=200)


async def get_flow_by_slug(request: Request) -> Response:
    state: FakeState = request.app.state.fake_state
    workspace_id = request.path_params["workspace_id"]
    slug = request.path_params["slug"]

    flow = state.get_flow_by_slug(workspace_id, slug)
    if flow is None:
        return JSONResponse({"detail": f"Flow with slug '{slug}' not found"}, status_code=404)

    # Embed version summaries
    versions = state.get_versions_for_flow(flow["id"])
    flow["versions"] = [
        {"id": v["id"], "name": v["name"], "status": v["status"], "etag": v.get("etag")} for v in versions
    ]

    result = {k: v for k, v in flow.items() if not k.startswith("_")}
    return JSONResponse(result)


async def get_flow_version_v2(request: Request) -> Response:
    state: FakeState = request.app.state.fake_state
    version_id = request.path_params["id"]

    version = state.get_version(version_id)
    if version is None:
        return JSONResponse({"detail": "Version not found"}, status_code=404)

    # Handle if-none-match (304)
    if_none_match = request.headers.get("if-none-match")
    if if_none_match and if_none_match == version.get("etag"):
        return Response(status_code=304)

    result = {k: v for k, v in version.items() if not k.startswith("_")}
    return JSONResponse(result)


async def patch_flow_version(request: Request) -> Response:
    state: FakeState = request.app.state.fake_state
    version_id = request.path_params["id"]

    version = state.versions.get(version_id)
    if version is None:
        return JSONResponse({"detail": "Version not found"}, status_code=404)

    # Check if-match (ETag)
    if_match = request.headers.get("if-match") or request.headers.get("x-if-match")
    if if_match and if_match != version["etag"]:
        return JSONResponse(
            {"detail": "ETag mismatch: version was modified since your last read"},
            status_code=412,
        )

    body = await request.json()

    # Check for lock conflicts
    if "locks" in body and isinstance(body["locks"], dict):
        _err = _check_lock_conflicts(version, body["locks"], request.headers.get("session", ""))
        if _err:
            return JSONResponse({"detail": _err}, status_code=409)

    # Apply merge patch
    new_version = _apply_version_patch(version, body)
    new_version["etag"] = state.next_etag()
    new_version["updated_at"] = state.now()

    state.versions[version_id] = new_version

    result = {k: v for k, v in new_version.items() if not k.startswith("_")}
    return JSONResponse(result)


async def put_flow_version(request: Request) -> Response:
    state: FakeState = request.app.state.fake_state
    version_id = request.path_params["id"]

    version = state.versions.get(version_id)
    if version is None:
        return JSONResponse({"detail": "Version not found"}, status_code=404)

    by_etag = request.query_params.get("by_etag")
    if not by_etag:
        return JSONResponse({"detail": "by_etag query parameter is required"}, status_code=400)

    if by_etag != version["etag"]:
        return JSONResponse({"detail": "ETag mismatch"}, status_code=412)

    body = await request.json()
    flow_id = version["_flow_id"]

    new_version = deepcopy(body)
    new_version["id"] = version_id
    new_version["_flow_id"] = flow_id
    new_version["etag"] = state.next_etag()
    new_version["updated_at"] = state.now()
    new_version.setdefault("locks", [])

    state.versions[version_id] = new_version

    result = {k: v for k, v in new_version.items() if not k.startswith("_")}
    return JSONResponse(result)


async def create_flow_version(request: Request) -> Response:
    state: FakeState = request.app.state.fake_state
    body = await request.json()

    flow_id = body.get("flow_id")
    if flow_id not in state.flows:
        return JSONResponse({"detail": "Flow not found"}, status_code=404)

    version_id = state.new_id()
    version = {
        "id": version_id,
        "name": body.get("name", "unnamed"),
        "status": body.get("status", "DRAFT"),
        "etag": state.next_etag(),
        "created_at": state.now(),
        "updated_at": state.now(),
        "parameters": body.get("parameters", []),
        "input_schema": body.get("input_schema"),
        "output_schema": body.get("output_schema"),
        "graph": {"nodes": {}, "edges": {}, "node_groups": {}},
        "locks": [],
        "_flow_id": flow_id,
    }
    state.versions[version_id] = version
    state.flows[flow_id]["_version_ids"].append(version_id)

    result = {k: v for k, v in version.items() if not k.startswith("_")}
    return JSONResponse(result, status_code=201)


async def duplicate_flow_version(request: Request) -> Response:
    state: FakeState = request.app.state.fake_state
    version_id = request.path_params["id"]

    version = state.versions.get(version_id)
    if version is None:
        return JSONResponse({"detail": "Version not found"}, status_code=404)

    body = await request.json()
    new_version_id = state.new_id()
    new_version = deepcopy(version)
    new_version["id"] = new_version_id
    new_version["name"] = body.get("name", version["name"] + " (copy)")
    new_version["status"] = body.get("status", "DRAFT")
    new_version["etag"] = state.next_etag()
    new_version["created_at"] = state.now()
    new_version["updated_at"] = state.now()
    new_version["locks"] = []

    flow_id = version["_flow_id"]
    state.versions[new_version_id] = new_version
    state.flows[flow_id]["_version_ids"].append(new_version_id)

    result = {k: v for k, v in new_version.items() if not k.startswith("_")}
    return JSONResponse(result, status_code=201)


async def delete_flow_version(request: Request) -> Response:
    state: FakeState = request.app.state.fake_state
    version_id = request.path_params["id"]

    if version_id not in state.versions:
        return JSONResponse({"detail": "Version not found"}, status_code=404)

    version = state.versions.pop(version_id)
    flow_id = version["_flow_id"]
    if flow_id in state.flows:
        state.flows[flow_id]["_version_ids"] = [
            vid for vid in state.flows[flow_id]["_version_ids"] if vid != version_id
        ]

    return Response(status_code=204)


async def get_flow_version_changes(request: Request) -> Response:
    # Simplified: return empty list (change tracking not implemented in fake)
    return JSONResponse([])


async def get_connections(request: Request) -> Response:
    """Return workspace connections."""
    state: FakeState = request.app.state.fake_state
    return JSONResponse(list(state.connections.values()))


async def create_connection(request: Request) -> Response:
    """Create a new connection."""
    state: FakeState = request.app.state.fake_state
    body = await request.json()
    connection_id = str(uuid.uuid4())
    connection = {
        "id": connection_id,
        "name": body.get("name", ""),
        "provider": body.get("provider", "custom"),
        "is_sandbox": body.get("is_sandbox", False),
        "configuration": body.get("configuration", {}),
        "resource_configs": [],
        "created_at": state.now(),
        "updated_at": state.now(),
    }
    state.connections[connection_id] = connection
    return JSONResponse(connection, status_code=201)


async def create_resource_config(request: Request) -> Response:
    """Create a resource config on a connection."""
    state: FakeState = request.app.state.fake_state
    connection_id = request.path_params["id"]
    connection = state.connections.get(connection_id)
    if connection is None:
        return JSONResponse({"detail": "Connection not found"}, status_code=404)

    body = await request.json()
    rc_id = str(uuid.uuid4())
    resource_config = {
        "id": rc_id,
        "name": body.get("name", ""),
        "resource": body.get("resource", "http"),
        "connection_config_id": connection_id,
        "configuration": body.get("configuration", {}),
        "created_at": state.now(),
        "updated_at": state.now(),
    }
    connection["resource_configs"].append(resource_config)
    return JSONResponse(resource_config, status_code=201)


async def update_connection_secrets(request: Request) -> Response:
    """Update secrets on a connection."""
    state: FakeState = request.app.state.fake_state
    connection_id = request.path_params["id"]
    connection = state.connections.get(connection_id)
    if connection is None:
        return JSONResponse({"detail": "Connection not found"}, status_code=404)

    secrets = await request.json()
    connection["secrets"] = secrets
    return JSONResponse(secrets, status_code=200)


async def get_workspace(request: Request) -> Response:
    """Return workspace info with base_url for the Decide API."""
    state: FakeState = request.app.state.fake_state
    workspace_id = request.path_params["workspace_id"]
    if workspace_id != state.workspace_id:
        return JSONResponse({"detail": "Workspace not found"}, status_code=404)
    return JSONResponse(
        {
            "id": workspace_id,
            "name": "fake-workspace",
            "base_url": "https://fake-decide.taktile.com",
            "organization_id": "org_fake",
        }
    )


async def decide_flow(request: Request) -> Response:
    """Fake Decide API endpoint. Echoes input data back as a successful decision."""
    body = await request.json()
    slug = request.path_params.get("slug", "unknown")
    env = request.path_params.get("env", "sandbox")
    version = body.get("metadata", {}).get("version")
    return JSONResponse(
        {
            "data": body.get("data", {}),
            "status": "success",
            "metadata": {
                "environment": env,
                "version": version,
                "flow_slug": slug,
                "decision_id": "fake-decision-id",
            },
        }
    )


def _check_lock_conflicts(
    version: dict[str, Any],
    incoming_locks: dict[str, Any],
    session: str,
) -> str | None:
    """Check if any incoming lock conflicts with existing locks. Returns error message or None."""
    existing_locks = version.get("locks", [])
    if isinstance(existing_locks, list):
        for existing in existing_locks:
            for _lock_id, new_lock in incoming_locks.items():
                if new_lock is None:
                    continue  # deletion
                if (
                    existing.get("resource_type") == new_lock.get("resource_type")
                    and existing.get("resource_id") == new_lock.get("resource_id")
                    and existing.get("session") != session
                ):
                    return (
                        f"Resource {new_lock.get('resource_type')} {new_lock.get('resource_id')} "
                        f"is locked by session '{existing.get('session')}'"
                    )
    return None


def _apply_version_patch(version: dict[str, Any], body: dict[str, Any]) -> dict[str, Any]:
    """Apply a FlowVersionUpdate merge patch to a version."""
    result = deepcopy(version)

    # Handle graph merge patch specially
    if "graph" in body:
        graph_patch = body["graph"]
        if "nodes" in graph_patch:
            result["graph"]["nodes"] = merge_patch(result["graph"].get("nodes", {}), graph_patch["nodes"])
        if "edges" in graph_patch:
            result["graph"]["edges"] = merge_patch(result["graph"].get("edges", {}), graph_patch["edges"])
        if "node_groups" in graph_patch:
            result["graph"]["node_groups"] = merge_patch(
                result["graph"].get("node_groups", {}), graph_patch["node_groups"]
            )

    # Handle locks (dict merge patch — null deletes)
    if "locks" in body and isinstance(body["locks"], dict):
        existing_locks_by_id: dict[str, Any] = {}
        if isinstance(result.get("locks"), list):
            for lock in result["locks"]:
                existing_locks_by_id[lock.get("id", "")] = lock

        for lock_id, lock_data in body["locks"].items():
            if lock_data is None:
                existing_locks_by_id.pop(lock_id, None)
            else:
                lock_data["id"] = lock_id
                lock_data.setdefault("timestamp", version.get("updated_at", ""))
                existing_locks_by_id[lock_id] = lock_data

        result["locks"] = list(existing_locks_by_id.values())

    # Handle top-level fields
    for key in ("name", "status", "parameters", "input_schema", "output_schema", "meta"):
        if key in body:
            result[key] = body[key]

    return result


# ---------------------------------------------------------------------------
# Dataset endpoints
# ---------------------------------------------------------------------------


async def get_dataset_info(request: Request) -> Response:
    """Fake dataset info endpoint with ETag support."""
    state: FakeState = request.app.state.fake_state
    dataset_id = request.path_params["dataset_id"]
    dataset = state.datasets.get(dataset_id)
    if dataset is None:
        return JSONResponse({"detail": "Not found"}, status_code=404)

    if_none_match = request.headers.get("if-none-match")
    if if_none_match and if_none_match == dataset.etag:
        return Response(status_code=304)

    return JSONResponse(
        {
            "id": dataset.dataset_id,
            "etag": dataset.etag,
            "rows_total": len(dataset.rows),
            "size_total_estimated_bytes": len(json.dumps(dataset.rows)),
        }
    )


async def create_dataset_job(request: Request) -> Response:
    """Fake dataset job creation — returns COMPLETED immediately with fake S3 URL."""
    state: FakeState = request.app.state.fake_state
    body = await request.json()
    job_type = body.get("type")
    flow_id = body.get("flow_id")

    if job_type != "download":
        return JSONResponse({"detail": "Only download jobs are supported in tests"}, status_code=422)

    dataset_id = body.get("request", {}).get("dataset_id")
    dataset = state.datasets.get(dataset_id)
    if dataset is None:
        return JSONResponse({"detail": "Dataset not found"}, status_code=404)

    job_id = str(uuid.uuid4())
    # Return COMPLETED immediately with an internal path for fake S3 download
    return JSONResponse(
        {
            "id": job_id,
            "status": "COMPLETED",
            "progress": 100,
            "type": "download",
            "flow_id": flow_id,
            "created_at": "2026-03-20T10:00:00Z",
            "updated_at": "2026-03-20T10:00:01Z",
            "created_by": "fake-user",
            "hidden": False,
            "request": {"dataset_id": dataset_id, "format": body.get("request", {}).get("format", "json")},
            "response": {
                "bucket": "fake-bucket",
                "key": f"datasets/{dataset_id}.json",
                "s3_url": f"https://fake-s3.taktile.com/datasets/{dataset_id}.json",
            },
            "error": None,
        }
    )


async def get_dataset_job(request: Request) -> Response:
    """Fake get job by id — not needed since we return COMPLETED inline, but included for completeness."""
    return JSONResponse({"detail": "Not implemented in fake"}, status_code=501)


# ---------------------------------------------------------------------------
# Comment endpoints
# ---------------------------------------------------------------------------


async def get_comments(request: Request) -> Response:
    """List comments for a flow version, optionally filtered by resource_type/resource_id."""
    state: FakeState = request.app.state.fake_state
    flow_version_id = request.query_params.get("flow_version_id")
    resource_type = request.query_params.get("resource_type")
    resource_id = request.query_params.get("resource_id")

    results = []
    for comment in state.comments.values():
        if comment.get("flow_version") != flow_version_id:
            continue
        if resource_type and comment.get("resource_type") != resource_type:
            continue
        if resource_id and comment.get("resource_id") != resource_id:
            continue
        results.append(comment)
    return JSONResponse(results)


async def get_comment_summary(request: Request) -> Response:
    """Return per-node comment counts for a flow version."""
    state: FakeState = request.app.state.fake_state
    flow_version_id = request.path_params["flow_version_id"]

    counts: dict[str, int] = {}
    for comment in state.comments.values():
        if comment.get("flow_version") != flow_version_id:
            continue
        if comment.get("resource_type") != "node":
            continue
        node_id = comment.get("resource_id", "")
        counts[node_id] = counts.get(node_id, 0) + 1

    return JSONResponse([{"node_id": nid, "comments": cnt} for nid, cnt in counts.items()])


async def put_comment(request: Request) -> Response:
    """Create a comment (client-generated ID via PUT)."""
    state: FakeState = request.app.state.fake_state
    comment_id = request.path_params["comment_id"]
    body = await request.json()

    comment = {
        "id": comment_id,
        "content": body.get("content", ""),
        "flow_version": body.get("flow_version"),
        "resource_type": body.get("resource_type"),
        "resource_id": body.get("resource_id"),
        "author": "fake-user-id",
        "created_at": state.now(),
        "updated_at": state.now(),
        "reply_count": 0,
        "resolved": False,
    }
    state.comments[comment_id] = comment
    return JSONResponse(comment)


async def delete_comment(request: Request) -> Response:
    """Delete a comment."""
    state: FakeState = request.app.state.fake_state
    comment_id = request.path_params["comment_id"]

    if comment_id not in state.comments:
        return JSONResponse({"detail": "Comment not found"}, status_code=404)

    del state.comments[comment_id]
    return Response(status_code=204)


async def create_file_upload(request: Request) -> Response:
    """Fake dataset file upload creation — returns presigned URL pointing back at fake server."""
    state: FakeState = request.app.state.fake_state
    body = await request.json()
    upload_id = str(uuid.uuid4())
    dataset_id = str(uuid.uuid4())

    upload = {
        "id": upload_id,
        "flow_id": body.get("flow_id"),
        "file_name": body.get("file_name", "upload.csv"),
        "purpose": body.get("purpose", "test_run"),
        "s3_presigned_url": f"https://fake-s3.taktile.com/upload/{upload_id}",
        "s3_presigned_fields": {"key": f"uploads/{upload_id}"},
        "status": "PENDING",
        "dataset_id": None,
        "error_metadata": None,
        "created_at": state.now(),
        "updated_at": state.now(),
        "created_by_id": "fake-user-id",
    }
    # Store with a pending dataset_id that gets set on "S3 upload"
    upload["_dataset_id"] = dataset_id
    state.file_uploads[upload_id] = upload
    result = {k: v for k, v in upload.items() if not k.startswith("_")}
    return JSONResponse(result)


async def fake_s3_upload(request: Request) -> Response:
    """Fake S3 upload endpoint — marks the upload as COMPLETED."""
    state: FakeState = request.app.state.fake_state
    upload_id = request.path_params["upload_id"]
    upload = state.file_uploads.get(upload_id)
    if upload is not None:
        upload["status"] = "COMPLETED"
        upload["dataset_id"] = upload["_dataset_id"]
        upload["updated_at"] = state.now()
    return Response(status_code=204)


async def get_file_upload_status(request: Request) -> Response:
    """Return current status of a file upload."""
    state: FakeState = request.app.state.fake_state
    upload_id = request.path_params["upload_id"]
    upload = state.file_uploads.get(upload_id)
    if upload is None:
        return JSONResponse({"detail": "Not found"}, status_code=404)
    result = {k: v for k, v in upload.items() if not k.startswith("_")}
    return JSONResponse(result)


async def download_fake_s3_dataset(request: Request) -> Response:
    """Fake S3 download — serves the dataset rows as JSON."""
    state: FakeState = request.app.state.fake_state
    dataset_id = request.path_params["dataset_id"]
    dataset = state.datasets.get(dataset_id)
    if dataset is None:
        return JSONResponse({"detail": "Not found"}, status_code=404)

    return Response(
        content=json.dumps(dataset.rows),
        media_type="application/json",
    )


# ---------------------------------------------------------------------------
# Dataset CRUD endpoints (new)
# ---------------------------------------------------------------------------


async def list_datasets(request: Request) -> Response:
    """List datasets for a flow."""

    state: FakeState = request.app.state.fake_state
    flow_id = request.query_params.get("flow_id", "")
    result = [ds.to_summary_dict() for ds in state.datasets.values() if ds.flow_id == flow_id]
    return JSONResponse(result)


async def create_dataset(request: Request) -> Response:
    """Create a dataset from scratch."""
    state: FakeState = request.app.state.fake_state
    body = await request.json()

    dataset_id = str(uuid.uuid4())
    input_columns = [FakeDatasetColumn(**c) for c in body.get("input_columns", [])]
    mock_columns = [FakeDatasetColumn(**c) for c in body.get("mock_columns", [])]
    meta_columns = [FakeDatasetColumn(**c) for c in body.get("meta_columns", [])]
    outcome_columns = [FakeDatasetColumn(**c) for c in body.get("outcome_columns", [])]

    ds = FakeDataset(
        dataset_id=dataset_id,
        flow_id=body["flow_id"],
        name=body["name"],
        etag=state.next_etag(),
        rows=[],
        input_columns=input_columns,
        mock_columns=mock_columns,
        meta_columns=meta_columns,
        outcome_columns=outcome_columns,
        source="scratch",
        purpose=body.get("purpose", "test_run"),
        created_at=state.now(),
        updated_at=state.now(),
    )
    state.datasets[dataset_id] = ds
    return JSONResponse(ds.to_dataset_dict())


async def get_dataset(request: Request) -> Response:
    """Get dataset with paginated rows."""
    state: FakeState = request.app.state.fake_state
    dataset_id = request.path_params["dataset_id"]
    ds = state.datasets.get(dataset_id)
    if ds is None:
        return JSONResponse({"detail": "Not found"}, status_code=404)

    from_ = int(request.query_params.get("from_", "0"))
    size = int(request.query_params.get("size", "50"))

    result = ds.to_dataset_dict()
    rows = ds.dataset_rows[from_ : from_ + size]
    result["rows"] = [r.to_dict() for r in rows]
    return JSONResponse(result)


async def patch_dataset(request: Request) -> Response:
    """Update dataset metadata."""
    state: FakeState = request.app.state.fake_state
    dataset_id = request.path_params["dataset_id"]
    ds = state.datasets.get(dataset_id)
    if ds is None:
        return JSONResponse({"detail": "Not found"}, status_code=404)

    body = await request.json()
    if "name" in body and body["name"] is not None:
        ds.name = body["name"]
    ds.etag = state.next_etag()
    ds.updated_at = state.now()
    return JSONResponse(ds.to_dataset_dict())


async def delete_dataset(request: Request) -> Response:
    """Delete a dataset."""
    state: FakeState = request.app.state.fake_state
    dataset_id = request.path_params["dataset_id"]
    if dataset_id not in state.datasets:
        return JSONResponse({"detail": "Not found"}, status_code=404)
    del state.datasets[dataset_id]
    return JSONResponse({})


async def append_dataset_rows(request: Request) -> Response:
    """Append rows to a dataset."""
    state: FakeState = request.app.state.fake_state
    dataset_id = request.path_params["dataset_id"]
    ds = state.datasets.get(dataset_id)
    if ds is None:
        return JSONResponse({"detail": "Not found"}, status_code=404)

    body = await request.json()
    source = body.get("source", "blank")
    new_row_ids = body.get("new_row_ids", [])
    new_rows: list[FakeDatasetRow] = []

    for row_id in new_row_ids:
        row = FakeDatasetRow(id=row_id, input_data={})
        if source == "row_id":
            # Duplicate: copy from existing row
            src_row_id = body.get("row_id")
            for existing in ds.dataset_rows:
                if existing.id == src_row_id:
                    row = FakeDatasetRow(
                        id=row_id,
                        input_data=deepcopy(existing.input_data),
                        output_data=deepcopy(existing.output_data),
                        mock_data=deepcopy(existing.mock_data),
                    )
                    break
        new_rows.append(row)

    ds.dataset_rows.extend(new_rows)
    ds.etag = state.next_etag()
    return JSONResponse([r.to_dict() for r in new_rows])


async def update_dataset_row(request: Request) -> Response:
    """Update a single row."""
    state: FakeState = request.app.state.fake_state
    dataset_id = request.path_params["dataset_id"]
    row_id = request.path_params["row_id"]
    ds = state.datasets.get(dataset_id)
    if ds is None:
        return JSONResponse({"detail": "Not found"}, status_code=404)

    body = await request.json()
    for row in ds.dataset_rows:
        if row.id == row_id:
            if "input_data" in body and body["input_data"] is not None:
                row.input_data = body["input_data"]
            if "output_data" in body and body["output_data"] is not None:
                row.output_data = body["output_data"]
            if "mock_data" in body and body["mock_data"] is not None:
                row.mock_data = body["mock_data"]
            if "meta_data" in body and body["meta_data"] is not None:
                row.meta_data = body["meta_data"]
            if "outcome_data" in body and body["outcome_data"] is not None:
                row.outcome_data = body["outcome_data"]
            ds.etag = state.next_etag()
            return JSONResponse(row.to_dict())

    return JSONResponse({"detail": "Row not found"}, status_code=404)


async def delete_dataset_row(request: Request) -> Response:
    """Delete a single row."""
    state: FakeState = request.app.state.fake_state
    dataset_id = request.path_params["dataset_id"]
    row_id = request.path_params["row_id"]
    ds = state.datasets.get(dataset_id)
    if ds is None:
        return JSONResponse({"detail": "Not found"}, status_code=404)

    for i, row in enumerate(ds.dataset_rows):
        if row.id == row_id:
            ds.dataset_rows.pop(i)
            ds.etag = state.next_etag()
            return JSONResponse({})

    return JSONResponse({"detail": "Row not found"}, status_code=404)


async def upsert_dataset_columns(request: Request) -> Response:
    """Add or rename columns."""
    state: FakeState = request.app.state.fake_state
    dataset_id = request.path_params["dataset_id"]
    ds = state.datasets.get(dataset_id)
    if ds is None:
        return JSONResponse({"detail": "Not found"}, status_code=404)

    body = await request.json()
    for item in body:
        group = item["group"]
        col_data = item["column"]
        col = FakeDatasetColumn(name=col_data["name"], desired_type=col_data["desired_type"])
        col_list: list[FakeDatasetColumn] = getattr(ds, group, [])
        # Replace if same name or column_to_replace matches
        replaced = False
        replace_name = item.get("column_to_replace")
        for i, existing in enumerate(col_list):
            if existing.name == col.name or (replace_name and existing.name == replace_name):
                col_list[i] = col
                replaced = True
                break
        if not replaced:
            col_list.append(col)
        setattr(ds, group, col_list)

    ds.etag = state.next_etag()
    return JSONResponse(ds.to_dataset_dict())


async def delete_dataset_columns(request: Request) -> Response:
    """Delete columns."""
    state: FakeState = request.app.state.fake_state
    dataset_id = request.path_params["dataset_id"]
    ds = state.datasets.get(dataset_id)
    if ds is None:
        return JSONResponse({"detail": "Not found"}, status_code=404)

    body = await request.json()
    for item in body:
        group = item["group"]
        name = item["name"]
        col_list: list[Any] = getattr(ds, group, [])
        setattr(ds, group, [c for c in col_list if c.name != name])

    ds.etag = state.next_etag()
    return JSONResponse(ds.to_dataset_dict())


async def fill_dataset_column(request: Request) -> Response:
    """Fill a column with a value."""
    state: FakeState = request.app.state.fake_state
    dataset_id = request.path_params["dataset_id"]
    group = request.path_params["group"]
    name = request.path_params["name"]
    ds = state.datasets.get(dataset_id)
    if ds is None:
        return JSONResponse({"detail": "Not found"}, status_code=404)

    body = await request.json()
    fill_value = body.get("fill_value")
    from_ = body.get("from_", 0)
    limit = body.get("limit")

    # Determine which data field to fill based on group
    data_field_map = {
        "input_columns": "input_data",
        "output_columns": "output_data",
        "mock_columns": "mock_data",
        "meta_columns": "meta_data",
        "outcome_columns": "outcome_data",
    }
    data_field = data_field_map.get(group, "input_data")

    rows_to_fill = ds.dataset_rows[from_:]
    if limit is not None:
        rows_to_fill = rows_to_fill[:limit]

    for row in rows_to_fill:
        data = getattr(row, data_field)
        if data is None:
            data = {}
            setattr(row, data_field, data)
        data[name] = fill_value

    ds.etag = state.next_etag()
    return JSONResponse(ds.to_dataset_dict())


async def download_dataset_as_file(request: Request) -> Response:
    """Download dataset as CSV or JSON."""
    state: FakeState = request.app.state.fake_state
    dataset_id = request.path_params["dataset_id"]
    ds = state.datasets.get(dataset_id)
    if ds is None:
        return JSONResponse({"detail": "Not found"}, status_code=404)

    fmt = request.query_params.get("format", "csv")
    rows_data = [r.to_dict() for r in ds.dataset_rows]

    if fmt == "json":
        return Response(content=json.dumps(rows_data), media_type="application/json")

    # CSV
    if not rows_data:
        return Response(content="", media_type="text/csv")

    # Flatten: use input_data keys as columns
    all_keys: list[str] = []
    for r in rows_data:
        for k in r.get("input_data", {}):
            if k not in all_keys:
                all_keys.append(k)

    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=all_keys)
    writer.writeheader()
    for r in rows_data:
        writer.writerow(r.get("input_data", {}))
    return Response(content=output.getvalue(), media_type="text/csv")


async def create_dataset_file_upload(request: Request) -> Response:
    """Fake file upload creation — returns a presigned URL pointing at a local endpoint."""
    state: FakeState = request.app.state.fake_state
    body = await request.json()
    upload_id = str(uuid.uuid4())

    # Create a fake dataset immediately (simulating what S3 upload + processing would do)
    dataset_id = str(uuid.uuid4())
    ds = FakeDataset(
        dataset_id=dataset_id,
        flow_id=body["flow_id"],
        name=body["file_name"],
        etag=state.next_etag(),
        rows=[],
        source="file",
        created_at=state.now(),
        updated_at=state.now(),
    )
    state.datasets[dataset_id] = ds

    # Store upload in state for polling
    state._file_uploads = getattr(state, "_file_uploads", {})
    state._file_uploads[upload_id] = {
        "id": upload_id,
        "flow_id": body["flow_id"],
        "file_name": body["file_name"],
        "status": "COMPLETED",
        "s3_presigned_url": "https://fake-s3.taktile.com/upload",
        "s3_presigned_fields": {"key": "fake-key"},
        "dataset_id": dataset_id,
        "error_metadata": None,
        "created_at": state.now(),
        "updated_at": state.now(),
        "created_by_id": str(uuid.uuid4()),
    }
    return JSONResponse(state._file_uploads[upload_id])


async def get_dataset_file_upload(request: Request) -> Response:
    """Get file upload status."""
    state: FakeState = request.app.state.fake_state
    upload_id = request.path_params["upload_id"]
    uploads = getattr(state, "_file_uploads", {})
    upload = uploads.get(upload_id)
    if upload is None:
        return JSONResponse({"detail": "Not found"}, status_code=404)
    return JSONResponse(upload)
