#!/usr/bin/env python3
"""Install git hooks from scripts/ into .git/hooks/."""

import shutil
import stat
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
HOOKS_SRC = ROOT / "scripts"
HOOKS_DST = ROOT / ".git" / "hooks"

HOOKS = ["pre-commit"]

for hook in HOOKS:
    src = HOOKS_SRC / hook
    dst = HOOKS_DST / hook
    if not src.exists():
        print(f"  skip {hook} (not found)")
        continue
    shutil.copy2(src, dst)
    dst.chmod(dst.stat().st_mode | stat.S_IEXEC)
    print(f"  installed {hook}")

print("Done.")
