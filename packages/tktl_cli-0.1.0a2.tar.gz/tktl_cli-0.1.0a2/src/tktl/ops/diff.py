"""Logical diff between two flow versions.

``compute_diff`` is a pure function (no API calls) that takes two raw version
dicts and returns a structured ``FlowDiff``.  ``diff_versions`` is the ops-layer
entry point that fetches the data first.
"""

from __future__ import annotations

import time
from collections.abc import Callable
from typing import Any

from tktl.api.client import TktlClient
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.models.diff import (
    ChangeKind,
    FieldChange,
    FlowDiff,
    IntegrationChange,
    NodeLogicChange,
    ParameterChange,
    SchemaChange,
    StructuralChange,
)
from tktl.ops.versions import _fetch_and_cache_version, _resolve_ids
from tktl.telemetry import estimate_tokens, track

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_SCAFFOLDING_TYPES = {"input", "output"}

_INTEGRATION_TYPES = {
    "manifest_connection_node",
    "custom_connection_node",
    "webhook_connection_node",
    "database_connection_node",
}

# ---------------------------------------------------------------------------
# Ops entry point
# ---------------------------------------------------------------------------


def diff_versions(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
    workspace_id: str,
    flow_slug: str,
    v1_name: str,
    v2_name: str,
) -> FlowDiff:
    """Fetch two versions and compute their logical diff."""
    start = time.monotonic()
    flow_id, v1_id = _resolve_ids(client, cache_index, workspace_id, flow_slug, v1_name)
    _, v2_id = _resolve_ids(client, cache_index, workspace_id, flow_slug, v2_name)
    assert v1_id is not None and v2_id is not None

    v1_raw = _fetch_and_cache_version(client, cache_manager, flow_id, v1_id)
    v2_raw = _fetch_and_cache_version(client, cache_manager, flow_id, v2_id)

    result = compute_diff(flow_slug, v1_name, v2_name, v1_raw, v2_raw)

    track(
        "operation",
        {
            "op": "diff_versions",
            "success": True,
            "output_tokens": estimate_tokens(result),
            "duration_ms": int((time.monotonic() - start) * 1000),
            "flow_slug": flow_slug,
            "v1": v1_name,
            "v2": v2_name,
        },
    )
    return result


# ---------------------------------------------------------------------------
# Pure diff function
# ---------------------------------------------------------------------------


def compute_diff(
    flow_slug: str,
    v1_name: str,
    v2_name: str,
    v1_raw: dict[str, Any],
    v2_raw: dict[str, Any],
) -> FlowDiff:
    """Compute a logical diff between two raw version dicts (no API calls)."""
    param_changes = _diff_parameters(
        v1_raw.get("parameters") or [],
        v2_raw.get("parameters") or [],
    )

    schema_changes = _diff_schemas(v1_raw, v2_raw)

    v1_nodes = (v1_raw.get("graph") or {}).get("nodes") or {}
    v2_nodes = (v2_raw.get("graph") or {}).get("nodes") or {}
    matched, added, removed = _match_nodes(v1_nodes, v2_nodes)

    structural = _build_structural_changes(matched, added, removed)
    logic_changes, integration_changes = _build_node_changes(matched, added, removed)

    return FlowDiff(
        flow_slug=flow_slug,
        v1_name=v1_name,
        v2_name=v2_name,
        parameter_changes=param_changes,
        schema_changes=schema_changes,
        structural_changes=structural,
        logic_changes=logic_changes,
        integration_changes=integration_changes,
    )


# ---------------------------------------------------------------------------
# Node matching
# ---------------------------------------------------------------------------


def _is_scaffolding(node: dict[str, Any]) -> bool:
    """Return True for input/output nodes and auto-generated split scaffolding."""
    if node.get("type") in _SCAFFOLDING_TYPES:
        return True
    meta = node.get("meta") or {}
    return bool(meta.get("is_split_branch_node") or meta.get("is_split_merge_node"))


def _match_nodes(
    v1_nodes: dict[str, dict[str, Any]],
    v2_nodes: dict[str, dict[str, Any]],
) -> tuple[list[tuple[dict[str, Any], dict[str, Any]]], list[dict[str, Any]], list[dict[str, Any]]]:
    """Match nodes across versions by name, skipping scaffolding.

    Returns ``(matched_pairs, added_in_v2, removed_from_v1)``.
    """
    v1_by_name = {n["name"]: n for n in v1_nodes.values() if not _is_scaffolding(n)}
    v2_by_name = {n["name"]: n for n in v2_nodes.values() if not _is_scaffolding(n)}

    matched = [(v1_by_name[name], v2_by_name[name]) for name in v1_by_name if name in v2_by_name]
    added = [n for name, n in v2_by_name.items() if name not in v1_by_name]
    removed = [n for name, n in v1_by_name.items() if name not in v2_by_name]

    return matched, added, removed


def _is_integration_node(node_type: str) -> bool:
    return node_type in _INTEGRATION_TYPES


# ---------------------------------------------------------------------------
# Structural changes
# ---------------------------------------------------------------------------


def _build_structural_changes(
    matched: list[tuple[dict[str, Any], dict[str, Any]]],
    added: list[dict[str, Any]],
    removed: list[dict[str, Any]],
) -> list[StructuralChange]:
    changes: list[StructuralChange] = []
    for n in added:
        changes.append(
            StructuralChange(
                node_name=n["name"], kind=ChangeKind.added, node_type=n.get("type"), v2_node_id=n.get("id")
            )
        )
    for n in removed:
        changes.append(
            StructuralChange(
                node_name=n["name"], kind=ChangeKind.removed, node_type=n.get("type"), v1_node_id=n.get("id")
            )
        )
    for n1, n2 in matched:
        if n1.get("type") != n2.get("type"):
            changes.append(
                StructuralChange(
                    node_name=n1["name"],
                    kind=ChangeKind.modified,
                    node_type=n2.get("type"),
                    detail=f"type changed from {n1.get('type')} to {n2.get('type')}",
                    v1_node_id=n1.get("id"),
                    v2_node_id=n2.get("id"),
                )
            )
    return changes


# ---------------------------------------------------------------------------
# Node logic + integration changes
# ---------------------------------------------------------------------------


def _build_node_changes(
    matched: list[tuple[dict[str, Any], dict[str, Any]]],
    added: list[dict[str, Any]],
    removed: list[dict[str, Any]],
) -> tuple[list[NodeLogicChange], list[IntegrationChange]]:
    logic_changes: list[NodeLogicChange] = []
    integration_changes: list[IntegrationChange] = []

    for n1, n2 in matched:
        ntype = n2.get("type", n1.get("type", ""))
        meta1 = n1.get("meta") or {}
        meta2 = n2.get("meta") or {}
        if meta1 == meta2:
            continue

        diff_fn = _NODE_DIFF_REGISTRY.get(ntype, _diff_generic)
        field_changes = diff_fn(meta1, meta2)
        if not field_changes:
            continue

        if _is_integration_node(ntype):
            pr = meta2.get("provider_resource") or {}
            integration_changes.append(
                IntegrationChange(
                    node_name=n1["name"],
                    kind=ChangeKind.modified,
                    provider=pr.get("provider"),
                    resource=pr.get("resource"),
                    v1_node_id=n1.get("id"),
                    v2_node_id=n2.get("id"),
                    changes=field_changes,
                )
            )
        else:
            logic_changes.append(
                NodeLogicChange(
                    node_name=n1["name"],
                    node_type=ntype,
                    v1_node_id=n1.get("id"),
                    v2_node_id=n2.get("id"),
                    changes=field_changes,
                )
            )

    # Added/removed integration nodes
    for n in added:
        if _is_integration_node(n.get("type", "")):
            pr = (n.get("meta") or {}).get("provider_resource") or {}
            integration_changes.append(
                IntegrationChange(
                    node_name=n["name"],
                    kind=ChangeKind.added,
                    provider=pr.get("provider"),
                    resource=pr.get("resource"),
                    v2_node_id=n.get("id"),
                )
            )
    for n in removed:
        if _is_integration_node(n.get("type", "")):
            pr = (n.get("meta") or {}).get("provider_resource") or {}
            integration_changes.append(
                IntegrationChange(
                    node_name=n["name"],
                    kind=ChangeKind.removed,
                    provider=pr.get("provider"),
                    resource=pr.get("resource"),
                    v1_node_id=n.get("id"),
                )
            )

    return logic_changes, integration_changes


# ---------------------------------------------------------------------------
# Parameter diff
# ---------------------------------------------------------------------------


def _diff_parameters(
    v1_params: list[dict[str, Any]],
    v2_params: list[dict[str, Any]],
) -> list[ParameterChange]:
    v1_map = {p["name"]: p.get("value") for p in v1_params}
    v2_map = {p["name"]: p.get("value") for p in v2_params}
    changes: list[ParameterChange] = []
    for name in v1_map:
        if name not in v2_map:
            changes.append(ParameterChange(name=name, kind=ChangeKind.removed, old_value=v1_map[name]))
        elif v1_map[name] != v2_map[name]:
            changes.append(
                ParameterChange(
                    name=name,
                    kind=ChangeKind.modified,
                    old_value=v1_map[name],
                    new_value=v2_map[name],
                )
            )
    for name in v2_map:
        if name not in v1_map:
            changes.append(ParameterChange(name=name, kind=ChangeKind.added, new_value=v2_map[name]))
    return changes


# ---------------------------------------------------------------------------
# Schema diff
# ---------------------------------------------------------------------------


def _diff_schemas(
    v1_raw: dict[str, Any],
    v2_raw: dict[str, Any],
) -> list[SchemaChange]:
    changes: list[SchemaChange] = []
    for schema_type in ("input", "output"):
        v1_props = (v1_raw.get(f"{schema_type}_schema") or {}).get("properties") or {}
        v2_props = (v2_raw.get(f"{schema_type}_schema") or {}).get("properties") or {}
        for field in v1_props:
            if field not in v2_props:
                changes.append(
                    SchemaChange(schema_type=schema_type, kind=ChangeKind.removed, field=field, old=v1_props[field])
                )
            elif v1_props[field] != v2_props[field]:
                changes.append(
                    SchemaChange(
                        schema_type=schema_type,
                        kind=ChangeKind.modified,
                        field=field,
                        old=v1_props[field],
                        new=v2_props[field],
                    )
                )
        for field in v2_props:
            if field not in v1_props:
                changes.append(
                    SchemaChange(schema_type=schema_type, kind=ChangeKind.added, field=field, new=v2_props[field])
                )
    return changes


# ---------------------------------------------------------------------------
# Per-type diff functions
# ---------------------------------------------------------------------------


def _diff_decision_table(m1: dict[str, Any], m2: dict[str, Any]) -> list[FieldChange]:
    changes: list[FieldChange] = []

    pf1 = [f.get("value", "") for f in (m1.get("predicate_fields") or [])]
    pf2 = [f.get("value", "") for f in (m2.get("predicate_fields") or [])]
    if pf1 != pf2:
        changes.append(FieldChange(field="condition_columns", old=pf1, new=pf2, kind=ChangeKind.modified))

    ef1 = [f.get("value", "") for f in (m1.get("effect_fields") or [])]
    ef2 = [f.get("value", "") for f in (m2.get("effect_fields") or [])]
    if ef1 != ef2:
        changes.append(FieldChange(field="result_columns", old=ef1, new=ef2, kind=ChangeKind.modified))

    c1 = len(m1.get("cases") or [])
    c2 = len(m2.get("cases") or [])
    if c1 != c2:
        changes.append(FieldChange(field="rules", old=f"{c1} rules", new=f"{c2} rules", kind=ChangeKind.modified))

    fb1 = m1.get("fallback")
    fb2 = m2.get("fallback")
    if fb1 != fb2:
        changes.append(FieldChange(field="fallback", old=fb1, new=fb2, kind=ChangeKind.modified))

    return changes


def _diff_scorecard(m1: dict[str, Any], m2: dict[str, Any]) -> list[FieldChange]:
    changes: list[FieldChange] = []

    af1 = (m1.get("assign_field") or {}).get("value")
    af2 = (m2.get("assign_field") or {}).get("value")
    if af1 != af2:
        changes.append(FieldChange(field="output_field", old=af1, new=af2, kind=ChangeKind.modified))

    f1_map = {f["input_field"]["value"]: f for f in (m1.get("factors") or []) if "input_field" in f}
    f2_map = {f["input_field"]["value"]: f for f in (m2.get("factors") or []) if "input_field" in f}

    for name in f1_map:
        if name not in f2_map:
            changes.append(FieldChange(field=f"factor '{name}'", old="present", new=None, kind=ChangeKind.removed))
        else:
            w1 = f1_map[name].get("weight", {}).get("value")
            w2 = f2_map[name].get("weight", {}).get("value")
            if w1 != w2:
                changes.append(FieldChange(field=f"factor '{name}' weight", old=w1, new=w2, kind=ChangeKind.modified))
            fc1 = len(f1_map[name].get("cases") or [])
            fc2 = len(f2_map[name].get("cases") or [])
            if fc1 != fc2:
                changes.append(
                    FieldChange(
                        field=f"factor '{name}' buckets",
                        old=f"{fc1} buckets",
                        new=f"{fc2} buckets",
                        kind=ChangeKind.modified,
                    )
                )
    for name in f2_map:
        if name not in f1_map:
            w = f2_map[name].get("weight", {}).get("value")
            changes.append(FieldChange(field=f"factor '{name}'", old=None, new=f"weight={w}", kind=ChangeKind.added))

    return changes


def _summarize_clauses(branch: dict[str, Any]) -> str:
    """One-line summary of branch conditions."""
    clauses = branch.get("clauses") or []
    junction = branch.get("junction", "and")
    parts = [f"{c.get('left', '')} {c.get('operator', '')} {c.get('right', '')}" for c in clauses]
    return f" {junction} ".join(parts) if parts else "(empty)"


def _summarize_effects(branch: dict[str, Any]) -> dict[str, Any]:
    """Dict of target→value for diff readability."""
    return {e.get("target", ""): e.get("value") for e in (branch.get("effects") or [])}


def _diff_rule(m1: dict[str, Any], m2: dict[str, Any]) -> list[FieldChange]:
    changes: list[FieldChange] = []
    b1 = m1.get("branches") or []
    b2 = m2.get("branches") or []
    if len(b1) != len(b2):
        changes.append(
            FieldChange(
                field="branches",
                old=f"{len(b1)} branches",
                new=f"{len(b2)} branches",
                kind=ChangeKind.modified,
            )
        )

    de1 = m1.get("default_effects") or []
    de2 = m2.get("default_effects") or []
    if de1 != de2:
        t1 = {e.get("target"): e.get("value") for e in de1}
        t2 = {e.get("target"): e.get("value") for e in de2}
        if t1 != t2:
            changes.append(FieldChange(field="default_effects", old=t1, new=t2, kind=ChangeKind.modified))

    for i, (br1, br2) in enumerate(zip(b1, b2)):
        if br1.get("clauses") != br2.get("clauses"):
            changes.append(
                FieldChange(
                    field=f"branch[{i}] conditions",
                    old=_summarize_clauses(br1),
                    new=_summarize_clauses(br2),
                    kind=ChangeKind.modified,
                )
            )
        if br1.get("effects") != br2.get("effects"):
            changes.append(
                FieldChange(
                    field=f"branch[{i}] effects",
                    old=_summarize_effects(br1),
                    new=_summarize_effects(br2),
                    kind=ChangeKind.modified,
                )
            )
    return changes


def _diff_split(m1: dict[str, Any], m2: dict[str, Any]) -> list[FieldChange]:
    changes: list[FieldChange] = []
    b1 = m1.get("branches") or []
    b2 = m2.get("branches") or []
    if len(b1) != len(b2):
        changes.append(
            FieldChange(field="branches", old=f"{len(b1)} paths", new=f"{len(b2)} paths", kind=ChangeKind.modified)
        )
    for i, (br1, br2) in enumerate(zip(b1, b2)):
        if br1.get("clauses") != br2.get("clauses"):
            changes.append(
                FieldChange(
                    field=f"branch[{i}] condition",
                    old=_summarize_clauses(br1),
                    new=_summarize_clauses(br2),
                    kind=ChangeKind.modified,
                )
            )
    return changes


def _diff_assignment(m1: dict[str, Any], m2: dict[str, Any]) -> list[FieldChange]:
    de1 = {e.get("target"): e.get("value") for e in (m1.get("default_effects") or [])}
    de2 = {e.get("target"): e.get("value") for e in (m2.get("default_effects") or [])}
    changes: list[FieldChange] = []
    for target in de1:
        if target not in de2:
            changes.append(FieldChange(field=target, old=de1[target], new=None, kind=ChangeKind.removed))
        elif de1[target] != de2[target]:
            changes.append(FieldChange(field=target, old=de1[target], new=de2[target], kind=ChangeKind.modified))
    for target in de2:
        if target not in de1:
            changes.append(FieldChange(field=target, old=None, new=de2[target], kind=ChangeKind.added))
    return changes


def _diff_transform(m1: dict[str, Any], m2: dict[str, Any]) -> list[FieldChange]:
    src1 = m1.get("src") or ""
    src2 = m2.get("src") or ""
    if src1 == src2:
        return []
    return [FieldChange(field="code", old=src1, new=src2, kind=ChangeKind.modified)]


def _diff_manifest_connection(m1: dict[str, Any], m2: dict[str, Any]) -> list[FieldChange]:
    changes: list[FieldChange] = []
    pr1 = m1.get("provider_resource") or {}
    pr2 = m2.get("provider_resource") or {}
    if pr1.get("provider") != pr2.get("provider"):
        changes.append(
            FieldChange(field="provider", old=pr1.get("provider"), new=pr2.get("provider"), kind=ChangeKind.modified)
        )
    if pr1.get("resource") != pr2.get("resource"):
        changes.append(
            FieldChange(field="resource", old=pr1.get("resource"), new=pr2.get("resource"), kind=ChangeKind.modified)
        )
    if pr1.get("manifest_version") != pr2.get("manifest_version"):
        changes.append(
            FieldChange(
                field="manifest_version",
                old=pr1.get("manifest_version"),
                new=pr2.get("manifest_version"),
                kind=ChangeKind.modified,
            )
        )

    inp1 = m1.get("input") or {}
    inp2 = m2.get("input") or {}
    if inp1 != inp2:
        changes.append(FieldChange(field="input_mapping", old="changed", new="changed", kind=ChangeKind.modified))

    out1 = {k: v for k, v in (m1.get("output") or {}).items() if isinstance(v, dict) and v.get("active")}
    out2 = {k: v for k, v in (m2.get("output") or {}).items() if isinstance(v, dict) and v.get("active")}
    if out1 != out2:
        changes.append(
            FieldChange(
                field="output_mapping",
                old=list(out1.keys()),
                new=list(out2.keys()),
                kind=ChangeKind.modified,
            )
        )

    cfg1 = m1.get("config") or {}
    cfg2 = m2.get("config") or {}
    if cfg1.get("caching") != cfg2.get("caching"):
        changes.append(
            FieldChange(field="caching", old=cfg1.get("caching"), new=cfg2.get("caching"), kind=ChangeKind.modified)
        )
    return changes


def _diff_custom_connection(m1: dict[str, Any], m2: dict[str, Any]) -> list[FieldChange]:
    changes: list[FieldChange] = []
    for key in ("verb", "path", "params", "headers", "body"):
        v1 = m1.get(key)
        v2 = m2.get(key)
        if v1 != v2:
            if key == "path":
                v1 = v1.get("expression") if isinstance(v1, dict) else v1
                v2 = v2.get("expression") if isinstance(v2, dict) else v2
            changes.append(FieldChange(field=key, old=v1, new=v2, kind=ChangeKind.modified))
    return changes


def _diff_matrix_table(m1: dict[str, Any], m2: dict[str, Any]) -> list[FieldChange]:
    changes: list[FieldChange] = []
    for key in ("condition_a", "condition_b", "result_field"):
        if m1.get(key) != m2.get(key):
            changes.append(FieldChange(field=key, old=m1.get(key), new=m2.get(key), kind=ChangeKind.modified))
    r1, r2 = m1.get("rows") or [], m2.get("rows") or []
    c1, c2 = m1.get("columns") or [], m2.get("columns") or []
    if r1 != r2:
        changes.append(FieldChange(field="rows", old=len(r1), new=len(r2), kind=ChangeKind.modified))
    if c1 != c2:
        changes.append(FieldChange(field="columns", old=len(c1), new=len(c2), kind=ChangeKind.modified))
    if m1.get("cells") != m2.get("cells"):
        changes.append(FieldChange(field="cells", old="changed", new="changed", kind=ChangeKind.modified))
    return changes


def _diff_flow_node(m1: dict[str, Any], m2: dict[str, Any]) -> list[FieldChange]:
    changes: list[FieldChange] = []
    if m1.get("child_flow_id") != m2.get("child_flow_id"):
        changes.append(
            FieldChange(
                field="child_flow_id",
                old=m1.get("child_flow_id"),
                new=m2.get("child_flow_id"),
                kind=ChangeKind.modified,
            )
        )
    if m1.get("input_mapping") != m2.get("input_mapping"):
        changes.append(FieldChange(field="input_mapping", old="changed", new="changed", kind=ChangeKind.modified))
    if m1.get("output_mapping") != m2.get("output_mapping"):
        changes.append(FieldChange(field="output_mapping", old="changed", new="changed", kind=ChangeKind.modified))
    return changes


def _diff_ml(m1: dict[str, Any], m2: dict[str, Any]) -> list[FieldChange]:
    changes: list[FieldChange] = []
    if m1.get("model_id") != m2.get("model_id"):
        changes.append(
            FieldChange(field="model_id", old=m1.get("model_id"), new=m2.get("model_id"), kind=ChangeKind.modified)
        )
    if m1.get("description") != m2.get("description"):
        changes.append(
            FieldChange(
                field="description", old=m1.get("description"), new=m2.get("description"), kind=ChangeKind.modified
            )
        )
    return changes


def _diff_ai_node(m1: dict[str, Any], m2: dict[str, Any]) -> list[FieldChange]:
    changes: list[FieldChange] = []
    for key in ("model", "prompt", "system_prompt", "temperature", "max_tokens"):
        if m1.get(key) != m2.get(key):
            changes.append(FieldChange(field=key, old=m1.get(key), new=m2.get(key), kind=ChangeKind.modified))
    oc1 = m1.get("output_config")
    oc2 = m2.get("output_config")
    if oc1 != oc2:
        changes.append(FieldChange(field="output_config", old=oc1, new=oc2, kind=ChangeKind.modified))
    return changes


def _diff_generic(m1: dict[str, Any], m2: dict[str, Any]) -> list[FieldChange]:
    """Fallback: shallow comparison of all top-level meta keys."""
    changes: list[FieldChange] = []
    all_keys = set(m1.keys()) | set(m2.keys())
    for key in sorted(all_keys):
        v1 = m1.get(key)
        v2 = m2.get(key)
        if v1 == v2:
            continue
        if key not in m1:
            changes.append(FieldChange(field=key, old=None, new=v2, kind=ChangeKind.added))
        elif key not in m2:
            changes.append(FieldChange(field=key, old=v1, new=None, kind=ChangeKind.removed))
        else:
            changes.append(FieldChange(field=key, old=v1, new=v2, kind=ChangeKind.modified))
    return changes


# ---------------------------------------------------------------------------
# Registry — must be defined after all _diff_* functions
# ---------------------------------------------------------------------------

NodeDiffFn = Callable[[dict[str, Any], dict[str, Any]], list[FieldChange]]

_NODE_DIFF_REGISTRY: dict[str, NodeDiffFn] = {
    "decision_table": _diff_decision_table,
    "scorecard": _diff_scorecard,
    "rule_2": _diff_rule,
    "split_2": _diff_split,
    "assignment_node": _diff_assignment,
    "transform": _diff_transform,
    "manifest_connection_node": _diff_manifest_connection,
    "custom_connection_node": _diff_custom_connection,
    "matrix_table": _diff_matrix_table,
    "flow_node": _diff_flow_node,
    "ml": _diff_ml,
    "ai_node": _diff_ai_node,
}
