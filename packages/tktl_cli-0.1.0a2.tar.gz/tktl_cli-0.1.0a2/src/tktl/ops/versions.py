"""Operations layer — version read and write operations."""

from __future__ import annotations

import sys
import time
from typing import Any

from tktl.api.client import TktlClient
from tktl.api.flows import create_flow, get_flow_by_slug
from tktl.api.versions import (
    create_version as api_create_version,
    duplicate_version as api_duplicate_version,
    get_changes as api_get_changes,
    get_version as api_get_version,
    normalize_body,
    normalize_graph_response,
    patch_version as api_patch_version,
)
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.models.errors import ConflictError, NotFoundError
from tktl.models.version import VersionDetail, VersionSummary
from tktl.telemetry import estimate_tokens, track

_MAX_ETAG_RETRIES = 3


def _resolve_ids(
    client: TktlClient,
    cache_index: CacheIndex,
    workspace_id: str,
    flow_slug: str,
    version_name: str | None = None,
) -> tuple[str, str | None]:
    """Resolve flow slug to flow_id and optionally version name to version_id.

    Falls back to API if cache index has no entry.
    """
    flow_id = cache_index.resolve_flow_id(flow_slug)

    if flow_id is None:
        # Fallback: fetch flow from API to populate index
        raw = get_flow_by_slug(client, workspace_id, flow_slug)
        flow_id = raw["id"]
        versions_map: dict[str, str] = {}
        for v in raw.get("versions", []):
            versions_map[v["name"]] = v["id"]
        cache_index.update_flow(flow_slug, flow_id, versions_map)
        cache_index.workspace_id = workspace_id
        cache_index.save()

    version_id = None
    if version_name is not None:
        version_id = cache_index.resolve_version_id(flow_slug, version_name)
        if version_id is None:
            # Fallback: re-fetch flow to get version mappings
            raw = get_flow_by_slug(client, workspace_id, flow_slug)
            versions_map = {}
            for v in raw.get("versions", []):
                versions_map[v["name"]] = v["id"]
            cache_index.update_flow(flow_slug, raw["id"], versions_map)
            cache_index.save()
            version_id = cache_index.resolve_version_id(flow_slug, version_name)
            if version_id is None:
                raise NotFoundError(f"Version not found: {version_name}")

    return flow_id, version_id


def _fetch_and_cache_version(
    client: TktlClient,
    cache_manager: CacheManager,
    flow_id: str,
    version_id: str,
) -> dict[str, Any]:
    """Fetch a version from the API and write it to the cache."""
    raw = api_get_version(client, version_id)
    if raw is None:
        raise NotFoundError(f"Version '{version_id}' not found")
    cache_manager.write_version(version_id, flow_id, raw)
    return raw


def list_versions(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
    workspace_id: str,
    flow_slug: str,
) -> list[VersionSummary]:
    """List all versions of a flow. Returns typed VersionSummary models."""
    start = time.monotonic()
    flow_id, _ = _resolve_ids(client, cache_index, workspace_id, flow_slug)

    # Fetch the flow (which includes version summaries)
    raw = get_flow_by_slug(client, workspace_id, flow_slug)
    versions = raw.get("versions", [])
    result = [VersionSummary.model_validate(v) for v in versions]
    track(
        "operation",
        {
            "op": "list_versions",
            "success": True,
            "output_tokens": estimate_tokens(result),
            "duration_ms": int((time.monotonic() - start) * 1000),
            "flow_slug": flow_slug,
        },
    )
    return result


def describe_version(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
    workspace_id: str,
    flow_slug: str,
    version_name: str,
    full: bool = False,
) -> VersionDetail:
    """Describe a version. Fetches from API, caches, decomposes into per-node files."""
    start = time.monotonic()
    flow_id, version_id = _resolve_ids(client, cache_index, workspace_id, flow_slug, version_name)
    assert version_id is not None

    # Fetch full version from API (or cache)
    raw = _fetch_and_cache_version(client, cache_manager, flow_id, version_id)

    if not full:
        raw = {k: v for k, v in raw.items() if k != "graph"}

    result = VersionDetail.model_validate(raw)
    track(
        "operation",
        {
            "op": "describe_version",
            "success": True,
            "output_tokens": estimate_tokens(result),
            "duration_ms": int((time.monotonic() - start) * 1000),
            "flow_slug": flow_slug,
            "flow_version_name": version_name,
        },
    )
    return result


def list_changes(
    client: TktlClient,
    cache_index: CacheIndex,
    workspace_id: str,
    flow_slug: str,
    version_name: str,
    after_etag: str | None = None,
    limit: int = 100,
) -> list[dict[str, Any]]:
    """Get change history for a version."""
    start = time.monotonic()
    flow_id = cache_index.resolve_flow_id(flow_slug)
    if flow_id is None:
        raise NotFoundError(f"Flow not found: {flow_slug}")

    version_id = cache_index.resolve_version_id(flow_slug, version_name)
    if version_id is None:
        raise NotFoundError(f"Version not found: {version_name}")

    result = api_get_changes(client, version_id, after_etag=after_etag, limit=limit)
    track(
        "operation",
        {
            "op": "list_changes",
            "success": True,
            "output_tokens": estimate_tokens(result),
            "duration_ms": int((time.monotonic() - start) * 1000),
            "flow_slug": flow_slug,
            "flow_version_name": version_name,
        },
    )
    return result


def update_version(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
    workspace_id: str,
    flow_slug: str,
    version_name: str,
    params: list[dict[str, Any]] | None = None,
    schema_in: dict[str, Any] | None = None,
    schema_out: dict[str, Any] | None = None,
) -> VersionDetail:
    """Update version-level fields (parameters, input_schema, output_schema).

    Uses ETag-based optimistic locking with up to 3 retries on 412.
    """
    start = time.monotonic()
    flow_id, version_id = _resolve_ids(client, cache_index, workspace_id, flow_slug, version_name)
    assert version_id is not None

    for attempt in range(_MAX_ETAG_RETRIES):
        # Fetch current version to get etag
        current = _fetch_and_cache_version(client, cache_manager, flow_id, version_id)
        etag = current.get("etag")

        # Build the patch body
        body: dict[str, Any] = {}
        if params is not None:
            body["parameters"] = params
        if schema_in is not None:
            body["input_schema"] = schema_in
        if schema_out is not None:
            body["output_schema"] = schema_out

        try:
            result = api_patch_version(client, version_id, body, if_match=etag)
            # Update cache
            cache_manager.write_version(version_id, flow_id, result)
            detail = VersionDetail.model_validate(result)
            track(
                "operation",
                {
                    "op": "update_version",
                    "success": True,
                    "output_tokens": estimate_tokens(detail),
                    "duration_ms": int((time.monotonic() - start) * 1000),
                    "flow_slug": flow_slug,
                    "flow_version_name": version_name,
                    "etag_retries": attempt,
                },
            )
            return detail
        except ConflictError as exc:
            if str(exc).lower().startswith("[validation]"):
                raise
            if attempt == _MAX_ETAG_RETRIES - 1:
                raise ConflictError(
                    f'Version "{version_name}" has been modified {_MAX_ETAG_RETRIES} times during update -- giving up.'
                )
            # Re-fetch and retry
            continue

    # Should not reach here
    raise ConflictError(f'Version "{version_name}" conflict')  # pragma: no cover


def publish_version(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
    workspace_id: str,
    flow_slug: str,
    version_name: str,
) -> VersionDetail:
    """Publish a draft version by setting status to PUBLISHED."""
    start = time.monotonic()
    flow_id, version_id = _resolve_ids(client, cache_index, workspace_id, flow_slug, version_name)
    assert version_id is not None

    current = _fetch_and_cache_version(client, cache_manager, flow_id, version_id)
    etag = current.get("etag")

    result = api_patch_version(client, version_id, {"status": "PUBLISHED"}, if_match=etag)
    cache_manager.write_version(version_id, flow_id, result)
    detail = VersionDetail.model_validate(result)
    track(
        "operation",
        {
            "op": "publish_version",
            "success": True,
            "output_tokens": estimate_tokens(detail),
            "duration_ms": int((time.monotonic() - start) * 1000),
            "flow_slug": flow_slug,
            "flow_version_name": version_name,
        },
    )
    return detail


def archive_version(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
    workspace_id: str,
    flow_slug: str,
    version_name: str,
) -> VersionDetail:
    """Archive a version by setting status to ARCHIVED."""
    start = time.monotonic()
    flow_id, version_id = _resolve_ids(client, cache_index, workspace_id, flow_slug, version_name)
    assert version_id is not None

    current = _fetch_and_cache_version(client, cache_manager, flow_id, version_id)
    etag = current.get("etag")

    result = api_patch_version(client, version_id, {"status": "ARCHIVED"}, if_match=etag)
    cache_manager.write_version(version_id, flow_id, result)
    detail = VersionDetail.model_validate(result)
    track(
        "operation",
        {
            "op": "archive_version",
            "success": True,
            "output_tokens": estimate_tokens(detail),
            "duration_ms": int((time.monotonic() - start) * 1000),
            "flow_slug": flow_slug,
            "flow_version_name": version_name,
        },
    )
    return detail


def create_version(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
    workspace_id: str,
    flow_slug: str,
    version_name: str,
) -> VersionDetail:
    """Create a new draft version for a flow."""
    start = time.monotonic()
    flow_id, _ = _resolve_ids(client, cache_index, workspace_id, flow_slug)

    result = api_create_version(client, flow_id, version_name)

    # Update cache index with new version
    cache_index.update_version(flow_slug, version_name, result["id"])
    cache_index.save()

    # Cache the new version
    cache_manager.write_version(result["id"], flow_id, result)
    detail = VersionDetail.model_validate(result)
    track(
        "operation",
        {
            "op": "create_version",
            "success": True,
            "output_tokens": estimate_tokens(detail),
            "duration_ms": int((time.monotonic() - start) * 1000),
            "flow_slug": flow_slug,
            "flow_version_name": version_name,
        },
    )
    return detail


def duplicate_version(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
    workspace_id: str,
    flow_slug: str,
    version_name: str,
    new_name: str,
) -> VersionDetail:
    """Duplicate an existing version."""
    start = time.monotonic()
    flow_id, version_id = _resolve_ids(client, cache_index, workspace_id, flow_slug, version_name)
    assert version_id is not None

    result = api_duplicate_version(client, version_id, new_name, created_by_id=client._user_id)
    new_version_id = result["id"]

    # Update cache index with new version
    cache_index.update_version(flow_slug, new_name, new_version_id)
    cache_index.save()

    # Re-fetch via v2 to get dict-keyed graph for caching
    v2_data = _fetch_and_cache_version(client, cache_manager, flow_id, new_version_id)
    detail = VersionDetail.model_validate(v2_data)
    track(
        "operation",
        {
            "op": "duplicate_version",
            "success": True,
            "output_tokens": estimate_tokens(detail),
            "duration_ms": int((time.monotonic() - start) * 1000),
            "flow_slug": flow_slug,
            "flow_version_name": new_name,
        },
    )
    return detail


def resolve_child_flow(
    client: TktlClient,
    workspace_id: str,
    child_flow_slug: str,
) -> dict[str, str]:
    """Find or create a child flow by slug and return its resolved IDs.

    Returns ``{"flow_id": ..., "version_id": ..., "etag": ..., "action": ...}``.
    """
    try:
        existing = get_flow_by_slug(client, workspace_id, child_flow_slug)
        flow_id = existing["id"]
        version_id = existing.get("default_sandbox_version") or existing.get("default_version", "")
        if not version_id:
            resp = client.get("/api/v1/flow_versions", params={"flow_id": flow_id})
            if resp.status_code == 200:
                versions = resp.json()
                version_id = versions[0]["id"] if versions else ""
        action = "found"
    except NotFoundError:
        flow_name = child_flow_slug.replace("-", " ").title()
        created = create_flow(client, workspace_id, name=flow_name, slug=child_flow_slug)
        flow_id = created["id"]
        version_id = created.get("default_sandbox_version") or ""
        if not version_id:
            resp = client.get("/api/v1/flow_versions", params={"flow_id": flow_id})
            if resp.status_code == 200:
                versions = resp.json()
                version_id = versions[0]["id"] if versions else ""
        action = "created"

    child_etag = "00000000"
    if version_id:
        ver_resp = client.get(f"/api/v2/flow_versions/{version_id}")
        if ver_resp.status_code == 200:
            child_etag = ver_resp.json().get("etag", "00000000")

    return {"flow_id": flow_id, "version_id": version_id, "etag": child_etag, "action": action}


def _upsert_child_flows(
    client: TktlClient,
    workspace_id: str,
    body: dict[str, Any],
) -> dict[str, dict[str, str]]:
    """Create any child flows referenced by ``type: flow`` or ``flow_loop`` nodes.

    For each flow/flow_loop node in the graph, looks up the ``child_flow_slug``
    on the target workspace.  If missing, creates the flow (and its initial
    version).  Updates the node meta in-place to reference the target
    flow/version IDs.

    Returns a mapping of ``{node_id: {slug, flow_id, version_id, action}}``
    describing what was created or found.
    """
    graph = body.get("graph", {})
    nodes = graph.get("nodes", {})
    results: dict[str, dict[str, str]] = {}

    for node_id, node in nodes.items():
        if node is None or node.get("type") not in ("flow", "flow_loop"):
            continue
        meta = node.get("meta", {})
        slug = meta.get("child_flow_slug")
        if not slug:
            continue

        resolved = resolve_child_flow(client, workspace_id, slug)

        meta["child_flow_id"] = resolved["flow_id"]
        meta["child_flow_version_id"] = resolved["version_id"]
        meta["child_flow_version_known_etag"] = resolved["etag"]
        meta["is_stale"] = False

        results[node_id] = {
            "slug": slug,
            "flow_id": resolved["flow_id"],
            "version_id": resolved["version_id"],
            "action": resolved["action"],
        }

    return results


def _build_replace_patch(
    current: dict[str, Any],
    new_body: dict[str, Any],
) -> dict[str, Any]:
    """Build a PATCH body that replaces the graph using null-delete merge patch semantics.

    For each graph collection (nodes, edges, node_groups), existing items
    not present in ``new_body`` are set to ``None`` (deleted via RFC 7396
    JSON Merge Patch), and new items are added/replaced.
    """
    patch_body: dict[str, Any] = {k: v for k, v in new_body.items() if k != "graph"}

    new_graph = new_body.get("graph")
    if not new_graph:
        return patch_body

    current_graph = current.get("graph", {})
    patch_graph: dict[str, Any] = {}

    for collection in ("nodes", "edges", "node_groups"):
        current_items = current_graph.get(collection, {})
        new_items = new_graph.get(collection, {})

        merged: dict[str, Any] = {}
        # Null-delete existing items not in the new set
        for item_id in current_items:
            if item_id not in new_items:
                merged[item_id] = None
        # Add/replace all new items
        merged.update(new_items)

        if merged:
            patch_graph[collection] = merged

    if patch_graph:
        patch_body["graph"] = patch_graph

    return patch_body


def replace_version(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
    workspace_id: str,
    flow_slug: str,
    version_name: str,
    body: dict[str, Any],
) -> VersionDetail:
    """Replace an entire version's graph via PATCH with null-delete merge semantics.

    Uses JSON Merge Patch (RFC 7396): existing nodes/edges not in the new body
    are set to ``null`` (deleted), and new ones are added, in a single PATCH.
    PUT v2 silently ignores the graph payload, so PATCH v1 is the only way to
    fully replace a version's graph.

    Automatically upserts any child flows referenced by ``type: flow`` nodes.
    """
    start = time.monotonic()
    normalize_body(body)
    flow_id, version_id = _resolve_ids(client, cache_index, workspace_id, flow_slug, version_name)
    assert version_id is not None

    # Upsert child flows before replacing the version
    child_results = _upsert_child_flows(client, workspace_id, body)
    if child_results:
        for info in child_results.values():
            print(f"  child flow '{info['slug']}': {info['action']}", file=sys.stderr)

    for attempt in range(_MAX_ETAG_RETRIES):
        # Fetch current version to get etag and existing graph items
        current = _fetch_and_cache_version(client, cache_manager, flow_id, version_id)
        etag = current.get("etag")
        assert etag is not None

        # Build PATCH body with null-deletes for full graph replacement
        patch_body = _build_replace_patch(current, body)

        try:
            result = api_patch_version(client, version_id, patch_body, if_match=etag)
            normalize_graph_response(result)
            cache_manager.write_version(version_id, flow_id, result)
            detail = VersionDetail.model_validate(result)
            track(
                "operation",
                {
                    "op": "replace_version",
                    "success": True,
                    "output_tokens": estimate_tokens(detail),
                    "duration_ms": int((time.monotonic() - start) * 1000),
                    "flow_slug": flow_slug,
                    "flow_version_name": version_name,
                    "etag_retries": attempt,
                },
            )
            return detail
        except ConflictError as exc:
            if str(exc).lower().startswith("[validation]"):
                raise
            if attempt == _MAX_ETAG_RETRIES - 1:
                raise ConflictError(
                    f'Version "{version_name}" has been modified {_MAX_ETAG_RETRIES} times during update -- giving up.'
                )
            continue

    raise ConflictError(f'Version "{version_name}" conflict')  # pragma: no cover
