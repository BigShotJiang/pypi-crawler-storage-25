"""Pre-built flow graph templates for batch node creation.

Each template returns a graph body compatible with ``replace_version``.
Sending all nodes in a single PATCH requires just 1 GET + 1 PATCH regardless
of how many nodes the template contains.
"""

from __future__ import annotations

import uuid
from typing import Any, Callable


def _uid() -> str:
    return str(uuid.uuid4())


def build_linear(user_id: str = "cli-user") -> dict[str, Any]:
    """input → transform → assignment → output

    Minimal skeleton: one transform for business logic, one assignment to set
    the final decision field.
    """
    transform_id = _uid()
    assign_id = _uid()
    return {
        "graph": {
            "nodes": {
                "node_input": {"name": "Input", "type": "input", "meta": {}},
                transform_id: {
                    "name": "Transform",
                    "type": "transform",
                    "meta": {
                        "src": "# Apply business logic here\nreturn data",
                        "created_by_id": user_id,
                        "updated_by_id": user_id,
                    },
                },
                assign_id: {
                    "name": "Set Decision",
                    "type": "assignment_node",
                    "meta": {
                        "default_effects": [],
                        "created_by_id": user_id,
                        "updated_by_id": user_id,
                    },
                },
                "node_output": {"name": "Output", "type": "output", "meta": {}},
            },
            "edges": {
                _uid(): {
                    "start_node_id": "node_input",
                    "end_node_id": transform_id,
                    "meta": {"is_split_edge": False},
                },
                _uid(): {
                    "start_node_id": transform_id,
                    "end_node_id": assign_id,
                    "meta": {"is_split_edge": False},
                },
                _uid(): {
                    "start_node_id": assign_id,
                    "end_node_id": "node_output",
                    "meta": {"is_split_edge": False},
                },
            },
            "node_groups": {},
        }
    }


def build_gated(user_id: str = "cli-user") -> dict[str, Any]:
    """input → eligibility split → [decline branch | continue branch] → merge → assignment → output

    A gate checks eligibility; ineligible applicants are declined immediately.
    The eligible path leads to a merge then a final assignment.
    """
    split_id = _uid()
    branch_eligible_id = _uid()
    branch_decline_id = _uid()
    merge_id = _uid()
    assign_id = _uid()
    e_split_eligible = _uid()
    e_split_decline = _uid()

    return {
        "graph": {
            "nodes": {
                "node_input": {"name": "Input", "type": "input", "meta": {}},
                split_id: {
                    "name": "Eligibility Gate",
                    "type": "split_2",
                    "meta": {
                        "branches": [
                            {
                                "id": "",
                                "junction": "and",
                                "edge_id": e_split_eligible,
                                "clauses": [
                                    {
                                        "id_left": "",
                                        "id_right": "",
                                        "left": "data.eligible",
                                        "right": '"true"',
                                        "operator": "eq",
                                    }
                                ],
                            },
                            {
                                "id": "",
                                "junction": "and",
                                "edge_id": e_split_decline,
                                "clauses": [],
                            },
                        ],
                        "default_edge_id": e_split_decline,
                    },
                },
                branch_eligible_id: {
                    "name": "Eligible Path",
                    "type": "transform",
                    "meta": {
                        "src": "# Process eligible applicant\nreturn data",
                        "is_split_branch_node": True,
                        "created_by_id": user_id,
                        "updated_by_id": user_id,
                    },
                },
                branch_decline_id: {
                    "name": "Decline Path",
                    "type": "transform",
                    "meta": {
                        "src": "data['decision'] = 'DECLINE'\nreturn data",
                        "is_split_branch_node": True,
                        "created_by_id": user_id,
                        "updated_by_id": user_id,
                    },
                },
                merge_id: {
                    "name": "Merge",
                    "type": "transform",
                    "meta": {
                        "src": "return data",
                        "is_split_merge_node": True,
                        "created_by_id": user_id,
                        "updated_by_id": user_id,
                    },
                },
                assign_id: {
                    "name": "Set Decision",
                    "type": "assignment_node",
                    "meta": {
                        "default_effects": [],
                        "created_by_id": user_id,
                        "updated_by_id": user_id,
                    },
                },
                "node_output": {"name": "Output", "type": "output", "meta": {}},
            },
            "edges": {
                _uid(): {
                    "start_node_id": "node_input",
                    "end_node_id": split_id,
                    "meta": {"is_split_edge": False},
                },
                e_split_eligible: {
                    "start_node_id": split_id,
                    "end_node_id": branch_eligible_id,
                    "meta": {"is_split_edge": True},
                },
                e_split_decline: {
                    "start_node_id": split_id,
                    "end_node_id": branch_decline_id,
                    "meta": {"is_split_edge": True},
                },
                _uid(): {
                    "start_node_id": branch_eligible_id,
                    "end_node_id": merge_id,
                    "meta": {"is_split_edge": False},
                },
                _uid(): {
                    "start_node_id": branch_decline_id,
                    "end_node_id": merge_id,
                    "meta": {"is_split_edge": False},
                },
                _uid(): {
                    "start_node_id": merge_id,
                    "end_node_id": assign_id,
                    "meta": {"is_split_edge": False},
                },
                _uid(): {
                    "start_node_id": assign_id,
                    "end_node_id": "node_output",
                    "meta": {"is_split_edge": False},
                },
            },
            "node_groups": {},
        }
    }


def build_scored(user_id: str = "cli-user") -> dict[str, Any]:
    """input → transform (score) → rule (threshold) → assignment → output

    Computes a score in a transform, then uses a rule node to evaluate the
    threshold and set an approve/decline effect in the assignment.
    """
    score_id = _uid()
    rule_id = _uid()
    assign_id = _uid()

    return {
        "graph": {
            "nodes": {
                "node_input": {"name": "Input", "type": "input", "meta": {}},
                score_id: {
                    "name": "Calculate Score",
                    "type": "transform",
                    "meta": {
                        "src": (
                            "# Compute a risk score (0-1000)\n"
                            "data['score'] = 500  # replace with real logic\n"
                            "return data"
                        ),
                        "created_by_id": user_id,
                        "updated_by_id": user_id,
                    },
                },
                rule_id: {
                    "name": "Score Threshold",
                    "type": "rule_2",
                    "meta": {
                        "default_effects": [
                            {
                                "id": "",
                                "field": "data.decision",
                                "operator": "set",
                                "value": '"DECLINE"',
                            }
                        ],
                        "branches": [
                            {
                                "id": "",
                                "junction": "and",
                                "clauses": [
                                    {
                                        "id_left": "",
                                        "id_right": "",
                                        "left": "data.score",
                                        "right": "600",
                                        "operator": "ge",
                                    }
                                ],
                                "effects": [
                                    {
                                        "id": "",
                                        "field": "data.decision",
                                        "operator": "set",
                                        "value": '"APPROVE"',
                                    }
                                ],
                            }
                        ],
                        "created_by_id": user_id,
                        "updated_by_id": user_id,
                    },
                },
                assign_id: {
                    "name": "Set Decision",
                    "type": "assignment_node",
                    "meta": {
                        "default_effects": [],
                        "created_by_id": user_id,
                        "updated_by_id": user_id,
                    },
                },
                "node_output": {"name": "Output", "type": "output", "meta": {}},
            },
            "edges": {
                _uid(): {
                    "start_node_id": "node_input",
                    "end_node_id": score_id,
                    "meta": {"is_split_edge": False},
                },
                _uid(): {
                    "start_node_id": score_id,
                    "end_node_id": rule_id,
                    "meta": {"is_split_edge": False},
                },
                _uid(): {
                    "start_node_id": rule_id,
                    "end_node_id": assign_id,
                    "meta": {"is_split_edge": False},
                },
                _uid(): {
                    "start_node_id": assign_id,
                    "end_node_id": "node_output",
                    "meta": {"is_split_edge": False},
                },
            },
            "node_groups": {},
        }
    }


def build_lookup(user_id: str = "cli-user") -> dict[str, Any]:
    """input → transform (prepare) → decision_table (lookup) → assignment → output

    Prepares lookup fields in a transform, then routes to a decision_table
    for deterministic rule-based outcomes, and assigns the result.
    """
    prepare_id = _uid()
    table_id = _uid()
    assign_id = _uid()
    pred_field_id = _uid()
    eff_field_id = _uid()

    return {
        "graph": {
            "nodes": {
                "node_input": {"name": "Input", "type": "input", "meta": {}},
                prepare_id: {
                    "name": "Prepare Lookup",
                    "type": "transform",
                    "meta": {
                        "src": "# Normalize fields for table lookup\nreturn data",
                        "created_by_id": user_id,
                        "updated_by_id": user_id,
                    },
                },
                table_id: {
                    "name": "Decision Table",
                    "type": "decision_table",
                    "meta": {
                        "predicate_fields": [
                            {
                                "id": pred_field_id,
                                "name": "Input Field",
                                "expression": "data.lookup_field",
                                "data_type": "string",
                            }
                        ],
                        "effect_fields": [
                            {
                                "id": eff_field_id,
                                "name": "Result",
                                "expression": "data.result",
                                "data_type": "string",
                            }
                        ],
                        "cases": [],
                        "fallback": {pred_field_id: None, eff_field_id: None},
                        "is_fallthrough": False,
                    },
                },
                assign_id: {
                    "name": "Apply Result",
                    "type": "assignment_node",
                    "meta": {
                        "default_effects": [],
                        "created_by_id": user_id,
                        "updated_by_id": user_id,
                    },
                },
                "node_output": {"name": "Output", "type": "output", "meta": {}},
            },
            "edges": {
                _uid(): {
                    "start_node_id": "node_input",
                    "end_node_id": prepare_id,
                    "meta": {"is_split_edge": False},
                },
                _uid(): {
                    "start_node_id": prepare_id,
                    "end_node_id": table_id,
                    "meta": {"is_split_edge": False},
                },
                _uid(): {
                    "start_node_id": table_id,
                    "end_node_id": assign_id,
                    "meta": {"is_split_edge": False},
                },
                _uid(): {
                    "start_node_id": assign_id,
                    "end_node_id": "node_output",
                    "meta": {"is_split_edge": False},
                },
            },
            "node_groups": {},
        }
    }


TEMPLATES: dict[str, Callable[[str], dict[str, Any]]] = {
    "linear": build_linear,
    "gated": build_gated,
    "scored": build_scored,
    "lookup": build_lookup,
}
