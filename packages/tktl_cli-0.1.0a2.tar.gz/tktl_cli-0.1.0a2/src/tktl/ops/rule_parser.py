"""Natural language rule parser for --rule option on nodes add."""

from __future__ import annotations

import re
from typing import Any

from tktl.models.errors import UsageError

# Operator text → API operator code
_OP_MAP: dict[str, str] = {
    "<=": "le",
    ">=": "ge",
    "!=": "ne",
    "==": "eq",
    "<": "lt",
    ">": "gt",
    "contains": "contains",
    "is not null": "is_not_none",
    "is null": "is_none",
}

# Regex to match a condition: field op value
# Handles multi-word operators like "is null", "is not null", "contains"
_CONDITION_RE = re.compile(
    r"(\w+)\s*(is not null|is null|contains|<=|>=|!=|==|<|>)\s*(.*?)(?=\s+and\b|\s+or\b|$)",
    re.IGNORECASE,
)

# Effect: field=value
_EFFECT_RE = re.compile(r"(\w+)\s*=\s*(.*?)(?=\s*,\s*\w+\s*=|$)")


def _parse_value_for_effect(raw: str) -> str:
    """Convert a raw value string to effect value representation."""
    raw = raw.strip()
    if raw in ("None", "null"):
        return "None"
    if raw in ("True", "true"):
        return "True"
    if raw in ("False", "false"):
        return "False"
    # Quoted string — keep as-is (strip outer quotes, re-wrap in escaped quotes)
    if (raw.startswith("'") and raw.endswith("'")) or (raw.startswith('"') and raw.endswith('"')):
        inner = raw[1:-1]
        return f'"{inner}"'
    # Numeric
    try:
        float(raw)
        return raw
    except ValueError:
        pass
    # Bare word — wrap in quotes
    return f'"{raw}"'


def _parse_value_for_clause(raw: str) -> str:
    """Convert a raw value string to clause right-side value representation."""
    raw = raw.strip()
    if raw in ("None", "null"):
        return "None"
    if raw in ("True", "true"):
        return "True"
    if raw in ("False", "false"):
        return "False"
    # Quoted string
    if (raw.startswith("'") and raw.endswith("'")) or (raw.startswith('"') and raw.endswith('"')):
        inner = raw[1:-1]
        return f'"{inner}"'
    # Numeric
    try:
        float(raw)
        return raw
    except ValueError:
        pass
    # Bare word — leave as-is (API will interpret)
    return raw


def _parse_effects(effects_str: str) -> list[dict[str, Any]]:
    """Parse 'field=value, field2=value2' into list of effect dicts."""
    effects: list[dict[str, Any]] = []
    # Split on commas that are followed by a word and '='
    parts = re.split(r",\s*(?=\w+\s*=)", effects_str.strip())
    for part in parts:
        part = part.strip()
        if not part:
            continue
        m = re.match(r"(\w+)\s*=\s*(.*)", part)
        if not m:
            continue
        field = m.group(1).strip()
        value_raw = m.group(2).strip()
        effects.append({"id": "", "target": field, "value": _parse_value_for_effect(value_raw)})
    return effects


def _parse_conditions(conditions_str: str) -> tuple[list[dict[str, Any]], str]:
    """Parse conditions string, returning (clauses, junction).

    Returns list of clause dicts and junction ("and" or "or").
    """
    # Detect junction
    # Split on ' and ' or ' or ' (case-insensitive), but not inside quotes
    conditions_str = conditions_str.strip()

    # Find all 'and'/'or' connectors at top level
    # Simple approach: tokenise
    junction = "and"
    if re.search(r"\bor\b", conditions_str, re.IGNORECASE):
        junction = "or"

    # Split on ' and ' or ' or '
    parts = re.split(r"\s+(?:and|or)\s+", conditions_str, flags=re.IGNORECASE)

    clauses: list[dict[str, Any]] = []
    for part in parts:
        part = part.strip()
        if not part:
            continue

        # Try to match condition
        m = _CONDITION_RE.match(part)
        if not m:
            raise UsageError(
                f"Cannot parse --rule: condition '{part}' not understood. "
                "Expected: 'field op value' (ops: <, <=, >, >=, ==, !=, contains, is null, is not null)"
            )

        field = m.group(1).strip()
        op_text = m.group(2).strip().lower()
        value_raw = m.group(3).strip() if m.group(3) else ""

        op_code = _OP_MAP.get(op_text)
        if op_code is None:
            raise UsageError(f"Cannot parse --rule: unknown operator '{op_text}'")

        clause: dict[str, Any] = {
            "id_left": "",
            "id_right": "",
            "left": f"data.{field}",
            "operator": op_code,
        }

        if op_code in ("is_none", "is_not_none"):
            clause["right"] = ""
        else:
            clause["right"] = _parse_value_for_clause(value_raw)

        clauses.append(clause)

    return clauses, junction


def parse_natural_rule(text: str) -> dict[str, Any]:
    """Parse a natural language rule into a rule_2 node meta dict.

    Expected format: "if <conditions> then <effects> else <effects>"

    Raises UsageError if the format is not understood.
    """
    text = text.strip()

    # Match: if ... then ... [else ...]
    m = re.match(
        r"^if\s+(.+?)\s+then\s+(.+?)(?:\s+else\s+(.+))?$",
        text,
        re.IGNORECASE | re.DOTALL,
    )
    if not m:
        raise UsageError(
            f"Cannot parse --rule: {text!r}. "
            "Expected: 'if <conditions> then <field>=<value>[,...] else <field>=<value>[,...]'"
        )

    conditions_str = m.group(1).strip()
    then_str = m.group(2).strip()
    else_str = m.group(3).strip() if m.group(3) else None

    if else_str is None:
        raise UsageError("--rule requires an 'else' clause: 'if ... then ... else ...'")

    try:
        clauses, junction = _parse_conditions(conditions_str)
    except UsageError:
        raise
    except Exception as exc:
        raise UsageError(
            f"Cannot parse --rule: {text!r}. "
            "Expected: 'if <conditions> then <field>=<value>[,...] else <field>=<value>[,...]'"
        ) from exc

    branch_effects = _parse_effects(then_str)
    default_effects = _parse_effects(else_str)

    return {
        "default_effects": default_effects,
        "branches": [
            {
                "id": "",
                "name": "Passes checks",
                "junction": junction,
                "clauses": clauses,
                "effects": branch_effects,
            }
        ],
    }
