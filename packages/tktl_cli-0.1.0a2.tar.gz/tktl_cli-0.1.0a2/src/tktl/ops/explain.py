"""Operations layer — plain-English flow explanation."""

from __future__ import annotations

from typing import Any

from tktl.api.client import TktlClient
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.ops.versions import _fetch_and_cache_version, _resolve_ids


def _describe_node(node: dict[str, Any]) -> str:
    """Generate a plain-English description for a single node."""
    ntype = node.get("type", "")
    name = node.get("name", "unknown")
    meta = node.get("meta") or {}

    if ntype == "input":
        schema = meta.get("input_schema") or {}
        props = list(schema.get("properties", {}).keys())
        if props:
            return f"Takes inputs: {', '.join(props)}"
        return "Takes inputs: unspecified"

    if ntype == "output":
        schema = meta.get("output_schema") or {}
        props = list(schema.get("properties", {}).keys())
        if props:
            return f"Returns outputs: {', '.join(props)}"
        return "Returns outputs: unspecified"

    if ntype == "assignment_node":
        # Collect target fields
        effects = meta.get("effects") or []
        targets = [e.get("target", "") for e in effects if e.get("target")]
        if targets:
            return f"Sets {', '.join(targets)} to fixed values."
        return "Sets fields to fixed values."

    if ntype == "rule_2":
        branches = meta.get("branches") or []
        branch_names = [b.get("name", "branch") for b in branches if b.get("name")]
        if branch_names:
            # Collect effect targets from branches
            all_targets: list[str] = []
            for branch in branches:
                for eff in branch.get("effects") or []:
                    t = eff.get("target", "")
                    if t and t not in all_targets:
                        all_targets.append(t)
            if all_targets:
                return (
                    f"Checks conditions: {', '.join(branch_names)}. "
                    f"Sets {', '.join(all_targets)} based on which branch matches."
                )
            return f"Checks conditions: {', '.join(branch_names)}."
        return "Applies rule logic."

    if ntype == "split_2":
        branches = meta.get("branches") or []
        if branches:
            # Try to extract a readable condition
            first_branch = branches[0]
            clauses = first_branch.get("clauses") or []
            if clauses:
                clause = clauses[0]
                left = clause.get("left", "").replace("data.", "")
                op = clause.get("operator", "")
                right = clause.get("right", "")
                return f"Routes on: {left} {op} {right}."
        return f"Routes on: {name}."

    if ntype == "transform":
        return f"Runs custom code: {name}."

    if ntype == "scorecard":
        assign_field = meta.get("assign_field") or meta.get("output_field") or "score"
        factors = meta.get("factors") or meta.get("buckets") or []
        factor_names = [f.get("name", "") for f in factors if f.get("name")]
        if factor_names:
            return f"Scores {assign_field} using {len(factor_names)} factors: {', '.join(factor_names[:5])}."
        return f"Scores {assign_field}."

    if ntype == "decision_table":
        predicates = meta.get("predicates") or []
        effects_list = meta.get("effects") or []
        pred_fields = [p.get("field", "").replace("data.", "") for p in predicates if p.get("field")]
        eff_fields = [e.get("field", "").replace("data.", "") for e in effects_list if e.get("field")]
        if pred_fields and eff_fields:
            return f"Looks up {', '.join(eff_fields)} based on {', '.join(pred_fields)}."
        return "Looks up values from a decision table."

    if ntype == "matrix_table":
        result_field = meta.get("result_field", "result").replace("data.", "")
        row_field = meta.get("row_field", "row").replace("data.", "")
        col_field = meta.get("column_field") or meta.get("col_field", "column")
        if isinstance(col_field, str):
            col_field = col_field.replace("data.", "")
        return f"Looks up {result_field} from a {row_field} × {col_field} grid."

    if ntype in ("custom_connection_node", "webhook_connection_node"):
        return f"Calls external API: {name}."

    if ntype == "flow":
        return f"Calls sub-flow: {name}."

    # Branch/merge — skip
    if isinstance(meta, dict) and (meta.get("is_split_branch_node") or meta.get("is_split_merge_node")):
        return ""

    return f"{name} ({ntype})"


def explain_flow(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
    workspace_id: str,
    flow_slug: str,
    version_name: str,
) -> dict[str, Any]:
    """Generate a plain-English summary of a flow version.

    Returns a dict with keys: flow, version, summary, nodes.
    """
    flow_id, version_id = _resolve_ids(client, cache_index, workspace_id, flow_slug, version_name)
    assert version_id is not None

    raw = _fetch_and_cache_version(client, cache_manager, flow_id, version_id)
    graph: dict[str, Any] = raw.get("graph") or {}
    nodes_dict: dict[str, Any] = graph.get("nodes") or {}

    node_descriptions: list[dict[str, Any]] = []
    sentence_parts: list[str] = []

    for node_id, node in nodes_dict.items():
        ntype = node.get("type", "")
        name = node.get("name", node_id)
        meta = node.get("meta") or {}

        # Skip branch/merge utility nodes
        if isinstance(meta, dict) and (meta.get("is_split_branch_node") or meta.get("is_split_merge_node")):
            continue

        description = _describe_node(node)
        if description:
            node_descriptions.append({"name": name, "type": ntype, "description": description})
            sentence_parts.append(description)

    # Build a summary paragraph
    if sentence_parts:
        summary = " ".join(sentence_parts)
    else:
        summary = f"Flow '{flow_slug}' version '{version_name}' has no nodes."

    return {
        "flow": flow_slug,
        "version": version_name,
        "summary": summary,
        "nodes": node_descriptions,
    }
