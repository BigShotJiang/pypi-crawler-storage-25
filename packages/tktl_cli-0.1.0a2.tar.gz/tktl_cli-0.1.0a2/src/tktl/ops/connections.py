"""Operations layer — workspace connections."""

from __future__ import annotations

from typing import Any

from tktl.api.client import TktlClient
from tktl.api.connections import create_connection as api_create_connection
from tktl.api.connections import create_resource_config as api_create_resource_config
from tktl.api.connections import list_connections as api_list_connections
from tktl.api.connections import update_secrets as api_update_secrets
from tktl.api.execution import _resolve_workspace_base_url
from tktl.models.connection import ConnectionDetail, ConnectionSummary, ResourceConfigDetail


def list_connections(
    client: TktlClient,
    workspace_id: str,
) -> list[ConnectionSummary]:
    """List all connections in the workspace."""
    base_url = _resolve_workspace_base_url(client, workspace_id)
    raw = api_list_connections(client._api_key, base_url)
    return [ConnectionSummary.model_validate(c) for c in raw]


def create_connection(
    client: TktlClient,
    workspace_id: str,
    name: str,
    provider: str,
    *,
    is_sandbox: bool = False,
    base_url: str | None = None,
    auth_method: str = "no_auth",
    secrets: list[dict[str, Any]] | None = None,
) -> ConnectionDetail:
    """Create a new connection in the workspace."""
    ws_base_url = _resolve_workspace_base_url(client, workspace_id)

    body: dict[str, Any] = {
        "name": name,
        "is_sandbox": is_sandbox,
        "provider": provider,
    }

    if base_url is not None:
        body["configuration"] = {
            "base_url": base_url,
            "auth_settings": {"auth_method": auth_method},
        }

    if secrets:
        body["secrets"] = secrets

    raw = api_create_connection(client._api_key, ws_base_url, body)
    return ConnectionDetail.model_validate(raw)


def create_resource_config(
    client: TktlClient,
    workspace_id: str,
    connection_id: str,
    name: str,
    resource: str,
    configuration: dict[str, Any] | None = None,
) -> ResourceConfigDetail:
    """Create a resource config on a connection."""
    ws_base_url = _resolve_workspace_base_url(client, workspace_id)

    body: dict[str, Any] = {
        "name": name,
        "resource": resource,
        "configuration": configuration or {},
    }

    raw = api_create_resource_config(client._api_key, ws_base_url, connection_id, body)
    return ResourceConfigDetail.model_validate(raw)


def update_secrets(
    client: TktlClient,
    workspace_id: str,
    connection_id: str,
    secrets: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Update secrets on a connection."""
    ws_base_url = _resolve_workspace_base_url(client, workspace_id)
    return api_update_secrets(client._api_key, ws_base_url, connection_id, secrets)
