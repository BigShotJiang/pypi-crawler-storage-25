"""Operations layer — dataset CRUD and schema-aware operations."""

from __future__ import annotations

import time as _time
import uuid
from pathlib import Path
from typing import Any

import httpx

from tktl.api.client import TktlClient
from tktl.api.datasets import (
    append_rows_api,
    create_dataset_api,
    create_file_upload_api,
    delete_columns_api,
    delete_dataset_api,
    delete_row_api,
    download_dataset_file_api,
    fill_column_api,
    get_dataset_api,
    get_file_upload_api,
    list_datasets_api,
    update_row_api,
    upsert_columns_api,
)
from tktl.api.execution import _resolve_workspace_base_url
from tktl.api.flows import get_flow_by_slug
from tktl.api.versions import get_version as api_get_version
from tktl.cache.index import CacheIndex
from tktl.models.dataset import (
    ColumnGroup,
    ColumnType,
    Dataset,
    DatasetColumn,
    DatasetFileUpload,
    DatasetRow,
    DatasetSummary,
    SchemaDiff,
    TypeMismatch,
)
from tktl.models.errors import NotFoundError, TktlError, UsageError

# Max rows per append API call
_MAX_ROWS_PER_APPEND = 50

# Polling delays for file upload (seconds)
_UPLOAD_POLL_DELAYS = [0.5] * 5 + [1.0] * 5 + [2.0] * 10

# JSON Schema type -> Dataset ColumnType mapping
_JSON_SCHEMA_TYPE_MAP: dict[str, ColumnType] = {
    "string": ColumnType.string,
    "number": ColumnType.number,
    "integer": ColumnType.integer,
    "boolean": ColumnType.boolean,
    "object": ColumnType.object,
    "array": ColumnType.array,
}


def _resolve_flow_id(
    client: TktlClient,
    cache_index: CacheIndex,
    workspace_id: str,
    flow_slug: str,
) -> str:
    """Resolve a flow slug to its UUID."""
    flow_id = cache_index.resolve_flow_id(flow_slug)
    if flow_id is not None:
        return flow_id

    raw = get_flow_by_slug(client, workspace_id, flow_slug)
    flow_id = raw["id"]
    versions_map: dict[str, str] = {}
    for v in raw.get("versions", []):
        versions_map[v["name"]] = v["id"]
    cache_index.update_flow(flow_slug, flow_id, versions_map)
    cache_index.save()
    return flow_id


def _resolve_version_id(
    client: TktlClient,
    cache_index: CacheIndex,
    workspace_id: str,
    flow_slug: str,
    version_name: str,
) -> str:
    """Resolve a version name to its UUID."""
    _resolve_flow_id(client, cache_index, workspace_id, flow_slug)

    version_id = cache_index.resolve_version_id(flow_slug, version_name)
    if version_id is not None:
        return version_id

    raw = get_flow_by_slug(client, workspace_id, flow_slug)
    versions_map: dict[str, str] = {}
    for v in raw.get("versions", []):
        versions_map[v["name"]] = v["id"]
    cache_index.update_flow(flow_slug, raw["id"], versions_map)
    cache_index.save()

    version_id = cache_index.resolve_version_id(flow_slug, version_name)
    if version_id is None:
        raise NotFoundError(f"Version not found: {version_name}")
    return version_id


def _get_ws_auth(client: TktlClient, workspace_id: str) -> tuple[str, str]:
    """Resolve workspace base URL and extract API key.

    Returns (api_key, workspace_base_url).
    """
    ws_base_url = _resolve_workspace_base_url(client, workspace_id)
    api_key = client._api_key
    return api_key, ws_base_url


def _schema_to_columns(input_schema: dict[str, Any]) -> list[DatasetColumn]:
    """Convert a JSON Schema to a list of DatasetColumns."""
    columns: list[DatasetColumn] = []
    properties = input_schema.get("properties", {})
    for name, prop in properties.items():
        json_type = prop.get("type", "any")
        if isinstance(json_type, list):
            json_type = next((t for t in json_type if t != "null"), "any")
        col_type = _JSON_SCHEMA_TYPE_MAP.get(json_type, ColumnType.any)
        columns.append(DatasetColumn(name=name, desired_type=col_type))
    return columns


# ---------------------------------------------------------------------------
# Dataset operations
# ---------------------------------------------------------------------------


def list_datasets(
    client: TktlClient,
    cache_index: CacheIndex,
    workspace_id: str,
    flow_slug: str,
) -> list[DatasetSummary]:
    """List all datasets for a flow."""
    flow_id = _resolve_flow_id(client, cache_index, workspace_id, flow_slug)
    api_key, ws_url = _get_ws_auth(client, workspace_id)
    raw = list_datasets_api(api_key, ws_url, flow_id)
    return [DatasetSummary.model_validate(d) for d in raw]


def create_dataset(
    client: TktlClient,
    cache_index: CacheIndex,
    workspace_id: str,
    flow_slug: str,
    name: str,
    input_columns: list[DatasetColumn],
    mock_columns: list[DatasetColumn] | None = None,
) -> Dataset:
    """Create a dataset from scratch with explicit columns."""
    flow_id = _resolve_flow_id(client, cache_index, workspace_id, flow_slug)
    api_key, ws_url = _get_ws_auth(client, workspace_id)
    body: dict[str, Any] = {
        "name": name,
        "flow_id": flow_id,
        "input_columns": [c.model_dump() for c in input_columns],
        "mock_columns": [c.model_dump() for c in (mock_columns or [])],
    }
    raw = create_dataset_api(api_key, ws_url, body)
    return Dataset.model_validate(raw)


def create_from_schema(
    client: TktlClient,
    cache_index: CacheIndex,
    workspace_id: str,
    flow_slug: str,
    version_name: str,
    dataset_name: str,
) -> Dataset:
    """Create a dataset with columns derived from the version's input schema."""
    flow_id = _resolve_flow_id(client, cache_index, workspace_id, flow_slug)
    version_id = _resolve_version_id(client, cache_index, workspace_id, flow_slug, version_name)

    raw_version = api_get_version(client, version_id)
    if raw_version is None:
        raise NotFoundError(f"Version '{version_name}' not found")

    input_schema = raw_version.get("input_schema") or {}
    if not input_schema.get("properties"):
        raise UsageError(f"Version '{version_name}' has no input schema properties")

    columns = _schema_to_columns(input_schema)

    api_key, ws_url = _get_ws_auth(client, workspace_id)
    body: dict[str, Any] = {
        "name": dataset_name,
        "flow_id": flow_id,
        "input_columns": [c.model_dump() for c in columns],
        "mock_columns": [],
    }
    raw = create_dataset_api(api_key, ws_url, body)
    return Dataset.model_validate(raw)


def describe_dataset(
    client: TktlClient,
    workspace_id: str,
    dataset_id: str,
) -> Dataset:
    """Get dataset metadata with first page of rows."""
    api_key, ws_url = _get_ws_auth(client, workspace_id)
    raw = get_dataset_api(api_key, ws_url, dataset_id, from_=0, size=0)
    return Dataset.model_validate(raw)


def get_rows(
    client: TktlClient,
    workspace_id: str,
    dataset_id: str,
    from_: int = 0,
    size: int = 50,
) -> list[DatasetRow]:
    """Get paginated rows from a dataset."""
    api_key, ws_url = _get_ws_auth(client, workspace_id)
    raw = get_dataset_api(api_key, ws_url, dataset_id, from_=from_, size=size)
    return [DatasetRow.model_validate(r) for r in raw.get("rows", [])]


def add_blank_rows(
    client: TktlClient,
    workspace_id: str,
    dataset_id: str,
    count: int,
) -> list[DatasetRow]:
    """Add blank rows to a dataset. Handles auto-batching."""
    if count < 1:
        raise UsageError("Count must be at least 1")

    api_key, ws_url = _get_ws_auth(client, workspace_id)
    all_rows: list[DatasetRow] = []

    remaining = count
    while remaining > 0:
        batch_size = min(remaining, _MAX_ROWS_PER_APPEND)
        row_ids = [str(uuid.uuid4()) for _ in range(batch_size)]
        body = {"source": "blank", "new_row_ids": row_ids}
        raw = append_rows_api(api_key, ws_url, dataset_id, body)
        all_rows.extend(DatasetRow.model_validate(r) for r in raw)
        remaining -= batch_size

    return all_rows


def add_rows(
    client: TktlClient,
    workspace_id: str,
    dataset_id: str,
    rows_data: list[dict[str, Any]],
) -> list[DatasetRow]:
    """Add rows with data to a dataset.

    Creates blank rows then updates each with data. Auto-batches in groups of 50.
    """
    if not rows_data:
        raise UsageError("No rows to add")

    api_key, ws_url = _get_ws_auth(client, workspace_id)
    all_rows: list[DatasetRow] = []

    for batch_start in range(0, len(rows_data), _MAX_ROWS_PER_APPEND):
        batch = rows_data[batch_start : batch_start + _MAX_ROWS_PER_APPEND]
        row_ids = [str(uuid.uuid4()) for _ in range(len(batch))]

        body = {"source": "blank", "new_row_ids": row_ids}
        append_rows_api(api_key, ws_url, dataset_id, body)

        for data, row_id in zip(batch, row_ids):
            updated = update_row_api(api_key, ws_url, dataset_id, row_id, {"input_data": data})
            all_rows.append(DatasetRow.model_validate(updated))

    return all_rows


def update_row(
    client: TktlClient,
    workspace_id: str,
    dataset_id: str,
    row_id: str,
    data: dict[str, Any],
) -> DatasetRow:
    """Update a single row's data."""
    api_key, ws_url = _get_ws_auth(client, workspace_id)
    raw = update_row_api(api_key, ws_url, dataset_id, row_id, data)
    return DatasetRow.model_validate(raw)


def delete_row(
    client: TktlClient,
    workspace_id: str,
    dataset_id: str,
    row_id: str,
) -> None:
    """Delete a single row."""
    api_key, ws_url = _get_ws_auth(client, workspace_id)
    delete_row_api(api_key, ws_url, dataset_id, row_id)


def delete_dataset(
    client: TktlClient,
    workspace_id: str,
    dataset_id: str,
) -> None:
    """Delete a dataset permanently."""
    api_key, ws_url = _get_ws_auth(client, workspace_id)
    delete_dataset_api(api_key, ws_url, dataset_id)


# ---------------------------------------------------------------------------
# Column operations
# ---------------------------------------------------------------------------


def add_column(
    client: TktlClient,
    workspace_id: str,
    dataset_id: str,
    group: ColumnGroup,
    name: str,
    desired_type: ColumnType,
) -> Dataset:
    """Add a column to a dataset."""
    api_key, ws_url = _get_ws_auth(client, workspace_id)
    body = [
        {
            "group": group.value,
            "column": {"name": name, "desired_type": desired_type.value},
        }
    ]
    raw = upsert_columns_api(api_key, ws_url, dataset_id, body)
    return Dataset.model_validate(raw)


def rename_column(
    client: TktlClient,
    workspace_id: str,
    dataset_id: str,
    group: ColumnGroup,
    old_name: str,
    new_name: str,
) -> Dataset:
    """Rename a column (also renames underlying data)."""
    api_key, ws_url = _get_ws_auth(client, workspace_id)
    ds_raw = get_dataset_api(api_key, ws_url, dataset_id, from_=0, size=0)
    ds = Dataset.model_validate(ds_raw)

    col_list = getattr(ds, group.value, []) or []
    col_type = ColumnType.any
    for col in col_list:
        if col.name == old_name:
            col_type = col.desired_type
            break

    body = [
        {
            "group": group.value,
            "column": {"name": new_name, "desired_type": col_type.value},
            "column_to_replace": old_name,
        }
    ]
    raw = upsert_columns_api(api_key, ws_url, dataset_id, body)
    return Dataset.model_validate(raw)


def delete_column(
    client: TktlClient,
    workspace_id: str,
    dataset_id: str,
    group: ColumnGroup,
    name: str,
) -> Dataset:
    """Delete a column from a dataset."""
    api_key, ws_url = _get_ws_auth(client, workspace_id)
    body = [{"group": group.value, "name": name}]
    raw = delete_columns_api(api_key, ws_url, dataset_id, body)
    return Dataset.model_validate(raw)


def fill_column(
    client: TktlClient,
    workspace_id: str,
    dataset_id: str,
    group: ColumnGroup,
    name: str,
    value: Any,
    from_: int = 0,
    limit: int | None = None,
) -> Dataset:
    """Fill a column with a value."""
    api_key, ws_url = _get_ws_auth(client, workspace_id)
    body: dict[str, Any] = {"fill_value": value, "from_": from_}
    if limit is not None:
        body["limit"] = limit
    raw = fill_column_api(api_key, ws_url, dataset_id, group.value, name, body)
    return Dataset.model_validate(raw)


# ---------------------------------------------------------------------------
# Upload
# ---------------------------------------------------------------------------


def upload_dataset(
    client: TktlClient,
    cache_index: CacheIndex,
    workspace_id: str,
    flow_slug: str,
    file_path: Path,
    name: str | None = None,
) -> Dataset:
    """Upload a local file as a new dataset."""
    flow_id = _resolve_flow_id(client, cache_index, workspace_id, flow_slug)
    api_key, ws_url = _get_ws_auth(client, workspace_id)

    if not file_path.exists():
        raise UsageError(f"File not found: {file_path}")

    file_name = file_path.name

    # Step 1: Create upload job
    upload_raw = create_file_upload_api(api_key, ws_url, {"flow_id": flow_id, "file_name": file_name})
    upload = DatasetFileUpload.model_validate(upload_raw)

    # Step 2: Upload to S3 (presigned POST)
    with open(file_path, "rb") as f:
        files = {"file": (file_name, f)}
        data = dict(upload.s3_presigned_fields)
        httpx.post(upload.s3_presigned_url, data=data, files=files, timeout=120.0)

    # Step 3: Poll until completed
    upload_id = upload.id
    for delay in _UPLOAD_POLL_DELAYS:
        status_raw = get_file_upload_api(api_key, ws_url, upload_id)
        status = status_raw.get("status", "")
        if status == "COMPLETED":
            dataset_id = status_raw.get("dataset_id")
            if dataset_id:
                ds_raw = get_dataset_api(api_key, ws_url, dataset_id, from_=0, size=0)
                return Dataset.model_validate(ds_raw)
            raise TktlError("Upload completed but no dataset_id returned")
        if status == "FAILED":
            error = status_raw.get("error_metadata", "Unknown error")
            raise TktlError(f"File upload failed: {error}")

        _time.sleep(delay)

    raise TktlError("File upload timed out")


# ---------------------------------------------------------------------------
# Download
# ---------------------------------------------------------------------------


def download_dataset(
    client: TktlClient,
    workspace_id: str,
    dataset_id: str,
    fmt: str = "csv",
    output_path: Path | None = None,
) -> str:
    """Download a dataset as a file."""
    api_key, ws_url = _get_ws_auth(client, workspace_id)
    data = download_dataset_file_api(api_key, ws_url, dataset_id, fmt=fmt)
    content = data.decode("utf-8")

    if output_path is not None:
        output_path.write_text(content)
        return str(output_path)

    return content


# ---------------------------------------------------------------------------
# Schema sync
# ---------------------------------------------------------------------------


def sync_schema(
    client: TktlClient,
    cache_index: CacheIndex,
    workspace_id: str,
    flow_slug: str,
    dataset_id: str,
    version_name: str,
    *,
    apply: bool = False,
) -> SchemaDiff:
    """Compare dataset columns against flow version input schema."""
    version_id = _resolve_version_id(client, cache_index, workspace_id, flow_slug, version_name)
    raw_version = api_get_version(client, version_id)
    if raw_version is None:
        raise NotFoundError(f"Version '{version_name}' not found")

    input_schema = raw_version.get("input_schema") or {}
    schema_columns = _schema_to_columns(input_schema)
    schema_by_name = {c.name: c for c in schema_columns}

    api_key, ws_url = _get_ws_auth(client, workspace_id)
    ds_raw = get_dataset_api(api_key, ws_url, dataset_id, from_=0, size=0)
    ds = Dataset.model_validate(ds_raw)
    ds_by_name = {c.name: c for c in ds.input_columns}

    missing: list[DatasetColumn] = []
    extra: list[DatasetColumn] = []
    mismatches: list[TypeMismatch] = []

    for name, schema_col in schema_by_name.items():
        if name not in ds_by_name:
            missing.append(schema_col)
        elif ds_by_name[name].desired_type != schema_col.desired_type:
            mismatches.append(
                TypeMismatch(
                    name=name,
                    dataset_type=ds_by_name[name].desired_type,
                    schema_type=schema_col.desired_type,
                )
            )

    for name, ds_col in ds_by_name.items():
        if name not in schema_by_name:
            extra.append(ds_col)

    diff = SchemaDiff(missing_columns=missing, extra_columns=extra, type_mismatches=mismatches)

    if apply and missing:
        body = [
            {
                "group": ColumnGroup.input_columns.value,
                "column": {"name": c.name, "desired_type": c.desired_type.value},
            }
            for c in missing
        ]
        upsert_columns_api(api_key, ws_url, dataset_id, body)

    return diff
