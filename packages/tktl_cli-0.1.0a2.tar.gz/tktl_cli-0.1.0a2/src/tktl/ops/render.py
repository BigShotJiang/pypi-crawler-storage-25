"""Operations layer — Mermaid diagram generation and PNG rendering."""

from __future__ import annotations

import re
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any

import html

import graphviz

from tktl.models.errors import RenderError
from tktl.ops.versions import _fetch_and_cache_version, _resolve_ids

# ---------------------------------------------------------------------------
# Mermaid block extraction
# ---------------------------------------------------------------------------

_MERMAID_BLOCK_RE = re.compile(r"```mermaid\n(.*?)\n```", re.DOTALL)
# Matches quoted label strings inside Mermaid nodes: ["..."] or ("...")
_MERMAID_LABEL_RE = re.compile(r'"([^"]*)"')


def extract_mermaid_blocks(md_text: str) -> list[str]:
    """Extract all ```mermaid ... ``` code blocks from a Markdown string."""
    return [m.group(1).strip() for m in _MERMAID_BLOCK_RE.finditer(md_text)]


def _normalize_newlines(code: str) -> str:
    """Replace ``\\n`` and literal newlines inside Mermaid label strings with ``<br/>``.

    Structural newlines (between diagram lines) are preserved; only newlines
    *inside* quoted label strings are replaced to prevent broken diagrams.
    """

    def _replace_label(m: re.Match) -> str:
        inner = m.group(1)
        inner = inner.replace("\\n", "<br/>")  # literal backslash-n
        inner = inner.replace("\n", "<br/>")  # actual newline
        return f'"{inner}"'

    return _MERMAID_LABEL_RE.sub(_replace_label, code)


# ---------------------------------------------------------------------------
# graph_to_mermaid — visual conventions
# ---------------------------------------------------------------------------

# Node type accent colors (matches Taktile "Add a node" panel icon backgrounds).
# This is the single source of truth for node-type colours — used by both the
# Graphviz renderer (render_graph_png) and the Mermaid text generator.
_TYPE_COLOR: dict[str, str] = {
    "input": "#6366F1",
    "output": "#6366F1",
    "ai_agent": "#8B7CF6",
    "assignment_node": "#EC4899",
    "split_2": "#3B82F6",
    "rule_2": "#F59E0B",
    "scorecard": "#8B5CF6",
    "decision_table": "#10B981",
    "matrix_table": "#6366F1",
    "ai_node_v2": "#6366F1",
    "ml_model": "#EAB308",
    "transform": "#84CC16",
    "flow": "#6B7280",
    "flow_loop": "#6B7280",
    "entity_action": "#14B8A6",
    "case_action": "#14B8A6",
    "manual_review": "#6B7280",
    "custom_connection_node": "#8B5CF6",
    "webhook_connection_node": "#8B5CF6",
    "data_integration": "#8B5CF6",
    "manifest_connection_node": "#8B5CF6",
}

# API node type → short CSS class alias (for Mermaid classDef names)
_NODE_CLASS: dict[str, str] = {
    "input": "io",
    "output": "io",
    "split_2": "split",
    "assignment_node": "assign",
    "rule_2": "rule",
    "decision_table": "dt",
    "scorecard": "score",
    "matrix_table": "matrix",
    "custom_connection_node": "connection",
    "webhook_connection_node": "connection",
    "data_integration": "connection",
    "manifest_connection_node": "connection",
    "ai_node_v2": "ai",
    "ai_agent": "agent",
    "flow_loop": "loop",
    "flow": "subflow",
    "transform": "transform",
    "ml_model": "ml",
    "entity_action": "entity",
    "case_action": "case",
    "manual_review": "manual",
}

# Derive Mermaid classDef styles from _TYPE_COLOR so colours stay in sync.
# Each CSS class gets "fill:white, stroke:<accent>, stroke-width:2px".
_CLASS_STYLES: dict[str, str] = {}
_seen: set[str] = set()
for _ntype, _cls in _NODE_CLASS.items():
    if _cls not in _seen:
        _color = _TYPE_COLOR.get(_ntype, "#6B7280")
        _CLASS_STYLES[_cls] = f"fill:#FFFFFF,stroke:{_color},stroke-width:2px,color:#1F2537"
        _seen.add(_cls)
# Special non-API classes
_CLASS_STYLES["branch"] = "fill:#FFFFFF,stroke:#E5E7EB,stroke-width:1px,color:#1F2537"
_CLASS_STYLES["merge"] = "fill:#9CA3AF,stroke:#9CA3AF,color:#9CA3AF"
_CLASS_STYLES["open"] = "fill:#FFFFFF,stroke:#6B7280,stroke-width:2px,color:#1F2537,stroke-dasharray:6 3"
# Diff status classes
_CLASS_STYLES["diff_added"] = "fill:#D1FAE5,stroke:#059669,stroke-width:2px,color:#1F2537"
_CLASS_STYLES["diff_removed"] = "fill:#FEE2E2,stroke:#EF4444,stroke-width:2px,color:#1F2537"
_CLASS_STYLES["diff_modified"] = "fill:#FEF3C7,stroke:#F59E0B,stroke-width:2px,color:#1F2537"
_CLASS_STYLES["diff_unchanged"] = "fill:#F9FAFB,stroke:#9CA3AF,stroke-width:1px,color:#6B7280"
del _seen, _ntype, _cls, _color

# API node type → UI display label (matches Taktile "Add a node" panel)
_TYPE_SHORT: dict[str, str] = {
    "input": "Input",
    "output": "Output",
    "assignment_node": "Assignment",
    "rule_2": "Rule",
    "decision_table": "Decision Table",
    "scorecard": "Scorecard",
    "matrix_table": "2D Matrix",
    "split_2": "Split",
    "transform": "Code",
    "custom_connection_node": "Connection",
    "webhook_connection_node": "Connection",
    "data_integration": "Connection",
    "manifest_connection_node": "Connection",
    "ai_node_v2": "AI",
    "ai_agent": "Agent",
    "flow_loop": "Loop",
    "flow": "Decision Flow",
    "ml_model": "Machine Learning",
    "entity_action": "Entity Actions",
    "case_action": "Case Actions",
    "manual_review": "Manual Review",
}

# Operator codes → human-readable symbols
_OP_DISPLAY: dict[str, str] = {
    "lt": "<",
    "le": "≤",
    "gt": ">",
    "ge": "≥",
    "eq": "=",
    "ne": "≠",
    "is_in": "in",
    "not_is_in": "not in",
    "is_none": "is null",
    "is_not_none": "not null",
    "contains": "contains",
    "does_not_contain": "not contains",
    "matches_regex": "~",
    "is_any": "any",
}


def _get_node_class(ntype: str, meta: dict[str, Any]) -> str:
    if meta.get("is_split_branch_node"):
        return "branch"
    if meta.get("is_split_merge_node"):
        return "merge"
    return _NODE_CLASS.get(ntype, "transform")


def _format_clause(clause: dict[str, Any]) -> str:
    left = clause.get("left", "").replace("data.", "").replace("params.", "")
    op = _OP_DISPLAY.get(clause.get("operator", ""), clause.get("operator", "?"))
    right = str(clause.get("right", "")).strip("\"'")
    if not left:
        return ""
    if clause.get("operator") in ("is_none", "is_not_none", "is_any"):
        return f"{left} {op}"
    return f"{left} {op} {right}"


def _build_split_edge_labels(nodes: dict[str, Any]) -> dict[str, str]:
    """Return mapping of split edge_id → human-readable condition string."""
    labels: dict[str, str] = {}
    for node in nodes.values():
        if node.get("type") != "split_2":
            continue
        meta = node.get("meta") or {}
        default_edge = meta.get("default_edge_id", "")
        for branch in meta.get("branches") or []:
            eid = branch.get("edge_id", "")
            if not eid:
                continue
            clauses = branch.get("clauses") or []
            if not clauses or eid == default_edge:
                labels[eid] = "default"
            else:
                parts = [_format_clause(c) for c in clauses if _format_clause(c)]
                labels[eid] = " & ".join(parts) if parts else "default"
    return labels


def _node_shape(alias: str, ntype: str, meta: dict[str, Any], name: str) -> str:
    """Build a Mermaid node declaration with type label and node name."""
    is_branch = bool(meta.get("is_split_branch_node"))
    is_merge = bool(meta.get("is_split_merge_node"))

    # Merge node → small filled circle
    if is_merge:
        return f"{alias}(( ))"

    # Branch node → compact rectangle with just the name
    if is_branch:
        return f'{alias}["{name}"]'

    type_short = _TYPE_SHORT.get(ntype, ntype)
    return f'{alias}["{type_short}\n<b>{name}</b>"]'


def graph_to_mermaid(graph: dict[str, Any]) -> str:
    """Convert a raw version graph dict to a Mermaid ``flowchart TD`` string.

    Features:
    - Uniform rectangular nodes with bold type label + name
    - Grey/indigo color scheme
    - Condition strings on split edges (extracted from split_2 clause data)
    """
    nodes: dict[str, Any] = graph.get("nodes") or {}
    edges: dict[str, Any] = graph.get("edges") or {}
    node_groups: dict[str, Any] = graph.get("node_groups") or {}

    # UUID → short alias (N0, N1, …)
    aliases: dict[str, str] = {nid: f"N{i}" for i, nid in enumerate(nodes)}

    # Build set of grouped node IDs for later
    grouped_nids: set[str] = set()
    for grp in node_groups.values():
        for nid in grp.get("node_ids", []):
            grouped_nids.add(nid)

    # Pre-compute split edge condition labels
    split_labels = _build_split_edge_labels(nodes)

    lines: list[str] = ["flowchart TD"]
    lines.append("")

    # classDef declarations
    for cls, style in _CLASS_STYLES.items():
        lines.append(f"    classDef {cls} {style}")
    lines.append("")

    # Node group subgraphs — contain their member nodes
    for gi, (gid, grp) in enumerate(node_groups.items()):
        grp_name = grp.get("name", f"Group {gi}")
        grp_alias = f"G{gi}"
        member_ids = grp.get("node_ids", [])
        lines.append(f'    subgraph {grp_alias} ["{grp_name}"]')
        for nid in member_ids:
            if nid in aliases:
                alias = aliases[nid]
                node = nodes[nid]
                ntype = node.get("type", "")
                name = node.get("name", "")
                meta_: dict[str, Any] = node.get("meta") or {}
                cls = _get_node_class(ntype, meta_)
                shape = _node_shape(alias, ntype, meta_, name)
                lines.append(f"        {shape}:::{cls}")
        lines.append("    end")
        lines.append(f"    style {grp_alias} fill:#F3F4F6,stroke:#D1D5DB,stroke-width:1px")
    if node_groups:
        lines.append("")

    # Ungrouped node declarations
    for nid, node in nodes.items():
        if nid in grouped_nids:
            continue  # already declared inside a subgraph
        alias = aliases[nid]
        ntype = node.get("type", "")
        name = node.get("name", "")
        meta: dict[str, Any] = node.get("meta") or {}
        cls = _get_node_class(ntype, meta)
        shape = _node_shape(alias, ntype, meta, name)
        lines.append(f"    {shape}:::{cls}")

    lines.append("")

    # Edge declarations
    for _eid, edge in edges.items():
        eid = edge.get("id", _eid)
        start = edge.get("start_node_id", "")
        end = edge.get("end_node_id", "")
        if start not in aliases or end not in aliases:
            continue

        a = aliases[start]
        b = aliases[end]
        is_split_edge = bool((edge.get("meta") or {}).get("is_split_edge"))
        start_type = nodes.get(start, {}).get("type", "")

        if is_split_edge and start_type == "split_2":
            # Use condition string from clause data; fall back to dest node name
            label = split_labels.get(eid) or split_labels.get(_eid)
            if not label:
                label = nodes.get(end, {}).get("name", "")
            if label:
                lines.append(f'    {a} -->|"{label}"| {b}')
                continue

        lines.append(f"    {a} --> {b}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _render_dot(dot: graphviz.Digraph, out_dir: Path) -> Path:
    """Render a Graphviz *dot* graph to PNG in *out_dir*.

    Handles directory creation, timestamp-based naming, and collision
    avoidance.  Returns the path to the saved PNG file.
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    stem = timestamp
    if (out_dir / f"{stem}.png").exists():
        i = 1
        while (out_dir / f"{stem}-{i}.png").exists():
            i += 1
        stem = f"{stem}-{i}"

    out_path = out_dir / stem
    try:
        dot.render(filename=str(out_path), cleanup=True)
    except graphviz.ExecutableNotFound as exc:
        raise RenderError("Graphviz 'dot' not found. Install it: brew install graphviz") from exc

    return Path(f"{out_path}.png")


# ---------------------------------------------------------------------------
# render_mermaid_png — render raw Mermaid code to PNG via Graphviz
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Mermaid flowchart → Graphviz converter
# ---------------------------------------------------------------------------

_CLASSDEF_RE = re.compile(r"classDef\s+(\w+)\s+(.*)")
_EDGE_SPLIT_RE = re.compile(r'\s*-->\s*(?:\|"?([^"|]*)"?\|\s*)?')
_CLASS_SUFFIX_RE = re.compile(r":::(\w+)\s*$")

# Node shape detectors — ordered from most-specific delimiter to least.
# Group 1 (when present) captures the label text.
_SHAPE_DETECTORS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"\(\(\s*\)\)$"), "point"),  # (( ))
    (re.compile(r'\(\("(.*)"\)\)$', re.S), "doublecircle"),  # (("..."))
    (re.compile(r'\(\["(.*)"\]\)$', re.S), "stadium"),  # (["..."])
    (re.compile(r'\[\["(.*)"\]\]$', re.S), "box3d"),  # [["..."]]
    (re.compile(r'\("(.*)"\)$', re.S), "ellipse"),  # ("...")
    (re.compile(r'\["(.*)"\]$', re.S), "rect"),  # ["..."]
    (re.compile(r'\{"(.*)"\}$', re.S), "diamond"),  # {"..."}
    (re.compile(r'>"(.*)"\]$', re.S), "asymmetric"),  # >"..."]
]


def _parse_classdef_props(line: str) -> tuple[str, dict[str, str]] | None:
    """Parse ``classDef name fill:#FFF,stroke:#000,...`` → ``(name, {prop: val})``."""
    m = _CLASSDEF_RE.match(line.strip())
    if not m:
        return None
    name = m.group(1)
    props: dict[str, str] = {}
    for item in m.group(2).split(","):
        if ":" in item:
            k, v = item.split(":", 1)
            props[k.strip()] = v.strip()
    return name, props


def _parse_node_decl(seg: str) -> tuple[str, str, str, str]:
    """Parse ``A["label"]:::cls`` → ``(node_id, label, gv_shape, css_class)``."""
    seg = seg.strip()
    if not seg:
        return ("", "", "rect", "")

    # Strip :::class suffix
    css_class = ""
    m = _CLASS_SUFFIX_RE.search(seg)
    if m:
        css_class = m.group(1)
        seg = seg[: m.start()].strip()

    # Node ID is the leading word characters
    m = re.match(r"(\w+)(.*)", seg, re.DOTALL)
    if not m:
        return (seg, seg, "rect", css_class)
    nid = m.group(1)
    rest = m.group(2).strip()

    if not rest:
        return (nid, nid, "rect", css_class)

    for pattern, shape in _SHAPE_DETECTORS:
        m2 = pattern.match(rest)
        if m2:
            label = m2.group(1) if m2.lastindex else ""
            return (nid, label, shape, css_class)

    return (nid, rest, "rect", css_class)


def _gv_node_attrs(
    nid: str,
    label: str,
    shape: str,
    css_class: str,
    class_defs: dict[str, dict[str, str]],
) -> dict[str, str]:
    """Build Graphviz node attributes from parsed Mermaid node data."""
    if shape == "point":
        return {
            "label": "",
            "shape": "circle",
            "width": "0.25",
            "height": "0.25",
            "fixedsize": "true",
            "style": "filled",
            "fillcolor": "#D1D5DB",
            "color": "#D1D5DB",
            "penwidth": "0",
        }

    attrs: dict[str, str] = {"style": "rounded,filled", "fillcolor": "white"}

    if shape == "diamond":
        attrs["shape"] = "diamond"
    elif shape == "doublecircle":
        attrs["shape"] = "doublecircle"
    elif shape == "box3d":
        attrs["shape"] = "rect"
        attrs["peripheries"] = "2"
    else:
        attrs["shape"] = "rect"

    # Graphviz HTML-like label when the text contains markup.
    # Escape HTML entities in text portions so & etc. don't break the XML parser,
    # but preserve existing HTML tags (<b>, <br/>, etc.).
    if "<" in label and ">" in label:
        escaped = re.sub(
            r"([^<>]+)",
            lambda m: html.escape(m.group(1), quote=False),
            label,
        )
        attrs["label"] = f"<{escaped}>"
    elif label:
        attrs["label"] = label
    else:
        attrs["label"] = nid

    # Apply classDef colours
    if css_class and css_class in class_defs:
        props = class_defs[css_class]
        if "fill" in props:
            attrs["fillcolor"] = props["fill"]
        if "stroke" in props:
            attrs["color"] = props["stroke"]
        if "color" in props:
            attrs["fontcolor"] = props["color"]

    return attrs


def _mermaid_to_graphviz(code: str) -> graphviz.Digraph:
    """Convert Mermaid ``flowchart`` code to a :class:`graphviz.Digraph`."""
    lines = code.strip().split("\n")

    direction = "TB"
    class_defs: dict[str, dict[str, str]] = {}
    nodes: dict[str, tuple[str, str, str]] = {}  # id → (label, shape, class)
    edge_list: list[tuple[str, str, str]] = []  # (src, dst, edge_label)
    in_subgraph = 0

    for raw_line in lines:
        line = raw_line.strip()
        if not line or line.startswith("%%"):
            continue

        # Skip subgraph contents (e.g. Legend)
        if line.startswith("subgraph"):
            in_subgraph += 1
            continue
        if line == "end" and in_subgraph > 0:
            in_subgraph -= 1
            continue
        if in_subgraph > 0:
            continue

        if line.startswith("flowchart"):
            parts = line.split()
            if len(parts) > 1:
                direction = parts[1]
            continue

        if line.startswith("classDef"):
            result = _parse_classdef_props(line)
            if result:
                class_defs[result[0]] = result[1]
            continue

        if line.startswith("direction") or line.startswith("class "):
            continue

        # Split on --> (with optional |label|) to find node segments + edge labels
        segments = _EDGE_SPLIT_RE.split(line)
        node_ids: list[str] = []
        labels: list[str] = []

        for i, part in enumerate(segments):
            if i % 2 == 0:
                part = (part or "").strip()
                if not part:
                    continue
                nid, label, gv_shape, css_class = _parse_node_decl(part)
                if nid:
                    if nid not in nodes:
                        nodes[nid] = (label, gv_shape, css_class)
                    node_ids.append(nid)
            else:
                labels.append(part or "")

        for j in range(len(node_ids) - 1):
            elabel = labels[j] if j < len(labels) else ""
            edge_list.append((node_ids[j], node_ids[j + 1], elabel))

    # --- Build Graphviz Digraph ---
    rankdir = {"TD": "TB", "TB": "TB", "LR": "LR", "RL": "RL", "BT": "BT"}.get(direction, "TB")

    dot = graphviz.Digraph(format="png")
    dot.attr(
        rankdir=rankdir,
        bgcolor="#FAFAFA",
        pad="0.4",
        nodesep="0.4",
        ranksep="0.5",
        dpi="250",
        splines="curved",
    )
    dot.attr(
        "node",
        shape="rect",
        style="rounded,filled",
        fillcolor="white",
        fontname=_FONT,
        fontsize="11",
        fontcolor="#1F2937",
        margin="0.1,0.06",
        penwidth="2",
    )
    dot.attr(
        "edge",
        color="#D1D5DB",
        fontname=_FONT,
        fontsize="9",
        fontcolor="#6B7280",
        arrowsize="0.7",
        arrowhead="vee",
        penwidth="1.5",
    )

    for nid, (label, gv_shape, css_class) in nodes.items():
        attrs = _gv_node_attrs(nid, label, gv_shape, css_class, class_defs)
        dot.node(nid, **attrs)

    for src, dst, elabel in edge_list:
        if elabel:
            dot.edge(src, dst, label=elabel)
        else:
            dot.edge(src, dst)

    return dot


def render_mermaid_png(code: str, out_dir: Path) -> Path:
    """Render raw Mermaid flowchart *code* as a PNG via local Graphviz.

    Parses ``flowchart TD`` syntax (nodes, edges, classDefs) and converts it
    to a Graphviz Digraph rendered with the ``dot`` engine.  Returns the path
    of the saved PNG file.  Raises :class:`RenderError` if Graphviz is not
    installed.
    """
    code = _normalize_newlines(code)
    dot = _mermaid_to_graphviz(code)
    return _render_dot(dot, out_dir)


# ---------------------------------------------------------------------------
# render_graph_png — Graphviz-based PNG renderer (flow graphs)
# ---------------------------------------------------------------------------


_FONT = "Helvetica Neue"


def _add_graphviz_node(target: graphviz.Digraph, nid: str, node: dict[str, Any]) -> None:
    """Add a single node to a Graphviz graph or subgraph."""
    ntype = node.get("type", "")
    name = node.get("name", "")
    meta: dict[str, Any] = node.get("meta") or {}
    is_merge = bool(meta.get("is_split_merge_node"))
    is_branch = bool(meta.get("is_split_branch_node"))
    color = _TYPE_COLOR.get(ntype, "#6B7280")
    if ntype in ("input", "output"):
        name = _TYPE_SHORT.get(ntype, name)

    if is_merge:
        target.node(
            nid,
            label="",
            shape="circle",
            width="0.25",
            height="0.25",
            fixedsize="true",
            style="filled",
            fillcolor="#D1D5DB",
            color="#D1D5DB",
            penwidth="0",
        )
    elif is_branch:
        target.node(
            nid,
            label=name,
            fontsize="10",
            color="#E5E7EB",
            fillcolor="#F9FAFB",
            penwidth="1.5",
        )
    else:
        type_short = html.escape(_TYPE_SHORT.get(ntype, ntype))
        safe_name = html.escape(name)
        label = (
            f"<<table border='0' cellspacing='0' cellpadding='1'>"
            f"<tr><td align='left'><font point-size='8' color='#9CA3AF'"
            f" face='{_FONT}'>{type_short}</font></td></tr>"
            f"<tr><td align='left'><font point-size='11' color='#111827'"
            f" face='{_FONT}'><b>{safe_name}</b></font></td></tr></table>>"
        )
        target.node(nid, label=label, color=color)


def render_graph_png(graph: dict[str, Any], out_dir: Path) -> Path:
    """Render a version *graph* dict as a PNG via Graphviz (``dot``).

    Returns the path of the saved PNG file.
    Raises :class:`RenderError` on failure.
    """
    nodes: dict[str, Any] = graph.get("nodes") or {}
    edges: dict[str, Any] = graph.get("edges") or {}
    node_groups: dict[str, Any] = graph.get("node_groups") or {}

    # Track which nodes are in groups
    grouped_nids: set[str] = set()
    for grp in node_groups.values():
        for nid in grp.get("node_ids", []):
            grouped_nids.add(nid)

    split_labels = _build_split_edge_labels(nodes)

    dot = graphviz.Digraph(format="png")
    dot.attr(
        rankdir="TB",
        bgcolor="#FAFAFA",
        pad="0.4",
        nodesep="0.4",
        ranksep="0.5",
        dpi="250",
        splines="curved",
    )
    dot.attr(
        "node",
        shape="rect",
        style="rounded,filled",
        fillcolor="white",
        fontname=_FONT,
        fontsize="11",
        fontcolor="#1F2937",
        margin="0.1,0.06",
        penwidth="2",
    )
    dot.attr(
        "edge",
        color="#D1D5DB",
        fontname=_FONT,
        fontsize="9",
        fontcolor="#6B7280",
        arrowsize="0.7",
        arrowhead="vee",
        penwidth="1.5",
    )

    # Render grouped nodes inside Graphviz cluster subgraphs
    for gid, grp in node_groups.items():
        grp_name = grp.get("name", "")
        member_ids = [nid for nid in grp.get("node_ids", []) if nid in nodes]
        if not member_ids:
            continue
        with dot.subgraph(name=f"cluster_{gid}") as sub:
            sub.attr(
                label=grp_name,
                style="rounded,dashed",
                color="#D1D5DB",
                bgcolor="#F9FAFB",
                fontname=_FONT,
                fontsize="10",
                fontcolor="#6B7280",
                penwidth="1.5",
            )
            for nid in member_ids:
                _add_graphviz_node(sub, nid, nodes[nid])

    # Render ungrouped nodes at top level
    for nid, node in nodes.items():
        if nid in grouped_nids:
            continue
        _add_graphviz_node(dot, nid, node)

    for _eid, edge in edges.items():
        eid = edge.get("id", _eid)
        start = edge.get("start_node_id", "")
        end = edge.get("end_node_id", "")
        if start not in nodes or end not in nodes:
            continue

        is_split_edge = bool((edge.get("meta") or {}).get("is_split_edge"))
        start_type = nodes.get(start, {}).get("type", "")

        label = ""
        if is_split_edge and start_type == "split_2":
            label = split_labels.get(eid) or split_labels.get(_eid) or ""
            if not label:
                label = nodes.get(end, {}).get("name", "")

        dot.edge(start, end, label=label)

    return _render_dot(dot, out_dir)


# ---------------------------------------------------------------------------
# build_flow_url — construct Taktile app navigation URLs
# ---------------------------------------------------------------------------


def build_flow_url(
    app_url: str,
    org_id: str,
    workspace_id: str,
    flow_id: str,
    version_id: str,
    *,
    node_id: str | None = None,
    right_pane_tab: str | None = None,
    left_pane: str | None = None,
    schema: str | None = None,
    decision_id: str | None = None,
    power_tools: bool = False,
) -> str:
    """Return a fully-qualified Taktile flow builder URL.

    Base path: ``{app_url}/decide/org/{org_id}/ws/{workspace_id}/flow/{flow_id}/version/{version_id}``

    Always uses ``/flow/`` (singular) and always includes ``/version/{version_id}``.

    Optional query params:
    - ``node`` + ``right-pane-tab`` — focus a specific node's logic / settings panel
    - ``left-pane="schema"`` + ``schema="input"|"output"`` — open input or output schema pane
    - ``left-pane="datasets"`` — dataset browser
    - ``left-pane="decision-history"`` + ``decision-id`` — open a specific run
    - ``power-tools=true`` — enable power tools mode
    """
    base = f"{app_url}/decide/org/{org_id}/ws/{workspace_id}/flow/{flow_id}/version/{version_id}"
    params: list[str] = []
    if power_tools:
        params.append("power-tools=true")
    if left_pane:
        params.append(f"left-pane={left_pane}")
    if schema:
        params.append(f"schema={schema}")
    if decision_id:
        params.append(f"decision-id={decision_id}")
    if node_id:
        params.append(f"node={node_id}")
    if right_pane_tab:
        params.append(f"right-pane-tab={right_pane_tab}")
    return f"{base}?{'&'.join(params)}" if params else base


# ---------------------------------------------------------------------------
# diff_to_mermaid
# ---------------------------------------------------------------------------


def diff_to_mermaid(graph_a: dict[str, Any], graph_b: dict[str, Any], diff: "Any") -> str:
    """Generate a Mermaid diagram showing node changes between two versions.

    Parameters
    ----------
    graph_a:
        Raw graph dict for version A.
    graph_b:
        Raw graph dict for version B.
    diff:
        A VersionDiff dataclass instance with added/removed/modified/unchanged lists.
    """
    # Build lookup of status per node_id
    status_map: dict[str, str] = {}
    for n in diff.added:
        status_map[n.node_id] = "diff_added"
    for n in diff.removed:
        status_map[n.node_id] = "diff_removed"
    for n in diff.modified:
        status_map[n.node_id] = "diff_modified"
    for n in diff.unchanged:
        status_map[n.node_id] = "diff_unchanged"

    nodes_a: dict[str, Any] = graph_a.get("nodes") or {}
    nodes_b: dict[str, Any] = graph_b.get("nodes") or {}

    # Union of all nodes; prefer B's version for added/modified/unchanged
    all_nodes: dict[str, Any] = {}
    for nid, node in nodes_a.items():
        all_nodes[nid] = node
    for nid, node in nodes_b.items():
        all_nodes[nid] = node

    aliases: dict[str, str] = {nid: f"N{i}" for i, nid in enumerate(all_nodes)}

    lines: list[str] = ["flowchart TD", ""]

    # classDef declarations
    for cls, style in _CLASS_STYLES.items():
        lines.append(f"    classDef {cls} {style}")
    lines.append("")

    # Node declarations
    for nid, node in all_nodes.items():
        alias = aliases[nid]
        ntype = node.get("type", "")
        name = node.get("name", "")
        meta: dict[str, Any] = node.get("meta") or {}
        diff_cls = status_map.get(nid, "diff_unchanged")
        shape = _node_shape(alias, ntype, meta, name)
        lines.append(f"    {shape}:::{diff_cls}")

    lines.append("")

    # Use graph_b edges (prefer newer version's structure)
    edges_b: dict[str, Any] = graph_b.get("edges") or {}
    for _eid, edge in edges_b.items():
        start = edge.get("start_node_id", "")
        end = edge.get("end_node_id", "")
        if start not in aliases or end not in aliases:
            continue
        lines.append(f"    {aliases[start]} --> {aliases[end]}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# preview_version_graph
# ---------------------------------------------------------------------------


def preview_version_graph(
    client: Any,
    cache_index: Any,
    cache_manager: Any,
    workspace_id: str,
    slug: str,
    version_name: str,
) -> Path:
    """Generate a PNG preview of a live version graph via Graphviz.

    Reads from cache if available (populated by a prior ``describe_version``
    call), otherwise fetches from the API.  Returns the path to the PNG.
    """
    flow_id, version_id = _resolve_ids(client, cache_index, workspace_id, slug, version_name)
    assert version_id is not None

    raw = cache_manager.read_full_version(version_id, flow_id)
    if raw is None:
        raw = _fetch_and_cache_version(client, cache_manager, flow_id, version_id)

    graph: dict[str, Any] = raw.get("graph") or {}
    out_dir = Path(tempfile.gettempdir()) / "tktl"
    return render_graph_png(graph, out_dir)
