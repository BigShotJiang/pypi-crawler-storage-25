"""Operations layer — graph building: add and remove nodes."""

from __future__ import annotations

import re
import uuid
from copy import deepcopy
from pathlib import Path
from typing import Any

from tktl.api.client import TktlClient
from tktl.api.versions import get_version, normalize_graph_response, patch_version
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.models.errors import NotFoundError, UsageError
from tktl.models.node import NodeDetail, NodeSummary
from tktl.ops.versions import _resolve_ids, resolve_child_flow

# Node types where meta must NOT include created_by_id/updated_by_id
_NO_CREATOR_TYPES = {"split_2", "decision_table", "scorecard", "matrix_table", "flow", "flow_loop"}

# Operator mapping for --clause parsing
_OP_MAP = {
    "<": "lt",
    "<=": "le",
    ">": "gt",
    ">=": "ge",
    "==": "eq",
    "!=": "ne",
}
_CLAUSE_RE = re.compile(r"^(\S+)\s*(==|!=|<=|>=|<|>)\s*(.+)$")
# Python literals that must NOT be auto-quoted — they evaluate to their native types
_UNQUOTED_LITERALS = {"True", "False", "None"}


def _uid() -> str:
    return str(uuid.uuid4())


def _parse_clause(clause: str) -> dict[str, str]:
    """Parse ``"data.field < 30"`` into a split clause dict.

    String values are auto-quoted for the API: ``data.x == APPROVED`` becomes
    ``right: '"APPROVED"'``.  Numeric values and Python literals (``True``,
    ``False``, ``None``) are left as-is so the execution engine evaluates them
    as their native types.
    """
    m = _CLAUSE_RE.match(clause.strip())
    if not m:
        raise UsageError(f"Invalid clause syntax: '{clause}'. Expected: 'data.field <operator> value'")
    left, op, right = m.group(1), m.group(2), m.group(3).strip()
    # Auto-quote string values, but leave numeric literals and Python keywords unquoted
    if (
        not right.startswith('"')
        and right not in _UNQUOTED_LITERALS
        and not right.replace(".", "").replace("-", "").isdigit()
    ):
        right = f'"{right}"'
    return {"id_left": "", "id_right": "", "left": left, "right": right, "operator": _OP_MAP[op]}


def _read_src(src: str) -> str:
    """Read transform source: @file or inline code."""
    if src.startswith("@"):
        path = Path(src[1:])
        if not path.exists():
            raise UsageError(f"Source file not found: {path}")
        return path.read_text()
    return src


def add_node(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
    workspace_id: str,
    slug: str,
    version_name: str,
    *,
    node_type: str,
    name: str,
    after_node_id: str,
    src: str | None = None,
    clause: str | None = None,
    config: dict[str, Any] | None = None,
    child_flow_slug: str | None = None,
    target_list: str | None = None,
    output_list: str | None = None,
    group_id: str | None = None,
) -> NodeDetail:
    """Add a node to a version's graph, wired after ``after_node_id``.

    For ``split`` type, also creates branch transforms and merge node.
    For ``flow`` / ``flow_loop`` types, resolves child flow references.
    Returns the new node as ``NodeDetail``.
    """
    flow_id, version_id = _resolve_ids(client, cache_index, workspace_id, slug, version_name)
    if flow_id is None or version_id is None:
        raise NotFoundError(f"Could not resolve flow '{slug}' or version '{version_name}'")
    raw = get_version(client, version_id)
    if raw is None:
        raise NotFoundError(f"Version '{version_name}' not found")

    etag = raw["etag"]
    nodes = raw["graph"]["nodes"]
    edges = raw["graph"]["edges"]
    user_id = client._user_id or "cli-user"

    # Validate --after exists
    if after_node_id not in nodes:
        raise NotFoundError(f"Node '{after_node_id}' not found in version '{version_name}'")

    # Find the outgoing edge from after_node_id
    out_edge_id = None
    next_node_id = None
    for eid, e in edges.items():
        if e["start_node_id"] == after_node_id:
            out_edge_id = eid
            next_node_id = e["end_node_id"]
            break

    if out_edge_id is None or next_node_id is None:
        raise UsageError(f"Node '{after_node_id}' has no outgoing edge to insert after")

    # Normalize type alias
    actual_type = _normalize_type(node_type)

    # Build the node and edges
    if actual_type == "split_2":
        patch_nodes, patch_edges = _build_split(
            name,
            after_node_id,
            next_node_id,
            out_edge_id,
            clause,
        )
        new_node_id = next(nid for nid, n in patch_nodes.items() if n.get("type") == "split_2")
    elif actual_type in ("flow", "flow_loop"):
        new_node_id, patch_nodes, patch_edges = _build_flow_node(
            actual_type,
            name,
            after_node_id,
            next_node_id,
            out_edge_id,
            child_flow_slug,
            config,
            target_list,
            output_list,
        )
        # Resolve child flow IDs before patching
        if child_flow_slug:
            resolved = resolve_child_flow(client, workspace_id, child_flow_slug)
            meta = patch_nodes[new_node_id]["meta"]
            meta["child_flow_id"] = resolved["flow_id"]
            meta["child_flow_version_id"] = resolved["version_id"]
            meta["child_flow_version_known_etag"] = resolved["etag"]
            meta["is_stale"] = False
    else:
        new_node_id, patch_nodes, patch_edges = _build_simple_node(
            actual_type,
            name,
            after_node_id,
            next_node_id,
            out_edge_id,
            user_id,
            src,
            config,
        )

    # Build graph patch
    graph_patch: dict[str, Any] = {"nodes": patch_nodes, "edges": patch_edges}

    # Optionally add the new node to an existing group
    if group_id is not None:
        node_groups = raw["graph"].get("node_groups", {})
        if group_id not in node_groups:
            raise NotFoundError(f"Group '{group_id}' not found in version '{version_name}'")
        existing_group = dict(node_groups[group_id])
        current_ids = existing_group.get("node_ids", [])
        if new_node_id not in current_ids:
            existing_group["node_ids"] = [*current_ids, new_node_id]
        graph_patch["node_groups"] = {group_id: existing_group}

    # PATCH — response contains the full updated version; no follow-up GETs needed.
    session = _uid()
    patched = patch_version(
        client,
        version_id,
        {"graph": graph_patch},
        if_match=etag,
        session=session,
    )

    # Update cache directly from the PATCH response
    patched = normalize_graph_response(patched)
    cache_manager.write_version(version_id, flow_id, patched)

    new_node = patched["graph"]["nodes"].get(new_node_id, {})
    return NodeDetail(
        id=new_node_id,
        name=new_node.get("name", name),
        type=new_node.get("type", actual_type),
        meta=new_node.get("meta", {}),
    )


def remove_node(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
    workspace_id: str,
    slug: str,
    version_name: str,
    node_id: str,
) -> list[NodeSummary]:
    """Remove a node from the graph and rewire edges.

    For split nodes, also removes branch transforms and merge node.
    Returns the updated node list.
    """
    flow_id, version_id = _resolve_ids(client, cache_index, workspace_id, slug, version_name)
    if flow_id is None or version_id is None:
        raise NotFoundError(f"Could not resolve flow '{slug}' or version '{version_name}'")
    raw = get_version(client, version_id)
    if raw is None:
        raise NotFoundError(f"Version '{version_name}' not found")

    etag = raw["etag"]
    nodes = raw["graph"]["nodes"]
    edges = raw["graph"]["edges"]

    if node_id not in nodes:
        raise NotFoundError(f"Node '{node_id}' not found in version '{version_name}'")

    target = nodes[node_id]
    is_split = target.get("type") == "split_2"

    # Collect nodes to remove
    remove_ids = {node_id}
    if is_split:
        # Also remove branch nodes and merge node
        for nid, n in nodes.items():
            meta = n.get("meta", {})
            if meta.get("is_split_branch_node") or meta.get("is_split_merge_node"):
                # Check if connected to this split
                for eid, e in edges.items():
                    if e["start_node_id"] == node_id and e["end_node_id"] == nid:
                        remove_ids.add(nid)
                    if e["start_node_id"] == nid:
                        # Check if this branch/merge connects back
                        for eid2, e2 in edges.items():
                            if e2["start_node_id"] == nid:
                                dest = e2["end_node_id"]
                                dest_meta = nodes.get(dest, {}).get("meta", {})
                                if dest_meta.get("is_split_merge_node"):
                                    remove_ids.add(dest)

    # Find prev and next nodes (outside the removal set)
    prev_node_id = None
    next_node_id = None
    for eid, e in edges.items():
        if e["end_node_id"] in remove_ids and e["start_node_id"] not in remove_ids:
            prev_node_id = e["start_node_id"]
        if e["start_node_id"] in remove_ids and e["end_node_id"] not in remove_ids:
            next_node_id = e["end_node_id"]

    # Build patch: null removed nodes, null all their edges, create new bridge edge
    patch_nodes: dict[str, Any] = {}
    for nid in nodes:
        if nid in remove_ids:
            patch_nodes[nid] = None
        else:
            patch_nodes[nid] = deepcopy(nodes[nid])

    patch_edges: dict[str, Any] = {}
    for eid, e in edges.items():
        if e["start_node_id"] in remove_ids or e["end_node_id"] in remove_ids:
            patch_edges[eid] = None
        # Keep edges not touching removed nodes as-is (don't include them — merge patch)

    # Bridge edge
    if prev_node_id and next_node_id:
        patch_edges[_uid()] = {
            "start_node_id": prev_node_id,
            "end_node_id": next_node_id,
            "meta": {"is_split_edge": False},
        }

    session = _uid()
    patched = patch_version(
        client,
        version_id,
        {
            "graph": {"nodes": patch_nodes, "edges": patch_edges},
        },
        if_match=etag,
        session=session,
    )

    # Update cache directly from the PATCH response; filter nulls for the return value
    patched = normalize_graph_response(patched)
    cache_manager.write_version(version_id, flow_id, patched)
    return [
        NodeSummary(id=nid, name=n.get("name", ""), type=n.get("type", ""))
        for nid, n in patched["graph"]["nodes"].items()
        if n is not None
    ]


# ---------------------------------------------------------------------------
# Internal builders
# ---------------------------------------------------------------------------


def _normalize_type(t: str) -> str:
    """Map user-friendly type names to API type strings."""
    aliases = {
        "split": "split_2",
        "rule": "rule_2",
        "assignment": "assignment_node",
        "table": "decision_table",
        "matrix": "matrix_table",
        "custom_connection": "custom_connection_node",
        "manual_review": "review_connection_node",
        "subflow": "flow",
        "loop": "flow_loop",
    }
    return aliases.get(t, t)


def _build_flow_node(
    node_type: str,
    name: str,
    after_id: str,
    next_id: str,
    old_edge_id: str,
    child_flow_slug: str | None,
    config: dict[str, Any] | None,
    target_list: str | None,
    output_list: str | None,
) -> tuple[str, dict[str, Any], dict[str, Any]]:
    """Build a flow or flow_loop node with default meta structure."""
    new_id = _uid()

    if config is not None:
        meta: dict[str, Any] = dict(config)
    else:
        if not child_flow_slug:
            raise UsageError("--child-flow is required for subflow/loop nodes")
        meta = {
            "child_flow_slug": child_flow_slug,
            "child_flow_id": None,
            "child_flow_version_id": None,
            "child_flow_version_known_etag": None,
            "is_stale": False,
            "input_mappings": {},
        }
        if node_type == "flow":
            meta["output_mappings"] = {}
        elif node_type == "flow_loop":
            meta["target_list_expression"] = {"id": _uid(), "value": target_list or ""}
            meta["output_destination_list_expression"] = {"id": _uid(), "value": output_list or ""}
            meta["break_condition"] = {
                "id": _uid(),
                "junction": "and",
                "clauses": [],
                "enabled": False,
            }

    # Ensure child_flow_slug is set even when using --config
    if child_flow_slug and "child_flow_slug" not in meta:
        meta["child_flow_slug"] = child_flow_slug

    patch_nodes = {
        new_id: {"name": name, "type": node_type, "meta": meta},
    }
    patch_edges = {
        old_edge_id: None,
        _uid(): {"start_node_id": after_id, "end_node_id": new_id, "meta": {"is_split_edge": False}},
        _uid(): {"start_node_id": new_id, "end_node_id": next_id, "meta": {"is_split_edge": False}},
    }
    return new_id, patch_nodes, patch_edges


def _build_simple_node(
    node_type: str,
    name: str,
    after_id: str,
    next_id: str,
    old_edge_id: str,
    user_id: str,
    src: str | None,
    config: dict[str, Any] | None,
) -> tuple[str, dict[str, Any], dict[str, Any]]:
    """Build a simple linear node (non-split)."""
    new_id = _uid()

    meta: dict[str, Any]
    if config is not None:
        meta = dict(config)
    elif node_type == "transform":
        if src is None:
            raise UsageError("--src or --config is required for transform nodes")
        meta = {"src": _read_src(src)}
    elif node_type == "rule_2":
        meta = {"default_effects": [], "branches": []}
    elif node_type == "assignment_node":
        meta = {"default_effects": []}
    else:
        raise UsageError(f"--config is required for {node_type} nodes")

    # Add creator fields for types that need them
    if node_type not in _NO_CREATOR_TYPES:
        if "created_by_id" not in meta:
            meta["created_by_id"] = user_id
        if "updated_by_id" not in meta:
            meta["updated_by_id"] = user_id

    patch_nodes = {
        new_id: {"name": name, "type": node_type, "meta": meta},
    }
    patch_edges = {
        old_edge_id: None,
        _uid(): {"start_node_id": after_id, "end_node_id": new_id, "meta": {"is_split_edge": False}},
        _uid(): {"start_node_id": new_id, "end_node_id": next_id, "meta": {"is_split_edge": False}},
    }
    return new_id, patch_nodes, patch_edges


def _build_split(
    name: str,
    after_id: str,
    next_id: str,
    old_edge_id: str,
    clause: str | None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Build a split_2 node with branch transforms and merge."""
    split_id = _uid()
    branch_a_id = _uid()
    branch_b_id = _uid()
    merge_id = _uid()
    e_split_a = _uid()
    e_split_b = _uid()

    # Build clause
    if clause:
        parsed = _parse_clause(clause)
        clauses = [parsed]
    else:
        clauses = [{"id_left": "", "id_right": "", "left": "", "right": "", "operator": "eq"}]

    patch_nodes = {
        split_id: {
            "name": name,
            "type": "split_2",
            "meta": {
                "branches": [
                    {"id": "", "junction": "and", "edge_id": e_split_a, "clauses": clauses},
                    {"id": "", "junction": "and", "edge_id": e_split_b, "clauses": []},
                ],
                "default_edge_id": e_split_b,
            },
        },
        branch_a_id: {
            "name": "Branch 1",
            "type": "transform",
            "meta": {"src": "", "is_split_branch_node": True},
        },
        branch_b_id: {
            "name": "Default Branch",
            "type": "transform",
            "meta": {"src": "", "is_split_branch_node": True},
        },
        merge_id: {
            "name": "Merge Node",
            "type": "transform",
            "meta": {"src": "", "is_split_merge_node": True},
        },
    }
    patch_edges = {
        old_edge_id: None,
        _uid(): {"start_node_id": after_id, "end_node_id": split_id, "meta": {"is_split_edge": False}},
        e_split_a: {"start_node_id": split_id, "end_node_id": branch_a_id, "meta": {"is_split_edge": True}},
        e_split_b: {"start_node_id": split_id, "end_node_id": branch_b_id, "meta": {"is_split_edge": True}},
        _uid(): {"start_node_id": branch_a_id, "end_node_id": merge_id, "meta": {"is_split_edge": False}},
        _uid(): {"start_node_id": branch_b_id, "end_node_id": merge_id, "meta": {"is_split_edge": False}},
        _uid(): {"start_node_id": merge_id, "end_node_id": next_id, "meta": {"is_split_edge": False}},
    }
    return patch_nodes, patch_edges
