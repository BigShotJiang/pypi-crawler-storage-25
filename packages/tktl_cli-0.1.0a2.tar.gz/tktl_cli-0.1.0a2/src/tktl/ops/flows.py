"""Operations layer — flow read and run operations."""

from __future__ import annotations

import time
from typing import Any

from tktl.api.client import TktlClient
from tktl.api.execution import run_flow as api_run_flow
from tktl.api.flows import create_flow as api_create_flow, get_flow_by_slug, list_flows as api_list_flows
from tktl.api.folders import update_flow_folder as api_update_flow_folder
from tktl.api.versions import patch_version as api_patch_version
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.models.flow import FlowDetail, FlowSummary
from tktl.telemetry import estimate_tokens, track


def create_flow(
    client: TktlClient,
    cache_index: CacheIndex,
    workspace_id: str,
    slug: str,
    name: str,
    *,
    folder_id: str | None = None,
    initial_version_name: str = "v1",
    schema_in: dict[str, Any] | None = None,
    schema_out: dict[str, Any] | None = None,
    cache_manager: CacheManager | None = None,
) -> FlowDetail:
    """Create a new flow and seed the cache index with its initial version.

    If ``schema_in`` or ``schema_out`` are provided they are applied in a
    single follow-up PATCH that reuses the ETag from the creation response —
    no extra GET round-trip is needed.
    """
    start = time.monotonic()
    raw = api_create_flow(
        client,
        workspace_id,
        slug,
        name,
        folder_id=folder_id,
        initial_version_name=initial_version_name,
    )
    flow_id = raw["id"]
    versions_map: dict[str, str] = {}
    for v in raw.get("versions", []):
        versions_map[v["name"]] = v["id"]
    cache_index.update_flow(slug, flow_id, versions_map)
    cache_index.workspace_id = workspace_id
    cache_index.save()

    # Apply schemas immediately using the creation-time ETag — no GET needed.
    if (schema_in is not None or schema_out is not None) and raw.get("versions"):
        v0 = raw["versions"][0]
        version_id = v0["id"]
        etag = v0.get("etag")
        body: dict[str, Any] = {}
        if schema_in is not None:
            body["input_schema"] = schema_in
        if schema_out is not None:
            body["output_schema"] = schema_out
        patched = api_patch_version(client, version_id, body, if_match=etag)
        if cache_manager is not None:
            cache_manager.write_version(version_id, flow_id, patched)

    result = FlowDetail.model_validate(raw)
    track(
        "operation",
        {
            "op": "create_flow",
            "success": True,
            "output_tokens": estimate_tokens(result),
            "duration_ms": int((time.monotonic() - start) * 1000),
            "flow_slug": slug,
        },
    )
    return result


def update_flow_folder(
    client: TktlClient,
    cache_index: CacheIndex,
    workspace_id: str,
    slug: str,
    folder_id: str,
) -> FlowDetail:
    """Move a flow into a folder and return the updated flow."""
    start = time.monotonic()
    raw = get_flow_by_slug(client, workspace_id, slug)
    flow_id = raw["id"]
    api_update_flow_folder(client, flow_id, folder_id)

    # Re-fetch to get the updated state
    raw = get_flow_by_slug(client, workspace_id, slug)
    versions_map: dict[str, str] = {v["name"]: v["id"] for v in raw.get("versions", [])}
    cache_index.update_flow(slug, flow_id, versions_map)
    cache_index.workspace_id = workspace_id
    cache_index.save()

    result = FlowDetail.model_validate(raw)
    track(
        "operation",
        {
            "op": "update_flow_folder",
            "success": True,
            "output_tokens": estimate_tokens(result),
            "duration_ms": int((time.monotonic() - start) * 1000),
            "flow_slug": slug,
        },
    )
    return result


def list_flows(
    client: TktlClient,
    cache_manager: CacheManager,
    workspace_id: str,
) -> list[FlowSummary]:
    """List all flows in a workspace. Returns typed FlowSummary models."""
    start = time.monotonic()
    raw = api_list_flows(client, workspace_id)
    result = [FlowSummary.model_validate(f) for f in raw]
    track(
        "operation",
        {
            "op": "list_flows",
            "success": True,
            "output_tokens": estimate_tokens(result),
            "duration_ms": int((time.monotonic() - start) * 1000),
        },
    )
    return result


def describe_flow(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
    workspace_id: str,
    slug: str,
) -> FlowDetail:
    """Describe a single flow by slug. Caches flow metadata and updates index."""
    start = time.monotonic()
    raw = get_flow_by_slug(client, workspace_id, slug)

    flow_id = raw["id"]

    # Update cache index with flow and version mappings
    versions_map: dict[str, str] = {}
    for v in raw.get("versions", []):
        versions_map[v["name"]] = v["id"]
    cache_index.update_flow(slug, flow_id, versions_map)
    cache_index.workspace_id = workspace_id
    cache_index.save()

    # Cache flow metadata
    cache_manager.write_flow_metadata(flow_id, raw)

    result = FlowDetail.model_validate(raw)
    track(
        "operation",
        {
            "op": "describe_flow",
            "success": True,
            "output_tokens": estimate_tokens(result),
            "duration_ms": int((time.monotonic() - start) * 1000),
            "flow_slug": slug,
        },
    )
    return result


def _coerce_booleans(data: dict[str, Any]) -> dict[str, Any]:
    """Convert boolean values to strings in input data.

    Taktile schemas use ``string|number|null`` for fields that look boolean,
    so JSON booleans (``true``/``false``) get rejected by input validation.
    This converts them to ``"true"``/``"false"`` to avoid that gotcha.
    """
    result: dict[str, Any] = {}
    for k, v in data.items():
        if isinstance(v, bool):
            result[k] = str(v).lower()
        elif isinstance(v, dict):
            result[k] = _coerce_booleans(v)
        else:
            result[k] = v
    return result


def run_flow(
    client: TktlClient,
    workspace_id: str,
    flow_slug: str,
    input_data: dict[str, Any],
    *,
    version: str | None = None,
    env: str = "sandbox",
    mock_data: dict[str, Any] | None = None,
    execution_mode: str = "sync",
    poll_timeout: float = 60.0,
) -> dict[str, Any]:
    """Run a flow via the workspace Decide API."""
    start = time.monotonic()
    input_data = _coerce_booleans(input_data)
    input_tokens = estimate_tokens(input_data)
    result = api_run_flow(
        client,
        workspace_id,
        flow_slug,
        input_data,
        version=version,
        env=env,
        mock_data=mock_data,
        execution_mode=execution_mode,
        poll_timeout=poll_timeout,
    )
    track(
        "flow_execution",
        {
            "op": "run_flow",
            "success": True,
            "input_tokens": input_tokens,
            "output_tokens": estimate_tokens(result),
            "duration_ms": int((time.monotonic() - start) * 1000),
            "flow_slug": flow_slug,
            "env": env,
            "decision_id": result.get("metadata", {}).get("decision_id") if isinstance(result, dict) else None,
        },
    )
    return result
