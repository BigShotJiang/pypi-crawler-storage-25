"""Operations layer — node read and write operations."""

from __future__ import annotations

import time
import uuid
from copy import deepcopy
from typing import Any

from tktl.api.client import TktlClient
from tktl.api.versions import (
    patch_version as api_patch_version,
)
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.merge import deep_merge
from tktl.models.errors import ConflictError, NotFoundError
from tktl.models.node import NodeDetail, NodeSummary
from tktl.ops.versions import _fetch_and_cache_version, _resolve_ids
from tktl.telemetry import estimate_tokens, track

_MAX_ETAG_RETRIES = 3


def _ensure_dict_nodes(graph: dict[str, Any]) -> dict[str, Any]:
    """Convert v1 (list) nodes/edges/node_groups to v2 (dict-keyed) format."""
    for key in ("nodes", "edges", "node_groups"):
        val = graph.get(key)
        if isinstance(val, list):
            graph[key] = {item["id"]: item for item in val}
    return graph


def list_nodes(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
    workspace_id: str,
    flow_slug: str,
    version_name: str,
) -> list[NodeSummary]:
    """List all nodes in a version. Returns typed NodeSummary models.

    Reads from cache if available, otherwise fetches and caches the version.
    """
    start = time.monotonic()
    flow_id, version_id = _resolve_ids(client, cache_index, workspace_id, flow_slug, version_name)
    assert version_id is not None

    # Try cache first
    node_index = cache_manager.read_node_index(version_id, flow_id)
    cache_hit = node_index is not None
    if node_index is None:
        # Fetch version and cache it (decomposes into per-node files)
        _fetch_and_cache_version(client, cache_manager, flow_id, version_id)
        node_index = cache_manager.read_node_index(version_id, flow_id)

    if node_index is None:
        result: list[NodeSummary] = []
    else:
        result = [NodeSummary.model_validate(n) for n in node_index]

    # Annotate nodes with group membership
    full_version = cache_manager.read_full_version(version_id, flow_id)
    if full_version is not None and result:
        graph = full_version.get("graph", {})
        _ensure_dict_nodes(graph)
        node_groups = graph.get("node_groups", {})
        # Build reverse lookup: node_id → (group_id, group_name)
        nid_to_group: dict[str, tuple[str, str]] = {}
        for gid, grp in node_groups.items():
            gname = grp.get("name", "")
            for nid in grp.get("node_ids", []):
                nid_to_group[nid] = (gid, gname)
        for node in result:
            if node.id in nid_to_group:
                node.group_id, node.group_name = nid_to_group[node.id]

    track(
        "operation",
        {
            "op": "list_nodes",
            "success": True,
            "output_tokens": estimate_tokens(result),
            "duration_ms": int((time.monotonic() - start) * 1000),
            "flow_slug": flow_slug,
            "flow_version_name": version_name,
            "cache_hit": cache_hit,
        },
    )
    return result


def get_node(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
    workspace_id: str,
    flow_slug: str,
    version_name: str,
    node_id: str,
    section: str | None = None,
) -> NodeDetail:
    """Get a single node by ID. Reads from cache if available.

    If section is specified, only that field is populated in the result.
    """
    start = time.monotonic()
    flow_id, version_id = _resolve_ids(client, cache_index, workspace_id, flow_slug, version_name)
    assert version_id is not None

    # Try cache first
    node_data = cache_manager.read_node(version_id, flow_id, node_id)
    cache_hit = node_data is not None
    if node_data is None:
        # Fetch version and cache it
        _fetch_and_cache_version(client, cache_manager, flow_id, version_id)
        node_data = cache_manager.read_node(version_id, flow_id, node_id)

    if node_data is None:
        track(
            "operation",
            {
                "op": "get_node",
                "success": False,
                "error_type": "NotFoundError",
                "output_tokens": 0,
                "duration_ms": int((time.monotonic() - start) * 1000),
                "flow_slug": flow_slug,
                "flow_version_name": version_name,
            },
        )
        raise NotFoundError(f"Node not found: {node_id}")

    # Strip internal cache fields
    clean = {k: v for k, v in node_data.items() if not k.startswith("_")}

    node = NodeDetail.model_validate(clean)

    if section is not None:
        # Return a filtered node with only the requested section
        if section == "meta":
            node = NodeDetail(id=node.id, name=node.name, type=node.type, meta=node.meta)
        elif section == "name":
            node = NodeDetail(id=node.id, name=node.name, type=node.type)
        elif section == "type":
            node = NodeDetail(id=node.id, name=node.name, type=node.type)

    track(
        "operation",
        {
            "op": "get_node",
            "success": True,
            "output_tokens": estimate_tokens(node),
            "duration_ms": int((time.monotonic() - start) * 1000),
            "flow_slug": flow_slug,
            "flow_version_name": version_name,
            "cache_hit": cache_hit,
        },
    )
    return node


def update_node(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
    workspace_id: str,
    flow_slug: str,
    version_name: str,
    node_id: str,
    meta: dict[str, Any],
    session: str | None = None,
    force: bool = False,
) -> NodeDetail:
    """Update a node's meta via PATCH.

    The real Flow API requires ALL nodes in the graph patch body (not just the
    target). Sending only one node causes a 409 "graph not fully connected".

    Steps:
    1. Resolve IDs, fetch current version (v2 format, dict-keyed nodes)
    2. Check for lock conflicts
    3. Deep-merge the user's meta patch into the target node
    4. Build a PATCH body with the FULL nodes dict (only target node modified)
    5. PATCH with if-match etag
    6. Update cache
    7. Retry on 412 (etag mismatch) up to 3 times
    """
    start = time.monotonic()
    flow_id, version_id = _resolve_ids(client, cache_index, workspace_id, flow_slug, version_name)
    assert version_id is not None

    if session is None:
        session = str(uuid.uuid4())

    for attempt in range(_MAX_ETAG_RETRIES):
        # Fetch current version (v2 format with dict-keyed nodes)
        current = _fetch_and_cache_version(client, cache_manager, flow_id, version_id)
        etag = current.get("etag")

        # Ensure dict-keyed nodes (v2 format)
        graph = current.get("graph", {})
        _ensure_dict_nodes(graph)
        nodes = graph.get("nodes", {})

        current_node = nodes.get(node_id)
        if current_node is None:
            raise NotFoundError(f"Node not found: {node_id}")

        # Check for existing locks
        conflicting_locks: list[dict[str, Any]] = []
        existing_locks = current.get("locks", [])
        if isinstance(existing_locks, list):
            for lock in existing_locks:
                if (
                    lock.get("resource_type") == "node"
                    and lock.get("resource_id") == node_id
                    and lock.get("session") != session
                ):
                    conflicting_locks.append(lock)

        if conflicting_locks and not force:
            first_lock = conflicting_locks[0]
            raise ConflictError(f'Node "{node_id}" is locked by session "{first_lock.get("session")}"')

        if conflicting_locks and force:
            release_locks: dict[str, Any] = {}
            for lock in conflicting_locks:
                release_locks[lock["id"]] = None
            try:
                release_result = api_patch_version(
                    client, version_id, {"locks": release_locks}, if_match=etag, session=session
                )
                etag = release_result.get("etag")
            except ConflictError:
                continue

        # Deep-merge meta into the target node
        current_meta = current_node.get("meta") or {}
        merged_meta = deep_merge(current_meta, meta)

        # Build FULL nodes dict with only the target node modified
        patched_nodes = deepcopy(nodes)
        patched_nodes[node_id]["meta"] = merged_meta

        body: dict[str, Any] = {
            "graph": {"nodes": patched_nodes},
        }

        try:
            result = api_patch_version(client, version_id, body, if_match=etag, session=session)

            # Update cache — result may be v1 format (list nodes)
            cache_manager.write_version(version_id, flow_id, result)

            # Extract the updated node
            result_graph = result.get("graph", {})
            result_nodes = result_graph.get("nodes", {})
            # Handle v1 (list) response
            if isinstance(result_nodes, list):
                result_nodes = {n["id"]: n for n in result_nodes}

            updated_node = result_nodes.get(node_id, {})
            detail = NodeDetail.model_validate(updated_node)
            track(
                "operation",
                {
                    "op": "update_node",
                    "success": True,
                    "output_tokens": estimate_tokens(detail),
                    "duration_ms": int((time.monotonic() - start) * 1000),
                    "flow_slug": flow_slug,
                    "flow_version_name": version_name,
                    "etag_retries": attempt,
                },
            )
            return detail

        except ConflictError as exc:
            msg = str(exc).lower()
            if "locked" in msg or "session" in msg or msg.startswith("[validation]"):
                raise
            if attempt == _MAX_ETAG_RETRIES - 1:
                raise ConflictError(
                    f'Version "{version_name}" has been modified {_MAX_ETAG_RETRIES} times during update -- giving up.'
                )
            continue

    raise ConflictError(f'Version "{version_name}" conflict')  # pragma: no cover
