"""Operations layer — batch run execution and history."""

from __future__ import annotations

import asyncio
import csv
import hashlib
import io
import json
import re
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import httpx

from tktl.api.client import TktlClient
from tktl.api.datasets import create_download_job, download_s3_file, get_dataset_info, get_job_status
from tktl.api.execution import _resolve_workspace_base_url
from tktl.api.flows import get_flow_by_slug
from tktl.models.batch import BatchResult, BatchRowResult, BatchRunMeta, BatchRunSummary
from tktl.models.errors import NotFoundError, UsageError
from tktl.telemetry import estimate_tokens, track

MAX_BATCH_ROWS = 1000
DEFAULT_CONCURRENCY = 10

_BRACKET_RE: re.Pattern[str] | None = None


def _get_bracket_re() -> re.Pattern[str]:
    global _BRACKET_RE  # noqa: PLW0603
    if _BRACKET_RE is None:
        _BRACKET_RE = re.compile(r"^([^\[]+)\[(\d+)\]$")
    return _BRACKET_RE


# ---------------------------------------------------------------------------
# Query extraction
# ---------------------------------------------------------------------------


def extract_query(data: Any, query: str) -> Any:
    """Extract a value from nested data using a dot/bracket path.

    Supports ``data.key``, ``items[0]``, and combinations like
    ``data.scores[1].value``.  Returns ``None`` for missing keys or
    out-of-range indices.
    """
    if data is None:
        return None

    current = data
    bracket_re = _get_bracket_re()

    for part in query.split("."):
        if current is None:
            return None

        m = bracket_re.match(part)
        if m:
            key, idx_str = m.group(1), int(m.group(2))
            if isinstance(current, dict):
                current = current.get(key)
            else:
                return None
            if isinstance(current, list) and idx_str < len(current):
                current = current[idx_str]
            else:
                return None
        else:
            if isinstance(current, dict):
                current = current.get(part)
            else:
                return None

    return current


# ---------------------------------------------------------------------------
# File parsing
# ---------------------------------------------------------------------------


def parse_batch_file(path: Path) -> list[dict[str, Any]]:
    """Parse a batch input file. Supports CSV, JSON (object/array), JSONL/NDJSON.

    Returns a list of dicts, one per row. Raises ``UsageError`` on invalid
    input or if the file exceeds ``MAX_BATCH_ROWS``.
    """
    if not path.exists():
        raise UsageError(f"File not found: {path}")

    content = path.read_text()
    suffix = path.suffix.lower()

    if suffix == ".csv":
        rows = _parse_csv(content)
    elif suffix in (".jsonl", ".ndjson"):
        rows = _parse_jsonl(content)
    elif suffix == ".json":
        rows = _parse_json(content)
    else:
        rows = _auto_detect_parse(content)

    if len(rows) == 0:
        raise UsageError("Batch file is empty")
    if len(rows) > MAX_BATCH_ROWS:
        raise UsageError(f"Batch file has {len(rows)} rows, maximum is {MAX_BATCH_ROWS}")

    return rows


def _parse_csv(content: str) -> list[dict[str, Any]]:
    reader = csv.DictReader(io.StringIO(content))
    return [_coerce_csv_values(dict(row)) for row in reader]


def _coerce_csv_values(row: dict[str, Any]) -> dict[str, Any]:
    """Try to parse CSV string values as int, float, or bool."""
    result: dict[str, Any] = {}
    for k, v in row.items():
        if not isinstance(v, str):
            result[k] = v
            continue
        low = v.lower()
        if low == "true":
            result[k] = True
        elif low == "false":
            result[k] = False
        else:
            try:
                result[k] = int(v)
            except ValueError:
                try:
                    result[k] = float(v)
                except ValueError:
                    result[k] = v
    return result


def _parse_jsonl(content: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for line_num, line in enumerate(content.strip().splitlines(), 1):
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError as exc:
            raise UsageError(f"Invalid JSON on line {line_num}: {exc}") from exc
        if not isinstance(obj, dict):
            raise UsageError(f"Line {line_num} is not a JSON object")
        rows.append(obj)
    return rows


def _parse_json(content: str) -> list[dict[str, Any]]:
    try:
        data = json.loads(content)
    except json.JSONDecodeError as exc:
        raise UsageError(f"Invalid JSON: {exc}") from exc

    if isinstance(data, list):
        for i, item in enumerate(data):
            if not isinstance(item, dict):
                raise UsageError(f"Item {i} in JSON array is not an object")
        return data
    elif isinstance(data, dict):
        return [data]
    else:
        raise UsageError("JSON file must contain an array of objects or a single object")


def _auto_detect_parse(content: str) -> list[dict[str, Any]]:
    """Auto-detect format for files with unrecognized extensions."""
    stripped = content.strip()
    if stripped.startswith("["):
        return _parse_json(content)
    if stripped.startswith("{"):
        # Could be JSONL (multiple lines) or single JSON object
        lines = [line for line in stripped.splitlines() if line.strip()]
        if len(lines) > 1:
            return _parse_jsonl(content)
        return _parse_json(content)
    # Fall back to CSV
    return _parse_csv(content)


# ---------------------------------------------------------------------------
# Dataset resolution
# ---------------------------------------------------------------------------

_POLL_SCHEDULE = [0.5] * 5 + [1.0] * 5 + [2.0] * 10  # ~35s max


def _resolve_dataset_rows(
    client: TktlClient,
    base_url: str,
    workspace_id: str,
    flow_slug: str,
    dataset_id: str,
    *,
    cache_dir: Path | None = None,
) -> tuple[list[dict[str, Any]], str, str | None]:
    """Download a dataset and extract input rows.

    Returns ``(rows, source_hash, dataset_etag)``.
    Uses local cache with ETag validation to avoid redundant downloads.
    """
    if cache_dir is None:
        cache_dir = Path.home() / ".tktl" / "cache"
    ds_cache = cache_dir / "datasets" / dataset_id

    # Check cache
    cached_etag: str | None = None
    if (ds_cache / "meta.json").exists() and (ds_cache / "data.json").exists():
        meta_data = json.loads((ds_cache / "meta.json").read_text())
        cached_etag = meta_data.get("etag")

        # Validate freshness via info endpoint
        info, current_etag = get_dataset_info(client._api_key, base_url, dataset_id, etag=cached_etag)
        if info is None:
            # 304 — cache is fresh
            content = (ds_cache / "data.json").read_bytes()
            rows = _extract_input_rows(json.loads(content))
            source_hash = f"sha256:{hashlib.sha256(content).hexdigest()}"
            return rows, source_hash, cached_etag

    # Resolve flow_id from slug (needed for job creation)
    flow_data = get_flow_by_slug(client, workspace_id, flow_slug)
    flow_id = flow_data["id"]

    # Create download job
    job = create_download_job(client._api_key, base_url, flow_id, dataset_id)
    job_id = job["id"]
    status = job.get("status", "PENDING")

    # Poll until complete
    if status != "COMPLETED":
        for delay in _POLL_SCHEDULE:
            time.sleep(delay)
            job = get_job_status(client._api_key, base_url, job_id)
            status = job.get("status", "PENDING")
            if status in ("COMPLETED", "FAILED"):
                break

    if status == "FAILED":
        error_msg = (job.get("error") or {}).get("message", "Unknown error")
        raise UsageError(f"Dataset download job failed: {error_msg}")
    if status != "COMPLETED":
        raise UsageError("Dataset download job timed out")

    # Download from S3
    s3_url = (job.get("response") or {}).get("s3_url")
    if not s3_url:
        raise UsageError("Dataset download job completed but no S3 URL in response")

    content = download_s3_file(s3_url)

    # Cache the downloaded data
    ds_cache.mkdir(parents=True, exist_ok=True)
    (ds_cache / "data.json").write_bytes(content)

    # Get ETag for cache meta
    dataset_etag: str | None = None
    try:
        info, dataset_etag = get_dataset_info(client._api_key, base_url, dataset_id)
    except Exception:
        pass  # Non-critical — we have the data

    cache_meta = {
        "dataset_id": dataset_id,
        "etag": dataset_etag,
        "cached_at": datetime.now(timezone.utc).isoformat(),
    }
    (ds_cache / "meta.json").write_text(json.dumps(cache_meta, indent=2))

    rows = _extract_input_rows(json.loads(content))
    source_hash = f"sha256:{hashlib.sha256(content).hexdigest()}"
    return rows, source_hash, dataset_etag


def _extract_input_rows(data: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Extract input rows from dataset data.

    Downloaded datasets use the decide request structure: ``{"request": {"data": {...}}}``.
    This function unwraps to the inner ``data`` dict so it can be used directly as the
    decide payload's ``data`` field. Falls back to ``input_data`` key, then the row as-is.
    """
    rows: list[dict[str, Any]] = []
    for item in data:
        if not isinstance(item, dict):
            continue
        # Unwrap request.data (standard dataset download format)
        req = item.get("request")
        if isinstance(req, dict) and "data" in req and isinstance(req["data"], dict):
            rows.append(req["data"])
        # Unwrap input_data (datasets API row format)
        elif "input_data" in item and isinstance(item["input_data"], dict):
            rows.append(item["input_data"])
        else:
            rows.append(item)
    return rows


# ---------------------------------------------------------------------------
# Batch execution
# ---------------------------------------------------------------------------


def run_batch(
    client: TktlClient,
    workspace_id: str,
    flow_slug: str,
    *,
    file_path: Path | None = None,
    dataset_id: str | None = None,
    version: str | None = None,
    env: str = "sandbox",
    concurrency: int = DEFAULT_CONCURRENCY,
    runs_dir: Path | None = None,
    cache_dir: Path | None = None,
    _transport: httpx.AsyncBaseTransport | None = None,
) -> BatchResult:
    """Run a batch of decisions from a local file or platform dataset.

    Exactly one of ``file_path`` or ``dataset_id`` must be provided.
    """
    if file_path is None and dataset_id is None:
        raise UsageError("Provide either --file or --dataset")
    if file_path is not None and dataset_id is not None:
        raise UsageError("Provide either --file or --dataset, not both")

    start = time.monotonic()
    started_at = datetime.now(timezone.utc).isoformat()

    # Resolve workspace base_url (sync, before entering async)
    base_url = _resolve_workspace_base_url(client, workspace_id)
    decide_url = f"{base_url}/run/api/v1/flows/{flow_slug}/{env}/decide"

    # Resolve input rows
    if file_path is not None:
        rows = parse_batch_file(file_path)
        file_content = file_path.read_bytes()
        source_type = "file"
        source = str(file_path)
        source_hash = f"sha256:{hashlib.sha256(file_content).hexdigest()}"
        dataset_etag = None
    else:
        assert dataset_id is not None
        rows, source_hash, dataset_etag = _resolve_dataset_rows(
            client,
            base_url,
            workspace_id,
            flow_slug,
            dataset_id,
            cache_dir=cache_dir,
        )
        source_type = "dataset"
        source = f"dataset:{dataset_id}"

    if len(rows) == 0:
        raise UsageError("Batch input is empty")
    if len(rows) > MAX_BATCH_ROWS:
        raise UsageError(f"Batch input has {len(rows)} rows, maximum is {MAX_BATCH_ROWS}")

    # Create run directory
    run_id = str(uuid.uuid4())
    if runs_dir is None:
        runs_dir = Path.home() / ".tktl" / "runs"
    run_dir = runs_dir / flow_slug / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    results_path = run_dir / "results.jsonl"

    # Write initial meta
    meta = BatchRunMeta(
        run_id=run_id,
        flow_slug=flow_slug,
        env=env,
        version=version,
        source_type=source_type,
        source=source,
        source_hash=source_hash,
        dataset_etag=dataset_etag,
        concurrency=concurrency,
        total_rows=len(rows),
        succeeded=0,
        failed=0,
        started_at=started_at,
        completed_at=None,
        duration_ms=None,
    )
    _write_meta(run_dir, meta)

    # Execute batch
    succeeded, failed = asyncio.run(
        _execute_batch_async(
            api_key=client._api_key,
            decide_url=decide_url,
            rows=rows,
            version=version,
            concurrency=concurrency,
            results_path=results_path,
            transport=_transport,
        )
    )

    # Finalize meta
    duration_ms = int((time.monotonic() - start) * 1000)
    meta = BatchRunMeta(
        run_id=run_id,
        flow_slug=flow_slug,
        env=env,
        version=version,
        source_type=source_type,
        source=source,
        source_hash=source_hash,
        dataset_etag=dataset_etag,
        concurrency=concurrency,
        total_rows=len(rows),
        succeeded=succeeded,
        failed=failed,
        started_at=started_at,
        completed_at=datetime.now(timezone.utc).isoformat(),
        duration_ms=duration_ms,
    )
    _write_meta(run_dir, meta)
    _update_run_index(runs_dir, flow_slug, meta)

    # Telemetry
    track(
        "batch_execution",
        {
            "op": "run_batch",
            "success": True,
            "total_rows": len(rows),
            "succeeded": succeeded,
            "failed": failed,
            "concurrency": concurrency,
            "input_tokens": estimate_tokens(rows),
            "duration_ms": duration_ms,
            "flow_slug": flow_slug,
            "env": env,
            "source_type": source_type,
        },
    )

    return BatchResult(meta=meta, results_path=str(results_path))


async def _execute_batch_async(
    *,
    api_key: str,
    decide_url: str,
    rows: list[dict[str, Any]],
    version: str | None,
    concurrency: int,
    results_path: Path,
    transport: httpx.AsyncBaseTransport | None = None,
) -> tuple[int, int]:
    """Execute all rows concurrently, writing results to JSONL as they complete."""
    semaphore = asyncio.Semaphore(concurrency)
    succeeded = 0
    failed = 0

    client_kwargs: dict[str, Any] = {}
    if transport is not None:
        client_kwargs["transport"] = transport

    async with httpx.AsyncClient(**client_kwargs) as client:

        async def run_one(index: int, input_data: dict[str, Any]) -> None:
            nonlocal succeeded, failed
            async with semaphore:
                row_start = time.monotonic()
                body: dict[str, Any] = {
                    "data": input_data,
                    "metadata": {},
                    "control": {"execution_mode": "sync"},
                }
                if version is not None:
                    body["metadata"]["version"] = version
                try:
                    resp = await client.post(
                        decide_url,
                        json=body,
                        headers={"X-Api-Key": api_key},
                        timeout=30.0,
                    )
                    result_data = resp.json()
                    row_result = BatchRowResult(
                        row_index=index,
                        input=input_data,
                        output=result_data,
                        error=None,
                        duration_ms=int((time.monotonic() - row_start) * 1000),
                        timestamp=datetime.now(timezone.utc).isoformat(),
                    )
                    succeeded += 1
                except Exception as exc:
                    row_result = BatchRowResult(
                        row_index=index,
                        input=input_data,
                        output=None,
                        error=str(exc),
                        duration_ms=int((time.monotonic() - row_start) * 1000),
                        timestamp=datetime.now(timezone.utc).isoformat(),
                    )
                    failed += 1

                # Append to JSONL (safe in asyncio single-thread)
                with open(results_path, "a") as f:
                    f.write(row_result.model_dump_json() + "\n")

        tasks = [run_one(i, row) for i, row in enumerate(rows)]
        await asyncio.gather(*tasks)

    return succeeded, failed


# ---------------------------------------------------------------------------
# History — storage helpers
# ---------------------------------------------------------------------------


def _write_meta(run_dir: Path, meta: BatchRunMeta) -> None:
    (run_dir / "meta.json").write_text(meta.model_dump_json(indent=2))


def _update_run_index(runs_dir: Path, flow_slug: str, meta: BatchRunMeta) -> None:
    """Append a run summary to the flow's index.json."""
    flow_dir = runs_dir / flow_slug
    flow_dir.mkdir(parents=True, exist_ok=True)
    index_path = flow_dir / "index.json"

    if index_path.exists():
        index = json.loads(index_path.read_text())
    else:
        index = {"runs": []}

    summary = BatchRunSummary(
        run_id=meta.run_id,
        source_type=meta.source_type,
        source=meta.source,
        source_hash=meta.source_hash,
        total_rows=meta.total_rows,
        succeeded=meta.succeeded,
        failed=meta.failed,
        started_at=meta.started_at,
        duration_ms=meta.duration_ms,
    )
    index["runs"].append(summary.model_dump())
    index_path.write_text(json.dumps(index, indent=2))


# ---------------------------------------------------------------------------
# History — read operations
# ---------------------------------------------------------------------------


def list_batch_runs(
    flow_slug: str,
    *,
    runs_dir: Path | None = None,
) -> list[BatchRunSummary]:
    """List all batch runs for a flow."""
    if runs_dir is None:
        runs_dir = Path.home() / ".tktl" / "runs"
    index_path = runs_dir / flow_slug / "index.json"
    if not index_path.exists():
        return []
    data = json.loads(index_path.read_text())
    return [BatchRunSummary.model_validate(r) for r in data.get("runs", [])]


def get_batch_run(
    flow_slug: str,
    run_id: str,
    *,
    runs_dir: Path | None = None,
) -> BatchRunMeta:
    """Get metadata for a specific batch run."""
    if runs_dir is None:
        runs_dir = Path.home() / ".tktl" / "runs"
    meta_path = runs_dir / flow_slug / run_id / "meta.json"
    if not meta_path.exists():
        raise NotFoundError(f"Batch run '{run_id}' not found for flow '{flow_slug}'")
    return BatchRunMeta.model_validate_json(meta_path.read_text())


def get_batch_results(
    flow_slug: str,
    run_id: str,
    *,
    runs_dir: Path | None = None,
) -> list[BatchRowResult]:
    """Read all row results for a specific batch run."""
    if runs_dir is None:
        runs_dir = Path.home() / ".tktl" / "runs"
    results_path = runs_dir / flow_slug / run_id / "results.jsonl"
    if not results_path.exists():
        raise NotFoundError(f"Results not found for batch run '{run_id}' of flow '{flow_slug}'")
    results: list[BatchRowResult] = []
    for line in results_path.read_text().strip().splitlines():
        line = line.strip()
        if line:
            results.append(BatchRowResult.model_validate_json(line))
    return results
