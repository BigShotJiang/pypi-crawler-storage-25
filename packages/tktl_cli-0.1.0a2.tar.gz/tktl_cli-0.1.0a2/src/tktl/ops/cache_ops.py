"""Cache management operations: refresh, clear, status."""

from __future__ import annotations

import os
import time
from typing import Any

from tktl.api.client import TktlClient
from tktl.api.flows import get_flow_by_slug, list_flows as api_list_flows
from tktl.api.versions import get_version as api_get_version
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.telemetry import estimate_tokens, track


def refresh_cache(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
    workspace_id: str,
) -> None:
    """Force-rebuild the entire cache for a workspace.

    1. List all flows
    2. For each flow, fetch flow detail and update index
    3. For each version, fetch full version and cache (decompose into per-node files)
    """
    start = time.monotonic()
    # List all flows
    flows = api_list_flows(client, workspace_id)

    cache_index.workspace_id = workspace_id

    for flow in flows:
        slug = flow["slug"]
        flow_id = flow["id"]

        # Fetch flow detail to get version summaries
        flow_detail = get_flow_by_slug(client, workspace_id, slug)

        # Cache flow metadata
        cache_manager.write_flow_metadata(flow_id, flow_detail)

        # Build version mappings
        versions_map: dict[str, str] = {}
        for v in flow_detail.get("versions", []):
            versions_map[v["name"]] = v["id"]

        cache_index.update_flow(slug, flow_id, versions_map)

        # Fetch and cache each version
        for version_name, version_id in versions_map.items():
            raw = api_get_version(client, version_id)
            if raw is not None:
                cache_manager.write_version(version_id, flow_id, raw)

    cache_index.save()
    track(
        "operation",
        {
            "op": "refresh_cache",
            "success": True,
            "output_tokens": 0,
            "duration_ms": int((time.monotonic() - start) * 1000),
        },
    )


def clear_cache(cache_manager: CacheManager) -> None:
    """Delete all cached data."""
    start = time.monotonic()
    cache_manager.clear_all()
    track(
        "operation",
        {
            "op": "clear_cache",
            "success": True,
            "output_tokens": 0,
            "duration_ms": int((time.monotonic() - start) * 1000),
        },
    )


def cache_status(cache_manager: CacheManager) -> dict[str, Any]:
    """Return status information about the cache.

    Returns a dict with:
    - cache_dir: path to the cache directory
    - exists: whether the cache directory exists
    - size_bytes: total size of cached files (if exists)
    - file_count: number of cached files (if exists)
    """
    start = time.monotonic()
    cache_dir = cache_manager._cache_dir
    result: dict[str, Any] = {
        "cache_dir": str(cache_dir),
        "exists": cache_dir.exists(),
    }

    if cache_dir.exists():
        total_size = 0
        file_count = 0
        for dirpath, _dirnames, filenames in os.walk(cache_dir):
            for f in filenames:
                fp = os.path.join(dirpath, f)
                total_size += os.path.getsize(fp)
                file_count += 1
        result["size_bytes"] = total_size
        result["file_count"] = file_count

    track(
        "operation",
        {
            "op": "cache_status",
            "success": True,
            "output_tokens": estimate_tokens(result),
            "duration_ms": int((time.monotonic() - start) * 1000),
        },
    )
    return result
