"""Operations layer — manual review node helpers."""

from __future__ import annotations

import uuid
from typing import Any

from tktl.api.client import TktlClient
from tktl.models.errors import NotFoundError
from tktl.ops.connections import list_connections


def find_manual_review_connection(
    client: TktlClient,
    workspace_id: str,
) -> tuple[str, str]:
    """Find the workspace's manual review connection and its first resource config.

    Every workspace has a single pre-provisioned manual review connection.

    Returns:
        (connection_id, resource_config_id)

    Raises:
        NotFoundError: If no manual_review connection exists in the workspace.
    """
    connections = list_connections(client, workspace_id)
    for conn in connections:
        if conn.provider == "manual_review":
            if conn.resource_configs:
                return conn.id, conn.resource_configs[0].id
            raise NotFoundError(f"Manual review connection '{conn.id}' has no resource configs")
    raise NotFoundError("No manual_review connection found in workspace")


def build_default_review_meta(
    connection_id: str,
    resource_config_id: str,
    *,
    highlights: list[dict[str, Any]] | None = None,
    response_form: dict[str, Any] | None = None,
    assign_strategy: str = "ANY",
) -> dict[str, Any]:
    """Build a ManualReviewNodeMeta dict with sensible defaults.

    Args:
        connection_id: UUID of the manual review connection.
        resource_config_id: UUID of the resource config on that connection.
        highlights: Optional list of highlight items to show the reviewer.
            Defaults to an empty list.
        response_form: Optional response form dict. Defaults to a single
            boolean "Approved" field.
        assign_strategy: Reviewer assignment strategy. One of "ANY",
            "REVIEWER_ONLY", "GROUP", "RULE". Defaults to "ANY".

    Returns:
        A dict suitable for use as the ``meta`` field of a
        ``review_connection_node``.
    """
    if response_form is None:
        response_form = {
            "description": "",
            "fields": [
                {
                    "id": str(uuid.uuid4()),
                    "key": "approved",
                    "type": "boolean",
                    "required": True,
                    "name": "Approved",
                    "enum": None,
                    "display_as": None,
                },
            ],
        }

    return {
        "provider_resource": {
            "provider": "manual_review",
            "resource": "manual_review",
        },
        "connection_id": connection_id,
        "resource_config_id": resource_config_id,
        "highlights": highlights or [],
        "response_form": response_form,
        "reviewer_assign_strategy": assign_strategy,
        "reviewer_assign_strategy_v2": {"type": assign_strategy},
        "response_metadata_key": None,
    }
