"""Operations layer — the heart of the library-first architecture.

All ops functions accept typed args, handle ID resolution, caching, locking,
ETag retry, and return typed Pydantic models.
"""

from tktl.ops.batch import (
    extract_query,
    get_batch_results,
    get_batch_run,
    list_batch_runs,
    parse_batch_file,
    run_batch,
)
from tktl.ops.cache_ops import cache_status, clear_cache, refresh_cache
from tktl.ops.graph import add_node, remove_node
from tktl.ops.flows import describe_flow, list_flows, run_flow
from tktl.ops.nodes import get_node, list_nodes, update_node
from tktl.ops.versions import (
    archive_version,
    create_version,
    describe_version,
    duplicate_version,
    list_changes,
    list_versions,
    publish_version,
    replace_version,
    update_version,
)

__all__ = [
    # Batch ops
    "run_batch",
    "parse_batch_file",
    "list_batch_runs",
    "get_batch_run",
    "get_batch_results",
    "extract_query",
    # Graph ops
    "add_node",
    "remove_node",
    # Flow ops
    "list_flows",
    "describe_flow",
    "run_flow",
    # Version ops
    "list_versions",
    "describe_version",
    "list_changes",
    "update_version",
    "publish_version",
    "archive_version",
    "create_version",
    "duplicate_version",
    "replace_version",
    # Node ops
    "list_nodes",
    "get_node",
    "update_node",
    # Cache ops
    "refresh_cache",
    "clear_cache",
    "cache_status",
]
