"""Operations layer — folder operations."""

from __future__ import annotations

import time

from tktl.api.client import TktlClient
from tktl.api.folders import create_folder as api_create_folder
from tktl.api.folders import list_folders as api_list_folders
from tktl.models.folder import FolderDetail, FolderSummary
from tktl.telemetry import estimate_tokens, track


def list_folders(client: TktlClient, workspace_id: str) -> list[FolderSummary]:
    """List all folders in a workspace."""
    start = time.monotonic()
    raw = api_list_folders(client, workspace_id)
    result = [FolderSummary.model_validate(f) for f in raw]
    track(
        "operation",
        {
            "op": "list_folders",
            "success": True,
            "output_tokens": estimate_tokens(result),
            "duration_ms": int((time.monotonic() - start) * 1000),
        },
    )
    return result


def create_folder(client: TktlClient, workspace_id: str, name: str) -> FolderDetail:
    """Create a new folder in a workspace."""
    start = time.monotonic()
    raw = api_create_folder(client, workspace_id, name)
    result = FolderDetail.model_validate(raw)
    track(
        "operation",
        {
            "op": "create_folder",
            "success": True,
            "output_tokens": estimate_tokens(result),
            "duration_ms": int((time.monotonic() - start) * 1000),
        },
    )
    return result
