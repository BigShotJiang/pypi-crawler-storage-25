"""Operations layer — comment read and write operations."""

from __future__ import annotations

import time
from typing import Any

from tktl.api.client import TktlClient
from tktl.api.comments import (
    create_comment as api_create_comment,
    delete_comment as api_delete_comment,
    get_comment_summary as api_get_comment_summary,
    list_comments as api_list_comments,
)
from tktl.cache.index import CacheIndex
from tktl.ops.versions import _resolve_ids
from tktl.telemetry import estimate_tokens, track


def list_comments(
    client: TktlClient,
    cache_index: CacheIndex,
    workspace_id: str,
    flow_slug: str,
    version_name: str,
    *,
    node_id: str | None = None,
) -> list[dict[str, Any]]:
    """List comments for a flow version, optionally filtered to a specific node."""
    start = time.monotonic()
    _flow_id, version_id = _resolve_ids(client, cache_index, workspace_id, flow_slug, version_name)
    assert version_id is not None

    resource_type = "node" if node_id else None
    result = api_list_comments(
        client,
        version_id,
        resource_type=resource_type,
        resource_id=node_id,
    )

    track(
        "operation",
        {
            "op": "list_comments",
            "success": True,
            "output_tokens": estimate_tokens(result),
            "duration_ms": int((time.monotonic() - start) * 1000),
            "flow_slug": flow_slug,
            "flow_version_name": version_name,
        },
    )
    return result


def add_comment(
    client: TktlClient,
    cache_index: CacheIndex,
    workspace_id: str,
    flow_slug: str,
    version_name: str,
    content: str,
    *,
    node_id: str | None = None,
) -> dict[str, Any]:
    """Add a comment to a flow version or a specific node."""
    start = time.monotonic()
    _flow_id, version_id = _resolve_ids(client, cache_index, workspace_id, flow_slug, version_name)
    assert version_id is not None

    if node_id:
        resource_type = "node"
        resource_id = node_id
    else:
        resource_type = "flow-version"
        resource_id = version_id

    result = api_create_comment(
        client,
        version_id,
        content,
        resource_type=resource_type,
        resource_id=resource_id,
    )

    track(
        "operation",
        {
            "op": "add_comment",
            "success": True,
            "output_tokens": estimate_tokens(result),
            "duration_ms": int((time.monotonic() - start) * 1000),
            "flow_slug": flow_slug,
            "flow_version_name": version_name,
            "node_id": node_id,
        },
    )
    return result


def delete_comment(
    client: TktlClient,
    comment_id: str,
) -> None:
    """Delete a comment by ID."""
    api_delete_comment(client, comment_id)


def comment_summary(
    client: TktlClient,
    cache_index: CacheIndex,
    workspace_id: str,
    flow_slug: str,
    version_name: str,
) -> list[dict[str, Any]]:
    """Get per-node comment counts for a flow version."""
    _flow_id, version_id = _resolve_ids(client, cache_index, workspace_id, flow_slug, version_name)
    assert version_id is not None
    return api_get_comment_summary(client, version_id)
