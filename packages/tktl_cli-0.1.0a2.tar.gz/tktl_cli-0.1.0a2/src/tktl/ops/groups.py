"""Operations layer — node group CRUD."""

from __future__ import annotations

import uuid
from typing import Any

from tktl.api.client import TktlClient
from tktl.api.versions import get_version, patch_version
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.models.errors import NotFoundError
from tktl.models.group import GroupDetail, GroupSummary
from tktl.ops.nodes import _ensure_dict_nodes
from tktl.ops.versions import _fetch_and_cache_version, _resolve_ids


def _get_version_data(
    client: TktlClient,
    cache_index: CacheIndex,
    workspace_id: str,
    slug: str,
    version_name: str,
) -> tuple[str, str, dict[str, Any]]:
    """Resolve IDs and fetch the current version. Returns (flow_id, version_id, raw)."""
    flow_id, version_id = _resolve_ids(client, cache_index, workspace_id, slug, version_name)
    if flow_id is None or version_id is None:
        raise NotFoundError(f"Could not resolve flow '{slug}' or version '{version_name}'")
    raw = get_version(client, version_id)
    if raw is None:
        raise NotFoundError(f"Version '{version_name}' not found")
    _ensure_dict_nodes(raw.get("graph", {}))
    return flow_id, version_id, raw


def _extract_groups(raw: dict[str, Any]) -> dict[str, Any]:
    """Extract the node_groups dict from a version response."""
    return raw.get("graph", {}).get("node_groups", {})


def list_groups(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
    workspace_id: str,
    slug: str,
    version_name: str,
) -> list[GroupSummary]:
    """List all node groups in a version."""
    flow_id, version_id, raw = _get_version_data(client, cache_index, workspace_id, slug, version_name)
    groups = _extract_groups(raw)
    return [GroupSummary.model_validate(g) for g in groups.values()]


def get_group(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
    workspace_id: str,
    slug: str,
    version_name: str,
    group_id: str,
) -> GroupDetail:
    """Get a single node group by ID."""
    flow_id, version_id, raw = _get_version_data(client, cache_index, workspace_id, slug, version_name)
    groups = _extract_groups(raw)
    group_data = groups.get(group_id)
    if group_data is None:
        raise NotFoundError(f"Group not found: {group_id}")
    return GroupDetail.model_validate(group_data)


def create_group(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
    workspace_id: str,
    slug: str,
    version_name: str,
    *,
    name: str,
    node_ids: list[str],
    meta: dict[str, Any] | None = None,
) -> GroupDetail:
    """Create a new node group."""
    flow_id, version_id, raw = _get_version_data(client, cache_index, workspace_id, slug, version_name)
    nodes = raw.get("graph", {}).get("nodes", {})

    # Validate node_ids exist
    missing = [nid for nid in node_ids if nid not in nodes]
    if missing:
        raise NotFoundError(f"Node(s) not found in version: {', '.join(missing)}")

    new_id = str(uuid.uuid4())
    group_data: dict[str, Any] = {"id": new_id, "name": name, "node_ids": node_ids}
    if meta is not None:
        group_data["meta"] = meta

    patch_version(
        client,
        version_id,
        {"graph": {"node_groups": {new_id: group_data}}},
        if_match=raw["etag"],
        session=str(uuid.uuid4()),
    )

    _fetch_and_cache_version(client, cache_manager, flow_id, version_id)

    # Re-fetch to get server state
    updated = get_version(client, version_id)
    if updated is None:
        raise NotFoundError(f"Version '{version_name}' not found after update")
    _ensure_dict_nodes(updated.get("graph", {}))
    return GroupDetail.model_validate(_extract_groups(updated)[new_id])


def update_group(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
    workspace_id: str,
    slug: str,
    version_name: str,
    group_id: str,
    *,
    name: str | None = None,
    node_ids: list[str] | None = None,
    meta: dict[str, Any] | None = None,
) -> GroupDetail:
    """Update a node group's name, members, or meta."""
    flow_id, version_id, raw = _get_version_data(client, cache_index, workspace_id, slug, version_name)
    groups = _extract_groups(raw)
    existing = groups.get(group_id)
    if existing is None:
        raise NotFoundError(f"Group not found: {group_id}")

    updated_group = dict(existing)
    if name is not None:
        updated_group["name"] = name
    if node_ids is not None:
        updated_group["node_ids"] = node_ids
    if meta is not None:
        updated_group["meta"] = meta

    patch_version(
        client,
        version_id,
        {"graph": {"node_groups": {group_id: updated_group}}},
        if_match=raw["etag"],
        session=str(uuid.uuid4()),
    )

    _fetch_and_cache_version(client, cache_manager, flow_id, version_id)

    updated = get_version(client, version_id)
    if updated is None:
        raise NotFoundError(f"Version '{version_name}' not found after update")
    _ensure_dict_nodes(updated.get("graph", {}))
    return GroupDetail.model_validate(_extract_groups(updated)[group_id])


def delete_group(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
    workspace_id: str,
    slug: str,
    version_name: str,
    group_id: str,
) -> list[GroupSummary]:
    """Delete a node group. Returns remaining groups."""
    flow_id, version_id, raw = _get_version_data(client, cache_index, workspace_id, slug, version_name)
    groups = _extract_groups(raw)
    if group_id not in groups:
        raise NotFoundError(f"Group not found: {group_id}")

    patch_version(
        client,
        version_id,
        {"graph": {"node_groups": {group_id: None}}},
        if_match=raw["etag"],
        session=str(uuid.uuid4()),
    )

    _fetch_and_cache_version(client, cache_manager, flow_id, version_id)

    updated = get_version(client, version_id)
    if updated is None:
        raise NotFoundError(f"Version '{version_name}' not found after update")
    _ensure_dict_nodes(updated.get("graph", {}))
    remaining = _extract_groups(updated)
    return [GroupSummary.model_validate(g) for g in remaining.values()]


def add_nodes_to_group(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
    workspace_id: str,
    slug: str,
    version_name: str,
    group_id: str,
    *,
    node_ids: list[str],
) -> GroupDetail:
    """Add nodes to an existing group (union, no duplicates)."""
    flow_id, version_id, raw = _get_version_data(client, cache_index, workspace_id, slug, version_name)
    groups = _extract_groups(raw)
    existing = groups.get(group_id)
    if existing is None:
        raise NotFoundError(f"Group not found: {group_id}")

    current_ids = existing.get("node_ids", [])
    # Union preserving order: existing first, then new ones not already present
    merged = list(current_ids)
    seen = set(current_ids)
    for nid in node_ids:
        if nid not in seen:
            merged.append(nid)
            seen.add(nid)

    return update_group(
        client,
        cache_index,
        cache_manager,
        workspace_id,
        slug,
        version_name,
        group_id,
        node_ids=merged,
    )


def remove_nodes_from_group(
    client: TktlClient,
    cache_index: CacheIndex,
    cache_manager: CacheManager,
    workspace_id: str,
    slug: str,
    version_name: str,
    group_id: str,
    *,
    node_ids: list[str],
) -> GroupDetail:
    """Remove nodes from a group."""
    flow_id, version_id, raw = _get_version_data(client, cache_index, workspace_id, slug, version_name)
    groups = _extract_groups(raw)
    existing = groups.get(group_id)
    if existing is None:
        raise NotFoundError(f"Group not found: {group_id}")

    current_ids = existing.get("node_ids", [])
    remove_set = set(node_ids)
    filtered = [nid for nid in current_ids if nid not in remove_set]

    return update_group(
        client,
        cache_index,
        cache_manager,
        workspace_id,
        slug,
        version_name,
        group_id,
        node_ids=filtered,
    )
