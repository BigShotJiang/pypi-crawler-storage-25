"""Folder API functions."""

from __future__ import annotations

from typing import Any

from tktl.api.client import TktlClient
from tktl.models.errors import NotFoundError


def list_folders(client: TktlClient, workspace_id: str) -> list[dict[str, Any]]:
    """List all folders in a workspace.

    GET /api/v1/folders/{workspace_id}
    """
    resp = client.get(f"/api/v1/folders/{workspace_id}")
    if resp.status_code == 200:
        return resp.json().get("folders", [])
    resp.raise_for_status()
    return []  # pragma: no cover


def create_folder(client: TktlClient, workspace_id: str, name: str) -> dict[str, Any]:
    """Create a new folder in a workspace.

    POST /api/v1/folders/
    """
    resp = client.post("/api/v1/folders/", json={"name": name, "workspace_id": workspace_id})
    if resp.status_code == 200:
        return resp.json()
    resp.raise_for_status()
    return {}  # pragma: no cover


def update_flow_folder(client: TktlClient, flow_id: str, folder_id: str) -> None:
    """Move a flow into a folder.

    PATCH /api/v1/flows/{id}
    """
    resp = client.patch(f"/api/v1/flows/{flow_id}", json={"folder_id": folder_id})
    if resp.status_code == 200:
        return
    if resp.status_code == 404:
        raise NotFoundError(f"Flow '{flow_id}' not found")
    resp.raise_for_status()
