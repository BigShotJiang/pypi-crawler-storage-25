"""Version API functions."""

from __future__ import annotations

import uuid
from typing import Any

from tktl.api.client import TktlClient
from tktl.models.errors import ConflictError, NotFoundError

# Fields inside node meta that should be auto-populated with UUIDs if missing
_ID_FIELDS = {"id", "id_left", "id_right"}


def get_version(
    client: TktlClient,
    version_id: str,
    if_none_match: str | None = None,
) -> dict[str, Any] | None:
    """Get a flow version (v2 format with graph).

    GET /api/v2/flow_versions/{id}

    Returns None if the server returns 304 Not Modified.
    """
    headers: dict[str, str] = {}
    if if_none_match:
        headers["if-none-match"] = if_none_match

    resp = client.get(f"/api/v2/flow_versions/{version_id}", headers=headers or None)

    if resp.status_code == 304:
        return None
    if resp.status_code == 404:
        raise NotFoundError(f"Version '{version_id}' not found")
    if resp.status_code == 200:
        return resp.json()
    resp.raise_for_status()
    return None  # pragma: no cover


def _fill_ids_recursive(obj: Any) -> None:
    """Auto-populate ``id``, ``id_left``, ``id_right`` fields with UUIDs.

    Walks any dict/list structure and generates a fresh UUID for any
    id-like field that is missing, empty, or a non-UUID short string
    (e.g. ``"f1"``, ``"ce1"``).  This lets callers build node meta
    without manually generating UUIDs for every clause, branch, effect,
    predicate, etc.
    """
    if isinstance(obj, dict):
        for key in _ID_FIELDS:
            if key in obj:
                val = obj[key]
                if not val or (isinstance(val, str) and not _is_uuid(val)):
                    obj[key] = str(uuid.uuid4())
        for value in obj.values():
            _fill_ids_recursive(value)
    elif isinstance(obj, list):
        for item in obj:
            _fill_ids_recursive(item)


def _is_uuid(s: str) -> bool:
    """Check if a string looks like a UUID."""
    try:
        uuid.UUID(s)
        return True
    except (ValueError, AttributeError):
        return False


def _fix_decision_table_keys(meta: dict[str, Any]) -> None:
    """Ensure all decision_table field IDs are UUIDs and remap case keys.

    The execution engine requires predicate_fields[].id and effect_fields[].id
    to be proper UUIDs.  If callers use short keys like ``"p1"``, this function
    replaces them with generated UUIDs and remaps all references in cases and
    fallback to match.
    """
    pred_fields = meta.get("predicate_fields")
    eff_fields = meta.get("effect_fields")
    if not pred_fields and not eff_fields:
        return

    # Build old-id → new-uuid mapping for non-UUID IDs
    id_map: dict[str, str] = {}

    for field_list in [pred_fields or [], eff_fields or []]:
        for field in field_list:
            old_id = field.get("id", "")
            if old_id and not _is_uuid(old_id):
                new_id = str(uuid.uuid4())
                id_map[old_id] = new_id
                field["id"] = new_id

    if not id_map:
        return  # all IDs were already UUIDs

    # Remap case predicate/effect dict keys
    for case in meta.get("cases", []):
        for dict_key in ("predicates", "effects"):
            old_dict = case.get(dict_key)
            if not isinstance(old_dict, dict):
                continue
            new_dict: dict[str, Any] = {}
            for k, v in old_dict.items():
                new_dict[id_map.get(k, k)] = v
            case[dict_key] = new_dict

    # Remap fallback keys
    old_fb = meta.get("fallback")
    if isinstance(old_fb, dict):
        new_fb: dict[str, Any] = {}
        for k, v in old_fb.items():
            new_fb[id_map.get(k, k)] = v
        meta["fallback"] = new_fb


def _list_to_dict(items: list[dict[str, Any]]) -> dict[str, Any]:
    """Convert a list of items with ``id`` fields to a dict keyed by id."""
    return {item["id"]: item for item in items if isinstance(item, dict) and "id" in item}


# Fields that only appear in API responses, not valid for PUT/PATCH input
_SERVER_ONLY_FIELDS = {
    "created_at",
    "updated_at",
    "graph_id",
    "locks",
    "child_versions",
    "parent_versions",
    "etag",
    "status",
    "id",
    "api_version",
    "review",
}


def normalize_graph_response(body: dict[str, Any]) -> dict[str, Any]:
    """Normalize graph collections in an API response (list→dict) without stripping fields.

    Use this on PATCH/PUT responses that need to be cached or further processed,
    where stripping server-only fields (id, etag, etc.) would break downstream code.
    """
    graph = body.get("graph")
    if not graph:
        return body
    for collection in ("nodes", "edges", "node_groups"):
        items = graph.get(collection)
        if isinstance(items, list):
            graph[collection] = _list_to_dict(items)
    return body


def normalize_body(body: dict[str, Any]) -> dict[str, Any]:
    """Normalize a version body so raw API exports work with PUT/PATCH.

    Handles two things:
    1. Converts array-format graphs (from API GET responses) to dict-keyed
       format expected by PUT/PATCH.
    2. Strips server-only fields that the API rejects on write.
    """
    # Strip server-only top-level fields
    for field in _SERVER_ONLY_FIELDS:
        body.pop(field, None)

    graph = body.get("graph")
    if not graph:
        return body

    # Strip server-only fields from graph itself
    for field in ("created_at", "updated_at", "meta", "id"):
        graph.pop(field, None)

    # Convert arrays to dicts if needed
    for collection in ("nodes", "edges", "node_groups"):
        items = graph.get(collection)
        if isinstance(items, list):
            graph[collection] = _list_to_dict(items)

    return body


def _ensure_graph_ids(body: dict[str, Any]) -> None:
    """Auto-populate ``id`` fields on nodes, edges, and inside node meta.

    - Nodes/edges get their ``id`` set from the dict key.
    - All nested ``id``, ``id_left``, ``id_right`` fields inside node meta
      get a fresh UUID if missing or empty.

    This lets callers omit ALL id fields when constructing graphs.
    """
    graph = body.get("graph")
    if not graph:
        return
    for collection in ("nodes", "edges"):
        items = graph.get(collection)
        if not isinstance(items, dict):
            continue
        for key, value in items.items():
            if isinstance(value, dict):
                if "id" not in value:
                    value["id"] = key
                # Auto-fill ids inside meta
                meta = value.get("meta")
                if meta is not None:
                    # Remap short field-ID keys in decision_table cases/fallback
                    # before _fill_ids_recursive converts them to UUIDs.
                    if value.get("type") == "decision_table" and isinstance(meta, dict):
                        _fix_decision_table_keys(meta)
                    _fill_ids_recursive(meta)


def patch_version(
    client: TktlClient,
    version_id: str,
    body: dict[str, Any],
    if_match: str | None = None,
    session: str | None = None,
) -> dict[str, Any]:
    """Apply a merge patch to a flow version.

    PATCH /api/v1/flow_versions/{id}

    Callers that pass raw API exports should call ``normalize_body(body)``
    first — this function does not strip server-only fields because some
    PATCH operations legitimately set fields like ``status``.
    """
    _ensure_graph_ids(body)

    headers: dict[str, str] = {}
    if if_match:
        headers["if-match"] = if_match
    if session:
        headers["session"] = session

    resp = client.patch(
        f"/api/v1/flow_versions/{version_id}",
        json=body,
        headers=headers or None,
    )

    if resp.status_code == 200:
        return resp.json()
    if resp.status_code == 404:
        raise NotFoundError(f"Version '{version_id}' not found")
    if resp.status_code == 412:
        raise ConflictError("ETag mismatch: version was modified since your last read")
    if resp.status_code == 409:
        detail = resp.json().get("detail", "Lock conflict")
        raise ConflictError(detail)
    if resp.status_code == 422:
        try:
            body = resp.json()
            raw = body.get("detail", resp.text[:500])
            detail = raw if isinstance(raw, str) else str(raw)
        except Exception:
            detail = resp.text[:500]
        raise ConflictError(f"[validation] {detail}")
    resp.raise_for_status()
    return {}  # pragma: no cover


def put_version(
    client: TktlClient,
    version_id: str,
    body: dict[str, Any],
    by_etag: str,
) -> dict[str, Any]:
    """Replace a flow version entirely.

    PUT /api/v2/flow_versions/{id}?by_etag=...
    """
    normalize_body(body)
    _ensure_graph_ids(body)

    resp = client.put(
        f"/api/v2/flow_versions/{version_id}",
        json=body,
        params={"by_etag": by_etag},
    )

    if resp.status_code == 200:
        return resp.json()
    if resp.status_code == 404:
        raise NotFoundError(f"Version '{version_id}' not found")
    if resp.status_code == 412:
        raise ConflictError("ETag mismatch: version was modified since your last read")
    resp.raise_for_status()
    return {}  # pragma: no cover


def create_version(
    client: TktlClient,
    flow_id: str,
    name: str,
    status: str = "DRAFT",
) -> dict[str, Any]:
    """Create a new flow version.

    POST /api/v1/flow_versions
    """
    body = {"flow_id": flow_id, "name": name, "status": status}
    resp = client.post("/api/v1/flow_versions", json=body)

    if resp.status_code in (200, 201):
        return resp.json()
    if resp.status_code == 404:
        raise NotFoundError(f"Flow '{flow_id}' not found")
    if resp.status_code == 409:
        raise ConflictError(f"Version '{name}' already exists")
    resp.raise_for_status()
    return {}  # pragma: no cover


def duplicate_version(
    client: TktlClient,
    version_id: str,
    name: str,
    *,
    created_by_id: str | None = None,
) -> dict[str, Any]:
    """Duplicate an existing flow version.

    POST /api/v1/flow_versions/{id}/duplicate

    The ``meta.created_by_id`` field must be set to avoid null meta,
    which causes the Taktile UI to crash.
    """
    body: dict[str, Any] = {"name": name}
    if created_by_id:
        body["meta"] = {"created_by_id": created_by_id}
    resp = client.post(
        f"/api/v1/flow_versions/{version_id}/duplicate",
        json=body,
    )

    if resp.status_code in (200, 201):
        return resp.json()
    if resp.status_code == 404:
        raise NotFoundError(f"Version '{version_id}' not found")
    resp.raise_for_status()
    return {}  # pragma: no cover


def delete_version(client: TktlClient, version_id: str) -> None:
    """Delete a flow version.

    DELETE /api/v1/flow_versions/{id}
    """
    resp = client.delete(f"/api/v1/flow_versions/{version_id}")

    if resp.status_code == 204:
        return
    if resp.status_code == 404:
        raise NotFoundError(f"Version '{version_id}' not found")
    resp.raise_for_status()


def get_changes(
    client: TktlClient,
    version_id: str,
    after_etag: str | None = None,
    limit: int = 100,
) -> list[dict[str, Any]]:
    """Get change history for a flow version.

    GET /api/v2/flow_versions/{id}/changes
    """
    params: dict[str, Any] = {"limit": limit}
    if after_etag:
        params["after_etag"] = after_etag

    resp = client.get(f"/api/v2/flow_versions/{version_id}/changes", params=params)

    if resp.status_code == 200:
        return resp.json()
    if resp.status_code == 404:
        raise NotFoundError(f"Version '{version_id}' not found")
    resp.raise_for_status()
    return []  # pragma: no cover
