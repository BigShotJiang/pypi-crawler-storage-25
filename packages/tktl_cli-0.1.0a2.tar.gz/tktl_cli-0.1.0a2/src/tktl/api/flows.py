"""Flow API functions."""

from __future__ import annotations

from typing import Any

from tktl.api.client import TktlClient
from tktl.models.errors import NotFoundError


def list_flows(client: TktlClient, workspace_id: str) -> list[dict[str, Any]]:
    """List all flows in a workspace.

    GET /api/v1/flows?workspace_id=...
    """
    resp = client.get("/api/v1/flows", params={"workspace_id": workspace_id})
    if resp.status_code == 200:
        return resp.json()
    resp.raise_for_status()
    return []  # pragma: no cover


def create_flow(
    client: TktlClient,
    workspace_id: str,
    slug: str,
    name: str,
    *,
    folder_id: str | None = None,
    initial_version_name: str = "v1",
    schema_in: dict[str, Any] | None = None,
    schema_out: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Create a new flow with an initial draft version.

    POST /api/v1/flows

    Returns the created flow dict. If the response includes a version ETag
    (via ``versions[0].etag``) it is included so callers can PATCH schemas
    without an extra GET round-trip.
    """
    payload: dict[str, Any] = {
        "name": name,
        "slug": slug,
        "workspace_id": workspace_id,
        "initial_version_name": initial_version_name,
    }
    if folder_id is not None:
        payload["flow_folder_id"] = folder_id
    if schema_in is not None:
        payload["initial_version_meta"] = payload.get("initial_version_meta") or {}
        payload["initial_version_meta"]["input_schema"] = schema_in
    if schema_out is not None:
        payload["initial_version_meta"] = payload.get("initial_version_meta") or {}
        payload["initial_version_meta"]["output_schema"] = schema_out

    resp = client.post("/api/v1/flows", json=payload)
    if resp.status_code == 200:
        return resp.json()
    resp.raise_for_status()
    return {}  # pragma: no cover


def get_flow_by_slug(client: TktlClient, workspace_id: str, slug: str) -> dict[str, Any]:
    """Get a flow by workspace ID and slug.

    GET /api/v1/flows/workspace_id/{ws}/slug/{slug}
    """
    resp = client.get(f"/api/v1/flows/workspace_id/{workspace_id}/slug/{slug}")
    if resp.status_code == 200:
        return resp.json()
    if resp.status_code == 404:
        raise NotFoundError(f"Flow with slug '{slug}' not found")
    resp.raise_for_status()
    return {}  # pragma: no cover
