"""Dataset API functions.

Provides two sets of functions:

1. **Legacy download functions** (raw httpx, used by batch.py):
   ``get_dataset_info``, ``create_download_job``, ``get_job_status``, ``download_s3_file``

2. **Dataset CRUD functions** (TktlClient-based, new):
   ``list_datasets_api``, ``create_dataset_api``, ``get_dataset_api``, ``patch_dataset_api``,
   ``delete_dataset_api``, ``append_rows_api``, ``update_row_api``, ``delete_row_api``,
   ``upsert_columns_api``, ``delete_columns_api``, ``fill_column_api``,
   ``create_file_upload_api``, ``get_file_upload_api``, ``download_dataset_file_api``
"""

from __future__ import annotations

from typing import Any

import httpx

from tktl.models.errors import NetworkError, NotFoundError

# ---------------------------------------------------------------------------
# Datasets API base path (workspace-scoped)
# ---------------------------------------------------------------------------
_DATASETS_BASE = "/datasets/api/v1"


# ===========================================================================
# Legacy download functions (raw httpx — used by batch.py)
# ===========================================================================


def get_dataset_info(
    api_key: str,
    base_url: str,
    dataset_id: str,
    *,
    etag: str | None = None,
) -> tuple[dict[str, Any] | None, str]:
    """Get lightweight dataset info. Supports ETag-based conditional requests.

    Returns ``(info_dict, etag)`` on 200, or ``(None, cached_etag)`` on 304.
    """
    url = f"{base_url}/datasets/api/v1/datasets/info/{dataset_id}"
    headers: dict[str, str] = {"X-Api-Key": api_key}
    if etag is not None:
        headers["If-None-Match"] = etag

    try:
        resp = httpx.get(url, headers=headers, timeout=15.0)
    except httpx.HTTPError as exc:
        raise NetworkError(f"Failed to get dataset info: {exc}") from exc

    if resp.status_code == 304:
        return None, etag or ""
    if resp.status_code == 404:
        raise NotFoundError(f"Dataset '{dataset_id}' not found")
    resp.raise_for_status()

    data = resp.json()
    new_etag = data.get("etag", "")
    return data, new_etag


def create_download_job(
    api_key: str,
    base_url: str,
    flow_id: str,
    dataset_id: str,
    *,
    fmt: str = "json",
) -> dict[str, Any]:
    """Create a dataset download job. Returns the job dict."""
    url = f"{base_url}/dataset_jobs/api/v1/dataset_jobs"
    body = {
        "flow_id": flow_id,
        "type": "download",
        "request": {
            "dataset_id": dataset_id,
            "format": fmt,
        },
    }

    try:
        resp = httpx.post(
            url,
            json=body,
            headers={"X-Api-Key": api_key},
            timeout=15.0,
        )
    except httpx.HTTPError as exc:
        raise NetworkError(f"Failed to create download job: {exc}") from exc

    if resp.status_code == 404:
        raise NotFoundError(f"Dataset '{dataset_id}' not found")
    resp.raise_for_status()
    return resp.json()


def get_job_status(
    api_key: str,
    base_url: str,
    job_id: str,
) -> dict[str, Any]:
    """Poll the status of a dataset job."""
    url = f"{base_url}/dataset_jobs/api/v1/dataset_jobs/{job_id}"

    try:
        resp = httpx.get(url, headers={"X-Api-Key": api_key}, timeout=15.0)
    except httpx.HTTPError as exc:
        raise NetworkError(f"Failed to get job status: {exc}") from exc

    if resp.status_code == 404:
        raise NotFoundError(f"Dataset job '{job_id}' not found")
    resp.raise_for_status()
    return resp.json()


def download_s3_file(url: str) -> bytes:
    """Download a file from a pre-signed S3 URL. No auth needed."""
    try:
        resp = httpx.get(url, timeout=120.0, follow_redirects=True)
    except httpx.HTTPError as exc:
        raise NetworkError(f"Failed to download dataset file: {exc}") from exc

    resp.raise_for_status()
    return resp.content


# ===========================================================================
# Dataset CRUD functions
#
# These use raw httpx with api_key + base_url (workspace base URL), matching
# the legacy download functions above. The datasets API is workspace-scoped
# and lives on the workspace base URL, NOT the Flow API URL.
# ===========================================================================


def _ds_get(api_key: str, base_url: str, path: str, **kwargs: Any) -> httpx.Response:
    url = f"{base_url}{_DATASETS_BASE}{path}"
    headers = {"X-Api-Key": api_key}
    if "headers" in kwargs:
        headers.update(kwargs.pop("headers"))
    try:
        return httpx.get(url, headers=headers, timeout=30.0, **kwargs)
    except httpx.HTTPError as exc:
        raise NetworkError(f"Dataset API request failed: {exc}") from exc


def _ds_post(api_key: str, base_url: str, path: str, **kwargs: Any) -> httpx.Response:
    url = f"{base_url}{_DATASETS_BASE}{path}"
    try:
        return httpx.post(url, headers={"X-Api-Key": api_key}, timeout=30.0, **kwargs)
    except httpx.HTTPError as exc:
        raise NetworkError(f"Dataset API request failed: {exc}") from exc


def _ds_patch(api_key: str, base_url: str, path: str, **kwargs: Any) -> httpx.Response:
    url = f"{base_url}{_DATASETS_BASE}{path}"
    headers = {"X-Api-Key": api_key}
    if "headers" in kwargs:
        headers.update(kwargs.pop("headers"))
    try:
        return httpx.patch(url, headers=headers, timeout=30.0, **kwargs)
    except httpx.HTTPError as exc:
        raise NetworkError(f"Dataset API request failed: {exc}") from exc


def _ds_put(api_key: str, base_url: str, path: str, **kwargs: Any) -> httpx.Response:
    url = f"{base_url}{_DATASETS_BASE}{path}"
    try:
        return httpx.put(url, headers={"X-Api-Key": api_key}, timeout=30.0, **kwargs)
    except httpx.HTTPError as exc:
        raise NetworkError(f"Dataset API request failed: {exc}") from exc


def _ds_delete(api_key: str, base_url: str, path: str, **kwargs: Any) -> httpx.Response:
    url = f"{base_url}{_DATASETS_BASE}{path}"
    try:
        return httpx.request("DELETE", url, headers={"X-Api-Key": api_key}, timeout=30.0, **kwargs)
    except httpx.HTTPError as exc:
        raise NetworkError(f"Dataset API request failed: {exc}") from exc


def list_datasets_api(api_key: str, base_url: str, flow_id: str) -> list[dict[str, Any]]:
    """List all datasets for a flow.

    GET {base_url}/datasets/api/v1/datasets?flow_id=...
    """
    resp = _ds_get(api_key, base_url, "/datasets", params={"flow_id": flow_id})
    if resp.status_code == 200:
        return resp.json()
    resp.raise_for_status()
    return []  # pragma: no cover


def create_dataset_api(api_key: str, base_url: str, body: dict[str, Any]) -> dict[str, Any]:
    """Create a dataset from scratch.

    POST {base_url}/datasets/api/v1/datasets
    """
    resp = _ds_post(api_key, base_url, "/datasets", json=body)
    if resp.status_code == 200:
        return resp.json()
    resp.raise_for_status()
    return {}  # pragma: no cover


def get_dataset_api(
    api_key: str,
    base_url: str,
    dataset_id: str,
    *,
    from_: int = 0,
    size: int = 50,
) -> dict[str, Any]:
    """Get a dataset with paginated rows.

    GET {base_url}/datasets/api/v1/datasets/{id}?from_=N&size=N
    """
    resp = _ds_get(api_key, base_url, f"/datasets/{dataset_id}", params={"from_": from_, "size": size})
    if resp.status_code == 200:
        return resp.json()
    if resp.status_code == 404:
        raise NotFoundError(f"Dataset '{dataset_id}' not found")
    resp.raise_for_status()
    return {}  # pragma: no cover


def patch_dataset_api(
    api_key: str,
    base_url: str,
    dataset_id: str,
    body: dict[str, Any],
    *,
    etag: str | None = None,
) -> dict[str, Any]:
    """Update dataset metadata (name, columns).

    PATCH {base_url}/datasets/api/v1/datasets/{id}
    """
    extra_headers: dict[str, str] = {}
    if etag is not None:
        extra_headers["If-Match"] = etag
    resp = _ds_patch(api_key, base_url, f"/datasets/{dataset_id}", json=body, headers=extra_headers)
    if resp.status_code == 200:
        return resp.json()
    if resp.status_code == 404:
        raise NotFoundError(f"Dataset '{dataset_id}' not found")
    resp.raise_for_status()
    return {}  # pragma: no cover


def delete_dataset_api(api_key: str, base_url: str, dataset_id: str) -> None:
    """Delete a dataset.

    DELETE {base_url}/datasets/api/v1/datasets/{id}
    """
    resp = _ds_delete(api_key, base_url, f"/datasets/{dataset_id}")
    if resp.status_code == 404:
        raise NotFoundError(f"Dataset '{dataset_id}' not found")
    resp.raise_for_status()


# --- Rows ---


def append_rows_api(
    api_key: str,
    base_url: str,
    dataset_id: str,
    body: dict[str, Any],
) -> list[dict[str, Any]]:
    """Append rows to a dataset.

    POST {base_url}/datasets/api/v1/datasets/{id}/rows
    """
    resp = _ds_post(api_key, base_url, f"/datasets/{dataset_id}/rows", json=body)
    if resp.status_code == 200:
        return resp.json()
    if resp.status_code == 404:
        raise NotFoundError(f"Dataset '{dataset_id}' not found")
    resp.raise_for_status()
    return []  # pragma: no cover


def update_row_api(
    api_key: str,
    base_url: str,
    dataset_id: str,
    row_id: str,
    body: dict[str, Any],
) -> dict[str, Any]:
    """Update a single row.

    PATCH {base_url}/datasets/api/v1/datasets/{id}/rows/{row_id}
    """
    resp = _ds_patch(api_key, base_url, f"/datasets/{dataset_id}/rows/{row_id}", json=body)
    if resp.status_code == 200:
        return resp.json()
    if resp.status_code == 404:
        raise NotFoundError(f"Dataset or row not found: {dataset_id}/{row_id}")
    resp.raise_for_status()
    return {}  # pragma: no cover


def delete_row_api(api_key: str, base_url: str, dataset_id: str, row_id: str) -> None:
    """Delete a single row.

    DELETE {base_url}/datasets/api/v1/datasets/{id}/rows/{row_id}
    """
    resp = _ds_delete(api_key, base_url, f"/datasets/{dataset_id}/rows/{row_id}")
    if resp.status_code == 404:
        raise NotFoundError(f"Dataset or row not found: {dataset_id}/{row_id}")
    resp.raise_for_status()


# --- Columns ---


def upsert_columns_api(
    api_key: str,
    base_url: str,
    dataset_id: str,
    body: list[dict[str, Any]],
) -> dict[str, Any]:
    """Add or rename columns (batch).

    PUT {base_url}/datasets/api/v1/datasets/{id}/columns
    """
    resp = _ds_put(api_key, base_url, f"/datasets/{dataset_id}/columns", json=body)
    if resp.status_code == 200:
        return resp.json()
    if resp.status_code == 404:
        raise NotFoundError(f"Dataset '{dataset_id}' not found")
    resp.raise_for_status()
    return {}  # pragma: no cover


def delete_columns_api(
    api_key: str,
    base_url: str,
    dataset_id: str,
    body: list[dict[str, Any]],
) -> dict[str, Any]:
    """Delete columns (batch).

    DELETE {base_url}/datasets/api/v1/datasets/{id}/columns
    """
    resp = _ds_delete(api_key, base_url, f"/datasets/{dataset_id}/columns", json=body)
    if resp.status_code == 200:
        return resp.json()
    if resp.status_code == 404:
        raise NotFoundError(f"Dataset '{dataset_id}' not found")
    resp.raise_for_status()
    return {}  # pragma: no cover


def fill_column_api(
    api_key: str,
    base_url: str,
    dataset_id: str,
    group: str,
    name: str,
    body: dict[str, Any],
) -> dict[str, Any]:
    """Fill a column with a value.

    PATCH {base_url}/datasets/api/v1/datasets/{id}/columns/{group}/{name}
    """
    resp = _ds_patch(api_key, base_url, f"/datasets/{dataset_id}/columns/{group}/{name}", json=body)
    if resp.status_code == 200:
        return resp.json()
    if resp.status_code == 404:
        raise NotFoundError(f"Dataset or column not found: {dataset_id}/{group}/{name}")
    resp.raise_for_status()
    return {}  # pragma: no cover


# --- File Upload ---


def create_file_upload_api(api_key: str, base_url: str, body: dict[str, Any]) -> dict[str, Any]:
    """Create a dataset file upload (returns presigned S3 URL).

    POST {base_url}/datasets/api/v1/dataset_file_uploads
    """
    resp = _ds_post(api_key, base_url, "/dataset_file_uploads", json=body)
    if resp.status_code == 200:
        return resp.json()
    resp.raise_for_status()
    return {}  # pragma: no cover


def get_file_upload_api(api_key: str, base_url: str, upload_id: str) -> dict[str, Any]:
    """Get the status of a file upload.

    GET {base_url}/datasets/api/v1/dataset_file_uploads/{id}
    """
    resp = _ds_get(api_key, base_url, f"/dataset_file_uploads/{upload_id}")
    if resp.status_code == 200:
        return resp.json()
    resp.raise_for_status()
    return {}  # pragma: no cover


# --- Download ---


def download_dataset_file_api(
    api_key: str,
    base_url: str,
    dataset_id: str,
    fmt: str = "csv",
) -> bytes:
    """Download a dataset as a file.

    GET {base_url}/datasets/api/v1/datasets/{id}/file?format={csv|json}
    """
    resp = _ds_get(api_key, base_url, f"/datasets/{dataset_id}/file", params={"format": fmt})
    if resp.status_code == 200:
        return resp.content
    if resp.status_code == 404:
        raise NotFoundError(f"Dataset '{dataset_id}' not found")
    resp.raise_for_status()
    return b""  # pragma: no cover


# ---------------------------------------------------------------------------
# Legacy file upload functions (used by main's upload_dataset op)
# ---------------------------------------------------------------------------


def create_file_upload(
    api_key: str,
    base_url: str,
    flow_id: str,
    file_name: str,
    *,
    purpose: str = "test_run",
) -> dict[str, Any]:
    """Create a dataset file upload request. Returns presigned S3 URL and fields.

    POST {base_url}/datasets/api/v1/dataset_file_uploads
    """
    url = f"{base_url}/datasets/api/v1/dataset_file_uploads"
    body = {
        "flow_id": flow_id,
        "file_name": file_name,
        "purpose": purpose,
    }
    try:
        resp = httpx.post(url, json=body, headers={"X-Api-Key": api_key}, timeout=15.0)
    except httpx.HTTPError as exc:
        raise NetworkError(f"Failed to create file upload: {exc}") from exc

    resp.raise_for_status()
    return resp.json()


def get_file_upload_status(
    api_key: str,
    base_url: str,
    upload_id: str,
) -> dict[str, Any]:
    """Poll the status of a dataset file upload.

    GET {base_url}/datasets/api/v1/dataset_file_uploads/{upload_id}
    """
    url = f"{base_url}/datasets/api/v1/dataset_file_uploads/{upload_id}"
    try:
        resp = httpx.get(url, headers={"X-Api-Key": api_key}, timeout=15.0)
    except httpx.HTTPError as exc:
        raise NetworkError(f"Failed to get upload status: {exc}") from exc

    if resp.status_code == 404:
        raise NotFoundError(f"Upload '{upload_id}' not found")
    resp.raise_for_status()
    return resp.json()


def upload_to_s3(
    presigned_url: str,
    presigned_fields: dict[str, str],
    file_content: bytes,
    file_name: str,
    content_type: str = "text/csv",
) -> None:
    """Upload a file to S3 using the presigned URL and fields."""
    try:
        resp = httpx.post(
            presigned_url,
            data=presigned_fields,
            files={"file": (file_name, file_content, content_type)},
            timeout=60.0,
        )
    except httpx.HTTPError as exc:
        raise NetworkError(f"Failed to upload to S3: {exc}") from exc

    if resp.status_code not in (200, 201, 204):
        raise NetworkError(f"S3 upload failed with status {resp.status_code}")
