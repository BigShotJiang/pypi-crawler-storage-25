"""Workspace connections API.

The Connect API is per-workspace and lives on the workspace base URL:
GET   {base_url}/connect/api/v1/connections                  — list all connections
POST  {base_url}/connect/api/v1/connections                  — create a connection
POST  {base_url}/connect/api/v1/connections/{id}/resources   — create a resource config
PATCH {base_url}/connect/api/v1/connections/{id}/secrets      — update secrets
"""

from __future__ import annotations

from typing import Any

import httpx

from tktl.models.errors import NetworkError


def list_connections(api_key: str, base_url: str) -> list[dict[str, Any]]:
    """List all connections in the workspace.

    GET {base_url}/connect/api/v1/connections
    """
    url = f"{base_url}/connect/api/v1/connections"

    try:
        resp = httpx.get(url, headers={"X-Api-Key": api_key}, timeout=15.0)
    except httpx.HTTPError as exc:
        raise NetworkError(f"Failed to list connections: {exc}") from exc

    if resp.status_code == 200:
        return resp.json()
    raise NetworkError(f"Failed to list connections: HTTP {resp.status_code}")


def create_connection(api_key: str, base_url: str, body: dict[str, Any]) -> dict[str, Any]:
    """Create a new connection.

    POST {base_url}/connect/api/v1/connections
    """
    url = f"{base_url}/connect/api/v1/connections"

    try:
        resp = httpx.post(url, json=body, headers={"X-Api-Key": api_key}, timeout=15.0)
    except httpx.HTTPError as exc:
        raise NetworkError(f"Failed to create connection: {exc}") from exc

    if resp.status_code in (200, 201):
        return resp.json()
    raise NetworkError(f"Failed to create connection: HTTP {resp.status_code}")


def create_resource_config(api_key: str, base_url: str, connection_id: str, body: dict[str, Any]) -> dict[str, Any]:
    """Create a resource config on a connection.

    POST {base_url}/connect/api/v1/connections/{connection_id}/resources
    """
    url = f"{base_url}/connect/api/v1/connections/{connection_id}/resources"

    try:
        resp = httpx.post(url, json=body, headers={"X-Api-Key": api_key}, timeout=15.0)
    except httpx.HTTPError as exc:
        raise NetworkError(f"Failed to create resource config: {exc}") from exc

    if resp.status_code in (200, 201):
        return resp.json()
    raise NetworkError(f"Failed to create resource config: HTTP {resp.status_code}")


def update_secrets(
    api_key: str, base_url: str, connection_id: str, secrets: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    """Update secrets on a connection.

    PATCH {base_url}/connect/api/v1/connections/{connection_id}/secrets
    """
    url = f"{base_url}/connect/api/v1/connections/{connection_id}/secrets"

    try:
        resp = httpx.patch(url, json=secrets, headers={"X-Api-Key": api_key}, timeout=15.0)
    except httpx.HTTPError as exc:
        raise NetworkError(f"Failed to update secrets: {exc}") from exc

    if resp.status_code == 200:
        return resp.json()
    raise NetworkError(f"Failed to update secrets: HTTP {resp.status_code}")
