"""Comment API functions.

Comments are per-flow-version and can be attached to nodes or the version itself.
Create uses PUT /api/v1/comments/{comment_id} (client-generated ID).
"""

from __future__ import annotations

import uuid
from typing import Any

from tktl.api.client import TktlClient
from tktl.models.errors import NotFoundError


def list_comments(
    client: TktlClient,
    flow_version_id: str,
    *,
    resource_type: str | None = None,
    resource_id: str | None = None,
) -> list[dict[str, Any]]:
    """List comments for a flow version.

    GET /api/v1/comments?flow_version_id=...
    """
    params: dict[str, str] = {"flow_version_id": flow_version_id}
    if resource_type is not None:
        params["resource_type"] = resource_type
    if resource_id is not None:
        params["resource_id"] = resource_id

    resp = client.get("/api/v1/comments", params=params)
    if resp.status_code == 200:
        return resp.json()
    resp.raise_for_status()
    return []  # pragma: no cover


def create_comment(
    client: TktlClient,
    flow_version_id: str,
    content: str,
    *,
    resource_type: str | None = None,
    resource_id: str | None = None,
) -> dict[str, Any]:
    """Create a comment on a flow version or node.

    PUT /api/v1/comments/{comment_id}  (client-generated UUID)
    """
    comment_id = str(uuid.uuid4())
    body: dict[str, Any] = {
        "content": content,
        "flow_version": flow_version_id,
    }
    if resource_type is not None:
        body["resource_type"] = resource_type
    if resource_id is not None:
        body["resource_id"] = resource_id

    resp = client.put(f"/api/v1/comments/{comment_id}", json=body)
    if resp.status_code == 200:
        return resp.json()
    if resp.status_code == 404:
        raise NotFoundError(f"Flow version '{flow_version_id}' not found")
    resp.raise_for_status()
    return {}  # pragma: no cover


def delete_comment(
    client: TktlClient,
    comment_id: str,
) -> None:
    """Delete a comment.

    DELETE /api/v1/comments/{comment_id}
    """
    resp = client.delete(f"/api/v1/comments/{comment_id}")
    if resp.status_code == 404:
        raise NotFoundError(f"Comment '{comment_id}' not found")
    resp.raise_for_status()


def get_comment_summary(
    client: TktlClient,
    flow_version_id: str,
) -> list[dict[str, Any]]:
    """Get per-node comment counts for a flow version.

    GET /api/v1/comments/summary/{flow_version_id}
    """
    resp = client.get(f"/api/v1/comments/summary/{flow_version_id}")
    if resp.status_code == 200:
        return resp.json()
    if resp.status_code == 404:
        raise NotFoundError(f"Flow version '{flow_version_id}' not found")
    resp.raise_for_status()
    return []  # pragma: no cover
