"""Thin HTTP client wrapping httpx with auth, base URL, and retry logic."""

from __future__ import annotations

import time
from pathlib import Path
from typing import Any

import httpx

from tktl.config import Config, Credentials, _DEFAULT_CONFIG_DIR
from tktl.models.errors import AuthError, NetworkError

DEFAULT_BASE_URL = "https://flow-api.taktile.com"

# Retry settings for network errors
_MAX_RETRIES = 3
_BACKOFF_DELAYS = [1, 2, 4]  # seconds


class TktlClient:
    """Synchronous HTTP client for the Taktile Flow API.

    Reads config and credentials from disk (or accepts explicit overrides).
    Attaches ``X-Api-Key`` header to every request.
    Retries network errors with exponential backoff.
    """

    def __init__(
        self,
        config_dir: Path = _DEFAULT_CONFIG_DIR,
        *,
        base_url: str | None = None,
        api_key: str | None = None,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        # Load config from disk
        config = Config(config_dir)
        config.load()

        # Determine base URL
        if base_url is not None:
            self._base_url = base_url
        else:
            self._base_url = config.get("flow_api_url") or DEFAULT_BASE_URL

        # Determine API key
        if api_key is not None:
            self._api_key = api_key
            self._user_id: str | None = None
        else:
            creds = Credentials(config_dir)
            creds.load()
            if not creds.api_key:
                raise AuthError("No API key found. Run `tktl auth login` to authenticate.")
            self._api_key = creds.api_key
            self._user_id = creds.user_id

        self._config = config

        # Build the httpx client
        self._http = httpx.Client(
            base_url=self._base_url,
            headers={"X-Api-Key": self._api_key},
            transport=transport,
        )

    @property
    def base_url(self) -> str:
        return self._base_url

    # ---- HTTP verbs ----

    def get(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        return self._request("GET", path, params=params, headers=headers)

    def post(
        self,
        path: str,
        *,
        json: Any = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        return self._request("POST", path, json=json, params=params, headers=headers)

    def patch(
        self,
        path: str,
        *,
        json: Any = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        return self._request("PATCH", path, json=json, params=params, headers=headers)

    def put(
        self,
        path: str,
        *,
        json: Any = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        return self._request("PUT", path, json=json, params=params, headers=headers)

    def delete(
        self,
        path: str,
        *,
        json: Any = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        return self._request("DELETE", path, json=json, params=params, headers=headers)

    # ---- internal ----

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        """Send an HTTP request with retry logic for network errors."""
        last_exc: Exception | None = None

        for attempt in range(_MAX_RETRIES + 1):
            try:
                return self._http.request(
                    method,
                    path,
                    json=json,
                    params=params,
                    headers=headers,
                )
            except httpx.HTTPError as exc:
                last_exc = exc
                if attempt < _MAX_RETRIES:
                    time.sleep(_BACKOFF_DELAYS[attempt])
                    continue
                raise NetworkError(str(exc)) from exc

        # Should not reach here, but satisfy type checker
        raise NetworkError(str(last_exc))  # pragma: no cover
