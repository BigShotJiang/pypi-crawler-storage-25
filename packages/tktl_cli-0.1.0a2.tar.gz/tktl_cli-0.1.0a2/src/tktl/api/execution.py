"""Flow execution via the workspace Decide API.

The execution endpoint is per-workspace and dynamically resolved:
1. GET /api/v1/workspaces/{workspace_id} on Flow API → base_url
2. POST {base_url}/run/api/v1/flows/{slug}/{env}/decide
"""

from __future__ import annotations

import time
from typing import Any

import httpx

from tktl.api.client import TktlClient
from tktl.models.errors import NetworkError, NotFoundError, TktlError

# Cache workspace base_url to avoid repeated lookups
_workspace_base_url_cache: dict[str, str] = {}


def _resolve_workspace_base_url(client: TktlClient, workspace_id: str) -> str:
    """Resolve the workspace's Decide API base URL via the Flow API."""
    if workspace_id in _workspace_base_url_cache:
        return _workspace_base_url_cache[workspace_id]

    resp = client.get(f"/api/v1/workspaces/{workspace_id}", params={"include_settings": "false"})
    if resp.status_code == 404:
        raise NotFoundError(f"Workspace '{workspace_id}' not found")
    resp.raise_for_status()

    data = resp.json()
    base_url = data.get("base_url", "")
    if not base_url:
        raise NotFoundError(f"Workspace '{workspace_id}' has no base_url configured")

    # Ensure https:// prefix
    if not base_url.startswith("http"):
        base_url = f"https://{base_url}"

    _workspace_base_url_cache[workspace_id] = base_url
    return base_url


def _poll_decision(
    base_url: str,
    flow_slug: str,
    env: str,
    decision_id: str,
    api_key: str,
    *,
    max_wait: float = 60.0,
    interval: float = 2.0,
) -> dict[str, Any]:
    """Poll GET /run/api/v1/flows/{slug}/[{env}/]decide/{id} until ready."""
    if env in ("live", "production"):
        url = f"{base_url}/run/api/v1/flows/{flow_slug}/decide/{decision_id}"
    else:
        url = f"{base_url}/run/api/v1/flows/{flow_slug}/{env}/decide/{decision_id}"
    deadline = time.monotonic() + max_wait

    while True:
        try:
            resp = httpx.get(url, headers={"X-Api-Key": api_key}, timeout=10.0)
        except httpx.HTTPError as exc:
            raise NetworkError(f"Failed to poll decision: {exc}") from exc

        if resp.status_code in (200, 424):
            return resp.json()
        elif resp.status_code != 404:
            raise TktlError(f"Unexpected status {resp.status_code} polling decision {decision_id}: {resp.text[:300]}")

        if time.monotonic() >= deadline:
            raise TktlError(f"Decision {decision_id} not ready after {max_wait}s")
        time.sleep(interval)


def run_flow(
    client: TktlClient,
    workspace_id: str,
    flow_slug: str,
    input_data: dict[str, Any],
    *,
    version: str | None = None,
    env: str = "sandbox",
    mock_data: dict[str, Any] | None = None,
    execution_mode: str = "sync",
    poll_timeout: float = 60.0,
) -> dict[str, Any]:
    """Execute a flow via the workspace Decide API.

    Steps:
    1. Resolve workspace base_url via Flow API
    2. POST {base_url}/run/api/v1/flows/{slug}/{env}/decide
    3. For async mode, poll GET /decisions/{decision_id} until complete
    4. Return the DecideResponse

    Parameters
    ----------
    client : TktlClient
        The Flow API client (used to resolve workspace base_url).
    workspace_id : str
        Workspace UUID.
    flow_slug : str
        Flow slug.
    input_data : dict
        The ``data`` portion of the decide request (matches flow input_schema).
    version : str, optional
        Version name to execute. If None, the published version is used.
    env : str
        Environment: "sandbox" or "live". Defaults to "sandbox".
    mock_data : dict, optional
        Mock data for connection/subflow nodes in sandbox mode. Keys are node
        IDs, values are the mock response objects those nodes should return.
    execution_mode : str
        Execution mode: "sync" or "async". Defaults to "sync".
    """
    base_url = _resolve_workspace_base_url(client, workspace_id)
    decide_url = f"{base_url}/run/api/v1/flows/{flow_slug}/{env}/decide"

    body: dict[str, Any] = {
        "data": input_data,
        "metadata": {},
        "control": {"execution_mode": execution_mode},
    }
    if mock_data is not None:
        body["mock_data"] = mock_data
    if version is not None:
        body["metadata"]["version"] = version

    # Use a separate httpx client for the decide endpoint (different base URL)
    try:
        resp = httpx.post(
            decide_url,
            json=body,
            headers={"X-Api-Key": client._api_key},
            timeout=30.0,
        )
    except httpx.HTTPError as exc:
        raise NetworkError(f"Failed to execute flow: {exc}") from exc

    # The Decide API returns JSON error bodies for runtime/compile failures
    # (424 Failed Dependency) and input validation errors (422).
    # Surface the JSON response instead of crashing on these.
    try:
        data = resp.json()
    except Exception:
        data = None

    if data is not None and resp.status_code in (200, 202, 422, 424):
        # For async mode, poll until the decision completes
        if resp.status_code == 202 and data.get("status") == "pending":
            decision_id = data.get("metadata", {}).get("decision_id")
            if decision_id:
                return _poll_decision(
                    base_url,
                    flow_slug,
                    env,
                    decision_id,
                    client._api_key,
                    max_wait=poll_timeout,
                )
        return data
    if resp.status_code == 404:
        raise NotFoundError(f"Flow '{flow_slug}' not found on decide endpoint")

    # Surface the execution error detail from the response body rather than a
    # raw HTTP exception.
    try:
        body = resp.json()
        detail = body.get("detail") or body.get("msg", "")
        if isinstance(detail, dict):
            exc_type = detail.get("exc_type", "")
            msg = detail.get("msg", "unknown error")
            node_id = detail.get("node_id", "")
            prefix = f"[{exc_type}] " if exc_type else ""
            suffix = f" (node: {node_id})" if node_id else ""
            err = f"{prefix}{msg}{suffix}"
        elif isinstance(detail, str) and detail:
            err = detail
        else:
            err = f"HTTP {resp.status_code}"
    except Exception:
        err = resp.text[:300] or f"HTTP {resp.status_code}"

    raise TktlError(f"Flow execution failed: {err}")
