"""Slug / version-name to ID resolution (cache-first, fallback-optional).

The ``Resolver`` accepts a pre-loaded cache dict (matching the index.json
schema from SPEC.md section 8.4) and an optional *lookup_fn* callable that
refreshes the cache from the API when a cache miss occurs.

This design uses dependency injection so it works regardless of whether
the cache and API modules have been built yet.
"""

from __future__ import annotations

from typing import Any, Callable

from tktl.models.errors import NotFoundError


class Resolver:
    """Resolve human-readable slugs/names to internal UUIDs.

    Parameters
    ----------
    cache:
        A dict matching the ``index.json`` schema::

            {
                "flows": {
                    "<slug>": {"id": "<flow_id>", "versions": {"<name>": "<version_id>", ...}},
                    ...
                }
            }

    lookup_fn:
        An optional callable that returns a *fresh* cache dict (same schema).
        Called once on a cache miss; the result replaces the internal cache.
    """

    def __init__(
        self,
        cache: dict[str, Any],
        lookup_fn: Callable[[], dict[str, Any]] | None = None,
    ) -> None:
        self._cache = cache
        self._lookup_fn = lookup_fn

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def resolve_flow_id(self, slug: str) -> str:
        """Return the flow UUID for *slug*.

        Raises ``NotFoundError`` if the slug is not in the cache (and
        the optional fallback also doesn't find it).
        """
        flow = self._flows().get(slug)
        if flow is not None:
            return flow["id"]

        # Cache miss — try the fallback if available.
        if self._lookup_fn is not None:
            self._refresh_cache()
            flow = self._flows().get(slug)
            if flow is not None:
                return flow["id"]

        raise NotFoundError(f"Flow not found: {slug}")

    def resolve_version_id(self, flow_slug: str, version_name: str) -> str:
        """Return the version UUID for *flow_slug* + *version_name*.

        Raises ``NotFoundError`` if the flow slug or version name is not
        found (after an optional fallback lookup).
        """
        version_id = self._try_resolve_version(flow_slug, version_name)
        if version_id is not None:
            return version_id

        # Cache miss — try fallback.
        if self._lookup_fn is not None:
            self._refresh_cache()
            version_id = self._try_resolve_version(flow_slug, version_name)
            if version_id is not None:
                return version_id

        # Provide a useful error message depending on what's missing.
        if flow_slug not in self._flows():
            raise NotFoundError(f"Flow not found: {flow_slug}")
        raise NotFoundError(f"Version not found: {version_name}")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _flows(self) -> dict[str, Any]:
        return self._cache.get("flows", {})

    def _try_resolve_version(self, flow_slug: str, version_name: str) -> str | None:
        flow = self._flows().get(flow_slug)
        if flow is None:
            return None
        versions = flow.get("versions", {})
        return versions.get(version_name)

    def _refresh_cache(self) -> None:
        """Call the fallback lookup and merge results into the cache."""
        assert self._lookup_fn is not None  # noqa: S101
        fresh = self._lookup_fn()
        # Merge fresh flow data into the existing cache so that previously
        # resolved entries are not lost.
        fresh_flows = fresh.get("flows", {})
        existing_flows = self._cache.setdefault("flows", {})
        for slug, flow_data in fresh_flows.items():
            if slug in existing_flows:
                # Merge versions — keep existing, add new.
                existing_versions = existing_flows[slug].setdefault("versions", {})
                existing_versions.update(flow_data.get("versions", {}))
                # Update flow ID in case it changed.
                existing_flows[slug]["id"] = flow_data["id"]
            else:
                existing_flows[slug] = flow_data
