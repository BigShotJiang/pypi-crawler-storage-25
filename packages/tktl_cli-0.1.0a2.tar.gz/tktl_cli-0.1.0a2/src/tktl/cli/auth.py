from __future__ import annotations

import os
import platform
from pathlib import Path

import httpx
import typer

from tktl.config import Config, Credentials
from tktl.telemetry import identify, track

auth_app = typer.Typer(name="auth", help="Manage authentication.", no_args_is_help=True)

DEFAULT_TAKTILE_API_URL = "https://api.taktile.com"


def _config_dir() -> Path:
    return Path(os.environ.get("TKTL_CONFIG_DIR", str(Path.home() / ".tktl")))


def _validate_api_key(api_key: str, taktile_api_url: str) -> dict[str, str] | None:
    """Validate an API key against the Taktile API login endpoint.

    Returns {"user_id": ..., "email": ...} on success, None on failure.
    """
    try:
        resp = httpx.post(
            f"{taktile_api_url}/api/v1/login/access-token",
            headers={"X-Api-Key": api_key},
            timeout=10.0,
        )
        if resp.status_code == 200:
            data = resp.json()
            user = data.get("user", {})
            return {
                "user_id": user.get("id", ""),
                "email": user.get("email", ""),
            }
    except httpx.HTTPError:
        pass
    return None


@auth_app.command("login")
def auth_login() -> None:
    """Authenticate with your API key.

    Validates the key against the Taktile API and stores it along
    with your user ID (needed for version operations).
    """
    api_key = typer.prompt("API key", hide_input=True)

    config = Config(config_dir=_config_dir())
    config.load()
    taktile_api_url = config.get("taktile_api_url") or DEFAULT_TAKTILE_API_URL

    typer.echo("Validating API key...")
    result = _validate_api_key(api_key, taktile_api_url)

    if result is None:
        typer.echo("Invalid API key or unable to reach the Taktile API.", err=True)
        raise typer.Exit(code=3)

    creds = Credentials(config_dir=_config_dir())
    creds.store(api_key, user_id=result["user_id"])

    # Telemetry: identify user and track login
    identify(
        result["user_id"],
        {
            "email": result["email"],
            "org_id": config.get("org"),
            "workspace_id": config.get("workspace"),
            "cli_version": "0.1.2026041415",
            "python_version": platform.python_version(),
            "os": platform.system(),
        },
    )
    track(
        "auth_login",
        {
            "email": result["email"],
            "org_id": config.get("org"),
            "workspace_id": config.get("workspace"),
            "cli_version": "0.1.2026041415",
            "os": platform.system(),
        },
    )

    typer.echo(f"Authenticated as {result['email']}. API key stored.")


@auth_app.command("logout")
def auth_logout() -> None:
    """Remove stored credentials."""
    creds = Credentials(config_dir=_config_dir())
    creds.delete()
    typer.echo("API key removed.")


@auth_app.command("status")
def auth_status() -> None:
    """Check authentication status."""
    creds = Credentials(config_dir=_config_dir())
    creds.load()
    if creds.api_key:
        masked = creds.api_key[:8] + "..." if len(creds.api_key) > 8 else "***"
        user_info = f" (user: {creds.user_id})" if creds.user_id else ""
        typer.echo(f"API key configured: {masked}{user_info}")
    else:
        typer.echo("No API key configured. Run `tktl auth login`.")
