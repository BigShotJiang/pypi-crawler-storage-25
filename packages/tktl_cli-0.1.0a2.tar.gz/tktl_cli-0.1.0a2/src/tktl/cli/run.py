"""CLI command for running flows."""

from __future__ import annotations

from typing import Optional

import typer

from tktl.cli import _deps
from tktl.cli._error_handler import handle_errors
from tktl.cli._json_arg import parse_json_arg
from tktl.cli.output import OutputFormat, print_output
from tktl.models.errors import UsageError
from tktl.ops.flows import run_flow

run_app = typer.Typer(name="run", help="Run a flow.", no_args_is_help=True)


@run_app.command("execute")
@handle_errors
def run_execute(
    slug: str = typer.Argument(..., help="Flow slug."),
    file: Optional[str] = typer.Option(None, "--file", "-f", help="Path to input JSON file."),
    input_json: Optional[str] = typer.Option(None, "--input", "-i", help="Inline JSON input."),
    version: Optional[str] = typer.Option(None, "--version", "-v", help="Version name (default: published)."),
    env: Optional[str] = typer.Option(None, "--env", "-e", help="Environment: sandbox or live."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Run a flow with input data via the workspace Decide API."""
    if file is None and input_json is None:
        raise UsageError("Provide either --file or --input")
    if file is not None and input_json is not None:
        raise UsageError("Provide either --file or --input, not both")

    if file is not None:
        input_data = parse_json_arg(f"@{file}")
    else:
        assert input_json is not None
        input_data = parse_json_arg(input_json)

    deps = _deps.build_deps()
    run_env = env or deps.client._config.get("env") or "sandbox"
    result = run_flow(deps.client, deps.workspace_id, slug, input_data, version=version, env=run_env)
    print_output(result, format=output, quiet=quiet)
