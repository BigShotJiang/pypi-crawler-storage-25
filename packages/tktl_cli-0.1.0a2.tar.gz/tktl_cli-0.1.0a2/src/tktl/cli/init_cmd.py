"""Interactive setup wizard for tktl CLI."""

from __future__ import annotations

import os
import platform
from pathlib import Path

import httpx
import typer

from tktl.config import Config, Credentials
from tktl.telemetry import identify, track

DEFAULT_TAKTILE_API_URL = "https://api.taktile.com"
DEFAULT_FLOW_API_URL = "https://flow-api.taktile.com"


def _config_dir() -> Path:
    return Path(os.environ.get("TKTL_CONFIG_DIR", str(Path.home() / ".tktl")))


def _validate_api_key(api_key: str, taktile_api_url: str) -> dict[str, str] | None:
    """Validate an API key against the Taktile API login endpoint."""
    try:
        resp = httpx.post(
            f"{taktile_api_url}/api/v1/login/access-token",
            headers={"X-Api-Key": api_key},
            timeout=10.0,
        )
        if resp.status_code == 200:
            data = resp.json()
            user = data.get("user", {})
            return {
                "user_id": user.get("id", ""),
                "email": user.get("email", ""),
            }
    except httpx.HTTPError:
        pass
    return None


def init() -> None:
    """Set up tktl CLI configuration interactively.

    Walks through API key, org, workspace, and environment.
    Validates against production Taktile by default. If validation fails,
    offers to configure custom API URLs (for internal/dev environments).
    """
    config_dir = _config_dir()
    taktile_api_url: str | None = None
    flow_api_url: str | None = None

    typer.echo("Welcome to tktl! Let's set up your configuration.\n")

    # Step 1: API key
    api_key = typer.prompt("API key", hide_input=True)

    # Step 2: Validate against prod
    typer.echo(f"Validating against {DEFAULT_TAKTILE_API_URL}...")
    result = _validate_api_key(api_key, DEFAULT_TAKTILE_API_URL)

    if result is None:
        # Prod failed — offer custom environment
        use_custom = typer.confirm(
            "Could not validate against production. Are you using a custom Taktile environment?",
        )
        if not use_custom:
            typer.echo("Invalid API key or unable to reach the Taktile API.", err=True)
            raise typer.Exit(code=3)

        # Prompt for custom URLs and re-validate
        taktile_api_url = typer.prompt("Taktile API URL")
        flow_api_url = typer.prompt("Flow API URL")

        typer.echo(f"Validating against {taktile_api_url}...")
        result = _validate_api_key(api_key, taktile_api_url)

        if result is None:
            typer.echo("Invalid API key or unable to reach the Taktile API.", err=True)
            raise typer.Exit(code=3)

    typer.echo(f"Authenticated as {result['email']}.\n")

    # Store credentials
    creds = Credentials(config_dir=config_dir)
    creds.store(api_key, user_id=result["user_id"])

    # Step 3: Organization and workspace
    org = typer.prompt("Organization ID")
    workspace = typer.prompt("Workspace ID")
    env = typer.prompt("Environment (sandbox/live)", default="sandbox")

    # Save config
    config = Config(config_dir=config_dir)
    config.load()
    config.set("org", org)
    config.set("workspace", workspace)
    config.set("env", env)
    config.set("taktile_api_url", taktile_api_url)
    config.set("flow_api_url", flow_api_url)
    config.save()

    # Telemetry
    identify(
        result["user_id"],
        {
            "email": result["email"],
            "org_id": org,
            "workspace_id": workspace,
            "cli_version": "0.1.2026041415",
            "python_version": platform.python_version(),
            "os": platform.system(),
        },
    )
    track(
        "init",
        {
            "email": result["email"],
            "org_id": org,
            "workspace_id": workspace,
            "env": env,
            "custom_urls": bool(taktile_api_url or flow_api_url),
            "cli_version": "0.1.2026041415",
            "os": platform.system(),
        },
    )

    typer.echo(f"\nConfiguration saved to {config_dir}/config.json")
    typer.echo("You're all set! Try `tktl flows list` to get started.")
