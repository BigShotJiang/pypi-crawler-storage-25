"""CLI commands for updating versions and nodes."""

from __future__ import annotations

from typing import Optional

import typer

from tktl.cli import _deps
from tktl.cli._error_handler import handle_errors
from tktl.cli._json_arg import parse_json_arg
from tktl.cli.output import OutputFormat, print_output
from tktl.models.errors import UsageError
from tktl.ops.nodes import update_node
from tktl.ops.versions import replace_version, update_version

update_app = typer.Typer(name="update", help="Update version or node configuration.", no_args_is_help=True)


@update_app.command("apply")
@handle_errors
def update_apply(
    slug: str = typer.Argument(..., help="Flow slug."),
    version: str = typer.Argument(..., help="Version name."),
    node: Optional[str] = typer.Option(None, "--node", help="Node ID to update."),
    node_config: Optional[str] = typer.Option(None, "--node-config", help="Node config as JSON or @file."),
    params: Optional[str] = typer.Option(None, "--params", help="Version parameters as JSON or @file."),
    schema_in: Optional[str] = typer.Option(None, "--schema-in", help="Input schema as JSON or @file."),
    schema_out: Optional[str] = typer.Option(None, "--schema-out", help="Output schema as JSON or @file."),
    file: Optional[str] = typer.Option(None, "--file", help="Replace entire version from JSON file."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Update a version or node configuration.

    For node updates: --node <ID> --node-config <JSON|@file>
    For version param updates: --params <JSON|@file>
    For schema updates: --schema-in <JSON|@file> or --schema-out <JSON|@file>
    For full replacement: --file <path>
    """
    deps = _deps.build_deps()

    # Node update
    if node is not None:
        if node_config is None:
            raise UsageError("--node-config is required when --node is specified")
        config_data = parse_json_arg(node_config)
        result = update_node(
            deps.client,
            deps.cache_index,
            deps.cache_manager,
            deps.workspace_id,
            slug,
            version,
            node,
            meta=config_data,
        )
        print_output(result, format=output, quiet=quiet)
        return

    # Full version replacement
    if file is not None:
        body = parse_json_arg(f"@{file}")
        result = replace_version(
            deps.client, deps.cache_index, deps.cache_manager, deps.workspace_id, slug, version, body
        )
        print_output(result, format=output, quiet=quiet)
        return

    # Version-level field updates
    if params is None and schema_in is None and schema_out is None:
        raise UsageError("Provide --node, --params, --schema-in, --schema-out, or --file")

    params_data = parse_json_arg(params) if params is not None else None
    schema_in_data = parse_json_arg(schema_in) if schema_in is not None else None
    schema_out_data = parse_json_arg(schema_out) if schema_out is not None else None

    result = update_version(
        deps.client,
        deps.cache_index,
        deps.cache_manager,
        deps.workspace_id,
        slug,
        version,
        params=params_data,
        schema_in=schema_in_data,
        schema_out=schema_out_data,
    )
    print_output(result, format=output, quiet=quiet)
