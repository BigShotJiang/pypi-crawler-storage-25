"""CLI commands for datasets: list, create, upload, describe, rows, CRUD."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

import typer

from tktl.cli import _deps
from tktl.cli._error_handler import handle_errors
from tktl.cli._json_arg import parse_json_arg
from tktl.cli.output import OutputFormat, print_output
from tktl.models.dataset import ColumnGroup, ColumnType, DatasetColumn
from tktl.models.errors import UsageError
from tktl.ops.batch import parse_batch_file
from tktl.ops.datasets import (
    add_blank_rows,
    add_column,
    add_rows,
    create_dataset,
    create_from_schema,
    delete_column,
    delete_dataset,
    delete_row,
    describe_dataset,
    download_dataset,
    fill_column,
    get_rows,
    list_datasets,
    rename_column,
    sync_schema,
    update_row,
    upload_dataset,
)

datasets_app = typer.Typer(name="datasets", help="Manage test datasets.", no_args_is_help=True)


@datasets_app.command("list")
@handle_errors
def datasets_list(
    slug: str = typer.Argument(..., help="Flow slug."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """List all datasets for a flow."""
    deps = _deps.build_deps()
    result = list_datasets(deps.client, deps.cache_index, deps.workspace_id, slug)
    print_output(result, format=output, quiet=quiet)


@datasets_app.command("create")
@handle_errors
def datasets_create(
    slug: str = typer.Argument(..., help="Flow slug."),
    name: str = typer.Option(..., "--name", "-n", help="Dataset name."),
    from_schema: Optional[str] = typer.Option(
        None, "--from-schema", help="Version name — derive columns from input schema."
    ),
    columns: Optional[str] = typer.Option(None, "--columns", help="Manual column definitions as JSON array."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Create a new dataset from scratch or from a flow version's schema."""
    if from_schema is not None and columns is not None:
        raise UsageError("Provide either --from-schema or --columns, not both")

    deps = _deps.build_deps()

    if from_schema is not None:
        result = create_from_schema(deps.client, deps.cache_index, deps.workspace_id, slug, from_schema, name)
    elif columns is not None:
        raw_cols = parse_json_arg(columns)
        if not isinstance(raw_cols, list):
            raise UsageError("--columns must be a JSON array")
        col_objs = [DatasetColumn.model_validate(c) for c in raw_cols]
        result = create_dataset(deps.client, deps.cache_index, deps.workspace_id, slug, name, col_objs)
    else:
        raise UsageError("Provide either --from-schema or --columns")

    print_output(result, format=output, quiet=quiet)


@datasets_app.command("upload")
@handle_errors
def datasets_upload(
    slug: str = typer.Argument(..., help="Flow slug."),
    file: str = typer.Option(..., "--file", "-f", help="Local file (CSV or JSON)."),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Dataset name (defaults to filename)."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Upload a local file as a new dataset."""
    deps = _deps.build_deps()
    result = upload_dataset(deps.client, deps.cache_index, deps.workspace_id, slug, Path(file), name)
    print_output(result, format=output, quiet=quiet)


@datasets_app.command("describe")
@handle_errors
def datasets_describe(
    dataset_id: str = typer.Argument(..., help="Dataset UUID."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Show dataset metadata."""
    deps = _deps.build_deps()
    result = describe_dataset(deps.client, deps.workspace_id, dataset_id)
    print_output(result, format=output, quiet=quiet)


@datasets_app.command("rows")
@handle_errors
def datasets_rows(
    dataset_id: str = typer.Argument(..., help="Dataset UUID."),
    from_: int = typer.Option(0, "--from", help="Start offset."),
    size: int = typer.Option(50, "--size", help="Number of rows."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """List dataset rows with pagination."""
    deps = _deps.build_deps()
    result = get_rows(deps.client, deps.workspace_id, dataset_id, from_=from_, size=size)
    print_output(result, format=output, quiet=quiet)


@datasets_app.command("add-rows")
@handle_errors
def datasets_add_rows(
    dataset_id: str = typer.Argument(..., help="Dataset UUID."),
    file: Optional[str] = typer.Option(None, "--file", "-f", help="File with row data (CSV/JSON)."),
    blank: Optional[int] = typer.Option(None, "--blank", help="Number of blank rows to add."),
    data: Optional[str] = typer.Option(None, "--data", help="Inline JSON array of row objects."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Append rows to a dataset."""
    sources = sum(1 for s in [file, blank, data] if s is not None)
    if sources != 1:
        raise UsageError("Provide exactly one of --file, --blank, or --data")

    deps = _deps.build_deps()

    if blank is not None:
        result = add_blank_rows(deps.client, deps.workspace_id, dataset_id, blank)
    elif data is not None:
        rows_data = parse_json_arg(data)
        if not isinstance(rows_data, list):
            raise UsageError("--data must be a JSON array")
        result = add_rows(deps.client, deps.workspace_id, dataset_id, rows_data)
    else:
        assert file is not None
        rows_data = parse_batch_file(Path(file))
        result = add_rows(deps.client, deps.workspace_id, dataset_id, rows_data)

    print_output(result, format=output, quiet=quiet)


@datasets_app.command("update-row")
@handle_errors
def datasets_update_row(
    dataset_id: str = typer.Argument(..., help="Dataset UUID."),
    row_id: str = typer.Argument(..., help="Row UUID."),
    data: str = typer.Option(..., "--data", help="JSON object with fields to update."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Modify a single row's data."""
    deps = _deps.build_deps()
    parsed = parse_json_arg(data)
    result = update_row(deps.client, deps.workspace_id, dataset_id, row_id, parsed)
    print_output(result, format=output, quiet=quiet)


@datasets_app.command("delete-row")
@handle_errors
def datasets_delete_row(
    dataset_id: str = typer.Argument(..., help="Dataset UUID."),
    row_id: str = typer.Argument(..., help="Row UUID."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Delete a single row."""
    deps = _deps.build_deps()
    delete_row(deps.client, deps.workspace_id, dataset_id, row_id)
    if not quiet:
        typer.echo(f"Deleted row {row_id}")


@datasets_app.command("add-column")
@handle_errors
def datasets_add_column(
    dataset_id: str = typer.Argument(..., help="Dataset UUID."),
    group: str = typer.Option(
        ..., "--group", help="Column group: input_columns, output_columns, mock_columns, meta_columns, outcome_columns."
    ),
    name: str = typer.Option(..., "--name", help="Column name."),
    col_type: str = typer.Option(
        ...,
        "--type",
        help="Column type: string, number, integer, boolean, object, array, datetime, date, any, enum, files.",
    ),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Add a column to a dataset."""
    deps = _deps.build_deps()
    result = add_column(deps.client, deps.workspace_id, dataset_id, ColumnGroup(group), name, ColumnType(col_type))
    print_output(result, format=output, quiet=quiet)


@datasets_app.command("rename-column")
@handle_errors
def datasets_rename_column(
    dataset_id: str = typer.Argument(..., help="Dataset UUID."),
    group: str = typer.Option(..., "--group", help="Column group."),
    old: str = typer.Option(..., "--old", help="Current column name."),
    new: str = typer.Option(..., "--new", help="New column name."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Rename a column."""
    deps = _deps.build_deps()
    result = rename_column(deps.client, deps.workspace_id, dataset_id, ColumnGroup(group), old, new)
    print_output(result, format=output, quiet=quiet)


@datasets_app.command("delete-column")
@handle_errors
def datasets_delete_column(
    dataset_id: str = typer.Argument(..., help="Dataset UUID."),
    group: str = typer.Option(..., "--group", help="Column group."),
    name: str = typer.Option(..., "--name", help="Column name."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Delete a column from a dataset."""
    deps = _deps.build_deps()
    result = delete_column(deps.client, deps.workspace_id, dataset_id, ColumnGroup(group), name)
    print_output(result, format=output, quiet=quiet)


@datasets_app.command("fill-column")
@handle_errors
def datasets_fill_column(
    dataset_id: str = typer.Argument(..., help="Dataset UUID."),
    group: str = typer.Option(..., "--group", help="Column group."),
    name: str = typer.Option(..., "--name", help="Column name."),
    value: str = typer.Option(..., "--value", help="Fill value as JSON (e.g. 42, '\"hello\"', true, null)."),
    from_: int = typer.Option(0, "--from", help="Start row index."),
    limit: Optional[int] = typer.Option(None, "--limit", help="Number of rows to fill."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Fill a column with a value."""
    parsed_value = json.loads(value)
    deps = _deps.build_deps()
    result = fill_column(
        deps.client, deps.workspace_id, dataset_id, ColumnGroup(group), name, parsed_value, from_=from_, limit=limit
    )
    print_output(result, format=output, quiet=quiet)


@datasets_app.command("sync-schema")
@handle_errors
def datasets_sync_schema(
    slug: str = typer.Argument(..., help="Flow slug."),
    dataset_id: str = typer.Argument(..., help="Dataset UUID."),
    version: str = typer.Option(..., "--version", "-v", help="Version name to sync against."),
    apply: bool = typer.Option(False, "--apply", help="Apply changes (add missing columns)."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Compare dataset columns against flow version input schema."""
    deps = _deps.build_deps()
    result = sync_schema(deps.client, deps.cache_index, deps.workspace_id, slug, dataset_id, version, apply=apply)
    print_output(result, format=output, quiet=quiet)


@datasets_app.command("download")
@handle_errors
def datasets_download(
    dataset_id: str = typer.Argument(..., help="Dataset UUID."),
    fmt: str = typer.Option("csv", "--format", help="File format: csv or json."),
    output_path: Optional[str] = typer.Option(None, "--output", "-o", help="Output file path (omit for stdout)."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Download a dataset as a file."""
    deps = _deps.build_deps()
    out = Path(output_path) if output_path else None
    content = download_dataset(deps.client, deps.workspace_id, dataset_id, fmt=fmt, output_path=out)
    if out is None:
        typer.echo(content)
    elif not quiet:
        typer.echo(f"Downloaded to {content}")


@datasets_app.command("delete")
@handle_errors
def datasets_delete(
    dataset_id: str = typer.Argument(..., help="Dataset UUID."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Delete a dataset permanently."""
    deps = _deps.build_deps()
    delete_dataset(deps.client, deps.workspace_id, dataset_id)
    if not quiet:
        typer.echo(f"Deleted dataset {dataset_id}")
