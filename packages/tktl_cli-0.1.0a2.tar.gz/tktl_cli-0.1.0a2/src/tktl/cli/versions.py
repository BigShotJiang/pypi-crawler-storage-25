"""CLI commands for versions: list, describe, publish, archive, create, duplicate, changes."""

from __future__ import annotations

import sys
import tempfile
from pathlib import Path
from typing import Optional

import typer

from tktl.cli import _deps
from tktl.cli._error_handler import handle_errors
from tktl.cli.output import OutputFormat, print_output
from tktl.models.errors import RenderError
from tktl.models.version import VersionSummary
from tktl.ops.diff import diff_versions
from tktl.ops.render import build_flow_url, diff_to_mermaid, preview_version_graph, render_mermaid_png
from tktl.ops.versions import (
    _fetch_and_cache_version,
    _resolve_ids,
    archive_version,
    create_version,
    describe_version,
    duplicate_version,
    list_changes,
    list_versions,
    publish_version,
)

versions_app = typer.Typer(name="versions", help="Manage flow versions.", no_args_is_help=True)


def _print_flow_url(
    deps: _deps.Deps,
    slug: str,
    version_id: str,
    quiet: bool,
    output: OutputFormat,
) -> None:
    """Print the Taktile app URL for the given version (no-op if URL can't be built)."""
    if quiet or not deps.app_url or not deps.org_id:
        return
    flow_id = deps.cache_index.resolve_flow_id(slug)
    if not flow_id:
        return
    url = build_flow_url(deps.app_url, deps.org_id, deps.workspace_id, flow_id, version_id)
    dest = sys.stderr if output == OutputFormat.json else sys.stdout
    typer.echo(f"\n  Open: {url}", file=dest)


@versions_app.command("list")
@handle_errors
def versions_list(
    slug: str = typer.Argument(..., help="Flow slug."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """List all versions of a flow."""
    deps = _deps.build_deps()
    result = list_versions(deps.client, deps.cache_index, deps.cache_manager, deps.workspace_id, slug)
    print_output(result, format=output, quiet=quiet)


@versions_app.command("describe")
@handle_errors
def versions_describe(
    slug: str = typer.Argument(..., help="Flow slug."),
    name: str = typer.Argument(..., help="Version name."),
    full: bool = typer.Option(False, "--full", help="Show full version including graph."),
    summary: bool = typer.Option(False, "--summary", "-s", help="Show summary only."),
    preview: bool = typer.Option(
        False, "--preview", "-p", help="Render flow graph as Mermaid PNG and print a file:// link."
    ),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Describe a version."""
    deps = _deps.build_deps()
    result = describe_version(
        deps.client, deps.cache_index, deps.cache_manager, deps.workspace_id, slug, name, full=full
    )
    if summary:
        result = VersionSummary(name=result.name, id=result.id, status=result.status)
    print_output(result, format=output, quiet=quiet)

    if preview and not quiet:
        dest = sys.stderr if output == OutputFormat.json else sys.stdout
        try:
            png_path = preview_version_graph(
                deps.client, deps.cache_index, deps.cache_manager, deps.workspace_id, slug, name
            )
            typer.echo(f"\n  Preview: file://{png_path}", file=dest)
        except RenderError as exc:
            typer.echo(f"  Preview: render failed — {exc}", file=sys.stderr)


@versions_app.command("publish")
@handle_errors
def versions_publish(
    slug: str = typer.Argument(..., help="Flow slug."),
    name: str = typer.Argument(..., help="Version name."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Publish a draft version."""
    deps = _deps.build_deps()
    result = publish_version(deps.client, deps.cache_index, deps.cache_manager, deps.workspace_id, slug, name)
    print_output(result, format=output, quiet=quiet)


@versions_app.command("archive")
@handle_errors
def versions_archive(
    slug: str = typer.Argument(..., help="Flow slug."),
    name: str = typer.Argument(..., help="Version name."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Archive a version."""
    deps = _deps.build_deps()
    result = archive_version(deps.client, deps.cache_index, deps.cache_manager, deps.workspace_id, slug, name)
    print_output(result, format=output, quiet=quiet)


@versions_app.command("create")
@handle_errors
def versions_create(
    slug: str = typer.Argument(..., help="Flow slug."),
    name: str = typer.Argument(..., help="New version name."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Create a new draft version."""
    deps = _deps.build_deps()
    result = create_version(deps.client, deps.cache_index, deps.cache_manager, deps.workspace_id, slug, name)
    print_output(result, format=output, quiet=quiet)
    _print_flow_url(deps, slug, result.id, quiet, output)


@versions_app.command("duplicate")
@handle_errors
def versions_duplicate(
    slug: str = typer.Argument(..., help="Flow slug."),
    name: str = typer.Argument(..., help="Source version name."),
    new_name: str = typer.Option(..., "--name", "-n", help="New version name."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Duplicate an existing version."""
    deps = _deps.build_deps()
    result = duplicate_version(
        deps.client, deps.cache_index, deps.cache_manager, deps.workspace_id, slug, name, new_name
    )
    print_output(result, format=output, quiet=quiet)
    _print_flow_url(deps, slug, result.id, quiet, output)


@versions_app.command("diff")
@handle_errors
def versions_diff(
    slug: str = typer.Argument(..., help="Flow slug."),
    version_a: str = typer.Argument(..., help="First version name."),
    version_b: str = typer.Argument(..., help="Second version name."),
    preview: bool = typer.Option(False, "--preview", "-p", help="Render diff as a PNG and print a file:// link."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Show the diff between two versions of a flow."""
    deps = _deps.build_deps()
    diff = diff_versions(
        deps.client,
        deps.cache_index,
        deps.cache_manager,
        deps.workspace_id,
        slug,
        version_a,
        version_b,
    )

    # Determine effective output format
    resolved_fmt = output
    if output == OutputFormat.auto:
        resolved_fmt = OutputFormat.table if sys.stdout.isatty() else OutputFormat.json

    if not quiet:
        if resolved_fmt == OutputFormat.json:
            print_output(diff.model_dump(mode="json"), format=output, quiet=quiet)
        else:
            typer.echo(diff.summary())

    if preview and not quiet:
        dest = sys.stderr if output == OutputFormat.json else sys.stdout
        try:
            flow_id_a, version_id_a = _resolve_ids(deps.client, deps.cache_index, deps.workspace_id, slug, version_a)
            flow_id_b, version_id_b = _resolve_ids(deps.client, deps.cache_index, deps.workspace_id, slug, version_b)
            assert version_id_a is not None and version_id_b is not None
            raw_a = _fetch_and_cache_version(deps.client, deps.cache_manager, flow_id_a, version_id_a)
            raw_b = _fetch_and_cache_version(deps.client, deps.cache_manager, flow_id_b, version_id_b)
            graph_a = raw_a.get("graph") or {}
            graph_b = raw_b.get("graph") or {}
            code = diff_to_mermaid(graph_a, graph_b, diff)
            out_dir = Path(tempfile.gettempdir()) / "tktl"
            png_path = render_mermaid_png(code, out_dir)
            typer.echo(f"\n  Preview: file://{png_path}", file=dest)
        except RenderError as exc:
            typer.echo(f"  Preview: render failed — {exc}", file=sys.stderr)


@versions_app.command("changes")
@handle_errors
def versions_changes(
    slug: str = typer.Argument(..., help="Flow slug."),
    name: str = typer.Argument(..., help="Version name."),
    after: Optional[str] = typer.Option(None, "--after", help="ETag to paginate after."),
    limit: int = typer.Option(100, "--limit", "-l", help="Maximum number of changes."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """List changes for a version."""
    deps = _deps.build_deps()
    result = list_changes(deps.client, deps.cache_index, deps.workspace_id, slug, name, after_etag=after, limit=limit)
    print_output(result, format=output, quiet=quiet)
