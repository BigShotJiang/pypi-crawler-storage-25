"""CLI commands for workspace connections."""

from __future__ import annotations

import json
from typing import Optional

import typer

from tktl.cli import _deps
from tktl.cli._error_handler import handle_errors
from tktl.cli.output import OutputFormat, print_output
from tktl.ops.connections import create_connection, create_resource_config, list_connections, update_secrets

connections_app = typer.Typer(name="connections", help="Manage workspace connections.", no_args_is_help=True)


@connections_app.command("list")
@handle_errors
def connections_list(
    provider: Optional[str] = typer.Option(
        None, "--provider", help="Filter by provider type (e.g. custom, manual_review)."
    ),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """List all connections in the workspace."""
    deps = _deps.build_deps()
    result = list_connections(deps.client, deps.workspace_id)
    if provider:
        result = [c for c in result if c.provider == provider]
    print_output(result, format=output, quiet=quiet)


@connections_app.command("create")
@handle_errors
def connections_create(
    name: str = typer.Option(..., "--name", help="Connection name."),
    provider: str = typer.Option("custom", "--provider", help="Provider type."),
    base_url: Optional[str] = typer.Option(None, "--base-url", help="Base URL for HTTP connections."),
    auth_method: str = typer.Option("no_auth", "--auth-method", help="Auth method."),
    is_sandbox: bool = typer.Option(False, "--is-sandbox", help="Mark as sandbox connection."),
    secret: Optional[list[str]] = typer.Option(None, "--secret", help="Secret as key=value (repeatable)."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Create a new connection in the workspace."""
    secrets = None
    if secret:
        secrets = []
        for s in secret:
            key, _, value = s.partition("=")
            secrets.append({"key": key, "value": value, "environment": "production"})

    deps = _deps.build_deps()
    result = create_connection(
        deps.client,
        deps.workspace_id,
        name=name,
        provider=provider,
        is_sandbox=is_sandbox,
        base_url=base_url,
        auth_method=auth_method,
        secrets=secrets,
    )
    print_output(result, format=output, quiet=quiet)


@connections_app.command("create-resource")
@handle_errors
def connections_create_resource(
    connection_id: str = typer.Argument(..., help="Connection ID."),
    name: str = typer.Option(..., "--name", help="Resource config name."),
    resource: str = typer.Option("http", "--resource", help="Resource type."),
    config: Optional[str] = typer.Option(None, "--config", help="Configuration as JSON or @file."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Create a resource config on a connection."""
    configuration = None
    if config is not None:
        if config.startswith("@"):
            with open(config[1:]) as f:
                configuration = json.load(f)
        else:
            configuration = json.loads(config)

    deps = _deps.build_deps()
    result = create_resource_config(
        deps.client,
        deps.workspace_id,
        connection_id=connection_id,
        name=name,
        resource=resource,
        configuration=configuration,
    )
    print_output(result, format=output, quiet=quiet)


@connections_app.command("update-secrets")
@handle_errors
def connections_update_secrets(
    connection_id: str = typer.Argument(..., help="Connection ID."),
    secret: list[str] = typer.Option(..., "--secret", help="Secret as key=value (repeatable)."),
    env: str = typer.Option("production", "--env", help="Environment for all secrets."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Update secrets on a connection."""
    secrets = []
    for s in secret:
        key, _, value = s.partition("=")
        secrets.append({"key": key, "value": value, "environment": env})

    deps = _deps.build_deps()
    result = update_secrets(
        deps.client,
        deps.workspace_id,
        connection_id=connection_id,
        secrets=secrets,
    )
    print_output(result, format=output, quiet=quiet)
