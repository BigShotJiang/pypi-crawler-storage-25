"""Utility for parsing JSON values that can be inline JSON or @file references."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from tktl.models.errors import UsageError


def parse_json_arg(value: str) -> Any:
    """Parse a JSON argument that is either inline JSON or an @file reference.

    If *value* starts with ``@``, the rest is treated as a file path and the
    file contents are parsed as JSON.  Otherwise *value* is parsed directly.

    Raises ``UsageError`` on invalid JSON or missing files.
    """
    if value.startswith("@"):
        file_path = Path(value[1:])
        if not file_path.exists():
            raise UsageError(f"File not found: {file_path}")
        try:
            return json.loads(file_path.read_text())
        except json.JSONDecodeError as exc:
            raise UsageError(f"Invalid JSON in {file_path}: {exc}") from exc
    else:
        try:
            return json.loads(value)
        except json.JSONDecodeError as exc:
            raise UsageError(f"Invalid JSON: {exc}") from exc
