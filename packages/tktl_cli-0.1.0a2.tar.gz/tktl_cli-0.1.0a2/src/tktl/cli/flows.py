"""CLI commands for flows: list, describe, run, batch."""

from __future__ import annotations

import json as _json
import re as _re
import sys
from pathlib import Path
from typing import Optional

import typer

from tktl.cli import _deps
from tktl.cli._error_handler import handle_errors
from tktl.cli._json_arg import parse_json_arg
from tktl.cli.output import OutputFormat, print_output
from tktl.models.errors import UsageError
from tktl.models.flow import FlowSummary
from tktl.ops.batch import extract_query, get_batch_results, get_batch_run, list_batch_runs, run_batch
from tktl.ops.diff import diff_versions
from tktl.ops.explain import explain_flow
from tktl.ops.flows import create_flow, describe_flow, list_flows, run_flow, update_flow_folder
from tktl.ops.templates import TEMPLATES
from tktl.ops.versions import replace_version

flows_app = typer.Typer(name="flows", help="Manage decision flows.", no_args_is_help=True)


@flows_app.command("create")
@handle_errors
def flows_create(
    slug: str = typer.Argument(..., help="URL-safe slug for the new flow (e.g. my-flow)."),
    name: str = typer.Argument(..., help="Human-readable flow name."),
    folder: Optional[str] = typer.Option(None, "--folder", "-f", help="Flow folder UUID."),
    version_name: str = typer.Option("v1", "--version-name", help="Name of the initial draft version."),
    template: Optional[str] = typer.Option(
        None,
        "--template",
        "-t",
        help=f"Pre-built node template: {', '.join(TEMPLATES)}. Adds all nodes in one PATCH.",
    ),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Create a new flow with an initial draft version."""
    if template is not None and template not in TEMPLATES:
        raise UsageError(f"Unknown template '{template}'. Available: {', '.join(TEMPLATES)}")

    deps = _deps.build_deps()
    result = create_flow(
        deps.client,
        deps.cache_index,
        deps.workspace_id,
        slug,
        name,
        folder_id=folder,
        initial_version_name=version_name,
    )

    if template is not None:
        user_id = deps.client._user_id or "cli-user"
        graph_body = TEMPLATES[template](user_id)
        replace_version(
            deps.client,
            deps.cache_index,
            deps.cache_manager,
            deps.workspace_id,
            slug,
            version_name,
            graph_body,
        )

    print_output(result, format=output, quiet=quiet)


@flows_app.command("update")
@handle_errors
def flows_update(
    slug: str = typer.Argument(..., help="Flow slug."),
    folder: Optional[str] = typer.Option(None, "--folder", "-f", help="Move flow into this folder UUID."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Update flow metadata (e.g. move to a folder)."""
    if folder is None:
        raise UsageError("Provide at least one option to update (e.g. --folder)")

    deps = _deps.build_deps()
    result = update_flow_folder(deps.client, deps.cache_index, deps.workspace_id, slug, folder)
    print_output(result, format=output, quiet=quiet)


@flows_app.command("list")
@handle_errors
def flows_list(
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """List all flows in the workspace."""
    deps = _deps.build_deps()
    result = list_flows(deps.client, deps.cache_manager, deps.workspace_id)
    print_output(result, format=output, quiet=quiet)


@flows_app.command("describe")
@handle_errors
def flows_describe(
    slug: str = typer.Argument(..., help="Flow slug."),
    summary: bool = typer.Option(False, "--summary", "-s", help="Show summary only."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Describe a flow by slug."""
    deps = _deps.build_deps()
    result = describe_flow(deps.client, deps.cache_index, deps.cache_manager, deps.workspace_id, slug)
    if summary:
        result = FlowSummary(slug=result.slug, id=result.id, name=result.name)
    print_output(result, format=output, quiet=quiet)


@flows_app.command("run")
@handle_errors
def flows_run(
    slug: str = typer.Argument(..., help="Flow slug."),
    file: Optional[str] = typer.Option(None, "--file", "-f", help="Path to input JSON file."),
    input_json: Optional[str] = typer.Option(None, "--input", "-i", help="Inline JSON input."),
    version: Optional[str] = typer.Option(None, "--version", "-v", help="Version name (default: published)."),
    env: Optional[str] = typer.Option(None, "--env", "-e", help="Environment: sandbox or live."),
    mock_data: Optional[str] = typer.Option(
        None,
        "--mock-data",
        "-m",
        help="Mock data JSON (inline or @file). Keys: node_id or parent__child.",
    ),
    async_mode: bool = typer.Option(
        False,
        "--async",
        help="Use async execution mode (polls for result).",
    ),
    timeout: float = typer.Option(
        60.0,
        "--timeout",
        "-t",
        help="Async poll timeout in seconds.",
    ),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Run a flow with input data via the workspace Decide API."""
    if file is None and input_json is None:
        raise UsageError("Provide either --file or --input")
    if file is not None and input_json is not None:
        raise UsageError("Provide either --file or --input, not both")

    if file is not None:
        input_data = parse_json_arg(f"@{file}")
    else:
        assert input_json is not None
        input_data = parse_json_arg(input_json)

    parsed_mock_data = None
    if mock_data is not None:
        parsed_mock_data = parse_json_arg(mock_data)

    deps = _deps.build_deps()
    run_env = env or deps.client._config.get("env") or "sandbox"
    execution_mode = "async" if async_mode else "sync"
    result = run_flow(
        deps.client,
        deps.workspace_id,
        slug,
        input_data,
        version=version,
        env=run_env,
        mock_data=parsed_mock_data,
        execution_mode=execution_mode,
        poll_timeout=timeout,
    )
    print_output(result, format=output, quiet=quiet)


@flows_app.command("batch")
@handle_errors
def flows_batch(
    slug: str = typer.Argument(..., help="Flow slug."),
    file: Optional[str] = typer.Option(None, "--file", "-f", help="Path to local input file (CSV, JSON, JSONL)."),
    dataset: Optional[str] = typer.Option(None, "--dataset", "-d", help="Dataset UUID on the platform."),
    concurrency: int = typer.Option(10, "--concurrency", "-c", help="Max concurrent requests (1-50)."),
    version: Optional[str] = typer.Option(None, "--version", "-v", help="Version name (default: published)."),
    env: Optional[str] = typer.Option(None, "--env", "-e", help="Environment: sandbox or live."),
    runs_dir: Optional[str] = typer.Option(None, "--runs-dir", hidden=True, help="Override runs directory."),
    expected_field: Optional[str] = typer.Option(
        None, "--expected-field", help="Field name containing expected output (for accuracy)."
    ),
    actual_field: Optional[str] = typer.Option(
        None, "--actual-field", help="Field name containing actual decision (for accuracy)."
    ),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Run multiple decisions from a local file or platform dataset. Max 1000 rows."""
    if file is None and dataset is None:
        raise UsageError("Provide either --file or --dataset")
    if file is not None and dataset is not None:
        raise UsageError("Provide either --file or --dataset, not both")

    deps = _deps.build_deps()
    run_env = env or deps.client._config.get("env") or "sandbox"
    kwargs: dict = {}
    if runs_dir is not None:
        kwargs["runs_dir"] = Path(runs_dir)

    result = run_batch(
        deps.client,
        deps.workspace_id,
        slug,
        file_path=Path(file) if file is not None else None,
        dataset_id=dataset,
        version=version,
        env=run_env,
        concurrency=concurrency,
        **kwargs,
    )

    # Enhanced summary for non-JSON, non-quiet mode
    if not quiet and output != OutputFormat.json:
        results_path = Path(result.results_path)
        decision_counts: dict[str, int] = {}
        error_count = 0

        if results_path.exists():
            for line in results_path.read_text().splitlines():
                if not line.strip():
                    continue
                row = _json.loads(line)
                if row.get("error"):
                    error_count += 1
                elif row.get("output"):
                    data = row.get("output", {}).get("data", {})
                    decision = data.get("decision") or data.get("result") or data.get("status")
                    if decision is not None:
                        key = str(decision)
                        decision_counts[key] = decision_counts.get(key, 0) + 1
                    else:
                        decision_counts["(no decision field)"] = decision_counts.get("(no decision field)", 0) + 1

        typer.echo(f"\nBatch complete: {result.meta.total_rows} rows in {result.meta.duration_ms}ms")
        typer.echo(f"  Succeeded: {result.meta.succeeded}  Failed: {result.meta.failed}")
        if error_count:
            typer.echo(f"  Errors: {error_count}")
        if decision_counts:
            typer.echo("  Decisions:")
            for k, v in sorted(decision_counts.items(), key=lambda x: -x[1]):
                typer.echo(f"    {k}: {v}")

        # Accuracy comparison
        if expected_field is not None and actual_field is not None and results_path.exists():
            match_count = 0
            total_count = 0
            for line in results_path.read_text().splitlines():
                if not line.strip():
                    continue
                row = _json.loads(line)
                actual_val = extract_query(row, f"output.data.{actual_field}")
                expected_val = extract_query(row, f"input.{expected_field}")
                if actual_val is not None or expected_val is not None:
                    total_count += 1
                    if actual_val == expected_val:
                        match_count += 1
            if total_count > 0:
                pct = (match_count / total_count) * 100
                typer.echo(f"  Accuracy: {match_count}/{total_count} ({pct:.1f}%)")

    print_output(result, format=output, quiet=quiet)


@flows_app.command("wizard")
@handle_errors
def flows_wizard(
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Interactively create a new flow with guided prompts."""
    # Step 1: Flow name
    name = typer.prompt("Flow name (e.g. 'Credit Decision')")

    # Step 2: Slug
    default_slug = _re.sub(r"[^a-z0-9-]", "", name.lower().replace(" ", "-").replace("_", "-"))
    slug = typer.prompt("Slug", default=default_slug)

    # Step 3: Input fields
    typer.echo("\nDefine input fields. Press Enter with empty name to finish.")
    input_fields: list[tuple[str, str]] = []
    while True:
        field_name = typer.prompt("  Field name", default="")
        if not field_name:
            break
        field_type = typer.prompt("  Type (string/number/integer/boolean)", default="number")
        input_fields.append((field_name, field_type))

    # Step 4: Output fields
    typer.echo("\nDefine output fields. Press Enter with empty name to finish.")
    output_fields: list[tuple[str, str, bool]] = []
    while True:
        field_name = typer.prompt("  Field name", default="")
        if not field_name:
            break
        field_type = typer.prompt("  Type (string/number/integer/boolean)", default="string")
        nullable_str = typer.prompt("  Nullable? [y/N]", default="N")
        nullable = nullable_str.strip().lower() in ("y", "yes")
        output_fields.append((field_name, field_type, nullable))

    # Step 5: Pattern selection
    _PATTERN_MAP = {"1": "linear", "2": "gated", "3": "scored", "4": "lookup"}
    typer.echo("\nSuggested patterns:")
    typer.echo("  1. Linear — input → transform → assignment → output")
    typer.echo("  2. Gated — input → eligibility split → [decline | continue] → merge → assignment → output")
    typer.echo("  3. Scored — input → transform (score) → rule (threshold) → assignment → output")
    typer.echo("  4. Lookup — input → transform → decision_table → assignment → output")
    pattern_str = typer.prompt("Pattern [1-4, or Enter to skip]", default="")

    # Step 6: Build JSON schemas
    input_schema: dict | None = None
    output_schema: dict | None = None

    if input_fields:
        properties: dict = {}
        for fname, ftype in input_fields:
            properties[fname] = {"type": ftype}
        input_schema = {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "type": "object",
            "properties": properties,
            "required": [f[0] for f in input_fields],
        }

    if output_fields:
        out_properties: dict = {}
        for fname, ftype, nullable in output_fields:
            if nullable:
                out_properties[fname] = {"anyOf": [{"type": ftype}, {"type": "null"}]}
            else:
                out_properties[fname] = {"type": ftype}
        output_schema = {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "type": "object",
            "properties": out_properties,
            "required": [f[0] for f in output_fields],
        }

    # Step 7: Create the flow (schemas applied in same round-trip via creation-time ETag)
    deps = _deps.build_deps()
    result = create_flow(
        deps.client,
        deps.cache_index,
        deps.workspace_id,
        slug,
        name,
        schema_in=input_schema,
        schema_out=output_schema,
        cache_manager=deps.cache_manager,
    )

    # Step 8: Apply template (all nodes sent in a single PATCH)
    chosen_template = _PATTERN_MAP.get(pattern_str)
    if chosen_template:
        user_id = deps.client._user_id or "cli-user"
        graph_body = TEMPLATES[chosen_template](user_id)
        replace_version(
            deps.client,
            deps.cache_index,
            deps.cache_manager,
            deps.workspace_id,
            slug,
            "v1",
            graph_body,
        )

    # Step 9: Print next steps (unless quiet or json)
    if not quiet and output != OutputFormat.json:
        typer.echo(f"\nFlow '{name}' created (slug: {slug})")
        if chosen_template:
            typer.echo(f"Template applied: {chosen_template}")
        typer.echo("\nNext steps:")
        typer.echo(f"  tktl nodes list {slug} v1          # see initial nodes")
        typer.echo(f'  tktl nodes add {slug} v1 --type <type> --name "Name" --after <node_id>')
        # Build a sample input snippet
        if input_fields:
            sample = "{" + ", ".join(f'"{f[0]}": ...' for f in input_fields[:2]) + "}"
        else:
            sample = "{}"
        typer.echo(f"  tktl flows run {slug} --version v1 --input '{sample}'")

    print_output(result, format=output, quiet=quiet)


@flows_app.command("explain")
@handle_errors
def flows_explain(
    slug: str = typer.Argument(..., help="Flow slug."),
    version: str = typer.Argument(..., help="Version name."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Explain a flow version in plain English."""
    deps = _deps.build_deps()
    result = explain_flow(
        deps.client,
        deps.cache_index,
        deps.cache_manager,
        deps.workspace_id,
        slug,
        version,
    )
    # For non-JSON output, print as readable text
    resolved_fmt = output
    if output == OutputFormat.auto:
        resolved_fmt = OutputFormat.table if sys.stdout.isatty() else OutputFormat.json

    if resolved_fmt != OutputFormat.json and not quiet:
        typer.echo(f"Flow: {result['flow']}  Version: {result['version']}")
        typer.echo(f"\nSummary: {result['summary']}")
        typer.echo("\nNodes:")
        for node in result.get("nodes", []):
            typer.echo(f"  - {node['name']} ({node['type']}): {node['description']}")
    else:
        print_output(result, format=output, quiet=quiet)


@flows_app.command("history")
@handle_errors
def flows_batch_history(
    slug: str = typer.Argument(..., help="Flow slug."),
    run_id: Optional[str] = typer.Option(None, "--run-id", help="Show details for a specific run."),
    query: Optional[str] = typer.Option(
        None, "--query", help="Extract a field from each result row. E.g. 'output.data.decision'."
    ),
    runs_dir: Optional[str] = typer.Option(None, "--runs-dir", hidden=True, help="Override runs directory."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """List or inspect past batch runs for a flow."""
    kwargs: dict = {}
    if runs_dir is not None:
        kwargs["runs_dir"] = Path(runs_dir)

    if run_id is not None and query is not None:
        # Extract a specific field from each result row
        results = get_batch_results(slug, run_id, **kwargs)
        extracted = [{"row_index": r.row_index, "value": extract_query(r.model_dump(), query)} for r in results]
        print_output(extracted, format=output, quiet=quiet)
    elif run_id is not None:
        result = get_batch_run(slug, run_id, **kwargs)
        print_output(result, format=output, quiet=quiet)
    else:
        result = list_batch_runs(slug, **kwargs)
        print_output(result, format=output, quiet=quiet)


@flows_app.command("diff")
@handle_errors
def flows_diff(
    slug: str = typer.Argument(..., help="Flow slug."),
    version_range: str = typer.Argument(
        ...,
        help="Version range: v1..v2",
        metavar="V1..V2",
    ),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Compare two versions of a flow and show logical differences."""
    if ".." not in version_range:
        raise UsageError("Version range must be in format 'v1..v2'")
    parts = version_range.split("..", 1)
    if len(parts) != 2 or not parts[0] or not parts[1]:
        raise UsageError("Version range must be in format 'v1..v2'")
    v1_name, v2_name = parts

    deps = _deps.build_deps()
    result = diff_versions(
        deps.client,
        deps.cache_index,
        deps.cache_manager,
        deps.workspace_id,
        slug,
        v1_name,
        v2_name,
    )
    print_output(result, format=output, quiet=quiet)
