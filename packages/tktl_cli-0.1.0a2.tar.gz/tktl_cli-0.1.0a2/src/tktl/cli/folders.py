"""CLI commands for flow folders: list, create."""

from __future__ import annotations

import typer

from tktl.cli import _deps
from tktl.cli._error_handler import handle_errors
from tktl.cli.output import OutputFormat, print_output
from tktl.ops.folders import create_folder, list_folders

folders_app = typer.Typer(name="folders", help="Manage flow folders.", no_args_is_help=True)


@folders_app.command("list")
@handle_errors
def folders_list(
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """List all folders in the workspace."""
    deps = _deps.build_deps()
    result = list_folders(deps.client, deps.workspace_id)
    print_output(result, format=output, quiet=quiet)


@folders_app.command("create")
@handle_errors
def folders_create(
    name: str = typer.Argument(..., help="Folder name."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Create a new flow folder in the workspace."""
    deps = _deps.build_deps()
    result = create_folder(deps.client, deps.workspace_id, name)
    print_output(result, format=output, quiet=quiet)
