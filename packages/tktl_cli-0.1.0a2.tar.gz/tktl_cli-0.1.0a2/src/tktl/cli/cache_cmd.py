"""CLI commands for cache management: refresh, clear, status."""

from __future__ import annotations

import typer

from tktl.cli import _deps
from tktl.cli._error_handler import handle_errors
from tktl.cli.output import OutputFormat, print_output
from tktl.ops.cache_ops import cache_status, clear_cache, refresh_cache

cache_app = typer.Typer(name="cache", help="Manage the local cache.", no_args_is_help=True)


@cache_app.command("refresh")
@handle_errors
def cache_refresh(
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Force-rebuild the entire cache."""
    deps = _deps.build_deps()
    refresh_cache(deps.client, deps.cache_index, deps.cache_manager, deps.workspace_id)
    print_output({"status": "ok", "message": "Cache refreshed successfully."}, format=output, quiet=quiet)


@cache_app.command("clear")
@handle_errors
def cache_clear(
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Delete all cached data."""
    deps = _deps.build_deps()
    clear_cache(deps.cache_manager)
    print_output({"status": "ok", "message": "Cache cleared."}, format=output, quiet=quiet)


@cache_app.command("status")
@handle_errors
def cache_status_cmd(
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Show cache status."""
    deps = _deps.build_deps()
    result = cache_status(deps.cache_manager)
    print_output(result, format=output, quiet=quiet)
