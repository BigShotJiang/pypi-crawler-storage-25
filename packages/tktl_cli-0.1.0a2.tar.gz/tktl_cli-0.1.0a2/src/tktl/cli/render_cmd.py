"""CLI command: tktl render — render Mermaid diagrams to PNG."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

import typer

from tktl.cli._error_handler import handle_errors
from tktl.models.errors import RenderError, UsageError
from tktl.ops.render import extract_mermaid_blocks, render_mermaid_png

_TMP_DIR = Path("/tmp/tktl")


@handle_errors
def render(
    file: Optional[Path] = typer.Argument(
        None,
        help="Markdown file to render (use - for stdin).",
    ),
    text: Optional[str] = typer.Option(
        None,
        "--text",
        "-t",
        help="Inline Mermaid code to render directly.",
    ),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Render Mermaid diagrams from a Markdown file, inline text, or stdin to PNG.

    Prints a clickable file:// path for each rendered diagram.

    \b
    Examples:
      tktl render plan.md
      tktl render --text "flowchart TD\\n  A --> B"
      cat plan.md | tktl render -
    """
    # --- Input resolution ---
    if text is not None and file is not None:
        raise UsageError("Provide either --text or a file argument, not both.")

    if text is not None:
        blocks = [text]
    elif file is not None and str(file) == "-":
        blocks = extract_mermaid_blocks(sys.stdin.read())
    elif file is not None:
        if not file.exists():
            raise UsageError(f"File not found: {file}")
        blocks = extract_mermaid_blocks(file.read_text())
    else:
        raise UsageError("Provide --text <mermaid>, a file path, or - for stdin.")

    if not blocks:
        if not quiet:
            typer.echo("No mermaid blocks found.")
        return

    for block in blocks:
        try:
            png_path = render_mermaid_png(block, _TMP_DIR)
            if not quiet:
                typer.echo(f"file://{png_path}")
        except RenderError as exc:
            typer.echo(f"Warning: render failed — {exc}", err=True)
