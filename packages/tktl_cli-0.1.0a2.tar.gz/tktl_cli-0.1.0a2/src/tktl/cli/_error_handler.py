"""Shared error handling for CLI commands.

Provides a decorator that catches TktlError, formats it, and exits
with the correct exit code.
"""

from __future__ import annotations

import functools
from typing import Any, Callable, TypeVar

from tktl.cli.output import OutputFormat, print_error
from tktl.models.errors import TktlError
from tktl.telemetry import set_source

F = TypeVar("F", bound=Callable[..., Any])


def handle_errors(fn: F) -> F:
    """Decorator that catches TktlError and exits with the correct code.

    When a TktlError is raised inside the decorated function, the error
    is formatted via print_error() and SystemExit is raised with the
    error's exit code.  This integrates cleanly with Typer/Click's
    CliRunner which catches SystemExit and uses its code.
    """

    @functools.wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        set_source("cli")
        try:
            return fn(*args, **kwargs)
        except TktlError as exc:
            # Determine output format from kwargs if present
            output_fmt = kwargs.get("output", OutputFormat.auto)
            if not isinstance(output_fmt, OutputFormat):
                output_fmt = OutputFormat.auto
            print_error(exc, format=output_fmt)
            raise SystemExit(exc.code)

    return wrapper  # type: ignore[return-value]
