"""CLI commands for nodes: list, describe, add, remove, edit."""

from __future__ import annotations

import json
import os
import subprocess
import tempfile
from pathlib import Path
from typing import Optional

import typer

from tktl.cli import _deps
from tktl.cli._error_handler import handle_errors
from tktl.cli._json_arg import parse_json_arg
from tktl.cli.output import OutputFormat, print_output
from tktl.models.errors import NotFoundError, UsageError
from tktl.ops.connections import list_connections
from tktl.ops.graph import add_node, remove_node
from tktl.ops.manual_review import build_default_review_meta, find_manual_review_connection
from tktl.ops.nodes import get_node, list_nodes, update_node
from tktl.ops.rule_parser import parse_natural_rule

nodes_app = typer.Typer(name="nodes", help="Manage version nodes.", no_args_is_help=True)


@nodes_app.command("list")
@handle_errors
def nodes_list(
    slug: str = typer.Argument(..., help="Flow slug."),
    version: str = typer.Argument(..., help="Version name."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """List all nodes in a version."""
    deps = _deps.build_deps()
    result = list_nodes(deps.client, deps.cache_index, deps.cache_manager, deps.workspace_id, slug, version)
    print_output(result, format=output, quiet=quiet)


@nodes_app.command("describe")
@handle_errors
def nodes_describe(
    slug: str = typer.Argument(..., help="Flow slug."),
    version: str = typer.Argument(..., help="Version name."),
    node_id: str = typer.Argument(..., help="Node ID."),
    section: Optional[str] = typer.Option(None, "--section", help="Only show this section (e.g. meta)."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Describe a single node."""
    deps = _deps.build_deps()
    result = get_node(
        deps.client, deps.cache_index, deps.cache_manager, deps.workspace_id, slug, version, node_id, section=section
    )
    print_output(result, format=output, quiet=quiet)


@nodes_app.command("add")
@handle_errors
def nodes_add(
    slug: str = typer.Argument(..., help="Flow slug."),
    version: str = typer.Argument(..., help="Version name."),
    node_type: str = typer.Option(
        ...,
        "--type",
        "-t",
        help="Node type: transform, split, rule, assignment, decision_table, "
        "scorecard, matrix_table, custom_connection, manual_review, subflow, loop.",
    ),
    name: str = typer.Option(..., "--name", "-n", help="Node display name."),
    after: str = typer.Option(..., "--after", "-a", help="Insert after this node ID."),
    src: Optional[str] = typer.Option(None, "--src", "-s", help="Transform source code or @file."),
    clause: Optional[str] = typer.Option(
        None,
        "--clause",
        help="Split clause: 'data.field < value'. Operators: <, <=, >, >=, ==, !=.",
    ),
    config: Optional[str] = typer.Option(None, "--config", "-c", help="Full node meta as JSON or @file."),
    connection: Optional[str] = typer.Option(
        None,
        "--connection",
        help="Connection ID or 'auto' to discover the workspace's manual review connection. "
        "For manual_review type only. Builds a default config when --config is not provided.",
    ),
    child_flow: Optional[str] = typer.Option(
        None,
        "--child-flow",
        help="Child flow slug. Required for subflow/loop node types. The child flow is found or created automatically.",
    ),
    target_list: Optional[str] = typer.Option(
        None,
        "--target-list",
        help="Loop node: expression producing the list to iterate (e.g. 'data.items').",
    ),
    output_list: Optional[str] = typer.Option(
        None,
        "--output-list",
        help="Loop node: expression for where to collect results (e.g. 'data.results').",
    ),
    rule: Optional[str] = typer.Option(
        None,
        "--rule",
        help="Natural language rule: 'if X op Y then field=val else field=val'",
    ),
    group: Optional[str] = typer.Option(
        None,
        "--group",
        help="Add the new node to this existing group ID.",
    ),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Add a node to a version's graph, wired after --after node."""
    deps = _deps.build_deps()
    config_data = parse_json_arg(config) if config is not None else None

    # Handle --rule option
    if rule is not None:
        if node_type != "rule":
            raise UsageError("--rule is only valid with --type rule")
        config_data = parse_natural_rule(rule)

    # Auto-build manual review config when --config is not provided
    if node_type == "manual_review" and config_data is None and connection is None:
        connection = "auto"
    if node_type == "manual_review" and connection is not None and config_data is None:
        if connection == "auto":
            conn_id, rc_id = find_manual_review_connection(deps.client, deps.workspace_id)
        else:
            conn_id = connection
            # Look up the resource_config_id from the connection
            conns = list_connections(deps.client, deps.workspace_id)
            rc_id = None
            for c in conns:
                if c.id == conn_id and c.resource_configs:
                    rc_id = c.resource_configs[0].id
                    break
            if rc_id is None:
                raise NotFoundError(f"Connection '{conn_id}' not found or has no resource configs")
        config_data = build_default_review_meta(conn_id, rc_id)

    result = add_node(
        deps.client,
        deps.cache_index,
        deps.cache_manager,
        deps.workspace_id,
        slug,
        version,
        node_type=node_type,
        name=name,
        after_node_id=after,
        src=src,
        clause=clause,
        config=config_data,
        child_flow_slug=child_flow,
        target_list=target_list,
        output_list=output_list,
        group_id=group,
    )
    print_output(result, format=output, quiet=quiet)


@nodes_app.command("edit")
@handle_errors
def nodes_edit(
    slug: str = typer.Argument(..., help="Flow slug."),
    version: str = typer.Argument(..., help="Version name."),
    node_id: str = typer.Argument(..., help="Node ID."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Open a node's config in your editor for in-place editing."""
    deps = _deps.build_deps()

    # Get current node config
    node = get_node(deps.client, deps.cache_index, deps.cache_manager, deps.workspace_id, slug, version, node_id)

    # Determine editor
    editor = os.environ.get("EDITOR", "vi")

    # Write meta to a temp file
    meta_data = node.meta if node.meta is not None else {}

    with tempfile.TemporaryDirectory() as tmp_dir:
        if node.type == "transform":
            # For transform nodes: edit just the src
            src_content = meta_data.get("src", "") if isinstance(meta_data, dict) else ""
            tmp_file = Path(tmp_dir) / f"{node_id}.py"
            tmp_file.write_text(src_content)
        else:
            # All other types: pretty JSON
            tmp_file = Path(tmp_dir) / f"{node_id}.json"
            tmp_file.write_text(json.dumps(meta_data, indent=2))

        # Open editor
        subprocess.call([editor, str(tmp_file)])

        # Read back
        new_content = tmp_file.read_text()

        if node.type == "transform":
            new_meta = {"src": new_content}
        else:
            new_meta = json.loads(new_content)

    # Update node
    result = update_node(
        deps.client,
        deps.cache_index,
        deps.cache_manager,
        deps.workspace_id,
        slug,
        version,
        node_id,
        new_meta,
    )
    print_output(result, format=output, quiet=quiet)


@nodes_app.command("remove")
@handle_errors
def nodes_remove(
    slug: str = typer.Argument(..., help="Flow slug."),
    version: str = typer.Argument(..., help="Version name."),
    node_id: str = typer.Argument(..., help="Node ID to remove."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Remove a node from the graph and rewire edges.

    For split nodes, also removes branch transforms and merge node.
    """
    deps = _deps.build_deps()
    result = remove_node(
        deps.client,
        deps.cache_index,
        deps.cache_manager,
        deps.workspace_id,
        slug,
        version,
        node_id,
    )
    print_output(result, format=output, quiet=quiet)
