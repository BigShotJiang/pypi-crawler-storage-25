from __future__ import annotations

import json
import os
from pathlib import Path

import typer

from tktl.config import Config

config_app = typer.Typer(name="config", help="Manage CLI configuration.", no_args_is_help=True)


def _config_dir() -> Path:
    return Path(os.environ.get("TKTL_CONFIG_DIR", str(Path.home() / ".tktl")))


@config_app.command("set")
def config_set(key: str, value: str) -> None:
    """Set a configuration value."""
    cfg = Config(config_dir=_config_dir())
    cfg.load()
    cfg.set(key, value)
    cfg.save()
    typer.echo(f"{key} = {value}")


@config_app.command("get")
def config_get(key: str) -> None:
    """Get a configuration value."""
    cfg = Config(config_dir=_config_dir())
    cfg.load()
    val = cfg.get(key)
    typer.echo(f"{key} = {val}")


@config_app.command("list")
def config_list() -> None:
    """List all configuration values."""
    cfg = Config(config_dir=_config_dir())
    cfg.load()
    typer.echo(json.dumps(cfg.get_all(), indent=2))
