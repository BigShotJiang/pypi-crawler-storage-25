"""CLI commands for node groups: list, describe, create, update, delete, add-nodes, remove-nodes."""

from __future__ import annotations

from typing import Optional

import typer

from tktl.cli import _deps
from tktl.cli._error_handler import handle_errors
from tktl.cli.output import OutputFormat, print_output
from tktl.ops.groups import (
    add_nodes_to_group,
    create_group,
    delete_group,
    get_group,
    list_groups,
    remove_nodes_from_group,
    update_group,
)

groups_app = typer.Typer(name="groups", help="Manage node groups.", no_args_is_help=True)


def _parse_node_ids(value: str) -> list[str]:
    """Split a comma-separated string of node IDs."""
    return [nid.strip() for nid in value.split(",") if nid.strip()]


@groups_app.command("list")
@handle_errors
def groups_list(
    slug: str = typer.Argument(..., help="Flow slug."),
    version: str = typer.Argument(..., help="Version name."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """List all node groups in a version."""
    deps = _deps.build_deps()
    result = list_groups(deps.client, deps.cache_index, deps.cache_manager, deps.workspace_id, slug, version)
    print_output(result, format=output, quiet=quiet)


@groups_app.command("describe")
@handle_errors
def groups_describe(
    slug: str = typer.Argument(..., help="Flow slug."),
    version: str = typer.Argument(..., help="Version name."),
    group_id: str = typer.Argument(..., help="Group ID."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Describe a single node group."""
    deps = _deps.build_deps()
    result = get_group(deps.client, deps.cache_index, deps.cache_manager, deps.workspace_id, slug, version, group_id)
    print_output(result, format=output, quiet=quiet)


@groups_app.command("create")
@handle_errors
def groups_create(
    slug: str = typer.Argument(..., help="Flow slug."),
    version: str = typer.Argument(..., help="Version name."),
    name: str = typer.Option(..., "--name", "-n", help="Group display name."),
    node_ids: str = typer.Option(..., "--node-ids", help="Comma-separated node IDs to include."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Create a new node group."""
    deps = _deps.build_deps()
    result = create_group(
        deps.client,
        deps.cache_index,
        deps.cache_manager,
        deps.workspace_id,
        slug,
        version,
        name=name,
        node_ids=_parse_node_ids(node_ids),
    )
    print_output(result, format=output, quiet=quiet)


@groups_app.command("update")
@handle_errors
def groups_update(
    slug: str = typer.Argument(..., help="Flow slug."),
    version: str = typer.Argument(..., help="Version name."),
    group_id: str = typer.Argument(..., help="Group ID."),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="New group name."),
    node_ids: Optional[str] = typer.Option(None, "--node-ids", help="Comma-separated new node IDs (replaces)."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Update a node group's name or members."""
    deps = _deps.build_deps()
    result = update_group(
        deps.client,
        deps.cache_index,
        deps.cache_manager,
        deps.workspace_id,
        slug,
        version,
        group_id,
        name=name,
        node_ids=_parse_node_ids(node_ids) if node_ids is not None else None,
    )
    print_output(result, format=output, quiet=quiet)


@groups_app.command("delete")
@handle_errors
def groups_delete(
    slug: str = typer.Argument(..., help="Flow slug."),
    version: str = typer.Argument(..., help="Version name."),
    group_id: str = typer.Argument(..., help="Group ID to delete."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Delete a node group (nodes are kept, only the grouping is removed)."""
    deps = _deps.build_deps()
    result = delete_group(deps.client, deps.cache_index, deps.cache_manager, deps.workspace_id, slug, version, group_id)
    print_output(result, format=output, quiet=quiet)


@groups_app.command("add-nodes")
@handle_errors
def groups_add_nodes(
    slug: str = typer.Argument(..., help="Flow slug."),
    version: str = typer.Argument(..., help="Version name."),
    group_id: str = typer.Argument(..., help="Group ID."),
    node_ids: str = typer.Option(..., "--node-ids", help="Comma-separated node IDs to add."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Add nodes to an existing group."""
    deps = _deps.build_deps()
    result = add_nodes_to_group(
        deps.client,
        deps.cache_index,
        deps.cache_manager,
        deps.workspace_id,
        slug,
        version,
        group_id,
        node_ids=_parse_node_ids(node_ids),
    )
    print_output(result, format=output, quiet=quiet)


@groups_app.command("remove-nodes")
@handle_errors
def groups_remove_nodes(
    slug: str = typer.Argument(..., help="Flow slug."),
    version: str = typer.Argument(..., help="Version name."),
    group_id: str = typer.Argument(..., help="Group ID."),
    node_ids: str = typer.Option(..., "--node-ids", help="Comma-separated node IDs to remove."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Remove nodes from a group."""
    deps = _deps.build_deps()
    result = remove_nodes_from_group(
        deps.client,
        deps.cache_index,
        deps.cache_manager,
        deps.workspace_id,
        slug,
        version,
        group_id,
        node_ids=_parse_node_ids(node_ids),
    )
    print_output(result, format=output, quiet=quiet)
