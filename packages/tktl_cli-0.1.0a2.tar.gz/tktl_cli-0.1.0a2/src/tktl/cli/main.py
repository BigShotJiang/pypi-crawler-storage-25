"""Root Typer application for tktl CLI.

Registers all sub-apps and provides global error handling.
"""

from __future__ import annotations

from importlib.metadata import version as pkg_version
from typing import Optional

import typer

from tktl.cli.auth import auth_app
from tktl.cli.cache_cmd import cache_app
from tktl.cli.comments import comments_app
from tktl.cli.config_cmd import config_app
from tktl.cli.connections import connections_app
from tktl.cli.datasets import datasets_app
from tktl.cli.flows import flows_app
from tktl.cli.folders import folders_app
from tktl.cli.groups import groups_app
from tktl.cli.init_cmd import init
from tktl.cli.nodes import nodes_app
from tktl.cli.output import OutputFormat, print_error
from tktl.cli.render_cmd import render
from tktl.cli.run import run_app
from tktl.cli.update import update_app
from tktl.cli.versions import versions_app
from tktl.models.errors import TktlError

app = typer.Typer(
    name="tktl",
    help="A developer- and agent-friendly CLI for managing Taktile decision flows.",
    no_args_is_help=True,
)

# --- Top-level commands ---
app.command("init")(init)
app.command("render")(render)

# --- Sub-apps ---
app.add_typer(config_app)
app.add_typer(auth_app)
app.add_typer(flows_app)
app.add_typer(versions_app)
app.add_typer(nodes_app)
app.add_typer(comments_app)
app.add_typer(datasets_app)
app.add_typer(update_app)
app.add_typer(run_app)
app.add_typer(cache_app)
app.add_typer(connections_app)
app.add_typer(folders_app)
app.add_typer(groups_app)

# --- Global state ---
_global_output: OutputFormat = OutputFormat.auto
_global_quiet: bool = False


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"tktl {pkg_version('tktl-cli')}")
        raise typer.Exit()


@app.callback()
def main(
    output: Optional[OutputFormat] = typer.Option(None, "--output", "-o", help="Global output format.", hidden=True),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress all informational output.", hidden=True),
    version: bool = typer.Option(
        False, "--version", "-V", help="Show version and exit.", callback=_version_callback, is_eager=True
    ),
) -> None:
    """tktl -- manage Taktile decision flows."""
    global _global_output, _global_quiet  # noqa: PLW0603
    if output is not None:
        _global_output = output
    _global_quiet = quiet


def handle_tktl_error(exc: TktlError, output_format: OutputFormat = OutputFormat.auto) -> None:
    """Format a TktlError and exit with the correct code."""
    print_error(exc, format=output_format)
    raise SystemExit(exc.code)
