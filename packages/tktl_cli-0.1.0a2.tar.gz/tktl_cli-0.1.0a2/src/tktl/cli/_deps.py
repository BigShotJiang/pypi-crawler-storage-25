"""Shared dependency construction for CLI commands.

All CLI commands need a TktlClient, CacheManager, and CacheIndex.
This module builds them from the config directory (TKTL_CONFIG_DIR env var
or default ~/.tktl).
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import NamedTuple

from tktl.api.client import TktlClient
from tktl.cache.index import CacheIndex
from tktl.cache.manager import CacheManager
from tktl.config import Config, derive_app_url
from tktl.models.errors import UsageError


def _config_dir() -> Path:
    return Path(os.environ.get("TKTL_CONFIG_DIR", str(Path.home() / ".tktl")))


class Deps(NamedTuple):
    client: TktlClient
    cache_manager: CacheManager
    cache_index: CacheIndex
    workspace_id: str
    org_id: str | None
    app_url: str | None


def _fetch_and_cache_org(client: TktlClient, config: Config, workspace_id: str) -> str | None:
    """Fetch organization_id from the workspace API and persist it in config."""
    try:
        resp = client.get(f"/api/v1/workspaces/{workspace_id}")
        if resp.status_code == 200:
            org_id = resp.json().get("organization_id")
            if org_id:
                config.set("org", org_id)
                config.save()
                return str(org_id)
    except Exception:
        pass
    return None


def build_deps() -> Deps:
    """Build all dependencies needed by ops functions from the config directory."""
    config_dir = _config_dir()
    cache_dir = config_dir / "cache"

    config = Config(config_dir)
    config.load()
    workspace_id = config.get("workspace")
    if not workspace_id:
        raise UsageError("No workspace configured. Run: tktl config set workspace <WORKSPACE_ID>")

    client = TktlClient(config_dir=config_dir)
    cache_manager = CacheManager(cache_dir)
    cache_index = CacheIndex(cache_dir)
    cache_index.load()

    # Resolve org_id — fetch from API and cache if not yet stored
    org_id: str | None = config.get("org")
    if not org_id:
        org_id = _fetch_and_cache_org(client, config, workspace_id)

    app_url = derive_app_url(config.get("flow_api_url"))

    return Deps(
        client=client,
        cache_manager=cache_manager,
        cache_index=cache_index,
        workspace_id=workspace_id,
        org_id=org_id,
        app_url=app_url,
    )
