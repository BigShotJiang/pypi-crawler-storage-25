"""CLI commands for comments: list, add, delete."""

from __future__ import annotations

from typing import Optional

import typer

from tktl.cli import _deps
from tktl.cli._error_handler import handle_errors
from tktl.cli.output import OutputFormat, print_output
from tktl.ops.comments import add_comment, delete_comment, list_comments

comments_app = typer.Typer(name="comments", help="Manage version comments.", no_args_is_help=True)


@comments_app.command("list")
@handle_errors
def comments_list(
    slug: str = typer.Argument(..., help="Flow slug."),
    version: str = typer.Argument(..., help="Version name."),
    node_id: Optional[str] = typer.Option(None, "--node", "-n", help="Filter to a specific node ID."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """List comments on a flow version."""
    deps = _deps.build_deps()
    result = list_comments(deps.client, deps.cache_index, deps.workspace_id, slug, version, node_id=node_id)
    print_output(result, format=output, quiet=quiet)


@comments_app.command("add")
@handle_errors
def comments_add(
    slug: str = typer.Argument(..., help="Flow slug."),
    version: str = typer.Argument(..., help="Version name."),
    content: str = typer.Argument(..., help="Comment text."),
    node_id: Optional[str] = typer.Option(None, "--node", "-n", help="Attach to a specific node ID."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Add a comment to a flow version or node."""
    deps = _deps.build_deps()
    result = add_comment(deps.client, deps.cache_index, deps.workspace_id, slug, version, content, node_id=node_id)
    print_output(result, format=output, quiet=quiet)


@comments_app.command("delete")
@handle_errors
def comments_delete(
    comment_id: str = typer.Argument(..., help="Comment ID to delete."),
    output: OutputFormat = typer.Option(OutputFormat.auto, "--output", "-o", help="Output format."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress output."),
) -> None:
    """Delete a comment by ID."""
    deps = _deps.build_deps()
    delete_comment(deps.client, comment_id)
    print_output({"status": "deleted", "comment_id": comment_id}, format=output, quiet=quiet)
