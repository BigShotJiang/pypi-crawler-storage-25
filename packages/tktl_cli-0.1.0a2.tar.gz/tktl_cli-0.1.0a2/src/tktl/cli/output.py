"""Shared output formatting for all CLI commands.

Supports JSON (machine-parseable), table (human-readable via Rich), and
auto-detection based on whether stdout is a TTY.
"""

from __future__ import annotations

import json
import sys
from enum import Enum
from typing import Any

from pydantic import BaseModel
from rich.console import Console
from rich.table import Table

from tktl.models.errors import TktlError


class OutputFormat(str, Enum):
    """Supported CLI output formats."""

    auto = "auto"
    json = "json"
    table = "table"


def _resolve_format(fmt: OutputFormat) -> OutputFormat:
    """Resolve ``auto`` to either ``json`` or ``table`` based on TTY detection."""
    if fmt is not OutputFormat.auto:
        return fmt
    return OutputFormat.table if sys.stdout.isatty() else OutputFormat.json


def _serialize(data: Any) -> Any:
    """Convert *data* to plain Python objects suitable for ``json.dumps``.

    Handles Pydantic models (single or in a list) by calling ``.model_dump()``.
    """
    if isinstance(data, BaseModel):
        return data.model_dump()
    if isinstance(data, list):
        return [item.model_dump() if isinstance(item, BaseModel) else item for item in data]
    return data


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def print_output(data: Any, *, format: OutputFormat, quiet: bool = False) -> None:  # noqa: A002
    """Print *data* to stdout in the requested format.

    Parameters
    ----------
    data:
        A dict, list of dicts, Pydantic model, or list of Pydantic models.
    format:
        The desired output format (``auto``, ``json``, ``table``).
    quiet:
        If ``True``, suppress all output.
    """
    if quiet:
        return

    resolved = _resolve_format(format)

    if resolved is OutputFormat.json:
        _print_json(data)
    else:
        _print_table(data)


def print_error(error: TktlError, *, format: OutputFormat) -> None:  # noqa: A002
    """Print *error* to stderr in the requested format.

    Parameters
    ----------
    error:
        A :class:`TktlError` (or subclass) instance.
    format:
        The desired output format (``auto``, ``json``, ``table``).
    """
    resolved = _resolve_format(format)

    if resolved is OutputFormat.json:
        _print_error_json(error)
    else:
        _print_error_table(error)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _print_json(data: Any) -> None:
    serialized = _serialize(data)
    print(json.dumps(serialized, indent=2))


def _print_table(data: Any) -> None:
    console = Console()
    serialized = _serialize(data)

    if isinstance(serialized, dict):
        _render_key_value_table(console, serialized)
    elif isinstance(serialized, list):
        _render_list_table(console, serialized)
    else:
        # Fallback: just print the string representation
        console.print(str(serialized))


def _render_key_value_table(console: Console, data: dict[str, Any]) -> None:
    """Render a single dict as a two-column key / value table."""
    table = Table(show_header=True, show_lines=False)
    table.add_column("Key", style="bold")
    table.add_column("Value")
    for key, value in data.items():
        table.add_row(str(key), str(value))
    console.print(table)


def _render_list_table(console: Console, data: list[dict[str, Any]]) -> None:
    """Render a list of dicts as a columnar table."""
    if not data:
        return

    # Derive columns from the first row's keys
    columns = list(data[0].keys())
    table = Table(show_header=True, show_lines=False)
    for col in columns:
        table.add_column(col, style="bold" if col == columns[0] else "")
    for row in data:
        table.add_row(*(str(row.get(col, "")) for col in columns))
    console.print(table)


def _print_error_json(error: TktlError) -> None:
    payload = {
        "error": {
            "code": error.code,
            "type": type(error).__name__,
            "message": str(error),
        }
    }
    print(json.dumps(payload, indent=2), file=sys.stderr)


def _print_error_table(error: TktlError) -> None:
    console = Console(stderr=True)
    console.print(f"[bold red]Error:[/bold red] {error}")
