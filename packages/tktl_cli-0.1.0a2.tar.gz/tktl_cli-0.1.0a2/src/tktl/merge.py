"""RFC 7396 JSON Merge Patch — client-side deep merge utility."""

from __future__ import annotations

from copy import deepcopy
from typing import Any


def deep_merge(base: dict[str, Any], patch: dict[str, Any]) -> dict[str, Any]:
    """Apply an RFC 7396 JSON Merge Patch to *base* and return a new dict.

    Rules:
    - ``None`` values in *patch* delete the corresponding key from *base*.
    - Missing keys in *patch* are preserved from *base*.
    - Arrays are **replaced**, not merged.
    - Nested dicts are merged recursively.
    - Neither *base* nor *patch* is mutated; a fresh dict is returned.
    """
    result = deepcopy(base)
    for key, value in patch.items():
        if value is None:
            result.pop(key, None)
        elif isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = deepcopy(value)
    return result
