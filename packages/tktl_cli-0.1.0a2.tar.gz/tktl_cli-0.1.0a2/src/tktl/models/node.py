from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict


class NodeSummary(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: str
    name: str
    type: str
    group_id: str | None = None
    group_name: str | None = None


class NodeDetail(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: str
    name: str
    type: str
    meta: dict[str, Any] | None = None
