class TktlError(Exception):
    """Base exception for all tktl errors."""

    code: int = 1

    def __init__(self, message: str) -> None:
        super().__init__(message)


class UsageError(TktlError):
    """Invalid usage or bad arguments."""

    code: int = 2


class AuthError(TktlError):
    """Authentication failure."""

    code: int = 3


class NotFoundError(TktlError):
    """Resource not found (bad slug, version name, or node ID)."""

    code: int = 4


class ConflictError(TktlError):
    """ETag mismatch or lock conflict."""

    code: int = 5


class NetworkError(TktlError):
    """Network error or API unreachable."""

    code: int = 6


class RenderError(TktlError):
    """Mermaid diagram rendering failed (network or encoding error)."""

    code: int = 10
