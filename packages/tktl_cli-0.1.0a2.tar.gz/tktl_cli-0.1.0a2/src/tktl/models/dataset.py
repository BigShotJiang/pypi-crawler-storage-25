"""Data models for dataset operations."""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict


class ColumnGroup(str, Enum):
    """Dataset column group."""

    input_columns = "input_columns"
    output_columns = "output_columns"
    mock_columns = "mock_columns"
    meta_columns = "meta_columns"
    outcome_columns = "outcome_columns"


class ColumnType(str, Enum):
    """Dataset column data type."""

    string = "string"
    boolean = "boolean"
    number = "number"
    integer = "integer"
    object = "object"
    array = "array"
    datetime = "datetime"
    date = "date"
    any = "any"
    enum = "enum"
    files = "files"


class DatasetPurpose(str, Enum):
    """Purpose of a dataset."""

    test_run = "test_run"
    job_source = "job_source"
    simulation = "simulation"


class DatasetSource(str, Enum):
    """How a dataset was created."""

    file = "file"
    history = "history"
    scratch = "scratch"
    simulation_failures = "simulation_failures"


class DatasetColumn(BaseModel):
    """A single column definition in a dataset."""

    name: str
    desired_type: ColumnType
    use_subflow_mocks: bool = False


class DatasetRow(BaseModel):
    """A single row in a dataset."""

    model_config = ConfigDict(extra="ignore")

    id: str
    input_data: dict[str, Any]
    output_data: dict[str, Any] | None = None
    mock_data: dict[str, Any] | None = None
    meta_data: dict[str, Any] | None = None
    outcome_data: dict[str, Any] | None = None


class Dataset(BaseModel):
    """Full dataset with column definitions and metadata."""

    model_config = ConfigDict(extra="ignore")

    id: str
    name: str
    flow_id: str
    etag: str
    created_at: str
    updated_at: str
    source: DatasetSource
    purpose: DatasetPurpose = DatasetPurpose.test_run
    input_columns: list[DatasetColumn]
    output_columns: list[DatasetColumn]
    mock_columns: list[DatasetColumn]
    meta_columns: list[DatasetColumn] | None = None
    outcome_columns: list[DatasetColumn] | None = None
    row_count: int | None = None


class DatasetSummary(BaseModel):
    """Lightweight summary for listing datasets."""

    model_config = ConfigDict(extra="ignore")

    id: str
    name: str
    flow_id: str
    source: DatasetSource
    purpose: DatasetPurpose
    row_count: int | None = None
    created_at: str
    updated_at: str


class TypeMismatch(BaseModel):
    """A column that exists in both dataset and schema but with different types."""

    name: str
    dataset_type: ColumnType
    schema_type: ColumnType


class SchemaDiff(BaseModel):
    """Result of comparing dataset columns against a flow version's input schema."""

    missing_columns: list[DatasetColumn]
    extra_columns: list[DatasetColumn]
    type_mismatches: list[TypeMismatch]


class DatasetFileUpload(BaseModel):
    """A file upload job for creating a dataset from a file."""

    model_config = ConfigDict(extra="ignore")

    id: str
    flow_id: str
    file_name: str
    status: str
    s3_presigned_url: str
    s3_presigned_fields: dict[str, str]
    dataset_id: str | None = None
    error_metadata: str | None = None
    created_at: str
    updated_at: str
