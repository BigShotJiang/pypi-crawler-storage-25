from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class FolderSummary(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: str
    name: str


class FolderDetail(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: str
    name: str
    workspace_id: str
    created_at: str | None = None
    updated_at: str | None = None
