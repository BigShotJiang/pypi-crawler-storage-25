from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class FlowSummary(BaseModel):
    model_config = ConfigDict(extra="ignore")

    slug: str
    id: str
    name: str


class FlowDetail(BaseModel):
    model_config = ConfigDict(extra="ignore")

    slug: str
    id: str
    name: str
    workspace_id: str
    folder_id: str | None = None
    created_at: str | None = None
    updated_at: str | None = None
    default_version: str | None = None
    default_sandbox_version: str | None = None
