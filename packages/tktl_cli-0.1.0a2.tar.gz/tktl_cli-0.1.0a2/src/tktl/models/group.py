from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict


class GroupSummary(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: str
    name: str = ""
    node_ids: list[str] = []


class GroupDetail(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: str
    name: str = ""
    node_ids: list[str] = []
    meta: dict[str, Any] | None = None
