"""Pydantic models for structured flow version diffs."""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict


class ChangeKind(str, Enum):
    added = "added"
    removed = "removed"
    modified = "modified"


class FieldChange(BaseModel):
    """A single semantic change within a node's meta.

    The ``field`` value should be descriptive enough for downstream consumers
    to narrate (e.g. ``"factor 'bureau_score' weight"`` rather than just
    ``"weight"``).
    """

    model_config = ConfigDict(extra="ignore")

    field: str
    old: Any = None
    new: Any = None
    kind: ChangeKind


class ParameterChange(BaseModel):
    """A flow-level parameter change (thresholds, constants)."""

    model_config = ConfigDict(extra="ignore")

    name: str
    kind: ChangeKind
    old_value: Any = None
    new_value: Any = None


class SchemaChange(BaseModel):
    """A change to the flow's input or output schema."""

    model_config = ConfigDict(extra="ignore")

    schema_type: str  # "input" or "output"
    kind: ChangeKind
    field: str
    old: Any = None
    new: Any = None


class StructuralChange(BaseModel):
    """A node added, removed, or type-changed."""

    model_config = ConfigDict(extra="ignore")

    node_name: str
    kind: ChangeKind
    node_type: str | None = None
    detail: str | None = None
    v1_node_id: str | None = None
    v2_node_id: str | None = None


class NodeLogicChange(BaseModel):
    """Semantic changes within a single node's configuration."""

    model_config = ConfigDict(extra="ignore")

    node_name: str
    node_type: str
    v1_node_id: str | None = None
    v2_node_id: str | None = None
    changes: list[FieldChange]


class IntegrationChange(BaseModel):
    """A change to a connector/provider node."""

    model_config = ConfigDict(extra="ignore")

    node_name: str
    kind: ChangeKind
    provider: str | None = None
    resource: str | None = None
    v1_node_id: str | None = None
    v2_node_id: str | None = None
    changes: list[FieldChange] = []


class FlowDiff(BaseModel):
    """Top-level diff result between two flow versions."""

    model_config = ConfigDict(extra="ignore")

    flow_slug: str
    v1_name: str
    v2_name: str
    parameter_changes: list[ParameterChange] = []
    schema_changes: list[SchemaChange] = []
    structural_changes: list[StructuralChange] = []
    logic_changes: list[NodeLogicChange] = []
    integration_changes: list[IntegrationChange] = []

    @property
    def has_changes(self) -> bool:
        return bool(
            self.parameter_changes
            or self.schema_changes
            or self.structural_changes
            or self.logic_changes
            or self.integration_changes
        )

    def summary(self) -> str:
        lines = [f"{self.flow_slug}: {self.v1_name} → {self.v2_name}"]
        if not self.has_changes:
            lines.append("  (no changes)")
            return "\n".join(lines)

        for p in self.parameter_changes:
            lines.append(f"  ~ parameter {p.name!r} ({p.kind.value}): {p.old_value!r} → {p.new_value!r}")
        for s in self.schema_changes:
            lines.append(f"  ~ {s.schema_type} schema {s.kind.value} {s.field!r}")
        for st in self.structural_changes:
            label = {"added": "+", "removed": "-", "modified": "~"}.get(st.kind.value, "?")
            lines.append(f"  {label} node {st.node_name!r} ({st.node_type or 'unknown'}) {st.kind.value}")
        for lg in self.logic_changes:
            lines.append(f"  ~ node {lg.node_name!r} ({lg.node_type}): {len(lg.changes)} change(s)")
        for ic in self.integration_changes:
            lines.append(f"  ~ integration {ic.node_name!r} ({ic.kind.value})")
        return "\n".join(lines)
