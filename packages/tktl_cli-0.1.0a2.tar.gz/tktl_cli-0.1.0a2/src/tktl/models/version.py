from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict


class VersionSummary(BaseModel):
    model_config = ConfigDict(extra="ignore")

    name: str
    id: str
    status: str


class VersionDetail(BaseModel):
    model_config = ConfigDict(extra="ignore")

    name: str
    id: str
    status: str
    etag: str | None = None
    created_at: str | None = None
    updated_at: str | None = None
    parameters: list[dict[str, Any]] | None = None
    input_schema: dict[str, Any] | None = None
    output_schema: dict[str, Any] | None = None
    graph: dict[str, Any] | None = None
