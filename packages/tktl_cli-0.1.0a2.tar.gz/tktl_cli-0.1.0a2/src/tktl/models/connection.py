from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class ResourceConfigSummary(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: str
    name: str
    resource: str


class ConnectionSummary(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: str
    name: str
    provider: str
    resource_configs: list[ResourceConfigSummary] = []


class ConnectionDetail(BaseModel):
    """Full connection response from create."""

    model_config = ConfigDict(extra="ignore")

    id: str
    name: str
    provider: str
    is_sandbox: bool
    resource_configs: list[ResourceConfigSummary] = []


class ResourceConfigDetail(BaseModel):
    """Resource config response from create."""

    model_config = ConfigDict(extra="ignore")

    id: str
    name: str
    resource: str
    connection_config_id: str
