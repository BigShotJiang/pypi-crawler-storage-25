"""Data models for batch run operations."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class BatchRowResult(BaseModel):
    """Result of a single row in a batch run."""

    row_index: int
    input: dict[str, Any]
    output: dict[str, Any] | None
    error: str | None
    duration_ms: int
    timestamp: str


class BatchRunMeta(BaseModel):
    """Metadata for a batch run."""

    run_id: str
    flow_slug: str
    env: str
    version: str | None
    source_type: str
    source: str
    source_hash: str
    dataset_etag: str | None = None
    concurrency: int
    total_rows: int
    succeeded: int
    failed: int
    started_at: str
    completed_at: str | None
    duration_ms: int | None


class BatchRunSummary(BaseModel):
    """Lightweight summary for listing batch runs."""

    run_id: str
    source_type: str
    source: str
    source_hash: str
    total_rows: int
    succeeded: int
    failed: int
    started_at: str
    duration_ms: int | None


class BatchResult(BaseModel):
    """Return type from run_batch() — metadata plus path to results."""

    meta: BatchRunMeta
    results_path: str
