"""CacheManager — hierarchical file-based cache with per-node decomposition.

Directory layout (rooted at ``~/.tktl/cache/``)::

    flows/{flow_id}/
        metadata.json
        versions/{version_id}/
            metadata.json      (version metadata + etag, no graph)
            full.json          (full version snapshot)
            nodes/
                _index.json    (node list: [{id, name, type}])
                {node_id}.json (individual node)
"""

from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any

from tktl.cache.freshness import cached_at_now


class CacheManager:
    """Read/write cache files following the hierarchical layout."""

    def __init__(self, cache_dir: Path) -> None:
        self._cache_dir = cache_dir

    # ------------------------------------------------------------------
    # Path helpers
    # ------------------------------------------------------------------

    def _flow_dir(self, flow_id: str) -> Path:
        return self._cache_dir / "flows" / flow_id

    def _version_dir(self, flow_id: str, version_id: str) -> Path:
        return self._flow_dir(flow_id) / "versions" / version_id

    def _nodes_dir(self, flow_id: str, version_id: str) -> Path:
        return self._version_dir(flow_id, version_id) / "nodes"

    # ------------------------------------------------------------------
    # Generic JSON helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _write_json(path: Path, data: dict[str, Any] | list[dict[str, Any]]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            json.dump(data, f, indent=2)

    @staticmethod
    def _read_json_dict(path: Path) -> dict[str, Any] | None:
        if not path.exists():
            return None
        with open(path) as f:
            result = json.load(f)
        if isinstance(result, dict):
            return result
        return None

    @staticmethod
    def _read_json_list(path: Path) -> list[dict[str, Any]] | None:
        if not path.exists():
            return None
        with open(path) as f:
            result = json.load(f)
        if isinstance(result, list):
            return result
        return None

    # ------------------------------------------------------------------
    # Flow metadata
    # ------------------------------------------------------------------

    def write_flow_metadata(self, flow_id: str, metadata: dict[str, Any]) -> None:
        """Write flow-level metadata to ``flows/{flow_id}/metadata.json``."""
        payload = {**metadata, "_cached_at": cached_at_now()}
        self._write_json(self._flow_dir(flow_id) / "metadata.json", payload)

    def read_flow_metadata(self, flow_id: str) -> dict[str, Any] | None:
        """Read flow-level metadata, or ``None`` if not cached."""
        return self._read_json_dict(self._flow_dir(flow_id) / "metadata.json")

    # ------------------------------------------------------------------
    # Version write (decomposition)
    # ------------------------------------------------------------------

    def write_version(
        self,
        version_id: str,
        flow_id: str,
        version_data: dict[str, Any],
    ) -> None:
        """Write a complete version to the cache.

        This creates:
        - ``metadata.json`` — version metadata + etag (no graph).
        - ``full.json`` — full version snapshot.
        - ``nodes/_index.json`` — lightweight node list.
        - ``nodes/{node_id}.json`` — one file per node.
        """
        ts = cached_at_now()
        ver_dir = self._version_dir(flow_id, version_id)

        # --- metadata.json (strip graph) ---
        metadata = {k: v for k, v in version_data.items() if k != "graph"}
        metadata["_cached_at"] = ts
        self._write_json(ver_dir / "metadata.json", metadata)

        # --- full.json ---
        full = {**version_data, "_cached_at": ts}
        self._write_json(ver_dir / "full.json", full)

        # --- per-node files ---
        graph = version_data.get("graph")
        nodes_dict: dict[str, Any] = {}
        if graph is not None:
            raw_nodes = graph.get("nodes", {})
            # Handle both v1 (list) and v2 (dict) formats
            if isinstance(raw_nodes, list):
                nodes_dict = {n["id"]: n for n in raw_nodes}
            else:
                nodes_dict = raw_nodes

        nodes_dir = self._nodes_dir(flow_id, version_id)

        # _index.json
        index_entries: list[dict[str, str]] = []
        for node_id, node_data in nodes_dict.items():
            index_entries.append(
                {
                    "id": node_data.get("id", node_id),
                    "name": node_data.get("name", ""),
                    "type": node_data.get("type", ""),
                }
            )
            # individual node file
            node_payload = {**node_data, "_cached_at": ts}
            self._write_json(nodes_dir / f"{node_id}.json", node_payload)

        self._write_json(nodes_dir / "_index.json", index_entries)

    # ------------------------------------------------------------------
    # Version reads
    # ------------------------------------------------------------------

    def read_full_version(self, version_id: str, flow_id: str) -> dict[str, Any] | None:
        """Return the full version snapshot (including graph), or ``None`` if not cached."""
        return self._read_json_dict(self._version_dir(flow_id, version_id) / "full.json")

    def read_version_metadata(self, version_id: str, flow_id: str) -> dict[str, Any] | None:
        """Return version metadata (no graph) + etag, or ``None``."""
        return self._read_json_dict(self._version_dir(flow_id, version_id) / "metadata.json")

    def read_node_index(self, version_id: str, flow_id: str) -> list[dict[str, Any]] | None:
        """Return the node index ``[{id, name, type}]``, or ``None``."""
        return self._read_json_list(self._nodes_dir(flow_id, version_id) / "_index.json")

    def read_node(self, version_id: str, flow_id: str, node_id: str) -> dict[str, Any] | None:
        """Return a single cached node, or ``None``."""
        return self._read_json_dict(self._nodes_dir(flow_id, version_id) / f"{node_id}.json")

    # ------------------------------------------------------------------
    # Node write
    # ------------------------------------------------------------------

    def write_node(
        self,
        version_id: str,
        flow_id: str,
        node_id: str,
        node_data: dict[str, Any],
    ) -> None:
        """Write (or overwrite) a single node cache file."""
        payload = {**node_data, "_cached_at": cached_at_now()}
        self._write_json(
            self._nodes_dir(flow_id, version_id) / f"{node_id}.json",
            payload,
        )

    # ------------------------------------------------------------------
    # Invalidation
    # ------------------------------------------------------------------

    def invalidate_version(self, version_id: str, flow_id: str) -> None:
        """Delete the entire version cache directory."""
        ver_dir = self._version_dir(flow_id, version_id)
        if ver_dir.exists():
            shutil.rmtree(ver_dir)

    def clear_all(self) -> None:
        """Delete the entire cache directory contents."""
        if self._cache_dir.exists():
            shutil.rmtree(self._cache_dir)
