"""Freshness logic for the hierarchical cache.

Each cached file stores a ``_cached_at`` ISO timestamp.  The cache considers
data **stale** after a configurable TTL (default: 5 minutes / 300 seconds).
"""

from __future__ import annotations

from datetime import datetime, timezone


def is_fresh(cached_at: str, ttl_seconds: int = 300) -> bool:
    """Return ``True`` if *cached_at* is within *ttl_seconds* of now.

    Parameters
    ----------
    cached_at:
        An ISO-8601 timestamp string (must be timezone-aware or treated as UTC).
    ttl_seconds:
        Number of seconds before cached data is considered stale.  Defaults to
        300 (5 minutes).
    """
    dt = datetime.fromisoformat(cached_at)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    now = datetime.now(timezone.utc)
    elapsed = (now - dt).total_seconds()
    return elapsed < ttl_seconds


def cached_at_now() -> str:
    """Return the current UTC time as an ISO-8601 string."""
    return datetime.now(timezone.utc).isoformat()
