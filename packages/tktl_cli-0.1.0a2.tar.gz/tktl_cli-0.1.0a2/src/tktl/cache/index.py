"""CacheIndex — lightweight slug-to-ID lookup table.

Manages ``~/.tktl/cache/index.json``.  Loaded once per CLI invocation to
resolve flow slugs to flow IDs and version names to version IDs.

Schema::

    {
        "workspace_id": "ws_abc",
        "flows": {
            "<slug>": {
                "id": "<flow_id>",
                "versions": {
                    "<version_name>": "<version_id>",
                    ...
                }
            },
            ...
        },
        "updated_at": "<ISO timestamp>"
    }
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from tktl.cache.freshness import cached_at_now


class CacheIndex:
    """In-memory representation of ``index.json`` with load/save methods."""

    def __init__(self, cache_dir: Path) -> None:
        self._cache_dir = cache_dir
        self._index_file = cache_dir / "index.json"

        self.workspace_id: str | None = None
        self.flows: dict[str, dict[str, Any]] = {}
        self.updated_at: str | None = None

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def load(self) -> None:
        """Load the index from disk.  If the file does not exist, state
        remains at its initial (empty) values."""
        if not self._index_file.exists():
            return
        with open(self._index_file) as f:
            data = json.load(f)
        self.workspace_id = data.get("workspace_id")
        self.flows = data.get("flows", {})
        self.updated_at = data.get("updated_at")

    def save(self) -> None:
        """Persist the current index to disk, creating directories as needed."""
        self._cache_dir.mkdir(parents=True, exist_ok=True)
        self.updated_at = cached_at_now()
        payload = {
            "workspace_id": self.workspace_id,
            "flows": self.flows,
            "updated_at": self.updated_at,
        }
        with open(self._index_file, "w") as f:
            json.dump(payload, f, indent=2)

    # ------------------------------------------------------------------
    # Resolution helpers
    # ------------------------------------------------------------------

    def resolve_flow_id(self, slug: str) -> str | None:
        """Return the flow ID for *slug*, or ``None`` if not cached."""
        entry = self.flows.get(slug)
        if entry is None:
            return None
        return entry.get("id")

    def resolve_version_id(self, slug: str, version_name: str) -> str | None:
        """Return the version ID for *slug* / *version_name*, or ``None``."""
        entry = self.flows.get(slug)
        if entry is None:
            return None
        versions = entry.get("versions", {})
        return versions.get(version_name)

    # ------------------------------------------------------------------
    # Mutation helpers
    # ------------------------------------------------------------------

    def update_flow(self, slug: str, flow_id: str, versions: dict[str, str]) -> None:
        """Create or overwrite the index entry for *slug*."""
        self.flows[slug] = {
            "id": flow_id,
            "versions": dict(versions),
        }

    def update_version(self, slug: str, version_name: str, version_id: str) -> None:
        """Add or update a single version mapping within an existing flow entry.

        If *slug* is not present in the index this is a silent no-op — the
        caller should use :meth:`update_flow` first.
        """
        entry = self.flows.get(slug)
        if entry is None:
            return
        entry.setdefault("versions", {})[version_name] = version_id
