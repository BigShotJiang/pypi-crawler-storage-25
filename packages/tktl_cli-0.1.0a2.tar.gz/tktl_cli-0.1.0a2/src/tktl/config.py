from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any

_DEFAULTS: dict[str, Any] = {
    "org": None,
    "workspace": None,
    "env": "sandbox",
    "flow_api_url": None,
    "taktile_api_url": None,
    "telemetry": True,
    "posthog_api_key": None,
    "posthog_host": None,
}

# Matches https://flow-api.<env>.cp.taktile.com  (dev, stg, …)
_FLOW_API_URL_ENV_RE = re.compile(r"https://flow-api\.([^.]+)\.cp\.taktile\.com")
# Matches https://flow-api.cp.taktile.com  (prod — no env segment)
_FLOW_API_URL_PROD_RE = re.compile(r"https://flow-api\.cp\.taktile\.com")

# Environments that map to no subdomain in the app URL (prod)
_PROD_ENV_ALIASES = frozenset({"prod", "production"})


def derive_app_url(flow_api_url: str | None) -> str | None:
    """Derive the Taktile app base URL from the flow-api URL.

    Environments:
    - ``dev``  → ``https://app.dev.taktile.com``
    - ``stg``  → ``https://app.stg.taktile.com``
    - prod (no env segment, or explicit ``prod``) → ``https://app.taktile.com``

    Returns *None* when *flow_api_url* is absent or doesn't match either pattern.
    """
    if not flow_api_url:
        return None
    # Prod — no env segment
    if _FLOW_API_URL_PROD_RE.match(flow_api_url):
        return "https://app.taktile.com"
    # Non-prod — env segment present
    m = _FLOW_API_URL_ENV_RE.match(flow_api_url)
    if not m:
        return None
    env = m.group(1)
    if env in _PROD_ENV_ALIASES:
        return "https://app.taktile.com"
    return f"https://app.{env}.taktile.com"


_DEFAULT_CONFIG_DIR = Path.home() / ".tktl"


class Config:
    def __init__(self, config_dir: Path = _DEFAULT_CONFIG_DIR) -> None:
        self._dir = config_dir
        self._file = config_dir / "config.json"
        self._data: dict[str, Any] = dict(_DEFAULTS)

    def load(self) -> None:
        if self._file.exists():
            with open(self._file) as f:
                stored = json.load(f)
            self._data = {**_DEFAULTS, **stored}

    def save(self) -> None:
        self._dir.mkdir(parents=True, exist_ok=True)
        with open(self._file, "w") as f:
            json.dump(self._data, f, indent=2)

    def get(self, key: str) -> Any:
        return self._data.get(key)

    def set(self, key: str, value: Any) -> None:
        self._data[key] = value

    def get_all(self) -> dict[str, Any]:
        return dict(self._data)


class Credentials:
    def __init__(self, config_dir: Path = _DEFAULT_CONFIG_DIR) -> None:
        self._dir = config_dir
        self._file = config_dir / "credentials.json"
        self.api_key: str | None = None
        self.user_id: str | None = None

    def load(self) -> None:
        if self._file.exists():
            with open(self._file) as f:
                data = json.load(f)
            self.api_key = data.get("api_key")
            self.user_id = data.get("user_id")

    def store(self, api_key: str, user_id: str | None = None) -> None:
        self._dir.mkdir(parents=True, exist_ok=True)
        self.api_key = api_key
        self.user_id = user_id
        payload: dict[str, Any] = {"api_key": api_key}
        if user_id:
            payload["user_id"] = user_id
        with open(self._file, "w") as f:
            json.dump(payload, f, indent=2)
        os.chmod(self._file, 0o600)

    def delete(self) -> None:
        self.api_key = None
        self.user_id = None
        if self._file.exists():
            self._file.unlink()
