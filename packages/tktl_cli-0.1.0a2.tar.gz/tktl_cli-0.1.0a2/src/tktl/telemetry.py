"""PostHog telemetry — estimate tokens, track ops, identify users."""

from __future__ import annotations

import functools
import hashlib
import json
import os
import platform
from pathlib import Path
import threading
import time
from typing import Any

import posthog
from pydantic import BaseModel

from tktl.config import Config, Credentials


class _State:
    """Module-level mutable state, kept in a single object for easy reset."""

    def __init__(self) -> None:
        self.client: Any = None
        self.distinct_id: str | None = None
        self.disabled: bool = False
        self.source: str = "library"
        self._lock = threading.Lock()


_state = _State()

_DEFAULT_API_KEY = "phc_i2zXufGcAORNmK3SSLkZPPuay4wxKMZ25SfGyMmlUZ4"
_DEFAULT_HOST = "https://eu.i.posthog.com"
_TKTL_VERSION = "0.1.2026041415"


# ---------------------------------------------------------------------------
# Token estimation
# ---------------------------------------------------------------------------


def estimate_tokens(data: Any) -> int:
    """Estimate token count from an operation's return value.

    Uses ``len(json_serialized) // 4`` as a rough approximation.
    """
    if data is None:
        return 0
    if isinstance(data, BaseModel):
        serialized = json.dumps(data.model_dump(), default=str)
    elif isinstance(data, list):
        serialized = json.dumps(
            [item.model_dump() if isinstance(item, BaseModel) else item for item in data],
            default=str,
        )
    elif isinstance(data, dict):
        serialized = json.dumps(data, default=str)
    else:
        serialized = str(data)
    return len(serialized) // 4


# ---------------------------------------------------------------------------
# Initialization (lazy)
# ---------------------------------------------------------------------------


def _anon_id() -> str:
    """Fallback distinct ID when no user_id is available."""
    raw = f"{platform.node()}{os.getenv('USER', os.getenv('USERNAME', ''))}"
    return f"anon-{hashlib.sha256(raw.encode()).hexdigest()[:16]}"


def _init() -> None:
    """Lazily initialize the PostHog client.  Called once on first track()."""
    if _state.client is not None or _state.disabled:
        return

    with _state._lock:
        # Double-check after acquiring lock
        if _state.client is not None or _state.disabled:
            return

        config_dir = os.environ.get("TKTL_CONFIG_DIR")
        config = Config(Path(config_dir)) if config_dir else Config()
        config.load()

        if config.get("telemetry") is False:
            _state.disabled = True
            return

        api_key = config.get("posthog_api_key") or _DEFAULT_API_KEY
        if not api_key:
            _state.disabled = True
            return

        host = config.get("posthog_host") or _DEFAULT_HOST

        client = posthog.Posthog(api_key, host=host)
        client.debug = False

        # Resolve distinct_id
        creds = Credentials(Path(config_dir)) if config_dir else Credentials()
        creds.load()
        _state.distinct_id = creds.user_id or _anon_id()
        _state.client = client


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def track(event: str, properties: dict[str, Any]) -> None:
    """Emit a PostHog event.  No-op when telemetry is disabled or not initialized."""
    if _state.disabled:
        return

    if _state.client is None:
        _init()

    if _state.client is None:
        return

    properties["source"] = _state.source
    properties["tktl_version"] = _TKTL_VERSION

    _state.client.capture(
        distinct_id=_state.distinct_id,
        event=f"tktl_{event}",
        properties=properties,
    )


def tracked(op_name: str):  # noqa: ANN201
    """Decorator that measures output tokens and emits an ``operation`` event."""

    def decorator(func):  # noqa: ANN001, ANN202
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            start = time.monotonic()
            try:
                result = func(*args, **kwargs)
                track(
                    "operation",
                    {
                        "op": op_name,
                        "success": True,
                        "output_tokens": estimate_tokens(result),
                        "duration_ms": int((time.monotonic() - start) * 1000),
                    },
                )
                return result
            except Exception as exc:
                track(
                    "operation",
                    {
                        "op": op_name,
                        "success": False,
                        "error_type": type(exc).__name__,
                        "output_tokens": 0,
                        "duration_ms": int((time.monotonic() - start) * 1000),
                    },
                )
                raise

        return wrapper

    return decorator


def disable() -> None:
    """Force-disable telemetry for the remainder of this process."""
    _state.disabled = True
    _state.client = None


def set_source(source: str) -> None:
    """Set the invocation source (``"cli"`` or ``"library"``)."""
    _state.source = source


def get_source() -> str:
    """Return the current invocation source."""
    return _state.source


def identify(user_id: str, properties: dict[str, Any]) -> None:
    """Set PostHog person properties for the given user."""
    if _state.disabled:
        return
    if _state.client is None:
        _init()
    if _state.client is None:
        return
    _state.distinct_id = user_id
    _state.client.set(distinct_id=user_id, properties=properties)
