# tktl

A developer- and agent-friendly CLI for managing [Taktile](https://taktile.com) decision flows.

`tktl` lets you browse, inspect, and surgically update flow versions and nodes from your terminal — or directly from Python. Designed to keep context small: an AI agent never needs to load a 10,000-line JSON to change one field.

## Install

```bash
pip install tktl-cli
```

### Graphviz (required for diagram rendering)

`tktl render` uses [Graphviz](https://graphviz.org/) to render Mermaid diagrams locally.

```bash
brew install graphviz          # macOS
sudo apt-get install graphviz  # Debian / Ubuntu
```

### From source

```bash
git clone https://github.com/taktile-org/tktl-cli.git
cd tktl-cli
uv sync && uv pip install -e .
```

Activate the venv or use `uv run`:

```bash
source .venv/bin/activate   # then `tktl` works directly
uv run tktl                 # no activation needed
```

## Setup

```bash
tktl auth login                          # paste your API key
tktl config set org <ORG_ID>
tktl config set workspace <WORKSPACE_ID>
```

### Custom environment (e.g. staging)

Use `TKTL_CONFIG_DIR` for a separate config directory:

```bash
mkdir -p .tktl-local
export TKTL_CONFIG_DIR=.tktl-local
tktl config set flow_api_url https://flow-api.stg.cp.taktile.com
tktl config set taktile_api_url https://taktile-api.stg.cp.taktile.com
tktl config set org <ORG_ID>
tktl config set workspace <WORKSPACE_ID>
tktl auth login
```

Then `export TKTL_CONFIG_DIR=.tktl-local` before each session.

## Usage

### Flows & Versions

```bash
tktl flows list
tktl flows describe credit-scoring
tktl versions list credit-scoring
tktl versions describe credit-scoring v1
tktl versions create credit-scoring v2
tktl versions duplicate credit-scoring v1 --name v2-experiment
tktl versions publish credit-scoring v2
tktl versions archive credit-scoring v1
```

### Nodes

```bash
tktl nodes list credit-scoring v1
tktl nodes describe credit-scoring v1 <NODE_ID>

# Add nodes (wired into the graph automatically)
tktl nodes add credit-scoring v1 --type transform --name "Scorer" \
  --after <INPUT_ID> --src 'data.score = 42'
tktl nodes add credit-scoring v1 --type split --name "Gate" \
  --after <SCORER_ID> --clause "data.score < 30"

# Remove a node (auto-rewires edges)
tktl nodes remove credit-scoring v1 <NODE_ID>

# Update node config
tktl update apply credit-scoring v1 \
  --node <NODE_ID> --node-config '{"src": "data.score = 99"}'
```

### Node Groups

Groups are visual containers that organize the canvas without affecting execution.
`tktl nodes list` annotates each node with its group.

```bash
tktl groups list credit-scoring v1
tktl groups create credit-scoring v1 --name "Scoring" --node-ids <ID1>,<ID2>
tktl groups describe credit-scoring v1 <GROUP_ID>
tktl groups update credit-scoring v1 <GROUP_ID> --name "Risk & Pricing"
tktl groups add-nodes credit-scoring v1 <GROUP_ID> --node-ids <ID3>
tktl groups remove-nodes credit-scoring v1 <GROUP_ID> --node-ids <ID2>
tktl groups delete credit-scoring v1 <GROUP_ID>

# Add a node directly into a group
tktl nodes add credit-scoring v1 --type transform --name "Normalize" \
  --after <INPUT_ID> --src 'data.norm = True' --group <GROUP_ID>
```

### Execute Decisions

```bash
tktl flows run credit-scoring --input '{"income": 50000}' --version v1
tktl flows batch credit-scoring -f inputs.csv --version v1
tktl flows batch credit-scoring --dataset <DATASET_UUID> --version v1
tktl flows history credit-scoring
tktl flows history credit-scoring --run-id <RUN_ID> --query "output.data.decision"
```

### Connections

```bash
tktl connections list
tktl connections create --name "Postman Echo" --provider custom \
  --base-url https://postman-echo.com --auth-method no_auth
```

## Library Usage

Every CLI command is backed by an importable Python function:

```python
from tktl.ops import list_flows, get_node, update_node, run_batch
from tktl.api.versions import get_version, patch_version

flows = list_flows(client, cache_manager, workspace_id)
node = get_node(client, cache_index, cache_manager, workspace_id, "credit-scoring", "v1", node_id)
```

See [skills/flow-builder/SKILL.md](skills/flow-builder/SKILL.md) for complete flow-building patterns.

## How It Works

- **Human-readable IDs** — flows by slug, versions by name, nodes by UUID (use `nodes list` to look up)
- **Surgical reads/writes** — targets the smallest object; decomposes versions into per-node cache files
- **Cache-first** — hierarchical cache at `~/.tktl/cache/` with 5-line index files, not 10k-line responses
- **Concurrency-safe** — ETag optimistic locking with auto-retry (re-fetch, re-merge, resend, up to 3×)
- **Agent-optimized** — non-TTY output defaults to JSON; `--summary` and `--section` flags keep context small

## Docs

| File | Content |
|---|---|
| [skills/flow-builder/SKILL.md](skills/flow-builder/SKILL.md) | Flow-building guide (workflow, node types, datasets, gotchas) |
| [skills/flow-builder/references/node-configs.md](skills/flow-builder/references/node-configs.md) | Per-type configuration reference |
| [skills/flow-builder/references/flow-patterns.md](skills/flow-builder/references/flow-patterns.md) | Reusable decision flow patterns |
| [skills/flow-builder/references/debugging.md](skills/flow-builder/references/debugging.md) | Diagnosing flow failures |
| [skills/flow-builder/references/working-with-child-flows-and-loop-nodes.md](skills/flow-builder/references/working-with-child-flows-and-loop-nodes.md) | Child flows and loop nodes |
| [skills/flow-review/SKILL.md](skills/flow-review/SKILL.md) | Edge-case audit + 100% node-coverage test generation |
| [skills/flow-review/references/best-practices.md](skills/flow-review/references/best-practices.md) | Flow quality checklist used by the review skill |
| [skills/flow-context/SKILL.md](skills/flow-context/SKILL.md) | Customer-context review, weighted grading, corrective workflow |
| [skills/tktl-debug/SKILL.md](skills/tktl-debug/SKILL.md) | Diagnose and fix failing flow runs |
| [skills/diff-flow-versions/SKILL.md](skills/diff-flow-versions/SKILL.md) | Plain-language summary of a version diff |
| [skills/onboard-flow/SKILL.md](skills/onboard-flow/SKILL.md) | Generate an onboarding document for a flow |
| [docs/specs/core-implementation.md](docs/specs/core-implementation.md) | Full technical specification |
| [docs/specs/batch-run.md](docs/specs/batch-run.md) | Batch execution and datasets |

## Development

```bash
uv sync                       # install dependencies
uv run pytest                 # run tests
uv run ruff check .           # lint
uv run ruff format .          # format
uv run tktl --help            # run the CLI
```

## License

MIT
