# Spec: Flow Mermaid Preview

## Overview

Two features built on a shared rendering backend:

1. **`tktl render <file.md>`** — render a Markdown planning doc (incl. Mermaid blocks) to PNG; for the "design before you build" workflow.
2. **`tktl versions describe --preview`** — generate Mermaid from a live flow version graph and print a clickable `file://` path.

---

## Rendering Backend

**No npm. No extra Python deps. Stdlib only.**

Use the [`mermaid.ink`](https://mermaid.ink) REST API.

```
GET https://mermaid.ink/img/{base64url_payload}
```

Payload: base64url-encoded (no padding) JSON — `{"code": "<mermaid_code>", "mermaid": {"theme": "default"}}`.

Transport: `urllib.request.urlopen` with 15 s timeout.

Output: PNG bytes written to `/tmp/tktl/<timestamp>.png` where timestamp = `datetime.now().strftime("%Y%m%d_%H%M%S")`.

If multiple renders happen within the same second, append `-1`, `-2`, etc. to avoid collision.

**Failure behaviour:** raise `RenderError(TktlError)` with a user-friendly message. Callers catch and print a warning; they never crash.

---

## graph_to_mermaid(graph: dict) -> str

Converts a raw version graph dict to a Mermaid `flowchart TD` string.

**Input**
```python
{
  "nodes": { "<uuid>": {"name": str, "type": str, "meta": dict}, ... },
  "edges": { "<uuid>": {"start_node_id": str, "end_node_id": str, "meta": dict}, ... }
}
```

**Node ID sanitisation:** UUIDs contain hyphens which break Mermaid parser. Use short sequential aliases `N0`, `N1`, …, built from the node insertion order.

**Node shapes by type:**

| `type` | Mermaid shape | Label |
|---|---|---|
| `input` | `N([name])` | name |
| `output` | `N([name])` | name |
| `split_2` | `N{name}` | name |
| `transform` with `meta.is_split_branch_node` | `N>name]` | name |
| `transform` with `meta.is_split_merge_node` | `N(( ))` | _(blank)_ |
| `rule_2` | `N[[rule: name]]` | type-prefixed |
| `assignment_node` | `N[assign: name]` | type-prefixed |
| `decision_table` | `N[(dt: name)]` | type-prefixed |
| `scorecard` | `N[score: name]` | type-prefixed |
| `matrix_table` | `N[matrix: name]` | type-prefixed |
| `transform` | `N[name]` | name |
| _(anything else)_ | `N[type: name]` | type-prefixed |

**Edges:** iterate the `edges` dict. For each edge emit `Na --> Nb`. For split edges (`meta.is_split_edge == True`) coming out of a `split_2` node, look up the branch name from the split meta and emit `Na -->|label| Nb`.

---

## extract_mermaid_blocks(md_text: str) -> list[str]

Extract all ` ```mermaid ` … ` ``` ` code blocks from a Markdown string. Return the inner code (without the fences).

---

## preview_version_graph(client, cache_index, cache_manager, workspace_id, slug, version_name) -> Path

New ops function in `src/tktl/ops/render.py`.

1. Resolve `flow_id`, `version_id` via `_resolve_ids`.
2. Read `full.json` from `cache_manager.read_full_version(version_id, flow_id)`. Fall back to API fetch if not cached.
3. Call `graph_to_mermaid(raw["graph"])`.
4. Call `render_mermaid_png(code, Path(tempfile.gettempdir()) / "tktl")`.
5. Return the PNG `Path`.

---

## CacheManager addition

Add `read_full_version(version_id, flow_id) -> dict | None` — reads `full.json` from the version cache dir. Already written by `write_version`; just needs a reader.

---

## Command: tktl render

Three input modes, mutually exclusive:

```
tktl render <file.md>          # Markdown file — extract mermaid blocks
tktl render --text "flowchart TD\n  A --> B"   # inline Mermaid code
tktl render -                  # stdin — read as Markdown, extract blocks
```

### Resolution logic

1. If `--text` is provided: treat value as raw Mermaid code. Single block.
2. Else if file argument is `-`: read stdin as Markdown text, extract blocks.
3. Else if file argument is a path: read file as Markdown, extract blocks.
4. Exactly one of the three must be provided — error otherwise.

### Rendering

For each Mermaid block:
1. `render_mermaid_png(code, Path("/tmp/tktl"))` — save timestamped PNG.
2. Print `file:///tmp/tktl/<timestamp>.png` to stdout.
3. **No auto-open.** The `file://` URI is clickable in VS Code terminal (Cmd+click) and iTerm2.

If no Mermaid blocks found: print `No mermaid blocks found` and exit 0.  
On `RenderError`: print warning, skip block, continue.

Registered as `app.command("render")` in `main.py`. No sub-app needed (single command).

### Pre-build design workflow (REQUIRED)

**Before any `tktl versions duplicate` or `tktl nodes add` calls**, the agent MUST:

1. Brainstorm the flow design with the user (node types, logic, branching).
2. Generate a Mermaid `flowchart TD` diagram representing the agreed design.
3. Call `tktl render --text "<mermaid>"` — print the `file://` link for the user to click.
4. Wait for user approval of the diagram.
5. Only then proceed to build.

This step is non-optional. Skipping it means the user has no visual checkpoint before
API calls start modifying their workspace.

---

## Command: tktl versions describe --preview

Add `--preview / -p` flag (default `False`) to `versions_describe`.

After `print_output(result, ...)`:
1. If `--preview` and not `--quiet`:
   - Call `preview_version_graph(...)`.
   - Print `\n  Preview: file:///tmp/tktl/<timestamp>.png`.
   - **No auto-open.** Link is clickable in VS Code terminal / iTerm2.
2. On `RenderError`: print `  Preview: render failed — check network` and continue.
3. If `--output json`: still render and print the path line to stderr so JSON stdout stays clean.

---

## Error type

```python
class RenderError(TktlError):
    code = 10
```

Add to `src/tktl/models/errors.py`.

---

## File layout changes

```
src/tktl/ops/render.py          (new)
src/tktl/cli/render_cmd.py      (new)
src/tktl/models/errors.py       (add RenderError)
src/tktl/cache/manager.py       (add read_full_version)
src/tktl/cli/versions.py        (add --preview flag)
src/tktl/cli/main.py            (register render command)
tests/test_ops/test_render.py   (new)
tests/test_e2e/test_render.py   (new)
```
