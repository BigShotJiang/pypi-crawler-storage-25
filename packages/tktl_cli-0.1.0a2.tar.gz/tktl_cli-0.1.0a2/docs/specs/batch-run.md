# Batch Run — Technical Specification

> Run multiple decisions against a flow from a local file or a platform dataset.
> Results are tracked per-flow with history for later inspection.

---

## 1. Overview

The `tktl flows batch` command extends the existing single-decision `flows run` with:

- **Two input sources:**
  - **Local file** (`--file`) — CSV, JSON array, single JSON object, or JSONL/NDJSON.
  - **Platform dataset** (`--dataset`) — download a dataset from the Taktile platform by UUID and use it as input.
- **Concurrent execution** with a configurable concurrency limit (default: 10).
- **Results tracking** — append-only JSONL results file per batch run.
- **Run history** — runs are grouped by flow slug and source for later inspection via `tktl flows history`.

**Constraint:** Maximum **1000 rows** per batch. Inputs exceeding this limit are rejected.

---

## 2. Commands

### 2.1 `tktl flows batch <SLUG>`

Execute multiple decisions against a flow from a local file or platform dataset.

```
tktl flows batch <SLUG> (--file <PATH> | --dataset <ID>) [OPTIONS]
```

**Arguments:**

| Argument | Description |
|:---|:---|
| `SLUG` | Flow slug |

**Input source (mutually exclusive, one required):**

| Flag | Type | Description |
|:---|:---|:---|
| `-f, --file` | PATH | Path to a local input file (CSV, JSON, JSONL/NDJSON) |
| `-d, --dataset` | UUID | Dataset ID on the platform. Downloads the dataset's `input_columns` as JSON and uses them as batch input. |

**Options:**

| Flag | Type | Default | Description |
|:---|:---|:---|:---|
| `-c, --concurrency` | INT | `10` | Maximum concurrent requests (1–50) |
| `-v, --version` | TEXT | *(published)* | Version name |
| `-e, --env` | TEXT | *(from config)* | Environment: `sandbox` or `live` |
| `--format` | TEXT | `json` | Download format when using `--dataset`: `json` or `csv` |
| `-o, --output` | FORMAT | `auto` | Output format for summary (`json`\|`table`) |
| `-q, --quiet` | BOOL | `false` | Suppress progress output |

**Examples:**

```bash
# From a local file
tktl flows batch credit-scoring --file inputs.csv --version v1.0

# From a platform dataset
tktl flows batch credit-scoring --dataset 9a8b7c6d-... --version v1.0

# Both produce the same downstream behaviour — only the input source differs
```

**Output (json mode):**

```json
{
  "meta": {
    "run_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    "flow_slug": "credit-scoring",
    "env": "sandbox",
    "source_type": "dataset",
    "source": "dataset:9a8b7c6d-...",
    "source_hash": "sha256:abcdef...",
    "total_rows": 50,
    "succeeded": 48,
    "failed": 2,
    "duration_ms": 5234
  },
  "results_path": "/Users/me/.tktl/runs/credit-scoring/a1b2c3d4/results.jsonl"
}
```

**Library:** `tktl.ops.batch.run_batch(client, workspace_id, flow_slug, *, file_path, dataset_id, version, env, concurrency, runs_dir) -> BatchResult`

---

### 2.2 `tktl flows history <SLUG>`

Inspect past batch runs for a flow.

```
tktl flows history <SLUG> [OPTIONS]
```

**Flags:**

| Flag | Type | Default | Description |
|:---|:---|:---|:---|
| `--run-id` | TEXT | *(none)* | Show details + results for a specific run |
| `--query` | TEXT | *(none)* | Extract a field from each result row (requires `--run-id`). Dot/bracket path, e.g. `output.data.decision` or `output.scores[0].value`. |
| `-o, --output` | FORMAT | `auto` | Output format (`json`\|`table`) |
| `-q, --quiet` | BOOL | `false` | Suppress output |

**Without `--run-id` (list mode):** Returns an array of run summaries for this flow.

```json
[
  {
    "run_id": "a1b2c3d4-...",
    "source_type": "file",
    "source": "input.csv",
    "total_rows": 50,
    "succeeded": 48,
    "failed": 2,
    "started_at": "2026-03-20T10:15:30Z",
    "duration_ms": 5234
  }
]
```

**With `--run-id` (detail mode):** Returns the full run metadata.

```json
{
  "run_id": "a1b2c3d4-...",
  "flow_slug": "credit-scoring",
  "env": "sandbox",
  "version": null,
  "source_type": "dataset",
  "source": "dataset:9a8b7c6d-...",
  "source_hash": "sha256:abcdef...",
  "dataset_etag": "abc123",
  "concurrency": 10,
  "total_rows": 50,
  "succeeded": 48,
  "failed": 2,
  "started_at": "2026-03-20T10:15:30Z",
  "completed_at": "2026-03-20T10:15:35Z",
  "duration_ms": 5234,
  "results_path": "/Users/me/.tktl/runs/credit-scoring/a1b2c3d4/results.jsonl"
}
```

**With `--query` (extraction mode):** Requires `--run-id`. Extracts the specified field from each result row using dot/bracket path notation.

```bash
tktl flows history credit-scoring --run-id abc123 --query "output.data.decision"
```

```json
[
  {"row_index": 0, "value": "approve"},
  {"row_index": 1, "value": "reject"}
]
```

Path syntax:
- `key` — access a dict key
- `key.nested` — access nested keys
- `items[0]` — access array index
- `data.scores[1].value` — mixed access

Returns `null` for missing keys or out-of-range indices.

**Library:**
- `tktl.ops.batch.list_batch_runs(flow_slug, runs_dir) -> list[BatchRunSummary]`
- `tktl.ops.batch.get_batch_run(flow_slug, run_id, runs_dir) -> BatchRunMeta`
- `tktl.ops.batch.extract_query(data, query) -> Any`

---

## 3. Input Sources

The batch command accepts two mutually exclusive input sources. Once rows are resolved, everything downstream (execution, results, history) is identical regardless of source.

### 3.1 Local file (`--file`)

A file on disk. Supported formats:

#### CSV

Each row becomes a JSON object. Column headers are keys.

```csv
income,age,employed
50000,30,true
75000,45,false
```

Becomes:

```json
[
  {"income": 50000, "age": 30, "employed": true},
  {"income": 75000, "age": 45, "employed": false}
]
```

**Type coercion:** CSV values are strings. The parser attempts to coerce in order: `int` → `float` → `bool` (`"true"`/`"false"`) → keep as string.

#### JSON Array

```json
[
  {"income": 50000, "age": 30},
  {"income": 75000, "age": 45}
]
```

Each element must be a JSON object.

#### Single JSON Object

```json
{"income": 50000, "age": 30}
```

Treated as a batch of 1 row.

#### JSONL / NDJSON

One JSON object per line. File extension: `.jsonl` or `.ndjson`.

```
{"income": 50000, "age": 30}
{"income": 75000, "age": 45}
```

#### Auto-Detection

For files with unrecognized extensions, the parser auto-detects:
- Starts with `[` → JSON array
- Starts with `{` → try JSONL (multiple lines), fall back to single JSON object
- Otherwise → CSV

### 3.2 Platform dataset (`--dataset`)

A dataset hosted on the Taktile platform, identified by UUID.

```bash
tktl flows batch credit-scoring --dataset 9a8b7c6d-e5f6-7890-abcd-ef1234567890
```

#### Dataset Jobs API

Dataset download is **asynchronous** — it goes through the Dataset Jobs service. The API lives on the **workspace base URL** (same host as the Decide API):

```
{workspace_base_url}/dataset_jobs/api/v1/
```

**Endpoints used:**

| Endpoint | Method | Purpose |
|:---|:---|:---|
| `/dataset_jobs` | POST | Create a download job |
| `/dataset_jobs/{id}` | GET | Poll job status until COMPLETED |
| *(S3 pre-signed URL)* | GET | Download the actual file (no auth needed) |

All endpoints use `X-Api-Key` authentication except the final S3 download (pre-signed URL).

#### Download flow

1. **Resolve workspace base URL** — reuse `_resolve_workspace_base_url()` (already cached).
2. **Check local cache** — look for `~/.tktl/cache/datasets/{dataset_id}/data.json` with matching ETag.
   - If cached and ETag matches → use the cached file (skip download).
3. **Create download job** — `POST /dataset_jobs/api/v1/dataset_jobs`:
   ```json
   {
     "flow_id": "{flow_id}",
     "type": "download",
     "request": {
       "dataset_id": "{dataset_id}",
       "format": "json"
     }
   }
   ```
   Returns a `DownloadDatasetJob` with `id`, `status: "PENDING"`.
4. **Poll until complete** — `GET /dataset_jobs/api/v1/dataset_jobs/{job_id}` with exponential backoff until `status` is `"COMPLETED"` or `"FAILED"`.
   - On `"FAILED"` → raise error with `error.message`.
   - On `"COMPLETED"` → extract `response.s3_url`.
5. **Download from S3** — `GET {s3_url}` (pre-signed, no auth headers needed). Returns the dataset file content.
6. **Cache** — write to `~/.tktl/cache/datasets/{dataset_id}/data.json` alongside `meta.json`.
7. **Extract input rows** — parse the downloaded JSON. Each row may have `input_data`, `output_data`, `mock_data`, etc. For batch execution, **only `input_data`** is extracted from each row.
8. **Validate** — same rules as local files: max 1000 rows, non-empty.

#### Polling strategy

| Attempt | Delay |
|:---|:---|
| 1–5 | 0.5s |
| 6–10 | 1.0s |
| 11–20 | 2.0s |
| 21+ | Fail with timeout error |

Maximum wait: ~35 seconds. Most small dataset downloads complete in 1–3 seconds.

#### Dataset cache layout

```
~/.tktl/cache/datasets/
  {dataset_id}/
    meta.json       # {"dataset_id": "...", "etag": "...", "row_count": N, "cached_at": "..."}
    data.json       # the downloaded file content
```

#### Why cache?

Datasets can be large and rarely change between invocations. Caching avoids re-triggering the download job on every batch run. The ETag from the dataset info endpoint (`GET /datasets/api/v1/datasets/info/{id}`) is stored in `meta.json` and used to validate freshness. On repeat runs, if the ETag matches, the cached file is used directly — no job needed.

#### Input extraction

Platform datasets have structured columns (`input_columns`, `output_columns`, `mock_columns`, etc.). For batch execution, only the **input data** matters:

```python
# Downloaded JSON (array of row objects)
[
  {"input_data": {"income": 50000, "age": 30}, "output_data": {...}, "mock_data": {...}},
  {"input_data": {"income": 75000, "age": 45}, "output_data": {...}, "mock_data": {...}}
]

# Extracted for batch execution
[
  {"income": 50000, "age": 30},
  {"income": 75000, "age": 45}
]
```

If rows are flat objects (no `input_data` key), they are used as-is.

### 3.3 Validation (both sources)

| Rule | Error |
|:---|:---|
| Neither `--file` nor `--dataset` | `UsageError: Provide either --file or --dataset` |
| Both `--file` and `--dataset` | `UsageError: Provide either --file or --dataset, not both` |
| File not found | `UsageError: File not found: {path}` |
| Dataset not found | `NotFoundError: Dataset '{id}' not found` |
| Empty input / no rows | `UsageError: Batch input is empty` |
| More than 200 rows | `UsageError: Batch input has {n} rows, maximum is 1000` |
| Non-object item in array | `UsageError: Item {i} in JSON array is not an object` |
| Invalid JSON | `UsageError: Invalid JSON on line {n}: {detail}` |

---

## 4. Execution

### 4.1 Flow

1. **Resolve input** — either parse local file or download + cache dataset → `list[dict]`.
2. Resolve workspace `base_url` via `GET /api/v1/workspaces/{workspace_id}` (sync, cached).
3. Build decide URL: `{base_url}/run/api/v1/flows/{slug}/{env}/decide`.
4. Generate `run_id` (UUID4).
5. Create run directory: `~/.tktl/runs/{flow_slug}/{run_id}/`.
6. Write initial `meta.json`.
7. Execute all rows concurrently via `asyncio.run()`:
   - `httpx.AsyncClient` for HTTP requests.
   - `asyncio.Semaphore(concurrency)` limits in-flight requests.
   - Each row POSTs the decide payload: `{"data": <row>, "metadata": {"version": <v>}, "control": {"execution_mode": "sync"}}`.
   - Each result (success or error) is appended to `results.jsonl` immediately.
8. Finalize `meta.json` with succeeded/failed counts and timing.
9. Update `index.json` for the flow.
10. Emit `batch_execution` telemetry event.
11. Return `BatchResult`.

### 4.2 Decide Payload

Same as `flows run` — the row data is wrapped in the standard decide body:

```json
{
  "data": { /* row from input */ },
  "metadata": { "version": "v1" },
  "control": { "execution_mode": "sync" }
}
```

### 4.3 Error Handling

- **Per-row errors** (network timeout, API error, non-200 response): captured in the row result's `error` field. The batch continues; other rows are not affected.
- **Batch-level errors** (file parse failure, auth failure, workspace not found, dataset not found): raised as `UsageError`, `AuthError`, or `NotFoundError` — the batch aborts before execution starts.

### 4.4 Concurrency

- Default: 10 concurrent requests.
- Configurable via `--concurrency` (range: 1–50).
- Implementation: `asyncio.Semaphore` gates HTTP requests within `asyncio.gather()`.

---

## 5. Results Storage

### 5.1 Directory Layout

```
~/.tktl/runs/
  {flow_slug}/
    index.json                # array of run summaries (append-only)
    {run_id}/
      meta.json               # BatchRunMeta
      results.jsonl           # one BatchRowResult per line (append-only)
```

### 5.2 `index.json`

```json
{
  "runs": [
    {
      "run_id": "a1b2c3d4-...",
      "source_type": "file",
      "source": "input.csv",
      "source_hash": "sha256:abcdef...",
      "total_rows": 50,
      "succeeded": 48,
      "failed": 2,
      "started_at": "2026-03-20T10:15:30Z",
      "duration_ms": 5234
    }
  ]
}
```

### 5.3 `meta.json`

Full `BatchRunMeta` model serialized as JSON.

```json
{
  "run_id": "a1b2c3d4-...",
  "flow_slug": "credit-scoring",
  "env": "sandbox",
  "version": null,
  "source_type": "dataset",
  "source": "dataset:9a8b7c6d-...",
  "source_hash": "sha256:abcdef1234567890...",
  "dataset_etag": "abc123",
  "concurrency": 10,
  "total_rows": 50,
  "succeeded": 48,
  "failed": 2,
  "started_at": "2026-03-20T10:15:30Z",
  "completed_at": "2026-03-20T10:15:35Z",
  "duration_ms": 5234
}
```

### 5.4 `results.jsonl`

One JSON object per line. Written as each row completes (append-only, crash-safe).

```json
{"row_index": 0, "input": {"income": 50000}, "output": {"decision": "approve"}, "error": null, "duration_ms": 142, "timestamp": "2026-03-20T10:15:30.123Z"}
{"row_index": 1, "input": {"income": 25000}, "output": null, "error": "Connection timeout", "duration_ms": 5002, "timestamp": "2026-03-20T10:15:31.456Z"}
```

---

## 6. Data Models

### 6.1 `BatchRowResult`

```python
class BatchRowResult(BaseModel):
    row_index: int
    input: dict[str, Any]
    output: dict[str, Any] | None
    error: str | None
    duration_ms: int
    timestamp: str  # ISO-8601
```

### 6.2 `BatchRunMeta`

```python
class BatchRunMeta(BaseModel):
    run_id: str
    flow_slug: str
    env: str
    version: str | None
    source_type: str           # "file" or "dataset"
    source: str                # file path or "dataset:{uuid}"
    source_hash: str           # SHA-256 of content
    dataset_etag: str | None   # ETag from platform (dataset only)
    concurrency: int
    total_rows: int
    succeeded: int
    failed: int
    started_at: str            # ISO-8601
    completed_at: str | None
    duration_ms: int | None
```

### 6.3 `BatchRunSummary`

```python
class BatchRunSummary(BaseModel):
    run_id: str
    source_type: str
    source: str
    source_hash: str
    total_rows: int
    succeeded: int
    failed: int
    started_at: str
    duration_ms: int | None
```

### 6.4 `BatchResult`

```python
class BatchResult(BaseModel):
    meta: BatchRunMeta
    results_path: str
```

---

## 7. Dataset APIs Reference

All APIs live on the **workspace base URL** — the same host used for the Decide API.

**Auth:** `X-Api-Key` header (same key as all other APIs), except S3 pre-signed URLs.

### 7.1 Get dataset info (for cache validation)

**Base path:** `{workspace_base_url}/datasets/api/v1`

```
GET /datasets/info/{dataset_id}
Headers: X-Api-Key: {key}, If-None-Match: {etag} (optional)
```

Returns lightweight metadata with ETag for cache validation:
- **200** — dataset info with current ETag.
- **304 Not Modified** — dataset hasn't changed since the given ETag.

Response (`TestRunDatasetExtended`):

```json
{
  "id": "9a8b7c6d-...",
  "etag": "abc123",
  "rows_total": 50,
  "size_total_estimated_bytes": 12345
}
```

### 7.2 Create download job

**Base path:** `{workspace_base_url}/dataset_jobs/api/v1`

```
POST /dataset_jobs
Headers: X-Api-Key: {key}
Content-Type: application/json
```

Request body (`DownloadDatasetJobCreation`):

```json
{
  "flow_id": "648ace59-...",
  "type": "download",
  "request": {
    "dataset_id": "49eea21a-...",
    "format": "json"
  }
}
```

Response (`DownloadDatasetJob`):

```json
{
  "id": "job-uuid-...",
  "status": "PENDING",
  "progress": 0,
  "type": "download",
  "flow_id": "648ace59-...",
  "request": { "dataset_id": "49eea21a-...", "format": "json" },
  "response": null
}
```

### 7.3 Poll job status

```
GET /dataset_jobs/{job_id}
Headers: X-Api-Key: {key}
```

Response when completed:

```json
{
  "id": "job-uuid-...",
  "status": "COMPLETED",
  "progress": 100,
  "type": "download",
  "response": {
    "bucket": "taktile-datasets-...",
    "key": "datasets/...",
    "s3_url": "https://taktile-datasets-....s3.amazonaws.com/datasets/...?X-Amz-..."
  }
}
```

Status values: `"PENDING"`, `"COMPLETED"`, `"FAILED"`.

On `"FAILED"`, the `error` field contains `{"message": "..."}`.

### 7.4 Download from S3

```
GET {response.s3_url}
```

Pre-signed URL — no auth headers needed. Returns the dataset file content (JSON array).

---

## 8. Dataset Cache

### 8.1 Layout

```
~/.tktl/cache/datasets/
  {dataset_id}/
    meta.json       # cache metadata + etag
    data.json       # downloaded dataset content
```

### 8.2 `meta.json`

```json
{
  "dataset_id": "9a8b7c6d-...",
  "etag": "abc123",
  "row_count": 50,
  "cached_at": "2026-03-20T10:00:00Z"
}
```

### 8.3 Cache validation flow

```
Has cached data.json for this dataset_id?
├── YES → GET /datasets/api/v1/datasets/info/{id} with If-None-Match: {cached_etag}
│         ├── 304 → use cached data.json (no download job needed)
│         └── 200 → new etag → trigger download job → poll → download from S3 → update cache
└── NO  → trigger download job → poll → download from S3 → write cache
```

This makes repeated runs against the same unchanged dataset near-instant (one lightweight info call to confirm the ETag, then read from disk).

---

## 9. Telemetry

Event: `batch_execution`

```python
track("batch_execution", {
    "op": "run_batch",
    "success": True,
    "total_rows": 50,
    "succeeded": 48,
    "failed": 2,
    "concurrency": 10,
    "duration_ms": 5234,
    "flow_slug": "credit-scoring",
    "env": "sandbox",
    "source_type": "dataset",   # or "file"
})
```

---

## 10. Architecture

Follows the library-first pattern:

| Layer | File | Responsibility |
|:---|:---|:---|
| **Models** | `src/tktl/models/batch.py` | `BatchRowResult`, `BatchRunMeta`, `BatchRunSummary`, `BatchResult` |
| **Ops** | `src/tktl/ops/batch.py` | `parse_batch_file()`, `run_batch()`, `list_batch_runs()`, `get_batch_run()`, `get_batch_results()`, `extract_query()` |
| **API** | `src/tktl/api/datasets.py` | `get_dataset_info()`, `create_download_job()`, `get_job_status()`, `download_s3_file()` |
| **CLI** | `src/tktl/cli/flows.py` | `flows batch` and `flows history` commands (thin wrappers) |

The dataset download and ETag caching is handled in the ops layer (`run_batch`), calling the API layer for HTTP. The async batch execution is internal to `ops/batch.py`. The public API (`run_batch()`) is synchronous — it calls `asyncio.run()` internally.
