# Datasets — Technical Specification

> Create, inspect, update, and manage test datasets for Taktile decision flows.
> Supports creation from scratch, file upload, schema-aware column derivation,
> and full CRUD on rows and columns.

---

## 1. Overview

The `tktl datasets` sub-app provides full dataset lifecycle management:

- **Create** datasets from scratch (defining columns manually or deriving from flow schema)
- **Upload** datasets from local CSV/JSON files via presigned S3 URLs
- **Read** dataset metadata and paginated rows
- **Update** rows (add, modify, delete) and columns (add, rename, delete, fill)
- **Sync** dataset columns with the flow's current input schema (schema drift detection)
- **Download** datasets as CSV or JSON files
- **Delete** datasets

**Smart strategy selection:** When adding rows, the ops layer auto-picks the optimal
approach — row-append API for ≤50 rows, file upload for larger batches.

---

## 2. Commands

### 2.1 `tktl datasets list <SLUG>`

List all datasets for a flow.

```
tktl datasets list <SLUG>
```

| Argument | Description |
|:---|:---|
| `SLUG` | Flow slug |

**Options:**

| Flag | Type | Default | Description |
|:---|:---|:---|:---|
| `-o, --output` | FORMAT | `auto` | Output format (`json`\|`table`) |

**Library:** `tktl.ops.datasets.list_datasets(client, workspace_id, flow_slug) -> list[DatasetSummary]`

---

### 2.2 `tktl datasets create <SLUG>`

Create an empty dataset from scratch.

```
tktl datasets create <SLUG> --name <NAME> [--from-schema <VERSION>] [--columns <JSON>]
```

| Argument | Description |
|:---|:---|
| `SLUG` | Flow slug |

**Options:**

| Flag | Type | Default | Description |
|:---|:---|:---|:---|
| `--name` | TEXT | *(required)* | Dataset name |
| `--from-schema` | TEXT | *(none)* | Version name — derive input columns from version's input schema |
| `--columns` | JSON | *(none)* | Manual column definitions: `[{"name": "income", "desired_type": "number"}, ...]` |
| `-o, --output` | FORMAT | `auto` | Output format |

`--from-schema` and `--columns` are mutually exclusive. If `--from-schema` is given, the
command inspects the version's `input_schema` and maps JSON Schema types to dataset column types.

**Type mapping (JSON Schema → Dataset column type):**

| JSON Schema type | Dataset `desired_type` |
|:---|:---|
| `string` | `string` |
| `number` | `number` |
| `integer` | `integer` |
| `boolean` | `boolean` |
| `object` | `object` |
| `array` | `array` |
| *(unknown/missing)* | `any` |

**Library:** `tktl.ops.datasets.create_dataset(client, workspace_id, flow_slug, name, input_columns, mock_columns=[]) -> Dataset`

**Library:** `tktl.ops.datasets.create_from_schema(client, workspace_id, flow_slug, version_name, dataset_name) -> Dataset`

---

### 2.3 `tktl datasets upload <SLUG>`

Upload a local file as a new dataset.

```
tktl datasets upload <SLUG> --file <PATH> [--name <NAME>]
```

| Argument | Description |
|:---|:---|
| `SLUG` | Flow slug |

**Options:**

| Flag | Type | Default | Description |
|:---|:---|:---|:---|
| `-f, --file` | PATH | *(required)* | Local file (CSV or JSON) |
| `--name` | TEXT | *(filename)* | Dataset name (defaults to filename without extension) |
| `-o, --output` | FORMAT | `auto` | Output format |

**Upload flow:**

1. `POST /dataset_file_uploads` with `flow_id` and `file_name` → returns presigned S3 URL + fields
2. Upload file to S3 using the presigned URL and fields (multipart form POST)
3. Poll `GET /dataset_file_uploads/{id}` until `status` is `COMPLETED` or `FAILED`
4. Return the created dataset (the upload job sets `dataset_id` on completion)

**Polling strategy:** Same as dataset download — 0.5s × 5, 1.0s × 5, 2.0s × 10, then timeout.

**Library:** `tktl.ops.datasets.upload_dataset(client, workspace_id, flow_slug, file_path, name) -> Dataset`

---

### 2.4 `tktl datasets describe <DATASET_ID>`

Show dataset metadata (columns, row count, timestamps).

```
tktl datasets describe <DATASET_ID>
```

**Options:**

| Flag | Type | Default | Description |
|:---|:---|:---|:---|
| `-o, --output` | FORMAT | `auto` | Output format |

**Library:** `tktl.ops.datasets.describe_dataset(client, dataset_id) -> Dataset`

---

### 2.5 `tktl datasets rows <DATASET_ID>`

List dataset rows with pagination.

```
tktl datasets rows <DATASET_ID> [--from 0] [--size 50]
```

**Options:**

| Flag | Type | Default | Description |
|:---|:---|:---|:---|
| `--from` | INT | `0` | Start offset |
| `--size` | INT | `50` | Number of rows to return |
| `-o, --output` | FORMAT | `auto` | Output format |

**Library:** `tktl.ops.datasets.get_rows(client, dataset_id, from_, size) -> list[DatasetRow]`

---

### 2.6 `tktl datasets add-rows <DATASET_ID>`

Append rows to an existing dataset.

```
tktl datasets add-rows <DATASET_ID> (--file <PATH> | --blank <N> | --data <JSON>)
```

**Options:**

| Flag | Type | Default | Description |
|:---|:---|:---|:---|
| `-f, --file` | PATH | *(none)* | File with row data (CSV/JSON) |
| `--blank` | INT | *(none)* | Number of blank rows to add |
| `--data` | JSON | *(none)* | Inline JSON array of row objects |
| `-o, --output` | FORMAT | `auto` | Output format |

Mutually exclusive: exactly one of `--file`, `--blank`, or `--data`.

**Strategy selection:**
- `--blank` ≤ 50 rows: use `POST /datasets/{id}/rows` with `source: "blank"`
- `--blank` > 50 rows: batch into multiple API calls (50 per call)
- `--file` or `--data`: parse rows, if ≤ 50 use row-append API, if > 50 use file upload

**Library:** `tktl.ops.datasets.add_rows(client, dataset_id, rows) -> list[DatasetRow]`

**Library:** `tktl.ops.datasets.add_blank_rows(client, dataset_id, count) -> list[DatasetRow]`

---

### 2.7 `tktl datasets update-row <DATASET_ID> <ROW_ID>`

Modify a single row's data.

```
tktl datasets update-row <DATASET_ID> <ROW_ID> --data <JSON>
```

**Options:**

| Flag | Type | Default | Description |
|:---|:---|:---|:---|
| `--data` | JSON | *(required)* | JSON object with fields to update: `{"input_data": {...}}` |
| `-o, --output` | FORMAT | `auto` | Output format |

**Library:** `tktl.ops.datasets.update_row(client, dataset_id, row_id, data) -> DatasetRow`

---

### 2.8 `tktl datasets delete-row <DATASET_ID> <ROW_ID>`

Delete a single row.

```
tktl datasets delete-row <DATASET_ID> <ROW_ID>
```

**Library:** `tktl.ops.datasets.delete_row(client, dataset_id, row_id) -> None`

---

### 2.9 `tktl datasets add-column <DATASET_ID>`

Add a new column to a dataset.

```
tktl datasets add-column <DATASET_ID> --group <GROUP> --name <NAME> --type <TYPE>
```

**Options:**

| Flag | Type | Default | Description |
|:---|:---|:---|:---|
| `--group` | ENUM | *(required)* | Column group: `input_columns`, `output_columns`, `mock_columns`, `meta_columns`, `outcome_columns` |
| `--name` | TEXT | *(required)* | Column name |
| `--type` | ENUM | *(required)* | Column type: `string`, `boolean`, `number`, `integer`, `object`, `array`, `datetime`, `date`, `any`, `enum`, `files` |
| `-o, --output` | FORMAT | `auto` | Output format |

**Library:** `tktl.ops.datasets.add_column(client, dataset_id, group, name, desired_type) -> Dataset`

---

### 2.10 `tktl datasets rename-column <DATASET_ID>`

Rename a column (also renames the underlying data).

```
tktl datasets rename-column <DATASET_ID> --group <GROUP> --old <OLD_NAME> --new <NEW_NAME>
```

**Library:** `tktl.ops.datasets.rename_column(client, dataset_id, group, old_name, new_name) -> Dataset`

---

### 2.11 `tktl datasets delete-column <DATASET_ID>`

Delete a column.

```
tktl datasets delete-column <DATASET_ID> --group <GROUP> --name <NAME>
```

**Library:** `tktl.ops.datasets.delete_column(client, dataset_id, group, name) -> Dataset`

---

### 2.12 `tktl datasets fill-column <DATASET_ID>`

Fill a column with a value, optionally for a row range.

```
tktl datasets fill-column <DATASET_ID> --group <GROUP> --name <NAME> --value <VALUE> [--from 0] [--limit N]
```

**Options:**

| Flag | Type | Default | Description |
|:---|:---|:---|:---|
| `--group` | ENUM | *(required)* | Column group |
| `--name` | TEXT | *(required)* | Column name |
| `--value` | JSON | *(required)* | Fill value (JSON: `42`, `"hello"`, `true`, `null`) |
| `--from` | INT | `0` | Start row index |
| `--limit` | INT | *(all)* | Number of rows to fill |
| `-o, --output` | FORMAT | `auto` | Output format |

**Library:** `tktl.ops.datasets.fill_column(client, dataset_id, group, name, value, from_, limit) -> Dataset`

---

### 2.13 `tktl datasets sync-schema <SLUG> <DATASET_ID>`

Compare dataset columns against the flow version's input schema and report/apply drift.

```
tktl datasets sync-schema <SLUG> <DATASET_ID> --version <VERSION> [--apply]
```

**Options:**

| Flag | Type | Default | Description |
|:---|:---|:---|:---|
| `--version` | TEXT | *(required)* | Version name to sync against |
| `--apply` | BOOL | `false` | Actually apply changes (add missing columns, flag removed) |
| `-o, --output` | FORMAT | `auto` | Output format |

**Output (without --apply):**

```json
{
  "missing_columns": [{"name": "new_field", "desired_type": "string"}],
  "extra_columns": [{"name": "old_field", "desired_type": "number"}],
  "type_mismatches": [{"name": "income", "dataset_type": "string", "schema_type": "number"}]
}
```

With `--apply`: adds missing columns, reports extras (does not auto-delete — that's destructive).

**Library:** `tktl.ops.datasets.sync_schema(client, workspace_id, flow_slug, dataset_id, version_name, apply) -> SchemaDiff`

---

### 2.14 `tktl datasets download <DATASET_ID>`

Download a dataset as a file.

```
tktl datasets download <DATASET_ID> [--format csv] [--output <PATH>]
```

**Options:**

| Flag | Type | Default | Description |
|:---|:---|:---|:---|
| `--format` | ENUM | `csv` | File format: `csv` or `json` |
| `--output` | PATH | *(stdout)* | Output file path (omit for stdout) |

**Library:** `tktl.ops.datasets.download_dataset(client, dataset_id, fmt, output_path) -> str`

---

### 2.15 `tktl datasets delete <DATASET_ID>`

Delete a dataset permanently.

```
tktl datasets delete <DATASET_ID>
```

**Library:** `tktl.ops.datasets.delete_dataset(client, dataset_id) -> None`

---

## 3. API Endpoints

All dataset endpoints live on the **workspace base URL**: `{base_url}/datasets/api/v1`.

Auth: `X-Api-Key` header (same key as all other APIs).

### 3.1 Dataset CRUD

| Method | Endpoint | Purpose |
|:---|:---|:---|
| `POST` | `/datasets` | Create dataset (from scratch) |
| `GET` | `/datasets?flow_id={id}` | List datasets for a flow |
| `GET` | `/datasets/info/{id}` | Get lightweight info + ETag |
| `GET` | `/datasets/{id}?from_={n}&size={n}` | Get dataset with paginated rows |
| `PATCH` | `/datasets/{id}` | Update name/columns metadata |
| `DELETE` | `/datasets/{id}` | Delete dataset |

### 3.2 Rows

| Method | Endpoint | Purpose |
|:---|:---|:---|
| `POST` | `/datasets/{id}/rows` | Append rows (blank, duplicated, or from decision) |
| `PATCH` | `/datasets/{id}/rows/{row_id}` | Modify a row |
| `DELETE` | `/datasets/{id}/rows/{row_id}` | Delete a row |

Row append body variants:
- **Blank:** `{"source": "blank", "new_row_ids": ["uuid1", ...]}`  (max 50 per call)
- **Duplicated:** `{"source": "row_id", "row_id": "uuid", "new_row_ids": ["uuid1", ...]}`
- **From decision:** `{"source": "decision_id", "decision_id": "uuid", "new_row_ids": ["uuid1", ...]}`

Row update body: `{"input_data": {...}, "output_data": {...}, "mock_data": {...}, "meta_data": {...}, "outcome_data": {...}}`

### 3.3 Columns

| Method | Endpoint | Purpose |
|:---|:---|:---|
| `PUT` | `/datasets/{id}/columns` | Batch add/rename columns |
| `DELETE` | `/datasets/{id}/columns` | Batch delete columns |
| `PUT` | `/datasets/{id}/columns/{group}/{name}` | Add/rename single column |
| `DELETE` | `/datasets/{id}/columns/{group}/{name}` | Delete single column |
| `PATCH` | `/datasets/{id}/columns/{group}/{name}` | Fill column with value |

### 3.4 File Upload

| Method | Endpoint | Purpose |
|:---|:---|:---|
| `POST` | `/dataset_file_uploads` | Create upload job → presigned S3 URL |
| `GET` | `/dataset_file_uploads/{id}` | Poll upload status |

Upload flow:
1. `POST /dataset_file_uploads` with `{"flow_id": "...", "file_name": "data.csv"}` → returns `DatasetFileUpload` with `s3_presigned_url` and `s3_presigned_fields`
2. POST to S3 presigned URL with the fields as form data + file content
3. Poll `GET /dataset_file_uploads/{id}` until `status` is `COMPLETED`
4. On completion, `dataset_id` is set on the upload object

### 3.5 Download

| Method | Endpoint | Purpose |
|:---|:---|:---|
| `GET` | `/datasets/{id}/file?format={csv\|json}` | Download dataset as file |

---

## 4. Data Models

### 4.1 Enums

```python
class ColumnGroup(str, Enum):
    input_columns = "input_columns"
    output_columns = "output_columns"
    mock_columns = "mock_columns"
    meta_columns = "meta_columns"
    outcome_columns = "outcome_columns"

class ColumnType(str, Enum):
    string = "string"
    boolean = "boolean"
    number = "number"
    integer = "integer"
    object = "object"
    array = "array"
    datetime = "datetime"
    date = "date"
    any = "any"
    enum = "enum"
    files = "files"

class DatasetPurpose(str, Enum):
    test_run = "test_run"
    job_source = "job_source"
    simulation = "simulation"

class DatasetSource(str, Enum):
    file = "file"
    history = "history"
    scratch = "scratch"
    simulation_failures = "simulation_failures"
```

### 4.2 `DatasetColumn`

```python
class DatasetColumn(BaseModel):
    name: str
    desired_type: ColumnType
    use_subflow_mocks: bool = False
```

### 4.3 `DatasetRow`

```python
class DatasetRow(BaseModel):
    id: str
    input_data: dict[str, Any]
    output_data: dict[str, Any] | None = None
    mock_data: dict[str, Any] | None = None
    meta_data: dict[str, Any] | None = None
    outcome_data: dict[str, Any] | None = None
```

### 4.4 `Dataset`

```python
class Dataset(BaseModel):
    id: str
    name: str
    flow_id: str
    etag: str
    created_at: str
    updated_at: str
    source: DatasetSource
    purpose: DatasetPurpose = DatasetPurpose.test_run
    input_columns: list[DatasetColumn]
    output_columns: list[DatasetColumn]
    mock_columns: list[DatasetColumn]
    meta_columns: list[DatasetColumn] | None = None
    outcome_columns: list[DatasetColumn] | None = None
    row_count: int | None = None
```

### 4.5 `DatasetSummary`

```python
class DatasetSummary(BaseModel):
    id: str
    name: str
    flow_id: str
    source: DatasetSource
    purpose: DatasetPurpose
    row_count: int | None = None
    created_at: str
    updated_at: str
```

### 4.6 `SchemaDiff`

```python
class SchemaDiff(BaseModel):
    missing_columns: list[DatasetColumn]    # In schema but not in dataset
    extra_columns: list[DatasetColumn]      # In dataset but not in schema
    type_mismatches: list[TypeMismatch]     # Same name, different type

class TypeMismatch(BaseModel):
    name: str
    dataset_type: ColumnType
    schema_type: ColumnType
```

### 4.7 `DatasetFileUpload`

```python
class DatasetFileUpload(BaseModel):
    id: str
    flow_id: str
    file_name: str
    status: str                              # PENDING, COMPLETED, FAILED, PARTIALLY_COMPLETED
    s3_presigned_url: str
    s3_presigned_fields: dict[str, str]
    dataset_id: str | None = None
    error_metadata: str | None = None
    created_at: str
    updated_at: str
```

---

## 5. Architecture

Follows the library-first pattern:

| Layer | File | Responsibility |
|:---|:---|:---|
| **Models** | `src/tktl/models/dataset.py` | `Dataset`, `DatasetSummary`, `DatasetColumn`, `DatasetRow`, `SchemaDiff`, enums |
| **API** | `src/tktl/api/datasets.py` | HTTP calls to workspace datasets API (uses `TktlClient`) |
| **Ops** | `src/tktl/ops/datasets.py` | High-level operations: schema derivation, auto-batch, sync |
| **CLI** | `src/tktl/cli/datasets.py` | Typer sub-app (thin wrappers around ops) |

### 5.1 Dependency Flow

```
CLI (tktl.cli.datasets)
    ↓
Operations (tktl.ops.datasets)
    ↓  ↓
    ↓  Schema inspection (tktl.ops.versions.describe_version)
    ↓
API (tktl.api.datasets)
    ↓
TktlClient (httpx)
```

### 5.2 Key Design Decisions

1. **API layer uses TktlClient** — the existing `datasets.py` uses raw `httpx` calls with manual
   auth. The new functions use `TktlClient` for consistency with the rest of the codebase.
   The existing download functions are preserved for backward compatibility.

2. **Auto-batch row appends** — the API caps at 50 rows per POST. The ops layer handles batching
   transparently. For >50 rows with data, it uses file upload instead.

3. **Schema-aware creation** — `create_from_schema` reads `version.input_schema`, extracts
   property names and types, and maps them to `DatasetColumn` definitions.

4. **Sync is non-destructive by default** — `sync-schema` reports drift. With `--apply`, it
   adds missing columns but never deletes extras (user must explicitly delete).

---

## 6. Fake API Routes (Testing)

New routes to add to `tests/fake_api/`:

| Route | Method | Handler |
|:---|:---|:---|
| `/datasets/api/v1/datasets` | POST | `create_dataset` |
| `/datasets/api/v1/datasets` | GET | `list_datasets` |
| `/datasets/api/v1/datasets/{dataset_id}` | GET | `get_dataset` |
| `/datasets/api/v1/datasets/{dataset_id}` | PATCH | `patch_dataset` |
| `/datasets/api/v1/datasets/{dataset_id}` | DELETE | `delete_dataset` |
| `/datasets/api/v1/datasets/{dataset_id}/rows` | POST | `append_rows` |
| `/datasets/api/v1/datasets/{dataset_id}/rows/{row_id}` | PATCH | `update_row` |
| `/datasets/api/v1/datasets/{dataset_id}/rows/{row_id}` | DELETE | `delete_row` |
| `/datasets/api/v1/datasets/{dataset_id}/columns` | PUT | `upsert_columns` |
| `/datasets/api/v1/datasets/{dataset_id}/columns` | DELETE | `delete_columns` |
| `/datasets/api/v1/datasets/{dataset_id}/columns/{group}/{name}` | PATCH | `fill_column` |
| `/datasets/api/v1/datasets/{dataset_id}/file` | GET | `download_dataset_file` |
| `/dataset_file_uploads` | POST | `create_file_upload` |
| `/dataset_file_uploads/{id}` | GET | `get_file_upload` |

The `FakeState` dataclass needs to be extended with richer dataset state (columns, row data).
