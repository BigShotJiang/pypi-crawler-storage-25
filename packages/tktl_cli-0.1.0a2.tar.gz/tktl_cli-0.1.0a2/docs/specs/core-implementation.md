# tktl CLI — Technical Specification

> A developer- and agent-friendly CLI for managing Taktile decision flows.
> Designed to be fast for humans, surgical for AI agents, and safe for concurrent use.

---

## Table of Contents

1. [Design Principles](#1-design-principles)
2. [Architecture: Library-First](#2-architecture-library-first)
3. [API Client Generation](#3-api-client-generation)
4. [Installation & Setup](#4-installation--setup)
5. [Configuration](#5-configuration)
6. [Authentication](#6-authentication)
7. [Command Reference](#7-command-reference)
8. [Caching System](#8-caching-system)
9. [Concurrency & Locking](#9-concurrency--locking)
10. [Agent-Optimized Interface](#10-agent-optimized-interface)
11. [Data Formats & I/O Conventions](#11-data-formats--io-conventions)
12. [Error Handling](#12-error-handling)
13. [Testing & Fake API](#13-testing--fake-api)
14. [Repository Structure](#14-repository-structure)
15. [Tech Stack & Dependencies](#15-tech-stack--dependencies)

---

## 1. Design Principles

| Principle | What it means |
|:---|:---|
| **Library-first** | All functionality lives in importable Python functions. The CLI is a thin wrapper. An AI agent can `from tktl import flows` and call the same logic directly — no subprocess needed. |
| **Human-readable identifiers where possible** | Users refer to flows by **slug** and versions by **name** — never raw UUIDs. Nodes are the exception: node names are not unique within a version, so nodes are addressed by their **UUID**. The `nodes list` command serves as the lookup table to find the right ID. |
| **Surgical by default** | Every read and write targets the smallest possible object (a single node, a single parameter block). Full-document operations are opt-in. |
| **Agent-safe** | Commands return minimal, structured output. An AI agent never needs to load a 10,000-line JSON to change one field. |
| **Cache-first** | Reads hit the local hierarchical cache before touching the network. Writes invalidate only what changed. |
| **Concurrency-safe** | ETag-based optimistic locking and node-level locks are handled transparently — the user never manages them. |
| **Composable** | Every command writes structured JSON to stdout. Pipe it, `jq` it, feed it to another command. |

---

## 2. Architecture: Library-First

The package is structured so that **all business logic lives in plain Python functions** in the `tktl.api` and `tktl.ops` layers. The CLI (`tktl.cli`) is a thin Typer wrapper that parses args and calls those functions. This means the same operations are available to:

1. **Humans** via the `tktl` CLI.
2. **AI agents** via direct Python import (e.g., as Claude Code tool functions or MCP server tools).
3. **Scripts** via `import tktl`.

### 2.1 The Operations Layer (`tktl.ops`)

Every user-facing action is a function in `tktl.ops`. These functions:

- Accept typed arguments (Pydantic models or primitives), never raw CLI strings.
- Return typed results (Pydantic models or dicts), never formatted strings.
- Handle caching, ID resolution, locking, and retries internally.
- Raise typed exceptions on failure (see [Error Handling](#11-error-handling)).

```python
# Example: the same function powers both CLI and agent usage

from tktl.ops import flows, nodes

# List flows — returns List[FlowSummary]
result = flows.list_flows()

# Get a single node — returns NodeDetail
node = nodes.get_node(flow_slug="credit-scoring", version_name="v1", node_id="risk_engine_01")

# Update a node's parameters — returns NodeDetail (updated)
updated = nodes.update_node(
    flow_slug="credit-scoring",
    version_name="v1",
    node_id="risk_engine_01",
    params={"score_threshold": 750},
)
```

### 2.2 The CLI Layer (`tktl.cli`)

Each CLI command is a one-liner that:
1. Parses flags into typed args.
2. Calls the corresponding `tktl.ops` function.
3. Formats the result for stdout (table or JSON).

```python
# Simplified example — the CLI is trivially thin
@app.command()
def list_flows(output: OutputFormat = OutputFormat.auto):
    result = flows.list_flows()
    print_output(result, output)
```

### 2.3 Agent Import Pattern

An AI agent skill or MCP server can import and call ops functions directly:

```python
from tktl.ops.nodes import list_nodes, get_node, update_node

# No subprocess, no JSON parsing, no stdout capture.
# The agent gets native Python objects.
nodes = list_nodes(flow_slug="credit-scoring", version_name="v1")
```

This eliminates the overhead of spawning a subprocess, parsing JSON output, and gives the agent typed return values and typed exceptions.

---

## 3. API Client Generation

The `tktl.api` layer is **generated from the OpenAPI spec** (`src/tktl/openapi/flow-api-openapi.json`) rather than hand-written. This ensures the client stays in sync with the API and eliminates an entire class of bugs (wrong field names, missing parameters, stale endpoints).

### 3.1 Source Spec

The file `src/tktl/openapi/flow-api-openapi.json` (OpenAPI 3.1.0) is the single source of truth for all Flow API types and endpoints. It is checked into the repo under `src/tktl/openapi/`.

### 3.2 Code Generator

We use [openapi-python-client](https://github.com/openapi-generators/openapi-python-client) to generate a typed Python client from the spec.

```bash
# Regenerate the client after an API spec update
uv run generate-client
```

This is defined as a script in `pyproject.toml` and runs:

```bash
openapi-python-client generate \
  --path src/tktl/openapi/flow-api-openapi.json \
  --output-path src/tktl/generated \
  --config openapi-client-config.yaml
```

### 3.3 What Gets Generated

The generator produces:

- **`src/tktl/generated/models/`** — Pydantic v2 models for every schema in the spec (`FlowVersionV2`, `FlowVersionUpdate`, `GraphMergePatch`, `NodeDb`, `NodeUpsert`, `ResourceLock`, `ResourceLockUpsert`, all 25 node meta types, etc.).
- **`src/tktl/generated/api/`** — Typed functions for every endpoint (`get_flow_version_v2()`, `update_flow_version()`, `get_flows()`, etc.) with correct parameter types, headers, and response parsing.
- **`src/tktl/generated/client.py`** — A configured httpx-based client class.

### 3.4 How the Generated Code Fits In

```
┌─────────────────────────────────────────────────────┐
│  tktl.cli          (Typer CLI — parses args)        │
│  tktl.ops          (business logic, caching, locks) │
│  tktl.api          (hand-written orchestration)     │  ← uses generated client
│  tktl.generated    (auto-generated from OpenAPI)    │  ← never edit by hand
└─────────────────────────────────────────────────────┘
```

- **`tktl.generated`** — auto-generated, never edited by hand. Provides typed models and raw API call functions.
- **`tktl.api`** — thin hand-written layer that wraps the generated client with auth injection, base URL resolution (from config), and any call-specific header assembly (`if-match`, `session`).
- **`tktl.ops`** — business logic that composes API calls with caching, ID resolution, locking, and merge logic.

### 3.5 Regeneration Workflow

When the Taktile API changes:

1. Drop the updated `flow-api-openapi.json` into `src/tktl/openapi/`.
2. Run `uv run generate-client`.
3. Run tests — any breaking changes surface as type errors or test failures.
4. Commit both the updated spec and the regenerated code.

### 3.6 Generator Config (`openapi-client-config.yaml`)

```yaml
project_name_override: tktl-generated
package_name_override: tktl.generated
use_path_prefixes_for_title_model_names: true
field_prefix: field_
```

---

## 4. Installation & Setup

```bash
pip install tktl-cli          # or: pipx install tktl-cli
tktl auth login                # paste your API key
tktl config set org <ORG_ID>
tktl config set workspace <WORKSPACE_SLUG_OR_ID>
```

### First-run checklist

After login the CLI validates the API key, resolves the org/workspace, and writes the initial cache index.

---

## 5. Configuration

Configuration lives at `~/.tktl/config.json`.

### `tktl config set <KEY> <VALUE>`

| Key | Description | Default |
|:---|:---|:---|
| `org` | Organisation ID | *(required)* |
| `workspace` | Workspace slug or ID | *(required)* |
| `env` | Target environment | `sandbox` |
| `flow_api_url` | Override for the Flow API base URL | `https://flow-api.taktile.com` |
| `taktile_api_url` | Override for the Taktile API base URL | `https://api.taktile.com` |

### `tktl config get [KEY]`

Print one value, or the full config (without secrets).

### `tktl config list`

Pretty-print the active configuration.

### Config file schema

```jsonc
{
  "org": "org_abc123",
  "workspace": "my-workspace",
  "env": "sandbox",               // "sandbox" | "live"
  "flow_api_url": null,           // null = use default
  "taktile_api_url": null
}
```

---

## 6. Authentication

Credentials are stored in `~/.tktl/credentials.json` (file mode `0600`).

> **Two APIs.** The Taktile platform exposes two distinct API surfaces:
>
> | API | Config key | Default | Used by |
> |:---|:---|:---|:---|
> | **Flow API** | `flow_api_url` | `https://flow-api.taktile.com` | All flow-management commands: `flows list`, `flows describe`, `version get`, `nodes *`, locks, etc. |
> | **Taktile API** | `taktile_api_url` | `https://api.taktile.com` | `auth login` (key validation), `flows run` (flow execution), and workspace management. |
>
> Most CLI commands talk to the Flow API. Only `auth login` and `flows run` talk to the Taktile API.

### `tktl auth login`

Interactive prompt for the API key. The CLI validates the key against the **Taktile API** (not the Flow API) by calling:

```
POST {taktile_api_url}/api/v1/login/access-token
```

The API key is sent as a bearer token via the `Authorization` header (or `X-Api-Key` header). The endpoint accepts `APIKeyHeader`, `Authorization`, or `OAuth2PasswordBearer` security schemes. On success (HTTP 200) the response is a `TokenWithUserAndKey` object containing `access_token`, `token_type`, `refresh_token`, `id_token`, `user`, `api_key`, and `product_access` fields. A non-200 response (e.g. 401/403) means the key is invalid.

If validation succeeds, the API key is persisted to `~/.tktl/credentials.json`. If it fails, the CLI prints an error and does not store anything.

### `tktl auth logout`

Deletes the stored credential file.

### `tktl auth status`

Prints whether a valid credential exists and (if reachable) whether it is still accepted by the API.

### Credential schema

```jsonc
{
  "api_key": "sk-..."
}
```

All HTTP requests attach the key via the `X-Api-Key` header (primary) or `Authorization` header (alternative). Both are accepted by the API.

---

## 7. Command Reference

### 7.1 Flows

#### `tktl flows list`

List all flows in the active workspace.

**API:** `GET /api/v1/flows?workspace_id={workspace_id}`

**Output:** Array of flow summaries.

```jsonc
[
  { "slug": "credit-scoring", "id": "fl_abc", "name": "Credit Scoring" },
  // ...
]
```

**Flags:**
| Flag | Description |
|:---|:---|
| `--output table\|json` | Output format (default: `table` for TTY, `json` for non-TTY) |

**Library:** `tktl.ops.flows.list_flows() -> list[FlowSummary]`

---

#### `tktl flows <SLUG> describe`

Describe a single flow — metadata only, no version contents.

**API:** `GET /api/v1/flows/workspace_id/{workspace_id}/slug/{slug}?shallow=true`

**Output:**

```jsonc
{
  "slug": "credit-scoring",
  "id": "fl_abc",
  "name": "Credit Scoring",
  "workspace_id": "...",
  "created_at": "...",
  "updated_at": "...",
  "default_version": "fv_xyz",
  "default_sandbox_version": "fv_abc"
}
```

**Flags:**
| Flag | Description |
|:---|:---|
| `--summary` | One-line summary: slug, name, default version. Ideal for agents. |
| `--output table\|json` | Output format |

**Library:** `tktl.ops.flows.describe_flow(slug) -> FlowDetail`

---

### 7.2 Versions

#### `tktl flows <SLUG> versions list`

List all versions of a flow (names, IDs, statuses — no graph data).

**API:** `GET /api/v1/flows/workspace_id/{workspace_id}/slug/{slug}?shallow=true` — the flow object contains version summaries. The CLI extracts and returns just the version list.

**Output:** Array of version summaries.

```jsonc
[
  { "name": "v1", "id": "fv_xyz", "status": "DRAFT" },
  { "name": "v2", "id": "fv_abc", "status": "PUBLISHED" }
]
```

**Library:** `tktl.ops.versions.list_versions(flow_slug) -> list[VersionSummary]`

---

#### `tktl flows <SLUG> version <NAME> describe`

Metadata for a single version, **without** the node graph by default.

**API:** `GET /api/v2/flow_versions/{id}` (version ID resolved from slug + name via cache/index). The CLI strips the `graph` field from the response unless `--full` is passed.

**Output:**

```jsonc
{
  "name": "v1",
  "id": "fv_xyz",
  "status": "DRAFT",
  "etag": "abc123",
  "created_at": "...",
  "updated_at": "...",
  "parameters": [ { "name": "threshold", "value": 0.8 } ],
  "input_schema": { /* ... */ },
  "output_schema": { /* ... */ }
}
```

**Flags:**
| Flag | Description |
|:---|:---|
| `--full` | Include the entire version object (all nodes, edges, config). Use sparingly. |
| `--summary` | Minimal output: name, status, node count. |
| `--output table\|json` | Output format |

**Library:** `tktl.ops.versions.describe_version(flow_slug, version_name, full=False) -> VersionDetail`

---

### 7.3 Nodes

Nodes are embedded in the flow version graph — **there are no dedicated node endpoints in the API**. The CLI provides a surgical node-level interface by fetching the version (from cache when possible) and extracting/projecting individual nodes client-side.

#### `tktl flows <SLUG> version <NAME> nodes list`

Returns a lightweight index of all nodes — just enough for a human or agent to pick the right one.

**Why this is essential:** Node names are **not unique** within a version (e.g., two nodes can both be called "Transform"). Nodes must be addressed by their UUID. This command is the lookup table — run it first, find the UUID, then use it in `node describe` or `update --node`.

**Derived from:** The `graph.nodes` dict of the cached flow version (v2 format). Each node is projected to `{id, name, type}`.

**Output:**

```jsonc
[
  { "id": "a1b2c3d4-...", "name": "Risk Engine", "type": "decision_table" },
  { "id": "e5f6a7b8-...", "name": "Pricing Rule", "type": "scorecard" }
]
```

This is the "map of the city" — an agent sees a small table, not the entire graph.

**Library:** `tktl.ops.nodes.list_nodes(flow_slug, version_name) -> list[NodeSummary]`

---

#### `tktl flows <SLUG> version <NAME> node <NODE_ID> describe`

Returns the **full JSON** for a single node, extracted from the version graph.

**Output:** The complete node object as stored in `graph.nodes[node_id]`.

```jsonc
{
  "id": "risk_engine_01",
  "name": "Risk Engine",
  "type": "decision_table",
  "meta": { /* node-type-specific config — varies by type */ }
}
```

The `meta` field is polymorphic — its schema depends on `type` (e.g., `DecisionTableNodeMeta`, `ScorecardNodeMeta`, `TransformNodeMeta`, etc.). There are 25 node types.

**Flags:**
| Flag | Description |
|:---|:---|
| `--section meta\|name\|type` | Return only a specific field of the node. |
| `--output table\|json` | Output format |

**Library:** `tktl.ops.nodes.get_node(flow_slug, version_name, node_id, section=None) -> NodeDetail`

---

### 7.4 Updates

All update commands handle ETag negotiation and locking transparently.

#### `tktl flows <SLUG> version <NAME> update [FLAGS]`

The `update` command performs **surgical patches** (via `PATCH` with `FlowVersionUpdate`) or a **full version replace** (via `PUT`). There are two categories of targeted updates: **node-level** (targeting a single node in the graph) and **version-level** (targeting top-level version fields).

All targeted updates go through `PATCH /api/v1/flow_versions/{id}` with JSON Merge Patch semantics.

##### Node Update Flags

These flags require `--node <NODE_ID>` to identify the target node.

| Flag | Accepts | Effect |
|:---|:---|:---|
| `--node <NODE_ID>` | Node UUID | **Required** for `--node-config`. Identifies the node to update. |
| `--node-config <JSON\|@file>` | JSON or path | Deep-merges into the node's `meta` object via `GraphMergePatch`. |

**Example:**

```bash
# Update the meta config of a single node
tktl flows credit-scoring version v1 update \
  --node a1b2c3d4-... \
  --node-config '{"score_threshold": 750}'
```

**API body constructed:**

```jsonc
// PATCH /api/v1/flow_versions/{id}
// Headers: if-match: {etag}, session: {session_id}
{
  "graph": {
    "nodes": {
      "a1b2c3d4-...": {
        "meta": { /* user's partial update, deep-merged client-side */ }
      }
    }
  },
  "locks": {
    "lock_1": {
      "owner": "user_id",
      "session": "session_id",
      "resource_type": "node",
      "resource_id": "a1b2c3d4-...",
      "duration_secs": 300
    }
  }
}
```

Only the targeted node is included in the `GraphMergePatch` — all other nodes are left untouched.

**Internal flow for a node update:**

1. **Resolve identifiers** — slug → flow ID, version name → version ID, via cache or API.
2. **Fetch current version** — `GET /api/v2/flow_versions/{id}`. Cache the full version; extract the target node.
3. **Acquire lock** — include a `ResourceLockUpsert` for the target node in the PATCH body.
4. **Build merge patch** — deep-merge the user's update into the current node's `meta`, construct a `GraphMergePatch` containing only the affected node.
5. **PATCH** — `PATCH /api/v1/flow_versions/{id}` with `if-match: {etag}` and `session` headers.
6. **Release lock** — send a follow-up PATCH with the lock key set to `null` (JSON Merge Patch deletion).
7. **Update cache** — write the new node state to the per-node cache file; update the version metadata/etag.

**Library:** `tktl.ops.nodes.update_node(flow_slug, version_name, node_id, meta: dict) -> NodeDetail`

##### Version-Level Update Flags

These flags target **top-level version fields** — no `--node` required.

| Flag | Accepts | Effect |
|:---|:---|:---|
| `--params <JSON\|@file>` | JSON or path | Updates the version's `parameters` array (matched by `name`). |
| `--schema-in <JSON\|@file>` | JSON or path | Replaces the version's `input_schema`. |
| `--schema-out <JSON\|@file>` | JSON or path | Replaces the version's `output_schema`. |

**Example:**

```bash
# Update the version's input schema
tktl flows credit-scoring version v1 update \
  --schema-in @schemas/credit_input.json

# Update a parameter value
tktl flows credit-scoring version v1 update \
  --params '[{"name": "threshold", "value": 0.85}]'
```

**API body constructed:**

```jsonc
// PATCH /api/v1/flow_versions/{id}
// Headers: if-match: {etag}
{
  "input_schema": { /* full replacement */ }
}
```

**Library:** `tktl.ops.versions.update_version(flow_slug, version_name, params=None, schema_in=None, schema_out=None) -> VersionDetail`

##### Bulk Update Flag (Full Replace — PUT)

| Flag | Accepts | Effect |
|:---|:---|:---|
| `--file <PATH>` | Local JSON file | Replaces the **entire version** object via `PUT /api/v2/flow_versions/{id}?by_etag={etag}`. |

The CLI reads the file, resolves the current ETag, and sends the PUT. **Use with caution** — this is the "big hammer."

**Library:** `tktl.ops.versions.replace_version(flow_slug, version_name, body: dict) -> VersionDetail`

---

### 7.5 Run

#### `tktl flows <SLUG> run`

Execute a flow via the workspace's **Decide API** — a per-workspace endpoint that is *not* part of the Flow API or Taktile API.

**How execution works (3-step resolution):**

1. **Resolve workspace base URL** — `GET /api/v1/workspaces/{workspace_id}` on the Flow API returns the workspace object, which includes a `base_url` field (e.g., `https://risk.5738c673.decide.taktile.com`).
2. **Build decide URL** — The execution endpoint is: `POST {base_url}/run/api/v1/flows/{slug}/{env}/decide` where `env` is `sandbox` or `live` (from config).
3. **Send request** — The input payload conforms to the Decide API schema:

```jsonc
{
  "data": { /* matches the flow version's input_schema */ },
  "metadata": {
    "version": "v1",        // version name — specified in the payload, not a CLI flag
    "entity_id": "optional"
  },
  "control": {
    "execution_mode": "sync"  // "sync" or "async"
  }
}
```

The CLI wraps the user's input data into this structure. The version name is included in `metadata.version`.

**Flags:**
| Flag | Description |
|:---|:---|
| `-f, --file <PATH>` | Path to a JSON input file (the `data` portion). |
| `--input <JSON>` | Inline JSON input (alternative to `--file`). |
| `--version <NAME>` | Version name (default: uses the published version). |
| `--env sandbox\|live` | Override the environment for this execution. |
| `--output table\|json` | Output format (default: `json`) |

There is no dry-run mode — the execution endpoint does not support it.

**Internal flow:**

1. Resolve `workspace_id` from config.
2. Fetch workspace from Flow API → extract `base_url`.
3. Build decide URL: `{base_url}/run/api/v1/flows/{slug}/{env}/decide`.
4. Wrap input data into `{data, metadata: {version}, control: {execution_mode: "sync"}}`.
5. POST with `X-Api-Key` header.
6. Return the response (`DecideResponse`).

The workspace `base_url` is cached after first resolution.

**Library:** `tktl.ops.flows.run_flow(client, workspace_id, slug, input_data, version=None, env=None) -> dict`

---

### 7.6 Version Lifecycle

#### `tktl flows <SLUG> version <NAME> publish`

Publish a draft version by setting its status to `PUBLISHED`.

**API:** `PATCH /api/v1/flow_versions/{id}` with `{"status": "PUBLISHED"}`.

**Library:** `tktl.ops.versions.publish_version(flow_slug, version_name) -> VersionDetail`

#### `tktl flows <SLUG> version <NAME> archive`

Archive a version by setting its status to `ARCHIVED`.

**API:** `PATCH /api/v1/flow_versions/{id}` with `{"status": "ARCHIVED"}`.

**Library:** `tktl.ops.versions.archive_version(flow_slug, version_name) -> VersionDetail`

#### `tktl flows <SLUG> version create <NAME>`

Create a new draft version for a flow.

**API:** `POST /api/v1/flow_versions` with `{"flow_id": "...", "name": "...", "status": "DRAFT"}`.

**Library:** `tktl.ops.versions.create_version(flow_slug, version_name) -> VersionDetail`

#### `tktl flows <SLUG> version <NAME> duplicate [--name <NEW_NAME>]`

Duplicate a version within the same flow.

**API:** `POST /api/v1/flow_versions/{id}/duplicate` with `{"name": "...", "status": "DRAFT"}`.

**Library:** `tktl.ops.versions.duplicate_version(flow_slug, version_name, new_name) -> VersionDetail`

---

### 7.7 Change History

#### `tktl flows <SLUG> version <NAME> changes [--after <ETAG>] [--limit <N>]`

View the change log for a version. Each change entry has an `etag`, an `authored_by` user, and either a `diff` (partial update) or a `checkpoint` (full snapshot).

**API:** `GET /api/v2/flow_versions/{id}/changes?after_etag={etag}&max_limit={limit}`

**Library:** `tktl.ops.versions.list_changes(flow_slug, version_name, after_etag=None, limit=100) -> list[ChangeEntry]`

---

### 7.8 Batch Run

Batch run commands execute multiple decisions from a file and track results for later inspection. See **[`docs/specs/batch-run.md`](batch-run.md)** for the full specification.

#### `tktl flows batch <SLUG> --file <PATH>`

Execute multiple decisions from a CSV, JSON array, single JSON object, or JSONL/NDJSON file. Max 1000 rows. Results are stored as append-only JSONL in `~/.tktl/runs/{slug}/{run_id}/`.

**Flags:** `--file` (required), `--concurrency` (default 10), `--version`, `--env`, `--output`, `--quiet`

**Library:** `tktl.ops.batch.run_batch(client, workspace_id, slug, file_path, ...) -> BatchResult`

#### `tktl flows history <SLUG>`

List past batch runs or inspect a specific run. With `--run-id`, shows run details. With `--run-id` and `--query`, extracts a specific field from each result row using dot/bracket path notation (e.g. `output.data.decision`, `output.scores[0].value`).

**Flags:** `--run-id`, `--query`, `--output`, `--quiet`

**Library:** `tktl.ops.batch.list_batch_runs()`, `get_batch_run()`, `get_batch_results()`, `extract_query()`

---

## 8. Caching System

The cache eliminates redundant network calls and keeps payloads small — critical for agent workflows where every token counts.

### 8.1 Why Client-Side Node Extraction?

The Taktile Flow API has **no node-level endpoints**. Nodes are always embedded in the flow version's `graph.nodes` dict. A full version can be 10,000+ lines of JSON. The cache solves this by:

1. Fetching the full version **once**.
2. Decomposing it into per-node files on disk.
3. Serving subsequent node reads from these small files.

This means `tktl ... node <ID> describe` reads a ~50-line file from disk, not a 10,000-line API response.

### 8.2 Cache Location

`~/.tktl/cache/`

### 8.3 Directory Structure

```
~/.tktl/cache/
├── index.json                         # slug→ID, version name→ID mappings
├── flows/
│   └── {flow_id}/                     # one dir per flow (keyed by UUID)
│       ├── metadata.json              # flow-level metadata
│       └── versions/
│           └── {version_id}/          # one dir per version (keyed by UUID)
│               ├── metadata.json      # version metadata + etag (no graph)
│               ├── full.json          # full version snapshot (for --full / bulk ops)
│               └── nodes/
│                   ├── _index.json    # node list: [{id, name, type}]
│                   ├── {node_id}.json # individual node (graph.nodes[id])
│                   └── ...
```

### 8.4 Index File (`index.json`)

Lightweight lookup table. Loaded once per CLI invocation to resolve slugs → IDs.

```jsonc
{
  "workspace_id": "ws_abc123",
  "flows": {
    "credit-scoring": {
      "id": "fl_abc",
      "versions": {
        "v1": "fv_xyz",
        "v2": "fv_abc"
      }
    }
  },
  "updated_at": "2026-03-17T10:00:00Z"
}
```

### 8.5 Cache Behaviour

| Operation | Cache action |
|:---|:---|
| **Read (list/describe/get)** | Return cached data if fresh. Otherwise fetch, cache, return. |
| **Write (update)** | After a successful API write, update only the affected cache file(s). |
| **`tktl cache refresh`** | Force-rebuild the entire cache for the current workspace. |
| **`tktl cache clear`** | Delete `~/.tktl/cache/` entirely. |
| **`tktl cache status`** | Print cache age, size, and staleness per flow. |

### 8.6 Freshness

Each cached file stores a `_cached_at` ISO timestamp. The CLI considers data **stale** after a configurable TTL (default: 5 minutes). Stale data is still returned but triggers a background refresh. Writes always go to the API and invalidate affected cache entries immediately.

### 8.7 ETag Storage

The version `metadata.json` stores the last-seen `etag` string. This is used for:

- **Conditional fetches:** `GET /api/v2/flow_versions/{id}` with `if-none-match: {etag}` — the API returns `304 Not Modified` if unchanged, saving bandwidth.
- **Optimistic locking on writes:** `PATCH /api/v1/flow_versions/{id}` with `if-match: {etag}`.

If the server returns `412 Precondition Failed`, the CLI automatically retries (see [Optimistic Locking](#91-optimistic-locking-etags)).

---

## 9. Concurrency & Locking

### 9.1 Optimistic Locking (ETags)

Every flow version has an `etag` string. The CLI attaches `if-match: {etag}` on every `PATCH`/`PUT`. If the server rejects with `412 Precondition Failed`, the CLI **automatically retries**:

1. **Re-fetch** — `GET /api/v2/flow_versions/{id}` to get the latest version and its current etag.
2. **Re-apply** — rebuild the patch against the fresh state (re-merge the user's changes into the updated node/version).
3. **Re-send** — `PATCH`/`PUT` with the new etag.
4. **Repeat** — up to 3 retries. If all fail, surface an error:

```
Error: Version "v1" has been modified 3 times during update — giving up.
Another user or process is actively editing this version.
```

This is safe for **targeted updates** (node config, params, schemas) because the CLI re-merges the user's small patch into whatever the latest state is — it doesn't blindly resend stale data. For **bulk updates** (`--file`), the retry re-reads the user's file but uses the fresh etag; the user is responsible for ensuring their file is compatible with the current state.

### 9.2 Node-Level Locks

Locks are **embedded in the flow version**, not managed via separate endpoints. The `FlowVersionUpdate` body includes a `locks` dict of `ResourceLockUpsert` objects.

**Lock model (`ResourceLockUpsert`):**

```jsonc
{
  "owner": "user-uuid",           // the user acquiring the lock
  "session": "session-id",        // the CLI session identifier
  "resource_type": "node",        // enum: flow, flow_version, parameter, node, schema
  "resource_id": "risk_engine_01",// the node being locked
  "duration_secs": 300            // lock TTL in seconds
}
```

**Lock lifecycle:**

1. **Acquire** — include the lock in the `locks` dict of the PATCH body. The lock is created atomically with the update.
2. **Release** — send a follow-up PATCH with the lock key set to `null` (JSON Merge Patch deletion semantics).
3. **Expiry** — locks have a `duration_secs` TTL. Expired locks are automatically ignored by the server.

The CLI also sends a `session` header on PATCH requests to identify the editing session. The `GET /api/v2/keepalive/` endpoint can be used to keep sessions alive during long operations.

### 9.3 Checking for Existing Locks

Before updating, the CLI reads the version's `locks` array from the response. If the target node is already locked by a different session:

```
Error: Node "risk_engine_01" is locked by session "other-session" (expires in 4m 30s).
Retry after the lock expires, or use --force to break the lock.
```

### 9.4 `--force` Flag

Available on `update` commands. Overwrites an existing lock by sending a new lock with the CLI's own session. Requires confirmation unless `--yes` is also passed.

---

## 10. Agent-Optimized Interface

These conventions ensure that an AI agent can operate efficiently without flooding its context window.

### 10.1 The Problem

A full flow version can be 10,000+ lines of JSON. Feeding this into an agent:
- Wastes tokens (cost, latency).
- Increases hallucination risk (the agent may corrupt unrelated nodes).
- Makes diffs unreadable.

### 10.2 The Solution: Surgical Getters and Setters

| Agent workflow step | CLI command | Context cost |
|:---|:---|:---|
| "What flows exist?" | `tktl flows list` | ~3 lines per flow |
| "What versions does this flow have?" | `tktl flows <S> versions list` | ~2 lines per version |
| "What nodes are in v1?" | `tktl flows <S> version v1 nodes list` | ~3 lines per node |
| "Show me the risk engine" | `tktl flows <S> version v1 node risk_engine_01 describe` | ~20-50 lines |
| "Update the score threshold" | `tktl flows <S> version v1 update --node risk_engine_01 --node-config '{"score_threshold": 750}'` | 1 command |

The agent navigates a tree: **flows → versions → nodes → sections** — never loading the full graph.

### 10.3 Direct Import (Zero-Overhead Agent Integration)

For agents running in-process (e.g., Claude Code skills, MCP servers), the `tktl.ops` functions can be imported directly. This avoids subprocess overhead and stdout parsing entirely:

```python
from tktl.ops.nodes import list_nodes, get_node, update_node

# Returns typed Python objects — no JSON parsing needed
nodes = list_nodes(flow_slug="credit-scoring", version_name="v1")
node = get_node(flow_slug="credit-scoring", version_name="v1", node_id="risk_engine_01")
updated = update_node(
    flow_slug="credit-scoring", version_name="v1",
    node_id="risk_engine_01",
    meta={"score_threshold": 750},
)
```

### 10.4 `--summary` Flag

Available on `describe` commands. Returns a one-line-per-item summary. Ideal as the first command an agent runs to orient itself.

```bash
$ tktl flows credit-scoring version v1 describe --summary
# v1 | DRAFT | 12 nodes | updated 2h ago
```

### 10.5 `--section` Flag

Available on `node describe`. Returns only one field of the node.

```bash
$ tktl flows credit-scoring version v1 node risk_engine_01 describe --section meta
# Returns ONLY the meta block — not name, not type.
```

### 10.6 Auto-JSON for Non-TTY

When stdout is not a TTY (script or agent), the CLI defaults to `--output json`. When stdout is a TTY, it defaults to `--output table`.

### 10.7 Exit Codes

| Code | Meaning |
|:---|:---|
| `0` | Success |
| `1` | General error |
| `2` | Invalid usage / bad arguments |
| `3` | Authentication failure |
| `4` | Resource not found (bad slug, bad node ID) |
| `5` | Conflict (ETag mismatch, lock held by another) |
| `6` | Network error / API unreachable |

---

## 11. Data Formats & I/O Conventions

### 11.1 JSON Input

Any flag that accepts JSON supports two forms:

- **Inline:** `--node-config '{"key": "value"}'`
- **File reference:** `--node-config @path/to/file.json`

The `@` prefix tells the CLI to read the file.

### 11.2 Output Formats

| Format | Flag | When |
|:---|:---|:---|
| **table** | `--output table` | Default for TTY. Human-readable columns. |
| **json** | `--output json` | Default for non-TTY. Machine-parseable. |

### 11.3 Quiet Mode

`--quiet` suppresses all informational output (progress, cache status). Only the result (or error) is printed. Useful for scripting and agents.

---

## 12. Error Handling

### 12.1 Exception Hierarchy (Library Layer)

The `tktl.ops` functions raise typed exceptions that both the CLI and agent consumers can handle:

```python
class TktlError(Exception):
    """Base exception. All tktl errors inherit from this."""
    code: int  # maps to the CLI exit code

class AuthError(TktlError):         # code 3
class NotFoundError(TktlError):     # code 4 — bad slug, version name, or node ID
class ConflictError(TktlError):     # code 5 — ETag mismatch or lock conflict
class NetworkError(TktlError):      # code 6
class UsageError(TktlError):        # code 2
```

### 12.2 CLI Error Output

The CLI catches `TktlError` subclasses and formats them for the terminal:

- **stderr** receives the error message.
- **JSON mode** outputs structured error JSON to stderr:

```jsonc
{
  "error": {
    "code": 5,
    "type": "conflict",
    "message": "Version \"v1\" was modified since your last read.",
    "hint": "Run `tktl flows credit-scoring version v1 describe` to refresh."
  }
}
```

### 12.3 Retry Behaviour

- **Network errors (code 6):** The ops layer retries up to 3 times with exponential backoff (1s, 2s, 4s).
- **ETag conflicts (412):** Auto-retried up to 3 times. The CLI re-fetches the latest version, re-merges the patch, and resends. Fails after 3 attempts.
- **Auth errors (code 3):** Never retried.

---

## 13. Testing & Fake API

### 13.1 Strategy

Tests run against a **fake Flow API server** that implements the same endpoints as the real API, backed by in-memory state. This gives us:

- **Full integration tests** — the entire stack (CLI → ops → api → HTTP → server → response) is exercised without mocking internals.
- **Deterministic state** — each test starts with a known set of flows, versions, and nodes.
- **Offline & fast** — no network calls, no rate limits, no flaky dependencies.
- **ETag/lock fidelity** — the fake server enforces the same concurrency rules (412 on stale ETags, lock conflicts), so locking logic is tested for real.

### 13.2 Fake Server Architecture

The fake server is a lightweight ASGI app (using [Starlette](https://www.starlette.io/) or plain httpx transport) that implements the subset of Flow API endpoints the CLI uses. It stores state in plain Python dicts.

```python
# tests/fake_api/state.py — the in-memory "database"
@dataclass
class FakeState:
    flows: dict[str, FlowDb]                    # flow_id → flow
    versions: dict[str, FlowVersionV2]          # version_id → version (v2 format, dict-keyed graph)
    locks: dict[str, ResourceLock]              # lock_id → lock
    etag_counter: int = 0                       # monotonic counter for generating etags

    def next_etag(self) -> str:
        self.etag_counter += 1
        return str(self.etag_counter)
```

### 13.3 Endpoints Implemented

| Endpoint | Behaviour |
|:---|:---|
| `GET /api/v1/flows` | Filter by `workspace_id`, return flow list from state. |
| `GET /api/v1/flows/workspace_id/{ws}/slug/{slug}` | Lookup by slug, return flow with version summaries. |
| `GET /api/v2/flow_versions/{id}` | Return version from state. Honour `if-none-match` (return 304 if etag matches). |
| `PATCH /api/v1/flow_versions/{id}` | Apply JSON Merge Patch to version in state. Enforce `if-match` (return 412 on mismatch). Process `locks` dict. Bump etag. |
| `PUT /api/v2/flow_versions/{id}` | Replace version in state. Require `by_etag` query param, enforce match. |
| `POST /api/v1/flow_versions` | Create new version in state. |
| `POST /api/v1/flow_versions/{id}/duplicate` | Deep-copy version with new name. |
| `DELETE /api/v1/flow_versions/{id}` | Remove from state, return 204. |
| `GET /api/v2/flow_versions/{id}/changes` | Return change log (tracked on each PATCH/PUT). |

### 13.4 Seed Data / Fixtures

A pytest fixture provides a pre-populated `FakeState` with realistic data:

```python
@pytest.fixture
def fake_state() -> FakeState:
    """A workspace with two flows, each with draft + published versions and multiple node types."""
    return build_seed_state(
        flows=[
            SeedFlow(slug="credit-scoring", versions=[
                SeedVersion(name="v1", status="PUBLISHED", nodes=[
                    SeedNode(id="input_node",       type="input",          name="Input"),
                    SeedNode(id="risk_engine_01",   type="decision_table", name="Risk Engine"),
                    SeedNode(id="pricing_rule",     type="scorecard",      name="Pricing Rule"),
                    SeedNode(id="output_node",      type="output",         name="Output"),
                ]),
                SeedVersion(name="v2-draft", status="DRAFT", nodes=[
                    SeedNode(id="input_node",       type="input",          name="Input"),
                    SeedNode(id="risk_engine_02",   type="decision_table", name="Risk Engine v2"),
                    SeedNode(id="ml_model_01",      type="ml",             name="ML Scorer"),
                    SeedNode(id="output_node",      type="output",         name="Output"),
                ]),
            ]),
            SeedFlow(slug="kyc-check", versions=[
                SeedVersion(name="v1", status="DRAFT", nodes=[
                    SeedNode(id="input_node",       type="input",          name="Input"),
                    SeedNode(id="data_fetch",       type="data_integration", name="ID Verification"),
                    SeedNode(id="output_node",      type="output",         name="Output"),
                ]),
            ]),
        ],
    )
```

### 13.5 Wiring into Tests

The fake server is injected as an httpx transport, so the real HTTP client code runs but requests never leave the process:

```python
@pytest.fixture
def tktl_client(fake_state: FakeState) -> TktlClient:
    """A tktl API client wired to the fake server."""
    fake_app = create_fake_app(fake_state)
    transport = httpx.MockTransport(fake_app)
    return TktlClient(
        base_url="https://fake-flow-api.taktile.com",
        transport=transport,
        api_key="test-key",
    )
```

This means:
- `tktl.api` code is tested with real HTTP semantics (headers, status codes, content-type).
- `tktl.ops` code is tested end-to-end (ID resolution, caching, locking, merge, PATCH construction).
- `tktl.cli` code is tested via `typer.testing.CliRunner` with the client injected.

### 13.6 What the Fake Server Enforces

| Rule | Implementation |
|:---|:---|
| **ETag mismatch → 412** | Every mutation bumps the version etag. PATCH/PUT with stale `if-match` or `by_etag` returns 412. |
| **Lock conflicts** | If a node lock exists with a different `session`, the fake rejects the PATCH with a lock-conflict error. |
| **Lock expiry** | Locks with `duration_secs` past their `timestamp` are ignored. |
| **JSON Merge Patch** | `PATCH` applies RFC 7396 merge semantics: `null` values delete keys, missing keys are unchanged. |
| **304 Not Modified** | `GET` with `if-none-match` matching the current etag returns 304 with no body. |
| **404 on missing resources** | Bad flow ID, version ID, or slug returns 404. |

### 13.7 Test Categories

| Category | What it tests | Example |
|:---|:---|:---|
| **`test_ops/`** | Full integration through the ops layer | `update_node()` acquires lock, patches, releases lock, updates cache |
| **`test_cli/`** | CLI arg parsing + formatted output | `tktl flows list --output json` returns valid JSON array |
| **`test_api/`** | HTTP request construction | Correct headers, query params, body shape |
| **`test_cache/`** | Cache read/write/invalidation | Node file is updated after a successful `update_node()` |
| **`test_concurrency/`** | ETag conflicts and lock behaviour | Two concurrent updates to the same node, one gets 412 |
| **`test_merge.py`** | Deep-merge logic | Partial meta update preserves unmodified fields |
| **`test_integration/`** | Real dev environment | Read-only tests against live Taktile dev API |

### 13.8 Integration Tests (Real Dev Environment)

In addition to the fake API tests, the project includes **read-only integration tests** that hit the real Taktile dev environment. These verify the full stack against real API responses.

**Configuration:** Tests read from a `.env` file (local) or environment variables (CI):

```bash
# .env (git-ignored, copied from .env.example)
TKTL_DEV_API_KEY=your-dev-api-key
TKTL_DEV_FLOW_API_URL=https://flow-api.dev.cp.taktile.com
TKTL_DEV_WORKSPACE_ID=61174b45-d517-417d-87e3-0222d13135d6
TKTL_DEV_FLOW_SLUG=no-op-2
TKTL_DEV_VERSION_NAME=Policy Enforcement v6
```

**Running locally:**
```bash
cp .env.example .env   # fill in TKTL_DEV_API_KEY
uv run pytest tests/test_integration -v
```

**Running in CI:** The `DEV_API_KEY` GitHub Actions secret is mapped to `TKTL_DEV_API_KEY`.

**Safety:** All integration tests are **read-only** — they list flows, describe versions, list nodes, and read individual nodes. They never create, modify, or delete anything. They are marked with `@pytest.mark.integration` and auto-skipped when `TKTL_DEV_API_KEY` is not set.

---

## 14. Repository Structure

This section defines the canonical layout of the tktl-cli repository and the design
decisions behind it. Any file in the repo should have a clear home based on these rules.

### 14.1 Design Principles

| Principle | What it means |
|:---|:---|
| **Agent-vendor neutrality** | Skills follow the [agentskills.io](https://agentskills.io) open format — adopted by 35+ agent products (Claude Code, Cursor, Copilot, Codex, Gemini CLI, etc.). Any agent can discover and execute them. The repo never assumes a specific vendor. |
| **Package colocation** | Files consumed by the `tktl` package at build, install, or runtime belong inside `src/tktl/`. External tools reference them via the package, not via repo-root-relative paths. |
| **Root directory hygiene** | The repo root contains only standard files (`README.md`, `CLAUDE.md`, `AGENTS.md`, `pyproject.toml`) and standard directories (`src/`, `tests/`, `docs/`, `scripts/`, `skills/`). Everything else nests under one of these. |
| **Skills over commands** | Reusable agent workflows live in `skills/` following the agentskills.io directory convention. Skill-specific reference docs live in `skills/<name>/references/`. No `.claude/commands/` directory — skills are the canonical location. |
| **Docs consolidation** | All project-level documentation (`specs/`, `plans/`) lives under `docs/`. Skill-specific reference docs (node configs, flow patterns, debugging) live inside their skill directory's `references/` folder, not at the project level. |

### 14.2 Top-Level Layout

```
tktl-cli/
├── skills/                              # Agent skills (agentskills.io format)
│   ├── flow-builder/                    # Main flow-builder skill
│   │   ├── SKILL.md                     # Patterns, gotchas, reference
│   │   └── references/                  # Skill-specific reference docs
│   │       ├── node-configs.md          # Per-type node configuration examples
│   │       ├── flow-patterns.md         # Reusable decision flow patterns
│   │       ├── debugging.md             # Flow failure diagnosis
│   │       ├── executing-flows-and-local-testing.md
│   │       └── working-with-child-flows-and-loop-nodes.md
│   ├── create-flow/                     # Multi-phase flow creation workflow
│   │   └── SKILL.md
│   ├── onboard-flow/                    # Generate flow documentation for existing flows
│   │   └── SKILL.md
│   ├── flow-review/                     # Review flows, generate adversarial test data
│   │   ├── SKILL.md
│   │   └── references/                  # Checklists, known issues
│   └── flow-summary/                    # Analyze flow JSON, produce summary docs
│       └── SKILL.md
│
├── src/tktl/                            # Python package (see §14.3)
│
├── tests/                               # Test suite (see §14.4)
│
├── docs/                                # Project-level documentation
│   ├── specs/                           # Technical specifications (source of truth)
│   │   ├── core-implementation.md       # This file
│   │   ├── batch-run.md
│   │   ├── datasets.md
│   │   ├── flow-review.md
│   │   ├── render.md
│   │   └── posthog-instrumentation.md
│   └── plans/                           # Implementation tracking (done/in-progress)
│
├── scripts/                             # Dev tooling (pre-commit hooks, etc.)
│
├── AGENTS.md                            # Implementation guide (developer source of truth)
├── CLAUDE.md                            # Claude Code instructions
├── README.md                            # Package overview & usage
├── pyproject.toml                       # uv-managed, single source of truth for deps
└── uv.lock                              # Locked dependency graph
```

#### Why `skills/` instead of `.claude/commands/`

`.claude/commands/` is a Claude Code-specific mechanism — files there can only be
invoked via Claude Code's `/command` slash-command interface. But `create-flow.md` and
`onboard-flow.md` are really *agent skills*: reusable workflows that any agent should
be able to discover and execute. Locking them into `.claude/commands/` makes the repo
agent-vendor-specific.

We adopt the [agentskills.io](https://agentskills.io) open format instead. Each skill
is a directory containing a `SKILL.md` with YAML frontmatter (`name`, `description`,
`compatibility`) plus optional `scripts/`, `references/`, and `assets/` subdirectories.
This format is supported by 35+ agent products. No `.claude/commands/` stubs are
needed — agents discover skills directly from the `skills/` directory.

#### Skill format (agentskills.io)

Each skill directory follows this structure:

```
skill-name/
  SKILL.md          # Required: YAML frontmatter + markdown instructions
  scripts/          # Optional: executable helpers
  references/       # Optional: detailed reference docs (loaded on demand)
  assets/           # Optional: templates, config files
```

The `SKILL.md` frontmatter:

```yaml
---
name: skill-name            # Must match directory name. Lowercase, hyphens, max 64 chars.
description: >
  What this skill does and when to use it.
  Use imperative phrasing: "Use when..."
compatibility: Requires Python 3.11+ and the tktl-cli package
metadata:
  author: taktile-org
  version: "1.0"
---
```

**Progressive disclosure:** Agents load only `name` + `description` at session start
(~50-100 tokens per skill). Full instructions are loaded only when the skill is
activated. Keep `SKILL.md` under 500 lines / 5000 tokens — move detailed reference
material to `references/` files.

**Writing effective skills:**
- Focus on what the agent *doesn't* know — project-specific conventions, non-obvious
  edge cases, specific API quirks. Skip explaining HTTP or databases.
- Favor procedures over declarations — teach *how to approach* a class of problems.
- Include gotchas sections — environment-specific facts that defy assumptions.
- Provide defaults, not menus — pick one recommended approach, mention alternatives briefly.

#### Why existing loose files move into skill directories

Files like `SKILL.md`, `IMPROVE.md`, `FLOW_REVIEW_AGENT.md`, `flow-summary-CLAUDE.md`,
and `issues.md` all serve agent personas — they provide context, patterns, and known
issues that agents use when building or reviewing flows. Scattering them across the
repo root makes discovery hard and doesn't follow any standard.

In the agentskills.io model, `IMPROVE.md` and `issues.md` become `references/` files
inside the relevant skill directory (e.g., `flow-review/references/known-issues.md`),
loaded on demand rather than polluting the catalog. The answer to "what can an agent do
with this repo?" becomes `ls skills/`.

#### Why reference docs move into skill directories

The top-level `docs/` directory contained files like `node-configs.md`,
`flow-patterns.md`, `debugging.md`, `executing-flows-and-local-testing.md`,
and `working-with-child-flows-and-loop-nodes.md`. These are all consumed by
agents when building or debugging flows — they are reference material for the
`flow-builder` skill, not project-level documentation. Keeping them in a
generic `docs/` directory obscures their relationship to the skill that uses
them.

In the agentskills.io model, these become `references/` files inside
`skills/flow-builder/references/`, loaded on demand when the skill is
activated. Project-level documentation (`specs/`, `plans/`) moves under
`docs/` instead, which now serves as the home for project-scoped documents
rather than skill-specific ones.

#### Why `templates/` moves into the package

The top-level `templates/` directory contains JSON reference configs for node types.
These are consumed by the CLI via `--config @template.json` and belong with the
package source. `src/tktl/ops/templates.py` already contains flow-creation templates
(Python code) — the node config templates (JSON) should live nearby at
`src/tktl/templates/`.

**Template filenames must match canonical API node types.** The current files use
shorthand names (`assignment.json`, `rule.json`) but the API type strings used
throughout the codebase are `assignment_node` and `rule_2` respectively (see
`_normalize_type()` in `ops/graph.py` and the type maps in `ops/render.py`). The
rename to `assignment_node.json` and `rule_2.json` makes the mapping 1:1 — given a
node's `type` field from the API, the template file is always `{type}.json`. No
lookup table or aliasing logic needed.

| Current filename | Canonical API type | New filename |
|:---|:---|:---|
| `assignment.json` | `assignment_node` | `assignment_node.json` |
| `rule.json` | `rule_2` | `rule_2.json` |
| `scorecard.json` | `scorecard` | `scorecard.json` (unchanged) |
| `decision_table.json` | `decision_table` | `decision_table.json` (unchanged) |
| `matrix_table.json` | `matrix_table` | `matrix_table.json` (unchanged) |
| `transform.json` | `transform` | `transform.json` (unchanged) |

Code that loads templates must resolve from the package directory:

```python
TEMPLATES_DIR = Path(__file__).parent.parent / "templates"
```

The `pyproject.toml` must include `templates/*.json` in package data so they ship
with `pip install tktl-cli`.

#### Why `openapi/` moves into the package

The five OpenAPI JSON files are reference data for the `tktl` package — they are the
source of truth for API client generation (§3) and are used by agents to understand
available endpoints. They belong inside `src/tktl/openapi/` rather than at the repo
root. The `openapi-client-config.yaml` and the `generate-client` script path in
`pyproject.toml` must be updated to reference the new location.

#### Why `flows/` is removed

The top-level `flows/` directory contained a single generated onboarding document
(output of the `onboard-flow` skill). Generated output should not occupy a top-level
directory alongside source code and specs. Generated flow docs should go to a
gitignored output directory or be kept as examples under `skills/examples/` if they
serve as reference material.

### 14.3 Package Structure (`src/tktl/`)

```
src/tktl/
├── __init__.py
│
├── templates/                         # Node config reference JSON (from top-level templates/)
│   ├── assignment_node.json           # assignment_node meta template
│   ├── rule_2.json                    # rule_2 meta template
│   ├── scorecard.json                 # scorecard meta template
│   ├── decision_table.json            # decision_table meta template
│   ├── matrix_table.json              # matrix_table meta template
│   └── transform.json                 # transform meta template
│
├── openapi/                           # API specifications (from top-level openapi/)
│   ├── flow-api-openapi.json          # Flow API — source of truth for client generation
│   ├── taktile-api-openapi.json       # Taktile API (auth, login)
│   ├── workspace-connect-openapi.json # Data connection/integration API
│   ├── workspace-datasets-openapi.json
│   └── workspace-dataset-jobs-openapi.json
│
├── generated/                         # AUTO-GENERATED — do not edit by hand
│   ├── __init__.py
│   ├── client.py                      # Generated httpx client
│   ├── models/                        # Pydantic models from OpenAPI schemas
│   │   ├── flow_version_v2.py
│   │   ├── flow_version_update.py
│   │   ├── graph_merge_patch.py
│   │   ├── node_db.py
│   │   ├── resource_lock.py
│   │   └── ...                        # All 100+ models
│   └── api/                           # Typed endpoint functions
│       ├── flows.py
│       ├── flow_versions.py
│       └── ...
│
├── ops/                               # Operations layer — the public API
│   ├── __init__.py                    # re-exports for convenience
│   ├── flows.py                       # list_flows, describe_flow, run_flow
│   ├── versions.py                    # list_versions, describe_version, create/publish/archive/duplicate/replace
│   ├── nodes.py                       # list_nodes, get_node, update_node
│   ├── templates.py                   # Pre-built flow graph templates (build_linear, build_gated, etc.)
│   ├── batch.py                       # parse_batch_file, run_batch, history, extract_query
│   └── cache_ops.py                   # refresh_cache, clear_cache, cache_status
│
├── cli/                               # Thin Typer CLI — parses args, calls ops, formats output
│   ├── __init__.py
│   ├── main.py                        # Root CLI group, global flags
│   ├── auth.py                        # auth login/logout/status
│   ├── config_cmd.py                  # config set/get/list
│   ├── flows.py                       # flows list, describe, run, batch, history
│   ├── versions.py                    # version list, describe, publish, archive, create, duplicate
│   ├── nodes.py                       # node list, describe
│   ├── update.py                      # update command (targeted + bulk)
│   ├── run.py                         # flow execution
│   ├── cache_cmd.py                   # cache refresh/clear/status
│   └── output.py                      # Output formatting (table/json), TTY detection
│
├── api/                               # Hand-written wrappers over generated client
│   ├── __init__.py
│   ├── client.py                      # Auth injection, base URL from config, session headers
│   ├── flows.py                       # Flow-specific call orchestration
│   ├── versions.py                    # Version-specific call orchestration
│   └── execution.py                   # Flow run via taktile_api
│
├── cache/                             # Hierarchical cache manager
│   ├── __init__.py
│   ├── manager.py                     # Read/write/invalidate cache files
│   ├── index.py                       # index.json management (slug → ID resolution)
│   └── freshness.py                   # TTL logic, staleness detection
│
├── models/                            # Hand-written models for CLI-specific views
│   ├── __init__.py
│   ├── flow.py                        # FlowSummary, FlowDetail (projections of generated models)
│   ├── version.py                     # VersionSummary, VersionDetail
│   ├── node.py                        # NodeSummary, NodeDetail
│   ├── batch.py                       # BatchRowResult, BatchRunMeta, BatchRunSummary, BatchResult
│   └── errors.py                      # TktlError hierarchy
│
├── resolver.py                        # Slug → ID, Name → ID resolution (cache-first)
├── merge.py                           # Deep-merge logic for node meta patches
└── config.py                          # Config + credential file read/write
```

### 14.4 Test Structure

```
tests/
├── conftest.py                        # Shared fixtures (fake server, temp cache dir)
├── fake_api/                          # Fake Flow API server for integration tests
│   ├── __init__.py
│   ├── app.py                         # ASGI app implementing Flow API subset
│   ├── state.py                       # In-memory state (flows, versions, locks, etags)
│   ├── routes.py                      # Route handlers (GET/PATCH/PUT/POST/DELETE)
│   ├── seed.py                        # Seed data builders (SeedFlow, SeedVersion, SeedNode)
│   └── merge_patch.py                 # RFC 7396 JSON Merge Patch implementation
├── test_ops/                          # Full integration tests through ops layer
├── test_cli/                          # CLI arg parsing + output formatting
├── test_api/                          # HTTP request construction
├── test_cache/                        # Cache read/write/invalidation
├── test_concurrency/                  # ETag conflicts and lock behaviour
└── test_merge.py                      # Deep-merge logic for node meta patches
```

---

## 15. Tech Stack & Dependencies

The project builds exclusively on the **Astral ecosystem** for all tooling. No mypy, no black, no isort, no pip — just `uv`, `ruff`, and `ty`.

### 15.1 Toolchain

| Tool | Role | Notes |
|:---|:---|:---|
| **[uv](https://docs.astral.sh/uv/)** | Package manager, virtualenv, build, publish, script runner | Replaces pip, pip-tools, venv, hatch, poetry. Single `uv.lock` for reproducible installs. |
| **[ruff](https://docs.astral.sh/ruff/)** | Linter + formatter | Replaces flake8, isort, black, pylint. One tool, one config section in `pyproject.toml`. |
| **[ty](https://docs.astral.sh/ty/)** | Type checker | Replaces mypy/pyright. Astral-native, fast, strict by default. |

### 15.2 Runtime Dependencies

| Component | Choice | Rationale |
|:---|:---|:---|
| **Language** | Python 3.11+ | Broad ecosystem, easy distribution. |
| **CLI framework** | [Typer](https://typer.tiangolo.com/) | Declarative, type-hint driven, built on Click. |
| **HTTP client** | [httpx](https://www.python-httpx.org/) | Sync + async, modern API, built-in retry support. |
| **Data models** | [Pydantic v2](https://docs.pydantic.dev/) | Validation, serialization, schema generation. |
| **Output formatting** | [Rich](https://rich.readthedocs.io/) | Tables, syntax highlighting, progress bars. |
| **Client generation** | [openapi-python-client](https://github.com/openapi-generators/openapi-python-client) | Dev dependency. Generates typed client from OpenAPI spec. |
| **Testing** | pytest + pytest-httpx | Mock HTTP layer for integration tests. |

### 15.3 pyproject.toml (abridged)

```toml
[project]
name = "tktl-cli"
version = "0.1.0"
requires-python = ">=3.11"
dependencies = [
    "typer>=0.12",
    "httpx>=0.27",
    "pydantic>=2.0",
    "rich>=13.0",
]

[project.scripts]
tktl = "tktl.cli.main:app"

[dependency-groups]
dev = [
    "pytest>=8.0",
    "pytest-httpx>=0.30",
    "starlette>=0.40",
    "openapi-python-client>=0.21",
    "ruff>=0.11",
]

[tool.uv.scripts]
generate-client = "openapi-python-client generate --path src/tktl/openapi/flow-api-openapi.json --output-path src/tktl/generated --config openapi-client-config.yaml"

[tool.ruff]
target-version = "py311"
line-length = 120

[tool.ruff.lint]
select = ["ALL"]
ignore = ["D1", "ANN1", "COM812", "ISC001"]  # adjust as needed

[tool.ruff.format]
quote-style = "double"
```

### 15.4 Common Commands

```bash
uv sync                    # Install all dependencies (creates uv.lock)
uv run tktl --help         # Run the CLI
uv run pytest              # Run tests
uv run ruff check .        # Lint
uv run ruff format .       # Format
uv run ty check            # Type check
uv run generate-client     # Regenerate API client from OpenAPI spec
```

### 15.5 CI Pipeline

The project uses a GitHub Actions workflow (`.github/workflows/ci.yml`) that runs on every push and PR:

```yaml
name: CI
on: [push, pull_request]

jobs:
  check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v4
      - run: uv sync
      - run: uv run ruff check .
      - run: uv run ruff format --check .
      - run: uv run pytest -x -v
```

Three gates, in order:
1. **Lint** — `ruff check .` catches code quality issues.
2. **Format** — `ruff format --check .` ensures consistent style.
3. **Test** — `pytest -x -v` runs the full suite (fail-fast on first error).

All three must pass for a PR to merge.

---

## Appendix A: API Endpoints Used

### Flow API endpoints (`flow_api_url`)

| CLI Operation | HTTP Method | Endpoint | Notes |
|:---|:---|:---|:---|
| List flows | `GET` | `/api/v1/flows?workspace_id={ws}` | Skip/limit pagination, no total count |
| Describe flow | `GET` | `/api/v1/flows/workspace_id/{ws}/slug/{slug}?shallow=true` | Returns `FlowDbDataplane` |
| Get flow by ID | `GET` | `/api/v1/flows/{id}` | Returns `FlowDbShallowSansLinkedFlows` |
| Get version (v2) | `GET` | `/api/v2/flow_versions/{id}` | `if-none-match` for cache. Returns `FlowVersionV2` (dict-keyed graph) |
| Update version | `PATCH` | `/api/v1/flow_versions/{id}` | JSON Merge Patch. `if-match` + `session` headers. Body: `FlowVersionUpdate` |
| Replace version | `PUT` | `/api/v2/flow_versions/{id}?by_etag={etag}` | Full replace |
| Create version | `POST` | `/api/v1/flow_versions` | Body: `FlowVersionCreate` |
| Duplicate version | `POST` | `/api/v1/flow_versions/{id}/duplicate` | Body: `FlowVersionDuplicate` |
| Delete version | `DELETE` | `/api/v1/flow_versions/{id}` | Returns 204 |
| Get version changes | `GET` | `/api/v2/flow_versions/{id}/changes` | Paginated. Returns `ChangeLogDb[]` |
| Get version revision | `GET` | `/api/v2/flow_versions/{id}/revision/{etag}` | Historical snapshot |
| Get workspace | `GET` | `/api/v1/workspaces/{workspace_id}` | Returns workspace with `base_url` for Decide API |
| Node types | `GET` | `/api/v1/types/flow_versions/{fv}/nodes/{node}` | Type inference for a node |

### Taktile API endpoints (`taktile_api_url`)

| CLI Operation | HTTP Method | Endpoint | Notes |
|:---|:---|:---|:---|
| Validate API key | `POST` | `/api/v1/login/access-token` | Key sent as bearer token. Returns `TokenWithUserAndKey` on 200. Used by `auth login`. |

### Workspace Decide API (per-workspace, dynamically resolved)

The Decide API base URL is resolved at runtime:
1. `GET /api/v1/workspaces/{workspace_id}` on the **Flow API** → returns workspace with `base_url` field.
2. The `base_url` (e.g., `https://risk.5738c673.decide.taktile.com`) hosts the Decide API.

| CLI Operation | HTTP Method | Endpoint | Notes |
|:---|:---|:---|:---|
| Run flow | `POST` | `{base_url}/run/api/v1/flows/{slug}/{env}/decide` | `env` is `sandbox` or `live`. Body: `{data, metadata: {version}, control}`. Auth: `X-Api-Key` header. |
| Get flow versions | `GET` | `{base_url}/run/api/v1/flows/{slug}/versions` | Lists available versions with URLs. |

## Appendix B: Key Data Models

### FlowVersionV2 (v2 response — used for reads)

```
id, name, status (DRAFT|PUBLISHED|ARCHIVED), etag,
created_at, updated_at, meta, api_version,
parameters: Parameter[], input_schema, output_schema,
graph: GraphV2 { nodes: {id: NodeDb}, edges: {id: EdgeDb}, node_groups: {id: NodeGroupDb} },
locks: ResourceLock[], review, operation
```

### FlowVersionUpdate (PATCH body — used for writes)

```
name?, status?, etag?, meta?,
parameters?, input_schema?, output_schema?,
graph?: GraphMergePatch { nodes: {id: NodeUpsert}, edges: {id: EdgeUpsert}, node_groups: {id: NodeGroupUpsert} },
locks?: {id: ResourceLockUpsert},
deleted_nodes_names?, deleted_nodegroups_names?, operation?
```

### NodeDb (node in responses)

```
id (uuid), name (string), type (NodeTypes enum — 25 types), meta (polymorphic — type-specific)
```

### ResourceLock / ResourceLockUpsert

```
owner (uuid), session (string), resource_type (flow|flow_version|parameter|node|schema),
resource_id (uuid), duration_secs (int), timestamp? (datetime), id? (uuid)
```

### Pagination

All list endpoints use **skip/limit** offset pagination. Responses are plain arrays with no envelope — the client infers "has more" by checking `len(results) == limit`.
