# PostHog Instrumentation Spec

> Track CLI/library usage, output token cost per operation, errors, latency, and cache efficiency.

---

## 1. Goal

Instrument the `tktl` operations layer so that every operation emits a PostHog event with:
- **What** was called (operation name)
- **How many tokens** the operation's output costs (the data returned to the caller — what an agent would consume)
- **How fast** it was (end-to-end latency)
- **Whether it worked** (success/failure, error type)
- **Cache behaviour** (hit/miss)

The primary metric is **output tokens** — when an AI agent calls `get_node()` or `list_nodes()`, how many tokens does the returned data cost in its context window? This is what determines cost, not the HTTP wire traffic happening behind the scenes.

Since instrumentation is at the **ops level**, it tracks usage regardless of whether the operation was invoked via the CLI, a Python import, or an MCP tool.

---

## 2. PostHog Setup

### 2.1 Dependency

```toml
# pyproject.toml
dependencies = [
    ...
    "posthog>=7.0",
]
```

### 2.2 Configuration

Add to `~/.tktl/config.json`:

```jsonc
{
  "telemetry": true,              // opt-out via `tktl config set telemetry false`
  "posthog_api_key": "phc_...",   // set via `tktl config set posthog_api_key <key>`
  "posthog_host": null             // null = default (https://us.i.posthog.com)
}
```

The CLI ships with a **default PostHog project key** baked in. Users can override or disable.

### 2.3 Opt-Out

```bash
tktl config set telemetry false   # disables all PostHog events
```

When `telemetry` is `false`, the PostHog client is never initialized. No events, no network calls.

### 2.4 Distinct ID

`user_id` from credentials (set during `tktl auth login`). Fallback: `anon-<sha256(hostname+username)[:16]>`.

---

## 3. Token Measurement

### What we measure

Every ops function returns data to the caller — a Pydantic model, a list, or a dict. That returned data is what an agent puts into its context window. We measure the **serialized size of the return value** and convert to an estimated token count.

```python
import json

def _estimate_tokens(data: Any) -> int:
    """Estimate token count from the operation's return value.

    Uses JSON serialization length / 4 as a rough approximation.
    Pydantic models are serialized via .model_dump().
    """
    if data is None:
        return 0
    if isinstance(data, BaseModel):
        serialized = json.dumps(data.model_dump())
    elif isinstance(data, list):
        serialized = json.dumps([
            item.model_dump() if isinstance(item, BaseModel) else item
            for item in data
        ])
    elif isinstance(data, dict):
        serialized = json.dumps(data)
    else:
        serialized = str(data)
    return len(serialized) // 4
```

### What we DON'T measure

- HTTP request/response bytes (internal implementation detail)
- Number of HTTP calls (not relevant to the consumer)
- Wire-level payload sizes

The consumer doesn't care how many HTTP calls it took internally — they care about the size of the data they receive.

---

## 4. Events

### 4.1 `operation` (primary event)

Emitted once per ops-layer function call.

| Property | Type | Example |
|:---|:---|:---|
| `op` | string | `"list_flows"`, `"update_node"`, `"run_flow"` |
| `success` | bool | `true` |
| `error_type` | string\|null | `null`, `"NotFoundError"`, `"ConflictError"` |
| `output_tokens` | int | `312` (estimated tokens in the returned data) |
| `duration_ms` | int | `1234` |
| `flow_slug` | string\|null | `"credit-scoring"` |
| `version_name` | string\|null | `"v1"` |
| `cache_hit` | bool\|null | `true`, `false`, `null` (not applicable) |
| `etag_retries` | int | `0`, `1`, `2` |
| `source` | string | `"cli"`, `"library"` |

**`output_tokens`** is the number that matters. It tells you: "this operation put ~312 tokens into the agent's context." Sum these across a session to get total token cost.

On error, `output_tokens` is `0` (no data returned).

### 4.2 `flow_execution` (enriched for decide calls)

Same as `operation` but with extra fields for flow execution.

| Property | Type | Example |
|:---|:---|:---|
| (all `operation` fields) | | |
| `input_tokens` | int | `64` (estimated tokens in the input data sent to the flow) |
| `env` | string | `"sandbox"`, `"live"` |
| `decision_id` | string\|null | `"abc-123"` |

For `run_flow`, we track **both** `input_tokens` (the `data` payload sent to the Decide API) and `output_tokens` (the `DecideResponse` returned), since the agent authors both.

### 4.3 `auth_login`

Emitted on `tktl auth login`. Sets PostHog person properties.

| Property | Type | Example |
|:---|:---|:---|
| `email` | string | `"user@example.com"` |
| `org_id` | string\|null | `"org-123"` |
| `workspace_id` | string\|null | `"ws-456"` |
| `cli_version` | string | `"0.1.0"` |
| `os` | string | `"Darwin"` |

---

## 5. Instrumentation Points

### 5.1 Ops functions — measure output tokens + track

Each ops function measures the serialized size of its return value:

```python
# src/tktl/ops/nodes.py

from tktl.telemetry import track, estimate_tokens

def get_node(client, cache_index, cache_manager, workspace_id,
             flow_slug, version_name, node_id, section=None):
    start = time.monotonic()
    cache_hit = None

    # ... existing logic ...
    node_data = cache_manager.read_node(version_id, flow_id, node_id)
    cache_hit = node_data is not None
    # ... fetch if not cached ...

    node = NodeDetail.model_validate(clean)

    track("operation", {
        "op": "get_node",
        "success": True,
        "output_tokens": estimate_tokens(node),
        "duration_ms": int((time.monotonic() - start) * 1000),
        "flow_slug": flow_slug,
        "version_name": version_name,
        "cache_hit": cache_hit,
    })
    return node
```

Error case:

```python
    except TktlError as exc:
        track("operation", {
            "op": "get_node",
            "success": False,
            "error_type": type(exc).__name__,
            "output_tokens": 0,
            "duration_ms": int((time.monotonic() - start) * 1000),
            "flow_slug": flow_slug,
            "version_name": version_name,
        })
        raise
```

### 5.2 `run_flow` — measure both input and output tokens

```python
def run_flow(client, workspace_id, flow_slug, input_data, *, version=None, env="sandbox"):
    start = time.monotonic()
    input_tokens = estimate_tokens(input_data)

    # ... resolve workspace, POST to decide API ...

    result = resp.json()
    track("flow_execution", {
        "op": "run_flow",
        "success": True,
        "input_tokens": input_tokens,
        "output_tokens": estimate_tokens(result),
        "duration_ms": int((time.monotonic() - start) * 1000),
        "flow_slug": flow_slug,
        "env": env,
        "decision_id": result.get("metadata", {}).get("decision_id"),
    })
    return result
```

### 5.3 Helper decorator (optional)

```python
# src/tktl/telemetry.py

def tracked(op_name: str):
    """Decorator that measures output tokens and emits an operation event."""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            start = time.monotonic()
            try:
                result = func(*args, **kwargs)
                track("operation", {
                    "op": op_name,
                    "success": True,
                    "output_tokens": estimate_tokens(result),
                    "duration_ms": int((time.monotonic() - start) * 1000),
                })
                return result
            except Exception as exc:
                track("operation", {
                    "op": op_name,
                    "success": False,
                    "error_type": type(exc).__name__,
                    "output_tokens": 0,
                    "duration_ms": int((time.monotonic() - start) * 1000),
                })
                raise
        return wrapper
    return decorator

# Usage:
@tracked("list_flows")
def list_flows(client, cache_manager, workspace_id):
    ...
```

Ops functions that need extra properties (flow_slug, cache_hit, etag_retries) call `track()` directly.

---

## 6. What Gets Tracked Per Operation

| Operation | Returns | Typical output_tokens | Key extra properties |
|:---|:---|:---|:---|
| `list_flows` | `list[FlowSummary]` | ~50 per flow | — |
| `describe_flow` | `FlowDetail` | ~100 | `flow_slug` |
| `list_versions` | `list[VersionSummary]` | ~30 per version | `flow_slug` |
| `describe_version` | `VersionDetail` | ~200 | `flow_slug`, `version_name`, `cache_hit` |
| `list_nodes` | `list[NodeSummary]` | ~20 per node | `flow_slug`, `version_name`, `cache_hit` |
| `get_node` | `NodeDetail` | 50–5000 (depends on meta) | `flow_slug`, `version_name`, `cache_hit` |
| `update_node` | `NodeDetail` | 50–5000 | `flow_slug`, `version_name`, `etag_retries` |
| `update_version` | `VersionDetail` | ~200 | `flow_slug`, `version_name`, `etag_retries` |
| `run_flow` | `dict` (DecideResponse) | 100–10000 | `flow_slug`, `env`, `decision_id`, `input_tokens` |
| `list_changes` | `list[dict]` | varies | `flow_slug`, `version_name` |
| `create_version` | `VersionDetail` | ~200 | `flow_slug`, `version_name` |
| `duplicate_version` | `VersionDetail` | ~200 | `flow_slug`, `version_name` |
| `publish_version` | `VersionDetail` | ~200 | `flow_slug`, `version_name` |
| `archive_version` | `VersionDetail` | ~200 | `flow_slug`, `version_name` |
| `refresh_cache` | `None` | 0 | — |
| `clear_cache` | `None` | 0 | — |
| `cache_status` | `dict` | ~10 | — |

---

## 7. PostHog Person Properties

Set once on `auth login` (via `posthog.identify`):

| Property | Source |
|:---|:---|
| `email` | Login response `user.email` |
| `org_id` | Config `org` |
| `workspace_id` | Config `workspace` |
| `cli_version` | `tktl.__version__` |
| `python_version` | `platform.python_version()` |
| `os` | `platform.system()` |

---

## 8. Dashboard

| Panel | Query |
|:---|:---|
| **Total Output Tokens (per day)** | `SUM(operation.output_tokens)` by day |
| **Output Tokens per Operation** | `AVG(output_tokens)` by `op` |
| **Most Token-Expensive Operations** | `SUM(output_tokens)` by `op`, descending |
| **Operation Frequency** | `COUNT(operation)` by `op` |
| **Cache Hit Rate** | `COUNT(WHERE cache_hit=true) / COUNT(WHERE cache_hit IS NOT NULL)` |
| **Token Savings from Cache** | `SUM(output_tokens WHERE cache_hit=true)` — tokens served without API call |
| **Error Rate** | `COUNT(WHERE success=false) / COUNT(*)` by `op` |
| **Avg Latency** | `AVG(duration_ms)` by `op` |
| **Agent vs CLI Usage** | `COUNT(*)` by `source` |
| **Flow Execution Tokens** | `SUM(input_tokens)` vs `SUM(output_tokens)` for `run_flow` |

---

## 9. Privacy & Performance

- **No PII in events:** No flow content, node source code, input data, or API keys. Only operation names, token counts, status codes, slugs.
- **Ops-level tracking works for agents too:** `from tktl.ops import update_node` emits the same event — no CLI required.
- **Async sends:** PostHog SDK sends in a background thread. No blocking.
- **Lazy import:** `import posthog` on first `track()`, not at import time.
- **Graceful degradation:** If PostHog is unreachable, events are silently dropped.
- **Opt-out:** `telemetry.disable()` or `tktl config set telemetry false`.

---

## 10. Project Structure

```
src/tktl/
├── telemetry.py          # NEW: PostHog init, track(), estimate_tokens(), tracked() decorator
├── ops/
│   ├── flows.py          # MODIFY: add track() calls with output_tokens
│   ├── versions.py       # MODIFY: add track() calls with output_tokens
│   ├── nodes.py          # MODIFY: add track() calls with output_tokens
│   └── cache_ops.py      # MODIFY: add track() calls with output_tokens
├── api/
│   └── execution.py      # MODIFY: add track() for flow_execution with input_tokens + output_tokens
└── config.py             # MODIFY: add telemetry defaults
```

Note: `api/client.py` is **not** modified. HTTP-level tracking is not needed — we only care about what comes out of the ops layer.

---

## 11. Testing

- **Unit tests:** Mock `tktl.telemetry.track` and verify:
  - Correct `op` name
  - `output_tokens` is proportional to the returned data size
  - `cache_hit` reflects actual cache state
  - `success`/`error_type` reflect outcome
- **Token estimation tests:** Verify `estimate_tokens()` produces consistent results for Pydantic models, lists, dicts.
- **Opt-out test:** Set `telemetry: false`, verify `track()` is a no-op.
- **No PostHog in tests:** Lazy import means tests never load PostHog unless telemetry is explicitly initialized.

---

## 12. Example: Agent Session in PostHog

An agent that navigates a flow, reads a node, updates it, and verifies:

```
Event: operation  op=list_flows       output_tokens=150   duration_ms=234   source=library
Event: operation  op=describe_flow    output_tokens=98    duration_ms=189   source=library  flow_slug=credit-scoring
Event: operation  op=list_nodes       output_tokens=80    duration_ms=2     source=library  cache_hit=true
Event: operation  op=get_node         output_tokens=312   duration_ms=1     source=library  cache_hit=true
Event: operation  op=update_node      output_tokens=318   duration_ms=1823  source=library  etag_retries=0
Event: operation  op=get_node         output_tokens=318   duration_ms=345   source=library  cache_hit=false
                                      ─────────────────
                             Total:   output_tokens=1276
```

This session cost ~1276 tokens of context. The cache saved 2 API calls (list_nodes + first get_node were cache hits).
