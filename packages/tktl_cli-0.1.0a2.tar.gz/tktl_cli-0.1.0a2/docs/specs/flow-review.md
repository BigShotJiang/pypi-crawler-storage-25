# Flow Review Skill

When asked to review a Taktile flow, follow this process.

## Setup

1. **Install**: `pip install -e .`
2. **Configure API URLs**:
   ```bash
   tktl config set flow_api_url <flow_api_url>
   tktl config set taktile_api_url <taktile_api_url>
   ```
3. **Set workspace and org**:
   ```bash
   tktl config set workspace <workspace_id>
   tktl config set org <organisation_id>
   ```

## Important

- **Use the installed `tktl` CLI directly** — run `tktl`, not `uv run tktl`. The CLI is already installed on the system.
- **Do not read the codebase to learn CLI behavior.** Use `tktl --help` and `tktl <command> --help` to discover available commands and flags.

## Process

1. **Parse the URL** — extract org, workspace, flow, and version IDs. Confirm the workspace is configured with `tktl config list`.
2. **Get metadata** — run `tktl flows describe`, `tktl versions describe`, and `tktl nodes list` to get parameters, schemas, and the full node inventory.
3. **Describe every node** — run `tktl nodes describe` for each node. This is the only way to get the graph edges (connections) and the logic inside each node. For large flows (20+ nodes), delegate to a subagent for efficiency.
4. **Reconstruct the graph topology** — from the node descriptions, map out the full path from input to output, identifying split/merge patterns and nesting depth.
5. **Trace the logic** — for each path through the graph, check:
   - Are knockout/aggregation rules wired correctly? (Every status field that's set should be checked downstream.)
   - Are computed fields actually used? (Look for fields set in one node but never referenced later.)
   - Do parameterized thresholds make sense relative to the data ranges?
   - For scorecards/decision tables, trace the math with representative values to verify the output ranges can actually reach all tiers.
6. **Ask before running test decisions** — do NOT execute test decisions unless the user explicitly asks or you ask and get consent. Test decisions hit the live sandbox and the user may not want that. If running tests would improve the review (e.g. to verify an accept path is reachable), say so and ask permission.

## What to Look For

- **Unwired knockouts** — a status field is set but not checked in the aggregation rule.
- **Unreachable branches** — mock data or threshold math that makes an entire path impossible to reach.
- **Dead code** — rules that can never fire because an upstream rule already handles the case (e.g. age < 18 after age < 20 knockout).
- **Computed-but-unused fields** — a node computes a value that no downstream node references.
- **DTI/ratio checks** — verify the denominator source and whether the threshold is reachable given upstream value ranges.
- **Mock integrations** — check if mock values are realistic enough to test all paths. Trace scorecard/decision table math with the actual mock values.
