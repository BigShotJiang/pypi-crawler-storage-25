# Plan: Repository Restructure

**Spec:** `docs/specs/core-implementation.md` §14 (Repository Structure)
**Ticket:** [CLI-1](https://linear.app/taktile/issue/CLI-1)

## Tasks

- [x] Create `skills/` with agentskills.io directory structure (one dir per skill, each with `SKILL.md`)
- [x] Migrate `SKILL.md` → `skills/flow-builder/SKILL.md`
- [x] Migrate `.claude/commands/create-flow.md` → `skills/create-flow/SKILL.md`
- [x] Migrate `.claude/commands/onboard-flow.md` → `skills/onboard-flow/SKILL.md`
- [x] Migrate `FLOW_REVIEW_AGENT.md` → `skills/flow-review/SKILL.md`
- [x] Migrate `flow-summary-CLAUDE.md` → `skills/flow-summary/SKILL.md`
- [x] Move `IMPROVE.md` and `issues.md` into `skills/flow-review/references/`
- [x] Add YAML frontmatter (name, description, compatibility) to each `SKILL.md`
- [x] Move and rename `templates/` → `src/tktl/templates/` (`assignment.json` → `assignment_node.json`, `rule.json` → `rule_2.json`)
- [x] Move `openapi/` → `src/tktl/openapi/`
- [x] Update template path resolution in source code (N/A — JSON templates are loaded by agents via `--config @file`, not by source code)
- [x] Update `generate-client` script path in `pyproject.toml`
- [x] Add `templates/*.json` and `openapi/*.json` to package data in `pyproject.toml`
- [x] Remove `.claude/commands/` entirely — skills/ is canonical
- [x] Remove `flows/` directory
- [x] Move `docs/` reference files → `skills/flow-builder/references/` (node-configs, flow-patterns, debugging, etc.)
- [x] Move `plans/` → `docs/plans/` and `specs/` → `docs/specs/`
- [x] Update cross-references in `CLAUDE.md`, `AGENTS.md`, `README.md`, skill files, plans, and spec §14
- [x] Run tests to verify nothing breaks

## Blocked

- [ ] Decide: should OpenAPI specs ship with `pip install tktl-cli` (~800KB) or stay dev-only?
- [ ] Decide: should generated flow docs have a standard gitignored output dir?
