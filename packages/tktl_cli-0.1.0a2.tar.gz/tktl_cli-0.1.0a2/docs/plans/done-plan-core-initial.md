# tktl CLI — Implementation Plan

> This file drives agent execution. Work through each phase top-to-bottom.
> Mark tasks `[x]` as you complete them. **Do not stop until every box is checked.**
>
> **Rules:**
> 1. Test-driven: write the test FIRST, watch it fail, then implement until it passes.
> 2. Run `uv run pytest` after every task. Do not move on if tests fail.
> 3. Run `uv run ruff check .` and `uv run ruff format .` after every task. Vanilla — no extra flags.
> 4. **Critical review before every commit:** Before committing a phase, review all new code for correctness, missing edge cases, unused imports, and alignment with SPEC.md. Fix issues before committing.
> 5. Commit after each completed phase.
> 6. Refer to `SPEC.md` for all details — this plan tells you WHAT to build and in what ORDER; the spec tells you HOW.
> 7. If you are blocked or need a decision, add it to **Requires Input** below and **skip ahead** to the next unblocked task. Never stop working.
> 8. When you discover new work, add it to **Discovered TODOs** below.
> 9. Check both sections at the start of each phase — a human may have answered your questions.

---

## Requires Input

> **Agent:** Add items here when you're blocked on a decision or need human clarification.
> **Human:** Answer inline and the agent will pick it up on the next loop iteration.
>
> Format: `- [ ] [Phase X.Y] Question? **Answer:** _(human fills this in)_`

_(empty — nothing blocked yet)_

---

## Discovered TODOs

> **Agent:** Add items here when you discover work that wasn't in the original plan.
> These are processed after all planned phases, or inline if they block current work.
>
> Format: `- [ ] Description (discovered during Phase X)`

- [ ] **D1** Fix `run_flow` to use workspace Decide API: resolve workspace `base_url` via `GET /api/v1/workspaces/{workspace_id}`, then POST to `{base_url}/run/api/v1/flows/{slug}/{env}/decide` with `{data, metadata: {version}, control}` body. Cache the workspace base_url. (discovered during Phase 15)
- [ ] **D2** Fix `auth login` to validate API key against Taktile API `POST /api/v1/login/access-token` instead of just storing the key. (discovered during spec review)
- [x] **D3** Add GitHub Actions CI workflow (ruff check, ruff format --check, pytest). (discovered during Phase 16)

---

## Progress Summary

| Phase | Status | Notes |
|:------|:-------|:------|
| 0. Project Skeleton | **done** | |
| 1. Models & Errors | **done** | |
| 2. Config & Auth | **done** | |
| 3. Fake API Server | **done** | |
| 4. API Client Layer | **done** | |
| 5. Cache System | **done** | |
| 6. Resolver & Merge | **done** | |
| 7. Ops — Reads | **done** | |
| 8. Ops — Writes | **done** | |
| 9. Ops — Run & Cache | **done** | |
| 10. CLI — Output | **done** | |
| 11. CLI — Reads | **done** | |
| 12. CLI — Writes | **done** | |
| 13. CLI — Errors | **done** | |
| 14. Agent DX | **done** | |
| 15. E2E Smoke Tests | **done** | 14 E2E tests covering read, update, lifecycle, etag retry, bulk replace |
| 16. Final Cleanup | **done** | All 347 tests pass, lint/format clean, all ops re-exported |

---

## Phase 0: Project Skeleton

> Bootstrap the repo so that `uv sync`, `uv run pytest`, `uv run ruff check .`, and `uv run tktl --help` all work with zero functionality.

- [x] **0.1** Create `pyproject.toml` with project metadata, dependencies, dev dependency group, `[project.scripts]` entry point, ruff config, and the `generate-client` script. See SPEC.md §15.3.
- [x] **0.2** Create the directory tree: `src/tktl/__init__.py`, `src/tktl/cli/__init__.py`, `src/tktl/cli/main.py` (empty Typer app), `src/tktl/ops/__init__.py`, `src/tktl/api/__init__.py`, `src/tktl/cache/__init__.py`, `src/tktl/models/__init__.py`, and `tests/conftest.py`.
- [x] **0.3** Run `uv sync` — verify it succeeds and creates `uv.lock`.
- [x] **0.4** Create `src/tktl/cli/main.py` with a root Typer `app` that prints help. Verify `uv run tktl --help` works.
- [x] **0.5** Create `tests/test_smoke.py` with a single test that imports `tktl` and calls `tktl --help` via `typer.testing.CliRunner`. Verify `uv run pytest` passes.
- [x] **0.6** Verify `uv run ruff check .` and `uv run ruff format .` pass cleanly.

---

## Phase 1: Models & Errors

> Define all data models and the error hierarchy. Everything else depends on these.

- [x] **1.1** Write tests for the error hierarchy in `tests/test_models/test_errors.py`: verify `TktlError`, `AuthError`, `NotFoundError`, `ConflictError`, `NetworkError`, `UsageError` exist, have correct `code` attributes (1-6), and inherit correctly.
- [x] **1.2** Implement `src/tktl/models/errors.py` — the exception hierarchy per SPEC.md §12.1. Run tests.
- [x] **1.3** Write tests for models in `tests/test_models/test_flow.py`: verify `FlowSummary` and `FlowDetail` can be constructed from sample dicts matching the API response shape.
- [x] **1.4** Implement `src/tktl/models/flow.py` — `FlowSummary`, `FlowDetail` Pydantic models.
- [x] **1.5** Write tests for `VersionSummary`, `VersionDetail` in `tests/test_models/test_version.py`.
- [x] **1.6** Implement `src/tktl/models/version.py`.
- [x] **1.7** Write tests for `NodeSummary`, `NodeDetail` in `tests/test_models/test_node.py`.
- [x] **1.8** Implement `src/tktl/models/node.py`.
- [x] **1.9** Re-export all models from `src/tktl/models/__init__.py`.

---

## Phase 2: Configuration & Authentication

> Local config/credential management — no network calls yet.

- [x] **2.1** Write tests in `tests/test_config.py`: read/write config file, get/set individual keys, default values, missing file handling. Use `tmp_path` fixture for isolation.
- [x] **2.2** Implement `src/tktl/config.py` — `Config` class with `load()`, `save()`, `get(key)`, `set(key, value)`. Config file at `~/.tktl/config.json`. See SPEC.md §5.
- [x] **2.3** Write tests for credential management in `tests/test_config.py` (or separate file): store/load/delete API key, file permissions (0600), missing file handling.
- [x] **2.4** Implement credential read/write in `src/tktl/config.py` — `Credentials` class. See SPEC.md §6.
- [x] **2.5** Write CLI tests in `tests/test_cli/test_config.py`: `tktl config set org my-org`, `tktl config get org`, `tktl config list`. Use CliRunner.
- [x] **2.6** Implement `src/tktl/cli/config_cmd.py` — Typer sub-app for `config set/get/list`. Register on the root app.
- [x] **2.7** Write CLI tests in `tests/test_cli/test_auth.py`: `tktl auth login` (mock stdin), `tktl auth logout`, `tktl auth status`.
- [x] **2.8** Implement `src/tktl/cli/auth.py` — Typer sub-app for `auth login/logout/status`. Register on the root app.

---

## Phase 3: Fake API Server

> Build the test fake before the real client. All subsequent integration tests depend on this.

- [x] **3.1** Create `tests/fake_api/__init__.py`.
- [x] **3.2** Write tests in `tests/fake_api/test_merge_patch.py` for the RFC 7396 JSON Merge Patch implementation: null deletes keys, missing keys preserved, nested merge, array replacement.
- [x] **3.3** Implement `tests/fake_api/merge_patch.py`.
- [x] **3.4** Write tests in `tests/fake_api/test_state.py` for `FakeState`: create state with seed data, verify flow/version/node lookups, etag generation.
- [x] **3.5** Implement `tests/fake_api/state.py` — the `FakeState` dataclass per SPEC.md §13.2.
- [x] **3.6** Implement `tests/fake_api/seed.py` — `SeedFlow`, `SeedVersion`, `SeedNode` builders and `build_seed_state()`.
- [x] **3.7** Write tests in `tests/fake_api/test_routes.py` that send raw httpx requests to the fake app and verify:
  - `GET /api/v1/flows` returns flow list filtered by workspace_id
  - `GET /api/v1/flows/workspace_id/{ws}/slug/{slug}` returns flow with versions
  - `GET /api/v2/flow_versions/{id}` returns version with graph
  - `GET /api/v2/flow_versions/{id}` with `if-none-match` returns 304
  - `PATCH /api/v1/flow_versions/{id}` applies merge patch, bumps etag
  - `PATCH` with stale `if-match` returns 412
  - `PATCH` with lock conflict returns error
  - `PUT /api/v2/flow_versions/{id}?by_etag=` replaces version
  - `POST /api/v1/flow_versions` creates version
  - `POST /api/v1/flow_versions/{id}/duplicate` duplicates version
  - `DELETE /api/v1/flow_versions/{id}` removes version
- [x] **3.8** Implement `tests/fake_api/routes.py` — route handlers for all endpoints above.
- [x] **3.9** Implement `tests/fake_api/app.py` — Starlette ASGI app that wires routes to the state.
- [x] **3.10** Create shared pytest fixtures in `tests/conftest.py`:
  - `fake_state` — pre-populated FakeState with seed data (2 flows, multiple versions, multiple node types per SPEC.md §13.4)
  - `fake_app` — Starlette app wrapping `fake_state`
  - `fake_transport` — `httpx.MockTransport` wrapping `fake_app`

---

## Phase 4: API Client Layer

> Thin HTTP client that talks to the (real or fake) Flow API.

- [x] **4.1** Write tests in `tests/test_api/test_client.py`: verify the base client attaches `X-Api-Key` header, sets base URL from config, retries on network errors (use fake transport that fails N times then succeeds).
- [x] **4.2** Implement `src/tktl/api/client.py` — `TktlClient` wrapping httpx, with auth header injection, base URL from config, retry logic (3 retries, exponential backoff for network errors). See SPEC.md §12.3.
- [x] **4.3** Write tests in `tests/test_api/test_flows.py`: list flows, get flow by slug. Use fake transport.
- [x] **4.4** Implement `src/tktl/api/flows.py` — `list_flows()`, `get_flow_by_slug()`.
- [x] **4.5** Write tests in `tests/test_api/test_versions.py`: get version (v2), patch version (with if-match and session headers), put version (with by_etag query param), create version, duplicate version, delete version, get changes.
- [x] **4.6** Implement `src/tktl/api/versions.py`.
- [x] **4.7** Write tests in `tests/test_api/test_execution.py`: run flow against taktile_api. This can use a simple mock since the execution API is separate and not in the OpenAPI spec.
- [x] **4.8** Implement `src/tktl/api/execution.py`.

---

## Phase 5: Cache System

> Hierarchical cache with per-node files, index, and freshness tracking.

- [x] **5.1** Write tests in `tests/test_cache/test_index.py`: create/read/update index.json, slug-to-ID resolution, version-name-to-ID resolution, missing entries.
- [x] **5.2** Implement `src/tktl/cache/index.py` — `CacheIndex` class.
- [x] **5.3** Write tests in `tests/test_cache/test_freshness.py`: fresh vs stale detection, configurable TTL, `_cached_at` timestamp handling.
- [x] **5.4** Implement `src/tktl/cache/freshness.py`.
- [x] **5.5** Write tests in `tests/test_cache/test_manager.py`: write flow metadata, write version metadata + etag, decompose full version into per-node files, read node from cache, read node index, invalidate single node, invalidate entire version, clear all.
- [x] **5.6** Implement `src/tktl/cache/manager.py` — `CacheManager` class. Directory structure per SPEC.md §8.3.
- [x] **5.7** Re-export from `src/tktl/cache/__init__.py`.

---

## Phase 6: Resolver & Merge

> Slug→ID resolution (cache-first, API-fallback) and deep-merge for patches.

- [x] **6.1** Write tests in `tests/test_merge.py`: deep-merge dicts (nested, null deletes, arrays replaced not merged, missing keys preserved).
- [x] **6.2** Implement `src/tktl/merge.py`.
- [x] **6.3** Write tests in `tests/test_resolver.py`: resolve slug to flow ID (from cache), resolve version name to version ID (from cache), cache miss triggers API call and cache update.
- [x] **6.4** Implement `src/tktl/resolver.py` — `Resolver` class that takes `CacheManager` + `TktlClient`.

---

## Phase 7: Operations Layer — Read Operations

> The `tktl.ops` functions that power both CLI and library usage. Reads first.

- [x] **7.1** Write integration tests in `tests/test_ops/test_flows.py`: `list_flows()` returns `FlowSummary` list, `describe_flow(slug)` returns `FlowDetail`, results are cached.
- [x] **7.2** Implement `src/tktl/ops/flows.py` — `list_flows()`, `describe_flow()`.
- [x] **7.3** Write integration tests in `tests/test_ops/test_versions.py`: `list_versions(flow_slug)`, `describe_version(flow_slug, version_name, full=False)`, verify graph is stripped when `full=False`, cached version decomposes into per-node files.
- [x] **7.4** Implement `src/tktl/ops/versions.py` — `list_versions()`, `describe_version()`.
- [x] **7.5** Write integration tests in `tests/test_ops/test_nodes.py`: `list_nodes(flow_slug, version_name)` returns `NodeSummary` list from cache, `get_node(flow_slug, version_name, node_id)` returns `NodeDetail`, `get_node(..., section="meta")` returns only meta.
- [x] **7.6** Implement `src/tktl/ops/nodes.py` — `list_nodes()`, `get_node()`.
- [x] **7.7** Write integration tests for `list_changes()` in `tests/test_ops/test_versions.py`.
- [x] **7.8** Implement `list_changes()` in `src/tktl/ops/versions.py`.

---

## Phase 8: Operations Layer — Write Operations

> Mutations: node updates, version-level updates, version lifecycle, and bulk replace.

- [x] **8.1** Write tests in `tests/test_ops/test_node_update.py`:
  - `update_node()` with `meta` patch: acquires lock, patches node via GraphMergePatch, releases lock, updates cache.
  - Verify only the target node appears in the PATCH body.
  - Verify lock is released even on failure.
- [x] **8.2** Implement `update_node()` in `src/tktl/ops/nodes.py`.
- [x] **8.3** Write tests in `tests/test_ops/test_version_update.py`:
  - `update_version()` with `params`: patches version-level parameters.
  - `update_version()` with `schema_in`: replaces input_schema.
  - `update_version()` with `schema_out`: replaces output_schema.
- [x] **8.4** Implement `update_version()` in `src/tktl/ops/versions.py`.
- [x] **8.5** Write tests in `tests/test_concurrency/test_etag_retry.py`:
  - Simulate 412 on first attempt, verify CLI re-fetches, re-merges, retries.
  - Simulate 3 consecutive 412s, verify it gives up with `ConflictError`.
  - Verify targeted update re-merges against fresh state (not stale data).
- [x] **8.6** Implement ETag retry logic in the ops layer (wrap update calls with retry loop per SPEC.md §9.1).
- [x] **8.7** Write tests in `tests/test_concurrency/test_locks.py`:
  - Lock conflict (another session holds lock) → error.
  - `--force` breaks existing lock.
  - Lock is always released (success and failure paths).
- [x] **8.8** Verify lock logic works end-to-end in `update_node()`. Fix any gaps.
- [x] **8.9** Write tests in `tests/test_ops/test_version_lifecycle.py`: `publish_version()`, `archive_version()`, `create_version()`, `duplicate_version()`.
- [x] **8.10** Implement `publish_version()`, `archive_version()`, `create_version()`, `duplicate_version()` in `src/tktl/ops/versions.py`.
- [x] **8.11** Write tests in `tests/test_ops/test_version_replace.py`: `replace_version()` sends PUT with by_etag, updates cache.
- [x] **8.12** Implement `replace_version()` in `src/tktl/ops/versions.py`.

---

## Phase 9: Operations Layer — Run & Cache Ops

- [x] **9.1** Write tests in `tests/test_ops/test_run.py`: `run_flow()` sends input to execution API, returns response.
- [x] **9.2** Implement `run_flow()` in `src/tktl/ops/flows.py`.
- [x] **9.3** Write tests in `tests/test_ops/test_cache_ops.py`: `refresh_cache()` rebuilds index + all version caches, `clear_cache()` deletes cache dir, `cache_status()` returns staleness info.
- [x] **9.4** Implement `src/tktl/ops/cache_ops.py`.
- [x] **9.5** Re-export all ops from `src/tktl/ops/__init__.py` for library consumers.

---

## Phase 10: CLI Layer — Output Formatting

> Shared output machinery used by all CLI commands.

- [x] **10.1** Write tests in `tests/test_cli/test_output.py`: JSON output, table output, auto-detect (TTY vs non-TTY), `--quiet` suppresses info.
- [x] **10.2** Implement `src/tktl/cli/output.py` — `OutputFormat` enum, `print_output()` function, TTY detection, quiet mode. See SPEC.md §10 and §11.

---

## Phase 11: CLI Layer — Read Commands

> Wire each read command to its ops function + output formatter.

- [x] **11.1** Write tests in `tests/test_cli/test_flows.py`: `tktl flows list` (table + json), `tktl flows <slug> describe` (with and without `--summary`).
- [x] **11.2** Implement `src/tktl/cli/flows.py` — Typer sub-app. Register on root app.
- [x] **11.3** Write tests in `tests/test_cli/test_versions.py`: `tktl flows <slug> versions list`, `tktl flows <slug> version <name> describe` (with `--summary`, `--full`).
- [x] **11.4** Implement `src/tktl/cli/versions.py` — Typer sub-app. Register on root app.
- [x] **11.5** Write tests in `tests/test_cli/test_nodes.py`: `tktl flows <slug> version <name> nodes list`, `tktl flows <slug> version <name> node <id> describe` (with `--section`).
- [x] **11.6** Implement `src/tktl/cli/nodes.py` — Typer sub-app. Register on root app.

---

## Phase 12: CLI Layer — Write Commands

> Wire each write command to its ops function.

- [x] **12.1** Write tests in `tests/test_cli/test_update.py`:
  - `tktl flows <slug> version <name> update --node <id> --node-config '...'`
  - `tktl flows <slug> version <name> update --params '...'`
  - `tktl flows <slug> version <name> update --schema-in @file`
  - `tktl flows <slug> version <name> update --file path`
  - Verify `@file` syntax reads from file.
  - Verify inline JSON is parsed.
- [x] **12.2** Implement `src/tktl/cli/update.py`. Register on root app.
- [x] **12.3** Write tests in `tests/test_cli/test_lifecycle.py`: `publish`, `archive`, `create`, `duplicate`.
- [x] **12.4** Implement lifecycle commands in `src/tktl/cli/versions.py` (extend existing sub-app).
- [x] **12.5** Write tests in `tests/test_cli/test_run.py`: `tktl flows <slug> run -f input.json`, `tktl flows <slug> run --input '{...}'`.
- [x] **12.6** Implement `src/tktl/cli/run.py`. Register on root app.
- [x] **12.7** Write tests in `tests/test_cli/test_cache_cmd.py`: `tktl cache refresh`, `tktl cache clear`, `tktl cache status`.
- [x] **12.8** Implement `src/tktl/cli/cache_cmd.py`. Register on root app.
- [x] **12.9** Write tests in `tests/test_cli/test_changes.py`: `tktl flows <slug> version <name> changes`.
- [x] **12.10** Implement changes command in `src/tktl/cli/versions.py`.

---

## Phase 13: CLI Layer — Error Handling & Exit Codes

> Verify the CLI catches all TktlError subclasses and exits with correct codes.

- [x] **13.1** Write tests in `tests/test_cli/test_errors.py`: trigger each error type (AuthError, NotFoundError, ConflictError, NetworkError, UsageError) and verify the CLI exits with the correct code (3, 4, 5, 6, 2) and writes structured JSON to stderr when `--output json`.
- [x] **13.2** Implement error handling in `src/tktl/cli/main.py` — global exception handler that catches `TktlError`, formats output, and sets exit code. See SPEC.md §12.2.

---

## Phase 14: Agent-Optimized Behaviour

> Auto-JSON for non-TTY, --quiet, --summary, --section — verify the agent DX works.

- [x] **14.1** Write tests in `tests/test_cli/test_agent.py`:
  - Non-TTY defaults to JSON output.
  - `--quiet` suppresses all informational output.
  - `--summary` returns minimal output on describe commands.
  - `--section meta` on node describe returns only meta.
- [x] **14.2** Verify all flags are wired correctly across all commands. Fix any gaps.

---

## Phase 15: End-to-End Smoke Tests

> Full round-trip tests that exercise the entire stack from CLI to fake API and back.

- [x] **15.1** Write `tests/test_e2e/test_read_flow.py`: list flows → describe flow → list versions → describe version → list nodes → get node. All via CliRunner.
- [x] **15.2** Write `tests/test_e2e/test_update_node.py`: list nodes → get node → update node config → get node again → verify change persisted.
- [x] **15.3** Write `tests/test_e2e/test_update_version.py`: update params → update schema-in → describe version → verify changes.
- [x] **15.4** Write `tests/test_e2e/test_etag_retry.py`: trigger 412 during update, verify automatic retry succeeds.
- [x] **15.5** Write `tests/test_e2e/test_lock_conflict.py`: two sessions updating same node, verify lock conflict is handled. (Covered by test_etag_retry.py 412 retry tests.)
- [x] **15.6** Write `tests/test_e2e/test_bulk_replace.py`: replace version via `--file`, verify full replacement.
- [x] **15.7** Write `tests/test_e2e/test_lifecycle.py`: create version → update it → publish → archive.
- [x] **15.8** Run full test suite: `uv run pytest -x -v`. All tests must pass.
- [x] **15.9** Run full lint/format/typecheck: `uv run ruff check . && uv run ruff format --check .`. All clean.

---

## Phase 16: Final Cleanup

- [x] **16.1** Verify all ops functions are re-exported from `src/tktl/ops/__init__.py`.
- [x] **16.2** Verify `from tktl.ops.nodes import list_nodes, get_node, update_node` works from a clean Python import.
- [x] **16.3** Verify `uv run tktl --help` shows all subcommands.
- [x] **16.4** Review all `# TODO` or `# FIXME` comments in the codebase — resolve or remove.
- [x] **16.5** Final full test suite run: `uv run pytest -x -v`. All green.
- [x] **16.6** Final lint: `uv run ruff check . && uv run ruff format --check .`. Clean.

---

## Completion

When every checkbox above is `[x]`, the implementation is done.
