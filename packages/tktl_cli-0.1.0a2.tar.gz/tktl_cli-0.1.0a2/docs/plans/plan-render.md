# Plan: Flow Mermaid Preview

Spec: `docs/specs/render.md`

## Phases

### Phase 1 — Core ops (TDD)

- [ ] Add `RenderError` to `src/tktl/models/errors.py`
- [ ] Add `read_full_version` to `CacheManager`
- [ ] Write `tests/test_ops/test_render.py` (failing)
  - `graph_to_mermaid`: empty graph, simple linear graph, split graph, unknown node type
  - `extract_mermaid_blocks`: no blocks, one block, multiple blocks, fenced with extra whitespace
  - `render_mermaid_png`: mock `urllib.request.urlopen` — success saves file; HTTP error raises `RenderError`; timeout raises `RenderError`
- [ ] Implement `src/tktl/ops/render.py`
  - `graph_to_mermaid(graph: dict) -> str`
  - `extract_mermaid_blocks(md_text: str) -> list[str]`
  - `render_mermaid_png(code: str, out_dir: Path) -> Path`
  - `preview_version_graph(client, cache_index, cache_manager, workspace_id, slug, version_name) -> Path`
- [ ] All tests green, ruff + ty clean

### Phase 2 — `tktl render` command (TDD)

- [ ] Write `tests/test_e2e/test_render.py` (failing)
  - No input → exit non-zero with usage error
  - `--text "flowchart TD\n  A --> B"` → renders, prints file:// path (mock render_mermaid_png)
  - File path → extracts blocks, renders each, prints paths
  - `-` (stdin) → reads markdown, extracts blocks, renders
  - No mermaid blocks found → exit 0, prints warning
  - Render error → prints warning, exits 0 (continues remaining blocks)
- [ ] Implement `src/tktl/cli/render_cmd.py`
  - `--text / -t` optional str
  - optional file argument (Path | None), `-` for stdin
  - mutual exclusion: `--text` + file → usage error
- [ ] Register in `main.py`: `app.command("render")(render)`
- [ ] All tests green, ruff + ty clean

### Phase 3 — `versions describe --preview` integration (TDD)

- [ ] Write / update test for `versions describe --preview` (mock preview_version_graph)
  - `--preview` flag → calls preview_version_graph, prints file:// path
  - `--preview` + render fails → prints warning, still shows version metadata
  - no `--preview` → no render call
- [ ] Add `--preview / -p` flag to `versions_describe` in `src/tktl/cli/versions.py`
- [ ] All tests green, ruff + ty clean

## Requires Input

_None._

## Discovered TODOs

_None yet._
