# PostHog Instrumentation — Implementation Plan

> Implements `docs/specs/posthog-instrumentation.md`. Adds output token tracking to every ops function.
>
> **Rules:**
> 1. Test-driven: write the test FIRST, watch it fail, then implement until it passes.
> 2. Run `uv run pytest`, `uv run ruff check .`, `uv run ruff format .`, `uv run ty check src/ tests/` after every task.
> 3. **Critical review before every commit.**
> 4. Commit after each completed phase.
> 5. If blocked, add to **Requires Input** and skip ahead.

---

## Requires Input

_(empty)_

---

## Discovered TODOs

_(empty)_

---

## Progress Summary

| Phase | Status | Notes |
|:------|:-------|:------|
| 0. Telemetry module | done | |
| 1. Config defaults | done | |
| 2. Instrument ops — reads | done | |
| 3. Instrument ops — writes | done | |
| 4. Instrument ops — run + cache | done | |
| 5. Source detection (cli vs library) | done | |
| 6. Auth login event | done | |
| 7. Opt-out and privacy | done | |
| 8. End-to-end verification | done | 450 tests pass, 0 failures |

---

## Phase 0: Telemetry Module

> Build `src/tktl/telemetry.py` — the single entry point for all instrumentation.

- [x]**0.1** Write tests in `tests/test_telemetry.py`:
  - `estimate_tokens()` returns correct counts for: Pydantic model, list of models, dict, None, empty list, string.
  - `estimate_tokens()` on a `NodeDetail` with meta produces a reasonable number (> 10).
  - `track()` is a no-op when telemetry is not initialized.
  - `track()` calls `posthog.capture` when initialized.
  - `tracked()` decorator emits an event with `op`, `success`, `output_tokens`, `duration_ms`.
  - `tracked()` decorator emits error event with `error_type` on exception.
- [x]**0.2** Implement `src/tktl/telemetry.py`:
  - `estimate_tokens(data: Any) -> int` — serialize to JSON, return `len // 4`.
  - `track(event: str, properties: dict) -> None` — lazy-init PostHog, call `posthog.capture`.
  - `tracked(op_name: str)` — decorator for ops functions.
  - `_init(config_dir)` — lazy PostHog initialization.
  - `disable()` — force-disable telemetry.
- [x]**0.3** Add `posthog>=3.0` to `pyproject.toml` dependencies. Run `uv sync`.

---

## Phase 1: Config Defaults

> Add telemetry config keys.

- [x]**1.1** Write tests in `tests/test_config.py`:
  - Default `telemetry` is `True`.
  - `telemetry` can be set to `False`.
  - `posthog_api_key` defaults to `None`.
  - `posthog_host` defaults to `None`.
- [x]**1.2** Add `telemetry`, `posthog_api_key`, `posthog_host` to `_DEFAULTS` in `src/tktl/config.py`.

---

## Phase 2: Instrument Ops — Reads

> Add `track()` calls to all read operations. These are the simplest — no retries, no cache writes.

- [x]**2.1** Write tests in `tests/test_ops/test_telemetry.py`:
  - Mock `tktl.telemetry.track`.
  - Call `list_flows()` → verify `track("operation", {"op": "list_flows", "success": True, "output_tokens": <int>, ...})` was called.
  - Call `describe_flow()` → verify event has `flow_slug`.
  - Call `list_nodes()` with cache hit → verify `cache_hit=True`.
  - Call `get_node()` with cache miss → verify `cache_hit=False`.
  - Call `get_node()` with non-existent node → verify `success=False`, `error_type="NotFoundError"`, `output_tokens=0`.
- [x]**2.2** Instrument `src/tktl/ops/flows.py`:
  - `list_flows()` — add `track()` with `output_tokens`.
  - `describe_flow()` — add `track()` with `output_tokens`, `flow_slug`.
- [x]**2.3** Instrument `src/tktl/ops/versions.py` (reads only):
  - `list_versions()` — add `track()` with `output_tokens`, `flow_slug`.
  - `describe_version()` — add `track()` with `output_tokens`, `flow_slug`, `version_name`, `cache_hit`.
  - `list_changes()` — add `track()` with `output_tokens`, `flow_slug`, `version_name`.
- [x]**2.4** Instrument `src/tktl/ops/nodes.py` (reads only):
  - `list_nodes()` — add `track()` with `output_tokens`, `flow_slug`, `version_name`, `cache_hit`.
  - `get_node()` — add `track()` with `output_tokens`, `flow_slug`, `version_name`, `cache_hit`.

---

## Phase 3: Instrument Ops — Writes

> Add `track()` calls to all write operations. These have retry loops and etag tracking.

- [x]**3.1** Write tests in `tests/test_ops/test_telemetry.py` (extend):
  - Call `update_node()` → verify event has `etag_retries=0`.
  - Call `update_version()` → verify event has `output_tokens`, `etag_retries`.
  - Call `publish_version()` → verify event with `op="publish_version"`.
  - Call `create_version()` → verify event with `op="create_version"`.
  - Call `duplicate_version()` → verify event with `op="duplicate_version"`.
  - Call `replace_version()` → verify event with `etag_retries`.
  - Call `archive_version()` → verify event.
- [x]**3.2** Instrument `src/tktl/ops/nodes.py` (writes):
  - `update_node()` — add `track()` with `output_tokens`, `flow_slug`, `version_name`, `etag_retries`. Both success and error paths.
- [x]**3.3** Instrument `src/tktl/ops/versions.py` (writes):
  - `update_version()` — add `track()` with `etag_retries`.
  - `publish_version()` — add `track()`.
  - `archive_version()` — add `track()`.
  - `create_version()` — add `track()`.
  - `duplicate_version()` — add `track()`.
  - `replace_version()` — add `track()` with `etag_retries`.

---

## Phase 4: Instrument Ops — Run + Cache

> `run_flow` has both `input_tokens` and `output_tokens`. Cache ops are trivial.

- [x]**4.1** Write tests:
  - Call `run_flow()` → verify `flow_execution` event with `input_tokens`, `output_tokens`, `env`, `decision_id`.
  - Call `refresh_cache()` → verify `operation` event with `output_tokens=0`.
  - Call `clear_cache()` → verify `operation` event.
  - Call `cache_status()` → verify `operation` event.
- [x]**4.2** Instrument `src/tktl/ops/flows.py`:
  - `run_flow()` — emit `flow_execution` event with `input_tokens` (from input_data) + `output_tokens` (from result).
- [x]**4.3** Instrument `src/tktl/ops/cache_ops.py`:
  - `refresh_cache()` — emit `operation` event.
  - `clear_cache()` — emit `operation` event.
  - `cache_status()` — emit `operation` event with `output_tokens`.

---

## Phase 5: Source Detection

> Distinguish CLI invocations from library imports.

- [x]**5.1** Write tests:
  - Operation called via `@handle_errors` decorator → `source="cli"`.
  - Operation called directly → `source="library"`.
- [x]**5.2** Add `_source` thread-local to `src/tktl/telemetry.py`:
  - `set_source(source: str)` — called by CLI layer.
  - `get_source() -> str` — returns `"cli"` or `"library"` (default).
- [x]**5.3** Update `src/tktl/cli/_error_handler.py`:
  - Call `set_source("cli")` before invoking the wrapped function.
- [x]**5.4** Update all `track()` calls to include `"source": get_source()`.

---

## Phase 6: Auth Login Event

> Emit `auth_login` event and set PostHog person properties.

- [x]**6.1** Write tests:
  - On `auth login` success, verify `track("auth_login", {"email": ..., "org_id": ..., ...})` is called.
  - Verify `posthog.identify` is called with person properties.
- [x]**6.2** Update `src/tktl/cli/auth.py`:
  - After successful login, call `track("auth_login", ...)`.
  - Call `identify()` in telemetry module to set person properties.
- [x]**6.3** Add `identify(user_id, properties)` to `src/tktl/telemetry.py`.

---

## Phase 7: Opt-Out and Privacy

> Ensure telemetry can be disabled and no PII is leaked.

- [x]**7.1** Write tests:
  - With `telemetry: false` in config, `track()` never calls `posthog.capture`.
  - With `telemetry.disable()`, all subsequent `track()` calls are no-ops.
  - No event contains flow content, node source code, input data, or API keys.
  - Events only contain: op names, token counts, slugs, version names, status codes, duration.
- [x]**7.2** Verify `_init()` respects config `telemetry` setting.
- [x]**7.3** Implement `disable()` function in telemetry module.
- [x]**7.4** Audit all `track()` calls — ensure no PII or content is included.

---

## Phase 8: End-to-End Verification

> Verify the full pipeline works: ops call → track() → PostHog event.

- [x]**8.1** Write an E2E test that:
  - Mocks `posthog.capture` at the module level.
  - Runs a full agent workflow: `list_flows → describe_flow → list_nodes → get_node → update_node`.
  - Collects all captured events.
  - Verifies total `output_tokens` across the session is reasonable (> 0, < 100000).
  - Verifies each event has the expected `op` name.
  - Verifies `cache_hit` is `True` for the second read.
- [x]**8.2** Run full test suite: `uv run pytest -x -v`. All tests pass.
- [x]**8.3** Run full lint: `uv run ruff check . && uv run ruff format --check . && uv run ty check src/ tests/`. All clean.
- [x]**8.4** Update `docs/specs/posthog-instrumentation.md` if any design decisions changed during implementation.

---

## Completion

When every checkbox above is `[x]`, the implementation is done.
