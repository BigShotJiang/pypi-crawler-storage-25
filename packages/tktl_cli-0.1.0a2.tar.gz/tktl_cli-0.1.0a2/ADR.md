# ADR: tktl CLI Architecture Decisions

> **Legend:** 🔶 = work-in-progress or planned

---

## Context

- We want agents to author and test flows, as per Q2 2026 OKR
    - [We built a set of tools (CLI + skill) for agentic whole flow authoring that have at least 10 internal and 2 external weekly users. All functionality is built in such a way that they can be integrated into an on-platform copilot on the Agents infrastructure in Q3'26.](https://www.notion.so/We-built-a-set-of-tools-CLI-skill-for-agentic-whole-flow-authoring-that-have-at-least-10-interna-32f0a226e5be80f3a1c2d51a7f8d7fd5?pvs=21)
- Three consumer types need the same operations:
    - Humans in terminals
    - Automation scripts (automated updates, rollouts)
    - Agents: local (Claude Code/Codex) and on-platform (hosted agent runtime)
- We need to support large flow editing
    - Flow versions can contain thousands of nodes, producing 10,000+ line JSON on GET
    - The Flow API has no node-level endpoints. Nodes are embedded in the version graph
    - PATCH requires the full node set in the body (otherwise 409)
- Multiple users and agents may edit the same flow version concurrently

---

## Principles

**We optimize for**

- **Agent efficiency:** surgical operations + auto-JSON + cache decomposition keep context windows small
- **Zero code duplication:** one ops layer serves CLI, agents, scripts, and future interfaces
- **Simple concurrency:** ETag retries + node locks, invisible to the user, prevent data loss
- **Composability:** every command produces structured JSON for shell pipelines and automation
- **Low token cost:** `--summary`, `--section`, per-node cache files minimize data transferred to agents
- **Fast iteration:** APIs are stable, CLI and skill can change faster, especially during internal testing
- **Agents code:** we embrace agent coding, kept on point from specification files in repository

**We accept**

- **Client-side node extraction:** the CLI must fetch and decompose the full version graph. Cache mitigates this but first-fetch is expensive
- 🔶 **Internal Flow API exposure:** should be moved to public-facing workspace API before public release
- **Cache staleness risk:** 5-minute TTL can serve stale data. ETag validation on writes catches this but reads may be outdated
- 🔶 **Local tooling assumption:** the design leans on `jq`, `grep`, `diff` and filesystem access. Risk for on-platform runtime where bash is not exposed

---

## Decision

### 1. Repo code structure

#### 1.1 Library-first, CLI as interface

- All business logic in `tktl.ops` as importable Python functions
- CLI (`tktl.cli`) is a thin Typer wrapper: parse args → call ops → format output
- No business logic in the CLI layer, ever
- Three access modes from the same code: CLI, Python import, MCP tool

```
tktl.cli         → Typer (arg parsing + output formatting only)
tktl.ops         → business logic, caching, locking, ID resolution
tktl.api         → hand-written HTTP orchestration (auth, headers, retries)
tktl.generated   → auto-generated from OpenAPI (never edit)
```

#### 1.2 CLI as primary interface, not MCP

We expose 60+ commands across 13 resource groups, growing. At that scale, CLI beats MCP:

- **Zero schema bloat.** MCP injects every tool's schema upfront (thousands of tokens). CLI has zero upfront cost, agent calls `--help` on demand.
- **Shell composability.** `tktl nodes list credit-scoring v1 | jq '.[].name' | grep -i "risk"`. Each command composes with every Unix tool.
- **Debuggability.** Human can run the exact same command the agent ran. MCP calls are opaque.
- **Token efficiency.** >10x more efficient than equivalent MCP tool definitions.

**When MCP makes sense:** non-developer access (analysts in chat UIs) or multi-agent runtime discovery.

**Three-layer stack:**

| Layer | Role | Example |
|---|---|---|
| **Capability (CLI)** | `--help` flags, JSON output, semantic exit codes | `tktl nodes describe credit-scoring v1 <id>` |
| **Procedure (Skill)** | How to use the CLI effectively: workflows, gotchas | `skills/flow-builder/SKILL.md` |
| **Bridge (MCP)** | 🔶 Thin wrapper calling CLI under the hood | Planned: `tktl-mcp-server` |

#### 1.3 Agent skills over vendor-specific commands

- Skills in `skills/` using [agentskills.io](https://agentskills.io) format, not `.claude/commands/`
- Vendor-neutral, works across 35+ agent products
- Each skill: `SKILL.md` + `references/` subfolder loaded on demand

#### 1.4 CLI resource ordering and structure

Pattern: `tktl <resource> <action>`. Consistent verbs across all resources.

| Resource | Read actions | Write actions |
|---|---|---|
| `flows` | `list`, `describe`, `explain`, `history` | `create`, `update`, `run`, `batch`, `wizard` |
| `versions` | `list`, `describe`, `diff`, `changes` | `create`, `duplicate`, `publish`, `archive` |
| `nodes` | `list`, `describe` | `add`, `edit`, `remove` |
| `update` | -- | `apply` (node config, params, schemas, full replace) |
| `groups` | `list`, `describe` | `create`, `update`, `delete`, `add-nodes`, `remove-nodes` |
| `datasets` | `list`, `describe`, `rows`, `download` | `create`, `upload`, `add-rows`, `update-row`, `delete-row`, `add-column`, `rename-column`, `delete-column`, `fill-column`, `sync-schema`, `delete` |
| `connections` | `list` | `create`, `create-resource`, `update-secrets` |
| `comments` | `list` | `add`, `delete` |
| `folders` | `list` | `create` |
| `auth` | `status` | `login`, `logout` |
| `config` | `get`, `list` | `set` |
| `cache` | `status` | `refresh`, `clear` |
| `render` | -- | *(top-level command)* |

**Read/write split enables agent permission models.** Coding agents auto-allow reads (`list`, `describe`, `diff`, etc.) and require approval for writes (`create`, `update`, `delete`, `run`, etc.). The verb convention makes this trivial to configure. New resources follow the same verbs, so the permission model covers them automatically.

#### 1.5 Configuration, authentication, and workspace routing

**Config** (`~/.tktl/config.json`): `org`, `workspace`, `env` (sandbox/live), optional URL overrides. Multiple environments via `TKTL_CONFIG_DIR`.

**Auth**: API key in `~/.tktl/credentials.json` (mode `0600`), attached as `X-Api-Key` header.

**Three API surfaces** 🔶 (to be consolidated):

| API | Used by |
|---|---|
| **Flow API** (`flow-api.taktile.com`) | All flow management: versions, nodes, groups, datasets, locks |
| **Taktile API** (`api.taktile.com`) | `auth login`, workspace management |
| **Workspace base URL** (per-workspace) | Flow execution (`flows run`, `flows batch`). Resolved from workspace object, cached. |

🔶 Plan: consolidate Flow API onto workspace base URL before public release.

### 2. CLI design

#### 2.1 Everything is JSON, pipes to jq

- Structured JSON to stdout, auto-detected (JSON for non-TTY, Rich tables for TTY)
- Errors to stderr as structured JSON with semantic exit codes (0-6, 10)
- Pipe to `jq`, `grep`, or any Unix tool

#### 2.2 Surgical reads and writes

- Targets the **smallest possible object** (single node, single parameter)
- `--full` for full document, `--summary` for one-liners, `--section` for single fields
- Large flows: `nodes list` returns ~3 lines per node, `nodes describe` returns ~30 lines for one node. Full-graph PATCH assembled by ops layer, invisible to caller.

#### 2.3 Human-readable identifiers

The original assumption was that human-readable names make the CLI more usable for both humans and agents. This holds for some resources but breaks on others.

- Flows by **slug**, versions by **name**: works well, both are unique
- Nodes, groups, datasets, connections, folders: by **UUID** (no guaranteed unique name)

🔶 **URL-to-identifier mismatch.** Platform URLs use UUIDs but CLI expects slugs/names. Agent must look up the mapping first. Needs to be addressed: accept UUIDs as alternative input, or add `tktl resolve <uuid>`.

#### 2.4 Cache-first with per-node decomposition

- One version fetch → decomposed into per-node files at `~/.tktl/cache/`
- Subsequent reads are local file reads, not API calls
- ETag-based conditional GETs (304 saves bandwidth)
- Writes invalidate only affected files

```
~/.tktl/cache/
├── index.json                          # slug→ID, name→ID
├── flows/{flow_id}/versions/{ver_id}/
│   ├── metadata.json                   # version meta + etag (no graph)
│   ├── full.json                       # backup for --full reads
│   └── nodes/
│       ├── _index.json                 # lightweight node list
│       └── {node_id}.json             # individual node (~20-50 lines)
```

A 200-node flow: one API call, then all reads from cache.

#### 2.5 Optimistic concurrency via ETags

- PATCH/PUT sends `if-match: {etag}`. On 412: re-fetch → re-merge → resend (up to 3 retries)
- Node-level locks embedded in PATCH body. TTL-based expiry (300s). `--force` breaks locks.
- All invisible to the caller

#### 2.6 Batch execution with local results tracking

- `tktl flows batch`: 1-50 parallelism, max 1000 rows, CSV/JSON/JSONL or platform dataset
- Results as append-only JSONL in `~/.tktl/runs/{slug}/{run_id}/`
- `--query "output.data.decision"` for field extraction across rows

#### 2.7 Telemetry with PostHog

- Emitted from `tktl.ops`, tracked regardless of interface (CLI, library, MCP)
- Per-operation: `op`, `success`, `duration_ms`, `output_tokens`, `cache_hit`, `etag_retries`
- Opt-out via `tktl config set telemetry false`

### 3. Testing and tooling

#### 3.1 Toolchain

- **uv** (package manager), **ruff** (lint + format), **ty** (type checker), **hatchling** (build)
- Pre-commit hook: `ruff check` → `ruff format --check` → `ty check --error-on-warning`
- CI: lint → unit tests (fake API) → integration tests (real dev, main-only)

#### 3.2 Fake API server

Unit tests run against a Starlette ASGI app (`tests/fake_api/`) with in-memory state, wired via `httpx.ASGITransport`. No network calls, full HTTP semantics enforced:

| Rule | Behavior |
|---|---|
| ETag mismatch | 412 Precondition Failed |
| ETag match on GET | 304 Not Modified |
| Lock conflict | 409 Conflict |
| Merge patch | RFC 7396 (null deletes, nested recursion) |
| Missing resources | 404 |

Why fake server, not mocks: exercises the full stack (CLI → ops → api → HTTP → server), tests concurrency logic against real behavior, deterministic seed data.

#### 3.3 Integration tests against dev

Integration tests hit the real Taktile dev environment with real HTTP calls.

Why: the fake server can't catch API behavior changes, undocumented edge cases, or response format drift. Only way to verify the generated API client works against the real server.

What: flow listing, version PATCH with ETag negotiation, full build-and-run cycle (duplicate → add nodes → set schemas → execute → verify). Test versions cleaned up in fixture teardown.

Gating: requires `TKTL_DEV_API_KEY`, `@pytest.mark.integration`, CI runs only on push to `main`, uses a dedicated safe flow (`no-op-2`).

---

## Consequences

### Expected Cost Impact

- **API calls:** cache decomposition = 1 fetch per version, not per node. 200-node flow: 1 API call instead of 200.
- **Tokens:** `nodes list` on 200-node flow: ~600 lines vs 10,000+ for full graph. Single `nodes describe`: ~30 lines.
- **Bandwidth:** conditional GETs return 304 for unchanged versions.
- 🔶 **To measure:** actual token usage per session, cache hit rates, API calls per agent task.

### Positive Consequences

- **Large flows work.** Cache decomposition + surgical reads make a 1000-node flow as easy to navigate as a 5-node flow.
- **Local tooling works.** JSON output → `jq`, `grep`, `diff` all work. Cache is a file tree. 🔶 Needs alternative for on-platform agents.
- **One ops layer, many interfaces.** CLI, Python import, MCP, on-platform copilot. No duplication.
- **Concurrent editing is safe.** ETag retries + node locks, transparent to caller.
- **API client stays in sync.** Generated from OpenAPI spec. Spec change = regenerate + test.
- **Fast tests.** Fake server enforces real HTTP semantics without network. Suite runs in seconds.

### Negative Consequences

- **First fetch is expensive.** Cold start for 1000-node flow = 10,000+ line response. Subsequent reads are cheap.
- **Full-graph PATCH complexity.** API requires all nodes in body. Ops layer hides this but implementation is non-trivial.
- 🔶 **Two API surfaces.** Different base URLs for management vs execution. Will be unified.
- **Generated code in repo.** Spec updates produce large diffs. Reviewers learn to ignore `tktl.generated/`.
- **Cache staleness.** 5-minute TTL, acceptable when agent owns the version.
- 🔶 **Node ID ergonomics.** UUID-only addressing. Revisit if name uniqueness can be enforced.
- 🔶 **Local tooling dependency.** `jq`, `grep`, filesystem access assumed. Risk for on-platform runtime (Q3'26). Ops layer Python import mitigates partially.
