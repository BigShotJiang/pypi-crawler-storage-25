# Claude Code Instructions

Read and follow `AGENTS.md` for all implementation guidance.

## Reference Docs

| File | Purpose |
|:---|:---|
| `skills/flow-builder/references/node-configs.md` | Per-type node config examples and gotchas |
| `skills/flow-builder/references/flow-patterns.md` | Node sequence patterns by use case |
| `skills/flow-builder/references/debugging.md` | Debugging procedures for flow issues |
| `skills/flow-builder/references/executing-flows-and-local-testing.md` | Running flows, async mode, mocking, integration test patterns |
| `skills/flow-builder/references/working-with-child-flows-and-loop-nodes.md` | Child flows, subflow mocking via `mock_data`, cross-workspace promotion |

## Rendering Flows

When asked to render/visualize/diagram a flow, always:
1. Use the CLI: `uv run tktl versions describe <slug> <version> --preview`
2. Open the resulting PNG in Preview: `open <path>`

Do not generate raw Mermaid text in the conversation.
