# Agent Instructions

You are implementing the `tktl` CLI. Follow these files:

## Project Documentation

| File | Purpose |
|:---|:---|
| `docs/specs/core-implementation.md` | Full technical spec — source of truth for all behaviour, data models, API mappings, architecture. |
| `docs/specs/batch-run.md` | Batch run spec — multi-row execution, file formats, results storage, history, query extraction. |
| `docs/specs/posthog-instrumentation.md` | PostHog telemetry spec — event types, byte tracking, privacy. |
| `docs/plans/` | Implementation plans with checkbox task lists. Read before starting work. |
| `skills/` | Agent skills in [agentskills.io](https://agentskills.io) format. |
| `README.md` | Project overview and usage examples. |
| `src/tktl/openapi/flow-api-openapi.json` | OpenAPI spec for the Taktile Flow API. |
| `src/tktl/openapi/taktile-api-openapi.json` | OpenAPI spec for the Taktile API (auth, login). |
| `src/tktl/openapi/workspace-datasets-openapi.json` | OpenAPI spec for the Workspace Datasets API. |
| `src/tktl/openapi/workspace-dataset-jobs-openapi.json` | OpenAPI spec for the Workspace Dataset Jobs API. |
| `.env.example` | Environment variables for local integration testing. |

When working on a new feature, check `docs/specs/` for an existing spec first. If none exists, write one before implementing.

## Plans

Plans live in `docs/plans/` as simple markdown files with checkbox task lists. They track
implementation progress for a spec or ticket. A plan is the agent's working state —
read it first to build context, update it as you go.

**Format:**

```markdown
# Plan: <Title>

**Spec:** `docs/specs/<name>.md`
**Ticket:** [TICKET-ID](url)

## Tasks

- [x] Completed task
- [ ] Open task
- [ ] Another open task

## Blocked

- [ ] Decision needed: <question>
```

**Rules:**
- One plan per spec or ticket. Name it `plan-<topic>.md`.
- Use `- [ ]` for open, `- [x]` for done. Nothing else.
- Blocked items go under `## Blocked` — skip them and work on unblocked tasks.
- When you discover new work, add it to the task list.
- Prefix done plans with `done-` (e.g., `done-plan-core-initial.md`).

## Execution Loop

1. Find the relevant spec in `docs/specs/` and the plan in `docs/plans/` (if one exists).
2. If the task is blocked (needs human input), move it to **Blocked** in the plan, then skip to the next unblocked task.
3. If you discover new work, add it to the **Tasks** section in the plan.
4. Execute following TDD: write the test first, watch it fail, implement, watch it pass.
5. After each task: run `uv run pytest`, `uv run ruff check .`, `uv run ruff format .`. Fix any failures before moving on.
6. Run `uv run ty check src/ tests/` — all code must pass strict type checking.
7. Check off the task in the plan (`- [x]`).
8. Commit after each completed phase.
9. Go to step 1. **Do not stop until every task is checked off.**

## Key Constraints

- **Library-first**: all logic lives in `src/tktl/ops/`. CLI commands are thin wrappers.
- **Test-driven**: never write implementation before writing the failing test.
- **Astral-only tooling**: use `uv`, `ruff`, `ty`. No pip, no mypy, no black.
- **Fake API for unit tests**: unit tests run against the fake server in `tests/fake_api/`.
- **Real API for integration tests**: integration tests in `tests/test_integration/` hit the real Taktile dev environment. They require `TKTL_DEV_API_KEY` in `.env`.
- **No hallucinated endpoints**: the Flow API has no node-level endpoints. Nodes are extracted client-side from the version graph. Check `docs/specs/core-implementation.md` Appendix A for the exact endpoints.
- **Session header required**: PATCH requests that modify rule_2, split_2, or assignment_node metas require a `session` header.
- **Full nodes in PATCH**: the API requires ALL nodes in the graph patch body, not just the modified one. Sending only the target node causes 409 "graph not fully connected".
- **Pre-commit hook**: runs ruff check + ruff format + ty check. Install via `uv run python scripts/install-hooks.py`.

## Agent Behaviour (always active)

1. **Clarify before implementing — but use Chrome first for context only.**
   - **Always use the CLI to retrieve flow, version, and node data.** When you need to describe, inspect, or reason about flow logic, schemas, node configuration, or graph structure, use `tktl versions describe`, `tktl nodes list`, `tktl nodes describe`, etc. Never scrape the browser UI to read flow logic — the CLI returns the complete, structured data.
   - Chrome is for **context resolution only**: parse the URL to extract org_id, workspace_id, flow_id, version_id, and node_id. Then pass those identifiers to the CLI. **Do NOT run `tktl config list` or other CLI config commands to find out what's active when Chrome is open.**
   - If Chrome tools are absent: use `tktl config list` to resolve workspace/org, and list open factual AND logic questions before writing any API calls.
   - Only ask the user about things neither the CLI nor Chrome can tell you: undecided business logic, thresholds not yet defined, ambiguous requirements.
   - Never guess at connection names, node IDs, or field values.

2. **Render before building.** Always run `tktl render --text "..."` with a complete Mermaid diagram and get user approval before any `tktl versions duplicate` or `tktl nodes add` calls.

3. **Schema first.** Every flow must have explicit input and output schemas. Define them before (or immediately after) creating the version — before adding any logic nodes. For every field the flow reads from `data.*`, declare it in `--schema-in`. For every field the flow writes to `data.*` that the caller will consume, declare it in `--schema-out`. Without schemas: `data: {}` is returned and batch runs can't be queried by field. Apply with:
   ```bash
   tktl update apply <slug> <ver> --schema-in @input_schema.json --schema-out @output_schema.json
   ```
   Include schema design in the Mermaid brainstorm step — label the I/O nodes with the actual field names.

4. **Chrome tools — read and show only. NEVER edit via Chrome.**
   All flow edits go through the CLI. Chrome MCP tools have exactly two permitted uses:
   - **Inspect** — read the current state to orient yourself (e.g. what workspace/flow/node is open, what a node's config looks like). Use this to answer your own questions before asking the user.
   - **Navigate to show the user** — open a URL so the user can see something (a flow, a node pane, a Mermaid PNG preview). Only navigate; do not interact further.

   When Chrome tools are present:
   - After rendering a Mermaid PNG → use `Bash: open {png_path}` (macOS) to open the PNG in Preview. Do NOT use Chrome navigate for `file://` paths — Chrome MCP prepends `https://` and mangles them.
   - After creating or duplicating a version → navigate Chrome to the Taktile flow URL.
   - When asked to show a node → navigate to `?node={node_id}&right-pane-tab=logic`. If the node_id is unknown, use `tktl nodes list <slug> <version>` to look it up — never use JavaScript or click the canvas.
   - Build Taktile URLs via `from tktl.config import Config, derive_app_url` + `from tktl.ops.render import build_flow_url`. The `org_id` is auto-fetched and cached by `build_deps()`.
   - URL pattern: `/flow/{flow_id}/version/{version_id}` — always singular `flow`, always include version. Never `/flows/`, never omit the version.
