import os
from typing import Optional, List, Union, Tuple, Callable

import click
from loguru import logger
import pandas as pd
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"

from syngen.ml.worker import Worker
from syngen.ml.utils import (
    setup_log_process,
    get_reports,
    fetch_env_variables
)
from syngen.ml.validation_schema import ReportTypes


def validate_required_parameters(
    metadata_path: Optional[str] = None,
    source: Optional[str] = None,
    table_name: Optional[str] = None
):
    """
    Validate that required parameters are provided
    """
    if not metadata_path and not source and not table_name:
        raise AttributeError(
            "It seems that the information about 'metadata_path' or 'table_name' "
            "and 'source' is absent. Please provide either the information about "
            "'metadata_path' or the information about 'source' and 'table_name'."
        )
    elif not metadata_path and source and not table_name:
        raise AttributeError(
            "It seems that the information about 'metadata_path' or 'table_name' is absent. "
            "Please provide either the information about 'metadata_path' or "
            "the information about 'source' and 'table_name'."
        )
    elif not metadata_path and table_name and not source:
        raise AttributeError(
            "It seems that the information about 'metadata_path' or 'source' is absent. "
            "Please provide either the information about 'metadata_path' or "
            "the information about 'source' and 'table_name'."
        )
    elif metadata_path and table_name and source:
        logger.warning(
            "The information about 'metadata_path' was provided. "
            "In this case the information about 'table_name' and 'source' will be ignored."
        )
    elif metadata_path and source:
        logger.warning(
            "The information about 'metadata_path' was provided. "
            "In this case the information about 'source' will be ignored."
        )
    elif metadata_path and table_name:
        logger.warning(
            "The information about 'metadata_path' was provided. "
            "In this case the information about 'table_name' will be ignored."
        )


def launch_train(
    metadata_path: Optional[str] = None,
    source: Optional[str] = None,
    table_name: Optional[str] = None,
    epochs: int = 10,
    drop_null: bool = False,
    row_limit: Optional[int] = None,
    reports: Union[List[str], Tuple[str], str] = "none",
    log_level: str = "INFO",
    batch_size: int = 32,
    fernet_key: Optional[str] = None,
    loader: Optional[Callable[[str], pd.DataFrame]] = None,
):
    setup_log_process(
        type_of_process="train",
        log_level=log_level,
        table_name=table_name,
        metadata_path=metadata_path
    )

    encryption_settings = fetch_env_variables({"fernet_key": fernet_key})

    worker = Worker(
        table_name=table_name,
        metadata_path=metadata_path,
        settings={
            "source": source,
            "epochs": epochs,
            "drop_null": drop_null,
            "row_limit": row_limit,
            "batch_size": batch_size,
            "reports": get_reports(
                value=reports,
                report_types=ReportTypes(),
                type_of_process="train"
            ),
        },
        log_level=log_level,
        type_of_process="train",
        encryption_settings=encryption_settings,
        loader=loader
    )

    logger.info(
        "The training process will be executed according to the information mentioned "
        "in 'train_settings' in the metadata file. If appropriate information is absent "
        "from the metadata file, then the values of parameters sent through CLI will be used. "
        "Otherwise, the values of parameters will be defaulted."
    )

    worker.launch_train()


@click.command()
@click.option(
    "--metadata_path",
    type=str,
    default=None,
    help="The path to the metadata file."
)
@click.option(
    "--source",
    type=str,
    default=None,
    help="The path to the table that you want to use as a reference.",
)
@click.option(
    "--table_name",
    type=str,
    default=None,
    help="The arbitrary string to name the directories.",
)
@click.option(
    "--epochs",
    default=10,
    type=click.IntRange(1),
    help="The number of trained epochs. If absent, it's defaulted to 10.",
)
@click.option(
    "--drop_null",
    default=False,
    type=click.BOOL,
    help="The flag which set whether to drop rows with at least one missing value. "
    "If absent, it's defaulted to False.",
)
@click.option(
    "--row_limit",
    default=None,
    type=click.IntRange(1),
    help="The number of rows to train over. A number less than the original table "
         "length will randomly subset the specified rows number.",
)
@click.option(
    "--reports",
    default=("none",),
    type=click.UNPROCESSED,
    multiple=True,
    help="Controls the generation of quality reports. "
    "Might require significant time for big generated tables (>1000 rows). "
    "If set to 'sample', generates a sample report. "
    "If set to 'accuracy', generates an accuracy report. "
    "If set to 'metrics_only', outputs the metrics information only to standard output "
    "without generation of a report. "
    "If set to 'all', generates both accuracy and sample report. "
    "If it's absent or set to 'none', no reports are generated.",
)
@click.option(
    "--log_level",
    default="INFO",
    type=click.Choice(["TRACE", "DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]),
    help="Set the logging level which will be used in the process. "
         "If absent, it's defaulted to 'INFO'",
)
@click.option(
    "--batch_size",
    default=32,
    type=click.IntRange(1),
    help="The number of rows that goes in one batch. "
         "This parameter can help to control memory consumption.",
)
@click.option(
    "--fernet_key",
    default=None,
    type=str,
    help="The name of the environment variable that kept the value of the Fernet key "
         "to encrypt and decrypt the sensitive data stored on the disk.",
)
def cli_launch_train(
    metadata_path: Optional[str],
    source: Optional[str],
    table_name: Optional[str],
    epochs: int,
    drop_null: bool,
    row_limit: Optional[int],
    reports: List[str],
    log_level: str,
    batch_size: int,
    fernet_key: Optional[str]
):
    """
    Launch the work of training process

    Parameters
    ----------
    metadata_path
    source
    table_name
    epochs
    drop_null
    row_limit
    reports
    log_level
    batch_size
    fernet_key
    -------
    """
    validate_required_parameters(
        metadata_path=metadata_path,
        source=source,
        table_name=table_name
    )
    launch_train(
        metadata_path=metadata_path,
        source=source,
        table_name=table_name,
        epochs=epochs,
        drop_null=drop_null,
        row_limit=row_limit,
        reports=reports,
        log_level=log_level,
        batch_size=batch_size,
        fernet_key=fernet_key
    )


if __name__ == "__main__":
    cli_launch_train()
