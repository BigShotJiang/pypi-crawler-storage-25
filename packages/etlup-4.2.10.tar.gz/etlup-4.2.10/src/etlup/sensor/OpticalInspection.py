from pydantic import ConfigDict, Field, AliasChoices
from typing_extensions import Literal, Union, Annotated
from .. import base_model, jinja_env


class OpticalInspectionV0(base_model.ConstructionBase):
    model_config = ConfigDict(json_schema_extra={
        'examples': [
            {
                "component": "FBK_LF1_ROL_054",
                "name": "Optical Inspection",
                "measurement_date": "2023-01-01T12:00:00+01:00",
                "location": "UT",
                "user_created": "fsiviero",
                "version": "v0",
                "passed": True,
                "comment": None,
            }
        ],
        'table': 'test',
        'component_types': ['Prototype LGAD', "PreProduction LGAD", "Production LGAD", "Ghost LGAD", "Fake LGAD"],
        'module_types': [],
        'description': 'Optical inspection test for sensors for Vendor and Lab testing center'
    })

    name: Literal['Optical Inspection'] = 'Optical Inspection'
    version: Literal["v0"] = "v0"

    passed: bool
    comment: Union[None, str] = Field(None, validation_alias=AliasChoices('comment', 'Comment'))

    def plot(self):
        return None

    def html_display(self):
        display_data = {
            "comment": self.comment,
            "passed": self.passed
        }
        template = jinja_env.get_template('sensors_plot.html')
        return template.render(
            plot=None,
            display_data=display_data
        )


OpticalInspectionType = Annotated[Union[OpticalInspectionV0], Field(discriminator="version")]