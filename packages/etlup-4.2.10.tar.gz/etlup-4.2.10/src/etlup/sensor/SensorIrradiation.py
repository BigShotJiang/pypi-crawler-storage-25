from pydantic import ConfigDict, Field, AliasChoices
from typing_extensions import Literal, Union, Annotated
from .. import base_model, jinja_env

class SensorIrradiationV0(base_model.ConstructionBase):
    model_config = ConfigDict(json_schema_extra={
        'examples': [
            {
                "component": "FBK_LF1_ROL_054",
                "name": "Sensor Irradiation",
                "measurement_date": "2023-01-01T12:00:00+01:00",
                "location": "UT",
                "user_created": "fsiviero",
                "version": "v0",
                "irradiation_level": 1E15,
            }
        ],
        'table': 'test',
        'component_types': ['Prototype LGAD', "PreProduction LGAD", "Production LGAD", "Ghost LGAD", "Fake LGAD"],
        'module_types': [],
        'description': 'Irradiation Test for LGADs'
    })

    component: str
    name: Literal['Sensor Irradiation'] = 'Sensor Irradiation'
    version: Literal["v0"] = "v0"
    
    irradiation_level: Union[None, float] = Field(None, validation_alias=AliasChoices('irradiation_level','Irradiation Level'))
    measuring_temperature: Union[None, float] = Field(None, validation_alias=AliasChoices('measuring_temperature','Measuring Temperature'))

    def plot(self):
        return None

    def html_display(self):
        display_data = {
            "irradiation_level": self.irradiation_level
        }
        template = jinja_env.get_template('sensors_plot.html')
        return template.render(
            plot = None,
            display_data = display_data
        )

SensorIrradiationType = Annotated[Union[SensorIrradiationV0], Field(discriminator="version")]