"""Run lifecycle class -- init, log, finish, properties.

The Run object manages:
- API client connection
- Write buffer for non-blocking metric logging
- Background sender thread for flush + heartbeat
- Config and Summary objects
- Step counter with W&B-compatible semantics
"""

from __future__ import annotations

import logging
import secrets
import string
import sys
from datetime import datetime, timezone
from typing import Any

from openrunner.api_client import APIClient
from openrunner.artifact import Artifact
from openrunner.buffer import WriteBuffer
from openrunner.cache import ArtifactCache
from openrunner.config import Config
from openrunner.git_info import capture_git_info
from openrunner.media import (
    Audio,
    BoundingBoxes2D,
    Embedding,
    Histogram,
    Html,
    Image,
    MatplotlibFigure,
    Plotly,
    PlotlyChart,
    PointCloud3D,
    Table,
    Video,
)
from openrunner.offline import OfflineStorage
from openrunner.sender import Sender
from openrunner.settings import SDKSettings
from openrunner.summary import Summary

logger = logging.getLogger("openrunner")

_ALPHABET = string.ascii_lowercase + string.digits


class _TeeWriter:
    """Wraps an IO stream to capture output while still writing to the original.

    Each line is buffered and sent to the Sender's console log buffer
    with a timestamp and stream identifier (stdout or stderr).
    """

    def __init__(self, original, stream_name: str, sender) -> None:
        self._original = original
        self._stream_name = stream_name
        self._sender = sender
        self._line_buffer = ""

    def write(self, text: str) -> int:
        self._original.write(text)
        # Buffer and split lines
        self._line_buffer += text
        while "\n" in self._line_buffer:
            line, self._line_buffer = self._line_buffer.split("\n", 1)
            if line:  # skip empty lines from trailing newlines
                ts = datetime.now(timezone.utc).isoformat()
                self._sender.add_console_line(ts, self._stream_name, line)
        return len(text)

    def flush(self) -> None:
        self._original.flush()
        # Flush partial line if any
        if self._line_buffer:
            ts = datetime.now(timezone.utc).isoformat()
            self._sender.add_console_line(ts, self._stream_name, self._line_buffer)
            self._line_buffer = ""

    def __getattr__(self, name):
        return getattr(self._original, name)


class _LogCaptureHandler(logging.Handler):
    """Captures Python logging output and sends it to OpenRunner console logs.

    This catches output from frameworks that use `logging` instead of `print()`
    (HuggingFace Transformers, PyTorch Lightning, etc.)
    """

    def __init__(self, sender) -> None:
        super().__init__()
        self._sender = sender
        # Don't capture openrunner's own logs to avoid recursion
        self.addFilter(lambda record: not record.name.startswith("openrunner"))

    def emit(self, record: logging.LogRecord) -> None:
        try:
            msg = self.format(record)
            ts = datetime.now(timezone.utc).isoformat()
            stream = "stderr" if record.levelno >= logging.WARNING else "stdout"
            self._sender.add_console_line(ts, stream, msg)
        except Exception:
            pass


def _generate_run_id() -> str:
    """Generate a W&B-style 8-character run ID."""
    return "".join(secrets.choice(_ALPHABET) for _ in range(8))


class Run:
    """An experiment run with lifecycle management.

    Created by ``openrunner.init()``, provides ``log()`` and ``finish()`` methods.
    The Run starts a background sender thread that flushes buffered metrics
    to the server and sends heartbeats.
    """

    def __init__(
        self,
        project: str,
        name: str | None = None,
        config_dict: dict[str, Any] | None = None,
        tags: list[str] | None = None,
        notes: str | None = None,
        group: str | None = None,
        job_type: str | None = None,
        run_id: str | None = None,
        settings: SDKSettings | None = None,
        resume: bool | str | None = None,
    ) -> None:
        # Parse "org/project" format (like W&B's "entity/project")
        if "/" in project:
            self._org, self._project = project.split("/", 1)
        else:
            self._org = None
            self._project = project
        self._name = name
        self._tags = tags
        self._notes = notes
        self._group = group
        self._job_type = job_type

        # Internal state
        self._summary = Summary()
        self._buffer = WriteBuffer()
        self._step = 0
        self._state = "running"
        self._artifact_cache = ArtifactCache()
        self._offline_storage: OfflineStorage | None = None

        # Settings
        settings = settings or SDKSettings()

        # Git info
        git_info = capture_git_info()

        # API client
        self._client = APIClient(
            base_url=settings.base_url,
            api_key=settings.api_key or "",
        )

        # -- Resume handling --------------------------------------------------
        resumed_from_id: str | None = None
        merged_config = dict(config_dict) if config_dict else {}

        if resume:
            parent_id = run_id
            parent_data = self._client.get_run(parent_id) if parent_id else None

            if parent_data is not None:
                # Parent found: generate new ID, merge config, offset steps
                self._id = _generate_run_id()
                resumed_from_id = parent_id
                parent_config = parent_data.get("config", {}) or {}
                merged_config = {**parent_config, **merged_config}
                max_step = self._client.get_run_max_step(parent_id)
                self._step = max_step + 1
            elif resume == "must":
                raise RuntimeError(
                    f"Cannot resume: run '{parent_id}' not found"
                )
            else:
                # resume=True or "allow" with missing parent: fresh run
                self._id = run_id or _generate_run_id()
        else:
            self._id = run_id or _generate_run_id()

        self._name = self._name or self._id
        self._config = Config(merged_config or None)

        # -- Offline mode -----------------------------------------------------
        if settings.mode == "offline":
            self._offline_storage = OfflineStorage(
                self._id, base_dir=settings.offline_dir
            )
            self._offline_storage.write_meta({
                "project": self._project,
                "name": self._name,
                "tags": self._tags,
                "notes": self._notes,
                "group": self._group,
                "job_type": self._job_type,
            })
            self._offline_storage.write_config(self._config.as_dict())
        else:
            # Create run on server (config sent at init, SDK-12)
            payload: dict[str, Any] = {
                "id": self._id,
                "project": self._project,
                "org": self._org,
                "display_name": self._name,
                "config": self._config.as_dict(),
                "tags": self._tags,
                "notes": self._notes,
                "group": self._group,
                "job_type": self._job_type,
            }
            if git_info is not None:
                payload["git_info"] = git_info
            if resumed_from_id is not None:
                payload["resumed_from_id"] = resumed_from_id

            self._client.create_run(payload)

        # Start background sender
        self._sender = Sender(
            buffer=self._buffer,
            client=self._client,
            run_id=self._id,
            system_metrics_enabled=settings.system_metrics_enabled,
            offline_storage=self._offline_storage,
        )
        self._sender.start()

        # Inject GPU info into config if available
        if self._sender._system_metrics is not None:
            gpu_info = self._sender._system_metrics.gpu_info
            if gpu_info:
                self._config.update({"_system": gpu_info})

        # Console log capture: redirect stdout/stderr through TeeWriter
        self._original_stdout = sys.stdout
        self._original_stderr = sys.stderr
        sys.stdout = _TeeWriter(sys.stdout, "stdout", self._sender)
        sys.stderr = _TeeWriter(sys.stderr, "stderr", self._sender)

        # Also capture Python logging output (used by HuggingFace, PyTorch, etc.)
        self._log_handler = _LogCaptureHandler(self._sender)
        logging.root.addHandler(self._log_handler)

    # -- Properties -----------------------------------------------------------

    @property
    def should_stop(self) -> bool:
        """True if the server has requested this run to stop."""
        return self._sender._stop_requested

    @property
    def id(self) -> str:
        """The unique run ID (8-char alphanumeric)."""
        return self._id

    @property
    def name(self) -> str:
        """The display name of the run."""
        return self._name

    @property
    def project(self) -> str:
        """The project name."""
        return self._project

    @property
    def config(self) -> Config:
        """The run's hyperparameter config."""
        return self._config

    @property
    def summary(self) -> Summary:
        """The run's summary metrics."""
        return self._summary

    @property
    def entity(self) -> str | None:
        """The entity (org) -- None for now."""
        return None

    @property
    def url(self) -> str:
        """Constructed URL to the run."""
        return f"{self._client._client.base_url}/runs/{self._id}"

    # -- Logging --------------------------------------------------------------

    def log(
        self,
        data: dict[str, Any],
        step: int | None = None,
        commit: bool = True,
    ) -> None:
        """Log metrics to the buffer.

        Detects Image and Table values and routes them to background
        media upload via the sender thread, keeping log() non-blocking.

        Args:
            data: Dict of metric key-value pairs (may include Image/Table).
            step: Explicit step value. If None, uses internal counter.
            commit: If True (default), increment the step counter.
        """
        current_step = step if step is not None else self._step
        timestamp = datetime.now(timezone.utc).isoformat()

        for key, value in data.items():
            if isinstance(value, Image):
                # Queue media upload (non-blocking -- sender handles serialization)
                self._buffer.put({
                    "_media": True,
                    "_media_type": "image",
                    "key": key,
                    "step": current_step,
                    "caption": value.caption,
                    "_image_obj": value,
                })
            elif isinstance(value, Table):
                # Queue table upload (non-blocking, inline JSONB)
                self._buffer.put({
                    "_media": True,
                    "_media_type": "table",
                    "key": key,
                    "step": current_step,
                    "_table_data": value._serialize(),
                })
            elif isinstance(value, Html):
                # Queue HTML data (inline JSONB, no S3 upload)
                self._buffer.put({
                    "_media": True,
                    "_media_type": "html",
                    "key": key,
                    "step": current_step,
                    "caption": value.caption,
                    "_html_data": value._serialize(),
                })
            elif isinstance(value, Audio):
                # Queue audio upload (sender serializes to WAV)
                self._buffer.put({
                    "_media": True,
                    "_media_type": "audio",
                    "key": key,
                    "step": current_step,
                    "caption": value.caption,
                    "_audio_obj": value,
                })
            elif isinstance(value, Video):
                # Queue video upload (sender serializes to MP4/WebM)
                self._buffer.put({
                    "_media": True,
                    "_media_type": "video",
                    "key": key,
                    "step": current_step,
                    "caption": value.caption,
                    "_video_obj": value,
                })
            elif isinstance(value, Histogram):
                # Queue histogram data (inline JSONB, no S3)
                self._buffer.put({
                    "_media": True,
                    "_media_type": "histogram",
                    "key": key,
                    "step": current_step,
                    "caption": value.caption,
                    "_histogram_data": value._serialize(),
                })
            elif isinstance(value, PlotlyChart):
                # Enhanced Plotly: JSON + optional static PNG (inline JSONB)
                self._buffer.put({
                    "_media": True,
                    "_media_type": "plotly",
                    "key": key,
                    "step": current_step,
                    "caption": value.caption,
                    "_plotly_data": value._serialize(),
                })
            elif isinstance(value, Plotly):
                # Queue plotly figure (inline JSONB, no S3)
                self._buffer.put({
                    "_media": True,
                    "_media_type": "plotly",
                    "key": key,
                    "step": current_step,
                    "caption": value.caption,
                    "_plotly_data": value._serialize(),
                })
            elif isinstance(value, MatplotlibFigure):
                # Capture matplotlib figure as PNG image
                self._buffer.put({
                    "_media": True,
                    "_media_type": "image",
                    "key": key,
                    "step": current_step,
                    "caption": value.caption,
                    "_image_obj": value,
                })
            elif isinstance(value, PointCloud3D):
                # Queue point cloud data (inline JSONB, no S3)
                self._buffer.put({
                    "_media": True,
                    "_media_type": "point_cloud_3d",
                    "key": key,
                    "step": current_step,
                    "caption": value.caption,
                    "_point_cloud_data": value._serialize(),
                })
            elif isinstance(value, Embedding):
                # Queue embedding data (inline JSONB, no S3)
                self._buffer.put({
                    "_media": True,
                    "_media_type": "embedding",
                    "key": key,
                    "step": current_step,
                    "caption": value.caption,
                    "_embedding_data": value._serialize(),
                })
            elif isinstance(value, BoundingBoxes2D):
                # Queue bbox overlay (image bytes + JSON box data)
                self._buffer.put({
                    "_media": True,
                    "_media_type": "bounding_boxes_2d",
                    "key": key,
                    "step": current_step,
                    "caption": value.caption,
                    "_bbox_obj": value,
                })
            else:
                # Regular metric
                self._summary._auto_update({key: value})
                self._buffer.put({
                    "key": key,
                    "value": value,
                    "step": current_step,
                    "timestamp": timestamp,
                })

        # Increment step counter on commit
        if commit and step is None:
            self._step += 1

    # -- Artifacts ------------------------------------------------------------

    def log_artifact(self, artifact: Artifact) -> dict[str, Any] | None:
        """Upload an artifact: create version, upload files, confirm.

        Files are uploaded via presigned URLs. Content-hash deduplication
        on the server means duplicate content is not re-uploaded.

        When the artifact was created with ``Artifact.from_version()``, only
        new/changed files are uploaded.  Unchanged base files are reused via
        their existing storage key (``reuse: true`` in the manifest).

        Args:
            artifact: The Artifact object with files added via add_file/add_dir.

        Returns:
            Server response dict with version info, or None on failure.
        """
        try:
            manifest = []
            new_file_names: set[str] = set()

            # Add explicitly added files (new or overriding base files)
            for f in artifact._files:
                entry: dict[str, Any] = {
                    "name": f["name"],
                    "size": f["size"],
                    "content_hash": f["content_hash"],
                }
                if f.get("is_reference"):
                    entry["is_reference"] = True
                    entry["reference_uri"] = f.get("reference_uri", "")
                manifest.append(entry)
                new_file_names.add(f["name"])

            # For draft-mode artifacts, carry over unchanged base files
            if artifact._base_version_id and artifact._base_files:
                for path, bf in artifact._base_files.items():
                    # Skip removed files and files overridden by new additions
                    if path in artifact._removed_files:
                        continue
                    if path in new_file_names:
                        continue
                    manifest.append({
                        "name": path,
                        "size": bf.get("size_bytes", 0),
                        "content_hash": bf.get("content_hash", ""),
                        "reuse": True,
                    })

            result = self._client.create_artifact_version(
                self._id,
                artifact.name,
                artifact.type,
                manifest,
                description=artifact.description,
                metadata=artifact.metadata,
                base_version_id=artifact._base_version_id,
            )
            if not result:
                return None

            # Upload files that need uploading (dedup may skip some)
            # Reference files and reused files never have upload URLs.
            for url_entry in result.get("upload_urls", []):
                local = next(
                    f for f in artifact._files if f["name"] == url_entry["name"]
                )
                self._client.upload_file_to_presigned_url(
                    url_entry["presigned_url"], local["local_path"]
                )

            # Confirm the version
            self._client.confirm_artifact_version(result["version_id"])
            return result
        except Exception as e:
            logger.warning("log_artifact failed: %s", e)
            return None

    def link_artifact(
        self, artifact: Artifact, aliases: list[str] | None = None
    ) -> dict[str, Any] | None:
        """Upload an artifact and set aliases on the created version.

        This is a convenience method that combines log_artifact with alias
        setting. The "latest" alias is automatically set by the server on
        confirmation; additional aliases (e.g., "production", "staging") are
        set via explicit API calls.

        Args:
            artifact: The Artifact object with files added.
            aliases: List of alias names to set (e.g., ["production"]).

        Returns:
            Server response dict with version info, or None on failure.
        """
        result = self.log_artifact(artifact)
        if result is None or not aliases:
            return result

        try:
            # We need the artifact_id to set aliases. Get it from the server.
            # The version_id is in the result; we can look up the artifact_id
            # from the artifact detail endpoint.
            version_id = result.get("version_id", "")

            # Get artifact by project lookup
            art_result = self._client._client.get(
                f"/projects/{self._project}/artifacts"
            )
            if art_result.status_code == 200:
                arts = art_result.json()
                artifact_id = None
                for a in arts:
                    if a.get("name") == artifact.name:
                        artifact_id = str(a["id"])
                        break

                if artifact_id and version_id:
                    for alias_name in aliases:
                        self._client.set_alias(artifact_id, alias_name, version_id)

        except Exception as e:
            logger.warning("link_artifact alias setting failed: %s", e)

        return result

    def use_artifact(
        self, name: str, version: int | None = None, alias: str | None = None
    ) -> "Path | None":
        """Download an artifact and cache locally.

        Uses an LRU cache to avoid re-downloading unchanged files.
        Supports alias-based lookup and "name:alias" syntax.

        Args:
            name: Artifact name. Can use "name:alias" syntax (e.g., "my-model:production").
            version: Specific version number, or None for latest.
            alias: Alias name to resolve (e.g., "production", "latest").

        Returns:
            Path to the local artifact directory, or None on failure.
        """
        try:
            from pathlib import Path

            # Support "name:alias" syntax
            if ":" in name and alias is None:
                name, alias = name.rsplit(":", 1)

            result = self._client.use_artifact(self._id, name, version, alias)
            if not result:
                return None

            # Prepare local artifact directory
            artifact_dir = (
                self._artifact_cache._dir
                / name
                / f"v{result.get('version', 0)}"
            )
            artifact_dir.mkdir(parents=True, exist_ok=True)

            for file_info in result.get("files", []):
                content_hash = file_info.get("content_hash", "")
                cached = self._artifact_cache.get(content_hash)

                dest = artifact_dir / file_info["path"]
                dest.parent.mkdir(parents=True, exist_ok=True)

                if cached:
                    # Copy from cache if not already at destination
                    if not dest.exists():
                        import shutil

                        shutil.copy2(str(cached), str(dest))
                else:
                    # Download and cache
                    data = self._client.download_file_from_presigned_url(
                        file_info["presigned_url"]
                    )
                    if data:
                        self._artifact_cache.put(content_hash, data)
                        dest.write_bytes(data)

            return artifact_dir
        except Exception as e:
            logger.warning("use_artifact failed: %s", e)
            return None

    # -- Console logging ------------------------------------------------------

    def log_text(self, text: str) -> None:
        """Explicitly log text to the console log without printing.

        Args:
            text: Text to log. Sent as stdout stream.
        """
        ts = datetime.now(timezone.utc).isoformat()
        self._sender.add_console_line(ts, "stdout", text)

    # -- Alerts ---------------------------------------------------------------

    def alert(
        self,
        title: str,
        text: str | None = None,
        level: str = "INFO",
    ) -> dict[str, Any] | None:
        """Send an alert for this run.

        Alerts are stored on the server and dispatched to configured
        notification channels (console, Slack webhook).

        Args:
            title: Short alert title.
            text: Detailed alert description (optional).
            level: Alert severity -- INFO, WARN, or ERROR. Default INFO.

        Returns:
            Server response dict with alert details, or None on failure.
        """
        try:
            return self._client.create_alert(
                self._id,
                title=title,
                text=text,
                level=level,
            )
        except Exception as e:
            logger.warning("alert() failed: %s", e)
            return None

    # -- Finish ---------------------------------------------------------------

    def finish(
        self,
        exit_code: int | None = None,
        quiet: bool = False,
    ) -> None:
        """Finish the run: stop sender, send final summary, close client.

        Args:
            exit_code: Optional exit code for the run.
            quiet: If True, suppress the finish message.
        """
        # Remove logging handler
        if hasattr(self, "_log_handler"):
            logging.root.removeHandler(self._log_handler)

        # Restore original stdout/stderr before stopping sender
        if hasattr(self, "_original_stdout"):
            # Flush any remaining captured output
            sys.stdout.flush()
            sys.stderr.flush()
            sys.stdout = self._original_stdout
            sys.stderr = self._original_stderr

        # Stop sender (drains buffer, closes offline storage)
        self._sender.stop()

        if self._offline_storage is not None:
            # Offline mode: write summary to disk
            self._offline_storage.write_summary(self._summary.as_dict())
        else:
            # Online mode: send final update to server
            update_payload: dict[str, Any] = {
                "state": "finished",
                "summary": self._summary.as_dict(),
            }
            if exit_code is not None:
                update_payload["exit_code"] = exit_code

            self._client.update_run(self._id, update_payload)

        # Close API client
        self._client.close()

        self._state = "finished"

        if not quiet:
            print(
                f"openrunner: Run {self._id} finished.",
                file=sys.stderr,
            )
