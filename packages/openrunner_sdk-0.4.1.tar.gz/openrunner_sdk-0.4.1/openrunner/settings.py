"""SDK settings with env var cascade (OPENRUNNER_* -> OPENRUN_* -> WANDB_* -> defaults)."""

from __future__ import annotations

import os
from pathlib import Path


class SDKSettings:
    """SDK settings resolved from environment variables.

    Cascade order for each setting:
      1. OPENRUNNER_* env var
      2. OPENRUN_* env var (backward compatibility)
      3. WANDB_* env var (migration convenience)
      4. Built-in default
    """

    def __init__(self) -> None:
        self._api_key: str | None = None
        self._base_url: str | None = None
        self._project: str | None = None
        self._system_metrics_enabled: bool | None = None

    @property
    def api_key(self) -> str | None:
        """API key for authentication (OPENRUNNER_API_KEY -> OPENRUN_API_KEY -> WANDB_API_KEY)."""
        if self._api_key is not None:
            return self._api_key
        return (
            os.environ.get("OPENRUNNER_API_KEY")
            or os.environ.get("OPENRUN_API_KEY")
            or os.environ.get("WANDB_API_KEY")
        )

    @api_key.setter
    def api_key(self, value: str | None) -> None:
        self._api_key = value

    @property
    def base_url(self) -> str:
        """Server base URL (OPENRUNNER_BASE_URL -> OPENRUN_BASE_URL -> WANDB_BASE_URL -> http://localhost:8000)."""
        if self._base_url is not None:
            return self._base_url
        return (
            os.environ.get("OPENRUNNER_BASE_URL")
            or os.environ.get("OPENRUN_BASE_URL")
            or os.environ.get("WANDB_BASE_URL")
            or "http://localhost:8000"
        )

    @base_url.setter
    def base_url(self, value: str | None) -> None:
        self._base_url = value

    @property
    def project(self) -> str | None:
        """Project name (OPENRUNNER_PROJECT -> OPENRUN_PROJECT -> WANDB_PROJECT)."""
        if self._project is not None:
            return self._project
        return (
            os.environ.get("OPENRUNNER_PROJECT")
            or os.environ.get("OPENRUN_PROJECT")
            or os.environ.get("WANDB_PROJECT")
        )

    @project.setter
    def project(self, value: str | None) -> None:
        self._project = value

    @property
    def system_metrics_enabled(self) -> bool:
        """Whether to collect system metrics (OPENRUNNER_SYSTEM_METRICS -> OPENRUN_SYSTEM_METRICS -> default True)."""
        if self._system_metrics_enabled is not None:
            return self._system_metrics_enabled
        val = (
            os.environ.get("OPENRUNNER_SYSTEM_METRICS")
            or os.environ.get("OPENRUN_SYSTEM_METRICS")
            or "true"
        )
        return val.lower() in ("true", "1", "yes")

    @system_metrics_enabled.setter
    def system_metrics_enabled(self, value: bool) -> None:
        self._system_metrics_enabled = value

    @property
    def mode(self) -> str:
        """SDK mode: 'online' (default) or 'offline' (OPENRUNNER_MODE or OPENRUN_MODE env var)."""
        return (
            os.environ.get("OPENRUNNER_MODE")
            or os.environ.get("OPENRUN_MODE")
            or "online"
        )

    @property
    def offline_dir(self) -> Path:
        """Directory for offline storage (OPENRUNNER_OFFLINE_DIR -> OPENRUN_OFFLINE_DIR -> ~/.openrunner/offline)."""
        return Path(
            os.environ.get("OPENRUNNER_OFFLINE_DIR")
            or os.environ.get(
                "OPENRUN_OFFLINE_DIR",
                str(Path.home() / ".openrunner" / "offline"),
            )
        )
