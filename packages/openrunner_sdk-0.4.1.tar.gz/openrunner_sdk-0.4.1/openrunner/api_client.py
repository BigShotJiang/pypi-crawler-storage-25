"""HTTP client for OpenRunner server communication.

Uses httpx.Client (synchronous, thread-safe) with defensive error handling.
All methods log warnings on failure and never raise exceptions to the caller.
"""

from __future__ import annotations

import logging
from typing import Any

import httpx

logger = logging.getLogger("openrunner")


class APIClient:
    """HTTP client for the OpenRunner server API.

    All methods are defensive -- they catch exceptions, log warnings,
    and return None/0 rather than propagating errors to the caller.
    This ensures SDK failures never crash training code.
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        kwargs: dict[str, Any] = {
            "base_url": f"{base_url.rstrip('/')}/api/v1",
            "headers": {"Authorization": f"Bearer {api_key}"},
            "timeout": 30.0,
        }
        if transport is not None:
            kwargs["transport"] = transport

        self._client = httpx.Client(**kwargs)

    def create_run(self, data: dict[str, Any]) -> dict[str, Any] | None:
        """POST /runs -- create a new run on the server.

        Returns the response JSON dict, or None on failure.
        """
        try:
            response = self._client.post("/runs", json=data)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("create_run failed: %s", e)
            return None

    def update_run(self, run_id: str, data: dict[str, Any]) -> dict[str, Any] | None:
        """PATCH /runs/{run_id} -- update run state/summary/config.

        Returns the response JSON dict, or None on failure.
        """
        try:
            response = self._client.patch(f"/runs/{run_id}", json=data)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("update_run failed: %s", e)
            return None

    def post_metrics(self, run_id: str, metrics: list[dict[str, Any]]) -> int:
        """POST /runs/{run_id}/metrics -- send a batch of metric records.

        Returns the count of metrics accepted, or 0 on failure.
        """
        try:
            response = self._client.post(
                f"/runs/{run_id}/metrics",
                json={"metrics": metrics},
            )
            response.raise_for_status()
            return response.json().get("count", 0)
        except Exception as e:
            logger.warning("post_metrics failed: %s", e)
            return 0

    def get_run(self, run_id: str) -> dict[str, Any] | None:
        """GET /runs/{run_id} -- fetch run data.

        Returns the response JSON dict, or None on failure/not-found.
        """
        try:
            response = self._client.get(f"/runs/{run_id}")
            if response.status_code == 404:
                return None
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("get_run failed: %s", e)
            return None

    def get_run_max_step(self, run_id: str) -> int:
        """GET /runs/{run_id}/metrics -- return max step across all metric keys.

        Fetches a small sample of metrics and finds the maximum step value.
        Returns 0 if no metrics exist or on failure.
        """
        try:
            response = self._client.get(
                f"/runs/{run_id}/metrics", params={"max_points": 10}
            )
            if response.status_code == 404:
                return 0
            response.raise_for_status()
            data = response.json()
            max_step = 0
            # data is a dict of metric_key -> list of {step, value, ...}
            if isinstance(data, dict):
                for key, series in data.items():
                    if isinstance(series, list):
                        for point in series:
                            step = point.get("step", 0)
                            if step > max_step:
                                max_step = step
            return max_step
        except Exception as e:
            logger.warning("get_run_max_step failed: %s", e)
            return 0

    def sync_metrics(self, run_id: str, metrics: list[dict[str, Any]]) -> int:
        """POST /runs/{run_id}/sync-metrics -- idempotent metric sync.

        Calls the sync-metrics endpoint which uses ON CONFLICT DO NOTHING
        to handle duplicate metric points. Returns count or 0 on failure.
        """
        try:
            response = self._client.post(
                f"/runs/{run_id}/sync-metrics",
                json={"metrics": metrics},
            )
            response.raise_for_status()
            return response.json().get("count", 0)
        except Exception as e:
            logger.warning("sync_metrics failed: %s", e)
            return 0

    def post_heartbeat(self, run_id: str) -> dict[str, Any] | None:
        """POST /runs/{run_id}/heartbeat -- send a heartbeat signal.

        Returns the response dict (includes stop_requested), or None on failure.
        """
        try:
            response = self._client.post(f"/runs/{run_id}/heartbeat")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("post_heartbeat failed: %s", e)
            return None

    def post_logs(self, run_id: str, lines: list[dict[str, Any]]) -> int:
        """POST /runs/{run_id}/logs -- send a batch of console log lines.

        Returns the count of lines accepted, or 0 on failure.
        """
        try:
            response = self._client.post(
                f"/runs/{run_id}/logs",
                json={"lines": lines},
            )
            response.raise_for_status()
            return response.json().get("count", 0)
        except Exception as e:
            logger.warning("post_logs failed: %s", e)
            return 0

    # -- Listing methods -------------------------------------------------------

    def list_projects(self) -> list[dict[str, Any]]:
        """GET /projects -- list all projects the user has access to.

        Returns a list of project dicts, or empty list on failure.
        """
        try:
            response = self._client.get("/projects")
            response.raise_for_status()
            data = response.json()
            # Server may return {projects: [...]} or [...]
            if isinstance(data, list):
                return data
            return data.get("projects", data.get("items", []))
        except Exception as e:
            logger.warning("list_projects failed: %s", e)
            return []

    def list_runs(self, project_id: str) -> list[dict[str, Any]]:
        """GET /projects/{project_id}/runs -- list runs in a project.

        Returns a list of run dicts, or empty list on failure.
        """
        try:
            response = self._client.get(f"/projects/{project_id}/runs")
            response.raise_for_status()
            data = response.json()
            if isinstance(data, list):
                return data
            return data.get("runs", data.get("items", []))
        except Exception as e:
            logger.warning("list_runs failed: %s", e)
            return []

    # -- Artifact methods ------------------------------------------------------

    def create_artifact_version(
        self,
        run_id: str,
        name: str,
        type: str,
        files: list[dict[str, Any]],
        description: str | None = None,
        metadata: dict[str, Any] | None = None,
        base_version_id: str | None = None,
    ) -> dict[str, Any] | None:
        """POST /runs/{run_id}/artifacts -- create a new artifact version.

        When base_version_id is provided, the server reuses storage keys
        for files marked with reuse=True in the manifest, enabling
        incremental artifact updates.

        Returns {version_id, version, upload_urls}, or None on failure.
        """
        try:
            body: dict[str, Any] = {
                "name": name,
                "type": type,
                "files": files,
            }
            if description is not None:
                body["description"] = description
            if metadata is not None:
                body["metadata"] = metadata
            if base_version_id is not None:
                body["base_version_id"] = base_version_id
            response = self._client.post(f"/runs/{run_id}/artifacts", json=body)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("create_artifact_version failed: %s", e)
            return None

    def confirm_artifact_version(
        self, version_id: str
    ) -> dict[str, Any] | None:
        """POST /artifacts/versions/{version_id}/confirm -- confirm upload.

        Returns {status, version}, or None on failure.
        """
        try:
            response = self._client.post(
                f"/artifacts/versions/{version_id}/confirm"
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("confirm_artifact_version failed: %s", e)
            return None

    def use_artifact(
        self,
        run_id: str,
        artifact_name: str,
        version: int | None = None,
        alias: str | None = None,
    ) -> dict[str, Any] | None:
        """POST /runs/{run_id}/use-artifact -- get download URLs.

        Supports alias-based lookup: provide alias instead of version, or
        use "name:alias" syntax in artifact_name.

        Returns download info dict, or None on failure.
        """
        try:
            body: dict[str, Any] = {"artifact_name": artifact_name}
            if version is not None:
                body["version"] = version
            if alias is not None:
                body["alias"] = alias
            response = self._client.post(
                f"/runs/{run_id}/use-artifact", json=body
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("use_artifact failed: %s", e)
            return None

    def set_alias(
        self,
        artifact_id: str,
        alias_name: str,
        version_id: str,
    ) -> dict[str, Any] | None:
        """PUT /artifacts/{artifact_id}/aliases/{alias_name} -- set an alias.

        Returns alias response dict, or None on failure.
        """
        try:
            response = self._client.put(
                f"/artifacts/{artifact_id}/aliases/{alias_name}",
                json={"version_id": version_id},
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("set_alias failed: %s", e)
            return None

    def list_aliases(
        self,
        artifact_id: str,
    ) -> list[dict[str, Any]]:
        """GET /artifacts/{artifact_id}/aliases -- list all aliases.

        Returns list of alias dicts, or empty list on failure.
        """
        try:
            response = self._client.get(f"/artifacts/{artifact_id}/aliases")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("list_aliases failed: %s", e)
            return []

    def list_artifacts(self, project_id: str) -> list[dict[str, Any]]:
        """GET /projects/{project_id}/artifacts -- list artifacts in a project.

        Returns a list of artifact dicts, or empty list on failure.
        """
        try:
            response = self._client.get(f"/projects/{project_id}/artifacts")
            response.raise_for_status()
            data = response.json()
            if isinstance(data, list):
                return data
            return data.get("artifacts", data.get("items", []))
        except Exception as e:
            logger.warning("list_artifacts failed: %s", e)
            return []

    def get_artifact_detail(self, artifact_id: str) -> dict[str, Any] | None:
        """GET /artifacts/{artifact_id} -- get artifact detail with versions.

        Returns the artifact detail dict, or None on failure.
        """
        try:
            response = self._client.get(f"/artifacts/{artifact_id}")
            if response.status_code == 404:
                return None
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("get_artifact_detail failed: %s", e)
            return None

    def get_artifact_download_urls(
        self, version_id: str
    ) -> dict[str, Any] | None:
        """GET /artifacts/versions/{version_id}/download -- get download URLs.

        Returns {version_id, version, files: [{path, presigned_url, size_bytes}]}.
        """
        try:
            response = self._client.get(
                f"/artifacts/versions/{version_id}/download"
            )
            if response.status_code == 404:
                return None
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("get_artifact_download_urls failed: %s", e)
            return None

    def list_artifact_files(self, version_id: str) -> list[dict[str, Any]]:
        """GET /artifacts/versions/{version_id}/files -- list files in a version.

        Returns a list of file dicts, or empty list on failure.
        """
        try:
            response = self._client.get(
                f"/artifacts/versions/{version_id}/files"
            )
            response.raise_for_status()
            data = response.json()
            return data if isinstance(data, list) else []
        except Exception as e:
            logger.warning("list_artifact_files failed: %s", e)
            return []

    def upload_file_to_presigned_url(
        self, presigned_url: str, file_path: str
    ) -> bool:
        """PUT raw file bytes to a presigned URL.

        Uses httpx directly (not self._client) because presigned URLs
        are absolute and should not have a base_url prefix.
        """
        try:
            with open(file_path, "rb") as f:
                data = f.read()
            resp = httpx.put(presigned_url, content=data, timeout=300.0)
            resp.raise_for_status()
            return True
        except Exception as e:
            logger.warning("upload_file_to_presigned_url failed: %s", e)
            return False

    def download_file_from_presigned_url(
        self, presigned_url: str
    ) -> bytes | None:
        """GET file bytes from a presigned URL.

        Uses httpx directly (not self._client) because presigned URLs
        are absolute and should not have a base_url prefix.
        """
        try:
            resp = httpx.get(presigned_url, timeout=300.0)
            resp.raise_for_status()
            return resp.content
        except Exception as e:
            logger.warning("download_file_from_presigned_url failed: %s", e)
            return None

    # -- Media methods -------------------------------------------------------

    def create_media_file(
        self,
        run_id: str,
        key: str,
        media_type: str,
        step: int | None = None,
        caption: str | None = None,
        content_type: str | None = None,
        width: int | None = None,
        height: int | None = None,
        data: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        """POST /runs/{run_id}/media -- create a media file record.

        Returns {id, storage_key, presigned_url}, or None on failure.
        """
        try:
            body: dict[str, Any] = {
                "key": key,
                "media_type": media_type,
            }
            if step is not None:
                body["step"] = step
            if caption is not None:
                body["caption"] = caption
            if content_type is not None:
                body["content_type"] = content_type
            if width is not None:
                body["width"] = width
            if height is not None:
                body["height"] = height
            if data is not None:
                body["data"] = data
            response = self._client.post(f"/runs/{run_id}/media", json=body)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("create_media_file failed: %s", e)
            return None

    def upload_media_bytes(
        self,
        presigned_url: str,
        data_bytes: bytes,
        content_type: str = "image/png",
    ) -> bool:
        """PUT bytes to a presigned URL with Content-Type header.

        Uses httpx directly (not self._client) because presigned URLs
        are absolute and should not have a base_url prefix.
        """
        try:
            resp = httpx.put(
                presigned_url,
                content=data_bytes,
                headers={"Content-Type": content_type},
                timeout=300.0,
            )
            resp.raise_for_status()
            return True
        except Exception as e:
            logger.warning("upload_media_bytes failed: %s", e)
            return False

    # -- Alert methods -------------------------------------------------------

    def create_alert(
        self,
        run_id: str,
        title: str,
        text: str | None = None,
        level: str = "INFO",
    ) -> dict[str, Any] | None:
        """POST /runs/{run_id}/alerts -- create an alert for a run.

        Returns the alert response dict, or None on failure.
        """
        try:
            body: dict[str, Any] = {"title": title, "level": level}
            if text is not None:
                body["text"] = text
            response = self._client.post(f"/runs/{run_id}/alerts", json=body)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("create_alert failed: %s", e)
            return None

    # -- Job methods ---------------------------------------------------------

    def create_job(
        self,
        project_id: str,
        data: dict[str, Any],
    ) -> dict[str, Any] | None:
        """POST /projects/{project_id}/jobs -- create a new job.

        Returns the job response dict, or None on failure.
        """
        try:
            response = self._client.post(
                f"/projects/{project_id}/jobs", json=data
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("create_job failed: %s", e)
            return None

    def get_job(self, job_id: str) -> dict[str, Any] | None:
        """GET /jobs/{job_id} -- fetch job data.

        Returns the job response dict, or None on failure.
        """
        try:
            response = self._client.get(f"/jobs/{job_id}")
            if response.status_code == 404:
                return None
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("get_job failed: %s", e)
            return None

    def list_jobs(self, project_id: str) -> list[dict[str, Any]]:
        """GET /projects/{project_id}/jobs -- list jobs in a project.

        Returns a list of job dicts, or empty list on failure.
        """
        try:
            response = self._client.get(f"/projects/{project_id}/jobs")
            response.raise_for_status()
            data = response.json()
            if isinstance(data, list):
                return data
            return data.get("jobs", data.get("items", []))
        except Exception as e:
            logger.warning("list_jobs failed: %s", e)
            return []

    def cancel_job(self, job_id: str) -> dict[str, Any] | None:
        """DELETE /jobs/{job_id} -- cancel a job.

        Returns the job response dict, or None on failure.
        """
        try:
            response = self._client.delete(f"/jobs/{job_id}")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("cancel_job failed: %s", e)
            return None

    # -- Trace methods -------------------------------------------------------

    def post_trace(
        self,
        project_id: str,
        trace_data: dict[str, Any],
    ) -> dict[str, Any] | None:
        """POST /projects/{project_id}/traces -- send a completed trace.

        Returns the trace response dict, or None on failure.
        """
        try:
            response = self._client.post(
                f"/projects/{project_id}/traces", json=trace_data
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("post_trace failed: %s", e)
            return None

    # -- Lifecycle -----------------------------------------------------------

    def close(self) -> None:
        """Close the underlying httpx client."""
        try:
            self._client.close()
        except Exception:
            pass
