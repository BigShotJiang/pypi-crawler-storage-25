"""W&B-compatible Summary object with auto-update and explicit set support."""

from __future__ import annotations

from typing import Any


class Summary:
    """W&B-compatible summary that auto-tracks last logged values.

    * ``_auto_update(data)`` is called by ``log()`` to record the last value
      for each metric key.
    * Explicit set (``summary["key"] = val`` or ``summary.key = val``) takes
      priority -- once a key is explicitly set, auto-update will NOT override it.
    * ``_get_update_payload()`` returns keys that changed since the last call
      (used by the sender to push delta updates to the server).
    """

    def __init__(self) -> None:
        object.__setattr__(self, "_data", {})
        object.__setattr__(self, "_explicit_keys", set())
        object.__setattr__(self, "_dirty_keys", set())

    # -- auto-update (called by log()) ----------------------------------------

    def _auto_update(self, data: dict[str, Any]) -> None:
        """Merge *data* into the summary, skipping explicitly set keys."""
        for k, v in data.items():
            if k not in self._explicit_keys:
                self._data[k] = v
                self._dirty_keys.add(k)

    # -- explicit set ---------------------------------------------------------

    def __setitem__(self, key: str, value: Any) -> None:
        self._data[key] = value
        self._explicit_keys.add(key)
        self._dirty_keys.add(key)

    def __setattr__(self, name: str, value: Any) -> None:
        self.__setitem__(name, value)

    # -- access ---------------------------------------------------------------

    def __getitem__(self, key: str) -> Any:
        return self._data[key]

    def __getattr__(self, name: str) -> Any:
        try:
            return self._data[name]
        except KeyError:
            raise AttributeError(f"Summary has no key '{name}'") from None

    def __contains__(self, key: object) -> bool:
        return key in self._data

    # -- introspection --------------------------------------------------------

    def as_dict(self) -> dict[str, Any]:
        """Return a copy of the current summary state."""
        return dict(self._data)

    def _get_update_payload(self) -> dict[str, Any]:
        """Return keys that changed since the last call, then clear dirty set."""
        payload = {k: self._data[k] for k in self._dirty_keys if k in self._data}
        self._dirty_keys.clear()
        return payload

    def __repr__(self) -> str:
        return f"Summary({self._data!r})"
