"""OpenRunner SDK - W&B-compatible ML experiment tracking.

Public API:
    openrunner.init(project=..., name=..., config=...)  -> Run
    openrunner.log({"loss": 0.5}, step=10)              -> None
    openrunner.finish(exit_code=0)                      -> None
    openrunner.config       -> Config proxy
    openrunner.summary      -> Summary proxy
    openrunner.run          -> active Run or None
    openrunner.Image        -> Image class for media logging
    openrunner.Html         -> Html class for raw HTML logging
    openrunner.Table        -> Table class for structured data
    openrunner.Audio        -> Audio class for audio logging
    openrunner.Video        -> Video class for video logging
    openrunner.Histogram    -> Histogram class for distribution logging
    openrunner.Plotly       -> Plotly class for interactive charts
    openrunner.PlotlyChart  -> Enhanced Plotly with static PNG fallback
    openrunner.MatplotlibFigure -> Capture matplotlib figure as PNG
    openrunner.PointCloud3D -> 3D point cloud visualization
    openrunner.Embedding    -> Embedding projection (t-SNE/PCA/UMAP)
    openrunner.BoundingBoxes2D -> Bounding box overlay on images
    openrunner.Artifact     -> Artifact class for versioned file collections
    openrunner.Api          -> Query API for read-only access to runs/projects
    openrunner.alert        -> Send an alert for the active run
    openrunner.log_artifact -> Upload an artifact
    openrunner.use_artifact -> Download an artifact (cached)
    openrunner.sweep        -> Create a hyperparameter sweep
    openrunner.agent        -> Run a sweep agent loop
    openrunner.launch       -> Create a remote execution job
    openrunner.launch.from_run -> Re-launch from a previous run's config
    openrunner.LaunchJob    -> Job handle with .wait() and .cancel()
    openrunner.trace        -> Decorator for LLM call tracing
    openrunner.trace.patch_openai -> Auto-trace OpenAI chat completions
    openrunner.Prompt       -> Versioned prompt management (get/render/publish)
    openrunner.evaluate     -> Run LLM evaluation against a dataset
    openrunner.scorer       -> Decorator to mark a function as an eval scorer
    openrunner.scorers      -> Built-in scorers (exact_match, contains, etc.)
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from openrunner.artifact import Artifact
from openrunner.config import Config
from openrunner.prompt import Prompt
from openrunner.launch import LaunchJob, launch, from_run as _launch_from_run
from openrunner.media import (
    Audio,
    BoundingBoxes2D,
    Embedding,
    Histogram,
    Html,
    Image,
    MatplotlibFigure,
    Plotly,
    PlotlyChart,
    PointCloud3D,
    Table,
    Video,
)
from openrunner.query_api import Api
from openrunner.run import Run
from openrunner.settings import SDKSettings
from openrunner.summary import Summary
from openrunner.sweep import agent, sweep
from openrunner.evaluation import evaluate, scorer
from openrunner.trace import trace, patch_openai as _patch_openai
import openrunner.scorers as scorers

# Attach from_run as a method on the launch function for
# openrunner.launch.from_run() syntax
launch.from_run = _launch_from_run  # type: ignore[attr-defined]

# Attach patch_openai as a method on the trace function for
# openrunner.trace.patch_openai() syntax
trace.patch_openai = _patch_openai  # type: ignore[attr-defined]

__version__ = "0.3.0"

logger = logging.getLogger("openrunner")

# Active run state
_active_run: Run | None = None


# ---------------------------------------------------------------------------
# Proxy objects for module-level config/summary access
# ---------------------------------------------------------------------------

class _ConfigProxy:
    """Proxy that delegates attribute access to the active run's Config.

    Since Python modules can't have properties, this proxy object sits
    at ``openrunner.config`` and forwards all access to ``_active_run.config``.
    """

    def __getattr__(self, name: str) -> Any:
        if _active_run is not None:
            return getattr(_active_run.config, name)
        raise AttributeError(f"No active run -- call openrunner.init() first")

    def __setattr__(self, name: str, value: Any) -> None:
        if _active_run is not None:
            setattr(_active_run.config, name, value)
        else:
            logger.warning("openrunner.config: no active run -- call openrunner.init() first")

    def __getitem__(self, key: str) -> Any:
        if _active_run is not None:
            return _active_run.config[key]
        raise KeyError(f"No active run -- call openrunner.init() first")

    def __setitem__(self, key: str, value: Any) -> None:
        if _active_run is not None:
            _active_run.config[key] = value
        else:
            logger.warning("openrunner.config: no active run -- call openrunner.init() first")

    def __repr__(self) -> str:
        if _active_run is not None:
            return repr(_active_run.config)
        return "ConfigProxy(no active run)"


class _SummaryProxy:
    """Proxy that delegates attribute access to the active run's Summary."""

    def __getattr__(self, name: str) -> Any:
        if _active_run is not None:
            return getattr(_active_run.summary, name)
        raise AttributeError(f"No active run -- call openrunner.init() first")

    def __setattr__(self, name: str, value: Any) -> None:
        if _active_run is not None:
            setattr(_active_run.summary, name, value)
        else:
            logger.warning("openrunner.summary: no active run -- call openrunner.init() first")

    def __getitem__(self, key: str) -> Any:
        if _active_run is not None:
            return _active_run.summary[key]
        raise KeyError(f"No active run -- call openrunner.init() first")

    def __setitem__(self, key: str, value: Any) -> None:
        if _active_run is not None:
            _active_run.summary[key] = value
        else:
            logger.warning("openrunner.summary: no active run -- call openrunner.init() first")

    def __repr__(self) -> str:
        if _active_run is not None:
            return repr(_active_run.summary)
        return "SummaryProxy(no active run)"


# Module-level proxy instances
config = _ConfigProxy()
summary = _SummaryProxy()


# ---------------------------------------------------------------------------
# Public API functions
# ---------------------------------------------------------------------------

def init(
    project: str | None = None,
    name: str | None = None,
    config: dict[str, Any] | None = None,
    tags: list[str] | None = None,
    notes: str | None = None,
    group: str | None = None,
    job_type: str | None = None,
    id: str | None = None,
    resume: bool | str | None = None,
    **kwargs: Any,
) -> Run | None:
    """Initialize a new run.

    Creates a run on the server, starts the background sender thread,
    and returns the Run object. Never raises -- SDK failures must not
    crash training code.

    Args:
        project: Project name (or OPENRUNNER_PROJECT env var, or "uncategorized").
        name: Display name for the run.
        config: Hyperparameter dict (sent to server at init time, SDK-12).
        tags: List of tags for the run.
        notes: Notes/description for the run.
        group: Group name for related runs.
        job_type: Job type label.
        id: Custom run ID (8-char alphanumeric generated if not provided).
        resume: Resume mode -- True/"allow" (resume if exists, fresh otherwise)
                or "must" (error if parent not found). The ``id`` parameter
                is treated as the parent run ID when resuming.

    Returns:
        The Run object, or None if initialization fails.
    """
    global _active_run

    try:
        settings = SDKSettings()

        # Resolve project
        resolved_project = project or settings.project or "uncategorized"

        # Warn if no API key (skip in offline mode)
        if not settings.api_key and settings.mode != "offline":
            logger.warning(
                "No API key set. Set OPENRUNNER_API_KEY or WANDB_API_KEY "
                "environment variable for server communication."
            )

        # Create run
        run = Run(
            project=resolved_project,
            name=name,
            config_dict=config,
            tags=tags,
            notes=notes,
            group=group,
            job_type=job_type,
            run_id=id,
            settings=settings,
            resume=resume,
        )

        _active_run = run
        return run

    except Exception as e:
        logger.warning("openrunner.init() failed: %s", e)
        return None


def log(
    data: dict[str, Any],
    step: int | None = None,
    commit: bool = True,
) -> None:
    """Log metrics. Never raises -- training must not be interrupted.

    Args:
        data: Dict of metric key-value pairs.
        step: Explicit step value.
        commit: If True (default), finalize the current step.
    """
    try:
        if _active_run is None:
            logger.warning("openrunner.log(): no active run -- call openrunner.init() first")
            return
        _active_run.log(data, step=step, commit=commit)
    except Exception as e:
        logger.warning("openrunner.log() failed: %s", e)


def finish(
    exit_code: int | None = None,
    quiet: bool | None = None,
) -> None:
    """Finish the active run. Never raises.

    Args:
        exit_code: Optional exit code.
        quiet: If True, suppress the finish message.
    """
    global _active_run

    try:
        if _active_run is None:
            return
        _active_run.finish(exit_code=exit_code, quiet=quiet or False)
        _active_run = None
    except Exception as e:
        logger.warning("openrunner.finish() failed: %s", e)
        _active_run = None


def alert(
    title: str,
    text: str | None = None,
    level: str = "INFO",
) -> dict[str, Any] | None:
    """Send an alert for the active run. Never raises.

    Alerts are stored on the server and dispatched to configured
    notification channels (console, Slack webhook).

    Args:
        title: Short alert title.
        text: Detailed alert description (optional).
        level: Alert severity -- INFO, WARN, or ERROR. Default INFO.

    Returns:
        Server response dict with alert details, or None on failure.
    """
    try:
        if _active_run is None:
            logger.warning("openrunner.alert(): no active run -- call openrunner.init() first")
            return None
        return _active_run.alert(title=title, text=text, level=level)
    except Exception as e:
        logger.warning("openrunner.alert() failed: %s", e)
        return None


def log_artifact(artifact: Artifact) -> dict[str, Any] | None:
    """Upload an artifact to the active run. Never raises.

    Args:
        artifact: The Artifact object with files added via add_file/add_dir.

    Returns:
        Server response dict with version info, or None on failure.
    """
    try:
        if _active_run is None:
            logger.warning("openrunner.log_artifact(): no active run")
            return None
        return _active_run.log_artifact(artifact)
    except Exception as e:
        logger.warning("openrunner.log_artifact() failed: %s", e)
        return None


def link_artifact(
    artifact: Artifact, aliases: list[str] | None = None
) -> dict[str, Any] | None:
    """Upload an artifact and set aliases. Never raises.

    Combines log_artifact with alias setting. Useful for model registry
    workflows where you want to tag a version as "production" or "staging".

    Args:
        artifact: The Artifact object with files added via add_file/add_dir.
        aliases: List of alias names to set (e.g., ["production"]).

    Returns:
        Server response dict with version info, or None on failure.
    """
    try:
        if _active_run is None:
            logger.warning("openrunner.link_artifact(): no active run")
            return None
        return _active_run.link_artifact(artifact, aliases=aliases)
    except Exception as e:
        logger.warning("openrunner.link_artifact() failed: %s", e)
        return None


def use_artifact(
    name: str, version: int | None = None, alias: str | None = None
) -> Path | None:
    """Download an artifact and cache locally. Never raises.

    Supports alias-based lookup and "name:alias" syntax
    (e.g., "my-model:production").

    Args:
        name: Artifact name. Can use "name:alias" syntax.
        version: Specific version number, or None for latest.
        alias: Alias name to resolve (e.g., "production").

    Returns:
        Path to the local artifact directory, or None on failure.
    """
    try:
        if _active_run is None:
            logger.warning("openrunner.use_artifact(): no active run")
            return None
        return _active_run.use_artifact(name, version, alias)
    except Exception as e:
        logger.warning("openrunner.use_artifact() failed: %s", e)
        return None


def should_stop() -> bool:
    """Check if the server has requested the active run to stop.

    Returns False if no active run. Users call this in their training
    loop: ``if openrunner.should_stop(): break``
    """
    if _active_run is None:
        return False
    return _active_run.should_stop


def log_text(text: str) -> None:
    """Log explicit text to the console log without printing. Never raises.

    Args:
        text: Text string to log.
    """
    try:
        if _active_run is None:
            logger.warning("openrunner.log_text(): no active run")
            return
        _active_run.log_text(text)
    except Exception as e:
        logger.warning("openrunner.log_text() failed: %s", e)


@property  # type: ignore[misc]
def run() -> Run | None:
    """Return the active run, or None."""
    return _active_run
