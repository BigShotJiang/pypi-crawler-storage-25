"""PyTorch Lightning integration for OpenRunner.

Provides ``OpenRunnerLogger`` -- a Lightning ``Logger`` that delegates
``log_metrics`` and ``log_hyperparams`` to the OpenRunner SDK.

Usage::

    from openrunner.integration.lightning import OpenRunnerLogger

    logger = OpenRunnerLogger(project="my-project", tags=["baseline"])
    trainer = Trainer(logger=logger)
    trainer.fit(model)

Requires: ``pip install openrunner[lightning]``
"""

from __future__ import annotations

from typing import Any

try:
    from lightning.pytorch.loggers import Logger
except ImportError:
    raise ImportError(
        "Lightning integration requires lightning. "
        "Install with: pip install openrunner[lightning]"
    )

import openrunner


class OpenRunnerLogger(Logger):
    """PyTorch Lightning logger backed by OpenRunner.

    The run is lazily initialized on the first call to
    ``log_hyperparams`` or ``log_metrics``, so adding the logger to a
    ``Trainer`` has zero side-effects until training actually starts.
    """

    def __init__(
        self,
        project: str = "uncategorized",
        name: str | None = None,
        config: dict[str, Any] | None = None,
        tags: list[str] | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__()
        self._project = project
        self._name = name
        self._config = config
        self._tags = tags
        self._run: Any = None  # openrunner.Run once initialized

    # -- Lightning Logger protocol ------------------------------------------

    @property
    def name(self) -> str:
        """Return the project name."""
        return self._project

    @property
    def version(self) -> str:
        """Return the run ID, or empty string if no run yet."""
        if self._run is not None:
            return self._run.id
        return ""

    @property
    def experiment(self) -> Any:
        """Return the underlying Run object (Lightning Logger protocol)."""
        return self._run

    # -- Core methods -------------------------------------------------------

    def _ensure_run(self) -> None:
        """Lazily initialize a run if one isn't active."""
        if self._run is None:
            self._run = openrunner.init(
                project=self._project,
                name=self._name,
                config=self._config,
                tags=self._tags,
            )

    def log_hyperparams(self, params: Any) -> None:
        """Log hyperparameters.

        Accepts a dict or a namespace-like object (e.g., ``argparse.Namespace``).
        Converts namespace objects to dicts via ``vars()``.
        """
        self._ensure_run()

        # Convert namespace-style objects to dict
        if hasattr(params, "__dict__") and not isinstance(params, dict):
            params = vars(params)

        openrunner.config.update(params)

    def log_metrics(
        self,
        metrics: dict[str, float],
        step: int | None = None,
    ) -> None:
        """Log training metrics to the active run."""
        self._ensure_run()
        openrunner.log(metrics, step=step)

    def finalize(self, status: str) -> None:
        """Finalize and close the run."""
        openrunner.finish()
