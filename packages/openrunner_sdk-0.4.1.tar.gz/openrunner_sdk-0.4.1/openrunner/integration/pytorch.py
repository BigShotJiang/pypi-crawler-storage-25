"""PyTorch integration for OpenRunner.

Provides a ``log_gradients`` utility that logs gradient norms for all
model parameters via ``openrunner.log()``.

Usage::

    from openrunner.integration.pytorch import log_gradients

    for batch in dataloader:
        loss = model(batch)
        loss.backward()
        log_gradients(model, step=step)
        optimizer.step()

Requires: ``pip install openrunner[pytorch]``
"""

from __future__ import annotations

try:
    import torch  # noqa: F401
except ImportError:
    raise ImportError(
        "PyTorch integration requires torch. "
        "Install with: pip install openrunner[pytorch]"
    )

import openrunner


def log_gradients(model: torch.nn.Module, step: int | None = None) -> None:
    """Log gradient norms for all model parameters.

    For each named parameter that has a gradient, logs the L2 norm
    as ``gradients/{name}``.  Parameters whose ``.grad`` is ``None``
    (e.g., frozen layers) are silently skipped.

    Args:
        model: A PyTorch ``nn.Module`` whose ``.backward()`` has been called.
        step: Optional explicit step value passed to ``openrunner.log()``.
    """
    for name, param in model.named_parameters():
        if param.grad is not None:
            norm = param.grad.norm().item()
            openrunner.log({f"gradients/{name}": norm}, step=step, commit=False)

    # Commit the step after all gradient norms have been logged.
    openrunner.log({}, step=step, commit=True)
