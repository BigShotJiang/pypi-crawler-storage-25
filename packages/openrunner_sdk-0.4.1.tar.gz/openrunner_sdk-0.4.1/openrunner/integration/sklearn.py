"""Scikit-learn integration for OpenRunner.

Provides utility functions to log scikit-learn model information,
classification reports, confusion matrices, and feature importances
to an active OpenRunner run.

Usage::

    from openrunner.integration.sklearn import (
        log_model,
        log_classification_report,
        log_confusion_matrix,
        log_feature_importance,
    )

    model = RandomForestClassifier().fit(X_train, y_train)
    log_model(model)
    log_classification_report(y_test, y_pred)
    log_confusion_matrix(y_test, y_pred)
    log_feature_importance(model, feature_names=["f1", "f2", "f3"])

Requires: ``pip install openrunner[sklearn]``
"""

from __future__ import annotations

from typing import Any, Sequence

try:
    import sklearn  # noqa: F401
except ImportError:
    raise ImportError(
        "Scikit-learn integration requires scikit-learn. "
        "Install with: pip install openrunner[sklearn]"
    )

import openrunner


def log_model(model: Any) -> None:
    """Log model hyperparameters via ``get_params()``.

    Logs all parameters returned by the model's ``get_params()`` method
    as a flat dict under ``model/`` prefix.

    Args:
        model: A fitted scikit-learn estimator.
    """
    if openrunner._active_run is None:
        return

    params = model.get_params()
    prefixed = {f"model/{k}": v for k, v in params.items() if _is_loggable(v)}
    if prefixed:
        openrunner.log(prefixed)


def log_classification_report(
    y_true: Sequence,
    y_pred: Sequence,
    labels: Sequence | None = None,
    target_names: Sequence[str] | None = None,
) -> None:
    """Log a classification report as a Table.

    Uses ``sklearn.metrics.classification_report`` to compute precision,
    recall, f1-score and support, then logs the result as an
    ``openrunner.Table``.

    Args:
        y_true: Ground-truth labels.
        y_pred: Predicted labels.
        labels: Optional list of label indices to include.
        target_names: Optional display names for each label.
    """
    if openrunner._active_run is None:
        return

    from sklearn.metrics import classification_report as _cr

    report = _cr(
        y_true,
        y_pred,
        labels=labels,
        target_names=target_names,
        output_dict=True,
    )

    columns = ["class", "precision", "recall", "f1-score", "support"]
    data: list[list[Any]] = []
    for cls_name, metrics in report.items():
        if isinstance(metrics, dict):
            data.append([
                cls_name,
                round(metrics.get("precision", 0), 4),
                round(metrics.get("recall", 0), 4),
                round(metrics.get("f1-score", 0), 4),
                metrics.get("support", 0),
            ])
        else:
            # scalar like "accuracy"
            data.append([cls_name, metrics, None, None, None])

    table = openrunner.Table(columns=columns, data=data)
    openrunner.log({"classification_report": table})


def log_confusion_matrix(
    y_true: Sequence,
    y_pred: Sequence,
    labels: Sequence | None = None,
    class_names: Sequence[str] | None = None,
) -> None:
    """Log a confusion matrix as an Image (matplotlib heatmap).

    Generates a heatmap using ``matplotlib`` and logs it as an
    ``openrunner.Image``.

    Args:
        y_true: Ground-truth labels.
        y_pred: Predicted labels.
        labels: Optional list of label values for ordering.
        class_names: Optional display names for the axes.
    """
    if openrunner._active_run is None:
        return

    from sklearn.metrics import confusion_matrix as _cm

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        raise ImportError(
            "log_confusion_matrix requires matplotlib. "
            "Install with: pip install matplotlib"
        )

    cm = _cm(y_true, y_pred, labels=labels)

    fig, ax = plt.subplots(figsize=(6, 5))
    im = ax.imshow(cm, interpolation="nearest", cmap="Blues")
    fig.colorbar(im, ax=ax)

    if class_names is not None:
        tick_marks = list(range(len(class_names)))
        ax.set_xticks(tick_marks)
        ax.set_xticklabels(class_names, rotation=45, ha="right")
        ax.set_yticks(tick_marks)
        ax.set_yticklabels(class_names)

    ax.set_xlabel("Predicted")
    ax.set_ylabel("True")
    ax.set_title("Confusion Matrix")
    fig.tight_layout()

    openrunner.log({"confusion_matrix": openrunner.Image(fig)})
    plt.close(fig)


def log_feature_importance(
    model: Any,
    feature_names: Sequence[str] | None = None,
) -> None:
    """Log feature importances as a Table.

    Extracts ``feature_importances_`` from the model and logs them
    as a sorted ``openrunner.Table`` (most important first).

    Args:
        model: A fitted scikit-learn estimator with
            ``feature_importances_`` attribute.
        feature_names: Optional list of feature names. If not
            provided, uses ``feature_0``, ``feature_1``, etc.
    """
    if openrunner._active_run is None:
        return

    if not hasattr(model, "feature_importances_"):
        return

    importances = model.feature_importances_
    if feature_names is None:
        feature_names = [f"feature_{i}" for i in range(len(importances))]

    # Sort by importance descending
    pairs = sorted(
        zip(feature_names, importances),
        key=lambda x: x[1],
        reverse=True,
    )

    columns = ["feature", "importance"]
    data = [[name, round(float(imp), 6)] for name, imp in pairs]

    table = openrunner.Table(columns=columns, data=data)
    openrunner.log({"feature_importance": table})


def _is_loggable(value: Any) -> bool:
    """Check if a value can be logged as a metric (numeric or string)."""
    return isinstance(value, (int, float, str, bool))
