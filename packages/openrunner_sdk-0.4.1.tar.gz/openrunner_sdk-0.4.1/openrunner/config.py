"""W&B-compatible Config object with dot notation and nested key flattening."""

from __future__ import annotations

from typing import Any, Iterator


class Config:
    """W&B-compatible config object with dict-style and dot notation access.

    Nested dicts are automatically flattened using dot notation keys:
        Config({"optimizer": {"lr": 0.01}})  ->  {"optimizer.lr": 0.01}

    Supports both ``config["lr"]`` and ``config.lr`` access patterns.
    """

    def __init__(self, initial: dict[str, Any] | None = None) -> None:
        object.__setattr__(self, "_data", {})
        if initial:
            self.update(initial)

    def update(self, d: dict[str, Any]) -> None:
        """Merge *d* into the config, flattening nested dicts."""
        flat = self._flatten(d)
        self._data.update(flat)

    @staticmethod
    def _flatten(d: dict[str, Any], prefix: str = "") -> dict[str, Any]:
        """Recursively flatten nested dicts with dot-separated keys."""
        items: dict[str, Any] = {}
        for k, v in d.items():
            key = f"{prefix}.{k}" if prefix else k
            if isinstance(v, dict):
                items.update(Config._flatten(v, key))
            else:
                items[key] = v
        return items

    # -- dict-style access ---------------------------------------------------

    def __getitem__(self, key: str) -> Any:
        return self._data[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self._data[key] = value

    def __contains__(self, key: object) -> bool:
        return key in self._data

    # -- dot notation access --------------------------------------------------

    def __getattr__(self, name: str) -> Any:
        try:
            return self._data[name]
        except KeyError:
            pass
        # Check for nested prefix (e.g., ``config.optimizer`` when keys like
        # ``optimizer.lr`` exist).
        prefix = f"{name}."
        nested = {
            k[len(prefix):]: v
            for k, v in self._data.items()
            if k.startswith(prefix)
        }
        if nested:
            return Config(nested)
        raise AttributeError(f"Config has no key '{name}'")

    def __setattr__(self, name: str, value: Any) -> None:
        self._data[name] = value

    # -- introspection --------------------------------------------------------

    def as_dict(self) -> dict[str, Any]:
        """Return a shallow copy of the flat config dict."""
        return dict(self._data)

    def keys(self) -> Iterator[str]:
        """Return config keys."""
        return self._data.keys()  # type: ignore[return-value]

    def values(self) -> Iterator[Any]:
        """Return config values."""
        return self._data.values()  # type: ignore[return-value]

    def items(self) -> Iterator[tuple[str, Any]]:
        """Return config (key, value) pairs."""
        return self._data.items()  # type: ignore[return-value]

    def __repr__(self) -> str:
        return f"Config({self._data!r})"
