"""Jupyter kernel manager with sandbox backends (nono / Docker / none).

The kernel subprocess is sandboxed, not the parent process.
- nono: wraps the kernel command with `nono run` (macOS/Linux)
- docker: runs kernel inside a container with volume mounts
- none: no sandboxing (development/testing only)
"""

import asyncio
import json
import os
import signal
import subprocess
import sys
import json
import tempfile
import logging

from jupyter_client import KernelManager

logger = logging.getLogger("safe_colab_cli.kernel")


class SandboxKernel:
    """Manages a Jupyter IPython kernel, optionally sandboxed."""

    def __init__(self):
        self._km = None
        self._kc = None
        self._docker_proc = None
        self._nono_proc = None
        self._nono_conn_file = None
        self._backend = "none"

    def pre_start_nono(self, env=None, data_dir=None, work_dir=None):
        """Start the nono subprocess SYNCHRONOUSLY, before asyncio runs.

        This MUST be called from synchronous code (before asyncio.run())
        because asyncio creates threads that prevent nono from forking.
        After calling this, use start(sandbox_backend='nono') to connect.
        """
        from .sandbox import build_nono_kernel_argv
        import socket
        import tempfile

        def _find_free_port():
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(("127.0.0.1", 0))
                return s.getsockname()[1]

        conn_info = {
            "transport": "tcp", "ip": "127.0.0.1",
            "shell_port": _find_free_port(), "iopub_port": _find_free_port(),
            "stdin_port": _find_free_port(), "control_port": _find_free_port(),
            "hb_port": _find_free_port(),
            "signature_scheme": "hmac-sha256", "key": os.urandom(16).hex(),
            "kernel_name": "python3",
        }

        conn_dir = tempfile.mkdtemp(prefix="safe-colab-kernel-")
        self._nono_conn_file = os.path.join(conn_dir, "kernel.json")
        with open(self._nono_conn_file, "w") as f:
            json.dump(conn_info, f)

        real_python = os.path.realpath(sys.executable)
        site_packages = [p for p in sys.path if "site-packages" in p]
        all_paths = site_packages + [p for p in sys.path if p and p not in site_packages]
        pythonpath = os.pathsep.join(all_paths)

        original_argv = [
            "/usr/bin/env", f"PYTHONPATH={pythonpath}",
            real_python, "-m", "ipykernel_launcher", "-f", self._nono_conn_file,
        ]

        nono_argv = build_nono_kernel_argv(
            original_argv=original_argv,
            data_dir=data_dir,
            work_dir=work_dir or os.getcwd(),
        )

        proc_env = os.environ.copy()
        if env:
            proc_env.update(env)
        kernel_cwd = os.path.realpath(os.path.abspath(work_dir or os.getcwd()))

        logger.info("Launching nono subprocess (pre-asyncio, single-threaded)...")
        self._nono_proc = subprocess.Popen(
            nono_argv,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=kernel_cwd,
            env=proc_env,
        )
        self._backend = "nono"
        logger.info(f"Nono subprocess started (PID {self._nono_proc.pid})")

    async def start(self, env=None, sandbox_backend="none", data_dir=None, work_dir=None):
        """Start the Jupyter kernel with the specified sandbox backend.

        Args:
            env: Extra environment variables for the kernel.
            sandbox_backend: 'nono', 'docker', or 'none'.
            data_dir: Read-only data directory (for sandbox config).
            work_dir: Read-write working directory (for sandbox config).
        """
        self._backend = sandbox_backend

        if sandbox_backend == "docker":
            await self._start_docker(env, data_dir, work_dir)
        elif sandbox_backend == "nono":
            await self._start_nono(env, data_dir, work_dir)
        else:
            await self._start_plain(env)

    async def _start_plain(self, env=None):
        """Start kernel without sandboxing."""
        self._km = KernelManager(kernel_name="python3")
        if env:
            self._km.extra_env = env
        self._km.start_kernel()
        self._kc = self._km.client()
        self._kc.start_channels()
        await asyncio.get_event_loop().run_in_executor(
            None, self._kc.wait_for_ready, 30
        )
        logger.info("IPython kernel started (no sandbox)")

    async def _start_nono(self, env=None, data_dir=None, work_dir=None):
        """Connect to an already-running nono subprocess.

        The nono process must be started BEFORE asyncio via pre_start_nono().
        If not already started, starts it here (may fail if asyncio created threads).
        """
        if not self._nono_proc or not self._nono_conn_file:
            # Not pre-started — try starting here (works if asyncio hasn't created threads)
            self.pre_start_nono(env=env, data_dir=data_dir, work_dir=work_dir)

        conn_file = self._nono_conn_file

        # Create KernelManager + client (ZMQ threads OK — nono already forked)
        self._km = KernelManager(kernel_name="python3")
        self._km.load_connection_file(conn_file)
        self._kc = self._km.client()
        self._kc.start_channels()

        try:
            await asyncio.get_event_loop().run_in_executor(
                None, self._kc.wait_for_ready, 60
            )
        except RuntimeError as e:
            stderr_output = ""
            if self._nono_proc:
                try:
                    self._nono_proc.terminate()
                    _, stderr_bytes = self._nono_proc.communicate(timeout=5)
                    stderr_output = stderr_bytes.decode("utf-8", errors="replace").strip()
                except Exception:
                    pass
            error_msg = f"Nono kernel died: {e}"
            if stderr_output:
                error_msg += f"\nnono stderr:\n{stderr_output}"
            logger.error(error_msg)
            raise RuntimeError(error_msg) from e
        logger.info("IPython kernel started (nono sandbox)")

    async def _start_docker(self, env=None, data_dir=None, work_dir=None):
        """Start kernel inside a Docker container.

        Strategy: Create a connection file on the host, mount it into Docker,
        run ipykernel inside Docker with --network host so ZMQ ports are shared,
        then connect from the host via the same connection file.
        """
        from .sandbox import build_docker_run_args, DEFAULT_DOCKER_IMAGE
        import json as json_mod

        # Create KernelManager to generate connection file with ports
        self._km = KernelManager(kernel_name="python3")
        self._km.write_connection_file()
        conn_file = self._km.connection_file
        logger.info(f"Connection file: {conn_file}")

        # Build docker command
        docker_cmd = build_docker_run_args(
            data_dir=data_dir,
            work_dir=work_dir or os.getcwd(),
            connection_file=conn_file,
        )

        # Add env vars
        if env:
            # Insert before the image name (which is second-to-last group)
            image_idx = None
            for i, arg in enumerate(docker_cmd):
                if arg == DEFAULT_DOCKER_IMAGE:
                    image_idx = i
                    break
            if image_idx:
                for k, v in env.items():
                    docker_cmd.insert(image_idx, f"{k}={v}")
                    docker_cmd.insert(image_idx, "-e")

        logger.info(f"Starting Docker kernel...")

        # Start Docker container in background
        self._docker_proc = subprocess.Popen(
            docker_cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        # Connect client to the kernel's ZMQ ports via the connection file
        self._kc = self._km.client()
        self._kc.start_channels()

        # Wait for kernel to be ready (Docker pull + startup is slower)
        await asyncio.get_event_loop().run_in_executor(
            None, self._kc.wait_for_ready, 120
        )
        logger.info("IPython kernel started (Docker sandbox)")

    async def execute(self, code: str, timeout: float = 120) -> dict:
        """Execute code and return results.

        Returns dict with keys: stdout, stderr, result, error, display_data
        """
        msg_id = self._kc.execute(code)
        return await asyncio.get_event_loop().run_in_executor(
            None, self._collect_output, msg_id, timeout
        )

    def _collect_output(self, msg_id: str, timeout: float) -> dict:
        """Collect all output messages for an execution request (blocking)."""
        stdout_parts = []
        stderr_parts = []
        result = None
        error = None
        display_data = []

        while True:
            try:
                msg = self._kc.get_iopub_msg(timeout=timeout)
            except Exception:
                break

            if msg["parent_header"].get("msg_id") != msg_id:
                continue

            msg_type = msg["msg_type"]
            content = msg["content"]

            if msg_type == "stream":
                if content["name"] == "stdout":
                    stdout_parts.append(content["text"])
                elif content["name"] == "stderr":
                    stderr_parts.append(content["text"])
            elif msg_type == "execute_result":
                result = content["data"].get("text/plain", "")
            elif msg_type == "display_data":
                display_data.append(content["data"])
            elif msg_type == "error":
                error = {
                    "ename": content["ename"],
                    "evalue": content["evalue"],
                    "traceback": content["traceback"],
                }
            elif msg_type == "status" and content["execution_state"] == "idle":
                break

        return {
            "stdout": "".join(stdout_parts),
            "stderr": "".join(stderr_parts),
            "result": result,
            "error": error,
            "display_data": display_data,
        }

    async def stop(self):
        """Shut down the kernel."""
        if self._kc:
            self._kc.stop_channels()
        if self._nono_proc:
            self._nono_proc.terminate()
            try:
                self._nono_proc.wait(timeout=5)
            except Exception:
                self._nono_proc.kill()
            self._nono_proc = None
        if self._docker_proc:
            container_name = f"safe-colab-kernel-{os.getpid()}"
            subprocess.run(
                ["docker", "stop", container_name],
                capture_output=True, timeout=10,
            )
            self._docker_proc.terminate()
            self._docker_proc = None
        if self._km:
            try:
                self._km.shutdown_kernel(now=True)
            except Exception as e:
                logger.warning(f"Kernel shutdown error: {e}")
        logger.info(f"Kernel stopped ({self._backend})")
