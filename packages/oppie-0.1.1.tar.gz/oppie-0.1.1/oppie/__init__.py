"""oppie — project management operations CLI."""

__version__ = '0.1.1'
