"""Market-data helpers."""
