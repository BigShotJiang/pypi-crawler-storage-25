"""Baseline strategies."""
