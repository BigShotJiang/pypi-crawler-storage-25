"""Report generation helpers."""
