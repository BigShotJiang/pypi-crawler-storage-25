"""Backtest engine and metrics."""
