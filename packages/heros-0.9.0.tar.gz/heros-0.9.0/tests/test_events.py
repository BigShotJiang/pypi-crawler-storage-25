import zenoh


def test_local_callback_on_LocalHERO(local_hero_device, local_method):
    local_hero_device.my_event.connect(local_method)
    local_hero_device.my_event("hello")
    local_method.assert_called_once_with("hello")


def test_local_callback_on_RemoteHERO(remote_hero_device, local_method):
    remote_hero_device.my_event.connect(local_method)
    remote_hero_device.my_event("hello")
    local_method.assert_called_once_with("hello")


def test_reliable_decorator(local_hero_device, local_method):
    assert local_hero_device.my_reliable_event1.publisher.reliability == zenoh.Reliability.RELIABLE
    assert local_hero_device.my_reliable_event1.publisher.congestion_control == zenoh.CongestionControl.BLOCK
    assert local_hero_device.my_reliable_event2.publisher.reliability == zenoh.Reliability.RELIABLE
    assert local_hero_device.my_reliable_event2.publisher.congestion_control == zenoh.CongestionControl.BLOCK
