from typing import Annotated

from nexo.types.string import OptStr
from nexo.types.uuid import OptUUID
from pydantic import BaseModel, Field


class UserUUID(BaseModel):
    user_uuid: Annotated[OptUUID, Field(None, description="User's UUID")] = None


class Original[T: OptStr](BaseModel):
    original: Annotated[T, Field(..., description="Original Transcript")]
