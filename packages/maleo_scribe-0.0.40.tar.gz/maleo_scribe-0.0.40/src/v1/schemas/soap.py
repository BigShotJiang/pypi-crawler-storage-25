from typing import Annotated

from nexo.types.string import OptStr
from pydantic import BaseModel, Field

from ...common.mixins import (
    ChiefComplaint,
    OptAdditionalComplaint,
    OptBodyMassIndex,
    OptChronology,
    OptConsumedMedication,
    OptDiastole,
    OptFactor,
    OptFamilyIllnessHistory,
    OptHabitActivityOccupation,
    OptHeartRate,
    OptHeight,
    OptLocation,
    OptOnset,
    OptOrganExaminationDetail,
    OptOtherInformation,
    OptOxygenSaturation,
    OptPainScale,
    OptPastIllnessHistory,
    OptRespirationRate,
    OptSystole,
    OptTemperature,
    OptWaistCircumference,
    OptWeight,
    Overall,
)


# ----- Subjective ----- #
class Subjective[T: OptStr](
    OptOtherInformation,
    OptConsumedMedication,
    OptHabitActivityOccupation,
    OptFamilyIllnessHistory,
    OptPastIllnessHistory,
    OptFactor,
    OptLocation,
    OptChronology,
    OptOnset,
    OptPainScale,
    OptAdditionalComplaint,
    ChiefComplaint[T],
):
    pass


# ----- Vital Sign ----- #
class VitalSign(
    OptOrganExaminationDetail,
    OptBodyMassIndex,
    OptWeight,
    OptHeight,
    OptWaistCircumference,
    OptOxygenSaturation,
    OptHeartRate,
    OptRespirationRate,
    OptTemperature,
    OptDiastole,
    OptSystole,
):
    pass


class VitalSignMixin(BaseModel):
    vital_sign: Annotated[VitalSign, Field(..., description="Vital Sign")]


# ----- Objective ----- #
class Objective[T: OptStr](
    OptOtherInformation,
    VitalSignMixin,
    Overall[T],
):
    pass


# ----- Assessment ----- #
class Assessment[T: OptStr](Overall[T]):
    pass


# ----- Plan ----- #
class Plan[T: OptStr](Overall[T]):
    pass


# ----- SOAP ----- #
class SOAP[S: OptStr, O: OptStr, A: OptStr, P: OptStr](BaseModel):
    subjective: Annotated[Subjective[S], Field(..., description="Subjective")]
    objective: Annotated[Objective[O], Field(..., description="Objective")]
    assessment: Annotated[Assessment[A], Field(..., description="Assessment")]
    plan: Annotated[Plan[P], Field(..., description="Plan")]


OptSOAP = SOAP | None


class SOAPMixin[T: OptSOAP](BaseModel):
    soap: Annotated[T, Field(..., description="SOAP")]
