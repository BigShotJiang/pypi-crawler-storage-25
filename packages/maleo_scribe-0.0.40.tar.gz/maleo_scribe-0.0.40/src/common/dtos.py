from typing import Annotated

from nexo.types.float import DoubleFloats
from pydantic import BaseModel, Field


class AudioMetadata(BaseModel):
    duration: Annotated[float, Field(..., description="Audio's Duration", ge=0.0)]
    size: Annotated[int, Field(..., description="Audio's Size", ge=0)]
    channels: Annotated[int, Field(..., description="Channels", ge=0)]
    frames: Annotated[int, Field(..., description="Frames", ge=0)]
    sample_rate: Annotated[int, Field(..., description="Sample Rate", ge=0)]
    sample_width: Annotated[int, Field(..., description="Sample Width", ge=0)]


class AudioMetadataMixin(BaseModel):
    audio_metadata: Annotated[AudioMetadata, Field(..., description="Audio's Metadata")]


class TranscriptionChunk(BaseModel):
    timestamp: Annotated[DoubleFloats, Field(..., description="Chunk Timestamp")]
    text: Annotated[str, Field(..., description="Chunk Text")]


class TranscriptionPipelineResponse(BaseModel):
    chunks: Annotated[
        list[TranscriptionChunk],
        Field(..., description="Transcription chunks", min_length=1),
    ]
    text: Annotated[str, Field(..., description="Transcription text")]


class TranscriptionMetadata(BaseModel):
    duration: Annotated[float, Field(..., description="Transcription Duration", ge=0.0)]
    pipeline_response: Annotated[
        TranscriptionPipelineResponse,
        Field(..., description="Transcription Pipeline Response"),
    ]


class TranscriptionMetadataMixin(BaseModel):
    transcription_metadata: Annotated[
        TranscriptionMetadata, Field(..., description="Transcription's Metadata")
    ]


class ProcessTranscriptPrompt(BaseModel):
    system: Annotated[str, Field(..., description="System Prompt")]
    user: Annotated[str, Field(..., description="User Prompt")]


class ProcessTranscriptMetadata[T](BaseModel):
    duration: Annotated[
        float, Field(..., description="Process Transcript Duration", ge=0.0)
    ]
    prompt: Annotated[
        ProcessTranscriptPrompt, Field(..., description="Process Transcript Prompt")
    ]
    response: Annotated[T, Field(..., description="Process Transcript Response")]


class ProcessTranscriptMetadataMixin[T](BaseModel):
    process_transcript_metadata: Annotated[
        ProcessTranscriptMetadata[T],
        Field(..., description="Process Transcript's Metadata"),
    ]
