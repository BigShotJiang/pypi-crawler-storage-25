from typing import Annotated

from nexo.types.string import OptStr
from pydantic import BaseModel, Field


class Transcript[T: OptStr](BaseModel):
    transcript: Annotated[T, Field(..., description="Transcript")]


class RawTranscript[T: OptStr](BaseModel):
    raw_transcript: Annotated[T, Field(..., description="Raw Transcript")]


class RefinedTranscript[T: OptStr](BaseModel):
    refined_transcript: Annotated[T, Field(..., description="Refined Transcript")]
