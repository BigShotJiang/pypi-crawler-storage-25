# luna-intelligence

LUNA — Developer activity intelligence. Monitor projects, enforce focus, generate AI session journals.

## Install

```bash
pip install luna-intelligence
```

## Requirements

- Python 3.8+
- LUNA daemon running locally (default: `http://localhost:3030`)
- `luna` CLI on PATH

## Usage

### Python API

```python
from luna import LunaClient

client = LunaClient()

# Query activity
events = client.events(limit=20)
stats  = client.stats()

# Get directive
action = client.next_action()
print(action.type)       # FOCUS | FINISH | EXECUTE
print(action.message)
print(action.directive)  # list of imperative steps

# Set intent
client.set_intent("Finish LUNA v8 journal engine")

# Generate journal
path = client.journal()  # triggers AI summary of last 6 hours
```

### CLI

```bash
luna-py status
luna-py next
luna-py events --limit 50
luna-py stats
luna-py intent "Ship CADMUS to Isaac"
luna-py journal
```
