from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional


@dataclass
class Event:
    id: int
    type: str
    action: str
    target: str
    project: str
    timestamp: int
    metadata: Optional[str] = None

    @property
    def time(self) -> datetime:
        return datetime.fromtimestamp(self.timestamp / 1000)


@dataclass
class Project:
    id: int
    name: str
    path: str
    status: str  # active | stale | archive
    last_active: int

    @property
    def last_active_time(self) -> datetime:
        return datetime.fromtimestamp(self.last_active / 1000)


@dataclass
class Stats:
    project: str
    count: int


@dataclass
class NextAction:
    type: str         # FOCUS | FINISH | EXECUTE
    message: str
    directive: List[str] = field(default_factory=list)
    suggestion: List[str] = field(default_factory=list)
