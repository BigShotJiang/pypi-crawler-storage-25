"""
LunaClient — connects to the LUNA daemon API (default: http://localhost:3030).

LUNA must be running locally (managed by pm2). This client wraps the REST
endpoints exposed by LUNA's Express server and also exposes the CLI commands
via subprocess for journal generation and directives.

Usage:
    from luna import LunaClient

    client = LunaClient()
    events = client.events(limit=10)
    action = client.next_action()
    client.log_event(project="my-repo", type="file", action="modified", target="src/main.py")
"""

import subprocess
import json
from typing import List, Optional

try:
    import requests
    _has_requests = True
except ImportError:
    _has_requests = False

from .models import Event, Project, Stats, NextAction


class LunaClient:
    """
    Python interface to a running LUNA daemon.

    Args:
        host: LUNA API host (default: localhost)
        port: LUNA API port (default: 3030)
        luna_bin: Path to the `luna` CLI binary (default: "luna" on PATH)
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 3030,
        luna_bin: str = "luna",
    ):
        self.base_url = f"http://{host}:{port}"
        self.luna_bin = luna_bin

        if not _has_requests:
            raise ImportError(
                "The 'requests' package is required. Install it with: pip install requests"
            )

    # ── REST API ──────────────────────────────────────────────────────────────

    def events(self, limit: int = 50) -> List[Event]:
        """Return the most recent activity events logged by LUNA."""
        resp = requests.get(f"{self.base_url}/events", params={"limit": limit})
        resp.raise_for_status()
        return [Event(**e) for e in resp.json()]

    def stats(self) -> List[Stats]:
        """Return per-project event counts for the last hour."""
        resp = requests.get(f"{self.base_url}/stats")
        resp.raise_for_status()
        return [Stats(**s) for s in resp.json()]

    def log_event(
        self,
        project: str,
        type: str,
        action: str,
        target: str,
        metadata: Optional[dict] = None,
    ) -> None:
        """Push a custom event into LUNA's activity log."""
        payload = {
            "project": project,
            "type": type,
            "action": action,
            "target": target,
            "timestamp": _now_ms(),
            "metadata": json.dumps(metadata) if metadata else None,
        }
        resp = requests.post(f"{self.base_url}/event", json=payload)
        resp.raise_for_status()

    # ── CLI commands (subprocess) ─────────────────────────────────────────────

    def next_action(self) -> NextAction:
        """
        Get LUNA's current directive: FOCUS / FINISH / EXECUTE.
        Parses the luna CLI output — returns a structured NextAction.
        """
        raw = self._run_cli("next")
        return _parse_next_action(raw)

    def status(self) -> dict:
        """Return current project, last activity, and intent as a dict."""
        raw = self._run_cli("status")
        return _parse_status(raw)

    def journal(self) -> str:
        """
        Trigger AI journal generation for the last 6 hours of activity.
        Returns the path to the generated markdown file.
        """
        raw = self._run_cli("journal")
        for line in raw.splitlines():
            if "Journal created:" in line:
                return line.split("Journal created:")[-1].strip()
        return raw.strip()

    def set_intent(self, text: str) -> None:
        """Set the current focus intent."""
        self._run_cli("intent", text)

    def projects(self) -> List[dict]:
        """Return raw project rows from LUNA's database."""
        raw = self._run_cli_json("projects")
        return raw if isinstance(raw, list) else []

    # ── Internal ──────────────────────────────────────────────────────────────

    def _run_cli(self, *args: str) -> str:
        result = subprocess.run(
            [self.luna_bin, *args],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0 and result.stderr:
            raise RuntimeError(f"LUNA CLI error: {result.stderr.strip()}")
        return result.stdout

    def _run_cli_json(self, *args: str) -> object:
        """Run CLI command and attempt JSON parse of output."""
        raw = self._run_cli(*args)
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return raw


# ── Parsers ───────────────────────────────────────────────────────────────────

def _parse_next_action(raw: str) -> NextAction:
    lines = [l.strip() for l in raw.splitlines() if l.strip()]
    action_type = "EXECUTE"
    message_lines = []
    directives = []
    suggestions = []
    in_directive = False
    in_suggestion = False

    for line in lines:
        if line.startswith("→"):
            directives.append(line.lstrip("→").strip())
            in_directive = True
            in_suggestion = False
        elif line.startswith("-"):
            suggestions.append(line.lstrip("-").strip())
            in_suggestion = True
            in_directive = False
        elif line in ("DO THIS:", "Context:"):
            in_directive = line == "DO THIS:"
            in_suggestion = line == "Context:"
        elif "FOCUS" in line:
            action_type = "FOCUS"
        elif "FINISH" in line:
            action_type = "FINISH"
        elif not in_directive and not in_suggestion and line not in ("🧠 LUNA DIRECTIVE",):
            message_lines.append(line)

    # Infer type from message if not caught above
    message = " ".join(message_lines).strip()
    if "split across" in message:
        action_type = "FOCUS"
    elif "unfinished" in message.lower():
        action_type = "FINISH"
    elif "focused" in message.lower():
        action_type = "EXECUTE"

    return NextAction(
        type=action_type,
        message=message,
        directive=directives,
        suggestion=suggestions,
    )


def _parse_status(raw: str) -> dict:
    result = {}
    for line in raw.splitlines():
        line = line.strip()
        if line.startswith("Project:"):
            result["project"] = line.split(":", 1)[1].strip()
        elif line.startswith("Last Activity:"):
            result["last_activity"] = line.split(":", 1)[1].strip()
        elif line.startswith("Intent:"):
            result["intent"] = line.split(":", 1)[1].strip()
    return result


def _now_ms() -> int:
    import time
    return int(time.time() * 1000)
