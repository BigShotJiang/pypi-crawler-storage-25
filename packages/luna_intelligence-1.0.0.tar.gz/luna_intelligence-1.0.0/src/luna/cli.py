"""luna-py CLI — thin wrapper exposing LUNA commands from Python."""

import argparse
import json
import sys

from .client import LunaClient


def main():
    parser = argparse.ArgumentParser(
        prog="luna-py",
        description="LUNA Intelligence — Python CLI",
    )
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("status", help="Current project and intent")
    sub.add_parser("next", help="Get LUNA directive (FOCUS / FINISH / EXECUTE)")
    sub.add_parser("journal", help="Generate AI session journal")
    sub.add_parser("stats", help="Per-project event counts (last hour)")

    events_p = sub.add_parser("events", help="Recent activity events")
    events_p.add_argument("--limit", type=int, default=20)

    intent_p = sub.add_parser("intent", help="Set focus intent")
    intent_p.add_argument("text", help="Intent text")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(0)

    client = LunaClient()

    if args.command == "status":
        s = client.status()
        print(f"\nProject:       {s.get('project', 'none')}")
        print(f"Last Activity: {s.get('last_activity', 'none')}")
        print(f"Intent:        {s.get('intent', 'none')}\n")

    elif args.command == "next":
        action = client.next_action()
        print(f"\n[{action.type}] {action.message}")
        if action.directive:
            print("\nDO THIS:")
            for d in action.directive:
                print(f"  → {d}")
        if action.suggestion:
            print("\nContext:")
            for s in action.suggestion:
                print(f"  - {s}")
        print()

    elif args.command == "journal":
        path = client.journal()
        print(f"Journal: {path}")

    elif args.command == "stats":
        stats = client.stats()
        for s in stats:
            print(f"  {s.project:<40} {s.count} events")

    elif args.command == "events":
        events = client.events(limit=args.limit)
        for e in events:
            print(f"  {e.time.strftime('%H:%M:%S')}  {e.project:<30}  {e.type}:{e.action}  {e.target}")

    elif args.command == "intent":
        client.set_intent(args.text)
        print(f"Intent set: {args.text}")
