# Copyright 2026 Scaleway, Aqora, Quantum Commons
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import json
import zlib
import base64

from typing import Dict


def zlib_to_str(e: str) -> str:
    base64_payload = e.encode("ascii")
    compressed_payload = base64.b64decode(base64_payload)
    json_bytes_payload = zlib.decompress(compressed_payload)
    string_payload = json_bytes_payload.decode()

    return string_payload


def zlib_to_dict(e: str) -> Dict:
    s = zlib_to_str(e)
    dict = json.loads(s)

    return dict
