Read AGENTS.md before doing anything.
