#![cfg_attr(not(feature = "std"), no_std)]

use core::fmt;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum TimecodeError {
    InvalidFormat,
    InvalidHours(u8),
    InvalidMinutes(u8),
    InvalidSeconds(u8),
    InvalidFrames(u8, u8),
    InvalidDropFrameRate,
    MismatchedRates,
}

impl fmt::Display for TimecodeError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::InvalidFormat => write!(f, "invalid timecode format"),
            Self::InvalidHours(h) => write!(f, "hours {h} out of range 0-23"),
            Self::InvalidMinutes(m) => write!(f, "minutes {m} out of range 0-59"),
            Self::InvalidSeconds(s) => write!(f, "seconds {s} out of range 0-59"),
            Self::InvalidFrames(fr, max) => {
                write!(f, "frames {fr} out of range 0-{}", max - 1)
            }
            Self::InvalidDropFrameRate => {
                write!(f, "drop-frame only valid for 29.97 and 59.94 fps")
            }
            Self::MismatchedRates => write!(f, "cannot operate on timecodes with different rates"),
        }
    }
}

#[cfg(feature = "std")]
impl std::error::Error for TimecodeError {}
