#![allow(non_camel_case_types)]

use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use ::talw_timecode as tc_core;
use tc_core::{FrameRate as CoreRate, TimecodeError};

#[pyclass(eq, hash, frozen)]
#[derive(Clone, Copy, PartialEq, Eq, Hash)]
pub enum FrameRate {
    FPS_23_976,
    FPS_24,
    FPS_25,
    FPS_29_97_DF,
    FPS_29_97_NDF,
    FPS_30,
    FPS_48,
    FPS_50,
    FPS_59_94_DF,
    FPS_59_94_NDF,
    FPS_60,
}

impl FrameRate {
    fn to_core(self) -> CoreRate {
        match self {
            Self::FPS_23_976 => CoreRate::Fps23_976,
            Self::FPS_24 => CoreRate::Fps24,
            Self::FPS_25 => CoreRate::Fps25,
            Self::FPS_29_97_DF => CoreRate::Fps29_97Df,
            Self::FPS_29_97_NDF => CoreRate::Fps29_97Ndf,
            Self::FPS_30 => CoreRate::Fps30,
            Self::FPS_48 => CoreRate::Fps48,
            Self::FPS_50 => CoreRate::Fps50,
            Self::FPS_59_94_DF => CoreRate::Fps59_94Df,
            Self::FPS_59_94_NDF => CoreRate::Fps59_94Ndf,
            Self::FPS_60 => CoreRate::Fps60,
        }
    }
}

#[pymethods]
impl FrameRate {
    #[staticmethod]
    fn from_float(fps: f64, drop_frame: bool) -> PyResult<Self> {
        let rate = CoreRate::from_float(fps, drop_frame)
            .ok_or_else(|| PyValueError::new_err(format!("unsupported frame rate: {fps}")))?;
        Ok(match rate {
            CoreRate::Fps23_976 => Self::FPS_23_976,
            CoreRate::Fps24 => Self::FPS_24,
            CoreRate::Fps25 => Self::FPS_25,
            CoreRate::Fps29_97Df => Self::FPS_29_97_DF,
            CoreRate::Fps29_97Ndf => Self::FPS_29_97_NDF,
            CoreRate::Fps30 => Self::FPS_30,
            CoreRate::Fps48 => Self::FPS_48,
            CoreRate::Fps50 => Self::FPS_50,
            CoreRate::Fps59_94Df => Self::FPS_59_94_DF,
            CoreRate::Fps59_94Ndf => Self::FPS_59_94_NDF,
            CoreRate::Fps60 => Self::FPS_60,
        })
    }

    fn __repr__(&self) -> String {
        format!("FrameRate.{}", match self {
            Self::FPS_23_976 => "FPS_23_976",
            Self::FPS_24 => "FPS_24",
            Self::FPS_25 => "FPS_25",
            Self::FPS_29_97_DF => "FPS_29_97_DF",
            Self::FPS_29_97_NDF => "FPS_29_97_NDF",
            Self::FPS_30 => "FPS_30",
            Self::FPS_48 => "FPS_48",
            Self::FPS_50 => "FPS_50",
            Self::FPS_59_94_DF => "FPS_59_94_DF",
            Self::FPS_59_94_NDF => "FPS_59_94_NDF",
            Self::FPS_60 => "FPS_60",
        })
    }
}

fn tc_err(e: TimecodeError) -> PyErr {
    PyValueError::new_err(e.to_string())
}

#[pyclass(frozen)]
#[derive(Clone)]
pub struct Timecode {
    inner: tc_core::Timecode,
    rate_py: FrameRate,
}

#[pymethods]
impl Timecode {
    #[new]
    fn py_new(input: &str, rate: FrameRate) -> PyResult<Self> {
        let inner = tc_core::Timecode::parse(input, rate.to_core()).map_err(tc_err)?;
        Ok(Self { inner, rate_py: rate })
    }

    #[staticmethod]
    fn from_frames(frames: i64, rate: FrameRate) -> Self {
        Self {
            inner: tc_core::Timecode::from_frames(frames, rate.to_core()),
            rate_py: rate,
        }
    }

    #[staticmethod]
    fn from_seconds(seconds: f64, rate: FrameRate) -> Self {
        Self {
            inner: tc_core::Timecode::from_seconds(seconds, rate.to_core()),
            rate_py: rate,
        }
    }

    #[staticmethod]
    fn from_milliseconds(ms: f64, rate: FrameRate) -> Self {
        Self {
            inner: tc_core::Timecode::from_milliseconds(ms, rate.to_core()),
            rate_py: rate,
        }
    }

    #[staticmethod]
    fn validate(input: &str, rate: FrameRate) -> bool {
        tc_core::Timecode::validate(input, rate.to_core())
    }

    #[getter]
    fn total_frames(&self) -> i64 {
        self.inner.total_frames()
    }

    #[getter]
    fn rate(&self) -> FrameRate {
        self.rate_py
    }

    #[getter]
    fn hours(&self) -> u8 {
        self.inner.hours()
    }

    #[getter]
    fn minutes(&self) -> u8 {
        self.inner.minutes()
    }

    #[getter]
    fn seconds(&self) -> u8 {
        self.inner.seconds()
    }

    #[getter]
    fn frames(&self) -> u8 {
        self.inner.frames()
    }

    #[getter]
    fn is_drop_frame(&self) -> bool {
        self.inner.rate().is_drop_frame()
    }

    fn to_seconds(&self) -> f64 {
        self.inner.to_seconds()
    }

    fn to_milliseconds(&self) -> f64 {
        self.inner.to_milliseconds()
    }

    fn convert_to(&self, rate: FrameRate) -> Self {
        Self {
            inner: self.inner.convert_to(rate.to_core()),
            rate_py: rate,
        }
    }

    fn __str__(&self) -> String {
        self.inner.to_string()
    }

    fn __repr__(&self) -> String {
        format!("Timecode('{}', {})", self.inner, self.rate_py.__repr__())
    }

    fn __add__(&self, frames: i64) -> Self {
        Self {
            inner: self.inner + frames,
            rate_py: self.rate_py,
        }
    }

    fn __sub__(&self, other: &Timecode) -> PyResult<i64> {
        self.inner.frame_diff(&other.inner).map_err(tc_err)
    }

    fn __eq__(&self, other: &Timecode) -> bool {
        self.inner == other.inner
    }

    fn __lt__(&self, other: &Timecode) -> PyResult<bool> {
        match self.inner.partial_cmp(&other.inner) {
            Some(ord) => Ok(ord == std::cmp::Ordering::Less),
            None => Err(PyValueError::new_err("cannot compare timecodes with different rates")),
        }
    }

    fn __le__(&self, other: &Timecode) -> PyResult<bool> {
        match self.inner.partial_cmp(&other.inner) {
            Some(ord) => Ok(ord != std::cmp::Ordering::Greater),
            None => Err(PyValueError::new_err("cannot compare timecodes with different rates")),
        }
    }

    fn __hash__(&self) -> u64 {
        use std::hash::{Hash, Hasher};
        let mut hasher = std::collections::hash_map::DefaultHasher::new();
        self.inner.hash(&mut hasher);
        hasher.finish()
    }
}

#[pyclass(frozen)]
#[derive(Clone)]
pub struct TimeRange {
    inner: tc_core::TimeRange,
}

#[pymethods]
impl TimeRange {
    #[new]
    fn py_new(start: &Timecode, duration_frames: i64) -> Self {
        Self {
            inner: tc_core::TimeRange::new(start.inner, duration_frames),
        }
    }

    #[staticmethod]
    fn from_start_end(start: &Timecode, end: &Timecode) -> PyResult<Self> {
        Ok(Self {
            inner: tc_core::TimeRange::from_start_end(start.inner, end.inner).map_err(tc_err)?,
        })
    }

    fn start(&self) -> Timecode {
        let s = self.inner.start();
        Timecode {
            inner: s,
            rate_py: rate_to_py(s.rate()),
        }
    }

    fn end(&self) -> Timecode {
        let e = self.inner.end();
        Timecode {
            inner: e,
            rate_py: rate_to_py(e.rate()),
        }
    }

    fn duration_frames(&self) -> i64 {
        self.inner.duration_frames()
    }

    fn contains(&self, tc: &Timecode) -> bool {
        self.inner.contains(tc.inner)
    }

    fn overlaps(&self, other: &TimeRange) -> bool {
        self.inner.overlaps(&other.inner)
    }

    fn __repr__(&self) -> String {
        format!(
            "TimeRange({} -> {}, {} frames)",
            self.inner.start(),
            self.inner.end(),
            self.inner.duration_frames()
        )
    }
}

fn rate_to_py(rate: CoreRate) -> FrameRate {
    match rate {
        CoreRate::Fps23_976 => FrameRate::FPS_23_976,
        CoreRate::Fps24 => FrameRate::FPS_24,
        CoreRate::Fps25 => FrameRate::FPS_25,
        CoreRate::Fps29_97Df => FrameRate::FPS_29_97_DF,
        CoreRate::Fps29_97Ndf => FrameRate::FPS_29_97_NDF,
        CoreRate::Fps30 => FrameRate::FPS_30,
        CoreRate::Fps48 => FrameRate::FPS_48,
        CoreRate::Fps50 => FrameRate::FPS_50,
        CoreRate::Fps59_94Df => FrameRate::FPS_59_94_DF,
        CoreRate::Fps59_94Ndf => FrameRate::FPS_59_94_NDF,
        CoreRate::Fps60 => FrameRate::FPS_60,
    }
}

#[pymodule]
fn talw_timecode(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<FrameRate>()?;
    m.add_class::<Timecode>()?;
    m.add_class::<TimeRange>()?;
    Ok(())
}
