"""Built-in Hive demos."""
