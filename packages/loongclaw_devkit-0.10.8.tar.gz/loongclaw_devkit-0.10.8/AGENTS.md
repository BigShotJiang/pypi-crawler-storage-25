# LoongClaw DevKit — AI 工作区规范

> 本文件是给 AI 看的元信息。开发者请看 [README.md](./README.md)。

## 仓库结构

- `README.md` — **唯一事实源**：开发者教程、PyPI 页、以及 `create_mcp_project`
  生成的用户项目 `AGENTS.md` 内容全部读这一份。改文档只改这里。
  打 wheel 时 hatchling `force-include` 自动复制一份到包内供运行时读。
- `src/loongclaw_devkit/server.py` — MCP server 入口（注册给 AI 的工具）
- `src/loongclaw_devkit/publish.py` — 发布脚本（随包分发）
- `src/loongclaw_devkit/templates/` — 项目脚手架模板（`server_template.py` / `requirements_template.txt`；
  AGENTS.md 不再是这里的模板，改从 README 运行时读）
- `publish.py` — symlink → `src/loongclaw_devkit/publish.py`（向后兼容）

## 开发命令

```bash
# 本地测试 MCP server
python -m loongclaw_devkit

# 构建 wheel
python -m build --wheel

# 发布到 PyPI
twine upload dist/*
```

## 品牌

统一使用 `loongclaw` / `LoongClaw`，禁止出现 `openclaw`。

## 文档规范

- **唯一开发者文档**：[README.md](./README.md)。新功能/工具/参数的说明**只写在这里**
- AI 调用工具的完整行为说明见 README §3；manifest 字段见 README §4
- 禁止再新建独立的"开发指南"文件造成信息重复
## 修改 devkit 行为前的自检清单

任何 `src/loongclaw_devkit/**/*.py` 改动如果会让用户：

- [ ] 看到不同的错误信息 / 不同的命令行输出
- [ ] 撞上新的限制（体积、超时、字段格式、阈值）
- [ ] 享受新的自动行为（自动剥 BOM、自动注入字段、自动重试）
- [ ] 被强制要求新的命名/格式约定（如 FastMCP 实例必须名 `mcp`）
- [ ] 碰上新的白名单门槛（如 `usesPlatformLlm`）

任一勾选 → **同 commit 必须更新 README.md**。
违反 = “我们知道、用户不知道”，是 CLAUDE.md「用户可感知能力的文档同步铁律」一票否决项。

release.sh 不会自动检（机器识别不了“用户可感知”），依赖你和 AI 手动扫。
