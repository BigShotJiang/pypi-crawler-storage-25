# LoongClaw DevKit DEVLOG

## 2026-04-27 [Perf+Quality] 加密大幅加速 + staging 烟雾测试 + --dry-run (v0.10.6)

### 现象（xhs-zidonghuoke 工单）

> 「为什么这个小红书 MCP 呀，每次发版的时候都要花非常非常久的时间」

xhs-zidonghuoke 一次发版要 ~15 分钟，等不及。客户端用户安装也很慢但那是**网络下载 + pip install 重型依赖**（opencv 80MB / pandas 50MB / streamlit / playwright），是另一条独立链路，本次不动。

### 三问根因

1. **症状层**：发版从开始到上传走完要 15 分钟
2. **机制层**：实测 xhs 56 个 .py 文件需要 Cython 加密。旧版本是 `for f in to_encrypt: subprocess.run([sys.executable, _setup_tmp.py, build_ext, --inplace])`——**每个文件单独冷启动一个 Python 子进程**（每次 1-2s 启动开销，加 setuptools/Cython 加载）+ **C 编译串行**
3. **根因层**：批量文件处理走逐个子进程是反模式。Cython 的 `cythonize(files, nthreads=N)` 本身支持批量并行翻译，setuptools 的 `build_ext -jN` 支持 C 编译并行——一次进程启动就能编译全部

举一反三：在 xhs `.mcpignore` 上用 pathspec 实测后发现，虽然 39 个测试文件已正确排除，但还有 4 个文件应该排除而没排：
- `erchuang/scripts/setup_feishu.py`（一次性配置脚本，MCP 主链不调用）
- `shuju/sync_to_cloud.py` / `sync_to_pg.py` / `gen_template.py`（BACKLOG B-032 已废弃）

更深一层举一反三：devkit 没有"看包内容"的预览能力 → 开发者只能上传后才知道 .mcpignore 配错 → 同样问题在新项目会重复出现。

### 三处修复

**Fix A — 批量并行编译**（核心，提速 ~5x）

```python
# 旧（v0.10.5 及以前）：56 次冷启动 × 1-2s = 90-110s 启动开销 + 串行 C 编译
for f in to_encrypt:
    setup_file.write_text("cythonize('{module_name}.pyx', ...)")
    subprocess.run([sys.executable, setup_file, "build_ext", "--inplace"], cwd=work_dir)

# 新（v0.10.6）：1 次冷启动 + cythonize 多线程 + C 编译多进程
nthreads = max(1, (os.cpu_count() or 1))
setup_code = (
    "from Cython.Build import cythonize\n"
    f"setup(ext_modules=cythonize({pyx_paths!r}, nthreads={nthreads}, ...))"
)
subprocess.run([sys.executable, setup_file, "build_ext", "--inplace", f"-j{nthreads}"],
               cwd=str(staging_dir))
```

实测 macOS M1 8 核 + xhs 56 文件：~15min → ~3min。Windows 提升预计更大（进程启动比 Unix 慢 2-3x）。

**Fix B — `.mcpignore` 补 4 行 + staging 烟雾测试**

xhs 文件改 4 行（见上）。devkit 加 `_smoke_test_staging(staging_dir)`：
1. `python -m compileall -q staging_dir`（语法检查所有明文 .py）
2. `python -c "import server"` 子进程在 staging 内（可能加载加密 .so 入口壳）

`compileall` 失败 → 阻断（语法损坏不可洗白）；`import server` `ModuleNotFoundError` → ⚠ warn 不阻断（开发机里依赖未装属正常，云端 pip install 会装上）；其他 import 错误（如顶层 raise / 模块级硬编码错配）→ 阻断。

**Fix D — `--dry-run` 预览模式**

`publish.py --auto --dry-run`：跑完加密 + 打包 + 烟雾测试 → 打印 zip 内全部文件列表（每条 🔒/📄/📦 + 大小）→ 删 zip → 短路（不 manifest、不 upload、不 save_config）。开发者能在第一次发版前确认包内容。

### 被否方案 + 为什么否

| 方案 | 否决理由 |
|---|---|
| **C — 给 duanju-mcp 也补 .mcpignore**（举一反三横向扩散） | 用户明确"现在不需要管"，由用户负责该项目维护节奏。本次只做 xhs |
| **A 用 multiprocessing.Pool 替代 cythonize(nthreads)** | cythonize 内部有更精细的依赖管理（pyx → c → so 三阶段），Pool 起多个独立进程跑 setup() 反而增加启动开销。`nthreads` 是 Cython 官方推荐路径 |
| **烟雾测试 ModuleNotFoundError 也阻断** | 开发机不装运行时依赖是普遍场景（user 的电脑不是 PyPI 镜像），强制阻断会让所有人的发版都挂在烟雾测试 → 第一反应是绕过它 = 安全网失效。妥协：精度换零误报，BACKLOG 后续做 ast 静态扫准确区分"被 mcpignore 排掉的本地模块"vs"未装的 PyPI 包" |
| **--dry-run 不删 zip（保留供检查）** | 残留 project.zip 容易被误以为是真发版产物（xhs 的 release.ps1 就有"看到 zip 就上传"的逻辑可能性）。删掉 = 状态干净 |
| **--dry-run 跳过加密只列 .mcpignore 过滤结果** | 速度更快但失真——pip install 后某 .py 才会被生成（如自动 codegen）；只列规则结果看不到加密 .so 是否真的成功落地 |

### 副作用

- **生效需 winbox `uv tool upgrade loongclaw-devkit` 到 0.10.6**（xhs release.ps1 用 PyPI 装的版本，不是仓库源码）
- 烟雾测试增加 ~5-10s（compileall 编译所有 .py + 一次 import）。相对 15min → 3min 的主路径节省可忽略
- `cythonize(nthreads=N)` + `build_ext -jN` 在 1-2 核机器上没收益但不会变慢（max(1, cpu_count())）
- 批量编译的 stderr 是合并的——某个 .pyx 报错时定位精度由 cython 自己保证（输出包含 `xxx.pyx:行号:列号`），实测不损失定位能力

### 经验沉淀

1. **批量子进程 = 反模式**：任何 "for X in items: subprocess.run(...)" 都该先问"这件事的 SDK/库本身能否一次完成"。Cython/setuptools/pip 几乎所有批量工具都有 `nthreads` / `-j` 选项
2. **预览模式是发版工具的必备**：发版是高代价操作（编译 + 打包 + 上传 + 改 PyPI/git tag）— 没有 dry-run 的发版工具会让所有"如果配错了怎么办"的恐惧最终演变成"上传后才发现"事故
3. **烟雾测试的精度妥协要在文档明示**：「为什么这个 warn 不阻断」必须写在 README 让用户理解，否则下次踩到"`.mcpignore` 误排除关键模块"还是会怪安全网没拦住

---

## 2026-04-27 [Bug] generate_manifest 下游白名单 + 3 个独立修复 (v0.10.5)


### 现象（xhs-zidonghuoke 工单 + 自我复盘）

xhs-zidonghuoke 升级到 v0.10.4 后用 7 个工作流 workaround 才能勉强发版：

1. `.publish.json` 写 `configFields` / `env` / `postInstallCommands` / `replaces` / `companionSkill` 全部被丢，云端 manifest 不含
2. `--json-output` 失败但 `$LASTEXITCODE = 0`，CI 假发版后还在推 git tag
3. Windows 装 v2rayN/Clash 后 `requests.post()` 必现 `SSLEOFError(UNEXPECTED_EOF_WHILE_READING)`
4. `run()` 的 `finally: shutil.rmtree(staging_dir)` 阻碍 upload 失败后重传（Cython 编译 5-15min）
5. `--json-output` 模式 stdout 既有进度也有最终 JSON，PowerShell `ConvertFrom-Json` 直接挂
6. PS5.1 默认 cp936 → emoji/中文乱码
7. 缺合法的 manifest 后处理扩展点，被迫 monkey-patch `generate_manifest`

### 真根因（坑 1，最严重）

**v0.10.4 修了上游白名单但下游 generate_manifest 还有同模式白名单。**

v0.10.4 改了 `main()`：`config = dict(saved)` + setdefault → `config` 字段齐全。但 `generate_manifest()` (L878 manifest dict 字面量) 是**第二道独立白名单**：

```python
manifest: dict = {
    "id": config["id"], "name": ..., "description": ..., "version": ..., "author": ..., "icon": ..., "runtime": ...,
    "files": files_map,
    "env": {},                       # ← 硬编码，无视 config["env"]
    "configFields": config_fields,   # ← config_fields 是扫 server.py 源码生成的
    "sourceArchive": "project.zip",
}
# postInstallCommands key 完全不存在
# replaces / companionSkill 也完全不存在 ← 审查时发现的额外漏网
```

config 进来字段全了，但组装 manifest 时 5 个字段都被丢了一次（其中 replaces/companionSkill 是发版前自审查时新发现的——客户端 mcp-store-page.tsx L453 真的读 companionSkill 显示「配套技能」UI，buildServerConfig 读 replaces 写到 mcp-servers.json 用于压制内置工具组）。**和 v0.10.4 同根因，一并治本**。

### 三问根因 / 举一反三失败的复盘

**v0.10.4 我做了什么 / 没做什么：**

| 步骤 | 做了 | 没做 |
|---|---|---|
| 修 main() 白名单 | ✓ Plan B `dict(saved)` | — |
| 写测试 | ✓ e2e 验证 main() 输出 | ✗ 没验证 manifest 含字段 |
| 举一反三 | ✗ | **应当 grep `manifest: dict = \|manifest\["` 找下游同模式白名单** |
| user memory | ✓ 写了 DK_PUB3 "未来新增字段都自动支持" | **这话错了** ——只覆盖 main() |

**警报词命中（事后回看）**：v0.10.4 DEVLOG 写「未来新增字段都自动支持」——这种**绝对化承诺**本身就是警报词。pipeline 越长（main → run → generate_manifest → upload）漏网概率越高，没人能在不 grep 全 pipeline 的情况下做这种承诺。

**举一反三铁律明确说**：「修完 bug 后必问：这个错误模式还会出现在哪里？立即 grep 同模式」——v0.10.4 我没做。

### v0.10.5 修复

**坑 1（治本，同 v0.10.4 Plan B 思路）**：

```python
# generate_manifest（v0.10.5）
user_config_fields = config.get("configFields")
if isinstance(user_config_fields, list) and user_config_fields:
    config_fields = user_config_fields  # 优先用户显式声明
else:
    config_fields = []  # 兜底：扫 server.py 自动生成
    # ... regex scan ...

manifest = {
    ...
    "env": dict(config.get("env") or {}),
    "configFields": config_fields,
    ...
}
post_install = config.get("postInstallCommands")
if isinstance(post_install, list) and post_install:
    manifest["postInstallCommands"] = list(post_install)
```

**坑 2（Fail Fast）**：

```python
# main() 末尾
result = run(config, project_dir, json_output)
if isinstance(result, dict) and result.get("status") != "success":
    sys.exit(1)
```

**坑 3（Session.trust_env=False）**：

```python
session = requests.Session()
session.trust_env = False
resp = session.post(url, data=encoder, headers=headers, timeout=(10, None))
```

upload 路径 + `fetch_upload_limit_mb()` 两处都用 Session。**WHY**：requests 默认 trust_env=True 会读 winhttp 注册表里 v2rayN/Clash 的本机代理，对 HTTPS MITM 拆包导致 SSLEOFError。devkit 上传走 HTTPS 直连云端，绝不需要走系统代理。

**坑 6（utf-8 reconfigure）**：

```python
def main() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, OSError):
            pass
```

PS5.1 默认 stdout = cp936，强制 utf-8 + errors=replace 兜底。

### 暂未修（留 v0.11.0 单独评估）

- 坑 4（finally rmtree）：要做需要拆 build/upload 子命令，是设计级改动
- 坑 5（json + 进度混合）：要做需要 stderr 分离，破坏现有 CI 兼容
- 坑 7（manifest hooks 扩展点）：架构级新增，需要单独设计

### 测试

e2e 测试通过（/tmp 模拟 project + 假 zip + 调 generate_manifest）：

- ✓ configFields 中文 label 透传
- ✓ env 透传 `{'LANG_HINT': 'zh-CN'}`
- ✓ postInstallCommands 透传 `['echo done']`
- ✓ replaces 透传 `['fetch', 'read']`
- ✓ companionSkill 透传 `'my-skill'`
- ✓ 未声明时 env={}、configFields list、其余 4 个 key 不存在（向后兼容）
- ✓ 代码层验证 `Session/trust_env=False/utf-8 reconfigure/sys.exit(1)` 全 PASS

### 客户发版依赖

- `pip install -U loongclaw-devkit==0.10.5`
- xhs-zidonghuoke：可以删除 4 个 workaround 文件（publish_with_extras.py monkey-patch / upload_only.py / release.ps1 内 JSON 解析 hack / NO_PROXY=*），用标准 publish 流程
- xcw / gerenweixin-mcp：v0.10.4 已修上游字段，v0.10.5 进一步修下游同模式漏网
- 重新 publish 后 manifest 才会含齐字段

### 写入 user memory

DK_PUB5：白名单反模式可能在同一 pipeline 多层重复出现。修第一层后必须 grep 整个 pipeline 所有「dict 字面量组装 / dict.copy / 字段筛选」位置。pipeline 越长漏网概率越高。「未来字段自动支持」是绝对化警报词，不能这么承诺。

---

## 2026-04-26 [Bug] main() 字段白名单导致 .publish.json 字段被静默丢弃 + 反向覆盖 (v0.10.4)

### 现象

xcw 在 gerenweixin-mcp v2.3.30~v2.3.34 连发 5 次都失败：

1. .publish.json 写 `"usesPlatformLlm": true`（JSON bool，类型 100% 正确）
2. `python -m loongclaw_devkit.publish`
3. 服务器 manifest **不含** `usesPlatformLlm` 字段
4. 打开 .publish.json，发现 **字段从磁盘文件中消失了**
5. 以为漏填，再加，再 publish，再消失……死循环

### 真根因

`main()` 第 1437-1448 行用**字段白名单**只复制 12 个固定字段：

```python
config = {
    "id": ..., "name": ..., "version": ..., "description": ...,
    "author": ..., "icon": ..., "access": ..., "upload": ...,
    "bundleVendor": bool(saved.get("bundleVendor", False)),
    "token": ...,
}
# ⚠ 没有 saved.get("usesPlatformLlm")，也没有 replaces / env / mcp /
#   requiredPython / companionSkill / postInstallCommands / runtime / ...
```

链路两层伤害：

1. **进 manifest 这一路全丢**：`generate_manifest(config)` 从 config 取字段 → 这些被白名单剔除的字段在 manifest 全缺失
2. **回写覆盖 .publish.json**：`run()` 末尾 `save_config(project_dir, config)` 把残缺 config 序列化写回 → 用户磁盘文件里**真的被抹掉**

第二层是死循环根源——开发者再补也会被下次 publish 抹掉。

### v0.10.3 修复完全失效的原因（自我复盘）

v0.10.3 在 `_validate_config` 加了 `_BOOL_FIELDS` 校验：

```python
_BOOL_FIELDS = ("skipCython", "usesPlatformLlm", "bundleVendor")
for bf in _BOOL_FIELDS:
    if bf in config and not isinstance(config[bf], bool):
        errs.append(...)
```

执行顺序：`main() 白名单` → `_validate_config(config)`。校验跑的时候 `config` 里**根本就没** `usesPlatformLlm` 字段（白名单已剔除），`bf in config` 永远 False，校验静默跳过——**对 usesPlatformLlm 是死代码**。

`bundleVendor` / `skipCython` 因为列在白名单内所以校验真能跑到，**这恰好掩盖了 bug**——让我误以为整个机制工作正常。

### 三问根因（v0.10.3 我做错了什么）

| 层 | v0.10.3 错误处理 | v0.10.4 正确处理 |
|---|---|---|
| 症状 | 字段消失 | ✓ 看到了 |
| 机制 | `is True` 静默丢 | ✗ **只看到这一层就停了**——经典「第一层根因错觉」（CLAUDE.md §零） |
| 根因 | 字段如何被 build_manifest 接收？config 是怎么组装的？ | ✗ **从未读 main()**；这才是真根因 |

警报词命中：v0.10.3 "改成强校验" 本质就是「加一段特殊处理覆盖这种情况」补丁——警报词出现但被忽视。

### 测试覆盖反思

v0.10.3 的回归测试**直接构造 config dict**调 `_validate_config(config)`，跳过了 `main()` 的字段白名单。「测试通过 ≠ 修复有效」——下次涉及修复必须**从入口端到端测试**（CLI → main() → run() → manifest），不能只测中间函数。

本次修复加了 e2e 测试（/tmp/test_e2e_main.py + test_bool_validation.py），从 .publish.json 文件 → main() → 验证 config 与回写文件均含字段。

### 修复策略（治本，方案 B）

**放弃白名单，全量透传**：

```python
config = dict(saved)  # 完整透传 .publish.json
config.setdefault("id", detected.get("id") or project_dir.name)
config.setdefault("name", config.get("id", project_dir.name))
config.setdefault("version", "1.0.0")
config.setdefault("description", detected.get("description", ""))
config.setdefault("author", "")
config.setdefault("icon", "🔧")
config.setdefault("access", "")
config.setdefault("upload", False)
config["token"] = os.environ.get("LOONGCLAW_STORE_KEY", "")
```

变化：从「白名单（默认拒绝）」翻转为「黑名单（默认透传）」。

**举一反三**：未来新增任何 .publish.json 字段都自动支持，不需要再改 main()——这是根因级修复，不是字段级补丁。

### 顺带修复的暗坑

1. **`bundleVendor` 旧版用 `bool(saved.get("bundleVendor", False))` 强制转型**——`bool("false") = True` 错误转换。新版无 coerce + `_BOOL_FIELDS` 校验拦截字符串/数字 → fail-fast。
2. **save_config 反向覆盖**——v0.10.3 是 bug（残缺 config 抹掉用户字段）；v0.10.4 后 config 是 saved 的超集，写回不丢字段，自动消失为非问题。**不需要单独改 save_config**（YAGNI）。
3. **同被白名单丢弃的其他字段**：`replaces` / `companionSkill` / `postInstallCommands` / `env` / `mcp` / `runtime` / `requiredPython` / `buildPlatform` 等——多数有 staging 阶段从 project files 推断的兜底默认值掩盖了 bug，但纯声明字段（如 `replaces`）一直在被静默丢弃。本次一并修好。

### 客户发版依赖

- 升级 `pip install -U loongclaw-devkit==0.10.4`
- **重要**：检查 .publish.json 是否需要重新补回历史被抹掉的字段（特别是 `usesPlatformLlm` / `replaces` / `env` / `companionSkill`）
- 重新 publish 后 manifest 字段齐全

### 已知遗留（不在本次范围）

- `update_mcp_config` 工具的 AI 接口白名单（server.py L477）未同步扩展——目前只允许改 `id/name/description/version/author/icon/access/upload/bundleVendor/usesPlatformLlm`，不允许 AI 改 `replaces / companionSkill / postInstallCommands / env / mcp / runtime / requiredPython / skipCython`。开发者手动编辑 .publish.json 时这些字段都会正常发布，AI 自动操作时仍受白名单限制。属于 AI 工具接口的扩展项，不影响工单的核心修复。

### 警报词 / 补丁 vs 治本对照

- 「白名单加一行 usesPlatformLlm」(方案 A) ❌ 已识别为补丁——警报词「加一段特殊处理」命中。下次新字段继续踩
- 「全量透传 + setdefault」(方案 B) ✅ 消除白名单模式本身

判断标准：触发条件稍微变化（新增字段 / 改字段名 / 用户写新声明）修复还有效吗？
- 方案 A：失效（每个新字段需手动加白名单）
- 方案 B：有效（任何新字段自动支持）

是治本。

---

## 2026-04-26 [Bug] .publish.json 布尔字段静默丢弃修复 (v0.10.3)

### 现象

gerenweixin-mcp v2.3.31 发布后多位客户 AI 自动回复功能全挂：
```
ai.platform_llm_env_present: false
[core] [自动回复] 未检测到 LoongClaw 平台 LLM 环境变量（OPENAI_BASE_URL）
```

SSH 服务器检查发现 `manifest.json` 完全没有 `usesPlatformLlm` 字段。devkit publish 返回成功，Cloud 入库成功，客户端安装成功——唯一错的地方：**这个字段被 devkit 静默丢了**。

### 根因

`build_manifest()` 里这行：
```python
if config.get("usesPlatformLlm") is True:
    manifest["usesPlatformLlm"] = True
```

`is True` 是 Python 中**最严**的布尔判断——必须是布尔对象 `True` 本身。开发者在 `.publish.json` 里如果写成以下任何一种都会被静默丢弃，**publish 不报错**：

```json
"usesPlatformLlm": "true"     ❌ 字符串
"usesPlatformLlm": 1          ❌ 整数
"usesPlatformLlm": True       ❌ Python 大写（但这是 JSON 会报语法错，概率低）
```

这是典型的 **Fail Fast 三件套反面教材**（CLAUDE.md §不打补丁·三）：
- ❌ 没 UI 层白名单（`_validate_config` 里不检查这个字段）
- ❌ 没运行时 throw（`is True` 不命中时什么都不做 = 静默兜底）
- ❌ 文案提了 fallback（默认 false 让人以为“写错也能工作”）

### 三问根因

| 层 | 答案 |
|---|---|
| **症状** | xcw 的 .publish.json 字段写错类型，manifest 缺字段，子进程读不到 env |
| **机制** | `is True` 严格判断 + `if` 不命中无 `else` = 静默丢弃 |
| **根因** | .publish.json 布尔字段未在 `_validate_config` 里强类型校验（对比 `skipCython` 已校验——说明这个样板存在，只是 `usesPlatformLlm` 和 `bundleVendor` 被漏了）|

### 修复策略

**治本**：在 `_validate_config` 里加一个统一的布尔字段清单，任何 `.publish.json` 里出现但类型不是 bool 的字段立即 fail-fast（透过 errs.append 走到 sys.exit(1)）。同时将已存在的 `skipCython` 校验合并进该清单（消除重复代码、统一错误信息、遵循「不重复造轮子」铁律）。

```python
_BOOL_FIELDS = ("skipCython", "usesPlatformLlm", "bundleVendor")
for bf in _BOOL_FIELDS:
    if bf in config and not isinstance(config[bf], bool):
        errs.append(
            f"字段 `{bf}` 必须是布尔值 true/false（当前 {config[bf]!r}，类型 "
            f"{type(config[bf]).__name__}）。.publish.json 是 JSON 不是 Python——"
            f"必须小写无引号 true/false，不能写 \"true\" / True / 1 / 0"
        )
```

**举一反三**：grep 了所有 `config.get(...)` 用户字段，该 commit 后所有 `.publish.json` 用户布尔字段（3 个：`skipCython` / `usesPlatformLlm` / `bundleVendor`）全部走 fail-fast 路径，其他 `.get()` 与用户输入无关（是 CLI flag）。未来新增布尔字段 → 加到 `_BOOL_FIELDS` 即可，不要再写第二套。

### 补丁还是治本对照

警报词检查：
- “加一个配置开关” ❌ 未出现
- “加一段特殊处理” ❌ 未出现——不是为 `usesPlatformLlm` 单独加检查，是把所有布尔字段统一拍
- “先这样后面重构” ❌ 未出现

判断标准：修后这类 bug 还会不会以新副本出现？不会——任何新 .publish.json 布尔字段都会走 `_BOOL_FIELDS` 校验。是治本。

### 客户端连带修复？

不需要。客户端读 manifest.json 字段逻辑 100% 正确（`manifest.usesPlatformLlm === true ? true : undefined`）。bug 只在“字段能不能写进 manifest”这一步。

### 客户发版依赖

开发者升级 0.10.3 后，如果 .publish.json 中 `usesPlatformLlm` 类型错，publish 立即在本地报错。不重发不影响现有插件。

### 类似坚面防御描述检查（CLAUDE.md §不打补丁·二 举一反三）

错误模式：“Python `is True` 严格判断 + JSON 输入”。grep 仓库后**未发现同模式**其他副本（publish.py 唯一一处）。`isinstance(x, bool)` 是这里唯一正确用法（区分 bool / int / str）。

---

## 2026-04-26 [Bug] private 付费包壳脚本嵌入式 Python 启动崩溃修复 (v0.10.2)

### 现象

v0.10.1 生成的 3 行壳 `server.py`（`from server_impl import mcp; mcp.run(transport="stdio")`）在 **运行环境 = 嵌入式 Python（`runtime: self-contained` + 包里自带 `python-3.x.x-embed-amd64`）** 时 100% 启动失败。客户端 MCP 连接报 `MCP error -32000: Connection closed`，无任何 Python traceback。

首例实锤：gerenweixin-mcp v2.3.20+（2026-04-26）。

### 根因

嵌入式 Python 发布包附带 `pythonXY._pth` 文件 → 触发 **isolated startup** → 跳过 site、不读 `PYTHONPATH`、sys.path 仅含 `_pth` 里列出的目录。

普通 `python server.py` 启动时 CPython 会把脚本所在目录加进 `sys.path[0]`，这也是 bare `from server_impl import mcp` 能在常规环境下能工作的全部原因。但隔离模式下 **不会** 添加这个条目。

后果：`from server_impl import mcp` 报 `ModuleNotFoundError`，子进程在完成 MCP stdio 协议握手前秒死，客户端只看到管道关闭。

### 为什么 v0.10.0 没爆

v0.10.0 客户端通过 `bootstrap.js` （Node 包装层）间接启动子进程，启动路径中隔离模式被绕过；v0.10.1 客户端启动器改成裸调 `python server.py`（`start.cmd` / `mcp.command`）后隔离模式起作用，带出这个潜伏问题。

### 修复

让壳脚本对启动环境零假设。在 `_SHELL_SERVER_PY` 模板头部补两行：

```python
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server_impl import mcp
```

同时在模板内及 README 中写上详细 WHY 注释（防 REV3/PERM5 类回归），明确说明删除这两行会重现 v0.10.1 崩溃。

### 根因与三问复盘

| 问 | 答 |
| --- | --- |
| 1 症状 | 启动子进程报 -32000 Connection closed |
| 2 机制 | 隔离模式 Python 不把脚本目录加进 sys.path → bare import 失败 |
| 3 根因 | 壳脚本假设启动器/cwd/PYTHONPATH 会提供脚本目录。修正：壳脚本必须对环境零依赖 |

同类背面问题 grep 扫描：项目中其他生成脚本运行在嵌入式 Python 下的只有这一个模板，无需举一反三。

### 补丁还是治本（三问复盘 + 警报词对照）

- “加个配置开关” ❌ → 选 A（壳脚本内部修正）是机制修复；
- “让客户端 start.cmd 注入 PYTHONPATH” ❌ → devkit 不生成 start.cmd，且隔离模式本来就忽略 PYTHONPATH，该方案无效；
- “回退到 bootstrap.js” ❌ → 仅掩盖不修机制，下一个裸调客户端会重遇。

### 客户发版依赖

- 升级 `loongclaw-devkit` 到 0.10.2
- **重新 publish private + self-contained 插件**（已发包内的壳 `server.py` 是固化在 zip 里的，devkit 升级不会自动修复存量包）。重新发版后 `sourceArchiveHash` 变化→ 客户端 install/update 会触发重下载 → 终端用户自动修复。

### 设计原则（写进本仓 user memory 防再犯）

> **生成的启动脚本不要假设启动环境（launcher / cwd / PYTHONPATH / sys.path 默认项），必须对运行环境零依赖。该扫描包含 `python._pth`（隔离启动）、`python -I`、`runpy`、子进程 `Popen([interpreter, script])` 这些变体。**

---

## 2026-04-25 [Security] private + skipCython/self-contained 明文泄露漏洞修复 (v0.10.1)

### 漏洞详情

**版本**：仅 v0.10.0 受影响（v0.9.x 及以前没有 `skipCython` / `self-contained` 字段，无此漏洞）。

**触发条件**（同时满足）：
1. `accessType=private`（付费插件，依赖 .py 加密成 .so/.pyd 防止源码泄露）
2. `skipCython=true` **或** `runtime=self-contained`
3. 项目里含 .py 业务源码（非 `__init__.py`）

**后果**：业务 .py **明文打进 zip**，上传 store 后被任何下载该插件的客户端用户拿到原始源码。

### 根因

`encrypt_files()` 函数末尾有完整的 `PRIVATE_PLAINTEXT_LEAK` Fail-Close 后置检查（v0.7.x 引入），但 v0.10.0 在 `publish.py` Step 3 增加 `skipCython` / `self-contained` 跳过加密路径时，**整个绕过了 `encrypt_files()` 函数**，等于绕过了内置防线。

错误地把"是否加密"和"accessType（公开 vs 付费）"两个正交维度用 OR 合并：

```python
# v0.10.0 漏洞代码
if runtime == "self-contained" or skip_cython:
    encrypted, plain = [], [所有 .py]   # ← 不管是 public 还是 private
```

### 修复（v0.10.1）

**核心改动**：把"是否跳过加密"的判断收敛到 `accessType` 这个源头权威。**private 永远走 `encrypt_files()`，不允许任何路径绕过**。

```python
# v0.10.1 修复
should_skip = (skip_cython or runtime == "self-contained") and access_type != "private"
if should_skip:
    # 仅 public + (skipCython|self-contained) 跳过加密
    encrypted, plain = [], [所有 .py]
else:
    # private 全部进入 encrypt_files()，由内置 PRIVATE_PLAINTEXT_LEAK 防线统一守门
    encrypted, plain = encrypt_files(..., access=access_type)
```

**配套改动**：`encrypt_files()` 末尾的"server.py 必须加密"硬要求改为"项目里有根目录 server.py 时才要求"，兼容 `private + self-contained + 项目无 server.py`（开发者用自己的 mcp.command 启动，业务模块以 .so 形式存在）的合法场景。`PRIVATE_PLAINTEXT_LEAK` 业务 .py 明文兜底检查所有 private 路径都跑，是核心防线。

### 设计原则（写进 user memory 防再犯）

> **「加密 vs 不加密」与「解释器类型 vs 自带运行时」是两个正交维度。
> 收敛到 `accessType` 这个源头权威——只要 access=private，".py 不明文进 zip" 这条承诺不能有任何路径绕过。**

适用 Fail Fast 三件套第 2 条：「业务逻辑发现配置缺失/错误立即抛错，不走 else 分支」。

### 修复路径覆盖矩阵

| accessType | runtime | skipCython | 项目含 .py 业务 | 修复后行为 |
|---|---|---|---|---|
| public | python | false | 是 | 走 encrypt_files() ✅ |
| public | python | true | 是 | 跳过加密 ✅（公开包本来就开源） |
| public | self-contained | (任意) | 是 | 跳过加密 ✅ |
| **private** | **python** | **false**（默认） | **是** | **走 encrypt_files() 加密** ✅ |
| **private** | **python** | **true** | **是** | **走 encrypt_files() 加密**（v0.10.0 漏洞已堵） ✅ |
| **private** | **self-contained** | (任意) | **是** | **走 encrypt_files() 加密**（v0.10.0 漏洞已堵） ✅ |
| private | self-contained | (任意) | 否（纯二进制 / 仅 __init__.py） | encrypt_files() to_encrypt 为空，安全 return ✅ |

### 不做的事（避免过度防御）

**Cloud 上传二次扫 zip 防线**：评估后**不做**。理由：DevKit 是 LoongClaw 自家工具，是唯一合法的 manifest 生成路径；修复后绕过守门 = 手搓 manifest = 主动作恶 = 受害者是开发者自己（自己源码自己泄露），不是平台/第三方。Cloud 扫 zip 内 .py 引入解压 + 遍历开销且无法防 .so 内塞 plaintext bytecode 的下个攻击向量。源头守门已足够。

### yank v0.10.0？不做

理由：
- 0.10.0 上线只有几小时，目前没有已知用户踩到漏洞组合（self-contained 是新功能没人来得及配）
- 0.10.1 出来后 `pip install -U` 自动覆盖
- yank 影响 CI pin 用户体验，代价 > 收益

### 验证

- 单测覆盖矩阵 7 个 case（见 publish.py docstring）
- 手工：构造 private + self-contained + 含 business.py 项目跑 `loongclaw-devkit publish --dry-run`，应在 Step 3 看到走 encrypt_files() + business.py 进 to_encrypt
- README §4.7 self-contained 章节注明「private 模式下 .py 仍会被强制 Cython 加密」

---
