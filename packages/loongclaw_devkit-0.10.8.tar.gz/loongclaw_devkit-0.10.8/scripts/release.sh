#!/usr/bin/env bash
# LoongClaw DevKit 一键发版脚本
#
# 用法：
#   bash scripts/release.sh 0.7.0              # 正常发版（交互确认）
#   bash scripts/release.sh 0.7.0 --dry-run    # 演练（不 push / 不 upload）
#   RELEASE_YES=1 bash scripts/release.sh 0.7.0  # 全自动（跳过所有 confirm，用默认 commit message）
#
# ⚠️ stdin 使用规则（2026-04-24 修复坑）：
#   - 不要用 `printf 'y\ny\n' | bash release.sh ...` 喂 confirm——以前 confirm 用 `read -n 1` 读 1 字符，
#     Step 3 又尝试从 stdin 读 commit message → stdin 被错位消费，commit message 退化为 `y`
#   - 自动化请用 RELEASE_YES=1；confirm 改为从 /dev/tty 读（stdin 不参与确认）
#   - 若需自定义 commit message，用 `echo 'my msg' | bash release.sh ...` 且不加 RELEASE_YES（stdin 不会被 confirm 吃掉）
#
# 前置条件：
#   - 当前分支 = main
#   - 工作区干净（或只有 pyproject.toml 和 README.md 修改待提交）
#   - ~/.pypirc 已配置
#   - ~/.local/bin/uvx 可用
#
# 执行流程（9 步）：
#   1. 预检（版本号格式 / 分支 / 工作区 / PyPI 未占用）
#   2. bump pyproject.toml 版本号
#   3. 提交 commit message（从 stdin 或交互输入）
#   4. push main（二次确认）
#   5. 打 tag v{version}
#   6. push tag
#   7. 清理 dist/ + 构建 wheel
#   8. twine upload（二次确认）
#   9. uvx 验证 PyPI 上新版本
#
# 失败策略：任何步骤失败立即 exit 1，不自动回滚（避免级联损伤）

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEVKIT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
UVX="${HOME}/.local/bin/uvx"

# ---------- 参数解析 ----------
NEW_VERSION="${1:-}"
DRY_RUN=0
if [[ "${2:-}" == "--dry-run" ]]; then
    DRY_RUN=1
fi

if [[ -z "$NEW_VERSION" ]]; then
    echo "❌ 用法: bash scripts/release.sh <version> [--dry-run]"
    echo "   示例: bash scripts/release.sh 0.7.0"
    exit 1
fi

# 版本号格式 X.Y.Z
if ! [[ "$NEW_VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    echo "❌ 版本号必须是 X.Y.Z 格式（当前: ${NEW_VERSION}）"
    exit 1
fi

log() { echo -e "\n\033[1;34m▶ $1\033[0m"; }
err() { echo -e "\033[1;31m✖ $1\033[0m" >&2; exit 1; }
ok()  { echo -e "\033[1;32m✓ $1\033[0m"; }

confirm() {
    local prompt="$1"
    if [[ $DRY_RUN -eq 1 ]]; then
        echo "[dry-run] 跳过确认: $prompt"
        return 0
    fi
    if [[ "${RELEASE_YES:-0}" == "1" ]]; then
        echo "[RELEASE_YES=1] 自动确认: $prompt"
        return 0
    fi
    # 从 /dev/tty 读（不消费 stdin）——stdin 仅供 commit message 使用
    if [[ ! -r /dev/tty ]]; then
        err "无 /dev/tty 可用的环境请设 RELEASE_YES=1 跑全自动模式"
    fi
    local reply
    read -p "$prompt (y/N) " -n 1 -r reply < /dev/tty
    echo
    [[ $reply =~ ^[Yy]$ ]] || err "已取消"
}

cd "$DEVKIT_DIR"

# ========== Step 1: 预检 ==========
log "Step 1/9: 预检"

[[ -f pyproject.toml ]] || err "pyproject.toml 不存在（当前目录: ${PWD}）"
[[ -x "$UVX" ]] || err "uvx 不存在: $UVX"

BRANCH=$(git rev-parse --abbrev-ref HEAD)
[[ "$BRANCH" == "main" ]] || err "必须在 main 分支发版（当前: ${BRANCH}）"

CURRENT_VERSION=$(grep -E '^version = ' pyproject.toml | head -1 | sed -E 's/version = "([^"]+)"/\1/')
[[ "$CURRENT_VERSION" != "$NEW_VERSION" ]] || err "版本号未变更（pyproject.toml 已是 ${NEW_VERSION}）"

# 工作区干净（允许 pyproject.toml/README.md 有未提交改动）
DIRTY=$(git status --porcelain | grep -v -E '^\s*M\s+(pyproject\.toml|README\.md)$' || true)
if [[ -n "$DIRTY" ]]; then
    echo "以下文件有未提交改动（非 pyproject.toml / README.md）："
    echo "$DIRTY"
    err "请先提交或 stash 这些改动"
fi

# PyPI 上未占用此版本号
log "检查 PyPI 是否已存在 $NEW_VERSION..."
if curl -sf "https://pypi.org/pypi/loongclaw-devkit/$NEW_VERSION/json" -o /dev/null 2>&1; then
    err "PyPI 上已存在 loongclaw-devkit==$NEW_VERSION"
fi

ok "预检通过: $CURRENT_VERSION → $NEW_VERSION (branch=main, PyPI 未占用)"

# ---------- 总览确认（唯一中间确认点，后续仅 PyPI 上传前再确认一次） ----------
echo
echo "============================================================"
echo "即将执行以下不可逆 / 强影响操作，请整体确认一次："
echo "  1) bump pyproject.toml: ${CURRENT_VERSION} → ${NEW_VERSION}"
echo "  2) git commit 版本变更"
echo "  3) git push origin main"
echo "  4) git tag v${NEW_VERSION} + git push tag"
echo "  5) 构建 wheel"
echo "  6) 上传 PyPI（此步前还会再确认一次）"
echo "============================================================"
confirm "以上全部执行？"

# ========== Step 2: bump pyproject.toml ==========
log "Step 2/9: bump 版本号"
# macOS sed 需要 -i '' 语法
sed -i.bak -E "s/^version = \"[0-9]+\.[0-9]+\.[0-9]+\"/version = \"$NEW_VERSION\"/" pyproject.toml
rm -f pyproject.toml.bak
grep "^version = " pyproject.toml
ok "pyproject.toml 已更新"

# v0.9.2 起：README.md 为唯一物理事实源，通过 pyproject.toml 的
# [tool.hatch.build.targets.wheel.force-include] 在 wheel 构建时自动
# 复制到包内。不需要手动 sync 步骤。

# ========== Step 3: commit ==========
log "Step 3/9: commit"

# commit message 来源优先级：
# 1. stdin 是 pipe 且 RELEASE_YES!=1 → 从 stdin 读（用户 echo 'msg' | release.sh）
# 2. 否则 → 默认模板
# RELEASE_YES=1 时强制走默认，避免自动化 yes pipe 污染 commit message（2026-04-24 坑）
COMMIT_MSG_FILE=$(mktemp)
if [[ -p /dev/stdin && "${RELEASE_YES:-0}" != "1" ]]; then
    cat > "$COMMIT_MSG_FILE"
    # 防御：commit message 过短（如单字符 "y"）= 用户误喂了 confirm 输入，拒绝
    MSG_LEN=$(wc -c < "$COMMIT_MSG_FILE" | tr -d ' ')
    if [[ "$MSG_LEN" -lt 10 ]]; then
        rm -f "$COMMIT_MSG_FILE"
        err "commit message 过短（${MSG_LEN} 字符，内容可能被 stdin 误吃）。请改用 RELEASE_YES=1 或不要 pipe 喂确认字符"
    fi
else
    cat > "$COMMIT_MSG_FILE" <<EOF
chore: release v$NEW_VERSION

$(git log "v$CURRENT_VERSION..HEAD" --pretty=format:'- %s' 2>/dev/null || echo '- (首次发版)')
EOF
    echo "--- 默认 commit message ---"
    cat "$COMMIT_MSG_FILE"
    echo "---"
fi

git add pyproject.toml README.md 2>/dev/null || true
git add pyproject.toml
git commit -F "$COMMIT_MSG_FILE"
rm -f "$COMMIT_MSG_FILE"
ok "commit 完成: $(git log -1 --oneline)"

# ========== Step 4: push main ==========
log "Step 4/9: push main"
if [[ $DRY_RUN -eq 0 ]]; then
    git push origin main
fi
ok "main 已推送"

# ========== Step 5: 打 tag ==========
log "Step 5/9: 打 tag v$NEW_VERSION"
if git rev-parse "v$NEW_VERSION" >/dev/null 2>&1; then
    err "tag v$NEW_VERSION 本地已存在"
fi
git tag -a "v$NEW_VERSION" -m "release: v$NEW_VERSION"
ok "tag v$NEW_VERSION 已创建"

# ========== Step 6: push tag ==========
log "Step 6/9: push tag"
if [[ $DRY_RUN -eq 0 ]]; then
    git push origin "v$NEW_VERSION"
fi
ok "tag 已推送"

# ========== Step 7: 构建 wheel ==========
log "Step 7/9: 干净构建 wheel"
rm -rf dist build
find src -name '*.egg-info' -exec rm -rf {} + 2>/dev/null || true
"$UVX" --from build pyproject-build --wheel
WHEEL="$(ls dist/loongclaw_devkit-$NEW_VERSION-*.whl 2>/dev/null | head -1)"
[[ -n "$WHEEL" ]] || err "未找到构建产物"
ok "构建完成: $WHEEL"

# ========== Step 8: twine upload ==========
log "Step 8/9: 上传 PyPI"
confirm "上传到 PyPI？（不可撤，只能 yank 或发新版）"
if [[ $DRY_RUN -eq 0 ]]; then
    "$UVX" twine upload "$WHEEL"
fi
ok "已上传: https://pypi.org/project/loongclaw-devkit/$NEW_VERSION/"

# ========== Step 9: 验证 ==========
log "Step 9/9: 验证 PyPI 新版本"
if [[ $DRY_RUN -eq 0 ]]; then
    # 等一下 PyPI CDN 同步
    echo "等待 PyPI CDN 同步 (10s)..."
    sleep 10
    "$UVX" --refresh --from "loongclaw-devkit==$NEW_VERSION" python -c "
import importlib.metadata
v = importlib.metadata.version('loongclaw-devkit')
assert v == '$NEW_VERSION', f'版本不匹配: got {v}'
print(f'✓ PyPI 验证通过: loongclaw-devkit=={v}')
"
fi

echo
ok "🎉 发版完成: v$NEW_VERSION"
echo "  - Git: $(git log -1 --oneline)"
echo "  - Tag: v$NEW_VERSION"
echo "  - PyPI: https://pypi.org/project/loongclaw-devkit/$NEW_VERSION/"
