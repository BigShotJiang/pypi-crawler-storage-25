# Aelion Vision 🚀
### Enterprise-grade, zero-boilerplate Computer Vision pipeline.

Aelion Vision is a multi-threaded, high-performance wrapper for OpenCV, MediaPipe, and ONNX. Built for extreme speed, it eliminates camera lag using asynchronous threading and provides professional modules for spatial hand tracking, 468-point face mesh, and biometric security.

---

## 🛠️ New in v1.1.0: Intelligence Layer
* **Lightweight Emotions:** ONNX-powered sentiment analysis (No TensorFlow required).
* **Security Vault:** Dlib-based identity verification with 128-D vector matching.
* **Spatial Mouse:** Control your Windows OS using binary hand gestures.
* **Zero-Lag Core:** Asynchronous camera handling for high-FPS processing.

---

## 📦 Installation

Ensure you are using Python 3.8+ and run:

```bash
pip install aelion-vision