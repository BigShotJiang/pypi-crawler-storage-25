"""
Aelion Vision Ecosystem v1.5.0
Enterprise-grade, zero-boilerplate Computer Vision pipeline.
Optimized for high-speed spatial awareness, biometric security, OCR, and sentiment analysis.
Powered by the independent Aelion Private AI Server infrastructure (ai.aelionyxe.top).
"""

# Core Engine & Human-Readable UI
from .core import Camera
from .ui import Draw

# Spatial & Interaction Engines (Hands & 3D Depth)
from .hands import HandTracker
from .spatial_engine import DepthMapper

# Identity & Security Engines (Vectors & Identity Vault)
from .faces import FaceRecognizer
from .security import SecurityVault
from .biometrics import Authenticator

# Biometric & Sentiment Engines (468-point Mesh & ONNX Emotions)
from .face_mesh import FaceMeshTracker
from .emotions import EmotionDetector

# Data & Optical Engines (100% Self-Hosted ONNX OCR)
from .text_engine import DataScanner

# Package Metadata
__version__ = "1.5.8"
__author__ = "Muhammad Ahmad"
__company__ = "Aelionyxe"
__status__ = "Production"

def get_info():
    """Returns the Aelion Vision capability manifest."""
    return {
        "Package": "Aelion Vision Ecosystem",
        "Company": __company__,
        "Version": __version__,
        "Status": __status__,
        "Network": "Self-Hosted (ai.aelionyxe.top)",
        "Modules": [
            "Core", "Draw (UI Engine)", "Hands", "Faces", "FaceMesh", 
            "Emotions", "SecurityVault", "SpatialDepth", "DataScanner (OCR)"
        ],
        "Backend": "ONNX / MediaPipe / Dlib / OpenCV DNN"
    }