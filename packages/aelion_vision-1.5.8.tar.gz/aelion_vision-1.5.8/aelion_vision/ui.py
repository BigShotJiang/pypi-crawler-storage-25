import cv2

class Draw:
    """Aelion Vision's Human-Readable Graphics Engine"""
    
    COLORS = {
        "red": (0, 0, 255), "green": (0, 255, 0), "blue": (255, 0, 0),
        "yellow": (0, 255, 255), "cyan": (255, 255, 0), "magenta": (255, 0, 255),
        "white": (255, 255, 255), "black": (0, 0, 0), "orange": (0, 165, 255)
    }

    @staticmethod
    def _color(c):
        return Draw.COLORS.get(c.lower(), (255, 255, 255)) if isinstance(c, str) else c

    @staticmethod
    def text(frame, text, x, y, color="white", size=0.7, thickness=1):
        """Draws clean, futuristic text"""
        cv2.putText(frame, str(text), (x, y), cv2.FONT_HERSHEY_DUPLEX, size, Draw._color(color), thickness)

    @staticmethod
    def panel(frame, x, y, w, h, color="black", alpha=0.6):
        """Draws a sleek, semi-transparent background panel for the HUD"""
        overlay = frame.copy()
        cv2.rectangle(overlay, (x, y), (x + w, y + h), Draw._color(color), -1)
        cv2.addWeighted(overlay, alpha, frame, 1 - alpha, 0, frame)

    @staticmethod
    def scifi_box(frame, x, y, w, h, color="cyan", thickness=2):
        """Draws a futuristic corner-bracket targeting box"""
        c = Draw._color(color)
        L = 20 # Length of the corner brackets
        cv2.rectangle(frame, (x, y), (x + w, y + h), c, 1) # Thin inner line
        
        # Corners
        cv2.line(frame, (x, y), (x + L, y), c, thickness)
        cv2.line(frame, (x, y), (x, y + L), c, thickness)
        cv2.line(frame, (x + w, y), (x + w - L, y), c, thickness)
        cv2.line(frame, (x + w, y), (x + w, y + L), c, thickness)
        cv2.line(frame, (x, y + h), (x + L, y + h), c, thickness)
        cv2.line(frame, (x, y + h), (x, y + h - L), c, thickness)
        cv2.line(frame, (x + w, y + h), (x + w - L, y + h), c, thickness)
        cv2.line(frame, (x + w, y + h), (x + w, y + h - L), c, thickness)