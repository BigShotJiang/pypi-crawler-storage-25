"""replace generated search_vector with trigger-based column including cuisine

The GENERATED ALWAYS column only had access to experiences.name and
experiences.description.  Cuisine lives in the restaurants table, so we
need a trigger to keep the tsvector in sync across both tables.

Revision ID: 0019
Revises: 0018
Create Date: 2026-04-13
"""

from typing import Sequence, Union

from alembic import op

revision: str = "0019"
down_revision: Union[str, None] = "0018"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

_TRIGGER_FN = """\
CREATE OR REPLACE FUNCTION experiences_search_vector_update() RETURNS trigger AS $$
DECLARE
    cuisine_text TEXT;
BEGIN
    SELECT coalesce(array_to_string(r.cuisine, ' '), '')
    INTO cuisine_text
    FROM restaurants r
    WHERE r.experience_id = NEW.id;

    NEW.search_vector := to_tsvector('english',
        coalesce(NEW.name, '') || ' ' ||
        coalesce(NEW.description, '') || ' ' ||
        coalesce(cuisine_text, '')
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
"""

_RESTAURANT_TRIGGER_FN = """\
CREATE OR REPLACE FUNCTION restaurants_sync_search_vector() RETURNS trigger AS $$
BEGIN
    UPDATE experiences SET
        search_vector = to_tsvector('english',
            coalesce(experiences.name, '') || ' ' ||
            coalesce(experiences.description, '') || ' ' ||
            coalesce(array_to_string(NEW.cuisine, ' '), '')
        )
    WHERE experiences.id = NEW.experience_id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
"""

_BACKFILL = """\
UPDATE experiences e SET search_vector = to_tsvector('english',
    coalesce(e.name, '') || ' ' ||
    coalesce(e.description, '') || ' ' ||
    coalesce((
        SELECT array_to_string(r.cuisine, ' ')
        FROM restaurants r WHERE r.experience_id = e.id
    ), '')
);
"""


def upgrade() -> None:
    op.execute("DROP INDEX IF EXISTS idx_experiences_search_vector")
    op.execute("ALTER TABLE experiences DROP COLUMN IF EXISTS search_vector")

    op.execute("ALTER TABLE experiences ADD COLUMN search_vector tsvector")
    op.execute(
        "CREATE INDEX idx_experiences_search_vector "
        "ON experiences USING gin (search_vector)"
    )

    op.execute(_TRIGGER_FN)
    op.execute(
        "CREATE TRIGGER trg_experiences_search_vector "
        "BEFORE INSERT OR UPDATE OF name, description "
        "ON experiences "
        "FOR EACH ROW EXECUTE FUNCTION experiences_search_vector_update()"
    )

    op.execute(_RESTAURANT_TRIGGER_FN)
    op.execute(
        "CREATE TRIGGER trg_restaurants_sync_search_vector "
        "AFTER INSERT OR UPDATE OF cuisine "
        "ON restaurants "
        "FOR EACH ROW EXECUTE FUNCTION restaurants_sync_search_vector()"
    )

    op.execute(_BACKFILL)


def downgrade() -> None:
    op.execute("DROP TRIGGER IF EXISTS trg_restaurants_sync_search_vector ON restaurants")
    op.execute("DROP FUNCTION IF EXISTS restaurants_sync_search_vector()")
    op.execute("DROP TRIGGER IF EXISTS trg_experiences_search_vector ON experiences")
    op.execute("DROP FUNCTION IF EXISTS experiences_search_vector_update()")

    op.execute("DROP INDEX IF EXISTS idx_experiences_search_vector")
    op.execute("ALTER TABLE experiences DROP COLUMN IF EXISTS search_vector")

    op.execute(
        "ALTER TABLE experiences ADD COLUMN search_vector tsvector "
        "GENERATED ALWAYS AS ("
        "  to_tsvector('english', coalesce(name, '') || ' ' || coalesce(description, ''))"
        ") STORED"
    )
    op.execute(
        "CREATE INDEX idx_experiences_search_vector "
        "ON experiences USING gin (search_vector)"
    )
