"""add conversation name

Revision ID: 0004
Revises: 0003
Create Date: 2026-02-25 16:49:28.948257
"""

from typing import Sequence, Union

import sqlalchemy as sa
import sqlmodel  # noqa: F401 — needed so sa.Enum can resolve SQLModel types

from alembic import op

# revision identifiers, used by Alembic.
revision: str = "0004"
down_revision: Union[str, None] = "0003"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("conversations", sa.Column("name", sa.Text(), nullable=True))


def downgrade() -> None:
    op.drop_column("conversations", "name")
