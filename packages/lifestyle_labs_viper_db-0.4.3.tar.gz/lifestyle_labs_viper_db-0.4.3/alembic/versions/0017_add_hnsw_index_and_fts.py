"""add HNSW index, FTS search_vector column, and pg_trgm trigram index

Revision ID: 0017
Revises: 0016
Create Date: 2026-04-13
"""

from typing import Sequence, Union

from alembic import op

revision: str = "0017"
down_revision: Union[str, None] = "0016"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute(
        "CREATE INDEX idx_experiences_embedding_hnsw "
        "ON experiences USING hnsw (embedding vector_cosine_ops) "
        "WITH (m = 16, ef_construction = 64)"
    )

    op.execute(
        "ALTER TABLE experiences ADD COLUMN search_vector tsvector "
        "GENERATED ALWAYS AS ("
        "  to_tsvector('english', coalesce(name, '') || ' ' || coalesce(description, ''))"
        ") STORED"
    )
    op.execute(
        "CREATE INDEX idx_experiences_search_vector "
        "ON experiences USING gin (search_vector)"
    )

    op.execute("CREATE EXTENSION IF NOT EXISTS pg_trgm")
    op.execute(
        "CREATE INDEX idx_experiences_name_trgm "
        "ON experiences USING gin (name gin_trgm_ops)"
    )


def downgrade() -> None:
    op.execute("DROP INDEX IF EXISTS idx_experiences_name_trgm")
    op.execute("DROP INDEX IF EXISTS idx_experiences_search_vector")
    op.execute("ALTER TABLE experiences DROP COLUMN IF EXISTS search_vector")
    op.execute("DROP INDEX IF EXISTS idx_experiences_embedding_hnsw")
