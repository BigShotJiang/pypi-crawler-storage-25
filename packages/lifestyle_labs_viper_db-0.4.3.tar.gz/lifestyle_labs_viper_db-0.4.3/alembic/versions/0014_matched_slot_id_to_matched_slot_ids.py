"""matched_slot_id_to_matched_slot_ids

Revision ID: 0014
Revises: 0013
Create Date: 2026-03-30

Migrate alert_preferences from a single matched_slot_id FK to a
matched_slot_ids BIGINT[] array for multi-slot matching.
"""

from typing import Sequence, Union

import sqlalchemy as sa

from alembic import op

revision: str = "0014"
down_revision: Union[str, None] = "0013"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "alert_preferences",
        sa.Column(
            "matched_slot_ids",
            sa.ARRAY(sa.BigInteger),
            nullable=True,
        ),
    )
    op.execute(
        "UPDATE alert_preferences "
        "SET matched_slot_ids = ARRAY[matched_slot_id] "
        "WHERE matched_slot_id IS NOT NULL"
    )
    op.drop_constraint(
        "alert_preferences_matched_slot_id_fkey",
        "alert_preferences",
        type_="foreignkey",
    )
    op.drop_column("alert_preferences", "matched_slot_id")


def downgrade() -> None:
    op.add_column(
        "alert_preferences",
        sa.Column("matched_slot_id", sa.BigInteger, nullable=True),
    )
    op.execute(
        "UPDATE alert_preferences "
        "SET matched_slot_id = matched_slot_ids[1] "
        "WHERE matched_slot_ids IS NOT NULL"
    )
    op.create_foreign_key(
        "alert_preferences_matched_slot_id_fkey",
        "alert_preferences",
        "availability_slots",
        ["matched_slot_id"],
        ["id"],
        ondelete="SET NULL",
    )
    op.drop_column("alert_preferences", "matched_slot_ids")
