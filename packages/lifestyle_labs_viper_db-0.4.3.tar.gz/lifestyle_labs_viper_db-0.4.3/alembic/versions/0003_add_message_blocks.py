"""add_message_blocks

Revision ID: 0003
Revises: 0002
Create Date: 2026-02-24

Adds a JSONB 'blocks' column to the messages table to support structured
content (text blocks, tool output blocks, etc.) alongside the legacy
plain-text 'content' column.
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB

revision: str = "0003"
down_revision: Union[str, None] = "0002"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("messages", sa.Column("blocks", JSONB, nullable=True))


def downgrade() -> None:
    op.drop_column("messages", "blocks")
