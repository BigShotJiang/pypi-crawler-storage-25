"""rename vibe to vibes add embedding and categories drop restaurant columns

Revision ID: 0006
Revises: 0005
Create Date: 2026-03-05 22:22:59.419248
"""

from typing import Sequence, Union

import pgvector
import sqlalchemy as sa
import sqlmodel  # noqa: F401 — needed so sa.Enum can resolve SQLModel types
from sqlalchemy.dialects import postgresql

from alembic import op

# revision identifiers, used by Alembic.
revision: str = "0006"
down_revision: Union[str, None] = "0005"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "experiences",
        sa.Column("vibes", sa.ARRAY(sa.Text()), server_default="{}", nullable=True),
    )
    op.add_column(
        "experiences",
        sa.Column("categories", sa.ARRAY(sa.Text()), server_default="{}", nullable=True),
    )
    op.add_column(
        "experiences",
        sa.Column(
            "embedding", pgvector.sqlalchemy.vector.VECTOR(dim=1536), nullable=True
        ),
    )
    op.drop_index(
        op.f("idx_experiences_vibe"), table_name="experiences", postgresql_using="gin"
    )
    op.create_index(
        "idx_experiences_vibes",
        "experiences",
        ["vibes"],
        unique=False,
        postgresql_using="gin",
    )
    op.drop_column("experiences", "vibe")
    op.drop_column("restaurants", "resy_url")
    op.drop_column("restaurants", "categories")
    op.create_unique_constraint(None, "users", ["phone"])


def downgrade() -> None:
    op.drop_constraint(None, "users", type_="unique")
    op.add_column(
        "restaurants",
        sa.Column(
            "categories",
            postgresql.ARRAY(sa.TEXT()),
            server_default=sa.text("'{}'::text[]"),
            autoincrement=False,
            nullable=True,
        ),
    )
    op.add_column(
        "restaurants",
        sa.Column("resy_url", sa.TEXT(), autoincrement=False, nullable=True),
    )
    op.add_column(
        "experiences",
        sa.Column(
            "vibe",
            postgresql.ARRAY(sa.TEXT()),
            server_default=sa.text("'{}'::text[]"),
            autoincrement=False,
            nullable=True,
        ),
    )
    op.drop_index(
        "idx_experiences_vibes", table_name="experiences", postgresql_using="gin"
    )
    op.create_index(
        op.f("idx_experiences_vibe"),
        "experiences",
        ["vibe"],
        unique=False,
        postgresql_using="gin",
    )
    op.drop_column("experiences", "embedding")
    op.drop_column("experiences", "categories")
    op.drop_column("experiences", "vibes")
