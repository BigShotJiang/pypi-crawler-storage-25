"""add appeal_score column to restaurants table

Revision ID: 0018
Revises: 0017
Create Date: 2026-04-13
"""

from typing import Sequence, Union

import sqlalchemy as sa

from alembic import op

revision: str = "0018"
down_revision: Union[str, None] = "0017"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "restaurants",
        sa.Column("appeal_score", sa.SmallInteger(), nullable=True),
    )


def downgrade() -> None:
    op.drop_column("restaurants", "appeal_score")
