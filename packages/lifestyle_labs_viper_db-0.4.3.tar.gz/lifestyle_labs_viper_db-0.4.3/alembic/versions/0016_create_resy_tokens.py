"""add resy_auth_token columns to users

Revision ID: 0016
Revises: 0015
Create Date: 2026-04-08
"""

from typing import Sequence, Union

import sqlalchemy as sa

from alembic import op

revision: str = "0016"
down_revision: Union[str, None] = "0015"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "users",
        sa.Column("resy_auth_token", sa.Text, nullable=True),
    )
    op.add_column(
        "users",
        sa.Column(
            "resy_token_obtained_at",
            sa.DateTime(timezone=True),
            nullable=True,
        ),
    )


def downgrade() -> None:
    op.drop_column("users", "resy_token_obtained_at")
    op.drop_column("users", "resy_auth_token")
