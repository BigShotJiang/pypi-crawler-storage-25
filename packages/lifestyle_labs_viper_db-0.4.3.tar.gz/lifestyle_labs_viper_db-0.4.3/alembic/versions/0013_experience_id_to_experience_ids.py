"""experience_id_to_experience_ids

Revision ID: 0013
Revises: 0012
Create Date: 2026-03-29

Rename experience_id (scalar FK) to experience_ids (integer array) on
alert_preferences to support multi-restaurant alerts.
"""

from typing import Sequence, Union

import sqlalchemy as sa

from alembic import op

revision: str = "0013"
down_revision: Union[str, None] = "0012"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "alert_preferences",
        sa.Column("experience_ids", sa.ARRAY(sa.Integer), nullable=True),
    )
    op.execute("UPDATE alert_preferences SET experience_ids = ARRAY[experience_id]")
    op.alter_column(
        "alert_preferences",
        "experience_ids",
        nullable=False,
    )
    op.drop_index("idx_alert_pref_active_experience", "alert_preferences")
    op.drop_constraint(
        "alert_preferences_experience_id_fkey",
        "alert_preferences",
        type_="foreignkey",
    )
    op.drop_column("alert_preferences", "experience_id")
    op.create_index(
        "idx_alert_pref_active_experience_ids",
        "alert_preferences",
        ["experience_ids"],
        postgresql_using="gin",
        postgresql_where=sa.text("is_active = true"),
    )


def downgrade() -> None:
    op.drop_index("idx_alert_pref_active_experience_ids", "alert_preferences")
    op.add_column(
        "alert_preferences",
        sa.Column("experience_id", sa.Integer, nullable=True),
    )
    op.execute("UPDATE alert_preferences SET experience_id = experience_ids[1]")
    op.alter_column(
        "alert_preferences",
        "experience_id",
        nullable=False,
    )
    op.create_foreign_key(
        "alert_preferences_experience_id_fkey",
        "alert_preferences",
        "experiences",
        ["experience_id"],
        ["id"],
        ondelete="CASCADE",
    )
    op.drop_column("alert_preferences", "experience_ids")
    op.create_index(
        "idx_alert_pref_active_experience",
        "alert_preferences",
        ["experience_id", "is_active"],
        postgresql_where=sa.text("is_active = true"),
    )
