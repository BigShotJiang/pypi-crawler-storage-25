"""
Postgres-native ENUMs exposed as Python enums.

DECISION: We define these as plain Python `enum.Enum` and register them with
SQLAlchemy via `sa.Enum(..., create_type=True)` on the column.  Alembic
*can* autogenerate CREATE TYPE for sa.Enum columns, but if you ever add a
new member you'll need a manual `op.execute("ALTER TYPE ... ADD VALUE ...")`
in the migration — Alembic cannot diff enum members.
"""

import enum


class BookingStatus(str, enum.Enum):
    PENDING = "pending"
    AWAITING_CONFIRMATION = "awaiting_confirmation"
    CONFIRMED = "confirmed"
    CANCELLED = "cancelled"


class MessageRole(str, enum.Enum):
    USER = "user"
    AI_AGENT = "ai_agent"
    HUMAN_AGENT = "human_agent"
