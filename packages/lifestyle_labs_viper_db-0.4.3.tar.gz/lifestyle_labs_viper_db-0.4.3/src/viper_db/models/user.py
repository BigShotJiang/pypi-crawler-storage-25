"""
DECISION: The `users.id` column is a UUID that references `auth.users(id)` in
Supabase.  We model it here as a plain UUID PK *without* the FK to auth.users
because Alembic manages only the `public` schema — the auth schema is owned by
Supabase.  The FK and the `handle_new_user()` trigger should stay in a
hand-maintained Supabase migration (or a manual Alembic op.execute block).
"""

from datetime import datetime
from typing import TYPE_CHECKING
from uuid import UUID

import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB
from sqlmodel import Field, Relationship, SQLModel

from ._base import utcnow_field, uuid_pk_field

if TYPE_CHECKING:
    from .booking import Booking
    from .conversation import Conversation


class User(SQLModel, table=True):
    __tablename__ = "users"

    id: UUID = uuid_pk_field()
    phone: str | None = Field(
        default=None,
        sa_column=sa.Column(sa.Text, unique=True),
    )
    email: str | None = Field(
        default=None,
        sa_column=sa.Column(sa.Text),
    )
    first_name: str = Field(
        sa_column=sa.Column(sa.Text, nullable=False, server_default=sa.text("''")),
    )
    last_name: str = Field(
        sa_column=sa.Column(sa.Text, nullable=False, server_default=sa.text("''")),
    )
    preferences: dict | None = Field(
        default=None,
        sa_column=sa.Column(JSONB, server_default=sa.text("'{}'::jsonb")),
    )
    created_at: datetime = utcnow_field()
    expo_push_token: str | None = Field(
        default=None,
        sa_column=sa.Column(sa.Text, nullable=True),
    )
    resy_auth_token: str | None = Field(
        default=None,
        sa_column=sa.Column(sa.Text, nullable=True),
    )
    resy_token_obtained_at: datetime | None = Field(
        default=None,
        sa_column=sa.Column(sa.DateTime(timezone=True), nullable=True),
    )
    updated_at: datetime = utcnow_field()

    bookings: list["Booking"] = Relationship(
        back_populates="user",
        sa_relationship_kwargs={"cascade": "all, delete-orphan", "passive_deletes": True},
    )
    conversations: list["Conversation"] = Relationship(
        back_populates="user",
        sa_relationship_kwargs={"cascade": "all, delete-orphan", "passive_deletes": True},
    )
