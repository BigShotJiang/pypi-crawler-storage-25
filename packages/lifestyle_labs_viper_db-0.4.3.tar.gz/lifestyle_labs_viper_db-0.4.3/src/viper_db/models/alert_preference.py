"""
Alert preference model — stores user-created availability alerts.

Each row is a one-and-done alert: when matching availability slots are found,
``matched_slot_ids`` is populated with the list of matching slot IDs,
``notified_at`` is set, and ``is_active`` is flipped to false.
"""

import datetime as dt
from typing import Optional
from uuid import UUID

import sqlalchemy as sa
from sqlmodel import Field, SQLModel

from ._base import utcnow_field


class AlertPreference(SQLModel, table=True):
    __tablename__ = "alert_preferences"
    __table_args__ = (
        sa.Index(
            "idx_alert_pref_user_active",
            "user_id",
            "is_active",
        ),
        sa.Index(
            "idx_alert_pref_active_experience_ids",
            "experience_ids",
            postgresql_using="gin",
            postgresql_where=sa.text("is_active = true"),
        ),
    )

    id: Optional[int] = Field(
        default=None,
        sa_column=sa.Column(sa.BigInteger, primary_key=True, autoincrement=True),
    )
    user_id: UUID = Field(
        sa_column=sa.Column(
            sa.Uuid,
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
    )
    experience_ids: list[int] = Field(
        sa_column=sa.Column(
            sa.ARRAY(sa.Integer),
            nullable=False,
        ),
    )
    party_sizes: list[int] = Field(
        sa_column=sa.Column(
            sa.ARRAY(sa.SmallInteger),
            nullable=False,
        ),
    )
    dates: list[dt.date] = Field(
        sa_column=sa.Column(
            sa.ARRAY(sa.Date),
            nullable=False,
        ),
    )
    time_start: dt.time = Field(
        sa_column=sa.Column(sa.Time, nullable=False),
    )
    time_end: dt.time = Field(
        sa_column=sa.Column(sa.Time, nullable=False),
    )
    is_active: bool = Field(
        default=True,
        sa_column=sa.Column(
            sa.Boolean,
            nullable=False,
            server_default=sa.text("true"),
        ),
    )
    matched_slot_ids: Optional[list[int]] = Field(
        default=None,
        sa_column=sa.Column(
            sa.ARRAY(sa.BigInteger),
            nullable=True,
        ),
    )
    notified_at: Optional[dt.datetime] = Field(
        default=None,
        sa_column=sa.Column(sa.DateTime(timezone=True), nullable=True),
    )
    created_at: dt.datetime = utcnow_field()
    updated_at: dt.datetime = utcnow_field()
