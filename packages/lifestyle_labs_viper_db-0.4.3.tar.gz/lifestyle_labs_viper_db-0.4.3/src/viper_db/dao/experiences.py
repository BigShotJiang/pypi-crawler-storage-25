"""CRUD operations for the experiences table."""

import datetime as dt
import math
from typing import Optional

from sqlalchemy import text as sa_text
from sqlalchemy.orm import selectinload
from sqlmodel import select

from viper_db.models import Experience
from viper_db.models.restaurant import Restaurant
from viper_db.utils.db import get_session


def _haversine_m(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    """Haversine distance in metres between two lat/lng pairs."""
    R = 6_371_000
    rlat1, rlat2 = math.radians(lat1), math.radians(lat2)
    dlat = math.radians(lat2 - lat1)
    dlng = math.radians(lng2 - lng1)
    a = (
        math.sin(dlat / 2) ** 2
        + math.cos(rlat1) * math.cos(rlat2) * math.sin(dlng / 2) ** 2
    )
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


class ExperiencesDAO:
    @property
    def session(self):
        return get_session()

    async def create(self, data) -> Experience:
        experience = Experience(**data.model_dump())
        self.session.add(experience)
        await self.session.commit()
        await self.session.refresh(experience)
        return experience

    async def get_by_id(self, experience_id: int) -> Optional[Experience]:
        result = await self.session.execute(
            select(Experience)
            .where(Experience.id == experience_id)
            .options(
                selectinload(Experience.restaurant),
                selectinload(Experience.nightlife_detail),
                selectinload(Experience.wellness_detail),
                selectinload(Experience.neighborhood),
                selectinload(Experience.experience_type),
            )
        )
        return result.scalar_one_or_none()

    async def get_by_ids(self, experience_ids: list[int]) -> list[Experience]:
        result = await self.session.execute(
            select(Experience)
            .where(Experience.id.in_(experience_ids))
            .options(
                selectinload(Experience.restaurant),
                selectinload(Experience.nightlife_detail),
                selectinload(Experience.wellness_detail),
                selectinload(Experience.neighborhood),
                selectinload(Experience.experience_type),
            )
        )
        return list(result.scalars().all())

    async def get_all(self) -> list[Experience]:
        result = await self.session.execute(select(Experience))
        return list(result.scalars().all())

    async def get_nearby_candidates(
        self,
        user_lat: float,
        user_lng: float,
        limit: int = 25,
    ) -> list[dict]:
        """Return the N closest active experiences (with Resy info)
        by Haversine distance."""
        stmt = (
            select(Experience)
            .where(
                Experience.latitude.is_not(None),
                Experience.longitude.is_not(None),
                Experience.is_active == True,  # noqa: E712
            )
            .options(selectinload(Experience.restaurant))
        )
        result = await self.session.execute(stmt)
        experiences = list(result.scalars().all())

        scored = []
        for exp in experiences:
            dist = _haversine_m(
                user_lat, user_lng, float(exp.latitude), float(exp.longitude)
            )
            restaurant: Optional[Restaurant] = exp.restaurant
            scored.append(
                {
                    "experience_id": exp.id,
                    "name": exp.name,
                    "address": exp.address,
                    "latitude": float(exp.latitude),
                    "longitude": float(exp.longitude),
                    "distance_m": dist,
                    "resy_venue_id": restaurant.resy_venue_id if restaurant else None,
                    "resy_name": restaurant.resy_name if restaurant else None,
                    "url_slug": restaurant.url_slug if restaurant else None,
                }
            )

        scored.sort(key=lambda c: c["distance_m"])
        return scored[:limit]

    # ── Methods for viper-agents (replaces raw SQL) ──────────────────────

    async def discover_by_embedding(
        self,
        embedding: list[float],
        cuisine: str | None = None,
        neighborhood: str | None = None,
        limit: int = 5,
    ) -> list[dict]:
        """Vector similarity search with optional cuisine/neighborhood filters."""
        sql = (
            "SELECT e.id AS experience_id, e.name, e.description, e.address, "
            "e.vibes, e.categories, e.website, e.booking_rules, "
            "e.cancellation_policy, e.image_urls, "
            "r.cuisine, r.resy_venue_id, r.url_slug, r.appeal_score, "
            "n.name AS neighborhood, "
            "e.embedding <=> :embedding AS distance "
            "FROM experiences e "
            "JOIN restaurants r ON r.experience_id = e.id "
            "LEFT JOIN neighborhoods n ON n.id = e.neighborhood_id "
            "WHERE e.embedding IS NOT NULL "
            "AND r.resy_venue_id IS NOT NULL"
        )
        params: dict = {"embedding": str(embedding)}

        if cuisine:
            sql += (
                " AND EXISTS ("
                "SELECT 1 FROM unnest(r.cuisine) c WHERE c ILIKE :cuisine_pattern"
                ")"
            )
            params["cuisine_pattern"] = f"%{cuisine}%"

        if neighborhood:
            sql += " AND n.name ILIKE :neighborhood_pattern"
            params["neighborhood_pattern"] = f"%{neighborhood}%"

        sql += " ORDER BY distance, r.appeal_score DESC NULLS LAST LIMIT :limit"
        params["limit"] = limit

        result = await self.session.execute(sa_text(sql), params)
        return list(result.fetchall())

    async def fallback_text_search(
        self,
        query: str,
        cuisine: str | None = None,
        neighborhood: str | None = None,
        limit: int = 5,
    ) -> list[dict]:
        """ILIKE fallback when vector search returns no results."""
        sql = (
            "SELECT e.id AS experience_id, e.name, e.description, e.address, "
            "e.vibes, e.categories, e.website, e.booking_rules, "
            "e.cancellation_policy, e.image_urls, "
            "r.cuisine, r.resy_venue_id, r.url_slug, r.appeal_score, "
            "n.name AS neighborhood "
            "FROM experiences e "
            "JOIN restaurants r ON r.experience_id = e.id "
            "LEFT JOIN neighborhoods n ON n.id = e.neighborhood_id "
            "WHERE r.resy_venue_id IS NOT NULL"
        )
        params: dict = {}

        if cuisine:
            sql += (
                " AND EXISTS ("
                "SELECT 1 FROM unnest(r.cuisine) c WHERE c ILIKE :cuisine_pattern"
                ")"
            )
            params["cuisine_pattern"] = f"%{cuisine}%"

        if neighborhood:
            sql += " AND n.name ILIKE :neighborhood_pattern"
            params["neighborhood_pattern"] = f"%{neighborhood}%"

        if query:
            sql += " AND (e.name ILIKE :q OR e.description ILIKE :q)"
            params["q"] = f"%{query}%"

        sql += " ORDER BY r.appeal_score DESC NULLS LAST LIMIT :limit"
        params["limit"] = limit

        result = await self.session.execute(sa_text(sql), params)
        return list(result.fetchall())

    async def hybrid_discover(
        self,
        embedding: list[float],
        query_text: str,
        cuisine: str | None = None,
        neighborhood: str | None = None,
        similarity_threshold: float = 0.6,
        limit: int = 50,
        vector_weight: float = 0.7,
        text_weight: float = 0.3,
        rrf_k: int = 60,
    ) -> list[dict]:
        """Hybrid search combining HNSW vector + full-text with RRF fusion.

        Each CTE fetches up to ``limit`` candidates so the fused pool is
        large enough for a downstream reranker to pick from.
        """
        cuisine_filter = ""
        neighborhood_filter = ""
        params: dict = {
            "embedding": str(embedding),
            "query": query_text,
            "threshold": similarity_threshold,
            "limit": limit,
            "vector_weight": vector_weight,
            "text_weight": text_weight,
            "rrf_k": rrf_k,
        }

        if cuisine:
            cuisine_filter = (
                " AND EXISTS ("
                "SELECT 1 FROM unnest(r.cuisine) c "
                "WHERE c ILIKE :cuisine_pattern)"
            )
            params["cuisine_pattern"] = f"%{cuisine}%"

        if neighborhood:
            neighborhood_filter = " AND n.name ILIKE :neighborhood_pattern"
            params["neighborhood_pattern"] = f"%{neighborhood}%"

        sql = (
            "WITH vector_hits AS ("
            "  SELECT e.id,"
            "    e.embedding <=> :embedding AS vdist,"
            "    ROW_NUMBER() OVER ("
            "      ORDER BY e.embedding <=> :embedding"
            "    ) AS vrank"
            "  FROM experiences e"
            "  JOIN restaurants r ON r.experience_id = e.id"
            "  LEFT JOIN neighborhoods n ON n.id = e.neighborhood_id"
            "  WHERE e.embedding IS NOT NULL"
            "    AND r.resy_venue_id IS NOT NULL"
            "    AND e.embedding <=> :embedding < :threshold"
            f"   {cuisine_filter}{neighborhood_filter}"
            "  ORDER BY vdist"
            "  LIMIT :limit"
            "), "
            "text_hits AS ("
            "  SELECT e.id,"
            "    ts_rank_cd(e.search_vector,"
            "      to_tsquery('english',"
            "        array_to_string("
            "          array(SELECT lexeme FROM unnest(to_tsvector('english', :query))),"
            "          ' | '"
            "        )"
            "      )"
            "    ) AS tscore,"
            "    ROW_NUMBER() OVER ("
            "      ORDER BY ts_rank_cd(e.search_vector,"
            "        to_tsquery('english',"
            "          array_to_string("
            "            array("
            "              SELECT lexeme "
            "              FROM unnest(to_tsvector('english', :query))"
            "            ),"
            "            ' | '"
            "          )"
            "        )"
            "      ) DESC"
            "    ) AS trank"
            "  FROM experiences e"
            "  JOIN restaurants r ON r.experience_id = e.id"
            "  LEFT JOIN neighborhoods n ON n.id = e.neighborhood_id"
            "  WHERE e.search_vector @@ to_tsquery('english',"
            "    array_to_string("
            "      array(SELECT lexeme FROM unnest(to_tsvector('english', :query))),"
            "      ' | '"
            "    )"
            "  )"
            "    AND r.resy_venue_id IS NOT NULL"
            f"   {cuisine_filter}{neighborhood_filter}"
            "  LIMIT :limit"
            "), "
            "fused AS ("
            "  SELECT COALESCE(v.id, t.id) AS id,"
            "    :vector_weight * COALESCE(1.0 / (:rrf_k + v.vrank), 0) +"
            "    :text_weight * COALESCE(1.0 / (:rrf_k + t.trank), 0)"
            "      AS rrf_score"
            "  FROM vector_hits v"
            "  FULL OUTER JOIN text_hits t ON v.id = t.id"
            "  ORDER BY rrf_score DESC"
            "  LIMIT :limit"
            ") "
            "SELECT e.id AS experience_id, e.name, e.description,"
            "  e.address, e.vibes, e.categories, e.website,"
            "  e.booking_rules, e.cancellation_policy, e.image_urls,"
            "  r.cuisine, r.resy_venue_id, r.url_slug, r.appeal_score,"
            "  n.name AS neighborhood,"
            "  f.rrf_score"
            " FROM fused f"
            " JOIN experiences e ON e.id = f.id"
            " JOIN restaurants r ON r.experience_id = e.id"
            " LEFT JOIN neighborhoods n ON n.id = e.neighborhood_id"
            " ORDER BY f.rrf_score DESC"
        )

        result = await self.session.execute(sa_text(sql), params)
        return list(result.fetchall())

    async def get_restaurant_by_name(self, name: str, limit: int = 3):
        """Fuzzy name lookup using trigram similarity + ILIKE fallback."""
        sql = (
            "SELECT e.id AS experience_id, e.name, e.description, e.address, "
            "e.vibes, e.categories, e.website, e.booking_rules, "
            "e.cancellation_policy, e.image_urls, "
            "r.cuisine, r.resy_venue_id, r.url_slug, r.appeal_score, "
            "n.name AS neighborhood, "
            "similarity(e.name, :name) AS sim "
            "FROM experiences e "
            "JOIN restaurants r ON r.experience_id = e.id "
            "LEFT JOIN neighborhoods n ON n.id = e.neighborhood_id "
            "WHERE similarity(e.name, :name) > 0.3 "
            "   OR e.name ILIKE :name_pattern "
            "ORDER BY sim DESC "
            "LIMIT :limit"
        )
        result = await self.session.execute(
            sa_text(sql),
            {"name": name, "name_pattern": f"%{name}%", "limit": limit},
        )
        return list(result.fetchall())

    async def list_cuisines_and_neighborhoods(self) -> dict:
        """Aggregate query returning available cuisines,
        neighborhoods, and total count."""
        cuisine_result = await self.session.execute(
            sa_text(
                "SELECT array_agg(DISTINCT c) AS cuisines "
                "FROM restaurants r, unnest(r.cuisine) c "
                "WHERE r.resy_venue_id IS NOT NULL"
            )
        )
        cuisine_row = cuisine_result.fetchone()
        cuisines = sorted(cuisine_row.cuisines or []) if cuisine_row else []

        neighborhood_result = await self.session.execute(
            sa_text(
                "SELECT array_agg(DISTINCT n.name) AS neighborhoods "
                "FROM neighborhoods n "
                "JOIN experiences e ON e.neighborhood_id = n.id "
                "JOIN restaurants r ON r.experience_id = e.id "
                "WHERE r.resy_venue_id IS NOT NULL"
            )
        )
        nbhd_row = neighborhood_result.fetchone()
        neighborhoods = sorted(nbhd_row.neighborhoods or []) if nbhd_row else []

        count_result = await self.session.execute(
            sa_text("SELECT COUNT(*) FROM restaurants WHERE resy_venue_id IS NOT NULL")
        )
        total = count_result.scalar() or 0

        return {
            "cuisines": cuisines,
            "neighborhoods": neighborhoods,
            "total_restaurants": total,
        }

    async def get_restaurant_cards(
        self,
        experience_ids: list[int],
        party_size: int | None = None,
        date: str | None = None,
    ) -> list[dict]:
        """Card data for UI presentation given a list of experience IDs.

        When party_size and date are provided, each card includes
        availability_slots from the pre-scraped data.
        """
        if not experience_ids:
            return []

        placeholders = ", ".join(f":id_{i}" for i in range(len(experience_ids)))
        params: dict = {f"id_{i}": eid for i, eid in enumerate(experience_ids)}

        sql = (
            "SELECT e.id AS experience_id, e.name, e.image_urls, "
            "e.address, e.latitude, e.longitude, "
            "r.cuisine, r.url_slug, "
            "n.name AS neighborhood "
            "FROM experiences e "
            "JOIN restaurants r ON r.experience_id = e.id "
            "LEFT JOIN neighborhoods n ON n.id = e.neighborhood_id "
            f"WHERE e.id IN ({placeholders})"
        )

        result = await self.session.execute(sa_text(sql), params)
        rows = result.fetchall()

        cards = [
            {
                "name": row.name or "",
                "cuisine": row.cuisine or [],
                "neighborhood": row.neighborhood or "",
                "experience_id": row.experience_id,
                "image_urls": row.image_urls or [],
                "url_slug": row.url_slug or "",
                "address": row.address or "",
                "latitude": float(row.latitude) if row.latitude is not None else None,
                "longitude": float(row.longitude) if row.longitude is not None else None,
                "availability_slots": [],
            }
            for row in rows
        ]

        if party_size is not None and date is not None:
            normalized_ps = 4 if party_size == 3 else party_size
            slot_sql = (
                "SELECT experience_id, time, slot_type, date "
                "FROM availability_slots "
                f"WHERE experience_id IN ({placeholders}) "
                "AND date = :slot_date "
                "AND party_size = :slot_party_size "
                "AND is_available = true "
                "ORDER BY time"
            )
            slot_date = dt.date.fromisoformat(date) if isinstance(date, str) else date
            slot_params = {
                **params,
                "slot_date": slot_date,
                "slot_party_size": normalized_ps,
            }
            slot_result = await self.session.execute(sa_text(slot_sql), slot_params)
            slot_rows = slot_result.fetchall()

            slots_by_exp: dict[int, list[dict]] = {}
            for sr in slot_rows:
                slots_by_exp.setdefault(sr.experience_id, []).append(
                    {
                        "time": sr.time.strftime("%H:%M") if sr.time else "",
                        "slot_type": sr.slot_type or "",
                        "date": sr.date.isoformat() if sr.date else "",
                    }
                )

            for card in cards:
                card["availability_slots"] = slots_by_exp.get(card["experience_id"], [])

        return cards


experiences_dao = ExperiencesDAO()
