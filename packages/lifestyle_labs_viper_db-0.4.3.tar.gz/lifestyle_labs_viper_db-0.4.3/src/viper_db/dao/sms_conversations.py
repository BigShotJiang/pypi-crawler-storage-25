"""CRUD operations for the sms_conversations table."""

import logging
from datetime import datetime, timezone

from sqlmodel import select

from viper_db.models.sms_conversation import SmsConversation
from viper_db.utils.db import get_session

logger = logging.getLogger(__name__)


class SmsConversationsDAO:
    @property
    def session(self):
        return get_session()

    async def get_by_phone(self, phone_number: str) -> SmsConversation | None:
        result = await self.session.execute(
            select(SmsConversation).where(SmsConversation.phone_number == phone_number)
        )
        return result.scalar_one_or_none()

    async def create(self, data: SmsConversation) -> SmsConversation:
        self.session.add(data)
        await self.session.commit()
        await self.session.refresh(data)
        return data

    async def update_last_message(self, conv_id: int) -> None:
        conv = await self.session.get(SmsConversation, conv_id)
        if conv:
            conv.last_message_at = datetime.now(timezone.utc)
            self.session.add(conv)
            await self.session.commit()


sms_conversations_dao = SmsConversationsDAO()
