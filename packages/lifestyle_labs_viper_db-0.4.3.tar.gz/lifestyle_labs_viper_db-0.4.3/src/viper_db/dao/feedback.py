"""CRUD operations for the feedback table."""

from uuid import UUID

from sqlmodel import select

from viper_db.models.feedback import Feedback
from viper_db.utils.db import get_session


class FeedbackDAO:
    @property
    def session(self):
        return get_session()

    async def create(self, user_id: UUID, message: str) -> Feedback:
        feedback = Feedback(user_id=user_id, message=message)
        self.session.add(feedback)
        await self.session.commit()
        await self.session.refresh(feedback)
        return feedback

    async def get_all(self) -> list[Feedback]:
        result = await self.session.execute(
            select(Feedback).order_by(Feedback.created_at.desc())
        )
        return list(result.scalars().all())


feedback_dao = FeedbackDAO()
