"""CRUD operations for the messages table."""

from typing import Optional

from sqlmodel import select

from viper_db.models import Message
from viper_db.utils.db import get_session


class MessagesDAO:
    @property
    def session(self):
        return get_session()

    async def get_by_id(self, message_id: int) -> Optional[Message]:
        return await self.session.get(Message, message_id)

    async def get_by_conversation_id(self, conversation_id: int) -> list[Message]:
        statement = (
            select(Message)
            .where(Message.conversation_id == conversation_id)
            .order_by(Message.created_at)
        )
        result = await self.session.execute(statement)
        return list(result.scalars().all())

    async def create(self, data) -> Message:
        message = Message.model_validate(data)
        self.session.add(message)
        await self.session.commit()
        await self.session.refresh(message)
        return message

    async def delete(self, message_id: int) -> bool:
        message = await self.session.get(Message, message_id)
        if not message:
            return False
        await self.session.delete(message)
        await self.session.commit()
        return True


messages_dao = MessagesDAO()
