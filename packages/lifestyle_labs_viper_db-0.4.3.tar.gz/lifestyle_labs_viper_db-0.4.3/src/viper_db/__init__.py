"""viper-db: shared database layer for Viper services."""

from viper_db.client import DbClient, create_db_client

__all__ = [
    "DbClient",
    "create_db_client",
]
