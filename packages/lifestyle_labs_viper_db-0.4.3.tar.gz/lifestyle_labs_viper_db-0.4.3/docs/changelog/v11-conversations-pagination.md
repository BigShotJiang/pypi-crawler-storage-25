# v11 — Add pagination and server-side ordering to conversations DAO

## Summary

`get_all_by_user()` now accepts `limit` and `offset` keyword arguments and returns conversations ordered by `created_at DESC`. Previously it returned every conversation for a user with no ordering, causing increasingly slow responses as chat history grew.

## Changes

### DAO: `get_all_by_user` (`dao/conversations.py`)
- Added `limit: int = 50` and `offset: int = 0` keyword-only parameters
- Query now applies `ORDER BY created_at DESC`, `.limit()`, and `.offset()`
- Default behaviour (`limit=50, offset=0`) is backwards-compatible; callers that need fewer rows (e.g. the SideMenu) pass `limit=10`

## Affected Paths
- `src/viper_db/dao/conversations.py`
