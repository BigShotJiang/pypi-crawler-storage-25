# v8 — Hybrid Search Tuning: Cuisine in FTS, Threshold Fix, OR-based Queries

## Summary

Fixed two issues that caused the hybrid search to return only 2 results for broad queries like "find me italian food". The vector path was blocked by an overly aggressive similarity threshold, and the full-text path missed most restaurants because cuisine data wasn't in the `search_vector` and the tsquery required all terms to match.

## Changes

### Migration `0019_search_vector_include_cuisine.py`
- Drops the `GENERATED ALWAYS` tsvector column (which could only reference `experiences.name` and `experiences.description`)
- Replaces it with a trigger-maintained `search_vector` that includes cuisine from the `restaurants` table
- Two triggers: `trg_experiences_search_vector` fires on experience INSERT/UPDATE of name or description; `trg_restaurants_sync_search_vector` fires on restaurant INSERT/UPDATE of cuisine
- Backfills all existing rows with `name + description + cuisine`

### Model Update: `Experience` (`models/experience.py`)
- Removed `sa.Computed()` from the `search_vector` column since it's now trigger-maintained instead of a generated column

### DAO: `hybrid_discover` (`dao/experiences.py`)
- Raised default `similarity_threshold` from `0.4` to `0.75` (cosine distance). The old value filtered out all results for short/generic queries because no embedding was within 0.4 cosine distance of "Italian food"
- Switched FTS from `plainto_tsquery` (AND between all terms) to an OR-based `to_tsquery` built from individual lexemes. "Italian food" now matches any restaurant containing "italian" OR "food" instead of requiring both

## Impact

| Query | Before | After |
|-------|--------|-------|
| "find me italian food" | 2 results, scores ~0.005 | 5 results, scores ~0.014-0.016 |
| "romantic dinner spot" | untested | 5 results |
| "casual pizza place" | untested | 5 results |

## Affected Paths
- `alembic/versions/0019_search_vector_include_cuisine.py`
- `src/viper_db/models/experience.py`
- `src/viper_db/dao/experiences.py`
