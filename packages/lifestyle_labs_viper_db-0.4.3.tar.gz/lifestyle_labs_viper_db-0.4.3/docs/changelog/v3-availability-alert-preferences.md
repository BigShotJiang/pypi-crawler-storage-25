# v3 — Availability Alert Preferences

## Summary

Added the `AlertPreference` model and DAO for user-created availability alerts, plus `expo_push_token` on the `User` model for push notification delivery.

## Changes

### New Model: `AlertPreference` (`models/alert_preference.py`)
- One-and-done alert model: `matched_slot_id` FK to `availability_slots`, `notified_at`, `is_active` flag
- Fields: `user_id`, `experience_id`, `party_sizes` (array), `dates` (array), `time_start`, `time_end`
- Indexes: `idx_alert_pref_user_active`, `idx_alert_pref_active_experience` (partial on `is_active = true`)

### New DAO: `AlertPreferencesDAO` (`dao/alert_preferences.py`)
- `create`, `get_by_user`, `get_all_active`, `get_matched_by_user`, `mark_matched`, `deactivate`, `delete`

### User Model Update
- Added nullable `expo_push_token` (Text) column to `users` table

### Migrations
- `0011_add_expo_push_token_to_users.py` — adds `expo_push_token` column
- `0012_create_alert_preferences.py` — creates `alert_preferences` table with indexes

### Registration
- `AlertPreference` registered in `models/__init__.py`
- `AlertPreferencesDAO` + `alert_preferences_dao` registered in `dao/__init__.py`
