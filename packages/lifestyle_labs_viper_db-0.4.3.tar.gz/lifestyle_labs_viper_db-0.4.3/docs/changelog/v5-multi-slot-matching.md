# v5 — Multi-Slot Alert Matching

## Summary

Replaced the single `matched_slot_id` FK on `alert_preferences` with a `matched_slot_ids` integer array column, enabling alerts to store references to multiple matched availability slots.

## Changes

### Migration `0014_matched_slot_id_to_matched_slot_ids.py`
- Adds `matched_slot_ids` column (`ARRAY(BigInteger)`, nullable)
- Migrates existing data: `UPDATE alert_preferences SET matched_slot_ids = ARRAY[matched_slot_id] WHERE matched_slot_id IS NOT NULL`
- Drops old `matched_slot_id` column and its FK constraint `alert_preferences_matched_slot_id_fkey`
- Downgrade reverses by taking `matched_slot_ids[1]` back into a scalar column and re-creating the FK

### Model Update: `AlertPreference` (`models/alert_preference.py`)
- `matched_slot_id: Optional[int]` (single FK) replaced with `matched_slot_ids: Optional[list[int]]` (`ARRAY(BigInteger)`)
- FK constraint removed (arrays can't have FKs; referential integrity maintained at application layer)

### DAO Update: `AlertPreferencesDAO` (`dao/alert_preferences.py`)
- `get_matched_by_user()`: filters on `AlertPreference.matched_slot_ids.isnot(None)`
- `get_all_active()`: filters on `AlertPreference.matched_slot_ids.is_(None)`
- `mark_matched()`: now accepts `slot_ids: list[int]` and sets `pref.matched_slot_ids = slot_ids`

## Nuances
- The array column is nullable rather than defaulting to `[]` so that `IS NULL` checks cleanly distinguish unmatched alerts from matched ones with zero slots
- No FK enforcement on the array; the cron worker and API handle missing slot IDs gracefully
