# v7 — Appeal Score Column

## Summary

Added `appeal_score` (SmallInteger, nullable) to the `restaurants` table, sourced from the "Coolness Factor (1-5)" column in the CSV. Discovery queries now SELECT and sort by this field as a secondary tiebreaker.

## Changes

### Model: `Restaurant` (`models/restaurant.py`)
- Added `appeal_score: int | None` field backed by `sa.SmallInteger`, defaulting to `None`

### Migration `0018_add_appeal_score_to_restaurants.py`
- Adds nullable `appeal_score SMALLINT` column to the `restaurants` table

### DAO: Discovery Queries (`dao/experiences.py`)
- `hybrid_discover` — `r.appeal_score` added to SELECT; secondary ORDER BY `r.appeal_score DESC NULLS LAST` after `rrf_score`
- `discover_by_embedding` — `r.appeal_score` added to SELECT; secondary ORDER BY after `distance`
- `fallback_text_search` — `r.appeal_score` added to SELECT; ORDER BY `r.appeal_score DESC NULLS LAST`
- `get_restaurant_by_name` — `r.appeal_score` added to SELECT (sort unchanged, stays by trigram similarity)

## Affected Paths
- `src/viper_db/models/restaurant.py`
- `src/viper_db/dao/experiences.py`
- `alembic/versions/0018_add_appeal_score_to_restaurants.py`
