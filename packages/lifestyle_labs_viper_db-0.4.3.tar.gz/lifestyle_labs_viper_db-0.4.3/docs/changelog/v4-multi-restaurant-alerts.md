# v4 — Multi-Restaurant Alerts

## Summary

Replaced the single `experience_id` FK on `alert_preferences` with an `experience_ids` integer array column, enabling users to create alerts that monitor multiple restaurants at once. Also added a `search` text filter to the restaurants DAO.

## Changes

### Migration `0013_experience_id_to_experience_ids.py`
- Adds `experience_ids` column (`ARRAY(Integer)`, initially nullable)
- Migrates existing data: `UPDATE alert_preferences SET experience_ids = ARRAY[experience_id]`
- Sets `experience_ids` to `NOT NULL`
- Drops old `experience_id` column, its FK constraint, and `idx_alert_pref_active_experience` index
- Creates GIN index `idx_alert_pref_active_experience_ids` for efficient `ANY()` queries

### Model Update: `AlertPreference` (`models/alert_preference.py`)
- `experience_id: int` (single FK) replaced with `experience_ids: list[int]` (`ARRAY(Integer)`)
- FK constraint removed (arrays can't have FKs; max 5 items enforced at API layer)
- Index updated from B-tree partial to GIN partial

### DAO Update: `RestaurantsDAO` (`dao/restaurants.py`)
- `get_filtered()` now accepts an optional `search: str` keyword argument
- When provided, applies `Experience.name.ilike(f"%{search}%")` filter

## Nuances
- The `AlertPreferencesDAO.create()` method uses `**kwargs` so it naturally accepts `experience_ids` without code changes
- No FK enforcement on the array, but the cron job handles missing experiences gracefully (skips them)
- The `search` parameter uses ILIKE for case-insensitive partial matching on experience name
