# v9 — `time_to` Upper-Bound Filter for Availability Slot Queries

## Summary

Added a `time_to` parameter to the availability slot DAO so queries can filter by a maximum time, not just a minimum. Previously, only `time_from` (earliest acceptable time) was supported, causing time-range requests like "1-3 PM" to return all slots from 1 PM onward with no upper bound.

## Changes

### DAO: `get_experiences_available_on_date` (`dao/availability_slots.py`)
- Added `time_to: Optional[dt.time] = None` parameter
- When provided, appends `AND a.time <= :time_to` to the SQL query
- Mirrors the existing `time_from` pattern; fully backward-compatible (omitting `time_to` preserves old behavior)

## Affected Paths
- `src/viper_db/dao/availability_slots.py`
