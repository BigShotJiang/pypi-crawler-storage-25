# v10 — Add address, latitude, longitude to restaurant card query

## Summary

Extended `get_restaurant_cards()` to include `address`, `latitude`, and `longitude` from the `experiences` table. These fields were already present in the DB but not selected in the card query, preventing the mobile chat UI from placing restaurant pins on a map.

## Changes

### DAO: `get_restaurant_cards` (`dao/experiences.py`)
- Added `e.address`, `e.latitude`, `e.longitude` to the SELECT clause
- Added `address`, `latitude`, `longitude` to the returned card dict
- `latitude`/`longitude` are cast to `float` (from `Numeric(9,6)`) with `None` passthrough for nulls

## Affected Paths
- `src/viper_db/dao/experiences.py`
