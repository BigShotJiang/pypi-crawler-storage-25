# v6 — Hybrid Search with HNSW, Full-Text, and Trigram Matching

## Summary

Upgraded restaurant discovery from brute-force vector scan + ILIKE fallback to a hybrid search system combining HNSW-indexed vector search, full-text search with tsvector/GIN, and Reciprocal Rank Fusion (RRF) scoring — all within Postgres. Also added trigram-based fuzzy name matching.

## Changes

### Migration `0017_add_hnsw_index_and_fts.py`
- HNSW index on `experiences.embedding` using `vector_cosine_ops` (m=16, ef_construction=64) — turns O(n) brute-force scans into sub-linear ANN lookups
- Generated `search_vector` tsvector column on `experiences` that auto-updates from `name` and `description`, with a GIN index
- `pg_trgm` extension enabled with a trigram GIN index on `experiences.name` for fuzzy name lookups

### Model Update: `Experience` (`models/experience.py`)
- Added `search_vector: Any` field with `sa.Computed` + `TSVECTOR` type so Alembic autogenerate stays in sync and the column is visible to the ORM

### DAO: `hybrid_discover` (`dao/experiences.py`)
- New method running a single SQL query with two CTEs (vector_hits + text_hits) fused via RRF
- Configurable `vector_weight`, `text_weight`, `rrf_k`, and `similarity_threshold` parameters
- Cuisine and neighborhood filters applied inside both CTEs so indexes do the heavy lifting
- Existing `discover_by_embedding` and `fallback_text_search` kept as deprecated fallbacks

### DAO: `get_restaurant_by_name` (`dao/experiences.py`)
- Replaced pure ILIKE with `similarity()` trigram matching + ILIKE fallback, ordered by similarity score descending
- Handles typos ("Carbne" -> "Carbone"), case insensitivity, and partial matches

### Test Infrastructure
- Added `pytest`, `pytest-asyncio`, `openai`, `greenlet`, `python-dotenv` to dev dependencies
- `tests/conftest.py` with async DB session and OpenAI client fixtures
- `tests/test_migration_0017.py` — 6 tests verifying all migration artifacts
- `tests/test_hybrid_search.py` — 10 tests covering RRF fusion, semantic queries, keyword queries, cuisine/neighborhood filters, threshold filtering, score ordering, and hybrid-vs-vector-only comparison
- `tests/test_trigram_search.py` — 5 tests covering exact match, typo tolerance, case insensitivity, no-match, and partial name

## Nuances
- `similarity_threshold=0.4` (cosine distance) filters truly irrelevant results before ranking; 0.4 distance = 0.6 similarity
- `rrf_k=60` is the standard constant from the Cormack et al. paper
- The generated tsvector column means no application code needed to keep FTS in sync
- HNSW parameters (m=16, ef_construction=64) are tuned for a collection of a few hundred rows
