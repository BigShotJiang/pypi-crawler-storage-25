# Changelog

## [0.5.0] - 2026-04-13

### Added

- **HNSW index** on `experiences.embedding` using `vector_cosine_ops` for sub-linear ANN lookups (migration 0017)
- **Generated `search_vector` tsvector column** on `experiences` with GIN index for full-text search
- **`pg_trgm` extension** and trigram GIN index on `experiences.name` for fuzzy name matching
- **`hybrid_discover` DAO method** combining HNSW vector search + full-text search via Reciprocal Rank Fusion (RRF), with configurable weights, similarity threshold, and cuisine/neighborhood filters
- **`search_vector` field** on the `Experience` SQLModel class (`GENERATED ALWAYS` computed column)
- **Test infrastructure**: pytest + pytest-asyncio dev dependencies, async DB session fixtures, OpenAI client fixtures
- **Integration tests**: migration verification (6 tests), hybrid search (10 tests), trigram name search (5 tests)

### Changed

- **`get_restaurant_by_name`** now uses trigram `similarity()` with ILIKE fallback instead of pure ILIKE, enabling typo tolerance and fuzzy partial matching
