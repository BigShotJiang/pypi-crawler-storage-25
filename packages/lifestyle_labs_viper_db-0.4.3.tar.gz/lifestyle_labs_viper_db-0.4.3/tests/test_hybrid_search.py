"""Integration tests for ExperiencesDAO.hybrid_discover against live DB + OpenAI."""

import pytest
from openai import AsyncOpenAI

from viper_db.config import settings
from viper_db.dao.experiences import ExperiencesDAO

EMBEDDING_MODEL = settings.get("OPENAI.embedding_model", "text-embedding-3-small")

SEMANTIC_QUERIES = [
    "romantic Italian dinner",
    "trendy Asian restaurant with a view",
    "lively Mexican spot for a group celebration",
]


async def _embed(client: AsyncOpenAI, query: str) -> list[float]:
    resp = await client.embeddings.create(model=EMBEDDING_MODEL, input=query)
    return resp.data[0].embedding


@pytest.fixture
def dao(db_session):
    d = ExperiencesDAO()
    d._test_session = db_session
    return d


@pytest.fixture(autouse=True)
def _patch_dao_session(dao, db_session, monkeypatch):
    monkeypatch.setattr(
        ExperiencesDAO,
        "session",
        property(lambda self: db_session),
    )


@pytest.mark.parametrize("query", SEMANTIC_QUERIES)
async def test_hybrid_returns_results(dao, openai_client, query):
    embedding = await _embed(openai_client, query)
    rows = await dao.hybrid_discover(
        embedding=embedding,
        query_text=query,
        similarity_threshold=0.6,
    )
    assert len(rows) > 0, f"No results for: {query}"
    assert all(r.rrf_score > 0 for r in rows), (
        "All results should have positive rrf_score"
    )


async def test_hybrid_semantic_query(dao, openai_client):
    """Query with no exact keyword matches — vector path should contribute."""
    query = "somewhere intimate for a special occasion"
    embedding = await _embed(openai_client, query)
    rows = await dao.hybrid_discover(
        embedding=embedding,
        query_text=query,
        similarity_threshold=0.75,
    )
    assert len(rows) > 0, "Semantic-only query returned no results"


async def test_hybrid_keyword_query(dao, openai_client):
    """Exact restaurant name — FTS should boost it to the top."""
    query = "Carbone"
    embedding = await _embed(openai_client, query)
    rows = await dao.hybrid_discover(embedding=embedding, query_text=query)
    assert len(rows) > 0, "Keyword query returned no results"
    top_name = rows[0].name.lower()
    assert "carbone" in top_name, f"Expected 'Carbone' at top, got '{rows[0].name}'"


async def test_hybrid_cuisine_filter(dao, openai_client):
    query = "good dinner spot"
    embedding = await _embed(openai_client, query)
    rows = await dao.hybrid_discover(
        embedding=embedding,
        query_text=query,
        cuisine="Italian",
    )
    for r in rows:
        cuisines_lower = [c.lower() for c in (r.cuisine or [])]
        assert any("italian" in c for c in cuisines_lower), (
            f"Expected Italian cuisine, got {r.cuisine}"
        )


async def test_hybrid_neighborhood_filter(dao, openai_client):
    query = "nice restaurant"
    embedding = await _embed(openai_client, query)
    rows = await dao.hybrid_discover(
        embedding=embedding,
        query_text=query,
        neighborhood="West Village",
    )
    for r in rows:
        assert "west village" in (r.neighborhood or "").lower(), (
            f"Expected West Village, got '{r.neighborhood}'"
        )


async def test_hybrid_threshold_filters_irrelevant(dao, openai_client):
    query = "underwater volcano dining on Mars"
    embedding = await _embed(openai_client, query)
    rows = await dao.hybrid_discover(
        embedding=embedding,
        query_text=query,
        similarity_threshold=0.3,
    )
    assert len(rows) <= 2, f"Nonsensical query returned {len(rows)} results"


async def test_hybrid_results_ordered_by_score(dao, openai_client):
    query = "romantic Italian dinner"
    embedding = await _embed(openai_client, query)
    rows = await dao.hybrid_discover(embedding=embedding, query_text=query, limit=10)
    scores = [r.rrf_score for r in rows]
    assert scores == sorted(scores, reverse=True), (
        "Results not ordered by rrf_score descending"
    )


async def test_hybrid_beats_vector_only(dao, openai_client):
    """Hybrid should rank 'Carbone' at least as high as vector-only."""
    query = "Carbone Italian Greenwich Village"
    embedding = await _embed(openai_client, query)

    hybrid_rows = await dao.hybrid_discover(
        embedding=embedding, query_text=query, limit=10
    )
    vector_rows = await dao.discover_by_embedding(embedding=embedding, limit=10)

    def _find_rank(rows, name_fragment):
        for i, r in enumerate(rows):
            if name_fragment.lower() in r.name.lower():
                return i
        return len(rows)

    hybrid_rank = _find_rank(hybrid_rows, "Carbone")
    vector_rank = _find_rank(vector_rows, "Carbone")
    assert hybrid_rank <= vector_rank, (
        f"Hybrid rank {hybrid_rank} worse than vector rank {vector_rank}"
    )
