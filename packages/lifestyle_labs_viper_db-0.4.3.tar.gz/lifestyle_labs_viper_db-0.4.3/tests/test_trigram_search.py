"""Integration tests for get_restaurant_by_name with trigram similarity."""

import pytest

from viper_db.dao.experiences import ExperiencesDAO


@pytest.fixture
def dao(db_session):
    return ExperiencesDAO()


@pytest.fixture(autouse=True)
def _patch_dao_session(dao, db_session, monkeypatch):
    monkeypatch.setattr(
        ExperiencesDAO,
        "session",
        property(lambda self: db_session),
    )


async def test_exact_name_match(dao):
    rows = await dao.get_restaurant_by_name("Carbone")
    assert len(rows) > 0, "Exact match for 'Carbone' returned nothing"
    assert any("carbone" in r.name.lower() for r in rows), "Carbone not in results"


async def test_typo_tolerance(dao):
    rows = await dao.get_restaurant_by_name("Carbne")
    assert len(rows) > 0, "Typo 'Carbne' returned nothing"
    assert any("carbone" in r.name.lower() for r in rows), "Carbone not found via typo"


async def test_case_insensitive(dao):
    rows = await dao.get_restaurant_by_name("carbone")
    assert len(rows) > 0, "Lowercase 'carbone' returned nothing"
    assert any("carbone" in r.name.lower() for r in rows), (
        "Carbone not found case-insensitive"
    )


async def test_no_match_returns_empty(dao):
    rows = await dao.get_restaurant_by_name("zzzznonexistent")
    assert len(rows) == 0, f"Nonsense name returned {len(rows)} results"


async def test_partial_name(dao):
    rows = await dao.get_restaurant_by_name("Carb")
    assert len(rows) > 0, "Partial name 'Carb' returned nothing"
    assert any("carbone" in r.name.lower() for r in rows), (
        "Carbone not found via partial name"
    )
