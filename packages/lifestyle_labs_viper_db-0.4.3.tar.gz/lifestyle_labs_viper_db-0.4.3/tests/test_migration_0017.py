"""Verify migration 0017 artifacts exist in the live database."""

from sqlalchemy import text


async def test_hnsw_index_exists(db_session):
    result = await db_session.execute(
        text(
            "SELECT indexname FROM pg_indexes "
            "WHERE indexname = 'idx_experiences_embedding_hnsw'"
        )
    )
    row = result.fetchone()
    assert row is not None, "HNSW index not found"


async def test_search_vector_column_populated(db_session):
    total = (await db_session.execute(text("SELECT COUNT(*) FROM experiences"))).scalar()
    populated = (
        await db_session.execute(
            text("SELECT COUNT(*) FROM experiences WHERE search_vector IS NOT NULL")
        )
    ).scalar()
    assert populated == total, f"search_vector populated for {populated}/{total} rows"


async def test_pg_trgm_extension_enabled(db_session):
    result = await db_session.execute(
        text("SELECT extname FROM pg_extension WHERE extname = 'pg_trgm'")
    )
    row = result.fetchone()
    assert row is not None, "pg_trgm extension not enabled"


async def test_trigram_index_exists(db_session):
    result = await db_session.execute(
        text(
            "SELECT indexname FROM pg_indexes "
            "WHERE indexname = 'idx_experiences_name_trgm'"
        )
    )
    row = result.fetchone()
    assert row is not None, "Trigram index not found"


async def test_fts_gin_index_exists(db_session):
    result = await db_session.execute(
        text(
            "SELECT indexname FROM pg_indexes "
            "WHERE indexname = 'idx_experiences_search_vector'"
        )
    )
    row = result.fetchone()
    assert row is not None, "FTS GIN index not found"


async def test_search_vector_content_is_valid(db_session):
    row = (
        await db_session.execute(
            text(
                "SELECT name, search_vector::text "
                "FROM experiences "
                "WHERE name IS NOT NULL "
                "LIMIT 1"
            )
        )
    ).fetchone()
    assert row is not None, "No experiences found"
    assert row[1] is not None, f"search_vector is NULL for '{row[0]}'"
    assert len(row[1]) > 0, f"search_vector is empty for '{row[0]}'"
