import pytest
from openai import AsyncOpenAI
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine

from viper_db.config import settings

EMBEDDING_MODEL = settings.get("OPENAI.embedding_model", "text-embedding-3-small")


def _get_async_url() -> str:
    url = settings.get("SUPABASE.db_url", "")
    assert url, "SUPABASE.db_url must be set"
    return url.replace("postgresql://", "postgresql+asyncpg://")


@pytest.fixture
async def db_session():
    engine = create_async_engine(_get_async_url())
    async with engine.connect() as conn:
        yield AsyncSession(bind=conn)
    await engine.dispose()


@pytest.fixture(scope="session")
def openai_client():
    api_key = settings.get("OPENAI.api_key")
    assert api_key, "OPENAI.api_key must be set"
    return AsyncOpenAI(api_key=api_key)


async def embed_query(client: AsyncOpenAI, query: str) -> list[float]:
    resp = await client.embeddings.create(model=EMBEDDING_MODEL, input=query)
    return resp.data[0].embedding
