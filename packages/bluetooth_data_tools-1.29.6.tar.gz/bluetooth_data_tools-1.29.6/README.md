# Bluetooth Data Tools

<p align="center">
  <a href="https://github.com/bluetooth-devices/bluetooth-data-tools/actions/workflows/ci.yml?query=branch%3Amain">
    <img src="https://img.shields.io/github/actions/workflow/status/bluetooth-devices/bluetooth-data-tools/ci.yml?branch=main&label=CI&logo=github&style=flat-square" alt="CI Status" >
  </a>
  <a href="https://bluetooth-data-tools.readthedocs.io">
    <img src="https://img.shields.io/readthedocs/bluetooth-data-tools.svg?logo=read-the-docs&logoColor=fff&style=flat-square" alt="Documentation Status">
  </a>
  <a href="https://codecov.io/gh/Bluetooth-Devices/bluetooth-data-tools">
    <img src="https://img.shields.io/codecov/c/github/Bluetooth-Devices/bluetooth-data-tools.svg?logo=codecov&logoColor=fff&style=flat-square" alt="Test coverage percentage">
  </a>
  <a href="https://codspeed.io/Bluetooth-Devices/bluetooth-data-tools"><img src="https://img.shields.io/endpoint?url=https://codspeed.io/badge.json" alt="CodSpeed Badge"/></a>
</p>
<p align="center">
  <a href="https://python-poetry.org/">
    <img src="https://img.shields.io/badge/packaging-poetry-299bd7?style=flat-square&logo=data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAASCAYAAABrXO8xAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAJJSURBVHgBfZLPa1NBEMe/s7tNXoxW1KJQKaUHkXhQvHgW6UHQQ09CBS/6V3hKc/AP8CqCrUcpmop3Cx48eDB4yEECjVQrlZb80CRN8t6OM/teagVxYZi38+Yz853dJbzoMV3MM8cJUcLMSUKIE8AzQ2PieZzFxEJOHMOgMQQ+dUgSAckNXhapU/NMhDSWLs1B24A8sO1xrN4NECkcAC9ASkiIJc6k5TRiUDPhnyMMdhKc+Zx19l6SgyeW76BEONY9exVQMzKExGKwwPsCzza7KGSSWRWEQhyEaDXp6ZHEr416ygbiKYOd7TEWvvcQIeusHYMJGhTwF9y7sGnSwaWyFAiyoxzqW0PM/RjghPxF2pWReAowTEXnDh0xgcLs8l2YQmOrj3N7ByiqEoH0cARs4u78WgAVkoEDIDoOi3AkcLOHU60RIg5wC4ZuTC7FaHKQm8Hq1fQuSOBvX/sodmNJSB5geaF5CPIkUeecdMxieoRO5jz9bheL6/tXjrwCyX/UYBUcjCaWHljx1xiX6z9xEjkYAzbGVnB8pvLmyXm9ep+W8CmsSHQQY77Zx1zboxAV0w7ybMhQmfqdmmw3nEp1I0Z+FGO6M8LZdoyZnuzzBdjISicKRnpxzI9fPb+0oYXsNdyi+d3h9bm9MWYHFtPeIZfLwzmFDKy1ai3p+PDls1Llz4yyFpferxjnyjJDSEy9CaCx5m2cJPerq6Xm34eTrZt3PqxYO1XOwDYZrFlH1fWnpU38Y9HRze3lj0vOujZcXKuuXm3jP+s3KbZVra7y2EAAAAAASUVORK5CYII=" alt="Poetry">
  </a>
  <a href="https://github.com/ambv/black">
    <img src="https://img.shields.io/badge/code%20style-black-000000.svg?style=flat-square" alt="black">
  </a>
  <a href="https://github.com/pre-commit/pre-commit">
    <img src="https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit&logoColor=white&style=flat-square" alt="pre-commit">
  </a>
</p>
<p align="center">
  <a href="https://pypi.org/project/bluetooth-data-tools/">
    <img src="https://img.shields.io/pypi/v/bluetooth-data-tools.svg?logo=python&logoColor=fff&style=flat-square" alt="PyPI Version">
  </a>
  <img src="https://img.shields.io/pypi/pyversions/bluetooth-data-tools.svg?style=flat-square&logo=python&amp;logoColor=fff" alt="Supported Python versions">
  <img src="https://img.shields.io/pypi/l/bluetooth-data-tools.svg?style=flat-square" alt="License">
</p>

Tools for converting bluetooth data and packets

## Installation

Install this via pip (or your favourite package manager):

`pip install bluetooth-data-tools`

## Usage

### Parsing BLE GAP Advertisement Data

Parse raw BLE advertisement bytes into structured data:

```python
from bluetooth_data_tools import parse_advertisement_data_bytes

# Parse raw GAP advertisement bytes
parsed = parse_advertisement_data_bytes(raw_bytes)
local_name = parsed[0]        # str | None
service_uuids = parsed[1]     # list[str]
service_data = parsed[2]      # dict[str, bytes]
manufacturer_data = parsed[3] # dict[int, bytes]
tx_power = parsed[4]          # int | None
```

Or use the object-oriented interface:

```python
from bluetooth_data_tools import BLEGAPAdvertisement, parse_advertisement_data

adv = parse_advertisement_data([raw_bytes1, raw_bytes2])
print(adv.local_name)
print(adv.service_uuids)
print(adv.service_data)
print(adv.manufacturer_data)
print(adv.tx_power)
```

### Bluetooth Address Utilities

```python
from bluetooth_data_tools import (
    int_to_bluetooth_address,
    mac_to_int,
    short_address,
    human_readable_name,
)

# Convert integer to MAC address
int_to_bluetooth_address(0x123456789ABC)
# "12:34:56:78:9A:BC"

# Convert MAC address to integer
mac_to_int("FF:FF:FF:FF:FF:FF")
# 281474976710655

# Get short address (last 2 octets)
short_address("AA:BB:CC:DD:EE:FF")
# "EEFF"

# Format a human-readable device name
human_readable_name("My Sensor", "", "AA:BB:CC:DD:EE:FF")
# "My Sensor (EEFF)"
```

### Distance Estimation

Estimate distance from TX power and RSSI:

```python
from bluetooth_data_tools import calculate_distance_meters

distance = calculate_distance_meters(power=-59, rssi=-60)
# ~1.135 meters
```

### Monotonic Time

A fast monotonic clock optimized for Bluetooth event timing. On Linux, uses `CLOCK_MONOTONIC_COARSE` via Cython for lower overhead:

```python
from bluetooth_data_tools import monotonic_time_coarse

now = monotonic_time_coarse()
```

### Private Address Resolution (RPA)

Resolve Bluetooth Low Energy random private addresses using an Identity Resolving Key:

```python
from bluetooth_data_tools import get_cipher_for_irk, resolve_private_address

cipher = get_cipher_for_irk(irk_bytes)  # 16-byte Identity Resolving Key
is_match = resolve_private_address(cipher, "40:01:02:0A:C4:A6")
```

## Contributors ✨

Thanks goes to these wonderful people ([emoji key](https://allcontributors.org/docs/en/emoji-key)):

<!-- prettier-ignore-start -->
<!-- ALL-CONTRIBUTORS-LIST:START - Do not remove or modify this section -->
<!-- markdownlint-disable -->
<!-- markdownlint-enable -->
<!-- ALL-CONTRIBUTORS-LIST:END -->
<!-- prettier-ignore-end -->

This project follows the [all-contributors](https://github.com/all-contributors/all-contributors) specification. Contributions of any kind welcome!

## Credits

This package was created with
[Cookiecutter](https://github.com/audreyr/cookiecutter) and the
[browniebroke/cookiecutter-pypackage](https://github.com/browniebroke/cookiecutter-pypackage)
project template.
