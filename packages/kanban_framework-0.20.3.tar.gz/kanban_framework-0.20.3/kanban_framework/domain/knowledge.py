"""Knowledge management backed by SQLite (stdlib, zero deps).

Single .db file replaces entries/*.json, index.json, usage-log.json, domains.json.
FTS5 provides full-text search with BM25 ranking.
jieba (optional) provides Chinese tokenization for FTS5 search.
fastembed (optional, ONNX-based) provides semantic vector search.
"""
from __future__ import annotations
import json
import sqlite3
import struct
from datetime import datetime, timezone, timedelta

try:
    import jieba
    HAS_JIEBA = True
except ImportError:
    jieba = None  # type: ignore
    HAS_JIEBA = False

try:
    import chromadb
    HAS_CHROMA = True
except ImportError:
    chromadb = None  # type: ignore
    HAS_CHROMA = False

_EMBED_MODEL = None
_EMBED_FAILED = False
_EMBED_DIM = 512  # bge-small-zh-v1.5


def _get_embed_model():
    """Lazy-load bge-small-zh-v1.5 via fastembed (ONNX, no PyTorch).
    Returns None if unavailable.
    """
    global _EMBED_MODEL, _EMBED_FAILED, _EMBED_DIM
    if _EMBED_FAILED:
        return None
    if _EMBED_MODEL is None:
        try:
            from fastembed import TextEmbedding
            _EMBED_MODEL = TextEmbedding(model_name="BAAI/bge-small-zh-v1.5")
            # Probe dim from first embedding
            probe = list(_EMBED_MODEL.embed(["dim_probe"]))[0]
            _EMBED_DIM = len(probe)
        except Exception:
            _EMBED_FAILED = True
            return None
    return _EMBED_MODEL


def _embed(text: str) -> bytes | None:
    """Compute float32 embedding for text. Returns packed bytes.
    Returns None if embedding model is unavailable.
    """
    if _EMBED_FAILED or not text:
        return None
    model = _get_embed_model()
    if model is None:
        return None
    try:
        vec = list(model.embed([text]))[0]
        return struct.pack(f"{len(vec)}f", *vec)
    except Exception:
        return None


def _unpack_embedding(blob: bytes) -> list[float]:
    """Unpack BLOB back to float list."""
    n = len(blob) // 4
    return list(struct.unpack(f"{n}f", blob))


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    """Cosine similarity between two vectors (both should be normalized)."""
    return sum(x * y for x, y in zip(a, b))


def _segment(text: str) -> str:
    """Segment Chinese text with jieba. Returns space-separated tokens.
    If jieba is not installed, returns the original text unchanged.
    """
    if not HAS_JIEBA or not text:
        return text
    # Only segment if text contains CJK characters
    if not any('一' <= c <= '鿿' for c in text):
        return text
    words = jieba.cut(text)
    return " ".join(w for w in words if w.strip())

DEFAULT_DOMAINS = {
    "cli": {"label": "CLI 命令", "keywords": ["argparse", "dispatch", "subcommand", "cli"]},
    "agent": {"label": "Agent 定义", "keywords": ["agent", "prompt", "role", "model"]},
    "testing": {"label": "测试", "keywords": ["pytest", "assert", "mock", "coverage", "test"]},
    "infra": {"label": "基础设施", "keywords": ["filesystem", "git", "config", "worktree", "path"]},
    "workflow": {"label": "工作流", "keywords": ["FSM", "state", "transition", "iteration", "phase"]},
    "dashboard": {"label": "看板仪表盘", "keywords": ["dashboard", "frontend", "js", "css"]},
    "git": {"label": "版本控制", "keywords": ["commit", "branch", "merge", "push", "remote"]},
    "web": {"label": "Web 开发", "keywords": ["fastapi", "flask", "django", "express", "api", "rest", "http", "router", "middleware", "cors"]},
    "database": {"label": "数据库", "keywords": ["sqlite", "sql", "postgresql", "mysql", "orm", "migration", "query", "transaction"]},
    "ui": {"label": "前端界面", "keywords": ["component", "react", "vue", "template", "render", "dom", "event", "async"]},
    "game": {"label": "游戏开发", "keywords": ["game", "pygame", "sprite", "collision", "render", "fps", "input", "animation"]},
    "security": {"label": "安全", "keywords": ["auth", "token", "jwt", "hash", "encrypt", "permission", "xss", "csrf"]},
}

STALE_DAYS = 30


class KnowledgeManager:
    def __init__(self, fs):
        self._fs = fs
        db_dir = fs.kanban_dir / "knowledge"
        fs.ensure_dir(db_dir)
        self._db_path = db_dir / "knowledge.db"
        self._conn = sqlite3.connect(str(self._db_path))
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._chroma_client = None
        self._chroma_collection = None
        self._ensure_schema()
        self._ensure_domains()

    # -- schema --

    def _ensure_schema(self):
        # Base tables
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS entries (
                id TEXT PRIMARY KEY,
                domain TEXT NOT NULL,
                category TEXT NOT NULL,
                title TEXT NOT NULL,
                content TEXT NOT NULL,
                content_segmented TEXT DEFAULT '',
                code_example TEXT DEFAULT '',
                tags TEXT DEFAULT '[]',
                source TEXT DEFAULT '{}',
                severity TEXT DEFAULT 'medium',
                status TEXT DEFAULT 'active',
                created_at TEXT NOT NULL,
                updated_at TEXT,
                stale_at TEXT,
                referenced_count INTEGER DEFAULT 0,
                last_referenced_at TEXT,
                last_referenced_by TEXT
            );
            CREATE TABLE IF NOT EXISTS usage_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entry_id TEXT NOT NULL,
                task_id TEXT NOT NULL,
                timestamp TEXT NOT NULL
            );
        """)

        # Add content_segmented column to existing databases (migration)
        cols = {r[1] for r in self._conn.execute("PRAGMA table_info(entries)")}
        if "content_segmented" not in cols:
            self._conn.execute("ALTER TABLE entries ADD COLUMN content_segmented TEXT DEFAULT ''")
        if "embedding" not in cols:
            self._conn.execute("ALTER TABLE entries ADD COLUMN embedding BLOB DEFAULT NULL")

        # Rebuild FTS5 with content_segmented column
        has_content_seg = False
        try:
            fts_cols = {r[1] for r in self._conn.execute("PRAGMA table_info(entries_fts)")}
            has_content_seg = "content_segmented" in fts_cols
        except sqlite3.OperationalError:
            pass

        if not has_content_seg:
            self._conn.execute("DROP TABLE IF EXISTS entries_fts")
            self._conn.execute(
                "CREATE VIRTUAL TABLE entries_fts USING fts5("
                "title, content, content_segmented, code_example, tags, "
                "content=entries, content_rowid=rowid)"
            )
            # Populate FTS5 from existing entries
            self._conn.execute(
                "INSERT INTO entries_fts(rowid, title, content, content_segmented, code_example, tags) "
                "SELECT rowid, title, content, content_segmented, code_example, tags FROM entries"
            )

        # Rebuild triggers (idempotent IF NOT EXISTS)
        self._conn.executescript("""
            DROP TRIGGER IF EXISTS entries_ai;
            DROP TRIGGER IF EXISTS entries_ad;
            DROP TRIGGER IF EXISTS entries_au;
            CREATE TRIGGER entries_ai AFTER INSERT ON entries BEGIN
                INSERT INTO entries_fts(rowid, title, content, content_segmented, code_example, tags)
                VALUES (new.rowid, new.title, new.content, new.content_segmented, new.code_example, new.tags);
            END;
            CREATE TRIGGER entries_ad AFTER DELETE ON entries BEGIN
                INSERT INTO entries_fts(entries_fts, rowid, title, content, content_segmented, code_example, tags)
                VALUES ('delete', old.rowid, old.title, old.content, old.content_segmented, old.code_example, old.tags);
            END;
            CREATE TRIGGER entries_au AFTER UPDATE ON entries BEGIN
                INSERT INTO entries_fts(entries_fts, rowid, title, content, content_segmented, code_example, tags)
                VALUES ('delete', old.rowid, old.title, old.content, old.content_segmented, old.code_example, old.tags);
                INSERT INTO entries_fts(rowid, title, content, content_segmented, code_example, tags)
                VALUES (new.rowid, new.title, new.content, new.content_segmented, new.code_example, new.tags);
            END;
        """)

    def _ensure_domains(self):
        self._conn.execute(
            "CREATE TABLE IF NOT EXISTS domains (name TEXT PRIMARY KEY, label TEXT, keywords TEXT)"
        )
        existing = {r[0] for r in self._conn.execute("SELECT name FROM domains")}
        for name, info in DEFAULT_DOMAINS.items():
            if name not in existing:
                self._conn.execute(
                    "INSERT INTO domains(name, label, keywords) VALUES(?,?,?)",
                    (name, info["label"], json.dumps(info["keywords"])),
                )

        # Backfill content_segmented for entries created before jieba integration
        if HAS_JIEBA:
            blanks = self._conn.execute(
                "SELECT rowid, title, content, code_example FROM entries WHERE content_segmented=''"
            ).fetchall()
            if blanks:
                for row in blanks:
                    seg = _segment(row[1]) + " " + _segment(row[2])
                    if row[3]:
                        seg += " " + _segment(row[3])
                    self._conn.execute(
                        "UPDATE entries SET content_segmented=? WHERE rowid=?",
                        (seg, row[0]),
                    )
                self._conn.commit()
                # Rebuild FTS5 to pick up the new segmented content
                self._conn.execute("DELETE FROM entries_fts")
                self._conn.execute(
                    "INSERT INTO entries_fts(rowid, title, content, content_segmented, code_example, tags) "
                    "SELECT rowid, title, content, content_segmented, code_example, tags FROM entries"
                )

        # Backfill embeddings for entries created before fastembed integration
        model = _get_embed_model()
        if model is not None:
            blanks = self._conn.execute(
                "SELECT rowid, title, content FROM entries WHERE embedding IS NULL"
            ).fetchall()
            if blanks:
                for row in blanks:
                    emb = _embed(row[1] + " " + row[2])
                    if emb:
                        self._conn.execute(
                            "UPDATE entries SET embedding=? WHERE rowid=?",
                            (emb, row[0]),
                        )
                self._conn.commit()

    # -- public API --

    def add_entry(self, *, domain, category, title, content,
                  tags=None, severity="medium", source=None, code_example="",
                  status="active", upsert=False):
        if not title.strip() and not content.strip():
            raise ValueError("at least title or content is required")
        tags = tags or []
        source = source or {}
        now = datetime.now(timezone.utc).isoformat()
        segmented = _segment(title) + " " + _segment(content)
        if code_example:
            segmented += " " + _segment(code_example)
        emb = _embed(title + " " + content)

        # Check for existing entry with same title + domain (#189)
        existing = self._conn.execute(
            "SELECT id FROM entries WHERE title=? AND domain=? LIMIT 1",
            (title.strip(), domain),
        ).fetchone()
        if existing:
            if not upsert:
                return {"skipped": True, "reason": "duplicate", "existing_id": existing[0]}
            self._conn.execute(
                """UPDATE entries SET category=?, content=?, content_segmented=?,
                   embedding=?, code_example=?, tags=?, source=?, severity=?,
                   status=?, updated_at=?
                   WHERE id=?""",
                (category, content, segmented, emb, code_example,
                 json.dumps(tags), json.dumps(source), severity, status, now,
                 existing[0]),
            )
            self._conn.commit()
            entry = self.get_entry(existing[0])
            self._chroma_upsert_entry(existing[0], title, content, domain, category, status)
            return entry

        eid = self._next_id()
        self._conn.execute(
            """INSERT INTO entries(id, domain, category, title, content, content_segmented,
               embedding, code_example, tags, source, severity, status, created_at, updated_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (eid, domain, category, title, content, segmented, emb, code_example,
             json.dumps(tags), json.dumps(source), severity, status, now, now),
        )
        self._conn.commit()
        entry = self.get_entry(eid)
        self._chroma_upsert_entry(eid, title, content, domain, category, status)
        return entry

    def get_entry(self, entry_id):
        row = self._conn.execute("SELECT * FROM entries WHERE id=?", (entry_id,)).fetchone()
        return self._row_to_dict(row) if row else None

    def list_entries(self, domain=None, category=None, status="active", limit=50, offset=0):
        """List entries with optional filters.

        Args:
            domain: Optional domain filter (e.g. 'testing', 'cli').
            category: Optional category filter (e.g. '踩坑', '架构').
            status: Entry status filter ('active', 'stale', 'draft'). Default 'active'.
            limit: Max entries to return (default 50).
            offset: Pagination offset (default 0).

        Returns:
            List of entry dicts ordered by id.
        """
        conditions = []
        params = []

        if domain:
            conditions.append("domain = ?")
            params.append(domain)
        if category:
            conditions.append("category = ?")
            params.append(category)
        if status:
            conditions.append("status = ?")
            params.append(status)

        where = " AND ".join(conditions) if conditions else "1=1"
        query = f"SELECT * FROM entries WHERE {where} ORDER BY id LIMIT ? OFFSET ?"
        params.extend([limit, offset])
        rows = self._conn.execute(query, params).fetchall()
        return [self._row_to_dict(r) for r in rows]

    # -- Chroma vector DB integration --

    def _ensure_chroma(self):
        """Lazily initialize Chroma PersistentClient and collection.

        Backfills existing entries with embeddings from SQLite on first run.
        Returns True if Chroma is ready, False otherwise.
        """
        if not HAS_CHROMA:
            return False
        if self._chroma_collection is not None:
            return True
        try:
            chroma_dir = str(self._fs.kanban_dir / "knowledge" / "chroma")
            self._chroma_client = chromadb.PersistentClient(path=chroma_dir)
            self._chroma_collection = self._chroma_client.get_or_create_collection(
                name="knowledge_entries",
                metadata={"hnsw:space": "cosine"},
            )
            # Backfill existing entries that have embeddings
            existing_ids = set(self._chroma_collection.get()["ids"])
            rows = self._conn.execute(
                "SELECT * FROM entries WHERE embedding IS NOT NULL"
            ).fetchall()
            for r in rows:
                eid = r["id"]
                if eid in existing_ids:
                    continue
                emb_blob = r["embedding"]
                if not emb_blob:
                    continue
                e_vec = _unpack_embedding(emb_blob)
                title = r["title"] or ""
                content = r["content"] or ""
                text = title + " " + content
                self._chroma_collection.add(
                    ids=[eid],
                    embeddings=[e_vec],
                    documents=[text],
                    metadatas=[{
                        "id": eid,
                        "domain": r["domain"],
                        "category": r["category"],
                        "title": title,
                        "status": r["status"],
                    }],
                )
            return True
        except Exception:
            return False

    def _chroma_upsert_entry(self, entry_id, title, content, domain, category, status):
        """Upsert a single entry to Chroma. Silently ignores failures."""
        if not self._ensure_chroma():
            return
        try:
            text = (title or "") + " " + (content or "")
            emb = _embed(text)
            if emb is None:
                return
            e_vec = _unpack_embedding(emb)
            self._chroma_collection.upsert(
                ids=[entry_id],
                embeddings=[e_vec],
                documents=[text],
                metadatas=[{
                    "id": entry_id,
                    "domain": domain,
                    "category": category,
                    "title": title,
                    "status": status,
                }],
            )
        except Exception:
            pass  # Chroma failure must not block SQLite writes

    def _chroma_delete_entry(self, entry_id):
        """Remove an entry from Chroma by ID. Silently ignores failures."""
        if self._chroma_collection is None:
            return
        try:
            self._chroma_collection.delete(ids=[entry_id])
        except Exception:
            pass

    def search(self, keyword, domain=None, limit=20):
        if not keyword:
            return []

        # Segment the query for Chinese search
        if HAS_JIEBA and any('一' <= c <= '鿿' for c in keyword):
            segmented = " ".join(w for w in jieba.cut(keyword) if w.strip())
            # Search content_segmented for Chinese, fall back to raw keyword
            query = """SELECT e.*, rank FROM entries_fts f
                       JOIN entries e ON e.rowid = f.rowid
                       WHERE entries_fts MATCH ? ORDER BY rank LIMIT ?"""
            params = [segmented, limit]
            rows = self._conn.execute(query, params).fetchall()
            # If no results from segmented, try raw keyword
            if not rows:
                params = [keyword, limit]
                rows = self._conn.execute(query, params).fetchall()
        else:
            query = """SELECT e.*, rank FROM entries_fts f
                       JOIN entries e ON e.rowid = f.rowid
                       WHERE entries_fts MATCH ? ORDER BY rank LIMIT ?"""
            params = [keyword, limit]
            rows = self._conn.execute(query, params).fetchall()

        results = [self._row_to_dict(r) for r in rows]
        if domain:
            results = [r for r in results if r["domain"] == domain]
        return results

    def search_by_domain(self, domain, severity=None, status="active", limit=20):
        rows = self._conn.execute(
            """SELECT * FROM entries WHERE domain=? AND status=?
               {} ORDER BY referenced_count DESC LIMIT ?""".format(
                "AND severity=?" if severity else ""),
            (domain, status, *([severity] if severity else []), limit),
        ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def search_by_tag(self, tag):
        rows = self._conn.execute(
            "SELECT * FROM entries WHERE tags LIKE ?", (f'%"{tag}"%',)
        ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def search_by_task(self, task_id):
        rows = self._conn.execute(
            "SELECT * FROM entries WHERE source LIKE ?", (f'%"{task_id}"%',)
        ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def search_semantic(self, query: str, limit: int = 20) -> list[dict]:
        """Semantic search using Chroma ANN with cosine distance.

        Falls back to full-table cosine scan if Chroma is unavailable, then to
        keyword search if embeddings are also unavailable.
        """
        if not query or _EMBED_FAILED:
            return self.search(query, limit=limit) if query else []

        model = _get_embed_model()
        if model is None:
            return self.search(query, limit=limit)

        q_emb = _embed(query)
        if q_emb is None:
            return self.search(query, limit=limit)

        q_vec = _unpack_embedding(q_emb)

        # Try Chroma ANN first
        if self._ensure_chroma():
            try:
                results = self._chroma_collection.query(
                    query_embeddings=[q_vec],
                    n_results=limit,
                )
                ids = results.get("ids", [[]])[0]
                if ids is not None and len(ids) > 0:
                    distances = results.get("distances", [[]])[0]
                    entries = []
                    for idx, eid in enumerate(ids):
                        entry = self.get_entry(eid)
                        if entry:
                            if distances and idx < len(distances):
                                entry["score"] = round(1.0 - distances[idx], 4)
                            entries.append(entry)
                    return entries
            except Exception:
                pass  # Fall through to manual scan

        # Fallback: full-table scan with cosine similarity
        rows = self._conn.execute(
            "SELECT * FROM entries WHERE embedding IS NOT NULL AND status='active'"
        ).fetchall()

        scored = []
        for r in rows:
            emb_blob = r["embedding"]
            if not emb_blob:
                continue
            e_vec = _unpack_embedding(emb_blob)
            score = _cosine_similarity(q_vec, e_vec)
            entry = self._row_to_dict(r)
            scored.append((score, entry))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [e for _, e in scored[:limit]]

    def search_hybrid(self, keyword: str, limit: int = 20) -> list[dict]:
        """Hybrid search: BM25 keyword + semantic vector fused via RRF."""
        kw_results = self.search(keyword, limit=limit * 2) if keyword else []
        sem_results = self.search_semantic(keyword, limit=limit * 2)

        # Reciprocal Rank Fusion
        scores: dict[str, float] = {}
        k = 60.0  # RRF constant

        for rank, r in enumerate(kw_results, 1):
            eid = r["id"]
            scores[eid] = scores.get(eid, 0) + 1.0 / (k + rank)

        for rank, r in enumerate(sem_results, 1):
            eid = r["id"]
            scores[eid] = scores.get(eid, 0) + 1.0 / (k + rank)

        # Merge entries, sort by combined score
        all_entries = {r["id"]: r for r in kw_results + sem_results}
        ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return [all_entries[eid] for eid, _ in ranked[:limit] if eid in all_entries]

    def record_usage(self, entry_id, task_id):
        now = datetime.now(timezone.utc).isoformat()
        self._conn.execute(
            "UPDATE entries SET referenced_count=referenced_count+1,"
            " last_referenced_at=?, last_referenced_by=?, stale_at=NULL,"
            " status='active' WHERE id=?",
            (now, task_id, entry_id),
        )
        self._conn.execute(
            "INSERT INTO usage_log(entry_id, task_id, timestamp) VALUES(?,?,?)",
            (entry_id, task_id, now),
        )
        self._conn.commit()

    def mark_stale_entries(self):
        threshold = (datetime.now(timezone.utc) - timedelta(days=STALE_DAYS)).isoformat()
        rows = self._conn.execute(
            """SELECT id FROM entries WHERE status='active'
               AND COALESCE(last_referenced_at, created_at) < ?""",
            (threshold,),
        ).fetchall()
        stale_ids = [r[0] for r in rows]
        if stale_ids:
            now = datetime.now(timezone.utc).isoformat()
            placeholders = ",".join("?" * len(stale_ids))
            self._conn.execute(
                f"UPDATE entries SET status='stale', stale_at=? WHERE id IN ({placeholders})",
                [now] + stale_ids,
            )
            self._conn.commit()
        return stale_ids

    def get_domains(self):
        rows = self._conn.execute("SELECT name, label, keywords FROM domains").fetchall()
        domains = {}
        for r in rows:
            domains[r[0]] = {"label": r[1], "keywords": json.loads(r[2])}
        return {"domains": domains or DEFAULT_DOMAINS}

    def match_domain(self, text):
        domains = self.get_domains()
        text_lower = text.lower()
        scores = {}
        for name, info in domains.get("domains", DEFAULT_DOMAINS).items():
            for kw in info.get("keywords", []):
                if kw.lower() in text_lower:
                    scores[name] = scores.get(name, 0) + 1
        return sorted(scores, key=scores.get, reverse=True)

    def find_similar_pitfalls(self, tags, min_tag_overlap=2):
        rows = self._conn.execute(
            "SELECT * FROM entries WHERE category='踩坑' AND status='active'"
        ).fetchall()
        tags_set = set(tags)
        results = []
        for r in rows:
            entry = self._row_to_dict(r)
            overlap = len(tags_set & set(entry.get("tags", [])))
            if overlap >= min_tag_overlap:
                results.append({**entry, "tag_overlap": overlap})
        results.sort(key=lambda x: x["tag_overlap"], reverse=True)
        return results

    def find_conflicting_solutions(self, task_id=""):
        rows = self._conn.execute(
            "SELECT * FROM entries WHERE category!='踩坑' AND status='active'"
        ).fetchall()
        entries = [self._row_to_dict(r) for r in rows]
        by_domain = {}
        for e in entries:
            by_domain.setdefault(e["domain"], []).append(e)
        conflicts = []
        for domain, ents in by_domain.items():
            n = len(ents)
            for i in range(n):
                for j in range(i + 1, n):
                    a, b = ents[i], ents[j]
                    tags_a = set(a.get("tags", []))
                    tags_b = set(b.get("tags", []))
                    overlap = len(tags_a & tags_b)
                    if overlap < 2:
                        continue
                    if a.get("category") != "架构" and b.get("category") != "架构":
                        continue
                    conflicts.append({
                        "entry_a": a["id"], "entry_b": b["id"],
                        "title_a": a["title"], "title_b": b["title"],
                        "domain": domain,
                        "shared_tags": sorted(tags_a & tags_b),
                        "tag_overlap": overlap,
                        "content_a": a["content"][:200],
                        "content_b": b["content"][:200],
                    })
        return conflicts

    def get_knowledge_gap_report(self):
        rows = self._conn.execute("SELECT domain, category FROM entries WHERE status='active'").fetchall()
        domain_counts = {}
        domain_pitfalls = {}
        for r in rows:
            d, c = r[0], r[1]
            domain_counts[d] = domain_counts.get(d, 0) + 1
            if c == "踩坑":
                domain_pitfalls[d] = domain_pitfalls.get(d, 0) + 1
        gaps = {}
        for d, pitfall_count in domain_pitfalls.items():
            if domain_counts.get(d, 1) < pitfall_count * 2:
                gaps[d] = {"total_entries": domain_counts.get(d, 0), "pitfalls": pitfall_count}
        return gaps

    def migrate_legacy_log(self):
        """Migrate old knowledge-log.md files to SQLite entries.
        Scans both project root and task directories. Returns total count."""
        import re
        log_files = []
        # Project root
        root_log = self._fs.kanban_dir / "knowledge-log.md"
        if self._fs.file_exists(root_log):
            log_files.append((root_log, None))
        # Task directories
        for task_dir in sorted(self._fs.kanban_dir.glob("tasks/TASK-*")):
            if task_dir.is_dir():
                task_log = task_dir / "knowledge-log.md"
                if self._fs.file_exists(task_log):
                    log_files.append((task_log, task_dir.name))

        pattern = re.compile(r'###\s+(\S+):\s*(.+?)\n\s*\n(.*?)(?=\n###|\Z)', re.DOTALL)
        count = 0
        for log_path, task_id in log_files:
            text = log_path.read_text(encoding="utf-8")
            for m in pattern.finditer(text):
                category = m.group(1)
                title = m.group(2).strip()
                content = m.group(3).strip()
                source = {"migrated_from": str(log_path.relative_to(self._fs.kanban_dir))}
                if task_id:
                    source["task_id"] = task_id
                self.add_entry(
                    domain=self.match_domain(f"{title} {content}")[0] if self.match_domain(title) else "infra",
                    category=category, title=title, content=content,
                    tags=[category], source=source,
                )
                count += 1
            log_path.rename(log_path.with_suffix(".md.bak"))
        return count

    # -- helpers --

    def _next_id(self):
        row = self._conn.execute(
            "SELECT id FROM entries ORDER BY CAST(SUBSTR(id, 2) AS INTEGER) DESC LIMIT 1"
        ).fetchone()
        if not row:
            return "K001"
        try:
            return f"K{int(row[0][1:]) + 1:03d}"
        except ValueError:
            return "K001"

    def _row_to_dict(self, row):
        d = dict(row)
        for field in ("tags", "source"):
            if field in d and isinstance(d[field], str):
                try:
                    d[field] = json.loads(d[field])
                except (json.JSONDecodeError, TypeError):
                    d[field] = [] if field == "tags" else {}
        d.pop("embedding", None)
        return d

    def _all_entry_ids(self):
        return [r[0] for r in self._conn.execute("SELECT id FROM entries ORDER BY id")]

    def close(self):
        self._conn.close()
