"""CORS allow_origins configuration coverage.

These tests verify Settings defaults, env overrides, and create_app middleware
wiring for allowed origins.
"""


# ---------------------------------------------------------------------------
# Tests — Settings.cors_origins field
# ---------------------------------------------------------------------------


class TestCorsOriginsSettingsField:
    """Settings must expose a cors_origins field with the correct default."""

    def test_default_cors_origins_is_localhost_3000(self):
        """Default value must be ["http://localhost:3000"], not ["*"]."""
        from runsight_api.core.config import Settings

        s = Settings()
        assert s.cors_origins == ["http://localhost:3000"]
        assert not any("5173" in origin for origin in s.cors_origins)

    def test_default_is_a_list(self):
        """cors_origins must be a list, not a string."""
        from runsight_api.core.config import Settings

        s = Settings()
        assert isinstance(s.cors_origins, list)


# ---------------------------------------------------------------------------
# Tests — env var override
# ---------------------------------------------------------------------------


class TestCorsOriginsEnvOverride:
    """RUNSIGHT_CORS_ORIGINS env var must override the default."""

    def test_env_var_single_origin(self, monkeypatch):
        """A single origin in the env var produces a one-element list."""
        monkeypatch.setenv("RUNSIGHT_CORS_ORIGINS", "http://localhost:3001")

        # Force re-creation of a fresh Settings instance
        from runsight_api.core.config import Settings

        s = Settings()
        assert s.cors_origins == ["http://localhost:3001"]

    def test_env_var_multiple_origins(self, monkeypatch):
        """Comma-separated origins produce a multi-element list."""
        monkeypatch.setenv(
            "RUNSIGHT_CORS_ORIGINS",
            "http://localhost:3001,http://127.0.0.1:5173",
        )

        from runsight_api.core.config import Settings

        s = Settings()
        assert s.cors_origins == [
            "http://localhost:3001",
            "http://127.0.0.1:5173",
        ]

    def test_env_var_wildcard(self, monkeypatch):
        """Setting the env var to '*' produces ['*'] (opt-in wide open)."""
        monkeypatch.setenv("RUNSIGHT_CORS_ORIGINS", "*")

        from runsight_api.core.config import Settings

        s = Settings()
        assert s.cors_origins == ["*"]

    def test_env_var_strips_whitespace(self, monkeypatch):
        """Whitespace around origins in the env var is stripped."""
        monkeypatch.setenv(
            "RUNSIGHT_CORS_ORIGINS",
            " http://localhost:4100 , http://127.0.0.1:4101 ",
        )

        from runsight_api.core.config import Settings

        s = Settings()
        assert s.cors_origins == ["http://localhost:4100", "http://127.0.0.1:4101"]


# ---------------------------------------------------------------------------
# Tests — create_app() wires settings into CORS middleware
# ---------------------------------------------------------------------------


class TestCreateAppUsesSettingsForCors:
    """create_app() must read origins from settings, not hardcode ['*']."""

    def test_cors_middleware_does_not_use_wildcard_by_default(self):
        """The default app must NOT have allow_origins=['*']."""
        from runsight_api.main import create_app

        app = create_app()

        # Walk the middleware stack to find CORSMiddleware
        cors_mw = None
        # In Starlette, middleware is nested: app.middleware_stack
        # We inspect the app's user_middleware list added via add_middleware
        for mw in app.user_middleware:
            if mw.cls.__name__ == "CORSMiddleware":
                cors_mw = mw
                break

        assert cors_mw is not None, "CORSMiddleware must be registered"
        allow_origins = cors_mw.kwargs.get(
            "allow_origins", cors_mw.args[0] if cors_mw.args else None
        )
        assert allow_origins != ["*"], (
            f"Default CORS origins must not be ['*'], got {allow_origins}"
        )

    def test_cors_middleware_uses_default_localhost_origin(self):
        """The default app must use ['http://localhost:3000'] for CORS."""
        from runsight_api.main import create_app

        app = create_app()

        cors_mw = None
        for mw in app.user_middleware:
            if mw.cls.__name__ == "CORSMiddleware":
                cors_mw = mw
                break

        assert cors_mw is not None, "CORSMiddleware must be registered"
        allow_origins = cors_mw.kwargs.get("allow_origins")
        assert allow_origins == ["http://localhost:3000"], (
            f"Default CORS origins must be ['http://localhost:3000'], got {allow_origins}"
        )
