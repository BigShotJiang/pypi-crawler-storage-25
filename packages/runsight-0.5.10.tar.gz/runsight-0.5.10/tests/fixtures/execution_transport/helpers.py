from __future__ import annotations

import asyncio
import json
from pathlib import Path

import pytest
from fastapi import FastAPI
from sqlmodel import SQLModel, Session, create_engine, select

from runsight_api.core.secrets import SecretsEnvLoader
from runsight_api.data.filesystem.provider_repo import FileSystemProviderRepo
from runsight_api.data.filesystem.workflow_repo import WorkflowRepository
from runsight_api.data.repositories.run_read_model import RunReadModel
from runsight_api.data.repositories.run_repo import RunRepository
from runsight_api.domain.entities.run import Run, RunStatus
from runsight_api.logic.services.eval_service import EvalService
from runsight_api.logic.services.execution_service import ExecutionService
from runsight_api.logic.services.run_service import RunService
from runsight_api.transport.deps import (
    get_eval_service,
    get_execution_service,
    get_run_service,
)
from runsight_api.transport.routers import runs, sse_stream

PROVIDER_SECRET_ENV_NAMES = (
    "OPENAI_API_KEY",
    "ANTHROPIC_API_KEY",
    "AZURE_OPENAI_API_KEY",
    "GEMINI_API_KEY",
    "GOOGLE_API_KEY",
)

FIXTURE_DIR = Path(__file__).parent


def read_workflow_fixture(name: str) -> str:
    return (FIXTURE_DIR / name).read_text(encoding="utf-8")


def write_workflow_file(base_dir: Path, workflow_id: str, content: str) -> None:
    workflows_dir = base_dir / "custom" / "workflows"
    workflows_dir.mkdir(parents=True, exist_ok=True)
    (workflows_dir / f"{workflow_id}.yaml").write_text(content, encoding="utf-8")


def write_provider_file(base_dir: Path) -> None:
    provider_dir = base_dir / "custom" / "providers"
    provider_dir.mkdir(parents=True, exist_ok=True)
    (provider_dir / "openai.yaml").write_text(
        "\n".join(
            [
                "id: openai",
                "kind: provider",
                "name: openai",
                "type: openai",
                "api_key: ${OPENAI_API_KEY}",
                "is_active: true",
                "models:",
                "  - gpt-4o",
                "",
            ]
        ),
        encoding="utf-8",
    )


def write_secrets_file(base_dir: Path) -> None:
    secrets_dir = base_dir / ".runsight"
    secrets_dir.mkdir(parents=True, exist_ok=True)
    (secrets_dir / "secrets.env").write_text(
        "# Managed by Runsight\nOPENAI_API_KEY=dummy-fake-test-key-for-execution-transport\n",
        encoding="utf-8",
    )


def make_achat_response(content: str, cost_usd: float = 0.001, total_tokens: int = 100):
    return {
        "content": content,
        "cost_usd": cost_usd,
        "prompt_tokens": 50,
        "completion_tokens": 50,
        "total_tokens": total_tokens,
        "tool_calls": None,
        "finish_reason": "stop",
        "raw_message": {"role": "assistant", "content": content},
    }


def build_app(*, db_engine, base_dir: Path, git_service=None):
    app = FastAPI()
    app.include_router(runs.router, prefix="/api")
    app.include_router(sse_stream.router, prefix="/api")

    workflow_repo = WorkflowRepository(str(base_dir))
    provider_repo = FileSystemProviderRepo(base_path=str(base_dir))
    secrets = SecretsEnvLoader(base_path=str(base_dir))
    execution_session = Session(db_engine)
    execution_service = ExecutionService(
        run_repo=RunRepository(execution_session),
        workflow_repo=workflow_repo,
        provider_repo=provider_repo,
        engine=db_engine,
        secrets=secrets,
        git_service=git_service,
    )
    app.state.execution_service = execution_service
    app.state.execution_session = execution_session

    def _get_run_service():
        session = Session(db_engine)
        run_repo = RunRepository(session)
        run_read_model = RunReadModel(session)
        return RunService(run_repo, workflow_repo, run_read_model=run_read_model)

    def _get_execution_service(_request=None):
        return execution_service

    def _get_eval_service():
        session = Session(db_engine)
        run_repo = RunRepository(session)
        run_read_model = RunReadModel(session)
        return EvalService(run_repo, run_read_model=run_read_model)

    app.dependency_overrides[get_run_service] = _get_run_service
    app.dependency_overrides[get_execution_service] = _get_execution_service
    app.dependency_overrides[get_eval_service] = _get_eval_service

    return app, execution_service


def parse_sse_events(raw: str) -> list[dict[str, object]]:
    events: list[dict[str, object]] = []
    current_event: str | None = None
    current_data: list[str] = []

    for line in raw.splitlines():
        if line.startswith("event:"):
            current_event = line[len("event:") :].strip()
        elif line.startswith("data:"):
            current_data.append(line[len("data:") :].strip())
        elif line == "" and current_event is not None:
            payload = "\n".join(current_data)
            events.append(
                {
                    "event": current_event,
                    "data": json.loads(payload) if payload else None,
                }
            )
            current_event = None
            current_data = []

    return events


async def wait_for_run_terminal(engine, run_id: str, timeout: float = 10.0) -> Run | None:
    deadline = asyncio.get_event_loop().time() + timeout
    terminal = {RunStatus.completed, RunStatus.failed, RunStatus.cancelled}

    while asyncio.get_event_loop().time() < deadline:
        with Session(engine) as session:
            run = session.get(Run, run_id)
            if run is not None and run.status in terminal:
                return run
        await asyncio.sleep(0.05)

    with Session(engine) as session:
        return session.get(Run, run_id)


def latest_run_id(engine) -> str:
    with Session(engine) as session:
        run = session.exec(select(Run).order_by(Run.created_at.desc())).first()
        assert run is not None, "expected POST /api/runs to create a run before prepare blocked"
        return run.id


def cancel_latest_run(engine, workflow_repo: WorkflowRepository) -> str:
    run_id = latest_run_id(engine)
    session = Session(engine)
    try:
        run_service = RunService(
            RunRepository(session),
            workflow_repo=workflow_repo,
            run_read_model=RunReadModel(session),
        )
        run_service.cancel_run(run_id)
    finally:
        session.close()
    return run_id


@pytest.fixture
def db_engine(tmp_path: Path):
    db_path = tmp_path / "runsight.db"
    engine = create_engine(
        f"sqlite:///{db_path}",
        connect_args={"check_same_thread": False},
    )
    SQLModel.metadata.create_all(engine)
    yield engine
    engine.dispose()


@pytest.fixture
def simple_workflow_yaml() -> str:
    return read_workflow_fixture("simple-workflow.yaml")


@pytest.fixture
def base_dir(tmp_path: Path, simple_workflow_yaml: str):
    base = tmp_path / "execution-transport-base"
    write_workflow_file(base, "simple-workflow", simple_workflow_yaml)
    write_provider_file(base)
    write_secrets_file(base)
    return base
