"""Tests for BaseYamlRepository generic base class."""

import pytest
import yaml
from pydantic import ValidationError

from base_yaml_helpers import (
    MALFORMED_YAML,
    DummyNotFound,
    DummyRepository,
    StrictDummyRepository,
    write_yaml_payload,
)


class TestBaseYamlRepositoryInstantiation:
    """BaseYamlRepository can be instantiated with a type parameter."""

    def test_instantiation_creates_directory(self, tmp_path):
        tmpdir = str(tmp_path)
        repo = DummyRepository(base_path=tmpdir)
        assert repo.entity_dir.exists()
        assert repo.entity_dir.name == "dummies"

    def test_instantiation_sets_base_path(self, tmp_path):
        tmpdir = str(tmp_path)
        repo = DummyRepository(base_path=tmpdir)
        assert str(repo.base_path) == tmpdir


class TestListAll:
    """list_all returns all entities from YAML files."""

    def test_list_all_empty(self, tmp_path):
        tmpdir = str(tmp_path)
        repo = DummyRepository(base_path=tmpdir)
        assert repo.list_all() == []

    def test_list_all_returns_all_entities(self, tmp_path):
        tmpdir = str(tmp_path)
        repo = DummyRepository(base_path=tmpdir)
        repo.create({"id": "d1", "name": "First"})
        repo.create({"id": "d2", "name": "Second"})
        results = repo.list_all()
        assert len(results) == 2
        ids = {e.id for e in results}
        assert ids == {"d1", "d2"}

    def test_list_all_skips_files_without_embedded_id(self, tmp_path):
        """YAML files without an 'id' field are skipped in list_all."""
        tmpdir = str(tmp_path)
        repo = DummyRepository(base_path=tmpdir)
        file_path = repo.entity_dir / "auto-id.yaml"
        write_yaml_payload(file_path, {"name": "No ID"})

        results = repo.list_all()

        assert len(results) == 0


class TestGetById:
    """get_by_id returns single entity."""

    def test_get_by_id_returns_entity(self, tmp_path):
        tmpdir = str(tmp_path)
        repo = DummyRepository(base_path=tmpdir)
        repo.create({"id": "d1", "name": "Test"})
        entity = repo.get_by_id("d1")
        assert entity is not None
        assert entity.id == "d1"
        assert entity.name == "Test"

    def test_get_by_id_returns_none_for_missing(self, tmp_path):
        """get_by_id returns None for non-existent ID."""
        tmpdir = str(tmp_path)
        repo = DummyRepository(base_path=tmpdir)
        assert repo.get_by_id("nonexistent") is None

    def test_get_by_id_returns_none_for_file_without_embedded_id(self, tmp_path):
        """If YAML lacks 'id', get_by_id returns None."""
        tmpdir = str(tmp_path)
        repo = DummyRepository(base_path=tmpdir)
        file_path = repo.entity_dir / "auto-id.yaml"
        write_yaml_payload(file_path, {"name": "No ID"})

        entity = repo.get_by_id("auto-id")

        assert entity is None


class TestCreate:
    """create writes YAML file."""

    def test_create_writes_file(self, tmp_path):
        tmpdir = str(tmp_path)
        repo = DummyRepository(base_path=tmpdir)
        entity = repo.create({"id": "d1", "name": "Created"})
        assert entity.id == "d1"
        assert entity.name == "Created"
        # Verify file exists on disk
        assert (repo.entity_dir / "d1.yaml").exists()

    def test_create_without_id_raises(self, tmp_path):
        tmpdir = str(tmp_path)
        repo = DummyRepository(base_path=tmpdir)
        with pytest.raises(ValueError, match="must have an id"):
            repo.create({"name": "No ID"})

    def test_create_preserves_extra_fields(self, tmp_path):
        tmpdir = str(tmp_path)
        repo = DummyRepository(base_path=tmpdir)
        entity = repo.create({"id": "d1", "name": "Test", "extra_field": "value"})
        assert entity.id == "d1"
        # Verify round-trip via get_by_id
        fetched = repo.get_by_id("d1")
        assert fetched.extra_field == "value"


class TestUpdate:
    """update modifies YAML file."""

    def test_update_modifies_entity(self, tmp_path):
        tmpdir = str(tmp_path)
        repo = DummyRepository(base_path=tmpdir)
        repo.create({"id": "d1", "name": "Original"})
        updated = repo.update("d1", {"id": "d1", "name": "Updated"})
        assert updated.name == "Updated"
        assert updated.id == "d1"

    def test_update_nonexistent_raises_not_found(self, tmp_path):
        tmpdir = str(tmp_path)
        repo = DummyRepository(base_path=tmpdir)
        with pytest.raises(DummyNotFound):
            repo.update("missing", {"name": "Nope"})


class TestStrictEntityWriteValidation:
    def test_create_rejects_unknown_fields_without_writing_yaml(self, tmp_path):
        tmpdir = str(tmp_path)
        repo = StrictDummyRepository(base_path=tmpdir)
        file_path = repo.entity_dir / "d1.yaml"
        with pytest.raises(ValidationError):
            repo.create({"id": "d1", "name": "Test", "unsupported": "x"})
        assert not file_path.exists()

    def test_update_rejects_unknown_fields_without_mutating_yaml(self, tmp_path):
        tmpdir = str(tmp_path)
        repo = StrictDummyRepository(base_path=tmpdir)
        repo.create({"id": "d1", "name": "Original"})

        with pytest.raises(ValidationError):
            repo.update("d1", {"id": "d1", "name": "Updated", "unsupported": "x"})

        with open(repo.entity_dir / "d1.yaml", "r") as f:
            on_disk = yaml.safe_load(f)
        assert on_disk == {"id": "d1", "name": "Original"}


class TestDelete:
    """delete removes YAML file."""

    def test_delete_removes_file(self, tmp_path):
        tmpdir = str(tmp_path)
        repo = DummyRepository(base_path=tmpdir)
        repo.create({"id": "d1", "name": "Delete Me"})
        assert repo.delete("d1") is True
        assert not (repo.entity_dir / "d1.yaml").exists()
        assert repo.get_by_id("d1") is None

    def test_delete_nonexistent_returns_false(self, tmp_path):
        tmpdir = str(tmp_path)
        repo = DummyRepository(base_path=tmpdir)
        assert repo.delete("nonexistent") is False


class TestPathTraversal:
    """Path traversal in IDs is rejected."""

    def test_create_rejects_path_traversal(self, tmp_path):
        tmpdir = str(tmp_path)
        repo = DummyRepository(base_path=tmpdir)
        with pytest.raises(ValueError, match="[Ii]nvalid"):
            repo.create({"id": "../secret", "name": "Evil"})

    def test_get_by_id_rejects_path_traversal(self, tmp_path):
        tmpdir = str(tmp_path)
        repo = DummyRepository(base_path=tmpdir)
        with pytest.raises(ValueError, match="[Ii]nvalid"):
            repo.get_by_id("../secret")

    def test_update_rejects_path_traversal(self, tmp_path):
        tmpdir = str(tmp_path)
        repo = DummyRepository(base_path=tmpdir)
        with pytest.raises(ValueError, match="[Ii]nvalid"):
            repo.update("../secret", {"name": "Evil"})

    def test_delete_rejects_path_traversal(self, tmp_path):
        tmpdir = str(tmp_path)
        repo = DummyRepository(base_path=tmpdir)
        with pytest.raises(ValueError, match="[Ii]nvalid"):
            repo.delete("../secret")

    def test_rejects_slash_in_id(self, tmp_path):
        tmpdir = str(tmp_path)
        repo = DummyRepository(base_path=tmpdir)
        with pytest.raises(ValueError, match="[Ii]nvalid"):
            repo.create({"id": "sub/dir", "name": "Evil"})


class TestMalformedYaml:
    """Malformed YAML files are skipped in list_all."""

    def test_malformed_yaml_skipped(self, tmp_path):
        tmpdir = str(tmp_path)
        repo = DummyRepository(base_path=tmpdir)
        repo.create({"id": "good", "name": "Good"})
        bad_file = repo.entity_dir / "bad.yaml"
        bad_file.write_text(MALFORMED_YAML)

        results = repo.list_all()

        assert len(results) == 1
        assert results[0].id == "good"

    def test_empty_yaml_file_skipped(self, tmp_path):
        tmpdir = str(tmp_path)
        repo = DummyRepository(base_path=tmpdir)
        empty_file = repo.entity_dir / "empty.yaml"
        empty_file.write_text("")

        results = repo.list_all()

        assert len(results) == 0
