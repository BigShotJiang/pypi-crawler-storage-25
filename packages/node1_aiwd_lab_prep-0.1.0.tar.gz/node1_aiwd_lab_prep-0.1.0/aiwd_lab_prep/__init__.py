from pathlib import Path

__all__ = [
    "list_templates",
    "get_template",
    "get_html",
    "get_css",
    "get_js",
    "get_combined",
    "print_template",
    "save_template",
]
__version__ = "0.1.0"

_TEMPLATES = {
    "product_entry": {
        "title": "Product Entry Form",
        "html": """
<div class=\"container\">
    <h2>Product Entry Form</h2>
    <label>Product Name</label>
    <input type=\"text\" id=\"productName\" placeholder=\"Enter name\"> 

    <label>Price</label>
    <input type=\"number\" id=\"productPrice\" placeholder=\"Enter price\"> 

    <label>Category</label>
    <input type=\"text\" id=\"productCategory\" placeholder=\"Enter category\"> 

    <label>Description</label>
    <textarea id=\"productDescription\" placeholder=\"Enter description\"></textarea>

    <button onclick=\"submitProduct()\">Submit Product</button>
    <div id=\"productResult\" class=\"result\"></div>
</div>
""",
        "css": """
body { font-family: Arial, sans-serif; background: #eef2f7; margin: 0; padding: 20px; }
.container { max-width: 500px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
h2 { margin-top: 0; }
label { display: block; margin-top: 12px; font-weight: bold; }
input, textarea { width: 100%; padding: 10px; margin-top: 6px; border: 1px solid #ccc; border-radius: 4px; }
button { width: 100%; padding: 10px; margin-top: 16px; border: none; background: #007bff; color: white; border-radius: 4px; cursor: pointer; }
button:hover { background: #0056b3; }
.result { margin-top: 16px; padding: 12px; background: #f8f9fa; border: 1px solid #ddd; border-radius: 4px; }
""",
        "js": """
function submitProduct() {
    var name = document.getElementById('productName').value;
    var price = document.getElementById('productPrice').value;
    var category = document.getElementById('productCategory').value;
    var description = document.getElementById('productDescription').value;

    if (!name || !price || !category) {
        alert('Please fill in name, price, and category.');
        return;
    }

    document.getElementById('productResult').innerText =
        'Product added: ' + name + ' | ₹' + price + ' | ' + category + '\n' + description;
}
""",
    },
    "job_application": {
        "title": "Job Application Form",
        "html": """
<div class=\"container\">
    <h2>Job Application Form</h2>
    <label>Full Name</label>
    <input type=\"text\" id=\"applicantName\" placeholder=\"Full name\">

    <label>Email</label>
    <input type=\"email\" id=\"applicantEmail\" placeholder=\"Email address\">

    <label>Phone</label>
    <input type=\"tel\" id=\"applicantPhone\" placeholder=\"Phone number\">

    <label>Position Applied For</label>
    <input type=\"text\" id=\"position\" placeholder=\"Position\">

    <label>Experience</label>
    <textarea id=\"experience\" placeholder=\"Write your experience\"></textarea>

    <button onclick=\"submitApplication()\">Submit Application</button>
    <div id=\"applicationResult\" class=\"result\"></div>
</div>
""",
        "css": """
body { font-family: Arial, sans-serif; background: #f1f5f9; padding: 20px; }
.container { max-width: 520px; margin: 0 auto; background: white; padding: 22px; border-radius: 8px; box-shadow: 0 4px 14px rgba(0,0,0,0.08); }
label { display: block; margin-top: 14px; font-size: 0.95rem; }
input, textarea { width: 100%; padding: 10px; margin-top: 6px; border-radius: 5px; border: 1px solid #ccd6dd; }
button { margin-top: 18px; width: 100%; background: #28a745; color: white; border: none; padding: 12px; border-radius: 5px; cursor: pointer; }
button:hover { background: #218838; }
.result { margin-top: 15px; padding: 12px; color: #155724; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; white-space: pre-wrap; }
""",
        "js": """
function submitApplication() {
    var name = document.getElementById('applicantName').value;
    var email = document.getElementById('applicantEmail').value;
    var phone = document.getElementById('applicantPhone').value;
    var position = document.getElementById('position').value;
    var experience = document.getElementById('experience').value;

    if (!name || !email || !position) {
        alert('Name, email, and position are required.');
        return;
    }

    document.getElementById('applicationResult').innerText =
        'Application submitted for: ' + name + '\nPosition: ' + position + '\nEmail: ' + email + '\nPhone: ' + phone;
}
""",
    },
    "todo": {
        "title": "Todo List",
        "html": """
<div class=\"container\">
    <h2>Todo List</h2>
    <div class=\"input-row\">
        <input type=\"text\" id=\"todoText\" placeholder=\"New task\">
        <button onclick=\"addTodo()\">Add</button>
    </div>

    <ul id=\"todoList\" class=\"todo-list\"></ul>
</div>
""",
        "css": """
body { font-family: Arial, sans-serif; margin: 0; background: #f8fafc; padding: 20px; }
.container { max-width: 500px; margin: auto; background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
.input-row { display: flex; gap: 8px; margin-bottom: 14px; }
input { flex: 1; padding: 10px; border-radius: 5px; border: 1px solid #ccc; }
button { padding: 10px 16px; border: none; border-radius: 5px; background: #007bff; color: white; cursor: pointer; }
button:hover { background: #0069d9; }
.todo-list { list-style: none; padding: 0; margin: 0; }
.todo-list li { display: flex; justify-content: space-between; align-items: center; padding: 10px 12px; border: 1px solid #e2e8f0; border-radius: 6px; margin-bottom: 8px; }
.todo-list button { background: #dc3545; }
""",
        "js": """
function addTodo() {
    var value = document.getElementById('todoText').value;
    if (!value) {
        alert('Write a task first.');
        return;
    }

    var list = document.getElementById('todoList');
    var li = document.createElement('li');
    li.innerHTML =
        '<span>' + value + '</span>' +
        ' <button onclick=\"this.parentElement.remove()\">Delete</button>';
    list.appendChild(li);
    document.getElementById('todoText').value = '';
}
""",
    },
    "complaint_registration": {
        "title": "Complaint Registration",
        "html": """
<div class=\"container\">
    <h2>Complaint Registration</h2>
    <label>Your Name</label>
    <input type=\"text\" id=\"complaintName\" placeholder=\"Name\">

    <label>Phone or Email</label>
    <input type=\"text\" id=\"complaintContact\" placeholder=\"Contact details\">

    <label>Complaint Type</label>
    <select id=\"complaintType\">
        <option value=\"Billing\">Billing</option>
        <option value=\"Service\">Service</option>
        <option value=\"Other\">Other</option>
    </select>

    <label>Complaint Details</label>
    <textarea id=\"complaintDetails\" placeholder=\"Describe problem\"></textarea>

    <button onclick=\"submitComplaint()\">Submit Complaint</button>
    <div id=\"complaintResult\" class=\"result\"></div>
</div>
""",
        "css": """
body { font-family: Arial, sans-serif; background: #eef2ff; padding: 20px; }
.container { max-width: 520px; margin: auto; background: white; padding: 22px; border-radius: 8px; box-shadow: 0 3px 12px rgba(0,0,0,0.08); }
label { display: block; margin-top: 12px; font-weight: 600; }
input, textarea, select { width: 100%; padding: 10px; margin-top: 6px; border-radius: 4px; border: 1px solid #b8c6db; }
button { width: 100%; margin-top: 16px; padding: 12px; border: none; border-radius: 5px; background: #17a2b8; color: white; cursor: pointer; }
button:hover { background: #117a8b; }
.result { margin-top: 16px; padding: 12px; border: 1px solid #c8e5ff; background: #e9f7ff; border-radius: 5px; }
""",
        "js": """
function submitComplaint() {
    var name = document.getElementById('complaintName').value;
    var contact = document.getElementById('complaintContact').value;
    var type = document.getElementById('complaintType').value;
    var details = document.getElementById('complaintDetails').value;

    if (!name || !contact || !details) {
        alert('Please fill name, contact, and details.');
        return;
    }

    document.getElementById('complaintResult').innerText =
        'Complaint submitted for ' + name + ' (' + type + ').\nContact: ' + contact + '\nDetails: ' + details;
}
""",
    },
    "registration_login": {
        "title": "Registration and Login",
        "html": """
<div class=\"container\">
    <h2>Register / Login</h2>
    <div class=\"card\">
        <h3>Register</h3>
        <label>Name</label>
        <input type=\"text\" id=\"regName\" placeholder=\"Your name\">
        <label>Email</label>
        <input type=\"email\" id=\"regEmail\" placeholder=\"Email\">
        <label>Password</label>
        <input type=\"password\" id=\"regPassword\" placeholder=\"Password\">
        <button onclick=\"registerUser()\">Register</button>
    </div>
    <div class=\"card\">
        <h3>Login</h3>
        <label>Email</label>
        <input type=\"email\" id=\"loginEmail\" placeholder=\"Email\">
        <label>Password</label>
        <input type=\"password\" id=\"loginPassword\" placeholder=\"Password\">
        <button onclick=\"loginUser()\">Login</button>
    </div>
    <div id=\"authResult\" class=\"result\"></div>
</div>
""",
        "css": """
body { font-family: Arial, sans-serif; margin: 0; background: #f4f7fc; padding: 20px; }
.container { max-width: 560px; margin: auto; }
.card { background: white; padding: 18px; border-radius: 8px; box-shadow: 0 2px 12px rgba(31,38,135,0.08); margin-bottom: 16px; }
label { display: block; margin-top: 12px; color: #333; }
input { width: 100%; padding: 10px; margin-top: 6px; border: 1px solid #cbd4e1; border-radius: 5px; }
button { width: 100%; padding: 12px; margin-top: 14px; background: #6610f2; color: white; border: none; border-radius: 5px; cursor: pointer; }
button:hover { background: #520dc2; }
.result { padding: 14px; background: #fff3cd; border: 1px solid #ffeeba; border-radius: 5px; }
""",
        "js": """
function registerUser() {
    var name = document.getElementById('regName').value;
    var email = document.getElementById('regEmail').value;
    var password = document.getElementById('regPassword').value;

    if (!name || !email || !password) {
        alert('Please fill all registration fields.');
        return;
    }

    document.getElementById('authResult').innerText =
        'Registered ' + name + ' with email ' + email + '.';
}

function loginUser() {
    var email = document.getElementById('loginEmail').value;
    var password = document.getElementById('loginPassword').value;

    if (!email || !password) {
        alert('Please fill login email and password.');
        return;
    }

    document.getElementById('authResult').innerText =
        'Login attempted for ' + email + '.';
}
""",
    },
    "product_listing": {
        "title": "Product Listing and Cart",
        "html": """
<div class=\"container\">
    <h2>Product Listing</h2>
    <div class=\"product-grid\">
        <div class=\"product-card\">
            <h4>Notebook</h4>
            <p>₹120</p>
            <button onclick=\"addToCart('Notebook', 120)\">Add to Cart</button>
        </div>
        <div class=\"product-card\">
            <h4>Pen Set</h4>
            <p>₹80</p>
            <button onclick=\"addToCart('Pen Set', 80)\">Add to Cart</button>
        </div>
        <div class=\"product-card\">
            <h4>Water Bottle</h4>
            <p>₹150</p>
            <button onclick=\"addToCart('Water Bottle', 150)\">Add to Cart</button>
        </div>
    </div>
    <h3>Cart</h3>
    <ul id=\"cartList\" class=\"cart-list\"></ul>
</div>
""",
        "css": """
body { font-family: Arial, sans-serif; background: #f6f9fc; margin: 0; padding: 20px; }
.container { max-width: 740px; margin: auto; }
.product-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 16px; margin-bottom: 18px; }
.product-card { background: white; padding: 16px; border-radius: 10px; border: 1px solid #dde5f0; text-align: center; }
.product-card button { margin-top: 12px; padding: 8px 12px; border: none; border-radius: 6px; background: #17a2b8; color: white; cursor: pointer; }
.product-card button:hover { background: #138496; }
.cart-list { list-style: none; padding: 0; }
.cart-list li { display: flex; justify-content: space-between; align-items: center; padding: 10px 12px; border: 1px solid #e8eef4; margin-bottom: 8px; border-radius: 8px; background: white; }
.cart-list button { background: #dc3545; color: white; border: none; border-radius: 5px; padding: 6px 10px; cursor: pointer; }
""",
        "js": """
function addToCart(name, price) {
    var list = document.getElementById('cartList');
    var li = document.createElement('li');
    li.innerHTML =
        '<span>' + name + ' - ₹' + price + '</span>' +
        ' <button onclick=\"this.parentElement.remove()\">Remove</button>';
    list.appendChild(li);
}
""",
    },
    "appointment_booking": {
        "title": "Appointment Booking",
        "html": """
<div class=\"container\">
    <h2>Appointment Booking</h2>
    <label>Your Name</label>
    <input type=\"text\" id=\"bookName\" placeholder=\"Name\">

    <label>Service</label>
    <input type=\"text\" id=\"bookService\" placeholder=\"Service required\">

    <label>Date</label>
    <input type=\"date\" id=\"bookDate\">

    <label>Time</label>
    <input type=\"time\" id=\"bookTime\">

    <button onclick=\"bookAppointment()\">Book Appointment</button>
    <div id=\"bookingResult\" class=\"result\"></div>
</div>
""",
        "css": """
body { font-family: Arial, sans-serif; background: #f7f8fd; padding: 20px; }
.container { max-width: 520px; margin: auto; background: white; padding: 22px; border-radius: 10px; box-shadow: 0 4px 14px rgba(0,0,0,0.07); }
label { display: block; margin-top: 12px; }
input { width: 100%; padding: 10px; margin-top: 6px; border-radius: 5px; border: 1px solid #cbd5e1; }
button { width: 100%; margin-top: 16px; padding: 12px; background: #0069d9; color: white; border: none; border-radius: 5px; cursor: pointer; }
button:hover { background: #0056b3; }
.result { margin-top: 16px; padding: 14px; background: #e2f0ff; border: 1px solid #b8daff; border-radius: 5px; }
""",
        "js": """
function bookAppointment() {
    var name = document.getElementById('bookName').value;
    var service = document.getElementById('bookService').value;
    var date = document.getElementById('bookDate').value;
    var time = document.getElementById('bookTime').value;

    if (!name || !service || !date || !time) {
        alert('Please fill all fields before booking.');
        return;
    }

    document.getElementById('bookingResult').innerText =
        'Appointment booked for ' + name + ' on ' + date + ' at ' + time + ' for ' + service + '.';
}
""",
    },
    "quiz_interface": {
        "title": "Quiz Interface",
        "html": """
<div class=\"container\">
    <h2>Quiz Interface</h2>
    <div class=\"question\">
        <p>1. HTML is used for?</p>
        <label><input type=\"radio\" name=\"q1\" value=\"a\"> Styling</label>
        <label><input type=\"radio\" name=\"q1\" value=\"b\"> Structure</label>
        <label><input type=\"radio\" name=\"q1\" value=\"c\"> Logic</label>
    </div>
    <div class=\"question\">
        <p>2. CSS stands for?</p>
        <label><input type=\"radio\" name=\"q2\" value=\"a\"> Cascading Style Sheets</label>
        <label><input type=\"radio\" name=\"q2\" value=\"b\"> Computer Style Syntax</label>
        <label><input type=\"radio\" name=\"q2\" value=\"c\"> Custom Script Source</label>
    </div>
    <div class=\"question\">
        <p>3. JavaScript is used to?</p>
        <label><input type=\"radio\" name=\"q3\" value=\"a\"> Create page structure</label>
        <label><input type=\"radio\" name=\"q3\" value=\"b\"> Add interactivity</label>
        <label><input type=\"radio\" name=\"q3\" value=\"c\"> Add server data</label>
    </div>
    <button onclick=\"submitQuiz()\">Submit Quiz</button>
    <div id=\"quizResult\" class=\"result\"></div>
</div>
""",
        "css": """
body { font-family: Arial, sans-serif; background: #fbfbfb; padding: 20px; }
.container { max-width: 620px; margin: auto; background: white; padding: 22px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }
.question { margin-bottom: 18px; }
.question p { margin-bottom: 8px; font-weight: bold; }
label { display: block; margin-bottom: 6px; cursor: pointer; }
button { background: #28a745; color: white; border: none; padding: 12px 16px; border-radius: 6px; cursor: pointer; }
button:hover { background: #218838; }
.result { margin-top: 16px; padding: 14px; background: #fff3cd; border: 1px solid #ffeeba; border-radius: 6px; }
""",
        "js": """
function submitQuiz() {
    var score = 0;
    if (document.querySelector('input[name=q1]:checked')?.value === 'b') score += 1;
    if (document.querySelector('input[name=q2]:checked')?.value === 'a') score += 1;
    if (document.querySelector('input[name=q3]:checked')?.value === 'b') score += 1;

    document.getElementById('quizResult').innerText =
        'Score: ' + score + ' / 3';
}
""",
    },
    "student_marks": {
        "title": "Student Marks Calculator",
        "html": """
<div class=\"container\">
    <h2>Student Marks Calculator</h2>
    <label>Maths</label>
    <input type=\"number\" id=\"mark1\" value=\"0\">
    <label>Science</label>
    <input type=\"number\" id=\"mark2\" value=\"0\">
    <label>English</label>
    <input type=\"number\" id=\"mark3\" value=\"0\">
    <label>Social</label>
    <input type=\"number\" id=\"mark4\" value=\"0\">
    <label>Hindi</label>
    <input type=\"number\" id=\"mark5\" value=\"0\">
    <button onclick=\"calculateMarks()\">Calculate Grade</button>
    <div id=\"marksResult\" class=\"result\"></div>
</div>
""",
        "css": """
body { font-family: Arial, sans-serif; background: #f2f6f9; padding: 20px; }
.container { max-width: 520px; margin: auto; background: white; padding: 22px; border-radius: 10px; box-shadow: 0 3px 12px rgba(0,0,0,0.09); }
label { display: block; margin-top: 12px; }
input { width: 100%; padding: 10px; margin-top: 6px; border-radius: 5px; border: 1px solid #b8c7d4; }
button { width: 100%; margin-top: 18px; padding: 12px; border: none; border-radius: 5px; background: #007bff; color: white; cursor: pointer; }
button:hover { background: #0056d2; }
.result { margin-top: 16px; padding: 14px; border: 1px solid #cce5ff; background: #e9f7ff; border-radius: 6px; }
""",
        "js": """
function calculateMarks() {
    var m1 = Number(document.getElementById('mark1').value);
    var m2 = Number(document.getElementById('mark2').value);
    var m3 = Number(document.getElementById('mark3').value);
    var m4 = Number(document.getElementById('mark4').value);
    var m5 = Number(document.getElementById('mark5').value);
    var total = m1 + m2 + m3 + m4 + m5;
    var percentage = total / 5;
    var grade = 'F';
    if (percentage >= 90) grade = 'A';
    else if (percentage >= 75) grade = 'B';
    else if (percentage >= 60) grade = 'C';
    else if (percentage >= 50) grade = 'D';

    document.getElementById('marksResult').innerText =
        'Total: ' + total + '\nPercentage: ' + percentage.toFixed(1) + '%\nGrade: ' + grade;
}
""",
    },
}


def list_templates():
    """Return the available template names."""
    return list(_TEMPLATES.keys())


def _get_template_data(name):
    try:
        return _TEMPLATES[name]
    except KeyError as exc:
        raise KeyError(f"Unknown template: {name}") from exc


def get_html(name):
    """Return the HTML body content for the named template."""
    return _get_template_data(name)["html"]


def get_css(name):
    """Return the CSS code for the named template."""
    return _get_template_data(name)["css"]


def get_js(name):
    """Return the JavaScript code for the named template."""
    return _get_template_data(name)["js"]


def get_template(name):
    """Return all code sections for the named template."""
    data = _get_template_data(name)
    return {
        "html": data["html"],
        "css": data["css"],
        "js": data["js"],
        "combined": get_combined(name),
        "title": data["title"],
    }


def get_combined(name):
    """Return a full HTML document with CSS and JS embedded."""
    data = _get_template_data(name)
    return f"""<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <title>{data['title']}</title>
    <style>{data['css']}</style>
</head>
<body>
{data['html']}
    <script>{data['js']}</script>
</body>
</html>
"""


def print_template(name):
    """Print the template sections to the console."""
    data = get_template(name)
    print('=== HTML ===\n')
    print(data["html"])
    print('\n=== CSS ===\n')
    print(data["css"])
    print('\n=== JavaScript ===\n')
    print(data["js"])


def save_template(name, path):
    """Save the full combined HTML file for the named template."""
    html = get_combined(name)
    destination = Path(path)
    destination.write_text(html, encoding="utf-8")
    return destination
