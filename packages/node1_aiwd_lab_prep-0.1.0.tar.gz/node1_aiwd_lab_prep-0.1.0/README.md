# AIWD Lab Prep

A minimal Python package that includes multiple HTML, CSS, and JavaScript templates for AIWD lab exam practice.

## What is included

- `product_entry`: Product entry form with fields for name, price, category, description.
- `job_application`: Job application form with inputs for name, email, phone, position, and experience.
- `todo`: Todo list with add/delete actions.
- `complaint_registration`: Complaint registration form with issue details.
- `registration_login`: Registration and login form.
- `product_listing`: Product listing with add/remove cart actions.
- `appointment_booking`: Appointment booking form with date/time.
- `quiz_interface`: Simple quiz interface with score output.
- `student_marks`: Marks calculator with total, percentage, and grade.

## Usage

1. Install the package locally:

```bash
pip install .
```

2. Use it from Python:

```python
from aiwd_lab_prep import (
    list_templates,
    get_html,
    get_css,
    get_js,
    get_combined,
    print_template,
    save_template,
)

print(list_templates())

# Print all sections for a template
print_template('job_application')

# Save a full HTML file
save_template('todo', 'todo_list.html')

# Get separate sections
html_code = get_html('quiz_interface')
css_code = get_css('quiz_interface')
js_code = get_js('quiz_interface')
```

## Build and upload to PyPI

```bash
pip install --upgrade setuptools wheel twine
python setup.py sdist bdist_wheel
twine upload dist/*
```

> Replace `name` in `setup.py` with your own unique package name before uploading to PyPI.
