"""Per-session tool activation state for progressive tool discovery.

Upgrade 1 of the MCP talk pattern. When a user calls `g8_tool_search`, we
remember which tools they activated so subsequent `tools/list` responses
include those schemas. State is scoped to a logical session so one user's
discoveries don't leak into another's connection.

We key the session on the resolved API key (sha256'd) rather than
`Mcp-Session-Id` because our Streamable HTTP manager runs in `stateless=True`
mode (no stable session IDs across requests). The effect is the same from the
user's perspective: activated tools persist across their tool calls within the
TTL window (4h).

Redis layout:
- Key:   mcp:session_tools:{api_key_sha}
- Type:  SET of tool names
- TTL:   4h (refreshed on every add)

Fallback: if Redis is unavailable, we fall back to a process-local dict so
local development + stdio transport still work. The dict entries never expire
inside a single process run but are obviously not shared across replicas.
"""

from __future__ import annotations

import hashlib
import logging
import time
from typing import Iterable

logger = logging.getLogger(__name__)

_SESSION_PREFIX = "mcp:session_tools:"
_SESSION_TTL = 4 * 3600  # 4 hours

# In-memory fallback keyed by session_id → (expires_epoch, set[tool_name]).
_local_cache: dict[str, tuple[float, set[str]]] = {}


def session_id_for_key(api_key: str) -> str:
    """Derive a stable session identifier from the caller's API key.

    We hash so we never log plaintext keys as part of Redis traffic; the first
    16 hex chars are plenty of entropy to avoid collisions across active users.
    """
    if not api_key:
        return "anonymous"
    return hashlib.sha256(api_key.encode()).hexdigest()[:16]


def _redis_key(session_id: str) -> str:
    return f"{_SESSION_PREFIX}{session_id}"


async def _redis_client():
    """Lazy-import the shared Redis client to avoid pulling it in for stdio."""
    try:
        from shared import apps

        return apps.infra().redis()
    except Exception:
        return None


async def get_activated(session_id: str) -> frozenset[str]:
    """Return the set of tool names this session has already activated."""
    if not session_id:
        return frozenset()

    # 1) Redis (shared across replicas)
    redis = await _redis_client()
    if redis is not None:
        try:
            members = await redis.smembers(_redis_key(session_id))
            if members:
                return frozenset(
                    m.decode() if isinstance(m, (bytes, bytearray)) else m for m in members
                )
        except Exception as e:
            logger.debug("MCP session_tools: Redis smembers failed (%s) - falling back to local", e)

    # 2) In-memory fallback
    entry = _local_cache.get(session_id)
    if not entry:
        return frozenset()
    expires, tools = entry
    if expires < time.time():
        _local_cache.pop(session_id, None)
        return frozenset()
    return frozenset(tools)


async def add_activated(session_id: str, tool_names: Iterable[str]) -> frozenset[str]:
    """Activate `tool_names` for the session, returning the new full set.

    Idempotent: re-activating an already-active tool is a no-op. TTL is
    refreshed on every call so an actively-browsing user never loses their
    discovered surface mid-session.
    """
    names = [t for t in tool_names if t]
    if not session_id or not names:
        return await get_activated(session_id)

    # 1) Redis
    redis = await _redis_client()
    if redis is not None:
        try:
            key = _redis_key(session_id)
            await redis.sadd(key, *names)
            await redis.expire(key, _SESSION_TTL)
        except Exception as e:
            logger.debug("MCP session_tools: Redis sadd failed (%s) - using local cache", e)

    # 2) In-memory fallback (always update, so tests without Redis still work)
    existing = _local_cache.get(session_id)
    tools = set(existing[1]) if existing else set()
    tools.update(names)
    _local_cache[session_id] = (time.time() + _SESSION_TTL, tools)

    return await get_activated(session_id)


async def clear_session(session_id: str) -> None:
    """Drop all activated tools for a session (test helper / explicit reset)."""
    if not session_id:
        return
    redis = await _redis_client()
    if redis is not None:
        try:
            await redis.delete(_redis_key(session_id))
        except Exception:
            pass
    _local_cache.pop(session_id, None)
