"""MCP resources - read-only context agents can include in prompts.

Most resources return JSON strings via `format_result`. A small number are
"app surfaces" (`mimeType="text/html"`) - Upgrade 4 from the Nov 2026
Anthropic AI Engineer talk. HTML surfaces render inline in Claude.ai;
clients that cannot render HTML fall back to the plain-text renderer.
See `g8_mcp_server.app_renderer` for the rules (inline CSS only, no JS,
HTML-escape everything).
"""

from __future__ import annotations

import json
import logging

from mcp.server import FastMCP

from g8_mcp_server.app_html_cache import cache_key_for_api_key, cached_render
from g8_mcp_server.app_renderer import (
    render_activities_feed_html,
    render_activities_feed_text_fallback,
    render_activities_today_html,
    render_activities_today_text_fallback,
    render_activity_detail_html,
    render_activity_detail_text_fallback,
    render_ad_images_html,
    render_ad_images_text_fallback,
    render_audience_sync_detail_html,
    render_audience_sync_detail_text_fallback,
    render_audience_syncs_dashboard_html,
    render_audience_syncs_dashboard_text_fallback,
    render_campaign_document_detail_html,
    render_campaign_document_detail_text_fallback,
    render_campaign_documents_html,
    render_campaign_documents_text_fallback,
    render_campaign_ideas_dashboard_html,
    render_campaign_ideas_dashboard_text_fallback,
    render_campaign_sequence_html,
    render_campaign_sequence_text_fallback,
    render_campaign_detail_html,
    render_campaign_detail_text_fallback,
    render_campaigns_dashboard_html,
    render_campaigns_dashboard_text_fallback,
    render_companies_dashboard_html,
    render_companies_dashboard_text_fallback,
    render_companies_country_html,
    render_companies_country_text_fallback,
    render_companies_size_html,
    render_companies_size_text_fallback,
    render_companies_revenue_html,
    render_companies_revenue_text_fallback,
    render_deals_stage_html,
    render_deals_stage_text_fallback,
    render_deals_owner_html,
    render_deals_owner_text_fallback,
    render_companies_industry_html,
    render_companies_industry_text_fallback,
    render_company_activities_html,
    render_company_activities_text_fallback,
    render_company_contacts_html,
    render_company_contacts_text_fallback,
    render_company_deals_html,
    render_company_deals_text_fallback,
    render_company_detail_html,
    render_company_detail_text_fallback,
    render_company_fields_schema_html,
    render_company_fields_schema_text_fallback,
    render_company_notes_html,
    render_company_notes_text_fallback,
    render_contact_activities_html,
    render_contact_activities_text_fallback,
    render_contact_deals_html,
    render_contact_deals_text_fallback,
    render_contact_detail_html,
    render_contact_detail_text_fallback,
    render_contacts_department_html,
    render_contacts_department_text_fallback,
    render_contacts_engagement_html,
    render_contacts_engagement_text_fallback,
    render_contacts_seniority_html,
    render_contacts_seniority_text_fallback,
    render_contacts_source_html,
    render_contacts_source_text_fallback,
    render_contact_fields_schema_html,
    render_contact_fields_schema_text_fallback,
    render_contact_notes_html,
    render_contact_notes_text_fallback,
    render_contact_tasks_html,
    render_contact_tasks_text_fallback,
    render_contacts_dashboard_html,
    render_contacts_dashboard_text_fallback,
    render_copilot_home_html,
    render_copilot_home_text_fallback,
    render_crm_fields_schema_html,
    render_crm_fields_schema_text_fallback,
    render_crm_sync_overview_html,
    render_crm_sync_overview_text_fallback,
    render_crm_syncs_dashboard_html,
    render_crm_syncs_dashboard_text_fallback,
    render_deal_activities_html,
    render_deal_activities_text_fallback,
    render_deal_detail_html,
    render_deal_detail_text_fallback,
    render_deals_dashboard_html,
    render_deals_dashboard_text_fallback,
    render_deals_this_week_html,
    render_deals_this_week_text_fallback,
    render_account_detail_html,
    render_account_detail_text_fallback,
    render_system_credit_usage_html,
    render_system_credit_usage_text_fallback,
    render_pipeline_deals_html,
    render_pipeline_deals_text_fallback,
    render_deals_pipeline_html,
    render_deals_pipeline_text_fallback,
    render_enrichment_job_html,
    render_enrichment_job_text_fallback,
    render_form_snippet_html,
    render_form_snippet_text_fallback,
    render_global_context_library_html,
    render_global_context_library_text_fallback,
    render_icp_dashboard_html,
    render_icp_dashboard_text_fallback,
    render_icp_detail_html,
    render_icp_detail_text_fallback,
    render_inbox_dashboard_html,
    render_inbox_dashboard_text_fallback,
    render_inbox_draft_html,
    render_inbox_draft_text_fallback,
    render_inbox_thread_detail_html,
    render_inbox_thread_detail_text_fallback,
    render_gc_doc_detail_html,
    render_gc_doc_detail_text_fallback,
    render_task_detail_html,
    render_task_detail_text_fallback,
    render_kb_library_html,
    render_kb_library_text_fallback,
    render_list_detail_html,
    render_list_detail_text_fallback,
    render_list_members_html,
    render_list_members_text_fallback,
    render_lists_dashboard_html,
    render_lists_dashboard_text_fallback,
    render_persona_dashboard_html,
    render_persona_dashboard_text_fallback,
    render_persona_detail_html,
    render_persona_detail_text_fallback,
    render_pipelines_overview_html,
    render_pipelines_overview_text_fallback,
    render_repo_detail_html,
    render_repo_detail_text_fallback,
    render_repo_install_html,
    render_repo_install_text_fallback,
    render_repo_scan_html,
    render_repo_scan_text_fallback,
    render_repo_snippet_html,
    render_repo_snippet_text_fallback,
    render_repo_streams_html,
    render_repo_streams_text_fallback,
    render_repos_dashboard_html,
    render_repos_dashboard_text_fallback,
    render_sequence_analytics_html,
    render_sequence_analytics_text_fallback,
    render_sequence_contacts_html,
    render_sequence_contacts_text_fallback,
    render_sequence_detail_html,
    render_sequence_detail_text_fallback,
    render_sequence_preview_html,
    render_sequence_preview_text_fallback,
    render_inbox_channel_html,
    render_inbox_channel_text_fallback,
    render_sequence_inbox_html,
    render_sequence_inbox_text_fallback,
    render_sequence_step_detail_html,
    render_sequence_step_detail_text_fallback,
    render_sequences_dashboard_html,
    render_sequences_dashboard_text_fallback,
    render_snippet_install_html,
    render_snippet_install_text_fallback,
    render_sync_errors_html,
    render_sync_errors_text_fallback,
    render_sync_runs_history_html,
    render_sync_runs_history_text_fallback,
    render_tasks_dashboard_html,
    render_tasks_dashboard_text_fallback,
    render_tasks_due_today_html,
    render_tasks_due_today_text_fallback,
    render_tasks_priority_html,
    render_tasks_priority_text_fallback,
    render_tasks_status_html,
    render_tasks_status_text_fallback,
    render_webhook_deliveries_html,
    render_webhook_deliveries_text_fallback,
    render_webhook_detail_html,
    render_webhook_detail_text_fallback,
    render_webhook_events_html,
    render_webhook_events_text_fallback,
    render_webhooks_dashboard_html,
    render_webhooks_dashboard_text_fallback,
)
from g8_mcp_server.client import G8Client, G8ClientError, format_result
from g8_mcp_server.skills import SKILLS_CATALOG, get_skill_content
from g8_mcp_server.ui_apps import claude_mcp_domain, register_ui_app_resource

logger = logging.getLogger(__name__)


def register(server: FastMCP, client: G8Client) -> None:
    """Register all MCP resources on the server."""

    # ------------------------------------------------------------------ #
    # MCP Apps (interactive widget) surfaces.                            #
    #                                                                    #
    # These use the `ui://` scheme + `text/html;profile=mcp-app` mime    #
    # type per the MCP Apps spec (launched 2026-01-26). Hosts that       #
    # support the extension (claude.ai, Claude Desktop, VS Code Copilot, #
    # Goose, ...) render these inline as sandboxed iframe widgets when   #
    # the linked tool fires. Non-supporting hosts ignore them.           #
    #                                                                    #
    # The tool→resource link lives on the TOOL side, via                 #
    # `_meta.ui.resourceUri` (see `tools/gtm.py::get_ad_images` etc).    #
    # Here we only register the resource + its CSP.                      #
    #                                                                    #
    # Spec: https://modelcontextprotocol.io/extensions/apps/overview     #
    # ------------------------------------------------------------------ #
    # ---- Shared view-config snippets -----------------------------------
    # The "ad-images detail" view is used in two places:
    #   1. As the root view of the standalone ui://campaigns/ad-images
    #      widget (when Claude calls g8_gtm_get_ad_images directly).
    #   2. As the drill-in target inside the dashboard widget (when the
    #      user clicks a campaign card).
    # Both render identically; only their place in the nav stack differs.
    # We define the shared view body once and reuse it.
    _ad_images_view = {
        "type": "image_grid",
        "data_path": "images",
        "loading_text": "Loading ad creatives...",
        "empty_text": "No ad creatives to show. Generate some first.",
        "row_key": "image_id",
        "title": "Ad creatives",
        "title_template": "Ad creatives - {campaign_name}",
        # Campaign-id orphan guard: a stale response from a back-then-
        # forward sequence won't overwrite the newer view's data.
        "context_match_fields": ["campaign_id"],
        # campaign_name is returned by g8_gtm_get_ad_images; capture it
        # for the title even when the standalone widget didn't get a
        # campaign_name pushed via context.
        "capture_from_result": ["campaign_id", "campaign_name"],
        "image": {
            "src_field": "image_url",
            "alt_field": "alt_text",
            "alt_fallback_field": "style",
            "alt_default": "ad creative",
            "aspect_ratio": "1.91 / 1",
        },
        "pills": [
            {"field": "platform", "default": "creative"},
        ],
        "actions": [
            {
                "id": "hide",
                "label": "Hide",
                "title": "Hide this creative (marks feedback=down)",
                "tool": "g8_gtm_hide_ad_image",
                "args_from_row": {"image_id": "image_id"},
                "args_from_context": {"campaign_id": "campaign_id"},
                "busy_text": "Hiding...",
                "optimistic_class": "hiding",
                "on_success": {
                    "mutation": "remove_card",
                    "match_field": "image_id",
                    "result_field": "hidden_image_id",
                    "context_match_field": "campaign_id",
                },
            },
        ],
    }

    # ---- shared detail / drill-in view configs -------------------------
    # Each detail view is defined ONCE here and reused in two places:
    #   1. As a sibling view inside a list widget's view_config
    #      (so the list pushes the detail in-place when a row is clicked).
    #   2. As the root view of a standalone `ui://*/detail` resource,
    #      so the model can call the detail tool directly and still get
    #      the rendered widget (no list context required).
    # Both paths flow through shell.html's renderDetail() with the same
    # config dict; only the nav-stack depth differs.
    #
    # All `data_path: "__self__"` views opt into the single-object dispatch
    # path: the whole structuredContent IS the entity, not a wrapper
    # around an array.

    _contact_detail_view = {
        "type": "detail",
        "data_path": "__self__",
        "loading_text": "Loading contact...",
        "empty_text": "Contact not found.",
        "title": "Contact",
        # Contacts come back from g8_get_contact_detail with split-name
        # fields. The interpolate() helper falls back to the static title
        # when both name parts are empty so we never render "  ".
        "title_template": "{first_name} {last_name}",
        "stat_cards": [
            {"label": "Title", "key": "job_title"},
            {"label": "Company", "key": "company_name"},
            {"label": "Seniority", "key": "seniority_level", "type": "pill"},
        ],
        "fields": [
            {"label": "Email", "key": "work_email", "type": "link"},
            {"label": "Phone", "key": "phone"},
            {"label": "LinkedIn", "key": "linkedin_url", "type": "link"},
            {"label": "Department", "key": "department"},
            {"label": "City", "key": "city"},
            {"label": "Country", "key": "country"},
            {"label": "Industry", "key": "company_industry"},
            {"label": "Domain", "key": "company_domain"},
        ],
    }

    _sequence_detail_view = {
        "type": "detail",
        "data_path": "__self__",
        "loading_text": "Loading sequence...",
        # When the backend returns a SequencePreview with all-null fields
        # (e.g. a draft sequence with no preview generated yet), the
        # default empty check would still try to render the wall of stat
        # cards and dashes. `empty_when_key` makes the view treat a null
        # `id` as "no detail available" and render `empty_text` instead.
        "empty_when_key": "id",
        "empty_text": "Sequence preview unavailable. The sequence may be a draft or have no steps configured.",
        "title": "Sequence",
        "title_template": "{name}",
        "stat_cards": [
            {"label": "Status", "key": "status", "type": "pill", "semantic": True},
            {"label": "Steps", "template": "{steps.length}", "key": "step_count"},
            {"label": "Channels", "template": "{channels.length}", "key": "channel_count"},
        ],
        "fields": [
            {"label": "Description", "key": "description", "type": "multiline", "hide_when_empty": True},
            {"label": "ID", "key": "id"},
        ],
        "sections": [
            {
                "id": "steps",
                "label": "Steps",
                "data_path": "steps",
                "item_template": "Step {step_order}: {step_type} (wait {time_interval}h)",
                "empty_text": "No steps configured.",
                "hide_when_empty": False,
            },
            {
                "id": "channels",
                "label": "Channels",
                "data_path": "channels",
                "item_template": "{channel_type}: {channel_value}",
                "hide_when_empty": True,
            },
        ],
    }

    _inbox_thread_view = {
        "type": "detail",
        "data_path": "__self__",
        "loading_text": "Loading thread...",
        "empty_text": "Thread not found.",
        "title": "Thread",
        "title_template": "{subject}",
        "stat_cards": [
            {"label": "Channel", "key": "channel", "type": "pill"},
            {"label": "Status", "key": "status", "type": "pill", "semantic": True},
            # Contact name has multi-shape risk per PR A inbox regression.
            # The detail endpoint may populate `name` OR split fields; the
            # template falls back to email when both are empty.
            {"label": "Contact", "template": "{contact.name}", "key": "contact.email"},
        ],
        "fields": [
            {"label": "Subject", "key": "subject"},
            {"label": "Created", "key": "created_at"},
            {"label": "Updated", "key": "updated_at"},
        ],
        "sections": [
            {
                "id": "messages",
                "label": "Messages",
                "data_path": "messages",
                "item_type": "timeline",
                # Backend canonical fields per developer_api InboxMessageItem:
                # `from_address`, `responder` (USER/AI/OTHER), `date`,
                # `content`. The shell falls back to "(no subject)" when
                # primary_template is empty, so an empty `from_address`
                # still renders a usable card.
                "primary_template": "{responder}: {from_address}",
                "meta_template": "{date}",
                "body_key": "content",
                "empty_text": "No messages in this thread yet.",
            },
        ],
    }

    _company_detail_view = {
        # Used by the standalone ui://companies/detail surface, which is
        # the widget for g8_lookup_company (open-data, costs 1 credit).
        # Not wired as a row-click target from companies/list (that drills
        # into the free contacts-at-company view instead).
        "type": "detail",
        "data_path": "__self__",
        "loading_text": "Looking up company...",
        "empty_text": "Company not found.",
        "title": "Company",
        "title_template": "{name}",
        "stat_cards": [
            {"label": "Industry", "key": "industry"},
            {"label": "Headcount", "key": "employee_count"},
            {"label": "Country", "key": "country"},
        ],
        "fields": [
            {"label": "Domain", "key": "domain", "type": "link"},
            {"label": "Description", "key": "description", "type": "multiline", "hide_when_empty": True},
            {"label": "Revenue", "key": "revenue", "hide_when_empty": True},
            {"label": "Founded", "key": "founded_year", "hide_when_empty": True},
            {"label": "LinkedIn", "key": "linkedin_url", "type": "link", "hide_when_empty": True},
            {"label": "Confidence", "key": "confidence_score", "hide_when_empty": True},
        ],
    }

    _deal_detail_view = {
        "type": "detail",
        "data_path": "__self__",
        "loading_text": "Loading deal...",
        "empty_text": "Deal not found.",
        "title": "Deal",
        "title_template": "{name}",
        "stat_cards": [
            {"label": "Amount", "template": "{amount} {currency}", "key": "amount"},
            {"label": "Stage", "key": "stage_name", "type": "pill"},
            {"label": "Status", "key": "status", "type": "pill", "semantic": True},
        ],
        "fields": [
            {"label": "Pipeline", "key": "pipeline_id"},
            {"label": "Owner", "key": "owner_id"},
            {"label": "Contact", "key": "contact_id", "hide_when_empty": True},
            {"label": "Company", "key": "company_id", "hide_when_empty": True},
            {"label": "Close date", "key": "close_date", "hide_when_empty": True},
            {"label": "Created", "key": "created_at"},
            {"label": "Updated", "key": "updated_at"},
        ],
    }

    # Sibling list views for "list-to-list" drill-ins (not detail views;
    # they reuse the table renderer with a different data_path / row_action).
    _contacts_in_list_view = {
        # Pushed when a card in lists/list is clicked. Calls
        # g8_search_contacts(list_id=row.id) and renders the contacts
        # table inside the same widget bundle. Reuses the same column
        # layout as ui://contacts/list for visual consistency.
        "type": "table",
        "data_path": "contacts",
        "loading_text": "Loading contacts in list...",
        "empty_text": "This list is empty.",
        "row_key": "id",
        "title": "Contacts",
        "title_template": "Contacts - {list_title}",
        "context_match_fields": ["list_id"],
        "columns": [
            {
                "key": "name",
                "label": "Name",
                "primary": True,
                "template": "{first_name} {last_name}",
            },
            {"key": "job_title", "label": "Title", "truncate": True},
            {"key": "company_name", "label": "Company", "truncate": True},
            {"key": "work_email", "label": "Email", "truncate": True},
        ],
    }

    _company_contacts_view = {
        # Pushed when a row in companies/list is clicked. Calls
        # g8_get_company_contacts(company_id=row.id) - free, CRM-side, no
        # credits. Reuses the contacts table layout.
        "type": "table",
        "data_path": "contacts",
        "loading_text": "Loading contacts at company...",
        "empty_text": "No contacts at this company yet.",
        "row_key": "id",
        "title": "Contacts",
        "title_template": "Contacts at {company_name}",
        "context_match_fields": ["company_id"],
        "columns": [
            {
                "key": "name",
                "label": "Name",
                "primary": True,
                "template": "{first_name} {last_name}",
            },
            {"key": "job_title", "label": "Title", "truncate": True},
            {"key": "seniority_level", "label": "Seniority", "type": "pill"},
            {"key": "work_email", "label": "Email", "truncate": True},
        ],
    }

    _sync_runs_view = {
        # Pushed when a row in audience-syncs/list is clicked. Calls
        # g8_get_audience_sync_runs(sync_id=row.id) and renders run history.
        "type": "table",
        "data_path": "runs",
        "loading_text": "Loading sync runs...",
        "empty_text": "No runs for this sync yet.",
        "row_key": "id",
        "title": "Sync runs",
        "title_template": "Runs - {sync_label}",
        "context_match_fields": ["sync_id"],
        "columns": [
            {"key": "started_at", "label": "Started", "primary": True},
            {"key": "status", "label": "Status", "type": "pill", "semantic": True},
            {"key": "member_count", "label": "Members"},
            {"key": "added_count", "label": "Added"},
            {"key": "removed_count", "label": "Removed"},
            {"key": "error_message", "label": "Error", "truncate": True},
        ],
    }

    register_ui_app_resource(
        server,
        uri="ui://campaigns/ad-images",
        bundle_name="shell",
        description=(
            "Interactive grid of ad creatives for one campaign, with per-card "
            "hide action. Driven by g8_gtm_get_ad_images + g8_gtm_hide_ad_image."
        ),
        csp={
            # The MCP Apps SDK is inlined into the widget bundle (see
            # ui_bundles/_vendor/README.md), so we declare ONLY the image
            # origins here. No CDN script origins are needed.
            #
            # NOTE: claude.ai is observed (2026-04-24) to ignore this list
            # entirely in the widget iframe CSP. We still emit it because
            # other MCP Apps hosts (Claude Desktop, Goose, VS Code Copilot)
            # honor it, and it correctly documents the asset origins the
            # widget actually uses.
            "resourceDomains": [
                # graph8 ad image hosts  -  verify + tighten with explicit
                # bucket subdomains before shipping broadly.
                "*.s3.amazonaws.com",
                "*.cloudfront.net",
                "*.r2.cloudflarestorage.com",
            ],
        },
        # claude.ai enforces a sandbox-origin format on ui.domain. Compute
        # dynamically so QA / dev / prod each emit the value that matches
        # their own MCP URL. See claude_mcp_domain() for details.
        domain=claude_mcp_domain(),
        view_config={
            "page_title": "graph8 ad creatives",
            "header_title": "Ad creatives",
            "app_name": "graph8 ad creatives",
            "app_version": "0.2.0",
            "root_view_id": "list",
            "views": {
                "list": _ad_images_view,
            },
        },
    )
    register_ui_app_resource(
        server,
        uri="ui://campaigns/dashboard",
        bundle_name="shell",
        description=(
            "Interactive dashboard of campaigns grouped by status. "
            "Clicking a card drills into the ad images grid for that "
            "campaign in-place. Driven by g8_gtm_list_campaigns; click "
            "fires g8_gtm_get_ad_images which populates a detail view "
            "in the same widget's nav stack."
        ),
        # Dashboard has no external assets - SDK is inlined, the campaign
        # list view loads no images. The drill-in detail view does load
        # ad images, so we declare the same image origins as the
        # standalone ad-images widget.
        csp={
            "resourceDomains": [
                "*.s3.amazonaws.com",
                "*.cloudfront.net",
                "*.r2.cloudflarestorage.com",
            ],
        },
        domain=claude_mcp_domain(),
        view_config={
            "page_title": "graph8 campaigns",
            "header_title": "Campaigns",
            "app_name": "graph8 campaigns",
            "app_version": "0.3.0",
            "root_view_id": "campaigns",
            "views": {
                "campaigns": {
                    "type": "card_grid",
                    "data_path": "campaigns",
                    "loading_text": "Waiting for campaign data...",
                    "empty_text": "No campaigns yet.",
                    "row_key": "id",
                    "title": "Campaigns",
                    "group_by": {
                        "field": "status",
                        "order": [
                            "active", "paused", "draft",
                            "complete", "archived", "other",
                        ],
                        "fallback": "other",
                    },
                    "card": {
                        "primary": "name",
                        "primary_fallback": "Untitled campaign",
                        "body": "goal",
                        "pills": [
                            {"field": "status", "semantic": True},
                            {"field": "category"},
                            {"field": "target_persona"},
                        ],
                    },
                    "row_action": {
                        "view": "ad-images",
                        "tool": "g8_gtm_get_ad_images",
                        "args_from_row": {"campaign_id": "id"},
                        "context_from_row": {
                            "campaign_id": "id",
                            "campaign_name": "name",
                        },
                    },
                },
                "ad-images": _ad_images_view,
            },
        },
    )

    # ------------------------------------------------------------------ #
    # Wave 1 widgets - generic list views, all driven by the shared      #
    # shell.html bundle and a per-widget view_config. Each one is        #
    # registered as a `ui://...` resource here, then linked from its     #
    # tool registration via `meta=ui_tool_meta(uri)`.                    #
    #                                                                    #
    # No drill-in actions yet: these are first-pass list surfaces. The   #
    # shell already supports row_action/actions, so future iterations    #
    # can enable contact->company->contact navigation, list->contacts    #
    # drill-in, etc., by extending each widget's view_config.            #
    # ------------------------------------------------------------------ #

    # ---- contacts (g8_find_contacts + g8_search_contacts) -------------
    register_ui_app_resource(
        server,
        uri="ui://contacts/list",
        bundle_name="shell",
        description=(
            "Sortable table of contacts (CRM search or open-data prospecting). "
            "Driven by g8_find_contacts and g8_search_contacts. Row click "
            "drills into the contact detail panel via g8_get_contact_detail."
        ),
        # No external image origins; SDK is inlined.
        domain=claude_mcp_domain(),
        view_config={
            "page_title": "graph8 contacts",
            "header_title": "Contacts",
            "app_name": "graph8 contacts",
            "app_version": "0.2.0",
            "root_view_id": "list",
            "views": {
                "list": {
                    "type": "table",
                    "data_path": "contacts",
                    "loading_text": "Loading contacts...",
                    "empty_text": "No contacts found. Try broader filters.",
                    "row_key": "id",
                    "title": "Contacts",
                    "columns": [
                        # `template` lets us combine first_name + last_name
                        # without a backend join. Falls back to "" if both
                        # are empty (rendered as blank cell).
                        {
                            "key": "name",
                            "label": "Name",
                            "primary": True,
                            "template": "{first_name} {last_name}",
                        },
                        {"key": "job_title", "label": "Title", "truncate": True},
                        {
                            "key": "seniority_level",
                            "label": "Seniority",
                            "type": "pill",
                        },
                        {"key": "company_name", "label": "Company", "truncate": True},
                        {"key": "company_industry", "label": "Industry", "truncate": True},
                        {"key": "work_email", "label": "Email", "truncate": True},
                    ],
                    # Row click pushes the detail view, calls
                    # g8_get_contact_detail (free, CRM-internal). The
                    # detail view body is shared with the standalone
                    # ui://contacts/detail registration below.
                    "row_action": {
                        "view": "detail",
                        "tool": "g8_get_contact_detail",
                        "args_from_row": {"contact_id": "id"},
                        "context_from_row": {
                            "contact_id": "id",
                            "first_name": "first_name",
                            "last_name": "last_name",
                        },
                    },
                },
                "detail": _contact_detail_view,
            },
        },
    )

    # ---- companies (g8_find_companies + g8_search_companies) ----------
    register_ui_app_resource(
        server,
        uri="ui://companies/list",
        bundle_name="shell",
        description=(
            "Sortable table of companies (CRM search or open-data prospecting). "
            "Driven by g8_find_companies and g8_search_companies. Row click "
            "drills into the contacts at that company via g8_get_company_contacts. "
            "Companies-detail (g8_lookup_company) is a separate widget because "
            "it costs 1 credit and is gated by a confirmation modal."
        ),
        domain=claude_mcp_domain(),
        view_config={
            "page_title": "graph8 companies",
            "header_title": "Companies",
            "app_name": "graph8 companies",
            "app_version": "0.2.0",
            "root_view_id": "list",
            "views": {
                "list": {
                    "type": "table",
                    "data_path": "companies",
                    "loading_text": "Loading companies...",
                    "empty_text": "No companies found. Try broader filters.",
                    "row_key": "id",
                    "title": "Companies",
                    "columns": [
                        {"key": "name", "label": "Name", "primary": True, "truncate": True},
                        {"key": "domain", "label": "Domain", "truncate": True},
                        {"key": "industry", "label": "Industry", "truncate": True},
                        {"key": "employee_count", "label": "Employees"},
                        {"key": "country", "label": "Country"},
                    ],
                    # Row click drills into contacts at that company.
                    # We deliberately do NOT call g8_lookup_company here -
                    # that costs 1 credit per click and would be a silent
                    # credit drain. g8_get_company_contacts is free.
                    "row_action": {
                        "view": "company-contacts",
                        "tool": "g8_get_company_contacts",
                        "args_from_row": {"company_id": "id"},
                        "context_from_row": {
                            "company_id": "id",
                            "company_name": "name",
                        },
                    },
                },
                "company-contacts": _company_contacts_view,
            },
        },
    )

    # ---- inbox (g8_list_inbox) ----------------------------------------
    register_ui_app_resource(
        server,
        uri="ui://inbox/list",
        bundle_name="shell",
        description=(
            "Multi-channel inbox thread list (email/SMS/LinkedIn). "
            "Driven by g8_list_inbox. Row click drills into the thread "
            "detail (subject + message timeline) via g8_get_reply."
        ),
        domain=claude_mcp_domain(),
        view_config={
            "page_title": "graph8 inbox",
            "header_title": "Inbox",
            "app_name": "graph8 inbox",
            "app_version": "0.2.0",
            "root_view_id": "list",
            "views": {
                "list": {
                    "type": "table",
                    "data_path": "threads",
                    "loading_text": "Loading inbox...",
                    "empty_text": "Inbox is empty.",
                    "row_key": "id",
                    "title": "Inbox",
                    "columns": [
                        {"key": "subject", "label": "Subject", "primary": True, "truncate": True},
                        # Backend serializes contact as {id, email, name, title}
                        # (see ai_inbox.services.channels - contacts_by_email
                        # construction). Older template used first_name/last_name
                        # which the backend never returns; falls back to email
                        # when name is null. Both keys come from the same dict
                        # so interpolation will pick whichever is non-empty.
                        {
                            "key": "contact_name",
                            "label": "Contact",
                            "template": "{contact.name}",
                            "truncate": True,
                        },
                        {"key": "channel", "label": "Channel", "type": "pill"},
                        {"key": "status", "label": "Status", "type": "pill", "semantic": True},
                        {"key": "preview", "label": "Preview", "truncate": True},
                        {"key": "updated_at", "label": "Updated"},
                    ],
                    # Row click pushes thread detail view. g8_get_reply
                    # takes both reply_id (the thread id) and channel because
                    # the inbox is multi-channel.
                    "row_action": {
                        "view": "thread",
                        "tool": "g8_get_reply",
                        "args_from_row": {
                            "reply_id": "id",
                            "channel": "channel",
                        },
                        "context_from_row": {
                            "reply_id": "id",
                            "subject": "subject",
                        },
                    },
                },
                "thread": _inbox_thread_view,
            },
        },
    )

    # ---- lists (g8_get_lists) -----------------------------------------
    register_ui_app_resource(
        server,
        uri="ui://lists/list",
        bundle_name="shell",
        description=(
            "Card grid of contact and company lists in your CRM. "
            "Driven by g8_get_lists. Card click drills into the contacts "
            "in that list via g8_search_contacts(list_id=...)."
        ),
        domain=claude_mcp_domain(),
        view_config={
            "page_title": "graph8 lists",
            "header_title": "Lists",
            "app_name": "graph8 lists",
            "app_version": "0.2.0",
            "root_view_id": "list",
            "views": {
                "list": {
                    "type": "card_grid",
                    "data_path": "lists",
                    "loading_text": "Loading lists...",
                    "empty_text": "No lists yet. Create one with g8_create_list.",
                    "row_key": "id",
                    "title": "Lists",
                    # Group by list type so contact lists and company lists
                    # render in separate sections.
                    "group_by": {
                        "field": "type",
                        "order": ["contacts", "companies", "other"],
                        "fallback": "other",
                    },
                    "card": {
                        "primary": "title",
                        "primary_fallback": "Untitled list",
                        "pills": [
                            {"field": "type"},
                        ],
                        # Body shows record count. Backend `Audience.total` is
                        # the single canonical count regardless of list type;
                        # the type pill above already disambiguates contacts
                        # vs companies. The interpolator returns "" when total
                        # is null, so empty lists render with no body line.
                        "body_template": "{total} records",
                    },
                    # Card click drills into contacts at that list.
                    # We reuse g8_search_contacts (already shipped) with the
                    # list_id filter - free, CRM-internal. Note this only
                    # works for contact lists; clicking a company list will
                    # also call this and likely return empty results until
                    # a g8_search_companies(list_id=...) variant is wired.
                    "row_action": {
                        "view": "contacts",
                        "tool": "g8_search_contacts",
                        "args_from_row": {"list_id": "id"},
                        "context_from_row": {
                            "list_id": "id",
                            "list_title": "title",
                        },
                    },
                },
                "contacts": _contacts_in_list_view,
            },
        },
    )

    # ---- sequences (g8_list_sequences) --------------------------------
    register_ui_app_resource(
        server,
        uri="ui://sequences/list",
        bundle_name="shell",
        description=(
            "Sortable table of outbound sequences. Driven by g8_list_sequences. "
            "Row click drills into the sequence detail (steps timeline, channels) "
            "via g8_get_sequence_preview."
        ),
        domain=claude_mcp_domain(),
        view_config={
            "page_title": "graph8 sequences",
            "header_title": "Sequences",
            "app_name": "graph8 sequences",
            "app_version": "0.2.0",
            "root_view_id": "list",
            "views": {
                "list": {
                    "type": "table",
                    "data_path": "sequences",
                    "loading_text": "Loading sequences...",
                    "empty_text": "No sequences yet.",
                    "row_key": "id",
                    "title": "Sequences",
                    "columns": [
                        {"key": "name", "label": "Name", "primary": True, "truncate": True},
                        {"key": "status", "label": "Status", "type": "pill", "semantic": True},
                        # step_count / contact_count come from the backend's
                        # plural fields (`step_counts`, `contact_counts`) via
                        # SequenceItem's AliasChoices in models.py.
                        {"key": "step_count", "label": "Steps"},
                        {"key": "contact_count", "label": "Contacts"},
                        # The backend list endpoint does not populate
                        # `description` - that field only appears on the
                        # detail endpoint - so we surface `sequence_kind` and
                        # `created_at` instead, which are populated.
                        {"key": "sequence_kind", "label": "Kind", "type": "pill"},
                        {"key": "created_at", "label": "Created", "truncate": True},
                    ],
                    # Row click pushes the detail view, calls
                    # g8_get_sequence_preview (free, CRM-internal). The detail
                    # view body is shared with the standalone
                    # ui://sequences/detail registration below.
                    "row_action": {
                        "view": "detail",
                        "tool": "g8_get_sequence_preview",
                        "args_from_row": {"sequence_id": "id"},
                        "context_from_row": {
                            "sequence_id": "id",
                            "name": "name",
                        },
                    },
                },
                "detail": _sequence_detail_view,
            },
        },
    )

    # ------------------------------------------------------------------ #
    # Standalone detail widgets.                                         #
    #                                                                    #
    # These re-use the same per-entity view configs (`_contact_detail_view`, #
    # `_sequence_detail_view`, etc.) defined at the top of this function. #
    # When the model invokes the corresponding detail tool directly      #
    # (instead of clicking a row in the list widget), the host loads     #
    # this resource and the shell renders the detail view as the root.  #
    # The list widget's sibling-view path remains identical.             #
    # ------------------------------------------------------------------ #

    register_ui_app_resource(
        server,
        uri="ui://contacts/detail",
        bundle_name="shell",
        description=(
            "Detail panel for one contact (free, CRM-internal). Driven by "
            "g8_get_contact_detail. Shares the same view body as the row-click "
            "drill-in from ui://contacts/list."
        ),
        domain=claude_mcp_domain(),
        view_config={
            "page_title": "graph8 contact",
            "header_title": "Contact",
            "app_name": "graph8 contact detail",
            "app_version": "0.1.0",
            "root_view_id": "detail",
            "views": {
                "detail": _contact_detail_view,
            },
        },
    )

    register_ui_app_resource(
        server,
        uri="ui://companies/detail",
        bundle_name="shell",
        description=(
            "Detail panel for one company from open-data lookup (1 credit). "
            "Driven by g8_lookup_company. Standalone widget; the credit "
            "spend happens at tool-invocation time, not at click time, "
            "so no in-widget confirmation is shown here."
        ),
        domain=claude_mcp_domain(),
        view_config={
            "page_title": "graph8 company",
            "header_title": "Company",
            "app_name": "graph8 company detail",
            "app_version": "0.1.0",
            "root_view_id": "detail",
            "views": {
                "detail": _company_detail_view,
            },
        },
    )

    register_ui_app_resource(
        server,
        uri="ui://sequences/detail",
        bundle_name="shell",
        description=(
            "Detail panel for one outbound sequence (steps timeline + channels). "
            "Driven by g8_get_sequence_preview. Shares the same view body as the "
            "row-click drill-in from ui://sequences/list."
        ),
        domain=claude_mcp_domain(),
        view_config={
            "page_title": "graph8 sequence",
            "header_title": "Sequence",
            "app_name": "graph8 sequence detail",
            "app_version": "0.1.0",
            "root_view_id": "detail",
            "views": {
                "detail": _sequence_detail_view,
            },
        },
    )

    register_ui_app_resource(
        server,
        uri="ui://inbox/thread",
        bundle_name="shell",
        description=(
            "Single inbox thread view (subject + message timeline). Driven by "
            "g8_get_reply. Shares the same view body as the row-click drill-in "
            "from ui://inbox/list."
        ),
        domain=claude_mcp_domain(),
        view_config={
            "page_title": "graph8 thread",
            "header_title": "Thread",
            "app_name": "graph8 inbox thread",
            "app_version": "0.1.0",
            "root_view_id": "detail",
            "views": {
                "detail": _inbox_thread_view,
            },
        },
    )

    register_ui_app_resource(
        server,
        uri="ui://deals/detail",
        bundle_name="shell",
        description=(
            "Detail panel for one CRM deal (amount, stage, owner). Driven by "
            "g8_get_deal. Shares the same view body as the row-click drill-in "
            "from ui://deals/list."
        ),
        domain=claude_mcp_domain(),
        view_config={
            "page_title": "graph8 deal",
            "header_title": "Deal",
            "app_name": "graph8 deal detail",
            "app_version": "0.1.0",
            "root_view_id": "detail",
            "views": {
                "detail": _deal_detail_view,
            },
        },
    )

    # ------------------------------------------------------------------ #
    # List widgets for the remaining read tools.                         #
    #                                                                    #
    # Each one drives a single "list/get_*" tool. Drill-ins fire when    #
    # there's a free CRM-internal detail tool on the other end (deals,  #
    # audience-syncs). Tools without a detail counterpart (tasks,       #
    # activities, crm-syncs, personas, icps) render as flat lists - we  #
    # can layer drill-ins later without breaking back-compat because    #
    # row_action is always optional in the view config.                 #
    # ------------------------------------------------------------------ #

    # ---- deals (g8_get_deals + g8_get_deal) ---------------------------
    register_ui_app_resource(
        server,
        uri="ui://deals/list",
        bundle_name="shell",
        description=(
            "Sortable table of CRM deals (revenue pipeline). Driven by "
            "g8_get_deals. Row click drills into the deal detail "
            "via g8_get_deal."
        ),
        domain=claude_mcp_domain(),
        view_config={
            "page_title": "graph8 deals",
            "header_title": "Deals",
            "app_name": "graph8 deals",
            "app_version": "0.1.0",
            "root_view_id": "list",
            "views": {
                "list": {
                    "type": "table",
                    "data_path": "deals",
                    "loading_text": "Loading deals...",
                    "empty_text": "No deals yet.",
                    "row_key": "id",
                    "title": "Deals",
                    "columns": [
                        {"key": "name", "label": "Name", "primary": True, "truncate": True},
                        {"key": "stage_name", "label": "Stage", "type": "pill"},
                        {"key": "status", "label": "Status", "type": "pill", "semantic": True},
                        {
                            "key": "amount",
                            "label": "Amount",
                            "template": "{amount} {currency}",
                        },
                        {"key": "close_date", "label": "Close date"},
                        {"key": "updated_at", "label": "Updated"},
                    ],
                    "row_action": {
                        "view": "detail",
                        "tool": "g8_get_deal",
                        "args_from_row": {"deal_id": "id"},
                        "context_from_row": {
                            "deal_id": "id",
                            "name": "name",
                        },
                    },
                },
                "detail": _deal_detail_view,
            },
        },
    )

    # ---- tasks (g8_get_tasks) -----------------------------------------
    register_ui_app_resource(
        server,
        uri="ui://tasks/list",
        bundle_name="shell",
        description=(
            "Sortable table of CRM tasks (todo/done). Driven by g8_get_tasks. "
            "No drill-in target yet - row click is a no-op until a "
            "g8_get_task detail tool is added."
        ),
        domain=claude_mcp_domain(),
        view_config={
            "page_title": "graph8 tasks",
            "header_title": "Tasks",
            "app_name": "graph8 tasks",
            "app_version": "0.1.0",
            "root_view_id": "list",
            "views": {
                "list": {
                    "type": "table",
                    "data_path": "tasks",
                    "loading_text": "Loading tasks...",
                    "empty_text": "No tasks.",
                    "row_key": "id",
                    "title": "Tasks",
                    "columns": [
                        {"key": "title", "label": "Title", "primary": True, "truncate": True},
                        {"key": "status", "label": "Status", "type": "pill", "semantic": True},
                        {"key": "priority", "label": "Priority"},
                        {"key": "due_date", "label": "Due"},
                        {"key": "assignee_id", "label": "Assignee", "truncate": True},
                        {"key": "updated_at", "label": "Updated"},
                    ],
                },
            },
        },
    )

    # ---- activities (g8_get_activities) -------------------------------
    register_ui_app_resource(
        server,
        uri="ui://activities/list",
        bundle_name="shell",
        description=(
            "Sortable table of CRM activity events (calls, emails, meetings). "
            "Driven by g8_get_activities."
        ),
        domain=claude_mcp_domain(),
        view_config={
            "page_title": "graph8 activities",
            "header_title": "Activities",
            "app_name": "graph8 activities",
            "app_version": "0.1.0",
            "root_view_id": "list",
            "views": {
                "list": {
                    "type": "table",
                    "data_path": "activities",
                    "loading_text": "Loading activities...",
                    "empty_text": "No activities recorded.",
                    "row_key": "id",
                    "title": "Activities",
                    "columns": [
                        {"key": "occurred_at", "label": "When", "primary": True},
                        {"key": "activity_type", "label": "Type", "type": "pill"},
                        {"key": "summary", "label": "Summary", "truncate": True},
                        {"key": "user_id", "label": "User", "truncate": True},
                        {"key": "contact_id", "label": "Contact"},
                        {"key": "deal_id", "label": "Deal", "truncate": True},
                    ],
                },
            },
        },
    )

    # ---- audience syncs (g8_list_audience_syncs + drill-in to runs) ---
    register_ui_app_resource(
        server,
        uri="ui://audience-syncs/list",
        bundle_name="shell",
        description=(
            "Sortable table of audience sync configurations (LinkedIn, Meta, "
            "Google ads). Driven by g8_list_audience_syncs. Row click drills "
            "into the run history via g8_get_audience_sync_runs."
        ),
        domain=claude_mcp_domain(),
        view_config={
            "page_title": "graph8 audience syncs",
            "header_title": "Audience syncs",
            "app_name": "graph8 audience syncs",
            "app_version": "0.1.0",
            "root_view_id": "list",
            "views": {
                "list": {
                    "type": "table",
                    "data_path": "syncs",
                    "loading_text": "Loading audience syncs...",
                    "empty_text": "No audience syncs configured.",
                    "row_key": "id",
                    "title": "Audience syncs",
                    "columns": [
                        {
                            "key": "platform_audience_name",
                            "label": "Audience",
                            "primary": True,
                            "truncate": True,
                        },
                        {"key": "platform", "label": "Platform", "type": "pill"},
                        {"key": "mode", "label": "Mode"},
                        {"key": "status", "label": "Status", "type": "pill", "semantic": True},
                        {"key": "refresh_cadence_hours", "label": "Cadence (h)"},
                        {"key": "last_sync_at", "label": "Last sync"},
                    ],
                    # Row click drills into run history. Free CRM-internal
                    # tool, no credits.
                    "row_action": {
                        "view": "runs",
                        "tool": "g8_get_audience_sync_runs",
                        "args_from_row": {"config_id": "id"},
                        "context_from_row": {
                            "sync_id": "id",
                            "sync_label": "platform_audience_name",
                        },
                    },
                },
                "runs": _sync_runs_view,
            },
        },
    )

    # ---- crm syncs (g8_list_crm_syncs) --------------------------------
    register_ui_app_resource(
        server,
        uri="ui://crm-syncs/list",
        bundle_name="shell",
        description=(
            "Card grid of connected CRM integrations (HubSpot, Salesforce, "
            "Pipedrive, etc.). Driven by g8_list_crm_syncs."
        ),
        domain=claude_mcp_domain(),
        view_config={
            "page_title": "graph8 CRM integrations",
            "header_title": "CRM integrations",
            "app_name": "graph8 crm syncs",
            "app_version": "0.1.0",
            "root_view_id": "list",
            "views": {
                "list": {
                    "type": "card_grid",
                    "data_path": "integrations",
                    "loading_text": "Loading integrations...",
                    "empty_text": "No CRM integrations connected.",
                    "row_key": "provider",
                    "title": "CRM integrations",
                    "card": {
                        "primary": "provider",
                        "primary_fallback": "Unknown provider",
                        "body": "account_name",
                        "pills": [
                            {"field": "status", "semantic": True},
                        ],
                    },
                },
            },
        },
    )

    # ---- personas (g8_gtm_get_personas) -------------------------------
    register_ui_app_resource(
        server,
        uri="ui://personas/list",
        bundle_name="shell",
        description=(
            "Card grid of buyer personas (job role + pain points). Driven by "
            "g8_gtm_get_personas."
        ),
        domain=claude_mcp_domain(),
        view_config={
            "page_title": "graph8 personas",
            "header_title": "Personas",
            "app_name": "graph8 personas",
            "app_version": "0.1.0",
            "root_view_id": "list",
            "views": {
                "list": {
                    "type": "card_grid",
                    "data_path": "personas",
                    "loading_text": "Loading personas...",
                    "empty_text": "No personas defined.",
                    "row_key": "id",
                    "title": "Personas",
                    "card": {
                        "primary": "name",
                        "primary_fallback": "Untitled persona",
                        "body": "role",
                        "pills": [
                            {"field": "status", "semantic": True},
                        ],
                    },
                },
            },
        },
    )

    # ---- ICPs (g8_gtm_get_icps) ---------------------------------------
    register_ui_app_resource(
        server,
        uri="ui://icps/list",
        bundle_name="shell",
        description=(
            "Card grid of Ideal Customer Profiles. Driven by g8_gtm_get_icps."
        ),
        domain=claude_mcp_domain(),
        view_config={
            "page_title": "graph8 ICPs",
            "header_title": "ICPs",
            "app_name": "graph8 icps",
            "app_version": "0.1.0",
            "root_view_id": "list",
            "views": {
                "list": {
                    "type": "card_grid",
                    "data_path": "icps",
                    "loading_text": "Loading ICPs...",
                    "empty_text": "No ICPs defined.",
                    "row_key": "id",
                    "title": "ICPs",
                    "card": {
                        "primary": "name",
                        "primary_fallback": "Untitled ICP",
                        "body": "industry",
                        "pills": [
                            {"field": "status", "semantic": True},
                            {"field": "company_size"},
                        ],
                    },
                },
            },
        },
    )

    # ------------------------------------------------------------------ #
    # Wave 3 confirmation widgets - credit/send guardrails.              #
    #                                                                    #
    # Each widget is a `confirmation`-type view that renders the dry-run #
    # preview returned by its source tool when called with `dry_run=True`#
    # (see ConfirmationPreview in models.py). On Confirm the widget      #
    # re-fires the same tool with `dry_run=False` and renders the ack    #
    # (success / error / cancelled). All views share a single config     #
    # shape: `data_path: "__self__"`, type: "confirmation".              #
    # ------------------------------------------------------------------ #

    _confirmation_view_base = {
        "type": "confirmation",
        "data_path": "__self__",
        "loading_text": "Preparing preview...",
    }

    def _confirmation_resource(uri: str, *, page_title: str, header_title: str, app_name: str, description: str) -> None:
        """Register a confirmation-style ui:// resource backed by shell.html."""
        register_ui_app_resource(
            server,
            uri=uri,
            bundle_name="shell",
            description=description,
            domain=claude_mcp_domain(),
            view_config={
                "page_title": page_title,
                "header_title": header_title,
                "app_name": app_name,
                "app_version": "0.1.0",
                "root_view_id": "confirm",
                "views": {
                    "confirm": dict(_confirmation_view_base),
                },
            },
        )

    _confirmation_resource(
        "ui://confirmations/build-contact-list",
        page_title="graph8 - confirm save list",
        header_title="Confirm: save contacts to list",
        app_name="graph8 confirm save list",
        description=(
            "Confirmation widget for g8_build_contact_list. Shows the list "
            "name, filter count, and credit footprint before the save. "
            "Driven by g8_build_contact_list(dry_run=True)."
        ),
    )
    _confirmation_resource(
        "ui://confirmations/enrich-contacts",
        page_title="graph8 - confirm enrichment",
        header_title="Confirm: enrich contacts",
        app_name="graph8 confirm enrich",
        description=(
            "Confirmation widget for g8_enrich_contacts. Shows the contact "
            "count and target list before charging credits. Driven by "
            "g8_enrich_contacts(dry_run=True)."
        ),
    )
    _confirmation_resource(
        "ui://confirmations/add-to-sequence",
        page_title="graph8 - confirm sequence enrollment",
        header_title="Confirm: enroll in sequence",
        app_name="graph8 confirm enroll",
        description=(
            "Confirmation widget for g8_add_to_sequence. Surfaces sequence "
            "id, contact count, and list id before sending real outreach. "
            "Driven by g8_add_to_sequence(dry_run=True)."
        ),
    )
    _confirmation_resource(
        "ui://confirmations/launch-campaign",
        page_title="graph8 - confirm launch campaign",
        header_title="Confirm: launch campaign",
        app_name="graph8 confirm launch",
        description=(
            "Confirmation widget for g8_gtm_launch_campaign. Surfaces the "
            "campaign id and warns that real outreach starts on confirm. "
            "Driven by g8_gtm_launch_campaign(dry_run=True)."
        ),
    )
    _confirmation_resource(
        "ui://confirmations/create-dialer-session",
        page_title="graph8 - confirm dialer session",
        header_title="Confirm: create dialer session",
        app_name="graph8 confirm dialer create",
        description=(
            "Confirmation widget for g8_voice_create_dialer_session. Shows "
            "session name, from-phone, list, and agent before creating the "
            "session in PAUSED state. Driven by "
            "g8_voice_create_dialer_session(dry_run=True)."
        ),
    )
    _confirmation_resource(
        "ui://confirmations/stop-dialer-session",
        page_title="graph8 - confirm stop session",
        header_title="Confirm: stop dialer session",
        app_name="graph8 confirm dialer stop",
        description=(
            "Confirmation widget for g8_voice_stop_session. Warns that "
            "stopping is one-way before flipping the session to COMPLETED. "
            "Driven by g8_voice_stop_session(dry_run=True)."
        ),
    )

    # ------------------------------------------------------------------ #
    # Voice / dialer surface widgets.                                    #
    #                                                                    #
    # Three read-only views drive the dialer chat experience:            #
    #   - ui://dialer/sessions  - card grid of dialer sessions w/ pause, #
    #     resume, and stop actions baked into each card                  #
    #   - ui://dialer/stats     - detail view with the aggregated stats  #
    #     report (filters/metrics/summary)                               #
    #   - ui://voice/agents     - card grid of voice agent personas      #
    # ------------------------------------------------------------------ #

    register_ui_app_resource(
        server,
        uri="ui://dialer/sessions",
        bundle_name="shell",
        description=(
            "Card grid of parallel dialer sessions for the org. Each card "
            "carries Pause / Resume / Stop action buttons that fire the "
            "matching voice tool in-place. Driven by "
            "g8_voice_list_dialer_sessions; pause/resume/stop tools refresh "
            "the same widget."
        ),
        domain=claude_mcp_domain(),
        view_config={
            "page_title": "graph8 dialer sessions",
            "header_title": "Dialer sessions",
            "app_name": "graph8 dialer sessions",
            "app_version": "0.1.0",
            "root_view_id": "list",
            "views": {
                "list": {
                    "type": "card_grid",
                    "data_path": "sessions",
                    "loading_text": "Loading dialer sessions...",
                    "empty_text": "No dialer sessions yet.",
                    "row_key": "session_id",
                    "title": "Dialer sessions",
                    "group_by": {
                        "field": "status",
                        "order": ["ACTIVE", "PAUSED", "COMPLETED", "FAILED", "other"],
                        "fallback": "other",
                    },
                    "card": {
                        "primary": "name",
                        "primary_fallback": "Untitled session",
                        "body": "user_email",
                        "pills": [
                            {"field": "status", "semantic": True},
                            {"field": "from_phone"},
                            {"field": "total_calls"},
                        ],
                    },
                    "actions": [
                        {
                            "id": "pause",
                            "label": "Pause",
                            "title": "Pause this dialer session (reversible)",
                            "tool": "g8_voice_pause_session",
                            "args_from_row": {"session_id": "session_id"},
                            "busy_text": "Pausing...",
                            "optimistic_class": "is-busy",
                            "on_success": {
                                "mutation": "update_card",
                                "match_field": "session_id",
                                "result_field": "session_id",
                                "updates": {"status": "status"},
                            },
                        },
                        {
                            "id": "resume",
                            "label": "Resume",
                            "title": "Resume this dialer session (places real calls)",
                            "tool": "g8_voice_resume_session",
                            "args_from_row": {"session_id": "session_id"},
                            "static_args": {"max_contacts": 4},
                            "confirm": {
                                "title": "Resume \"{name}\"?",
                                "body": "Voice will dial the next batch of contacts (up to 4).",
                                "confirm_label": "Resume dialing",
                                "cancel_label": "Keep paused",
                            },
                            "busy_text": "Resuming...",
                            "optimistic_class": "is-busy",
                            "on_success": {
                                "mutation": "update_card",
                                "match_field": "session_id",
                                "result_field": "session_id",
                                "updates": {"status": "status"},
                            },
                        },
                        {
                            "id": "stop",
                            "label": "Stop",
                            "title": "Stop this dialer session permanently",
                            "tool": "g8_voice_stop_session",
                            "args_from_row": {"session_id": "session_id"},
                            "confirm": {
                                "title": "Stop \"{name}\"?",
                                "body": "This is one-way. The session will be marked COMPLETED.",
                                "confirm_label": "Stop session",
                                "cancel_label": "Cancel",
                            },
                            "busy_text": "Stopping...",
                            "optimistic_class": "is-busy",
                            "on_success": {
                                "mutation": "update_card",
                                "match_field": "session_id",
                                "result_field": "session_id",
                                "updates": {"status": "status"},
                            },
                        },
                    ],
                },
            },
        },
    )

    register_ui_app_resource(
        server,
        uri="ui://dialer/stats",
        bundle_name="shell",
        description=(
            "Aggregated dialer analytics for the org. Shows filters echo, "
            "per-period metrics rows, and an overall summary. Driven by "
            "g8_voice_get_dialer_stats."
        ),
        domain=claude_mcp_domain(),
        view_config={
            "page_title": "graph8 dialer stats",
            "header_title": "Dialer stats",
            "app_name": "graph8 dialer stats",
            "app_version": "0.1.0",
            "root_view_id": "detail",
            "views": {
                "detail": {
                    "type": "detail",
                    "data_path": "__self__",
                    "loading_text": "Loading dialer stats...",
                    "empty_text": "No dialer activity in this window.",
                    "title": "Dialer stats",
                    "stat_cards": [
                        {"label": "Total dials", "key": "summary.total_dials"},
                        {"label": "Connect rate", "key": "summary.connection_rate"},
                        {"label": "Talk time", "key": "summary.talk_time"},
                    ],
                    "fields": [
                        {"label": "Aggregation", "key": "filters.aggregation"},
                        {"label": "Date from", "key": "filters.date_from", "hide_when_empty": True},
                        {"label": "Date to", "key": "filters.date_to", "hide_when_empty": True},
                        {"label": "Session ID", "key": "filters.session_id", "hide_when_empty": True},
                        {"label": "User email", "key": "filters.user_email", "hide_when_empty": True},
                    ],
                    "sections": [
                        {
                            "id": "metrics",
                            "label": "Metrics",
                            "data_path": "metrics",
                            "item_template": "{period}: {total_dials} dials, {connection_rate} connect rate, {success_rate} success",
                            "empty_text": "No metric rows.",
                            "hide_when_empty": False,
                        },
                    ],
                },
            },
        },
    )

    register_ui_app_resource(
        server,
        uri="ui://voice/agents",
        bundle_name="shell",
        description=(
            "Card grid of voice agent personas available for dialer "
            "sessions. Driven by g8_voice_list_agents."
        ),
        domain=claude_mcp_domain(),
        view_config={
            "page_title": "graph8 voice agents",
            "header_title": "Voice agents",
            "app_name": "graph8 voice agents",
            "app_version": "0.1.0",
            "root_view_id": "list",
            "views": {
                "list": {
                    "type": "card_grid",
                    "data_path": "agents",
                    "loading_text": "Loading voice agents...",
                    "empty_text": "No voice agents available.",
                    "row_key": "agent_id",
                    "title": "Voice agents",
                    "card": {
                        "primary": "agent_name",
                        "primary_fallback": "Untitled agent",
                        "body": "description",
                        "pills": [
                            {"field": "role"},
                            {"field": "agent_status", "semantic": True},
                            {"field": "entity_type"},
                        ],
                    },
                },
            },
        },
    )

    def _session_suffix() -> str:
        """Derive a stable per-caller cache suffix from the API key.

        Ensures two orgs can't share cached HTML for the same entity id -
        per-entity surfaces (ad-images, sequence-preview) mix this into the
        suffix alongside the id; per-org surfaces (personas, kb) use it
        directly.
        """
        try:
            key = client._api_key  # protected: same pattern as session_tools
        except Exception:
            key = ""
        return cache_key_for_api_key(key)

    @server.resource("g8://repos")
    async def list_repos() -> str:
        """List of connected repositories with names, URLs, and status."""
        result = await client.get("/repos")
        return format_result(result)

    @server.resource("g8://repos/{repo_id}/scan")
    async def get_scan(repo_id: str) -> str:
        """Latest scan results - tech stack, API routes, and GTM readiness."""
        result = await client.get(f"/repos/{repo_id}/scan")
        return format_result(result)

    @server.resource("g8://repos/{repo_id}/kb")
    async def list_kb_docs(repo_id: str) -> str:
        """Knowledge base document list - 45 doc titles and categories."""
        result = await client.get(f"/repos/{repo_id}/kb")
        return format_result(result)

    @server.resource("g8://repos/{repo_id}/kb/{doc_id}")
    async def get_kb_doc(repo_id: str, doc_id: str) -> str:
        """Individual KB document - full strategic content."""
        result = await client.get(f"/repos/{repo_id}/kb/{doc_id}")
        return format_result(result)

    @server.resource("g8://repos/{repo_id}/campaigns")
    async def list_campaigns(repo_id: str) -> str:
        """Campaign list with names, categories, goals, and readiness status."""
        result = await client.get(f"/repos/{repo_id}/campaigns")
        return format_result(result)

    @server.resource("g8://repos/{repo_id}/campaigns/{campaign_id}/brief")
    async def get_campaign_brief(repo_id: str, campaign_id: str) -> str:
        """Campaign brief - strategy, audience, goals, and channel plan."""
        result = await client.get(f"/repos/{repo_id}/campaigns/{campaign_id}")
        return format_result(result)

    @server.resource("g8://contacts")
    async def list_contacts() -> str:
        """Recent contacts summary - names, emails, companies, and titles."""
        result = await client.get("/contacts", {"limit": 50})
        return format_result(result)

    @server.resource("g8://companies")
    async def list_companies() -> str:
        """Companies summary - names, domains, industries, and employee counts."""
        result = await client.get("/companies", {"limit": 50})
        return format_result(result)

    @server.resource("g8://intent/keywords")
    async def list_intent_keywords() -> str:
        """Saved compete-tracking keyword inventory for the current org.

        Each row carries `total_resolved_contacts` and
        `total_resolved_companies` so an agent can rank by delivered compete
        intelligence at a glance. Discovery hook for the competitor-intent
        workflow - clients that crawl resources/list will land here before
        needing g8_tool_search to find the intent tools.
        """
        result = await client.post("/intent/keywords/list", {"page": 1, "limit": 100})
        return format_result(result)

    # ------------------------------------------------------------------ #
    # MCP application surfaces (Upgrade 4 - inline HTML resources).      #
    # ------------------------------------------------------------------ #

    async def _fetch_campaign_ad_images(campaign_id: str) -> tuple[str | None, list[dict]]:
        """Call the developer API and pull campaign ad images + campaign name.

        Returns `(campaign_name, images)` even on non-401/404 failure so the
        renderer can always produce *some* output. 404 is re-raised as an
        empty result; other errors log and return empty images.
        """
        try:
            raw = await client.get(f"/campaigns/{campaign_id}/ad-images")
        except G8ClientError as e:
            if e.status_code == 404:
                return None, []
            logger.warning(
                "g8://campaigns/%s/ad-images backend error %s: %s",
                campaign_id,
                e.status_code,
                e,
            )
            return None, []

        payload = raw.get("data") if isinstance(raw, dict) else None
        if not isinstance(payload, dict):
            return None, []
        images_raw = payload.get("images") or []
        images: list[dict] = [img for img in images_raw if isinstance(img, dict)]
        return payload.get("campaign_name"), images

    @server.resource(
        "g8://campaigns/{campaign_id}/ad-images",
        mime_type="text/html",
        description=(
            "Visual grid of ad image creatives for one campaign. Renders inline "
            "in Claude.ai (HTML); other clients fall back to plain text via the "
            "sibling text resource."
        ),
    )
    async def campaign_ad_images_html(campaign_id: str) -> str:
        """HTML app surface - grid of ad creatives for a campaign.

        This is the Upgrade 4 spike: MCP resources can return
        `mimeType="text/html"` and Claude.ai will render them inline. The
        renderer has strict rules (inline CSS only, no JS, escaped user data);
        see `app_renderer.py`.

        Wrapped in `cached_render` so a client that re-reads the surface
        within 5 min serves from Redis (or the in-memory fallback when
        Redis is unavailable) instead of re-hitting the dev API.
        """
        async def _do() -> str:
            campaign_name, images = await _fetch_campaign_ad_images(campaign_id)
            return render_ad_images_html(
                campaign_id=campaign_id,
                campaign_name=campaign_name,
                image_records=images,
            )

        return await cached_render(
            cache_prefix="ad_images_html",
            key_suffix=f"{campaign_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://campaigns/{campaign_id}/ad-images.txt",
        mime_type="text/plain",
        description="Plain-text list of ad image creatives for clients without HTML.",
    )
    async def campaign_ad_images_text(campaign_id: str) -> str:
        """Plaintext fallback for the ad-images app surface.

        Exposed as a separate URI so non-HTML clients (Claude Code CLI,
        Cursor, Claude Desktop as of 2026-04) can explicitly request it.
        """
        async def _do() -> str:
            campaign_name, images = await _fetch_campaign_ad_images(campaign_id)
            return render_ad_images_text_fallback(
                campaign_id=campaign_id,
                campaign_name=campaign_name,
                image_records=images,
            )

        return await cached_render(
            cache_prefix="ad_images_text",
            key_suffix=f"{campaign_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Sequence preview - app surface #2 (upgrade 4 extension).           #
    # ------------------------------------------------------------------ #

    async def _fetch_sequence_preview(sequence_id: str) -> dict | None:
        """Call the sequence preview endpoint and return the inner payload.

        Degrades to `None` on 404 / other non-success so the renderer can
        always emit a valid empty-state document instead of raising.
        """
        try:
            raw = await client.get(f"/sequences/{sequence_id}/preview")
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://sequences/%s backend error %s: %s",
                sequence_id,
                e.status_code,
                e,
            )
            return None

        if not isinstance(raw, dict):
            return None
        data = raw.get("data", raw)
        return data if isinstance(data, dict) else None

    @server.resource(
        "g8://sequences/{sequence_id}/preview",
        mime_type="text/html",
        description=(
            "Visual preview of a sequence - step timeline + channels. Renders "
            "inline in Claude.ai; other clients fall back to plain text via the "
            "sibling .txt resource. Matches the `g8://campaigns/{id}/ad-images` "
            "URI convention - explicit suffix avoids ambiguity with an open "
            "{sequence_id} capture."
        ),
    )
    async def sequence_preview_html(sequence_id: str) -> str:
        """HTML app surface - step timeline for a single sequence."""

        async def _do() -> str:
            preview = await _fetch_sequence_preview(sequence_id)
            return render_sequence_preview_html(
                sequence_id=sequence_id,
                preview=preview,
            )

        return await cached_render(
            cache_prefix="sequence_preview_html",
            key_suffix=f"{sequence_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://sequences/{sequence_id}/preview.txt",
        mime_type="text/plain",
        description="Plain-text step list for a sequence (clients without HTML).",
    )
    async def sequence_preview_text(sequence_id: str) -> str:
        """Plaintext fallback for the sequence preview app surface."""

        async def _do() -> str:
            preview = await _fetch_sequence_preview(sequence_id)
            return render_sequence_preview_text_fallback(
                sequence_id=sequence_id,
                preview=preview,
            )

        return await cached_render(
            cache_prefix="sequence_preview_text",
            key_suffix=f"{sequence_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Persona dashboard - app surface #3.                                #
    # Unlike ad-images and sequence-preview, this is NOT URI-templated:  #
    # there's one dashboard per authenticated org (from the API key).    #
    # ------------------------------------------------------------------ #

    async def _fetch_personas() -> list[dict]:
        """Load all personas for the current org, or [] on failure."""
        try:
            raw = await client.get("/personas", {"limit": 200})
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://personas/dashboard backend error %s: %s",
                e.status_code,
                e,
            )
            return []

        if not isinstance(raw, dict):
            return []
        data = raw.get("data")
        if not isinstance(data, list):
            return []
        return [p for p in data if isinstance(p, dict)]

    @server.resource(
        "g8://personas/dashboard",
        mime_type="text/html",
        description=(
            "Visual dashboard of all personas defined for the authenticated "
            "org - priority, confidence, signals, recommended goal, and "
            "campaign approach. Renders inline in Claude.ai; other clients "
            "fall back to plain text via the sibling .txt resource."
        ),
    )
    async def personas_dashboard_html() -> str:
        """HTML app surface - persona dashboard for the current org."""

        async def _do() -> str:
            personas = await _fetch_personas()
            return render_persona_dashboard_html(personas=personas)

        return await cached_render(
            cache_prefix="personas_dashboard_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://personas/dashboard.txt",
        mime_type="text/plain",
        description="Plain-text persona list (clients without HTML).",
    )
    async def personas_dashboard_text() -> str:
        """Plaintext fallback for the persona dashboard app surface."""

        async def _do() -> str:
            personas = await _fetch_personas()
            return render_persona_dashboard_text_fallback(personas=personas)

        return await cached_render(
            cache_prefix="personas_dashboard_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # KB library - app surface #4.                                       #
    # Like the persona dashboard, this is org-scoped (no URI capture).   #
    # ------------------------------------------------------------------ #

    async def _fetch_kb_documents() -> list[dict]:
        """Load all KB docs for the current org, or [] on failure."""
        try:
            raw = await client.get("/kb")
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://kb/library backend error %s: %s",
                e.status_code,
                e,
            )
            return []

        if not isinstance(raw, dict):
            return []
        data = raw.get("data")
        if not isinstance(data, list):
            return []
        return [d for d in data if isinstance(d, dict)]

    @server.resource(
        "g8://kb/library",
        mime_type="text/html",
        description=(
            "Visual dashboard of the KB library - docs grouped by section, "
            "with chunk counts and last-updated timestamps. Renders inline "
            "in Claude.ai; other clients fall back to the sibling .txt "
            "resource."
        ),
    )
    async def kb_library_html() -> str:
        """HTML app surface - KB library dashboard for the current org."""

        async def _do() -> str:
            documents = await _fetch_kb_documents()
            return render_kb_library_html(documents=documents)

        return await cached_render(
            cache_prefix="kb_library_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://kb/library.txt",
        mime_type="text/plain",
        description="Plain-text KB library list grouped by section.",
    )
    async def kb_library_text() -> str:
        """Plaintext fallback for the KB library app surface."""

        async def _do() -> str:
            documents = await _fetch_kb_documents()
            return render_kb_library_text_fallback(documents=documents)

        return await cached_render(
            cache_prefix="kb_library_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # ICP dashboard - app surface #5.                                    #
    # Mirrors the persona pattern: org-scoped, no URI capture, backed by #
    # GET /api/v1/icps (fit/opportunity/readiness scores + firmographics).#
    # ------------------------------------------------------------------ #

    async def _fetch_icps() -> list[dict]:
        """Load all ICPs for the current org, or [] on failure."""
        try:
            raw = await client.get("/icps", {"limit": 200})
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://icps/dashboard backend error %s: %s",
                e.status_code,
                e,
            )
            return []

        if not isinstance(raw, dict):
            return []
        data = raw.get("data")
        if not isinstance(data, list):
            return []
        return [i for i in data if isinstance(i, dict)]

    @server.resource(
        "g8://icps/dashboard",
        mime_type="text/html",
        description=(
            "Visual dashboard of all ICPs defined for the authenticated "
            "org - fit/opportunity/readiness scores, buying signals, "
            "firmographics, and tech stack. Renders inline in Claude.ai; "
            "other clients fall back to plain text via the sibling .txt "
            "resource."
        ),
    )
    async def icps_dashboard_html() -> str:
        """HTML app surface - ICP dashboard for the current org."""

        async def _do() -> str:
            icps = await _fetch_icps()
            return render_icp_dashboard_html(icps=icps)

        return await cached_render(
            cache_prefix="icps_dashboard_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://icps/dashboard.txt",
        mime_type="text/plain",
        description="Plain-text ICP list with scores + buying signals.",
    )
    async def icps_dashboard_text() -> str:
        """Plaintext fallback for the ICP dashboard app surface."""

        async def _do() -> str:
            icps = await _fetch_icps()
            return render_icp_dashboard_text_fallback(icps=icps)

        return await cached_render(
            cache_prefix="icps_dashboard_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Campaigns dashboard - app surface #6.                              #
    # Org-scoped status-grouped dashboard over GET /api/v1/campaigns.    #
    # ------------------------------------------------------------------ #

    async def _fetch_campaigns() -> list[dict]:
        """Load campaigns for the current org, or [] on failure."""
        try:
            raw = await client.get("/campaigns", {"page": 1, "limit": 200})
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://campaigns/dashboard backend error %s: %s",
                e.status_code,
                e,
            )
            return []

        if not isinstance(raw, dict):
            return []
        data = raw.get("data")
        if not isinstance(data, list):
            return []
        return [c for c in data if isinstance(c, dict)]

    @server.resource(
        "g8://campaigns/dashboard",
        mime_type="text/html",
        description=(
            "Visual dashboard of all campaigns for the authenticated org, "
            "grouped by status (live / draft / paused / etc.). Each card "
            "shows name, category, target persona, goal preview, and slug. "
            "Renders inline in Claude.ai; other clients fall back to the "
            "sibling .txt resource."
        ),
    )
    async def campaigns_dashboard_html() -> str:
        """HTML app surface - campaigns dashboard for the current org."""

        async def _do() -> str:
            campaigns = await _fetch_campaigns()
            return render_campaigns_dashboard_html(campaigns=campaigns)

        return await cached_render(
            cache_prefix="campaigns_dashboard_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://campaigns/dashboard.txt",
        mime_type="text/plain",
        description="Plain-text campaigns list grouped by status.",
    )
    async def campaigns_dashboard_text() -> str:
        """Plaintext fallback for the campaigns dashboard app surface."""

        async def _do() -> str:
            campaigns = await _fetch_campaigns()
            return render_campaigns_dashboard_text_fallback(campaigns=campaigns)

        return await cached_render(
            cache_prefix="campaigns_dashboard_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Inbox dashboard - app surface #7.                                  #
    # Threads grouped by channel (email / sms / linkedin / whatsapp).    #
    # ------------------------------------------------------------------ #

    async def _fetch_inbox_threads() -> list[dict]:
        """Load inbox threads for the current org, or [] on failure.

        Backend envelope uses `threads`, not `data` - we check both.
        """
        try:
            raw = await client.get("/inbox", {"page": 1, "page_size": 200})
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://inbox/dashboard backend error %s: %s",
                e.status_code,
                e,
            )
            return []

        if not isinstance(raw, dict):
            return []
        # Support both envelope shapes - the inbox endpoint's typed schema
        # uses `threads`, but some legacy paths use `data`.
        threads = raw.get("threads")
        if not isinstance(threads, list):
            threads = raw.get("data")
        if not isinstance(threads, list):
            return []
        return [t for t in threads if isinstance(t, dict)]

    @server.resource(
        "g8://inbox/dashboard",
        mime_type="text/html",
        description=(
            "Visual inbox dashboard - threads grouped by channel (email / "
            "SMS / LinkedIn / WhatsApp), with subject, contact, tags, "
            "assignee, status badge, and message preview per row. "
            "Renders inline in Claude.ai; other clients fall back to the "
            "sibling .txt resource."
        ),
    )
    async def inbox_dashboard_html() -> str:
        """HTML app surface - inbox dashboard for the current org."""

        async def _do() -> str:
            threads = await _fetch_inbox_threads()
            return render_inbox_dashboard_html(threads=threads)

        return await cached_render(
            cache_prefix="inbox_dashboard_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://inbox/dashboard.txt",
        mime_type="text/plain",
        description="Plain-text inbox threads grouped by channel.",
    )
    async def inbox_dashboard_text() -> str:
        """Plaintext fallback for the inbox dashboard app surface."""

        async def _do() -> str:
            threads = await _fetch_inbox_threads()
            return render_inbox_dashboard_text_fallback(threads=threads)

        return await cached_render(
            cache_prefix="inbox_dashboard_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Lists dashboard - app surface #8.                                  #
    # CRM lists grouped by type (contacts / companies / other).          #
    # ------------------------------------------------------------------ #

    async def _fetch_lists() -> list[dict]:
        """Load CRM lists for the current org, or [] on failure.

        Backend envelope uses `lists` (ListsResult model) but we also
        fall back to `data` for legacy compatibility.
        """
        try:
            raw = await client.get("/lists", {"page": 1, "limit": 200})
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://lists/dashboard backend error %s: %s",
                e.status_code,
                e,
            )
            return []

        if not isinstance(raw, dict):
            return []
        items = raw.get("lists")
        if not isinstance(items, list):
            items = raw.get("data")
        if not isinstance(items, list):
            return []
        return [l for l in items if isinstance(l, dict)]

    @server.resource(
        "g8://lists/dashboard",
        mime_type="text/html",
        description=(
            "Visual CRM lists dashboard - contact and company lists "
            "grouped by type, with total counts (contacts + companies) "
            "and updated timestamps per row. Renders inline in "
            "Claude.ai; other clients fall back to the sibling .txt "
            "resource."
        ),
    )
    async def lists_dashboard_html() -> str:
        """HTML app surface - lists dashboard for the current org."""

        async def _do() -> str:
            lists = await _fetch_lists()
            return render_lists_dashboard_html(lists=lists)

        return await cached_render(
            cache_prefix="lists_dashboard_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://lists/dashboard.txt",
        mime_type="text/plain",
        description="Plain-text CRM lists grouped by type.",
    )
    async def lists_dashboard_text() -> str:
        """Plaintext fallback for the lists dashboard app surface."""

        async def _do() -> str:
            lists = await _fetch_lists()
            return render_lists_dashboard_text_fallback(lists=lists)

        return await cached_render(
            cache_prefix="lists_dashboard_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Sequences dashboard - app surface #9.                              #
    # Outbound sequences grouped by status (active/paused/draft/archived)#
    # ------------------------------------------------------------------ #

    async def _fetch_sequences() -> list[dict]:
        """Load outbound sequences for the current org, or [] on failure."""
        try:
            raw = await client.get("/sequences", {"page": 1, "limit": 200})
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://sequences/dashboard backend error %s: %s",
                e.status_code,
                e,
            )
            return []

        if not isinstance(raw, dict):
            return []
        items = raw.get("sequences")
        if not isinstance(items, list):
            items = raw.get("data")
        if not isinstance(items, list):
            return []
        return [s for s in items if isinstance(s, dict)]

    @server.resource(
        "g8://sequences/dashboard",
        mime_type="text/html",
        description=(
            "Visual outbound sequences dashboard - sequences grouped by "
            "status (active / paused / draft / archived) with per-row "
            "name, step count, contact count, status dot, and updated "
            "timestamp. Sorted by contact count desc within each group. "
            "Renders inline in Claude.ai; other clients fall back to the "
            "sibling .txt resource."
        ),
    )
    async def sequences_dashboard_html() -> str:
        """HTML app surface - sequences dashboard for the current org."""

        async def _do() -> str:
            sequences = await _fetch_sequences()
            return render_sequences_dashboard_html(sequences=sequences)

        return await cached_render(
            cache_prefix="sequences_dashboard_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://sequences/dashboard.txt",
        mime_type="text/plain",
        description="Plain-text outbound sequences grouped by status.",
    )
    async def sequences_dashboard_text() -> str:
        """Plaintext fallback for the sequences dashboard app surface."""

        async def _do() -> str:
            sequences = await _fetch_sequences()
            return render_sequences_dashboard_text_fallback(sequences=sequences)

        return await cached_render(
            cache_prefix="sequences_dashboard_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Activities feed - app surface #10.                                 #
    # Chronological CRM activity stream grouped by date.                 #
    # ------------------------------------------------------------------ #

    async def _fetch_activities() -> list[dict]:
        """Load recent CRM activities for the current org, or [] on failure.

        Activities endpoint envelope is just a bare list or `data`/`activities`
        key - we defensively support all three.
        """
        try:
            raw = await client.get("/activities", {"limit": 200})
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://activities/feed backend error %s: %s",
                e.status_code,
                e,
            )
            return []

        if isinstance(raw, list):
            return [a for a in raw if isinstance(a, dict)]
        if not isinstance(raw, dict):
            return []
        items = raw.get("activities")
        if not isinstance(items, list):
            items = raw.get("data")
        if not isinstance(items, list):
            return []
        return [a for a in items if isinstance(a, dict)]

    @server.resource(
        "g8://activities/feed",
        mime_type="text/html",
        description=(
            "Visual CRM activity feed - recent notes, calls, meetings, "
            "stage changes, and task completions grouped by date (newest "
            "first). Each row shows an activity-type icon + badge, "
            "summary, linked entities (contact / company / deal), and "
            "timestamp. Renders inline in Claude.ai; other clients fall "
            "back to the sibling .txt resource."
        ),
    )
    async def activities_feed_html() -> str:
        """HTML app surface - activity feed for the current org."""

        async def _do() -> str:
            activities = await _fetch_activities()
            return render_activities_feed_html(activities=activities)

        return await cached_render(
            cache_prefix="activities_feed_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://activities/feed.txt",
        mime_type="text/plain",
        description="Plain-text CRM activity feed grouped by date.",
    )
    async def activities_feed_text() -> str:
        """Plaintext fallback for the activity feed app surface."""

        async def _do() -> str:
            activities = await _fetch_activities()
            return render_activities_feed_text_fallback(activities=activities)

        return await cached_render(
            cache_prefix="activities_feed_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Deals pipeline - app surface #11.                                   #
    # Open deals grouped by pipeline stage with per-stage totals.         #
    # ------------------------------------------------------------------ #

    async def _fetch_deals() -> list[dict]:
        """Load deals for the current org, or [] on failure.

        Deals endpoint uses the standard envelope: `{"deals": [...]}` or
        `{"data": [...]}`. We default to pulling 200 to cover a reasonable
        pipeline without blowing up the HTML payload.
        """
        try:
            raw = await client.get("/deals", {"limit": 200})
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://deals/pipeline backend error %s: %s",
                e.status_code,
                e,
            )
            return []

        if isinstance(raw, list):
            return [d for d in raw if isinstance(d, dict)]
        if not isinstance(raw, dict):
            return []
        items = raw.get("deals")
        if not isinstance(items, list):
            items = raw.get("data")
        if not isinstance(items, list):
            return []
        return [d for d in items if isinstance(d, dict)]

    @server.resource(
        "g8://deals/pipeline",
        mime_type="text/html",
        description=(
            "Visual CRM deals pipeline - open deals grouped by stage with "
            "per-stage subtotals and a grand-total pipeline value. Each "
            "row shows deal name, amount, currency, status badge, and "
            "close date. Renders inline in Claude.ai; other clients fall "
            "back to the sibling .txt resource."
        ),
    )
    async def deals_pipeline_html() -> str:
        """HTML app surface - deals pipeline for the current org."""

        async def _do() -> str:
            deals = await _fetch_deals()
            return render_deals_pipeline_html(deals=deals)

        return await cached_render(
            cache_prefix="deals_pipeline_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://deals/pipeline.txt",
        mime_type="text/plain",
        description="Plain-text CRM deals pipeline grouped by stage.",
    )
    async def deals_pipeline_text() -> str:
        """Plaintext fallback for the deals pipeline app surface."""

        async def _do() -> str:
            deals = await _fetch_deals()
            return render_deals_pipeline_text_fallback(deals=deals)

        return await cached_render(
            cache_prefix="deals_pipeline_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Tasks dashboard - app surface #12.                                  #
    # Sales task queue grouped by status with overdue highlighting.       #
    # ------------------------------------------------------------------ #

    async def _fetch_tasks() -> list[dict]:
        """Load tasks for the current org, or [] on failure.

        Tasks endpoint envelope: `{"tasks": [...]}` or `{"data": [...]}`.
        """
        try:
            raw = await client.get("/tasks", {"limit": 200})
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://tasks/dashboard backend error %s: %s",
                e.status_code,
                e,
            )
            return []

        if isinstance(raw, list):
            return [t for t in raw if isinstance(t, dict)]
        if not isinstance(raw, dict):
            return []
        items = raw.get("tasks")
        if not isinstance(items, list):
            items = raw.get("data")
        if not isinstance(items, list):
            return []
        return [t for t in items if isinstance(t, dict)]

    @server.resource(
        "g8://tasks/dashboard",
        mime_type="text/html",
        description=(
            "Visual CRM tasks queue - open and in-progress sales tasks "
            "grouped by status, with priority badges (P1-P4), due dates, "
            "overdue highlighting (red badge when due_date is past), "
            "and linked contact / company / assignee for each row. "
            "Sorted globally by priority asc then due date asc. Renders "
            "inline in Claude.ai; other clients fall back to the sibling "
            ".txt resource."
        ),
    )
    async def tasks_dashboard_html() -> str:
        """HTML app surface - task queue for the current org."""

        async def _do() -> str:
            tasks = await _fetch_tasks()
            return render_tasks_dashboard_html(tasks=tasks)

        return await cached_render(
            cache_prefix="tasks_dashboard_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://tasks/dashboard.txt",
        mime_type="text/plain",
        description="Plain-text CRM task queue grouped by status.",
    )
    async def tasks_dashboard_text() -> str:
        """Plaintext fallback for the tasks dashboard app surface."""

        async def _do() -> str:
            tasks = await _fetch_tasks()
            return render_tasks_dashboard_text_fallback(tasks=tasks)

        return await cached_render(
            cache_prefix="tasks_dashboard_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Campaign ideas dashboard - app surface #13.                         #
    # Saved campaign ideas with favorite star + description + timeline.   #
    # ------------------------------------------------------------------ #

    async def _fetch_campaign_ideas() -> list[dict]:
        """Load saved campaign ideas for the current org, or [] on failure.

        Ideas endpoint envelope: `{"ideas": [...]}` or `{"data": [...]}`.
        """
        try:
            raw = await client.get("/campaigns/ideas", {"limit": 200})
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://campaigns/ideas backend error %s: %s",
                e.status_code,
                e,
            )
            return []

        if isinstance(raw, list):
            return [i for i in raw if isinstance(i, dict)]
        if not isinstance(raw, dict):
            return []
        items = raw.get("ideas")
        if not isinstance(items, list):
            items = raw.get("data")
        if not isinstance(items, list):
            return []
        return [i for i in items if isinstance(i, dict)]

    @server.resource(
        "g8://campaigns/ideas",
        mime_type="text/html",
        description=(
            "Visual campaign ideation board - saved campaign ideas rendered "
            "as cards with favorite star highlight, description, and "
            "created date. Favorited ideas render first with a warm amber "
            "border; the rest sort newest-first. Renders inline in "
            "Claude.ai; other clients fall back to the sibling .txt."
        ),
    )
    async def campaign_ideas_dashboard_html() -> str:
        """HTML app surface - campaign ideas board for the current org."""

        async def _do() -> str:
            ideas = await _fetch_campaign_ideas()
            return render_campaign_ideas_dashboard_html(ideas=ideas)

        return await cached_render(
            cache_prefix="campaign_ideas_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://campaigns/ideas.txt",
        mime_type="text/plain",
        description="Plain-text campaign ideation board.",
    )
    async def campaign_ideas_dashboard_text() -> str:
        """Plaintext fallback for the campaign ideas app surface."""

        async def _do() -> str:
            ideas = await _fetch_campaign_ideas()
            return render_campaign_ideas_dashboard_text_fallback(ideas=ideas)

        return await cached_render(
            cache_prefix="campaign_ideas_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Pipelines overview - app surface #14.                               #
    # Pipeline structure - stages visualized as a horizontal flow.        #
    # ------------------------------------------------------------------ #

    async def _fetch_pipelines() -> list[dict]:
        """Load pipelines for the current org, or [] on failure.

        Pipelines envelope: `{"pipelines": [...]}` or `{"data": [...]}`.
        """
        try:
            raw = await client.get("/deals/pipelines", None)
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://pipelines/overview backend error %s: %s",
                e.status_code,
                e,
            )
            return []

        if isinstance(raw, list):
            return [p for p in raw if isinstance(p, dict)]
        if not isinstance(raw, dict):
            return []
        items = raw.get("pipelines")
        if not isinstance(items, list):
            items = raw.get("data")
        if not isinstance(items, list):
            return []
        return [p for p in items if isinstance(p, dict)]

    @server.resource(
        "g8://pipelines/overview",
        mime_type="text/html",
        description=(
            "Visual CRM pipeline structure - each configured pipeline "
            "rendered as a horizontal flow of numbered, arrow-connected "
            "stage chips. Answers 'what stages do we have' - complementary "
            "to g8://deals/pipeline which shows the deals inside the "
            "stages. Renders inline in Claude.ai; other clients fall "
            "back to the sibling .txt resource."
        ),
    )
    async def pipelines_overview_html() -> str:
        """HTML app surface - pipeline structure for the current org."""

        async def _do() -> str:
            pipelines = await _fetch_pipelines()
            return render_pipelines_overview_html(pipelines=pipelines)

        return await cached_render(
            cache_prefix="pipelines_overview_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://pipelines/overview.txt",
        mime_type="text/plain",
        description="Plain-text CRM pipeline structure with stage flow arrows.",
    )
    async def pipelines_overview_text() -> str:
        """Plaintext fallback for the pipelines overview app surface."""

        async def _do() -> str:
            pipelines = await _fetch_pipelines()
            return render_pipelines_overview_text_fallback(pipelines=pipelines)

        return await cached_render(
            cache_prefix="pipelines_overview_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Global context library - app surface #15.                           #
    # Studio's 44-doc knowledge base grouped by bucket.                   #
    # ------------------------------------------------------------------ #

    async def _fetch_global_docs() -> list[dict]:
        """Load global context documents for the current org, or [] on failure.

        Envelope: `{"documents": [...]}` or `{"data": [...]}` - the GET
        endpoint supports a `category` filter + `limit`. We pull all
        categories (no filter) and cap at 200 to safely cover the 44-doc
        ceiling plus growth.
        """
        try:
            raw = await client.get(
                "/global-context/documents",
                {"limit": 200},
            )
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://global-context/library backend error %s: %s",
                e.status_code,
                e,
            )
            return []

        if isinstance(raw, list):
            return [d for d in raw if isinstance(d, dict)]
        if not isinstance(raw, dict):
            return []
        items = raw.get("documents")
        if not isinstance(items, list):
            items = raw.get("data")
        if not isinstance(items, list):
            return []
        return [d for d in items if isinstance(d, dict)]

    @server.resource(
        "g8://global-context/library",
        mime_type="text/html",
        description=(
            "Studio global context library - the 44-doc knowledge base "
            "per org (21 context + 16 intelligence + 6 research + 1 "
            "brief). Documents grouped by category with status badges "
            "(ready / generating / queued / stale / failed) and last-"
            "updated timestamps. Renders inline in Claude.ai; other "
            "clients fall back to the sibling .txt resource."
        ),
    )
    async def global_context_library_html() -> str:
        """HTML app surface - global context library for the current org."""

        async def _do() -> str:
            docs = await _fetch_global_docs()
            return render_global_context_library_html(documents=docs)

        return await cached_render(
            cache_prefix="global_context_library_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://global-context/library.txt",
        mime_type="text/plain",
        description="Plain-text global context library grouped by category.",
    )
    async def global_context_library_text() -> str:
        """Plaintext fallback for the global context library app surface."""

        async def _do() -> str:
            docs = await _fetch_global_docs()
            return render_global_context_library_text_fallback(documents=docs)

        return await cached_render(
            cache_prefix="global_context_library_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Audience syncs dashboard - app surface #16.                         #
    # Ad-platform audience sync configs grouped by platform.              #
    # ------------------------------------------------------------------ #

    async def _fetch_audience_syncs() -> list[dict]:
        """Load audience syncs for the current org, or [] on failure.

        Envelope: list | {syncs: [...]} | {data: [...]}
        """
        try:
            raw = await client.get("/audience-syncs", None)
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://audience-syncs/dashboard backend error %s: %s",
                e.status_code,
                e,
            )
            return []

        if isinstance(raw, list):
            return [s for s in raw if isinstance(s, dict)]
        if not isinstance(raw, dict):
            return []
        items = raw.get("syncs")
        if not isinstance(items, list):
            items = raw.get("data")
        if not isinstance(items, list):
            return []
        return [s for s in items if isinstance(s, dict)]

    @server.resource(
        "g8://audience-syncs/dashboard",
        mime_type="text/html",
        description=(
            "Audience sync status dashboard - ad platform (Meta, LinkedIn, "
            "Google Ads, X) audience sync configurations grouped by platform, "
            "with active-state dot, refresh cadence, last-sync timestamp, "
            "and colored status badge per row. Answers 'are my ads "
            "audiences in sync?'. Renders inline in Claude.ai; other "
            "clients fall back to the sibling .txt resource."
        ),
    )
    async def audience_syncs_dashboard_html() -> str:
        """HTML app surface - audience sync status for the current org."""

        async def _do() -> str:
            syncs = await _fetch_audience_syncs()
            return render_audience_syncs_dashboard_html(syncs=syncs)

        return await cached_render(
            cache_prefix="audience_syncs_dashboard_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://audience-syncs/dashboard.txt",
        mime_type="text/plain",
        description="Plain-text audience sync status dashboard grouped by platform.",
    )
    async def audience_syncs_dashboard_text() -> str:
        """Plaintext fallback for the audience syncs dashboard app surface."""

        async def _do() -> str:
            syncs = await _fetch_audience_syncs()
            return render_audience_syncs_dashboard_text_fallback(syncs=syncs)

        return await cached_render(
            cache_prefix="audience_syncs_dashboard_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # CRM integrations dashboard - app surface #17.                       #
    # HubSpot / Salesforce / Pipedrive / Zoho / SugarCRM connection       #
    # state with last-sync + status badge.                                #
    # ------------------------------------------------------------------ #

    async def _fetch_crm_syncs() -> list[dict]:
        """Load CRM integrations for the current org, or [] on failure.

        Envelope: list | {integrations: [...]} | {data: [...]}
        """
        try:
            raw = await client.get("/crm-syncs", None)
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://crm-syncs/dashboard backend error %s: %s",
                e.status_code,
                e,
            )
            return []

        if isinstance(raw, list):
            return [i for i in raw if isinstance(i, dict)]
        if not isinstance(raw, dict):
            return []
        items = raw.get("integrations")
        if not isinstance(items, list):
            items = raw.get("data")
        if not isinstance(items, list):
            return []
        return [i for i in items if isinstance(i, dict)]

    @server.resource(
        "g8://crm-syncs/dashboard",
        mime_type="text/html",
        description=(
            "CRM integrations dashboard - connected/disconnected state for "
            "HubSpot, Salesforce, Pipedrive, Zoho, SugarCRM and other CRM "
            "providers, with per-row account name, last-sync timestamp, and "
            "colored status badge. Answers 'which CRMs am I syncing with?'. "
            "Renders inline in Claude.ai; other clients fall back to the "
            "sibling .txt resource."
        ),
    )
    async def crm_syncs_dashboard_html() -> str:
        """HTML app surface - CRM integrations for the current org."""

        async def _do() -> str:
            integrations = await _fetch_crm_syncs()
            return render_crm_syncs_dashboard_html(integrations=integrations)

        return await cached_render(
            cache_prefix="crm_syncs_dashboard_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://crm-syncs/dashboard.txt",
        mime_type="text/plain",
        description="Plain-text CRM integrations dashboard.",
    )
    async def crm_syncs_dashboard_text() -> str:
        """Plaintext fallback for the CRM integrations dashboard."""

        async def _do() -> str:
            integrations = await _fetch_crm_syncs()
            return render_crm_syncs_dashboard_text_fallback(
                integrations=integrations
            )

        return await cached_render(
            cache_prefix="crm_syncs_dashboard_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Sync runs history - app surface #18.                                #
    # Per-sync run timeline (URI-templated like sequence-preview).        #
    # ------------------------------------------------------------------ #

    async def _fetch_sync_runs(config_id: str) -> tuple[list[dict], str | None]:
        """Fetch run history + sync label for a specific config, or ([], None) on failure.

        Envelope for runs: list | {runs: [...]} | {data: [...]}
        Sync label is looked up best-effort via GET /audience-syncs/{config_id}.
        """
        try:
            raw = await client.get(f"/audience-syncs/{config_id}/runs", {"limit": 100})
        except G8ClientError as e:
            if e.status_code == 404:
                return ([], None)
            logger.warning(
                "g8://audience-syncs/%s/runs backend error %s: %s",
                config_id,
                e.status_code,
                e,
            )
            return ([], None)

        if isinstance(raw, list):
            runs = [r for r in raw if isinstance(r, dict)]
        elif isinstance(raw, dict):
            items = raw.get("runs")
            if not isinstance(items, list):
                items = raw.get("data")
            runs = [r for r in items if isinstance(r, dict)] if isinstance(items, list) else []
        else:
            runs = []

        # Best-effort label lookup - surface renders fine without it
        label: str | None = None
        try:
            sync_raw = await client.get(f"/audience-syncs/{config_id}")
            sync_data = (
                sync_raw.get("data", sync_raw)
                if isinstance(sync_raw, dict)
                else None
            )
            if isinstance(sync_data, dict):
                label = (
                    sync_data.get("platform_audience_name")
                    or sync_data.get("name")
                    or sync_data.get("platform")
                )
        except G8ClientError:
            pass

        return (runs, label)

    @server.resource(
        "g8://audience-syncs/{config_id}/runs",
        mime_type="text/html",
        description=(
            "Sync run history for a specific audience sync config - timeline of "
            "runs with per-run status badge, started/finished timestamps, "
            "member-count delta (+added / -removed), and inline error messages "
            "for failed runs. Answers 'why did this sync break / when did it "
            "last succeed?'. URI-templated by config_id - explicit /runs suffix "
            "avoids ambiguity with an open {config_id} capture. Renders inline "
            "in Claude.ai; other clients fall back to the sibling .txt resource."
        ),
    )
    async def sync_runs_history_html(config_id: str) -> str:
        """HTML app surface - run timeline for a single sync config."""

        async def _do() -> str:
            runs, label = await _fetch_sync_runs(config_id)
            return render_sync_runs_history_html(
                runs=runs,
                config_id=config_id,
                sync_label=label,
            )

        return await cached_render(
            cache_prefix="sync_runs_history_html",
            key_suffix=f"{config_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://audience-syncs/{config_id}/runs.txt",
        mime_type="text/plain",
        description="Plain-text sync run timeline for clients without HTML.",
    )
    async def sync_runs_history_text(config_id: str) -> str:
        """Plaintext fallback for the sync runs history app surface."""

        async def _do() -> str:
            runs, label = await _fetch_sync_runs(config_id)
            return render_sync_runs_history_text_fallback(
                runs=runs,
                config_id=config_id,
                sync_label=label,
            )

        return await cached_render(
            cache_prefix="sync_runs_history_text",
            key_suffix=f"{config_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # CRM fields schema - app surface #19.                                #
    # Per-provider field mapping (URI-templated by provider).             #
    # Entity type defaults to "contacts" but can be switched via an       #
    # optional `entity` suffix in the URI capture.                        #
    # ------------------------------------------------------------------ #

    async def _fetch_crm_fields(
        provider: str, entity_type: str = "contacts"
    ) -> list[dict]:
        """Load CRM field schema for a provider + entity, or [] on failure.

        Envelope from backend: may return top-level {data: [...]} or
        {data: {fields: [...]}} depending on the provider adapter.
        """
        try:
            raw = await client.get(
                f"/crm-syncs/{provider}/fields",
                {"entity_type": entity_type},
            )
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://crm-syncs/%s/fields backend error %s: %s",
                provider,
                e.status_code,
                e,
            )
            return []

        if isinstance(raw, list):
            return [f for f in raw if isinstance(f, dict)]
        if not isinstance(raw, dict):
            return []
        data = raw.get("data", raw)
        if isinstance(data, list):
            return [f for f in data if isinstance(f, dict)]
        if isinstance(data, dict):
            items = data.get("fields") or data.get("data") or []
            if isinstance(items, list):
                return [f for f in items if isinstance(f, dict)]
        return []

    @server.resource(
        "g8://crm-syncs/{provider}/fields",
        mime_type="text/html",
        description=(
            "CRM field schema for one provider - contact-level property map "
            "with per-field name/label + colored type chip (string/number/"
            "boolean/enum/email/date) + required + custom badges. Required "
            "fields sort to the top, then optional. Answers 'what fields "
            "can I sync, and which are required?'. URI-templated by "
            "provider (hubspot / salesforce / pipedrive / zoho / sugarcrm). "
            "Defaults to contact entity; other entities queryable via the "
            "underlying sync.get_crm_fields tool. Renders inline in "
            "Claude.ai; other clients fall back to the sibling .txt resource."
        ),
    )
    async def crm_fields_schema_html(provider: str) -> str:
        """HTML app surface - field schema for one CRM provider (contacts)."""

        async def _do() -> str:
            fields = await _fetch_crm_fields(provider, "contacts")
            return render_crm_fields_schema_html(
                fields=fields,
                provider=provider,
                entity_type="contacts",
            )

        return await cached_render(
            cache_prefix="crm_fields_schema_html",
            key_suffix=f"{provider}:contacts:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://crm-syncs/{provider}/fields.txt",
        mime_type="text/plain",
        description="Plain-text CRM field schema for clients without HTML.",
    )
    async def crm_fields_schema_text(provider: str) -> str:
        """Plaintext fallback for the CRM fields schema app surface."""

        async def _do() -> str:
            fields = await _fetch_crm_fields(provider, "contacts")
            return render_crm_fields_schema_text_fallback(
                fields=fields,
                provider=provider,
                entity_type="contacts",
            )

        return await cached_render(
            cache_prefix="crm_fields_schema_text",
            key_suffix=f"{provider}:contacts:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ----------------------------------------------------------------------
    # Inbox thread detail (upgrade 4 - surface #20)
    # Single-thread conversation view with all messages, tags, assignees.
    # URI-templated on reply_id; defaults to channel=email (matches the
    # g8_get_reply tool default). For other channels the caller can use
    # the tool directly; narrowing the URI to email avoids a noisy URI scheme.
    # ----------------------------------------------------------------------

    async def _fetch_inbox_thread(
        reply_id: str, channel: str = "email"
    ) -> dict | None:
        """Load a single inbox thread, or None on missing/error.

        Returns the payload dict so the renderer can treat unknown fields
        defensively without a Pydantic roundtrip.
        """
        try:
            raw = await client.get(f"/inbox/{reply_id}", {"channel": channel})
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://inbox/threads/%s backend error %s: %s",
                reply_id,
                e.status_code,
                e,
            )
            return None

        if not isinstance(raw, dict):
            return None
        data = raw.get("data", raw)
        if isinstance(data, dict) and data:
            return data
        return None

    @server.resource(
        "g8://inbox/threads/{reply_id}",
        mime_type="text/html",
        description=(
            "Single inbox thread view - full message history with inbound "
            "vs outbound styling, timestamps, subject (when it diverges from "
            "the thread subject), tags, and assignees. Complements "
            "g8://inbox/dashboard (thread list) - drill into one thread to "
            "read the whole conversation inline. Defaults to channel=email; "
            "use the sync.get_reply tool for SMS / LinkedIn / etc. "
            "Renders inline in Claude.ai; other clients fall back to the "
            "sibling .txt resource."
        ),
    )
    async def inbox_thread_detail_html(reply_id: str) -> str:
        """HTML app surface - one inbox thread with full conversation."""

        async def _do() -> str:
            thread = await _fetch_inbox_thread(reply_id, "email")
            return render_inbox_thread_detail_html(
                thread=thread,
                reply_id=reply_id,
                channel="email",
            )

        return await cached_render(
            cache_prefix="inbox_thread_detail_html",
            key_suffix=f"{reply_id}:email:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://inbox/threads/{reply_id}.txt",
        mime_type="text/plain",
        description="Plain-text inbox thread transcript for clients without HTML.",
    )
    async def inbox_thread_detail_text(reply_id: str) -> str:
        """Plaintext fallback for the inbox thread detail app surface."""

        async def _do() -> str:
            thread = await _fetch_inbox_thread(reply_id, "email")
            return render_inbox_thread_detail_text_fallback(
                thread=thread,
                reply_id=reply_id,
                channel="email",
            )

        return await cached_render(
            cache_prefix="inbox_thread_detail_text",
            key_suffix=f"{reply_id}:email:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ----------------------------------------------------------------------
    # Campaign documents (upgrade 4 - surface #21)
    # Per-campaign document library grouped by folder_path with status chips
    # and type chips. Complements surface #15 (org-wide global context
    # library) by giving a campaign-scoped lens - "what deliverables exist
    # for THIS campaign and where is each one in the generation pipeline?".
    # URI-templated on campaign_id. Campaign name is fetched best-effort to
    # give the header a human-readable label; falls back to the raw id.
    # ----------------------------------------------------------------------

    async def _fetch_campaign_documents(campaign_id: str) -> list[dict]:
        """Load campaign document metadata, or [] on missing/error.

        Envelope is a list wrapped in `{data: [...]}` per backend convention.
        """
        try:
            raw = await client.get(f"/campaigns/{campaign_id}/documents")
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://campaigns/%s/documents backend error %s: %s",
                campaign_id,
                e.status_code,
                e,
            )
            return []

        if isinstance(raw, list):
            return [d for d in raw if isinstance(d, dict)]
        if not isinstance(raw, dict):
            return []
        data = raw.get("data", raw)
        if isinstance(data, list):
            return [d for d in data if isinstance(d, dict)]
        if isinstance(data, dict):
            items = data.get("documents") or data.get("data") or []
            if isinstance(items, list):
                return [d for d in items if isinstance(d, dict)]
        return []

    async def _fetch_campaign_name(campaign_id: str) -> str | None:
        """Best-effort campaign display name lookup; None on any failure."""
        try:
            raw = await client.get(f"/campaigns/{campaign_id}")
        except G8ClientError:
            return None
        except Exception:  # noqa: BLE001 - defensive: never break the render
            return None

        if not isinstance(raw, dict):
            return None
        data = raw.get("data", raw)
        if not isinstance(data, dict):
            return None
        name = data.get("name") or data.get("display_name") or data.get("title")
        if isinstance(name, str) and name.strip():
            return name.strip()
        return None

    @server.resource(
        "g8://campaigns/{campaign_id}/documents",
        mime_type="text/html",
        description=(
            "Campaign document library - all generated deliverables for one "
            "campaign, grouped by folder (strategy / brief / research / "
            "intelligence / messaging / copy / email / sequence / landing / "
            "ads / creative) with status chips (ready / generating / pending "
            "/ stale / failed) and type chips. Answers 'what has been "
            "generated for this campaign, and which docs are still missing "
            "or failed?'. Complements g8://global-context/library (org-wide) "
            "with a campaign-scoped lens. URI-templated by campaign_id. "
            "Renders inline in Claude.ai; other clients fall back to the "
            "sibling .txt resource."
        ),
    )
    async def campaign_documents_html(campaign_id: str) -> str:
        """HTML app surface - campaign document library grouped by folder."""

        async def _do() -> str:
            documents = await _fetch_campaign_documents(campaign_id)
            campaign_name = await _fetch_campaign_name(campaign_id)
            return render_campaign_documents_html(
                documents=documents,
                campaign_id=campaign_id,
                campaign_name=campaign_name,
            )

        return await cached_render(
            cache_prefix="campaign_documents_html",
            key_suffix=f"{campaign_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://campaigns/{campaign_id}/documents.txt",
        mime_type="text/plain",
        description="Plain-text campaign document library for clients without HTML.",
    )
    async def campaign_documents_text(campaign_id: str) -> str:
        """Plaintext fallback for the campaign documents app surface."""

        async def _do() -> str:
            documents = await _fetch_campaign_documents(campaign_id)
            campaign_name = await _fetch_campaign_name(campaign_id)
            return render_campaign_documents_text_fallback(
                documents=documents,
                campaign_id=campaign_id,
                campaign_name=campaign_name,
            )

        return await cached_render(
            cache_prefix="campaign_documents_text",
            key_suffix=f"{campaign_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ----------------------------------------------------------------------
    # Campaign sequence steps (upgrade 4 - surface #22)
    # Per-campaign DESIGNED step plan grouped by day offset. Complements
    # surface #2 (sequence preview - per sequence_id, execution view) and
    # surface #9 (sequences dashboard - org-wide list) by giving a
    # campaign-scoped step plan: "what steps will THIS campaign run, on
    # which days, in which channels?". Best-effort campaign name lookup
    # reuses `_fetch_campaign_name()` from surface #21.
    # ----------------------------------------------------------------------

    async def _fetch_campaign_sequence(campaign_id: str) -> list[dict]:
        """Load campaign sequence steps, or [] on missing/error.

        Envelope: `{data: {steps: [...]}}` per backend convention; some
        variants may return the list at the top level.
        """
        try:
            raw = await client.get(f"/campaigns/{campaign_id}/sequence")
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://campaigns/%s/sequence backend error %s: %s",
                campaign_id,
                e.status_code,
                e,
            )
            return []

        if isinstance(raw, list):
            return [s for s in raw if isinstance(s, dict)]
        if not isinstance(raw, dict):
            return []
        data = raw.get("data", raw)
        if isinstance(data, dict):
            items = data.get("steps") or data.get("data") or []
            if isinstance(items, list):
                return [s for s in items if isinstance(s, dict)]
        if isinstance(data, list):
            return [s for s in data if isinstance(s, dict)]
        return []

    @server.resource(
        "g8://campaigns/{campaign_id}/sequence",
        mime_type="text/html",
        description=(
            "Campaign sequence plan - the designed step catalog for one "
            "campaign, grouped by day offset (Day 0 kickoff, Day 2, Day 5, "
            "etc.). Per step: name + colored channel chip (email blue, "
            "linkedin indigo, sms green, phone/call amber, slack purple) + "
            "mode chip (automatic green, manual amber) + CTA type chip + "
            "personalization level chip + angle label + optional condition. "
            "Complements g8://sequences/{sequence_id}/preview (per-sequence "
            "execution view) and g8://sequences/dashboard (org-wide) with "
            "a campaign-scoped plan. URI-templated by campaign_id. "
            "Renders inline in Claude.ai; other clients fall back to the "
            "sibling .txt resource."
        ),
    )
    async def campaign_sequence_html(campaign_id: str) -> str:
        """HTML app surface - campaign sequence plan grouped by day offset."""

        async def _do() -> str:
            steps = await _fetch_campaign_sequence(campaign_id)
            campaign_name = await _fetch_campaign_name(campaign_id)
            return render_campaign_sequence_html(
                steps=steps,
                campaign_id=campaign_id,
                campaign_name=campaign_name,
            )

        return await cached_render(
            cache_prefix="campaign_sequence_html",
            key_suffix=f"{campaign_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://campaigns/{campaign_id}/sequence.txt",
        mime_type="text/plain",
        description="Plain-text campaign sequence plan for clients without HTML.",
    )
    async def campaign_sequence_text(campaign_id: str) -> str:
        """Plaintext fallback for the campaign sequence app surface."""

        async def _do() -> str:
            steps = await _fetch_campaign_sequence(campaign_id)
            campaign_name = await _fetch_campaign_name(campaign_id)
            return render_campaign_sequence_text_fallback(
                steps=steps,
                campaign_id=campaign_id,
                campaign_name=campaign_name,
            )

        return await cached_render(
            cache_prefix="campaign_sequence_text",
            key_suffix=f"{campaign_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ----------------------------------------------------------------------
    # Surface #23 - Sequence analytics (performance dashboard).
    # URI-templated by sequence_id. Complements surface #2 (sequence
    # preview - step structure) and surface #9 (sequences dashboard -
    # org list) with the "how is this sequence actually performing?"
    # lens. Best-effort sequence display name lookup.
    # ----------------------------------------------------------------------

    async def _fetch_sequence_analytics(sequence_id: str) -> dict | None:
        """Load sequence analytics, or None on 404 / backend error.

        Envelope: `{data: {overview, performance, engagement, timeline,
        contact_distribution, step_breakdown, ...}}` per backend.
        """
        try:
            raw = await client.get(f"/sequences/{sequence_id}/analytics")
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://sequences/%s/analytics backend error %s: %s",
                sequence_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001 - defensive: never break the render
            return None

        if not isinstance(raw, dict):
            return None
        data = raw.get("data", raw)
        return data if isinstance(data, dict) else None

    async def _fetch_sequence_name(sequence_id: str) -> str | None:
        """Best-effort sequence display name lookup; None on any failure."""
        try:
            raw = await client.get(f"/sequences/{sequence_id}")
        except G8ClientError:
            return None
        except Exception:  # noqa: BLE001
            return None

        if not isinstance(raw, dict):
            return None
        data = raw.get("data", raw)
        if not isinstance(data, dict):
            return None
        name = data.get("name") or data.get("display_name") or data.get("title")
        if isinstance(name, str) and name.strip():
            return name.strip()
        return None

    @server.resource(
        "g8://sequences/{sequence_id}/analytics",
        mime_type="text/html",
        description=(
            "Sequence performance dashboard - overview stats (total "
            "contacts, success rate, progress) + per-step delivery / "
            "reply / bounce rate bars + first-step response rates "
            "(24h/48h/7d) + 20-day send timeline. Includes a derived "
            "health badge (excellent / good / mediocre / struggling / "
            "no data). Complements g8://sequences/{sequence_id}/preview "
            "(step structure) and g8://sequences/dashboard (org list) "
            "with the performance lens. URI-templated by sequence_id. "
            "Renders inline in Claude.ai; other clients fall back to the "
            "sibling .txt resource."
        ),
    )
    async def sequence_analytics_html(sequence_id: str) -> str:
        """HTML app surface - sequence performance dashboard."""

        async def _do() -> str:
            analytics = await _fetch_sequence_analytics(sequence_id)
            sequence_name = await _fetch_sequence_name(sequence_id)
            return render_sequence_analytics_html(
                analytics=analytics,
                sequence_id=sequence_id,
                sequence_name=sequence_name,
            )

        return await cached_render(
            cache_prefix="sequence_analytics_html",
            key_suffix=f"{sequence_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://sequences/{sequence_id}/analytics.txt",
        mime_type="text/plain",
        description="Plain-text sequence analytics summary for clients without HTML.",
    )
    async def sequence_analytics_text(sequence_id: str) -> str:
        """Plaintext fallback for the sequence analytics app surface."""

        async def _do() -> str:
            analytics = await _fetch_sequence_analytics(sequence_id)
            sequence_name = await _fetch_sequence_name(sequence_id)
            return render_sequence_analytics_text_fallback(
                analytics=analytics,
                sequence_id=sequence_id,
                sequence_name=sequence_name,
            )

        return await cached_render(
            cache_prefix="sequence_analytics_text",
            key_suffix=f"{sequence_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ----------------------------------------------------------------------
    # Surface #24 - Deal detail (per-deal drilldown).
    # URI-templated by deal_id. Complements surface #11 (deals pipeline -
    # org-wide list grouped by stage) with the "tell me everything about
    # THIS deal" lens. Best-effort fetches: pipeline stages (for the
    # funnel ladder) + company name (to replace raw company_id).
    # ----------------------------------------------------------------------

    async def _fetch_deal_detail(deal_id: str) -> dict | None:
        """Load the deal, or None on 404 / backend error.

        Envelope: `{data: {id, name, amount, stage_id, stage_name, ...}}`.
        """
        try:
            raw = await client.get(f"/deals/{deal_id}")
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://deals/%s backend error %s: %s",
                deal_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001 - defensive: never break the render
            return None

        if not isinstance(raw, dict):
            return None
        data = raw.get("data", raw)
        return data if isinstance(data, dict) else None

    async def _fetch_pipeline_stages_for_deal(deal: dict | None) -> list[dict] | None:
        """Load ordered stages for the deal's pipeline; None on failure.

        `GET /deals/pipelines` returns all org pipelines; we pick the one
        matching `deal.pipeline_id` (or the default pipeline if no id).
        """
        if not isinstance(deal, dict):
            return None
        pipeline_id = deal.get("pipeline_id")
        try:
            raw = await client.get("/deals/pipelines")
        except G8ClientError as e:
            logger.warning(
                "g8://deals pipelines fetch backend error %s: %s",
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        if not isinstance(raw, dict):
            return None
        pipelines = raw.get("data", raw)
        if not isinstance(pipelines, list):
            return None

        # Find the matching pipeline, or fall back to default, or first.
        match = None
        default = None
        for p in pipelines:
            if not isinstance(p, dict):
                continue
            if pipeline_id and str(p.get("id") or "") == str(pipeline_id):
                match = p
                break
            if p.get("is_default"):
                default = p
        chosen = match or default or (pipelines[0] if pipelines else None)
        if not isinstance(chosen, dict):
            return None
        stages = chosen.get("stages")
        if not isinstance(stages, list):
            return None
        return [s for s in stages if isinstance(s, dict)]

    async def _fetch_company_name(company_id) -> str | None:
        """Best-effort company name lookup; None on any failure."""
        if company_id is None or company_id == "":
            return None
        try:
            raw = await client.get(f"/companies/{company_id}")
        except G8ClientError:
            return None
        except Exception:  # noqa: BLE001
            return None

        if not isinstance(raw, dict):
            return None
        data = raw.get("data", raw)
        if not isinstance(data, dict):
            return None
        name = data.get("name") or data.get("company_name") or data.get("display_name")
        if isinstance(name, str) and name.strip():
            return name.strip()
        return None

    @server.resource(
        "g8://deals/{deal_id}",
        mime_type="text/html",
        description=(
            "Single-deal drilldown - amount, stage, close date, days in "
            "pipeline, pipeline funnel ladder showing current position, "
            "description, linked company + owner. Derived open/won/lost "
            "status badge from stage metadata. Complements "
            "g8://deals/pipeline (org-wide list) with the per-deal lens. "
            "URI-templated by deal_id. Renders inline in Claude.ai; other "
            "clients fall back to the sibling .txt resource."
        ),
    )
    async def deal_detail_html(deal_id: str) -> str:
        """HTML app surface - single deal drilldown."""

        async def _do() -> str:
            deal = await _fetch_deal_detail(deal_id)
            pipeline_stages = await _fetch_pipeline_stages_for_deal(deal)
            company_name = None
            if isinstance(deal, dict):
                company_name = await _fetch_company_name(deal.get("company_id"))
            return render_deal_detail_html(
                deal=deal,
                deal_id=deal_id,
                pipeline_stages=pipeline_stages,
                company_name=company_name,
            )

        return await cached_render(
            cache_prefix="deal_detail_html",
            key_suffix=f"{deal_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://deals/{deal_id}.txt",
        mime_type="text/plain",
        description="Plain-text single-deal drilldown for clients without HTML.",
    )
    async def deal_detail_text(deal_id: str) -> str:
        """Plaintext fallback for the deal detail app surface."""

        async def _do() -> str:
            deal = await _fetch_deal_detail(deal_id)
            pipeline_stages = await _fetch_pipeline_stages_for_deal(deal)
            company_name = None
            if isinstance(deal, dict):
                company_name = await _fetch_company_name(deal.get("company_id"))
            return render_deal_detail_text_fallback(
                deal=deal,
                deal_id=deal_id,
                pipeline_stages=pipeline_stages,
                company_name=company_name,
            )

        return await cached_render(
            cache_prefix="deal_detail_text",
            key_suffix=f"{deal_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ----------------------------------------------------------------------
    # Surface #25 - Contact detail (per-contact drilldown).
    # URI-templated by contact_id. Enriches the base contact profile
    # with linked deals, open tasks, and recent notes - the full
    # "tell me everything about THIS person" view. Best-effort related
    # fetches so the surface always renders even if one sidecar fails.
    # ----------------------------------------------------------------------

    async def _fetch_contact_detail(contact_id: str) -> dict | None:
        """Load the contact profile, or None on 404 / backend error.

        Envelope: `{data: {id, first_name, last_name, full_name,
        work_email, job_title, seniority_level, company: {...}, ...}}`.
        """
        try:
            raw = await client.get(f"/contacts/{contact_id}")
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://contacts/%s backend error %s: %s",
                contact_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001 - defensive: never break the render
            return None

        if not isinstance(raw, dict):
            return None
        data = raw.get("data", raw)
        return data if isinstance(data, dict) else None

    async def _fetch_contact_deals(contact_id: str) -> list[dict]:
        """Best-effort linked-deals fetch; [] on failure."""
        try:
            raw = await client.get(f"/contacts/{contact_id}/deals")
        except G8ClientError:
            return []
        except Exception:  # noqa: BLE001
            return []

        if not isinstance(raw, dict):
            return []
        data = raw.get("data", raw)
        if not isinstance(data, list):
            return []
        return [d for d in data if isinstance(d, dict)]

    async def _fetch_contact_tasks(contact_id: str) -> list[dict]:
        """Best-effort linked-tasks fetch; [] on failure."""
        try:
            raw = await client.get(f"/contacts/{contact_id}/tasks")
        except G8ClientError:
            return []
        except Exception:  # noqa: BLE001
            return []

        if not isinstance(raw, dict):
            return []
        data = raw.get("data", raw)
        if not isinstance(data, list):
            return []
        return [t for t in data if isinstance(t, dict)]

    async def _fetch_contact_notes(contact_id: str) -> list[dict]:
        """Best-effort linked-notes fetch; [] on failure."""
        try:
            raw = await client.get(f"/contacts/{contact_id}/notes")
        except G8ClientError:
            return []
        except Exception:  # noqa: BLE001
            return []

        if not isinstance(raw, dict):
            return []
        data = raw.get("data", raw)
        if not isinstance(data, list):
            return []
        return [n for n in data if isinstance(n, dict)]

    @server.resource(
        "g8://contacts/{contact_id}",
        mime_type="text/html",
        description=(
            "Single-contact drilldown - profile header with seniority "
            "badge, stat-card grid (confidence, linked deals count, "
            "open tasks, notes), profile section (role + department + "
            "company + location), contact methods (work email, phones, "
            "social chips: LinkedIn / Twitter / Facebook), about blurb, "
            "linked deals list, open tasks list with priority badges, "
            "recent notes. The full 'who is this person' view. "
            "URI-templated by contact_id. Renders inline in Claude.ai; "
            "other clients fall back to the sibling .txt resource."
        ),
    )
    async def contact_detail_html(contact_id: str) -> str:
        """HTML app surface - single contact drilldown."""

        async def _do() -> str:
            contact = await _fetch_contact_detail(contact_id)
            if not isinstance(contact, dict):
                return render_contact_detail_html(
                    contact=None, contact_id=contact_id
                )
            deals = await _fetch_contact_deals(contact_id)
            tasks = await _fetch_contact_tasks(contact_id)
            notes = await _fetch_contact_notes(contact_id)
            return render_contact_detail_html(
                contact=contact,
                contact_id=contact_id,
                deals=deals,
                tasks=tasks,
                notes=notes,
            )

        return await cached_render(
            cache_prefix="contact_detail_html",
            key_suffix=f"{contact_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://contacts/{contact_id}.txt",
        mime_type="text/plain",
        description="Plain-text single-contact drilldown for clients without HTML.",
    )
    async def contact_detail_text(contact_id: str) -> str:
        """Plaintext fallback for the contact detail app surface."""

        async def _do() -> str:
            contact = await _fetch_contact_detail(contact_id)
            if not isinstance(contact, dict):
                return render_contact_detail_text_fallback(
                    contact=None, contact_id=contact_id
                )
            deals = await _fetch_contact_deals(contact_id)
            tasks = await _fetch_contact_tasks(contact_id)
            notes = await _fetch_contact_notes(contact_id)
            return render_contact_detail_text_fallback(
                contact=contact,
                contact_id=contact_id,
                deals=deals,
                tasks=tasks,
                notes=notes,
            )

        return await cached_render(
            cache_prefix="contact_detail_text",
            key_suffix=f"{contact_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ----------------------------------------------------------------------
    # Surface #26 - Company detail (per-company drilldown).
    # URI-templated by company_id. Completes the CRM entity triad with
    # surface #25 (contact detail) and surface #24 (deal detail).
    # Enriches the base company profile with linked contacts and deals.
    # Best-effort related fetches so the surface always renders even if
    # one sidecar fails.
    # ----------------------------------------------------------------------

    async def _fetch_company_detail(company_id: str) -> dict | None:
        """Load the company profile, or None on 404 / backend error."""
        try:
            raw = await client.get(f"/companies/{company_id}")
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://companies/%s backend error %s: %s",
                company_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001 - defensive: never break the render
            return None

        if not isinstance(raw, dict):
            return None
        data = raw.get("data", raw)
        return data if isinstance(data, dict) else None

    async def _fetch_company_contacts(company_id: str) -> list[dict]:
        """Best-effort contacts-at-company fetch; [] on failure."""
        try:
            raw = await client.get(f"/companies/{company_id}/contacts")
        except G8ClientError:
            return []
        except Exception:  # noqa: BLE001
            return []

        if not isinstance(raw, dict):
            return []
        data = raw.get("data", raw)
        if not isinstance(data, list):
            return []
        return [c for c in data if isinstance(c, dict)]

    async def _fetch_company_deals(company_id: str) -> list[dict]:
        """Best-effort deals-at-company fetch; [] on failure."""
        try:
            raw = await client.get(f"/companies/{company_id}/deals")
        except G8ClientError:
            return []
        except Exception:  # noqa: BLE001
            return []

        if not isinstance(raw, dict):
            return []
        data = raw.get("data", raw)
        if not isinstance(data, list):
            return []
        return [d for d in data if isinstance(d, dict)]

    @server.resource(
        "g8://companies/{company_id}",
        mime_type="text/html",
        description=(
            "Single-company drilldown - logo + derived size badge "
            "(solo/small/mid/large/enterprise from employee_count), "
            "stat-card grid (employees, revenue, founded year, contacts, "
            "open deals), overview section (industry, location, address, "
            "phone, LinkedIn followers), web presence (domain + website + "
            "LinkedIn/Twitter/Facebook/Crunchbase chips), description, "
            "linked contacts list, linked deals list. Completes the CRM "
            "triad with g8://contacts/{contact_id} and g8://deals/{deal_id}. "
            "URI-templated by company_id. Renders inline in Claude.ai; "
            "other clients fall back to the sibling .txt resource."
        ),
    )
    async def company_detail_html(company_id: str) -> str:
        """HTML app surface - single company drilldown."""

        async def _do() -> str:
            company = await _fetch_company_detail(company_id)
            if not isinstance(company, dict):
                return render_company_detail_html(
                    company=None, company_id=company_id
                )
            contacts = await _fetch_company_contacts(company_id)
            deals = await _fetch_company_deals(company_id)
            return render_company_detail_html(
                company=company,
                company_id=company_id,
                contacts=contacts,
                deals=deals,
            )

        return await cached_render(
            cache_prefix="company_detail_html",
            key_suffix=f"{company_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://companies/{company_id}.txt",
        mime_type="text/plain",
        description="Plain-text single-company drilldown for clients without HTML.",
    )
    async def company_detail_text(company_id: str) -> str:
        """Plaintext fallback for the company detail app surface."""

        async def _do() -> str:
            company = await _fetch_company_detail(company_id)
            if not isinstance(company, dict):
                return render_company_detail_text_fallback(
                    company=None, company_id=company_id
                )
            contacts = await _fetch_company_contacts(company_id)
            deals = await _fetch_company_deals(company_id)
            return render_company_detail_text_fallback(
                company=company,
                company_id=company_id,
                contacts=contacts,
                deals=deals,
            )

        return await cached_render(
            cache_prefix="company_detail_text",
            key_suffix=f"{company_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ----------------------------------------------------------------------
    # Surface #27 - Campaign detail (per-campaign top-level overview)
    # ----------------------------------------------------------------------
    # URI-templated by campaign_id. Complements surface #6 (campaigns
    # dashboard, org-wide list), surface #21 (per-campaign documents),
    # and surface #22 (per-campaign sequence plan). Answers "what is THIS
    # campaign about at a glance" - status, narrative, channels,
    # document coverage - then points at the children for the deep dives.
    #
    # We keep the URI suffix `/overview` rather than bare
    # `g8://campaigns/{campaign_id}` to avoid any ambiguity with the
    # existing static org-scoped `g8://campaigns/dashboard` +
    # `g8://campaigns/ideas` resources. Consistent with the existing
    # child URIs (`/documents`, `/sequence`).
    # ----------------------------------------------------------------------

    async def _fetch_campaign_detail(campaign_id: str) -> dict | None:
        """Load the campaign profile, or None on 404 / backend error."""
        try:
            raw = await client.get(f"/campaigns/{campaign_id}")
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://campaigns/%s/overview backend error %s: %s",
                campaign_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001 - defensive: never break the render
            return None

        if not isinstance(raw, dict):
            return None
        data = raw.get("data", raw)
        return data if isinstance(data, dict) else None

    async def _fetch_campaign_documents_for_detail(campaign_id: str) -> list[dict]:
        """Best-effort documents-for-campaign fetch; [] on failure.

        Only `status` is consumed by the detail renderer (for the
        per-bucket tally). The full document listing lives in
        surface #21 - here we just aggregate counts for the overview
        stat card.
        """
        try:
            raw = await client.get(f"/campaigns/{campaign_id}/documents")
        except G8ClientError:
            return []
        except Exception:  # noqa: BLE001
            return []

        if not isinstance(raw, dict):
            return []
        data = raw.get("data", raw)
        if isinstance(data, list):
            return [d for d in data if isinstance(d, dict)]
        if isinstance(data, dict):
            items = data.get("documents") or data.get("items") or data.get("data")
            if isinstance(items, list):
                return [d for d in items if isinstance(d, dict)]
        return []

    @server.resource(
        "g8://campaigns/{campaign_id}/overview",
        mime_type="text/html",
        description=(
            "Campaign top-level overview - status + category + goal + "
            "target persona + channel mix + narrative (brief / core "
            "concept / primary hook) + per-status document tally for "
            "ONE campaign. Answers 'what is this campaign about at a "
            "glance, and how is it going?'. Complements g8://campaigns/"
            "dashboard (org-wide list), g8://campaigns/{campaign_id}/"
            "documents (full doc library), and g8://campaigns/{campaign_id}/"
            "sequence (step design). URI-templated by campaign_id. "
            "Renders inline in Claude.ai; other clients fall back to the "
            "sibling .txt resource."
        ),
    )
    async def campaign_detail_html(campaign_id: str) -> str:
        """HTML app surface - per-campaign top-level overview."""

        async def _do() -> str:
            campaign = await _fetch_campaign_detail(campaign_id)
            if not isinstance(campaign, dict):
                return render_campaign_detail_html(
                    campaign=None, campaign_id=campaign_id
                )
            documents = await _fetch_campaign_documents_for_detail(campaign_id)
            return render_campaign_detail_html(
                campaign=campaign,
                campaign_id=campaign_id,
                documents=documents,
            )

        return await cached_render(
            cache_prefix="campaign_detail_html",
            key_suffix=f"{campaign_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://campaigns/{campaign_id}/overview.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the campaign top-level overview. "
            "Mirrors the HTML layout (overview → channels → narrative → "
            "documents → drill-down pointers) as markdown. Use this when "
            "your client can't render inline HTML."
        ),
    )
    async def campaign_detail_text(campaign_id: str) -> str:
        """Plaintext app surface - per-campaign top-level overview."""

        async def _do() -> str:
            campaign = await _fetch_campaign_detail(campaign_id)
            if not isinstance(campaign, dict):
                return render_campaign_detail_text_fallback(
                    campaign=None, campaign_id=campaign_id
                )
            documents = await _fetch_campaign_documents_for_detail(campaign_id)
            return render_campaign_detail_text_fallback(
                campaign=campaign,
                campaign_id=campaign_id,
                documents=documents,
            )

        return await cached_render(
            cache_prefix="campaign_detail_text",
            key_suffix=f"{campaign_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Audience sync config detail - app surface #28.                      #
    # Per-config overview (platform + audience + cadence + mode + status) #
    # plus last N runs, with drill-down to full runs history (#18).       #
    # ------------------------------------------------------------------ #

    async def _fetch_audience_sync_detail(config_id: str) -> dict | None:
        """Fetch sync config detail, or None on 404 / other failures."""
        try:
            raw = await client.get(f"/audience-syncs/{config_id}")
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://audience-syncs/%s backend error %s: %s",
                config_id,
                e.status_code,
                e,
            )
            return None

        if not isinstance(raw, dict):
            return None
        data = raw.get("data", raw)
        if isinstance(data, dict):
            return data
        return None

    async def _fetch_audience_sync_recent_runs(config_id: str) -> list[dict]:
        """Fetch recent runs (best-effort, [] on any failure)."""
        try:
            raw = await client.get(
                f"/audience-syncs/{config_id}/runs", {"limit": 20}
            )
        except G8ClientError:
            return []

        if isinstance(raw, list):
            return [r for r in raw if isinstance(r, dict)]
        if isinstance(raw, dict):
            items = raw.get("runs")
            if not isinstance(items, list):
                items = raw.get("data")
            if isinstance(items, list):
                return [r for r in items if isinstance(r, dict)]
        return []

    @server.resource(
        "g8://audience-syncs/{config_id}/overview",
        mime_type="text/html",
        description=(
            "Audience sync config detail - platform + audience id + "
            "refresh cadence + mode (mirror/append-only) + active-state + "
            "last-sync timestamp for a SINGLE sync configuration, plus the "
            "most recent 5 runs with status badges and member deltas. "
            "Complements g8://audience-syncs (dashboard) and "
            "g8://audience-syncs/{config_id}/runs (full run history). "
            "URI-templated by config_id. The explicit /overview suffix "
            "disambiguates from the sibling /runs child and prevents "
            "collision with the .txt fallback. Renders inline in "
            "Claude.ai; other clients fall back to the sibling .txt resource."
        ),
    )
    async def audience_sync_detail_html(config_id: str) -> str:
        """HTML app surface - per-config audience sync detail."""

        async def _do() -> str:
            config = await _fetch_audience_sync_detail(config_id)
            if not isinstance(config, dict):
                return render_audience_sync_detail_html(
                    config=None, config_id=config_id
                )
            runs = await _fetch_audience_sync_recent_runs(config_id)
            return render_audience_sync_detail_html(
                config=config,
                config_id=config_id,
                runs=runs,
            )

        return await cached_render(
            cache_prefix="audience_sync_detail_html",
            key_suffix=f"{config_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://audience-syncs/{config_id}/overview.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the audience sync config detail. "
            "Mirrors the HTML layout (overview \u2192 recent runs \u2192 "
            "drill-down pointers) as markdown. Use this when your client "
            "can't render inline HTML."
        ),
    )
    async def audience_sync_detail_text(config_id: str) -> str:
        """Plaintext app surface - per-config audience sync detail."""

        async def _do() -> str:
            config = await _fetch_audience_sync_detail(config_id)
            if not isinstance(config, dict):
                return render_audience_sync_detail_text_fallback(
                    config=None, config_id=config_id
                )
            runs = await _fetch_audience_sync_recent_runs(config_id)
            return render_audience_sync_detail_text_fallback(
                config=config,
                config_id=config_id,
                runs=runs,
            )

        return await cached_render(
            cache_prefix="audience_sync_detail_text",
            key_suffix=f"{config_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Sequence detail - app surface #29.                                  #
    # Top-level overview for a single sequence (name / description /      #
    # owner / status / associated list / behavior flags / timestamps +    #
    # best-effort contact-state breakdown). Complements:                  #
    #   - g8://sequences/{sequence_id}/preview    (step structure)        #
    #   - g8://sequences/{sequence_id}/analytics  (performance)           #
    #   - g8://sequences/dashboard                (org-wide list)         #
    # ------------------------------------------------------------------ #

    async def _fetch_sequence_detail(sequence_id: str) -> dict | None:
        """Fetch sequence detail, or None on 404 / other failures."""
        try:
            raw = await client.get(f"/sequences/{sequence_id}")
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://sequences/%s/overview backend error %s: %s",
                sequence_id,
                e.status_code,
                e,
            )
            return None

        if not isinstance(raw, dict):
            return None
        data = raw.get("data", raw)
        if isinstance(data, dict):
            return data
        return None

    async def _fetch_sequence_contacts_for_detail(sequence_id: str) -> list[dict]:
        """Fetch sequence contacts for state tally (best-effort, [] on failure).

        Uses a larger page limit than the default so the state breakdown
        reflects the true distribution for medium-sized sequences.
        Failures (including non-2xx) return [] - the renderer handles
        None/[] gracefully by omitting the contacts section.
        """
        try:
            raw = await client.get(
                f"/sequences/{sequence_id}/contacts",
                {"limit": 200},
            )
        except G8ClientError:
            return []

        if isinstance(raw, list):
            return [c for c in raw if isinstance(c, dict)]
        if isinstance(raw, dict):
            items = raw.get("data")
            if not isinstance(items, list):
                items = raw.get("contacts")
            if isinstance(items, list):
                return [c for c in items if isinstance(c, dict)]
        return []

    @server.resource(
        "g8://sequences/{sequence_id}/overview",
        mime_type="text/html",
        description=(
            "Sequence top-level overview \u2014 name + description + "
            "status + owner (user_email) + associated list + behavior "
            "flags (finish-on-reply, same-thread, wait-for-new-contacts) "
            "+ lifecycle timestamps (created/updated/paused/resumed) + "
            "best-effort contact-state breakdown. Complements "
            "g8://sequences/{sequence_id}/preview (step structure) and "
            "g8://sequences/{sequence_id}/analytics (performance). "
            "URI-templated by sequence_id. The explicit /overview suffix "
            "disambiguates from siblings /preview and /analytics and "
            "prevents collision with the .txt fallback. Renders inline "
            "in Claude.ai; other clients fall back to the sibling .txt resource."
        ),
    )
    async def sequence_detail_html(sequence_id: str) -> str:
        """HTML app surface - per-sequence top-level overview."""

        async def _do() -> str:
            sequence = await _fetch_sequence_detail(sequence_id)
            if not isinstance(sequence, dict):
                return render_sequence_detail_html(
                    sequence=None, sequence_id=sequence_id
                )
            contacts = await _fetch_sequence_contacts_for_detail(sequence_id)
            return render_sequence_detail_html(
                sequence=sequence,
                sequence_id=sequence_id,
                contacts=contacts,
            )

        return await cached_render(
            cache_prefix="sequence_detail_html",
            key_suffix=f"{sequence_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://sequences/{sequence_id}/overview.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the sequence top-level overview. "
            "Mirrors the HTML layout (description \u2192 overview \u2192 "
            "behavior \u2192 contacts \u2192 drill-down pointers) as "
            "markdown. Use this when your client can't render inline HTML."
        ),
    )
    async def sequence_detail_text(sequence_id: str) -> str:
        """Plaintext app surface - per-sequence top-level overview."""

        async def _do() -> str:
            sequence = await _fetch_sequence_detail(sequence_id)
            if not isinstance(sequence, dict):
                return render_sequence_detail_text_fallback(
                    sequence=None, sequence_id=sequence_id
                )
            contacts = await _fetch_sequence_contacts_for_detail(sequence_id)
            return render_sequence_detail_text_fallback(
                sequence=sequence,
                sequence_id=sequence_id,
                contacts=contacts,
            )

        return await cached_render(
            cache_prefix="sequence_detail_text",
            key_suffix=f"{sequence_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Campaign document detail - app surface #30.                         #
    # Per-document overview (status, type, version, content preview) for #
    # a single Studio doc inside a campaign. Complements #21 (per-       #
    # campaign document library) and #27 (campaign top-level overview). #
    # ------------------------------------------------------------------ #

    async def _fetch_campaign_document_detail(
        campaign_id: str, document_id: str
    ) -> dict | None:
        """Fetch a single campaign document, or None on 404 / other failures.

        Hits `GET /campaigns/{campaign_id}/documents/{document_id}`. Returns
        None on 404 so the renderer can drop to its empty-state card; logs
        other backend errors once and returns None so the surface never
        raises.
        """
        try:
            raw = await client.get(
                f"/campaigns/{campaign_id}/documents/{document_id}"
            )
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://campaigns/%s/documents/%s backend error %s: %s",
                campaign_id,
                document_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001 - defensive: never break the render
            return None

        if not isinstance(raw, dict):
            return None
        data = raw.get("data", raw)
        return data if isinstance(data, dict) else None

    @server.resource(
        "g8://campaigns/{campaign_id}/documents/{document_id}/overview",
        mime_type="text/html",
        description=(
            "Campaign document detail - per-document overview for ONE "
            "Studio doc: status badge, type badge, version, content "
            "preview (capped ~4k chars), word/character counts, and a "
            "drill-up hint to the campaign's document library and "
            "top-level overview. Answers 'what's inside this specific "
            "document?' without leaving MCP. URI-templated by campaign_id "
            "and document_id. Renders inline in Claude.ai; other clients "
            "fall back to the sibling .txt resource."
        ),
    )
    async def campaign_document_detail_html(
        campaign_id: str, document_id: str
    ) -> str:
        """HTML app surface - per-document overview for a campaign doc."""

        async def _do() -> str:
            document = await _fetch_campaign_document_detail(
                campaign_id, document_id
            )
            return render_campaign_document_detail_html(
                document=document,
                campaign_id=campaign_id,
                document_id=document_id,
            )

        return await cached_render(
            cache_prefix="campaign_document_detail_html",
            key_suffix=f"{campaign_id}:{document_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://campaigns/{campaign_id}/documents/{document_id}/overview.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the campaign document detail surface. "
            "Mirrors the HTML layout (metadata \u2192 content summary "
            "\u2192 content preview \u2192 drill-up pointers) as markdown. "
            "Use this when your client can't render inline HTML."
        ),
    )
    async def campaign_document_detail_text(
        campaign_id: str, document_id: str
    ) -> str:
        """Plaintext app surface - per-document overview for a campaign doc."""

        async def _do() -> str:
            document = await _fetch_campaign_document_detail(
                campaign_id, document_id
            )
            return render_campaign_document_detail_text_fallback(
                document=document,
                campaign_id=campaign_id,
                document_id=document_id,
            )

        return await cached_render(
            cache_prefix="campaign_document_detail_text",
            key_suffix=f"{campaign_id}:{document_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #31 - per-webhook detail (status, events, recent deliveries).
    # Pairs `GET /webhooks/{webhook_id}` (subscription metadata) with a  #
    # best-effort `GET /webhooks/{webhook_id}/deliveries` call so the    #
    # HTML renderer can show a success/failure mix and tally - the      #
    # single question an operator asks after "is this webhook on?":     #
    # "is it actually firing?"                                          #
    # ------------------------------------------------------------------ #

    async def _fetch_webhook_detail(webhook_id: str) -> dict | None:
        """Fetch a webhook subscription, or None on 404 / other failures."""
        try:
            raw = await client.get(f"/webhooks/{webhook_id}")
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://webhooks/%s backend error %s: %s",
                webhook_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001 - defensive: never break the render
            return None

        if not isinstance(raw, dict):
            return None
        data = raw.get("data", raw)
        return data if isinstance(data, dict) else None

    async def _fetch_webhook_deliveries(webhook_id: str) -> list | None:
        """Best-effort deliveries fetch - returns None on any failure.

        The renderer treats None as "no delivery section" and still shows
        the overview. That way a missing /deliveries endpoint (older
        backends) or a transient 5xx doesn't blow up the whole surface.
        """
        try:
            raw = await client.get(f"/webhooks/{webhook_id}/deliveries")
        except G8ClientError as e:
            if e.status_code in (404, 405, 501):
                return None
            logger.warning(
                "g8://webhooks/%s/deliveries backend error %s: %s",
                webhook_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        if isinstance(raw, list):
            return raw
        if isinstance(raw, dict):
            for key in ("deliveries", "data", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    return val
        return None

    @server.resource(
        "g8://webhooks/{webhook_id}/overview",
        mime_type="text/html",
        description=(
            "Webhook detail - per-subscription overview for ONE webhook: "
            "active/paused status, target URL, subscribed event types, "
            "and up to 10 recent deliveries with HTTP status codes, "
            "attempt counts, error snippets, and a success-rate tally. "
            "Answers 'is this webhook actually firing?' without leaving "
            "MCP. URI-templated by webhook_id. Renders inline in "
            "Claude.ai; other clients fall back to the sibling .txt "
            "resource."
        ),
    )
    async def webhook_detail_html(webhook_id: str) -> str:
        """HTML app surface - per-webhook overview + recent deliveries."""

        async def _do() -> str:
            webhook = await _fetch_webhook_detail(webhook_id)
            deliveries = (
                await _fetch_webhook_deliveries(webhook_id) if webhook else None
            )
            return render_webhook_detail_html(
                webhook=webhook,
                webhook_id=webhook_id,
                deliveries=deliveries,
            )

        return await cached_render(
            cache_prefix="webhook_detail_html",
            key_suffix=f"{webhook_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://webhooks/{webhook_id}/overview.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the webhook detail surface. Mirrors "
            "the HTML layout (metadata \u2192 events \u2192 recent "
            "deliveries \u2192 drill-up pointers) as markdown. Use this "
            "when your client can't render inline HTML."
        ),
    )
    async def webhook_detail_text(webhook_id: str) -> str:
        """Plaintext app surface - per-webhook overview + deliveries."""

        async def _do() -> str:
            webhook = await _fetch_webhook_detail(webhook_id)
            deliveries = (
                await _fetch_webhook_deliveries(webhook_id) if webhook else None
            )
            return render_webhook_detail_text_fallback(
                webhook=webhook,
                webhook_id=webhook_id,
                deliveries=deliveries,
            )

        return await cached_render(
            cache_prefix="webhook_detail_text",
            key_suffix=f"{webhook_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #39 - webhook deliveries (per-webhook history). Drills     #
    # down from surface #31 (webhook overview - only shows 10 recent)    #
    # and answers the next question after "is it firing?": "WHY did     #
    # delivery X fail?" - renders up to 40 delivery attempts with      #
    # event code chip, HTTP response code, attempts counter, error      #
    # snippet, duration, and success-rate tally.                        #
    # URI: `g8://webhooks/{webhook_id}/deliveries` - disambiguated      #
    # from the `/overview` sibling by the trailing path segment.        #
    # Reuses `_fetch_webhook_detail` + `_fetch_webhook_deliveries`      #
    # helpers from surface #31 above.                                   #
    # ------------------------------------------------------------------ #

    @server.resource(
        "g8://webhooks/{webhook_id}/deliveries",
        mime_type="text/html",
        description=(
            "Webhook deliveries - per-subscription delivery history for "
            "ONE webhook. Shows total attempts, success/failure tally, "
            "pending/retrying counts, status mix and event mix as pill "
            "chips, and up to 40 recent delivery rows with event code, "
            "HTTP response code badge (2xx green / 4xx amber / 5xx red), "
            "attempts counter (warning-tinted at max), error snippet, "
            "timestamps, and duration. Empty-state covers both "
            "missing-webhook (\"deliveries not available\") and "
            "zero-deliveries (\"no attempts yet\"). URI-templated by "
            "webhook_id. Renders inline in Claude.ai; other clients fall "
            "back to the sibling .txt resource. Complements "
            "g8://webhooks/{webhook_id}/overview which shows the webhook "
            "metadata + a small recent-deliveries preview."
        ),
    )
    async def webhook_deliveries_html(webhook_id: str) -> str:
        """HTML app surface - per-webhook delivery history."""

        async def _do() -> str:
            deliveries = await _fetch_webhook_deliveries(webhook_id)
            webhook = (
                await _fetch_webhook_detail(webhook_id)
                if deliveries is not None and deliveries
                else None
            )
            return render_webhook_deliveries_html(
                deliveries=deliveries,
                webhook_id=webhook_id,
                webhook=webhook,
            )

        return await cached_render(
            cache_prefix="webhook_deliveries_html",
            key_suffix=f"{webhook_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://webhooks/{webhook_id}/deliveries.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the webhook-deliveries surface. "
            "Mirrors the HTML layout (stats \u2192 status mix \u2192 "
            "event mix \u2192 delivery rows \u2192 drill-up pointers) "
            "as markdown. Use this when your client can't render inline "
            "HTML."
        ),
    )
    async def webhook_deliveries_text(webhook_id: str) -> str:
        """Plaintext app surface - per-webhook delivery history."""

        async def _do() -> str:
            deliveries = await _fetch_webhook_deliveries(webhook_id)
            webhook = (
                await _fetch_webhook_detail(webhook_id)
                if deliveries is not None and deliveries
                else None
            )
            return render_webhook_deliveries_text_fallback(
                deliveries=deliveries,
                webhook_id=webhook_id,
                webhook=webhook,
            )

        return await cached_render(
            cache_prefix="webhook_deliveries_text",
            key_suffix=f"{webhook_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #32 - per-repo detail (scan status + install status +      #
    # metadata). Complements the existing JSON resources for repo lists #
    # by answering: "for THIS repo, can I scan it? is it installed?     #
    # what's the write_key?" - without leaking the full credential.     #
    # ------------------------------------------------------------------ #

    async def _fetch_repo_detail(repo_id: str) -> dict | None:
        """Fetch a repo record, or None on 404 / other failures."""
        try:
            raw = await client.get(f"/repos/{repo_id}")
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://repos/%s backend error %s: %s",
                repo_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001 - defensive: never break the render
            return None

        if not isinstance(raw, dict):
            return None
        data = raw.get("data", raw)
        return data if isinstance(data, dict) else None

    @server.resource(
        "g8://repos/{repo_id}/overview",
        mime_type="text/html",
        description=(
            "Repo detail - per-repository overview for ONE repo: scan "
            "status (ready/scanning/failed/...), install status "
            "(installed/pending/...), provider (github/gitlab/...), "
            "default branch, project_id, and a MASKED write_key "
            "(first 4 + last 2 only - never the full credential). "
            "Context cards explain what each status means so operators "
            "know whether the repo is ready to scan, install, or "
            "needs intervention. URI-templated by repo_id. Renders "
            "inline in Claude.ai; other clients fall back to the "
            "sibling .txt resource."
        ),
    )
    async def repo_detail_html(repo_id: str) -> str:
        """HTML app surface - per-repo scan/install overview."""

        async def _do() -> str:
            repo = await _fetch_repo_detail(repo_id)
            return render_repo_detail_html(repo=repo, repo_id=repo_id)

        return await cached_render(
            cache_prefix="repo_detail_html",
            key_suffix=f"{repo_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://repos/{repo_id}/overview.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the repo detail surface. Mirrors "
            "the HTML layout (stats \u2192 overview \u2192 what each "
            "status means \u2192 drill-up pointers) as markdown. Use "
            "this when your client can't render inline HTML. "
            "write_key is masked the same way as the HTML surface."
        ),
    )
    async def repo_detail_text(repo_id: str) -> str:
        """Plaintext app surface - per-repo scan/install overview."""

        async def _do() -> str:
            repo = await _fetch_repo_detail(repo_id)
            return render_repo_detail_text_fallback(
                repo=repo, repo_id=repo_id
            )

        return await cached_render(
            cache_prefix="repo_detail_text",
            key_suffix=f"{repo_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #33 - per-config audience-sync errors (why are we failing?)#
    # Pairs `GET /audience-syncs/{config_id}/errors` with a best-effort #
    # `GET /audience-syncs/{config_id}` so the renderer can show a     #
    # friendly sync label in the header.                               #
    # ------------------------------------------------------------------ #

    async def _fetch_sync_errors(config_id: str) -> list[dict] | None:
        """Fetch failure rows for a sync config, or None on 404.

        The backend dev API returns up to `limit` failures (default 20,
        max 100). We ask for the max so the renderer can show a
        meaningful "+ N older" overflow note without ever missing
        the most recent failures.
        """
        try:
            raw = await client.get(
                f"/audience-syncs/{config_id}/errors", {"limit": 100}
            )
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://audience-syncs/%s/errors backend error %s: %s",
                config_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001 - defensive
            return None

        if isinstance(raw, list):
            return raw
        if isinstance(raw, dict):
            for key in ("errors", "data", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    return val
        return None

    async def _fetch_sync_config_for_errors(config_id: str) -> dict | None:
        """Best-effort sync-config lookup for the header label.

        Returns None on any failure (404/etc). The renderer tolerates
        None - it just falls back to a generic "Audience sync" label.
        """
        try:
            raw = await client.get(f"/audience-syncs/{config_id}")
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://audience-syncs/%s label fetch error %s: %s",
                config_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None
        if not isinstance(raw, dict):
            return None
        data = raw.get("data", raw)
        return data if isinstance(data, dict) else None

    @server.resource(
        "g8://audience-syncs/{config_id}/errors",
        mime_type="text/html",
        description=(
            "Audience-sync errors - per-config failure list for ONE "
            "sync config. Grouped error messages (count + %) + "
            "timeline of recent failures with timestamp + message + "
            "id. Header shows derived sync label (from config) and "
            "total failure count. Empty-state covers both missing-"
            "config (\"errors not available\") and zero-failures "
            "(\"no recent failures - great!\"). URI-templated by "
            "config_id. Renders inline in Claude.ai; other clients "
            "fall back to the sibling .txt resource."
        ),
    )
    async def sync_errors_html(config_id: str) -> str:
        """HTML app surface - per-config sync failures + grouping."""

        async def _do() -> str:
            errors = await _fetch_sync_errors(config_id)
            config = (
                await _fetch_sync_config_for_errors(config_id)
                if errors is not None and errors
                else None
            )
            return render_sync_errors_html(
                errors=errors, config_id=config_id, config=config
            )

        return await cached_render(
            cache_prefix="sync_errors_html",
            key_suffix=f"{config_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://audience-syncs/{config_id}/errors.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the audience-sync errors surface. "
            "Mirrors the HTML layout (stats \u2192 error groups \u2192 "
            "recent failures \u2192 drill-up pointers) as markdown. "
            "Use this when your client can't render inline HTML."
        ),
    )
    async def sync_errors_text(config_id: str) -> str:
        """Plaintext app surface - per-config sync failures + grouping."""

        async def _do() -> str:
            errors = await _fetch_sync_errors(config_id)
            config = (
                await _fetch_sync_config_for_errors(config_id)
                if errors is not None and errors
                else None
            )
            return render_sync_errors_text_fallback(
                errors=errors, config_id=config_id, config=config
            )

        return await cached_render(
            cache_prefix="sync_errors_text",
            key_suffix=f"{config_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #34 - per-contact notes timeline (who said what, when)    #
    # Pairs `GET /contacts/{contact_id}/notes` (the notes list) with a  #
    # best-effort `GET /contacts/{contact_id}/detail` so the renderer   #
    # can derive a friendly header label ("Jane Doe - notes").          #
    # ------------------------------------------------------------------ #

    async def _fetch_contact_notes(contact_id: str) -> list[dict] | None:
        """Fetch the list of notes for a contact, or None on 404/error.

        Response shape: `{"notes": [...]}`. We unwrap to the list here
        so the renderer only sees a plain list (or None).
        """
        try:
            raw = await client.get(f"/contacts/{contact_id}/notes")
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://contacts/%s/notes backend error %s: %s",
                contact_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001 - defensive
            return None

        if isinstance(raw, list):
            return raw
        if isinstance(raw, dict):
            for key in ("notes", "data", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    return val
        return None

    async def _fetch_contact_for_notes(contact_id: str) -> dict | None:
        """Best-effort contact lookup for the header label.

        Returns None on any failure - renderer tolerates None and
        falls back to a generic "Contact" label.
        """
        try:
            raw = await client.get(f"/contacts/{contact_id}/detail")
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://contacts/%s detail fetch error %s: %s",
                contact_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None
        if not isinstance(raw, dict):
            return None
        data = raw.get("data", raw)
        return data if isinstance(data, dict) else None

    @server.resource(
        "g8://contacts/{contact_id}/notes",
        mime_type="text/html",
        description=(
            "Contact notes - per-contact note timeline for ONE contact. "
            "Shows total notes, unique authors, edit count, and last-"
            "note timestamp in a stat grid. Author breakdown section "
            "groups notes by created_by_name (count + %). Timeline lists "
            "the most recent notes with author, timestamp, edit badge, "
            "and full content. Empty-state covers both missing-contact "
            "(\"notes not available\") and zero-notes (\"no notes yet - "
            "add one\"). URI-templated by contact_id. Renders inline in "
            "Claude.ai; other clients fall back to the sibling .txt "
            "resource. Complements g8://contacts/{contact_id} which "
            "shows the full profile + activity dashboard."
        ),
    )
    async def contact_notes_html(contact_id: str) -> str:
        """HTML app surface - per-contact note timeline."""

        async def _do() -> str:
            notes = await _fetch_contact_notes(contact_id)
            contact = (
                await _fetch_contact_for_notes(contact_id)
                if notes is not None and notes
                else None
            )
            return render_contact_notes_html(
                notes=notes, contact_id=contact_id, contact=contact
            )

        return await cached_render(
            cache_prefix="contact_notes_html",
            key_suffix=f"{contact_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://contacts/{contact_id}/notes.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the contact-notes surface. Mirrors "
            "the HTML layout (stats \u2192 authors \u2192 recent notes "
            "\u2192 drill-up pointers) as markdown. Use this when your "
            "client can't render inline HTML."
        ),
    )
    async def contact_notes_text(contact_id: str) -> str:
        """Plaintext app surface - per-contact note timeline."""

        async def _do() -> str:
            notes = await _fetch_contact_notes(contact_id)
            contact = (
                await _fetch_contact_for_notes(contact_id)
                if notes is not None and notes
                else None
            )
            return render_contact_notes_text_fallback(
                notes=notes, contact_id=contact_id, contact=contact
            )

        return await cached_render(
            cache_prefix="contact_notes_text",
            key_suffix=f"{contact_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #35 - per-contact tasks (open work + due-date call-outs)  #
    # Pairs `GET /contacts/{contact_id}/tasks` (a LIST, not dict-       #
    # wrapped) with a best-effort `GET /contacts/{contact_id}/detail`   #
    # for the header label ("Jane Doe - tasks").                        #
    # ------------------------------------------------------------------ #

    async def _fetch_contact_tasks(contact_id: str) -> list[dict] | None:
        """Fetch the list of tasks for a contact, or None on 404/error.

        Backend handler returns a LIST directly (not wrapped). We
        tolerate dict-wrapped responses defensively in case that ever
        changes (matches the notes helper's tolerance).
        """
        try:
            raw = await client.get(f"/contacts/{contact_id}/tasks")
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://contacts/%s/tasks backend error %s: %s",
                contact_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001 - defensive
            return None

        if isinstance(raw, list):
            return raw
        if isinstance(raw, dict):
            for key in ("tasks", "data", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    return val
        return None

    async def _fetch_contact_for_tasks(contact_id: str) -> dict | None:
        """Best-effort contact lookup for the header label.

        Returns None on any failure - renderer tolerates None and
        falls back to a generic "Contact" label.
        """
        try:
            raw = await client.get(f"/contacts/{contact_id}/detail")
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://contacts/%s detail fetch error %s: %s",
                contact_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None
        if not isinstance(raw, dict):
            return None
        data = raw.get("data", raw)
        return data if isinstance(data, dict) else None

    @server.resource(
        "g8://contacts/{contact_id}/tasks",
        mime_type="text/html",
        description=(
            "Contact tasks - per-contact task timeline for ONE contact. "
            "Shows total / open / in-progress / overdue / due-today / "
            "done counts in a stat grid, plus status-bucket pills "
            "(Open / In progress / Done / Cancelled). Timeline lists "
            "the most-recent tasks with title, description, status pill, "
            "priority pill (High / Medium / Low - matches frontend "
            "task-card palette), due-date call-out (Overdue / Due today "
            "/ Tomorrow / future date), assignee, and task type. "
            "Empty-state covers both missing-contact (\"tasks not "
            "available\") and zero-tasks (\"no tasks yet - create one\"). "
            "URI-templated by contact_id. Renders inline in Claude.ai; "
            "other clients fall back to the sibling .txt resource. "
            "Complements g8://contacts/{contact_id} (full profile + "
            "activity) and g8://contacts/{contact_id}/notes (note "
            "timeline)."
        ),
    )
    async def contact_tasks_html(contact_id: str) -> str:
        """HTML app surface - per-contact task timeline."""

        async def _do() -> str:
            tasks = await _fetch_contact_tasks(contact_id)
            contact = (
                await _fetch_contact_for_tasks(contact_id)
                if tasks is not None and tasks
                else None
            )
            return render_contact_tasks_html(
                tasks=tasks, contact_id=contact_id, contact=contact
            )

        return await cached_render(
            cache_prefix="contact_tasks_html",
            key_suffix=f"{contact_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://contacts/{contact_id}/tasks.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the contact-tasks surface. Mirrors "
            "the HTML layout (stats \u2192 status counts \u2192 recent "
            "tasks \u2192 drill-up pointers) as markdown. Use this when "
            "your client can't render inline HTML."
        ),
    )
    async def contact_tasks_text(contact_id: str) -> str:
        """Plaintext app surface - per-contact task timeline."""

        async def _do() -> str:
            tasks = await _fetch_contact_tasks(contact_id)
            contact = (
                await _fetch_contact_for_tasks(contact_id)
                if tasks is not None and tasks
                else None
            )
            return render_contact_tasks_text_fallback(
                tasks=tasks, contact_id=contact_id, contact=contact
            )

        return await cached_render(
            cache_prefix="contact_tasks_text",
            key_suffix=f"{contact_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #36 - enrichment job detail (waterfall progress + cost)   #
    # `GET /enrichment/jobs/{job_id}` returns a single job dict with    #
    # status, progress counters, provider sequence, and credit cost.    #
    # 404 → None → "not available" empty state. No companion fetch     #
    # needed (the response carries everything for the header).         #
    # ------------------------------------------------------------------ #

    async def _fetch_enrichment_job(job_id: str) -> dict | None:
        """Fetch the enrichment job, or None on 404/error."""
        try:
            raw = await client.get(f"/enrichment/jobs/{job_id}")
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://enrichment/jobs/%s backend error %s: %s",
                job_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None
        if isinstance(raw, dict):
            # Some endpoints wrap in {data: {...}} - unwrap defensively
            inner = raw.get("data")
            if isinstance(inner, dict):
                return inner
            return raw
        return None

    @server.resource(
        "g8://enrichment/jobs/{job_id}",
        mime_type="text/html",
        description=(
            "Enrichment job detail - full status of ONE enrichment job. "
            "Shows status pill (queued / processing / completed / failed "
            "/ cancelled), a progress bar with processed/total record "
            "counts, a 6-stat grid (total / processed / success / failed "
            "/ credits used / duration), the provider waterfall sequence "
            "as ordered chips (e.g. ZoomInfo → Apollo → Cognism), and a "
            "timestamps card (created / started / completed). Includes "
            "a success-rate sub-line over processed records when "
            "available, and color-codes the rate (green ≥70%, amber "
            "≥40%, red below). URI-templated by job_id. Renders inline "
            "in Claude.ai; other clients fall back to the sibling .txt "
            "resource. Empty state for 404 / missing job id."
        ),
    )
    async def enrichment_job_html(job_id: str) -> str:
        """HTML app surface - single enrichment job detail."""

        async def _do() -> str:
            job = await _fetch_enrichment_job(job_id)
            return render_enrichment_job_html(job=job, job_id=job_id)

        return await cached_render(
            cache_prefix="enrichment_job_html",
            key_suffix=f"{job_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://enrichment/jobs/{job_id}.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the enrichment-job-detail surface. "
            "Mirrors the HTML layout (status \u2192 stats \u2192 "
            "provider waterfall \u2192 timeline \u2192 drill-up "
            "pointers) as markdown. Use this when your client can't "
            "render inline HTML."
        ),
    )
    async def enrichment_job_text(job_id: str) -> str:
        """Plaintext app surface - single enrichment job detail."""

        async def _do() -> str:
            job = await _fetch_enrichment_job(job_id)
            return render_enrichment_job_text_fallback(
                job=job, job_id=job_id
            )

        return await cached_render(
            cache_prefix="enrichment_job_text",
            key_suffix=f"{job_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #37 - per-company notes timeline (who said what, when)    #
    # Mirror of surface #34 (contact notes) scoped to companies. Ships  #
    # with graph8 design tokens from the start - no AI-tell accent     #
    # borders, uniform shadcn Card/Badge patterns translated to inline #
    # CSS. Backend: GET /companies/{company_id}/notes (shape           #
    # `{"notes": [...]}`) + best-effort GET /companies/{company_id}    #
    # for header label (name > domain > "Company" fallback).           #
    # ------------------------------------------------------------------ #

    async def _fetch_company_notes(company_id: str) -> list[dict] | None:
        """Fetch the list of notes for a company, or None on 404/error.

        Response shape: `{"notes": [...]}`. Unwrap to the list here so
        the renderer only sees a plain list (or None).
        """
        try:
            raw = await client.get(f"/companies/{company_id}/notes")
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://companies/%s/notes backend error %s: %s",
                company_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001 - defensive
            return None

        if isinstance(raw, list):
            return raw
        if isinstance(raw, dict):
            for key in ("notes", "data", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    return val
        return None

    async def _fetch_company_for_notes(company_id: str) -> dict | None:
        """Best-effort company lookup for header label.

        Returns None on any failure - renderer tolerates None and falls
        back to a generic "Company" label.
        """
        try:
            raw = await client.get(f"/companies/{company_id}")
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://companies/%s fetch error %s: %s",
                company_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None
        if not isinstance(raw, dict):
            return None
        data = raw.get("data", raw)
        return data if isinstance(data, dict) else None

    @server.resource(
        "g8://companies/{company_id}/notes",
        mime_type="text/html",
        description=(
            "Company notes - per-company note timeline for ONE company. "
            "Shows total notes, unique authors, edit count, and last-"
            "note timestamp in a stat grid. Author breakdown section "
            "groups notes by created_by_name (count + %). Timeline lists "
            "the most recent notes with author, timestamp, edit badge, "
            "and full content. Empty-state covers both missing-company "
            "(\"notes not available\") and zero-notes (\"no notes yet - "
            "add one\"). URI-templated by company_id. Renders inline in "
            "Claude.ai; other clients fall back to the sibling .txt "
            "resource. Complements g8://companies/{company_id} which "
            "shows the full company profile + contacts + deals."
        ),
    )
    async def company_notes_html(company_id: str) -> str:
        """HTML app surface - per-company note timeline."""

        async def _do() -> str:
            notes = await _fetch_company_notes(company_id)
            company = (
                await _fetch_company_for_notes(company_id)
                if notes is not None and notes
                else None
            )
            return render_company_notes_html(
                notes=notes, company_id=company_id, company=company
            )

        return await cached_render(
            cache_prefix="company_notes_html",
            key_suffix=f"{company_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://companies/{company_id}/notes.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the company-notes surface. Mirrors "
            "the HTML layout (stats \u2192 authors \u2192 recent notes "
            "\u2192 drill-up pointers) as markdown. Use this when your "
            "client can't render inline HTML."
        ),
    )
    async def company_notes_text(company_id: str) -> str:
        """Plaintext app surface - per-company note timeline."""

        async def _do() -> str:
            notes = await _fetch_company_notes(company_id)
            company = (
                await _fetch_company_for_notes(company_id)
                if notes is not None and notes
                else None
            )
            return render_company_notes_text_fallback(
                notes=notes, company_id=company_id, company=company
            )

        return await cached_render(
            cache_prefix="company_notes_text",
            key_suffix=f"{company_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #38 - List members (contacts for a specific list/audience) #
    # Per-list drill that complements surface #8 (lists dashboard,       #
    # org-wide). Backend: GET /lists/{list_id}/contacts paginated.       #
    # Header label: best-effort match against GET /lists to find title.  #
    # Born graph8-native: #7d2df3 primary, #dfdfdf border, Aeonik font.  #
    # URI is `g8://lists/{list_id}/contacts` - disambiguated from the    #
    # org-wide `g8://lists/dashboard` by the trailing path segment.      #
    # ------------------------------------------------------------------ #

    async def _fetch_list_members(list_id: str) -> list[dict] | None:
        """Fetch the first page of contacts for a list, or None on 404/error.

        Uses the default page size (50) - the renderer caps the rendered
        roster at 40 and shows an overflow hint for additional pages. The
        developer API envelope wraps the list under `data`; unwrap here.
        """
        try:
            raw = await client.get(f"/lists/{list_id}/contacts")
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://lists/%s/contacts backend error %s: %s",
                list_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001 - defensive
            return None

        if isinstance(raw, list):
            return raw
        if isinstance(raw, dict):
            for key in ("data", "contacts", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    return val
        return None

    async def _fetch_list_for_members(list_id: str) -> dict | None:
        """Best-effort list lookup for header label.

        Scans `GET /lists` for a row whose id matches `list_id` (string-
        compared since the API may return int or str). Returns the raw
        dict or None - the renderer tolerates None and uses a generic
        "List" label fallback.
        """
        try:
            raw = await client.get("/lists")
        except G8ClientError as e:
            logger.warning(
                "g8://lists lookup for members header error %s: %s",
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        if isinstance(raw, dict):
            rows = raw.get("data") if isinstance(raw.get("data"), list) else raw.get("lists")
        else:
            rows = raw if isinstance(raw, list) else None
        if not isinstance(rows, list):
            return None

        target = str(list_id)
        for row in rows:
            if not isinstance(row, dict):
                continue
            row_id = row.get("id")
            if row_id is not None and str(row_id) == target:
                return row
        return None

    @server.resource(
        "g8://lists/{list_id}/contacts",
        mime_type="text/html",
        description=(
            "List members - per-list contact roster for ONE list. Shows "
            "total contacts, unique companies, department count, and "
            "country count in a stat grid. Seniority mix + department "
            "breakdown sections group contacts with pill chips. Timeline "
            "lists the first 40 contacts with name, id, title, department, "
            "seniority badge, email, company id, and location. Empty-state "
            "covers both missing-list (\"members not available\") and "
            "zero-members (\"no contacts in this list yet - add one\"). "
            "URI-templated by list_id. Renders inline in Claude.ai; other "
            "clients fall back to the sibling .txt resource. Complements "
            "g8://lists/dashboard which shows the org-wide lists index."
        ),
    )
    async def list_members_html(list_id: str) -> str:
        """HTML app surface - per-list contact roster."""

        async def _do() -> str:
            contacts = await _fetch_list_members(list_id)
            list_meta = (
                await _fetch_list_for_members(list_id)
                if contacts is not None and contacts
                else None
            )
            return render_list_members_html(
                contacts=contacts, list_id=list_id, list_meta=list_meta
            )

        return await cached_render(
            cache_prefix="list_members_html",
            key_suffix=f"{list_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://lists/{list_id}/contacts.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the list-members surface. Mirrors the "
            "HTML layout (stats \u2192 seniority \u2192 departments "
            "\u2192 contacts \u2192 drill-up pointers) as markdown. Use "
            "this when your client can't render inline HTML."
        ),
    )
    async def list_members_text(list_id: str) -> str:
        """Plaintext app surface - per-list contact roster."""

        async def _do() -> str:
            contacts = await _fetch_list_members(list_id)
            list_meta = (
                await _fetch_list_for_members(list_id)
                if contacts is not None and contacts
                else None
            )
            return render_list_members_text_fallback(
                contacts=contacts, list_id=list_id, list_meta=list_meta
            )

        return await cached_render(
            cache_prefix="list_members_text",
            key_suffix=f"{list_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #40 - Sequence contacts (per-sequence roster). Drills      #
    # down from surface #30 (sequence overview) by answering the next    #
    # question after "is this sequence running?": "WHO is in it, in     #
    # what state, on which step?" Parallel to surface #38 (list members)#
    # but for the execution container rather than the static list.     #
    # URI: `g8://sequences/{sequence_id}/contacts` - disambiguated      #
    # from the `/overview`, `/preview`, and `/analytics` siblings by    #
    # the trailing path segment.                                        #
    # ------------------------------------------------------------------ #

    async def _fetch_sequence_contacts(sequence_id: str) -> list | None:
        """Fetch first page of sequence contacts, or None on failure.

        Returns None on 404/transient - the renderer treats None as
        "surface not available" rather than blowing up. Unwraps the
        ApiResponse envelope and falls back across common list keys so
        backend drift doesn't break the surface.
        """
        try:
            raw = await client.get(f"/sequences/{sequence_id}/contacts")
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://sequences/%s/contacts backend error %s: %s",
                sequence_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        if isinstance(raw, list):
            return raw
        if isinstance(raw, dict):
            for key in ("data", "contacts", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    return val
        return None

    @server.resource(
        "g8://sequences/{sequence_id}/contacts",
        mime_type="text/html",
        description=(
            "Sequence contacts - per-sequence contact roster for ONE "
            "sequence. Shows total contacts, active count, unique "
            "contact ids, and distinct-step count in a stat grid. State "
            "mix section renders status-colored pill chips (queued=blue, "
            "in_progress/active=primary-tint, paused=amber, "
            "completed=green, failed/bounced=red, removed/stopped=muted). "
            "Step distribution section shows per-step enrollment counts. "
            "Timeline lists up to 40 contacts with state badge, contact "
            "id, current step, enrollment timestamp, and last-moved "
            "timestamp. Empty-state covers both missing-sequence "
            "(\"sequence contacts not available\") and zero-contacts "
            "(\"not populated yet - add contacts\"). URI-templated by "
            "sequence_id. Renders inline in Claude.ai; other clients "
            "fall back to the sibling .txt resource. Complements "
            "g8://sequences/{sequence_id}/overview (subscription "
            "metadata), /preview (step structure), and /analytics "
            "(performance)."
        ),
    )
    async def sequence_contacts_html(sequence_id: str) -> str:
        """HTML app surface - per-sequence contact roster."""

        async def _do() -> str:
            contacts = await _fetch_sequence_contacts(sequence_id)
            sequence = (
                await _fetch_sequence_detail(sequence_id)
                if contacts is not None and contacts
                else None
            )
            return render_sequence_contacts_html(
                contacts=contacts, sequence_id=sequence_id, sequence=sequence
            )

        return await cached_render(
            cache_prefix="sequence_contacts_html",
            key_suffix=f"{sequence_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://sequences/{sequence_id}/contacts.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the sequence-contacts surface. "
            "Mirrors the HTML layout (stats \u2192 state mix \u2192 "
            "step distribution \u2192 contacts \u2192 drill-up pointers) "
            "as markdown. Use this when your client can't render inline "
            "HTML."
        ),
    )
    async def sequence_contacts_text(sequence_id: str) -> str:
        """Plaintext app surface - per-sequence contact roster."""

        async def _do() -> str:
            contacts = await _fetch_sequence_contacts(sequence_id)
            sequence = (
                await _fetch_sequence_detail(sequence_id)
                if contacts is not None and contacts
                else None
            )
            return render_sequence_contacts_text_fallback(
                contacts=contacts, sequence_id=sequence_id, sequence=sequence
            )

        return await cached_render(
            cache_prefix="sequence_contacts_text",
            key_suffix=f"{sequence_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #41 - per-contact deals roster                              #
    # Drills from surface #25 (contact detail) and completes the contact #
    # drill-across triad with /notes (#34) and /tasks (#35).             #
    # Reuses `_fetch_contact_for_tasks` defined above for the header     #
    # label (same shape, same endpoint).                                 #
    # URI: `g8://contacts/{contact_id}/deals` - disambiguated from the   #
    # `/notes` and `/tasks` siblings by the trailing path segment.       #
    # ------------------------------------------------------------------ #

    async def _fetch_contact_deals(contact_id: str) -> list | None:
        """Fetch the list of deals associated with a contact, or None on
        404/error.

        Developer-API endpoint returns `ApiResponse[list[ContactDealResponse]]`,
        which means the raw response is `{"data": [...]}` on success. We
        tolerate bare lists and the common fallback keys defensively.
        """
        try:
            raw = await client.get(f"/contacts/{contact_id}/deals")
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://contacts/%s/deals backend error %s: %s",
                contact_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        if isinstance(raw, list):
            return raw
        if isinstance(raw, dict):
            for key in ("data", "deals", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    return val
        return None

    @server.resource(
        "g8://contacts/{contact_id}/deals",
        mime_type="text/html",
        description=(
            "Contact deals - per-contact deal roster for ONE contact. "
            "Shows total / open / won / pipeline value in a stat grid, "
            "plus stage-bucket pills (Won=green, Lost=red, other stages "
            "=primary tint) and role breakdown (Buyer / Decision Maker "
            "/ etc). Timeline lists up to 40 deals with stage badge, "
            "deal name, currency-formatted value chip, role chip, close "
            "date, and creation timestamp. Empty-state covers both "
            "missing-contact (\"deals not available\") and zero-deals "
            "(\"no deals linked yet - create one\"). URI-templated by "
            "contact_id. Renders inline in Claude.ai; other clients fall "
            "back to the sibling .txt resource. Complements g8://contacts"
            "/{contact_id} (profile + activity), /notes (note timeline), "
            "and /tasks (task queue)."
        ),
    )
    async def contact_deals_html(contact_id: str) -> str:
        """HTML app surface - per-contact deal roster."""

        async def _do() -> str:
            deals = await _fetch_contact_deals(contact_id)
            contact = (
                await _fetch_contact_for_tasks(contact_id)
                if deals is not None and deals
                else None
            )
            return render_contact_deals_html(
                deals=deals, contact_id=contact_id, contact=contact
            )

        return await cached_render(
            cache_prefix="contact_deals_html",
            key_suffix=f"{contact_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://contacts/{contact_id}/deals.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the contact-deals surface. Mirrors "
            "the HTML layout (stats \u2192 stage mix \u2192 roles "
            "\u2192 deals \u2192 drill-up pointers) as markdown. Use "
            "this when your client can't render inline HTML."
        ),
    )
    async def contact_deals_text(contact_id: str) -> str:
        """Plaintext app surface - per-contact deal roster."""

        async def _do() -> str:
            deals = await _fetch_contact_deals(contact_id)
            contact = (
                await _fetch_contact_for_tasks(contact_id)
                if deals is not None and deals
                else None
            )
            return render_contact_deals_text_fallback(
                deals=deals, contact_id=contact_id, contact=contact
            )

        return await cached_render(
            cache_prefix="contact_deals_text",
            key_suffix=f"{contact_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #42 - Company deals (per-company deal roster).             #
    # Mirrors surface #41 at the account level. Backend returns the same #
    # `ContactDealResponse` DTO shape for GET /companies/{id}/deals,     #
    # so the renderer reuses surface #41's stage/value/palette helpers.  #
    # Reuses `_fetch_company_for_notes` defined above for the header     #
    # label (same shape, same endpoint).                                 #
    # URI: `g8://companies/{company_id}/deals` - disambiguated from the  #
    # `/notes` sibling (#37) and the parent `g8://companies/{id}` (#26) #
    # by the trailing path segment.                                      #
    # ------------------------------------------------------------------ #

    async def _fetch_company_deals(company_id: str) -> list | None:
        """Fetch deals linked to a company, or None on 404/error.

        Developer-API endpoint returns `ApiResponse[list[ContactDealResponse]]`,
        the same envelope as /contacts/{id}/deals. Tolerates bare lists
        and common fallback keys defensively.
        """
        try:
            raw = await client.get(f"/companies/{company_id}/deals")
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://companies/%s/deals backend error %s: %s",
                company_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        if isinstance(raw, list):
            return raw
        if isinstance(raw, dict):
            for key in ("data", "deals", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    return val
        return None

    @server.resource(
        "g8://companies/{company_id}/deals",
        mime_type="text/html",
        description=(
            "Company deals - per-company deal roster for ONE company. "
            "Shows total / open / won / pipeline value in a stat grid, "
            "plus stage-bucket pills (Won=green, Lost=red, other stages "
            "=primary tint). Timeline lists up to 40 deals with stage "
            "badge, deal name, currency-formatted value chip, close "
            "date, and creation timestamp. Empty-state covers both "
            "missing-company (\"deals not available\") and zero-deals "
            "(\"no deals linked yet - create one\"). URI-templated by "
            "company_id. Renders inline in Claude.ai; other clients fall "
            "back to the sibling .txt resource. Complements g8://companies"
            "/{company_id} (profile + contacts + deals preview) and "
            "/notes (note timeline)."
        ),
    )
    async def company_deals_html(company_id: str) -> str:
        """HTML app surface - per-company deal roster."""

        async def _do() -> str:
            deals = await _fetch_company_deals(company_id)
            company = (
                await _fetch_company_for_notes(company_id)
                if deals is not None and deals
                else None
            )
            return render_company_deals_html(
                deals=deals, company_id=company_id, company=company
            )

        return await cached_render(
            cache_prefix="company_deals_html",
            key_suffix=f"{company_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://companies/{company_id}/deals.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the company-deals surface. Mirrors "
            "the HTML layout (stats \u2192 stage mix \u2192 deals \u2192 "
            "drill-up pointers) as markdown. Use this when your client "
            "can't render inline HTML."
        ),
    )
    async def company_deals_text(company_id: str) -> str:
        """Plaintext app surface - per-company deal roster."""

        async def _do() -> str:
            deals = await _fetch_company_deals(company_id)
            company = (
                await _fetch_company_for_notes(company_id)
                if deals is not None and deals
                else None
            )
            return render_company_deals_text_fallback(
                deals=deals, company_id=company_id, company=company
            )

        return await cached_render(
            cache_prefix="company_deals_text",
            key_suffix=f"{company_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #43 - Webhooks dashboard (org-wide).                       #
    # Top-level org surface. URI: `g8://webhooks` - single-segment,     #
    # distinct from the per-webhook surfaces (`/{id}/overview`, `/{id}/  #
    # deliveries`) which live at 3 segments. No URI collision.          #
    # Complements surface #32 (webhook-detail) and surface #39           #
    # (webhook-deliveries) with an org-wide list + status summary.      #
    # ------------------------------------------------------------------ #

    async def _fetch_webhooks_list() -> list | None:
        """Fetch org-wide webhook registry, or None on error.

        Developer-API endpoint returns `ApiResponse[list[WebhookResponse]]`.
        Tolerates bare lists and common fallback keys defensively.
        """
        try:
            raw = await client.get("/webhooks")
        except G8ClientError as e:
            logger.warning(
                "g8://webhooks backend error %s: %s",
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        if isinstance(raw, list):
            return raw
        if isinstance(raw, dict):
            for key in ("data", "webhooks", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    return val
        return None

    @server.resource(
        "g8://webhooks",
        mime_type="text/html",
        description=(
            "Webhooks dashboard - org-wide registry of webhook "
            "subscriptions. Shows total / active / inactive / unique "
            "events in a stat grid. Event coverage section lists the "
            "event types that at least one webhook subscribes to "
            "(with subscription counts). Webhook list shows up to 40 "
            "rows with status badge (ACTIVE=green, INACTIVE=muted), "
            "display name (name > url fallback), short url, event "
            "count, and per-row drill-down pointers to "
            "g8://webhooks/{id}/overview and "
            "g8://webhooks/{id}/deliveries. Empty-state covers both "
            "no-webhooks-yet (\"POST /webhooks to subscribe\") and "
            "backend-unavailable. Renders inline in Claude.ai; other "
            "clients fall back to the .txt sibling."
        ),
    )
    async def webhooks_dashboard_html() -> str:
        """HTML app surface - org-wide webhooks dashboard."""

        async def _do() -> str:
            webhooks = await _fetch_webhooks_list()
            return render_webhooks_dashboard_html(webhooks=webhooks)

        return await cached_render(
            cache_prefix="webhooks_dashboard_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://webhooks.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the webhooks dashboard. Mirrors "
            "the HTML layout (stats \u2192 event coverage \u2192 "
            "webhooks \u2192 manage pointers) as markdown. Use this "
            "when your client can't render inline HTML."
        ),
    )
    async def webhooks_dashboard_text() -> str:
        """Plaintext app surface - org-wide webhooks dashboard."""

        async def _do() -> str:
            webhooks = await _fetch_webhooks_list()
            return render_webhooks_dashboard_text_fallback(webhooks=webhooks)

        return await cached_render(
            cache_prefix="webhooks_dashboard_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #44 - Contact fields schema (org-wide CRM column registry).#
    # Top-level org surface. URI: `g8://fields/contacts` - static         #
    # 2-segment, disjoint from sibling `g8://fields/companies` (future   #
    # surface #45) and sibling surface #19                                #
    # (`g8://crm-syncs/{provider}/fields`, which is 3-segment templated). #
    # No URI collision. Backend: GET /fields ->                           #
    # ApiResponse[list[FieldResponse{id, title, name, data_type,          #
    # is_global}]]. Each item: id=None = base/system column,              #
    # id=positive int = user-created custom column; is_global=False =     #
    # list-specific.                                                      #
    # ------------------------------------------------------------------ #

    async def _fetch_contact_fields() -> list | None:
        """Fetch contact fields schema, or None on error.

        Developer-API returns `ApiResponse[list[FieldResponse]]`. Tolerates
        bare lists and common fallback keys defensively.
        """
        try:
            raw = await client.get("/fields")
        except G8ClientError as e:
            logger.warning(
                "g8://fields/contacts backend error %s: %s",
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        if isinstance(raw, list):
            return raw
        if isinstance(raw, dict):
            for key in ("data", "fields", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    return val
        return None

    @server.resource(
        "g8://fields/contacts",
        mime_type="text/html",
        description=(
            "Contact fields schema - org-wide CRM column registry for "
            "the contacts entity. Stat grid: total / base / custom / "
            "list-specific. Data-type coverage pills show which types "
            "(text, number, date, etc.) are in use across the schema. "
            "Field list shows up to 80 rows sorted base-first then "
            "alpha, with CUSTOM badge (purple) for user-created "
            "columns and LIST-SPECIFIC badge (warning) for non-global "
            "fields. Answers: \"which columns does my contacts CRM "
            "have, which are custom, which are list-specific?\". "
            "Complements surface #19 "
            "(g8://crm-syncs/{provider}/fields - provider-specific "
            "schema). Sibling: g8://fields/companies (company schema). "
            "Empty-state covers both no-fields-yet and backend-"
            "unavailable. Renders inline in Claude.ai; other clients "
            "fall back to the .txt sibling."
        ),
    )
    async def contact_fields_schema_html() -> str:
        """HTML app surface - org-wide contact fields schema."""

        async def _do() -> str:
            fields = await _fetch_contact_fields()
            return render_contact_fields_schema_html(fields=fields)

        return await cached_render(
            cache_prefix="contact_fields_schema_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://fields/contacts.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the contact fields schema. Mirrors "
            "the HTML layout (stats \u2192 data types \u2192 fields "
            "\u2192 manage pointers) as markdown. Use this when your "
            "client can't render inline HTML."
        ),
    )
    async def contact_fields_schema_text() -> str:
        """Plaintext app surface - org-wide contact fields schema."""

        async def _do() -> str:
            fields = await _fetch_contact_fields()
            return render_contact_fields_schema_text_fallback(fields=fields)

        return await cached_render(
            cache_prefix="contact_fields_schema_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #45 - Company fields schema (org-wide CRM column registry).#
    # Top-level org surface. URI: `g8://fields/companies` - static        #
    # 2-segment, sibling of surface #44 (`g8://fields/contacts`).        #
    # Completes the g8://fields/* namespace. Backend:                     #
    # GET /fields/companies -> ApiResponse[list[FieldResponse{id, title,  #
    # name, data_type, is_global}]]. Same DTO shape as /fields, so the    #
    # renderer reuses surface #44's helpers directly.                     #
    # ------------------------------------------------------------------ #

    async def _fetch_company_fields() -> list | None:
        """Fetch company fields schema, or None on error.

        Developer-API returns `ApiResponse[list[FieldResponse]]`. Tolerates
        bare lists and common fallback keys defensively.
        """
        try:
            raw = await client.get("/fields/companies")
        except G8ClientError as e:
            logger.warning(
                "g8://fields/companies backend error %s: %s",
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        if isinstance(raw, list):
            return raw
        if isinstance(raw, dict):
            for key in ("data", "fields", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    return val
        return None

    @server.resource(
        "g8://fields/companies",
        mime_type="text/html",
        description=(
            "Company fields schema - org-wide CRM column registry for "
            "the companies entity. Stat grid: total / base / custom / "
            "list-specific. Data-type coverage pills show which types "
            "(text, number, date, etc.) are in use across the schema. "
            "Field list shows up to 80 rows sorted base-first then "
            "alpha, with CUSTOM badge (purple) for user-created "
            "columns and LIST-SPECIFIC badge (warning) for non-global "
            "fields. Answers: \"which columns does my companies CRM "
            "have, which are custom, which are list-specific?\". "
            "Sibling of surface #44 "
            "(g8://fields/contacts - contacts schema). Complements "
            "surface #19 (g8://crm-syncs/{provider}/fields - "
            "provider-specific schema). Empty-state covers both "
            "no-fields-yet and backend-unavailable. Renders inline in "
            "Claude.ai; other clients fall back to the .txt sibling."
        ),
    )
    async def company_fields_schema_html() -> str:
        """HTML app surface - org-wide company fields schema."""

        async def _do() -> str:
            fields = await _fetch_company_fields()
            return render_company_fields_schema_html(fields=fields)

        return await cached_render(
            cache_prefix="company_fields_schema_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://fields/companies.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the company fields schema. Mirrors "
            "the HTML layout (stats \u2192 data types \u2192 fields "
            "\u2192 manage pointers) as markdown. Use this when your "
            "client can't render inline HTML."
        ),
    )
    async def company_fields_schema_text() -> str:
        """Plaintext app surface - org-wide company fields schema."""

        async def _do() -> str:
            fields = await _fetch_company_fields()
            return render_company_fields_schema_text_fallback(fields=fields)

        return await cached_render(
            cache_prefix="company_fields_schema_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #46 - Company contacts (per-company contact roster).        #
    # Sibling to surface #38 (g8://lists/{list_id}/contacts) - same       #
    # "contacts-under-a-parent" shape but scoped to a single company.     #
    # Complements #26 (company-detail), #37 (company-notes), #42         #
    # (company-deals). Backend returns CompanyContactItem[] from          #
    # GET /companies/{company_id}/contacts. URI-templated by company_id;  #
    # path segments `/notes`, `/deals`, `/contacts` keep siblings         #
    # mutually exclusive.                                                 #
    # ------------------------------------------------------------------ #

    async def _fetch_company_contacts_roster(company_id: str) -> list | None:
        """Fetch contacts belonging to a company, or None on 404/error.

        Developer-API endpoint returns `ApiResponse[list[CompanyContactItem]]`.
        Tolerates bare lists and common fallback keys defensively.
        """
        try:
            raw = await client.get(f"/companies/{company_id}/contacts")
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://companies/%s/contacts backend error %s: %s",
                company_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        if isinstance(raw, list):
            return raw
        if isinstance(raw, dict):
            for key in ("data", "contacts", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    return val
        return None

    @server.resource(
        "g8://companies/{company_id}/contacts",
        mime_type="text/html",
        description=(
            "Company contacts - per-company contact roster for ONE company. "
            "Shows total / with-email / with-phone / seniority-levels in a "
            "stat grid, plus a seniority-mix pill row. Rows list up to 60 "
            "contacts with name + job title + seniority badge + email + "
            "phone + LinkedIn + location chips. Empty-state covers both "
            "missing-company (\"contacts not available\") and zero-contacts "
            "(\"no contacts linked yet - add one\"). URI-templated by "
            "company_id. Renders inline in Claude.ai; other clients fall "
            "back to the sibling .txt resource. Complements g8://companies"
            "/{company_id} (profile), /notes (note timeline), and /deals "
            "(deal roster)."
        ),
    )
    async def company_contacts_html(company_id: str) -> str:
        """HTML app surface - per-company contact roster."""

        async def _do() -> str:
            contacts = await _fetch_company_contacts_roster(company_id)
            company = (
                await _fetch_company_for_notes(company_id)
                if contacts is not None and contacts
                else None
            )
            return render_company_contacts_html(
                contacts=contacts,
                company_id=company_id,
                company_meta=company,
            )

        return await cached_render(
            cache_prefix="company_contacts_html",
            key_suffix=f"{company_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://companies/{company_id}/contacts.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the company-contacts surface. Mirrors "
            "the HTML layout (stats \u2192 seniority mix \u2192 contacts "
            "\u2192 drill-up pointers) as markdown. Use this when your "
            "client can't render inline HTML."
        ),
    )
    async def company_contacts_text(company_id: str) -> str:
        """Plaintext app surface - per-company contact roster."""

        async def _do() -> str:
            contacts = await _fetch_company_contacts_roster(company_id)
            company = (
                await _fetch_company_for_notes(company_id)
                if contacts is not None and contacts
                else None
            )
            return render_company_contacts_text_fallback(
                contacts=contacts,
                company_id=company_id,
                company_meta=company,
            )

        return await cached_render(
            cache_prefix="company_contacts_text",
            key_suffix=f"{company_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #47 - Webhook events catalog (org-wide event type registry).#
    # Top-level org surface. URI: `g8://webhooks/events` - static         #
    # 2-segment, disjoint from both the 1-segment `g8://webhooks`         #
    # dashboard (surface #43) and the 3-segment per-webhook templates     #
    # `/{webhook_id}/overview` (#32) + `/{webhook_id}/deliveries` (#39).  #
    # No URI collision. Backend: GET /webhooks/events ->                  #
    # ApiResponse[list[WebhookEventResponse{event, description}]] with    #
    # dotted event names (campaign.*, engagement.email_*, etc.). The     #
    # catalog is driven by `WEBHOOK_EVENTS` in                            #
    # campaign_builder/services/webhook_service.py - 36+ event types.     #
    # Renderer groups by leading prefix and preserves canonical category  #
    # order (lifecycle → enrichment → engagement → outcome).              #
    # ------------------------------------------------------------------ #

    async def _fetch_webhook_events() -> list | None:
        """Fetch webhook events catalog, or None on error.

        Developer-API returns `ApiResponse[list[WebhookEventResponse]]`.
        Tolerates bare lists and common fallback keys defensively.
        """
        try:
            raw = await client.get("/webhooks/events")
        except G8ClientError as e:
            logger.warning(
                "g8://webhooks/events backend error %s: %s",
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        if isinstance(raw, list):
            return raw
        if isinstance(raw, dict):
            for key in ("data", "events", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    return val
        return None

    @server.resource(
        "g8://webhooks/events",
        mime_type="text/html",
        description=(
            "Webhook events catalog - org-wide registry of event types "
            "your integrations can subscribe to. Stat grid: total / "
            "categories / engagement / lifecycle. Events are grouped "
            "into canonical categories (campaign lifecycle, content "
            "generation, intelligence, enrichment, audience, sequence "
            "deployment, engagement, meetings) and rendered as "
            "monospace pills with optional hover descriptions. "
            "Answers: \"which webhook events exist, what can I "
            "subscribe to, how are they organized?\". Sibling of "
            "g8://webhooks (dashboard), g8://webhooks/{id}/overview "
            "(per-webhook detail), g8://webhooks/{id}/deliveries "
            "(per-webhook log). Empty-state covers both empty-catalog "
            "and backend-unavailable. Renders inline in Claude.ai; "
            "other clients fall back to the .txt sibling."
        ),
    )
    async def webhook_events_catalog_html() -> str:
        """HTML app surface - org-wide webhook events catalog."""

        async def _do() -> str:
            events = await _fetch_webhook_events()
            return render_webhook_events_html(events=events)

        return await cached_render(
            cache_prefix="webhook_events_catalog_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://webhooks/events.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the webhook events catalog. Mirrors "
            "the HTML layout (stats \u2192 category sections \u2192 "
            "manage pointers) as markdown. Use this when your client "
            "can't render inline HTML."
        ),
    )
    async def webhook_events_catalog_text() -> str:
        """Plaintext app surface - org-wide webhook events catalog."""

        async def _do() -> str:
            events = await _fetch_webhook_events()
            return render_webhook_events_text_fallback(events=events)

        return await cached_render(
            cache_prefix="webhook_events_catalog_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # HTML app surface #48 - repos dashboard (org-wide registry)          #
    # ------------------------------------------------------------------ #

    async def _fetch_repos_list() -> list | None:
        """Fetch org-wide connected repos list, or None on error.

        Developer-API returns `ApiResponse[list[RepoResponse]]` at
        `GET /repos` with optional `page`/`limit` pagination. Tolerates
        bare lists and common fallback keys defensively.
        """
        try:
            raw = await client.get("/repos")
        except G8ClientError as e:
            logger.warning(
                "g8://repos/dashboard backend error %s: %s",
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        if isinstance(raw, list):
            return raw
        if isinstance(raw, dict):
            for key in ("data", "repos", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    return val
        return None

    @server.resource(
        "g8://repos/dashboard",
        mime_type="text/html",
        description=(
            "Repos dashboard - org-wide registry of connected code "
            "repositories. Stat grid: total / scan complete / snippet "
            "installed / providers. Provider mix pills surface the "
            "canonical provider distribution (github / gitlab / "
            "local / other). Each repo row shows name + provider chip "
            "+ two status badges (SCAN + INSTALL, green=done / "
            "yellow=pending / red=failed / muted=unknown) + URL chip "
            "+ branch chip + created chip, with drill-down pointers "
            "to per-repo overview, scan, knowledge base, and campaign "
            "sub-surfaces. Answers: \"which repos are connected, "
            "which ones finished scanning, which have the tracking "
            "snippet installed, which providers are we using?\". "
            "HTML sibling of the existing structured-JSON "
            "g8://repos resource; complements g8://repos/{id}/overview "
            "(per-repo detail, surface #30). Empty-state covers both "
            "empty-registry and backend-unavailable. Renders inline "
            "in Claude.ai; other clients fall back to the .txt sibling."
        ),
    )
    async def repos_dashboard_html() -> str:
        """HTML app surface - org-wide repos dashboard."""

        async def _do() -> str:
            repos = await _fetch_repos_list()
            return render_repos_dashboard_html(repos=repos)

        return await cached_render(
            cache_prefix="repos_dashboard_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://repos/dashboard.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the repos dashboard. Mirrors the "
            "HTML layout (stats \u2192 provider mix \u2192 repo rows "
            "\u2192 manage pointers) as markdown. Use this when your "
            "client can't render inline HTML."
        ),
    )
    async def repos_dashboard_text() -> str:
        """Plaintext app surface - org-wide repos dashboard."""

        async def _do() -> str:
            repos = await _fetch_repos_list()
            return render_repos_dashboard_text_fallback(repos=repos)

        return await cached_render(
            cache_prefix="repos_dashboard_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # HTML app surface #49 - repo install status (per-repo patch set)     #
    # ------------------------------------------------------------------ #
    # URI: `g8://repos/{repo_id}/install` - 3-segment template,          #
    # sibling to the existing `/scan`, `/kb`, `/campaigns`, `/overview`  #
    # per-repo surfaces. Disjoint from the 2-segment static               #
    # `g8://repos/dashboard` by segment count.                            #

    async def _fetch_repo_install_status(repo_id: str) -> dict | None:
        """Fetch the latest install patch set for a repo, or None on error.

        Developer-API returns `ApiResponse[PatchSetResponse]` at
        `GET /repos/{repo_id}/install/status`. Returns None on any
        backend error (404, 5xx, network). Tolerates the `data`
        envelope and a handful of fallback keys defensively.
        """
        try:
            raw = await client.get(f"/repos/{repo_id}/install/status")
        except G8ClientError as e:
            logger.warning(
                "g8://repos/%s/install backend error %s: %s",
                repo_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        if isinstance(raw, dict):
            for key in ("data", "patch_set", "result"):
                val = raw.get(key)
                if isinstance(val, dict):
                    return val
            # Already-unwrapped dict - treat as the patch_set itself
            if "patches" in raw or "status" in raw:
                return raw
        return None

    @server.resource(
        "g8://repos/{repo_id}/install",
        mime_type="text/html",
        description=(
            "Per-repo install status - latest patch set for the "
            "`GET /repos/{repo_id}/install/status` endpoint. Stat "
            "grid: patch count / status (APPLIED green, PREVIEW "
            "yellow, ROLLED_BACK red, unknown muted) / distinct "
            "actions / created-at. Timeline block surfaces the "
            "created / applied / rolled_back timestamps; action mix "
            "pills bucket CREATE / MODIFY / DELETE patches. Each "
            "patch row shows file_path + action badge + description. "
            "Drill-up covers regenerate / apply / rollback write "
            "paths and sibling per-repo surfaces (overview, scan, "
            "kb, campaigns) + the org-wide g8://repos/dashboard. "
            "Answers: 'what changes does the GTM install make to "
            "my repo, has it been applied, can I roll it back?'. "
            "Complements g8://repos/{repo_id}/overview (per-repo "
            "summary) and g8://repos/dashboard (org-wide registry). "
            "Empty-state covers no-patch-set-yet, repo-not-found, "
            "and backend-unavailable. Renders inline in Claude.ai; "
            "other clients fall back to the .txt sibling."
        ),
    )
    async def repo_install_html(repo_id: str) -> str:
        """HTML app surface - per-repo install patch set status."""

        async def _do() -> str:
            patch_set = await _fetch_repo_install_status(repo_id)
            return render_repo_install_html(patch_set=patch_set, repo_id=repo_id)

        return await cached_render(
            cache_prefix="repo_install_html",
            key_suffix=f"{repo_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://repos/{repo_id}/install.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for per-repo install status. Mirrors "
            "the HTML layout (stats \u2192 timeline \u2192 action "
            "mix \u2192 patches \u2192 manage pointers) as markdown. "
            "Use this when your client can't render inline HTML."
        ),
    )
    async def repo_install_text(repo_id: str) -> str:
        """Plaintext app surface - per-repo install patch set status."""

        async def _do() -> str:
            patch_set = await _fetch_repo_install_status(repo_id)
            return render_repo_install_text_fallback(
                patch_set=patch_set, repo_id=repo_id
            )

        return await cached_render(
            cache_prefix="repo_install_text",
            key_suffix=f"{repo_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #50 - CRM sync provider overview.
    # ------------------------------------------------------------------ #
    # URI: `g8://crm-syncs/{provider}/overview` - 3-segment template.    #
    # Slots alongside the existing 2-seg static `g8://crm-syncs/         #
    # dashboard` (org-wide) and 3-seg template `g8://crm-syncs/          #
    # {provider}/fields` (schema) surfaces. Aggregates three backend     #
    # calls: status (connection + last_sync + message) + fields schema   #
    # (count + required/optional + type buckets) + integrations list     #
    # filtered for this provider (supplies connected_at).                #

    async def _fetch_crm_status(provider: str) -> dict | None:
        """Fetch CrmStatusResponse for a provider, or None on any error.

        Developer-API: `GET /crm-syncs/{provider}/status` returns
        `ApiResponse[CrmStatusResponse{provider, connected,
        connection_id, crm_type, message, last_sync_at}]`.
        """
        try:
            raw = await client.get(f"/crm-syncs/{provider}/status")
        except G8ClientError as e:
            logger.warning(
                "g8://crm-syncs/%s/overview status backend error %s: %s",
                provider,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        if isinstance(raw, dict):
            for key in ("data", "status", "result"):
                val = raw.get(key)
                if isinstance(val, dict):
                    return val
            # Already-unwrapped dict - treat as the status itself
            if "connected" in raw or "provider" in raw or "crm_type" in raw:
                return raw
        return None

    async def _fetch_crm_fields(provider: str) -> list[dict] | None:
        """Fetch CrmFieldsResponse.fields for a provider, or None on error.

        Returns [] for an empty successful response, None only when the
        backend fails. This lets the renderer distinguish "no fields
        yet" from "fetch failed".
        """
        try:
            raw = await client.get(f"/crm-syncs/{provider}/fields")
        except G8ClientError as e:
            logger.warning(
                "g8://crm-syncs/%s/overview fields backend error %s: %s",
                provider,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        if isinstance(raw, list):
            return [f for f in raw if isinstance(f, dict)]
        if isinstance(raw, dict):
            for key in ("data", "fields", "result", "items"):
                val = raw.get(key)
                if isinstance(val, list):
                    return [f for f in val if isinstance(f, dict)]
                if isinstance(val, dict):
                    inner = val.get("fields")
                    if isinstance(inner, list):
                        return [f for f in inner if isinstance(f, dict)]
        return None

    async def _fetch_crm_integration(provider: str) -> dict | None:
        """Fetch the integration row from `GET /crm-syncs` for this provider.

        Supplies `connected_at` which is not exposed on the status
        endpoint. Best-effort: returns None if the list fetch fails
        or no row matches the provider slug.
        """
        try:
            raw = await client.get("/crm-syncs")
        except G8ClientError as e:
            logger.warning(
                "g8://crm-syncs/%s/overview integrations backend error %s: %s",
                provider,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        # Normalize to a list of integration dicts.
        integrations: list[dict] = []
        if isinstance(raw, list):
            integrations = [i for i in raw if isinstance(i, dict)]
        elif isinstance(raw, dict):
            for key in ("data", "integrations", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    integrations = [
                        i for i in val if isinstance(i, dict)
                    ]
                    break

        target = provider.strip().lower()
        for integ in integrations:
            row_provider = integ.get("provider")
            if (
                isinstance(row_provider, str)
                and row_provider.strip().lower() == target
            ):
                return integ
        return None

    @server.resource(
        "g8://crm-syncs/{provider}/overview",
        mime_type="text/html",
        description=(
            "Per-CRM-provider operational overview - connection status "
            "(CONNECTED green / DISCONNECTED red / unknown muted), 4 "
            "stat cards (Connection, Total fields, Required fields, "
            "Last sync), a connection-details card (crm_type chip, "
            "connection_id, connected_at, status message), and a "
            "field-schema summary (type buckets + required/optional "
            "split). Aggregates three backend calls: "
            "`GET /crm-syncs/{provider}/status`, `GET /crm-syncs/"
            "{provider}/fields`, and the filtered `GET /crm-syncs` "
            "integration row (for connected_at). Drill-up card covers "
            "contacts / companies / lists push endpoints plus sibling "
            "surfaces (g8://crm-syncs/{provider}/fields full schema + "
            "g8://crm-syncs/dashboard org-wide list + g8://audience-"
            "syncs/dashboard adjacent sync lens + g8://webhooks/events "
            "taxonomy). Answers: 'is this CRM connected, when did it "
            "last sync, how many fields + required, what's the "
            "connection message?'. Empty-state covers not-connected, "
            "unknown-provider, and backend-unavailable. Renders inline "
            "in Claude.ai; other clients fall back to the .txt sibling."
        ),
    )
    async def crm_sync_overview_html(provider: str) -> str:
        """HTML app surface - per-CRM-provider operational overview."""

        async def _do() -> str:
            status = await _fetch_crm_status(provider)
            fields = await _fetch_crm_fields(provider)
            integration = await _fetch_crm_integration(provider)
            return render_crm_sync_overview_html(
                status=status,
                fields=fields,
                integration=integration,
                provider=provider,
            )

        return await cached_render(
            cache_prefix="crm_sync_overview_html",
            key_suffix=f"{provider}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://crm-syncs/{provider}/overview.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for per-CRM-provider operational "
            "overview. Mirrors the HTML layout (stats \u2192 "
            "connection details \u2192 field schema \u2192 manage "
            "pointers) as markdown. Use this when your client can't "
            "render inline HTML."
        ),
    )
    async def crm_sync_overview_text(provider: str) -> str:
        """Plaintext app surface - per-CRM-provider operational overview."""

        async def _do() -> str:
            status = await _fetch_crm_status(provider)
            fields = await _fetch_crm_fields(provider)
            integration = await _fetch_crm_integration(provider)
            return render_crm_sync_overview_text_fallback(
                status=status,
                fields=fields,
                integration=integration,
                provider=provider,
            )

        return await cached_render(
            cache_prefix="crm_sync_overview_text",
            key_suffix=f"{provider}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #51 - Inbox thread draft viewer.
    # ------------------------------------------------------------------ #
    # URI: `g8://inbox/threads/{reply_id}/draft` - 4-segment template.   #
    # Slots alongside the existing 3-seg `g8://inbox/threads/{reply_id}` #
    # (thread detail) and 2-seg `g8://inbox/dashboard` (org-wide).       #
    # Aggregates two backend calls: GET /inbox/{reply_id}/draft (content #
    # + plain_content + credits_charged) and GET /inbox/{reply_id}       #
    # (parent thread channel + subject + contact + latest inbound).      #

    async def _fetch_inbox_draft(reply_id: str) -> dict | None:
        """Fetch DraftResponse for a thread, or None on any error.

        Developer-API: `GET /inbox/{reply_id}/draft` returns
        `ApiResponse[DraftResponse{content, plain_content,
        credits_charged}]`. Draft generation is a billable event so
        the handler relies on the caching layer to avoid double-billing
        during repeat requests within a session.
        """
        try:
            raw = await client.get(f"/inbox/{reply_id}/draft")
        except G8ClientError as e:
            logger.warning(
                "g8://inbox/threads/%s/draft backend error %s: %s",
                reply_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        if isinstance(raw, dict):
            for key in ("data", "draft", "result"):
                val = raw.get(key)
                if isinstance(val, dict):
                    return val
            # Already-unwrapped DraftResponse.
            if (
                "content" in raw
                or "plain_content" in raw
                or "credits_charged" in raw
            ):
                return raw
        return None

    async def _fetch_inbox_thread_for_draft(reply_id: str) -> dict | None:
        """Fetch parent InboxThreadResponse, or None on error.

        Used only as context for the draft surface (subject + contact
        + latest inbound excerpt). Separate from the fuller per-thread
        surface `g8://inbox/threads/{reply_id}` which has its own
        fetcher higher in this file.
        """
        try:
            raw = await client.get(f"/inbox/{reply_id}")
        except G8ClientError as e:
            logger.warning(
                "g8://inbox/threads/%s/draft thread fetch error %s: %s",
                reply_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        if isinstance(raw, dict):
            for key in ("data", "thread", "result"):
                val = raw.get(key)
                if isinstance(val, dict):
                    return val
            # Already-unwrapped thread dict.
            if "id" in raw or "channel" in raw or "messages" in raw:
                return raw
        return None

    @server.resource(
        "g8://inbox/threads/{reply_id}/draft",
        mime_type="text/html",
        description=(
            "Per-thread AI draft viewer - preview the generated reply "
            "before sending. Header shows reply_id monospace + channel "
            "chip (email green / sms primary / linkedin warning) + "
            "draft-quality status chip (READY / HTML ONLY / PLAIN ONLY "
            "/ EMPTY). 4 stat cards (Channel, HTML size in chars, "
            "Plain size in chars, Credits charged). Context card with "
            "thread subject + contact (name, email, company) + latest "
            "inbound message excerpt (from + date + tag-stripped body). "
            "Draft body card renders plain_content when available, "
            "falls back to stripping tags from the HTML content - "
            "never executes the HTML. Drill-up card covers send / "
            "regenerate / assign / tag endpoints plus siblings "
            "(g8://inbox/threads/{reply_id} full thread + "
            "g8://inbox/dashboard org-wide). Answers: 'what's the AI "
            "about to say on my behalf, and is it safe to send?'. "
            "Empty states: empty draft (no content + no plain), thread "
            "not found (reserved), and backend unavailable. Renders "
            "inline in Claude.ai; other clients fall back to the .txt "
            "sibling."
        ),
    )
    async def inbox_draft_html(reply_id: str) -> str:
        """HTML app surface - per-thread AI draft viewer."""

        async def _do() -> str:
            draft = await _fetch_inbox_draft(reply_id)
            thread = await _fetch_inbox_thread_for_draft(reply_id)
            return render_inbox_draft_html(
                draft=draft,
                thread=thread,
                reply_id=reply_id,
            )

        return await cached_render(
            cache_prefix="inbox_draft_html",
            key_suffix=f"{reply_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://inbox/threads/{reply_id}/draft.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for per-thread AI draft viewer. "
            "Mirrors the HTML layout (stats \u2192 thread context "
            "\u2192 draft body \u2192 manage pointers) as markdown. "
            "Draft body renders in a fenced code block so the text is "
            "scannable even in clients that can't render inline HTML."
        ),
    )
    async def inbox_draft_text(reply_id: str) -> str:
        """Plaintext app surface - per-thread AI draft viewer."""

        async def _do() -> str:
            draft = await _fetch_inbox_draft(reply_id)
            thread = await _fetch_inbox_thread_for_draft(reply_id)
            return render_inbox_draft_text_fallback(
                draft=draft,
                thread=thread,
                reply_id=reply_id,
            )

        return await cached_render(
            cache_prefix="inbox_draft_text",
            key_suffix=f"{reply_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #52 - Tracking snippet install (g8://snippet/install).     #
    # Static 2-seg, org-scoped. Aggregates GET /snippet (write key +     #
    # script_tag + react_snippet + domains) and GET /snippet/form (html  #
    # template + fields + event_name + notes) into a single install     #
    # guide. Onboarding-critical: new orgs need this to wire up          #
    # tracking before any other surface has data to show.                #
    # ------------------------------------------------------------------ #

    async def _fetch_tracking_snippet() -> dict | None:
        """Fetch SnippetResponse from GET /snippet, or None on error.

        Tolerates both envelope-wrapped and already-unwrapped shapes.
        """
        try:
            raw = await client.get("/snippet")
        except G8ClientError as e:
            logger.warning(
                "g8://snippet/install backend error %s: %s",
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        if isinstance(raw, dict):
            for key in ("data", "snippet", "result"):
                val = raw.get(key)
                if isinstance(val, dict):
                    return val
            # Already-unwrapped SnippetResponse.
            if (
                "write_key" in raw
                or "tracking_host" in raw
                or "script_tag" in raw
            ):
                return raw
        return None

    async def _fetch_tracking_form() -> dict | None:
        """Fetch form template from GET /snippet/form, or None on error.

        Form template is optional: the install surface still renders the
        snippet + script + react even when the form fetch fails.
        """
        try:
            raw = await client.get("/snippet/form")
        except G8ClientError as e:
            logger.warning(
                "g8://snippet/install form fetch error %s: %s",
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        if isinstance(raw, dict):
            for key in ("data", "form", "result"):
                val = raw.get(key)
                if isinstance(val, dict):
                    return val
            # Already-unwrapped form dict.
            if "html" in raw or "fields" in raw or "event_name" in raw:
                return raw
        return None

    @server.resource(
        "g8://snippet/install",
        mime_type="text/html",
        description=(
            "Tracking snippet install guide - org-wide onboarding "
            "surface. Header shows snippet READY/MISSING chip + form "
            "READY/OFFLINE chip. 4 stat cards (Write key preview, "
            "Tracking host, Domains count, Form fields count). "
            "Authorized-domains card renders the list of domains allowed "
            "to post to this tracking stream. Script-tag card shows the "
            "vanilla <script> one-liner ready to paste into <head>. "
            "React/Next.js card shows the <Graph8Analytics /> component "
            "for App-Router / Pages-Router projects. Form-template card "
            "shows the lead-capture form HTML with field pills + emit "
            "event + notes. Drill-up card covers raw GET /snippet, "
            "GET /snippet/form, per-repo streams, repos dashboard, "
            "per-repo install status, and the g8_get_tracking_snippet / "
            "g8_get_form_template tools. Empty states: no tracking "
            "stream connected yet, or backend unavailable. Renders "
            "inline in Claude.ai; other clients fall back to the .txt "
            "sibling."
        ),
    )
    async def snippet_install_html() -> str:
        """HTML app surface - org-wide tracking snippet install guide."""

        async def _do() -> str:
            snippet = await _fetch_tracking_snippet()
            form = await _fetch_tracking_form()
            return render_snippet_install_html(
                snippet=snippet,
                form=form,
            )

        return await cached_render(
            cache_prefix="snippet_install_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://snippet/install.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the tracking snippet install "
            "guide. Mirrors the HTML layout (stats \u2192 domains "
            "\u2192 script tag \u2192 react snippet \u2192 form "
            "template \u2192 manage pointers) as markdown. Code "
            "blocks render in fenced triple-backtick blocks so they "
            "can be copied cleanly in any client."
        ),
    )
    async def snippet_install_text() -> str:
        """Plaintext app surface - tracking snippet install guide."""

        async def _do() -> str:
            snippet = await _fetch_tracking_snippet()
            form = await _fetch_tracking_form()
            return render_snippet_install_text_fallback(
                snippet=snippet,
                form=form,
            )

        return await cached_render(
            cache_prefix="snippet_install_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #53 - per-contact activities timeline.                     #
    # URI: `g8://contacts/{contact_id}/activities` - 4-segment template,#
    # disjoint from existing `/notes` (#37), `/tasks` (#38), `/deals`   #
    # (#39), and the 2-seg `g8://contacts/{id}` parent detail (#26).    #
    # Pairs `GET /activities?contact_id={id}&limit=50` (activity list)  #
    # with a best-effort `GET /contacts/{contact_id}/detail` for the    #
    # header label ("Jane Doe - activities").                            #
    # ------------------------------------------------------------------ #

    async def _fetch_contact_activities(
        contact_id: str,
    ) -> list[dict] | None:
        """Fetch the list of activities for ONE contact, or None on
        404/error.

        Backend returns `{"data": [...]}` shape (from gtm_context_router
        `list_activities`). We tolerate dict-wrapped and bare-list
        responses defensively.
        """
        try:
            raw = await client.get(
                "/activities",
                params={"contact_id": contact_id, "limit": 100},
            )
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://contacts/%s/activities backend error %s: %s",
                contact_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001 - defensive
            return None

        if isinstance(raw, list):
            return raw
        if isinstance(raw, dict):
            for key in ("data", "activities", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    return val
        return None

    async def _fetch_contact_for_activities(
        contact_id: str,
    ) -> dict | None:
        """Best-effort contact lookup for the header label.

        Returns None on any failure - renderer tolerates None and
        falls back to a generic "Contact {id}" label. Mirrors the
        helper used by /notes (#37) and /tasks (#38).
        """
        try:
            raw = await client.get(f"/contacts/{contact_id}/detail")
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://contacts/%s detail fetch for activities error %s: %s",
                contact_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None
        if not isinstance(raw, dict):
            return None
        data = raw.get("data", raw)
        return data if isinstance(data, dict) else None

    @server.resource(
        "g8://contacts/{contact_id}/activities",
        mime_type="text/html",
        description=(
            "Contact activities - per-contact activity timeline for ONE "
            "contact. Shows total / calls / emails / meetings counts in "
            "a stat grid, plus an activity-type breakdown (call / email "
            "/ meeting / note / task / sms / demo) with per-type counts "
            "and percentages. Timeline lists up to 25 most-recent "
            "activities with a color-coded type badge, subject, "
            "description, outcome call-out (if set), next-steps call-out "
            "(if set), meta chips (subtype / status / duration / source), "
            "date, and owner. Empty states: missing contact ('activities "
            "not available') and zero activities ('no activities yet'). "
            "URI-templated by contact_id. Renders inline in Claude.ai; "
            "other clients fall back to the sibling .txt resource. "
            "Complements g8://contacts/{contact_id} (full profile + "
            "activity dashboard), g8://contacts/{contact_id}/notes "
            "(note timeline), g8://contacts/{contact_id}/tasks (task "
            "timeline), g8://contacts/{contact_id}/deals (linked deals) "
            "and g8://activities/feed (org-wide feed)."
        ),
    )
    async def contact_activities_html(contact_id: str) -> str:
        """HTML app surface - per-contact activity timeline."""

        async def _do() -> str:
            activities = await _fetch_contact_activities(contact_id)
            contact = (
                await _fetch_contact_for_activities(contact_id)
                if activities is not None and activities
                else None
            )
            return render_contact_activities_html(
                activities=activities,
                contact_id=contact_id,
                contact=contact,
            )

        return await cached_render(
            cache_prefix="contact_activities_html",
            key_suffix=f"{contact_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://contacts/{contact_id}/activities.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the contact-activities surface. "
            "Mirrors the HTML layout (stats \u2192 type breakdown "
            "\u2192 timeline \u2192 drill-up pointers) as markdown. "
            "Use this when your client can't render inline HTML."
        ),
    )
    async def contact_activities_text(contact_id: str) -> str:
        """Plaintext app surface - per-contact activity timeline."""

        async def _do() -> str:
            activities = await _fetch_contact_activities(contact_id)
            contact = (
                await _fetch_contact_for_activities(contact_id)
                if activities is not None and activities
                else None
            )
            return render_contact_activities_text_fallback(
                activities=activities,
                contact_id=contact_id,
                contact=contact,
            )

        return await cached_render(
            cache_prefix="contact_activities_text",
            key_suffix=f"{contact_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #54 - per-repo tracking streams listing.                   #
    # URI: `g8://repos/{repo_id}/streams` - 4-seg template, disjoint     #
    # from existing `/overview` (#32) and `/install` (#49) siblings.     #
    # Fetches `GET /repos/{repo_id}/streams` for the stream list, plus a #
    # best-effort `GET /repos/{repo_id}` for the repo label header.      #
    # ------------------------------------------------------------------ #

    async def _fetch_repo_streams(repo_id: str) -> list[dict] | None:
        """Fetch the list of tracking streams for ONE repo.

        Returns None on any backend error so the renderer can emit the
        muted "unavailable" empty state. A successful empty list
        triggers the "no streams connected" primary-tint empty state.
        Envelope unwrap tolerates data/streams/items/results keys + a
        bare-list payload defensively (different backend versions wrap
        differently).
        """
        try:
            raw = await client.get(f"/repos/{repo_id}/streams")
        except G8ClientError as e:
            # 404 here means the repo has no stream endpoint reachable
            # (e.g. repo not installed yet). Treat as "unavailable".
            logger.warning(
                "g8://repos/%s/streams backend error %s: %s",
                repo_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001 - defensive: never break the render
            return None

        if isinstance(raw, list):
            return raw
        if isinstance(raw, dict):
            for key in ("data", "streams", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    return val
        return None

    @server.resource(
        "g8://repos/{repo_id}/streams",
        mime_type="text/html",
        description=(
            "Repo tracking streams \u2014 per-repo list of Flow API "
            "streams (sites/domains) available to this org, with each "
            "stream's id, friendly name, domains array, and masked "
            "write-key preview. Header shows the repo name (best-effort "
            "lookup) + 4 stat cards (Streams total, With write key, "
            "Missing key, Distinct domains). Per-stream card: display "
            "name (name \u2192 first-domain \u2192 id fallback) + "
            "KEY/NO KEY status chip + monospace stream id + domain "
            "chips (capped at 10 with \"+N more\") + write-key preview "
            "pill (first 16 chars + \u2026). URI-templated by repo_id. "
            "Complements g8://repos/{repo_id}/overview (surface #32 "
            "profile), g8://repos/{repo_id}/install (surface #49 patch "
            "set), g8://snippet/install (surface #52 org-wide snippet "
            "guide), and g8://repos/dashboard (surface #48 index). "
            "Empty states: streams_unavailable (backend error) and "
            "no_streams_connected (valid org, zero streams). Renders "
            "inline in Claude.ai; other clients fall back to the "
            "sibling .txt resource."
        ),
    )
    async def repo_streams_html(repo_id: str) -> str:
        """HTML app surface \u2014 per-repo tracking streams listing."""

        async def _do() -> str:
            streams = await _fetch_repo_streams(repo_id)
            repo = (
                await _fetch_repo_detail(repo_id) if streams else None
            )
            repo_label: str | None = None
            if isinstance(repo, dict):
                label_raw = (
                    repo.get("name")
                    or repo.get("repo_name")
                    or repo.get("full_name")
                    or repo.get("url")
                )
                if isinstance(label_raw, str) and label_raw.strip():
                    repo_label = label_raw.strip()
            return render_repo_streams_html(
                repo_id=repo_id,
                streams=streams,
                repo_label=repo_label,
            )

        return await cached_render(
            cache_prefix="repo_streams_html",
            key_suffix=f"{repo_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://repos/{repo_id}/streams.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the repo tracking streams surface. "
            "Mirrors the HTML layout (header \u2192 stats \u2192 per-"
            "stream rows \u2192 install pointers) as markdown. Use "
            "this when your client can't render inline HTML."
        ),
    )
    async def repo_streams_text(repo_id: str) -> str:
        """Plaintext app surface \u2014 per-repo tracking streams."""

        async def _do() -> str:
            streams = await _fetch_repo_streams(repo_id)
            repo = (
                await _fetch_repo_detail(repo_id) if streams else None
            )
            repo_label: str | None = None
            if isinstance(repo, dict):
                label_raw = (
                    repo.get("name")
                    or repo.get("repo_name")
                    or repo.get("full_name")
                    or repo.get("url")
                )
                if isinstance(label_raw, str) and label_raw.strip():
                    repo_label = label_raw.strip()
            return render_repo_streams_text_fallback(
                repo_id=repo_id,
                streams=streams,
                repo_label=repo_label,
            )

        return await cached_render(
            cache_prefix="repo_streams_text",
            key_suffix=f"{repo_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #55 - per-repo scan report.                                #
    # URI: `g8://repos/{repo_id}/scan` - 4-seg template, disjoint from   #
    # existing `/overview` (#32), `/install` (#49), `/streams` (#54)     #
    # siblings. Fetches `GET /repos/{repo_id}/scan` for the scan record  #
    # (tech stack + API routes + GTM readiness + product type + README   #
    # summary), plus a best-effort `GET /repos/{repo_id}` for the repo   #
    # label header.                                                       #
    # ------------------------------------------------------------------ #

    async def _fetch_repo_scan(repo_id: str) -> dict | None:
        """Fetch the latest scan record for ONE repo.

        Returns None on any backend error so the renderer can emit the
        muted "unavailable" empty state. A 404 specifically means no
        scan has been persisted yet → renderer shows the "no_scan"
        primary-tint empty state pointing at POST /repos/{id}/scan.
        Envelope unwrap tolerates data/scan/result keys + a bare-dict
        payload defensively.
        """
        try:
            raw = await client.get(f"/repos/{repo_id}/scan")
        except G8ClientError as e:
            if e.status_code == 404:
                # No scan on record yet - signal "no_scan" to the
                # renderer via a distinct marker. Return sentinel
                # dict so callers can tell "no_scan" from "error".
                return {"__no_scan__": True}
            logger.warning(
                "g8://repos/%s/scan backend error %s: %s",
                repo_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001 - defensive: never break the render
            return None

        if isinstance(raw, dict):
            for key in ("data", "scan", "result"):
                val = raw.get(key)
                if isinstance(val, dict):
                    return val
            # Already-unwrapped dict (has characteristic scan keys)
            if any(k in raw for k in ("tech_stack", "api_routes", "gtm_readiness")):
                return raw
        return None

    @server.resource(
        "g8://repos/{repo_id}/scan",
        mime_type="text/html",
        description=(
            "Repo scan report \u2014 per-repo snapshot of what graph8 "
            "knows about this repository: tech stack (framework / "
            "language / router / styling / auth / database / deployment), "
            "API routes (method + path), GTM readiness flags "
            "(tracking / forms / attribution / identity), product type, "
            "and README summary. Header shows the friendly repo name "
            "(best-effort lookup) + 4 stat cards (Framework, API routes, "
            "Product type, GTM readiness X/4). Dedicated cards render "
            "tech-stack chips, 4-flag GTM pill row (positive-green when "
            "true / muted when false), API route list (up to 50 with "
            "overflow note), and optional README summary in pre-wrap. "
            "URI-templated by repo_id. Complements "
            "g8://repos/{repo_id}/overview (surface #32 profile), "
            "g8://repos/{repo_id}/install (surface #49 patch set), and "
            "g8://repos/{repo_id}/streams (surface #54 stream inventory). "
            "Empty states: scan_unavailable (backend error) and "
            "no_scan_on_record (404 \u2014 no scan persisted yet, "
            "points at POST /repos/{id}/scan). Renders inline in "
            "Claude.ai; other clients fall back to the sibling .txt "
            "resource."
        ),
    )
    async def repo_scan_html(repo_id: str) -> str:
        """HTML app surface \u2014 per-repo scan report."""

        async def _do() -> str:
            scan = await _fetch_repo_scan(repo_id)
            # Unwrap the "no_scan" sentinel into None so the renderer
            # can pick the right empty-state mode via its own branching.
            effective_scan: object = scan
            no_scan = (
                isinstance(scan, dict) and scan.get("__no_scan__") is True
            )
            if no_scan:
                # No scan persisted yet - render dedicated empty state.
                from g8_mcp_server.app_renderer import (  # noqa: WPS433
                    _render_repo_scan_empty_state_html,
                )
                return _render_repo_scan_empty_state_html(repo_id, "no_scan")
            repo = await _fetch_repo_detail(repo_id) if effective_scan else None
            return render_repo_scan_html(
                repo_id=repo_id,
                scan=effective_scan,
                repo=repo,
            )

        return await cached_render(
            cache_prefix="repo_scan_html",
            key_suffix=f"{repo_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://repos/{repo_id}/scan.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the repo scan report surface. "
            "Mirrors the HTML layout (header \u2192 stats \u2192 tech "
            "stack \u2192 GTM readiness \u2192 API routes \u2192 README "
            "summary \u2192 drill-up) as markdown. Use this when your "
            "client can't render inline HTML."
        ),
    )
    async def repo_scan_text(repo_id: str) -> str:
        """Plaintext app surface \u2014 per-repo scan report."""

        async def _do() -> str:
            scan = await _fetch_repo_scan(repo_id)
            no_scan = (
                isinstance(scan, dict) and scan.get("__no_scan__") is True
            )
            if no_scan:
                # Dedicated no_scan text mirror
                lines = [
                    "# Repo scan - no scan on record",
                    "",
                    f"Repo id: `{repo_id}`",
                    "",
                    "No scan has been persisted for this repo. Run the "
                    "`g8` CLI against the repo (or call the "
                    f"`POST /repos/{repo_id}/scan` endpoint from an MCP "
                    "agent) to record tech stack, API routes, and GTM "
                    "readiness. Results feed the install flow at "
                    f"`g8://repos/{repo_id}/install`.",
                    "",
                    "## Manage this repo",
                    f"- Overview: `g8://repos/{repo_id}/overview`",
                    f"- Install status: `g8://repos/{repo_id}/install`",
                    f"- Tracking streams: `g8://repos/{repo_id}/streams`",
                    "- Repos dashboard: `g8://repos/dashboard`",
                    f"- Rescan: `POST /repos/{repo_id}/scan`",
                    f"- Raw scan: `GET /repos/{repo_id}/scan`",
                ]
                return "\n".join(lines).rstrip() + "\n"
            repo = await _fetch_repo_detail(repo_id) if scan else None
            return render_repo_scan_text_fallback(
                repo_id=repo_id,
                scan=scan,
                repo=repo,
            )

        return await cached_render(
            cache_prefix="repo_scan_text",
            key_suffix=f"{repo_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #56 - per-repo tracking snippet (upgrade 4 #56)             #
    # URI: `g8://repos/{repo_id}/snippet` - 4-seg template in the        #
    # /repos/{id}/* sibling family (joins overview #32, install #49,     #
    # streams #54, scan #55). Backed by `GET /repos/{repo_id}/snippet`   #
    # which returns the tracking snippet bound to this repo's stream    #
    # selection. Different from the org-wide `g8://snippet/install`     #
    # (#52) - the per-repo endpoint uses the repo's pinned write key   #
    # and is what the `g8` CLI hits after install.                       #
    # 404 → `"not_found"` sentinel; 400 "No write key configured"       #
    # → `"no_write_key"` sentinel; other errors → None (unavailable).   #
    # ------------------------------------------------------------------ #

    async def _fetch_repo_snippet(repo_id: str) -> dict | None:
        """Fetch the per-repo tracking snippet.

        Returns ``{"__not_found__": True}`` on 404 (repo missing) so the
        renderer can show a dedicated empty state; returns
        ``{"__no_write_key__": True}`` on 400 ("No write key configured")
        so the renderer can point the user at stream selection; returns
        None on any other error so the renderer falls back to the muted
        "unavailable" state. Envelope unwrap tolerates ``data`` /
        ``snippet`` / ``result`` keys plus already-unwrapped payloads.
        """
        try:
            raw = await client.get(f"/repos/{repo_id}/snippet")
        except G8ClientError as e:
            if e.status_code == 404:
                return {"__not_found__": True}
            if e.status_code == 400:
                # 400 with a "No write key" detail is the no_write_key
                # branch. Other 400s (stream not found, stream missing
                # keys) also indicate a configuration gap - treat the
                # same way so the renderer funnels the caller to the
                # streams surface.
                return {"__no_write_key__": True}
            logger.warning(
                "g8://repos/%s/snippet backend error %s: %s",
                repo_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001 - defensive: never break the render
            return None

        if isinstance(raw, dict):
            for key in ("data", "snippet", "result"):
                val = raw.get(key)
                if isinstance(val, dict):
                    return val
            # Already-unwrapped dict (has the characteristic keys)
            if any(k in raw for k in ("write_key", "script_tag", "react_snippet")):
                return raw
        return None

    @server.resource(
        "g8://repos/{repo_id}/snippet",
        mime_type="text/html",
        description=(
            "Per-repo tracking snippet \u2014 shows the tracking write "
            "key, JavaScript script tag, and React/Next.js component "
            "bound to this repo's pinned stream. Complements the "
            "org-wide install guide at `g8://snippet/install` (#52) by "
            "showing the snippet that specifically this repo would "
            "ship with. Slot in the `/repos/{id}/*` sibling family with "
            "`g8://repos/{repo_id}/overview` (#32 profile), `/install` "
            "(#49 patch set), `/streams` (#54 stream inventory), and "
            "`/scan` (#55 scan report). Header shows the friendly repo "
            "name + a READY/MISSING write-key badge. Stat cards show "
            "write-key preview, tracking host, and authorized-domain "
            "count. Domain chips, escape-safe script-tag and React "
            "component preview blocks, and a drill-up card round out "
            "the surface. Empty states: no_write_key (400 \u2014 repo "
            "has no stream pinned yet, points at `/streams` + `/install`); "
            "not_found (404 \u2014 repo does not exist); unavailable "
            "(5xx). Renders inline in Claude.ai; other clients fall "
            "back to the sibling `.txt` resource."
        ),
    )
    async def repo_snippet_html(repo_id: str) -> str:
        """HTML app surface \u2014 per-repo tracking snippet."""

        async def _do() -> str:
            snippet = await _fetch_repo_snippet(repo_id)
            # Sentinel-driven empty-state routing.
            if isinstance(snippet, dict) and snippet.get("__not_found__") is True:
                from g8_mcp_server.app_renderer import (  # noqa: WPS433
                    _render_repo_snippet_empty_state_html,
                )
                return _render_repo_snippet_empty_state_html(repo_id, "not_found")
            if isinstance(snippet, dict) and snippet.get("__no_write_key__") is True:
                from g8_mcp_server.app_renderer import (  # noqa: WPS433
                    _render_repo_snippet_empty_state_html,
                )
                return _render_repo_snippet_empty_state_html(
                    repo_id, "no_write_key"
                )
            repo = await _fetch_repo_detail(repo_id) if snippet else None
            return render_repo_snippet_html(
                repo_id=repo_id,
                snippet=snippet,
                repo=repo,
            )

        return await cached_render(
            cache_prefix="repo_snippet_html",
            key_suffix=f"{repo_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://repos/{repo_id}/snippet.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the per-repo tracking-snippet surface. "
            "Mirrors the HTML layout (header \u2192 summary \u2192 domains "
            "\u2192 script tag \u2192 React component \u2192 drill-up) as "
            "markdown with fenced code blocks. Use this when your client "
            "can't render inline HTML."
        ),
    )
    async def repo_snippet_text(repo_id: str) -> str:
        """Plaintext app surface \u2014 per-repo tracking snippet."""

        async def _do() -> str:
            snippet = await _fetch_repo_snippet(repo_id)
            if isinstance(snippet, dict) and snippet.get("__not_found__") is True:
                lines = [
                    "# Repo snippet - repo not found",
                    "",
                    f"No repo exists at id `{repo_id}`. Check the repos "
                    "dashboard at `g8://repos/dashboard` or `GET /repos` "
                    "to find the correct id.",
                    "",
                    "## Manage repos",
                    "- Repos dashboard: `g8://repos/dashboard`",
                    "- Raw list: `GET /repos`",
                ]
                return "\n".join(lines).rstrip() + "\n"
            if isinstance(snippet, dict) and snippet.get("__no_write_key__") is True:
                lines = [
                    "# Repo snippet - no write key configured",
                    "",
                    f"Repo id: `{repo_id}`",
                    "",
                    "This repo has no tracking write key pinned yet. "
                    "Pick a stream via "
                    f"`g8://repos/{repo_id}/streams` and pass its id to "
                    f"`GET /repos/{repo_id}/snippet?stream_id=<id>`, or "
                    "run the install flow at "
                    f"`g8://repos/{repo_id}/install`.",
                    "",
                    "## Manage this repo",
                    f"- Overview: `g8://repos/{repo_id}/overview`",
                    f"- Install status: `g8://repos/{repo_id}/install`",
                    f"- Tracking streams: `g8://repos/{repo_id}/streams`",
                    f"- Scan report: `g8://repos/{repo_id}/scan`",
                    "- Org-wide snippet: `g8://snippet/install`",
                    "- Repos dashboard: `g8://repos/dashboard`",
                    f"- Raw snippet: `GET /repos/{repo_id}/snippet`",
                    "- Tool: `g8_get_tracking_snippet`",
                ]
                return "\n".join(lines).rstrip() + "\n"
            repo = await _fetch_repo_detail(repo_id) if snippet else None
            return render_repo_snippet_text_fallback(
                repo_id=repo_id,
                snippet=snippet,
                repo=repo,
            )

        return await cached_render(
            cache_prefix="repo_snippet_text",
            key_suffix=f"{repo_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #57 - Form snippet (g8://snippet/form).                    #
    # Static 2-seg, org-scoped. Aggregates GET /snippet/form            #
    # (lead-capture form HTML + fields[] + event_name + notes +         #
    # write_key + tracking_host) into a dedicated surface. Different   #
    # from #52 (snippet/install), which is the JS tracking snippet:    #
    # #57 focuses on the embeddable HTML form - separate user intent   #
    # (capture leads vs. instrument pageviews). Different from the per-#
    # repo #56 (repos/{id}/snippet), which is the JS snippet bound to   #
    # a single repo.                                                    #
    # ------------------------------------------------------------------ #

    async def _fetch_form_snippet() -> dict | None:
        """Fetch form template from GET /snippet/form, or None on error.

        Tolerates envelope-wrapped (`data` / `form` / `result`) and
        already-unwrapped shapes.
        """
        try:
            raw = await client.get("/snippet/form")
        except G8ClientError as e:
            logger.warning(
                "g8://snippet/form backend error %s: %s",
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        if isinstance(raw, dict):
            for key in ("data", "form", "result"):
                val = raw.get(key)
                if isinstance(val, dict):
                    return val
            if (
                "html" in raw
                or "fields" in raw
                or "event_name" in raw
                or "write_key" in raw
            ):
                return raw
        return None

    @server.resource(
        "g8://snippet/form",
        mime_type="text/html",
        description=(
            "Lead-capture form snippet - org-wide embeddable HTML form "
            "surface. Header shows FORM READY/MISSING chip. 4 stat cards "
            "(Write key preview, Tracking host, Fields count, Event "
            "name). Fields card shows chip per captured field name "
            "(name / email / company / …). Main content is an escaped "
            "<pre> block with the full form HTML (clipped at 4000 "
            "chars) - drop into any page that already loads the JS "
            "tracking snippet (see g8://snippet/install). The form "
            "fires `window.graph8.track('<event>', ...)` with a "
            "direct-POST fallback to the tracking host. Integration "
            "notes from the backend render below the code. Drill-up "
            "points at the JS tracking snippet surface, repos "
            "dashboard, webhook events catalog, raw GET /snippet/form, "
            "and the g8_get_form_snippet tool. Empty states: no "
            "tracking stream connected yet (primary-tint, points at "
            "Connections), or backend unavailable (muted). Renders "
            "inline in Claude.ai; other clients fall back to the .txt "
            "sibling."
        ),
    )
    async def form_snippet_html() -> str:
        """HTML app surface - org-wide lead-capture form snippet."""

        async def _do() -> str:
            form = await _fetch_form_snippet()
            return render_form_snippet_html(form=form)

        return await cached_render(
            cache_prefix="form_snippet_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://snippet/form.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the lead-capture form snippet. "
            "Mirrors the HTML layout (stats \u2192 fields \u2192 form "
            "HTML \u2192 notes \u2192 related-surfaces pointers) as "
            "markdown. Form HTML renders in a fenced ```html block so "
            "it can be copied cleanly in any client."
        ),
    )
    async def form_snippet_text() -> str:
        """Plaintext app surface - lead-capture form snippet."""

        async def _do() -> str:
            form = await _fetch_form_snippet()
            return render_form_snippet_text_fallback(form=form)

        return await cached_render(
            cache_prefix="form_snippet_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # HTML app surface #58 - contacts dashboard (org-wide contact index). #
    #                                                                    #
    # URI: `g8://contacts/dashboard` (+ `.txt` sibling). Static 2-seg    #
    # URI, disjoint from the upgrade-1 JSON list at `g8://contacts`     #
    # and from the per-contact detail at `g8://contacts/{contact_id}`.   #
    # Backed by `GET /contacts?limit=200` which returns                 #
    # `ApiResponse[list[ContactListItem]]` plus `pagination.total`.      #
    # ------------------------------------------------------------------ #

    async def _fetch_contacts_dashboard() -> tuple[list[dict] | None, int | None]:
        """Fetch org-wide contacts + pagination total.

        Returns `(contacts, total)`. On failure, returns `(None, None)`
        so the renderer can produce the 'unavailable' empty state.
        Tolerates envelope-wrapped (`data` + `pagination.total`),
        bare lists, and common fallback keys.
        """
        try:
            raw = await client.get("/contacts", {"limit": 200})
        except G8ClientError as e:
            logger.warning(
                "g8://contacts/dashboard backend error %s: %s",
                e.status_code,
                e,
            )
            return None, None
        except Exception:  # noqa: BLE001
            return None, None

        if isinstance(raw, list):
            return raw, None

        if isinstance(raw, dict):
            contacts: list[dict] | None = None
            for key in ("data", "contacts", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    contacts = val
                    break

            total: int | None = None
            pagination = raw.get("pagination")
            if isinstance(pagination, dict):
                tv = pagination.get("total")
                if isinstance(tv, int) and tv >= 0:
                    total = tv

            return contacts, total

        return None, None

    @server.resource(
        "g8://contacts/dashboard",
        mime_type="text/html",
        description=(
            "Contacts dashboard - org-wide contact index. Stat grid "
            "(Total / With email / With phone / With LinkedIn) surfaces "
            "reachability at a glance. Seniority mix pills use a graph8-"
            "tone palette (exec/VP = primary, director/manager = green, "
            "IC = muted). Top-departments and top-countries chip clouds "
            "show firmographic coverage. The 60 most recent contacts "
            "render as cards: display name + seniority/LinkedIn/phone "
            "badges + job title + email + location + company_id, each "
            "with drill-down pointers to per-contact detail, notes, "
            "tasks, deals, and activities surfaces. Distinct from "
            "g8://lists/{list_id}/contacts (list-scoped) and "
            "g8://companies/{company_id}/contacts (company-scoped) - "
            "this is the global contact index. Answers: \"how many "
            "reachable contacts do we have, which seniority levels "
            "dominate, which departments and countries are we strong "
            "in, and who are the most recent additions?\". Empty states: "
            "no contacts yet (primary-tint, points at POST /contacts / "
            "batch assert / enrichment) or backend unavailable (muted). "
            "Renders inline in Claude.ai; other clients fall back to "
            "the .txt sibling."
        ),
    )
    async def contacts_dashboard_html() -> str:
        """HTML app surface - org-wide contacts dashboard."""

        async def _do() -> str:
            contacts, total = await _fetch_contacts_dashboard()
            return render_contacts_dashboard_html(
                contacts=contacts, total=total
            )

        return await cached_render(
            cache_prefix="contacts_dashboard_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://contacts/dashboard.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the contacts dashboard. Mirrors the "
            "HTML layout (stats \u2192 seniority \u2192 departments "
            "\u2192 countries \u2192 contact rows \u2192 manage "
            "pointers) as markdown. Use this when your client can't "
            "render inline HTML."
        ),
    )
    async def contacts_dashboard_text() -> str:
        """Plaintext app surface - org-wide contacts dashboard."""

        async def _do() -> str:
            contacts, total = await _fetch_contacts_dashboard()
            return render_contacts_dashboard_text_fallback(
                contacts=contacts, total=total
            )

        return await cached_render(
            cache_prefix="contacts_dashboard_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # HTML app surface #59 - companies dashboard (org-wide company index).#
    #                                                                    #
    # URI: `g8://companies/dashboard` (+ `.txt` sibling). Static 2-seg   #
    # URI, disjoint from the upgrade-1 JSON list at `g8://companies`    #
    # and from the per-company detail at `g8://companies/{company_id}`.  #
    # Backed by `GET /companies?limit=200` which returns                #
    # `ApiResponse[list[CompanyListItem]]` plus `pagination.total`.      #
    #                                                                    #
    # Collision safety: the per-company detail template formally matches #
    # /dashboard (company_id="dashboard"), but FastMCP's                #
    # ResourceManager.get_resource checks static _resources first so    #
    # the dashboard handler always wins. Integration test locks this.   #
    # ------------------------------------------------------------------ #

    async def _fetch_companies_dashboard() -> tuple[list[dict] | None, int | None]:
        """Fetch org-wide companies + pagination total.

        Returns `(companies, total)`. On failure, returns `(None, None)`
        so the renderer can produce the 'unavailable' empty state.
        Tolerates envelope-wrapped (`data` + `pagination.total`),
        bare lists, and common fallback keys.
        """
        try:
            raw = await client.get("/companies", {"limit": 200})
        except G8ClientError as e:
            logger.warning(
                "g8://companies/dashboard backend error %s: %s",
                e.status_code,
                e,
            )
            return None, None
        except Exception:  # noqa: BLE001
            return None, None

        if isinstance(raw, list):
            return raw, None

        if isinstance(raw, dict):
            companies: list[dict] | None = None
            for key in ("data", "companies", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    companies = val
                    break

            total: int | None = None
            pagination = raw.get("pagination")
            if isinstance(pagination, dict):
                tv = pagination.get("total")
                if isinstance(tv, int) and tv >= 0:
                    total = tv

            return companies, total

        return None, None

    @server.resource(
        "g8://companies/dashboard",
        mime_type="text/html",
        description=(
            "Companies dashboard - org-wide company index. Stat grid "
            "(Total / With domain / With LinkedIn / Employee count "
            "known) surfaces ICP-fit coverage at a glance. Industry "
            "chip cluster shows vertical distribution; employee-size "
            "bucket cluster (1-10 / 11-50 / 51-200 / 201-1000 / "
            "1001-5000 / 5000+) uses a graph8-tone palette with larger "
            "buckets (SMB mid-market and above) in primary tint. "
            "Top-countries chip cloud shows geo coverage. The 50 "
            "most recent companies render as cards: display name "
            "(falling back to domain, then `(unnamed company)`) + "
            "INDUSTRY/LINKEDIN/WEBSITE badges + description + domain "
            "+ location + employees · founded_year, each with "
            "drill-down pointers to per-company detail, notes, "
            "contacts, and deals surfaces. Distinct from the upgrade-1 "
            "JSON list at g8://companies and from per-company detail. "
            "Answers: \"how big is our account universe, which "
            "industries and sizes dominate, and which companies were "
            "added most recently?\". Empty states: no companies yet "
            "(primary-tint, points at POST /companies / batch assert "
            "/ enrich-company) or backend unavailable (muted). "
            "Renders inline in Claude.ai; other clients fall back to "
            "the .txt sibling."
        ),
    )
    async def companies_dashboard_html() -> str:
        """HTML app surface - org-wide companies dashboard."""

        async def _do() -> str:
            companies, total = await _fetch_companies_dashboard()
            return render_companies_dashboard_html(
                companies=companies, total=total
            )

        return await cached_render(
            cache_prefix="companies_dashboard_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://companies/dashboard.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the companies dashboard. Mirrors "
            "the HTML layout (stats \u2192 industries \u2192 employee "
            "sizes \u2192 countries \u2192 company rows \u2192 manage "
            "pointers) as markdown. Use this when your client can't "
            "render inline HTML."
        ),
    )
    async def companies_dashboard_text() -> str:
        """Plaintext app surface - org-wide companies dashboard."""

        async def _do() -> str:
            companies, total = await _fetch_companies_dashboard()
            return render_companies_dashboard_text_fallback(
                companies=companies, total=total
            )

        return await cached_render(
            cache_prefix="companies_dashboard_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # HTML app surface #60 - deals dashboard (org-wide deals index).     #
    #                                                                    #
    # URI: `g8://deals/dashboard` (+ `.txt` sibling). Static 2-seg URI,  #
    # sibling to the stage-grouped kanban at `g8://deals/pipeline` and   #
    # disjoint from per-deal detail at `g8://deals/{deal_id}`. Backed    #
    # by `GET /deals?limit=200` which returns                            #
    # `ApiResponse[list[DealResponse]]` plus `pagination.total`.         #
    #                                                                    #
    # Collision safety: the per-deal detail template formally matches    #
    # /dashboard (deal_id="dashboard"), but FastMCP's                    #
    # ResourceManager.get_resource checks static _resources first so    #
    # the dashboard handler always wins. Integration test locks this.   #
    # ------------------------------------------------------------------ #

    async def _fetch_deals_dashboard() -> tuple[list[dict] | None, int | None]:
        """Fetch org-wide deals + pagination total.

        Returns `(deals, total)`. On failure, returns `(None, None)`
        so the renderer can produce the 'unavailable' empty state.
        Tolerates envelope-wrapped (`data` + `pagination.total`),
        bare lists, and common fallback keys.
        """
        try:
            raw = await client.get("/deals", {"limit": 200})
        except G8ClientError as e:
            logger.warning(
                "g8://deals/dashboard backend error %s: %s",
                e.status_code,
                e,
            )
            return None, None
        except Exception:  # noqa: BLE001
            return None, None

        if isinstance(raw, list):
            return raw, None

        if isinstance(raw, dict):
            deals: list[dict] | None = None
            for key in ("data", "deals", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    deals = val
                    break

            total: int | None = None
            pagination = raw.get("pagination")
            if isinstance(pagination, dict):
                tv = pagination.get("total")
                if isinstance(tv, int) and tv >= 0:
                    total = tv

            return deals, total

        return None, None

    @server.resource(
        "g8://deals/dashboard",
        mime_type="text/html",
        description=(
            "Deals dashboard - org-wide CRM deals index. Stat grid "
            "(Total / Pipeline value / Avg deal size / With close "
            "date) surfaces financial coverage at a glance. Stage "
            "chip cluster shows pipeline-stage distribution. The "
            "close-date horizon bucket cluster "
            "(overdue / this week / this month / this quarter / "
            "later / no close date) uses a graph8-tone palette "
            "with overdue in destructive-muted, upcoming in "
            "primary/positive tints, and later/no-date in muted. "
            "Currency chip cloud shows pipeline currency mix; when "
            "multiple currencies exist, pipeline value sums only "
            "the dominant currency and the caveat is shown inline. "
            "The top 50 deals by amount desc render as cards: "
            "display name (falling back to `(unnamed deal)`) + "
            "STAGE badge + horizon badge + amount · currency + "
            "description + close-date line, each with drill-down "
            "pointers to per-deal detail + per-company detail. "
            "Distinct from the stage-kanban at g8://deals/pipeline "
            "(this surface is financial/temporal, that one is "
            "stage-structural). Answers: \"what's our pipeline "
            "value, which deals are closing soonest, and where "
            "does revenue cluster by stage?\". Empty states: "
            "no deals yet (primary-tint, points at POST /deals + "
            "pipeline/structure) or backend unavailable (muted). "
            "Renders inline in Claude.ai; other clients fall back "
            "to the .txt sibling."
        ),
    )
    async def deals_dashboard_html() -> str:
        """HTML app surface - org-wide deals dashboard."""

        async def _do() -> str:
            deals, total = await _fetch_deals_dashboard()
            return render_deals_dashboard_html(deals=deals, total=total)

        return await cached_render(
            cache_prefix="deals_dashboard_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://deals/dashboard.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the deals dashboard. Mirrors "
            "the HTML layout (stats \u2192 stages \u2192 close "
            "date horizon \u2192 currencies \u2192 deal rows "
            "\u2192 manage pointers) as markdown. Use this when "
            "your client can't render inline HTML."
        ),
    )
    async def deals_dashboard_text() -> str:
        """Plaintext app surface - org-wide deals dashboard."""

        async def _do() -> str:
            deals, total = await _fetch_deals_dashboard()
            return render_deals_dashboard_text_fallback(
                deals=deals, total=total
            )

        return await cached_render(
            cache_prefix="deals_dashboard_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #61 - Per-pipeline deals (templated).                     #
    # URI: `g8://pipelines/{pipeline_id}/deals` (+ `.txt` sibling).       #
    # 3-segment TEMPLATE with literal `/deals` suffix. Distinct from:    #
    #   - static 2-seg `g8://pipelines/overview` (surface #14)            #
    #   - static 2-seg `g8://deals/dashboard` (surface #60) & pipeline    #
    #     (surface #11)                                                   #
    #   - 2-seg template `g8://deals/{deal_id}` (surface #24)             #
    # Backed by:                                                          #
    #   - `GET /deals?pipeline_id={id}&limit=200` for deals               #
    #   - `GET /deals/pipelines` to look up pipeline metadata             #
    #     (name + ordered stages)                                         #
    # The literal `/deals` trailing segment keeps `.txt` dispatch         #
    # unambiguous even under FastMCP's `[^/]+` template regex.            #
    # ------------------------------------------------------------------ #

    async def _fetch_pipeline_deals(
        pipeline_id: str,
    ) -> tuple[dict | None, list[dict] | None, int | None]:
        """Fetch pipeline metadata + pipeline-scoped deals.

        Returns `(pipeline, deals, total)`. On failure, returns
        `(pipeline_or_None, None, None)` so the renderer produces the
        'unavailable' empty state. Pipeline metadata is best-effort -
        a missing pipeline still renders an `(#id)` fallback header.
        """
        pipeline: dict | None = None
        try:
            raw_pipes = await client.get("/deals/pipelines", {})
        except G8ClientError as e:
            logger.debug(
                "g8://pipelines/%s/deals pipelines lookup error %s: %s",
                pipeline_id,
                e.status_code,
                e,
            )
            raw_pipes = None
        except Exception:  # noqa: BLE001
            raw_pipes = None

        if isinstance(raw_pipes, dict):
            pipes_list = None
            for key in ("data", "pipelines", "items", "results"):
                val = raw_pipes.get(key)
                if isinstance(val, list):
                    pipes_list = val
                    break
        elif isinstance(raw_pipes, list):
            pipes_list = raw_pipes
        else:
            pipes_list = None

        if isinstance(pipes_list, list):
            for p in pipes_list:
                if not isinstance(p, dict):
                    continue
                pid = p.get("id")
                if isinstance(pid, str) and pid == pipeline_id:
                    pipeline = p
                    break

        try:
            raw = await client.get(
                "/deals", {"pipeline_id": pipeline_id, "limit": 200}
            )
        except G8ClientError as e:
            logger.warning(
                "g8://pipelines/%s/deals backend error %s: %s",
                pipeline_id,
                e.status_code,
                e,
            )
            return pipeline, None, None
        except Exception:  # noqa: BLE001
            return pipeline, None, None

        if isinstance(raw, list):
            return pipeline, raw, None

        if isinstance(raw, dict):
            deals: list[dict] | None = None
            for key in ("data", "deals", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    deals = val
                    break

            total: int | None = None
            pagination = raw.get("pagination")
            if isinstance(pagination, dict):
                tv = pagination.get("total")
                if isinstance(tv, int) and tv >= 0:
                    total = tv

            return pipeline, deals, total

        return pipeline, None, None

    @server.resource(
        "g8://pipelines/{pipeline_id}/deals",
        mime_type="text/html",
        description=(
            "Per-pipeline deals - for multi-pipeline orgs (New Biz / "
            "Renewals / Partnerships etc.), shows ONE pipeline's "
            "deals grouped by ITS configured stages in pipeline "
            "order. Complements g8://deals/pipeline (org-wide "
            "stage kanban - this one is pipeline-scoped), "
            "g8://pipelines/overview (stage config without deals - "
            "this one shows deals inside those stages), and "
            "g8://deals/dashboard (financial + temporal lens - this "
            "one is stage-oriented). KPI cards: Deals in pipeline / "
            "Pipeline value (dominant-currency total) / With amount "
            "/ With close date. Each stage renders as a section "
            "header with stage name chip, deal-count chip, and "
            "subtotal chip (dominant currency only); stage rows "
            "render deal name + amount chip + close-date chip + "
            "drill-down pointer to g8://deals/{deal_id}. Stages "
            "are rendered in pipeline config order (position asc) "
            "even when empty - empty stages show '(no deals)' "
            "placeholder so the full funnel shape stays visible. "
            "Deals whose stage doesn't match any configured stage "
            "are bucketed under 'Unstaged'. Capped at 120 total "
            "rendered deals (30 per stage) so large pipelines "
            "don't blow the context budget. Drill-up card points "
            "at overview / org-wide kanban / dashboard / per-deal "
            "template. Renders inline in Claude.ai; other clients "
            "fall back to the .txt sibling."
        ),
    )
    async def pipeline_deals_html(pipeline_id: str) -> str:
        """HTML app surface - per-pipeline deals grouped by stage."""

        async def _do() -> str:
            pipeline, deals, total = await _fetch_pipeline_deals(pipeline_id)
            return render_pipeline_deals_html(
                pipeline_id=pipeline_id,
                pipeline=pipeline,
                deals=deals,
                total=total,
            )

        return await cached_render(
            cache_prefix="pipeline_deals_html",
            key_suffix=f"{pipeline_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://pipelines/{pipeline_id}/deals.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the per-pipeline deals surface. "
            "Mirrors the HTML layout (stats \u2192 per-stage "
            "sections in pipeline order \u2192 unstaged deals "
            "\u2192 related-surface pointers) as markdown. Use "
            "this when your client can't render inline HTML."
        ),
    )
    async def pipeline_deals_text(pipeline_id: str) -> str:
        """Plaintext app surface - per-pipeline deals grouped by stage."""

        async def _do() -> str:
            pipeline, deals, total = await _fetch_pipeline_deals(pipeline_id)
            return render_pipeline_deals_text_fallback(
                pipeline_id=pipeline_id,
                pipeline=pipeline,
                deals=deals,
                total=total,
            )

        return await cached_render(
            cache_prefix="pipeline_deals_text",
            key_suffix=f"{pipeline_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #62 - Per-ICP detail (templated).                          #
    # URI: `g8://icps/{icp_id}` (+ `.txt` sibling).                       #
    # 2-segment TEMPLATE. Distinct from:                                 #
    #   - static 2-seg `g8://icps/dashboard` (surface #13) - FastMCP     #
    #     ResourceManager checks the static `_resources` dict FIRST,     #
    #     so `dashboard` always wins when it's the exact literal URI.    #
    #     Same pattern shipped safely in surfaces #58 (contacts) and     #
    #     #59 (companies).                                                #
    # Backed by: `GET /icps?limit=200` then client-side filter by `id`   #
    # (no per-id endpoint in developer_api).                             #
    # ------------------------------------------------------------------ #

    async def _fetch_icp_by_id(icp_id: str) -> dict | None:
        """Load a single ICP by id. Returns None when not found / unavailable.

        Developer API exposes `GET /icps` returning `{data: [...]}`; there
        is no per-id endpoint, so we filter client-side. Returns None for
        both unavailable (backend error) and not-found (id absent) so the
        renderer can distinguish via the URI payload vs None result.
        """
        try:
            raw = await client.get("/icps", {"limit": 200})
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://icps/%s backend error %s: %s",
                icp_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        if not isinstance(raw, dict):
            return None
        data = raw.get("data")
        if not isinstance(data, list):
            return None
        for icp in data:
            if not isinstance(icp, dict):
                continue
            if icp.get("id") == icp_id:
                return icp
        return None

    @server.resource(
        "g8://icps/{icp_id}",
        mime_type="text/html",
        description=(
            "Single-ICP drilldown - header with name + pinned star + "
            "priority/status badges, 4-card KPI quadrant (Fit / "
            "Opportunity / Readiness / Total - each colored by bucket "
            "on the graph8 palette: 80+ positive, 60-79 primary, "
            "40-59 warning, 0-39 muted), description section, "
            "firmographics meta rows (industry / size / geography / "
            "revenue etc.), tech-stack meta rows (CRMs / tooling / "
            "stack signals), and buying-signal chip cluster. "
            "Complements g8://icps/dashboard (grid of all ICPs - this "
            "one is a single-ICP detail), g8://personas/dashboard "
            "(sibling targeting axis: who to reach inside an ICP-fit "
            "account), and g8://global-context/library (studio doc "
            "library where ICPs live). URI-templated by icp_id. "
            "Renders inline in Claude.ai; other clients fall back to "
            "the .txt sibling."
        ),
    )
    async def icp_detail_html(icp_id: str) -> str:
        """HTML app surface - single ICP drilldown."""

        async def _do() -> str:
            icp = await _fetch_icp_by_id(icp_id)
            return render_icp_detail_html(icp_id=icp_id, icp=icp)

        return await cached_render(
            cache_prefix="icp_detail_html",
            key_suffix=f"{icp_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://icps/{icp_id}.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the per-ICP detail surface. Mirrors "
            "the HTML layout (scores \u2192 description \u2192 "
            "firmographics \u2192 tech stack \u2192 buying signals "
            "\u2192 related-surface pointers) as markdown. Use this "
            "when your client can't render inline HTML."
        ),
    )
    async def icp_detail_text(icp_id: str) -> str:
        """Plaintext app surface - single ICP drilldown."""

        async def _do() -> str:
            icp = await _fetch_icp_by_id(icp_id)
            return render_icp_detail_text_fallback(icp_id=icp_id, icp=icp)

        return await cached_render(
            cache_prefix="icp_detail_text",
            key_suffix=f"{icp_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #63 - Per-persona detail (templated).                       #
    # URI: `g8://personas/{persona_id}` (+ `.txt` sibling).              #
    # 2-segment TEMPLATE. Distinct from:                                 #
    #   - static 2-seg `g8://personas/dashboard` (surface #3) - FastMCP  #
    #     ResourceManager checks the static `_resources` dict FIRST,     #
    #     so `dashboard` always wins when it's the exact literal URI.    #
    #     Same pattern shipped safely in surfaces #58 (contacts), #59    #
    #     (companies), and #62 (icps).                                    #
    # Backed by: `GET /personas?limit=200` then client-side filter by    #
    # `id` (no per-id endpoint in developer_api).                        #
    # ------------------------------------------------------------------ #

    async def _fetch_persona_by_id(persona_id: str) -> dict | None:
        """Load a single persona by id. Returns None when not found / unavailable.

        Developer API exposes `GET /personas` returning `{data: [...]}`;
        there is no per-id endpoint, so we filter client-side. Returns
        None for both unavailable (backend error) and not-found (id
        absent) so the renderer can distinguish via the URI payload vs
        None result.
        """
        try:
            raw = await client.get("/personas", {"limit": 200})
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://personas/%s backend error %s: %s",
                persona_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        if not isinstance(raw, dict):
            return None
        data = raw.get("data")
        if not isinstance(data, list):
            return None
        for persona in data:
            if not isinstance(persona, dict):
                continue
            if persona.get("id") == persona_id:
                return persona
        return None

    @server.resource(
        "g8://personas/{persona_id}",
        mime_type="text/html",
        description=(
            "Single-persona drilldown - header with title + pinned star "
            "+ priority / confidence / status chips (each bucketed on "
            "the graph8 palette: high=positive, medium=primary, "
            "low=warning, else=muted), overview meta block "
            "(expected receptivity + recommended goal), why-target "
            "rich text, campaign-approach rich text, and key-signals "
            "chip cluster. Complements g8://personas/dashboard (grid of "
            "all personas - this one is a single-persona detail), "
            "g8://icps/dashboard and g8://icps/{icp_id} (sibling "
            "targeting axis: what account profile to target), and "
            "g8://global-context/library (studio doc library where "
            "persona research lives). URI-templated by persona_id. "
            "Renders inline in Claude.ai; other clients fall back to "
            "the .txt sibling."
        ),
    )
    async def persona_detail_html(persona_id: str) -> str:
        """HTML app surface - single persona drilldown."""

        async def _do() -> str:
            persona = await _fetch_persona_by_id(persona_id)
            return render_persona_detail_html(persona_id=persona_id, persona=persona)

        return await cached_render(
            cache_prefix="persona_detail_html",
            key_suffix=f"{persona_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://personas/{persona_id}.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the per-persona detail surface. "
            "Mirrors the HTML layout (title + chips \u2192 overview "
            "\u2192 why target \u2192 campaign approach \u2192 key "
            "signals \u2192 related-surface pointers) as markdown. Use "
            "this when your client can't render inline HTML."
        ),
    )
    async def persona_detail_text(persona_id: str) -> str:
        """Plaintext app surface - single persona drilldown."""

        async def _do() -> str:
            persona = await _fetch_persona_by_id(persona_id)
            return render_persona_detail_text_fallback(
                persona_id=persona_id, persona=persona
            )

        return await cached_render(
            cache_prefix="persona_detail_text",
            key_suffix=f"{persona_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #64 - Per-list detail (templated).                          #
    # URI: `g8://lists/{list_id}` (+ `.txt` sibling).                    #
    # 2-segment TEMPLATE. Distinct from:                                 #
    #   - static 2-seg `g8://lists/dashboard` (surface #5) - FastMCP     #
    #     ResourceManager checks the static `_resources` dict FIRST,     #
    #     so `dashboard` always wins when it's the exact literal URI.    #
    #     Same pattern shipped safely in surfaces #58 (contacts), #59    #
    #     (companies), #62 (icps), #63 (personas).                        #
    #   - 3-seg template `g8://lists/{list_id}/contacts` (surface #38) - #
    #     different segment count, no collision.                          #
    # Backed by: `GET /lists?limit=200` then client-side filter by       #
    # `id`. List ids are **integers** in the API but arrive as strings   #
    # in the URI template, so the matcher coerces both sides to str.    #
    # ------------------------------------------------------------------ #

    async def _fetch_list_by_id(list_id: str) -> dict | None:
        """Load a single list by id. Returns None when not found / unavailable.

        Developer API exposes `GET /lists` returning `{data: [...]}`;
        there is no per-id endpoint, so we filter client-side. List ids
        are **int** in the response payload but **str** in the URI
        template, so we coerce both sides to str for comparison. Returns
        None for both unavailable (backend error) and not-found (id
        absent) so the renderer can distinguish via the URI payload vs
        None result.
        """
        try:
            raw = await client.get("/lists", {"limit": 200})
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://lists/%s backend error %s: %s",
                list_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        if not isinstance(raw, dict):
            return None
        data = raw.get("data")
        if not isinstance(data, list):
            return None
        needle = str(list_id).strip()
        for list_obj in data:
            if not isinstance(list_obj, dict):
                continue
            if str(list_obj.get("id")) == needle:
                return list_obj
        return None

    @server.resource(
        "g8://lists/{list_id}",
        mime_type="text/html",
        description=(
            "Single-list drilldown - header with title + dynamic-vs-"
            "static badge + type / status chips (each bucketed on the "
            "graph8 palette: contacts/leads=primary, companies=positive, "
            "suppressions=warning, else=muted; active=positive, "
            "processing=primary, error=warning, archived=muted), "
            "four-card KPI quadrant (Total Members / Type / Status / "
            "Updated), metadata section (source + created + created by + "
            "updated + id), and tags chip cluster. Complements "
            "g8://lists/dashboard (grid of all lists \u2014 this one is "
            "a single-list detail) and g8://lists/{list_id}/contacts "
            "(drill into the list's contact members). "
            "URI-templated by list_id. Renders inline in Claude.ai; "
            "other clients fall back to the .txt sibling."
        ),
    )
    async def list_detail_html(list_id: str) -> str:
        """HTML app surface - single list drilldown."""

        async def _do() -> str:
            list_obj = await _fetch_list_by_id(list_id)
            return render_list_detail_html(list_id=list_id, list_obj=list_obj)

        return await cached_render(
            cache_prefix="list_detail_html",
            key_suffix=f"{list_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://lists/{list_id}.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the per-list detail surface. "
            "Mirrors the HTML layout (title + chips \u2192 KPIs "
            "\u2192 metadata \u2192 tags \u2192 related-surface "
            "pointers) as markdown. Use this when your client can't "
            "render inline HTML."
        ),
    )
    async def list_detail_text(list_id: str) -> str:
        """Plaintext app surface - single list drilldown."""

        async def _do() -> str:
            list_obj = await _fetch_list_by_id(list_id)
            return render_list_detail_text_fallback(
                list_id=list_id, list_obj=list_obj
            )

        return await cached_render(
            cache_prefix="list_detail_text",
            key_suffix=f"{list_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #65 - Per-global-context-document detail (templated).       #
    # URI: `g8://global-context/documents/{doc_id}` (+ `.txt` sibling).  #
    # 3-segment TEMPLATE. Distinct from:                                 #
    #   - 2-seg static `g8://global-context/library` (surface #15) -     #
    #     different segment count, no collision.                          #
    # Backed by: `GET /global-context/documents?limit=200` then client-  #
    # side filter by `id` (no per-id endpoint in developer_api).         #
    # ------------------------------------------------------------------ #

    async def _fetch_gc_doc_by_id(doc_id: str) -> dict | None:
        """Load a single global-context document by id. None on miss/unavailable."""
        try:
            raw = await client.get(
                "/global-context/documents",
                {"limit": 200},
            )
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://global-context/documents/%s backend error %s: %s",
                doc_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        needle = str(doc_id).strip()
        if isinstance(raw, list):
            items = raw
        elif isinstance(raw, dict):
            items = raw.get("documents")
            if not isinstance(items, list):
                items = raw.get("data")
        else:
            return None
        if not isinstance(items, list):
            return None
        for doc in items:
            if not isinstance(doc, dict):
                continue
            if str(doc.get("id")).strip() == needle:
                return doc
        return None

    @server.resource(
        "g8://global-context/documents/{doc_id}",
        mime_type="text/html",
        description=(
            "Single-document drilldown from Studio's 44-doc global "
            "context library \u2014 header with display name + "
            "category / file-type / status chips (category bucketed "
            "on the graph8 palette: context docs = primary, "
            "intelligence docs = positive, research docs = warning), "
            "four-card KPI row (Priority / Version / Category / "
            "Updated), full document body (escaped + newline\u2192br, "
            "clipped at 20k chars), metadata section (folder path + "
            "timestamps + id), and drill-up pointers. Complements "
            "g8://global-context/library (grid of all 44 docs \u2014 "
            "this one is a single-document detail). URI-templated by "
            "doc_id. Renders inline in Claude.ai; other clients fall "
            "back to the .txt sibling."
        ),
    )
    async def gc_doc_detail_html(doc_id: str) -> str:
        """HTML app surface - single global-context document drilldown."""

        async def _do() -> str:
            doc = await _fetch_gc_doc_by_id(doc_id)
            return render_gc_doc_detail_html(doc_id=doc_id, doc=doc)

        return await cached_render(
            cache_prefix="gc_doc_detail_html",
            key_suffix=f"{doc_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://global-context/documents/{doc_id}.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the per-global-context-document "
            "detail surface. Mirrors the HTML layout (title + chips "
            "\u2192 KPIs \u2192 content \u2192 metadata \u2192 "
            "related-surface pointers) as markdown. Use this when "
            "your client can't render inline HTML."
        ),
    )
    async def gc_doc_detail_text(doc_id: str) -> str:
        """Plaintext app surface - single global-context document drilldown."""

        async def _do() -> str:
            doc = await _fetch_gc_doc_by_id(doc_id)
            return render_gc_doc_detail_text_fallback(
                doc_id=doc_id, doc=doc
            )

        return await cached_render(
            cache_prefix="gc_doc_detail_text",
            key_suffix=f"{doc_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #66 - Copilot Home hub (`g8://copilot/home`).               #
    #                                                                    #
    # Org-scoped 2-seg static URI. Entry-point hub referenced by every   #
    # detail surface's drill-up card (#58-#65). No backend endpoint -    #
    # the surface compiles statically from known URI map. Activities are #
    # optionally hydrated from `/activities` for a "Recent activity"     #
    # section; surface still renders if the activities call fails.       #
    # ------------------------------------------------------------------ #

    async def _fetch_copilot_home_activities() -> list[dict]:
        """Best-effort fetch of recent activities for the hub.

        Graceful degradation: on any failure (backend down, 401, 404,
        malformed payload), return empty list so the hub still renders.
        """
        try:
            raw = await client.get("/activities", {"limit": 10})
        except G8ClientError:
            return []
        except Exception:  # noqa: BLE001
            return []
        if isinstance(raw, list):
            return [a for a in raw if isinstance(a, dict)]
        if isinstance(raw, dict):
            for key in ("activities", "items", "data"):
                items = raw.get(key)
                if isinstance(items, list):
                    return [a for a in items if isinstance(a, dict)]
        return []

    @server.resource(
        "g8://copilot/home",
        mime_type="text/html",
        description=(
            "Copilot workspace hub \u2014 the entry point for the "
            "graph8 MCP copilot. Welcome header, four entry cards "
            "(Campaigns / Contacts / Inbox / Deals), an explore grid "
            "grouped by Build / Run / Monitor / Context with 19 "
            "surface URIs, an optional recent-activity section "
            "(hydrated from /activities when the backend is "
            "reachable), and suggested prompts. Every URI is a live "
            "MCP resource; paste into a follow-up turn to drill in. "
            "Renders inline in Claude.ai; other clients fall back to "
            "the .txt sibling."
        ),
    )
    async def copilot_home_html() -> str:
        """HTML app surface - copilot workspace hub."""

        async def _do() -> str:
            activities = await _fetch_copilot_home_activities()
            return render_copilot_home_html(activities=activities)

        return await cached_render(
            cache_prefix="copilot_home_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://copilot/home.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the copilot home hub. Mirrors "
            "the HTML layout (welcome \u2192 entry points \u2192 "
            "explore sections \u2192 recent activity \u2192 suggested "
            "prompts) as markdown. Use this when your client can't "
            "render inline HTML."
        ),
    )
    async def copilot_home_text() -> str:
        """Plaintext app surface - copilot workspace hub."""

        async def _do() -> str:
            activities = await _fetch_copilot_home_activities()
            return render_copilot_home_text_fallback(activities=activities)

        return await cached_render(
            cache_prefix="copilot_home_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #67 - Per-task detail (templated).                         #
    # URI: `g8://tasks/{task_id}` (+ `.txt` sibling).                    #
    # 2-segment TEMPLATE. Distinct from:                                 #
    #   - 2-seg static `g8://tasks/dashboard` (surface #12) -            #
    #     FastMCP ResourceManager checks `_resources` before             #
    #     `_templates`, so the literal `dashboard` URI wins.             #
    # Backed by: `GET /tasks?limit=500` (org-wide list) then client-     #
    # side filter by `id` (no per-id GET endpoint in developer_api).     #
    # ------------------------------------------------------------------ #

    async def _fetch_task_by_id(task_id: str) -> dict | None:
        """Load a single task by id. None on miss/unavailable."""
        try:
            raw = await client.get("/tasks", {"limit": 500})
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://tasks/%s backend error %s: %s",
                task_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        needle = str(task_id).strip()
        if isinstance(raw, list):
            items = raw
        elif isinstance(raw, dict):
            items = raw.get("tasks")
            if not isinstance(items, list):
                items = raw.get("data")
        else:
            return None
        if not isinstance(items, list):
            return None
        for task in items:
            if not isinstance(task, dict):
                continue
            if str(task.get("id")).strip() == needle:
                return task
        return None

    @server.resource(
        "g8://tasks/{task_id}",
        mime_type="text/html",
        description=(
            "Single-task drilldown \u2014 header with title + status "
            "chip / overdue chip / task-type chip, four-card KPI row "
            "(Priority [Urgent/High/Normal/Low mapped from 0-4] / Due "
            "[warning tint when overdue] / Assignee / Updated), "
            "description block (escaped + newline\u2192br, clipped at "
            "10k), metadata section (parent entity + assignee-id + "
            "created-by + timestamps + task-id), and drill-up pointers "
            "that surface the parent contact dynamically when "
            "entity_type=contact. Complements g8://tasks/dashboard "
            "(all tasks at a glance). URI-templated by task_id. Renders "
            "inline in Claude.ai; other clients fall back to the .txt "
            "sibling."
        ),
    )
    async def task_detail_html(task_id: str) -> str:
        """HTML app surface - single task drilldown."""

        async def _do() -> str:
            task = await _fetch_task_by_id(task_id)
            return render_task_detail_html(task_id=task_id, task=task)

        return await cached_render(
            cache_prefix="task_detail_html",
            key_suffix=f"{task_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://tasks/{task_id}.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the per-task detail surface. "
            "Mirrors the HTML layout (title + inline status/overdue/"
            "type \u2192 KPIs \u2192 description \u2192 metadata "
            "\u2192 related-surface pointers with parent-contact drill-"
            "up when applicable) as markdown. Use this when your "
            "client can't render inline HTML."
        ),
    )
    async def task_detail_text(task_id: str) -> str:
        """Plaintext app surface - single task drilldown."""

        async def _do() -> str:
            task = await _fetch_task_by_id(task_id)
            return render_task_detail_text_fallback(
                task_id=task_id, task=task
            )

        return await cached_render(
            cache_prefix="task_detail_text",
            key_suffix=f"{task_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #68 - Per-activity detail (templated).                     #
    # URI: `g8://activities/{activity_id}` (+ `.txt` sibling).           #
    # 2-segment TEMPLATE. Distinct from:                                 #
    #   - 2-seg static `g8://activities/feed` (surface #10) -            #
    #     FastMCP ResourceManager checks `_resources` before             #
    #     `_templates`, so the literal `feed` URI wins.                  #
    # Backed by: `GET /activities?limit=200` (org-wide list) then        #
    # client-side filter by `id` (no per-id GET endpoint exposed in      #
    # developer_api).                                                    #
    # ------------------------------------------------------------------ #

    async def _fetch_activity_by_id(activity_id: str) -> dict | None:
        """Load a single activity by id. None on miss/unavailable."""
        try:
            raw = await client.get("/activities", {"limit": 200})
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://activities/%s backend error %s: %s",
                activity_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        needle = str(activity_id).strip()
        if isinstance(raw, list):
            items = raw
        elif isinstance(raw, dict):
            items = raw.get("activities")
            if not isinstance(items, list):
                items = raw.get("data")
        else:
            return None
        if not isinstance(items, list):
            return None
        for activity in items:
            if not isinstance(activity, dict):
                continue
            if str(activity.get("id")).strip() == needle:
                return activity
        return None

    @server.resource(
        "g8://activities/{activity_id}",
        mime_type="text/html",
        description=(
            "Single-activity drilldown \u2014 header with subject + "
            "inline type / subtype / status / outcome chips (each with "
            "its own semantic accent: calls/emails/messages primary, "
            "meetings/demos/appointments positive, notes muted; "
            "connected/booked/won positive, no-answer/voicemail/bounced "
            "warning), four-card KPI quadrant (Date / Duration "
            "[\"45m\" / \"1h 30m\" / \"2h\"] / Owner / Outcome "
            "[positive/warning tint]), description block (escaped + "
            "newline\u2192br, clipped at 10k), next-steps block, "
            "metadata section (parent contact/company/deal IDs + "
            "owner-id + source + external-id + activity-id), and drill-"
            "up pointers that surface parent contact / company / deal "
            "dynamically when their IDs are populated. Complements "
            "g8://activities/feed (org-wide activity stream). URI-"
            "templated by activity_id. Renders inline in Claude.ai; "
            "other clients fall back to the .txt sibling."
        ),
    )
    async def activity_detail_html(activity_id: str) -> str:
        """HTML app surface - single activity drilldown."""

        async def _do() -> str:
            activity = await _fetch_activity_by_id(activity_id)
            return render_activity_detail_html(
                activity_id=activity_id, activity=activity
            )

        return await cached_render(
            cache_prefix="activity_detail_html",
            key_suffix=f"{activity_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://activities/{activity_id}.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the per-activity detail surface. "
            "Mirrors the HTML layout (subject + inline type / subtype / "
            "status / outcome \u2192 KPIs \u2192 description \u2192 "
            "next-steps \u2192 metadata \u2192 related-surface pointers "
            "with parent contact / company / deal drill-up when "
            "applicable) as markdown. Use this when your client can't "
            "render inline HTML."
        ),
    )
    async def activity_detail_text(activity_id: str) -> str:
        """Plaintext app surface - single activity drilldown."""

        async def _do() -> str:
            activity = await _fetch_activity_by_id(activity_id)
            return render_activity_detail_text_fallback(
                activity_id=activity_id, activity=activity
            )

        return await cached_render(
            cache_prefix="activity_detail_text",
            key_suffix=f"{activity_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #69 - Per-company activities (templated).                  #
    # URI: `g8://companies/{company_id}/activities` (+ `.txt` sibling).  #
    # 3-segment TEMPLATE. Siblings:                                      #
    #   - g8://companies/{company_id}           (profile, #26)           #
    #   - g8://companies/{company_id}/notes     (notes, #37)             #
    #   - g8://companies/{company_id}/deals     (deals, #41)             #
    #   - g8://companies/{company_id}/contacts  (contacts, #46)          #
    # Cousins:                                                           #
    #   - g8://activities/feed                  (org-wide feed, #10)     #
    #   - g8://contacts/{contact_id}/activities (per-contact, #53)       #
    #   - g8://activities/{activity_id}         (per-activity detail #68)#
    # Backed by: `GET /activities?company_id={id}&limit=100`.            #
    # ------------------------------------------------------------------ #

    async def _fetch_company_activities(
        company_id: str,
    ) -> list[dict] | None:
        """Load activities filtered by company_id. None on miss/unavailable.

        Response shape tolerant: accepts bare list, `{data: [...]}`, or
        `{activities: [...]}`.
        """
        try:
            raw = await client.get(
                "/activities",
                {"company_id": company_id, "limit": 100},
            )
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://companies/%s/activities backend error %s: %s",
                company_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        if isinstance(raw, list):
            return raw
        if isinstance(raw, dict):
            for key in ("activities", "data", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    return val
        return None

    @server.resource(
        "g8://companies/{company_id}/activities",
        mime_type="text/html",
        description=(
            "Company activities \u2014 per-company activity timeline for "
            "ONE company. Shows total / calls / emails / meetings in a "
            "stat grid, a type-breakdown pill row (call / email / "
            "meeting / note / task / sms with count + %), and a "
            "chronological timeline of the 25 most recent activities "
            "(type badge + subject + description + outcome + next-steps "
            "+ subtype/status/duration/contact/source chips + date + "
            "owner). Empty-state covers both missing-company "
            "(\"activities not available\") and zero-activities "
            "(\"no activities yet\"). URI-templated by company_id. "
            "Renders inline in Claude.ai; other clients fall back to "
            "the sibling .txt resource. Complements g8://companies/"
            "{company_id} (profile), /notes (notes timeline), /deals "
            "(deal roster), /contacts (contact roster), and the "
            "org-wide g8://activities/feed."
        ),
    )
    async def company_activities_html(company_id: str) -> str:
        """HTML app surface - per-company activities timeline."""

        async def _do() -> str:
            activities = await _fetch_company_activities(company_id)
            company_meta = (
                await _fetch_company_for_notes(company_id)
                if activities is not None and activities
                else None
            )
            return render_company_activities_html(
                activities=activities,
                company_id=company_id,
                company_meta=company_meta,
            )

        return await cached_render(
            cache_prefix="company_activities_html",
            key_suffix=f"{company_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://companies/{company_id}/activities.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the per-company activities surface. "
            "Mirrors the HTML layout (stats \u2192 type breakdown "
            "\u2192 timeline \u2192 drill-up pointers) as markdown. Use "
            "this when your client can't render inline HTML."
        ),
    )
    async def company_activities_text(company_id: str) -> str:
        """Plaintext app surface - per-company activities timeline."""

        async def _do() -> str:
            activities = await _fetch_company_activities(company_id)
            company_meta = (
                await _fetch_company_for_notes(company_id)
                if activities is not None and activities
                else None
            )
            return render_company_activities_text_fallback(
                activities=activities,
                company_id=company_id,
                company_meta=company_meta,
            )

        return await cached_render(
            cache_prefix="company_activities_text",
            key_suffix=f"{company_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #70 - Per-deal activities (templated).                     #
    # URI: `g8://deals/{deal_id}/activities` (+ `.txt` sibling).         #
    # 3-segment TEMPLATE. Completes the entity→activities drill matrix:  #
    #   - #10 g8://activities/feed                   (org-wide)          #
    #   - #53 g8://contacts/{contact_id}/activities  (per-contact)       #
    #   - #68 g8://activities/{activity_id}          (per-activity)      #
    #   - #69 g8://companies/{company_id}/activities (per-company)       #
    #   - #70 g8://deals/{deal_id}/activities        (per-deal)          #
    # Parent 2-seg template `g8://deals/{deal_id}` (#24) must not        #
    # collide - FastMCP's regex discriminates by segment count.          #
    # Backed by: `GET /activities?deal_id={id}&limit=100`.               #
    # ------------------------------------------------------------------ #

    async def _fetch_deal_activities(
        deal_id: str,
    ) -> list[dict] | None:
        """Load activities filtered by deal_id. None on miss/unavailable.

        Response shape tolerant: accepts bare list, `{data: [...]}`, or
        `{activities: [...]}`.
        """
        try:
            raw = await client.get(
                "/activities",
                {"deal_id": deal_id, "limit": 100},
            )
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://deals/%s/activities backend error %s: %s",
                deal_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001
            return None

        if isinstance(raw, list):
            return raw
        if isinstance(raw, dict):
            for key in ("activities", "data", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    return val
        return None

    @server.resource(
        "g8://deals/{deal_id}/activities",
        mime_type="text/html",
        description=(
            "Deal activities \u2014 per-deal activity timeline for ONE "
            "opportunity. Shows total / calls / emails / meetings in a "
            "stat grid, a type-breakdown pill row (call / email / "
            "meeting / note / task / sms with count + %), and a "
            "chronological timeline of the 25 most recent activities "
            "(type badge + subject + description + outcome + next-steps "
            "+ subtype/status/duration/contact/source chips + date + "
            "owner). Each row carries a contact chip so reps can tell "
            "which contact at the deal each touch belongs to. "
            "Empty-state covers both missing-deal (\"activities not "
            "available\") and zero-activities (\"no activities yet\"). "
            "URI-templated by deal_id. Renders inline in Claude.ai; "
            "other clients fall back to the sibling .txt resource. "
            "Complements g8://deals/{deal_id} (profile, #24), "
            "g8://deals/dashboard (pipeline), g8://activities/feed "
            "(org-wide), g8://contacts/{contact_id}/activities (per-"
            "contact, #53), g8://companies/{company_id}/activities "
            "(per-company, #69), and g8://activities/{activity_id} "
            "(per-activity detail, #68)."
        ),
    )
    async def deal_activities_html(deal_id: str) -> str:
        """HTML app surface - per-deal activities timeline."""

        async def _do() -> str:
            activities = await _fetch_deal_activities(deal_id)
            deal_meta = (
                await _fetch_deal_detail(deal_id)
                if activities is not None and activities
                else None
            )
            return render_deal_activities_html(
                activities=activities,
                deal_id=deal_id,
                deal_meta=deal_meta,
            )

        return await cached_render(
            cache_prefix="deal_activities_html",
            key_suffix=f"{deal_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://deals/{deal_id}/activities.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for the per-deal activities surface. "
            "Mirrors the HTML layout (stats \u2192 type breakdown "
            "\u2192 timeline \u2192 drill-up pointers) as markdown. Use "
            "this when your client can't render inline HTML."
        ),
    )
    async def deal_activities_text(deal_id: str) -> str:
        """Plaintext app surface - per-deal activities timeline."""

        async def _do() -> str:
            activities = await _fetch_deal_activities(deal_id)
            deal_meta = (
                await _fetch_deal_detail(deal_id)
                if activities is not None and activities
                else None
            )
            return render_deal_activities_text_fallback(
                activities=activities,
                deal_id=deal_id,
                deal_meta=deal_meta,
            )

        return await cached_render(
            cache_prefix="deal_activities_text",
            key_suffix=f"{deal_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )


    # ================================================================
    # Surface #71 - Per-sequence-step detail (4-seg templated URI).
    # URI: g8://sequences/{sequence_id}/steps/{step_id}
    #
    # Backend: reuses GET /sequences/{sequence_id}/preview (Surface #6).
    # The preview endpoint returns the sequence with its `steps` array
    # inline - we filter client-side to find the target step_id. Same
    # strategy as Surfaces #65/#67/#68 (no per-step GET endpoint exists
    # in developer_api).
    #
    # Collision safety: 4-segment template coexists with 3-seg
    # templates (preview/overview/analytics/contacts) and the 2-seg
    # static dashboard - FastMCP's URI-regex dispatcher disambiguates
    # by segment count + suffix.
    # ================================================================

    async def _fetch_sequence_preview_for_step(
        sequence_id: str,
    ) -> dict | None:
        """Fetch the preview for a sequence, or None on 404/error.

        Response shape: ApiResponse-wrapped SequencePreviewResponse
        `{"data": {"id": ..., "steps": [...], ...}}`. We unwrap and
        return the inner dict so the renderer only sees the preview
        body (not the `{data: ...}` envelope).
        """
        try:
            raw = await client.get(f"/sequences/{sequence_id}/preview")
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://sequences/%s/steps/* backend error %s: %s",
                sequence_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001 - defensive
            return None

        if isinstance(raw, dict):
            # Unwrap ApiResponse {"data": {...}} envelope if present.
            data = raw.get("data")
            if isinstance(data, dict):
                return data
            # Some endpoints return the preview body directly.
            if "steps" in raw or "id" in raw:
                return raw
        return None

    @server.resource(
        "g8://sequences/{sequence_id}/steps/{step_id}",
        mime_type="text/html",
        description=(
            "Sequence step detail \u2014 per-step drilldown within a "
            "sequence. Shows step order, step_type, input_type, delay "
            "(time_interval, human-formatted), and the step's content "
            "(email subject + body for email steps; message for "
            "linkedin/sms steps; title + description for task steps; "
            "wait duration for wait steps). Includes a mini "
            "prev/current/next sibling strip (up to 5 steps centered on "
            "the current one) so reps see the sequence flow at a "
            "glance. Empty-state covers both missing-sequence (preview "
            "unavailable) and missing-step (no matching step_id in the "
            "sequence's steps array). URI-templated by sequence_id + "
            "step_id (4-segment). Renders inline in Claude.ai; other "
            "clients fall back to the sibling .txt resource. "
            "Complements g8://sequences/{sequence_id}/overview (#47), "
            "g8://sequences/{sequence_id}/preview (#6), "
            "g8://sequences/{sequence_id}/analytics (#23), "
            "g8://sequences/{sequence_id}/contacts (#40), and "
            "g8://sequences/dashboard (#9)."
        ),
    )
    async def sequence_step_detail_html(
        sequence_id: str, step_id: str
    ) -> str:
        """HTML app surface \u2014 per-sequence-step detail."""

        async def _do() -> str:
            preview = await _fetch_sequence_preview_for_step(sequence_id)
            return render_sequence_step_detail_html(
                preview=preview,
                sequence_id=sequence_id,
                step_id=step_id,
            )

        return await cached_render(
            cache_prefix="sequence_step_detail_html",
            key_suffix=f"{sequence_id}:{step_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://sequences/{sequence_id}/steps/{step_id}.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for g8://sequences/{sequence_id}/steps/"
            "{step_id}. Same content as the HTML surface, formatted as "
            "markdown."
        ),
    )
    async def sequence_step_detail_text(
        sequence_id: str, step_id: str
    ) -> str:
        """Plaintext app surface \u2014 per-sequence-step detail."""

        async def _do() -> str:
            preview = await _fetch_sequence_preview_for_step(sequence_id)
            return render_sequence_step_detail_text_fallback(
                preview=preview,
                sequence_id=sequence_id,
                step_id=step_id,
            )

        return await cached_render(
            cache_prefix="sequence_step_detail_text",
            key_suffix=f"{sequence_id}:{step_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )


    # ================================================================
    # Surface #72 - Per-sequence inbox (3-seg templated URI).
    # URI: g8://sequences/{sequence_id}/inbox
    #
    # Backend: reuses GET /inbox?sequence_id={id} (unified-inbox feed
    # filtered server-side by campaign_ids=[sequence_id]). Optionally
    # supplements with GET /sequences/{sequence_id}/preview to look up
    # the sequence name for the page header.
    #
    # Collision safety: 3-segment template with /inbox suffix is
    # disjoint from siblings /overview /preview /analytics /contacts
    # and the 4-seg /steps/{step_id} template. FastMCP URI-regex
    # discriminates by literal suffix + segment count.
    # ================================================================

    async def _fetch_sequence_inbox_threads(
        sequence_id: str,
    ) -> list | None:
        """Fetch inbox threads filtered by sequence_id.

        Returns the `data` list from GET /inbox?sequence_id={id} on
        success, an empty list on 404, and None on other errors so the
        renderer can distinguish "no threads" from "inbox unavailable".
        """
        try:
            raw = await client.get(
                "/inbox",
                {"sequence_id": sequence_id, "page": 1, "page_size": 50},
            )
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://sequences/%s/inbox backend error %s: %s",
                sequence_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001 - defensive
            return None

        if isinstance(raw, dict):
            data = raw.get("data")
            if isinstance(data, list):
                return data
            if "threads" in raw and isinstance(raw["threads"], list):
                return raw["threads"]
        if isinstance(raw, list):
            return raw
        return []

    async def _fetch_sequence_inbox_preview(
        sequence_id: str,
    ) -> dict | None:
        """Fetch the preview body for a sequence (for header label only).

        Returns None on 404/error - the renderer treats that together
        with an empty threads list as the "inbox unavailable" empty
        state. When threads are present but the preview is missing the
        header falls back to `Sequence {id}`.
        """
        try:
            raw = await client.get(f"/sequences/{sequence_id}/preview")
        except G8ClientError as e:
            if e.status_code == 404:
                return None
            logger.warning(
                "g8://sequences/%s/inbox preview lookup error %s: %s",
                sequence_id,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001 - defensive
            return None

        if isinstance(raw, dict):
            data = raw.get("data")
            if isinstance(data, dict):
                return data
            if "steps" in raw or "id" in raw or "name" in raw:
                return raw
        return None

    @server.resource(
        "g8://sequences/{sequence_id}/inbox",
        mime_type="text/html",
        description=(
            "Sequence replies \u2014 inbox threads scoped to a single "
            "sequence. Shows total/open/responded/ai_responded counts, a "
            "channel breakdown (email/sms/linkedin), and a capped list "
            "(first 25) of threads with subject, contact, channel + "
            "status badges, tags, assignee, message count, and a short "
            "preview of the last message. Each thread carries a "
            "drill-down pointer (g8://inbox/{thread_id}) to the full "
            "thread detail (Surface #20). Empty-state covers both the "
            "missing-sequence (preview unavailable) and zero-replies "
            "(accent-tone) pathways. URI-templated by sequence_id "
            "(3-segment). Renders inline in Claude.ai; other clients "
            "fall back to the sibling .txt resource. Complements "
            "g8://sequences/{sequence_id}/overview (#47), "
            "g8://sequences/{sequence_id}/preview (#6), "
            "g8://sequences/{sequence_id}/analytics (#23), "
            "g8://sequences/{sequence_id}/contacts (#40), and "
            "g8://sequences/{sequence_id}/steps/{step_id} (#71)."
        ),
    )
    async def sequence_inbox_html(sequence_id: str) -> str:
        """HTML app surface \u2014 per-sequence inbox."""

        async def _do() -> str:
            threads = await _fetch_sequence_inbox_threads(sequence_id)
            preview = await _fetch_sequence_inbox_preview(sequence_id)
            return render_sequence_inbox_html(
                threads=threads,
                preview=preview,
                sequence_id=sequence_id,
            )

        return await cached_render(
            cache_prefix="sequence_inbox_html",
            key_suffix=f"{sequence_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://sequences/{sequence_id}/inbox.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for g8://sequences/{sequence_id}/inbox. "
            "Same content as the HTML surface, formatted as markdown."
        ),
    )
    async def sequence_inbox_text(sequence_id: str) -> str:
        """Plaintext app surface \u2014 per-sequence inbox."""

        async def _do() -> str:
            threads = await _fetch_sequence_inbox_threads(sequence_id)
            preview = await _fetch_sequence_inbox_preview(sequence_id)
            return render_sequence_inbox_text_fallback(
                threads=threads,
                preview=preview,
                sequence_id=sequence_id,
            )

        return await cached_render(
            cache_prefix="sequence_inbox_text",
            key_suffix=f"{sequence_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )


    # ================================================================
    # Surface #73 - Channel-scoped inbox (3-seg templated URI).
    # URI: g8://inbox/channels/{channel}
    #
    # Backend: reuses GET /inbox?channel={channel}&page=1&page_size=50
    # (inbox_router accepts an InboxChannel enum - email / sms /
    # linkedin - and maps linkedin internally to heyreach).
    # ================================================================

    async def _fetch_inbox_channel_threads(channel: str) -> list | None:
        """Fetch the channel-scoped inbox threads list, None on error.

        `channel` is the raw URI segment. The backend endpoint accepts
        email / sms / linkedin - no validation here because the
        renderer surfaces a dedicated "invalid channel" empty-state
        that names the bad segment back to the user.

        Response shape: ApiResponse-wrapped list
        `{"data": [ {thread1}, {thread2}, ... ]}`. We unwrap and return
        the list so the renderer only sees threads.
        """
        try:
            raw = await client.get(
                "/inbox",
                {"channel": channel, "page": 1, "page_size": 50},
            )
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            # 400 typically means invalid channel - let the renderer
            # fall through to the invalid-channel empty-state instead
            # of swallowing it.
            if e.status_code == 400:
                return None
            logger.warning(
                "g8://inbox/channels/%s backend error %s: %s",
                channel,
                e.status_code,
                e,
            )
            return None
        except Exception:  # noqa: BLE001 - defensive
            return None

        if isinstance(raw, dict):
            data = raw.get("data")
            if isinstance(data, list):
                return data
            if "threads" in raw and isinstance(raw["threads"], list):
                return raw["threads"]
        if isinstance(raw, list):
            return raw
        return []

    @server.resource(
        "g8://inbox/channels/{channel}",
        mime_type="text/html",
        description=(
            "Channel-scoped inbox - shows reply threads for a single "
            "channel (email / sms / linkedin). Complements g8://inbox/"
            "dashboard (org-wide, all channels) and g8://sequences/"
            "{sequence_id}/inbox (sequence-scoped, all channels). "
            "Renders header + channel chip + 4-card stats row (Total / "
            "Open / Responded / AI-responded) + thread list (50-row "
            "cap with overflow banner) + drill-up to sibling channel "
            "surfaces and backend filter URL. Invalid channel → "
            "dedicated 'channel unavailable' empty-state; populated-"
            "but-no-replies → 'No {channel} replies yet' zero-state "
            "(accent tone). URI-templated by channel (3-segment). "
            "Renders inline in Claude.ai; other clients fall back to "
            "the sibling .txt resource. Complements g8://inbox/"
            "dashboard (#16), g8://inbox/threads/{reply_id} (#30), "
            "g8://inbox/threads/{reply_id}/draft (#51), and "
            "g8://sequences/{sequence_id}/inbox (#72)."
        ),
    )
    async def inbox_channel_html(channel: str) -> str:
        """HTML app surface - channel-scoped inbox."""

        async def _do() -> str:
            threads = await _fetch_inbox_channel_threads(channel)
            return render_inbox_channel_html(
                threads=threads, channel=channel
            )

        return await cached_render(
            cache_prefix="inbox_channel_html",
            key_suffix=f"{channel}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://inbox/channels/{channel}.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for g8://inbox/channels/{channel}. "
            "Same content as the HTML surface, formatted as markdown."
        ),
    )
    async def inbox_channel_text(channel: str) -> str:
        """Plaintext app surface - channel-scoped inbox."""

        async def _do() -> str:
            threads = await _fetch_inbox_channel_threads(channel)
            return render_inbox_channel_text_fallback(
                threads=threads, channel=channel
            )

        return await cached_render(
            cache_prefix="inbox_channel_text",
            key_suffix=f"{channel}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # =================================================================
    # Surface #74 - Status-scoped tasks pane (3-segment template)
    #
    #   URI: g8://tasks/status/{status}  (HTML + .txt)
    #   Backend: GET /tasks?status={status}&limit=100
    #
    # Sibling safety (FastMCP URI dispatcher discriminates by segment
    # count + literal prefix):
    #   - 2-seg static g8://tasks/dashboard (#12) - in _resources
    #   - 2-seg template g8://tasks/{task_id} (#67) - in _templates
    #   - 3-seg template g8://tasks/status/{status} (#74) - in
    #     _templates, NEW. Literal /status/ prefix prevents cross-match
    #     with the {task_id} template.
    # =================================================================

    async def _fetch_tasks_status(status: str) -> list | None:
        """Fetch tasks filtered by status. Returns None on backend error.

        Invalid status values (per renderer's _tasks_status_normalize)
        are NOT filtered here - the renderer's empty-state handles
        unknown statuses. Backend 4xx/5xx → None so the renderer emits
        the 'unavailable' empty state.
        """
        try:
            raw = await client.get(
                "/tasks", {"status": status, "limit": 100}
            )
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://tasks/status/%s backend error %s: %s",
                status, e.status_code, e,
            )
            return None
        except Exception:  # noqa: BLE001 - defensive
            return None

        if isinstance(raw, dict):
            data = raw.get("data")
            if isinstance(data, list):
                return data
            if "tasks" in raw and isinstance(raw["tasks"], list):
                return raw["tasks"]
        if isinstance(raw, list):
            return raw
        return []

    @server.resource(
        "g8://tasks/status/{status}",
        mime_type="text/html",
        description=(
            "Status-scoped tasks pane - shows all tasks in a single "
            "status (open / in_progress / blocked / completed / "
            "cancelled). Complements g8://tasks/dashboard (org-wide, "
            "all statuses, #12) and g8://tasks/{task_id} (single-task "
            "detail, #67). Renders header + 4-card stats row (Total / "
            "Overdue / High-priority / Assigned) + task list (100-row "
            "cap with overflow banner) + drill-up to sibling status "
            "surfaces and backend filter URL. Invalid status → "
            "dedicated 'status unavailable' empty-state; valid-but-"
            "empty → 'No {Status} tasks' zero-state (accent tone). "
            "URI-templated by status (3-segment). Renders inline in "
            "Claude.ai; other clients fall back to the sibling .txt "
            "resource."
        ),
    )
    async def tasks_status_html(status: str) -> str:
        """HTML app surface - status-scoped tasks pane."""

        async def _do() -> str:
            tasks = await _fetch_tasks_status(status)
            return render_tasks_status_html(tasks=tasks, status=status)

        return await cached_render(
            cache_prefix="tasks_status_html",
            key_suffix=f"{status}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://tasks/status/{status}.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for g8://tasks/status/{status}. Same "
            "content as the HTML surface, formatted as markdown."
        ),
    )
    async def tasks_status_text(status: str) -> str:
        """Plaintext app surface - status-scoped tasks pane."""

        async def _do() -> str:
            tasks = await _fetch_tasks_status(status)
            return render_tasks_status_text_fallback(
                tasks=tasks, status=status
            )

        return await cached_render(
            cache_prefix="tasks_status_text",
            key_suffix=f"{status}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ===================================================================
    # Surface #75 - Priority-scoped tasks pane
    # URI: g8://tasks/priority/{priority}  (3-seg template under tasks/)
    # Backend: GET /tasks?priority={int}&limit=100
    # Safe vs #67 (2-seg {task_id}) and #74 (3-seg /status/{status}) -
    # FastMCP's segment-count + literal-prefix dispatch resolves each
    # template unambiguously. Verified by integration test.
    # ===================================================================

    async def _fetch_tasks_priority(priority: str) -> list | None:
        """Fetch tasks at a given priority level.

        Maps the canonical URI key (p1-p4 or alias) to the backend
        integer (1-4). Invalid keys → None so renderer emits the
        'unavailable' empty state. Backend 4xx/5xx → None for the same
        reason.
        """
        from g8_mcp_server.app_renderer import _tasks_priority_to_int

        backend_int = _tasks_priority_to_int(priority)
        if backend_int is None:
            # Invalid URI param. Renderer's empty-state handles it -
            # but we must return None (not []) so render sees 'backend
            # error' path and renders the 'unavailable' message that
            # lists the valid values.
            return None

        try:
            raw = await client.get(
                "/tasks", {"priority": backend_int, "limit": 100}
            )
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://tasks/priority/%s backend error %s: %s",
                priority, e.status_code, e,
            )
            return None
        except Exception:  # noqa: BLE001 - defensive
            return None

        if isinstance(raw, dict):
            data = raw.get("data")
            if isinstance(data, list):
                return data
            if "tasks" in raw and isinstance(raw["tasks"], list):
                return raw["tasks"]
        if isinstance(raw, list):
            return raw
        return []

    @server.resource(
        "g8://tasks/priority/{priority}",
        mime_type="text/html",
        description=(
            "Priority-scoped tasks pane - shows all tasks at a single "
            "priority level (p1 / p2 / p3 / p4, or urgent / high / "
            "medium / low). Complements g8://tasks/dashboard (org-wide, "
            "all priorities, #12), g8://tasks/{task_id} (single-task "
            "detail, #67), and g8://tasks/status/{status} (status "
            "filter, #74). Renders header + 4-card stats row (Total / "
            "Overdue / Open / Assigned) + task list (100-row cap with "
            "overflow banner) + drill-up to sibling priority surfaces, "
            "cross-axis status pane, and backend filter URL. Invalid "
            "priority → dedicated 'priority unavailable' empty-state; "
            "valid-but-empty → 'No {Priority} tasks' zero-state (accent "
            "tone). URI-templated by priority (3-segment). Renders "
            "inline in Claude.ai; other clients fall back to the "
            "sibling .txt resource."
        ),
    )
    async def tasks_priority_html(priority: str) -> str:
        """HTML app surface - priority-scoped tasks pane."""

        async def _do() -> str:
            tasks = await _fetch_tasks_priority(priority)
            return render_tasks_priority_html(
                tasks=tasks, priority=priority
            )

        return await cached_render(
            cache_prefix="tasks_priority_html",
            key_suffix=f"{priority}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://tasks/priority/{priority}.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for g8://tasks/priority/{priority}. "
            "Same content as the HTML surface, formatted as markdown."
        ),
    )
    async def tasks_priority_text(priority: str) -> str:
        """Plaintext app surface - priority-scoped tasks pane."""

        async def _do() -> str:
            tasks = await _fetch_tasks_priority(priority)
            return render_tasks_priority_text_fallback(
                tasks=tasks, priority=priority
            )

        return await cached_render(
            cache_prefix="tasks_priority_text",
            key_suffix=f"{priority}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # -------- Surface #76 - g8://contacts/seniority/{seniority} --------

    async def _fetch_contacts_seniority(seniority: str) -> list | None:
        """Fetch contacts filtered by seniority tier; None on invalid key /
        backend error (renderer emits 'unavailable' state - saves backend traffic).

        Backend behavior: `GET /contacts?seniority_level=<key>` (exact match,
        contacts_router.py:59). We pass the normalized canonical key.
        """
        from g8_mcp_server.app_renderer import _contacts_seniority_normalize

        normalized = _contacts_seniority_normalize(seniority)
        if normalized is None:
            return None
        try:
            raw = await client.get(
                "/contacts",
                {"seniority_level": normalized, "limit": 100},
            )
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://contacts/seniority/%s backend error %s: %s",
                normalized, e.status_code, e,
            )
            return None
        except Exception:
            return None
        if isinstance(raw, dict):
            data = raw.get("data")
            if isinstance(data, list):
                return data
            if "contacts" in raw and isinstance(raw["contacts"], list):
                return raw["contacts"]
        if isinstance(raw, list):
            return raw
        return []

    @server.resource(
        "g8://contacts/seniority/{seniority}",
        mime_type="text/html",
        description=(
            "Contacts filtered by seniority tier. Accepts canonical keys "
            "(`c_suite`, `executive`, `founder`, `vp`, `director`, `head`, "
            "`manager`, `lead`, `senior`, `ic`, `entry`) plus common "
            "aliases (`ceo`/`svp`/`mgr`/`jr` etc.). Backend: "
            "`GET /contacts?seniority_level=<key>` (exact match, contacts_router)."
        ),
    )
    async def contacts_seniority_html(seniority: str) -> str:
        """HTML app surface - seniority-scoped contacts pane."""

        async def _do() -> str:
            contacts = await _fetch_contacts_seniority(seniority)
            return render_contacts_seniority_html(
                contacts=contacts, seniority=seniority
            )

        return await cached_render(
            cache_prefix="contacts_seniority_html",
            key_suffix=f"{seniority}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://contacts/seniority/{seniority}.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for g8://contacts/seniority/{seniority}. "
            "Same content as the HTML surface, formatted as markdown."
        ),
    )
    async def contacts_seniority_text(seniority: str) -> str:
        """Plaintext app surface - seniority-scoped contacts pane."""

        async def _do() -> str:
            contacts = await _fetch_contacts_seniority(seniority)
            return render_contacts_seniority_text_fallback(
                contacts=contacts, seniority=seniority
            )

        return await cached_render(
            cache_prefix="contacts_seniority_text",
            key_suffix=f"{seniority}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # -------- Surface #77 - g8://contacts/department/{department} --------

    async def _fetch_contacts_department(department: str) -> list | None:
        """Fetch contacts filtered by job department; None on invalid key /
        backend error (renderer emits 'unavailable' state - saves backend traffic).

        Backend behavior: `GET /contacts?job_department=<key>` (ILIKE partial
        match, contacts_router.py:117). We pass the normalized canonical key
        (e.g. 'customer_success') and rely on the backend ILIKE to match
        variants like 'Customer Success', 'CustomerSuccess', 'customer-success'.
        """
        from g8_mcp_server.app_renderer import _contacts_department_normalize

        normalized = _contacts_department_normalize(department)
        if normalized is None:
            return None
        try:
            raw = await client.get(
                "/contacts",
                {"job_department": normalized, "limit": 100},
            )
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://contacts/department/%s backend error %s: %s",
                normalized, e.status_code, e,
            )
            return None
        except Exception:
            return None
        if isinstance(raw, dict):
            data = raw.get("data")
            if isinstance(data, list):
                return data
            if "contacts" in raw and isinstance(raw["contacts"], list):
                return raw["contacts"]
        if isinstance(raw, list):
            return raw
        return []

    @server.resource(
        "g8://contacts/department/{department}",
        mime_type="text/html",
        description=(
            "Contacts filtered by job department. Accepts canonical keys "
            "(`sales`, `marketing`, `engineering`, `product`, `design`, "
            "`operations`, `customer_success`, `finance`, `hr`, `legal`, "
            "`data`, `it`, `executive`, `support`) plus 100+ common "
            "aliases (`eng`/`mkt`/`cs`/`sdr`/`pm`/`ops`/`devops` etc.). "
            "Cross-axis drill-up links to `g8://contacts/seniority/vp`. "
            "Backend: `GET /contacts?job_department=<key>` (ILIKE partial "
            "match, contacts_router)."
        ),
    )
    async def contacts_department_html(department: str) -> str:
        """HTML app surface - department-scoped contacts pane."""

        async def _do() -> str:
            contacts = await _fetch_contacts_department(department)
            return render_contacts_department_html(
                contacts=contacts, department=department
            )

        return await cached_render(
            cache_prefix="contacts_department_html",
            key_suffix=f"{department}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://contacts/department/{department}.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for g8://contacts/department/{department}. "
            "Same content as the HTML surface, formatted as markdown."
        ),
    )
    async def contacts_department_text(department: str) -> str:
        """Plaintext app surface - department-scoped contacts pane."""

        async def _do() -> str:
            contacts = await _fetch_contacts_department(department)
            return render_contacts_department_text_fallback(
                contacts=contacts, department=department
            )

        return await cached_render(
            cache_prefix="contacts_department_text",
            key_suffix=f"{department}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # -------- Surface #78 - g8://companies/industry/{industry} --------

    async def _fetch_companies_industry(industry: str) -> list | None:
        """Fetch companies filtered by industry; None on invalid key /
        backend error (renderer emits 'unavailable' state - saves backend
        traffic).

        Backend behavior: `GET /companies?industry=<key>` (ILIKE partial
        match, companies_router.py:84). We pass the normalized canonical
        key (e.g. 'saas') and rely on the backend ILIKE to match variants
        like 'SaaS', 'Software as a Service', 'Cloud Computing', etc.
        """
        from g8_mcp_server.app_renderer import _companies_industry_normalize

        normalized = _companies_industry_normalize(industry)
        if normalized is None:
            return None
        try:
            raw = await client.get(
                "/companies",
                {"industry": normalized, "limit": 100},
            )
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://companies/industry/%s backend error %s: %s",
                normalized, e.status_code, e,
            )
            return None
        except Exception:
            return None
        if isinstance(raw, dict):
            data = raw.get("data")
            if isinstance(data, list):
                return data
            if "companies" in raw and isinstance(raw["companies"], list):
                return raw["companies"]
        if isinstance(raw, list):
            return raw
        return []

    @server.resource(
        "g8://companies/industry/{industry}",
        mime_type="text/html",
        description=(
            "Companies filtered by industry. Accepts 16 canonical keys "
            "(`saas`, `fintech`, `healthcare`, `biotech`, `manufacturing`, "
            "`retail`, `ecommerce`, `media`, `education`, `telecom`, "
            "`real_estate`, `professional_services`, `energy`, "
            "`nonprofit`, `hospitality`, `automotive`) plus 180+ common "
            "aliases (`software`/`finance`/`pharma`/`edtech`/`proptech`/"
            "`cleantech`/`auto` etc.). Cross-entity drill-up links to "
            "`g8://contacts/dashboard`. Backend: "
            "`GET /companies?industry=<key>` (ILIKE partial match)."
        ),
    )
    async def companies_industry_html(industry: str) -> str:
        """HTML app surface - industry-scoped companies pane."""

        async def _do() -> str:
            companies = await _fetch_companies_industry(industry)
            return render_companies_industry_html(
                companies=companies, industry=industry
            )

        return await cached_render(
            cache_prefix="companies_industry_html",
            key_suffix=f"{industry}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://companies/industry/{industry}.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for g8://companies/industry/{industry}. "
            "Same content as the HTML surface, formatted as markdown."
        ),
    )
    async def companies_industry_text(industry: str) -> str:
        """Plaintext app surface - industry-scoped companies pane."""

        async def _do() -> str:
            companies = await _fetch_companies_industry(industry)
            return render_companies_industry_text_fallback(
                companies=companies, industry=industry
            )

        return await cached_render(
            cache_prefix="companies_industry_text",
            key_suffix=f"{industry}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # -------- Surface #79 - g8://companies/country/{country} --------

    async def _fetch_companies_country(country: str) -> list | None:
        """Fetch companies filtered by country; None on invalid key /
        backend error (renderer emits 'unavailable' state - zero backend
        traffic).

        Backend behavior: `GET /companies?country=<value>` (EXACT match,
        companies_router.py:91-92). We pass the canonical TITLE-CASE backend
        value (e.g. 'United States', 'United Kingdom') - NOT the URI slug -
        because the backend filter is exact match, not ILIKE.
        """
        from g8_mcp_server.app_renderer import (
            _companies_country_backend_value,
            _companies_country_normalize,
        )

        normalized = _companies_country_normalize(country)
        if normalized is None:
            return None
        backend_value = _companies_country_backend_value(normalized)
        if backend_value is None:
            return None
        try:
            raw = await client.get(
                "/companies",
                {"country": backend_value, "limit": 100},
            )
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://companies/country/%s backend error %s: %s",
                normalized, e.status_code, e,
            )
            return None
        except Exception:
            return None
        if isinstance(raw, dict):
            data = raw.get("data")
            if isinstance(data, list):
                return data
            if "companies" in raw and isinstance(raw["companies"], list):
                return raw["companies"]
        if isinstance(raw, list):
            return raw
        return []

    @server.resource(
        "g8://companies/country/{country}",
        mime_type="text/html",
        description=(
            "Companies filtered by headquarters country. Accepts 20 "
            "canonical slug keys (`united_states`, `united_kingdom`, "
            "`germany`, `france`, `canada`, `australia`, `india`, `japan`, "
            "`brazil`, `mexico`, `netherlands`, `spain`, `italy`, `sweden`, "
            "`switzerland`, `singapore`, `ireland`, `israel`, `china`, "
            "`uae`) plus 100+ common aliases (`us`/`usa`/`uk`/`britain`/"
            "`de`/`fr`/`holland`/`dubai` etc.). Cross-axis drill-up links "
            "to `g8://companies/industry/saas`; cross-entity drill-up links "
            "to `g8://contacts/dashboard`. Backend: "
            "`GET /companies?country=<exact-value>` (EXACT match, URI slug "
            "resolves to canonical TITLE-CASE backend value)."
        ),
    )
    async def companies_country_html(country: str) -> str:
        """HTML app surface - country-scoped companies pane."""

        async def _do() -> str:
            companies = await _fetch_companies_country(country)
            return render_companies_country_html(
                companies=companies, country=country
            )

        return await cached_render(
            cache_prefix="companies_country_html",
            key_suffix=f"{country}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://companies/country/{country}.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for g8://companies/country/{country}. "
            "Same content as the HTML surface, formatted as markdown."
        ),
    )
    async def companies_country_text(country: str) -> str:
        """Plaintext app surface - country-scoped companies pane."""

        async def _do() -> str:
            companies = await _fetch_companies_country(country)
            return render_companies_country_text_fallback(
                companies=companies, country=country
            )

        return await cached_render(
            cache_prefix="companies_country_text",
            key_suffix=f"{country}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # -------- Surface #80 - g8://companies/size/{tier} --------

    async def _fetch_companies_size(tier: str) -> list | None:
        """Fetch companies filtered by employee-count RANGE; None on invalid
        key / backend error (renderer emits 'unavailable' state).

        Backend behavior: `GET /companies?employee_count_min=X&employee_count_max=Y`
        (companies_router.py:55-56 + 87-90). URI slug resolves to (min,max|None)
        tuple via `_COMPANIES_SIZE_RANGE`; max=None (enterprise tier) sends only
        the min param so the backend returns all 1001+ companies.
        """
        from g8_mcp_server.app_renderer import (
            _companies_size_normalize,
            _companies_size_range,
        )

        normalized = _companies_size_normalize(tier)
        if normalized is None:
            return None
        emin, emax = _companies_size_range(normalized)
        if emin is None:
            return None
        params: dict = {"employee_count_min": emin, "limit": 100}
        if emax is not None:
            params["employee_count_max"] = emax
        try:
            raw = await client.get("/companies", params)
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://companies/size/%s backend error %s: %s",
                normalized, e.status_code, e,
            )
            return None
        except Exception:
            return None
        if isinstance(raw, dict):
            data = raw.get("data")
            if isinstance(data, list):
                return data
            if "companies" in raw and isinstance(raw["companies"], list):
                return raw["companies"]
        if isinstance(raw, list):
            return raw
        return []

    @server.resource(
        "g8://companies/size/{tier}",
        mime_type="text/html",
        description=(
            "Companies filtered by employee-count tier. Accepts 5 canonical "
            "tier keys (`micro` 1-10, `smb` 11-50, `mid` 51-250, `large` "
            "251-1000, `enterprise` 1001+) plus 80+ aliases (`small`, "
            "`startup`, `mid-market`, `fortune-500`, `strategic`, etc.). "
            "Cross-axis drill-up links to `g8://companies/industry/saas` and "
            "`g8://companies/country/united_states`; cross-entity drill-up "
            "links to `g8://contacts/dashboard`. Backend: RANGE filter via "
            "`GET /companies?employee_count_min=X&employee_count_max=Y`; "
            "enterprise tier passes only min."
        ),
    )
    async def companies_size_html(tier: str) -> str:
        """HTML app surface - size-tier-scoped companies pane."""

        async def _do() -> str:
            companies = await _fetch_companies_size(tier)
            return render_companies_size_html(
                companies=companies, tier=tier
            )

        return await cached_render(
            cache_prefix="companies_size_html",
            key_suffix=f"{tier}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://companies/size/{tier}.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for g8://companies/size/{tier}. Same content "
            "as the HTML surface, formatted as markdown."
        ),
    )
    async def companies_size_text(tier: str) -> str:
        """Plaintext app surface - size-tier-scoped companies pane."""

        async def _do() -> str:
            companies = await _fetch_companies_size(tier)
            return render_companies_size_text_fallback(
                companies=companies, tier=tier
            )

        return await cached_render(
            cache_prefix="companies_size_text",
            key_suffix=f"{tier}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # -------- Surface #81 - g8://companies/revenue/{tier} --------

    async def _fetch_companies_revenue(tier: str) -> list | None:
        """Fetch companies filtered by annual revenue (USD) RANGE; None on
        invalid key / backend error (renderer emits 'unavailable' state).

        Backend behavior: `GET /companies?revenue_min=X&revenue_max=Y`
        (companies_router.py:61-62 + 99-102). URI slug resolves to
        (min_usd, max_usd|None) tuple via `_COMPANIES_REVENUE_RANGE`;
        max_usd=None (enterprise tier) sends only the min param so the
        backend returns all $500M+ companies.
        """
        from g8_mcp_server.app_renderer import (
            _companies_revenue_normalize,
            _companies_revenue_range,
        )

        normalized = _companies_revenue_normalize(tier)
        if normalized is None:
            return None
        rmin, rmax = _companies_revenue_range(normalized)
        if rmin is None:
            return None
        params: dict = {"revenue_min": rmin, "limit": 100}
        if rmax is not None:
            params["revenue_max"] = rmax
        try:
            raw = await client.get("/companies", params)
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://companies/revenue/%s backend error %s: %s",
                normalized, e.status_code, e,
            )
            return None
        except Exception:
            return None
        if isinstance(raw, dict):
            data = raw.get("data")
            if isinstance(data, list):
                return data
            if "companies" in raw and isinstance(raw["companies"], list):
                return raw["companies"]
        if isinstance(raw, list):
            return raw
        return []

    @server.resource(
        "g8://companies/revenue/{tier}",
        mime_type="text/html",
        description=(
            "Companies filtered by annual revenue tier (USD). Accepts 5 "
            "canonical tier keys (`bootstrap` <$1M, `smb` $1M-$10M, `mid` "
            "$10M-$50M, `large` $50M-$500M, `enterprise` $500M+) plus 80+ "
            "aliases (`pre-revenue`, `small`, `mid-market`, `fortune-500`, "
            "`billion-plus`, `pe-backed`, etc.). Cross-axis drill-up links "
            "to `g8://companies/industry/saas`, `g8://companies/country/"
            "united_states`, and `g8://companies/size/mid` - first TRIPLE "
            "cross-axis surface. Cross-entity drill-up links to "
            "`g8://contacts/dashboard`. Backend: RANGE filter via "
            "`GET /companies?revenue_min=X&revenue_max=Y`; enterprise tier "
            "passes only min."
        ),
    )
    async def companies_revenue_html(tier: str) -> str:
        """HTML app surface - revenue-tier-scoped companies pane."""

        async def _do() -> str:
            companies = await _fetch_companies_revenue(tier)
            return render_companies_revenue_html(
                companies=companies, tier=tier
            )

        return await cached_render(
            cache_prefix="companies_revenue_html",
            key_suffix=f"{tier}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://companies/revenue/{tier}.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for g8://companies/revenue/{tier}. Same "
            "content as the HTML surface, formatted as markdown."
        ),
    )
    async def companies_revenue_text(tier: str) -> str:
        """Plaintext app surface - revenue-tier-scoped companies pane."""

        async def _do() -> str:
            companies = await _fetch_companies_revenue(tier)
            return render_companies_revenue_text_fallback(
                companies=companies, tier=tier
            )

        return await cached_render(
            cache_prefix="companies_revenue_text",
            key_suffix=f"{tier}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #82 - stage-scoped deals pane.                              #
    # Template URI: g8://deals/stage/{stage} + .txt fallback.             #
    # First axis-filter on the DEALS entity (after 4 on companies).       #
    # 6 canonical stages (prospecting / qualification / proposal /        #
    # negotiation / won / lost) + ~90 aliases.                            #
    # Backend: GET /deals?limit=200 then client-side bucket by            #
    # canonical stage via _deals_stage_bucket_of() heuristic.             #
    # ------------------------------------------------------------------ #

    async def _fetch_deals_for_stage(stage: str):
        """Fetch all deals then let the renderer filter client-side.

        Returns None if the stage slug is unrecognized (renderer will emit
        the 'unavailable' state without a backend call).
        Returns [] on backend error.
        """
        from g8_mcp_server.app_renderer import _deals_stage_normalize

        if _deals_stage_normalize(stage) is None:
            return None
        try:
            raw = await client.get("/deals", {"limit": 200})
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://deals/stage/%s backend error %s: %s",
                stage, e.status_code, e,
            )
            return []
        except Exception:
            return []
        if isinstance(raw, list):
            return [d for d in raw if isinstance(d, dict)]
        if not isinstance(raw, dict):
            return []
        items = raw.get("deals")
        if not isinstance(items, list):
            items = raw.get("data")
        if not isinstance(items, list):
            return []
        return [d for d in items if isinstance(d, dict)]

    @server.resource(
        "g8://deals/stage/{stage}",
        mime_type="text/html",
        description=(
            "Deals filtered by canonical pipeline stage. Accepts 6 "
            "canonical keys (`prospecting`, `qualification`, `proposal`, "
            "`negotiation`, `won`, `lost`) plus 90+ aliases (`mql`, "
            "`sql`, `demo`, `quote`, `redlines`, `closed-won`, "
            "`closed-lost`, etc.). First axis-filter on the DEALS entity; "
            "complements `g8://deals/pipeline` (kanban) and "
            "`g8://deals/dashboard` (financial). Cross-entity drill-up "
            "links to `g8://contacts/dashboard`. Backend: fetches 200 "
            "deals then buckets client-side via stage_name heuristic."
        ),
    )
    async def deals_stage_html(stage: str) -> str:
        """HTML app surface - stage-scoped deals pane."""

        async def _do() -> str:
            deals = await _fetch_deals_for_stage(stage)
            return render_deals_stage_html(deals=deals, stage=stage)

        return await cached_render(
            cache_prefix="deals_stage_html",
            key_suffix=f"{stage}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://deals/stage/{stage}.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for g8://deals/stage/{stage}. Same "
            "content as the HTML surface, formatted as markdown."
        ),
    )
    async def deals_stage_text(stage: str) -> str:
        """Plaintext app surface - stage-scoped deals pane."""

        async def _do() -> str:
            deals = await _fetch_deals_for_stage(stage)
            return render_deals_stage_text_fallback(
                deals=deals, stage=stage
            )

        return await cached_render(
            cache_prefix="deals_stage_text",
            key_suffix=f"{stage}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------ #
    # Surface #83 - deals by owner (3-seg templated HTML app).          #
    # URIs: g8://deals/owner/{user_id} + .txt                            #
    # Backend: GET /deals?owner_id={user_id}&limit=200 - TRUE backend     #
    # filter with EXACT match on opaque user_id column (SIXTH distinct   #
    # pattern across MCP HTML surfaces).                                  #
    # ------------------------------------------------------------------ #

    async def _fetch_deals_for_owner(user_id: str):
        """Fetch deals filtered by owner_id at the backend.

        Returns None if the user_id slug is invalid (renderer will emit
        the 'unavailable' state without a backend call).
        Returns [] on backend error.
        """
        from g8_mcp_server.app_renderer import _deals_owner_normalize

        normalized = _deals_owner_normalize(user_id)
        if normalized is None:
            return None
        try:
            raw = await client.get(
                "/deals",
                {"owner_id": normalized, "limit": 200},
            )
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://deals/owner/%s backend error %s: %s",
                normalized, e.status_code, e,
            )
            return []
        except Exception:
            return []
        if isinstance(raw, list):
            return [d for d in raw if isinstance(d, dict)]
        if not isinstance(raw, dict):
            return []
        items = raw.get("deals")
        if not isinstance(items, list):
            items = raw.get("data")
        if not isinstance(items, list):
            return []
        return [d for d in items if isinstance(d, dict)]

    @server.resource(
        "g8://deals/owner/{user_id}",
        mime_type="text/html",
        description=(
            "Deals filtered by owner user_id. EXACT backend match on the "
            "opaque user_id column - no canonical set / no alias table "
            "since user_ids are per-org opaque strings (UUIDs, emails, "
            "auth subs). First opaque-ID axis-filter; second axis-filter "
            "on the DEALS entity (companion to "
            "`g8://deals/stage/{stage}`). Cross-axis drill-up links to "
            "stage siblings + cross-entity to `g8://contacts/dashboard`. "
            "Backend: `GET /deals?owner_id={user_id}&limit=200`."
        ),
    )
    async def deals_owner_html(user_id: str) -> str:
        """HTML app surface - owner-scoped deals pane."""

        async def _do() -> str:
            deals = await _fetch_deals_for_owner(user_id)
            return render_deals_owner_html(deals=deals, user_id=user_id)

        return await cached_render(
            cache_prefix="deals_owner_html",
            key_suffix=f"{user_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://deals/owner/{user_id}.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for g8://deals/owner/{user_id}. Same "
            "content as the HTML surface, formatted as markdown."
        ),
    )
    async def deals_owner_text(user_id: str) -> str:
        """Plaintext app surface - owner-scoped deals pane."""

        async def _do() -> str:
            deals = await _fetch_deals_for_owner(user_id)
            return render_deals_owner_text_fallback(
                deals=deals, user_id=user_id
            )

        return await cached_render(
            cache_prefix="deals_owner_text",
            key_suffix=f"{user_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # -------- Surface #84 - g8://contacts/engagement/{level} --------

    async def _fetch_contacts_for_engagement(level: str):
        """Fetch contacts for client-side engagement-level bucketing.

        Backend has no native engagement column - we fetch a broad page
        (`GET /contacts?limit=200`) and let `_contacts_engagement_filter`
        bucket each contact by its engagement_score / last_touch_at.

        Returns None if the level slug is invalid or backend errored
        (renderer emits the 'unavailable' state without a backend call).
        Returns [] if backend returns nothing matchable.
        """
        from g8_mcp_server.app_renderer import _contacts_engagement_normalize

        normalized = _contacts_engagement_normalize(level)
        if normalized is None:
            return None
        try:
            raw = await client.get("/contacts", {"limit": 200})
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://contacts/engagement/%s backend error %s: %s",
                normalized, e.status_code, e,
            )
            return None
        except Exception:
            return None
        if isinstance(raw, list):
            return [c for c in raw if isinstance(c, dict)]
        if not isinstance(raw, dict):
            return []
        items = raw.get("contacts")
        if not isinstance(items, list):
            items = raw.get("data")
        if not isinstance(items, list):
            return []
        return [c for c in items if isinstance(c, dict)]

    @server.resource(
        "g8://contacts/engagement/{level}",
        mime_type="text/html",
        description=(
            "Contacts filtered by engagement level (hot/warm/cool/cold/"
            "dormant). POST-FETCH CLIENT-SIDE BUCKETING - no backend "
            "engagement column; we score-tier each contact first "
            "(≥80/60/40/20) and fall back to days-since-last-touch "
            "bands (≤7/30/90/180). Third axis-filter on the CONTACTS "
            "entity (companion to `g8://contacts/seniority/{seniority}` "
            "and `g8://contacts/department/{department}`). Cross-axis "
            "drill-up links to seniority + department siblings + "
            "cross-entity `g8://deals/pipeline`. Backend: "
            "`GET /contacts?limit=200` then client-side bucket."
        ),
    )
    async def contacts_engagement_html(level: str) -> str:
        """HTML app surface - engagement-level scoped contacts pane."""

        async def _do() -> str:
            contacts = await _fetch_contacts_for_engagement(level)
            return render_contacts_engagement_html(
                contacts=contacts, level=level
            )

        return await cached_render(
            cache_prefix="contacts_engagement_html",
            key_suffix=f"{level}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://contacts/engagement/{level}.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for g8://contacts/engagement/{level}. "
            "Same content as the HTML surface, formatted as markdown."
        ),
    )
    async def contacts_engagement_text(level: str) -> str:
        """Plaintext app surface - engagement-level scoped contacts pane."""

        async def _do() -> str:
            contacts = await _fetch_contacts_for_engagement(level)
            return render_contacts_engagement_text_fallback(
                contacts=contacts, level=level
            )

        return await cached_render(
            cache_prefix="contacts_engagement_text",
            key_suffix=f"{level}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # -------- Surface #85 - g8://contacts/source/{channel} --------

    async def _fetch_contacts_for_source(channel: str):
        """Fetch contacts filtered by acquisition source/channel.

        Backend filter: `GET /contacts?source={channel}&limit=200`. We pass
        the normalized canonical key (e.g. 'referral', 'paid', 'organic').
        Returns None if invalid slug / backend errored (renderer emits the
        'unavailable' state without a backend call). Returns [] on empty
        match or 404.
        """
        from g8_mcp_server.app_renderer import _contacts_source_normalize

        normalized = _contacts_source_normalize(channel)
        if normalized is None:
            return None
        try:
            raw = await client.get(
                "/contacts",
                {"source": normalized, "limit": 200},
            )
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://contacts/source/%s backend error %s: %s",
                normalized, e.status_code, e,
            )
            return None
        except Exception:
            return None
        if isinstance(raw, list):
            return [c for c in raw if isinstance(c, dict)]
        if not isinstance(raw, dict):
            return []
        items = raw.get("contacts")
        if not isinstance(items, list):
            items = raw.get("data")
        if not isinstance(items, list):
            return []
        return [c for c in items if isinstance(c, dict)]

    @server.resource(
        "g8://contacts/source/{channel}",
        mime_type="text/html",
        description=(
            "Contacts filtered by acquisition source channel. Accepts "
            "canonical keys (`referral`, `paid`, `organic`, `events`, "
            "`inbound`, `outbound`, `partner`, `direct`, `social`, "
            "`webinar`, `import`, `other`) plus ~80 aliases (`seo`/"
            "`ppc`/`linkedin-ads`/`cold-email`/`conference`/etc.). "
            "Fourth axis-filter on the CONTACTS entity (companion to "
            "#76 seniority / #77 department / #84 engagement). "
            "Cross-axis drill-up links to engagement + seniority + "
            "cross-entity `g8://deals/pipeline`. Backend: "
            "`GET /contacts?source=<key>&limit=200`."
        ),
    )
    async def contacts_source_html(channel: str) -> str:
        """HTML app surface - source-channel scoped contacts pane."""

        async def _do() -> str:
            contacts = await _fetch_contacts_for_source(channel)
            return render_contacts_source_html(
                contacts=contacts, channel=channel
            )

        return await cached_render(
            cache_prefix="contacts_source_html",
            key_suffix=f"{channel}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://contacts/source/{channel}.txt",
        mime_type="text/plain",
        description=(
            "Plaintext fallback for g8://contacts/source/{channel}. "
            "Same content as the HTML surface, formatted as markdown."
        ),
    )
    async def contacts_source_text(channel: str) -> str:
        """Plaintext app surface - source-channel scoped contacts pane."""

        async def _do() -> str:
            contacts = await _fetch_contacts_for_source(channel)
            return render_contacts_source_text_fallback(
                contacts=contacts, channel=channel
            )

        return await cached_render(
            cache_prefix="contacts_source_text",
            key_suffix=f"{channel}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # -------- Surface #86 - g8://activities/today --------
    # 2-seg STATIC resource (no URI capture). TEMPORAL scope: filters
    # activities to today (UTC). Sibling of #11 ``g8://activities/feed``.
    async def _fetch_activities_for_today():
        """Fetch today's activities with server-side + client-side filter.

        Returns None on unknown error, [] on 404 or empty response.
        Backend is expected to honor ``?since={bound}`` but we apply a
        client-side safety filter on occurred_at anyway.
        """
        from g8_mcp_server.app_renderer import _activities_today_utc_bound

        bound = _activities_today_utc_bound()
        try:
            raw = await client.get(
                "/activities", {"since": bound, "limit": 200}
            )
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://activities/today backend error %s: %s",
                e.status_code, e,
            )
            return None
        except Exception as e:
            logger.warning("g8://activities/today fetch error: %s", e)
            return None

        if isinstance(raw, list):
            return raw
        if isinstance(raw, dict):
            for key in ("data", "activities", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    return val
            return []
        return []

    @server.resource(
        "g8://activities/today",
        name="activities_today_html",
        description=(
            "Today's activity feed for the current org - temporal scope "
            "(00:00 UTC boundary). Renders inline HTML with stats "
            "(Total / Most common type / Peak hour / Contacts touched), "
            "hour-bucketed activity rows, and cross-entity drill-up "
            "links. Static 2-seg resource under g8://activities/; "
            "sibling of g8://activities/feed (recent, not today-only)."
        ),
        mime_type="text/html",
    )
    async def activities_today_html() -> str:
        async def _do() -> str:
            activities = await _fetch_activities_for_today()
            if activities is None:
                return render_activities_today_html(activities=[])
            return render_activities_today_html(activities=activities)

        return await cached_render(
            cache_prefix="activities_today_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://activities/today.txt",
        name="activities_today_text",
        description=(
            "Plaintext fallback for g8://activities/today. "
            "Same content as the HTML surface; for clients that do not "
            "render inline HTML app surfaces."
        ),
        mime_type="text/plain",
    )
    async def activities_today_text() -> str:
        async def _do() -> str:
            activities = await _fetch_activities_for_today()
            if activities is None:
                return render_activities_today_text_fallback(activities=[])
            return render_activities_today_text_fallback(activities=activities)

        return await cached_render(
            cache_prefix="activities_today_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # -------- Surface #87 - g8://tasks/due-today --------
    # 2-seg STATIC resource. SECOND temporal scope surface (after #86).
    # Applied to TASKS entity with due_before boundary (not since=).
    # Catches overdue + due-today in one fetch, then partitions client-
    # side into three bands: overdue / due_today / completed_today.
    # Sibling of #12 tasks/dashboard, #67 tasks/{task_id},
    # #74 tasks/status/{status}, #75 tasks/priority/{priority}.
    async def _fetch_tasks_for_due_today():
        """Fetch tasks with due_before=tomorrow_utc + client-side filter.

        Returns None on unknown error, [] on 404 or empty response. The
        due_before boundary is tomorrow 00:00 UTC, so everything due
        through end-of-today comes in one request. We also pull a wider
        limit to ensure recent-completed tasks (which the client
        partitioner may match via completed_at) are included.
        """
        from g8_mcp_server.app_renderer import (
            _tasks_due_today_tomorrow_utc_bound,
        )

        due_before = _tasks_due_today_tomorrow_utc_bound()
        try:
            raw = await client.get(
                "/tasks", {"due_before": due_before, "limit": 200}
            )
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://tasks/due-today backend error %s: %s",
                e.status_code, e,
            )
            return None
        except Exception as e:
            logger.warning("g8://tasks/due-today fetch error: %s", e)
            return None

        if isinstance(raw, list):
            return raw
        if isinstance(raw, dict):
            for key in ("data", "tasks", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    return val
            return []
        return []

    @server.resource(
        "g8://tasks/due-today",
        name="tasks_due_today_html",
        description=(
            "Tasks in today's urgency window - temporal scope with "
            "three-band partition: Overdue / Due today / Completed "
            "today. Server fetches everything due before tomorrow 00:00 "
            "UTC, client partitions by due_date + completed_at. "
            "Renders inline HTML with stats (Total / Overdue / Due "
            "today / Completed today), band-specific palettes "
            "(warning-amber for overdue, accent-purple for due today, "
            "positive-green for completed), and cross-entity drill-up "
            "links. Static 2-seg resource under g8://tasks/; sibling "
            "of g8://tasks/dashboard, g8://tasks/status/{status}, "
            "g8://tasks/priority/{priority}."
        ),
        mime_type="text/html",
    )
    async def tasks_due_today_html() -> str:
        async def _do() -> str:
            tasks = await _fetch_tasks_for_due_today()
            if tasks is None:
                return render_tasks_due_today_html(tasks=[])
            return render_tasks_due_today_html(tasks=tasks)

        return await cached_render(
            cache_prefix="tasks_due_today_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://tasks/due-today.txt",
        name="tasks_due_today_text",
        description=(
            "Plaintext fallback for g8://tasks/due-today. Same content "
            "as the HTML surface; for clients that do not render inline "
            "HTML app surfaces."
        ),
        mime_type="text/plain",
    )
    async def tasks_due_today_text() -> str:
        async def _do() -> str:
            tasks = await _fetch_tasks_for_due_today()
            if tasks is None:
                return render_tasks_due_today_text_fallback(tasks=[])
            return render_tasks_due_today_text_fallback(tasks=tasks)

        return await cached_render(
            cache_prefix="tasks_due_today_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # -------- Surface #88 - g8://deals/this-week --------
    # 2-seg STATIC resource. THIRD temporal-scope surface (after #86
    # activities/today + #87 tasks/due-today), first to use WEEK scope
    # rather than DAY scope. Introduces the NINTH distinct backend-
    # filter pattern: DUAL-BOUND TEMPORAL RANGE via
    # ?close_after={monday} & ?close_before={next_monday}. Client-side
    # three-band partition: closing_this_week / closed_won_this_week /
    # closed_lost_this_week. Sibling of #24 deals/{deal_id},
    # #60 deals/dashboard, /pipeline, #70 deals/{deal_id}/activities,
    # #82 deals/stage/{stage}, #83 deals/owner/{user_id}.
    async def _fetch_deals_for_this_week():
        """Fetch deals via dual-bound temporal range filter.

        Returns None on unknown error, [] on 404 or empty response.
        Backend is expected to honor ``?close_after=`` + ``?close_before=``
        but we apply a client-side safety filter on close_date / closed_at
        regardless.
        """
        from g8_mcp_server.app_renderer import (
            _deals_this_week_week_end_utc,
            _deals_this_week_week_start_utc,
        )

        week_start = _deals_this_week_week_start_utc()
        week_end = _deals_this_week_week_end_utc()
        try:
            raw = await client.get(
                "/deals",
                {
                    "close_after": week_start,
                    "close_before": week_end,
                    "limit": 200,
                },
            )
        except G8ClientError as e:
            if e.status_code == 404:
                return []
            logger.warning(
                "g8://deals/this-week backend error %s: %s",
                e.status_code, e,
            )
            return None
        except Exception as e:
            logger.warning("g8://deals/this-week fetch error: %s", e)
            return None

        if isinstance(raw, list):
            return raw
        if isinstance(raw, dict):
            for key in ("data", "deals", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    return val
            return []
        return []

    @server.resource(
        "g8://deals/this-week",
        name="deals_this_week_html",
        description=(
            "Deals in this week's UTC window - temporal scope with a "
            "three-band partition: Closing this week / Won this week / "
            "Lost this week. Week runs Monday 00:00 UTC through the "
            "following Monday 00:00 UTC (exclusive). Renders inline "
            "HTML with stats (Total in window / Pipeline $ / Won $ / "
            "Lost $), band-specific palettes (accent-purple for "
            "closing, positive-green for won, destructive-red for "
            "lost), and cross-entity drill-up links. Static 2-seg "
            "resource under g8://deals/; sibling of g8://deals/"
            "pipeline, g8://deals/dashboard, g8://deals/stage/{stage}, "
            "g8://deals/owner/{user_id}."
        ),
        mime_type="text/html",
    )
    async def deals_this_week_html() -> str:
        async def _do() -> str:
            deals = await _fetch_deals_for_this_week()
            if deals is None:
                return render_deals_this_week_html(deals=[])
            return render_deals_this_week_html(deals=deals)

        return await cached_render(
            cache_prefix="deals_this_week_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://deals/this-week.txt",
        name="deals_this_week_text",
        description=(
            "Plaintext fallback for g8://deals/this-week. Same content "
            "as the HTML surface; for clients that do not render "
            "inline HTML app surfaces."
        ),
        mime_type="text/plain",
    )
    async def deals_this_week_text() -> str:
        async def _do() -> str:
            deals = await _fetch_deals_for_this_week()
            if deals is None:
                return render_deals_this_week_text_fallback(deals=[])
            return render_deals_this_week_text_fallback(deals=deals)

        return await cached_render(
            cache_prefix="deals_this_week_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------
    # Surface #89 - g8://accounts/{account_id}
    # ------------------------------------------------------------------
    # Templated 2-seg account drilldown: REVENUE-LENS overlay on top of
    # a MashupCompany record. Backend: three parallel GET calls against
    # /companies/{id}, /companies/{id}/deals, /companies/{id}/contacts.
    # Renderer partitions deals into won/open/lost, computes a 0-100
    # account-health score, and surfaces a revenue-first stat row.
    # First MCP app surface for the "accounts" entity prefix.
    # ------------------------------------------------------------------

    async def _fetch_account_detail(account_id: str) -> dict | None:
        client = await _client_from_credentials()
        if client is None:
            return None
        try:
            raw = await client.get(f"/companies/{account_id}")
        except Exception as e:  # noqa: BLE001
            logger.warning("g8://accounts/%s fetch error: %s", account_id, e)
            return None
        if isinstance(raw, dict):
            return raw
        return None

    async def _fetch_account_deals(account_id: str) -> list[dict]:
        client = await _client_from_credentials()
        if client is None:
            return []
        try:
            raw = await client.get(f"/companies/{account_id}/deals")
        except Exception as e:  # noqa: BLE001
            logger.warning("g8://accounts/%s deals fetch error: %s", account_id, e)
            return []
        if isinstance(raw, list):
            return [d for d in raw if isinstance(d, dict)]
        if isinstance(raw, dict):
            for key in ("data", "deals", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    return [d for d in val if isinstance(d, dict)]
        return []

    async def _fetch_account_contacts(account_id: str) -> list[dict]:
        client = await _client_from_credentials()
        if client is None:
            return []
        try:
            raw = await client.get(f"/companies/{account_id}/contacts")
        except Exception as e:  # noqa: BLE001
            logger.warning("g8://accounts/%s contacts fetch error: %s", account_id, e)
            return []
        if isinstance(raw, list):
            return [c for c in raw if isinstance(c, dict)]
        if isinstance(raw, dict):
            for key in ("data", "contacts", "items", "results"):
                val = raw.get(key)
                if isinstance(val, list):
                    return [c for c in val if isinstance(c, dict)]
        return []

    @server.resource(
        "g8://accounts/{account_id}",
        name="account_detail_html",
        description=(
            "Single-account drilldown - REVENUE LENS overlay on a "
            "MashupCompany record. Stats row (Total account value / "
            "Won $ / Open pipeline / Health score 0-100), three-band "
            "deal partition (won / open / lost) with amount sums and "
            "band-specific palettes (positive-green for won, "
            "accent-purple for open, destructive-red for lost), and "
            "a compact contacts summary (count + top-5 chips). "
            "Differentiator vs g8://companies/{company_id} (#38): #38 "
            "frames the company as a CRM profile; #89 frames the same "
            "record as a revenue account. Backend fetches are parallel "
            "against /companies/{id}, /companies/{id}/deals, and "
            "/companies/{id}/contacts. URI-templated by account_id; "
            "first MCP app surface under g8://accounts/."
        ),
        mime_type="text/html",
    )
    async def account_detail_html(account_id: str) -> str:
        async def _do() -> str:
            company = await _fetch_account_detail(account_id)
            if not isinstance(company, dict):
                return render_account_detail_html(account_id=account_id)
            deals = await _fetch_account_deals(account_id)
            contacts = await _fetch_account_contacts(account_id)
            return render_account_detail_html(
                account_id=account_id,
                company=company,
                deals=deals,
                contacts=contacts,
            )

        return await cached_render(
            cache_prefix="account_detail_html",
            key_suffix=f"{account_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://accounts/{account_id}.txt",
        name="account_detail_text",
        description=(
            "Plaintext fallback for g8://accounts/{account_id}. Same "
            "content as the HTML surface for clients that do not "
            "render inline HTML app surfaces."
        ),
        mime_type="text/plain",
    )
    async def account_detail_text(account_id: str) -> str:
        async def _do() -> str:
            company = await _fetch_account_detail(account_id)
            if not isinstance(company, dict):
                return render_account_detail_text_fallback(account_id=account_id)
            deals = await _fetch_account_deals(account_id)
            contacts = await _fetch_account_contacts(account_id)
            return render_account_detail_text_fallback(
                account_id=account_id,
                company=company,
                deals=deals,
                contacts=contacts,
            )

        return await cached_render(
            cache_prefix="account_detail_text",
            key_suffix=f"{account_id}:{_session_suffix()}",
            fetch_and_render=_do,
        )

    # ------------------------------------------------------------------
    # Surface #90 - g8://system/credit-usage  (CAPSTONE for Upgrade 4)
    # ------------------------------------------------------------------
    # First MCP app surface under the `system/` entity prefix.
    # Introduces the ELEVENTH distinct backend access pattern:
    # STATIC-KNOWLEDGE SURFACE - no backend fetch. Renderer serves
    # documented reference content (service categories, tips,
    # drill-ups) from Python constants.
    #
    # Live balance + per-service usage history will auto-enable when
    # the public developer API exposes a `/credits/usage` read
    # endpoint. Until then, this surface is deliberately honest about
    # the data gap: the status card explains that live balance is
    # checked via Studio billing, not this surface.
    # ------------------------------------------------------------------

    @server.resource(
        "g8://system/credit-usage",
        name="system_credit_usage_html",
        description=(
            "System-level reference for credit consumption in graph8 - "
            "what categories of operations (AI / Data / Messaging / "
            "Workflow) cost credits, which service names fall under "
            "each category, and cost-control tips. Deliberately static: "
            "live balance and per-service usage history are not yet "
            "exposed through the public developer API; operators check "
            "live balance via the Studio billing page. First surface "
            "under the g8://system/ entity prefix. CAPSTONE for Upgrade "
            "4 (MCP Application HTML)."
        ),
        mime_type="text/html",
    )
    async def system_credit_usage_html() -> str:
        async def _do() -> str:
            return render_system_credit_usage_html()

        return await cached_render(
            cache_prefix="system_credit_usage_html",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource(
        "g8://system/credit-usage.txt",
        name="system_credit_usage_text",
        description=(
            "Plaintext fallback for g8://system/credit-usage. Same "
            "content as the HTML surface for clients that do not "
            "render inline HTML app surfaces."
        ),
        mime_type="text/plain",
    )
    async def system_credit_usage_text() -> str:
        async def _do() -> str:
            return render_system_credit_usage_text_fallback()

        return await cached_render(
            cache_prefix="system_credit_usage_text",
            key_suffix=_session_suffix(),
            fetch_and_render=_do,
        )

    @server.resource("g8://skills")
    async def list_skills() -> str:
        """Catalog of graph8 skills - prescriptive workflow guides for common user journeys."""
        return json.dumps(
            [
                {
                    "slug": entry["slug"],
                    "title": entry["title"],
                    "summary": entry["summary"],
                    "when_to_use": entry["when_to_use"],
                    "uri": f"g8://skills/{entry['slug']}",
                }
                for entry in SKILLS_CATALOG
            ],
            indent=2,
        )

    @server.resource("g8://skills/{slug}")
    async def get_skill(slug: str) -> str:
        """Full markdown content of a single graph8 skill by slug."""
        content = get_skill_content(slug)
        if content is None:
            available = ", ".join(s["slug"] for s in SKILLS_CATALOG)
            return json.dumps({
                "error": f"Unknown skill slug: '{slug}'",
                "available_slugs": available,
            })
        return content
