"""Redis-backed HTML cache for MCP application surfaces (upgrade 4 follow-up).

The four HTML app surfaces (ad-images, sequence preview, persona dashboard,
KB library) all read backend data and render HTML on each request. The
rendering itself is cheap, but the backend call is the real cost - a single
KB library can be dozens of rows, personas can require a warm SQL schema,
etc. A client that renders the same surface twice in a row (e.g. Claude.ai
web re-renders when the user scrolls back) currently pays full price twice.

This module wraps any async `fetch_and_render` callable with a short-TTL
Redis cache so repeated calls inside the TTL window serve from Redis.

Redis layout:
- Key:   mcp:app_html:{cache_prefix}:{key_suffix}
- Value: rendered HTML (or plaintext) - bytes
- TTL:   caller-specified; defaults to 300s (5 min)

Fallback: if Redis is unavailable, we fall back to a process-local dict so
stdio / local dev still works. Entries never sync across replicas in that
mode - acceptable trade-off for a cache.

Rules for callers:
- Pick a `cache_prefix` that names the surface (e.g. "ad_images_html").
- The suffix should be stable across repeat calls for the same rendered view
  (e.g. the campaign_id / sequence_id / api-key hash).
- Don't cache variable user input - this is not a general-purpose cache.
- For per-org surfaces, feed the hashed API key as the suffix so cache
  isolation between orgs is enforced without logging plaintext keys.
"""

from __future__ import annotations

import hashlib
import logging
import time
from typing import Awaitable, Callable

logger = logging.getLogger(__name__)

_CACHE_PREFIX = "mcp:app_html:"
_DEFAULT_TTL = 300  # 5 minutes - enough to smooth double-renders, short enough to feel fresh

# In-memory fallback keyed by cache_key → (expires_epoch, rendered).
_local_cache: dict[str, tuple[float, str]] = {}


def cache_key_for_api_key(api_key: str) -> str:
    """Derive a short, stable suffix from the caller's API key.

    Same hashing strategy as `session_tools.session_id_for_key` - we never
    want to log plaintext keys as part of Redis traffic.
    """
    if not api_key:
        return "anonymous"
    return hashlib.sha256(api_key.encode()).hexdigest()[:16]


def _full_key(cache_prefix: str, key_suffix: str) -> str:
    # Sanitize colon usage - suffix might include user-visible ids.
    clean_suffix = key_suffix.replace(":", "_") if key_suffix else "default"
    clean_prefix = cache_prefix.strip(":") or "surface"
    return f"{_CACHE_PREFIX}{clean_prefix}:{clean_suffix}"


async def _redis_client():
    """Lazy-import shared Redis so stdio / tests without Redis still work."""
    try:
        from shared import apps

        return apps.infra().redis()
    except Exception:
        return None


async def get_cached(cache_prefix: str, key_suffix: str) -> str | None:
    """Return cached HTML/text for the key, or None on miss."""
    full = _full_key(cache_prefix, key_suffix)

    redis = await _redis_client()
    if redis is not None:
        try:
            raw = await redis.get(full)
            if raw is not None:
                return raw.decode() if isinstance(raw, (bytes, bytearray)) else raw
        except Exception as e:
            logger.debug("MCP app_html_cache: Redis get failed (%s) - falling back to local", e)

    entry = _local_cache.get(full)
    if not entry:
        return None
    expires, value = entry
    if expires < time.time():
        _local_cache.pop(full, None)
        return None
    return value


async def set_cached(
    cache_prefix: str,
    key_suffix: str,
    value: str,
    *,
    ttl: int = _DEFAULT_TTL,
) -> None:
    """Store rendered output in the cache with the configured TTL."""
    if not value:
        return
    full = _full_key(cache_prefix, key_suffix)
    redis = await _redis_client()
    if redis is not None:
        try:
            await redis.setex(full, ttl, value)
        except Exception as e:
            logger.debug("MCP app_html_cache: Redis setex failed (%s)", e)
    _local_cache[full] = (time.time() + ttl, value)


async def cached_render(
    *,
    cache_prefix: str,
    key_suffix: str,
    fetch_and_render: Callable[[], Awaitable[str]],
    ttl: int = _DEFAULT_TTL,
) -> str:
    """Return cached HTML/text for the key, rendering on miss.

    `fetch_and_render` is an async callable that performs the backend call
    AND produces the final string (HTML or plaintext). On miss we invoke it
    and store the result. On hit we return the cached string and skip the
    backend call entirely.

    If the render returns a falsy value, we do NOT cache it - don't want to
    persist an empty-state response across a real backend outage.
    """
    cached = await get_cached(cache_prefix, key_suffix)
    if cached is not None:
        return cached

    rendered = await fetch_and_render()
    if rendered:
        await set_cached(cache_prefix, key_suffix, rendered, ttl=ttl)
    return rendered


def clear_local_cache() -> None:
    """Drop the in-memory fallback - test helper."""
    _local_cache.clear()
