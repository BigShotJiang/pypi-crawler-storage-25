"""CLI entry point for `g8` commands - developer-facing terminal interface.

Provides the same capabilities as MCP tools but formatted for terminal output.
Installed via `pip install g8-mcp-server`, invoked as `g8`.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
import webbrowser

from g8_mcp_server.client import G8Client, G8ClientError, CREDENTIALS_PATH, save_credentials, remove_credentials, load_stored_credentials

_SETTINGS_URL = "https://app.graph8.com/settings/api"
_DEFAULT_API_URL = "https://be.graph8.com"


def _add_api_commands(subparsers: argparse._SubParsersAction) -> None:
    """Register all API commands (mirrors MCP tools)."""

    # -- CRM --
    p = subparsers.add_parser("search-contacts", help="Search contacts in your CRM")
    p.add_argument("--email", help="Filter by email")
    p.add_argument("--name", help="Filter by name")
    p.add_argument("--job-title", help="Filter by job title")
    p.add_argument("--seniority", help="Filter by seniority (C-Suite, VP, Director, Manager)")
    p.add_argument("--company", help="Filter by company name")
    p.add_argument("--country", help="Filter by country")
    p.add_argument("--list-id", help="Filter by list ID")
    p.add_argument("--page", type=int, default=1)
    p.add_argument("--limit", type=int, default=25)

    p = subparsers.add_parser("search-companies", help="Search companies in your CRM")
    p.add_argument("--domain", help="Filter by domain")
    p.add_argument("--industry", help="Filter by industry")
    p.add_argument("--name", help="Filter by company name")
    p.add_argument("--page", type=int, default=1)
    p.add_argument("--limit", type=int, default=25)

    # -- Prospecting --
    p = subparsers.add_parser("lookup-person", help="Look up a person (1 credit)")
    p.add_argument("--email", help="Email address")
    p.add_argument("--linkedin", help="LinkedIn URL")
    p.add_argument("--first-name", help="First name")
    p.add_argument("--last-name", help="Last name")
    p.add_argument("--company-domain", help="Company domain")

    p = subparsers.add_parser("lookup-company", help="Look up a company (1 credit)")
    p.add_argument("--domain", help="Company domain")
    p.add_argument("--name", help="Company name")

    p = subparsers.add_parser("find-contacts", help="Search 300M+ contacts (credits per result)")
    p.add_argument("--filters", required=True, help='JSON filters, e.g. \'[{"field":"seniority_level","operator":"any_of","value":["VP"]}]\'')
    p.add_argument("--page", type=int, default=1)
    p.add_argument("--limit", type=int, default=25)

    p = subparsers.add_parser("find-companies", help="Search company database (credits per result)")
    p.add_argument("--filters", required=True, help="JSON filters")
    p.add_argument("--page", type=int, default=1)
    p.add_argument("--limit", type=int, default=25)

    p = subparsers.add_parser("build-list", help="Search + save to new list (credits per contact)")
    p.add_argument("--filters", required=True, help="JSON filters (same as find-contacts)")
    p.add_argument("--title", required=True, help="List name")
    p.add_argument("--max-results", type=int, default=100)

    # -- Contacts & Lists --
    p = subparsers.add_parser("create-contact", help="Create a CRM contact")
    p.add_argument("--email", required=True, help="Work email")
    p.add_argument("--first-name", help="First name")
    p.add_argument("--last-name", help="Last name")
    p.add_argument("--job-title", help="Job title")
    p.add_argument("--company-domain", help="Company domain")
    p.add_argument("--list-id", type=int, help="Add to list")

    p = subparsers.add_parser("create-list", help="Create a new list")
    p.add_argument("--title", required=True, help="List name")
    p.add_argument("--type", default="contacts", choices=["contacts", "companies"])

    p = subparsers.add_parser("add-to-list", help="Add contacts to a list")
    p.add_argument("--list-id", type=int, required=True)
    p.add_argument("--contact-ids", required=True, help="Comma-separated contact IDs")

    # -- Enrichment --
    p = subparsers.add_parser("enrich", help="Enrich contacts (credits per contact)")
    p.add_argument("--contact-ids", required=True, help="Comma-separated contact IDs")
    p.add_argument("--list-id", type=int, required=True)

    # -- Sequences --
    p = subparsers.add_parser("sequences", help="List available sequences")
    p.add_argument("--page", type=int, default=1)
    p.add_argument("--limit", type=int, default=25)

    p = subparsers.add_parser("add-to-sequence", help="Add contacts to a sequence")
    p.add_argument("--sequence-id", required=True)
    p.add_argument("--contact-ids", required=True, help="Comma-separated contact IDs")
    p.add_argument("--list-id", type=int, required=True)

    p = subparsers.add_parser("create-sequence", help="Create a new sequence")
    p.add_argument("--name", required=True, help="Sequence name")
    p.add_argument("--user-email", required=True, help="Owner email")
    p.add_argument("--description", help="Description")
    p.add_argument("--steps", help="JSON array of step configs")
    p.add_argument("--channels", help="JSON array of channel configs")
    p.add_argument("--campaign-id", help="AI Studio campaign ID to link")

    p = subparsers.add_parser("sequence-preview", help="Preview a sequence with steps and channels")
    p.add_argument("--sequence-id", required=True)

    p = subparsers.add_parser("update-sequence", help="Update sequence metadata")
    p.add_argument("--sequence-id", required=True)
    p.add_argument("--name", help="New name")
    p.add_argument("--description", help="New description")

    p = subparsers.add_parser("update-sequence-step", help="Update a step within a sequence")
    p.add_argument("--sequence-id", required=True)
    p.add_argument("--step-id", required=True)
    p.add_argument("--step-data", help="JSON step data")
    p.add_argument("--time-interval", type=int, help="Delay in seconds")
    p.add_argument("--step-type", help="Step type (EMAIL, PHONE, etc.)")

    p = subparsers.add_parser("pause-sequence", help="Pause a live sequence")
    p.add_argument("--sequence-id", required=True)

    p = subparsers.add_parser("resume-sequence", help="Resume a paused sequence")
    p.add_argument("--sequence-id", required=True)

    p = subparsers.add_parser("sequence-analytics", help="Get sequence analytics")
    p.add_argument("--sequence-id", required=True)

    p = subparsers.add_parser("delete-sequence", help="Archive (soft-delete) a sequence")
    p.add_argument("--sequence-id", required=True)

    # -- Inbox --
    p = subparsers.add_parser("inbox-list", help="List inbox threads (email, SMS, LinkedIn)")
    p.add_argument("--channel", choices=["email", "sms", "linkedin"], help="Filter by channel")
    p.add_argument("--sequence-id", help="Filter by sequence/campaign ID")
    p.add_argument("--status", help="Filter by status")
    p.add_argument("--assignee", help="Filter by assignee email")
    p.add_argument("--tag", help="Filter by tag ID")
    p.add_argument("--page", type=int, default=1)
    p.add_argument("--page-size", type=int, default=50)

    p = subparsers.add_parser("inbox-get", help="Get a single inbox thread")
    p.add_argument("reply_id", help="Thread/reply ID")
    p.add_argument("--channel", default="email", choices=["email", "sms", "linkedin"])

    p = subparsers.add_parser("inbox-assign", help="Assign a user to an inbox thread")
    p.add_argument("reply_id", help="Thread/reply ID")
    p.add_argument("--email", required=True, help="Assignee email")
    p.add_argument("--channel", default="email", choices=["email", "sms", "linkedin"])

    p = subparsers.add_parser("inbox-tag", help="Tag an inbox thread")
    p.add_argument("reply_id", help="Thread/reply ID")
    p.add_argument("--tag-ids", required=True, help="Comma-separated tag IDs")
    p.add_argument("--channel", default="email", choices=["email", "sms", "linkedin"])

    p = subparsers.add_parser("inbox-draft", help="Generate AI draft reply (charges credits)")
    p.add_argument("reply_id", help="Thread/reply ID")
    p.add_argument("--channel", default="email", choices=["email", "sms", "linkedin"])

    p = subparsers.add_parser("inbox-send", help="Send a reply")
    p.add_argument("reply_id", help="Thread/reply ID")
    p.add_argument("--body", required=True, help="Message body")
    p.add_argument("--channel", required=True, choices=["email", "sms", "linkedin"])
    p.add_argument("--subject", help="Email subject (email only)")
    p.add_argument("--to", help="Recipient (email, phone, or LinkedIn ID)")
    p.add_argument("--from-address", help="Sender (mailbox, phone, or LinkedIn account ID)")

    # -- Campaigns --
    p = subparsers.add_parser("campaigns", help="List campaigns")
    p.add_argument("--page", type=int, default=1)
    p.add_argument("--limit", type=int, default=25)

    p = subparsers.add_parser("campaign", help="Get campaign details")
    p.add_argument("campaign_id", help="Campaign ID")

    # -- Audience Sync --
    subparsers.add_parser("sync-audience-list", help="List audience sync configurations")

    p = subparsers.add_parser("sync-audience-create", help="Create an audience sync")
    p.add_argument("--audience-id", type=int, required=True, help="Audience list ID")
    p.add_argument("--platform", required=True, choices=["meta", "linkedin", "google", "x"])
    p.add_argument("--mode", default="mirror", choices=["mirror", "append_only"])
    p.add_argument("--cadence", type=int, default=24, help="Refresh cadence in hours")
    p.add_argument("--name", help="Platform audience name")

    p = subparsers.add_parser("sync-audience-update", help="Update an audience sync")
    p.add_argument("--config-id", type=int, required=True)
    p.add_argument("--mode", choices=["mirror", "append_only"])
    p.add_argument("--cadence", type=int, help="Refresh cadence in hours")
    p.add_argument("--active", type=str, choices=["true", "false"], help="Enable/disable")

    p = subparsers.add_parser("sync-audience-delete", help="Delete an audience sync (soft)")
    p.add_argument("--config-id", type=int, required=True)

    p = subparsers.add_parser("sync-audience-trigger", help="Trigger an audience sync")
    p.add_argument("--config-id", type=int, required=True)

    p = subparsers.add_parser("sync-audience-runs", help="List sync run history")
    p.add_argument("--config-id", type=int, required=True)
    p.add_argument("--limit", type=int, default=20)

    p = subparsers.add_parser("sync-audience-errors", help="List sync error logs")
    p.add_argument("--config-id", type=int, required=True)
    p.add_argument("--limit", type=int, default=20)

    # -- CRM Sync --
    subparsers.add_parser("sync-crm-list", help="List CRM integrations")

    p = subparsers.add_parser("sync-crm-push", help="Push records to a CRM provider")
    p.add_argument("--provider", required=True, choices=["hubspot", "salesforce", "pipedrive", "zoho", "sugarcrm"])
    p.add_argument("--entity", required=True, choices=["contacts", "companies", "lists"])
    p.add_argument("--records", required=True, help="JSON array of records to push")

    p = subparsers.add_parser("sync-crm-fields", help="Discover CRM fields")
    p.add_argument("--provider", required=True, choices=["hubspot", "salesforce", "pipedrive", "zoho", "sugarcrm"])
    p.add_argument("--entity-type", default="contacts")

    p = subparsers.add_parser("sync-crm-status", help="Check CRM connection health")
    p.add_argument("--provider", required=True, choices=["hubspot", "salesforce", "pipedrive", "zoho", "sugarcrm"])


def main() -> None:
    """Entry point for the `g8` CLI command."""
    parser = argparse.ArgumentParser(
        prog="g8",
        description="graph8 - B2B sales and marketing platform",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""commands:
  Auth:        login, logout, whoami
  CRM:         search-contacts, search-companies, create-contact, create-list, add-to-list
  Prospecting: find-contacts, find-companies, build-list, lookup-person, lookup-company
  Enrichment:  enrich
  Sequences:   sequences, add-to-sequence, create-sequence, sequence-preview,
               update-sequence, update-sequence-step, pause-sequence,
               resume-sequence, sequence-analytics, delete-sequence
  Inbox:       inbox-list, inbox-get, inbox-assign, inbox-tag, inbox-draft, inbox-send
  Sync:        sync-audience-list, sync-audience-create, sync-audience-update,
               sync-audience-delete, sync-audience-trigger, sync-audience-runs,
               sync-audience-errors, sync-crm-list, sync-crm-push,
               sync-crm-fields, sync-crm-status
  Campaigns:   campaigns, campaign
  Developer:   snippet, form

Run 'g8 <command> --help' for details on any command.""",
    )
    subparsers = parser.add_subparsers(dest="command")

    # -- Auth --
    login_parser = subparsers.add_parser("login", help="Sign in via browser (OAuth) or API key")
    login_parser.add_argument("--api-key", action="store_true", help="Paste an API key instead of OAuth")
    login_parser.add_argument("--url", type=str, default=None, help="Backend API URL (default: production)")
    subparsers.add_parser("logout", help="Remove stored credentials")
    subparsers.add_parser("whoami", help="Show current auth status")

    # -- Developer --
    snippet_parser = subparsers.add_parser("snippet", help="Get tracking snippet for your framework")
    snippet_parser.add_argument("--framework", type=str, help="Target framework (html, react, nextjs, vue, wordpress, webflow, shopify)")
    snippet_parser.add_argument("--repo-id", type=str, default=None)
    snippet_parser.add_argument("--list", action="store_true", help="List supported frameworks")
    snippet_parser.add_argument("--format", choices=["text", "json"], default="text")

    form_parser = subparsers.add_parser("form", help="Get progressive form template")
    form_parser.add_argument("--framework", type=str, required=True)
    form_parser.add_argument("--variant", type=str, required=True, choices=["embedded", "popup"])
    form_parser.add_argument("--repo-id", type=str, default=None)
    form_parser.add_argument("--stages", type=str, default=None, help="Custom field stages (JSON)")
    form_parser.add_argument("--format", choices=["text", "json"], default="text")

    # -- API commands (mirrors MCP tools) --
    _add_api_commands(subparsers)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    if args.command == "login":
        api_url = args.url or _DEFAULT_API_URL
        if args.api_key:
            _handle_login_api_key(api_url)
        else:
            _handle_login_oauth(api_url)
        return
    if args.command == "logout":
        _handle_logout()
        return
    if args.command == "whoami":
        asyncio.run(_handle_whoami())
        return

    try:
        asyncio.run(_dispatch(args))
    except G8ClientError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        sys.exit(0)


# ---------------------------------------------------------------------------
# Auth commands
# ---------------------------------------------------------------------------


def _handle_login_oauth(api_url: str = _DEFAULT_API_URL) -> None:
    """Handle `g8 login` - OAuth browser flow with local callback server."""
    import secrets
    import threading
    from http.server import HTTPServer, BaseHTTPRequestHandler
    from urllib.parse import urlencode, urlparse, parse_qs

    _OAUTH_CALLBACK_PORT = 18920
    _APP_LOGIN_URL = "https://app.graph8.com/cli-auth"

    result: dict[str, str] = {}
    server_ready = threading.Event()

    class CallbackHandler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:
            parsed = urlparse(self.path)
            params = parse_qs(parsed.query)

            api_key = params.get("api_key", [""])[0]
            email = params.get("email", [""])[0]
            error = params.get("error", [""])[0]

            if error:
                result["error"] = error
                self._respond("Authentication failed. You can close this tab.")
            elif api_key:
                result["api_key"] = api_key
                result["email"] = email
                self._respond("Authenticated! You can close this tab and return to your terminal.")
            else:
                self._respond("Missing credentials. Please try again.")
                result["error"] = "No API key in callback"

        def _respond(self, message: str) -> None:
            html = f"""<html><body style="font-family:system-ui;display:flex;justify-content:center;
            align-items:center;height:100vh;margin:0;background:#0a0a0a;color:#fff">
            <div style="text-align:center"><h2>graph8 CLI</h2><p>{message}</p></div></body></html>"""
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(html.encode())

        def log_message(self, format: str, *args: object) -> None:
            pass  # Suppress HTTP logs

    state = secrets.token_urlsafe(32)
    callback_url = f"http://localhost:{_OAUTH_CALLBACK_PORT}/callback"

    auth_url = f"{_APP_LOGIN_URL}?" + urlencode({
        "callback_url": callback_url,
        "state": state,
    })

    print(f"Opening graph8 in your browser to sign in...\n")
    webbrowser.open(auth_url)
    print("Waiting for authentication...")

    try:
        server = HTTPServer(("127.0.0.1", _OAUTH_CALLBACK_PORT), CallbackHandler)
        server.timeout = 120
        server.handle_request()  # Handle one request then stop
        server.server_close()
    except OSError as e:
        print(f"\nError: could not start callback server on port {_OAUTH_CALLBACK_PORT}: {e}", file=sys.stderr)
        print("Try `g8 login --api-key` to authenticate with an API key instead.")
        sys.exit(1)
    except KeyboardInterrupt:
        print("\nLogin cancelled.")
        sys.exit(0)

    if "error" in result:
        print(f"\nLogin failed: {result['error']}", file=sys.stderr)
        sys.exit(1)

    api_key = result.get("api_key", "")
    email = result.get("email", "")

    if not api_key:
        print("\nLogin failed: no credentials received.", file=sys.stderr)
        sys.exit(1)

    # Validate the key
    print("Verifying...", end=" ", flush=True)
    try:
        asyncio.run(_validate_key(api_key, api_url))
    except G8ClientError:
        print("failed.")
        print("Error: received invalid credentials. Try again or use `g8 login --api-key`.", file=sys.stderr)
        sys.exit(1)
    except Exception:
        print("skipped (could not reach API).")

    save_credentials(api_key, api_url, auth_method="oauth", email=email)
    print("done.\n")
    if email:
        print(f"Logged in as {email}")
    print("Credentials saved to ~/.g8/credentials.json")
    print("You can now use `g8 snippet`, `g8 form`, and other commands.")


def _handle_login_api_key(api_url: str = _DEFAULT_API_URL) -> None:
    """Handle `g8 login --api-key` - prompt for API key, store locally."""
    print(f"Opening graph8 settings in your browser...\n  {_SETTINGS_URL}\n")
    webbrowser.open(_SETTINGS_URL)

    print("Create an API key in Settings -> API, then paste it here.\n")
    try:
        api_key = input("API key: ").strip()
    except (EOFError, KeyboardInterrupt):
        print("\nLogin cancelled.")
        sys.exit(0)

    if not api_key:
        print("Error: no API key provided.", file=sys.stderr)
        sys.exit(1)

    # Validate the key
    print("Verifying...", end=" ", flush=True)
    try:
        asyncio.run(_validate_key(api_key, api_url))
    except G8ClientError:
        print("failed.")
        print("Error: invalid API key. Check the key and try again.", file=sys.stderr)
        sys.exit(1)
    except Exception:
        print("skipped (could not reach API).")

    save_credentials(api_key, api_url, auth_method="api_key")
    print("done.\n")
    print("Authenticated successfully. Credentials saved to ~/.g8/credentials.json")
    print("You can now use `g8 snippet`, `g8 form`, and other commands.")


def _handle_logout() -> None:
    """Handle `g8 logout` - remove stored credentials."""
    if remove_credentials():
        print("Logged out. Credentials removed from ~/.g8/credentials.json")
    else:
        print("No stored credentials found.")
    print("Use `g8 login` or set G8_API_KEY to authenticate.")


async def _handle_whoami() -> None:
    """Handle `g8 whoami` - show auth status."""
    import os
    env_key = os.environ.get("G8_API_KEY", "")
    stored_key, stored_url, auth_method = load_stored_credentials()

    if not env_key and not stored_key:
        print("Not authenticated.")
        print("Run `g8 login` or set G8_API_KEY to get started.")
        return

    if env_key:
        source = "G8_API_KEY environment variable"
        key = env_key
    elif auth_method == "oauth":
        source = "OAuth (~/.g8/credentials.json)"
        key = stored_key
    else:
        source = "API key (~/.g8/credentials.json)"
        key = stored_key

    masked = f"{key[:8]}...{key[-4:]}" if len(key) > 12 else "****"

    print(f"Auth source:  {source}")
    print(f"API key:      {masked}")

    # Show email for OAuth logins
    if not env_key and auth_method == "oauth":
        try:
            data = json.loads(CREDENTIALS_PATH.read_text())
            email = data.get("email", "")
            if email:
                print(f"Logged in as: {email}")
        except (json.JSONDecodeError, OSError):
            pass

    if stored_url:
        print(f"API URL:      {stored_url}")


async def _validate_key(api_key: str, api_url: str = _DEFAULT_API_URL) -> None:
    """Make a lightweight API call to verify the key is valid."""
    import httpx

    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    async with httpx.AsyncClient(base_url=api_url, headers=headers, timeout=10) as client:
        resp = await client.get("/api/v1/contacts", params={"limit": 1})
        if resp.status_code == 401:
            raise G8ClientError(401, "Invalid API key")


def _parse_ids(s: str) -> list[int]:
    """Parse comma-separated IDs into a list of ints."""
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def _print_json(data: dict) -> None:
    """Pretty-print API response."""
    payload = data.get("data", data)
    print(json.dumps(payload, indent=2, default=str))


async def _api_call(args: argparse.Namespace) -> None:
    """Handle all API commands by mapping to G8Client calls."""
    client = G8Client(require_key=True)
    cmd = args.command

    if cmd == "search-contacts":
        result = await client.get("/contacts", {
            "email": getattr(args, "email", None), "name": getattr(args, "name", None),
            "job_title": getattr(args, "job_title", None), "seniority_level": getattr(args, "seniority", None),
            "company_name": getattr(args, "company", None), "country": getattr(args, "country", None),
            "list_id": getattr(args, "list_id", None), "page": args.page, "limit": args.limit,
        })
    elif cmd == "search-companies":
        result = await client.get("/companies", {
            "domain": getattr(args, "domain", None), "industry": getattr(args, "industry", None),
            "name": getattr(args, "name", None), "page": args.page, "limit": args.limit,
        })
    elif cmd == "lookup-person":
        body = {k: v for k, v in {
            "email": getattr(args, "email", None), "linkedin_url": getattr(args, "linkedin", None),
            "first_name": getattr(args, "first_name", None), "last_name": getattr(args, "last_name", None),
            "company_domain": getattr(args, "company_domain", None),
        }.items() if v}
        result = await client.post("/enrichment/lookup/person", body)
    elif cmd == "lookup-company":
        body = {k: v for k, v in {
            "domain": getattr(args, "domain", None), "name": getattr(args, "name", None),
        }.items() if v}
        result = await client.post("/enrichment/lookup/company", body)
    elif cmd == "find-contacts":
        result = await client.post("/search/contacts", {
            "filters": json.loads(args.filters), "page": args.page, "limit": args.limit,
        })
    elif cmd == "find-companies":
        result = await client.post("/search/companies", {
            "filters": json.loads(args.filters), "page": args.page, "limit": args.limit,
        })
    elif cmd == "build-list":
        result = await client.post("/search/contacts/save", {
            "filters": json.loads(args.filters), "list_title": args.title, "max_results": args.max_results,
        })
    elif cmd == "create-contact":
        body = {k: v for k, v in {
            "work_email": args.email, "first_name": getattr(args, "first_name", None),
            "last_name": getattr(args, "last_name", None), "job_title": getattr(args, "job_title", None),
            "company_domain": getattr(args, "company_domain", None), "list_id": getattr(args, "list_id", None),
        }.items() if v is not None}
        result = await client.post("/contacts", body)
    elif cmd == "create-list":
        result = await client.post("/lists", {"title": args.title, "type": args.type})
    elif cmd == "add-to-list":
        result = await client.post(f"/lists/{args.list_id}/contacts", {"contact_ids": _parse_ids(args.contact_ids)})
    elif cmd == "enrich":
        result = await client.post("/enrichment/enrich", {"contact_ids": _parse_ids(args.contact_ids), "list_id": args.list_id})
    elif cmd == "sequences":
        result = await client.get("/sequences", {"page": args.page, "limit": args.limit})
    elif cmd == "add-to-sequence":
        result = await client.post(f"/sequences/{args.sequence_id}/contacts", {
            "contact_ids": _parse_ids(args.contact_ids), "list_id": args.list_id,
        })
    elif cmd == "create-sequence":
        body: dict = {"name": args.name, "user_email": args.user_email, "finish_on_reply": True, "send_in_same_thread": False}
        if args.description:
            body["description"] = args.description
        if args.steps:
            body["steps"] = json.loads(args.steps)
        if args.channels:
            body["channels"] = json.loads(args.channels)
        if args.campaign_id:
            body["campaign_id"] = args.campaign_id
        result = await client.post("/sequences", body)
    elif cmd == "sequence-preview":
        result = await client.get(f"/sequences/{args.sequence_id}/preview")
    elif cmd == "update-sequence":
        body = {k: v for k, v in {"name": getattr(args, "name", None), "description": getattr(args, "description", None)}.items() if v is not None}
        result = await client.patch(f"/sequences/{args.sequence_id}", body)
    elif cmd == "update-sequence-step":
        body = {k: v for k, v in {
            "step_data": json.loads(args.step_data) if getattr(args, "step_data", None) else None,
            "time_interval": getattr(args, "time_interval", None),
            "step_type": getattr(args, "step_type", None),
        }.items() if v is not None}
        result = await client.patch(f"/sequences/{args.sequence_id}/steps/{args.step_id}", body)
    elif cmd == "pause-sequence":
        result = await client.post(f"/sequences/{args.sequence_id}/pause")
    elif cmd == "resume-sequence":
        result = await client.post(f"/sequences/{args.sequence_id}/resume")
    elif cmd == "sequence-analytics":
        result = await client.get(f"/sequences/{args.sequence_id}/analytics")
    elif cmd == "delete-sequence":
        result = await client.delete(f"/sequences/{args.sequence_id}")
    elif cmd == "campaigns":
        result = await client.get("/campaigns", {"page": args.page, "limit": args.limit})
    elif cmd == "campaign":
        result = await client.get(f"/campaigns/{args.campaign_id}")
    elif cmd == "inbox-list":
        result = await client.get("/inbox", {
            "channel": getattr(args, "channel", None),
            "sequence_id": getattr(args, "sequence_id", None),
            "status": getattr(args, "status", None),
            "assignee": getattr(args, "assignee", None),
            "tag": getattr(args, "tag", None),
            "page": args.page,
            "page_size": getattr(args, "page_size", 50),
        })
    elif cmd == "inbox-get":
        result = await client.get(f"/inbox/{args.reply_id}", {"channel": args.channel})
    elif cmd == "inbox-assign":
        result = await client.post(
            f"/inbox/{args.reply_id}/assign?channel={args.channel}",
            {"assignee_email": args.email},
        )
    elif cmd == "inbox-tag":
        tag_ids = [t.strip() for t in args.tag_ids.split(",")]
        result = await client.post(
            f"/inbox/{args.reply_id}/tag?channel={args.channel}",
            {"tag_ids": tag_ids},
        )
    elif cmd == "inbox-draft":
        result = await client.get(f"/inbox/{args.reply_id}/draft", {"channel": args.channel})
    elif cmd == "inbox-send":
        payload = {"body": args.body, "channel": args.channel}
        if getattr(args, "subject", None):
            payload["subject"] = args.subject
        if getattr(args, "to", None):
            payload["to"] = args.to
        if getattr(args, "from_address", None):
            payload["from_address"] = args.from_address
        result = await client.post(f"/inbox/{args.reply_id}/send", payload)
    # -- Audience Sync --
    elif cmd == "sync-audience-list":
        result = await client.get("/audience-syncs")
    elif cmd == "sync-audience-create":
        body: dict = {"audience_id": args.audience_id, "platform": args.platform, "mode": args.mode, "refresh_cadence_hours": args.cadence}
        if getattr(args, "name", None):
            body["platform_audience_name"] = args.name
        result = await client.post("/audience-syncs", body)
    elif cmd == "sync-audience-update":
        body = {}
        if getattr(args, "mode", None):
            body["mode"] = args.mode
        if getattr(args, "cadence", None) is not None:
            body["refresh_cadence_hours"] = args.cadence
        if getattr(args, "active", None) is not None:
            body["is_active"] = args.active == "true"
        result = await client.patch(f"/audience-syncs/{args.config_id}", body)
    elif cmd == "sync-audience-delete":
        result = await client.delete(f"/audience-syncs/{args.config_id}")
    elif cmd == "sync-audience-trigger":
        result = await client.post(f"/audience-syncs/{args.config_id}/trigger", {})
    elif cmd == "sync-audience-runs":
        result = await client.get(f"/audience-syncs/{args.config_id}/runs", {"limit": args.limit})
    elif cmd == "sync-audience-errors":
        result = await client.get(f"/audience-syncs/{args.config_id}/errors", {"limit": args.limit})
    # -- CRM Sync --
    elif cmd == "sync-crm-list":
        result = await client.get("/crm-syncs")
    elif cmd == "sync-crm-push":
        records = json.loads(args.records)
        result = await client.post(f"/crm-syncs/{args.provider}/{args.entity}/push", {"records": records})
    elif cmd == "sync-crm-fields":
        result = await client.get(f"/crm-syncs/{args.provider}/fields", {"entity_type": args.entity_type})
    elif cmd == "sync-crm-status":
        result = await client.get(f"/crm-syncs/{args.provider}/status")
    else:
        return

    _print_json(result)


async def _dispatch(args: argparse.Namespace) -> None:
    """Route to the appropriate command handler."""
    if args.command == "snippet":
        await _handle_snippet(args)
    elif args.command == "form":
        await _handle_form(args)
    else:
        await _api_call(args)


async def _handle_snippet(args: argparse.Namespace) -> None:
    """Handle the `g8 snippet` command."""
    from g8_mcp_server.tools.snippet import SUPPORTED_FRAMEWORKS, build_snippet_result

    if args.list:
        print("Supported frameworks:")
        for fid, name in SUPPORTED_FRAMEWORKS.items():
            print(f"  {fid:<12} {name}")
        return

    if not args.framework:
        print("Error: --framework is required (or use --list to see options)", file=sys.stderr)
        sys.exit(1)

    if args.framework not in SUPPORTED_FRAMEWORKS:
        print(f"Error: unsupported framework '{args.framework}'. Use --list to see options.", file=sys.stderr)
        sys.exit(1)

    client = G8Client(require_key=True)
    snippet_data = await _fetch_snippet_data(client, args.repo_id)
    write_key = snippet_data.get("write_key", "")
    tracking_host = snippet_data.get("tracking_host", "https://t.graph8.com")

    result = build_snippet_result(args.framework, write_key, tracking_host)

    if args.format == "json":
        print(json.dumps(result, indent=2))
    else:
        _print_snippet_text(result)


async def _handle_form(args: argparse.Namespace) -> None:
    """Handle the `g8 form` command."""
    from g8_mcp_server.tools.forms import SUPPORTED_FRAMEWORKS, build_form_result

    if args.framework not in SUPPORTED_FRAMEWORKS:
        print(f"Error: unsupported framework '{args.framework}'.", file=sys.stderr)
        sys.exit(1)

    client = G8Client(require_key=True)
    snippet_data = await _fetch_snippet_data(client, args.repo_id)
    write_key = snippet_data.get("write_key", "")
    tracking_host = snippet_data.get("tracking_host", "https://t.graph8.com")

    field_stages = None
    if args.stages:
        try:
            field_stages = json.loads(args.stages)
        except json.JSONDecodeError:
            print("Error: --stages must be valid JSON", file=sys.stderr)
            sys.exit(1)

    result = build_form_result(args.framework, args.variant, write_key, tracking_host, field_stages, client.base_url)

    if args.format == "json":
        print(json.dumps(result, indent=2))
    else:
        _print_form_text(result)


async def _fetch_snippet_data(client: G8Client, repo_id: str | None) -> dict:
    """Fetch write key and tracking host from the backend."""
    if repo_id:
        resp = await client.get(f"/repos/{repo_id}/snippet")
    else:
        resp = await client.get("/snippet")

    data = resp.get("data", resp)
    return data


def _print_snippet_text(result: dict) -> None:
    """Print snippet result in human-readable terminal format."""
    print(f"\n{'='*60}")
    print(f"graph8 Tracking Snippet - {result['framework']}")
    print(f"{'='*60}\n")

    print("Setup Steps:")
    for i, step in enumerate(result.get("setup_steps", []), 1):
        print(f"  {i}. {step}")

    print(f"\nCode:\n{'-'*60}")
    print(result.get("snippet_code", ""))
    print(f"{'-'*60}")

    methods = result.get("tracking_methods", {})
    if isinstance(methods, dict):
        print("\nTracking Methods:")
        for name, example in methods.items():
            print(f"  {name}: {example}")
    else:
        print(f"\nTracking Methods:\n{methods}")

    print(f"\nPrivacy Options:\n{result.get('privacy_options', '')}")

    verification = result.get("verification", [])
    if isinstance(verification, list):
        print("\nVerification:")
        for i, step in enumerate(verification, 1):
            print(f"  {i}. {step}")
    else:
        print(f"\nVerification:\n{verification}")
    print()


def _print_form_text(result: dict) -> None:
    """Print form template result in human-readable terminal format."""
    variant = result.get("variant", "embedded")
    print(f"\n{'='*60}")
    print(f"graph8 Progressive Form ({variant}) - {result['framework']}")
    print(f"{'='*60}\n")

    print("Prerequisite:")
    print(f"  {result.get('prerequisite', '')}\n")

    print(f"Code:\n{'-'*60}")
    print(result.get("template_code", ""))
    print(f"{'-'*60}")

    print("\nField Stages:")
    for stage in result.get("field_stages", []):
        fields = ", ".join(f["name"] for f in stage.get("fields", []))
        print(f"  Stage {stage['stage']}: {fields}")

    print(f"\nData Flow:\n{result.get('data_flow', '')}")
    print(f"\nCustomization:\n{result.get('customization_guide', '')}")
    print()
