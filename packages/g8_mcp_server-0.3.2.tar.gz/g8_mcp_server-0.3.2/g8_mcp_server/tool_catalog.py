"""Startup-time snapshot of registered tools for progressive discovery.

Upgrade 1 of the MCP talk pattern (Anthropic Nov 2026). With 83 tools in `all`
mode, dumping every schema into `tools/list` at connect time wastes context.
This module captures each tool's `name` + `description` after registration so
`g8_tool_search` can do cheap keyword ranking without re-walking FastMCP
internals on every call.

The catalog is built once per server process via `build_catalog(server)` after
all tools are registered in `server.py::_register_tools`.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass

from mcp.server import FastMCP

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class CatalogEntry:
    name: str
    description: str
    # Lowercased tokens pre-split once so search hot-path is cheap.
    name_tokens: frozenset[str]
    desc_tokens: frozenset[str]


_CATALOG: dict[str, CatalogEntry] = {}


_TOKEN_RE = re.compile(r"[A-Za-z][A-Za-z0-9]+")


def _tokenize(text: str) -> frozenset[str]:
    if not text:
        return frozenset()
    # Split camelCase and snake_case; keep tokens >= 2 chars.
    raw = _TOKEN_RE.findall(text.lower())
    out: set[str] = set()
    for t in raw:
        if len(t) >= 2:
            out.add(t)
        # Also split on underscores inside tokens (already lowercased)
        for part in t.split("_"):
            if len(part) >= 2:
                out.add(part)
    return frozenset(out)


async def build_catalog(server: FastMCP) -> int:
    """Snapshot registered tools into the module-level catalog.

    Safe to call multiple times - rebuilds from the current server state. Must
    be called AFTER all tools are registered. Returns the number of tools
    indexed.
    """
    global _CATALOG
    tools = await server.list_tools()
    snapshot: dict[str, CatalogEntry] = {}
    for t in tools:
        desc = (t.description or "").strip()
        snapshot[t.name] = CatalogEntry(
            name=t.name,
            description=desc,
            name_tokens=_tokenize(t.name),
            desc_tokens=_tokenize(desc),
        )
    _CATALOG = snapshot
    logger.info("MCP tool catalog built: %d tools indexed", len(_CATALOG))
    return len(_CATALOG)


def all_tool_names() -> frozenset[str]:
    return frozenset(_CATALOG.keys())


def get_entry(name: str) -> CatalogEntry | None:
    return _CATALOG.get(name)


def search(query: str, limit: int = 10) -> list[tuple[CatalogEntry, float]]:
    """Rank catalog entries against a free-text query.

    Scoring (intentionally dumb but cheap):
    - +3 per query token found in the tool name tokens
    - +1 per query token found in description tokens
    - +2 bonus if any query term is a verbatim substring of the tool name
      (catches things like "enrich" → g8_enrich_contacts)
    """
    if not query or not _CATALOG:
        return []

    q_tokens = _tokenize(query)
    q_substrings = [t for t in re.findall(r"[A-Za-z0-9]+", query.lower()) if len(t) >= 3]

    scored: list[tuple[CatalogEntry, float]] = []
    for entry in _CATALOG.values():
        score = 0.0
        for qt in q_tokens:
            if qt in entry.name_tokens:
                score += 3.0
            if qt in entry.desc_tokens:
                score += 1.0
        lname = entry.name.lower()
        for sub in q_substrings:
            if sub in lname:
                score += 2.0
        if score > 0:
            scored.append((entry, score))

    scored.sort(key=lambda pair: (-pair[1], pair[0].name))
    return scored[:limit]
