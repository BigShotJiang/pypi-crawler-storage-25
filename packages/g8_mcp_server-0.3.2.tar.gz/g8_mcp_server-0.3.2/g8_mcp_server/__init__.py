"""graph8 MCP server - GTM operations for AI agents."""

__version__ = "0.3.2"
