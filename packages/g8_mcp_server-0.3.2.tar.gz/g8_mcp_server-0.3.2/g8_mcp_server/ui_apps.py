"""MCP Apps protocol helpers for graph8's Python MCP server.

The official `@modelcontextprotocol/ext-apps` package is TypeScript-only.
This module implements the same wire-level registration pattern against
FastMCP so we can:

  1. Register `ui://` resources with mime type `text/html;profile=mcp-app`
     (the literal spec-mandated value), including `_meta.ui.csp` +
     `_meta.ui.permissions` on the resource content.
  2. Link tools to a UI resource via `_meta.ui.resourceUri`, so an
     MCP Apps-capable host (claude.ai, Claude Desktop, VS Code Copilot,
     Goose, ...) renders the UI inline when the tool fires.

Everything here is a thin sugar layer over `@server.resource` and
`@server.tool` from FastMCP >= 1.26 (1.26 is required because the
`meta` field on `ReadResourceContents` is propagated to the wire
`TextResourceContents._meta` starting in that release; earlier
versions silently drop it).

Spec references:
  - Overview:  https://modelcontextprotocol.io/extensions/apps/overview
  - Wire spec: https://github.com/modelcontextprotocol/ext-apps/blob/main/specification/draft/apps.mdx
  - Launch blog (2026-01-26):
    https://blog.modelcontextprotocol.io/posts/2026-01-26-mcp-apps/

Backward compat: the legacy `g8://` text/html resources registered in
``resources.py`` are NOT touched by this module. They continue to work
as text attachments in claude.ai (Claude reasons over the HTML as
content). This module adds the `ui://` variant alongside, linked from a
tool via `_meta.ui.resourceUri` to trigger inline widget rendering.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
from pathlib import Path
from typing import Any, Awaitable, Callable

from mcp.server import FastMCP
from mcp.server.lowlevel.helper_types import ReadResourceContents

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Client-specific domain constraints
# ---------------------------------------------------------------------------

#: Default public URL of the graph8 MCP endpoint (prod). Overridable via the
#: ``G8_MCP_PUBLIC_URL`` env var so QA / dev deployments emit the right
#: claudemcpcontent.com hash for the host they're running on.
_DEFAULT_MCP_PUBLIC_URL: str = "https://be.graph8.com/mcp"


def claude_mcp_domain(public_url: str | None = None) -> str:
    """Compute claude.ai's expected ``ui.domain`` value for this MCP server.

    Per claude.ai's enforcement (observed 2026-04-24): the ``_meta.ui.domain``
    field on a ``ui://`` resource MUST match
    ``{first-32-chars-of-sha256(mcp_url)}.claudemcpcontent.com`` or the
    widget is rejected at render time with an "Invalid ui.domain format"
    banner. The upstream MCP Apps spec calls this field an informational
    label, so claude.ai's constraint is client-specific; other hosts
    (Claude Desktop, Goose, etc.) tolerate free-form labels or ignore it.

    We emit the claude.ai-compatible value unconditionally because it's also
    valid on the clients that ignore the field.

    Args:
      public_url: Full MCP endpoint URL to hash. Defaults to
        ``$G8_MCP_PUBLIC_URL`` if set, else the prod URL.
    """
    url = public_url or os.getenv("G8_MCP_PUBLIC_URL", _DEFAULT_MCP_PUBLIC_URL)
    digest = hashlib.sha256(url.encode()).hexdigest()[:32]
    return f"{digest}.claudemcpcontent.com"


# ---------------------------------------------------------------------------
# Protocol constants (spec-mandated literals  -  do not change casually)
# ---------------------------------------------------------------------------

#: The literal MIME type string defined by the MCP Apps spec for HTML widgets.
#: Per the draft spec: *"SHOULD be text/html;profile=mcp-app for HTML-based
#: UIs in the initial MVP."*
UI_MIME_TYPE: str = "text/html;profile=mcp-app"

#: The URI scheme all MCP App resources must use. Per the spec: *"Must start
#: with `ui://`"*. Plain `text/html` resources on other schemes still work
#: but hosts will deliver them as text attachments rather than inline widgets.
UI_SCHEME: str = "ui://"

#: Directory where single-file HTML+JS app bundles live, one per surface.
#: Layout: ``mcp_server/g8_mcp_server/ui_bundles/{name}.html``.
_BUNDLE_DIR: Path = Path(__file__).parent / "ui_bundles"

#: Path to the vendored ``@modelcontextprotocol/ext-apps`` IIFE bundle. See
#: ``ui_bundles/_vendor/README.md`` for how this file is built. We inline it
#: because claude.ai's widget-iframe CSP is ``script-src 'self'
#: 'unsafe-inline' ... https://assets.claude.ai`` and ignores our resource's
#: ``_meta.ui.csp.resourceDomains`` list - so no CDN imports survive.
_VENDOR_BUNDLE_PATH: Path = _BUNDLE_DIR / "_vendor" / "ext-apps.iife.min.js"

#: Literal placeholder string that widget HTML templates use to mark where
#: the vendored SDK bundle should be injected. ``load_bundle`` substitutes
#: this (and only this) with the file contents of ``_VENDOR_BUNDLE_PATH``.
#: Widgets that don't need the SDK omit the placeholder and pass through
#: unchanged (backwards-compatible).
VENDOR_BUNDLE_PLACEHOLDER: str = "<!--@MCP_APPS_VENDOR_BUNDLE@-->"

#: Literal placeholder for the per-widget ``view_config`` JSON. Used by the
#: generic ``shell.html`` bundle so a single shell can render arbitrary
#: widgets driven by a Python-supplied config dict. Substitution leaves the
#: surrounding ``<script type="application/json">`` block intact -- only the
#: placeholder text is swapped for serialized JSON. Widgets that don't use
#: the shell omit the placeholder and pass through unchanged.
VIEW_CONFIG_PLACEHOLDER: str = "{{VIEW_CONFIG_JSON}}"


# ---------------------------------------------------------------------------
# Bundle loading
# ---------------------------------------------------------------------------


def _read_vendor_bundle() -> str:
    """Read the vendored MCP Apps SDK IIFE bundle from disk.

    Raises FileNotFoundError if the bundle is missing -- that means the
    image was built without ``ui_bundles/_vendor/ext-apps.iife.min.js``,
    which is a deployment bug. Build instructions are in
    ``ui_bundles/_vendor/README.md``.
    """
    if not _VENDOR_BUNDLE_PATH.is_file():
        raise FileNotFoundError(
            f"Vendored MCP Apps SDK bundle not found at {_VENDOR_BUNDLE_PATH}. "
            f"Rebuild it per ui_bundles/_vendor/README.md."
        )
    return _VENDOR_BUNDLE_PATH.read_text(encoding="utf-8")


def _serialize_view_config(view_config: dict[str, Any]) -> str:
    r"""Serialize a view-config dict to a JSON string safe to embed inside
    a ``<script type="application/json">`` block.

    The only escape we need is ``</`` -> ``<\/``: HTML5 closes a script
    block on the literal byte sequence ``</script`` regardless of script
    type. Keys with a ``</`` byte sequence in their values would otherwise
    truncate the JSON block early. ``json.dumps`` doesn't escape this by
    default; we patch it post-hoc instead of using ``ensure_ascii`` (which
    would also bloat the bundle for non-ASCII labels).
    """
    raw = json.dumps(view_config, ensure_ascii=False)
    return raw.replace("</", "<\\/")


def load_bundle(
    bundle_name: str,
    *,
    view_config: dict[str, Any] | None = None,
) -> str:
    """Load a UI bundle HTML file by name (without extension).

    Bundles live in ``mcp_server/g8_mcp_server/ui_bundles/{name}.html`` and
    must be single-file HTML with inlined JS + CSS.

    Two placeholders are substituted, both optional and independent:

    1. ``<!--@MCP_APPS_VENDOR_BUNDLE@-->`` -> ``<script>{vendor-iife}</script>``
       Required for any widget that uses the MCP Apps SDK (see
       ``ui_bundles/_vendor/README.md``). Widgets without this placeholder
       pass through unchanged.

    2. ``{{VIEW_CONFIG_JSON}}`` -> JSON-serialized ``view_config``
       Used by the generic ``shell.html`` so a single shell can render
       arbitrary widgets driven by config. If the placeholder is present
       but ``view_config`` is None, we substitute ``null`` so the bundle's
       JSON.parse fails fast at widget load time with a clear error.
       Bundles without this placeholder ignore ``view_config`` entirely.

    Both substitutions are byte-level string replaces -- order doesn't
    matter, and bundles can use either, both, or neither placeholder.
    The call is backwards-compatible: existing call sites that pass
    ``bundle_name`` positionally and no ``view_config`` get the prior
    behavior (vendor injection only).

    Raises:
        FileNotFoundError: if the bundle file is missing, OR if the
            vendor placeholder is used but the vendor file is gone --
            both indicate deployment bugs that should fail loudly.
    """
    path = _BUNDLE_DIR / f"{bundle_name}.html"
    if not path.is_file():
        raise FileNotFoundError(
            f"MCP App bundle {bundle_name!r} not found at {path}. "
            f"Expected a single-file HTML at that path."
        )
    html = path.read_text(encoding="utf-8")
    if VENDOR_BUNDLE_PLACEHOLDER in html:
        vendor = _read_vendor_bundle()
        # Wrap in a classic <script> tag so `var __mcpApps = ...` at the top
        # level of the IIFE attaches to `window` and is reachable from the
        # module script that runs afterwards.
        injection = f"<script>{vendor}</script>"
        html = html.replace(VENDOR_BUNDLE_PLACEHOLDER, injection, 1)
    if VIEW_CONFIG_PLACEHOLDER in html:
        json_str = _serialize_view_config(view_config) if view_config else "null"
        # Replace ALL occurrences (no count limit). The single-occurrence
        # contract is brittle: docs/comments inside the bundle that
        # mention the placeholder by name would be the silent first hit
        # and leave the real <script> block unsubstituted.
        html = html.replace(VIEW_CONFIG_PLACEHOLDER, json_str)
    return html


# ---------------------------------------------------------------------------
# Metadata builders
# ---------------------------------------------------------------------------


def ui_resource_meta(
    *,
    csp: dict[str, list[str]] | None = None,
    permissions: dict[str, dict[str, Any]] | None = None,
    prefers_border: bool | None = None,
    domain: str | None = None,
) -> dict[str, Any]:
    """Build the ``_meta.ui`` object that goes on a UI resource's contents.

    Per `the spec <https://github.com/modelcontextprotocol/ext-apps/blob/main/specification/draft/apps.mdx>`_:

    - ``csp`` - Content-Security-Policy overrides. Shape:
      ``{"resourceDomains": ["..."], "connectDomains": ["..."],
      "frameDomains": ["..."], "baseUriDomains": ["..."]}``.
      Any origin the app loads assets from or connects to MUST be listed.
      Wildcards are forbidden.

    - ``permissions`` - Iframe Permission-Policy requests. Shape:
      ``{"camera": {}, "microphone": {}, "geolocation": {},
      "clipboardWrite": {}}``. Each allowed key is an empty object
      (future-proofing for scoped options).

    - ``prefers_border`` - Cosmetic: host SHOULD render the iframe with a
      visible border if True.

    - ``domain`` - Informational label shown to the user (e.g. "graph8").

    Returns a dict shaped ``{"ui": {...}}`` suitable for passing as the
    ``meta`` kwarg to ``@server.resource``.
    """
    ui: dict[str, Any] = {}
    if csp is not None:
        ui["csp"] = csp
    if permissions is not None:
        ui["permissions"] = permissions
    if prefers_border is not None:
        ui["prefersBorder"] = prefers_border
    if domain is not None:
        ui["domain"] = domain
    return {"ui": ui} if ui else {}


def ui_tool_meta(
    resource_uri: str,
    *,
    visibility: list[str] | None = None,
) -> dict[str, Any]:
    """Build the ``_meta.ui`` object that goes on a UI-linked tool.

    - ``resource_uri`` - The ``ui://...`` URI of the MCP App this tool
      drives. When the tool is invoked by an MCP-Apps-aware host, the host
      will read this resource and render it, then push the tool result to
      the app via ``ontoolresult``.

    - ``visibility`` - Optional list controlling who sees the tool:
      ``["model"]`` (only the LLM can invoke it), ``["app"]`` (only the
      rendered app can invoke it via postMessage), or both (the default
      if omitted).

    Returns a dict shaped ``{"ui": {...}}`` suitable for passing as the
    ``meta`` kwarg to ``@server.tool``.
    """
    if not resource_uri.startswith(UI_SCHEME):
        raise ValueError(
            f"UI tool's resource_uri must start with {UI_SCHEME!r}: "
            f"got {resource_uri!r}"
        )
    ui: dict[str, Any] = {"resourceUri": resource_uri}
    if visibility is not None:
        ui["visibility"] = visibility
    return {"ui": ui}


# ---------------------------------------------------------------------------
# Registration helper
# ---------------------------------------------------------------------------


def register_ui_app_resource(
    server: FastMCP,
    *,
    uri: str,
    bundle_name: str,
    description: str,
    csp: dict[str, list[str]] | None = None,
    permissions: dict[str, dict[str, Any]] | None = None,
    prefers_border: bool | None = None,
    domain: str | None = None,
    view_config: dict[str, Any] | None = None,
) -> None:
    """Register a ``ui://`` MCP App resource backed by a bundled HTML file.

    Two registration styles are supported:

    1. **Bespoke bundle** -- ``bundle_name`` points to a fully custom HTML
       file (e.g. ``"campaigns_dashboard"``) and ``view_config`` is None.
       The bundle ships its own DOM/CSS/JS. Used by the original PoC.

    2. **Shell + view_config** -- ``bundle_name="shell"`` plus a
       ``view_config`` dict describing which views the widget exposes,
       what fields drive the cards/tables, and which tools row clicks
       fire. The shell's generic renderer reads the config at load time
       and shapes itself accordingly. Used for scaling to many widgets
       without per-widget HTML.

    Example (style 2)::

        register_ui_app_resource(
            server,
            uri="ui://contacts/list",
            bundle_name="shell",
            description="Contact search results",
            domain=claude_mcp_domain(),
            view_config={
                "page_title": "graph8 contacts",
                "header_title": "Contacts",
                "root_view_id": "list",
                "views": {
                    "list": {
                        "type": "table",
                        "data_path": "contacts",
                        "columns": [
                            {"key": "first_name", "label": "First", "primary": True},
                            {"key": "last_name", "label": "Last"},
                            {"key": "work_email", "label": "Email"},
                        ],
                    },
                },
            },
        )

    The URI is the one tools target via ``_meta.ui.resourceUri``. The bundle
    file is loaded lazily on each read.

    ``description`` is what shows up in ``resources/list``; keep it short.
    """
    if not uri.startswith(UI_SCHEME):
        raise ValueError(
            f"UI resource URI must start with {UI_SCHEME!r}: got {uri!r}"
        )
    # Fail fast if the bundle file is missing OR the view-config doesn't
    # serialize cleanly -- both are deployment bugs that should crash at
    # registration time, not at first widget render.
    _ = load_bundle(bundle_name, view_config=view_config)

    meta = ui_resource_meta(
        csp=csp,
        permissions=permissions,
        prefers_border=prefers_border,
        domain=domain,
    )

    @server.resource(
        uri,
        mime_type=UI_MIME_TYPE,
        description=description,
        meta=meta or None,
    )
    async def _ui_resource() -> str:  # pragma: no cover - trivial wrapper
        # Load the bundle lazily so dev edits to the HTML file show up on the
        # next read without a server restart. This is cheap enough (one file
        # read per read_resource call, bundles are <100 KB).
        return load_bundle(bundle_name, view_config=view_config)


__all__ = [
    "UI_MIME_TYPE",
    "UI_SCHEME",
    "VENDOR_BUNDLE_PLACEHOLDER",
    "VIEW_CONFIG_PLACEHOLDER",
    "claude_mcp_domain",
    "load_bundle",
    "ui_resource_meta",
    "ui_tool_meta",
    "register_ui_app_resource",
]
