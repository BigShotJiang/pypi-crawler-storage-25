# MCP Apps SDK — vendored IIFE bundle

## Why inline?

claude.ai's iframe sandbox for MCP widgets is served from
`{sha256(mcp_url)[:32]}.claudemcpcontent.com` and inherits the
claude.ai page-level CSP:

```
script-src 'self' 'unsafe-inline' 'unsafe-eval' blob: data: https://assets.claude.ai
```

claude.ai ignores the `_meta.ui.csp.resourceDomains` list on the
resource — so any CDN import (`cdn.jsdelivr.net`, `esm.sh`, unpkg, etc.)
inside the widget is blocked before `App.connect()` can run. The only
JavaScript claude.ai will execute in the widget iframe is **inline**
(`'unsafe-inline'`), so the MCP Apps SDK must be inlined.

## How this is built

```bash
# 1. Install SDK + esbuild in a throwaway dir
mkdir -p /tmp/mcp-apps-bundle && cd /tmp/mcp-apps-bundle
npm init -y
npm install @modelcontextprotocol/ext-apps@1.7.0 esbuild

# 2. Re-export the public surface we need
cat > entry.js <<'EOF'
export { App } from "@modelcontextprotocol/ext-apps";
EOF

# 3. Bundle everything (SDK + MCP core SDK + zod) into a single IIFE
./node_modules/.bin/esbuild entry.js \
  --bundle --format=iife --global-name=__mcpApps \
  --platform=browser --target=es2022 --minify \
  --outfile=ext-apps.iife.min.js

# 4. Copy into place
cp ext-apps.iife.min.js <repo>/mcp_server/g8_mcp_server/ui_bundles/_vendor/
```

The bundle exposes a global `__mcpApps` object with `App` as the only
export. Usage from the widget HTML:

```html
<script>/* contents of ext-apps.iife.min.js */</script>
<script type="module">
  const { App } = __mcpApps;
  const app = new App({ name: "...", version: "..." });
  // ...
</script>
```

## Versioning

Currently pinned to `@modelcontextprotocol/ext-apps@1.7.0` (latest as of
2026-04-22). Bump deliberately — the host postMessage contract is the
blast radius, not just our bundle.

## Size

~423 KB minified, ~77 KB brotli over the wire. The bundle is injected
into both widget HTML resources at read time by
`ui_apps.load_bundle()`, which substitutes the literal placeholder
`<!--@MCP_APPS_VENDOR_BUNDLE@-->` in the widget HTML with the contents
of this file.
