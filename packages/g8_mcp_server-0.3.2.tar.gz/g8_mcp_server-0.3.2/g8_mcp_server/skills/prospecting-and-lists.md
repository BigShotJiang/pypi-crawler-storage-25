# Skill: Prospecting and Lists

**When to use this skill:** the user wants to find new leads, build a contact list, or enrich contacts they already have.

## Core concept you must get right

graph8 has two very different data sources. Confusing them produces wrong answers.

| Source | Tools | What it is |
|---|---|---|
| **Your CRM** (PostgreSQL) | `g8_search_contacts`, `g8_search_companies` | Only contacts your org has already imported or created. |
| **Open data index** (300M+ records) | `g8_find_contacts`, `g8_find_companies`, `g8_lookup_person`, `g8_lookup_company` | The global prospecting database. |

Rule: if the user says "find me" or "give me new leads," always use the open-data tools. If they say "check whether we have" or "who in our list is...," use the CRM tools.

## The list-building workflow (prescriptive)

Follow this sequence for any "build me a list of X" request:

1. **Sample with a small limit.** Call `g8_find_contacts(filters, limit=25)` first. Show the user the top 3-5 rows and ask them to confirm the filters before committing to a larger save.

2. **Confirm before saving.** `g8_build_contact_list` commits to `max_results`. Ask the user before calling — filters that look right on 25 rows can produce garbage on 500.

3. **Save the list.** Call `g8_build_contact_list(filters=same_filters, list_title="...", max_results=N)`. Use a descriptive list title like "VP Sales at SaaS 50-500" rather than "My List." This is the list the user will see in the Workbench UI later.

4. **Optionally enrich.** If the saved contacts are missing emails or phones, call `g8_enrich_contacts(contact_ids, list_id)`. Ask before enriching — the user may want to spot-check the list first.

5. **Optionally enroll.** To push the list into outreach, use the running-a-campaign skill or `g8_list_sequences` + `g8_add_to_sequence`. Never enroll contacts in a sequence without explicit user confirmation — it sends real messages.

## Filter format

Filters for `g8_find_contacts`, `g8_find_companies`, and `g8_build_contact_list` are a list of dicts. Each dict has:

```json
{"field": "seniority_level", "operator": "any_of", "value": ["VP", "Director"]}
```

**Common contact fields:** `first_name`, `last_name`, `work_email`, `job_title`, `seniority_level`, `job_department`, `role`, `company_name`, `company_domain`, `company_industry`, `company_employee_count`, `company_revenue`, `country`, `state`, `city`.

**Common company fields:** `name`, `domain`, `industry`, `employee_count`, `revenue`, `founded_year`, `country`.

**Operators:** `any_of`, `contains`, `all_of`, `none_of`, `is_empty`, `is_not_empty`, `between`, `exists`.

**Real example** (VPs of Sales at US SaaS companies with 50-500 headcount):

```json
[
  {"field": "seniority_level", "operator": "any_of", "value": ["VP"]},
  {"field": "job_department", "operator": "any_of", "value": ["Sales"]},
  {"field": "company_industry", "operator": "contains", "value": ["SaaS", "Software"]},
  {"field": "company_employee_count", "operator": "between", "value": [50, 500]},
  {"field": "country", "operator": "any_of", "value": ["United States"]}
]
```

## Single-person and single-company lookup

If the user asks about one specific person or company (by email, LinkedIn URL, or domain), use the faster single-record tools:

- `g8_lookup_person(email=..., linkedin_url=..., first_name=..., last_name=..., company_domain=...)` — returns enriched profile.
- `g8_lookup_company(domain=..., name=...)` — returns enriched firmographics.

These do not save to CRM. To save, follow up with `g8_create_contact(work_email=..., ...)` which returns a `contact_id` you can then `g8_add_to_list` or `g8_add_to_sequence`.

## Common mistakes to avoid

- **Do not call `g8_build_contact_list` before sampling with `g8_find_contacts`.** You will commit to saving up to `max_results` contacts on filters the user did not validate. A 25-record sample first lets you confirm the filters before committing.
- **Do not pass prospecting records to `g8_add_to_sequence` or `g8_add_to_list`.** Those tools need `contact_id` (integer) from the CRM. Prospecting results are not yet in the CRM. Save them first with `g8_build_contact_list` or `g8_create_contact`.
- **Do not create a list with `g8_create_list` if the user wants it populated.** Use `g8_build_contact_list` instead — it creates the list and populates it in one call.
- **Do not skip the enrichment confirmation.** "Enrich these 500 contacts" sounds harmless but can produce results the user did not want. Always confirm before calling.

## Chaining into outreach

Once contacts are saved to a list (`list_id`), the typical next step is:

1. `g8_list_sequences(limit=50)` — find an existing sequence to use.
2. Show the user the sequence name and ask which one to enroll into.
3. `g8_add_to_sequence(sequence_id, contact_ids, list_id)` — confirm with user first. This starts real outreach.

If no suitable sequence exists, create one with `g8_create_sequence` — but campaign-level planning is better handled via the running-a-campaign skill.
