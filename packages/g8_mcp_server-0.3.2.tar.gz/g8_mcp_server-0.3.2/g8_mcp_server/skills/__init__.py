"""graph8 MCP skills - markdown workflow guides loaded on demand.

Skills are prescriptive domain-knowledge documents that teach an agent how
to use graph8 tools in the right order, with the right confirmations, for
a specific user journey. They are distinct from tool docstrings (which
describe individual tools) and prompts (which are pre-canned user messages).

Exposed through two surfaces:
- Tools: g8_list_skills, g8_load_skill (see g8_mcp_server/tools/skills.py)
- Resources: g8://skills, g8://skills/{slug} (see g8_mcp_server/resources.py)
"""

from __future__ import annotations

from pathlib import Path
from typing import TypedDict

_SKILLS_DIR = Path(__file__).parent


class SkillEntry(TypedDict):
    """Catalog metadata for one skill. Content lives in the sibling .md file."""

    slug: str
    title: str
    summary: str
    path: str  # filename within the skills/ directory
    when_to_use: str


# Ordered catalog. Keep the list short and curated - this is the first
# thing the model sees when it calls g8_list_skills. Each summary should
# answer "when would I reach for this skill?"
SKILLS_CATALOG: list[SkillEntry] = [
    {
        "slug": "prospecting-and-lists",
        "title": "Prospecting and Lists",
        "summary": "Find new leads in graph8's 300M+ open data index, preview filters safely, save to CRM lists, and enrich contacts.",
        "path": "prospecting-and-lists.md",
        "when_to_use": "User wants to find new leads, build a contact list, or enrich contacts.",
    },
    {
        "slug": "running-a-campaign",
        "title": "Running a Campaign End-to-End",
        "summary": "Ideate, draft, document, sequence, review, and launch a graph8 campaign. Covers loading brand context, building steps, and launch confirmations.",
        "path": "running-a-campaign.md",
        "when_to_use": "User wants to create, review, or launch a graph8 campaign.",
    },
    {
        "slug": "installing-tracking",
        "title": "Installing graph8 Tracking",
        "summary": "Install the p.js snippet on a website or wire up full Spine integration in a codebase. Picks between standalone snippet and repo-based install paths.",
        "path": "installing-tracking.md",
        "when_to_use": "User wants to install graph8 tracking, identity, forms, or attribution.",
    },
    {
        "slug": "ai-inbox-replies",
        "title": "AI Inbox Replies",
        "summary": "Triage the multi-channel inbox (email, SMS, LinkedIn), generate AI drafts, review, and send replies with confirmations.",
        "path": "ai-inbox-replies.md",
        "when_to_use": "User wants to read, triage, or reply to inbound messages in their inbox.",
    },
]


def get_skill_content(slug: str) -> str | None:
    """Return the markdown content for a skill by slug, or None if unknown."""
    entry = next((s for s in SKILLS_CATALOG if s["slug"] == slug), None)
    if entry is None:
        return None
    skill_path = _SKILLS_DIR / entry["path"]
    if not skill_path.exists():
        return None
    return skill_path.read_text(encoding="utf-8")


def list_skill_slugs() -> list[str]:
    """Return the list of available skill slugs."""
    return [s["slug"] for s in SKILLS_CATALOG]
