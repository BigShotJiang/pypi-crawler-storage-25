# Skill: AI Inbox Replies

**When to use this skill:** the user wants to triage their graph8 inbox, read inbound replies from prospects, draft responses with AI assistance, or send replies through email, SMS, or LinkedIn.

## Core concept

The graph8 inbox is a unified view of replies across three channels:

| Channel | What it is |
|---|---|
| `email` | Inbound replies to sequence emails |
| `sms` | SMS replies from sequence messages |
| `linkedin` | LinkedIn DM replies and connection responses |

Each thread has a `reply_id` and a `channel`. **You must pass the correct channel on every tool call.** Calling `g8_get_reply(reply_id, channel="email")` against a LinkedIn thread will fail.

## The reply workflow (prescriptive)

### Step 1 — triage the inbox

Start here whenever the user says "what's in my inbox" or "any new replies":

```
g8_list_inbox(page=1, page_size=50)                   # all channels
g8_list_inbox(channel="email", status="unread")       # narrow to email unreads
g8_list_inbox(channel="linkedin", assignee="me@..." ) # my assigned LinkedIn threads
g8_list_inbox(sequence_id="seq_abc", page_size=100)   # all replies from one sequence
```

Return format: a list of threads with `reply_id`, `channel`, latest message preview, contact info, status, tags, assignee. Summarize the highlights (count by channel, count unread, any urgent-looking tags) before going deeper.

### Step 2 — load a single thread

```
g8_get_reply(reply_id="reply_xyz", channel="email")
```

This returns the full message history for the thread. Read it end-to-end before suggesting any reply — a thread may span 4-6 messages and the latest message is not always the right one to reply to.

### Step 3 — generate a draft (optional)

If the user wants AI help drafting the reply:

```
g8_get_reply_draft(reply_id="reply_xyz", channel="email")
```

Before calling, tell the user you are about to generate a draft and ask if they want to proceed. The draft is generated from the full thread history, so the quality scales with how much context the thread has.

### Step 4 — review and edit

The draft is a starting point, not a finished reply. Show it to the user and ask:

- Does this match the tone they want?
- Is there a specific detail (numbers, timeline, a product link) that must be included?
- Should the signature or from-address be different?

Edit based on their feedback before sending.

### Step 5 — send (destructive, always confirm)

```
g8_send_reply(
    reply_id="reply_xyz",
    channel="email",            # or "sms" or "linkedin"
    body="Hi Jane, ...",
    subject="Re: Quick question about ACME",   # email only
    to="jane@acme.com",         # email address, phone number, or LinkedIn ID
    from_address="sam@ourco.com",               # mailbox, phone, or LinkedIn account
)
```

**This sends a real message.** It cannot be unsent. Before calling, confirm with the user:

> "I'm about to send this reply to `jane@acme.com` from `sam@ourco.com`. Here it is:\n\n[body]\n\nConfirm?"

Never call `g8_send_reply` without explicit yes.

## Channel-specific gotchas

### Email
- `subject` is optional — if omitted, the send inherits "Re: {original subject}" from the thread
- `from_address` must be a mailbox the org has connected
- HTML bodies need proper escaping; plaintext is safer for agent-generated replies

### SMS
- `to` is a phone number in E.164 format (e.g., `+15551234567`)
- `from_address` is a phone number the org has provisioned
- Omit `subject` — SMS has no subject line; any value is silently dropped by the provider
- Keep the body short (ideally under 160 chars to avoid SMS segmentation into multiple billable messages)

### LinkedIn
- `to` is a LinkedIn member ID or account identifier, not a URL
- `from_address` is the LinkedIn account ID the org has connected
- No `subject` — LinkedIn DMs don't have subjects
- Character limits are more forgiving than SMS but still avoid long walls of text

## Assignment and tagging

For routing and categorization without sending:

```
g8_assign_reply(reply_id="reply_xyz", assignee_email="sam@ourco.com", channel="email")
g8_tag_reply(reply_id="reply_xyz", tag_ids=["tag_interested", "tag_hot"], channel="email")
```

These don't send messages. Use them when the user says "assign this to Sam" or "tag these as hot leads."

## Error handling

- **404** from `g8_get_reply` — wrong `reply_id` or wrong `channel`. Double-check both.
- **403** from `g8_send_reply` — usually a disconnected mailbox, provisioning issue, or missing LinkedIn account. Surface the error to the user; they likely need to reconnect the channel in settings.

## Common mistakes to avoid

- **Sending a draft verbatim without review.** AI drafts often get the facts right but the tone wrong. Show the user, let them edit.
- **Forgetting to pass `channel`.** Defaulting to `channel="email"` when the thread is LinkedIn will return a 404 or wrong thread.
- **Skipping `g8_get_reply` before sending.** Without reading the full thread you may reply to the wrong message, contradict something already said, or miss context from earlier turns.
- **Using `subject` on SMS or LinkedIn sends.** Not applicable; providers silently drop it. Not a failure, just dead weight.
