# Skill: Installing graph8 Tracking

**When to use this skill:** the user wants to install the graph8 tracking snippet (p.js) on their website or web application, set up identity resolution, progressive forms, or wire up full GTM infrastructure in a codebase.

**Who this is for:** primarily developers working in Cursor, Windsurf, Claude Code, or VS Code with the MCP server connected. These tools are registered in `dev` mode (and in `all` mode).

## Two paths - pick the right one

### Path A: Standalone snippet (no codebase needed)

If the user is not in a connected repo and just wants the tracking script to paste into their site:

```
g8_get_tracking_snippet(framework="nextjs")
```

This returns framework-specific installation code (HTML, React, Next.js, Vue, WordPress, Webflow, Shopify). Hand the snippet to the user and stop.

### Path B: Full repo install (Spine)

If the user is in a codebase and wants graph8 deeply integrated (tracking + identity + forms + attribution + analytics events baked into their stack), use the Spine flow:

1. `g8_connect_repo(repo_url, repo_name)`
2. `g8_scan_repo(repo_id)`
3. `g8_get_scan_results(repo_id)` - review detected stack
4. `g8_install_spine(repo_id)` - generates a patch set
5. **Show patches to user, confirm**
6. `g8_apply_install(repo_id)` - destructive, modifies codebase
7. `g8_doctor(repo_id)` - verify installation

Use Path B when the user says "integrate graph8," "install graph8 properly," "wire up tracking and forms," or when you see a connected repo in `g8_status`.

Use Path A when they say "just give me the script" or when no repo is connected.

## Path A details - standalone snippet

Supported frameworks: `html`, `react`, `nextjs`, `vue`, `wordpress`, `webflow`, `shopify`.

### SSR vs CSR matters

For **SSR frameworks** (Next.js, WordPress, Shopify), the snippet loads in the server-rendered HTML head, so `window.g8` is available on first paint.

For **CSR frameworks** (React, Vue), the snippet injects via `useEffect` or `onMounted`, so it becomes available after hydration. Always use defensive calls like `window.g8?.track(...)` rather than `window.g8.track(...)`. The optional chaining prevents errors if a track call fires before the script has loaded.

### Post-install setup (always tell the user)

Installing the script is step one. The user still needs to:

1. **Identify users** on login/signup:
   ```
   g8.identify('user-id', { email: 'user@example.com', name: 'Jane Doe' })
   ```
2. **Track key events** for conversion attribution:
   ```
   g8.track('signup_completed', { plan: 'pro' })
   g8.track('trial_started', { source: 'homepage' })
   g8.track('meeting_booked', { campaign_id: 'xyz' })
   ```
3. **Use progressive forms** for lead capture (see "Progressive forms" section below).

## Path B details - full Spine install

### Step 1 - connect

```
g8_connect_repo(
    repo_url="https://github.com/acme/marketing-site",
    repo_name="acme-site",
    provider="github",        # or "gitlab" or "local"
    default_branch="main",
)
```

Returns `repo_id`. Save it - every subsequent dev-mode tool needs it.

### Step 2 - scan

```
g8_scan_repo(repo_id)         # kicks off analysis
g8_get_scan_results(repo_id)  # read findings
```

Scan output includes detected framework, API routes, README summary, and **GTM readiness flags** (e.g., "has login page," "has pricing page," "no tracking installed"). Surface these flags to the user.

### Step 3 - generate install patches

```
g8_install_spine(repo_id)
```

This returns a patch set - proposed edits across multiple files to wire up tracking, identity, forms, and attribution. **Do not apply patches without showing them to the user first.** This is real code that will land in their repo.

Summarize for the user:
- number of files modified
- key changes per file (tracking added to layout, identity call added to login handler, form component created, env vars declared)

### Step 4 - apply (destructive, always confirm)

```
g8_apply_install(repo_id)
```

This writes the patches to the working tree. Ask the user for explicit confirmation with wording like:

> "I'm about to modify N files in your repo to wire up graph8 tracking. This will add the p.js script to your layout, an identify call to your auth handler, and a progressive form component. Proceed?"

### Step 5 - verify

```
g8_doctor(repo_id)
```

Runs health checks on the installed integration. If anything is misconfigured (missing write key, script tag not present on the rendered page, identity call missing), the doctor output will flag it.

## Progressive forms

Once tracking is installed, set up progressive forms for lead capture:

```
g8_get_form_template(
    framework="react",         # html, react, nextjs, vue, wordpress, webflow, shopify
    variant="embedded",        # "embedded" (inline) or "popup" (overlay with triggers)
)
```

Both `framework` and `variant` are required. You can optionally pass `field_stages` (JSON string) to override the default 3-stage progressive fill, and `repo_id` to use repo-scoped config.

Progressive forms start with just email, then reveal additional fields (name, company, job title, budget, timeline) across multiple stages as the lead returns to the site. graph8 resolves identity across sessions so the form "remembers" what was already submitted.

Default field staging:
- **Stage 1** (first visit): email
- **Stage 2** (return visit): first_name, company, job_title
- **Stage 3** (later visit): budget, timeline

## Privacy and consent

`p.js` supports privacy data-attributes that control data collection. Mention these if the user is in a regulated industry (health, EU, CCPA):

```html
<script src="..." data-privacy-dont-send="true" ...></script>  <!-- disables cookies and event sending -->
<script src="..." data-privacy-user-ids="true" ...></script>   <!-- disables storing user identifiers -->
<script src="..." data-privacy-ip-policy="stripLastOctet" ...></script>  <!-- IP: keep, stripLastOctet, remove -->
<script src="..." data-init-only="true" ...></script>          <!-- initializes without sending page event -->
```

## Verification checklist

After install (either path), walk the user through verifying:

1. Open browser DevTools -> Network tab
2. Reload the page
3. Confirm a request to `{tracking_host}/p.js` fires
4. Open Console, check `window.g8` is defined
5. Run `window.g8.track('test_event')` and confirm a network request goes out

## Destructive actions to always confirm

- `g8_apply_install` - modifies the user's codebase
- Any uncommitted changes the user has when applying patches - warn them to commit first or at least show `git status`

## Common mistakes to avoid

- **Calling `g8_apply_install` without showing the patches.** The user cannot approve what they have not seen. Always surface the diff (or at least the file list + summary of each change) first.
- **Recommending `window.g8.track()` for React/Vue without the optional chaining.** Will throw `Cannot read property 'track' of undefined` before the script loads. Use `window.g8?.track()`.
- **Forgetting to call `g8_doctor` after install.** Silent misconfigurations are common (missing env var, script tag not rendered). Doctor catches them.
- **Skipping `g8_scan_repo` before `g8_install_spine`.** Spine uses scan results to decide what to patch. Running install without a fresh scan produces generic patches that miss framework-specific optimizations.
- **Using Path B when Path A is enough.** A WordPress user who just wants the tag pasted does not need a connected repo. Ask clarifying questions before `g8_connect_repo`.
