# Skill: Running a Campaign End-to-End

**When to use this skill:** the user wants to ideate, build, review, or launch a graph8 campaign. Covers the full arc from concept to live outreach.

## Core concept

A graph8 **campaign** is a strategic container: target persona, core concept, primary hook, channel plan, and a linked sequence of steps. Launching a campaign triggers real outreach to enrolled contacts - email sends, SMS messages, LinkedIn touches. Never launch without explicit user confirmation.

Campaigns are distinct from standalone sequences (see prospecting-and-lists skill). A sequence is just the step list; a campaign wraps a sequence with strategy, documents (briefs, copy, ad creatives), and analytics. When the user says "campaign," use the `g8_gtm_*` tool family. When they say "sequence," use the `g8_*` sequence tools directly.

In `all` mode these GTM tools are prefixed `g8_gtm_`. In `gtm` mode they are unprefixed. This skill uses the `g8_gtm_` prefix.

## The campaign workflow (prescriptive)

### Step 1 - understand what exists

Before creating anything, check what the org already has:

```
g8_gtm_list_campaigns(limit=50)                 # existing campaigns
g8_gtm_get_campaign_ideas(limit=50)             # saved brainstorm ideas
g8_gtm_get_personas(status="active")            # target personas
g8_gtm_get_icps(status="active")                # ICPs
```

If the user is iterating on an existing campaign, load it with `g8_gtm_get_campaign(campaign_id)` and skip to Step 4.

### Step 2 - load context before writing copy

Never write campaign copy without loading org context. The user has 44 documents of brand, positioning, and audience context that the model must use to stay on-brand.

```
g8_gtm_get_global_context(category="context")   # brand_brief, value_props, offer_brief, personas, ICPs, messaging_house, proof_catalog, pricing_matrix
g8_gtm_get_global_context(category="intelligence")  # website_scrape, company_enrichment, competitor_discovery, organic_keywords
g8_gtm_get_global_context(category="research")  # buyer_psychology, competitive_teardown, gtm_channel, review_sentiment
g8_gtm_search_kb(query="...")                   # targeted lookup if you need specifics
```

The single highest-value document is `campaign_intelligence_brief` (in the `context` category) - it is a pre-extracted summary of all 43 upstream docs. Load it first, then only pull individual docs if you need detail.

### Step 3 - draft the campaign

Ask the user to confirm these decisions before creating:

- **Category**: free-form string (e.g., Outbound, Nurture). Check existing campaigns with `g8_gtm_list_campaigns` to see what conventions the org already uses - stay consistent rather than inventing a new label.
- **Target persona**: which persona ID from `g8_gtm_get_personas`
- **Primary hook**: the one-sentence reason the prospect opens the email
- **Goal**: what a "success" looks like (e.g., "15 booked meetings in 30 days")

Then create the draft:

```
g8_gtm_create_campaign(
    name="Q2 VP Eng Outbound",
    category="Outbound",
    brief="...",
    core_concept="...",
    primary_hook="...",
    target_persona="persona_id_xyz",
    goal="...",
)
```

The response returns `campaign_id` - keep it; you need it for every subsequent tool call.

### Step 4 - build the supporting documents

Campaigns render better in the UI and perform better in execution when they have supporting documents. The common set is:

- **brief** - audience, problem, solution positioning
- **value_props** - 3-5 concrete value props
- **copy_angles** - 3-4 message angles (problem, curiosity, social proof, urgency)
- **subject_lines** - 5-10 candidates per angle
- **ad_copy** - headline/description pairs for paid (only if running paid)

Create or update with:

```
g8_gtm_list_campaign_documents(campaign_id)           # see what exists
g8_gtm_get_campaign_document(campaign_id, document_id) # read one
g8_gtm_create_campaign_document(                       # add one
    campaign_id,
    file_type="brief",
    display_name="Q2 VP Eng Brief",
    content="...",
    status="draft",
)
g8_gtm_update_campaign_document(campaign_id, document_id, content="...", status="approved")
```

### Step 5 - build the sequence of steps

A campaign needs a sequence. View or modify it with:

```
g8_gtm_get_campaign_sequence(campaign_id)             # current step list
g8_gtm_create_campaign_step(                          # add step
    campaign_id,
    name="Day 0 intro",
    channel="email",
    mode="template",
    day=0,
    angle_id="angle_1",
    cta_type="soft_ask",
    personalization_level="medium",
)
g8_gtm_update_campaign_step(campaign_id, step_id, ...)
g8_gtm_delete_campaign_step(campaign_id, step_id)      # destructive, confirm
```

Sequencing tips:
- Start with `day=0` email, follow with `day=3` LinkedIn touch, then `day=7` email reply bump.
- `personalization_level` of `high` lifts reply rates by generating per-contact content, but takes longer to prepare each send.
- `cta_type="soft_ask"` for early steps (curiosity), `hard_ask` only in the final 1-2 steps.
- Set `stop_on_reply=True` on every step unless you have a specific reason not to.

### Step 6 - final review before launch

Do not skip this. Before calling `g8_gtm_launch_campaign`:

1. `g8_gtm_get_campaign(campaign_id)` - read the full campaign back.
2. Summarize to the user: **name, persona, channel mix, step count, estimated contacts enrolled**.
3. Warn them: "Launching will send real emails/messages to the enrolled contact list starting today."
4. Ask for explicit yes before proceeding.

Only then:

```
g8_gtm_launch_campaign(campaign_id)
```

This is an irreversible destructive operation. If the user regrets it, they need to pause the underlying sequence via `g8_pause_sequence(sequence_id)`.

## When to use existing vs create new

| User says... | Do... |
|---|---|
| "Help me write a campaign for X" | Check `g8_gtm_get_campaign_ideas` first - user may have saved a brainstorm |
| "Improve this campaign" | Load with `g8_gtm_get_campaign`, review documents, suggest edits, never rewrite without showing the diff |
| "Launch the Q2 campaign" | Load, summarize, confirm, then launch |
| "What campaigns do I have?" | `g8_gtm_list_campaigns` - read-only, safe |

## Destructive actions to always confirm

- `g8_gtm_launch_campaign` - sends real outreach
- `g8_gtm_delete_campaign_step` - removes a step from an active campaign
- `g8_gtm_delete_campaign_document` - removes a document permanently
- `g8_gtm_update_campaign_sequence` (replaces step list) - can reorder or drop steps

For any of these, state what will happen in plain English and wait for an affirmative before calling.

## Common mistakes to avoid

- **Writing copy without loading global context.** The model will generate on-brand-looking but off-brand content. Always call `g8_gtm_get_global_context` with the `campaign_intelligence_brief` first.
- **Creating a campaign from scratch when an idea exists.** Check `g8_gtm_get_campaign_ideas` - the user may have already drafted this.
- **Launching without showing the sequence summary.** The user cannot evaluate what they are approving if you have not read back the campaign.
- **Confusing campaign ID with sequence ID.** `g8_gtm_launch_campaign` takes `campaign_id`. `g8_add_to_sequence` takes `sequence_id`. They are different.
- **Using unprefixed `g8_list_campaigns` in `all` mode.** That is the dev/repo-scoped campaign tool, not the GTM org-scoped one. Use `g8_gtm_list_campaigns`.
