"""Audience sync and CRM sync tools."""

from __future__ import annotations

from mcp.server import FastMCP
from mcp.types import ToolAnnotations

from g8_mcp_server.client import G8Client, safe_call_typed
from g8_mcp_server.models import (
    ActionResult,
    AudienceSyncsResult,
    CrmFieldsResult,
    CrmSyncsResult,
    ResourceDetail,
    SyncRunsResult,
)
from g8_mcp_server.ui_apps import ui_tool_meta

_READ_ONLY = ToolAnnotations(readOnlyHint=True, idempotentHint=True)
# Config creates/updates mutate sync settings but don't push data or cost
# credits - _WRITE for "confirm-before-calling but not dangerous".
_WRITE = ToolAnnotations(
    readOnlyHint=False, destructiveHint=False, idempotentHint=False, openWorldHint=True
)
_DESTRUCTIVE = ToolAnnotations(destructiveHint=True, openWorldHint=True)


def register(server: FastMCP, client: G8Client) -> None:
    """Register audience sync and CRM sync tools on the MCP server."""

    # ------------------------------------------------------------------
    # Audience Sync tools
    # ------------------------------------------------------------------

    @server.tool(
        annotations=_READ_ONLY,
        meta=ui_tool_meta("ui://audience-syncs/list"),
    )
    async def g8_list_audience_syncs() -> AudienceSyncsResult | str:
        """List all audience sync configurations for your org.

        Returns sync configs for ad platforms (Meta, LinkedIn, Google Ads, X)
        with status, cadence, and last sync time.
        """
        return await safe_call_typed(
            client.get("/audience-syncs"),
            AudienceSyncsResult.from_envelope,
            context="Audience sync list",
        )

    @server.tool(annotations=_WRITE)
    async def g8_create_audience_sync(
        audience_id: int,
        platform: str,
        mode: str = "mirror",
        refresh_cadence_hours: int = 24,
        platform_audience_name: str | None = None,
    ) -> ActionResult | str:
        """Create a new audience sync configuration.

        Syncs a graph8 audience list to an ad platform for custom audience targeting.
        Returns 409 if a sync already exists for this audience + platform combo.

        Args:
            audience_id: Audience list ID to sync
            platform: Ad platform (meta, linkedin, google, x)
            mode: Sync mode - "mirror" (add+remove) or "append_only" (add only)
            refresh_cadence_hours: Hours between auto-syncs (default 24)
            platform_audience_name: Custom name for the audience on the platform
        """
        body: dict = {
            "audience_id": audience_id,
            "platform": platform,
            "mode": mode,
            "refresh_cadence_hours": refresh_cadence_hours,
        }
        if platform_audience_name:
            body["platform_audience_name"] = platform_audience_name
        return await safe_call_typed(
            client.post("/audience-syncs", body),
            ActionResult.from_envelope,
            context="Audience sync creation",
        )

    @server.tool(annotations=_READ_ONLY)
    async def g8_get_audience_sync(config_id: int) -> ResourceDetail | str:
        """Get details for a specific audience sync configuration.

        Args:
            config_id: Sync config ID
        """
        return await safe_call_typed(
            client.get(f"/audience-syncs/{config_id}"),
            ResourceDetail.from_envelope,
            context="Audience sync detail",
        )

    @server.tool(annotations=_WRITE)
    async def g8_update_audience_sync(
        config_id: int,
        mode: str | None = None,
        refresh_cadence_hours: int | None = None,
        is_active: bool | None = None,
    ) -> ActionResult | str:
        """Update an audience sync configuration.

        Args:
            config_id: Sync config ID
            mode: Sync mode - "mirror" or "append_only"
            refresh_cadence_hours: Hours between auto-syncs
            is_active: Enable/disable the sync
        """
        body = {
            k: v
            for k, v in {
                "mode": mode,
                "refresh_cadence_hours": refresh_cadence_hours,
                "is_active": is_active,
            }.items()
            if v is not None
        }
        return await safe_call_typed(
            client.patch(f"/audience-syncs/{config_id}", body),
            ActionResult.from_envelope,
            context="Audience sync update",
        )

    @server.tool(annotations=_DESTRUCTIVE)
    async def g8_delete_audience_sync(config_id: int) -> ActionResult | str:
        """Delete an audience sync configuration (soft delete).

        IMPORTANT: This deactivates the sync. The audience data on the ad platform
        is NOT deleted - manage that directly in the platform.

        Args:
            config_id: Sync config ID
        """
        return await safe_call_typed(
            client.delete(f"/audience-syncs/{config_id}"),
            ActionResult.from_envelope,
            context="Audience sync deletion",
        )

    @server.tool(annotations=_DESTRUCTIVE)
    async def g8_trigger_audience_sync(config_id: int) -> ActionResult | str:
        """Manually trigger an audience sync to push latest members to the ad platform.

        IMPORTANT: This pushes real data to the ad platform immediately.
        Confirm with the user before triggering.

        Args:
            config_id: Sync config ID
        """
        return await safe_call_typed(
            client.post(f"/audience-syncs/{config_id}/trigger", {}),
            ActionResult.from_envelope,
            context="Audience sync trigger",
        )

    @server.tool(
        annotations=_READ_ONLY,
        # Drill-in target from ui://audience-syncs/list - reuses the runs
        # table layout via the sibling "runs" view.
        meta=ui_tool_meta("ui://audience-syncs/list"),
    )
    async def g8_get_audience_sync_runs(
        config_id: int,
        limit: int = 20,
    ) -> SyncRunsResult | str:
        """Get sync run history for an audience sync configuration.

        Returns recent sync runs with status, member counts, and timing.

        Args:
            config_id: Sync config ID
            limit: Max runs to return (default 20, max 100)
        """
        return await safe_call_typed(
            client.get(f"/audience-syncs/{config_id}/runs", {"limit": limit}),
            SyncRunsResult.from_envelope,
            context="Audience sync runs",
        )

    @server.tool(annotations=_READ_ONLY)
    async def g8_get_audience_sync_errors(
        config_id: int,
        limit: int = 20,
    ) -> SyncRunsResult | str:
        """Get error logs for an audience sync configuration.

        Returns recent failed sync runs with error messages and details.

        Args:
            config_id: Sync config ID
            limit: Max errors to return (default 20, max 100)
        """
        return await safe_call_typed(
            client.get(f"/audience-syncs/{config_id}/errors", {"limit": limit}),
            SyncRunsResult.from_envelope,
            context="Audience sync errors",
        )

    # ------------------------------------------------------------------
    # CRM Sync tools
    # ------------------------------------------------------------------

    @server.tool(
        annotations=_READ_ONLY,
        meta=ui_tool_meta("ui://crm-syncs/list"),
    )
    async def g8_list_crm_syncs() -> CrmSyncsResult | str:
        """List configured CRM integrations for your org.

        Returns connected CRM providers (HubSpot, Salesforce, Pipedrive, Zoho, SugarCRM)
        with connection status.
        """
        return await safe_call_typed(
            client.get("/crm-syncs"),
            CrmSyncsResult.from_envelope,
            context="CRM sync list",
        )

    @server.tool(annotations=_DESTRUCTIVE)
    async def g8_push_to_crm_contact(
        provider: str,
        records: list[dict],
    ) -> ActionResult | str:
        """Push contacts to an external CRM provider.

        IMPORTANT: This creates real records in the external CRM.
        Confirm with the user before pushing.

        Args:
            provider: CRM provider (hubspot, salesforce, pipedrive, zoho, sugarcrm)
            records: List of contact records to push (each a dict with contact fields)
        """
        return await safe_call_typed(
            client.post(f"/crm-syncs/{provider}/contacts/push", {"records": records}),
            ActionResult.from_envelope,
            context="CRM contact push",
        )

    @server.tool(annotations=_DESTRUCTIVE)
    async def g8_push_to_crm_company(
        provider: str,
        records: list[dict],
    ) -> ActionResult | str:
        """Push companies to an external CRM provider.

        IMPORTANT: This creates real records in the external CRM.
        Confirm with the user before pushing.

        Args:
            provider: CRM provider (hubspot, salesforce, pipedrive, zoho, sugarcrm)
            records: List of company records to push (each a dict with company fields)
        """
        return await safe_call_typed(
            client.post(f"/crm-syncs/{provider}/companies/push", {"records": records}),
            ActionResult.from_envelope,
            context="CRM company push",
        )

    @server.tool(annotations=_DESTRUCTIVE)
    async def g8_push_to_crm_list(
        provider: str,
        records: list[dict],
    ) -> ActionResult | str:
        """Modify CRM list memberships (add/remove contacts from lists).

        Each record should contain: list_id, add_contact_ids, remove_contact_ids.

        Args:
            provider: CRM provider (hubspot, salesforce, pipedrive, zoho, sugarcrm)
            records: List of membership operations
        """
        return await safe_call_typed(
            client.post(f"/crm-syncs/{provider}/lists/push", {"records": records}),
            ActionResult.from_envelope,
            context="CRM list push",
        )

    @server.tool(annotations=_READ_ONLY)
    async def g8_get_crm_fields(
        provider: str,
        entity_type: str = "contacts",
    ) -> CrmFieldsResult | str:
        """Discover available fields for an entity type on a CRM provider.

        Useful for building field mappings before pushing data.

        Args:
            provider: CRM provider (hubspot, salesforce, pipedrive, zoho, sugarcrm)
            entity_type: Entity type (contacts, companies, leads, deals)
        """
        return await safe_call_typed(
            client.get(f"/crm-syncs/{provider}/fields", {"entity_type": entity_type}),
            CrmFieldsResult.from_envelope,
            context="CRM fields",
        )

    @server.tool(annotations=_READ_ONLY)
    async def g8_get_crm_status(provider: str) -> ResourceDetail | str:
        """Check connection health for a CRM provider.

        Args:
            provider: CRM provider (hubspot, salesforce, pipedrive, zoho, sugarcrm)
        """
        return await safe_call_typed(
            client.get(f"/crm-syncs/{provider}/status"),
            ResourceDetail.from_envelope,
            context="CRM status",
        )
