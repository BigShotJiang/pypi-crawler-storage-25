"""Intent data tools - competitor compete tracking + page / visitor search.

The full g8_intent_* suite. Wraps the `/api/v1/intent/*` endpoints so an
agent can do everything it needs for compete tracking without chaining
internal calls:

Pages layer (the underlying intent-enriched page index):
  g8_intent_domain_search     - pages on a competitor domain + subdomains
  g8_intent_search_pages      - text / semantic / hybrid search
  g8_intent_page_visitors     - resolved people for one page URL
  g8_intent_pages_contacts    - resolved contacts across a URL list
  g8_intent_pages_visitor_counts - batched visitor counts per URL
  g8_intent_stats             - index coverage health

Keywords layer (per-org compete-tracking rows):
  g8_intent_list_keywords           - inventory
  g8_intent_create_from_domain      - one-shot: domain -> URLs -> contacts -> saved row
  g8_intent_delete_keyword          - soft delete
  g8_intent_keyword_urls            - URLs linked to a keyword
  g8_intent_keyword_contacts        - resolved people for a keyword
  g8_intent_keyword_companies       - resolved companies for a keyword
  g8_intent_update_keyword_filters  - replace a keyword's search_filters JSON
"""

from __future__ import annotations

from typing import Any

from mcp.server import FastMCP
from mcp.types import ToolAnnotations

from g8_mcp_server.client import G8Client

_READ_ONLY = ToolAnnotations(readOnlyHint=True, idempotentHint=True)
_WRITE = ToolAnnotations(
    readOnlyHint=False, destructiveHint=False, idempotentHint=False, openWorldHint=True,
)
_DESTRUCTIVE = ToolAnnotations(destructiveHint=True, openWorldHint=True)


def _unwrap(resp: Any) -> Any:
    """Unwrap {data: ...} ApiResponse envelope to the inner payload."""
    if isinstance(resp, dict) and "data" in resp:
        return resp["data"]
    return resp


def register(server: FastMCP, client: G8Client) -> None:
    """Register all g8_intent_* tools on the MCP server."""

    # ------------------------------------------------------------------
    # Pages layer
    # ------------------------------------------------------------------

    @server.tool(annotations=_READ_ONLY)
    async def g8_intent_domain_search(
        domain: str,
        limit: int = 200,
    ) -> dict[str, Any] | str:
        """Find every indexed page on a competitor's domain (and subdomains).

        Queries graph8's intent-enriched crawl directly via ClickHouse. Returns
        the apex domain and every subdomain (www, blog, help, go, etc.) - no
        news articles that merely mention the competitor.

        Args:
            domain: Competitor root domain, e.g. "cognism.com". Bare domain,
                no scheme, no path.
            limit: Max pages (default 200, max 500).
        """
        body = {"domain": domain, "limit": max(1, min(limit, 500))}
        try:
            return _unwrap(await client.post("/intent/pages-by-domain", body))
        except Exception as e:
            return f"Intent domain search failed: {e}"

    @server.tool(annotations=_READ_ONLY)
    async def g8_intent_search_pages(
        query: str,
        limit: int = 50,
        semantic_ratio: float = 0.0,
        filters: dict[str, Any] | None = None,
        sort: list[str] | None = None,
        include_visitors: bool = True,
    ) -> dict[str, Any] | str:
        """Text / semantic / hybrid search across graph8's intent-enriched pages.

        Supports the same operator syntax as the UI search box:
        - Bare domain (cognism.com) -> domain-mode
        - site:cognism.com, intitle:pricing, inurl:blog
        - type:blog, audience:b2b, -excluded_word

        Args:
            query: Search string (free-form text + operators).
            limit: Max results (default 50, max 500).
            semantic_ratio: 0.0 text-only, 1.0 semantic-only, between = hybrid.
            filters: Optional filter dict passed through to the search handler
                (audience, page_type, commercial_intent_level, etc.).
            sort: Optional sort fields like ["commercial_score:desc"].
            include_visitors: When true, enriches each hit with a visitor count.
        """
        body: dict[str, Any] = {
            "query": query,
            "limit": max(1, min(limit, 500)),
            "semantic_ratio": max(0.0, min(semantic_ratio, 1.0)),
            "include_visitors": include_visitors,
        }
        if filters:
            body["filters"] = filters
        if sort:
            body["sort"] = sort
        try:
            return _unwrap(await client.post("/intent/pages/search", body))
        except Exception as e:
            return f"Intent page search failed: {e}"

    @server.tool(annotations=_READ_ONLY)
    async def g8_intent_page_visitors(
        url: str,
        limit: int = 50,
        mode: str = "quick",
    ) -> dict[str, Any] | str:
        """Resolve the people who visited a specific page URL.

        Args:
            url: Canonical PAGE_URL (no scheme, no www), e.g.
                "cognism.com/pricing".
            limit: Max visitors (default 50, max 500).
            mode: "quick" (~500ms, CID + UP_ID only) or
                "full" (~2-3s, all identity paths).
        """
        body = {"url": url, "limit": max(1, min(limit, 500)), "mode": mode}
        try:
            return _unwrap(await client.post("/intent/pages/visitors", body))
        except Exception as e:
            return f"Page visitors lookup failed: {e}"

    @server.tool(annotations=_READ_ONLY)
    async def g8_intent_pages_contacts(
        urls: list[str],
        limit: int = 100,
        mode: str = "quick",
    ) -> dict[str, Any] | str:
        """Aggregated, deduplicated resolved contacts across multiple page URLs.

        One batched HEM pull plus parallel identity fan-out. Primary consumer
        is compete-tracking setup: pre-populate a keyword's contacts array so
        it shows real counts immediately (not after the daily resolver).

        Args:
            urls: Up to 200 canonical PAGE_URLs.
            limit: Max contacts returned (default 100, max 500).
            mode: "quick" or "full".
        """
        body = {"urls": urls, "limit": max(1, min(limit, 500)), "mode": mode}
        try:
            return _unwrap(await client.post("/intent/pages/contacts", body))
        except Exception as e:
            return f"Pages contacts lookup failed: {e}"

    @server.tool(annotations=_READ_ONLY)
    async def g8_intent_pages_visitor_counts(
        urls: list[str],
    ) -> dict[str, Any] | str:
        """Batched unique-visitor count per page URL.

        Reads the pre-aggregated intent.url_visitor_counts MV (fast
        regardless of size). Useful for ranking a URL list by traffic before
        drilling into contacts.

        Args:
            urls: Up to 15,000 canonical PAGE_URLs.
        """
        try:
            return _unwrap(await client.post("/intent/pages/visitor-counts", {"urls": urls}))
        except Exception as e:
            return f"Visitor counts lookup failed: {e}"

    @server.tool(annotations=_READ_ONLY)
    async def g8_intent_stats() -> dict[str, Any] | str:
        """Intent index coverage stats (doc count + size).

        Call before starting a compete-tracking program to confirm the index
        has meaningful coverage for the orgs / domains of interest.
        """
        try:
            return _unwrap(await client.get("/intent/stats"))
        except Exception as e:
            return f"Intent stats failed: {e}"

    # ------------------------------------------------------------------
    # Keywords layer
    # ------------------------------------------------------------------

    @server.tool(annotations=_READ_ONLY)
    async def g8_intent_list_keywords(
        keyword_contains: str | None = None,
        page: int = 1,
        limit: int = 100,
    ) -> dict[str, Any] | str:
        """All compete-tracking keyword rows for this org.

        Each row carries `total_resolved_contacts` and
        `total_resolved_companies` so you can rank by delivered compete
        intelligence. Filter by substring if you want e.g. only rows that
        match "zoominfo".

        Args:
            keyword_contains: Optional case-insensitive substring filter.
            page: Page number (default 1).
            limit: Rows per page (default 100, max 500).
        """
        body: dict[str, Any] = {"page": page, "limit": max(1, min(limit, 500))}
        if keyword_contains:
            body["keyword_contains"] = keyword_contains
        try:
            return await client.post("/intent/keywords/list", body)
        except Exception as e:
            return f"Keyword list failed: {e}"

    @server.tool(annotations=_WRITE)
    async def g8_intent_create_from_domain(
        domain: str,
        page_limit: int = 200,
        contact_limit: int = 200,
    ) -> dict[str, Any] | str:
        """One-shot compete-tracking keyword create from a competitor domain.

        Server-side composite:
        1. Pull on-domain pages from the CH intent index
        2. Resolve contacts across those pages
        3. Save a keyword row with both URLs and pre-resolved contacts

        Strict off-domain guard: nothing outside `<domain>` or
        `*.<domain>` gets saved, even if the initial query returns noise.
        Returns the new keyword_id plus counts (pages_seeded,
        contacts_seeded, companies_seeded, off_domain_rejected).

        Args:
            domain: Competitor domain, e.g. "cognism.com" (bare, no scheme).
            page_limit: Max pages to seed (default 200, max 500).
            contact_limit: Max contacts to pre-resolve (default 200, max 500).
        """
        body = {
            "domain": domain,
            "page_limit": max(1, min(page_limit, 500)),
            "contact_limit": max(1, min(contact_limit, 500)),
        }
        try:
            return _unwrap(await client.post("/intent/keywords/create-from-domain", body))
        except Exception as e:
            return f"Keyword create failed: {e}"

    @server.tool(annotations=_DESTRUCTIVE)
    async def g8_intent_delete_keyword(keyword_id: str) -> dict[str, Any] | str:
        """Soft-delete a compete-tracking keyword row.

        Args:
            keyword_id: UUID of the keyword row (from g8_intent_list_keywords).
        """
        try:
            return await client.delete(f"/intent/keywords/{keyword_id}")
        except Exception as e:
            return f"Keyword delete failed: {e}"

    @server.tool(annotations=_READ_ONLY)
    async def g8_intent_keyword_urls(
        keyword_id: str,
        page: int = 1,
        limit: int = 100,
    ) -> dict[str, Any] | str:
        """URLs linked to a compete-tracking keyword.

        Returns the page list populated from either the initial
        save-from-search seed or the daily data4seo resolver.

        Args:
            keyword_id: UUID from g8_intent_list_keywords.
            page: Page (default 1).
            limit: Per page (default 100, max 500).
        """
        body = {"page": page, "limit": max(1, min(limit, 500)), "conditions": []}
        try:
            return await client.post(f"/intent/keywords/{keyword_id}/urls", body)
        except Exception as e:
            return f"Keyword URLs fetch failed: {e}"

    @server.tool(annotations=_READ_ONLY)
    async def g8_intent_keyword_contacts(
        keyword_id: str,
        page: int = 1,
        limit: int = 100,
    ) -> dict[str, Any] | str:
        """People resolved against a keyword's URL set.

        Each row includes full contact identity (name, job title, LinkedIn,
        work email) plus the company they're tied to.
        """
        body = {"page": page, "limit": max(1, min(limit, 500)), "conditions": []}
        try:
            return await client.post(f"/intent/keywords/{keyword_id}/contacts", body)
        except Exception as e:
            return f"Keyword contacts fetch failed: {e}"

    @server.tool(annotations=_READ_ONLY)
    async def g8_intent_keyword_companies(
        keyword_id: str,
        page: int = 1,
        limit: int = 100,
    ) -> dict[str, Any] | str:
        """Companies resolved against a keyword's URL set.

        Aggregates contacts by company_domain so you see which orgs are
        poking around the competitor, not just individuals.
        """
        body = {"page": page, "limit": max(1, min(limit, 500)), "conditions": []}
        try:
            return await client.post(f"/intent/keywords/{keyword_id}/companies", body)
        except Exception as e:
            return f"Keyword companies fetch failed: {e}"

    @server.tool(annotations=_WRITE)
    async def g8_intent_update_keyword_filters(
        keyword_id: str,
        search_filters: dict[str, Any],
    ) -> dict[str, Any] | str:
        """Replace a keyword's `search_filters` JSON.

        Full replacement (not merge). Typed fields (all optional):
          - audience: "b2b" | "b2c" | "both"
          - exclude_page_types: list of "news" | "finance" | "forum" | "vendor_marketing"
          - min_commercial_intent_level: int 0-100
          - max_urls_per_domain: int 1-20
          - llm_triage: bool
          - exclude_domains: list of domain strings

        Takes effect on the resolver's next cycle.

        Args:
            keyword_id: UUID of the keyword.
            search_filters: Full replacement filter dict.
        """
        try:
            return await client.post(
                f"/intent/keywords/{keyword_id}/filters",
                {"search_filters": search_filters},
            )
        except Exception as e:
            return f"Keyword filter update failed: {e}"

    # ------------------------------------------------------------------
    # URL-keyed company drill-down (intent_search module)
    # ------------------------------------------------------------------

    @server.tool(annotations=_READ_ONLY)
    async def g8_intent_search_url_companies(
        url: str,
        days: int = 90,
        limit: int = 200,
    ) -> dict[str, Any] | str:
        """Companies that visited a single page URL, aggregated by COMPANY_ID.

        Drill-down for a URL not yet saved as a keyword. Returns each
        company's audience bucket (b2b / b2c), visit_count, contacts_seen,
        last_seen, plus light enrichment (industry, employee_count range,
        logo_url) from MashupCompany. Reads {org_id}.intent_resolved.

        Use this when an agent already has a URL of interest (e.g. from
        g8_intent_search_pages) and wants company-level signal without
        committing to a saved keyword. For keyword-keyed company rollups
        across many URLs, use g8_intent_keyword_companies instead.

        Args:
            url: Canonical page_url, no scheme, no www
                (e.g. "cognism.com/pricing").
            days: Lookback window in days (default 90, range 1-365).
            limit: Max companies returned (default 200, max 500).
        """
        body = {
            "url": url,
            "days": max(1, min(days, 365)),
            "limit": max(1, min(limit, 500)),
        }
        try:
            return _unwrap(await client.post("/intent-search/url-companies", body))
        except Exception as e:
            return f"URL companies lookup failed: {e}"
