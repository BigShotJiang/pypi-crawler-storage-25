"""Inbox tools - multi-channel inbox (email, SMS, LinkedIn)."""

from __future__ import annotations

from mcp.server import FastMCP
from mcp.types import ToolAnnotations

from g8_mcp_server.client import G8Client, safe_call_typed
from g8_mcp_server.ui_apps import ui_tool_meta
from g8_mcp_server.models import (
    ActionResult,
    InboxDraft,
    InboxListResult,
    InboxThreadDetail,
)

_READ_ONLY = ToolAnnotations(readOnlyHint=True, idempotentHint=True)
# Mutates org data but not destructive (assign/tag). Clients should confirm
# but don't need the "dangerous" warning reserved for _DESTRUCTIVE.
_WRITE = ToolAnnotations(
    readOnlyHint=False, destructiveHint=False, idempotentHint=False, openWorldHint=True
)
_DESTRUCTIVE = ToolAnnotations(destructiveHint=True, openWorldHint=True)


def register(server: FastMCP, client: G8Client) -> None:
    """Register inbox tools on the MCP server."""

    @server.tool(
        annotations=_READ_ONLY,
        # Drives ui://inbox/list.
        meta=ui_tool_meta("ui://inbox/list"),
    )
    async def g8_list_inbox(
        channel: str | None = None,
        sequence_id: str | None = None,
        status: str | None = None,
        assignee: str | None = None,
        tag: str | None = None,
        page: int = 1,
        page_size: int = 50,
    ) -> InboxListResult | str:
        """List inbox threads across email, SMS, and LinkedIn channels.

        Returns conversations with messages, tags, assignees, and status.
        Use channel filter to narrow to a specific channel.

        Args:
            channel: Filter by channel (email, sms, linkedin). Omit for all channels.
            sequence_id: Filter by sequence/campaign ID
            status: Filter by status
            assignee: Filter by assignee email
            tag: Filter by tag ID
            page: Page number (default 1)
            page_size: Items per page (default 50, max 200)
        """
        params = {
            "channel": channel,
            "sequence_id": sequence_id,
            "status": status,
            "assignee": assignee,
            "tag": tag,
            "page": page,
            "page_size": page_size,
        }
        return await safe_call_typed(
            client.get("/inbox", params),
            InboxListResult.from_envelope,
            context="Inbox list",
        )

    @server.tool(
        annotations=_READ_ONLY,
        meta=ui_tool_meta("ui://inbox/thread"),
    )
    async def g8_get_reply(
        reply_id: str,
        channel: str = "email",
    ) -> InboxThreadDetail | str:
        """Get a single inbox thread with full message history.

        Args:
            reply_id: Thread/reply ID
            channel: Channel type - email, sms, or linkedin (default: email)
        """
        return await safe_call_typed(
            client.get(f"/inbox/{reply_id}", {"channel": channel}),
            InboxThreadDetail.from_envelope,
            context="Inbox thread",
        )

    @server.tool(annotations=_WRITE)
    async def g8_assign_reply(
        reply_id: str,
        assignee_email: str,
        channel: str = "email",
    ) -> ActionResult | str:
        """Assign a user to an inbox thread.

        Args:
            reply_id: Thread/reply ID
            assignee_email: Email of the user to assign
            channel: Channel type - email, sms, or linkedin (default: email)
        """
        return await safe_call_typed(
            client.post(f"/inbox/{reply_id}/assign?channel={channel}", {"assignee_email": assignee_email}),
            ActionResult.from_envelope,
            context="Inbox assign",
        )

    @server.tool(annotations=_WRITE)
    async def g8_tag_reply(
        reply_id: str,
        tag_ids: list[str],
        channel: str = "email",
    ) -> ActionResult | str:
        """Attach tags to an inbox thread.

        Args:
            reply_id: Thread/reply ID
            tag_ids: List of tag IDs to attach
            channel: Channel type - email, sms, or linkedin (default: email)
        """
        return await safe_call_typed(
            client.post(f"/inbox/{reply_id}/tag?channel={channel}", {"tag_ids": tag_ids}),
            ActionResult.from_envelope,
            context="Inbox tag",
        )

    @server.tool(annotations=_READ_ONLY)
    async def g8_get_reply_draft(
        reply_id: str,
        channel: str = "email",
    ) -> InboxDraft | str:
        """Generate an AI draft reply for an inbox thread. Charges credits.

        Returns 402 if the organization has insufficient credits.

        Args:
            reply_id: Thread/reply ID
            channel: Channel type - email, sms, or linkedin (default: email)
        """
        return await safe_call_typed(
            client.get(f"/inbox/{reply_id}/draft", {"channel": channel}),
            InboxDraft.from_envelope,
            context="Inbox draft",
        )

    @server.tool(annotations=_DESTRUCTIVE)
    async def g8_send_reply(
        reply_id: str,
        body: str,
        channel: str,
        subject: str | None = None,
        to: str | None = None,
        from_address: str | None = None,
    ) -> ActionResult | str:
        """Send a reply through the specified channel.

        IMPORTANT: This sends a real message. Confirm with user first.

        Args:
            reply_id: Thread/reply ID to reply to
            body: Message body to send
            channel: Channel to send through - email, sms, or linkedin
            subject: Email subject (optional, for email channel)
            to: Recipient (email address, phone number, or LinkedIn ID)
            from_address: Sender (mailbox email, phone number, or LinkedIn account ID)
        """
        payload: dict[str, str] = {"body": body, "channel": channel}
        if subject:
            payload["subject"] = subject
        if to:
            payload["to"] = to
        if from_address:
            payload["from_address"] = from_address
        return await safe_call_typed(
            client.post(f"/inbox/{reply_id}/send", payload),
            ActionResult.from_envelope,
            context="Inbox send",
        )
