"""Workflow builder MCP tools.

Wrappers around the public Developer API workflows endpoints exposed by
``developer_api/interfaces/v1/workflows_router.py``. These let an MCP
agent discover, build, edit, run, and control workflows in voice's
``/api/v1/actions/*`` (``runtime_type='workflow'``) surface - the same
graph that powers ``app.graph8.com/agents/workflows``.

Tool surface (25 total):
  Read / discover (5)
    - g8_workflow_list_node_types       slim catalog of all 37 node types
    - g8_workflow_describe_node_type    one node type with full Pydantic schema
    - g8_workflow_list                  list workflows for the org
    - g8_workflow_get                   full graph for a workflow
    - g8_workflow_get_trigger_status    trigger config + last cursor

  Build / edit (8)
    - g8_workflow_create                POST a new workflow (DESTRUCTIVE)
    - g8_workflow_update                PUT a partial graph update
    - g8_workflow_delete                DELETE (DESTRUCTIVE)
    - g8_workflow_validate              dry-run structural + reference check
    - g8_workflow_add_node              granular: fetch -> insert -> PUT
    - g8_workflow_update_node           granular: patch one node's data
    - g8_workflow_remove_node           granular: remove + drop dangling edges
    - g8_workflow_connect_nodes         granular: append edge

  Lifecycle (6)
    - g8_workflow_execute               trigger a run (DESTRUCTIVE)
    - g8_workflow_get_execution         poll execution status / result
    - g8_workflow_pause_execution       pause running execution (REVERSIBLE)
    - g8_workflow_resume_execution      resume paused execution (REVERSIBLE)
    - g8_workflow_stop_execution        permanently stop (DESTRUCTIVE)
    - g8_workflow_reset_trigger_cursor  cursor -> now (REVERSIBLE)

  Resolver helpers (6) - read-only, point a human description at concrete IDs
    - g8_workflow_list_roam_users       Roam users for send_roam_notification.user_ids
    - g8_workflow_list_roam_groups      Roam groups for send_roam_notification.recipient_id
    - g8_workflow_list_slack_users      Slack users for send_slack_notification.user_id
    - g8_workflow_list_slack_channels   Slack channels for send_slack_notification.channel_id
    - g8_workflow_list_mcp_servers      MCP servers + tool lists for tool node config
    - g8_workflow_list_dispositions     Static enum used by call/voicemail trigger filters

Progressive discovery: NONE of these tools belong in
``server._ALWAYS_ON_TOOLS``. Workflow building is a deep niche;
``g8_tool_search`` widens the visible surface only when the agent is
on-task. This keeps the steady-state context tax at zero.

Backwards compatibility: this module is purely additive. All public
shapes pass through the developer_api proxy as ``Dict[str, Any]`` so
schema additions on the voice side never break MCP clients.
"""

from __future__ import annotations

from typing import Any

from mcp.server import FastMCP
from mcp.types import ToolAnnotations

from g8_mcp_server.client import G8Client
from g8_mcp_server.models import ConfirmationDetail, ConfirmationPreview

_READ_ONLY = ToolAnnotations(readOnlyHint=True, idempotentHint=True)
# create / delete / execute / stop - flips real persisted state.
_DESTRUCTIVE = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=True,
    openWorldHint=True,
)
# pause / resume / trigger-reset / update / add-node / etc. - reversible
# state changes that don't destroy data.
_REVERSIBLE_WRITE = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=False,
    idempotentHint=True,
    openWorldHint=True,
)


def _unwrap(resp: Any) -> Any:
    """Strip the developer_api ``ApiResponse`` envelope when present.

    Most workflow routes pass-through voice's payload directly (no
    envelope), but a few helpers may wrap. Tolerate both so the agent
    sees the same shape it would get from the OpenAPI docs.
    """
    if isinstance(resp, dict) and "data" in resp and len(resp) <= 3:
        # 3 = data + optional pagination + optional meta (typical envelope).
        # Avoid stripping when "data" is one field among many in a real payload.
        keys = set(resp.keys())
        if keys.issubset({"data", "pagination", "meta", "success"}):
            return resp["data"]
    return resp


# ---------------------------------------------------------------------------
# Shape-tolerant node accessors
#
# Workflows persisted before the proxy normalization fix (PR #5763) may
# still be on disk in three overlapping shapes:
#
#   1) Canonical (snake_case, what the proxy now writes):
#        {"node_id": "...", "node_type": "...", "name": "...", "config": {...}}
#   2) Frontend (camelCase, before configToBackend ran):
#        {"nodeId": "...", "nodeType": "...", "name": "...", "config": {...}}
#   3) ReactFlow hybrid (older MCP create payloads):
#        {"id": "...", "type": "...", "data": {"label": "...", "config": {...}}}
#
# These helpers read either shape so the granular tools (add_node /
# update_node / remove_node / connect_nodes) keep working on legacy rows.
# Going forward the tools always WRITE canonical snake_case, so over time
# the variance disappears as users edit existing workflows.
# ---------------------------------------------------------------------------


def _node_id_of(node: Any) -> Any:
    """Return the node identifier regardless of which shape it's in."""
    if not isinstance(node, dict):
        return None
    return node.get("node_id") or node.get("nodeId") or node.get("id")


def _node_type_of(node: Any) -> Any:
    """Return the node type regardless of which shape it's in."""
    if not isinstance(node, dict):
        return None
    return node.get("node_type") or node.get("nodeType") or node.get("type")


def _node_label_of(node: Any) -> Any:
    """Return the human-readable node label regardless of which shape it's in."""
    if not isinstance(node, dict):
        return None
    if isinstance(node.get("name"), str):
        return node["name"]
    data = node.get("data")
    if isinstance(data, dict) and isinstance(data.get("label"), str):
        return data["label"]
    return None


def _node_config_of(node: Any) -> dict[str, Any]:
    """Return the per-node config dict regardless of which shape it's in.

    Returns a fresh dict so callers can mutate without aliasing the source.
    """
    if not isinstance(node, dict):
        return {}
    cfg = node.get("config")
    if isinstance(cfg, dict):
        return dict(cfg)
    data = node.get("data")
    if isinstance(data, dict) and isinstance(data.get("config"), dict):
        return dict(data["config"])
    return {}


def _build_canonical_node(
    node_id: str,
    node_type: str,
    *,
    label: str | None = None,
    config: dict[str, Any] | None = None,
    position: dict[str, float] | None = None,
    connections: list[str] | None = None,
    conditional_connections: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Build a node in the canonical snake_case shape voice + visual builder
    agree on. Always emits ``node_id`` / ``node_type`` / flat ``name`` /
    flat ``config`` / ``connections`` (the field voice's executor uses for
    graph traversal). The proxy normalizes hybrid shapes for back-compat,
    but writing canonical here keeps the on-disk row clean.

    CRITICAL: voice's ``WorkflowGraphExecutor`` traverses via
    ``node.connections[0]`` - NOT via the top-level ``edges`` list.
    A node persisted without ``connections`` will halt the executor at
    that step even if there is a matching edge. We therefore always emit
    a ``connections`` list (defaulting to ``[]``) and rely on the helpers
    below (add_node / connect_nodes / etc.) to keep it in sync with edges.
    """
    out: dict[str, Any] = {
        "node_id": node_id,
        "node_type": node_type,
        "name": label or node_type,
        "config": config or {},
        "position": position or {"x": 0, "y": 0},
        "connections": list(connections) if connections is not None else [],
    }
    if conditional_connections is not None:
        out["conditional_connections"] = dict(conditional_connections)
    return out


def _rewrite_node_canonical(node: dict[str, Any]) -> dict[str, Any]:
    """Coerce a node read from voice (any shape) to canonical snake_case
    in-place style - returns a fresh dict so callers can replace and PUT.

    Preserves ``connections`` and ``conditional_connections`` as-is when
    present so a rewrite never breaks the executor's traversal contract.
    """
    nid = _node_id_of(node)
    ntype = _node_type_of(node)
    out: dict[str, Any] = {
        "node_id": nid,
        "node_type": ntype,
        "name": _node_label_of(node) or (ntype or "node"),
        "config": _node_config_of(node),
    }
    if "position" in node and isinstance(node["position"], dict):
        out["position"] = node["position"]
    # connections is required by voice's executor - preserve if present,
    # default to [] otherwise so a malformed legacy node round-trips clean.
    raw_conns = node.get("connections")
    out["connections"] = list(raw_conns) if isinstance(raw_conns, list) else []
    # conditional_connections is only present on branch / condition / loop
    # nodes - preserve when present, omit otherwise (voice's schema marks
    # this Optional, so a missing key parses cleanly).
    cc = node.get("conditional_connections")
    if isinstance(cc, dict):
        out["conditional_connections"] = dict(cc)
    # Preserve any other top-level keys voice's schema knows about
    # (description, source_handle, etc.) without dropping them.
    for k, v in node.items():
        if k in {
            "node_id", "node_type", "nodeId", "nodeType", "id", "type",
            "name", "config", "data", "position",
            "connections", "conditional_connections",
        }:
            continue
        out[k] = v
    return out


def register(server: FastMCP, client: G8Client, *, name_prefix: str = "workflow") -> None:
    """Register the workflow builder MCP tools.

    Mirrors the convention used by ``tools/voice.py`` so tool names line
    up: ``g8_workflow_*``. Pass ``name_prefix=""`` to expose bare
    ``g8_*`` names if a future mode wants to drop the namespace (no
    callers do today).
    """

    def tool_name(base_name: str) -> str:
        if name_prefix:
            return f"g8_{name_prefix}_{base_name}"
        return f"g8_{base_name}"

    # ------------------------------------------------------------------
    # Read / discover
    # ------------------------------------------------------------------

    @server.tool(name=tool_name("list_node_types"), annotations=_READ_ONLY)
    async def list_node_types(detail: str = "slim") -> dict[str, Any] | str:
        """List every workflow node type with its config schema.

        Use this BEFORE building a workflow so the agent knows which
        ``type`` strings are valid and what each one's ``config`` dict
        must contain. Catalog covers all 37 node types: triggers (sequence,
        domain visit, signal, scheduler, manual), actions (LLM, API call,
        Python script, send email/slack/roam, branch, foreach, delay,
        etc.), and integrations.

        The catalog also includes:
          - ``trigger_output_schemas`` - for trigger nodes, what each
            run's input_data dict will contain. Critical for downstream
            template references like ``{{trigger.contact_email}}``.
          - ``resolver_tool_hints`` - names of MCP tools that can resolve
            an opaque id field (e.g. recipient_id for roam_send_message
            -> "g8_get_lists" or a future Roam helper).
          - ``example_workflows`` - a worked, runnable graph for one or
            more triggers per node type.

        Args:
            detail: ``"slim"`` (default) returns a compact ``[(field_name,
                type_str)]`` per node, suitable for the agent's first
                glance. ``"full"`` returns the underlying Pydantic JSON
                schema for every config field - use when the slim view
                does not give enough detail to fill a value correctly.
        """
        params: dict[str, Any] = {"detail": detail or "slim"}
        try:
            return _unwrap(await client.get("/workflows/node-types/schema", params))
        except Exception as e:
            return f"List workflow node types failed: {e}"

    @server.tool(name=tool_name("describe_node_type"), annotations=_READ_ONLY)
    async def describe_node_type(
        node_type: str,
        detail: str = "full",
    ) -> dict[str, Any] | str:
        """Get the config schema for a single node type.

        Cheaper than ``g8_workflow_list_node_types(detail="full")`` when
        the agent already knows which type it wants - returns just one
        entry instead of all 37. Same payload shape as the catalog.

        Args:
            node_type: One of the values returned by
                ``g8_workflow_list_node_types`` (e.g. ``"sequence_reply_trigger"``,
                ``"roam_send_message"``, ``"llm_completion"``).
            detail: ``"slim"`` or ``"full"`` (default ``"full"`` since
                the typical caller wants the schema to fill a config).
        """
        if not node_type:
            return "Error: node_type is required."
        params: dict[str, Any] = {"node_type": node_type, "detail": detail or "full"}
        try:
            return _unwrap(await client.get("/workflows/node-types/schema", params))
        except Exception as e:
            return f"Describe workflow node type failed: {e}"

    @server.tool(name=tool_name("list"), annotations=_READ_ONLY)
    async def list_workflows(
        enabled: bool | None = None,
        category: str | None = None,
        is_template: bool | None = None,
    ) -> dict[str, Any] | str:
        """List workflows owned by the caller's organization.

        Returns ``runtime_type='workflow'`` actions only - non-workflow
        actions (LLM/API/script skills) are intentionally not exposed
        through this tool surface.

        Args:
            enabled: ``True`` returns enabled workflows only; ``False``
                returns disabled. Omit to return both.
            category: Optional category filter (e.g. ``"sales"``,
                ``"automation"``). Categories are free-form strings the
                user assigned at create time.
            is_template: ``True`` returns templates (workflows other
                orgs can fork). Omit for non-templates.
        """
        params: dict[str, Any] = {}
        if enabled is not None:
            params["enabled"] = enabled
        if category:
            params["category"] = category
        if is_template is not None:
            params["is_template"] = is_template
        try:
            return _unwrap(await client.get("/workflows", params or None))
        except Exception as e:
            return f"List workflows failed: {e}"

    @server.tool(name=tool_name("get"), annotations=_READ_ONLY)
    async def get_workflow(action_id: str) -> dict[str, Any] | str:
        """Get the full graph for a workflow (nodes + edges + trigger).

        The shape: ``{action_id, name, description, runtime_type, enabled,
        config: {metadata, settings, nodes: [...], edges: [...], start_node_id}}``.
        Use this before any granular edit so the agent has the current
        node/edge ids to mutate.

        Returned config follows the canonical snake_case shape: each node
        has flat ``node_id`` / ``node_type`` / ``name`` / ``config`` /
        ``position``. Older rows persisted before normalization may still
        carry the ReactFlow ``id`` / ``type`` / ``data:{label,config}``
        envelope; the granular helpers (``add_node`` / ``update_node`` /
        ``remove_node`` / ``connect_nodes``) read both shapes so they work
        on either.

        Args:
            action_id: Workflow id from ``g8_workflow_list`` or the URL
                ``app.graph8.com/agents/workflows/{action_id}``.
        """
        if not action_id:
            return "Error: action_id is required."
        try:
            return _unwrap(await client.get(f"/workflows/{action_id}"))
        except Exception as e:
            return f"Get workflow failed: {e}"

    @server.tool(name=tool_name("get_trigger_status"), annotations=_READ_ONLY)
    async def get_trigger_status(action_id: str) -> dict[str, Any] | str:
        """Get the trigger status (cursor + config) for a workflow.

        Useful when debugging "why isn't my workflow firing?" - surfaces
        whether a trigger is configured, its type, and the last cursor
        timestamp the engine processed up to.

        Args:
            action_id: Workflow id.
        """
        if not action_id:
            return "Error: action_id is required."
        try:
            return _unwrap(await client.get(f"/workflows/{action_id}/trigger-status"))
        except Exception as e:
            return f"Get trigger status failed: {e}"

    # ------------------------------------------------------------------
    # Build / edit - top-level
    # ------------------------------------------------------------------

    @server.tool(name=tool_name("create"), annotations=_DESTRUCTIVE)
    async def create_workflow(
        name: str,
        config: dict[str, Any],
        description: str | None = None,
        category: str | None = None,
        enabled: bool = False,
        dry_run: bool = False,
    ) -> dict[str, Any] | str:
        """Create a new workflow.

        IMPORTANT: This persists a real workflow row in the org. ALWAYS
        confirm with the user before calling. Recommended pattern: run
        ``g8_workflow_validate`` first to catch structural errors, then
        call this with ``dry_run=True`` to render a confirmation
        widget, then again with ``dry_run=False`` after the user
        confirms.

        The ``config`` dict must follow the canonical snake_case shape
        the visual builder and voice's executor agree on. Each node MUST
        carry a ``connections`` list (the executor traverses via
        ``node.connections[0]`` - top-level ``edges`` is for renderers).
        Branch / condition nodes additionally use ``conditional_connections``
        ({path_id: target_node_id}) to gate which downstream branch fires.

        Worked example modeled on a real production workflow
        ("Receive Data from cience" - webhook → enrich → round-robin owner
        → branch by owner → send email). Truncated to 4 nodes for clarity:

            {
              "metadata": {"name": "Cience inbound", "version": 1, "category": "Automation"},
              "settings": {},
              "start_node_id": "webhook-dc67ee9b",
              "nodes": [
                {
                  "node_id": "webhook-dc67ee9b",
                  "node_type": "webhook",
                  "name": "Webhook",
                  "config": {
                    "webhook_path": "cience-visitor",
                    "webhook_secret": "...",
                    "input_schema": [
                      {"name": "email", "type": "string", "required": true},
                      {"name": "name", "type": "string", "required": true}
                    ]
                  },
                  "position": {"x": 0, "y": 0},
                  "connections": ["create_contact-6ebac32b"]
                },
                {
                  "node_id": "create_contact-6ebac32b",
                  "node_type": "create_contact",
                  "name": "Create Contact",
                  "config": {
                    "email": "${webhook-dc67ee9b.email}",
                    "last_name": "${webhook-dc67ee9b.name}",
                    "input_mappings": []
                  },
                  "position": {"x": 300, "y": 0},
                  "connections": ["round_robin-ac411e98"]
                },
                {
                  "node_id": "round_robin-ac411e98",
                  "node_type": "round_robin",
                  "name": "Round Robin",
                  "config": {"users": [{"name": "Din", "email": "din@x.com", "user_id": "..."}]},
                  "position": {"x": 1824, "y": 128},
                  "connections": ["condition-1196a24b"]
                },
                {
                  "node_id": "condition-1196a24b",
                  "node_type": "condition",
                  "name": "Owner branch",
                  "config": {
                    "paths": [
                      {
                        "id": "path-din",
                        "label": "Din",
                        "conditions": [{
                          "operator": "contains",
                          "left_operand": "${round_robin-ac411e98.user_email}",
                          "right_operand": "din@x.com"
                        }]
                      }
                    ]
                  },
                  "position": {"x": 2096, "y": 32},
                  "connections": [],
                  "conditional_connections": {"path-din": "send_email-2e3bb0d7"}
                }
              ],
              "edges": [
                {"id": "edge-webhook-create", "source": "webhook-dc67ee9b", "target": "create_contact-6ebac32b"},
                {"id": "edge-create-rr", "source": "create_contact-6ebac32b", "target": "round_robin-ac411e98"},
                {"id": "edge-rr-cond", "source": "round_robin-ac411e98", "target": "condition-1196a24b"}
              ]
            }

        Notable conventions extracted from production workflows:
          - ``node_id`` pattern: ``{node_type}-{8-hex}`` (e.g. ``send_email-2e3bb0d7``)
          - ``edge.id`` pattern: ``edge-{source}-{target}`` or with a 4-hex suffix
          - Cross-node variable substitution: ``${node_id.output_field}``
          - ``input_mappings`` on most nodes carries explicit cross-node data
            flow ``[{target_field, source_expression}]``
          - ``webhook`` triggers carry ``input_schema`` (a list of
            ``{name, type, required, description}``) - these become the
            top-level keys agents reference via ``${webhook-id.field}``

        Back-compat: the developer_api proxy normalizes the older ReactFlow
        hybrid shape (``id`` / ``type`` / ``data:{label,config}`` /
        ``startNodeId``) and the camelCase frontend shape (``nodeId`` /
        ``nodeType`` / ``startNodeId``) to canonical before persistence,
        so existing callers using either of those shapes still work - but
        new code should emit canonical, INCLUDING ``connections`` per node,
        otherwise voice's executor halts at the first node despite having
        a valid edge list.

        ``runtime_type='workflow'`` and ``org_id`` are pinned server-
        side; the body cannot override them.

        Args:
            name: Workflow display name.
            config: The graph dict (nodes / edges / startNodeId / trigger).
            description: Optional human-readable summary.
            category: Optional grouping (e.g. ``"sales"``).
            enabled: Default ``False`` so a fresh workflow is paused
                until the user explicitly enables it. Set ``True`` if
                the user has already approved auto-firing.
            dry_run: When ``True``, return a confirmation preview
                without creating the workflow.
        """
        if not name:
            return "Error: name is required."
        if not isinstance(config, dict):
            return "Error: config must be a dict with nodes / edges / startNodeId."

        if dry_run:
            node_count = len(config.get("nodes") or [])
            edge_count = len(config.get("edges") or [])
            trigger = config.get("trigger") or {}
            details = [
                ConfirmationDetail(label="Name", value=name),
                ConfirmationDetail(label="Nodes", value=str(node_count)),
                ConfirmationDetail(label="Edges", value=str(edge_count)),
                ConfirmationDetail(label="Enabled", value=str(enabled).lower()),
            ]
            if isinstance(trigger, dict) and trigger.get("type"):
                details.append(ConfirmationDetail(label="Trigger", value=str(trigger["type"])))
            if category:
                details.append(ConfirmationDetail(label="Category", value=category))
            confirm_args: dict[str, Any] = {
                "name": name,
                "config": config,
                "description": description,
                "category": category,
                "enabled": enabled,
                "dry_run": False,
            }
            confirm_args = {k: v for k, v in confirm_args.items() if v is not None}
            return ConfirmationPreview(
                action_label="Create workflow",
                summary=f'Create workflow "{name}" with {node_count} nodes and {edge_count} edges.',
                details=details,
                warning=(
                    "Run g8_workflow_validate first if you have not already - "
                    "structural errors are easier to fix before persisting."
                ),
                cost_label=None,
                confirm_tool=tool_name("create"),
                confirm_args=confirm_args,
                confirm_label="Create workflow",
                cancel_label="Cancel",
            ).model_dump()

        body: dict[str, Any] = {
            "name": name,
            "config": config,
            "enabled": enabled,
        }
        if description is not None:
            body["description"] = description
        if category is not None:
            body["category"] = category
        try:
            return _unwrap(await client.post("/workflows", body=body))
        except Exception as e:
            return f"Create workflow failed: {e}"

    @server.tool(name=tool_name("update"), annotations=_REVERSIBLE_WRITE)
    async def update_workflow(
        action_id: str,
        name: str | None = None,
        description: str | None = None,
        category: str | None = None,
        enabled: bool | None = None,
        config: dict[str, Any] | None = None,
    ) -> dict[str, Any] | str:
        """Update a workflow's metadata or graph.

        Pass only the fields you want to change - this is a partial
        update (PUT semantics behind voice's ActionUpdateRequest). To
        edit nodes/edges granularly, prefer the ``g8_workflow_add_node``
        / ``update_node`` / ``remove_node`` / ``connect_nodes`` helpers
        which fetch + mutate + put for you.

        Args:
            action_id: Workflow id.
            name: New display name (omit to keep current).
            description: New description.
            category: New category.
            enabled: ``True`` to enable, ``False`` to pause.
            config: New full graph dict. Replaces the existing graph
                wholesale - for granular edits use the helpers below.
        """
        if not action_id:
            return "Error: action_id is required."
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        if category is not None:
            body["category"] = category
        if enabled is not None:
            body["enabled"] = enabled
        if config is not None:
            body["config"] = config
        if not body:
            return "Error: pass at least one field to update."
        try:
            return _unwrap(await client.put(f"/workflows/{action_id}", body=body))
        except Exception as e:
            return f"Update workflow failed: {e}"

    @server.tool(name=tool_name("delete"), annotations=_DESTRUCTIVE)
    async def delete_workflow(
        action_id: str,
        dry_run: bool = False,
    ) -> dict[str, Any] | str:
        """Delete a workflow permanently.

        IMPORTANT: This is one-way - ``g8_workflow_get`` will 404 after.
        ALWAYS confirm with the user. Recommended pattern: dry_run first
        to render the confirmation widget.

        Args:
            action_id: Workflow id.
            dry_run: When ``True``, return a confirmation preview
                without deleting.
        """
        if not action_id:
            return "Error: action_id is required."
        if dry_run:
            return ConfirmationPreview(
                action_label="Delete workflow",
                summary=f"Permanently delete workflow {action_id}.",
                details=[ConfirmationDetail(label="Workflow ID", value=action_id)],
                warning="This cannot be undone. All execution history for the workflow remains queryable but the workflow itself will be gone.",
                cost_label=None,
                confirm_tool=tool_name("delete"),
                confirm_args={"action_id": action_id, "dry_run": False},
                confirm_label="Delete workflow",
                cancel_label="Cancel",
            ).model_dump()
        try:
            return _unwrap(await client.delete(f"/workflows/{action_id}"))
        except Exception as e:
            return f"Delete workflow failed: {e}"

    @server.tool(name=tool_name("validate"), annotations=_READ_ONLY)
    async def validate_workflow(config: dict[str, Any]) -> dict[str, Any] | str:
        """Validate a workflow graph WITHOUT saving it.

        Returns ``{errors: [...], warnings: [...], missing_references:
        [...]}``. Call this before ``g8_workflow_create`` or after a
        granular edit to confirm the graph is structurally sound and
        every templated reference (``{{node1.output}}``) resolves.

        Args:
            config: The graph dict ``{metadata?, settings?, nodes, edges,
                start_node_id, trigger?}`` - same canonical shape
                ``g8_workflow_get`` returns under ``response.config``.
                Hybrid / camelCase shapes are normalized server-side
                before validation, so older payloads still work.
        """
        if not isinstance(config, dict):
            return "Error: config must be a dict with nodes / edges / startNodeId."
        body = {"config": config}
        try:
            return _unwrap(await client.post("/workflows/validate", body=body))
        except Exception as e:
            return f"Validate workflow failed: {e}"

    # ------------------------------------------------------------------
    # Build / edit - granular helpers (fetch -> mutate -> PUT)
    #
    # These avoid making the agent re-send the entire graph for one
    # node tweak. They also normalise the "where does this node go"
    # decisions: append by default, allow optional position hint.
    # ------------------------------------------------------------------

    async def _fetch_config(action_id: str) -> tuple[dict[str, Any] | None, str | None]:
        """Internal helper: fetch current graph dict. Returns (config, error_str)."""
        try:
            wf = await client.get(f"/workflows/{action_id}")
        except Exception as e:
            return None, f"Could not fetch workflow {action_id}: {e}"
        wf = _unwrap(wf)
        if not isinstance(wf, dict):
            return None, f"Unexpected response shape for workflow {action_id}."
        config = wf.get("config")
        if not isinstance(config, dict):
            return None, f"Workflow {action_id} has no config / graph yet."
        # Defensive defaults so callers can mutate freely.
        config.setdefault("nodes", [])
        config.setdefault("edges", [])
        return config, None

    @server.tool(name=tool_name("add_node"), annotations=_REVERSIBLE_WRITE)
    async def add_node(
        action_id: str,
        node_id: str,
        node_type: str,
        config: dict[str, Any] | None = None,
        label: str | None = None,
        position: dict[str, float] | None = None,
        connect_from: str | None = None,
    ) -> dict[str, Any] | str:
        """Add one node to an existing workflow's graph.

        Fetches the current graph, appends the node (and optionally one
        edge), and PUTs the result. If ``node_id`` already exists this
        returns an error rather than silently overwriting - use
        ``g8_workflow_update_node`` for that.

        The new node is written in the canonical snake_case shape
        (``node_id`` / ``node_type`` / flat ``name`` / flat ``config`` /
        ``connections: []``). Existing nodes in the graph that are still
        on the legacy ReactFlow shape (``id`` / ``type`` /
        ``data:{label,config}``) are recognized for the duplicate-id check
        but otherwise left untouched on this PUT - the proxy normalizes
        them before persistence so they migrate over time as the graph is
        edited.

        When ``connect_from`` is set this helper does TWO things, not
        one: it appends the edge to ``edges`` AND appends ``node_id`` to
        the source node's ``connections`` list. The duplicate write is
        intentional - voice's executor traverses via ``node.connections``,
        not via ``edges``, so a node added with only an edge would never
        be reached at runtime. Convention: prefer ``add_node(...,
        connect_from=upstream)`` over ``add_node(...)`` then
        ``connect_nodes(upstream, ...)`` - same end state, one fewer PUT.

        Args:
            action_id: Workflow id.
            node_id: New node's id (must be unique within the graph).
                Convention from production: ``{node_type}-{8-hex}``
                (e.g. ``send_email-2e3bb0d7``). Short snake_case ids work
                too but mixing both styles in the same workflow is ugly.
            node_type: One of the values from ``g8_workflow_list_node_types``.
            config: Per-node config dict - shape varies by node_type.
                Use ``g8_workflow_describe_node_type`` to see the
                required fields.
            label: Optional display label. Defaults to ``node_type``.
            position: Optional ``{"x": float, "y": float}``. Defaults
                to ``{"x": 0, "y": 0}``.
            connect_from: Optional id of a node to connect FROM. Adds an
                edge ``connect_from -> node_id`` AND appends ``node_id``
                to the source node's ``connections`` list. Skip if you'll
                wire the node up separately via
                ``g8_workflow_connect_nodes`` - that helper performs the
                same dual write.
        """
        if not action_id or not node_id or not node_type:
            return "Error: action_id, node_id, and node_type are required."
        cfg, err = await _fetch_config(action_id)
        if err is not None or cfg is None:
            return err or "Internal error: missing config."
        nodes = cfg["nodes"]
        if any(_node_id_of(n) == node_id for n in nodes):
            return f"Error: node id '{node_id}' already exists. Use g8_workflow_update_node instead."
        nodes.append(
            _build_canonical_node(
                node_id,
                node_type,
                label=label,
                config=config,
                position=position,
            )
        )
        if connect_from:
            # Validate the upstream node exists so we don't silently create
            # an edge to a phantom source.
            src_idx = next(
                (i for i, n in enumerate(nodes) if _node_id_of(n) == connect_from),
                None,
            )
            if src_idx is None:
                return (
                    f"Error: connect_from node '{connect_from}' not found in "
                    f"workflow {action_id}. Add the upstream node first or pass "
                    "connect_from=None and wire later via g8_workflow_connect_nodes."
                )
            edges = cfg["edges"]
            edges.append(
                {
                    "id": f"edge-{connect_from}-{node_id}",
                    "source": connect_from,
                    "target": node_id,
                }
            )
            # CRITICAL: voice's executor traverses via node.connections[0],
            # not top-level edges. Mirror the edge into the source node's
            # connections list. Rewrite the source to canonical first so we
            # don't lose the connections field if it was on a legacy node.
            src_node = nodes[src_idx]
            if isinstance(src_node, dict):
                rewritten = _rewrite_node_canonical(src_node)
                conns = rewritten.setdefault("connections", [])
                if node_id not in conns:
                    conns.append(node_id)
                nodes[src_idx] = rewritten
        try:
            return _unwrap(await client.put(f"/workflows/{action_id}", body={"config": cfg}))
        except Exception as e:
            return f"Add node failed: {e}"

    @server.tool(name=tool_name("update_node"), annotations=_REVERSIBLE_WRITE)
    async def update_node(
        action_id: str,
        node_id: str,
        config: dict[str, Any] | None = None,
        label: str | None = None,
        position: dict[str, float] | None = None,
        connections: list[str] | None = None,
        conditional_connections: dict[str, str] | None = None,
    ) -> dict[str, Any] | str:
        """Update one node's config / label / position / connections in place.

        Pass only the fields you want to change. The node's ``type``
        is intentionally not updatable here - switching node types
        requires removing and re-adding so the new config schema can
        be validated cleanly.

        On legacy ReactFlow-shape nodes (``id`` / ``type`` /
        ``data:{label,config}``) this rewrites the node to the canonical
        snake_case shape so subsequent reads / saves stay clean.

        ``connections`` and ``conditional_connections`` are how voice's
        executor traverses the graph. Use ``connections`` for normal
        sequential nodes (``send_email``, ``add_to_list``, etc.) and
        ``conditional_connections`` (a dict ``{path_id: target_node_id}``
        or ``{"true": target, "false": target}``) for ``condition`` /
        ``loop`` / ``human_approval`` nodes that branch. Most callers
        will rely on ``add_node`` / ``connect_nodes`` to keep these
        fields in sync - this helper only needs to touch them when
        rewiring a condition node by hand.

        Args:
            action_id: Workflow id.
            node_id: Existing node's id.
            config: New full per-node config dict (replaces, doesn't
                merge - voice owns the per-type schema).
            label: New display label.
            position: New ``{"x":..., "y":...}``.
            connections: New outgoing connections list (replaces). Pass
                an empty list to clear; omit to leave unchanged.
            conditional_connections: New conditional connections dict
                (replaces). Pass an empty dict to clear; omit to leave
                unchanged.
        """
        if not action_id or not node_id:
            return "Error: action_id and node_id are required."
        cfg, err = await _fetch_config(action_id)
        if err is not None or cfg is None:
            return err or "Internal error: missing config."
        nodes = cfg["nodes"]
        idx = next(
            (i for i, n in enumerate(nodes) if _node_id_of(n) == node_id),
            None,
        )
        if idx is None:
            return f"Error: node id '{node_id}' not found in workflow {action_id}."
        existing = nodes[idx]
        if not isinstance(existing, dict):
            return f"Error: node '{node_id}' has malformed shape; cannot patch."

        # Rewrite to canonical, preserving existing values for fields the
        # caller did not pass.
        rewritten = _rewrite_node_canonical(existing)
        if label is not None:
            rewritten["name"] = label
        if config is not None:
            rewritten["config"] = config
        if position is not None:
            rewritten["position"] = position
        if connections is not None:
            rewritten["connections"] = list(connections)
        if conditional_connections is not None:
            if conditional_connections:
                rewritten["conditional_connections"] = dict(conditional_connections)
            else:
                rewritten.pop("conditional_connections", None)
        nodes[idx] = rewritten

        try:
            return _unwrap(await client.put(f"/workflows/{action_id}", body={"config": cfg}))
        except Exception as e:
            return f"Update node failed: {e}"

    @server.tool(name=tool_name("remove_node"), annotations=_REVERSIBLE_WRITE)
    async def remove_node(action_id: str, node_id: str) -> dict[str, Any] | str:
        """Remove a node from a workflow's graph.

        Also drops any edges that reference the node so the resulting
        graph stays connected. The node is removed from ``nodes`` and
        any edge with ``source == node_id`` or ``target == node_id`` is
        removed from ``edges``.

        IMPORTANT: If ``node_id`` is the workflow's ``start_node_id`` /
        ``startNodeId`` the graph becomes invalid - voice will reject
        the PUT. Pick a new start node via ``g8_workflow_update`` first
        in that case.

        Args:
            action_id: Workflow id.
            node_id: Node to remove (matched against ``node_id`` /
                ``nodeId`` / ``id`` so legacy rows still work).
        """
        if not action_id or not node_id:
            return "Error: action_id and node_id are required."
        cfg, err = await _fetch_config(action_id)
        if err is not None or cfg is None:
            return err or "Internal error: missing config."
        nodes = cfg["nodes"]
        edges = cfg["edges"]
        before_n = len(nodes)
        cfg["nodes"] = [n for n in nodes if _node_id_of(n) != node_id]
        if len(cfg["nodes"]) == before_n:
            return f"Error: node id '{node_id}' not found in workflow {action_id}."
        cfg["edges"] = [
            e for e in edges
            if not (
                isinstance(e, dict)
                and (e.get("source") == node_id or e.get("target") == node_id)
            )
        ]
        # CRITICAL: also scrub the removed id from every other node's
        # connections list and from any conditional_connections mapping.
        # If we left a dangling reference behind, voice's executor would
        # still try to traverse to the deleted node and fail at runtime.
        for i, n in enumerate(cfg["nodes"]):
            if not isinstance(n, dict):
                continue
            mutated = False
            conns = n.get("connections")
            if isinstance(conns, list) and node_id in conns:
                n["connections"] = [c for c in conns if c != node_id]
                mutated = True
            cc = n.get("conditional_connections")
            if isinstance(cc, dict):
                cleaned = {k: v for k, v in cc.items() if v != node_id}
                if len(cleaned) != len(cc):
                    n["conditional_connections"] = cleaned or None
                    if n["conditional_connections"] is None:
                        n.pop("conditional_connections", None)
                    mutated = True
            if mutated:
                cfg["nodes"][i] = n
        try:
            return _unwrap(await client.put(f"/workflows/{action_id}", body={"config": cfg}))
        except Exception as e:
            return f"Remove node failed: {e}"

    @server.tool(name=tool_name("connect_nodes"), annotations=_REVERSIBLE_WRITE)
    async def connect_nodes(
        action_id: str,
        source: str,
        target: str,
        edge_id: str | None = None,
        condition: str | None = None,
    ) -> dict[str, Any] | str:
        """Add an edge connecting one node to another.

        Performs a DUAL write: appends to top-level ``edges`` AND appends
        ``target`` to the source node's ``connections`` list. The latter
        is what voice's executor actually traverses - an edge without the
        matching connection entry would render in the canvas but never
        execute. The helper rewrites the source node to canonical shape
        as part of the write so legacy ReactFlow rows pick up the field.

        Idempotent on (source, target) when BOTH the edge and the
        connection entry are already present - a re-call is a no-op.
        Voice's branch / decision nodes use ``condition`` (set on the
        edge) plus ``conditional_connections`` (a dict on the source node
        mapping path_id → target_node_id) to gate which downstream branch
        fires; pass ``condition`` here to set the edge label, and use
        ``g8_workflow_update_node`` to set the per-node
        ``conditional_connections`` when wiring a condition node.

        Both endpoints are looked up against ``node_id`` / ``nodeId`` /
        ``id`` so the helper works on legacy ReactFlow-shape graphs.

        Args:
            action_id: Workflow id.
            source: Upstream node id.
            target: Downstream node id.
            edge_id: Optional explicit edge id. Defaults to
                ``"edge-{source}-{target}"`` (matches the production
                convention from real workflows).
            condition: Optional condition string for branch / decision
                nodes (e.g. ``"true"``, ``"false"``, ``"matches_icp"``).
        """
        if not action_id or not source or not target:
            return "Error: action_id, source, and target are required."
        cfg, err = await _fetch_config(action_id)
        if err is not None or cfg is None:
            return err or "Internal error: missing config."
        nodes = cfg["nodes"]
        src_idx = next(
            (i for i, n in enumerate(nodes) if isinstance(n, dict) and _node_id_of(n) == source),
            None,
        )
        if src_idx is None:
            return f"Error: source node '{source}' not in workflow {action_id}."
        if not any(isinstance(n, dict) and _node_id_of(n) == target for n in nodes):
            return f"Error: target node '{target}' not in workflow {action_id}."
        edges = cfg["edges"]
        # Idempotent on the (source, target) pair so a re-call is safe.
        edge_already_present = any(
            isinstance(e, dict) and e.get("source") == source and e.get("target") == target
            for e in edges
        )
        # Inspect source node's connections list - the field voice's
        # executor actually traverses on. An edge without a connection
        # wouldn't reach the executor, so we treat the (edge, connection)
        # pair as the truth and only short-circuit when BOTH are present.
        src_node = nodes[src_idx]
        src_conns_present = (
            isinstance(src_node, dict)
            and isinstance(src_node.get("connections"), list)
            and target in src_node["connections"]
        )
        if edge_already_present and src_conns_present:
            try:
                return _unwrap(await client.get(f"/workflows/{action_id}"))
            except Exception as e:
                return f"Connect nodes (idempotent reload) failed: {e}"
        if not edge_already_present:
            new_edge: dict[str, Any] = {
                "id": edge_id or f"edge-{source}-{target}",
                "source": source,
                "target": target,
            }
            if condition is not None:
                new_edge["condition"] = condition
            edges.append(new_edge)
        # CRITICAL: keep node.connections in sync - voice's executor uses
        # node.connections[0], not top-level edges. Rewrite the source to
        # canonical shape so legacy ReactFlow rows pick up the field.
        if isinstance(src_node, dict):
            rewritten = _rewrite_node_canonical(src_node)
            conns = rewritten.setdefault("connections", [])
            if target not in conns:
                conns.append(target)
            nodes[src_idx] = rewritten
        try:
            return _unwrap(await client.put(f"/workflows/{action_id}", body={"config": cfg}))
        except Exception as e:
            return f"Connect nodes failed: {e}"

    # ------------------------------------------------------------------
    # Lifecycle - execute + execution status + pause/resume/stop
    # ------------------------------------------------------------------

    @server.tool(name=tool_name("execute"), annotations=_DESTRUCTIVE)
    async def execute_workflow(
        action_id: str,
        input_data: dict[str, Any] | None = None,
        triggered_by: str | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any] | str:
        """Trigger a workflow run.

        IMPORTANT: This actually runs the workflow - it can spend money
        (LLM tokens, send messages, etc.) depending on the nodes inside.
        ALWAYS confirm with the user. Recommended flow: ``dry_run=True``
        first to render a confirmation widget, then again with
        ``dry_run=False`` after the user confirms.

        Returns ``{execution_id, status: "queued" | "running"}``. Poll
        with ``g8_workflow_get_execution`` until status is ``completed``
        or ``failed``.

        Args:
            action_id: Workflow id.
            input_data: Optional ``{key: value}`` dict - becomes
                ``{{trigger.key}}`` references inside the graph.
                Defaults to ``{}``.
            triggered_by: Optional caller user_id (defaults to the API
                key's user server-side).
            dry_run: When ``True``, return a confirmation preview
                without firing the workflow.
        """
        if not action_id:
            return "Error: action_id is required."
        if dry_run:
            details = [ConfirmationDetail(label="Workflow", value=action_id)]
            if input_data:
                details.append(ConfirmationDetail(label="Input keys", value=", ".join(input_data.keys())))
            confirm_args: dict[str, Any] = {
                "action_id": action_id,
                "input_data": input_data,
                "triggered_by": triggered_by,
                "dry_run": False,
            }
            confirm_args = {k: v for k, v in confirm_args.items() if v is not None}
            return ConfirmationPreview(
                action_label="Run workflow",
                summary=f"Trigger an execution of workflow {action_id}.",
                details=details,
                warning="Workflow nodes can spend credits, send messages, or call external APIs. Confirm intent first.",
                cost_label=None,
                confirm_tool=tool_name("execute"),
                confirm_args=confirm_args,
                confirm_label="Run workflow",
                cancel_label="Cancel",
            ).model_dump()
        body: dict[str, Any] = {"input_data": input_data or {}}
        if triggered_by is not None:
            body["triggered_by"] = triggered_by
        try:
            return _unwrap(await client.post(f"/workflows/{action_id}/execute", body=body))
        except Exception as e:
            return f"Execute workflow failed: {e}"

    @server.tool(name=tool_name("get_execution"), annotations=_READ_ONLY)
    async def get_execution(execution_id: str) -> dict[str, Any] | str:
        """Get a workflow execution's status / output / token cost.

        Polling pattern: call this every few seconds after
        ``g8_workflow_execute`` until ``status`` is ``completed`` or
        ``failed``. Voice's GET enforces tenant isolation natively, so
        this surfaces 404 for executions that don't belong to the
        caller's org.

        Args:
            execution_id: Execution UUID returned by
                ``g8_workflow_execute``.
        """
        if not execution_id:
            return "Error: execution_id is required."
        try:
            return _unwrap(await client.get(f"/workflows/executions/{execution_id}"))
        except Exception as e:
            return f"Get execution failed: {e}"

    @server.tool(name=tool_name("pause_execution"), annotations=_REVERSIBLE_WRITE)
    async def pause_execution(
        execution_id: str,
        reason: str | None = None,
        message: str | None = None,
    ) -> dict[str, Any] | str:
        """Pause a running workflow execution. Reversible - call
        ``g8_workflow_resume_execution`` to flip back to ``running``.
        Idempotent: pausing an already-paused execution is a no-op.

        The developer_api proxy adds a pre-flight org check so this
        cannot pause an execution belonging to another tenant.

        Args:
            execution_id: Execution UUID.
            reason: Optional short reason saved with the execution.
            message: Optional human-readable note.
        """
        if not execution_id:
            return "Error: execution_id is required."
        body: dict[str, Any] = {}
        if reason is not None:
            body["reason"] = reason
        if message is not None:
            body["message"] = message
        try:
            return _unwrap(
                await client.post(f"/workflows/executions/{execution_id}/pause", body=body)
            )
        except Exception as e:
            return f"Pause execution failed: {e}"

    @server.tool(name=tool_name("resume_execution"), annotations=_REVERSIBLE_WRITE)
    async def resume_execution(
        execution_id: str,
        from_step: str | None = None,
        skip_failed: bool | None = None,
    ) -> dict[str, Any] | str:
        """Resume a paused workflow execution. Idempotent.

        Pre-flight org check is enforced server-side.

        Args:
            execution_id: Execution UUID.
            from_step: Optional step id to resume from (defaults to the
                step where the pause happened).
            skip_failed: When ``True``, skip any step that previously
                failed instead of retrying.
        """
        if not execution_id:
            return "Error: execution_id is required."
        body: dict[str, Any] = {}
        if from_step is not None:
            body["from_step"] = from_step
        if skip_failed is not None:
            body["skip_failed"] = skip_failed
        try:
            return _unwrap(
                await client.post(f"/workflows/executions/{execution_id}/resume", body=body)
            )
        except Exception as e:
            return f"Resume execution failed: {e}"

    @server.tool(name=tool_name("stop_execution"), annotations=_DESTRUCTIVE)
    async def stop_execution(
        execution_id: str,
        reason: str | None = None,
        save_partial_results: bool | None = None,
        message: str | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any] | str:
        """Stop a workflow execution permanently.

        IMPORTANT: One-way - the execution cannot be resumed after
        stop. Use ``g8_workflow_pause_execution`` instead if the user
        might want to flip it back. ALWAYS confirm with the user.
        Recommended flow: ``dry_run=True`` first.

        Pre-flight org check is enforced server-side.

        Args:
            execution_id: Execution UUID.
            reason: Optional short reason saved with the execution.
            save_partial_results: When ``True``, persist per-step output
                produced before the stop. Default ``False``.
            message: Optional human-readable note.
            dry_run: When ``True``, return a confirmation preview.
        """
        if not execution_id:
            return "Error: execution_id is required."
        if dry_run:
            details = [ConfirmationDetail(label="Execution ID", value=execution_id)]
            if reason:
                details.append(ConfirmationDetail(label="Reason", value=reason))
            if save_partial_results is not None:
                details.append(
                    ConfirmationDetail(label="Save partial results", value=str(save_partial_results).lower())
                )
            confirm_args: dict[str, Any] = {
                "execution_id": execution_id,
                "reason": reason,
                "save_partial_results": save_partial_results,
                "message": message,
                "dry_run": False,
            }
            confirm_args = {k: v for k, v in confirm_args.items() if v is not None}
            return ConfirmationPreview(
                action_label="Stop execution",
                summary=f"Permanently stop execution {execution_id}.",
                details=details,
                warning="One-way. Use pause_execution instead if you may want to resume.",
                cost_label=None,
                confirm_tool=tool_name("stop_execution"),
                confirm_args=confirm_args,
                confirm_label="Stop execution",
                cancel_label="Cancel",
            ).model_dump()
        body: dict[str, Any] = {}
        if reason is not None:
            body["reason"] = reason
        if save_partial_results is not None:
            body["save_partial_results"] = save_partial_results
        if message is not None:
            body["message"] = message
        try:
            return _unwrap(
                await client.post(f"/workflows/executions/{execution_id}/stop", body=body)
            )
        except Exception as e:
            return f"Stop execution failed: {e}"

    @server.tool(name=tool_name("reset_trigger_cursor"), annotations=_REVERSIBLE_WRITE)
    async def reset_trigger_cursor(action_id: str) -> dict[str, Any] | str:
        """Reset the workflow's trigger cursor to ``now()``.

        Use case: a workflow with a sequence_reply or domain_visit
        trigger has been disabled for a while; on re-enable it would
        otherwise replay every event in the backlog. Calling this
        first jumps the cursor forward so only events from now on
        will fire the workflow.

        Args:
            action_id: Workflow id.
        """
        if not action_id:
            return "Error: action_id is required."
        try:
            return _unwrap(await client.post(f"/workflows/{action_id}/trigger-reset"))
        except Exception as e:
            return f"Reset trigger cursor failed: {e}"

    # ------------------------------------------------------------------
    # Resolver helpers - convert "send a Roam DM to Hamza" into the
    # concrete user_ids / channel_ids / etc. that node configs require.
    # All read-only; safe to call without confirmation.
    # ------------------------------------------------------------------

    @server.tool(name=tool_name("list_roam_users"), annotations=_READ_ONLY)
    async def list_roam_users() -> dict[str, Any] | str:
        """List Roam users connected to the org.

        Use this to resolve a user description ("DM Hamza", "ping the SDR
        team") into the concrete user_ids needed for
        ``send_roam_notification`` (mode=dm, user_ids=[...]) or
        ``recipient_id`` (mode=group). Each entry includes id, name, email.
        Returns ``{users: [{id, name, email}]}``.
        """
        try:
            return _unwrap(await client.get("/workflows/integrations/roam/users"))
        except Exception as e:
            return f"List Roam users failed: {e}"

    @server.tool(name=tool_name("list_roam_groups"), annotations=_READ_ONLY)
    async def list_roam_groups() -> dict[str, Any] | str:
        """List Roam groups connected to the org.

        Use this to resolve a group description ("post to #team-sdr") into
        the concrete group ``address_id`` needed for
        ``send_roam_notification`` (mode=group, recipient_id=...).
        Each entry includes address_id, name, group_type, access_mode.
        Returns ``{groups: [{address_id, name, group_type, access_mode}]}``.
        """
        try:
            return _unwrap(await client.get("/workflows/integrations/roam/groups"))
        except Exception as e:
            return f"List Roam groups failed: {e}"

    @server.tool(name=tool_name("list_slack_users"), annotations=_READ_ONLY)
    async def list_slack_users() -> dict[str, Any] | str:
        """List Slack users in the connected workspace.

        Use this to resolve a user description ("DM Hamza on Slack") into
        the concrete Slack user_id needed for
        ``send_slack_notification`` (mode=dm, user_id=...).
        Each entry includes id, name, real_name, is_bot, deleted.
        Returns ``{users: [{id, name, real_name, is_bot, deleted}]}``.
        """
        try:
            return _unwrap(await client.get("/workflows/integrations/slack/users"))
        except Exception as e:
            return f"List Slack users failed: {e}"

    @server.tool(name=tool_name("list_slack_channels"), annotations=_READ_ONLY)
    async def list_slack_channels() -> dict[str, Any] | str:
        """List Slack channels in the connected workspace.

        Use this to resolve a channel description ("post to #general") into
        the concrete Slack channel_id needed for
        ``send_slack_notification`` (mode=channel, channel_id=...).
        Each entry includes id, name, is_private, num_members.
        Returns ``{channels: [{id, name, is_private, num_members}]}``.
        """
        try:
            return _unwrap(await client.get("/workflows/integrations/slack/channels"))
        except Exception as e:
            return f"List Slack channels failed: {e}"

    @server.tool(name=tool_name("list_mcp_servers"), annotations=_READ_ONLY)
    async def list_mcp_servers() -> dict[str, Any] | str:
        """List MCP servers connected to the org with their available tools.

        Use this to fill the ``tool`` node config:
          - ``mcp_server_id`` from ``servers[].mcp_server_id``
          - ``mcp_tool_name`` from the per-server tools list

        Each entry includes id, mcp_server_id, name, transport_type,
        enabled, last_connected_at. The voice endpoint also exposes
        ``GET /api/v1/mcp-servers/{id}/tools`` for per-server tool details.
        Returns ``{servers: [...], total}``.
        """
        try:
            return _unwrap(await client.get("/workflows/mcp-servers"))
        except Exception as e:
            return f"List MCP servers failed: {e}"

    @server.tool(name=tool_name("list_dispositions"), annotations=_READ_ONLY)
    async def list_dispositions() -> dict[str, Any] | str:
        """List valid call disposition values (static enum).

        Use this to fill ``disposition_filters`` on call / voicemail /
        new_call_disposition trigger configs. Mirrors voice's canonical
        ``DispositionType`` enum so the catalog has a single source of
        truth without a network round-trip.

        Returns ``{dispositions: [{value, label, category}]}`` where
        category is one of ``sdr_selectable | system_detected | system_set``.
        """
        try:
            return _unwrap(await client.get("/workflows/dispositions"))
        except Exception as e:
            return f"List dispositions failed: {e}"
