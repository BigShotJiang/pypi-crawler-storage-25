"""Developer mode tools - repo-scoped operations for building GTM into codebases.

These tools require a repo_id and are used by developers in Cursor, Windsurf,
or Claude Code while building products.
"""

from __future__ import annotations

from mcp.server import FastMCP
from mcp.types import ToolAnnotations

from g8_mcp_server.client import G8Client, safe_call_typed
from g8_mcp_server.models import (
    ActionResult,
    CampaignsResult,
    KBDocumentsResult,
    KBResult,
    RepoDetail,
    ResourceDetail,
    ScanResult,
)

_READ_ONLY = ToolAnnotations(readOnlyHint=True, idempotentHint=True)
# Repo mutations that aren't destructive - connect/scan/install create or
# modify repo state but don't delete anything. `g8_apply_install` stays
# _DESTRUCTIVE because it actually writes patches to the checked-out tree.
_WRITE = ToolAnnotations(
    readOnlyHint=False, destructiveHint=False, idempotentHint=False, openWorldHint=True
)
_DESTRUCTIVE = ToolAnnotations(destructiveHint=True, openWorldHint=True)


def register(server: FastMCP, client: G8Client) -> None:
    """Register dev-mode tools (repo-scoped)."""

    # -- Repos --

    @server.tool(annotations=_WRITE)
    async def g8_connect_repo(
        repo_url: str, repo_name: str, provider: str = "github", default_branch: str = "main"
    ) -> ActionResult | str:
        """Connect a GitHub/GitLab repository to graph8 for GTM automation.

        After connecting, run g8_scan_repo to analyze the tech stack.

        Args:
            repo_url: Full repository URL (e.g. https://github.com/org/repo)
            repo_name: Short name for the repo (e.g. my-saas-app)
            provider: Repository provider - github, gitlab, or local
            default_branch: Default branch name (usually main)
        """
        return await safe_call_typed(
            client.post(
                "/repos",
                {
                    "repo_url": repo_url,
                    "repo_name": repo_name,
                    "provider": provider,
                    "default_branch": default_branch,
                },
            ),
            ActionResult.from_envelope,
            context="Repo connection",
        )

    @server.tool(annotations=_WRITE)
    async def g8_scan_repo(repo_id: str) -> ActionResult | str:
        """Scan a connected repository for tech stack, API routes, and GTM readiness.

        Args:
            repo_id: Repository ID from g8_connect_repo or g8_status
        """
        return await safe_call_typed(
            client.post(f"/repos/{repo_id}/scan", {}),
            ActionResult.from_envelope,
            context="Repo scan",
        )

    @server.tool(annotations=_READ_ONLY)
    async def g8_get_scan_results(repo_id: str) -> ScanResult | str:
        """Get the latest scan results for a repository.

        Returns detected tech stack, API routes, README summary, and GTM readiness flags.

        Args:
            repo_id: Repository ID
        """
        return await safe_call_typed(
            client.get(f"/repos/{repo_id}/scan"),
            ScanResult.from_envelope,
            context="Scan results",
        )

    @server.tool(annotations=_READ_ONLY)
    async def g8_status(repo_id: str) -> RepoDetail | str:
        """Get the current status of a connected repository.

        Args:
            repo_id: Repository ID
        """
        return await safe_call_typed(
            client.get(f"/repos/{repo_id}"),
            RepoDetail.from_envelope,
            context="Repo",
        )

    @server.tool(annotations=_READ_ONLY)
    async def g8_doctor(repo_id: str) -> ActionResult | str:
        """Run health checks on a repository's GTM installation.

        Args:
            repo_id: Repository ID
        """
        return await safe_call_typed(
            client.post(f"/repos/{repo_id}/verify", {}),
            ActionResult.from_envelope,
            context="Repo health check",
        )

    # -- Install --

    @server.tool(annotations=_WRITE)
    async def g8_install_spine(repo_id: str) -> ActionResult | str:
        """Generate a GTM install patch set for a scanned repository.

        Produces code patches that add tracking, forms, identity resolution,
        and attribution to the codebase. Review the patches before applying.

        Args:
            repo_id: Repository ID (must have scan results first)
        """
        return await safe_call_typed(
            client.post(f"/repos/{repo_id}/install"),
            ActionResult.from_envelope,
            context="GTM install",
        )

    @server.tool(annotations=_DESTRUCTIVE)
    async def g8_apply_install(repo_id: str) -> ActionResult | str:
        """Apply the generated GTM patches to the repository.

        IMPORTANT: This modifies the codebase. Always confirm with the user first.

        Args:
            repo_id: Repository ID with a pending patch set
        """
        return await safe_call_typed(
            client.post(f"/repos/{repo_id}/install/apply"),
            ActionResult.from_envelope,
            context="GTM install apply",
        )

    # -- Dev-mode campaigns (repo-scoped) --

    @server.tool(annotations=_READ_ONLY)
    async def g8_list_campaigns(repo_id: str, page: int = 1, limit: int = 50) -> CampaignsResult | str:
        """List generated campaigns for a repository.

        Args:
            repo_id: Repository ID
            page: Page number (default 1)
            limit: Items per page (default 50, max 200)
        """
        return await safe_call_typed(
            client.get(f"/repos/{repo_id}/campaigns", {"page": page, "limit": limit}),
            CampaignsResult.from_envelope,
            context="Campaign list",
        )

    @server.tool(annotations=_READ_ONLY)
    async def g8_get_campaign(repo_id: str, campaign_id: str) -> ResourceDetail | str:
        """Get full details for a specific campaign.

        Args:
            repo_id: Repository ID
            campaign_id: Campaign ID from g8_list_campaigns
        """
        return await safe_call_typed(
            client.get(f"/repos/{repo_id}/campaigns/{campaign_id}"),
            ResourceDetail.from_envelope,
            context="Campaign",
        )

    @server.tool(annotations=_READ_ONLY)
    async def g8_search_kb(repo_id: str, query: str) -> KBResult | str:
        """Search the GTM knowledge base for a repository.

        Args:
            repo_id: Repository ID
            query: Search query (e.g. "ICP for enterprise buyers")
        """
        return await safe_call_typed(
            client.post(f"/repos/{repo_id}/kb/search", {"query": query}),
            KBResult.from_envelope,
            context="KB search",
        )

    @server.tool(annotations=_READ_ONLY)
    async def g8_list_kb_documents(repo_id: str) -> KBDocumentsResult | str:
        """List all documents in the GTM knowledge base.

        Args:
            repo_id: Repository ID
        """
        return await safe_call_typed(
            client.get(f"/repos/{repo_id}/kb"),
            KBDocumentsResult.from_envelope,
            context="KB documents",
        )
