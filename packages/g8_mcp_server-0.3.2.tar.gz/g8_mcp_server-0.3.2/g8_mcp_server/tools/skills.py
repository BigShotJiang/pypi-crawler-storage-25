"""Skills tools - workflow-level domain knowledge served as markdown.

Registers two tools:
- g8_list_skills: catalog of available skills (slug, title, when_to_use)
- g8_load_skill: full markdown content for a single skill by slug

Skills are prescriptive guides for multi-step graph8 workflows. They
complement tool docstrings (which describe individual tools) by covering
the sequencing, confirmations, and gotchas that only show up across
multiple tool calls.

Both tools return Pydantic `Model | str` unions (Upgrade 2 - structured
output). The success branch gives the agent typed fields (slug / title /
content / ...); the `str` branch is reserved for error messages on the
unhappy path (unknown slug, missing file). This mirrors the envelope
pattern used by every other tool in the MCP surface.
"""

from __future__ import annotations

from mcp.server import FastMCP
from mcp.types import ToolAnnotations

from g8_mcp_server.models import (
    SkillContentResult,
    SkillsCatalogResult,
)
from g8_mcp_server.skills import SKILLS_CATALOG, get_skill_content

_READ_ONLY = ToolAnnotations(readOnlyHint=True, idempotentHint=True)


def register(server: FastMCP) -> None:
    """Register skill discovery tools on the MCP server."""

    @server.tool(annotations=_READ_ONLY)
    async def g8_list_skills() -> SkillsCatalogResult | str:
        """List available graph8 skills - prescriptive workflow guides.

        Each skill is a markdown document covering a specific user journey
        (prospecting, running a campaign, installing tracking, handling
        inbox replies). Call g8_load_skill(slug) to fetch the full content.

        Returns a structured catalog with slug, title, summary, and
        when_to_use for every skill. Use when_to_use to decide which skill
        to load next.
        """
        return SkillsCatalogResult.from_entries(list(SKILLS_CATALOG))

    @server.tool(annotations=_READ_ONLY)
    async def g8_load_skill(slug: str) -> SkillContentResult | str:
        """Load the full markdown content of a graph8 skill by slug.

        Use this after g8_list_skills when the user's task matches a
        skill's when_to_use. The returned content is prescriptive - follow
        the tool sequencing and confirmations it describes.

        Args:
            slug: Skill slug from g8_list_skills (e.g. "prospecting-and-lists")
        """
        # Find catalog entry BEFORE loading content so we can surface a
        # well-formed error even when the slug is valid but the markdown
        # file went missing (rare - would indicate a broken package build).
        entry = next((s for s in SKILLS_CATALOG if s["slug"] == slug), None)
        if entry is None:
            available = ", ".join(s["slug"] for s in SKILLS_CATALOG)
            return (
                f"Unknown skill slug: {slug!r}. "
                f"Available slugs: {available}. "
                f"Call g8_list_skills to see the full catalog with descriptions."
            )

        content = get_skill_content(slug)
        if content is None:
            return (
                f"Skill {slug!r} is registered in the catalog but its markdown "
                f"file is missing on disk. This is a packaging bug - please "
                f"report it. Other skills should still load normally."
            )

        return SkillContentResult.from_entry(dict(entry), content)
