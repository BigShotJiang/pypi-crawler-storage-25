"""Pipeline management tools - org-scoped CRUD + AI suggester (Stage Checklist v2 Phase 1.6).

Twelve tools covering:
  Read:  list_pipelines, get_pipeline, list_stage_evidence_library
  Write: create_pipeline, update_pipeline, create_stage, update_stage,
         reorder_stages, suggest_pipeline_from_context, create_pipeline_from_suggestion
  Destructive: delete_pipeline, delete_stage

The suggester reads the org's `cb_global_contexts` rows (brand_brief,
value_props, ICPs, personas, etc.) and returns a draft grounded in that
context. The draft is NOT auto-persisted - the agent reviews, optionally
edits, then calls `create_pipeline_from_suggestion`.
"""

from __future__ import annotations

from typing import Any

from mcp.server import FastMCP
from mcp.types import ToolAnnotations

from g8_mcp_server.client import G8Client, safe_call_typed
from g8_mcp_server.models import ActionResult, ResourceDetail

_READ_ONLY = ToolAnnotations(readOnlyHint=True, idempotentHint=True)
_WRITE = ToolAnnotations(
    readOnlyHint=False, destructiveHint=False, idempotentHint=False, openWorldHint=True
)
_DESTRUCTIVE = ToolAnnotations(destructiveHint=True, openWorldHint=True)


def register(server: FastMCP, client: G8Client, *, name_prefix: str = "") -> None:
    """Register pipeline tools.

    When ``name_prefix="gtm"`` is passed (the "all" mode case), tools are
    namespaced as ``g8_gtm_*`` to coexist with dev-mode tools.
    """

    def tool_name(base_name: str) -> str:
        if name_prefix:
            return f"g8_{name_prefix}_{base_name}"
        return f"g8_{base_name}"

    # ------------------------------------------------------------------ Reads

    @server.tool(name=tool_name("list_pipelines"), annotations=_READ_ONLY)
    async def list_pipelines() -> ResourceDetail | str:
        """List all deal pipelines for your organization, with stages.

        Each stage includes its `required_elements` (must-have evidence keys
        that gate stage advance), `recommended_elements` (nice-to-haves), and
        `channel_scripts` (markdown talk tracks per channel: call/email/linkedin).
        """
        return await safe_call_typed(
            client.get("/v1/pipelines"),
            ResourceDetail.from_envelope,
            context="List pipelines",
        )

    @server.tool(name=tool_name("get_pipeline"), annotations=_READ_ONLY)
    async def get_pipeline(pipeline_id: str) -> ResourceDetail | str:
        """Get one pipeline by ID, including all stages and their checklist + scripts."""
        return await safe_call_typed(
            client.get(f"/v1/pipelines/{pipeline_id}"),
            ResourceDetail.from_envelope,
            context="Get pipeline",
        )

    @server.tool(name=tool_name("list_stage_evidence_library"), annotations=_READ_ONLY)
    async def list_stage_evidence_library() -> ResourceDetail | str:
        """List the 8 canonical evidence keys + human-readable labels.

        Use this BEFORE constructing `required_elements` / `recommended_elements`
        payloads so you know the vocabulary. Any key not in this list will be
        silently dropped at write time.
        """
        return await safe_call_typed(
            client.get("/v1/pipelines/evidence-library"),
            ResourceDetail.from_envelope,
            context="Stage evidence library",
        )

    # ----------------------------------------------------------------- Writes

    @server.tool(name=tool_name("create_pipeline"), annotations=_WRITE)
    async def create_pipeline(
        name: str = "Sales Pipeline",
        target: str = "prospects_revenue",
        blank: bool = False,
    ) -> ActionResult | str:
        """Create a new pipeline with default stages seeded for the target.

        `target` controls which default stage shape gets seeded:
          - `prospects_revenue` (default) - AE / new-logo deals (9 stages)
          - `prospects_meeting` - SDR meeting-booking flow (7 stages)
          - `customers_revenue` - CSM expansion / renewal (8 stages)

        Set `blank=True` to skip the per-target defaults and start with 2
        placeholder stages the user / agent will customize manually. Useful
        for the "build from scratch" path.

        For an AI-grounded suggestion based on the org's global context,
        prefer `suggest_pipeline_from_context` followed by
        `create_pipeline_from_suggestion`.
        """
        return await safe_call_typed(
            client.post(
                "/v1/pipelines",
                body={"name": name, "target": target, "blank": blank},
            ),
            ActionResult.from_envelope,
            context="Create pipeline",
        )

    @server.tool(name=tool_name("update_pipeline"), annotations=_WRITE)
    async def update_pipeline(
        pipeline_id: str,
        name: str | None = None,
        set_default: bool = False,
    ) -> ActionResult | str:
        """Rename a pipeline and/or promote it to default.

        Pass `name` to rename. Pass `set_default=True` to make this the org's
        default pipeline (unsets is_default on all others atomically).
        """
        if set_default:
            return await safe_call_typed(
                client.put(f"/v1/pipelines/{pipeline_id}/set-default", body={}),
                ActionResult.from_envelope,
                context="Set default pipeline",
            )
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        return await safe_call_typed(
            client.put(f"/v1/pipelines/{pipeline_id}", body=body),
            ActionResult.from_envelope,
            context="Update pipeline",
        )

    @server.tool(name=tool_name("delete_pipeline"), annotations=_DESTRUCTIVE)
    async def delete_pipeline(pipeline_id: str) -> ActionResult | str:
        """Delete a pipeline. Fails if the pipeline has deals or is the only one."""
        return await safe_call_typed(
            client.delete(f"/v1/pipelines/{pipeline_id}"),
            ActionResult.from_envelope,
            context="Delete pipeline",
        )

    @server.tool(name=tool_name("create_stage"), annotations=_WRITE)
    async def create_stage(
        pipeline_id: str,
        name: str,
        probability: int = 0,
        stage_type: str = "open",
        color: str = "#6B7280",
        required_elements: list[str] | None = None,
        recommended_elements: list[str] | None = None,
        channel_scripts: dict[str, str] | None = None,
    ) -> ActionResult | str:
        """Add a new stage to a pipeline.

        `required_elements` and `recommended_elements` must be subsets of the
        8 keys returned by `list_stage_evidence_library`. Unknown keys are
        silently dropped server-side.

        `channel_scripts` is an optional dict with keys `call`, `email`,
        `linkedin` (any subset). Each value is markdown text - opinionated
        talk tracks for that channel at this stage. Empty/whitespace values
        are dropped.

        `stage_type` must be one of: "open", "won", "lost".
        """
        body = {
            "name": name,
            "probability": probability,
            "stage_type": stage_type,
            "color": color,
            "required_elements": required_elements or [],
            "recommended_elements": recommended_elements or [],
        }
        if channel_scripts:
            body["channel_scripts"] = channel_scripts
        return await safe_call_typed(
            client.post(f"/v1/pipelines/{pipeline_id}/stages", body=body),
            ActionResult.from_envelope,
            context="Create stage",
        )

    @server.tool(name=tool_name("update_stage"), annotations=_WRITE)
    async def update_stage(
        pipeline_id: str,
        stage_id: str,
        name: str | None = None,
        probability: int | None = None,
        stage_type: str | None = None,
        color: str | None = None,
        required_elements: list[str] | None = None,
        recommended_elements: list[str] | None = None,
        channel_scripts: dict[str, str] | None = None,
    ) -> ActionResult | str:
        """Update a stage. All parameters are optional - pass only what you want to change.

        Same vocabulary rules as `create_stage` for required_elements,
        recommended_elements, and channel_scripts.
        """
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if probability is not None:
            body["probability"] = probability
        if stage_type is not None:
            body["stage_type"] = stage_type
        if color is not None:
            body["color"] = color
        if required_elements is not None:
            body["required_elements"] = required_elements
        if recommended_elements is not None:
            body["recommended_elements"] = recommended_elements
        if channel_scripts is not None:
            body["channel_scripts"] = channel_scripts
        return await safe_call_typed(
            client.put(f"/v1/pipelines/{pipeline_id}/stages/{stage_id}", body=body),
            ActionResult.from_envelope,
            context="Update stage",
        )

    @server.tool(name=tool_name("delete_stage"), annotations=_DESTRUCTIVE)
    async def delete_stage(pipeline_id: str, stage_id: str) -> ActionResult | str:
        """Delete a stage. Fails if the stage has deals or the pipeline would drop below 2 stages."""
        return await safe_call_typed(
            client.delete(f"/v1/pipelines/{pipeline_id}/stages/{stage_id}"),
            ActionResult.from_envelope,
            context="Delete stage",
        )

    @server.tool(name=tool_name("reorder_stages"), annotations=_WRITE)
    async def reorder_stages(pipeline_id: str, stage_ids: list[str]) -> ActionResult | str:
        """Reorder stages in a pipeline. Pass the full ordered list of stage IDs."""
        return await safe_call_typed(
            client.put(
                f"/v1/pipelines/{pipeline_id}/stages/reorder",
                body={"stage_ids": stage_ids},
            ),
            ActionResult.from_envelope,
            context="Reorder stages",
        )

    # --------------------------------------------------- AI suggester (paid)

    @server.tool(name=tool_name("suggest_pipeline_from_context"), annotations=_WRITE)
    async def suggest_pipeline_from_context(
        target: str = "prospects_revenue",
        motion_hint: str | None = None,
        use_brief_only: bool = True,
    ) -> ResourceDetail | str:
        """Generate an AI-suggested pipeline grounded in the org's GTM context.

        Reads the org's approved `cb_global_contexts` rows (brand_brief,
        value_props, ICPs, personas, messaging_house, offer_brief, pricing_matrix,
        buyer_psychology, gtm_channel - or the pre-extracted `campaign_intelligence_brief`
        if present) and returns a `PipelineSuggestion` draft. Each stage carries
        opinionated `required_elements`, `recommended_elements`, and
        `channel_scripts` anchored to the org's actual language - not generic.

        **This tool consumes credits** (g8_t2 / Sonnet tier per call). Returns
        a draft only - does NOT persist. Pass the result to
        `create_pipeline_from_suggestion` (with optional edits) to commit.

        `target` picks the pipeline shape:
          - `prospects_revenue` (default) - AE / new-logo deal flow
          - `prospects_meeting` - SDR meeting-booking flow
          - `customers_revenue` - CSM expansion / renewal flow

        `motion_hint` is an optional freeform steer (e.g. "enterprise SaaS,
        annual contracts, 60-day cycle"). `use_brief_only=True` (default)
        uses the pre-extracted intelligence brief; set False to read source
        docs directly (more granular, more tokens).

        On Anthropic API failure or empty global context, returns a generic
        target-appropriate fallback with `context_sources: []`.
        """
        body: dict[str, Any] = {"use_brief_only": use_brief_only, "target": target}
        if motion_hint:
            body["motion_hint"] = motion_hint
        return await safe_call_typed(
            client.post("/v1/pipelines/suggest", body=body),
            ResourceDetail.from_envelope,
            context="Suggest pipeline",
        )

    @server.tool(name=tool_name("create_pipeline_from_suggestion"), annotations=_WRITE)
    async def create_pipeline_from_suggestion(
        suggestion: dict[str, Any],
    ) -> ActionResult | str:
        """Persist a `PipelineSuggestion` (possibly edited) as a real pipeline.

        Pass the dict returned by `suggest_pipeline_from_context` (or a
        hand-crafted equivalent). Validates evidence keys against the canonical
        library, sanitizes channel scripts, and creates the pipeline + stages
        atomically.

        No dedup: every call creates a new pipeline. The agent is responsible
        for not posting the same draft twice.

        Required suggestion shape:
        ```
        {
          "name": "Sales Pipeline",
          "rationale": "...",
          "context_sources": ["brand_brief", "value_props"],
          "stages": [
            {"name": "...", "probability": 20, "stage_type": "open",
             "color": "#3B82F6", "required_elements": [...],
             "recommended_elements": [...], "channel_scripts": {...},
             "rationale": "..."}
          ]
        }
        ```
        """
        return await safe_call_typed(
            client.post("/v1/pipelines/from-suggestion", body=suggestion),
            ActionResult.from_envelope,
            context="Create pipeline from suggestion",
        )
