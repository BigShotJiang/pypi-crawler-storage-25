"""Unit tests for HTML app surface #51 — inbox thread draft viewer.

Covers:
  - _inbox_draft_clip: empty/whitespace/clip/escape
  - _inbox_draft_channel_norm / _inbox_draft_channel_palette
  - _inbox_draft_status_palette: READY / HTML ONLY / PLAIN ONLY / EMPTY
  - _inbox_draft_strip_tags: tag stripping / entity unescape / clip
  - _inbox_draft_latest_inbound / _inbox_draft_contact_display
  - _inbox_draft_stat_card: uniform border + accent palette
  - _render_inbox_draft_empty_state_html: 3 modes
  - render_inbox_draft_html: full rendering paths
  - render_inbox_draft_text_fallback
  - smoke tests with realistic data
  - regression locks: no single-side accent borders, no legacy hexes,
    drill-up does NOT list self, manage block does NOT list self.
"""

from __future__ import annotations

import pytest

from g8_mcp_server.app_renderer import (
    _G8_ACCENT_BG,
    _G8_BORDER,
    _G8_CARD_BG,
    _G8_MUTED_BG,
    _G8_PRIMARY,
    _G8_TEXT,
    _G8_TEXT_MUTED,
    _G8_WARNING_BG,
    _G8_WARNING_FG,
    _INBOX_DRAFT_CHANNELS_POSITIVE,
    _INBOX_DRAFT_CHANNELS_PRIMARY,
    _INBOX_DRAFT_CHANNELS_WARNING,
    _MAX_INBOX_DRAFT_CONTACT_LEN,
    _MAX_INBOX_DRAFT_CONTENT_LEN,
    _MAX_INBOX_DRAFT_LAST_INBOUND_LEN,
    _MAX_INBOX_DRAFT_REPLY_ID_LEN,
    _MAX_INBOX_DRAFT_SUBJECT_LEN,
    _inbox_draft_channel_norm,
    _inbox_draft_channel_palette,
    _inbox_draft_clip,
    _inbox_draft_contact_display,
    _inbox_draft_latest_inbound,
    _inbox_draft_stat_card,
    _inbox_draft_status_palette,
    _inbox_draft_strip_tags,
    _render_inbox_draft_empty_state_html,
    render_inbox_draft_html,
    render_inbox_draft_text_fallback,
)


# ==================================================================== #
# _inbox_draft_clip                                                    #
# ==================================================================== #


class TestClip:
    def test_none_returns_empty(self):
        assert _inbox_draft_clip(None, 10) == ""

    def test_non_string_returns_empty(self):
        assert _inbox_draft_clip(123, 10) == ""
        assert _inbox_draft_clip(["a"], 10) == ""

    def test_whitespace_only_returns_empty(self):
        assert _inbox_draft_clip("", 10) == ""
        assert _inbox_draft_clip("   ", 10) == ""
        assert _inbox_draft_clip("\n\t", 10) == ""

    def test_short_string_unchanged(self):
        assert _inbox_draft_clip("hi", 10) == "hi"

    def test_clip_adds_ellipsis(self):
        assert _inbox_draft_clip("abcdefgh", 5) == "abcd…"

    def test_html_escape(self):
        assert _inbox_draft_clip("<script>", 20) == "&lt;script&gt;"

    def test_xss_payload(self):
        assert "<script>" not in _inbox_draft_clip("<script>alert(1)</script>", 100)


# ==================================================================== #
# _inbox_draft_channel_norm                                            #
# ==================================================================== #


class TestChannelNorm:
    def test_lowercase(self):
        assert _inbox_draft_channel_norm("EMAIL") == "email"
        assert _inbox_draft_channel_norm("  SMS  ") == "sms"

    def test_empty_returns_unknown(self):
        assert _inbox_draft_channel_norm("") == "unknown"
        assert _inbox_draft_channel_norm("   ") == "unknown"

    def test_none_returns_unknown(self):
        assert _inbox_draft_channel_norm(None) == "unknown"

    def test_non_string_returns_unknown(self):
        assert _inbox_draft_channel_norm(5) == "unknown"
        assert _inbox_draft_channel_norm([]) == "unknown"

    def test_already_lower(self):
        assert _inbox_draft_channel_norm("linkedin") == "linkedin"


# ==================================================================== #
# _inbox_draft_channel_palette                                         #
# ==================================================================== #


class TestChannelPalette:
    def test_email_positive(self):
        bg, fg, label = _inbox_draft_channel_palette("email")
        assert bg == "#d1fae5"
        assert fg == "#059669"
        assert label == "EMAIL"

    def test_sms_primary(self):
        bg, fg, label = _inbox_draft_channel_palette("sms")
        assert bg == _G8_ACCENT_BG
        assert fg == _G8_PRIMARY
        assert label == "SMS"

    def test_linkedin_warning(self):
        bg, fg, label = _inbox_draft_channel_palette("linkedin")
        assert bg == _G8_WARNING_BG
        assert fg == _G8_WARNING_FG
        assert label == "LINKEDIN"

    def test_unknown_muted(self):
        bg, fg, label = _inbox_draft_channel_palette("whatsapp")
        assert bg == _G8_MUTED_BG
        assert fg == _G8_TEXT_MUTED
        assert label == "WHATSAPP"

    def test_none_muted(self):
        bg, fg, label = _inbox_draft_channel_palette(None)
        assert bg == _G8_MUTED_BG
        assert fg == _G8_TEXT_MUTED
        assert label == "UNKNOWN"

    def test_case_insensitive(self):
        bg, fg, label = _inbox_draft_channel_palette("EMAIL")
        assert fg == "#059669"
        assert label == "EMAIL"

    def test_channel_tuples_correct(self):
        assert "email" in _INBOX_DRAFT_CHANNELS_POSITIVE
        assert "sms" in _INBOX_DRAFT_CHANNELS_PRIMARY
        assert "linkedin" in _INBOX_DRAFT_CHANNELS_WARNING


# ==================================================================== #
# _inbox_draft_status_palette                                          #
# ==================================================================== #


class TestStatusPalette:
    def test_both_present_ready(self):
        bg, fg, label = _inbox_draft_status_palette(has_plain=True, has_html=True)
        assert label == "READY"
        assert fg == "#059669"

    def test_html_only_warning(self):
        bg, fg, label = _inbox_draft_status_palette(has_plain=False, has_html=True)
        assert label == "HTML ONLY"
        assert fg == _G8_WARNING_FG

    def test_plain_only_primary(self):
        bg, fg, label = _inbox_draft_status_palette(has_plain=True, has_html=False)
        assert label == "PLAIN ONLY"
        assert fg == _G8_PRIMARY

    def test_empty_muted(self):
        bg, fg, label = _inbox_draft_status_palette(has_plain=False, has_html=False)
        assert label == "EMPTY"
        assert fg == _G8_TEXT_MUTED


# ==================================================================== #
# _inbox_draft_strip_tags                                              #
# ==================================================================== #


class TestStripTags:
    def test_none_returns_empty(self):
        assert _inbox_draft_strip_tags(None, 100) == ""

    def test_non_string_returns_empty(self):
        assert _inbox_draft_strip_tags(123, 100) == ""
        assert _inbox_draft_strip_tags({"x": 1}, 100) == ""

    def test_empty_returns_empty(self):
        assert _inbox_draft_strip_tags("", 100) == ""
        assert _inbox_draft_strip_tags("   ", 100) == ""

    def test_strip_p_tags(self):
        out = _inbox_draft_strip_tags("<p>Hello</p><p>World</p>", 100)
        # Tag-stripped: Hello\nWorld
        assert "Hello" in out
        assert "World" in out
        assert "<p>" not in out

    def test_br_tags_become_newlines(self):
        out = _inbox_draft_strip_tags("line1<br>line2<br/>line3", 100)
        assert "line1" in out
        assert "line2" in out
        assert "line3" in out
        assert "<br" not in out

    def test_entity_unescape(self):
        out = _inbox_draft_strip_tags("<p>Hi &amp; bye</p>", 100)
        # After strip and unescape, '&' is visible, then html.escape
        # re-escapes it for safe embedding → '&amp;' in output.
        assert "&amp;" in out
        assert "Hi" in out
        assert "bye" in out

    def test_xss_strip(self):
        # Script tag must not survive.
        out = _inbox_draft_strip_tags("<script>alert(1)</script>text", 100)
        assert "<script>" not in out
        # The word "alert" is stripped along with its tag siblings —
        # we just verify the raw <script> tag doesn't survive and
        # the bare text at the end does.
        assert "text" in out

    def test_clip_long_content(self):
        long = "a" * 500
        out = _inbox_draft_strip_tags(long, 50)
        assert len(out) <= 50
        assert out.endswith("…")

    def test_collapse_excessive_blanks(self):
        # 5 consecutive paragraph breaks → at most 2 blanks.
        content = "A<br><br><br><br><br><br>B"
        out = _inbox_draft_strip_tags(content, 100)
        assert out.count("\n\n\n") == 0
        assert "A" in out
        assert "B" in out

    def test_all_block_tags_stripped(self):
        content = "<div>D</div><h1>H</h1><li>L</li><blockquote>Q</blockquote>"
        out = _inbox_draft_strip_tags(content, 100)
        assert "<" not in out
        for ch in ("D", "H", "L", "Q"):
            assert ch in out


# ==================================================================== #
# _inbox_draft_latest_inbound                                          #
# ==================================================================== #


class TestLatestInbound:
    def test_none_returns_none(self):
        assert _inbox_draft_latest_inbound(None) is None

    def test_non_dict_returns_none(self):
        assert _inbox_draft_latest_inbound("not a dict") is None

    def test_no_messages_returns_none(self):
        assert _inbox_draft_latest_inbound({}) is None
        assert _inbox_draft_latest_inbound({"messages": None}) is None

    def test_non_list_messages_returns_none(self):
        assert _inbox_draft_latest_inbound({"messages": "not a list"}) is None

    def test_finds_user_responder(self):
        thread = {
            "messages": [
                {"responder": "AI", "content": "auto reply"},
                {"responder": "USER", "content": "their message"},
            ]
        }
        out = _inbox_draft_latest_inbound(thread)
        assert out is not None
        assert out["content"] == "their message"

    def test_finds_inbound_direction_alias(self):
        thread = {
            "messages": [
                {"responder": "AI", "content": "drafted"},
                {"direction": "received", "content": "their reply"},
            ]
        }
        out = _inbox_draft_latest_inbound(thread)
        assert out is not None
        assert out["content"] == "their reply"

    def test_all_outbound_returns_none(self):
        thread = {
            "messages": [
                {"responder": "AI", "content": "a"},
                {"responder": "OTHER", "content": "b"},
            ]
        }
        assert _inbox_draft_latest_inbound(thread) is None


# ==================================================================== #
# _inbox_draft_contact_display                                         #
# ==================================================================== #


class TestContactDisplay:
    def test_none_returns_empty(self):
        assert _inbox_draft_contact_display(None) == ("", "", "")

    def test_non_dict_contact(self):
        assert _inbox_draft_contact_display({"contact": "not a dict"}) == ("", "", "")

    def test_missing_contact(self):
        assert _inbox_draft_contact_display({}) == ("", "", "")

    def test_full_name_preferred(self):
        out = _inbox_draft_contact_display(
            {"contact": {"first_name": "Jane", "last_name": "Doe", "email": "j@e.com", "company": "X"}}
        )
        assert out == ("Jane Doe", "j@e.com", "X")

    def test_name_fallback(self):
        out = _inbox_draft_contact_display(
            {"contact": {"name": "Just One", "email": "j@e.com"}}
        )
        assert out == ("Just One", "j@e.com", "")

    def test_email_as_display_when_no_name(self):
        out = _inbox_draft_contact_display(
            {"contact": {"email": "only@email.com"}}
        )
        assert out == ("only@email.com", "only@email.com", "")


# ==================================================================== #
# _inbox_draft_stat_card                                               #
# ==================================================================== #


class TestStatCard:
    def test_uniform_border_not_single_side(self):
        html_out = _inbox_draft_stat_card("L", "V")
        # Ensure we don't have a single-side colored border.
        assert "border-left:" not in html_out
        assert "border-top:" not in html_out
        assert "border-right:" not in html_out
        assert "border-bottom:" not in html_out
        assert f"border:1px solid {_G8_BORDER}" in html_out

    def test_primary_accent(self):
        html_out = _inbox_draft_stat_card("L", "V", accent="primary")
        assert _G8_PRIMARY in html_out

    def test_positive_accent(self):
        html_out = _inbox_draft_stat_card("L", "V", accent="positive")
        assert "#059669" in html_out

    def test_destructive_accent(self):
        html_out = _inbox_draft_stat_card("L", "V", accent="destructive")
        assert "#ca3214" in html_out

    def test_warning_accent(self):
        html_out = _inbox_draft_stat_card("L", "V", accent="warning")
        assert _G8_WARNING_FG in html_out

    def test_default_text_accent(self):
        html_out = _inbox_draft_stat_card("L", "V")
        assert _G8_TEXT in html_out

    def test_html_escape_in_label_and_value(self):
        html_out = _inbox_draft_stat_card("<l>", "<v>")
        assert "<l>" not in html_out
        assert "<v>" not in html_out
        assert "&lt;l&gt;" in html_out
        assert "&lt;v&gt;" in html_out


# ==================================================================== #
# _render_inbox_draft_empty_state_html                                 #
# ==================================================================== #


class TestEmptyState:
    def test_empty_draft_mode(self):
        html_out = _render_inbox_draft_empty_state_html("t_abc", "empty_draft")
        assert "Draft is empty" in html_out
        assert "t_abc" in html_out
        # primary-tint background
        assert _G8_ACCENT_BG in html_out
        assert _G8_PRIMARY in html_out

    def test_unavailable_mode(self):
        html_out = _render_inbox_draft_empty_state_html("t_abc", "unavailable")
        assert "Draft not available" in html_out
        assert "t_abc" in html_out

    def test_thread_not_found_mode(self):
        html_out = _render_inbox_draft_empty_state_html("t_abc", "thread_not_found")
        assert "Thread not found" in html_out
        assert "t_abc" in html_out

    def test_xss_escape_in_reply_id(self):
        html_out = _render_inbox_draft_empty_state_html("<script>", "empty_draft")
        assert "<script>" not in html_out
        assert "&lt;script&gt;" in html_out

    def test_empty_reply_id_shows_unknown(self):
        html_out = _render_inbox_draft_empty_state_html("", "unavailable")
        assert "(unknown)" in html_out


# ==================================================================== #
# render_inbox_draft_html                                              #
# ==================================================================== #


class TestRenderHtml:
    def test_both_none_unavailable(self):
        html_out = render_inbox_draft_html(draft=None, thread=None, reply_id="t_1")
        assert "Draft not available" in html_out

    def test_draft_non_dict_empty_draft(self):
        # A non-dict draft is treated as missing / unstarted.
        html_out = render_inbox_draft_html(draft="garbage", thread={}, reply_id="t_1")
        assert "Draft is empty" in html_out

    def test_draft_empty_content_and_plain(self):
        html_out = render_inbox_draft_html(
            draft={"content": "", "plain_content": "", "credits_charged": 0},
            thread={},
            reply_id="t_1",
        )
        assert "Draft is empty" in html_out

    def test_ready_status_chip_rendered(self):
        draft = {"content": "<p>Hi</p>", "plain_content": "Hi", "credits_charged": 1}
        html_out = render_inbox_draft_html(draft=draft, thread={}, reply_id="t_1")
        assert "READY" in html_out

    def test_html_only_status_chip(self):
        draft = {"content": "<p>Hi</p>", "plain_content": "", "credits_charged": 1}
        html_out = render_inbox_draft_html(draft=draft, thread={}, reply_id="t_1")
        assert "HTML ONLY" in html_out

    def test_plain_only_status_chip(self):
        draft = {"content": "", "plain_content": "Hi", "credits_charged": 1}
        html_out = render_inbox_draft_html(draft=draft, thread={}, reply_id="t_1")
        assert "PLAIN ONLY" in html_out

    def test_channel_chip_rendered(self):
        draft = {"content": "x", "plain_content": "y"}
        thread = {"channel": "email"}
        html_out = render_inbox_draft_html(draft=draft, thread=thread, reply_id="t_1")
        assert "EMAIL" in html_out

    def test_doctype_present(self):
        draft = {"content": "x", "plain_content": "y"}
        html_out = render_inbox_draft_html(draft=draft, thread={}, reply_id="t_1")
        assert "<!DOCTYPE html>" in html_out
        assert "</html>" in html_out

    def test_stat_cards_show_sizes(self):
        draft = {"content": "<p>hi</p>", "plain_content": "hi", "credits_charged": 3}
        html_out = render_inbox_draft_html(draft=draft, thread={}, reply_id="t_1")
        assert "HTML size" in html_out
        assert "Plain size" in html_out
        assert "Channel" in html_out
        assert "Credits" in html_out
        # credits value
        assert ">3<" in html_out

    def test_subject_in_context(self):
        draft = {"content": "x", "plain_content": "y"}
        thread = {"channel": "email", "subject": "Re: Meeting follow-up"}
        html_out = render_inbox_draft_html(draft=draft, thread=thread, reply_id="t_1")
        assert "Re: Meeting follow-up" in html_out
        assert "Subject:" in html_out

    def test_contact_in_context(self):
        draft = {"content": "x", "plain_content": "y"}
        thread = {
            "contact": {"first_name": "Jane", "last_name": "Doe", "email": "j@e.com"}
        }
        html_out = render_inbox_draft_html(draft=draft, thread=thread, reply_id="t_1")
        assert "Jane Doe" in html_out
        assert "j@e.com" in html_out

    def test_latest_inbound_excerpt(self):
        draft = {"content": "x", "plain_content": "y"}
        thread = {
            "messages": [
                {"responder": "AI", "content": "auto"},
                {
                    "responder": "USER",
                    "content": "<p>Quick question about pricing</p>",
                    "from_address": "c@corp.com",
                    "date": "2026-04-20T10:00:00Z",
                },
            ]
        }
        html_out = render_inbox_draft_html(draft=draft, thread=thread, reply_id="t_1")
        assert "LATEST INBOUND" in html_out
        assert "Quick question about pricing" in html_out
        assert "c@corp.com" in html_out

    def test_draft_body_prefers_plain(self):
        draft = {
            "content": "<p>HTML body</p>",
            "plain_content": "Plain body",
        }
        html_out = render_inbox_draft_html(draft=draft, thread={}, reply_id="t_1")
        assert "Plain body" in html_out
        assert "Plain-text version" in html_out

    def test_draft_body_falls_back_to_stripped_html(self):
        draft = {"content": "<p>Only HTML</p>", "plain_content": ""}
        html_out = render_inbox_draft_html(draft=draft, thread={}, reply_id="t_1")
        assert "Only HTML" in html_out
        assert "HTML stripped to plain text" in html_out
        assert "<p>" not in html_out.split("</head>", 1)[1].split(
            "Draft body</h2>", 1
        )[1]

    def test_xss_in_draft_content(self):
        draft = {"content": "<script>alert(1)</script>", "plain_content": ""}
        html_out = render_inbox_draft_html(draft=draft, thread={}, reply_id="t_1")
        # Raw script tag must not appear.
        assert "<script>alert(1)</script>" not in html_out

    def test_xss_in_plain_content(self):
        draft = {"content": "", "plain_content": "<script>alert(1)</script>"}
        html_out = render_inbox_draft_html(draft=draft, thread={}, reply_id="t_1")
        assert "<script>alert(1)</script>" not in html_out
        assert "&lt;script&gt;" in html_out

    def test_xss_in_subject(self):
        draft = {"content": "x", "plain_content": "y"}
        thread = {"subject": "<script>bad</script>"}
        html_out = render_inbox_draft_html(draft=draft, thread=thread, reply_id="t_1")
        assert "<script>bad</script>" not in html_out

    def test_xss_in_reply_id(self):
        draft = {"content": "x", "plain_content": "y"}
        html_out = render_inbox_draft_html(draft=draft, thread={}, reply_id="<script>")
        assert "<script>" not in html_out

    def test_drill_up_does_NOT_list_self(self):
        """Regression lock: manage block must not self-reference."""
        draft = {"content": "x", "plain_content": "y"}
        html_out = render_inbox_draft_html(draft=draft, thread={}, reply_id="t_xyz")
        # Find the Manage draft block.
        manage_block = html_out.split("Manage draft</h2>", 1)[1].split("</div>", 1)[0]
        assert "g8://inbox/threads/t_xyz/draft" not in manage_block

    def test_drill_up_points_at_siblings(self):
        draft = {"content": "x", "plain_content": "y"}
        html_out = render_inbox_draft_html(draft=draft, thread={}, reply_id="t_x")
        assert "g8://inbox/threads/t_x" in html_out
        assert "g8://inbox/dashboard" in html_out

    def test_drill_up_points_at_write_endpoints(self):
        draft = {"content": "x", "plain_content": "y"}
        html_out = render_inbox_draft_html(draft=draft, thread={}, reply_id="t_x")
        assert "POST /inbox/t_x/send" in html_out
        assert "POST /inbox/t_x/assign" in html_out
        assert "POST /inbox/t_x/tag" in html_out

    def test_no_single_side_accent_borders(self):
        """Regression lock: no single-side colored borders."""
        draft = {"content": "x", "plain_content": "y"}
        html_out = render_inbox_draft_html(
            draft=draft, thread={"subject": "X"}, reply_id="t_1"
        )
        assert "border-left:3px" not in html_out
        assert "border-left:4px" not in html_out
        assert "border-top:3px solid #" not in html_out
        # The primary-tint edges for messages use a proper 1px all-around border.
        # Anything that sets a single-side color accent is a tell.

    def test_no_legacy_accent_hexes(self):
        """Regression lock: no non-graph8 accent hexes in the output."""
        draft = {"content": "x", "plain_content": "y"}
        thread = {"channel": "email"}
        html_out = render_inbox_draft_html(draft=draft, thread=thread, reply_id="t_1")
        for legacy in ("#6366f1", "#4f46e5", "#10b981", "#ec4899", "#dc2626", "#16a34a"):
            assert legacy not in html_out, (
                f"Legacy accent hex {legacy} leaked into render"
            )

    def test_4_stat_cards_present(self):
        draft = {"content": "x", "plain_content": "y"}
        html_out = render_inbox_draft_html(draft=draft, thread={}, reply_id="t_1")
        # 4 stat cards → at least 4 grid children; count labels.
        for label in ("Channel", "HTML size", "Plain size", "Credits"):
            assert label in html_out

    def test_long_draft_overflow_truncates(self):
        long_plain = "x" * (_MAX_INBOX_DRAFT_CONTENT_LEN + 500)
        draft = {"content": "", "plain_content": long_plain}
        html_out = render_inbox_draft_html(draft=draft, thread={}, reply_id="t_1")
        assert "Preview truncated" in html_out


# ==================================================================== #
# render_inbox_draft_text_fallback                                     #
# ==================================================================== #


class TestTextFallback:
    def test_both_none(self):
        out = render_inbox_draft_text_fallback(
            draft=None, thread=None, reply_id="t_1"
        )
        assert "Could not fetch draft" in out

    def test_draft_non_dict(self):
        out = render_inbox_draft_text_fallback(
            draft="x", thread={}, reply_id="t_1"
        )
        assert "No draft generated yet" in out

    def test_empty_draft(self):
        out = render_inbox_draft_text_fallback(
            draft={"content": "", "plain_content": ""}, thread={}, reply_id="t_1"
        )
        assert "Draft is empty" in out

    def test_full_render(self):
        draft = {"content": "<p>x</p>", "plain_content": "x", "credits_charged": 2}
        thread = {"channel": "email", "subject": "Hi", "status": "open"}
        out = render_inbox_draft_text_fallback(
            draft=draft, thread=thread, reply_id="t_1"
        )
        assert out.startswith("# Inbox draft")
        assert "**Channel:** email" in out
        assert "**Credits charged:** 2" in out
        assert "**Thread status:** open" in out
        assert "## Thread context" in out
        assert "## Draft body" in out
        assert "## Manage draft" in out

    def test_draft_body_code_fence(self):
        draft = {"content": "", "plain_content": "Hello"}
        out = render_inbox_draft_text_fallback(
            draft=draft, thread={}, reply_id="t_1"
        )
        assert "```" in out
        assert "Hello" in out

    def test_manage_block_does_not_list_self(self):
        """Regression lock: text manage block must not self-reference."""
        draft = {"content": "x", "plain_content": "y"}
        out = render_inbox_draft_text_fallback(
            draft=draft, thread={}, reply_id="t_abc"
        )
        manage_block = out.split("## Manage draft", 1)[1]
        assert "g8://inbox/threads/t_abc/draft" not in manage_block

    def test_manage_block_points_at_siblings(self):
        draft = {"content": "x", "plain_content": "y"}
        out = render_inbox_draft_text_fallback(
            draft=draft, thread={}, reply_id="t_x"
        )
        assert "POST /inbox/t_x/send" in out
        assert "GET /inbox/t_x/draft" in out
        assert "g8://inbox/threads/t_x" in out
        assert "g8://inbox/dashboard" in out

    def test_contact_in_context(self):
        draft = {"content": "x", "plain_content": "y"}
        thread = {"contact": {"first_name": "Jane", "last_name": "Doe", "email": "j@e.com", "company": "X"}}
        out = render_inbox_draft_text_fallback(
            draft=draft, thread=thread, reply_id="t_1"
        )
        assert "Jane Doe" in out
        assert "<j@e.com>" in out
        assert "(X)" in out

    def test_latest_inbound_in_context(self):
        draft = {"content": "x", "plain_content": "y"}
        thread = {
            "messages": [
                {
                    "responder": "USER",
                    "content": "<p>Quick Q about pricing</p>",
                    "from_address": "c@c.com",
                    "date": "2026-04-20",
                }
            ]
        }
        out = render_inbox_draft_text_fallback(
            draft=draft, thread=thread, reply_id="t_1"
        )
        assert "Latest inbound" in out
        assert "Quick Q about pricing" in out
        assert "c@c.com" in out

    def test_long_body_truncation(self):
        long = "y" * (_MAX_INBOX_DRAFT_CONTENT_LEN + 100)
        draft = {"content": "", "plain_content": long}
        out = render_inbox_draft_text_fallback(
            draft=draft, thread={}, reply_id="t_1"
        )
        assert "preview truncated" in out

    def test_long_reply_id_clipped(self):
        out = render_inbox_draft_text_fallback(
            draft={"content": "x", "plain_content": "y"},
            thread={},
            reply_id="t_" + "z" * 200,
        )
        # ID should appear clipped (≤ cap + ellipsis).
        # Header line has the backticked id.
        first = out.splitlines()[0]
        assert "…" in first

    def test_trailing_newline(self):
        out = render_inbox_draft_text_fallback(
            draft={"content": "x", "plain_content": "y"},
            thread={},
            reply_id="t_1",
        )
        assert out.endswith("\n")


# ==================================================================== #
# Smoke tests                                                           #
# ==================================================================== #


class TestSmoke:
    def test_realistic_email_draft(self):
        draft = {
            "content": "<p>Hi Sarah,</p><p>Thanks for your question about pricing. "
            "Our Pro plan is $99/mo and includes unlimited contacts.</p><p>Happy to "
            "set up a 15-minute demo if it'd help.</p><p>Best,<br>Thomas</p>",
            "plain_content": "Hi Sarah,\n\nThanks for your question about pricing. "
            "Our Pro plan is $99/mo and includes unlimited contacts.\n\nHappy to "
            "set up a 15-minute demo if it'd help.\n\nBest,\nThomas",
            "credits_charged": 2,
        }
        thread = {
            "id": "t_abc123",
            "channel": "email",
            "subject": "Re: Pricing question",
            "status": "open",
            "contact": {
                "first_name": "Sarah",
                "last_name": "Jones",
                "email": "sarah@acme.co",
                "company": "Acme Co",
            },
            "messages": [
                {
                    "responder": "USER",
                    "content": "<p>Hi, what's your pricing for 5k contacts?</p>",
                    "from_address": "sarah@acme.co",
                    "date": "2026-04-20T10:00:00Z",
                },
            ],
            "tags": [],
            "assignees": [],
        }

        # HTML renders with all elements.
        html_out = render_inbox_draft_html(
            draft=draft, thread=thread, reply_id="t_abc123"
        )
        assert "<!DOCTYPE html>" in html_out
        assert "EMAIL" in html_out
        assert "READY" in html_out
        assert "Sarah Jones" in html_out
        assert "sarah@acme.co" in html_out
        assert "Acme Co" in html_out
        assert "Re: Pricing question" in html_out
        assert "5k contacts" in html_out  # latest inbound excerpt
        assert "Thanks for your question about pricing" in html_out
        assert "Plain-text version" in html_out
        # Credits is 2.
        assert ">2<" in html_out
        # Drill-up points at siblings, not self.
        assert "g8://inbox/threads/t_abc123" in html_out
        manage_block = html_out.split("Manage draft</h2>", 1)[1].split("</div>", 1)[0]
        assert "g8://inbox/threads/t_abc123/draft" not in manage_block

        # Text fallback mirrors the structure.
        text_out = render_inbox_draft_text_fallback(
            draft=draft, thread=thread, reply_id="t_abc123"
        )
        assert text_out.startswith("# Inbox draft")
        assert "**Channel:** email" in text_out
        assert "**Credits charged:** 2" in text_out
        assert "## Thread context" in text_out
        assert "Sarah Jones" in text_out
        assert "Latest inbound" in text_out
        assert "## Draft body" in text_out
        assert "```" in text_out
        assert "## Manage draft" in text_out

    def test_linkedin_html_only_draft(self):
        draft = {
            "content": "<p>Hi Sarah, thanks for connecting!</p>",
            "plain_content": "",
            "credits_charged": 1,
        }
        thread = {
            "id": "li_xyz",
            "channel": "linkedin",
            "contact": {"name": "Sarah Jones"},
        }
        html_out = render_inbox_draft_html(
            draft=draft, thread=thread, reply_id="li_xyz"
        )
        assert "LINKEDIN" in html_out
        assert "HTML ONLY" in html_out
        # Linkedin warning palette in channel chip.
        assert _G8_WARNING_FG in html_out
        # HTML body rendered as stripped-tag plain text.
        assert "thanks for connecting" in html_out

    def test_sms_plain_only_draft(self):
        draft = {
            "content": "",
            "plain_content": "Hi Sarah, following up on the demo",
            "credits_charged": 1,
        }
        thread = {"id": "sms_1", "channel": "sms"}
        html_out = render_inbox_draft_html(
            draft=draft, thread=thread, reply_id="sms_1"
        )
        assert "SMS" in html_out
        assert "PLAIN ONLY" in html_out
        assert "following up on the demo" in html_out
