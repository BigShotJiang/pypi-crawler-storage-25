"""Unit tests for the MCP HTML cache (upgrade 4 follow-up).

Covers:
- Cache miss invokes the render function
- Cache hit skips the render function entirely
- Empty render results are NOT cached (avoid poisoning the cache during outages)
- TTL expiry forces a re-render
- Different key suffixes cache independently (per-user isolation)
- Local fallback works when Redis is unavailable
"""

from __future__ import annotations

import time
from unittest.mock import AsyncMock

import pytest

from g8_mcp_server import app_html_cache
from g8_mcp_server.app_html_cache import (
    cache_key_for_api_key,
    cached_render,
    clear_local_cache,
    get_cached,
    set_cached,
)


@pytest.fixture(autouse=True)
def _clean_cache():
    """Every test gets a fresh in-memory cache."""
    clear_local_cache()
    yield
    clear_local_cache()


@pytest.fixture
def _no_redis(monkeypatch):
    """Force Redis to be unavailable — tests pure in-memory behavior."""
    async def _none():
        return None

    monkeypatch.setattr(app_html_cache, "_redis_client", _none)


# ---------------------------------------------------------------------------
# cache_key_for_api_key
# ---------------------------------------------------------------------------


class TestCacheKeyForApiKey:
    def test_empty_key_is_anonymous(self):
        assert cache_key_for_api_key("") == "anonymous"
        assert cache_key_for_api_key(None) == "anonymous"  # type: ignore[arg-type]

    def test_stable_for_same_key(self):
        a = cache_key_for_api_key("g8_live_xxxxxxxxxxxx")
        b = cache_key_for_api_key("g8_live_xxxxxxxxxxxx")
        assert a == b
        assert len(a) == 16

    def test_different_keys_produce_different_suffixes(self):
        a = cache_key_for_api_key("key_a")
        b = cache_key_for_api_key("key_b")
        assert a != b

    def test_never_leaks_plaintext(self):
        """Hashed suffix must not contain the original API key substring."""
        key = "g8_super_secret_abcdef123456"
        suffix = cache_key_for_api_key(key)
        assert "secret" not in suffix
        assert "abcdef" not in suffix


# ---------------------------------------------------------------------------
# cached_render — happy path
# ---------------------------------------------------------------------------


class TestCachedRender:
    async def test_miss_invokes_render(self, _no_redis):
        fn = AsyncMock(return_value="<html>fresh</html>")
        result = await cached_render(
            cache_prefix="test_surface",
            key_suffix="abc",
            fetch_and_render=fn,
        )
        assert result == "<html>fresh</html>"
        fn.assert_called_once()

    async def test_hit_skips_render(self, _no_redis):
        fn = AsyncMock(return_value="<html>first</html>")
        # First call — miss → invokes
        await cached_render(
            cache_prefix="test_surface",
            key_suffix="abc",
            fetch_and_render=fn,
        )
        fn.reset_mock()

        # Second call with same key — hit → does NOT invoke
        fn.return_value = "<html>second</html>"
        result = await cached_render(
            cache_prefix="test_surface",
            key_suffix="abc",
            fetch_and_render=fn,
        )
        assert result == "<html>first</html>"
        fn.assert_not_called()

    async def test_different_suffixes_cache_independently(self, _no_redis):
        fn_a = AsyncMock(return_value="<html>A</html>")
        fn_b = AsyncMock(return_value="<html>B</html>")

        a = await cached_render(
            cache_prefix="test_surface",
            key_suffix="user_a",
            fetch_and_render=fn_a,
        )
        b = await cached_render(
            cache_prefix="test_surface",
            key_suffix="user_b",
            fetch_and_render=fn_b,
        )
        assert a == "<html>A</html>"
        assert b == "<html>B</html>"
        fn_a.assert_called_once()
        fn_b.assert_called_once()

    async def test_different_prefixes_cache_independently(self, _no_redis):
        fn_html = AsyncMock(return_value="<html>HTML</html>")
        fn_text = AsyncMock(return_value="Plaintext")

        html = await cached_render(
            cache_prefix="ad_images_html",
            key_suffix="campaign_1",
            fetch_and_render=fn_html,
        )
        text = await cached_render(
            cache_prefix="ad_images_text",
            key_suffix="campaign_1",
            fetch_and_render=fn_text,
        )
        assert html == "<html>HTML</html>"
        assert text == "Plaintext"

    async def test_empty_render_not_cached(self, _no_redis):
        """Falsy render result (empty string) must not poison the cache."""
        fn = AsyncMock(side_effect=["", "<html>retry</html>"])
        # First call returns "" — should not be cached
        first = await cached_render(
            cache_prefix="test_surface",
            key_suffix="abc",
            fetch_and_render=fn,
        )
        assert first == ""
        # Second call re-invokes fetch_and_render
        second = await cached_render(
            cache_prefix="test_surface",
            key_suffix="abc",
            fetch_and_render=fn,
        )
        assert second == "<html>retry</html>"
        assert fn.call_count == 2

    async def test_ttl_expiry_forces_rerender(self, _no_redis, monkeypatch):
        fn = AsyncMock(side_effect=["<html>first</html>", "<html>second</html>"])

        # First call with a 60s TTL — cached
        await cached_render(
            cache_prefix="test_surface",
            key_suffix="abc",
            fetch_and_render=fn,
            ttl=60,
        )

        # Warp time forward past TTL
        real_time = time.time
        monkeypatch.setattr(app_html_cache.time, "time", lambda: real_time() + 120)

        # Second call should miss (expired) and re-render
        result = await cached_render(
            cache_prefix="test_surface",
            key_suffix="abc",
            fetch_and_render=fn,
            ttl=60,
        )
        assert result == "<html>second</html>"
        assert fn.call_count == 2


# ---------------------------------------------------------------------------
# get_cached / set_cached — low-level
# ---------------------------------------------------------------------------


class TestGetSetCached:
    async def test_miss_returns_none(self, _no_redis):
        assert await get_cached("test_surface", "missing") is None

    async def test_set_then_get(self, _no_redis):
        await set_cached("test_surface", "abc", "<html>value</html>", ttl=60)
        got = await get_cached("test_surface", "abc")
        assert got == "<html>value</html>"

    async def test_empty_value_not_stored(self, _no_redis):
        """Don't poison the cache with an empty backend response."""
        await set_cached("test_surface", "abc", "", ttl=60)
        assert await get_cached("test_surface", "abc") is None

    async def test_colon_in_suffix_sanitized(self, _no_redis):
        """Colons in user-supplied suffixes shouldn't create fake prefix levels."""
        await set_cached("test_surface", "user:abc:def", "<html>v</html>", ttl=60)
        got = await get_cached("test_surface", "user:abc:def")
        assert got == "<html>v</html>"

    async def test_ttl_zero_rejected_for_set_but_get_still_works(self, _no_redis):
        """Non-zero TTL required — zero means immediate expiry; we accept it."""
        await set_cached("test_surface", "abc", "<html>v</html>", ttl=1)
        assert await get_cached("test_surface", "abc") == "<html>v</html>"


# ---------------------------------------------------------------------------
# Redis fallback — ensure failures don't break caching
# ---------------------------------------------------------------------------


class TestRedisFallback:
    async def test_redis_failure_falls_back_to_local(self, monkeypatch):
        """If Redis raises, the local cache must still serve the value."""

        class _BrokenRedis:
            async def get(self, key):
                raise RuntimeError("redis down")

            async def setex(self, key, ttl, value):
                raise RuntimeError("redis down")

        async def _broken():
            return _BrokenRedis()

        monkeypatch.setattr(app_html_cache, "_redis_client", _broken)

        fn = AsyncMock(return_value="<html>v</html>")
        # First call — render + store in local (Redis setex fails silently)
        a = await cached_render(
            cache_prefix="test_surface",
            key_suffix="abc",
            fetch_and_render=fn,
        )
        # Second call — Redis get raises, we fall through to local cache
        b = await cached_render(
            cache_prefix="test_surface",
            key_suffix="abc",
            fetch_and_render=fn,
        )
        assert a == b == "<html>v</html>"
        fn.assert_called_once()
