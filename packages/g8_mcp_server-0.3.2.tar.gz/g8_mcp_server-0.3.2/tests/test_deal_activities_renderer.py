"""Unit tests for the Surface #70 per-deal activities renderer.

Surface: g8://deals/{deal_id}/activities  (+ .txt sibling)

Covers:
  - Empty states (None → unavailable, [] → no activities yet)
  - Header label derivation (name > title > fallback)
  - Stat cards (total / calls / emails / meetings)
  - Type breakdown chips (with count + %)
  - Timeline rendering (subject / description / outcome / next-steps /
    date / owner / subtype / status / duration / contact / source chips)
  - Drill-up links (profile / pipeline dashboard / org-wide feed /
    backend filter) — and NOT self-referencing
  - Overflow banner when >25 activities
  - Security / regression locks (no JavaScript, no legacy hexes,
    graph8 design tokens, no single-side colored accent border, XSS
    escaping on all user-controlled fields)
  - Text fallback mirroring
"""

from __future__ import annotations

import pytest

from g8_mcp_server.app_renderer import (
    _G8_ACCENT_BG,
    _G8_BORDER,
    _G8_CARD_RADIUS,
    _G8_FONT,
    _G8_MUTED_BG,
    _G8_PRIMARY,
    _deal_activity_header_label,
    _render_deal_activities_empty_state_html,
    render_deal_activities_html,
    render_deal_activities_text_fallback,
)


_DEAL_ID = "deal_8ab27791efff40deaaaa"


def _sample_activity(**overrides) -> dict:
    base = {
        "id": "act_1",
        "activity_type": "call",
        "activity_subtype": "discovery",
        "subject": "Closing call",
        "description": "Negotiated final terms and pricing.",
        "activity_date": "2026-04-15T14:30:00",
        "duration_minutes": 90,
        "status": "completed",
        "outcome": "won",
        "next_steps": "Send signed contract.",
        "owner_id": "usr_alice",
        "owner_name": "Alice Johnson",
        "contact_id": "cont_42",
        "company_id": "comp_77",
        "deal_id": _DEAL_ID,
        "source": "hubspot",
        "external_id": "hs_7777",
    }
    base.update(overrides)
    return base


# ============================================================
# Header label helper
# ============================================================

class TestHeaderLabel:
    def test_name_preferred(self):
        out = _deal_activity_header_label(
            {"name": "Acme Q4 Renewal", "title": "Acme - Q4"}, _DEAL_ID
        )
        assert out == "Acme Q4 Renewal"

    def test_title_fallback(self):
        out = _deal_activity_header_label(
            {"title": "Acme - Q4"}, _DEAL_ID
        )
        assert out == "Acme - Q4"

    def test_id_fallback(self):
        out = _deal_activity_header_label(None, _DEAL_ID)
        assert out.startswith("Deal ")
        assert _DEAL_ID[:24] in out

    def test_empty_name_ignored(self):
        out = _deal_activity_header_label(
            {"name": "  ", "title": "Fallback"}, _DEAL_ID
        )
        assert out == "Fallback"

    def test_unknown_id_fallback(self):
        out = _deal_activity_header_label(None, "")
        assert "(unknown)" in out

    def test_long_name_clipped(self):
        out = _deal_activity_header_label({"name": "A" * 500}, _DEAL_ID)
        assert len(out) <= 140

    def test_nondict_meta_tolerated(self):
        out = _deal_activity_header_label("not-a-dict", _DEAL_ID)
        assert out.startswith("Deal ")

    def test_non_str_name_falls_through(self):
        out = _deal_activity_header_label(
            {"name": 123, "title": "Real"}, _DEAL_ID
        )
        assert out == "Real"


# ============================================================
# Empty state
# ============================================================

class TestEmptyState:
    def test_zero_activities_positive_tone(self):
        out = _render_deal_activities_empty_state_html(
            deal_id=_DEAL_ID, zero_activities=True
        )
        assert "No activities yet" in out
        assert _DEAL_ID[:64] in out
        assert _G8_PRIMARY in out
        assert _G8_ACCENT_BG in out

    def test_unavailable_muted_tone(self):
        out = _render_deal_activities_empty_state_html(
            deal_id=_DEAL_ID, zero_activities=False
        )
        assert "Activities not available" in out
        assert "GET /deals" in out

    def test_no_deal_id(self):
        out = _render_deal_activities_empty_state_html(
            deal_id="", zero_activities=True
        )
        assert "(unknown)" in out

    def test_empty_state_escapes_deal_id(self):
        evil = "<script>alert(1)</script>"
        out = _render_deal_activities_empty_state_html(
            deal_id=evil, zero_activities=False
        )
        assert "<script>" not in out
        assert "&lt;script&gt;" in out


# ============================================================
# Render edges
# ============================================================

class TestRenderHtmlEdges:
    def test_none_returns_unavailable(self):
        out = render_deal_activities_html(
            activities=None, deal_id=_DEAL_ID
        )
        assert "Activities not available" in out

    def test_empty_returns_no_activities(self):
        out = render_deal_activities_html(
            activities=[], deal_id=_DEAL_ID
        )
        assert "No activities yet" in out

    def test_non_dict_rows_skipped(self):
        out = render_deal_activities_html(
            activities=["junk", None, _sample_activity()],
            deal_id=_DEAL_ID,
        )
        assert "Closing call" in out


# ============================================================
# Header + stats
# ============================================================

class TestHeader:
    def test_name_used_in_header(self):
        out = render_deal_activities_html(
            activities=[_sample_activity()],
            deal_id=_DEAL_ID,
            deal_meta={"name": "Acme Q4"},
        )
        assert "Acme Q4" in out

    def test_deal_id_in_header(self):
        out = render_deal_activities_html(
            activities=[_sample_activity()], deal_id=_DEAL_ID
        )
        assert _DEAL_ID in out

    def test_title_fallback_in_header(self):
        out = render_deal_activities_html(
            activities=[_sample_activity()],
            deal_id=_DEAL_ID,
            deal_meta={"title": "Fallback Title"},
        )
        assert "Fallback Title" in out

    def test_fallback_header_when_no_meta(self):
        out = render_deal_activities_html(
            activities=[_sample_activity()],
            deal_id=_DEAL_ID,
            deal_meta=None,
        )
        assert "Deal " in out

    def test_deal_activities_label_shown(self):
        out = render_deal_activities_html(
            activities=[_sample_activity()],
            deal_id=_DEAL_ID,
        )
        assert "Deal activities" in out


class TestStats:
    def test_total_counts(self):
        activities = [
            _sample_activity(id="a", activity_type="call"),
            _sample_activity(id="b", activity_type="call"),
            _sample_activity(id="c", activity_type="email"),
            _sample_activity(id="d", activity_type="meeting"),
        ]
        out = render_deal_activities_html(
            activities=activities, deal_id=_DEAL_ID
        )
        assert "Total" in out
        assert "Calls" in out
        assert "Emails" in out
        assert "Meetings" in out


class TestTypeBreakdown:
    def test_type_chips_rendered(self):
        activities = [
            _sample_activity(id="a", activity_type="call"),
            _sample_activity(id="b", activity_type="email"),
            _sample_activity(id="c", activity_type="meeting"),
        ]
        out = render_deal_activities_html(
            activities=activities, deal_id=_DEAL_ID
        )
        assert "Type breakdown" in out
        assert "33%" in out

    def test_overflow_when_many_types(self):
        types = [
            "call", "email", "meeting", "note", "task",
            "sms", "linkedin", "demo", "appointment", "voicemail",
        ]
        activities = [
            _sample_activity(id=f"a{i}", activity_type=t)
            for i, t in enumerate(types)
        ]
        out = render_deal_activities_html(
            activities=activities, deal_id=_DEAL_ID
        )
        assert "more type(s)" in out


# ============================================================
# Timeline
# ============================================================

class TestTimeline:
    def test_subject(self):
        out = render_deal_activities_html(
            activities=[_sample_activity(subject="Demo call")],
            deal_id=_DEAL_ID,
        )
        assert "Demo call" in out

    def test_description(self):
        out = render_deal_activities_html(
            activities=[_sample_activity(description="Walked through pricing")],
            deal_id=_DEAL_ID,
        )
        assert "Walked through pricing" in out

    def test_outcome(self):
        out = render_deal_activities_html(
            activities=[_sample_activity(outcome="booked")],
            deal_id=_DEAL_ID,
        )
        assert "Outcome:" in out
        assert "booked" in out

    def test_next_steps(self):
        out = render_deal_activities_html(
            activities=[_sample_activity(next_steps="Send proposal")],
            deal_id=_DEAL_ID,
        )
        assert "Next:" in out
        assert "Send proposal" in out

    def test_duration_1h_30m(self):
        out = render_deal_activities_html(
            activities=[_sample_activity(duration_minutes=90)],
            deal_id=_DEAL_ID,
        )
        assert "1h 30m" in out

    def test_duration_30_min(self):
        out = render_deal_activities_html(
            activities=[_sample_activity(duration_minutes=30)],
            deal_id=_DEAL_ID,
        )
        assert "30 min" in out

    def test_owner_name(self):
        out = render_deal_activities_html(
            activities=[_sample_activity(owner_name="Bob")],
            deal_id=_DEAL_ID,
        )
        assert "Bob" in out

    def test_subtype(self):
        out = render_deal_activities_html(
            activities=[_sample_activity(activity_subtype="outbound")],
            deal_id=_DEAL_ID,
        )
        assert "outbound" in out.lower()

    def test_status(self):
        out = render_deal_activities_html(
            activities=[_sample_activity(status="completed")],
            deal_id=_DEAL_ID,
        )
        assert "status:" in out
        assert "completed" in out

    def test_source(self):
        out = render_deal_activities_html(
            activities=[_sample_activity(source="outreach")],
            deal_id=_DEAL_ID,
        )
        assert "via outreach" in out

    def test_contact_chip_present(self):
        out = render_deal_activities_html(
            activities=[_sample_activity(contact_id="cont_12345")],
            deal_id=_DEAL_ID,
        )
        assert "contact: cont_12345" in out

    def test_contact_chip_absent_when_none(self):
        out = render_deal_activities_html(
            activities=[_sample_activity(contact_id=None)],
            deal_id=_DEAL_ID,
        )
        assert "contact: " not in out

    def test_contact_chip_absent_when_empty(self):
        out = render_deal_activities_html(
            activities=[_sample_activity(contact_id="")],
            deal_id=_DEAL_ID,
        )
        assert "contact: " not in out

    def test_overflow_banner_over_25(self):
        activities = [
            _sample_activity(id=f"a{i}") for i in range(30)
        ]
        out = render_deal_activities_html(
            activities=activities, deal_id=_DEAL_ID
        )
        assert "+ 5 more activities" in out
        assert "GET /activities?deal_id=" in out
        assert "limit=200" in out

    def test_no_overflow_at_25(self):
        activities = [
            _sample_activity(id=f"a{i}") for i in range(25)
        ]
        out = render_deal_activities_html(
            activities=activities, deal_id=_DEAL_ID
        )
        assert "more activities" not in out


# ============================================================
# Drill-up
# ============================================================

class TestDrillUp:
    def test_parent_deal_link(self):
        out = render_deal_activities_html(
            activities=[_sample_activity()], deal_id=_DEAL_ID
        )
        assert f"g8://deals/{_DEAL_ID}" in out

    def test_pipeline_link(self):
        out = render_deal_activities_html(
            activities=[_sample_activity()], deal_id=_DEAL_ID
        )
        assert "g8://deals/dashboard" in out

    def test_activity_feed_link(self):
        out = render_deal_activities_html(
            activities=[_sample_activity()], deal_id=_DEAL_ID
        )
        assert "g8://activities/feed" in out

    def test_backend_filter_link(self):
        out = render_deal_activities_html(
            activities=[_sample_activity()], deal_id=_DEAL_ID
        )
        assert f"GET /activities?deal_id={_DEAL_ID}" in out

    def test_no_self_reference(self):
        out = render_deal_activities_html(
            activities=[_sample_activity()], deal_id=_DEAL_ID
        )
        assert f"g8://deals/{_DEAL_ID}/activities" not in out

    def test_manage_heading(self):
        out = render_deal_activities_html(
            activities=[_sample_activity()], deal_id=_DEAL_ID
        )
        assert "Manage this deal" in out


# ============================================================
# Regression / security
# ============================================================

class TestDesignTokens:
    def test_primary_used(self):
        out = render_deal_activities_html(
            activities=[_sample_activity()], deal_id=_DEAL_ID
        )
        assert _G8_PRIMARY in out

    def test_border_used(self):
        out = render_deal_activities_html(
            activities=[_sample_activity()], deal_id=_DEAL_ID
        )
        assert _G8_BORDER in out

    def test_font_used(self):
        out = render_deal_activities_html(
            activities=[_sample_activity()], deal_id=_DEAL_ID
        )
        assert _G8_FONT in out

    def test_card_radius(self):
        out = render_deal_activities_html(
            activities=[_sample_activity()], deal_id=_DEAL_ID
        )
        assert _G8_CARD_RADIUS in out

    def test_muted_bg_used(self):
        out = render_deal_activities_html(
            activities=[_sample_activity()], deal_id=_DEAL_ID
        )
        assert _G8_MUTED_BG in out


class TestNoLegacyHexes:
    @pytest.mark.parametrize("bad_hex", [
        "#000000", "#FF0000", "#ff0000",
    ])
    def test_no_legacy_hex(self, bad_hex):
        out = render_deal_activities_html(
            activities=[_sample_activity()], deal_id=_DEAL_ID
        )
        assert bad_hex not in out


class TestNoJavaScript:
    def test_no_script(self):
        out = render_deal_activities_html(
            activities=[_sample_activity()], deal_id=_DEAL_ID
        )
        assert "<script" not in out
        assert "javascript:" not in out

    def test_no_event_handlers(self):
        out = render_deal_activities_html(
            activities=[_sample_activity()], deal_id=_DEAL_ID
        )
        for evt in ("onclick=", "onload=", "onerror=", "onmouseover="):
            assert evt not in out


class TestNoSingleSideColoredAccent:
    def test_no_border_left_primary(self):
        out = render_deal_activities_html(
            activities=[_sample_activity()], deal_id=_DEAL_ID
        )
        assert f"border-left:3px solid {_G8_PRIMARY}" not in out
        assert f"border-left:4px solid {_G8_PRIMARY}" not in out


class TestXssEscape:
    def test_escape_subject(self):
        out = render_deal_activities_html(
            activities=[_sample_activity(subject="<img src=x onerror=alert(1)>")],
            deal_id=_DEAL_ID,
        )
        assert "<img src=x onerror=alert" not in out
        assert "&lt;img" in out

    def test_escape_description(self):
        out = render_deal_activities_html(
            activities=[_sample_activity(description="<script>x()</script>")],
            deal_id=_DEAL_ID,
        )
        assert "<script>x()" not in out
        assert "&lt;script&gt;" in out

    def test_escape_next_steps(self):
        out = render_deal_activities_html(
            activities=[_sample_activity(next_steps="<b>bold</b>")],
            deal_id=_DEAL_ID,
        )
        assert "<b>bold</b>" not in out

    def test_escape_owner(self):
        out = render_deal_activities_html(
            activities=[_sample_activity(owner_name="<svg/onload=alert(1)>")],
            deal_id=_DEAL_ID,
        )
        assert "<svg" not in out

    def test_escape_deal_id(self):
        evil_id = "<img src=x>"
        out = render_deal_activities_html(
            activities=[_sample_activity()],
            deal_id=evil_id,
        )
        assert "<img src=x>" not in out
        assert "&lt;img src=x&gt;" in out

    def test_escape_deal_name(self):
        out = render_deal_activities_html(
            activities=[_sample_activity()],
            deal_id=_DEAL_ID,
            deal_meta={"name": "<h1>XSS</h1>"},
        )
        assert "<h1>XSS" not in out

    def test_escape_outcome(self):
        out = render_deal_activities_html(
            activities=[_sample_activity(outcome="<iframe>")],
            deal_id=_DEAL_ID,
        )
        assert "<iframe>" not in out

    def test_escape_source(self):
        out = render_deal_activities_html(
            activities=[_sample_activity(source="<x>")],
            deal_id=_DEAL_ID,
        )
        assert ">via <x>" not in out


# ============================================================
# Well-formed
# ============================================================

class TestWellFormed:
    def test_doctype(self):
        out = render_deal_activities_html(
            activities=[_sample_activity()], deal_id=_DEAL_ID
        )
        assert out.startswith("<!DOCTYPE html>")

    def test_html_body(self):
        out = render_deal_activities_html(
            activities=[_sample_activity()], deal_id=_DEAL_ID
        )
        assert "<html" in out
        assert "<body" in out
        assert out.rstrip().endswith("</html>")


# ============================================================
# Text fallback
# ============================================================

class TestTextFallback:
    def test_none_unavailable(self):
        out = render_deal_activities_text_fallback(
            activities=None, deal_id=_DEAL_ID
        )
        assert "# Activities not available" in out

    def test_empty_no_activities(self):
        out = render_deal_activities_text_fallback(
            activities=[], deal_id=_DEAL_ID
        )
        assert "# No activities yet" in out

    def test_header_name(self):
        out = render_deal_activities_text_fallback(
            activities=[_sample_activity()],
            deal_id=_DEAL_ID,
            deal_meta={"name": "Acme Q4"},
        )
        assert "# Acme Q4 — activities" in out

    def test_header_fallback(self):
        out = render_deal_activities_text_fallback(
            activities=[_sample_activity()],
            deal_id=_DEAL_ID,
            deal_meta=None,
        )
        assert "# Deal " in out

    def test_stats_section(self):
        activities = [
            _sample_activity(id="a", activity_type="call"),
            _sample_activity(id="b", activity_type="email"),
        ]
        out = render_deal_activities_text_fallback(
            activities=activities, deal_id=_DEAL_ID
        )
        assert "## Stats" in out
        assert "- Total: 2" in out
        assert "- Calls: 1" in out

    def test_type_breakdown_section(self):
        out = render_deal_activities_text_fallback(
            activities=[_sample_activity()], deal_id=_DEAL_ID
        )
        assert "## Type breakdown" in out

    def test_timeline(self):
        out = render_deal_activities_text_fallback(
            activities=[_sample_activity(subject="Discovery")],
            deal_id=_DEAL_ID,
        )
        assert "## Timeline" in out
        assert "Discovery" in out

    def test_description_mirrored(self):
        out = render_deal_activities_text_fallback(
            activities=[_sample_activity(description="Demo walkthrough")],
            deal_id=_DEAL_ID,
        )
        assert "Demo walkthrough" in out

    def test_outcome_mirrored(self):
        out = render_deal_activities_text_fallback(
            activities=[_sample_activity(outcome="won")],
            deal_id=_DEAL_ID,
        )
        assert "Outcome: won" in out

    def test_next_steps_mirrored(self):
        out = render_deal_activities_text_fallback(
            activities=[_sample_activity(next_steps="Send")],
            deal_id=_DEAL_ID,
        )
        assert "Next: Send" in out

    def test_duration_mirrored(self):
        out = render_deal_activities_text_fallback(
            activities=[_sample_activity(duration_minutes=90)],
            deal_id=_DEAL_ID,
        )
        assert "duration=1h 30m" in out

    def test_status_mirrored(self):
        out = render_deal_activities_text_fallback(
            activities=[_sample_activity(status="completed")],
            deal_id=_DEAL_ID,
        )
        assert "status=completed" in out

    def test_source_mirrored(self):
        out = render_deal_activities_text_fallback(
            activities=[_sample_activity(source="outreach")],
            deal_id=_DEAL_ID,
        )
        assert "source=outreach" in out

    def test_contact_mirrored(self):
        out = render_deal_activities_text_fallback(
            activities=[_sample_activity(contact_id="cont_77")],
            deal_id=_DEAL_ID,
        )
        assert "contact=cont_77" in out

    def test_overflow_text(self):
        activities = [
            _sample_activity(id=f"a{i}") for i in range(30)
        ]
        out = render_deal_activities_text_fallback(
            activities=activities, deal_id=_DEAL_ID
        )
        assert "+ 5 more activities" in out
        assert "deal_id=" in out

    def test_manage_section(self):
        out = render_deal_activities_text_fallback(
            activities=[_sample_activity()], deal_id=_DEAL_ID
        )
        assert "## Manage this deal" in out
        assert f"`g8://deals/{_DEAL_ID}`" in out
        assert "`g8://deals/dashboard`" in out
        assert "`g8://activities/feed`" in out

    def test_text_no_self_reference(self):
        out = render_deal_activities_text_fallback(
            activities=[_sample_activity()], deal_id=_DEAL_ID
        )
        assert f"g8://deals/{_DEAL_ID}/activities" not in out

    def test_text_newline_terminated(self):
        out = render_deal_activities_text_fallback(
            activities=[_sample_activity()], deal_id=_DEAL_ID
        )
        assert out.endswith("\n")


# ============================================================
# Smoke
# ============================================================

class TestSmoke:
    def test_populated_full(self):
        activities = [
            _sample_activity(id="a1", activity_type="call", subject="Kickoff"),
            _sample_activity(
                id="a2", activity_type="email",
                subject="Pricing email",
                description=None, outcome=None, next_steps=None,
                duration_minutes=None, contact_id="cont_2",
            ),
        ]
        out = render_deal_activities_html(
            activities=activities,
            deal_id=_DEAL_ID,
            deal_meta={"name": "Acme Enterprise"},
        )
        assert "Acme Enterprise" in out
        assert "Kickoff" in out
        assert "Pricing email" in out

    def test_text_smoke(self):
        out = render_deal_activities_text_fallback(
            activities=[_sample_activity()],
            deal_id=_DEAL_ID,
            deal_meta={"name": "Acme"},
        )
        assert "# Acme — activities" in out
