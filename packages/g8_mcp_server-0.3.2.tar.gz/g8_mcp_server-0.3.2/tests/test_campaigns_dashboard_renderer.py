"""Tests for the campaigns dashboard HTML + text renderers (upgrade 4 — #6)."""

from __future__ import annotations

from g8_mcp_server import app_renderer
from g8_mcp_server.app_renderer import (
    _campaign_status_color,
    _group_campaigns_by_status,
    render_campaigns_dashboard_html,
    render_campaigns_dashboard_text_fallback,
)


def _campaign(idx: int = 0, **overrides) -> dict:
    """Build a default campaign dict matching `GET /api/v1/campaigns` shape."""
    base = {
        "id": f"c_{idx}",
        "name": f"Campaign {idx}",
        "slug": f"campaign-{idx}",
        "status": "live",
        "category": "outbound",
        "goal": "Drive meetings for enterprise SaaS buyers.",
        "target_persona": "VP of Engineering",
        "created_at": "2026-04-01",
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


class TestCampaignStatusColor:
    def test_known_statuses(self):
        # Backported to graph8 tokens 2026-04-21
        assert _campaign_status_color("live") == "#059669"  # _G8_POSITIVE_FG
        assert _campaign_status_color("active") == "#059669"
        assert _campaign_status_color("scheduled") == "#7d2df3"  # _G8_PRIMARY
        assert _campaign_status_color("draft") == "#777777"
        assert _campaign_status_color("paused") == "#a0750a"
        assert _campaign_status_color("failed") == "#b91c1c"  # _G8_DESTRUCTIVE_ON_LIGHT_FG

    def test_case_and_whitespace_tolerant(self):
        assert _campaign_status_color("LIVE") == "#059669"  # _G8_POSITIVE_FG
        assert _campaign_status_color(" Draft ") == "#777777"

    def test_unknown_returns_gray(self):
        assert _campaign_status_color("something-else") == "#777777"
        assert _campaign_status_color(None) == "#777777"
        assert _campaign_status_color("") == "#777777"

    def test_no_banned_hexes_in_status_palette(self):
        # Lock: no banned Studio hex in any status entry
        banned = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}
        from mcp_server.g8_mcp_server.app_renderer import (
            _CAMPAIGN_STATUS_COLORS,
        )
        for status, value in _CAMPAIGN_STATUS_COLORS.items():
            assert value.lower() not in banned, (
                f"status={status!r} hex={value!r} is banned"
            )


class TestGroupCampaignsByStatus:
    def test_empty(self):
        assert _group_campaigns_by_status([]) == []

    def test_single_status(self):
        result = _group_campaigns_by_status([_campaign(status="live"), _campaign(status="live")])
        assert len(result) == 1
        assert result[0][0] == "live"
        assert len(result[0][1]) == 2

    def test_ordering(self):
        """Preferred order: live → draft → paused → ended."""
        campaigns = [
            _campaign(idx=1, status="ended"),
            _campaign(idx=2, status="draft"),
            _campaign(idx=3, status="live"),
            _campaign(idx=4, status="paused"),
        ]
        result = _group_campaigns_by_status(campaigns)
        keys = [k for k, _ in result]
        # live comes first, then draft, paused, ended
        assert keys.index("live") < keys.index("draft")
        assert keys.index("draft") < keys.index("paused")
        assert keys.index("paused") < keys.index("ended")

    def test_case_normalized(self):
        result = _group_campaigns_by_status(
            [_campaign(status="LIVE"), _campaign(status="Live")]
        )
        assert len(result) == 1
        assert result[0][0] == "live"
        assert len(result[0][1]) == 2

    def test_missing_status_bucketed_as_unknown(self):
        result = _group_campaigns_by_status([_campaign(status=None), _campaign(status="")])
        assert len(result) == 1
        assert result[0][0] == "unknown"

    def test_unknown_statuses_preserve_order(self):
        """Unknown keys come AFTER preferred keys but keep their insertion order."""
        campaigns = [
            _campaign(idx=1, status="exotic1"),
            _campaign(idx=2, status="live"),
            _campaign(idx=3, status="exotic2"),
        ]
        result = _group_campaigns_by_status(campaigns)
        keys = [k for k, _ in result]
        assert keys == ["live", "exotic1", "exotic2"]


# ---------------------------------------------------------------------------
# HTML renderer
# ---------------------------------------------------------------------------


class TestRenderCampaignsDashboardHtml:
    def test_empty_renders_empty_state(self):
        html_out = render_campaigns_dashboard_html(campaigns=None)
        assert "No campaigns yet" in html_out

        html_out2 = render_campaigns_dashboard_html(campaigns=[])
        assert "No campaigns yet" in html_out2

    def test_non_list_input(self):
        html_out = render_campaigns_dashboard_html(campaigns="nope")  # type: ignore[arg-type]
        assert "No campaigns yet" in html_out

    def test_garbage_list_empty_state(self):
        html_out = render_campaigns_dashboard_html(campaigns=[None, "x", 1])  # type: ignore[list-item]
        assert "No campaigns yet" in html_out

    def test_renders_campaign_card(self):
        html_out = render_campaigns_dashboard_html(campaigns=[_campaign()])
        assert "Campaign 0" in html_out
        assert "outbound" in html_out
        assert "Drive meetings" in html_out
        assert "VP of Engineering" in html_out
        assert "campaign-0" in html_out
        assert "2026-04-01" in html_out

    def test_status_section_heading(self):
        html_out = render_campaigns_dashboard_html(
            campaigns=[_campaign(status="live"), _campaign(idx=1, status="draft")]
        )
        assert "live" in html_out
        assert "draft" in html_out

    def test_org_label(self):
        html_out = render_campaigns_dashboard_html(
            campaigns=[_campaign()], org_label="Acme Inc"
        )
        assert "Acme Inc" in html_out

    def test_missing_optional_fields(self):
        """Category/goal/persona/slug/created optional — no crashes, no phantom rows."""
        spartan = {"id": "c_0", "name": "Minimal", "status": "draft"}
        html_out = render_campaigns_dashboard_html(campaigns=[spartan])
        assert "Minimal" in html_out

    def test_missing_name_fallback(self):
        html_out = render_campaigns_dashboard_html(
            campaigns=[{"id": "c_0", "status": "live"}]
        )
        assert "Untitled campaign" in html_out

    def test_status_count_rendered(self):
        html_out = render_campaigns_dashboard_html(
            campaigns=[_campaign(idx=i) for i in range(3)]
        )
        # Summary sub line: "3 campaign(s) across 1 status group(s)"
        assert "3 campaign(s)" in html_out


class TestEscaping:
    def test_name_escaped(self):
        html_out = render_campaigns_dashboard_html(
            campaigns=[_campaign(name="<script>evil</script>")]
        )
        assert "<script>evil</script>" not in html_out
        assert "&lt;script&gt;" in html_out

    def test_goal_escaped(self):
        html_out = render_campaigns_dashboard_html(
            campaigns=[_campaign(goal="<img onerror=bad()>")]
        )
        assert "<img onerror" not in html_out

    def test_persona_escaped(self):
        html_out = render_campaigns_dashboard_html(
            campaigns=[_campaign(target_persona="<b>VP</b>")]
        )
        assert "<b>VP</b>" not in html_out
        assert "&lt;b&gt;" in html_out

    def test_category_escaped(self):
        html_out = render_campaigns_dashboard_html(
            campaigns=[_campaign(category="<em>cat</em>")]
        )
        assert "<em>cat</em>" not in html_out

    def test_slug_escaped(self):
        html_out = render_campaigns_dashboard_html(
            campaigns=[_campaign(slug="<s>x</s>")]
        )
        assert "<s>x</s>" not in html_out

    def test_status_name_escaped(self):
        """Status becomes a heading — any markup must not leak."""
        html_out = render_campaigns_dashboard_html(
            campaigns=[_campaign(status="<xss>")]
        )
        # The status is lowercased + escaped
        assert "<xss>" not in html_out
        assert "&lt;xss&gt;" in html_out


class TestBounds:
    def test_max_campaigns_rendered(self):
        campaigns = [_campaign(idx=i, name=f"CAMP_{i}") for i in range(120)]
        html_out = render_campaigns_dashboard_html(campaigns=campaigns)
        assert "CAMP_0" in html_out
        assert "CAMP_119" not in html_out  # past cap 60
        assert "omitted" in html_out

    def test_long_goal_truncated(self):
        html_out = render_campaigns_dashboard_html(
            campaigns=[_campaign(goal="g" * 5000)]
        )
        assert "…" in html_out
        assert "g" * 1000 not in html_out

    def test_long_persona_truncated(self):
        html_out = render_campaigns_dashboard_html(
            campaigns=[_campaign(target_persona="p" * 5000)]
        )
        assert "…" in html_out


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------


class TestCampaignsDashboardTextFallback:
    def test_empty(self):
        out = render_campaigns_dashboard_text_fallback(campaigns=None)
        assert "No campaigns yet" in out

        out2 = render_campaigns_dashboard_text_fallback(campaigns=[])
        assert "No campaigns yet" in out2

    def test_non_list(self):
        out = render_campaigns_dashboard_text_fallback(campaigns="no")  # type: ignore[arg-type]
        assert "No campaigns yet" in out

    def test_renders_key_fields(self):
        out = render_campaigns_dashboard_text_fallback(campaigns=[_campaign()])
        assert "Campaign 0" in out
        assert "outbound" in out
        assert "VP of Engineering" in out
        assert "Drive meetings" in out

    def test_status_grouping(self):
        out = render_campaigns_dashboard_text_fallback(
            campaigns=[
                _campaign(status="live"),
                _campaign(idx=1, status="draft"),
                _campaign(idx=2, status="draft"),
            ]
        )
        assert "## live" in out
        assert "## draft" in out

    def test_org_label(self):
        out = render_campaigns_dashboard_text_fallback(
            campaigns=[_campaign()], org_label="Acme"
        )
        assert "# Campaigns — Acme" in out

    def test_max_cap_footer(self):
        campaigns = [_campaign(idx=i) for i in range(120)]
        out = render_campaigns_dashboard_text_fallback(campaigns=campaigns)
        assert "more campaign(s)" in out

    def test_no_markup_leak(self):
        out = render_campaigns_dashboard_text_fallback(
            campaigns=[_campaign(name="<tag>")]
        )
        assert "<html>" not in out
        assert "<body>" not in out


# ---------------------------------------------------------------------------
# Caps constants
# ---------------------------------------------------------------------------


class TestCapsExist:
    def test_constants(self):
        assert app_renderer._MAX_CAMPAIGNS_RENDERED >= 10
        assert app_renderer._MAX_CAMPAIGN_GOAL_LEN >= 100
        assert app_renderer._MAX_CAMPAIGN_PERSONA_LEN >= 50
