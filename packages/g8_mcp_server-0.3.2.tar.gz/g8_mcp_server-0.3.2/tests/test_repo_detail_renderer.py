"""Unit tests for surface #32 — repo detail renderer.

Covers the palette + helper fns in app_renderer.py for the per-repo
overview surface:

  g8://repos/{repo_id}/overview
  g8://repos/{repo_id}/overview.txt

Focus areas:
- scan / install / provider palettes (case-insensitive, None-safe)
- derive_display_name (repo_name > host/path(url) with .git strip > fallback)
- mask_write_key (>=8 chars, <8 chars, None, empty, whitespace-only)
- stat_card + info_row escape
- empty_state (escape paths, no double-escape)
- HTML renderer (provider chip color, 4-card stat grid, overview
  info-grid with masked write_key, two-card context-section copy
  variants per scan/install status, XSS escape on name/url/branch/
  project_id/write_key, drill-up hints, credential leak regression)
- text fallback (markdown mirror, "(masked)" note, status-meaning
  block, drill-up)
"""

from __future__ import annotations

import pytest

from g8_mcp_server.app_renderer import (
    _REPO_DETAIL_INSTALL_STATUS_COLORS,
    _REPO_DETAIL_SCAN_STATUS_COLORS,
    _render_repo_detail_empty_state_html,
    _repo_detail_derive_display_name,
    _repo_detail_info_row,
    _repo_detail_install_status_palette,
    _repo_detail_mask_write_key,
    _repo_detail_provider_palette,
    _repo_detail_scan_status_palette,
    _repo_detail_stat_card,
    render_repo_detail_html,
    render_repo_detail_text_fallback,
)

_BANNED_HEXES = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}


class TestRepoDetailPalettesNoBannedHexes:
    """Lock tests: palettes must not reintroduce banned Studio hexes."""

    def test_no_banned_hexes_in_scan_status_palette(self):
        for key, pal in _REPO_DETAIL_SCAN_STATUS_COLORS.items():
            for field in ("bg", "fg", "border"):
                assert pal[field].lower() not in _BANNED_HEXES, (
                    f"Banned hex {pal[field]!r} in _REPO_DETAIL_SCAN_STATUS_COLORS[{key!r}][{field!r}]"
                )

    def test_no_banned_hexes_in_install_status_palette(self):
        for key, pal in _REPO_DETAIL_INSTALL_STATUS_COLORS.items():
            for field in ("bg", "fg", "border"):
                assert pal[field].lower() not in _BANNED_HEXES, (
                    f"Banned hex {pal[field]!r} in _REPO_DETAIL_INSTALL_STATUS_COLORS[{key!r}][{field!r}]"
                )


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _sample_repo() -> dict:
    return {
        "id": "repo_abc123",
        "repo_url": "https://github.com/graph8-com/g8",
        "repo_name": "g8",
        "provider": "github",
        "default_branch": "main",
        "scan_status": "ready",
        "install_status": "installed",
        "project_id": "prj_xyz",
        "write_key": "wk_1234567890abcdef",
        "created_at": "2026-03-01T10:00:00Z",
        "updated_at": "2026-04-15T14:00:00Z",
    }


# ---------------------------------------------------------------------------
# TestScanStatusPalette
# ---------------------------------------------------------------------------


class TestScanStatusPalette:
    def test_known_status_ready(self):
        pal = _repo_detail_scan_status_palette("ready")
        assert "bg" in pal and "fg" in pal and "border" in pal

    def test_known_status_scanning(self):
        pal = _repo_detail_scan_status_palette("scanning")
        assert pal["fg"]  # truthy

    def test_known_status_failed_is_red_ish(self):
        pal = _repo_detail_scan_status_palette("failed")
        # red family foreground
        assert pal["fg"].lower().startswith("#")

    def test_ready_and_failed_distinct(self):
        ready = _repo_detail_scan_status_palette("ready")
        failed = _repo_detail_scan_status_palette("failed")
        assert ready != failed

    def test_case_insensitive_upper(self):
        assert _repo_detail_scan_status_palette("READY") == _repo_detail_scan_status_palette("ready")

    def test_case_insensitive_mixed(self):
        assert _repo_detail_scan_status_palette("Ready") == _repo_detail_scan_status_palette("ready")

    def test_whitespace_stripped(self):
        assert _repo_detail_scan_status_palette("  ready  ") == _repo_detail_scan_status_palette("ready")

    def test_empty_string_returns_default(self):
        pal = _repo_detail_scan_status_palette("")
        # Shouldn't crash; returns some palette dict
        assert "bg" in pal

    def test_none_returns_default(self):
        pal = _repo_detail_scan_status_palette(None)
        assert "bg" in pal

    def test_non_string_returns_default(self):
        pal = _repo_detail_scan_status_palette(123)  # type: ignore[arg-type]
        assert "bg" in pal

    def test_unknown_status_returns_default(self):
        pal = _repo_detail_scan_status_palette("totally-made-up")
        default = _repo_detail_scan_status_palette(None)
        assert pal == default


# ---------------------------------------------------------------------------
# TestInstallStatusPalette
# ---------------------------------------------------------------------------


class TestInstallStatusPalette:
    def test_known_installed(self):
        pal = _repo_detail_install_status_palette("installed")
        assert pal["fg"].lower().startswith("#")

    def test_known_pending(self):
        pal = _repo_detail_install_status_palette("pending")
        assert "bg" in pal

    def test_known_failed(self):
        pal = _repo_detail_install_status_palette("failed")
        assert "bg" in pal

    def test_installed_vs_pending_distinct(self):
        assert (
            _repo_detail_install_status_palette("installed")
            != _repo_detail_install_status_palette("pending")
        )

    def test_case_insensitive(self):
        assert (
            _repo_detail_install_status_palette("INSTALLED")
            == _repo_detail_install_status_palette("installed")
        )

    def test_none(self):
        pal = _repo_detail_install_status_palette(None)
        assert "bg" in pal

    def test_empty(self):
        pal = _repo_detail_install_status_palette("")
        assert "bg" in pal

    def test_whitespace(self):
        pal = _repo_detail_install_status_palette("   ")
        assert "bg" in pal

    def test_unknown_returns_default(self):
        pal = _repo_detail_install_status_palette("unheard-of")
        default = _repo_detail_install_status_palette(None)
        assert pal == default


# ---------------------------------------------------------------------------
# TestProviderPalette
# ---------------------------------------------------------------------------


class TestProviderPalette:
    def test_github(self):
        pal = _repo_detail_provider_palette("github")
        assert "bg" in pal

    def test_gitlab(self):
        pal = _repo_detail_provider_palette("gitlab")
        assert "bg" in pal

    def test_bitbucket(self):
        pal = _repo_detail_provider_palette("bitbucket")
        assert "bg" in pal

    def test_local(self):
        pal = _repo_detail_provider_palette("local")
        assert "bg" in pal

    def test_case_insensitive(self):
        assert (
            _repo_detail_provider_palette("GITHUB")
            == _repo_detail_provider_palette("github")
        )

    def test_none(self):
        assert "bg" in _repo_detail_provider_palette(None)

    def test_empty(self):
        assert "bg" in _repo_detail_provider_palette("")

    def test_unknown_provider(self):
        pal = _repo_detail_provider_palette("custom-provider")
        default = _repo_detail_provider_palette(None)
        assert pal == default

    def test_github_and_gitlab_distinct(self):
        assert (
            _repo_detail_provider_palette("github")
            != _repo_detail_provider_palette("gitlab")
        )


# ---------------------------------------------------------------------------
# TestDeriveDisplayName
# ---------------------------------------------------------------------------


class TestDeriveDisplayName:
    def test_uses_repo_name_when_present(self):
        assert _repo_detail_derive_display_name({"repo_name": "g8"}) == "g8"

    def test_strips_whitespace_on_name(self):
        assert _repo_detail_derive_display_name({"repo_name": "  g8  "}) == "g8"

    def test_falls_back_to_url_host_and_path(self):
        out = _repo_detail_derive_display_name(
            {"repo_url": "https://github.com/graph8-com/g8"}
        )
        assert out == "github.com/graph8-com/g8"

    def test_strips_git_suffix(self):
        out = _repo_detail_derive_display_name(
            {"repo_url": "https://github.com/graph8-com/g8.git"}
        )
        assert out == "github.com/graph8-com/g8"

    def test_ssh_url_without_scheme(self):
        # No "://" — rest equals the whole string
        out = _repo_detail_derive_display_name(
            {"repo_url": "git@github.com:graph8-com/g8.git"}
        )
        assert "git@github.com:graph8-com/g8" in out

    def test_caps_at_three_path_segments(self):
        out = _repo_detail_derive_display_name(
            {"repo_url": "https://example.com/a/b/c/d/e"}
        )
        # keeps at most 3 segments: host + 2 subpaths
        assert out == "example.com/a/b"

    def test_two_segments_kept_whole(self):
        out = _repo_detail_derive_display_name(
            {"repo_url": "https://example.com/solo"}
        )
        assert out == "example.com/solo"

    def test_host_only(self):
        out = _repo_detail_derive_display_name(
            {"repo_url": "https://example.com"}
        )
        assert out == "example.com"

    def test_repo_name_preferred_over_url(self):
        out = _repo_detail_derive_display_name(
            {
                "repo_name": "custom-name",
                "repo_url": "https://example.com/x/y",
            }
        )
        assert out == "custom-name"

    def test_empty_name_falls_through_to_url(self):
        out = _repo_detail_derive_display_name(
            {"repo_name": "", "repo_url": "https://example.com/a/b"}
        )
        assert out == "example.com/a/b"

    def test_whitespace_name_falls_through(self):
        out = _repo_detail_derive_display_name(
            {"repo_name": "   ", "repo_url": "https://example.com/a/b"}
        )
        assert out == "example.com/a/b"

    def test_none_repo(self):
        assert _repo_detail_derive_display_name(None) == "Repository"

    def test_empty_dict(self):
        assert _repo_detail_derive_display_name({}) == "Repository"

    def test_non_dict(self):
        assert _repo_detail_derive_display_name("not-a-dict") == "Repository"  # type: ignore[arg-type]

    def test_non_string_name(self):
        out = _repo_detail_derive_display_name({"repo_name": 42})
        # Falls through to repo_url; no repo_url -> "Repository"
        assert out == "Repository"

    def test_non_string_url(self):
        out = _repo_detail_derive_display_name({"repo_url": 42})
        assert out == "Repository"


# ---------------------------------------------------------------------------
# TestMaskWriteKey
# ---------------------------------------------------------------------------


class TestMaskWriteKey:
    def test_standard_key_masked(self):
        out = _repo_detail_mask_write_key("wk_1234567890abcdef")
        assert out == "wk_1…ef"

    def test_shows_first_four_and_last_two(self):
        out = _repo_detail_mask_write_key("abcdefghij")
        assert out == "abcd…ij"

    def test_eight_char_boundary(self):
        out = _repo_detail_mask_write_key("12345678")
        assert out == "1234…78"

    def test_short_key_fully_masked(self):
        out = _repo_detail_mask_write_key("abc")
        assert out == "•••"

    def test_seven_char_fully_masked(self):
        out = _repo_detail_mask_write_key("1234567")
        assert out == "•••••••"

    def test_empty_returns_none_marker(self):
        assert _repo_detail_mask_write_key("") == "(none)"

    def test_whitespace_returns_none_marker(self):
        assert _repo_detail_mask_write_key("   ") == "(none)"

    def test_none_returns_none_marker(self):
        assert _repo_detail_mask_write_key(None) == "(none)"

    def test_non_string_returns_none_marker(self):
        assert _repo_detail_mask_write_key(12345)  == "(none)"  # type: ignore[arg-type]

    def test_whitespace_around_key_stripped(self):
        # strip() applied before length check
        out = _repo_detail_mask_write_key("  wk_abcdefgh  ")
        # stripped to "wk_abcdefgh" (11 chars, >= 8), first 4 + last 2
        assert out == "wk_a…gh"


# ---------------------------------------------------------------------------
# TestStatCard
# ---------------------------------------------------------------------------


class TestStatCard:
    def test_label_and_value_present(self):
        html = _repo_detail_stat_card("Scan", "ready")
        assert "Scan" in html
        assert "ready" in html

    def test_escapes_label(self):
        html = _repo_detail_stat_card("<script>", "ok")
        assert "<script>" not in html
        assert "&lt;script&gt;" in html

    def test_escapes_value(self):
        html = _repo_detail_stat_card("Label", "<b>x</b>")
        assert "<b>x</b>" not in html
        assert "&lt;b&gt;x&lt;/b&gt;" in html

    def test_accent_applied(self):
        html = _repo_detail_stat_card("Scan", "ready", accent="#10b981")
        assert "#10b981" in html

    def test_no_accent_when_none(self):
        html = _repo_detail_stat_card("Scan", "ready", accent=None)
        assert "border-top" not in html

    def test_accent_escaped(self):
        # Not a realistic case, but ensures we escape accents
        html = _repo_detail_stat_card("Scan", "ok", accent='"><script>')
        assert "<script>" not in html


# ---------------------------------------------------------------------------
# TestInfoRow
# ---------------------------------------------------------------------------


class TestInfoRow:
    def test_label_and_value_present(self):
        html = _repo_detail_info_row("Provider", "<b>github</b>")
        assert "Provider" in html
        # value_html passed through (caller is responsible for safety)
        assert "<b>github</b>" in html

    def test_label_escaped(self):
        html = _repo_detail_info_row("<script>", "x")
        assert "<script>" not in html
        assert "&lt;script&gt;" in html

    def test_value_html_trusted(self):
        # value_html is NOT escaped — callers pass pre-escaped content
        html = _repo_detail_info_row("Key", "<code>wk_1…ef</code>")
        assert "<code>" in html


# ---------------------------------------------------------------------------
# TestEmptyState
# ---------------------------------------------------------------------------


class TestEmptyState:
    def test_contains_repo_id(self):
        html = _render_repo_detail_empty_state_html(
            repo_id="repo_missing", reason="Not found"
        )
        assert "repo_missing" in html

    def test_contains_reason(self):
        html = _render_repo_detail_empty_state_html(
            repo_id="r", reason="Totally gone."
        )
        assert "Totally gone." in html

    def test_escapes_reason(self):
        html = _render_repo_detail_empty_state_html(
            repo_id="r", reason="<script>alert(1)</script>"
        )
        assert "<script>alert(1)</script>" not in html
        assert "&lt;script&gt;" in html

    def test_no_double_escape(self):
        # _clip HTML-escapes the id; empty-state must not re-escape
        html = _render_repo_detail_empty_state_html(
            repo_id="<id>", reason="x"
        )
        assert "&amp;lt;" not in html

    def test_unknown_id_fallback(self):
        html = _render_repo_detail_empty_state_html(repo_id="", reason="x")
        assert "(unknown)" in html

    def test_drill_up_to_repos_index(self):
        html = _render_repo_detail_empty_state_html(
            repo_id="r", reason="x"
        )
        assert "g8://repos" in html


# ---------------------------------------------------------------------------
# TestRenderHtml
# ---------------------------------------------------------------------------


class TestRenderHtml:
    def test_contains_display_name(self):
        html = render_repo_detail_html(repo=_sample_repo(), repo_id="repo_abc123")
        assert "g8" in html

    def test_contains_repo_id_in_header(self):
        html = render_repo_detail_html(repo=_sample_repo(), repo_id="repo_abc123")
        assert "repo_abc123" in html

    def test_contains_provider_chip_uppercase(self):
        html = render_repo_detail_html(repo=_sample_repo(), repo_id="repo_abc123")
        assert "GITHUB" in html

    def test_contains_scan_chip(self):
        html = render_repo_detail_html(repo=_sample_repo(), repo_id="repo_abc123")
        assert "READY" in html

    def test_contains_install_chip(self):
        html = render_repo_detail_html(repo=_sample_repo(), repo_id="repo_abc123")
        assert "INSTALLED" in html

    def test_contains_default_branch_main(self):
        html = render_repo_detail_html(repo=_sample_repo(), repo_id="repo_abc123")
        assert "main" in html

    def test_contains_project_id(self):
        html = render_repo_detail_html(repo=_sample_repo(), repo_id="repo_abc123")
        assert "prj_xyz" in html

    def test_contains_repo_url(self):
        html = render_repo_detail_html(repo=_sample_repo(), repo_id="repo_abc123")
        assert "github.com/graph8-com/g8" in html

    def test_write_key_masked_first_four_shown(self):
        html = render_repo_detail_html(repo=_sample_repo(), repo_id="repo_abc123")
        assert "wk_1" in html

    def test_write_key_masked_last_two_shown(self):
        html = render_repo_detail_html(repo=_sample_repo(), repo_id="repo_abc123")
        # "ef" is the last 2 chars of the mask
        assert "ef</code>" in html or ">ef<" in html or "wk_1…ef" in html

    def test_write_key_never_leaks(self):
        """REGRESSION: full write_key must NEVER appear in rendered HTML."""
        repo = _sample_repo()
        html = render_repo_detail_html(repo=repo, repo_id="repo_abc123")
        assert repo["write_key"] not in html, "write_key leaked in HTML output!"

    def test_write_key_masked_annotation(self):
        html = render_repo_detail_html(repo=_sample_repo(), repo_id="repo_abc123")
        assert "(masked)" in html

    def test_write_key_none_shows_none_marker(self):
        repo = _sample_repo()
        repo["write_key"] = None
        html = render_repo_detail_html(repo=repo, repo_id="repo_abc123")
        assert "(none)" in html

    def test_write_key_missing_shows_none_marker(self):
        repo = _sample_repo()
        repo.pop("write_key")
        html = render_repo_detail_html(repo=repo, repo_id="repo_abc123")
        assert "(none)" in html

    def test_short_write_key_fully_masked(self):
        repo = _sample_repo()
        repo["write_key"] = "abc"
        html = render_repo_detail_html(repo=repo, repo_id="r")
        # "abc" should not appear literally — fully masked by bullets
        assert "•••" in html

    # XSS / escape

    def test_escapes_repo_name(self):
        repo = _sample_repo()
        repo["repo_name"] = "<script>alert(1)</script>"
        html = render_repo_detail_html(repo=repo, repo_id="r")
        assert "<script>alert(1)</script>" not in html
        assert "&lt;script&gt;" in html

    def test_escapes_repo_url(self):
        repo = _sample_repo()
        repo["repo_url"] = "https://evil.com/<img src=x>"
        html = render_repo_detail_html(repo=repo, repo_id="r")
        assert "<img src=x>" not in html

    def test_escapes_branch(self):
        repo = _sample_repo()
        repo["default_branch"] = "<script>"
        html = render_repo_detail_html(repo=repo, repo_id="r")
        assert "<script>" not in html
        assert "&lt;script&gt;" in html

    def test_escapes_project_id(self):
        repo = _sample_repo()
        repo["project_id"] = "<script>evil</script>"
        html = render_repo_detail_html(repo=repo, repo_id="r")
        assert "<script>evil</script>" not in html

    def test_escapes_repo_id_in_header(self):
        html = render_repo_detail_html(
            repo=_sample_repo(), repo_id="<id>"
        )
        assert "<id>" not in html or "&lt;id&gt;" in html

    def test_no_double_escape(self):
        repo = _sample_repo()
        repo["repo_name"] = "<x>"
        html = render_repo_detail_html(repo=repo, repo_id="r")
        assert "&amp;lt;" not in html

    # Stat grid structure

    def test_has_four_stat_cards(self):
        html = render_repo_detail_html(repo=_sample_repo(), repo_id="r")
        # 4 stat cards: Scan, Install, Provider, Branch
        # Use class attribute count as a sentinel
        assert html.count('class="stat-card"') == 4

    def test_stat_grid_contains_all_labels(self):
        html = render_repo_detail_html(repo=_sample_repo(), repo_id="r")
        for label in ("Scan", "Install", "Provider", "Branch"):
            assert label in html

    def test_branch_shows_default_placeholder(self):
        repo = _sample_repo()
        repo["default_branch"] = ""
        html = render_repo_detail_html(repo=repo, repo_id="r")
        assert "(default)" in html

    # Unknown / missing fields

    def test_unknown_scan_status_renders(self):
        repo = _sample_repo()
        repo["scan_status"] = ""
        html = render_repo_detail_html(repo=repo, repo_id="r")
        assert "UNKNOWN" in html

    def test_unknown_install_status_renders(self):
        repo = _sample_repo()
        repo["install_status"] = ""
        html = render_repo_detail_html(repo=repo, repo_id="r")
        assert "UNKNOWN" in html

    def test_unknown_provider_renders(self):
        repo = _sample_repo()
        repo["provider"] = ""
        html = render_repo_detail_html(repo=repo, repo_id="r")
        assert "UNKNOWN" in html

    # Context section — scan status copy variants

    def test_scan_context_ready(self):
        repo = _sample_repo()
        repo["scan_status"] = "ready"
        html = render_repo_detail_html(repo=repo, repo_id="r")
        assert "Scan complete" in html

    def test_scan_context_completed_alias(self):
        repo = _sample_repo()
        repo["scan_status"] = "completed"
        html = render_repo_detail_html(repo=repo, repo_id="r")
        assert "Scan complete" in html

    def test_scan_context_scanning(self):
        repo = _sample_repo()
        repo["scan_status"] = "scanning"
        html = render_repo_detail_html(repo=repo, repo_id="r")
        assert "in progress" in html.lower()

    def test_scan_context_running_alias(self):
        repo = _sample_repo()
        repo["scan_status"] = "running"
        html = render_repo_detail_html(repo=repo, repo_id="r")
        assert "in progress" in html.lower()

    def test_scan_context_pending(self):
        repo = _sample_repo()
        repo["scan_status"] = "pending"
        html = render_repo_detail_html(repo=repo, repo_id="r")
        assert "queued" in html.lower()

    def test_scan_context_failed(self):
        repo = _sample_repo()
        repo["scan_status"] = "failed"
        html = render_repo_detail_html(repo=repo, repo_id="r")
        assert "rescan" in html.lower()

    def test_scan_context_error_alias(self):
        repo = _sample_repo()
        repo["scan_status"] = "error"
        html = render_repo_detail_html(repo=repo, repo_id="r")
        assert "rescan" in html.lower()

    def test_scan_context_unknown_fallback(self):
        repo = _sample_repo()
        repo["scan_status"] = "gibberish"
        html = render_repo_detail_html(repo=repo, repo_id="r")
        assert "not started" in html.lower()

    # Context section — install status copy variants

    def test_install_context_installed(self):
        repo = _sample_repo()
        repo["install_status"] = "installed"
        html = render_repo_detail_html(repo=repo, repo_id="r")
        assert "events should be flowing" in html

    def test_install_context_active_alias(self):
        repo = _sample_repo()
        repo["install_status"] = "active"
        html = render_repo_detail_html(repo=repo, repo_id="r")
        assert "events should be flowing" in html

    def test_install_context_pending(self):
        repo = _sample_repo()
        repo["install_status"] = "pending"
        html = render_repo_detail_html(repo=repo, repo_id="r")
        assert "Deploy" in html or "deploy" in html

    def test_install_context_generated_alias(self):
        repo = _sample_repo()
        repo["install_status"] = "generated"
        html = render_repo_detail_html(repo=repo, repo_id="r")
        assert "Snippet generated" in html

    def test_install_context_failed(self):
        repo = _sample_repo()
        repo["install_status"] = "failed"
        html = render_repo_detail_html(repo=repo, repo_id="r")
        assert "failed" in html.lower()

    def test_install_context_unknown_fallback(self):
        repo = _sample_repo()
        repo["install_status"] = "something-new"
        html = render_repo_detail_html(repo=repo, repo_id="r")
        assert "not installed" in html.lower()

    # Drill-up hints

    def test_drill_up_campaigns(self):
        html = render_repo_detail_html(repo=_sample_repo(), repo_id="repo_abc123")
        assert "g8://repos/repo_abc123/campaigns" in html

    def test_drill_up_kb(self):
        html = render_repo_detail_html(repo=_sample_repo(), repo_id="repo_abc123")
        assert "g8://repos/repo_abc123/kb" in html

    def test_drill_up_scan(self):
        html = render_repo_detail_html(repo=_sample_repo(), repo_id="repo_abc123")
        assert "g8://repos/repo_abc123/scan" in html

    def test_drill_up_rescan_action(self):
        html = render_repo_detail_html(repo=_sample_repo(), repo_id="repo_abc123")
        assert "/rescan" in html

    # Empty-state pathway

    def test_none_repo_returns_empty_state(self):
        html = render_repo_detail_html(repo=None, repo_id="missing")
        assert "Repository not available" in html
        assert "missing" in html

    def test_non_dict_repo_returns_empty_state(self):
        html = render_repo_detail_html(repo=[], repo_id="missing")  # type: ignore[arg-type]
        assert "Repository not available" in html

    def test_empty_state_no_write_key_leak(self):
        # Even if somehow passed a non-dict, we never see "wk_"
        html = render_repo_detail_html(repo=None, repo_id="r")
        assert "wk_" not in html

    # Dates

    def test_created_at_shown(self):
        html = render_repo_detail_html(repo=_sample_repo(), repo_id="r")
        assert "2026-03-01T10:00:00Z" in html

    def test_updated_at_shown(self):
        html = render_repo_detail_html(repo=_sample_repo(), repo_id="r")
        assert "2026-04-15T14:00:00Z" in html

    def test_missing_dates_ok(self):
        repo = _sample_repo()
        repo.pop("created_at")
        repo.pop("updated_at")
        html = render_repo_detail_html(repo=repo, repo_id="r")
        assert "Created" not in html or "Updated" not in html
        # at a minimum, should not crash and should still render the header
        assert "g8" in html

    # HTML structure sanity

    def test_is_full_document(self):
        html = render_repo_detail_html(repo=_sample_repo(), repo_id="r")
        assert html.startswith("<!DOCTYPE html>")
        assert html.rstrip().endswith("</html>")

    def test_has_title(self):
        html = render_repo_detail_html(repo=_sample_repo(), repo_id="r")
        assert "<title>" in html
        assert "g8" in html

    def test_no_scripts_injected(self):
        # The renderer itself must never emit a <script> tag
        repo = _sample_repo()
        html = render_repo_detail_html(repo=repo, repo_id="r")
        assert "<script" not in html.lower()

    # URL clipping

    def test_very_long_url_clipped(self):
        repo = _sample_repo()
        repo["repo_url"] = "https://example.com/" + ("a" * 1000)
        html = render_repo_detail_html(repo=repo, repo_id="r")
        # Should not contain all 1000 a's intact
        assert ("a" * 600) not in html


# ---------------------------------------------------------------------------
# TestRenderTextFallback
# ---------------------------------------------------------------------------


class TestRenderTextFallback:
    def test_contains_display_name_header(self):
        text = render_repo_detail_text_fallback(
            repo=_sample_repo(), repo_id="repo_abc123"
        )
        assert text.startswith("# g8")

    def test_contains_provider(self):
        text = render_repo_detail_text_fallback(
            repo=_sample_repo(), repo_id="r"
        )
        assert "github" in text

    def test_contains_scan_status(self):
        text = render_repo_detail_text_fallback(
            repo=_sample_repo(), repo_id="r"
        )
        assert "ready" in text

    def test_contains_install_status(self):
        text = render_repo_detail_text_fallback(
            repo=_sample_repo(), repo_id="r"
        )
        assert "installed" in text

    def test_contains_repo_url(self):
        text = render_repo_detail_text_fallback(
            repo=_sample_repo(), repo_id="r"
        )
        assert "https://github.com/graph8-com/g8" in text

    def test_contains_default_branch(self):
        text = render_repo_detail_text_fallback(
            repo=_sample_repo(), repo_id="r"
        )
        assert "main" in text

    def test_contains_project_id(self):
        text = render_repo_detail_text_fallback(
            repo=_sample_repo(), repo_id="r"
        )
        assert "prj_xyz" in text

    def test_write_key_masked(self):
        text = render_repo_detail_text_fallback(
            repo=_sample_repo(), repo_id="r"
        )
        assert "wk_1…ef" in text

    def test_write_key_never_leaks(self):
        repo = _sample_repo()
        text = render_repo_detail_text_fallback(repo=repo, repo_id="r")
        assert repo["write_key"] not in text, "write_key leaked in text output!"

    def test_masked_annotation(self):
        text = render_repo_detail_text_fallback(
            repo=_sample_repo(), repo_id="r"
        )
        assert "(masked)" in text

    def test_contains_status_meaning_section(self):
        text = render_repo_detail_text_fallback(
            repo=_sample_repo(), repo_id="r"
        )
        assert "What each status means" in text

    def test_status_meaning_ready(self):
        repo = _sample_repo()
        repo["scan_status"] = "ready"
        text = render_repo_detail_text_fallback(repo=repo, repo_id="r")
        assert "complete" in text.lower()

    def test_status_meaning_scanning(self):
        repo = _sample_repo()
        repo["scan_status"] = "scanning"
        text = render_repo_detail_text_fallback(repo=repo, repo_id="r")
        assert "in progress" in text.lower()

    def test_status_meaning_pending(self):
        repo = _sample_repo()
        repo["scan_status"] = "pending"
        text = render_repo_detail_text_fallback(repo=repo, repo_id="r")
        assert "queued" in text.lower()

    def test_status_meaning_failed(self):
        repo = _sample_repo()
        repo["scan_status"] = "failed"
        text = render_repo_detail_text_fallback(repo=repo, repo_id="r")
        assert "failed" in text.lower()

    def test_install_meaning_installed(self):
        repo = _sample_repo()
        repo["install_status"] = "installed"
        text = render_repo_detail_text_fallback(repo=repo, repo_id="r")
        assert "deployed" in text.lower() or "flowing" in text.lower()

    def test_install_meaning_pending(self):
        repo = _sample_repo()
        repo["install_status"] = "pending"
        text = render_repo_detail_text_fallback(repo=repo, repo_id="r")
        assert "deploy" in text.lower()

    def test_install_meaning_failed(self):
        repo = _sample_repo()
        repo["install_status"] = "failed"
        text = render_repo_detail_text_fallback(repo=repo, repo_id="r")
        assert "failed" in text.lower()

    def test_drill_up_listed(self):
        text = render_repo_detail_text_fallback(
            repo=_sample_repo(), repo_id="repo_abc123"
        )
        assert "g8://repos/repo_abc123/campaigns" in text
        assert "g8://repos/repo_abc123/kb" in text
        assert "g8://repos/repo_abc123/scan" in text
        assert "/rescan" in text

    def test_none_repo_empty_state(self):
        text = render_repo_detail_text_fallback(repo=None, repo_id="r")
        assert "Repository not available" in text
        assert "r" in text

    def test_non_dict_repo_empty_state(self):
        text = render_repo_detail_text_fallback(repo=[], repo_id="r")  # type: ignore[arg-type]
        assert "Repository not available" in text

    def test_empty_state_no_write_key(self):
        text = render_repo_detail_text_fallback(repo=None, repo_id="r")
        assert "wk_" not in text

    def test_missing_repo_id_shows_unknown(self):
        text = render_repo_detail_text_fallback(repo=None, repo_id="")
        assert "(unknown)" in text

    def test_ends_with_newline(self):
        text = render_repo_detail_text_fallback(
            repo=_sample_repo(), repo_id="r"
        )
        assert text.endswith("\n")

    def test_unknown_scan_and_install(self):
        repo = _sample_repo()
        repo["scan_status"] = ""
        repo["install_status"] = ""
        text = render_repo_detail_text_fallback(repo=repo, repo_id="r")
        # "(unknown)" appears for each
        assert text.count("(unknown)") >= 2

    def test_handles_missing_optional_fields(self):
        # Just id — everything else absent
        text = render_repo_detail_text_fallback(
            repo={"id": "repo_min"}, repo_id="repo_min"
        )
        assert "repo_min" in text
        assert "Write key" in text
