"""Tests for the inbox dashboard HTML + text renderers (upgrade 4 — #7)."""

from __future__ import annotations

from g8_mcp_server import app_renderer
from g8_mcp_server.app_renderer import (
    _group_inbox_by_channel,
    _inbox_channel_icon,
    _inbox_contact_label,
    _inbox_status_color,
    render_inbox_dashboard_html,
    render_inbox_dashboard_text_fallback,
)


def _thread(idx: int = 0, **overrides) -> dict:
    """Default thread dict matching `InboxThreadSummary`."""
    base = {
        "id": f"t_{idx}",
        "channel": "email",
        "subject": f"Thread {idx}",
        "status": "open",
        "contact": {"name": f"Contact {idx}", "email": f"c{idx}@example.com"},
        "tags": [{"name": "hot"}, {"name": "priority"}],
        "assignees": [{"name": "Thomas", "email": "thomas@graph8.com"}],
        "preview": f"Preview of thread {idx}",
        "created_at": "2026-04-01T00:00:00Z",
        "updated_at": "2026-04-15T12:00:00Z",
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class TestInboxStatusColor:
    def test_known(self):
        # Backported to graph8 tokens 2026-04-21
        assert _inbox_status_color("open") == "#059669"  # _G8_POSITIVE_FG
        assert _inbox_status_color("replied") == "#7d2df3"  # _G8_PRIMARY
        assert _inbox_status_color("pending") == "#a0750a"
        assert _inbox_status_color("closed") == "#777777"

    def test_case_and_whitespace(self):
        assert _inbox_status_color("OPEN") == "#059669"  # _G8_POSITIVE_FG
        assert _inbox_status_color(" Replied ") == "#7d2df3"  # _G8_PRIMARY

    def test_unknown(self):
        assert _inbox_status_color("weird") == "#777777"
        assert _inbox_status_color(None) == "#777777"
        assert _inbox_status_color("") == "#777777"

    def test_no_banned_hexes_in_status_palette(self):
        banned = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}
        from mcp_server.g8_mcp_server.app_renderer import _INBOX_STATUS_COLORS
        for k, v in _INBOX_STATUS_COLORS.items():
            assert v.lower() not in banned, f"status={k!r} hex={v!r} is banned"


class TestInboxChannelIcon:
    def test_known(self):
        assert _inbox_channel_icon("email") == "✉"
        assert _inbox_channel_icon("sms") == "💬"
        assert _inbox_channel_icon("linkedin") == "in"
        assert _inbox_channel_icon("whatsapp") == "📱"

    def test_unknown_returns_bullet(self):
        assert _inbox_channel_icon("unknown") == "•"
        assert _inbox_channel_icon(None) == "•"
        assert _inbox_channel_icon("") == "•"


class TestGroupInboxByChannel:
    def test_empty(self):
        assert _group_inbox_by_channel([]) == []

    def test_ordering(self):
        threads = [
            _thread(idx=1, channel="linkedin"),
            _thread(idx=2, channel="email"),
            _thread(idx=3, channel="sms"),
        ]
        result = _group_inbox_by_channel(threads)
        keys = [k for k, _ in result]
        assert keys.index("email") < keys.index("sms")
        assert keys.index("sms") < keys.index("linkedin")

    def test_missing_channel_bucketed_as_other(self):
        result = _group_inbox_by_channel(
            [_thread(channel=None), _thread(channel="")]
        )
        assert result[0][0] == "other"
        assert len(result[0][1]) == 2

    def test_unknown_channels_preserve_insertion_order(self):
        threads = [
            _thread(idx=1, channel="alpha"),
            _thread(idx=2, channel="email"),
            _thread(idx=3, channel="beta"),
        ]
        result = _group_inbox_by_channel(threads)
        keys = [k for k, _ in result]
        # Preferred (email) comes first, then insertion order for unknowns
        assert keys == ["email", "alpha", "beta"]


class TestInboxContactLabel:
    def test_none_returns_empty(self):
        assert _inbox_contact_label(None) == ""
        assert _inbox_contact_label("not a dict") == ""  # type: ignore[arg-type]

    def test_prefers_name(self):
        label = _inbox_contact_label({"name": "Alice", "email": "a@b.com"})
        assert label == "Alice"

    def test_falls_back_to_email(self):
        label = _inbox_contact_label({"email": "a@b.com"})
        assert label == "a@b.com"

    def test_falls_back_to_phone(self):
        label = _inbox_contact_label({"phone": "+15551234"})
        assert label == "+15551234"

    def test_empty_dict(self):
        assert _inbox_contact_label({}) == ""


# ---------------------------------------------------------------------------
# HTML renderer
# ---------------------------------------------------------------------------


class TestRenderInboxDashboardHtml:
    def test_empty_state(self):
        html_out = render_inbox_dashboard_html(threads=None)
        assert "Inbox is empty" in html_out

        html_out2 = render_inbox_dashboard_html(threads=[])
        assert "Inbox is empty" in html_out2

    def test_non_list_input(self):
        html_out = render_inbox_dashboard_html(threads="nope")  # type: ignore[arg-type]
        assert "Inbox is empty" in html_out

    def test_only_garbage_items(self):
        html_out = render_inbox_dashboard_html(threads=[None, "x", 1])  # type: ignore[list-item]
        assert "Inbox is empty" in html_out

    def test_renders_thread(self):
        html_out = render_inbox_dashboard_html(threads=[_thread()])
        assert "Thread 0" in html_out
        assert "Contact 0" in html_out
        assert "Preview of thread 0" in html_out
        assert "Thomas" in html_out  # assignee
        assert "hot" in html_out
        assert "priority" in html_out

    def test_channel_grouping_rendered(self):
        html_out = render_inbox_dashboard_html(
            threads=[
                _thread(channel="email"),
                _thread(idx=1, channel="sms"),
            ]
        )
        assert "email" in html_out
        assert "sms" in html_out
        assert "✉" in html_out
        assert "💬" in html_out

    def test_missing_subject_fallback(self):
        html_out = render_inbox_dashboard_html(
            threads=[_thread(subject=None)]
        )
        assert "(no subject)" in html_out

    def test_status_badge(self):
        html_out = render_inbox_dashboard_html(threads=[_thread(status="replied")])
        assert "replied" in html_out

    def test_org_label(self):
        html_out = render_inbox_dashboard_html(
            threads=[_thread()], org_label="Acme"
        )
        assert "Acme" in html_out

    def test_string_tags_supported(self):
        """Tags can be strings OR dicts — both should render."""
        html_out = render_inbox_dashboard_html(
            threads=[_thread(tags=["urgent", "vip"])]
        )
        assert "urgent" in html_out
        assert "vip" in html_out


class TestEscaping:
    def test_subject_escaped(self):
        html_out = render_inbox_dashboard_html(
            threads=[_thread(subject="<script>evil()</script>")]
        )
        assert "<script>evil" not in html_out
        assert "&lt;script&gt;" in html_out

    def test_preview_escaped(self):
        html_out = render_inbox_dashboard_html(
            threads=[_thread(preview="<img onerror=bad()>")]
        )
        assert "<img onerror" not in html_out

    def test_contact_name_escaped(self):
        html_out = render_inbox_dashboard_html(
            threads=[_thread(contact={"name": "<b>evil</b>"})]
        )
        assert "<b>evil</b>" not in html_out

    def test_tag_name_escaped(self):
        html_out = render_inbox_dashboard_html(
            threads=[_thread(tags=[{"name": "<xss>"}])]
        )
        assert "<xss>" not in html_out
        assert "&lt;xss&gt;" in html_out

    def test_assignee_escaped(self):
        html_out = render_inbox_dashboard_html(
            threads=[_thread(assignees=[{"name": "<svg>"}])]
        )
        assert "<svg>" not in html_out


class TestBounds:
    def test_max_threads_rendered(self):
        threads = [_thread(idx=i, subject=f"T_{i}") for i in range(120)]
        html_out = render_inbox_dashboard_html(threads=threads)
        assert "T_0" in html_out
        assert "T_119" not in html_out  # past cap 60
        assert "omitted" in html_out

    def test_long_preview_truncated(self):
        html_out = render_inbox_dashboard_html(
            threads=[_thread(preview="p" * 5000)]
        )
        assert "…" in html_out

    def test_long_subject_truncated(self):
        html_out = render_inbox_dashboard_html(
            threads=[_thread(subject="s" * 5000)]
        )
        assert "…" in html_out


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------


class TestInboxDashboardTextFallback:
    def test_empty(self):
        out = render_inbox_dashboard_text_fallback(threads=None)
        assert "Inbox is empty" in out

        out2 = render_inbox_dashboard_text_fallback(threads=[])
        assert "Inbox is empty" in out2

    def test_non_list(self):
        out = render_inbox_dashboard_text_fallback(threads="nope")  # type: ignore[arg-type]
        assert "Inbox is empty" in out

    def test_renders_key_fields(self):
        out = render_inbox_dashboard_text_fallback(threads=[_thread()])
        assert "Thread 0" in out
        assert "Contact 0" in out
        assert "Preview of thread 0" in out
        assert "[open]" in out
        assert "hot" in out

    def test_channel_grouping(self):
        out = render_inbox_dashboard_text_fallback(
            threads=[
                _thread(channel="email"),
                _thread(idx=1, channel="sms"),
                _thread(idx=2, channel="sms"),
            ]
        )
        assert "## email" in out
        assert "## sms" in out

    def test_org_label(self):
        out = render_inbox_dashboard_text_fallback(
            threads=[_thread()], org_label="Acme"
        )
        assert "# Inbox — Acme" in out

    def test_max_cap_footer(self):
        threads = [_thread(idx=i) for i in range(120)]
        out = render_inbox_dashboard_text_fallback(threads=threads)
        assert "more thread(s)" in out

    def test_no_html_leak(self):
        out = render_inbox_dashboard_text_fallback(
            threads=[_thread(subject="<tag>")]
        )
        assert "<html>" not in out
        assert "<body>" not in out


# ---------------------------------------------------------------------------
# Caps sanity
# ---------------------------------------------------------------------------


class TestCapsExist:
    def test_constants(self):
        assert app_renderer._MAX_INBOX_THREADS_RENDERED >= 10
        assert app_renderer._MAX_INBOX_PREVIEW_LEN >= 100
        assert app_renderer._MAX_INBOX_SUBJECT_LEN >= 50
