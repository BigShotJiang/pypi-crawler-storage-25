"""Unit tests for the sequence-preview HTML renderer (upgrade 4 — app surface #2).

Mirrors the discipline from `test_app_renderer.py`:

- Every backend field is HTML-escaped (XSS safety)
- Caps on steps and channels so long sequences don't blow up the response
- Empty / None / malformed input produces an empty-state page, never an exception
- Plaintext fallback mirrors the same truths
"""

from __future__ import annotations

from html.parser import HTMLParser

import pytest

from g8_mcp_server.app_renderer import (
    _MAX_CHANNELS_RENDERED,
    _MAX_STEPS_RENDERED,
    render_sequence_preview_html,
    render_sequence_preview_text_fallback,
)


def _preview(n_steps: int = 3, n_channels: int = 2, **overrides) -> dict:
    base = {
        "id": "seq_abc",
        "name": "Outbound to VP Sales",
        "status": "active",
        "description": "3-touch multichannel sequence for warm reply harvesting.",
        "steps": [
            {
                "id": f"step_{i}",
                "step_order": i + 1,
                "step_type": ["email", "linkedin_connection", "call"][i % 3],
                "input_type": "manual",
                "time_interval": [0, 86400, 259200][i % 3],
                "step_data": {
                    "subject": f"Subject {i}",
                    "body": f"Step body content {i}",
                },
            }
            for i in range(n_steps)
        ],
        "channels": [
            {
                "id": f"ch_{i}",
                "channel_id": f"cid_{i}",
                "channel_type": ["email", "linkedin"][i % 2],
                "channel_value": f"user{i}@example.com",
            }
            for i in range(n_channels)
        ],
    }
    base.update(overrides)
    return base


class _TagCollector(HTMLParser):
    """Collects start tags so we can check HTML is well-formed enough to parse."""

    def __init__(self):
        super().__init__()
        self.tags: list[str] = []

    def handle_starttag(self, tag, attrs):
        self.tags.append(tag)


# ---------------------------------------------------------------------------
# Happy path rendering
# ---------------------------------------------------------------------------


class TestRenderSequencePreviewHtml:
    def test_returns_complete_html_document(self):
        result = render_sequence_preview_html(
            sequence_id="seq_abc",
            preview=_preview(),
        )
        assert result.startswith("<!doctype html>")
        assert "<html" in result and "</html>" in result.rstrip()
        assert "Outbound to VP Sales" in result
        assert "seq_abc" in result

    def test_renders_each_step(self):
        result = render_sequence_preview_html(
            sequence_id="seq_abc",
            preview=_preview(n_steps=3),
        )
        assert "Step 1" in result
        assert "Step 2" in result
        assert "Step 3" in result
        # Step types should appear
        assert "email" in result
        assert "linkedin_connection" in result
        assert "call" in result

    def test_renders_each_channel(self):
        result = render_sequence_preview_html(
            sequence_id="seq_abc",
            preview=_preview(n_channels=2),
        )
        assert "user0@example.com" in result
        assert "user1@example.com" in result

    def test_renders_description_and_status(self):
        result = render_sequence_preview_html(
            sequence_id="seq_abc",
            preview=_preview(),
        )
        assert "3-touch multichannel sequence" in result
        # Status badge
        assert "active" in result.lower()

    def test_step_body_rendered(self):
        result = render_sequence_preview_html(
            sequence_id="seq_abc",
            preview=_preview(n_steps=1),
        )
        assert "Subject 0" in result

    def test_time_interval_formatted(self):
        """Delay labels like +1d should appear for time_interval seconds."""
        preview = _preview(n_steps=3)
        # The test data's 2nd step has time_interval=86400 → 1d
        result = render_sequence_preview_html(sequence_id="seq_abc", preview=preview)
        assert "+1d" in result or "+24h" in result
        # The 3rd step has 259200s → 3d
        assert "+3d" in result

    def test_no_javascript_in_output(self):
        result = render_sequence_preview_html(
            sequence_id="seq_abc",
            preview=_preview(),
        )
        assert "<script" not in result.lower()
        assert "onerror" not in result.lower()
        assert "onload" not in result.lower()
        assert "javascript:" not in result.lower()

    def test_html_is_parseable(self):
        parser = _TagCollector()
        parser.feed(render_sequence_preview_html(sequence_id="seq_abc", preview=_preview()))
        assert "html" in parser.tags
        assert "body" in parser.tags
        assert "ol" in parser.tags
        assert "li" in parser.tags


# ---------------------------------------------------------------------------
# XSS / escaping
# ---------------------------------------------------------------------------


class TestEscaping:
    def test_name_escaped(self):
        preview = _preview()
        preview["name"] = '<script>alert("xss")</script>'
        result = render_sequence_preview_html(sequence_id="seq_abc", preview=preview)
        assert "<script>" not in result
        assert "&lt;script&gt;" in result

    def test_description_escaped(self):
        preview = _preview()
        preview["description"] = '<img src=x onerror="alert(1)">'
        result = render_sequence_preview_html(sequence_id="seq_abc", preview=preview)
        assert '<img src=x onerror=' not in result
        assert "&lt;img" in result

    def test_step_body_escaped(self):
        # _extract_step_body prefers subject first, so inject there.
        preview = _preview(n_steps=1)
        preview["steps"][0]["step_data"] = {
            "subject": '</style><script>evil</script>',
        }
        result = render_sequence_preview_html(sequence_id="seq_abc", preview=preview)
        assert "<script>evil</script>" not in result
        assert "&lt;script&gt;evil" in result

    def test_channel_value_escaped(self):
        preview = _preview(n_channels=1)
        preview["channels"][0]["channel_value"] = '"><svg onload=alert(1)>'
        result = render_sequence_preview_html(sequence_id="seq_abc", preview=preview)
        assert "<svg onload" not in result

    def test_status_escaped(self):
        preview = _preview()
        preview["status"] = "<b>active</b>"
        result = render_sequence_preview_html(sequence_id="seq_abc", preview=preview)
        assert "<b>active</b>" not in result
        assert "&lt;b&gt;active" in result


# ---------------------------------------------------------------------------
# Caps, malformed input, empty state
# ---------------------------------------------------------------------------


class TestBounds:
    def test_step_cap_enforced(self):
        preview = _preview(n_steps=_MAX_STEPS_RENDERED + 5)
        result = render_sequence_preview_html(sequence_id="seq_abc", preview=preview)
        # We should see a "N step(s) omitted" note
        assert "step(s) omitted" in result
        # And only _MAX_STEPS_RENDERED "Step N" labels should appear
        step_count = result.count('class="step-num"')
        assert step_count == _MAX_STEPS_RENDERED

    def test_channel_cap_enforced(self):
        preview = _preview(n_steps=1, n_channels=_MAX_CHANNELS_RENDERED + 3)
        result = render_sequence_preview_html(sequence_id="seq_abc", preview=preview)
        assert "channel(s) omitted" in result

    def test_none_preview_renders_empty_state(self):
        result = render_sequence_preview_html(sequence_id="seq_missing", preview=None)
        assert "<!doctype html>" in result
        assert "seq_missing" in result
        assert "No sequence found" in result

    def test_empty_dict_renders_empty_state(self):
        result = render_sequence_preview_html(sequence_id="seq_missing", preview={})
        assert "No sequence found" in result

    def test_non_dict_preview_renders_empty_state(self):
        # Defensive — if a caller passes a list or string, should not raise.
        result = render_sequence_preview_html(sequence_id="seq_bad", preview="not-a-dict")  # type: ignore[arg-type]
        assert "No sequence found" in result

    def test_non_dict_step_skipped(self):
        preview = _preview(n_steps=2)
        preview["steps"].insert(1, "garbage string")  # type: ignore
        result = render_sequence_preview_html(sequence_id="seq_abc", preview=preview)
        # Only the two valid steps should render
        assert result.count('class="step-num"') == 2

    def test_missing_steps_key(self):
        preview = _preview()
        preview.pop("steps")
        result = render_sequence_preview_html(sequence_id="seq_abc", preview=preview)
        # Renders empty steps block without raising
        assert "No steps configured" in result

    def test_missing_channels_key(self):
        preview = _preview(n_channels=0)
        preview.pop("channels")
        result = render_sequence_preview_html(sequence_id="seq_abc", preview=preview)
        assert "No channels configured" in result


# ---------------------------------------------------------------------------
# Plaintext fallback
# ---------------------------------------------------------------------------


class TestSequencePreviewTextFallback:
    def test_none_preview_returns_not_found(self):
        result = render_sequence_preview_text_fallback(
            sequence_id="seq_missing", preview=None
        )
        assert "seq_missing" in result
        assert "Not found" in result

    def test_plaintext_renders_steps(self):
        result = render_sequence_preview_text_fallback(
            sequence_id="seq_abc", preview=_preview(n_steps=2)
        )
        assert "Outbound to VP Sales" in result
        assert "# " in result
        assert "[email]" in result or "[linkedin_connection]" in result
        # Subject wins over body in _extract_step_body preference list.
        assert "Subject 0" in result

    def test_plaintext_renders_channels(self):
        result = render_sequence_preview_text_fallback(
            sequence_id="seq_abc", preview=_preview(n_channels=2)
        )
        assert "user0@example.com" in result

    def test_plaintext_step_cap(self):
        preview = _preview(n_steps=_MAX_STEPS_RENDERED + 5)
        result = render_sequence_preview_text_fallback(
            sequence_id="seq_abc", preview=preview
        )
        assert "and 5 more" in result

    def test_empty_dict_plaintext_has_no_steps(self):
        result = render_sequence_preview_text_fallback(sequence_id="seq", preview={})
        # Treated same as None — not found
        assert "Not found" in result
