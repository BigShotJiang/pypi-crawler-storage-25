"""Tests for the campaign sequence renderer (upgrade 4 — surface #22).

Covers:
  - `_campaign_step_channel_palette` (known/unknown/None/case/whitespace)
  - `_campaign_step_mode_palette` (aliases auto/automatic)
  - `_campaign_step_personalization_palette` (high/medium/low/none)
  - `_group_campaign_steps_by_day` (int/str-int/None ordering, unscheduled
    bucket trailing)
  - `render_campaign_sequence_html` (empty states, header, day grouping,
    channel summary, chips, condition line, overflow, escaping)
  - `render_campaign_sequence_text_fallback` (empty states, markdown
    headers, chip metadata, overflow)
"""

from __future__ import annotations

from g8_mcp_server.app_renderer import (
    _CAMPAIGN_STEP_CHANNEL_DEFAULT,
    _CAMPAIGN_STEP_MODE_DEFAULT,
    _CAMPAIGN_STEP_PERSONALIZATION_DEFAULT,
    _MAX_CAMPAIGN_STEP_NAME_LEN,
    _MAX_CAMPAIGN_STEPS_RENDERED,
    _campaign_step_channel_palette,
    _campaign_step_mode_palette,
    _campaign_step_personalization_palette,
    _group_campaign_steps_by_day,
    render_campaign_sequence_html,
    render_campaign_sequence_text_fallback,
)


def _step(
    id_: str = "s1",
    name: str | None = "Intro email",
    channel: str | None = "email",
    mode: str | None = "automatic",
    day: int | None = 0,
    angle_id: str | None = "angle_1",
    cta_type: str | None = "soft_ask",
    personalization_level: str | None = "medium",
    condition: str | None = None,
) -> dict:
    return {
        "id": id_,
        "name": name,
        "channel": channel,
        "mode": mode,
        "day": day,
        "angle_id": angle_id,
        "cta_type": cta_type,
        "personalization_level": personalization_level,
        "condition": condition,
    }


# ---------------------------------------------------------------------------
# _campaign_step_channel_palette
# ---------------------------------------------------------------------------


class TestChannelPalette:
    def test_email_blue(self):
        assert _campaign_step_channel_palette("email")["fg"] == "#1e40af"

    def test_linkedin_indigo(self):
        assert _campaign_step_channel_palette("linkedin")["fg"] == "#7d2df3"

    def test_sms_green(self):
        assert _campaign_step_channel_palette("sms")["fg"] == "#059669"  # was banned #166534

    def test_whatsapp_green(self):
        assert _campaign_step_channel_palette("whatsapp")["fg"] == "#059669"  # was banned #166534

    def test_phone_amber(self):
        assert _campaign_step_channel_palette("phone")["fg"] == "#92400e"

    def test_call_amber(self):
        assert _campaign_step_channel_palette("call")["fg"] == "#92400e"

    def test_voice_amber(self):
        assert _campaign_step_channel_palette("voice")["fg"] == "#92400e"

    def test_slack_purple(self):
        assert _campaign_step_channel_palette("slack")["fg"] == "#6b21a8"

    def test_task_neutral(self):
        assert _campaign_step_channel_palette("task")["fg"] == "#0A0A0A"

    def test_case_insensitive(self):
        assert _campaign_step_channel_palette("EMAIL") == _campaign_step_channel_palette("email")

    def test_whitespace_stripped(self):
        assert _campaign_step_channel_palette("  email  ") == _campaign_step_channel_palette("email")

    def test_none_defaults(self):
        assert _campaign_step_channel_palette(None) == _CAMPAIGN_STEP_CHANNEL_DEFAULT

    def test_empty_defaults(self):
        assert _campaign_step_channel_palette("") == _CAMPAIGN_STEP_CHANNEL_DEFAULT

    def test_unknown_defaults(self):
        assert _campaign_step_channel_palette("carrier-pigeon") == _CAMPAIGN_STEP_CHANNEL_DEFAULT


# ---------------------------------------------------------------------------
# _campaign_step_mode_palette
# ---------------------------------------------------------------------------


class TestModePalette:
    def test_automatic_green(self):
        assert _campaign_step_mode_palette("automatic")["fg"] == "#059669"  # was banned #166534

    def test_auto_alias_green(self):
        assert _campaign_step_mode_palette("auto")["fg"] == "#059669"  # was banned #166534

    def test_no_banned_hexes_in_channel_palette(self):
        """Lock test — no banned Studio hex reintroduced into channel palette."""
        from g8_mcp_server.app_renderer import _CAMPAIGN_STEP_CHANNEL_COLORS

        banned = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}
        for _channel, pal in _CAMPAIGN_STEP_CHANNEL_COLORS.items():
            for _k, value in pal.items():
                assert value.lower() not in banned, (
                    f"banned Studio hex {value} resurfaced in channel palette"
                )

    def test_no_banned_hexes_in_mode_palette(self):
        """Lock test — no banned Studio hex reintroduced into mode palette."""
        from g8_mcp_server.app_renderer import _CAMPAIGN_STEP_MODE_COLORS

        banned = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}
        for _mode, pal in _CAMPAIGN_STEP_MODE_COLORS.items():
            for _k, value in pal.items():
                assert value.lower() not in banned, (
                    f"banned Studio hex {value} resurfaced in mode palette"
                )

    def test_manual_amber(self):
        assert _campaign_step_mode_palette("manual")["fg"] == "#92400e"

    def test_semi_auto_indigo(self):
        assert _campaign_step_mode_palette("semi_auto")["fg"] == "#7d2df3"

    def test_case_insensitive(self):
        assert _campaign_step_mode_palette("MANUAL") == _campaign_step_mode_palette("manual")

    def test_none_defaults(self):
        assert _campaign_step_mode_palette(None) == _CAMPAIGN_STEP_MODE_DEFAULT

    def test_empty_defaults(self):
        assert _campaign_step_mode_palette("") == _CAMPAIGN_STEP_MODE_DEFAULT

    def test_unknown_defaults(self):
        assert _campaign_step_mode_palette("weird") == _CAMPAIGN_STEP_MODE_DEFAULT


# ---------------------------------------------------------------------------
# _campaign_step_personalization_palette
# ---------------------------------------------------------------------------


class TestPersonalizationPalette:
    def test_high_indigo(self):
        assert _campaign_step_personalization_palette("high")["fg"] == "#7d2df3"

    def test_medium_blue(self):
        assert _campaign_step_personalization_palette("medium")["fg"] == "#1e40af"

    def test_low_gray(self):
        assert _campaign_step_personalization_palette("low")["fg"] == "#777777"

    def test_none_level_gray(self):
        # Note: "none" as a string, not Python None
        assert _campaign_step_personalization_palette("none")["fg"] == "#777777"

    def test_case_insensitive(self):
        assert _campaign_step_personalization_palette("HIGH") == _campaign_step_personalization_palette("high")

    def test_none_defaults(self):
        assert _campaign_step_personalization_palette(None) == _CAMPAIGN_STEP_PERSONALIZATION_DEFAULT

    def test_empty_defaults(self):
        assert _campaign_step_personalization_palette("") == _CAMPAIGN_STEP_PERSONALIZATION_DEFAULT

    def test_unknown_defaults(self):
        assert _campaign_step_personalization_palette("xyz") == _CAMPAIGN_STEP_PERSONALIZATION_DEFAULT


# ---------------------------------------------------------------------------
# _group_campaign_steps_by_day
# ---------------------------------------------------------------------------


class TestGroupStepsByDay:
    def test_empty_returns_empty(self):
        assert _group_campaign_steps_by_day([]) == []

    def test_single_day(self):
        steps = [_step(day=0)]
        result = _group_campaign_steps_by_day(steps)
        assert len(result) == 1
        assert result[0][0] == 0

    def test_multiple_days_ascending(self):
        steps = [
            _step(id_="a", day=5),
            _step(id_="b", day=0),
            _step(id_="c", day=2),
        ]
        result = _group_campaign_steps_by_day(steps)
        days = [d for d, _ in result]
        assert days == [0, 2, 5]

    def test_none_day_trailing(self):
        steps = [
            _step(id_="a", day=2),
            _step(id_="b", day=None),
            _step(id_="c", day=0),
        ]
        result = _group_campaign_steps_by_day(steps)
        days = [d for d, _ in result]
        assert days == [0, 2, None]

    def test_string_day_coerced(self):
        """Backend sometimes serializes day as a string; should still sort numerically."""
        steps = [
            _step(id_="a", day="10"),  # type: ignore[arg-type]
            _step(id_="b", day="2"),  # type: ignore[arg-type]
        ]
        result = _group_campaign_steps_by_day(steps)
        days = [d for d, _ in result]
        assert days == [2, 10]

    def test_negative_day_sorts_first(self):
        """Day -1 (pre-kickoff) should come before day 0."""
        steps = [
            _step(id_="a", day=0),
            _step(id_="b", day=-1),
        ]
        result = _group_campaign_steps_by_day(steps)
        days = [d for d, _ in result]
        assert days == [-1, 0]

    def test_garbage_day_goes_to_none_bucket(self):
        steps = [
            _step(id_="a", day="NaN"),  # type: ignore[arg-type]
            _step(id_="b", day=0),
        ]
        result = _group_campaign_steps_by_day(steps)
        days = [d for d, _ in result]
        assert days == [0, None]

    def test_same_day_steps_preserved(self):
        steps = [
            _step(id_="a", day=0),
            _step(id_="b", day=0),
            _step(id_="c", day=0),
        ]
        result = _group_campaign_steps_by_day(steps)
        assert len(result) == 1
        assert len(result[0][1]) == 3


# ---------------------------------------------------------------------------
# render_campaign_sequence_html — empty states
# ---------------------------------------------------------------------------


class TestRenderHtmlEmpty:
    def test_none_returns_empty_state(self):
        html = render_campaign_sequence_html(
            steps=None, campaign_id="c1", campaign_name="Q4"
        )
        assert "No sequence steps" in html

    def test_empty_list_returns_empty_state(self):
        html = render_campaign_sequence_html(
            steps=[], campaign_id="c1", campaign_name="Q4"
        )
        assert "No sequence steps" in html

    def test_non_list_returns_empty_state(self):
        html = render_campaign_sequence_html(
            steps="garbage",  # type: ignore[arg-type]
            campaign_id="c1",
            campaign_name="Q4",
        )
        assert "No sequence steps" in html

    def test_only_garbage_items_returns_empty_state(self):
        html = render_campaign_sequence_html(
            steps=[1, "x", None],  # type: ignore[list-item]
            campaign_id="c1",
            campaign_name="Q4",
        )
        assert "No sequence steps" in html

    def test_default_campaign_name_fallback(self):
        html = render_campaign_sequence_html(
            steps=None, campaign_id="c1", campaign_name=None
        )
        assert "Campaign" in html

    def test_empty_state_escapes_id(self):
        html = render_campaign_sequence_html(
            steps=[],
            campaign_id="<b>x</b>",
            campaign_name="Q",
        )
        assert "<b>x</b>" not in html
        assert "&lt;b&gt;x&lt;/b&gt;" in html


# ---------------------------------------------------------------------------
# render_campaign_sequence_html — populated
# ---------------------------------------------------------------------------


class TestRenderHtmlPopulated:
    def test_header_shows_campaign_name(self):
        html = render_campaign_sequence_html(
            steps=[_step()], campaign_id="c1", campaign_name="Q4 Push"
        )
        assert "Q4 Push" in html

    def test_header_shows_campaign_id(self):
        html = render_campaign_sequence_html(
            steps=[_step()], campaign_id="camp_abc", campaign_name="X"
        )
        assert "camp_abc" in html

    def test_header_escapes_name(self):
        html = render_campaign_sequence_html(
            steps=[_step()],
            campaign_id="c1",
            campaign_name="<script>xss</script>",
        )
        assert "<script>xss</script>" not in html
        assert "&lt;script&gt;" in html

    def test_total_step_count(self):
        html = render_campaign_sequence_html(
            steps=[_step(id_="a", day=0), _step(id_="b", day=2)],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "2 step(s)" in html

    def test_day_count(self):
        html = render_campaign_sequence_html(
            steps=[_step(id_="a", day=0), _step(id_="b", day=2), _step(id_="c", day=5)],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "3 day(s)" in html

    def test_day_0_labeled_kickoff(self):
        html = render_campaign_sequence_html(
            steps=[_step(day=0)], campaign_id="c1", campaign_name="X"
        )
        assert "Day 0 (kickoff)" in html

    def test_day_n_labeled(self):
        html = render_campaign_sequence_html(
            steps=[_step(day=5)], campaign_id="c1", campaign_name="X"
        )
        assert "Day 5" in html

    def test_unscheduled_label(self):
        html = render_campaign_sequence_html(
            steps=[_step(day=None)], campaign_id="c1", campaign_name="X"
        )
        assert "Unscheduled" in html

    def test_step_name_rendered(self):
        html = render_campaign_sequence_html(
            steps=[_step(name="Intro handshake")],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "Intro handshake" in html

    def test_step_name_escaped(self):
        html = render_campaign_sequence_html(
            steps=[_step(name="<img src=x>")],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "<img src=x>" not in html
        assert "&lt;img" in html

    def test_step_name_truncated(self):
        long_name = "A" * 500
        html = render_campaign_sequence_html(
            steps=[_step(name=long_name)],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "A" * (_MAX_CAMPAIGN_STEP_NAME_LEN + 10) not in html

    def test_id_fallback_when_no_name(self):
        html = render_campaign_sequence_html(
            steps=[_step(id_="step_xyz", name=None)],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "step_xyz" in html

    def test_channel_chip_rendered(self):
        html = render_campaign_sequence_html(
            steps=[_step(channel="email")],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "email" in html
        # Blue channel palette
        assert "#1e40af" in html

    def test_mode_chip_rendered(self):
        html = render_campaign_sequence_html(
            steps=[_step(mode="manual")],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "manual" in html
        # Amber mode palette
        assert "#92400e" in html

    def test_cta_chip_rendered(self):
        html = render_campaign_sequence_html(
            steps=[_step(cta_type="hard_ask")],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "hard_ask" in html

    def test_personalization_chip_rendered(self):
        html = render_campaign_sequence_html(
            steps=[_step(personalization_level="high")],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "high" in html

    def test_angle_chip_rendered(self):
        html = render_campaign_sequence_html(
            steps=[_step(angle_id="angle_contrarian")],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "angle: angle_contrarian" in html

    def test_condition_rendered(self):
        html = render_campaign_sequence_html(
            steps=[_step(condition="opened_prev_email")],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "if: opened_prev_email" in html

    def test_condition_escaped(self):
        html = render_campaign_sequence_html(
            steps=[_step(condition="<script>alert(1)</script>")],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "<script>alert(1)</script>" not in html

    def test_condition_hidden_when_missing(self):
        html = render_campaign_sequence_html(
            steps=[_step(condition=None)],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "if:" not in html

    def test_channel_summary_pills_rendered(self):
        """Header shows distinct channel pills across the plan."""
        html = render_campaign_sequence_html(
            steps=[
                _step(id_="a", channel="email", day=0),
                _step(id_="b", channel="linkedin", day=2),
                _step(id_="c", channel="email", day=5),  # duplicate
            ],
            campaign_id="c1",
            campaign_name="X",
        )
        # Both channels should appear in the summary section
        assert html.count('class="cseq-summary-pill"') == 2

    def test_overflow_footer_shown_when_capped(self):
        steps = [
            _step(id_=f"s{i}", name=f"Step {i}", day=i)
            for i in range(_MAX_CAMPAIGN_STEPS_RENDERED + 5)
        ]
        html = render_campaign_sequence_html(
            steps=steps, campaign_id="c1", campaign_name="X"
        )
        assert "5 step(s) omitted" in html

    def test_overflow_hidden_when_under_cap(self):
        steps = [_step(id_=f"s{i}", day=i) for i in range(3)]
        html = render_campaign_sequence_html(
            steps=steps, campaign_id="c1", campaign_name="X"
        )
        assert "omitted" not in html

    def test_step_numbering_resets_per_day(self):
        """Step numbers inside a day reset to 1 — not global."""
        html = render_campaign_sequence_html(
            steps=[
                _step(id_="a", day=0, name="A"),
                _step(id_="b", day=0, name="B"),
                _step(id_="c", day=2, name="C"),
            ],
            campaign_id="c1",
            campaign_name="X",
        )
        # Day 0 has steps 1, 2; Day 2 has step 1 again — the numeral "1"
        # must appear at least twice.
        assert html.count('class="cseq-step-num">1<') >= 2

    def test_skips_non_dict_steps(self):
        html = render_campaign_sequence_html(
            steps=[
                None,  # type: ignore[list-item]
                "garbage",  # type: ignore[list-item]
                _step(name="Real Step"),
                42,  # type: ignore[list-item]
            ],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "Real Step" in html

    def test_steps_grouped_in_day_order(self):
        """Earlier days should appear before later days in the output."""
        html = render_campaign_sequence_html(
            steps=[
                _step(id_="late", name="Later Step", day=5),
                _step(id_="early", name="Early Step", day=0),
            ],
            campaign_id="c1",
            campaign_name="X",
        )
        assert html.index("Early Step") < html.index("Later Step")


# ---------------------------------------------------------------------------
# render_campaign_sequence_text_fallback
# ---------------------------------------------------------------------------


class TestRenderTextFallback:
    def test_none_empty_state(self):
        text = render_campaign_sequence_text_fallback(
            steps=None, campaign_id="c1", campaign_name="Q4"
        )
        assert "No steps configured yet" in text
        assert "Q4" in text

    def test_empty_list_empty_state(self):
        text = render_campaign_sequence_text_fallback(
            steps=[], campaign_id="c1", campaign_name="Q4"
        )
        assert "No steps configured yet" in text

    def test_non_list_empty_state(self):
        text = render_campaign_sequence_text_fallback(
            steps="garbage",  # type: ignore[arg-type]
            campaign_id="c1",
            campaign_name="Q4",
        )
        assert "No steps configured yet" in text

    def test_only_garbage_items_empty_state(self):
        text = render_campaign_sequence_text_fallback(
            steps=[1, "x", None],  # type: ignore[list-item]
            campaign_id="c1",
            campaign_name="Q4",
        )
        assert "No steps configured yet" in text

    def test_campaign_id_shown(self):
        text = render_campaign_sequence_text_fallback(
            steps=[_step()], campaign_id="camp_xyz", campaign_name="X"
        )
        assert "camp_xyz" in text

    def test_default_campaign_name(self):
        text = render_campaign_sequence_text_fallback(
            steps=[_step()], campaign_id="c1", campaign_name=None
        )
        assert "Campaign" in text

    def test_step_count_line(self):
        text = render_campaign_sequence_text_fallback(
            steps=[_step(id_="a", day=0), _step(id_="b", day=2)],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "2 step(s)" in text
        assert "2 day(s)" in text

    def test_day_0_kickoff_label(self):
        text = render_campaign_sequence_text_fallback(
            steps=[_step(day=0)], campaign_id="c1", campaign_name="X"
        )
        assert "Day 0 (kickoff)" in text

    def test_day_n_label(self):
        text = render_campaign_sequence_text_fallback(
            steps=[_step(day=5)], campaign_id="c1", campaign_name="X"
        )
        assert "Day 5" in text

    def test_unscheduled_label(self):
        text = render_campaign_sequence_text_fallback(
            steps=[_step(day=None)], campaign_id="c1", campaign_name="X"
        )
        assert "Unscheduled" in text

    def test_markdown_headers(self):
        text = render_campaign_sequence_text_fallback(
            steps=[_step()], campaign_id="c1", campaign_name="X"
        )
        assert text.startswith("# Campaign sequence")
        assert "## Day 0" in text

    def test_channel_in_row(self):
        text = render_campaign_sequence_text_fallback(
            steps=[_step(channel="linkedin")],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "<linkedin>" in text

    def test_mode_in_row(self):
        text = render_campaign_sequence_text_fallback(
            steps=[_step(mode="manual")],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "[manual]" in text

    def test_cta_in_row(self):
        text = render_campaign_sequence_text_fallback(
            steps=[_step(cta_type="hard_ask")],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "cta=hard_ask" in text

    def test_personalization_in_row(self):
        text = render_campaign_sequence_text_fallback(
            steps=[_step(personalization_level="high")],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "personalization=high" in text

    def test_angle_in_row(self):
        text = render_campaign_sequence_text_fallback(
            steps=[_step(angle_id="angle_contrarian")],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "angle=angle_contrarian" in text

    def test_condition_line(self):
        text = render_campaign_sequence_text_fallback(
            steps=[_step(condition="opened_prev")],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "if: opened_prev" in text

    def test_condition_hidden_when_missing(self):
        text = render_campaign_sequence_text_fallback(
            steps=[_step(condition=None)], campaign_id="c1", campaign_name="X"
        )
        assert "if:" not in text

    def test_step_number_starts_at_1(self):
        text = render_campaign_sequence_text_fallback(
            steps=[_step()], campaign_id="c1", campaign_name="X"
        )
        assert "1. " in text

    def test_step_numbering_per_day(self):
        """Numbers reset each day section."""
        text = render_campaign_sequence_text_fallback(
            steps=[
                _step(id_="a", name="A", day=0),
                _step(id_="b", name="B", day=0),
                _step(id_="c", name="C", day=2),
            ],
            campaign_id="c1",
            campaign_name="X",
        )
        # "1. " should appear at least twice (once per day's first step).
        assert text.count("1. ") >= 2

    def test_overflow_suffix_shown_when_capped(self):
        steps = [
            _step(id_=f"s{i}", day=i)
            for i in range(_MAX_CAMPAIGN_STEPS_RENDERED + 3)
        ]
        text = render_campaign_sequence_text_fallback(
            steps=steps, campaign_id="c1", campaign_name="X"
        )
        assert "3 more step(s)" in text

    def test_overflow_hidden_when_under_cap(self):
        text = render_campaign_sequence_text_fallback(
            steps=[_step(id_=f"s{i}", day=i) for i in range(3)],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "more step" not in text

    def test_trailing_newline(self):
        text = render_campaign_sequence_text_fallback(
            steps=[_step()], campaign_id="c1", campaign_name="X"
        )
        assert text.endswith("\n")

    def test_id_fallback_when_no_name(self):
        text = render_campaign_sequence_text_fallback(
            steps=[_step(id_="step_abc", name=None)],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "step_abc" in text
