"""Unit tests for HTML app surface #46 — company contacts renderer.

Surface #46 renders the per-company contact roster at
`g8://companies/{company_id}/contacts` + `.txt`. Sibling to surface #38
(list-members). Backend returns `CompanyContactItem[]` from
`GET /companies/{company_id}/contacts`.

Coverage:
- Helpers (clip, display_name, location, bucket_seniority, counts, stat_card)
- Empty-state (both modes)
- render_company_contacts_html (None → unavailable, [] → empty, full render)
- render_company_contacts_text_fallback (markdown mirror)
- Regression locks:
    - No single-side colored accent borders (AI-tell)
    - No legacy accent hexes (non-graph8 tokens)
    - 60-row overflow
    - Drill-up points at siblings #26 / #37 / #42, not self
    - Header says Contacts (scoped to the company)
"""

from __future__ import annotations

import pytest

from g8_mcp_server.app_renderer import (
    _COMPANY_CONTACTS_SENIORITY_ORDER,
    _MAX_COMPANY_CONTACTS_RENDERED,
    _MAX_COMPANY_CONTACTS_SENIORITY_RENDERED,
    _MAX_COMPANY_CONTACT_NAME_LEN,
    _company_contacts_bucket_seniority,
    _company_contacts_clip,
    _company_contacts_display_name,
    _company_contacts_location,
    _company_contacts_stat_card,
    _company_contacts_with_email_count,
    _company_contacts_with_phone_count,
    _render_company_contacts_empty_state_html,
    render_company_contacts_html,
    render_company_contacts_text_fallback,
)


# graph8 token regressions ---------------------------------------------------

_LEGACY_ACCENT_HEXES = (
    "#6366f1",   # pre-graph8 indigo primary
    "#4f46e5",   # pre-graph8 indigo dark
    "#10b981",   # pre-graph8 success green (not the new palette)
    "#ec4899",   # pre-graph8 pink
    "#dc2626",   # pre-graph8 destructive
    "#16a34a",   # pre-graph8 success
)


# ---------------------------------------------------------------------------
# TestClip
# ---------------------------------------------------------------------------


class TestClip:
    def test_none_returns_empty(self):
        assert _company_contacts_clip(None, 50) == ""

    def test_non_string_returns_empty(self):
        assert _company_contacts_clip(123, 50) == ""
        assert _company_contacts_clip([], 50) == ""

    def test_whitespace_only_returns_empty(self):
        assert _company_contacts_clip("   ", 50) == ""
        assert _company_contacts_clip("\n\t", 50) == ""

    def test_short_passes_through(self):
        assert _company_contacts_clip("hello", 50) == "hello"

    def test_long_is_clipped_with_ellipsis(self):
        long = "x" * 100
        out = _company_contacts_clip(long, 20)
        assert out.endswith("…")
        assert len(out) <= 20

    def test_html_escape(self):
        out = _company_contacts_clip("<script>alert(1)</script>", 200)
        assert "<script>" not in out
        assert "&lt;script&gt;" in out

    def test_strips_whitespace(self):
        assert _company_contacts_clip("  foo  ", 50) == "foo"


# ---------------------------------------------------------------------------
# TestDisplayName
# ---------------------------------------------------------------------------


class TestDisplayName:
    def test_full_name_wins(self):
        contact = {"full_name": "Alice Chen", "first_name": "Al", "last_name": "C"}
        assert _company_contacts_display_name(contact) == "Alice Chen"

    def test_first_last_concatenation(self):
        assert _company_contacts_display_name({"first_name": "Bob", "last_name": "Smith"}) == "Bob Smith"

    def test_email_fallback(self):
        assert _company_contacts_display_name({"work_email": "x@y.com"}) == "x@y.com"

    def test_unnamed_default(self):
        assert _company_contacts_display_name({}) == "(unnamed contact)"

    def test_non_dict(self):
        assert _company_contacts_display_name(None) == "(unnamed contact)"
        assert _company_contacts_display_name("nope") == "(unnamed contact)"

    def test_full_name_empty_falls_through_to_first_last(self):
        contact = {"full_name": "", "first_name": "Cara", "last_name": "Liu"}
        assert _company_contacts_display_name(contact) == "Cara Liu"

    def test_full_name_whitespace_falls_through(self):
        contact = {"full_name": "   ", "first_name": "Dan", "last_name": "Park"}
        assert _company_contacts_display_name(contact) == "Dan Park"

    def test_html_escape_in_name(self):
        contact = {"full_name": "<script>x</script>"}
        out = _company_contacts_display_name(contact)
        assert "<script>" not in out
        assert "&lt;script&gt;" in out

    def test_long_name_clipped(self):
        contact = {"full_name": "x" * 500}
        out = _company_contacts_display_name(contact)
        assert len(out) <= _MAX_COMPANY_CONTACT_NAME_LEN


# ---------------------------------------------------------------------------
# TestLocation
# ---------------------------------------------------------------------------


class TestLocation:
    def test_full_location(self):
        c = {"city": "SF", "state": "CA", "country": "US"}
        assert _company_contacts_location(c) == "SF, CA, US"

    def test_partial_location_city_only(self):
        assert _company_contacts_location({"city": "Berlin"}) == "Berlin"

    def test_partial_location_state_country(self):
        assert _company_contacts_location({"state": "TX", "country": "US"}) == "TX, US"

    def test_empty_returns_blank(self):
        assert _company_contacts_location({}) == ""

    def test_non_dict_returns_blank(self):
        assert _company_contacts_location(None) == ""

    def test_whitespace_fields_skipped(self):
        c = {"city": "  ", "state": "NY", "country": ""}
        assert _company_contacts_location(c) == "NY"

    def test_html_escape_in_location(self):
        c = {"city": "<x>", "state": "CA", "country": "US"}
        out = _company_contacts_location(c)
        assert "<x>" not in out
        assert "&lt;x&gt;" in out


# ---------------------------------------------------------------------------
# TestBucketSeniority
# ---------------------------------------------------------------------------


class TestBucketSeniority:
    def test_buckets_and_counts(self):
        contacts = [
            {"seniority_level": "vp"},
            {"seniority_level": "vp"},
            {"seniority_level": "director"},
        ]
        result = _company_contacts_bucket_seniority(contacts)
        assert ("vp", 2) in result
        assert ("director", 1) in result

    def test_missing_seniority_buckets_as_unknown(self):
        contacts = [{"first_name": "x"}, {"seniority_level": ""}]
        result = _company_contacts_bucket_seniority(contacts)
        assert ("unknown", 2) in result

    def test_sort_order_desc_count_then_canonical(self):
        contacts = [
            {"seniority_level": "director"},  # 1
            {"seniority_level": "vp"},        # 1
            {"seniority_level": "c_suite"},   # 1
            {"seniority_level": "c_suite"},   # 2 total
        ]
        result = _company_contacts_bucket_seniority(contacts)
        # c_suite (2) first (tied counts ordered by canonical — c_suite leads)
        assert result[0] == ("c_suite", 2)
        # then vp (canonical index 3) before director (canonical index 4)
        assert result[1] == ("vp", 1)
        assert result[2] == ("director", 1)

    def test_unknown_ordered_last_when_tied(self):
        contacts = [{"seniority_level": "ic"}, {"seniority_level": ""}]
        result = _company_contacts_bucket_seniority(contacts)
        # tied on count 1 — "ic" has canonical index, "unknown" tied on canonical 11
        assert result[0][0] == "ic"
        assert result[1][0] == "unknown"

    def test_canonical_order_is_stable(self):
        # Stability proof against _COMPANY_CONTACTS_SENIORITY_ORDER mutation
        assert _COMPANY_CONTACTS_SENIORITY_ORDER[0] == "c_suite"
        assert _COMPANY_CONTACTS_SENIORITY_ORDER[-1] == "unknown"

    def test_non_dict_contacts_filtered(self):
        result = _company_contacts_bucket_seniority(["x", None, {"seniority_level": "vp"}])
        assert result == [("vp", 1)]

    def test_case_insensitive(self):
        contacts = [{"seniority_level": "VP"}, {"seniority_level": "vp"}]
        result = _company_contacts_bucket_seniority(contacts)
        assert result == [("vp", 2)]


# ---------------------------------------------------------------------------
# TestEmailPhoneCounts
# ---------------------------------------------------------------------------


class TestEmailPhoneCounts:
    def test_with_email_count(self):
        contacts = [
            {"work_email": "a@b.com"},
            {"work_email": ""},
            {"work_email": None},
            {"work_email": "c@d.com"},
        ]
        assert _company_contacts_with_email_count(contacts) == 2

    def test_with_email_count_strips_whitespace(self):
        assert _company_contacts_with_email_count([{"work_email": "   "}]) == 0

    def test_with_email_count_non_string(self):
        assert _company_contacts_with_email_count([{"work_email": 123}]) == 0

    def test_with_email_count_non_dict(self):
        assert _company_contacts_with_email_count(["x", None, {"work_email": "a@b.com"}]) == 1

    def test_with_phone_count(self):
        contacts = [{"direct_phone": "+1234"}, {"direct_phone": ""}, {}]
        assert _company_contacts_with_phone_count(contacts) == 1

    def test_with_phone_count_empty(self):
        assert _company_contacts_with_phone_count([]) == 0


# ---------------------------------------------------------------------------
# TestStatCard
# ---------------------------------------------------------------------------


class TestStatCard:
    def test_renders_card_with_label_and_value(self):
        html = _company_contacts_stat_card("Total", "42")
        assert "Total" in html
        assert "42" in html

    def test_accent_uses_primary(self):
        html = _company_contacts_stat_card("Total", "42", accent=True)
        assert "#7d2df3" in html

    def test_non_accent_uses_text_color(self):
        html = _company_contacts_stat_card("Total", "42", accent=False)
        assert "#7d2df3" not in html.lower() or "color:#7d2df3" not in html

    def test_uniform_border_not_single_side(self):
        html = _company_contacts_stat_card("Total", "42")
        # Must have "border:1px solid #dfdfdf" (uniform) — not "border-left"
        assert "border:1px solid" in html
        assert "border-left" not in html
        assert "border-right" not in html
        assert "border-top:" not in html
        assert "border-bottom:" not in html

    def test_html_escape_label_and_value(self):
        html = _company_contacts_stat_card("<x>", "<y>")
        assert "<x>" not in html
        assert "<y>" not in html
        assert "&lt;x&gt;" in html
        assert "&lt;y&gt;" in html


# ---------------------------------------------------------------------------
# TestEmptyState
# ---------------------------------------------------------------------------


class TestEmptyState:
    def test_empty_mode(self):
        html = _render_company_contacts_empty_state_html("42", mode="empty")
        assert "No contacts linked to this company yet" in html
        assert "company_id=42" in html or "(company_id=42)" in html

    def test_unavailable_mode(self):
        html = _render_company_contacts_empty_state_html("42", mode="unavailable")
        assert "Company contacts not available" in html

    def test_graph8_tokens_present(self):
        html = _render_company_contacts_empty_state_html("42", mode="empty")
        assert "#7d2df3" in html
        assert "#dfdfdf" in html
        assert "Aeonik" in html

    def test_doctype_html5(self):
        html = _render_company_contacts_empty_state_html("42", mode="empty")
        assert html.startswith("<!DOCTYPE html>")

    def test_title_has_company_id(self):
        html = _render_company_contacts_empty_state_html("42", mode="empty")
        assert "Company 42 — contacts" in html

    def test_no_legacy_hexes(self):
        html = _render_company_contacts_empty_state_html("42", mode="empty").lower()
        for hex_code in _LEGACY_ACCENT_HEXES:
            assert hex_code.lower() not in html


# ---------------------------------------------------------------------------
# TestRenderHtml
# ---------------------------------------------------------------------------


@pytest.fixture
def sample_contacts():
    return [
        {
            "id": 1,
            "first_name": "Alice",
            "last_name": "Chen",
            "full_name": "Alice Chen",
            "work_email": "alice@acme.com",
            "job_title": "VP Engineering",
            "seniority_level": "vp",
            "direct_phone": "+1-555-0100",
            "linkedin_url": "https://linkedin.com/in/alice",
            "city": "San Francisco",
            "state": "CA",
            "country": "US",
        },
        {
            "id": 2,
            "first_name": "Bob",
            "last_name": "Smith",
            "full_name": "Bob Smith",
            "work_email": "bob@acme.com",
            "job_title": "Senior Engineer",
            "seniority_level": "senior",
            "direct_phone": None,
            "linkedin_url": None,
            "city": "Austin",
            "state": "TX",
            "country": "US",
        },
    ]


class TestRenderHtml:
    def test_none_returns_unavailable(self):
        html = render_company_contacts_html(contacts=None, company_id="42")
        assert "Company contacts not available" in html

    def test_empty_list_returns_empty_state(self):
        html = render_company_contacts_html(contacts=[], company_id="42")
        assert "No contacts linked to this company yet" in html

    def test_full_render_has_total(self, sample_contacts):
        html = render_company_contacts_html(contacts=sample_contacts, company_id="42")
        assert "2 TOTAL" in html

    def test_full_render_has_stat_cards(self, sample_contacts):
        html = render_company_contacts_html(contacts=sample_contacts, company_id="42")
        assert "Total contacts" in html
        assert "With email" in html
        assert "With phone" in html
        assert "Seniority levels" in html

    def test_seniority_mix_section_present(self, sample_contacts):
        html = render_company_contacts_html(contacts=sample_contacts, company_id="42")
        assert "Seniority mix" in html

    def test_contact_rows_rendered(self, sample_contacts):
        html = render_company_contacts_html(contacts=sample_contacts, company_id="42")
        assert "Alice Chen" in html
        assert "Bob Smith" in html

    def test_job_titles_rendered(self, sample_contacts):
        html = render_company_contacts_html(contacts=sample_contacts, company_id="42")
        assert "VP Engineering" in html

    def test_emails_rendered(self, sample_contacts):
        html = render_company_contacts_html(contacts=sample_contacts, company_id="42")
        assert "alice@acme.com" in html
        assert "bob@acme.com" in html

    def test_phone_chip_when_present(self, sample_contacts):
        html = render_company_contacts_html(contacts=sample_contacts, company_id="42")
        assert "+1-555-0100" in html

    def test_linkedin_pill_when_present(self, sample_contacts):
        html = render_company_contacts_html(contacts=sample_contacts, company_id="42")
        assert ">LinkedIn<" in html

    def test_location_rendered(self, sample_contacts):
        html = render_company_contacts_html(contacts=sample_contacts, company_id="42")
        assert "San Francisco, CA, US" in html

    def test_no_single_side_accent_borders(self, sample_contacts):
        html = render_company_contacts_html(contacts=sample_contacts, company_id="42")
        # AI-tell regression — single-side colored accent borders are banned
        assert "border-left:4px solid" not in html
        assert "border-left:3px solid" not in html
        assert "border-top:4px solid" not in html
        assert "border-bottom:4px solid" not in html

    def test_no_legacy_accent_hexes(self, sample_contacts):
        html = render_company_contacts_html(contacts=sample_contacts, company_id="42").lower()
        for hex_code in _LEGACY_ACCENT_HEXES:
            assert hex_code.lower() not in html

    def test_graph8_tokens_present(self, sample_contacts):
        html = render_company_contacts_html(contacts=sample_contacts, company_id="42")
        assert "#7d2df3" in html  # primary
        assert "#dfdfdf" in html  # border
        assert "Aeonik" in html

    def test_drill_up_has_parent_company(self, sample_contacts):
        html = render_company_contacts_html(contacts=sample_contacts, company_id="42")
        assert "g8://companies/42" in html

    def test_drill_up_has_company_notes(self, sample_contacts):
        html = render_company_contacts_html(contacts=sample_contacts, company_id="42")
        assert "g8://companies/42/notes" in html

    def test_drill_up_has_company_deals(self, sample_contacts):
        html = render_company_contacts_html(contacts=sample_contacts, company_id="42")
        assert "g8://companies/42/deals" in html

    def test_drill_up_has_all_companies(self, sample_contacts):
        html = render_company_contacts_html(contacts=sample_contacts, company_id="42")
        # Not self-referential — do NOT list the current surface under drill-up
        assert "g8://companies</code>" in html

    def test_drill_up_has_fetch_endpoint(self, sample_contacts):
        html = render_company_contacts_html(contacts=sample_contacts, company_id="42")
        assert "GET /companies/42/contacts" in html

    def test_drill_up_has_add_contact(self, sample_contacts):
        html = render_company_contacts_html(contacts=sample_contacts, company_id="42")
        assert "POST /contacts" in html
        assert "company_id=42" in html

    def test_drill_up_does_NOT_list_self(self, sample_contacts):
        html = render_company_contacts_html(contacts=sample_contacts, company_id="42")
        drill_section_start = html.find("Drill into this company")
        assert drill_section_start != -1
        drill_section = html[drill_section_start:]
        # The self-URI (`/contacts`) should NOT appear as a drill-up resource
        # (it's the current surface). Fetch endpoint is fine though.
        assert "g8://companies/42/contacts</code>" not in drill_section

    def test_header_has_title_and_total_chip(self, sample_contacts):
        html = render_company_contacts_html(contacts=sample_contacts, company_id="42")
        assert "— contacts" in html
        assert "2 TOTAL" in html

    def test_header_uses_company_name_from_meta(self, sample_contacts):
        meta = {"name": "Acme Corp", "domain": "acme.com"}
        html = render_company_contacts_html(
            contacts=sample_contacts, company_id="42", company_meta=meta
        )
        assert "Acme Corp — contacts" in html
        assert "acme.com" in html

    def test_xss_in_name_escaped(self, sample_contacts):
        contacts = sample_contacts + [
            {"id": 99, "full_name": "<script>alert(1)</script>", "seniority_level": "ic"}
        ]
        html = render_company_contacts_html(contacts=contacts, company_id="42")
        assert "<script>alert(1)</script>" not in html
        assert "&lt;script&gt;" in html

    def test_xss_in_email_escaped(self):
        contacts = [{"id": 1, "work_email": "<img src=x onerror=y>"}]
        html = render_company_contacts_html(contacts=contacts, company_id="42")
        assert "<img src=x" not in html

    def test_xss_in_company_name_escaped(self, sample_contacts):
        meta = {"name": "<script>x</script>"}
        html = render_company_contacts_html(
            contacts=sample_contacts, company_id="42", company_meta=meta
        )
        assert "<script>x</script>" not in html

    def test_overflow_beyond_cap(self):
        contacts = [
            {"id": i, "full_name": f"Contact {i}", "work_email": f"c{i}@x.com"}
            for i in range(_MAX_COMPANY_CONTACTS_RENDERED + 5)
        ]
        html = render_company_contacts_html(contacts=contacts, company_id="42")
        assert "+ 5 more contacts" in html
        # offset link present
        assert f"offset={_MAX_COMPANY_CONTACTS_RENDERED}" in html

    def test_invalid_entries_filtered(self, sample_contacts):
        contacts = sample_contacts + ["not a dict", None, 123]
        html = render_company_contacts_html(contacts=contacts, company_id="42")
        assert "2 TOTAL" in html  # still 2 valid

    def test_non_dict_only_returns_empty(self):
        html = render_company_contacts_html(
            contacts=["nope", None, 1], company_id="42"
        )
        # All filtered out → empty render
        assert "No contacts linked to this company yet" in html

    def test_valid_doctype(self, sample_contacts):
        html = render_company_contacts_html(contacts=sample_contacts, company_id="42")
        assert html.startswith("<!DOCTYPE html>")

    def test_seniority_overflow(self):
        # Create more unique seniority buckets than the cap allows
        seniorities = [
            "c_suite", "executive", "founder", "vp", "director",
            "head", "manager", "lead", "senior", "ic", "entry",
        ]
        contacts = [
            {"id": i, "full_name": f"c{i}", "seniority_level": s}
            for i, s in enumerate(seniorities)
        ]
        html = render_company_contacts_html(contacts=contacts, company_id="42")
        # 11 unique levels, cap 8 → 3 more expected
        remaining = len(seniorities) - _MAX_COMPANY_CONTACTS_SENIORITY_RENDERED
        if remaining > 0:
            assert f"+ {remaining} more" in html


# ---------------------------------------------------------------------------
# TestTextFallback
# ---------------------------------------------------------------------------


class TestTextFallback:
    def test_none_returns_not_available(self):
        text = render_company_contacts_text_fallback(contacts=None, company_id="42")
        assert "not available" in text.lower()

    def test_empty_list_returns_empty_message(self):
        text = render_company_contacts_text_fallback(contacts=[], company_id="42")
        assert "no contacts yet" in text.lower()

    def test_headers_are_markdown(self):
        contacts = [{"id": 1, "full_name": "Alice"}]
        text = render_company_contacts_text_fallback(contacts=contacts, company_id="42")
        assert "# Company" in text or "# Acme" in text

    def test_stats_rendered(self):
        contacts = [
            {"id": 1, "full_name": "Alice", "work_email": "a@x.com"},
            {"id": 2, "full_name": "Bob", "work_email": "b@x.com", "direct_phone": "+1"},
        ]
        text = render_company_contacts_text_fallback(contacts=contacts, company_id="42")
        assert "Total contacts: 2" in text
        assert "With email: 2" in text
        assert "With phone: 1" in text

    def test_contact_rows(self):
        contacts = [
            {
                "id": 1, "full_name": "Alice Chen",
                "work_email": "a@x.com", "direct_phone": "+1-111",
                "job_title": "VP", "seniority_level": "vp",
                "city": "NYC",
            },
        ]
        text = render_company_contacts_text_fallback(contacts=contacts, company_id="42")
        assert "Alice Chen" in text
        assert "a@x.com" in text
        assert "+1-111" in text
        assert "title: VP" in text
        assert "[Vp]" in text  # seniority title-cased
        assert "location: NYC" in text

    def test_drill_up_pointers_in_text(self):
        contacts = [{"id": 1, "full_name": "Alice"}]
        text = render_company_contacts_text_fallback(contacts=contacts, company_id="42")
        assert "g8://companies/42" in text
        assert "g8://companies/42/notes" in text
        assert "g8://companies/42/deals" in text
        assert "GET /companies/42/contacts" in text
        assert "POST /contacts" in text
        assert "g8://companies" in text

    def test_drill_up_section_does_NOT_list_self(self):
        contacts = [{"id": 1, "full_name": "Alice"}]
        text = render_company_contacts_text_fallback(contacts=contacts, company_id="42")
        # Split at drill-up header
        header_idx = text.find("## Drill into this company")
        assert header_idx != -1
        tail = text[header_idx:]
        # Self URI (`g8://companies/42/contacts`) should NOT be listed
        # under drill-up — only the fetch endpoint (`GET ...`) may name it.
        for line in tail.splitlines():
            if line.strip().startswith("- Company") and "g8://companies/42/contacts" in line:
                pytest.fail(
                    f"drill-up should not self-reference: {line!r}"
                )

    def test_ends_with_newline(self):
        contacts = [{"id": 1, "full_name": "Alice"}]
        text = render_company_contacts_text_fallback(contacts=contacts, company_id="42")
        assert text.endswith("\n")

    def test_no_html_in_text_fallback(self):
        contacts = [
            {"id": 1, "full_name": "<script>x</script>", "work_email": "a@x.com"}
        ]
        text = render_company_contacts_text_fallback(contacts=contacts, company_id="42")
        # Text is plain markdown — HTML tags pass through as-is (not escaped)
        # but the renderer should not INJECT HTML itself (no <div>, <span>, etc.)
        for tag in ("<div", "<span", "<p>", "<h1>", "<code"):
            assert tag not in text

    def test_overflow_note(self):
        contacts = [
            {"id": i, "full_name": f"C{i}", "work_email": f"{i}@x.com"}
            for i in range(_MAX_COMPANY_CONTACTS_RENDERED + 3)
        ]
        text = render_company_contacts_text_fallback(contacts=contacts, company_id="42")
        assert "+ 3 more contacts omitted" in text
        assert f"offset={_MAX_COMPANY_CONTACTS_RENDERED}" in text

    def test_company_name_from_meta(self):
        contacts = [{"id": 1, "full_name": "Alice"}]
        meta = {"name": "Acme Corp", "domain": "acme.com"}
        text = render_company_contacts_text_fallback(
            contacts=contacts, company_id="42", company_meta=meta
        )
        assert "# Acme Corp — contacts" in text
        assert "acme.com" in text

    def test_seniority_mix_section(self):
        contacts = [
            {"id": 1, "full_name": "a", "seniority_level": "vp"},
            {"id": 2, "full_name": "b", "seniority_level": "director"},
        ]
        text = render_company_contacts_text_fallback(contacts=contacts, company_id="42")
        assert "## Seniority mix" in text
        assert "Vp" in text
        assert "Director" in text


# ---------------------------------------------------------------------------
# TestSmoke
# ---------------------------------------------------------------------------


class TestSmoke:
    def test_both_empty_modes_render(self):
        assert render_company_contacts_html(contacts=None, company_id="x").startswith("<!DOCTYPE html>")
        assert render_company_contacts_html(contacts=[], company_id="x").startswith("<!DOCTYPE html>")
        assert render_company_contacts_text_fallback(contacts=None, company_id="x")
        assert render_company_contacts_text_fallback(contacts=[], company_id="x")

    def test_full_html_is_valid_envelope(self):
        contacts = [{"id": 1, "full_name": "Alice"}]
        html = render_company_contacts_html(contacts=contacts, company_id="42")
        assert html.startswith("<!DOCTYPE html>")
        assert "</html>" in html

    def test_text_has_no_html_leaks(self):
        contacts = [{"id": 1, "full_name": "Alice"}]
        text = render_company_contacts_text_fallback(contacts=contacts, company_id="42")
        for tag in ("<div", "<span", "<code"):
            assert tag not in text
