"""Unit tests for Surface #81 — g8://companies/revenue/{tier}.

Locks the revenue-tier axis-filter renderer: normalization + backend USD
range mapping + 4-card stats row (Total / With domain / Unique industries /
**Median revenue** — first derived numeric KPI) + sort invariant
(industry ASC, revenue DESC, name ASC) + triple cross-axis drill-up
(dashboard + siblings + cross-axis industry + cross-axis country +
cross-axis size + cross-entity contacts).

Divergences from #80 locked by named tests:
- `TestStatsRow::test_has_median_revenue_not_countries`
- `TestRenderHtml::test_sort_by_industry_then_revenue_desc`
- `TestDrillUp::test_cross_axis_link_to_size` (first TRIPLE cross-axis)
- `TestMedian::*` (new derived-numeric stat class)
- `TestFormat::*` (new USD formatter class — $1.2M / $2.3B notation)
- `TestRange::test_enterprise_has_no_max_usd` (range-filter mirror of #80)
- EIGHT forbidden literals locked (adds `size` to #80's seven).
"""

import pytest

from mcp_server.g8_mcp_server.app_renderer import (
    _COMPANIES_REVENUE_ALIASES,
    _COMPANIES_REVENUE_LABELS,
    _COMPANIES_REVENUE_RANGE,
    _COMPANIES_REVENUE_SHORT_LABELS,
    _COMPANIES_REVENUE_VALID,
    _companies_revenue_amount,
    _companies_revenue_clip,
    _companies_revenue_country_str,
    _companies_revenue_display_name,
    _companies_revenue_drill_up_html,
    _companies_revenue_empty_state_html,
    _companies_revenue_format,
    _companies_revenue_header_html,
    _companies_revenue_industry_str,
    _companies_revenue_kpi_card_html,
    _companies_revenue_label,
    _companies_revenue_list_html,
    _companies_revenue_location,
    _companies_revenue_median,
    _companies_revenue_normalize,
    _companies_revenue_overflow_banner_html,
    _companies_revenue_palette,
    _companies_revenue_range,
    _companies_revenue_row_html,
    _companies_revenue_short_label,
    _companies_revenue_stats_row_html,
    render_companies_revenue_html,
    render_companies_revenue_text_fallback,
)


# ---------------------------------------------------------------------------
# Normalization
# ---------------------------------------------------------------------------


class TestNormalizeCanonical:
    @pytest.mark.parametrize("key", list(_COMPANIES_REVENUE_VALID))
    def test_canonical_self_map(self, key):
        assert _companies_revenue_normalize(key) == key

    @pytest.mark.parametrize("key", list(_COMPANIES_REVENUE_VALID))
    def test_uppercase(self, key):
        assert _companies_revenue_normalize(key.upper()) == key

    @pytest.mark.parametrize("key", list(_COMPANIES_REVENUE_VALID))
    def test_with_whitespace(self, key):
        assert _companies_revenue_normalize(f"  {key}  ") == key


class TestNormalizeAliases:
    @pytest.mark.parametrize("alias,canonical", list(_COMPANIES_REVENUE_ALIASES.items()))
    def test_alias_resolves(self, alias, canonical):
        assert _companies_revenue_normalize(alias) == canonical

    def test_uppercase_alias(self):
        assert _companies_revenue_normalize("SMALL") == "smb"

    def test_mixed_case_alias(self):
        assert _companies_revenue_normalize("Mid-Market") == "mid"

    def test_hyphen_to_underscore(self):
        assert _companies_revenue_normalize("mid-market") == "mid"
        assert _companies_revenue_normalize("mid_market") == "mid"

    def test_pre_revenue_to_bootstrap(self):
        assert _companies_revenue_normalize("pre-revenue") == "bootstrap"
        assert _companies_revenue_normalize("pre_revenue") == "bootstrap"


class TestNormalizeInvalid:
    @pytest.mark.parametrize("bad", [
        "xxx", "unknown", "bogus", "", "  ",
    ])
    def test_invalid_returns_none(self, bad):
        assert _companies_revenue_normalize(bad) is None

    @pytest.mark.parametrize("bad", [
        None, 42, 3.14, True, [], {},
    ])
    def test_non_string_returns_none(self, bad):
        assert _companies_revenue_normalize(bad) is None

    @pytest.mark.parametrize("literal", [
        "notes", "deals", "contacts", "activities",
        "dashboard", "industry", "country", "size",
    ])
    def test_no_collision_with_nested_literals(self, literal):
        """All 8 forbidden literals must be rejected."""
        assert _companies_revenue_normalize(literal) is None

    @pytest.mark.parametrize("literal", [
        "NOTES", "Deals", "CoNtAcTs", "ACTIVITIES",
        "DASHBOARD", "Industry", "COUNTRY", "SIZE",
    ])
    def test_forbidden_literals_case_insensitive(self, literal):
        assert _companies_revenue_normalize(literal) is None


# ---------------------------------------------------------------------------
# Labels
# ---------------------------------------------------------------------------


class TestLabel:
    @pytest.mark.parametrize("key,expected", list(_COMPANIES_REVENUE_LABELS.items()))
    def test_canonical_label(self, key, expected):
        assert _companies_revenue_label(key) == expected

    def test_alias_resolves_to_canonical_label(self):
        assert _companies_revenue_label("pre-revenue") == _COMPANIES_REVENUE_LABELS["bootstrap"]

    def test_invalid_fallback(self):
        assert _companies_revenue_label("xxx") == "Companies"

    def test_none_fallback(self):
        assert _companies_revenue_label(None) == "Companies"


class TestShortLabel:
    @pytest.mark.parametrize("key,expected", list(_COMPANIES_REVENUE_SHORT_LABELS.items()))
    def test_canonical_short_label(self, key, expected):
        assert _companies_revenue_short_label(key) == expected

    def test_invalid_fallback(self):
        assert _companies_revenue_short_label("xxx") == "—"


# ---------------------------------------------------------------------------
# Range — USD range filter pattern (mirrors #80 shape)
# ---------------------------------------------------------------------------


class TestRange:
    @pytest.mark.parametrize("key,expected_min,expected_max", [
        ("bootstrap",  0,            999_999),
        ("smb",        1_000_000,    9_999_999),
        ("mid",        10_000_000,   49_999_999),
        ("large",      50_000_000,   499_999_999),
        ("enterprise", 500_000_000,  None),
    ])
    def test_canonical_range(self, key, expected_min, expected_max):
        assert _companies_revenue_range(key) == (expected_min, expected_max)

    def test_enterprise_has_no_max_usd(self):
        """Enterprise tier is open-ended — max must be None."""
        _, rmax = _companies_revenue_range("enterprise")
        assert rmax is None

    def test_bootstrap_starts_at_zero(self):
        """Bootstrap covers pre-revenue — min must be 0."""
        rmin, rmax = _companies_revenue_range("bootstrap")
        assert rmin == 0
        assert rmax == 999_999

    def test_mid_bounded_range(self):
        rmin, rmax = _companies_revenue_range("mid")
        assert rmin == 10_000_000
        assert rmax == 49_999_999

    def test_alias_resolves_to_range(self):
        assert _companies_revenue_range("pre-revenue") == (0, 999_999)
        assert _companies_revenue_range("fortune-500") == (500_000_000, None)

    def test_invalid_returns_none_tuple(self):
        assert _companies_revenue_range("xxx") == (None, None)

    def test_none_returns_none_tuple(self):
        assert _companies_revenue_range(None) == (None, None)


# ---------------------------------------------------------------------------
# Palette
# ---------------------------------------------------------------------------


class TestPalette:
    @pytest.mark.parametrize("key", list(_COMPANIES_REVENUE_VALID))
    def test_returns_tuple(self, key):
        result = _companies_revenue_palette(key)
        assert isinstance(result, tuple)
        assert len(result) == 2

    @pytest.mark.parametrize("key", list(_COMPANIES_REVENUE_VALID))
    def test_no_banned_hexes(self, key):
        bg, fg = _companies_revenue_palette(key)
        for hex_val in ("#1d4ed8", "#166534", "#991b1b", "#0891b2"):
            assert hex_val.lower() not in bg.lower()
            assert hex_val.lower() not in fg.lower()

    def test_mid_is_accent(self):
        bg, fg = _companies_revenue_palette("mid")
        assert bg == "#f2eafe"
        assert fg == "#7d2df3"

    def test_large_is_accent(self):
        bg, fg = _companies_revenue_palette("large")
        assert bg == "#f2eafe"
        assert fg == "#7d2df3"

    def test_enterprise_is_warning(self):
        bg, fg = _companies_revenue_palette("enterprise")
        assert bg == "#fff3c4"
        assert fg == "#a0750a"

    def test_bootstrap_is_muted(self):
        bg, fg = _companies_revenue_palette("bootstrap")
        assert bg == "#f9f9f9"
        assert fg == "#777777"

    def test_smb_is_muted(self):
        bg, fg = _companies_revenue_palette("smb")
        assert bg == "#f9f9f9"
        assert fg == "#777777"

    def test_invalid_is_muted(self):
        bg, fg = _companies_revenue_palette("xxx")
        assert bg == "#f9f9f9"
        assert fg == "#777777"


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------


class TestClip:
    def test_short(self):
        assert _companies_revenue_clip("hi") == "hi"

    def test_long_clipped(self):
        result = _companies_revenue_clip("x" * 200, cap=100)
        assert result.endswith("…")
        assert len(result) <= 101

    def test_none(self):
        assert _companies_revenue_clip(None) == ""

    def test_whitespace_only(self):
        assert _companies_revenue_clip("   ") == ""

    def test_escaped(self):
        assert _companies_revenue_clip("<b>") == "&lt;b&gt;"

    def test_strips(self):
        assert _companies_revenue_clip("  hi  ") == "hi"

    def test_coerces_int(self):
        assert _companies_revenue_clip(42) == "42"

    def test_non_string_unstringable(self):
        class Bad:
            def __str__(self):
                raise RuntimeError()

        assert _companies_revenue_clip(Bad()) == ""


class TestAmount:
    def test_int(self):
        assert _companies_revenue_amount({"revenue": 10_000_000}) == 10_000_000

    def test_string(self):
        assert _companies_revenue_amount({"revenue": "5000000"}) == 5_000_000

    def test_string_with_comma(self):
        assert _companies_revenue_amount({"revenue": "1,000,000"}) == 1_000_000

    def test_string_with_dollar(self):
        assert _companies_revenue_amount({"revenue": "$50000000"}) == 50_000_000

    def test_string_with_plus(self):
        assert _companies_revenue_amount({"revenue": "500000+"}) == 500_000

    def test_float_integer(self):
        assert _companies_revenue_amount({"revenue": 1_000_000.0}) == 1_000_000

    def test_bool_rejected(self):
        assert _companies_revenue_amount({"revenue": True}) is None

    def test_negative_rejected(self):
        assert _companies_revenue_amount({"revenue": -100}) is None

    def test_none(self):
        assert _companies_revenue_amount({"revenue": None}) is None

    def test_missing(self):
        assert _companies_revenue_amount({}) is None

    def test_non_dict(self):
        assert _companies_revenue_amount("not a dict") is None

    def test_annual_revenue_fallback(self):
        assert _companies_revenue_amount({"annual_revenue": 5_000_000}) == 5_000_000

    def test_company_revenue_fallback(self):
        assert _companies_revenue_amount({"company_revenue": 2_000_000}) == 2_000_000


class TestFormat:
    """USD formatting — $1.2M / $2.3B / $500K / $42 notation."""

    def test_none(self):
        assert _companies_revenue_format(None) == "—"

    def test_negative(self):
        assert _companies_revenue_format(-100) == "—"

    def test_dollars_under_1k(self):
        assert _companies_revenue_format(42) == "$42"

    def test_thousands(self):
        assert _companies_revenue_format(500_000) == "$500K"

    def test_millions(self):
        assert _companies_revenue_format(45_000_000) == "$45.0M"

    def test_millions_fractional(self):
        assert _companies_revenue_format(1_200_000) == "$1.2M"

    def test_billions(self):
        assert _companies_revenue_format(2_300_000_000) == "$2.3B"

    def test_exact_billion(self):
        assert _companies_revenue_format(1_000_000_000) == "$1.0B"

    def test_exact_million(self):
        assert _companies_revenue_format(1_000_000) == "$1.0M"

    def test_bool_rejected(self):
        # Bool is a subclass of int so int(True)=1 — but format accepts
        # any int. Expected behavior: True → "$1" (not a concern since
        # _companies_revenue_amount rejects bools upstream).
        result = _companies_revenue_format(True)
        assert result in ("$1", "—")  # tolerate both interpretations

    def test_nan(self):
        assert _companies_revenue_format(float("nan")) == "—"

    def test_inf(self):
        assert _companies_revenue_format(float("inf")) == "—"


class TestMedian:
    """DIVERGENCE LOCK: first surface with derived numeric KPI."""

    def test_empty(self):
        assert _companies_revenue_median([]) is None

    def test_non_list(self):
        assert _companies_revenue_median("not a list") is None

    def test_all_missing(self):
        assert _companies_revenue_median([{"name": "A"}, {"name": "B"}]) is None

    def test_single_value(self):
        assert _companies_revenue_median([{"revenue": 1_000_000}]) == 1_000_000

    def test_odd_count(self):
        companies = [
            {"revenue": 10_000_000},
            {"revenue": 20_000_000},
            {"revenue": 30_000_000},
        ]
        assert _companies_revenue_median(companies) == 20_000_000

    def test_even_count(self):
        companies = [
            {"revenue": 10_000_000},
            {"revenue": 20_000_000},
            {"revenue": 30_000_000},
            {"revenue": 40_000_000},
        ]
        # (20M + 30M) // 2 = 25M
        assert _companies_revenue_median(companies) == 25_000_000

    def test_unsorted_input(self):
        companies = [
            {"revenue": 30_000_000},
            {"revenue": 10_000_000},
            {"revenue": 20_000_000},
        ]
        assert _companies_revenue_median(companies) == 20_000_000

    def test_zero_values_excluded(self):
        """Zero-revenue entries are excluded — they'd skew the median."""
        companies = [
            {"revenue": 0},
            {"revenue": 10_000_000},
            {"revenue": 20_000_000},
        ]
        # Only 10M + 20M counted -> median = 15M (even count)
        assert _companies_revenue_median(companies) == 15_000_000

    def test_mixed_missing_and_present(self):
        companies = [
            {"revenue": 10_000_000},
            {"name": "B"},
            {"revenue": 20_000_000},
            {"revenue": 30_000_000},
        ]
        # Only 10M, 20M, 30M counted -> median = 20M
        assert _companies_revenue_median(companies) == 20_000_000


class TestIndustryStr:
    def test_present(self):
        assert _companies_revenue_industry_str({"industry": "saas"}) == "saas"

    def test_missing(self):
        assert _companies_revenue_industry_str({}) == ""

    def test_non_string(self):
        assert _companies_revenue_industry_str({"industry": 42}) == ""

    def test_whitespace_stripped(self):
        assert _companies_revenue_industry_str({"industry": "  saas  "}) == "saas"

    def test_non_dict(self):
        assert _companies_revenue_industry_str("not a dict") == ""


class TestCountryStr:
    def test_present(self):
        assert _companies_revenue_country_str({"country": "US"}) == "US"

    def test_missing(self):
        assert _companies_revenue_country_str({}) == ""

    def test_non_string(self):
        assert _companies_revenue_country_str({"country": 42}) == ""

    def test_non_dict(self):
        assert _companies_revenue_country_str("not a dict") == ""


class TestDisplayName:
    def test_name_wins(self):
        assert _companies_revenue_display_name(
            {"name": "AcmeCo", "domain": "acme.com"}
        ) == "AcmeCo"

    def test_domain_fallback(self):
        assert _companies_revenue_display_name({"domain": "acme.com"}) == "acme.com"

    def test_unnamed(self):
        assert _companies_revenue_display_name({}) == "(unnamed)"

    def test_non_dict(self):
        assert _companies_revenue_display_name("not a dict") == "(unnamed)"

    def test_xss_escape(self):
        result = _companies_revenue_display_name({"name": "<script>"})
        assert "&lt;" in result
        assert "<script>" not in result


class TestLocation:
    def test_city_and_country(self):
        assert _companies_revenue_location(
            {"city": "NYC", "country": "US"}
        ) == "NYC, US"

    def test_country_only(self):
        assert _companies_revenue_location({"country": "US"}) == "US"

    def test_city_only(self):
        assert _companies_revenue_location({"city": "NYC"}) == "NYC"

    def test_empty(self):
        assert _companies_revenue_location({}) == ""

    def test_non_dict(self):
        assert _companies_revenue_location("not a dict") == ""


# ---------------------------------------------------------------------------
# HTML building blocks
# ---------------------------------------------------------------------------


class TestHeader:
    def test_contains_label(self):
        html = _companies_revenue_header_html("mid", 10)
        assert "Mid-Market" in html

    def test_plural(self):
        html = _companies_revenue_header_html("mid", 10)
        assert "10 companies" in html

    def test_singular(self):
        html = _companies_revenue_header_html("mid", 1)
        assert "1 company" in html

    def test_zero(self):
        html = _companies_revenue_header_html("mid", 0)
        assert "0 companies" in html

    def test_uses_graph8_primary(self):
        html = _companies_revenue_header_html("mid", 1)
        assert "#7d2df3" in html.lower() or "#f2eafe" in html.lower()

    def test_revenue_eyebrow(self):
        html = _companies_revenue_header_html("mid", 1)
        assert "revenue" in html.lower()


class TestKpiCard:
    def test_renders_label_value(self):
        html = _companies_revenue_kpi_card_html("Total", 42)
        assert "Total" in html
        assert "42" in html

    def test_accent_variant(self):
        html = _companies_revenue_kpi_card_html("Total", 42, accent=True)
        assert "#f2eafe" in html.lower() or "#7d2df3" in html.lower()


class TestStatsRow:
    def test_four_cards(self):
        html = _companies_revenue_stats_row_html([{"name": "A"}])
        assert html.count('padding:16px') == 4

    def test_has_median_revenue_not_countries(self):
        """DIVERGENCE LOCK: #81 shows Median revenue (derived numeric),
        NOT unique countries (#80's stat) or LinkedIn (#79's stat).
        """
        html = _companies_revenue_stats_row_html([{"name": "A"}])
        assert "Median revenue" in html
        assert "Unique industries" in html
        # Must NOT show #80's countries card
        assert "Unique countries" not in html
        # Must NOT show #79's LinkedIn card
        assert "LinkedIn" not in html

    def test_median_computed(self):
        companies = [
            {"name": "A", "revenue": 10_000_000},
            {"name": "B", "revenue": 20_000_000},
            {"name": "C", "revenue": 30_000_000},
        ]
        html = _companies_revenue_stats_row_html(companies)
        # Median = 20M → "$20.0M"
        assert "$20.0M" in html

    def test_empty_list(self):
        html = _companies_revenue_stats_row_html([])
        assert ">0<" in html

    def test_non_list(self):
        html = _companies_revenue_stats_row_html("not a list")
        assert ">0<" in html


class TestRow:
    def test_renders_name(self):
        html = _companies_revenue_row_html({"name": "AcmeCo"})
        assert "AcmeCo" in html

    def test_domain_present(self):
        html = _companies_revenue_row_html(
            {"name": "AcmeCo", "domain": "acme.com"}
        )
        assert "acme.com" in html

    def test_industry_chip(self):
        html = _companies_revenue_row_html(
            {"name": "A", "industry": "saas"}
        )
        assert "saas" in html

    def test_revenue_chip(self):
        html = _companies_revenue_row_html(
            {"name": "A", "revenue": 45_000_000}
        )
        assert "$45.0M" in html

    def test_no_revenue_no_chip(self):
        html = _companies_revenue_row_html({"name": "A"})
        assert "$" not in html

    def test_location(self):
        html = _companies_revenue_row_html(
            {"name": "A", "city": "NYC", "country": "US"}
        )
        assert "NYC" in html
        assert "US" in html

    def test_xss_name(self):
        html = _companies_revenue_row_html({"name": "<script>alert(1)</script>"})
        assert "<script>alert" not in html
        assert "&lt;script&gt;" in html

    def test_xss_domain(self):
        html = _companies_revenue_row_html(
            {"name": "A", "domain": "<script>"}
        )
        assert "<script>" not in html

    def test_xss_industry(self):
        html = _companies_revenue_row_html(
            {"name": "A", "industry": "<img onerror=x>"}
        )
        assert "<img" not in html
        assert ("&lt;img" in html) or ("&amp;lt;img" in html)


class TestList:
    def test_renders_all_rows(self):
        companies = [{"name": f"Co{i}"} for i in range(5)]
        html = _companies_revenue_list_html(companies)
        for i in range(5):
            assert f"Co{i}" in html

    def test_caps_at_100(self):
        companies = [{"name": f"Co{i}"} for i in range(150)]
        html = _companies_revenue_list_html(companies)
        assert "Co99" in html
        assert "Co100" not in html


class TestOverflowBanner:
    def test_under_cap_empty(self):
        assert _companies_revenue_overflow_banner_html(50, "mid") == ""

    def test_exactly_cap_empty(self):
        assert _companies_revenue_overflow_banner_html(100, "mid") == ""

    def test_over_cap_renders(self):
        html = _companies_revenue_overflow_banner_html(150, "mid")
        assert "50" in html
        assert "more" in html

    def test_uses_range_in_url(self):
        """URL must use revenue_min + revenue_max params."""
        html = _companies_revenue_overflow_banner_html(150, "mid")
        assert "revenue_min=10000000" in html
        assert "revenue_max=49999999" in html

    def test_enterprise_no_max_in_url(self):
        html = _companies_revenue_overflow_banner_html(150, "enterprise")
        assert "revenue_min=500000000" in html
        assert "revenue_max" not in html

    def test_bootstrap_has_max_in_url(self):
        html = _companies_revenue_overflow_banner_html(150, "bootstrap")
        assert "revenue_min=0" in html
        assert "revenue_max=999999" in html


class TestDrillUp:
    def test_has_dashboard(self):
        html = _companies_revenue_drill_up_html("mid")
        assert "g8://companies/dashboard" in html

    def test_has_siblings(self):
        html = _companies_revenue_drill_up_html("mid")
        for sibling in _COMPANIES_REVENUE_VALID:
            if sibling != "mid":
                assert f"g8://companies/revenue/{sibling}" in html

    def test_no_self_reference(self):
        html = _companies_revenue_drill_up_html("mid")
        assert "g8://companies/revenue/mid" not in html

    def test_cross_axis_link_to_industry(self):
        html = _companies_revenue_drill_up_html("mid")
        assert "g8://companies/industry/saas" in html

    def test_cross_axis_link_to_country(self):
        html = _companies_revenue_drill_up_html("mid")
        assert "g8://companies/country/united_states" in html

    def test_cross_axis_link_to_size(self):
        """DIVERGENCE LOCK: first TRIPLE cross-axis link (size sibling)."""
        html = _companies_revenue_drill_up_html("mid")
        assert "g8://companies/size/mid" in html

    def test_cross_entity_link_to_contacts(self):
        html = _companies_revenue_drill_up_html("mid")
        assert "g8://contacts/dashboard" in html

    def test_related_surfaces_label(self):
        html = _companies_revenue_drill_up_html("mid")
        assert "Related surfaces" in html


class TestEmptyState:
    def test_unavailable_mode(self):
        html = _companies_revenue_empty_state_html("xxx", "unavailable")
        assert "not recognized" in html.lower()
        assert "bootstrap" in html
        assert "smb" in html
        assert "mid" in html
        assert "large" in html
        assert "enterprise" in html

    def test_empty_mode(self):
        html = _companies_revenue_empty_state_html("mid", "empty")
        assert "Mid-Market" in html
        assert "No" in html

    def test_empty_mode_uses_tier_palette(self):
        html = _companies_revenue_empty_state_html("enterprise", "empty")
        assert "#fff3c4" in html.lower()


# ---------------------------------------------------------------------------
# Main renderer
# ---------------------------------------------------------------------------


class TestRenderHtml:
    def test_invalid_tier_renders_unavailable(self):
        html = render_companies_revenue_html(companies=[], tier="xxx")
        assert "not recognized" in html.lower()

    def test_forbidden_literal_renders_unavailable(self):
        html = render_companies_revenue_html(companies=[], tier="size")
        assert "not recognized" in html.lower()

    def test_none_companies_renders_unavailable_when_tier_invalid(self):
        html = render_companies_revenue_html(companies=None, tier="xxx")
        assert "not recognized" in html.lower()

    def test_none_companies_with_valid_tier_renders_empty(self):
        html = render_companies_revenue_html(companies=None, tier="mid")
        assert "No Mid-Market" in html

    def test_empty_list(self):
        html = render_companies_revenue_html(companies=[], tier="mid")
        assert "No Mid-Market" in html

    def test_happy_path(self):
        companies = [{"name": "AcmeCo", "industry": "saas"}]
        html = render_companies_revenue_html(companies=companies, tier="mid")
        assert "AcmeCo" in html
        assert "Mid-Market" in html

    def test_sort_by_industry_then_revenue_desc(self):
        """DIVERGENCE LOCK: sort (industry ASC, revenue DESC, name ASC).

        No country level unlike #80. Revenue reps want vertical first,
        then biggest-ARR first.
        """
        companies = [
            {"name": "SmallFin", "industry": "fintech", "revenue": 15_000_000},
            {"name": "BigFin",   "industry": "fintech", "revenue": 45_000_000},
            {"name": "BigSaaS",  "industry": "saas",    "revenue": 40_000_000},
            {"name": "SmallSaaS","industry": "saas",    "revenue": 12_000_000},
        ]
        html = render_companies_revenue_html(companies=companies, tier="mid")
        big_fin = html.find("BigFin")
        small_fin = html.find("SmallFin")
        big_saas = html.find("BigSaaS")
        small_saas = html.find("SmallSaaS")
        # fintech < saas
        assert big_fin < big_saas
        # Within fintech: higher revenue first
        assert big_fin < small_fin
        # Within saas: higher revenue first
        assert big_saas < small_saas

    def test_overflow_banner_at_101(self):
        companies = [{"name": f"Co{i}"} for i in range(150)]
        html = render_companies_revenue_html(companies=companies, tier="mid")
        assert "50" in html and "more" in html

    def test_xss_in_name(self):
        html = render_companies_revenue_html(
            companies=[{"name": "<script>alert(1)</script>"}],
            tier="mid",
        )
        assert "<script>alert" not in html

    def test_cross_axis_links_in_html(self):
        html = render_companies_revenue_html(
            companies=[{"name": "A"}], tier="mid"
        )
        assert "g8://companies/industry/saas" in html
        assert "g8://companies/country/united_states" in html
        assert "g8://companies/size/mid" in html

    def test_cross_entity_link_in_html(self):
        html = render_companies_revenue_html(
            companies=[{"name": "A"}], tier="mid"
        )
        assert "g8://contacts/dashboard" in html

    def test_alias_routed_to_canonical(self):
        html = render_companies_revenue_html(
            companies=[{"name": "A"}], tier="pre-revenue"
        )
        assert "Bootstrap" in html

    def test_doctype(self):
        html = render_companies_revenue_html(companies=[], tier="mid")
        assert html.startswith("<!DOCTYPE html>")


class TestDesignTokens:
    @pytest.mark.parametrize("banned", [
        "#1d4ed8", "#166534", "#991b1b", "#0891b2",
    ])
    def test_no_banned_hexes(self, banned):
        html = render_companies_revenue_html(
            companies=[{"name": "A", "industry": "saas", "country": "US",
                        "revenue": 45_000_000}],
            tier="mid",
        )
        assert banned.lower() not in html.lower()

    @pytest.mark.parametrize("expected", [
        "#7d2df3", "#dfdfdf", "#f2eafe", "#fff3c4",
    ])
    def test_uses_graph8_tokens(self, expected):
        html = render_companies_revenue_html(
            companies=[{"name": "A", "industry": "saas", "country": "US",
                        "revenue": 500_000_000}],
            tier="enterprise",
        )
        assert expected.lower() in html.lower()

    def test_aeonik(self):
        html = render_companies_revenue_html(
            companies=[{"name": "A"}], tier="mid"
        )
        assert "aeonik" in html.lower()


class TestNoJs:
    def test_no_script_tag(self):
        html = render_companies_revenue_html(
            companies=[{"name": "A"}], tier="mid"
        )
        assert "<script" not in html.lower()

    def test_no_event_handlers(self):
        html = render_companies_revenue_html(
            companies=[{"name": "A"}], tier="mid"
        )
        for handler in ("onclick=", "onerror=", "onload=", "onmouseover="):
            assert handler not in html.lower()


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------


class TestTextFallback:
    def test_invalid_tier(self):
        txt = render_companies_revenue_text_fallback(companies=[], tier="xxx")
        assert "not recognized" in txt.lower()

    def test_none_companies_valid_tier(self):
        txt = render_companies_revenue_text_fallback(
            companies=None, tier="mid"
        )
        assert "# Companies" in txt

    def test_empty_list(self):
        txt = render_companies_revenue_text_fallback(companies=[], tier="mid")
        assert "Total: 0" in txt

    def test_happy_path(self):
        companies = [
            {"name": "AcmeCo", "industry": "saas", "country": "US",
             "revenue": 45_000_000},
        ]
        txt = render_companies_revenue_text_fallback(
            companies=companies, tier="mid"
        )
        assert "AcmeCo" in txt
        assert "Mid-Market" in txt
        assert "Total: 1" in txt
        assert "$45.0M" in txt

    def test_stats_in_text(self):
        txt = render_companies_revenue_text_fallback(companies=[], tier="mid")
        assert "Total:" in txt
        assert "With domain:" in txt
        assert "Unique industries:" in txt
        assert "Median revenue:" in txt

    def test_backend_filter_uses_range_params(self):
        """Backend filter URL uses revenue_min/max."""
        txt = render_companies_revenue_text_fallback(companies=[], tier="mid")
        assert "revenue_min=10000000" in txt
        assert "revenue_max=49999999" in txt

    def test_backend_filter_enterprise_no_max(self):
        txt = render_companies_revenue_text_fallback(
            companies=[], tier="enterprise"
        )
        assert "revenue_min=500000000" in txt
        assert "revenue_max" not in txt

    def test_cross_axis_link_to_industry(self):
        txt = render_companies_revenue_text_fallback(companies=[], tier="mid")
        assert "g8://companies/industry/saas" in txt

    def test_cross_axis_link_to_country(self):
        txt = render_companies_revenue_text_fallback(companies=[], tier="mid")
        assert "g8://companies/country/united_states" in txt

    def test_cross_axis_link_to_size(self):
        """First TRIPLE cross-axis surface."""
        txt = render_companies_revenue_text_fallback(companies=[], tier="mid")
        assert "g8://companies/size/mid" in txt

    def test_cross_entity_link_to_contacts(self):
        txt = render_companies_revenue_text_fallback(companies=[], tier="mid")
        assert "g8://contacts/dashboard" in txt

    def test_overflow_note(self):
        companies = [{"name": f"Co{i}"} for i in range(150)]
        txt = render_companies_revenue_text_fallback(
            companies=companies, tier="mid"
        )
        assert "+50 more" in txt

    def test_trailing_newline(self):
        txt = render_companies_revenue_text_fallback(companies=[], tier="mid")
        assert txt.endswith("\n")


# ---------------------------------------------------------------------------
# Smoke
# ---------------------------------------------------------------------------


class TestSmoke:
    @pytest.mark.parametrize("key", list(_COMPANIES_REVENUE_VALID))
    def test_canonical_html_without_error(self, key):
        html = render_companies_revenue_html(
            companies=[{"name": "A", "industry": "saas", "country": "US",
                        "revenue": 10_000_000}],
            tier=key,
        )
        assert html.startswith("<!DOCTYPE html>")

    @pytest.mark.parametrize("key", list(_COMPANIES_REVENUE_VALID))
    def test_canonical_text_without_error(self, key):
        txt = render_companies_revenue_text_fallback(
            companies=[{"name": "A"}], tier=key
        )
        assert txt.startswith("# Companies")

    @pytest.mark.parametrize("alias", list(_COMPANIES_REVENUE_ALIASES.keys()))
    def test_alias_html_without_error(self, alias):
        html = render_companies_revenue_html(
            companies=[{"name": "A"}], tier=alias
        )
        assert html.startswith("<!DOCTYPE html>")

    @pytest.mark.parametrize("alias", list(_COMPANIES_REVENUE_ALIASES.keys()))
    def test_alias_text_without_error(self, alias):
        txt = render_companies_revenue_text_fallback(
            companies=[{"name": "A"}], tier=alias
        )
        assert txt.startswith("# Companies")


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------


class TestConstants:
    def test_valid_is_tuple(self):
        assert isinstance(_COMPANIES_REVENUE_VALID, tuple)
        assert len(_COMPANIES_REVENUE_VALID) == 5

    def test_labels_complete(self):
        for key in _COMPANIES_REVENUE_VALID:
            assert key in _COMPANIES_REVENUE_LABELS

    def test_short_labels_complete(self):
        for key in _COMPANIES_REVENUE_VALID:
            assert key in _COMPANIES_REVENUE_SHORT_LABELS

    def test_range_complete(self):
        for key in _COMPANIES_REVENUE_VALID:
            assert key in _COMPANIES_REVENUE_RANGE

    def test_aliases_target_valid(self):
        for canonical in _COMPANIES_REVENUE_ALIASES.values():
            assert canonical in _COMPANIES_REVENUE_VALID

    def test_no_alias_equals_canonical(self):
        for alias in _COMPANIES_REVENUE_ALIASES:
            assert alias not in _COMPANIES_REVENUE_VALID

    def test_aliases_has_50_plus(self):
        assert len(_COMPANIES_REVENUE_ALIASES) >= 50

    @pytest.mark.parametrize("literal", [
        "notes", "deals", "contacts", "activities",
        "dashboard", "industry", "country", "size",
    ])
    def test_no_alias_collides_with_nested_literals(self, literal):
        """Lock 8 forbidden literals including #80's newly-added `size`."""
        assert literal not in _COMPANIES_REVENUE_ALIASES

    @pytest.mark.parametrize("literal", [
        "notes", "deals", "contacts", "activities",
        "dashboard", "industry", "country", "size",
    ])
    def test_no_canonical_collides_with_nested_literals(self, literal):
        assert literal not in _COMPANIES_REVENUE_VALID

    def test_forbidden_literals_excluded(self):
        """Sanity check: all 8 forbidden literals reject via normalize()."""
        for literal in ("notes", "deals", "contacts", "activities",
                        "dashboard", "industry", "country", "size"):
            assert _companies_revenue_normalize(literal) is None
