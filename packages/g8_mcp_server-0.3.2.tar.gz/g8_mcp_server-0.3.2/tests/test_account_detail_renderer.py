"""Unit tests for Surface #89 — g8://accounts/{account_id} renderer.

First MCP app surface for the **accounts** entity prefix. Re-frames a
MashupCompany record as a REVENUE ACCOUNT: emphasizes $ in the stats
row, partitions deals into won/open/lost, and computes a 0-100 account
health score from deals + contacts.

Differentiator vs surface #38 (g8://companies/{company_id}) — #38 is
the CRM-profile lens; #89 is the revenue-account lens.
"""

from __future__ import annotations

import pytest

from mcp_server.g8_mcp_server import app_renderer as ar


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------


class TestConstants:
    def test_won_keywords_is_frozenset(self):
        assert isinstance(ar._ACCOUNT_DETAIL_WON_KEYWORDS, frozenset)
        assert "closed_won" in ar._ACCOUNT_DETAIL_WON_KEYWORDS
        assert "won" in ar._ACCOUNT_DETAIL_WON_KEYWORDS

    def test_lost_keywords_is_frozenset(self):
        assert isinstance(ar._ACCOUNT_DETAIL_LOST_KEYWORDS, frozenset)
        assert "closed_lost" in ar._ACCOUNT_DETAIL_LOST_KEYWORDS
        assert "lost" in ar._ACCOUNT_DETAIL_LOST_KEYWORDS

    def test_renderer_functions_exported(self):
        assert callable(ar.render_account_detail_html)
        assert callable(ar.render_account_detail_text_fallback)


# ---------------------------------------------------------------------------
# Stage normalization
# ---------------------------------------------------------------------------


class TestStageNormalized:
    def test_from_stage(self):
        assert ar._account_detail_stage_normalized({"stage": "Closed_Won"}) == "closed_won"

    def test_from_status(self):
        assert ar._account_detail_stage_normalized({"status": "Proposal"}) == "proposal"

    def test_prefers_stage_over_status(self):
        assert ar._account_detail_stage_normalized(
            {"stage": "closed_won", "status": "lost"}
        ) == "closed_won"

    def test_empty_when_missing(self):
        assert ar._account_detail_stage_normalized({}) == ""

    def test_empty_when_non_dict(self):
        assert ar._account_detail_stage_normalized(None) == ""
        assert ar._account_detail_stage_normalized("not a dict") == ""

    def test_strips_whitespace(self):
        assert ar._account_detail_stage_normalized({"stage": "  won  "}) == "won"


# ---------------------------------------------------------------------------
# Won/Lost classification
# ---------------------------------------------------------------------------


class TestIsWon:
    @pytest.mark.parametrize(
        "stage",
        ["won", "closed_won", "closed-won", "closedwon", "closed won"],
    )
    def test_won_keywords(self, stage):
        assert ar._account_detail_is_won({"stage": stage}) is True

    def test_substring_match(self):
        assert ar._account_detail_is_won({"stage": "won-by-competitor"}) is True

    def test_not_won(self):
        assert ar._account_detail_is_won({"stage": "proposal"}) is False

    def test_case_insensitive(self):
        assert ar._account_detail_is_won({"stage": "CLOSED_WON"}) is True

    def test_empty(self):
        assert ar._account_detail_is_won({}) is False


class TestIsLost:
    @pytest.mark.parametrize(
        "stage",
        ["lost", "closed_lost", "closed-lost", "closedlost", "closed lost"],
    )
    def test_lost_keywords(self, stage):
        assert ar._account_detail_is_lost({"stage": stage}) is True

    def test_substring_match(self):
        assert ar._account_detail_is_lost({"stage": "churned-lost"}) is True

    def test_not_lost(self):
        assert ar._account_detail_is_lost({"stage": "proposal"}) is False

    def test_case_insensitive(self):
        assert ar._account_detail_is_lost({"stage": "CLOSED_LOST"}) is True


# ---------------------------------------------------------------------------
# Bucketing
# ---------------------------------------------------------------------------


class TestBucket:
    def test_won(self):
        assert ar._account_detail_bucket({"stage": "closed_won"}) == "won"

    def test_lost(self):
        assert ar._account_detail_bucket({"stage": "closed_lost"}) == "lost"

    def test_open(self):
        assert ar._account_detail_bucket({"stage": "proposal"}) == "open"

    def test_won_takes_precedence_over_open(self):
        assert ar._account_detail_bucket({"stage": "won"}) == "won"

    def test_unknown_stage_is_open(self):
        assert ar._account_detail_bucket({"stage": "wibble"}) == "open"

    def test_no_stage_is_open(self):
        assert ar._account_detail_bucket({}) == "open"


# ---------------------------------------------------------------------------
# Partition
# ---------------------------------------------------------------------------


class TestPartition:
    def test_returns_three_keys(self):
        result = ar._account_detail_partition_deals([])
        assert set(result.keys()) == {"won", "open", "lost"}

    def test_buckets_correctly(self):
        deals = [
            {"stage": "closed_won", "amount": 50000},
            {"stage": "proposal", "amount": 10000},
            {"stage": "closed_lost", "amount": 20000},
            {"stage": "negotiation", "amount": 30000},
        ]
        result = ar._account_detail_partition_deals(deals)
        assert len(result["won"]) == 1
        assert len(result["open"]) == 2
        assert len(result["lost"]) == 1

    def test_non_list_returns_empties(self):
        result = ar._account_detail_partition_deals(None)
        assert result["won"] == []
        assert result["open"] == []
        assert result["lost"] == []

    def test_skips_non_dicts(self):
        result = ar._account_detail_partition_deals(
            [{"stage": "won"}, "not a dict", None]
        )
        assert len(result["won"]) == 1
        assert len(result["open"]) == 0


# ---------------------------------------------------------------------------
# Amount extraction
# ---------------------------------------------------------------------------


class TestAmount:
    def test_prefers_amount(self):
        assert ar._account_detail_amount({"amount": 1000}) == 1000.0

    def test_value_fallback(self):
        assert ar._account_detail_amount({"value": 500}) == 500.0

    def test_arr_fallback(self):
        assert ar._account_detail_amount({"arr": 250}) == 250.0

    def test_total_value_fallback(self):
        assert ar._account_detail_amount({"total_value": 125}) == 125.0

    def test_expected_value_fallback(self):
        assert ar._account_detail_amount({"expected_value": 75}) == 75.0

    def test_none_when_missing(self):
        assert ar._account_detail_amount({}) == 0.0

    def test_non_dict_returns_zero(self):
        assert ar._account_detail_amount(None) == 0.0
        assert ar._account_detail_amount("not a dict") == 0.0

    def test_string_parses(self):
        assert ar._account_detail_amount({"amount": "5000"}) == 5000.0

    def test_string_with_currency_symbol(self):
        assert ar._account_detail_amount({"amount": "$5,000"}) == 5000.0

    def test_prefers_amount_over_value(self):
        assert ar._account_detail_amount({"amount": 100, "value": 200}) == 100.0


class TestSumAmount:
    def test_sums(self):
        deals = [{"amount": 100}, {"amount": 200}, {"amount": 50}]
        assert ar._account_detail_sum_amount(deals) == 350.0

    def test_empty(self):
        assert ar._account_detail_sum_amount([]) == 0.0

    def test_non_list(self):
        assert ar._account_detail_sum_amount(None) == 0.0

    def test_skips_missing(self):
        deals = [{"amount": 100}, {}, {"amount": 50}]
        assert ar._account_detail_sum_amount(deals) == 150.0


# ---------------------------------------------------------------------------
# Currency formatting
# ---------------------------------------------------------------------------


class TestFormatCurrency:
    def test_zero(self):
        assert ar._account_detail_format_currency(0) == "$0"

    def test_sub_1k(self):
        assert ar._account_detail_format_currency(500) == "$500"

    def test_k_tier(self):
        assert ar._account_detail_format_currency(5000) == "$5.0K"

    def test_m_tier(self):
        assert ar._account_detail_format_currency(5_000_000) == "$5.0M"

    def test_decimal_rounding_k(self):
        assert ar._account_detail_format_currency(1250) == "$1.2K"

    def test_decimal_rounding_m(self):
        assert ar._account_detail_format_currency(1_500_000) == "$1.5M"

    def test_negative(self):
        assert ar._account_detail_format_currency(-500) == "-$500"

    def test_negative_k(self):
        assert ar._account_detail_format_currency(-5000) == "-$5.0K"


# ---------------------------------------------------------------------------
# Health score
# ---------------------------------------------------------------------------


class TestHealthScore:
    def test_zero_when_empty(self):
        assert ar._account_detail_health_score([], [], []) == 0

    def test_deals_signal_capped_at_40(self):
        won = [{"stage": "won"}] * 10
        # 10 * 10 = 100, capped to 40
        assert ar._account_detail_health_score(won, [], []) == 40

    def test_pipeline_signal_capped_at_30(self):
        open_deals = [{"stage": "proposal"}] * 20
        # 20 * 6 = 120, capped to 30
        assert ar._account_detail_health_score([], open_deals, []) == 30

    def test_contacts_signal_capped_at_30(self):
        contacts = [{}] * 20
        # 20 * 3 = 60, capped to 30
        assert ar._account_detail_health_score([], [], contacts) == 30

    def test_combined_capped_at_100(self):
        won = [{"stage": "won"}] * 10
        open_deals = [{"stage": "proposal"}] * 10
        contacts = [{}] * 20
        assert ar._account_detail_health_score(won, open_deals, contacts) == 100

    def test_normal_mix(self):
        won = [{"stage": "won"}] * 2  # 2 * 10 = 20
        open_deals = [{"stage": "proposal"}] * 3  # 3 * 6 = 18
        contacts = [{}] * 4  # 4 * 3 = 12
        assert ar._account_detail_health_score(won, open_deals, contacts) == 50


class TestHealthBand:
    def test_high(self):
        assert ar._account_detail_health_band(70) == "high"
        assert ar._account_detail_health_band(100) == "high"

    def test_medium(self):
        assert ar._account_detail_health_band(40) == "medium"
        assert ar._account_detail_health_band(69) == "medium"

    def test_low(self):
        assert ar._account_detail_health_band(0) == "low"
        assert ar._account_detail_health_band(39) == "low"


class TestHealthPalette:
    def test_high_positive(self):
        palette = ar._account_detail_health_palette("high")
        assert palette["bg"] == ar._G8_POSITIVE_BG
        assert palette["fg"] == ar._G8_POSITIVE_FG

    def test_medium_warning(self):
        palette = ar._account_detail_health_palette("medium")
        assert palette["bg"] == ar._G8_WARNING_BG
        assert palette["fg"] == ar._G8_WARNING_FG

    def test_low_accent(self):
        palette = ar._account_detail_health_palette("low")
        assert palette["bg"] == ar._G8_ACCENT_BG
        assert palette["fg"] == ar._G8_PRIMARY


# ---------------------------------------------------------------------------
# Display name
# ---------------------------------------------------------------------------


class TestDisplayName:
    def test_prefers_company_name(self):
        assert ar._account_detail_display_name({"company_name": "Acme"}, "id") == "Acme"

    def test_name_fallback(self):
        assert ar._account_detail_display_name({"name": "Acme"}, "id") == "Acme"

    def test_legal_name_fallback(self):
        assert ar._account_detail_display_name({"legal_name": "Acme Inc."}, "id") == "Acme Inc."

    def test_display_name_fallback(self):
        assert ar._account_detail_display_name({"display_name": "Acme"}, "id") == "Acme"

    def test_id_fallback(self):
        assert ar._account_detail_display_name({}, "acc_42") == "Account #acc_42"

    def test_non_dict(self):
        assert ar._account_detail_display_name(None, "id") == "Account #id"

    def test_capped_at_200(self):
        long_name = "A" * 300
        result = ar._account_detail_display_name({"name": long_name}, "id")
        assert len(result) == 200


class TestDealName:
    def test_prefers_name(self):
        assert ar._account_detail_deal_name({"name": "Big Deal"}) == "Big Deal"

    def test_title_fallback(self):
        assert ar._account_detail_deal_name({"title": "Deal"}) == "Deal"

    def test_id_fallback(self):
        assert ar._account_detail_deal_name({"id": 42}) == "Deal #42"

    def test_untitled_fallback(self):
        assert ar._account_detail_deal_name({}) == "Untitled deal"

    def test_non_dict(self):
        assert ar._account_detail_deal_name(None) == "Untitled deal"


# ---------------------------------------------------------------------------
# Sorting
# ---------------------------------------------------------------------------


class TestSortDeals:
    def test_sorts_by_amount_desc(self):
        deals = [{"amount": 100}, {"amount": 500}, {"amount": 300}]
        sorted_deals = ar._account_detail_sort_deals(deals)
        assert [d["amount"] for d in sorted_deals] == [500, 300, 100]

    def test_non_list(self):
        assert ar._account_detail_sort_deals(None) == []

    def test_skips_non_dicts(self):
        deals = [{"amount": 100}, "not a dict", {"amount": 200}]
        result = ar._account_detail_sort_deals(deals)
        assert len(result) == 2


# ---------------------------------------------------------------------------
# HTML building blocks
# ---------------------------------------------------------------------------


class TestStatsRow:
    def test_has_total_won_open_health(self):
        """LOCK: stats row must show the 4-card revenue shape."""
        html = ar._account_detail_stats_row_html(
            [{"amount": 1000, "stage": "won"}],
            [{"amount": 500, "stage": "proposal"}],
            [],
            [],
        )
        assert "Total account value" in html
        assert "Won $" in html
        assert "Open pipeline" in html
        assert "Health score" in html

    def test_total_sums_all_bands(self):
        html = ar._account_detail_stats_row_html(
            [{"amount": 1000}],
            [{"amount": 500}],
            [{"amount": 200}],
            [],
        )
        # Total = 1700 -> $1.7K
        assert "$1.7K" in html

    def test_empty_shows_zeros(self):
        html = ar._account_detail_stats_row_html([], [], [], [])
        assert "$0" in html

    def test_won_tinted_positive(self):
        html = ar._account_detail_stats_row_html(
            [{"amount": 1000}], [], [], [],
        )
        assert ar._G8_POSITIVE_BG in html

    def test_open_tinted_accent(self):
        html = ar._account_detail_stats_row_html(
            [], [{"amount": 500}], [], [],
        )
        assert ar._G8_ACCENT_BG in html

    def test_health_shown(self):
        html = ar._account_detail_stats_row_html([], [], [], [])
        assert "0/100" in html


class TestHeader:
    def test_has_revenue_account_chip(self):
        html = ar._account_detail_header_html("Acme Corp", "acc_123")
        assert "REVENUE ACCOUNT" in html

    def test_has_name(self):
        html = ar._account_detail_header_html("Acme Corp", "acc_123")
        assert "Acme Corp" in html

    def test_has_id(self):
        html = ar._account_detail_header_html("Acme Corp", "acc_123")
        assert "acc_123" in html

    def test_xss_escaped(self):
        html = ar._account_detail_header_html("<script>", "id")
        assert "<script>" not in html
        assert "&lt;script&gt;" in html


class TestDealRow:
    def test_won_uses_positive_palette(self):
        html = ar._account_detail_deal_row_html(
            {"name": "Enterprise", "amount": 50000, "stage": "won"}, "won"
        )
        assert ar._G8_POSITIVE_BG in html
        assert ar._G8_POSITIVE_FG in html

    def test_open_uses_accent_palette(self):
        html = ar._account_detail_deal_row_html(
            {"name": "Pilot", "amount": 10000, "stage": "proposal"}, "open"
        )
        assert ar._G8_ACCENT_BG in html
        assert ar._G8_PRIMARY in html

    def test_lost_uses_destructive_palette(self):
        html = ar._account_detail_deal_row_html(
            {"name": "Churned", "amount": 5000, "stage": "lost"}, "lost"
        )
        assert ar._G8_DESTRUCTIVE_BG in html
        assert ar._G8_DESTRUCTIVE_FG in html

    def test_lost_has_opacity(self):
        html = ar._account_detail_deal_row_html(
            {"name": "Churned", "amount": 5000}, "lost"
        )
        assert "opacity:0.75" in html

    def test_has_name_and_amount(self):
        html = ar._account_detail_deal_row_html(
            {"name": "Big Deal", "amount": 1000}, "won"
        )
        assert "Big Deal" in html
        assert "$1.0K" in html

    def test_xss_escaped(self):
        html = ar._account_detail_deal_row_html(
            {"name": "<script>bad</script>", "amount": 100}, "open"
        )
        assert "<script>bad</script>" not in html


class TestBandSection:
    def test_empty_returns_empty_string(self):
        assert ar._account_detail_band_section_html("won", [], "Won") == ""

    def test_renders_items(self):
        html = ar._account_detail_band_section_html(
            "won", [{"name": "Deal A", "amount": 1000}], "Won deals"
        )
        assert "Won deals" in html
        assert "Deal A" in html

    def test_cap_40(self):
        deals = [{"name": f"Deal {i}", "amount": i * 100} for i in range(50)]
        html = ar._account_detail_band_section_html("open", deals, "Open")
        assert "10 more omitted" in html

    def test_count_badge(self):
        html = ar._account_detail_band_section_html(
            "won", [{"amount": 100}, {"amount": 200}], "Won"
        )
        assert ">2<" in html  # count badge

    def test_sum_shown(self):
        html = ar._account_detail_band_section_html(
            "won", [{"amount": 1000}, {"amount": 500}], "Won"
        )
        assert "$1.5K" in html


class TestContactsSummary:
    def test_empty_shows_message(self):
        html = ar._account_detail_contacts_summary_html([])
        assert "No contacts" in html

    def test_non_list_shows_message(self):
        html = ar._account_detail_contacts_summary_html(None)
        assert "No contacts" in html

    def test_count_shown(self):
        contacts = [{"first_name": "Jane", "last_name": "Doe"}] * 3
        html = ar._account_detail_contacts_summary_html(contacts)
        assert "Contacts (3)" in html

    def test_top_5_chips(self):
        contacts = [
            {"first_name": "A", "last_name": "One"},
            {"first_name": "B", "last_name": "Two"},
        ]
        html = ar._account_detail_contacts_summary_html(contacts)
        assert "A One" in html
        assert "B Two" in html

    def test_overflow_shown(self):
        contacts = [{"first_name": f"C{i}", "last_name": "X"} for i in range(10)]
        html = ar._account_detail_contacts_summary_html(contacts)
        assert "+ 5 more" in html

    def test_email_fallback(self):
        html = ar._account_detail_contacts_summary_html([{"email": "jane@acme.com"}])
        assert "jane@acme.com" in html


class TestDrillUp:
    def test_has_five_pointers(self):
        html = ar._account_detail_drill_up_html("acc_123")
        assert "g8://companies/acc_123" in html
        assert "g8://deals/this-week" in html
        assert "g8://deals/pipeline" in html
        assert "g8://activities/today" in html
        assert "g8://copilot/home" in html

    def test_has_related_heading(self):
        html = ar._account_detail_drill_up_html("acc_123")
        assert "Related surfaces" in html


class TestEmptyState:
    def test_has_not_found_message(self):
        html = ar._account_detail_empty_state_html("acc_404")
        assert "Account not found" in html

    def test_has_account_id(self):
        html = ar._account_detail_empty_state_html("acc_404")
        assert "acc_404" in html


# ---------------------------------------------------------------------------
# Full HTML render
# ---------------------------------------------------------------------------


class TestRenderHtml:
    def test_renders_name_in_html(self):
        """LOCK: account name must render in the HTML output."""
        html = ar.render_account_detail_html(
            "acc_1",
            company={"name": "Acme Corp"},
            deals=[],
            contacts=[],
        )
        assert "Acme Corp" in html

    def test_missing_company_shows_empty_state(self):
        html = ar.render_account_detail_html("acc_1", company=None)
        assert "Account not found" in html

    def test_includes_header(self):
        html = ar.render_account_detail_html(
            "acc_1", company={"name": "X"}, deals=[], contacts=[],
        )
        assert "REVENUE ACCOUNT" in html

    def test_includes_drill_up(self):
        html = ar.render_account_detail_html(
            "acc_1", company={"name": "X"}, deals=[], contacts=[],
        )
        assert "Related surfaces" in html

    def test_empty_deals_no_sections(self):
        html = ar.render_account_detail_html(
            "acc_1", company={"name": "X"}, deals=[], contacts=[],
        )
        assert "Won deals" not in html
        assert "Open pipeline" in html  # stats row still says "Open pipeline"
        # But no deal SECTION should render
        # (check by absence of section header pattern with count badge)

    def test_sorts_open_by_amount_desc(self):
        html = ar.render_account_detail_html(
            "acc_1",
            company={"name": "X"},
            deals=[
                {"name": "Small", "amount": 100, "stage": "proposal"},
                {"name": "Medium", "amount": 500, "stage": "proposal"},
                {"name": "Large", "amount": 1000, "stage": "proposal"},
            ],
            contacts=[],
        )
        large_idx = html.index("Large")
        medium_idx = html.index("Medium")
        small_idx = html.index("Small")
        assert large_idx < medium_idx < small_idx


class TestHtmlStructure:
    def test_has_doctype(self):
        html = ar.render_account_detail_html("a1", company={"name": "X"}, deals=[], contacts=[])
        assert html.startswith("<!DOCTYPE html>")

    def test_closes_html(self):
        html = ar.render_account_detail_html("a1", company={"name": "X"}, deals=[], contacts=[])
        assert html.endswith("</body></html>")

    def test_has_title(self):
        html = ar.render_account_detail_html("a1", company={"name": "X"}, deals=[], contacts=[])
        assert "<title>Account a1</title>" in html


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------


class TestTextFallback:
    def test_has_name_header(self):
        txt = ar.render_account_detail_text_fallback(
            "acc_1",
            company={"name": "Acme"},
            deals=[],
            contacts=[],
        )
        assert "# Acme" in txt

    def test_missing_company_empty_state(self):
        txt = ar.render_account_detail_text_fallback("acc_1", company=None)
        assert "No record for account ID acc_1" in txt

    def test_stats_line(self):
        txt = ar.render_account_detail_text_fallback(
            "acc_1",
            company={"name": "X"},
            deals=[{"stage": "won", "amount": 1000}],
            contacts=[],
        )
        assert "Total:" in txt
        assert "Won:" in txt
        assert "Health:" in txt

    def test_lists_won_deals(self):
        txt = ar.render_account_detail_text_fallback(
            "acc_1",
            company={"name": "X"},
            deals=[{"name": "Deal A", "stage": "won", "amount": 1000}],
            contacts=[],
        )
        assert "## Won deals" in txt
        assert "Deal A" in txt

    def test_related_surfaces(self):
        txt = ar.render_account_detail_text_fallback(
            "acc_1",
            company={"name": "X"},
            deals=[],
            contacts=[],
        )
        assert "## Related surfaces" in txt
        assert "g8://companies/acc_1" in txt

    def test_backend_hint(self):
        txt = ar.render_account_detail_text_fallback(
            "acc_1",
            company={"name": "X"},
            deals=[],
            contacts=[],
        )
        assert "/companies/acc_1/deals" in txt
        assert "/companies/acc_1/contacts" in txt


# ---------------------------------------------------------------------------
# Design tokens
# ---------------------------------------------------------------------------


class TestDesignTokens:
    @pytest.mark.parametrize(
        "banned_hex",
        ["#1d4ed8", "#166534", "#991b1b", "#0891b2"],
    )
    def test_no_banned_hexes(self, banned_hex):
        html = ar.render_account_detail_html(
            "acc_1",
            company={"name": "Acme"},
            deals=[
                {"stage": "won", "amount": 1000},
                {"stage": "proposal", "amount": 500},
                {"stage": "lost", "amount": 200},
            ],
            contacts=[{"first_name": "Jane"}],
        )
        assert banned_hex.lower() not in html.lower(), f"banned hex {banned_hex} found"

    def test_uses_primary_purple(self):
        html = ar.render_account_detail_html(
            "acc_1", company={"name": "X"}, deals=[], contacts=[],
        )
        assert ar._G8_PRIMARY in html

    def test_uses_aeonik_font(self):
        html = ar.render_account_detail_html(
            "acc_1", company={"name": "X"}, deals=[], contacts=[],
        )
        assert "Aeonik" in html

    def test_uses_positive_for_won(self):
        html = ar.render_account_detail_html(
            "acc_1",
            company={"name": "X"},
            deals=[{"stage": "won", "amount": 1000}],
            contacts=[],
        )
        assert ar._G8_POSITIVE_BG in html

    def test_uses_destructive_for_lost(self):
        html = ar.render_account_detail_html(
            "acc_1",
            company={"name": "X"},
            deals=[{"stage": "lost", "amount": 1000}],
            contacts=[],
        )
        assert ar._G8_DESTRUCTIVE_BG in html


class TestNoJs:
    def test_no_script_tag(self):
        html = ar.render_account_detail_html(
            "acc_1", company={"name": "X"}, deals=[], contacts=[],
        )
        assert "<script" not in html.lower()

    def test_no_onclick(self):
        html = ar.render_account_detail_html(
            "acc_1", company={"name": "X"}, deals=[], contacts=[],
        )
        assert "onclick" not in html.lower()


# ---------------------------------------------------------------------------
# Smoke
# ---------------------------------------------------------------------------


class TestSmoke:
    def test_full_mix(self):
        deals = [
            {"name": f"Deal {i}", "amount": i * 1000, "stage": "proposal"}
            for i in range(10)
        ] + [
            {"name": f"Won {i}", "amount": i * 5000, "stage": "closed_won"}
            for i in range(5)
        ] + [
            {"name": f"Lost {i}", "amount": i * 2000, "stage": "closed_lost"}
            for i in range(3)
        ]
        contacts = [{"first_name": f"C{i}", "last_name": "X"} for i in range(8)]
        html = ar.render_account_detail_html(
            "acc_big",
            company={"name": "Big Corp"},
            deals=deals,
            contacts=contacts,
        )
        assert "Big Corp" in html
        assert "Won deals" in html
        assert "Open pipeline" in html
        assert "Lost deals" in html

    def test_overflow_past_cap(self):
        deals = [{"name": f"D{i}", "amount": 100, "stage": "proposal"} for i in range(50)]
        html = ar.render_account_detail_html(
            "acc_big",
            company={"name": "X"},
            deals=deals,
            contacts=[],
        )
        assert "10 more omitted" in html


# ---------------------------------------------------------------------------
# Return types
# ---------------------------------------------------------------------------


class TestReturnTypes:
    def test_html_is_str(self):
        html = ar.render_account_detail_html("a1", company={"name": "X"}, deals=[], contacts=[])
        assert isinstance(html, str)

    def test_text_is_str(self):
        txt = ar.render_account_detail_text_fallback("a1", company={"name": "X"}, deals=[], contacts=[])
        assert isinstance(txt, str)

    def test_partition_returns_dict(self):
        result = ar._account_detail_partition_deals([])
        assert isinstance(result, dict)

    def test_sort_returns_list(self):
        result = ar._account_detail_sort_deals([])
        assert isinstance(result, list)
