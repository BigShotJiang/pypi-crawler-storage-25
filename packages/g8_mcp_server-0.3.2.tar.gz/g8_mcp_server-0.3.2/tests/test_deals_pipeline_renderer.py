"""Tests for the deals pipeline HTML + text renderers (upgrade 4 — #11)."""

from __future__ import annotations

from g8_mcp_server import app_renderer
from g8_mcp_server.app_renderer import (
    _deal_status_color,
    _format_currency,
    _group_deals_by_stage,
    _stage_total_amount,
    render_deals_pipeline_html,
    render_deals_pipeline_text_fallback,
)


def _deal(idx: int = 0, **overrides) -> dict:
    """Default deal dict matching `DealItem`."""
    base = {
        "id": f"deal_{idx}",
        "name": f"Deal {idx}",
        "amount": 10_000.0,
        "currency": "USD",
        "stage_id": "stg_disc",
        "stage_name": "Discovery",
        "pipeline_id": "pipe_default",
        "contact_id": 100 + idx,
        "company_id": None,
        "owner_id": "user_abc",
        "status": "open",
        "created_at": "2026-04-10T12:00:00Z",
        "updated_at": "2026-04-15T12:00:00Z",
        "close_date": "2026-05-01",
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class TestDealStatusColor:
    def test_known(self):
        # Backported to graph8 tokens 2026-04-21
        assert _deal_status_color("open") == "#7d2df3"  # _G8_PRIMARY
        assert _deal_status_color("won") == "#059669"  # _G8_POSITIVE_FG
        assert _deal_status_color("lost") == "#b91c1c"  # _G8_DESTRUCTIVE_ON_LIGHT_FG
        assert _deal_status_color("abandoned") == "#777777"

    def test_case_and_whitespace(self):
        assert _deal_status_color("OPEN") == "#7d2df3"  # _G8_PRIMARY
        assert _deal_status_color(" Won ") == "#059669"  # _G8_POSITIVE_FG

    def test_unknown(self):
        assert _deal_status_color("weird") == "#777777"
        assert _deal_status_color(None) == "#777777"
        assert _deal_status_color("") == "#777777"

    def test_no_banned_hexes_in_status_palette(self):
        # Lock: no banned Studio hex in any status entry
        banned = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}
        from mcp_server.g8_mcp_server.app_renderer import _DEAL_STATUS_COLORS
        for status, value in _DEAL_STATUS_COLORS.items():
            assert value.lower() not in banned, (
                f"status={status!r} hex={value!r} is banned"
            )


class TestFormatCurrency:
    def test_million_compact(self):
        assert _format_currency(1_500_000, "USD") == "USD 1.5M"
        assert _format_currency(2_000_000, "USD") == "USD 2.0M"

    def test_thousand_compact(self):
        assert _format_currency(1_500, "USD") == "USD 1.5k"
        assert _format_currency(25_000, "USD") == "USD 25.0k"

    def test_small_raw(self):
        assert _format_currency(500, "USD") == "USD 500"
        assert _format_currency(0, "USD") == "USD 0"

    def test_default_currency(self):
        # None → USD default
        assert _format_currency(100, None) == "USD 100"
        assert _format_currency(100, "") == "USD 100"

    def test_currency_upper_and_trimmed(self):
        assert _format_currency(100, " eur ") == "EUR 100"

    def test_non_numeric_returns_empty(self):
        assert _format_currency(None, "USD") == ""
        assert _format_currency("nope", "USD") == ""  # type: ignore[arg-type]


class TestGroupDealsByStage:
    def test_empty(self):
        assert _group_deals_by_stage([]) == []

    def test_preserves_insertion_order(self):
        deals = [
            _deal(idx=1, stage_name="Qualify"),
            _deal(idx=2, stage_name="Proposal"),
            _deal(idx=3, stage_name="Qualify"),
        ]
        result = _group_deals_by_stage(deals)
        keys = [k for k, _ in result]
        assert keys == ["Qualify", "Proposal"]
        # Items in "Qualify" bucket preserve input order too
        qualify_items = dict(result)["Qualify"]
        assert [d["id"] for d in qualify_items] == ["deal_1", "deal_3"]

    def test_stage_id_fallback(self):
        # Missing stage_name — stage_id is used
        deals = [_deal(idx=1, stage_name=None, stage_id="stg_discovery")]
        result = _group_deals_by_stage(deals)
        assert result[0][0] == "stg_discovery"

    def test_no_stage_bucket_last(self):
        deals = [
            _deal(idx=1, stage_name="A"),
            _deal(idx=2, stage_name=None, stage_id=None),
            _deal(idx=3, stage_name="B"),
        ]
        result = _group_deals_by_stage(deals)
        keys = [k for k, _ in result]
        assert keys[-1] == "(no stage)"
        assert keys[:-1] == ["A", "B"]

    def test_empty_stage_strings_bucket_as_no_stage(self):
        deals = [
            _deal(idx=1, stage_name="", stage_id=""),
            _deal(idx=2, stage_name="   ", stage_id=None),
        ]
        result = _group_deals_by_stage(deals)
        assert result == [("(no stage)", deals)]


class TestStageTotalAmount:
    def test_empty(self):
        total, cur = _stage_total_amount([])
        assert total == 0.0
        assert cur is None

    def test_sums_amounts(self):
        deals = [
            _deal(idx=1, amount=1000, currency="USD"),
            _deal(idx=2, amount=2000, currency="USD"),
        ]
        total, cur = _stage_total_amount(deals)
        assert total == 3000.0
        assert cur == "USD"

    def test_picks_most_common_currency(self):
        deals = [
            _deal(idx=1, amount=1000, currency="EUR"),
            _deal(idx=2, amount=1000, currency="USD"),
            _deal(idx=3, amount=1000, currency="USD"),
        ]
        _total, cur = _stage_total_amount(deals)
        assert cur == "USD"

    def test_skips_non_numeric_amounts(self):
        deals = [
            _deal(idx=1, amount=1000, currency="USD"),
            _deal(idx=2, amount=None, currency="USD"),
            _deal(idx=3, amount="nope", currency="USD"),  # type: ignore[arg-type]
        ]
        total, cur = _stage_total_amount(deals)
        assert total == 1000.0
        assert cur == "USD"


# ---------------------------------------------------------------------------
# HTML renderer
# ---------------------------------------------------------------------------


class TestRenderDealsPipelineHtml:
    def test_empty_state(self):
        html_out = render_deals_pipeline_html(deals=None)
        assert "No deals yet" in html_out

        html_out2 = render_deals_pipeline_html(deals=[])
        assert "No deals yet" in html_out2

    def test_non_list_input(self):
        html_out = render_deals_pipeline_html(deals="nope")  # type: ignore[arg-type]
        assert "No deals yet" in html_out

    def test_only_garbage_items(self):
        html_out = render_deals_pipeline_html(deals=[None, "x", 1])  # type: ignore[list-item]
        assert "No deals yet" in html_out

    def test_renders_deal(self):
        html_out = render_deals_pipeline_html(deals=[_deal()])
        assert "Deal 0" in html_out
        assert "Discovery" in html_out
        assert "USD 10.0k" in html_out
        assert "open" in html_out

    def test_stage_grouping(self):
        html_out = render_deals_pipeline_html(
            deals=[
                _deal(idx=1, stage_name="Qualify"),
                _deal(idx=2, stage_name="Proposal"),
            ]
        )
        assert "Qualify" in html_out
        assert "Proposal" in html_out

    def test_stage_total_header(self):
        html_out = render_deals_pipeline_html(
            deals=[
                _deal(idx=1, stage_name="Qualify", amount=50_000),
                _deal(idx=2, stage_name="Qualify", amount=25_000),
            ]
        )
        # Stage total = 75k
        assert "USD 75.0k" in html_out

    def test_grand_total(self):
        html_out = render_deals_pipeline_html(
            deals=[
                _deal(idx=1, stage_name="A", amount=500_000),
                _deal(idx=2, stage_name="B", amount=500_000),
            ]
        )
        # Grand total = 1M
        assert "USD 1.0M" in html_out
        assert "total" in html_out

    def test_missing_name_fallback(self):
        html_out = render_deals_pipeline_html(deals=[_deal(name=None)])
        assert "(untitled)" in html_out

    def test_org_label(self):
        html_out = render_deals_pipeline_html(
            deals=[_deal()], org_label="Acme"
        )
        assert "Acme" in html_out

    def test_largest_first_in_stage(self):
        html_out = render_deals_pipeline_html(
            deals=[
                _deal(idx=1, name="Small", amount=1000, stage_name="X"),
                _deal(idx=2, name="Large", amount=50_000, stage_name="X"),
                _deal(idx=3, name="Medium", amount=5000, stage_name="X"),
            ]
        )
        large_pos = html_out.find("Large")
        medium_pos = html_out.find("Medium")
        small_pos = html_out.find("Small")
        assert large_pos < medium_pos < small_pos


class TestEscaping:
    def test_name_escaped(self):
        html_out = render_deals_pipeline_html(
            deals=[_deal(name="<script>evil()</script>")]
        )
        assert "<script>evil" not in html_out
        assert "&lt;script&gt;" in html_out

    def test_stage_name_escaped(self):
        html_out = render_deals_pipeline_html(
            deals=[_deal(stage_name="<xss>")]
        )
        assert "<xss>" not in html_out
        assert "&lt;xss&gt;" in html_out

    def test_status_escaped(self):
        html_out = render_deals_pipeline_html(
            deals=[_deal(status="<img>")]
        )
        assert "<img>" not in html_out


class TestBounds:
    def test_max_deals_rendered(self):
        # 120 deals, cap is 80 — omitted footer must appear.
        deals = [
            _deal(idx=i, amount=float(i * 100), stage_name=f"S_{i % 3}")
            for i in range(120)
        ]
        html_out = render_deals_pipeline_html(deals=deals)
        assert "omitted" in html_out

    def test_long_name_truncated(self):
        html_out = render_deals_pipeline_html(
            deals=[_deal(name="x" * 5000)]
        )
        assert "…" in html_out


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------


class TestDealsPipelineTextFallback:
    def test_empty(self):
        out = render_deals_pipeline_text_fallback(deals=None)
        assert "No deals yet" in out

        out2 = render_deals_pipeline_text_fallback(deals=[])
        assert "No deals yet" in out2

    def test_non_list(self):
        out = render_deals_pipeline_text_fallback(deals="nope")  # type: ignore[arg-type]
        assert "No deals yet" in out

    def test_only_garbage_items(self):
        out = render_deals_pipeline_text_fallback(deals=[None, "x", 1])  # type: ignore[list-item]
        assert "No deals yet" in out

    def test_renders_key_fields(self):
        out = render_deals_pipeline_text_fallback(deals=[_deal()])
        assert "Deal 0" in out
        assert "[open]" in out
        assert "USD 10.0k" in out

    def test_stage_grouping(self):
        out = render_deals_pipeline_text_fallback(
            deals=[
                _deal(idx=1, stage_name="Qualify"),
                _deal(idx=2, stage_name="Proposal"),
            ]
        )
        assert "## Qualify" in out
        assert "## Proposal" in out

    def test_pipeline_value_line(self):
        out = render_deals_pipeline_text_fallback(
            deals=[
                _deal(idx=1, amount=500_000),
                _deal(idx=2, amount=500_000),
            ]
        )
        assert "Pipeline value: USD 1.0M" in out

    def test_org_label(self):
        out = render_deals_pipeline_text_fallback(
            deals=[_deal()], org_label="Acme"
        )
        assert "# Deals — Acme" in out

    def test_close_date_line(self):
        out = render_deals_pipeline_text_fallback(
            deals=[_deal(close_date="2026-06-30")]
        )
        assert "Close: 2026-06-30" in out

    def test_max_cap_footer(self):
        deals = [
            _deal(idx=i, amount=float(i * 100), stage_name=f"S_{i % 3}")
            for i in range(120)
        ]
        out = render_deals_pipeline_text_fallback(deals=deals)
        assert "more deal(s)" in out

    def test_no_html_leak(self):
        out = render_deals_pipeline_text_fallback(
            deals=[_deal(name="<tag>")]
        )
        assert "<html>" not in out
        assert "<body>" not in out


# ---------------------------------------------------------------------------
# Caps sanity
# ---------------------------------------------------------------------------


class TestCapsExist:
    def test_constants(self):
        assert app_renderer._MAX_DEALS_RENDERED >= 10
        assert app_renderer._MAX_DEAL_NAME_LEN >= 50
