"""Unit tests for the Surface #69 per-company activities renderer.

Surface: g8://companies/{company_id}/activities  (+ .txt sibling)

Covers:
  - Empty states (None → unavailable, [] → no activities yet)
  - Header label derivation (name > domain > fallback)
  - Stat cards (total / calls / emails / meetings)
  - Type breakdown chips (with count + %)
  - Timeline rendering (subject / description / outcome / next-steps /
    date / owner / subtype / status / duration / contact / source chips)
  - Drill-up links (to companies/{id}/notes/contacts/deals; org-wide
    feed; backend filter URL) — and NOT self-referencing
  - Overflow banner when >25 activities
  - Security / regression locks (no JavaScript, no legacy hexes,
    graph8 design tokens, no single-side colored accent border, XSS
    escaping on all user-controlled fields)
  - Text fallback mirroring
"""

from __future__ import annotations

import pytest

from g8_mcp_server.app_renderer import (
    _G8_ACCENT_BG,
    _G8_ACCENT_BORDER,
    _G8_BORDER,
    _G8_CARD_RADIUS,
    _G8_FONT,
    _G8_MUTED_BG,
    _G8_PRIMARY,
    _company_activity_header_label,
    _render_company_activities_empty_state_html,
    render_company_activities_html,
    render_company_activities_text_fallback,
)


_COMPANY_ID = "comp_8ab27791efff40deaaaa"


def _sample_activity(**overrides) -> dict:
    base = {
        "id": "act_1",
        "activity_type": "call",
        "activity_subtype": "discovery",
        "subject": "Quarterly review call",
        "description": "Discussed Q4 renewal pipeline and expansion opportunities.",
        "activity_date": "2026-04-15T14:30:00",
        "duration_minutes": 45,
        "status": "completed",
        "outcome": "connected",
        "next_steps": "Follow up with pricing by Friday.",
        "owner_id": "usr_alice",
        "owner_name": "Alice Johnson",
        "contact_id": "cont_42",
        "company_id": _COMPANY_ID,
        "source": "hubspot",
        "external_id": "hs_7777",
    }
    base.update(overrides)
    return base


# ============================================================
# Header label helper
# ============================================================

class TestHeaderLabel:
    def test_name_preferred(self):
        out = _company_activity_header_label(
            {"name": "Acme Corp", "domain": "acme.com"}, _COMPANY_ID
        )
        assert out == "Acme Corp"

    def test_domain_fallback(self):
        out = _company_activity_header_label(
            {"domain": "globex.io"}, _COMPANY_ID
        )
        assert out == "globex.io"

    def test_id_fallback(self):
        out = _company_activity_header_label(None, _COMPANY_ID)
        assert out.startswith("Company ")
        assert _COMPANY_ID[:24] in out

    def test_empty_name_ignored(self):
        out = _company_activity_header_label(
            {"name": "  ", "domain": "globex.io"}, _COMPANY_ID
        )
        assert out == "globex.io"

    def test_unknown_id_fallback(self):
        out = _company_activity_header_label(None, "")
        assert "(unknown)" in out

    def test_long_name_clipped(self):
        name = "A" * 500
        out = _company_activity_header_label({"name": name}, _COMPANY_ID)
        assert len(out) <= 140

    def test_nondict_meta_tolerated(self):
        out = _company_activity_header_label("not-a-dict", _COMPANY_ID)
        assert out.startswith("Company ")

    def test_non_str_name_falls_through(self):
        out = _company_activity_header_label(
            {"name": 12345, "domain": "x.io"}, _COMPANY_ID
        )
        assert out == "x.io"


# ============================================================
# Empty state
# ============================================================

class TestEmptyState:
    def test_zero_activities_positive_tone(self):
        out = _render_company_activities_empty_state_html(
            company_id=_COMPANY_ID, zero_activities=True
        )
        assert "No activities yet" in out
        assert _COMPANY_ID[:64] in out
        assert _G8_PRIMARY in out
        assert _G8_ACCENT_BG in out

    def test_unavailable_muted_tone(self):
        out = _render_company_activities_empty_state_html(
            company_id=_COMPANY_ID, zero_activities=False
        )
        assert "Activities not available" in out
        assert "GET /companies" in out

    def test_no_company_id(self):
        out = _render_company_activities_empty_state_html(
            company_id="", zero_activities=True
        )
        assert "(unknown)" in out

    def test_empty_state_escapes_company_id(self):
        evil = "<script>alert(1)</script>"
        out = _render_company_activities_empty_state_html(
            company_id=evil, zero_activities=False
        )
        assert "<script>" not in out
        assert "&lt;script&gt;" in out


# ============================================================
# render_company_activities_html — None / empty inputs
# ============================================================

class TestRenderHtmlEdges:
    def test_none_returns_unavailable(self):
        out = render_company_activities_html(
            activities=None, company_id=_COMPANY_ID
        )
        assert "Activities not available" in out

    def test_empty_returns_no_activities(self):
        out = render_company_activities_html(
            activities=[], company_id=_COMPANY_ID
        )
        assert "No activities yet" in out

    def test_non_dict_rows_skipped(self):
        out = render_company_activities_html(
            activities=[
                "not-a-dict",
                None,
                _sample_activity(),
            ],
            company_id=_COMPANY_ID,
        )
        assert "Quarterly review call" in out
        # Only the dict contributes to the stat
        assert ">3<" in out or "3</div>" in out or "Total" in out
        # Non-dict rows don't crash the renderer


# ============================================================
# Header + stats + type breakdown
# ============================================================

class TestHeader:
    def test_name_used_in_header(self):
        out = render_company_activities_html(
            activities=[_sample_activity()],
            company_id=_COMPANY_ID,
            company_meta={"name": "Acme Corp"},
        )
        assert "Acme Corp" in out

    def test_company_id_in_header(self):
        out = render_company_activities_html(
            activities=[_sample_activity()],
            company_id=_COMPANY_ID,
        )
        assert _COMPANY_ID in out

    def test_domain_fallback_in_header(self):
        out = render_company_activities_html(
            activities=[_sample_activity()],
            company_id=_COMPANY_ID,
            company_meta={"domain": "globex.io"},
        )
        assert "globex.io" in out

    def test_fallback_header_when_no_meta(self):
        out = render_company_activities_html(
            activities=[_sample_activity()],
            company_id=_COMPANY_ID,
            company_meta=None,
        )
        assert "Company " in out

    def test_company_activities_label_shown(self):
        out = render_company_activities_html(
            activities=[_sample_activity()],
            company_id=_COMPANY_ID,
            company_meta={"name": "Acme"},
        )
        assert "Company activities" in out


class TestStats:
    def test_total_counts(self):
        activities = [
            _sample_activity(id="a", activity_type="call"),
            _sample_activity(id="b", activity_type="call"),
            _sample_activity(id="c", activity_type="email"),
            _sample_activity(id="d", activity_type="meeting"),
        ]
        out = render_company_activities_html(
            activities=activities, company_id=_COMPANY_ID
        )
        # Total: 4, Calls: 2, Emails: 1, Meetings: 1
        assert "Total" in out
        assert "Calls" in out
        assert "Emails" in out
        assert "Meetings" in out

    def test_mixed_type_bucketing(self):
        activities = [
            _sample_activity(id=f"a{i}", activity_type="call")
            for i in range(3)
        ] + [
            _sample_activity(id=f"b{i}", activity_type="email")
            for i in range(5)
        ]
        out = render_company_activities_html(
            activities=activities, company_id=_COMPANY_ID
        )
        assert "Calls" in out
        assert "Emails" in out


class TestTypeBreakdown:
    def test_type_chips_rendered(self):
        activities = [
            _sample_activity(id="a", activity_type="call"),
            _sample_activity(id="b", activity_type="email"),
            _sample_activity(id="c", activity_type="meeting"),
        ]
        out = render_company_activities_html(
            activities=activities, company_id=_COMPANY_ID
        )
        assert "Type breakdown" in out
        # 3 types at 33% each
        assert "33%" in out

    def test_overflow_when_many_types(self):
        # Create > 8 distinct activity types
        types = [
            "call", "email", "meeting", "note", "task",
            "sms", "linkedin", "demo", "appointment", "voicemail",
        ]
        activities = [
            _sample_activity(id=f"a{i}", activity_type=t)
            for i, t in enumerate(types)
        ]
        out = render_company_activities_html(
            activities=activities, company_id=_COMPANY_ID
        )
        assert "more type(s)" in out


# ============================================================
# Timeline rendering
# ============================================================

class TestTimeline:
    def test_subject_rendered(self):
        out = render_company_activities_html(
            activities=[_sample_activity(subject="Discovery call")],
            company_id=_COMPANY_ID,
        )
        assert "Discovery call" in out

    def test_description_rendered(self):
        out = render_company_activities_html(
            activities=[_sample_activity(description="Walked through demo")],
            company_id=_COMPANY_ID,
        )
        assert "Walked through demo" in out

    def test_outcome_rendered(self):
        out = render_company_activities_html(
            activities=[_sample_activity(outcome="booked")],
            company_id=_COMPANY_ID,
        )
        assert "Outcome:" in out
        assert "booked" in out

    def test_next_steps_rendered(self):
        out = render_company_activities_html(
            activities=[
                _sample_activity(next_steps="Send pricing doc")
            ],
            company_id=_COMPANY_ID,
        )
        assert "Next:" in out
        assert "Send pricing doc" in out

    def test_duration_chip(self):
        out = render_company_activities_html(
            activities=[_sample_activity(duration_minutes=90)],
            company_id=_COMPANY_ID,
        )
        assert "1h 30m" in out

    def test_duration_under_hour(self):
        out = render_company_activities_html(
            activities=[_sample_activity(duration_minutes=30)],
            company_id=_COMPANY_ID,
        )
        assert "30 min" in out

    def test_duration_none_hidden(self):
        out = render_company_activities_html(
            activities=[_sample_activity(duration_minutes=None)],
            company_id=_COMPANY_ID,
        )
        assert "min" not in out or "30 min" not in out  # at minimum no synthesized duration

    def test_owner_name_rendered(self):
        out = render_company_activities_html(
            activities=[_sample_activity(owner_name="Bob")],
            company_id=_COMPANY_ID,
        )
        assert "Bob" in out

    def test_subtype_chip(self):
        out = render_company_activities_html(
            activities=[_sample_activity(activity_subtype="outbound")],
            company_id=_COMPANY_ID,
        )
        assert "outbound" in out.lower()

    def test_status_chip(self):
        out = render_company_activities_html(
            activities=[_sample_activity(status="completed")],
            company_id=_COMPANY_ID,
        )
        assert "status:" in out
        assert "completed" in out

    def test_source_chip(self):
        out = render_company_activities_html(
            activities=[_sample_activity(source="outreach")],
            company_id=_COMPANY_ID,
        )
        assert "via outreach" in out

    def test_contact_chip_when_present(self):
        """Contact id chip is a company-activities-specific addition."""
        out = render_company_activities_html(
            activities=[_sample_activity(contact_id="cont_12345")],
            company_id=_COMPANY_ID,
        )
        assert "contact: cont_12345" in out

    def test_contact_chip_absent_when_missing(self):
        out = render_company_activities_html(
            activities=[_sample_activity(contact_id=None)],
            company_id=_COMPANY_ID,
        )
        assert "contact: " not in out

    def test_contact_chip_absent_when_empty(self):
        out = render_company_activities_html(
            activities=[_sample_activity(contact_id="")],
            company_id=_COMPANY_ID,
        )
        assert "contact: " not in out

    def test_overflow_banner_over_25(self):
        activities = [
            _sample_activity(id=f"a{i}", subject=f"Activity {i}")
            for i in range(30)
        ]
        out = render_company_activities_html(
            activities=activities, company_id=_COMPANY_ID
        )
        assert "+ 5 more activities" in out
        assert "GET /activities?company_id=" in out
        assert "limit=200" in out

    def test_no_overflow_at_or_under_25(self):
        activities = [
            _sample_activity(id=f"a{i}", subject=f"Act {i}")
            for i in range(25)
        ]
        out = render_company_activities_html(
            activities=activities, company_id=_COMPANY_ID
        )
        assert "more activities" not in out


# ============================================================
# Drill-up
# ============================================================

class TestDrillUp:
    def test_parent_company_link(self):
        out = render_company_activities_html(
            activities=[_sample_activity()], company_id=_COMPANY_ID
        )
        assert f"g8://companies/{_COMPANY_ID}" in out

    def test_notes_link(self):
        out = render_company_activities_html(
            activities=[_sample_activity()], company_id=_COMPANY_ID
        )
        assert f"g8://companies/{_COMPANY_ID}/notes" in out

    def test_contacts_link(self):
        out = render_company_activities_html(
            activities=[_sample_activity()], company_id=_COMPANY_ID
        )
        assert f"g8://companies/{_COMPANY_ID}/contacts" in out

    def test_deals_link(self):
        out = render_company_activities_html(
            activities=[_sample_activity()], company_id=_COMPANY_ID
        )
        assert f"g8://companies/{_COMPANY_ID}/deals" in out

    def test_activity_feed_link(self):
        out = render_company_activities_html(
            activities=[_sample_activity()], company_id=_COMPANY_ID
        )
        assert "g8://activities/feed" in out

    def test_backend_filter_link(self):
        out = render_company_activities_html(
            activities=[_sample_activity()], company_id=_COMPANY_ID
        )
        assert f"GET /activities?company_id={_COMPANY_ID}" in out

    def test_no_self_reference(self):
        out = render_company_activities_html(
            activities=[_sample_activity()], company_id=_COMPANY_ID
        )
        assert f"g8://companies/{_COMPANY_ID}/activities" not in out

    def test_manage_heading(self):
        out = render_company_activities_html(
            activities=[_sample_activity()], company_id=_COMPANY_ID
        )
        assert "Manage this company" in out


# ============================================================
# Regression / security locks
# ============================================================

class TestDesignTokens:
    def test_primary_color_used(self):
        out = render_company_activities_html(
            activities=[_sample_activity()], company_id=_COMPANY_ID
        )
        assert _G8_PRIMARY in out

    def test_border_color_used(self):
        out = render_company_activities_html(
            activities=[_sample_activity()], company_id=_COMPANY_ID
        )
        assert _G8_BORDER in out

    def test_font_used(self):
        out = render_company_activities_html(
            activities=[_sample_activity()], company_id=_COMPANY_ID
        )
        assert _G8_FONT in out

    def test_card_radius_used(self):
        out = render_company_activities_html(
            activities=[_sample_activity()], company_id=_COMPANY_ID
        )
        assert _G8_CARD_RADIUS in out

    def test_muted_bg_used(self):
        out = render_company_activities_html(
            activities=[_sample_activity()], company_id=_COMPANY_ID
        )
        assert _G8_MUTED_BG in out


class TestNoLegacyHexes:
    @pytest.mark.parametrize("bad_hex", [
        "#000000", "#000 ",  # true black
        "#FFF ", "#ffffff",   # true white (sometimes allowed if card bg — keep flexible)
        "#FF0000", "#ff0000",  # pure red
    ])
    def test_no_legacy_hex(self, bad_hex):
        out = render_company_activities_html(
            activities=[_sample_activity()], company_id=_COMPANY_ID
        )
        # #ffffff is the card bg — allow it
        if bad_hex.lower().strip() in ("#fff ", "#ffffff"):
            return
        assert bad_hex not in out, f"Found legacy hex {bad_hex}"


class TestNoJavaScript:
    def test_no_script_tags(self):
        out = render_company_activities_html(
            activities=[_sample_activity()], company_id=_COMPANY_ID
        )
        assert "<script" not in out
        assert "javascript:" not in out

    def test_no_event_handlers(self):
        out = render_company_activities_html(
            activities=[_sample_activity()], company_id=_COMPANY_ID
        )
        for evt in ("onclick=", "onload=", "onerror=", "onmouseover="):
            assert evt not in out


class TestNoSingleSideColoredAccentBorder:
    def test_no_border_left_primary(self):
        out = render_company_activities_html(
            activities=[_sample_activity()], company_id=_COMPANY_ID
        )
        # Allow `border-top:3px solid <accent>` (used in empty-state)
        # but no `border-left:<color>: _G8_PRIMARY on activity rows
        assert f"border-left:3px solid {_G8_PRIMARY}" not in out
        assert f"border-left:4px solid {_G8_PRIMARY}" not in out


class TestXssEscape:
    def test_escape_subject(self):
        out = render_company_activities_html(
            activities=[_sample_activity(subject="<img src=x onerror=alert(1)>")],
            company_id=_COMPANY_ID,
        )
        assert "<img src=x onerror=alert" not in out
        assert "&lt;img" in out

    def test_escape_description(self):
        out = render_company_activities_html(
            activities=[_sample_activity(description="<script>evil()</script>")],
            company_id=_COMPANY_ID,
        )
        assert "<script>evil" not in out
        assert "&lt;script&gt;" in out

    def test_escape_next_steps(self):
        out = render_company_activities_html(
            activities=[_sample_activity(next_steps="<b>bold</b>")],
            company_id=_COMPANY_ID,
        )
        assert "<b>bold</b>" not in out

    def test_escape_owner_name(self):
        out = render_company_activities_html(
            activities=[_sample_activity(owner_name="<svg/onload=alert(1)>")],
            company_id=_COMPANY_ID,
        )
        assert "<svg" not in out

    def test_escape_company_id(self):
        evil_id = "<img src=x>"
        out = render_company_activities_html(
            activities=[_sample_activity()],
            company_id=evil_id,
        )
        # company_id is used in drill-up code tags — must be escaped
        assert "<img src=x>" not in out
        assert "&lt;img src=x&gt;" in out

    def test_escape_company_name(self):
        out = render_company_activities_html(
            activities=[_sample_activity()],
            company_id=_COMPANY_ID,
            company_meta={"name": "<h1>XSS</h1>"},
        )
        assert "<h1>XSS" not in out

    def test_escape_outcome(self):
        out = render_company_activities_html(
            activities=[_sample_activity(outcome="<iframe>")],
            company_id=_COMPANY_ID,
        )
        assert "<iframe>" not in out

    def test_escape_source(self):
        out = render_company_activities_html(
            activities=[_sample_activity(source="<x>")],
            company_id=_COMPANY_ID,
        )
        assert ">via <x>" not in out


# ============================================================
# HTML well-formedness
# ============================================================

class TestWellFormed:
    def test_doctype_present(self):
        out = render_company_activities_html(
            activities=[_sample_activity()], company_id=_COMPANY_ID
        )
        assert out.startswith("<!DOCTYPE html>")

    def test_html_body_tags(self):
        out = render_company_activities_html(
            activities=[_sample_activity()], company_id=_COMPANY_ID
        )
        assert "<html" in out
        assert "<body" in out
        assert out.rstrip().endswith("</html>")


# ============================================================
# Text fallback
# ============================================================

class TestTextFallback:
    def test_none_unavailable(self):
        out = render_company_activities_text_fallback(
            activities=None, company_id=_COMPANY_ID
        )
        assert "# Activities not available" in out
        assert _COMPANY_ID in out

    def test_empty_no_activities(self):
        out = render_company_activities_text_fallback(
            activities=[], company_id=_COMPANY_ID
        )
        assert "# No activities yet" in out
        assert _COMPANY_ID in out

    def test_header_name(self):
        out = render_company_activities_text_fallback(
            activities=[_sample_activity()],
            company_id=_COMPANY_ID,
            company_meta={"name": "Acme"},
        )
        assert "# Acme — activities" in out

    def test_header_fallback(self):
        out = render_company_activities_text_fallback(
            activities=[_sample_activity()],
            company_id=_COMPANY_ID,
            company_meta=None,
        )
        assert "# Company " in out

    def test_stats_section(self):
        activities = [
            _sample_activity(id="a", activity_type="call"),
            _sample_activity(id="b", activity_type="email"),
            _sample_activity(id="c", activity_type="meeting"),
        ]
        out = render_company_activities_text_fallback(
            activities=activities, company_id=_COMPANY_ID
        )
        assert "## Stats" in out
        assert "- Total: 3" in out
        assert "- Calls: 1" in out
        assert "- Emails: 1" in out
        assert "- Meetings: 1" in out

    def test_type_breakdown_section(self):
        activities = [
            _sample_activity(id="a", activity_type="call"),
            _sample_activity(id="b", activity_type="email"),
        ]
        out = render_company_activities_text_fallback(
            activities=activities, company_id=_COMPANY_ID
        )
        assert "## Type breakdown" in out

    def test_timeline_section(self):
        out = render_company_activities_text_fallback(
            activities=[_sample_activity(subject="Discovery")],
            company_id=_COMPANY_ID,
        )
        assert "## Timeline" in out
        assert "Discovery" in out

    def test_description_mirrored(self):
        out = render_company_activities_text_fallback(
            activities=[_sample_activity(description="Demo walkthrough")],
            company_id=_COMPANY_ID,
        )
        assert "Demo walkthrough" in out

    def test_outcome_mirrored(self):
        out = render_company_activities_text_fallback(
            activities=[_sample_activity(outcome="connected")],
            company_id=_COMPANY_ID,
        )
        assert "Outcome: connected" in out

    def test_next_steps_mirrored(self):
        out = render_company_activities_text_fallback(
            activities=[_sample_activity(next_steps="Send docs")],
            company_id=_COMPANY_ID,
        )
        assert "Next: Send docs" in out

    def test_duration_mirrored(self):
        out = render_company_activities_text_fallback(
            activities=[_sample_activity(duration_minutes=90)],
            company_id=_COMPANY_ID,
        )
        assert "duration=1h 30m" in out

    def test_status_mirrored(self):
        out = render_company_activities_text_fallback(
            activities=[_sample_activity(status="completed")],
            company_id=_COMPANY_ID,
        )
        assert "status=completed" in out

    def test_source_mirrored(self):
        out = render_company_activities_text_fallback(
            activities=[_sample_activity(source="outreach")],
            company_id=_COMPANY_ID,
        )
        assert "source=outreach" in out

    def test_contact_mirrored(self):
        out = render_company_activities_text_fallback(
            activities=[_sample_activity(contact_id="cont_77")],
            company_id=_COMPANY_ID,
        )
        assert "contact=cont_77" in out

    def test_overflow_banner_text(self):
        activities = [
            _sample_activity(id=f"a{i}") for i in range(30)
        ]
        out = render_company_activities_text_fallback(
            activities=activities, company_id=_COMPANY_ID
        )
        assert "+ 5 more activities" in out
        assert "company_id=" in out

    def test_manage_section(self):
        out = render_company_activities_text_fallback(
            activities=[_sample_activity()], company_id=_COMPANY_ID
        )
        assert "## Manage this company" in out
        assert f"`g8://companies/{_COMPANY_ID}`" in out
        assert f"`g8://companies/{_COMPANY_ID}/notes`" in out
        assert f"`g8://companies/{_COMPANY_ID}/contacts`" in out
        assert f"`g8://companies/{_COMPANY_ID}/deals`" in out
        assert "`g8://activities/feed`" in out

    def test_text_no_self_reference(self):
        out = render_company_activities_text_fallback(
            activities=[_sample_activity()], company_id=_COMPANY_ID
        )
        assert f"g8://companies/{_COMPANY_ID}/activities" not in out

    def test_text_newline_terminated(self):
        out = render_company_activities_text_fallback(
            activities=[_sample_activity()], company_id=_COMPANY_ID
        )
        assert out.endswith("\n")


# ============================================================
# Smoke: full-stack sanity
# ============================================================

class TestSmoke:
    def test_populated_full_render(self):
        activities = [
            _sample_activity(
                id="a1",
                activity_type="call",
                subject="Kickoff call",
                description="Introductory conversation",
                outcome="connected",
                next_steps="Send followup",
                duration_minutes=30,
                owner_name="Alice",
                contact_id="cont_1",
            ),
            _sample_activity(
                id="a2",
                activity_type="email",
                subject="Pricing email",
                description=None,
                outcome=None,
                next_steps=None,
                duration_minutes=None,
                owner_name="Bob",
                contact_id="cont_2",
            ),
        ]
        out = render_company_activities_html(
            activities=activities,
            company_id=_COMPANY_ID,
            company_meta={"name": "Acme Corp"},
        )
        assert "Acme Corp" in out
        assert "Kickoff call" in out
        assert "Pricing email" in out
        assert "Alice" in out
        assert "Bob" in out
        assert "cont_1" in out
        assert "cont_2" in out

    def test_text_smoke(self):
        out = render_company_activities_text_fallback(
            activities=[_sample_activity()],
            company_id=_COMPANY_ID,
            company_meta={"name": "Acme"},
        )
        assert "# Acme — activities" in out
        assert "Quarterly review call" in out
