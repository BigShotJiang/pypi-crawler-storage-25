"""Unit tests for Surface #65 — `render_gc_doc_detail_html` / text fallback.

Per-global-context-document detail: `g8://global-context/documents/{doc_id}`
(+ `.txt` sibling). Mirrors the structure of test_list_detail_renderer.py
(Surface #64).

graph8-native design: only `_G8_*` tokens — no Studio legacy hexes.
"""

from __future__ import annotations

import pytest

from mcp_server.g8_mcp_server import app_renderer as ar


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


_DOC_ID = "7e1a8c42-aaaa-4bbb-8ccc-dddddddddddd"


_SAMPLE_DOC: dict = {
    "id": _DOC_ID,
    "display_name": "Brand Brief — Q2 2026",
    "file_type": "markdown",
    "category": "brand_brief",
    "folder_path": "context/brand/",
    "status": "ready",
    "priority": 10,
    "version": "v3.1",
    "content": (
        "graph8 helps sales teams find and convert their best-fit buyers.\n"
        "Core values: clarity, speed, signal over noise.\n\n"
        "## Core Audience\n"
        "B2B SaaS sales teams of 5-50 reps."
    ),
    "created_at": "2026-01-15T10:30:00Z",
    "updated_at": "2026-04-18T14:22:00Z",
}


_LEGACY_STUDIO_HEXES = (
    "#eef2ff",
    "#4338ca",
    "#f59e0b",
    "#166534",
    "#a16207",
    "#7c2d12",
    "#6b7280",
)


# ---------------------------------------------------------------------------
# _gc_doc_detail_clip
# ---------------------------------------------------------------------------


class TestClip:
    def test_none(self):
        assert ar._gc_doc_detail_clip(None, 100) == ""

    def test_non_string(self):
        assert ar._gc_doc_detail_clip(42, 100) == ""
        assert ar._gc_doc_detail_clip(["x"], 100) == ""

    def test_whitespace(self):
        assert ar._gc_doc_detail_clip("   ", 100) == ""

    def test_under_cap(self):
        assert ar._gc_doc_detail_clip("hello", 100) == "hello"

    def test_over_cap(self):
        out = ar._gc_doc_detail_clip("hello world", 5)
        assert out.endswith("…")
        assert len(out) == 5

    def test_no_escape(self):
        # Clip does NOT escape — callers (chip/meta_row) escape. Avoids double-escape.
        assert ar._gc_doc_detail_clip("<script>", 100) == "<script>"


# ---------------------------------------------------------------------------
# _gc_doc_detail_title
# ---------------------------------------------------------------------------


class TestTitle:
    def test_none(self):
        assert ar._gc_doc_detail_title(None, "abc") == "Document #abc"

    def test_empty(self):
        assert ar._gc_doc_detail_title({}, "abc") == "Document #abc"

    def test_has_display_name(self):
        out = ar._gc_doc_detail_title({"display_name": "Brand Brief"}, "abc")
        assert out == "Brand Brief"

    def test_has_title_alias(self):
        # Fallback to 'title' if 'display_name' is missing
        out = ar._gc_doc_detail_title({"title": "Style Guide"}, "abc")
        assert out == "Style Guide"

    def test_display_name_wins(self):
        # display_name takes priority over title
        out = ar._gc_doc_detail_title(
            {"display_name": "Brand", "title": "Other"}, "abc"
        )
        assert out == "Brand"

    def test_whitespace(self):
        out = ar._gc_doc_detail_title({"display_name": "   "}, "abc")
        assert out == "Document #abc"

    def test_non_string(self):
        out = ar._gc_doc_detail_title({"display_name": 42}, "abc")
        assert out == "Document #abc"

    def test_escape(self):
        out = ar._gc_doc_detail_title({"display_name": "<script>"}, "abc")
        assert out == "&lt;script&gt;"

    def test_clip(self):
        long = "x" * 300
        out = ar._gc_doc_detail_title({"display_name": long}, "abc")
        assert out.endswith("…")
        assert len(out) <= ar._MAX_GC_DOC_TITLE_LEN

    def test_id_escape(self):
        out = ar._gc_doc_detail_title(None, "<evil>")
        assert "&lt;evil&gt;" in out


# ---------------------------------------------------------------------------
# _gc_doc_detail_id_matches
# ---------------------------------------------------------------------------


class TestIdMatches:
    def test_match(self):
        assert ar._gc_doc_detail_id_matches({"id": "abc"}, "abc") is True

    def test_mismatch(self):
        assert ar._gc_doc_detail_id_matches({"id": "abc"}, "def") is False

    def test_none_lenient(self):
        assert ar._gc_doc_detail_id_matches(None, "abc") is True

    def test_missing_id_lenient(self):
        assert ar._gc_doc_detail_id_matches({}, "abc") is True

    def test_whitespace(self):
        assert ar._gc_doc_detail_id_matches({"id": "abc"}, "  abc  ") is True

    def test_uuid_shape(self):
        u = "550e8400-e29b-41d4-a716-446655440000"
        assert ar._gc_doc_detail_id_matches({"id": u}, u) is True


# ---------------------------------------------------------------------------
# _gc_doc_detail_category_accent
# ---------------------------------------------------------------------------


class TestCategoryAccent:
    def test_brand_brief(self):
        bg, fg, border = ar._gc_doc_detail_category_accent("brand_brief")
        assert fg == ar._G8_PRIMARY

    def test_personas(self):
        bg, fg, border = ar._gc_doc_detail_category_accent("personas")
        assert fg == ar._G8_PRIMARY

    def test_value_props(self):
        bg, fg, border = ar._gc_doc_detail_category_accent("value_props")
        assert fg == ar._G8_PRIMARY

    def test_website_scrape(self):
        bg, fg, border = ar._gc_doc_detail_category_accent("website_scrape")
        assert fg == ar._G8_POSITIVE_FG

    def test_company_enrichment(self):
        bg, fg, border = ar._gc_doc_detail_category_accent("company_enrichment")
        assert fg == ar._G8_POSITIVE_FG

    def test_buyer_psychology(self):
        bg, fg, border = ar._gc_doc_detail_category_accent("buyer_psychology")
        assert fg == ar._G8_WARNING_FG

    def test_review_sentiment(self):
        bg, fg, border = ar._gc_doc_detail_category_accent("review_sentiment")
        assert fg == ar._G8_WARNING_FG

    def test_campaign_brief(self):
        bg, fg, border = ar._gc_doc_detail_category_accent("campaign_intelligence_brief")
        assert fg == ar._G8_PRIMARY

    def test_unknown(self):
        bg, fg, border = ar._gc_doc_detail_category_accent("quantum")
        assert fg == ar._G8_TEXT_MUTED

    def test_none(self):
        bg, fg, border = ar._gc_doc_detail_category_accent(None)
        assert fg == ar._G8_TEXT_MUTED

    def test_empty(self):
        bg, fg, border = ar._gc_doc_detail_category_accent("")
        assert fg == ar._G8_TEXT_MUTED


# ---------------------------------------------------------------------------
# _gc_doc_detail_status_accent
# ---------------------------------------------------------------------------


class TestStatusAccent:
    def test_ready(self):
        bg, fg, border = ar._gc_doc_detail_status_accent("ready")
        assert fg == ar._G8_POSITIVE_FG

    def test_complete(self):
        bg, fg, border = ar._gc_doc_detail_status_accent("complete")
        assert fg == ar._G8_POSITIVE_FG

    def test_processing(self):
        bg, fg, border = ar._gc_doc_detail_status_accent("processing")
        assert fg == ar._G8_PRIMARY

    def test_draft(self):
        bg, fg, border = ar._gc_doc_detail_status_accent("draft")
        assert fg == ar._G8_PRIMARY

    def test_error(self):
        bg, fg, border = ar._gc_doc_detail_status_accent("error")
        assert fg == ar._G8_WARNING_FG

    def test_archived(self):
        bg, fg, border = ar._gc_doc_detail_status_accent("archived")
        assert fg == ar._G8_TEXT_MUTED

    def test_none(self):
        bg, fg, border = ar._gc_doc_detail_status_accent(None)
        assert fg == ar._G8_TEXT_MUTED


# ---------------------------------------------------------------------------
# _gc_doc_detail_parse_priority
# ---------------------------------------------------------------------------


class TestParsePriority:
    def test_none(self):
        assert ar._gc_doc_detail_parse_priority(None) is None

    def test_int(self):
        assert ar._gc_doc_detail_parse_priority(10) == 10

    def test_zero(self):
        assert ar._gc_doc_detail_parse_priority(0) == 0

    def test_negative(self):
        # negative accepted (priority can be -1 for deprioritized)
        assert ar._gc_doc_detail_parse_priority(-1) == -1

    def test_float(self):
        assert ar._gc_doc_detail_parse_priority(3.7) == 3

    def test_string(self):
        assert ar._gc_doc_detail_parse_priority("5") == 5

    def test_string_float(self):
        assert ar._gc_doc_detail_parse_priority("5.9") == 5

    def test_bool_rejected(self):
        assert ar._gc_doc_detail_parse_priority(True) is None
        assert ar._gc_doc_detail_parse_priority(False) is None

    def test_nan_rejected(self):
        assert ar._gc_doc_detail_parse_priority(float("nan")) is None

    def test_inf_rejected(self):
        assert ar._gc_doc_detail_parse_priority(float("inf")) is None

    def test_garbage(self):
        assert ar._gc_doc_detail_parse_priority("high") is None

    def test_empty_string(self):
        assert ar._gc_doc_detail_parse_priority("") is None


# ---------------------------------------------------------------------------
# _gc_doc_detail_format_datetime
# ---------------------------------------------------------------------------


class TestFormatDatetime:
    def test_none(self):
        assert ar._gc_doc_detail_format_datetime(None) == ""

    def test_iso(self):
        out = ar._gc_doc_detail_format_datetime("2026-04-18T14:22:00Z")
        assert "2026" in out

    def test_empty(self):
        assert ar._gc_doc_detail_format_datetime("") == ""


# ---------------------------------------------------------------------------
# _gc_doc_detail_chip + meta_row + kpi_card
# ---------------------------------------------------------------------------


class TestChip:
    def test_basic(self):
        out = ar._gc_doc_detail_chip("Ready")
        assert "Ready" in out

    def test_escape(self):
        out = ar._gc_doc_detail_chip("<script>")
        assert "<script>" not in out
        assert "&lt;script&gt;" in out


class TestKpiCard:
    def test_basic(self):
        out = ar._gc_doc_detail_kpi_card("Priority", "10")
        assert "Priority" in out
        assert "10" in out

    def test_primary_accent(self):
        out = ar._gc_doc_detail_kpi_card("X", "Y", accent="primary")
        assert ar._G8_PRIMARY in out

    def test_muted_accent(self):
        out = ar._gc_doc_detail_kpi_card("X", "Y", accent="muted")
        assert ar._G8_TEXT_MUTED in out


# ---------------------------------------------------------------------------
# _gc_doc_detail_content_section
# ---------------------------------------------------------------------------


class TestContentSection:
    def test_none(self):
        assert ar._gc_doc_detail_content_section(None) == ""

    def test_non_string(self):
        assert ar._gc_doc_detail_content_section(42) == ""

    def test_whitespace(self):
        assert ar._gc_doc_detail_content_section("  ") == ""

    def test_basic(self):
        out = ar._gc_doc_detail_content_section("Hello world")
        assert "Hello world" in out

    def test_newline_to_br(self):
        out = ar._gc_doc_detail_content_section("line1\nline2")
        assert "<br>" in out

    def test_escape_then_br(self):
        out = ar._gc_doc_detail_content_section("<script>\nalert(1)")
        assert "<script>" not in out
        assert "&lt;script&gt;" in out
        assert "<br>" in out

    def test_escape(self):
        out = ar._gc_doc_detail_content_section("<img src=x>")
        assert "<img src=x>" not in out
        assert "&lt;img" in out

    def test_clip(self):
        long = "x" * 30_000
        out = ar._gc_doc_detail_content_section(long)
        assert "…" in out
        # Should not blow past content cap substantially
        assert len(out) < 50_000


# ---------------------------------------------------------------------------
# _gc_doc_detail_metadata_section
# ---------------------------------------------------------------------------


class TestMetadataSection:
    def test_empty(self):
        assert ar._gc_doc_detail_metadata_section([]) == ""

    def test_all_empty_values(self):
        # Filters out empty values
        out = ar._gc_doc_detail_metadata_section([("X", ""), ("Y", "")])
        assert out == ""

    def test_basic(self):
        out = ar._gc_doc_detail_metadata_section([
            ("Folder", "context/brand"),
            ("Created", "2026-01-15"),
        ])
        assert "Folder" in out
        assert "context/brand" in out
        assert "Created" in out


# ---------------------------------------------------------------------------
# _gc_doc_detail_empty_state_html
# ---------------------------------------------------------------------------


class TestEmptyStateHtml:
    def test_unavailable(self):
        out = ar._gc_doc_detail_empty_state_html(mode="unavailable", doc_id="abc")
        assert "unavailable" in out.lower() or "not available" in out.lower()

    def test_not_found(self):
        out = ar._gc_doc_detail_empty_state_html(mode="not_found", doc_id="abc")
        assert "not found" in out.lower()

    def test_escapes_id(self):
        out = ar._gc_doc_detail_empty_state_html(mode="unavailable", doc_id="<evil>")
        assert "<evil>" not in out
        assert "&lt;evil&gt;" in out

    def test_no_legacy_hexes(self):
        out = ar._gc_doc_detail_empty_state_html(mode="unavailable", doc_id="abc")
        for hex_color in _LEGACY_STUDIO_HEXES:
            assert hex_color.lower() not in out.lower()


# ---------------------------------------------------------------------------
# render_gc_doc_detail_html
# ---------------------------------------------------------------------------


class TestRenderHtml:
    def test_basic(self):
        out = ar.render_gc_doc_detail_html(doc_id=_DOC_ID, doc=_SAMPLE_DOC)
        assert "<!DOCTYPE html>" in out
        assert "Brand Brief" in out

    def test_none(self):
        out = ar.render_gc_doc_detail_html(doc_id=_DOC_ID, doc=None)
        assert "unavailable" in out.lower() or "not available" in out.lower()

    def test_mismatched_id(self):
        out = ar.render_gc_doc_detail_html(
            doc_id="other", doc={**_SAMPLE_DOC, "id": "different"}
        )
        assert "not found" in out.lower()

    def test_title_rendered(self):
        out = ar.render_gc_doc_detail_html(doc_id=_DOC_ID, doc=_SAMPLE_DOC)
        assert "Brand Brief" in out

    def test_category_chip(self):
        out = ar.render_gc_doc_detail_html(doc_id=_DOC_ID, doc=_SAMPLE_DOC)
        assert "brand_brief" in out

    def test_file_type_chip(self):
        out = ar.render_gc_doc_detail_html(doc_id=_DOC_ID, doc=_SAMPLE_DOC)
        assert "markdown" in out

    def test_status_chip(self):
        out = ar.render_gc_doc_detail_html(doc_id=_DOC_ID, doc=_SAMPLE_DOC)
        assert "READY" in out  # uppercased

    def test_priority_rendered(self):
        out = ar.render_gc_doc_detail_html(doc_id=_DOC_ID, doc=_SAMPLE_DOC)
        assert "10" in out

    def test_version_rendered(self):
        out = ar.render_gc_doc_detail_html(doc_id=_DOC_ID, doc=_SAMPLE_DOC)
        assert "v3.1" in out

    def test_content_rendered(self):
        out = ar.render_gc_doc_detail_html(doc_id=_DOC_ID, doc=_SAMPLE_DOC)
        assert "Core Audience" in out
        assert "<br>" in out  # newline conversion

    def test_folder_path_in_metadata(self):
        out = ar.render_gc_doc_detail_html(doc_id=_DOC_ID, doc=_SAMPLE_DOC)
        assert "context/brand/" in out

    def test_drill_up_library(self):
        out = ar.render_gc_doc_detail_html(doc_id=_DOC_ID, doc=_SAMPLE_DOC)
        assert "g8://global-context/library" in out

    def test_drill_up_does_NOT_list_self(self):
        """Drill-up must not include a link back to this same doc."""
        out = ar.render_gc_doc_detail_html(doc_id=_DOC_ID, doc=_SAMPLE_DOC)
        # bare URI to self should not appear as drill-up bullet
        self_uri = f"<code>g8://global-context/documents/{_DOC_ID}</code>"
        assert self_uri not in out

    def test_no_javascript(self):
        out = ar.render_gc_doc_detail_html(doc_id=_DOC_ID, doc=_SAMPLE_DOC)
        assert "javascript:" not in out.lower()
        assert "<script" not in out.lower()

    def test_no_legacy_accent_hexes(self):
        out = ar.render_gc_doc_detail_html(doc_id=_DOC_ID, doc=_SAMPLE_DOC)
        for hex_color in _LEGACY_STUDIO_HEXES:
            assert hex_color.lower() not in out.lower(), (
                f"leaked legacy hex {hex_color}"
            )

    def test_uses_graph8_primary(self):
        out = ar.render_gc_doc_detail_html(doc_id=_DOC_ID, doc=_SAMPLE_DOC)
        assert ar._G8_PRIMARY.lower() in out.lower()

    def test_uses_graph8_font(self):
        out = ar.render_gc_doc_detail_html(doc_id=_DOC_ID, doc=_SAMPLE_DOC)
        assert "Aeonik" in out

    def test_no_single_side_colored_accent_border(self):
        import re
        out = ar.render_gc_doc_detail_html(doc_id=_DOC_ID, doc=_SAMPLE_DOC)
        accent_hexes = [
            ar._G8_PRIMARY.lower(),
            ar._G8_POSITIVE_FG.lower(),
            ar._G8_WARNING_FG.lower(),
        ]
        for hex_color in accent_hexes:
            pattern = re.compile(
                rf"border-(top|right|bottom|left):\s*\d+px\s+solid\s+{re.escape(hex_color)}",
                re.IGNORECASE,
            )
            matches = pattern.findall(out)
            assert not matches, (
                f"single-side colored accent border ({hex_color}) found: {matches}"
            )

    def test_xss_title(self):
        doc = {**_SAMPLE_DOC, "display_name": "<script>alert(1)</script>"}
        out = ar.render_gc_doc_detail_html(doc_id=_DOC_ID, doc=doc)
        assert "<script>alert(1)</script>" not in out
        assert "&lt;script&gt;" in out

    def test_xss_content(self):
        doc = {**_SAMPLE_DOC, "content": "<script>alert(1)</script>"}
        out = ar.render_gc_doc_detail_html(doc_id=_DOC_ID, doc=doc)
        assert "<script>alert(1)</script>" not in out
        assert "&lt;script&gt;" in out

    def test_xss_category(self):
        doc = {**_SAMPLE_DOC, "category": "<img src=x>"}
        out = ar.render_gc_doc_detail_html(doc_id=_DOC_ID, doc=doc)
        assert "<img src=x>" not in out

    def test_xss_folder(self):
        doc = {**_SAMPLE_DOC, "folder_path": "<evil>"}
        out = ar.render_gc_doc_detail_html(doc_id=_DOC_ID, doc=doc)
        assert "<evil>" not in out
        assert "&lt;evil&gt;" in out

    def test_xss_doc_id(self):
        out = ar.render_gc_doc_detail_html(doc_id="<evil>", doc=None)
        assert "<evil>" not in out
        assert "&lt;evil&gt;" in out

    def test_missing_content(self):
        doc = {**_SAMPLE_DOC}
        del doc["content"]
        out = ar.render_gc_doc_detail_html(doc_id=_DOC_ID, doc=doc)
        # Should render without crash — no content section
        assert "Brand Brief" in out

    def test_missing_priority(self):
        doc = {**_SAMPLE_DOC}
        del doc["priority"]
        out = ar.render_gc_doc_detail_html(doc_id=_DOC_ID, doc=doc)
        assert "—" in out  # dash for missing priority

    def test_minimal_doc(self):
        doc = {"id": "x", "display_name": "Test"}
        out = ar.render_gc_doc_detail_html(doc_id="x", doc=doc)
        assert "Test" in out

    def test_html_well_formed(self):
        out = ar.render_gc_doc_detail_html(doc_id=_DOC_ID, doc=_SAMPLE_DOC)
        assert out.startswith("<!DOCTYPE html>")
        assert out.strip().endswith("</html>")

    def test_kpi_quadrant(self):
        out = ar.render_gc_doc_detail_html(doc_id=_DOC_ID, doc=_SAMPLE_DOC)
        assert "Priority" in out
        assert "Version" in out
        assert "Category" in out
        assert "Updated" in out


# ---------------------------------------------------------------------------
# render_gc_doc_detail_text_fallback
# ---------------------------------------------------------------------------


class TestTextFallback:
    def test_basic(self):
        out = ar.render_gc_doc_detail_text_fallback(
            doc_id=_DOC_ID, doc=_SAMPLE_DOC
        )
        assert "Brand Brief" in out

    def test_none(self):
        out = ar.render_gc_doc_detail_text_fallback(doc_id=_DOC_ID, doc=None)
        assert "not available" in out.lower() or "unavailable" in out.lower()

    def test_mismatch(self):
        out = ar.render_gc_doc_detail_text_fallback(
            doc_id="other", doc={**_SAMPLE_DOC, "id": "different"}
        )
        assert "not found" in out.lower() or "no document" in out.lower()

    def test_content_rendered(self):
        out = ar.render_gc_doc_detail_text_fallback(
            doc_id=_DOC_ID, doc=_SAMPLE_DOC
        )
        assert "Core Audience" in out

    def test_priority_rendered(self):
        out = ar.render_gc_doc_detail_text_fallback(
            doc_id=_DOC_ID, doc=_SAMPLE_DOC
        )
        assert "10" in out

    def test_related_surfaces(self):
        out = ar.render_gc_doc_detail_text_fallback(
            doc_id=_DOC_ID, doc=_SAMPLE_DOC
        )
        assert "g8://global-context/library" in out

    def test_markdown_headings(self):
        out = ar.render_gc_doc_detail_text_fallback(
            doc_id=_DOC_ID, doc=_SAMPLE_DOC
        )
        assert "##" in out

    def test_no_html(self):
        out = ar.render_gc_doc_detail_text_fallback(
            doc_id=_DOC_ID, doc=_SAMPLE_DOC
        )
        assert "<html>" not in out
        assert "<div" not in out

    def test_ends_with_newline(self):
        out = ar.render_gc_doc_detail_text_fallback(
            doc_id=_DOC_ID, doc=_SAMPLE_DOC
        )
        assert out.endswith("\n")


# ---------------------------------------------------------------------------
# Smoke
# ---------------------------------------------------------------------------


class TestSmoke:
    def test_roundtrip(self):
        h = ar.render_gc_doc_detail_html(doc_id=_DOC_ID, doc=_SAMPLE_DOC)
        t = ar.render_gc_doc_detail_text_fallback(
            doc_id=_DOC_ID, doc=_SAMPLE_DOC
        )
        assert isinstance(h, str)
        assert isinstance(t, str)
        assert len(h) > 500
        assert len(t) > 100

    def test_empty_state_roundtrip(self):
        h = ar.render_gc_doc_detail_html(doc_id="missing", doc=None)
        t = ar.render_gc_doc_detail_text_fallback(doc_id="missing", doc=None)
        assert isinstance(h, str)
        assert isinstance(t, str)
