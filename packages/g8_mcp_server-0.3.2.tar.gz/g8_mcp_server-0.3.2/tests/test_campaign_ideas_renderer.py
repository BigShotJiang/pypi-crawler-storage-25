"""Tests for the campaign ideas HTML + text renderers (upgrade 4 — #13)."""

from __future__ import annotations

from g8_mcp_server import app_renderer
from g8_mcp_server.app_renderer import (
    _iso_descending_key,
    render_campaign_ideas_dashboard_html,
    render_campaign_ideas_dashboard_text_fallback,
)


def _idea(idx: int = 0, **overrides) -> dict:
    """Default idea dict matching `CampaignIdeaItem`."""
    base = {
        "id": f"idea_{idx}",
        "title": f"Idea {idx}",
        "description": f"Description for idea {idx}",
        "favorited": False,
        "created_at": "2026-04-10T12:00:00Z",
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class TestIsoDescendingKey:
    def test_later_dates_sort_first(self):
        # 2026 > 2025 → descending means 2026's transformed key < 2025's
        newer = _iso_descending_key("2026-04-10T12:00:00Z")
        older = _iso_descending_key("2025-04-10T12:00:00Z")
        assert newer < older

    def test_same_day_later_time_first(self):
        newer = _iso_descending_key("2026-04-10T15:00:00Z")
        older = _iso_descending_key("2026-04-10T10:00:00Z")
        assert newer < older

    def test_digits_only_flipped(self):
        # 0 → 9, 1 → 8, etc. Non-digits (like '-' and 'T') preserved.
        assert _iso_descending_key("0") == "9"
        assert _iso_descending_key("9") == "0"
        assert _iso_descending_key("2026-04-10") == "7973-95-89"

    def test_empty_passthrough(self):
        assert _iso_descending_key("") == ""


# ---------------------------------------------------------------------------
# HTML renderer
# ---------------------------------------------------------------------------


class TestRenderCampaignIdeasHtml:
    def test_empty_state(self):
        html_out = render_campaign_ideas_dashboard_html(ideas=None)
        assert "No campaign ideas yet" in html_out

        html_out2 = render_campaign_ideas_dashboard_html(ideas=[])
        assert "No campaign ideas yet" in html_out2

    def test_non_list_input(self):
        html_out = render_campaign_ideas_dashboard_html(ideas="nope")  # type: ignore[arg-type]
        assert "No campaign ideas yet" in html_out

    def test_only_garbage_items(self):
        html_out = render_campaign_ideas_dashboard_html(ideas=[None, "x", 1])  # type: ignore[list-item]
        assert "No campaign ideas yet" in html_out

    def test_renders_idea(self):
        html_out = render_campaign_ideas_dashboard_html(ideas=[_idea()])
        assert "Idea 0" in html_out
        assert "Description for idea 0" in html_out

    def test_favorited_first(self):
        html_out = render_campaign_ideas_dashboard_html(
            ideas=[
                _idea(idx=1, title="Plain", favorited=False),
                _idea(idx=2, title="Starred", favorited=True),
            ]
        )
        starred_pos = html_out.find("Starred")
        plain_pos = html_out.find("Plain")
        assert starred_pos < plain_pos

    def test_favorited_star_rendered(self):
        html_out = render_campaign_ideas_dashboard_html(
            ideas=[_idea(favorited=True)]
        )
        assert "★" in html_out
        assert "favorited" in html_out

    def test_non_favorited_no_star(self):
        html_out = render_campaign_ideas_dashboard_html(
            ideas=[_idea(favorited=False)]
        )
        # No star character should appear for a non-favorited-only list
        assert "★" not in html_out

    def test_newer_idea_first(self):
        html_out = render_campaign_ideas_dashboard_html(
            ideas=[
                _idea(idx=1, title="Old", created_at="2026-01-01T10:00:00Z"),
                _idea(idx=2, title="Fresh", created_at="2026-05-01T10:00:00Z"),
                _idea(idx=3, title="Middle", created_at="2026-03-01T10:00:00Z"),
            ]
        )
        fresh_pos = html_out.find("Fresh")
        middle_pos = html_out.find("Middle")
        old_pos = html_out.find("Old")
        assert fresh_pos < middle_pos < old_pos

    def test_favorited_beats_newer(self):
        # Old + favorited should beat new + not-favorited
        html_out = render_campaign_ideas_dashboard_html(
            ideas=[
                _idea(idx=1, title="Fresh", created_at="2026-05-01T10:00:00Z"),
                _idea(idx=2, title="OldStarred", created_at="2026-01-01T10:00:00Z", favorited=True),
            ]
        )
        starred_pos = html_out.find("OldStarred")
        fresh_pos = html_out.find("Fresh")
        assert starred_pos < fresh_pos

    def test_missing_title_fallback(self):
        html_out = render_campaign_ideas_dashboard_html(ideas=[_idea(title=None)])
        assert "(untitled)" in html_out

    def test_missing_description_no_empty_block(self):
        # Should not render an empty <p class="idea-desc"></p>
        html_out = render_campaign_ideas_dashboard_html(
            ideas=[_idea(description=None)]
        )
        assert 'class="idea-desc">' not in html_out or "idea-desc\"></p>" not in html_out

    def test_org_label(self):
        html_out = render_campaign_ideas_dashboard_html(
            ideas=[_idea()], org_label="Acme"
        )
        assert "Acme" in html_out

    def test_favorited_count_badge(self):
        html_out = render_campaign_ideas_dashboard_html(
            ideas=[
                _idea(idx=1, favorited=True),
                _idea(idx=2, favorited=True),
                _idea(idx=3, favorited=False),
            ]
        )
        assert "2 favorited" in html_out


class TestEscaping:
    def test_title_escaped(self):
        html_out = render_campaign_ideas_dashboard_html(
            ideas=[_idea(title="<script>evil()</script>")]
        )
        assert "<script>evil" not in html_out
        assert "&lt;script&gt;" in html_out

    def test_description_escaped(self):
        html_out = render_campaign_ideas_dashboard_html(
            ideas=[_idea(description="<xss>")]
        )
        assert "<xss>" not in html_out
        assert "&lt;xss&gt;" in html_out


class TestBounds:
    def test_max_ideas_rendered(self):
        # 100 ideas, cap is 60 — omitted footer must appear.
        ideas = [
            _idea(idx=i, created_at=f"2026-04-{(i % 28) + 1:02d}T10:00:00Z")
            for i in range(100)
        ]
        html_out = render_campaign_ideas_dashboard_html(ideas=ideas)
        assert "omitted" in html_out

    def test_long_title_truncated(self):
        html_out = render_campaign_ideas_dashboard_html(
            ideas=[_idea(title="x" * 5000)]
        )
        assert "…" in html_out


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------


class TestCampaignIdeasTextFallback:
    def test_empty(self):
        out = render_campaign_ideas_dashboard_text_fallback(ideas=None)
        assert "No ideas yet" in out

        out2 = render_campaign_ideas_dashboard_text_fallback(ideas=[])
        assert "No ideas yet" in out2

    def test_non_list(self):
        out = render_campaign_ideas_dashboard_text_fallback(ideas="nope")  # type: ignore[arg-type]
        assert "No ideas yet" in out

    def test_only_garbage_items(self):
        out = render_campaign_ideas_dashboard_text_fallback(ideas=[None, "x", 1])  # type: ignore[list-item]
        assert "No ideas yet" in out

    def test_renders_key_fields(self):
        out = render_campaign_ideas_dashboard_text_fallback(ideas=[_idea()])
        assert "Idea 0" in out
        assert "Description for idea 0" in out

    def test_favorited_marker(self):
        out = render_campaign_ideas_dashboard_text_fallback(
            ideas=[_idea(favorited=True)]
        )
        assert "★" in out

    def test_favorited_count_line(self):
        out = render_campaign_ideas_dashboard_text_fallback(
            ideas=[_idea(idx=1, favorited=True), _idea(idx=2)]
        )
        assert "★ 1 favorited" in out

    def test_created_line(self):
        out = render_campaign_ideas_dashboard_text_fallback(
            ideas=[_idea(created_at="2026-04-10T12:00:00Z")]
        )
        assert "Created:" in out

    def test_org_label(self):
        out = render_campaign_ideas_dashboard_text_fallback(
            ideas=[_idea()], org_label="Acme"
        )
        assert "# Campaign Ideas — Acme" in out

    def test_max_cap_footer(self):
        ideas = [
            _idea(idx=i, created_at=f"2026-04-{(i % 28) + 1:02d}T10:00:00Z")
            for i in range(100)
        ]
        out = render_campaign_ideas_dashboard_text_fallback(ideas=ideas)
        assert "more idea(s)" in out

    def test_no_html_leak(self):
        out = render_campaign_ideas_dashboard_text_fallback(
            ideas=[_idea(title="<tag>")]
        )
        assert "<html>" not in out
        assert "<body>" not in out


# ---------------------------------------------------------------------------
# Caps sanity
# ---------------------------------------------------------------------------


class TestCapsExist:
    def test_constants(self):
        assert app_renderer._MAX_IDEAS_RENDERED >= 10
        assert app_renderer._MAX_IDEA_TITLE_LEN >= 50
        assert app_renderer._MAX_IDEA_DESC_LEN >= 50
