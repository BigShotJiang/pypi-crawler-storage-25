"""Tests for the tasks dashboard HTML + text renderers (upgrade 4 — #12)."""

from __future__ import annotations

from g8_mcp_server import app_renderer
from g8_mcp_server.app_renderer import (
    _group_tasks_by_status,
    _task_is_overdue,
    _task_priority_color,
    _task_priority_label,
    _task_status_color,
    render_tasks_dashboard_html,
    render_tasks_dashboard_text_fallback,
)


def _task(idx: int = 0, **overrides) -> dict:
    """Default task dict matching `TaskItem`."""
    base = {
        "id": f"task_{idx}",
        "title": f"Task {idx}",
        "description": f"Do thing {idx}",
        "status": "open",
        "priority": 3,
        "due_date": "2026-05-01",
        "assignee_id": "user_abc",
        "contact_id": 100 + idx,
        "company_id": None,
        "created_at": "2026-04-10T12:00:00Z",
        "updated_at": "2026-04-15T12:00:00Z",
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class TestTaskStatusColor:
    def test_known(self):
        # Backported to graph8 tokens 2026-04-21
        assert _task_status_color("open") == "#7d2df3"  # _G8_PRIMARY
        assert _task_status_color("in_progress") == "#a0750a"  # _G8_WARNING_FG
        assert _task_status_color("completed") == "#059669"  # _G8_POSITIVE_FG
        assert _task_status_color("cancelled") == "#777777"
        assert _task_status_color("blocked") == "#b91c1c"  # _G8_DESTRUCTIVE_ON_LIGHT_FG

    def test_case_and_whitespace(self):
        assert _task_status_color("OPEN") == "#7d2df3"  # _G8_PRIMARY
        assert _task_status_color(" Completed ") == "#059669"  # _G8_POSITIVE_FG

    def test_unknown(self):
        assert _task_status_color("weird") == "#777777"
        assert _task_status_color(None) == "#777777"
        assert _task_status_color("") == "#777777"

    def test_no_banned_hexes_in_status_palette(self):
        # Lock: no banned Studio hex in any status entry
        banned = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}
        from mcp_server.g8_mcp_server.app_renderer import _TASK_STATUS_COLORS
        for status, value in _TASK_STATUS_COLORS.items():
            assert value.lower() not in banned, (
                f"status={status!r} hex={value!r} is banned"
            )


class TestTaskPriorityLabel:
    def test_known(self):
        assert _task_priority_label(1) == "P1"
        assert _task_priority_label(2) == "P2"
        assert _task_priority_label(3) == "P3"
        assert _task_priority_label(4) == "P4"

    def test_out_of_range(self):
        assert _task_priority_label(0) == ""
        assert _task_priority_label(-1) == ""
        assert _task_priority_label(10) == ""

    def test_none_and_types(self):
        assert _task_priority_label(None) == ""
        assert _task_priority_label("3") == ""  # type: ignore[arg-type]
        assert _task_priority_label(3.0) == ""  # type: ignore[arg-type]


class TestTaskPriorityColor:
    def test_p1_dark_red(self):
        # Backported to graph8 token 2026-04-21
        assert _task_priority_color(1) == "#b91c1c"  # _G8_DESTRUCTIVE_ON_LIGHT_FG

    def test_p2_orange_red(self):
        assert _task_priority_color(2) == "#c2410c"

    def test_p3_amber(self):
        assert _task_priority_color(3) == "#b45309"

    def test_p4_and_lower_gray(self):
        assert _task_priority_color(4) == "#777777"
        assert _task_priority_color(5) == "#777777"

    def test_none(self):
        assert _task_priority_color(None) == "#777777"


class TestTaskIsOverdue:
    def test_past_date(self):
        # 2026-04-15 < 2026-05-01 → overdue when "now" is 2026-05-01
        assert _task_is_overdue("2026-04-15", now_iso="2026-05-01")

    def test_future_date(self):
        assert not _task_is_overdue("2026-05-15", now_iso="2026-05-01")

    def test_same_date_not_overdue(self):
        # Same day = not overdue (strictly before)
        assert not _task_is_overdue("2026-05-01", now_iso="2026-05-01")

    def test_iso_timestamp_input(self):
        # Full ISO should still work via prefix match
        assert _task_is_overdue("2026-04-15T10:00:00Z", now_iso="2026-05-01")
        assert not _task_is_overdue(
            "2026-05-15T10:00:00Z", now_iso="2026-05-01T10:00:00Z"
        )

    def test_missing_returns_false(self):
        assert not _task_is_overdue(None, now_iso="2026-05-01")
        assert not _task_is_overdue("", now_iso="2026-05-01")

    def test_malformed_returns_false(self):
        assert not _task_is_overdue("not-a-date", now_iso="2026-05-01")
        assert not _task_is_overdue("2026/05/01", now_iso="2026-05-01")


class TestGroupTasksByStatus:
    def test_empty(self):
        assert _group_tasks_by_status([]) == []

    def test_preferred_order(self):
        tasks = [
            _task(idx=1, status="completed"),
            _task(idx=2, status="open"),
            _task(idx=3, status="in_progress"),
            _task(idx=4, status="blocked"),
        ]
        result = _group_tasks_by_status(tasks)
        keys = [k for k, _ in result]
        # open → in_progress → blocked → completed
        assert keys == ["open", "in_progress", "blocked", "completed"]

    def test_unknown_status_after_preferred(self):
        tasks = [
            _task(idx=1, status="weird_status"),
            _task(idx=2, status="open"),
        ]
        result = _group_tasks_by_status(tasks)
        keys = [k for k, _ in result]
        # preferred come first
        assert keys[0] == "open"
        assert "weird_status" in keys
        assert keys.index("open") < keys.index("weird_status")

    def test_missing_status_defaults_to_open(self):
        tasks = [_task(idx=1, status=None), _task(idx=2, status="")]
        result = _group_tasks_by_status(tasks)
        assert result == [("open", tasks)]

    def test_case_normalization(self):
        tasks = [_task(idx=1, status="OPEN"), _task(idx=2, status="Open")]
        result = _group_tasks_by_status(tasks)
        assert len(result) == 1
        assert result[0][0] == "open"
        assert len(result[0][1]) == 2


# ---------------------------------------------------------------------------
# HTML renderer
# ---------------------------------------------------------------------------


class TestRenderTasksDashboardHtml:
    def test_empty_state(self):
        html_out = render_tasks_dashboard_html(tasks=None)
        assert "No tasks yet" in html_out

        html_out2 = render_tasks_dashboard_html(tasks=[])
        assert "No tasks yet" in html_out2

    def test_non_list_input(self):
        html_out = render_tasks_dashboard_html(tasks="nope")  # type: ignore[arg-type]
        assert "No tasks yet" in html_out

    def test_only_garbage_items(self):
        html_out = render_tasks_dashboard_html(tasks=[None, "x", 1])  # type: ignore[list-item]
        assert "No tasks yet" in html_out

    def test_renders_task(self):
        html_out = render_tasks_dashboard_html(tasks=[_task()])
        assert "Task 0" in html_out
        assert "Do thing 0" in html_out
        assert "open" in html_out
        assert "P3" in html_out

    def test_status_grouping(self):
        html_out = render_tasks_dashboard_html(
            tasks=[
                _task(idx=1, status="open"),
                _task(idx=2, status="completed"),
            ]
        )
        assert "open" in html_out
        assert "completed" in html_out

    def test_overdue_badge(self):
        # due 2026-01-01 which is strictly before 2026-05-01 "now"
        html_out = render_tasks_dashboard_html(
            tasks=[_task(due_date="2026-01-01", status="open")],
            now_iso="2026-05-01",
        )
        assert "overdue" in html_out.lower()

    def test_completed_not_flagged_overdue(self):
        # Completed tasks with past due_date should NOT count as overdue
        html_out = render_tasks_dashboard_html(
            tasks=[_task(due_date="2026-01-01", status="completed")],
            now_iso="2026-05-01",
        )
        # Banner is "N overdue" — should be absent when count is 0
        assert "1 overdue" not in html_out

    def test_priority_sort(self):
        html_out = render_tasks_dashboard_html(
            tasks=[
                _task(idx=1, title="Low", priority=4, status="open"),
                _task(idx=2, title="Critical", priority=1, status="open"),
                _task(idx=3, title="Medium", priority=3, status="open"),
            ]
        )
        crit_pos = html_out.find("Critical")
        med_pos = html_out.find("Medium")
        low_pos = html_out.find("Low")
        assert crit_pos < med_pos < low_pos

    def test_missing_title_fallback(self):
        html_out = render_tasks_dashboard_html(tasks=[_task(title=None)])
        assert "(untitled)" in html_out

    def test_org_label(self):
        html_out = render_tasks_dashboard_html(
            tasks=[_task()], org_label="Acme"
        )
        assert "Acme" in html_out

    def test_overdue_banner_count(self):
        # 2 overdue tasks
        html_out = render_tasks_dashboard_html(
            tasks=[
                _task(idx=1, due_date="2026-01-01", status="open"),
                _task(idx=2, due_date="2026-02-01", status="open"),
                _task(idx=3, due_date="2027-01-01", status="open"),
            ],
            now_iso="2026-05-01",
        )
        assert "2 overdue" in html_out


class TestEscaping:
    def test_title_escaped(self):
        html_out = render_tasks_dashboard_html(
            tasks=[_task(title="<script>evil()</script>")]
        )
        assert "<script>evil" not in html_out
        assert "&lt;script&gt;" in html_out

    def test_description_escaped(self):
        html_out = render_tasks_dashboard_html(
            tasks=[_task(description="<xss>")]
        )
        assert "<xss>" not in html_out
        assert "&lt;xss&gt;" in html_out

    def test_status_escaped(self):
        # Status → _clip → html.escape
        html_out = render_tasks_dashboard_html(
            tasks=[_task(status="<img>")]
        )
        assert "<img>" not in html_out


class TestBounds:
    def test_max_tasks_rendered(self):
        # 150 tasks, cap is 100 — omitted footer must appear.
        tasks = [
            _task(idx=i, priority=(i % 4) + 1, due_date=f"2026-05-{(i % 28) + 1:02d}")
            for i in range(150)
        ]
        html_out = render_tasks_dashboard_html(tasks=tasks)
        assert "omitted" in html_out

    def test_long_title_truncated(self):
        html_out = render_tasks_dashboard_html(
            tasks=[_task(title="x" * 5000)]
        )
        assert "…" in html_out


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------


class TestTasksDashboardTextFallback:
    def test_empty(self):
        out = render_tasks_dashboard_text_fallback(tasks=None)
        assert "No tasks yet" in out

        out2 = render_tasks_dashboard_text_fallback(tasks=[])
        assert "No tasks yet" in out2

    def test_non_list(self):
        out = render_tasks_dashboard_text_fallback(tasks="nope")  # type: ignore[arg-type]
        assert "No tasks yet" in out

    def test_only_garbage_items(self):
        out = render_tasks_dashboard_text_fallback(tasks=[None, "x", 1])  # type: ignore[list-item]
        assert "No tasks yet" in out

    def test_renders_key_fields(self):
        out = render_tasks_dashboard_text_fallback(tasks=[_task()])
        assert "Task 0" in out
        assert "[P3]" in out
        assert "## open" in out

    def test_overdue_marker(self):
        out = render_tasks_dashboard_text_fallback(
            tasks=[_task(due_date="2026-01-01", status="open")],
            now_iso="2026-05-01",
        )
        assert "!OVERDUE" in out

    def test_overdue_banner(self):
        out = render_tasks_dashboard_text_fallback(
            tasks=[
                _task(idx=1, due_date="2026-01-01", status="open"),
                _task(idx=2, due_date="2026-02-01", status="open"),
            ],
            now_iso="2026-05-01",
        )
        assert "!! 2 overdue" in out

    def test_org_label(self):
        out = render_tasks_dashboard_text_fallback(
            tasks=[_task()], org_label="Acme"
        )
        assert "# Tasks — Acme" in out

    def test_max_cap_footer(self):
        tasks = [
            _task(idx=i, priority=(i % 4) + 1, due_date=f"2026-05-{(i % 28) + 1:02d}")
            for i in range(150)
        ]
        out = render_tasks_dashboard_text_fallback(tasks=tasks)
        assert "more task(s)" in out

    def test_no_html_leak(self):
        out = render_tasks_dashboard_text_fallback(
            tasks=[_task(title="<tag>")]
        )
        assert "<html>" not in out
        assert "<body>" not in out


# ---------------------------------------------------------------------------
# Caps sanity
# ---------------------------------------------------------------------------


class TestCapsExist:
    def test_constants(self):
        assert app_renderer._MAX_TASKS_RENDERED >= 10
        assert app_renderer._MAX_TASK_TITLE_LEN >= 50
        assert app_renderer._MAX_TASK_DESC_LEN >= 50
