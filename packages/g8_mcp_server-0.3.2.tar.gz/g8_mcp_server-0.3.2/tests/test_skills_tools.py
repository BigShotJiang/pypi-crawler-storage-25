"""Tests for structured-output refactor of skills tools (Upgrade 2 coda).

Prior state: `g8_list_skills` / `g8_load_skill` returned plain `str` (JSON
blob + markdown). After the refactor they return Pydantic `Model | str`
unions so the agent sees typed fields without re-parsing, matching the
rest of the MCP surface.

These tests lock:
- The tool signatures resolve to the expected Pydantic models.
- Happy-path returns are valid model instances (not strings).
- Error-path returns are plain strings (the `str` branch of the union).
- Model field shapes match `SKILLS_CATALOG` and `get_skill_content`.
"""

from __future__ import annotations

import pytest

from g8_mcp_server.models import (
    SkillContentResult,
    SkillMetadata,
    SkillsCatalogResult,
)
from g8_mcp_server.skills import SKILLS_CATALOG


class TestSkillsCatalogResultModel:
    def test_from_entries_builds_typed_catalog(self):
        result = SkillsCatalogResult.from_entries(list(SKILLS_CATALOG))
        assert isinstance(result, SkillsCatalogResult)
        assert result.total == len(SKILLS_CATALOG)
        assert len(result.skills) == len(SKILLS_CATALOG)
        for skill in result.skills:
            assert isinstance(skill, SkillMetadata)
            assert skill.slug
            assert skill.title
            assert skill.summary
            assert skill.when_to_use

    def test_from_entries_ignores_path_field(self):
        """`path` is an internal field on SKILLS_CATALOG entries — should be
        stripped by `_StrictIgnore` so it never leaks to the agent."""
        result = SkillsCatalogResult.from_entries(list(SKILLS_CATALOG))
        dump = result.model_dump()
        for entry in dump["skills"]:
            assert "path" not in entry
            assert set(entry.keys()) == {"slug", "title", "summary", "when_to_use"}

    def test_from_entries_skips_non_dict_entries(self):
        """Defensive: a corrupted catalog entry (None, list, etc.) must not blow up."""
        result = SkillsCatalogResult.from_entries([
            {"slug": "ok", "title": "OK", "summary": "s", "when_to_use": "w"},
            None,  # type: ignore[list-item]
            "string-not-dict",  # type: ignore[list-item]
            ["not", "a", "dict"],  # type: ignore[list-item]
        ])
        assert result.total == 1
        assert result.skills[0].slug == "ok"

    def test_empty_catalog_yields_zero_total(self):
        result = SkillsCatalogResult.from_entries([])
        assert result.total == 0
        assert result.skills == []

    def test_model_emits_output_schema(self):
        """FastMCP auto-generates an outputSchema from the model — spot-check
        that the model is JSON-schema-able (no forward refs, weird types)."""
        schema = SkillsCatalogResult.model_json_schema()
        assert schema["type"] == "object"
        assert "skills" in schema["properties"]
        assert "total" in schema["properties"]


class TestSkillContentResultModel:
    def test_from_entry_with_full_content(self):
        entry = {"slug": "prospecting-and-lists", "title": "Prospecting", "path": "x.md"}
        result = SkillContentResult.from_entry(entry, "# Heading\n\nBody text.")
        assert isinstance(result, SkillContentResult)
        assert result.slug == "prospecting-and-lists"
        assert result.title == "Prospecting"
        assert result.content == "# Heading\n\nBody text."

    def test_from_entry_missing_title_falls_back_to_slug(self):
        entry = {"slug": "ai-inbox-replies"}
        result = SkillContentResult.from_entry(entry, "content")
        assert result.slug == "ai-inbox-replies"
        assert result.title == "ai-inbox-replies"  # fallback

    def test_from_entry_missing_slug_renders_empty_strings(self):
        """Defensive: if caller passes a totally empty dict we don't crash —
        we surface empty fields so the union falls back sensibly."""
        result = SkillContentResult.from_entry({}, "content")
        assert result.slug == ""
        assert result.title == ""
        assert result.content == "content"

    def test_from_entry_with_non_dict_entry(self):
        """If `entry` is not a dict, fall back to empty metadata."""
        result = SkillContentResult.from_entry("not-a-dict", "content")  # type: ignore[arg-type]
        assert result.slug == ""
        assert result.title == ""
        assert result.content == "content"

    def test_none_content_becomes_empty_string(self):
        """Consistency: content field is always a str, never None."""
        entry = {"slug": "s", "title": "T"}
        result = SkillContentResult.from_entry(entry, None)  # type: ignore[arg-type]
        assert result.content == ""

    def test_model_emits_output_schema(self):
        schema = SkillContentResult.model_json_schema()
        assert schema["type"] == "object"
        assert set(schema["properties"].keys()) >= {"slug", "title", "content"}


class TestSkillsToolsRegistration:
    """Integration-style: register skills tools on a fresh FastMCP server and
    verify the signatures + outputSchema presence."""

    def _fresh_server(self):
        from mcp.server import FastMCP
        from g8_mcp_server.tools import skills as skills_tools

        server = FastMCP("test-skills")
        skills_tools.register(server)
        return server

    def test_both_tools_registered(self):
        server = self._fresh_server()
        names = list(server._tool_manager._tools.keys())
        assert "g8_list_skills" in names
        assert "g8_load_skill" in names

    def test_both_tools_have_output_schema(self):
        """Structured output contract: every tool emits an `outputSchema`."""
        server = self._fresh_server()
        for tool_name in ("g8_list_skills", "g8_load_skill"):
            tool = server._tool_manager._tools[tool_name]
            # FastMCP stores the schema on the `Tool` object — it's derived
            # from the return annotation, which is `Model | str` for both.
            fn_metadata = getattr(tool, "fn_metadata", None) or getattr(tool, "_metadata", None)
            assert fn_metadata is not None, f"{tool_name} lost its fn_metadata"

    @pytest.mark.asyncio
    async def test_list_skills_returns_model_instance(self):
        server = self._fresh_server()
        tool = server._tool_manager._tools["g8_list_skills"]
        result = await tool.fn()
        assert isinstance(result, SkillsCatalogResult)
        assert result.total == len(SKILLS_CATALOG)

    @pytest.mark.asyncio
    async def test_load_skill_happy_path_returns_model(self):
        server = self._fresh_server()
        tool = server._tool_manager._tools["g8_load_skill"]
        # Pick the first catalog entry — guaranteed to exist because the test
        # runs inside the repo where the markdown files ship.
        first_slug = SKILLS_CATALOG[0]["slug"]
        result = await tool.fn(slug=first_slug)
        assert isinstance(result, SkillContentResult)
        assert result.slug == first_slug
        assert result.content  # markdown body should be non-empty

    @pytest.mark.asyncio
    async def test_load_skill_unknown_slug_returns_str(self):
        """Error branch of the `Model | str` union: unknown slug → plain string.
        Must NOT be JSON — that was the old bug."""
        server = self._fresh_server()
        tool = server._tool_manager._tools["g8_load_skill"]
        result = await tool.fn(slug="definitely-not-a-real-skill-xyz")
        assert isinstance(result, str)
        # Should not be JSON-ish (no leading `{`)
        assert not result.lstrip().startswith("{")
        # Should guide the agent to recover
        assert "g8_list_skills" in result
        assert "Available slugs" in result
