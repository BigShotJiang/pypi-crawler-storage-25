"""Unit tests for Surface #80 — g8://companies/size/{tier}.

Locks the size-tier axis-filter renderer: normalization + backend range
mapping + 4-card stats row (Total / With domain / Unique industries /
Unique countries) + sort invariant (country ASC, industry ASC,
-employee_count, name ASC) + 3-way drill-up (dashboard + siblings +
cross-axis industry + cross-axis country + cross-entity contacts).

Divergences from #79 locked by named tests:
- `TestStatsRow::test_has_unique_industries_and_countries`
- `TestRenderHtml::test_sort_by_country_then_industry_then_employee_count`
- `TestDrillUp::test_cross_axis_link_to_industry`
- `TestDrillUp::test_cross_axis_link_to_country`
- `TestRange::test_enterprise_has_no_max` (range-filter pattern)
- `TestRange::test_micro_bounded_range`
"""

import pytest

from mcp_server.g8_mcp_server.app_renderer import (
    _COMPANIES_SIZE_ALIASES,
    _COMPANIES_SIZE_LABELS,
    _COMPANIES_SIZE_RANGE,
    _COMPANIES_SIZE_SHORT_LABELS,
    _COMPANIES_SIZE_VALID,
    _companies_size_clip,
    _companies_size_country_str,
    _companies_size_display_name,
    _companies_size_drill_up_html,
    _companies_size_empty_state_html,
    _companies_size_employee_count,
    _companies_size_header_html,
    _companies_size_industry_str,
    _companies_size_kpi_card_html,
    _companies_size_label,
    _companies_size_list_html,
    _companies_size_location,
    _companies_size_normalize,
    _companies_size_overflow_banner_html,
    _companies_size_palette,
    _companies_size_range,
    _companies_size_row_html,
    _companies_size_short_label,
    _companies_size_stats_row_html,
    render_companies_size_html,
    render_companies_size_text_fallback,
)


# ---------------------------------------------------------------------------
# Normalization
# ---------------------------------------------------------------------------


class TestNormalizeCanonical:
    @pytest.mark.parametrize("key", list(_COMPANIES_SIZE_VALID))
    def test_canonical_self_map(self, key):
        assert _companies_size_normalize(key) == key

    @pytest.mark.parametrize("key", list(_COMPANIES_SIZE_VALID))
    def test_uppercase(self, key):
        assert _companies_size_normalize(key.upper()) == key

    @pytest.mark.parametrize("key", list(_COMPANIES_SIZE_VALID))
    def test_with_whitespace(self, key):
        assert _companies_size_normalize(f"  {key}  ") == key


class TestNormalizeAliases:
    @pytest.mark.parametrize("alias,canonical", list(_COMPANIES_SIZE_ALIASES.items()))
    def test_alias_resolves(self, alias, canonical):
        assert _companies_size_normalize(alias) == canonical

    def test_uppercase_alias(self):
        assert _companies_size_normalize("SMALL") == "smb"

    def test_mixed_case_alias(self):
        assert _companies_size_normalize("Mid-Market") == "mid"

    def test_hyphen_to_underscore(self):
        assert _companies_size_normalize("mid-market") == "mid"
        assert _companies_size_normalize("mid_market") == "mid"


class TestNormalizeInvalid:
    @pytest.mark.parametrize("bad", [
        "xxx", "unknown", "bogus", "", "  ",
    ])
    def test_invalid_returns_none(self, bad):
        assert _companies_size_normalize(bad) is None

    @pytest.mark.parametrize("bad", [
        None, 42, 3.14, True, [], {},
    ])
    def test_non_string_returns_none(self, bad):
        assert _companies_size_normalize(bad) is None

    @pytest.mark.parametrize("literal", [
        "notes", "deals", "contacts", "activities",
        "dashboard", "industry", "country",
    ])
    def test_no_collision_with_nested_literals(self, literal):
        """All 7 forbidden literals must be rejected."""
        assert _companies_size_normalize(literal) is None

    @pytest.mark.parametrize("literal", [
        "NOTES", "Deals", "CoNtAcTs", "ACTIVITIES",
        "DASHBOARD", "Industry", "COUNTRY",
    ])
    def test_forbidden_literals_case_insensitive(self, literal):
        assert _companies_size_normalize(literal) is None


# ---------------------------------------------------------------------------
# Labels
# ---------------------------------------------------------------------------


class TestLabel:
    @pytest.mark.parametrize("key,expected", list(_COMPANIES_SIZE_LABELS.items()))
    def test_canonical_label(self, key, expected):
        assert _companies_size_label(key) == expected

    def test_alias_resolves_to_canonical_label(self):
        assert _companies_size_label("startup") == _COMPANIES_SIZE_LABELS["micro"]

    def test_invalid_fallback(self):
        assert _companies_size_label("xxx") == "Companies"

    def test_none_fallback(self):
        assert _companies_size_label(None) == "Companies"


class TestShortLabel:
    @pytest.mark.parametrize("key,expected", list(_COMPANIES_SIZE_SHORT_LABELS.items()))
    def test_canonical_short_label(self, key, expected):
        assert _companies_size_short_label(key) == expected

    def test_invalid_fallback(self):
        assert _companies_size_short_label("xxx") == "—"


# ---------------------------------------------------------------------------
# Range (NEW to #80 — range filter pattern)
# ---------------------------------------------------------------------------


class TestRange:
    @pytest.mark.parametrize("key,expected_min,expected_max", [
        ("micro",      1,    10),
        ("smb",        11,   50),
        ("mid",        51,   250),
        ("large",      251,  1000),
        ("enterprise", 1001, None),
    ])
    def test_canonical_range(self, key, expected_min, expected_max):
        assert _companies_size_range(key) == (expected_min, expected_max)

    def test_enterprise_has_no_max(self):
        """Enterprise tier is open-ended — max must be None."""
        _, emax = _companies_size_range("enterprise")
        assert emax is None

    def test_micro_bounded_range(self):
        """Micro is bounded — max must be 10 (not None)."""
        emin, emax = _companies_size_range("micro")
        assert emin == 1
        assert emax == 10

    def test_alias_resolves_to_range(self):
        assert _companies_size_range("startup") == (1, 10)
        assert _companies_size_range("fortune-500") == (1001, None)

    def test_invalid_returns_none_tuple(self):
        assert _companies_size_range("xxx") == (None, None)

    def test_none_returns_none_tuple(self):
        assert _companies_size_range(None) == (None, None)


# ---------------------------------------------------------------------------
# Palette
# ---------------------------------------------------------------------------


class TestPalette:
    @pytest.mark.parametrize("key", list(_COMPANIES_SIZE_VALID))
    def test_returns_tuple(self, key):
        result = _companies_size_palette(key)
        assert isinstance(result, tuple)
        assert len(result) == 2

    @pytest.mark.parametrize("key", list(_COMPANIES_SIZE_VALID))
    def test_no_banned_hexes(self, key):
        bg, fg = _companies_size_palette(key)
        for hex_val in ("#1d4ed8", "#166534", "#991b1b", "#0891b2"):
            assert hex_val.lower() not in bg.lower()
            assert hex_val.lower() not in fg.lower()

    def test_mid_is_accent(self):
        bg, fg = _companies_size_palette("mid")
        assert bg == "#f2eafe"
        assert fg == "#7d2df3"

    def test_large_is_accent(self):
        bg, fg = _companies_size_palette("large")
        assert bg == "#f2eafe"
        assert fg == "#7d2df3"

    def test_enterprise_is_warning(self):
        bg, fg = _companies_size_palette("enterprise")
        assert bg == "#fff3c4"
        assert fg == "#a0750a"

    def test_micro_is_muted(self):
        bg, fg = _companies_size_palette("micro")
        assert bg == "#f9f9f9"
        assert fg == "#777777"

    def test_smb_is_muted(self):
        bg, fg = _companies_size_palette("smb")
        assert bg == "#f9f9f9"
        assert fg == "#777777"

    def test_invalid_is_muted(self):
        bg, fg = _companies_size_palette("xxx")
        assert bg == "#f9f9f9"
        assert fg == "#777777"


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------


class TestClip:
    def test_short(self):
        assert _companies_size_clip("hi") == "hi"

    def test_long_clipped(self):
        result = _companies_size_clip("x" * 200, cap=100)
        assert result.endswith("…")
        assert len(result) <= 101

    def test_none(self):
        assert _companies_size_clip(None) == ""

    def test_whitespace_only(self):
        assert _companies_size_clip("   ") == ""

    def test_escaped(self):
        assert _companies_size_clip("<b>") == "&lt;b&gt;"

    def test_strips(self):
        assert _companies_size_clip("  hi  ") == "hi"

    def test_coerces_int(self):
        assert _companies_size_clip(42) == "42"

    def test_non_string_unstringable(self):
        class Bad:
            def __str__(self):
                raise RuntimeError()

        assert _companies_size_clip(Bad()) == ""


class TestEmployeeCount:
    def test_int(self):
        assert _companies_size_employee_count({"employee_count": 100}) == 100

    def test_string(self):
        assert _companies_size_employee_count({"employee_count": "500"}) == 500

    def test_string_with_comma(self):
        assert _companies_size_employee_count({"employee_count": "1,000"}) == 1000

    def test_string_with_plus(self):
        assert _companies_size_employee_count({"employee_count": "1000+"}) == 1000

    def test_float_integer(self):
        assert _companies_size_employee_count({"employee_count": 100.0}) == 100

    def test_bool_rejected(self):
        assert _companies_size_employee_count({"employee_count": True}) is None

    def test_negative_rejected(self):
        assert _companies_size_employee_count({"employee_count": -5}) is None

    def test_none(self):
        assert _companies_size_employee_count({"employee_count": None}) is None

    def test_missing(self):
        assert _companies_size_employee_count({}) is None

    def test_non_dict(self):
        assert _companies_size_employee_count("not a dict") is None

    def test_num_employees_fallback(self):
        assert _companies_size_employee_count({"num_employees": 42}) == 42


class TestIndustryStr:
    def test_present(self):
        assert _companies_size_industry_str({"industry": "saas"}) == "saas"

    def test_missing(self):
        assert _companies_size_industry_str({}) == ""

    def test_non_string(self):
        assert _companies_size_industry_str({"industry": 42}) == ""

    def test_whitespace_stripped(self):
        assert _companies_size_industry_str({"industry": "  saas  "}) == "saas"

    def test_non_dict(self):
        assert _companies_size_industry_str("not a dict") == ""


class TestCountryStr:
    def test_present(self):
        assert _companies_size_country_str({"country": "US"}) == "US"

    def test_missing(self):
        assert _companies_size_country_str({}) == ""

    def test_non_string(self):
        assert _companies_size_country_str({"country": 42}) == ""

    def test_non_dict(self):
        assert _companies_size_country_str("not a dict") == ""


class TestDisplayName:
    def test_name_wins(self):
        assert _companies_size_display_name(
            {"name": "AcmeCo", "domain": "acme.com"}
        ) == "AcmeCo"

    def test_domain_fallback(self):
        assert _companies_size_display_name({"domain": "acme.com"}) == "acme.com"

    def test_unnamed(self):
        assert _companies_size_display_name({}) == "(unnamed)"

    def test_non_dict(self):
        assert _companies_size_display_name("not a dict") == "(unnamed)"

    def test_xss_escape(self):
        result = _companies_size_display_name({"name": "<script>"})
        assert "&lt;" in result
        assert "<script>" not in result


class TestLocation:
    def test_city_and_country(self):
        assert _companies_size_location(
            {"city": "NYC", "country": "US"}
        ) == "NYC, US"

    def test_country_only(self):
        assert _companies_size_location({"country": "US"}) == "US"

    def test_city_only(self):
        assert _companies_size_location({"city": "NYC"}) == "NYC"

    def test_empty(self):
        assert _companies_size_location({}) == ""

    def test_non_dict(self):
        assert _companies_size_location("not a dict") == ""


# ---------------------------------------------------------------------------
# HTML building blocks
# ---------------------------------------------------------------------------


class TestHeader:
    def test_contains_label(self):
        html = _companies_size_header_html("mid", 10)
        assert "Mid-Market" in html

    def test_plural(self):
        html = _companies_size_header_html("mid", 10)
        assert "10 companies" in html

    def test_singular(self):
        html = _companies_size_header_html("mid", 1)
        assert "1 company" in html

    def test_zero(self):
        html = _companies_size_header_html("mid", 0)
        assert "0 companies" in html

    def test_uses_graph8_primary(self):
        html = _companies_size_header_html("mid", 1)
        assert "#7d2df3" in html.lower() or "#f2eafe" in html.lower()


class TestKpiCard:
    def test_renders_label_value(self):
        html = _companies_size_kpi_card_html("Total", 42)
        assert "Total" in html
        assert "42" in html

    def test_accent_variant(self):
        html = _companies_size_kpi_card_html("Total", 42, accent=True)
        assert "#f2eafe" in html.lower() or "#7d2df3" in html.lower()


class TestStatsRow:
    def test_four_cards(self):
        html = _companies_size_stats_row_html([{"name": "A"}])
        # Count card divs
        assert html.count('padding:16px') == 4

    def test_has_unique_industries_and_countries(self):
        """DIVERGENCE LOCK: #80 shows both diversity KPIs (not LinkedIn)."""
        html = _companies_size_stats_row_html([{"name": "A"}])
        assert "Unique industries" in html
        assert "Unique countries" in html
        # Must NOT show #79's LinkedIn card
        assert "LinkedIn" not in html
        # Must NOT show #78's employee tier cards
        assert "Enterprise" not in html
        assert "SMB" not in html

    def test_counts_correctly(self):
        companies = [
            {"name": "A", "industry": "saas", "country": "US", "domain": "a.com"},
            {"name": "B", "industry": "saas", "country": "UK", "domain": "b.com"},
            {"name": "C", "industry": "fintech", "country": "US"},
        ]
        html = _companies_size_stats_row_html(companies)
        # Total = 3
        assert ">3<" in html
        # With domain = 2
        assert ">2<" in html
        # Unique industries = 2 (saas, fintech)
        # Unique countries = 2 (US, UK)

    def test_empty_list(self):
        html = _companies_size_stats_row_html([])
        assert ">0<" in html

    def test_non_list(self):
        html = _companies_size_stats_row_html("not a list")
        assert ">0<" in html


class TestRow:
    def test_renders_name(self):
        html = _companies_size_row_html({"name": "AcmeCo"})
        assert "AcmeCo" in html

    def test_domain_present(self):
        html = _companies_size_row_html(
            {"name": "AcmeCo", "domain": "acme.com"}
        )
        assert "acme.com" in html

    def test_industry_chip(self):
        html = _companies_size_row_html(
            {"name": "A", "industry": "saas"}
        )
        assert "saas" in html

    def test_no_industry_no_chip(self):
        html = _companies_size_row_html({"name": "A"})
        # Should still render name
        assert "A" in html

    def test_employee_chip(self):
        html = _companies_size_row_html(
            {"name": "A", "employee_count": 500}
        )
        assert "500 emp" in html

    def test_no_employee_no_chip(self):
        html = _companies_size_row_html({"name": "A"})
        assert "emp" not in html

    def test_location(self):
        html = _companies_size_row_html(
            {"name": "A", "city": "NYC", "country": "US"}
        )
        assert "NYC" in html
        assert "US" in html

    def test_xss_name(self):
        html = _companies_size_row_html({"name": "<script>alert(1)</script>"})
        assert "<script>alert" not in html
        assert "&lt;script&gt;" in html

    def test_xss_domain(self):
        html = _companies_size_row_html(
            {"name": "A", "domain": "<script>"}
        )
        assert "<script>" not in html

    def test_xss_industry(self):
        html = _companies_size_row_html(
            {"name": "A", "industry": "<img onerror=x>"}
        )
        # Raw < and > must be escaped (no live tag possible).
        # Accept either single-escape (&lt;img) or safe double-escape
        # (&amp;lt;img — happens when chip primitive escapes
        # already-clipped/escaped input). Both are XSS-safe.
        assert "<img" not in html
        assert ("&lt;img" in html) or ("&amp;lt;img" in html)


class TestList:
    def test_renders_all_rows(self):
        companies = [{"name": f"Co{i}"} for i in range(5)]
        html = _companies_size_list_html(companies)
        for i in range(5):
            assert f"Co{i}" in html

    def test_caps_at_100(self):
        companies = [{"name": f"Co{i}"} for i in range(150)]
        html = _companies_size_list_html(companies)
        assert "Co99" in html
        assert "Co100" not in html


class TestOverflowBanner:
    def test_under_cap_empty(self):
        assert _companies_size_overflow_banner_html(50, "mid") == ""

    def test_exactly_cap_empty(self):
        assert _companies_size_overflow_banner_html(100, "mid") == ""

    def test_over_cap_renders(self):
        html = _companies_size_overflow_banner_html(150, "mid")
        assert "50" in html
        assert "more" in html

    def test_uses_range_in_url(self):
        """URL must use employee_count_min + employee_count_max params."""
        html = _companies_size_overflow_banner_html(150, "mid")
        assert "employee_count_min=51" in html
        assert "employee_count_max=250" in html

    def test_enterprise_no_max_in_url(self):
        html = _companies_size_overflow_banner_html(150, "enterprise")
        assert "employee_count_min=1001" in html
        assert "employee_count_max" not in html


class TestDrillUp:
    def test_has_dashboard(self):
        html = _companies_size_drill_up_html("mid")
        assert "g8://companies/dashboard" in html

    def test_has_siblings(self):
        html = _companies_size_drill_up_html("mid")
        # 4 sibling tiers (not self)
        for sibling in _COMPANIES_SIZE_VALID:
            if sibling != "mid":
                assert f"g8://companies/size/{sibling}" in html

    def test_no_self_reference(self):
        html = _companies_size_drill_up_html("mid")
        assert "g8://companies/size/mid" not in html

    def test_cross_axis_link_to_industry(self):
        """DIVERGENCE LOCK: cross-axis drill-up to industry filter."""
        html = _companies_size_drill_up_html("mid")
        assert "g8://companies/industry/saas" in html

    def test_cross_axis_link_to_country(self):
        """DIVERGENCE LOCK: cross-axis drill-up to country filter."""
        html = _companies_size_drill_up_html("mid")
        assert "g8://companies/country/united_states" in html

    def test_cross_entity_link_to_contacts(self):
        html = _companies_size_drill_up_html("mid")
        assert "g8://contacts/dashboard" in html

    def test_related_surfaces_label(self):
        html = _companies_size_drill_up_html("mid")
        assert "Related surfaces" in html


class TestEmptyState:
    def test_unavailable_mode(self):
        html = _companies_size_empty_state_html("xxx", "unavailable")
        assert "not recognized" in html.lower()
        assert "micro" in html
        assert "smb" in html
        assert "mid" in html
        assert "large" in html
        assert "enterprise" in html

    def test_empty_mode(self):
        html = _companies_size_empty_state_html("mid", "empty")
        assert "Mid-Market" in html
        assert "No" in html

    def test_empty_mode_uses_tier_palette(self):
        html = _companies_size_empty_state_html("enterprise", "empty")
        assert "#fff3c4" in html.lower()


# ---------------------------------------------------------------------------
# Main renderer
# ---------------------------------------------------------------------------


class TestRenderHtml:
    def test_invalid_tier_renders_unavailable(self):
        html = render_companies_size_html(companies=[], tier="xxx")
        assert "not recognized" in html.lower()

    def test_forbidden_literal_renders_unavailable(self):
        html = render_companies_size_html(companies=[], tier="industry")
        assert "not recognized" in html.lower()

    def test_none_companies_renders_unavailable_when_tier_invalid(self):
        html = render_companies_size_html(companies=None, tier="xxx")
        assert "not recognized" in html.lower()

    def test_none_companies_with_valid_tier_renders_empty(self):
        html = render_companies_size_html(companies=None, tier="mid")
        assert "No Mid-Market" in html

    def test_empty_list(self):
        html = render_companies_size_html(companies=[], tier="mid")
        assert "No Mid-Market" in html

    def test_happy_path(self):
        companies = [{"name": "AcmeCo", "industry": "saas"}]
        html = render_companies_size_html(companies=companies, tier="mid")
        assert "AcmeCo" in html
        assert "Mid-Market" in html

    def test_sort_by_country_then_industry_then_employee_count(self):
        """DIVERGENCE LOCK: sort (country ASC, industry ASC, -emp, name ASC)."""
        companies = [
            {"name": "BigUsSaaS", "country": "US", "industry": "saas",
             "employee_count": 500},
            {"name": "SmallUsSaaS", "country": "US", "industry": "saas",
             "employee_count": 100},
            {"name": "UkFin", "country": "UK", "industry": "fintech",
             "employee_count": 200},
            {"name": "UsFin", "country": "US", "industry": "fintech",
             "employee_count": 300},
        ]
        html = render_companies_size_html(companies=companies, tier="mid")
        uk = html.find("UkFin")
        us_fin = html.find("UsFin")
        big_us_saas = html.find("BigUsSaaS")
        small_us_saas = html.find("SmallUsSaaS")
        # UK < US (country alpha)
        assert uk < us_fin
        # Within US: fintech < saas (industry alpha)
        assert us_fin < big_us_saas
        # Within US+saas: bigger employee count first
        assert big_us_saas < small_us_saas

    def test_overflow_banner_at_101(self):
        companies = [{"name": f"Co{i}"} for i in range(150)]
        html = render_companies_size_html(companies=companies, tier="mid")
        assert "50" in html and "more" in html

    def test_xss_in_name(self):
        html = render_companies_size_html(
            companies=[{"name": "<script>alert(1)</script>"}],
            tier="mid",
        )
        assert "<script>alert" not in html

    def test_cross_axis_link_in_html(self):
        html = render_companies_size_html(
            companies=[{"name": "A"}], tier="mid"
        )
        assert "g8://companies/industry/saas" in html
        assert "g8://companies/country/united_states" in html

    def test_cross_entity_link_in_html(self):
        html = render_companies_size_html(
            companies=[{"name": "A"}], tier="mid"
        )
        assert "g8://contacts/dashboard" in html

    def test_alias_routed_to_canonical(self):
        html = render_companies_size_html(
            companies=[{"name": "A"}], tier="startup"
        )
        assert "Micro" in html

    def test_doctype(self):
        html = render_companies_size_html(companies=[], tier="mid")
        assert html.startswith("<!DOCTYPE html>")


class TestDesignTokens:
    @pytest.mark.parametrize("banned", [
        "#1d4ed8", "#166534", "#991b1b", "#0891b2",
    ])
    def test_no_banned_hexes(self, banned):
        html = render_companies_size_html(
            companies=[{"name": "A", "industry": "saas", "country": "US",
                        "employee_count": 100}],
            tier="mid",
        )
        assert banned.lower() not in html.lower()

    @pytest.mark.parametrize("expected", [
        "#7d2df3", "#dfdfdf", "#f2eafe", "#fff3c4",
    ])
    def test_uses_graph8_tokens(self, expected):
        html = render_companies_size_html(
            companies=[{"name": "A", "industry": "saas", "country": "US",
                        "employee_count": 100}],
            tier="enterprise",
        )
        assert expected.lower() in html.lower()

    def test_aeonik(self):
        html = render_companies_size_html(
            companies=[{"name": "A"}], tier="mid"
        )
        assert "aeonik" in html.lower()


class TestNoJs:
    def test_no_script_tag(self):
        html = render_companies_size_html(
            companies=[{"name": "A"}], tier="mid"
        )
        assert "<script" not in html.lower()

    def test_no_event_handlers(self):
        html = render_companies_size_html(
            companies=[{"name": "A"}], tier="mid"
        )
        for handler in ("onclick=", "onerror=", "onload=", "onmouseover="):
            assert handler not in html.lower()


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------


class TestTextFallback:
    def test_invalid_tier(self):
        txt = render_companies_size_text_fallback(companies=[], tier="xxx")
        assert "not recognized" in txt.lower()

    def test_none_companies_valid_tier(self):
        txt = render_companies_size_text_fallback(companies=None, tier="mid")
        assert "# Companies" in txt

    def test_empty_list(self):
        txt = render_companies_size_text_fallback(companies=[], tier="mid")
        assert "Total: 0" in txt

    def test_happy_path(self):
        companies = [
            {"name": "AcmeCo", "industry": "saas", "country": "US",
             "employee_count": 100},
        ]
        txt = render_companies_size_text_fallback(
            companies=companies, tier="mid"
        )
        assert "AcmeCo" in txt
        assert "Mid-Market" in txt
        assert "Total: 1" in txt

    def test_stats_in_text(self):
        txt = render_companies_size_text_fallback(companies=[], tier="mid")
        assert "Total:" in txt
        assert "With domain:" in txt
        assert "Unique industries:" in txt
        assert "Unique countries:" in txt

    def test_backend_filter_uses_range_params(self):
        """Backend filter URL uses employee_count_min/max."""
        txt = render_companies_size_text_fallback(companies=[], tier="mid")
        assert "employee_count_min=51" in txt
        assert "employee_count_max=250" in txt

    def test_backend_filter_enterprise_no_max(self):
        txt = render_companies_size_text_fallback(
            companies=[], tier="enterprise"
        )
        assert "employee_count_min=1001" in txt
        assert "employee_count_max" not in txt

    def test_cross_axis_link_to_industry(self):
        txt = render_companies_size_text_fallback(companies=[], tier="mid")
        assert "g8://companies/industry/saas" in txt

    def test_cross_axis_link_to_country(self):
        txt = render_companies_size_text_fallback(companies=[], tier="mid")
        assert "g8://companies/country/united_states" in txt

    def test_cross_entity_link_to_contacts(self):
        txt = render_companies_size_text_fallback(companies=[], tier="mid")
        assert "g8://contacts/dashboard" in txt

    def test_overflow_note(self):
        companies = [{"name": f"Co{i}"} for i in range(150)]
        txt = render_companies_size_text_fallback(
            companies=companies, tier="mid"
        )
        assert "+50 more" in txt

    def test_no_html_leaks(self):
        txt = render_companies_size_text_fallback(
            companies=[{"name": "<b>X</b>"}], tier="mid"
        )
        # Text output doesn't need to escape, but shouldn't have unbalanced HTML
        assert "<!DOCTYPE" not in txt

    def test_trailing_newline(self):
        txt = render_companies_size_text_fallback(companies=[], tier="mid")
        assert txt.endswith("\n")


# ---------------------------------------------------------------------------
# Smoke
# ---------------------------------------------------------------------------


class TestSmoke:
    @pytest.mark.parametrize("key", list(_COMPANIES_SIZE_VALID))
    def test_canonical_html_without_error(self, key):
        html = render_companies_size_html(
            companies=[{"name": "A", "industry": "saas", "country": "US",
                        "employee_count": 100}],
            tier=key,
        )
        assert html.startswith("<!DOCTYPE html>")

    @pytest.mark.parametrize("key", list(_COMPANIES_SIZE_VALID))
    def test_canonical_text_without_error(self, key):
        txt = render_companies_size_text_fallback(
            companies=[{"name": "A"}], tier=key
        )
        assert txt.startswith("# Companies")

    @pytest.mark.parametrize("alias", list(_COMPANIES_SIZE_ALIASES.keys()))
    def test_alias_html_without_error(self, alias):
        html = render_companies_size_html(
            companies=[{"name": "A"}], tier=alias
        )
        assert html.startswith("<!DOCTYPE html>")

    @pytest.mark.parametrize("alias", list(_COMPANIES_SIZE_ALIASES.keys()))
    def test_alias_text_without_error(self, alias):
        txt = render_companies_size_text_fallback(
            companies=[{"name": "A"}], tier=alias
        )
        assert txt.startswith("# Companies")


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------


class TestConstants:
    def test_valid_is_tuple(self):
        assert isinstance(_COMPANIES_SIZE_VALID, tuple)
        assert len(_COMPANIES_SIZE_VALID) == 5

    def test_labels_complete(self):
        for key in _COMPANIES_SIZE_VALID:
            assert key in _COMPANIES_SIZE_LABELS

    def test_short_labels_complete(self):
        for key in _COMPANIES_SIZE_VALID:
            assert key in _COMPANIES_SIZE_SHORT_LABELS

    def test_range_complete(self):
        for key in _COMPANIES_SIZE_VALID:
            assert key in _COMPANIES_SIZE_RANGE

    def test_aliases_target_valid(self):
        for canonical in _COMPANIES_SIZE_ALIASES.values():
            assert canonical in _COMPANIES_SIZE_VALID

    def test_no_alias_equals_canonical(self):
        for alias in _COMPANIES_SIZE_ALIASES:
            assert alias not in _COMPANIES_SIZE_VALID

    def test_aliases_has_50_plus(self):
        assert len(_COMPANIES_SIZE_ALIASES) >= 50

    @pytest.mark.parametrize("literal", [
        "notes", "deals", "contacts", "activities",
        "dashboard", "industry", "country",
    ])
    def test_no_alias_collides_with_nested_literals(self, literal):
        assert literal not in _COMPANIES_SIZE_ALIASES

    @pytest.mark.parametrize("literal", [
        "notes", "deals", "contacts", "activities",
        "dashboard", "industry", "country",
    ])
    def test_no_canonical_collides_with_nested_literals(self, literal):
        assert literal not in _COMPANIES_SIZE_VALID
