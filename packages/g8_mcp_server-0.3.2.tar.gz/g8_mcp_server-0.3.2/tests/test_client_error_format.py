"""Regression tests for the MCP client error formatter.

The original bug: every 5xx response from the backend was masked as
"graph8 is temporarily unavailable", hiding the real cause from LLM clients.
After the fix, 5xx responses with a meaningful detail surface that detail
verbatim. Empty 5xx bodies still fall back to the friendly generic message.
"""

from __future__ import annotations

from g8_mcp_server.client import G8ClientError, _format_error


class TestFormatErrorOnFiveHundred:
    def test_500_with_pydantic_detail_is_surfaced(self):
        """A 500 carrying real validation detail must NOT be masked as generic."""
        err = G8ClientError(
            500,
            "API error (500): 2 validation errors for CreateStepPayload\n"
            "step_type: Input should be 'PHONE', 'EMAIL', ...",
        )
        msg = _format_error(err)
        # The detail must reach the caller, not the generic fallback.
        assert "temporarily unavailable" not in msg
        assert "validation errors" in msg
        assert "step_type" in msg

    def test_502_with_arbitrary_detail_is_surfaced(self):
        err = G8ClientError(502, "API error (502): upstream timeout from sequencer")
        msg = _format_error(err)
        assert "upstream timeout" in msg
        assert "temporarily unavailable" not in msg

    def test_500_with_empty_body_falls_back_to_generic(self):
        """If the response body has no detail, keep the friendly fallback."""
        err = G8ClientError(500, "API error (500): ")
        msg = _format_error(err)
        assert "temporarily unavailable" in msg

    def test_500_unparseable_message_falls_back_gracefully(self):
        """Defensive: a totally unexpected message shape must not crash the formatter."""
        err = G8ClientError(500, "")
        msg = _format_error(err)
        assert "temporarily unavailable" in msg


class TestFormatErrorOnFourHundred:
    """Backwards compatibility: 4xx behavior is unchanged."""

    def test_422_message_unchanged(self):
        err = G8ClientError(422, "API error (422): bad input")
        msg = _format_error(err)
        assert "Invalid request parameters" in msg

    def test_404_message_unchanged(self):
        err = G8ClientError(404, "Resource not found.")
        msg = _format_error(err, context="Sequence")
        assert "Sequence not found" in msg

    def test_429_message_unchanged(self):
        err = G8ClientError(429, "rate limited")
        msg = _format_error(err)
        assert "Rate limit exceeded" in msg
