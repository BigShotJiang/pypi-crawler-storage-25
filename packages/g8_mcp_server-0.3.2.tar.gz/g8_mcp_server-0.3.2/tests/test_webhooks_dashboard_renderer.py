"""Unit tests for surface #43 — org-wide webhooks dashboard.

Covers helpers and both renderers (HTML + text fallback). Design parity:
graph8 tokens, no single-side accent borders, no legacy accent hexes.
"""

from g8_mcp_server.app_renderer import (
    _render_webhooks_dashboard_empty_state_html,
    _webhooks_dashboard_active_count,
    _webhooks_dashboard_clip,
    _webhooks_dashboard_display_name,
    _webhooks_dashboard_event_count,
    _webhooks_dashboard_is_active,
    _webhooks_dashboard_short_url,
    _webhooks_dashboard_stat_card,
    _webhooks_dashboard_status_palette,
    _webhooks_dashboard_unique_events,
    render_webhooks_dashboard_html,
    render_webhooks_dashboard_text_fallback,
)


def _webhook(
    *,
    id: str = "wh_1",
    name: str | None = "Test Webhook",
    url: str = "https://example.com/hook",
    events: list[str] | None = None,
    is_active: bool = True,
    created_at: str | None = "2026-04-01T10:00:00Z",
) -> dict:
    """Build a valid webhook dict for testing."""
    if events is None:
        events = ["contact.created", "contact.updated"]
    return {
        "id": id,
        "name": name,
        "url": url,
        "events": events,
        "is_active": is_active,
        "created_at": created_at,
    }


class TestClip:
    def test_non_string(self):
        assert _webhooks_dashboard_clip(None, 10) == ""
        assert _webhooks_dashboard_clip(42, 10) == ""
        assert _webhooks_dashboard_clip(["a"], 10) == ""

    def test_whitespace(self):
        assert _webhooks_dashboard_clip("   ", 10) == ""

    def test_short_pass_through_escaped(self):
        assert _webhooks_dashboard_clip("hi & bye", 20) == "hi &amp; bye"

    def test_long_clips(self):
        out = _webhooks_dashboard_clip("x" * 100, 10)
        assert out.endswith("…")
        assert len(out) <= 11

    def test_html_escape(self):
        assert _webhooks_dashboard_clip("<script>", 20) == "&lt;script&gt;"


class TestDisplayName:
    def test_name_wins(self):
        w = _webhook(name="Order Hook", url="https://example.com/hook")
        assert _webhooks_dashboard_display_name(w) == "Order Hook"

    def test_url_fallback_when_no_name(self):
        w = _webhook(name=None, url="https://example.com/hook")
        assert "example.com/hook" in _webhooks_dashboard_display_name(w)

    def test_url_fallback_when_blank_name(self):
        w = _webhook(name="   ", url="https://example.com/hook")
        assert "example.com/hook" in _webhooks_dashboard_display_name(w)

    def test_long_url_clipped(self):
        w = _webhook(name=None, url="https://example.com/" + "x" * 500)
        out = _webhooks_dashboard_display_name(w)
        assert out.endswith("…")

    def test_default_when_no_name_no_url(self):
        w = {"id": "wh_1"}
        assert _webhooks_dashboard_display_name(w) == "webhook"

    def test_xss_in_name_escaped(self):
        w = _webhook(name="<script>alert(1)</script>")
        out = _webhooks_dashboard_display_name(w)
        assert "<script>" not in out
        assert "&lt;script&gt;" in out

    def test_xss_in_url_escaped(self):
        w = _webhook(name=None, url="https://a.com/<x>")
        out = _webhooks_dashboard_display_name(w)
        assert "<x>" not in out
        assert "&lt;x&gt;" in out


class TestShortUrl:
    def test_none(self):
        assert _webhooks_dashboard_short_url(None) == ""

    def test_non_string(self):
        assert _webhooks_dashboard_short_url(42) == ""

    def test_blank(self):
        assert _webhooks_dashboard_short_url("   ") == ""

    def test_short(self):
        assert _webhooks_dashboard_short_url("https://a.com/x") == "https://a.com/x"

    def test_long_clipped(self):
        out = _webhooks_dashboard_short_url("https://example.com/" + "x" * 200)
        assert out.endswith("…")

    def test_xss_escaped(self):
        out = _webhooks_dashboard_short_url("https://a.com/<script>")
        assert "<script>" not in out
        assert "&lt;script&gt;" in out


class TestIsActive:
    def test_true_bool(self):
        assert _webhooks_dashboard_is_active({"is_active": True}) is True

    def test_false_bool(self):
        assert _webhooks_dashboard_is_active({"is_active": False}) is False

    def test_missing(self):
        assert _webhooks_dashboard_is_active({}) is False

    def test_none(self):
        assert _webhooks_dashboard_is_active({"is_active": None}) is False

    def test_string_truthy_not_counted(self):
        """Strict bool check: non-bool must not be treated as active."""
        assert _webhooks_dashboard_is_active({"is_active": "true"}) is False

    def test_int_one_not_counted(self):
        """int 1 is not a bool and must not be treated as active."""
        # Note: True is a bool subclass of int, but 1 is not a bool.
        # isinstance(1, bool) is False.
        assert _webhooks_dashboard_is_active({"is_active": 1}) is False


class TestActiveCount:
    def test_all_active(self):
        whs = [_webhook(is_active=True), _webhook(is_active=True)]
        assert _webhooks_dashboard_active_count(whs) == 2

    def test_mixed(self):
        whs = [
            _webhook(is_active=True),
            _webhook(is_active=False),
            _webhook(is_active=True),
        ]
        assert _webhooks_dashboard_active_count(whs) == 2

    def test_non_list(self):
        assert _webhooks_dashboard_active_count(None) == 0
        assert _webhooks_dashboard_active_count("foo") == 0

    def test_non_dict_filtered(self):
        whs = [_webhook(is_active=True), "not a dict", 42]
        assert _webhooks_dashboard_active_count(whs) == 1

    def test_empty(self):
        assert _webhooks_dashboard_active_count([]) == 0


class TestEventCount:
    def test_sums_event_list_lengths(self):
        whs = [
            _webhook(events=["a", "b"]),
            _webhook(events=["c"]),
        ]
        assert _webhooks_dashboard_event_count(whs) == 3

    def test_non_list_events_skipped(self):
        whs = [_webhook(events=["a"]), {"events": "not-a-list"}]
        assert _webhooks_dashboard_event_count(whs) == 1

    def test_non_string_events_skipped(self):
        whs = [{"events": ["a", 42, None, ""]}]
        # only "a" counts
        assert _webhooks_dashboard_event_count(whs) == 1

    def test_blank_events_skipped(self):
        whs = [{"events": ["a", "   ", "b"]}]
        assert _webhooks_dashboard_event_count(whs) == 2

    def test_non_list_input(self):
        assert _webhooks_dashboard_event_count(None) == 0


class TestUniqueEvents:
    def test_groups_and_sorts(self):
        whs = [
            _webhook(events=["a", "b"]),
            _webhook(events=["a", "c"]),
            _webhook(events=["b"]),
        ]
        out = _webhooks_dashboard_unique_events(whs)
        # a=2, b=2, c=1 → sorted by count desc then alpha
        assert out == [("a", 2), ("b", 2), ("c", 1)]

    def test_non_list_input(self):
        assert _webhooks_dashboard_unique_events(None) == []

    def test_non_dict_entries_skipped(self):
        whs = [_webhook(events=["a"]), "not a dict"]
        assert _webhooks_dashboard_unique_events(whs) == [("a", 1)]

    def test_strips_and_counts_normalized(self):
        whs = [{"events": ["a  ", "a", " a"]}]
        assert _webhooks_dashboard_unique_events(whs) == [("a", 3)]

    def test_skips_empty_and_non_strings(self):
        whs = [{"events": ["a", "", 42, None]}]
        assert _webhooks_dashboard_unique_events(whs) == [("a", 1)]


class TestStatusPalette:
    def test_active_is_green(self):
        bg, fg = _webhooks_dashboard_status_palette(True)
        assert bg == "#d1fae5"
        assert fg == "#059669"

    def test_inactive_is_muted(self):
        bg, fg = _webhooks_dashboard_status_palette(False)
        assert "#f9f9f9" in bg or "#f9f9f9" == bg
        # fg is the muted text token
        assert fg == "#777777"


class TestStatCard:
    def test_label_and_value_present(self):
        out = _webhooks_dashboard_stat_card("Total", "12")
        assert "Total" in out
        assert ">12<" in out

    def test_primary_accent(self):
        out = _webhooks_dashboard_stat_card("Total", "5", accent="primary")
        assert "#7d2df3" in out

    def test_positive_accent(self):
        out = _webhooks_dashboard_stat_card("Active", "3", accent="positive")
        assert "#059669" in out

    def test_destructive_accent(self):
        out = _webhooks_dashboard_stat_card("Inactive", "2", accent="destructive")
        assert "#ca3214" in out

    def test_uniform_border_not_single_side(self):
        out = _webhooks_dashboard_stat_card("Total", "5")
        assert "border:1px solid" in out
        # no single-side colored accent borders
        assert "border-left:3px" not in out
        assert "border-top:3px" not in out
        assert "border-right:3px" not in out
        assert "border-bottom:3px" not in out

    def test_label_html_escaped(self):
        out = _webhooks_dashboard_stat_card("<script>", "5")
        assert "<script>" not in out
        assert "&lt;script&gt;" in out


class TestEmptyState:
    def test_empty_mode(self):
        out = _render_webhooks_dashboard_empty_state_html(mode="empty")
        assert "<!DOCTYPE html>" in out
        assert "No webhooks configured yet" in out
        assert "POST /webhooks" in out
        assert "GET /webhooks/events" in out

    def test_unavailable_mode(self):
        out = _render_webhooks_dashboard_empty_state_html(mode="unavailable")
        assert "not available" in out
        assert "GET /webhooks" in out

    def test_graph8_tokens_present(self):
        out = _render_webhooks_dashboard_empty_state_html(mode="empty")
        assert "Aeonik" in out

    def test_no_single_side_accent_borders(self):
        for mode in ("empty", "unavailable"):
            out = _render_webhooks_dashboard_empty_state_html(mode=mode)
            assert "border-left:3px" not in out
            assert "border-top:3px" not in out
            assert "border-right:3px" not in out
            assert "border-bottom:3px" not in out


class TestRenderHtml:
    def test_none_unavailable(self):
        out = render_webhooks_dashboard_html(webhooks=None)
        assert "not available" in out

    def test_empty_list_empty_state(self):
        out = render_webhooks_dashboard_html(webhooks=[])
        assert "No webhooks configured yet" in out

    def test_single_webhook_renders(self):
        whs = [_webhook()]
        out = render_webhooks_dashboard_html(webhooks=whs)
        assert "<!DOCTYPE html>" in out
        assert "Test Webhook" in out
        assert "id=wh_1" in out
        assert "1 TOTAL" in out

    def test_stat_cards_rendered(self):
        whs = [
            _webhook(id="w1", is_active=True),
            _webhook(id="w2", is_active=True),
            _webhook(id="w3", is_active=False),
        ]
        out = render_webhooks_dashboard_html(webhooks=whs)
        assert "Total" in out
        assert "Active" in out
        assert "Inactive" in out
        assert "Unique events" in out

    def test_active_count_in_stat_card(self):
        whs = [_webhook(is_active=True), _webhook(id="w2", is_active=False)]
        out = render_webhooks_dashboard_html(webhooks=whs)
        assert ">2<" in out  # total
        assert ">1<" in out  # active

    def test_event_coverage_section(self):
        whs = [_webhook(events=["contact.created"])]
        out = render_webhooks_dashboard_html(webhooks=whs)
        assert "Event coverage" in out
        assert "contact.created" in out

    def test_event_coverage_not_shown_when_zero_events(self):
        whs = [_webhook(events=[])]
        out = render_webhooks_dashboard_html(webhooks=whs)
        assert "Event coverage" not in out

    def test_active_badge(self):
        whs = [_webhook(is_active=True)]
        out = render_webhooks_dashboard_html(webhooks=whs)
        assert "ACTIVE" in out

    def test_inactive_badge(self):
        whs = [_webhook(is_active=False)]
        out = render_webhooks_dashboard_html(webhooks=whs)
        assert "INACTIVE" in out

    def test_per_row_drill_down_pointers(self):
        whs = [_webhook(id="wh_123")]
        out = render_webhooks_dashboard_html(webhooks=whs)
        assert "g8://webhooks/wh_123/overview" in out
        assert "g8://webhooks/wh_123/deliveries" in out

    def test_drill_up_links(self):
        whs = [_webhook()]
        out = render_webhooks_dashboard_html(webhooks=whs)
        assert "POST /webhooks</code>" in out
        assert "GET /webhooks/events</code>" in out

    def test_overflow_40(self):
        whs = [_webhook(id=f"w{i}") for i in range(45)]
        out = render_webhooks_dashboard_html(webhooks=whs)
        assert "+ 5 more webhooks" in out

    def test_8_event_chip_overflow(self):
        # 12 unique events, cap 10 → "+ 2 more events"
        whs = [_webhook(events=[f"evt.{i}" for i in range(12)])]
        out = render_webhooks_dashboard_html(webhooks=whs)
        assert "+ 2 more events" in out

    def test_xss_in_name_escaped(self):
        whs = [_webhook(name="<script>alert(1)</script>")]
        out = render_webhooks_dashboard_html(webhooks=whs)
        assert "<script>alert" not in out
        assert "&lt;script&gt;" in out

    def test_xss_in_url_escaped(self):
        whs = [_webhook(url="https://a.com/<img>")]
        out = render_webhooks_dashboard_html(webhooks=whs)
        assert "<img>" not in out
        assert "&lt;img&gt;" in out

    def test_xss_in_webhook_id_escaped(self):
        xss = "<script>alert(1)</script>"
        whs = [_webhook(id=xss)]
        out = render_webhooks_dashboard_html(webhooks=whs)
        assert xss not in out
        assert "&lt;script&gt;" in out

    def test_xss_in_event_name_escaped(self):
        whs = [_webhook(events=["<script>evil</script>"])]
        out = render_webhooks_dashboard_html(webhooks=whs)
        assert "<script>evil" not in out
        assert "&lt;script&gt;" in out

    def test_no_single_side_accent_borders(self):
        whs = [_webhook()]
        out = render_webhooks_dashboard_html(webhooks=whs)
        assert "border-left:3px" not in out
        assert "border-top:3px" not in out
        assert "border-right:3px" not in out
        assert "border-bottom:3px" not in out

    def test_no_legacy_accent_hexes(self):
        whs = [_webhook()]
        out = render_webhooks_dashboard_html(webhooks=whs)
        for legacy in ("#6366f1", "#4f46e5", "#10b981", "#ec4899", "#dc2626", "#16a34a"):
            assert legacy not in out, (
                f"surface #43 should not contain legacy hex {legacy}"
            )

    def test_aeonik_font_present(self):
        whs = [_webhook()]
        out = render_webhooks_dashboard_html(webhooks=whs)
        assert "Aeonik" in out

    def test_graph8_primary_present(self):
        whs = [_webhook()]
        out = render_webhooks_dashboard_html(webhooks=whs)
        assert "#7d2df3" in out

    def test_int_is_active_one_not_treated_as_active(self):
        """int value for is_active must not be treated as active."""
        whs = [{"id": "w1", "name": "hook", "url": "https://a.com", "events": [], "is_active": 1}]
        out = render_webhooks_dashboard_html(webhooks=whs)
        # is_active=1 (int) should NOT render ACTIVE badge (strict bool)
        assert "INACTIVE" in out
        # Active count should be 0
        # The ">0<" on the Active stat card will appear since total=1, active=0
        # so inactive=1, active=0.
        assert ">1<" in out  # total
        # 0 active → rendered
        # This is tricky because 0 would show up. We already assert "INACTIVE".

    def test_invalid_entries_filtered(self):
        whs = [_webhook(), "not a dict", 42, None, _webhook(id="w2")]
        out = render_webhooks_dashboard_html(webhooks=whs)
        assert "2 TOTAL" in out

    def test_event_count_display(self):
        whs = [_webhook(events=["a", "b", "c"])]
        out = render_webhooks_dashboard_html(webhooks=whs)
        assert "3 events" in out

    def test_one_event_singular(self):
        whs = [_webhook(events=["a"])]
        out = render_webhooks_dashboard_html(webhooks=whs)
        assert "1 event" in out
        # not "1 events"
        assert "1 events" not in out

    def test_created_at_rendered(self):
        whs = [_webhook(created_at="2026-04-01T10:00:00Z")]
        out = render_webhooks_dashboard_html(webhooks=whs)
        assert "created 2026-04-01T10:00:00Z" in out


class TestTextFallback:
    def test_none_unavailable(self):
        text = render_webhooks_dashboard_text_fallback(webhooks=None)
        assert "not available" in text

    def test_empty(self):
        text = render_webhooks_dashboard_text_fallback(webhooks=[])
        assert "no webhooks configured" in text

    def test_markdown_headers(self):
        whs = [_webhook()]
        text = render_webhooks_dashboard_text_fallback(webhooks=whs)
        assert "# Webhooks" in text
        assert "## Webhooks" in text
        assert "## Manage webhooks" in text

    def test_event_coverage_section(self):
        whs = [_webhook(events=["x.y"])]
        text = render_webhooks_dashboard_text_fallback(webhooks=whs)
        assert "## Event coverage" in text
        assert "- x.y: 1" in text

    def test_stats_rendered(self):
        whs = [_webhook(is_active=True), _webhook(id="w2", is_active=False)]
        text = render_webhooks_dashboard_text_fallback(webhooks=whs)
        assert "- Total: 2" in text
        assert "- Active: 1" in text
        assert "- Inactive: 1" in text

    def test_webhook_row_format(self):
        whs = [_webhook(id="w1", name="My Hook", url="https://a.com/h", events=["x"])]
        text = render_webhooks_dashboard_text_fallback(webhooks=whs)
        assert "[ACTIVE] My Hook (id=w1)" in text
        assert "url=https://a.com/h" in text
        assert "1 event" in text

    def test_inactive_in_text(self):
        whs = [_webhook(is_active=False)]
        text = render_webhooks_dashboard_text_fallback(webhooks=whs)
        assert "[INACTIVE]" in text

    def test_url_fallback_when_no_name(self):
        whs = [_webhook(name=None, url="https://a.com/h")]
        text = render_webhooks_dashboard_text_fallback(webhooks=whs)
        assert "https://a.com/h" in text

    def test_default_webhook_when_no_name_or_url(self):
        whs = [{"id": "wh_1", "events": [], "is_active": True}]
        text = render_webhooks_dashboard_text_fallback(webhooks=whs)
        assert "[ACTIVE] webhook (id=wh_1)" in text

    def test_overflow_40(self):
        whs = [_webhook(id=f"w{i}") for i in range(45)]
        text = render_webhooks_dashboard_text_fallback(webhooks=whs)
        assert "+ 5 more webhooks" in text

    def test_manage_pointers(self):
        whs = [_webhook()]
        text = render_webhooks_dashboard_text_fallback(webhooks=whs)
        assert "POST /webhooks" in text
        assert "GET /webhooks/events" in text
        assert "g8://webhooks/{id}/overview" in text
        assert "g8://webhooks/{id}/deliveries" in text

    def test_strict_bool_is_active(self):
        whs = [{"id": "w1", "name": "h", "url": "https://a.com", "events": [], "is_active": 1}]
        text = render_webhooks_dashboard_text_fallback(webhooks=whs)
        # int 1 not bool → INACTIVE
        assert "[INACTIVE]" in text


class TestSmoke:
    def test_mixed_payload(self):
        whs = [
            _webhook(
                id=f"w{i}",
                name=f"Hook {i}",
                url=f"https://example.com/hook/{i}",
                events=[f"event.{j}" for j in range(i % 4)],
                is_active=i % 3 == 0,
            )
            for i in range(30)
        ]
        html_out = render_webhooks_dashboard_html(webhooks=whs)
        assert "30 TOTAL" in html_out
        text_out = render_webhooks_dashboard_text_fallback(webhooks=whs)
        assert "- Total: 30" in text_out

    def test_unicode_in_name(self):
        whs = [_webhook(name="日本語 Hook ✓")]
        html_out = render_webhooks_dashboard_html(webhooks=whs)
        assert "日本語 Hook ✓" in html_out
        text_out = render_webhooks_dashboard_text_fallback(webhooks=whs)
        assert "日本語 Hook ✓" in text_out
