"""Tests for Surface #76 — g8://contacts/seniority/{seniority}.

Coverage plan:
- normalize: canonical keys (11), URL-friendly aliases (30+), invalid strings,
  non-string inputs, None/empty/whitespace, case variants.
- label/short_label: every canonical + one alias.
- palette: every canonical key (must use graph8 tokens only; never the 4 banned
  Studio hexes).
- clip: empty/None/whitespace/over-cap/under-cap/non-string.
- display_name: first+last, work_email fallback, unnamed fallback,
  non-dict input.
- location: every field present, none present, missing middle, non-string values.
- header/kpi/stats/row: structural HTML presence.
- overflow banner: positive, zero, negative.
- drill_up: siblings include every other tier, never self-ref.
- empty_state: zero_state=True accent, zero_state=False muted.
- render_contacts_seniority_html: happy path, empty list, None payload,
  invalid URI key, non-list payload, XSS escape.
- render_contacts_seniority_text_fallback: same set of branches.
- Design tokens: locks out banned Studio hexes + confirms graph8 tokens present.
- no_js: ensure no <script> or event handlers in any render output.
- Smoke: all aliases route to valid URIs without KeyError.
- Constants: tuple immutability + completeness.
"""

from __future__ import annotations

import pytest

from mcp_server.g8_mcp_server.app_renderer import (
    _CONTACTS_SENIORITY_ALIASES,
    _CONTACTS_SENIORITY_LABELS,
    _CONTACTS_SENIORITY_VALID,
    _contacts_seniority_chip_html,
    _contacts_seniority_clip,
    _contacts_seniority_display_name,
    _contacts_seniority_drill_up_html,
    _contacts_seniority_empty_state_html,
    _contacts_seniority_header_html,
    _contacts_seniority_kpi_card_html,
    _contacts_seniority_label,
    _contacts_seniority_list_html,
    _contacts_seniority_location,
    _contacts_seniority_normalize,
    _contacts_seniority_overflow_banner_html,
    _contacts_seniority_palette,
    _contacts_seniority_row_html,
    _contacts_seniority_short_label,
    _contacts_seniority_stats_row_html,
    render_contacts_seniority_html,
    render_contacts_seniority_text_fallback,
)


# ---------------------------------------------------------------------------
# Normalize — canonical keys
# ---------------------------------------------------------------------------

class TestNormalizeCanonical:
    @pytest.mark.parametrize("key", list(_CONTACTS_SENIORITY_VALID))
    def test_all_canonical_self_map(self, key):
        assert _contacts_seniority_normalize(key) == key

    @pytest.mark.parametrize("key", list(_CONTACTS_SENIORITY_VALID))
    def test_canonical_uppercase(self, key):
        assert _contacts_seniority_normalize(key.upper()) == key

    @pytest.mark.parametrize("key", list(_CONTACTS_SENIORITY_VALID))
    def test_canonical_with_spaces(self, key):
        assert _contacts_seniority_normalize(f"  {key}  ") == key

    def test_c_suite_hyphen_form(self):
        assert _contacts_seniority_normalize("c-suite") == "c_suite"

    def test_c_suite_title_case(self):
        assert _contacts_seniority_normalize("C-Suite") == "c_suite"

    def test_vp_spaces(self):
        assert _contacts_seniority_normalize(" VP ") == "vp"


# ---------------------------------------------------------------------------
# Normalize — aliases
# ---------------------------------------------------------------------------

class TestNormalizeAliases:
    @pytest.mark.parametrize("alias,expected", [
        ("ceo", "c_suite"),
        ("cto", "c_suite"),
        ("cfo", "c_suite"),
        ("coo", "c_suite"),
        ("cpo", "c_suite"),
        ("cmo", "c_suite"),
        ("cro", "c_suite"),
        ("cxo", "c_suite"),
        ("csuite", "c_suite"),
        ("c-level", "c_suite"),
        ("c_level", "c_suite"),
        ("clevel", "c_suite"),
        ("exec", "executive"),
        ("execs", "executive"),
        ("executives", "executive"),
        ("president", "executive"),
        ("owner", "founder"),
        ("co-founder", "founder"),
        ("cofounder", "founder"),
        ("co_founder", "founder"),
        ("svp", "vp"),
        ("evp", "vp"),
        ("avp", "vp"),
        ("vice-president", "vp"),
        ("vice_president", "vp"),
        ("vicepresident", "vp"),
        ("vp-level", "vp"),
        ("directors", "director"),
        ("sr-director", "director"),
        ("sr_director", "director"),
        ("head-of", "head"),
        ("head_of", "head"),
        ("mgr", "manager"),
        ("managers", "manager"),
        ("team-lead", "lead"),
        ("team_lead", "lead"),
        ("teamlead", "lead"),
        ("staff", "senior"),
        ("principal", "senior"),
        ("sr", "senior"),
        ("individual_contributor", "ic"),
        ("individual-contributor", "ic"),
        ("ics", "ic"),
        ("entry-level", "entry"),
        ("entry_level", "entry"),
        ("junior", "entry"),
        ("jr", "entry"),
        ("associate", "entry"),
        ("intern", "entry"),
        ("internship", "entry"),
    ])
    def test_alias_maps_to_canonical(self, alias, expected):
        assert _contacts_seniority_normalize(alias) == expected

    @pytest.mark.parametrize("alias", ["CEO", "Svp", "Jr", "Manager"])
    def test_alias_case_insensitive(self, alias):
        assert _contacts_seniority_normalize(alias) is not None

    def test_sr_with_dot(self):
        assert _contacts_seniority_normalize("sr.") == "senior"

    def test_jr_with_dot(self):
        assert _contacts_seniority_normalize("jr.") == "entry"


# ---------------------------------------------------------------------------
# Normalize — invalid inputs
# ---------------------------------------------------------------------------

class TestNormalizeInvalid:
    @pytest.mark.parametrize("bad", [
        "bogus", "random", "nobody", "",
        "   ", "\t\n", "xyz", "1234",
    ])
    def test_invalid_strings(self, bad):
        assert _contacts_seniority_normalize(bad) is None

    @pytest.mark.parametrize("bad", [None, 0, 42, True, False, [], {}, set()])
    def test_non_string(self, bad):
        assert _contacts_seniority_normalize(bad) is None


# ---------------------------------------------------------------------------
# Label / short_label
# ---------------------------------------------------------------------------

class TestLabel:
    @pytest.mark.parametrize("key", list(_CONTACTS_SENIORITY_VALID))
    def test_canonical_has_label(self, key):
        label = _contacts_seniority_label(key)
        assert isinstance(label, str)
        assert label.strip()

    def test_alias_uses_normalized_label(self):
        assert _contacts_seniority_label("ceo") == "C-Suite"
        assert _contacts_seniority_label("svp") == "VP"

    def test_invalid_returns_fallback(self):
        assert _contacts_seniority_label("bogus") == "Contacts"
        assert _contacts_seniority_label("") == "Contacts"
        assert _contacts_seniority_label(None) == "Contacts"


class TestShortLabel:
    @pytest.mark.parametrize("key", list(_CONTACTS_SENIORITY_VALID))
    def test_matches_full_label(self, key):
        assert _contacts_seniority_short_label(key) == _contacts_seniority_label(key)


# ---------------------------------------------------------------------------
# Palette
# ---------------------------------------------------------------------------

class TestPalette:
    BANNED_HEXES = ("#1d4ed8", "#166534", "#991b1b", "#0891b2")

    @pytest.mark.parametrize("key", list(_CONTACTS_SENIORITY_VALID))
    def test_returns_bg_fg_tuple(self, key):
        bg, fg = _contacts_seniority_palette(key)
        assert isinstance(bg, str) and bg
        assert isinstance(fg, str) and fg

    @pytest.mark.parametrize("key", list(_CONTACTS_SENIORITY_VALID))
    def test_no_banned_hexes(self, key):
        bg, fg = _contacts_seniority_palette(key)
        for banned in self.BANNED_HEXES:
            assert banned not in bg.lower()
            assert banned not in fg.lower()

    def test_invalid_uses_muted(self):
        bg, fg = _contacts_seniority_palette("bogus")
        assert bg == "#f9f9f9"  # _G8_MUTED_BG

    def test_c_suite_uses_accent(self):
        bg, fg = _contacts_seniority_palette("c_suite")
        assert bg == "#f2eafe"  # _G8_ACCENT_BG
        assert fg == "#7d2df3"  # _G8_PRIMARY

    def test_vp_uses_accent(self):
        bg, fg = _contacts_seniority_palette("vp")
        assert bg == "#f2eafe"

    def test_manager_uses_warning(self):
        bg, fg = _contacts_seniority_palette("manager")
        assert bg == "#fff3c4"  # _G8_WARNING_BG


# ---------------------------------------------------------------------------
# Clip
# ---------------------------------------------------------------------------

class TestClip:
    def test_short_unchanged(self):
        assert _contacts_seniority_clip("hi", 100) == "hi"

    def test_exactly_at_cap(self):
        s = "a" * 10
        assert _contacts_seniority_clip(s, 10) == s

    def test_truncates_over_cap(self):
        result = _contacts_seniority_clip("a" * 100, 10)
        assert result.endswith("…")
        assert len(result) == 10

    def test_none(self):
        assert _contacts_seniority_clip(None, 10) == ""

    def test_empty(self):
        assert _contacts_seniority_clip("", 10) == ""

    def test_whitespace(self):
        assert _contacts_seniority_clip("   ", 10) == ""

    def test_coerces_int(self):
        assert _contacts_seniority_clip(42, 10) == "42"

    def test_strips_whitespace(self):
        assert _contacts_seniority_clip("  hello  ", 100) == "hello"


# ---------------------------------------------------------------------------
# Display name
# ---------------------------------------------------------------------------

class TestDisplayName:
    def test_first_last(self):
        name = _contacts_seniority_display_name(
            {"first_name": "Jane", "last_name": "Doe"}
        )
        assert "Jane" in name and "Doe" in name

    def test_first_only(self):
        name = _contacts_seniority_display_name({"first_name": "Jane"})
        assert "Jane" in name

    def test_last_only(self):
        name = _contacts_seniority_display_name({"last_name": "Doe"})
        assert "Doe" in name

    def test_email_fallback(self):
        name = _contacts_seniority_display_name(
            {"work_email": "user@example.com"}
        )
        assert "user@example.com" in name

    def test_unnamed_fallback(self):
        assert _contacts_seniority_display_name({}) == "(unnamed contact)"

    def test_non_dict(self):
        assert _contacts_seniority_display_name(None) == "(unnamed contact)"
        assert _contacts_seniority_display_name("foo") == "(unnamed contact)"
        assert _contacts_seniority_display_name([]) == "(unnamed contact)"

    def test_xss_escape(self):
        name = _contacts_seniority_display_name(
            {"first_name": "<script>", "last_name": "Doe"}
        )
        assert "<script>" not in name
        assert "&lt;script&gt;" in name


# ---------------------------------------------------------------------------
# Location
# ---------------------------------------------------------------------------

class TestLocation:
    def test_all_three(self):
        loc = _contacts_seniority_location(
            {"city": "SF", "state": "CA", "country": "US"}
        )
        assert "SF, CA, US" in loc

    def test_missing_city(self):
        loc = _contacts_seniority_location(
            {"state": "CA", "country": "US"}
        )
        assert loc == "CA, US"

    def test_missing_state(self):
        loc = _contacts_seniority_location(
            {"city": "SF", "country": "US"}
        )
        assert loc == "SF, US"

    def test_empty_fields(self):
        loc = _contacts_seniority_location(
            {"city": "", "state": "  ", "country": None}
        )
        assert loc == ""

    def test_all_missing(self):
        assert _contacts_seniority_location({}) == ""

    def test_non_dict(self):
        assert _contacts_seniority_location(None) == ""
        assert _contacts_seniority_location("foo") == ""

    def test_xss_escape(self):
        loc = _contacts_seniority_location(
            {"city": "<b>City</b>"}
        )
        assert "<b>" not in loc
        assert "&lt;b&gt;" in loc


# ---------------------------------------------------------------------------
# Header
# ---------------------------------------------------------------------------

class TestHeader:
    def test_contains_label(self):
        html = _contacts_seniority_header_html("vp", 5)
        assert "VP" in html

    def test_contains_count(self):
        html = _contacts_seniority_header_html("vp", 5)
        assert "5 contacts" in html

    def test_singular(self):
        html = _contacts_seniority_header_html("vp", 1)
        assert "1 contact" in html
        assert "1 contacts" not in html

    def test_zero(self):
        html = _contacts_seniority_header_html("vp", 0)
        assert "0 contacts" in html

    def test_uses_graph8_primary(self):
        html = _contacts_seniority_header_html("c_suite", 10)
        assert "#7d2df3" in html.lower()


# ---------------------------------------------------------------------------
# KPI card / stats row
# ---------------------------------------------------------------------------

class TestKpiCard:
    def test_label_and_value(self):
        html = _contacts_seniority_kpi_card_html("Total", "42")
        assert "Total" in html
        assert "42" in html

    def test_accent_variant_uses_primary(self):
        html = _contacts_seniority_kpi_card_html("T", "1", accent=True)
        assert "#7d2df3" in html.lower() or "#f2eafe" in html.lower()


class TestStatsRow:
    def test_four_cards(self):
        html = _contacts_seniority_stats_row_html([
            {"work_email": "a@b.com", "company_name": "X", "job_title": "VP"},
        ])
        assert "Total" in html
        assert "With email" in html
        assert "With company" in html
        assert "With title" in html

    def test_counts_correctly(self):
        html = _contacts_seniority_stats_row_html([
            {"work_email": "a@b.com", "company_name": "X", "job_title": "VP"},
            {"work_email": "b@b.com", "company_name": "", "job_title": ""},
            {"work_email": "", "company_name": "Y", "job_title": "CEO"},
        ])
        # 3 total, 2 with_email, 2 with_company, 2 with_title
        assert "3" in html
        assert "2" in html

    def test_empty_list(self):
        html = _contacts_seniority_stats_row_html([])
        assert "0" in html

    def test_no_seniority_tautology(self):
        """Pane is already scoped to one seniority — don't show a
        'seniority count' KPI. That would be trivially equal to Total."""
        html = _contacts_seniority_stats_row_html([
            {"seniority_level": "vp"},
        ])
        # No "By seniority" or "High seniority" label.
        assert "High seniority" not in html
        assert "Seniority count" not in html


# ---------------------------------------------------------------------------
# Chip
# ---------------------------------------------------------------------------

class TestChip:
    def test_renders_label(self):
        html = _contacts_seniority_chip_html("VP", bg="#fff", fg="#000")
        assert "VP" in html

    def test_border_optional(self):
        html_no_border = _contacts_seniority_chip_html(
            "VP", bg="#fff", fg="#000"
        )
        assert "border:none" in html_no_border
        html_with_border = _contacts_seniority_chip_html(
            "VP", bg="#fff", fg="#000", border="#000"
        )
        assert "border:1px solid" in html_with_border


# ---------------------------------------------------------------------------
# Row
# ---------------------------------------------------------------------------

class TestRow:
    def test_basic(self):
        html = _contacts_seniority_row_html(
            {
                "first_name": "Jane",
                "last_name": "Doe",
                "job_title": "VP Sales",
                "company_name": "Acme",
                "work_email": "jane@acme.com",
            },
            "vp",
        )
        assert "Jane Doe" in html
        assert "VP Sales" in html
        assert "Acme" in html
        assert "jane@acme.com" in html

    def test_xss_escape_name(self):
        html = _contacts_seniority_row_html(
            {"first_name": "<script>alert('x')</script>"},
            "vp",
        )
        assert "<script>" not in html
        assert "&lt;script&gt;" in html

    def test_xss_escape_title(self):
        html = _contacts_seniority_row_html(
            {"first_name": "A", "job_title": "<img onerror=x>"},
            "vp",
        )
        assert "<img onerror" not in html
        assert "&lt;img" in html

    def test_xss_escape_email(self):
        html = _contacts_seniority_row_html(
            {"first_name": "A", "work_email": "<x>@y"},
            "vp",
        )
        assert "<x>" not in html

    def test_xss_escape_company(self):
        html = _contacts_seniority_row_html(
            {"first_name": "A", "company_name": "<h1>Evil</h1>"},
            "vp",
        )
        assert "<h1>Evil</h1>" not in html

    def test_missing_fields_graceful(self):
        html = _contacts_seniority_row_html({}, "vp")
        assert "(unnamed contact)" in html

    def test_chip_present(self):
        html = _contacts_seniority_row_html(
            {"first_name": "A"}, "c_suite"
        )
        assert "C-Suite" in html

    def test_dept_chip_when_present(self):
        html = _contacts_seniority_row_html(
            {"first_name": "A", "job_department": "Engineering"},
            "vp",
        )
        assert "Engineering" in html

    def test_no_dept_chip_when_missing(self):
        html = _contacts_seniority_row_html({"first_name": "A"}, "vp")
        # Just ensure the render doesn't error; dept column missing is fine.
        assert "A " in html or "A<" in html or "A\n" in html

    def test_location_rendered(self):
        html = _contacts_seniority_row_html(
            {
                "first_name": "A",
                "city": "SF",
                "state": "CA",
                "country": "US",
            },
            "vp",
        )
        assert "SF, CA, US" in html


# ---------------------------------------------------------------------------
# List
# ---------------------------------------------------------------------------

class TestList:
    def test_renders_all_rows(self):
        contacts = [
            {"first_name": f"C{i}", "last_name": "X"} for i in range(5)
        ]
        html = _contacts_seniority_list_html(contacts, "vp")
        for i in range(5):
            assert f"C{i}" in html

    def test_caps_at_100(self):
        contacts = [
            {"first_name": f"C{i}"} for i in range(150)
        ]
        html = _contacts_seniority_list_html(contacts, "vp")
        # Only first 100 names present
        assert "C99" in html
        assert "C100" not in html


# ---------------------------------------------------------------------------
# Overflow banner
# ---------------------------------------------------------------------------

class TestOverflowBanner:
    def test_zero(self):
        assert _contacts_seniority_overflow_banner_html(0, "vp") == ""

    def test_negative(self):
        assert _contacts_seniority_overflow_banner_html(-5, "vp") == ""

    def test_positive(self):
        html = _contacts_seniority_overflow_banner_html(42, "vp")
        assert "42 more" in html
        assert "seniority_level=vp" in html
        assert "page=2" in html

    def test_uses_normalized_key_in_url(self):
        html = _contacts_seniority_overflow_banner_html(5, "ceo")
        assert "seniority_level=c_suite" in html

    def test_uses_muted_bg(self):
        html = _contacts_seniority_overflow_banner_html(10, "vp")
        assert "#f9f9f9" in html.lower()


# ---------------------------------------------------------------------------
# Drill up
# ---------------------------------------------------------------------------

class TestDrillUp:
    def test_has_dashboard(self):
        html = _contacts_seniority_drill_up_html("vp")
        assert "g8://contacts/dashboard" in html

    def test_siblings_present(self):
        html = _contacts_seniority_drill_up_html("vp")
        for sibling in _CONTACTS_SENIORITY_VALID:
            if sibling == "vp":
                continue
            assert f"g8://contacts/seniority/{sibling}" in html

    def test_no_self_reference(self):
        html = _contacts_seniority_drill_up_html("vp")
        # Self URI should NOT appear under drill-up card
        sibling_uri = "g8://contacts/seniority/vp"
        # Count - note the alias "vp-level" → vp won't appear as URI, only canonical keys
        # Self-ref check: the string "g8://contacts/seniority/vp<" should not exist
        # but every sibling like g8://contacts/seniority/executive might have other matches.
        # Simple check: exact sibling URI not present.
        assert sibling_uri + "</code>" not in html

    def test_all_siblings_for_c_suite(self):
        html = _contacts_seniority_drill_up_html("c_suite")
        for sibling in _CONTACTS_SENIORITY_VALID:
            if sibling == "c_suite":
                continue
            assert sibling in html

    def test_related_surfaces_label(self):
        html = _contacts_seniority_drill_up_html("vp")
        assert "Related surfaces" in html


# ---------------------------------------------------------------------------
# Empty state
# ---------------------------------------------------------------------------

class TestEmptyState:
    def test_zero_state_accent(self):
        html = _contacts_seniority_empty_state_html("vp", zero_state=True)
        assert "#7d2df3" in html.lower() or "#f2eafe" in html.lower()
        assert "No VP contacts" in html

    def test_zero_state_non_empty(self):
        html = _contacts_seniority_empty_state_html("c_suite", zero_state=True)
        assert "C-Suite" in html

    def test_unavailable_muted(self):
        html = _contacts_seniority_empty_state_html("vp", zero_state=False)
        assert "unavailable" in html.lower()
        assert "#f9f9f9" in html.lower() or "#dfdfdf" in html.lower()

    def test_unavailable_invalid_key(self):
        html = _contacts_seniority_empty_state_html("bogus", zero_state=False)
        assert "Contacts unavailable" in html

    def test_unavailable_hints_valid_keys(self):
        html = _contacts_seniority_empty_state_html("bogus", zero_state=False)
        assert "c_suite" in html
        assert "vp" in html


# ---------------------------------------------------------------------------
# render_contacts_seniority_html — full render
# ---------------------------------------------------------------------------

class TestRenderHtml:
    def test_happy_path(self):
        contacts = [
            {
                "first_name": "Jane",
                "last_name": "Doe",
                "job_title": "VP Sales",
                "company_name": "Acme",
                "work_email": "jane@acme.com",
                "seniority_level": "vp",
            },
        ]
        html = render_contacts_seniority_html(contacts=contacts, seniority="vp")
        assert "<!DOCTYPE html>" in html
        assert "Jane Doe" in html
        assert "Acme" in html
        assert "Contacts · VP" in html

    def test_invalid_seniority(self):
        html = render_contacts_seniority_html(contacts=[], seniority="bogus")
        assert "unavailable" in html.lower()

    def test_invalid_non_string(self):
        html = render_contacts_seniority_html(contacts=[], seniority=None)
        assert "unavailable" in html.lower()

    def test_none_payload(self):
        html = render_contacts_seniority_html(contacts=None, seniority="vp")
        assert "unavailable" in html.lower()

    def test_empty_list_zero_state(self):
        html = render_contacts_seniority_html(contacts=[], seniority="vp")
        assert "No VP contacts" in html
        # Zero-state is accent, not muted
        assert "#7d2df3" in html.lower() or "#f2eafe" in html.lower()

    def test_non_list_payload_treated_as_empty(self):
        html = render_contacts_seniority_html(
            contacts={"weird": "dict"}, seniority="vp"
        )
        assert "No VP contacts" in html

    def test_non_dict_entries_filtered(self):
        contacts = [
            {"first_name": "Real"},
            "string entry",
            None,
            42,
            {"first_name": "Real2"},
        ]
        html = render_contacts_seniority_html(contacts=contacts, seniority="vp")
        assert "Real" in html
        assert "Real2" in html
        assert "2 contacts" in html

    def test_sort_by_company_last_first(self):
        contacts = [
            {"first_name": "B", "last_name": "X", "company_name": "Zeta"},
            {"first_name": "A", "last_name": "X", "company_name": "Alpha"},
            {"first_name": "A", "last_name": "Y", "company_name": "Alpha"},
        ]
        html = render_contacts_seniority_html(
            contacts=contacts, seniority="vp"
        )
        # Alpha/X/A should come before Alpha/Y/A, which comes before Zeta/X/B
        idx_ax = html.find("A X")
        idx_ay = html.find("A Y")
        idx_bx = html.find("B X")
        assert idx_ax < idx_ay < idx_bx

    def test_alias_routed(self):
        html = render_contacts_seniority_html(
            contacts=[{"first_name": "Jane"}], seniority="ceo"
        )
        # "ceo" normalizes to "c_suite" → header label "C-Suite"
        assert "C-Suite" in html

    def test_xss_in_render(self):
        html = render_contacts_seniority_html(
            contacts=[{"first_name": "<script>alert('xss')</script>"}],
            seniority="vp",
        )
        assert "<script>" not in html
        assert "&lt;script&gt;" in html

    def test_overflow_banner_appears(self):
        contacts = [
            {"first_name": f"C{i}"} for i in range(150)
        ]
        html = render_contacts_seniority_html(
            contacts=contacts, seniority="vp"
        )
        assert "50 more" in html
        assert "seniority_level=vp" in html


# ---------------------------------------------------------------------------
# Design tokens — lock-out banned hexes
# ---------------------------------------------------------------------------

class TestDesignTokens:
    BANNED = ("#1d4ed8", "#166534", "#991b1b", "#0891b2")

    def _sample_render(self):
        return render_contacts_seniority_html(
            contacts=[
                {
                    "first_name": "J",
                    "last_name": "D",
                    "job_title": "VP",
                    "company_name": "Acme",
                    "work_email": "j@acme.com",
                    "job_department": "Sales",
                    "city": "SF",
                    "state": "CA",
                    "country": "US",
                },
            ],
            seniority="vp",
        )

    @pytest.mark.parametrize("banned", list(BANNED))
    def test_no_banned_hexes_in_html(self, banned):
        html = self._sample_render()
        assert banned not in html.lower()

    @pytest.mark.parametrize("token", [
        "#7d2df3",  # _G8_PRIMARY
        "#f2eafe",  # _G8_ACCENT_BG
        "#dfdfdf",  # _G8_BORDER
        "#f9f9f9",  # _G8_MUTED_BG
    ])
    def test_graph8_tokens_present(self, token):
        html = self._sample_render()
        assert token in html.lower()

    def test_aeonik_font(self):
        html = self._sample_render()
        assert "Aeonik" in html


# ---------------------------------------------------------------------------
# No JavaScript
# ---------------------------------------------------------------------------

class TestNoJs:
    def test_no_script_tag(self):
        html = render_contacts_seniority_html(
            contacts=[{"first_name": "A"}], seniority="vp"
        )
        assert "<script" not in html.lower()
        assert "</script" not in html.lower()

    def test_no_event_handlers(self):
        html = render_contacts_seniority_html(
            contacts=[{"first_name": "A"}], seniority="vp"
        )
        for attr in ("onclick=", "onerror=", "onload=", "onmouseover="):
            assert attr not in html.lower()


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------

class TestTextFallback:
    def test_invalid_seniority(self):
        txt = render_contacts_seniority_text_fallback(
            contacts=[], seniority="bogus"
        )
        assert "unavailable" in txt.lower()
        assert "c_suite" in txt

    def test_none_payload(self):
        txt = render_contacts_seniority_text_fallback(
            contacts=None, seniority="vp"
        )
        assert "unavailable" in txt.lower()

    def test_empty_list(self):
        txt = render_contacts_seniority_text_fallback(
            contacts=[], seniority="vp"
        )
        assert "No VP contacts yet" in txt
        assert "Related surfaces" in txt

    def test_happy_path(self):
        contacts = [
            {
                "first_name": "Jane",
                "last_name": "Doe",
                "job_title": "VP Sales",
                "company_name": "Acme",
                "work_email": "jane@acme.com",
            },
        ]
        txt = render_contacts_seniority_text_fallback(
            contacts=contacts, seniority="vp"
        )
        assert "Jane Doe" in txt
        assert "VP Sales" in txt
        assert "Acme" in txt
        assert "jane@acme.com" in txt
        assert "Related surfaces" in txt
        assert "Backend filter" in txt

    def test_stats_in_text(self):
        contacts = [
            {
                "first_name": "A", "work_email": "a@b.com",
                "company_name": "X", "job_title": "T1",
            },
        ]
        txt = render_contacts_seniority_text_fallback(
            contacts=contacts, seniority="vp"
        )
        assert "Total: 1" in txt
        assert "With email: 1" in txt
        assert "With company: 1" in txt
        assert "With title: 1" in txt

    def test_overflow_note(self):
        contacts = [
            {"first_name": f"C{i}"} for i in range(150)
        ]
        txt = render_contacts_seniority_text_fallback(
            contacts=contacts, seniority="vp"
        )
        assert "50 more contact" in txt

    def test_unnamed_fallback(self):
        contacts = [{"seniority_level": "vp"}]
        txt = render_contacts_seniority_text_fallback(
            contacts=contacts, seniority="vp"
        )
        assert "(unnamed contact)" in txt


# ---------------------------------------------------------------------------
# Smoke — every alias normalizes + renders cleanly
# ---------------------------------------------------------------------------

class TestSmoke:
    @pytest.mark.parametrize(
        "alias",
        list(_CONTACTS_SENIORITY_ALIASES.keys())
        + list(_CONTACTS_SENIORITY_VALID),
    )
    def test_alias_renders_without_error(self, alias):
        html = render_contacts_seniority_html(
            contacts=[{"first_name": "A"}], seniority=alias
        )
        assert html.startswith("<!DOCTYPE html>")

    @pytest.mark.parametrize(
        "alias",
        list(_CONTACTS_SENIORITY_ALIASES.keys())
        + list(_CONTACTS_SENIORITY_VALID),
    )
    def test_alias_text_without_error(self, alias):
        txt = render_contacts_seniority_text_fallback(
            contacts=[{"first_name": "A"}], seniority=alias
        )
        assert len(txt) > 0


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

class TestConstants:
    def test_valid_keys_is_tuple(self):
        assert isinstance(_CONTACTS_SENIORITY_VALID, tuple)
        assert len(_CONTACTS_SENIORITY_VALID) == 11

    def test_labels_covers_all_valid(self):
        for key in _CONTACTS_SENIORITY_VALID:
            assert key in _CONTACTS_SENIORITY_LABELS
            assert isinstance(_CONTACTS_SENIORITY_LABELS[key], str)

    def test_aliases_target_valid(self):
        for alias, target in _CONTACTS_SENIORITY_ALIASES.items():
            assert target in _CONTACTS_SENIORITY_VALID, (
                f"Alias {alias!r} → {target!r} not in canonical set"
            )

    def test_no_alias_equals_canonical(self):
        """Aliases must not shadow canonical keys."""
        canonical_set = set(_CONTACTS_SENIORITY_VALID)
        for alias in _CONTACTS_SENIORITY_ALIASES:
            assert alias not in canonical_set, (
                f"Alias {alias!r} shadows canonical key"
            )
