"""Unit tests for Upgrade 4 surface #39: webhook deliveries HTML renderer.

Drills down from surface #31 (webhook overview — which only shows 10
recent deliveries) and answers the next question after "is it firing?":
"why did delivery X fail?" Ships with graph8 design tokens from the
start — tests lock in the absence of AI-tell accent borders and legacy
palette colors.

Design parity assertions (vs earlier surfaces):
    - Uniform 1px solid #dfdfdf border on every card (no `border-top:
      3px solid <accent>` or `border-left: 3px solid <accent>`)
    - shadow-xs on cards
    - #7d2df3 primary + #f2eafe primary tint for accent chips only
    - Aeonik font-family first
    - Semantic status colors drawn from graph8 tokens
"""

from __future__ import annotations

import pytest

from g8_mcp_server.app_renderer import (
    _WEBHOOK_DELIVERY_STATUS_PALETTE,
    _render_webhook_deliveries_empty_state_html,
    _webhook_deliveries_bucket_events,
    _webhook_deliveries_bucket_statuses,
    _webhook_deliveries_clip,
    _webhook_deliveries_duration,
    _webhook_deliveries_response_code_palette,
    _webhook_deliveries_stat_card,
    _webhook_deliveries_status_key,
    _webhook_deliveries_status_palette,
    _webhook_deliveries_success_rate,
    render_webhook_deliveries_html,
    render_webhook_deliveries_text_fallback,
)

_BANNED_HEXES = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}


class TestWebhookDeliveriesPaletteNoBannedHexes:
    """Lock test: status palette must not reintroduce banned Studio hexes."""

    def test_no_banned_hexes_in_status_palette(self):
        for key, (bg, fg) in _WEBHOOK_DELIVERY_STATUS_PALETTE.items():
            for value in (bg, fg):
                assert value.lower() not in _BANNED_HEXES, (
                    f"Banned hex {value!r} in _WEBHOOK_DELIVERY_STATUS_PALETTE[{key!r}]"
                )


# =============================================================== #
# Helpers                                                         #
# =============================================================== #


def _make_delivery(
    *,
    id: str = "dlv_1",
    event: str | None = "contact.created",
    status: str | None = "success",
    attempts: int | None = 1,
    max_attempts: int | None = 3,
    response_code: int | None = 200,
    error_message: str | None = None,
    created_at: str | None = "2026-04-20T12:00:00Z",
    completed_at: str | None = "2026-04-20T12:00:00.250Z",
) -> dict:
    return {
        "id": id,
        "event": event,
        "status": status,
        "attempts": attempts,
        "max_attempts": max_attempts,
        "response_code": response_code,
        "error_message": error_message,
        "created_at": created_at,
        "completed_at": completed_at,
    }


# =============================================================== #
# _webhook_deliveries_clip                                        #
# =============================================================== #


class TestClip:
    def test_non_string_returns_empty(self):
        assert _webhook_deliveries_clip(None, 10) == ""
        assert _webhook_deliveries_clip(42, 10) == ""
        assert _webhook_deliveries_clip({"a": 1}, 10) == ""

    def test_whitespace_returns_empty(self):
        assert _webhook_deliveries_clip("   ", 10) == ""
        assert _webhook_deliveries_clip("", 10) == ""

    def test_short_string_passes_through_escaped(self):
        assert _webhook_deliveries_clip("hello", 10) == "hello"

    def test_long_string_clips_with_ellipsis(self):
        result = _webhook_deliveries_clip("a" * 50, 10)
        assert len(result) == 10
        assert result.endswith("\u2026")

    def test_html_escape(self):
        assert _webhook_deliveries_clip("<script>", 40) == "&lt;script&gt;"
        # amp + quote
        assert "&amp;" in _webhook_deliveries_clip("A&B", 40)

    def test_strips_whitespace(self):
        assert _webhook_deliveries_clip("  hi  ", 10) == "hi"


# =============================================================== #
# _webhook_deliveries_status_key                                  #
# =============================================================== #


class TestStatusKey:
    def test_lowercases(self):
        assert _webhook_deliveries_status_key("SUCCESS") == "success"
        assert _webhook_deliveries_status_key("Failed") == "failed"

    def test_strips(self):
        assert _webhook_deliveries_status_key("  success  ") == "success"

    def test_empty_returns_unknown(self):
        assert _webhook_deliveries_status_key("") == "unknown"
        assert _webhook_deliveries_status_key("   ") == "unknown"

    def test_non_string_returns_unknown(self):
        assert _webhook_deliveries_status_key(None) == "unknown"
        assert _webhook_deliveries_status_key(42) == "unknown"
        assert _webhook_deliveries_status_key([]) == "unknown"


# =============================================================== #
# _webhook_deliveries_status_palette                              #
# =============================================================== #


class TestStatusPalette:
    def test_success_aliases_all_green(self):
        # All three success aliases produce identical (positive) color
        p1 = _webhook_deliveries_status_palette("success")
        p2 = _webhook_deliveries_status_palette("succeeded")
        p3 = _webhook_deliveries_status_palette("delivered")
        assert p1 == p2 == p3

    def test_failure_aliases(self):
        assert _webhook_deliveries_status_palette("failed") == \
            _webhook_deliveries_status_palette("error")

    def test_retry_aliases(self):
        assert _webhook_deliveries_status_palette("retrying") == \
            _webhook_deliveries_status_palette("retry")

    def test_pending_and_queued_share_primary(self):
        assert _webhook_deliveries_status_palette("pending") == \
            _webhook_deliveries_status_palette("queued")
        bg, fg = _webhook_deliveries_status_palette("pending")
        assert bg == "#dbe9ff"
        assert fg == "#7d2df3"  # _G8_PRIMARY — was banned #1d4ed8

    def test_unknown_returns_muted(self):
        bg, fg = _webhook_deliveries_status_palette("some_unrecognized_status")
        # Not a success / failure / retry color
        assert bg not in {"#dbe9ff"}
        # Muted gray fg
        assert isinstance(bg, str) and isinstance(fg, str)


# =============================================================== #
# _webhook_deliveries_response_code_palette                       #
# =============================================================== #


class TestResponseCodePalette:
    def test_2xx_green(self):
        bg, fg = _webhook_deliveries_response_code_palette(200)
        assert "#" in bg
        # Green family — check fg is not warning / destructive family
        bg_201, _ = _webhook_deliveries_response_code_palette(201)
        assert (bg, fg) == (bg_201, _)

    def test_4xx_amber(self):
        # 4xx shares palette family (warning)
        p400 = _webhook_deliveries_response_code_palette(404)
        p401 = _webhook_deliveries_response_code_palette(401)
        assert p400 == p401

    def test_5xx_red(self):
        p500 = _webhook_deliveries_response_code_palette(500)
        p503 = _webhook_deliveries_response_code_palette(503)
        assert p500 == p503

    def test_distinct_families(self):
        p2 = _webhook_deliveries_response_code_palette(200)
        p4 = _webhook_deliveries_response_code_palette(404)
        p5 = _webhook_deliveries_response_code_palette(500)
        # All three distinct
        assert p2 != p4
        assert p4 != p5
        assert p2 != p5

    def test_rejects_bool(self):
        # True is subclass of int → critical to reject
        p_true = _webhook_deliveries_response_code_palette(True)
        p_muted = _webhook_deliveries_response_code_palette("unrecognized")
        assert p_true == p_muted

    def test_string_digit_coerced(self):
        # "200" → treated as 200
        p_str = _webhook_deliveries_response_code_palette("200")
        p_int = _webhook_deliveries_response_code_palette(200)
        assert p_str == p_int

    def test_non_digit_string_muted(self):
        p = _webhook_deliveries_response_code_palette("abc")
        p2 = _webhook_deliveries_response_code_palette(None)
        # Both fall back to muted
        assert p == p2

    def test_out_of_range(self):
        # 1xx, 3xx, 6xx → muted
        p100 = _webhook_deliveries_response_code_palette(100)
        p300 = _webhook_deliveries_response_code_palette(301)
        p600 = _webhook_deliveries_response_code_palette(600)
        p_muted = _webhook_deliveries_response_code_palette(None)
        assert p100 == p300 == p600 == p_muted


# =============================================================== #
# _webhook_deliveries_duration                                    #
# =============================================================== #


class TestDuration:
    def test_milliseconds(self):
        d = _webhook_deliveries_duration(
            "2026-04-20T12:00:00Z", "2026-04-20T12:00:00.250Z"
        )
        assert d == "250ms"

    def test_seconds(self):
        d = _webhook_deliveries_duration(
            "2026-04-20T12:00:00Z", "2026-04-20T12:00:01.500Z"
        )
        assert d == "1.5s"

    def test_minutes(self):
        d = _webhook_deliveries_duration(
            "2026-04-20T12:00:00Z", "2026-04-20T12:01:30Z"
        )
        assert d == "1.5m"

    def test_hours(self):
        d = _webhook_deliveries_duration(
            "2026-04-20T12:00:00Z", "2026-04-20T14:30:00Z"
        )
        assert d == "2.5h"

    def test_negative_delta_empty(self):
        d = _webhook_deliveries_duration(
            "2026-04-20T12:00:01Z", "2026-04-20T12:00:00Z"
        )
        assert d == ""

    def test_malformed_iso_empty(self):
        d = _webhook_deliveries_duration("not-a-date", "2026-04-20T12:00:00Z")
        assert d == ""

    def test_non_strings_empty(self):
        assert _webhook_deliveries_duration(None, None) == ""
        assert _webhook_deliveries_duration(42, "2026-04-20T12:00:00Z") == ""
        assert _webhook_deliveries_duration("2026-04-20T12:00:00Z", None) == ""

    def test_z_suffix_tolerated(self):
        # Python <3.11 rejects 'Z' in fromisoformat; renderer handles it
        d = _webhook_deliveries_duration(
            "2026-04-20T12:00:00Z", "2026-04-20T12:00:02Z"
        )
        assert d == "2.0s"


# =============================================================== #
# _webhook_deliveries_bucket_events                               #
# =============================================================== #


class TestBucketEvents:
    def test_groups_by_event(self):
        deliveries = [
            _make_delivery(event="contact.created"),
            _make_delivery(event="contact.created"),
            _make_delivery(event="contact.updated"),
        ]
        buckets = _webhook_deliveries_bucket_events(deliveries)
        assert buckets[0] == ("contact.created", 2)
        assert buckets[1] == ("contact.updated", 1)

    def test_unknown_for_missing(self):
        deliveries = [
            _make_delivery(event=None),
            _make_delivery(event=""),
            _make_delivery(event="   "),
        ]
        buckets = _webhook_deliveries_bucket_events(deliveries)
        # All three fold into 'unknown'
        assert ("unknown", 3) in buckets

    def test_sorted_desc_by_count_alpha_tiebreak(self):
        deliveries = [
            _make_delivery(event="b.event"),
            _make_delivery(event="a.event"),
            _make_delivery(event="c.event"),
            _make_delivery(event="a.event"),
        ]
        buckets = _webhook_deliveries_bucket_events(deliveries)
        # a.event has 2, then b.event and c.event each have 1
        # Tiebreak alphabetical within count=1
        assert buckets[0] == ("a.event", 2)
        assert buckets[1][0] == "b.event"
        assert buckets[2][0] == "c.event"

    def test_skips_non_dicts(self):
        buckets = _webhook_deliveries_bucket_events([None, "nope", 42])
        assert buckets == []


# =============================================================== #
# _webhook_deliveries_bucket_statuses                             #
# =============================================================== #


class TestBucketStatuses:
    def test_groups_by_normalized_status(self):
        deliveries = [
            _make_delivery(status="SUCCESS"),
            _make_delivery(status="success"),
            _make_delivery(status="Failed"),
        ]
        buckets = _webhook_deliveries_bucket_statuses(deliveries)
        # Normalized: success=2, failed=1
        lookup = dict(buckets)
        assert lookup["success"] == 2
        assert lookup["failed"] == 1

    def test_unknown_for_missing(self):
        deliveries = [_make_delivery(status=None)]
        buckets = _webhook_deliveries_bucket_statuses(deliveries)
        assert ("unknown", 1) in buckets

    def test_sorted_desc(self):
        deliveries = [
            _make_delivery(status="success"),
            _make_delivery(status="failed"),
            _make_delivery(status="failed"),
        ]
        buckets = _webhook_deliveries_bucket_statuses(deliveries)
        assert buckets[0] == ("failed", 2)


# =============================================================== #
# _webhook_deliveries_success_rate                                #
# =============================================================== #


class TestSuccessRate:
    def test_all_success(self):
        deliveries = [_make_delivery(status="success") for _ in range(5)]
        assert _webhook_deliveries_success_rate(deliveries) == (5, 0, 5)

    def test_all_aliases_counted(self):
        deliveries = [
            _make_delivery(status="success"),
            _make_delivery(status="succeeded"),
            _make_delivery(status="delivered"),
        ]
        succeeded, failed, total = _webhook_deliveries_success_rate(deliveries)
        assert succeeded == 3
        assert failed == 0
        assert total == 3

    def test_mixed(self):
        deliveries = [
            _make_delivery(status="success"),
            _make_delivery(status="failed"),
            _make_delivery(status="error"),
            _make_delivery(status="pending"),  # not counted as failure
        ]
        succeeded, failed, total = _webhook_deliveries_success_rate(deliveries)
        assert succeeded == 1
        assert failed == 2
        assert total == 4

    def test_empty(self):
        assert _webhook_deliveries_success_rate([]) == (0, 0, 0)

    def test_skips_non_dicts(self):
        succeeded, failed, total = _webhook_deliveries_success_rate(
            [None, "nope", _make_delivery(status="success")]
        )
        assert (succeeded, failed, total) == (1, 0, 1)


# =============================================================== #
# _webhook_deliveries_stat_card                                   #
# =============================================================== #


class TestStatCard:
    def test_four_accents(self):
        for accent in ("text", "primary", "positive", "destructive"):
            html_out = _webhook_deliveries_stat_card("Label", "42", accent=accent)
            assert "Label" in html_out
            assert "42" in html_out

    def test_unknown_accent_falls_back(self):
        # Gracefully falls back to default text color
        html_out = _webhook_deliveries_stat_card("L", "V", accent="nonsense")
        assert "L" in html_out
        assert "V" in html_out

    def test_uniform_border_not_single_side(self):
        html_out = _webhook_deliveries_stat_card("L", "V", accent="primary")
        # No single-side accent bar (AI-tell anti-pattern)
        assert "border-top:3px" not in html_out
        assert "border-left:3px" not in html_out
        assert "border-right:3px" not in html_out
        assert "border-bottom:3px" not in html_out
        # But uniform 1px border is present
        assert "border:1px solid #dfdfdf" in html_out

    def test_html_escapes_label_and_value(self):
        html_out = _webhook_deliveries_stat_card("<L>", "<V>", accent="text")
        assert "&lt;L&gt;" in html_out
        assert "&lt;V&gt;" in html_out

    def test_primary_accent_uses_graph8_purple(self):
        html_out = _webhook_deliveries_stat_card("L", "V", accent="primary")
        assert "#7d2df3" in html_out


# =============================================================== #
# Empty state                                                     #
# =============================================================== #


class TestEmptyState:
    def test_unavailable_mode(self):
        html_out = _render_webhook_deliveries_empty_state_html(
            "wh_123", mode="unavailable"
        )
        assert "not available" in html_out.lower()
        assert "wh_123" in html_out

    def test_empty_mode(self):
        html_out = _render_webhook_deliveries_empty_state_html(
            "wh_123", mode="empty"
        )
        assert "no deliveries" in html_out.lower()
        assert "wh_123" in html_out

    def test_xss_in_webhook_id_escaped(self):
        html_out = _render_webhook_deliveries_empty_state_html(
            "<script>alert(1)</script>", mode="empty"
        )
        assert "<script>alert(1)</script>" not in html_out
        assert "&lt;script&gt;" in html_out


# =============================================================== #
# render_webhook_deliveries_html                                  #
# =============================================================== #


class TestRenderHtml:
    def test_none_deliveries_yields_unavailable_state(self):
        html_out = render_webhook_deliveries_html(
            deliveries=None, webhook_id="wh_abc"
        )
        assert "not available" in html_out.lower()

    def test_empty_deliveries_yields_empty_state(self):
        html_out = render_webhook_deliveries_html(
            deliveries=[], webhook_id="wh_abc"
        )
        assert "no deliveries" in html_out.lower()

    def test_single_delivery_renders(self):
        html_out = render_webhook_deliveries_html(
            deliveries=[_make_delivery()],
            webhook_id="wh_abc",
        )
        assert "Webhook" in html_out
        assert "wh_abc" in html_out
        assert "contact.created" in html_out
        assert "dlv_1" in html_out
        assert "HTTP 200" in html_out

    def test_stat_cards_present(self):
        html_out = render_webhook_deliveries_html(
            deliveries=[
                _make_delivery(status="success"),
                _make_delivery(status="success"),
                _make_delivery(status="failed"),
            ],
            webhook_id="wh_abc",
        )
        assert "Total deliveries" in html_out
        assert "Succeeded" in html_out
        assert "Failed" in html_out
        assert "Success rate" in html_out
        # 3 total, 2 success, 1 failed → 67%
        assert "67%" in html_out

    def test_status_chips_section(self):
        html_out = render_webhook_deliveries_html(
            deliveries=[_make_delivery(status="success"), _make_delivery(status="failed")],
            webhook_id="wh_abc",
        )
        assert "Delivery status mix" in html_out
        assert "Success" in html_out
        assert "Failed" in html_out

    def test_event_chips_section(self):
        html_out = render_webhook_deliveries_html(
            deliveries=[
                _make_delivery(event="contact.created"),
                _make_delivery(event="contact.updated"),
            ],
            webhook_id="wh_abc",
        )
        assert "Events" in html_out
        assert "contact.created" in html_out
        assert "contact.updated" in html_out

    def test_overflow_past_40(self):
        deliveries = [_make_delivery(id=f"dlv_{i}") for i in range(45)]
        html_out = render_webhook_deliveries_html(
            deliveries=deliveries, webhook_id="wh_abc"
        )
        # Only first 40 rendered
        assert "dlv_0" in html_out
        assert "dlv_39" in html_out
        assert "dlv_44" not in html_out
        # Overflow note
        assert "+ 5 older deliveries" in html_out
        assert "page=2" in html_out

    def test_event_overflow_past_8(self):
        deliveries = [
            _make_delivery(event=f"event.{i}") for i in range(10)
        ]
        html_out = render_webhook_deliveries_html(
            deliveries=deliveries, webhook_id="wh_abc"
        )
        # Only 8 event chips rendered
        assert "+ 2 more events" in html_out

    def test_webhook_label_from_name(self):
        html_out = render_webhook_deliveries_html(
            deliveries=[_make_delivery()],
            webhook_id="wh_abc",
            webhook={"name": "Segment sync webhook"},
        )
        assert "Segment sync webhook" in html_out

    def test_webhook_label_falls_back_to_url(self):
        html_out = render_webhook_deliveries_html(
            deliveries=[_make_delivery()],
            webhook_id="wh_abc",
            webhook={"url": "https://example.com/hooks/foo"},
        )
        assert "example.com" in html_out

    def test_webhook_label_default(self):
        html_out = render_webhook_deliveries_html(
            deliveries=[_make_delivery()],
            webhook_id="wh_abc",
            webhook={},
        )
        assert "Webhook" in html_out

    def test_xss_in_webhook_name_escaped(self):
        html_out = render_webhook_deliveries_html(
            deliveries=[_make_delivery()],
            webhook_id="wh_abc",
            webhook={"name": "<script>alert(1)</script>"},
        )
        assert "<script>alert(1)</script>" not in html_out
        assert "&lt;script&gt;" in html_out

    def test_xss_in_event_name_escaped(self):
        html_out = render_webhook_deliveries_html(
            deliveries=[_make_delivery(event="<script>")],
            webhook_id="wh_abc",
        )
        assert "<script>" not in html_out.replace("<script", "XXX")  # just ensure no raw <script tag
        # More direct check: escape is present
        assert "&lt;script&gt;" in html_out

    def test_xss_in_error_message_escaped(self):
        html_out = render_webhook_deliveries_html(
            deliveries=[
                _make_delivery(
                    status="failed",
                    error_message="<img src=x onerror=alert(1)>",
                )
            ],
            webhook_id="wh_abc",
        )
        assert "<img src=x" not in html_out
        assert "&lt;img" in html_out

    def test_attempts_counter_at_max_warning(self):
        html_out = render_webhook_deliveries_html(
            deliveries=[
                _make_delivery(status="failed", attempts=3, max_attempts=3)
            ],
            webhook_id="wh_abc",
        )
        # Warning-tinted counter — warning FG token from graph8 palette
        assert "attempts 3/3" in html_out
        # Warning FG is #a0750a
        assert "#a0750a" in html_out

    def test_attempts_counter_below_max_muted(self):
        html_out = render_webhook_deliveries_html(
            deliveries=[
                _make_delivery(status="retrying", attempts=1, max_attempts=3)
            ],
            webhook_id="wh_abc",
        )
        assert "attempts 1/3" in html_out

    def test_attempts_no_max(self):
        html_out = render_webhook_deliveries_html(
            deliveries=[
                _make_delivery(attempts=2, max_attempts=None)
            ],
            webhook_id="wh_abc",
        )
        assert "attempts 2" in html_out

    def test_bool_attempts_rejected(self):
        # bool is subclass of int — renderer guards against this
        html_out = render_webhook_deliveries_html(
            deliveries=[_make_delivery(attempts=True, max_attempts=True)],
            webhook_id="wh_abc",
        )
        # No attempts display — neither "attempts 1" nor "True"
        assert "attempts True" not in html_out
        assert "attempts 1/1" not in html_out

    def test_response_code_chip_ranges(self):
        # 2xx green, 4xx amber, 5xx red
        html_out = render_webhook_deliveries_html(
            deliveries=[
                _make_delivery(id="a", response_code=200),
                _make_delivery(id="b", response_code=404, status="failed"),
                _make_delivery(id="c", response_code=503, status="failed"),
            ],
            webhook_id="wh_abc",
        )
        assert "HTTP 200" in html_out
        assert "HTTP 404" in html_out
        assert "HTTP 503" in html_out

    def test_no_response_code_chip_when_missing(self):
        html_out = render_webhook_deliveries_html(
            deliveries=[_make_delivery(response_code=None, status="pending")],
            webhook_id="wh_abc",
        )
        assert "HTTP" not in html_out

    def test_bool_response_code_rejected(self):
        html_out = render_webhook_deliveries_html(
            deliveries=[_make_delivery(response_code=True)],
            webhook_id="wh_abc",
        )
        assert "HTTP True" not in html_out
        assert "HTTP 1" not in html_out

    def test_drill_up_card_present(self):
        html_out = render_webhook_deliveries_html(
            deliveries=[_make_delivery()],
            webhook_id="wh_abc",
        )
        assert "g8://webhooks/wh_abc/overview" in html_out
        assert "/webhooks/wh_abc/deliveries?status=failed" in html_out
        assert "GET /webhooks" in html_out

    def test_total_chip_shown_in_header(self):
        html_out = render_webhook_deliveries_html(
            deliveries=[_make_delivery() for _ in range(7)],
            webhook_id="wh_abc",
        )
        assert "7 TOTAL" in html_out

    def test_duration_rendered_in_row(self):
        html_out = render_webhook_deliveries_html(
            deliveries=[_make_delivery()],
            webhook_id="wh_abc",
        )
        assert "(250ms)" in html_out

    def test_no_single_side_accent_borders(self):
        """Lock out the AI-tell single-side colored accent pattern."""
        html_out = render_webhook_deliveries_html(
            deliveries=[_make_delivery() for _ in range(3)],
            webhook_id="wh_abc",
        )
        forbidden_patterns = [
            "border-top:3px solid",
            "border-left:3px solid",
            "border-right:3px solid",
            "border-bottom:3px solid",
            "border-top:4px solid",
            "border-left:4px solid",
        ]
        for pat in forbidden_patterns:
            assert pat not in html_out, f"Found forbidden AI-tell pattern: {pat}"

    def test_no_legacy_accent_hexes(self):
        """Lock out legacy palette colors from surfaces #1-#35."""
        html_out = render_webhook_deliveries_html(
            deliveries=[_make_delivery()],
            webhook_id="wh_abc",
        )
        # Legacy indigo accent from earlier surfaces
        assert "#4f46e5" not in html_out
        # Legacy green that isn't the positive FG token
        assert "#10b981" not in html_out
        # Legacy pink that's not used
        assert "#ec4899" not in html_out

    def test_aeonik_font_present(self):
        html_out = render_webhook_deliveries_html(
            deliveries=[_make_delivery()],
            webhook_id="wh_abc",
        )
        assert "Aeonik" in html_out

    def test_graph8_primary_purple_present(self):
        html_out = render_webhook_deliveries_html(
            deliveries=[_make_delivery()],
            webhook_id="wh_abc",
        )
        assert "#7d2df3" in html_out


# =============================================================== #
# Text fallback                                                   #
# =============================================================== #


class TestTextFallback:
    def test_none_deliveries_unavailable(self):
        text = render_webhook_deliveries_text_fallback(
            deliveries=None, webhook_id="wh_abc"
        )
        assert "not available" in text.lower()
        assert "wh_abc" in text

    def test_empty_deliveries(self):
        text = render_webhook_deliveries_text_fallback(
            deliveries=[], webhook_id="wh_abc"
        )
        assert "no deliveries" in text.lower()

    def test_markdown_headers(self):
        text = render_webhook_deliveries_text_fallback(
            deliveries=[_make_delivery(status="success"), _make_delivery(status="failed")],
            webhook_id="wh_abc",
        )
        assert "# " in text  # header
        assert "## Delivery status mix" in text
        assert "## Events" in text
        assert "## Deliveries" in text
        assert "## Drill into this webhook" in text

    def test_stats_rendered(self):
        text = render_webhook_deliveries_text_fallback(
            deliveries=[_make_delivery() for _ in range(3)],
            webhook_id="wh_abc",
        )
        assert "Total deliveries: 3" in text
        assert "Succeeded: 3" in text
        assert "Success rate:" in text

    def test_response_code_shown(self):
        text = render_webhook_deliveries_text_fallback(
            deliveries=[_make_delivery(response_code=200)],
            webhook_id="wh_abc",
        )
        assert "HTTP 200" in text

    def test_bool_response_code_rejected(self):
        text = render_webhook_deliveries_text_fallback(
            deliveries=[_make_delivery(response_code=True)],
            webhook_id="wh_abc",
        )
        assert "HTTP True" not in text
        assert "HTTP 1" not in text

    def test_attempts_counter(self):
        text = render_webhook_deliveries_text_fallback(
            deliveries=[_make_delivery(attempts=2, max_attempts=3)],
            webhook_id="wh_abc",
        )
        assert "attempts 2/3" in text

    def test_attempts_no_max(self):
        text = render_webhook_deliveries_text_fallback(
            deliveries=[_make_delivery(attempts=2, max_attempts=None)],
            webhook_id="wh_abc",
        )
        assert "attempts 2" in text

    def test_bool_attempts_rejected(self):
        text = render_webhook_deliveries_text_fallback(
            deliveries=[_make_delivery(attempts=True)],
            webhook_id="wh_abc",
        )
        assert "attempts True" not in text
        assert "attempts 1" not in text

    def test_error_message_shown(self):
        text = render_webhook_deliveries_text_fallback(
            deliveries=[
                _make_delivery(status="failed", error_message="timeout")
            ],
            webhook_id="wh_abc",
        )
        assert "error: timeout" in text

    def test_overflow_past_40(self):
        text = render_webhook_deliveries_text_fallback(
            deliveries=[_make_delivery(id=f"d{i}") for i in range(50)],
            webhook_id="wh_abc",
        )
        assert "+ 10 older deliveries" in text

    def test_drill_up_pointers(self):
        text = render_webhook_deliveries_text_fallback(
            deliveries=[_make_delivery()],
            webhook_id="wh_abc",
        )
        assert "g8://webhooks/wh_abc/overview" in text
        assert "/webhooks/wh_abc/deliveries?status=failed" in text

    def test_webhook_name_used_when_present(self):
        text = render_webhook_deliveries_text_fallback(
            deliveries=[_make_delivery()],
            webhook_id="wh_abc",
            webhook={"name": "Segment sync"},
        )
        assert "Segment sync" in text


# =============================================================== #
# Smoke test — large realistic payload                            #
# =============================================================== #


class TestSmoke:
    def test_large_mixed_payload(self):
        deliveries = [
            _make_delivery(
                id=f"dlv_{i}",
                event=f"event.{i % 5}",
                status=(
                    "success" if i % 3 == 0
                    else "failed" if i % 3 == 1
                    else "retrying"
                ),
                attempts=(i % 4) + 1,
                response_code=(
                    200 if i % 3 == 0
                    else 503 if i % 3 == 1
                    else None
                ),
                error_message=(
                    f"Connection timeout to partner after {i}s"
                    if i % 3 == 1
                    else None
                ),
            )
            for i in range(25)
        ]
        html_out = render_webhook_deliveries_html(
            deliveries=deliveries,
            webhook_id="wh_xyz",
            webhook={"name": "Partner sync", "url": "https://partner.example.com/hook"},
        )
        # Header
        assert "Partner sync" in html_out
        # Stats
        assert "25 TOTAL" in html_out
        # No legacy patterns
        assert "border-top:3px solid" not in html_out
        # Primary purple present
        assert "#7d2df3" in html_out
        # Text fallback parity
        text = render_webhook_deliveries_text_fallback(
            deliveries=deliveries,
            webhook_id="wh_xyz",
            webhook={"name": "Partner sync"},
        )
        assert "Partner sync" in text
        assert "Total deliveries: 25" in text
