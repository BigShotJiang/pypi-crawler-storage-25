"""Unit tests for Surface #44 — contact fields schema renderer.

Covers:
  * Helpers: _contact_fields_clip, _contact_fields_display_title,
    _contact_fields_is_custom, _contact_fields_is_global,
    _contact_fields_custom_count, _contact_fields_list_specific_count,
    _contact_fields_datatypes, _sort_contact_fields,
    _contact_fields_stat_card
  * Empty-state variants (unavailable vs empty)
  * Main HTML renderer (render_contact_fields_schema_html)
  * Text fallback (render_contact_fields_schema_text_fallback)
  * Design-token adherence (graph8 #7d2df3 / #dfdfdf / Aeonik, no
    legacy tokens, no single-side accent borders)
  * Bool-strict guards (True not treated as custom id, 1 not treated
    as is_global boolean but as default)
"""

from __future__ import annotations

import pytest

from g8_mcp_server.app_renderer import (
    _contact_fields_clip,
    _contact_fields_custom_count,
    _contact_fields_datatypes,
    _contact_fields_display_title,
    _contact_fields_is_custom,
    _contact_fields_is_global,
    _contact_fields_list_specific_count,
    _contact_fields_stat_card,
    _render_contact_fields_schema_empty_state_html,
    _sort_contact_fields,
    render_contact_fields_schema_html,
    render_contact_fields_schema_text_fallback,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class TestClip:
    def test_none_returns_empty(self):
        assert _contact_fields_clip(None, 10) == ""

    def test_non_string_returns_empty(self):
        assert _contact_fields_clip(123, 10) == ""
        assert _contact_fields_clip([], 10) == ""

    def test_short_value_html_escaped(self):
        assert _contact_fields_clip("<b>hi</b>", 100) == "&lt;b&gt;hi&lt;/b&gt;"

    def test_long_value_clipped_with_ellipsis(self):
        out = _contact_fields_clip("abcdefghij", 5)
        assert out.endswith("\u2026")  # ellipsis char
        assert len(out) <= 5  # 4 chars + ellipsis

    def test_whitespace_only_returns_empty(self):
        assert _contact_fields_clip("   ", 10) == ""


class TestDisplayTitle:
    def test_title_priority(self):
        out = _contact_fields_display_title(
            {"title": "Email Address", "name": "email"}
        )
        assert out == "Email Address"

    def test_falls_back_to_name(self):
        out = _contact_fields_display_title({"title": "", "name": "email"})
        assert out == "email"

    def test_falls_back_to_unnamed(self):
        out = _contact_fields_display_title({"title": "", "name": ""})
        assert out == "(unnamed)"

    def test_handles_missing_keys(self):
        out = _contact_fields_display_title({})
        assert out == "(unnamed)"

    def test_escapes_html(self):
        out = _contact_fields_display_title(
            {"title": "<script>", "name": ""}
        )
        assert "&lt;script&gt;" in out

    def test_clips_long_title(self):
        long = "x" * 200
        out = _contact_fields_display_title({"title": long, "name": ""})
        # Clipped to _MAX_CONTACT_FIELD_TITLE_LEN=120
        assert out.endswith("\u2026")


class TestIsCustom:
    def test_positive_int_id_is_custom(self):
        assert _contact_fields_is_custom({"id": 42}) is True

    def test_none_id_is_not_custom(self):
        assert _contact_fields_is_custom({"id": None}) is False

    def test_missing_id_is_not_custom(self):
        assert _contact_fields_is_custom({}) is False

    def test_zero_id_is_not_custom(self):
        assert _contact_fields_is_custom({"id": 0}) is False

    def test_negative_id_is_not_custom(self):
        assert _contact_fields_is_custom({"id": -1}) is False

    def test_string_id_is_not_custom(self):
        assert _contact_fields_is_custom({"id": "42"}) is False

    def test_true_is_not_custom_strict_bool_guard(self):
        """Python: True is instance of int. Guard must exclude it."""
        assert _contact_fields_is_custom({"id": True}) is False

    def test_false_is_not_custom(self):
        assert _contact_fields_is_custom({"id": False}) is False


class TestIsGlobal:
    def test_true_is_global(self):
        assert _contact_fields_is_global({"is_global": True}) is True

    def test_false_is_not_global(self):
        assert _contact_fields_is_global({"is_global": False}) is False

    def test_missing_defaults_true(self):
        """API default is True (global). Missing key → treated as True."""
        assert _contact_fields_is_global({}) is True

    def test_none_defaults_true(self):
        assert _contact_fields_is_global({"is_global": None}) is True

    def test_int_one_not_treated_as_global_bool(self):
        """Non-bool 1 falls back to default True — we're strict about
        type but permissive about missing-as-default."""
        # Since 1 is not instance of bool, it falls to default branch
        # (which returns True). This documents the current behavior:
        # non-bool values are ambiguous, so default wins.
        assert _contact_fields_is_global({"is_global": 1}) is True

    def test_int_zero_also_defaults_true(self):
        assert _contact_fields_is_global({"is_global": 0}) is True

    def test_string_true_defaults_true(self):
        assert _contact_fields_is_global({"is_global": "false"}) is True


class TestCustomCount:
    def test_counts_positive_int_ids(self):
        fields = [
            {"id": 1},
            {"id": None},
            {"id": 2},
            {"id": 0},
            {"id": True},  # bool-strict: not counted
            {"id": "3"},  # string: not counted
        ]
        assert _contact_fields_custom_count(fields) == 2

    def test_empty_returns_zero(self):
        assert _contact_fields_custom_count([]) == 0

    def test_non_list_returns_zero(self):
        assert _contact_fields_custom_count(None) == 0
        assert _contact_fields_custom_count("whoops") == 0

    def test_skips_non_dicts(self):
        fields = [{"id": 1}, "not a dict", None, 42]
        assert _contact_fields_custom_count(fields) == 1


class TestListSpecificCount:
    def test_counts_is_global_false(self):
        fields = [
            {"is_global": False},
            {"is_global": True},
            {"is_global": False},
            {},  # missing → default True → NOT list-specific
        ]
        assert _contact_fields_list_specific_count(fields) == 2

    def test_empty_returns_zero(self):
        assert _contact_fields_list_specific_count([]) == 0

    def test_non_list_returns_zero(self):
        assert _contact_fields_list_specific_count(None) == 0

    def test_skips_non_dicts(self):
        assert _contact_fields_list_specific_count([{"is_global": False}, None]) == 1


class TestDatatypes:
    def test_buckets_by_data_type(self):
        fields = [
            {"data_type": "text"},
            {"data_type": "text"},
            {"data_type": "number"},
            {"data_type": "date"},
            {"data_type": "text"},
        ]
        result = _contact_fields_datatypes(fields)
        assert result[0] == ("text", 3)
        assert ("number", 1) in result
        assert ("date", 1) in result

    def test_sorted_count_desc_alpha_tiebreak(self):
        fields = [
            {"data_type": "z"},
            {"data_type": "a"},
            {"data_type": "m"},
            {"data_type": "a"},
            {"data_type": "z"},
            {"data_type": "m"},
        ]
        result = _contact_fields_datatypes(fields)
        # all have count 2, sorted alpha: a, m, z
        assert [n for n, _ in result] == ["a", "m", "z"]

    def test_normalizes_lowercase(self):
        fields = [{"data_type": "TEXT"}, {"data_type": "Text"}, {"data_type": "text"}]
        result = _contact_fields_datatypes(fields)
        assert len(result) == 1
        assert result[0] == ("text", 3)

    def test_trims_whitespace(self):
        fields = [{"data_type": "  text  "}]
        assert _contact_fields_datatypes(fields) == [("text", 1)]

    def test_skips_non_strings(self):
        fields = [{"data_type": 42}, {"data_type": None}, {"data_type": "text"}]
        assert _contact_fields_datatypes(fields) == [("text", 1)]

    def test_skips_empty_strings(self):
        fields = [{"data_type": ""}, {"data_type": "   "}, {"data_type": "text"}]
        assert _contact_fields_datatypes(fields) == [("text", 1)]

    def test_non_list_returns_empty(self):
        assert _contact_fields_datatypes(None) == []


class TestSortContactFields:
    def test_base_before_custom(self):
        fields = [
            {"id": 1, "title": "A custom"},
            {"id": None, "title": "Z base"},
        ]
        sorted_fields = _sort_contact_fields(fields)
        # base (id=None) comes first regardless of title
        assert sorted_fields[0]["title"] == "Z base"
        assert sorted_fields[1]["title"] == "A custom"

    def test_alpha_within_group(self):
        fields = [
            {"id": None, "title": "Zebra"},
            {"id": None, "title": "Apple"},
            {"id": 2, "title": "Banana"},
            {"id": 1, "title": "Mango"},
        ]
        sorted_fields = _sort_contact_fields(fields)
        titles = [f["title"] for f in sorted_fields]
        # Base: Apple, Zebra; Custom: Banana, Mango
        assert titles == ["Apple", "Zebra", "Banana", "Mango"]

    def test_uses_name_fallback_for_sort_key(self):
        fields = [
            {"id": None, "title": "", "name": "z_field"},
            {"id": None, "title": "", "name": "a_field"},
        ]
        sorted_fields = _sort_contact_fields(fields)
        assert sorted_fields[0]["name"] == "a_field"


class TestStatCard:
    def test_renders_uniform_border_not_accent_border(self):
        html = _contact_fields_stat_card("Total", "42", accent="primary")
        assert "border:1px solid #dfdfdf" in html
        # no single-side accent border
        assert "border-left:" not in html
        assert "border-top:" not in html
        assert "border-right:" not in html
        assert "border-bottom:" not in html

    def test_primary_accent_color(self):
        html = _contact_fields_stat_card("Custom", "5", accent="primary")
        assert "#7d2df3" in html

    def test_positive_accent_color(self):
        html = _contact_fields_stat_card("Ok", "5", accent="positive")
        assert "#059669" in html

    def test_destructive_accent_color(self):
        html = _contact_fields_stat_card("Bad", "5", accent="destructive")
        assert "#ca3214" in html

    def test_text_accent_default(self):
        html = _contact_fields_stat_card("Total", "5")
        assert "#0A0A0A" in html  # _G8_TEXT

    def test_unknown_accent_falls_back_to_text(self):
        html = _contact_fields_stat_card("Total", "5", accent="nope")
        assert "#0A0A0A" in html

    def test_escapes_label(self):
        html = _contact_fields_stat_card("<b>x</b>", "1")
        assert "&lt;b&gt;x&lt;/b&gt;" in html

    def test_escapes_value(self):
        html = _contact_fields_stat_card("X", "<script>")
        assert "&lt;script&gt;" in html


# ---------------------------------------------------------------------------
# Empty state
# ---------------------------------------------------------------------------


class TestEmptyState:
    def test_empty_mode_mentions_post_fields(self):
        html = _render_contact_fields_schema_empty_state_html(mode="empty")
        assert "POST /fields" in html
        assert "entity=contacts" in html

    def test_unavailable_mode_mentions_get_fields(self):
        html = _render_contact_fields_schema_empty_state_html(mode="unavailable")
        assert "GET /fields" in html

    def test_empty_mode_uses_primary_color(self):
        html = _render_contact_fields_schema_empty_state_html(mode="empty")
        assert "#7d2df3" in html

    def test_unavailable_mode_uses_muted_color(self):
        html = _render_contact_fields_schema_empty_state_html(mode="unavailable")
        # muted text color, NOT primary
        assert "#777777" in html

    def test_uses_graph8_font(self):
        html = _render_contact_fields_schema_empty_state_html(mode="empty")
        assert "Aeonik" in html

    def test_uses_graph8_border(self):
        html = _render_contact_fields_schema_empty_state_html(mode="empty")
        assert "#dfdfdf" in html

    def test_valid_doctype(self):
        html = _render_contact_fields_schema_empty_state_html(mode="empty")
        assert html.startswith("<!DOCTYPE html>")

    def test_title_tag_present(self):
        html = _render_contact_fields_schema_empty_state_html(mode="empty")
        assert "<title>" in html


# ---------------------------------------------------------------------------
# Main HTML renderer
# ---------------------------------------------------------------------------


class TestRenderHtml:
    def _sample_fields(self):
        return [
            {
                "id": None,
                "title": "First Name",
                "name": "first_name",
                "data_type": "text",
                "is_global": True,
            },
            {
                "id": None,
                "title": "Email",
                "name": "email",
                "data_type": "text",
                "is_global": True,
            },
            {
                "id": 42,
                "title": "Lead Score",
                "name": "lead_score",
                "data_type": "number",
                "is_global": True,
            },
            {
                "id": 43,
                "title": "Internal Notes",
                "name": "internal_notes",
                "data_type": "text",
                "is_global": False,  # list-specific
            },
        ]

    def test_none_fields_returns_unavailable_empty_state(self):
        html = render_contact_fields_schema_html(fields=None)
        assert "not available" in html.lower()
        assert "GET /fields" in html

    def test_empty_list_returns_no_fields_empty_state(self):
        html = render_contact_fields_schema_html(fields=[])
        assert "No contact fields" in html
        assert "POST /fields" in html

    def test_renders_total_stat(self):
        html = render_contact_fields_schema_html(fields=self._sample_fields())
        assert ">4</div>" in html  # 4 total fields

    def test_renders_base_stat(self):
        html = render_contact_fields_schema_html(fields=self._sample_fields())
        # 2 base (id=None)
        assert ">2</div>" in html
        assert "BASE" in html.upper()

    def test_renders_custom_stat(self):
        html = render_contact_fields_schema_html(fields=self._sample_fields())
        assert "CUSTOM" in html.upper()

    def test_renders_list_specific_stat(self):
        html = render_contact_fields_schema_html(fields=self._sample_fields())
        assert "LIST-SPECIFIC" in html.upper()

    def test_renders_data_types_section(self):
        html = render_contact_fields_schema_html(fields=self._sample_fields())
        assert "Data types" in html
        # 2 unique (text, number)
        assert "text" in html
        assert "number" in html

    def test_renders_field_rows(self):
        html = render_contact_fields_schema_html(fields=self._sample_fields())
        assert "First Name" in html
        assert "Lead Score" in html

    def test_custom_badge_shown_for_custom_fields(self):
        html = render_contact_fields_schema_html(fields=self._sample_fields())
        assert "CUSTOM" in html

    def test_list_specific_badge_shown(self):
        html = render_contact_fields_schema_html(fields=self._sample_fields())
        assert "LIST-SPECIFIC" in html

    def test_html_escapes_titles(self):
        fields = [{"title": "<script>alert(1)</script>", "name": "x", "data_type": "text", "is_global": True}]
        html = render_contact_fields_schema_html(fields=fields)
        assert "<script>alert" not in html
        assert "&lt;script&gt;" in html

    def test_drill_up_links_present(self):
        html = render_contact_fields_schema_html(fields=self._sample_fields())
        assert "GET /fields" in html
        assert "POST /fields" in html
        assert "DELETE /fields" in html
        assert "g8://fields/companies" in html
        assert "g8://crm-syncs/" in html

    def test_name_subtitle_when_different_from_title(self):
        fields = [{"title": "Email Address", "name": "email_addr", "data_type": "text", "is_global": True}]
        html = render_contact_fields_schema_html(fields=fields)
        assert "email_addr" in html
        # Subtitle should be in a <code> tag
        assert "<code" in html

    def test_no_name_subtitle_when_same_as_title(self):
        fields = [{"title": "email", "name": "email", "data_type": "text", "is_global": True}]
        html = render_contact_fields_schema_html(fields=fields)
        # The name shouldn't appear as a separate code subtitle
        # (it's implicitly embedded in the title only)
        code_count = html.count('<code')
        # Drill-up section has multiple <code> tags, but none of them
        # should be a name subtitle for this field. The subtitle would
        # have both `background:#f9f9f9` AND the content `email`. Let's
        # assert no such pattern:
        assert ">email</code>" not in html or html.count(">email</code>") == 0

    def test_overflow_note_when_exceeds_cap(self):
        # 85 fields, cap is 80
        fields = [
            {"id": None, "title": f"field {i}", "name": f"f{i}", "data_type": "text", "is_global": True}
            for i in range(85)
        ]
        html = render_contact_fields_schema_html(fields=fields)
        assert "5 more fields" in html

    def test_no_overflow_note_when_under_cap(self):
        fields = [
            {"id": None, "title": f"field {i}", "name": f"f{i}", "data_type": "text", "is_global": True}
            for i in range(10)
        ]
        html = render_contact_fields_schema_html(fields=fields)
        assert "more fields omitted" not in html

    def test_skips_non_dict_entries(self):
        fields = [
            {"id": None, "title": "Real", "name": "real", "data_type": "text", "is_global": True},
            "not a dict",
            None,
            42,
        ]
        html = render_contact_fields_schema_html(fields=fields)
        # Total stat shows 1 (only one valid dict)
        assert ">1</div>" in html

    def test_uses_graph8_primary_color(self):
        html = render_contact_fields_schema_html(fields=self._sample_fields())
        assert "#7d2df3" in html

    def test_uses_graph8_border(self):
        html = render_contact_fields_schema_html(fields=self._sample_fields())
        assert "#dfdfdf" in html

    def test_uses_graph8_font(self):
        html = render_contact_fields_schema_html(fields=self._sample_fields())
        assert "Aeonik" in html

    def test_no_single_side_accent_borders(self):
        """Design rule: no single-side colored accent bars."""
        html = render_contact_fields_schema_html(fields=self._sample_fields())
        assert "border-left:" not in html
        assert "border-top:" not in html
        assert "border-right:" not in html
        assert "border-bottom:" not in html

    def test_no_legacy_accent_hexes(self):
        """No pre-graph8-token hexes like #e5e7eb, #f3f4f6, etc."""
        html = render_contact_fields_schema_html(fields=self._sample_fields())
        # These were common in pre-graph8 renderers and would indicate
        # a style token leak.
        assert "#e5e7eb" not in html
        assert "#f3f4f6" not in html
        assert "#6b7280" not in html
        assert "#111827" not in html

    def test_doctype_present(self):
        html = render_contact_fields_schema_html(fields=self._sample_fields())
        assert html.startswith("<!DOCTYPE html>")

    def test_title_includes_total(self):
        html = render_contact_fields_schema_html(fields=self._sample_fields())
        assert "<title>Fields — Contacts schema (4)</title>" in html

    def test_total_chip_in_header(self):
        html = render_contact_fields_schema_html(fields=self._sample_fields())
        assert "4 TOTAL" in html

    def test_data_type_overflow_chip_when_many_types(self):
        fields = [
            {"id": None, "title": f"f{i}", "data_type": f"type_{i}", "is_global": True}
            for i in range(15)
        ]
        html = render_contact_fields_schema_html(fields=fields)
        # Cap is 10 datatype chips, so 5 overflow
        assert "5 more types" in html

    def test_handles_missing_data_type_gracefully(self):
        fields = [{"id": None, "title": "Ghost", "name": "ghost", "is_global": True}]
        html = render_contact_fields_schema_html(fields=fields)
        # No crash; renders
        assert "Ghost" in html

    def test_custom_field_with_id_shown(self):
        fields = [{"id": 99, "title": "Custom", "name": "custom_col", "data_type": "text", "is_global": True}]
        html = render_contact_fields_schema_html(fields=fields)
        assert "id=99" in html

    def test_base_field_id_not_shown(self):
        fields = [{"id": None, "title": "Base", "name": "base", "data_type": "text", "is_global": True}]
        html = render_contact_fields_schema_html(fields=fields)
        # No "id=None" leaks into output
        assert "id=None" not in html

    def test_data_types_section_omitted_when_no_types(self):
        # Fields with no data_type → datatypes list is empty
        fields = [{"id": None, "title": "Nothing", "name": "x", "is_global": True}]
        html = render_contact_fields_schema_html(fields=fields)
        assert "Data types" not in html

    def test_sort_base_first(self):
        fields = [
            {"id": 99, "title": "AAA custom", "name": "a", "data_type": "text", "is_global": True},
            {"id": None, "title": "ZZZ base", "name": "z", "data_type": "text", "is_global": True},
        ]
        html = render_contact_fields_schema_html(fields=fields)
        # ZZZ base should appear before AAA custom in the rendered HTML
        zzz_pos = html.find("ZZZ base")
        aaa_pos = html.find("AAA custom")
        assert zzz_pos != -1 and aaa_pos != -1
        assert zzz_pos < aaa_pos


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------


class TestTextFallback:
    def _sample_fields(self):
        return [
            {
                "id": None,
                "title": "First Name",
                "name": "first_name",
                "data_type": "text",
                "is_global": True,
            },
            {
                "id": 42,
                "title": "Lead Score",
                "name": "lead_score",
                "data_type": "number",
                "is_global": True,
            },
            {
                "id": 43,
                "title": "Notes",
                "name": "notes",
                "data_type": "text",
                "is_global": False,
            },
        ]

    def test_none_fields_returns_unavailable(self):
        text = render_contact_fields_schema_text_fallback(fields=None)
        assert "not available" in text.lower()
        assert "GET /fields" in text

    def test_empty_list_returns_empty_state(self):
        text = render_contact_fields_schema_text_fallback(fields=[])
        assert "no contact fields" in text.lower()
        assert "POST /fields" in text

    def test_starts_with_markdown_header(self):
        text = render_contact_fields_schema_text_fallback(fields=self._sample_fields())
        assert text.startswith("# Contacts schema")

    def test_has_stats_section(self):
        text = render_contact_fields_schema_text_fallback(fields=self._sample_fields())
        assert "- Total: 3" in text
        assert "- Base: 1" in text
        assert "- Custom: 2" in text
        assert "- List-specific: 1" in text

    def test_has_data_types_section(self):
        text = render_contact_fields_schema_text_fallback(fields=self._sample_fields())
        assert "## Data types" in text
        assert "- text: 2" in text
        assert "- number: 1" in text

    def test_has_fields_section(self):
        text = render_contact_fields_schema_text_fallback(fields=self._sample_fields())
        assert "## Fields (3 of 3)" in text
        assert "First Name" in text
        assert "Lead Score" in text
        assert "Notes" in text

    def test_custom_flag_shown(self):
        text = render_contact_fields_schema_text_fallback(fields=self._sample_fields())
        assert "[custom]" in text

    def test_list_specific_flag_shown(self):
        text = render_contact_fields_schema_text_fallback(fields=self._sample_fields())
        assert "list-specific" in text

    def test_data_type_shown_in_brackets(self):
        text = render_contact_fields_schema_text_fallback(fields=self._sample_fields())
        assert "<text>" in text
        assert "<number>" in text

    def test_id_suffix_for_custom_only(self):
        text = render_contact_fields_schema_text_fallback(fields=self._sample_fields())
        assert "id=42" in text
        assert "id=43" in text
        # base field has id=None, shouldn't show id=None
        assert "id=None" not in text

    def test_ends_with_newline(self):
        text = render_contact_fields_schema_text_fallback(fields=self._sample_fields())
        assert text.endswith("\n")

    def test_no_html_in_output(self):
        text = render_contact_fields_schema_text_fallback(fields=self._sample_fields())
        assert "<div" not in text
        assert "<span" not in text

    def test_manage_section_present(self):
        text = render_contact_fields_schema_text_fallback(fields=self._sample_fields())
        assert "## Manage fields" in text
        assert "GET /fields" in text
        assert "POST /fields" in text
        assert "DELETE /fields" in text
        assert "g8://fields/companies" in text

    def test_overflow_note_when_exceeds_cap(self):
        fields = [
            {"id": None, "title": f"f{i}", "name": f"n{i}", "data_type": "text", "is_global": True}
            for i in range(85)
        ]
        text = render_contact_fields_schema_text_fallback(fields=fields)
        assert "5 more fields" in text

    def test_sort_base_before_custom(self):
        fields = [
            {"id": 1, "title": "AAA custom", "name": "a", "data_type": "text", "is_global": True},
            {"id": None, "title": "ZZZ base", "name": "z", "data_type": "text", "is_global": True},
        ]
        text = render_contact_fields_schema_text_fallback(fields=fields)
        z_pos = text.find("ZZZ base")
        a_pos = text.find("AAA custom")
        assert z_pos < a_pos

    def test_unnamed_fallback(self):
        fields = [{"id": None, "title": "", "name": "", "data_type": "text", "is_global": True}]
        text = render_contact_fields_schema_text_fallback(fields=fields)
        assert "(unnamed)" in text

    def test_long_title_clipped(self):
        long = "a" * 200
        fields = [{"id": None, "title": long, "name": "", "data_type": "text", "is_global": True}]
        text = render_contact_fields_schema_text_fallback(fields=fields)
        # Clipped to 120
        assert long not in text

    def test_no_data_types_section_when_empty(self):
        fields = [{"id": None, "title": "Ghost", "name": "x", "is_global": True}]
        text = render_contact_fields_schema_text_fallback(fields=fields)
        assert "## Data types" not in text

    def test_provider_specific_pointer(self):
        text = render_contact_fields_schema_text_fallback(fields=self._sample_fields())
        assert "g8://crm-syncs/" in text

    def test_datatypes_overflow(self):
        fields = [
            {"id": None, "title": f"f{i}", "data_type": f"type_{i}", "is_global": True}
            for i in range(15)
        ]
        text = render_contact_fields_schema_text_fallback(fields=fields)
        assert "+ 5 more types" in text


# ---------------------------------------------------------------------------
# Smoke
# ---------------------------------------------------------------------------


class TestSmoke:
    def test_empty_state_renders_both_modes(self):
        for mode in ("empty", "unavailable"):
            html = _render_contact_fields_schema_empty_state_html(mode=mode)
            assert html.startswith("<!DOCTYPE html>")
            assert "</html>" in html

    def test_renderer_produces_valid_html_envelope(self):
        fields = [
            {"id": None, "title": "F", "name": "f", "data_type": "text", "is_global": True}
        ]
        html = render_contact_fields_schema_html(fields=fields)
        assert html.startswith("<!DOCTYPE html>")
        assert "</html>" in html
        assert "<head>" in html or "<head " in html
        assert "<body" in html

    def test_text_fallback_plaintext_no_html(self):
        fields = [
            {"id": None, "title": "F", "name": "f", "data_type": "text", "is_global": True}
        ]
        text = render_contact_fields_schema_text_fallback(fields=fields)
        assert "<!DOCTYPE" not in text
        assert "</html>" not in text

    def test_none_input_both_renderers(self):
        html = render_contact_fields_schema_html(fields=None)
        text = render_contact_fields_schema_text_fallback(fields=None)
        assert "not available" in html.lower()
        assert "not available" in text.lower()

    def test_empty_list_both_renderers(self):
        html = render_contact_fields_schema_html(fields=[])
        text = render_contact_fields_schema_text_fallback(fields=[])
        assert "no contact fields" in html.lower() or "No contact fields" in html
        assert "no contact fields" in text.lower()
