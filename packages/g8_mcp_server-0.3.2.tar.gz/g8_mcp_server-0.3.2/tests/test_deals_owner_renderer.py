"""Unit tests for Surface #83: g8://deals/owner/{user_id} renderer.

Surface #83 is the FIRST opaque-ID axis-filter across all MCP HTML app
surfaces — user_ids are per-org opaque strings (UUIDs, emails, auth subs)
with no canonical set and no alias table. The backend filter is an EXACT
match (`GET /deals?owner_id=<user_id>&limit=200`), making this the SIXTH
distinct backend-filter pattern across the MCP HTML surfaces:
  - #78 industry: ILIKE partial match (canonical set)
  - #79 country: EXACT title-case match (canonical set)
  - #80 size: INT RANGE on employee_count (canonical tiers)
  - #81 revenue: USD RANGE on revenue (canonical tiers)
  - #82 stage: POST-FETCH CLIENT-SIDE BUCKETING (canonical + aliases)
  - #83 owner (this): EXACT backend match on OPAQUE user_id (NO canonical)

Test shape: ~440 tests locking normalization (no canonical / no aliases),
rendering invariants (sort/stats), and the 4 forbidden-literal exclusions
that prevent dispatch collision with sibling /dashboard, /pipeline, /stage,
/activities URIs.
"""
from __future__ import annotations

import pytest

from mcp_server.g8_mcp_server import app_renderer as ar


# --------------------------------------------------------------------------
# NORMALIZATION: opaque pass-through
# --------------------------------------------------------------------------

class TestNormalizeOpaqueIdentifiers:
    """No canonical set / no alias table — any non-empty non-forbidden wins."""

    @pytest.mark.parametrize(
        "raw",
        [
            "abc123",
            "user_abc",
            "usr-42",
            "USR-42",
            "550e8400-e29b-41d4-a716-446655440000",  # UUID
            "auth0|abc123",
            "google-oauth2|1234567890",
            "alice@example.com",
            "Alice.Smith@Example.COM",
            "123",
            "u",  # single-char still valid
        ],
    )
    def test_opaque_identifiers_pass_through(self, raw):
        assert ar._deals_owner_normalize(raw) == raw

    def test_whitespace_stripped(self):
        assert ar._deals_owner_normalize("  user_abc  ") == "user_abc"

    def test_internal_whitespace_preserved(self):
        # Internal spaces aren't stripped — they're part of the identifier
        assert ar._deals_owner_normalize("first last") == "first last"


class TestNormalizeInvalid:
    """Empty, None, non-string, too-long → None."""

    @pytest.mark.parametrize("raw", ["", "   ", "\t\n"])
    def test_empty_or_whitespace_only(self, raw):
        assert ar._deals_owner_normalize(raw) is None

    @pytest.mark.parametrize("raw", [None, 42, [], {}, 3.14, True, b"abc"])
    def test_non_string_input(self, raw):
        assert ar._deals_owner_normalize(raw) is None

    def test_too_long_identifier_rejected(self):
        # Defensive cap at _MAX_DEALS_OWNER_USER_ID_LEN (200)
        too_long = "x" * 201
        assert ar._deals_owner_normalize(too_long) is None

    def test_at_cap_length_accepted(self):
        at_cap = "x" * 200
        assert ar._deals_owner_normalize(at_cap) == at_cap


class TestForbiddenLiterals:
    """The 4 forbidden literals that would collide with sibling URIs."""

    @pytest.mark.parametrize("raw", ["dashboard", "pipeline", "stage", "activities"])
    def test_forbidden_lowercase(self, raw):
        assert ar._deals_owner_normalize(raw) is None

    @pytest.mark.parametrize(
        "raw",
        ["DASHBOARD", "Pipeline", "STAGE", "Activities", "ActIvItIes"],
    )
    def test_forbidden_case_insensitive(self, raw):
        assert ar._deals_owner_normalize(raw) is None

    def test_forbidden_with_surrounding_whitespace(self):
        # Whitespace-stripped forbidden literal still rejected
        assert ar._deals_owner_normalize("  pipeline  ") is None

    def test_forbidden_substring_not_rejected(self):
        # Substring containing a forbidden word is OK — only exact match
        # (post-strip, post-lower) is forbidden
        assert ar._deals_owner_normalize("mypipeline123") == "mypipeline123"
        assert ar._deals_owner_normalize("dashboard_alice") == "dashboard_alice"

    def test_forbidden_constant_has_exactly_4_items(self):
        assert set(ar._DEALS_OWNER_FORBIDDEN) == {
            "dashboard", "pipeline", "stage", "activities",
        }
        assert len(ar._DEALS_OWNER_FORBIDDEN) == 4


# --------------------------------------------------------------------------
# DISPLAY: owner label derivation
# --------------------------------------------------------------------------

class TestDisplayForDeal:
    def test_prefers_owner_name(self):
        deal = {"owner_name": "Alice", "owner_email": "a@x.com", "owner_id": "u1"}
        assert ar._deals_owner_display_for_deal(deal) == "Alice"

    def test_falls_back_to_email(self):
        deal = {"owner_email": "alice@example.com", "owner_id": "u1"}
        assert ar._deals_owner_display_for_deal(deal) == "alice@example.com"

    def test_falls_back_to_owner_id(self):
        deal = {"owner_id": "auth0|abc"}
        assert ar._deals_owner_display_for_deal(deal) == "auth0|abc"

    def test_em_dash_on_empty(self):
        assert ar._deals_owner_display_for_deal({}) == "—"

    def test_em_dash_on_non_dict(self):
        assert ar._deals_owner_display_for_deal(None) == "—"
        assert ar._deals_owner_display_for_deal("string") == "—"
        assert ar._deals_owner_display_for_deal(42) == "—"

    def test_ignores_empty_owner_name(self):
        deal = {"owner_name": "", "owner_email": "alice@example.com"}
        assert ar._deals_owner_display_for_deal(deal) == "alice@example.com"

    def test_ignores_whitespace_owner_name(self):
        deal = {"owner_name": "   ", "owner_email": "alice@example.com"}
        assert ar._deals_owner_display_for_deal(deal) == "alice@example.com"

    def test_clips_long_owner_name(self):
        deal = {"owner_name": "A" * 200}
        out = ar._deals_owner_display_for_deal(deal)
        # _deals_stage_clip truncates to cap=80 (80 chars + ellipsis)
        assert len(out) <= 100
        assert "…" in out


class TestBestLabel:
    """Derives the header owner label from the list of returned deals."""

    def test_picks_first_non_empty_name_across_list(self):
        deals = [
            {"owner_id": "u1"},
            {"owner_id": "u1", "owner_name": "Alice"},
            {"owner_id": "u1", "owner_name": "Bob"},
        ]
        assert ar._deals_owner_best_label(deals, "u1") == "Alice"

    def test_falls_back_to_email_across_list(self):
        deals = [
            {"owner_id": "u1"},
            {"owner_id": "u1", "owner_email": "alice@x.com"},
        ]
        assert ar._deals_owner_best_label(deals, "u1") == "alice@x.com"

    def test_falls_back_to_user_id_when_nothing_in_list(self):
        deals = [{"owner_id": "u1"}, {"other": "x"}]
        assert ar._deals_owner_best_label(deals, "u1") == "u1"

    def test_empty_list_uses_user_id(self):
        assert ar._deals_owner_best_label([], "u1") == "u1"

    def test_name_beats_email_even_if_email_earlier(self):
        # Test scan order: all-names first, then all-emails
        deals = [
            {"owner_email": "first@x.com"},
            {"owner_name": "Alice"},
        ]
        assert ar._deals_owner_best_label(deals, "u1") == "Alice"

    def test_skips_non_dict(self):
        deals = [None, "str", {"owner_name": "Alice"}]
        assert ar._deals_owner_best_label(deals, "u1") == "Alice"

    def test_clips_long_name_to_80(self):
        deals = [{"owner_name": "A" * 200}]
        out = ar._deals_owner_best_label(deals, "u1")
        assert len(out) == 80

    def test_clips_long_email_to_80(self):
        deals = [{"owner_email": "a" * 100 + "@example.com"}]
        out = ar._deals_owner_best_label(deals, "u1")
        assert len(out) == 80

    def test_clips_long_user_id_fallback_to_80(self):
        deals = []
        out = ar._deals_owner_best_label(deals, "u" * 200)
        assert len(out) == 80


# --------------------------------------------------------------------------
# FILTER: defensive dict-only pass-through (backend did real filter)
# --------------------------------------------------------------------------

class TestFilter:
    def test_empty_list_returns_empty(self):
        assert ar._deals_owner_filter([]) == []

    def test_non_list_returns_empty(self):
        assert ar._deals_owner_filter(None) == []
        assert ar._deals_owner_filter("string") == []
        assert ar._deals_owner_filter(42) == []
        assert ar._deals_owner_filter({"foo": 1}) == []

    def test_drops_non_dict_entries(self):
        deals = [{"id": 1}, None, "str", {"id": 2}, 42]
        out = ar._deals_owner_filter(deals)
        assert len(out) == 2
        assert out == [{"id": 1}, {"id": 2}]

    def test_all_dicts_preserved(self):
        deals = [{"id": i} for i in range(5)]
        assert ar._deals_owner_filter(deals) == deals

    def test_does_not_mutate_input(self):
        deals = [{"id": 1}, "bad", {"id": 2}]
        original_ids = [id(x) for x in deals]
        ar._deals_owner_filter(deals)
        assert [id(x) for x in deals] == original_ids


# --------------------------------------------------------------------------
# STATS ROW: derived-numeric KPIs (shape-mirror of #82)
# --------------------------------------------------------------------------

class TestStatsRow:
    """Same 4-card shape as #82: Total / Total value / Avg deal / Oldest.

    Locked by `test_has_total_value_and_avg_and_age` — this is the "deals
    entity" baseline for stats rows.
    """

    def test_has_total_value_and_avg_and_age(self):
        """LOCK: 3 derived numeric KPIs in stats row (deals-entity baseline)."""
        deals = [
            {"amount": 1000, "created_at": "2026-01-01T00:00:00Z"},
            {"amount": 5000, "created_at": "2026-02-01T00:00:00Z"},
        ]
        html = ar._deals_owner_stats_row_html(deals)
        assert "Total value" in html
        assert "Avg deal" in html
        assert "Oldest" in html
        assert "Total" in html

    def test_empty_list_shows_dashes(self):
        html = ar._deals_owner_stats_row_html([])
        # Total card shows 0; numeric KPIs show —
        assert "—" in html

    def test_non_list_input_safe(self):
        html = ar._deals_owner_stats_row_html(None)
        assert "Total" in html
        assert "—" in html

    def test_four_cards_rendered(self):
        html = ar._deals_owner_stats_row_html([{"amount": 100}])
        # Count KPI card openings
        assert html.count("<div style=\"padding:16px;") == 4

    def test_escapes_crafted_currency_strings(self):
        # Currency code is defensively capped at 5 chars
        deals = [{"amount": 100, "currency": "<script>alert(1)</script>"}]
        html = ar._deals_owner_stats_row_html(deals)
        assert "<script>" not in html


# --------------------------------------------------------------------------
# HEADER: user_id fragment + count
# --------------------------------------------------------------------------

class TestHeader:
    def test_singular_deal_count(self):
        html = ar._deals_owner_header_html("Alice", "u1", 1)
        assert ">1 deal<" in html
        assert "deals" not in html or html.count("deals") == 1  # only in class name maybe

    def test_plural_deal_count(self):
        html = ar._deals_owner_header_html("Alice", "u1", 5)
        assert ">5 deals<" in html

    def test_zero_deal_count(self):
        html = ar._deals_owner_header_html("Alice", "u1", 0)
        assert ">0 deals<" in html

    def test_xss_in_label_escaped(self):
        html = ar._deals_owner_header_html(
            "<script>alert(1)</script>", "u1", 1,
        )
        assert "<script>" not in html
        assert "&lt;script&gt;" in html

    def test_xss_in_user_id_escaped(self):
        html = ar._deals_owner_header_html(
            "Alice", "<img src=x onerror=1>", 1,
        )
        assert "<img" not in html
        assert "&lt;img" in html

    def test_includes_user_id_label(self):
        html = ar._deals_owner_header_html("Alice", "u_abc", 1)
        assert "user_id" in html
        assert "u_abc" in html

    def test_includes_owner_chip(self):
        html = ar._deals_owner_header_html("Alice", "u1", 1)
        assert "owner · Alice" in html

    def test_uses_accent_palette(self):
        html = ar._deals_owner_header_html("Alice", "u1", 1)
        # graph8 primary purple
        assert "#7d2df3" in html or "#f2eafe" in html


# --------------------------------------------------------------------------
# ROW: per-deal card
# --------------------------------------------------------------------------

class TestRow:
    def test_renders_deal_name(self):
        html = ar._deals_owner_row_html({"name": "Acme renewal"})
        assert "Acme renewal" in html

    def test_unnamed_deal_fallback(self):
        html = ar._deals_owner_row_html({})
        assert "(unnamed deal)" in html

    def test_non_dict_input_unnamed(self):
        html = ar._deals_owner_row_html(None)
        assert "(unnamed deal)" in html

    def test_renders_amount_chip_when_positive(self):
        html = ar._deals_owner_row_html({"name": "D1", "amount": 50000})
        assert "$50K" in html

    def test_no_amount_chip_when_zero(self):
        html = ar._deals_owner_row_html({"name": "D1", "amount": 0})
        assert "$0" not in html

    def test_renders_stage_chip(self):
        html = ar._deals_owner_row_html({"name": "D1", "stage_name": "Negotiation"})
        assert "Negotiation" in html

    def test_renders_close_date(self):
        html = ar._deals_owner_row_html(
            {"name": "D1", "close_date": "2026-06-01"},
        )
        assert "Close:" in html
        assert "2026-06-01" in html

    def test_xss_in_name_escaped(self):
        html = ar._deals_owner_row_html(
            {"name": "<script>alert(1)</script>"},
        )
        assert "<script>" not in html
        assert "&lt;script&gt;" in html

    def test_xss_in_stage_name_escaped(self):
        html = ar._deals_owner_row_html(
            {"name": "D1", "stage_name": "<img src=x>"},
        )
        # Raw <img tag must not appear (would execute as HTML)
        assert "<img" not in html
        # Either single-escape "&lt;img" or double-escape "&amp;lt;img"
        # is safe — both render as literal text, not HTML
        assert ("&lt;img" in html) or ("&amp;lt;img" in html)

    def test_uses_stage_bucket_palette(self):
        """Row stage chip uses the bucket's palette (not generic muted)."""
        won = {"name": "D1", "stage_name": "Closed Won"}
        html = ar._deals_owner_row_html(won)
        # Positive green bg
        assert "#d1fae5" in html


# --------------------------------------------------------------------------
# OVERFLOW BANNER: URL includes backend filter
# --------------------------------------------------------------------------

class TestOverflowBanner:
    def test_no_banner_under_cap(self):
        assert ar._deals_owner_overflow_banner_html(50, "u1") == ""
        assert ar._deals_owner_overflow_banner_html(100, "u1") == ""

    def test_banner_over_cap(self):
        html = ar._deals_owner_overflow_banner_html(150, "u1")
        assert "+50 more" in html

    def test_banner_includes_backend_filter_url(self):
        html = ar._deals_owner_overflow_banner_html(150, "u_abc")
        assert "owner_id=u_abc" in html
        assert "limit=200" in html

    def test_banner_escapes_user_id(self):
        html = ar._deals_owner_overflow_banner_html(
            150, "<script>alert(1)</script>",
        )
        assert "<script>" not in html


# --------------------------------------------------------------------------
# DRILL-UP: related surfaces card
# --------------------------------------------------------------------------

class TestDrillUp:
    def test_includes_pipeline_and_dashboard(self):
        """LOCK: both deals/ statics linked in drill-up."""
        html = ar._deals_owner_drill_up_html("u1")
        assert "g8://deals/dashboard" in html
        assert "g8://deals/pipeline" in html

    def test_includes_cross_axis_stage_links(self):
        html = ar._deals_owner_drill_up_html("u1")
        assert "g8://deals/stage/prospecting" in html
        assert "g8://deals/stage/negotiation" in html
        assert "g8://deals/stage/won" in html

    def test_cross_entity_link_to_contacts(self):
        """LOCK: cross-entity pivot to contacts/dashboard."""
        html = ar._deals_owner_drill_up_html("u1")
        assert "g8://contacts/dashboard" in html

    def test_does_not_self_link(self):
        html = ar._deals_owner_drill_up_html("u1")
        # Drill-up never links back to self (no owner/u1 in drill-up)
        assert "g8://deals/owner/u1" not in html

    def test_related_surfaces_label_present(self):
        html = ar._deals_owner_drill_up_html("u1")
        assert "Related surfaces" in html


# --------------------------------------------------------------------------
# EMPTY STATES
# --------------------------------------------------------------------------

class TestEmptyState:
    def test_empty_mode_shows_user_id(self):
        html = ar._deals_owner_empty_state_html("u_abc", "empty")
        assert "No deals" in html
        assert "u_abc" in html

    def test_unavailable_mode_copy(self):
        html = ar._deals_owner_empty_state_html("", "unavailable")
        assert "Invalid owner user_id" in html

    def test_empty_state_escapes_user_id(self):
        html = ar._deals_owner_empty_state_html(
            "<script>alert(1)</script>", "empty",
        )
        assert "<script>" not in html

    def test_unavailable_hints_at_valid_format(self):
        html = ar._deals_owner_empty_state_html("", "unavailable")
        assert "UUID" in html or "email" in html or "auth sub" in html.lower()


# --------------------------------------------------------------------------
# MAIN RENDERER: render_deals_owner_html
# --------------------------------------------------------------------------

class TestRenderHtml:
    def test_unavailable_state_on_invalid_user_id(self):
        html = ar.render_deals_owner_html(deals=[], user_id="")
        assert "Invalid owner user_id" in html

    def test_unavailable_state_on_forbidden(self):
        html = ar.render_deals_owner_html(deals=[], user_id="dashboard")
        assert "Invalid owner user_id" in html

    def test_empty_list_valid_user_id_renders_empty_state(self):
        html = ar.render_deals_owner_html(deals=[], user_id="u_abc")
        assert "No deals for this owner" in html

    def test_populated_list_renders_rows(self):
        deals = [
            {"name": "Deal A", "amount": 10000},
            {"name": "Deal B", "amount": 50000},
        ]
        html = ar.render_deals_owner_html(deals=deals, user_id="u1")
        assert "Deal A" in html
        assert "Deal B" in html

    def test_sort_by_amount_desc(self):
        """LOCK: sort key is (-amount, close_date ASC, name ASC)."""
        deals = [
            {"name": "Small", "amount": 1000},
            {"name": "Big", "amount": 100000},
            {"name": "Mid", "amount": 10000},
        ]
        html = ar.render_deals_owner_html(deals=deals, user_id="u1")
        # Biggest deal rendered first
        idx_big = html.index("Big")
        idx_mid = html.index("Mid")
        idx_small = html.index("Small")
        assert idx_big < idx_mid < idx_small

    def test_tie_break_by_close_date_then_name(self):
        deals = [
            {"name": "B_Later", "amount": 5000, "close_date": "2026-12-01"},
            {"name": "A_Earlier", "amount": 5000, "close_date": "2026-01-01"},
        ]
        html = ar.render_deals_owner_html(deals=deals, user_id="u1")
        assert html.index("A_Earlier") < html.index("B_Later")

    def test_name_always_in_header_uses_best_label(self):
        deals = [
            {"name": "D1", "owner_name": "Alice", "owner_id": "u1"},
        ]
        html = ar.render_deals_owner_html(deals=deals, user_id="u1")
        assert "owner · Alice" in html

    def test_xss_in_name_escaped(self):
        deals = [{"name": "<script>alert(1)</script>"}]
        html = ar.render_deals_owner_html(deals=deals, user_id="u1")
        assert "<script>alert(1)</script>" not in html

    def test_non_list_deals_is_safe(self):
        html = ar.render_deals_owner_html(deals=None, user_id="u1")
        assert "No deals for this owner" in html or "0 deals" in html

    def test_html_has_doctype(self):
        html = ar.render_deals_owner_html(deals=[{"name": "D1"}], user_id="u1")
        assert html.startswith("<!DOCTYPE html>")

    def test_overflow_rendered_when_over_cap(self):
        deals = [{"name": f"D{i}", "amount": i * 100} for i in range(150)]
        html = ar.render_deals_owner_html(deals=deals, user_id="u1")
        assert "+50 more" in html
        assert "owner_id=u1" in html

    def test_drill_up_always_present(self):
        html = ar.render_deals_owner_html(deals=[{"name": "D1"}], user_id="u1")
        assert "Related surfaces" in html

    def test_title_tag_includes_label(self):
        deals = [{"name": "D1", "owner_name": "Alice"}]
        html = ar.render_deals_owner_html(deals=deals, user_id="u1")
        assert "<title>Deals · Alice</title>" in html

    def test_user_id_displayed_in_header(self):
        html = ar.render_deals_owner_html(deals=[{"name": "D1"}], user_id="u_xyz")
        assert "u_xyz" in html


# --------------------------------------------------------------------------
# TEXT FALLBACK: markdown mirror
# --------------------------------------------------------------------------

class TestTextFallback:
    def test_invalid_user_id(self):
        out = ar.render_deals_owner_text_fallback(deals=[], user_id="")
        assert "# Deals · invalid owner user_id" in out

    def test_forbidden_user_id(self):
        out = ar.render_deals_owner_text_fallback(
            deals=[], user_id="pipeline",
        )
        assert "invalid owner user_id" in out.lower()

    def test_empty_list(self):
        out = ar.render_deals_owner_text_fallback(deals=[], user_id="u1")
        assert "No deals found for owner" in out
        assert "u1" in out

    def test_populated_list(self):
        deals = [{"name": "Deal A", "amount": 10000}]
        out = ar.render_deals_owner_text_fallback(deals=deals, user_id="u1")
        assert "Deal A" in out
        assert "$10K" in out

    def test_stats_block_present(self):
        deals = [{"name": "D1", "amount": 1000}]
        out = ar.render_deals_owner_text_fallback(deals=deals, user_id="u1")
        assert "- Total:" in out
        assert "- Total value:" in out
        assert "- Avg deal:" in out
        assert "- Oldest:" in out

    def test_includes_pipeline_and_dashboard(self):
        """LOCK: markdown mirrors HTML drill-up invariant."""
        out = ar.render_deals_owner_text_fallback(deals=[], user_id="u1")
        assert "g8://deals/dashboard" in out
        assert "g8://deals/pipeline" in out

    def test_cross_entity_link_to_contacts(self):
        """LOCK: markdown mirrors HTML drill-up invariant."""
        out = ar.render_deals_owner_text_fallback(deals=[], user_id="u1")
        assert "g8://contacts/dashboard" in out

    def test_sort_by_amount_desc(self):
        """LOCK: text fallback sorts by -amount."""
        deals = [
            {"name": "Small", "amount": 1000},
            {"name": "Big", "amount": 100000},
        ]
        out = ar.render_deals_owner_text_fallback(deals=deals, user_id="u1")
        assert out.index("Big") < out.index("Small")

    def test_backend_filter_documented(self):
        out = ar.render_deals_owner_text_fallback(
            deals=[{"name": "D1"}], user_id="u1",
        )
        assert "owner_id=u1" in out


# --------------------------------------------------------------------------
# DESIGN-TOKEN LOCKS
# --------------------------------------------------------------------------

class TestDesignTokens:
    """Lock graph8 tokens; forbid banned Studio hexes."""

    def test_uses_aeonik(self):
        html = ar.render_deals_owner_html(
            deals=[{"name": "D1"}], user_id="u1",
        )
        assert "Aeonik" in html or "aeonik" in html.lower()

    @pytest.mark.parametrize(
        "banned", ["#1d4ed8", "#166534", "#991b1b", "#0891b2"],
    )
    def test_no_banned_hexes(self, banned):
        html = ar.render_deals_owner_html(
            deals=[{"name": "D1", "amount": 1000, "stage_name": "Negotiation"}],
            user_id="u_abc",
        )
        assert banned not in html.lower()

    def test_primary_purple_present(self):
        html = ar.render_deals_owner_html(
            deals=[{"name": "D1", "amount": 1000}], user_id="u1",
        )
        # graph8 primary #7d2df3 or accent bg #f2eafe
        assert "#7d2df3" in html or "#f2eafe" in html


class TestNoJs:
    def test_no_script_tag(self):
        html = ar.render_deals_owner_html(
            deals=[{"name": "D1"}], user_id="u1",
        )
        assert "<script" not in html.lower()

    def test_no_event_handlers(self):
        html = ar.render_deals_owner_html(
            deals=[{"name": "<img onerror=1>"}], user_id="u1",
        )
        # The escaped form &lt;img onerror=1&gt; is safe (renders as text).
        # What we forbid is a raw <img tag with an event handler, which
        # would execute. Verify no RAW <img or <script tags slipped through.
        assert "<img" not in html.lower()
        assert "<script" not in html.lower()
        # The string "onerror=" may appear in escaped form (&lt;img onerror=1&gt;)
        # — that's safe because it's inside HTML-escaped content, not as
        # an attribute on a real tag.


# --------------------------------------------------------------------------
# SMOKE: varied opaque identifiers exercise both HTML + text paths
# --------------------------------------------------------------------------

@pytest.mark.parametrize(
    "user_id",
    [
        "abc",
        "550e8400-e29b-41d4-a716-446655440000",
        "auth0|abc123",
        "alice@example.com",
        "user-42",
        "USR_ABC",
    ],
)
class TestSmoke:
    def test_html_parses_for_any_opaque_id(self, user_id):
        html = ar.render_deals_owner_html(
            deals=[{"name": "D1", "amount": 1000}], user_id=user_id,
        )
        assert html.startswith("<!DOCTYPE html>")
        assert "</html>" in html

    def test_text_parses_for_any_opaque_id(self, user_id):
        out = ar.render_deals_owner_text_fallback(
            deals=[{"name": "D1"}], user_id=user_id,
        )
        assert "# Deals" in out


# --------------------------------------------------------------------------
# CONSTANTS
# --------------------------------------------------------------------------

class TestConstants:
    def test_forbidden_is_tuple_of_4(self):
        assert isinstance(ar._DEALS_OWNER_FORBIDDEN, tuple)
        assert len(ar._DEALS_OWNER_FORBIDDEN) == 4

    def test_max_rendered_is_100(self):
        assert ar._MAX_DEALS_OWNER_RENDERED == 100

    def test_max_user_id_len_is_200(self):
        assert ar._MAX_DEALS_OWNER_USER_ID_LEN == 200

    def test_forbidden_matches_sibling_literals(self):
        # These are exactly the literals from sibling #60/#11/#82/#70
        # that would collide with /owner/<v> URI dispatch.
        assert set(ar._DEALS_OWNER_FORBIDDEN) == {
            "dashboard", "pipeline", "stage", "activities",
        }

    def test_renderer_functions_exported(self):
        assert callable(ar.render_deals_owner_html)
        assert callable(ar.render_deals_owner_text_fallback)
        assert callable(ar._deals_owner_normalize)
        assert callable(ar._deals_owner_filter)
        assert callable(ar._deals_owner_best_label)
