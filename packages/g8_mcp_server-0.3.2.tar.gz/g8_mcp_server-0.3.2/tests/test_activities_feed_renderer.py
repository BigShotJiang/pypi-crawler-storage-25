"""Tests for the activities feed HTML + text renderers (upgrade 4 — #10)."""

from __future__ import annotations

from g8_mcp_server import app_renderer
from g8_mcp_server.app_renderer import (
    _activity_context_label,
    _activity_date_bucket,
    _activity_type_color,
    _activity_type_icon,
    _group_activities_by_date,
    render_activities_feed_html,
    render_activities_feed_text_fallback,
)


def _activity(idx: int = 0, **overrides) -> dict:
    """Default activity dict matching `ActivityItem`."""
    base = {
        "id": f"act_{idx}",
        "activity_type": "note",
        "summary": f"Activity {idx}",
        "contact_id": 100 + idx,
        "company_id": None,
        "deal_id": None,
        "user_id": "user_abc",
        "occurred_at": "2026-04-15T12:00:00Z",
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class TestActivityTypeIcon:
    def test_known(self):
        assert _activity_type_icon("note") == "📝"
        assert _activity_type_icon("email") == "✉"
        assert _activity_type_icon("call") == "📞"
        assert _activity_type_icon("meeting") == "📅"
        assert _activity_type_icon("task") == "✓"

    def test_case_and_whitespace(self):
        assert _activity_type_icon("NOTE") == "📝"
        assert _activity_type_icon(" Call ") == "📞"

    def test_unknown_returns_bullet(self):
        assert _activity_type_icon("weird") == "•"
        assert _activity_type_icon(None) == "•"
        assert _activity_type_icon("") == "•"


class TestActivityTypeColor:
    def test_known(self):
        # Backported to graph8 tokens 2026-04-21
        assert _activity_type_color("note") == "#7d2df3"
        assert _activity_type_color("email") == "#7d2df3"  # _G8_PRIMARY
        assert _activity_type_color("call") == "#059669"  # _G8_POSITIVE_FG
        assert _activity_type_color("created") == "#059669"  # _G8_POSITIVE_FG

    def test_unknown(self):
        assert _activity_type_color("weird") == "#777777"
        assert _activity_type_color(None) == "#777777"

    def test_no_banned_hexes_in_type_palette(self):
        banned = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}
        from mcp_server.g8_mcp_server.app_renderer import _ACTIVITY_TYPE_COLORS
        for k, v in _ACTIVITY_TYPE_COLORS.items():
            assert v.lower() not in banned, f"type={k!r} hex={v!r} is banned"


class TestActivityDateBucket:
    def test_iso_timestamp(self):
        assert _activity_date_bucket("2026-04-15T12:00:00Z") == "2026-04-15"

    def test_date_only(self):
        assert _activity_date_bucket("2026-04-15") == "2026-04-15"

    def test_missing_returns_dash(self):
        assert _activity_date_bucket(None) == "—"
        assert _activity_date_bucket("") == "—"

    def test_malformed_returns_dash(self):
        # Doesn't match YYYY-MM-DD shape at pos 4 and 7
        assert _activity_date_bucket("2026/04/15T...") == "—"
        assert _activity_date_bucket("nonsense") == "—"


class TestGroupActivitiesByDate:
    def test_empty(self):
        assert _group_activities_by_date([]) == []

    def test_sorts_descending(self):
        acts = [
            _activity(idx=1, occurred_at="2026-04-10T10:00:00Z"),
            _activity(idx=2, occurred_at="2026-04-15T10:00:00Z"),
            _activity(idx=3, occurred_at="2026-04-12T10:00:00Z"),
        ]
        result = _group_activities_by_date(acts)
        keys = [k for k, _ in result]
        assert keys == ["2026-04-15", "2026-04-12", "2026-04-10"]

    def test_unknown_bucket_last(self):
        acts = [
            _activity(idx=1, occurred_at="2026-04-15T10:00:00Z"),
            _activity(idx=2, occurred_at=None),
            _activity(idx=3, occurred_at="2026-04-10T10:00:00Z"),
        ]
        result = _group_activities_by_date(acts)
        keys = [k for k, _ in result]
        # unknown/"—" comes last
        assert keys[-1] == "—"
        assert keys[:-1] == ["2026-04-15", "2026-04-10"]

    def test_multiple_on_same_day(self):
        acts = [
            _activity(idx=1, occurred_at="2026-04-15T10:00:00Z"),
            _activity(idx=2, occurred_at="2026-04-15T14:00:00Z"),
        ]
        result = _group_activities_by_date(acts)
        assert len(result) == 1
        assert result[0][0] == "2026-04-15"
        assert len(result[0][1]) == 2


class TestActivityContextLabel:
    def test_all_empty(self):
        assert _activity_context_label({}) == ""

    def test_contact_only(self):
        assert _activity_context_label({"contact_id": 42}) == "contact #42"

    def test_company_only(self):
        assert _activity_context_label({"company_id": 9}) == "company #9"

    def test_deal_only(self):
        assert _activity_context_label({"deal_id": "deal_abc"}) == "deal deal_abc"

    def test_all_three(self):
        out = _activity_context_label(
            {"contact_id": 1, "company_id": 2, "deal_id": "deal_x"}
        )
        assert "contact #1" in out
        assert "company #2" in out
        assert "deal deal_x" in out
        assert " · " in out

    def test_zero_or_negative_contact_ignored(self):
        # 0 and negative treated as missing
        assert _activity_context_label({"contact_id": 0}) == ""


# ---------------------------------------------------------------------------
# HTML renderer
# ---------------------------------------------------------------------------


class TestRenderActivitiesFeedHtml:
    def test_empty_state(self):
        html_out = render_activities_feed_html(activities=None)
        assert "No recent activity" in html_out

        html_out2 = render_activities_feed_html(activities=[])
        assert "No recent activity" in html_out2

    def test_non_list_input(self):
        html_out = render_activities_feed_html(activities="nope")  # type: ignore[arg-type]
        assert "No recent activity" in html_out

    def test_only_garbage_items(self):
        html_out = render_activities_feed_html(activities=[None, "x", 1])  # type: ignore[list-item]
        assert "No recent activity" in html_out

    def test_renders_activity(self):
        html_out = render_activities_feed_html(activities=[_activity()])
        assert "Activity 0" in html_out
        assert "note" in html_out
        assert "📝" in html_out
        assert "contact #100" in html_out

    def test_date_grouping(self):
        html_out = render_activities_feed_html(
            activities=[
                _activity(idx=1, occurred_at="2026-04-15T10:00:00Z"),
                _activity(idx=2, occurred_at="2026-04-14T10:00:00Z"),
            ]
        )
        assert "2026-04-15" in html_out
        assert "2026-04-14" in html_out

    def test_missing_summary_fallback(self):
        html_out = render_activities_feed_html(
            activities=[_activity(summary=None)]
        )
        assert "(no summary)" in html_out

    def test_org_label(self):
        html_out = render_activities_feed_html(
            activities=[_activity()], org_label="Acme"
        )
        assert "Acme" in html_out

    def test_newest_first_order(self):
        html_out = render_activities_feed_html(
            activities=[
                _activity(idx=1, summary="Old", occurred_at="2026-04-01T10:00:00Z"),
                _activity(idx=2, summary="Fresh", occurred_at="2026-04-20T10:00:00Z"),
                _activity(idx=3, summary="Middle", occurred_at="2026-04-10T10:00:00Z"),
            ]
        )
        fresh_pos = html_out.find("Fresh")
        middle_pos = html_out.find("Middle")
        old_pos = html_out.find("Old")
        assert fresh_pos < middle_pos < old_pos


class TestEscaping:
    def test_summary_escaped(self):
        html_out = render_activities_feed_html(
            activities=[_activity(summary="<script>evil()</script>")]
        )
        assert "<script>evil" not in html_out
        assert "&lt;script&gt;" in html_out

    def test_activity_type_escaped(self):
        html_out = render_activities_feed_html(
            activities=[_activity(activity_type="<xss>")]
        )
        assert "<xss>" not in html_out
        assert "&lt;xss&gt;" in html_out

    def test_deal_id_escaped(self):
        html_out = render_activities_feed_html(
            activities=[_activity(deal_id="<img>")]
        )
        assert "<img>" not in html_out


class TestBounds:
    def test_max_activities_rendered(self):
        # Make later indices newer so they pass the cap.
        acts = [
            _activity(idx=i, summary=f"A_{i}", occurred_at=f"2026-04-{(i % 30) + 1:02d}T10:00:00Z")
            for i in range(120)
        ]
        html_out = render_activities_feed_html(activities=acts)
        # Cap is 80, so some must be omitted.
        assert "omitted" in html_out

    def test_long_summary_truncated(self):
        html_out = render_activities_feed_html(
            activities=[_activity(summary="s" * 5000)]
        )
        assert "…" in html_out


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------


class TestActivitiesFeedTextFallback:
    def test_empty(self):
        out = render_activities_feed_text_fallback(activities=None)
        assert "No recent activity" in out

        out2 = render_activities_feed_text_fallback(activities=[])
        assert "No recent activity" in out2

    def test_non_list(self):
        out = render_activities_feed_text_fallback(activities="nope")  # type: ignore[arg-type]
        assert "No recent activity" in out

    def test_renders_key_fields(self):
        out = render_activities_feed_text_fallback(activities=[_activity()])
        assert "Activity 0" in out
        assert "[note]" in out
        assert "contact #100" in out

    def test_date_grouping(self):
        out = render_activities_feed_text_fallback(
            activities=[
                _activity(idx=1, occurred_at="2026-04-15T10:00:00Z"),
                _activity(idx=2, occurred_at="2026-04-14T10:00:00Z"),
            ]
        )
        assert "## 2026-04-15" in out
        assert "## 2026-04-14" in out

    def test_org_label(self):
        out = render_activities_feed_text_fallback(
            activities=[_activity()], org_label="Acme"
        )
        assert "# Activity Feed — Acme" in out

    def test_max_cap_footer(self):
        acts = [
            _activity(idx=i, occurred_at=f"2026-04-{(i % 30) + 1:02d}T10:00:00Z")
            for i in range(120)
        ]
        out = render_activities_feed_text_fallback(activities=acts)
        assert "more activity(ies)" in out

    def test_no_html_leak(self):
        out = render_activities_feed_text_fallback(
            activities=[_activity(summary="<tag>")]
        )
        assert "<html>" not in out
        assert "<body>" not in out


# ---------------------------------------------------------------------------
# Caps sanity
# ---------------------------------------------------------------------------


class TestCapsExist:
    def test_constants(self):
        assert app_renderer._MAX_ACTIVITIES_RENDERED >= 10
        assert app_renderer._MAX_ACTIVITY_SUMMARY_LEN >= 50
