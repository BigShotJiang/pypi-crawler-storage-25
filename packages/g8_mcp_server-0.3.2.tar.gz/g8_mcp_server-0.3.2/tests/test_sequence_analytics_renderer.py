"""Tests for sequence analytics HTML app surface (surface #23).

Surface #23 renders sequence performance analytics: overview stats,
per-step delivery / reply / bounce bars, first-step response rates
(24h/48h/7d), and a 20-day send timeline. Distinct from surface #2
(sequence preview — step structure) and surface #9 (sequences dashboard
— org list).

Coverage emphasises:
- Health badge classification thresholds (the derived-metric bit)
- Step-type palette aliases (email/phone/sms/linkedin/fallback)
- Percentage + count formatting edge cases
- Bar-width clamping (neg / >100 / None / garbage)
- Empty-state triggers (None / non-dict / zero-everything)
- Defensive handling of non-dict entries in lists
- HTML escape of user/org data
- Text fallback parity with markdown structure
"""

from g8_mcp_server.app_renderer import (
    _analytics_health_key,
    _analytics_step_type_palette,
    _format_analytics_count,
    _format_analytics_pct,
    _render_analytics_bar,
    render_sequence_analytics_html,
    render_sequence_analytics_text_fallback,
)


# ---------------------------------------------------------------------------
# Health key classifier
# ---------------------------------------------------------------------------


class TestAnalyticsHealthKey:
    def test_no_contacts_returns_no_data(self):
        assert _analytics_health_key(50.0, 0) == "no_data"

    def test_none_contacts_returns_no_data(self):
        assert _analytics_health_key(50.0, None) == "no_data"

    def test_negative_contacts_returns_no_data(self):
        # Defensive: never treat garbage as positive data.
        assert _analytics_health_key(50.0, -1) == "no_data"

    def test_excellent_threshold(self):
        assert _analytics_health_key(30.0, 100) == "excellent"
        assert _analytics_health_key(95.0, 100) == "excellent"

    def test_good_threshold(self):
        assert _analytics_health_key(15.0, 100) == "good"
        assert _analytics_health_key(29.9, 100) == "good"

    def test_mediocre_threshold(self):
        assert _analytics_health_key(5.0, 100) == "mediocre"
        assert _analytics_health_key(14.9, 100) == "mediocre"

    def test_struggling_threshold(self):
        assert _analytics_health_key(0.0, 100) == "struggling"
        assert _analytics_health_key(4.9, 100) == "struggling"

    def test_none_rate_with_contacts_is_struggling(self):
        assert _analytics_health_key(None, 100) == "struggling"

    def test_excellent_boundary_is_inclusive(self):
        assert _analytics_health_key(30.0, 1) == "excellent"

    def test_good_boundary_is_inclusive(self):
        assert _analytics_health_key(15.0, 1) == "good"

    def test_mediocre_boundary_is_inclusive(self):
        assert _analytics_health_key(5.0, 1) == "mediocre"


# ---------------------------------------------------------------------------
# Step-type palette
# ---------------------------------------------------------------------------


class TestAnalyticsStepTypePalette:
    def test_email_palette(self):
        pal = _analytics_step_type_palette("email")
        assert pal["fg"] == "#1e40af"

    def test_email_case_insensitive(self):
        pal = _analytics_step_type_palette("EMAIL")
        assert pal["fg"] == "#1e40af"

    def test_phone_palette(self):
        pal = _analytics_step_type_palette("phone")
        assert pal["fg"] == "#92400e"

    def test_call_aliases_to_phone_palette(self):
        assert (
            _analytics_step_type_palette("call")
            == _analytics_step_type_palette("phone")
        )

    def test_voice_aliases_to_phone_palette(self):
        assert (
            _analytics_step_type_palette("voice")
            == _analytics_step_type_palette("phone")
        )

    def test_sms_palette(self):
        pal = _analytics_step_type_palette("sms")
        assert pal["fg"] == "#059669"  # was banned #166534

    def test_no_banned_hexes_in_health_palette(self):
        """Lock test — no banned Studio hex reintroduced into health palette."""
        from g8_mcp_server.app_renderer import _ANALYTICS_HEALTH_COLORS

        banned = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}
        for _health, pal in _ANALYTICS_HEALTH_COLORS.items():
            for _k, value in pal.items():
                assert value.lower() not in banned, (
                    f"banned Studio hex {value} resurfaced in health palette"
                )

    def test_whatsapp_aliases_to_sms(self):
        assert (
            _analytics_step_type_palette("whatsapp")
            == _analytics_step_type_palette("sms")
        )

    def test_linkedin_palette(self):
        pal = _analytics_step_type_palette("linkedin")
        assert pal["fg"] == "#7d2df3"

    def test_unknown_falls_back(self):
        pal = _analytics_step_type_palette("carrier_pigeon")
        assert pal["fg"] == "#777777"

    def test_none_falls_back(self):
        pal = _analytics_step_type_palette(None)
        assert pal["fg"] == "#777777"

    def test_empty_string_falls_back(self):
        pal = _analytics_step_type_palette("")
        assert pal["fg"] == "#777777"


# ---------------------------------------------------------------------------
# Formatters
# ---------------------------------------------------------------------------


class TestFormatAnalyticsPct:
    def test_float_formats_with_one_decimal(self):
        assert _format_analytics_pct(12.5) == "12.5%"

    def test_int_formats_with_trailing_zero(self):
        assert _format_analytics_pct(10) == "10.0%"

    def test_zero_formats_as_zero(self):
        assert _format_analytics_pct(0.0) == "0.0%"

    def test_none_formats_as_zero(self):
        assert _format_analytics_pct(None) == "0.0%"

    def test_string_garbage_formats_as_zero(self):
        assert _format_analytics_pct("not a number") == "0.0%"

    def test_negative_passes_through_rounded(self):
        # We don't clamp — callers can represent net-negative metrics.
        assert _format_analytics_pct(-3.2) == "-3.2%"


class TestFormatAnalyticsCount:
    def test_int_with_thousands_separator(self):
        assert _format_analytics_count(1_000) == "1,000"

    def test_large_count_with_thousands_separator(self):
        assert _format_analytics_count(1_234_567) == "1,234,567"

    def test_zero(self):
        assert _format_analytics_count(0) == "0"

    def test_none_returns_zero(self):
        assert _format_analytics_count(None) == "0"

    def test_string_garbage_returns_zero(self):
        assert _format_analytics_count("not a number") == "0"


# ---------------------------------------------------------------------------
# Bar rendering (width clamp)
# ---------------------------------------------------------------------------


class TestRenderAnalyticsBar:
    def test_normal_percentage(self):
        html = _render_analytics_bar(50.0, {"fg": "#059669"})
        assert 'width:50.0%' in html
        assert '#059669' in html

    def test_over_100_clamps_to_100(self):
        html = _render_analytics_bar(250.0, {"fg": "#059669"})
        assert 'width:100.0%' in html

    def test_negative_clamps_to_zero(self):
        html = _render_analytics_bar(-10.0, {"fg": "#059669"})
        assert 'width:0.0%' in html

    def test_none_renders_as_zero(self):
        html = _render_analytics_bar(None, {"fg": "#059669"})
        assert 'width:0.0%' in html

    def test_garbage_renders_as_zero(self):
        html = _render_analytics_bar("not a number", {"fg": "#059669"})
        assert 'width:0.0%' in html

    def test_boundary_exactly_100(self):
        html = _render_analytics_bar(100.0, {"fg": "#059669"})
        assert 'width:100.0%' in html


# ---------------------------------------------------------------------------
# HTML renderer — empty states
# ---------------------------------------------------------------------------


class TestRenderHtmlEmptyStates:
    def test_none_analytics(self):
        html = render_sequence_analytics_html(
            analytics=None, sequence_id="seq-1"
        )
        assert "No analytics yet" in html
        assert "seq-1" in html

    def test_non_dict_analytics(self):
        html = render_sequence_analytics_html(
            analytics="garbage",  # type: ignore[arg-type]
            sequence_id="seq-1",
        )
        assert "No analytics yet" in html

    def test_fully_zero_analytics(self):
        # A sequence that exists but has never sent / has no steps should
        # render the empty state, not a dashboard of zero-bars.
        html = render_sequence_analytics_html(
            analytics={
                "overview": {"total_contacts": 0, "total_steps": 0},
                "performance": {},
                "timeline": [],
            },
            sequence_id="seq-1",
        )
        assert "No analytics yet" in html

    def test_empty_state_includes_sequence_id(self):
        html = render_sequence_analytics_html(
            analytics=None, sequence_id="seq-xyz"
        )
        assert "seq-xyz" in html

    def test_empty_state_includes_sequence_name(self):
        html = render_sequence_analytics_html(
            analytics=None, sequence_id="seq-1", sequence_name="Q2 Outbound"
        )
        assert "Q2 Outbound" in html

    def test_empty_state_with_no_name_uses_default(self):
        html = render_sequence_analytics_html(
            analytics=None, sequence_id="seq-1"
        )
        assert "Sequence" in html


# ---------------------------------------------------------------------------
# HTML renderer — populated
# ---------------------------------------------------------------------------


def _sample_analytics():
    """A realistic analytics payload for populated-render tests."""
    return {
        "overview": {
            "total_contacts": 1200,
            "active_contacts": 340,
            "completed_contacts": 720,
            "total_steps": 5,
            "active_steps": 5,
            "success_rate": 22.5,
            "overall_progress": 78.0,
        },
        "performance": {
            "step_performance": [
                {
                    "step_id": "step-1",
                    "step_name": "Opener email",
                    "step_type": "email",
                    "sent_count": 1200,
                    "delivered_count": 1180,
                    "delivery_rate": 98.3,
                    "reply_rate": 12.1,
                    "bounce_rate": 1.7,
                },
                {
                    "step_id": "step-2",
                    "step_name": "Follow-up call",
                    "step_type": "phone",
                    "sent_count": 450,
                    "delivered_count": 450,
                    "delivery_rate": 100.0,
                    "reply_rate": 5.5,
                    "bounce_rate": 0.0,
                },
            ],
            "response_rates": [
                {
                    "step_id": "step-1",
                    "step_name": "Opener email",
                    "time_frame": "24h",
                    "response_rate": 4.2,
                    "response_count": 50,
                    "total_sent": 1200,
                },
                {
                    "step_id": "step-1",
                    "step_name": "Opener email",
                    "time_frame": "48h",
                    "response_rate": 6.8,
                    "response_count": 82,
                    "total_sent": 1200,
                },
                {
                    "step_id": "step-1",
                    "step_name": "Opener email",
                    "time_frame": "7d",
                    "response_rate": 12.1,
                    "response_count": 145,
                    "total_sent": 1200,
                },
            ],
        },
        "engagement": {},
        "timeline": [
            {"date": "2026-04-01", "total_sent": 100},
            {"date": "2026-04-02", "total_sent": 120},
            {"date": "2026-04-03", "total_sent": 95},
            {"date": "2026-04-04", "total_sent": 0},
            {"date": "2026-04-05", "total_sent": 180},
        ],
    }


class TestRenderHtmlPopulated:
    def test_renders_title_and_id(self):
        html = render_sequence_analytics_html(
            analytics=_sample_analytics(),
            sequence_id="seq-1",
            sequence_name="Q2 Outbound",
        )
        assert "Q2 Outbound" in html
        assert "seq-1" in html

    def test_health_badge_good_at_22pct(self):
        html = render_sequence_analytics_html(
            analytics=_sample_analytics(),
            sequence_id="seq-1",
        )
        # 22.5% success with 1200 contacts → "good" band.
        assert "good" in html

    def test_health_badge_excellent(self):
        a = _sample_analytics()
        a["overview"]["success_rate"] = 45.0
        html = render_sequence_analytics_html(
            analytics=a, sequence_id="seq-1"
        )
        assert "excellent" in html

    def test_health_badge_struggling(self):
        a = _sample_analytics()
        a["overview"]["success_rate"] = 1.0
        html = render_sequence_analytics_html(
            analytics=a, sequence_id="seq-1"
        )
        assert "struggling" in html

    def test_renders_overview_stat_cards(self):
        html = render_sequence_analytics_html(
            analytics=_sample_analytics(),
            sequence_id="seq-1",
        )
        assert "Total contacts" in html
        assert "1,200" in html
        assert "22.5%" in html
        assert "78.0%" in html

    def test_renders_step_performance_rows(self):
        html = render_sequence_analytics_html(
            analytics=_sample_analytics(),
            sequence_id="seq-1",
        )
        assert "Opener email" in html
        assert "Follow-up call" in html
        assert "12.1%" in html
        assert "5.5%" in html

    def test_renders_step_type_chips(self):
        html = render_sequence_analytics_html(
            analytics=_sample_analytics(),
            sequence_id="seq-1",
        )
        assert "email" in html
        assert "phone" in html

    def test_renders_response_rate_cards(self):
        html = render_sequence_analytics_html(
            analytics=_sample_analytics(),
            sequence_id="seq-1",
        )
        assert "First-step response rates" in html
        assert "24h" in html
        assert "48h" in html
        assert "7d" in html

    def test_renders_timeline(self):
        html = render_sequence_analytics_html(
            analytics=_sample_analytics(),
            sequence_id="seq-1",
        )
        assert "Send timeline" in html
        assert "total sends" in html

    def test_timeline_omits_when_all_zeros(self):
        a = _sample_analytics()
        a["timeline"] = [{"date": "2026-04-01", "total_sent": 0}] * 3
        html = render_sequence_analytics_html(
            analytics=a, sequence_id="seq-1"
        )
        assert "Send timeline" not in html

    def test_timeline_omits_when_empty(self):
        a = _sample_analytics()
        a["timeline"] = []
        html = render_sequence_analytics_html(
            analytics=a, sequence_id="seq-1"
        )
        assert "Send timeline" not in html

    def test_response_rates_omits_when_empty(self):
        a = _sample_analytics()
        a["performance"]["response_rates"] = []
        html = render_sequence_analytics_html(
            analytics=a, sequence_id="seq-1"
        )
        assert "First-step response rates" not in html

    def test_step_performance_shows_muted_when_empty(self):
        a = _sample_analytics()
        a["performance"]["step_performance"] = []
        html = render_sequence_analytics_html(
            analytics=a, sequence_id="seq-1"
        )
        assert "No step data yet" in html

    def test_step_performance_caps_at_max(self):
        a = _sample_analytics()
        many = [
            {
                "step_id": f"step-{i}",
                "step_name": f"Step {i}",
                "step_type": "email",
                "sent_count": 10,
                "delivered_count": 10,
                "delivery_rate": 100.0,
                "reply_rate": 1.0,
                "bounce_rate": 0.0,
            }
            for i in range(50)
        ]
        a["performance"]["step_performance"] = many
        html = render_sequence_analytics_html(
            analytics=a, sequence_id="seq-1"
        )
        # Cap is 30 so 20 should be omitted.
        assert "20 step(s) omitted" in html

    def test_xss_escape_in_step_name(self):
        a = _sample_analytics()
        a["performance"]["step_performance"][0]["step_name"] = (
            "<script>alert(1)</script>"
        )
        html = render_sequence_analytics_html(
            analytics=a, sequence_id="seq-1"
        )
        assert "<script>" not in html
        assert "&lt;script&gt;" in html

    def test_xss_escape_in_sequence_name(self):
        html = render_sequence_analytics_html(
            analytics=_sample_analytics(),
            sequence_id="seq-1",
            sequence_name="<img onerror=x>",
        )
        assert "<img onerror=x>" not in html
        assert "&lt;img" in html

    def test_non_dict_step_in_performance_is_skipped(self):
        a = _sample_analytics()
        a["performance"]["step_performance"] = [
            "garbage",  # type: ignore[list-item]
            a["performance"]["step_performance"][0],
        ]
        html = render_sequence_analytics_html(
            analytics=a, sequence_id="seq-1"
        )
        # Real row still renders.
        assert "Opener email" in html

    def test_missing_step_name_falls_back_to_step_id(self):
        a = _sample_analytics()
        a["performance"]["step_performance"] = [
            {
                "step_id": "alt-id-42",
                "step_type": "email",
                "sent_count": 10,
                "delivered_count": 10,
                "reply_rate": 0.0,
            }
        ]
        html = render_sequence_analytics_html(
            analytics=a, sequence_id="seq-1"
        )
        assert "alt-id-42" in html

    def test_renders_reply_and_bounce_bar_colors(self):
        html = render_sequence_analytics_html(
            analytics=_sample_analytics(),
            sequence_id="seq-1",
        )
        # Reply bar uses green, bounce bar uses red.
        assert "#059669" in html
        assert "#dc2626" in html

    def test_sent_count_with_thousands_separator(self):
        html = render_sequence_analytics_html(
            analytics=_sample_analytics(),
            sequence_id="seq-1",
        )
        assert "1,200" in html

    def test_doctype_present(self):
        html = render_sequence_analytics_html(
            analytics=_sample_analytics(),
            sequence_id="seq-1",
        )
        assert "<!DOCTYPE html>" in html

    def test_no_inline_script(self):
        html = render_sequence_analytics_html(
            analytics=_sample_analytics(),
            sequence_id="seq-1",
        )
        assert "<script" not in html.lower()

    def test_no_javascript_scheme(self):
        html = render_sequence_analytics_html(
            analytics=_sample_analytics(),
            sequence_id="seq-1",
        )
        assert "javascript:" not in html.lower()

    def test_performance_section_headers(self):
        html = render_sequence_analytics_html(
            analytics=_sample_analytics(),
            sequence_id="seq-1",
        )
        assert "Per-step performance" in html

    def test_steps_display_ratio(self):
        html = render_sequence_analytics_html(
            analytics=_sample_analytics(),
            sequence_id="seq-1",
        )
        # active_steps/total_steps = 5/5
        assert "5/5" in html

    def test_delivery_rate_percentage_shown(self):
        html = render_sequence_analytics_html(
            analytics=_sample_analytics(),
            sequence_id="seq-1",
        )
        assert "98.3%" in html


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------


class TestRenderTextFallback:
    def test_none_analytics(self):
        text = render_sequence_analytics_text_fallback(
            analytics=None, sequence_id="seq-1"
        )
        assert "No analytics data available" in text
        assert "seq-1" in text

    def test_zero_state_summary(self):
        text = render_sequence_analytics_text_fallback(
            analytics={"overview": {}, "performance": {}, "timeline": []},
            sequence_id="seq-1",
        )
        assert "No analytics yet" in text

    def test_populated_has_markdown_header(self):
        text = render_sequence_analytics_text_fallback(
            analytics=_sample_analytics(),
            sequence_id="seq-1",
            sequence_name="Q2 Outbound",
        )
        assert "# Sequence analytics" in text
        assert "Q2 Outbound" in text

    def test_populated_has_overview_section(self):
        text = render_sequence_analytics_text_fallback(
            analytics=_sample_analytics(),
            sequence_id="seq-1",
        )
        assert "## Overview" in text
        assert "Success rate: 22.5%" in text
        assert "Progress: 78.0%" in text

    def test_populated_has_per_step_section(self):
        text = render_sequence_analytics_text_fallback(
            analytics=_sample_analytics(),
            sequence_id="seq-1",
        )
        assert "## Per-step performance" in text
        assert "Opener email" in text
        assert "Follow-up call" in text

    def test_populated_has_response_rates(self):
        text = render_sequence_analytics_text_fallback(
            analytics=_sample_analytics(),
            sequence_id="seq-1",
        )
        assert "## First-step response rates" in text
        assert "24h:" in text

    def test_populated_has_timeline(self):
        text = render_sequence_analytics_text_fallback(
            analytics=_sample_analytics(),
            sequence_id="seq-1",
        )
        assert "## Send timeline" in text
        assert "Total:" in text
        assert "peak:" in text

    def test_health_badge_in_fallback(self):
        text = render_sequence_analytics_text_fallback(
            analytics=_sample_analytics(),
            sequence_id="seq-1",
        )
        assert "Health:" in text

    def test_excellent_health_in_fallback(self):
        a = _sample_analytics()
        a["overview"]["success_rate"] = 45.0
        text = render_sequence_analytics_text_fallback(
            analytics=a, sequence_id="seq-1"
        )
        assert "excellent" in text

    def test_step_cap_in_fallback(self):
        a = _sample_analytics()
        many = [
            {
                "step_id": f"step-{i}",
                "step_name": f"Step {i}",
                "step_type": "email",
                "sent_count": 10,
                "delivery_rate": 100.0,
                "reply_rate": 1.0,
                "bounce_rate": 0.0,
            }
            for i in range(50)
        ]
        a["performance"]["step_performance"] = many
        text = render_sequence_analytics_text_fallback(
            analytics=a, sequence_id="seq-1"
        )
        assert "20 more step(s)" in text

    def test_no_section_when_empty(self):
        a = _sample_analytics()
        a["performance"]["response_rates"] = []
        a["performance"]["step_performance"] = []
        a["timeline"] = []
        # Overview stays, but optional sections drop out.
        text = render_sequence_analytics_text_fallback(
            analytics=a, sequence_id="seq-1"
        )
        assert "## First-step response rates" not in text
        assert "## Per-step performance" not in text
        assert "## Send timeline" not in text

    def test_non_dict_step_in_text_is_skipped(self):
        a = _sample_analytics()
        a["performance"]["step_performance"] = [
            "garbage",  # type: ignore[list-item]
            a["performance"]["step_performance"][0],
        ]
        text = render_sequence_analytics_text_fallback(
            analytics=a, sequence_id="seq-1"
        )
        assert "Opener email" in text

    def test_non_dict_response_in_text_is_skipped(self):
        a = _sample_analytics()
        a["performance"]["response_rates"] = [
            "garbage",  # type: ignore[list-item]
            a["performance"]["response_rates"][0],
        ]
        text = render_sequence_analytics_text_fallback(
            analytics=a, sequence_id="seq-1"
        )
        # Real 24h row still appears.
        assert "24h:" in text

    def test_trailing_newline(self):
        text = render_sequence_analytics_text_fallback(
            analytics=_sample_analytics(),
            sequence_id="seq-1",
        )
        assert text.endswith("\n")

    def test_zero_sends_timeline_omitted(self):
        a = _sample_analytics()
        a["timeline"] = [{"date": "2026-04-01", "total_sent": 0}] * 3
        text = render_sequence_analytics_text_fallback(
            analytics=a, sequence_id="seq-1"
        )
        assert "## Send timeline" not in text
