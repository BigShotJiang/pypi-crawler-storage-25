"""Unit tests for Upgrade 4 surface #38: per-list members HTML renderer.

Complements surface #8 (lists dashboard, org-wide) by drilling into a
single list/audience and showing the actual contact roster. Ships with
graph8 design tokens from the start — tests lock in the absence of
AI-tell accent borders and legacy palette colors.

Design parity assertions (vs earlier surfaces):
    - Uniform 1px solid #dfdfdf border on every card (no `border-top:
      3px solid <accent>` or `border-left: 3px solid <accent>` pattern)
    - shadow-xs on cards
    - #7d2df3 primary + #f2eafe primary tint for accent chips only
    - Aeonik font-family first
    - No legacy indigo/green/red/gray hexes from surfaces #1-#35
    - Display name chain: first+last > work_email > "(unnamed contact)"
"""

from __future__ import annotations

import pytest

from g8_mcp_server.app_renderer import (
    _list_members_bucket_departments,
    _list_members_bucket_seniority,
    _list_members_clip,
    _list_members_display_name,
    _list_members_location,
    _list_members_stat_card,
    _list_members_unique_companies,
    _list_members_unique_countries,
    _render_list_members_empty_state_html,
    render_list_members_html,
    render_list_members_text_fallback,
)


# =============================================================== #
# Helpers                                                         #
# =============================================================== #


def _make_contact(
    *,
    id: str | int = 1,
    first_name: str | None = "Alice",
    last_name: str | None = "Smith",
    work_email: str | None = "alice@acme.com",
    job_title: str | None = "VP of Revenue Operations",
    job_department: str | None = "Revenue",
    seniority_level: str | None = "vp",
    city: str | None = "San Francisco",
    state: str | None = "CA",
    country: str | None = "USA",
    company_id: int | str | None = 101,
) -> dict:
    return {
        "id": id,
        "first_name": first_name,
        "last_name": last_name,
        "work_email": work_email,
        "job_title": job_title,
        "job_department": job_department,
        "seniority_level": seniority_level,
        "city": city,
        "state": state,
        "country": country,
        "company_id": company_id,
    }


# =============================================================== #
# _list_members_clip                                              #
# =============================================================== #


class TestClip:
    def test_none_returns_empty(self):
        assert _list_members_clip(None, 80) == ""

    def test_non_string_returns_empty(self):
        assert _list_members_clip(42, 80) == ""
        assert _list_members_clip(["a"], 80) == ""
        assert _list_members_clip(True, 80) == ""

    def test_empty_string_returns_empty(self):
        assert _list_members_clip("", 80) == ""
        assert _list_members_clip("   ", 80) == ""

    def test_normal_string_unchanged(self):
        assert _list_members_clip("hello world", 80) == "hello world"

    def test_strips_surrounding_whitespace(self):
        assert _list_members_clip("  hi  ", 80) == "hi"

    def test_truncates_with_ellipsis(self):
        result = _list_members_clip("a" * 100, 20)
        assert result.endswith("…")
        assert len(result) == 20

    def test_escapes_html(self):
        assert _list_members_clip("<script>", 80) == "&lt;script&gt;"

    def test_preserves_ampersand(self):
        # html.escape turns & into &amp;
        assert _list_members_clip("A & B", 80) == "A &amp; B"


# =============================================================== #
# _list_members_display_name                                      #
# =============================================================== #


class TestDisplayName:
    def test_first_plus_last_preferred(self):
        assert _list_members_display_name(_make_contact()) == "Alice Smith"

    def test_first_only(self):
        c = _make_contact(last_name=None)
        assert _list_members_display_name(c) == "Alice"

    def test_last_only(self):
        c = _make_contact(first_name=None)
        assert _list_members_display_name(c) == "Smith"

    def test_fallback_to_email_when_no_name(self):
        c = _make_contact(first_name=None, last_name=None)
        assert _list_members_display_name(c) == "alice@acme.com"

    def test_fallback_to_email_when_name_blank(self):
        c = _make_contact(first_name="  ", last_name="  ")
        assert _list_members_display_name(c) == "alice@acme.com"

    def test_unnamed_sentinel_when_nothing(self):
        c = _make_contact(first_name=None, last_name=None, work_email=None)
        assert _list_members_display_name(c) == "(unnamed contact)"

    def test_unnamed_when_all_blank(self):
        c = _make_contact(first_name="", last_name="", work_email="")
        assert _list_members_display_name(c) == "(unnamed contact)"

    def test_non_dict_input(self):
        assert _list_members_display_name("not a dict") == "(unnamed contact)"
        assert _list_members_display_name(None) == "(unnamed contact)"

    def test_escapes_xss_in_name(self):
        c = _make_contact(first_name="<script>", last_name="alert")
        result = _list_members_display_name(c)
        assert "<script>" not in result
        assert "&lt;script&gt;" in result


# =============================================================== #
# _list_members_location                                          #
# =============================================================== #


class TestLocation:
    def test_all_three_parts(self):
        assert (
            _list_members_location(_make_contact())
            == "San Francisco, CA, USA"
        )

    def test_only_country(self):
        c = _make_contact(city=None, state=None)
        assert _list_members_location(c) == "USA"

    def test_city_and_country_only(self):
        c = _make_contact(state=None)
        assert _list_members_location(c) == "San Francisco, USA"

    def test_empty_all(self):
        c = _make_contact(city=None, state=None, country=None)
        assert _list_members_location(c) == ""

    def test_blank_parts_skipped(self):
        c = _make_contact(city="", state="   ", country="USA")
        assert _list_members_location(c) == "USA"

    def test_non_dict_input(self):
        assert _list_members_location("not a dict") == ""
        assert _list_members_location(None) == ""

    def test_escapes_xss(self):
        c = _make_contact(city="<script>", state=None, country=None)
        result = _list_members_location(c)
        assert "<script>" not in result
        assert "&lt;script&gt;" in result


# =============================================================== #
# _list_members_bucket_seniority                                  #
# =============================================================== #


class TestBucketSeniority:
    def test_groups_by_level(self):
        contacts = [
            _make_contact(seniority_level="vp"),
            _make_contact(seniority_level="vp"),
            _make_contact(seniority_level="director"),
        ]
        buckets = _list_members_bucket_seniority(contacts)
        d = dict(buckets)
        assert d["vp"] == 2
        assert d["director"] == 1

    def test_missing_level_goes_to_unknown(self):
        contacts = [_make_contact(seniority_level=None)]
        buckets = _list_members_bucket_seniority(contacts)
        assert dict(buckets) == {"unknown": 1}

    def test_blank_level_goes_to_unknown(self):
        contacts = [_make_contact(seniority_level="   ")]
        buckets = _list_members_bucket_seniority(contacts)
        assert dict(buckets) == {"unknown": 1}

    def test_sort_order_descending_by_count(self):
        contacts = [
            _make_contact(seniority_level="director"),
            _make_contact(seniority_level="vp"),
            _make_contact(seniority_level="vp"),
            _make_contact(seniority_level="vp"),
        ]
        buckets = _list_members_bucket_seniority(contacts)
        # vp (3) before director (1)
        assert buckets[0] == ("vp", 3)
        assert buckets[1] == ("director", 1)

    def test_tie_break_uses_canonical_order(self):
        """Equal counts → canonical seniority order (c_suite > vp > director)."""
        contacts = [
            _make_contact(seniority_level="director"),
            _make_contact(seniority_level="vp"),
            _make_contact(seniority_level="c_suite"),
        ]
        buckets = _list_members_bucket_seniority(contacts)
        # All have count=1, so c_suite first, then vp, then director
        assert buckets[0][0] == "c_suite"
        assert buckets[1][0] == "vp"
        assert buckets[2][0] == "director"

    def test_skips_non_dict(self):
        contacts = [_make_contact(seniority_level="vp"), "not a dict", None]
        buckets = _list_members_bucket_seniority(contacts)
        assert dict(buckets) == {"vp": 1}

    def test_case_normalized(self):
        contacts = [
            _make_contact(seniority_level="VP"),
            _make_contact(seniority_level="vp"),
        ]
        buckets = _list_members_bucket_seniority(contacts)
        assert dict(buckets) == {"vp": 2}

    def test_empty_list(self):
        assert _list_members_bucket_seniority([]) == []


# =============================================================== #
# _list_members_bucket_departments                                #
# =============================================================== #


class TestBucketDepartments:
    def test_groups_by_dept(self):
        contacts = [
            _make_contact(job_department="Sales"),
            _make_contact(job_department="Sales"),
            _make_contact(job_department="Engineering"),
        ]
        buckets = _list_members_bucket_departments(contacts)
        d = dict(buckets)
        assert d["Sales"] == 2
        assert d["Engineering"] == 1

    def test_missing_dept_goes_to_unknown(self):
        contacts = [_make_contact(job_department=None)]
        buckets = _list_members_bucket_departments(contacts)
        assert dict(buckets) == {"Unknown": 1}

    def test_sort_descending_by_count(self):
        contacts = [
            _make_contact(job_department="Engineering"),
            _make_contact(job_department="Sales"),
            _make_contact(job_department="Sales"),
        ]
        buckets = _list_members_bucket_departments(contacts)
        assert buckets[0] == ("Sales", 2)

    def test_tie_break_alphabetical_case_insensitive(self):
        contacts = [
            _make_contact(job_department="engineering"),
            _make_contact(job_department="Sales"),
        ]
        buckets = _list_members_bucket_departments(contacts)
        # engineering comes before Sales alphabetically (case-insensitive)
        assert buckets[0][0] == "engineering"

    def test_skips_non_dict(self):
        contacts = [_make_contact(job_department="Sales"), 42, None]
        buckets = _list_members_bucket_departments(contacts)
        assert dict(buckets) == {"Sales": 1}

    def test_empty_list(self):
        assert _list_members_bucket_departments([]) == []


# =============================================================== #
# _list_members_unique_companies                                  #
# =============================================================== #


class TestUniqueCompanies:
    def test_counts_distinct_ids(self):
        contacts = [
            _make_contact(company_id=1),
            _make_contact(company_id=1),
            _make_contact(company_id=2),
        ]
        assert _list_members_unique_companies(contacts) == 2

    def test_skips_none_values(self):
        contacts = [
            _make_contact(company_id=None),
            _make_contact(company_id=1),
        ]
        assert _list_members_unique_companies(contacts) == 1

    def test_skips_empty_string(self):
        contacts = [_make_contact(company_id=""), _make_contact(company_id=1)]
        assert _list_members_unique_companies(contacts) == 1

    def test_rejects_bool_values(self):
        """Python bool subclasses int — must not slip into company counts."""
        contacts = [
            _make_contact(company_id=True),
            _make_contact(company_id=False),
        ]
        # Both bool values are rejected
        assert _list_members_unique_companies(contacts) == 0

    def test_mixed_int_and_str_ids(self):
        # Different types → distinct
        contacts = [
            _make_contact(company_id=1),
            _make_contact(company_id="1"),
        ]
        assert _list_members_unique_companies(contacts) == 2

    def test_empty(self):
        assert _list_members_unique_companies([]) == 0

    def test_skips_non_dict(self):
        contacts = [_make_contact(company_id=1), "not a dict"]
        assert _list_members_unique_companies(contacts) == 1


# =============================================================== #
# _list_members_unique_countries                                  #
# =============================================================== #


class TestUniqueCountries:
    def test_counts_distinct(self):
        contacts = [
            _make_contact(country="USA"),
            _make_contact(country="UK"),
            _make_contact(country="USA"),
        ]
        assert _list_members_unique_countries(contacts) == 2

    def test_case_normalized(self):
        contacts = [
            _make_contact(country="USA"),
            _make_contact(country="usa"),
        ]
        assert _list_members_unique_countries(contacts) == 1

    def test_skips_empty(self):
        contacts = [
            _make_contact(country=None),
            _make_contact(country=""),
            _make_contact(country="USA"),
        ]
        assert _list_members_unique_countries(contacts) == 1

    def test_empty(self):
        assert _list_members_unique_countries([]) == 0


# =============================================================== #
# _list_members_stat_card                                         #
# =============================================================== #


class TestStatCard:
    def test_contains_label_and_value(self):
        card = _list_members_stat_card("Total contacts", "42")
        assert "Total contacts" in card
        assert "42" in card

    def test_uniform_border_not_single_side(self):
        """Locks out `border-top: 3px solid ...` AI-tell pattern."""
        card = _list_members_stat_card("label", "v", accent=True)
        assert "border-top:3px" not in card
        assert "border-top: 3px" not in card
        assert "border-left:3px" not in card
        assert "border-left: 3px" not in card

    def test_accent_uses_graph8_primary(self):
        card = _list_members_stat_card("label", "v", accent=True)
        assert "#7d2df3" in card

    def test_non_accent_uses_text_color(self):
        card = _list_members_stat_card("label", "v", accent=False)
        # Default text color (dark, not accent)
        assert "#0A0A0A" in card

    def test_uses_graph8_border(self):
        card = _list_members_stat_card("label", "v")
        assert "#dfdfdf" in card

    def test_uses_aeonik_via_inherit(self):
        """Stat card alone doesn't set font-family; inherits from <body>."""
        card = _list_members_stat_card("label", "v")
        # Border + radius + padding present
        assert "border-radius:12px" in card
        assert "padding:16px" in card

    def test_escapes_label_xss(self):
        card = _list_members_stat_card("<script>", "v")
        assert "<script>" not in card
        assert "&lt;script&gt;" in card

    def test_escapes_value_xss(self):
        card = _list_members_stat_card("l", "<script>")
        assert "<script>alert" not in card
        assert "&lt;script&gt;" in card


# =============================================================== #
# _render_list_members_empty_state_html                           #
# =============================================================== #


class TestEmptyState:
    def test_empty_mode_shows_add_pointer(self):
        html = _render_list_members_empty_state_html("42", mode="empty")
        assert "No contacts in this list yet" in html
        assert "POST /lists/42/contacts" in html
        # Empty mode → primary tint
        assert "#f2eafe" in html

    def test_unavailable_mode_shows_not_available(self):
        html = _render_list_members_empty_state_html("42", mode="unavailable")
        assert "List members not available" in html
        # Unavailable mode → muted/gray, not primary tint
        assert "List id <code>42</code>" in html

    def test_both_modes_link_dashboard(self):
        for mode in ("empty", "unavailable"):
            html = _render_list_members_empty_state_html("42", mode=mode)
            assert "g8://lists/dashboard" in html

    def test_escapes_list_id_xss(self):
        html = _render_list_members_empty_state_html(
            "<script>alert(1)</script>", mode="empty"
        )
        assert "<script>alert" not in html
        assert "&lt;script&gt;" in html

    def test_uses_aeonik(self):
        html = _render_list_members_empty_state_html("42", mode="empty")
        assert "Aeonik" in html

    def test_uses_graph8_border(self):
        html = _render_list_members_empty_state_html("42", mode="empty")
        assert "#dfdfdf" in html

    def test_no_single_side_accent_borders(self):
        for mode in ("empty", "unavailable"):
            html = _render_list_members_empty_state_html("42", mode=mode)
            assert "border-top:3px" not in html
            assert "border-top: 3px" not in html
            assert "border-left:3px" not in html
            assert "border-left: 3px" not in html


# =============================================================== #
# render_list_members_html                                        #
# =============================================================== #


class TestRenderHtml:
    def test_none_contacts_returns_unavailable(self):
        html = render_list_members_html(contacts=None, list_id="42")
        assert "List members not available" in html

    def test_empty_contacts_returns_empty_state(self):
        html = render_list_members_html(contacts=[], list_id="42")
        assert "No contacts in this list yet" in html

    def test_label_from_meta_title(self):
        html = render_list_members_html(
            contacts=[_make_contact()],
            list_id="42",
            list_meta={"title": "Enterprise Prospects"},
        )
        assert "Enterprise Prospects" in html

    def test_label_from_meta_name_fallback(self):
        html = render_list_members_html(
            contacts=[_make_contact()],
            list_id="42",
            list_meta={"name": "Alt Label"},
        )
        assert "Alt Label" in html

    def test_label_generic_when_no_meta(self):
        html = render_list_members_html(
            contacts=[_make_contact()], list_id="42", list_meta=None
        )
        # "List" appears as header default label
        assert "List — members" in html

    def test_total_chip(self):
        contacts = [_make_contact(id=i) for i in range(5)]
        html = render_list_members_html(contacts=contacts, list_id="42")
        assert "5 TOTAL" in html

    def test_four_stat_cards(self):
        contacts = [
            _make_contact(company_id=1),
            _make_contact(company_id=2, country="UK"),
        ]
        html = render_list_members_html(contacts=contacts, list_id="42")
        assert "Total contacts" in html
        assert "Unique companies" in html
        assert "Departments" in html
        assert "Countries" in html

    def test_seniority_pills_rendered(self):
        contacts = [
            _make_contact(seniority_level="vp"),
            _make_contact(seniority_level="director"),
        ]
        html = render_list_members_html(contacts=contacts, list_id="42")
        assert "Seniority mix" in html
        assert "Vp" in html or "VP" in html  # title-cased or original
        assert "Director" in html

    def test_department_pills_rendered(self):
        contacts = [
            _make_contact(job_department="Sales"),
            _make_contact(job_department="Engineering"),
        ]
        html = render_list_members_html(contacts=contacts, list_id="42")
        assert "Departments" in html
        assert "Sales" in html
        assert "Engineering" in html

    def test_department_overflow_note(self):
        contacts = [
            _make_contact(job_department=f"Dept{i}", id=i) for i in range(10)
        ]
        html = render_list_members_html(contacts=contacts, list_id="42")
        # 10 unique depts; cap is 6
        assert "+ 4 more" in html

    def test_contact_row_shows_name_and_id(self):
        c = _make_contact(id=42, first_name="Bob", last_name="Jones")
        html = render_list_members_html(contacts=[c], list_id="1")
        assert "Bob Jones" in html
        assert "id=42" in html

    def test_contact_row_shows_title(self):
        html = render_list_members_html(
            contacts=[_make_contact()], list_id="1"
        )
        assert "VP of Revenue Operations" in html

    def test_contact_row_shows_email(self):
        html = render_list_members_html(
            contacts=[_make_contact()], list_id="1"
        )
        assert "alice@acme.com" in html

    def test_contact_row_shows_location(self):
        html = render_list_members_html(
            contacts=[_make_contact()], list_id="1"
        )
        assert "San Francisco, CA, USA" in html

    def test_contact_row_shows_company_id(self):
        html = render_list_members_html(
            contacts=[_make_contact(company_id=999)], list_id="1"
        )
        assert "company #999" in html

    def test_contact_overflow_note(self):
        contacts = [_make_contact(id=i, first_name=f"U{i}") for i in range(50)]
        html = render_list_members_html(contacts=contacts, list_id="42")
        assert "+ 10 more contacts" in html
        assert "GET /lists/42/contacts?page=2" in html

    def test_drill_up_section(self):
        html = render_list_members_html(
            contacts=[_make_contact()], list_id="42"
        )
        assert "g8://lists/dashboard" in html
        assert "POST /lists/42/contacts" in html
        assert "DELETE /lists/42/contacts" in html

    def test_uses_aeonik_font(self):
        html = render_list_members_html(
            contacts=[_make_contact()], list_id="42"
        )
        assert "Aeonik" in html

    def test_uses_graph8_primary(self):
        html = render_list_members_html(
            contacts=[_make_contact()], list_id="42"
        )
        assert "#7d2df3" in html

    def test_uses_graph8_border(self):
        html = render_list_members_html(
            contacts=[_make_contact()], list_id="42"
        )
        assert "#dfdfdf" in html

    def test_no_single_side_accent_borders(self):
        """No AI-tell `border-top: 3px solid` or `border-left: 3px solid`."""
        contacts = [_make_contact(id=i) for i in range(5)]
        html = render_list_members_html(contacts=contacts, list_id="42")
        assert "border-top:3px" not in html
        assert "border-top: 3px" not in html
        assert "border-left:3px" not in html
        assert "border-left: 3px" not in html

    def test_no_legacy_accent_hexes(self):
        """None of the earlier surfaces' accent hexes should leak into #38."""
        contacts = [
            _make_contact(
                id=i,
                first_name=f"U{i}",
                seniority_level="vp" if i % 2 == 0 else "director",
            )
            for i in range(3)
        ]
        html = render_list_members_html(contacts=contacts, list_id="42")
        for legacy in ("#6366f1", "#16a34a", "#dc2626", "#9ca3af", "#f59e0b"):
            assert legacy not in html, (
                f"list members renderer must not contain legacy {legacy}"
            )

    def test_xss_in_name(self):
        c = _make_contact(
            first_name="<script>alert(1)</script>", last_name="evil"
        )
        html = render_list_members_html(contacts=[c], list_id="1")
        assert "<script>alert" not in html
        assert "&lt;script&gt;" in html

    def test_xss_in_title(self):
        c = _make_contact(job_title="<img src=x onerror=alert(1)>")
        html = render_list_members_html(contacts=[c], list_id="1")
        assert "<img src=x onerror" not in html
        assert "&lt;img" in html

    def test_xss_in_list_id(self):
        html = render_list_members_html(
            contacts=[_make_contact()],
            list_id="<script>alert(1)</script>",
        )
        assert "<script>alert" not in html
        assert "&lt;script&gt;" in html

    def test_xss_in_list_title(self):
        html = render_list_members_html(
            contacts=[_make_contact()],
            list_id="42",
            list_meta={"title": "<script>evil</script>"},
        )
        assert "<script>evil" not in html
        assert "&lt;script&gt;" in html

    def test_no_double_escape(self):
        c = _make_contact(first_name="A & B", last_name=None, work_email=None)
        html = render_list_members_html(contacts=[c], list_id="1")
        assert "&amp;amp;" not in html
        assert "&amp;" in html

    def test_valid_html_doctype(self):
        html = render_list_members_html(
            contacts=[_make_contact()], list_id="42"
        )
        assert html.startswith("<!DOCTYPE html>")
        assert html.rstrip().endswith("</html>")

    def test_filters_non_dict_contacts_defensively(self):
        """Extra defence: non-dict entries in the list are skipped."""
        contacts = [_make_contact(), "garbage", None, 42]
        html = render_list_members_html(contacts=contacts, list_id="42")
        # Only one valid contact was rendered
        assert "1 TOTAL" in html


# =============================================================== #
# render_list_members_text_fallback                               #
# =============================================================== #


class TestTextFallback:
    def test_none_returns_not_available(self):
        text = render_list_members_text_fallback(contacts=None, list_id="42")
        assert "members not available" in text
        assert "g8://lists/dashboard" in text

    def test_empty_returns_no_members(self):
        text = render_list_members_text_fallback(contacts=[], list_id="42")
        assert "no members yet" in text
        assert "POST /lists/42/contacts" in text

    def test_header_with_meta_title(self):
        text = render_list_members_text_fallback(
            contacts=[_make_contact()],
            list_id="42",
            list_meta={"title": "Enterprise Prospects"},
        )
        assert "# Enterprise Prospects — members" in text

    def test_header_generic_when_no_meta(self):
        text = render_list_members_text_fallback(
            contacts=[_make_contact()], list_id="42"
        )
        assert "# List — members" in text

    def test_stats_block(self):
        contacts = [_make_contact(id=i) for i in range(3)]
        text = render_list_members_text_fallback(contacts=contacts, list_id="42")
        assert "- Total contacts: 3" in text
        assert "- Unique companies:" in text
        assert "- Countries:" in text
        assert "- Departments:" in text

    def test_seniority_section(self):
        contacts = [
            _make_contact(seniority_level="vp"),
            _make_contact(seniority_level="director"),
        ]
        text = render_list_members_text_fallback(
            contacts=contacts, list_id="42"
        )
        assert "## Seniority mix" in text
        assert "Vp: 1" in text
        assert "Director: 1" in text

    def test_departments_section(self):
        contacts = [
            _make_contact(job_department="Sales"),
            _make_contact(job_department="Engineering"),
        ]
        text = render_list_members_text_fallback(
            contacts=contacts, list_id="42"
        )
        assert "## Departments" in text
        assert "Sales: 1" in text
        assert "Engineering: 1" in text

    def test_contact_row_with_all_fields(self):
        text = render_list_members_text_fallback(
            contacts=[_make_contact()], list_id="42"
        )
        assert "Alice Smith" in text
        assert "VP of Revenue Operations" in text
        assert "<alice@acme.com>" in text
        assert "company #101" in text
        assert "San Francisco, CA, USA" in text

    def test_contact_overflow_note(self):
        contacts = [_make_contact(id=i, first_name=f"U{i}") for i in range(50)]
        text = render_list_members_text_fallback(
            contacts=contacts, list_id="42"
        )
        assert "+ 10 more contacts" in text
        assert "GET /lists/42/contacts?page=2" in text

    def test_drill_up_section(self):
        text = render_list_members_text_fallback(
            contacts=[_make_contact()], list_id="42"
        )
        assert "## Drill into this list" in text
        assert "g8://lists/dashboard" in text
        assert "POST /lists/42/contacts" in text
        assert "DELETE /lists/42/contacts" in text

    def test_ends_without_crashing_on_missing_fields(self):
        """Empty optional fields should not crash the renderer."""
        c = _make_contact(
            first_name=None,
            last_name=None,
            work_email="solo@acme.com",
            job_title=None,
            job_department=None,
            seniority_level=None,
            city=None,
            state=None,
            country=None,
            company_id=None,
        )
        text = render_list_members_text_fallback(contacts=[c], list_id="42")
        assert "solo@acme.com" in text


# =============================================================== #
# Smoke tests                                                     #
# =============================================================== #


class TestSmoke:
    def test_50_mixed_contacts_render(self):
        """Mixed roster renders both HTML and text without error."""
        contacts = [
            _make_contact(
                id=i,
                first_name=f"User{i}",
                last_name=f"L{i}",
                work_email=f"u{i}@acme.com",
                job_title=f"Title {i}",
                job_department=["Sales", "Engineering", "Marketing"][i % 3],
                seniority_level=["vp", "director", "manager", "ic"][i % 4],
                city=["SF", "NYC", "London"][i % 3],
                state=["CA", "NY", None][i % 3],
                country=["USA", "USA", "UK"][i % 3],
                company_id=i // 3 + 1,
            )
            for i in range(50)
        ]
        html = render_list_members_html(
            contacts=contacts,
            list_id="enterprise-q2",
            list_meta={"title": "Enterprise Q2 Targets"},
        )
        text = render_list_members_text_fallback(
            contacts=contacts,
            list_id="enterprise-q2",
            list_meta={"title": "Enterprise Q2 Targets"},
        )
        assert "<!DOCTYPE html>" in html
        assert "Enterprise Q2 Targets" in html
        assert "50 TOTAL" in html
        assert "+ 10 more contacts" in html
        assert "# Enterprise Q2 Targets — members" in text

    def test_single_sparse_contact_does_not_crash(self):
        c = {"id": 1}  # only id, every optional field missing
        html = render_list_members_html(contacts=[c], list_id="42")
        text = render_list_members_text_fallback(contacts=[c], list_id="42")
        assert "<!DOCTYPE html>" in html
        assert "(unnamed contact)" in html
        assert "(unnamed" in text or "unnamed" in text
