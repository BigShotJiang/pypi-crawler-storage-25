"""Unit tests for Upgrade 4 surface #40: sequence contacts HTML renderer.

Drills down from surface #30 (sequence overview) to answer the next
question after "is this sequence running?": "who is in it, in what
state, on which step?" Parallels surface #38 (list members) but for
the execution container (sequence) rather than the static list.

Design parity assertions (vs earlier surfaces):
    - Uniform 1px solid #dfdfdf border on every card
    - No single-side colored accent bars (AI-tell lock-out)
    - shadow-xs on cards
    - #7d2df3 primary + #f2eafe primary tint
    - Aeonik font stack first
"""

from __future__ import annotations

import pytest

from g8_mcp_server.app_renderer import (
    _SEQUENCE_CONTACT_STATE_PALETTE,
    _render_sequence_contacts_empty_state_html,
    _sequence_contacts_active_count,
    _sequence_contacts_bucket_states,
    _sequence_contacts_bucket_steps,
    _sequence_contacts_clip,
    _sequence_contacts_stat_card,
    _sequence_contacts_state_key,
    _sequence_contacts_state_label,
    _sequence_contacts_state_palette,
    _sequence_contacts_unique_contacts,
    render_sequence_contacts_html,
    render_sequence_contacts_text_fallback,
)

_BANNED_HEXES = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}


class TestSequenceContactsPaletteNoBannedHexes:
    """Lock test: state palette must not reintroduce banned Studio hexes."""

    def test_no_banned_hexes_in_state_palette(self):
        for key, (bg, fg) in _SEQUENCE_CONTACT_STATE_PALETTE.items():
            for value in (bg, fg):
                assert value.lower() not in _BANNED_HEXES, (
                    f"Banned hex {value!r} in _SEQUENCE_CONTACT_STATE_PALETTE[{key!r}]"
                )


def _make_contact(
    *,
    id: str = "enr_1",
    contact_id: int | None = 100,
    state: str | None = "in_progress",
    current_step_order: int | None = 1,
    created_at: str | None = "2026-04-20T10:00:00Z",
    updated_at: str | None = "2026-04-20T10:30:00Z",
) -> dict:
    return {
        "id": id,
        "contact_id": contact_id,
        "state": state,
        "current_step_order": current_step_order,
        "created_at": created_at,
        "updated_at": updated_at,
    }


# =============================================================== #
# clip                                                            #
# =============================================================== #


class TestClip:
    def test_non_string(self):
        assert _sequence_contacts_clip(None, 10) == ""
        assert _sequence_contacts_clip(42, 10) == ""

    def test_whitespace(self):
        assert _sequence_contacts_clip("  ", 10) == ""

    def test_short_pass_through_escaped(self):
        assert _sequence_contacts_clip("hi", 10) == "hi"

    def test_long_clips(self):
        out = _sequence_contacts_clip("a" * 50, 10)
        assert len(out) == 10
        assert out.endswith("\u2026")

    def test_html_escape(self):
        assert _sequence_contacts_clip("<b>", 10) == "&lt;b&gt;"


# =============================================================== #
# state_key                                                       #
# =============================================================== #


class TestStateKey:
    def test_lowercases(self):
        assert _sequence_contacts_state_key("IN_PROGRESS") == "in_progress"

    def test_strips(self):
        assert _sequence_contacts_state_key("  paused  ") == "paused"

    def test_space_to_underscore(self):
        assert _sequence_contacts_state_key("in progress") == "in_progress"

    def test_hyphen_to_underscore(self):
        assert _sequence_contacts_state_key("in-progress") == "in_progress"

    def test_empty_unknown(self):
        assert _sequence_contacts_state_key("") == "unknown"
        assert _sequence_contacts_state_key("   ") == "unknown"
        assert _sequence_contacts_state_key(None) == "unknown"
        assert _sequence_contacts_state_key(42) == "unknown"


# =============================================================== #
# state_palette                                                   #
# =============================================================== #


class TestStatePalette:
    def test_queued_primary(self):
        bg, fg = _sequence_contacts_state_palette("queued")
        assert bg == "#dbe9ff"
        assert fg == "#7d2df3"  # _G8_PRIMARY — was banned #1d4ed8

    def test_in_progress_and_active_share_primary_tint(self):
        assert _sequence_contacts_state_palette("in_progress") == \
            _sequence_contacts_state_palette("active")

    def test_completed_and_finished_share_positive(self):
        assert _sequence_contacts_state_palette("completed") == \
            _sequence_contacts_state_palette("finished")

    def test_failed_and_bounced_share_destructive(self):
        assert _sequence_contacts_state_palette("failed") == \
            _sequence_contacts_state_palette("bounced")

    def test_removed_and_stopped_share_muted(self):
        assert _sequence_contacts_state_palette("removed") == \
            _sequence_contacts_state_palette("stopped")

    def test_unknown_falls_back(self):
        bg, fg = _sequence_contacts_state_palette("some_random_state")
        assert isinstance(bg, str) and isinstance(fg, str)


# =============================================================== #
# state_label                                                     #
# =============================================================== #


class TestStateLabel:
    def test_in_progress(self):
        assert _sequence_contacts_state_label("in_progress") == "In Progress"

    def test_completed(self):
        assert _sequence_contacts_state_label("completed") == "Completed"

    def test_unknown(self):
        assert _sequence_contacts_state_label("unknown") == "Unknown"


# =============================================================== #
# bucket_states                                                   #
# =============================================================== #


class TestBucketStates:
    def test_groups_by_state(self):
        contacts = [
            _make_contact(state="in_progress"),
            _make_contact(state="in_progress"),
            _make_contact(state="completed"),
        ]
        buckets = _sequence_contacts_bucket_states(contacts)
        lookup = dict(buckets)
        assert lookup["in_progress"] == 2
        assert lookup["completed"] == 1

    def test_canonical_order_takes_precedence_over_count(self):
        """in_progress should appear before completed even if count is lower."""
        contacts = [
            _make_contact(state="in_progress"),  # count=1
            _make_contact(state="completed"),
            _make_contact(state="completed"),
            _make_contact(state="completed"),  # count=3
        ]
        buckets = _sequence_contacts_bucket_states(contacts)
        # in_progress ranks earlier in canonical order
        assert buckets[0][0] == "in_progress"
        assert buckets[1][0] == "completed"

    def test_unknown_last(self):
        contacts = [
            _make_contact(state="unknown_state"),
            _make_contact(state="unknown_state"),
            _make_contact(state="completed"),
        ]
        buckets = _sequence_contacts_bucket_states(contacts)
        # completed is in canonical order, unknown_state comes after
        assert buckets[0][0] == "completed"
        assert buckets[-1][0] == "unknown_state"

    def test_missing_state_becomes_unknown(self):
        buckets = _sequence_contacts_bucket_states([_make_contact(state=None)])
        assert ("unknown", 1) in buckets

    def test_skips_non_dicts(self):
        assert _sequence_contacts_bucket_states([None, 42, "nope"]) == []

    def test_normalizes_casing(self):
        contacts = [
            _make_contact(state="In_Progress"),
            _make_contact(state="in progress"),
        ]
        buckets = _sequence_contacts_bucket_states(contacts)
        assert dict(buckets)["in_progress"] == 2


# =============================================================== #
# bucket_steps                                                    #
# =============================================================== #


class TestBucketSteps:
    def test_groups_by_step(self):
        contacts = [
            _make_contact(current_step_order=1),
            _make_contact(current_step_order=1),
            _make_contact(current_step_order=3),
        ]
        buckets = _sequence_contacts_bucket_steps(contacts)
        assert buckets == [(1, 2), (3, 1)]

    def test_sorted_ascending(self):
        contacts = [
            _make_contact(current_step_order=5),
            _make_contact(current_step_order=1),
            _make_contact(current_step_order=3),
        ]
        buckets = _sequence_contacts_bucket_steps(contacts)
        assert [step for step, _ in buckets] == [1, 3, 5]

    def test_skips_missing(self):
        contacts = [
            _make_contact(current_step_order=None),
            _make_contact(current_step_order=1),
        ]
        buckets = _sequence_contacts_bucket_steps(contacts)
        assert buckets == [(1, 1)]

    def test_rejects_bool(self):
        # True is subclass of int
        contacts = [
            _make_contact(current_step_order=True),
            _make_contact(current_step_order=1),
        ]
        buckets = _sequence_contacts_bucket_steps(contacts)
        assert buckets == [(1, 1)]

    def test_skips_non_dicts(self):
        assert _sequence_contacts_bucket_steps([None, "x", 99]) == []


# =============================================================== #
# unique_contacts                                                 #
# =============================================================== #


class TestUniqueContacts:
    def test_counts_distinct(self):
        contacts = [
            _make_contact(contact_id=100),
            _make_contact(contact_id=100),
            _make_contact(contact_id=101),
        ]
        assert _sequence_contacts_unique_contacts(contacts) == 2

    def test_skips_none(self):
        contacts = [
            _make_contact(contact_id=None),
            _make_contact(contact_id=100),
        ]
        assert _sequence_contacts_unique_contacts(contacts) == 1

    def test_rejects_bool(self):
        contacts = [
            _make_contact(contact_id=True),
            _make_contact(contact_id=100),
        ]
        assert _sequence_contacts_unique_contacts(contacts) == 1

    def test_skips_non_dicts(self):
        assert _sequence_contacts_unique_contacts([None, 42]) == 0


# =============================================================== #
# active_count                                                    #
# =============================================================== #


class TestActiveCount:
    def test_queued_in_progress_active_paused_count(self):
        contacts = [
            _make_contact(state="queued"),
            _make_contact(state="in_progress"),
            _make_contact(state="active"),
            _make_contact(state="paused"),
            _make_contact(state="completed"),
            _make_contact(state="failed"),
        ]
        assert _sequence_contacts_active_count(contacts) == 4

    def test_empty(self):
        assert _sequence_contacts_active_count([]) == 0

    def test_skips_non_dicts(self):
        assert _sequence_contacts_active_count([None, 42]) == 0


# =============================================================== #
# stat_card                                                       #
# =============================================================== #


class TestStatCard:
    def test_four_accents(self):
        for accent in ("text", "primary", "positive", "destructive"):
            out = _sequence_contacts_stat_card("L", "V", accent=accent)
            assert "L" in out and "V" in out

    def test_uniform_border_not_single_side(self):
        out = _sequence_contacts_stat_card("L", "V", accent="primary")
        for bad in (
            "border-top:3px", "border-left:3px",
            "border-right:3px", "border-bottom:3px",
        ):
            assert bad not in out
        assert "border:1px solid #dfdfdf" in out

    def test_html_escape(self):
        out = _sequence_contacts_stat_card("<L>", "<V>", accent="text")
        assert "&lt;L&gt;" in out
        assert "&lt;V&gt;" in out

    def test_primary_accent_uses_graph8_purple(self):
        out = _sequence_contacts_stat_card("L", "V", accent="primary")
        assert "#7d2df3" in out


# =============================================================== #
# empty state                                                     #
# =============================================================== #


class TestEmptyState:
    def test_unavailable(self):
        out = _render_sequence_contacts_empty_state_html("s1", mode="unavailable")
        assert "not available" in out.lower()
        assert "s1" in out

    def test_empty(self):
        out = _render_sequence_contacts_empty_state_html("s1", mode="empty")
        assert "hasn" in out.lower() or "populate" in out.lower() or "no contacts" in out.lower()
        assert "s1" in out

    def test_xss_escaped(self):
        out = _render_sequence_contacts_empty_state_html(
            "<script>alert(1)</script>", mode="empty"
        )
        assert "<script>alert(1)</script>" not in out
        assert "&lt;script&gt;" in out


# =============================================================== #
# render_html                                                     #
# =============================================================== #


class TestRenderHtml:
    def test_none_unavailable(self):
        out = render_sequence_contacts_html(
            contacts=None, sequence_id="s1"
        )
        assert "not available" in out.lower()

    def test_empty_shows_empty_state(self):
        out = render_sequence_contacts_html(
            contacts=[], sequence_id="s1"
        )
        # empty state message
        assert "hasn" in out.lower() or "populate" in out.lower() or "no contacts" in out.lower()

    def test_single_contact_renders(self):
        out = render_sequence_contacts_html(
            contacts=[_make_contact()],
            sequence_id="s1",
        )
        assert "s1" in out
        assert "contact #100" in out
        assert "Step 1" in out
        assert "In Progress" in out

    def test_stat_cards_rendered(self):
        out = render_sequence_contacts_html(
            contacts=[
                _make_contact(contact_id=100, state="in_progress", current_step_order=1),
                _make_contact(contact_id=101, state="completed", current_step_order=3),
                _make_contact(contact_id=102, state="failed", current_step_order=2),
            ],
            sequence_id="s1",
        )
        assert "Total contacts" in out
        assert "Active" in out
        assert "Unique contact ids" in out
        assert "Distinct steps" in out

    def test_state_mix_section(self):
        out = render_sequence_contacts_html(
            contacts=[
                _make_contact(state="in_progress"),
                _make_contact(state="completed"),
            ],
            sequence_id="s1",
        )
        assert "State mix" in out
        assert "In Progress" in out
        assert "Completed" in out

    def test_step_distribution_section(self):
        out = render_sequence_contacts_html(
            contacts=[
                _make_contact(current_step_order=1),
                _make_contact(current_step_order=2),
            ],
            sequence_id="s1",
        )
        assert "Step distribution" in out
        assert "Step 1" in out
        assert "Step 2" in out

    def test_sequence_label_from_name(self):
        out = render_sequence_contacts_html(
            contacts=[_make_contact()],
            sequence_id="s1",
            sequence={"name": "Q4 outbound blast"},
        )
        assert "Q4 outbound blast" in out

    def test_sequence_label_from_title_fallback(self):
        out = render_sequence_contacts_html(
            contacts=[_make_contact()],
            sequence_id="s1",
            sequence={"title": "Alt title"},
        )
        assert "Alt title" in out

    def test_sequence_default_label(self):
        out = render_sequence_contacts_html(
            contacts=[_make_contact()],
            sequence_id="s1",
            sequence={},
        )
        assert "Sequence" in out

    def test_overflow_40(self):
        contacts = [_make_contact(id=f"enr_{i}", contact_id=i) for i in range(45)]
        out = render_sequence_contacts_html(contacts=contacts, sequence_id="s1")
        assert "enr_0" in out
        assert "enr_39" in out
        assert "enr_44" not in out
        assert "+ 5 more contacts" in out
        assert "page=2" in out

    def test_state_chip_overflow_past_8(self):
        # Create 10 unknown-but-distinct states
        contacts = [
            _make_contact(state=f"weird_state_{i}") for i in range(10)
        ]
        out = render_sequence_contacts_html(contacts=contacts, sequence_id="s1")
        assert "+ 2 more states" in out

    def test_total_chip_in_header(self):
        out = render_sequence_contacts_html(
            contacts=[_make_contact() for _ in range(7)],
            sequence_id="s1",
        )
        assert "7 TOTAL" in out

    def test_drill_up_links(self):
        out = render_sequence_contacts_html(
            contacts=[_make_contact()],
            sequence_id="s1",
        )
        assert "g8://sequences/s1/overview" in out
        assert "g8://sequences/s1/preview" in out
        assert "g8://sequences/s1/analytics" in out
        assert "g8://sequences/dashboard" in out
        assert "?state=in_progress" in out

    def test_xss_in_sequence_name_escaped(self):
        out = render_sequence_contacts_html(
            contacts=[_make_contact()],
            sequence_id="s1",
            sequence={"name": "<script>alert(1)</script>"},
        )
        assert "<script>alert(1)</script>" not in out
        assert "&lt;script&gt;" in out

    def test_xss_in_sequence_id_escaped(self):
        out = render_sequence_contacts_html(
            contacts=[_make_contact()],
            sequence_id="<script>",
        )
        assert "<script>" not in out.replace("<!DOCTYPE", "").replace("<html", "").replace("</html", "").replace("<head", "").replace("</head", "").replace("<meta", "").replace("<body", "").replace("</body", "").replace("<title>", "").replace("</title>", "").replace("<div", "").replace("</div", "").replace("<h1", "").replace("</h1", "").replace("<h2", "").replace("<p", "").replace("</p", "").replace("<ul", "").replace("</ul", "").replace("<li", "").replace("</li", "").replace("<code", "").replace("</code", "").replace("<span", "").replace("</span", "")
        # More reliable: escaped entity must be present
        assert "&lt;script&gt;" in out

    def test_no_contact_id_display(self):
        out = render_sequence_contacts_html(
            contacts=[_make_contact(contact_id=None)],
            sequence_id="s1",
        )
        assert "(no contact id)" in out

    def test_bool_contact_id_excluded_from_count(self):
        out = render_sequence_contacts_html(
            contacts=[
                _make_contact(contact_id=True),
                _make_contact(contact_id=100),
            ],
            sequence_id="s1",
        )
        # Unique count should be 1 (bool rejected)
        assert "Unique contact ids" in out

    def test_no_single_side_accent_borders(self):
        out = render_sequence_contacts_html(
            contacts=[_make_contact() for _ in range(3)],
            sequence_id="s1",
        )
        for bad in (
            "border-top:3px solid", "border-left:3px solid",
            "border-right:3px solid", "border-bottom:3px solid",
            "border-top:4px solid", "border-left:4px solid",
        ):
            assert bad not in out, f"Found AI-tell pattern: {bad}"

    def test_no_legacy_accent_hexes(self):
        out = render_sequence_contacts_html(
            contacts=[_make_contact()],
            sequence_id="s1",
        )
        assert "#4f46e5" not in out
        assert "#10b981" not in out
        assert "#ec4899" not in out

    def test_aeonik_font_present(self):
        out = render_sequence_contacts_html(
            contacts=[_make_contact()],
            sequence_id="s1",
        )
        assert "Aeonik" in out

    def test_graph8_primary_present(self):
        out = render_sequence_contacts_html(
            contacts=[_make_contact()],
            sequence_id="s1",
        )
        assert "#7d2df3" in out


# =============================================================== #
# text fallback                                                   #
# =============================================================== #


class TestTextFallback:
    def test_none_unavailable(self):
        text = render_sequence_contacts_text_fallback(
            contacts=None, sequence_id="s1"
        )
        assert "not available" in text.lower()

    def test_empty(self):
        text = render_sequence_contacts_text_fallback(
            contacts=[], sequence_id="s1"
        )
        assert "no contacts" in text.lower() or "hasn" in text.lower()
        assert "POST /sequences/s1/contacts" in text

    def test_markdown_headers(self):
        text = render_sequence_contacts_text_fallback(
            contacts=[
                _make_contact(state="in_progress", current_step_order=1),
                _make_contact(state="completed", current_step_order=3),
            ],
            sequence_id="s1",
        )
        assert "## State mix" in text
        assert "## Step distribution" in text
        assert "## Contacts" in text
        assert "## Drill into this sequence" in text

    def test_stats_rendered(self):
        text = render_sequence_contacts_text_fallback(
            contacts=[_make_contact() for _ in range(3)],
            sequence_id="s1",
        )
        assert "Total contacts: 3" in text
        assert "Active: 3" in text
        assert "Unique contact ids:" in text

    def test_contact_row_format(self):
        text = render_sequence_contacts_text_fallback(
            contacts=[_make_contact(contact_id=100, current_step_order=2)],
            sequence_id="s1",
        )
        assert "[In Progress]" in text
        assert "contact #100" in text
        assert "Step 2" in text

    def test_bool_step_rejected(self):
        text = render_sequence_contacts_text_fallback(
            contacts=[_make_contact(current_step_order=True)],
            sequence_id="s1",
        )
        assert "Step True" not in text
        assert "Step 1" not in text  # shouldn't print Step at all for bool

    def test_bool_contact_id_rejected(self):
        text = render_sequence_contacts_text_fallback(
            contacts=[_make_contact(contact_id=True)],
            sequence_id="s1",
        )
        assert "contact #True" not in text
        assert "contact #1" not in text
        assert "(no contact id)" in text

    def test_overflow_40(self):
        text = render_sequence_contacts_text_fallback(
            contacts=[_make_contact(id=f"e{i}") for i in range(50)],
            sequence_id="s1",
        )
        assert "+ 10 more contacts" in text

    def test_drill_up_pointers(self):
        text = render_sequence_contacts_text_fallback(
            contacts=[_make_contact()],
            sequence_id="s1",
        )
        assert "g8://sequences/s1/overview" in text
        assert "g8://sequences/s1/preview" in text
        assert "g8://sequences/s1/analytics" in text
        assert "g8://sequences/dashboard" in text

    def test_sequence_name(self):
        text = render_sequence_contacts_text_fallback(
            contacts=[_make_contact()],
            sequence_id="s1",
            sequence={"name": "Partner outbound"},
        )
        assert "Partner outbound" in text


# =============================================================== #
# Smoke test                                                      #
# =============================================================== #


class TestSmoke:
    def test_large_mixed_payload(self):
        states = ["queued", "in_progress", "paused", "completed", "failed", "removed"]
        contacts = [
            _make_contact(
                id=f"enr_{i}",
                contact_id=1000 + i,
                state=states[i % len(states)],
                current_step_order=(i % 5) + 1,
            )
            for i in range(30)
        ]
        html_out = render_sequence_contacts_html(
            contacts=contacts,
            sequence_id="seq_xyz",
            sequence={"name": "Q4 AE touch sequence"},
        )
        assert "Q4 AE touch sequence" in html_out
        assert "30 TOTAL" in html_out
        # Legacy accent hexes absent
        assert "#4f46e5" not in html_out
        assert "border-top:3px solid" not in html_out
        # Primary graph8 purple present
        assert "#7d2df3" in html_out

        text = render_sequence_contacts_text_fallback(
            contacts=contacts,
            sequence_id="seq_xyz",
            sequence={"name": "Q4 AE touch sequence"},
        )
        assert "Q4 AE touch sequence" in text
        assert "Total contacts: 30" in text
