"""Unit tests for Surface #82 — g8://deals/stage/{stage}.

First AXIS-filter surface on the DEALS entity family. Following the
sept-directional / dispatch-safety discipline established in #78-#81,
this surface adds:

  - A FIFTH backend-filter pattern: POST-FETCH CLIENT-SIDE BUCKETING
    (stages are per-org custom strings, so we fetch all deals and
    bucket via `_deals_stage_bucket_of` heuristic).
  - 6 canonical stages (prospecting / qualification / proposal /
    negotiation / won / lost) covering universal sales-pipeline
    terminology.
  - 4 forbidden literals (activities / pipeline / dashboard / stage)
    to prevent 3-seg dispatch collision with `/{deal_id}/activities`
    and static sibling URIs.
  - First stats row with THREE derived numeric KPIs (Total value /
    Avg deal / Oldest age) — locked by
    `test_has_total_value_and_avg_and_age`.

Tests below lock these divergences plus the usual HTML-escape, palette,
sort, overflow, empty-state, text-fallback, and smoke invariants.
"""

from __future__ import annotations

import pytest

from mcp_server.g8_mcp_server.app_renderer import (
    _DEALS_STAGE_ALIASES,
    _DEALS_STAGE_LABELS,
    _DEALS_STAGE_SHORT_LABELS,
    _DEALS_STAGE_VALID,
    _MAX_DEALS_STAGE_RENDERED,
    _deals_stage_amount,
    _deals_stage_avg_amount,
    _deals_stage_bucket_of,
    _deals_stage_clip,
    _deals_stage_currency,
    _deals_stage_display_name,
    _deals_stage_drill_up_html,
    _deals_stage_empty_state_html,
    _deals_stage_filter,
    _deals_stage_format_amount,
    _deals_stage_header_html,
    _deals_stage_kpi_card_html,
    _deals_stage_label,
    _deals_stage_list_html,
    _deals_stage_normalize,
    _deals_stage_oldest_age_days,
    _deals_stage_overflow_banner_html,
    _deals_stage_palette,
    _deals_stage_row_html,
    _deals_stage_short_label,
    _deals_stage_stats_row_html,
    _deals_stage_total_value,
    render_deals_stage_html,
    render_deals_stage_text_fallback,
)

# graph8 design tokens — any deviation from these is an AI-tell
_G8_PRIMARY = "#7d2df3"
_G8_BORDER = "#dfdfdf"
_G8_ACCENT_BG = "#f2eafe"
_G8_WARNING_BG = "#fff3c4"
_G8_POSITIVE_BG = "#d1fae5"
_G8_FONT = "Aeonik"
_BANNED_HEXES = ("#1d4ed8", "#166534", "#991b1b", "#0891b2")


# ===========================================================================
# Normalization
# ===========================================================================

class TestNormalizeCanonical:
    """All 6 canonical keys map to themselves."""

    @pytest.mark.parametrize("key", _DEALS_STAGE_VALID)
    def test_canonical_self_map(self, key):
        assert _deals_stage_normalize(key) == key

    @pytest.mark.parametrize("key", _DEALS_STAGE_VALID)
    def test_canonical_uppercase(self, key):
        assert _deals_stage_normalize(key.upper()) == key

    @pytest.mark.parametrize("key", _DEALS_STAGE_VALID)
    def test_canonical_with_spaces(self, key):
        assert _deals_stage_normalize(f"  {key}  ") == key


class TestNormalizeAliases:
    """~90 aliases resolve to their canonical bucket."""

    @pytest.mark.parametrize("alias,canonical", list(_DEALS_STAGE_ALIASES.items()))
    def test_alias_resolves(self, alias, canonical):
        assert _deals_stage_normalize(alias) == canonical

    @pytest.mark.parametrize("alias,canonical", list(_DEALS_STAGE_ALIASES.items()))
    def test_alias_case_insensitive(self, alias, canonical):
        assert _deals_stage_normalize(alias.upper()) == canonical

    def test_hyphen_underscore_swap(self):
        # 'closed_won' is in aliases; 'closed-won' should also resolve
        assert _deals_stage_normalize("closed-won") == "won"
        assert _deals_stage_normalize("closed_won") == "won"

    def test_aliases_has_50_plus(self):
        assert len(_DEALS_STAGE_ALIASES) >= 50


class TestNormalizeInvalid:
    """Invalid inputs return None without raising."""

    @pytest.mark.parametrize("raw", [
        "",
        "   ",
        "bogus",
        "not-a-stage",
        "12345",
    ])
    def test_invalid_strings(self, raw):
        assert _deals_stage_normalize(raw) is None

    @pytest.mark.parametrize("raw", [None, 123, [], {}, True])
    def test_non_string_inputs(self, raw):
        assert _deals_stage_normalize(raw) is None

    def test_no_collision_with_nested_literals(self):
        """Forbidden literals must NOT resolve to any canonical stage.

        4 forbidden literals: activities, pipeline, dashboard, stage.
        activities is critical (would collide with `/{deal_id}/activities`
        template #70 at dispatch time). The others are excluded for
        consistency / clarity.
        """
        for literal in ("activities", "pipeline", "dashboard", "stage"):
            assert _deals_stage_normalize(literal) is None
            assert _deals_stage_normalize(literal.upper()) is None
            assert _deals_stage_normalize(f"  {literal}  ") is None


class TestForbiddenLiteralsExcluded:
    """No alias or canonical key equals a forbidden literal."""

    def test_forbidden_literals_excluded(self):
        forbidden = {"activities", "pipeline", "dashboard", "stage"}
        for key in _DEALS_STAGE_VALID:
            assert key not in forbidden, (
                f"canonical key {key!r} collides with forbidden literal"
            )
        for alias in _DEALS_STAGE_ALIASES:
            assert alias not in forbidden, (
                f"alias {alias!r} collides with forbidden literal"
            )


# ===========================================================================
# Labels / short labels
# ===========================================================================

class TestLabel:
    @pytest.mark.parametrize("key", _DEALS_STAGE_VALID)
    def test_canonical_label(self, key):
        assert _deals_stage_label(key) == _DEALS_STAGE_LABELS[key]

    def test_alias_uses_canonical_label(self):
        assert _deals_stage_label("mql") == _DEALS_STAGE_LABELS["prospecting"]
        assert _deals_stage_label("closed-won") == _DEALS_STAGE_LABELS["won"]

    def test_invalid_fallback(self):
        assert _deals_stage_label("bogus") == "Deals"
        assert _deals_stage_label(None) == "Deals"

    def test_labels_complete(self):
        for key in _DEALS_STAGE_VALID:
            assert key in _DEALS_STAGE_LABELS


class TestShortLabel:
    @pytest.mark.parametrize("key", _DEALS_STAGE_VALID)
    def test_canonical(self, key):
        assert _deals_stage_short_label(key) == _DEALS_STAGE_SHORT_LABELS[key]

    def test_invalid_fallback(self):
        assert _deals_stage_short_label("bogus") == "—"


# ===========================================================================
# Palette
# ===========================================================================

class TestPalette:
    @pytest.mark.parametrize("key", _DEALS_STAGE_VALID)
    def test_returns_tuple(self, key):
        bg, fg = _deals_stage_palette(key)
        assert isinstance(bg, str) and bg.startswith("#")
        assert isinstance(fg, str) and fg.startswith("#")

    def test_proposal_is_accent(self):
        bg, fg = _deals_stage_palette("proposal")
        assert bg == _G8_ACCENT_BG
        assert fg == _G8_PRIMARY

    def test_negotiation_is_accent(self):
        bg, fg = _deals_stage_palette("negotiation")
        assert bg == _G8_ACCENT_BG
        assert fg == _G8_PRIMARY

    def test_won_is_positive(self):
        bg, _ = _deals_stage_palette("won")
        assert bg == _G8_POSITIVE_BG

    def test_prospecting_is_warning(self):
        bg, _ = _deals_stage_palette("prospecting")
        assert bg == _G8_WARNING_BG

    def test_qualification_is_warning(self):
        bg, _ = _deals_stage_palette("qualification")
        assert bg == _G8_WARNING_BG

    def test_lost_is_muted(self):
        bg, fg = _deals_stage_palette("lost")
        assert bg == "#f9f9f9"

    def test_invalid_returns_muted(self):
        bg, fg = _deals_stage_palette("bogus")
        assert bg == "#f9f9f9"

    @pytest.mark.parametrize("key", _DEALS_STAGE_VALID)
    def test_no_banned_hexes(self, key):
        bg, fg = _deals_stage_palette(key)
        for banned in _BANNED_HEXES:
            assert banned not in (bg, fg), (
                f"palette for {key!r} contains banned hex {banned!r}"
            )


# ===========================================================================
# Bucket-of (stage classification heuristic)
# ===========================================================================

class TestBucketOf:
    def test_non_dict(self):
        assert _deals_stage_bucket_of(None) is None
        assert _deals_stage_bucket_of("foo") is None

    def test_stage_type_won(self):
        assert _deals_stage_bucket_of({"stage_type": "won"}) == "won"

    def test_stage_type_lost(self):
        assert _deals_stage_bucket_of({"stage_type": "lost"}) == "lost"

    def test_empty_stage_name_defaults_prospecting(self):
        assert _deals_stage_bucket_of({"stage_name": ""}) == "prospecting"
        assert _deals_stage_bucket_of({}) == "prospecting"
        assert _deals_stage_bucket_of({"stage_name": None}) == "prospecting"

    def test_closed_won(self):
        assert _deals_stage_bucket_of({"stage_name": "Closed Won"}) == "won"
        assert _deals_stage_bucket_of({"stage_name": "closed-won"}) == "won"
        assert _deals_stage_bucket_of({"stage_name": "CLOSEDWON"}) == "won"

    def test_closed_lost(self):
        assert _deals_stage_bucket_of({"stage_name": "Closed Lost"}) == "lost"
        assert _deals_stage_bucket_of({"stage_name": "abandoned"}) == "lost"

    def test_negotiation_keywords(self):
        for kw in [
            "Negotiation",
            "Contract Sent",
            "Legal Review",
            "Procurement",
            "Red Lines",
            "Verbal Commit",
            "Awaiting Signature",
        ]:
            assert _deals_stage_bucket_of({"stage_name": kw}) == "negotiation"

    def test_proposal_keywords(self):
        for kw in [
            "Proposal Sent",
            "Quote",
            "Pricing Review",
            "POC",
            "Pilot",
            "Evaluation Phase",
        ]:
            assert _deals_stage_bucket_of({"stage_name": kw}) == "proposal"

    def test_qualification_keywords(self):
        for kw in [
            "Qualification",
            "Demo Scheduled",
            "Meeting Set",
            "SQL",
            "Needs Analysis",
            "BANT",
            "MEDDIC",
            "Discovery Call",
        ]:
            assert _deals_stage_bucket_of({"stage_name": kw}) == "qualification"

    def test_prospecting_default(self):
        for kw in ["Lead", "MQL", "New Lead", "Initial Contact", "Outreach"]:
            # These may or may not match prospecting keywords, but they should
            # at minimum default to prospecting (not None)
            result = _deals_stage_bucket_of({"stage_name": kw})
            assert result == "prospecting"

    def test_won_wins_over_close(self):
        # stage_name containing 'won' short-circuits before 'closed-lost'
        assert _deals_stage_bucket_of({"stage_name": "Closed Won"}) == "won"

    def test_stage_type_overrides_name(self):
        """Backend-explicit stage_type wins over name heuristic."""
        assert (
            _deals_stage_bucket_of(
                {"stage_type": "won", "stage_name": "Negotiation"}
            )
            == "won"
        )


# ===========================================================================
# Filter
# ===========================================================================

class TestFilter:
    def test_empty_list(self):
        assert _deals_stage_filter([], "won") == []

    def test_invalid_stage(self):
        assert _deals_stage_filter([{"stage_name": "Won"}], "bogus") == []

    def test_non_list(self):
        assert _deals_stage_filter(None, "won") == []

    def test_matches_only_bucket(self):
        deals = [
            {"name": "W", "stage_name": "Closed Won"},
            {"name": "L", "stage_name": "Closed Lost"},
            {"name": "M", "stage_name": "MQL"},
        ]
        won = _deals_stage_filter(deals, "won")
        assert len(won) == 1
        assert won[0]["name"] == "W"

    def test_alias_filters_same_bucket(self):
        deals = [{"name": "W", "stage_name": "Closed Won"}]
        assert len(_deals_stage_filter(deals, "closed-won")) == 1

    def test_skips_non_dict_entries(self):
        deals = [{"stage_name": "Closed Won"}, "invalid", None, 42]
        assert len(_deals_stage_filter(deals, "won")) == 1


# ===========================================================================
# Amount
# ===========================================================================

class TestAmount:
    def test_non_dict(self):
        assert _deals_stage_amount(None) is None

    def test_int_amount(self):
        assert _deals_stage_amount({"amount": 5000}) == 5000

    def test_float_amount(self):
        assert _deals_stage_amount({"amount": 5000.5}) == 5000.5

    def test_string_amount_with_dollar(self):
        assert _deals_stage_amount({"amount": "$5,000"}) == 5000.0

    def test_fallback_fields(self):
        assert _deals_stage_amount({"value": 100}) == 100
        assert _deals_stage_amount({"deal_value": 200}) == 200
        assert _deals_stage_amount({"total_value": 300}) == 300

    def test_bool_rejected(self):
        assert _deals_stage_amount({"amount": True}) is None

    def test_negative_rejected(self):
        assert _deals_stage_amount({"amount": -100}) is None
        assert _deals_stage_amount({"amount": "-100"}) is None

    def test_nan_rejected(self):
        assert _deals_stage_amount({"amount": float("nan")}) is None
        assert _deals_stage_amount({"amount": float("inf")}) is None

    def test_empty_string(self):
        assert _deals_stage_amount({"amount": ""}) is None


# ===========================================================================
# Format amount
# ===========================================================================

class TestFormatAmount:
    def test_none(self):
        assert _deals_stage_format_amount(None) == "—"

    def test_nan(self):
        assert _deals_stage_format_amount(float("nan")) == "—"

    def test_negative(self):
        assert _deals_stage_format_amount(-100) == "—"

    def test_sub_1k(self):
        assert _deals_stage_format_amount(42) == "$42"

    def test_1k(self):
        assert _deals_stage_format_amount(1000) == "$1K"

    def test_500k(self):
        assert _deals_stage_format_amount(500000) == "$500K"

    def test_1m(self):
        assert _deals_stage_format_amount(1_000_000) == "$1.0M"

    def test_45m(self):
        assert _deals_stage_format_amount(45_000_000) == "$45.0M"

    def test_2b(self):
        assert _deals_stage_format_amount(2_300_000_000) == "$2.3B"

    def test_non_usd_currency(self):
        assert _deals_stage_format_amount(1000, "EUR") == "EUR 1K"


# ===========================================================================
# Total value / avg / oldest age
# ===========================================================================

class TestTotalValue:
    def test_empty(self):
        assert _deals_stage_total_value([]) == 0

    def test_sum(self):
        deals = [{"amount": 100}, {"amount": 200}, {"amount": 300}]
        assert _deals_stage_total_value(deals) == 600

    def test_skips_none(self):
        deals = [{"amount": 100}, {"amount": None}, {"amount": 200}]
        assert _deals_stage_total_value(deals) == 300


class TestAvgAmount:
    def test_empty(self):
        assert _deals_stage_avg_amount([]) is None

    def test_all_none(self):
        assert _deals_stage_avg_amount([{"amount": None}]) is None

    def test_avg(self):
        deals = [{"amount": 100}, {"amount": 200}, {"amount": 300}]
        assert _deals_stage_avg_amount(deals) == 200

    def test_zero_excluded(self):
        deals = [{"amount": 0}, {"amount": 100}]
        assert _deals_stage_avg_amount(deals) == 100


class TestOldestAgeDays:
    def test_empty(self):
        assert _deals_stage_oldest_age_days([]) is None

    def test_all_missing(self):
        assert _deals_stage_oldest_age_days([{"name": "x"}]) is None

    def test_days_positive(self):
        from datetime import datetime, timedelta, timezone

        past = (datetime.now(timezone.utc) - timedelta(days=30)).isoformat()
        deals = [{"created_at": past}]
        assert _deals_stage_oldest_age_days(deals) >= 29


# ===========================================================================
# Clip
# ===========================================================================

class TestClip:
    def test_none(self):
        assert _deals_stage_clip(None) == ""

    def test_empty(self):
        assert _deals_stage_clip("") == ""

    def test_trim(self):
        assert _deals_stage_clip("  hi  ") == "hi"

    def test_escape(self):
        assert _deals_stage_clip("<script>") == "&lt;script&gt;"

    def test_cap(self):
        assert _deals_stage_clip("x" * 200, cap=10) == "x" * 10 + "…"

    def test_non_string_castable(self):
        assert _deals_stage_clip(42) == "42"


# ===========================================================================
# Display name
# ===========================================================================

class TestDisplayName:
    def test_none(self):
        assert _deals_stage_display_name(None) == "(unnamed deal)"

    def test_name_preferred(self):
        assert _deals_stage_display_name({"name": "Acme"}) == "Acme"

    def test_title_fallback(self):
        assert _deals_stage_display_name({"title": "Beta"}) == "Beta"

    def test_deal_name_fallback(self):
        assert _deals_stage_display_name({"deal_name": "Gamma"}) == "Gamma"

    def test_empty_fallback(self):
        assert _deals_stage_display_name({}) == "(unnamed deal)"


# ===========================================================================
# HTML building blocks
# ===========================================================================

class TestHeader:
    @pytest.mark.parametrize("key", _DEALS_STAGE_VALID)
    def test_renders(self, key):
        out = _deals_stage_header_html(key, 5)
        assert "<h1" in out
        assert "5 deals" in out
        assert "stage ·" in out

    def test_singular_deal(self):
        out = _deals_stage_header_html("won", 1)
        assert "1 deal" in out
        assert "1 deals" not in out

    def test_zero(self):
        out = _deals_stage_header_html("won", 0)
        assert "0 deals" in out


class TestKpiCard:
    def test_renders(self):
        out = _deals_stage_kpi_card_html("Total", 42)
        assert "Total" in out
        assert "42" in out

    def test_accent(self):
        out = _deals_stage_kpi_card_html("Total", 42, accent=True)
        assert _G8_ACCENT_BG in out


class TestStatsRow:
    def test_non_list(self):
        out = _deals_stage_stats_row_html(None)
        assert "Total" in out

    def test_empty(self):
        out = _deals_stage_stats_row_html([])
        assert "Total" in out
        assert "Total value" in out
        assert "Avg deal" in out
        assert "Oldest" in out

    def test_has_total_value_and_avg_and_age(self):
        """LOCK: Stats row must show 4 cards: Total / Total value / Avg / Oldest.

        First surface with THREE derived numeric KPIs — divergence from
        #78-#81 which had count-based stats rows.
        """
        deals = [{"amount": 100}, {"amount": 200}]
        out = _deals_stage_stats_row_html(deals)
        assert "Total" in out
        assert "Total value" in out
        assert "Avg deal" in out
        assert "Oldest" in out

    def test_formats_total_value(self):
        deals = [{"amount": 1_000_000}]
        out = _deals_stage_stats_row_html(deals)
        assert "$1.0M" in out

    def test_skips_non_dict(self):
        out = _deals_stage_stats_row_html([{"amount": 100}, "bad", None])
        assert "Total" in out


class TestRow:
    def test_renders(self):
        out = _deals_stage_row_html({"name": "Acme", "amount": 5000})
        assert "Acme" in out
        assert "$5K" in out

    def test_xss_name(self):
        out = _deals_stage_row_html({"name": "<script>alert(1)</script>"})
        assert "<script>alert" not in out
        assert "&lt;script&gt;" in out

    def test_missing_amount(self):
        out = _deals_stage_row_html({"name": "x"})
        assert "x" in out
        # Amount chip should be absent
        assert "$" not in out or "margin-top:6px" in out

    def test_close_date(self):
        out = _deals_stage_row_html({
            "name": "x", "close_date": "2026-06-30"
        })
        assert "Close: 2026-06-30" in out


class TestList:
    def test_empty(self):
        assert _deals_stage_list_html([]) == ""

    def test_caps_at_max(self):
        deals = [{"name": f"d{i}", "amount": 100} for i in range(200)]
        out = _deals_stage_list_html(deals)
        assert out.count("d0\"") <= 1  # safety — simple smoke
        # Verify cap: 100 rendered deals
        assert out.count("padding:12px 16px;") == _MAX_DEALS_STAGE_RENDERED


class TestOverflowBanner:
    def test_no_banner_under_cap(self):
        assert _deals_stage_overflow_banner_html(50, "won") == ""

    def test_banner_over_cap(self):
        out = _deals_stage_overflow_banner_html(150, "won")
        assert "+50 more" in out

    def test_banner_references_backend(self):
        out = _deals_stage_overflow_banner_html(150, "won")
        assert "GET /deals?limit=200" in out


class TestDrillUp:
    @pytest.mark.parametrize("key", _DEALS_STAGE_VALID)
    def test_renders(self, key):
        out = _deals_stage_drill_up_html(key)
        assert "Related surfaces" in out

    def test_includes_pipeline_and_dashboard(self):
        """LOCK: drill-up must link to both g8://deals/pipeline and dashboard."""
        out = _deals_stage_drill_up_html("won")
        assert "g8://deals/dashboard" in out
        assert "g8://deals/pipeline" in out

    def test_includes_all_siblings(self):
        out = _deals_stage_drill_up_html("won")
        for sibling in _DEALS_STAGE_VALID:
            if sibling == "won":
                continue
            assert f"g8://deals/stage/{sibling}" in out

    def test_no_self_reference(self):
        out = _deals_stage_drill_up_html("won")
        # The self-reference should not appear as its own link
        # (we skip it in the sibling loop)
        # Header will mention "stage · Won" in the page header but not here
        assert out.count("g8://deals/stage/won") == 0

    def test_cross_entity_link_to_contacts(self):
        """LOCK: drill-up includes cross-entity link to contacts/dashboard."""
        out = _deals_stage_drill_up_html("won")
        assert "g8://contacts/dashboard" in out


class TestEmptyState:
    def test_unavailable(self):
        out = _deals_stage_empty_state_html("bogus", "unavailable")
        assert "Stage not recognized" in out
        assert "prospecting" in out
        assert "won" in out

    def test_empty(self):
        out = _deals_stage_empty_state_html("won", "empty")
        assert "No Won deals" in out


# ===========================================================================
# Main renderer
# ===========================================================================

class TestRenderHtml:
    def test_unavailable(self):
        out = render_deals_stage_html(deals=[], stage="bogus")
        assert "Stage not recognized" in out
        assert "<!DOCTYPE html>" in out

    def test_empty(self):
        out = render_deals_stage_html(deals=[], stage="won")
        assert "No Won deals right now" in out

    def test_renders_deals(self):
        deals = [{"name": "Acme", "stage_name": "Closed Won", "amount": 50000}]
        out = render_deals_stage_html(deals=deals, stage="won")
        assert "Acme" in out
        assert "$50K" in out

    def test_sort_by_amount_desc(self):
        """LOCK: sort order is (-amount, close_date, name)."""
        deals = [
            {"name": "Small", "stage_name": "Closed Won", "amount": 100},
            {"name": "Big",   "stage_name": "Closed Won", "amount": 1000000},
            {"name": "Mid",   "stage_name": "Closed Won", "amount": 50000},
        ]
        out = render_deals_stage_html(deals=deals, stage="won")
        i_big = out.index("Big")
        i_mid = out.index("Mid")
        i_small = out.index("Small")
        assert i_big < i_mid < i_small, (
            f"expected Big < Mid < Small; got {i_big}, {i_mid}, {i_small}"
        )

    def test_xss_in_deal_name(self):
        deals = [{
            "name": "<script>alert(1)</script>",
            "stage_name": "Closed Won",
        }]
        out = render_deals_stage_html(deals=deals, stage="won")
        assert "<script>alert" not in out

    def test_alias_routed(self):
        deals = [{"name": "X", "stage_name": "Closed Won"}]
        out = render_deals_stage_html(deals=deals, stage="closed-won")
        assert "X" in out

    def test_invalid_companies_none(self):
        out = render_deals_stage_html(deals=None, stage="won")
        assert "No Won deals" in out


class TestDesignTokens:
    @pytest.mark.parametrize("banned", _BANNED_HEXES)
    @pytest.mark.parametrize("stage", _DEALS_STAGE_VALID)
    def test_no_banned_hexes(self, banned, stage):
        out = render_deals_stage_html(
            deals=[{"name": "X", "stage_name": "Closed Won"}], stage=stage
        )
        assert banned not in out, (
            f"rendered HTML for stage={stage} contains banned hex {banned}"
        )

    def test_uses_graph8_primary(self):
        deals = [{"name": "X", "stage_name": "Proposal Sent", "amount": 100}]
        out = render_deals_stage_html(deals=deals, stage="proposal")
        assert _G8_PRIMARY in out

    def test_uses_aeonik_font(self):
        out = render_deals_stage_html(
            deals=[{"name": "X"}], stage="won"
        )
        assert "Aeonik" in out

    def test_uses_graph8_border(self):
        out = render_deals_stage_html(
            deals=[{"name": "X"}], stage="won"
        )
        assert _G8_BORDER in out


class TestNoJs:
    def test_no_script_tags(self):
        out = render_deals_stage_html(
            deals=[{"name": "X"}], stage="won"
        )
        assert "<script" not in out

    def test_no_inline_handlers(self):
        out = render_deals_stage_html(
            deals=[{"name": "X"}], stage="won"
        )
        # onclick, onload, etc.
        for handler in ("onclick=", "onload=", "onerror=", "onmouseover="):
            assert handler not in out


# ===========================================================================
# Text fallback
# ===========================================================================

class TestTextFallback:
    def test_unavailable(self):
        out = render_deals_stage_text_fallback(deals=[], stage="bogus")
        assert "stage not recognized" in out.lower()
        assert "prospecting" in out

    def test_empty(self):
        out = render_deals_stage_text_fallback(deals=[], stage="won")
        assert "No Won deals right now" in out

    def test_renders_deals(self):
        deals = [{"name": "X", "stage_name": "Closed Won", "amount": 500}]
        out = render_deals_stage_text_fallback(deals=deals, stage="won")
        assert "X" in out
        assert "$500" in out

    def test_sort_matches_html(self):
        deals = [
            {"name": "Small", "stage_name": "Closed Won", "amount": 100},
            {"name": "Big",   "stage_name": "Closed Won", "amount": 1000000},
        ]
        out = render_deals_stage_text_fallback(deals=deals, stage="won")
        assert out.index("Big") < out.index("Small")

    def test_backend_filter_noted(self):
        out = render_deals_stage_text_fallback(
            deals=[{"stage_name": "Closed Won"}], stage="won"
        )
        assert "GET /deals?limit=200" in out

    def test_related_siblings_listed(self):
        out = render_deals_stage_text_fallback(
            deals=[{"stage_name": "Closed Won"}], stage="won"
        )
        for sibling in _DEALS_STAGE_VALID:
            if sibling == "won":
                continue
            assert f"g8://deals/stage/{sibling}" in out

    def test_cross_entity_link_to_contacts(self):
        out = render_deals_stage_text_fallback(
            deals=[{"stage_name": "Closed Won"}], stage="won"
        )
        assert "g8://contacts/dashboard" in out

    def test_pipeline_and_dashboard_links(self):
        out = render_deals_stage_text_fallback(
            deals=[{"stage_name": "Closed Won"}], stage="won"
        )
        assert "g8://deals/dashboard" in out
        assert "g8://deals/pipeline" in out


# ===========================================================================
# Smoke: render all canonical + all aliases successfully
# ===========================================================================

class TestSmoke:
    @pytest.mark.parametrize("key", _DEALS_STAGE_VALID)
    def test_html_canonical_renders(self, key):
        out = render_deals_stage_html(
            deals=[{"name": "X", "stage_name": "Closed Won"}], stage=key
        )
        assert "<!DOCTYPE html>" in out

    @pytest.mark.parametrize("key", _DEALS_STAGE_VALID)
    def test_text_canonical_renders(self, key):
        out = render_deals_stage_text_fallback(
            deals=[{"name": "X", "stage_name": "Closed Won"}], stage=key
        )
        assert isinstance(out, str) and out.endswith("\n")

    @pytest.mark.parametrize("alias", list(_DEALS_STAGE_ALIASES.keys()))
    def test_html_alias_renders(self, alias):
        out = render_deals_stage_html(deals=[], stage=alias)
        assert "<!DOCTYPE html>" in out

    @pytest.mark.parametrize("alias", list(_DEALS_STAGE_ALIASES.keys()))
    def test_text_alias_renders(self, alias):
        out = render_deals_stage_text_fallback(deals=[], stage=alias)
        assert isinstance(out, str)


# ===========================================================================
# Constants invariants
# ===========================================================================

class TestConstants:
    def test_6_canonical(self):
        assert len(_DEALS_STAGE_VALID) == 6

    def test_labels_complete(self):
        for key in _DEALS_STAGE_VALID:
            assert key in _DEALS_STAGE_LABELS
            assert key in _DEALS_STAGE_SHORT_LABELS

    def test_aliases_target_valid(self):
        for alias, canonical in _DEALS_STAGE_ALIASES.items():
            assert canonical in _DEALS_STAGE_VALID

    def test_no_alias_equals_canonical(self):
        for alias in _DEALS_STAGE_ALIASES:
            assert alias not in _DEALS_STAGE_VALID, (
                f"alias {alias!r} duplicates a canonical key"
            )

    def test_aliases_has_50_plus(self):
        assert len(_DEALS_STAGE_ALIASES) >= 50

    def test_max_rendered(self):
        assert _MAX_DEALS_STAGE_RENDERED == 100

    def test_no_canonical_collides_with_nested_literals(self):
        forbidden = {"activities", "pipeline", "dashboard", "stage"}
        for key in _DEALS_STAGE_VALID:
            assert key not in forbidden

    def test_no_alias_collides_with_nested_literals(self):
        forbidden = {"activities", "pipeline", "dashboard", "stage"}
        for alias in _DEALS_STAGE_ALIASES:
            assert alias not in forbidden
