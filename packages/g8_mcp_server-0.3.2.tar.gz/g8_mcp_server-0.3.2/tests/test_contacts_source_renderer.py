"""Tests for Surface #85 — g8://contacts/source/{channel} renderer.

Fourth axis-filter on the CONTACTS entity (companion to #76 seniority,
#77 department, #84 engagement). Uses EXACT backend match on a
canonical source channel — hybrid of #78 industry (ILIKE) and #82
stage (canonical + aliases) but with a TRUE backend filter (no
client-side bucketing once fetched).

Locks:
- 12 canonical channels: referral / paid / organic / events / inbound /
  outbound / partner / direct / social / webinar / import / other
- ~80 aliases (seo/ppc/linkedin-ads/cold-email/conference/etc.)
- 9 forbidden literals: dashboard, notes, tasks, deals, activities,
  seniority, department, engagement, source (self)
- NEW stats signature for contacts: Total / Companies / With email /
  Email coverage % (4 acquisition-quality KPIs)
- Palette: positive-green (referral/partner), accent-purple (inbound/
  webinar), warning-amber (paid/outbound), muted everything else
- Sort: (company_name ASC, name ASC) — grouped by company
- Drill-up: dashboard + 4 siblings + 2 cross-axis (engagement/hot +
  seniority/c-level) + cross-entity (deals/pipeline)
"""
from __future__ import annotations

import pytest

from mcp_server.g8_mcp_server.app_renderer import (
    _CONTACTS_SOURCE_ALIASES,
    _CONTACTS_SOURCE_DESCRIPTIONS,
    _CONTACTS_SOURCE_FORBIDDEN,
    _CONTACTS_SOURCE_LABELS,
    _CONTACTS_SOURCE_SHORT_LABELS,
    _CONTACTS_SOURCE_VALID,
    _MAX_CONTACTS_SOURCE_RENDERED,
    _contacts_source_clip,
    _contacts_source_description,
    _contacts_source_display_name,
    _contacts_source_distinct_companies,
    _contacts_source_drill_up_html,
    _contacts_source_empty_state_html,
    _contacts_source_filter,
    _contacts_source_header_html,
    _contacts_source_label,
    _contacts_source_list_html,
    _contacts_source_normalize,
    _contacts_source_of,
    _contacts_source_overflow_banner_html,
    _contacts_source_palette,
    _contacts_source_row_html,
    _contacts_source_short_label,
    _contacts_source_stats_row_html,
    _contacts_source_with_email_count,
    render_contacts_source_html,
    render_contacts_source_text_fallback,
)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------


class TestConstants:
    def test_valid_channels_count(self):
        assert len(_CONTACTS_SOURCE_VALID) == 12

    def test_valid_channels_exact(self):
        assert _CONTACTS_SOURCE_VALID == (
            "referral", "paid", "organic", "events", "inbound", "outbound",
            "partner", "direct", "social", "webinar", "import", "other",
        )

    def test_labels_cover_canonical(self):
        for key in _CONTACTS_SOURCE_VALID:
            assert key in _CONTACTS_SOURCE_LABELS

    def test_short_labels_cover_canonical(self):
        for key in _CONTACTS_SOURCE_VALID:
            assert key in _CONTACTS_SOURCE_SHORT_LABELS

    def test_descriptions_cover_canonical(self):
        for key in _CONTACTS_SOURCE_VALID:
            assert key in _CONTACTS_SOURCE_DESCRIPTIONS

    def test_max_rendered_cap(self):
        assert _MAX_CONTACTS_SOURCE_RENDERED == 100

    def test_forbidden_count(self):
        assert len(_CONTACTS_SOURCE_FORBIDDEN) == 9

    def test_forbidden_exact(self):
        assert set(_CONTACTS_SOURCE_FORBIDDEN) == {
            "dashboard", "notes", "tasks", "deals", "activities",
            "seniority", "department", "engagement", "source",
        }

    def test_aliases_non_empty(self):
        assert len(_CONTACTS_SOURCE_ALIASES) >= 60

    def test_aliases_all_target_canonical(self):
        for target in _CONTACTS_SOURCE_ALIASES.values():
            assert target in _CONTACTS_SOURCE_VALID


# ---------------------------------------------------------------------------
# Normalize — canonical
# ---------------------------------------------------------------------------


class TestNormalize:
    @pytest.mark.parametrize("key", list(_CONTACTS_SOURCE_VALID))
    def test_canonical_passthrough(self, key):
        assert _contacts_source_normalize(key) == key

    @pytest.mark.parametrize("raw, expected", [
        ("REFERRAL", "referral"),
        ("Paid", "paid"),
        ("Organic", "organic"),
        ("EVENTS", "events"),
        ("Inbound", "inbound"),
    ])
    def test_case_insensitive(self, raw, expected):
        assert _contacts_source_normalize(raw) == expected

    @pytest.mark.parametrize("raw, expected", [
        ("  referral  ", "referral"),
        ("\tpaid\n", "paid"),
    ])
    def test_whitespace_stripped(self, raw, expected):
        assert _contacts_source_normalize(raw) == expected


class TestNormalizeAliases:
    @pytest.mark.parametrize("alias", [
        "ref", "refer", "referrals", "intro", "introduction",
        "word-of-mouth", "word_of_mouth", "wom",
    ])
    def test_referral_aliases(self, alias):
        assert _contacts_source_normalize(alias) == "referral"

    @pytest.mark.parametrize("alias", [
        "ads", "ad", "advertising", "ppc", "sem",
        "google-ads", "google_ads", "facebook-ads", "facebook_ads",
        "meta-ads", "meta_ads", "linkedin-ads", "linkedin_ads",
        "adwords", "paid-ads", "paid_ads", "paid-search",
        "paid_search", "paid-social", "paid_social", "retargeting",
    ])
    def test_paid_aliases(self, alias):
        assert _contacts_source_normalize(alias) == "paid"

    @pytest.mark.parametrize("alias", [
        "seo", "search", "google", "content", "blog",
        "article", "guide", "organic-search", "organic_search",
    ])
    def test_organic_aliases(self, alias):
        assert _contacts_source_normalize(alias) == "organic"

    @pytest.mark.parametrize("alias", [
        "event", "conference", "conf", "booth", "field",
        "expo", "tradeshow", "trade-show", "trade_show", "meetup",
    ])
    def test_events_aliases(self, alias):
        assert _contacts_source_normalize(alias) == "events"

    @pytest.mark.parametrize("alias", [
        "form", "contact-form", "contact_form", "demo-request",
        "demo_request", "trial", "signup", "self-serve", "self_serve",
    ])
    def test_inbound_aliases(self, alias):
        assert _contacts_source_normalize(alias) == "inbound"

    @pytest.mark.parametrize("alias", [
        "cold", "cold-outreach", "cold_outreach", "cold-email",
        "cold_email", "prospecting", "sdr", "bdr", "sales",
    ])
    def test_outbound_aliases(self, alias):
        assert _contacts_source_normalize(alias) == "outbound"

    @pytest.mark.parametrize("alias", [
        "affiliate", "reseller", "alliance", "channel", "partners",
    ])
    def test_partner_aliases(self, alias):
        assert _contacts_source_normalize(alias) == "partner"

    @pytest.mark.parametrize("alias", [
        "brand", "homepage", "landing", "typed-url", "typed_url",
    ])
    def test_direct_aliases(self, alias):
        assert _contacts_source_normalize(alias) == "direct"

    @pytest.mark.parametrize("alias", [
        "linkedin", "twitter", "x", "facebook", "instagram",
        "reddit", "youtube", "tiktok", "social-media", "social_media",
    ])
    def test_social_aliases(self, alias):
        assert _contacts_source_normalize(alias) == "social"

    @pytest.mark.parametrize("alias", [
        "webinars", "virtual-event", "virtual_event", "demo",
    ])
    def test_webinar_aliases(self, alias):
        assert _contacts_source_normalize(alias) == "webinar"

    @pytest.mark.parametrize("alias", [
        "imports", "bulk", "csv", "list", "apollo", "zoominfo", "enrichment",
    ])
    def test_import_aliases(self, alias):
        assert _contacts_source_normalize(alias) == "import"

    @pytest.mark.parametrize("alias", [
        "misc", "unknown", "unclassified", "null", "none", "n/a",
    ])
    def test_other_aliases(self, alias):
        assert _contacts_source_normalize(alias) == "other"


class TestNormalizeInvalid:
    @pytest.mark.parametrize("raw", [
        None, 0, True, False, [], {}, 1.5, b"paid",
    ])
    def test_non_string_returns_none(self, raw):
        assert _contacts_source_normalize(raw) is None

    @pytest.mark.parametrize("raw", ["", "   ", "\t", "\n"])
    def test_empty_returns_none(self, raw):
        assert _contacts_source_normalize(raw) is None

    @pytest.mark.parametrize("raw", [
        "fluffy-clouds", "banana", "not-a-channel-123", "chipotle",
    ])
    def test_unknown_returns_none(self, raw):
        assert _contacts_source_normalize(raw) is None


class TestForbiddenLiterals:
    @pytest.mark.parametrize("forbidden", list(_CONTACTS_SOURCE_FORBIDDEN))
    def test_each_forbidden_returns_none(self, forbidden):
        assert _contacts_source_normalize(forbidden) is None

    @pytest.mark.parametrize("forbidden", list(_CONTACTS_SOURCE_FORBIDDEN))
    def test_case_variants_return_none(self, forbidden):
        assert _contacts_source_normalize(forbidden.upper()) is None
        assert _contacts_source_normalize(forbidden.title()) is None

    def test_dashboard_blocked(self):
        assert _contacts_source_normalize("dashboard") is None

    def test_self_name_blocked(self):
        assert _contacts_source_normalize("source") is None

    def test_engagement_sibling_blocked(self):
        # engagement is #84 axis sibling — must not be valid here
        assert _contacts_source_normalize("engagement") is None


# ---------------------------------------------------------------------------
# Labels / palette / descriptions
# ---------------------------------------------------------------------------


class TestLabels:
    @pytest.mark.parametrize("key", list(_CONTACTS_SOURCE_VALID))
    def test_label_capitalized(self, key):
        assert _contacts_source_label(key) == _CONTACTS_SOURCE_LABELS[key]

    def test_invalid_default(self):
        assert _contacts_source_label("fluffy") == "Contacts"

    def test_none_default(self):
        assert _contacts_source_label(None) == "Contacts"

    @pytest.mark.parametrize("key", list(_CONTACTS_SOURCE_VALID))
    def test_short_label(self, key):
        assert _contacts_source_short_label(key) == _CONTACTS_SOURCE_SHORT_LABELS[key]

    def test_short_label_default(self):
        assert _contacts_source_short_label("xxx") == "—"


class TestDescriptions:
    @pytest.mark.parametrize("key", list(_CONTACTS_SOURCE_VALID))
    def test_description_non_empty(self, key):
        d = _contacts_source_description(key)
        assert d and isinstance(d, str)

    def test_unknown_empty(self):
        assert _contacts_source_description("xxx") == ""


class TestPalette:
    @pytest.mark.parametrize("key", ["referral", "partner"])
    def test_trusted_channels_positive_green(self, key):
        bg, fg = _contacts_source_palette(key)
        assert bg == "#d1fae5"

    @pytest.mark.parametrize("key", ["inbound", "webinar"])
    def test_self_serve_accent_purple(self, key):
        bg, fg = _contacts_source_palette(key)
        assert bg == "#f2eafe"

    @pytest.mark.parametrize("key", ["paid", "outbound"])
    def test_investment_warning_amber(self, key):
        bg, fg = _contacts_source_palette(key)
        assert bg == "#fff3c4"

    @pytest.mark.parametrize("key", [
        "organic", "events", "direct", "social", "import", "other",
    ])
    def test_rest_muted(self, key):
        bg, fg = _contacts_source_palette(key)
        assert bg == "#f9f9f9"

    def test_invalid_muted(self):
        bg, fg = _contacts_source_palette("xxx")
        assert bg == "#f9f9f9"

    def test_palette_returns_tuple(self):
        for key in _CONTACTS_SOURCE_VALID:
            r = _contacts_source_palette(key)
            assert isinstance(r, tuple) and len(r) == 2


# ---------------------------------------------------------------------------
# _contacts_source_of — extract field
# ---------------------------------------------------------------------------


class TestSourceOf:
    @pytest.mark.parametrize("field", [
        "source", "lead_source", "acquisition_source", "channel",
    ])
    def test_each_field_extracted(self, field):
        assert _contacts_source_of({field: "referral"}) == "referral"

    def test_alias_resolved(self):
        assert _contacts_source_of({"source": "seo"}) == "organic"

    def test_unknown_string_falls_to_other(self):
        # non-canonical, non-alias → "other"
        assert _contacts_source_of({"source": "some-wild-value"}) == "other"

    def test_empty_string(self):
        assert _contacts_source_of({"source": ""}) is None

    def test_missing_returns_none(self):
        assert _contacts_source_of({}) is None

    def test_non_dict(self):
        assert _contacts_source_of("str") is None

    def test_non_string_value_skipped(self):
        # int source field is skipped, falls through to next candidate field
        assert _contacts_source_of({"source": 42}) is None


# ---------------------------------------------------------------------------
# Filter
# ---------------------------------------------------------------------------


class TestFilter:
    def test_referral_only(self):
        contacts = [
            {"first_name": "A", "source": "referral"},
            {"first_name": "B", "source": "paid"},
            {"first_name": "C", "source": "referral"},
        ]
        r = _contacts_source_filter(contacts, "referral")
        assert len(r) == 2
        assert {c["first_name"] for c in r} == {"A", "C"}

    def test_alias_normalization(self):
        contacts = [{"first_name": "X", "source": "seo"}]
        r = _contacts_source_filter(contacts, "organic")
        assert len(r) == 1

    def test_non_canonical_value_bucketed_as_other(self):
        contacts = [
            {"first_name": "X", "source": "wild"},
            {"first_name": "Y", "source": "other"},
        ]
        r = _contacts_source_filter(contacts, "other")
        assert len(r) == 2

    def test_invalid_channel(self):
        assert _contacts_source_filter(
            [{"first_name": "A", "source": "referral"}],
            "xxx",
        ) == []

    def test_none_contacts(self):
        assert _contacts_source_filter(None, "referral") == []

    def test_non_list_contacts(self):
        assert _contacts_source_filter({"x": 1}, "referral") == []

    def test_non_dict_items_skipped(self):
        contacts = [
            {"first_name": "A", "source": "referral"},
            "bad",
            None,
            42,
        ]
        r = _contacts_source_filter(contacts, "referral")
        assert len(r) == 1

    def test_contact_without_source_excluded(self):
        contacts = [
            {"first_name": "A", "source": "referral"},
            {"first_name": "B"},  # no source field
        ]
        r = _contacts_source_filter(contacts, "referral")
        assert len(r) == 1


# ---------------------------------------------------------------------------
# Aggregate helpers
# ---------------------------------------------------------------------------


class TestAggregates:
    def test_distinct_companies_count(self):
        contacts = [
            {"company_name": "Acme"},
            {"company_name": "Acme"},
            {"company_name": "Widgets Inc"},
            {"company": "Beta"},
        ]
        assert _contacts_source_distinct_companies(contacts) == 3

    def test_distinct_companies_case_insensitive(self):
        contacts = [
            {"company_name": "Acme"},
            {"company_name": "ACME"},
            {"company_name": "acme"},
        ]
        assert _contacts_source_distinct_companies(contacts) == 1

    def test_distinct_companies_empty(self):
        assert _contacts_source_distinct_companies([]) == 0

    def test_distinct_companies_skips_non_dict(self):
        contacts = [{"company_name": "Acme"}, "str", None]
        assert _contacts_source_distinct_companies(contacts) == 1

    def test_with_email_count(self):
        contacts = [
            {"email": "a@b.com"},
            {"email": "c@d.com"},
            {"email": ""},
            {"first_name": "no-email"},
            {"email": "not-an-email"},  # no @
        ]
        assert _contacts_source_with_email_count(contacts) == 2

    def test_with_email_count_empty(self):
        assert _contacts_source_with_email_count([]) == 0


# ---------------------------------------------------------------------------
# Display helpers
# ---------------------------------------------------------------------------


class TestDisplayName:
    def test_full_name_preferred(self):
        assert _contacts_source_display_name(
            {"full_name": "Alice Wong", "first_name": "A"}
        ) == "Alice Wong"

    def test_first_last_concat(self):
        assert _contacts_source_display_name(
            {"first_name": "Alice", "last_name": "Wong"}
        ) == "Alice Wong"

    def test_email_fallback(self):
        assert _contacts_source_display_name({"email": "x@y.com"}) == "x@y.com"

    def test_empty(self):
        assert _contacts_source_display_name({}) == "(unnamed contact)"


class TestClip:
    def test_short_unchanged(self):
        assert _contacts_source_clip("hello") == "hello"

    def test_long_truncated(self):
        s = "x" * 150
        r = _contacts_source_clip(s, cap=100)
        assert len(r) == 101  # 100 + "…"
        assert r.endswith("…")

    def test_none(self):
        assert _contacts_source_clip(None) == ""

    def test_empty(self):
        assert _contacts_source_clip("") == ""

    def test_html_escaped(self):
        assert "&lt;" in _contacts_source_clip("<script>")


# ---------------------------------------------------------------------------
# Stats row — LOCK
# ---------------------------------------------------------------------------


class TestStatsRow:
    def test_has_four_cards(self):
        html_out = _contacts_source_stats_row_html([])
        assert "repeat(4,1fr)" in html_out

    def test_has_total_and_companies_and_email_coverage(self):
        """LOCK: NEW stats signature for acquisition-quality KPIs.

        Distinct from #84 engagement (Avg score / Avg days / Most recent)
        and #82/#83 deals (Total value / Avg deal / Oldest age). Source
        KPIs: Total + Companies + With email + Email coverage (%).
        """
        html_out = _contacts_source_stats_row_html([
            {"company_name": "Acme", "email": "a@b.com"},
        ])
        assert "Total" in html_out
        assert "Companies" in html_out
        assert "With email" in html_out
        assert "Email coverage" in html_out

    def test_total_count(self):
        contacts = [
            {"first_name": "A"},
            {"first_name": "B"},
            {"first_name": "C"},
        ]
        html_out = _contacts_source_stats_row_html(contacts)
        assert ">3<" in html_out

    def test_email_coverage_pct(self):
        contacts = [
            {"email": "a@b.com"},
            {"email": "c@d.com"},
            {"first_name": "no-email"},
            {"first_name": "no-email-2"},
        ]
        html_out = _contacts_source_stats_row_html(contacts)
        assert "50%" in html_out

    def test_empty_shows_dash(self):
        html_out = _contacts_source_stats_row_html([])
        assert "—" in html_out

    def test_non_list_safe(self):
        html_out = _contacts_source_stats_row_html(None)
        assert ">0<" in html_out


# ---------------------------------------------------------------------------
# Header
# ---------------------------------------------------------------------------


class TestHeader:
    def test_label_present(self):
        html_out = _contacts_source_header_html("referral", 5)
        assert "Referral" in html_out

    def test_singular(self):
        html_out = _contacts_source_header_html("paid", 1)
        assert "1 contact" in html_out

    def test_plural(self):
        html_out = _contacts_source_header_html("paid", 5)
        assert "5 contacts" in html_out

    def test_uppercase_axis(self):
        html_out = _contacts_source_header_html("referral", 5)
        assert "source ·" in html_out

    def test_palette_applied(self):
        html_out = _contacts_source_header_html("referral", 5)
        assert "background:#d1fae5" in html_out

    def test_description_included(self):
        html_out = _contacts_source_header_html("referral", 5)
        assert _contacts_source_description("referral") in html_out


# ---------------------------------------------------------------------------
# Row
# ---------------------------------------------------------------------------


class TestRow:
    def test_name_rendered(self):
        html_out = _contacts_source_row_html({"first_name": "Alice"})
        assert "Alice" in html_out

    def test_title_chip(self):
        html_out = _contacts_source_row_html(
            {"first_name": "A", "title": "VP Sales"}
        )
        assert "VP Sales" in html_out

    def test_company_chip(self):
        html_out = _contacts_source_row_html(
            {"first_name": "A", "company_name": "Acme"}
        )
        assert "Acme" in html_out

    def test_email_line(self):
        html_out = _contacts_source_row_html(
            {"first_name": "A", "email": "a@b.com"}
        )
        assert "a@b.com" in html_out

    def test_xss_in_name_escaped(self):
        html_out = _contacts_source_row_html(
            {"first_name": "<script>alert(1)</script>"}
        )
        assert "<script>" not in html_out

    def test_xss_in_company_escaped(self):
        html_out = _contacts_source_row_html(
            {"first_name": "A", "company_name": "<img onerror=x>"}
        )
        assert "<img" not in html_out


# ---------------------------------------------------------------------------
# List / overflow
# ---------------------------------------------------------------------------


class TestList:
    def test_under_cap_all_rendered(self):
        contacts = [{"first_name": f"C{i}"} for i in range(5)]
        html_out = _contacts_source_list_html(contacts)
        for i in range(5):
            assert f"C{i}" in html_out

    def test_cap_enforced(self):
        contacts = [{"first_name": f"C{i}"} for i in range(150)]
        html_out = _contacts_source_list_html(contacts)
        assert "C99" in html_out
        assert "C100" not in html_out

    def test_non_dict_filtered(self):
        contacts = [{"first_name": "A"}, "bad", None]
        html_out = _contacts_source_list_html(contacts)
        assert "A" in html_out


class TestOverflow:
    def test_under_cap_no_banner(self):
        assert _contacts_source_overflow_banner_html(50, "referral") == ""

    def test_at_cap_no_banner(self):
        assert _contacts_source_overflow_banner_html(
            _MAX_CONTACTS_SOURCE_RENDERED, "referral"
        ) == ""

    def test_over_cap_banner(self):
        html_out = _contacts_source_overflow_banner_html(125, "referral")
        assert "+25" in html_out
        assert "source=referral" in html_out

    def test_invalid_channel_fallback_url(self):
        html_out = _contacts_source_overflow_banner_html(125, "xxx")
        assert "+25" in html_out
        assert "/contacts?limit=200" in html_out


# ---------------------------------------------------------------------------
# Drill-up
# ---------------------------------------------------------------------------


class TestDrillUp:
    def test_dashboard_present(self):
        html_out = _contacts_source_drill_up_html("referral")
        assert "g8://contacts/dashboard" in html_out

    def test_includes_some_siblings(self):
        html_out = _contacts_source_drill_up_html("referral")
        count = sum(
            1 for sibling in _CONTACTS_SOURCE_VALID
            if f"g8://contacts/source/{sibling}" in html_out
        )
        assert count >= 3  # at least 3 sibling channels shown

    def test_excludes_self(self):
        html_out = _contacts_source_drill_up_html("referral")
        assert "g8://contacts/source/referral" not in html_out

    def test_cross_axis_engagement(self):
        html_out = _contacts_source_drill_up_html("referral")
        assert "g8://contacts/engagement/hot" in html_out

    def test_cross_axis_seniority(self):
        html_out = _contacts_source_drill_up_html("referral")
        assert "g8://contacts/seniority/c-level" in html_out

    def test_cross_entity_deals(self):
        html_out = _contacts_source_drill_up_html("referral")
        assert "g8://deals/pipeline" in html_out


# ---------------------------------------------------------------------------
# Empty state
# ---------------------------------------------------------------------------


class TestEmptyState:
    def test_unavailable_shows_sample_options(self):
        html_out = _contacts_source_empty_state_html("xxx", "unavailable")
        assert "referral" in html_out
        assert "paid" in html_out

    def test_empty_valid(self):
        html_out = _contacts_source_empty_state_html("referral", "empty")
        assert "No Referral contacts" in html_out


# ---------------------------------------------------------------------------
# render_contacts_source_html
# ---------------------------------------------------------------------------


class TestRenderHtml:
    def test_invalid_channel_unavailable(self):
        html_out = render_contacts_source_html(contacts=[], channel="xxx")
        assert "Source channel not recognized" in html_out

    def test_dashboard_literal_unavailable(self):
        html_out = render_contacts_source_html(
            contacts=[], channel="dashboard"
        )
        assert "Source channel not recognized" in html_out

    def test_empty_contacts(self):
        html_out = render_contacts_source_html(
            contacts=[], channel="referral"
        )
        assert "No Referral contacts" in html_out

    def test_one_contact(self):
        contacts = [{"first_name": "Alice", "source": "referral"}]
        html_out = render_contacts_source_html(
            contacts=contacts, channel="referral"
        )
        assert "Alice" in html_out
        assert "1 contact" in html_out

    def test_many_contacts(self):
        contacts = [
            {"first_name": f"C{i}", "source": "referral"}
            for i in range(3)
        ]
        html_out = render_contacts_source_html(
            contacts=contacts, channel="referral"
        )
        assert "3 contacts" in html_out

    def test_alias_resolves(self):
        contacts = [{"first_name": "X", "source": "seo"}]
        html_out = render_contacts_source_html(
            contacts=contacts, channel="organic"
        )
        assert "Organic" in html_out

    def test_sort_by_company(self):
        contacts = [
            {"first_name": "A", "source": "referral", "company_name": "Zebra"},
            {"first_name": "B", "source": "referral", "company_name": "Acme"},
        ]
        html_out = render_contacts_source_html(
            contacts=contacts, channel="referral"
        )
        assert html_out.index("Acme") < html_out.index("Zebra")

    def test_non_matching_filtered(self):
        contacts = [
            {"first_name": "Ref", "source": "referral"},
            {"first_name": "Paid", "source": "paid"},
        ]
        html_out = render_contacts_source_html(
            contacts=contacts, channel="referral"
        )
        assert ">Ref<" in html_out or "Ref" in html_out
        assert ">Paid<" not in html_out


class TestRenderHtmlStructure:
    def test_doctype(self):
        html_out = render_contacts_source_html(
            contacts=[], channel="referral"
        )
        assert html_out.startswith("<!DOCTYPE html>")

    def test_title_tag(self):
        html_out = render_contacts_source_html(
            contacts=[], channel="referral"
        )
        assert "<title>" in html_out

    def test_max_width(self):
        html_out = render_contacts_source_html(
            contacts=[], channel="referral"
        )
        assert "max-width:960px" in html_out


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------


class TestTextFallback:
    def test_invalid_unrecognized(self):
        txt = render_contacts_source_text_fallback(
            contacts=[], channel="xxx"
        )
        assert "not recognized" in txt.lower()

    def test_valid_channels_listed_on_unrecognized(self):
        txt = render_contacts_source_text_fallback(
            contacts=[], channel="xxx"
        )
        for ch in _CONTACTS_SOURCE_VALID:
            assert ch in txt

    def test_empty_no_contacts_msg(self):
        txt = render_contacts_source_text_fallback(
            contacts=[], channel="referral"
        )
        assert "No Referral contacts" in txt

    def test_one_contact(self):
        txt = render_contacts_source_text_fallback(
            contacts=[{"first_name": "Alice", "source": "referral"}],
            channel="referral",
        )
        assert "Alice" in txt

    def test_siblings_listed(self):
        txt = render_contacts_source_text_fallback(
            contacts=[], channel="referral"
        )
        for sibling in _CONTACTS_SOURCE_VALID:
            if sibling == "referral":
                continue
            assert f"g8://contacts/source/{sibling}" in txt

    def test_cross_axis(self):
        txt = render_contacts_source_text_fallback(
            contacts=[], channel="referral"
        )
        assert "engagement/hot" in txt
        assert "seniority/c-level" in txt

    def test_cross_entity_deals(self):
        txt = render_contacts_source_text_fallback(
            contacts=[], channel="referral"
        )
        assert "deals/pipeline" in txt

    def test_backend_filter_documented(self):
        txt = render_contacts_source_text_fallback(
            contacts=[], channel="referral"
        )
        assert "source=referral" in txt

    def test_overflow_explainer(self):
        contacts = [
            {"first_name": f"C{i}", "source": "referral"}
            for i in range(150)
        ]
        txt = render_contacts_source_text_fallback(
            contacts=contacts, channel="referral"
        )
        assert "+50" in txt

    def test_dashboard_literal_unavailable(self):
        txt = render_contacts_source_text_fallback(
            contacts=[], channel="dashboard"
        )
        assert "not recognized" in txt.lower()


# ---------------------------------------------------------------------------
# Design tokens
# ---------------------------------------------------------------------------


class TestDesignTokens:
    @pytest.mark.parametrize("banned_hex", [
        "#1d4ed8", "#166534", "#991b1b", "#0891b2",
    ])
    def test_banned_hex_absent(self, banned_hex):
        html_out = render_contacts_source_html(
            contacts=[{"first_name": "A", "source": "referral"}],
            channel="referral",
        )
        assert banned_hex.lower() not in html_out.lower()

    def test_aeonik_font(self):
        html_out = render_contacts_source_html(
            contacts=[], channel="referral"
        )
        assert "Aeonik" in html_out

    def test_border_token(self):
        html_out = render_contacts_source_html(
            contacts=[], channel="referral"
        )
        assert "#dfdfdf" in html_out

    def test_primary_purple_or_accent(self):
        html_out = render_contacts_source_html(
            contacts=[{"first_name": "A"}], channel="referral",
        )
        assert "#7d2df3" in html_out.lower() or "#f2eafe" in html_out.lower()


# ---------------------------------------------------------------------------
# No JS / XSS
# ---------------------------------------------------------------------------


class TestNoJs:
    def test_no_script_tags(self):
        contact = {
            "first_name": "A",
            "source": "referral",
            "email": "<script>alert(1)</script>",
        }
        html_out = render_contacts_source_html(
            contacts=[contact], channel="referral"
        )
        assert "<script>" not in html_out

    def test_no_img_tags(self):
        contact = {
            "first_name": "<img onerror=x>",
            "source": "referral",
        }
        html_out = render_contacts_source_html(
            contacts=[contact], channel="referral"
        )
        assert "<img" not in html_out


# ---------------------------------------------------------------------------
# Smoke
# ---------------------------------------------------------------------------


class TestSmoke:
    @pytest.mark.parametrize("channel", list(_CONTACTS_SOURCE_VALID))
    def test_html_renders_every_channel(self, channel):
        contacts = [
            {"first_name": f"C{i}", "source": channel}
            for i in range(3)
        ]
        html_out = render_contacts_source_html(
            contacts=contacts, channel=channel,
        )
        assert "<!DOCTYPE" in html_out
        assert _CONTACTS_SOURCE_LABELS[channel] in html_out

    @pytest.mark.parametrize("channel", list(_CONTACTS_SOURCE_VALID))
    def test_text_renders_every_channel(self, channel):
        txt = render_contacts_source_text_fallback(
            contacts=[{"first_name": "X", "source": channel}],
            channel=channel,
        )
        assert txt.startswith("# Contacts ·")

    @pytest.mark.parametrize("alias", [
        "seo", "ppc", "linkedin-ads", "cold-email", "conference",
        "webinar", "affiliate", "brand", "linkedin", "csv",
    ])
    def test_alias_renders(self, alias):
        html_out = render_contacts_source_html(
            contacts=[{"first_name": "A", "source": alias}],
            channel=alias,
        )
        assert "<!DOCTYPE" in html_out
        assert "Source channel not recognized" not in html_out

    def test_none_contacts_renders_unavailable(self):
        html_out = render_contacts_source_html(
            contacts=None, channel="referral",
        )
        assert "<!DOCTYPE" in html_out


class TestReturnTypes:
    def test_html_str(self):
        out = render_contacts_source_html(contacts=[], channel="referral")
        assert isinstance(out, str)

    def test_text_str(self):
        out = render_contacts_source_text_fallback(
            contacts=[], channel="referral"
        )
        assert isinstance(out, str)
