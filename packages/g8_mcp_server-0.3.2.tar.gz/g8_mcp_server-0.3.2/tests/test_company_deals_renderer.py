"""Unit tests for surface #42 — per-company deal roster.

Surface #42 reuses surface #41's helpers (same `ContactDealResponse`
DTO shape from the backend), so the helpers themselves are already
covered by `test_contact_deals_renderer.py`. This module focuses on
the surface-#42-specific pieces: empty-state, company-label derivation,
HTML rendering (drill-up links differ, no roles section), and text
fallback. Design-parity checks repeat at this layer because #42 ships
its own header + drill-up markup.
"""

from g8_mcp_server.app_renderer import (
    _company_deals_company_label,
    _render_company_deals_empty_state_html,
    render_company_deals_html,
    render_company_deals_text_fallback,
)


def _deal(
    *,
    deal_id: str = "d1",
    name: str = "Test Deal",
    stage: str = "open",
    value: float | int | None = 10000,
    currency: str | None = "USD",
    close_date: str | None = "2026-06-30",
    created_at: str | None = "2026-04-01T10:00:00Z",
) -> dict:
    """Build a valid deal dict for testing."""
    return {
        "deal_id": deal_id,
        "name": name,
        "stage": stage,
        "value": value,
        "currency": currency,
        "close_date": close_date,
        "created_at": created_at,
    }


class TestEmptyState:
    def test_empty_mode(self):
        html_out = _render_company_deals_empty_state_html("co_1", mode="empty")
        assert "<!DOCTYPE html>" in html_out
        assert "no deal associations yet" in html_out
        assert "company_id=co_1" in html_out
        # must link to create deal and to the parent profile
        assert "POST /deals" in html_out
        assert "g8://companies/co_1" in html_out

    def test_unavailable_mode(self):
        html_out = _render_company_deals_empty_state_html("co_1", mode="unavailable")
        assert "not available" in html_out
        assert "may be invalid" in html_out

    def test_xss_in_company_id_escaped(self):
        xss = "<script>alert(1)</script>"
        html_out = _render_company_deals_empty_state_html(xss, mode="empty")
        assert xss not in html_out
        assert "&lt;script&gt;" in html_out

    def test_xss_unavailable_mode(self):
        xss = "<img src=x onerror=1>"
        html_out = _render_company_deals_empty_state_html(xss, mode="unavailable")
        assert xss not in html_out
        assert "&lt;img" in html_out

    def test_graph8_tokens_present(self):
        html_out = _render_company_deals_empty_state_html("co_1", mode="empty")
        assert "Aeonik" in html_out

    def test_no_single_side_accent_borders(self):
        for mode in ("empty", "unavailable"):
            html_out = _render_company_deals_empty_state_html("co_1", mode=mode)
            assert "border-left:3px" not in html_out
            assert "border-top:3px" not in html_out
            assert "border-right:3px" not in html_out
            assert "border-bottom:3px" not in html_out


class TestCompanyLabel:
    def test_none(self):
        assert _company_deals_company_label(None) == "Company"

    def test_non_dict(self):
        assert _company_deals_company_label("not a dict") == "Company"
        assert _company_deals_company_label(42) == "Company"

    def test_empty_dict(self):
        assert _company_deals_company_label({}) == "Company"

    def test_name_wins(self):
        company = {"name": "Acme Inc.", "domain": "acme.com", "website": "https://acme.com"}
        assert _company_deals_company_label(company) == "Acme Inc."

    def test_domain_fallback(self):
        company = {"domain": "acme.com"}
        assert _company_deals_company_label(company) == "acme.com"

    def test_website_fallback(self):
        company = {"website": "https://acme.com"}
        assert _company_deals_company_label(company) == "https://acme.com"

    def test_skips_blank_name(self):
        company = {"name": "   ", "domain": "acme.com"}
        assert _company_deals_company_label(company) == "acme.com"

    def test_skips_non_string_name(self):
        company = {"name": 42, "domain": "acme.com"}
        assert _company_deals_company_label(company) == "acme.com"

    def test_custom_fallback(self):
        assert _company_deals_company_label(None, fallback="Unknown Co") == "Unknown Co"

    def test_xss_escaped(self):
        company = {"name": "<script>alert(1)</script>"}
        out = _company_deals_company_label(company)
        assert "<script>" not in out
        assert "&lt;script&gt;" in out

    def test_long_name_clipped(self):
        company = {"name": "x" * 300}
        out = _company_deals_company_label(company)
        assert len(out) <= 141
        assert out.endswith("…")


class TestRenderHtml:
    def test_none_deals_unavailable(self):
        html_out = render_company_deals_html(deals=None, company_id="co_1")
        assert "not available" in html_out
        assert "may be invalid" in html_out

    def test_empty_list_empty_state(self):
        html_out = render_company_deals_html(deals=[], company_id="co_1")
        assert "no deal associations yet" in html_out

    def test_single_deal_renders_table(self):
        deals = [_deal()]
        html_out = render_company_deals_html(deals=deals, company_id="co_1")
        assert "<!DOCTYPE html>" in html_out
        assert "Test Deal" in html_out
        assert "deal_id=d1" in html_out
        assert "company id: <code>co_1</code>" in html_out

    def test_stat_cards_rendered(self):
        deals = [_deal(stage="open"), _deal(stage="won"), _deal(stage="lost")]
        html_out = render_company_deals_html(deals=deals, company_id="co_1")
        assert "Total deals" in html_out
        assert "Open" in html_out
        assert "Won" in html_out
        assert "Pipeline value" in html_out

    def test_stage_mix_shown(self):
        deals = [_deal(stage="open"), _deal(stage="won")]
        html_out = render_company_deals_html(deals=deals, company_id="co_1")
        assert "Stage mix" in html_out

    def test_no_roles_section_vs_surface_41(self):
        """Surface #42 MUST NOT render a role breakdown section —
        company deals don't have cleanly-owned roles."""
        deals = [_deal()]
        html_out = render_company_deals_html(deals=deals, company_id="co_1")
        # No "Role" section header on company surface
        assert "Role mix" not in html_out
        assert "Role breakdown" not in html_out

    def test_company_label_in_title_and_header(self):
        company = {"name": "Acme Co"}
        deals = [_deal()]
        html_out = render_company_deals_html(
            deals=deals, company_id="co_1", company=company
        )
        assert "<title>Acme Co — deals</title>" in html_out
        assert "Acme Co — deals" in html_out

    def test_company_label_fallback(self):
        deals = [_deal()]
        html_out = render_company_deals_html(deals=deals, company_id="co_1")
        assert "Company — deals" in html_out

    def test_company_label_uses_domain(self):
        company = {"domain": "acme.com"}
        deals = [_deal()]
        html_out = render_company_deals_html(
            deals=deals, company_id="co_1", company=company
        )
        assert "acme.com — deals" in html_out

    def test_overflow_40(self):
        deals = [_deal(deal_id=f"d{i}") for i in range(45)]
        html_out = render_company_deals_html(deals=deals, company_id="co_1")
        assert "+ 5 more deals" in html_out

    def test_total_chip_in_header(self):
        deals = [_deal() for _ in range(7)]
        html_out = render_company_deals_html(deals=deals, company_id="co_1")
        assert "7 TOTAL" in html_out

    def test_drill_up_links_four_items(self):
        deals = [_deal()]
        html_out = render_company_deals_html(deals=deals, company_id="co_1")
        # 4 items — no /tasks (companies don't have tasks endpoint)
        assert "g8://companies/co_1</code>" in html_out
        assert "g8://companies/co_1/notes</code>" in html_out
        assert "g8://deals/pipelines</code>" in html_out
        assert "GET /deals</code>" in html_out
        # surface #42 must NOT link to /tasks
        assert "g8://companies/co_1/tasks</code>" not in html_out

    def test_xss_in_company_name_escaped(self):
        deals = [_deal()]
        company = {"name": "<script>alert(1)</script>"}
        html_out = render_company_deals_html(
            deals=deals, company_id="co_1", company=company
        )
        assert "<script>alert" not in html_out
        assert "&lt;script&gt;" in html_out

    def test_xss_in_company_id_escaped(self):
        xss = "<script>alert(1)</script>"
        deals = [_deal()]
        html_out = render_company_deals_html(deals=deals, company_id=xss)
        assert xss not in html_out
        assert "&lt;script&gt;" in html_out

    def test_xss_in_deal_name_escaped(self):
        deals = [_deal(name="<img src=x>")]
        html_out = render_company_deals_html(deals=deals, company_id="co_1")
        assert "<img src=x>" not in html_out
        assert "&lt;img" in html_out

    def test_bool_value_excluded_from_pipeline(self):
        # Python bool is subclass of int — must not inflate pipeline.
        deals = [_deal(stage="open", value=True)]
        html_out = render_company_deals_html(deals=deals, company_id="co_1")
        # Pipeline value should be "—" (no positive total)
        assert ">—<" in html_out

    def test_no_single_side_accent_borders(self):
        deals = [_deal()]
        html_out = render_company_deals_html(deals=deals, company_id="co_1")
        assert "border-left:3px" not in html_out
        assert "border-top:3px" not in html_out
        assert "border-right:3px" not in html_out
        assert "border-bottom:3px" not in html_out

    def test_no_legacy_accent_hexes(self):
        deals = [_deal()]
        html_out = render_company_deals_html(deals=deals, company_id="co_1")
        for legacy in ("#6366f1", "#4f46e5", "#10b981", "#ec4899", "#dc2626", "#16a34a"):
            assert legacy not in html_out, (
                f"surface #42 should not contain legacy hex {legacy}"
            )

    def test_aeonik_font_present(self):
        deals = [_deal()]
        html_out = render_company_deals_html(deals=deals, company_id="co_1")
        assert "Aeonik" in html_out

    def test_graph8_primary_present(self):
        deals = [_deal()]
        html_out = render_company_deals_html(deals=deals, company_id="co_1")
        assert "#7d2df3" in html_out

    def test_invalid_deals_filtered(self):
        deals = [_deal(), "not a dict", 42, None, _deal(deal_id="d2")]
        html_out = render_company_deals_html(deals=deals, company_id="co_1")
        assert "2 TOTAL" in html_out

    def test_close_date_and_created_at_rendered(self):
        deals = [_deal(close_date="2026-07-01", created_at="2026-04-01T10:00:00Z")]
        html_out = render_company_deals_html(deals=deals, company_id="co_1")
        assert "closes 2026-07-01" in html_out
        assert "created 2026-04-01T10:00:00Z" in html_out


class TestTextFallback:
    def test_none_unavailable(self):
        text = render_company_deals_text_fallback(deals=None, company_id="co_1")
        assert "not available" in text

    def test_empty(self):
        text = render_company_deals_text_fallback(deals=[], company_id="co_1")
        assert "no deals yet" in text
        assert "company_id=co_1" in text

    def test_markdown_headers(self):
        deals = [_deal()]
        text = render_company_deals_text_fallback(deals=deals, company_id="co_1")
        assert "# Company" in text
        assert "## Stage mix" in text
        assert "## Deals" in text
        assert "## Drill into this company" in text

    def test_no_roles_header(self):
        """Surface #42 text fallback must not have a Role mix header."""
        deals = [_deal()]
        text = render_company_deals_text_fallback(deals=deals, company_id="co_1")
        assert "## Role" not in text

    def test_stats_rendered(self):
        deals = [_deal(stage="open"), _deal(stage="won")]
        text = render_company_deals_text_fallback(deals=deals, company_id="co_1")
        assert "- Total deals: 2" in text
        assert "- Open: 1" in text
        assert "- Won: 1" in text

    def test_deal_row_format(self):
        deals = [_deal(stage="open", name="My Deal", value=5000)]
        text = render_company_deals_text_fallback(deals=deals, company_id="co_1")
        assert "[Open] My Deal" in text
        assert "deal_id=d1" in text
        assert "$5,000 USD" in text

    def test_bool_value_rejected(self):
        deals = [_deal(stage="open", value=True)]
        text = render_company_deals_text_fallback(deals=deals, company_id="co_1")
        # no "$1 USD" for True
        assert "$1 USD" not in text

    def test_overflow_40(self):
        deals = [_deal(deal_id=f"d{i}") for i in range(45)]
        text = render_company_deals_text_fallback(deals=deals, company_id="co_1")
        assert "+ 5 more deals" in text

    def test_drill_up_pointers_four_items(self):
        deals = [_deal()]
        text = render_company_deals_text_fallback(deals=deals, company_id="co_1")
        assert "g8://companies/co_1" in text
        assert "g8://companies/co_1/notes" in text
        assert "g8://deals/pipelines" in text
        assert "GET /deals" in text
        # Must NOT reference a tasks sibling
        assert "g8://companies/co_1/tasks" not in text

    def test_company_name_in_header(self):
        deals = [_deal()]
        company = {"name": "Acme Inc."}
        text = render_company_deals_text_fallback(
            deals=deals, company_id="co_1", company=company
        )
        assert "# Acme Inc. — deals" in text

    def test_company_domain_fallback(self):
        deals = [_deal()]
        company = {"domain": "acme.com"}
        text = render_company_deals_text_fallback(
            deals=deals, company_id="co_1", company=company
        )
        assert "# acme.com — deals" in text

    def test_company_default_label(self):
        deals = [_deal()]
        text = render_company_deals_text_fallback(deals=deals, company_id="co_1")
        assert "# Company — deals" in text

    def test_close_date_and_created_at(self):
        deals = [_deal(close_date="2026-07-01", created_at="2026-04-01T10:00:00Z")]
        text = render_company_deals_text_fallback(deals=deals, company_id="co_1")
        assert "closes 2026-07-01" in text
        assert "created 2026-04-01T10:00:00Z" in text


class TestSmoke:
    def test_mixed_payload(self):
        """Large mixed payload doesn't explode."""
        stages = ["open", "qualified", "proposal", "won", "lost", "closed_won"]
        deals = [
            _deal(
                deal_id=f"d{i}",
                name=f"Deal {i}",
                stage=stages[i % len(stages)],
                value=1000 * (i + 1),
                currency="USD" if i % 2 == 0 else "EUR",
            )
            for i in range(30)
        ]
        company = {"name": "Acme Inc.", "domain": "acme.com"}
        html_out = render_company_deals_html(
            deals=deals, company_id="co_1", company=company
        )
        assert "30 TOTAL" in html_out
        assert "Acme Inc. — deals" in html_out
        text_out = render_company_deals_text_fallback(
            deals=deals, company_id="co_1", company=company
        )
        assert "- Total deals: 30" in text_out
        assert "# Acme Inc. — deals" in text_out

    def test_unicode_in_deal_name(self):
        deals = [_deal(name="日本語 Deal ✓")]
        html_out = render_company_deals_html(deals=deals, company_id="co_1")
        assert "日本語 Deal ✓" in html_out
        text_out = render_company_deals_text_fallback(deals=deals, company_id="co_1")
        assert "日本語 Deal ✓" in text_out
