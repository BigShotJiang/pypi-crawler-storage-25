"""Tests for the 5 contact deep-read tools.

These tools are thin wrappers over existing /api/v1 routes so we're testing:
  * registration (all 5 present, annotated read-only)
  * the tool calls the right backend path with the right params
  * the response is passed through intact (shape-preserving)
  * composite `g8_get_contact_company` handles the two-step lookup +
    gracefully returns an empty detail when the contact has no company linkage
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock

import pytest

import g8_mcp_server.client as client_module
from g8_mcp_server.server import create_server


@pytest.fixture
def mcp_server(monkeypatch):
    monkeypatch.setenv("G8_API_KEY", "test_key")
    monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
    monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent"))
    return create_server()


def _tool(server, name: str):
    return server._tool_manager._tools[name]


class TestRegistration:
    @pytest.mark.parametrize(
        "tool_name",
        [
            "g8_get_contact_detail",
            "g8_get_contact_activity",
            "g8_get_contact_deals",
            "g8_get_contact_company",
            "g8_get_company_contacts",
        ],
    )
    def test_tool_registered_and_read_only(self, mcp_server, tool_name):
        tool = _tool(mcp_server, tool_name)
        assert tool is not None
        ann = tool.annotations
        if ann is not None:
            assert ann.readOnlyHint is True, (
                f"{tool_name} should be read-only"
            )


class TestContactDetail:
    @pytest.mark.asyncio
    async def test_calls_right_endpoint_and_returns_detail(
        self, mcp_server, monkeypatch
    ):
        envelope: dict[str, Any] = {
            "data": {
                "id": 42,
                "first_name": "Alice",
                "last_name": "Example",
                "work_email": "alice@example.com",
                "company_id": 7,
            }
        }
        mock_get = AsyncMock(return_value=envelope)
        monkeypatch.setattr(
            "g8_mcp_server.client.G8Client.get", mock_get, raising=True
        )
        tool = _tool(mcp_server, "g8_get_contact_detail")

        result = await tool.fn(contact_id=42)

        # Called the right backend path
        assert mock_get.await_count == 1
        assert mock_get.await_args.args[0] == "/contacts/42"
        # Passed the contact through — ResourceDetail allows extra fields
        dumped = result.model_dump()
        assert dumped["id"] == 42
        assert dumped["first_name"] == "Alice"
        assert dumped["work_email"] == "alice@example.com"


class TestContactActivity:
    @pytest.mark.asyncio
    async def test_filters_by_contact_client_side(self, mcp_server, monkeypatch):
        """Backend `/activities?contact_id=X` is broken (returns 500), so we
        pull org-wide activities and filter client-side."""
        envelope = {
            "data": [
                {"id": "a1", "activity_type": "call", "contact_id": 99},
                {"id": "a2", "activity_type": "email", "contact_id": 42},
                {"id": "a3", "activity_type": "meeting", "contact_id": 99},
                {"id": "a4", "activity_type": "call", "contact_id": 99},
            ]
        }
        mock_get = AsyncMock(return_value=envelope)
        monkeypatch.setattr(
            "g8_mcp_server.client.G8Client.get", mock_get, raising=True
        )
        tool = _tool(mcp_server, "g8_get_contact_activity")

        result = await tool.fn(contact_id=99)

        # Single call - org-wide pull with no contact_id filter
        assert mock_get.await_count == 1
        path, params = mock_get.await_args.args
        assert path == "/activities"
        assert params == {"limit": 200}
        # 3 of 4 matched contact 99
        assert result["total"] == 3
        assert all(a["contact_id"] == 99 for a in result["activities"])
        assert result["scan_truncated"] is False

    @pytest.mark.asyncio
    async def test_activity_type_filter_applies_client_side(
        self, mcp_server, monkeypatch
    ):
        envelope = {
            "data": [
                {"id": "a1", "activity_type": "call", "contact_id": 99},
                {"id": "a2", "activity_type": "email", "contact_id": 99},
                {"id": "a3", "activity_type": "call", "contact_id": 99},
            ]
        }
        mock_get = AsyncMock(return_value=envelope)
        monkeypatch.setattr(
            "g8_mcp_server.client.G8Client.get", mock_get, raising=True
        )
        tool = _tool(mcp_server, "g8_get_contact_activity")

        result = await tool.fn(contact_id=99, activity_type="call")

        assert result["total"] == 2
        assert all(a["activity_type"] == "call" for a in result["activities"])

    @pytest.mark.asyncio
    async def test_handles_nested_contact_object(self, mcp_server, monkeypatch):
        """Some rows embed `contact: {id: ...}` instead of a flat `contact_id`."""
        envelope = {
            "data": [
                {"id": "a1", "contact": {"id": 99}, "activity_type": "call"},
                {"id": "a2", "contact": {"id": 42}, "activity_type": "email"},
            ]
        }
        mock_get = AsyncMock(return_value=envelope)
        monkeypatch.setattr(
            "g8_mcp_server.client.G8Client.get", mock_get, raising=True
        )
        tool = _tool(mcp_server, "g8_get_contact_activity")

        result = await tool.fn(contact_id=99)
        assert result["total"] == 1
        assert result["activities"][0]["id"] == "a1"

    @pytest.mark.asyncio
    async def test_respects_limit(self, mcp_server, monkeypatch):
        envelope = {
            "data": [
                {"id": f"a{i}", "activity_type": "call", "contact_id": 99}
                for i in range(10)
            ]
        }
        mock_get = AsyncMock(return_value=envelope)
        monkeypatch.setattr(
            "g8_mcp_server.client.G8Client.get", mock_get, raising=True
        )
        tool = _tool(mcp_server, "g8_get_contact_activity")

        result = await tool.fn(contact_id=99, limit=3)
        assert result["total"] == 3

    @pytest.mark.asyncio
    async def test_scan_truncated_when_upstream_hits_200(
        self, mcp_server, monkeypatch
    ):
        envelope = {
            "data": [
                {"id": f"a{i}", "contact_id": 99, "activity_type": "call"}
                for i in range(200)
            ]
        }
        mock_get = AsyncMock(return_value=envelope)
        monkeypatch.setattr(
            "g8_mcp_server.client.G8Client.get", mock_get, raising=True
        )
        tool = _tool(mcp_server, "g8_get_contact_activity")

        result = await tool.fn(contact_id=99)
        assert result["scan_truncated"] is True


class TestContactDeals:
    @pytest.mark.asyncio
    async def test_returns_raw_deal_list(self, mcp_server, monkeypatch):
        envelope = {
            "data": [
                {
                    "deal_id": "d1",
                    "name": "Acme Expansion",
                    "stage": "Proposal",
                    "value": 50000,
                    "currency": "USD",
                },
                {
                    "deal_id": "d2",
                    "name": "Initech Pilot",
                    "stage": "Discovery",
                },
            ]
        }
        mock_get = AsyncMock(return_value=envelope)
        monkeypatch.setattr(
            "g8_mcp_server.client.G8Client.get", mock_get, raising=True
        )
        tool = _tool(mcp_server, "g8_get_contact_deals")

        result = await tool.fn(contact_id=17)

        assert mock_get.await_args.args[0] == "/contacts/17/deals"
        assert result["total"] == 2
        # Shape preserved: ContactDealResponse fields (deal_id / stage / value)
        # are passed through so the agent reads them directly without us
        # having to normalise into DealItem.
        assert result["deals"][0]["deal_id"] == "d1"
        assert result["deals"][0]["stage"] == "Proposal"
        assert result["deals"][0]["value"] == 50000

    @pytest.mark.asyncio
    async def test_empty_response_returns_empty_list(self, mcp_server, monkeypatch):
        mock_get = AsyncMock(return_value={"data": []})
        monkeypatch.setattr(
            "g8_mcp_server.client.G8Client.get", mock_get, raising=True
        )
        tool = _tool(mcp_server, "g8_get_contact_deals")

        result = await tool.fn(contact_id=1)

        assert result == {"deals": [], "total": 0}

    @pytest.mark.asyncio
    async def test_malformed_envelope_defaults_to_empty(
        self, mcp_server, monkeypatch
    ):
        # Backend returned something un-dict-like (shouldn't happen, but we
        # don't want a 500 from the tool if it does)
        mock_get = AsyncMock(return_value=None)
        monkeypatch.setattr(
            "g8_mcp_server.client.G8Client.get", mock_get, raising=True
        )
        tool = _tool(mcp_server, "g8_get_contact_deals")

        result = await tool.fn(contact_id=1)

        assert result == {"deals": [], "total": 0}


class TestContactCompany:
    @pytest.mark.asyncio
    async def test_extracts_nested_company_block(self, mcp_server, monkeypatch):
        """The /contacts/{id} response embeds the company as a nested object;
        we extract it directly (no 2nd call needed)."""
        contact_env = {
            "data": {
                "id": 42,
                "first_name": "Alice",
                "company": {
                    "id": 7,
                    "name": "Acme Inc.",
                    "domain": "acme.com",
                    "industry": "SaaS",
                },
            }
        }
        mock_get = AsyncMock(return_value=contact_env)
        monkeypatch.setattr(
            "g8_mcp_server.client.G8Client.get", mock_get, raising=True
        )
        tool = _tool(mcp_server, "g8_get_contact_company")

        result = await tool.fn(contact_id=42)

        # Single backend call — we don't hit /companies/{id}
        called_paths = [c.args[0] for c in mock_get.await_args_list]
        assert called_paths == ["/contacts/42"]
        dumped = result.model_dump()
        assert dumped["id"] == 7
        assert dumped["name"] == "Acme Inc."
        assert dumped["domain"] == "acme.com"

    @pytest.mark.asyncio
    async def test_no_company_linkage_returns_empty_detail(
        self, mcp_server, monkeypatch
    ):
        """When the contact response has no nested company (or the company is
        missing an id), return an empty ResourceDetail."""
        contact_env = {"data": {"id": 42, "first_name": "Alice"}}

        mock_get = AsyncMock(return_value=contact_env)
        monkeypatch.setattr(
            "g8_mcp_server.client.G8Client.get", mock_get, raising=True
        )
        tool = _tool(mcp_server, "g8_get_contact_company")

        result = await tool.fn(contact_id=42)

        called_paths = [c.args[0] for c in mock_get.await_args_list]
        assert called_paths == ["/contacts/42"]
        assert result.model_dump()["id"] is None

    @pytest.mark.asyncio
    async def test_empty_nested_company_object_returns_empty(
        self, mcp_server, monkeypatch
    ):
        """Defensive: even if `company` is present as `{}`, we still return
        empty rather than surface a blank record."""
        contact_env = {"data": {"id": 42, "company": {}}}
        mock_get = AsyncMock(return_value=contact_env)
        monkeypatch.setattr(
            "g8_mcp_server.client.G8Client.get", mock_get, raising=True
        )
        tool = _tool(mcp_server, "g8_get_contact_company")

        result = await tool.fn(contact_id=42)
        assert result.model_dump()["id"] is None


class TestCompanyContacts:
    @pytest.mark.asyncio
    async def test_passes_pagination_params(self, mcp_server, monkeypatch):
        envelope = {
            "data": [
                {"id": 1, "first_name": "Alice", "work_email": "a@acme.com"},
                {"id": 2, "first_name": "Bob", "work_email": "b@acme.com"},
            ],
            "pagination": {
                "page": 1,
                "limit": 100,
                "total": 2,
                "has_next": False,
            },
        }
        mock_get = AsyncMock(return_value=envelope)
        monkeypatch.setattr(
            "g8_mcp_server.client.G8Client.get", mock_get, raising=True
        )
        tool = _tool(mcp_server, "g8_get_company_contacts")

        result = await tool.fn(company_id=7, limit=50, offset=10)

        path, params = mock_get.await_args.args
        assert path == "/companies/7/contacts"
        assert params["limit"] == 50
        assert params["offset"] == 10
        assert len(result.contacts) == 2
        assert result.contacts[0].first_name == "Alice"

    @pytest.mark.asyncio
    async def test_default_limit_is_100(self, mcp_server, monkeypatch):
        mock_get = AsyncMock(return_value={"data": []})
        monkeypatch.setattr(
            "g8_mcp_server.client.G8Client.get", mock_get, raising=True
        )
        tool = _tool(mcp_server, "g8_get_company_contacts")

        await tool.fn(company_id=7)

        params = mock_get.await_args.args[1]
        assert params["limit"] == 100
        assert params["offset"] == 0
