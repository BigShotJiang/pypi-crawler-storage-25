"""Unit tests for Surface #57 — org-wide lead-capture form snippet renderer.

Covers the helpers + HTML / text renderers in
``g8_mcp_server.app_renderer`` for the form snippet surface
(``g8://snippet/form`` + ``.txt`` sibling).

Regression locks:
- No single-side colored accent borders (AI-tell).
- No legacy accent hexes (enforces graph8 design-token refactor).
- Drill-up card does NOT self-reference ``g8://snippet/form``.
- Write-key preview NEVER leaks the full secret into HTML (always
  clipped to first 16 chars + ellipsis). Full key intentionally appears
  inside the embedded form HTML <pre> block (that's what users copy).
"""
from __future__ import annotations

import pytest

from g8_mcp_server.app_renderer import (
    _MAX_FORM_SNIPPET_EVENT_NAME_LEN,
    _MAX_FORM_SNIPPET_FIELDS_RENDERED,
    _MAX_FORM_SNIPPET_FIELD_NAME_LEN,
    _MAX_FORM_SNIPPET_HOST_LEN,
    _MAX_FORM_SNIPPET_HTML_LEN,
    _MAX_FORM_SNIPPET_NOTES_LEN,
    _MAX_FORM_SNIPPET_WRITE_KEY_LEN,
    _form_snippet_clip,
    _form_snippet_code_block,
    _form_snippet_field_chip,
    _form_snippet_fields_list,
    _form_snippet_stat_card,
    _form_snippet_status,
    _form_snippet_write_key_display,
    _render_form_snippet_empty_state_html,
    render_form_snippet_html,
    render_form_snippet_text_fallback,
)


WRITE_KEY = "wk_live_0123456789abcdef_ignored_tail"
TRACKING_HOST = "https://t.graph8.com"
SAMPLE_FORM_HTML = (
    '<form id="g8-lead-form">\n'
    '  <input name="name" type="text">\n'
    '  <input name="email" type="email">\n'
    '  <input name="company" type="text">\n'
    '  <button type="submit">Submit</button>\n'
    "</form>\n"
    "<script>\n"
    '  (function(){ window.graph8?.track("form_submitted", {}); })();\n'
    "</script>"
)
SAMPLE_FORM = {
    "html": SAMPLE_FORM_HTML,
    "write_key": WRITE_KEY,
    "tracking_host": TRACKING_HOST,
    "fields": ["name", "email", "company"],
    "event_name": "form_submitted",
    "notes": (
        "This form calls window.graph8.track('form_submitted', ...). "
        "If the tracking snippet isn't loaded yet, it falls back to a "
        "direct POST to the tracking host. Customise the HTML freely; "
        "keep the submit-handler intact so analytics stay wired."
    ),
}


# ────────────────────────────────────────────────────────────────────────────
# Helpers
# ────────────────────────────────────────────────────────────────────────────


class TestClip:
    def test_empty_string(self):
        assert _form_snippet_clip("", 10) == ""

    def test_whitespace_only(self):
        assert _form_snippet_clip("   ", 10) == ""

    def test_none(self):
        assert _form_snippet_clip(None, 10) == ""

    def test_non_string(self):
        assert _form_snippet_clip(123, 10) == ""
        assert _form_snippet_clip({"x": 1}, 10) == ""

    def test_short(self):
        assert _form_snippet_clip("hi", 10) == "hi"

    def test_long_truncates_with_ellipsis(self):
        out = _form_snippet_clip("x" * 100, 10)
        assert out.endswith("…")
        assert len(out) == 10


class TestWriteKeyDisplay:
    def test_empty(self):
        assert _form_snippet_write_key_display("") == ""

    def test_none(self):
        assert _form_snippet_write_key_display(None) == ""

    def test_non_string(self):
        assert _form_snippet_write_key_display(123) == ""

    def test_whitespace_stripped(self):
        assert _form_snippet_write_key_display("   abc   ") == "abc"

    def test_short_returned_in_full(self):
        # Under 16 chars → returned verbatim, no ellipsis.
        assert _form_snippet_write_key_display("abc") == "abc"

    def test_exactly_16_chars_returned_in_full(self):
        val = "x" * 16
        assert _form_snippet_write_key_display(val) == val

    def test_long_truncated_with_ellipsis(self):
        out = _form_snippet_write_key_display(WRITE_KEY)
        assert out == WRITE_KEY[:16] + "…"
        assert out.endswith("…")
        assert len(out) == 17  # 16 chars + 1 ellipsis char

    def test_full_key_never_leaks_through_preview(self):
        # This is the critical security test: the preview MUST NEVER
        # contain the full write key.
        preview = _form_snippet_write_key_display(WRITE_KEY)
        assert WRITE_KEY not in preview
        # Tail portion specifically is never in the preview.
        assert "ignored_tail" not in preview


class TestFieldsList:
    def test_empty(self):
        assert _form_snippet_fields_list([]) == []

    def test_none(self):
        assert _form_snippet_fields_list(None) == []

    def test_non_list(self):
        assert _form_snippet_fields_list({"name": "x"}) == []
        assert _form_snippet_fields_list("abc") == []

    def test_preserves_insertion_order(self):
        assert _form_snippet_fields_list(["c", "a", "b"]) == ["c", "a", "b"]

    def test_dedupes(self):
        assert _form_snippet_fields_list(
            ["name", "email", "name", "email", "company"]
        ) == ["name", "email", "company"]

    def test_strips_whitespace(self):
        assert _form_snippet_fields_list(
            ["  name  ", "email"]
        ) == ["name", "email"]

    def test_ignores_non_strings(self):
        assert _form_snippet_fields_list(
            ["name", 123, None, {"k": "v"}, "email"]
        ) == ["name", "email"]

    def test_ignores_empty_after_strip(self):
        assert _form_snippet_fields_list(
            ["name", "  ", "", "email"]
        ) == ["name", "email"]


class TestStatus:
    def test_html_present_returns_ready(self):
        bg, fg, label = _form_snippet_status({"html": "<form></form>"})
        assert label == "READY"
        assert bg == "#d1fae5"
        assert fg == "#059669"

    def test_empty_html_returns_missing(self):
        bg, fg, label = _form_snippet_status({"html": ""})
        assert label == "MISSING"
        assert bg == "#fee2e2"
        assert fg == "#ca3214"

    def test_whitespace_only_html_returns_missing(self):
        _, _, label = _form_snippet_status({"html": "   \n  "})
        assert label == "MISSING"

    def test_none_data_returns_missing(self):
        _, _, label = _form_snippet_status(None)
        assert label == "MISSING"

    def test_non_dict_returns_missing(self):
        _, _, label = _form_snippet_status("<form></form>")
        assert label == "MISSING"

    def test_non_string_html_returns_missing(self):
        _, _, label = _form_snippet_status({"html": 123})
        assert label == "MISSING"


class TestStatCard:
    def test_uniform_border(self):
        card = _form_snippet_stat_card("Test", "value")
        assert "border:1px solid #dfdfdf" in card
        # Uniform border only — not a colored accent bar.
        assert "border-left:" not in card
        assert "border-right:" not in card
        assert "border-top:" not in card
        assert "border-bottom:" not in card

    def test_primary_accent(self):
        card = _form_snippet_stat_card("k", "v", accent="primary")
        assert "#7d2df3" in card

    def test_positive_accent(self):
        card = _form_snippet_stat_card("k", "v", accent="positive")
        assert "#059669" in card

    def test_destructive_accent(self):
        card = _form_snippet_stat_card("k", "v", accent="destructive")
        assert "#ca3214" in card

    def test_html_escape_on_label_and_value(self):
        card = _form_snippet_stat_card("<script>", "<b>x</b>")
        assert "<script>" not in card.replace("&lt;", "")
        assert "&lt;script&gt;" in card
        assert "&lt;b&gt;x&lt;/b&gt;" in card

    def test_no_single_side_colored_accent_border(self):
        for accent in ("primary", "positive", "destructive", "warning", "text"):
            card = _form_snippet_stat_card("k", "v", accent=accent)
            # This is the key regression lock: no single-side colored
            # border strips (AI-tell pattern).
            assert "border-left:" not in card
            assert "border-right:" not in card
            assert "border-top:" not in card
            assert "border-bottom:" not in card


class TestFieldChip:
    def test_renders_name(self):
        chip = _form_snippet_field_chip("email")
        assert "email" in chip

    def test_escapes_html(self):
        chip = _form_snippet_field_chip("<script>")
        assert "<script>" not in chip.replace("&lt;", "")
        assert "&lt;script&gt;" in chip

    def test_uses_muted_background(self):
        chip = _form_snippet_field_chip("name")
        assert "#f9f9f9" in chip  # _G8_MUTED_BG

    def test_monospace_font(self):
        chip = _form_snippet_field_chip("company")
        assert "ui-monospace" in chip

    def test_clips_long_name(self):
        long = "x" * 200
        chip = _form_snippet_field_chip(long)
        # Should be clipped at _MAX_FORM_SNIPPET_FIELD_NAME_LEN (60).
        assert "…" in chip


class TestCodeBlock:
    def test_empty_returns_empty(self):
        out, overflow = _form_snippet_code_block("", 100)
        assert out == ""
        assert overflow is False

    def test_whitespace_only_returns_empty(self):
        out, _ = _form_snippet_code_block("   ", 100)
        assert out == ""

    def test_none_returns_empty(self):
        out, overflow = _form_snippet_code_block(None, 100)
        assert out == ""
        assert overflow is False

    def test_non_string_returns_empty(self):
        out, _ = _form_snippet_code_block({"x": 1}, 100)
        assert out == ""

    def test_short_no_overflow(self):
        out, overflow = _form_snippet_code_block("<form></form>", 100)
        assert overflow is False
        # HTML-escaped output.
        assert "&lt;form&gt;&lt;/form&gt;" in out

    def test_long_overflow_flag(self):
        long_form = "<form>" + "x" * 5000 + "</form>"
        out, overflow = _form_snippet_code_block(long_form, 100)
        assert overflow is True
        assert out.endswith("…")


class TestEmptyState:
    def test_no_stream_uses_primary_tint(self):
        body = _render_form_snippet_empty_state_html("no_stream")
        assert "#7d2df3" in body
        assert "#f2eafe" in body  # accent_bg
        assert "No tracking stream" in body

    def test_no_stream_points_at_connections(self):
        body = _render_form_snippet_empty_state_html("no_stream")
        assert "Connections" in body

    def test_no_stream_mentions_install_surface(self):
        body = _render_form_snippet_empty_state_html("no_stream")
        # Should reference the JS tracking snippet surface.
        assert "g8://snippet/install" in body

    def test_unavailable_uses_muted(self):
        body = _render_form_snippet_empty_state_html("unavailable")
        assert "#777777" in body  # _G8_TEXT_MUTED
        assert "not available" in body.lower()

    def test_unknown_mode_falls_to_unavailable(self):
        body = _render_form_snippet_empty_state_html("mystery-mode")
        # Default branch = unavailable.
        assert "not available" in body.lower()


# ────────────────────────────────────────────────────────────────────────────
# HTML renderer
# ────────────────────────────────────────────────────────────────────────────


class TestRenderHtml:
    def test_none_returns_unavailable(self):
        out = render_form_snippet_html(None)
        assert "<!DOCTYPE html>" in out
        assert "not available" in out.lower()

    def test_non_dict_returns_unavailable(self):
        out = render_form_snippet_html("<form></form>")
        assert "not available" in out.lower()

    def test_empty_dict_returns_no_stream(self):
        # Empty dict has no write_key → no_stream branch.
        out = render_form_snippet_html({})
        assert "No tracking stream" in out

    def test_missing_write_key_returns_no_stream(self):
        out = render_form_snippet_html(
            {"html": "<form></form>", "fields": ["name"]}
        )
        assert "No tracking stream" in out

    def test_empty_write_key_returns_no_stream(self):
        out = render_form_snippet_html(
            {"write_key": "   ", "html": "<form></form>"}
        )
        assert "No tracking stream" in out

    def test_full_render_contains_doctype(self):
        out = render_form_snippet_html(SAMPLE_FORM)
        assert "<!DOCTYPE html>" in out
        assert out.endswith("</html>")

    def test_full_render_contains_header(self):
        out = render_form_snippet_html(SAMPLE_FORM)
        assert "Lead-capture form" in out
        assert "Form snippet" in out

    def test_status_chip_ready_when_html_present(self):
        out = render_form_snippet_html(SAMPLE_FORM)
        assert "FORM READY" in out
        assert "#d1fae5" in out  # positive green

    def test_status_chip_missing_when_html_empty(self):
        d = dict(SAMPLE_FORM, html="")
        out = render_form_snippet_html(d)
        assert "FORM MISSING" in out

    def test_four_stat_cards_present(self):
        out = render_form_snippet_html(SAMPLE_FORM)
        assert out.count("text-transform:uppercase") >= 4
        assert "WRITE KEY" in out.upper()
        assert "TRACKING HOST" in out.upper()
        assert "FIELDS" in out.upper()
        assert "EVENT NAME" in out.upper()

    def test_write_key_preview_rendered(self):
        out = render_form_snippet_html(SAMPLE_FORM)
        # Should render the clipped preview (first 16 chars + …).
        preview = WRITE_KEY[:16]
        assert preview in out
        assert "…" in out

    def test_write_key_never_leaks_into_preview_pill(self):
        """Security test: full key must NEVER appear in the status/preview."""
        out = render_form_snippet_html(SAMPLE_FORM)
        # The tail portion is never in the preview on the stat card.
        # The full key DOES appear inside the embedded form HTML
        # <pre> block, though — that's intentional (users copy it).
        # So we scope the check: the stat card label "WRITE KEY" must
        # be followed by only the preview (not the full key) before we
        # reach the next section boundary.
        #
        # Practical check: the write-key stat card div doesn't contain
        # the full secret. We find the WRITE KEY stat card's closing </div>
        # pair and ensure the full write key isn't between those.
        upper = out.upper()
        idx_label = upper.find("WRITE KEY")
        assert idx_label >= 0
        # Grab the 400 chars after the label — covers the stat card value div.
        window = out[idx_label : idx_label + 400]
        assert "ignored_tail" not in window
        assert WRITE_KEY not in window

    def test_preview_pill_uses_clipped_display_only(self):
        out = render_form_snippet_html(SAMPLE_FORM)
        # The 16-char preview is rendered; the full key is not in the
        # preview pill region.
        clipped = WRITE_KEY[:16]
        assert clipped in out

    def test_tracking_host_rendered(self):
        out = render_form_snippet_html(SAMPLE_FORM)
        assert TRACKING_HOST in out

    def test_field_count_rendered(self):
        out = render_form_snippet_html(SAMPLE_FORM)
        assert ">3<" in out  # 3 fields

    def test_event_name_rendered(self):
        out = render_form_snippet_html(SAMPLE_FORM)
        assert "form_submitted" in out

    def test_field_chips_rendered(self):
        out = render_form_snippet_html(SAMPLE_FORM)
        for field in ("name", "email", "company"):
            assert field in out

    def test_field_overflow_note_when_many_fields(self):
        many = [f"f{i}" for i in range(_MAX_FORM_SNIPPET_FIELDS_RENDERED + 5)]
        d = dict(SAMPLE_FORM, fields=many)
        out = render_form_snippet_html(d)
        assert "+ 5 more field" in out

    def test_empty_fields_shows_friendly_message(self):
        d = dict(SAMPLE_FORM, fields=[])
        out = render_form_snippet_html(d)
        assert "No fields declared" in out

    def test_form_html_rendered_in_pre_block(self):
        out = render_form_snippet_html(SAMPLE_FORM)
        assert "<pre" in out
        # Original content is HTML-escaped.
        assert "&lt;form" in out
        assert "g8-lead-form" in out

    def test_form_html_overflow_note_when_long(self):
        long_form = "<form>" + "x" * 10_000 + "</form>"
        d = dict(SAMPLE_FORM, html=long_form)
        out = render_form_snippet_html(d)
        assert "Truncated" in out

    def test_missing_form_html_shows_friendly_message(self):
        d = dict(SAMPLE_FORM, html="")
        out = render_form_snippet_html(d)
        assert "no <code>html</code> field" in out.lower() or "no html field" in out.lower()

    def test_notes_card_rendered_when_present(self):
        out = render_form_snippet_html(SAMPLE_FORM)
        assert "Integration notes" in out
        # Backend notes text appears.
        assert "track" in out

    def test_notes_card_omitted_when_empty(self):
        d = dict(SAMPLE_FORM, notes="")
        out = render_form_snippet_html(d)
        assert "Integration notes" not in out

    def test_drill_up_lists_related_surfaces(self):
        out = render_form_snippet_html(SAMPLE_FORM)
        assert "g8://snippet/install" in out
        assert "g8://repos/dashboard" in out
        assert "g8://webhooks/events" in out
        assert "GET /snippet/form" in out
        assert "g8_get_form_snippet" in out

    def test_drill_up_does_NOT_list_self(self):
        """Drill-up card must NOT self-reference g8://snippet/form."""
        out = render_form_snippet_html(SAMPLE_FORM)
        # Find the "Related surfaces" div (drill-up card).
        idx = out.find("Related surfaces")
        assert idx >= 0
        drill_up_region = out[idx:]
        # Self-URI must not appear in drill-up region. (It may appear
        # elsewhere, but the drill-up card is the specific lock.)
        assert "g8://snippet/form" not in drill_up_region

    def test_no_single_side_accent_borders(self):
        out = render_form_snippet_html(SAMPLE_FORM)
        # No single-side colored border bars (AI-tell).
        for color_hex in ("#7d2df3", "#059669", "#ca3214"):
            assert f"border-left:4px solid {color_hex}" not in out
            assert f"border-right:4px solid {color_hex}" not in out
            assert f"border-left:3px solid {color_hex}" not in out
            assert f"border-right:3px solid {color_hex}" not in out

    def test_no_legacy_accent_hexes(self):
        """Legacy indigo/sky/teal accents must not appear — graph8 only.

        Note: `#7d2df3` (graph8 primary) IS expected to appear on any
        surface using `_G8_PRIMARY`; it was auto-migrated from `#4338ca`
        on 2026-04-21 (token cleanup). The regression test now locks out
        the pre-migration indigo-600 specifically.
        """
        out = render_form_snippet_html(SAMPLE_FORM)
        assert "#4338ca" not in out  # indigo-600
        assert "#4f46e5" not in out  # indigo-600 alt
        assert "#0ea5e9" not in out  # sky-500
        assert "#0d9488" not in out  # teal-600
        assert "#0891b2" not in out  # cyan-600

    def test_xss_escape_on_field_name(self):
        d = dict(SAMPLE_FORM, fields=["<script>alert(1)</script>"])
        out = render_form_snippet_html(d)
        # The raw <script> (without escape) must not appear.
        assert "<script>alert(1)</script>" not in out
        assert "&lt;script&gt;" in out

    def test_xss_escape_on_event_name(self):
        d = dict(SAMPLE_FORM, event_name="<img/onerror=alert(1)>")
        out = render_form_snippet_html(d)
        assert "<img/onerror" not in out.replace("&lt;", "<!escaped-")
        assert "&lt;img" in out

    def test_xss_escape_on_tracking_host(self):
        d = dict(SAMPLE_FORM, tracking_host="<script>alert(1)</script>")
        out = render_form_snippet_html(d)
        assert "<script>alert(1)</script>" not in out

    def test_xss_escape_on_notes(self):
        d = dict(SAMPLE_FORM, notes="<b>bold</b>")
        out = render_form_snippet_html(d)
        # Notes field should be escaped.
        assert "<b>bold</b>" not in out
        assert "&lt;b&gt;bold&lt;/b&gt;" in out

    def test_xss_escape_on_form_html_inside_pre(self):
        """The form html is rendered ESCAPED inside <pre> (user reads it)."""
        d = dict(
            SAMPLE_FORM,
            html='<script>alert(1)</script><form></form>',
        )
        out = render_form_snippet_html(d)
        # The <script> must be escaped so the browser doesn't execute it.
        assert "&lt;script&gt;alert(1)&lt;/script&gt;" in out

    def test_html_escapes_write_key_in_code_block(self):
        """The write key appears inside the form HTML <pre> block.

        That's intentional (users copy it), but any < > & chars in it
        must still be escaped so they don't break the DOM.
        """
        weird_key = 'wk<script>"&amp;"'
        form_html = f'<form data-write-key="{weird_key}"></form>'
        d = dict(SAMPLE_FORM, html=form_html, write_key=weird_key)
        out = render_form_snippet_html(d)
        # Raw key must be escaped inside pre. No unescaped <script>.
        assert "<script>" not in out.replace("&lt;", "<!escaped-")


# ────────────────────────────────────────────────────────────────────────────
# Text fallback
# ────────────────────────────────────────────────────────────────────────────


class TestTextFallback:
    def test_none_returns_not_available(self):
        out = render_form_snippet_text_fallback(None)
        assert "not available" in out.lower()

    def test_non_dict_returns_not_available(self):
        out = render_form_snippet_text_fallback("<form></form>")
        assert "not available" in out.lower()

    def test_missing_write_key_returns_no_stream(self):
        out = render_form_snippet_text_fallback({"html": "<form></form>"})
        assert "No tracking stream" in out

    def test_empty_write_key_returns_no_stream(self):
        out = render_form_snippet_text_fallback(
            {"write_key": "   ", "html": "<form></form>"}
        )
        assert "No tracking stream" in out

    def test_full_render_has_header(self):
        out = render_form_snippet_text_fallback(SAMPLE_FORM)
        assert out.startswith("# Form snippet — lead-capture form")

    def test_stats_section(self):
        out = render_form_snippet_text_fallback(SAMPLE_FORM)
        assert "## Stats" in out
        assert "Write key:" in out
        assert "Tracking host:" in out
        assert "Fields:" in out
        assert "Event name:" in out

    def test_write_key_in_stats_is_clipped(self):
        out = render_form_snippet_text_fallback(SAMPLE_FORM)
        # Stats row should show the clipped preview, not the full key.
        # Extract the "Write key:" line.
        for line in out.splitlines():
            if line.startswith("- Write key:"):
                assert "ignored_tail" not in line
                assert WRITE_KEY not in line
                break
        else:
            pytest.fail("No 'Write key:' line found")

    def test_full_write_key_intentional_in_fenced_html_block(self):
        """Full write key IS in the fenced ```html block.

        That's intentional — the user copies this block into their site,
        so it has to contain the real key.
        """
        d = dict(SAMPLE_FORM, html=f'<form data-write-key="{WRITE_KEY}"></form>')
        out = render_form_snippet_text_fallback(d)
        assert "```html" in out
        # Full key IS present inside the fenced block.
        assert WRITE_KEY in out

    def test_fields_section(self):
        out = render_form_snippet_text_fallback(SAMPLE_FORM)
        assert "## Fields captured (3)" in out
        assert "- `name`" in out
        assert "- `email`" in out
        assert "- `company`" in out

    def test_empty_fields_section(self):
        d = dict(SAMPLE_FORM, fields=[])
        out = render_form_snippet_text_fallback(d)
        assert "## Fields captured" in out
        assert "did not declare" in out.lower()

    def test_field_overflow_note(self):
        many = [f"f{i}" for i in range(_MAX_FORM_SNIPPET_FIELDS_RENDERED + 7)]
        d = dict(SAMPLE_FORM, fields=many)
        out = render_form_snippet_text_fallback(d)
        assert "+ 7 more field" in out

    def test_form_html_in_fenced_html_block(self):
        out = render_form_snippet_text_fallback(SAMPLE_FORM)
        assert "## Lead-capture form HTML" in out
        assert "```html" in out
        # Closing fence.
        assert out.count("```") >= 2
        # Original content inside.
        assert "g8-lead-form" in out

    def test_missing_form_html_shows_friendly_message(self):
        d = dict(SAMPLE_FORM, html="")
        out = render_form_snippet_text_fallback(d)
        assert "## Lead-capture form HTML" in out
        assert "no `html` field" in out.lower()

    def test_notes_section_when_present(self):
        out = render_form_snippet_text_fallback(SAMPLE_FORM)
        assert "## Integration notes" in out

    def test_notes_section_omitted_when_empty(self):
        d = dict(SAMPLE_FORM, notes="")
        out = render_form_snippet_text_fallback(d)
        assert "## Integration notes" not in out

    def test_manage_block_present(self):
        out = render_form_snippet_text_fallback(SAMPLE_FORM)
        assert "## Related surfaces" in out
        assert "g8://snippet/install" in out
        assert "g8://repos/dashboard" in out
        assert "g8://webhooks/events" in out
        assert "GET /snippet/form" in out
        assert "g8_get_form_snippet" in out

    def test_manage_block_does_not_list_self(self):
        """Text fallback: related-surfaces block must not self-reference."""
        out = render_form_snippet_text_fallback(SAMPLE_FORM)
        idx = out.find("## Related surfaces")
        assert idx >= 0
        related = out[idx:]
        assert "g8://snippet/form" not in related

    def test_ends_with_newline(self):
        out = render_form_snippet_text_fallback(SAMPLE_FORM)
        assert out.endswith("\n")

    def test_text_is_valid_markdown_enough(self):
        """Plain-markdown test: no raw HTML leaking outside fenced blocks."""
        import re

        out = render_form_snippet_text_fallback(SAMPLE_FORM)
        # Strip fenced code blocks (they legitimately contain <form>, <script>).
        bare = re.sub(r"```.*?```", "", out, flags=re.DOTALL)
        assert "<script" not in bare
        assert "<form" not in bare
        assert "<b>" not in bare


# ────────────────────────────────────────────────────────────────────────────
# Smoke
# ────────────────────────────────────────────────────────────────────────────


class TestSmoke:
    def test_html_idempotent_on_same_input(self):
        out1 = render_form_snippet_html(SAMPLE_FORM)
        out2 = render_form_snippet_html(SAMPLE_FORM)
        assert out1 == out2

    def test_text_idempotent_on_same_input(self):
        out1 = render_form_snippet_text_fallback(SAMPLE_FORM)
        out2 = render_form_snippet_text_fallback(SAMPLE_FORM)
        assert out1 == out2

    def test_realistic_4_field_payload_renders_both_paths(self):
        d = dict(
            SAMPLE_FORM, fields=["name", "email", "company", "phone"]
        )
        html_out = render_form_snippet_html(d)
        text_out = render_form_snippet_text_fallback(d)
        # Both paths reference all 4 fields.
        for f in ("name", "email", "company", "phone"):
            assert f in html_out
            assert f in text_out

    def test_empty_fields_list_renders_safely(self):
        d = dict(SAMPLE_FORM, fields=[])
        html_out = render_form_snippet_html(d)
        text_out = render_form_snippet_text_fallback(d)
        # No crash; both paths render the friendly fallback message.
        assert html_out
        assert text_out
