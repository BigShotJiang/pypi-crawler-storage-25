"""Unit tests for the persona dashboard HTML renderer (upgrade 4 — app surface #3).

Same discipline as the sequence-preview and ad-images renderers:

- Every backend field is HTML-escaped (XSS safety)
- Cap on personas rendered so a large list doesn't blow up the response
- Empty / None / malformed input produces an empty-state page, never an exception
- Plaintext fallback mirrors the same truths
"""

from __future__ import annotations

from html.parser import HTMLParser

import pytest

from g8_mcp_server.app_renderer import (
    _MAX_PERSONAS_RENDERED,
    _MAX_PERSONA_SIGNALS_RENDERED,
    render_persona_dashboard_html,
    render_persona_dashboard_text_fallback,
)


def _persona(idx: int = 0, **overrides) -> dict:
    """Build a minimally complete persona dict."""
    base = {
        "id": f"persona_{idx}",
        "title": f"VP Sales persona {idx}",
        "priority": ["P0", "P1", "P2"][idx % 3],
        "confidence": ["high", "medium", "low"][idx % 3],
        "status": "active",
        "pinned": idx == 0,
        "why_target": f"Persona {idx} buys because of budget authority and Q4 deadline pressure.",
        "campaign_approach": f"Lead with ROI proof points; open with a warm intro reference.",
        "expected_receptivity": "Medium-high; cold but responsive during pipeline reviews.",
        "recommended_goal": "Book a 20-minute intro call",
        "key_signals": [
            "Headcount growth > 20%",
            "Hiring SDRs",
            "Recent funding round",
        ],
    }
    base.update(overrides)
    return base


def _personas(n: int = 3) -> list[dict]:
    return [_persona(idx=i) for i in range(n)]


class _TagCollector(HTMLParser):
    """Collects start tags so we can check HTML is well-formed enough to parse."""

    def __init__(self):
        super().__init__()
        self.tags: list[str] = []

    def handle_starttag(self, tag, attrs):
        self.tags.append(tag)


# ---------------------------------------------------------------------------
# Happy path rendering
# ---------------------------------------------------------------------------


class TestRenderPersonaDashboardHtml:
    def test_returns_complete_html_document(self):
        result = render_persona_dashboard_html(personas=_personas(n=3))
        assert result.startswith("<!doctype html>")
        assert "<html" in result and "</html>" in result.rstrip()
        assert "Personas" in result

    def test_renders_each_persona_title(self):
        result = render_persona_dashboard_html(personas=_personas(n=3))
        assert "VP Sales persona 0" in result
        assert "VP Sales persona 1" in result
        assert "VP Sales persona 2" in result

    def test_renders_priority_and_confidence_badges(self):
        result = render_persona_dashboard_html(personas=_personas(n=1))
        # Priority label in the badge
        assert "Priority" in result
        # Confidence label too (badge text is e.g. "Confidence: high")
        assert "Confidence" in result

    def test_renders_signals_as_pills(self):
        result = render_persona_dashboard_html(personas=_personas(n=1))
        assert "Headcount growth" in result
        assert "Hiring SDRs" in result
        assert "Recent funding round" in result

    def test_pinned_star_shown(self):
        personas = [_persona(idx=0)]
        personas[0]["pinned"] = True
        result = render_persona_dashboard_html(personas=personas)
        assert "★" in result

    def test_pinned_absent_when_false(self):
        personas = [_persona(idx=1)]
        personas[0]["pinned"] = False
        result = render_persona_dashboard_html(personas=personas)
        # Should still render but without the star
        assert "★" not in result or result.count("★") == 0

    def test_why_and_approach_sections(self):
        result = render_persona_dashboard_html(personas=_personas(n=1))
        assert "Why target" in result
        assert "Campaign approach" in result
        assert "buys because of budget authority" in result
        assert "ROI proof points" in result

    def test_no_javascript_in_output(self):
        result = render_persona_dashboard_html(personas=_personas(n=2))
        assert "<script" not in result.lower()
        assert "onerror" not in result.lower()
        assert "onload" not in result.lower()
        assert "javascript:" not in result.lower()

    def test_html_is_parseable(self):
        parser = _TagCollector()
        parser.feed(render_persona_dashboard_html(personas=_personas(n=2)))
        assert "html" in parser.tags
        assert "body" in parser.tags
        # Grid of personas uses <article> cards
        assert "article" in parser.tags

    def test_org_label_rendered(self):
        result = render_persona_dashboard_html(personas=_personas(n=1), org_label="Acme Corp")
        assert "Acme Corp" in result


# ---------------------------------------------------------------------------
# XSS / escaping
# ---------------------------------------------------------------------------


class TestEscaping:
    def test_title_escaped(self):
        p = _persona()
        p["title"] = '<script>alert("xss")</script>'
        result = render_persona_dashboard_html(personas=[p])
        assert "<script>" not in result
        assert "&lt;script&gt;" in result

    def test_why_target_escaped(self):
        p = _persona()
        p["why_target"] = '<img src=x onerror="alert(1)">'
        result = render_persona_dashboard_html(personas=[p])
        assert '<img src=x onerror=' not in result
        assert "&lt;img" in result

    def test_signal_escaped(self):
        p = _persona()
        p["key_signals"] = ['"><svg onload=alert(1)>']
        result = render_persona_dashboard_html(personas=[p])
        assert "<svg onload" not in result

    def test_status_escaped(self):
        p = _persona()
        p["status"] = "<b>active</b>"
        result = render_persona_dashboard_html(personas=[p])
        assert "<b>active</b>" not in result

    def test_org_label_escaped(self):
        result = render_persona_dashboard_html(
            personas=_personas(n=1),
            org_label='<script>bad</script>',
        )
        assert "<script>bad</script>" not in result
        assert "&lt;script&gt;bad" in result


# ---------------------------------------------------------------------------
# Caps, malformed input, empty state
# ---------------------------------------------------------------------------


class TestBounds:
    def test_persona_cap_enforced(self):
        personas = _personas(n=_MAX_PERSONAS_RENDERED + 5)
        result = render_persona_dashboard_html(personas=personas)
        assert "persona(s) omitted" in result
        # Only _MAX_PERSONAS_RENDERED cards should render
        article_count = result.count("<article")
        assert article_count == _MAX_PERSONAS_RENDERED

    def test_signal_cap_enforced(self):
        p = _persona()
        p["key_signals"] = [f"signal-{i}" for i in range(_MAX_PERSONA_SIGNALS_RENDERED + 4)]
        result = render_persona_dashboard_html(personas=[p])
        # Only _MAX_PERSONA_SIGNALS_RENDERED signals render
        signal_pill_count = result.count('class="signal"')
        assert signal_pill_count == _MAX_PERSONA_SIGNALS_RENDERED

    def test_none_personas_renders_empty_state(self):
        result = render_persona_dashboard_html(personas=None)
        assert "<!doctype html>" in result
        assert "No personas configured" in result

    def test_empty_list_renders_empty_state(self):
        result = render_persona_dashboard_html(personas=[])
        assert "No personas configured" in result

    def test_non_list_input_renders_empty_state(self):
        # Defensive — if a caller passes a string or dict, should not raise.
        result = render_persona_dashboard_html(personas="not-a-list")  # type: ignore[arg-type]
        assert "No personas configured" in result

    def test_non_dict_persona_skipped(self):
        mixed = [_persona(idx=0), "garbage", _persona(idx=1)]
        result = render_persona_dashboard_html(personas=mixed)  # type: ignore[arg-type]
        # Only the two valid personas should render
        article_count = result.count("<article")
        assert article_count == 2

    def test_missing_title_falls_back(self):
        p = _persona()
        p.pop("title")
        result = render_persona_dashboard_html(personas=[p])
        assert "Untitled persona" in result

    def test_missing_optional_fields_does_not_raise(self):
        p = {"id": "persona_minimal", "title": "Minimal persona"}
        result = render_persona_dashboard_html(personas=[p])
        # Should include title and render a card
        assert "Minimal persona" in result
        assert "<article" in result


# ---------------------------------------------------------------------------
# Plaintext fallback
# ---------------------------------------------------------------------------


class TestPersonaDashboardTextFallback:
    def test_none_returns_empty_state(self):
        result = render_persona_dashboard_text_fallback(personas=None)
        assert "No personas configured" in result

    def test_empty_list_returns_empty_state(self):
        result = render_persona_dashboard_text_fallback(personas=[])
        assert "No personas configured" in result

    def test_plaintext_renders_personas(self):
        result = render_persona_dashboard_text_fallback(personas=_personas(n=2))
        assert "VP Sales persona 0" in result
        assert "VP Sales persona 1" in result
        assert "Priority:" in result
        assert "Confidence:" in result

    def test_plaintext_signals(self):
        result = render_persona_dashboard_text_fallback(personas=_personas(n=1))
        assert "Signals:" in result
        assert "Headcount growth" in result

    def test_plaintext_why_and_approach(self):
        result = render_persona_dashboard_text_fallback(personas=_personas(n=1))
        assert "Why target:" in result
        assert "Campaign approach:" in result

    def test_plaintext_persona_cap(self):
        personas = _personas(n=_MAX_PERSONAS_RENDERED + 3)
        result = render_persona_dashboard_text_fallback(personas=personas)
        assert "and 3 more" in result

    def test_plaintext_org_label(self):
        result = render_persona_dashboard_text_fallback(
            personas=_personas(n=1),
            org_label="Acme Corp",
        )
        assert "Acme Corp" in result

    def test_plaintext_non_list_input(self):
        result = render_persona_dashboard_text_fallback(personas="not-a-list")  # type: ignore[arg-type]
        assert "No personas configured" in result
