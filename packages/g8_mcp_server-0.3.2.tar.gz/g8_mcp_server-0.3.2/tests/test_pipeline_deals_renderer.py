"""Unit tests for HTML app surface #61 — per-pipeline deals renderer.

URI: ``g8://pipelines/{pipeline_id}/deals``

Locks regression invariants for:
  - graph8 design tokens (no legacy accent hexes, no single-side colored
    accent borders, Aeonik font family, primary ``#7d2df3``)
  - drill-up card does NOT self-reference the surface URI
  - no ``<script>`` / ``javascript:`` / inline event handlers
  - pagination safety: ``total >= visible`` override, ``total < visible``
    ignored (clamped to ``len(deals)``)
  - XSS escape on every user-controlled field (deal name, description,
    stage_name, pipeline name, deal_id in drill-down, currency)
  - display name fallback (name → ``(unnamed deal)``)
  - amount parser rejects bool, negative, NaN, inf
  - stage ordering by ``position`` asc with alpha tiebreak
  - dominant currency selection with alpha tiebreak
  - per-stage subtotal filters to matching currency only
  - stage-matching by id (preferred) or case-insensitive name fallback
  - orphans bucket for stage-mismatched deals
  - smoke tests on realistic and empty payloads
"""

from __future__ import annotations

import pytest

from g8_mcp_server import app_renderer as ar


# -------------------------------------------------------------------- #
# Sample payload                                                      #
# -------------------------------------------------------------------- #

_PIPELINE_ID = "pipe-nb-42"

_PIPELINE: dict = {
    "id": _PIPELINE_ID,
    "name": "New Business",
    "stages": [
        {"id": "stage-lead", "name": "Lead", "position": 1},
        {"id": "stage-disco", "name": "Discovery", "position": 2},
        {"id": "stage-prop", "name": "Proposal", "position": 3},
        {"id": "stage-nego", "name": "Negotiation", "position": 4},
        {"id": "stage-closed", "name": "Closed Won", "position": 5},
    ],
}

_BASE_DEAL = {
    "id": "deal-111",
    "name": "Acme Enterprise License",
    "description": "3yr ELA for the analytics platform.",
    "amount": 150000.0,
    "currency": "USD",
    "stage_id": "stage-prop",
    "stage_name": "Proposal",
    "pipeline_id": _PIPELINE_ID,
    "company_id": 101,
    "close_date": "2026-06-15",
}

_SAMPLE_DEALS: list[dict] = [
    _BASE_DEAL,  # Proposal, 150k USD
    {
        "id": "deal-222",
        "name": "Beta Annual Renewal",
        "description": "Renewal for the mid-market plan.",
        "amount": 42000,
        "currency": "USD",
        "stage_id": "stage-nego",
        "stage_name": "Negotiation",
        "close_date": "2026-05-05",
    },
    {
        "id": "deal-333",
        "name": "Gamma Pilot",
        "description": None,
        "amount": "8500",  # string amount
        "currency": "EUR",
        "stage_id": "stage-disco",
        "stage_name": "Discovery",
        "close_date": "2026-04-15",
    },
    {
        "id": "deal-444",
        "name": "Delta Holdings Expansion",
        "amount": 250000.5,
        "currency": "USD",
        "stage_id": "stage-prop",  # same stage as _BASE_DEAL
        "stage_name": "Proposal",
        "close_date": "2027-01-01",
    },
    {
        # Deal with mismatched stage — should become an orphan
        "id": "deal-555",
        "name": "Epsilon Add-on",
        "amount": 5000,
        "currency": "USD",
        "stage_name": "Archived",  # not in pipeline stages
    },
    {
        # Anonymous deal — minimal fields
        "stage_id": "stage-lead",
        "stage_name": "Lead",
    },
]


# -------------------------------------------------------------------- #
# _pipeline_deals_clip                                                #
# -------------------------------------------------------------------- #

class TestClip:
    def test_non_string_returns_empty(self):
        assert ar._pipeline_deals_clip(None, 50) == ""
        assert ar._pipeline_deals_clip(123, 50) == ""
        assert ar._pipeline_deals_clip([], 50) == ""
        assert ar._pipeline_deals_clip({"a": 1}, 50) == ""

    def test_empty_string_returns_empty(self):
        assert ar._pipeline_deals_clip("", 50) == ""
        assert ar._pipeline_deals_clip("   ", 50) == ""
        assert ar._pipeline_deals_clip("\t\n", 50) == ""

    def test_short_string_passes_through(self):
        assert ar._pipeline_deals_clip("hello", 50) == "hello"

    def test_strips_whitespace(self):
        assert ar._pipeline_deals_clip("  hi  ", 50) == "hi"

    def test_escapes_html(self):
        out = ar._pipeline_deals_clip("<script>x</script>", 100)
        assert "<script>" not in out
        assert "&lt;script&gt;" in out

    def test_truncates_with_ellipsis(self):
        # cap=10 → first 9 chars + "…"
        out = ar._pipeline_deals_clip("a" * 50, 10)
        assert out.endswith("…")
        # 9 "a"s + ellipsis
        assert out.count("a") == 9

    def test_truncation_preserves_escape(self):
        # Ensure that even after clipping, HTML stays safe
        raw = "<" + "x" * 100
        out = ar._pipeline_deals_clip(raw, 10)
        assert "<" not in out
        assert "&lt;" in out


# -------------------------------------------------------------------- #
# _pipeline_deals_deal_name                                           #
# -------------------------------------------------------------------- #

class TestDealName:
    def test_with_name(self):
        assert ar._pipeline_deals_deal_name({"name": "Acme Deal"}) == "Acme Deal"

    def test_empty_name_falls_back(self):
        assert ar._pipeline_deals_deal_name({"name": ""}) == "(unnamed deal)"
        assert ar._pipeline_deals_deal_name({"name": "   "}) == "(unnamed deal)"

    def test_missing_name_falls_back(self):
        assert ar._pipeline_deals_deal_name({}) == "(unnamed deal)"
        assert ar._pipeline_deals_deal_name({"name": None}) == "(unnamed deal)"

    def test_non_string_name_falls_back(self):
        assert ar._pipeline_deals_deal_name({"name": 123}) == "(unnamed deal)"
        assert ar._pipeline_deals_deal_name({"name": []}) == "(unnamed deal)"

    def test_truncates_long_name(self):
        long_name = "a" * 200
        out = ar._pipeline_deals_deal_name({"name": long_name})
        assert out.endswith("…")
        assert len(out) <= ar._MAX_PIPELINE_DEALS_NAME_LEN

    def test_escapes_html(self):
        out = ar._pipeline_deals_deal_name({"name": "<script>x</script>"})
        assert "<script>" not in out
        assert "&lt;" in out


# -------------------------------------------------------------------- #
# _pipeline_deals_pipeline_name                                       #
# -------------------------------------------------------------------- #

class TestPipelineName:
    def test_with_name(self):
        out = ar._pipeline_deals_pipeline_name(_PIPELINE, _PIPELINE_ID)
        assert out == "New Business"

    def test_missing_pipeline_falls_back_to_id(self):
        out = ar._pipeline_deals_pipeline_name(None, "pipe-xxx")
        assert out == "Pipeline #pipe-xxx"

    def test_non_dict_pipeline_falls_back(self):
        out = ar._pipeline_deals_pipeline_name("not a dict", "pipe-xxx")  # type: ignore[arg-type]
        assert out == "Pipeline #pipe-xxx"

    def test_empty_name_falls_back_to_id(self):
        out = ar._pipeline_deals_pipeline_name({"name": ""}, "pipe-xxx")
        assert out == "Pipeline #pipe-xxx"

    def test_empty_name_and_empty_id_falls_back(self):
        out = ar._pipeline_deals_pipeline_name(None, "")
        assert out == "Pipeline"

    def test_escapes_html_in_name(self):
        out = ar._pipeline_deals_pipeline_name(
            {"name": "<script>x</script>"}, "pid"
        )
        assert "<script>" not in out
        assert "&lt;" in out

    def test_escapes_html_in_id(self):
        out = ar._pipeline_deals_pipeline_name(None, "<xss>")
        assert "<xss>" not in out

    def test_truncates_long_name(self):
        long_name = "p" * 200
        out = ar._pipeline_deals_pipeline_name({"name": long_name}, "pid")
        assert out.endswith("…")


# -------------------------------------------------------------------- #
# _pipeline_deals_parse_amount                                        #
# -------------------------------------------------------------------- #

class TestParseAmount:
    def test_int(self):
        assert ar._pipeline_deals_parse_amount(150) == 150.0

    def test_float(self):
        assert ar._pipeline_deals_parse_amount(150.5) == 150.5

    def test_str_number(self):
        assert ar._pipeline_deals_parse_amount("250") == 250.0

    def test_str_with_commas(self):
        assert ar._pipeline_deals_parse_amount("1,250,000") == 1250000.0

    def test_str_with_whitespace(self):
        assert ar._pipeline_deals_parse_amount("  500  ") == 500.0

    def test_empty_str(self):
        assert ar._pipeline_deals_parse_amount("") is None
        assert ar._pipeline_deals_parse_amount("   ") is None

    def test_none(self):
        assert ar._pipeline_deals_parse_amount(None) is None

    def test_invalid_str(self):
        assert ar._pipeline_deals_parse_amount("abc") is None

    def test_bool_rejected(self):
        # bool is a subclass of int — must be rejected
        assert ar._pipeline_deals_parse_amount(True) is None
        assert ar._pipeline_deals_parse_amount(False) is None

    def test_nan_rejected(self):
        assert ar._pipeline_deals_parse_amount(float("nan")) is None
        assert ar._pipeline_deals_parse_amount("nan") is None

    def test_inf_rejected(self):
        assert ar._pipeline_deals_parse_amount(float("inf")) is None
        assert ar._pipeline_deals_parse_amount(float("-inf")) is None
        assert ar._pipeline_deals_parse_amount("inf") is None

    def test_negative_rejected(self):
        assert ar._pipeline_deals_parse_amount(-100) is None
        assert ar._pipeline_deals_parse_amount(-1.5) is None
        assert ar._pipeline_deals_parse_amount("-250") is None

    def test_zero_accepted(self):
        assert ar._pipeline_deals_parse_amount(0) == 0.0
        assert ar._pipeline_deals_parse_amount("0") == 0.0

    def test_list_rejected(self):
        assert ar._pipeline_deals_parse_amount([100]) is None
        assert ar._pipeline_deals_parse_amount({"amount": 100}) is None


# -------------------------------------------------------------------- #
# _pipeline_deals_format_amount                                       #
# -------------------------------------------------------------------- #

class TestFormatAmount:
    def test_none_returns_empty(self):
        assert ar._pipeline_deals_format_amount(None, "USD") == ""

    def test_zero_dollars(self):
        assert ar._pipeline_deals_format_amount(0.0, "USD") == "$0"

    def test_dollars_under_1k(self):
        assert ar._pipeline_deals_format_amount(500.0, "USD") == "$500"

    def test_thousands(self):
        assert ar._pipeline_deals_format_amount(1500.0, "USD") == "$1.5k"

    def test_round_thousands(self):
        assert ar._pipeline_deals_format_amount(5000.0, "USD") == "$5k"

    def test_millions(self):
        assert ar._pipeline_deals_format_amount(1500000.0, "USD") == "$1.5M"

    def test_large_value_no_decimal(self):
        # When value >= 100 in unit, drops the decimal
        out = ar._pipeline_deals_format_amount(150000.0, "USD")
        assert out == "$150k"

    def test_non_usd_currency_uses_prefix(self):
        out = ar._pipeline_deals_format_amount(1500.0, "EUR")
        assert "EUR" in out

    def test_non_usd_no_dollar(self):
        out = ar._pipeline_deals_format_amount(1500.0, "EUR")
        assert not out.startswith("$")

    def test_none_currency_defaults_to_dollar(self):
        out = ar._pipeline_deals_format_amount(1500.0, None)
        assert out.startswith("$")

    def test_empty_currency_defaults_to_dollar(self):
        out = ar._pipeline_deals_format_amount(1500.0, "")
        assert out.startswith("$")

    def test_currency_stripped_and_uppercased(self):
        out = ar._pipeline_deals_format_amount(1500.0, "  eur  ")
        assert "EUR" in out

    def test_non_string_currency_defaults_to_dollar(self):
        out = ar._pipeline_deals_format_amount(1500.0, 123)  # type: ignore[arg-type]
        assert out.startswith("$")


# -------------------------------------------------------------------- #
# _pipeline_deals_extract_stages                                      #
# -------------------------------------------------------------------- #

class TestExtractStages:
    def test_none_pipeline_returns_empty(self):
        assert ar._pipeline_deals_extract_stages(None) == []

    def test_non_dict_returns_empty(self):
        assert ar._pipeline_deals_extract_stages("not dict") == []  # type: ignore[arg-type]

    def test_no_stages_key_returns_empty(self):
        assert ar._pipeline_deals_extract_stages({"name": "x"}) == []

    def test_non_list_stages_returns_empty(self):
        assert ar._pipeline_deals_extract_stages({"stages": "not list"}) == []
        assert ar._pipeline_deals_extract_stages({"stages": {}}) == []

    def test_filters_non_dict_entries(self):
        out = ar._pipeline_deals_extract_stages(
            {"stages": [{"name": "A"}, "not dict", 123, None]}
        )
        assert len(out) == 1
        assert out[0]["name"] == "A"

    def test_sorts_by_position_asc(self):
        out = ar._pipeline_deals_extract_stages({"stages": [
            {"name": "C", "position": 3},
            {"name": "A", "position": 1},
            {"name": "B", "position": 2},
        ]})
        names = [s["name"] for s in out]
        assert names == ["A", "B", "C"]

    def test_alpha_tiebreak_on_equal_position(self):
        out = ar._pipeline_deals_extract_stages({"stages": [
            {"name": "Charlie", "position": 1},
            {"name": "Alpha", "position": 1},
            {"name": "Beta", "position": 1},
        ]})
        names = [s["name"] for s in out]
        assert names == ["Alpha", "Beta", "Charlie"]

    def test_unpositioned_go_to_end(self):
        out = ar._pipeline_deals_extract_stages({"stages": [
            {"name": "NoPos"},
            {"name": "A", "position": 1},
        ]})
        assert out[0]["name"] == "A"
        assert out[1]["name"] == "NoPos"

    def test_bool_position_treated_as_unpositioned(self):
        # bool is a subclass of int — but not a valid position
        out = ar._pipeline_deals_extract_stages({"stages": [
            {"name": "Bool", "position": True},
            {"name": "A", "position": 1},
        ]})
        assert out[0]["name"] == "A"

    def test_cap_at_max(self):
        big = [{"name": f"S{i}", "position": i} for i in range(50)]
        out = ar._pipeline_deals_extract_stages({"stages": big})
        assert len(out) == ar._MAX_PIPELINE_DEALS_STAGES_RENDERED


# -------------------------------------------------------------------- #
# _pipeline_deals_stage_id_from_deal                                  #
# _pipeline_deals_stage_name_from_deal                                #
# -------------------------------------------------------------------- #

class TestStageIdFromDeal:
    def test_string_id(self):
        assert ar._pipeline_deals_stage_id_from_deal({"stage_id": "s-1"}) == "s-1"

    def test_stripped(self):
        assert ar._pipeline_deals_stage_id_from_deal({"stage_id": "  s-1  "}) == "s-1"

    def test_int_id(self):
        assert ar._pipeline_deals_stage_id_from_deal({"stage_id": 42}) == "42"

    def test_bool_rejected(self):
        # bool is a subclass of int — must not be stringified
        assert ar._pipeline_deals_stage_id_from_deal({"stage_id": True}) == ""
        assert ar._pipeline_deals_stage_id_from_deal({"stage_id": False}) == ""

    def test_missing(self):
        assert ar._pipeline_deals_stage_id_from_deal({}) == ""
        assert ar._pipeline_deals_stage_id_from_deal({"stage_id": None}) == ""

    def test_empty_string(self):
        assert ar._pipeline_deals_stage_id_from_deal({"stage_id": ""}) == ""
        assert ar._pipeline_deals_stage_id_from_deal({"stage_id": "   "}) == ""


class TestStageNameFromDeal:
    def test_string_name(self):
        assert ar._pipeline_deals_stage_name_from_deal({"stage_name": "Lead"}) == "Lead"

    def test_stripped(self):
        assert ar._pipeline_deals_stage_name_from_deal(
            {"stage_name": "  Lead  "}
        ) == "Lead"

    def test_missing(self):
        assert ar._pipeline_deals_stage_name_from_deal({}) == ""

    def test_empty_string(self):
        assert ar._pipeline_deals_stage_name_from_deal({"stage_name": "   "}) == ""

    def test_non_string(self):
        assert ar._pipeline_deals_stage_name_from_deal({"stage_name": 123}) == ""


# -------------------------------------------------------------------- #
# _pipeline_deals_stage_has_deal                                      #
# -------------------------------------------------------------------- #

class TestStageHasDeal:
    def test_id_match_wins(self):
        stage = {"id": "s-1", "name": "Discovery"}
        deal = {"stage_id": "s-1", "stage_name": "Proposal"}  # name mismatch on purpose
        assert ar._pipeline_deals_stage_has_deal(stage, deal) is True

    def test_name_match_case_insensitive(self):
        stage = {"id": "s-1", "name": "Discovery"}
        deal = {"stage_name": "DISCOVERY"}
        assert ar._pipeline_deals_stage_has_deal(stage, deal) is True

    def test_name_match_when_no_id_on_deal(self):
        stage = {"id": "s-1", "name": "Discovery"}
        deal = {"stage_name": "Discovery"}
        assert ar._pipeline_deals_stage_has_deal(stage, deal) is True

    def test_no_match(self):
        stage = {"id": "s-1", "name": "Discovery"}
        deal = {"stage_id": "s-99", "stage_name": "Archived"}
        assert ar._pipeline_deals_stage_has_deal(stage, deal) is False

    def test_no_stage_id_or_name_on_deal(self):
        stage = {"id": "s-1", "name": "Discovery"}
        deal = {}
        assert ar._pipeline_deals_stage_has_deal(stage, deal) is False

    def test_stage_missing_id(self):
        stage = {"name": "Discovery"}
        deal = {"stage_name": "Discovery"}
        assert ar._pipeline_deals_stage_has_deal(stage, deal) is True

    def test_stage_missing_name(self):
        stage = {"id": "s-1"}
        deal = {"stage_id": "s-1"}
        assert ar._pipeline_deals_stage_has_deal(stage, deal) is True


# -------------------------------------------------------------------- #
# _pipeline_deals_group_by_stage                                      #
# -------------------------------------------------------------------- #

class TestGroupByStage:
    def test_groups_by_stage(self):
        grouped, orphans = ar._pipeline_deals_group_by_stage(
            _PIPELINE["stages"], _SAMPLE_DEALS
        )
        # 5 stages in pipeline
        assert len(grouped) == 5
        # Proposal stage should have 2 deals
        proposal_deals = [deals for stage, deals in grouped if stage["name"] == "Proposal"]
        assert len(proposal_deals) == 1
        assert len(proposal_deals[0]) == 2

    def test_orphans_contain_mismatched(self):
        grouped, orphans = ar._pipeline_deals_group_by_stage(
            _PIPELINE["stages"], _SAMPLE_DEALS
        )
        # deal-555 (Archived) is the orphan
        assert len(orphans) == 1
        assert orphans[0]["id"] == "deal-555"

    def test_empty_deals(self):
        grouped, orphans = ar._pipeline_deals_group_by_stage(
            _PIPELINE["stages"], []
        )
        assert len(grouped) == 5
        assert all(len(d) == 0 for _, d in grouped)
        assert orphans == []

    def test_empty_stages_all_orphans(self):
        grouped, orphans = ar._pipeline_deals_group_by_stage([], _SAMPLE_DEALS)
        assert grouped == []
        assert len(orphans) == len(_SAMPLE_DEALS)

    def test_preserves_stage_order(self):
        stages = [
            {"id": "z", "name": "Zebra"},
            {"id": "a", "name": "Alpha"},
        ]
        grouped, _ = ar._pipeline_deals_group_by_stage(stages, [])
        # Order must match input stage order (extract_stages sorts upstream)
        names = [stage["name"] for stage, _ in grouped]
        assert names == ["Zebra", "Alpha"]

    def test_non_dict_deals_filtered(self):
        grouped, orphans = ar._pipeline_deals_group_by_stage(
            _PIPELINE["stages"], [{"stage_id": "stage-prop"}, "not dict", 42, None]
        )
        # 1 valid deal should land in Proposal
        prop_deals = [d for s, d in grouped if s["name"] == "Proposal"][0]
        assert len(prop_deals) == 1


# -------------------------------------------------------------------- #
# _pipeline_deals_sort_by_amount                                      #
# -------------------------------------------------------------------- #

class TestSortByAmount:
    def test_amount_having_first(self):
        deals = [
            {"id": "a"},  # no amount
            {"id": "b", "amount": 100},
        ]
        sorted_ = ar._pipeline_deals_sort_by_amount(deals)
        assert sorted_[0]["id"] == "b"
        assert sorted_[1]["id"] == "a"

    def test_amount_desc(self):
        deals = [
            {"id": "a", "amount": 100},
            {"id": "b", "amount": 500},
            {"id": "c", "amount": 250},
        ]
        sorted_ = ar._pipeline_deals_sort_by_amount(deals)
        assert [d["id"] for d in sorted_] == ["b", "c", "a"]

    def test_stable_for_no_amounts(self):
        deals = [{"id": "a"}, {"id": "b"}, {"id": "c"}]
        sorted_ = ar._pipeline_deals_sort_by_amount(deals)
        # Python's sort is stable; input order preserved
        assert [d["id"] for d in sorted_] == ["a", "b", "c"]

    def test_empty(self):
        assert ar._pipeline_deals_sort_by_amount([]) == []


# -------------------------------------------------------------------- #
# _pipeline_deals_stage_subtotal                                      #
# -------------------------------------------------------------------- #

class TestStageSubtotal:
    def test_sums_matching_currency(self):
        deals = [
            {"amount": 100, "currency": "USD"},
            {"amount": 200, "currency": "USD"},
            {"amount": 500, "currency": "EUR"},
        ]
        assert ar._pipeline_deals_stage_subtotal(deals, "USD") == 300.0

    def test_skips_missing_amount(self):
        deals = [
            {"amount": 100, "currency": "USD"},
            {"currency": "USD"},
        ]
        assert ar._pipeline_deals_stage_subtotal(deals, "USD") == 100.0

    def test_skips_mismatched_currency(self):
        deals = [
            {"amount": 100, "currency": "USD"},
            {"amount": 500, "currency": "EUR"},
        ]
        assert ar._pipeline_deals_stage_subtotal(deals, "USD") == 100.0

    def test_empty_list_returns_zero(self):
        assert ar._pipeline_deals_stage_subtotal([], "USD") == 0.0

    def test_none_currency_sums_all(self):
        # When currency is None, no filter — sums all valid amounts
        deals = [
            {"amount": 100, "currency": "USD"},
            {"amount": 200, "currency": "EUR"},
        ]
        assert ar._pipeline_deals_stage_subtotal(deals, None) == 300.0


# -------------------------------------------------------------------- #
# _pipeline_deals_dominant_currency                                   #
# -------------------------------------------------------------------- #

class TestDominantCurrency:
    def test_single_currency(self):
        deals = [{"amount": 100, "currency": "USD"}]
        assert ar._pipeline_deals_dominant_currency(deals) == "USD"

    def test_most_common_wins(self):
        deals = [
            {"amount": 100, "currency": "USD"},
            {"amount": 200, "currency": "USD"},
            {"amount": 500, "currency": "EUR"},
        ]
        assert ar._pipeline_deals_dominant_currency(deals) == "USD"

    def test_alpha_tiebreak(self):
        # Two each of USD and EUR → alpha sort picks EUR
        deals = [
            {"amount": 100, "currency": "USD"},
            {"amount": 200, "currency": "EUR"},
            {"amount": 300, "currency": "USD"},
            {"amount": 400, "currency": "EUR"},
        ]
        assert ar._pipeline_deals_dominant_currency(deals) == "EUR"

    def test_empty(self):
        assert ar._pipeline_deals_dominant_currency([]) is None

    def test_no_amount_excluded(self):
        deals = [
            {"currency": "USD"},  # no amount
            {"amount": 100, "currency": "EUR"},
        ]
        assert ar._pipeline_deals_dominant_currency(deals) == "EUR"

    def test_mixed_case_normalized(self):
        deals = [
            {"amount": 100, "currency": "usd"},
            {"amount": 200, "currency": "USD"},
            {"amount": 300, "currency": "Usd"},
        ]
        assert ar._pipeline_deals_dominant_currency(deals) == "USD"

    def test_non_dict_skipped(self):
        deals = ["not dict", {"amount": 100, "currency": "USD"}]  # type: ignore[list-item]
        assert ar._pipeline_deals_dominant_currency(deals) == "USD"

    def test_empty_currency_excluded(self):
        deals = [
            {"amount": 100, "currency": ""},
            {"amount": 200, "currency": "USD"},
        ]
        assert ar._pipeline_deals_dominant_currency(deals) == "USD"


# -------------------------------------------------------------------- #
# _pipeline_deals_stat_card                                           #
# -------------------------------------------------------------------- #

class TestStatCard:
    def test_default_accent(self):
        out = ar._pipeline_deals_stat_card("X", "1")
        assert "X" in out
        assert ">1<" in out

    def test_primary_accent_uses_primary(self):
        out = ar._pipeline_deals_stat_card("X", "1", accent="primary")
        assert ar._G8_PRIMARY in out

    def test_positive_accent_uses_positive(self):
        out = ar._pipeline_deals_stat_card("X", "1", accent="positive")
        assert ar._G8_POSITIVE_FG in out

    def test_escapes_label(self):
        out = ar._pipeline_deals_stat_card("<xss>", "1")
        assert "<xss>" not in out

    def test_no_single_side_colored_accent_border(self):
        """Regression: graph8 design forbids one-sided colored accent borders."""
        for accent in ("default", "primary", "positive"):
            out = ar._pipeline_deals_stat_card("X", "1", accent=accent)
            assert "border-left:" not in out
            assert "border-top:" not in out
            assert "border-right:" not in out
            assert "border-bottom:" not in out


# -------------------------------------------------------------------- #
# _pipeline_deals_chip                                                #
# -------------------------------------------------------------------- #

class TestChip:
    def test_escapes_label(self):
        out = ar._pipeline_deals_chip("<xss>")
        assert "<xss>" not in out
        assert "&lt;xss&gt;" in out

    def test_uses_default_colors(self):
        out = ar._pipeline_deals_chip("ok")
        assert ar._G8_MUTED_BG in out or ar._G8_BORDER in out


# -------------------------------------------------------------------- #
# _pipeline_deals_empty_state_html                                    #
# -------------------------------------------------------------------- #

class TestEmptyStateHtml:
    def test_empty_mode(self):
        out = ar._pipeline_deals_empty_state_html(
            mode="empty", pipeline_name="New Business", pipeline_id="p1"
        )
        assert "No deals" in out
        assert "New Business" in out
        assert "POST /deals" in out

    def test_unavailable_mode(self):
        out = ar._pipeline_deals_empty_state_html(
            mode="unavailable", pipeline_name="P", pipeline_id="p1"
        )
        assert "not available" in out
        assert "GET /deals?pipeline_id=p1" in out

    def test_escapes_pipeline_id_in_url(self):
        out = ar._pipeline_deals_empty_state_html(
            mode="unavailable", pipeline_name="P", pipeline_id="<xss>"
        )
        assert "<xss>" not in out

    def test_empty_mode_uses_primary_accent(self):
        out = ar._pipeline_deals_empty_state_html(
            mode="empty", pipeline_name="P", pipeline_id="p1"
        )
        assert ar._G8_ACCENT_BG in out or ar._G8_ACCENT_BORDER in out

    def test_no_single_side_colored_border(self):
        out = ar._pipeline_deals_empty_state_html(
            mode="empty", pipeline_name="P", pipeline_id="p1"
        )
        assert "border-left:" not in out
        assert "border-top:" not in out
        assert "border-right:" not in out
        assert "border-bottom:" not in out


# -------------------------------------------------------------------- #
# render_pipeline_deals_html                                          #
# -------------------------------------------------------------------- #

class TestRenderHtml:
    def test_none_deals_returns_unavailable(self):
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=None
        )
        assert "not available" in out

    def test_non_list_deals_returns_unavailable(self):
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals="bogus"  # type: ignore[arg-type]
        )
        assert "not available" in out

    def test_empty_deals_returns_empty_state(self):
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=[]
        )
        assert "No deals" in out

    def test_renders_pipeline_name_in_header(self):
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        assert "New Business" in out

    def test_renders_all_kpi_cards(self):
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        assert "Deals in pipeline" in out
        assert "Pipeline value" in out
        assert "With amount" in out
        assert "With close date" in out

    def test_deals_count_in_kpi(self):
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        # 6 deals total in _SAMPLE_DEALS
        assert ">6<" in out

    def test_renders_stage_sections(self):
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        # All pipeline stages should appear
        assert "Lead" in out
        assert "Discovery" in out
        assert "Proposal" in out
        assert "Negotiation" in out
        assert "Closed Won" in out

    def test_stages_in_pipeline_order(self):
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        lead_pos = out.index("Lead")
        disco_pos = out.index("Discovery")
        prop_pos = out.index("Proposal")
        nego_pos = out.index("Negotiation")
        closed_pos = out.index("Closed Won")
        assert lead_pos < disco_pos < prop_pos < nego_pos < closed_pos

    def test_deal_name_rendered(self):
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        assert "Acme Enterprise License" in out
        assert "Beta Annual Renewal" in out
        assert "Gamma Pilot" in out
        assert "Delta Holdings Expansion" in out

    def test_anonymous_deal_uses_fallback(self):
        # The 6th deal in _SAMPLE_DEALS has no name
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        assert "(unnamed deal)" in out

    def test_deals_in_stage_sorted_by_amount_desc(self):
        # Proposal has Acme (150k) and Delta (250k). Delta should come first.
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        delta_pos = out.index("Delta Holdings Expansion")
        acme_pos = out.index("Acme Enterprise License")
        assert delta_pos < acme_pos

    def test_empty_stage_shows_placeholder(self):
        # Closed Won has no deals → "(no deals in this stage)"
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        assert "(no deals in this stage)" in out

    def test_orphans_section_rendered(self):
        # deal-555 "Epsilon Add-on" has stage_name "Archived" → orphan
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        assert "Unstaged" in out
        assert "Epsilon Add-on" in out

    def test_no_orphans_section_when_all_matched(self):
        # Drop deal-555, keep rest
        deals = [d for d in _SAMPLE_DEALS if d.get("id") != "deal-555"]
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=deals
        )
        assert "Unstaged" not in out

    def test_drill_up_lists_related_surfaces(self):
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        assert "g8://pipelines/overview" in out
        assert "g8://deals/pipeline" in out
        assert "g8://deals/dashboard" in out
        assert "POST /deals" in out

    def test_drill_up_does_NOT_list_self(self):
        """Regression: drill-up must not reference the per-pipeline URI."""
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        drill_start = out.index("Related surfaces")
        drill_block = out[drill_start:]
        # The literal URI must not self-reference
        assert "g8://pipelines/" + _PIPELINE_ID + "/deals" not in drill_block

    def test_pagination_total_overrides_visible(self):
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS, total=100
        )
        assert "of 100 total" in out

    def test_pagination_total_lower_is_clamped(self):
        # total < visible should be ignored
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS, total=2
        )
        assert "of 2 total" not in out

    def test_pagination_total_equal_no_suffix(self):
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS, total=6
        )
        assert "of 6 total" not in out

    def test_renders_drill_down_for_valid_deal_id(self):
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        assert "g8://deals/deal-111" in out
        assert "g8://deals/deal-222" in out

    def test_xss_escape_deal_name(self):
        malicious = [{"id": "x", "name": "<script>alert('xss')</script>", "amount": 100}]
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=malicious
        )
        assert "<script>alert" not in out

    def test_xss_escape_description(self):
        malicious = [{
            "id": "x",
            "name": "A",
            "description": "<img src=x onerror=alert(1)>",
            "amount": 100,
        }]
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=malicious
        )
        assert "<img src=x" not in out

    def test_xss_escape_stage_name(self):
        malicious = [{
            "id": "x",
            "name": "A",
            "stage_name": "<svg onload=alert(1)>",
            "amount": 100,
        }]
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=malicious
        )
        assert "<svg onload=" not in out

    def test_xss_escape_currency(self):
        malicious = [{
            "id": "x",
            "name": "A",
            "amount": 100,
            "currency": "<script>USD</script>",
        }]
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=malicious
        )
        assert "<script>USD" not in out

    def test_xss_escape_deal_id_in_drill_down(self):
        malicious = [{
            "id": "<script>xss</script>",
            "name": "A",
            "amount": 100,
            "stage_id": "stage-lead",
        }]
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=malicious
        )
        assert "<script>xss</script>" not in out

    def test_xss_escape_pipeline_name(self):
        malicious_pipeline = {
            "id": "p",
            "name": "<script>alert('x')</script>",
            "stages": [],
        }
        out = ar.render_pipeline_deals_html(
            pipeline_id="p", pipeline=malicious_pipeline, deals=_SAMPLE_DEALS
        )
        assert "<script>alert" not in out

    def test_xss_escape_pipeline_id(self):
        out = ar.render_pipeline_deals_html(
            pipeline_id="<xss>", pipeline=None, deals=_SAMPLE_DEALS
        )
        assert "<xss>" not in out

    def test_no_script_tags(self):
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        assert "<script" not in out
        assert "</script" not in out

    def test_no_javascript(self):
        """Regression: no javascript: URLs or on* event handlers."""
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        assert "javascript:" not in out.lower()
        assert 'onclick="' not in out.lower()
        assert 'onload="' not in out.lower()
        assert 'onerror="' not in out.lower()

    def test_no_legacy_accent_hexes(self):
        """Regression: no pre-graph8 accent hexes."""
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        legacy = ["#6366f1", "#4f46e5", "#10b981", "#ec4899", "#dc2626", "#16a34a"]
        for hex_code in legacy:
            assert hex_code not in out

    def test_no_single_side_colored_accent_border(self):
        """Regression: no one-sided colored borders anywhere."""
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        assert "border-left:" not in out
        assert "border-top:" not in out
        assert "border-right:" not in out
        assert "border-bottom:" not in out

    def test_uses_graph8_font(self):
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        assert "Aeonik" in out

    def test_uses_graph8_primary(self):
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        assert ar._G8_PRIMARY in out

    def test_is_valid_html(self):
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        assert out.startswith("<!DOCTYPE html>")
        assert out.rstrip().endswith("</html>")

    def test_overflow_card_when_over_max(self):
        # Create more than MAX_RENDERED deals (120), all in one stage
        big_deals = [
            {
                "id": f"d-{i}",
                "name": f"Deal {i}",
                "amount": 100,
                "currency": "USD",
                "stage_id": "stage-lead",
            }
            for i in range(150)
        ]
        out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=big_deals
        )
        assert "more deal(s)" in out

    def test_pipeline_name_falls_back_when_missing(self):
        out = ar.render_pipeline_deals_html(
            pipeline_id="pipe-xyz", pipeline=None, deals=_SAMPLE_DEALS
        )
        assert "Pipeline #pipe-xyz" in out


# -------------------------------------------------------------------- #
# render_pipeline_deals_text_fallback                                 #
# -------------------------------------------------------------------- #

class TestTextFallback:
    def test_none_deals_returns_unavailable(self):
        out = ar.render_pipeline_deals_text_fallback(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=None
        )
        assert "not available" in out

    def test_empty_deals_returns_empty_message(self):
        out = ar.render_pipeline_deals_text_fallback(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=[]
        )
        assert "No deals" in out

    def test_renders_pipeline_name(self):
        out = ar.render_pipeline_deals_text_fallback(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        assert "New Business" in out

    def test_renders_stats_section(self):
        out = ar.render_pipeline_deals_text_fallback(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        assert "## Stats" in out
        assert "Deals in pipeline" in out

    def test_renders_stage_sections_in_order(self):
        out = ar.render_pipeline_deals_text_fallback(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        lead_pos = out.index("## Lead")
        disco_pos = out.index("## Discovery")
        prop_pos = out.index("## Proposal")
        nego_pos = out.index("## Negotiation")
        closed_pos = out.index("## Closed Won")
        assert lead_pos < disco_pos < prop_pos < nego_pos < closed_pos

    def test_renders_deal_names(self):
        out = ar.render_pipeline_deals_text_fallback(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        assert "Acme Enterprise License" in out
        assert "Gamma Pilot" in out

    def test_renders_orphans_section(self):
        out = ar.render_pipeline_deals_text_fallback(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        assert "Unstaged" in out
        assert "Epsilon Add-on" in out

    def test_renders_drill_up_section(self):
        out = ar.render_pipeline_deals_text_fallback(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        assert "Related surfaces" in out
        assert "g8://pipelines/overview" in out
        assert "g8://deals/pipeline" in out

    def test_drill_up_does_NOT_list_self(self):
        out = ar.render_pipeline_deals_text_fallback(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        related_pos = out.index("Related surfaces")
        related_block = out[related_pos:]
        self_uri = "g8://pipelines/" + _PIPELINE_ID + "/deals"
        assert self_uri not in related_block

    def test_renders_drill_down_for_valid_deal_id(self):
        out = ar.render_pipeline_deals_text_fallback(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        assert "g8://deals/deal-111" in out

    def test_trailing_newline(self):
        out = ar.render_pipeline_deals_text_fallback(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        assert out.endswith("\n")

    def test_anonymous_deal_uses_fallback(self):
        out = ar.render_pipeline_deals_text_fallback(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        assert "(unnamed deal)" in out

    def test_pagination_override_in_title(self):
        out = ar.render_pipeline_deals_text_fallback(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS, total=99
        )
        assert "of 99 total" in out

    def test_pagination_lower_total_clamped(self):
        out = ar.render_pipeline_deals_text_fallback(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS, total=1
        )
        assert "of 1 total" not in out


# -------------------------------------------------------------------- #
# Smoke tests                                                         #
# -------------------------------------------------------------------- #

class TestSmoke:
    def test_html_and_text_both_render(self):
        html_out = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        text_out = ar.render_pipeline_deals_text_fallback(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        assert html_out
        assert text_out

    def test_render_is_idempotent(self):
        first = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        second = ar.render_pipeline_deals_html(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        assert first == second

    def test_text_render_is_idempotent(self):
        first = ar.render_pipeline_deals_text_fallback(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        second = ar.render_pipeline_deals_text_fallback(
            pipeline_id=_PIPELINE_ID, pipeline=_PIPELINE, deals=_SAMPLE_DEALS
        )
        assert first == second

    def test_empty_payload_html(self):
        out = ar.render_pipeline_deals_html(
            pipeline_id="p-empty", pipeline=None, deals=[]
        )
        assert out
        assert "No deals" in out

    def test_empty_payload_text(self):
        out = ar.render_pipeline_deals_text_fallback(
            pipeline_id="p-empty", pipeline=None, deals=[]
        )
        assert out
        assert "No deals" in out

    def test_minimal_pipeline_minimal_deal(self):
        # Pipeline with no stages + deal with only stage_name
        out = ar.render_pipeline_deals_html(
            pipeline_id="p", pipeline={"id": "p", "name": "P"}, deals=[
                {"id": "d1", "name": "D", "amount": 100, "stage_name": "X"}
            ]
        )
        # Should render without exception; deal goes to orphans
        assert "D" in out
        assert "Unstaged" in out
