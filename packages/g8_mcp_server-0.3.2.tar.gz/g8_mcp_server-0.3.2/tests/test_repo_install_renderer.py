"""Unit tests for HTML app surface #49 — repo install status renderer.

Surface #49 renders the per-repo install patch set at
`g8://repos/{repo_id}/install` (+ `.txt`). 3-segment template,
sibling to the existing `/scan`, `/kb`, `/campaigns`, `/overview`
per-repo surfaces. Disjoint from the 2-segment static
`g8://repos/dashboard` (surface #48).

Backend: `GET /repos/{repo_id}/install/status` → `PatchSetResponse`
`{id, repo_id, status, patches[{file_path, action, description,
diff?, content?}], applied_at, rolled_back_at, created_at}`.

Status enum values (from `repo_scanner.domain.value_objects`):
- PatchSetStatus: preview / applied / rolled_back
- PatchAction: create / modify / delete

Coverage:
- Helpers (clip, status_norm, action_norm, status_palette,
  action_palette, action_buckets, unique_action_count, stat_card)
- Empty-state (empty / unavailable / not_found modes)
- render_repo_install_html (None → unavailable, empty patches
  → empty, full patch set → rich HTML)
- render_repo_install_text_fallback (markdown mirror)
- Regression locks:
    - No single-side colored accent borders (AI-tell)
    - No legacy accent hexes (non-graph8 tokens)
    - Drill-up points at sibling + write-path endpoints, not self
    - Overflow capped at _MAX_REPO_INSTALL_PATCHES_RENDERED
    - XSS escape on every user-controlled field
    - Status + action palettes return expected graph8 tokens
"""

from __future__ import annotations

import pytest

from g8_mcp_server.app_renderer import (
    _G8_ACCENT_BG,
    _G8_BORDER,
    _G8_MUTED_BG,
    _G8_PRIMARY,
    _G8_TEXT,
    _G8_TEXT_MUTED,
    _G8_WARNING_BG,
    _G8_WARNING_FG,
    _MAX_REPO_INSTALL_ACTION_CHIPS,
    _MAX_REPO_INSTALL_DESCRIPTION_LEN,
    _MAX_REPO_INSTALL_FILE_PATH_LEN,
    _MAX_REPO_INSTALL_PATCHES_RENDERED,
    _REPO_INSTALL_ACTION_CREATE,
    _REPO_INSTALL_ACTION_DELETE,
    _REPO_INSTALL_ACTION_MODIFY,
    _REPO_INSTALL_STATUS_APPLIED,
    _REPO_INSTALL_STATUS_FAILED,
    _REPO_INSTALL_STATUS_PENDING,
    _render_repo_install_empty_state_html,
    _repo_install_action_buckets,
    _repo_install_action_norm,
    _repo_install_action_palette,
    _repo_install_clip,
    _repo_install_stat_card,
    _repo_install_status_norm,
    _repo_install_status_palette,
    _repo_install_unique_action_count,
    render_repo_install_html,
    render_repo_install_text_fallback,
)


# graph8 token regressions ---------------------------------------------------

_LEGACY_ACCENT_HEXES = (
    "#6366f1",   # pre-graph8 indigo primary
    "#4f46e5",   # pre-graph8 indigo dark
    "#10b981",   # pre-graph8 success green (old palette)
    "#ec4899",   # pre-graph8 pink
    "#dc2626",   # pre-graph8 destructive (old)
    "#16a34a",   # pre-graph8 success (old)
)


# ---------------------------------------------------------------------------
# TestClip
# ---------------------------------------------------------------------------


class TestClip:
    def test_empty_string_returns_empty(self):
        assert _repo_install_clip("", 50) == ""

    def test_whitespace_only_returns_empty(self):
        assert _repo_install_clip("   \t\n", 50) == ""

    def test_none_returns_empty(self):
        assert _repo_install_clip(None, 50) == ""

    def test_non_string_returns_empty(self):
        assert _repo_install_clip(123, 50) == ""
        assert _repo_install_clip(["x"], 50) == ""
        assert _repo_install_clip({"a": 1}, 50) == ""

    def test_short_string_passes_through_escaped(self):
        assert _repo_install_clip("hello", 50) == "hello"

    def test_clips_long_strings_with_ellipsis(self):
        s = "a" * 120
        out = _repo_install_clip(s, 20)
        assert out.endswith("…")
        assert len(out) == 20

    def test_escapes_html_characters(self):
        out = _repo_install_clip("<script>alert(1)</script>", 100)
        assert "<" not in out
        assert "&lt;script" in out


# ---------------------------------------------------------------------------
# TestStatusNorm
# ---------------------------------------------------------------------------


class TestStatusNorm:
    def test_lowercases_and_strips(self):
        assert _repo_install_status_norm("  APPLIED  ") == "applied"

    def test_empty_string(self):
        assert _repo_install_status_norm("") == ""

    def test_none(self):
        assert _repo_install_status_norm(None) == ""

    def test_non_string(self):
        assert _repo_install_status_norm(123) == ""
        assert _repo_install_status_norm({"x": 1}) == ""

    def test_already_lower(self):
        assert _repo_install_status_norm("preview") == "preview"


# ---------------------------------------------------------------------------
# TestActionNorm
# ---------------------------------------------------------------------------


class TestActionNorm:
    def test_lowercases_and_strips(self):
        assert _repo_install_action_norm("  CREATE  ") == "create"

    def test_empty_returns_unknown(self):
        assert _repo_install_action_norm("") == "unknown"

    def test_whitespace_returns_unknown(self):
        assert _repo_install_action_norm("   ") == "unknown"

    def test_none_returns_unknown(self):
        assert _repo_install_action_norm(None) == "unknown"

    def test_non_string_returns_unknown(self):
        assert _repo_install_action_norm(42) == "unknown"


# ---------------------------------------------------------------------------
# TestStatusPalette
# ---------------------------------------------------------------------------


class TestStatusPalette:
    def test_applied_is_green(self):
        bg, fg, label = _repo_install_status_palette("applied")
        assert bg == "#d1fae5"
        assert fg == "#059669"
        assert label == "APPLIED"

    def test_preview_is_warning_yellow(self):
        bg, fg, label = _repo_install_status_palette("preview")
        assert bg == _G8_WARNING_BG
        assert fg == _G8_WARNING_FG
        assert label == "PREVIEW"

    def test_rolled_back_is_red(self):
        bg, fg, label = _repo_install_status_palette("rolled_back")
        assert bg == "#fee2e2"
        assert fg == "#ca3214"
        assert label == "ROLLED_BACK"

    def test_unknown_is_muted(self):
        bg, fg, label = _repo_install_status_palette("weird_state")
        assert bg == _G8_MUTED_BG
        assert fg == _G8_TEXT_MUTED
        assert label == "WEIRD_STATE"

    def test_empty_is_unknown_label(self):
        bg, fg, label = _repo_install_status_palette("")
        assert bg == _G8_MUTED_BG
        assert fg == _G8_TEXT_MUTED
        assert label == "UNKNOWN"

    def test_non_string_treated_as_empty(self):
        bg, fg, label = _repo_install_status_palette(None)  # type: ignore[arg-type]
        assert bg == _G8_MUTED_BG
        assert fg == _G8_TEXT_MUTED
        assert label == "UNKNOWN"


# ---------------------------------------------------------------------------
# TestActionPalette
# ---------------------------------------------------------------------------


class TestActionPalette:
    def test_create_is_primary_accent(self):
        bg, fg, label = _repo_install_action_palette("create")
        assert bg == _G8_ACCENT_BG
        assert fg == _G8_PRIMARY
        assert label == "CREATE"

    def test_modify_is_primary_accent(self):
        bg, fg, label = _repo_install_action_palette("modify")
        assert bg == _G8_ACCENT_BG
        assert fg == _G8_PRIMARY
        assert label == "MODIFY"

    def test_delete_is_destructive_red(self):
        bg, fg, label = _repo_install_action_palette("delete")
        assert bg == "#fee2e2"
        assert fg == "#ca3214"
        assert label == "DELETE"

    def test_unknown_is_muted(self):
        bg, fg, label = _repo_install_action_palette("weird")
        assert bg == _G8_MUTED_BG
        assert fg == _G8_TEXT_MUTED
        assert label == "WEIRD"

    def test_empty_is_unknown_label(self):
        bg, fg, label = _repo_install_action_palette("")
        assert bg == _G8_MUTED_BG
        assert fg == _G8_TEXT_MUTED
        assert label == "UNKNOWN"

    def test_add_alias_is_create(self):
        # add → create palette (tolerance alias)
        bg, fg, _ = _repo_install_action_palette("add")
        assert bg == _G8_ACCENT_BG
        assert fg == _G8_PRIMARY

    def test_remove_alias_is_delete(self):
        bg, fg, _ = _repo_install_action_palette("remove")
        assert bg == "#fee2e2"
        assert fg == "#ca3214"


# ---------------------------------------------------------------------------
# TestActionBuckets
# ---------------------------------------------------------------------------


class TestActionBuckets:
    def test_buckets_by_action(self):
        patches = [
            {"action": "create"},
            {"action": "create"},
            {"action": "modify"},
            {"action": "delete"},
            {"action": "delete"},
            {"action": "delete"},
        ]
        out = _repo_install_action_buckets(patches)
        assert out == [("delete", 3), ("create", 2), ("modify", 1)]

    def test_desc_count_sort(self):
        patches = [
            {"action": "create"},
            {"action": "modify"},
            {"action": "modify"},
        ]
        out = _repo_install_action_buckets(patches)
        # modify comes first (count 2 > 1)
        assert out[0][0] == "modify"
        assert out[0][1] == 2

    def test_alpha_tiebreak(self):
        # Both counts equal — alpha order wins
        patches = [
            {"action": "zed"},
            {"action": "alpha"},
            {"action": "mid"},
        ]
        out = _repo_install_action_buckets(patches)
        assert out == [("alpha", 1), ("mid", 1), ("zed", 1)]

    def test_missing_action_buckets_to_unknown(self):
        patches = [
            {"action": "create"},
            {},
            {"action": ""},
            {"action": None},
        ]
        out = _repo_install_action_buckets(patches)
        # 3 unknowns (missing / empty / None all normalize to 'unknown')
        by_name = dict(out)
        assert by_name["unknown"] == 3
        assert by_name["create"] == 1

    def test_non_dict_filtered_out(self):
        patches = [
            {"action": "create"},
            "string",
            None,
            123,
            {"action": "delete"},
        ]
        out = _repo_install_action_buckets(patches)
        by_name = dict(out)
        assert by_name == {"create": 1, "delete": 1}

    def test_empty_list_returns_empty(self):
        assert _repo_install_action_buckets([]) == []


# ---------------------------------------------------------------------------
# TestUniqueActionCount
# ---------------------------------------------------------------------------


class TestUniqueActionCount:
    def test_counts_distinct(self):
        patches = [
            {"action": "create"},
            {"action": "create"},
            {"action": "modify"},
        ]
        assert _repo_install_unique_action_count(patches) == 2

    def test_empty_is_zero(self):
        assert _repo_install_unique_action_count([]) == 0

    def test_unknowns_bucket_together(self):
        patches = [{"action": ""}, {}, {"action": None}]
        # All three collapse into a single 'unknown' bucket
        assert _repo_install_unique_action_count(patches) == 1


# ---------------------------------------------------------------------------
# TestStatCard
# ---------------------------------------------------------------------------


class TestStatCard:
    def test_uniform_border(self):
        html_out = _repo_install_stat_card("Label", "42")
        # Must have `border:1px solid {border}` — not border-left/top/right/bottom
        assert f"border:1px solid {_G8_BORDER}" in html_out
        # regression lock: no single-side accent border
        for side in ("border-left:", "border-top:", "border-right:", "border-bottom:"):
            # Colored side accents (4+ px primary/accent) are the AI-tell; a 1px
            # side border is fine (not used here anyway).
            assert f"{side}4px" not in html_out

    def test_primary_accent_uses_g8_primary(self):
        html_out = _repo_install_stat_card("Label", "42", accent="primary")
        assert _G8_PRIMARY in html_out

    def test_positive_accent_uses_green(self):
        html_out = _repo_install_stat_card("Label", "42", accent="positive")
        assert "#059669" in html_out

    def test_destructive_accent_uses_red(self):
        html_out = _repo_install_stat_card("Label", "42", accent="destructive")
        assert "#ca3214" in html_out

    def test_warning_accent_uses_yellow_fg(self):
        html_out = _repo_install_stat_card("Label", "42", accent="warning")
        assert _G8_WARNING_FG in html_out

    def test_default_accent_is_text(self):
        html_out = _repo_install_stat_card("Label", "42")
        assert _G8_TEXT in html_out

    def test_escapes_label_and_value(self):
        html_out = _repo_install_stat_card("<lbl>", "<val>")
        assert "<lbl>" not in html_out
        assert "&lt;lbl&gt;" in html_out
        assert "&lt;val&gt;" in html_out


# ---------------------------------------------------------------------------
# TestEmptyState
# ---------------------------------------------------------------------------


class TestEmptyState:
    def test_empty_mode(self):
        html_out = _render_repo_install_empty_state_html("abc-123", mode="empty")
        assert "<!DOCTYPE html>" in html_out
        assert "No install patch set yet" in html_out
        # Empty mode uses primary accent
        assert _G8_PRIMARY in html_out

    def test_unavailable_mode(self):
        html_out = _render_repo_install_empty_state_html("abc-123", mode="unavailable")
        assert "Install status not available" in html_out
        assert _G8_TEXT_MUTED in html_out

    def test_not_found_mode_echoes_repo_id(self):
        html_out = _render_repo_install_empty_state_html("xyz-999", mode="not_found")
        assert "Repo not found" in html_out
        # Escaped repo id appears
        assert "xyz-999" in html_out

    def test_not_found_escapes_repo_id(self):
        html_out = _render_repo_install_empty_state_html(
            "<script>alert(1)</script>", mode="not_found"
        )
        assert "<script>" not in html_out
        assert "&lt;script&gt;" in html_out

    def test_empty_mode_mentions_install_endpoint(self):
        html_out = _render_repo_install_empty_state_html("abc", mode="empty")
        assert "POST /repos/{repo_id}/install" in html_out


# ---------------------------------------------------------------------------
# TestRenderHtml
# ---------------------------------------------------------------------------


def _sample_patch(
    *,
    file_path: str = "gtm/config.json",
    action: str = "create",
    description: str = "Create GTM config file",
) -> dict:
    return {
        "file_path": file_path,
        "action": action,
        "description": description,
    }


def _sample_patch_set(
    *,
    status: str = "preview",
    patches: list[dict] | None = None,
    created_at: str | None = "2026-04-20T10:00:00Z",
    applied_at: str | None = None,
    rolled_back_at: str | None = None,
) -> dict:
    if patches is None:
        patches = [_sample_patch()]
    return {
        "id": "patch-set-uuid",
        "repo_id": "repo-uuid",
        "status": status,
        "patches": patches,
        "created_at": created_at,
        "applied_at": applied_at,
        "rolled_back_at": rolled_back_at,
    }


class TestRenderHtml:
    def test_none_patch_set_renders_unavailable(self):
        html_out = render_repo_install_html(patch_set=None, repo_id="abc")
        assert "Install status not available" in html_out

    def test_non_dict_patch_set_renders_unavailable(self):
        html_out = render_repo_install_html(patch_set="not-a-dict", repo_id="abc")  # type: ignore[arg-type]
        assert "Install status not available" in html_out

    def test_missing_patches_key_renders_empty(self):
        html_out = render_repo_install_html(patch_set={"status": "preview"}, repo_id="abc")
        assert "No install patch set yet" in html_out

    def test_empty_patches_renders_empty_state(self):
        html_out = render_repo_install_html(
            patch_set={"status": "preview", "patches": []}, repo_id="abc"
        )
        assert "No install patch set yet" in html_out

    def test_all_non_dict_patches_renders_empty(self):
        html_out = render_repo_install_html(
            patch_set={"status": "preview", "patches": [None, "x", 42]}, repo_id="abc"
        )
        assert "No install patch set yet" in html_out

    def test_full_render_has_doctype(self):
        html_out = render_repo_install_html(patch_set=_sample_patch_set(), repo_id="r1")
        assert "<!DOCTYPE html>" in html_out
        assert "<title>Repo install" in html_out

    def test_full_render_shows_total_patch_count(self):
        patches = [_sample_patch() for _ in range(7)]
        html_out = render_repo_install_html(
            patch_set=_sample_patch_set(patches=patches), repo_id="r1"
        )
        assert "Patches (7 of 7)" in html_out

    def test_status_chip_shows_palette(self):
        html_out = render_repo_install_html(
            patch_set=_sample_patch_set(status="applied"), repo_id="r1"
        )
        # Applied = green
        assert "#d1fae5" in html_out
        assert "#059669" in html_out
        assert "APPLIED" in html_out

    def test_status_preview_uses_warning_yellow(self):
        html_out = render_repo_install_html(
            patch_set=_sample_patch_set(status="preview"), repo_id="r1"
        )
        assert _G8_WARNING_BG in html_out
        assert _G8_WARNING_FG in html_out

    def test_status_rolled_back_uses_red(self):
        html_out = render_repo_install_html(
            patch_set=_sample_patch_set(status="rolled_back"), repo_id="r1"
        )
        assert "#fee2e2" in html_out
        assert "#ca3214" in html_out

    def test_renders_action_distribution_pills(self):
        patches = [
            _sample_patch(action="create"),
            _sample_patch(action="create"),
            _sample_patch(action="modify"),
            _sample_patch(action="delete"),
        ]
        html_out = render_repo_install_html(
            patch_set=_sample_patch_set(patches=patches), repo_id="r1"
        )
        assert "Action mix" in html_out
        assert "3 distinct" in html_out
        assert "create" in html_out
        assert "modify" in html_out
        assert "delete" in html_out

    def test_action_chip_overflow_caps_at_max(self):
        # > _MAX action types should show "+ N more actions"
        actions = [f"action_{i}" for i in range(_MAX_REPO_INSTALL_ACTION_CHIPS + 3)]
        patches = [_sample_patch(action=a) for a in actions]
        html_out = render_repo_install_html(
            patch_set=_sample_patch_set(patches=patches), repo_id="r1"
        )
        assert "more actions" in html_out

    def test_timeline_shows_all_three_timestamps(self):
        html_out = render_repo_install_html(
            patch_set=_sample_patch_set(
                status="rolled_back",
                created_at="2026-04-20T10:00:00Z",
                applied_at="2026-04-20T11:00:00Z",
                rolled_back_at="2026-04-20T12:00:00Z",
            ),
            repo_id="r1",
        )
        assert "Timeline" in html_out
        assert "created" in html_out
        assert "applied" in html_out
        assert "rolled_back" in html_out
        assert "2026-04-20T11:00:00Z" in html_out

    def test_timeline_omitted_when_no_timestamps(self):
        html_out = render_repo_install_html(
            patch_set=_sample_patch_set(
                created_at=None, applied_at=None, rolled_back_at=None
            ),
            repo_id="r1",
        )
        # Timeline heading should NOT appear when there are zero chips
        assert "<h2 style=\"font-size:15px;margin:0 0 10px 0;color:#0A0A0A;\">Timeline" not in html_out

    def test_patch_row_shows_file_path_and_action(self):
        html_out = render_repo_install_html(
            patch_set=_sample_patch_set(
                patches=[_sample_patch(file_path="src/app.py", action="modify", description="Patch the app")]
            ),
            repo_id="r1",
        )
        assert "src/app.py" in html_out
        assert "MODIFY" in html_out
        assert "Patch the app" in html_out

    def test_patch_row_tolerates_missing_file_path(self):
        html_out = render_repo_install_html(
            patch_set=_sample_patch_set(patches=[{"action": "create"}]),
            repo_id="r1",
        )
        assert "(unknown file)" in html_out

    def test_overflow_caps_at_max_rendered(self):
        patches = [_sample_patch() for _ in range(_MAX_REPO_INSTALL_PATCHES_RENDERED + 5)]
        html_out = render_repo_install_html(
            patch_set=_sample_patch_set(patches=patches), repo_id="r1"
        )
        assert "+ 5 more patches omitted" in html_out

    def test_escapes_file_path(self):
        html_out = render_repo_install_html(
            patch_set=_sample_patch_set(
                patches=[_sample_patch(file_path="<script>alert(1)</script>")]
            ),
            repo_id="r1",
        )
        assert "<script>" not in html_out
        assert "&lt;script&gt;" in html_out

    def test_escapes_description(self):
        html_out = render_repo_install_html(
            patch_set=_sample_patch_set(
                patches=[_sample_patch(description="<img src=x onerror=1>")]
            ),
            repo_id="r1",
        )
        assert "<img src=x" not in html_out
        assert "&lt;img" in html_out

    def test_escapes_repo_id(self):
        html_out = render_repo_install_html(
            patch_set=_sample_patch_set(),
            repo_id="<script>evil</script>",
        )
        assert "<script>evil</script>" not in html_out
        assert "&lt;script&gt;" in html_out

    def test_escapes_status_label(self):
        html_out = render_repo_install_html(
            patch_set=_sample_patch_set(status="<img onerror=1>"),
            repo_id="r1",
        )
        # Label is uppercased by the palette helper; escaping happens after
        assert "<img onerror=1>" not in html_out
        assert "<IMG ONERROR=1>" not in html_out
        assert "&lt;IMG" in html_out

    def test_drill_up_points_at_sibling_surfaces(self):
        html_out = render_repo_install_html(
            patch_set=_sample_patch_set(), repo_id="abc-123"
        )
        assert "g8://repos/abc-123/overview" in html_out
        assert "g8://repos/abc-123/scan" in html_out
        assert "g8://repos/abc-123/kb" in html_out
        assert "g8://repos/abc-123/campaigns" in html_out
        assert "g8://repos/dashboard" in html_out

    def test_drill_up_points_at_write_endpoints(self):
        html_out = render_repo_install_html(
            patch_set=_sample_patch_set(), repo_id="r1"
        )
        assert "POST /repos/{repo_id}/install" in html_out
        assert "POST /repos/{repo_id}/install/apply" in html_out
        assert "POST /repos/{repo_id}/rollback" in html_out

    def test_drill_up_does_NOT_list_self(self):
        # Regression lock — the "Manage install" block must not list
        # the current surface URI as a drill-down target.
        html_out = render_repo_install_html(
            patch_set=_sample_patch_set(), repo_id="r1"
        )
        # The drill-up block should not mention g8://repos/{repo_id}/install
        # as a separate pointer (that's the surface we're already on).
        # Only the breadcrumb header mentions install — the manage block should
        # point elsewhere.
        manage_start = html_out.find("Manage install")
        assert manage_start >= 0
        manage_block = html_out[manage_start:]
        # No self-reference inside the manage block:
        assert "g8://repos/r1/install</code>" not in manage_block
        assert "g8://repos/{repo_id}/install.txt" not in manage_block

    def test_no_single_side_accent_borders(self):
        # Regression lock: the "AI-tell" is a 4+px colored border-left
        # (or border-top/right/bottom) on cards. graph8 uses uniform
        # 1px shadcn-style borders.
        html_out = render_repo_install_html(
            patch_set=_sample_patch_set(), repo_id="r1"
        )
        for side in ("border-left:", "border-top:", "border-right:", "border-bottom:"):
            for width in ("3px", "4px", "5px", "6px"):
                assert f"{side}{width}" not in html_out

    def test_no_legacy_accent_hexes(self):
        # Regression lock: no pre-graph8 indigo/pink/teal palette tokens.
        html_out = render_repo_install_html(
            patch_set=_sample_patch_set(), repo_id="r1"
        )
        for legacy in _LEGACY_ACCENT_HEXES:
            assert legacy not in html_out.lower()

    def test_non_dict_patches_filtered(self):
        html_out = render_repo_install_html(
            patch_set={
                "status": "preview",
                "patches": [_sample_patch(), "not-a-dict", None, 42, _sample_patch()],
            },
            repo_id="r1",
        )
        # Only the 2 valid dicts count
        assert "Patches (2 of 2)" in html_out

    def test_file_path_long_is_clipped(self):
        long_path = "very/long/nested/path/" + ("x" * 200) + "/file.py"
        html_out = render_repo_install_html(
            patch_set=_sample_patch_set(
                patches=[_sample_patch(file_path=long_path)]
            ),
            repo_id="r1",
        )
        # Clipped — length capped and ellipsis present
        assert "…" in html_out

    def test_stat_cards_show_all_four(self):
        html_out = render_repo_install_html(
            patch_set=_sample_patch_set(
                patches=[_sample_patch(), _sample_patch(action="delete")]
            ),
            repo_id="r1",
        )
        # The four stat labels
        assert "Patches" in html_out
        assert "Status" in html_out
        assert "Actions" in html_out
        assert "Created" in html_out

    def test_stat_card_created_em_dash_when_missing(self):
        html_out = render_repo_install_html(
            patch_set=_sample_patch_set(created_at=None),
            repo_id="r1",
        )
        # "—" rendered for missing timestamp in the Created stat card
        assert "—" in html_out


# ---------------------------------------------------------------------------
# TestTextFallback
# ---------------------------------------------------------------------------


class TestTextFallback:
    def test_none_patch_set(self):
        out = render_repo_install_text_fallback(patch_set=None, repo_id="r1")
        assert "status not available" in out

    def test_non_dict_patch_set(self):
        out = render_repo_install_text_fallback(patch_set="x", repo_id="r1")  # type: ignore[arg-type]
        assert "status not available" in out

    def test_missing_patches_renders_empty(self):
        out = render_repo_install_text_fallback(
            patch_set={"status": "preview"}, repo_id="r1"
        )
        assert "no patch set yet" in out

    def test_empty_patches_renders_empty(self):
        out = render_repo_install_text_fallback(
            patch_set={"status": "preview", "patches": []}, repo_id="r1"
        )
        assert "no patch set yet" in out

    def test_full_patch_set_shows_stats(self):
        out = render_repo_install_text_fallback(
            patch_set=_sample_patch_set(
                status="applied",
                patches=[_sample_patch(), _sample_patch(action="delete")],
            ),
            repo_id="r1",
        )
        assert "# Repo install" in out
        assert "status: applied" in out
        assert "- Patches: 2" in out
        assert "- Actions: 2" in out

    def test_action_mix_section(self):
        out = render_repo_install_text_fallback(
            patch_set=_sample_patch_set(
                patches=[
                    _sample_patch(action="create"),
                    _sample_patch(action="create"),
                    _sample_patch(action="delete"),
                ]
            ),
            repo_id="r1",
        )
        assert "## Action mix" in out
        assert "- create: 2" in out
        assert "- delete: 1" in out

    def test_patches_section_lists_each_patch(self):
        out = render_repo_install_text_fallback(
            patch_set=_sample_patch_set(
                patches=[_sample_patch(file_path="a.py", action="create")]
            ),
            repo_id="r1",
        )
        assert "## Patches" in out
        assert "[create] a.py" in out

    def test_description_sub_bullet(self):
        out = render_repo_install_text_fallback(
            patch_set=_sample_patch_set(
                patches=[
                    _sample_patch(
                        file_path="a.py",
                        action="modify",
                        description="Patch something",
                    )
                ]
            ),
            repo_id="r1",
        )
        assert "Patch something" in out

    def test_timeline_fields_rendered(self):
        out = render_repo_install_text_fallback(
            patch_set=_sample_patch_set(
                status="rolled_back",
                applied_at="2026-04-20T11:00:00Z",
                rolled_back_at="2026-04-20T12:00:00Z",
            ),
            repo_id="r1",
        )
        assert "- Applied: 2026-04-20T11:00:00Z" in out
        assert "- Rolled back: 2026-04-20T12:00:00Z" in out

    def test_overflow_note_at_cap(self):
        patches = [
            _sample_patch() for _ in range(_MAX_REPO_INSTALL_PATCHES_RENDERED + 3)
        ]
        out = render_repo_install_text_fallback(
            patch_set=_sample_patch_set(patches=patches), repo_id="r1"
        )
        assert "+ 3 more patches omitted" in out

    def test_manage_block_does_not_list_self(self):
        # Regression lock — the "Manage install" section must not list
        # g8://repos/{repo_id}/install as a drill-down target.
        out = render_repo_install_text_fallback(
            patch_set=_sample_patch_set(), repo_id="r1"
        )
        assert "## Manage install" in out
        manage_idx = out.find("## Manage install")
        manage_block = out[manage_idx:]
        # The manage block doesn't point back at the surface itself
        assert "g8://repos/r1/install\n" not in manage_block
        assert "g8://repos/r1/install.txt" not in manage_block

    def test_manage_block_points_at_siblings(self):
        out = render_repo_install_text_fallback(
            patch_set=_sample_patch_set(), repo_id="r1"
        )
        assert "g8://repos/r1/overview" in out
        assert "g8://repos/r1/scan" in out
        assert "g8://repos/r1/kb" in out
        assert "g8://repos/r1/campaigns" in out
        assert "g8://repos/dashboard" in out

    def test_manage_block_lists_write_endpoints(self):
        out = render_repo_install_text_fallback(
            patch_set=_sample_patch_set(), repo_id="r1"
        )
        assert "POST /repos/{repo_id}/install" in out
        assert "POST /repos/{repo_id}/install/apply" in out
        assert "POST /repos/{repo_id}/rollback" in out

    def test_long_file_path_clipped(self):
        long_path = "very/long/path/" + ("x" * 200) + "/file.py"
        out = render_repo_install_text_fallback(
            patch_set=_sample_patch_set(
                patches=[_sample_patch(file_path=long_path)]
            ),
            repo_id="r1",
        )
        assert "…" in out


# ---------------------------------------------------------------------------
# TestSmoke — structural integrity across realistic payloads
# ---------------------------------------------------------------------------


class TestSmoke:
    def test_realistic_patch_set_renders(self):
        patch_set = {
            "id": "12345678-1234-5678-1234-567812345678",
            "repo_id": "abcdef12-1234-5678-1234-567812345678",
            "status": "preview",
            "patches": [
                {
                    "file_path": "gtm/config.json",
                    "action": "create",
                    "description": "Create GTM configuration file",
                },
                {
                    "file_path": "src/app/layout.tsx",
                    "action": "modify",
                    "description": "Inject G8Analytics component into root layout",
                },
                {
                    "file_path": "package.json",
                    "action": "modify",
                    "description": "Add @graph8/nextjs dependency",
                },
            ],
            "created_at": "2026-04-20T10:00:00Z",
            "applied_at": None,
            "rolled_back_at": None,
        }
        html_out = render_repo_install_html(
            patch_set=patch_set, repo_id=patch_set["repo_id"]
        )
        text_out = render_repo_install_text_fallback(
            patch_set=patch_set, repo_id=patch_set["repo_id"]
        )
        assert "<!DOCTYPE html>" in html_out
        assert "gtm/config.json" in html_out
        assert "PREVIEW" in html_out
        assert "# Repo install" in text_out
        assert "status: preview" in text_out
        # URL drill-downs are consistent across HTML + text
        assert f"g8://repos/{patch_set['repo_id']}/overview" in html_out
        assert f"g8://repos/{patch_set['repo_id']}/overview" in text_out

    def test_applied_patch_set_renders_positively(self):
        patch_set = _sample_patch_set(
            status="applied",
            applied_at="2026-04-20T11:00:00Z",
        )
        html_out = render_repo_install_html(patch_set=patch_set, repo_id="r1")
        assert "APPLIED" in html_out
        assert "#059669" in html_out  # green FG
        assert "2026-04-20T11:00:00Z" in html_out

    def test_rolled_back_patch_set_renders_destructively(self):
        patch_set = _sample_patch_set(
            status="rolled_back",
            applied_at="2026-04-20T11:00:00Z",
            rolled_back_at="2026-04-20T12:00:00Z",
        )
        html_out = render_repo_install_html(patch_set=patch_set, repo_id="r1")
        assert "ROLLED_BACK" in html_out
        assert "#ca3214" in html_out  # destructive red FG

    def test_empty_patches_triggers_empty_state(self):
        html_out = render_repo_install_html(
            patch_set={"status": "preview", "patches": []}, repo_id="r1"
        )
        assert "No install patch set yet" in html_out

    def test_status_enum_values_cover_all_cases(self):
        # All three declared PatchSetStatus values must return a distinct palette
        bg_applied, _, _ = _repo_install_status_palette("applied")
        bg_preview, _, _ = _repo_install_status_palette("preview")
        bg_rolled_back, _, _ = _repo_install_status_palette("rolled_back")
        # Green, yellow, red — all distinct
        assert bg_applied == "#d1fae5"
        assert bg_preview == _G8_WARNING_BG
        assert bg_rolled_back == "#fee2e2"
        assert len({bg_applied, bg_preview, bg_rolled_back}) == 3

    def test_status_constants_are_lowercase(self):
        # The declared enum values from value_objects.py are lowercase
        assert "applied" in _REPO_INSTALL_STATUS_APPLIED
        assert "preview" in _REPO_INSTALL_STATUS_PENDING
        assert "rolled_back" in _REPO_INSTALL_STATUS_FAILED

    def test_action_constants_are_lowercase(self):
        assert "create" in _REPO_INSTALL_ACTION_CREATE
        assert "modify" in _REPO_INSTALL_ACTION_MODIFY
        assert "delete" in _REPO_INSTALL_ACTION_DELETE
