"""Unit tests for surface #41 — per-contact deal roster.

Covers helpers and both renderers (HTML + text fallback). Design parity:
graph8 tokens, no single-side accent borders, no legacy accent hexes.
"""

from g8_mcp_server.app_renderer import (
    _contact_deals_bucket_roles,
    _contact_deals_bucket_stages,
    _contact_deals_clip,
    _contact_deals_format_value,
    _contact_deals_is_open,
    _contact_deals_open_count,
    _contact_deals_pipeline_value,
    _contact_deals_role_label,
    _contact_deals_stage_key,
    _contact_deals_stage_label,
    _contact_deals_stage_palette,
    _contact_deals_stat_card,
    _contact_deals_won_count,
    _render_contact_deals_empty_state_html,
    render_contact_deals_html,
    render_contact_deals_text_fallback,
)


def _deal(
    *,
    deal_id: str = "d1",
    name: str = "Test Deal",
    stage: str = "open",
    value: float | int | None = 10000,
    currency: str | None = "USD",
    role: str | None = "buyer",
    close_date: str | None = "2026-06-30",
    created_at: str | None = "2026-04-01T10:00:00Z",
) -> dict:
    """Build a valid deal dict for testing."""
    return {
        "deal_id": deal_id,
        "name": name,
        "stage": stage,
        "value": value,
        "currency": currency,
        "role": role,
        "close_date": close_date,
        "created_at": created_at,
    }


class TestClip:
    def test_non_string(self):
        assert _contact_deals_clip(None, 10) == ""
        assert _contact_deals_clip(42, 10) == ""
        assert _contact_deals_clip(["a"], 10) == ""

    def test_whitespace(self):
        assert _contact_deals_clip("   ", 10) == ""

    def test_short_pass_through_escaped(self):
        assert _contact_deals_clip("hi & bye", 20) == "hi &amp; bye"

    def test_long_clips(self):
        out = _contact_deals_clip("x" * 100, 10)
        assert out.endswith("…")
        assert len(out) <= 11

    def test_html_escape(self):
        assert _contact_deals_clip("<script>", 20) == "&lt;script&gt;"


class TestStageKey:
    def test_lowercases(self):
        assert _contact_deals_stage_key("Closed Won") == "closed_won"

    def test_hyphen_to_underscore(self):
        assert _contact_deals_stage_key("closed-won") == "closed_won"

    def test_strips(self):
        assert _contact_deals_stage_key("  Won  ") == "won"

    def test_empty_unknown(self):
        assert _contact_deals_stage_key("") == "unknown"
        assert _contact_deals_stage_key(None) == "unknown"
        assert _contact_deals_stage_key(42) == "unknown"


class TestStagePalette:
    def test_won_positive(self):
        bg, fg = _contact_deals_stage_palette("won")
        assert bg == "#d1fae5"
        assert fg == "#059669"

    def test_closed_won_positive(self):
        assert _contact_deals_stage_palette("closed_won") == _contact_deals_stage_palette("won")

    def test_lost_destructive(self):
        bg, fg = _contact_deals_stage_palette("lost")
        assert bg.startswith("rgba(202,50,20")
        assert fg == "#fffcfc"

    def test_closed_lost_shares_lost(self):
        assert _contact_deals_stage_palette("closed_lost") == _contact_deals_stage_palette("lost")

    def test_unknown_muted(self):
        bg, fg = _contact_deals_stage_palette("unknown")
        assert bg == "#ededed"
        assert fg == "#777777"

    def test_other_stages_primary_tint(self):
        bg, fg = _contact_deals_stage_palette("qualified")
        assert bg == "#f2eafe"
        assert fg == "#7d2df3"

    def test_open_stage_primary_tint(self):
        assert _contact_deals_stage_palette("open")[1] == "#7d2df3"


class TestStageLabel:
    def test_closed_won(self):
        assert _contact_deals_stage_label("closed_won") == "Closed Won"

    def test_unknown(self):
        assert _contact_deals_stage_label("unknown") == "Unknown"

    def test_single(self):
        assert _contact_deals_stage_label("open") == "Open"


class TestIsOpen:
    def test_open_stages(self):
        assert _contact_deals_is_open("open") is True
        assert _contact_deals_is_open("qualified") is True
        assert _contact_deals_is_open("proposal") is True

    def test_closed_stages(self):
        assert _contact_deals_is_open("won") is False
        assert _contact_deals_is_open("closed_won") is False
        assert _contact_deals_is_open("lost") is False
        assert _contact_deals_is_open("closed_lost") is False

    def test_unknown_not_open(self):
        assert _contact_deals_is_open("unknown") is False


class TestBucketStages:
    def test_groups_by_stage(self):
        deals = [
            _deal(stage="open"),
            _deal(stage="open"),
            _deal(stage="won"),
        ]
        buckets = dict(_contact_deals_bucket_stages(deals))
        assert buckets == {"open": 2, "won": 1}

    def test_sorted_by_count_desc_alpha_tiebreak(self):
        deals = [
            _deal(stage="won"),
            _deal(stage="open"),
            _deal(stage="qualified"),
        ]
        # All counts = 1, alpha tiebreak → open, qualified, won
        result = _contact_deals_bucket_stages(deals)
        assert [k for k, _ in result] == ["open", "qualified", "won"]

    def test_missing_stage_unknown(self):
        deals = [{"deal_id": "x", "stage": None}]
        result = _contact_deals_bucket_stages(deals)
        assert result == [("unknown", 1)]

    def test_skips_non_dicts(self):
        deals = [_deal(stage="open"), "not a dict", None]
        result = _contact_deals_bucket_stages(deals)
        assert result == [("open", 1)]


class TestBucketRoles:
    def test_groups(self):
        deals = [
            _deal(role="buyer"),
            _deal(role="buyer"),
            _deal(role="decision_maker"),
        ]
        buckets = dict(_contact_deals_bucket_roles(deals))
        assert buckets == {"buyer": 2, "decision_maker": 1}

    def test_missing_role_unknown(self):
        deals = [_deal(role=None), _deal(role="")]
        result = _contact_deals_bucket_roles(deals)
        assert result == [("unknown", 2)]

    def test_hyphen_space_normalized(self):
        deals = [_deal(role="Decision Maker"), _deal(role="decision-maker")]
        buckets = dict(_contact_deals_bucket_roles(deals))
        assert buckets == {"decision_maker": 2}


class TestRoleLabel:
    def test_decision_maker(self):
        assert _contact_deals_role_label("decision_maker") == "Decision Maker"

    def test_unknown(self):
        assert _contact_deals_role_label("unknown") == "Unknown"


class TestWonCount:
    def test_won_and_closed_won(self):
        deals = [_deal(stage="won"), _deal(stage="closed_won"), _deal(stage="open")]
        assert _contact_deals_won_count(deals) == 2

    def test_empty(self):
        assert _contact_deals_won_count([]) == 0

    def test_skips_non_dicts(self):
        assert _contact_deals_won_count(["x", None]) == 0


class TestOpenCount:
    def test_open_stages(self):
        deals = [
            _deal(stage="open"),
            _deal(stage="qualified"),
            _deal(stage="won"),
            _deal(stage="lost"),
            _deal(stage="unknown"),
            _deal(stage=None),
        ]
        assert _contact_deals_open_count(deals) == 2

    def test_empty(self):
        assert _contact_deals_open_count([]) == 0


class TestPipelineValue:
    def test_sums_open_only(self):
        deals = [
            _deal(stage="open", value=10000, currency="USD"),
            _deal(stage="qualified", value=5000, currency="USD"),
            _deal(stage="won", value=50000, currency="USD"),  # excluded
            _deal(stage="lost", value=99999, currency="USD"),  # excluded
        ]
        total, cur = _contact_deals_pipeline_value(deals)
        assert total == 15000.0
        assert cur == "USD"

    def test_rejects_bool_value(self):
        deals = [_deal(stage="open", value=True)]  # True not counted
        total, _ = _contact_deals_pipeline_value(deals)
        assert total == 0.0

    def test_skips_non_numeric(self):
        deals = [_deal(stage="open", value="not a number")]
        total, _ = _contact_deals_pipeline_value(deals)
        assert total == 0.0

    def test_empty(self):
        assert _contact_deals_pipeline_value([]) == (0.0, None)

    def test_dominant_currency(self):
        deals = [
            _deal(stage="open", value=100, currency="USD"),
            _deal(stage="open", value=100, currency="USD"),
            _deal(stage="open", value=100, currency="EUR"),
        ]
        _, cur = _contact_deals_pipeline_value(deals)
        assert cur == "USD"


class TestFormatValue:
    def test_int_with_currency(self):
        assert _contact_deals_format_value(10000, "USD") == "$10,000 USD"

    def test_float_two_decimals(self):
        assert _contact_deals_format_value(1234.56, "USD") == "$1,234.56 USD"

    def test_whole_float_no_decimals(self):
        assert _contact_deals_format_value(1000.0, "USD") == "$1,000 USD"

    def test_no_currency(self):
        assert _contact_deals_format_value(500, None) == "$500"

    def test_bool_rejected(self):
        assert _contact_deals_format_value(True, "USD") == ""
        assert _contact_deals_format_value(False, "USD") == ""

    def test_none_rejected(self):
        assert _contact_deals_format_value(None, "USD") == ""

    def test_non_numeric(self):
        assert _contact_deals_format_value("100", "USD") == ""


class TestStatCard:
    def test_four_accents(self):
        for accent in ("text", "primary", "positive", "destructive"):
            card = _contact_deals_stat_card("label", "value", accent=accent)
            assert "label" in card
            assert "value" in card

    def test_uniform_border_not_single_side(self):
        card = _contact_deals_stat_card("L", "V", accent="primary")
        assert "border:1px solid #dfdfdf" in card
        assert "border-left:3px" not in card
        assert "border-top:3px" not in card
        assert "border-right:3px" not in card
        assert "border-bottom:3px" not in card

    def test_html_escape(self):
        card = _contact_deals_stat_card("<b>", "<i>", accent="text")
        assert "&lt;b&gt;" in card
        assert "&lt;i&gt;" in card


class TestEmptyState:
    def test_unavailable(self):
        html_out = _render_contact_deals_empty_state_html("c1", mode="unavailable")
        assert "Contact deals not available" in html_out
        assert "c1" in html_out

    def test_empty(self):
        html_out = _render_contact_deals_empty_state_html("c1", mode="empty")
        assert "No deals linked" in html_out
        assert "POST /deals" in html_out

    def test_xss_in_contact_id_escaped(self):
        xss = "<script>alert(1)</script>"
        html_out = _render_contact_deals_empty_state_html(xss, mode="empty")
        assert "<script>" not in html_out
        assert "&lt;script&gt;" in html_out


class TestRenderHtml:
    def test_none_unavailable(self):
        html_out = render_contact_deals_html(deals=None, contact_id="c1")
        assert "Contact deals not available" in html_out

    def test_empty_empty_state(self):
        html_out = render_contact_deals_html(deals=[], contact_id="c1")
        assert "No deals linked" in html_out

    def test_single_deal_renders(self):
        deals = [_deal()]
        html_out = render_contact_deals_html(deals=deals, contact_id="c1")
        assert "Test Deal" in html_out
        assert "deal_id=d1" in html_out

    def test_stat_cards_rendered(self):
        deals = [_deal(stage="open"), _deal(stage="won")]
        html_out = render_contact_deals_html(deals=deals, contact_id="c1")
        assert "Total deals" in html_out
        assert "Open" in html_out
        assert "Won" in html_out
        assert "Pipeline value" in html_out

    def test_pipeline_value_formatted(self):
        deals = [_deal(stage="open", value=12345, currency="USD")]
        html_out = render_contact_deals_html(deals=deals, contact_id="c1")
        assert "$12,345 USD" in html_out

    def test_stage_mix_section(self):
        deals = [_deal(stage="open"), _deal(stage="won")]
        html_out = render_contact_deals_html(deals=deals, contact_id="c1")
        assert "Stage mix" in html_out
        assert "Open" in html_out
        assert "Won" in html_out

    def test_roles_section_rendered_when_identified(self):
        deals = [_deal(role="buyer"), _deal(role="decision_maker")]
        html_out = render_contact_deals_html(deals=deals, contact_id="c1")
        assert "Roles" in html_out
        assert "Buyer" in html_out
        assert "Decision Maker" in html_out

    def test_roles_section_skipped_when_all_unknown(self):
        deals = [_deal(role=None), _deal(role="")]
        html_out = render_contact_deals_html(deals=deals, contact_id="c1")
        # "Roles" section should NOT render if all roles are unknown
        assert "Roles</h2>" not in html_out

    def test_contact_label_from_first_last_name(self):
        deals = [_deal()]
        contact = {"first_name": "Jane", "last_name": "Doe"}
        html_out = render_contact_deals_html(deals=deals, contact_id="c1", contact=contact)
        assert "Jane Doe" in html_out

    def test_contact_label_from_email_fallback(self):
        deals = [_deal()]
        contact = {"email": "jane@example.com"}
        html_out = render_contact_deals_html(deals=deals, contact_id="c1", contact=contact)
        assert "jane@example.com" in html_out

    def test_contact_label_default(self):
        deals = [_deal()]
        html_out = render_contact_deals_html(deals=deals, contact_id="c1")
        assert "Contact — deals" in html_out

    def test_overflow_40(self):
        deals = [_deal(deal_id=f"d{i}") for i in range(45)]
        html_out = render_contact_deals_html(deals=deals, contact_id="c1")
        assert "+ 5 more deals" in html_out

    def test_total_chip_in_header(self):
        deals = [_deal() for _ in range(7)]
        html_out = render_contact_deals_html(deals=deals, contact_id="c1")
        assert "7 TOTAL" in html_out

    def test_drill_up_links(self):
        deals = [_deal()]
        html_out = render_contact_deals_html(deals=deals, contact_id="c1")
        assert "g8://contacts/c1</code>" in html_out
        assert "g8://contacts/c1/notes</code>" in html_out
        assert "g8://contacts/c1/tasks</code>" in html_out
        assert "g8://deals/pipelines</code>" in html_out
        assert "GET /deals</code>" in html_out

    def test_xss_in_contact_name_escaped(self):
        deals = [_deal()]
        contact = {"first_name": "<script>", "last_name": "x"}
        html_out = render_contact_deals_html(deals=deals, contact_id="c1", contact=contact)
        assert "<script>" not in html_out
        assert "&lt;script&gt;" in html_out

    def test_xss_in_contact_id_escaped(self):
        xss = "<script>alert(1)</script>"
        deals = [_deal()]
        html_out = render_contact_deals_html(deals=deals, contact_id=xss)
        # raw unescaped pattern must not appear in any form
        assert xss not in html_out
        # "&lt;script&gt;alert" subsequence must be present (escaped)
        assert "&lt;script&gt;" in html_out

    def test_xss_in_deal_name_escaped(self):
        deals = [_deal(name="<img src=x>")]
        html_out = render_contact_deals_html(deals=deals, contact_id="c1")
        assert "<img src=x>" not in html_out
        assert "&lt;img" in html_out

    def test_bool_value_excluded_from_pipeline(self):
        deals = [_deal(stage="open", value=True)]
        html_out = render_contact_deals_html(deals=deals, contact_id="c1")
        # Pipeline value should be "—" (no positive total)
        assert ">—<" in html_out

    def test_no_single_side_accent_borders(self):
        deals = [_deal()]
        html_out = render_contact_deals_html(deals=deals, contact_id="c1")
        assert "border-left:3px" not in html_out
        assert "border-top:3px" not in html_out
        assert "border-right:3px" not in html_out
        assert "border-bottom:3px" not in html_out

    def test_no_legacy_accent_hexes(self):
        deals = [_deal()]
        html_out = render_contact_deals_html(deals=deals, contact_id="c1")
        # These are from surfaces #1-#35; surface #41 must not contain any.
        for legacy in ("#6366f1", "#4f46e5", "#10b981", "#ec4899", "#dc2626", "#16a34a"):
            assert legacy not in html_out, (
                f"surface #41 should not contain legacy hex {legacy}"
            )

    def test_aeonik_font_present(self):
        deals = [_deal()]
        html_out = render_contact_deals_html(deals=deals, contact_id="c1")
        assert "Aeonik" in html_out

    def test_graph8_primary_present(self):
        deals = [_deal()]
        html_out = render_contact_deals_html(deals=deals, contact_id="c1")
        assert "#7d2df3" in html_out


class TestTextFallback:
    def test_none_unavailable(self):
        text = render_contact_deals_text_fallback(deals=None, contact_id="c1")
        assert "not available" in text

    def test_empty(self):
        text = render_contact_deals_text_fallback(deals=[], contact_id="c1")
        assert "no deals yet" in text

    def test_markdown_headers(self):
        deals = [_deal()]
        text = render_contact_deals_text_fallback(deals=deals, contact_id="c1")
        assert "# Contact" in text
        assert "## Stage mix" in text
        assert "## Deals" in text
        assert "## Drill into this contact" in text

    def test_stats_rendered(self):
        deals = [_deal(stage="open"), _deal(stage="won")]
        text = render_contact_deals_text_fallback(deals=deals, contact_id="c1")
        assert "- Total deals: 2" in text
        assert "- Open: 1" in text
        assert "- Won: 1" in text

    def test_deal_row_format(self):
        deals = [_deal(stage="open", name="My Deal", value=5000)]
        text = render_contact_deals_text_fallback(deals=deals, contact_id="c1")
        assert "[Open] My Deal" in text
        assert "deal_id=d1" in text
        assert "$5,000 USD" in text

    def test_bool_value_rejected(self):
        deals = [_deal(stage="open", value=True)]
        text = render_contact_deals_text_fallback(deals=deals, contact_id="c1")
        # no "$1 USD" for True
        assert "$1 USD" not in text

    def test_overflow_40(self):
        deals = [_deal(deal_id=f"d{i}") for i in range(45)]
        text = render_contact_deals_text_fallback(deals=deals, contact_id="c1")
        assert "+ 5 more deals" in text

    def test_drill_up_pointers(self):
        deals = [_deal()]
        text = render_contact_deals_text_fallback(deals=deals, contact_id="c1")
        assert "g8://contacts/c1" in text
        assert "g8://contacts/c1/notes" in text
        assert "g8://contacts/c1/tasks" in text

    def test_contact_name(self):
        deals = [_deal()]
        contact = {"first_name": "Jane", "last_name": "Doe"}
        text = render_contact_deals_text_fallback(deals=deals, contact_id="c1", contact=contact)
        assert "# Jane Doe — deals" in text


class TestSmoke:
    def test_mixed_payload(self):
        """Large mixed payload doesn't explode."""
        stages = ["open", "qualified", "proposal", "won", "lost", "closed_won"]
        roles = ["buyer", "decision_maker", "influencer", None]
        deals = [
            _deal(
                deal_id=f"d{i}",
                name=f"Deal {i}",
                stage=stages[i % len(stages)],
                value=1000 * (i + 1),
                currency="USD" if i % 2 == 0 else "EUR",
                role=roles[i % len(roles)],
            )
            for i in range(30)
        ]
        html_out = render_contact_deals_html(deals=deals, contact_id="c1")
        assert "30 TOTAL" in html_out
        text_out = render_contact_deals_text_fallback(deals=deals, contact_id="c1")
        assert "- Total deals: 30" in text_out
