"""Tests for deal detail HTML app surface (surface #24).

Surface #24 renders a per-deal drilldown: amount, stage, close date,
days in pipeline, pipeline funnel ladder, description, linked company +
owner. Distinct from surface #11 (deals pipeline — org-wide list
grouped by stage).

Coverage emphasises:
- Status derivation from stage metadata (open/won/lost/abandoned)
  - explicit stage_type wins
  - name heuristics ("won"/"lost"/"abandon") as fallback
  - neutral default when neither applies
- Stage-index lookup on the pipeline ladder
  - id match, name-lowercase fallback, None when absent
- Day arithmetic: days_since (created_at → now) and days_until (now →
  close_date) both handle ISO parse failures and timezone-naive input
- Empty-state triggers (None / non-dict / missing deal)
- Defensive handling of non-dict entries in pipeline_stages
- HTML escape of user-controlled fields (name, description, owner_id)
- Text fallback parity with markdown structure
"""

from datetime import datetime, timedelta, timezone

from g8_mcp_server.app_renderer import (
    _DEAL_DETAIL_STATUS_COLORS,
    _deal_detail_days_since,
    _deal_detail_days_until,
    _deal_detail_derive_status,
    _deal_detail_find_current_stage_index,
    _deal_detail_parse_iso,
    _deal_detail_status_palette,
    _render_deal_detail_pipeline_ladder,
    render_deal_detail_html,
    render_deal_detail_text_fallback,
)

_BANNED_HEXES = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}


class TestDealDetailStatusPaletteNoBannedHexes:
    """Lock test: _DEAL_DETAIL_STATUS_COLORS must not reintroduce banned Studio hexes."""

    def test_no_banned_hexes_in_status_palette(self):
        for status, pal in _DEAL_DETAIL_STATUS_COLORS.items():
            for field in ("bg", "fg", "border"):
                assert pal[field].lower() not in _BANNED_HEXES, (
                    f"Banned hex {pal[field]!r} found in _DEAL_DETAIL_STATUS_COLORS[{status!r}][{field!r}]"
                )


# ---------------------------------------------------------------------------
# Status derivation
# ---------------------------------------------------------------------------


class TestDealDetailDeriveStatus:
    def test_explicit_stage_type_open(self):
        assert _deal_detail_derive_status("Discovery", "open") == "open"

    def test_explicit_stage_type_won(self):
        # stage_type wins even if stage_name says something else
        assert _deal_detail_derive_status("Discovery", "won") == "won"

    def test_explicit_stage_type_lost(self):
        assert _deal_detail_derive_status("Anything", "lost") == "lost"

    def test_explicit_stage_type_case_insensitive(self):
        assert _deal_detail_derive_status("X", "WON") == "won"

    def test_explicit_stage_type_unknown_falls_through_to_name(self):
        # Unknown stage_type → falls back to name heuristics
        assert _deal_detail_derive_status("Closed Won", "weird") == "won"

    def test_name_heuristic_won(self):
        assert _deal_detail_derive_status("Closed Won") == "won"

    def test_name_heuristic_lost(self):
        assert _deal_detail_derive_status("Closed Lost") == "lost"

    def test_name_heuristic_abandoned(self):
        assert _deal_detail_derive_status("Abandoned") == "abandoned"

    def test_name_heuristic_contains_won(self):
        assert _deal_detail_derive_status("WON - Amazing Deal") == "won"

    def test_name_heuristic_neutral(self):
        assert _deal_detail_derive_status("Discovery") == "open"
        assert _deal_detail_derive_status("Proposal Sent") == "open"

    def test_none_stage_defaults_open(self):
        assert _deal_detail_derive_status(None) == "open"

    def test_empty_stage_defaults_open(self):
        assert _deal_detail_derive_status("") == "open"
        assert _deal_detail_derive_status("   ") == "open"


# ---------------------------------------------------------------------------
# Status palette
# ---------------------------------------------------------------------------


class TestDealDetailStatusPalette:
    def test_open(self):
        p = _deal_detail_status_palette("open")
        assert p["bg"] == "#f2eafe"
        assert p["fg"] == "#7d2df3"  # was banned #1d4ed8 → _G8_PRIMARY

    def test_won_is_green(self):
        p = _deal_detail_status_palette("won")
        assert p["fg"] == "#059669"  # was banned #166534 → _G8_POSITIVE_FG

    def test_lost_is_red(self):
        p = _deal_detail_status_palette("lost")
        assert p["fg"] == "#b91c1c"  # was banned #991b1b → _G8_DESTRUCTIVE_ON_LIGHT_FG

    def test_abandoned_is_gray(self):
        p = _deal_detail_status_palette("abandoned")
        assert p["fg"] == "#777777"

    def test_unknown_falls_back_to_open(self):
        p = _deal_detail_status_palette("weird")
        assert p["fg"] == "#7d2df3"  # was banned #1d4ed8 → _G8_PRIMARY


# ---------------------------------------------------------------------------
# ISO parsing + day arithmetic
# ---------------------------------------------------------------------------


class TestDealDetailParseIso:
    def test_valid_iso_returns_datetime(self):
        dt = _deal_detail_parse_iso("2026-04-15T10:00:00Z")
        assert dt is not None
        assert dt.year == 2026

    def test_valid_iso_tz_aware_stays_aware(self):
        dt = _deal_detail_parse_iso("2026-04-15T10:00:00+00:00")
        assert dt is not None
        assert dt.tzinfo is not None

    def test_naive_iso_gets_utc_tz(self):
        dt = _deal_detail_parse_iso("2026-04-15T10:00:00")
        assert dt is not None
        assert dt.tzinfo is not None

    def test_none_returns_none(self):
        assert _deal_detail_parse_iso(None) is None

    def test_empty_returns_none(self):
        assert _deal_detail_parse_iso("") is None
        assert _deal_detail_parse_iso("   ") is None

    def test_garbage_returns_none(self):
        assert _deal_detail_parse_iso("not a date") is None
        assert _deal_detail_parse_iso("2026-13-45") is None


class TestDealDetailDaysSince:
    def test_recent_date(self):
        ten_days_ago = (datetime.now(timezone.utc) - timedelta(days=10)).isoformat()
        assert _deal_detail_days_since(ten_days_ago) == 10

    def test_zero_days(self):
        now = datetime.now(timezone.utc).isoformat()
        result = _deal_detail_days_since(now)
        # Could be 0 or possibly -1 due to microsecond drift; allow both
        assert result in (0, -1)

    def test_none_returns_none(self):
        assert _deal_detail_days_since(None) is None

    def test_garbage_returns_none(self):
        assert _deal_detail_days_since("bad") is None


class TestDealDetailDaysUntil:
    def test_future_date(self):
        future = (datetime.now(timezone.utc) + timedelta(days=30)).isoformat()
        result = _deal_detail_days_until(future)
        assert result in (29, 30)  # microsecond drift tolerance

    def test_past_date_returns_negative(self):
        past = (datetime.now(timezone.utc) - timedelta(days=5)).isoformat()
        result = _deal_detail_days_until(past)
        assert result in (-5, -6)

    def test_none_returns_none(self):
        assert _deal_detail_days_until(None) is None

    def test_garbage_returns_none(self):
        assert _deal_detail_days_until("bad") is None


# ---------------------------------------------------------------------------
# Stage index finder
# ---------------------------------------------------------------------------


class TestDealDetailFindCurrentStageIndex:
    def _stages(self):
        return [
            {"id": "stage_1", "name": "Discovery"},
            {"id": "stage_2", "name": "Proposal"},
            {"id": "stage_3", "name": "Negotiation"},
            {"id": "stage_4", "name": "Closed Won"},
        ]

    def test_id_match_first_stage(self):
        assert _deal_detail_find_current_stage_index(self._stages(), "stage_1") == 0

    def test_id_match_middle(self):
        assert _deal_detail_find_current_stage_index(self._stages(), "stage_2") == 1

    def test_id_match_last(self):
        assert _deal_detail_find_current_stage_index(self._stages(), "stage_4") == 3

    def test_name_fallback_match(self):
        # If no id matches, try name-lowercase fallback
        assert _deal_detail_find_current_stage_index(
            self._stages(), "proposal"
        ) == 1

    def test_name_fallback_case_insensitive(self):
        assert _deal_detail_find_current_stage_index(
            self._stages(), "NEGOTIATION"
        ) == 2

    def test_no_match_returns_none(self):
        assert _deal_detail_find_current_stage_index(
            self._stages(), "nonexistent"
        ) is None

    def test_none_target_returns_none(self):
        assert _deal_detail_find_current_stage_index(self._stages(), None) is None

    def test_empty_target_returns_none(self):
        assert _deal_detail_find_current_stage_index(self._stages(), "") is None
        assert _deal_detail_find_current_stage_index(self._stages(), "   ") is None

    def test_none_stages_returns_none(self):
        assert _deal_detail_find_current_stage_index(None, "stage_1") is None

    def test_empty_stages_returns_none(self):
        assert _deal_detail_find_current_stage_index([], "stage_1") is None

    def test_non_dict_entries_skipped(self):
        stages = [
            "not a dict",
            None,
            {"id": "stage_1", "name": "Discovery"},
        ]
        assert _deal_detail_find_current_stage_index(stages, "stage_1") == 2


# ---------------------------------------------------------------------------
# Pipeline ladder rendering
# ---------------------------------------------------------------------------


class TestDealDetailPipelineLadder:
    def _stages(self):
        return [
            {"id": "s1", "name": "Discovery"},
            {"id": "s2", "name": "Proposal"},
            {"id": "s3", "name": "Closed Won"},
        ]

    def test_none_stages_empty_string(self):
        assert _render_deal_detail_pipeline_ladder(None, "s1", "open") == ""

    def test_empty_list_empty_string(self):
        assert _render_deal_detail_pipeline_ladder([], "s1", "open") == ""

    def test_all_non_dict_empty_string(self):
        assert _render_deal_detail_pipeline_ladder(
            ["a", None, 5], "s1", "open"
        ) == ""

    def test_renders_pills_for_each_stage(self):
        html = _render_deal_detail_pipeline_ladder(self._stages(), "s1", "open")
        assert "Discovery" in html
        assert "Proposal" in html
        assert "Closed Won" in html

    def test_includes_section_title(self):
        html = _render_deal_detail_pipeline_ladder(self._stages(), "s1", "open")
        assert "Pipeline position" in html

    def test_current_stage_uses_status_palette(self):
        html = _render_deal_detail_pipeline_ladder(self._stages(), "s2", "open")
        # s2 is current with open status → open palette colors
        assert "#f2eafe" in html  # open bg
        assert "#7d2df3" in html  # open fg (was banned #1d4ed8 → _G8_PRIMARY)

    def test_past_stages_green_muted(self):
        html = _render_deal_detail_pipeline_ladder(self._stages(), "s2", "open")
        # s1 is before s2 → muted green
        assert "#f0fdf4" in html  # muted green bg

    def test_current_none_falls_back_to_muted_all(self):
        # When current stage cannot be located, render all muted
        html = _render_deal_detail_pipeline_ladder(
            self._stages(), "nonexistent", "open"
        )
        assert "#f9f9f9" in html

    def test_markers_rendered(self):
        html = _render_deal_detail_pipeline_ladder(self._stages(), "s2", "open")
        # Check for the three marker types
        assert "✓" in html  # past (s1)
        assert "●" in html  # current (s2)
        assert "○" in html  # future (s3)

    def test_unnamed_stage_gets_placeholder(self):
        stages = [{"id": "s1"}]  # no name
        html = _render_deal_detail_pipeline_ladder(stages, "s1", "open")
        assert "(unnamed)" in html


# ---------------------------------------------------------------------------
# HTML renderer — empty states
# ---------------------------------------------------------------------------


class TestRenderDealDetailEmptyStates:
    def test_none_deal_returns_not_found(self):
        html = render_deal_detail_html(deal=None, deal_id="abc-123")
        assert "Deal not found" in html
        assert "abc-123" in html

    def test_non_dict_deal_returns_not_found(self):
        html = render_deal_detail_html(deal="not a dict", deal_id="xyz")
        assert "Deal not found" in html

    def test_list_deal_returns_not_found(self):
        html = render_deal_detail_html(deal=[1, 2, 3], deal_id="xyz")
        assert "Deal not found" in html

    def test_empty_state_escapes_deal_id(self):
        html = render_deal_detail_html(
            deal=None, deal_id="<script>alert('xss')</script>"
        )
        assert "<script>alert" not in html
        assert "&lt;script&gt;" in html

    def test_empty_state_references_pipeline_surface(self):
        html = render_deal_detail_html(deal=None, deal_id="x")
        assert "g8://deals/pipeline" in html


# ---------------------------------------------------------------------------
# HTML renderer — populated
# ---------------------------------------------------------------------------


def _sample_deal():
    return {
        "id": "deal-abc-123",
        "name": "Acme Q2 Expansion",
        "description": "Multi-year expansion deal with Acme Corp.",
        "amount": 250000.0,
        "currency": "USD",
        "stage_id": "stage_negotiation",
        "stage_name": "Negotiation",
        "pipeline_id": "pipeline_main",
        "company_id": 42,
        "owner_id": "ae_alice",
        "close_date": (datetime.now(timezone.utc) + timedelta(days=30)).isoformat(),
        "created_at": (datetime.now(timezone.utc) - timedelta(days=45)).isoformat(),
        "updated_at": (datetime.now(timezone.utc) - timedelta(days=2)).isoformat(),
    }


def _sample_stages():
    return [
        {"id": "stage_discovery", "name": "Discovery"},
        {"id": "stage_proposal", "name": "Proposal"},
        {"id": "stage_negotiation", "name": "Negotiation"},
        {"id": "stage_won", "name": "Closed Won"},
        {"id": "stage_lost", "name": "Closed Lost"},
    ]


class TestRenderDealDetailPopulated:
    def test_title_includes_deal_name(self):
        html = render_deal_detail_html(deal=_sample_deal(), deal_id="deal-abc-123")
        assert "Acme Q2 Expansion" in html
        assert "<title>Deal — Acme Q2 Expansion</title>" in html

    def test_deal_id_rendered(self):
        html = render_deal_detail_html(deal=_sample_deal(), deal_id="deal-abc-123")
        assert "deal-abc-123" in html

    def test_status_badge_open(self):
        html = render_deal_detail_html(deal=_sample_deal(), deal_id="x")
        assert "OPEN" in html

    def test_status_badge_won_when_stage_is_closed_won(self):
        deal = _sample_deal()
        deal["stage_name"] = "Closed Won"
        html = render_deal_detail_html(deal=deal, deal_id="x")
        assert "WON" in html

    def test_status_badge_lost_when_stage_is_closed_lost(self):
        deal = _sample_deal()
        deal["stage_name"] = "Closed Lost"
        html = render_deal_detail_html(deal=deal, deal_id="x")
        assert "LOST" in html

    def test_amount_formatted(self):
        html = render_deal_detail_html(deal=_sample_deal(), deal_id="x")
        # 250k → USD 250.0k
        assert "USD 250" in html

    def test_stage_name_rendered(self):
        html = render_deal_detail_html(deal=_sample_deal(), deal_id="x")
        assert "Negotiation" in html

    def test_days_in_pipeline_rendered(self):
        html = render_deal_detail_html(deal=_sample_deal(), deal_id="x")
        # 45d old
        assert "Days in pipeline" in html
        assert "45d" in html or "44d" in html  # drift tolerance

    def test_close_date_future_shows_days_away(self):
        html = render_deal_detail_html(deal=_sample_deal(), deal_id="x")
        assert "away" in html

    def test_close_date_past_shows_overdue_in_red(self):
        deal = _sample_deal()
        deal["close_date"] = (datetime.now(timezone.utc) - timedelta(days=5)).isoformat()
        html = render_deal_detail_html(deal=deal, deal_id="x")
        assert "overdue" in html
        assert "#dc2626" in html  # red

    def test_close_date_today_shows_today(self):
        deal = _sample_deal()
        deal["close_date"] = datetime.now(timezone.utc).isoformat()
        html = render_deal_detail_html(deal=deal, deal_id="x")
        assert "today" in html or "away" in html  # drift tolerance

    def test_pipeline_ladder_rendered_when_stages_present(self):
        html = render_deal_detail_html(
            deal=_sample_deal(),
            deal_id="x",
            pipeline_stages=_sample_stages(),
        )
        assert "Pipeline position" in html
        assert "Discovery" in html
        assert "Closed Won" in html

    def test_pipeline_ladder_omitted_when_no_stages(self):
        html = render_deal_detail_html(deal=_sample_deal(), deal_id="x")
        assert "Pipeline position" not in html

    def test_description_rendered(self):
        html = render_deal_detail_html(deal=_sample_deal(), deal_id="x")
        assert "Multi-year expansion" in html
        assert "Description" in html

    def test_description_omitted_when_empty(self):
        deal = _sample_deal()
        deal["description"] = None
        html = render_deal_detail_html(deal=deal, deal_id="x")
        # "Description" section title should not appear
        # (other parts may happen to contain the word, so check carefully)
        assert '<section class="description">' not in html

    def test_company_name_rendered_when_provided(self):
        html = render_deal_detail_html(
            deal=_sample_deal(),
            deal_id="x",
            company_name="Acme Corp",
        )
        assert "Acme Corp" in html
        assert "Relationships" in html

    def test_company_id_fallback_when_no_name(self):
        html = render_deal_detail_html(deal=_sample_deal(), deal_id="x")
        assert "Company #42" in html

    def test_owner_id_rendered(self):
        html = render_deal_detail_html(deal=_sample_deal(), deal_id="x")
        assert "ae_alice" in html

    def test_relationships_section_omitted_when_both_empty(self):
        deal = _sample_deal()
        deal["company_id"] = None
        deal["owner_id"] = None
        html = render_deal_detail_html(deal=deal, deal_id="x")
        assert '<section class="relationships">' not in html

    def test_timestamps_rendered(self):
        html = render_deal_detail_html(deal=_sample_deal(), deal_id="x")
        assert "created" in html
        assert "updated" in html

    def test_no_script_tags(self):
        html = render_deal_detail_html(deal=_sample_deal(), deal_id="x")
        assert "<script>" not in html
        assert "<script " not in html
        assert "javascript:" not in html

    def test_doctype_present(self):
        html = render_deal_detail_html(deal=_sample_deal(), deal_id="x")
        assert html.startswith("<!doctype html>")

    def test_xss_escape_in_deal_name(self):
        deal = _sample_deal()
        deal["name"] = "<script>alert('xss')</script>Evil Deal"
        html = render_deal_detail_html(deal=deal, deal_id="x")
        assert "<script>alert" not in html
        assert "&lt;script&gt;" in html

    def test_xss_escape_in_description(self):
        deal = _sample_deal()
        deal["description"] = "<img src=x onerror=alert(1)>"
        html = render_deal_detail_html(deal=deal, deal_id="x")
        assert "<img src=x" not in html
        # escaped form
        assert "&lt;img" in html

    def test_xss_escape_in_owner_id(self):
        deal = _sample_deal()
        deal["owner_id"] = "<script>alert(1)</script>"
        html = render_deal_detail_html(deal=deal, deal_id="x")
        assert "<script>alert" not in html

    def test_xss_escape_in_deal_id(self):
        deal = _sample_deal()
        html = render_deal_detail_html(deal=deal, deal_id="<evil>")
        assert "<evil>" not in html
        assert "&lt;evil&gt;" in html

    def test_no_amount_shows_dash(self):
        deal = _sample_deal()
        deal["amount"] = None
        html = render_deal_detail_html(deal=deal, deal_id="x")
        # Amount card should show em-dash equivalent
        assert "Amount" in html
        assert "—" in html

    def test_no_stage_name_shows_placeholder(self):
        deal = _sample_deal()
        deal["stage_name"] = None
        deal["stage_id"] = None
        html = render_deal_detail_html(deal=deal, deal_id="x")
        assert "(no stage)" in html

    def test_stage_type_from_deal_overrides_name_heuristic(self):
        # If deal carries explicit stage_type, it overrides the name-based
        # heuristic. This matters for pipelines where stage_name is
        # something like "Closed" (ambiguous) but stage_type="won".
        deal = _sample_deal()
        deal["stage_name"] = "Discovery"  # would normally map to open
        deal["stage_type"] = "won"
        html = render_deal_detail_html(deal=deal, deal_id="x")
        assert "WON" in html

    def test_non_dict_pipeline_stages_gracefully_ignored(self):
        html = render_deal_detail_html(
            deal=_sample_deal(),
            deal_id="x",
            pipeline_stages="not a list",
        )
        # Renderer should just omit the ladder, not crash
        assert "Pipeline position" not in html


# ---------------------------------------------------------------------------
# Plaintext fallback
# ---------------------------------------------------------------------------


class TestRenderDealDetailTextFallback:
    def test_none_deal_returns_not_found(self):
        text = render_deal_detail_text_fallback(deal=None, deal_id="abc")
        assert "# Deal not found" in text
        assert "abc" in text

    def test_non_dict_deal_returns_not_found(self):
        text = render_deal_detail_text_fallback(deal="not a dict", deal_id="x")
        assert "# Deal not found" in text

    def test_populated_has_markdown_title(self):
        text = render_deal_detail_text_fallback(
            deal=_sample_deal(), deal_id="x"
        )
        assert text.startswith("# Acme Q2 Expansion")

    def test_populated_has_deal_id_backticks(self):
        text = render_deal_detail_text_fallback(
            deal=_sample_deal(), deal_id="deal-abc-123"
        )
        assert "`deal-abc-123`" in text

    def test_populated_has_status_line(self):
        text = render_deal_detail_text_fallback(
            deal=_sample_deal(), deal_id="x"
        )
        assert "Status: **OPEN**" in text

    def test_populated_has_overview_section(self):
        text = render_deal_detail_text_fallback(
            deal=_sample_deal(), deal_id="x"
        )
        assert "## Overview" in text
        assert "- Amount: USD" in text
        assert "- Stage: Negotiation" in text
        assert "- Close date:" in text
        assert "- Days in pipeline:" in text

    def test_pipeline_section_with_stages(self):
        text = render_deal_detail_text_fallback(
            deal=_sample_deal(),
            deal_id="x",
            pipeline_stages=_sample_stages(),
        )
        assert "## Pipeline position" in text
        assert "Discovery" in text
        assert "Negotiation" in text
        # Past stages use check marker
        assert "✓" in text
        # Current uses filled marker
        assert "●" in text
        # Future uses open marker
        assert "○" in text

    def test_pipeline_section_omitted_without_stages(self):
        text = render_deal_detail_text_fallback(
            deal=_sample_deal(), deal_id="x"
        )
        assert "## Pipeline position" not in text

    def test_description_section(self):
        text = render_deal_detail_text_fallback(
            deal=_sample_deal(), deal_id="x"
        )
        assert "## Description" in text
        assert "Multi-year expansion" in text

    def test_description_omitted_when_empty(self):
        deal = _sample_deal()
        deal["description"] = None
        text = render_deal_detail_text_fallback(deal=deal, deal_id="x")
        assert "## Description" not in text

    def test_relationships_section(self):
        text = render_deal_detail_text_fallback(
            deal=_sample_deal(),
            deal_id="x",
            company_name="Acme Corp",
        )
        assert "## Relationships" in text
        assert "- Company: Acme Corp" in text
        assert "- Owner: ae_alice" in text

    def test_relationships_falls_back_to_company_id(self):
        text = render_deal_detail_text_fallback(
            deal=_sample_deal(), deal_id="x"
        )
        assert "- Company: #42" in text

    def test_relationships_omitted_when_both_empty(self):
        deal = _sample_deal()
        deal["company_id"] = None
        deal["owner_id"] = None
        text = render_deal_detail_text_fallback(deal=deal, deal_id="x")
        assert "## Relationships" not in text

    def test_timestamps_line(self):
        text = render_deal_detail_text_fallback(
            deal=_sample_deal(), deal_id="x"
        )
        assert "created" in text
        assert "updated" in text

    def test_trailing_newline(self):
        text = render_deal_detail_text_fallback(
            deal=_sample_deal(), deal_id="x"
        )
        assert text.endswith("\n")

    def test_days_in_pipeline_em_dash_when_no_created_at(self):
        deal = _sample_deal()
        deal["created_at"] = None
        text = render_deal_detail_text_fallback(deal=deal, deal_id="x")
        assert "- Days in pipeline: —" in text

    def test_close_date_em_dash_when_none(self):
        deal = _sample_deal()
        deal["close_date"] = None
        text = render_deal_detail_text_fallback(deal=deal, deal_id="x")
        assert "- Close date: —" in text

    def test_won_status_in_text(self):
        deal = _sample_deal()
        deal["stage_type"] = "won"
        text = render_deal_detail_text_fallback(deal=deal, deal_id="x")
        assert "Status: **WON**" in text
