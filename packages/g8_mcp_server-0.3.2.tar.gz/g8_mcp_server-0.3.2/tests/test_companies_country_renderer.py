"""Unit tests for Surface #79 — country-scoped companies pane renderer.

Tests mirror the #78 (companies/industry) layout with divergence-locking
invariant tests for the 4 intentional design differences:
  1. Geographic axis (not entity attribute) — first geo-filter.
  2. Backend filter is EXACT match (URI slug → canonical TITLE-CASE value)
     via _companies_country_backend_value.
  3. Stats row: Total / With domain / Unique industries / With LinkedIn
     (test_has_unique_industries_not_employee_tiers).
  4. Sort key: (industry ASC, employee_count DESC, name ASC) — cluster by
     industry within a country pane (test_sort_by_industry_then_employee_count_desc).
  5. Drill-up adds cross-AXIS link to g8://companies/industry/saas AND keeps
     cross-entity link to g8://contacts/dashboard established by #78
     (test_cross_axis_drill_up_to_industry).
"""

from __future__ import annotations

import pytest

from mcp_server.g8_mcp_server.app_renderer import (
    _COMPANIES_COUNTRY_ALIASES,
    _COMPANIES_COUNTRY_BACKEND_VALUE,
    _COMPANIES_COUNTRY_LABELS,
    _COMPANIES_COUNTRY_VALID,
    _companies_country_backend_value,
    _companies_country_chip_html,
    _companies_country_clip,
    _companies_country_display_name,
    _companies_country_drill_up_html,
    _companies_country_empty_state_html,
    _companies_country_employee_count,
    _companies_country_header_html,
    _companies_country_industry_str,
    _companies_country_kpi_card_html,
    _companies_country_label,
    _companies_country_list_html,
    _companies_country_location,
    _companies_country_normalize,
    _companies_country_overflow_banner_html,
    _companies_country_page_html,
    _companies_country_palette,
    _companies_country_row_html,
    _companies_country_short_label,
    _companies_country_stats_row_html,
    render_companies_country_html,
    render_companies_country_text_fallback,
)


# ---------------------------------------------------------------------------
# Normalize — canonical keys
# ---------------------------------------------------------------------------
class TestNormalizeCanonical:
    @pytest.mark.parametrize("key", _COMPANIES_COUNTRY_VALID)
    def test_canonical_self_map(self, key):
        assert _companies_country_normalize(key) == key

    @pytest.mark.parametrize("key", _COMPANIES_COUNTRY_VALID)
    def test_canonical_uppercase_maps(self, key):
        assert _companies_country_normalize(key.upper()) == key

    @pytest.mark.parametrize("key", _COMPANIES_COUNTRY_VALID)
    def test_canonical_spaces_and_hyphens(self, key):
        spaced = key.replace("_", " ")
        hyphened = key.replace("_", "-")
        assert _companies_country_normalize(spaced) == key
        assert _companies_country_normalize(hyphened) == key


# ---------------------------------------------------------------------------
# Normalize — aliases
# ---------------------------------------------------------------------------
class TestNormalizeAliases:
    @pytest.mark.parametrize(
        "alias,expected", sorted(_COMPANIES_COUNTRY_ALIASES.items())
    )
    def test_alias_maps_to_canonical(self, alias, expected):
        assert _companies_country_normalize(alias) == expected

    @pytest.mark.parametrize(
        "alias,expected", sorted(_COMPANIES_COUNTRY_ALIASES.items())
    )
    def test_alias_uppercase_maps(self, alias, expected):
        assert _companies_country_normalize(alias.upper()) == expected

    def test_us_aliases(self):
        for alias in ["us", "USA", "America", "U-S", "u_s_a", "united-states"]:
            assert _companies_country_normalize(alias) == "united_states"

    def test_uk_aliases(self):
        for alias in ["uk", "UK", "Britain", "great-britain", "GB", "England"]:
            assert _companies_country_normalize(alias) == "united_kingdom"

    def test_germany_aliases(self):
        for alias in ["de", "DE", "Deutschland", "german", "GER"]:
            assert _companies_country_normalize(alias) == "germany"

    def test_netherlands_aliases(self):
        for alias in ["nl", "dutch", "Holland", "the-Netherlands"]:
            assert _companies_country_normalize(alias) == "netherlands"

    def test_uae_aliases(self):
        for alias in ["ae", "Dubai", "Emirates", "united-arab-emirates"]:
            assert _companies_country_normalize(alias) == "uae"


# ---------------------------------------------------------------------------
# Normalize — invalid input
# ---------------------------------------------------------------------------
class TestNormalizeInvalid:
    @pytest.mark.parametrize(
        "raw",
        [
            "",
            " ",
            "\t",
            "bogus",
            "nowhere",
            "atlantis",
            "zzzzzzz",
            None,
            123,
            [],
            {},
            True,
            False,
            0,
        ],
    )
    def test_invalid_returns_none(self, raw):
        assert _companies_country_normalize(raw) is None

    @pytest.mark.parametrize(
        "literal",
        [
            "notes",
            "deals",
            "contacts",
            "activities",
            "dashboard",
            "industry",
            "NOTES",
            "Dashboard",
        ],
    )
    def test_no_collision_with_nested_literals(self, literal):
        """Must not accept the sibling nested literal as a country value."""
        assert _companies_country_normalize(literal) is None


# ---------------------------------------------------------------------------
# Label + short_label
# ---------------------------------------------------------------------------
class TestLabel:
    @pytest.mark.parametrize(
        "key,expected",
        [
            ("united_states", "United States"),
            ("united_kingdom", "United Kingdom"),
            ("germany", "Germany"),
            ("uae", "United Arab Emirates"),
            ("us", "United States"),
            ("UK", "United Kingdom"),
            ("bogus", "Companies"),
            (None, "Companies"),
            ("", "Companies"),
        ],
    )
    def test_label(self, key, expected):
        assert _companies_country_label(key) == expected


class TestShortLabel:
    def test_short_label_same_as_label(self):
        assert _companies_country_short_label("us") == "United States"


# ---------------------------------------------------------------------------
# Backend value mapping (divergence #2 from #78 — EXACT match)
# ---------------------------------------------------------------------------
class TestBackendValue:
    @pytest.mark.parametrize(
        "key,expected",
        [
            ("us", "United States"),
            ("USA", "United States"),
            ("united_states", "United States"),
            ("uk", "United Kingdom"),
            ("britain", "United Kingdom"),
            ("de", "Germany"),
            ("deutschland", "Germany"),
            ("fr", "France"),
            ("dubai", "United Arab Emirates"),
            ("uae", "United Arab Emirates"),
        ],
    )
    def test_aliases_resolve_to_title_case_backend_value(self, key, expected):
        assert _companies_country_backend_value(key) == expected

    def test_invalid_returns_none(self):
        assert _companies_country_backend_value("bogus") is None
        assert _companies_country_backend_value(None) is None

    def test_all_canonical_have_backend_value(self):
        for key in _COMPANIES_COUNTRY_VALID:
            bv = _companies_country_backend_value(key)
            assert bv is not None
            # Must be title case (first letter uppercase)
            assert bv[0].isupper(), f"{key} → {bv!r} not title case"

    def test_backend_value_matches_label(self):
        """backend_value and label should be identical (both are the
        human-readable country name)."""
        for key in _COMPANIES_COUNTRY_VALID:
            assert _companies_country_backend_value(key) == _COMPANIES_COUNTRY_LABELS[key]


# ---------------------------------------------------------------------------
# Palette — 3-tier geo-themed bucketing
# ---------------------------------------------------------------------------
class TestPalette:
    @pytest.mark.parametrize(
        "key",
        ["united_states", "united_kingdom", "canada", "germany", "france"],
    )
    def test_accent_countries(self, key):
        bg, fg = _companies_country_palette(key)
        assert bg == "#f2eafe"  # graph8 accent bg
        assert fg == "#7d2df3"  # graph8 primary

    @pytest.mark.parametrize(
        "key", ["india", "brazil", "mexico", "china", "uae"],
    )
    def test_warning_countries(self, key):
        bg, fg = _companies_country_palette(key)
        assert bg == "#fff3c4"  # graph8 warning bg
        assert fg == "#a0750a"  # graph8 warning fg

    @pytest.mark.parametrize(
        "key",
        [
            "japan", "australia", "netherlands", "spain", "italy",
            "sweden", "switzerland", "singapore", "ireland", "israel",
        ],
    )
    def test_muted_countries(self, key):
        bg, fg = _companies_country_palette(key)
        assert bg == "#f9f9f9"  # graph8 muted bg
        assert fg == "#777777"  # graph8 text muted

    @pytest.mark.parametrize("key", _COMPANIES_COUNTRY_VALID)
    def test_no_banned_hexes(self, key):
        bg, fg = _companies_country_palette(key)
        banned = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}
        assert bg not in banned
        assert fg not in banned

    def test_invalid_returns_muted(self):
        bg, fg = _companies_country_palette("bogus")
        assert bg == "#f9f9f9"
        assert fg == "#777777"


# ---------------------------------------------------------------------------
# Clip
# ---------------------------------------------------------------------------
class TestClip:
    def test_short_passthrough(self):
        assert _companies_country_clip("hello", 20) == "hello"

    def test_at_cap(self):
        assert _companies_country_clip("a" * 20, 20) == "a" * 20

    def test_over_cap_ellipsis(self):
        result = _companies_country_clip("a" * 30, 10)
        assert result.endswith("…")
        assert len(result) == 10

    def test_none_returns_empty(self):
        assert _companies_country_clip(None, 10) == ""

    def test_empty_string(self):
        assert _companies_country_clip("", 10) == ""

    def test_whitespace_stripped(self):
        assert _companies_country_clip("  hi  ", 10) == "hi"

    def test_coerces_int(self):
        assert _companies_country_clip(42, 10) == "42"

    def test_escapes_html(self):
        assert "&lt;" in _companies_country_clip("<script>", 20)


# ---------------------------------------------------------------------------
# Employee count helper (used in sort key)
# ---------------------------------------------------------------------------
class TestEmployeeCount:
    @pytest.mark.parametrize(
        "val,expected",
        [
            (0, 0),
            (5, 5),
            (100, 100),
            (5000, 5000),
            ("42", 42),
            ("1,234", 1234),
            (None, 0),
            ("bogus", 0),
            ("", 0),
        ],
    )
    def test_employee_count(self, val, expected):
        assert _companies_country_employee_count({"employee_count": val}) == expected

    def test_non_dict(self):
        assert _companies_country_employee_count("not a dict") == 0


# ---------------------------------------------------------------------------
# Industry string helper (used in sort key)
# ---------------------------------------------------------------------------
class TestIndustryStr:
    def test_basic(self):
        assert _companies_country_industry_str({"industry": "SaaS"}) == "SaaS"

    def test_whitespace_stripped(self):
        assert _companies_country_industry_str({"industry": "  Fintech  "}) == "Fintech"

    def test_empty(self):
        assert _companies_country_industry_str({"industry": ""}) == ""

    def test_none(self):
        assert _companies_country_industry_str({"industry": None}) == ""

    def test_missing_key(self):
        assert _companies_country_industry_str({}) == ""

    def test_non_dict(self):
        assert _companies_country_industry_str("not a dict") == ""


# ---------------------------------------------------------------------------
# Display name
# ---------------------------------------------------------------------------
class TestDisplayName:
    def test_name_preferred(self):
        assert _companies_country_display_name({"name": "AlphaCo"}) == "AlphaCo"

    def test_company_name_fallback(self):
        assert (
            _companies_country_display_name({"company_name": "BetaCorp"})
            == "BetaCorp"
        )

    def test_domain_fallback(self):
        assert (
            _companies_country_display_name({"domain": "acme.com"}) == "acme.com"
        )

    def test_unnamed_fallback(self):
        assert _companies_country_display_name({}) == "(unnamed company)"

    def test_non_dict(self):
        assert _companies_country_display_name("nope") == "(unnamed company)"

    def test_xss_escaped(self):
        out = _companies_country_display_name({"name": "<script>"})
        assert "<script>" not in out
        assert "&lt;" in out


# ---------------------------------------------------------------------------
# Location
# ---------------------------------------------------------------------------
class TestLocation:
    def test_city_state(self):
        assert (
            _companies_country_location({"city": "NYC", "state": "NY"})
            == "NYC, NY"
        )

    def test_city_only(self):
        assert _companies_country_location({"city": "Paris"}) == "Paris"

    def test_empty_fields_skipped(self):
        assert (
            _companies_country_location({"city": "NYC", "state": ""})
            == "NYC"
        )

    def test_all_missing(self):
        assert _companies_country_location({}) == ""

    def test_non_dict(self):
        assert _companies_country_location("no") == ""

    def test_xss_escaped(self):
        out = _companies_country_location({"city": "<x>", "state": "NY"})
        assert "<x>" not in out


# ---------------------------------------------------------------------------
# Header
# ---------------------------------------------------------------------------
class TestHeader:
    def test_label_present(self):
        html = _companies_country_header_html(country="us", count=5)
        assert "United States" in html

    def test_eyebrow_country_prefix(self):
        html = _companies_country_header_html(country="us", count=1)
        assert "Country ·" in html

    def test_singular_plural(self):
        assert "1 company" in _companies_country_header_html(country="us", count=1)
        assert "5 companies" in _companies_country_header_html(country="us", count=5)
        assert "0 companies" in _companies_country_header_html(country="us", count=0)

    def test_uses_graph8_primary(self):
        html = _companies_country_header_html(country="us", count=3)
        assert "#7d2df3" in html

    def test_xss_escaped(self):
        html = _companies_country_header_html(country="<x>", count=1)
        assert "<x>" not in html or "&lt;" in html


# ---------------------------------------------------------------------------
# KPI card
# ---------------------------------------------------------------------------
class TestKpiCard:
    def test_label_and_value(self):
        html = _companies_country_kpi_card_html(label="Total", value=42)
        assert "Total" in html
        assert "42" in html

    def test_accent_variant(self):
        html = _companies_country_kpi_card_html(
            label="Total", value=1, variant="accent"
        )
        assert "#f2eafe" in html


# ---------------------------------------------------------------------------
# Stats row — DIVERGENCE LOCK #1
# ---------------------------------------------------------------------------
class TestStatsRow:
    def test_four_cards(self):
        companies = [{"domain": "a.com", "industry": "saas", "linkedin_url": "https://x"}]
        html = _companies_country_stats_row_html(companies)
        assert "Total" in html
        assert "With domain" in html
        assert "Unique industries" in html
        assert "With LinkedIn" in html

    def test_has_unique_industries_not_employee_tiers(self):
        """LOCK: #79 stats row is geo-flavored — Unique industries + With
        LinkedIn, NOT Employee tiers + Unique countries (#78's row).
        """
        companies = [{"domain": "a.com", "industry": "saas"}]
        html = _companies_country_stats_row_html(companies)
        # Positive invariants
        assert "Unique industries" in html
        assert "With LinkedIn" in html
        # Negative invariants
        assert "Employee tiers" not in html
        assert "Unique countries" not in html

    def test_counts_correct(self):
        companies = [
            {"domain": "a.com", "industry": "saas", "linkedin_url": "https://x"},
            {"domain": "b.com", "industry": "saas"},
            {"industry": "fintech"},
            {"industry": "healthcare", "linkedin_url": "https://y"},
        ]
        html = _companies_country_stats_row_html(companies)
        # With domain: 2 (a.com, b.com)
        # Unique industries: 3 (saas, fintech, healthcare)
        # With LinkedIn: 2
        assert ">2<" in html or ">2 <" in html  # at minimum a "2" appears
        assert ">3<" in html or ">3 <" in html

    def test_empty_list(self):
        html = _companies_country_stats_row_html([])
        assert ">0<" in html

    def test_filters_non_dict(self):
        html = _companies_country_stats_row_html([{"domain": "a"}, "not dict", None, 42])
        # Only the dict should count
        assert "Total" in html


# ---------------------------------------------------------------------------
# Chip
# ---------------------------------------------------------------------------
class TestChip:
    def test_renders_label(self):
        html = _companies_country_chip_html(label="US", bg="#f2eafe", fg="#7d2df3")
        assert "US" in html

    def test_border_optional(self):
        with_border = _companies_country_chip_html(
            label="a", bg="#fff", fg="#000", border=True,
        )
        without = _companies_country_chip_html(
            label="a", bg="#fff", fg="#000", border=False,
        )
        assert "border:1px" in with_border
        assert "border:1px" not in without


# ---------------------------------------------------------------------------
# Row
# ---------------------------------------------------------------------------
class TestRow:
    def test_basic(self):
        c = {"name": "AlphaCo", "domain": "alpha.com", "industry": "SaaS",
             "employee_count": 100, "city": "NYC", "state": "NY"}
        html = _companies_country_row_html(c, "us")
        assert "AlphaCo" in html
        assert "alpha.com" in html
        assert "100 employees" in html
        assert "SaaS" in html  # industry chip

    def test_country_chip_present(self):
        c = {"name": "X", "industry": "saas"}
        html = _companies_country_row_html(c, "us")
        assert "United States" in html

    def test_industry_chip_when_present(self):
        html = _companies_country_row_html(
            {"name": "X", "industry": "FinTech"}, "us",
        )
        assert "FinTech" in html

    def test_no_industry_chip_when_missing(self):
        html = _companies_country_row_html({"name": "X"}, "us")
        # Only country chip should be present
        assert html.count("<span") == 1

    def test_non_dict_returns_empty(self):
        assert _companies_country_row_html("nope", "us") == ""

    def test_xss_name(self):
        html = _companies_country_row_html({"name": "<script>"}, "us")
        assert "<script>" not in html

    def test_xss_domain(self):
        html = _companies_country_row_html(
            {"name": "X", "domain": "<x>"}, "us",
        )
        assert "<x>" not in html

    def test_xss_industry(self):
        html = _companies_country_row_html(
            {"name": "X", "industry": "<x>"}, "us",
        )
        assert "<x>" not in html

    def test_employee_count_comma_formatted(self):
        html = _companies_country_row_html(
            {"name": "X", "employee_count": 5000}, "us",
        )
        assert "5,000" in html

    def test_missing_all_fields_graceful(self):
        html = _companies_country_row_html({}, "us")
        assert "(unnamed company)" in html

    def test_location_rendered(self):
        html = _companies_country_row_html(
            {"name": "X", "city": "SF", "state": "CA"}, "us",
        )
        assert "SF, CA" in html


# ---------------------------------------------------------------------------
# List
# ---------------------------------------------------------------------------
class TestList:
    def test_renders_all_rows(self):
        companies = [{"name": f"Co{i}"} for i in range(3)]
        html = _companies_country_list_html(companies, "us")
        for i in range(3):
            assert f"Co{i}" in html

    def test_caps_at_100(self):
        companies = [{"name": f"Co{i}"} for i in range(150)]
        html = _companies_country_list_html(companies, "us")
        # Should only render 100
        assert "Co99" in html
        assert "Co100" not in html


# ---------------------------------------------------------------------------
# Overflow banner
# ---------------------------------------------------------------------------
class TestOverflowBanner:
    def test_zero_returns_empty(self):
        assert _companies_country_overflow_banner_html(country="us", overflow=0) == ""

    def test_negative_returns_empty(self):
        assert _companies_country_overflow_banner_html(country="us", overflow=-5) == ""

    def test_positive_renders(self):
        html = _companies_country_overflow_banner_html(country="us", overflow=42)
        assert "42 more" in html

    def test_uses_backend_value_in_url(self):
        """For alias `us`, the overflow URL must use the TITLE-CASE
        backend value 'United States', not the URI slug."""
        html = _companies_country_overflow_banner_html(country="us", overflow=5)
        assert "United States" in html

    def test_uses_muted_bg(self):
        html = _companies_country_overflow_banner_html(country="us", overflow=1)
        assert "#f9f9f9" in html


# ---------------------------------------------------------------------------
# Drill-up — DIVERGENCE LOCK #3 (cross-axis)
# ---------------------------------------------------------------------------
class TestDrillUp:
    def test_has_dashboard(self):
        html = _companies_country_drill_up_html("us")
        assert "g8://companies/dashboard" in html

    def test_siblings_present(self):
        html = _companies_country_drill_up_html("us")
        # All 19 other canonical countries
        for sibling in _COMPANIES_COUNTRY_VALID:
            if sibling == "united_states":
                continue
            assert f"g8://companies/country/{sibling}" in html

    def test_no_self_reference(self):
        html = _companies_country_drill_up_html("us")
        assert "g8://companies/country/united_states" not in html

    def test_cross_axis_drill_up_to_industry(self):
        """LOCK: #79 adds a cross-AXIS link to g8://companies/industry/saas —
        first time companies surfaces have a cross-axis drill-up."""
        html = _companies_country_drill_up_html("us")
        assert "g8://companies/industry/saas" in html
        assert "cross-axis" in html.lower()

    def test_cross_entity_link_to_contacts(self):
        """LOCK: #79 keeps the cross-entity link to g8://contacts/dashboard
        established by #78."""
        html = _companies_country_drill_up_html("us")
        assert "g8://contacts/dashboard" in html
        assert "cross-entity" in html.lower()

    def test_related_surfaces_label(self):
        html = _companies_country_drill_up_html("us")
        assert "Related surfaces" in html


# ---------------------------------------------------------------------------
# Empty state
# ---------------------------------------------------------------------------
class TestEmptyState:
    def test_zero_state_accent(self):
        html = _companies_country_empty_state_html(
            country="us", zero_state=True,
        )
        assert "No United States companies yet" in html
        assert "#f2eafe" in html  # accent bg

    def test_unavailable_muted(self):
        html = _companies_country_empty_state_html(
            country="bogus", zero_state=False,
        )
        assert "unavailable" in html.lower()
        assert "#f9f9f9" in html

    def test_unavailable_hints_valid_keys(self):
        html = _companies_country_empty_state_html(
            country="bogus", zero_state=False,
        )
        # Must list canonical keys
        assert "united_states" in html
        assert "germany" in html

    def test_zero_state_references_backend_value(self):
        """zero_state message must show the exact backend filter value,
        which is the TITLE-CASE name, not the URI slug."""
        html = _companies_country_empty_state_html(
            country="us", zero_state=True,
        )
        assert "United States" in html

    def test_invalid_uses_muted_variant(self):
        html = _companies_country_empty_state_html(
            country="atlantis", zero_state=False,
        )
        # Should NOT use accent bg because country is invalid
        assert "No " not in html or "unavailable" in html.lower()


# ---------------------------------------------------------------------------
# render_companies_country_html — full render
# ---------------------------------------------------------------------------
class TestRenderHtml:
    def test_happy_path(self):
        companies = [
            {"name": "AlphaCo", "domain": "alpha.com", "industry": "saas",
             "employee_count": 100, "linkedin_url": "https://x"},
        ]
        html = render_companies_country_html(companies=companies, country="us")
        assert "United States" in html
        assert "AlphaCo" in html
        assert "alpha.com" in html

    def test_invalid_country(self):
        html = render_companies_country_html(companies=[], country="bogus")
        assert "unavailable" in html.lower()

    def test_invalid_non_string(self):
        html = render_companies_country_html(companies=[], country=None)
        assert "unavailable" in html.lower()

    def test_none_payload(self):
        html = render_companies_country_html(companies=None, country="us")
        assert "unavailable" in html.lower()

    def test_empty_list_zero_state(self):
        html = render_companies_country_html(companies=[], country="us")
        assert "No United States companies yet" in html

    def test_non_list_payload(self):
        # Falls through to empty-list behavior with zero_state card
        html = render_companies_country_html(companies="nope", country="us")
        assert "No United States companies yet" in html

    def test_non_dict_entries_filtered(self):
        companies = [{"name": "A"}, "nope", None, 42]
        html = render_companies_country_html(companies=companies, country="us")
        assert "A" in html

    def test_sort_by_industry_then_employee_count_desc(self):
        """LOCK: sort is (industry ASC, employee_count DESC, name ASC).
        Cluster by industry within a country pane; biggest first
        within each industry.
        """
        companies = [
            {"name": "SaasSmall", "industry": "saas", "employee_count": 10},
            {"name": "SaasBig", "industry": "saas", "employee_count": 10000},
            {"name": "FintechMid", "industry": "fintech", "employee_count": 500},
            {"name": "FintechTiny", "industry": "fintech", "employee_count": 5},
        ]
        html = render_companies_country_html(companies=companies, country="us")
        # fintech < saas alphabetically, so FintechMid > FintechTiny > SaasBig > SaasSmall
        fintech_mid_pos = html.find("FintechMid")
        fintech_tiny_pos = html.find("FintechTiny")
        saas_big_pos = html.find("SaasBig")
        saas_small_pos = html.find("SaasSmall")
        assert fintech_mid_pos < fintech_tiny_pos < saas_big_pos < saas_small_pos

    def test_alias_routed(self):
        html = render_companies_country_html(
            companies=[{"name": "X"}], country="USA",
        )
        assert "United States" in html

    def test_xss_escaped_in_render(self):
        companies = [{"name": "<script>", "industry": "<x>"}]
        html = render_companies_country_html(companies=companies, country="us")
        assert "<script>" not in html
        assert "<x>" not in html

    def test_overflow_banner_appears(self):
        companies = [{"name": f"Co{i}", "industry": "saas"} for i in range(120)]
        html = render_companies_country_html(companies=companies, country="us")
        assert "20 more" in html

    def test_cross_axis_link_in_html(self):
        """LOCK: cross-axis link to /industry/saas appears in full render."""
        html = render_companies_country_html(
            companies=[{"name": "X"}], country="us",
        )
        assert "g8://companies/industry/saas" in html

    def test_cross_entity_link_in_html(self):
        """LOCK: cross-entity link to /contacts/dashboard appears."""
        html = render_companies_country_html(
            companies=[{"name": "X"}], country="us",
        )
        assert "g8://contacts/dashboard" in html


# ---------------------------------------------------------------------------
# Design tokens
# ---------------------------------------------------------------------------
class TestDesignTokens:
    @pytest.mark.parametrize(
        "hex_code", ["#1d4ed8", "#166534", "#991b1b", "#0891b2"],
    )
    def test_no_banned_hex(self, hex_code):
        html = render_companies_country_html(
            companies=[{"name": "X", "industry": "saas"}], country="us",
        )
        assert hex_code not in html

    @pytest.mark.parametrize(
        "token", ["#7d2df3", "#dfdfdf", "#f2eafe", "#f9f9f9"],
    )
    def test_graph8_token_present(self, token):
        html = render_companies_country_html(
            companies=[{"name": "X", "industry": "saas"}], country="us",
        )
        assert token in html

    def test_aeonik_font(self):
        html = render_companies_country_html(
            companies=[{"name": "X"}], country="us",
        )
        assert "Aeonik" in html


# ---------------------------------------------------------------------------
# No inline JS
# ---------------------------------------------------------------------------
class TestNoJs:
    def test_no_script_tag(self):
        html = render_companies_country_html(
            companies=[{"name": "<script>alert(1)</script>"}], country="us",
        )
        assert "<script" not in html.lower()

    def test_no_event_handlers(self):
        html = render_companies_country_html(
            companies=[{"name": "A"}], country="united_states",
        )
        for attr in ("onclick=", "onerror=", "onload=", "onmouseover="):
            assert attr not in html.lower()


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------
class TestTextFallback:
    def test_invalid_country(self):
        txt = render_companies_country_text_fallback(
            companies=[], country="bogus",
        )
        assert "unavailable" in txt.lower()

    def test_none_payload(self):
        txt = render_companies_country_text_fallback(
            companies=None, country="us",
        )
        assert "unavailable" in txt.lower()

    def test_empty_list(self):
        txt = render_companies_country_text_fallback(
            companies=[], country="us",
        )
        assert "United States" in txt
        assert "No United States companies yet" in txt

    def test_happy_path(self):
        companies = [{"name": "AlphaCo", "industry": "saas", "employee_count": 100}]
        txt = render_companies_country_text_fallback(
            companies=companies, country="us",
        )
        assert "# Companies — United States" in txt
        assert "AlphaCo" in txt

    def test_stats_section(self):
        txt = render_companies_country_text_fallback(
            companies=[{"name": "A", "industry": "saas", "linkedin_url": "x"}],
            country="us",
        )
        assert "## Stats" in txt
        assert "Unique industries" in txt
        assert "With LinkedIn" in txt

    def test_overflow_note(self):
        companies = [{"name": f"Co{i}", "industry": "saas"} for i in range(120)]
        txt = render_companies_country_text_fallback(
            companies=companies, country="us",
        )
        assert "+ 20 more" in txt

    def test_unnamed_fallback(self):
        txt = render_companies_country_text_fallback(
            companies=[{}], country="us",
        )
        assert "(unnamed company)" in txt

    def test_backend_filter_uses_title_case(self):
        """Text fallback must reference the TITLE-CASE backend value, not
        the URI slug."""
        txt = render_companies_country_text_fallback(
            companies=[{"name": "X"}], country="us",
        )
        assert "GET /companies?country=United States" in txt

    def test_cross_axis_link_in_text(self):
        """LOCK: cross-axis link to /industry/saas appears in text."""
        txt = render_companies_country_text_fallback(
            companies=[{"name": "X"}], country="us",
        )
        assert "g8://companies/industry/saas" in txt

    def test_cross_entity_link_in_text(self):
        """LOCK: cross-entity link to /contacts/dashboard appears."""
        txt = render_companies_country_text_fallback(
            companies=[{"name": "X"}], country="us",
        )
        assert "g8://contacts/dashboard" in txt


# ---------------------------------------------------------------------------
# Smoke — every canonical + alias renders without error
# ---------------------------------------------------------------------------
class TestSmoke:
    @pytest.mark.parametrize("key", _COMPANIES_COUNTRY_VALID)
    def test_canonical_html_without_error(self, key):
        html = render_companies_country_html(
            companies=[{"name": "X"}], country=key,
        )
        assert isinstance(html, str)
        assert len(html) > 100

    @pytest.mark.parametrize("key", _COMPANIES_COUNTRY_VALID)
    def test_canonical_text_without_error(self, key):
        txt = render_companies_country_text_fallback(
            companies=[{"name": "X"}], country=key,
        )
        assert isinstance(txt, str)
        assert len(txt) > 20

    @pytest.mark.parametrize("alias", list(_COMPANIES_COUNTRY_ALIASES.keys()))
    def test_alias_html_without_error(self, alias):
        html = render_companies_country_html(
            companies=[{"name": "X"}], country=alias,
        )
        assert isinstance(html, str)

    @pytest.mark.parametrize("alias", list(_COMPANIES_COUNTRY_ALIASES.keys()))
    def test_alias_text_without_error(self, alias):
        txt = render_companies_country_text_fallback(
            companies=[{"name": "X"}], country=alias,
        )
        assert isinstance(txt, str)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
class TestConstants:
    def test_valid_is_tuple(self):
        assert isinstance(_COMPANIES_COUNTRY_VALID, tuple)
        assert len(_COMPANIES_COUNTRY_VALID) == 20

    def test_labels_complete(self):
        for key in _COMPANIES_COUNTRY_VALID:
            assert key in _COMPANIES_COUNTRY_LABELS

    def test_backend_values_complete(self):
        for key in _COMPANIES_COUNTRY_VALID:
            assert key in _COMPANIES_COUNTRY_BACKEND_VALUE

    def test_aliases_target_valid(self):
        for alias, canonical in _COMPANIES_COUNTRY_ALIASES.items():
            assert canonical in _COMPANIES_COUNTRY_VALID

    def test_no_alias_equals_canonical(self):
        for alias in _COMPANIES_COUNTRY_ALIASES:
            assert alias not in _COMPANIES_COUNTRY_VALID

    def test_aliases_has_100_plus(self):
        assert len(_COMPANIES_COUNTRY_ALIASES) >= 100

    def test_no_alias_collides_with_nested_literals(self):
        """Locks that no alias matches a sibling nested literal."""
        forbidden = {"notes", "deals", "contacts", "activities", "dashboard", "industry"}
        for alias in _COMPANIES_COUNTRY_ALIASES:
            assert alias.lower() not in forbidden

    def test_no_canonical_collides_with_nested_literals(self):
        forbidden = {"notes", "deals", "contacts", "activities", "dashboard", "industry"}
        for key in _COMPANIES_COUNTRY_VALID:
            assert key.lower() not in forbidden
