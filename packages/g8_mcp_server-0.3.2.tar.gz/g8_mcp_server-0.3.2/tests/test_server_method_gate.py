"""Regression tests for the MCP ASGI middleware HTTP method gate.

The middleware in ``_RemoteMCPApp.__call__`` rejects unknown HTTP methods
with 405 *before* the request reaches the MCP SDK. The accepted set is:

- POST    — JSON-RPC requests/responses
- DELETE  — explicit session termination
- OPTIONS — CORS preflight (handled directly, no auth)
- GET     — Server-Sent Events notification stream (per MCP spec
            2025-03-26). ChatGPT custom MCP connectors require this;
            claude.ai does not open it (which is why a previous 405
            went unnoticed for months).

These tests lock in:
  1. POST is forwarded to the SDK handler (smoke).
  2. GET is forwarded to the SDK handler (no 405) and the body buffer
     is *not* read — SSE streams have no body, and reading would block.
  3. PUT (and other unsupported methods) still produce 405 with the
     correct ``Allow`` header.
  4. CORS preflight (OPTIONS) is handled directly, never reaches the SDK.
"""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from g8_mcp_server import server as srv


# ---------------------------------------------------------------------------
# Helpers: build an ASGI scope/receive/send harness without booting the SDK
# ---------------------------------------------------------------------------

def _http_scope(method: str, path: str = "/", headers: list[tuple[bytes, bytes]] | None = None):
    return {
        "type": "http",
        "asgi": {"version": "3.0"},
        "http_version": "1.1",
        "method": method,
        "scheme": "https",
        "path": path,
        "raw_path": path.encode(),
        "query_string": b"",
        "headers": headers or [],
        "server": ("be.graph8.com", 443),
        "client": ("127.0.0.1", 12345),
    }


class _ReceiveSpy:
    """Records calls to receive() so tests can assert it was/wasn't invoked."""

    def __init__(self, body: bytes = b""):
        self._body = body
        self._sent = False
        self.call_count = 0

    async def __call__(self):
        self.call_count += 1
        if not self._sent:
            self._sent = True
            return {"type": "http.request", "body": self._body, "more_body": False}
        # Block forever if called again — mimics SSE waiting for disconnect.
        # Tests should never get here for the GET fast-path.
        return {"type": "http.disconnect"}


class _SendCapture:
    def __init__(self):
        self.messages: list[dict] = []

    async def __call__(self, message):
        self.messages.append(message)

    @property
    def status(self) -> int | None:
        for m in self.messages:
            if m.get("type") == "http.response.start":
                return m.get("status")
        return None

    @property
    def headers(self) -> list[tuple[bytes, bytes]]:
        for m in self.messages:
            if m.get("type") == "http.response.start":
                return list(m.get("headers", []))
        return []


def _bearer_headers(token: str = "test_api_key_short") -> list[tuple[bytes, bytes]]:
    return [(b"authorization", f"Bearer {token}".encode())]


@pytest.fixture
def mcp_app(monkeypatch):
    """A `_RemoteMCPApp` whose handler/session-manager are mocked.

    - ``handler`` is an AsyncMock standing in for the SDK ASGI app.
    - The session manager is pre-marked `_started=True`, so
      `_ensure_started` is a no-op and we never spin up the real SDK.
    - Rate limiter is short-circuited to "always allow".
    - Introspection is disabled so short tokens take the API-key path.
    """
    handler = AsyncMock()
    session_manager = object()  # never used because _started=True
    app = srv._RemoteMCPApp(handler, session_manager)  # type: ignore[arg-type]
    app._started = True  # bypass lazy startup

    monkeypatch.setattr(srv, "_check_mcp_rate_limit", AsyncMock(return_value=(True, 0)))
    monkeypatch.setattr(srv, "_INTROSPECT_CLIENT_ID", "")  # forces API-key-direct path
    return app, handler


# ---------------------------------------------------------------------------
# 1. PUT (and friends) → 405
# ---------------------------------------------------------------------------

class TestUnsupportedMethodsReturn405:
    @pytest.mark.asyncio
    @pytest.mark.parametrize("method", ["PUT", "PATCH", "HEAD", "TRACE"])
    async def test_unsupported_method_returns_405(self, mcp_app, method):
        app, handler = mcp_app
        send = _SendCapture()
        await app(_http_scope(method, headers=_bearer_headers()), _ReceiveSpy(), send)

        assert send.status == 405
        # The Allow header must advertise the full supported set, including GET.
        allow_value = next(
            (v for k, v in send.headers if k.lower() == b"allow"),
            None,
        )
        assert allow_value is not None
        allow_set = {m.strip() for m in allow_value.decode().split(",")}
        assert allow_set == {"GET", "POST", "DELETE", "OPTIONS"}

        # Handler must NOT be invoked for rejected methods.
        handler.assert_not_called()


# ---------------------------------------------------------------------------
# 2. GET → forwarded to handler, body never buffered
# ---------------------------------------------------------------------------

class TestGetIsForwardedAsSseStream:
    @pytest.mark.asyncio
    async def test_get_reaches_handler_no_405(self, mcp_app):
        """GET /mcp/ must pass through to the SDK so it can return an SSE
        stream. Regression for ChatGPT custom MCP connector failure where
        graph8 returned 405 before the SDK saw the request."""
        app, handler = mcp_app

        async def handler_impl(scope, receive, send):
            # Mimic SDK SSE response start; tests don't need the full stream.
            await send({
                "type": "http.response.start",
                "status": 200,
                "headers": [(b"content-type", b"text/event-stream")],
            })

        handler.side_effect = handler_impl

        receive = _ReceiveSpy()
        send = _SendCapture()
        await app(_http_scope("GET", headers=_bearer_headers()), receive, send)

        # Handler was invoked exactly once.
        assert handler.await_count == 1
        # No 405 anywhere.
        assert send.status == 200
        # And the body-buffering loop was bypassed: the middleware must
        # NOT call receive() before delegating to the SDK. SSE has no
        # request body and reading would block the long-lived stream.
        assert receive.call_count == 0, (
            "GET fast-path must forward `receive` directly to the SDK "
            "without buffering the request body"
        )

    @pytest.mark.asyncio
    async def test_get_without_bearer_returns_401(self, mcp_app):
        """GET still requires auth — opening an SSE stream without a key
        must not bypass the bearer check."""
        app, handler = mcp_app
        send = _SendCapture()
        await app(_http_scope("GET"), _ReceiveSpy(), send)

        assert send.status == 401
        handler.assert_not_called()


# ---------------------------------------------------------------------------
# 3. POST still forwarded (smoke)
# ---------------------------------------------------------------------------

class TestPostStillForwarded:
    @pytest.mark.asyncio
    async def test_post_initialize_reaches_handler(self, mcp_app):
        app, handler = mcp_app

        async def handler_impl(scope, receive, send):
            # Drain the replayed body once to mimic the SDK reading the JSON-RPC.
            await receive()
            await send({
                "type": "http.response.start",
                "status": 200,
                "headers": [(b"content-type", b"application/json")],
            })
            await send({"type": "http.response.body", "body": b'{"jsonrpc":"2.0","id":1,"result":{}}'})

        handler.side_effect = handler_impl

        body = b'{"jsonrpc":"2.0","id":1,"method":"initialize","params":{}}'
        send = _SendCapture()
        await app(_http_scope("POST", headers=_bearer_headers()), _ReceiveSpy(body), send)

        assert handler.await_count == 1
        assert send.status == 200


# ---------------------------------------------------------------------------
# 4. OPTIONS preflight handled directly
# ---------------------------------------------------------------------------

class TestOptionsPreflight:
    @pytest.mark.asyncio
    async def test_options_returns_204_without_auth(self, mcp_app):
        app, handler = mcp_app
        send = _SendCapture()
        # No Authorization header — preflight must still succeed.
        headers = [(b"origin", b"https://chatgpt.com")]
        await app(_http_scope("OPTIONS", headers=headers), _ReceiveSpy(), send)

        assert send.status == 204
        # Allow methods header includes GET so browsers won't block the SSE upgrade.
        allow_methods = next(
            (v for k, v in send.headers if k.lower() == b"access-control-allow-methods"),
            None,
        )
        assert allow_methods is not None
        assert b"GET" in allow_methods
        handler.assert_not_called()
