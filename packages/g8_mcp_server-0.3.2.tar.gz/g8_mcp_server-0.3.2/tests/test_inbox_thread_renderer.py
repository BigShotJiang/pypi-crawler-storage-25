"""Unit tests for the inbox thread detail HTML renderer (upgrade 4 surface #20).

The renderer takes the raw /inbox/{reply_id} payload and produces a single-
conversation view. These tests cover:
- empty / missing thread → empty state
- header fields (subject, channel, status, contact, tags, assignees)
- message direction styling (inbound vs outbound vs unknown)
- message body truncation and HTML escaping
- per-message subject rendered only when it diverges from the thread
- timestamp handling (sent_at preferred, received_at fallback)
- counts line (total / inbound / outbound)
- cap + overflow footer
- plain-text fallback shape
"""

from __future__ import annotations

import pytest

from g8_mcp_server.app_renderer import (
    _format_contact_line,
    _inbox_thread_channel_palette,
    _inbox_thread_status_palette,
    _MAX_INBOX_MESSAGES_RENDERED,
    _MAX_INBOX_MESSAGE_BODY_LEN,
    _message_direction_label,
    render_inbox_thread_detail_html,
    render_inbox_thread_detail_text_fallback,
)


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------


class TestMessageDirectionLabel:
    @pytest.mark.parametrize(
        "raw,expected",
        [
            ("inbound", "inbound"),
            ("in", "inbound"),
            ("received", "inbound"),
            ("incoming", "inbound"),
            ("Inbound", "inbound"),
            ("  INBOUND  ", "inbound"),
            ("outbound", "outbound"),
            ("out", "outbound"),
            ("sent", "outbound"),
            ("outgoing", "outbound"),
            ("Outbound", "outbound"),
            ("", ""),
            (None, ""),
            ("weird", ""),
            ("unknown", ""),
        ],
    )
    def test_normalizes_direction(self, raw, expected):
        assert _message_direction_label(raw) == expected


class TestInboxThreadChannelPalette:
    def test_known_channels_resolve(self):
        for key in ("email", "sms", "whatsapp", "linkedin", "slack"):
            pal = _inbox_thread_channel_palette(key)
            assert "bg" in pal and "fg" in pal and "border" in pal

    def test_case_insensitive(self):
        assert _inbox_thread_channel_palette("EMAIL") == _inbox_thread_channel_palette("email")

    def test_unknown_falls_back_to_default_palette(self):
        default = _inbox_thread_channel_palette("nonexistent")
        assert default["bg"] == "#f9f9f9"
        assert default["fg"] == "#777777"

    def test_none_is_default(self):
        default = _inbox_thread_channel_palette(None)
        assert default["bg"] == "#f9f9f9"

    def test_no_banned_hexes_in_channel_palette(self):
        """Lock test — no banned Studio hex reintroduced into thread channel palette."""
        from g8_mcp_server.app_renderer import _INBOX_THREAD_CHANNEL_PALETTES

        banned = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}
        for _channel, pal in _INBOX_THREAD_CHANNEL_PALETTES.items():
            for _field, value in pal.items():
                assert value.lower() not in banned, (
                    f"banned Studio hex {value} resurfaced in thread channel palette"
                )


class TestInboxThreadStatusPalette:
    @pytest.mark.parametrize(
        "status",
        ["open", "new", "pending", "in_progress", "replied", "closed",
         "resolved", "archived", "spam"],
    )
    def test_known_status_resolves(self, status):
        pal = _inbox_thread_status_palette(status)
        assert "bg" in pal and "fg" in pal

    def test_unknown_falls_back(self):
        pal = _inbox_thread_status_palette("purgatory")
        assert pal["bg"] == "#f9f9f9"

    def test_no_banned_hexes_in_status_palette(self):
        """Lock test — no banned Studio hex reintroduced into thread status palette."""
        from g8_mcp_server.app_renderer import _INBOX_THREAD_STATUS_PALETTES

        banned = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}
        for _status, pal in _INBOX_THREAD_STATUS_PALETTES.items():
            for _channel, value in pal.items():
                assert value.lower() not in banned, (
                    f"banned Studio hex {value} resurfaced in thread status palette"
                )


class TestFormatContactLine:
    def test_first_and_last_name_combine(self):
        name, email = _format_contact_line({"first_name": "Ada", "last_name": "Lovelace"})
        assert name == "Ada Lovelace"
        assert email == ""

    def test_only_first_name(self):
        name, _ = _format_contact_line({"first_name": "Ada"})
        assert name == "Ada"

    def test_only_last_name(self):
        name, _ = _format_contact_line({"last_name": "Lovelace"})
        assert name == "Lovelace"

    def test_falls_back_to_name_field(self):
        name, _ = _format_contact_line({"name": "Ada L."})
        assert name == "Ada L."

    def test_email_only_becomes_display_name(self):
        name, email = _format_contact_line({"email": "ada@example.com"})
        assert name == "ada@example.com"
        assert email == "ada@example.com"

    def test_empty_dict(self):
        assert _format_contact_line({}) == ("", "")

    def test_none_input(self):
        assert _format_contact_line(None) == ("", "")

    def test_non_dict_input(self):
        assert _format_contact_line("not a dict") == ("", "")


# ---------------------------------------------------------------------------
# HTML renderer
# ---------------------------------------------------------------------------


class TestRenderInboxThreadDetailHtml:
    def test_empty_state_on_none(self):
        html_out = render_inbox_thread_detail_html(
            thread=None, reply_id="reply-abc", channel="email"
        )
        assert "Inbox thread not found" in html_out
        assert "reply-abc" in html_out
        assert "<!DOCTYPE html>" in html_out

    def test_empty_state_on_empty_dict(self):
        html_out = render_inbox_thread_detail_html(
            thread={}, reply_id="reply-abc", channel="email"
        )
        assert "Inbox thread not found" in html_out

    def test_empty_state_includes_channel(self):
        html_out = render_inbox_thread_detail_html(
            thread=None, reply_id="r1", channel="sms"
        )
        assert "sms" in html_out

    def test_empty_state_default_channel_is_email(self):
        html_out = render_inbox_thread_detail_html(
            thread=None, reply_id="r1", channel=None
        )
        assert "email" in html_out

    def test_non_dict_thread_triggers_empty_state(self):
        html_out = render_inbox_thread_detail_html(
            thread="not a dict",  # type: ignore[arg-type]
            reply_id="r1",
        )
        assert "Inbox thread not found" in html_out

    def test_basic_thread_renders_subject(self):
        thread = {
            "subject": "Quarterly review ping",
            "channel": "email",
            "status": "open",
            "messages": [],
        }
        html_out = render_inbox_thread_detail_html(
            thread=thread, reply_id="r1"
        )
        assert "Quarterly review ping" in html_out
        assert "r1" in html_out

    def test_subject_html_escaped(self):
        thread = {"subject": "Re: <script>alert(1)</script>", "messages": []}
        html_out = render_inbox_thread_detail_html(
            thread=thread, reply_id="r1"
        )
        assert "<script>" not in html_out
        assert "&lt;script&gt;" in html_out

    def test_no_subject_fallback(self):
        thread = {"messages": []}
        html_out = render_inbox_thread_detail_html(
            thread=thread, reply_id="r1"
        )
        assert "(no subject)" in html_out

    def test_channel_chip_rendered(self):
        thread = {"subject": "x", "channel": "whatsapp", "messages": []}
        html_out = render_inbox_thread_detail_html(
            thread=thread, reply_id="r1"
        )
        assert "whatsapp" in html_out
        assert "ibx-channel" in html_out

    def test_status_chip_rendered(self):
        thread = {"subject": "x", "status": "replied", "messages": []}
        html_out = render_inbox_thread_detail_html(
            thread=thread, reply_id="r1"
        )
        assert "replied" in html_out
        assert "ibx-status" in html_out

    def test_contact_block_rendered(self):
        thread = {
            "subject": "x",
            "contact": {
                "first_name": "Ada",
                "last_name": "Lovelace",
                "email": "ada@example.com",
            },
            "messages": [],
        }
        html_out = render_inbox_thread_detail_html(thread=thread, reply_id="r1")
        assert "Ada Lovelace" in html_out
        assert "ada@example.com" in html_out

    def test_contact_email_only(self):
        thread = {
            "subject": "x",
            "contact": {"email": "anon@example.com"},
            "messages": [],
        }
        html_out = render_inbox_thread_detail_html(thread=thread, reply_id="r1")
        assert "anon@example.com" in html_out

    def test_contact_escaped(self):
        thread = {
            "subject": "x",
            "contact": {"name": "<b>Evil</b>"},
            "messages": [],
        }
        html_out = render_inbox_thread_detail_html(thread=thread, reply_id="r1")
        assert "<b>Evil</b>" not in html_out
        assert "&lt;b&gt;Evil&lt;/b&gt;" in html_out

    def test_tags_rendered(self):
        thread = {
            "subject": "x",
            "tags": [{"name": "hot-lead"}, {"label": "follow-up"}, "urgent"],
            "messages": [],
        }
        html_out = render_inbox_thread_detail_html(thread=thread, reply_id="r1")
        assert "hot-lead" in html_out
        assert "follow-up" in html_out
        assert "urgent" in html_out
        assert html_out.count('class="ibx-tag"') == 3

    def test_tags_escaped(self):
        thread = {
            "subject": "x",
            "tags": [{"name": "<script>"}],
            "messages": [],
        }
        html_out = render_inbox_thread_detail_html(thread=thread, reply_id="r1")
        assert "<script>" not in html_out
        assert "&lt;script&gt;" in html_out

    def test_tags_capped(self):
        thread = {
            "subject": "x",
            "tags": [{"name": f"tag-{i}"} for i in range(20)],
            "messages": [],
        }
        html_out = render_inbox_thread_detail_html(thread=thread, reply_id="r1")
        # Only first 10 rendered
        assert "tag-0" in html_out
        assert "tag-9" in html_out
        assert "tag-10" not in html_out

    def test_assignees_rendered(self):
        thread = {
            "subject": "x",
            "assignees": [
                {"name": "Grace Hopper", "email": "grace@example.com"},
                {"email": "admiral@example.com"},
            ],
            "messages": [],
        }
        html_out = render_inbox_thread_detail_html(thread=thread, reply_id="r1")
        assert "Grace Hopper" in html_out
        assert "admiral@example.com" in html_out
        assert "Assigned:" in html_out

    def test_assignees_capped(self):
        thread = {
            "subject": "x",
            "assignees": [{"name": f"user-{i}"} for i in range(10)],
            "messages": [],
        }
        html_out = render_inbox_thread_detail_html(thread=thread, reply_id="r1")
        assert "user-0" in html_out
        assert "user-5" in html_out
        # cap is 6 → user-6 etc not rendered
        assert "user-7" not in html_out

    def test_message_direction_classes(self):
        thread = {
            "subject": "x",
            "messages": [
                {"direction": "inbound", "sender": "a@b.c", "body": "hi"},
                {"direction": "outbound", "sender": "rep@org", "body": "hello"},
                {"direction": "", "sender": "??", "body": "mystery"},
            ],
        }
        html_out = render_inbox_thread_detail_html(thread=thread, reply_id="r1")
        assert "ibx-msg-inbound" in html_out
        assert "ibx-msg-outbound" in html_out
        assert "ibx-msg-unknown" in html_out

    def test_message_direction_aliases(self):
        thread = {
            "subject": "x",
            "messages": [
                {"direction": "received", "sender": "a@b.c", "body": "hi"},
                {"direction": "sent", "sender": "rep@org", "body": "hello"},
            ],
        }
        html_out = render_inbox_thread_detail_html(thread=thread, reply_id="r1")
        assert "ibx-msg-inbound" in html_out
        assert "ibx-msg-outbound" in html_out

    def test_message_body_html_escaped(self):
        thread = {
            "subject": "x",
            "messages": [
                {
                    "direction": "inbound",
                    "sender": "a@b.c",
                    "body": "<script>alert(1)</script>",
                }
            ],
        }
        html_out = render_inbox_thread_detail_html(thread=thread, reply_id="r1")
        assert "<script>alert(1)</script>" not in html_out
        assert "&lt;script&gt;" in html_out

    def test_message_body_truncated(self):
        long_body = "x" * (_MAX_INBOX_MESSAGE_BODY_LEN + 500)
        thread = {
            "subject": "x",
            "messages": [
                {"direction": "inbound", "sender": "a@b.c", "body": long_body}
            ],
        }
        html_out = render_inbox_thread_detail_html(thread=thread, reply_id="r1")
        assert "…" in html_out
        # Truncated — shouldn't include the full 2500+ chars
        body_start = html_out.index('class="ibx-msg-body">') + len('class="ibx-msg-body">')
        body_end = html_out.index("</div>", body_start)
        rendered_body = html_out[body_start:body_end]
        assert len(rendered_body) <= _MAX_INBOX_MESSAGE_BODY_LEN + 10

    def test_per_message_subject_rendered_when_diverges(self):
        thread = {
            "subject": "Main thread",
            "messages": [
                {
                    "direction": "inbound",
                    "sender": "a@b.c",
                    "subject": "Re: something different",
                    "body": "hi",
                }
            ],
        }
        html_out = render_inbox_thread_detail_html(thread=thread, reply_id="r1")
        assert "Re: something different" in html_out
        assert 'class="ibx-msg-subject"' in html_out

    def test_per_message_subject_hidden_when_matches_thread(self):
        thread = {
            "subject": "Main thread",
            "messages": [
                {
                    "direction": "inbound",
                    "sender": "a@b.c",
                    "subject": "Main thread",
                    "body": "hi",
                }
            ],
        }
        html_out = render_inbox_thread_detail_html(thread=thread, reply_id="r1")
        assert 'class="ibx-msg-subject"' not in html_out

    def test_sent_at_timestamp_rendered(self):
        thread = {
            "subject": "x",
            "messages": [
                {
                    "direction": "outbound",
                    "sender": "rep",
                    "body": "hi",
                    "sent_at": "2026-04-20T10:00:00Z",
                }
            ],
        }
        html_out = render_inbox_thread_detail_html(thread=thread, reply_id="r1")
        assert "2026-04-20T10:00:00Z" in html_out

    def test_received_at_fallback(self):
        thread = {
            "subject": "x",
            "messages": [
                {
                    "direction": "inbound",
                    "sender": "a@b.c",
                    "body": "hi",
                    "received_at": "2026-04-20T11:00:00Z",
                }
            ],
        }
        html_out = render_inbox_thread_detail_html(thread=thread, reply_id="r1")
        assert "2026-04-20T11:00:00Z" in html_out

    def test_recipient_rendered_when_present(self):
        thread = {
            "subject": "x",
            "messages": [
                {
                    "direction": "outbound",
                    "sender": "rep@org",
                    "recipient": "lead@customer.co",
                    "body": "hi",
                }
            ],
        }
        html_out = render_inbox_thread_detail_html(thread=thread, reply_id="r1")
        assert "lead@customer.co" in html_out

    def test_counts_line_rendered(self):
        thread = {
            "subject": "x",
            "messages": [
                {"direction": "inbound", "sender": "a", "body": "1"},
                {"direction": "inbound", "sender": "a", "body": "2"},
                {"direction": "outbound", "sender": "b", "body": "3"},
            ],
        }
        html_out = render_inbox_thread_detail_html(thread=thread, reply_id="r1")
        assert "3 message(s)" in html_out
        assert "2 inbound" in html_out
        assert "1 outbound" in html_out

    def test_zero_messages_shows_empty_state(self):
        thread = {"subject": "x", "messages": []}
        html_out = render_inbox_thread_detail_html(thread=thread, reply_id="r1")
        assert "No messages in this thread yet" in html_out

    def test_message_cap_and_overflow_footer(self):
        msgs = [
            {"direction": "inbound", "sender": f"s{i}", "body": f"b{i}"}
            for i in range(_MAX_INBOX_MESSAGES_RENDERED + 15)
        ]
        thread = {"subject": "x", "messages": msgs}
        html_out = render_inbox_thread_detail_html(thread=thread, reply_id="r1")
        assert "15 message(s) omitted" in html_out
        # First-100 present, 115th not
        assert "b0" in html_out
        assert "b99" in html_out

    def test_non_list_tags_ignored(self):
        thread = {"subject": "x", "tags": "not-a-list", "messages": []}
        html_out = render_inbox_thread_detail_html(thread=thread, reply_id="r1")
        # Does not crash; no tag chips rendered
        assert 'class="ibx-tag"' not in html_out

    def test_non_list_messages_ignored(self):
        thread = {"subject": "x", "messages": "weird"}
        html_out = render_inbox_thread_detail_html(thread=thread, reply_id="r1")
        assert "No messages in this thread yet" in html_out

    def test_reply_id_escaped(self):
        html_out = render_inbox_thread_detail_html(
            thread={"subject": "x", "messages": []},
            reply_id="<script>",
        )
        assert "<script>" not in html_out
        assert "&lt;script&gt;" in html_out

    def test_non_dict_message_entry_skipped(self):
        thread = {
            "subject": "x",
            "messages": [
                "not a dict",
                {"direction": "inbound", "sender": "a", "body": "hi"},
                None,
            ],
        }
        html_out = render_inbox_thread_detail_html(thread=thread, reply_id="r1")
        # Only the valid dict entry rendered
        assert html_out.count('class="ibx-msg ') == 1


# ---------------------------------------------------------------------------
# Plain-text fallback
# ---------------------------------------------------------------------------


class TestRenderInboxThreadDetailTextFallback:
    def test_empty_state_on_none(self):
        out = render_inbox_thread_detail_text_fallback(
            thread=None, reply_id="r1", channel="email"
        )
        assert "Inbox thread not found" in out
        assert "r1" in out
        assert "g8://inbox/dashboard" in out

    def test_empty_state_on_empty_dict(self):
        out = render_inbox_thread_detail_text_fallback(
            thread={}, reply_id="r1", channel="email"
        )
        assert "Inbox thread not found" in out

    def test_header_fields_rendered(self):
        thread = {
            "subject": "Quarterly ping",
            "channel": "email",
            "status": "open",
            "messages": [],
        }
        out = render_inbox_thread_detail_text_fallback(
            thread=thread, reply_id="r1"
        )
        assert "Inbox thread: Quarterly ping" in out
        assert "Thread ID: r1" in out
        assert "Channel: email" in out
        assert "Status: open" in out

    def test_contact_line_with_email(self):
        thread = {
            "subject": "x",
            "contact": {"name": "Ada", "email": "ada@example.com"},
            "messages": [],
        }
        out = render_inbox_thread_detail_text_fallback(
            thread=thread, reply_id="r1"
        )
        assert "Contact: Ada <ada@example.com>" in out

    def test_contact_line_without_email(self):
        thread = {
            "subject": "x",
            "contact": {"name": "Ada"},
            "messages": [],
        }
        out = render_inbox_thread_detail_text_fallback(
            thread=thread, reply_id="r1"
        )
        assert "Contact: Ada" in out
        assert "<" not in out.split("Contact:")[1].split("\n")[0]

    def test_tags_line(self):
        thread = {
            "subject": "x",
            "tags": [{"name": "hot"}, "urgent"],
            "messages": [],
        }
        out = render_inbox_thread_detail_text_fallback(
            thread=thread, reply_id="r1"
        )
        assert "Tags: hot, urgent" in out

    def test_assignees_line(self):
        thread = {
            "subject": "x",
            "assignees": [{"name": "Grace"}, {"email": "admiral@x.co"}],
            "messages": [],
        }
        out = render_inbox_thread_detail_text_fallback(
            thread=thread, reply_id="r1"
        )
        assert "Assigned: Grace, admiral@x.co" in out

    def test_messages_count_line(self):
        thread = {
            "subject": "x",
            "messages": [
                {"direction": "inbound", "sender": "a", "body": "1"},
                {"direction": "outbound", "sender": "b", "body": "2"},
            ],
        }
        out = render_inbox_thread_detail_text_fallback(
            thread=thread, reply_id="r1"
        )
        assert "Messages: 2 (1 inbound / 1 outbound)" in out

    def test_message_delimiter_and_direction_marker(self):
        thread = {
            "subject": "x",
            "messages": [
                {"direction": "inbound", "sender": "a@b.c", "body": "hi"}
            ],
        }
        out = render_inbox_thread_detail_text_fallback(
            thread=thread, reply_id="r1"
        )
        assert "---" in out
        assert "[inbound]" in out
        assert "a@b.c" in out
        assert "hi" in out

    def test_recipient_arrow_included(self):
        thread = {
            "subject": "x",
            "messages": [
                {
                    "direction": "outbound",
                    "sender": "rep@org",
                    "recipient": "lead@co",
                    "body": "hey",
                }
            ],
        }
        out = render_inbox_thread_detail_text_fallback(
            thread=thread, reply_id="r1"
        )
        assert "-> lead@co" in out

    def test_timestamp_line(self):
        thread = {
            "subject": "x",
            "messages": [
                {
                    "direction": "inbound",
                    "sender": "a",
                    "body": "hi",
                    "sent_at": "2026-04-20T10:00:00Z",
                }
            ],
        }
        out = render_inbox_thread_detail_text_fallback(
            thread=thread, reply_id="r1"
        )
        assert "@ 2026-04-20T10:00:00Z" in out

    def test_per_message_subject_only_when_diverges(self):
        thread = {
            "subject": "Main",
            "messages": [
                {
                    "direction": "inbound",
                    "sender": "a",
                    "subject": "Different",
                    "body": "hi",
                },
                {
                    "direction": "outbound",
                    "sender": "b",
                    "subject": "Main",
                    "body": "bye",
                },
            ],
        }
        out = render_inbox_thread_detail_text_fallback(
            thread=thread, reply_id="r1"
        )
        assert "Subject: Different" in out
        assert "Subject: Main" not in out

    def test_body_truncated(self):
        long_body = "a" * (_MAX_INBOX_MESSAGE_BODY_LEN + 100)
        thread = {
            "subject": "x",
            "messages": [
                {"direction": "inbound", "sender": "a", "body": long_body}
            ],
        }
        out = render_inbox_thread_detail_text_fallback(
            thread=thread, reply_id="r1"
        )
        assert "…" in out

    def test_zero_messages_marker(self):
        thread = {"subject": "x", "messages": []}
        out = render_inbox_thread_detail_text_fallback(
            thread=thread, reply_id="r1"
        )
        assert "(no messages)" in out

    def test_overflow_footer(self):
        msgs = [
            {"direction": "inbound", "sender": f"s{i}", "body": f"b{i}"}
            for i in range(_MAX_INBOX_MESSAGES_RENDERED + 7)
        ]
        thread = {"subject": "x", "messages": msgs}
        out = render_inbox_thread_detail_text_fallback(
            thread=thread, reply_id="r1"
        )
        assert "and 7 more message(s)" in out

    def test_non_list_messages(self):
        thread = {"subject": "x", "messages": "nope"}
        out = render_inbox_thread_detail_text_fallback(
            thread=thread, reply_id="r1"
        )
        assert "(no messages)" in out
