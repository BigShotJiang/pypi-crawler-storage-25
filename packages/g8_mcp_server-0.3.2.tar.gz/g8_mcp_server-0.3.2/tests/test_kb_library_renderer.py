"""Unit tests for the KB library HTML renderer (upgrade 4 — app surface #4).

Same discipline as the earlier renderers:

- Every backend field is HTML-escaped (XSS safety)
- Caps on docs and sections so large libraries stay inside client limits
- Empty / None / malformed input produces an empty-state page, never raises
- Plaintext fallback mirrors the same truths
- Grouping by section works with missing / malformed section fields
"""

from __future__ import annotations

from html.parser import HTMLParser

import pytest

from g8_mcp_server.app_renderer import (
    _MAX_KB_DOCS_RENDERED,
    _MAX_KB_SECTIONS_RENDERED,
    _group_kb_by_section,
    render_kb_library_html,
    render_kb_library_text_fallback,
)


def _doc(idx: int = 0, section: str = "Strategy", **overrides) -> dict:
    base = {
        "doc_path": f"docs/strategy/doc_{idx}.md",
        "section": section,
        "title": f"Strategy doc {idx}",
        "chunks": 4 + idx,
        "last_updated": "2026-04-18",
    }
    base.update(overrides)
    return base


def _docs(n_per_section: int = 2, sections: list[str] | None = None) -> list[dict]:
    sections = sections or ["Strategy", "Messaging", "Operations"]
    out: list[dict] = []
    idx = 0
    for section in sections:
        for _ in range(n_per_section):
            out.append(_doc(idx=idx, section=section))
            idx += 1
    return out


class _TagCollector(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tags: list[str] = []

    def handle_starttag(self, tag, attrs):
        self.tags.append(tag)


# ---------------------------------------------------------------------------
# Grouping helper
# ---------------------------------------------------------------------------


class TestGroupKbBySection:
    def test_preserves_first_seen_order(self):
        docs = [
            _doc(idx=0, section="Strategy"),
            _doc(idx=1, section="Messaging"),
            _doc(idx=2, section="Strategy"),
            _doc(idx=3, section="Operations"),
        ]
        grouped = _group_kb_by_section(docs)
        section_names = [s for s, _ in grouped]
        assert section_names == ["Strategy", "Messaging", "Operations"]
        # Strategy should have 2 docs
        strategy_docs = next(d for s, d in grouped if s == "Strategy")
        assert len(strategy_docs) == 2

    def test_missing_section_becomes_uncategorized(self):
        docs = [_doc(idx=0), _doc(idx=1, section="")]
        docs[0].pop("section")
        grouped = _group_kb_by_section(docs)
        section_names = [s for s, _ in grouped]
        assert "Uncategorized" in section_names

    def test_non_string_section_becomes_uncategorized(self):
        doc = _doc(idx=0)
        doc["section"] = 42  # type: ignore[assignment]
        grouped = _group_kb_by_section([doc])
        section_names = [s for s, _ in grouped]
        assert section_names == ["Uncategorized"]

    def test_non_dict_doc_skipped(self):
        docs = [_doc(idx=0), "garbage", _doc(idx=1)]
        grouped = _group_kb_by_section(docs)  # type: ignore[arg-type]
        total = sum(len(d) for _, d in grouped)
        assert total == 2


# ---------------------------------------------------------------------------
# Happy path rendering
# ---------------------------------------------------------------------------


class TestRenderKbLibraryHtml:
    def test_returns_complete_html_document(self):
        result = render_kb_library_html(documents=_docs())
        assert result.startswith("<!doctype html>")
        assert "<html" in result and "</html>" in result.rstrip()
        assert "KB Library" in result

    def test_renders_each_section_header(self):
        result = render_kb_library_html(documents=_docs(n_per_section=2))
        assert "Strategy" in result
        assert "Messaging" in result
        assert "Operations" in result

    def test_renders_each_doc_title(self):
        result = render_kb_library_html(documents=_docs(n_per_section=2))
        for i in range(6):
            assert f"Strategy doc {i}" in result

    def test_renders_doc_paths(self):
        result = render_kb_library_html(documents=_docs(n_per_section=1))
        assert "docs/strategy/doc_0.md" in result

    def test_renders_chunk_counts(self):
        result = render_kb_library_html(documents=[_doc(idx=0, chunks=7)])
        assert "7 chunk(s)" in result

    def test_renders_last_updated(self):
        result = render_kb_library_html(documents=[_doc(idx=0, last_updated="2026-03-01")])
        assert "Updated 2026-03-01" in result

    def test_section_doc_counts_rendered(self):
        result = render_kb_library_html(documents=_docs(n_per_section=3))
        # Each section has 3 docs
        assert "3 doc(s)" in result

    def test_no_javascript_in_output(self):
        result = render_kb_library_html(documents=_docs())
        assert "<script" not in result.lower()
        assert "onerror" not in result.lower()
        assert "onload" not in result.lower()
        assert "javascript:" not in result.lower()

    def test_html_is_parseable(self):
        parser = _TagCollector()
        parser.feed(render_kb_library_html(documents=_docs()))
        assert "html" in parser.tags
        assert "body" in parser.tags
        assert "section" in parser.tags
        assert "ul" in parser.tags
        assert "li" in parser.tags

    def test_org_label_rendered(self):
        result = render_kb_library_html(documents=_docs(n_per_section=1), org_label="Acme Corp")
        assert "Acme Corp" in result


# ---------------------------------------------------------------------------
# XSS / escaping
# ---------------------------------------------------------------------------


class TestEscaping:
    def test_title_escaped(self):
        doc = _doc()
        doc["title"] = '<script>alert("xss")</script>'
        result = render_kb_library_html(documents=[doc])
        assert "<script>" not in result
        assert "&lt;script&gt;" in result

    def test_section_name_escaped(self):
        doc = _doc(section='<img src=x onerror="alert(1)">')
        result = render_kb_library_html(documents=[doc])
        assert "<img src=x" not in result
        assert "&lt;img" in result

    def test_doc_path_escaped(self):
        doc = _doc()
        doc["doc_path"] = '"><svg onload=alert(1)>'
        result = render_kb_library_html(documents=[doc])
        assert "<svg onload" not in result

    def test_last_updated_escaped(self):
        doc = _doc()
        doc["last_updated"] = '<b>today</b>'
        result = render_kb_library_html(documents=[doc])
        assert "<b>today</b>" not in result

    def test_org_label_escaped(self):
        result = render_kb_library_html(
            documents=_docs(n_per_section=1),
            org_label='<script>bad</script>',
        )
        assert "<script>bad</script>" not in result


# ---------------------------------------------------------------------------
# Caps, malformed input, empty state
# ---------------------------------------------------------------------------


class TestBounds:
    def test_doc_cap_enforced(self):
        big_library = [_doc(idx=i, section="Strategy") for i in range(_MAX_KB_DOCS_RENDERED + 10)]
        result = render_kb_library_html(documents=big_library)
        assert "doc(s) omitted" in result

    def test_section_cap_enforced(self):
        # Create enough distinct sections to trigger the section cap
        sections = [f"Section {i}" for i in range(_MAX_KB_SECTIONS_RENDERED + 5)]
        docs = [_doc(idx=i, section=sections[i]) for i in range(len(sections))]
        result = render_kb_library_html(documents=docs)
        assert "section(s) omitted" in result

    def test_none_renders_empty_state(self):
        result = render_kb_library_html(documents=None)
        assert "<!doctype html>" in result
        assert "library is empty" in result.lower()

    def test_empty_list_renders_empty_state(self):
        result = render_kb_library_html(documents=[])
        assert "library is empty" in result.lower()

    def test_non_list_input_renders_empty_state(self):
        result = render_kb_library_html(documents="not-a-list")  # type: ignore[arg-type]
        assert "library is empty" in result.lower()

    def test_non_dict_doc_skipped(self):
        mixed = [_doc(idx=0), "garbage", _doc(idx=1)]
        result = render_kb_library_html(documents=mixed)  # type: ignore[arg-type]
        # Should render both valid docs, skipping the string
        assert "Strategy doc 0" in result
        assert "Strategy doc 1" in result

    def test_missing_title_falls_back_to_path(self):
        doc = _doc()
        doc.pop("title")
        result = render_kb_library_html(documents=[doc])
        # Falls back to doc_path when title is absent
        assert "docs/strategy/doc_0.md" in result

    def test_missing_title_and_path_falls_back_to_untitled(self):
        doc = {"section": "Strategy"}
        result = render_kb_library_html(documents=[doc])
        assert "Untitled" in result


# ---------------------------------------------------------------------------
# Plaintext fallback
# ---------------------------------------------------------------------------


class TestKbLibraryTextFallback:
    def test_none_returns_empty_state(self):
        result = render_kb_library_text_fallback(documents=None)
        assert "Library is empty" in result

    def test_empty_list_returns_empty_state(self):
        result = render_kb_library_text_fallback(documents=[])
        assert "Library is empty" in result

    def test_renders_sections(self):
        result = render_kb_library_text_fallback(documents=_docs(n_per_section=2))
        assert "## Strategy" in result
        assert "## Messaging" in result
        assert "## Operations" in result

    def test_renders_doc_titles_and_paths(self):
        result = render_kb_library_text_fallback(documents=_docs(n_per_section=1))
        assert "Strategy doc 0" in result
        # Path rendered beneath the title
        assert "docs/strategy/doc_0.md" in result

    def test_plaintext_chunk_count(self):
        result = render_kb_library_text_fallback(documents=[_doc(idx=0, chunks=12)])
        assert "12 chunks" in result

    def test_plaintext_doc_cap(self):
        big_library = [_doc(idx=i, section="Strategy") for i in range(_MAX_KB_DOCS_RENDERED + 5)]
        result = render_kb_library_text_fallback(documents=big_library)
        assert "more doc(s)" in result

    def test_plaintext_section_cap(self):
        sections = [f"Section {i}" for i in range(_MAX_KB_SECTIONS_RENDERED + 3)]
        docs = [_doc(idx=i, section=sections[i]) for i in range(len(sections))]
        result = render_kb_library_text_fallback(documents=docs)
        assert "more section(s)" in result

    def test_plaintext_org_label(self):
        result = render_kb_library_text_fallback(
            documents=_docs(n_per_section=1),
            org_label="Acme Corp",
        )
        assert "Acme Corp" in result
