"""Unit tests for HTML app surface #50 — per-CRM-provider overview.

Covers:
  - _crm_overview_clip: empty/whitespace/clip/escape
  - _crm_overview_provider_norm / _crm_overview_field_type_norm
  - _crm_overview_connection_palette: bool / string / unknown
  - _crm_overview_field_type_buckets: desc-count + alpha tiebreak
  - _crm_overview_required_count
  - _crm_overview_is_connected: status wins, fallback to integration
  - _crm_overview_stat_card: uniform border + accent palette
  - _render_crm_overview_empty_state_html: 3 modes
  - render_crm_sync_overview_html: full rendering paths
  - render_crm_sync_overview_text_fallback
  - smoke tests with realistic data
  - regression locks: no single-side accent borders, no legacy hexes,
    drill-up does NOT list self, manage block does NOT list self.
"""

from __future__ import annotations

import pytest

from g8_mcp_server.app_renderer import (
    _CRM_OVERVIEW_CONNECTED_LABELS,
    _CRM_OVERVIEW_DISCONNECTED_LABELS,
    _G8_ACCENT_BG,
    _G8_ACCENT_BORDER,
    _G8_BORDER,
    _G8_CARD_BG,
    _G8_MUTED_BG,
    _G8_PRIMARY,
    _G8_TEXT,
    _G8_TEXT_MUTED,
    _G8_WARNING_BG,
    _G8_WARNING_FG,
    _MAX_CRM_OVERVIEW_CONNECTION_ID_LEN,
    _MAX_CRM_OVERVIEW_CRM_TYPE_LEN,
    _MAX_CRM_OVERVIEW_FIELD_TYPE_CHIPS,
    _MAX_CRM_OVERVIEW_MESSAGE_LEN,
    _crm_overview_clip,
    _crm_overview_connection_palette,
    _crm_overview_field_type_buckets,
    _crm_overview_field_type_norm,
    _crm_overview_is_connected,
    _crm_overview_provider_norm,
    _crm_overview_required_count,
    _crm_overview_stat_card,
    _render_crm_overview_empty_state_html,
    render_crm_sync_overview_html,
    render_crm_sync_overview_text_fallback,
)


# ==================================================================== #
# _crm_overview_clip                                                   #
# ==================================================================== #


class TestClip:
    def test_none_returns_empty(self):
        assert _crm_overview_clip(None, 10) == ""

    def test_non_string_returns_empty(self):
        assert _crm_overview_clip(123, 10) == ""
        assert _crm_overview_clip(["a"], 10) == ""
        assert _crm_overview_clip({"a": 1}, 10) == ""

    def test_whitespace_only_returns_empty(self):
        assert _crm_overview_clip("", 10) == ""
        assert _crm_overview_clip("   ", 10) == ""
        assert _crm_overview_clip("\n\t", 10) == ""

    def test_short_string_unchanged(self):
        assert _crm_overview_clip("hello", 10) == "hello"

    def test_clip_adds_ellipsis(self):
        # Length 5 cap → truncates to 4 chars + ellipsis.
        assert _crm_overview_clip("abcdefgh", 5) == "abcd…"

    def test_html_escape(self):
        assert _crm_overview_clip("<img>", 20) == "&lt;img&gt;"

    def test_strip_whitespace(self):
        assert _crm_overview_clip("  hello  ", 10) == "hello"


# ==================================================================== #
# _crm_overview_provider_norm / _crm_overview_field_type_norm          #
# ==================================================================== #


class TestProviderNorm:
    def test_none_returns_unknown(self):
        assert _crm_overview_provider_norm(None) == "unknown"

    def test_empty_returns_unknown(self):
        assert _crm_overview_provider_norm("") == "unknown"
        assert _crm_overview_provider_norm("   ") == "unknown"

    def test_non_string_returns_unknown(self):
        assert _crm_overview_provider_norm(123) == "unknown"

    def test_lowercases(self):
        assert _crm_overview_provider_norm("HUBSPOT") == "hubspot"
        assert _crm_overview_provider_norm("Salesforce") == "salesforce"

    def test_strips(self):
        assert _crm_overview_provider_norm("  hubspot  ") == "hubspot"


class TestFieldTypeNorm:
    def test_none_returns_unknown(self):
        assert _crm_overview_field_type_norm(None) == "unknown"

    def test_empty_returns_unknown(self):
        assert _crm_overview_field_type_norm("") == "unknown"
        assert _crm_overview_field_type_norm("   ") == "unknown"

    def test_non_string_returns_unknown(self):
        assert _crm_overview_field_type_norm(123) == "unknown"

    def test_lowercases(self):
        assert _crm_overview_field_type_norm("STRING") == "string"

    def test_strips(self):
        assert _crm_overview_field_type_norm("  number  ") == "number"


# ==================================================================== #
# _crm_overview_connection_palette                                     #
# ==================================================================== #


class TestConnectionPalette:
    def test_true_is_green(self):
        bg, fg, label = _crm_overview_connection_palette(True)
        assert bg == "#d1fae5"
        assert fg == "#059669"
        assert label == "CONNECTED"

    def test_false_is_red(self):
        bg, fg, label = _crm_overview_connection_palette(False)
        assert bg == "#fee2e2"
        assert fg == "#ca3214"
        assert label == "DISCONNECTED"

    def test_string_connected_alias_is_green(self):
        for v in _CRM_OVERVIEW_CONNECTED_LABELS:
            bg, fg, _ = _crm_overview_connection_palette(v)
            assert bg == "#d1fae5"
            assert fg == "#059669"

    def test_string_disconnected_alias_is_red(self):
        for v in _CRM_OVERVIEW_DISCONNECTED_LABELS:
            bg, fg, _ = _crm_overview_connection_palette(v)
            assert bg == "#fee2e2"
            assert fg == "#ca3214"

    def test_uppercase_string_normalizes(self):
        bg, fg, label = _crm_overview_connection_palette("CONNECTED")
        assert bg == "#d1fae5"
        assert label == "CONNECTED"

    def test_unknown_string_is_muted_with_label(self):
        bg, fg, label = _crm_overview_connection_palette("pending")
        assert bg == _G8_MUTED_BG
        assert fg == _G8_TEXT_MUTED
        assert label == "PENDING"

    def test_none_is_muted_unknown(self):
        bg, fg, label = _crm_overview_connection_palette(None)
        assert bg == _G8_MUTED_BG
        assert fg == _G8_TEXT_MUTED
        assert label == "UNKNOWN"


# ==================================================================== #
# _crm_overview_field_type_buckets                                     #
# ==================================================================== #


class TestFieldTypeBuckets:
    def test_empty_list(self):
        assert _crm_overview_field_type_buckets([]) == []

    def test_single_type(self):
        fields = [
            {"type": "string"},
            {"type": "string"},
        ]
        assert _crm_overview_field_type_buckets(fields) == [("string", 2)]

    def test_desc_count_order(self):
        fields = [
            {"type": "string"},
            {"type": "number"},
            {"type": "string"},
            {"type": "string"},
            {"type": "number"},
        ]
        result = _crm_overview_field_type_buckets(fields)
        assert result[0] == ("string", 3)
        assert result[1] == ("number", 2)

    def test_alpha_tiebreak(self):
        # Both have count 1 — alphabetical order for tie.
        fields = [
            {"type": "zebra"},
            {"type": "alpha"},
        ]
        result = _crm_overview_field_type_buckets(fields)
        assert result == [("alpha", 1), ("zebra", 1)]

    def test_non_dict_skipped(self):
        fields = [
            {"type": "string"},
            "not-a-dict",
            None,
            {"type": "number"},
        ]
        result = _crm_overview_field_type_buckets(fields)
        assert len(result) == 2

    def test_missing_type_buckets_as_unknown(self):
        fields = [
            {},
            {"type": None},
            {"type": "   "},
            {"type": "string"},
        ]
        result = _crm_overview_field_type_buckets(fields)
        # 3 'unknown' + 1 'string' → unknown wins on count
        assert result[0] == ("unknown", 3)
        assert result[1] == ("string", 1)


# ==================================================================== #
# _crm_overview_required_count                                         #
# ==================================================================== #


class TestRequiredCount:
    def test_empty(self):
        assert _crm_overview_required_count([]) == 0

    def test_all_required(self):
        fields = [
            {"required": True},
            {"required": True},
        ]
        assert _crm_overview_required_count(fields) == 2

    def test_mixed(self):
        fields = [
            {"required": True},
            {"required": False},
            {"required": True},
            {},
        ]
        assert _crm_overview_required_count(fields) == 2

    def test_non_dict_skipped(self):
        fields = [
            {"required": True},
            None,
            "not-a-dict",
        ]
        assert _crm_overview_required_count(fields) == 1

    def test_truthy_non_bool(self):
        fields = [
            {"required": "yes"},  # truthy string
            {"required": 1},  # truthy int
            {"required": 0},  # falsy int
        ]
        assert _crm_overview_required_count(fields) == 2


# ==================================================================== #
# _crm_overview_is_connected                                           #
# ==================================================================== #


class TestIsConnected:
    def test_status_true_wins(self):
        assert (
            _crm_overview_is_connected(
                status={"connected": True},
                integration={"status": "disconnected"},
            )
            is True
        )

    def test_status_false_wins(self):
        assert (
            _crm_overview_is_connected(
                status={"connected": False},
                integration={"status": "connected"},
            )
            is False
        )

    def test_status_missing_falls_back_to_integration(self):
        assert (
            _crm_overview_is_connected(
                status=None,
                integration={"status": "connected"},
            )
            is True
        )

    def test_status_missing_connected_falls_back(self):
        assert (
            _crm_overview_is_connected(
                status={"crm_type": "foo"},
                integration={"status": "connected"},
            )
            is True
        )

    def test_both_missing(self):
        assert _crm_overview_is_connected(None, None) is False

    def test_integration_disconnected(self):
        assert (
            _crm_overview_is_connected(
                status=None, integration={"status": "disconnected"}
            )
            is False
        )


# ==================================================================== #
# _crm_overview_stat_card                                              #
# ==================================================================== #


class TestStatCard:
    def test_renders_label_and_value(self):
        html_out = _crm_overview_stat_card("Connection", "CONNECTED")
        assert "Connection" in html_out
        assert "CONNECTED" in html_out

    def test_uniform_border_no_single_side_accent(self):
        html_out = _crm_overview_stat_card("X", "1")
        # No single-side accent borders anywhere.
        assert "border-left" not in html_out
        assert "border-right" not in html_out
        assert "border-top:" not in html_out
        assert "border-bottom:" not in html_out
        # Uses the full uniform border token.
        assert f"border:1px solid {_G8_BORDER}" in html_out

    def test_primary_accent_uses_graph8_primary(self):
        html_out = _crm_overview_stat_card("X", "1", accent="primary")
        assert _G8_PRIMARY in html_out

    def test_positive_accent_is_green(self):
        html_out = _crm_overview_stat_card("X", "1", accent="positive")
        assert "#059669" in html_out

    def test_destructive_accent_is_red(self):
        html_out = _crm_overview_stat_card("X", "1", accent="destructive")
        assert "#ca3214" in html_out

    def test_warning_accent_uses_warning_fg(self):
        html_out = _crm_overview_stat_card("X", "1", accent="warning")
        assert _G8_WARNING_FG in html_out

    def test_escapes_label_and_value(self):
        html_out = _crm_overview_stat_card("<img>", "<xss>")
        assert "&lt;img&gt;" in html_out
        assert "&lt;xss&gt;" in html_out
        assert "<img>" not in html_out.replace("&lt;img&gt;", "")


# ==================================================================== #
# _render_crm_overview_empty_state_html                                #
# ==================================================================== #


class TestEmptyState:
    def test_not_connected_mode(self):
        html_out = _render_crm_overview_empty_state_html(
            "hubspot", mode="not_connected"
        )
        assert "not connected" in html_out
        assert "hubspot" in html_out

    def test_unknown_provider_mode(self):
        html_out = _render_crm_overview_empty_state_html(
            "weirdprovider", mode="unknown_provider"
        )
        assert "unknown provider" in html_out
        assert "weirdprovider" in html_out

    def test_unavailable_mode(self):
        html_out = _render_crm_overview_empty_state_html(
            "hubspot", mode="unavailable"
        )
        assert "overview not available" in html_out
        assert "hubspot" in html_out

    def test_escapes_provider(self):
        html_out = _render_crm_overview_empty_state_html(
            "<img>", mode="not_connected"
        )
        assert "<img>" not in html_out.replace("&lt;img&gt;", "")

    def test_none_mode_falls_through_to_unavailable(self):
        # Any unrecognized mode string → unavailable message.
        html_out = _render_crm_overview_empty_state_html(
            "hubspot", mode="???"
        )
        assert "overview not available" in html_out


# ==================================================================== #
# render_crm_sync_overview_html — full integration                     #
# ==================================================================== #


class TestRenderHtml:
    def test_all_missing_returns_unavailable(self):
        html_out = render_crm_sync_overview_html(
            status=None, fields=None, integration=None, provider="hubspot"
        )
        assert "overview not available" in html_out

    def test_connected_with_fields(self):
        status = {
            "provider": "hubspot",
            "connected": True,
            "connection_id": "conn_abc",
            "crm_type": "hubspot",
            "last_sync_at": "2026-04-20T12:00:00Z",
        }
        fields = [
            {"name": "Email", "slug": "email", "type": "string", "required": True},
            {"name": "Age", "slug": "age", "type": "number", "required": False},
            {"name": "FName", "slug": "fname", "type": "string", "required": True},
        ]
        html_out = render_crm_sync_overview_html(
            status=status, fields=fields, integration=None, provider="hubspot"
        )
        assert "hubspot" in html_out.lower()
        assert "CONNECTED" in html_out
        # 3 total, 2 required, 1 optional.
        assert ">3<" in html_out
        assert ">2<" in html_out
        assert "2 REQUIRED" in html_out
        assert "1 OPTIONAL" in html_out
        assert "2026-04-20T12:00:00Z" in html_out

    def test_disconnected_with_message(self):
        status = {
            "provider": "salesforce",
            "connected": False,
            "message": "OAuth token expired",
        }
        html_out = render_crm_sync_overview_html(
            status=status, fields=[], integration=None, provider="salesforce"
        )
        assert "DISCONNECTED" in html_out
        assert "OAuth token expired" in html_out
        # Disconnected + has message → falls through to full render.
        assert "salesforce" in html_out.lower()

    def test_not_connected_and_empty_yields_empty_state(self):
        status = {"connected": False}
        html_out = render_crm_sync_overview_html(
            status=status, fields=None, integration=None, provider="hubspot"
        )
        assert "not connected" in html_out

    def test_connection_details_card_renders(self):
        status = {
            "connected": True,
            "crm_type": "salesforce",
            "connection_id": "conn_xyz123",
            "last_sync_at": "2026-04-20T12:00:00Z",
        }
        integration = {
            "provider": "salesforce",
            "connected_at": "2026-03-01T00:00:00Z",
        }
        html_out = render_crm_sync_overview_html(
            status=status,
            fields=[],
            integration=integration,
            provider="salesforce",
        )
        assert "Connection details" in html_out
        assert "salesforce" in html_out
        assert "conn_xyz123" in html_out
        assert "2026-03-01T00:00:00Z" in html_out

    def test_integration_supplies_last_sync_when_status_missing(self):
        integration = {
            "provider": "hubspot",
            "status": "connected",
            "last_sync_at": "2026-04-20T10:00:00Z",
        }
        html_out = render_crm_sync_overview_html(
            status=None,
            fields=[],
            integration=integration,
            provider="hubspot",
        )
        assert "2026-04-20T10:00:00Z" in html_out

    def test_never_synced_shows_placeholder(self):
        html_out = render_crm_sync_overview_html(
            status={"connected": True},
            fields=[],
            integration=None,
            provider="hubspot",
        )
        assert "(never)" in html_out

    def test_fields_section_rendered_for_any_fields(self):
        fields = [
            {"type": "string", "required": True},
            {"type": "number", "required": False},
        ]
        html_out = render_crm_sync_overview_html(
            status={"connected": True},
            fields=fields,
            integration=None,
            provider="hubspot",
        )
        assert "Fields schema" in html_out
        assert "string" in html_out
        assert "number" in html_out

    def test_fields_section_hidden_when_empty(self):
        html_out = render_crm_sync_overview_html(
            status={"connected": True},
            fields=[],
            integration=None,
            provider="hubspot",
        )
        assert "Fields schema" not in html_out

    def test_type_chips_cap_at_max(self):
        # Generate MAX+5 types.
        fields = [
            {"type": f"type{i}"}
            for i in range(_MAX_CRM_OVERVIEW_FIELD_TYPE_CHIPS + 5)
        ]
        html_out = render_crm_sync_overview_html(
            status={"connected": True},
            fields=fields,
            integration=None,
            provider="hubspot",
        )
        # Overflow chip should appear.
        assert "more types" in html_out

    def test_drill_up_does_NOT_list_self(self):
        """REGRESSION LOCK — drill-up must not pointer back to /overview.

        The self-URI would be a dead link. Drill-up should point to
        siblings (/fields, /status), parents (dashboard), and
        adjacent surfaces (audience-syncs, webhooks/events).
        """
        html_out = render_crm_sync_overview_html(
            status={"connected": True},
            fields=[],
            integration=None,
            provider="hubspot",
        )
        # No reference to /overview in drill-up context.
        assert "g8://crm-syncs/hubspot/overview" not in html_out

    def test_manage_block_does_not_list_self(self):
        """REGRESSION LOCK — manage block must point to write paths,
        not back to the overview surface itself."""
        html_out = render_crm_sync_overview_html(
            status={"connected": True},
            fields=[],
            integration=None,
            provider="hubspot",
        )
        assert "Manage hubspot sync" in html_out
        assert "g8://crm-syncs/hubspot/overview" not in html_out

    def test_no_single_side_accent_borders(self):
        """REGRESSION LOCK — no border-left/right/top:/bottom: styles.

        Graph8 design parity: all borders are uniform 1px solid
        #dfdfdf. Single-side accent borders are 'dead giveaway for
        ai coding'.
        """
        html_out = render_crm_sync_overview_html(
            status={"connected": True},
            fields=[{"type": "string"}],
            integration=None,
            provider="hubspot",
        )
        assert "border-left:" not in html_out
        assert "border-right:" not in html_out
        assert "border-top:" not in html_out
        assert "border-bottom:" not in html_out

    def test_no_legacy_accent_hexes(self):
        """REGRESSION LOCK — uses graph8 tokens only.

        No legacy accent colors like the old blue/cyan/pink that
        predated the graph8 refresh.
        """
        html_out = render_crm_sync_overview_html(
            status={"connected": True},
            fields=[{"type": "string", "required": True}],
            integration={"provider": "hubspot", "connected_at": "x"},
            provider="hubspot",
        )
        # Legacy colors that must NOT appear.
        for legacy in ("#3b82f6", "#2563eb", "#ec4899", "#f59e0b", "#8b5cf6"):
            assert legacy.lower() not in html_out.lower()
        # Graph8 primary must appear.
        assert _G8_PRIMARY in html_out

    def test_html_escape_of_provider(self):
        html_out = render_crm_sync_overview_html(
            status={"connected": True},
            fields=[],
            integration=None,
            provider="<script>",
        )
        assert "<script>" not in html_out.replace("&lt;script&gt;", "")

    def test_html_escape_of_message(self):
        status = {
            "connected": False,
            "message": "<img onerror=1>",
        }
        html_out = render_crm_sync_overview_html(
            status=status, fields=[], integration=None, provider="x"
        )
        # Message is escaped in its block.
        assert "&lt;img onerror=1&gt;" in html_out

    def test_html_escape_of_long_connection_id(self):
        long_id = "a" * (_MAX_CRM_OVERVIEW_CONNECTION_ID_LEN + 20)
        status = {"connected": True, "connection_id": long_id}
        html_out = render_crm_sync_overview_html(
            status=status, fields=[], integration=None, provider="x"
        )
        # Should be clipped.
        assert "…" in html_out

    def test_html_escape_of_long_message(self):
        long_msg = "m" * (_MAX_CRM_OVERVIEW_MESSAGE_LEN + 20)
        status = {"connected": True, "message": long_msg}
        html_out = render_crm_sync_overview_html(
            status=status, fields=[], integration=None, provider="x"
        )
        assert "…" in html_out

    def test_provider_chip_uppercased(self):
        html_out = render_crm_sync_overview_html(
            status={"connected": True},
            fields=[],
            integration=None,
            provider="hubspot",
        )
        assert "HUBSPOT" in html_out

    def test_html_has_doctype(self):
        html_out = render_crm_sync_overview_html(
            status={"connected": True},
            fields=[],
            integration=None,
            provider="hubspot",
        )
        assert "<!DOCTYPE html>" in html_out


# ==================================================================== #
# render_crm_sync_overview_text_fallback                               #
# ==================================================================== #


class TestTextFallback:
    def test_all_missing_returns_unavailable(self):
        text = render_crm_sync_overview_text_fallback(
            status=None, fields=None, integration=None, provider="hubspot"
        )
        assert "Could not fetch" in text
        assert "hubspot" in text

    def test_not_connected_empty_returns_message(self):
        text = render_crm_sync_overview_text_fallback(
            status={"connected": False},
            fields=None,
            integration=None,
            provider="hubspot",
        )
        assert "not connected" in text

    def test_full_rendering_connected(self):
        status = {
            "connected": True,
            "crm_type": "hubspot",
            "connection_id": "conn_xyz",
            "last_sync_at": "2026-04-20T12:00:00Z",
        }
        fields = [
            {"type": "string", "required": True},
            {"type": "string", "required": False},
            {"type": "number", "required": True},
        ]
        text = render_crm_sync_overview_text_fallback(
            status=status, fields=fields, integration=None, provider="hubspot"
        )
        assert "# CRM sync — hubspot" in text
        assert "**Status:** connected" in text
        assert "**Total fields:** 3" in text
        assert "**Required fields:** 2 (1 optional)" in text
        assert "**Last sync:** 2026-04-20T12:00:00Z" in text
        assert "## Fields schema" in text
        assert "## Manage hubspot sync" in text

    def test_type_overflow_note(self):
        fields = [
            {"type": f"t{i}"}
            for i in range(_MAX_CRM_OVERVIEW_FIELD_TYPE_CHIPS + 3)
        ]
        text = render_crm_sync_overview_text_fallback(
            status={"connected": True},
            fields=fields,
            integration=None,
            provider="hubspot",
        )
        assert "more types omitted" in text

    def test_connection_details_block(self):
        status = {
            "connected": True,
            "crm_type": "hubspot",
            "connection_id": "conn_xyz",
            "message": "OK",
        }
        integration = {
            "provider": "hubspot",
            "connected_at": "2026-03-01T00:00:00Z",
        }
        text = render_crm_sync_overview_text_fallback(
            status=status,
            fields=[],
            integration=integration,
            provider="hubspot",
        )
        assert "## Connection details" in text
        assert "- CRM type: `hubspot`" in text
        assert "- Connection ID: `conn_xyz`" in text
        assert "- Connected since: 2026-03-01T00:00:00Z" in text
        assert "- Message: OK" in text

    def test_never_synced_placeholder(self):
        text = render_crm_sync_overview_text_fallback(
            status={"connected": True},
            fields=[],
            integration=None,
            provider="hubspot",
        )
        assert "(never)" in text

    def test_clips_connection_id(self):
        long_id = "a" * (_MAX_CRM_OVERVIEW_CONNECTION_ID_LEN + 20)
        text = render_crm_sync_overview_text_fallback(
            status={"connected": True, "connection_id": long_id},
            fields=[],
            integration=None,
            provider="x",
        )
        assert "…" in text

    def test_clips_message(self):
        long_msg = "m" * (_MAX_CRM_OVERVIEW_MESSAGE_LEN + 20)
        text = render_crm_sync_overview_text_fallback(
            status={"connected": True, "message": long_msg},
            fields=[],
            integration=None,
            provider="x",
        )
        assert "…" in text

    def test_manage_block_has_all_pointers(self):
        text = render_crm_sync_overview_text_fallback(
            status={"connected": True},
            fields=[],
            integration=None,
            provider="hubspot",
        )
        assert "contacts/push" in text
        assert "companies/push" in text
        assert "lists/push" in text
        assert "g8://crm-syncs/hubspot/fields" in text
        assert "g8://crm-syncs/dashboard" in text
        assert "g8://audience-syncs/dashboard" in text
        assert "g8://webhooks/events" in text

    def test_drill_up_does_NOT_list_self(self):
        """REGRESSION LOCK — text manage block must not list /overview."""
        text = render_crm_sync_overview_text_fallback(
            status={"connected": True},
            fields=[],
            integration=None,
            provider="hubspot",
        )
        assert "g8://crm-syncs/hubspot/overview" not in text

    def test_fields_section_hidden_when_empty(self):
        text = render_crm_sync_overview_text_fallback(
            status={"connected": True},
            fields=[],
            integration=None,
            provider="hubspot",
        )
        assert "## Fields schema" not in text

    def test_has_trailing_newline(self):
        text = render_crm_sync_overview_text_fallback(
            status={"connected": True},
            fields=[],
            integration=None,
            provider="hubspot",
        )
        assert text.endswith("\n")


# ==================================================================== #
# Smoke tests with realistic data                                      #
# ==================================================================== #


class TestSmoke:
    def test_smoke_hubspot_connected(self):
        status = {
            "provider": "hubspot",
            "connected": True,
            "connection_id": "hub_7d3f...",
            "crm_type": "hubspot",
            "last_sync_at": "2026-04-20T10:30:00Z",
            "message": "Sync completed 842 contacts",
        }
        fields = [
            {"name": "Email", "slug": "email", "type": "string", "required": True, "label": "Email Address"},
            {"name": "First Name", "slug": "first_name", "type": "string", "required": False, "label": "First Name"},
            {"name": "Last Name", "slug": "last_name", "type": "string", "required": False, "label": "Last Name"},
            {"name": "Phone", "slug": "phone", "type": "string", "required": False, "label": "Phone"},
            {"name": "Created Date", "slug": "createdate", "type": "datetime", "required": False, "label": "Created"},
        ]
        integration = {
            "provider": "hubspot",
            "status": "connected",
            "connection_id": "hub_7d3f...",
            "last_sync_at": "2026-04-20T10:30:00Z",
            "connected_at": "2026-02-15T00:00:00Z",
        }
        html_out = render_crm_sync_overview_html(
            status=status,
            fields=fields,
            integration=integration,
            provider="hubspot",
        )
        # Key facts present.
        assert "HUBSPOT" in html_out
        assert "CONNECTED" in html_out
        assert "hub_7d3f..." in html_out
        assert "2026-04-20T10:30:00Z" in html_out
        assert "2026-02-15T00:00:00Z" in html_out
        assert "842 contacts" in html_out
        assert "Fields schema" in html_out
        # All core data present.
        assert "string" in html_out
        assert "datetime" in html_out

    def test_smoke_salesforce_disconnected(self):
        status = {
            "provider": "salesforce",
            "connected": False,
            "message": "OAuth token expired — please reconnect",
        }
        html_out = render_crm_sync_overview_html(
            status=status,
            fields=None,
            integration=None,
            provider="salesforce",
        )
        assert "DISCONNECTED" in html_out
        assert "OAuth token expired" in html_out

    def test_smoke_text_fallback_hubspot(self):
        status = {
            "connected": True,
            "crm_type": "hubspot",
            "connection_id": "hub_abc",
            "last_sync_at": "2026-04-20T10:00:00Z",
        }
        fields = [
            {"type": "string", "required": True},
            {"type": "string", "required": False},
            {"type": "number", "required": False},
        ]
        text = render_crm_sync_overview_text_fallback(
            status=status,
            fields=fields,
            integration=None,
            provider="hubspot",
        )
        # Structure.
        assert text.startswith("# CRM sync — hubspot")
        assert "**Status:** connected" in text
        assert "**Total fields:** 3" in text
        assert "## Fields schema" in text
        assert "## Manage hubspot sync" in text
        assert text.endswith("\n")
