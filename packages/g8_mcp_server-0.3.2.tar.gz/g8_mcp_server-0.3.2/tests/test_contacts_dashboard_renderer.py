"""Unit tests for HTML app surface #58 — contacts dashboard renderer.

Surface #58 renders the org-wide contact index at
`g8://contacts/dashboard` (+ `.txt`). HTML sibling to the existing
upgrade-1 JSON list at `g8://contacts`; complements the per-contact
detail surface at `g8://contacts/{contact_id}`.

Backend: `GET /contacts?limit=200` → `ApiResponse[list[ContactListItem]]`
with `pagination{page, limit, total, has_next}`.

Coverage:
- Helpers: clip, display_name, seniority_norm, seniority_palette,
  has_email/phone/linkedin, location, bucket, stat_card, chip,
  overflow_chip
- Empty-state (both modes)
- `render_contacts_dashboard_html` (None → unavailable, [] → empty,
  populated → full layout, pagination override, bucket ordering)
- `render_contacts_dashboard_text_fallback` (markdown mirror)
- Regression locks:
    - No single-side colored accent borders (AI-tell)
    - No legacy accent hexes (non-graph8 tokens)
    - Drill-up points at per-contact/fields/search surfaces, not self
    - Overflow capped at _MAX_CONTACTS_DASHBOARD_RENDERED
    - XSS escape on every user-controlled field (name, title, email,
      city, state, country, department, seniority)
    - Text fallback is valid markdown (no raw HTML leaks)
    - Empty-state mode distinction: primary tint vs muted
"""

from __future__ import annotations

import re

import pytest

from g8_mcp_server.app_renderer import (
    _G8_ACCENT_BG,
    _G8_ACCENT_BORDER,
    _G8_BORDER,
    _G8_MUTED_BG,
    _G8_POSITIVE_BG,
    _G8_POSITIVE_FG,
    _G8_PRIMARY,
    _G8_TEXT,
    _G8_TEXT_MUTED,
    _MAX_CONTACTS_DASHBOARD_COUNTRY_CHIPS,
    _MAX_CONTACTS_DASHBOARD_DEPARTMENT_CHIPS,
    _MAX_CONTACTS_DASHBOARD_EMAIL_LEN,
    _MAX_CONTACTS_DASHBOARD_LOCATION_LEN,
    _MAX_CONTACTS_DASHBOARD_NAME_LEN,
    _MAX_CONTACTS_DASHBOARD_RENDERED,
    _MAX_CONTACTS_DASHBOARD_SENIORITY_CHIPS,
    _MAX_CONTACTS_DASHBOARD_TITLE_LEN,
    _contacts_dashboard_bucket,
    _contacts_dashboard_chip,
    _contacts_dashboard_clip,
    _contacts_dashboard_display_name,
    _contacts_dashboard_has_email,
    _contacts_dashboard_has_linkedin,
    _contacts_dashboard_has_phone,
    _contacts_dashboard_location,
    _contacts_dashboard_overflow_chip,
    _contacts_dashboard_seniority_norm,
    _contacts_dashboard_seniority_palette,
    _contacts_dashboard_stat_card,
    _render_contacts_dashboard_empty_state_html,
    render_contacts_dashboard_html,
    render_contacts_dashboard_text_fallback,
)


# graph8 token regressions ---------------------------------------------------

_LEGACY_ACCENT_HEXES = (
    "#6366f1",   # pre-graph8 indigo primary
    "#4f46e5",   # pre-graph8 indigo dark
    "#10b981",   # pre-graph8 success green (old palette)
    "#ec4899",   # pre-graph8 pink
    "#dc2626",   # pre-graph8 destructive (old)
    "#16a34a",   # pre-graph8 success (old)
)


# ---------------------------------------------------------------------------
# Sample fixtures
# ---------------------------------------------------------------------------


_BASE_CONTACT = {
    "id": 101,
    "first_name": "Alice",
    "last_name": "Johnson",
    "work_email": "alice@acme.com",
    "direct_phone": "+1-415-555-0101",
    "mobile_phone": None,
    "job_title": "VP of Sales",
    "job_department": "Sales",
    "seniority_level": "VP",
    "linkedin_url": "https://linkedin.com/in/alicejohnson",
    "city": "San Francisco",
    "state": "California",
    "country": "United States",
    "company_id": 42,
}


def _make_contact(**overrides) -> dict:
    out = dict(_BASE_CONTACT)
    out.update(overrides)
    return out


_SAMPLE_CONTACTS = [
    _BASE_CONTACT,
    _make_contact(
        id=102,
        first_name="Bob",
        last_name="Smith",
        work_email="bob@acme.com",
        seniority_level="Director",
        job_title="Director of Marketing",
        job_department="Marketing",
        country="United States",
        linkedin_url=None,
    ),
    _make_contact(
        id=103,
        first_name="Carol",
        last_name="Diaz",
        work_email=None,
        direct_phone=None,
        mobile_phone=None,
        linkedin_url=None,
        seniority_level="Senior",
        job_title="Senior Engineer",
        job_department="Engineering",
        country="Mexico",
        city="Guadalajara",
        state="Jalisco",
    ),
    _make_contact(
        id=104,
        first_name="Dev",
        last_name="Patel",
        work_email="dev@acme.com",
        mobile_phone="+91-9000012345",
        direct_phone=None,
        seniority_level="C-Level",
        job_title="CEO",
        job_department="Executive",
        linkedin_url="https://linkedin.com/in/devpatel",
        city="Bangalore",
        state="Karnataka",
        country="India",
        company_id=99,
    ),
    _make_contact(
        id=105,
        first_name=None,
        last_name=None,
        work_email="anonymous@unknown.biz",
        direct_phone=None,
        mobile_phone=None,
        linkedin_url=None,
        seniority_level=None,
        job_title=None,
        job_department=None,
        city=None,
        state=None,
        country=None,
        company_id=None,
    ),
]


# ---------------------------------------------------------------------------
# TestClip
# ---------------------------------------------------------------------------


class TestClip:
    def test_empty_string(self):
        assert _contacts_dashboard_clip("", 50) == ""

    def test_whitespace_only(self):
        assert _contacts_dashboard_clip("   ", 50) == ""

    def test_none(self):
        assert _contacts_dashboard_clip(None, 50) == ""

    def test_non_string(self):
        assert _contacts_dashboard_clip(42, 50) == ""
        assert _contacts_dashboard_clip(["x"], 50) == ""

    def test_short_value_passes_through(self):
        assert _contacts_dashboard_clip("Alice", 50) == "Alice"

    def test_long_value_clipped_with_ellipsis(self):
        result = _contacts_dashboard_clip("a" * 100, 20)
        assert result.endswith("…")
        assert len(result) == 20

    def test_html_escape(self):
        assert "&lt;" in _contacts_dashboard_clip("<b>x</b>", 50)


# ---------------------------------------------------------------------------
# TestDisplayName
# ---------------------------------------------------------------------------


class TestDisplayName:
    def test_both_names(self):
        assert _contacts_dashboard_display_name(
            {"first_name": "Alice", "last_name": "Johnson"}
        ) == "Alice Johnson"

    def test_first_only(self):
        assert _contacts_dashboard_display_name(
            {"first_name": "Alice"}
        ) == "Alice"

    def test_last_only(self):
        assert _contacts_dashboard_display_name(
            {"last_name": "Johnson"}
        ) == "Johnson"

    def test_fallback_to_email_local_part(self):
        result = _contacts_dashboard_display_name(
            {"first_name": None, "last_name": None, "work_email": "alice@acme.com"}
        )
        assert result == "alice"

    def test_fallback_when_all_missing(self):
        assert _contacts_dashboard_display_name({}) == "(unnamed contact)"

    def test_whitespace_names_fall_through(self):
        assert _contacts_dashboard_display_name(
            {"first_name": "   ", "last_name": "\t\n", "work_email": None}
        ) == "(unnamed contact)"

    def test_html_escape_in_name(self):
        result = _contacts_dashboard_display_name(
            {"first_name": "<Alice>", "last_name": "\"Bob\""}
        )
        # Names should be escaped so angle brackets/quotes don't render raw.
        assert "<Alice>" not in result
        assert "&lt;" in result or "&quot;" in result or "&amp;" in result

    def test_long_name_clipped(self):
        result = _contacts_dashboard_display_name(
            {"first_name": "A" * 100, "last_name": "B" * 100}
        )
        assert result.endswith("…")
        # Character count is on escape-expanded content; just verify a cap.
        assert len(result) < 200

    def test_email_local_too_long_clipped(self):
        result = _contacts_dashboard_display_name(
            {
                "first_name": None,
                "last_name": None,
                "work_email": ("x" * 200) + "@acme.com",
            }
        )
        assert result.endswith("…")


# ---------------------------------------------------------------------------
# TestSeniorityNorm & Palette
# ---------------------------------------------------------------------------


class TestSeniorityNorm:
    def test_normalize_strips_and_lowercases(self):
        assert _contacts_dashboard_seniority_norm("  VP  ") == "vp"

    def test_non_string(self):
        assert _contacts_dashboard_seniority_norm(None) == ""
        assert _contacts_dashboard_seniority_norm(42) == ""


class TestSeniorityPalette:
    def test_c_level_is_primary(self):
        bg, fg = _contacts_dashboard_seniority_palette("C-Level")
        assert bg == _G8_ACCENT_BG
        assert fg == _G8_PRIMARY

    def test_founder_is_primary(self):
        bg, fg = _contacts_dashboard_seniority_palette("Founder")
        assert fg == _G8_PRIMARY

    def test_vp_is_primary(self):
        bg, fg = _contacts_dashboard_seniority_palette("VP")
        assert fg == _G8_PRIMARY

    def test_svp_is_primary(self):
        bg, fg = _contacts_dashboard_seniority_palette("SVP")
        assert fg == _G8_PRIMARY

    def test_director_is_positive(self):
        bg, fg = _contacts_dashboard_seniority_palette("Director")
        assert bg == _G8_POSITIVE_BG
        assert fg == _G8_POSITIVE_FG

    def test_manager_is_positive(self):
        bg, fg = _contacts_dashboard_seniority_palette("Manager")
        assert fg == _G8_POSITIVE_FG

    def test_ic_is_muted(self):
        bg, fg = _contacts_dashboard_seniority_palette("Senior")
        assert bg == _G8_MUTED_BG
        assert fg == _G8_TEXT_MUTED

    def test_unknown_is_muted(self):
        bg, fg = _contacts_dashboard_seniority_palette("something-weird")
        assert bg == _G8_MUTED_BG
        assert fg == _G8_TEXT_MUTED

    def test_empty_is_muted(self):
        bg, fg = _contacts_dashboard_seniority_palette("")
        assert bg == _G8_MUTED_BG
        assert fg == _G8_TEXT_MUTED


# ---------------------------------------------------------------------------
# TestReachabilityFlags
# ---------------------------------------------------------------------------


class TestReachabilityFlags:
    def test_has_email_true(self):
        assert _contacts_dashboard_has_email({"work_email": "a@b.com"}) is True

    def test_has_email_false_empty(self):
        assert _contacts_dashboard_has_email({"work_email": ""}) is False

    def test_has_email_false_none(self):
        assert _contacts_dashboard_has_email({"work_email": None}) is False

    def test_has_email_false_whitespace(self):
        assert _contacts_dashboard_has_email({"work_email": "   "}) is False

    def test_has_phone_direct(self):
        assert _contacts_dashboard_has_phone({"direct_phone": "555-0101"}) is True

    def test_has_phone_mobile(self):
        assert _contacts_dashboard_has_phone(
            {"direct_phone": None, "mobile_phone": "555-0202"}
        ) is True

    def test_has_phone_both_missing(self):
        assert _contacts_dashboard_has_phone(
            {"direct_phone": None, "mobile_phone": None}
        ) is False

    def test_has_linkedin_true(self):
        assert _contacts_dashboard_has_linkedin(
            {"linkedin_url": "https://linkedin.com/in/x"}
        ) is True

    def test_has_linkedin_false(self):
        assert _contacts_dashboard_has_linkedin({"linkedin_url": None}) is False
        assert _contacts_dashboard_has_linkedin({"linkedin_url": "   "}) is False


# ---------------------------------------------------------------------------
# TestLocation
# ---------------------------------------------------------------------------


class TestLocation:
    def test_full_location(self):
        assert _contacts_dashboard_location(
            {"city": "SF", "state": "CA", "country": "USA"}
        ) == "SF, CA, USA"

    def test_partial_location(self):
        assert _contacts_dashboard_location(
            {"city": "SF", "state": None, "country": "USA"}
        ) == "SF, USA"

    def test_empty_location(self):
        assert _contacts_dashboard_location({}) == ""
        assert _contacts_dashboard_location(
            {"city": None, "state": None, "country": None}
        ) == ""

    def test_html_escape(self):
        result = _contacts_dashboard_location(
            {"city": "<script>", "state": None, "country": None}
        )
        assert "<script>" not in result
        assert "&lt;" in result or "&amp;" in result

    def test_long_location_clipped(self):
        result = _contacts_dashboard_location(
            {"city": "x" * 100, "state": "y" * 100, "country": "z" * 100}
        )
        assert result.endswith("…")
        assert len(result) <= _MAX_CONTACTS_DASHBOARD_LOCATION_LEN + 5  # room for &amp;

    def test_whitespace_fields_skipped(self):
        assert _contacts_dashboard_location(
            {"city": "   ", "state": "CA", "country": None}
        ) == "CA"


# ---------------------------------------------------------------------------
# TestBucket
# ---------------------------------------------------------------------------


class TestBucket:
    def test_counts_and_sorts_desc(self):
        data = [
            {"seniority_level": "VP"},
            {"seniority_level": "VP"},
            {"seniority_level": "Director"},
        ]
        buckets = _contacts_dashboard_bucket(data, "seniority_level")
        assert buckets[0] == ("VP", 2)
        assert buckets[1] == ("Director", 1)

    def test_whitespace_trimmed_and_grouped(self):
        data = [
            {"seniority_level": "VP"},
            {"seniority_level": " VP "},
            {"seniority_level": "vp"},
        ]
        buckets = _contacts_dashboard_bucket(data, "seniority_level")
        # All three collapse to one bucket because we lowercase-strip.
        assert len(buckets) == 1
        assert buckets[0][1] == 3

    def test_skips_missing_or_empty(self):
        data = [
            {"seniority_level": None},
            {"seniority_level": ""},
            {"seniority_level": "   "},
            {"seniority_level": 42},  # non-string is skipped
            {"seniority_level": "VP"},
        ]
        buckets = _contacts_dashboard_bucket(data, "seniority_level")
        assert buckets == [("VP", 1)]

    def test_skips_non_dict(self):
        data = [None, "not a dict", {"seniority_level": "VP"}]
        buckets = _contacts_dashboard_bucket(data, "seniority_level")
        assert buckets == [("VP", 1)]

    def test_tie_broken_alphabetically(self):
        data = [
            {"seniority_level": "Manager"},
            {"seniority_level": "Director"},
        ]
        buckets = _contacts_dashboard_bucket(data, "seniority_level")
        # Both have count 1; alpha order → Director first
        assert buckets == [("Director", 1), ("Manager", 1)]

    def test_preserves_display_casing(self):
        data = [
            {"seniority_level": "VP"},
            {"seniority_level": "vp"},
        ]
        buckets = _contacts_dashboard_bucket(data, "seniority_level")
        # First-seen casing is preserved on output
        assert buckets[0][0] == "VP"

    def test_empty_input(self):
        assert _contacts_dashboard_bucket([], "seniority_level") == []


# ---------------------------------------------------------------------------
# TestStatCard
# ---------------------------------------------------------------------------


class TestStatCard:
    def test_label_and_value_rendered(self):
        out = _contacts_dashboard_stat_card("Total", "42")
        assert "Total" in out
        assert "42" in out

    def test_primary_accent(self):
        out = _contacts_dashboard_stat_card("Total", "42", accent="primary")
        assert _G8_PRIMARY in out

    def test_positive_accent(self):
        out = _contacts_dashboard_stat_card("Active", "5", accent="positive")
        assert _G8_POSITIVE_FG in out

    def test_no_single_side_colored_accent_border(self):
        """Regression: no `border-left: N px solid <color>` AI tell.

        shadcn cards use uniform borders on all 4 sides.
        """
        out = _contacts_dashboard_stat_card("Total", "42", accent="primary")
        assert not re.search(
            r"border-(left|right|top|bottom):\s*\d+px\s+solid\s+#",
            out,
        )

    def test_escapes_html_in_label(self):
        out = _contacts_dashboard_stat_card("<script>", "42")
        assert "<script>" not in out

    def test_escapes_html_in_value(self):
        out = _contacts_dashboard_stat_card("Total", "<script>")
        assert "<script>" not in out


# ---------------------------------------------------------------------------
# TestChipAndOverflow
# ---------------------------------------------------------------------------


class TestChip:
    def test_label_and_count(self):
        out = _contacts_dashboard_chip(
            "VP", 5, bg=_G8_ACCENT_BG, fg=_G8_PRIMARY
        )
        assert "VP" in out
        assert "5" in out

    def test_escapes_label(self):
        out = _contacts_dashboard_chip(
            "<script>", 1, bg=_G8_ACCENT_BG, fg=_G8_PRIMARY
        )
        assert "<script>" not in out

    def test_custom_border(self):
        out = _contacts_dashboard_chip(
            "VP", 5, bg=_G8_ACCENT_BG, fg=_G8_PRIMARY,
            border=_G8_ACCENT_BORDER,
        )
        assert _G8_ACCENT_BORDER in out

    def test_default_border_is_neutral(self):
        out = _contacts_dashboard_chip(
            "Sales", 3, bg=_G8_MUTED_BG, fg=_G8_TEXT
        )
        assert _G8_BORDER in out


class TestOverflowChip:
    def test_count_and_suffix(self):
        out = _contacts_dashboard_overflow_chip(5, "items")
        assert "5" in out
        assert "items" in out

    def test_uses_muted_palette(self):
        out = _contacts_dashboard_overflow_chip(5, "x")
        assert _G8_MUTED_BG in out
        assert _G8_TEXT_MUTED in out


# ---------------------------------------------------------------------------
# TestEmptyState
# ---------------------------------------------------------------------------


class TestEmptyState:
    def test_empty_mode_uses_primary_accent(self):
        out = _render_contacts_dashboard_empty_state_html(mode="empty")
        assert "No contacts yet" in out
        assert _G8_PRIMARY in out
        assert _G8_ACCENT_BG in out

    def test_empty_mode_points_at_create_routes(self):
        out = _render_contacts_dashboard_empty_state_html(mode="empty")
        assert "POST /contacts" in out
        assert "batch" in out.lower() or "assert" in out.lower()
        assert "enrich" in out.lower()

    def test_unavailable_mode_muted(self):
        out = _render_contacts_dashboard_empty_state_html(mode="unavailable")
        assert "not available" in out.lower()
        # Unavailable state should not lean on primary tint
        assert _G8_ACCENT_BG not in out

    def test_empty_mode_has_valid_html(self):
        out = _render_contacts_dashboard_empty_state_html(mode="empty")
        assert out.startswith("<!DOCTYPE html>")
        assert out.rstrip().endswith("</html>")

    def test_empty_state_escapes_heading_in_title(self):
        out = _render_contacts_dashboard_empty_state_html(mode="empty")
        # <title> element is populated from the heading — verify it's the
        # escaped string, not raw HTML.
        assert "<title>Contacts — No contacts yet</title>" in out


# ---------------------------------------------------------------------------
# TestRenderHtml
# ---------------------------------------------------------------------------


class TestRenderHtml:
    def test_none_returns_unavailable(self):
        out = render_contacts_dashboard_html(contacts=None)
        assert "not available" in out.lower()

    def test_empty_list_returns_empty_state(self):
        out = render_contacts_dashboard_html(contacts=[])
        assert "No contacts yet" in out

    def test_populated_renders_full_layout(self):
        out = render_contacts_dashboard_html(contacts=_SAMPLE_CONTACTS)
        assert "Contacts" in out
        assert "Total contacts" in out
        assert "With email" in out
        assert "With phone" in out
        assert "With LinkedIn" in out

    def test_total_chip_reflects_count(self):
        out = render_contacts_dashboard_html(contacts=_SAMPLE_CONTACTS)
        assert f"{len(_SAMPLE_CONTACTS)} TOTAL" in out

    def test_pagination_total_override_used(self):
        """When backend provides pagination.total > visible, use that."""
        out = render_contacts_dashboard_html(
            contacts=_SAMPLE_CONTACTS, total=999
        )
        assert "999 TOTAL" in out

    def test_pagination_total_lower_than_visible_ignored(self):
        """If total < visible, fall back to len(contacts) for safety."""
        out = render_contacts_dashboard_html(
            contacts=_SAMPLE_CONTACTS, total=0  # stale/wrong
        )
        # Effective total becomes len(contacts)
        assert f"{len(_SAMPLE_CONTACTS)} TOTAL" in out

    def test_seniority_mix_section_rendered(self):
        out = render_contacts_dashboard_html(contacts=_SAMPLE_CONTACTS)
        assert "Seniority mix" in out

    def test_departments_section_rendered(self):
        out = render_contacts_dashboard_html(contacts=_SAMPLE_CONTACTS)
        assert "Top departments" in out

    def test_countries_section_rendered(self):
        out = render_contacts_dashboard_html(contacts=_SAMPLE_CONTACTS)
        assert "Top countries" in out

    def test_contact_names_rendered(self):
        out = render_contacts_dashboard_html(contacts=_SAMPLE_CONTACTS)
        assert "Alice Johnson" in out
        assert "Bob Smith" in out

    def test_anonymous_contact_has_fallback(self):
        out = render_contacts_dashboard_html(contacts=[_SAMPLE_CONTACTS[-1]])
        # Anonymous contact with only email → fallback to local part
        assert "anonymous" in out

    def test_drill_down_points_at_per_contact(self):
        out = render_contacts_dashboard_html(contacts=_SAMPLE_CONTACTS)
        assert "g8://contacts/101" in out
        assert "g8://contacts/101/notes" in out
        assert "g8://contacts/101/tasks" in out
        assert "g8://contacts/101/deals" in out
        assert "g8://contacts/101/activities" in out

    def test_drill_up_does_NOT_list_self(self):
        """Regression: drill-up should never point at g8://contacts/dashboard."""
        out = render_contacts_dashboard_html(contacts=_SAMPLE_CONTACTS)
        # Count occurrences — should only appear in <title> and h1 tags
        # (i.e. NOT as a <code>g8://contacts/dashboard</code> drill-up target).
        assert "<code>g8://contacts/dashboard</code>" not in out

    def test_drill_up_points_at_fields_catalog(self):
        out = render_contacts_dashboard_html(contacts=_SAMPLE_CONTACTS)
        assert "g8://fields/contacts" in out

    def test_drill_up_points_at_companies(self):
        out = render_contacts_dashboard_html(contacts=_SAMPLE_CONTACTS)
        assert "g8://companies" in out

    def test_drill_up_points_at_batch_assert(self):
        out = render_contacts_dashboard_html(contacts=_SAMPLE_CONTACTS)
        assert "PUT /contacts/assert/batch" in out

    def test_drill_up_points_at_search(self):
        out = render_contacts_dashboard_html(contacts=_SAMPLE_CONTACTS)
        assert "POST /search/contacts" in out

    def test_overflow_capped(self):
        big = [_make_contact(id=i) for i in range(_MAX_CONTACTS_DASHBOARD_RENDERED + 10)]
        out = render_contacts_dashboard_html(contacts=big)
        assert f"+ 10 more contacts omitted" in out

    def test_overflow_points_at_pagination(self):
        big = [_make_contact(id=i) for i in range(_MAX_CONTACTS_DASHBOARD_RENDERED + 10)]
        out = render_contacts_dashboard_html(contacts=big)
        assert "?page=2" in out

    def test_html_escape_on_name(self):
        contacts = [_make_contact(first_name="<script>alert()</script>")]
        out = render_contacts_dashboard_html(contacts=contacts)
        assert "<script>alert()</script>" not in out

    def test_html_escape_on_email(self):
        contacts = [_make_contact(work_email="<script>@bad.com")]
        out = render_contacts_dashboard_html(contacts=contacts)
        assert "<script>@bad.com" not in out

    def test_html_escape_on_title(self):
        contacts = [_make_contact(job_title="<img src=x>")]
        out = render_contacts_dashboard_html(contacts=contacts)
        assert "<img src=x>" not in out

    def test_html_escape_on_location(self):
        contacts = [_make_contact(city="<img>", state="<b>", country="<i>")]
        out = render_contacts_dashboard_html(contacts=contacts)
        assert "<img>" not in out
        # Body may contain <b> as an HTML tag for bold text; check it's the
        # escaped version from our escape, not an injected tag immediately
        # after "📍" emoji.
        assert "📍 &lt;img&gt;" in out

    def test_html_escape_on_department_and_seniority(self):
        contacts = [_make_contact(
            job_department="<b>sales</b>",
            seniority_level="<i>VP</i>",
        )]
        out = render_contacts_dashboard_html(contacts=contacts)
        assert "<b>sales</b>" not in out
        assert "<i>VP</i>" not in out

    def test_html_is_well_formed(self):
        out = render_contacts_dashboard_html(contacts=_SAMPLE_CONTACTS)
        assert out.startswith("<!DOCTYPE html>")
        assert out.rstrip().endswith("</html>")

    def test_no_single_side_colored_accent_border(self):
        """AI-tell regression: shadcn cards use uniform borders."""
        out = render_contacts_dashboard_html(contacts=_SAMPLE_CONTACTS)
        assert not re.search(
            r"border-(left|right|top|bottom):\s*\d+px\s+solid\s+#",
            out,
        )

    def test_no_legacy_accent_hexes(self):
        """Regression: no pre-graph8 tokens leak into output."""
        out = render_contacts_dashboard_html(contacts=_SAMPLE_CONTACTS)
        for hex_code in _LEGACY_ACCENT_HEXES:
            assert hex_code not in out, f"Legacy hex {hex_code} leaked"

    def test_no_javascript(self):
        """Surfaces must be static markup (no inline JS)."""
        out = render_contacts_dashboard_html(contacts=_SAMPLE_CONTACTS)
        assert "<script" not in out.lower()
        assert "javascript:" not in out.lower()
        assert "onclick=" not in out.lower()
        assert "onerror=" not in out.lower()

    def test_phone_badge_shown_when_phone_present(self):
        out = render_contacts_dashboard_html(contacts=[_BASE_CONTACT])
        assert "PHONE" in out

    def test_linkedin_badge_shown_when_linkedin_present(self):
        out = render_contacts_dashboard_html(contacts=[_BASE_CONTACT])
        assert "LINKEDIN" in out

    def test_company_chip_only_when_company_id_present(self):
        contact_no_company = _make_contact(company_id=None)
        out = render_contacts_dashboard_html(contacts=[contact_no_company])
        assert "company #" not in out

    def test_invalid_entries_filtered(self):
        """Non-dict contacts should not crash the renderer."""
        out = render_contacts_dashboard_html(
            contacts=[None, "not a contact", _BASE_CONTACT]
        )
        assert "Alice Johnson" in out

    def test_subtitle_mentions_recent_count(self):
        out = render_contacts_dashboard_html(contacts=_SAMPLE_CONTACTS)
        assert "most recent contacts" in out

    def test_populated_does_not_show_empty_text(self):
        out = render_contacts_dashboard_html(contacts=_SAMPLE_CONTACTS)
        assert "No contacts yet" not in out


# ---------------------------------------------------------------------------
# TestTextFallback
# ---------------------------------------------------------------------------


class TestTextFallback:
    def test_none_returns_unavailable(self):
        out = render_contacts_dashboard_text_fallback(contacts=None)
        assert "not available" in out.lower()

    def test_empty_list_returns_empty_text(self):
        out = render_contacts_dashboard_text_fallback(contacts=[])
        assert "no contacts yet" in out.lower()

    def test_empty_state_points_at_create_routes(self):
        out = render_contacts_dashboard_text_fallback(contacts=[])
        assert "POST /contacts" in out

    def test_populated_has_kpi_section(self):
        out = render_contacts_dashboard_text_fallback(contacts=_SAMPLE_CONTACTS)
        assert "Total contacts:" in out
        assert "With email:" in out
        assert "With phone:" in out
        assert "With LinkedIn:" in out

    def test_seniority_section_rendered(self):
        out = render_contacts_dashboard_text_fallback(contacts=_SAMPLE_CONTACTS)
        assert "Seniority mix" in out

    def test_departments_section_rendered(self):
        out = render_contacts_dashboard_text_fallback(contacts=_SAMPLE_CONTACTS)
        assert "Top departments" in out

    def test_countries_section_rendered(self):
        out = render_contacts_dashboard_text_fallback(contacts=_SAMPLE_CONTACTS)
        assert "Top countries" in out

    def test_contact_rows_rendered(self):
        out = render_contacts_dashboard_text_fallback(contacts=_SAMPLE_CONTACTS)
        assert "Alice Johnson" in out
        assert "alice@acme.com" in out

    def test_contact_row_shows_id(self):
        out = render_contacts_dashboard_text_fallback(contacts=_SAMPLE_CONTACTS)
        assert "id=101" in out

    def test_manage_section_has_surface_pointers(self):
        out = render_contacts_dashboard_text_fallback(contacts=_SAMPLE_CONTACTS)
        assert "g8://contacts/{contact_id}" in out
        assert "g8://contacts/{contact_id}/notes" in out
        assert "g8://fields/contacts" in out

    def test_manage_section_has_write_routes(self):
        out = render_contacts_dashboard_text_fallback(contacts=_SAMPLE_CONTACTS)
        assert "POST /contacts" in out
        assert "PUT /contacts/assert/batch" in out
        assert "POST /search/contacts" in out

    def test_overflow_note_shown_when_truncated(self):
        big = [_make_contact(id=i) for i in range(_MAX_CONTACTS_DASHBOARD_RENDERED + 5)]
        out = render_contacts_dashboard_text_fallback(contacts=big)
        assert "+ 5 more contacts omitted" in out

    def test_pagination_total_override_used(self):
        out = render_contacts_dashboard_text_fallback(
            contacts=_SAMPLE_CONTACTS, total=999
        )
        assert "999 total" in out

    def test_pagination_total_clamped(self):
        out = render_contacts_dashboard_text_fallback(
            contacts=_SAMPLE_CONTACTS, total=0
        )
        assert f"{len(_SAMPLE_CONTACTS)} total" in out

    def test_text_is_valid_markdown(self):
        """No raw HTML tags should leak into the text fallback."""
        out = render_contacts_dashboard_text_fallback(contacts=_SAMPLE_CONTACTS)
        # Heading markers are markdown, not HTML
        assert "# Contacts" in out
        # No closing HTML tags
        assert "</div>" not in out
        assert "</h" not in out
        assert "<code>" not in out

    def test_ends_with_newline(self):
        out = render_contacts_dashboard_text_fallback(contacts=_SAMPLE_CONTACTS)
        assert out.endswith("\n")

    def test_invalid_entries_filtered(self):
        out = render_contacts_dashboard_text_fallback(
            contacts=[None, "not a contact", _BASE_CONTACT]
        )
        assert "Alice Johnson" in out

    def test_row_includes_location_when_present(self):
        out = render_contacts_dashboard_text_fallback(contacts=[_BASE_CONTACT])
        assert "location:" in out
        assert "San Francisco" in out

    def test_row_includes_seniority_bracket(self):
        out = render_contacts_dashboard_text_fallback(contacts=[_BASE_CONTACT])
        assert "[VP]" in out

    def test_anonymous_contact_shows_unnamed(self):
        out = render_contacts_dashboard_text_fallback(
            contacts=[_SAMPLE_CONTACTS[-1]]
        )
        assert "(unnamed)" in out


# ---------------------------------------------------------------------------
# TestSmoke — fast end-to-end sanity checks
# ---------------------------------------------------------------------------


class TestSmoke:
    def test_html_output_not_empty(self):
        out = render_contacts_dashboard_html(contacts=_SAMPLE_CONTACTS)
        assert len(out) > 500

    def test_text_output_not_empty(self):
        out = render_contacts_dashboard_text_fallback(contacts=_SAMPLE_CONTACTS)
        assert len(out) > 100

    def test_html_and_text_agree_on_counts(self):
        """Both renderers should surface the same count numbers."""
        html_out = render_contacts_dashboard_html(contacts=_SAMPLE_CONTACTS)
        text_out = render_contacts_dashboard_text_fallback(contacts=_SAMPLE_CONTACTS)
        total = len(_SAMPLE_CONTACTS)
        assert str(total) in html_out
        assert str(total) in text_out
