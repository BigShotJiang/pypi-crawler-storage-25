"""
Unit tests for Surface #53 — per-contact activities timeline renderer.

Covers:
- Type normalization + synonym collapsing (phone_call → call, etc.)
- Palette lookup + fallback for unknown types
- Clipping helpers (subject, description, outcome, next_steps, owner)
- Date formatting (ISO datetime, date-only, raw-echo, None/empty)
- Duration formatting (min, h+min, zero/None)
- Type count aggregation (sort: count desc, label asc)
- Bucket count for a single type
- Stat card structure + graph8 design tokens
- Type badge pill structure
- Empty state rendering (missing contact, zero activities)
- Header label derivation (full_name → first+last → email → fallback)
- Full HTML render (stats, type breakdown, timeline, drill-up)
- HTML escape safety (XSS on subject, description, owner_name)
- Drill-up card does NOT self-reference
- No single-side accent borders (graph8 design rule)
- No legacy accent hex colors
- Text fallback mirror layout
- Overflow handling (25 rendered + "+ N more")
- Smoke tests for round-trip stability
"""

from __future__ import annotations

import re
from datetime import date

import pytest

from g8_mcp_server.app_renderer import (
    _contact_activity_bucket_count,
    _contact_activity_clip_description,
    _contact_activity_clip_next_steps,
    _contact_activity_clip_outcome,
    _contact_activity_clip_subject,
    _contact_activity_duration_label,
    _contact_activity_format_date,
    _contact_activity_header_label,
    _contact_activity_normalize_type,
    _contact_activity_owner_label,
    _contact_activity_stat_card,
    _contact_activity_type_badge,
    _contact_activity_type_counts,
    _contact_activity_type_palette,
    _render_contact_activities_empty_state_html,
    render_contact_activities_html,
    render_contact_activities_text_fallback,
)


# -----------------------------------------------------------------------
# Fixtures
# -----------------------------------------------------------------------

CONTACT_ID = "a1b2c3d4-e5f6-7890-abcd-1234567890ab"

SAMPLE_CONTACT = {
    "id": CONTACT_ID,
    "full_name": "Jane Doe",
    "first_name": "Jane",
    "last_name": "Doe",
    "email": "jane@acme.com",
    "title": "VP Sales",
}

SAMPLE_ACTIVITIES = [
    {
        "id": "act-1",
        "activity_type": "call",
        "subject": "Q1 pipeline review",
        "description": "Walked through the Q1 deal list and identified 3 at-risk opportunities.",
        "owner_name": "Alice Smith",
        "activity_date": "2026-04-15T14:30:00",
        "duration_minutes": 45,
        "status": "completed",
        "outcome": "Positive — agreed to a follow-up",
        "next_steps": "Send proposal by Friday",
        "source": "aircall",
    },
    {
        "id": "act-2",
        "activity_type": "email",
        "subject": "Re: Proposal draft",
        "description": "Shared the proposal PDF and asked for feedback.",
        "owner_name": "Alice Smith",
        "activity_date": "2026-04-14T09:15:00",
        "status": "sent",
        "source": "gmail",
    },
    {
        "id": "act-3",
        "activity_type": "meeting",
        "subject": "Discovery call",
        "description": "30-minute intro covering current stack and pain points.",
        "owner_name": "Bob Jones",
        "activity_date": "2026-04-10",
        "duration_minutes": 30,
        "status": "completed",
        "source": "calendly",
    },
    {
        "id": "act-4",
        "activity_type": "note",
        "subject": "Internal note",
        "description": "Jane mentioned hiring freeze ends in Q3.",
        "owner_name": "Alice Smith",
        "activity_date": "2026-04-09",
    },
]


# =======================================================================
# TestNormalizeType
# =======================================================================


class TestNormalizeType:
    def test_returns_empty_for_none(self):
        assert _contact_activity_normalize_type(None) == ""

    def test_returns_empty_for_empty_string(self):
        assert _contact_activity_normalize_type("") == ""
        assert _contact_activity_normalize_type("   ") == ""

    def test_returns_empty_for_non_string(self):
        assert _contact_activity_normalize_type(123) == ""

    def test_lowercases_and_strips(self):
        assert _contact_activity_normalize_type("  CALL  ") == "call"
        assert _contact_activity_normalize_type("Email") == "email"

    def test_phone_call_synonym(self):
        assert _contact_activity_normalize_type("phone_call") == "call"
        assert _contact_activity_normalize_type("phone") == "call"
        assert _contact_activity_normalize_type("voice_call") == "call"

    def test_email_synonym(self):
        assert _contact_activity_normalize_type("email_sent") == "email"
        assert _contact_activity_normalize_type("email_received") == "email"

    def test_meeting_synonym(self):
        assert _contact_activity_normalize_type("mtg") == "meeting"
        assert _contact_activity_normalize_type("video_call") == "meeting"
        assert _contact_activity_normalize_type("zoom") == "meeting"

    def test_sms_synonym(self):
        assert _contact_activity_normalize_type("text") == "sms"
        assert _contact_activity_normalize_type("text_message") == "sms"

    def test_unknown_type_passes_through(self):
        assert _contact_activity_normalize_type("webinar") == "webinar"


# =======================================================================
# TestTypePalette
# =======================================================================


class TestTypePalette:
    def test_known_type_returns_full_palette(self):
        pal = _contact_activity_type_palette("call")
        assert pal["label"] == "Call"
        assert "bg" in pal and "fg" in pal and "border" in pal

    def test_synonym_resolves_to_canonical(self):
        pal = _contact_activity_type_palette("phone_call")
        assert pal["label"] == "Call"

    def test_unknown_type_uses_fallback_with_derived_label(self):
        pal = _contact_activity_type_palette("webinar")
        assert pal["label"] == "Webinar"
        # fallback colors
        assert pal["bg"] == "#f9f9f9"

    def test_none_type_uses_generic_activity_label(self):
        pal = _contact_activity_type_palette(None)
        assert pal["label"] == "Activity"

    def test_empty_type_uses_generic_activity_label(self):
        pal = _contact_activity_type_palette("")
        assert pal["label"] == "Activity"

    def test_returns_copy_not_reference(self):
        # Mutating the returned dict must not leak into the registry
        pal = _contact_activity_type_palette("call")
        pal["bg"] = "#000000"
        fresh = _contact_activity_type_palette("call")
        assert fresh["bg"] != "#000000"


# =======================================================================
# TestClipping
# =======================================================================


class TestClipSubject:
    def test_returns_placeholder_for_empty(self):
        assert _contact_activity_clip_subject(None) == "(no subject)"
        assert _contact_activity_clip_subject("") == "(no subject)"
        assert _contact_activity_clip_subject("   ") == "(no subject)"

    def test_preserves_short_subject(self):
        assert _contact_activity_clip_subject("Hi") == "Hi"

    def test_strips_whitespace(self):
        assert _contact_activity_clip_subject("  Call with Jane  ") == "Call with Jane"

    def test_clips_long_subject_with_ellipsis(self):
        long = "A" * 200
        out = _contact_activity_clip_subject(long)
        assert out.endswith("…")
        assert len(out) <= 181

    def test_non_string_uses_placeholder(self):
        assert _contact_activity_clip_subject(42) == "(no subject)"


class TestClipDescription:
    def test_empty_returns_empty_string(self):
        assert _contact_activity_clip_description(None) == ""
        assert _contact_activity_clip_description("") == ""
        assert _contact_activity_clip_description("   ") == ""

    def test_clips_long_description(self):
        long = "x" * 500
        out = _contact_activity_clip_description(long)
        assert out.endswith("…")
        assert len(out) <= 401

    def test_preserves_short_description(self):
        assert _contact_activity_clip_description("short note") == "short note"


class TestClipOutcome:
    def test_empty_returns_empty(self):
        assert _contact_activity_clip_outcome("") == ""
        assert _contact_activity_clip_outcome(None) == ""

    def test_clips_long_outcome(self):
        long = "y" * 300
        out = _contact_activity_clip_outcome(long)
        assert out.endswith("…")


class TestClipNextSteps:
    def test_empty_returns_empty(self):
        assert _contact_activity_clip_next_steps("") == ""

    def test_clips_long(self):
        long = "z" * 300
        out = _contact_activity_clip_next_steps(long)
        assert out.endswith("…")


# =======================================================================
# TestOwnerLabel
# =======================================================================


class TestOwnerLabel:
    def test_prefers_owner_name(self):
        assert _contact_activity_owner_label({"owner_name": "Alice"}) == "Alice"

    def test_falls_back_to_owner_id(self):
        assert _contact_activity_owner_label({"owner_id": "u-123"}) == "u-123"

    def test_fallback_unassigned_when_missing(self):
        assert _contact_activity_owner_label({}) == "Unassigned"

    def test_non_dict_returns_unassigned(self):
        assert _contact_activity_owner_label(None) == "Unassigned"
        assert _contact_activity_owner_label("string") == "Unassigned"

    def test_clips_long_owner_name(self):
        long = "Z" * 200
        out = _contact_activity_owner_label({"owner_name": long})
        assert out.endswith("…")

    def test_empty_owner_name_falls_to_id(self):
        assert (
            _contact_activity_owner_label({"owner_name": "", "owner_id": "u-1"})
            == "u-1"
        )


# =======================================================================
# TestFormatDate
# =======================================================================


class TestFormatDate:
    def test_none_returns_dash(self):
        assert _contact_activity_format_date(None) == "—"

    def test_empty_returns_dash(self):
        assert _contact_activity_format_date("") == "—"
        assert _contact_activity_format_date("   ") == "—"

    def test_iso_datetime_formats_as_yyyy_mm_dd_hh_mm(self):
        out = _contact_activity_format_date("2026-04-15T14:30:00")
        assert out == "2026-04-15 14:30"

    def test_date_only_formats_as_yyyy_mm_dd(self):
        assert _contact_activity_format_date("2026-04-15") == "2026-04-15"

    def test_iso_with_z_handled(self):
        out = _contact_activity_format_date("2026-04-15T14:30:00Z")
        assert out.startswith("2026-04-15")

    def test_unparseable_string_echoed(self):
        assert _contact_activity_format_date("not a date") == "not a date"


# =======================================================================
# TestDurationLabel
# =======================================================================


class TestDurationLabel:
    def test_none_returns_empty(self):
        assert _contact_activity_duration_label(None) == ""

    def test_zero_returns_empty(self):
        assert _contact_activity_duration_label(0) == ""

    def test_negative_returns_empty(self):
        assert _contact_activity_duration_label(-5) == ""

    def test_sub_hour_minutes(self):
        assert _contact_activity_duration_label(45) == "45 min"

    def test_exact_hour(self):
        assert _contact_activity_duration_label(60) == "1h"
        assert _contact_activity_duration_label(120) == "2h"

    def test_hour_plus_minutes(self):
        assert _contact_activity_duration_label(90) == "1h 30m"
        assert _contact_activity_duration_label(125) == "2h 5m"

    def test_non_int_returns_empty(self):
        assert _contact_activity_duration_label("not a number") == ""


# =======================================================================
# TestTypeCounts
# =======================================================================


class TestTypeCounts:
    def test_empty_list_returns_empty(self):
        assert _contact_activity_type_counts([]) == []

    def test_counts_by_type(self):
        acts = [
            {"activity_type": "call"},
            {"activity_type": "call"},
            {"activity_type": "email"},
        ]
        counts = _contact_activity_type_counts(acts)
        assert ("call", 2) in counts
        assert ("email", 1) in counts

    def test_sorts_by_count_desc(self):
        acts = [
            {"activity_type": "email"},
            {"activity_type": "call"},
            {"activity_type": "call"},
            {"activity_type": "call"},
            {"activity_type": "meeting"},
            {"activity_type": "meeting"},
        ]
        counts = _contact_activity_type_counts(acts)
        # Sorted by count desc: call(3), meeting(2), email(1)
        assert counts[0] == ("call", 3)
        assert counts[1] == ("meeting", 2)
        assert counts[2] == ("email", 1)

    def test_synonyms_collapse(self):
        acts = [
            {"activity_type": "call"},
            {"activity_type": "phone_call"},
            {"activity_type": "voice_call"},
        ]
        counts = _contact_activity_type_counts(acts)
        assert counts == [("call", 3)]

    def test_missing_type_bucketed_as_other(self):
        acts = [
            {"activity_type": None},
            {"activity_type": ""},
            {},
        ]
        counts = _contact_activity_type_counts(acts)
        assert counts == [("other", 3)]

    def test_ignores_non_dict_entries(self):
        acts = [
            {"activity_type": "call"},
            None,
            "string",
            {"activity_type": "email"},
        ]
        counts = _contact_activity_type_counts(acts)
        # Should only count the 2 dicts
        total = sum(c for _, c in counts)
        assert total == 2


class TestBucketCount:
    def test_count_for_bucket(self):
        acts = [
            {"activity_type": "call"},
            {"activity_type": "call"},
            {"activity_type": "email"},
        ]
        assert _contact_activity_bucket_count(acts, "call") == 2
        assert _contact_activity_bucket_count(acts, "email") == 1
        assert _contact_activity_bucket_count(acts, "meeting") == 0

    def test_synonyms_count(self):
        acts = [
            {"activity_type": "phone_call"},
            {"activity_type": "call"},
        ]
        assert _contact_activity_bucket_count(acts, "call") == 2


# =======================================================================
# TestStatCard
# =======================================================================


class TestStatCard:
    def test_renders_label_and_value(self):
        out = _contact_activity_stat_card("Total", "42")
        assert "Total" in out
        assert "42" in out

    def test_uses_g8_border_token(self):
        out = _contact_activity_stat_card("Total", "42")
        assert "#dfdfdf" in out  # _G8_BORDER

    def test_uses_g8_card_bg(self):
        out = _contact_activity_stat_card("Total", "42")
        assert "#ffffff" in out  # _G8_CARD_BG

    def test_escapes_label_value(self):
        out = _contact_activity_stat_card("<x>", "<y>")
        assert "&lt;x&gt;" in out
        assert "&lt;y&gt;" in out

    def test_accent_line_optional(self):
        out_no_accent = _contact_activity_stat_card("A", "1")
        out_with_accent = _contact_activity_stat_card("A", "1", accent="#7d2df3")
        assert "border-top" not in out_no_accent
        assert "border-top:3px solid #7d2df3" in out_with_accent

    def test_no_single_side_colored_accent_border(self):
        # The stat-card should only use the 3-side G8_BORDER + optional
        # top accent line. It should NEVER have a single-side colored
        # left or right accent border (a graph8 design-rule violation).
        out = _contact_activity_stat_card("A", "1", accent="#7d2df3")
        assert "border-left" not in out
        assert "border-right" not in out


class TestTypeBadge:
    def test_renders_label(self):
        out = _contact_activity_type_badge("call")
        assert "Call" in out

    def test_uses_palette_bg(self):
        out = _contact_activity_type_badge("call")
        assert "#f2eafe" in out  # call bg

    def test_unknown_type_uses_fallback(self):
        out = _contact_activity_type_badge("webinar")
        assert "Webinar" in out
        assert "#f9f9f9" in out  # fallback bg

    def test_escapes_label(self):
        out = _contact_activity_type_badge("<script>")
        # Raw < > are escaped; palette fallback title-cases the label, so
        # we assert on `&lt;` + `&gt;` around the escaped payload.
        assert "<script>" not in out
        assert "&lt;" in out and "&gt;" in out


# =======================================================================
# TestEmptyState
# =======================================================================


class TestEmptyState:
    def test_zero_activities_renders_start_state(self):
        out = _render_contact_activities_empty_state_html(
            contact_id=CONTACT_ID, zero_activities=True
        )
        assert "No activities yet" in out
        assert CONTACT_ID in out

    def test_missing_contact_renders_not_available(self):
        out = _render_contact_activities_empty_state_html(
            contact_id=CONTACT_ID, zero_activities=False
        )
        assert "Activities not available" in out

    def test_uses_g8_design_tokens(self):
        out = _render_contact_activities_empty_state_html(
            contact_id=CONTACT_ID, zero_activities=True
        )
        # Graph8 primary hex
        assert "#7d2df3" in out
        # Graph8 border
        assert "#dfdfdf" in out

    def test_escapes_contact_id(self):
        out = _render_contact_activities_empty_state_html(
            contact_id="<script>alert('x')</script>",
            zero_activities=True,
        )
        assert "<script>" not in out
        assert "&lt;script&gt;" in out

    def test_handles_empty_contact_id(self):
        out = _render_contact_activities_empty_state_html(
            contact_id="", zero_activities=False
        )
        assert "(unknown)" in out


# =======================================================================
# TestHeaderLabel
# =======================================================================


class TestHeaderLabel:
    def test_prefers_full_name(self):
        assert (
            _contact_activity_header_label(
                {"full_name": "Jane Doe", "first_name": "X"},
                CONTACT_ID,
            )
            == "Jane Doe"
        )

    def test_falls_back_to_first_last(self):
        assert (
            _contact_activity_header_label(
                {"first_name": "Jane", "last_name": "Doe"}, CONTACT_ID
            )
            == "Jane Doe"
        )

    def test_falls_back_to_email(self):
        assert (
            _contact_activity_header_label(
                {"email": "jane@acme.com"}, CONTACT_ID
            )
            == "jane@acme.com"
        )

    def test_fallback_when_no_contact(self):
        out = _contact_activity_header_label(None, CONTACT_ID)
        assert out.startswith("Contact ")
        assert CONTACT_ID[:24] in out

    def test_fallback_when_empty_contact(self):
        out = _contact_activity_header_label({}, CONTACT_ID)
        assert out.startswith("Contact ")

    def test_fallback_for_missing_contact_id(self):
        out = _contact_activity_header_label(None, "")
        assert "(unknown)" in out


# =======================================================================
# TestRenderHtml
# =======================================================================


class TestRenderHtml:
    def test_none_activities_renders_empty_state(self):
        out = render_contact_activities_html(
            activities=None, contact_id=CONTACT_ID
        )
        assert "Activities not available" in out

    def test_empty_activities_renders_start_state(self):
        out = render_contact_activities_html(
            activities=[], contact_id=CONTACT_ID
        )
        assert "No activities yet" in out

    def test_full_render_contains_header(self):
        out = render_contact_activities_html(
            activities=SAMPLE_ACTIVITIES,
            contact_id=CONTACT_ID,
            contact=SAMPLE_CONTACT,
        )
        assert "Jane Doe" in out
        assert "activities" in out.lower()

    def test_stat_cards_present(self):
        out = render_contact_activities_html(
            activities=SAMPLE_ACTIVITIES, contact_id=CONTACT_ID
        )
        assert "Total" in out
        assert "Calls" in out
        assert "Emails" in out
        assert "Meetings" in out
        # Counts
        assert ">4<" in out  # total = 4
        assert ">1<" in out  # 1 call, 1 email, 1 meeting, 1 note

    def test_type_breakdown_card_present(self):
        out = render_contact_activities_html(
            activities=SAMPLE_ACTIVITIES, contact_id=CONTACT_ID
        )
        assert "Type breakdown" in out
        assert "Call" in out
        assert "Email" in out
        assert "Meeting" in out
        assert "Note" in out

    def test_timeline_section_present(self):
        out = render_contact_activities_html(
            activities=SAMPLE_ACTIVITIES, contact_id=CONTACT_ID
        )
        assert "Timeline" in out
        assert "Q1 pipeline review" in out
        assert "Alice Smith" in out

    def test_outcome_call_out_rendered(self):
        out = render_contact_activities_html(
            activities=SAMPLE_ACTIVITIES, contact_id=CONTACT_ID
        )
        assert "Outcome" in out
        assert "agreed to a follow-up" in out

    def test_next_steps_call_out_rendered(self):
        out = render_contact_activities_html(
            activities=SAMPLE_ACTIVITIES, contact_id=CONTACT_ID
        )
        assert "Next" in out
        assert "Send proposal by Friday" in out

    def test_duration_rendered_for_call(self):
        out = render_contact_activities_html(
            activities=SAMPLE_ACTIVITIES, contact_id=CONTACT_ID
        )
        assert "45 min" in out

    def test_source_chip_rendered(self):
        out = render_contact_activities_html(
            activities=SAMPLE_ACTIVITIES, contact_id=CONTACT_ID
        )
        assert "aircall" in out
        assert "gmail" in out

    def test_drill_up_does_NOT_list_self(self):
        """Regression lock — drill-up must NOT link to the same resource."""
        out = render_contact_activities_html(
            activities=SAMPLE_ACTIVITIES, contact_id=CONTACT_ID
        )
        # Drill-up section should NOT contain a self-link
        # (extract the drill-up section and check)
        assert "Manage this contact" in out
        drill_up_idx = out.index("Manage this contact")
        drill_up_section = out[drill_up_idx:]
        # Self-reference would be: g8://contacts/{id}/activities (the very surface we're rendering)
        self_uri = f"g8://contacts/{CONTACT_ID}/activities"
        assert self_uri not in drill_up_section

    def test_drill_up_lists_sibling_resources(self):
        out = render_contact_activities_html(
            activities=SAMPLE_ACTIVITIES, contact_id=CONTACT_ID
        )
        assert f"g8://contacts/{CONTACT_ID}" in out  # parent
        assert f"g8://contacts/{CONTACT_ID}/notes" in out
        assert f"g8://contacts/{CONTACT_ID}/tasks" in out
        assert f"g8://contacts/{CONTACT_ID}/deals" in out
        assert "g8://activities/feed" in out

    def test_no_single_side_accent_borders(self):
        """Regression lock — no left/right colored accent bars anywhere."""
        out = render_contact_activities_html(
            activities=SAMPLE_ACTIVITIES, contact_id=CONTACT_ID
        )
        # Match patterns like `border-left: 3px solid #` or `border-right: 4px solid #`
        left_accent = re.search(
            r"border-left:\s*\d+px\s+solid\s+#[0-9a-fA-F]{3,6}", out
        )
        right_accent = re.search(
            r"border-right:\s*\d+px\s+solid\s+#[0-9a-fA-F]{3,6}", out
        )
        assert left_accent is None
        assert right_accent is None

    def test_no_legacy_accent_hexes(self):
        """Regression lock — must not contain legacy accent colors."""
        out = render_contact_activities_html(
            activities=SAMPLE_ACTIVITIES, contact_id=CONTACT_ID
        )
        # The old / legacy accents the codebase avoided (indigo-600, sky-500).
        # Note: `#7d2df3` is the graph8 brand primary and IS expected to
        # appear on any surface using `_G8_PRIMARY` — it was auto-migrated
        # from `#4338ca` on 2026-04-21 (token cleanup). The regression test
        # now locks out the pre-migration indigo-600 specifically.
        legacy = ["#4338ca", "#0ea5e9"]
        for color in legacy:
            assert color not in out

    def test_escapes_xss_in_subject(self):
        acts = [
            {
                "activity_type": "call",
                "subject": "<script>alert('xss')</script>",
                "owner_name": "Alice",
                "activity_date": "2026-04-15",
            }
        ]
        out = render_contact_activities_html(
            activities=acts, contact_id=CONTACT_ID
        )
        assert "<script>alert" not in out
        assert "&lt;script&gt;" in out

    def test_escapes_xss_in_description(self):
        acts = [
            {
                "activity_type": "call",
                "subject": "call",
                "description": "<img src=x onerror=alert(1)>",
                "owner_name": "Alice",
                "activity_date": "2026-04-15",
            }
        ]
        out = render_contact_activities_html(
            activities=acts, contact_id=CONTACT_ID
        )
        assert "<img src=x" not in out
        assert "&lt;img src=x" in out

    def test_escapes_xss_in_owner_name(self):
        acts = [
            {
                "activity_type": "call",
                "subject": "call",
                "owner_name": "<script>alert(1)</script>",
                "activity_date": "2026-04-15",
            }
        ]
        out = render_contact_activities_html(
            activities=acts, contact_id=CONTACT_ID
        )
        assert "<script>alert" not in out
        assert "&lt;script&gt;" in out

    def test_overflow_note_when_many_activities(self):
        # Make 30 activities — renderer shows 25, note +5 more
        many = [
            {
                "activity_type": "call",
                "subject": f"Call {i}",
                "owner_name": "Alice",
                "activity_date": "2026-04-15",
            }
            for i in range(30)
        ]
        out = render_contact_activities_html(
            activities=many, contact_id=CONTACT_ID
        )
        assert "+ 5 more activities" in out

    def test_no_type_breakdown_when_one_type_only(self):
        # If all one type, the breakdown card still renders but shows that single chip
        acts = [{"activity_type": "call", "subject": f"c{i}"} for i in range(3)]
        out = render_contact_activities_html(
            activities=acts, contact_id=CONTACT_ID
        )
        assert "Type breakdown" in out

    def test_renders_doctype(self):
        out = render_contact_activities_html(
            activities=SAMPLE_ACTIVITIES, contact_id=CONTACT_ID
        )
        assert out.startswith("<!DOCTYPE html>")

    def test_renders_valid_closing_body_html(self):
        out = render_contact_activities_html(
            activities=SAMPLE_ACTIVITIES, contact_id=CONTACT_ID
        )
        assert out.rstrip().endswith("</html>")

    def test_contact_id_displayed_in_header(self):
        out = render_contact_activities_html(
            activities=SAMPLE_ACTIVITIES,
            contact_id=CONTACT_ID,
            contact=SAMPLE_CONTACT,
        )
        assert CONTACT_ID in out

    def test_meta_chips_for_subtype_and_status(self):
        acts = [
            {
                "activity_type": "call",
                "activity_subtype": "outbound",
                "subject": "call 1",
                "status": "completed",
                "owner_name": "Alice",
                "activity_date": "2026-04-15",
            }
        ]
        out = render_contact_activities_html(
            activities=acts, contact_id=CONTACT_ID
        )
        assert "outbound" in out
        assert "status: completed" in out

    def test_owner_fallback_to_unassigned(self):
        acts = [{"activity_type": "call", "subject": "c"}]
        out = render_contact_activities_html(
            activities=acts, contact_id=CONTACT_ID
        )
        assert "Unassigned" in out


# =======================================================================
# TestTextFallback
# =======================================================================


class TestTextFallback:
    def test_none_activities_text(self):
        out = render_contact_activities_text_fallback(
            activities=None, contact_id=CONTACT_ID
        )
        assert "# Activities not available" in out
        assert CONTACT_ID in out

    def test_empty_activities_text(self):
        out = render_contact_activities_text_fallback(
            activities=[], contact_id=CONTACT_ID
        )
        assert "# No activities yet" in out

    def test_full_render_markdown_mirror(self):
        out = render_contact_activities_text_fallback(
            activities=SAMPLE_ACTIVITIES,
            contact_id=CONTACT_ID,
            contact=SAMPLE_CONTACT,
        )
        assert "# Jane Doe — activities" in out
        assert "## Stats" in out
        assert "- Total: 4" in out
        assert "- Calls: 1" in out
        assert "- Emails: 1" in out
        assert "- Meetings: 1" in out

    def test_type_breakdown_section_in_text(self):
        out = render_contact_activities_text_fallback(
            activities=SAMPLE_ACTIVITIES, contact_id=CONTACT_ID
        )
        assert "## Type breakdown" in out
        assert "- Call:" in out
        assert "- Email:" in out

    def test_timeline_entries_with_markdown_bullets(self):
        out = render_contact_activities_text_fallback(
            activities=SAMPLE_ACTIVITIES, contact_id=CONTACT_ID
        )
        assert "## Timeline" in out
        assert "**[Call]**" in out
        assert "**[Email]**" in out
        assert "Q1 pipeline review" in out

    def test_outcome_and_next_steps_in_text(self):
        out = render_contact_activities_text_fallback(
            activities=SAMPLE_ACTIVITIES, contact_id=CONTACT_ID
        )
        assert "Outcome:" in out
        assert "agreed to a follow-up" in out
        assert "Next:" in out
        assert "Send proposal by Friday" in out

    def test_manage_block_does_not_list_self(self):
        """Regression lock — manage block must NOT link to same surface."""
        out = render_contact_activities_text_fallback(
            activities=SAMPLE_ACTIVITIES, contact_id=CONTACT_ID
        )
        assert "## Manage this contact" in out
        manage_idx = out.index("## Manage this contact")
        manage_section = out[manage_idx:]
        self_uri = f"g8://contacts/{CONTACT_ID}/activities"
        assert self_uri not in manage_section

    def test_manage_block_lists_siblings(self):
        out = render_contact_activities_text_fallback(
            activities=SAMPLE_ACTIVITIES, contact_id=CONTACT_ID
        )
        assert f"g8://contacts/{CONTACT_ID}/notes" in out
        assert f"g8://contacts/{CONTACT_ID}/tasks" in out
        assert f"g8://contacts/{CONTACT_ID}/deals" in out
        assert "g8://activities/feed" in out

    def test_overflow_line_when_many(self):
        many = [
            {"activity_type": "call", "subject": f"c{i}", "owner_name": "A"}
            for i in range(30)
        ]
        out = render_contact_activities_text_fallback(
            activities=many, contact_id=CONTACT_ID
        )
        assert "+ 5 more activities" in out

    def test_ends_with_newline(self):
        out = render_contact_activities_text_fallback(
            activities=SAMPLE_ACTIVITIES, contact_id=CONTACT_ID
        )
        assert out.endswith("\n")

    def test_duration_in_text_meta_line(self):
        out = render_contact_activities_text_fallback(
            activities=SAMPLE_ACTIVITIES, contact_id=CONTACT_ID
        )
        # The 45-minute call should mention duration in the meta line
        assert "duration=45 min" in out

    def test_source_in_text_meta_line(self):
        out = render_contact_activities_text_fallback(
            activities=SAMPLE_ACTIVITIES, contact_id=CONTACT_ID
        )
        assert "source=aircall" in out


# =======================================================================
# TestSmoke
# =======================================================================


class TestSmoke:
    def test_both_renderers_callable_with_realistic_payload(self):
        html = render_contact_activities_html(
            activities=SAMPLE_ACTIVITIES,
            contact_id=CONTACT_ID,
            contact=SAMPLE_CONTACT,
        )
        text = render_contact_activities_text_fallback(
            activities=SAMPLE_ACTIVITIES,
            contact_id=CONTACT_ID,
            contact=SAMPLE_CONTACT,
        )
        assert isinstance(html, str) and len(html) > 500
        assert isinstance(text, str) and len(text) > 100

    def test_renderers_idempotent_on_same_input(self):
        a = render_contact_activities_html(
            activities=SAMPLE_ACTIVITIES, contact_id=CONTACT_ID
        )
        b = render_contact_activities_html(
            activities=SAMPLE_ACTIVITIES, contact_id=CONTACT_ID
        )
        assert a == b

    def test_text_renderer_idempotent(self):
        a = render_contact_activities_text_fallback(
            activities=SAMPLE_ACTIVITIES, contact_id=CONTACT_ID
        )
        b = render_contact_activities_text_fallback(
            activities=SAMPLE_ACTIVITIES, contact_id=CONTACT_ID
        )
        assert a == b
