"""Unit tests for Surface #67 — `render_task_detail_html` / text fallback.

Per-task detail: `g8://tasks/{task_id}` (+ `.txt` sibling). Mirrors the
structure of test_gc_doc_detail_renderer.py (Surface #65).

graph8-native design: only `_G8_*` tokens — no Studio legacy hexes.
"""

from __future__ import annotations

import re

import pytest

from mcp_server.g8_mcp_server import app_renderer as ar


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


_TASK_ID = "task_7e1a8c42aaaa4bbb8ccc"


_SAMPLE_TASK: dict = {
    "id": _TASK_ID,
    "entity_type": "contact",
    "entity_id": "42",
    "title": "Follow up with Acme on Q2 proposal",
    "description": (
        "Thomas mentioned wanting to extend the contract.\n"
        "Ask about stakeholder changes.\n\n"
        "- Is Sarah still the decision-maker?\n"
        "- What's the expected close date?"
    ),
    "due_date": "2027-04-25T00:00:00Z",  # future
    "assignee_id": "user_abc123",
    "assignee_name": "Usjid Iqbal",
    "status": "open",
    "priority": 2,  # High
    "task_type": "follow_up",
    "created_by": "user_thomas",
    "created_at": "2026-04-15T10:30:00Z",
    "updated_at": "2026-04-18T14:22:00Z",
}


_LEGACY_STUDIO_HEXES = (
    "#eef2ff",
    "#4338ca",
    "#f59e0b",
    "#166534",
    "#a16207",
    "#7c2d12",
    "#6b7280",
)


# ---------------------------------------------------------------------------
# _task_detail_clip
# ---------------------------------------------------------------------------


class TestClip:
    def test_none(self):
        assert ar._task_detail_clip(None, 100) == ""

    def test_non_string(self):
        assert ar._task_detail_clip(123, 100) == ""

    def test_whitespace(self):
        assert ar._task_detail_clip("   \n\t  ", 100) == ""

    def test_under_cap(self):
        assert ar._task_detail_clip("short", 100) == "short"

    def test_over_cap(self):
        out = ar._task_detail_clip("a" * 200, 50)
        assert len(out) <= 50
        assert out.endswith("…")

    def test_no_escape(self):
        """Clip does NOT escape — callers escape. Avoids double-escape."""
        assert ar._task_detail_clip("<script>", 100) == "<script>"


# ---------------------------------------------------------------------------
# _task_detail_title
# ---------------------------------------------------------------------------


class TestTitle:
    def test_from_title(self):
        assert ar._task_detail_title({"title": "Call Bob"}, "t-1") == "Call Bob"

    def test_none_task(self):
        assert ar._task_detail_title(None, "t-1") == "Task #t-1"

    def test_none_task_no_id(self):
        assert ar._task_detail_title(None, "") == "Task"

    def test_missing_title(self):
        assert ar._task_detail_title({"id": "x"}, "t-1") == "Task #t-1"

    def test_whitespace_title(self):
        assert ar._task_detail_title({"title": "   "}, "t-1") == "Task #t-1"

    def test_non_string_title(self):
        assert ar._task_detail_title({"title": 123}, "t-1") == "Task #t-1"

    def test_escape(self):
        out = ar._task_detail_title({"title": "<script>alert(1)</script>"}, "x")
        assert "<script>" not in out
        assert "&lt;script&gt;" in out

    def test_clip(self):
        out = ar._task_detail_title({"title": "A" * 500}, "x")
        assert len(out) < 500
        assert out.endswith("…")

    def test_fallback_id_escaped(self):
        out = ar._task_detail_title(None, "<evil>")
        assert "<evil>" not in out
        assert "&lt;evil&gt;" in out


# ---------------------------------------------------------------------------
# _task_detail_id_matches
# ---------------------------------------------------------------------------


class TestIdMatches:
    def test_match(self):
        assert ar._task_detail_id_matches({"id": "t-1"}, "t-1") is True

    def test_mismatch(self):
        assert ar._task_detail_id_matches({"id": "t-1"}, "t-2") is False

    def test_none_doc_lenient(self):
        assert ar._task_detail_id_matches(None, "t-1") is True

    def test_non_dict_lenient(self):
        assert ar._task_detail_id_matches("not-a-dict", "t-1") is True

    def test_missing_id_lenient(self):
        assert ar._task_detail_id_matches({}, "t-1") is True

    def test_whitespace_in_uri(self):
        assert ar._task_detail_id_matches({"id": "t-1"}, " t-1 ") is True


# ---------------------------------------------------------------------------
# _task_detail_priority_display
# ---------------------------------------------------------------------------


class TestPriorityDisplay:
    def test_none(self):
        assert ar._task_detail_priority_display(None) == ("—", "muted")

    def test_zero_is_none(self):
        assert ar._task_detail_priority_display(0) == ("None", "muted")

    def test_one_is_urgent(self):
        assert ar._task_detail_priority_display(1) == ("Urgent", "warning")

    def test_two_is_high(self):
        assert ar._task_detail_priority_display(2) == ("High", "primary")

    def test_three_is_normal(self):
        assert ar._task_detail_priority_display(3) == ("Normal", "default")

    def test_four_is_low(self):
        assert ar._task_detail_priority_display(4) == ("Low", "muted")

    def test_out_of_range(self):
        assert ar._task_detail_priority_display(99) == ("—", "muted")

    def test_negative(self):
        assert ar._task_detail_priority_display(-1) == ("—", "muted")

    def test_str_numeric(self):
        assert ar._task_detail_priority_display("2") == ("High", "primary")

    def test_str_garbage(self):
        assert ar._task_detail_priority_display("urgent") == ("—", "muted")

    def test_float(self):
        assert ar._task_detail_priority_display(2.0) == ("High", "primary")

    def test_bool_rejected(self):
        """bool is an int in Python — True would otherwise parse as 1=Urgent."""
        assert ar._task_detail_priority_display(True) == ("—", "muted")
        assert ar._task_detail_priority_display(False) == ("—", "muted")


# ---------------------------------------------------------------------------
# _task_detail_status_accent
# ---------------------------------------------------------------------------


class TestStatusAccent:
    def test_none(self):
        bg, fg, _ = ar._task_detail_status_accent(None)
        assert bg == ar._G8_MUTED_BG
        assert fg == ar._G8_TEXT_MUTED

    def test_completed_positive(self):
        bg, fg, _ = ar._task_detail_status_accent("completed")
        assert bg == ar._G8_POSITIVE_BG
        assert fg == ar._G8_POSITIVE_FG

    def test_open_primary(self):
        bg, fg, _ = ar._task_detail_status_accent("open")
        assert bg == ar._G8_ACCENT_BG
        assert fg == ar._G8_PRIMARY

    def test_in_progress_primary(self):
        bg, fg, _ = ar._task_detail_status_accent("in_progress")
        assert fg == ar._G8_PRIMARY

    def test_overdue_warning(self):
        bg, fg, _ = ar._task_detail_status_accent("overdue")
        assert bg == ar._G8_WARNING_BG
        assert fg == ar._G8_WARNING_FG

    def test_archived_muted(self):
        bg, fg, _ = ar._task_detail_status_accent("archived")
        assert bg == ar._G8_MUTED_BG

    def test_unknown_muted(self):
        bg, fg, _ = ar._task_detail_status_accent("weird_status")
        assert fg == ar._G8_TEXT_MUTED

    def test_case_insensitive(self):
        assert (
            ar._task_detail_status_accent("COMPLETED")
            == ar._task_detail_status_accent("completed")
        )


# ---------------------------------------------------------------------------
# _task_detail_is_overdue
# ---------------------------------------------------------------------------


class TestIsOverdue:
    def test_past_date_open(self):
        assert ar._task_detail_is_overdue("2020-01-01T00:00:00Z", "open") is True

    def test_future_date(self):
        assert ar._task_detail_is_overdue("2099-01-01T00:00:00Z", "open") is False

    def test_past_date_completed(self):
        assert ar._task_detail_is_overdue("2020-01-01T00:00:00Z", "completed") is False

    def test_past_date_cancelled(self):
        assert ar._task_detail_is_overdue("2020-01-01T00:00:00Z", "cancelled") is False

    def test_none_due(self):
        assert ar._task_detail_is_overdue(None, "open") is False

    def test_empty_due(self):
        assert ar._task_detail_is_overdue("", "open") is False

    def test_garbage_due(self):
        assert ar._task_detail_is_overdue("not-a-date", "open") is False

    def test_non_string_due(self):
        assert ar._task_detail_is_overdue(12345, "open") is False


# ---------------------------------------------------------------------------
# _task_detail_format_datetime / _task_detail_format_date
# ---------------------------------------------------------------------------


class TestFormatDatetime:
    def test_none(self):
        assert ar._task_detail_format_datetime(None) == ""

    def test_empty(self):
        assert ar._task_detail_format_datetime("") == ""

    def test_iso_utc(self):
        out = ar._task_detail_format_datetime("2026-04-18T14:22:00Z")
        assert out == "2026-04-18 14:22"

    def test_iso_with_tz(self):
        out = ar._task_detail_format_datetime("2026-04-18T14:22:00+00:00")
        assert out == "2026-04-18 14:22"

    def test_garbage(self):
        assert ar._task_detail_format_datetime("not-a-date") == ""

    def test_non_string(self):
        assert ar._task_detail_format_datetime(12345) == ""


class TestFormatDate:
    def test_none(self):
        assert ar._task_detail_format_date(None) == ""

    def test_iso(self):
        out = ar._task_detail_format_date("2026-04-25T00:00:00Z")
        assert out == "2026-04-25"

    def test_garbage(self):
        assert ar._task_detail_format_date("bogus") == ""


# ---------------------------------------------------------------------------
# _task_detail_chip
# ---------------------------------------------------------------------------


class TestChip:
    def test_basic(self):
        out = ar._task_detail_chip("OPEN")
        assert "OPEN" in out
        assert "<span" in out

    def test_escape(self):
        out = ar._task_detail_chip("<script>")
        assert "<script>" not in out
        assert "&lt;script&gt;" in out


# ---------------------------------------------------------------------------
# _task_detail_kpi_card
# ---------------------------------------------------------------------------


class TestKpiCard:
    def test_default(self):
        out = ar._task_detail_kpi_card("Priority", "High")
        assert "Priority" in out
        assert "High" in out
        assert ar._G8_CARD_BG in out

    def test_primary(self):
        out = ar._task_detail_kpi_card("Priority", "High", accent="primary")
        assert ar._G8_PRIMARY in out
        assert ar._G8_ACCENT_BG in out

    def test_warning(self):
        out = ar._task_detail_kpi_card("Due", "2020-01-01", accent="warning")
        assert ar._G8_WARNING_BG in out
        assert ar._G8_WARNING_FG in out

    def test_muted(self):
        out = ar._task_detail_kpi_card("Assignee", "—", accent="muted")
        assert ar._G8_MUTED_BG in out
        assert ar._G8_TEXT_MUTED in out


# ---------------------------------------------------------------------------
# _task_detail_description_section
# ---------------------------------------------------------------------------


class TestDescriptionSection:
    def test_none(self):
        assert ar._task_detail_description_section(None) == ""

    def test_non_string(self):
        assert ar._task_detail_description_section(123) == ""

    def test_whitespace(self):
        assert ar._task_detail_description_section("    ") == ""

    def test_short(self):
        out = ar._task_detail_description_section("Short desc")
        assert "Short desc" in out
        assert "Description" in out

    def test_multi_line(self):
        out = ar._task_detail_description_section("line1\nline2")
        assert "<br>" in out

    def test_escape_first(self):
        out = ar._task_detail_description_section("<evil>")
        assert "<evil>" not in out
        assert "&lt;evil&gt;" in out

    def test_clip_at_cap(self):
        out = ar._task_detail_description_section("x" * (ar._MAX_TASK_DETAIL_DESCRIPTION_LEN + 100))
        assert "…" in out


# ---------------------------------------------------------------------------
# _task_detail_metadata_section
# ---------------------------------------------------------------------------


class TestMetadataSection:
    def test_empty(self):
        assert ar._task_detail_metadata_section([]) == ""

    def test_basic(self):
        out = ar._task_detail_metadata_section([("Created", "2026-04-18 10:00")])
        assert "Created" in out
        assert "2026-04-18 10:00" in out
        assert "Details" in out


# ---------------------------------------------------------------------------
# empty-state
# ---------------------------------------------------------------------------


class TestEmptyState:
    def test_not_found(self):
        out = ar._task_detail_empty_state_html(mode="not_found", task_id="xyz")
        assert "Task not found" in out
        assert "xyz" in out

    def test_unavailable(self):
        out = ar._task_detail_empty_state_html(mode="unavailable", task_id="xyz")
        assert "Task detail not available" in out

    def test_id_escaped(self):
        out = ar._task_detail_empty_state_html(mode="not_found", task_id="<evil>")
        assert "<evil>" not in out
        assert "&lt;evil&gt;" in out

    def test_no_js(self):
        out = ar._task_detail_empty_state_html(mode="unavailable", task_id="x")
        assert "<script" not in out.lower()
        assert "javascript:" not in out.lower()
        assert "onerror=" not in out.lower()


# ---------------------------------------------------------------------------
# render_task_detail_html
# ---------------------------------------------------------------------------


class TestRenderHtml:
    def test_basic(self):
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=_SAMPLE_TASK)
        assert "Follow up with Acme on Q2 proposal" in out
        assert "<!DOCTYPE html>" in out

    def test_none_task(self):
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=None)
        assert "Task detail not available" in out

    def test_non_dict_task(self):
        out = ar.render_task_detail_html(task_id=_TASK_ID, task="not-a-dict")
        assert "Task detail not available" in out

    def test_id_mismatch(self):
        out = ar.render_task_detail_html(task_id="other-id", task=_SAMPLE_TASK)
        assert "Task not found" in out

    def test_title(self):
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=_SAMPLE_TASK)
        assert "Follow up with Acme on Q2 proposal" in out

    def test_status_chip_rendered(self):
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=_SAMPLE_TASK)
        assert "OPEN" in out

    def test_task_type_chip_rendered(self):
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=_SAMPLE_TASK)
        assert "follow_up" in out

    def test_priority_display(self):
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=_SAMPLE_TASK)
        # Priority 2 → "High"
        assert "High" in out

    def test_priority_urgent(self):
        task = {**_SAMPLE_TASK, "priority": 1}
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=task)
        assert "Urgent" in out

    def test_priority_none_0(self):
        task = {**_SAMPLE_TASK, "priority": 0}
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=task)
        # Priority 0 is "None"
        assert "None" in out or "—" in out

    def test_priority_missing(self):
        task = {k: v for k, v in _SAMPLE_TASK.items() if k != "priority"}
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=task)
        assert "—" in out  # em-dash fallback

    def test_due_date_shown(self):
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=_SAMPLE_TASK)
        assert "2027-04-25" in out

    def test_overdue_chip_shown(self):
        task = {**_SAMPLE_TASK, "due_date": "2020-01-01T00:00:00Z"}
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=task)
        assert "OVERDUE" in out

    def test_overdue_not_shown_when_completed(self):
        task = {
            **_SAMPLE_TASK,
            "due_date": "2020-01-01T00:00:00Z",
            "status": "completed",
        }
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=task)
        assert "OVERDUE" not in out

    def test_assignee_shown(self):
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=_SAMPLE_TASK)
        assert "Usjid Iqbal" in out

    def test_assignee_fallback_to_id(self):
        task = {k: v for k, v in _SAMPLE_TASK.items() if k != "assignee_name"}
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=task)
        assert "user_abc123" in out

    def test_description_rendered(self):
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=_SAMPLE_TASK)
        assert "stakeholder changes" in out

    def test_parent_contact_drill_up(self):
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=_SAMPLE_TASK)
        # entity_type=contact + entity_id=42 → drill-up pointers
        assert "g8://contacts/42" in out
        assert "g8://contacts/42/tasks" in out

    def test_no_parent_contact_drill_up_when_non_contact(self):
        task = {**_SAMPLE_TASK, "entity_type": "company", "entity_id": "99"}
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=task)
        assert "g8://contacts/99" not in out

    def test_drill_up_tasks_dashboard(self):
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=_SAMPLE_TASK)
        assert "g8://tasks/dashboard" in out

    def test_drill_up_copilot_home(self):
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=_SAMPLE_TASK)
        assert "g8://copilot/home" in out

    def test_no_javascript(self):
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=_SAMPLE_TASK)
        assert "<script" not in out.lower()
        assert "javascript:" not in out.lower()
        assert " onclick=" not in out.lower()
        assert " onerror=" not in out.lower()

    def test_no_legacy_hexes(self):
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=_SAMPLE_TASK).lower()
        for hex_color in _LEGACY_STUDIO_HEXES:
            assert hex_color not in out, f"Legacy Studio hex {hex_color} leaked"

    def test_uses_graph8_primary(self):
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=_SAMPLE_TASK)
        assert "#7d2df3" in out

    def test_uses_graph8_border(self):
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=_SAMPLE_TASK)
        assert "#dfdfdf" in out

    def test_uses_aeonik(self):
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=_SAMPLE_TASK)
        assert "Aeonik" in out

    def test_no_single_side_colored_accent_border(self):
        """Single-side colored accent borders are an AI-tell; use neutral borders."""
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=_SAMPLE_TASK)
        for color in (ar._G8_PRIMARY, ar._G8_POSITIVE_FG, ar._G8_WARNING_FG, ar._G8_DESTRUCTIVE_FG):
            for side in ("border-left", "border-right", "border-top", "border-bottom"):
                pattern = re.compile(rf"{side}[^;]*{re.escape(color)}", re.IGNORECASE)
                assert not pattern.search(out), (
                    f"single-side colored accent border using {color} on {side} detected"
                )

    def test_xss_title(self):
        task = {**_SAMPLE_TASK, "title": "<script>alert(1)</script>"}
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=task)
        assert "<script>alert(1)</script>" not in out
        assert "&lt;script&gt;" in out

    def test_xss_description(self):
        task = {**_SAMPLE_TASK, "description": "<img src=x onerror=alert(1)>"}
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=task)
        assert "<img src=x" not in out
        assert "&lt;img src=x" in out

    def test_xss_assignee_name(self):
        task = {**_SAMPLE_TASK, "assignee_name": "<b>nope</b>"}
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=task)
        assert "<b>nope</b>" not in out
        assert "&lt;b&gt;nope&lt;/b&gt;" in out

    def test_xss_entity_id_in_drill_up(self):
        task = {**_SAMPLE_TASK, "entity_id": "<evil>"}
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=task)
        assert "<evil>" not in out

    def test_xss_task_id_in_fallback_title(self):
        out = ar.render_task_detail_html(task_id="<evil>", task=None)
        assert "<evil>" not in out

    def test_minimal(self):
        out = ar.render_task_detail_html(
            task_id="m-1",
            task={"id": "m-1", "title": "Minimal task"},
        )
        assert "Minimal task" in out
        assert "<!DOCTYPE html>" in out

    def test_well_formed(self):
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=_SAMPLE_TASK)
        assert out.count("<html>") == out.count("</html>") == 1
        assert out.count("<body") == out.count("</body>") == 1
        assert out.count("<head>") == out.count("</head>") == 1


# ---------------------------------------------------------------------------
# render_task_detail_text_fallback
# ---------------------------------------------------------------------------


class TestTextFallback:
    def test_basic(self):
        out = ar.render_task_detail_text_fallback(task_id=_TASK_ID, task=_SAMPLE_TASK)
        assert out.startswith("# Follow up with Acme")
        assert out.endswith("\n")

    def test_none_task(self):
        out = ar.render_task_detail_text_fallback(task_id=_TASK_ID, task=None)
        assert "Task detail not available" in out

    def test_id_mismatch(self):
        out = ar.render_task_detail_text_fallback(task_id="other", task=_SAMPLE_TASK)
        assert "No task with id" in out

    def test_status_inline(self):
        out = ar.render_task_detail_text_fallback(task_id=_TASK_ID, task=_SAMPLE_TASK)
        assert "OPEN" in out

    def test_kpis_section(self):
        out = ar.render_task_detail_text_fallback(task_id=_TASK_ID, task=_SAMPLE_TASK)
        assert "## KPIs" in out
        assert "Priority: High" in out

    def test_description_section(self):
        out = ar.render_task_detail_text_fallback(task_id=_TASK_ID, task=_SAMPLE_TASK)
        assert "## Description" in out
        assert "stakeholder changes" in out

    def test_related_surfaces(self):
        out = ar.render_task_detail_text_fallback(task_id=_TASK_ID, task=_SAMPLE_TASK)
        assert "## Related surfaces" in out
        assert "g8://tasks/dashboard" in out
        assert "g8://contacts/42" in out
        assert "g8://copilot/home" in out

    def test_no_html(self):
        out = ar.render_task_detail_text_fallback(task_id=_TASK_ID, task=_SAMPLE_TASK)
        assert "<div" not in out
        assert "<span" not in out
        assert "<script" not in out

    def test_xss_plaintext(self):
        task = {**_SAMPLE_TASK, "title": "<script>alert(1)</script>"}
        out = ar.render_task_detail_text_fallback(task_id=_TASK_ID, task=task)
        # In plaintext mode the raw <script> tag is inert — but we should
        # still preserve it literally (nothing to escape into).
        assert "<script>alert(1)</script>" in out

    def test_overdue_inline(self):
        task = {**_SAMPLE_TASK, "due_date": "2020-01-01T00:00:00Z"}
        out = ar.render_task_detail_text_fallback(task_id=_TASK_ID, task=task)
        assert "OVERDUE" in out


# ---------------------------------------------------------------------------
# Smoke
# ---------------------------------------------------------------------------


class TestSmoke:
    def test_html_roundtrip(self):
        out = ar.render_task_detail_html(task_id=_TASK_ID, task=_SAMPLE_TASK)
        assert len(out) > 1000
        assert "<!DOCTYPE html>" in out
        assert out.rstrip().endswith("</html>")

    def test_empty_roundtrip(self):
        out = ar.render_task_detail_html(task_id="x", task=None)
        assert "<!DOCTYPE html>" in out
        assert out.rstrip().endswith("</html>")
