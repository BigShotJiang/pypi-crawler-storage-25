"""Tests for the audience syncs dashboard renderer (upgrade 4 — #16)."""

from __future__ import annotations

from g8_mcp_server import app_renderer
from g8_mcp_server.app_renderer import (
    _format_cadence,
    _group_syncs_by_platform,
    _sync_status_color,
    render_audience_syncs_dashboard_html,
    render_audience_syncs_dashboard_text_fallback,
)


def _sync(
    id_: int = 1,
    audience_id: int = 100,
    platform: str | None = "meta",
    mode: str | None = "mirror",
    refresh_cadence_hours: int | None = 24,
    is_active: bool | None = True,
    platform_audience_name: str | None = "High-Intent Leads",
    last_sync_at: str | None = "2026-04-10T12:00:00Z",
    status: str | None = "success",
) -> dict:
    return {
        "id": id_,
        "audience_id": audience_id,
        "platform": platform,
        "mode": mode,
        "refresh_cadence_hours": refresh_cadence_hours,
        "is_active": is_active,
        "platform_audience_name": platform_audience_name,
        "last_sync_at": last_sync_at,
        "status": status,
    }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class TestSyncStatusColor:
    def test_success(self):
        # Backported to graph8 tokens 2026-04-21
        c = _sync_status_color("success")
        assert c["fg"] == "#059669"  # _G8_POSITIVE_FG

    def test_running(self):
        c = _sync_status_color("running")
        assert c["fg"] == "#1e40af"

    def test_failed(self):
        c = _sync_status_color("failed")
        assert c["fg"] == "#b91c1c"  # _G8_DESTRUCTIVE_ON_LIGHT_FG

    def test_unknown_active_true(self):
        c = _sync_status_color("weird", is_active=True)
        # Fallback: is_active True → active green
        assert c["fg"] == "#059669"  # _G8_POSITIVE_FG

    def test_unknown_active_false(self):
        c = _sync_status_color("weird", is_active=False)
        # Fallback: is_active False → inactive gray
        assert c["fg"] == "#777777"

    def test_none_active_true(self):
        c = _sync_status_color(None, is_active=True)
        assert c["fg"] == "#059669"  # _G8_POSITIVE_FG

    def test_none_active_false(self):
        c = _sync_status_color(None, is_active=False)
        assert c["fg"] == "#777777"

    def test_case_insensitive(self):
        c1 = _sync_status_color("FAILED")
        c2 = _sync_status_color("failed")
        assert c1 == c2

    def test_no_banned_fg_hexes(self):
        banned = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}
        from mcp_server.g8_mcp_server.app_renderer import _SYNC_STATUS_COLORS
        for k, v in _SYNC_STATUS_COLORS.items():
            assert v["fg"].lower() not in banned, (
                f"status={k!r} fg={v['fg']!r} is banned"
            )


class TestGroupSyncsByPlatform:
    def test_preferred_order(self):
        syncs = [
            _sync(platform="x"),
            _sync(platform="meta"),
            _sync(platform="google"),
            _sync(platform="linkedin"),
        ]
        grouped = _group_syncs_by_platform(syncs)
        assert list(grouped.keys()) == ["meta", "linkedin", "google", "x"]

    def test_unknown_platform_after_preferred(self):
        syncs = [
            _sync(platform="mystery_platform"),
            _sync(platform="meta"),
        ]
        grouped = _group_syncs_by_platform(syncs)
        keys = list(grouped.keys())
        assert keys[0] == "meta"
        assert "mystery_platform" in keys

    def test_missing_platform_to_other(self):
        syncs = [_sync(platform=None)]
        grouped = _group_syncs_by_platform(syncs)
        assert "other" in grouped

    def test_case_insensitive(self):
        syncs = [
            _sync(platform="META"),
            _sync(platform="Meta"),
            _sync(platform="meta"),
        ]
        grouped = _group_syncs_by_platform(syncs)
        assert len(grouped["meta"]) == 3

    def test_empty(self):
        assert _group_syncs_by_platform([]) == {}


class TestFormatCadence:
    def test_hours_under_day(self):
        assert _format_cadence(6) == "every 6h"

    def test_daily(self):
        assert _format_cadence(24) == "daily"

    def test_multiple_days(self):
        assert _format_cadence(72) == "every 3d"

    def test_non_round_day_stays_in_hours(self):
        assert _format_cadence(30) == "every 30h"

    def test_zero_is_empty(self):
        assert _format_cadence(0) == ""

    def test_negative_is_empty(self):
        assert _format_cadence(-1) == ""

    def test_none_is_empty(self):
        assert _format_cadence(None) == ""

    def test_non_int_is_empty(self):
        assert _format_cadence("24") == ""  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# HTML renderer
# ---------------------------------------------------------------------------


class TestRenderAudienceSyncsHtml:
    def test_empty_state_none(self):
        html_out = render_audience_syncs_dashboard_html(syncs=None)
        assert "No audience syncs yet" in html_out

    def test_empty_state_list(self):
        html_out = render_audience_syncs_dashboard_html(syncs=[])
        assert "No audience syncs yet" in html_out

    def test_non_list_input(self):
        html_out = render_audience_syncs_dashboard_html(syncs="nope")  # type: ignore[arg-type]
        assert "No audience syncs yet" in html_out

    def test_only_garbage(self):
        html_out = render_audience_syncs_dashboard_html(
            syncs=[None, "x", 1]  # type: ignore[list-item]
        )
        assert "No audience syncs yet" in html_out

    def test_renders_sync(self):
        html_out = render_audience_syncs_dashboard_html(syncs=[_sync()])
        assert "High-Intent Leads" in html_out
        assert "success" in html_out
        assert "mirror" in html_out
        assert "daily" in html_out

    def test_platform_heading(self):
        html_out = render_audience_syncs_dashboard_html(
            syncs=[_sync(platform="meta")]
        )
        assert "Meta" in html_out

    def test_linkedin_platform_label(self):
        html_out = render_audience_syncs_dashboard_html(
            syncs=[_sync(platform="linkedin")]
        )
        assert "LinkedIn" in html_out

    def test_x_twitter_platform_label(self):
        html_out = render_audience_syncs_dashboard_html(
            syncs=[_sync(platform="x")]
        )
        assert "X (Twitter)" in html_out

    def test_google_platform_label(self):
        html_out = render_audience_syncs_dashboard_html(
            syncs=[_sync(platform="google")]
        )
        assert "Google Ads" in html_out

    def test_active_count_header(self):
        html_out = render_audience_syncs_dashboard_html(
            syncs=[
                _sync(id_=1, is_active=True),
                _sync(id_=2, is_active=True),
                _sync(id_=3, is_active=False),
            ]
        )
        assert "2 active" in html_out

    def test_platform_active_count(self):
        html_out = render_audience_syncs_dashboard_html(
            syncs=[
                _sync(id_=1, platform="meta", is_active=True),
                _sync(id_=2, platform="meta", is_active=False),
            ]
        )
        assert "1/2 active" in html_out

    def test_preferred_platform_order(self):
        html_out = render_audience_syncs_dashboard_html(
            syncs=[
                _sync(id_=1, platform="x", platform_audience_name="X Aud"),
                _sync(id_=2, platform="meta", platform_audience_name="Meta Aud"),
                _sync(id_=3, platform="linkedin", platform_audience_name="LI Aud"),
            ]
        )
        meta_pos = html_out.find("Meta Aud")
        li_pos = html_out.find("LI Aud")
        x_pos = html_out.find("X Aud")
        assert meta_pos < li_pos < x_pos

    def test_missing_name_fallback_to_audience_id(self):
        html_out = render_audience_syncs_dashboard_html(
            syncs=[_sync(platform_audience_name=None, audience_id=42)]
        )
        assert "Audience #42" in html_out

    def test_missing_both_ids_fallback(self):
        html_out = render_audience_syncs_dashboard_html(
            syncs=[_sync(platform_audience_name=None, audience_id=None, id_=None)]
        )
        assert "Audience #?" in html_out

    def test_active_dot_for_active_sync(self):
        html_out = render_audience_syncs_dashboard_html(
            syncs=[_sync(is_active=True)]
        )
        assert "active-dot" in html_out

    def test_inactive_dot_for_inactive_sync(self):
        html_out = render_audience_syncs_dashboard_html(
            syncs=[_sync(is_active=False)]
        )
        assert "inactive-dot" in html_out

    def test_status_color_success_green(self):
        html_out = render_audience_syncs_dashboard_html(
            syncs=[_sync(status="success")]
        )
        assert "#d1fae5" in html_out

    def test_status_color_failed_red(self):
        html_out = render_audience_syncs_dashboard_html(
            syncs=[_sync(status="failed")]
        )
        assert "#fee2e2" in html_out

    def test_meta_row_without_cadence(self):
        html_out = render_audience_syncs_dashboard_html(
            syncs=[_sync(refresh_cadence_hours=None, mode=None, last_sync_at=None)]
        )
        # Should not crash; meta row should be empty or absent
        assert "High-Intent Leads" in html_out

    def test_org_label(self):
        html_out = render_audience_syncs_dashboard_html(
            syncs=[_sync()], org_label="Acme"
        )
        assert "Acme" in html_out


class TestEscaping:
    def test_audience_name_escaped(self):
        html_out = render_audience_syncs_dashboard_html(
            syncs=[_sync(platform_audience_name="<script>bad()</script>")]
        )
        assert "<script>bad" not in html_out
        assert "&lt;script&gt;" in html_out

    def test_mode_escaped(self):
        html_out = render_audience_syncs_dashboard_html(
            syncs=[_sync(mode="<xss>")]
        )
        assert "<xss>" not in html_out

    def test_status_escaped(self):
        html_out = render_audience_syncs_dashboard_html(
            syncs=[_sync(status="<img>")]
        )
        assert "<img>" not in html_out


class TestBounds:
    def test_max_syncs_rendered(self):
        # 70 syncs, cap is 50 — footer note must appear
        syncs = [_sync(id_=i, audience_id=100 + i) for i in range(70)]
        html_out = render_audience_syncs_dashboard_html(syncs=syncs)
        assert "20 sync(s) omitted" in html_out

    def test_long_audience_name_truncated(self):
        html_out = render_audience_syncs_dashboard_html(
            syncs=[_sync(platform_audience_name="x" * 5000)]
        )
        assert "…" in html_out


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------


class TestTextFallback:
    def test_empty_none(self):
        out = render_audience_syncs_dashboard_text_fallback(syncs=None)
        assert "No audience syncs yet" in out

    def test_empty_list(self):
        out = render_audience_syncs_dashboard_text_fallback(syncs=[])
        assert "No audience syncs yet" in out

    def test_non_list(self):
        out = render_audience_syncs_dashboard_text_fallback(syncs="x")  # type: ignore[arg-type]
        assert "No audience syncs yet" in out

    def test_only_garbage(self):
        out = render_audience_syncs_dashboard_text_fallback(
            syncs=[None, "x", 1]  # type: ignore[list-item]
        )
        assert "No audience syncs yet" in out

    def test_renders_sync(self):
        out = render_audience_syncs_dashboard_text_fallback(syncs=[_sync()])
        assert "High-Intent Leads" in out
        assert "(success)" in out

    def test_platform_heading(self):
        out = render_audience_syncs_dashboard_text_fallback(
            syncs=[_sync(platform="meta")]
        )
        assert "## Meta" in out

    def test_active_marker(self):
        out = render_audience_syncs_dashboard_text_fallback(
            syncs=[_sync(is_active=True)]
        )
        assert "●" in out

    def test_inactive_marker(self):
        out = render_audience_syncs_dashboard_text_fallback(
            syncs=[_sync(is_active=False)]
        )
        assert "○" in out

    def test_active_count_line(self):
        out = render_audience_syncs_dashboard_text_fallback(
            syncs=[
                _sync(id_=1, is_active=True),
                _sync(id_=2, is_active=False),
            ]
        )
        assert "1 active" in out

    def test_cadence_line(self):
        out = render_audience_syncs_dashboard_text_fallback(
            syncs=[_sync(refresh_cadence_hours=24)]
        )
        assert "daily" in out

    def test_last_sync_line(self):
        out = render_audience_syncs_dashboard_text_fallback(
            syncs=[_sync(last_sync_at="2026-04-10T12:00:00Z")]
        )
        assert "last sync 2026-04-10" in out

    def test_org_label(self):
        out = render_audience_syncs_dashboard_text_fallback(
            syncs=[_sync()], org_label="Acme"
        )
        assert "# Audience Syncs — Acme" in out

    def test_max_cap_footer(self):
        syncs = [_sync(id_=i) for i in range(70)]
        out = render_audience_syncs_dashboard_text_fallback(syncs=syncs)
        assert "more sync(s)" in out

    def test_no_html_leak(self):
        out = render_audience_syncs_dashboard_text_fallback(
            syncs=[_sync(platform_audience_name="<tag>")]
        )
        assert "<html>" not in out
        assert "<body>" not in out


# ---------------------------------------------------------------------------
# Caps sanity
# ---------------------------------------------------------------------------


class TestCapsExist:
    def test_constants(self):
        assert app_renderer._MAX_AUDIENCE_SYNCS_RENDERED >= 10
        assert app_renderer._MAX_SYNC_NAME_LEN >= 50
