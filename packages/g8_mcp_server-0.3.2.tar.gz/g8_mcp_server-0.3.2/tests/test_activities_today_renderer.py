"""Unit tests for Surface #86 — g8://activities/today.

TEMPORAL axis-filter (eighth distinct backend-filter pattern in Upgrade
4): 2-seg STATIC resource, no URI capture, filters activities by
occurred_at >= today 00:00 UTC. Sibling under ``g8://activities/``:
- #11 ``g8://activities/feed`` (recent, not today-only)
- #86 ``g8://activities/today`` (this surface)

Locked invariants:
- NEW stats signature for activities entity:
    Total / Most common type / Peak hour / Contacts touched
- Hour-bucketed grid (not date-bucketed).
- graph8 design tokens ONLY (no banned Studio hexes).
- Client-side today-filter on top of backend ``?since={bound}``.
- Cross-entity drill-up to tasks/deals/contacts/copilot home.
"""

from __future__ import annotations

import re

import pytest

from mcp_server.g8_mcp_server import app_renderer as ar


# ---------------------------------------------------------------------------
# Helpers / constants
# ---------------------------------------------------------------------------

TODAY_ISO = "2026-04-21T00:00:00Z"
TODAY_DATE = "2026-04-21"
YESTERDAY_DATE = "2026-04-20"
TOMORROW_DATE = "2026-04-22"


def _today(hour: int = 9, minute: int = 0) -> str:
    return f"{TODAY_DATE}T{hour:02d}:{minute:02d}:00Z"


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------


class TestConstants:
    def test_max_rendered_cap(self):
        assert ar._MAX_ACTIVITIES_RENDERED == 80

    def test_type_labels_map_exists(self):
        assert isinstance(ar._ACTIVITIES_TODAY_TYPE_LABELS, dict)
        # Each label should be human-readable (first letter uppercase).
        for k, v in ar._ACTIVITIES_TODAY_TYPE_LABELS.items():
            assert isinstance(v, str) and v
            assert v[0].isupper()

    def test_type_labels_cover_common_types(self):
        for key in ("note", "email", "call", "meeting", "task", "event"):
            assert key in ar._ACTIVITIES_TODAY_TYPE_LABELS

    def test_renderer_functions_exported(self):
        assert callable(ar.render_activities_today_html)
        assert callable(ar.render_activities_today_text_fallback)


# ---------------------------------------------------------------------------
# UTC bound helper
# ---------------------------------------------------------------------------


class TestUtcBound:
    def test_returns_iso_zulu(self):
        out = ar._activities_today_utc_bound()
        assert isinstance(out, str)
        # "YYYY-MM-DDT00:00:00Z"
        assert re.match(r"^\d{4}-\d{2}-\d{2}T00:00:00Z$", out), out

    def test_is_00_00_00(self):
        out = ar._activities_today_utc_bound()
        assert out.endswith("T00:00:00Z")


# ---------------------------------------------------------------------------
# is_today
# ---------------------------------------------------------------------------


class TestIsToday:
    def test_exact_match(self):
        assert ar._activities_today_is_today(_today(12), bound_iso=TODAY_ISO)

    def test_yesterday_is_not_today(self):
        assert not ar._activities_today_is_today(
            f"{YESTERDAY_DATE}T23:59:59Z", bound_iso=TODAY_ISO
        )

    def test_tomorrow_is_not_today(self):
        assert not ar._activities_today_is_today(
            f"{TOMORROW_DATE}T00:00:00Z", bound_iso=TODAY_ISO
        )

    def test_midnight_today_is_today(self):
        assert ar._activities_today_is_today(
            f"{TODAY_DATE}T00:00:00Z", bound_iso=TODAY_ISO
        )

    def test_none_is_not_today(self):
        assert not ar._activities_today_is_today(None, bound_iso=TODAY_ISO)

    def test_empty_is_not_today(self):
        assert not ar._activities_today_is_today("", bound_iso=TODAY_ISO)

    def test_whitespace_is_not_today(self):
        assert not ar._activities_today_is_today("   ", bound_iso=TODAY_ISO)

    def test_non_string_is_not_today(self):
        assert not ar._activities_today_is_today(12345, bound_iso=TODAY_ISO)  # type: ignore[arg-type]
        assert not ar._activities_today_is_today(None, bound_iso=TODAY_ISO)

    def test_malformed_iso_is_not_today(self):
        assert not ar._activities_today_is_today("2026/04/21", bound_iso=TODAY_ISO)
        assert not ar._activities_today_is_today("2026-04-2", bound_iso=TODAY_ISO)

    def test_uses_current_clock_when_no_bound(self):
        # Without explicit bound, truly-today timestamps should match.
        from datetime import datetime, timezone

        now_iso = (
            datetime.now(tz=timezone.utc).replace(microsecond=0).isoformat().replace(
                "+00:00", "Z"
            )
        )
        assert ar._activities_today_is_today(now_iso)

    def test_bound_from_different_day_rejects_today_prefix(self):
        # If bound says yesterday, today's dates should not match.
        yesterday_bound = f"{YESTERDAY_DATE}T00:00:00Z"
        assert not ar._activities_today_is_today(_today(9), bound_iso=yesterday_bound)


# ---------------------------------------------------------------------------
# Filter
# ---------------------------------------------------------------------------


class TestFilter:
    def test_keeps_today_drops_yesterday(self):
        activities = [
            {"id": 1, "occurred_at": _today(8)},
            {"id": 2, "occurred_at": f"{YESTERDAY_DATE}T22:00:00Z"},
            {"id": 3, "occurred_at": _today(14)},
        ]
        result = ar._activities_today_filter(activities, bound_iso=TODAY_ISO)
        assert [a["id"] for a in result] == [1, 3]

    def test_non_list_returns_empty(self):
        assert ar._activities_today_filter(None, bound_iso=TODAY_ISO) == []
        assert ar._activities_today_filter("bad", bound_iso=TODAY_ISO) == []  # type: ignore[arg-type]

    def test_non_dict_items_filtered(self):
        result = ar._activities_today_filter(
            [None, "hi", 5, {"occurred_at": _today(9)}],  # type: ignore[list-item]
            bound_iso=TODAY_ISO,
        )
        assert len(result) == 1

    def test_empty_list_returns_empty(self):
        assert ar._activities_today_filter([], bound_iso=TODAY_ISO) == []

    def test_no_mutation(self):
        activities = [
            {"id": 1, "occurred_at": _today(8)},
            {"id": 2, "occurred_at": f"{YESTERDAY_DATE}T10:00:00Z"},
        ]
        original = list(activities)
        _ = ar._activities_today_filter(activities, bound_iso=TODAY_ISO)
        assert activities == original


# ---------------------------------------------------------------------------
# Hour bucket
# ---------------------------------------------------------------------------


class TestHourBucket:
    def test_parses_00(self):
        assert ar._activities_today_hour_bucket(f"{TODAY_DATE}T00:15:00Z") == 0

    def test_parses_09(self):
        assert ar._activities_today_hour_bucket(f"{TODAY_DATE}T09:45:00Z") == 9

    def test_parses_23(self):
        assert ar._activities_today_hour_bucket(f"{TODAY_DATE}T23:59:59Z") == 23

    def test_space_separator_accepted(self):
        assert ar._activities_today_hour_bucket(f"{TODAY_DATE} 14:00:00") == 14

    def test_malformed_separator_returns_none(self):
        # No T/space at position 10 — hour bucket cannot locate HH.
        assert ar._activities_today_hour_bucket("2026-04-21X10:00:00") is None

    def test_none_returns_none(self):
        assert ar._activities_today_hour_bucket(None) is None

    def test_empty_returns_none(self):
        assert ar._activities_today_hour_bucket("") is None

    def test_non_string_returns_none(self):
        assert ar._activities_today_hour_bucket(12345) is None  # type: ignore[arg-type]

    def test_too_short_returns_none(self):
        assert ar._activities_today_hour_bucket("2026-04-21") is None

    def test_out_of_range_returns_none(self):
        # 25 is invalid.
        assert ar._activities_today_hour_bucket(f"{TODAY_DATE}T25:00:00Z") is None

    def test_negative_hour_rejected(self):
        # "-5" parses as -5 int, which is out of 0..23 range.
        assert ar._activities_today_hour_bucket(f"{TODAY_DATE}T-5:00:00Z") is None

    def test_unparseable_hh_returns_none(self):
        assert ar._activities_today_hour_bucket(f"{TODAY_DATE}TXX:00:00Z") is None


# ---------------------------------------------------------------------------
# Group by hour
# ---------------------------------------------------------------------------


class TestGroupByHour:
    def test_groups_distinct_hours(self):
        activities = [
            {"id": 1, "occurred_at": _today(9, 30)},
            {"id": 2, "occurred_at": _today(9, 45)},
            {"id": 3, "occurred_at": _today(14, 0)},
        ]
        grouped = ar._activities_today_group_by_hour(activities)
        # 14 comes first (highest hour); then 9.
        assert [k for k, _ in grouped] == [14, 9]
        assert len(grouped[0][1]) == 1
        assert len(grouped[1][1]) == 2

    def test_unknown_hour_goes_last(self):
        activities = [
            {"id": 1, "occurred_at": _today(10)},
            {"id": 2, "occurred_at": "not-a-timestamp"},
        ]
        grouped = ar._activities_today_group_by_hour(activities)
        keys = [k for k, _ in grouped]
        assert keys == [10, None]

    def test_non_dict_filtered(self):
        grouped = ar._activities_today_group_by_hour([
            None, "x", {"occurred_at": _today(5)}  # type: ignore[list-item]
        ])
        assert len(grouped) == 1
        assert grouped[0][0] == 5

    def test_empty_list(self):
        assert ar._activities_today_group_by_hour([]) == []


# ---------------------------------------------------------------------------
# Type counts
# ---------------------------------------------------------------------------


class TestTypeCounts:
    def test_basic_counts(self):
        counts = ar._activities_today_type_counts([
            {"activity_type": "email"},
            {"activity_type": "email"},
            {"activity_type": "call"},
        ])
        assert counts == {"email": 2, "call": 1}

    def test_case_normalized(self):
        counts = ar._activities_today_type_counts([
            {"activity_type": "EMAIL"},
            {"activity_type": "Email"},
        ])
        assert counts == {"email": 2}

    def test_type_field_fallback(self):
        counts = ar._activities_today_type_counts([{"type": "note"}])
        assert counts == {"note": 1}

    def test_missing_type_routes_to_event(self):
        counts = ar._activities_today_type_counts([{}])
        assert counts == {"event": 1}

    def test_blank_string_routes_to_event(self):
        counts = ar._activities_today_type_counts([{"activity_type": "   "}])
        assert counts == {"event": 1}

    def test_non_dict_filtered(self):
        counts = ar._activities_today_type_counts([None, "x", 3])  # type: ignore[list-item]
        assert counts == {}


# ---------------------------------------------------------------------------
# Most common type
# ---------------------------------------------------------------------------


class TestMostCommonType:
    def test_single_winner(self):
        assert ar._activities_today_most_common_type([
            {"activity_type": "email"},
            {"activity_type": "email"},
            {"activity_type": "call"},
        ]) == "Email"

    def test_empty_returns_dash(self):
        assert ar._activities_today_most_common_type([]) == "—"

    def test_tie_breaks_alpha(self):
        # Alphabetical tiebreaker ensures deterministic output.
        out = ar._activities_today_most_common_type([
            {"activity_type": "call"},
            {"activity_type": "email"},
        ])
        # Both have 1 count; max by (count, type) = "email" > "call" alphabetically,
        # so email wins (since we use max).
        assert out in ("Email", "Call")

    def test_unknown_type_labeled_via_title_case(self):
        out = ar._activities_today_most_common_type([
            {"activity_type": "custom_thing"},
        ])
        assert "Custom" in out and "Thing" in out


# ---------------------------------------------------------------------------
# Peak hour
# ---------------------------------------------------------------------------


class TestPeakHour:
    def test_single_peak(self):
        result = ar._activities_today_peak_hour([
            {"occurred_at": _today(14)},
            {"occurred_at": _today(14)},
            {"occurred_at": _today(9)},
        ])
        assert result == "14:00"

    def test_empty_returns_dash(self):
        assert ar._activities_today_peak_hour([]) == "—"

    def test_unknown_hours_ignored(self):
        result = ar._activities_today_peak_hour([
            {"occurred_at": "bad"},
            {"occurred_at": _today(7)},
        ])
        assert result == "07:00"

    def test_all_unknown_returns_dash(self):
        assert ar._activities_today_peak_hour([{"occurred_at": "bad"}]) == "—"

    def test_midnight_formatted(self):
        result = ar._activities_today_peak_hour([
            {"occurred_at": f"{TODAY_DATE}T00:30:00Z"}
        ])
        assert result == "00:00"


# ---------------------------------------------------------------------------
# Contacts touched
# ---------------------------------------------------------------------------


class TestContactsTouched:
    def test_distinct_count(self):
        result = ar._activities_today_contacts_touched([
            {"contact_id": "abc"},
            {"contact_id": "ABC"},  # case-normalized
            {"contact_id": "xyz"},
        ])
        assert result == 2

    def test_missing_contact_ignored(self):
        result = ar._activities_today_contacts_touched([
            {"contact_id": "abc"},
            {},
            {"deal_id": "xxx"},
        ])
        assert result == 1

    def test_int_contact_id(self):
        result = ar._activities_today_contacts_touched([
            {"contact_id": 1},
            {"contact_id": 1},
            {"contact_id": 2},
        ])
        assert result == 2

    def test_zero_ignored(self):
        result = ar._activities_today_contacts_touched([{"contact_id": 0}])
        assert result == 0

    def test_none_ignored(self):
        result = ar._activities_today_contacts_touched([{"contact_id": None}])
        assert result == 0

    def test_empty_list(self):
        assert ar._activities_today_contacts_touched([]) == 0

    def test_non_dict_filtered(self):
        assert ar._activities_today_contacts_touched([None, "x"]) == 0  # type: ignore[list-item]


# ---------------------------------------------------------------------------
# Display helpers
# ---------------------------------------------------------------------------


class TestDisplaySummary:
    def test_summary_from_summary_field(self):
        assert (
            ar._activities_today_display_summary({"summary": "Hello"}) == "Hello"
        )

    def test_fallback_to_body(self):
        assert ar._activities_today_display_summary({"body": "X"}) == "X"

    def test_empty_returns_placeholder(self):
        assert (
            ar._activities_today_display_summary({"summary": "   "}) == "(no summary)"
        )

    def test_non_dict(self):
        assert ar._activities_today_display_summary("nope") == "(no summary)"  # type: ignore[arg-type]

    def test_xss_escaped(self):
        out = ar._activities_today_display_summary({"summary": "<script>x</script>"})
        assert "&lt;script&gt;" in out
        assert "<script>" not in out

    def test_long_clipped(self):
        long = "a" * 500
        out = ar._activities_today_display_summary({"summary": long})
        assert len(out) <= ar._MAX_ACTIVITY_SUMMARY_LEN + 3  # "…"
        assert out.endswith("…")


class TestDisplayContext:
    def test_all_three_ids(self):
        out = ar._activities_today_display_context({
            "contact_id": 1, "company_id": 2, "deal_id": "d3"
        })
        assert "contact #1" in out
        assert "company #2" in out
        assert "deal d3" in out

    def test_no_ids(self):
        assert ar._activities_today_display_context({}) == ""

    def test_zero_ids_skipped(self):
        out = ar._activities_today_display_context({"contact_id": 0, "company_id": 0})
        assert out == ""

    def test_xss_escaped_contact_id(self):
        out = ar._activities_today_display_context({"contact_id": "<evil>"})
        assert "&lt;" in out

    def test_non_dict(self):
        assert ar._activities_today_display_context("x") == ""  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Stats row
# ---------------------------------------------------------------------------


class TestStatsRow:
    def test_has_total_most_common_peak_and_contacts_touched(self):
        """LOCK: the new 4-card stats signature for activities entity."""
        activities = [
            {"activity_type": "email", "occurred_at": _today(9), "contact_id": 1},
            {"activity_type": "email", "occurred_at": _today(9), "contact_id": 2},
            {"activity_type": "call", "occurred_at": _today(14), "contact_id": 1},
        ]
        html_out = ar._activities_today_stats_row_html(activities)
        assert "Total" in html_out
        assert "Most common" in html_out
        assert "Peak hour" in html_out
        assert "Contacts touched" in html_out

    def test_empty_shows_dashes(self):
        html_out = ar._activities_today_stats_row_html([])
        assert "—" in html_out
        # Total must show "0" not "—".
        assert ">0<" in html_out

    def test_total_accurate(self):
        activities = [{"occurred_at": _today(10)}] * 5
        html_out = ar._activities_today_stats_row_html(activities)
        assert ">5<" in html_out

    def test_non_list_safe(self):
        # Should not raise.
        html_out = ar._activities_today_stats_row_html([None, "x"])  # type: ignore[list-item]
        assert ">0<" in html_out

    def test_has_4_cards(self):
        html_out = ar._activities_today_stats_row_html([])
        # Four card <div style="flex:1..."> blocks.
        assert html_out.count("flex:1;min-width:140px") == 4


# ---------------------------------------------------------------------------
# Header
# ---------------------------------------------------------------------------


class TestHeader:
    def test_singular(self):
        html_out = ar._activities_today_header_html(1)
        assert "1 activity" in html_out

    def test_plural(self):
        html_out = ar._activities_today_header_html(5)
        assert "5 activities" in html_out

    def test_zero_uses_plural(self):
        html_out = ar._activities_today_header_html(0)
        assert "0 activities" in html_out

    def test_has_temporal_scope_chip(self):
        html_out = ar._activities_today_header_html(3)
        assert "TEMPORAL SCOPE" in html_out

    def test_title_present(self):
        assert "Today's activity" in ar._activities_today_header_html(0)


# ---------------------------------------------------------------------------
# Row
# ---------------------------------------------------------------------------


class TestRow:
    def test_renders_hour(self):
        row = ar._activities_today_row_html({
            "activity_type": "email",
            "occurred_at": _today(9, 30),
            "summary": "Hi",
        })
        assert "09:00" in row
        assert "Hi" in row

    def test_renders_type_label(self):
        row = ar._activities_today_row_html({
            "activity_type": "call",
            "occurred_at": _today(9),
            "summary": "X",
        })
        assert "Call" in row

    def test_unknown_hour_shows_dash(self):
        row = ar._activities_today_row_html({
            "activity_type": "email",
            "occurred_at": "bad",
            "summary": "X",
        })
        assert "—" in row

    def test_xss_summary_escaped(self):
        row = ar._activities_today_row_html({
            "activity_type": "note",
            "occurred_at": _today(9),
            "summary": "<script>",
        })
        assert "&lt;script&gt;" in row
        assert "<script>" not in row[row.index("&lt;") :]

    def test_context_chips_rendered(self):
        row = ar._activities_today_row_html({
            "activity_type": "email",
            "occurred_at": _today(9),
            "summary": "Hi",
            "contact_id": 42,
        })
        assert "contact #42" in row

    def test_non_dict_returns_empty(self):
        assert ar._activities_today_row_html("x") == ""  # type: ignore[arg-type]

    def test_no_summary_shows_placeholder(self):
        row = ar._activities_today_row_html({
            "activity_type": "email",
            "occurred_at": _today(9),
        })
        assert "(no summary)" in row


# ---------------------------------------------------------------------------
# Drill-up
# ---------------------------------------------------------------------------


class TestDrillUp:
    def test_has_activities_feed_sibling(self):
        html_out = ar._activities_today_drill_up_html()
        assert "g8://activities/feed" in html_out

    def test_has_tasks_dashboard_cross_entity(self):
        html_out = ar._activities_today_drill_up_html()
        assert "g8://tasks/dashboard" in html_out

    def test_has_deals_pipeline_cross_entity(self):
        html_out = ar._activities_today_drill_up_html()
        assert "g8://deals/pipeline" in html_out

    def test_has_contacts_dashboard_cross_entity(self):
        html_out = ar._activities_today_drill_up_html()
        assert "g8://contacts/dashboard" in html_out

    def test_has_copilot_home_link(self):
        html_out = ar._activities_today_drill_up_html()
        assert "g8://copilot/home" in html_out

    def test_no_self_link(self):
        html_out = ar._activities_today_drill_up_html()
        assert "g8://activities/today" not in html_out

    def test_label_present(self):
        html_out = ar._activities_today_drill_up_html()
        assert "Related surfaces" in html_out


# ---------------------------------------------------------------------------
# Empty state
# ---------------------------------------------------------------------------


class TestEmptyState:
    def test_empty_state_body(self):
        html_out = ar._activities_today_empty_state_html()
        assert "No activity" in html_out
        assert "UTC" in html_out

    def test_empty_state_explainer_present(self):
        html_out = ar._activities_today_empty_state_html()
        assert "00:00 UTC" in html_out


# ---------------------------------------------------------------------------
# render_html
# ---------------------------------------------------------------------------


class TestRenderHtml:
    def test_empty_renders_empty_state(self):
        html_out = ar.render_activities_today_html(activities=[], bound_iso=TODAY_ISO)
        assert "No activity logged today" in html_out

    def test_none_activities_renders_empty(self):
        html_out = ar.render_activities_today_html(activities=None, bound_iso=TODAY_ISO)
        assert "No activity logged today" in html_out

    def test_populated_renders_rows(self):
        html_out = ar.render_activities_today_html(
            activities=[
                {"activity_type": "email", "occurred_at": _today(9), "summary": "Hi"}
            ],
            bound_iso=TODAY_ISO,
        )
        assert "Hi" in html_out
        assert "Email" in html_out

    def test_filters_out_yesterday(self):
        html_out = ar.render_activities_today_html(
            activities=[
                {"activity_type": "email", "occurred_at": _today(9), "summary": "today-hi"},
                {"activity_type": "call", "occurred_at": f"{YESTERDAY_DATE}T22:00:00Z",
                 "summary": "yester-call"},
            ],
            bound_iso=TODAY_ISO,
        )
        assert "today-hi" in html_out
        assert "yester-call" not in html_out

    def test_doctype_present(self):
        html_out = ar.render_activities_today_html(activities=[], bound_iso=TODAY_ISO)
        assert html_out.startswith("<!doctype html>")

    def test_title_tag_present(self):
        html_out = ar.render_activities_today_html(activities=[], bound_iso=TODAY_ISO)
        assert "<title>Today's activity</title>" in html_out

    def test_sort_by_hour_desc(self):
        """LOCK: the highest-hour bucket is rendered first."""
        html_out = ar.render_activities_today_html(
            activities=[
                {"activity_type": "email", "occurred_at": _today(9), "summary": "morning"},
                {"activity_type": "call", "occurred_at": _today(18), "summary": "evening"},
            ],
            bound_iso=TODAY_ISO,
        )
        # "18:00" bucket header must appear before "09:00".
        assert html_out.index("18:00") < html_out.index("09:00")

    def test_overflow_banner_appears_above_cap(self):
        many = [
            {"activity_type": "email", "occurred_at": _today(9), "summary": f"#{i}"}
            for i in range(ar._MAX_ACTIVITIES_RENDERED + 5)
        ]
        html_out = ar.render_activities_today_html(activities=many, bound_iso=TODAY_ISO)
        assert "omitted" in html_out

    def test_no_overflow_banner_under_cap(self):
        few = [
            {"activity_type": "email", "occurred_at": _today(9), "summary": "only"}
        ]
        html_out = ar.render_activities_today_html(activities=few, bound_iso=TODAY_ISO)
        assert "omitted" not in html_out

    def test_drill_up_always_present(self):
        html_out = ar.render_activities_today_html(activities=[], bound_iso=TODAY_ISO)
        assert "g8://activities/feed" in html_out
        assert "g8://tasks/dashboard" in html_out

    def test_non_list_input_safe(self):
        html_out = ar.render_activities_today_html(activities="x", bound_iso=TODAY_ISO)  # type: ignore[arg-type]
        assert "No activity" in html_out

    def test_title_matches_axis(self):
        html_out = ar.render_activities_today_html(
            activities=[
                {"activity_type": "email", "occurred_at": _today(9), "summary": "Hi"}
            ],
            bound_iso=TODAY_ISO,
        )
        assert "Today's activity" in html_out


# ---------------------------------------------------------------------------
# render_html structure
# ---------------------------------------------------------------------------


class TestRenderHtmlStructure:
    def test_max_width_container(self):
        html_out = ar.render_activities_today_html(activities=[], bound_iso=TODAY_ISO)
        assert "max-width:900px" in html_out

    def test_body_background_muted(self):
        html_out = ar.render_activities_today_html(activities=[], bound_iso=TODAY_ISO)
        assert f"background:{ar._G8_MUTED_BG}" in html_out


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------


class TestTextFallback:
    def test_header_present(self):
        txt = ar.render_activities_today_text_fallback(
            activities=[], bound_iso=TODAY_ISO
        )
        assert txt.startswith("# Today's activity")

    def test_empty_explainer(self):
        txt = ar.render_activities_today_text_fallback(
            activities=[], bound_iso=TODAY_ISO
        )
        assert "No activity logged today" in txt
        assert "Scope resets at 00:00 UTC" in txt

    def test_stats_listed(self):
        txt = ar.render_activities_today_text_fallback(
            activities=[
                {"activity_type": "email", "occurred_at": _today(9), "contact_id": 1,
                 "summary": "Hi"}
            ],
            bound_iso=TODAY_ISO,
        )
        assert "- Total: 1" in txt
        assert "- Most common:" in txt
        assert "- Peak hour: 09:00" in txt
        assert "- Contacts touched: 1" in txt

    def test_hour_headers_present(self):
        txt = ar.render_activities_today_text_fallback(
            activities=[
                {"activity_type": "email", "occurred_at": _today(9), "summary": "A"},
                {"activity_type": "call", "occurred_at": _today(18), "summary": "B"},
            ],
            bound_iso=TODAY_ISO,
        )
        assert "## 18:00" in txt
        assert "## 09:00" in txt

    def test_related_surfaces_block(self):
        txt = ar.render_activities_today_text_fallback(
            activities=[], bound_iso=TODAY_ISO
        )
        assert "g8://activities/feed" in txt
        assert "g8://tasks/dashboard" in txt
        assert "g8://deals/pipeline" in txt
        assert "g8://contacts/dashboard" in txt
        assert "g8://copilot/home" in txt

    def test_backend_filter_line_on_populated(self):
        txt = ar.render_activities_today_text_fallback(
            activities=[
                {"activity_type": "email", "occurred_at": _today(9), "summary": "Hi"}
            ],
            bound_iso=TODAY_ISO,
        )
        assert "since=" in txt
        assert "/activities?since=" in txt

    def test_overflow_line(self):
        many = [
            {"activity_type": "email", "occurred_at": _today(9), "summary": f"#{i}"}
            for i in range(ar._MAX_ACTIVITIES_RENDERED + 3)
        ]
        txt = ar.render_activities_today_text_fallback(
            activities=many, bound_iso=TODAY_ISO
        )
        assert "omitted" in txt

    def test_filters_yesterday_out(self):
        txt = ar.render_activities_today_text_fallback(
            activities=[
                {"activity_type": "email", "occurred_at": f"{YESTERDAY_DATE}T10:00:00Z",
                 "summary": "Y"},
            ],
            bound_iso=TODAY_ISO,
        )
        assert "No activity logged today" in txt


# ---------------------------------------------------------------------------
# Design tokens
# ---------------------------------------------------------------------------


class TestDesignTokens:
    def test_no_banned_studio_hexes(self):
        html_out = ar.render_activities_today_html(
            activities=[
                {"activity_type": "email", "occurred_at": _today(9), "summary": "Hi"}
            ],
            bound_iso=TODAY_ISO,
        )
        for banned in ("#1d4ed8", "#166534", "#991b1b", "#0891b2"):
            assert banned not in html_out, f"banned hex {banned} leaked"

    def test_primary_purple_used(self):
        html_out = ar.render_activities_today_html(
            activities=[
                {"activity_type": "email", "occurred_at": _today(9), "summary": "Hi"}
            ],
            bound_iso=TODAY_ISO,
        )
        assert ar._G8_PRIMARY in html_out

    def test_aeonik_font(self):
        html_out = ar.render_activities_today_html(
            activities=[], bound_iso=TODAY_ISO
        )
        assert "Aeonik" in html_out

    def test_border_token(self):
        html_out = ar.render_activities_today_html(
            activities=[], bound_iso=TODAY_ISO
        )
        assert ar._G8_BORDER in html_out


# ---------------------------------------------------------------------------
# No JS
# ---------------------------------------------------------------------------


class TestNoJs:
    def test_no_script_tag(self):
        html_out = ar.render_activities_today_html(
            activities=[
                {"activity_type": "email", "occurred_at": _today(9), "summary": "Hi"}
            ],
            bound_iso=TODAY_ISO,
        )
        assert "<script" not in html_out.lower()

    def test_no_event_handlers(self):
        html_out = ar.render_activities_today_html(
            activities=[
                {"activity_type": "email", "occurred_at": _today(9), "summary": "Hi"}
            ],
            bound_iso=TODAY_ISO,
        )
        for attr in (" onclick=", " onload=", " onerror=", " onmouseover="):
            assert attr not in html_out


# ---------------------------------------------------------------------------
# Smoke
# ---------------------------------------------------------------------------


class TestSmoke:
    @pytest.mark.parametrize("activity_type", [
        "note", "email", "call", "meeting", "task", "stage_change",
        "assignment", "created", "event",
    ])
    def test_html_renders_each_type(self, activity_type):
        html_out = ar.render_activities_today_html(
            activities=[
                {"activity_type": activity_type, "occurred_at": _today(9),
                 "summary": f"smoke {activity_type}"}
            ],
            bound_iso=TODAY_ISO,
        )
        assert f"smoke {activity_type}" in html_out

    @pytest.mark.parametrize("activity_type", [
        "note", "email", "call", "meeting", "task", "stage_change",
        "assignment", "created", "event",
    ])
    def test_text_renders_each_type(self, activity_type):
        txt = ar.render_activities_today_text_fallback(
            activities=[
                {"activity_type": activity_type, "occurred_at": _today(9),
                 "summary": f"smoke {activity_type}"}
            ],
            bound_iso=TODAY_ISO,
        )
        assert f"smoke {activity_type}" in txt

    def test_handles_full_list(self):
        many = [
            {"activity_type": "email", "occurred_at": _today(h), "summary": f"#{h}"}
            for h in range(24)
        ]
        html_out = ar.render_activities_today_html(
            activities=many, bound_iso=TODAY_ISO
        )
        assert "00:00" in html_out
        assert "23:00" in html_out


# ---------------------------------------------------------------------------
# Return types
# ---------------------------------------------------------------------------


class TestReturnTypes:
    def test_html_returns_str(self):
        out = ar.render_activities_today_html(activities=[], bound_iso=TODAY_ISO)
        assert isinstance(out, str)

    def test_text_returns_str(self):
        out = ar.render_activities_today_text_fallback(
            activities=[], bound_iso=TODAY_ISO
        )
        assert isinstance(out, str)
