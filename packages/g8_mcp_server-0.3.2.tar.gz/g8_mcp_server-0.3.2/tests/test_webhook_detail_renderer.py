"""Unit tests for surface #31 — webhook detail renderer.

Covers the palette + helper fns in app_renderer.py for the per-webhook
overview + recent-deliveries surface:

  g8://webhooks/{webhook_id}/overview
  g8://webhooks/{webhook_id}/overview.txt

Focus areas:
- delivery-status palette (success / pending / failed / unknown)
- is-successful-delivery (status tokens + 2xx codes)
- tally_deliveries (bucketing)
- compute_success_rate (None for empty/unknown, filters pending)
- derive_display_name (name > host > "Webhook")
- short_url (scheme preservation, truncation)
- stat-card and info-row escape
- empty-state card (escape paths, no double-escape)
- HTML renderer (active dot vs status separation, 5-card grid,
  events chips + overflow + empty-state, deliveries rendering with
  HTTP code coloring + error tint + overflow note + summary line,
  drill-up hints)
- text fallback (same fields, markdown mirror, deliveries summary)
"""

from __future__ import annotations

import pytest

from g8_mcp_server.app_renderer import (
    _WEBHOOK_DETAIL_DELIVERY_STATUS_COLORS,
    _render_webhook_detail_empty_state_html,
    _webhook_detail_compute_success_rate,
    _webhook_detail_delivery_status_palette,
    _webhook_detail_derive_display_name,
    _webhook_detail_info_row,
    _webhook_detail_is_successful_delivery,
    _webhook_detail_short_url,
    _webhook_detail_stat_card,
    _webhook_detail_tally_deliveries,
    render_webhook_detail_html,
    render_webhook_detail_text_fallback,
)

_BANNED_HEXES = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}


class TestWebhookDetailPaletteNoBannedHexes:
    """Lock test: _WEBHOOK_DETAIL_DELIVERY_STATUS_COLORS must not reintroduce banned Studio hexes."""

    def test_no_banned_hexes_in_delivery_status_palette(self):
        for key, pal in _WEBHOOK_DETAIL_DELIVERY_STATUS_COLORS.items():
            for field in ("bg", "fg", "border"):
                assert pal[field].lower() not in _BANNED_HEXES, (
                    f"Banned hex {pal[field]!r} in _WEBHOOK_DETAIL_DELIVERY_STATUS_COLORS[{key!r}][{field!r}]"
                )


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _sample_webhook() -> dict:
    return {
        "id": "wh_abc123",
        "name": "Zapier CRM Sync",
        "url": "https://hooks.zapier.com/hooks/catch/12345/abcdef",
        "events": ["contact.created", "contact.updated", "deal.won"],
        "is_active": True,
        "status": "active",
        "created_at": "2026-03-15T10:30:00Z",
        "updated_at": "2026-04-18T14:22:00Z",
    }


def _sample_deliveries() -> list[dict]:
    return [
        {
            "id": "d1",
            "event": "contact.created",
            "status": "delivered",
            "response_code": 200,
            "attempts": 1,
            "max_attempts": 3,
            "completed_at": "2026-04-19T12:00:00Z",
        },
        {
            "id": "d2",
            "event": "deal.won",
            "status": "failed",
            "response_code": 500,
            "attempts": 3,
            "max_attempts": 3,
            "completed_at": "2026-04-19T11:45:00Z",
            "error_message": "Connection timeout after 30s",
        },
        {
            "id": "d3",
            "event": "contact.updated",
            "status": "pending",
            "attempts": 0,
            "max_attempts": 3,
            "created_at": "2026-04-19T11:30:00Z",
        },
    ]


# ---------------------------------------------------------------------------
# _webhook_detail_delivery_status_palette
# ---------------------------------------------------------------------------


class TestDeliveryStatusPalette:
    def test_delivered_is_green(self):
        p = _webhook_detail_delivery_status_palette("delivered")
        assert p["fg"] == "#059669"  # was banned #166534 → _G8_POSITIVE_FG
        assert p["bg"] == "#d1fae5"

    def test_success_alias(self):
        p = _webhook_detail_delivery_status_palette("success")
        assert p["fg"] == "#059669"  # was banned #166534

    def test_succeeded_alias(self):
        assert (
            _webhook_detail_delivery_status_palette("succeeded")["fg"]
            == "#059669"  # was banned #166534
        )

    def test_completed_alias(self):
        assert (
            _webhook_detail_delivery_status_palette("completed")["fg"]
            == "#059669"  # was banned #166534
        )

    def test_pending_is_indigo(self):
        p = _webhook_detail_delivery_status_palette("pending")
        assert p["fg"] == "#7d2df3"

    def test_queued_alias(self):
        assert (
            _webhook_detail_delivery_status_palette("queued")["fg"]
            == "#7d2df3"
        )

    def test_retrying_is_blue(self):
        p = _webhook_detail_delivery_status_palette("retrying")
        assert p["fg"] == "#1e40af"

    def test_in_progress_alias(self):
        assert (
            _webhook_detail_delivery_status_palette("in_progress")["fg"]
            == "#1e40af"
        )

    def test_failed_is_red(self):
        p = _webhook_detail_delivery_status_palette("failed")
        assert p["fg"] == "#b91c1c"  # was banned #991b1b → _G8_DESTRUCTIVE_ON_LIGHT_FG

    def test_error_alias(self):
        assert (
            _webhook_detail_delivery_status_palette("error")["fg"]
            == "#b91c1c"  # was banned #991b1b
        )

    def test_dead_is_amber(self):
        p = _webhook_detail_delivery_status_palette("dead")
        assert p["fg"] == "#92400e"

    def test_exhausted_alias(self):
        assert (
            _webhook_detail_delivery_status_palette("exhausted")["fg"]
            == "#92400e"
        )

    def test_unknown_status_returns_default(self):
        p = _webhook_detail_delivery_status_palette("something_strange")
        # neutral gray
        assert p["fg"] == "#777777"
        assert p["bg"] == "#f9f9f9"

    def test_none_returns_default(self):
        p = _webhook_detail_delivery_status_palette(None)
        assert p["fg"] == "#777777"

    def test_empty_string_returns_default(self):
        p = _webhook_detail_delivery_status_palette("   ")
        assert p["fg"] == "#777777"

    def test_case_insensitive(self):
        p = _webhook_detail_delivery_status_palette("DELIVERED")
        assert p["fg"] == "#059669"  # was banned #166534

    def test_strips_whitespace(self):
        p = _webhook_detail_delivery_status_palette(" delivered ")
        assert p["fg"] == "#059669"  # was banned #166534

    def test_non_string_returns_default(self):
        p = _webhook_detail_delivery_status_palette(42)  # type: ignore[arg-type]
        assert p["fg"] == "#777777"


# ---------------------------------------------------------------------------
# _webhook_detail_is_successful_delivery
# ---------------------------------------------------------------------------


class TestIsSuccessfulDelivery:
    def test_delivered_status_is_success(self):
        assert _webhook_detail_is_successful_delivery({"status": "delivered"})

    def test_success_status_is_success(self):
        assert _webhook_detail_is_successful_delivery({"status": "success"})

    def test_succeeded_status_is_success(self):
        assert _webhook_detail_is_successful_delivery({"status": "succeeded"})

    def test_completed_status_is_success(self):
        assert _webhook_detail_is_successful_delivery({"status": "completed"})

    def test_2xx_without_status_is_success(self):
        assert _webhook_detail_is_successful_delivery({"response_code": 201})

    def test_200_is_success(self):
        assert _webhook_detail_is_successful_delivery({"response_code": 200})

    def test_299_is_success(self):
        assert _webhook_detail_is_successful_delivery({"response_code": 299})

    def test_300_is_not_success(self):
        assert not _webhook_detail_is_successful_delivery({"response_code": 300})

    def test_4xx_is_not_success(self):
        assert not _webhook_detail_is_successful_delivery({"response_code": 404})

    def test_5xx_is_not_success(self):
        assert not _webhook_detail_is_successful_delivery({"response_code": 500})

    def test_failed_with_2xx_still_counts_as_success(self):
        # If response_code is 2xx, we trust it even if status says failed.
        assert _webhook_detail_is_successful_delivery(
            {"status": "failed", "response_code": 200}
        )

    def test_pending_without_code_is_not_success(self):
        assert not _webhook_detail_is_successful_delivery({"status": "pending"})

    def test_none_is_not_success(self):
        assert not _webhook_detail_is_successful_delivery(None)

    def test_empty_dict_is_not_success(self):
        assert not _webhook_detail_is_successful_delivery({})

    def test_non_dict_is_not_success(self):
        assert not _webhook_detail_is_successful_delivery("nope")  # type: ignore[arg-type]

    def test_status_case_insensitive(self):
        assert _webhook_detail_is_successful_delivery({"status": "DELIVERED"})

    def test_status_strips_whitespace(self):
        assert _webhook_detail_is_successful_delivery({"status": "  delivered  "})

    def test_non_int_response_code_ignored(self):
        assert not _webhook_detail_is_successful_delivery(
            {"response_code": "200"}
        )


# ---------------------------------------------------------------------------
# _webhook_detail_tally_deliveries
# ---------------------------------------------------------------------------


class TestTallyDeliveries:
    def test_empty_list(self):
        tally = _webhook_detail_tally_deliveries([])
        assert tally == {"success": 0, "pending": 0, "failed": 0, "unknown": 0}

    def test_none_input(self):
        tally = _webhook_detail_tally_deliveries(None)
        assert tally == {"success": 0, "pending": 0, "failed": 0, "unknown": 0}

    def test_all_success(self):
        tally = _webhook_detail_tally_deliveries([
            {"status": "delivered"},
            {"status": "success"},
            {"response_code": 200},
        ])
        assert tally["success"] == 3

    def test_mixed_buckets(self):
        tally = _webhook_detail_tally_deliveries([
            {"status": "delivered"},  # success
            {"status": "failed"},  # failed
            {"status": "pending"},  # pending
            {"status": "retrying"},  # pending
            {"status": "dead"},  # failed
            {},  # unknown
        ])
        assert tally == {"success": 1, "pending": 2, "failed": 2, "unknown": 1}

    def test_2xx_without_status_is_success(self):
        tally = _webhook_detail_tally_deliveries([
            {"response_code": 200},
            {"response_code": 201},
        ])
        assert tally["success"] == 2

    def test_non_dict_items_are_unknown(self):
        tally = _webhook_detail_tally_deliveries([
            "weird",
            42,
            None,
            {"status": "delivered"},
        ])
        assert tally["success"] == 1
        assert tally["unknown"] == 3

    def test_empty_status_without_code_is_unknown(self):
        tally = _webhook_detail_tally_deliveries([
            {"status": "   "},
            {"status": ""},
        ])
        assert tally["unknown"] == 2

    def test_non_list_returns_zeros(self):
        assert _webhook_detail_tally_deliveries("nope") == {
            "success": 0, "pending": 0, "failed": 0, "unknown": 0
        }


# ---------------------------------------------------------------------------
# _webhook_detail_compute_success_rate
# ---------------------------------------------------------------------------


class TestComputeSuccessRate:
    def test_empty_list_returns_none(self):
        assert _webhook_detail_compute_success_rate([]) is None

    def test_none_returns_none(self):
        assert _webhook_detail_compute_success_rate(None) is None

    def test_all_unknown_returns_none(self):
        assert _webhook_detail_compute_success_rate([{}, {}]) is None

    def test_all_success(self):
        rate = _webhook_detail_compute_success_rate([
            {"status": "delivered"},
            {"status": "success"},
        ])
        assert rate == (2, 2)

    def test_half_success(self):
        rate = _webhook_detail_compute_success_rate([
            {"status": "delivered"},
            {"status": "failed"},
        ])
        assert rate == (1, 2)

    def test_unknown_deliveries_not_in_denominator(self):
        rate = _webhook_detail_compute_success_rate([
            {"status": "delivered"},
            {"status": "failed"},
            {},  # unknown — excluded
            "nope",  # excluded
        ])
        assert rate == (1, 2)

    def test_2xx_without_status_counts(self):
        rate = _webhook_detail_compute_success_rate([
            {"response_code": 200},
            {"response_code": 500},
        ])
        # both have non-null response_code so both are in denominator
        assert rate == (1, 2)

    def test_pending_is_in_denominator_but_not_numerator(self):
        rate = _webhook_detail_compute_success_rate([
            {"status": "delivered"},
            {"status": "pending"},
        ])
        assert rate == (1, 2)


# ---------------------------------------------------------------------------
# _webhook_detail_derive_display_name
# ---------------------------------------------------------------------------


class TestDeriveDisplayName:
    def test_prefers_name(self):
        wh = {"name": "Zapier Sync", "url": "https://hooks.zapier.com/x"}
        assert _webhook_detail_derive_display_name(wh) == "Zapier Sync"

    def test_strips_whitespace_from_name(self):
        assert _webhook_detail_derive_display_name({"name": "  Zapier   "}) == "Zapier"

    def test_falls_back_to_host(self):
        wh = {"url": "https://hooks.zapier.com/hooks/catch/12345"}
        assert _webhook_detail_derive_display_name(wh) == "hooks.zapier.com"

    def test_falls_back_to_url_without_scheme(self):
        wh = {"url": "hooks.example.com/path"}
        assert _webhook_detail_derive_display_name(wh) == "hooks.example.com"

    def test_default_when_no_name_no_url(self):
        assert _webhook_detail_derive_display_name({}) == "Webhook"

    def test_default_when_empty_name_empty_url(self):
        assert _webhook_detail_derive_display_name({"name": "  ", "url": "  "}) == "Webhook"

    def test_none_input(self):
        assert _webhook_detail_derive_display_name(None) == "Webhook"

    def test_non_dict_input(self):
        assert _webhook_detail_derive_display_name("nope") == "Webhook"  # type: ignore[arg-type]

    def test_name_priority_over_url(self):
        wh = {"name": "My Webhook", "url": "https://other.example.com"}
        assert _webhook_detail_derive_display_name(wh) == "My Webhook"


# ---------------------------------------------------------------------------
# _webhook_detail_short_url
# ---------------------------------------------------------------------------


class TestShortUrl:
    def test_short_url_unchanged(self):
        assert _webhook_detail_short_url("https://example.com/x") == "https://example.com/x"

    def test_long_url_truncated_keeps_host(self):
        long_url = "https://example.com/" + "x" * 200
        out = _webhook_detail_short_url(long_url)
        assert out.startswith("https://example.com/")
        assert out.endswith("…")

    def test_none_returns_empty(self):
        assert _webhook_detail_short_url(None) == ""

    def test_empty_returns_empty(self):
        assert _webhook_detail_short_url("") == ""
        assert _webhook_detail_short_url("   ") == ""

    def test_non_string_returns_empty(self):
        assert _webhook_detail_short_url(42) == ""  # type: ignore[arg-type]

    def test_no_scheme_truncated(self):
        long_url = "example.com/" + "a" * 200
        out = _webhook_detail_short_url(long_url)
        assert out.endswith("…")


# ---------------------------------------------------------------------------
# _webhook_detail_stat_card
# ---------------------------------------------------------------------------


class TestStatCard:
    def test_basic_card(self):
        html = _webhook_detail_stat_card("Status", "Active")
        assert "Status" in html
        assert "Active" in html
        assert "stat-card" in html

    def test_escapes_label_and_value(self):
        html = _webhook_detail_stat_card("<x>", "<y>")
        assert "<x>" not in html
        assert "&lt;x&gt;" in html
        assert "&lt;y&gt;" in html

    def test_accent_applied(self):
        html = _webhook_detail_stat_card("Status", "Active", accent="#059669")
        assert "#059669" in html


# ---------------------------------------------------------------------------
# _webhook_detail_info_row
# ---------------------------------------------------------------------------


class TestInfoRow:
    def test_basic(self):
        html = _webhook_detail_info_row("Target URL", "<span>foo</span>")
        assert "Target URL" in html
        assert "<span>foo</span>" in html  # value_html passed through

    def test_escapes_label(self):
        html = _webhook_detail_info_row("<X>", "value")
        assert "<X>" not in html
        assert "&lt;X&gt;" in html


# ---------------------------------------------------------------------------
# _render_webhook_detail_empty_state_html
# ---------------------------------------------------------------------------


class TestEmptyState:
    def test_includes_id(self):
        out = _render_webhook_detail_empty_state_html(
            webhook_id="wh_missing", reason="Not found"
        )
        assert "wh_missing" in out

    def test_includes_reason(self):
        out = _render_webhook_detail_empty_state_html(
            webhook_id="wh_x", reason="Revoked by org admin"
        )
        assert "Revoked by org admin" in out

    def test_escapes_reason(self):
        out = _render_webhook_detail_empty_state_html(
            webhook_id="wh_x", reason="<script>alert(1)</script>"
        )
        assert "<script>alert(1)</script>" not in out
        assert "&lt;script&gt;" in out

    def test_escapes_id_no_double_escape(self):
        # `_clip` already HTML-escapes; we must NOT wrap it again.
        out = _render_webhook_detail_empty_state_html(
            webhook_id="<evil>", reason="bad"
        )
        assert "<evil>" not in out
        assert "&lt;evil&gt;" in out
        assert "&amp;lt;" not in out  # no double-escape

    def test_empty_id_placeholder(self):
        out = _render_webhook_detail_empty_state_html(webhook_id="", reason="x")
        assert "(unknown)" in out

    def test_includes_discovery_hint(self):
        out = _render_webhook_detail_empty_state_html(
            webhook_id="wh_x", reason="404"
        )
        assert "g8_list_webhooks" in out


# ---------------------------------------------------------------------------
# render_webhook_detail_html — happy-path & branches
# ---------------------------------------------------------------------------


class TestRenderHtml:
    def test_renders_webhook_name(self):
        html = render_webhook_detail_html(
            webhook=_sample_webhook(), webhook_id="wh_abc123"
        )
        assert "Zapier CRM Sync" in html

    def test_renders_doctype_and_meta(self):
        html = render_webhook_detail_html(
            webhook=_sample_webhook(), webhook_id="wh_abc123"
        )
        assert html.startswith("<!DOCTYPE html>")
        assert '<meta charset="utf-8">' in html

    def test_falls_back_to_host_when_no_name(self):
        wh = dict(_sample_webhook())
        wh.pop("name")
        html = render_webhook_detail_html(webhook=wh, webhook_id="wh_abc123")
        assert "hooks.zapier.com" in html

    def test_active_dot_green_when_active(self):
        html = render_webhook_detail_html(
            webhook=_sample_webhook(), webhook_id="wh_abc123"
        )
        # active dot uses green #059669
        assert "#059669" in html

    def test_active_dot_gray_when_paused(self):
        wh = dict(_sample_webhook(), is_active=False)
        html = render_webhook_detail_html(webhook=wh, webhook_id="wh_abc123")
        # paused uses gray #777777 for the dot
        assert "#777777" in html
        assert "Paused" in html

    def test_events_rendered_as_chips(self):
        html = render_webhook_detail_html(
            webhook=_sample_webhook(), webhook_id="wh_abc123"
        )
        assert "contact.created" in html
        assert "contact.updated" in html
        assert "deal.won" in html

    def test_events_overflow_note(self):
        wh = dict(_sample_webhook(), events=[f"event.{i}" for i in range(30)])
        html = render_webhook_detail_html(webhook=wh, webhook_id="wh_x")
        # cap is 24; so +6 overflow
        assert "+6 more" in html

    def test_empty_events_shows_empty_state(self):
        wh = dict(_sample_webhook(), events=[])
        html = render_webhook_detail_html(webhook=wh, webhook_id="wh_x")
        assert "No events subscribed" in html

    def test_no_deliveries_param_omits_section(self):
        html = render_webhook_detail_html(
            webhook=_sample_webhook(), webhook_id="wh_abc123", deliveries=None
        )
        # If deliveries is None, there's no "Recent deliveries" section heading.
        assert "Recent deliveries" not in html

    def test_empty_deliveries_shows_empty_state(self):
        html = render_webhook_detail_html(
            webhook=_sample_webhook(), webhook_id="wh_abc123", deliveries=[]
        )
        assert "No deliveries yet" in html

    def test_deliveries_rendered(self):
        html = render_webhook_detail_html(
            webhook=_sample_webhook(),
            webhook_id="wh_abc123",
            deliveries=_sample_deliveries(),
        )
        assert "contact.created" in html
        assert "deal.won" in html
        # Status labels uppercased
        assert "DELIVERED" in html
        assert "FAILED" in html

    def test_delivery_error_rendered(self):
        html = render_webhook_detail_html(
            webhook=_sample_webhook(),
            webhook_id="wh_abc123",
            deliveries=_sample_deliveries(),
        )
        assert "Connection timeout after 30s" in html
        # error tint red background
        assert "#fef2f2" in html

    def test_delivery_2xx_code_colored_green(self):
        html = render_webhook_detail_html(
            webhook=_sample_webhook(),
            webhook_id="wh_abc123",
            deliveries=_sample_deliveries(),
        )
        assert "#059669" in html  # was banned #166534 → _G8_POSITIVE_FG

    def test_delivery_5xx_code_colored_red(self):
        html = render_webhook_detail_html(
            webhook=_sample_webhook(),
            webhook_id="wh_abc123",
            deliveries=_sample_deliveries(),
        )
        assert "#b91c1c" in html  # was banned #991b1b → _G8_DESTRUCTIVE_ON_LIGHT_FG

    def test_delivery_4xx_code_colored_amber(self):
        d = [{"status": "failed", "response_code": 404, "attempts": 1, "max_attempts": 3}]
        html = render_webhook_detail_html(
            webhook=_sample_webhook(), webhook_id="wh_x", deliveries=d
        )
        assert "#92400e" in html

    def test_deliveries_overflow_note_over_cap(self):
        d = [
            {"status": "delivered", "response_code": 200, "event": f"e.{i}"}
            for i in range(15)
        ]
        html = render_webhook_detail_html(
            webhook=_sample_webhook(), webhook_id="wh_x", deliveries=d
        )
        # cap is 10; 5 overflow
        assert "+5 older" in html

    def test_summary_line_shown(self):
        html = render_webhook_detail_html(
            webhook=_sample_webhook(),
            webhook_id="wh_abc123",
            deliveries=_sample_deliveries(),
        )
        assert "1 succeeded" in html
        assert "1 failed" in html
        assert "1 pending" in html

    def test_drill_up_hints(self):
        html = render_webhook_detail_html(
            webhook=_sample_webhook(), webhook_id="wh_abc123"
        )
        assert "GET /webhooks/wh_abc123/deliveries" in html
        assert "PATCH /webhooks/wh_abc123" in html
        assert "GET /webhooks/events" in html

    def test_success_rate_displayed(self):
        html = render_webhook_detail_html(
            webhook=_sample_webhook(),
            webhook_id="wh_abc123",
            deliveries=_sample_deliveries(),
        )
        # 1 success / 3 known = 33%
        assert "33%" in html

    def test_success_rate_em_dash_when_none(self):
        html = render_webhook_detail_html(
            webhook=_sample_webhook(),
            webhook_id="wh_abc123",
            deliveries=None,
        )
        # "—" for last delivery + success rate
        assert "—" in html

    def test_escapes_webhook_name_xss(self):
        wh = dict(_sample_webhook(), name="<script>alert(1)</script>")
        html = render_webhook_detail_html(webhook=wh, webhook_id="wh_x")
        assert "<script>alert(1)</script>" not in html
        assert "&lt;script&gt;" in html

    def test_escapes_url_xss(self):
        wh = dict(_sample_webhook(), url="https://evil.com/\"><script>x</script>")
        html = render_webhook_detail_html(webhook=wh, webhook_id="wh_x")
        assert "<script>x</script>" not in html

    def test_escapes_event_name_xss(self):
        wh = dict(_sample_webhook(), events=["<img src=x onerror=alert(1)>"])
        html = render_webhook_detail_html(webhook=wh, webhook_id="wh_x")
        assert "<img src=x onerror=alert(1)>" not in html
        assert "&lt;img" in html

    def test_escapes_delivery_error_xss(self):
        d = [{
            "status": "failed",
            "response_code": 500,
            "attempts": 3,
            "max_attempts": 3,
            "error_message": "<script>evil</script>",
        }]
        html = render_webhook_detail_html(
            webhook=_sample_webhook(), webhook_id="wh_x", deliveries=d
        )
        assert "<script>evil</script>" not in html
        assert "&lt;script&gt;" in html

    def test_no_double_escape(self):
        wh = dict(_sample_webhook(), name="<evil>")
        html = render_webhook_detail_html(webhook=wh, webhook_id="wh_x")
        assert "&lt;evil&gt;" in html
        assert "&amp;lt;" not in html

    def test_missing_webhook_renders_empty_state(self):
        html = render_webhook_detail_html(webhook=None, webhook_id="wh_missing")
        assert "wh_missing" in html
        assert "Webhook not available" in html

    def test_url_displayed_in_overview(self):
        html = render_webhook_detail_html(
            webhook=_sample_webhook(), webhook_id="wh_abc123"
        )
        assert "hooks.zapier.com" in html

    def test_long_url_truncated_via_clip(self):
        long_url = "https://example.com/" + ("x" * 800)
        wh = dict(_sample_webhook(), url=long_url)
        html = render_webhook_detail_html(webhook=wh, webhook_id="wh_x")
        # _MAX_WEBHOOK_DETAIL_URL_LEN is 500; truncated string must not include all 'x'
        assert long_url not in html

    def test_created_and_updated_rendered(self):
        html = render_webhook_detail_html(
            webhook=_sample_webhook(), webhook_id="wh_abc123"
        )
        assert "2026-03-15T10:30:00Z" in html
        assert "2026-04-18T14:22:00Z" in html

    def test_id_code_block(self):
        html = render_webhook_detail_html(
            webhook=_sample_webhook(), webhook_id="wh_abc123"
        )
        assert "wh_abc123" in html

    def test_event_type_field_accepted(self):
        d = [{"status": "delivered", "response_code": 200, "event_type": "foo.bar"}]
        html = render_webhook_detail_html(
            webhook=_sample_webhook(), webhook_id="wh_x", deliveries=d
        )
        assert "foo.bar" in html

    def test_error_field_accepted(self):
        d = [{
            "status": "failed",
            "response_code": 500,
            "error": "Alt error field",
        }]
        html = render_webhook_detail_html(
            webhook=_sample_webhook(), webhook_id="wh_x", deliveries=d
        )
        assert "Alt error field" in html


# ---------------------------------------------------------------------------
# render_webhook_detail_text_fallback
# ---------------------------------------------------------------------------


class TestRenderTextFallback:
    def test_basic_structure(self):
        text = render_webhook_detail_text_fallback(
            webhook=_sample_webhook(), webhook_id="wh_abc123"
        )
        assert text.startswith("# Zapier CRM Sync")
        assert "- Status: Active" in text
        assert "- Webhook id: wh_abc123" in text

    def test_paused_status(self):
        wh = dict(_sample_webhook(), is_active=False)
        text = render_webhook_detail_text_fallback(webhook=wh, webhook_id="wh_x")
        assert "- Status: Paused" in text

    def test_events_section(self):
        text = render_webhook_detail_text_fallback(
            webhook=_sample_webhook(), webhook_id="wh_abc123"
        )
        assert "## Subscribed events (3 total)" in text
        assert "- contact.created" in text
        assert "- contact.updated" in text
        assert "- deal.won" in text

    def test_empty_events_copy(self):
        wh = dict(_sample_webhook(), events=[])
        text = render_webhook_detail_text_fallback(webhook=wh, webhook_id="wh_x")
        assert "## Subscribed events (0 total)" in text
        assert "No events subscribed." in text

    def test_events_overflow(self):
        wh = dict(_sample_webhook(), events=[f"e.{i}" for i in range(30)])
        text = render_webhook_detail_text_fallback(webhook=wh, webhook_id="wh_x")
        # _MAX_WEBHOOK_DETAIL_EVENTS_RENDERED = 24
        assert "(+6 more)" in text

    def test_deliveries_summary(self):
        text = render_webhook_detail_text_fallback(
            webhook=_sample_webhook(),
            webhook_id="wh_abc123",
            deliveries=_sample_deliveries(),
        )
        assert "## Recent deliveries" in text
        assert "3 total" in text
        assert "33% success rate" in text

    def test_no_deliveries_section_when_none(self):
        text = render_webhook_detail_text_fallback(
            webhook=_sample_webhook(),
            webhook_id="wh_abc123",
            deliveries=None,
        )
        assert "## Recent deliveries" not in text

    def test_empty_deliveries_copy(self):
        text = render_webhook_detail_text_fallback(
            webhook=_sample_webhook(),
            webhook_id="wh_abc123",
            deliveries=[],
        )
        assert "No deliveries recorded yet." in text

    def test_delivery_lines(self):
        text = render_webhook_detail_text_fallback(
            webhook=_sample_webhook(),
            webhook_id="wh_abc123",
            deliveries=_sample_deliveries(),
        )
        assert "[delivered] contact.created" in text
        assert "[failed] deal.won" in text
        assert "[pending] contact.updated" in text
        assert "HTTP 200" in text
        assert "HTTP 500" in text
        assert "error: Connection timeout after 30s" in text

    def test_drill_up_pointers(self):
        text = render_webhook_detail_text_fallback(
            webhook=_sample_webhook(), webhook_id="wh_abc123"
        )
        assert "GET /webhooks/wh_abc123/deliveries" in text
        assert "PATCH /webhooks/wh_abc123" in text
        assert "GET /webhooks/events" in text

    def test_missing_webhook_empty_state(self):
        text = render_webhook_detail_text_fallback(
            webhook=None, webhook_id="wh_missing"
        )
        assert "Webhook not available" in text
        assert "wh_missing" in text

    def test_display_name_falls_back_to_host(self):
        wh = dict(_sample_webhook())
        wh.pop("name")
        text = render_webhook_detail_text_fallback(webhook=wh, webhook_id="wh_x")
        assert text.startswith("# hooks.zapier.com")

    def test_deliveries_overflow_pointer(self):
        d = [
            {"status": "delivered", "response_code": 200, "event": f"e.{i}"}
            for i in range(15)
        ]
        text = render_webhook_detail_text_fallback(
            webhook=_sample_webhook(), webhook_id="wh_x", deliveries=d
        )
        assert "+5 older" in text

    def test_trailing_newline(self):
        text = render_webhook_detail_text_fallback(
            webhook=_sample_webhook(), webhook_id="wh_abc123"
        )
        assert text.endswith("\n")

    def test_empty_webhook_id_placeholder(self):
        text = render_webhook_detail_text_fallback(
            webhook=None, webhook_id=""
        )
        assert "(unknown)" in text
