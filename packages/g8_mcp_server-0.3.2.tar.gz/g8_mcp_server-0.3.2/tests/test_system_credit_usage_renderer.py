"""Unit tests for Surface #90 — g8://system/credit-usage renderer.

CAPSTONE surface for Upgrade 4. First MCP app surface under the
`system/` entity prefix. Introduces the ELEVENTH backend access
pattern: STATIC-KNOWLEDGE SURFACE (no backend fetch).

This surface is deliberately honest about a data gap: live balance
and per-service usage history are NOT yet exposed via the public
developer API. The surface serves a documented reference of what
consumes credits in graph8, plus cost-control tips.
"""

from __future__ import annotations

import pytest

from mcp_server.g8_mcp_server import app_renderer as ar


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------


class TestConstants:
    def test_categories_is_list(self):
        assert isinstance(ar._SYSTEM_CREDIT_SERVICE_CATEGORIES, list)

    def test_four_categories(self):
        """LOCK: exactly four service categories."""
        assert len(ar._SYSTEM_CREDIT_SERVICE_CATEGORIES) == 4

    def test_expected_category_names(self):
        """LOCK: the four canonical category names."""
        names = [c.get("category") for c in ar._SYSTEM_CREDIT_SERVICE_CATEGORIES]
        assert "AI operations" in names
        assert "Data operations" in names
        assert "Messaging operations" in names
        assert "Workflow operations" in names

    def test_each_category_has_required_keys(self):
        for cat in ar._SYSTEM_CREDIT_SERVICE_CATEGORIES:
            assert "category" in cat
            assert "description" in cat
            assert "services" in cat
            assert isinstance(cat["services"], list)
            assert len(cat["services"]) > 0

    def test_all_services_are_strings(self):
        for cat in ar._SYSTEM_CREDIT_SERVICE_CATEGORIES:
            for service in cat["services"]:
                assert isinstance(service, str)
                assert service  # non-empty

    def test_status_note_is_string(self):
        assert isinstance(ar._SYSTEM_CREDIT_BALANCE_STATUS_NOTE, str)
        assert len(ar._SYSTEM_CREDIT_BALANCE_STATUS_NOTE) > 40

    def test_status_note_mentions_developer_api(self):
        """LOCK: the surface is HONEST about the data gap."""
        assert "developer API" in ar._SYSTEM_CREDIT_BALANCE_STATUS_NOTE

    def test_status_note_mentions_studio(self):
        """LOCK: points operators to the Studio for live balance."""
        assert "Studio" in ar._SYSTEM_CREDIT_BALANCE_STATUS_NOTE

    def test_tips_is_list(self):
        assert isinstance(ar._SYSTEM_CREDIT_TIP_ITEMS, list)
        assert len(ar._SYSTEM_CREDIT_TIP_ITEMS) >= 3

    def test_tips_are_strings(self):
        for tip in ar._SYSTEM_CREDIT_TIP_ITEMS:
            assert isinstance(tip, str)
            assert len(tip) > 10

    def test_renderer_functions_exported(self):
        assert callable(ar.render_system_credit_usage_html)
        assert callable(ar.render_system_credit_usage_text_fallback)


# ---------------------------------------------------------------------------
# Category content
# ---------------------------------------------------------------------------


class TestCategoryContent:
    def test_ai_category_has_ai_services(self):
        ai_cat = next(
            c for c in ar._SYSTEM_CREDIT_SERVICE_CATEGORIES
            if c["category"] == "AI operations"
        )
        assert "ai_draft_reply" in ai_cat["services"]
        assert "ai_enrichment" in ai_cat["services"]

    def test_data_category_has_enrichment(self):
        data_cat = next(
            c for c in ar._SYSTEM_CREDIT_SERVICE_CATEGORIES
            if c["category"] == "Data operations"
        )
        assert "contact_enrichment" in data_cat["services"]
        assert "company_enrichment" in data_cat["services"]

    def test_messaging_category_has_send_services(self):
        msg_cat = next(
            c for c in ar._SYSTEM_CREDIT_SERVICE_CATEGORIES
            if c["category"] == "Messaging operations"
        )
        assert "email_send" in msg_cat["services"]
        assert "sms_send" in msg_cat["services"]

    def test_workflow_category_has_run_services(self):
        wf_cat = next(
            c for c in ar._SYSTEM_CREDIT_SERVICE_CATEGORIES
            if c["category"] == "Workflow operations"
        )
        assert "workflow_run" in wf_cat["services"]


# ---------------------------------------------------------------------------
# HTML building blocks
# ---------------------------------------------------------------------------


class TestHeader:
    def test_has_system_axis_chip(self):
        html = ar._system_credit_header_html()
        assert "SYSTEM" in html

    def test_has_title(self):
        html = ar._system_credit_header_html()
        assert "Credit usage and billing" in html

    def test_has_subtitle(self):
        html = ar._system_credit_header_html()
        assert "live balance" in html

    def test_uses_muted_chip_background(self):
        """SYSTEM chip is muted to signal 'metadata, not data'."""
        html = ar._system_credit_header_html()
        assert ar._G8_MUTED_BG in html


class TestStatusCard:
    def test_has_live_balance_status_title(self):
        html = ar._system_credit_status_card_html()
        assert "Live-balance status" in html

    def test_contains_full_status_note(self):
        html = ar._system_credit_status_card_html()
        # Note is escaped - check a distinctive phrase
        assert "developer API" in html

    def test_uses_warning_palette(self):
        """Status card uses warning amber to flag the data gap."""
        html = ar._system_credit_status_card_html()
        assert ar._G8_WARNING_BG in html
        assert ar._G8_WARNING_FG in html


class TestServiceChip:
    def test_renders_service_name(self):
        html = ar._system_credit_service_chip_html("ai_enrichment")
        assert "ai_enrichment" in html

    def test_uses_accent_palette(self):
        html = ar._system_credit_service_chip_html("ai_enrichment")
        assert ar._G8_ACCENT_BG in html
        assert ar._G8_PRIMARY in html

    def test_xss_escaped(self):
        html = ar._system_credit_service_chip_html("<script>")
        assert "<script>" not in html
        assert "&lt;script&gt;" in html

    def test_monospace_font(self):
        """Service names render in monospace (they look like code tokens)."""
        html = ar._system_credit_service_chip_html("ai_enrichment")
        assert "monospace" in html.lower()


class TestCategoryCard:
    def test_renders_title(self):
        html = ar._system_credit_category_card_html(
            {"category": "Test Cat", "description": "desc", "services": ["a", "b"]}
        )
        assert "Test Cat" in html

    def test_renders_description(self):
        html = ar._system_credit_category_card_html(
            {"category": "X", "description": "A test description", "services": ["a"]}
        )
        assert "A test description" in html

    def test_renders_all_service_chips(self):
        html = ar._system_credit_category_card_html(
            {"category": "X", "description": "y", "services": ["one", "two", "three"]}
        )
        assert "one" in html
        assert "two" in html
        assert "three" in html

    def test_count_badge(self):
        html = ar._system_credit_category_card_html(
            {"category": "X", "description": "y", "services": ["a", "b", "c"]}
        )
        assert "3 services" in html

    def test_xss_escaped_title(self):
        html = ar._system_credit_category_card_html(
            {"category": "<script>", "description": "d", "services": []}
        )
        assert "<script>" not in html

    def test_handles_missing_services_key(self):
        html = ar._system_credit_category_card_html(
            {"category": "X", "description": "y"}
        )
        assert "X" in html
        assert "0 services" in html


class TestCategoriesSection:
    def test_renders_section_title(self):
        html = ar._system_credit_categories_section_html()
        assert "Credit-consuming service categories" in html

    def test_renders_all_four_categories(self):
        html = ar._system_credit_categories_section_html()
        assert "AI operations" in html
        assert "Data operations" in html
        assert "Messaging operations" in html
        assert "Workflow operations" in html


class TestTips:
    def test_renders_section_title(self):
        html = ar._system_credit_tips_html()
        assert "Cost-control tips" in html

    def test_renders_all_tips(self):
        html = ar._system_credit_tips_html()
        for tip in ar._SYSTEM_CREDIT_TIP_ITEMS:
            # Description may be escaped; check a distinctive snippet
            snippet = tip[:20]
            # Run simple escape for any special chars
            import html as _html
            assert _html.escape(snippet) in html or snippet in html

    def test_uses_accent_palette(self):
        html = ar._system_credit_tips_html()
        assert ar._G8_ACCENT_BG in html


class TestDrillUp:
    def test_has_related_surfaces_heading(self):
        html = ar._system_credit_drill_up_html()
        assert "Related surfaces" in html

    def test_has_five_pointers(self):
        html = ar._system_credit_drill_up_html()
        assert "g8://copilot/home" in html
        assert "g8://deals/this-week" in html
        assert "g8://deals/pipeline" in html
        assert "g8://activities/today" in html
        assert "g8://tasks/due-today" in html


# ---------------------------------------------------------------------------
# Full HTML render
# ---------------------------------------------------------------------------


class TestRenderHtml:
    def test_has_doctype(self):
        html = ar.render_system_credit_usage_html()
        assert html.startswith("<!DOCTYPE html>")

    def test_closes_html(self):
        html = ar.render_system_credit_usage_html()
        assert html.endswith("</body></html>")

    def test_has_title(self):
        html = ar.render_system_credit_usage_html()
        assert "<title>Credit usage - graph8</title>" in html

    def test_includes_header(self):
        html = ar.render_system_credit_usage_html()
        assert "SYSTEM" in html
        assert "Credit usage and billing" in html

    def test_includes_status_card(self):
        html = ar.render_system_credit_usage_html()
        assert "Live-balance status" in html

    def test_includes_categories_section(self):
        html = ar.render_system_credit_usage_html()
        assert "Credit-consuming service categories" in html

    def test_includes_tips(self):
        html = ar.render_system_credit_usage_html()
        assert "Cost-control tips" in html

    def test_includes_drill_up(self):
        html = ar.render_system_credit_usage_html()
        assert "Related surfaces" in html

    def test_all_four_categories_present(self):
        html = ar.render_system_credit_usage_html()
        assert "AI operations" in html
        assert "Data operations" in html
        assert "Messaging operations" in html
        assert "Workflow operations" in html

    def test_representative_services_present(self):
        html = ar.render_system_credit_usage_html()
        assert "ai_enrichment" in html
        assert "contact_enrichment" in html
        assert "email_send" in html
        assert "workflow_run" in html

    def test_idempotent_output(self):
        """Static surface - should produce identical output each call."""
        assert ar.render_system_credit_usage_html() == ar.render_system_credit_usage_html()


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------


class TestTextFallback:
    def test_has_h1(self):
        txt = ar.render_system_credit_usage_text_fallback()
        assert "# Credit usage and billing" in txt

    def test_has_status_section(self):
        txt = ar.render_system_credit_usage_text_fallback()
        assert "## Live-balance status" in txt

    def test_has_categories_section(self):
        txt = ar.render_system_credit_usage_text_fallback()
        assert "## Credit-consuming service categories" in txt

    def test_has_all_four_subsections(self):
        txt = ar.render_system_credit_usage_text_fallback()
        assert "### AI operations" in txt
        assert "### Data operations" in txt
        assert "### Messaging operations" in txt
        assert "### Workflow operations" in txt

    def test_has_tips_section(self):
        txt = ar.render_system_credit_usage_text_fallback()
        assert "## Cost-control tips" in txt

    def test_has_related_surfaces(self):
        txt = ar.render_system_credit_usage_text_fallback()
        assert "## Related surfaces" in txt

    def test_lists_services_as_code(self):
        txt = ar.render_system_credit_usage_text_fallback()
        assert "`ai_enrichment`" in txt
        assert "`contact_enrichment`" in txt
        assert "`email_send`" in txt

    def test_notes_no_backend_fetch(self):
        """Text fallback should document the static-knowledge pattern."""
        txt = ar.render_system_credit_usage_text_fallback()
        assert "static-knowledge surface" in txt

    def test_notes_planned_endpoint(self):
        """Text fallback should name the future live endpoint."""
        txt = ar.render_system_credit_usage_text_fallback()
        assert "/credits/usage" in txt

    def test_idempotent_output(self):
        assert ar.render_system_credit_usage_text_fallback() == ar.render_system_credit_usage_text_fallback()


# ---------------------------------------------------------------------------
# Design tokens
# ---------------------------------------------------------------------------


class TestDesignTokens:
    @pytest.mark.parametrize(
        "banned_hex",
        ["#1d4ed8", "#166534", "#991b1b", "#0891b2"],
    )
    def test_no_banned_hexes(self, banned_hex):
        html = ar.render_system_credit_usage_html()
        assert banned_hex.lower() not in html.lower(), f"banned hex {banned_hex} found"

    def test_uses_primary_purple(self):
        html = ar.render_system_credit_usage_html()
        assert ar._G8_PRIMARY in html

    def test_uses_aeonik_font(self):
        html = ar.render_system_credit_usage_html()
        assert "Aeonik" in html

    def test_uses_border_token(self):
        html = ar.render_system_credit_usage_html()
        assert ar._G8_BORDER in html

    def test_uses_warning_for_status(self):
        """Status card uses warning amber to signal the data gap honestly."""
        html = ar.render_system_credit_usage_html()
        assert ar._G8_WARNING_BG in html

    def test_uses_accent_for_tips(self):
        html = ar.render_system_credit_usage_html()
        assert ar._G8_ACCENT_BG in html

    def test_uses_muted_for_system_chip(self):
        """SYSTEM chip is muted - unlike entity chips (accent-purple)."""
        html = ar.render_system_credit_usage_html()
        assert ar._G8_MUTED_BG in html


# ---------------------------------------------------------------------------
# No-JS guarantees
# ---------------------------------------------------------------------------


class TestNoJs:
    def test_no_script_tag(self):
        html = ar.render_system_credit_usage_html()
        assert "<script" not in html.lower()

    def test_no_onclick(self):
        html = ar.render_system_credit_usage_html()
        assert "onclick" not in html.lower()

    def test_no_inline_event_handlers(self):
        html = ar.render_system_credit_usage_html()
        for evt in ("onmouseover", "onload", "onerror", "onsubmit"):
            assert evt not in html.lower()


# ---------------------------------------------------------------------------
# Smoke / return types
# ---------------------------------------------------------------------------


class TestSmoke:
    def test_html_non_empty(self):
        assert len(ar.render_system_credit_usage_html()) > 500

    def test_text_non_empty(self):
        assert len(ar.render_system_credit_usage_text_fallback()) > 300


class TestReturnTypes:
    def test_html_is_str(self):
        assert isinstance(ar.render_system_credit_usage_html(), str)

    def test_text_is_str(self):
        assert isinstance(ar.render_system_credit_usage_text_fallback(), str)

    def test_header_is_str(self):
        assert isinstance(ar._system_credit_header_html(), str)

    def test_status_card_is_str(self):
        assert isinstance(ar._system_credit_status_card_html(), str)

    def test_service_chip_is_str(self):
        assert isinstance(ar._system_credit_service_chip_html("svc"), str)

    def test_category_card_is_str(self):
        assert isinstance(
            ar._system_credit_category_card_html(
                {"category": "c", "description": "d", "services": []}
            ),
            str,
        )

    def test_categories_section_is_str(self):
        assert isinstance(ar._system_credit_categories_section_html(), str)

    def test_tips_is_str(self):
        assert isinstance(ar._system_credit_tips_html(), str)

    def test_drill_up_is_str(self):
        assert isinstance(ar._system_credit_drill_up_html(), str)


# ---------------------------------------------------------------------------
# Honesty locks — this surface is DELIBERATELY HONEST about a data gap.
# These tests prevent accidental drift into fabricated live numbers.
# ---------------------------------------------------------------------------


class TestHonestyLocks:
    def test_status_explicitly_says_not_yet_exposed(self):
        """LOCK: must say live balance is NOT yet available."""
        assert "not yet exposed" in ar._SYSTEM_CREDIT_BALANCE_STATUS_NOTE

    def test_status_points_to_studio_billing(self):
        """LOCK: must direct users to the Studio billing page."""
        assert "Studio billing page" in ar._SYSTEM_CREDIT_BALANCE_STATUS_NOTE

    def test_no_fabricated_credit_amounts_in_html(self):
        """LOCK: no specific credit count numbers appear in the output.

        This surface must never fabricate per-service credit amounts
        (e.g., 'ai_enrichment = 3 credits'). Thomas's rule: never
        fabricate numbers.
        """
        html = ar.render_system_credit_usage_html()
        # These specific claim-shapes should not appear:
        forbidden = [
            "1 credit per call",
            "2 credits per call",
            "3 credits per call",
            "credits per service call",
        ]
        for phrase in forbidden:
            assert phrase not in html, f"forbidden claim-shape appeared: {phrase}"

    def test_no_fabricated_usage_totals(self):
        """LOCK: no fabricated per-org usage statistics in the output."""
        html = ar.render_system_credit_usage_html()
        # Should not contain any "used: N credits this month" claims.
        forbidden = [
            "used this month",
            "used this week",
            "remaining balance:",
            "available credits:",
        ]
        for phrase in forbidden:
            assert phrase not in html.lower(), f"fabricated usage claim: {phrase}"
