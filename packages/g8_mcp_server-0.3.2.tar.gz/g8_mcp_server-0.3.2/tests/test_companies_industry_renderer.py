"""Tests for Surface #78 — g8://companies/industry/{industry}.

Coverage plan:
- normalize: canonical keys (16), URL-friendly aliases (180+), invalid strings,
  non-string inputs, None/empty/whitespace, case variants, hyphen/underscore forms.
- label/short_label: every canonical + one alias.
- palette: every canonical key (must use graph8 tokens only; never the 4 banned
  Studio hexes).
- clip: empty/None/whitespace/over-cap/under-cap/non-string.
- display_name: name, domain fallback, unnamed fallback, non-dict.
- location: every field present, none present, missing middle, non-string values.
- header/kpi/stats/row: structural HTML presence. Stats row MUST show
  "Employee tiers" (NOT "Seniority tiers" — that's Surface #77's signature).
- overflow banner: positive, zero, negative. URL uses industry param.
- drill_up: siblings include every other industry, never self-ref, includes
  cross-entity link to g8://contacts/dashboard (first cross-entity for
  companies surfaces).
- empty_state: zero_state=True accent, zero_state=False muted.
- render_companies_industry_html: happy path, empty list, None payload,
  invalid URI key, non-list payload, XSS escape, employee_count sort.
- render_companies_industry_text_fallback: same set of branches.
- Design tokens: locks out banned Studio hexes + confirms graph8 tokens present.
- no_js: ensure no <script> or event handlers in any render output.
- Smoke: all aliases + canonicals route to valid URIs without KeyError.
- Constants: tuple immutability + completeness + no alias shadowing.
- Employee tier: micro / smb / mid / enterprise buckets with edge values.
"""

from __future__ import annotations

import pytest

from mcp_server.g8_mcp_server.app_renderer import (
    _COMPANIES_INDUSTRY_ALIASES,
    _COMPANIES_INDUSTRY_LABELS,
    _COMPANIES_INDUSTRY_VALID,
    _companies_industry_chip_html,
    _companies_industry_clip,
    _companies_industry_display_name,
    _companies_industry_drill_up_html,
    _companies_industry_empty_state_html,
    _companies_industry_employee_tier,
    _companies_industry_header_html,
    _companies_industry_kpi_card_html,
    _companies_industry_label,
    _companies_industry_list_html,
    _companies_industry_location,
    _companies_industry_normalize,
    _companies_industry_overflow_banner_html,
    _companies_industry_palette,
    _companies_industry_row_html,
    _companies_industry_short_label,
    _companies_industry_stats_row_html,
    render_companies_industry_html,
    render_companies_industry_text_fallback,
)


# ---------------------------------------------------------------------------
# Normalize — canonical keys
# ---------------------------------------------------------------------------

class TestNormalizeCanonical:
    @pytest.mark.parametrize("key", list(_COMPANIES_INDUSTRY_VALID))
    def test_all_canonical_self_map(self, key):
        assert _companies_industry_normalize(key) == key

    @pytest.mark.parametrize("key", list(_COMPANIES_INDUSTRY_VALID))
    def test_canonical_uppercase(self, key):
        assert _companies_industry_normalize(key.upper()) == key

    @pytest.mark.parametrize("key", list(_COMPANIES_INDUSTRY_VALID))
    def test_canonical_with_spaces(self, key):
        assert _companies_industry_normalize(f"  {key}  ") == key

    def test_real_estate_hyphen_form(self):
        assert _companies_industry_normalize("real-estate") == "real_estate"

    def test_real_estate_title_case(self):
        assert _companies_industry_normalize("Real Estate") == "real_estate"

    def test_professional_services_spaces(self):
        assert _companies_industry_normalize("Professional Services") == "professional_services"

    def test_saas_case_variants(self):
        assert _companies_industry_normalize("SaaS") == "saas"
        assert _companies_industry_normalize("SAAS") == "saas"
        assert _companies_industry_normalize("sAaS") == "saas"


# ---------------------------------------------------------------------------
# Normalize — aliases
# ---------------------------------------------------------------------------

class TestNormalizeAliases:
    @pytest.mark.parametrize("alias,expected", [
        # SaaS
        ("cloud", "saas"),
        ("cloud-computing", "saas"),
        ("software", "saas"),
        ("enterprise-software", "saas"),
        ("b2b-saas", "saas"),
        ("paas", "saas"),
        ("iaas", "saas"),
        ("platform", "saas"),
        ("devtools", "saas"),
        ("dev-tools", "saas"),
        # FinTech
        ("finance", "fintech"),
        ("banking", "fintech"),
        ("financial-services", "fintech"),
        ("payments", "fintech"),
        ("insurtech", "fintech"),
        ("wealthtech", "fintech"),
        ("crypto", "fintech"),
        ("blockchain", "fintech"),
        ("defi", "fintech"),
        ("lending", "fintech"),
        ("insurance", "fintech"),
        # Healthcare
        ("health", "healthcare"),
        ("medical", "healthcare"),
        ("healthtech", "healthcare"),
        ("health-tech", "healthcare"),
        ("clinical", "healthcare"),
        ("hospital", "healthcare"),
        ("digital-health", "healthcare"),
        # Biotech
        ("pharma", "biotech"),
        ("pharmaceutical", "biotech"),
        ("life-sciences", "biotech"),
        ("biotechnology", "biotech"),
        ("genomics", "biotech"),
        ("medical-device", "biotech"),
        ("medtech", "biotech"),
        # Manufacturing
        ("industrial", "manufacturing"),
        ("mfg", "manufacturing"),
        ("heavy-industry", "manufacturing"),
        ("machinery", "manufacturing"),
        ("chemicals", "manufacturing"),
        ("aerospace", "manufacturing"),
        ("defense", "manufacturing"),
        # Retail
        ("consumer-goods", "retail"),
        ("cpg", "retail"),
        ("fmcg", "retail"),
        ("apparel", "retail"),
        ("fashion", "retail"),
        ("luxury", "retail"),
        ("grocery", "retail"),
        ("beauty", "retail"),
        # E-commerce
        ("e-commerce", "ecommerce"),
        ("online-retail", "ecommerce"),
        ("marketplace", "ecommerce"),
        ("dtc", "ecommerce"),
        ("d2c", "ecommerce"),
        ("direct-to-consumer", "ecommerce"),
        # Media
        ("entertainment", "media"),
        ("publishing", "media"),
        ("news", "media"),
        ("broadcasting", "media"),
        ("streaming", "media"),
        ("music", "media"),
        ("film", "media"),
        ("gaming", "media"),
        ("advertising", "media"),
        ("adtech", "media"),
        ("martech", "media"),
        # Education
        ("edtech", "education"),
        ("edu", "education"),
        ("learning", "education"),
        ("k12", "education"),
        ("k-12", "education"),
        ("higher-ed", "education"),
        ("university", "education"),
        ("training", "education"),
        ("elearning", "education"),
        # Telecom
        ("telecommunications", "telecom"),
        ("wireless", "telecom"),
        ("broadband", "telecom"),
        ("isp", "telecom"),
        ("carrier", "telecom"),
        ("5g", "telecom"),
        ("networking", "telecom"),
        # Real Estate
        ("realestate", "real_estate"),
        ("proptech", "real_estate"),
        ("property", "real_estate"),
        ("commercial-real-estate", "real_estate"),
        ("cre", "real_estate"),
        ("reit", "real_estate"),
        # Professional Services
        ("consulting", "professional_services"),
        ("legal-services", "professional_services"),
        ("accounting-services", "professional_services"),
        ("advisory", "professional_services"),
        ("law-firm", "professional_services"),
        ("audit", "professional_services"),
        ("staffing", "professional_services"),
        ("agency", "professional_services"),
        # Energy
        ("oil-gas", "energy"),
        ("oil-and-gas", "energy"),
        ("utilities", "energy"),
        ("renewable-energy", "energy"),
        ("renewables", "energy"),
        ("power", "energy"),
        ("solar", "energy"),
        ("wind", "energy"),
        ("cleantech", "energy"),
        # Nonprofit
        ("ngo", "nonprofit"),
        ("non-profit", "nonprofit"),
        ("charity", "nonprofit"),
        ("foundation", "nonprofit"),
        ("philanthropy", "nonprofit"),
        ("mission-driven", "nonprofit"),
        ("social-impact", "nonprofit"),
        # Hospitality
        ("travel", "hospitality"),
        ("tourism", "hospitality"),
        ("hotels", "hospitality"),
        ("hotel", "hospitality"),
        ("restaurants", "hospitality"),
        ("food-services", "hospitality"),
        ("leisure", "hospitality"),
        ("airlines", "hospitality"),
        ("cruise", "hospitality"),
        # Automotive
        ("auto", "automotive"),
        ("transportation", "automotive"),
        ("mobility", "automotive"),
        ("car", "automotive"),
        ("vehicle", "automotive"),
        ("ev", "automotive"),
        ("electric-vehicle", "automotive"),
        ("logistics", "automotive"),
        ("shipping", "automotive"),
        ("fleet", "automotive"),
    ])
    def test_alias_maps_to_canonical(self, alias, expected):
        assert _companies_industry_normalize(alias) == expected

    def test_alias_uppercase(self):
        assert _companies_industry_normalize("PHARMA") == "biotech"

    def test_alias_with_spaces(self):
        assert _companies_industry_normalize("  software  ") == "saas"

    def test_alias_mixed_underscore_hyphen(self):
        # both hyphenated and underscored forms of same alias work
        assert _companies_industry_normalize("real-estate") == "real_estate"
        assert _companies_industry_normalize("real_estate") == "real_estate"
        assert _companies_industry_normalize("cloud-computing") == "saas"
        assert _companies_industry_normalize("cloud_computing") == "saas"


# ---------------------------------------------------------------------------
# Normalize — invalid
# ---------------------------------------------------------------------------

class TestNormalizeInvalid:
    @pytest.mark.parametrize("bad", [
        "", "   ", None, 42, [], {}, "zzzzzz", "unknown-industry",
        "spaceship", "dragon", "?", "null",
        "saa",  # partial
        True,
    ])
    def test_invalid_returns_none(self, bad):
        assert _companies_industry_normalize(bad) is None

    def test_empty_after_strip(self):
        assert _companies_industry_normalize("\t\n  ") is None

    def test_no_collision_with_nested_literals(self):
        """Industry values MUST NOT match literal trailing paths `notes`,
        `deals`, `contacts`, `activities` — those are reserved for
        `g8://companies/{company_id}/{literal}` templates (#37/#41/#46/#47).
        """
        for literal in ("notes", "deals", "contacts", "activities"):
            assert _companies_industry_normalize(literal) is None, (
                f"Industry value {literal!r} would collide with nested template"
            )


# ---------------------------------------------------------------------------
# Labels
# ---------------------------------------------------------------------------

class TestLabel:
    def test_every_canonical_has_label(self):
        for key in _COMPANIES_INDUSTRY_VALID:
            label = _companies_industry_label(key)
            assert isinstance(label, str) and label

    def test_saas_label(self):
        assert _companies_industry_label("saas") == "SaaS"

    def test_real_estate_label(self):
        assert _companies_industry_label("real_estate") == "Real Estate"

    def test_professional_services_label(self):
        assert _companies_industry_label("professional_services") == "Professional Services"

    def test_biotech_label(self):
        assert _companies_industry_label("biotech") == "Biotech & Pharma"

    def test_alias_resolves_to_canonical_label(self):
        assert _companies_industry_label("software") == "SaaS"
        assert _companies_industry_label("pharma") == "Biotech & Pharma"
        assert _companies_industry_label("proptech") == "Real Estate"

    def test_invalid_returns_companies(self):
        assert _companies_industry_label("bogus") == "Companies"


class TestShortLabel:
    def test_same_as_label(self):
        for key in _COMPANIES_INDUSTRY_VALID:
            assert _companies_industry_short_label(key) == _companies_industry_label(key)


# ---------------------------------------------------------------------------
# Palette
# ---------------------------------------------------------------------------

class TestPalette:
    BANNED_HEXES = ("#1d4ed8", "#166534", "#991b1b", "#0891b2")

    @pytest.mark.parametrize("key", list(_COMPANIES_INDUSTRY_VALID))
    def test_returns_bg_fg_tuple(self, key):
        bg, fg = _companies_industry_palette(key)
        assert isinstance(bg, str) and bg
        assert isinstance(fg, str) and fg

    @pytest.mark.parametrize("key", list(_COMPANIES_INDUSTRY_VALID))
    def test_no_banned_hexes(self, key):
        bg, fg = _companies_industry_palette(key)
        for banned in self.BANNED_HEXES:
            assert banned not in bg.lower()
            assert banned not in fg.lower()

    def test_invalid_uses_muted(self):
        bg, fg = _companies_industry_palette("bogus")
        assert bg == "#f9f9f9"  # _G8_MUTED_BG

    def test_saas_uses_accent(self):
        bg, fg = _companies_industry_palette("saas")
        assert bg == "#f2eafe"  # _G8_ACCENT_BG
        assert fg == "#7d2df3"  # _G8_PRIMARY

    def test_fintech_uses_accent(self):
        bg, fg = _companies_industry_palette("fintech")
        assert bg == "#f2eafe"

    def test_ecommerce_uses_accent(self):
        bg, fg = _companies_industry_palette("ecommerce")
        assert bg == "#f2eafe"

    def test_media_uses_accent(self):
        bg, fg = _companies_industry_palette("media")
        assert bg == "#f2eafe"

    def test_telecom_uses_accent(self):
        bg, fg = _companies_industry_palette("telecom")
        assert bg == "#f2eafe"

    def test_healthcare_uses_warning(self):
        bg, fg = _companies_industry_palette("healthcare")
        assert bg == "#fff3c4"  # _G8_WARNING_BG

    def test_biotech_uses_warning(self):
        bg, fg = _companies_industry_palette("biotech")
        assert bg == "#fff3c4"

    def test_manufacturing_uses_warning(self):
        bg, fg = _companies_industry_palette("manufacturing")
        assert bg == "#fff3c4"

    def test_energy_uses_warning(self):
        bg, fg = _companies_industry_palette("energy")
        assert bg == "#fff3c4"

    def test_real_estate_uses_warning(self):
        bg, fg = _companies_industry_palette("real_estate")
        assert bg == "#fff3c4"

    def test_automotive_uses_warning(self):
        bg, fg = _companies_industry_palette("automotive")
        assert bg == "#fff3c4"

    def test_retail_uses_muted(self):
        bg, fg = _companies_industry_palette("retail")
        assert bg == "#f9f9f9"

    def test_education_uses_muted(self):
        bg, fg = _companies_industry_palette("education")
        assert bg == "#f9f9f9"

    def test_professional_services_uses_muted(self):
        bg, fg = _companies_industry_palette("professional_services")
        assert bg == "#f9f9f9"

    def test_nonprofit_uses_muted(self):
        bg, fg = _companies_industry_palette("nonprofit")
        assert bg == "#f9f9f9"

    def test_hospitality_uses_muted(self):
        bg, fg = _companies_industry_palette("hospitality")
        assert bg == "#f9f9f9"


# ---------------------------------------------------------------------------
# Clip
# ---------------------------------------------------------------------------

class TestClip:
    def test_short_unchanged(self):
        assert _companies_industry_clip("hi", 100) == "hi"

    def test_exactly_at_cap(self):
        s = "a" * 10
        assert _companies_industry_clip(s, 10) == s

    def test_truncates_over_cap(self):
        result = _companies_industry_clip("a" * 100, 10)
        assert result.endswith("…")
        assert len(result) == 10

    def test_none(self):
        assert _companies_industry_clip(None, 10) == ""

    def test_empty(self):
        assert _companies_industry_clip("", 10) == ""

    def test_whitespace(self):
        assert _companies_industry_clip("   ", 10) == ""

    def test_coerces_int(self):
        assert _companies_industry_clip(42, 10) == "42"

    def test_strips_whitespace(self):
        assert _companies_industry_clip("  hello  ", 100) == "hello"


# ---------------------------------------------------------------------------
# Employee tier
# ---------------------------------------------------------------------------

class TestEmployeeTier:
    def test_none(self):
        assert _companies_industry_employee_tier(None) is None

    def test_empty_string(self):
        assert _companies_industry_employee_tier("") is None

    def test_unparseable(self):
        assert _companies_industry_employee_tier("abc") is None

    def test_micro(self):
        assert _companies_industry_employee_tier(5) == "micro"
        assert _companies_industry_employee_tier("9") == "micro"
        assert _companies_industry_employee_tier(0) == "micro"

    def test_smb(self):
        assert _companies_industry_employee_tier(10) == "smb"
        assert _companies_industry_employee_tier(50) == "smb"
        assert _companies_industry_employee_tier("99") == "smb"

    def test_mid(self):
        assert _companies_industry_employee_tier(100) == "mid"
        assert _companies_industry_employee_tier("500") == "mid"
        assert _companies_industry_employee_tier(999) == "mid"

    def test_enterprise(self):
        assert _companies_industry_employee_tier(1000) == "enterprise"
        assert _companies_industry_employee_tier("5000") == "enterprise"
        assert _companies_industry_employee_tier("100000") == "enterprise"

    def test_with_commas(self):
        assert _companies_industry_employee_tier("1,500") == "enterprise"
        assert _companies_industry_employee_tier("50,000") == "enterprise"

    def test_string_spaces(self):
        assert _companies_industry_employee_tier(" 250 ") == "mid"


# ---------------------------------------------------------------------------
# Display name
# ---------------------------------------------------------------------------

class TestDisplayName:
    def test_name(self):
        result = _companies_industry_display_name({"name": "Acme Corp"})
        assert "Acme Corp" in result

    def test_domain_fallback(self):
        result = _companies_industry_display_name({"domain": "acme.com"})
        assert "acme.com" in result

    def test_unnamed_fallback(self):
        assert _companies_industry_display_name({}) == "(unnamed company)"

    def test_non_dict(self):
        assert _companies_industry_display_name(None) == "(unnamed company)"
        assert _companies_industry_display_name("foo") == "(unnamed company)"
        assert _companies_industry_display_name([]) == "(unnamed company)"

    def test_xss_escape(self):
        result = _companies_industry_display_name({"name": "<script>Evil</script>"})
        assert "<script>" not in result
        assert "&lt;script&gt;" in result

    def test_empty_name_fallback_to_domain(self):
        result = _companies_industry_display_name({"name": "  ", "domain": "acme.com"})
        assert "acme.com" in result


# ---------------------------------------------------------------------------
# Location
# ---------------------------------------------------------------------------

class TestLocation:
    def test_all_three(self):
        loc = _companies_industry_location(
            {"city": "SF", "state": "CA", "country": "US"}
        )
        assert "SF, CA, US" in loc

    def test_missing_city(self):
        loc = _companies_industry_location({"state": "CA", "country": "US"})
        assert loc == "CA, US"

    def test_empty_fields(self):
        loc = _companies_industry_location(
            {"city": "", "state": "  ", "country": None}
        )
        assert loc == ""

    def test_all_missing(self):
        assert _companies_industry_location({}) == ""

    def test_non_dict(self):
        assert _companies_industry_location(None) == ""
        assert _companies_industry_location("foo") == ""

    def test_xss_escape(self):
        loc = _companies_industry_location({"city": "<b>City</b>"})
        assert "<b>" not in loc
        assert "&lt;b&gt;" in loc


# ---------------------------------------------------------------------------
# Header
# ---------------------------------------------------------------------------

class TestHeader:
    def test_contains_label(self):
        html = _companies_industry_header_html("saas", 5)
        assert "SaaS" in html

    def test_contains_count(self):
        html = _companies_industry_header_html("saas", 5)
        assert "5 companies" in html

    def test_singular(self):
        html = _companies_industry_header_html("saas", 1)
        assert "1 company" in html
        assert "1 companies" not in html

    def test_zero(self):
        html = _companies_industry_header_html("saas", 0)
        assert "0 companies" in html

    def test_uses_graph8_primary(self):
        html = _companies_industry_header_html("saas", 10)
        assert "#7d2df3" in html.lower()

    def test_industry_prefix(self):
        html = _companies_industry_header_html("saas", 10)
        assert "Industry" in html


# ---------------------------------------------------------------------------
# KPI card / stats row
# ---------------------------------------------------------------------------

class TestKpiCard:
    def test_label_and_value(self):
        html = _companies_industry_kpi_card_html("Total", "42")
        assert "Total" in html
        assert "42" in html

    def test_accent_variant_uses_primary(self):
        html = _companies_industry_kpi_card_html("T", "1", accent=True)
        assert "#7d2df3" in html.lower() or "#f2eafe" in html.lower()


class TestStatsRow:
    def test_four_cards(self):
        html = _companies_industry_stats_row_html([
            {"domain": "acme.com", "country": "US", "employee_count": "50"},
        ])
        assert "Total" in html
        assert "With domain" in html
        assert "Unique countries" in html
        assert "Employee tiers" in html

    def test_has_employee_tiers_not_seniority(self):
        """Companies pane is account-level — show employee tier coverage,
        NOT seniority tiers (that's #77's signature)."""
        html = _companies_industry_stats_row_html([
            {"domain": "acme.com", "employee_count": "100"},
        ])
        assert "Employee tiers" in html
        # #77's seniority signature MUST be absent.
        assert "Seniority tiers" not in html
        # #77's unique-companies signature MUST be absent (it's a
        # companies-pane so "unique companies" would be nonsensical).
        assert "Unique companies" not in html

    def test_counts_correctly(self):
        html = _companies_industry_stats_row_html([
            {"domain": "acme.com", "country": "US", "employee_count": "50"},
            {"domain": "beta.com", "country": "US", "employee_count": "500"},
            {"domain": "", "country": "CA", "employee_count": "5000"},
        ])
        assert "3" in html
        # 2 with domain; 2 countries; 3 tiers (smb/mid/enterprise)
        assert "2" in html

    def test_empty_list(self):
        html = _companies_industry_stats_row_html([])
        assert "0" in html

    def test_non_dict_entries_filtered(self):
        html = _companies_industry_stats_row_html([
            {"domain": "acme.com"},
            "bogus",
            None,
        ])
        assert "Total" in html


# ---------------------------------------------------------------------------
# Chip
# ---------------------------------------------------------------------------

class TestChip:
    def test_renders_label(self):
        html = _companies_industry_chip_html("SaaS", bg="#fff", fg="#000")
        assert "SaaS" in html

    def test_border_optional(self):
        html_no_border = _companies_industry_chip_html(
            "SaaS", bg="#fff", fg="#000"
        )
        assert "border:none" in html_no_border
        html_with_border = _companies_industry_chip_html(
            "SaaS", bg="#fff", fg="#000", border="#000"
        )
        assert "border:1px solid" in html_with_border


# ---------------------------------------------------------------------------
# Row
# ---------------------------------------------------------------------------

class TestRow:
    def test_basic(self):
        html = _companies_industry_row_html(
            {
                "name": "Acme SaaS",
                "domain": "acme.com",
                "employee_count": "100",
                "founded_year": 2020,
                "city": "SF",
                "country": "US",
            },
            "saas",
        )
        assert "Acme SaaS" in html
        assert "acme.com" in html
        assert "100 employees" in html
        assert "founded 2020" in html

    def test_xss_escape_name(self):
        html = _companies_industry_row_html(
            {"name": "<script>alert('x')</script>"},
            "saas",
        )
        assert "<script>" not in html
        assert "&lt;script&gt;" in html

    def test_xss_escape_domain(self):
        html = _companies_industry_row_html(
            {"name": "A", "domain": "<x>evil.com"},
            "saas",
        )
        assert "<x>" not in html
        assert "&lt;x&gt;" in html

    def test_xss_escape_description(self):
        html = _companies_industry_row_html(
            {"name": "A", "description": "<img onerror=x>"},
            "saas",
        )
        assert "<img onerror" not in html
        assert "&lt;img" in html

    def test_missing_fields_graceful(self):
        html = _companies_industry_row_html({}, "saas")
        assert "(unnamed company)" in html

    def test_chip_present(self):
        html = _companies_industry_row_html({"name": "A"}, "fintech")
        assert "FinTech" in html

    def test_tier_chip_smb(self):
        html = _companies_industry_row_html(
            {"name": "A", "employee_count": "50"},
            "saas",
        )
        assert "SMB" in html

    def test_tier_chip_enterprise(self):
        html = _companies_industry_row_html(
            {"name": "A", "employee_count": "5000"},
            "manufacturing",
        )
        assert "Enterprise" in html

    def test_no_tier_chip_when_missing(self):
        html = _companies_industry_row_html({"name": "A"}, "saas")
        # No employee_count → no tier chip rendered.
        for tier_label in ("Micro", "SMB", "Mid", "Enterprise"):
            assert tier_label not in html

    def test_location_rendered(self):
        html = _companies_industry_row_html(
            {
                "name": "A",
                "city": "SF",
                "state": "CA",
                "country": "US",
            },
            "saas",
        )
        assert "SF, CA, US" in html


# ---------------------------------------------------------------------------
# List
# ---------------------------------------------------------------------------

class TestList:
    def test_renders_all_rows(self):
        companies = [{"name": f"Co{i}"} for i in range(5)]
        html = _companies_industry_list_html(companies, "saas")
        for i in range(5):
            assert f"Co{i}" in html

    def test_caps_at_100(self):
        companies = [{"name": f"Co{i}"} for i in range(150)]
        html = _companies_industry_list_html(companies, "saas")
        assert "Co99" in html
        assert "Co100" not in html


# ---------------------------------------------------------------------------
# Overflow banner
# ---------------------------------------------------------------------------

class TestOverflowBanner:
    def test_zero(self):
        assert _companies_industry_overflow_banner_html(0, "saas") == ""

    def test_negative(self):
        assert _companies_industry_overflow_banner_html(-5, "saas") == ""

    def test_positive(self):
        html = _companies_industry_overflow_banner_html(42, "saas")
        assert "42 more" in html
        assert "industry=saas" in html
        assert "page=2" in html

    def test_uses_normalized_key_in_url(self):
        html = _companies_industry_overflow_banner_html(5, "software")
        assert "industry=saas" in html

    def test_uses_muted_bg(self):
        html = _companies_industry_overflow_banner_html(10, "saas")
        assert "#f9f9f9" in html.lower()


# ---------------------------------------------------------------------------
# Drill up
# ---------------------------------------------------------------------------

class TestDrillUp:
    def test_has_dashboard(self):
        html = _companies_industry_drill_up_html("saas")
        assert "g8://companies/dashboard" in html

    def test_siblings_present(self):
        html = _companies_industry_drill_up_html("saas")
        for sibling in _COMPANIES_INDUSTRY_VALID:
            if sibling == "saas":
                continue
            assert f"g8://companies/industry/{sibling}" in html

    def test_cross_entity_drill_up_to_contacts_dashboard(self):
        """#78 is first companies axis-filter with cross-entity drill-up
        to the contacts family. Locked here."""
        html = _companies_industry_drill_up_html("saas")
        assert "g8://contacts/dashboard" in html
        assert "cross-entity" in html.lower()

    def test_no_self_reference(self):
        html = _companies_industry_drill_up_html("saas")
        sibling_uri = "g8://companies/industry/saas"
        assert sibling_uri + "</code>" not in html

    def test_all_siblings_for_real_estate(self):
        html = _companies_industry_drill_up_html("real_estate")
        for sibling in _COMPANIES_INDUSTRY_VALID:
            if sibling == "real_estate":
                continue
            assert sibling in html

    def test_related_surfaces_label(self):
        html = _companies_industry_drill_up_html("saas")
        assert "Related surfaces" in html


# ---------------------------------------------------------------------------
# Empty state
# ---------------------------------------------------------------------------

class TestEmptyState:
    def test_zero_state_accent(self):
        html = _companies_industry_empty_state_html("saas", zero_state=True)
        assert "#7d2df3" in html.lower() or "#f2eafe" in html.lower()
        assert "No SaaS companies" in html

    def test_zero_state_real_estate(self):
        html = _companies_industry_empty_state_html("real_estate", zero_state=True)
        assert "Real Estate" in html

    def test_unavailable_muted(self):
        html = _companies_industry_empty_state_html("saas", zero_state=False)
        assert "unavailable" in html.lower()
        assert "#f9f9f9" in html.lower() or "#dfdfdf" in html.lower()

    def test_unavailable_invalid_key(self):
        html = _companies_industry_empty_state_html("bogus", zero_state=False)
        assert "Companies unavailable" in html

    def test_unavailable_hints_valid_keys(self):
        html = _companies_industry_empty_state_html("bogus", zero_state=False)
        assert "saas" in html
        assert "fintech" in html
        assert "healthcare" in html


# ---------------------------------------------------------------------------
# render_companies_industry_html — full render
# ---------------------------------------------------------------------------

class TestRenderHtml:
    def test_happy_path(self):
        companies = [
            {
                "id": 1,
                "name": "Acme SaaS",
                "domain": "acme.com",
                "industry": "SaaS",
                "employee_count": "500",
                "city": "SF",
                "country": "US",
            },
        ]
        html = render_companies_industry_html(companies=companies, industry="saas")
        assert "<!DOCTYPE html>" in html
        assert "Acme SaaS" in html
        assert "acme.com" in html
        assert "Companies · SaaS" in html

    def test_invalid_industry(self):
        html = render_companies_industry_html(companies=[], industry="bogus")
        assert "unavailable" in html.lower()

    def test_invalid_non_string(self):
        html = render_companies_industry_html(companies=[], industry=None)
        assert "unavailable" in html.lower()

    def test_none_payload(self):
        html = render_companies_industry_html(companies=None, industry="saas")
        assert "unavailable" in html.lower()

    def test_empty_list_zero_state(self):
        html = render_companies_industry_html(companies=[], industry="saas")
        assert "No SaaS companies" in html
        assert "#7d2df3" in html.lower() or "#f2eafe" in html.lower()

    def test_non_list_payload_treated_as_empty(self):
        html = render_companies_industry_html(
            companies={"weird": "dict"}, industry="saas"
        )
        assert "No SaaS companies" in html

    def test_non_dict_entries_filtered(self):
        companies = [
            {"name": "Real"},
            "string entry",
            None,
            42,
            {"name": "Real2"},
        ]
        html = render_companies_industry_html(companies=companies, industry="saas")
        assert "Real" in html
        assert "Real2" in html
        assert "2 companies" in html

    def test_sort_by_employee_count_desc_then_name(self):
        """Companies sort by employee_count DESC (largest first), with name
        ASC tiebreaker. Divergence from #77 which sorts by seniority rank."""
        companies = [
            {"name": "Small SaaS", "employee_count": "10"},
            {"name": "Enterprise SaaS", "employee_count": "10000"},
            {"name": "Mid SaaS", "employee_count": "500"},
        ]
        html = render_companies_industry_html(
            companies=companies, industry="saas"
        )
        idx_ent = html.find("Enterprise SaaS")
        idx_mid = html.find("Mid SaaS")
        idx_small = html.find("Small SaaS")
        assert idx_ent < idx_mid < idx_small

    def test_sort_tiebreak_by_name(self):
        companies = [
            {"name": "Zebra Corp", "employee_count": "100"},
            {"name": "Alpha Corp", "employee_count": "100"},
            {"name": "Beta Corp", "employee_count": "100"},
        ]
        html = render_companies_industry_html(
            companies=companies, industry="saas"
        )
        idx_a = html.find("Alpha Corp")
        idx_b = html.find("Beta Corp")
        idx_z = html.find("Zebra Corp")
        assert idx_a < idx_b < idx_z

    def test_alias_routed(self):
        html = render_companies_industry_html(
            companies=[{"name": "Acme"}], industry="software"
        )
        assert "SaaS" in html

    def test_fintech_alias_routed(self):
        html = render_companies_industry_html(
            companies=[{"name": "Acme"}], industry="finance"
        )
        assert "FinTech" in html

    def test_pharma_alias_routed(self):
        html = render_companies_industry_html(
            companies=[{"name": "Pfizer"}], industry="pharma"
        )
        assert "Biotech &amp; Pharma" in html or "Biotech & Pharma" in html

    def test_xss_in_render(self):
        html = render_companies_industry_html(
            companies=[{"name": "<script>alert('xss')</script>"}],
            industry="saas",
        )
        assert "<script>alert" not in html
        assert "&lt;script&gt;" in html

    def test_overflow_banner_appears(self):
        companies = [{"name": f"Co{i}"} for i in range(150)]
        html = render_companies_industry_html(
            companies=companies, industry="saas"
        )
        assert "50 more" in html
        assert "industry=saas" in html

    def test_cross_entity_link_in_html(self):
        html = render_companies_industry_html(
            companies=[{"name": "Acme"}], industry="saas"
        )
        assert "g8://contacts/dashboard" in html


# ---------------------------------------------------------------------------
# Design tokens — lock-out banned hexes
# ---------------------------------------------------------------------------

class TestDesignTokens:
    BANNED = ("#1d4ed8", "#166534", "#991b1b", "#0891b2")

    def _sample_render(self):
        return render_companies_industry_html(
            companies=[
                {
                    "name": "Acme",
                    "domain": "acme.com",
                    "employee_count": "500",
                    "founded_year": 2020,
                    "city": "SF",
                    "state": "CA",
                    "country": "US",
                    "description": "We do stuff",
                },
            ],
            industry="saas",
        )

    @pytest.mark.parametrize("banned", list(BANNED))
    def test_no_banned_hexes_in_html(self, banned):
        html = self._sample_render()
        assert banned not in html.lower()

    @pytest.mark.parametrize("token", [
        "#7d2df3",  # _G8_PRIMARY
        "#f2eafe",  # _G8_ACCENT_BG
        "#dfdfdf",  # _G8_BORDER
        "#f9f9f9",  # _G8_MUTED_BG
    ])
    def test_graph8_tokens_present(self, token):
        html = self._sample_render()
        assert token in html.lower()

    def test_aeonik_font(self):
        html = self._sample_render()
        assert "Aeonik" in html


# ---------------------------------------------------------------------------
# No JavaScript
# ---------------------------------------------------------------------------

class TestNoJs:
    def test_no_script_tag(self):
        html = render_companies_industry_html(
            companies=[{"name": "A"}], industry="saas"
        )
        assert "<script" not in html.lower()
        assert "</script" not in html.lower()

    def test_no_event_handlers(self):
        html = render_companies_industry_html(
            companies=[{"name": "A"}], industry="saas"
        )
        for attr in ("onclick=", "onerror=", "onload=", "onmouseover="):
            assert attr not in html.lower()


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------

class TestTextFallback:
    def test_invalid_industry(self):
        txt = render_companies_industry_text_fallback(
            companies=[], industry="bogus"
        )
        assert "unavailable" in txt.lower()
        assert "saas" in txt
        assert "healthcare" in txt

    def test_none_payload(self):
        txt = render_companies_industry_text_fallback(
            companies=None, industry="saas"
        )
        assert "unavailable" in txt.lower()

    def test_empty_list(self):
        txt = render_companies_industry_text_fallback(
            companies=[], industry="saas"
        )
        assert "No SaaS companies yet" in txt
        assert "Related surfaces" in txt

    def test_happy_path(self):
        companies = [
            {
                "name": "Acme SaaS",
                "domain": "acme.com",
                "employee_count": "500",
                "founded_year": 2020,
                "description": "Widgets for hire",
            },
        ]
        txt = render_companies_industry_text_fallback(
            companies=companies, industry="saas"
        )
        assert "Acme SaaS" in txt
        assert "acme.com" in txt
        assert "founded 2020" in txt
        assert "Related surfaces" in txt
        assert "Backend filter" in txt

    def test_stats_in_text(self):
        companies = [
            {
                "name": "A", "domain": "a.com",
                "country": "US", "employee_count": "500",
            },
        ]
        txt = render_companies_industry_text_fallback(
            companies=companies, industry="saas"
        )
        assert "Total: 1" in txt
        assert "With domain: 1" in txt
        assert "Unique countries: 1" in txt
        assert "Employee tiers: 1" in txt

    def test_overflow_note(self):
        companies = [{"name": f"Co{i}"} for i in range(150)]
        txt = render_companies_industry_text_fallback(
            companies=companies, industry="saas"
        )
        assert "50 more" in txt

    def test_unnamed_fallback(self):
        companies = [{"employee_count": "100"}]
        txt = render_companies_industry_text_fallback(
            companies=companies, industry="saas"
        )
        assert "(unnamed company)" in txt

    def test_cross_entity_link_in_text(self):
        txt = render_companies_industry_text_fallback(
            companies=[{"name": "Acme"}], industry="saas"
        )
        assert "g8://contacts/dashboard" in txt


# ---------------------------------------------------------------------------
# Smoke — every alias normalizes + renders cleanly
# ---------------------------------------------------------------------------

class TestSmoke:
    @pytest.mark.parametrize(
        "alias",
        list(_COMPANIES_INDUSTRY_ALIASES.keys())
        + list(_COMPANIES_INDUSTRY_VALID),
    )
    def test_alias_renders_without_error(self, alias):
        html = render_companies_industry_html(
            companies=[{"name": "Acme"}], industry=alias
        )
        assert html.startswith("<!DOCTYPE html>")

    @pytest.mark.parametrize(
        "alias",
        list(_COMPANIES_INDUSTRY_ALIASES.keys())
        + list(_COMPANIES_INDUSTRY_VALID),
    )
    def test_alias_text_without_error(self, alias):
        txt = render_companies_industry_text_fallback(
            companies=[{"name": "Acme"}], industry=alias
        )
        assert len(txt) > 0


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

class TestConstants:
    def test_valid_keys_is_tuple(self):
        assert isinstance(_COMPANIES_INDUSTRY_VALID, tuple)
        assert len(_COMPANIES_INDUSTRY_VALID) == 16

    def test_labels_covers_all_valid(self):
        for key in _COMPANIES_INDUSTRY_VALID:
            assert key in _COMPANIES_INDUSTRY_LABELS
            assert isinstance(_COMPANIES_INDUSTRY_LABELS[key], str)

    def test_aliases_target_valid(self):
        for alias, target in _COMPANIES_INDUSTRY_ALIASES.items():
            assert target in _COMPANIES_INDUSTRY_VALID, (
                f"Alias {alias!r} → {target!r} not in canonical set"
            )

    def test_no_alias_equals_canonical(self):
        """Aliases must not shadow canonical keys."""
        canonical_set = set(_COMPANIES_INDUSTRY_VALID)
        for alias in _COMPANIES_INDUSTRY_ALIASES:
            assert alias not in canonical_set, (
                f"Alias {alias!r} shadows canonical key"
            )

    def test_aliases_has_150_plus(self):
        """Industries have the widest alias coverage of any axis so far."""
        assert len(_COMPANIES_INDUSTRY_ALIASES) >= 150

    def test_no_alias_collides_with_nested_literals(self):
        """Aliases MUST NOT include values that match literal trailing paths
        `notes`/`deals`/`contacts`/`activities` — those trigger the
        `companies/{company_id}/{literal}` templates (#37/#41/#46/#47)."""
        reserved = {"notes", "deals", "contacts", "activities"}
        for alias in _COMPANIES_INDUSTRY_ALIASES:
            assert alias not in reserved, (
                f"Alias {alias!r} collides with nested template literal"
            )
        for canonical in _COMPANIES_INDUSTRY_VALID:
            assert canonical not in reserved, (
                f"Canonical {canonical!r} collides with nested template literal"
            )
