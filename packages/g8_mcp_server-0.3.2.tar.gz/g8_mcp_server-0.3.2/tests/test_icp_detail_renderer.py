"""Unit tests for HTML app surface #62 — per-ICP detail renderer.

URI: ``g8://icps/{icp_id}``

Locks regression invariants for:
  - graph8 design tokens (no legacy accent hexes, no single-side colored
    accent borders, Aeonik font family, primary ``#7d2df3``)
  - drill-up card does NOT self-reference the surface URI
  - no ``<script>`` / ``javascript:`` / inline event handlers
  - XSS escape on every user-controlled field (name, description,
    buying_signals, firmographics / tech_stack keys + values)
  - display name fallback (name → ``ICP #<id>``)
  - score parser rejects bool, NaN, inf, out-of-range [0, 100]
  - score bucket mapping: positive (80+), primary (60-79),
    warning (40-59), muted default (<40)
  - id-mismatch between URI and payload renders "not_found"
  - empty/None inputs render unavailable / not-found cards
  - facts flattener handles bool/int/float/list/dict/nested input
  - buying_signals caps at _MAX_ICP_DETAIL_SIGNALS
  - smoke tests on realistic and empty payloads
"""

from __future__ import annotations

import pytest

from g8_mcp_server import app_renderer as ar


# -------------------------------------------------------------------- #
# Sample payload                                                      #
# -------------------------------------------------------------------- #

_ICP_ID = "icp-mid-saas"

_SAMPLE_ICP: dict = {
    "id": _ICP_ID,
    "name": "Mid-market SaaS",
    "description": (
        "B2B SaaS platforms at 100-500 FTE selling into the enterprise,"
        " using modern RevOps tooling and revenue > $20M ARR."
    ),
    "priority": 1,
    "status": "active",
    "pinned": True,
    "fit_score": 82.5,
    "opportunity_score": 71,
    "readiness_score": 55,
    "total_score": 69.5,
    "firmographics": {
        "industry": "SaaS",
        "employee_count": "100-500",
        "revenue_band": "$20M-$100M ARR",
        "geography": ["US", "Canada", "UK"],
        "funding_stage": "Series B+",
    },
    "tech_stack": {
        "crm": "Salesforce",
        "marketing_automation": "HubSpot",
        "data_warehouse": "Snowflake",
        "tags": ["Stripe", "Segment", "Snowflake", "dbt"],
    },
    "buying_signals": [
        "Hiring RevOps/GTM roles in last 90 days",
        "Adopted a data warehouse in last 18 months",
        "Recent series funding event",
        "Growth >= 40% YoY",
    ],
}


# -------------------------------------------------------------------- #
# _icp_detail_clip                                                    #
# -------------------------------------------------------------------- #

class TestClip:
    def test_non_string_returns_empty(self):
        assert ar._icp_detail_clip(None, 50) == ""
        assert ar._icp_detail_clip(123, 50) == ""
        assert ar._icp_detail_clip([], 50) == ""
        assert ar._icp_detail_clip({"a": 1}, 50) == ""

    def test_empty_string_returns_empty(self):
        assert ar._icp_detail_clip("", 50) == ""
        assert ar._icp_detail_clip("   ", 50) == ""
        assert ar._icp_detail_clip("\t\n", 50) == ""

    def test_escapes_html_special_chars(self):
        assert ar._icp_detail_clip("<script>", 50) == "&lt;script&gt;"
        assert ar._icp_detail_clip("A & B", 50) == "A &amp; B"
        assert ar._icp_detail_clip('"quoted"', 50) == "&quot;quoted&quot;"

    def test_clips_at_cap_with_ellipsis(self):
        long = "a" * 100
        result = ar._icp_detail_clip(long, 20)
        # last char replaced by …
        assert result.endswith("…")
        assert len(result) == 20

    def test_strips_whitespace(self):
        assert ar._icp_detail_clip("  hello  ", 50) == "hello"


# -------------------------------------------------------------------- #
# _icp_detail_name                                                    #
# -------------------------------------------------------------------- #

class TestName:
    def test_uses_name_when_present(self):
        assert ar._icp_detail_name({"name": "Mid-market SaaS"}, "icp-1") == "Mid-market SaaS"

    def test_name_fallback_on_none(self):
        assert ar._icp_detail_name(None, "icp-1") == "ICP #icp-1"

    def test_name_fallback_on_non_dict(self):
        assert ar._icp_detail_name([1, 2], "icp-1") == "ICP #icp-1"

    def test_name_fallback_on_missing_name(self):
        assert ar._icp_detail_name({"id": "icp-1"}, "icp-1") == "ICP #icp-1"

    def test_name_fallback_on_empty_name(self):
        assert ar._icp_detail_name({"name": ""}, "icp-1") == "ICP #icp-1"
        assert ar._icp_detail_name({"name": "   "}, "icp-1") == "ICP #icp-1"

    def test_name_fallback_on_non_string_name(self):
        assert ar._icp_detail_name({"name": 123}, "icp-1") == "ICP #icp-1"
        assert ar._icp_detail_name({"name": None}, "icp-1") == "ICP #icp-1"

    def test_empty_id_no_icp(self):
        assert ar._icp_detail_name(None, "") == "ICP"

    def test_escapes_name(self):
        out = ar._icp_detail_name({"name": "<script>"}, "x")
        assert "&lt;script&gt;" in out
        assert "<script>" not in out

    def test_clips_long_name(self):
        long = "A" * 200
        out = ar._icp_detail_name({"name": long}, "x")
        assert out.endswith("…")
        assert len(out) <= ar._MAX_ICP_DETAIL_NAME_LEN

    def test_escapes_id_in_fallback(self):
        out = ar._icp_detail_name(None, "<id>")
        assert "&lt;" in out
        assert "<id>" not in out


# -------------------------------------------------------------------- #
# _icp_detail_parse_score                                             #
# -------------------------------------------------------------------- #

class TestParseScore:
    def test_none(self):
        assert ar._icp_detail_parse_score(None) is None

    def test_bool_rejected(self):
        assert ar._icp_detail_parse_score(True) is None
        assert ar._icp_detail_parse_score(False) is None

    def test_int(self):
        assert ar._icp_detail_parse_score(75) == 75.0

    def test_float(self):
        assert ar._icp_detail_parse_score(82.5) == 82.5

    def test_string_numeric(self):
        assert ar._icp_detail_parse_score("75") == 75.0
        assert ar._icp_detail_parse_score("82.5") == 82.5

    def test_string_with_percent(self):
        assert ar._icp_detail_parse_score("75%") == 75.0

    def test_string_whitespace(self):
        assert ar._icp_detail_parse_score("  75  ") == 75.0

    def test_string_empty(self):
        assert ar._icp_detail_parse_score("") is None
        assert ar._icp_detail_parse_score("   ") is None

    def test_string_non_numeric(self):
        assert ar._icp_detail_parse_score("high") is None

    def test_nan_rejected(self):
        assert ar._icp_detail_parse_score(float("nan")) is None

    def test_inf_rejected(self):
        assert ar._icp_detail_parse_score(float("inf")) is None
        assert ar._icp_detail_parse_score(float("-inf")) is None

    def test_negative_rejected(self):
        assert ar._icp_detail_parse_score(-1) is None
        assert ar._icp_detail_parse_score(-0.5) is None

    def test_above_100_rejected(self):
        assert ar._icp_detail_parse_score(101) is None
        assert ar._icp_detail_parse_score(150.5) is None

    def test_zero_accepted(self):
        assert ar._icp_detail_parse_score(0) == 0.0

    def test_100_accepted(self):
        assert ar._icp_detail_parse_score(100) == 100.0

    def test_non_numeric_types(self):
        assert ar._icp_detail_parse_score([]) is None
        assert ar._icp_detail_parse_score({}) is None


# -------------------------------------------------------------------- #
# _icp_detail_format_score                                            #
# -------------------------------------------------------------------- #

class TestFormatScore:
    def test_none_shows_dash(self):
        assert ar._icp_detail_format_score(None) == "—"

    def test_whole_number_no_decimal(self):
        assert ar._icp_detail_format_score(75.0) == "75"
        assert ar._icp_detail_format_score(100.0) == "100"

    def test_decimal_shows_one_place(self):
        assert ar._icp_detail_format_score(82.5) == "82.5"
        assert ar._icp_detail_format_score(69.25) == "69.2"

    def test_zero(self):
        assert ar._icp_detail_format_score(0.0) == "0"


# -------------------------------------------------------------------- #
# _icp_detail_score_accent                                            #
# -------------------------------------------------------------------- #

class TestScoreAccent:
    def test_none(self):
        assert ar._icp_detail_score_accent(None) == "default"

    def test_positive_80_plus(self):
        assert ar._icp_detail_score_accent(80.0) == "positive"
        assert ar._icp_detail_score_accent(100.0) == "positive"
        assert ar._icp_detail_score_accent(95.5) == "positive"

    def test_primary_60_79(self):
        assert ar._icp_detail_score_accent(60.0) == "primary"
        assert ar._icp_detail_score_accent(79.9) == "primary"
        assert ar._icp_detail_score_accent(75.0) == "primary"

    def test_warning_40_59(self):
        assert ar._icp_detail_score_accent(40.0) == "warning"
        assert ar._icp_detail_score_accent(59.9) == "warning"
        assert ar._icp_detail_score_accent(55.0) == "warning"

    def test_destructive_below_40(self):
        assert ar._icp_detail_score_accent(0.0) == "destructive"
        assert ar._icp_detail_score_accent(39.9) == "destructive"
        assert ar._icp_detail_score_accent(15.0) == "destructive"


# -------------------------------------------------------------------- #
# _icp_detail_priority / _icp_detail_status / _icp_detail_is_pinned   #
# -------------------------------------------------------------------- #

class TestPriority:
    def test_none(self):
        assert ar._icp_detail_priority(None) == ""

    def test_empty_dict(self):
        assert ar._icp_detail_priority({}) == ""

    def test_int(self):
        assert ar._icp_detail_priority({"priority": 1}) == "1"

    def test_float_whole(self):
        assert ar._icp_detail_priority({"priority": 2.0}) == "2"

    def test_float_fraction(self):
        assert ar._icp_detail_priority({"priority": 2.5}) == "2.5"

    def test_bool_rejected(self):
        assert ar._icp_detail_priority({"priority": True}) == ""
        assert ar._icp_detail_priority({"priority": False}) == ""

    def test_string(self):
        assert ar._icp_detail_priority({"priority": "high"}) == "high"

    def test_string_stripped(self):
        assert ar._icp_detail_priority({"priority": "  high  "}) == "high"

    def test_empty_string(self):
        assert ar._icp_detail_priority({"priority": ""}) == ""
        assert ar._icp_detail_priority({"priority": "   "}) == ""

    def test_clipped(self):
        result = ar._icp_detail_priority({"priority": "A" * 50})
        assert len(result) == 16


class TestStatus:
    def test_none(self):
        assert ar._icp_detail_status(None) == ""

    def test_empty_dict(self):
        assert ar._icp_detail_status({}) == ""

    def test_string(self):
        assert ar._icp_detail_status({"status": "active"}) == "active"

    def test_non_string(self):
        assert ar._icp_detail_status({"status": 1}) == ""

    def test_empty_string(self):
        assert ar._icp_detail_status({"status": ""}) == ""
        assert ar._icp_detail_status({"status": "   "}) == ""

    def test_clipped(self):
        result = ar._icp_detail_status({"status": "A" * 100})
        assert len(result) == 32


class TestIsPinned:
    def test_none(self):
        assert ar._icp_detail_is_pinned(None) is False

    def test_empty_dict(self):
        assert ar._icp_detail_is_pinned({}) is False

    def test_true(self):
        assert ar._icp_detail_is_pinned({"pinned": True}) is True

    def test_false(self):
        assert ar._icp_detail_is_pinned({"pinned": False}) is False

    def test_missing(self):
        assert ar._icp_detail_is_pinned({"name": "x"}) is False

    def test_truthy_string(self):
        # Non-explicit bool still works via bool()
        assert ar._icp_detail_is_pinned({"pinned": "yes"}) is True

    def test_falsy_values(self):
        assert ar._icp_detail_is_pinned({"pinned": 0}) is False
        assert ar._icp_detail_is_pinned({"pinned": ""}) is False
        assert ar._icp_detail_is_pinned({"pinned": None}) is False


# -------------------------------------------------------------------- #
# _icp_detail_flatten_facts                                           #
# -------------------------------------------------------------------- #

class TestFlattenFacts:
    def test_none(self):
        assert ar._icp_detail_flatten_facts(None) == []

    def test_non_dict(self):
        assert ar._icp_detail_flatten_facts("facts") == []
        assert ar._icp_detail_flatten_facts([1, 2]) == []

    def test_empty_dict(self):
        assert ar._icp_detail_flatten_facts({}) == []

    def test_simple_strings(self):
        out = ar._icp_detail_flatten_facts({"industry": "SaaS", "size": "100-500"})
        assert ("Industry", "SaaS") in out
        assert ("Size", "100-500") in out

    def test_underscores_to_title_case(self):
        out = ar._icp_detail_flatten_facts({"employee_count": "500"})
        assert out[0][0] == "Employee Count"

    def test_list_values_joined(self):
        out = ar._icp_detail_flatten_facts({"geos": ["US", "CA", "UK"]})
        assert out[0][1] == "US, CA, UK"

    def test_list_values_truncated(self):
        out = ar._icp_detail_flatten_facts(
            {"tags": ["a", "b", "c", "d", "e", "f", "g", "h"]}
        )
        assert "(+2)" in out[0][1]

    def test_list_ignores_non_primitives(self):
        out = ar._icp_detail_flatten_facts({"tags": ["a", {"b": 1}, [1, 2]]})
        assert out[0][1] == "a"

    def test_list_ignores_empty_strings(self):
        out = ar._icp_detail_flatten_facts({"tags": ["", "  ", "a"]})
        assert out[0][1] == "a"

    def test_dict_values_preview(self):
        out = ar._icp_detail_flatten_facts(
            {"stack": {"crm": "Salesforce", "mart": "HubSpot"}}
        )
        assert "Salesforce" in out[0][1]
        assert "HubSpot" in out[0][1]
        assert ";" in out[0][1]

    def test_bool_values(self):
        out = ar._icp_detail_flatten_facts({"active": True, "gated": False})
        out_dict = dict(out)
        assert out_dict["Active"] == "Yes"
        assert out_dict["Gated"] == "No"

    def test_int_value(self):
        out = ar._icp_detail_flatten_facts({"count": 42})
        assert out[0][1] == "42"

    def test_float_whole(self):
        out = ar._icp_detail_flatten_facts({"ratio": 1.0})
        assert out[0][1] == "1"

    def test_float_fraction(self):
        out = ar._icp_detail_flatten_facts({"ratio": 1.25})
        assert out[0][1] == "1.25"

    def test_float_nan_skipped(self):
        out = ar._icp_detail_flatten_facts({"ratio": float("nan")})
        assert out == []

    def test_float_inf_skipped(self):
        out = ar._icp_detail_flatten_facts({"ratio": float("inf")})
        assert out == []

    def test_none_values_skipped(self):
        out = ar._icp_detail_flatten_facts({"a": None, "b": "kept"})
        assert out == [("B", "kept")]

    def test_empty_string_values_skipped(self):
        out = ar._icp_detail_flatten_facts({"a": "", "b": "kept"})
        assert out == [("B", "kept")]

    def test_empty_list_values_skipped(self):
        out = ar._icp_detail_flatten_facts({"a": [], "b": "kept"})
        assert out == [("B", "kept")]

    def test_empty_dict_values_skipped(self):
        out = ar._icp_detail_flatten_facts({"a": {}, "b": "kept"})
        assert out == [("B", "kept")]

    def test_non_string_keys_skipped(self):
        out = ar._icp_detail_flatten_facts({1: "a", "b": "kept"})
        assert out == [("B", "kept")]

    def test_caps_at_max_facts(self):
        cap = ar._MAX_ICP_DETAIL_FACTS
        big = {f"k{i}": f"v{i}" for i in range(cap + 10)}
        out = ar._icp_detail_flatten_facts(big)
        assert len(out) <= cap

    def test_value_clipped(self):
        long = "A" * (ar._MAX_ICP_DETAIL_FACT_VALUE_LEN + 100)
        out = ar._icp_detail_flatten_facts({"big": long})
        assert out[0][1].endswith("…")
        assert len(out[0][1]) == ar._MAX_ICP_DETAIL_FACT_VALUE_LEN


# -------------------------------------------------------------------- #
# _icp_detail_extract_signals                                         #
# -------------------------------------------------------------------- #

class TestExtractSignals:
    def test_none(self):
        assert ar._icp_detail_extract_signals(None) == []

    def test_non_dict(self):
        assert ar._icp_detail_extract_signals([]) == []

    def test_missing(self):
        assert ar._icp_detail_extract_signals({}) == []

    def test_non_list(self):
        assert ar._icp_detail_extract_signals({"buying_signals": "string"}) == []

    def test_basic(self):
        out = ar._icp_detail_extract_signals({"buying_signals": ["a", "b"]})
        assert out == ["a", "b"]

    def test_non_string_skipped(self):
        out = ar._icp_detail_extract_signals(
            {"buying_signals": ["a", 123, None, {"x": 1}, "b"]}
        )
        assert out == ["a", "b"]

    def test_empty_string_skipped(self):
        out = ar._icp_detail_extract_signals(
            {"buying_signals": ["", "  ", "kept"]}
        )
        assert out == ["kept"]

    def test_stripped(self):
        out = ar._icp_detail_extract_signals(
            {"buying_signals": ["  hello  "]}
        )
        assert out == ["hello"]

    def test_clipped(self):
        long = "A" * 500
        out = ar._icp_detail_extract_signals({"buying_signals": [long]})
        assert out[0].endswith("…")
        assert len(out[0]) == ar._MAX_ICP_DETAIL_SIGNAL_LEN

    def test_caps(self):
        many = [f"s{i}" for i in range(ar._MAX_ICP_DETAIL_SIGNALS + 10)]
        out = ar._icp_detail_extract_signals({"buying_signals": many})
        assert len(out) == ar._MAX_ICP_DETAIL_SIGNALS


# -------------------------------------------------------------------- #
# _icp_detail_score_card                                              #
# -------------------------------------------------------------------- #

class TestScoreCard:
    def test_none_score(self):
        html = ar._icp_detail_score_card("Fit", None)
        assert "Fit" in html
        assert "—" in html
        # default uses card bg — should NOT use positive/accent colors
        assert ar._G8_POSITIVE_FG not in html
        assert ar._G8_PRIMARY not in html

    def test_positive(self):
        html = ar._icp_detail_score_card("Fit", 85.0)
        assert ar._G8_POSITIVE_BG in html
        assert ar._G8_POSITIVE_FG in html
        assert "85" in html

    def test_primary(self):
        html = ar._icp_detail_score_card("Fit", 70.0)
        assert ar._G8_ACCENT_BG in html
        assert ar._G8_PRIMARY in html

    def test_warning(self):
        html = ar._icp_detail_score_card("Fit", 45.0)
        assert ar._G8_WARNING_BG in html
        assert ar._G8_WARNING_FG in html

    def test_destructive(self):
        html = ar._icp_detail_score_card("Fit", 15.0)
        # uses muted bg (more aligned with graph8 palette)
        assert ar._G8_MUTED_BG in html

    def test_escapes_label(self):
        html = ar._icp_detail_score_card("<script>", 50.0)
        assert "&lt;script&gt;" in html
        assert "<script>" not in html or html.count("<script>") == 0


# -------------------------------------------------------------------- #
# _icp_detail_chip                                                    #
# -------------------------------------------------------------------- #

class TestChip:
    def test_basic(self):
        out = ar._icp_detail_chip("hello")
        assert "hello" in out
        assert "border" in out.lower()
        assert "padding" in out.lower()

    def test_escapes(self):
        out = ar._icp_detail_chip("<script>")
        assert "&lt;script&gt;" in out

    def test_uses_tokens(self):
        out = ar._icp_detail_chip("hello")
        assert ar._G8_MUTED_BG in out
        assert ar._G8_TEXT in out
        assert ar._G8_BORDER in out


# -------------------------------------------------------------------- #
# _icp_detail_facts_section                                           #
# -------------------------------------------------------------------- #

class TestFactsSection:
    def test_empty_returns_empty(self):
        assert ar._icp_detail_facts_section("Title", []) == ""

    def test_single_row(self):
        html = ar._icp_detail_facts_section("Firmographics", [("Industry", "SaaS")])
        assert "Firmographics" in html
        assert "Industry" in html
        assert "SaaS" in html

    def test_escapes_label_and_value(self):
        html = ar._icp_detail_facts_section(
            "<hdr>", [("<lab>", "<val>")]
        )
        assert "&lt;hdr&gt;" in html
        assert "&lt;lab&gt;" in html
        assert "&lt;val&gt;" in html


# -------------------------------------------------------------------- #
# _icp_detail_signals_section                                         #
# -------------------------------------------------------------------- #

class TestSignalsSection:
    def test_empty(self):
        assert ar._icp_detail_signals_section([]) == ""

    def test_basic(self):
        html = ar._icp_detail_signals_section(["Hiring growth", "Funding event"])
        assert "Buying Signals" in html
        assert "Hiring growth" in html
        assert "Funding event" in html

    def test_escapes(self):
        html = ar._icp_detail_signals_section(["<script>"])
        assert "&lt;script&gt;" in html
        assert "<script>" not in html or html.count("<script>") == 0


# -------------------------------------------------------------------- #
# _icp_detail_description_section                                     #
# -------------------------------------------------------------------- #

class TestDescriptionSection:
    def test_none(self):
        assert ar._icp_detail_description_section(None) == ""

    def test_non_string(self):
        assert ar._icp_detail_description_section(123) == ""
        assert ar._icp_detail_description_section([]) == ""

    def test_empty_string(self):
        assert ar._icp_detail_description_section("") == ""
        assert ar._icp_detail_description_section("   ") == ""

    def test_basic(self):
        html = ar._icp_detail_description_section("hello world")
        assert "hello world" in html
        assert "Description" in html

    def test_escapes(self):
        html = ar._icp_detail_description_section("<script>alert(1)</script>")
        assert "&lt;script&gt;" in html
        assert "<script>alert" not in html

    def test_newlines_to_br(self):
        html = ar._icp_detail_description_section("line1\nline2")
        assert "<br>" in html

    def test_clipped(self):
        long = "A" * (ar._MAX_ICP_DETAIL_DESCRIPTION_LEN + 100)
        html = ar._icp_detail_description_section(long)
        assert "…" in html


# -------------------------------------------------------------------- #
# _icp_detail_empty_state_html                                        #
# -------------------------------------------------------------------- #

class TestEmptyStateHtml:
    def test_unavailable_mode(self):
        html = ar._icp_detail_empty_state_html(mode="unavailable", icp_id="icp-1")
        assert "not available" in html.lower()
        assert "icp-1" in html
        assert "GET /icps" in html

    def test_not_found_mode(self):
        html = ar._icp_detail_empty_state_html(mode="not_found", icp_id="icp-1")
        assert "not found" in html.lower()
        assert "icp-1" in html
        assert "g8://icps/dashboard" in html

    def test_escapes_id(self):
        html = ar._icp_detail_empty_state_html(mode="unavailable", icp_id="<id>")
        assert "&lt;id&gt;" in html
        assert "<id>" not in html

    def test_uses_graph8_tokens(self):
        html = ar._icp_detail_empty_state_html(mode="not_found", icp_id="icp-1")
        assert ar._G8_FONT in html
        assert ar._G8_BORDER in html or ar._G8_ACCENT_BORDER in html


# -------------------------------------------------------------------- #
# render_icp_detail_html — smoke & invariants                         #
# -------------------------------------------------------------------- #

class TestRenderHtml:
    def test_none_renders_unavailable(self):
        html = ar.render_icp_detail_html(icp_id="x", icp=None)
        assert "not available" in html.lower() or "unable" in html.lower()

    def test_non_dict_renders_unavailable(self):
        html = ar.render_icp_detail_html(icp_id="x", icp="not a dict")  # type: ignore[arg-type]
        assert "not available" in html.lower() or "unable" in html.lower()

    def test_id_mismatch_renders_not_found(self):
        html = ar.render_icp_detail_html(
            icp_id="icp-1", icp={"id": "icp-999", "name": "Wrong"}
        )
        assert "not found" in html.lower()

    def test_no_id_in_payload_is_ok(self):
        # Missing id → we still render the ICP (no mismatch)
        html = ar.render_icp_detail_html(
            icp_id="icp-1", icp={"name": "No ID"}
        )
        assert "No ID" in html

    def test_basic_smoke(self):
        html = ar.render_icp_detail_html(icp_id=_ICP_ID, icp=_SAMPLE_ICP)
        # doctype + container + all sections
        assert html.startswith("<!DOCTYPE html>")
        assert "Mid-market SaaS" in html
        assert "Ideal Customer Profile" in html
        # Scores present
        assert "Fit" in html
        assert "Opportunity" in html
        assert "Readiness" in html
        assert "Total" in html
        # Description
        assert "B2B SaaS platforms" in html
        # Firmographics
        assert "Firmographics" in html
        assert "Industry" in html
        assert "SaaS" in html
        # Tech stack
        assert "Tech Stack" in html
        assert "Crm" in html or "CRM" in html or "Salesforce" in html
        # Buying signals
        assert "Buying Signals" in html
        assert "Hiring RevOps" in html or "Hiring" in html

    def test_renders_priority_and_status_chips(self):
        html = ar.render_icp_detail_html(icp_id=_ICP_ID, icp=_SAMPLE_ICP)
        assert "Priority 1" in html
        assert "ACTIVE" in html

    def test_renders_pinned_star(self):
        html = ar.render_icp_detail_html(icp_id=_ICP_ID, icp=_SAMPLE_ICP)
        assert "★" in html

    def test_no_star_when_not_pinned(self):
        icp = dict(_SAMPLE_ICP)
        icp["pinned"] = False
        html = ar.render_icp_detail_html(icp_id=_ICP_ID, icp=icp)
        assert "★" not in html

    def test_drill_up_list(self):
        html = ar.render_icp_detail_html(icp_id=_ICP_ID, icp=_SAMPLE_ICP)
        assert "Related surfaces" in html
        assert "g8://icps/dashboard" in html
        assert "g8://personas/dashboard" in html
        assert "g8://global-context/library" in html
        assert "g8://contacts/dashboard" in html
        assert "g8://companies/dashboard" in html
        assert "g8_search_companies" in html

    def test_drill_up_does_NOT_list_self(self):
        """Regression: drill-up card must never self-reference surface URI."""
        html = ar.render_icp_detail_html(icp_id=_ICP_ID, icp=_SAMPLE_ICP)
        # The specific icp-mid-saas URI should never appear as a drill-up link
        assert f"g8://icps/{_ICP_ID}" not in html
        # Literal template `g8://icps/{icp_id}` should also not appear in the
        # drill-up (we want it pointing elsewhere, not circular).
        assert "g8://icps/{icp_id}" not in html

    def test_no_javascript(self):
        """Regression: no script tags / javascript: / event handlers."""
        html = ar.render_icp_detail_html(icp_id=_ICP_ID, icp=_SAMPLE_ICP)
        assert "<script" not in html.lower()
        assert "javascript:" not in html.lower()
        # no inline event handlers
        for handler in ("onclick=", "onerror=", "onload=", "onmouseover="):
            assert handler not in html.lower()

    def test_no_single_side_colored_accent_border(self):
        """Regression: avoid single-side colored accent borders per style guide."""
        html = ar.render_icp_detail_html(icp_id=_ICP_ID, icp=_SAMPLE_ICP)
        # We only use uniform 1px borders with _G8_BORDER / _G8_ACCENT_BORDER
        # (all 4 sides). Catch common anti-patterns.
        for bad in (
            "border-left:4px",
            "border-left:3px solid #7d2df3",
            "border-top:4px solid #7d2df3",
            "border-bottom:4px solid #7d2df3",
        ):
            assert bad not in html

    def test_no_legacy_accent_hexes(self):
        """Regression: renderer must use graph8 tokens, not legacy hexes."""
        html = ar.render_icp_detail_html(icp_id=_ICP_ID, icp=_SAMPLE_ICP)
        # Legacy/ad-hoc colors from earlier ICP dashboard implementation.
        legacy = [
            "#166534",  # old green
            "#4d7c0f",  # old lime
            "#b45309",  # old amber
            "#b91c1c",  # old red
            "#9ca3af",  # old gray
            "#eef2ff",  # old indigo tint
            "#4338ca",  # old indigo
        ]
        for h in legacy:
            assert h not in html, (
                f"legacy hex {h} should not appear; use graph8 tokens"
            )

    def test_uses_graph8_tokens(self):
        html = ar.render_icp_detail_html(icp_id=_ICP_ID, icp=_SAMPLE_ICP)
        # Must use graph8 primary, border, font
        assert ar._G8_PRIMARY in html
        assert ar._G8_BORDER in html
        assert "Aeonik" in html

    def test_xss_name(self):
        html = ar.render_icp_detail_html(
            icp_id="icp-1",
            icp={"id": "icp-1", "name": "<script>alert('XSS')</script>"},
        )
        assert "<script>alert" not in html
        assert "&lt;script&gt;" in html

    def test_xss_description(self):
        html = ar.render_icp_detail_html(
            icp_id="icp-1",
            icp={
                "id": "icp-1",
                "name": "Test",
                "description": "<img src=x onerror=alert(1)>",
            },
        )
        assert "<img src=x onerror" not in html
        assert "&lt;img" in html

    def test_xss_buying_signals(self):
        html = ar.render_icp_detail_html(
            icp_id="icp-1",
            icp={
                "id": "icp-1",
                "name": "Test",
                "buying_signals": ["<script>alert(1)</script>"],
            },
        )
        assert "<script>alert" not in html

    def test_xss_firmographics_key(self):
        html = ar.render_icp_detail_html(
            icp_id="icp-1",
            icp={
                "id": "icp-1",
                "name": "Test",
                "firmographics": {"<evil>": "value"},
            },
        )
        # .title() capitalizes: <evil> → <Evil> → html-escaped
        assert "&lt;Evil&gt;" in html
        assert "<evil>" not in html

    def test_xss_firmographics_value(self):
        html = ar.render_icp_detail_html(
            icp_id="icp-1",
            icp={
                "id": "icp-1",
                "name": "Test",
                "firmographics": {"industry": "<script>alert(1)</script>"},
            },
        )
        assert "<script>alert" not in html

    def test_empty_icp_minimal(self):
        """ICP with just a name still renders without error."""
        html = ar.render_icp_detail_html(
            icp_id="icp-1", icp={"id": "icp-1", "name": "Minimal"}
        )
        assert "Minimal" in html
        assert "—" in html  # score dashes

    def test_all_scores_missing(self):
        html = ar.render_icp_detail_html(
            icp_id="icp-1", icp={"id": "icp-1", "name": "No Scores"}
        )
        # All four score cards show — dash
        assert html.count(">—<") >= 4

    def test_missing_description(self):
        icp = dict(_SAMPLE_ICP)
        icp.pop("description", None)
        html = ar.render_icp_detail_html(icp_id=_ICP_ID, icp=icp)
        assert "Description" not in html or "B2B SaaS" not in html

    def test_missing_firmographics(self):
        icp = dict(_SAMPLE_ICP)
        icp.pop("firmographics", None)
        html = ar.render_icp_detail_html(icp_id=_ICP_ID, icp=icp)
        # Section omitted if empty
        assert "Firmographics" not in html

    def test_missing_tech_stack(self):
        icp = dict(_SAMPLE_ICP)
        icp.pop("tech_stack", None)
        html = ar.render_icp_detail_html(icp_id=_ICP_ID, icp=icp)
        assert "Tech Stack" not in html

    def test_missing_buying_signals(self):
        icp = dict(_SAMPLE_ICP)
        icp.pop("buying_signals", None)
        html = ar.render_icp_detail_html(icp_id=_ICP_ID, icp=icp)
        assert "Buying Signals" not in html

    def test_title_includes_name(self):
        html = ar.render_icp_detail_html(icp_id=_ICP_ID, icp=_SAMPLE_ICP)
        assert "<title>ICP: Mid-market SaaS</title>" in html


# -------------------------------------------------------------------- #
# render_icp_detail_text_fallback                                     #
# -------------------------------------------------------------------- #

class TestTextFallback:
    def test_none(self):
        out = ar.render_icp_detail_text_fallback(icp_id="icp-1", icp=None)
        assert "ICP #icp-1" in out
        assert "not available" in out.lower()

    def test_non_dict(self):
        out = ar.render_icp_detail_text_fallback(icp_id="icp-1", icp="nope")  # type: ignore[arg-type]
        assert "not available" in out.lower()

    def test_id_mismatch(self):
        out = ar.render_icp_detail_text_fallback(
            icp_id="icp-1", icp={"id": "icp-999", "name": "Wrong"}
        )
        assert "not found" in out.lower()

    def test_basic(self):
        out = ar.render_icp_detail_text_fallback(icp_id=_ICP_ID, icp=_SAMPLE_ICP)
        assert "# Mid-market SaaS" in out
        assert "★" in out
        assert "Priority 1" in out
        assert "ACTIVE" in out
        assert "## Scores" in out
        assert "Fit:" in out
        assert "Opportunity:" in out
        assert "Readiness:" in out
        assert "Total:" in out
        assert "## Description" in out
        assert "B2B SaaS platforms" in out
        assert "## Firmographics" in out
        assert "## Tech Stack" in out
        assert "## Buying Signals" in out
        assert "Hiring RevOps" in out or "Hiring" in out
        # Drill-up markdown list
        assert "g8://icps/dashboard" in out
        assert "g8://personas/dashboard" in out
        assert "g8://global-context/library" in out
        assert "g8_search_companies" in out

    def test_minimal_icp(self):
        out = ar.render_icp_detail_text_fallback(
            icp_id="icp-1", icp={"id": "icp-1", "name": "Minimal"}
        )
        assert "# Minimal" in out
        assert "## Scores" in out
        assert "Fit: —" in out

    def test_no_name(self):
        out = ar.render_icp_detail_text_fallback(
            icp_id="icp-1", icp={"id": "icp-1"}
        )
        assert "# ICP #icp-1" in out

    def test_no_pinned_no_star(self):
        icp = dict(_SAMPLE_ICP)
        icp["pinned"] = False
        out = ar.render_icp_detail_text_fallback(icp_id=_ICP_ID, icp=icp)
        # star absent from heading
        first_line = out.split("\n")[0]
        assert "★" not in first_line

    def test_sections_skipped_when_empty(self):
        icp = {"id": "icp-1", "name": "Test"}
        out = ar.render_icp_detail_text_fallback(icp_id="icp-1", icp=icp)
        assert "## Description" not in out
        assert "## Firmographics" not in out
        assert "## Tech Stack" not in out
        assert "## Buying Signals" not in out

    def test_ends_with_newline(self):
        out = ar.render_icp_detail_text_fallback(icp_id=_ICP_ID, icp=_SAMPLE_ICP)
        assert out.endswith("\n")

    def test_description_clipped(self):
        long_desc = "A" * (ar._MAX_ICP_DETAIL_DESCRIPTION_LEN + 100)
        icp = {"id": "icp-1", "name": "T", "description": long_desc}
        out = ar.render_icp_detail_text_fallback(icp_id="icp-1", icp=icp)
        assert "…" in out


# -------------------------------------------------------------------- #
# Smoke across payload shapes                                         #
# -------------------------------------------------------------------- #

class TestSmoke:
    def test_html_roundtrip_does_not_raise(self):
        ar.render_icp_detail_html(icp_id=_ICP_ID, icp=_SAMPLE_ICP)
        ar.render_icp_detail_html(icp_id="", icp=None)
        ar.render_icp_detail_html(icp_id="x", icp={})
        ar.render_icp_detail_html(
            icp_id="x", icp={"id": "x", "name": "", "buying_signals": []}
        )

    def test_text_roundtrip_does_not_raise(self):
        ar.render_icp_detail_text_fallback(icp_id=_ICP_ID, icp=_SAMPLE_ICP)
        ar.render_icp_detail_text_fallback(icp_id="", icp=None)
        ar.render_icp_detail_text_fallback(icp_id="x", icp={})

    def test_html_score_ordering(self):
        """Rendering order must be Fit, Opportunity, Readiness, Total."""
        html = ar.render_icp_detail_html(icp_id=_ICP_ID, icp=_SAMPLE_ICP)
        # Find the positions of each label's first occurrence
        fit_pos = html.find("Fit")
        opp_pos = html.find("Opportunity")
        read_pos = html.find("Readiness")
        total_pos = html.find("Total")
        assert 0 < fit_pos < opp_pos < read_pos < total_pos

    def test_html_well_formed(self):
        """HTML has matching doctype, html, body tags."""
        html = ar.render_icp_detail_html(icp_id=_ICP_ID, icp=_SAMPLE_ICP)
        assert html.count("<!DOCTYPE html>") == 1
        assert html.count("<html>") == 1
        assert html.count("</html>") == 1
        assert html.count("<body") == 1
        assert html.count("</body>") == 1
