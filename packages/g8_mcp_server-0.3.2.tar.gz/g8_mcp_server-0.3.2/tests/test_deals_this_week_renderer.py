"""Unit tests for Surface #88 — g8://deals/this-week.

THIRD temporal-scope surface in Upgrade 4 (after #86 activities/today
and #87 tasks/due-today). FIRST to use a WEEK scope (7-day window
Monday → next Monday) rather than a day scope.

**NEW backend-filter pattern** — DUAL-BOUND TEMPORAL RANGE
(``?close_after={monday_00_utc}&close_before={next_monday_00_utc}``).
Where #86 used a single past-bound (``?since=``) and #87 used a single
future-bound (``?due_before=``), #88 uses both bounds to express a
precise window. This is the NINTH distinct backend-filter pattern
shipped across Upgrade 4.

Sibling family under ``g8://deals/`` (SEVEN families):
    ``g8://deals/pipeline``             (static kanban)
    ``g8://deals/dashboard``            (#60, static financial)
    ``g8://deals/{deal_id}``            (#24, template)
    ``g8://deals/{deal_id}/activities`` (#70, nested)
    ``g8://deals/stage/{stage}``        (#82, axis)
    ``g8://deals/owner/{user_id}``      (#83, axis)
    ``g8://deals/this-week``            (#88 — THIS surface)

Locked invariants:
- NEW stats signature: Total in window / Pipeline $ / Won $ / Lost $
- Three bands: closing_this_week / closed_won_this_week /
  closed_lost_this_week
- First Upgrade 4 surface to use the DESTRUCTIVE design-token palette
  (for the `closed_lost` band).
- Sort orders: closing by amount DESC; won by closed_at DESC;
  lost by closed_at DESC.
- Cross-entity drill-up to pipeline/dashboard/stage/activities/copilot.
"""

from __future__ import annotations

import re

import pytest

from mcp_server.g8_mcp_server import app_renderer as ar


# ---------------------------------------------------------------------------
# Helpers / constants
# ---------------------------------------------------------------------------

# Week of 2026-04-20 (Monday) through 2026-04-27 (next Monday, exclusive).
WEEK_START = "2026-04-20"
WEEK_END = "2026-04-27"
IN_WEEK_DATE = "2026-04-22"  # Wednesday
IN_WEEK_ISO = "2026-04-22T10:00:00Z"
BEFORE_WEEK_DATE = "2026-04-19"  # Sunday before
AFTER_WEEK_DATE = "2026-04-28"  # Tuesday after


def _open_deal(
    close: str, *, amount: float = 1000, deal_id: str = "d1", name: str = "Deal"
) -> dict:
    return {
        "id": deal_id,
        "name": name,
        "stage": "negotiating",
        "close_date": close,
        "amount": amount,
    }


def _won_deal(
    closed_at: str, *, amount: float = 10000, deal_id: str = "w1", name: str = "Won"
) -> dict:
    return {
        "id": deal_id,
        "name": name,
        "stage": "closed_won",
        "closed_at": closed_at,
        "amount": amount,
    }


def _lost_deal(
    closed_at: str, *, amount: float = 5000, deal_id: str = "l1", name: str = "Lost"
) -> dict:
    return {
        "id": deal_id,
        "name": name,
        "stage": "closed_lost",
        "closed_at": closed_at,
        "amount": amount,
    }


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------


class TestConstants:
    def test_won_keywords_frozenset(self):
        assert isinstance(ar._DEALS_THIS_WEEK_WON_KEYWORDS, frozenset)

    def test_won_keywords_cover_common(self):
        for s in ("won", "closed_won", "closed-won", "closedwon"):
            assert s in ar._DEALS_THIS_WEEK_WON_KEYWORDS

    def test_lost_keywords_frozenset(self):
        assert isinstance(ar._DEALS_THIS_WEEK_LOST_KEYWORDS, frozenset)

    def test_lost_keywords_cover_common(self):
        for s in ("lost", "closed_lost", "closed-lost", "closedlost"):
            assert s in ar._DEALS_THIS_WEEK_LOST_KEYWORDS

    def test_open_statuses_frozenset(self):
        assert isinstance(ar._DEALS_THIS_WEEK_OPEN_STATUSES, frozenset)

    def test_renderer_functions_exported(self):
        assert callable(ar.render_deals_this_week_html)
        assert callable(ar.render_deals_this_week_text_fallback)


# ---------------------------------------------------------------------------
# UTC bounds
# ---------------------------------------------------------------------------


class TestWeekStartUtc:
    def test_returns_iso_zulu(self):
        out = ar._deals_this_week_week_start_utc()
        assert isinstance(out, str)
        assert re.match(r"^\d{4}-\d{2}-\d{2}T00:00:00Z$", out), out

    def test_is_00_00_00(self):
        out = ar._deals_this_week_week_start_utc()
        assert out.endswith("T00:00:00Z")

    def test_is_monday(self):
        """Week start should be a Monday."""
        from datetime import date
        out = ar._deals_this_week_week_start_utc()[:10]
        y, m, d = out.split("-")
        assert date(int(y), int(m), int(d)).weekday() == 0  # Monday


class TestWeekEndUtc:
    def test_returns_iso_zulu(self):
        out = ar._deals_this_week_week_end_utc()
        assert isinstance(out, str)
        assert re.match(r"^\d{4}-\d{2}-\d{2}T00:00:00Z$", out), out

    def test_is_monday(self):
        from datetime import date
        out = ar._deals_this_week_week_end_utc()[:10]
        y, m, d = out.split("-")
        assert date(int(y), int(m), int(d)).weekday() == 0  # Monday

    def test_end_after_start(self):
        start = ar._deals_this_week_week_start_utc()[:10]
        end = ar._deals_this_week_week_end_utc()[:10]
        assert end > start

    def test_end_is_7_days_after_start(self):
        from datetime import date, timedelta
        s_str = ar._deals_this_week_week_start_utc()[:10]
        e_str = ar._deals_this_week_week_end_utc()[:10]
        sy, sm, sd = s_str.split("-")
        ey, em, ed = e_str.split("-")
        s = date(int(sy), int(sm), int(sd))
        e = date(int(ey), int(em), int(ed))
        assert e - s == timedelta(days=7)


# ---------------------------------------------------------------------------
# Date extraction
# ---------------------------------------------------------------------------


class TestDateOnly:
    def test_parses_iso(self):
        assert ar._deals_this_week_date_only("2026-04-22T10:00:00Z") == "2026-04-22"

    def test_parses_date_only(self):
        assert ar._deals_this_week_date_only("2026-04-22") == "2026-04-22"

    def test_none(self):
        assert ar._deals_this_week_date_only(None) is None

    def test_empty(self):
        assert ar._deals_this_week_date_only("") is None

    def test_short(self):
        assert ar._deals_this_week_date_only("2026-04") is None

    def test_bad_delimiter(self):
        assert ar._deals_this_week_date_only("2026/04/22") is None


class TestInWeek:
    def test_date_in_week(self):
        assert ar._deals_this_week_in_week(
            IN_WEEK_DATE, week_start_date=WEEK_START, week_end_date=WEEK_END
        ) is True

    def test_week_start_inclusive(self):
        assert ar._deals_this_week_in_week(
            WEEK_START, week_start_date=WEEK_START, week_end_date=WEEK_END
        ) is True

    def test_week_end_exclusive(self):
        assert ar._deals_this_week_in_week(
            WEEK_END, week_start_date=WEEK_START, week_end_date=WEEK_END
        ) is False

    def test_before_week_rejected(self):
        assert ar._deals_this_week_in_week(
            BEFORE_WEEK_DATE, week_start_date=WEEK_START, week_end_date=WEEK_END
        ) is False

    def test_after_week_rejected(self):
        assert ar._deals_this_week_in_week(
            AFTER_WEEK_DATE, week_start_date=WEEK_START, week_end_date=WEEK_END
        ) is False

    def test_none_rejected(self):
        assert ar._deals_this_week_in_week(
            None, week_start_date=WEEK_START, week_end_date=WEEK_END
        ) is False

    def test_iso_parsed(self):
        assert ar._deals_this_week_in_week(
            IN_WEEK_ISO, week_start_date=WEEK_START, week_end_date=WEEK_END
        ) is True


# ---------------------------------------------------------------------------
# Close-date / closed-at extraction
# ---------------------------------------------------------------------------


class TestGetCloseDate:
    def test_prefers_close_date(self):
        d = {"close_date": "2026-04-22", "expected_close_date": "2026-04-23"}
        assert ar._deals_this_week_get_close_date(d) == "2026-04-22"

    def test_expected_close_date_fallback(self):
        assert ar._deals_this_week_get_close_date(
            {"expected_close_date": "2026-04-22"}
        ) == "2026-04-22"

    def test_close_at_fallback(self):
        assert ar._deals_this_week_get_close_date(
            {"close_at": "2026-04-22T10:00:00Z"}
        ) == "2026-04-22"

    def test_expected_close_fallback(self):
        assert ar._deals_this_week_get_close_date(
            {"expected_close": "2026-04-22"}
        ) == "2026-04-22"

    def test_none_missing(self):
        assert ar._deals_this_week_get_close_date({}) is None

    def test_non_dict(self):
        assert ar._deals_this_week_get_close_date("x") is None  # type: ignore[arg-type]


class TestGetClosedAt:
    def test_prefers_closed_at(self):
        d = {"closed_at": "2026-04-22", "closed_date": "2026-04-23"}
        assert ar._deals_this_week_get_closed_at(d) == "2026-04-22"

    def test_closed_date_fallback(self):
        assert ar._deals_this_week_get_closed_at(
            {"closed_date": "2026-04-22"}
        ) == "2026-04-22"

    def test_won_at_fallback(self):
        assert ar._deals_this_week_get_closed_at(
            {"won_at": "2026-04-22"}
        ) == "2026-04-22"

    def test_lost_at_fallback(self):
        assert ar._deals_this_week_get_closed_at(
            {"lost_at": "2026-04-22"}
        ) == "2026-04-22"

    def test_updated_at_fallback(self):
        assert ar._deals_this_week_get_closed_at(
            {"updated_at": "2026-04-22T10:00:00Z"}
        ) == "2026-04-22"

    def test_none_missing(self):
        assert ar._deals_this_week_get_closed_at({}) is None


# ---------------------------------------------------------------------------
# Stage classification
# ---------------------------------------------------------------------------


class TestStageNormalized:
    def test_stage_field(self):
        assert ar._deals_this_week_stage_normalized({"stage": "CLOSED_WON"}) == "closed_won"

    def test_status_field_fallback(self):
        assert ar._deals_this_week_stage_normalized({"status": "Negotiating"}) == "negotiating"

    def test_prefers_stage_over_status(self):
        assert ar._deals_this_week_stage_normalized(
            {"stage": "won", "status": "active"}
        ) == "won"

    def test_non_dict(self):
        assert ar._deals_this_week_stage_normalized("x") == ""  # type: ignore[arg-type]

    def test_whitespace_stripped(self):
        assert ar._deals_this_week_stage_normalized({"stage": "  Won  "}) == "won"


class TestIsWon:
    @pytest.mark.parametrize(
        "stage", ["won", "closed_won", "closed-won", "CLOSED_WON", "Won"]
    )
    def test_recognises_won(self, stage):
        assert ar._deals_this_week_is_won({"stage": stage}) is True

    def test_keyword_match(self):
        assert ar._deals_this_week_is_won({"stage": "won - upsell"}) is True

    def test_not_won(self):
        assert ar._deals_this_week_is_won({"stage": "negotiating"}) is False

    def test_not_lost(self):
        assert ar._deals_this_week_is_won({"stage": "closed_lost"}) is False

    def test_empty(self):
        assert ar._deals_this_week_is_won({}) is False


class TestIsLost:
    @pytest.mark.parametrize(
        "stage", ["lost", "closed_lost", "closed-lost", "CLOSED_LOST", "Lost"]
    )
    def test_recognises_lost(self, stage):
        assert ar._deals_this_week_is_lost({"stage": stage}) is True

    def test_keyword_match(self):
        assert ar._deals_this_week_is_lost({"stage": "lost to competitor"}) is True

    def test_not_lost(self):
        assert ar._deals_this_week_is_lost({"stage": "negotiating"}) is False

    def test_not_won(self):
        assert ar._deals_this_week_is_lost({"stage": "closed_won"}) is False


# ---------------------------------------------------------------------------
# Bucket
# ---------------------------------------------------------------------------


class TestBucket:
    def test_closing_this_week(self):
        d = _open_deal(IN_WEEK_DATE)
        assert ar._deals_this_week_bucket(
            d, week_start_date=WEEK_START, week_end_date=WEEK_END
        ) == "closing_this_week"

    def test_closing_next_week_is_other(self):
        d = _open_deal(AFTER_WEEK_DATE)
        assert ar._deals_this_week_bucket(
            d, week_start_date=WEEK_START, week_end_date=WEEK_END
        ) == "other"

    def test_closing_last_week_is_other(self):
        d = _open_deal(BEFORE_WEEK_DATE)
        assert ar._deals_this_week_bucket(
            d, week_start_date=WEEK_START, week_end_date=WEEK_END
        ) == "other"

    def test_won_this_week(self):
        d = _won_deal(IN_WEEK_DATE)
        assert ar._deals_this_week_bucket(
            d, week_start_date=WEEK_START, week_end_date=WEEK_END
        ) == "closed_won_this_week"

    def test_lost_this_week(self):
        d = _lost_deal(IN_WEEK_DATE)
        assert ar._deals_this_week_bucket(
            d, week_start_date=WEEK_START, week_end_date=WEEK_END
        ) == "closed_lost_this_week"

    def test_won_last_week_is_other(self):
        d = _won_deal(BEFORE_WEEK_DATE)
        assert ar._deals_this_week_bucket(
            d, week_start_date=WEEK_START, week_end_date=WEEK_END
        ) == "other"

    def test_won_without_closed_at_is_other(self):
        d = {"stage": "closed_won", "amount": 100}
        assert ar._deals_this_week_bucket(
            d, week_start_date=WEEK_START, week_end_date=WEEK_END
        ) == "other"

    def test_open_without_close_date_is_other(self):
        d = {"stage": "open", "amount": 100}
        assert ar._deals_this_week_bucket(
            d, week_start_date=WEEK_START, week_end_date=WEEK_END
        ) == "other"

    def test_non_dict(self):
        assert ar._deals_this_week_bucket(
            "x", week_start_date=WEEK_START, week_end_date=WEEK_END  # type: ignore[arg-type]
        ) == "other"


# ---------------------------------------------------------------------------
# Partition
# ---------------------------------------------------------------------------


class TestPartition:
    def test_returns_three_keys(self):
        out = ar._deals_this_week_partition(
            [], week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert set(out.keys()) == {
            "closing_this_week",
            "closed_won_this_week",
            "closed_lost_this_week",
        }

    def test_buckets_correctly(self):
        deals = [
            _open_deal(IN_WEEK_DATE, deal_id="c1"),
            _won_deal(IN_WEEK_DATE, deal_id="w1"),
            _lost_deal(IN_WEEK_DATE, deal_id="l1"),
            _open_deal(AFTER_WEEK_DATE, deal_id="x"),  # dropped
        ]
        out = ar._deals_this_week_partition(
            deals, week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert len(out["closing_this_week"]) == 1
        assert out["closing_this_week"][0]["id"] == "c1"
        assert len(out["closed_won_this_week"]) == 1
        assert len(out["closed_lost_this_week"]) == 1

    def test_non_list(self):
        out = ar._deals_this_week_partition(
            None, week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert out == {
            "closing_this_week": [],
            "closed_won_this_week": [],
            "closed_lost_this_week": [],
        }

    def test_skips_non_dicts(self):
        out = ar._deals_this_week_partition(
            [None, "x", _open_deal(IN_WEEK_DATE)],  # type: ignore[list-item]
            week_start_date=WEEK_START,
            week_end_date=WEEK_END,
        )
        assert len(out["closing_this_week"]) == 1


# ---------------------------------------------------------------------------
# Amount
# ---------------------------------------------------------------------------


class TestAmount:
    def test_amount_field(self):
        assert ar._deals_this_week_amount({"amount": 1500}) == 1500.0

    def test_value_fallback(self):
        assert ar._deals_this_week_amount({"value": 2500}) == 2500.0

    def test_arr_fallback(self):
        assert ar._deals_this_week_amount({"arr": 10000}) == 10000.0

    def test_total_value_fallback(self):
        assert ar._deals_this_week_amount({"total_value": 500}) == 500.0

    def test_string_numeric(self):
        assert ar._deals_this_week_amount({"amount": "1500"}) == 1500.0

    def test_missing(self):
        assert ar._deals_this_week_amount({}) == 0.0

    def test_non_numeric(self):
        assert ar._deals_this_week_amount({"amount": "x"}) == 0.0

    def test_none_value(self):
        assert ar._deals_this_week_amount({"amount": None}) == 0.0

    def test_non_dict(self):
        assert ar._deals_this_week_amount("x") == 0.0  # type: ignore[arg-type]

    def test_prefers_amount_over_value(self):
        d = {"amount": 1, "value": 2}
        assert ar._deals_this_week_amount(d) == 1.0


class TestSumAmount:
    def test_sum(self):
        deals = [{"amount": 100}, {"amount": 200}, {"amount": 300}]
        assert ar._deals_this_week_sum_amount(deals) == 600.0

    def test_empty(self):
        assert ar._deals_this_week_sum_amount([]) == 0.0

    def test_skips_non_dicts(self):
        assert ar._deals_this_week_sum_amount([None, {"amount": 100}, "x"]) == 100.0  # type: ignore[list-item]

    def test_non_list(self):
        assert ar._deals_this_week_sum_amount(None) == 0.0  # type: ignore[arg-type]


class TestFormatCurrency:
    def test_small(self):
        assert ar._deals_this_week_format_currency(50) == "$50"

    def test_zero(self):
        assert ar._deals_this_week_format_currency(0) == "$0"

    def test_thousand(self):
        assert ar._deals_this_week_format_currency(1500) == "$1.5K"

    def test_ten_k(self):
        assert ar._deals_this_week_format_currency(10000) == "$10.0K"

    def test_million(self):
        assert ar._deals_this_week_format_currency(2_500_000) == "$2.5M"

    def test_negative(self):
        assert ar._deals_this_week_format_currency(-1500) == "-$1.5K"

    def test_non_numeric(self):
        assert ar._deals_this_week_format_currency("abc") == "$0"  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Sort band
# ---------------------------------------------------------------------------


class TestSortBand:
    def test_closing_by_amount_desc(self):
        deals = [
            _open_deal(IN_WEEK_DATE, deal_id="a", amount=100),
            _open_deal(IN_WEEK_DATE, deal_id="b", amount=5000),
            _open_deal(IN_WEEK_DATE, deal_id="c", amount=2500),
        ]
        out = ar._deals_this_week_sort_band(deals, "closing_this_week")
        ids = [d["id"] for d in out]
        assert ids == ["b", "c", "a"]

    def test_won_by_closed_at_desc(self):
        deals = [
            _won_deal(IN_WEEK_DATE, deal_id="early"),
            _won_deal("2026-04-23", deal_id="late"),
        ]
        out = ar._deals_this_week_sort_band(deals, "closed_won_this_week")
        ids = [d["id"] for d in out]
        assert ids == ["late", "early"]

    def test_lost_by_closed_at_desc(self):
        deals = [
            _lost_deal(IN_WEEK_DATE, deal_id="early"),
            _lost_deal("2026-04-23", deal_id="late"),
        ]
        out = ar._deals_this_week_sort_band(deals, "closed_lost_this_week")
        ids = [d["id"] for d in out]
        assert ids == ["late", "early"]

    def test_unknown_band_passthrough(self):
        deals = [{"id": "x"}, {"id": "y"}]
        assert ar._deals_this_week_sort_band(deals, "whatever") == deals


# ---------------------------------------------------------------------------
# Display name
# ---------------------------------------------------------------------------


class TestDisplayName:
    def test_name(self):
        assert ar._deals_this_week_display_name({"name": "Acme"}) == "Acme"

    def test_title_fallback(self):
        assert ar._deals_this_week_display_name({"title": "Big"}) == "Big"

    def test_deal_name_fallback(self):
        assert ar._deals_this_week_display_name({"deal_name": "Combo"}) == "Combo"

    def test_subject_fallback(self):
        assert ar._deals_this_week_display_name({"subject": "Subj"}) == "Subj"

    def test_id_fallback(self):
        assert ar._deals_this_week_display_name({"id": 42}) == "Deal #42"

    def test_untitled(self):
        assert ar._deals_this_week_display_name({}) == "(untitled)"

    def test_non_dict(self):
        assert ar._deals_this_week_display_name("x") == "(untitled)"  # type: ignore[arg-type]

    def test_truncated_200(self):
        assert len(ar._deals_this_week_display_name({"name": "x" * 500})) == 200


# ---------------------------------------------------------------------------
# Stats row
# ---------------------------------------------------------------------------


class TestStatsRow:
    def test_has_total_pipeline_won_lost(self):
        """LOCK: the 4-card stats signature for deals/this-week."""
        partitioned = {
            "closing_this_week": [_open_deal(IN_WEEK_DATE, amount=1000)],
            "closed_won_this_week": [_won_deal(IN_WEEK_DATE, amount=10000)],
            "closed_lost_this_week": [_lost_deal(IN_WEEK_DATE, amount=5000)],
        }
        out = ar._deals_this_week_stats_row_html(partitioned)
        assert "Total in window" in out
        assert "Pipeline $" in out
        assert "Won $" in out
        assert "Lost $" in out

    def test_total_is_count_sum(self):
        partitioned = {
            "closing_this_week": [_open_deal(IN_WEEK_DATE)] * 2,
            "closed_won_this_week": [_won_deal(IN_WEEK_DATE)] * 3,
            "closed_lost_this_week": [_lost_deal(IN_WEEK_DATE)],
        }
        out = ar._deals_this_week_stats_row_html(partitioned)
        assert ">6<" in out

    def test_pipeline_dollars_formatted(self):
        partitioned = {
            "closing_this_week": [_open_deal(IN_WEEK_DATE, amount=25_000)],
            "closed_won_this_week": [],
            "closed_lost_this_week": [],
        }
        out = ar._deals_this_week_stats_row_html(partitioned)
        assert "$25.0K" in out

    def test_won_dollars_formatted(self):
        partitioned = {
            "closing_this_week": [],
            "closed_won_this_week": [_won_deal(IN_WEEK_DATE, amount=1_500_000)],
            "closed_lost_this_week": [],
        }
        out = ar._deals_this_week_stats_row_html(partitioned)
        assert "$1.5M" in out

    def test_empty_zero_dollar(self):
        out = ar._deals_this_week_stats_row_html(
            {
                "closing_this_week": [],
                "closed_won_this_week": [],
                "closed_lost_this_week": [],
            }
        )
        assert "$0" in out
        assert ">0<" in out

    def test_has_4_cards(self):
        out = ar._deals_this_week_stats_row_html(
            {
                "closing_this_week": [],
                "closed_won_this_week": [],
                "closed_lost_this_week": [],
            }
        )
        assert out.count("flex:1;min-width:140px") == 4

    def test_won_color_positive_when_nonzero(self):
        out = ar._deals_this_week_stats_row_html(
            {
                "closing_this_week": [],
                "closed_won_this_week": [_won_deal(IN_WEEK_DATE)],
                "closed_lost_this_week": [],
            }
        )
        assert ar._G8_POSITIVE_FG in out

    def test_lost_color_destructive_when_nonzero(self):
        out = ar._deals_this_week_stats_row_html(
            {
                "closing_this_week": [],
                "closed_won_this_week": [],
                "closed_lost_this_week": [_lost_deal(IN_WEEK_DATE)],
            }
        )
        assert ar._G8_DESTRUCTIVE_BG in out


# ---------------------------------------------------------------------------
# Header
# ---------------------------------------------------------------------------


class TestHeader:
    def test_singular(self):
        assert "1 deal" in ar._deals_this_week_header_html(1, WEEK_START)

    def test_plural(self):
        assert "5 deals" in ar._deals_this_week_header_html(5, WEEK_START)

    def test_zero_plural(self):
        assert "0 deals" in ar._deals_this_week_header_html(0, WEEK_START)

    def test_temporal_scope_chip(self):
        assert "TEMPORAL SCOPE" in ar._deals_this_week_header_html(1, WEEK_START)

    def test_title(self):
        assert "Deals this week" in ar._deals_this_week_header_html(0, WEEK_START)

    def test_week_date_in_header(self):
        assert WEEK_START in ar._deals_this_week_header_html(0, WEEK_START)


# ---------------------------------------------------------------------------
# Row
# ---------------------------------------------------------------------------


class TestRow:
    def test_closing_row_shows_amount(self):
        row = ar._deals_this_week_row_html(
            _open_deal(IN_WEEK_DATE, amount=25_000), "closing_this_week"
        )
        assert "$25.0K" in row

    def test_closing_row_accent_palette(self):
        row = ar._deals_this_week_row_html(
            _open_deal(IN_WEEK_DATE), "closing_this_week"
        )
        assert ar._G8_ACCENT_BG in row
        assert "closing" in row

    def test_won_row_positive_palette(self):
        row = ar._deals_this_week_row_html(
            _won_deal(IN_WEEK_DATE), "closed_won_this_week"
        )
        assert ar._G8_POSITIVE_BG in row
        assert "won" in row

    def test_lost_row_destructive_palette(self):
        row = ar._deals_this_week_row_html(
            _lost_deal(IN_WEEK_DATE), "closed_lost_this_week"
        )
        assert ar._G8_DESTRUCTIVE_BG in row
        assert "lost" in row

    def test_lost_row_has_opacity_dim(self):
        row = ar._deals_this_week_row_html(
            _lost_deal(IN_WEEK_DATE), "closed_lost_this_week"
        )
        assert "opacity:0.75" in row

    def test_renders_name(self):
        row = ar._deals_this_week_row_html(
            _open_deal(IN_WEEK_DATE, name="ACME Corp"), "closing_this_week"
        )
        assert "ACME Corp" in row

    def test_xss_escaped(self):
        row = ar._deals_this_week_row_html(
            _open_deal(IN_WEEK_DATE, name="<script>alert(1)</script>"),
            "closing_this_week",
        )
        assert "<script>" not in row
        assert "&lt;script&gt;" in row

    def test_non_dict_returns_empty(self):
        assert ar._deals_this_week_row_html("x", "closing_this_week") == ""  # type: ignore[arg-type]

    def test_closing_row_shows_date(self):
        row = ar._deals_this_week_row_html(
            _open_deal(IN_WEEK_DATE), "closing_this_week"
        )
        assert IN_WEEK_DATE in row


# ---------------------------------------------------------------------------
# Band section
# ---------------------------------------------------------------------------


class TestBandSection:
    def test_renders_items(self):
        deals = [
            _open_deal(IN_WEEK_DATE, deal_id="a", name="A"),
            _open_deal(IN_WEEK_DATE, deal_id="b", name="B"),
        ]
        out = ar._deals_this_week_band_section_html("closing_this_week", deals)
        assert "A" in out
        assert "B" in out

    def test_closing_header(self):
        out = ar._deals_this_week_band_section_html(
            "closing_this_week", [_open_deal(IN_WEEK_DATE)]
        )
        assert "Closing this week" in out

    def test_won_header(self):
        out = ar._deals_this_week_band_section_html(
            "closed_won_this_week", [_won_deal(IN_WEEK_DATE)]
        )
        assert "Won this week" in out

    def test_lost_header(self):
        out = ar._deals_this_week_band_section_html(
            "closed_lost_this_week", [_lost_deal(IN_WEEK_DATE)]
        )
        assert "Lost this week" in out

    def test_empty_returns_empty_string(self):
        assert ar._deals_this_week_band_section_html("closing_this_week", []) == ""

    def test_cap_40(self):
        deals = [_open_deal(IN_WEEK_DATE, deal_id=f"d{i}") for i in range(45)]
        out = ar._deals_this_week_band_section_html(
            "closing_this_week", deals, cap=40
        )
        assert "5 more omitted" in out

    def test_count_badge(self):
        deals = [_open_deal(IN_WEEK_DATE) for _ in range(7)]
        out = ar._deals_this_week_band_section_html("closing_this_week", deals)
        assert "(7)" in out


# ---------------------------------------------------------------------------
# Drill-up
# ---------------------------------------------------------------------------


class TestDrillUp:
    def test_has_five_pointers(self):
        out = ar._deals_this_week_drill_up_html()
        assert "g8://deals/pipeline" in out
        assert "g8://deals/dashboard" in out
        assert "g8://deals/stage/closed_won" in out
        assert "g8://activities/today" in out
        assert "g8://copilot/home" in out

    def test_related_surfaces_heading(self):
        out = ar._deals_this_week_drill_up_html()
        assert "Related surfaces" in out


# ---------------------------------------------------------------------------
# Empty state
# ---------------------------------------------------------------------------


class TestEmptyState:
    def test_nothing_copy(self):
        assert "Nothing this week" in ar._deals_this_week_empty_state_html()

    def test_utc(self):
        assert "UTC" in ar._deals_this_week_empty_state_html()

    def test_points_to_pipeline(self):
        assert "g8://deals/pipeline" in ar._deals_this_week_empty_state_html()


# ---------------------------------------------------------------------------
# render_deals_this_week_html
# ---------------------------------------------------------------------------


class TestRenderHtml:
    def test_renders_deals(self):
        deals = [
            _open_deal(IN_WEEK_DATE, deal_id="c1", name="closing1"),
            _won_deal(IN_WEEK_DATE, deal_id="w1", name="won1"),
            _lost_deal(IN_WEEK_DATE, deal_id="l1", name="lost1"),
        ]
        out = ar.render_deals_this_week_html(
            deals=deals, week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert "closing1" in out
        assert "won1" in out
        assert "lost1" in out

    def test_sorts_closing_by_amount_desc(self):
        """LOCK: closing_this_week band sorted by amount desc."""
        deals = [
            _open_deal(IN_WEEK_DATE, deal_id="small", amount=100, name="smallone"),
            _open_deal(IN_WEEK_DATE, deal_id="big", amount=10000, name="bigone"),
        ]
        out = ar.render_deals_this_week_html(
            deals=deals, week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert out.index("bigone") < out.index("smallone")

    def test_empty_renders_empty_state(self):
        out = ar.render_deals_this_week_html(
            deals=[], week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert "Nothing this week" in out

    def test_none_renders_empty_state(self):
        out = ar.render_deals_this_week_html(
            deals=None, week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert "Nothing this week" in out

    def test_next_week_filtered_out(self):
        deals = [_open_deal(AFTER_WEEK_DATE, name="future_deal")]
        out = ar.render_deals_this_week_html(
            deals=deals, week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert "future_deal" not in out

    def test_won_last_week_filtered_out(self):
        deals = [_won_deal(BEFORE_WEEK_DATE, name="prewin")]
        out = ar.render_deals_this_week_html(
            deals=deals, week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert "prewin" not in out


class TestRenderHtmlStructure:
    def test_doctype(self):
        out = ar.render_deals_this_week_html(
            deals=[], week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert out.startswith("<!doctype html>")

    def test_closed_html(self):
        out = ar.render_deals_this_week_html(
            deals=[], week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert out.rstrip().endswith("</html>")

    def test_title_tag(self):
        out = ar.render_deals_this_week_html(
            deals=[], week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert "<title>Deals this week</title>" in out

    def test_drill_up_included(self):
        out = ar.render_deals_this_week_html(
            deals=[_open_deal(IN_WEEK_DATE)],
            week_start_date=WEEK_START,
            week_end_date=WEEK_END,
        )
        assert "g8://deals/pipeline" in out


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------


class TestTextFallback:
    def test_h1(self):
        out = ar.render_deals_this_week_text_fallback(
            deals=[], week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert out.startswith("# Deals this week")

    def test_empty_state(self):
        out = ar.render_deals_this_week_text_fallback(
            deals=[], week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert "Nothing this week" in out

    def test_stats_present(self):
        deals = [_open_deal(IN_WEEK_DATE, amount=1000)]
        out = ar.render_deals_this_week_text_fallback(
            deals=deals, week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert "Total in window" in out
        assert "Pipeline $" in out
        assert "Won $" in out
        assert "Lost $" in out

    def test_lists_deals(self):
        deals = [_open_deal(IN_WEEK_DATE, amount=1000, name="specific_deal")]
        out = ar.render_deals_this_week_text_fallback(
            deals=deals, week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert "specific_deal" in out

    def test_backend_filter_hint(self):
        deals = [_open_deal(IN_WEEK_DATE)]
        out = ar.render_deals_this_week_text_fallback(
            deals=deals, week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert "close_after" in out
        assert "close_before" in out

    def test_related_surfaces(self):
        out = ar.render_deals_this_week_text_fallback(
            deals=[], week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert "g8://deals/pipeline" in out
        assert "g8://deals/dashboard" in out
        assert "g8://activities/today" in out


# ---------------------------------------------------------------------------
# Design tokens
# ---------------------------------------------------------------------------


class TestDesignTokens:
    def test_no_banned_studio_hexes(self):
        out = ar.render_deals_this_week_html(
            deals=[
                _open_deal(IN_WEEK_DATE),
                _won_deal(IN_WEEK_DATE),
                _lost_deal(IN_WEEK_DATE),
            ],
            week_start_date=WEEK_START,
            week_end_date=WEEK_END,
        )
        for banned in ("#1d4ed8", "#166534", "#991b1b", "#0891b2"):
            assert banned not in out, f"banned hex {banned} leaked"

    def test_primary_purple_used(self):
        out = ar.render_deals_this_week_html(
            deals=[_open_deal(IN_WEEK_DATE)],
            week_start_date=WEEK_START,
            week_end_date=WEEK_END,
        )
        assert ar._G8_PRIMARY in out

    def test_aeonik_font(self):
        out = ar.render_deals_this_week_html(
            deals=[], week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert "Aeonik" in out

    def test_border(self):
        out = ar.render_deals_this_week_html(
            deals=[], week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert ar._G8_BORDER in out

    def test_positive_bg_won(self):
        out = ar.render_deals_this_week_html(
            deals=[_won_deal(IN_WEEK_DATE)],
            week_start_date=WEEK_START,
            week_end_date=WEEK_END,
        )
        assert ar._G8_POSITIVE_BG in out

    def test_destructive_bg_lost(self):
        out = ar.render_deals_this_week_html(
            deals=[_lost_deal(IN_WEEK_DATE)],
            week_start_date=WEEK_START,
            week_end_date=WEEK_END,
        )
        assert ar._G8_DESTRUCTIVE_BG in out

    def test_accent_bg_closing(self):
        out = ar.render_deals_this_week_html(
            deals=[_open_deal(IN_WEEK_DATE)],
            week_start_date=WEEK_START,
            week_end_date=WEEK_END,
        )
        assert ar._G8_ACCENT_BG in out


# ---------------------------------------------------------------------------
# No JS
# ---------------------------------------------------------------------------


class TestNoJs:
    def test_no_script_tag(self):
        out = ar.render_deals_this_week_html(
            deals=[_open_deal(IN_WEEK_DATE)],
            week_start_date=WEEK_START,
            week_end_date=WEEK_END,
        )
        assert "<script" not in out.lower()

    def test_no_event_handlers(self):
        out = ar.render_deals_this_week_html(
            deals=[_open_deal(IN_WEEK_DATE)],
            week_start_date=WEEK_START,
            week_end_date=WEEK_END,
        )
        for attr in (" onclick=", " onload=", " onerror=", " onmouseover="):
            assert attr not in out


# ---------------------------------------------------------------------------
# Smoke
# ---------------------------------------------------------------------------


class TestSmoke:
    @pytest.mark.parametrize(
        "stage",
        [
            "negotiating",
            "proposal",
            "prospecting",
            "qualification",
            "discovery",
            "pending",
        ],
    )
    def test_open_stages_render(self, stage):
        deal = {"id": "s", "name": f"stg-{stage}", "stage": stage,
                "close_date": IN_WEEK_DATE, "amount": 500}
        out = ar.render_deals_this_week_html(
            deals=[deal], week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert f"stg-{stage}" in out

    @pytest.mark.parametrize(
        "stage", ["won", "closed_won", "closed-won", "WON", "won - upsell"]
    )
    def test_won_variants(self, stage):
        deal = {
            "id": "w", "name": f"won-{stage}", "stage": stage,
            "closed_at": IN_WEEK_DATE, "amount": 10000,
        }
        out = ar.render_deals_this_week_html(
            deals=[deal], week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert f"won-{stage}" in out

    @pytest.mark.parametrize(
        "stage", ["lost", "closed_lost", "closed-lost", "LOST", "lost to competitor"]
    )
    def test_lost_variants(self, stage):
        deal = {
            "id": "l", "name": f"lost-{stage}", "stage": stage,
            "closed_at": IN_WEEK_DATE, "amount": 5000,
        }
        out = ar.render_deals_this_week_html(
            deals=[deal], week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert f"lost-{stage}" in out

    def test_full_mix_rendered(self):
        deals = []
        for i in range(10):
            deals.append(
                _open_deal(IN_WEEK_DATE, deal_id=f"c{i}", name=f"close{i}", amount=1000 + i)
            )
        for i in range(5):
            deals.append(
                _won_deal(IN_WEEK_DATE, deal_id=f"w{i}", name=f"win{i}", amount=5000)
            )
        for i in range(3):
            deals.append(
                _lost_deal(IN_WEEK_DATE, deal_id=f"l{i}", name=f"loss{i}", amount=2000)
            )
        out = ar.render_deals_this_week_html(
            deals=deals, week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert "close0" in out and "win0" in out and "loss0" in out

    def test_overflow(self):
        deals = [
            _open_deal(IN_WEEK_DATE, deal_id=f"t{i}", name=f"deal{i}", amount=i)
            for i in range(45)
        ]
        out = ar.render_deals_this_week_html(
            deals=deals, week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert "5 more omitted" in out


# ---------------------------------------------------------------------------
# Return types
# ---------------------------------------------------------------------------


class TestReturnTypes:
    def test_html_returns_str(self):
        out = ar.render_deals_this_week_html(
            deals=[], week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert isinstance(out, str)

    def test_text_returns_str(self):
        out = ar.render_deals_this_week_text_fallback(
            deals=[], week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert isinstance(out, str)

    def test_partition_returns_dict(self):
        out = ar._deals_this_week_partition(
            [], week_start_date=WEEK_START, week_end_date=WEEK_END
        )
        assert isinstance(out, dict)

    def test_sort_band_returns_list(self):
        out = ar._deals_this_week_sort_band([], "closing_this_week")
        assert isinstance(out, list)
