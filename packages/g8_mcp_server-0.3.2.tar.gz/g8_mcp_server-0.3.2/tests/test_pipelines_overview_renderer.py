"""Tests for the pipelines overview HTML + text renderers (upgrade 4 — #14)."""

from __future__ import annotations

from g8_mcp_server import app_renderer
from g8_mcp_server.app_renderer import (
    _stage_sort_key,
    render_pipelines_overview_html,
    render_pipelines_overview_text_fallback,
)


def _stage(id_: str = "s1", name: str = "Stage", order: int | None = 0) -> dict:
    return {"id": id_, "name": name, "order": order}


def _pipeline(
    id_: str = "p1",
    name: str = "Default Pipeline",
    stages: list[dict] | None = None,
) -> dict:
    if stages is None:
        stages = [
            _stage(id_="s1", name="Lead", order=0),
            _stage(id_="s2", name="Qualify", order=1),
            _stage(id_="s3", name="Proposal", order=2),
        ]
    return {"id": id_, "name": name, "stages": stages}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class TestStageSortKey:
    def test_order_ascending(self):
        a = _stage(id_="a", order=0)
        b = _stage(id_="b", order=1)
        assert _stage_sort_key(a) < _stage_sort_key(b)

    def test_none_order_sorts_last(self):
        a = _stage(id_="a", order=0)
        b = _stage(id_="b", order=None)
        assert _stage_sort_key(a) < _stage_sort_key(b)

    def test_missing_order_sorts_last(self):
        a = _stage(id_="a", order=3)
        b = {"id": "b", "name": "no order"}  # no "order" key
        assert _stage_sort_key(a) < _stage_sort_key(b)

    def test_same_order_tiebreak_by_id(self):
        a = {"id": "aaa", "name": "X", "order": 0}
        b = {"id": "zzz", "name": "Y", "order": 0}
        assert _stage_sort_key(a) < _stage_sort_key(b)

    def test_missing_id_tiebreak(self):
        a = {"name": "X", "order": 0}  # no id
        b = {"id": "zz", "name": "Y", "order": 0}
        # a has id="" vs b="zz", so a < b
        assert _stage_sort_key(a) < _stage_sort_key(b)

    def test_non_int_order_sorts_last(self):
        # String / float / None / missing all treated as fallback
        a = _stage(id_="a", order=0)
        b = {"id": "b", "name": "odd", "order": "five"}
        assert _stage_sort_key(a) < _stage_sort_key(b)


# ---------------------------------------------------------------------------
# HTML renderer
# ---------------------------------------------------------------------------


class TestRenderPipelinesOverviewHtml:
    def test_empty_state_none(self):
        html_out = render_pipelines_overview_html(pipelines=None)
        assert "No pipelines yet" in html_out

    def test_empty_state_empty_list(self):
        html_out = render_pipelines_overview_html(pipelines=[])
        assert "No pipelines yet" in html_out

    def test_non_list_input(self):
        html_out = render_pipelines_overview_html(pipelines="nope")  # type: ignore[arg-type]
        assert "No pipelines yet" in html_out

    def test_only_garbage_items(self):
        html_out = render_pipelines_overview_html(pipelines=[None, "x", 1])  # type: ignore[list-item]
        assert "No pipelines yet" in html_out

    def test_renders_pipeline(self):
        html_out = render_pipelines_overview_html(pipelines=[_pipeline()])
        assert "Default Pipeline" in html_out
        assert "Lead" in html_out
        assert "Qualify" in html_out
        assert "Proposal" in html_out

    def test_stage_count_in_heading(self):
        html_out = render_pipelines_overview_html(pipelines=[_pipeline()])
        assert "3 stage(s)" in html_out

    def test_header_total_stages_count(self):
        html_out = render_pipelines_overview_html(
            pipelines=[
                _pipeline(id_="p1", name="A"),  # 3 stages
                _pipeline(id_="p2", name="B", stages=[_stage()]),  # 1 stage
            ]
        )
        # Pipeline count and total stage count rendered in header
        assert "2 pipeline(s)" in html_out
        assert "4 stage(s)" in html_out

    def test_stage_numbering(self):
        html_out = render_pipelines_overview_html(pipelines=[_pipeline()])
        # Each stage should have a 1-indexed num badge (1, 2, 3)
        assert ">1<" in html_out
        assert ">2<" in html_out
        assert ">3<" in html_out

    def test_stage_order_preserved(self):
        # order 2, 0, 1 shuffled — should render 0, 1, 2
        html_out = render_pipelines_overview_html(
            pipelines=[
                _pipeline(
                    stages=[
                        _stage(id_="s3", name="Proposal", order=2),
                        _stage(id_="s1", name="Lead", order=0),
                        _stage(id_="s2", name="Qualify", order=1),
                    ]
                )
            ]
        )
        lead_pos = html_out.find("Lead")
        qualify_pos = html_out.find("Qualify")
        proposal_pos = html_out.find("Proposal")
        assert lead_pos < qualify_pos < proposal_pos

    def test_stages_with_none_order_still_render(self):
        html_out = render_pipelines_overview_html(
            pipelines=[
                _pipeline(
                    stages=[
                        _stage(id_="s1", name="First", order=0),
                        _stage(id_="s2", name="Second", order=None),
                        _stage(id_="s3", name="Third", order=None),
                    ]
                )
            ]
        )
        # All three names should appear
        assert "First" in html_out
        assert "Second" in html_out
        assert "Third" in html_out

    def test_unnamed_pipeline_fallback(self):
        html_out = render_pipelines_overview_html(
            pipelines=[_pipeline(name=None)]
        )
        assert "(unnamed pipeline)" in html_out

    def test_unnamed_stage_fallback(self):
        html_out = render_pipelines_overview_html(
            pipelines=[
                _pipeline(
                    stages=[
                        _stage(id_="s1", name=None, order=0),
                        _stage(id_="s2", name="Named", order=1),
                    ]
                )
            ]
        )
        assert "(stage 1)" in html_out
        assert "Named" in html_out

    def test_empty_stages_shows_note(self):
        html_out = render_pipelines_overview_html(
            pipelines=[_pipeline(stages=[])]
        )
        assert "No stages configured" in html_out

    def test_garbage_stages_filtered(self):
        html_out = render_pipelines_overview_html(
            pipelines=[_pipeline(stages=[None, "x", 1, _stage(name="OK")])]  # type: ignore[list-item]
        )
        assert "OK" in html_out
        # Only 1 valid stage — header should say "1 stage(s)" in pipeline heading
        # (multiple "1 stage(s)" may appear — top-level and pipeline heading)
        assert "1 stage(s)" in html_out

    def test_org_label(self):
        html_out = render_pipelines_overview_html(
            pipelines=[_pipeline()], org_label="Acme"
        )
        assert "Acme" in html_out

    def test_arrow_separator_in_css(self):
        """Stage chips should be connected by a CSS ::before arrow."""
        html_out = render_pipelines_overview_html(pipelines=[_pipeline()])
        # The CSS rule uses "→" content
        assert "→" in html_out or "&rarr;" in html_out


class TestEscaping:
    def test_pipeline_name_escaped(self):
        html_out = render_pipelines_overview_html(
            pipelines=[_pipeline(name="<script>evil()</script>")]
        )
        assert "<script>evil" not in html_out
        assert "&lt;script&gt;" in html_out

    def test_stage_name_escaped(self):
        html_out = render_pipelines_overview_html(
            pipelines=[
                _pipeline(stages=[_stage(name="<xss>", order=0)])
            ]
        )
        assert "<xss>" not in html_out
        assert "&lt;xss&gt;" in html_out


class TestBounds:
    def test_max_pipelines_rendered(self):
        # 15 pipelines, cap is 10 — footer note must appear
        pipelines = [
            _pipeline(id_=f"p{i}", name=f"Pipeline {i}")
            for i in range(15)
        ]
        html_out = render_pipelines_overview_html(pipelines=pipelines)
        assert "5 pipeline(s) omitted" in html_out

    def test_max_stages_per_pipeline(self):
        # 30 stages, cap is 20 — per-pipeline omitted note must appear
        stages = [
            _stage(id_=f"s{i}", name=f"Stage {i}", order=i)
            for i in range(30)
        ]
        html_out = render_pipelines_overview_html(
            pipelines=[_pipeline(stages=stages)]
        )
        assert "10 stage(s) omitted" in html_out

    def test_long_pipeline_name_truncated(self):
        html_out = render_pipelines_overview_html(
            pipelines=[_pipeline(name="x" * 5000)]
        )
        assert "…" in html_out

    def test_long_stage_name_truncated(self):
        html_out = render_pipelines_overview_html(
            pipelines=[
                _pipeline(stages=[_stage(name="y" * 5000, order=0)])
            ]
        )
        assert "…" in html_out


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------


class TestPipelinesOverviewTextFallback:
    def test_empty_none(self):
        out = render_pipelines_overview_text_fallback(pipelines=None)
        assert "No pipelines yet" in out

    def test_empty_list(self):
        out = render_pipelines_overview_text_fallback(pipelines=[])
        assert "No pipelines yet" in out

    def test_non_list(self):
        out = render_pipelines_overview_text_fallback(pipelines="nope")  # type: ignore[arg-type]
        assert "No pipelines yet" in out

    def test_only_garbage_items(self):
        out = render_pipelines_overview_text_fallback(pipelines=[None, "x", 1])  # type: ignore[list-item]
        assert "No pipelines yet" in out

    def test_renders_pipeline_name(self):
        out = render_pipelines_overview_text_fallback(pipelines=[_pipeline()])
        assert "Default Pipeline" in out

    def test_renders_stage_flow_chain(self):
        out = render_pipelines_overview_text_fallback(pipelines=[_pipeline()])
        # Should produce "1. Lead → 2. Qualify → 3. Proposal"
        assert "1. Lead" in out
        assert "2. Qualify" in out
        assert "3. Proposal" in out
        assert " → " in out

    def test_stage_order_preserved(self):
        out = render_pipelines_overview_text_fallback(
            pipelines=[
                _pipeline(
                    stages=[
                        _stage(id_="s3", name="Proposal", order=2),
                        _stage(id_="s1", name="Lead", order=0),
                        _stage(id_="s2", name="Qualify", order=1),
                    ]
                )
            ]
        )
        lead_pos = out.find("Lead")
        qualify_pos = out.find("Qualify")
        proposal_pos = out.find("Proposal")
        assert lead_pos < qualify_pos < proposal_pos

    def test_empty_stages_note(self):
        out = render_pipelines_overview_text_fallback(
            pipelines=[_pipeline(stages=[])]
        )
        assert "(no stages configured)" in out

    def test_unnamed_pipeline_fallback(self):
        out = render_pipelines_overview_text_fallback(
            pipelines=[_pipeline(name=None)]
        )
        assert "(unnamed pipeline)" in out

    def test_unnamed_stage_fallback(self):
        out = render_pipelines_overview_text_fallback(
            pipelines=[
                _pipeline(stages=[_stage(name=None, order=0)])
            ]
        )
        assert "(stage 1)" in out

    def test_org_label(self):
        out = render_pipelines_overview_text_fallback(
            pipelines=[_pipeline()], org_label="Acme"
        )
        assert "# Pipelines — Acme" in out

    def test_header_counts(self):
        out = render_pipelines_overview_text_fallback(
            pipelines=[
                _pipeline(id_="p1", name="A"),  # 3 stages
                _pipeline(id_="p2", name="B", stages=[_stage()]),  # 1 stage
            ]
        )
        assert "2 pipeline(s)" in out
        assert "4 stage(s)" in out

    def test_max_pipelines_cap(self):
        pipelines = [
            _pipeline(id_=f"p{i}", name=f"Pipeline {i}")
            for i in range(15)
        ]
        out = render_pipelines_overview_text_fallback(pipelines=pipelines)
        assert "more pipeline(s)" in out

    def test_max_stages_cap(self):
        stages = [
            _stage(id_=f"s{i}", name=f"Stage {i}", order=i)
            for i in range(30)
        ]
        out = render_pipelines_overview_text_fallback(
            pipelines=[_pipeline(stages=stages)]
        )
        assert "more stage(s) omitted" in out

    def test_no_html_leak(self):
        out = render_pipelines_overview_text_fallback(
            pipelines=[_pipeline(name="<tag>")]
        )
        assert "<html>" not in out
        assert "<body>" not in out


# ---------------------------------------------------------------------------
# Caps sanity
# ---------------------------------------------------------------------------


class TestCapsExist:
    def test_constants(self):
        assert app_renderer._MAX_PIPELINES_RENDERED >= 3
        assert app_renderer._MAX_PIPELINE_NAME_LEN >= 50
        assert app_renderer._MAX_STAGE_NAME_LEN >= 20
        assert app_renderer._MAX_STAGES_PER_PIPELINE >= 5
