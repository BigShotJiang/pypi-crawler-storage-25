"""Unit tests for Surface #72 — per-sequence inbox renderer.

Covers `render_sequence_inbox_html` and
`render_sequence_inbox_text_fallback` in `app_renderer.py`.

Parallels the test discipline from #69/#70/#71: helpers tested in
isolation, graph8 design-token parity, no legacy hexes, no inline JS,
XSS escape at render sites (escape-once-not-twice contract), dual
empty-state modes (preview unavailable vs. zero replies), overflow
banner math, drill-up links without self-reference.
"""

import pytest

from g8_mcp_server.app_renderer import (
    _G8_ACCENT_BG,
    _G8_ACCENT_BORDER,
    _G8_BORDER,
    _G8_CARD_BG,
    _G8_CARD_RADIUS,
    _G8_FONT,
    _G8_MUTED_BG,
    _G8_PRIMARY,
    _G8_TEXT,
    _MAX_SEQ_INBOX_THREADS_RENDERED,
    _MAX_SEQ_INBOX_TAGS_PER_THREAD,
    _seq_inbox_channel_chip_html,
    _seq_inbox_channel_palette,
    _seq_inbox_clip,
    _seq_inbox_contact_label,
    _seq_inbox_count_by_channel,
    _seq_inbox_count_by_status,
    _seq_inbox_drill_up_html,
    _seq_inbox_header_html,
    _seq_inbox_kpi_card_html,
    _seq_inbox_message_preview,
    _seq_inbox_overflow_banner_html,
    _seq_inbox_sequence_label,
    _seq_inbox_stats_row_html,
    _seq_inbox_status_palette,
    _seq_inbox_thread_list_html,
    _seq_inbox_thread_row_html,
    render_sequence_inbox_html,
    render_sequence_inbox_text_fallback,
)


_SEQ_ID = "seq_8ab27791efff40deaaaa"


def _make_preview(**overrides) -> dict:
    data = {"id": _SEQ_ID, "name": "Q2 outbound SaaS", "steps": []}
    data.update(overrides)
    return data


def _make_thread(**overrides) -> dict:
    data = {
        "id": "t1",
        "channel": "email",
        "subject": "Re: intro",
        "status": "responded",
        "contact": {"name": "Alice", "email": "alice@ex.com", "company": "Acme"},
        "messages": [{"content": "Sounds interesting, tell me more."}],
        "tags": [{"name": "hot"}],
        "assignees": [{"email": "bob@ours.com"}],
        "created_at": "2026-04-18",
        "updated_at": "2026-04-20",
    }
    data.update(overrides)
    return data


def _make_threads(n: int = 3) -> list:
    threads = []
    for i in range(n):
        ch = ["email", "sms", "linkedin"][i % 3]
        st = ["open", "responded", "ai_responded"][i % 3]
        threads.append(
            _make_thread(
                id=f"t{i}",
                channel=ch,
                subject=f"Thread #{i}",
                status=st,
                contact={"name": f"Person {i}", "email": f"p{i}@ex.com"},
                messages=[{"content": f"msg body {i}"}],
            )
        )
    return threads


# ----------------------------------------------------------------- #
# Clip helper
# ----------------------------------------------------------------- #


class TestClip:
    def test_preserves_under_cap(self):
        assert _seq_inbox_clip("hi", 10) == "hi"

    def test_clips_over_cap(self):
        out = _seq_inbox_clip("abcdefghijklmno", 8)
        assert out.endswith("…")
        assert len(out) == 8

    def test_none(self):
        assert _seq_inbox_clip(None, 10) == ""

    def test_exact_cap(self):
        assert _seq_inbox_clip("abcdef", 6) == "abcdef"

    def test_non_str(self):
        assert _seq_inbox_clip(42, 10) == "42"


# ----------------------------------------------------------------- #
# Sequence label
# ----------------------------------------------------------------- #


class TestSequenceLabel:
    def test_prefers_name(self):
        assert (
            _seq_inbox_sequence_label({"name": "My Seq"}, "seq_x") == "My Seq"
        )

    def test_falls_back_to_title(self):
        assert (
            _seq_inbox_sequence_label({"title": "Titled"}, "seq_x") == "Titled"
        )

    def test_falls_back_to_id(self):
        assert (
            _seq_inbox_sequence_label(None, "seq_abc") == "Sequence seq_abc"
        )

    def test_empty_name_falls_through(self):
        assert (
            _seq_inbox_sequence_label({"name": "  "}, "seq_x")
            == "Sequence seq_x"
        )

    def test_non_dict(self):
        assert _seq_inbox_sequence_label("nope", "seq_x") == "Sequence seq_x"

    def test_long_name_clipped(self):
        long = "a" * 300
        result = _seq_inbox_sequence_label({"name": long}, "seq_x")
        assert result.endswith("…")


# ----------------------------------------------------------------- #
# Contact label extraction
# ----------------------------------------------------------------- #


class TestContactLabel:
    def test_name_email(self):
        n, e = _seq_inbox_contact_label({"name": "A", "email": "a@x.com"})
        assert n == "A"
        assert e == "a@x.com"

    def test_first_last(self):
        n, _ = _seq_inbox_contact_label(
            {"first_name": "Ada", "last_name": "Lovelace"}
        )
        assert n == "Ada Lovelace"

    def test_missing(self):
        assert _seq_inbox_contact_label(None) == ("", "")

    def test_non_dict(self):
        assert _seq_inbox_contact_label("nope") == ("", "")

    def test_partial(self):
        n, e = _seq_inbox_contact_label({"email": "only@x.com"})
        assert n == ""
        assert e == "only@x.com"


# ----------------------------------------------------------------- #
# Palettes
# ----------------------------------------------------------------- #


class TestChannelPalette:
    @pytest.mark.parametrize(
        "ch",
        ["email", "linkedin", "heyreach"],
    )
    def test_primary_palette(self, ch):
        bg, fg = _seq_inbox_channel_palette(ch)
        assert bg == _G8_ACCENT_BG
        assert fg == _G8_PRIMARY

    @pytest.mark.parametrize("ch", ["sms", "text"])
    def test_positive_palette(self, ch):
        bg, fg = _seq_inbox_channel_palette(ch)
        assert "#d1fae5" in bg.lower() or bg.lower() == "#d1fae5"

    def test_unknown(self):
        bg, fg = _seq_inbox_channel_palette("something")
        assert bg == _G8_MUTED_BG

    def test_none(self):
        bg, _ = _seq_inbox_channel_palette(None)
        assert bg == _G8_MUTED_BG


class TestStatusPalette:
    def test_responded_positive(self):
        bg, _ = _seq_inbox_status_palette("responded")
        assert bg.lower() == "#d1fae5"

    def test_ai_responded_primary(self):
        bg, fg = _seq_inbox_status_palette("ai_responded")
        assert bg == _G8_ACCENT_BG
        assert fg == _G8_PRIMARY

    def test_open_warning(self):
        bg, _ = _seq_inbox_status_palette("open")
        assert bg.lower() == "#fff3c4"

    def test_unknown(self):
        bg, _ = _seq_inbox_status_palette("weird")
        assert bg == _G8_MUTED_BG

    def test_none(self):
        bg, _ = _seq_inbox_status_palette(None)
        assert bg == _G8_MUTED_BG


# ----------------------------------------------------------------- #
# Message preview
# ----------------------------------------------------------------- #


class TestMessagePreview:
    def test_last_message_content(self):
        msgs = [
            {"content": "first"},
            {"content": "second"},
            {"content": "third"},
        ]
        assert _seq_inbox_message_preview(msgs) == "third"

    def test_body_field_fallback(self):
        msgs = [{"body": "body-only"}]
        assert _seq_inbox_message_preview(msgs) == "body-only"

    def test_text_field_fallback(self):
        msgs = [{"text": "text-only"}]
        assert _seq_inbox_message_preview(msgs) == "text-only"

    def test_empty(self):
        assert _seq_inbox_message_preview([]) == ""

    def test_none(self):
        assert _seq_inbox_message_preview(None) == ""

    def test_non_dict_rows_skipped(self):
        msgs = ["str-row", 42, {"content": "actual"}]
        assert _seq_inbox_message_preview(msgs) == "actual"

    def test_whitespace_collapsed(self):
        msgs = [{"content": "one\n\ntwo\t\tthree"}]
        assert _seq_inbox_message_preview(msgs) == "one two three"

    def test_non_string_content_returns_empty(self):
        msgs = [{"content": 42}]
        assert _seq_inbox_message_preview(msgs) == ""

    def test_clipping(self):
        msgs = [{"content": "a" * 500}]
        out = _seq_inbox_message_preview(msgs)
        assert out.endswith("…")
        assert len(out) <= 201  # cap + ellipsis


# ----------------------------------------------------------------- #
# Count helpers
# ----------------------------------------------------------------- #


class TestCountByStatus:
    def test_all_buckets(self):
        threads = [
            {"status": "open"},
            {"status": "open"},
            {"status": "responded"},
            {"status": "ai_responded"},
            {"status": "weird"},
        ]
        counts = _seq_inbox_count_by_status(threads)
        assert counts["total"] == 5
        assert counts["open"] == 2
        assert counts["responded"] == 1
        assert counts["ai_responded"] == 1

    def test_non_dict_skipped(self):
        counts = _seq_inbox_count_by_status(["nope", 42, {"status": "open"}])
        assert counts["total"] == 1
        assert counts["open"] == 1

    def test_empty(self):
        counts = _seq_inbox_count_by_status([])
        assert counts == {"total": 0, "open": 0, "responded": 0, "ai_responded": 0}


class TestCountByChannel:
    def test_groups(self):
        threads = [
            {"channel": "email"},
            {"channel": "email"},
            {"channel": "sms"},
            {"channel": "heyreach"},  # normalized to linkedin
        ]
        counts = _seq_inbox_count_by_channel(threads)
        assert counts["email"] == 2
        assert counts["sms"] == 1
        assert counts["linkedin"] == 1
        assert "heyreach" not in counts

    def test_missing_channel_becomes_other(self):
        threads = [{"channel": None}, {"channel": ""}, {}]
        counts = _seq_inbox_count_by_channel(threads)
        assert counts["other"] == 3


# ----------------------------------------------------------------- #
# KPI card + channel chip
# ----------------------------------------------------------------- #


class TestKpiCard:
    def test_renders_label_and_value(self):
        out = _seq_inbox_kpi_card_html("Total", "42")
        assert "Total" in out
        assert "42" in out

    def test_accent_flag(self):
        out = _seq_inbox_kpi_card_html("Total", "42", accent=True)
        assert _G8_ACCENT_BG in out


class TestChannelChip:
    def test_renders(self):
        out = _seq_inbox_channel_chip_html("email", 3)
        assert "EMAIL" in out
        assert ">3<" in out

    def test_xss_escape(self):
        out = _seq_inbox_channel_chip_html("<script>", 1)
        assert "<script>" not in out
        assert "&lt;script&gt;" in out.upper() or "&LT;" in out.upper()


# ----------------------------------------------------------------- #
# Header + stats row + channel row
# ----------------------------------------------------------------- #


class TestHeader:
    def test_label_rendered(self):
        out = _seq_inbox_header_html(
            sequence_label="My Seq",
            sequence_id="seq_xyz",
            thread_count=7,
        )
        assert "My Seq" in out
        assert "seq_xyz" in out
        assert "7 thread" in out

    def test_xss_label_escaped(self):
        out = _seq_inbox_header_html(
            sequence_label="<script>",
            sequence_id="seq_x",
            thread_count=0,
        )
        assert "<script>" not in out


class TestStatsRow:
    def test_counts_rendered(self):
        out = _seq_inbox_stats_row_html(
            {"total": 10, "open": 3, "responded": 5, "ai_responded": 2}
        )
        assert "10" in out
        assert ">3<" in out
        assert ">5<" in out
        assert ">2<" in out


# ----------------------------------------------------------------- #
# Thread row
# ----------------------------------------------------------------- #


class TestThreadRow:
    def test_subject_rendered(self):
        out = _seq_inbox_thread_row_html(_make_thread(subject="Hello world"))
        assert "Hello world" in out

    def test_channel_badge(self):
        out = _seq_inbox_thread_row_html(_make_thread(channel="email"))
        assert "EMAIL" in out

    def test_status_badge(self):
        out = _seq_inbox_thread_row_html(_make_thread(status="responded"))
        assert "RESPONDED" in out.upper()

    def test_contact_rendered(self):
        out = _seq_inbox_thread_row_html(_make_thread())
        assert "Alice" in out
        assert "alice@ex.com" in out

    def test_preview_rendered(self):
        out = _seq_inbox_thread_row_html(_make_thread())
        assert "Sounds interesting" in out

    def test_tag_rendered(self):
        out = _seq_inbox_thread_row_html(_make_thread(tags=[{"name": "hot"}]))
        assert "hot" in out

    def test_assignee_rendered(self):
        out = _seq_inbox_thread_row_html(_make_thread())
        assert "bob@ours.com" in out

    def test_thread_id_link(self):
        out = _seq_inbox_thread_row_html(_make_thread(id="t_xyz"))
        assert "g8://inbox/t_xyz" in out

    def test_heyreach_normalized_to_linkedin(self):
        out = _seq_inbox_thread_row_html(_make_thread(channel="heyreach"))
        assert "LINKEDIN" in out

    def test_non_dict_returns_empty(self):
        assert _seq_inbox_thread_row_html("nope") == ""

    def test_xss_subject_escaped(self):
        out = _seq_inbox_thread_row_html(
            _make_thread(subject='<img src=x onerror=alert(1)>')
        )
        # Tag brackets must be escaped; the attribute text surviving as
        # inert text content is fine.
        assert "<img" not in out
        assert "&lt;img" in out
        assert "&gt;" in out

    def test_xss_contact_name_escaped(self):
        out = _seq_inbox_thread_row_html(
            _make_thread(
                contact={"name": "<script>alert(1)</script>", "email": "x@x.com"}
            )
        )
        assert "<script>" not in out

    def test_message_count_singular(self):
        out = _seq_inbox_thread_row_html(
            _make_thread(messages=[{"content": "only one"}])
        )
        assert "1 msg" in out
        assert "1 msgs" not in out

    def test_message_count_plural(self):
        out = _seq_inbox_thread_row_html(
            _make_thread(
                messages=[{"content": "a"}, {"content": "b"}, {"content": "c"}]
            )
        )
        assert "3 msgs" in out


# ----------------------------------------------------------------- #
# Thread list + overflow
# ----------------------------------------------------------------- #


class TestThreadList:
    def test_no_overflow(self):
        _html, overflow = _seq_inbox_thread_list_html(_make_threads(3))
        assert overflow == 0

    def test_overflow(self):
        threads = _make_threads(_MAX_SEQ_INBOX_THREADS_RENDERED + 5)
        _html, overflow = _seq_inbox_thread_list_html(threads)
        assert overflow == 5

    def test_non_dict_rows_filtered(self):
        threads = ["nope", 42, _make_thread()]
        _html, overflow = _seq_inbox_thread_list_html(threads)
        assert overflow == 0


class TestOverflowBanner:
    def test_zero_returns_empty(self):
        assert _seq_inbox_overflow_banner_html(0, "seq_x") == ""

    def test_nonzero_rendered(self):
        out = _seq_inbox_overflow_banner_html(5, "seq_abc")
        assert "+ 5 more" in out
        assert "seq_abc" in out

    def test_accent_tone(self):
        out = _seq_inbox_overflow_banner_html(3, "seq_x")
        assert _G8_ACCENT_BG in out


# ----------------------------------------------------------------- #
# Drill-up
# ----------------------------------------------------------------- #


class TestDrillUp:
    def test_no_self_ref(self):
        out = _seq_inbox_drill_up_html("seq_abc")
        # Must NOT link back to /inbox (that's the current page).
        assert "g8://sequences/seq_abc/inbox" not in out

    def test_overview_link(self):
        out = _seq_inbox_drill_up_html("seq_abc")
        assert "g8://sequences/seq_abc/overview" in out

    def test_preview_link(self):
        out = _seq_inbox_drill_up_html("seq_abc")
        assert "g8://sequences/seq_abc/preview" in out

    def test_analytics_link(self):
        out = _seq_inbox_drill_up_html("seq_abc")
        assert "g8://sequences/seq_abc/analytics" in out

    def test_contacts_link(self):
        out = _seq_inbox_drill_up_html("seq_abc")
        assert "g8://sequences/seq_abc/contacts" in out

    def test_dashboard_link(self):
        out = _seq_inbox_drill_up_html("seq_abc")
        assert "g8://sequences/dashboard" in out

    def test_org_inbox_link(self):
        out = _seq_inbox_drill_up_html("seq_abc")
        assert "g8://inbox/dashboard" in out


# ----------------------------------------------------------------- #
# Top-level renderer — populated case
# ----------------------------------------------------------------- #


class TestRenderHtml:
    def test_populated_render(self):
        out = render_sequence_inbox_html(
            threads=_make_threads(3),
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert "<!doctype html>" in out
        assert "Q2 outbound SaaS" in out
        assert "Sequence replies" in out

    def test_stats_total_counts(self):
        out = render_sequence_inbox_html(
            threads=_make_threads(3),
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        # 3 threads, channels are email/sms/linkedin one each.
        assert ">3<" in out
        assert ">1<" in out

    def test_channel_breakdown_present(self):
        out = render_sequence_inbox_html(
            threads=_make_threads(3),
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert "Channels" in out

    def test_overflow_banner(self):
        out = render_sequence_inbox_html(
            threads=_make_threads(_MAX_SEQ_INBOX_THREADS_RENDERED + 3),
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert "+ 3 more" in out

    def test_no_overflow_at_cap(self):
        out = render_sequence_inbox_html(
            threads=_make_threads(_MAX_SEQ_INBOX_THREADS_RENDERED),
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert "more thread" not in out.lower()

    def test_threads_non_list_coerced(self):
        out = render_sequence_inbox_html(
            threads="not a list",
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        # Coerced to [] → zero-state empty render (preview present)
        assert "No replies yet" in out


# ----------------------------------------------------------------- #
# Empty state — preview unavailable
# ----------------------------------------------------------------- #


class TestEmptyPreviewUnavailable:
    def test_unavailable_tone(self):
        out = render_sequence_inbox_html(
            threads=[],
            preview=None,
            sequence_id="seq_missing",
        )
        assert "Inbox not available" in out

    def test_mentions_sequence_id(self):
        out = render_sequence_inbox_html(
            threads=[],
            preview=None,
            sequence_id="seq_missing",
        )
        assert "seq_missing" in out

    def test_drill_up_present(self):
        out = render_sequence_inbox_html(
            threads=[],
            preview=None,
            sequence_id="seq_missing",
        )
        assert "g8://sequences/dashboard" in out


# ----------------------------------------------------------------- #
# Empty state — zero replies
# ----------------------------------------------------------------- #


class TestEmptyZeroReplies:
    def test_zero_replies_tone(self):
        out = render_sequence_inbox_html(
            threads=[],
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert "No replies yet" in out

    def test_mentions_sequence_name(self):
        out = render_sequence_inbox_html(
            threads=[],
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert "Q2 outbound SaaS" in out

    def test_accent_tone(self):
        out = render_sequence_inbox_html(
            threads=[],
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert _G8_ACCENT_BG in out


# ----------------------------------------------------------------- #
# Design tokens parity
# ----------------------------------------------------------------- #


class TestDesignTokens:
    def test_primary_token_used(self):
        out = render_sequence_inbox_html(
            threads=_make_threads(2),
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert _G8_PRIMARY in out

    def test_border_token_used(self):
        out = render_sequence_inbox_html(
            threads=_make_threads(2),
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert _G8_BORDER in out

    def test_font_token_used(self):
        out = render_sequence_inbox_html(
            threads=_make_threads(2),
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert "Aeonik" in out

    def test_card_radius_used(self):
        out = render_sequence_inbox_html(
            threads=_make_threads(2),
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert _G8_CARD_RADIUS in out

    def test_muted_bg_in_empty_state(self):
        out = render_sequence_inbox_html(
            threads=[],
            preview=None,
            sequence_id="seq_x",
        )
        assert _G8_MUTED_BG in out


# ----------------------------------------------------------------- #
# No legacy hexes / no JS / no single-side colored accent border
# ----------------------------------------------------------------- #


class TestNoLegacyHexes:
    @pytest.mark.parametrize(
        "bad_hex",
        ["#000000", "#EBEBEB", "#FAFAFA"],
    )
    def test_no_bad_hexes(self, bad_hex):
        out = render_sequence_inbox_html(
            threads=_make_threads(2),
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert bad_hex.lower() not in out.lower()

    def test_no_color_0(self):
        """#000 is a legacy tell unless used for shadow rgba — we use 0 0% 0%."""
        out = render_sequence_inbox_html(
            threads=_make_threads(1),
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        # should NOT have a raw color:#000
        assert "color:#000" not in out.replace(" ", "")
        assert "color:#000000" not in out.replace(" ", "")


class TestNoJavaScript:
    def test_no_script_tags(self):
        out = render_sequence_inbox_html(
            threads=_make_threads(3),
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert "<script" not in out.lower()

    def test_no_event_handlers(self):
        out = render_sequence_inbox_html(
            threads=_make_threads(3),
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        for evt in ("onclick", "onload", "onerror", "onmouseover"):
            assert evt not in out.lower()


class TestNoSingleSideColoredAccentBorder:
    def test_no_border_left_primary(self):
        """Single-side colored accent border is an AI-tell — reject it."""
        out = render_sequence_inbox_html(
            threads=_make_threads(3),
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        no_space = out.replace(" ", "")
        assert "border-left:3pxsolid#7d2df3" not in no_space.lower()
        assert "border-left:4pxsolid#7d2df3" not in no_space.lower()


# ----------------------------------------------------------------- #
# XSS escape at render sites
# ----------------------------------------------------------------- #


class TestXssEscape:
    def test_subject_escaped(self):
        threads = [
            _make_thread(subject='<img src=x onerror="alert(1)">'),
        ]
        out = render_sequence_inbox_html(
            threads=threads,
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        # Tag brackets escaped; attribute-quote escaping prevents the
        # payload from breaking out of text context.
        assert "<img" not in out
        assert "&lt;img" in out
        assert '"alert(1)"' not in out  # original quote pattern broken

    def test_sequence_id_escaped(self):
        out = render_sequence_inbox_html(
            threads=_make_threads(1),
            preview=_make_preview(),
            sequence_id="seq_<script>",
        )
        assert "<script>" not in out

    def test_preview_name_escaped(self):
        out = render_sequence_inbox_html(
            threads=_make_threads(1),
            preview={"name": "<b>bold</b>"},
            sequence_id=_SEQ_ID,
        )
        assert "<b>" not in out

    def test_tag_escaped(self):
        threads = [_make_thread(tags=[{"name": "<script>"}])]
        out = render_sequence_inbox_html(
            threads=threads,
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert "<script>" not in out


# ----------------------------------------------------------------- #
# Well-formed doc
# ----------------------------------------------------------------- #


class TestWellFormed:
    def test_doctype(self):
        out = render_sequence_inbox_html(
            threads=_make_threads(1),
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert out.startswith("<!doctype html>")

    def test_html_body_tags(self):
        out = render_sequence_inbox_html(
            threads=_make_threads(1),
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert "<html" in out
        assert "<body>" in out
        assert "</body>" in out
        assert "</html>" in out


# ----------------------------------------------------------------- #
# Text fallback
# ----------------------------------------------------------------- #


class TestTextFallback:
    def test_header(self):
        out = render_sequence_inbox_text_fallback(
            threads=_make_threads(2),
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert "# Sequence inbox — Q2 outbound SaaS" in out

    def test_sequence_id_bullet(self):
        out = render_sequence_inbox_text_fallback(
            threads=_make_threads(2),
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert f"sequence_id: `{_SEQ_ID}`" in out

    def test_stats_section(self):
        out = render_sequence_inbox_text_fallback(
            threads=_make_threads(3),
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert "## Stats" in out
        assert "Total: 3" in out

    def test_channels_section(self):
        out = render_sequence_inbox_text_fallback(
            threads=_make_threads(3),
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert "## Channels" in out
        assert "- email:" in out

    def test_threads_section(self):
        out = render_sequence_inbox_text_fallback(
            threads=_make_threads(2),
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert "## Threads" in out

    def test_thread_detail_link(self):
        out = render_sequence_inbox_text_fallback(
            threads=[_make_thread(id="t_xyz")],
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert "`g8://inbox/t_xyz`" in out

    def test_preview_quote(self):
        out = render_sequence_inbox_text_fallback(
            threads=[_make_thread(messages=[{"content": "inline-quote"}])],
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert "> inline-quote" in out

    def test_tags_line(self):
        out = render_sequence_inbox_text_fallback(
            threads=[_make_thread(tags=[{"name": "hot"}, {"name": "vip"}])],
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert "tags: hot, vip" in out

    def test_assignee_line(self):
        out = render_sequence_inbox_text_fallback(
            threads=[_make_thread(assignees=[{"name": "Bob"}])],
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert "assigned: Bob" in out

    def test_overflow_line(self):
        out = render_sequence_inbox_text_fallback(
            threads=_make_threads(_MAX_SEQ_INBOX_THREADS_RENDERED + 3),
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert "+ 3 more thread" in out

    def test_drill_up_no_self_ref(self):
        out = render_sequence_inbox_text_fallback(
            threads=_make_threads(1),
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert f"g8://sequences/{_SEQ_ID}/inbox" not in out

    def test_empty_no_preview(self):
        out = render_sequence_inbox_text_fallback(
            threads=[],
            preview=None,
            sequence_id="seq_missing",
        )
        assert "Inbox not available" in out
        assert "seq_missing" in out

    def test_empty_zero_replies(self):
        out = render_sequence_inbox_text_fallback(
            threads=[],
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert "No replies yet" in out

    def test_newline_terminated(self):
        out = render_sequence_inbox_text_fallback(
            threads=_make_threads(1),
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert out.endswith("\n")

    def test_non_list_threads_coerced(self):
        out = render_sequence_inbox_text_fallback(
            threads="nope",
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        # preview present → zero-state path
        assert "No replies yet" in out


# ----------------------------------------------------------------- #
# Smoke
# ----------------------------------------------------------------- #


class TestSmoke:
    def test_full_populated_render(self):
        threads = [
            _make_thread(
                id="t1",
                channel="email",
                subject="Re: intro",
                status="responded",
                tags=[{"name": "hot"}, {"name": "vip"}],
                assignees=[{"email": "bob@ours.com"}],
                messages=[
                    {"content": "Intro message"},
                    {"content": "Sounds great, interested"},
                ],
            ),
            _make_thread(
                id="t2",
                channel="sms",
                subject="Follow-up",
                status="open",
                contact={"name": "Charlie", "email": "c@x.com"},
                messages=[{"content": "maybe later"}],
                tags=[],
                assignees=[],
            ),
        ]
        out = render_sequence_inbox_html(
            threads=threads,
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert "<!doctype html>" in out
        assert "Q2 outbound SaaS" in out
        assert "Re: intro" in out
        assert "Follow-up" in out
        assert "EMAIL" in out
        assert "SMS" in out
        assert "bob@ours.com" in out
        assert "Charlie" in out
        assert "g8://inbox/t1" in out
        assert "g8://inbox/t2" in out

    def test_text_smoke(self):
        out = render_sequence_inbox_text_fallback(
            threads=_make_threads(2),
            preview=_make_preview(),
            sequence_id=_SEQ_ID,
        )
        assert "# Sequence inbox" in out
        assert "## Stats" in out
        assert "## Channels" in out
        assert "## Threads" in out
        assert "## Manage this sequence" in out
