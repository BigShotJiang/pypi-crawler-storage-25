"""Unit tests for the contact-notes app surface renderer (Upgrade 4 #34).

Covers:
  * helper functions: clip-content, author-label, group-by-author, stat-card
  * empty states (None vs []), with the celebratory "no notes yet" mode
  * full HTML render: header, stat grid, author breakdown, timeline,
    overflow notes, drill-up section
  * EDITED badge logic (updated_at != created_at)
  * label fallback chain (first/last → name → display_name → work_email)
  * XSS escape coverage on all user-controlled fields
  * text fallback parity with HTML

Pattern matches test_sync_errors_renderer.py / test_repo_detail_renderer.py.
"""

from __future__ import annotations

import re

import pytest

from g8_mcp_server.app_renderer import (
    _MAX_CONTACT_NOTE_AUTHOR_LEN,
    _MAX_CONTACT_NOTE_CONTENT_LEN,
    _MAX_CONTACT_NOTES_AUTHORS_RENDERED,
    _MAX_CONTACT_NOTES_RENDERED,
    _contact_notes_author_label,
    _contact_notes_clip_content,
    _contact_notes_group_by_author,
    _contact_notes_stat_card,
    _render_contact_notes_empty_state_html,
    render_contact_notes_html,
    render_contact_notes_text_fallback,
)


# ---------------------------------------------------------------------------
# Helper fixtures
# ---------------------------------------------------------------------------


def _make_note(**overrides):
    base = {
        "id": "11111111-1111-1111-1111-111111111111",
        "entity_type": "contact",
        "entity_id": "42",
        "content": "Default note body",
        "created_by": "u1",
        "created_by_name": "Alice",
        "created_at": "2026-04-18T10:00:00Z",
        "updated_at": "2026-04-18T10:00:00Z",
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# _contact_notes_clip_content
# ---------------------------------------------------------------------------


class TestClipContent:
    def test_returns_empty_label_for_none(self):
        assert _contact_notes_clip_content(None) == "(empty note)"

    def test_returns_empty_label_for_empty_string(self):
        assert _contact_notes_clip_content("") == "(empty note)"

    def test_returns_empty_label_for_whitespace_only(self):
        assert _contact_notes_clip_content("   \n\t  ") == "(empty note)"

    def test_returns_empty_label_for_non_string(self):
        assert _contact_notes_clip_content(123) == "(empty note)"

    def test_strips_outer_whitespace(self):
        assert _contact_notes_clip_content("  hello  ") == "hello"

    def test_short_content_passes_through(self):
        assert _contact_notes_clip_content("short note") == "short note"

    def test_long_content_clipped_with_ellipsis(self):
        long = "x" * (_MAX_CONTACT_NOTE_CONTENT_LEN + 50)
        result = _contact_notes_clip_content(long)
        assert result.endswith("…")
        assert len(result) <= _MAX_CONTACT_NOTE_CONTENT_LEN + 1  # +1 for ellipsis

    def test_preserves_internal_newlines(self):
        # Whitespace.strip() trims outer only, internal newlines preserved
        assert _contact_notes_clip_content("line1\nline2") == "line1\nline2"

    def test_does_not_html_escape(self):
        # Caller is responsible for escaping
        assert _contact_notes_clip_content("<b>bold</b>") == "<b>bold</b>"


# ---------------------------------------------------------------------------
# _contact_notes_author_label
# ---------------------------------------------------------------------------


class TestAuthorLabel:
    def test_prefers_created_by_name(self):
        note = _make_note(created_by="user_id_1", created_by_name="Alice")
        assert _contact_notes_author_label(note) == "Alice"

    def test_falls_back_to_created_by(self):
        note = _make_note(created_by="user@example.com", created_by_name=None)
        assert _contact_notes_author_label(note) == "user@example.com"

    def test_falls_back_to_unknown_when_both_missing(self):
        note = _make_note(created_by=None, created_by_name=None)
        assert _contact_notes_author_label(note) == "Unknown"

    def test_unknown_when_both_empty_string(self):
        note = _make_note(created_by="", created_by_name="")
        assert _contact_notes_author_label(note) == "Unknown"

    def test_unknown_when_created_by_name_whitespace_only(self):
        note = _make_note(created_by="fallback", created_by_name="   ")
        assert _contact_notes_author_label(note) == "fallback"

    def test_strips_outer_whitespace_from_name(self):
        note = _make_note(created_by_name="  Alice  ")
        assert _contact_notes_author_label(note) == "Alice"

    def test_handles_non_dict(self):
        assert _contact_notes_author_label(None) == "Unknown"
        assert _contact_notes_author_label("not a dict") == "Unknown"

    def test_clips_long_name(self):
        long_name = "X" * (_MAX_CONTACT_NOTE_AUTHOR_LEN + 20)
        note = _make_note(created_by_name=long_name)
        result = _contact_notes_author_label(note)
        assert result.endswith("…")
        assert len(result) <= _MAX_CONTACT_NOTE_AUTHOR_LEN + 1


# ---------------------------------------------------------------------------
# _contact_notes_group_by_author
# ---------------------------------------------------------------------------


class TestGroupByAuthor:
    def test_empty_input_returns_empty_list(self):
        assert _contact_notes_group_by_author([]) == []

    def test_single_author(self):
        notes = [
            _make_note(created_by_name="Alice", created_at="2026-04-18T10:00:00Z"),
            _make_note(created_by_name="Alice", created_at="2026-04-17T10:00:00Z"),
        ]
        groups = _contact_notes_group_by_author(notes)
        assert len(groups) == 1
        assert groups[0]["author"] == "Alice"
        assert groups[0]["count"] == 2
        assert groups[0]["last_seen"] == "2026-04-18T10:00:00Z"
        assert groups[0]["first_seen"] == "2026-04-17T10:00:00Z"

    def test_sorted_by_count_desc(self):
        notes = [
            _make_note(created_by_name="Bob"),
            _make_note(created_by_name="Alice"),
            _make_note(created_by_name="Alice"),
            _make_note(created_by_name="Alice"),
            _make_note(created_by_name="Carol"),
            _make_note(created_by_name="Carol"),
        ]
        groups = _contact_notes_group_by_author(notes)
        assert [g["author"] for g in groups] == ["Alice", "Carol", "Bob"]
        assert [g["count"] for g in groups] == [3, 2, 1]

    def test_skips_non_dict_entries(self):
        notes = [
            _make_note(created_by_name="Alice"),
            "not a dict",  # type: ignore[list-item]
            None,  # type: ignore[list-item]
            _make_note(created_by_name="Alice"),
        ]
        groups = _contact_notes_group_by_author(notes)
        assert len(groups) == 1
        assert groups[0]["count"] == 2

    def test_handles_missing_timestamps(self):
        notes = [
            _make_note(created_by_name="Alice", created_at=None),
            _make_note(created_by_name="Alice", created_at=None),
        ]
        groups = _contact_notes_group_by_author(notes)
        assert groups[0]["count"] == 2
        assert groups[0]["last_seen"] is None
        assert groups[0]["first_seen"] is None

    def test_partial_timestamps(self):
        notes = [
            _make_note(created_by_name="Alice", created_at=None),
            _make_note(created_by_name="Alice", created_at="2026-04-18T10:00:00Z"),
        ]
        groups = _contact_notes_group_by_author(notes)
        assert groups[0]["last_seen"] == "2026-04-18T10:00:00Z"
        assert groups[0]["first_seen"] == "2026-04-18T10:00:00Z"

    def test_unknown_author_grouped_together(self):
        notes = [
            _make_note(created_by_name=None, created_by=None),
            _make_note(created_by_name=None, created_by=None),
        ]
        groups = _contact_notes_group_by_author(notes)
        assert len(groups) == 1
        assert groups[0]["author"] == "Unknown"
        assert groups[0]["count"] == 2

    def test_ties_broken_by_last_seen_desc(self):
        notes = [
            _make_note(created_by_name="Alice", created_at="2026-04-10T00:00:00Z"),
            _make_note(created_by_name="Bob", created_at="2026-04-18T00:00:00Z"),
        ]
        groups = _contact_notes_group_by_author(notes)
        # Both have count=1, so Bob (later) should sort first
        assert groups[0]["author"] == "Bob"
        assert groups[1]["author"] == "Alice"


# ---------------------------------------------------------------------------
# _contact_notes_stat_card
# ---------------------------------------------------------------------------


class TestStatCard:
    def test_basic_card(self):
        html = _contact_notes_stat_card("Total", "5")
        assert "Total" in html
        assert ">5<" in html
        assert "stat-card" in html

    def test_escapes_label_and_value(self):
        html = _contact_notes_stat_card("<x>", "<y>")
        assert "<x>" not in html
        assert "<y>" not in html
        assert "&lt;x&gt;" in html
        assert "&lt;y&gt;" in html

    def test_accent_renders_border(self):
        html = _contact_notes_stat_card("L", "V", accent="#059669")
        assert "border-top:3px solid #059669" in html

    def test_no_accent_no_border_top(self):
        html = _contact_notes_stat_card("L", "V")
        assert "border-top:3px solid" not in html

    def test_accent_is_escaped(self):
        # Accent comes from constant strings in renderer, but defensive escape
        html = _contact_notes_stat_card("L", "V", accent="<dangerous>")
        assert "<dangerous>" not in html


# ---------------------------------------------------------------------------
# _render_contact_notes_empty_state_html
# ---------------------------------------------------------------------------


class TestEmptyState:
    def test_zero_notes_celebratory_mode(self):
        html = _render_contact_notes_empty_state_html(
            contact_id="42", zero_notes=True
        )
        assert "No notes yet" in html
        assert "#7d2df3" in html  # Indigo accent for "add a note" call to action

    def test_zero_notes_calls_out_post_endpoint(self):
        html = _render_contact_notes_empty_state_html(
            contact_id="42", zero_notes=True
        )
        assert "POST /contacts" in html

    def test_not_available_mode_uses_gray_accent(self):
        html = _render_contact_notes_empty_state_html(
            contact_id="42", zero_notes=False
        )
        assert "Notes not available" in html
        assert "#777777" in html

    def test_empty_state_includes_contact_id(self):
        html = _render_contact_notes_empty_state_html(
            contact_id="abc-xyz-789", zero_notes=False
        )
        assert "abc-xyz-789" in html

    def test_empty_state_handles_missing_id(self):
        html = _render_contact_notes_empty_state_html(
            contact_id="", zero_notes=False
        )
        assert "(unknown)" in html

    def test_empty_state_escapes_contact_id(self):
        html = _render_contact_notes_empty_state_html(
            contact_id="<script>", zero_notes=False
        )
        assert "<script>" not in html
        assert "&lt;script&gt;" in html

    def test_empty_state_is_complete_html(self):
        html = _render_contact_notes_empty_state_html(
            contact_id="42", zero_notes=True
        )
        assert html.startswith("<!DOCTYPE html>")
        assert html.rstrip().endswith("</html>")


# ---------------------------------------------------------------------------
# render_contact_notes_html
# ---------------------------------------------------------------------------


class TestRenderHtml:
    def test_none_routes_to_not_available_state(self):
        html = render_contact_notes_html(notes=None, contact_id="42")
        assert "Notes not available" in html

    def test_empty_list_routes_to_no_notes_state(self):
        html = render_contact_notes_html(notes=[], contact_id="42")
        assert "No notes yet" in html

    def test_only_non_dict_entries_routes_to_no_notes(self):
        html = render_contact_notes_html(
            notes=["nope", None, 123], contact_id="42"  # type: ignore[list-item]
        )
        assert "No notes yet" in html

    def test_basic_render_includes_header_and_total(self):
        notes = [_make_note()]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        assert "<!DOCTYPE html>" in html
        assert "1 TOTAL" in html

    def test_label_from_first_last_name(self):
        notes = [_make_note()]
        contact = {"first_name": "Jane", "last_name": "Doe"}
        html = render_contact_notes_html(
            notes=notes, contact_id="42", contact=contact
        )
        assert "Jane Doe" in html

    def test_label_falls_back_to_name(self):
        notes = [_make_note()]
        contact = {"name": "Janie"}
        html = render_contact_notes_html(
            notes=notes, contact_id="42", contact=contact
        )
        assert "Janie" in html

    def test_label_falls_back_to_display_name(self):
        notes = [_make_note()]
        contact = {"display_name": "Display Name"}
        html = render_contact_notes_html(
            notes=notes, contact_id="42", contact=contact
        )
        assert "Display Name" in html

    def test_label_falls_back_to_work_email(self):
        notes = [_make_note()]
        contact = {"work_email": "jane@example.com"}
        html = render_contact_notes_html(
            notes=notes, contact_id="42", contact=contact
        )
        assert "jane@example.com" in html

    def test_label_falls_back_to_email(self):
        notes = [_make_note()]
        contact = {"email": "jane@personal.com"}
        html = render_contact_notes_html(
            notes=notes, contact_id="42", contact=contact
        )
        assert "jane@personal.com" in html

    def test_label_defaults_when_no_contact(self):
        notes = [_make_note()]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        assert "Contact" in html  # default header label

    def test_label_handles_first_only(self):
        notes = [_make_note()]
        contact = {"first_name": "Jane", "last_name": ""}
        html = render_contact_notes_html(
            notes=notes, contact_id="42", contact=contact
        )
        assert "Jane" in html

    def test_total_count_in_badge(self):
        notes = [_make_note() for _ in range(7)]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        assert "7 TOTAL" in html

    def test_unique_authors_stat(self):
        notes = [
            _make_note(created_by_name="Alice"),
            _make_note(created_by_name="Bob"),
            _make_note(created_by_name="Carol"),
        ]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        # Stats grid has Total + Unique authors + Edits + Last note
        # Look for "Unique authors" label and the value 3
        assert "Unique authors" in html
        # Find the value that follows
        assert ">3<" in html

    def test_edit_count_in_stat_grid(self):
        notes = [
            _make_note(
                created_at="2026-04-18T10:00:00Z",
                updated_at="2026-04-18T11:00:00Z",  # edited
            ),
            _make_note(
                created_at="2026-04-17T10:00:00Z",
                updated_at="2026-04-17T10:00:00Z",  # not edited
            ),
        ]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        assert "Edits" in html
        # 1 edit
        assert ">1<" in html

    def test_last_note_timestamp(self):
        notes = [
            _make_note(created_at="2026-04-18T10:00:00Z"),
            _make_note(created_at="2026-04-10T00:00:00Z"),
        ]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        assert "2026-04-18T10:00:00Z" in html

    def test_author_breakdown_section_renders(self):
        notes = [
            _make_note(created_by_name="Alice"),
            _make_note(created_by_name="Alice"),
            _make_note(created_by_name="Bob"),
        ]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        assert "Authors" in html
        assert "Alice" in html
        assert "Bob" in html

    def test_author_count_with_percentage(self):
        # 4 Alice / 1 Bob → Alice 80%, Bob 20%
        notes = (
            [_make_note(created_by_name="Alice") for _ in range(4)]
            + [_make_note(created_by_name="Bob")]
        )
        html = render_contact_notes_html(notes=notes, contact_id="42")
        assert "(80%)" in html
        assert "(20%)" in html

    def test_singular_note_word(self):
        notes = [_make_note(created_by_name="Alice")]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        # "1 note" not "1 notes"
        assert "1 note " in html
        assert "1 notes" not in html

    def test_plural_notes_word(self):
        notes = [_make_note(created_by_name="Alice") for _ in range(3)]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        assert "3 notes" in html

    def test_author_overflow_note(self):
        # 6 unique authors, _MAX_CONTACT_NOTES_AUTHORS_RENDERED = 5
        notes = [
            _make_note(created_by_name=f"User{i}") for i in range(6)
        ]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        assert "+ 1 more author" in html

    def test_author_overflow_plural(self):
        notes = [
            _make_note(created_by_name=f"User{i}") for i in range(8)
        ]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        assert "+ 3 more authors" in html

    def test_no_author_overflow_when_under_max(self):
        notes = [
            _make_note(created_by_name=f"User{i}")
            for i in range(_MAX_CONTACT_NOTES_AUTHORS_RENDERED)
        ]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        assert "more author" not in html

    def test_timeline_section_renders(self):
        notes = [
            _make_note(content="First note", created_at="2026-04-18T10:00:00Z"),
        ]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        assert "Recent notes" in html
        assert "First note" in html

    def test_timeline_overflow_note(self):
        # Create one more than max
        notes = [
            _make_note(id=f"id-{i}", content=f"Note {i}")
            for i in range(_MAX_CONTACT_NOTES_RENDERED + 3)
        ]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        assert "+ 3 older notes" in html

    def test_timeline_overflow_singular(self):
        notes = [
            _make_note(id=f"id-{i}", content=f"Note {i}")
            for i in range(_MAX_CONTACT_NOTES_RENDERED + 1)
        ]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        assert "+ 1 older note" in html
        assert "+ 1 older notes" not in html

    def test_no_timeline_overflow_when_under_max(self):
        notes = [_make_note() for _ in range(5)]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        assert "older note" not in html

    def test_edited_badge_appears_when_updated_differs(self):
        notes = [
            _make_note(
                created_at="2026-04-18T10:00:00Z",
                updated_at="2026-04-18T11:00:00Z",
            )
        ]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        assert "EDITED" in html

    def test_edited_badge_absent_when_updated_matches(self):
        notes = [
            _make_note(
                created_at="2026-04-18T10:00:00Z",
                updated_at="2026-04-18T10:00:00Z",
            )
        ]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        assert "EDITED" not in html

    def test_edited_badge_absent_when_no_updated_at(self):
        notes = [
            _make_note(
                created_at="2026-04-18T10:00:00Z",
                updated_at=None,
            )
        ]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        assert "EDITED" not in html

    def test_drill_up_section_links_to_contact_detail(self):
        notes = [_make_note()]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        assert "g8://contacts/42" in html
        assert "POST /contacts/42/notes" in html

    def test_contact_id_in_header(self):
        notes = [_make_note()]
        html = render_contact_notes_html(notes=notes, contact_id="abc-xyz")
        assert "abc-xyz" in html

    def test_contact_id_escaped_in_header(self):
        notes = [_make_note()]
        html = render_contact_notes_html(
            notes=notes, contact_id="<script>alert(1)</script>"
        )
        assert "<script>alert(1)</script>" not in html
        assert "&lt;script&gt;" in html

    def test_xss_in_note_content(self):
        notes = [_make_note(content="<img src=x onerror=alert(1)>")]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        assert "<img src=x" not in html
        assert "&lt;img src=x" in html

    def test_xss_in_author_name(self):
        notes = [_make_note(created_by_name="<svg/onload=alert(1)>")]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        assert "<svg/onload=" not in html
        assert "&lt;svg" in html

    def test_xss_in_contact_label(self):
        notes = [_make_note()]
        contact = {"first_name": "<script>", "last_name": "Doe"}
        html = render_contact_notes_html(
            notes=notes, contact_id="42", contact=contact
        )
        assert "<script>" not in html

    def test_xss_in_note_id(self):
        notes = [_make_note(id="<svg/onload=alert(1)>")]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        assert "<svg/onload=" not in html

    def test_xss_in_timestamp(self):
        notes = [_make_note(created_at="<script>alert(1)</script>")]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        assert "<script>alert(1)</script>" not in html

    def test_empty_note_id_renders_question_mark(self):
        notes = [_make_note(id=None)]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        assert "id: ?" in html

    def test_missing_timestamp_renders_dash(self):
        notes = [_make_note(created_at=None, updated_at=None)]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        # at least one em-dash should appear in the timeline area
        assert "—" in html

    def test_is_complete_html_document(self):
        notes = [_make_note()]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        assert html.startswith("<!DOCTYPE html>")
        assert html.rstrip().endswith("</html>")

    def test_no_double_escape_on_clip(self):
        # _clip already HTML-escapes; if we doubled it we'd see &amp;lt;
        notes = [_make_note()]
        contact = {"first_name": "<Tag>"}
        html = render_contact_notes_html(
            notes=notes, contact_id="42", contact=contact
        )
        assert "&amp;lt;" not in html
        assert "&lt;Tag&gt;" in html

    def test_long_note_content_clipped(self):
        long_content = "x" * (_MAX_CONTACT_NOTE_CONTENT_LEN + 200)
        notes = [_make_note(content=long_content)]
        html = render_contact_notes_html(notes=notes, contact_id="42")
        assert "…" in html
        # The full long string shouldn't appear verbatim
        assert long_content not in html

    def test_multiple_authors_breakdown_order(self):
        # 3 from Alice, 2 from Bob, 1 from Carol
        notes = (
            [_make_note(created_by_name="Alice") for _ in range(3)]
            + [_make_note(created_by_name="Bob") for _ in range(2)]
            + [_make_note(created_by_name="Carol")]
        )
        html = render_contact_notes_html(notes=notes, contact_id="42")
        # Alice should appear before Bob in the author breakdown section
        # Find first occurrence in author-row blocks
        author_section = html.split("Authors</h2>")[1].split("</section>")[0]
        alice_pos = author_section.find("Alice")
        bob_pos = author_section.find("Bob")
        carol_pos = author_section.find("Carol")
        assert 0 <= alice_pos < bob_pos < carol_pos


# ---------------------------------------------------------------------------
# render_contact_notes_text_fallback
# ---------------------------------------------------------------------------


class TestRenderTextFallback:
    def test_none_returns_not_available(self):
        text = render_contact_notes_text_fallback(notes=None, contact_id="42")
        assert "Notes not available" in text
        assert "Contact id: 42" in text

    def test_empty_returns_no_notes_yet(self):
        text = render_contact_notes_text_fallback(notes=[], contact_id="42")
        assert "No notes yet" in text
        assert "POST /contacts/42/notes" in text

    def test_only_non_dict_returns_no_notes_yet(self):
        text = render_contact_notes_text_fallback(
            notes=["nope", None],  # type: ignore[list-item]
            contact_id="42",
        )
        assert "No notes yet" in text

    def test_basic_render_has_header(self):
        notes = [_make_note(content="Test note")]
        text = render_contact_notes_text_fallback(notes=notes, contact_id="42")
        assert text.startswith("# ")
        assert "notes" in text.lower()

    def test_includes_total_count(self):
        notes = [_make_note() for _ in range(5)]
        text = render_contact_notes_text_fallback(notes=notes, contact_id="42")
        assert "Total notes: 5" in text

    def test_includes_unique_authors(self):
        notes = [
            _make_note(created_by_name="Alice"),
            _make_note(created_by_name="Bob"),
        ]
        text = render_contact_notes_text_fallback(notes=notes, contact_id="42")
        assert "Unique authors: 2" in text

    def test_includes_edit_count(self):
        notes = [
            _make_note(
                created_at="2026-04-18T10:00:00Z",
                updated_at="2026-04-18T11:00:00Z",
            ),
            _make_note(
                created_at="2026-04-17T10:00:00Z",
                updated_at="2026-04-17T10:00:00Z",
            ),
        ]
        text = render_contact_notes_text_fallback(notes=notes, contact_id="42")
        assert "Edits: 1" in text

    def test_label_from_contact(self):
        notes = [_make_note()]
        contact = {"first_name": "Jane", "last_name": "Doe"}
        text = render_contact_notes_text_fallback(
            notes=notes, contact_id="42", contact=contact
        )
        assert "Jane Doe" in text

    def test_authors_section_present(self):
        notes = [
            _make_note(created_by_name="Alice"),
            _make_note(created_by_name="Bob"),
        ]
        text = render_contact_notes_text_fallback(notes=notes, contact_id="42")
        assert "## Authors" in text
        assert "Alice" in text
        assert "Bob" in text

    def test_recent_notes_section_present(self):
        notes = [_make_note(content="First", id="abc")]
        text = render_contact_notes_text_fallback(notes=notes, contact_id="42")
        assert "## Recent notes" in text
        assert "First" in text
        assert "id=abc" in text

    def test_edited_tag_in_recent_notes(self):
        notes = [
            _make_note(
                created_at="2026-04-18T10:00:00Z",
                updated_at="2026-04-18T11:00:00Z",
            )
        ]
        text = render_contact_notes_text_fallback(notes=notes, contact_id="42")
        assert "(edited)" in text

    def test_drill_up_section(self):
        notes = [_make_note()]
        text = render_contact_notes_text_fallback(notes=notes, contact_id="42")
        assert "g8://contacts/42" in text
        assert "POST /contacts/42/notes" in text

    def test_timeline_overflow_message(self):
        notes = [
            _make_note(id=f"id-{i}", content=f"Note {i}")
            for i in range(_MAX_CONTACT_NOTES_RENDERED + 5)
        ]
        text = render_contact_notes_text_fallback(notes=notes, contact_id="42")
        assert "+ 5 older notes" in text

    def test_author_overflow_message(self):
        notes = [_make_note(created_by_name=f"U{i}") for i in range(7)]
        text = render_contact_notes_text_fallback(notes=notes, contact_id="42")
        assert "+ 2 more authors" in text

    def test_newlines_in_content_collapsed_to_arrow(self):
        notes = [_make_note(content="line1\nline2")]
        text = render_contact_notes_text_fallback(notes=notes, contact_id="42")
        assert "line1 ⏎ line2" in text

    def test_ends_with_newline(self):
        notes = [_make_note()]
        text = render_contact_notes_text_fallback(notes=notes, contact_id="42")
        assert text.endswith("\n")

    def test_handles_empty_contact_id(self):
        text = render_contact_notes_text_fallback(notes=None, contact_id="")
        assert "(unknown)" in text

    def test_no_html_tags_in_text(self):
        notes = [_make_note(content="<b>bold</b>")]
        text = render_contact_notes_text_fallback(notes=notes, contact_id="42")
        # Plain text should preserve the literal tags (not escape them);
        # but no opening HTML doctype/structure
        assert not re.search(r"</?(html|head|body|div|span|h1|h2)[^>]*>", text)
