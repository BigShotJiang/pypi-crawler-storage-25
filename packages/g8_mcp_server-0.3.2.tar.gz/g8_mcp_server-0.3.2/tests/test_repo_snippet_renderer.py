"""Unit tests for Surface #56 — per-repo tracking snippet renderer.

Covers the helpers + HTML / text renderers in
``g8_mcp_server.app_renderer`` for the per-repo tracking snippet surface.
Regression locks:
- No single-side colored accent borders (AI-tell).
- No legacy accent hexes (enforces graph8 design-token refactor).
- Drill-up card does NOT self-reference
  ``g8://repos/{repo_id}/snippet``.
- Write-key preview never leaks the full secret into HTML (always clipped
  to first 16 chars + ellipsis).
"""
from __future__ import annotations

import pytest

from g8_mcp_server.app_renderer import (
    _MAX_REPO_SNIPPET_DOMAIN_CHIPS,
    _MAX_REPO_SNIPPET_DOMAIN_LEN,
    _MAX_REPO_SNIPPET_HOST_LEN,
    _MAX_REPO_SNIPPET_REACT_LEN,
    _MAX_REPO_SNIPPET_SCRIPT_TAG_LEN,
    _MAX_REPO_SNIPPET_WRITE_KEY_LEN,
    _render_repo_snippet_empty_state_html,
    _repo_snippet_clip,
    _repo_snippet_code_block,
    _repo_snippet_domains_list,
    _repo_snippet_repo_label,
    _repo_snippet_stat_card,
    _repo_snippet_status,
    _repo_snippet_write_key_display,
    render_repo_snippet_html,
    render_repo_snippet_text_fallback,
)


REPO_ID = "repo-abc-123"
WRITE_KEY = "wk_live_0123456789abcdef_ignored_tail"
TRACKING_HOST = "https://t.graph8.com"
SAMPLE_SNIPPET = {
    "write_key": WRITE_KEY,
    "tracking_host": TRACKING_HOST,
    "domains": ["app.acme.com", "www.acme.com", "docs.acme.com"],
    "script_tag": (
        '<script src="https://t.graph8.com/p.js" '
        'data-write-key="wk_live_0123456789abcdef_ignored_tail" '
        'data-tracking-host="https://t.graph8.com" defer></script>'
    ),
    "react_snippet": (
        "import Script from \"next/script\";\n\n"
        "export function Graph8Analytics() {\n"
        "  return (\n"
        "    <Script\n"
        "      src=\"https://t.graph8.com/p.js\"\n"
        "      data-write-key=\"wk_live_0123456789abcdef_ignored_tail\"\n"
        "      data-tracking-host=\"https://t.graph8.com\"\n"
        "      strategy=\"afterInteractive\"\n"
        "    />\n"
        "  );\n"
        "}\n"
    ),
    "config": {
        "write_key": WRITE_KEY,
        "tracking_host": TRACKING_HOST,
        "domains": ["app.acme.com", "www.acme.com", "docs.acme.com"],
    },
}
SAMPLE_REPO = {
    "id": REPO_ID,
    "name": "acme-website",
    "slug": "acme/acme-website",
    "full_name": "acme/acme-website",
}


# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------


class TestClip:
    def test_none(self):
        assert _repo_snippet_clip(None, 10) == ""

    def test_empty_str(self):
        assert _repo_snippet_clip("", 10) == ""

    def test_whitespace(self):
        assert _repo_snippet_clip("   ", 10) == ""

    def test_short(self):
        assert _repo_snippet_clip("abc", 10) == "abc"

    def test_long(self):
        assert _repo_snippet_clip("a" * 100, 10) == "a" * 9 + "…"

    def test_non_str(self):
        assert _repo_snippet_clip(42, 10) == "42"


class TestWriteKeyDisplay:
    def test_empty(self):
        assert _repo_snippet_write_key_display("") == ""

    def test_none(self):
        assert _repo_snippet_write_key_display(None) == ""

    def test_non_str(self):
        assert _repo_snippet_write_key_display(42) == ""

    def test_short(self):
        assert _repo_snippet_write_key_display("wk_123") == "wk_123"

    def test_exactly_16(self):
        key = "a" * 16
        assert _repo_snippet_write_key_display(key) == key

    def test_17(self):
        key = "a" * 17
        assert _repo_snippet_write_key_display(key) == "a" * 16 + "…"

    def test_live_key_clipped(self):
        preview = _repo_snippet_write_key_display(WRITE_KEY)
        # 16 chars + ellipsis
        assert preview == "wk_live_01234567" + "…"

    def test_full_key_never_leaks(self):
        preview = _repo_snippet_write_key_display(WRITE_KEY)
        assert WRITE_KEY not in preview
        assert "ignored_tail" not in preview


class TestDomainsList:
    def test_empty(self):
        assert _repo_snippet_domains_list([]) == []

    def test_non_list(self):
        assert _repo_snippet_domains_list("app.acme.com") == []

    def test_none(self):
        assert _repo_snippet_domains_list(None) == []

    def test_dedupes_preserving_order(self):
        assert _repo_snippet_domains_list(
            ["b.com", "a.com", "b.com", "c.com", "a.com"]
        ) == ["b.com", "a.com", "c.com"]

    def test_strips_whitespace(self):
        assert _repo_snippet_domains_list(["  a.com  ", "b.com"]) == [
            "a.com",
            "b.com",
        ]

    def test_drops_non_strings(self):
        assert _repo_snippet_domains_list(["a.com", 42, None, "b.com"]) == [
            "a.com",
            "b.com",
        ]

    def test_drops_empty_strings(self):
        assert _repo_snippet_domains_list(["a.com", "", "   ", "b.com"]) == [
            "a.com",
            "b.com",
        ]


class TestStatus:
    def test_none(self):
        bg, fg, label = _repo_snippet_status(None)
        assert label == "MISSING"
        assert fg == "#ca3214"

    def test_non_dict(self):
        bg, fg, label = _repo_snippet_status("oops")
        assert label == "MISSING"

    def test_missing_write_key(self):
        bg, fg, label = _repo_snippet_status({"tracking_host": "x"})
        assert label == "MISSING"

    def test_empty_write_key(self):
        bg, fg, label = _repo_snippet_status({"write_key": "   "})
        assert label == "MISSING"

    def test_ready(self):
        bg, fg, label = _repo_snippet_status({"write_key": "wk_123"})
        assert label == "READY"
        assert fg == "#059669"


class TestRepoLabel:
    def test_none_repo(self):
        assert _repo_snippet_repo_label(None, REPO_ID) == REPO_ID

    def test_non_dict_repo(self):
        assert _repo_snippet_repo_label("oops", REPO_ID) == REPO_ID

    def test_prefers_name(self):
        assert _repo_snippet_repo_label(
            {"name": "acme", "full_name": "a/b", "slug": "x"}, REPO_ID
        ) == "acme"

    def test_falls_back_to_full_name(self):
        assert _repo_snippet_repo_label(
            {"full_name": "a/b", "slug": "x"}, REPO_ID
        ) == "a/b"

    def test_falls_back_to_slug(self):
        assert _repo_snippet_repo_label({"slug": "x"}, REPO_ID) == "x"

    def test_empty_name_falls_through(self):
        assert _repo_snippet_repo_label(
            {"name": "", "full_name": "", "slug": "x"}, REPO_ID
        ) == "x"

    def test_all_empty_uses_repo_id(self):
        assert _repo_snippet_repo_label(
            {"name": "", "full_name": "", "slug": ""}, REPO_ID
        ) == REPO_ID


class TestStatCard:
    def test_default_accent(self):
        out = _repo_snippet_stat_card("Write key", "wk_x")
        assert "Write key" in out
        assert "wk_x" in out

    def test_primary_accent(self):
        out = _repo_snippet_stat_card("X", "y", accent="primary")
        assert "#7d2df3" in out

    def test_positive_accent(self):
        out = _repo_snippet_stat_card("X", "y", accent="positive")
        assert "#059669" in out

    def test_uniform_border(self):
        out = _repo_snippet_stat_card("X", "y")
        # Four-sided border, not single-side colored accent.
        assert "border:1px solid #dfdfdf" in out

    def test_no_single_side_colored_accent_border(self):
        # Regression lock — single-side colored borders are an AI-tell.
        out = _repo_snippet_stat_card("X", "y", accent="primary")
        for side in ("border-left", "border-right", "border-top", "border-bottom"):
            assert f"{side}:" not in out

    def test_escapes_label(self):
        out = _repo_snippet_stat_card("<X>", "<y>")
        assert "&lt;X&gt;" in out
        assert "&lt;y&gt;" in out


class TestCodeBlock:
    def test_empty(self):
        code, overflow = _repo_snippet_code_block("", 100)
        assert code == ""
        assert overflow is False

    def test_non_str(self):
        code, overflow = _repo_snippet_code_block(None, 100)
        assert code == ""
        assert overflow is False

    def test_short(self):
        code, overflow = _repo_snippet_code_block("abc", 100)
        assert code == "abc"
        assert overflow is False

    def test_escapes(self):
        code, overflow = _repo_snippet_code_block("<b>x</b>", 100)
        assert code == "&lt;b&gt;x&lt;/b&gt;"
        assert overflow is False

    def test_overflow(self):
        source = "a" * 200
        code, overflow = _repo_snippet_code_block(source, 100)
        assert overflow is True
        assert code.endswith("…")
        assert len(code) <= 100

    def test_exactly_cap(self):
        source = "a" * 100
        code, overflow = _repo_snippet_code_block(source, 100)
        assert overflow is False


class TestEmptyState:
    def test_no_write_key(self):
        out = _render_repo_snippet_empty_state_html(REPO_ID, "no_write_key")
        assert "No write key configured" in out
        assert "/streams" in out
        assert "/install" in out
        assert "#7d2df3" in out  # primary tint

    def test_not_found(self):
        out = _render_repo_snippet_empty_state_html(REPO_ID, "not_found")
        assert "Repo not found" in out
        assert "g8://repos/dashboard" in out

    def test_unavailable(self):
        out = _render_repo_snippet_empty_state_html(REPO_ID, "unavailable")
        assert "not available" in out or "unavailable" in out.lower()

    def test_unknown_mode_falls_through_to_unavailable(self):
        out = _render_repo_snippet_empty_state_html(REPO_ID, "what")
        assert "not available" in out or "unavailable" in out.lower()

    def test_escapes_repo_id(self):
        out = _render_repo_snippet_empty_state_html(
            "<script>alert(1)</script>", "no_write_key"
        )
        assert "<script>alert(1)</script>" not in out
        assert "&lt;script&gt;" in out


# ----------------------------------------------------------------------
# HTML renderer
# ----------------------------------------------------------------------


class TestRenderHtml:
    def test_happy_path(self):
        out = render_repo_snippet_html(
            repo_id=REPO_ID, snippet=SAMPLE_SNIPPET, repo=SAMPLE_REPO
        )
        assert "Repo snippet" in out
        assert "acme-website" in out
        assert "READY" in out

    def test_none_snippet_empty_state(self):
        out = render_repo_snippet_html(repo_id=REPO_ID, snippet=None)
        assert "not available" in out

    def test_non_dict_snippet_empty_state(self):
        out = render_repo_snippet_html(repo_id=REPO_ID, snippet="oops")
        assert "not available" in out

    def test_missing_write_key_empty_state(self):
        out = render_repo_snippet_html(
            repo_id=REPO_ID, snippet={"tracking_host": TRACKING_HOST}
        )
        assert "No write key configured" in out

    def test_empty_write_key_empty_state(self):
        out = render_repo_snippet_html(
            repo_id=REPO_ID, snippet={"write_key": "   "}
        )
        assert "No write key configured" in out

    def test_write_key_never_leaks_in_full(self):
        out = render_repo_snippet_html(
            repo_id=REPO_ID, snippet=SAMPLE_SNIPPET, repo=SAMPLE_REPO
        )
        # The preview is "wk_live_01234567…" — full key should NOT appear
        # in the header or stat cards (but it's expected inside the raw
        # script_tag / react_snippet which get escaped in <pre>).
        # Assert: first stat-card row only shows the clipped preview.
        assert "wk_live_01234567…" in out

    def test_host_rendered(self):
        out = render_repo_snippet_html(
            repo_id=REPO_ID, snippet=SAMPLE_SNIPPET, repo=SAMPLE_REPO
        )
        assert "https://t.graph8.com" in out

    def test_domain_count(self):
        out = render_repo_snippet_html(
            repo_id=REPO_ID, snippet=SAMPLE_SNIPPET, repo=SAMPLE_REPO
        )
        assert "Authorized domains (3)" in out

    def test_domain_chips_rendered(self):
        out = render_repo_snippet_html(
            repo_id=REPO_ID, snippet=SAMPLE_SNIPPET, repo=SAMPLE_REPO
        )
        for d in ("app.acme.com", "www.acme.com", "docs.acme.com"):
            assert d in out

    def test_no_domain_card_when_empty(self):
        snippet = dict(SAMPLE_SNIPPET)
        snippet["domains"] = []
        out = render_repo_snippet_html(
            repo_id=REPO_ID, snippet=snippet, repo=SAMPLE_REPO
        )
        assert "Authorized domains" not in out

    def test_domain_overflow(self):
        snippet = dict(SAMPLE_SNIPPET)
        snippet["domains"] = [f"d{i}.example.com" for i in range(30)]
        out = render_repo_snippet_html(
            repo_id=REPO_ID, snippet=snippet, repo=SAMPLE_REPO
        )
        overflow = 30 - _MAX_REPO_SNIPPET_DOMAIN_CHIPS
        assert f"+ {overflow} more domains" in out

    def test_script_tag_rendered(self):
        out = render_repo_snippet_html(
            repo_id=REPO_ID, snippet=SAMPLE_SNIPPET, repo=SAMPLE_REPO
        )
        assert "Script tag" in out
        # Escaped
        assert "&lt;script" in out

    def test_no_script_card_when_missing(self):
        snippet = dict(SAMPLE_SNIPPET)
        snippet["script_tag"] = ""
        out = render_repo_snippet_html(
            repo_id=REPO_ID, snippet=snippet, repo=SAMPLE_REPO
        )
        assert "Script tag (vanilla HTML)" not in out

    def test_script_tag_overflow(self):
        snippet = dict(SAMPLE_SNIPPET)
        snippet["script_tag"] = "x" * 2000
        out = render_repo_snippet_html(
            repo_id=REPO_ID, snippet=snippet, repo=SAMPLE_REPO
        )
        assert "Preview truncated" in out

    def test_react_rendered(self):
        out = render_repo_snippet_html(
            repo_id=REPO_ID, snippet=SAMPLE_SNIPPET, repo=SAMPLE_REPO
        )
        assert "React / Next.js component" in out
        assert "Graph8Analytics" in out

    def test_no_react_card_when_missing(self):
        snippet = dict(SAMPLE_SNIPPET)
        snippet["react_snippet"] = ""
        out = render_repo_snippet_html(
            repo_id=REPO_ID, snippet=snippet, repo=SAMPLE_REPO
        )
        assert "React / Next.js component" not in out

    def test_react_overflow(self):
        snippet = dict(SAMPLE_SNIPPET)
        snippet["react_snippet"] = "y" * (_MAX_REPO_SNIPPET_REACT_LEN + 100)
        out = render_repo_snippet_html(
            repo_id=REPO_ID, snippet=snippet, repo=SAMPLE_REPO
        )
        assert "Preview truncated" in out

    def test_drill_up_rendered(self):
        out = render_repo_snippet_html(
            repo_id=REPO_ID, snippet=SAMPLE_SNIPPET, repo=SAMPLE_REPO
        )
        assert "Manage this repo" in out
        for link in (
            f"g8://repos/{REPO_ID}/overview",
            f"g8://repos/{REPO_ID}/install",
            f"g8://repos/{REPO_ID}/streams",
            f"g8://repos/{REPO_ID}/scan",
            "g8://snippet/install",
            "g8://repos/dashboard",
        ):
            assert link in out

    def test_drill_up_does_NOT_list_self(self):
        # Regression lock: drill-up must not self-reference.
        out = render_repo_snippet_html(
            repo_id=REPO_ID, snippet=SAMPLE_SNIPPET, repo=SAMPLE_REPO
        )
        # The surface URI is g8://repos/{id}/snippet. Make sure the
        # drill-up section (everything after "Manage this repo") doesn't
        # include it as a bullet. The URI may appear elsewhere (header,
        # summary), just not as a self-link.
        manage_idx = out.find("Manage this repo")
        assert manage_idx > -1
        drill_up = out[manage_idx:]
        # The drill-up should NOT include the current surface's URI.
        assert f"g8://repos/{REPO_ID}/snippet</code>" not in drill_up

    def test_repo_id_escaped(self):
        out = render_repo_snippet_html(
            repo_id="<script>alert(1)</script>",
            snippet=SAMPLE_SNIPPET,
            repo=None,
        )
        assert "<script>alert(1)</script>" not in out
        assert "&lt;script&gt;" in out

    def test_repo_label_escaped(self):
        out = render_repo_snippet_html(
            repo_id=REPO_ID,
            snippet=SAMPLE_SNIPPET,
            repo={"name": "<b>x</b>"},
        )
        assert "<b>x</b>" not in out
        assert "&lt;b&gt;x&lt;/b&gt;" in out

    def test_domain_xss_escaped(self):
        snippet = dict(SAMPLE_SNIPPET)
        snippet["domains"] = ["<img onerror=alert(1)>"]
        out = render_repo_snippet_html(
            repo_id=REPO_ID, snippet=snippet, repo=SAMPLE_REPO
        )
        assert "<img onerror" not in out
        assert "&lt;img" in out

    def test_no_single_side_accent_borders(self):
        # Regression lock: no single-side colored accent borders
        # anywhere on the happy path.
        out = render_repo_snippet_html(
            repo_id=REPO_ID, snippet=SAMPLE_SNIPPET, repo=SAMPLE_REPO
        )
        for side in ("border-left", "border-right", "border-top", "border-bottom"):
            # Allow `border-radius`, forbid solo side borders.
            # Spot-check the specific colored-accent pattern.
            assert f"{side}:3px solid" not in out
            assert f"{side}:4px solid" not in out

    def test_no_legacy_accent_hexes(self):
        # Regression lock: legacy sky-blue / zinc accents from pre-graph8
        # design tokens.
        out = render_repo_snippet_html(
            repo_id=REPO_ID, snippet=SAMPLE_SNIPPET, repo=SAMPLE_REPO
        )
        for legacy in ("#0ea5e9", "#38bdf8", "#2563eb", "#1d4ed8"):
            assert legacy not in out

    def test_uses_graph8_primary_color(self):
        out = render_repo_snippet_html(
            repo_id=REPO_ID, snippet=SAMPLE_SNIPPET, repo=SAMPLE_REPO
        )
        assert "#7d2df3" in out

    def test_uses_aeonik_font(self):
        out = render_repo_snippet_html(
            repo_id=REPO_ID, snippet=SAMPLE_SNIPPET, repo=SAMPLE_REPO
        )
        assert "Aeonik" in out

    def test_no_trailing_bullet_self_reference_in_empty_states(self):
        # Even empty states should not self-reference the snippet surface.
        for mode in ("no_write_key", "not_found", "unavailable"):
            out = _render_repo_snippet_empty_state_html(REPO_ID, mode)
            # Self reference only allowed in the drill-up body text of
            # the no_write_key branch (as a GET endpoint mention). But
            # the bullet-style `g8://repos/{id}/snippet` link should
            # not appear.
            assert f"g8://repos/{REPO_ID}/snippet</code>" not in out

    def test_empty_domains_list_still_renders(self):
        snippet = {
            "write_key": WRITE_KEY,
            "tracking_host": TRACKING_HOST,
            "domains": [],
            "script_tag": SAMPLE_SNIPPET["script_tag"],
            "react_snippet": SAMPLE_SNIPPET["react_snippet"],
        }
        out = render_repo_snippet_html(
            repo_id=REPO_ID, snippet=snippet, repo=SAMPLE_REPO
        )
        assert "Authorized domains" not in out
        # Stat card still shows 0 domains.
        assert "Domains" in out

    def test_missing_tracking_host_renders_unknown(self):
        snippet = {
            "write_key": WRITE_KEY,
            "tracking_host": "",
            "domains": [],
        }
        out = render_repo_snippet_html(
            repo_id=REPO_ID, snippet=snippet, repo=SAMPLE_REPO
        )
        assert "(unknown)" in out


# ----------------------------------------------------------------------
# Text fallback
# ----------------------------------------------------------------------


class TestTextFallback:
    def test_happy_path(self):
        out = render_repo_snippet_text_fallback(
            repo_id=REPO_ID, snippet=SAMPLE_SNIPPET, repo=SAMPLE_REPO
        )
        assert "# Repo snippet — acme-website" in out
        assert "Write key: `wk_live_01234567…`" in out
        assert "Tracking host: `https://t.graph8.com`" in out
        assert "Domains: 3" in out

    def test_none_snippet(self):
        out = render_repo_snippet_text_fallback(
            repo_id=REPO_ID, snippet=None
        )
        assert "not available" in out
        assert "Manage this repo" in out

    def test_non_dict_snippet(self):
        out = render_repo_snippet_text_fallback(
            repo_id=REPO_ID, snippet="oops"
        )
        assert "not available" in out

    def test_missing_write_key(self):
        out = render_repo_snippet_text_fallback(
            repo_id=REPO_ID, snippet={"tracking_host": TRACKING_HOST}
        )
        assert "No write key configured" in out
        assert f"g8://repos/{REPO_ID}/streams" in out
        assert f"g8://repos/{REPO_ID}/install" in out

    def test_domains_rendered(self):
        out = render_repo_snippet_text_fallback(
            repo_id=REPO_ID, snippet=SAMPLE_SNIPPET, repo=SAMPLE_REPO
        )
        for d in ("app.acme.com", "www.acme.com", "docs.acme.com"):
            assert f"- `{d}`" in out

    def test_domain_overflow_summary(self):
        snippet = dict(SAMPLE_SNIPPET)
        snippet["domains"] = [f"d{i}.example.com" for i in range(30)]
        out = render_repo_snippet_text_fallback(
            repo_id=REPO_ID, snippet=snippet, repo=SAMPLE_REPO
        )
        overflow = 30 - _MAX_REPO_SNIPPET_DOMAIN_CHIPS
        assert f"+ {overflow} more domain" in out

    def test_script_block_rendered(self):
        out = render_repo_snippet_text_fallback(
            repo_id=REPO_ID, snippet=SAMPLE_SNIPPET, repo=SAMPLE_REPO
        )
        assert "## Script tag (vanilla HTML)" in out
        assert "```html" in out

    def test_script_block_omitted_when_empty(self):
        snippet = dict(SAMPLE_SNIPPET)
        snippet["script_tag"] = ""
        out = render_repo_snippet_text_fallback(
            repo_id=REPO_ID, snippet=snippet, repo=SAMPLE_REPO
        )
        assert "## Script tag" not in out

    def test_react_block_rendered(self):
        out = render_repo_snippet_text_fallback(
            repo_id=REPO_ID, snippet=SAMPLE_SNIPPET, repo=SAMPLE_REPO
        )
        assert "## React / Next.js component" in out
        assert "```tsx" in out

    def test_react_block_omitted_when_empty(self):
        snippet = dict(SAMPLE_SNIPPET)
        snippet["react_snippet"] = ""
        out = render_repo_snippet_text_fallback(
            repo_id=REPO_ID, snippet=snippet, repo=SAMPLE_REPO
        )
        assert "## React / Next.js component" not in out

    def test_drill_up(self):
        out = render_repo_snippet_text_fallback(
            repo_id=REPO_ID, snippet=SAMPLE_SNIPPET, repo=SAMPLE_REPO
        )
        assert "## Manage this repo" in out
        for link in (
            f"g8://repos/{REPO_ID}/overview",
            f"g8://repos/{REPO_ID}/install",
            f"g8://repos/{REPO_ID}/streams",
            f"g8://repos/{REPO_ID}/scan",
            "g8://snippet/install",
            "g8://repos/dashboard",
            "g8_get_tracking_snippet",
        ):
            assert link in out

    def test_drill_up_does_NOT_list_self(self):
        out = render_repo_snippet_text_fallback(
            repo_id=REPO_ID, snippet=SAMPLE_SNIPPET, repo=SAMPLE_REPO
        )
        manage_idx = out.find("## Manage this repo")
        assert manage_idx > -1
        drill_up = out[manage_idx:]
        assert f"- g8://repos/{REPO_ID}/snippet" not in drill_up
        # The raw GET /repos/{id}/snippet endpoint IS expected in the
        # drill-up.
        assert f"GET /repos/{REPO_ID}/snippet" in drill_up

    def test_overflow_script_tag_clipped(self):
        snippet = dict(SAMPLE_SNIPPET)
        snippet["script_tag"] = "x" * (_MAX_REPO_SNIPPET_SCRIPT_TAG_LEN + 100)
        out = render_repo_snippet_text_fallback(
            repo_id=REPO_ID, snippet=snippet, repo=SAMPLE_REPO
        )
        # The ellipsis should appear inside the script tag block.
        assert "…" in out

    def test_overflow_react_clipped(self):
        snippet = dict(SAMPLE_SNIPPET)
        snippet["react_snippet"] = "y" * (_MAX_REPO_SNIPPET_REACT_LEN + 100)
        out = render_repo_snippet_text_fallback(
            repo_id=REPO_ID, snippet=snippet, repo=SAMPLE_REPO
        )
        assert "…" in out

    def test_missing_tracking_host_unknown(self):
        snippet = {
            "write_key": WRITE_KEY,
            "tracking_host": "",
            "domains": [],
        }
        out = render_repo_snippet_text_fallback(
            repo_id=REPO_ID, snippet=snippet, repo=SAMPLE_REPO
        )
        assert "Tracking host: `(unknown)`" in out

    def test_domain_count_zero_no_domain_section(self):
        snippet = dict(SAMPLE_SNIPPET)
        snippet["domains"] = []
        out = render_repo_snippet_text_fallback(
            repo_id=REPO_ID, snippet=snippet, repo=SAMPLE_REPO
        )
        assert "## Authorized domains" not in out
        assert "Domains: 0" in out

    def test_trailing_newline(self):
        out = render_repo_snippet_text_fallback(
            repo_id=REPO_ID, snippet=SAMPLE_SNIPPET, repo=SAMPLE_REPO
        )
        assert out.endswith("\n")


# ----------------------------------------------------------------------
# Smoke
# ----------------------------------------------------------------------


class TestSmoke:
    def test_constants(self):
        assert _MAX_REPO_SNIPPET_WRITE_KEY_LEN == 80
        assert _MAX_REPO_SNIPPET_HOST_LEN == 120
        assert _MAX_REPO_SNIPPET_DOMAIN_LEN == 80
        assert _MAX_REPO_SNIPPET_SCRIPT_TAG_LEN == 800
        assert _MAX_REPO_SNIPPET_REACT_LEN == 2400
        assert _MAX_REPO_SNIPPET_DOMAIN_CHIPS == 12

    def test_html_is_well_formed_enough(self):
        out = render_repo_snippet_html(
            repo_id=REPO_ID, snippet=SAMPLE_SNIPPET, repo=SAMPLE_REPO
        )
        assert out.startswith("<!DOCTYPE html>")
        assert out.endswith("</html>")
        # Balanced primary wrapper.
        assert out.count("<body") == 1
        assert out.count("</body>") == 1

    def test_text_is_valid_markdown_enough(self):
        out = render_repo_snippet_text_fallback(
            repo_id=REPO_ID, snippet=SAMPLE_SNIPPET, repo=SAMPLE_REPO
        )
        # Heading order: h1 → h2 sections.
        assert out.startswith("# ")
        # Script tags only allowed inside fenced code blocks (the
        # whole point of this surface is to display a script tag!).
        # Strip code fences and verify the "bare" markdown is clean.
        import re

        bare = re.sub(r"```.*?```", "", out, flags=re.DOTALL)
        assert "<script" not in bare
        assert "<b>" not in bare
