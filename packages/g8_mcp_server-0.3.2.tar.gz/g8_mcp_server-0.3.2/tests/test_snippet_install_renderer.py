"""Unit tests for HTML app surface #52 — tracking snippet install guide.

Covers:
  - _snippet_install_clip: empty/whitespace/clip/escape
  - _snippet_install_write_key_display: short/long preview
  - _snippet_install_domains_list / _snippet_install_fields_list
  - _snippet_install_snippet_status / _snippet_install_form_status
  - _snippet_install_stat_card: uniform border + accent palette
  - _snippet_install_code_block: clip + escape + overflow
  - _render_snippet_install_empty_state_html: 2 modes
  - render_snippet_install_html: full rendering paths
  - render_snippet_install_text_fallback
  - smoke tests with realistic data
  - regression locks: no single-side accent borders, no legacy hexes,
    drill-up does NOT list self, manage block does NOT list self.
"""

from __future__ import annotations

import pytest

from g8_mcp_server.app_renderer import (
    _G8_ACCENT_BG,
    _G8_BORDER,
    _G8_CARD_BG,
    _G8_MUTED_BG,
    _G8_PRIMARY,
    _G8_TEXT,
    _G8_TEXT_MUTED,
    _MAX_SNIPPET_DOMAIN_CHIPS,
    _MAX_SNIPPET_DOMAIN_LEN,
    _MAX_SNIPPET_FIELD_CHIPS,
    _MAX_SNIPPET_FORM_LEN,
    _MAX_SNIPPET_HOST_LEN,
    _MAX_SNIPPET_NOTES_LEN,
    _MAX_SNIPPET_REACT_LEN,
    _MAX_SNIPPET_SCRIPT_TAG_LEN,
    _MAX_SNIPPET_WRITE_KEY_LEN,
    _render_snippet_install_empty_state_html,
    _snippet_install_clip,
    _snippet_install_code_block,
    _snippet_install_domains_list,
    _snippet_install_fields_list,
    _snippet_install_form_status,
    _snippet_install_snippet_status,
    _snippet_install_stat_card,
    _snippet_install_write_key_display,
    render_snippet_install_html,
    render_snippet_install_text_fallback,
)


# ==================================================================== #
# _snippet_install_clip                                                #
# ==================================================================== #


class TestClip:
    def test_none_returns_empty(self):
        assert _snippet_install_clip(None, 10) == ""

    def test_empty_returns_empty(self):
        assert _snippet_install_clip("", 10) == ""

    def test_whitespace_returns_empty(self):
        assert _snippet_install_clip("   ", 10) == ""

    def test_non_string_stringified(self):
        assert _snippet_install_clip(42, 10) == "42"

    def test_short_unchanged(self):
        assert _snippet_install_clip("hello", 10) == "hello"

    def test_long_truncated(self):
        assert _snippet_install_clip("hello world long", 10) == "hello wor…"

    def test_strips_outer_whitespace(self):
        assert _snippet_install_clip("  hi  ", 10) == "hi"


# ==================================================================== #
# _snippet_install_write_key_display                                  #
# ==================================================================== #


class TestWriteKeyDisplay:
    def test_empty_returns_empty(self):
        assert _snippet_install_write_key_display("") == ""

    def test_none_returns_empty(self):
        assert _snippet_install_write_key_display(None) == ""

    def test_non_string_returns_empty(self):
        assert _snippet_install_write_key_display(123) == ""

    def test_short_key_shown_full(self):
        assert _snippet_install_write_key_display("abc123") == "abc123"

    def test_exactly_16_shown_full(self):
        assert _snippet_install_write_key_display("1234567890abcdef") == "1234567890abcdef"

    def test_long_key_truncated_with_ellipsis(self):
        assert (
            _snippet_install_write_key_display("1234567890abcdef1234")
            == "1234567890abcdef…"
        )

    def test_strips_whitespace(self):
        assert _snippet_install_write_key_display("  short  ") == "short"


# ==================================================================== #
# _snippet_install_domains_list / _snippet_install_fields_list         #
# ==================================================================== #


class TestDomainsList:
    def test_empty_returns_empty(self):
        assert _snippet_install_domains_list([]) == []

    def test_none_returns_empty(self):
        assert _snippet_install_domains_list(None) == []

    def test_non_list_returns_empty(self):
        assert _snippet_install_domains_list("example.com") == []

    def test_strings_returned_in_order(self):
        assert _snippet_install_domains_list(["a.com", "b.com"]) == ["a.com", "b.com"]

    def test_dedupes(self):
        assert _snippet_install_domains_list(["a.com", "b.com", "a.com"]) == ["a.com", "b.com"]

    def test_strips_whitespace(self):
        assert _snippet_install_domains_list(["  a.com  ", "b.com"]) == ["a.com", "b.com"]

    def test_ignores_non_strings(self):
        assert _snippet_install_domains_list([42, "a.com", None]) == ["a.com"]

    def test_ignores_empty_after_strip(self):
        assert _snippet_install_domains_list([" ", "a.com", ""]) == ["a.com"]


class TestFieldsList:
    def test_empty_returns_empty(self):
        assert _snippet_install_fields_list([]) == []

    def test_none_returns_empty(self):
        assert _snippet_install_fields_list(None) == []

    def test_returns_strings(self):
        assert _snippet_install_fields_list(["name", "email"]) == ["name", "email"]

    def test_dedupes(self):
        assert _snippet_install_fields_list(["name", "email", "name"]) == ["name", "email"]

    def test_ignores_non_strings(self):
        assert _snippet_install_fields_list(["name", 42]) == ["name"]


# ==================================================================== #
# _snippet_install_snippet_status                                      #
# ==================================================================== #


class TestSnippetStatus:
    def test_ready_when_write_key_present(self):
        bg, fg, label = _snippet_install_snippet_status({"write_key": "abc"})
        assert label == "READY"
        assert fg == "#059669"

    def test_missing_when_dict_empty(self):
        bg, fg, label = _snippet_install_snippet_status({})
        assert label == "MISSING"
        assert fg == "#ca3214"

    def test_missing_when_write_key_empty(self):
        _, _, label = _snippet_install_snippet_status({"write_key": ""})
        assert label == "MISSING"

    def test_missing_when_write_key_whitespace(self):
        _, _, label = _snippet_install_snippet_status({"write_key": "   "})
        assert label == "MISSING"

    def test_missing_when_none(self):
        _, _, label = _snippet_install_snippet_status(None)
        assert label == "MISSING"

    def test_missing_when_non_dict(self):
        _, _, label = _snippet_install_snippet_status("snippet")
        assert label == "MISSING"


# ==================================================================== #
# _snippet_install_form_status                                         #
# ==================================================================== #


class TestFormStatus:
    def test_ready_when_html_present(self):
        bg, fg, label = _snippet_install_form_status({"html": "<form></form>"})
        assert label == "READY"
        assert fg == "#059669"

    def test_offline_when_dict_empty(self):
        _, _, label = _snippet_install_form_status({})
        assert label == "OFFLINE"

    def test_offline_when_html_empty(self):
        _, _, label = _snippet_install_form_status({"html": ""})
        assert label == "OFFLINE"

    def test_offline_when_none(self):
        _, _, label = _snippet_install_form_status(None)
        assert label == "OFFLINE"

    def test_offline_when_non_dict(self):
        _, _, label = _snippet_install_form_status("form")
        assert label == "OFFLINE"


# ==================================================================== #
# _snippet_install_stat_card                                          #
# ==================================================================== #


class TestStatCard:
    def test_uniform_border(self):
        card = _snippet_install_stat_card("Label", "42")
        assert f"border:1px solid {_G8_BORDER}" in card

    def test_primary_accent(self):
        card = _snippet_install_stat_card("Label", "42", accent="primary")
        assert _G8_PRIMARY in card

    def test_positive_accent(self):
        card = _snippet_install_stat_card("Label", "42", accent="positive")
        assert "#059669" in card

    def test_destructive_accent(self):
        card = _snippet_install_stat_card("Label", "42", accent="destructive")
        assert "#ca3214" in card

    def test_warning_accent(self):
        card = _snippet_install_stat_card("Label", "42", accent="warning")
        # _G8_WARNING_FG lookup
        assert "#a0750a" in card

    def test_default_text(self):
        card = _snippet_install_stat_card("Label", "42")
        assert _G8_TEXT in card

    def test_escapes_label_and_value(self):
        card = _snippet_install_stat_card("<b>x</b>", "<i>y</i>")
        assert "<b>x</b>" not in card
        assert "&lt;b&gt;x&lt;/b&gt;" in card


# ==================================================================== #
# _snippet_install_code_block                                         #
# ==================================================================== #


class TestCodeBlock:
    def test_empty_returns_empty_no_overflow(self):
        code, ov = _snippet_install_code_block("", 100)
        assert code == ""
        assert ov is False

    def test_none_returns_empty(self):
        code, ov = _snippet_install_code_block(None, 100)
        assert code == ""
        assert ov is False

    def test_non_string_returns_empty(self):
        code, ov = _snippet_install_code_block(42, 100)
        assert code == ""
        assert ov is False

    def test_whitespace_only_returns_empty(self):
        code, ov = _snippet_install_code_block("   ", 100)
        assert code == ""
        assert ov is False

    def test_short_not_overflow(self):
        code, ov = _snippet_install_code_block("hello", 100)
        assert code == "hello"
        assert ov is False

    def test_long_triggers_overflow(self):
        code, ov = _snippet_install_code_block("x" * 200, 50)
        assert ov is True
        assert code.endswith("…")

    def test_escapes_html(self):
        code, _ = _snippet_install_code_block(
            '<script src="evil.com"></script>', 200
        )
        assert "<script" not in code
        assert "&lt;script" in code

    def test_escapes_ampersand(self):
        code, _ = _snippet_install_code_block("a & b", 100)
        assert "&amp;" in code

    def test_escapes_quotes(self):
        code, _ = _snippet_install_code_block('x="y"', 100)
        assert "&quot;" in code or "&#x27;" in code or '"' not in code


# ==================================================================== #
# _render_snippet_install_empty_state_html                            #
# ==================================================================== #


class TestEmptyState:
    def test_unavailable_mode_uses_muted(self):
        out = _render_snippet_install_empty_state_html(mode="unavailable")
        assert "Tracking snippet not available" in out
        assert _G8_CARD_BG in out

    def test_no_stream_mode_uses_primary(self):
        out = _render_snippet_install_empty_state_html(mode="no_stream")
        assert "No tracking stream connected yet" in out
        assert _G8_ACCENT_BG in out
        assert _G8_PRIMARY in out

    def test_unavailable_mentions_get_snippet(self):
        out = _render_snippet_install_empty_state_html(mode="unavailable")
        assert "GET /snippet" in out

    def test_no_stream_mentions_connections(self):
        out = _render_snippet_install_empty_state_html(mode="no_stream")
        assert "Connections" in out

    def test_unknown_mode_defaults_to_unavailable(self):
        out = _render_snippet_install_empty_state_html(mode="weird")
        assert "Tracking snippet not available" in out


# ==================================================================== #
# render_snippet_install_html                                         #
# ==================================================================== #


class TestRenderHtml:
    def _mk_snippet(self, **overrides):
        base = {
            "write_key": "wk_abc123",
            "tracking_host": "https://t.graph8.com",
            "domains": ["example.com", "foo.com"],
            "script_tag": '<script src="https://t.graph8.com/p.js" data-write-key="wk_abc123"></script>',
            "react_snippet": 'import Script from "next/script";\n\nexport function Graph8Analytics() {}\n',
            "config": {},
        }
        base.update(overrides)
        return base

    def _mk_form(self, **overrides):
        base = {
            "html": "<form id='g8-lead-form'><input name='email'></form>",
            "write_key": "wk_abc123",
            "tracking_host": "https://t.graph8.com",
            "fields": ["name", "email", "company"],
            "event_name": "form_submitted",
            "notes": "Sample note.",
        }
        base.update(overrides)
        return base

    def test_none_snippet_renders_unavailable(self):
        html_ = render_snippet_install_html(snippet=None)
        assert "Tracking snippet not available" in html_

    def test_non_dict_snippet_renders_unavailable(self):
        html_ = render_snippet_install_html(snippet="str")  # type: ignore[arg-type]
        assert "Tracking snippet not available" in html_

    def test_missing_write_key_triggers_no_stream(self):
        html_ = render_snippet_install_html(
            snippet={"write_key": "", "tracking_host": "x"}
        )
        assert "No tracking stream connected yet" in html_

    def test_full_render_has_doctype(self):
        html_ = render_snippet_install_html(snippet=self._mk_snippet())
        assert "<!DOCTYPE html>" in html_

    def test_full_render_has_write_key_preview(self):
        html_ = render_snippet_install_html(snippet=self._mk_snippet())
        # Short write_key "wk_abc123" is <= 16 chars → shown in full.
        assert "wk_abc123" in html_

    def test_long_write_key_truncated_in_preview(self):
        html_ = render_snippet_install_html(
            snippet=self._mk_snippet(write_key="wk_abcdefghijklmnopqrstuvwxyz")
        )
        assert "wk_abcdefghijklm…" in html_ or "wk_abcdefghijklmn…" in html_

    def test_tracking_host_rendered(self):
        html_ = render_snippet_install_html(snippet=self._mk_snippet())
        assert "t.graph8.com" in html_

    def test_domain_count_rendered(self):
        html_ = render_snippet_install_html(snippet=self._mk_snippet())
        assert "example.com" in html_
        assert "foo.com" in html_

    def test_zero_domains_hides_domains_card(self):
        html_ = render_snippet_install_html(
            snippet=self._mk_snippet(domains=[])
        )
        assert "Authorized domains" not in html_

    def test_script_tag_rendered_escaped(self):
        html_ = render_snippet_install_html(snippet=self._mk_snippet())
        # Script tag must not render raw — it should be escaped.
        # Look for escaped "<script" signature in the code block
        assert "&lt;script" in html_

    def test_script_tag_card_header(self):
        html_ = render_snippet_install_html(snippet=self._mk_snippet())
        assert "Script tag" in html_

    def test_react_snippet_rendered(self):
        html_ = render_snippet_install_html(snippet=self._mk_snippet())
        assert "Graph8Analytics" in html_

    def test_react_card_header(self):
        html_ = render_snippet_install_html(snippet=self._mk_snippet())
        assert "React / Next.js component" in html_

    def test_form_rendered_when_form_provided(self):
        html_ = render_snippet_install_html(
            snippet=self._mk_snippet(), form=self._mk_form()
        )
        assert "Lead-capture form template" in html_
        assert "g8-lead-form" in html_

    def test_form_not_rendered_when_form_none(self):
        html_ = render_snippet_install_html(
            snippet=self._mk_snippet(), form=None
        )
        assert "Lead-capture form template" not in html_

    def test_form_field_pills_rendered(self):
        html_ = render_snippet_install_html(
            snippet=self._mk_snippet(), form=self._mk_form()
        )
        assert "email" in html_
        assert "company" in html_

    def test_form_event_name_rendered(self):
        html_ = render_snippet_install_html(
            snippet=self._mk_snippet(), form=self._mk_form()
        )
        assert "form_submitted" in html_

    def test_form_notes_rendered(self):
        html_ = render_snippet_install_html(
            snippet=self._mk_snippet(), form=self._mk_form()
        )
        assert "Sample note." in html_

    def test_form_status_chip_shows_ready(self):
        html_ = render_snippet_install_html(
            snippet=self._mk_snippet(), form=self._mk_form()
        )
        assert "FORM READY" in html_

    def test_form_status_chip_shows_offline_when_missing(self):
        html_ = render_snippet_install_html(
            snippet=self._mk_snippet(), form=None
        )
        assert "FORM OFFLINE" in html_

    def test_snippet_status_chip_shows_ready(self):
        html_ = render_snippet_install_html(snippet=self._mk_snippet())
        assert "SNIPPET READY" in html_

    def test_four_stat_cards_present(self):
        html_ = render_snippet_install_html(
            snippet=self._mk_snippet(), form=self._mk_form()
        )
        # Labels live in the HTML mixed case — CSS text-transform
        # uppercases them at render time. Verify the mixed-case strings
        # present in the document.
        assert "Write key" in html_
        assert "Tracking host" in html_
        assert "Domains" in html_
        assert "Form fields" in html_

    def test_xss_escape_on_tracking_host(self):
        html_ = render_snippet_install_html(
            snippet=self._mk_snippet(tracking_host="<script>alert(1)</script>")
        )
        assert "<script>alert(1)</script>" not in html_
        assert "&lt;script&gt;" in html_

    def test_xss_escape_on_domain(self):
        html_ = render_snippet_install_html(
            snippet=self._mk_snippet(
                domains=["<script>x</script>", "legit.com"]
            )
        )
        assert "<script>x</script>" not in html_
        assert "&lt;script&gt;" in html_

    def test_drill_up_points_at_siblings(self):
        html_ = render_snippet_install_html(snippet=self._mk_snippet())
        assert "GET /snippet" in html_
        assert "GET /snippet/form" in html_
        assert "g8://repos/dashboard" in html_
        assert "g8_get_tracking_snippet" in html_
        assert "g8_get_form_template" in html_

    def test_drill_up_does_NOT_list_self(self):
        # Regression lock: manage-tracking block must not self-reference.
        html_ = render_snippet_install_html(snippet=self._mk_snippet())
        # The URI itself must not appear anywhere as a clickable pointer.
        # (It's OK for doctype/title to mention "snippet" — just not the
        # full self-URI g8://snippet/install.)
        assert "g8://snippet/install" not in html_

    def test_no_single_side_accent_borders(self):
        """Regression lock: the AI-tell single-side colored accent border
        pattern must never appear in this renderer."""
        html_ = render_snippet_install_html(
            snippet=self._mk_snippet(), form=self._mk_form()
        )
        # These are common single-side colored border antipatterns.
        forbidden = [
            "border-left:4px solid #",
            "border-left: 4px solid #",
            "border-top:4px solid #",
            "border-top: 4px solid #",
        ]
        for pattern in forbidden:
            assert pattern not in html_, (
                f"Single-side colored accent border pattern '{pattern}' "
                f"leaked into the snippet install renderer."
            )

    def test_no_legacy_accent_hexes(self):
        """Regression lock: old non-graph8 palette hexes must not appear."""
        html_ = render_snippet_install_html(
            snippet=self._mk_snippet(), form=self._mk_form()
        )
        forbidden_hexes = [
            "#6366f1",  # indigo
            "#4f46e5",  # indigo-600
            "#10b981",  # emerald
            "#ec4899",  # pink
            "#dc2626",  # red-600 (we use #ca3214)
            "#16a34a",  # green-600 (we use #059669)
        ]
        for hx in forbidden_hexes:
            assert hx not in html_, (
                f"Legacy accent hex {hx} leaked into snippet install "
                f"renderer. Use graph8 tokens instead."
            )

    def test_domain_overflow_note(self):
        many = [f"d{i}.com" for i in range(_MAX_SNIPPET_DOMAIN_CHIPS + 5)]
        html_ = render_snippet_install_html(
            snippet=self._mk_snippet(domains=many)
        )
        assert "+ 5 more domains" in html_

    def test_field_overflow_note(self):
        many = [f"f{i}" for i in range(_MAX_SNIPPET_FIELD_CHIPS + 3)]
        html_ = render_snippet_install_html(
            snippet=self._mk_snippet(),
            form=self._mk_form(fields=many),
        )
        assert "+ 3 more" in html_

    def test_script_tag_overflow_truncates(self):
        huge = "<script>" + "x" * (_MAX_SNIPPET_SCRIPT_TAG_LEN + 50) + "</script>"
        html_ = render_snippet_install_html(
            snippet=self._mk_snippet(script_tag=huge)
        )
        assert "Preview truncated" in html_

    def test_form_overflow_truncates(self):
        huge = "<form>" + "x" * (_MAX_SNIPPET_FORM_LEN + 100) + "</form>"
        html_ = render_snippet_install_html(
            snippet=self._mk_snippet(),
            form=self._mk_form(html=huge),
        )
        assert "Preview truncated" in html_


# ==================================================================== #
# render_snippet_install_text_fallback                                 #
# ==================================================================== #


class TestTextFallback:
    def _mk_snippet(self, **overrides):
        base = {
            "write_key": "wk_abc123",
            "tracking_host": "https://t.graph8.com",
            "domains": ["example.com"],
            "script_tag": '<script src="x"></script>',
            "react_snippet": "import Script from next/script",
        }
        base.update(overrides)
        return base

    def _mk_form(self, **overrides):
        base = {
            "html": "<form>x</form>",
            "fields": ["name", "email"],
            "event_name": "form_submitted",
            "notes": "notes here",
        }
        base.update(overrides)
        return base

    def test_none_returns_not_available(self):
        out = render_snippet_install_text_fallback(snippet=None)
        assert "not available" in out

    def test_non_dict_returns_not_available(self):
        out = render_snippet_install_text_fallback(snippet="x")  # type: ignore[arg-type]
        assert "not available" in out

    def test_missing_write_key_triggers_no_stream_text(self):
        out = render_snippet_install_text_fallback(
            snippet={"write_key": "", "tracking_host": "x"}
        )
        assert "No tracking stream connected yet" in out

    def test_header_present(self):
        out = render_snippet_install_text_fallback(snippet=self._mk_snippet())
        assert "# Install tracking" in out

    def test_write_key_shown(self):
        out = render_snippet_install_text_fallback(snippet=self._mk_snippet())
        assert "wk_abc123" in out

    def test_host_shown(self):
        out = render_snippet_install_text_fallback(snippet=self._mk_snippet())
        assert "t.graph8.com" in out

    def test_script_section_when_present(self):
        out = render_snippet_install_text_fallback(snippet=self._mk_snippet())
        assert "## Script tag" in out

    def test_react_section_when_present(self):
        out = render_snippet_install_text_fallback(snippet=self._mk_snippet())
        assert "## React" in out

    def test_form_section_when_form_present(self):
        out = render_snippet_install_text_fallback(
            snippet=self._mk_snippet(), form=self._mk_form()
        )
        assert "## Lead-capture form template" in out

    def test_form_section_absent_when_form_none(self):
        out = render_snippet_install_text_fallback(
            snippet=self._mk_snippet(), form=None
        )
        assert "## Lead-capture form template" not in out

    def test_form_fields_listed(self):
        out = render_snippet_install_text_fallback(
            snippet=self._mk_snippet(), form=self._mk_form()
        )
        assert "name" in out
        assert "email" in out

    def test_form_event_listed(self):
        out = render_snippet_install_text_fallback(
            snippet=self._mk_snippet(), form=self._mk_form()
        )
        assert "form_submitted" in out

    def test_manage_block_present(self):
        out = render_snippet_install_text_fallback(snippet=self._mk_snippet())
        assert "## Manage tracking" in out

    def test_manage_block_points_at_siblings(self):
        out = render_snippet_install_text_fallback(snippet=self._mk_snippet())
        assert "GET /snippet" in out
        assert "GET /snippet/form" in out
        assert "g8://repos/dashboard" in out
        assert "g8_get_tracking_snippet" in out
        assert "g8_get_form_template" in out

    def test_manage_block_does_not_list_self(self):
        # Regression lock.
        out = render_snippet_install_text_fallback(snippet=self._mk_snippet())
        assert "g8://snippet/install" not in out

    def test_code_blocks_use_fenced_triple_backticks(self):
        out = render_snippet_install_text_fallback(
            snippet=self._mk_snippet(), form=self._mk_form()
        )
        # At least 3 fenced blocks: script, react, form.
        assert out.count("```") >= 6

    def test_script_unescaped_in_text(self):
        # In text fallback, script tag should be human-readable, not HTML-escaped.
        out = render_snippet_install_text_fallback(snippet=self._mk_snippet())
        assert "<script" in out
        assert "&lt;script" not in out

    def test_domain_list_present(self):
        out = render_snippet_install_text_fallback(snippet=self._mk_snippet())
        assert "example.com" in out

    def test_unavailable_manage_block_points_at_siblings(self):
        out = render_snippet_install_text_fallback(snippet=None)
        # Even the unavailable branch lists the management pointers.
        assert "GET /snippet" in out
        assert "g8_get_tracking_snippet" in out

    def test_no_stream_manage_block_present(self):
        out = render_snippet_install_text_fallback(
            snippet={"write_key": ""}
        )
        assert "## Manage tracking" in out
        # Still no self-reference.
        assert "g8://snippet/install" not in out


# ==================================================================== #
# Smoke tests with realistic data                                      #
# ==================================================================== #


class TestSmoke:
    def test_realistic_full_install_html(self):
        snippet = {
            "write_key": "wk_01HXY2ZABCDEF01234",
            "tracking_host": "https://t.graph8.com",
            "domains": ["acme.com", "app.acme.com"],
            "script_tag": (
                '<script src="https://t.graph8.com/p.js" '
                'data-write-key="wk_01HXY2ZABCDEF01234" '
                'data-tracking-host="https://t.graph8.com" defer></script>'
            ),
            "react_snippet": (
                'import Script from "next/script";\n\n'
                "export function Graph8Analytics() {\n"
                "  return (\n"
                '    <Script src="https://t.graph8.com/p.js" '
                'data-write-key="wk_01HXY2ZABCDEF01234" />\n'
                "  );\n"
                "}\n"
            ),
            "config": {
                "write_key": "wk_01HXY2ZABCDEF01234",
                "tracking_host": "https://t.graph8.com",
                "domains": ["acme.com", "app.acme.com"],
            },
        }
        form = {
            "html": (
                '<form id="g8-lead-form">\n'
                '  <input name="name" type="text">\n'
                '  <input name="email" type="email">\n'
                '  <input name="company" type="text">\n'
                '  <button type="submit">Submit</button>\n'
                "</form>"
            ),
            "write_key": "wk_01HXY2ZABCDEF01234",
            "tracking_host": "https://t.graph8.com",
            "fields": ["name", "email", "company"],
            "event_name": "form_submitted",
            "notes": (
                "Drop this into any page that already loads the snippet. "
                "Form will emit form_submitted on submit."
            ),
        }
        html_ = render_snippet_install_html(snippet=snippet, form=form)
        text = render_snippet_install_text_fallback(snippet=snippet, form=form)
        # HTML round-trip
        assert "<!DOCTYPE html>" in html_
        assert "SNIPPET READY" in html_
        assert "FORM READY" in html_
        assert "acme.com" in html_
        assert "app.acme.com" in html_
        assert "Graph8Analytics" in html_
        assert "form_submitted" in html_
        # Text round-trip
        assert "# Install tracking" in text
        # wk_01HXY2ZABCDEF01234 -> 21 chars; display first 16 + … =
        # "wk_01HXY2ZABCDEF…"
        assert "wk_01HXY2ZABCDEF…" in text
        assert "t.graph8.com" in text
        assert "## Script tag" in text
        assert "## React" in text
        assert "## Lead-capture form template" in text

    def test_no_stream_smoke(self):
        html_ = render_snippet_install_html(snippet={"write_key": ""})
        text = render_snippet_install_text_fallback(snippet={"write_key": ""})
        assert "No tracking stream connected yet" in html_
        assert "No tracking stream connected yet" in text

    def test_snippet_only_no_form(self):
        snippet = {
            "write_key": "wk_shortkey",
            "tracking_host": "https://t.graph8.com",
            "domains": [],
            "script_tag": "<script></script>",
            "react_snippet": "",
        }
        html_ = render_snippet_install_html(snippet=snippet, form=None)
        text = render_snippet_install_text_fallback(snippet=snippet, form=None)
        assert "SNIPPET READY" in html_
        assert "FORM OFFLINE" in html_
        assert "Lead-capture form template" not in html_
        assert "## Lead-capture form template" not in text
