"""Unit tests for the surface #29 sequence-detail renderer + helpers.

Surface #29 is the per-sequence top-level overview at URI
`g8://sequences/{sequence_id}/overview`. Complements:
  - surface #2  (g8://sequences/{sequence_id}/preview   — step structure)
  - surface #23 (g8://sequences/{sequence_id}/analytics — performance)
  - surface #9  (g8://sequences/dashboard               — org-wide list)

Answers "what is THIS sequence — who owns it, what list, what status,
what behavior flags, how are contacts distributed across states?".

The `/overview` suffix is deliberate:
  - Three siblings already live under `g8://sequences/{sequence_id}/`:
    `/preview` and `/analytics`.
  - Without `/overview`, a bare `{sequence_id}` template would capture
    `seq_42.txt` into `sequence_id` before the `.txt` fallback template
    is reached, shadowing the plaintext variant. The suffix makes all
    siblings unambiguous at dispatch time.
"""

from __future__ import annotations

import pytest

from g8_mcp_server.app_renderer import (
    _SEQUENCE_DETAIL_CONTACT_STATE_COLORS,
    _SEQUENCE_DETAIL_STATUS_COLORS,
    _render_sequence_detail_empty_state_html,
    _sequence_contact_state_palette,
    _sequence_detail_bool_chip,
    _sequence_detail_derive_display_name,
    _sequence_detail_info_row,
    _sequence_detail_stat_card,
    _sequence_detail_status_palette,
    _sequence_detail_tally_contact_states,
    render_sequence_detail_html,
    render_sequence_detail_text_fallback,
)

_BANNED_HEXES = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}


class TestSequenceDetailPalettesNoBannedHexes:
    """Lock tests: palettes must not reintroduce banned Studio hexes."""

    def test_no_banned_hexes_in_status_palette(self):
        for key, pal in _SEQUENCE_DETAIL_STATUS_COLORS.items():
            for field in ("bg", "fg", "border"):
                assert pal[field].lower() not in _BANNED_HEXES, (
                    f"Banned hex {pal[field]!r} in _SEQUENCE_DETAIL_STATUS_COLORS[{key!r}][{field!r}]"
                )

    def test_no_banned_hexes_in_contact_state_palette(self):
        for key, pal in _SEQUENCE_DETAIL_CONTACT_STATE_COLORS.items():
            for field in ("bg", "fg", "border"):
                assert pal[field].lower() not in _BANNED_HEXES, (
                    f"Banned hex {pal[field]!r} in _SEQUENCE_DETAIL_CONTACT_STATE_COLORS[{key!r}][{field!r}]"
                )


def _sample_sequence() -> dict:
    return {
        "id": "seq_abc123",
        "name": "Welcome series",
        "description": "Onboard trial users over two weeks.",
        "status": "live",
        "user_email": "thomas@graph8.com",
        "associated_list_id": 42,
        "finish_on_reply": True,
        "send_in_same_thread": False,
        "wait_for_new_contacts": True,
        "paused_at": None,
        "resumed_at": None,
        "created_at": "2026-04-01T00:00:00Z",
        "updated_at": "2026-04-19T10:00:00Z",
    }


def _sample_contacts() -> list[dict]:
    # 4 active, 2 replied, 1 bounced, 1 paused, 1 with missing state
    return [
        {"id": "sc_1", "state": "active", "current_step_order": 1},
        {"id": "sc_2", "state": "active", "current_step_order": 2},
        {"id": "sc_3", "state": "active", "current_step_order": 1},
        {"id": "sc_4", "state": "active", "current_step_order": 3},
        {"id": "sc_5", "state": "replied", "current_step_order": 2},
        {"id": "sc_6", "state": "replied", "current_step_order": 1},
        {"id": "sc_7", "state": "bounced", "current_step_order": 1},
        {"id": "sc_8", "state": "paused", "current_step_order": 2},
        {"id": "sc_9"},  # no state → "unknown"
    ]


# ---------------------------------------------------------------------------
# _sequence_detail_derive_display_name
# ---------------------------------------------------------------------------

class TestSequenceDetailDeriveDisplayName:
    def test_uses_name_when_present(self):
        assert _sequence_detail_derive_display_name({"name": "My Sequence"}) == "My Sequence"

    def test_trims_whitespace(self):
        assert _sequence_detail_derive_display_name({"name": "  Welcome  "}) == "Welcome"

    def test_empty_name_falls_through(self):
        assert _sequence_detail_derive_display_name({"name": ""}) == "Sequence"

    def test_whitespace_only_name_falls_through(self):
        assert _sequence_detail_derive_display_name({"name": "   "}) == "Sequence"

    def test_none_sequence(self):
        assert _sequence_detail_derive_display_name(None) == "Sequence"

    def test_non_dict_sequence(self):
        assert _sequence_detail_derive_display_name("bogus") == "Sequence"  # type: ignore[arg-type]

    def test_name_not_string(self):
        assert _sequence_detail_derive_display_name({"name": 42}) == "Sequence"

    def test_missing_name_key(self):
        assert _sequence_detail_derive_display_name({"status": "live"}) == "Sequence"


# ---------------------------------------------------------------------------
# _sequence_detail_status_palette
# ---------------------------------------------------------------------------

class TestSequenceDetailStatusPalette:
    @pytest.mark.parametrize("status,expected_fg", [
        ("draft", "#777777"),
        ("live", "#059669"),  # was banned #166534 → _G8_POSITIVE_FG
        ("running", "#059669"),  # was banned #166534
        ("active", "#059669"),  # was banned #166534
        ("paused", "#92400e"),
        ("finished", "#7d2df3"),
        ("completed", "#7d2df3"),
        ("archived", "#777777"),
        ("error", "#b91c1c"),  # was banned #991b1b → _G8_DESTRUCTIVE_ON_LIGHT_FG
        ("failed", "#b91c1c"),  # was banned #991b1b
    ])
    def test_known_statuses(self, status, expected_fg):
        assert _sequence_detail_status_palette(status)["fg"] == expected_fg

    def test_unknown_returns_default(self):
        assert _sequence_detail_status_palette("unicorn")["fg"] == "#777777"

    def test_case_insensitive(self):
        assert _sequence_detail_status_palette("LIVE")["fg"] == "#059669"  # was banned #166534

    def test_whitespace_trimmed(self):
        assert _sequence_detail_status_palette("  live  ")["fg"] == "#059669"  # was banned #166534

    def test_empty_string_returns_default(self):
        assert _sequence_detail_status_palette("")["fg"] == "#777777"

    def test_none_returns_default(self):
        assert _sequence_detail_status_palette(None)["fg"] == "#777777"

    def test_non_string_returns_default(self):
        assert _sequence_detail_status_palette(42)["fg"] == "#777777"  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# _sequence_contact_state_palette
# ---------------------------------------------------------------------------

class TestSequenceContactStatePalette:
    @pytest.mark.parametrize("state,expected_fg", [
        ("active", "#1e40af"),
        ("running", "#1e40af"),
        ("scheduled", "#7d2df3"),
        ("pending", "#777777"),
        ("paused", "#92400e"),
        ("replied", "#059669"),  # was banned #166534 → _G8_POSITIVE_FG
        ("finished", "#059669"),  # was banned #166534
        ("completed", "#059669"),  # was banned #166534
        ("bounced", "#b91c1c"),  # was banned #991b1b → _G8_DESTRUCTIVE_ON_LIGHT_FG
        ("failed", "#b91c1c"),  # was banned #991b1b
        ("error", "#b91c1c"),  # was banned #991b1b
        ("opted_out", "#777777"),
        ("unsubscribed", "#777777"),
    ])
    def test_known_states(self, state, expected_fg):
        assert _sequence_contact_state_palette(state)["fg"] == expected_fg

    def test_unknown_returns_default(self):
        assert _sequence_contact_state_palette("waiting_for_approval")["fg"] == "#777777"

    def test_case_insensitive(self):
        assert _sequence_contact_state_palette("ACTIVE")["fg"] == "#1e40af"

    def test_none_returns_default(self):
        assert _sequence_contact_state_palette(None)["fg"] == "#777777"

    def test_empty_string_returns_default(self):
        assert _sequence_contact_state_palette("")["fg"] == "#777777"

    def test_non_string_returns_default(self):
        assert _sequence_contact_state_palette(42)["fg"] == "#777777"  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# _sequence_detail_tally_contact_states
# ---------------------------------------------------------------------------

class TestSequenceDetailTallyContactStates:
    def test_basic_tally(self):
        contacts = [
            {"state": "active"},
            {"state": "active"},
            {"state": "replied"},
        ]
        tally = _sequence_detail_tally_contact_states(contacts)
        assert tally == {"active": 2, "replied": 1}

    def test_missing_state_bucketed_as_unknown(self):
        contacts = [{"id": "sc_1"}, {"id": "sc_2", "state": ""}]
        tally = _sequence_detail_tally_contact_states(contacts)
        assert tally == {"unknown": 2}

    def test_whitespace_only_state_bucketed_as_unknown(self):
        contacts = [{"state": "   "}]
        tally = _sequence_detail_tally_contact_states(contacts)
        assert tally == {"unknown": 1}

    def test_case_normalized(self):
        contacts = [{"state": "ACTIVE"}, {"state": "active"}, {"state": " Active "}]
        tally = _sequence_detail_tally_contact_states(contacts)
        assert tally == {"active": 3}

    def test_non_dict_entries_skipped(self):
        contacts = [{"state": "active"}, "bogus", 42, None, {"state": "replied"}]
        tally = _sequence_detail_tally_contact_states(contacts)  # type: ignore[arg-type]
        assert tally == {"active": 1, "replied": 1}

    def test_empty_list(self):
        assert _sequence_detail_tally_contact_states([]) == {}

    def test_none_input(self):
        assert _sequence_detail_tally_contact_states(None) == {}

    def test_non_list_input(self):
        assert _sequence_detail_tally_contact_states("bogus") == {}  # type: ignore[arg-type]

    def test_full_mixed_sample(self):
        tally = _sequence_detail_tally_contact_states(_sample_contacts())
        assert tally == {"active": 4, "replied": 2, "bounced": 1, "paused": 1, "unknown": 1}


# ---------------------------------------------------------------------------
# _sequence_detail_stat_card
# ---------------------------------------------------------------------------

class TestSequenceDetailStatCard:
    def test_basic(self):
        out = _sequence_detail_stat_card("Status", "Live")
        assert 'class="stat-card"' in out
        assert 'class="stat-label"' in out
        assert ">Status<" in out
        assert ">Live</div>" in out

    def test_accent_applied(self):
        out = _sequence_detail_stat_card("Status", "Live", accent="#166534")
        assert "color:#166534" in out

    def test_no_accent(self):
        out = _sequence_detail_stat_card("Status", "Live")
        assert "color:" not in out.split('class="stat-value"')[1].split(">")[0] or True
        # accent is optional — absence means no ";color:..." suffix
        assert ';color:' not in out.split('class="stat-value"')[1].split('>')[0]

    def test_label_escaped(self):
        out = _sequence_detail_stat_card("<script>", "Live")
        assert "&lt;script&gt;" in out
        assert "<script>" not in out

    def test_value_not_escaped(self):
        # value is pre-composed HTML — caller's responsibility
        out = _sequence_detail_stat_card("Owner", '<span class="mono">a@b.com</span>')
        assert '<span class="mono">a@b.com</span>' in out


# ---------------------------------------------------------------------------
# _sequence_detail_info_row
# ---------------------------------------------------------------------------

class TestSequenceDetailInfoRow:
    def test_basic(self):
        out = _sequence_detail_info_row("Owner", "a@b.com")
        assert 'class="info-row"' in out
        assert ">Owner<" in out
        assert ">a@b.com<" in out

    def test_label_escaped(self):
        out = _sequence_detail_info_row("<script>", "ok")
        assert "&lt;script&gt;" in out

    def test_value_not_escaped(self):
        out = _sequence_detail_info_row("Owner", '<span class="mono">a@b.com</span>')
        assert '<span class="mono">a@b.com</span>' in out


# ---------------------------------------------------------------------------
# _sequence_detail_bool_chip
# ---------------------------------------------------------------------------

class TestSequenceDetailBoolChip:
    def test_on_state(self):
        out = _sequence_detail_bool_chip("Finish on reply", True)
        assert "Finish on reply: on" in out
        assert "#d1fae5" in out  # green bg
        assert "#059669" in out  # green fg (was banned #166534 → _G8_POSITIVE_FG)

    def test_off_state(self):
        out = _sequence_detail_bool_chip("Finish on reply", False)
        assert "Finish on reply: off" in out
        assert "#f9f9f9" in out  # gray bg
        assert "#777777" in out  # gray fg

    def test_label_escaped(self):
        out = _sequence_detail_bool_chip("<script>", True)
        assert "&lt;script&gt;" in out


# ---------------------------------------------------------------------------
# _render_sequence_detail_empty_state_html
# ---------------------------------------------------------------------------

class TestRenderSequenceDetailEmptyState:
    def test_basic(self):
        out = _render_sequence_detail_empty_state_html(sequence_id="seq_42")
        assert "Sequence not found" in out
        assert "<code>seq_42</code>" in out
        assert "g8_list_sequences" in out
        assert "g8://sequences/dashboard" in out

    def test_empty_id_shows_unknown(self):
        out = _render_sequence_detail_empty_state_html(sequence_id="")
        assert "(unknown)" in out

    def test_id_is_escaped(self):
        out = _render_sequence_detail_empty_state_html(sequence_id="<script>")
        assert "&lt;script&gt;" in out
        assert "<script>" not in out

    def test_custom_reason(self):
        out = _render_sequence_detail_empty_state_html(
            sequence_id="seq_42", reason="Archived by admin"
        )
        assert "Archived by admin" in out

    def test_reason_is_escaped(self):
        out = _render_sequence_detail_empty_state_html(
            sequence_id="seq_42", reason="<img src=x>"
        )
        assert "&lt;img src=x&gt;" in out
        assert "<img src=x>" not in out


# ---------------------------------------------------------------------------
# render_sequence_detail_html — happy path
# ---------------------------------------------------------------------------

class TestRenderSequenceDetailHtml:
    def test_full_happy_path(self):
        out = render_sequence_detail_html(
            sequence=_sample_sequence(),
            sequence_id="seq_abc123",
            contacts=_sample_contacts(),
        )
        # Core structure
        assert "<!doctype html>" in out
        assert "<title>Sequence — Welcome series</title>" in out
        assert "<h1>Welcome series</h1>" in out
        assert "id: #seq_abc123" in out

        # Status badge
        assert "LIVE" in out
        assert "#059669" in out  # green fg for live (was banned #166534 → _G8_POSITIVE_FG)

        # Stat cards
        assert ">Status<" in out
        assert ">Owner<" in out
        assert ">List<" in out
        assert ">Contacts<" in out
        assert ">Active<" in out

        # Stat values
        assert "Live" in out  # title-cased status value
        assert "thomas@graph8.com" in out
        assert "#42" in out  # list id formatted

        # Description
        assert "Onboard trial users over two weeks." in out

        # Overview info rows
        assert "Associated list" in out
        assert "Created" in out
        assert "Updated" in out
        assert "2026-04-01T00:00:00Z" in out
        assert "2026-04-19T10:00:00Z" in out

        # Behavior chips
        assert "Finish on reply: on" in out
        assert "Same thread: off" in out
        assert "Wait for new contacts: on" in out

        # Contact state chips (4 active, 2 replied, 1 bounced, 1 paused, 1 unknown)
        assert "active: 4" in out
        assert "replied: 2" in out
        assert "bounced: 1" in out

        # Drill-down hints
        assert "g8://sequences/seq_abc123/preview" in out
        assert "g8://sequences/seq_abc123/analytics" in out
        assert "g8://sequences/dashboard" in out

    def test_no_contacts_omits_contacts_section(self):
        out = render_sequence_detail_html(
            sequence=_sample_sequence(),
            sequence_id="seq_abc123",
            contacts=None,
        )
        assert "contacts-section" not in out
        # stat cards for contacts/active show em-dash
        assert ">—</div>" in out

    def test_empty_contacts_shows_empty_state(self):
        out = render_sequence_detail_html(
            sequence=_sample_sequence(),
            sequence_id="seq_abc123",
            contacts=[],
        )
        assert "No contacts enrolled in this sequence yet." in out

    def test_none_sequence_returns_empty_state(self):
        out = render_sequence_detail_html(sequence=None, sequence_id="seq_42")
        assert "Sequence not found" in out
        assert "<code>seq_42</code>" in out

    def test_non_dict_sequence_returns_empty_state(self):
        out = render_sequence_detail_html(sequence="bogus", sequence_id="seq_42")  # type: ignore[arg-type]
        assert "Sequence not found" in out

    def test_no_description_omits_section(self):
        seq = _sample_sequence()
        seq["description"] = None
        out = render_sequence_detail_html(sequence=seq, sequence_id="seq_abc123")
        assert "description-section" not in out

    def test_empty_description_omits_section(self):
        seq = _sample_sequence()
        seq["description"] = "   "
        out = render_sequence_detail_html(sequence=seq, sequence_id="seq_abc123")
        assert "description-section" not in out

    def test_no_status_shows_unknown(self):
        seq = _sample_sequence()
        seq["status"] = None
        out = render_sequence_detail_html(sequence=seq, sequence_id="seq_abc123")
        assert "UNKNOWN" in out

    def test_missing_user_email_shows_dash(self):
        seq = _sample_sequence()
        seq["user_email"] = None
        out = render_sequence_detail_html(sequence=seq, sequence_id="seq_abc123")
        # Owner stat card should show em-dash
        assert "thomas@graph8.com" not in out

    def test_missing_associated_list_id(self):
        seq = _sample_sequence()
        seq["associated_list_id"] = None
        out = render_sequence_detail_html(sequence=seq, sequence_id="seq_abc123")
        # List stat card shows em-dash; no "#42" visible
        assert "Associated list" not in out

    def test_paused_sequence_shows_paused_at(self):
        seq = _sample_sequence()
        seq["status"] = "paused"
        seq["paused_at"] = "2026-04-18T10:00:00Z"
        out = render_sequence_detail_html(sequence=seq, sequence_id="seq_abc123")
        assert "PAUSED" in out
        assert "Paused" in out
        assert "2026-04-18T10:00:00Z" in out

    def test_behavior_flags_all_false(self):
        seq = _sample_sequence()
        seq["finish_on_reply"] = False
        seq["send_in_same_thread"] = False
        seq["wait_for_new_contacts"] = False
        out = render_sequence_detail_html(sequence=seq, sequence_id="seq_abc123")
        assert "Finish on reply: off" in out
        assert "Same thread: off" in out
        assert "Wait for new contacts: off" in out

    def test_name_escaped(self):
        seq = _sample_sequence()
        seq["name"] = "<script>alert(1)</script>"
        out = render_sequence_detail_html(sequence=seq, sequence_id="seq_abc123")
        assert "<script>alert(1)</script>" not in out
        assert "&lt;script&gt;" in out

    def test_description_escaped(self):
        seq = _sample_sequence()
        seq["description"] = "<b>bold</b>"
        out = render_sequence_detail_html(sequence=seq, sequence_id="seq_abc123")
        assert "<b>bold</b>" not in out
        assert "&lt;b&gt;bold&lt;/b&gt;" in out

    def test_user_email_escaped(self):
        seq = _sample_sequence()
        seq["user_email"] = "<evil>@test.com"
        out = render_sequence_detail_html(sequence=seq, sequence_id="seq_abc123")
        assert "<evil>@test.com" not in out

    def test_long_description_truncated(self):
        seq = _sample_sequence()
        seq["description"] = "A" * 1000
        out = render_sequence_detail_html(sequence=seq, sequence_id="seq_abc123")
        # default MAX_SEQUENCE_DETAIL_DESC_LEN is 600
        assert "A" * 1000 not in out
        assert "…" in out

    def test_active_count_includes_running_and_scheduled(self):
        contacts = [
            {"id": "1", "state": "active"},
            {"id": "2", "state": "running"},
            {"id": "3", "state": "scheduled"},
            {"id": "4", "state": "replied"},
        ]
        out = render_sequence_detail_html(
            sequence=_sample_sequence(),
            sequence_id="seq_abc123",
            contacts=contacts,
        )
        # Active card should count 3 (active + running + scheduled)
        # Contacts total = 4
        assert "active: 1" in out
        assert "running: 1" in out
        assert "scheduled: 1" in out
        assert "replied: 1" in out

    def test_contact_state_chips_sorted_descending(self):
        contacts = (
            [{"id": f"a{i}", "state": "active"} for i in range(5)]
            + [{"id": f"r{i}", "state": "replied"} for i in range(3)]
            + [{"id": f"b{i}", "state": "bounced"} for i in range(1)]
        )
        out = render_sequence_detail_html(
            sequence=_sample_sequence(),
            sequence_id="seq_abc123",
            contacts=contacts,
        )
        # active (5) should appear before replied (3) should appear before bounced (1)
        active_idx = out.find("active: 5")
        replied_idx = out.find("replied: 3")
        bounced_idx = out.find("bounced: 1")
        assert active_idx < replied_idx < bounced_idx
        assert active_idx > 0
        assert replied_idx > 0
        assert bounced_idx > 0

    def test_many_states_capped_with_overflow(self):
        # Build 12 distinct states to exercise the overflow path
        contacts = []
        for n, state in enumerate([
            "active", "running", "scheduled", "paused", "replied",
            "bounced", "failed", "completed", "opted_out", "custom_x",
            "custom_y", "custom_z",
        ]):
            contacts.extend([{"id": f"{state}_{i}", "state": state} for i in range(n + 1)])
        out = render_sequence_detail_html(
            sequence=_sample_sequence(),
            sequence_id="seq_abc123",
            contacts=contacts,
        )
        # MAX_SEQUENCE_DETAIL_CONTACT_STATES_RENDERED = 8
        assert "state-overflow" in out
        assert "more (" in out

    def test_inline_css_only(self):
        out = render_sequence_detail_html(
            sequence=_sample_sequence(),
            sequence_id="seq_abc123",
            contacts=_sample_contacts(),
        )
        # No <script> tags, no <link rel=stylesheet>
        assert "<script" not in out
        assert "<link" not in out

    def test_id_is_escaped_in_header(self):
        out = render_sequence_detail_html(
            sequence=_sample_sequence(),
            sequence_id="<script>alert(1)</script>",
            contacts=None,
        )
        assert "<script>alert(1)</script>" not in out


# ---------------------------------------------------------------------------
# render_sequence_detail_text_fallback
# ---------------------------------------------------------------------------

class TestRenderSequenceDetailTextFallback:
    def test_full_happy_path(self):
        out = render_sequence_detail_text_fallback(
            sequence=_sample_sequence(),
            sequence_id="seq_abc123",
            contacts=_sample_contacts(),
        )
        assert "# Sequence — Welcome series" in out
        assert "Status: **live**" in out
        assert "id: `seq_abc123`" in out

        assert "## Description" in out
        assert "Onboard trial users over two weeks." in out

        assert "## Overview" in out
        assert "- Owner: thomas@graph8.com" in out
        assert "- Associated list: #42" in out
        assert "- Created: 2026-04-01T00:00:00Z" in out
        assert "- Updated: 2026-04-19T10:00:00Z" in out

        assert "## Behavior" in out
        assert "- Finish on reply: on" in out
        assert "- Same thread: off" in out
        assert "- Wait for new contacts: on" in out

        assert "## Contacts (9 total)" in out
        assert "- active: 4" in out
        assert "- replied: 2" in out
        assert "- bounced: 1" in out
        assert "- paused: 1" in out
        assert "- unknown: 1" in out

        assert "## Drill into this sequence" in out
        assert "- Step structure: g8://sequences/seq_abc123/preview" in out
        assert "- Analytics: g8://sequences/seq_abc123/analytics" in out
        assert "- All sequences: g8://sequences/dashboard" in out

    def test_none_sequence_returns_empty_state(self):
        out = render_sequence_detail_text_fallback(sequence=None, sequence_id="seq_42")
        assert "# Sequence not found" in out
        assert "`seq_42`" in out
        assert "g8_list_sequences" in out

    def test_non_dict_sequence_returns_empty_state(self):
        out = render_sequence_detail_text_fallback(sequence="bogus", sequence_id="seq_42")  # type: ignore[arg-type]
        assert "# Sequence not found" in out

    def test_no_description_omits_section(self):
        seq = _sample_sequence()
        seq["description"] = None
        out = render_sequence_detail_text_fallback(sequence=seq, sequence_id="seq_abc123")
        assert "## Description" not in out

    def test_empty_description_omits_section(self):
        seq = _sample_sequence()
        seq["description"] = ""
        out = render_sequence_detail_text_fallback(sequence=seq, sequence_id="seq_abc123")
        assert "## Description" not in out

    def test_missing_owner_omits_line(self):
        seq = _sample_sequence()
        seq["user_email"] = None
        out = render_sequence_detail_text_fallback(sequence=seq, sequence_id="seq_abc123")
        assert "- Owner:" not in out

    def test_missing_list_omits_line(self):
        seq = _sample_sequence()
        seq["associated_list_id"] = None
        out = render_sequence_detail_text_fallback(sequence=seq, sequence_id="seq_abc123")
        assert "- Associated list:" not in out

    def test_paused_and_resumed_shown(self):
        seq = _sample_sequence()
        seq["paused_at"] = "2026-04-10T00:00:00Z"
        seq["resumed_at"] = "2026-04-12T00:00:00Z"
        out = render_sequence_detail_text_fallback(sequence=seq, sequence_id="seq_abc123")
        assert "- Paused: 2026-04-10T00:00:00Z" in out
        assert "- Resumed: 2026-04-12T00:00:00Z" in out

    def test_no_contacts_omits_contacts_section(self):
        out = render_sequence_detail_text_fallback(
            sequence=_sample_sequence(),
            sequence_id="seq_abc123",
            contacts=None,
        )
        assert "## Contacts" not in out

    def test_empty_contacts_shows_empty_line(self):
        out = render_sequence_detail_text_fallback(
            sequence=_sample_sequence(),
            sequence_id="seq_abc123",
            contacts=[],
        )
        assert "## Contacts" in out
        assert "No contacts enrolled in this sequence yet." in out

    def test_status_falls_back_to_unknown(self):
        seq = _sample_sequence()
        seq["status"] = None
        out = render_sequence_detail_text_fallback(sequence=seq, sequence_id="seq_abc123")
        assert "Status: **unknown**" in out

    def test_behavior_all_false(self):
        seq = _sample_sequence()
        seq["finish_on_reply"] = False
        seq["send_in_same_thread"] = False
        seq["wait_for_new_contacts"] = False
        out = render_sequence_detail_text_fallback(sequence=seq, sequence_id="seq_abc123")
        assert "- Finish on reply: off" in out
        assert "- Same thread: off" in out
        assert "- Wait for new contacts: off" in out

    def test_behavior_missing_flags_default_off(self):
        seq = {
            "id": "seq_x",
            "name": "Min",
            "status": "draft",
        }
        out = render_sequence_detail_text_fallback(sequence=seq, sequence_id="seq_x")
        assert "- Finish on reply: off" in out
        assert "- Same thread: off" in out
        assert "- Wait for new contacts: off" in out

    def test_trailing_newline(self):
        out = render_sequence_detail_text_fallback(
            sequence=_sample_sequence(),
            sequence_id="seq_abc123",
            contacts=_sample_contacts(),
        )
        assert out.endswith("\n")
        assert not out.endswith("\n\n")

    def test_id_precedence_sequence_dict_wins(self):
        seq = _sample_sequence()
        # caller passes a different sequence_id than the sequence dict's own id
        out = render_sequence_detail_text_fallback(
            sequence=seq, sequence_id="different_id"
        )
        # "id" line uses dict id; drill-down uses dict id too
        assert "id: `seq_abc123`" in out
        assert "g8://sequences/seq_abc123/preview" in out
