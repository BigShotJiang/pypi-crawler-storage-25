"""Unit tests for Surface #63 — `render_persona_detail_html` / text fallback.

Per-persona detail: `g8://personas/{persona_id}` (+ `.txt` sibling).
Mirrors the structure of test_icp_detail_renderer.py (Surface #62).

graph8-native design: only `_G8_*` tokens — no Studio legacy hexes
(`#eef2ff`, `#4338ca`, `#f59e0b`, etc.). Every regression lock test
enforces this.
"""

from __future__ import annotations

import pytest

from mcp_server.g8_mcp_server import app_renderer as ar


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


_PERSONA_ID = "p-vp-eng-midmarket"


_SAMPLE_PERSONA: dict = {
    "id": _PERSONA_ID,
    "title": "VP Engineering @ Mid-Market SaaS",
    "priority": "high",
    "confidence": "medium",
    "status": "active",
    "pinned": True,
    "why_target": (
        "VP Eng owns developer velocity budget and tooling decisions. "
        "They are the primary economic buyer for developer productivity "
        "tools in a 100-500 eng org."
    ),
    "campaign_approach": (
        "Lead with developer velocity metrics + peer benchmarks. "
        "Avoid generic 'AI' pitches — they've been burned. Tie every "
        "claim to a shipped customer outcome."
    ),
    "expected_receptivity": "High during Q4 planning cycle",
    "recommended_goal": "Book a 30-min tooling audit call",
    "key_signals": [
        "Hiring SRE / platform engineers",
        "Posting about dev velocity on LinkedIn",
        "Recently switched to monorepo",
        "Open roles mention 'developer experience'",
    ],
}


# Legacy Studio hexes from the persona dashboard that this surface
# deliberately migrates away from.
_LEGACY_STUDIO_HEXES = (
    "#eef2ff",  # old signal chip bg
    "#4338ca",  # old signal chip fg
    "#f59e0b",  # old pinned star
    "#166534",  # old priority:high bg (duplicated from ICP palette)
    "#a16207",  # old priority:medium bg
    "#7c2d12",  # old priority:low bg
    "#6b7280",  # gray fallback
)


# ---------------------------------------------------------------------------
# _persona_detail_clip
# ---------------------------------------------------------------------------


class TestClip:
    def test_none(self):
        assert ar._persona_detail_clip(None, 100) == ""

    def test_non_string(self):
        assert ar._persona_detail_clip(42, 100) == ""
        assert ar._persona_detail_clip(["x"], 100) == ""
        assert ar._persona_detail_clip({"x": 1}, 100) == ""

    def test_whitespace(self):
        assert ar._persona_detail_clip("   ", 100) == ""
        assert ar._persona_detail_clip("\n\t", 100) == ""

    def test_under_cap(self):
        assert ar._persona_detail_clip("hello", 100) == "hello"

    def test_at_cap(self):
        # cap=5, len=5 — no ellipsis
        assert ar._persona_detail_clip("hello", 5) == "hello"

    def test_over_cap(self):
        # cap=5, len>5 — truncated with ellipsis
        result = ar._persona_detail_clip("hello world", 5)
        assert result.endswith("…")
        assert len(result) == 5

    def test_escape(self):
        assert ar._persona_detail_clip("<script>", 100) == "&lt;script&gt;"

    def test_escape_amp(self):
        assert ar._persona_detail_clip("a & b", 100) == "a &amp; b"

    def test_strip_then_clip(self):
        assert ar._persona_detail_clip("  hi  ", 100) == "hi"


# ---------------------------------------------------------------------------
# _persona_detail_title
# ---------------------------------------------------------------------------


class TestTitle:
    def test_title_present(self):
        assert ar._persona_detail_title({"title": "VP Eng"}, "p-1") == "VP Eng"

    def test_title_whitespace_fallback(self):
        assert ar._persona_detail_title({"title": "   "}, "p-1") == "Persona #p-1"

    def test_none_persona_with_id(self):
        assert ar._persona_detail_title(None, "p-1") == "Persona #p-1"

    def test_none_persona_no_id(self):
        assert ar._persona_detail_title(None, "") == "Persona"

    def test_non_dict_persona(self):
        assert ar._persona_detail_title("nope", "p-1") == "Persona #p-1"  # type: ignore[arg-type]

    def test_title_clipped(self):
        long = "x" * (ar._MAX_PERSONA_DETAIL_TITLE_LEN + 100)
        result = ar._persona_detail_title({"title": long}, "p-1")
        assert result.endswith("…")
        assert len(result) == ar._MAX_PERSONA_DETAIL_TITLE_LEN

    def test_title_escaped(self):
        assert ar._persona_detail_title({"title": "<b>Evil</b>"}, "p-1") == "&lt;b&gt;Evil&lt;/b&gt;"

    def test_id_escaped(self):
        assert "&lt;" in ar._persona_detail_title(None, "<xss>")

    def test_id_clipped(self):
        pid = "a" * 200
        result = ar._persona_detail_title(None, pid)
        # id portion clipped to 80 chars (via str(persona_id)[:80])
        assert "Persona #" in result


# ---------------------------------------------------------------------------
# _persona_detail_priority_accent
# ---------------------------------------------------------------------------


class TestPriorityAccent:
    def test_high(self):
        bg, fg, border = ar._persona_detail_priority_accent("high")
        assert bg == ar._G8_POSITIVE_BG
        assert fg == ar._G8_POSITIVE_FG

    def test_medium(self):
        bg, fg, border = ar._persona_detail_priority_accent("medium")
        assert bg == ar._G8_ACCENT_BG
        assert fg == ar._G8_PRIMARY

    def test_low(self):
        bg, fg, border = ar._persona_detail_priority_accent("low")
        assert bg == ar._G8_WARNING_BG
        assert fg == ar._G8_WARNING_FG

    def test_unknown(self):
        bg, fg, border = ar._persona_detail_priority_accent("chimera")
        assert bg == ar._G8_MUTED_BG
        assert fg == ar._G8_TEXT_MUTED

    def test_none(self):
        bg, fg, border = ar._persona_detail_priority_accent(None)
        assert bg == ar._G8_MUTED_BG

    def test_non_string(self):
        bg, fg, border = ar._persona_detail_priority_accent(3)
        assert bg == ar._G8_MUTED_BG

    def test_case_insensitive(self):
        assert ar._persona_detail_priority_accent("HIGH")[0] == ar._G8_POSITIVE_BG
        assert ar._persona_detail_priority_accent("High")[0] == ar._G8_POSITIVE_BG

    def test_aliases(self):
        assert ar._persona_detail_priority_accent("p1")[0] == ar._G8_POSITIVE_BG
        assert ar._persona_detail_priority_accent("top")[0] == ar._G8_POSITIVE_BG
        assert ar._persona_detail_priority_accent("p2")[0] == ar._G8_ACCENT_BG
        assert ar._persona_detail_priority_accent("backlog")[0] == ar._G8_WARNING_BG


# ---------------------------------------------------------------------------
# _persona_detail_confidence_accent
# ---------------------------------------------------------------------------


class TestConfidenceAccent:
    def test_high(self):
        bg, fg, _ = ar._persona_detail_confidence_accent("high")
        assert bg == ar._G8_POSITIVE_BG

    def test_medium(self):
        bg, fg, _ = ar._persona_detail_confidence_accent("medium")
        assert bg == ar._G8_ACCENT_BG

    def test_low(self):
        bg, fg, _ = ar._persona_detail_confidence_accent("low")
        assert bg == ar._G8_WARNING_BG

    def test_unknown(self):
        bg, fg, _ = ar._persona_detail_confidence_accent("?")
        assert bg == ar._G8_MUTED_BG

    def test_none(self):
        bg, fg, _ = ar._persona_detail_confidence_accent(None)
        assert bg == ar._G8_MUTED_BG

    def test_aliases(self):
        assert ar._persona_detail_confidence_accent("strong")[0] == ar._G8_POSITIVE_BG
        assert ar._persona_detail_confidence_accent("moderate")[0] == ar._G8_ACCENT_BG
        assert ar._persona_detail_confidence_accent("weak")[0] == ar._G8_WARNING_BG


# ---------------------------------------------------------------------------
# _persona_detail_priority
# ---------------------------------------------------------------------------


class TestPriority:
    def test_none_persona(self):
        assert ar._persona_detail_priority(None) == ""

    def test_non_dict(self):
        assert ar._persona_detail_priority("nope") == ""  # type: ignore[arg-type]

    def test_missing(self):
        assert ar._persona_detail_priority({}) == ""

    def test_none_value(self):
        assert ar._persona_detail_priority({"priority": None}) == ""

    def test_bool(self):
        # bool is subclass of int but we want to reject it
        assert ar._persona_detail_priority({"priority": True}) == ""
        assert ar._persona_detail_priority({"priority": False}) == ""

    def test_int(self):
        assert ar._persona_detail_priority({"priority": 1}) == "1"

    def test_float_integer(self):
        assert ar._persona_detail_priority({"priority": 2.0}) == "2"

    def test_float_decimal(self):
        assert ar._persona_detail_priority({"priority": 1.5}) == "1.5"

    def test_string(self):
        assert ar._persona_detail_priority({"priority": "high"}) == "high"

    def test_whitespace_string(self):
        assert ar._persona_detail_priority({"priority": "   "}) == ""

    def test_long_string_clipped(self):
        assert len(ar._persona_detail_priority({"priority": "x" * 100})) == 16

    def test_nan(self):
        assert ar._persona_detail_priority({"priority": float("nan")}) == ""

    def test_inf(self):
        assert ar._persona_detail_priority({"priority": float("inf")}) == ""


# ---------------------------------------------------------------------------
# _persona_detail_confidence / _persona_detail_status
# ---------------------------------------------------------------------------


class TestConfidence:
    def test_none_persona(self):
        assert ar._persona_detail_confidence(None) == ""

    def test_missing(self):
        assert ar._persona_detail_confidence({}) == ""

    def test_non_string(self):
        assert ar._persona_detail_confidence({"confidence": 0.9}) == ""

    def test_whitespace(self):
        assert ar._persona_detail_confidence({"confidence": "   "}) == ""

    def test_normal(self):
        assert ar._persona_detail_confidence({"confidence": "medium"}) == "medium"

    def test_clipped(self):
        assert len(ar._persona_detail_confidence({"confidence": "x" * 50})) == 16


class TestStatus:
    def test_none_persona(self):
        assert ar._persona_detail_status(None) == ""

    def test_missing(self):
        assert ar._persona_detail_status({}) == ""

    def test_non_string(self):
        assert ar._persona_detail_status({"status": 42}) == ""

    def test_whitespace(self):
        assert ar._persona_detail_status({"status": " \n "}) == ""

    def test_normal(self):
        assert ar._persona_detail_status({"status": "active"}) == "active"

    def test_clipped(self):
        assert len(ar._persona_detail_status({"status": "y" * 100})) == 32


# ---------------------------------------------------------------------------
# _persona_detail_is_pinned
# ---------------------------------------------------------------------------


class TestIsPinned:
    def test_none(self):
        assert ar._persona_detail_is_pinned(None) is False

    def test_non_dict(self):
        assert ar._persona_detail_is_pinned("no") is False  # type: ignore[arg-type]

    def test_missing(self):
        assert ar._persona_detail_is_pinned({}) is False

    def test_false(self):
        assert ar._persona_detail_is_pinned({"pinned": False}) is False

    def test_true(self):
        assert ar._persona_detail_is_pinned({"pinned": True}) is True

    def test_truthy_string(self):
        assert ar._persona_detail_is_pinned({"pinned": "yes"}) is True

    def test_falsy_zero(self):
        assert ar._persona_detail_is_pinned({"pinned": 0}) is False


# ---------------------------------------------------------------------------
# _persona_detail_extract_signals
# ---------------------------------------------------------------------------


class TestExtractSignals:
    def test_none_persona(self):
        assert ar._persona_detail_extract_signals(None) == []

    def test_non_dict(self):
        assert ar._persona_detail_extract_signals("no") == []  # type: ignore[arg-type]

    def test_missing(self):
        assert ar._persona_detail_extract_signals({}) == []

    def test_non_list(self):
        assert ar._persona_detail_extract_signals({"key_signals": "oops"}) == []

    def test_empty_list(self):
        assert ar._persona_detail_extract_signals({"key_signals": []}) == []

    def test_non_string_items_filtered(self):
        out = ar._persona_detail_extract_signals(
            {"key_signals": ["ok", 42, None, "", "  ", "good"]}
        )
        assert out == ["ok", "good"]

    def test_long_clipped(self):
        long = "x" * (ar._MAX_PERSONA_DETAIL_SIGNAL_LEN + 100)
        out = ar._persona_detail_extract_signals({"key_signals": [long]})
        assert len(out) == 1
        assert out[0].endswith("…")
        assert len(out[0]) == ar._MAX_PERSONA_DETAIL_SIGNAL_LEN

    def test_cap(self):
        many = [f"sig-{i}" for i in range(ar._MAX_PERSONA_DETAIL_SIGNALS + 10)]
        out = ar._persona_detail_extract_signals({"key_signals": many})
        assert len(out) == ar._MAX_PERSONA_DETAIL_SIGNALS

    def test_stripped(self):
        out = ar._persona_detail_extract_signals({"key_signals": ["  trim me  "]})
        assert out == ["trim me"]


# ---------------------------------------------------------------------------
# _persona_detail_chip
# ---------------------------------------------------------------------------


class TestChip:
    def test_default(self):
        out = ar._persona_detail_chip("hello")
        assert "hello" in out
        assert ar._G8_MUTED_BG in out
        assert "<span" in out

    def test_escape(self):
        out = ar._persona_detail_chip("<script>")
        assert "&lt;script&gt;" in out
        assert "<script>" not in out.replace("<span", "").replace("</span", "")

    def test_custom_colors(self):
        out = ar._persona_detail_chip("x", bg="#123456", fg="#abcdef", border="#deadbe")
        assert "#123456" in out
        assert "#abcdef" in out
        assert "#deadbe" in out


# ---------------------------------------------------------------------------
# _persona_detail_rich_text
# ---------------------------------------------------------------------------


class TestRichText:
    def test_none(self):
        assert ar._persona_detail_rich_text(None, 100) == ""

    def test_non_string(self):
        assert ar._persona_detail_rich_text(42, 100) == ""

    def test_whitespace(self):
        assert ar._persona_detail_rich_text("   ", 100) == ""

    def test_normal(self):
        assert ar._persona_detail_rich_text("hello", 100) == "hello"

    def test_newline_to_br(self):
        assert ar._persona_detail_rich_text("a\nb", 100) == "a<br>b"

    def test_escape(self):
        assert ar._persona_detail_rich_text("<b>", 100) == "&lt;b&gt;"

    def test_clipped(self):
        out = ar._persona_detail_rich_text("x" * 50, 10)
        assert out.endswith("…")
        assert len(out) == 10

    def test_escape_then_br(self):
        # <script> escaped first, then newline -> <br>
        out = ar._persona_detail_rich_text("<script>\npayload", 100)
        assert "&lt;script&gt;<br>payload" == out


# ---------------------------------------------------------------------------
# _persona_detail_section / _persona_detail_meta_row / _persona_detail_meta_section
# ---------------------------------------------------------------------------


class TestSection:
    def test_empty_body_returns_empty(self):
        assert ar._persona_detail_section("Why", "") == ""

    def test_basic(self):
        out = ar._persona_detail_section("Why", "body text")
        assert "Why" in out
        assert "body text" in out
        assert ar._G8_BORDER in out

    def test_title_escaped(self):
        out = ar._persona_detail_section("<b>Why</b>", "body")
        assert "&lt;b&gt;Why&lt;/b&gt;" in out


class TestMetaSection:
    def test_empty(self):
        assert ar._persona_detail_meta_section([]) == ""

    def test_basic(self):
        out = ar._persona_detail_meta_section([("Receptivity", "high"), ("Goal", "book call")])
        assert "Receptivity" in out
        assert "high" in out
        assert "Goal" in out
        assert "book call" in out

    def test_escape(self):
        out = ar._persona_detail_meta_section([("<L>", "<V>")])
        assert "&lt;L&gt;" in out
        assert "&lt;V&gt;" in out


class TestSignalsSection:
    def test_empty(self):
        assert ar._persona_detail_signals_section([]) == ""

    def test_basic(self):
        out = ar._persona_detail_signals_section(["a", "b"])
        assert "a" in out
        assert "b" in out
        assert ar._G8_ACCENT_BG in out
        assert ar._G8_PRIMARY in out

    def test_escape(self):
        out = ar._persona_detail_signals_section(["<xss>"])
        assert "&lt;xss&gt;" in out


# ---------------------------------------------------------------------------
# _persona_detail_empty_state_html
# ---------------------------------------------------------------------------


class TestEmptyStateHtml:
    def test_not_found(self):
        out = ar._persona_detail_empty_state_html(mode="not_found", persona_id="p-1")
        assert "not found" in out.lower()
        assert "p-1" in out
        assert ar._G8_ACCENT_BG in out

    def test_unavailable(self):
        out = ar._persona_detail_empty_state_html(mode="unavailable", persona_id="p-1")
        assert "not available" in out.lower()
        assert ar._G8_MUTED_BG in out

    def test_id_escaped(self):
        out = ar._persona_detail_empty_state_html(mode="not_found", persona_id="<xss>")
        assert "&lt;xss&gt;" in out
        assert "<xss>" not in out

    def test_no_js(self):
        out = ar._persona_detail_empty_state_html(mode="not_found", persona_id="p-1")
        assert "<script" not in out.lower()
        assert "javascript:" not in out.lower()

    def test_id_clipped(self):
        pid = "a" * 200
        out = ar._persona_detail_empty_state_html(mode="not_found", persona_id=pid)
        # id portion clipped to 80 chars
        assert "aaaaaaaaaa" in out


# ---------------------------------------------------------------------------
# render_persona_detail_html
# ---------------------------------------------------------------------------


class TestRenderHtml:
    def test_full_happy_path(self):
        out = ar.render_persona_detail_html(
            persona_id=_PERSONA_ID, persona=_SAMPLE_PERSONA
        )
        assert out.startswith("<!DOCTYPE html>")
        assert out.endswith("</html>")
        assert "VP Engineering" in out
        assert "Priority high" in out
        assert "Confidence: medium" in out
        assert "ACTIVE" in out
        assert "★" in out  # pinned
        assert "Why Target" in out
        assert "Campaign Approach" in out
        assert "Key Signals" in out
        assert "Hiring SRE" in out

    def test_none_persona(self):
        out = ar.render_persona_detail_html(persona_id="p-1", persona=None)
        assert "not available" in out.lower()

    def test_non_dict_persona(self):
        out = ar.render_persona_detail_html(persona_id="p-1", persona="nope")  # type: ignore[arg-type]
        assert "not available" in out.lower()

    def test_id_mismatch_renders_not_found(self):
        persona = {"id": "different", "title": "x"}
        out = ar.render_persona_detail_html(persona_id="p-1", persona=persona)
        assert "not found" in out.lower()

    def test_id_match_renders_normally(self):
        persona = {"id": "p-match", "title": "Ok"}
        out = ar.render_persona_detail_html(persona_id="p-match", persona=persona)
        assert "not found" not in out.lower()
        assert "Ok" in out

    def test_xss_title(self):
        persona = dict(_SAMPLE_PERSONA, title="<script>alert(1)</script>")
        out = ar.render_persona_detail_html(persona_id=_PERSONA_ID, persona=persona)
        assert "<script>alert(1)</script>" not in out
        assert "&lt;script&gt;" in out

    def test_xss_why_target(self):
        persona = dict(_SAMPLE_PERSONA, why_target="<img onerror=1>")
        out = ar.render_persona_detail_html(persona_id=_PERSONA_ID, persona=persona)
        assert "<img onerror=1>" not in out
        assert "&lt;img" in out

    def test_xss_campaign_approach(self):
        persona = dict(_SAMPLE_PERSONA, campaign_approach="<b onload=1>")
        out = ar.render_persona_detail_html(persona_id=_PERSONA_ID, persona=persona)
        assert "<b onload=1>" not in out
        assert "&lt;b" in out

    def test_xss_key_signals(self):
        persona = dict(_SAMPLE_PERSONA, key_signals=["<script>"])
        out = ar.render_persona_detail_html(persona_id=_PERSONA_ID, persona=persona)
        assert "<script>" not in out.replace("<script", "X")  # allow tag scan
        assert "&lt;script&gt;" in out

    def test_xss_receptivity(self):
        persona = dict(_SAMPLE_PERSONA, expected_receptivity="<script>")
        out = ar.render_persona_detail_html(persona_id=_PERSONA_ID, persona=persona)
        assert "&lt;script&gt;" in out

    def test_xss_goal(self):
        persona = dict(_SAMPLE_PERSONA, recommended_goal="<script>")
        out = ar.render_persona_detail_html(persona_id=_PERSONA_ID, persona=persona)
        assert "&lt;script&gt;" in out

    def test_no_script_tags(self):
        out = ar.render_persona_detail_html(persona_id=_PERSONA_ID, persona=_SAMPLE_PERSONA)
        # No actual executable <script> tag — we use <style> rules inline
        lower = out.lower()
        assert "<script" not in lower
        assert "javascript:" not in lower

    def test_no_legacy_hexes(self):
        out = ar.render_persona_detail_html(persona_id=_PERSONA_ID, persona=_SAMPLE_PERSONA)
        for hex_ in _LEGACY_STUDIO_HEXES:
            assert hex_ not in out.lower(), (
                f"legacy Studio hex {hex_} leaked into persona detail HTML"
            )

    def test_uses_graph8_primary(self):
        # priority=medium → _G8_ACCENT_BG + _G8_PRIMARY chip
        persona = dict(_SAMPLE_PERSONA, priority="medium", confidence="medium")
        out = ar.render_persona_detail_html(persona_id=_PERSONA_ID, persona=persona)
        assert ar._G8_PRIMARY in out
        assert ar._G8_ACCENT_BG in out

    def test_uses_graph8_positive(self):
        # priority=high + confidence=high → _G8_POSITIVE_*
        persona = dict(_SAMPLE_PERSONA, priority="high", confidence="high")
        out = ar.render_persona_detail_html(persona_id=_PERSONA_ID, persona=persona)
        assert ar._G8_POSITIVE_BG in out
        assert ar._G8_POSITIVE_FG in out

    def test_uses_graph8_warning_for_low(self):
        persona = dict(_SAMPLE_PERSONA, priority="low", confidence="low")
        out = ar.render_persona_detail_html(persona_id=_PERSONA_ID, persona=persona)
        assert ar._G8_WARNING_BG in out

    def test_uses_aeonik_font(self):
        out = ar.render_persona_detail_html(persona_id=_PERSONA_ID, persona=_SAMPLE_PERSONA)
        assert "Aeonik" in out

    def test_uses_g8_border(self):
        out = ar.render_persona_detail_html(persona_id=_PERSONA_ID, persona=_SAMPLE_PERSONA)
        assert ar._G8_BORDER in out

    def test_no_single_side_colored_accent_border(self):
        """Regression: no border-left/right/top/bottom with colored accent.

        Surface-level violation — single-side colored borders break the
        graph8 design language. All accents should be either full
        chips/pills or subtle uniform borders.
        """
        out = ar.render_persona_detail_html(persona_id=_PERSONA_ID, persona=_SAMPLE_PERSONA)
        forbidden = (
            f"border-left:{ar._G8_PRIMARY}",
            f"border-left: {ar._G8_PRIMARY}",
            f"border-right:{ar._G8_PRIMARY}",
            f"border-top:{ar._G8_PRIMARY}",
            f"border-bottom:{ar._G8_PRIMARY}",
        )
        for f in forbidden:
            assert f not in out, f"single-side accent border found: {f}"

    def test_drill_up_card_present(self):
        out = ar.render_persona_detail_html(persona_id=_PERSONA_ID, persona=_SAMPLE_PERSONA)
        assert "Related surfaces" in out
        assert "g8://personas/dashboard" in out
        assert "g8://icps/dashboard" in out
        assert "g8://global-context/library" in out
        assert "g8://contacts/dashboard" in out
        assert "g8://copilot/home" in out
        assert "g8_search_contacts" in out

    def test_drill_up_does_NOT_list_self(self):
        """The detail card must not suggest itself as a related surface."""
        out = ar.render_persona_detail_html(persona_id=_PERSONA_ID, persona=_SAMPLE_PERSONA)
        # The URI pattern `g8://personas/{persona_id}` should not appear
        # as a link in the drill-up list (only the literal dashboard URI).
        assert "g8://personas/{persona_id}" not in out

    def test_pinned_star_only_when_pinned(self):
        persona = dict(_SAMPLE_PERSONA, pinned=False)
        out = ar.render_persona_detail_html(persona_id=_PERSONA_ID, persona=persona)
        # Pinned <span> has title="Pinned" — should NOT appear
        assert 'title="Pinned"' not in out

    def test_pinned_star_when_pinned(self):
        persona = dict(_SAMPLE_PERSONA, pinned=True)
        out = ar.render_persona_detail_html(persona_id=_PERSONA_ID, persona=persona)
        assert 'title="Pinned"' in out

    def test_empty_signals_no_section(self):
        persona = dict(_SAMPLE_PERSONA, key_signals=[])
        out = ar.render_persona_detail_html(persona_id=_PERSONA_ID, persona=persona)
        assert "Key Signals" not in out

    def test_no_why_target_no_section(self):
        persona = dict(_SAMPLE_PERSONA, why_target="")
        out = ar.render_persona_detail_html(persona_id=_PERSONA_ID, persona=persona)
        assert "Why Target" not in out

    def test_no_approach_no_section(self):
        persona = dict(_SAMPLE_PERSONA, campaign_approach="")
        out = ar.render_persona_detail_html(persona_id=_PERSONA_ID, persona=persona)
        assert "Campaign Approach" not in out

    def test_no_overview_rows_no_meta_section(self):
        persona = dict(_SAMPLE_PERSONA, expected_receptivity="", recommended_goal="")
        out = ar.render_persona_detail_html(persona_id=_PERSONA_ID, persona=persona)
        assert "Overview" not in out

    def test_empty_persona_minimal(self):
        out = ar.render_persona_detail_html(persona_id="p-min", persona={"id": "p-min"})
        assert "Persona" in out  # title fallback
        assert "not found" not in out.lower()
        assert "not available" not in out.lower()

    def test_persona_id_empty(self):
        # Defensive — empty persona_id + valid persona
        persona = {"title": "Fine"}
        out = ar.render_persona_detail_html(persona_id="", persona=persona)
        assert "Fine" in out

    def test_html_has_doctype(self):
        out = ar.render_persona_detail_html(persona_id=_PERSONA_ID, persona=_SAMPLE_PERSONA)
        assert out.startswith("<!DOCTYPE html>")

    def test_title_in_head(self):
        out = ar.render_persona_detail_html(persona_id=_PERSONA_ID, persona=_SAMPLE_PERSONA)
        assert "<title>Persona: VP Engineering" in out

    def test_long_why_target_clipped(self):
        persona = dict(_SAMPLE_PERSONA, why_target="y" * 5000)
        out = ar.render_persona_detail_html(persona_id=_PERSONA_ID, persona=persona)
        assert "…" in out

    def test_long_approach_clipped(self):
        persona = dict(_SAMPLE_PERSONA, campaign_approach="z" * 5000)
        out = ar.render_persona_detail_html(persona_id=_PERSONA_ID, persona=persona)
        assert "…" in out


# ---------------------------------------------------------------------------
# render_persona_detail_text_fallback
# ---------------------------------------------------------------------------


class TestTextFallback:
    def test_happy_path(self):
        out = ar.render_persona_detail_text_fallback(
            persona_id=_PERSONA_ID, persona=_SAMPLE_PERSONA
        )
        assert out.startswith("# VP Engineering")
        assert "★" in out
        assert "Priority high" in out
        assert "Confidence: medium" in out
        assert "ACTIVE" in out
        assert "## Overview" in out
        assert "- **Expected Receptivity:**" in out
        assert "- **Recommended Goal:**" in out
        assert "## Why Target" in out
        assert "## Campaign Approach" in out
        assert "## Key Signals" in out
        assert "## Related surfaces" in out
        assert "g8://personas/dashboard" in out

    def test_none_persona(self):
        out = ar.render_persona_detail_text_fallback(persona_id="p-1", persona=None)
        assert "Persona detail not available" in out

    def test_non_dict(self):
        out = ar.render_persona_detail_text_fallback(persona_id="p-1", persona="no")  # type: ignore[arg-type]
        assert "Persona detail not available" in out

    def test_id_mismatch(self):
        out = ar.render_persona_detail_text_fallback(
            persona_id="p-1", persona={"id": "other", "title": "x"}
        )
        assert "Persona not found" in out

    def test_id_match(self):
        out = ar.render_persona_detail_text_fallback(
            persona_id="p-ok", persona={"id": "p-ok", "title": "x"}
        )
        assert "Persona not found" not in out

    def test_not_pinned_no_star(self):
        persona = dict(_SAMPLE_PERSONA, pinned=False)
        out = ar.render_persona_detail_text_fallback(persona_id=_PERSONA_ID, persona=persona)
        first_line = out.splitlines()[0]
        assert "★" not in first_line

    def test_empty_signals_no_section(self):
        persona = dict(_SAMPLE_PERSONA, key_signals=[])
        out = ar.render_persona_detail_text_fallback(persona_id=_PERSONA_ID, persona=persona)
        assert "## Key Signals" not in out

    def test_no_overview_fields(self):
        persona = dict(_SAMPLE_PERSONA, expected_receptivity="", recommended_goal="")
        out = ar.render_persona_detail_text_fallback(persona_id=_PERSONA_ID, persona=persona)
        assert "## Overview" not in out

    def test_no_why_target(self):
        persona = dict(_SAMPLE_PERSONA, why_target="")
        out = ar.render_persona_detail_text_fallback(persona_id=_PERSONA_ID, persona=persona)
        assert "## Why Target" not in out

    def test_title_fallback(self):
        out = ar.render_persona_detail_text_fallback(persona_id="p-nope", persona={"id": "p-nope"})
        assert "# Persona #p-nope" in out

    def test_trailing_newline(self):
        out = ar.render_persona_detail_text_fallback(
            persona_id=_PERSONA_ID, persona=_SAMPLE_PERSONA
        )
        assert out.endswith("\n")


# ---------------------------------------------------------------------------
# Smoke — end-to-end
# ---------------------------------------------------------------------------


class TestSmoke:
    def test_both_renderers_roundtrip(self):
        """Sanity check: both renderers produce non-empty output for the sample."""
        h = ar.render_persona_detail_html(persona_id=_PERSONA_ID, persona=_SAMPLE_PERSONA)
        t = ar.render_persona_detail_text_fallback(
            persona_id=_PERSONA_ID, persona=_SAMPLE_PERSONA
        )
        assert len(h) > 500
        assert len(t) > 200

    def test_html_no_raw_newlines_in_attrs(self):
        out = ar.render_persona_detail_html(
            persona_id=_PERSONA_ID,
            persona=dict(_SAMPLE_PERSONA, why_target="line1\nline2"),
        )
        # newline should have been converted to <br>
        assert "<br>" in out
