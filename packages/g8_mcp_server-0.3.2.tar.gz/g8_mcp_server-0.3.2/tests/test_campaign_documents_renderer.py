"""Tests for the campaign documents renderer (upgrade 4 — surface #21).

Covers:
  - `_campaign_doc_status_palette` (known/unknown/None/case/whitespace)
  - `_campaign_doc_type_palette` (exact match + prefix fallback + default)
  - `_group_campaign_docs_by_folder` (ordering, fallback, alphabetical tail)
  - `_sort_campaign_docs` (ready first, failed last, alpha tiebreaker)
  - `render_campaign_documents_html` (empty / header / grouping / chips /
    caps / overflow / HTML escape)
  - `render_campaign_documents_text_fallback` (empty / header / structure)
"""

from __future__ import annotations

from g8_mcp_server.app_renderer import (
    _CAMPAIGN_DOC_STATUS_DEFAULT,
    _CAMPAIGN_DOC_TYPE_DEFAULT,
    _MAX_CAMPAIGN_DOC_TITLE_LEN,
    _MAX_CAMPAIGN_DOCS_RENDERED,
    _campaign_doc_status_palette,
    _campaign_doc_type_palette,
    _group_campaign_docs_by_folder,
    _sort_campaign_docs,
    render_campaign_documents_html,
    render_campaign_documents_text_fallback,
)


def _doc(
    id_: str = "doc_1",
    file_type: str | None = "brief",
    display_name: str | None = "Campaign Brief",
    folder_path: str | None = "strategy",
    status: str | None = "ready",
    updated_at: str | None = "2026-04-20T10:00:00Z",
) -> dict:
    return {
        "id": id_,
        "file_type": file_type,
        "display_name": display_name,
        "folder_path": folder_path,
        "status": status,
        "updated_at": updated_at,
    }


# ---------------------------------------------------------------------------
# _campaign_doc_status_palette
# ---------------------------------------------------------------------------


class TestCampaignDocStatusPalette:
    def test_ready_green(self):
        p = _campaign_doc_status_palette("ready")
        # Migrated to graph8 token (_G8_POSITIVE_FG) — was banned #166534
        assert p["fg"] == "#059669"

    def test_completed_green(self):
        p = _campaign_doc_status_palette("completed")
        assert p["fg"] == "#059669"  # was banned #166534

    def test_generating_blue(self):
        p = _campaign_doc_status_palette("generating")
        assert p["fg"] == "#1e40af"

    def test_pending_indigo(self):
        p = _campaign_doc_status_palette("pending")
        assert p["fg"] == "#7d2df3"

    def test_queued_indigo(self):
        p = _campaign_doc_status_palette("queued")
        assert p["fg"] == "#7d2df3"

    def test_stale_amber(self):
        p = _campaign_doc_status_palette("stale")
        assert p["fg"] == "#92400e"

    def test_failed_red(self):
        p = _campaign_doc_status_palette("failed")
        assert p["fg"] == "#b91c1c"  # was banned #991b1b

    def test_error_red(self):
        p = _campaign_doc_status_palette("error")
        assert p["fg"] == "#b91c1c"  # was banned #991b1b

    def test_no_banned_hexes_in_status_palette(self):
        """Lock test — no banned Studio hex reintroduced into status palette."""
        from g8_mcp_server.app_renderer import _CAMPAIGN_DOC_STATUS_COLORS

        banned = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}
        for _status, pal in _CAMPAIGN_DOC_STATUS_COLORS.items():
            for _channel, value in pal.items():
                assert value.lower() not in banned, (
                    f"banned Studio hex {value} resurfaced in status palette"
                )

    def test_case_insensitive(self):
        assert _campaign_doc_status_palette("READY") == _campaign_doc_status_palette("ready")

    def test_whitespace_stripped(self):
        assert _campaign_doc_status_palette("  ready  ") == _campaign_doc_status_palette("ready")

    def test_none_defaults(self):
        assert _campaign_doc_status_palette(None) == _CAMPAIGN_DOC_STATUS_DEFAULT

    def test_empty_defaults(self):
        assert _campaign_doc_status_palette("") == _CAMPAIGN_DOC_STATUS_DEFAULT

    def test_unknown_defaults(self):
        assert _campaign_doc_status_palette("weird_unknown_status") == _CAMPAIGN_DOC_STATUS_DEFAULT

    def test_returns_bg_fg_border(self):
        p = _campaign_doc_status_palette("ready")
        assert "bg" in p and "fg" in p and "border" in p


# ---------------------------------------------------------------------------
# _campaign_doc_type_palette
# ---------------------------------------------------------------------------


class TestCampaignDocTypePalette:
    def test_brief_indigo(self):
        p = _campaign_doc_type_palette("brief")
        assert p["fg"] == "#7d2df3"

    def test_strategy_indigo(self):
        p = _campaign_doc_type_palette("strategy")
        assert p["fg"] == "#7d2df3"

    def test_icp_indigo(self):
        p = _campaign_doc_type_palette("icp")
        assert p["fg"] == "#7d2df3"

    def test_persona_indigo(self):
        p = _campaign_doc_type_palette("persona")
        assert p["fg"] == "#7d2df3"

    def test_messaging_purple(self):
        p = _campaign_doc_type_palette("messaging")
        assert p["fg"] == "#6b21a8"

    def test_email_purple(self):
        p = _campaign_doc_type_palette("email")
        assert p["fg"] == "#6b21a8"

    def test_sequence_purple(self):
        p = _campaign_doc_type_palette("sequence")
        assert p["fg"] == "#6b21a8"

    def test_landing_purple(self):
        p = _campaign_doc_type_palette("landing")
        assert p["fg"] == "#6b21a8"

    def test_landing_page_purple(self):
        p = _campaign_doc_type_palette("landing_page")
        assert p["fg"] == "#6b21a8"

    def test_ad_copy_teal(self):
        p = _campaign_doc_type_palette("ad_copy")
        assert p["fg"] == "#0f766e"

    def test_ad_images_teal(self):
        p = _campaign_doc_type_palette("ad_images")
        assert p["fg"] == "#0f766e"

    def test_creative_teal(self):
        p = _campaign_doc_type_palette("creative")
        assert p["fg"] == "#0f766e"

    def test_research_green(self):
        p = _campaign_doc_type_palette("research")
        assert p["fg"] == "#059669"  # was banned #166534

    def test_intelligence_green(self):
        p = _campaign_doc_type_palette("intelligence")
        assert p["fg"] == "#059669"  # was banned #166534

    def test_competitor_green(self):
        p = _campaign_doc_type_palette("competitor")
        assert p["fg"] == "#059669"  # was banned #166534

    def test_no_banned_hexes_in_type_palette(self):
        """Lock test — no banned Studio hex reintroduced into type palette."""
        from g8_mcp_server.app_renderer import _CAMPAIGN_DOC_TYPE_COLORS

        banned = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}
        for _doc_type, pal in _CAMPAIGN_DOC_TYPE_COLORS.items():
            for _channel, value in pal.items():
                assert value.lower() not in banned, (
                    f"banned Studio hex {value} resurfaced in type palette"
                )

    def test_prefix_match_ad_copy_v2(self):
        """Unknown suffix still maps via prefix — 'ad_copy_v2' → 'ad_copy' (teal)."""
        p = _campaign_doc_type_palette("ad_copy_v2")
        assert p["fg"] == "#0f766e"

    def test_prefix_match_email_subject_line(self):
        """'email_subject_line' maps via prefix → 'email' (purple)."""
        p = _campaign_doc_type_palette("email_subject_line")
        assert p["fg"] == "#6b21a8"

    def test_prefix_match_brief_detailed(self):
        """'brief_detailed' maps via prefix → 'brief' (indigo)."""
        p = _campaign_doc_type_palette("brief_detailed")
        assert p["fg"] == "#7d2df3"

    def test_case_insensitive(self):
        assert _campaign_doc_type_palette("BRIEF") == _campaign_doc_type_palette("brief")

    def test_whitespace_stripped(self):
        assert _campaign_doc_type_palette("  brief  ") == _campaign_doc_type_palette("brief")

    def test_none_defaults(self):
        assert _campaign_doc_type_palette(None) == _CAMPAIGN_DOC_TYPE_DEFAULT

    def test_empty_defaults(self):
        assert _campaign_doc_type_palette("") == _CAMPAIGN_DOC_TYPE_DEFAULT

    def test_fully_unknown_defaults(self):
        assert _campaign_doc_type_palette("zzz_xyz") == _CAMPAIGN_DOC_TYPE_DEFAULT


# ---------------------------------------------------------------------------
# _group_campaign_docs_by_folder
# ---------------------------------------------------------------------------


class TestGroupCampaignDocsByFolder:
    def test_empty_returns_empty(self):
        assert _group_campaign_docs_by_folder([]) == {}

    def test_single_folder(self):
        docs = [_doc(folder_path="strategy")]
        result = _group_campaign_docs_by_folder(docs)
        assert list(result.keys()) == ["strategy"]
        assert len(result["strategy"]) == 1

    def test_preferred_order(self):
        """'strategy' precedes 'research' precedes 'email' in the
        preferred-folder list — output must reflect that, not insertion order."""
        docs = [
            _doc(id_="e", folder_path="email"),
            _doc(id_="r", folder_path="research"),
            _doc(id_="s", folder_path="strategy"),
        ]
        result = _group_campaign_docs_by_folder(docs)
        keys = list(result.keys())
        assert keys.index("strategy") < keys.index("research")
        assert keys.index("research") < keys.index("email")

    def test_fallback_to_file_type_when_folder_missing(self):
        """When folder_path is None, group by file_type instead of 'other'."""
        docs = [_doc(folder_path=None, file_type="brief")]
        result = _group_campaign_docs_by_folder(docs)
        assert "brief" in result

    def test_fallback_to_other_when_both_missing(self):
        docs = [_doc(folder_path=None, file_type=None)]
        result = _group_campaign_docs_by_folder(docs)
        assert "other" in result

    def test_unknown_folders_alphabetical(self):
        """Unknown folder names render after preferred ones, alphabetically."""
        docs = [
            _doc(id_="z", folder_path="zulu", file_type="x"),
            _doc(id_="a", folder_path="alpha", file_type="x"),
            _doc(id_="m", folder_path="mike", file_type="x"),
        ]
        result = _group_campaign_docs_by_folder(docs)
        keys = list(result.keys())
        # All three are unknown, so order is alphabetical.
        assert keys == ["alpha", "mike", "zulu"]

    def test_case_insensitive_bucket(self):
        """'Strategy' and 'strategy' merge into one bucket."""
        docs = [
            _doc(id_="a", folder_path="Strategy"),
            _doc(id_="b", folder_path="strategy"),
        ]
        result = _group_campaign_docs_by_folder(docs)
        assert "strategy" in result
        assert len(result["strategy"]) == 2

    def test_whitespace_stripped_bucket_key(self):
        docs = [
            _doc(id_="a", folder_path="  strategy  "),
            _doc(id_="b", folder_path="strategy"),
        ]
        result = _group_campaign_docs_by_folder(docs)
        assert "strategy" in result
        assert len(result["strategy"]) == 2


# ---------------------------------------------------------------------------
# _sort_campaign_docs
# ---------------------------------------------------------------------------


class TestSortCampaignDocs:
    def test_ready_first(self):
        docs = [
            _doc(id_="p", display_name="Pending", status="pending"),
            _doc(id_="r", display_name="Ready", status="ready"),
        ]
        out = _sort_campaign_docs(docs)
        assert out[0]["display_name"] == "Ready"

    def test_completed_also_first(self):
        docs = [
            _doc(id_="g", display_name="Generating", status="generating"),
            _doc(id_="c", display_name="Completed", status="completed"),
        ]
        out = _sort_campaign_docs(docs)
        assert out[0]["display_name"] == "Completed"

    def test_failed_last(self):
        docs = [
            _doc(id_="f", display_name="Failed", status="failed"),
            _doc(id_="g", display_name="Generating", status="generating"),
        ]
        out = _sort_campaign_docs(docs)
        assert out[-1]["display_name"] == "Failed"

    def test_error_last(self):
        docs = [
            _doc(id_="e", display_name="Error", status="error"),
            _doc(id_="g", display_name="Generating", status="generating"),
        ]
        out = _sort_campaign_docs(docs)
        assert out[-1]["display_name"] == "Error"

    def test_alphabetical_within_bucket(self):
        docs = [
            _doc(id_="z", display_name="Zeta", status="ready"),
            _doc(id_="a", display_name="Alpha", status="ready"),
            _doc(id_="m", display_name="Mike", status="ready"),
        ]
        out = _sort_campaign_docs(docs)
        assert [d["display_name"] for d in out] == ["Alpha", "Mike", "Zeta"]

    def test_full_order_ready_middle_failed(self):
        docs = [
            _doc(id_="fx", display_name="Fx", status="failed"),
            _doc(id_="ry", display_name="Ry", status="ready"),
            _doc(id_="mx", display_name="Mx", status="generating"),
        ]
        out = _sort_campaign_docs(docs)
        statuses = [d["status"] for d in out]
        assert statuses == ["ready", "generating", "failed"]

    def test_id_fallback_when_no_name(self):
        docs = [
            _doc(id_="zzz", display_name=None, status="ready"),
            _doc(id_="aaa", display_name=None, status="ready"),
        ]
        out = _sort_campaign_docs(docs)
        assert out[0]["id"] == "aaa"


# ---------------------------------------------------------------------------
# render_campaign_documents_html — empty states
# ---------------------------------------------------------------------------


class TestRenderHtmlEmpty:
    def test_none_returns_empty_state(self):
        html = render_campaign_documents_html(
            documents=None, campaign_id="camp_123", campaign_name="Q4 Push"
        )
        assert "No documents for this campaign yet" in html

    def test_empty_list_returns_empty_state(self):
        html = render_campaign_documents_html(
            documents=[], campaign_id="camp_123", campaign_name="Q4 Push"
        )
        assert "No documents for this campaign yet" in html

    def test_non_list_returns_empty_state(self):
        html = render_campaign_documents_html(
            documents="garbage",  # type: ignore[arg-type]
            campaign_id="camp_123",
            campaign_name="Q4 Push",
        )
        assert "No documents for this campaign yet" in html

    def test_only_garbage_items_returns_empty_state(self):
        """A list of non-dicts should render empty-state, not crash."""
        html = render_campaign_documents_html(
            documents=[1, "x", None],  # type: ignore[list-item]
            campaign_id="camp_123",
            campaign_name="Q4 Push",
        )
        assert "No documents for this campaign yet" in html

    def test_campaign_name_defaults_to_campaign(self):
        """Empty state still works when campaign_name is None."""
        html = render_campaign_documents_html(
            documents=None, campaign_id="camp_123", campaign_name=None
        )
        assert "Campaign" in html

    def test_campaign_id_shown_in_empty_state(self):
        html = render_campaign_documents_html(
            documents=[], campaign_id="camp_unique_id_xyz", campaign_name="X"
        )
        assert "camp_unique_id_xyz" in html

    def test_empty_state_escapes_campaign_id(self):
        html = render_campaign_documents_html(
            documents=[],
            campaign_id="<script>alert(1)</script>",
            campaign_name="X",
        )
        assert "<script>" not in html
        assert "&lt;script&gt;" in html


# ---------------------------------------------------------------------------
# render_campaign_documents_html — populated
# ---------------------------------------------------------------------------


class TestRenderHtmlPopulated:
    def test_header_shows_campaign_name(self):
        html = render_campaign_documents_html(
            documents=[_doc()],
            campaign_id="camp_1",
            campaign_name="Q4 Enterprise Push",
        )
        assert "Q4 Enterprise Push" in html

    def test_header_shows_campaign_id(self):
        html = render_campaign_documents_html(
            documents=[_doc()],
            campaign_id="camp_abc123",
            campaign_name="X",
        )
        assert "camp_abc123" in html

    def test_header_escapes_campaign_name(self):
        html = render_campaign_documents_html(
            documents=[_doc()],
            campaign_id="c1",
            campaign_name="<img src=x onerror=y>",
        )
        assert "<img" not in html or "&lt;img" in html

    def test_header_escapes_campaign_id(self):
        html = render_campaign_documents_html(
            documents=[_doc()],
            campaign_id="<b>bad</b>",
            campaign_name="X",
        )
        assert "<b>bad</b>" not in html
        assert "&lt;b&gt;bad&lt;/b&gt;" in html

    def test_ready_count_rendered(self):
        docs = [
            _doc(id_="a", status="ready"),
            _doc(id_="b", status="generating"),
            _doc(id_="c", status="ready"),
        ]
        html = render_campaign_documents_html(
            documents=docs, campaign_id="c1", campaign_name="X"
        )
        assert "2 ready" in html

    def test_failed_count_rendered_when_nonzero(self):
        docs = [
            _doc(id_="a", status="ready"),
            _doc(id_="b", status="failed"),
        ]
        html = render_campaign_documents_html(
            documents=docs, campaign_id="c1", campaign_name="X"
        )
        assert "1 failed" in html

    def test_failed_count_hidden_when_zero(self):
        """The failed count span should not render at zero — the CSS class
        definition is always present (.cdoc-count-failed) but no actual
        count span should be emitted."""
        docs = [_doc(id_="a", status="ready")]
        html = render_campaign_documents_html(
            documents=docs, campaign_id="c1", campaign_name="X"
        )
        assert "<span class='cdoc-count-failed'>" not in html
        assert "failed</span>" not in html

    def test_folder_header_rendered(self):
        html = render_campaign_documents_html(
            documents=[_doc(folder_path="strategy")],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "Strategy" in html

    def test_folder_underscore_becomes_space(self):
        html = render_campaign_documents_html(
            documents=[_doc(folder_path="landing_page")],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "Landing Page" in html

    def test_folder_ready_count_rendered(self):
        docs = [
            _doc(id_="a", folder_path="strategy", status="ready"),
            _doc(id_="b", folder_path="strategy", status="generating"),
        ]
        html = render_campaign_documents_html(
            documents=docs, campaign_id="c1", campaign_name="X"
        )
        assert "1/2 ready" in html

    def test_doc_name_rendered(self):
        html = render_campaign_documents_html(
            documents=[_doc(display_name="My Special Brief")],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "My Special Brief" in html

    def test_doc_name_escaped(self):
        html = render_campaign_documents_html(
            documents=[_doc(display_name="<script>xss</script>")],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "<script>xss</script>" not in html
        assert "&lt;script&gt;" in html

    def test_doc_name_truncated(self):
        long_name = "A" * 500
        html = render_campaign_documents_html(
            documents=[_doc(display_name=long_name)],
            campaign_id="c1",
            campaign_name="X",
        )
        # Name should be capped at _MAX_CAMPAIGN_DOC_TITLE_LEN.
        assert "A" * (_MAX_CAMPAIGN_DOC_TITLE_LEN + 10) not in html

    def test_id_fallback_when_no_display_name(self):
        html = render_campaign_documents_html(
            documents=[_doc(id_="doc_xyz", display_name=None)],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "doc_xyz" in html

    def test_untitled_when_no_id_or_name(self):
        doc = {
            "file_type": "brief",
            "folder_path": "strategy",
            "status": "ready",
        }
        html = render_campaign_documents_html(
            documents=[doc], campaign_id="c1", campaign_name="X"
        )
        assert "(untitled)" in html

    def test_status_chip_rendered(self):
        html = render_campaign_documents_html(
            documents=[_doc(status="ready")],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "ready" in html.lower()
        # Green status palette — was banned #166534, now graph8 _G8_POSITIVE_FG
        assert "#059669" in html

    def test_status_chip_em_dash_when_missing(self):
        html = render_campaign_documents_html(
            documents=[_doc(status=None)],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "—" in html

    def test_type_chip_rendered(self):
        html = render_campaign_documents_html(
            documents=[_doc(file_type="brief")],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "brief" in html
        assert "#7d2df3" in html  # indigo palette

    def test_type_chip_hidden_when_empty(self):
        """Empty file_type should NOT render an empty chip."""
        html = render_campaign_documents_html(
            documents=[_doc(file_type="")],
            campaign_id="c1",
            campaign_name="X",
        )
        # The type chip span class should not appear for empty types.
        assert 'class="cdoc-type"' not in html

    def test_updated_at_rendered(self):
        html = render_campaign_documents_html(
            documents=[_doc(updated_at="2026-04-20T10:00:00Z")],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "2026-04-20T10:00:00Z" in html

    def test_overflow_footer_shown_when_capped(self):
        docs = [
            _doc(id_=f"d{i}", display_name=f"Doc {i}", folder_path="strategy")
            for i in range(_MAX_CAMPAIGN_DOCS_RENDERED + 5)
        ]
        html = render_campaign_documents_html(
            documents=docs, campaign_id="c1", campaign_name="X"
        )
        assert "5 doc(s) omitted" in html

    def test_overflow_footer_hidden_when_under_cap(self):
        docs = [_doc(id_=f"d{i}", display_name=f"Doc {i}") for i in range(3)]
        html = render_campaign_documents_html(
            documents=docs, campaign_id="c1", campaign_name="X"
        )
        assert "omitted" not in html

    def test_grouping_preferred_folders_first(self):
        """Strategy (preferred) should appear before ads (preferred, later)."""
        html = render_campaign_documents_html(
            documents=[
                _doc(id_="a", folder_path="ads", display_name="Ad Thing"),
                _doc(id_="s", folder_path="strategy", display_name="Brief Thing"),
            ],
            campaign_id="c1",
            campaign_name="X",
        )
        assert html.index("Brief Thing") < html.index("Ad Thing")

    def test_skips_non_dict_docs(self):
        """Garbage items mixed with real ones should be filtered out."""
        html = render_campaign_documents_html(
            documents=[
                None,  # type: ignore[list-item]
                "garbage",  # type: ignore[list-item]
                _doc(display_name="Real Doc"),
                42,  # type: ignore[list-item]
            ],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "Real Doc" in html


# ---------------------------------------------------------------------------
# render_campaign_documents_text_fallback
# ---------------------------------------------------------------------------


class TestRenderTextFallback:
    def test_none_empty_state(self):
        text = render_campaign_documents_text_fallback(
            documents=None, campaign_id="c1", campaign_name="Q4 Push"
        )
        assert "No documents yet" in text
        assert "Q4 Push" in text

    def test_empty_list_empty_state(self):
        text = render_campaign_documents_text_fallback(
            documents=[], campaign_id="c1", campaign_name="Q4 Push"
        )
        assert "No documents yet" in text

    def test_non_list_empty_state(self):
        text = render_campaign_documents_text_fallback(
            documents="garbage",  # type: ignore[arg-type]
            campaign_id="c1",
            campaign_name="Q4 Push",
        )
        assert "No documents yet" in text

    def test_only_garbage_items_empty_state(self):
        text = render_campaign_documents_text_fallback(
            documents=[1, "x", None],  # type: ignore[list-item]
            campaign_id="c1",
            campaign_name="Q4 Push",
        )
        assert "No documents yet" in text

    def test_campaign_id_shown(self):
        text = render_campaign_documents_text_fallback(
            documents=[_doc()], campaign_id="camp_xyz", campaign_name="X"
        )
        assert "camp_xyz" in text

    def test_campaign_name_default(self):
        """When no name is given, 'Campaign' is used."""
        text = render_campaign_documents_text_fallback(
            documents=[_doc()], campaign_id="c1", campaign_name=None
        )
        assert "Campaign" in text

    def test_counts_line(self):
        docs = [_doc(status="ready"), _doc(status="generating")]
        text = render_campaign_documents_text_fallback(
            documents=docs, campaign_id="c1", campaign_name="X"
        )
        assert "2 doc(s)" in text
        assert "1 ready" in text

    def test_failed_count_shown(self):
        docs = [_doc(status="ready"), _doc(status="failed")]
        text = render_campaign_documents_text_fallback(
            documents=docs, campaign_id="c1", campaign_name="X"
        )
        assert "1 failed" in text

    def test_failed_count_hidden_when_zero(self):
        text = render_campaign_documents_text_fallback(
            documents=[_doc(status="ready")], campaign_id="c1", campaign_name="X"
        )
        assert "failed" not in text.lower()

    def test_folder_header_markdown(self):
        text = render_campaign_documents_text_fallback(
            documents=[_doc(folder_path="strategy")],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "## Strategy" in text

    def test_doc_name_shown(self):
        text = render_campaign_documents_text_fallback(
            documents=[_doc(display_name="My Brief")],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "My Brief" in text

    def test_file_type_shown(self):
        text = render_campaign_documents_text_fallback(
            documents=[_doc(file_type="brief")],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "brief" in text

    def test_status_shown(self):
        text = render_campaign_documents_text_fallback(
            documents=[_doc(status="ready")],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "ready" in text.lower()

    def test_updated_at_shown(self):
        text = render_campaign_documents_text_fallback(
            documents=[_doc(updated_at="2026-04-20T10:00:00Z")],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "2026-04-20T10:00:00Z" in text

    def test_overflow_suffix_shown_when_capped(self):
        docs = [
            _doc(id_=f"d{i}", display_name=f"Doc {i}", folder_path="strategy")
            for i in range(_MAX_CAMPAIGN_DOCS_RENDERED + 3)
        ]
        text = render_campaign_documents_text_fallback(
            documents=docs, campaign_id="c1", campaign_name="X"
        )
        assert "3 more doc(s)" in text

    def test_overflow_suffix_hidden_when_under_cap(self):
        docs = [_doc(id_=f"d{i}", display_name=f"Doc {i}") for i in range(3)]
        text = render_campaign_documents_text_fallback(
            documents=docs, campaign_id="c1", campaign_name="X"
        )
        assert "more doc" not in text

    def test_trailing_newline(self):
        text = render_campaign_documents_text_fallback(
            documents=[_doc()], campaign_id="c1", campaign_name="X"
        )
        assert text.endswith("\n")

    def test_id_fallback_when_no_name(self):
        text = render_campaign_documents_text_fallback(
            documents=[_doc(id_="doc_xyz", display_name=None)],
            campaign_id="c1",
            campaign_name="X",
        )
        assert "doc_xyz" in text

    def test_row_format_name_type_status(self):
        text = render_campaign_documents_text_fallback(
            documents=[_doc(display_name="Name", file_type="brief", status="ready")],
            campaign_id="c1",
            campaign_name="X",
        )
        # Pattern: "- Name  <brief>  [ready]..."
        assert "<brief>" in text
        assert "[ready]" in text
