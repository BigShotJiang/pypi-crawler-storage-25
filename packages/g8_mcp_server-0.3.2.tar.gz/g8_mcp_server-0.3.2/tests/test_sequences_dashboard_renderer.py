"""Tests for the sequences dashboard HTML + text renderers (upgrade 4 — #9).

Distinct from `test_sequence_preview_renderer.py` which covers the per-sequence
URI-templated surface #2. This file covers the STATIC org-scoped
`g8://sequences/dashboard` surface.
"""

from __future__ import annotations

from g8_mcp_server import app_renderer
from g8_mcp_server.app_renderer import (
    _group_sequences_by_status,
    _sequence_effective_status,
    _sequence_status_color,
    render_sequences_dashboard_html,
    render_sequences_dashboard_text_fallback,
)


def _seq(idx: int = 0, **overrides) -> dict:
    """Default sequence dict matching `SequenceItem`."""
    base = {
        "id": f"seq_{idx}",
        "name": f"Sequence {idx}",
        "description": f"Outbound sequence {idx}",
        "status": "active",
        "is_shared": False,
        "is_archived": False,
        "step_count": 5,
        "contact_count": 100,
        "created_at": "2026-04-01T00:00:00Z",
        "updated_at": "2026-04-15T12:00:00Z",
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class TestSequenceStatusColor:
    def test_known(self):
        # Backported to graph8 tokens 2026-04-21
        assert _sequence_status_color("active") == "#059669"  # _G8_POSITIVE_FG
        assert _sequence_status_color("live") == "#059669"  # _G8_POSITIVE_FG
        assert _sequence_status_color("running") == "#059669"  # _G8_POSITIVE_FG
        assert _sequence_status_color("completed") == "#7d2df3"  # _G8_PRIMARY
        assert _sequence_status_color("paused") == "#a0750a"
        assert _sequence_status_color("draft") == "#777777"
        assert _sequence_status_color("archived") == "#777777"

    def test_case_and_whitespace(self):
        assert _sequence_status_color("ACTIVE") == "#059669"  # _G8_POSITIVE_FG
        assert _sequence_status_color(" Paused ") == "#a0750a"

    def test_unknown(self):
        assert _sequence_status_color("weird") == "#777777"
        assert _sequence_status_color(None) == "#777777"
        assert _sequence_status_color("") == "#777777"

    def test_no_banned_hexes_in_status_palette(self):
        banned = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}
        from mcp_server.g8_mcp_server.app_renderer import _SEQUENCE_STATUS_COLORS
        for k, v in _SEQUENCE_STATUS_COLORS.items():
            assert v.lower() not in banned, f"status={k!r} hex={v!r} is banned"


class TestSequenceEffectiveStatus:
    def test_explicit_status(self):
        assert _sequence_effective_status({"status": "active"}) == "active"
        assert _sequence_effective_status({"status": "Paused"}) == "paused"

    def test_archived_flag_fallback(self):
        assert _sequence_effective_status({"is_archived": True}) == "archived"

    def test_default_draft(self):
        assert _sequence_effective_status({}) == "draft"
        assert _sequence_effective_status({"status": None}) == "draft"
        assert _sequence_effective_status({"status": ""}) == "draft"

    def test_status_wins_over_archived_flag(self):
        # Explicit status takes precedence.
        assert _sequence_effective_status(
            {"status": "paused", "is_archived": True}
        ) == "paused"


class TestGroupSequencesByStatus:
    def test_empty(self):
        assert _group_sequences_by_status([]) == []

    def test_ordering(self):
        seqs = [
            _seq(idx=1, status="archived"),
            _seq(idx=2, status="active"),
            _seq(idx=3, status="paused"),
            _seq(idx=4, status="draft"),
        ]
        result = _group_sequences_by_status(seqs)
        keys = [k for k, _ in result]
        # active first, then paused, then draft, then archived
        assert keys.index("active") < keys.index("paused")
        assert keys.index("paused") < keys.index("draft")
        assert keys.index("draft") < keys.index("archived")

    def test_unknown_statuses_preserve_insertion_order(self):
        seqs = [
            _seq(idx=1, status="alpha"),
            _seq(idx=2, status="active"),
            _seq(idx=3, status="beta"),
        ]
        result = _group_sequences_by_status(seqs)
        keys = [k for k, _ in result]
        # Preferred (active) comes first, then insertion order for unknowns
        assert keys == ["active", "alpha", "beta"]

    def test_is_archived_bucketed_as_archived(self):
        seqs = [_seq(status=None, is_archived=True)]
        result = _group_sequences_by_status(seqs)
        assert result[0][0] == "archived"


# ---------------------------------------------------------------------------
# HTML renderer
# ---------------------------------------------------------------------------


class TestRenderSequencesDashboardHtml:
    def test_empty_state(self):
        html_out = render_sequences_dashboard_html(sequences=None)
        assert "No sequences yet" in html_out

        html_out2 = render_sequences_dashboard_html(sequences=[])
        assert "No sequences yet" in html_out2

    def test_non_list_input(self):
        html_out = render_sequences_dashboard_html(sequences="nope")  # type: ignore[arg-type]
        assert "No sequences yet" in html_out

    def test_only_garbage_items(self):
        html_out = render_sequences_dashboard_html(sequences=[None, "x", 1])  # type: ignore[list-item]
        assert "No sequences yet" in html_out

    def test_renders_sequence(self):
        html_out = render_sequences_dashboard_html(sequences=[_seq()])
        assert "Sequence 0" in html_out
        assert "5 steps" in html_out
        assert "100 contacts" in html_out

    def test_singular_counts(self):
        html_out = render_sequences_dashboard_html(
            sequences=[_seq(step_count=1, contact_count=1)]
        )
        assert "1 step" in html_out
        assert "1 contact" in html_out

    def test_status_grouping_rendered(self):
        html_out = render_sequences_dashboard_html(
            sequences=[
                _seq(status="active"),
                _seq(idx=1, status="paused"),
            ]
        )
        assert "active" in html_out
        assert "paused" in html_out

    def test_missing_name_fallback(self):
        html_out = render_sequences_dashboard_html(
            sequences=[_seq(name=None)]
        )
        assert "(untitled)" in html_out

    def test_org_label(self):
        html_out = render_sequences_dashboard_html(
            sequences=[_seq()], org_label="Acme"
        )
        assert "Acme" in html_out

    def test_sort_by_contact_count_desc(self):
        html_out = render_sequences_dashboard_html(
            sequences=[
                _seq(idx=1, name="Small", contact_count=5),
                _seq(idx=2, name="Big", contact_count=5000),
                _seq(idx=3, name="Medium", contact_count=500),
            ]
        )
        # Big should appear before Medium, Medium before Small within the
        # same group.
        big_pos = html_out.find("Big")
        med_pos = html_out.find("Medium")
        small_pos = html_out.find("Small")
        assert big_pos < med_pos < small_pos


class TestEscaping:
    def test_name_escaped(self):
        html_out = render_sequences_dashboard_html(
            sequences=[_seq(name="<script>evil()</script>")]
        )
        assert "<script>evil" not in html_out
        assert "&lt;script&gt;" in html_out

    def test_description_escaped(self):
        html_out = render_sequences_dashboard_html(
            sequences=[_seq(description="<img onerror=bad()>")]
        )
        assert "<img onerror" not in html_out

    def test_status_name_escaped(self):
        html_out = render_sequences_dashboard_html(
            sequences=[_seq(status="<xss>")]
        )
        assert "<xss>" not in html_out
        assert "&lt;xss&gt;" in html_out


class TestBounds:
    def test_max_sequences_rendered(self):
        seqs = [_seq(idx=i, name=f"S_{i}", contact_count=i) for i in range(120)]
        html_out = render_sequences_dashboard_html(sequences=seqs)
        # Highest contact_count (119) appears; lowest (0) past cap doesn't.
        assert "S_119" in html_out
        assert "S_0" not in html_out  # past cap 60 (lowest contact_count)
        assert "omitted" in html_out

    def test_long_description_truncated(self):
        html_out = render_sequences_dashboard_html(
            sequences=[_seq(description="d" * 5000)]
        )
        assert "…" in html_out

    def test_long_name_truncated(self):
        html_out = render_sequences_dashboard_html(
            sequences=[_seq(name="n" * 5000)]
        )
        assert "…" in html_out


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------


class TestSequencesDashboardTextFallback:
    def test_empty(self):
        out = render_sequences_dashboard_text_fallback(sequences=None)
        assert "No sequences yet" in out

        out2 = render_sequences_dashboard_text_fallback(sequences=[])
        assert "No sequences yet" in out2

    def test_non_list(self):
        out = render_sequences_dashboard_text_fallback(sequences="nope")  # type: ignore[arg-type]
        assert "No sequences yet" in out

    def test_renders_key_fields(self):
        out = render_sequences_dashboard_text_fallback(sequences=[_seq()])
        assert "Sequence 0" in out
        assert "5 step(s)" in out
        assert "100 contact(s)" in out

    def test_status_grouping(self):
        out = render_sequences_dashboard_text_fallback(
            sequences=[
                _seq(status="active"),
                _seq(idx=1, status="paused"),
            ]
        )
        assert "## active" in out
        assert "## paused" in out

    def test_org_label(self):
        out = render_sequences_dashboard_text_fallback(
            sequences=[_seq()], org_label="Acme"
        )
        assert "# Sequences — Acme" in out

    def test_max_cap_footer(self):
        seqs = [_seq(idx=i) for i in range(120)]
        out = render_sequences_dashboard_text_fallback(sequences=seqs)
        assert "more sequence(s)" in out

    def test_no_html_leak(self):
        out = render_sequences_dashboard_text_fallback(
            sequences=[_seq(name="<tag>")]
        )
        assert "<html>" not in out
        assert "<body>" not in out


# ---------------------------------------------------------------------------
# Caps sanity
# ---------------------------------------------------------------------------


class TestCapsExist:
    def test_constants(self):
        assert app_renderer._MAX_SEQUENCES_RENDERED >= 10
        assert app_renderer._MAX_SEQUENCE_NAME_LEN >= 50
        assert app_renderer._MAX_SEQUENCE_DESC_LEN >= 100
