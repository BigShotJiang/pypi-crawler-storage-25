"""Structured-output tests for g8_get_tracking_snippet and g8_get_form_template.

These are the last two tools migrated to typed Pydantic returns in upgrade 2,
bringing coverage to 83/83. The structured shape matters because AI agents
rely on `outputSchema` to know the response contract before calling.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock

import pytest

import g8_mcp_server.client as client_module
from g8_mcp_server.models import (
    FormFieldDefinition,
    FormStageDefinition,
    FormTemplateResult,
    TrackingMethods,
    TrackingSnippetResult,
)
from g8_mcp_server.server import create_server


@pytest.fixture
def mcp_server(monkeypatch):
    monkeypatch.setenv("G8_API_KEY", "test_key")
    monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
    monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent"))
    return create_server()


def _tool(server, name):
    return server._tool_manager._tools[name]


# ---------------------------------------------------------------------------
# Output schema (outputSchema MCP field)
# ---------------------------------------------------------------------------


class TestOutputSchemas:
    """Verify FastMCP auto-detected the Pydantic return types and emits proper
    outputSchema with `anyOf` union for (model | str)."""

    def test_tracking_snippet_has_output_schema(self, mcp_server):
        tool = _tool(mcp_server, "g8_get_tracking_snippet")
        assert tool.output_schema is not None
        # The schema includes the Pydantic model definition under $defs.
        defs = tool.output_schema.get("$defs") or {}
        assert "TrackingSnippetResult" in defs
        props = defs["TrackingSnippetResult"]["properties"]
        for field in (
            "write_key",
            "tracking_host",
            "framework",
            "snippet_code",
            "setup_steps",
            "tracking_methods",
            "privacy_options",
            "verification",
        ):
            assert field in props, f"Missing field in outputSchema: {field}"

    def test_form_template_has_output_schema(self, mcp_server):
        tool = _tool(mcp_server, "g8_get_form_template")
        assert tool.output_schema is not None
        defs = tool.output_schema.get("$defs") or {}
        assert "FormTemplateResult" in defs
        props = defs["FormTemplateResult"]["properties"]
        for field in (
            "write_key",
            "tracking_host",
            "framework",
            "variant",
            "template_code",
            "field_stages",
            "data_flow",
            "customization_guide",
            "prerequisite",
        ):
            assert field in props, f"Missing field in outputSchema: {field}"

    def test_tracking_snippet_union_allows_plain_string(self, mcp_server):
        """The `Model | str` union must allow a string for error paths."""
        tool = _tool(mcp_server, "g8_get_tracking_snippet")
        schema = tool.output_schema
        # Pydantic emits union as `anyOf: [{...model}, {type: string}]`
        # The top-level schema wraps in {"result": {...}} for non-object returns,
        # so check the nested structure either way.
        dumped = str(schema)
        assert '"string"' in dumped or "'string'" in dumped, (
            "Union `Model | str` should include plain string branch for error envelopes"
        )


# ---------------------------------------------------------------------------
# Pydantic model validation
# ---------------------------------------------------------------------------


class TestTrackingSnippetResultModel:
    def test_minimal(self):
        r = TrackingSnippetResult()
        assert r.write_key == ""
        assert r.snippet_code == ""
        assert r.setup_steps == []
        assert isinstance(r.tracking_methods, TrackingMethods)

    def test_from_dict_full_payload(self):
        payload = {
            "write_key": "wk_abc",
            "tracking_host": "https://t.graph8.com",
            "framework": "Next.js",
            "snippet_code": "<Script ... />",
            "setup_steps": ["Add to layout", "Verify"],
            "tracking_methods": {
                "identify": 'g8.identify("x")',
                "track": 'g8.track("e")',
            },
            "privacy_options": "Privacy…",
            "verification": ["DevTools → Network"],
        }
        r = TrackingSnippetResult.from_dict(payload)
        assert r.write_key == "wk_abc"
        assert r.tracking_methods.identify == 'g8.identify("x")'
        assert r.tracking_methods.track == 'g8.track("e")'
        assert r.setup_steps == ["Add to layout", "Verify"]

    def test_extra_fields_ignored(self):
        """_StrictIgnore means unexpected fields should not blow up."""
        r = TrackingSnippetResult.from_dict(
            {"write_key": "wk", "unknown_field": 123, "new_field": "future"}
        )
        assert r.write_key == "wk"
        assert not hasattr(r, "unknown_field")


class TestFormTemplateResultModel:
    def test_minimal(self):
        r = FormTemplateResult()
        assert r.template_code == ""
        assert r.field_stages == []

    def test_from_dict_with_stages(self):
        payload = {
            "write_key": "wk",
            "tracking_host": "host",
            "framework": "React",
            "variant": "embedded",
            "template_code": "<Form />",
            "field_stages": [
                {
                    "stage": 1,
                    "fields": [
                        {"name": "email", "type": "email", "label": "Email", "required": True},
                    ],
                },
                {
                    "stage": 2,
                    "fields": [
                        {
                            "name": "budget",
                            "type": "select",
                            "label": "Budget",
                            "required": False,
                            "options": ["low", "high"],
                        },
                    ],
                },
            ],
            "data_flow": "…",
            "customization_guide": "…",
            "prerequisite": "Install snippet first",
        }
        r = FormTemplateResult.from_dict(payload)
        assert r.framework == "React"
        assert r.variant == "embedded"
        assert len(r.field_stages) == 2
        assert r.field_stages[0].stage == 1
        assert r.field_stages[0].fields[0].name == "email"
        assert r.field_stages[0].fields[0].required is True
        assert r.field_stages[1].fields[0].options == ["low", "high"]

    def test_stage_with_empty_fields(self):
        """Stage must accept an empty fields list."""
        stage = FormStageDefinition(stage=1, fields=[])
        assert stage.fields == []

    def test_field_required_defaults_to_none(self):
        """FormFieldDefinition fields are optional so backend changes don't break."""
        f = FormFieldDefinition(name="x")
        assert f.required is None
        assert f.options is None


# ---------------------------------------------------------------------------
# End-to-end tool call (with mocked HTTP client)
# ---------------------------------------------------------------------------


def _build_client_with_mocked_get(return_value):
    """Build a real G8Client then mock its .get method."""
    from g8_mcp_server.client import G8Client

    client = G8Client(require_key=False)
    client.get = AsyncMock(return_value=return_value)
    return client


class TestTrackingSnippetToolReturnsModel:
    async def test_returns_typed_model_on_success(self, mcp_server):
        from mcp.server import FastMCP
        from g8_mcp_server.tools import snippet as snippet_module

        mock_client = _build_client_with_mocked_get(
            {"data": {"write_key": "wk_demo", "tracking_host": "https://t.graph8.com"}}
        )

        test_server = FastMCP("test")
        snippet_module.register(test_server, mock_client)
        test_tool = test_server._tool_manager._tools["g8_get_tracking_snippet"]

        # Invoke via FastMCP's tool_manager so we exercise the full wrapper and
        # get back the Pydantic model (or string) — FastMCP returns either the
        # structured dict or a ToolResult depending on version.
        result = await test_tool.fn(framework="nextjs")
        # We annotated the tool `-> TrackingSnippetResult | str`, so the fn
        # returns the Pydantic model directly.
        assert result.__class__.__name__ == "TrackingSnippetResult"
        assert result.write_key == "wk_demo"
        assert result.framework == "Next.js"
        assert result.snippet_code  # non-empty
        assert result.setup_steps  # non-empty list

    async def test_returns_string_on_invalid_framework(self, mcp_server):
        from mcp.server import FastMCP
        from g8_mcp_server.tools import snippet as snippet_module

        mock_client = _build_client_with_mocked_get({})

        test_server = FastMCP("test")
        snippet_module.register(test_server, mock_client)
        test_tool = test_server._tool_manager._tools["g8_get_tracking_snippet"]

        result = await test_tool.fn(framework="BOGUS_FRAMEWORK")
        # Error path falls back to format_result (string envelope).
        assert isinstance(result, str)
        assert "Unsupported framework" in result


class TestFormTemplateToolReturnsModel:
    async def test_returns_typed_model_on_success(self, mcp_server):
        from mcp.server import FastMCP
        from g8_mcp_server.tools import forms as forms_module

        mock_client = _build_client_with_mocked_get(
            {"data": {"write_key": "wk_form", "tracking_host": "https://t.graph8.com"}}
        )

        test_server = FastMCP("test")
        forms_module.register(test_server, mock_client)
        test_tool = test_server._tool_manager._tools["g8_get_form_template"]

        result = await test_tool.fn(framework="react", variant="embedded")
        assert result.__class__.__name__ == "FormTemplateResult"
        assert result.write_key == "wk_form"
        assert result.framework == "React"
        assert result.variant == "embedded"
        assert result.template_code  # non-empty
        assert len(result.field_stages) >= 1
        assert result.field_stages[0].stage == 1

    async def test_returns_string_on_invalid_variant(self, mcp_server):
        from mcp.server import FastMCP
        from g8_mcp_server.tools import forms as forms_module

        mock_client = _build_client_with_mocked_get({})

        test_server = FastMCP("test")
        forms_module.register(test_server, mock_client)
        test_tool = test_server._tool_manager._tools["g8_get_form_template"]

        result = await test_tool.fn(framework="react", variant="nonsense")
        assert isinstance(result, str)
        assert "Unsupported variant" in result
