"""Tests for Surface #84 — g8://contacts/engagement/{level} renderer.

Third axis-filter on the CONTACTS entity (companion to #76 seniority and
#77 department). POST-FETCH CLIENT-SIDE BUCKETING pattern — backend has
no engagement column; we score-tier each contact (≥80/60/40/20) and
fall back to days-since-last-touch bands (≤7/30/90/180).

Locks:
- Canonical 5 levels: hot / warm / cool / cold / dormant
- ~50 aliases including tier ranking (a/b/c/d/e/f-tier) and intent words
- 8 forbidden literals: dashboard, notes, tasks, deals, activities,
  seniority, department, engagement
- NEW stats shape for contacts entity: Total / Avg score / Avg days /
  Most recent (3 derived numeric KPIs)
- Palette: positive-green hot, accent-purple warm, warning-amber cool,
  muted cold+dormant
- Sort: (-score, days_since_touch ASC, name ASC)
- Drill-up: dashboard + 4 sibling levels + 2 cross-axis (seniority/
  c-level, department/engineering) + cross-entity (deals/pipeline)
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest

from mcp_server.g8_mcp_server.app_renderer import (
    _CONTACTS_ENGAGEMENT_ALIASES,
    _CONTACTS_ENGAGEMENT_DESCRIPTIONS,
    _CONTACTS_ENGAGEMENT_FORBIDDEN,
    _CONTACTS_ENGAGEMENT_LABELS,
    _CONTACTS_ENGAGEMENT_SHORT_LABELS,
    _CONTACTS_ENGAGEMENT_VALID,
    _MAX_CONTACTS_ENGAGEMENT_RENDERED,
    _contacts_engagement_avg_days,
    _contacts_engagement_avg_score,
    _contacts_engagement_bucket_of,
    _contacts_engagement_clip,
    _contacts_engagement_days_since_touch,
    _contacts_engagement_description,
    _contacts_engagement_display_name,
    _contacts_engagement_drill_up_html,
    _contacts_engagement_empty_state_html,
    _contacts_engagement_filter,
    _contacts_engagement_header_html,
    _contacts_engagement_label,
    _contacts_engagement_list_html,
    _contacts_engagement_min_days,
    _contacts_engagement_normalize,
    _contacts_engagement_overflow_banner_html,
    _contacts_engagement_palette,
    _contacts_engagement_row_html,
    _contacts_engagement_score,
    _contacts_engagement_short_label,
    _contacts_engagement_stats_row_html,
    render_contacts_engagement_html,
    render_contacts_engagement_text_fallback,
)


# ---------------------------------------------------------------------------
# Constants — canonical shape
# ---------------------------------------------------------------------------


class TestConstants:
    def test_valid_levels_count(self):
        assert len(_CONTACTS_ENGAGEMENT_VALID) == 5

    def test_valid_levels_exact(self):
        assert _CONTACTS_ENGAGEMENT_VALID == (
            "hot", "warm", "cool", "cold", "dormant",
        )

    def test_labels_cover_canonical(self):
        for key in _CONTACTS_ENGAGEMENT_VALID:
            assert key in _CONTACTS_ENGAGEMENT_LABELS

    def test_short_labels_cover_canonical(self):
        for key in _CONTACTS_ENGAGEMENT_VALID:
            assert key in _CONTACTS_ENGAGEMENT_SHORT_LABELS

    def test_descriptions_cover_canonical(self):
        for key in _CONTACTS_ENGAGEMENT_VALID:
            assert key in _CONTACTS_ENGAGEMENT_DESCRIPTIONS

    def test_max_rendered_is_cap(self):
        assert _MAX_CONTACTS_ENGAGEMENT_RENDERED == 100

    def test_forbidden_count(self):
        assert len(_CONTACTS_ENGAGEMENT_FORBIDDEN) == 8

    def test_forbidden_exact(self):
        assert set(_CONTACTS_ENGAGEMENT_FORBIDDEN) == {
            "dashboard", "notes", "tasks", "deals", "activities",
            "seniority", "department", "engagement",
        }

    def test_aliases_non_empty(self):
        assert len(_CONTACTS_ENGAGEMENT_ALIASES) >= 40

    def test_aliases_all_canonical_targets(self):
        for target in _CONTACTS_ENGAGEMENT_ALIASES.values():
            assert target in _CONTACTS_ENGAGEMENT_VALID


# ---------------------------------------------------------------------------
# Normalization — happy path
# ---------------------------------------------------------------------------


class TestNormalize:
    @pytest.mark.parametrize("key", list(_CONTACTS_ENGAGEMENT_VALID))
    def test_canonical_pass_through(self, key):
        assert _contacts_engagement_normalize(key) == key

    @pytest.mark.parametrize("raw, expected", [
        ("HOT", "hot"),
        ("Warm", "warm"),
        ("COOL", "cool"),
        ("Cold", "cold"),
        ("DORMANT", "dormant"),
    ])
    def test_case_insensitive(self, raw, expected):
        assert _contacts_engagement_normalize(raw) == expected

    @pytest.mark.parametrize("raw, expected", [
        ("  hot  ", "hot"),
        ("\twarm\n", "warm"),
    ])
    def test_whitespace_stripped(self, raw, expected):
        assert _contacts_engagement_normalize(raw) == expected


class TestNormalizeAliases:
    @pytest.mark.parametrize("alias, target", [
        ("active", "hot"),
        ("engaged", "hot"),
        ("high", "hot"),
        ("high-intent", "hot"),
        ("high_intent", "hot"),
        ("priority", "hot"),
        ("top", "hot"),
        ("a", "hot"),
        ("a-tier", "hot"),
        ("a_tier", "hot"),
    ])
    def test_hot_aliases(self, alias, target):
        assert _contacts_engagement_normalize(alias) == target

    @pytest.mark.parametrize("alias, target", [
        ("medium", "warm"),
        ("moderate", "warm"),
        ("nurturing", "warm"),
        ("nurture", "warm"),
        ("mid", "warm"),
        ("b", "warm"),
        ("b-tier", "warm"),
        ("b_tier", "warm"),
        ("recent", "warm"),
    ])
    def test_warm_aliases(self, alias, target):
        assert _contacts_engagement_normalize(alias) == target

    @pytest.mark.parametrize("alias, target", [
        ("slowing", "cool"),
        ("c", "cool"),
        ("c-tier", "cool"),
        ("c_tier", "cool"),
        ("stale", "cool"),
        ("slow", "cool"),
        ("fading", "cool"),
    ])
    def test_cool_aliases(self, alias, target):
        assert _contacts_engagement_normalize(alias) == target

    @pytest.mark.parametrize("alias, target", [
        ("low", "cold"),
        ("low-intent", "cold"),
        ("low_intent", "cold"),
        ("unengaged", "cold"),
        ("d", "cold"),
        ("d-tier", "cold"),
        ("d_tier", "cold"),
        ("disengaged", "cold"),
    ])
    def test_cold_aliases(self, alias, target):
        assert _contacts_engagement_normalize(alias) == target

    @pytest.mark.parametrize("alias, target", [
        ("inactive", "dormant"),
        ("archived", "dormant"),
        ("archive", "dormant"),
        ("stopped", "dormant"),
        ("churned", "dormant"),
        ("lost", "dormant"),
        ("dead", "dormant"),
        ("abandoned", "dormant"),
        ("gone", "dormant"),
        ("none", "dormant"),
        ("never", "dormant"),
        ("zero", "dormant"),
        ("0", "dormant"),
        ("e", "dormant"),
        ("e-tier", "dormant"),
        ("e_tier", "dormant"),
        ("f", "dormant"),
        ("f-tier", "dormant"),
        ("f_tier", "dormant"),
    ])
    def test_dormant_aliases(self, alias, target):
        assert _contacts_engagement_normalize(alias) == target

    @pytest.mark.parametrize("alias", [
        "a-tier", "b-tier", "c-tier", "d-tier", "e-tier", "f-tier",
    ])
    def test_hyphen_tier_forms(self, alias):
        assert _contacts_engagement_normalize(alias) in _CONTACTS_ENGAGEMENT_VALID

    @pytest.mark.parametrize("alias", [
        "a_tier", "b_tier", "c_tier", "d_tier", "e_tier", "f_tier",
    ])
    def test_underscore_tier_forms(self, alias):
        assert _contacts_engagement_normalize(alias) in _CONTACTS_ENGAGEMENT_VALID


class TestNormalizeInvalid:
    @pytest.mark.parametrize("raw", [
        None, 0, True, False, [], {}, 1.5, b"hot",
    ])
    def test_non_string_returns_none(self, raw):
        assert _contacts_engagement_normalize(raw) is None

    @pytest.mark.parametrize("raw", ["", "   ", "\n", "\t\t"])
    def test_empty_returns_none(self, raw):
        assert _contacts_engagement_normalize(raw) is None

    @pytest.mark.parametrize("raw", [
        "sizzling", "piping", "lukewarm", "freezing",
        "ghost", "zombie", "unknown-level-123",
    ])
    def test_unknown_returns_none(self, raw):
        assert _contacts_engagement_normalize(raw) is None


class TestForbiddenLiterals:
    @pytest.mark.parametrize("forbidden", list(_CONTACTS_ENGAGEMENT_FORBIDDEN))
    def test_each_forbidden_returns_none(self, forbidden):
        assert _contacts_engagement_normalize(forbidden) is None

    @pytest.mark.parametrize("forbidden", list(_CONTACTS_ENGAGEMENT_FORBIDDEN))
    def test_forbidden_case_variants_return_none(self, forbidden):
        assert _contacts_engagement_normalize(forbidden.upper()) is None
        assert _contacts_engagement_normalize(forbidden.title()) is None

    def test_dashboard_specifically_blocked(self):
        assert _contacts_engagement_normalize("dashboard") is None

    def test_self_name_blocked(self):
        assert _contacts_engagement_normalize("engagement") is None


# ---------------------------------------------------------------------------
# Label / palette / description helpers
# ---------------------------------------------------------------------------


class TestLabels:
    @pytest.mark.parametrize("key", list(_CONTACTS_ENGAGEMENT_VALID))
    def test_label_returns_capitalized(self, key):
        assert _contacts_engagement_label(key) == key.capitalize()

    def test_invalid_label_default(self):
        assert _contacts_engagement_label("gibberish") == "Contacts"

    def test_none_label_default(self):
        assert _contacts_engagement_label(None) == "Contacts"

    @pytest.mark.parametrize("key", list(_CONTACTS_ENGAGEMENT_VALID))
    def test_short_label_defined(self, key):
        assert _contacts_engagement_short_label(key) == key.capitalize()

    def test_short_label_default(self):
        assert _contacts_engagement_short_label("xyz") == "—"


class TestDescriptions:
    @pytest.mark.parametrize("key", list(_CONTACTS_ENGAGEMENT_VALID))
    def test_description_non_empty(self, key):
        d = _contacts_engagement_description(key)
        assert d and isinstance(d, str)

    def test_unknown_description_empty(self):
        assert _contacts_engagement_description("nope") == ""


class TestPalette:
    def test_hot_is_positive_green(self):
        bg, fg = _contacts_engagement_palette("hot")
        assert bg == "#d1fae5"

    def test_warm_is_accent_purple(self):
        bg, fg = _contacts_engagement_palette("warm")
        assert bg == "#f2eafe"

    def test_cool_is_warning_amber(self):
        bg, fg = _contacts_engagement_palette("cool")
        assert bg == "#fff3c4"

    @pytest.mark.parametrize("key", ["cold", "dormant"])
    def test_cold_dormant_muted(self, key):
        bg, fg = _contacts_engagement_palette(key)
        assert bg == "#f9f9f9"  # _G8_MUTED_BG

    def test_invalid_palette_muted(self):
        bg, fg = _contacts_engagement_palette("nope")
        assert bg == "#f9f9f9"

    def test_palette_returns_2_tuple(self):
        for key in _CONTACTS_ENGAGEMENT_VALID:
            result = _contacts_engagement_palette(key)
            assert isinstance(result, tuple) and len(result) == 2


# ---------------------------------------------------------------------------
# Bucket helpers — score and days branches
# ---------------------------------------------------------------------------


class TestBucketByScore:
    @pytest.mark.parametrize("score, expected", [
        (100, "hot"),
        (95, "hot"),
        (80, "hot"),
        (79.99, "warm"),
        (60, "warm"),
        (59, "cool"),
        (40, "cool"),
        (39, "cold"),
        (20, "cold"),
        (19, "dormant"),
        (0, "dormant"),
    ])
    def test_score_tiers(self, score, expected):
        assert _contacts_engagement_bucket_of(
            {"engagement_score": score}
        ) == expected

    def test_score_clipped_above_100(self):
        # Score is clamped but still in "hot" bucket
        assert _contacts_engagement_bucket_of(
            {"engagement_score": 500}
        ) == "hot"

    def test_score_clipped_below_0(self):
        assert _contacts_engagement_bucket_of(
            {"engagement_score": -10}
        ) == "dormant"

    def test_score_from_string(self):
        assert _contacts_engagement_bucket_of(
            {"engagement_score": "82"}
        ) == "hot"


class TestBucketByDays:
    @staticmethod
    def _ts(days_ago: int) -> str:
        return (datetime.now(timezone.utc) - timedelta(days=days_ago)).isoformat()

    @pytest.mark.parametrize("days, expected", [
        (0, "hot"),
        (1, "hot"),
        (7, "hot"),
        (8, "warm"),
        (30, "warm"),
        (31, "cool"),
        (90, "cool"),
        (91, "cold"),
        (180, "cold"),
        (181, "dormant"),
        (365, "dormant"),
    ])
    def test_days_bands(self, days, expected):
        contact = {"last_activity_at": self._ts(days)}
        assert _contacts_engagement_bucket_of(contact) == expected

    def test_no_score_no_dates_defaults_dormant(self):
        assert _contacts_engagement_bucket_of({"email": "x@y.com"}) == "dormant"

    def test_score_wins_over_days(self):
        # Score says hot, but old date — score takes precedence
        contact = {
            "engagement_score": 90,
            "last_activity_at": self._ts(300),
        }
        assert _contacts_engagement_bucket_of(contact) == "hot"

    def test_fallback_timestamps_parsed(self):
        # Use last_contacted_at fallback
        contact = {"last_contacted_at": self._ts(5)}
        assert _contacts_engagement_bucket_of(contact) == "hot"


class TestBucketInvalid:
    @pytest.mark.parametrize("raw", [None, [], 0, "", True])
    def test_non_dict_returns_none(self, raw):
        assert _contacts_engagement_bucket_of(raw) is None

    def test_score_bool_ignored(self):
        # bool(True)=1 would be cold, but booleans explicitly rejected
        result = _contacts_engagement_bucket_of(
            {"engagement_score": True, "email": "x@y.com"}
        )
        assert result == "dormant"  # falls through to days, then default

    def test_invalid_score_string_falls_through(self):
        result = _contacts_engagement_bucket_of(
            {"engagement_score": "not a number"}
        )
        assert result == "dormant"


# ---------------------------------------------------------------------------
# Score / days helpers
# ---------------------------------------------------------------------------


class TestScoreHelper:
    @pytest.mark.parametrize("v, expected", [
        (50, 50.0),
        (50.5, 50.5),
        ("50", 50.0),
        ("  73.2  ", 73.2),
        (150, 100.0),  # clamp
        (-5, 0.0),     # clamp
    ])
    def test_valid_scores(self, v, expected):
        assert _contacts_engagement_score({"engagement_score": v}) == expected

    @pytest.mark.parametrize("v", [
        None, "", "abc", [], {}, True, False,
        float("inf"), float("-inf"), float("nan"),
    ])
    def test_invalid_scores(self, v):
        assert _contacts_engagement_score({"engagement_score": v}) is None

    def test_missing_field_none(self):
        assert _contacts_engagement_score({}) is None

    def test_not_dict_none(self):
        assert _contacts_engagement_score("str") is None


class TestDaysSinceHelper:
    @staticmethod
    def _ts(days_ago: int) -> str:
        return (datetime.now(timezone.utc) - timedelta(days=days_ago)).isoformat()

    def test_last_activity_at_preferred(self):
        contact = {
            "last_activity_at": self._ts(5),
            "last_contacted_at": self._ts(50),
        }
        assert _contacts_engagement_days_since_touch(contact) == 5

    def test_fallback_order(self):
        contact = {"last_meeting_at": self._ts(10)}
        assert _contacts_engagement_days_since_touch(contact) == 10

    def test_updated_at_fallback(self):
        contact = {"updated_at": self._ts(100)}
        assert _contacts_engagement_days_since_touch(contact) == 100

    def test_no_dates_none(self):
        assert _contacts_engagement_days_since_touch({}) is None

    def test_not_dict_none(self):
        assert _contacts_engagement_days_since_touch("str") is None

    def test_unparseable_returns_none(self):
        assert _contacts_engagement_days_since_touch(
            {"last_activity_at": "not-a-date"}
        ) is None

    def test_z_suffix_parsed(self):
        contact = {"last_activity_at": "2025-01-01T00:00:00Z"}
        # Should not raise
        result = _contacts_engagement_days_since_touch(contact)
        assert result is not None and result > 0


# ---------------------------------------------------------------------------
# Filter
# ---------------------------------------------------------------------------


class TestFilter:
    def test_hot_bucket(self):
        contacts = [
            {"first_name": "A", "engagement_score": 90},
            {"first_name": "B", "engagement_score": 50},
            {"first_name": "C", "engagement_score": 10},
        ]
        filtered = _contacts_engagement_filter(contacts, "hot")
        assert len(filtered) == 1
        assert filtered[0]["first_name"] == "A"

    def test_invalid_level_empty(self):
        contacts = [{"first_name": "A", "engagement_score": 90}]
        assert _contacts_engagement_filter(contacts, "unknown") == []

    def test_none_contacts_empty(self):
        assert _contacts_engagement_filter(None, "hot") == []

    def test_non_list_empty(self):
        assert _contacts_engagement_filter({"x": 1}, "hot") == []

    def test_non_dict_items_filtered(self):
        contacts = [
            {"first_name": "A", "engagement_score": 90},
            "not a dict",
            None,
            42,
        ]
        filtered = _contacts_engagement_filter(contacts, "hot")
        assert len(filtered) == 1

    def test_alias_input_works(self):
        contacts = [{"first_name": "A", "engagement_score": 85}]
        filtered = _contacts_engagement_filter(contacts, "active")
        assert len(filtered) == 1


# ---------------------------------------------------------------------------
# Aggregate helpers
# ---------------------------------------------------------------------------


class TestAggregates:
    def test_avg_score_empty(self):
        assert _contacts_engagement_avg_score([]) is None

    def test_avg_score_basic(self):
        contacts = [{"engagement_score": 60}, {"engagement_score": 80}]
        assert _contacts_engagement_avg_score(contacts) == 70.0

    def test_avg_score_ignores_missing(self):
        contacts = [{"engagement_score": 60}, {"email": "x@y.com"}]
        assert _contacts_engagement_avg_score(contacts) == 60.0

    @staticmethod
    def _ts(days_ago: int) -> str:
        return (datetime.now(timezone.utc) - timedelta(days=days_ago)).isoformat()

    def test_avg_days_basic(self):
        contacts = [
            {"last_activity_at": self._ts(10)},
            {"last_activity_at": self._ts(30)},
        ]
        avg = _contacts_engagement_avg_days(contacts)
        assert avg is not None
        assert 19 <= avg <= 21  # ~20

    def test_avg_days_empty(self):
        assert _contacts_engagement_avg_days([]) is None

    def test_min_days_basic(self):
        contacts = [
            {"last_activity_at": self._ts(5)},
            {"last_activity_at": self._ts(30)},
            {"last_activity_at": self._ts(15)},
        ]
        assert _contacts_engagement_min_days(contacts) == 5

    def test_min_days_empty(self):
        assert _contacts_engagement_min_days([]) is None


# ---------------------------------------------------------------------------
# Display helpers
# ---------------------------------------------------------------------------


class TestDisplayName:
    def test_full_name_preferred(self):
        contact = {"full_name": "Alice Wong", "first_name": "A", "last_name": "W"}
        assert _contacts_engagement_display_name(contact) == "Alice Wong"

    def test_name_field(self):
        contact = {"name": "Bob Jones"}
        assert _contacts_engagement_display_name(contact) == "Bob Jones"

    def test_first_last_concat(self):
        contact = {"first_name": "Carol", "last_name": "Diaz"}
        assert _contacts_engagement_display_name(contact) == "Carol Diaz"

    def test_first_only(self):
        contact = {"first_name": "Ed"}
        assert _contacts_engagement_display_name(contact) == "Ed"

    def test_email_fallback(self):
        contact = {"email": "f@g.com"}
        assert _contacts_engagement_display_name(contact) == "f@g.com"

    def test_empty_fallback(self):
        assert _contacts_engagement_display_name({}) == "(unnamed contact)"

    def test_non_dict(self):
        assert _contacts_engagement_display_name("str") == "(unnamed contact)"


class TestClip:
    def test_short_text_unchanged(self):
        assert _contacts_engagement_clip("hello") == "hello"

    def test_long_text_truncated(self):
        long = "a" * 150
        result = _contacts_engagement_clip(long, cap=100)
        assert len(result) == 101
        assert result.endswith("…")

    def test_none(self):
        assert _contacts_engagement_clip(None) == ""

    def test_empty(self):
        assert _contacts_engagement_clip("") == ""

    def test_whitespace_only(self):
        assert _contacts_engagement_clip("   ") == ""

    def test_non_string_coerced(self):
        assert _contacts_engagement_clip(42) == "42"

    def test_html_escaped(self):
        assert "&lt;" in _contacts_engagement_clip("<script>")


# ---------------------------------------------------------------------------
# Stats row — LOCK: 4 cards + 3 derived KPIs
# ---------------------------------------------------------------------------


class TestStatsRow:
    def test_has_four_cards(self):
        html_out = _contacts_engagement_stats_row_html([])
        # 4 cards in a grid
        assert "repeat(4,1fr)" in html_out

    def test_has_avg_score_and_avg_days_and_most_recent(self):
        """LOCK: NEW stats shape for contacts entity.

        Distinct from #76 seniority / #77 department (no numeric KPIs)
        and #82/#83 deals (total value / avg amount / oldest age).
        Contacts entity baseline: Total + Avg score + Avg days + Most recent.
        """
        contacts = [
            {"engagement_score": 60, "last_activity_at":
             (datetime.now(timezone.utc) - timedelta(days=5)).isoformat()},
        ]
        html_out = _contacts_engagement_stats_row_html(contacts)
        assert "Total" in html_out
        assert "Avg score" in html_out
        assert "Avg days" in html_out
        assert "Most recent" in html_out

    def test_total_accurate(self):
        contacts = [
            {"first_name": "A"},
            {"first_name": "B"},
            {"first_name": "C"},
        ]
        html_out = _contacts_engagement_stats_row_html(contacts)
        assert ">3<" in html_out

    def test_empty_shows_dashes(self):
        html_out = _contacts_engagement_stats_row_html([])
        assert "—" in html_out  # score/days/recent all dashes

    def test_non_list_treated_as_empty(self):
        html_out = _contacts_engagement_stats_row_html(None)
        assert ">0<" in html_out

    def test_most_recent_today(self):
        now = datetime.now(timezone.utc).isoformat()
        contacts = [{"last_activity_at": now}]
        html_out = _contacts_engagement_stats_row_html(contacts)
        assert "today" in html_out

    def test_most_recent_days_ago(self):
        ts = (datetime.now(timezone.utc) - timedelta(days=10)).isoformat()
        contacts = [{"last_activity_at": ts}]
        html_out = _contacts_engagement_stats_row_html(contacts)
        assert "10d ago" in html_out

    def test_score_rounded(self):
        contacts = [
            {"engagement_score": 55.6},
            {"engagement_score": 44.4},
        ]
        html_out = _contacts_engagement_stats_row_html(contacts)
        assert ">50<" in html_out  # average is 50


# ---------------------------------------------------------------------------
# Header
# ---------------------------------------------------------------------------


class TestHeader:
    def test_contains_label(self):
        html_out = _contacts_engagement_header_html("hot", 5)
        assert "Hot" in html_out

    def test_singular_count(self):
        html_out = _contacts_engagement_header_html("warm", 1)
        assert "1 contact" in html_out
        assert "1 contacts" not in html_out

    def test_plural_count(self):
        html_out = _contacts_engagement_header_html("warm", 5)
        assert "5 contacts" in html_out

    def test_zero_count(self):
        html_out = _contacts_engagement_header_html("cool", 0)
        assert "0 contacts" in html_out

    def test_has_chip_background(self):
        html_out = _contacts_engagement_header_html("hot", 5)
        assert "background:#d1fae5" in html_out

    def test_uppercase_axis_prefix(self):
        html_out = _contacts_engagement_header_html("warm", 5)
        assert "engagement ·" in html_out

    def test_description_present(self):
        html_out = _contacts_engagement_header_html("dormant", 5)
        assert _contacts_engagement_description("dormant") in html_out


# ---------------------------------------------------------------------------
# Row
# ---------------------------------------------------------------------------


class TestRow:
    def test_name_rendered(self):
        contact = {"first_name": "Alice"}
        html_out = _contacts_engagement_row_html(contact)
        assert "Alice" in html_out

    def test_score_chip(self):
        contact = {"first_name": "Alice", "engagement_score": 85}
        html_out = _contacts_engagement_row_html(contact)
        assert "score 85" in html_out

    def test_days_chip(self):
        ts = (datetime.now(timezone.utc) - timedelta(days=3)).isoformat()
        contact = {"first_name": "Alice", "last_activity_at": ts}
        html_out = _contacts_engagement_row_html(contact)
        assert "3d ago" in html_out

    def test_today_chip(self):
        now = datetime.now(timezone.utc).isoformat()
        contact = {"first_name": "Alice", "last_activity_at": now}
        html_out = _contacts_engagement_row_html(contact)
        assert "today" in html_out

    def test_email_rendered(self):
        contact = {"first_name": "Alice", "email": "a@b.com"}
        html_out = _contacts_engagement_row_html(contact)
        assert "a@b.com" in html_out

    def test_xss_in_name_escaped(self):
        contact = {"first_name": "<script>alert(1)</script>"}
        html_out = _contacts_engagement_row_html(contact)
        assert "<script>" not in html_out

    def test_xss_in_email_escaped(self):
        contact = {"first_name": "A", "email": "<img onerror=x>"}
        html_out = _contacts_engagement_row_html(contact)
        assert "<img" not in html_out

    def test_both_chips_empty_ok(self):
        contact = {"first_name": "Nothing"}
        html_out = _contacts_engagement_row_html(contact)
        assert "Nothing" in html_out


# ---------------------------------------------------------------------------
# List
# ---------------------------------------------------------------------------


class TestList:
    def test_renders_up_to_cap(self):
        contacts = [{"first_name": f"C{i}"} for i in range(5)]
        html_out = _contacts_engagement_list_html(contacts)
        for i in range(5):
            assert f"C{i}" in html_out

    def test_cap_enforced(self):
        contacts = [{"first_name": f"C{i}"} for i in range(150)]
        html_out = _contacts_engagement_list_html(contacts)
        assert "C99" in html_out
        assert "C100" not in html_out

    def test_non_dict_filtered(self):
        contacts = [{"first_name": "X"}, "bad", None]
        html_out = _contacts_engagement_list_html(contacts)
        assert "X" in html_out


# ---------------------------------------------------------------------------
# Overflow banner
# ---------------------------------------------------------------------------


class TestOverflow:
    def test_under_cap_no_banner(self):
        assert _contacts_engagement_overflow_banner_html(50, "hot") == ""

    def test_at_cap_no_banner(self):
        assert _contacts_engagement_overflow_banner_html(
            _MAX_CONTACTS_ENGAGEMENT_RENDERED, "hot"
        ) == ""

    def test_over_cap_banner(self):
        html_out = _contacts_engagement_overflow_banner_html(125, "hot")
        assert "+25" in html_out
        assert "GET /contacts?limit=200" in html_out


# ---------------------------------------------------------------------------
# Drill-up — LOCK: specific links
# ---------------------------------------------------------------------------


class TestDrillUp:
    def test_dashboard_link_present(self):
        html_out = _contacts_engagement_drill_up_html("hot")
        assert "g8://contacts/dashboard" in html_out

    def test_includes_siblings(self):
        html_out = _contacts_engagement_drill_up_html("hot")
        for sibling in _CONTACTS_ENGAGEMENT_VALID:
            if sibling == "hot":
                continue
            assert f"g8://contacts/engagement/{sibling}" in html_out

    def test_excludes_self_sibling(self):
        html_out = _contacts_engagement_drill_up_html("hot")
        assert "g8://contacts/engagement/hot" not in html_out

    def test_cross_axis_seniority(self):
        html_out = _contacts_engagement_drill_up_html("hot")
        assert "g8://contacts/seniority/c-level" in html_out

    def test_cross_axis_department(self):
        html_out = _contacts_engagement_drill_up_html("hot")
        assert "g8://contacts/department/engineering" in html_out

    def test_cross_entity_deals(self):
        html_out = _contacts_engagement_drill_up_html("hot")
        assert "g8://deals/pipeline" in html_out


# ---------------------------------------------------------------------------
# Empty state
# ---------------------------------------------------------------------------


class TestEmptyState:
    def test_unavailable_shows_valid_options(self):
        html_out = _contacts_engagement_empty_state_html("xxx", "unavailable")
        for key in _CONTACTS_ENGAGEMENT_VALID:
            assert key in html_out

    def test_empty_valid_label(self):
        html_out = _contacts_engagement_empty_state_html("hot", "empty")
        assert "No Hot contacts" in html_out


# ---------------------------------------------------------------------------
# render_contacts_engagement_html
# ---------------------------------------------------------------------------


class TestRenderHtml:
    def test_invalid_level_unavailable(self):
        html_out = render_contacts_engagement_html(contacts=[], level="xxx")
        assert "Engagement level not recognized" in html_out

    def test_dashboard_literal_unavailable(self):
        html_out = render_contacts_engagement_html(
            contacts=[], level="dashboard"
        )
        assert "Engagement level not recognized" in html_out

    def test_empty_contacts_shows_empty_state(self):
        html_out = render_contacts_engagement_html(contacts=[], level="hot")
        assert "No Hot contacts" in html_out

    def test_renders_one_contact(self):
        contacts = [{"first_name": "Alice", "engagement_score": 90}]
        html_out = render_contacts_engagement_html(
            contacts=contacts, level="hot"
        )
        assert "Alice" in html_out
        assert "1 contact" in html_out

    def test_renders_many_contacts(self):
        contacts = [
            {"first_name": f"C{i}", "engagement_score": 90}
            for i in range(3)
        ]
        html_out = render_contacts_engagement_html(
            contacts=contacts, level="hot"
        )
        assert "3 contacts" in html_out

    def test_alias_resolves(self):
        contacts = [{"first_name": "X", "engagement_score": 90}]
        html_out = render_contacts_engagement_html(
            contacts=contacts, level="active"
        )
        assert "Hot" in html_out  # alias normalized

    def test_sort_by_score_desc(self):
        contacts = [
            {"first_name": "Low", "engagement_score": 80},
            {"first_name": "High", "engagement_score": 99},
            {"first_name": "Mid", "engagement_score": 85},
        ]
        html_out = render_contacts_engagement_html(
            contacts=contacts, level="hot"
        )
        assert html_out.index("High") < html_out.index("Mid") < html_out.index("Low")

    def test_sort_breaks_ties_by_days(self):
        now = datetime.now(timezone.utc)
        contacts = [
            {"first_name": "Old", "engagement_score": 90,
             "last_activity_at": (now - timedelta(days=50)).isoformat()},
            {"first_name": "New", "engagement_score": 90,
             "last_activity_at": (now - timedelta(days=1)).isoformat()},
        ]
        html_out = render_contacts_engagement_html(
            contacts=contacts, level="hot"
        )
        assert html_out.index("New") < html_out.index("Old")

    def test_non_matching_contacts_filtered_out(self):
        contacts = [
            {"first_name": "Hot", "engagement_score": 90},
            {"first_name": "Cold", "engagement_score": 5},
        ]
        html_out = render_contacts_engagement_html(
            contacts=contacts, level="hot"
        )
        assert "Hot" in html_out
        # Cold contact not rendered
        assert ">Cold<" not in html_out


class TestRenderHtmlStructure:
    def test_has_doctype(self):
        html_out = render_contacts_engagement_html(contacts=[], level="hot")
        assert html_out.startswith("<!DOCTYPE html>")

    def test_has_title(self):
        html_out = render_contacts_engagement_html(contacts=[], level="hot")
        assert "<title>" in html_out

    def test_has_max_width(self):
        html_out = render_contacts_engagement_html(contacts=[], level="hot")
        assert "max-width:960px" in html_out


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------


class TestTextFallback:
    def test_invalid_level_unrecognized(self):
        txt = render_contacts_engagement_text_fallback(
            contacts=[], level="xxx"
        )
        assert "not recognized" in txt.lower()

    def test_valid_levels_listed_on_unrecognized(self):
        txt = render_contacts_engagement_text_fallback(
            contacts=[], level="xxx"
        )
        for key in _CONTACTS_ENGAGEMENT_VALID:
            assert key in txt

    def test_empty_list_no_contacts_msg(self):
        txt = render_contacts_engagement_text_fallback(
            contacts=[], level="hot"
        )
        assert "No Hot contacts" in txt

    def test_one_contact_rendered(self):
        txt = render_contacts_engagement_text_fallback(
            contacts=[{"first_name": "Alice", "engagement_score": 90}],
            level="hot",
        )
        assert "Alice" in txt

    def test_score_in_output(self):
        txt = render_contacts_engagement_text_fallback(
            contacts=[{"first_name": "A", "engagement_score": 85}],
            level="hot",
        )
        assert "score 85" in txt

    def test_siblings_in_related(self):
        txt = render_contacts_engagement_text_fallback(
            contacts=[], level="hot"
        )
        for sibling in _CONTACTS_ENGAGEMENT_VALID:
            if sibling == "hot":
                continue
            assert f"g8://contacts/engagement/{sibling}" in txt

    def test_cross_axis_present(self):
        txt = render_contacts_engagement_text_fallback(
            contacts=[], level="hot"
        )
        assert "seniority/c-level" in txt
        assert "department/engineering" in txt

    def test_cross_entity_present(self):
        txt = render_contacts_engagement_text_fallback(
            contacts=[], level="hot"
        )
        assert "deals/pipeline" in txt

    def test_overflow_explainer(self):
        contacts = [
            {"first_name": f"C{i}", "engagement_score": 90}
            for i in range(150)
        ]
        txt = render_contacts_engagement_text_fallback(
            contacts=contacts, level="hot"
        )
        assert "+50" in txt

    def test_dashboard_literal_unavailable(self):
        txt = render_contacts_engagement_text_fallback(
            contacts=[], level="dashboard"
        )
        assert "not recognized" in txt.lower()


# ---------------------------------------------------------------------------
# Design tokens — LOCK: graph8 palette only
# ---------------------------------------------------------------------------


class TestDesignTokens:
    @pytest.mark.parametrize("banned_hex", [
        "#1d4ed8",  # Studio blue
        "#166534",  # Studio green
        "#991b1b",  # Studio red
        "#0891b2",  # Studio cyan
    ])
    def test_banned_studio_hex_absent(self, banned_hex):
        html_out = render_contacts_engagement_html(
            contacts=[{"first_name": "A", "engagement_score": 90}],
            level="hot",
        )
        assert banned_hex.lower() not in html_out.lower()

    def test_primary_purple_present(self):
        html_out = render_contacts_engagement_html(
            contacts=[{"first_name": "A"}], level="hot",
        )
        # Primary used somewhere (chip bg on warm renders, Total card)
        # at minimum present in accent KPI
        assert "#7d2df3" in html_out.lower() or "#f2eafe" in html_out.lower()

    def test_aeonik_font(self):
        html_out = render_contacts_engagement_html(
            contacts=[], level="hot",
        )
        assert "Aeonik" in html_out

    def test_border_token(self):
        html_out = render_contacts_engagement_html(
            contacts=[], level="hot",
        )
        assert "#dfdfdf" in html_out


# ---------------------------------------------------------------------------
# No JS / safe HTML
# ---------------------------------------------------------------------------


class TestNoJs:
    def test_no_script_tags(self):
        contact = {
            "first_name": "A",
            "engagement_score": 90,
            "email": "<script>alert(1)</script>",
        }
        html_out = render_contacts_engagement_html(
            contacts=[contact], level="hot"
        )
        # No raw <script> tags anywhere
        assert "<script>" not in html_out

    def test_no_event_handlers(self):
        contact = {
            "first_name": '<img onerror="alert(1)">',
            "engagement_score": 90,
        }
        html_out = render_contacts_engagement_html(
            contacts=[contact], level="hot",
        )
        # No raw <img or <script tags — XSS-safe
        assert "<img" not in html_out


# ---------------------------------------------------------------------------
# Smoke — end-to-end rendering covers all 5 levels + text variants
# ---------------------------------------------------------------------------


class TestSmoke:
    @pytest.mark.parametrize("level", list(_CONTACTS_ENGAGEMENT_VALID))
    def test_html_renders_every_level(self, level):
        contacts = [
            {"first_name": "A", "engagement_score": 90},
            {"first_name": "B", "engagement_score": 70},
            {"first_name": "C", "engagement_score": 50},
            {"first_name": "D", "engagement_score": 30},
            {"first_name": "E", "engagement_score": 10},
        ]
        html_out = render_contacts_engagement_html(
            contacts=contacts, level=level,
        )
        assert "<!DOCTYPE" in html_out
        assert _CONTACTS_ENGAGEMENT_LABELS[level] in html_out

    @pytest.mark.parametrize("level", list(_CONTACTS_ENGAGEMENT_VALID))
    def test_text_renders_every_level(self, level):
        txt = render_contacts_engagement_text_fallback(
            contacts=[{"first_name": "X", "engagement_score": 90}],
            level=level,
        )
        assert txt.startswith("# Contacts ·")

    @pytest.mark.parametrize("alias", [
        "active", "engaged", "high", "priority",
        "medium", "nurturing", "recent",
        "slowing", "stale", "fading",
        "low", "unengaged", "disengaged",
        "inactive", "archived", "churned", "lost",
        "a-tier", "b-tier", "c-tier", "d-tier", "e-tier", "f-tier",
    ])
    def test_alias_renders_cleanly(self, alias):
        html_out = render_contacts_engagement_html(
            contacts=[{"first_name": "A", "engagement_score": 90}],
            level=alias,
        )
        assert "<!DOCTYPE" in html_out
        assert "Engagement level not recognized" not in html_out

    def test_none_contacts_renders_unavailable(self):
        html_out = render_contacts_engagement_html(
            contacts=None, level="hot",
        )
        assert "<!DOCTYPE" in html_out


# ---------------------------------------------------------------------------
# Final sanity: each renderer returns a string
# ---------------------------------------------------------------------------


class TestReturnTypes:
    def test_html_returns_str(self):
        out = render_contacts_engagement_html(contacts=[], level="hot")
        assert isinstance(out, str)

    def test_text_returns_str(self):
        out = render_contacts_engagement_text_fallback(contacts=[], level="hot")
        assert isinstance(out, str)
