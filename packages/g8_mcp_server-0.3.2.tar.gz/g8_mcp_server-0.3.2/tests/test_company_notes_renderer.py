"""Unit tests for Upgrade 4 surface #37: per-company notes HTML renderer.

Mirror of `test_contact_notes_renderer.py` but scoped to companies.
Ships with graph8 design tokens from the start — tests lock in the
absence of AI-tell accent borders.

Design parity assertions (vs surface #34 contact notes):
    - Uniform 1px solid #dfdfdf border on every card (no `border-top:
      3px solid <accent>` pattern)
    - shadow-xs on cards
    - shadcn Badge variants for pills (outline + warning + default)
    - Aeonik font-family first (no `-apple-system` first)
    - #7d2df3 primary, #059669/#ca3214/#a0750a semantic colors only
    - Company label chain: name > domain > "Company" (NOT contact's
      first/last/display/email chain)
"""

from __future__ import annotations

import html
import pytest

from g8_mcp_server.app_renderer import (
    _company_notes_author_label,
    _company_notes_clip_content,
    _company_notes_group_by_author,
    _company_notes_stat_card,
    _render_company_notes_empty_state_html,
    render_company_notes_html,
    render_company_notes_text_fallback,
)


# =============================================================== #
# Helpers                                                         #
# =============================================================== #


def _make_note(
    *,
    id: str | int = 1,
    content: str = "hello world",
    created_at: str = "2026-04-21T10:00:00Z",
    updated_at: str | None = None,
    created_by: str | None = "user_1",
    created_by_name: str | None = "Alice",
) -> dict:
    return {
        "id": id,
        "content": content,
        "created_at": created_at,
        "updated_at": updated_at or created_at,
        "created_by": created_by,
        "created_by_name": created_by_name,
    }


# =============================================================== #
# _company_notes_clip_content                                     #
# =============================================================== #


class TestClipContent:
    def test_none_returns_empty_marker(self):
        assert _company_notes_clip_content(None) == "(empty note)"

    def test_empty_string(self):
        assert _company_notes_clip_content("") == "(empty note)"

    def test_whitespace_only(self):
        assert _company_notes_clip_content("   \n  \t ") == "(empty note)"

    def test_non_string(self):
        assert _company_notes_clip_content(42) == "(empty note)"
        assert _company_notes_clip_content(["a", "b"]) == "(empty note)"

    def test_preserves_internal_newlines(self):
        assert (
            _company_notes_clip_content("line1\nline2")
            == "line1\nline2"
        )

    def test_clips_at_boundary(self):
        long = "x" * 700
        result = _company_notes_clip_content(long)
        assert len(result) <= 601  # 600 chars + ellipsis
        assert result.endswith("…")

    def test_under_boundary_unchanged(self):
        s = "x" * 600
        assert _company_notes_clip_content(s) == s

    def test_strips_outer_whitespace(self):
        assert _company_notes_clip_content("  hello  ") == "hello"


# =============================================================== #
# _company_notes_author_label                                     #
# =============================================================== #


class TestAuthorLabel:
    def test_created_by_name_preferred(self):
        note = {"created_by_name": "Alice", "created_by": "user_1"}
        assert _company_notes_author_label(note) == "Alice"

    def test_fallback_to_created_by(self):
        note = {"created_by": "user_1"}
        assert _company_notes_author_label(note) == "user_1"

    def test_fallback_to_unknown_when_both_missing(self):
        note = {}
        assert _company_notes_author_label(note) == "Unknown"

    def test_non_dict_input(self):
        assert _company_notes_author_label("not a dict") == "Unknown"
        assert _company_notes_author_label(None) == "Unknown"

    def test_whitespace_name_falls_through_to_created_by(self):
        note = {"created_by_name": "   ", "created_by": "user_1"}
        assert _company_notes_author_label(note) == "user_1"

    def test_empty_created_by_falls_to_unknown(self):
        note = {"created_by": ""}
        assert _company_notes_author_label(note) == "Unknown"

    def test_long_name_clipped(self):
        note = {"created_by_name": "A" * 200}
        result = _company_notes_author_label(note)
        assert len(result) <= 81  # 80 + ellipsis
        assert result.endswith("…")


# =============================================================== #
# _company_notes_group_by_author                                  #
# =============================================================== #


class TestGroupByAuthor:
    def test_empty_list(self):
        assert _company_notes_group_by_author([]) == []

    def test_single_author_count(self):
        notes = [
            _make_note(created_by_name="Alice", created_at="2026-04-20"),
            _make_note(created_by_name="Alice", created_at="2026-04-21"),
        ]
        result = _company_notes_group_by_author(notes)
        assert len(result) == 1
        assert result[0]["author"] == "Alice"
        assert result[0]["count"] == 2
        assert result[0]["last_seen"] == "2026-04-21"
        assert result[0]["first_seen"] == "2026-04-20"

    def test_multi_author_count_desc(self):
        notes = [
            _make_note(created_by_name="Alice", created_at="2026-04-20"),
            _make_note(created_by_name="Bob", created_at="2026-04-21"),
            _make_note(created_by_name="Alice", created_at="2026-04-22"),
            _make_note(created_by_name="Alice", created_at="2026-04-23"),
        ]
        result = _company_notes_group_by_author(notes)
        assert [b["author"] for b in result] == ["Alice", "Bob"]

    def test_tied_counts_recency_tiebreak(self):
        """Within tied counts, the most-recently-active author wins."""
        notes = [
            _make_note(created_by_name="Old", created_at="2026-04-01"),
            _make_note(created_by_name="New", created_at="2026-04-30"),
        ]
        result = _company_notes_group_by_author(notes)
        # Both have count=1, but New has more recent last_seen
        assert result[0]["author"] == "New"

    def test_non_dict_filtered(self):
        notes = [
            _make_note(created_by_name="Alice"),
            "not a note",
            None,
            42,
        ]
        result = _company_notes_group_by_author(notes)
        assert len(result) == 1
        assert result[0]["author"] == "Alice"

    def test_missing_timestamp(self):
        notes = [{"created_by_name": "Alice"}]
        result = _company_notes_group_by_author(notes)
        assert result[0]["last_seen"] is None
        assert result[0]["first_seen"] is None

    def test_unknown_bucketing(self):
        """Notes without any author info bucket under 'Unknown'."""
        notes = [
            _make_note(created_by_name=None, created_by=None),
            _make_note(created_by_name=None, created_by=None),
        ]
        result = _company_notes_group_by_author(notes)
        assert len(result) == 1
        assert result[0]["author"] == "Unknown"
        assert result[0]["count"] == 2


# =============================================================== #
# _company_notes_stat_card — graph8 token parity                  #
# =============================================================== #


class TestStatCard:
    def test_label_escaped(self):
        html_str = _company_notes_stat_card("<script>", "42")
        assert "&lt;script&gt;" in html_str
        assert "<script>" not in html_str

    def test_value_escaped(self):
        html_str = _company_notes_stat_card("Count", "<img>")
        assert "&lt;img&gt;" in html_str

    def test_uses_graph8_border(self):
        """Uniform #dfdfdf border — NO single-side accent bar."""
        html_str = _company_notes_stat_card("Count", "42")
        assert "1px solid #dfdfdf" in html_str

    def test_no_accent_border(self):
        """No `border-top: 3px solid` pattern (AI-tell)."""
        html_str = _company_notes_stat_card("Count", "42")
        assert "border-top:3px" not in html_str
        assert "border-top: 3px" not in html_str
        # No rotating accent hex colors from the old palette
        for banned in ("#6366f1", "#16a34a", "#dc2626", "#f59e0b", "#9ca3af"):
            assert banned not in html_str, (
                f"stat card must not contain legacy accent {banned}"
            )

    def test_has_shadow_xs(self):
        html_str = _company_notes_stat_card("Count", "42")
        assert "0 1px 3px 0 hsl(0 0% 0% / 0.09)" in html_str

    def test_uses_card_radius(self):
        html_str = _company_notes_stat_card("Count", "42")
        assert "border-radius:12px" in html_str


# =============================================================== #
# Empty state                                                     #
# =============================================================== #


class TestEmptyState:
    def test_zero_notes_mode(self):
        html_str = _render_company_notes_empty_state_html(
            company_id="42", zero_notes=True
        )
        assert "No notes yet" in html_str
        assert "POST /companies/{company_id}/notes" in html_str
        assert "<!DOCTYPE html>" in html_str

    def test_not_available_mode(self):
        html_str = _render_company_notes_empty_state_html(
            company_id="42", zero_notes=False
        )
        assert "Notes not available" in html_str
        assert "may be invalid, deleted, or belong to another org" in html_str

    def test_uses_aeonik_font(self):
        html_str = _render_company_notes_empty_state_html(
            company_id="42", zero_notes=True
        )
        assert "Aeonik" in html_str

    def test_uses_graph8_card_border(self):
        """Empty-state card uses uniform #dfdfdf, not accent bar."""
        html_str = _render_company_notes_empty_state_html(
            company_id="42", zero_notes=True
        )
        assert "1px solid #dfdfdf" in html_str
        assert "border-top:3px" not in html_str
        assert "border-top: 3px" not in html_str

    def test_company_id_escaped(self):
        html_str = _render_company_notes_empty_state_html(
            company_id="<script>alert(1)</script>", zero_notes=True
        )
        assert "<script>" not in html_str
        assert "&lt;script&gt;" in html_str

    def test_unknown_id(self):
        html_str = _render_company_notes_empty_state_html(
            company_id="", zero_notes=True
        )
        assert "(unknown)" in html_str


# =============================================================== #
# render_company_notes_html — integration                         #
# =============================================================== #


class TestRenderHtml:
    def test_none_notes_returns_not_available(self):
        html_str = render_company_notes_html(notes=None, company_id="42")
        assert "Notes not available" in html_str

    def test_empty_notes_returns_zero_state(self):
        html_str = render_company_notes_html(notes=[], company_id="42")
        assert "No notes yet" in html_str

    def test_non_dict_notes_filtered_to_empty(self):
        """List of junk should render as zero-state, not crash."""
        html_str = render_company_notes_html(
            notes=["junk", None, 42], company_id="42"
        )
        assert "No notes yet" in html_str

    def test_label_from_name(self):
        html_str = render_company_notes_html(
            notes=[_make_note()],
            company_id="42",
            company={"name": "Acme Inc"},
        )
        assert "Acme Inc" in html_str

    def test_label_fallback_to_domain(self):
        html_str = render_company_notes_html(
            notes=[_make_note()],
            company_id="42",
            company={"domain": "acme.com"},
        )
        assert "acme.com" in html_str

    def test_label_fallback_to_generic(self):
        """No company dict → generic 'Company' label."""
        html_str = render_company_notes_html(
            notes=[_make_note()],
            company_id="42",
            company=None,
        )
        # "Company" appears in header, not just in meta text
        assert "Company" in html_str

    def test_label_prefers_name_over_domain(self):
        html_str = render_company_notes_html(
            notes=[_make_note()],
            company_id="42",
            company={"name": "Acme", "domain": "acme.com"},
        )
        # Both present in the company dict but name wins as display label
        assert "Acme — " in html_str

    def test_total_count(self):
        html_str = render_company_notes_html(
            notes=[_make_note(id=i) for i in range(5)],
            company_id="42",
        )
        assert "5 TOTAL" in html_str

    def test_unique_authors_count(self):
        notes = [
            _make_note(created_by_name="Alice"),
            _make_note(created_by_name="Bob"),
            _make_note(created_by_name="Alice"),
        ]
        html_str = render_company_notes_html(notes=notes, company_id="42")
        # 2 unique authors shows in stat card
        assert ">2<" in html_str

    def test_edits_count(self):
        notes = [
            _make_note(
                created_at="2026-04-20T10:00:00Z",
                updated_at="2026-04-21T10:00:00Z",  # edited
            ),
            _make_note(),  # not edited
        ]
        html_str = render_company_notes_html(notes=notes, company_id="42")
        assert "EDITED" in html_str

    def test_not_edited_no_badge(self):
        notes = [_make_note()]  # updated_at == created_at
        html_str = render_company_notes_html(notes=notes, company_id="42")
        assert "EDITED" not in html_str

    def test_author_overflow_note(self):
        notes = [
            _make_note(created_by_name=f"User{i}", id=i) for i in range(8)
        ]
        html_str = render_company_notes_html(notes=notes, company_id="42")
        # 8 distinct authors; cap is 5
        assert "+ 3 more authors" in html_str

    def test_timeline_overflow_note(self):
        notes = [_make_note(id=i) for i in range(25)]  # cap is 20
        html_str = render_company_notes_html(notes=notes, company_id="42")
        assert "+ 5 older notes" in html_str
        assert "GET /companies/42/notes" in html_str

    def test_drill_up_links(self):
        html_str = render_company_notes_html(
            notes=[_make_note()],
            company_id="42",
        )
        assert "g8://companies/42" in html_str
        assert "POST /companies/42/notes" in html_str

    def test_uses_aeonik_font(self):
        html_str = render_company_notes_html(
            notes=[_make_note()], company_id="42"
        )
        assert "Aeonik" in html_str

    def test_uses_graph8_primary(self):
        html_str = render_company_notes_html(
            notes=[_make_note()], company_id="42"
        )
        assert "#7d2df3" in html_str

    def test_no_single_side_accent_borders(self):
        """No AI-tell pattern anywhere in the rendered HTML."""
        notes = [
            _make_note(id=i, updated_at="2026-04-30T10:00:00Z") for i in range(3)
        ]
        html_str = render_company_notes_html(notes=notes, company_id="42")
        assert "border-top:3px" not in html_str
        assert "border-top: 3px" not in html_str
        assert "border-left:3px" not in html_str
        assert "border-left: 3px" not in html_str

    def test_no_legacy_accent_hexes(self):
        """None of surface #34's contact-notes accent hexes should appear."""
        notes = [
            _make_note(
                id=i,
                created_by_name=f"U{i}",
                updated_at="2026-04-30T10:00:00Z",
            )
            for i in range(2)
        ]
        html_str = render_company_notes_html(notes=notes, company_id="42")
        # Legacy contact-notes palette colors that AI-tell as accent bars
        for legacy in ("#6366f1", "#16a34a", "#dc2626", "#9ca3af"):
            assert legacy not in html_str, (
                f"company notes renderer must not contain legacy {legacy}"
            )

    def test_author_xss_escape(self):
        notes = [
            _make_note(
                created_by_name="<script>alert(1)</script>",
                id="n1",
            )
        ]
        html_str = render_company_notes_html(notes=notes, company_id="42")
        assert "<script>" not in html_str
        assert "&lt;script&gt;" in html_str

    def test_content_xss_escape(self):
        notes = [_make_note(content="<img src=x onerror=alert(1)>")]
        html_str = render_company_notes_html(notes=notes, company_id="42")
        # Content is escaped
        assert "<img src=x onerror" not in html_str
        assert "&lt;img" in html_str

    def test_company_id_xss_escape(self):
        html_str = render_company_notes_html(
            notes=[_make_note()],
            company_id="<script>alert(1)</script>",
        )
        assert "<script>alert" not in html_str

    def test_id_chip_escape(self):
        notes = [_make_note(id="<img>")]
        html_str = render_company_notes_html(notes=notes, company_id="42")
        assert "<img>" not in html_str
        assert "&lt;img&gt;" in html_str

    def test_no_double_escape(self):
        notes = [_make_note(content="A & B")]
        html_str = render_company_notes_html(notes=notes, company_id="42")
        # Should have &amp; once, not &amp;amp;
        assert "&amp;amp;" not in html_str
        assert "&amp;" in html_str

    def test_timestamp_in_timeline(self):
        notes = [_make_note(created_at="2026-04-21T10:00:00Z")]
        html_str = render_company_notes_html(notes=notes, company_id="42")
        assert "2026-04-21T10:00:00Z" in html_str

    def test_percentage_breakdown(self):
        """Author section shows count + percentage."""
        notes = [
            _make_note(created_by_name="Alice"),
            _make_note(created_by_name="Alice"),
            _make_note(created_by_name="Bob"),
            _make_note(created_by_name="Bob"),
        ]
        html_str = render_company_notes_html(notes=notes, company_id="42")
        # Each has 50%
        assert "(50%)" in html_str

    def test_singular_vs_plural_author_word(self):
        notes = [_make_note(created_by_name="Alice")]
        html_str = render_company_notes_html(notes=notes, company_id="42")
        assert "1 note " in html_str or "1 note<" in html_str

    def test_valid_html_doctype(self):
        html_str = render_company_notes_html(
            notes=[_make_note()], company_id="42"
        )
        assert html_str.startswith("<!DOCTYPE html>")
        assert html_str.rstrip().endswith("</html>")


# =============================================================== #
# Text fallback                                                   #
# =============================================================== #


class TestTextFallback:
    def test_none_notes_returns_not_available(self):
        text = render_company_notes_text_fallback(notes=None, company_id="42")
        assert "# Notes not available" in text
        assert "Company id: 42" in text

    def test_empty_notes_returns_zero_state(self):
        text = render_company_notes_text_fallback(notes=[], company_id="42")
        assert "# No notes yet" in text
        assert "POST /companies/42/notes" in text

    def test_header_uses_name(self):
        text = render_company_notes_text_fallback(
            notes=[_make_note()],
            company_id="42",
            company={"name": "Acme Inc"},
        )
        assert "# Acme Inc — notes" in text

    def test_header_fallback_to_domain(self):
        text = render_company_notes_text_fallback(
            notes=[_make_note()],
            company_id="42",
            company={"domain": "acme.com"},
        )
        assert "# acme.com — notes" in text

    def test_header_fallback_to_generic(self):
        text = render_company_notes_text_fallback(
            notes=[_make_note()], company_id="42"
        )
        assert "# Company — notes" in text

    def test_stats_block(self):
        notes = [_make_note(id=i) for i in range(3)]
        text = render_company_notes_text_fallback(notes=notes, company_id="42")
        assert "- Total notes: 3" in text
        assert "- Unique authors: 1" in text

    def test_authors_section(self):
        notes = [
            _make_note(created_by_name="Alice"),
            _make_note(created_by_name="Bob"),
        ]
        text = render_company_notes_text_fallback(notes=notes, company_id="42")
        assert "## Authors (2 unique)" in text
        assert "Alice:" in text
        assert "Bob:" in text

    def test_recent_notes_section(self):
        notes = [_make_note(id=1, content="hello")]
        text = render_company_notes_text_fallback(notes=notes, company_id="42")
        assert "## Recent notes (1 of 1)" in text
        assert "hello" in text

    def test_edited_suffix(self):
        notes = [
            _make_note(
                id=1,
                created_at="2026-04-20T10:00:00Z",
                updated_at="2026-04-21T10:00:00Z",
            )
        ]
        text = render_company_notes_text_fallback(notes=notes, company_id="42")
        assert "(edited):" in text

    def test_no_edited_suffix_when_unchanged(self):
        notes = [_make_note(id=1)]
        text = render_company_notes_text_fallback(notes=notes, company_id="42")
        assert "(edited)" not in text

    def test_newline_flattened_in_content(self):
        notes = [_make_note(id=1, content="line1\nline2")]
        text = render_company_notes_text_fallback(notes=notes, company_id="42")
        assert " ⏎ " in text

    def test_overflow_note(self):
        notes = [_make_note(id=i) for i in range(25)]  # cap 20
        text = render_company_notes_text_fallback(notes=notes, company_id="42")
        assert "+ 5 older notes" in text

    def test_drill_up_section(self):
        text = render_company_notes_text_fallback(
            notes=[_make_note()], company_id="42"
        )
        assert "## Drill into this company" in text
        assert "g8://companies/42" in text
        assert "POST /companies/42/notes" in text

    def test_ends_with_newline(self):
        text = render_company_notes_text_fallback(
            notes=[_make_note()], company_id="42"
        )
        assert text.endswith("\n")


# =============================================================== #
# Smoke                                                           #
# =============================================================== #


class TestSmoke:
    def test_20_mixed_notes_render(self):
        """Mixed-author, some-edited render without error."""
        notes = [
            _make_note(
                id=i,
                created_by_name=f"User{i % 3}",
                updated_at=(
                    "2026-04-22T10:00:00Z"
                    if i % 2 == 0
                    else f"2026-04-21T{10 + i % 10}:00:00Z"
                ),
                content=f"Note content {i}",
            )
            for i in range(20)
        ]
        html_str = render_company_notes_html(
            notes=notes,
            company_id="acme-1",
            company={"name": "Acme Inc"},
        )
        text = render_company_notes_text_fallback(
            notes=notes,
            company_id="acme-1",
            company={"name": "Acme Inc"},
        )
        assert "<!DOCTYPE html>" in html_str
        assert "Acme Inc" in html_str
        assert "# Acme Inc — notes" in text
