"""Unit tests for surface #30 — campaign document detail renderer.

Covers the palette + helper fns in app_renderer.py for the per-document
overview surface:

  g8://campaigns/{campaign_id}/documents/{document_id}/overview
  g8://campaigns/{campaign_id}/documents/{document_id}/overview.txt

Focus areas:
- display-name precedence (name > type > "Document")
- humanize-type logic (acronyms, snake_case, empty)
- content-summary counters (chars / words / lines)
- stat-card and info-row fragments (escape, structure)
- empty-state card (escape paths, pointer text)
- HTML renderer (status/type badges, version formatting, content preview,
  truncation banner, missing-content branch, drill-up hint)
- text fallback (same fields, markdown mirror, truncation banner)
"""

from __future__ import annotations

import json

import pytest

from g8_mcp_server.app_renderer import (
    _campaign_doc_detail_content_summary,
    _campaign_doc_detail_derive_display_name,
    _campaign_doc_detail_humanize_type,
    _campaign_doc_detail_info_row,
    _campaign_doc_detail_stat_card,
    _render_campaign_doc_detail_empty_state_html,
    render_campaign_document_detail_html,
    render_campaign_document_detail_text_fallback,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _sample_document() -> dict:
    return {
        "id": "doc-abc-123",
        "campaign_id": "cmp-xyz-456",
        "name": "Q2 Ad Copy v2",
        "type": "ad_copy",
        "status": "ready",
        "version": 2,
        "content": (
            "Headline: Ship faster with graph8.\n"
            "Subhead: Our AI packs a decade of GTM expertise.\n"
            "\n"
            "Call to action: Start free trial."
        ),
        "created_at": "2026-04-01T12:00:00Z",
        "updated_at": "2026-04-15T08:30:00Z",
    }


# ---------------------------------------------------------------------------
# _campaign_doc_detail_derive_display_name
# ---------------------------------------------------------------------------


class TestDeriveDisplayName:
    def test_prefers_name(self):
        doc = {"name": "Q2 Ad Copy", "type": "ad_copy"}
        assert _campaign_doc_detail_derive_display_name(doc) == "Q2 Ad Copy"

    def test_strips_whitespace_from_name(self):
        doc = {"name": "   Q2 Ad Copy   "}
        assert _campaign_doc_detail_derive_display_name(doc) == "Q2 Ad Copy"

    def test_falls_back_to_type(self):
        doc = {"type": "ad_copy"}
        assert _campaign_doc_detail_derive_display_name(doc) == "Ad copy"

    def test_falls_back_to_file_type(self):
        doc = {"file_type": "landing_page"}
        assert _campaign_doc_detail_derive_display_name(doc) == "Landing page"

    def test_final_fallback(self):
        assert _campaign_doc_detail_derive_display_name({}) == "Document"

    def test_empty_name_falls_through(self):
        doc = {"name": "", "type": "brief"}
        assert _campaign_doc_detail_derive_display_name(doc) == "Brief"

    def test_whitespace_name_falls_through(self):
        doc = {"name": "   ", "type": "brief"}
        assert _campaign_doc_detail_derive_display_name(doc) == "Brief"

    def test_non_string_name_ignored(self):
        doc = {"name": 123, "type": "brief"}
        assert _campaign_doc_detail_derive_display_name(doc) == "Brief"

    def test_non_dict_input(self):
        assert _campaign_doc_detail_derive_display_name(None) == "Document"
        assert _campaign_doc_detail_derive_display_name("string") == "Document"
        assert _campaign_doc_detail_derive_display_name([]) == "Document"


# ---------------------------------------------------------------------------
# _campaign_doc_detail_humanize_type
# ---------------------------------------------------------------------------


class TestHumanizeType:
    def test_snake_case(self):
        assert _campaign_doc_detail_humanize_type("ad_copy") == "Ad copy"

    def test_kebab_case(self):
        assert _campaign_doc_detail_humanize_type("landing-page") == "Landing page"

    def test_preserves_short_acronyms(self):
        assert _campaign_doc_detail_humanize_type("ICP") == "ICP"
        assert _campaign_doc_detail_humanize_type("FAQ") == "FAQ"
        assert _campaign_doc_detail_humanize_type("CTA") == "CTA"

    def test_does_not_preserve_long_uppercase(self):
        # >5 chars should NOT be treated as an acronym
        result = _campaign_doc_detail_humanize_type("LONGNAME")
        assert result == "LONGNAME"  # already starts upper, first char stays

    def test_preserves_version_suffix(self):
        assert _campaign_doc_detail_humanize_type("ad_copy_v2") == "Ad copy v2"

    def test_single_word(self):
        assert _campaign_doc_detail_humanize_type("brief") == "Brief"

    def test_empty_string(self):
        assert _campaign_doc_detail_humanize_type("") == ""

    def test_whitespace(self):
        assert _campaign_doc_detail_humanize_type("   ") == ""

    def test_none(self):
        assert _campaign_doc_detail_humanize_type(None) == ""

    def test_non_string(self):
        assert _campaign_doc_detail_humanize_type(123) == ""
        assert _campaign_doc_detail_humanize_type([]) == ""


# ---------------------------------------------------------------------------
# _campaign_doc_detail_content_summary
# ---------------------------------------------------------------------------


class TestContentSummary:
    def test_none_content(self):
        summary = _campaign_doc_detail_content_summary(None)
        assert summary == {
            "char_count": 0,
            "word_count": 0,
            "line_count": 0,
            "has_content": False,
        }

    def test_empty_string(self):
        summary = _campaign_doc_detail_content_summary("")
        assert summary["has_content"] is False
        assert summary["char_count"] == 0

    def test_whitespace_only(self):
        summary = _campaign_doc_detail_content_summary("   \n\t  ")
        # char_count counts all chars; has_content checks strip()
        assert summary["has_content"] is False
        assert summary["char_count"] > 0

    def test_simple_string(self):
        summary = _campaign_doc_detail_content_summary("hello world")
        assert summary["has_content"] is True
        assert summary["char_count"] == 11
        assert summary["word_count"] == 2
        assert summary["line_count"] == 1

    def test_multiline_string(self):
        summary = _campaign_doc_detail_content_summary("line 1\nline 2\nline 3")
        assert summary["word_count"] == 6
        assert summary["line_count"] == 3

    def test_structured_content_serializes(self):
        payload = {"headline": "Hello", "cta": "Go"}
        summary = _campaign_doc_detail_content_summary(payload)
        assert summary["has_content"] is True
        assert summary["char_count"] == len(json.dumps(payload, default=str))

    def test_list_content(self):
        payload = ["a", "b", "c"]
        summary = _campaign_doc_detail_content_summary(payload)
        assert summary["has_content"] is True
        assert summary["char_count"] > 0


# ---------------------------------------------------------------------------
# _campaign_doc_detail_stat_card
# ---------------------------------------------------------------------------


class TestStatCard:
    def test_basic(self):
        html_out = _campaign_doc_detail_stat_card("Version", "v2")
        assert 'class="stat-card"' in html_out
        assert ">Version<" in html_out
        assert ">v2<" in html_out

    def test_accent(self):
        html_out = _campaign_doc_detail_stat_card("Status", "Ready", accent="#166534")
        assert "border-top:3px solid #166534" in html_out

    def test_escape(self):
        html_out = _campaign_doc_detail_stat_card("<Label>", "<value>")
        assert "&lt;Label&gt;" in html_out
        assert "&lt;value&gt;" in html_out
        assert "<Label>" not in html_out


# ---------------------------------------------------------------------------
# _campaign_doc_detail_info_row
# ---------------------------------------------------------------------------


class TestInfoRow:
    def test_label_escaped(self):
        html_out = _campaign_doc_detail_info_row("<Status>", "<span>body</span>")
        assert "&lt;Status&gt;" in html_out
        # Value html passes through un-escaped (caller escapes)
        assert "<span>body</span>" in html_out

    def test_structure(self):
        html_out = _campaign_doc_detail_info_row("Status", "ready")
        assert 'class="info-row"' in html_out
        assert 'class="info-label"' in html_out
        assert 'class="info-value"' in html_out


# ---------------------------------------------------------------------------
# _render_campaign_doc_detail_empty_state_html
# ---------------------------------------------------------------------------


class TestEmptyState:
    def test_basic(self):
        html_out = _render_campaign_doc_detail_empty_state_html(
            campaign_id="cmp-1",
            document_id="doc-1",
            reason="No document data available.",
        )
        assert "Document not available" in html_out
        assert "No document data available." in html_out
        assert "cmp-1" in html_out
        assert "doc-1" in html_out

    def test_escape_ids(self):
        # _clip already HTML-escapes; passing raw HTML chars must NOT
        # double-escape and must NOT leak through unescaped.
        html_out = _render_campaign_doc_detail_empty_state_html(
            campaign_id="<cmp>",
            document_id="<doc>",
            reason="x",
        )
        assert "&lt;cmp&gt;" in html_out
        assert "&lt;doc&gt;" in html_out
        # Critical regression guard — double-escape would emit &amp;lt;
        assert "&amp;lt;" not in html_out

    def test_escape_reason(self):
        html_out = _render_campaign_doc_detail_empty_state_html(
            campaign_id="a",
            document_id="b",
            reason="<script>alert(1)</script>",
        )
        assert "&lt;script&gt;" in html_out
        assert "<script>" not in html_out

    def test_empty_ids_show_unknown(self):
        html_out = _render_campaign_doc_detail_empty_state_html(
            campaign_id="",
            document_id="",
            reason="x",
        )
        assert "(unknown)" in html_out

    def test_valid_html_structure(self):
        html_out = _render_campaign_doc_detail_empty_state_html(
            campaign_id="x", document_id="y", reason="z"
        )
        assert html_out.startswith("<!DOCTYPE html>")
        assert html_out.rstrip().endswith("</html>")


# ---------------------------------------------------------------------------
# render_campaign_document_detail_html
# ---------------------------------------------------------------------------


class TestRenderHtml:
    def test_none_document_shows_empty_state(self):
        html_out = render_campaign_document_detail_html(
            document=None, campaign_id="c1", document_id="d1"
        )
        assert "Document not available" in html_out

    def test_non_dict_document_shows_empty_state(self):
        html_out = render_campaign_document_detail_html(
            document="string", campaign_id="c1", document_id="d1"
        )
        assert "Document not available" in html_out

    def test_includes_name_title(self):
        doc = _sample_document()
        html_out = render_campaign_document_detail_html(
            document=doc, campaign_id="cmp-xyz-456", document_id="doc-abc-123"
        )
        assert "Q2 Ad Copy v2" in html_out
        assert "<title>Document — Q2 Ad Copy v2</title>" in html_out

    def test_status_badge(self):
        doc = _sample_document()
        html_out = render_campaign_document_detail_html(
            document=doc, campaign_id="c1", document_id="d1"
        )
        assert 'class="status-badge"' in html_out
        assert ">READY<" in html_out

    def test_type_badge(self):
        doc = _sample_document()
        html_out = render_campaign_document_detail_html(
            document=doc, campaign_id="c1", document_id="d1"
        )
        assert 'class="type-badge"' in html_out
        # Humanized label
        assert ">Ad copy<" in html_out

    def test_no_type_badge_when_type_missing(self):
        doc = {"id": "d", "campaign_id": "c", "name": "N", "status": "ready"}
        html_out = render_campaign_document_detail_html(
            document=doc, campaign_id="c", document_id="d"
        )
        assert 'class="type-badge"' not in html_out

    def test_version_formatting_int(self):
        doc = _sample_document()
        html_out = render_campaign_document_detail_html(
            document=doc, campaign_id="c", document_id="d"
        )
        assert ">v2<" in html_out

    def test_version_formatting_str_without_prefix(self):
        doc = _sample_document()
        doc["version"] = "3"
        html_out = render_campaign_document_detail_html(
            document=doc, campaign_id="c", document_id="d"
        )
        assert ">v3<" in html_out

    def test_version_formatting_str_with_prefix(self):
        doc = _sample_document()
        doc["version"] = "v4"
        html_out = render_campaign_document_detail_html(
            document=doc, campaign_id="c", document_id="d"
        )
        assert ">v4<" in html_out

    def test_version_none_shows_dash(self):
        doc = _sample_document()
        doc["version"] = None
        html_out = render_campaign_document_detail_html(
            document=doc, campaign_id="c", document_id="d"
        )
        # Find Version stat card — dash visible
        assert "Version" in html_out

    def test_stat_grid_has_five_cards(self):
        doc = _sample_document()
        html_out = render_campaign_document_detail_html(
            document=doc, campaign_id="c", document_id="d"
        )
        assert html_out.count('class="stat-card"') == 5

    def test_content_preview_rendered(self):
        doc = _sample_document()
        html_out = render_campaign_document_detail_html(
            document=doc, campaign_id="c", document_id="d"
        )
        assert 'class="content-section"' in html_out
        assert "Ship faster with graph8" in html_out

    def test_content_preview_escapes_html(self):
        doc = _sample_document()
        doc["content"] = "<script>alert('xss')</script>"
        html_out = render_campaign_document_detail_html(
            document=doc, campaign_id="c", document_id="d"
        )
        assert "&lt;script&gt;" in html_out
        assert "<script>alert" not in html_out

    def test_empty_content_shows_placeholder(self):
        doc = _sample_document()
        doc["content"] = ""
        html_out = render_campaign_document_detail_html(
            document=doc, campaign_id="c", document_id="d"
        )
        assert "content-empty" in html_out
        assert "has not been generated" in html_out

    def test_truncation_banner_when_content_exceeds_cap(self):
        doc = _sample_document()
        # Blow past _MAX_CAMPAIGN_DOC_DETAIL_CONTENT_PREVIEW_LEN (4000).
        doc["content"] = "x" * 5000
        html_out = render_campaign_document_detail_html(
            document=doc, campaign_id="c", document_id="d"
        )
        assert "Preview truncated" in html_out
        assert 'class="content-truncated"' in html_out

    def test_no_truncation_banner_when_under_cap(self):
        doc = _sample_document()
        html_out = render_campaign_document_detail_html(
            document=doc, campaign_id="c", document_id="d"
        )
        assert 'class="content-truncated"' not in html_out

    def test_structured_content_serialized_as_json(self):
        doc = _sample_document()
        doc["content"] = {"headline": "H", "cta": "Go"}
        html_out = render_campaign_document_detail_html(
            document=doc, campaign_id="c", document_id="d"
        )
        # JSON serialization should render the key:value pairs
        assert "headline" in html_out
        assert '&quot;H&quot;' in html_out or "H" in html_out

    def test_drill_up_hints_present(self):
        doc = _sample_document()
        html_out = render_campaign_document_detail_html(
            document=doc,
            campaign_id="cmp-xyz-456",
            document_id="doc-abc-123",
        )
        assert "g8://campaigns/cmp-xyz-456/documents" in html_out
        assert "g8://campaigns/cmp-xyz-456/overview" in html_out
        assert "g8://campaigns/dashboard" in html_out

    def test_overview_section_rendered_when_fields_present(self):
        doc = _sample_document()
        html_out = render_campaign_document_detail_html(
            document=doc, campaign_id="c", document_id="d"
        )
        assert 'class="overview-section"' in html_out
        assert "Created" in html_out
        assert "Updated" in html_out

    def test_id_escaped_in_header(self):
        doc = _sample_document()
        doc["id"] = "<doc-1>"
        html_out = render_campaign_document_detail_html(
            document=doc, campaign_id="c", document_id="<doc-1>"
        )
        assert "&lt;doc-1&gt;" in html_out
        assert "<doc-1>" not in html_out.replace("&lt;doc-1&gt;", "")

    def test_valid_html_document(self):
        doc = _sample_document()
        html_out = render_campaign_document_detail_html(
            document=doc, campaign_id="c", document_id="d"
        )
        assert html_out.startswith("<!DOCTYPE html>")
        assert html_out.rstrip().endswith("</html>")

    def test_long_name_clipped(self):
        doc = _sample_document()
        doc["name"] = "N" * 500
        html_out = render_campaign_document_detail_html(
            document=doc, campaign_id="c", document_id="d"
        )
        # Content cap is 200 chars — expect ellipsis
        assert "…" in html_out


# ---------------------------------------------------------------------------
# render_campaign_document_detail_text_fallback
# ---------------------------------------------------------------------------


class TestRenderTextFallback:
    def test_none_document(self):
        out = render_campaign_document_detail_text_fallback(
            document=None, campaign_id="c1", document_id="d1"
        )
        assert "Document not available" in out
        assert "c1" in out
        assert "d1" in out

    def test_heading(self):
        doc = _sample_document()
        out = render_campaign_document_detail_text_fallback(
            document=doc, campaign_id="c", document_id="d"
        )
        assert out.startswith("# Q2 Ad Copy v2")

    def test_metadata_section(self):
        doc = _sample_document()
        out = render_campaign_document_detail_text_fallback(
            document=doc, campaign_id="c", document_id="d"
        )
        assert "- Campaign: cmp-xyz-456" in out
        assert "- Document: doc-abc-123" in out
        assert "- Status: ready" in out
        assert "- Type: Ad copy" in out
        assert "- File type: ad_copy" in out
        assert "- Version: 2" in out

    def test_content_summary_counts(self):
        doc = _sample_document()
        out = render_campaign_document_detail_text_fallback(
            document=doc, campaign_id="c", document_id="d"
        )
        assert "## Content summary" in out
        assert "- Characters:" in out
        assert "- Words:" in out
        assert "- Lines:" in out

    def test_content_preview_included(self):
        doc = _sample_document()
        out = render_campaign_document_detail_text_fallback(
            document=doc, campaign_id="c", document_id="d"
        )
        assert "## Content preview" in out
        assert "Ship faster with graph8" in out

    def test_empty_content_marked(self):
        doc = _sample_document()
        doc["content"] = None
        out = render_campaign_document_detail_text_fallback(
            document=doc, campaign_id="c", document_id="d"
        )
        assert "- (empty)" in out
        assert "## Content preview" not in out

    def test_truncation_note_when_over_cap(self):
        doc = _sample_document()
        # 12k+ chars → _MAX_CAMPAIGN_DOC_DETAIL_CONTENT_LEN caps at 12000
        doc["content"] = "x" * 15000
        out = render_campaign_document_detail_text_fallback(
            document=doc, campaign_id="c", document_id="d"
        )
        assert "(truncated" in out

    def test_no_truncation_note_when_under_cap(self):
        doc = _sample_document()
        out = render_campaign_document_detail_text_fallback(
            document=doc, campaign_id="c", document_id="d"
        )
        assert "(truncated" not in out

    def test_structured_content_serialized(self):
        doc = _sample_document()
        doc["content"] = {"a": 1, "b": 2}
        out = render_campaign_document_detail_text_fallback(
            document=doc, campaign_id="c", document_id="d"
        )
        assert '"a": 1' in out

    def test_drill_up_section(self):
        doc = _sample_document()
        out = render_campaign_document_detail_text_fallback(
            document=doc,
            campaign_id="cmp-xyz-456",
            document_id="doc-abc-123",
        )
        assert "## Drill up from this document" in out
        assert "g8://campaigns/cmp-xyz-456/documents" in out
        assert "g8://campaigns/cmp-xyz-456/overview" in out
        assert "g8://campaigns/dashboard" in out

    def test_ends_with_newline(self):
        doc = _sample_document()
        out = render_campaign_document_detail_text_fallback(
            document=doc, campaign_id="c", document_id="d"
        )
        assert out.endswith("\n")

    def test_file_type_suppressed_when_matches_humanized(self):
        """If file_type already matches the humanized type, don't duplicate."""
        doc = _sample_document()
        doc["type"] = "ICP"  # Humanized == "ICP" (acronym preserved)
        out = render_campaign_document_detail_text_fallback(
            document=doc, campaign_id="c", document_id="d"
        )
        assert "- Type: ICP" in out
        # Should not show "File type: ICP" separately
        lines = [line for line in out.split("\n") if line.startswith("- ")]
        assert sum(1 for line in lines if "ICP" in line) == 1

    def test_fallback_for_non_dict(self):
        out = render_campaign_document_detail_text_fallback(
            document="oops", campaign_id="c", document_id="d"
        )
        assert "Document not available" in out
