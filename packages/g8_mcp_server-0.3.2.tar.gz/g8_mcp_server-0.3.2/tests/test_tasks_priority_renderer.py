"""Unit tests for Surface #75 — g8://tasks/priority/{priority}.

Tests the renderer in isolation. Integration test lives in
tests/test_integration.py::test_tasks_priority_app_surface_registered.
"""

import re

import pytest

from mcp_server.g8_mcp_server.app_renderer import (
    _MAX_TASKS_PRIORITY_RENDERED,
    _TASKS_PRIORITY_LABELS,
    _TASKS_PRIORITY_TO_INT,
    _TASKS_PRIORITY_VALID,
    _tasks_priority_clip,
    _tasks_priority_drill_up_html,
    _tasks_priority_empty_state_html,
    _tasks_priority_header_html,
    _tasks_priority_label,
    _tasks_priority_normalize,
    _tasks_priority_overflow_banner_html,
    _tasks_priority_palette,
    _tasks_priority_row_html,
    _tasks_priority_short_label,
    _tasks_priority_stats_row_html,
    _tasks_priority_status_display,
    _tasks_priority_status_palette,
    _tasks_priority_to_int,
    _tasks_priority_urgency_label,
    render_tasks_priority_html,
    render_tasks_priority_text_fallback,
)


# ----------------------------------------------------------------- #
# _tasks_priority_normalize
# ----------------------------------------------------------------- #


class TestNormalize:
    @pytest.mark.parametrize(
        "raw,expected",
        [
            # Canonical
            ("p1", "p1"),
            ("p2", "p2"),
            ("p3", "p3"),
            ("p4", "p4"),
            # Case
            ("P1", "p1"),
            ("P2", "p2"),
            ("P3", "p3"),
            ("P4", "p4"),
            # Aliases — words
            ("urgent", "p1"),
            ("Urgent", "p1"),
            ("URGENT", "p1"),
            ("high", "p2"),
            ("High", "p2"),
            ("medium", "p3"),
            ("Medium", "p3"),
            ("low", "p4"),
            ("Low", "p4"),
            # Aliases — raw ints as strings
            ("1", "p1"),
            ("2", "p2"),
            ("3", "p3"),
            ("4", "p4"),
            # Trimming
            ("  p1  ", "p1"),
            ("\tp2\n", "p2"),
        ],
    )
    def test_valid_inputs(self, raw, expected):
        assert _tasks_priority_normalize(raw) == expected

    @pytest.mark.parametrize(
        "raw",
        [
            "p0",
            "p5",
            "p10",
            "0",  # no-priority sentinel — not a renderable level
            "5",
            "critical",
            "none",
            "bogus",
            "pp1",
            "p 1",
        ],
    )
    def test_invalid_inputs(self, raw):
        assert _tasks_priority_normalize(raw) is None

    @pytest.mark.parametrize(
        "raw",
        [
            None,
            1,
            1.0,
            True,
            [],
            {},
            (),
            object(),
        ],
    )
    def test_non_string_inputs(self, raw):
        assert _tasks_priority_normalize(raw) is None

    def test_empty_string(self):
        assert _tasks_priority_normalize("") is None

    def test_whitespace_only(self):
        assert _tasks_priority_normalize("   ") is None


# ----------------------------------------------------------------- #
# _tasks_priority_label / _short_label / _urgency_label
# ----------------------------------------------------------------- #


class TestLabel:
    def test_canonical(self):
        assert _tasks_priority_label("p1") == "P1 · Urgent"
        assert _tasks_priority_label("p2") == "P2 · High"
        assert _tasks_priority_label("p3") == "P3 · Medium"
        assert _tasks_priority_label("p4") == "P4 · Low"

    def test_unknown_returns_empty(self):
        assert _tasks_priority_label("bogus") == ""
        assert _tasks_priority_label("") == ""

    def test_non_string_returns_empty(self):
        assert _tasks_priority_label(None) == ""
        assert _tasks_priority_label(1) == ""

    def test_case_insensitive(self):
        assert _tasks_priority_label("P1") == "P1 · Urgent"

    def test_short_label(self):
        assert _tasks_priority_short_label("p1") == "P1"
        assert _tasks_priority_short_label("p4") == "P4"
        assert _tasks_priority_short_label("bogus") == ""
        assert _tasks_priority_short_label(None) == ""

    def test_urgency_label(self):
        assert _tasks_priority_urgency_label("p1") == "Urgent"
        assert _tasks_priority_urgency_label("p2") == "High"
        assert _tasks_priority_urgency_label("p3") == "Medium"
        assert _tasks_priority_urgency_label("p4") == "Low"
        assert _tasks_priority_urgency_label("bogus") == ""
        assert _tasks_priority_urgency_label(None) == ""


# ----------------------------------------------------------------- #
# _tasks_priority_to_int
# ----------------------------------------------------------------- #


class TestToInt:
    @pytest.mark.parametrize(
        "key,expected_int",
        [
            ("p1", 1),
            ("p2", 2),
            ("p3", 3),
            ("p4", 4),
            ("urgent", 1),
            ("high", 2),
            ("medium", 3),
            ("low", 4),
            ("1", 1),
            ("2", 2),
            ("3", 3),
            ("4", 4),
            ("P1", 1),
        ],
    )
    def test_valid(self, key, expected_int):
        assert _tasks_priority_to_int(key) == expected_int

    def test_invalid(self):
        assert _tasks_priority_to_int("bogus") is None
        assert _tasks_priority_to_int("") is None
        assert _tasks_priority_to_int(None) is None
        assert _tasks_priority_to_int(1) is None  # must be string
        assert _tasks_priority_to_int("0") is None
        assert _tasks_priority_to_int("5") is None


# ----------------------------------------------------------------- #
# _tasks_priority_palette
# ----------------------------------------------------------------- #


class TestPalette:
    def test_high_priority_is_accent(self):
        bg, fg = _tasks_priority_palette("p1")
        assert bg == "#f2eafe"  # _G8_ACCENT_BG
        assert fg == "#7d2df3"  # _G8_PRIMARY

        bg, fg = _tasks_priority_palette("p2")
        assert bg == "#f2eafe"
        assert fg == "#7d2df3"

    def test_p3_is_warning(self):
        bg, fg = _tasks_priority_palette("p3")
        assert bg == "#fff3c4"  # _G8_WARNING_BG
        assert fg == "#b45309"

    def test_p4_is_muted(self):
        bg, fg = _tasks_priority_palette("p4")
        assert bg == "#f9f9f9"  # _G8_MUTED_BG
        assert fg == "#777777"  # _G8_TEXT_MUTED

    def test_alias_urgent_is_accent(self):
        bg, fg = _tasks_priority_palette("urgent")
        assert bg == "#f2eafe"
        assert fg == "#7d2df3"

    def test_unknown_is_muted(self):
        bg, fg = _tasks_priority_palette("bogus")
        assert bg == "#f9f9f9"
        assert fg == "#777777"

    def test_none_is_muted(self):
        bg, fg = _tasks_priority_palette(None)
        assert bg == "#f9f9f9"
        assert fg == "#777777"


# ----------------------------------------------------------------- #
# _tasks_priority_status_palette / _tasks_priority_status_display
# ----------------------------------------------------------------- #


class TestStatusPalette:
    def test_open_is_accent(self):
        bg, fg = _tasks_priority_status_palette("open")
        assert bg == "#f2eafe"
        assert fg == "#7d2df3"

    def test_in_progress_is_accent(self):
        bg, fg = _tasks_priority_status_palette("in_progress")
        assert bg == "#f2eafe"
        assert fg == "#7d2df3"

    def test_blocked_is_warning(self):
        bg, fg = _tasks_priority_status_palette("blocked")
        assert bg == "#fff3c4"
        assert fg == "#b45309"

    def test_completed_is_positive(self):
        bg, fg = _tasks_priority_status_palette("completed")
        assert bg == "#d1fae5"  # _G8_POSITIVE_BG
        assert fg == "#059669"  # _G8_POSITIVE_FG

    def test_done_alias_is_positive(self):
        bg, fg = _tasks_priority_status_palette("done")
        assert bg == "#d1fae5"
        assert fg == "#059669"

    def test_cancelled_is_muted(self):
        bg, fg = _tasks_priority_status_palette("cancelled")
        assert bg == "#f9f9f9"
        assert fg == "#777777"

    def test_unknown_is_muted(self):
        bg, fg = _tasks_priority_status_palette("bogus")
        assert bg == "#f9f9f9"
        assert fg == "#777777"

    def test_non_string_is_muted(self):
        bg, fg = _tasks_priority_status_palette(None)
        assert bg == "#f9f9f9"

    def test_status_display_open(self):
        assert _tasks_priority_status_display("open") == "Open"

    def test_status_display_in_progress(self):
        assert _tasks_priority_status_display("in_progress") == "In progress"
        assert _tasks_priority_status_display("IN_PROGRESS") == "In progress"
        assert _tasks_priority_status_display("in-progress") == "In progress"

    def test_status_display_done_alias(self):
        assert _tasks_priority_status_display("done") == "Completed"

    def test_status_display_unknown_preserves_raw(self):
        assert _tasks_priority_status_display("mystery") == "mystery"

    def test_status_display_non_string(self):
        assert _tasks_priority_status_display(None) == ""
        assert _tasks_priority_status_display(1) == ""


# ----------------------------------------------------------------- #
# _tasks_priority_clip
# ----------------------------------------------------------------- #


class TestClip:
    def test_short_string_unchanged(self):
        assert _tasks_priority_clip("hello", 10) == "hello"

    def test_long_string_clipped(self):
        result = _tasks_priority_clip("x" * 20, 10)
        assert len(result) == 10
        assert result.endswith("…")

    def test_none(self):
        assert _tasks_priority_clip(None, 10) == ""

    def test_empty_string(self):
        assert _tasks_priority_clip("", 10) == ""

    def test_whitespace_only(self):
        assert _tasks_priority_clip("   ", 10) == ""

    def test_non_string_coerced(self):
        assert _tasks_priority_clip(12345, 10) == "12345"

    def test_strips_surrounding_whitespace(self):
        assert _tasks_priority_clip("  hi  ", 10) == "hi"

    def test_does_not_escape(self):
        # Clip helpers return raw; escaping is at render site.
        assert _tasks_priority_clip("<script>", 20) == "<script>"


# ----------------------------------------------------------------- #
# _tasks_priority_header_html
# ----------------------------------------------------------------- #


class TestHeader:
    def test_renders_label(self):
        html_ = _tasks_priority_header_html("p1", 5)
        assert "P1 · Urgent" in html_

    def test_total_singular(self):
        html_ = _tasks_priority_header_html("p2", 1)
        assert "1 task at this priority" in html_

    def test_total_plural(self):
        html_ = _tasks_priority_header_html("p2", 7)
        assert "7 tasks at this priority" in html_

    def test_total_zero(self):
        html_ = _tasks_priority_header_html("p3", 0)
        assert "0 tasks at this priority" in html_

    def test_has_eyebrow(self):
        html_ = _tasks_priority_header_html("p4", 3)
        assert "Tasks · priority" in html_

    def test_unknown_label_fallback(self):
        html_ = _tasks_priority_header_html("bogus", 3)
        assert "Tasks" in html_  # fallback


# ----------------------------------------------------------------- #
# _tasks_priority_stats_row_html
# ----------------------------------------------------------------- #


class TestStatsRow:
    def test_four_cards(self):
        html_ = _tasks_priority_stats_row_html([])
        # Count the number of KPI card divs with flex:1
        assert html_.count("flex:1;") == 4

    def test_total_card(self):
        tasks = [{"status": "open"}, {"status": "completed"}]
        html_ = _tasks_priority_stats_row_html(tasks)
        assert "Total" in html_
        assert ">2<" in html_  # total value

    def test_overdue_count_excludes_completed(self):
        # Completed overdue doesn't count.
        tasks = [
            {"status": "open", "due_date": "2020-01-01"},
            {"status": "completed", "due_date": "2020-01-01"},
            {"status": "cancelled", "due_date": "2020-01-01"},
        ]
        html_ = _tasks_priority_stats_row_html(tasks)
        assert "Overdue" in html_

    def test_open_count(self):
        tasks = [
            {"status": "open"},
            {"status": "in_progress"},
            {"status": "blocked"},
            {"status": "completed"},
            {"status": "cancelled"},
        ]
        html_ = _tasks_priority_stats_row_html(tasks)
        assert "Open" in html_

    def test_assigned_card(self):
        tasks = [
            {"assignee_id": "u1"},
            {"assignee_id": "u2"},
            {},
        ]
        html_ = _tasks_priority_stats_row_html(tasks)
        assert "Assigned" in html_

    def test_non_dict_skipped(self):
        tasks = [{"status": "open"}, "junk", None, 42]
        html_ = _tasks_priority_stats_row_html(tasks)
        # Total should be 4 (all entries counted), but only dicts contribute
        # to overdue/open/assigned. The "Total" card counts len(tasks).
        assert "Total" in html_

    def test_no_high_priority_label_since_tautology(self):
        """Unlike #74, this pane does NOT have a 'High priority' card
        because the pane itself IS priority-scoped (tautology)."""
        tasks = [{"status": "open"}]
        html_ = _tasks_priority_stats_row_html(tasks)
        # The word "priority" should NOT appear as a card label here —
        # only "Total", "Overdue", "Open", "Assigned".
        # Check that "Open" appears as a card label (not "High priority")
        assert "Open" in html_
        assert "High priority" not in html_


# ----------------------------------------------------------------- #
# _tasks_priority_overflow_banner_html
# ----------------------------------------------------------------- #


class TestOverflowBanner:
    def test_zero_overflow_hidden(self):
        assert _tasks_priority_overflow_banner_html(0, "p1") == ""

    def test_negative_overflow_hidden(self):
        assert _tasks_priority_overflow_banner_html(-5, "p1") == ""

    def test_positive_overflow_shown(self):
        html_ = _tasks_priority_overflow_banner_html(25, "p1")
        assert "25 more tasks" in html_

    def test_one_overflow_singular(self):
        html_ = _tasks_priority_overflow_banner_html(1, "p2")
        assert "1 more task" in html_
        assert "1 more tasks" not in html_

    def test_backend_int_shown(self):
        html_ = _tasks_priority_overflow_banner_html(10, "p3")
        assert "priority=3" in html_

    def test_alias_mapped_to_int(self):
        html_ = _tasks_priority_overflow_banner_html(10, "urgent")
        assert "priority=1" in html_

    def test_invalid_priority_shows_no_int(self):
        # Invalid normalize → no backend int; overflow still rendered.
        html_ = _tasks_priority_overflow_banner_html(10, "bogus")
        assert "priority=" in html_  # empty value


# ----------------------------------------------------------------- #
# _tasks_priority_drill_up_html
# ----------------------------------------------------------------- #


class TestDrillUp:
    def test_links_to_dashboard(self):
        html_ = _tasks_priority_drill_up_html("p1")
        assert "g8://tasks/dashboard" in html_

    def test_lists_sibling_priorities(self):
        html_ = _tasks_priority_drill_up_html("p1")
        # Should show p2, p3, p4 but NOT p1 (no self-ref)
        assert "g8://tasks/priority/p2" in html_
        assert "g8://tasks/priority/p3" in html_
        assert "g8://tasks/priority/p4" in html_

    def test_no_self_reference(self):
        for prio in _TASKS_PRIORITY_VALID:
            html_ = _tasks_priority_drill_up_html(prio)
            # The self-link would look like: g8://tasks/priority/{prio}</code> — {prio_label}
            # Count occurrences of `g8://tasks/priority/{prio}`
            self_uri = f"g8://tasks/priority/{prio}"
            # Backend filter URL would not have the priority key in the URI form.
            # Count occurrences in <li> entries only.
            occurrences = html_.count(f"<code>g8://tasks/priority/{prio}</code>")
            assert occurrences == 0, f"self-ref leaked for {prio}: {occurrences}"

    def test_cross_axis_link_to_status_pane(self):
        html_ = _tasks_priority_drill_up_html("p1")
        assert "g8://tasks/status/open" in html_

    def test_backend_filter_url(self):
        html_ = _tasks_priority_drill_up_html("p2")
        assert "GET /tasks?priority=2" in html_

    def test_backend_filter_url_alias(self):
        html_ = _tasks_priority_drill_up_html("urgent")
        assert "GET /tasks?priority=1" in html_

    def test_invalid_priority_no_backend_filter(self):
        html_ = _tasks_priority_drill_up_html("bogus")
        # Backend filter block skipped when priority is invalid
        assert "GET /tasks?priority=" not in html_


# ----------------------------------------------------------------- #
# _tasks_priority_empty_state_html
# ----------------------------------------------------------------- #


class TestEmptyState:
    def test_zero_state_accent(self):
        html_ = _tasks_priority_empty_state_html("p1", zero_state=True)
        assert "No P1 · Urgent tasks" in html_
        # Accent tone — bg should be accent
        assert "#f2eafe" in html_
        # Should NOT reference backend errors
        assert "returned no data" not in html_

    def test_unavailable_state_muted(self):
        html_ = _tasks_priority_empty_state_html("p1", zero_state=False)
        assert "P1 · Urgent tasks unavailable" in html_
        # Muted tone
        assert "#f9f9f9" in html_
        assert "returned no data" in html_

    def test_unavailable_unknown_priority(self):
        html_ = _tasks_priority_empty_state_html("bogus", zero_state=False)
        # Raw label empty → fallback "Tasks unavailable"
        assert "Tasks unavailable" in html_
        # NOT redundant: should NOT produce "Tasks tasks unavailable"
        assert "Tasks tasks unavailable" not in html_

    def test_unavailable_empty_priority(self):
        html_ = _tasks_priority_empty_state_html("", zero_state=False)
        assert "Tasks unavailable" in html_
        assert "Tasks tasks unavailable" not in html_

    def test_unavailable_lists_valid_values(self):
        html_ = _tasks_priority_empty_state_html("p1", zero_state=False)
        # Error message should hint at valid values
        assert "p1" in html_
        assert "p4" in html_


# ----------------------------------------------------------------- #
# _tasks_priority_row_html — task card
# ----------------------------------------------------------------- #


class TestTaskRow:
    def _sample(self, **kw):
        base = {
            "id": "t1",
            "title": "Follow up with Acme",
            "description": "Chase down the CFO approval.",
            "due_date": "2026-05-01",
            "assignee_name": "Rep A",
            "status": "open",
            "priority": 1,
            "task_type": "call",
            "entity_type": "contact",
            "entity_id": "c42",
        }
        base.update(kw)
        return base

    def test_renders_title(self):
        html_ = _tasks_priority_row_html(self._sample(), "p1")
        assert "Follow up with Acme" in html_

    def test_renders_description(self):
        html_ = _tasks_priority_row_html(self._sample(), "p1")
        assert "Chase down the CFO approval." in html_

    def test_renders_status_chip(self):
        html_ = _tasks_priority_row_html(self._sample(), "p1")
        assert "Open" in html_

    def test_renders_priority_chip(self):
        html_ = _tasks_priority_row_html(self._sample(priority=2), "p2")
        assert "P2" in html_

    def test_priority_chip_uses_accent_palette_for_p1(self):
        html_ = _tasks_priority_row_html(self._sample(priority=1), "p1")
        # Accent bg should appear in the chip
        assert "#f2eafe" in html_
        assert "#7d2df3" in html_

    def test_priority_chip_skipped_for_none_priority(self):
        html_ = _tasks_priority_row_html(self._sample(priority=None), "p1")
        # Still renders row without crashing; no P{n} chip text
        assert ">P1<" not in html_ or "P1 · Urgent" in html_  # label in header is fine

    def test_priority_chip_skipped_for_zero(self):
        html_ = _tasks_priority_row_html(self._sample(priority=0), "p1")
        # priority 0 is no-priority sentinel; no chip
        # Label "P0" should NOT be in chip output
        assert ">P0<" not in html_

    def test_priority_chip_skipped_for_out_of_range(self):
        html_ = _tasks_priority_row_html(self._sample(priority=99), "p1")
        assert ">P99<" not in html_

    def test_priority_chip_skipped_for_bool(self):
        html_ = _tasks_priority_row_html(self._sample(priority=True), "p1")
        assert ">P1<" not in html_.split("<article")[1]  # no chip

    def test_due_chip_when_future(self):
        html_ = _tasks_priority_row_html(
            self._sample(due_date="2099-12-31"), "p1"
        )
        assert "Due 2099-12-31" in html_

    def test_overdue_chip_when_past_and_open(self):
        html_ = _tasks_priority_row_html(
            self._sample(due_date="2020-01-01", status="open"), "p1"
        )
        assert "Overdue · 2020-01-01" in html_

    def test_no_overdue_when_completed(self):
        html_ = _tasks_priority_row_html(
            self._sample(due_date="2020-01-01", status="completed"), "p1"
        )
        assert "Overdue" not in html_

    def test_assignee_in_meta(self):
        html_ = _tasks_priority_row_html(self._sample(), "p1")
        assert "@Rep A" in html_

    def test_entity_ref_in_meta(self):
        html_ = _tasks_priority_row_html(self._sample(), "p1")
        assert "contact #c42" in html_

    def test_xss_title_escaped(self):
        html_ = _tasks_priority_row_html(
            self._sample(title="<script>alert(1)</script>"), "p1"
        )
        assert "<script>alert(1)</script>" not in html_
        assert "&lt;script&gt;" in html_

    def test_xss_description_escaped(self):
        html_ = _tasks_priority_row_html(
            self._sample(description="<img onerror=alert(1)>"), "p1"
        )
        assert "<img onerror=alert(1)>" not in html_
        assert "&lt;img" in html_

    def test_missing_title_fallback(self):
        html_ = _tasks_priority_row_html(self._sample(title=None), "p1")
        assert "(untitled)" in html_


# ----------------------------------------------------------------- #
# render_tasks_priority_html — top-level
# ----------------------------------------------------------------- #


class TestRenderHtml:
    def test_invalid_priority_unavailable(self):
        html_ = render_tasks_priority_html(tasks=[], priority="bogus")
        assert "Tasks unavailable" in html_
        assert "Tasks tasks unavailable" not in html_

    def test_empty_priority_unavailable(self):
        html_ = render_tasks_priority_html(tasks=[], priority="")
        assert "Tasks unavailable" in html_

    def test_none_priority_unavailable(self):
        html_ = render_tasks_priority_html(tasks=[], priority=None)
        assert "Tasks unavailable" in html_

    def test_none_tasks_unavailable(self):
        html_ = render_tasks_priority_html(tasks=None, priority="p1")
        assert "P1 · Urgent tasks unavailable" in html_
        assert "returned no data" in html_

    def test_empty_tasks_zero_state(self):
        html_ = render_tasks_priority_html(tasks=[], priority="p1")
        assert "No P1 · Urgent tasks" in html_
        # Drill-up visible in zero-state
        assert "g8://tasks/dashboard" in html_

    def test_single_task(self):
        tasks = [{"id": "t1", "title": "Call CFO", "priority": 1, "status": "open"}]
        html_ = render_tasks_priority_html(tasks=tasks, priority="p1")
        assert "Call CFO" in html_
        assert "1 task at this priority" in html_

    def test_multiple_tasks_sorted_by_due(self):
        tasks = [
            {"id": "t1", "title": "Late", "priority": 2, "status": "open", "due_date": "2099-01-01"},
            {"id": "t2", "title": "Soon", "priority": 2, "status": "open", "due_date": "2025-01-01"},
        ]
        html_ = render_tasks_priority_html(tasks=tasks, priority="p2")
        # Soon should come before Late
        soon_idx = html_.find("Soon")
        late_idx = html_.find("Late")
        assert soon_idx != -1
        assert late_idx != -1
        assert soon_idx < late_idx

    def test_overflow_truncation(self):
        tasks = [
            {"id": f"t{i}", "title": f"Task {i}", "priority": 1, "status": "open"}
            for i in range(_MAX_TASKS_PRIORITY_RENDERED + 15)
        ]
        html_ = render_tasks_priority_html(tasks=tasks, priority="p1")
        assert "15 more tasks" in html_

    def test_non_list_tasks_treated_as_empty(self):
        html_ = render_tasks_priority_html(tasks="junk", priority="p1")
        assert "No P1 · Urgent tasks" in html_

    def test_non_dict_entries_filtered(self):
        tasks = [
            "junk",
            None,
            {"id": "t1", "title": "Real", "priority": 1, "status": "open"},
            42,
        ]
        html_ = render_tasks_priority_html(tasks=tasks, priority="p1")
        assert "Real" in html_
        assert "1 task at this priority" in html_

    def test_doctype_present(self):
        html_ = render_tasks_priority_html(tasks=[], priority="p1")
        assert html_.startswith("<!DOCTYPE html>")

    def test_page_bg_is_muted(self):
        html_ = render_tasks_priority_html(tasks=[], priority="p1")
        assert "background:#f9f9f9" in html_  # _G8_MUTED_BG

    def test_alias_normalized_in_output(self):
        tasks = [{"id": "t1", "title": "X", "priority": 1, "status": "open"}]
        html_ = render_tasks_priority_html(tasks=tasks, priority="urgent")
        assert "P1 · Urgent" in html_


# ----------------------------------------------------------------- #
# Design token lock-down (no legacy hexes)
# ----------------------------------------------------------------- #


class TestDesignTokens:
    """Surfaces from #37 onward MUST use graph8 design tokens only.

    These tests lock out the Studio pre-token hexes that would creep
    back in if someone copied from an old surface.
    """

    BANNED_HEXES = ("#1d4ed8", "#166534", "#991b1b", "#0891b2")

    def _sample_tasks(self):
        return [
            {"id": "t1", "title": "Real", "priority": 1, "status": "open", "due_date": "2025-06-01", "assignee_id": "u1"},
            {"id": "t2", "title": "Blocked", "priority": 1, "status": "blocked", "due_date": "2025-06-15"},
            {"id": "t3", "title": "Done", "priority": 1, "status": "completed"},
            {"id": "t4", "title": "Late", "priority": 1, "status": "open", "due_date": "2020-01-01"},
        ]

    def test_no_legacy_hexes_in_full_render(self):
        html_ = render_tasks_priority_html(
            tasks=self._sample_tasks(), priority="p1"
        )
        for hex_ in self.BANNED_HEXES:
            assert hex_ not in html_, f"legacy hex {hex_} leaked"

    def test_no_legacy_hexes_in_empty(self):
        html_ = render_tasks_priority_html(tasks=[], priority="p1")
        for hex_ in self.BANNED_HEXES:
            assert hex_ not in html_

    def test_no_legacy_hexes_in_unavailable(self):
        html_ = render_tasks_priority_html(tasks=None, priority="p1")
        for hex_ in self.BANNED_HEXES:
            assert hex_ not in html_

    def test_no_legacy_hexes_in_invalid(self):
        html_ = render_tasks_priority_html(tasks=[], priority="bogus")
        for hex_ in self.BANNED_HEXES:
            assert hex_ not in html_

    def test_primary_token_present(self):
        html_ = render_tasks_priority_html(
            tasks=self._sample_tasks(), priority="p1"
        )
        assert "#7d2df3" in html_  # _G8_PRIMARY

    def test_accent_bg_present(self):
        html_ = render_tasks_priority_html(
            tasks=self._sample_tasks(), priority="p1"
        )
        assert "#f2eafe" in html_  # _G8_ACCENT_BG

    def test_aeonik_font(self):
        html_ = render_tasks_priority_html(
            tasks=self._sample_tasks(), priority="p1"
        )
        assert "Aeonik" in html_


# ----------------------------------------------------------------- #
# No JS, no inline scripts
# ----------------------------------------------------------------- #


class TestNoJs:
    def test_no_script_tags(self):
        tasks = [{"id": "t1", "title": "Real", "priority": 1, "status": "open"}]
        html_ = render_tasks_priority_html(tasks=tasks, priority="p1")
        assert "<script" not in html_.lower()

    def test_no_event_handlers(self):
        tasks = [{"id": "t1", "title": "Real", "priority": 1, "status": "open"}]
        html_ = render_tasks_priority_html(tasks=tasks, priority="p1")
        assert "onclick=" not in html_.lower()
        assert "onerror=" not in html_.lower()
        assert "onload=" not in html_.lower()


# ----------------------------------------------------------------- #
# Text fallback
# ----------------------------------------------------------------- #


class TestTextFallback:
    def test_invalid_priority(self):
        text = render_tasks_priority_text_fallback(
            tasks=[], priority="bogus"
        )
        assert "# Tasks unavailable" in text
        assert "Invalid priority" in text
        assert "p1" in text
        assert "p4" in text

    def test_none_tasks(self):
        text = render_tasks_priority_text_fallback(
            tasks=None, priority="p1"
        )
        assert "# P1 · Urgent tasks unavailable" in text
        assert "Backend returned no data" in text

    def test_empty_tasks_zero_state(self):
        text = render_tasks_priority_text_fallback(
            tasks=[], priority="p1"
        )
        assert "# No P1 · Urgent tasks" in text
        assert "## Related surfaces" in text
        # Drill-up to status pane
        assert "g8://tasks/status/open" in text

    def test_populated(self):
        tasks = [
            {
                "id": "t1",
                "title": "Call CFO",
                "priority": 1,
                "status": "open",
                "due_date": "2099-01-01",
                "assignee_name": "Rep",
            }
        ]
        text = render_tasks_priority_text_fallback(tasks=tasks, priority="p1")
        assert "# Tasks — P1 · Urgent" in text
        assert "Call CFO" in text
        assert "P1" in text
        assert "Open" in text
        assert "due 2099-01-01" in text
        assert "@Rep" in text

    def test_overflow_note(self):
        tasks = [
            {"id": f"t{i}", "title": f"T{i}", "priority": 1, "status": "open"}
            for i in range(_MAX_TASKS_PRIORITY_RENDERED + 3)
        ]
        text = render_tasks_priority_text_fallback(tasks=tasks, priority="p1")
        assert "+ 3 more task(s)" in text

    def test_no_self_reference(self):
        text = render_tasks_priority_text_fallback(tasks=[], priority="p2")
        # Related surfaces should NOT include p2 self-ref
        assert "g8://tasks/priority/p2" not in text

    def test_backend_filter_url(self):
        tasks = [{"id": "t1", "title": "X", "priority": 3, "status": "open"}]
        text = render_tasks_priority_text_fallback(tasks=tasks, priority="p3")
        assert "GET /tasks?priority=3" in text


# ----------------------------------------------------------------- #
# Smoke
# ----------------------------------------------------------------- #


class TestSmoke:
    def test_all_four_priorities_render(self):
        for prio in _TASKS_PRIORITY_VALID:
            html_ = render_tasks_priority_html(tasks=[], priority=prio)
            assert html_.startswith("<!DOCTYPE html>")
            assert _TASKS_PRIORITY_LABELS[prio] in html_

    def test_all_aliases_render(self):
        for alias in ["urgent", "high", "medium", "low", "1", "2", "3", "4"]:
            html_ = render_tasks_priority_html(tasks=[], priority=alias)
            assert html_.startswith("<!DOCTYPE html>")

    def test_populated_render(self):
        tasks = [
            {"id": f"t{i}", "title": f"Task {i}", "priority": 1, "status": "open"}
            for i in range(5)
        ]
        html_ = render_tasks_priority_html(tasks=tasks, priority="p1")
        assert html_.startswith("<!DOCTYPE html>")
        assert "Task 0" in html_
        assert "Task 4" in html_


# ----------------------------------------------------------------- #
# Constants
# ----------------------------------------------------------------- #


class TestConstants:
    def test_valid_count(self):
        assert len(_TASKS_PRIORITY_VALID) == 4

    def test_valid_all_canonical(self):
        assert set(_TASKS_PRIORITY_VALID) == {"p1", "p2", "p3", "p4"}

    def test_labels_all_present(self):
        for key in _TASKS_PRIORITY_VALID:
            assert key in _TASKS_PRIORITY_LABELS

    def test_to_int_all_present(self):
        for key in _TASKS_PRIORITY_VALID:
            assert key in _TASKS_PRIORITY_TO_INT

    def test_to_int_values(self):
        assert _TASKS_PRIORITY_TO_INT["p1"] == 1
        assert _TASKS_PRIORITY_TO_INT["p2"] == 2
        assert _TASKS_PRIORITY_TO_INT["p3"] == 3
        assert _TASKS_PRIORITY_TO_INT["p4"] == 4

    def test_max_rendered_reasonable(self):
        assert _MAX_TASKS_PRIORITY_RENDERED >= 50
        assert _MAX_TASKS_PRIORITY_RENDERED <= 500
