"""Tests for g8_get_activity_summary — the client-side rollup over /activities.

The tool pulls up to 200 most recent activities from the existing /api/v1/activities
list endpoint, filters by a day window client-side, and aggregates into a summary.
Zero new backend routes required — this test suite pins:
  * the tool is registered on the server
  * the tool returns a well-shaped rollup when the client returns a plausible envelope
  * the day-window filter excludes activities older than the window
  * the 'truncated' flag is set when the upstream response hit the 200-row cap
  * empty responses don't blow up — they return a zeroed summary
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock

import pytest

import g8_mcp_server.client as client_module
from g8_mcp_server.server import create_server


@pytest.fixture
def mcp_server(monkeypatch):
    monkeypatch.setenv("G8_API_KEY", "test_key")
    monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
    monkeypatch.setattr(client_module, "CREDENTIALS_PATH", Path("/tmp/nonexistent"))
    return create_server()


def _tool(server, name: str):
    return server._tool_manager._tools[name]


def _iso(dt: datetime) -> str:
    # Match the Postgres-style rendering the /activities endpoint emits:
    # "YYYY-MM-DD HH:MM:SS+00:00"
    return dt.strftime("%Y-%m-%d %H:%M:%S") + "+00:00"


class TestRegistration:
    def test_tool_registered(self, mcp_server):
        tool = _tool(mcp_server, "g8_get_activity_summary")
        assert tool is not None
        # Read-only behavioral hint — this tool never mutates org data
        ann = tool.annotations
        if ann is not None:
            assert ann.readOnlyHint is True


class TestShape:
    @pytest.mark.asyncio
    async def test_returns_rollup_for_mixed_activities(self, mcp_server, monkeypatch):
        now = datetime.now(timezone.utc)
        envelope: dict[str, Any] = {
            "data": [
                {
                    "id": "1",
                    "activity_type": "call",
                    "outcome": "connected",
                    "owner_id": "u1",
                    "owner_name": "Alice",
                    "duration_minutes": 15,
                    "activity_date": _iso(now - timedelta(days=1)),
                },
                {
                    "id": "2",
                    "activity_type": "call",
                    "outcome": "voicemail",
                    "owner_id": "u1",
                    "owner_name": "Alice",
                    "duration_minutes": 2,
                    "activity_date": _iso(now - timedelta(days=2)),
                },
                {
                    "id": "3",
                    "activity_type": "email",
                    "outcome": None,
                    "owner_id": "u2",
                    "owner_name": "Bob",
                    "duration_minutes": None,
                    "activity_date": _iso(now - timedelta(hours=3)),
                },
            ]
        }
        mock_get = AsyncMock(return_value=envelope)
        monkeypatch.setattr(
            "g8_mcp_server.client.G8Client.get", mock_get, raising=True
        )
        tool = _tool(mcp_server, "g8_get_activity_summary")

        result = await tool.fn(days=7)

        assert result["total_activities"] == 3
        assert result["by_type"] == {"call": 2, "email": 1}
        assert result["by_outcome"] == {"connected": 1, "voicemail": 1, "unknown": 1}
        assert result["total_duration_minutes"] == 17
        assert result["truncated"] is False
        # top_owners ranked by count
        names = [o["name"] for o in result["top_owners"]]
        assert names[0] == "Alice"
        assert names[1] == "Bob"
        # activities_by_day has one entry per day in the window
        assert len(result["activities_by_day"]) == 7
        assert sum(d["count"] for d in result["activities_by_day"]) == 3

    @pytest.mark.asyncio
    async def test_excludes_activities_outside_window(self, mcp_server, monkeypatch):
        now = datetime.now(timezone.utc)
        envelope = {
            "data": [
                # Inside 7-day window
                {
                    "id": "1",
                    "activity_type": "call",
                    "activity_date": _iso(now - timedelta(days=3)),
                },
                # Outside — 40 days old
                {
                    "id": "2",
                    "activity_type": "call",
                    "activity_date": _iso(now - timedelta(days=40)),
                },
            ]
        }
        mock_get = AsyncMock(return_value=envelope)
        monkeypatch.setattr(
            "g8_mcp_server.client.G8Client.get", mock_get, raising=True
        )
        tool = _tool(mcp_server, "g8_get_activity_summary")

        result = await tool.fn(days=7)

        assert result["total_activities"] == 1
        assert result["by_type"] == {"call": 1}

    @pytest.mark.asyncio
    async def test_truncated_flag_when_200_returned(self, mcp_server, monkeypatch):
        now = datetime.now(timezone.utc)
        envelope = {
            "data": [
                {
                    "id": str(i),
                    "activity_type": "email",
                    "activity_date": _iso(now - timedelta(hours=i)),
                }
                for i in range(200)
            ]
        }
        mock_get = AsyncMock(return_value=envelope)
        monkeypatch.setattr(
            "g8_mcp_server.client.G8Client.get", mock_get, raising=True
        )
        tool = _tool(mcp_server, "g8_get_activity_summary")

        result = await tool.fn(days=30)

        assert result["truncated"] is True
        assert "note" in result

    @pytest.mark.asyncio
    async def test_empty_response_returns_zeros(self, mcp_server, monkeypatch):
        mock_get = AsyncMock(return_value={"data": []})
        monkeypatch.setattr(
            "g8_mcp_server.client.G8Client.get", mock_get, raising=True
        )
        tool = _tool(mcp_server, "g8_get_activity_summary")

        result = await tool.fn(days=7)

        assert result["total_activities"] == 0
        assert result["by_type"] == {}
        assert result["by_outcome"] == {}
        assert result["total_duration_minutes"] == 0
        assert result["truncated"] is False
        # Still has 7 day buckets, all zero
        assert len(result["activities_by_day"]) == 7
        assert all(d["count"] == 0 for d in result["activities_by_day"])

    @pytest.mark.asyncio
    async def test_malformed_rows_do_not_crash(self, mcp_server, monkeypatch):
        now = datetime.now(timezone.utc)
        envelope = {
            "data": [
                "not a dict",  # should be skipped
                {"activity_type": "call", "activity_date": None},  # no date → skip
                {
                    "activity_type": "meeting",
                    "activity_date": _iso(now),
                },  # kept
            ]
        }
        mock_get = AsyncMock(return_value=envelope)
        monkeypatch.setattr(
            "g8_mcp_server.client.G8Client.get", mock_get, raising=True
        )
        tool = _tool(mcp_server, "g8_get_activity_summary")

        result = await tool.fn(days=7)

        assert result["total_activities"] == 1
        assert result["by_type"] == {"meeting": 1}

    @pytest.mark.asyncio
    async def test_filters_forwarded_to_backend(self, mcp_server, monkeypatch):
        mock_get = AsyncMock(return_value={"data": []})
        monkeypatch.setattr(
            "g8_mcp_server.client.G8Client.get", mock_get, raising=True
        )
        tool = _tool(mcp_server, "g8_get_activity_summary")

        await tool.fn(
            days=14,
            activity_type="call",
            contact_id="c123",
            company_id="co456",
            deal_id="d789",
        )

        # The tool should pass filters through to /activities exactly once
        assert mock_get.await_count == 1
        path, params = mock_get.await_args.args
        assert path == "/activities"
        assert params["limit"] == 200
        assert params["activity_type"] == "call"
        assert params["contact_id"] == "c123"
        assert params["company_id"] == "co456"
        assert params["deal_id"] == "d789"
