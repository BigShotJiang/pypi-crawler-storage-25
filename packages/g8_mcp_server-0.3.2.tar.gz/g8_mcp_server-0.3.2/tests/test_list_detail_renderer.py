"""Unit tests for Surface #64 — `render_list_detail_html` / text fallback.

Per-list detail: `g8://lists/{list_id}` (+ `.txt` sibling).
Mirrors the structure of test_persona_detail_renderer.py (Surface #63)
and test_icp_detail_renderer.py (Surface #62).

graph8-native design: only `_G8_*` tokens — no Studio legacy hexes
(`#eef2ff`, `#4338ca`, `#f59e0b`, etc.). Every regression lock test
enforces this.
"""

from __future__ import annotations

import pytest

from mcp_server.g8_mcp_server import app_renderer as ar


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


_LIST_ID = "42"


_SAMPLE_LIST: dict = {
    "id": 42,
    "title": "Enterprise CFOs — Q2 2026",
    "type": "contacts",
    "source": "manual",
    "status": "active",
    "total": 1234,
    "is_dynamic": True,
    "tags": ["enterprise", "cfo", "q2-2026", "warm", "outbound"],
    "created_at": "2026-01-15T10:30:00Z",
    "created_by": "thomas@graph8.com",
    "updated_at": "2026-04-18T14:22:00Z",
}


# Legacy Studio hexes from the lists dashboard that this surface
# deliberately migrates away from.
_LEGACY_STUDIO_HEXES = (
    "#eef2ff",  # old chip bg
    "#4338ca",  # old chip fg
    "#f59e0b",  # old warning bg
    "#166534",  # old positive bg
    "#a16207",  # old priority:medium bg
    "#7c2d12",  # old priority:low bg
    "#6b7280",  # gray fallback
)


# ---------------------------------------------------------------------------
# _list_detail_clip
# ---------------------------------------------------------------------------


class TestClip:
    def test_none(self):
        assert ar._list_detail_clip(None, 100) == ""

    def test_non_string(self):
        assert ar._list_detail_clip(42, 100) == ""
        assert ar._list_detail_clip(["x"], 100) == ""
        assert ar._list_detail_clip({"x": 1}, 100) == ""

    def test_whitespace(self):
        assert ar._list_detail_clip("   ", 100) == ""
        assert ar._list_detail_clip("\n\t", 100) == ""

    def test_under_cap(self):
        assert ar._list_detail_clip("hello", 100) == "hello"

    def test_at_cap(self):
        assert ar._list_detail_clip("hello", 5) == "hello"

    def test_over_cap(self):
        result = ar._list_detail_clip("hello world", 5)
        assert result.endswith("…")
        assert len(result) == 5

    def test_escape(self):
        assert ar._list_detail_clip("<script>", 100) == "&lt;script&gt;"

    def test_escape_ampersand(self):
        assert ar._list_detail_clip("A & B", 100) == "A &amp; B"

    def test_empty_string(self):
        assert ar._list_detail_clip("", 100) == ""


# ---------------------------------------------------------------------------
# _list_detail_title
# ---------------------------------------------------------------------------


class TestTitle:
    def test_none_list(self):
        assert ar._list_detail_title(None, "42") == "List #42"

    def test_empty_list(self):
        assert ar._list_detail_title({}, "42") == "List #42"

    def test_no_title(self):
        assert ar._list_detail_title({"id": 42}, "42") == "List #42"

    def test_has_title(self):
        out = ar._list_detail_title({"title": "VIP Prospects"}, "42")
        assert out == "VIP Prospects"

    def test_title_whitespace(self):
        assert ar._list_detail_title({"title": "   "}, "42") == "List #42"

    def test_title_non_string(self):
        assert ar._list_detail_title({"title": 42}, "42") == "List #42"

    def test_title_escape(self):
        out = ar._list_detail_title({"title": "<script>"}, "42")
        assert out == "&lt;script&gt;"

    def test_title_clip(self):
        long = "x" * 200
        out = ar._list_detail_title({"title": long}, "42")
        assert out.endswith("…")
        assert len(out) <= ar._MAX_LIST_DETAIL_TITLE_LEN

    def test_list_id_escape(self):
        out = ar._list_detail_title(None, "<evil>")
        assert "&lt;evil&gt;" in out


# ---------------------------------------------------------------------------
# _list_detail_id_matches
# ---------------------------------------------------------------------------


class TestIdMatches:
    def test_int_id_matches_str(self):
        assert ar._list_detail_id_matches({"id": 42}, "42") is True

    def test_str_id_matches_str(self):
        assert ar._list_detail_id_matches({"id": "42"}, "42") is True

    def test_mismatch(self):
        assert ar._list_detail_id_matches({"id": 42}, "43") is False

    def test_none_list(self):
        # Lenient: can't enforce when no list
        assert ar._list_detail_id_matches(None, "42") is True

    def test_missing_id(self):
        # Lenient: can't enforce when list has no id
        assert ar._list_detail_id_matches({}, "42") is True

    def test_whitespace_in_url(self):
        # URI whitespace trimmed before compare
        assert ar._list_detail_id_matches({"id": 42}, "  42  ") is True

    def test_uuid_shape(self):
        u = "550e8400-e29b-41d4-a716-446655440000"
        assert ar._list_detail_id_matches({"id": u}, u) is True

    def test_zero_id(self):
        assert ar._list_detail_id_matches({"id": 0}, "0") is True


# ---------------------------------------------------------------------------
# _list_detail_parse_total
# ---------------------------------------------------------------------------


class TestParseTotal:
    def test_none(self):
        assert ar._list_detail_parse_total(None) is None

    def test_int(self):
        assert ar._list_detail_parse_total(42) == 42

    def test_str_int(self):
        assert ar._list_detail_parse_total("1234") == 1234

    def test_float(self):
        assert ar._list_detail_parse_total(42.0) == 42

    def test_negative(self):
        # negative rejected
        assert ar._list_detail_parse_total(-1) is None

    def test_bool_rejected(self):
        # bools are ints in Python — but not "count" semantically
        assert ar._list_detail_parse_total(True) is None
        assert ar._list_detail_parse_total(False) is None

    def test_nan_rejected(self):
        assert ar._list_detail_parse_total(float("nan")) is None

    def test_inf_rejected(self):
        assert ar._list_detail_parse_total(float("inf")) is None
        assert ar._list_detail_parse_total(float("-inf")) is None

    def test_garbage_str(self):
        assert ar._list_detail_parse_total("not a number") is None

    def test_zero(self):
        assert ar._list_detail_parse_total(0) == 0


# ---------------------------------------------------------------------------
# _list_detail_format_total
# ---------------------------------------------------------------------------


class TestFormatTotal:
    def test_none(self):
        assert ar._list_detail_format_total(None) == "—"

    def test_zero(self):
        assert ar._list_detail_format_total(0) == "0"

    def test_small(self):
        assert ar._list_detail_format_total(42) == "42"

    def test_thousands(self):
        assert ar._list_detail_format_total(1234) == "1,234"

    def test_millions(self):
        assert ar._list_detail_format_total(1234567) == "1,234,567"


# ---------------------------------------------------------------------------
# _list_detail_type_accent
# ---------------------------------------------------------------------------


class TestTypeAccent:
    def test_contacts(self):
        bg, fg, border = ar._list_detail_type_accent("contacts")
        assert bg == ar._G8_ACCENT_BG
        assert fg == ar._G8_PRIMARY

    def test_leads(self):
        bg, fg, border = ar._list_detail_type_accent("leads")
        assert fg == ar._G8_PRIMARY

    def test_people(self):
        bg, fg, border = ar._list_detail_type_accent("people")
        assert fg == ar._G8_PRIMARY

    def test_companies(self):
        bg, fg, border = ar._list_detail_type_accent("companies")
        assert fg == ar._G8_POSITIVE_FG

    def test_accounts(self):
        bg, fg, border = ar._list_detail_type_accent("accounts")
        assert fg == ar._G8_POSITIVE_FG

    def test_suppressions(self):
        bg, fg, border = ar._list_detail_type_accent("suppressions")
        assert fg == ar._G8_WARNING_FG

    def test_exclusions(self):
        bg, fg, border = ar._list_detail_type_accent("exclusions")
        assert fg == ar._G8_WARNING_FG

    def test_unknown(self):
        bg, fg, border = ar._list_detail_type_accent("quantum")
        assert fg == ar._G8_TEXT_MUTED

    def test_none(self):
        bg, fg, border = ar._list_detail_type_accent(None)
        assert fg == ar._G8_TEXT_MUTED

    def test_case_insensitive(self):
        bg, fg, border = ar._list_detail_type_accent("CONTACTS")
        assert fg == ar._G8_PRIMARY


# ---------------------------------------------------------------------------
# _list_detail_status_accent
# ---------------------------------------------------------------------------


class TestStatusAccent:
    def test_active(self):
        bg, fg, border = ar._list_detail_status_accent("active")
        assert fg == ar._G8_POSITIVE_FG

    def test_ready(self):
        bg, fg, border = ar._list_detail_status_accent("ready")
        assert fg == ar._G8_POSITIVE_FG

    def test_complete(self):
        bg, fg, border = ar._list_detail_status_accent("complete")
        assert fg == ar._G8_POSITIVE_FG

    def test_processing(self):
        bg, fg, border = ar._list_detail_status_accent("processing")
        assert fg == ar._G8_PRIMARY

    def test_running(self):
        bg, fg, border = ar._list_detail_status_accent("running")
        assert fg == ar._G8_PRIMARY

    def test_syncing(self):
        bg, fg, border = ar._list_detail_status_accent("syncing")
        assert fg == ar._G8_PRIMARY

    def test_pending(self):
        bg, fg, border = ar._list_detail_status_accent("pending")
        assert fg == ar._G8_PRIMARY

    def test_error(self):
        bg, fg, border = ar._list_detail_status_accent("error")
        assert fg == ar._G8_WARNING_FG

    def test_failed(self):
        bg, fg, border = ar._list_detail_status_accent("failed")
        assert fg == ar._G8_WARNING_FG

    def test_stale(self):
        bg, fg, border = ar._list_detail_status_accent("stale")
        assert fg == ar._G8_TEXT_MUTED

    def test_archived(self):
        bg, fg, border = ar._list_detail_status_accent("archived")
        assert fg == ar._G8_TEXT_MUTED

    def test_paused(self):
        bg, fg, border = ar._list_detail_status_accent("paused")
        assert fg == ar._G8_TEXT_MUTED

    def test_unknown(self):
        bg, fg, border = ar._list_detail_status_accent("zebra")
        assert fg == ar._G8_TEXT_MUTED

    def test_none(self):
        bg, fg, border = ar._list_detail_status_accent(None)
        assert fg == ar._G8_TEXT_MUTED

    def test_case_insensitive(self):
        bg, fg, border = ar._list_detail_status_accent("ACTIVE")
        assert fg == ar._G8_POSITIVE_FG


# ---------------------------------------------------------------------------
# _list_detail_extract_tags
# ---------------------------------------------------------------------------


class TestExtractTags:
    def test_none(self):
        assert ar._list_detail_extract_tags(None) == []

    def test_missing(self):
        assert ar._list_detail_extract_tags({}) == []

    def test_empty_list(self):
        assert ar._list_detail_extract_tags({"tags": []}) == []

    def test_simple(self):
        out = ar._list_detail_extract_tags({"tags": ["a", "b", "c"]})
        assert out == ["a", "b", "c"]

    def test_dedup(self):
        out = ar._list_detail_extract_tags({"tags": ["a", "b", "a", "c", "b"]})
        # de-duplication case-insensitive
        assert len(out) == 3

    def test_whitespace_only_dropped(self):
        out = ar._list_detail_extract_tags({"tags": ["a", "  ", "", "b"]})
        assert out == ["a", "b"]

    def test_non_string_dropped(self):
        out = ar._list_detail_extract_tags({"tags": ["a", 42, None, "b"]})
        assert out == ["a", "b"]

    def test_tag_clip(self):
        long = "x" * 200
        out = ar._list_detail_extract_tags({"tags": [long]})
        assert out[0].endswith("…")
        assert len(out[0]) <= ar._MAX_LIST_DETAIL_TAG_LEN

    def test_tag_escape_happens_at_render(self):
        # extract_tags does NOT escape — escaping happens in chip rendering.
        # This test just confirms the raw tag is preserved.
        out = ar._list_detail_extract_tags({"tags": ["<script>"]})
        assert "<script>" in out[0]

    def test_max_limit(self):
        many = [f"tag{i}" for i in range(100)]
        out = ar._list_detail_extract_tags({"tags": many})
        assert len(out) <= ar._MAX_LIST_DETAIL_TAGS

    def test_non_list(self):
        assert ar._list_detail_extract_tags({"tags": "not-a-list"}) == []


# ---------------------------------------------------------------------------
# _list_detail_format_datetime
# ---------------------------------------------------------------------------


class TestFormatDatetime:
    def test_none(self):
        # format returns "" for None; rendering layer substitutes dash
        assert ar._list_detail_format_datetime(None) == ""

    def test_empty(self):
        assert ar._list_detail_format_datetime("") == ""

    def test_iso_utc(self):
        out = ar._list_detail_format_datetime("2026-04-18T14:22:00Z")
        # Should contain some recognizable date
        assert "2026" in out or "04" in out or "Apr" in out

    def test_iso_offset(self):
        out = ar._list_detail_format_datetime("2026-04-18T14:22:00+00:00")
        assert "2026" in out or "Apr" in out

    def test_garbage(self):
        out = ar._list_detail_format_datetime("not a date")
        # Either returns the garbage or a dash — must not crash
        assert isinstance(out, str)

    def test_non_string(self):
        # Should not crash on non-string input
        out = ar._list_detail_format_datetime(42)
        assert isinstance(out, str)


# ---------------------------------------------------------------------------
# _list_detail_chip
# ---------------------------------------------------------------------------


class TestChip:
    def test_basic(self):
        out = ar._list_detail_chip("Active", bg="#fff", fg="#000", border="#eee")
        assert "Active" in out
        assert "#fff" in out

    def test_escape(self):
        out = ar._list_detail_chip("<script>", bg="#fff", fg="#000", border="#eee")
        assert "<script>" not in out
        assert "&lt;script&gt;" in out


# ---------------------------------------------------------------------------
# _list_detail_meta_row
# ---------------------------------------------------------------------------


class TestMetaRow:
    def test_basic(self):
        out = ar._list_detail_meta_row("Source", "manual")
        assert "Source" in out
        assert "manual" in out


# ---------------------------------------------------------------------------
# _list_detail_metadata_section
# ---------------------------------------------------------------------------


class TestMetadataSection:
    def test_empty(self):
        out = ar._list_detail_metadata_section([])
        # Empty input yields empty string OR a container — must not crash
        assert isinstance(out, str)

    def test_rows(self):
        out = ar._list_detail_metadata_section([
            ("Source", "manual"),
            ("Created", "2026-01-15"),
        ])
        assert "Source" in out
        assert "manual" in out
        assert "Created" in out


# ---------------------------------------------------------------------------
# _list_detail_tags_section
# ---------------------------------------------------------------------------


class TestTagsSection:
    def test_empty(self):
        out = ar._list_detail_tags_section([])
        # Empty input should collapse to empty string
        assert out == "" or isinstance(out, str)

    def test_with_tags(self):
        out = ar._list_detail_tags_section(["a", "b", "c"])
        assert "a" in out
        assert "b" in out
        assert "c" in out


# ---------------------------------------------------------------------------
# _list_detail_empty_state_html
# ---------------------------------------------------------------------------


class TestEmptyStateHtml:
    def test_unavailable(self):
        out = ar._list_detail_empty_state_html(mode="unavailable", list_id="42")
        assert "unavailable" in out.lower() or "not available" in out.lower()

    def test_not_found(self):
        out = ar._list_detail_empty_state_html(mode="not_found", list_id="42")
        assert "not found" in out.lower() or "no list" in out.lower()

    def test_escapes_list_id(self):
        out = ar._list_detail_empty_state_html(mode="unavailable", list_id="<evil>")
        assert "<evil>" not in out
        assert "&lt;evil&gt;" in out

    def test_uses_graph8_tokens(self):
        out = ar._list_detail_empty_state_html(mode="unavailable", list_id="42")
        assert ar._G8_FONT.split(",")[0] in out  # Aeonik

    def test_no_legacy_hexes(self):
        out = ar._list_detail_empty_state_html(mode="unavailable", list_id="42")
        for hex_color in _LEGACY_STUDIO_HEXES:
            assert hex_color.lower() not in out.lower(), (
                f"leaked legacy hex {hex_color}"
            )


# ---------------------------------------------------------------------------
# render_list_detail_html
# ---------------------------------------------------------------------------


class TestRenderHtml:
    def test_basic_render(self):
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=_SAMPLE_LIST)
        assert "<!DOCTYPE html>" in out
        assert "Enterprise CFOs" in out

    def test_none_yields_empty_state(self):
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=None)
        assert "unavailable" in out.lower() or "not available" in out.lower()

    def test_mismatched_id_yields_not_found(self):
        out = ar.render_list_detail_html(
            list_id="99", list_obj={**_SAMPLE_LIST, "id": 1}
        )
        assert "not found" in out.lower() or "no list" in out.lower()

    def test_int_id_matches_str_uri(self):
        # list has id=42 (int), URI has "42" (str) — should match
        out = ar.render_list_detail_html(list_id="42", list_obj=_SAMPLE_LIST)
        assert "Enterprise CFOs" in out

    def test_title_rendered(self):
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=_SAMPLE_LIST)
        assert "Enterprise CFOs" in out

    def test_total_rendered_with_commas(self):
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=_SAMPLE_LIST)
        assert "1,234" in out

    def test_type_chip(self):
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=_SAMPLE_LIST)
        assert "contacts" in out.lower()

    def test_status_chip(self):
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=_SAMPLE_LIST)
        assert "active" in out.lower()

    def test_dynamic_badge_when_true(self):
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=_SAMPLE_LIST)
        assert "dynamic" in out.lower()

    def test_no_dynamic_badge_when_false(self):
        lst = {**_SAMPLE_LIST, "is_dynamic": False}
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=lst)
        # Static badge or no dynamic pill
        assert "dynamic" not in out.lower() or "static" in out.lower()

    def test_source_in_metadata(self):
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=_SAMPLE_LIST)
        assert "manual" in out

    def test_created_by_in_metadata(self):
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=_SAMPLE_LIST)
        assert "thomas@graph8.com" in out

    def test_tags_rendered(self):
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=_SAMPLE_LIST)
        assert "enterprise" in out
        assert "cfo" in out
        assert "q2-2026" in out

    def test_drill_up_contacts(self):
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=_SAMPLE_LIST)
        assert "g8://lists/42/contacts" in out

    def test_drill_up_dashboard(self):
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=_SAMPLE_LIST)
        assert "g8://lists/dashboard" in out

    def test_drill_up_does_NOT_list_self(self):
        """Drill-up must not include a link back to this same list."""
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=_SAMPLE_LIST)
        # should NOT contain a bare `g8://lists/42` as a drill-up pointer
        # (the URI may appear in metadata rows, but not as a related-surface
        # bullet — we check the most-visible form: end of a `<code>` tag)
        assert "<code>g8://lists/42</code>" not in out

    def test_no_javascript(self):
        """No JS in rendered HTML."""
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=_SAMPLE_LIST)
        assert "javascript:" not in out.lower()
        assert "<script" not in out.lower()

    def test_no_legacy_accent_hexes(self):
        """No legacy Studio hexes leak through."""
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=_SAMPLE_LIST)
        for hex_color in _LEGACY_STUDIO_HEXES:
            assert hex_color.lower() not in out.lower(), (
                f"leaked legacy hex {hex_color}"
            )

    def test_uses_graph8_primary(self):
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=_SAMPLE_LIST)
        assert ar._G8_PRIMARY.lower() in out.lower()

    def test_uses_graph8_font(self):
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=_SAMPLE_LIST)
        assert ar._G8_FONT.split(",")[0] in out  # Aeonik

    def test_no_single_side_colored_accent_border(self):
        """Regression: no single-side colored *accent* borders (border-top:4px
        solid #7d2df3, etc.).

        Subtle single-side neutral dividers (e.g. border-bottom with
        _G8_MUTED_BG or _G8_BORDER) are fine — they're table/meta
        dividers, not brand accents. We flag only borders that use an
        accent color (primary, positive-fg, warning-fg).
        """
        import re
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=_SAMPLE_LIST)
        accent_hexes = [
            ar._G8_PRIMARY.lower(),
            ar._G8_POSITIVE_FG.lower(),
            ar._G8_WARNING_FG.lower(),
        ]
        for hex_color in accent_hexes:
            pattern = re.compile(
                rf"border-(top|right|bottom|left):\s*\d+px\s+solid\s+{re.escape(hex_color)}",
                re.IGNORECASE,
            )
            matches = pattern.findall(out)
            assert not matches, (
                f"single-side colored accent border ({hex_color}) found: {matches}"
            )

    def test_xss_title(self):
        lst = {**_SAMPLE_LIST, "title": "<script>alert(1)</script>"}
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=lst)
        assert "<script>alert(1)</script>" not in out
        assert "&lt;script&gt;" in out

    def test_xss_source(self):
        lst = {**_SAMPLE_LIST, "source": "<img src=x onerror=alert(1)>"}
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=lst)
        assert "<img src=x" not in out

    def test_xss_created_by(self):
        lst = {**_SAMPLE_LIST, "created_by": "<script>alert(1)</script>"}
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=lst)
        assert "<script>alert(1)</script>" not in out

    def test_xss_tag(self):
        lst = {**_SAMPLE_LIST, "tags": ["<script>"]}
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=lst)
        assert "<script>" not in out
        assert "&lt;script&gt;" in out

    def test_xss_list_id(self):
        out = ar.render_list_detail_html(list_id="<evil>", list_obj=None)
        assert "<evil>" not in out
        assert "&lt;evil&gt;" in out

    def test_missing_total(self):
        lst = {**_SAMPLE_LIST}
        del lst["total"]
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=lst)
        # Should render dash or 0 — must not crash
        assert "—" in out or "0" in out

    def test_zero_total(self):
        lst = {**_SAMPLE_LIST, "total": 0}
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=lst)
        assert "0" in out

    def test_minimal_list(self):
        # Only id and title — everything else missing
        lst = {"id": 42, "title": "Minimal"}
        out = ar.render_list_detail_html(list_id="42", list_obj=lst)
        assert "Minimal" in out
        # Should not crash

    def test_html_well_formed(self):
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=_SAMPLE_LIST)
        assert out.startswith("<!DOCTYPE html>")
        assert out.strip().endswith("</html>")

    def test_max_width_container(self):
        """Container has explicit max-width for readable layout."""
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=_SAMPLE_LIST)
        assert "max-width" in out

    def test_kpi_quadrant(self):
        """Four KPI cards: Total Members / Type / Status / Updated."""
        out = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=_SAMPLE_LIST)
        assert "Total Members" in out
        assert "Type" in out
        assert "Status" in out
        assert "Updated" in out


# ---------------------------------------------------------------------------
# render_list_detail_text_fallback
# ---------------------------------------------------------------------------


class TestTextFallback:
    def test_basic(self):
        out = ar.render_list_detail_text_fallback(
            list_id=_LIST_ID, list_obj=_SAMPLE_LIST
        )
        assert "Enterprise CFOs" in out

    def test_none(self):
        out = ar.render_list_detail_text_fallback(list_id=_LIST_ID, list_obj=None)
        assert "unavailable" in out.lower() or "not available" in out.lower()

    def test_mismatch_id(self):
        out = ar.render_list_detail_text_fallback(
            list_id="99", list_obj={**_SAMPLE_LIST, "id": 1}
        )
        assert "not found" in out.lower() or "no list" in out.lower()

    def test_total_rendered(self):
        out = ar.render_list_detail_text_fallback(
            list_id=_LIST_ID, list_obj=_SAMPLE_LIST
        )
        assert "1,234" in out

    def test_tags_rendered(self):
        out = ar.render_list_detail_text_fallback(
            list_id=_LIST_ID, list_obj=_SAMPLE_LIST
        )
        assert "enterprise" in out
        assert "cfo" in out

    def test_related_surfaces(self):
        out = ar.render_list_detail_text_fallback(
            list_id=_LIST_ID, list_obj=_SAMPLE_LIST
        )
        assert "g8://lists/42/contacts" in out
        assert "g8://lists/dashboard" in out

    def test_markdown_headings(self):
        out = ar.render_list_detail_text_fallback(
            list_id=_LIST_ID, list_obj=_SAMPLE_LIST
        )
        # Should have markdown-style headings (## or #)
        assert "##" in out or "#" in out

    def test_no_html(self):
        out = ar.render_list_detail_text_fallback(
            list_id=_LIST_ID, list_obj=_SAMPLE_LIST
        )
        # Plaintext fallback must not have HTML tags
        assert "<html>" not in out
        assert "<div" not in out

    def test_xss_title_plaintext(self):
        lst = {**_SAMPLE_LIST, "title": "<script>alert(1)</script>"}
        out = ar.render_list_detail_text_fallback(list_id=_LIST_ID, list_obj=lst)
        # In plaintext, the literal "<script>" IS OK because the client
        # treats it as text — but we still want no `javascript:` URIs etc.
        assert "javascript:" not in out.lower()

    def test_ends_with_newline(self):
        out = ar.render_list_detail_text_fallback(
            list_id=_LIST_ID, list_obj=_SAMPLE_LIST
        )
        assert out.endswith("\n")


# ---------------------------------------------------------------------------
# Smoke
# ---------------------------------------------------------------------------


class TestSmoke:
    def test_roundtrip(self):
        """HTML and text both rendered without crash for same input."""
        h = ar.render_list_detail_html(list_id=_LIST_ID, list_obj=_SAMPLE_LIST)
        t = ar.render_list_detail_text_fallback(
            list_id=_LIST_ID, list_obj=_SAMPLE_LIST
        )
        assert isinstance(h, str)
        assert isinstance(t, str)
        assert len(h) > 500
        assert len(t) > 100

    def test_empty_state_roundtrip(self):
        h = ar.render_list_detail_html(list_id="nonexistent", list_obj=None)
        t = ar.render_list_detail_text_fallback(list_id="nonexistent", list_obj=None)
        assert isinstance(h, str)
        assert isinstance(t, str)
