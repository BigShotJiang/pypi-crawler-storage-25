"""Regression tests for MCP OAuth → API key resolution and cache invalidation.

These tests cover the failure modes that caused users to be stuck with a
revoked/wrong-org cached API key for up to 14 days:

1. The user cache key includes org_id, so an org switch in PropelAuth
   automatically misses the cache and triggers fresh key creation.
2. A freshly-minted API key is cached immediately (no post-mint validation
   round-trip — see notes in _resolve_jwt_to_api_key).
3. invalidate_cached_key() busts both token-level and user-level cache
   entries via the api_key reverse mapping, so a 401 from the backend
   forces the next request to provision a fresh key.
4. safe_call() invokes invalidate_cached_key on 401 and surfaces the key
   suffix in the user-facing error.
"""

from __future__ import annotations

import hashlib
import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from g8_mcp_server import server as srv
from g8_mcp_server.auth import set_api_key
from g8_mcp_server.client import G8ClientError, _format_error, safe_call


# ---------------------------------------------------------------------------
# Fake Redis: just enough to exercise getex/setex/get/delete
# ---------------------------------------------------------------------------

class FakeRedis:
    def __init__(self):
        self.store: dict[str, bytes] = {}

    async def get(self, key):
        return self.store.get(key)

    async def setex(self, key, ttl, value):
        if isinstance(value, str):
            value = value.encode()
        self.store[key] = value

    async def delete(self, key):
        return 1 if self.store.pop(key, None) is not None else 0


@pytest.fixture
def fake_redis(monkeypatch):
    fake = FakeRedis()
    monkeypatch.setattr(srv, "_redis", lambda: fake)
    return fake


# ---------------------------------------------------------------------------
# Cache-key composition
# ---------------------------------------------------------------------------

class TestCacheKeyComposition:
    def test_user_cache_key_includes_org_id(self):
        """Same user in different orgs must produce different cache keys.

        This is the core fix for the 'stuck with wrong-org key' bug.
        """
        k1 = srv._user_cache_key_for("user_123", "org_AAA")
        k2 = srv._user_cache_key_for("user_123", "org_BBB")
        assert k1 != k2, "user cache key must differ when active org differs"

    def test_user_cache_key_stable_for_same_inputs(self):
        k1 = srv._user_cache_key_for("user_123", "org_AAA")
        k2 = srv._user_cache_key_for("user_123", "org_AAA")
        assert k1 == k2

    def test_reverse_key_is_deterministic(self):
        k1 = srv._key_reverse_key_for("api_key_xyz")
        k2 = srv._key_reverse_key_for("api_key_xyz")
        assert k1 == k2
        assert k1.startswith(srv._KEY_REVERSE_PREFIX)


# ---------------------------------------------------------------------------
# Cache invalidation by api_key (the 401-recovery path)
# ---------------------------------------------------------------------------

class TestInvalidateCachedKey:
    @pytest.mark.asyncio
    async def test_invalidate_busts_both_cache_levels(self, fake_redis):
        """invalidate_cached_key must remove BOTH token and user cache entries
        plus the reverse mapping, so the next OAuth resolution starts fresh."""
        api_key = "stale_key_abcd1234"
        token_key = f"{srv._JWT_CACHE_PREFIX}token_hash_xx"
        user_key = f"{srv._USER_CACHE_PREFIX}user_org_hash_yy"

        # Seed the caches
        await fake_redis.setex(token_key, 60, api_key)
        await fake_redis.setex(user_key, 60, api_key)
        await srv._store_key_reverse_mapping(api_key, [token_key, user_key])

        deleted = await srv.invalidate_cached_key(api_key)

        assert deleted == 2
        assert await fake_redis.get(token_key) is None
        assert await fake_redis.get(user_key) is None
        # Reverse mapping itself is also cleaned up
        assert await fake_redis.get(srv._key_reverse_key_for(api_key)) is None

    @pytest.mark.asyncio
    async def test_invalidate_no_op_when_no_mapping(self, fake_redis):
        """No reverse mapping → return 0, don't crash."""
        deleted = await srv.invalidate_cached_key("never_cached_key")
        assert deleted == 0

    @pytest.mark.asyncio
    async def test_invalidate_empty_key_returns_zero(self, fake_redis):
        assert await srv.invalidate_cached_key("") == 0


# ---------------------------------------------------------------------------
# _resolve_jwt_to_api_key — happy path & validation gating
# ---------------------------------------------------------------------------

class TestResolveJwtToApiKey:
    @pytest.mark.asyncio
    async def test_org_switch_misses_user_cache(self, fake_redis):
        """A user that was previously cached for org A but is now active in
        org B must NOT receive the cached-for-A key. This is the fix for
        the user reporting 'reconnected, still 401' after an org switch."""
        token = "oauth_token_long_enough_for_introspect_xxxxxxxxxxxxxxx"
        user_id = "user_123"
        old_org_uuid = "pa_uuid_for_org_AAA"
        new_org_uuid = "pa_uuid_for_org_BBB"
        old_key = "key_for_old_org_AAAA"
        new_key = "key_for_new_org_BBBB"

        # Pre-seed cache for old org (simulates state after first successful resolve)
        old_user_cache_key = srv._user_cache_key_for(user_id, old_org_uuid)
        await fake_redis.setex(old_user_cache_key, 60, old_key)

        with patch.object(srv, "_introspect_token", new=AsyncMock(return_value={"sub": user_id, "username": "u"})), \
             patch.object(srv, "_fetch_user_org", new=AsyncMock(return_value=new_org_uuid)), \
             patch.object(srv, "_create_api_key", new=AsyncMock(return_value=new_key)):
            result = await srv._resolve_jwt_to_api_key(token)

        assert result == new_key, "must NOT return the cached key from the old org"
        # New org cache key was populated
        assert (await fake_redis.get(srv._user_cache_key_for(user_id, new_org_uuid))) == new_key.encode()

    @pytest.mark.asyncio
    async def test_freshly_minted_key_is_cached_without_revalidation(self, fake_redis):
        """The OAuth mint path trusts PropelAuth's response to _create_api_key
        and caches the key immediately without a second validation round-trip.

        History: commit a7c8e49d2 added a post-mint validation step against
        /api/v1/profile (404) and later /campaign-builder/profile/mcp/status
        (JWT-only, rejects end-user API keys with 401). Every freshly-minted
        key was being rejected. Reverted to the pre-a7c8e49d2 behavior (no
        post-mint validation); stale-cache safety comes from the reverse
        mapping + invalidate_cached_key() path instead."""
        token = "oauth_token_long_enough_for_introspect_xxxxxxxxxxxxxxx"
        user_id = "user_fresh"
        org_uuid = "pa_uuid_fresh"
        minted_key = "newly_minted_key_FRSH"

        captured: list[tuple[str, int]] = []
        original_setex = fake_redis.setex

        async def spy_setex(key, ttl, value):
            captured.append((key, ttl))
            await original_setex(key, ttl, value)

        fake_redis.setex = spy_setex  # type: ignore[assignment]

        validate_mock = AsyncMock()
        with patch.object(srv, "_introspect_token", new=AsyncMock(return_value={"sub": user_id})), \
             patch.object(srv, "_fetch_user_org", new=AsyncMock(return_value=org_uuid)), \
             patch.object(srv, "_create_api_key", new=AsyncMock(return_value=minted_key)), \
             patch.object(srv, "_validate_api_key", new=validate_mock):
            result = await srv._resolve_jwt_to_api_key(token)

        assert result == minted_key
        # Validation is NOT called on the OAuth mint path anymore.
        validate_mock.assert_not_called()
        # Both cache entries use the full JWT TTL (no "short TTL for unvalidated keys" path).
        cache_ttls = [
            ttl for key, ttl in captured
            if key.startswith(srv._JWT_CACHE_PREFIX) or key.startswith(srv._USER_CACHE_PREFIX)
        ]
        assert cache_ttls == [srv._JWT_CACHE_TTL, srv._JWT_CACHE_TTL], (
            f"expected both cache entries at full TTL, got: {cache_ttls}"
        )

    @pytest.mark.asyncio
    async def test_level1_hit_refreshes_reverse_mapping(self, fake_redis):
        """A Level 1 (token) cache hit must re-arm the reverse mapping so
        invalidate_cached_key still works for long-lived sessions."""
        token = "oauth_token_long_enough_for_introspect_xxxxxxxxxxxxxxx"
        cached_key = "previously_cached_key_LM01"
        token_cache_key = f"{srv._JWT_CACHE_PREFIX}{hashlib.sha256(token.encode()).hexdigest()[:32]}"
        await fake_redis.setex(token_cache_key, 60, cached_key)
        # Note: NO reverse mapping pre-existing (simulating drift / Redis eviction)

        result = await srv._resolve_jwt_to_api_key(token)

        assert result == cached_key
        # Reverse mapping should now exist so a future 401 can invalidate
        reverse = await fake_redis.get(srv._key_reverse_key_for(cached_key))
        assert reverse is not None
        assert token_cache_key in json.loads(reverse.decode())

    @pytest.mark.asyncio
    async def test_successful_resolve_writes_reverse_mapping(self, fake_redis):
        """Reverse mapping must exist after a successful resolve so a later
        401 from a tool call can bust the cache."""
        token = "oauth_token_long_enough_for_introspect_xxxxxxxxxxxxxxx"
        user_id = "user_42"
        org_uuid = "pa_uuid_42"
        good_key = "fresh_valid_key_4242"

        with patch.object(srv, "_introspect_token", new=AsyncMock(return_value={"sub": user_id})), \
             patch.object(srv, "_fetch_user_org", new=AsyncMock(return_value=org_uuid)), \
             patch.object(srv, "_create_api_key", new=AsyncMock(return_value=good_key)):
            await srv._resolve_jwt_to_api_key(token)

        reverse = await fake_redis.get(srv._key_reverse_key_for(good_key))
        assert reverse is not None
        cache_keys = json.loads(reverse.decode())
        assert len(cache_keys) == 2
        # Confirm both cache entries the reverse mapping points to actually exist
        for ck in cache_keys:
            assert await fake_redis.get(ck) == good_key.encode()


# ---------------------------------------------------------------------------
# safe_call — 401 triggers cache invalidation + key suffix in error
# ---------------------------------------------------------------------------

class TestSafeCallOn401:
    @pytest.mark.asyncio
    async def test_401_invalidates_cache_and_includes_key_suffix(self, fake_redis, monkeypatch):
        """When a tool call returns 401, safe_call should:
        - call invalidate_cached_key(stale_key) so next request bypasses cache
        - include the last 4 chars of the stale key in the user-facing error
        """
        stale_key = "stale_revoked_key_WXYZ"
        token_key = f"{srv._JWT_CACHE_PREFIX}tk"
        user_key = f"{srv._USER_CACHE_PREFIX}uk"
        await fake_redis.setex(token_key, 60, stale_key)
        await fake_redis.setex(user_key, 60, stale_key)
        await srv._store_key_reverse_mapping(stale_key, [token_key, user_key])

        # Set the api_key in the request contextvar (as auth middleware would)
        set_api_key(stale_key)

        async def boom():
            raise G8ClientError(401, "backend rejected key")

        try:
            msg = await safe_call(boom(), context="Test op")
        finally:
            set_api_key("")  # reset

        assert "WXYZ" in msg, "key suffix must be in user-facing error for debuggability"
        # Cache was busted by the 401
        assert await fake_redis.get(token_key) is None
        assert await fake_redis.get(user_key) is None

    @pytest.mark.asyncio
    async def test_format_error_401_no_suffix(self):
        """_format_error without key_suffix must still produce a clean message."""
        msg = _format_error(G8ClientError(401, "x"))
        assert "invalid or expired" in msg
        assert "(key=..." not in msg  # no suffix → no parenthetical

    @pytest.mark.asyncio
    async def test_format_error_401_with_suffix(self):
        msg = _format_error(G8ClientError(401, "x"), key_suffix="ab12")
        assert "(key=...ab12)" in msg
