"""Tests for Surface #77 — g8://contacts/department/{department}.

Coverage plan:
- normalize: canonical keys (14), URL-friendly aliases (100+), invalid strings,
  non-string inputs, None/empty/whitespace, case variants, hyphen/underscore forms.
- label/short_label: every canonical + one alias.
- palette: every canonical key (must use graph8 tokens only; never the 4 banned
  Studio hexes).
- clip: empty/None/whitespace/over-cap/under-cap/non-string.
- display_name: first+last, work_email fallback, unnamed fallback, non-dict.
- location: every field present, none present, missing middle, non-string values.
- header/kpi/stats/row: structural HTML presence. Stats row MUST show
  "Unique companies" + "Seniority tiers" (NOT "With company" + "With title" —
  that's Surface #76's signature).
- overflow banner: positive, zero, negative. URL uses job_department param.
- drill_up: siblings include every other dept, never self-ref, includes
  cross-axis link to seniority/vp (first cross-axis for contacts surfaces).
- empty_state: zero_state=True accent, zero_state=False muted.
- render_contacts_department_html: happy path, empty list, None payload,
  invalid URI key, non-list payload, XSS escape, seniority-rank sort.
- render_contacts_department_text_fallback: same set of branches.
- Design tokens: locks out banned Studio hexes + confirms graph8 tokens present.
- no_js: ensure no <script> or event handlers in any render output.
- Smoke: all aliases + canonicals route to valid URIs without KeyError.
- Constants: tuple immutability + completeness + no alias shadowing.
"""

from __future__ import annotations

import pytest

from mcp_server.g8_mcp_server.app_renderer import (
    _CONTACTS_DEPARTMENT_ALIASES,
    _CONTACTS_DEPARTMENT_LABELS,
    _CONTACTS_DEPARTMENT_VALID,
    _contacts_department_chip_html,
    _contacts_department_clip,
    _contacts_department_display_name,
    _contacts_department_drill_up_html,
    _contacts_department_empty_state_html,
    _contacts_department_header_html,
    _contacts_department_kpi_card_html,
    _contacts_department_label,
    _contacts_department_list_html,
    _contacts_department_location,
    _contacts_department_normalize,
    _contacts_department_overflow_banner_html,
    _contacts_department_palette,
    _contacts_department_row_html,
    _contacts_department_short_label,
    _contacts_department_stats_row_html,
    render_contacts_department_html,
    render_contacts_department_text_fallback,
)


# ---------------------------------------------------------------------------
# Normalize — canonical keys
# ---------------------------------------------------------------------------

class TestNormalizeCanonical:
    @pytest.mark.parametrize("key", list(_CONTACTS_DEPARTMENT_VALID))
    def test_all_canonical_self_map(self, key):
        assert _contacts_department_normalize(key) == key

    @pytest.mark.parametrize("key", list(_CONTACTS_DEPARTMENT_VALID))
    def test_canonical_uppercase(self, key):
        assert _contacts_department_normalize(key.upper()) == key

    @pytest.mark.parametrize("key", list(_CONTACTS_DEPARTMENT_VALID))
    def test_canonical_with_spaces(self, key):
        assert _contacts_department_normalize(f"  {key}  ") == key

    def test_customer_success_hyphen_form(self):
        assert _contacts_department_normalize("customer-success") == "customer_success"

    def test_customer_success_title_case(self):
        assert _contacts_department_normalize("Customer Success") == "customer_success"

    def test_sales_spaces(self):
        assert _contacts_department_normalize(" sales ") == "sales"


# ---------------------------------------------------------------------------
# Normalize — aliases
# ---------------------------------------------------------------------------

class TestNormalizeAliases:
    @pytest.mark.parametrize("alias,expected", [
        # Sales
        ("sdr", "sales"),
        ("bdr", "sales"),
        ("ae", "sales"),
        ("gtm", "sales"),
        ("revenue", "sales"),
        ("bizdev", "sales"),
        ("biz-dev", "sales"),
        ("account-executive", "sales"),
        ("business-development", "sales"),
        # Marketing
        ("mkt", "marketing"),
        ("mktg", "marketing"),
        ("growth", "marketing"),
        ("brand", "marketing"),
        ("content", "marketing"),
        ("seo", "marketing"),
        ("pr", "marketing"),
        ("demand-gen", "marketing"),
        ("demandgen", "marketing"),
        # Engineering
        ("eng", "engineering"),
        ("engr", "engineering"),
        ("software", "engineering"),
        ("dev", "engineering"),
        ("devs", "engineering"),
        ("r&d", "engineering"),
        ("rnd", "engineering"),
        # Product
        ("pm", "product"),
        ("product-management", "product"),
        ("product-mgmt", "product"),
        # Design
        ("ux", "design"),
        ("ui", "design"),
        ("ui-ux", "design"),
        ("product-design", "design"),
        # Operations
        ("ops", "operations"),
        ("revops", "operations"),
        ("rev-ops", "operations"),
        ("salesops", "operations"),
        ("bizops", "operations"),
        ("marketing-ops", "operations"),
        # Customer Success
        ("cs", "customer_success"),
        ("cx", "customer_success"),
        ("csm", "customer_success"),
        ("success", "customer_success"),
        ("customer-experience", "customer_success"),
        ("account-management", "customer_success"),
        # Finance
        ("accounting", "finance"),
        ("fp&a", "finance"),
        ("fpa", "finance"),
        ("treasury", "finance"),
        # HR
        ("people", "hr"),
        ("talent", "hr"),
        ("recruiting", "hr"),
        ("human-resources", "hr"),
        ("people-ops", "hr"),
        # Legal
        ("compliance", "legal"),
        ("general-counsel", "legal"),
        # Data
        ("analytics", "data"),
        ("data-science", "data"),
        ("bi", "data"),
        ("ml", "data"),
        ("machine-learning", "data"),
        ("business-intelligence", "data"),
        # IT
        ("infosec", "it"),
        ("security", "it"),
        ("devops", "it"),
        ("sre", "it"),
        ("infrastructure", "it"),
        # Executive
        ("exec", "executive"),
        ("leadership", "executive"),
        ("c-suite", "executive"),
        ("founders", "executive"),
        # Support
        ("customer-support", "support"),
        ("technical-support", "support"),
        ("help-desk", "support"),
        ("helpdesk", "support"),
    ])
    def test_alias_maps_to_canonical(self, alias, expected):
        assert _contacts_department_normalize(alias) == expected

    def test_alias_uppercase(self):
        assert _contacts_department_normalize("SDR") == "sales"

    def test_alias_mixed_case(self):
        assert _contacts_department_normalize("CustomerSupport") is None or \
               _contacts_department_normalize("CustomerSupport") == "support"
        # Title case variant that normalizes: "Customer-Support" → "customer-support"
        assert _contacts_department_normalize("Customer-Support") == "support"

    def test_alias_with_spaces(self):
        assert _contacts_department_normalize("  sdr  ") == "sales"


# ---------------------------------------------------------------------------
# Normalize — invalid
# ---------------------------------------------------------------------------

class TestNormalizeInvalid:
    @pytest.mark.parametrize("bad", [
        "", "   ", None, 42, [], {}, "zzzzzz", "unknown-role",
        "janitor", "chef", "astronaut", "?", "null",
        "sal", "mkt-team",  # partial but not matching
        True,
    ])
    def test_invalid_returns_none(self, bad):
        assert _contacts_department_normalize(bad) is None

    def test_empty_after_strip(self):
        assert _contacts_department_normalize("\t\n  ") is None


# ---------------------------------------------------------------------------
# Labels
# ---------------------------------------------------------------------------

class TestLabel:
    def test_every_canonical_has_label(self):
        for key in _CONTACTS_DEPARTMENT_VALID:
            label = _contacts_department_label(key)
            assert isinstance(label, str) and label

    def test_customer_success_label(self):
        assert _contacts_department_label("customer_success") == "Customer Success"

    def test_hr_label_is_people_and_hr(self):
        assert _contacts_department_label("hr") == "People & HR"

    def test_data_label(self):
        assert _contacts_department_label("data") == "Data & Analytics"

    def test_alias_resolves_to_canonical_label(self):
        assert _contacts_department_label("sdr") == "Sales"
        assert _contacts_department_label("cs") == "Customer Success"
        assert _contacts_department_label("eng") == "Engineering"

    def test_invalid_returns_contacts(self):
        assert _contacts_department_label("bogus") == "Contacts"


class TestShortLabel:
    def test_same_as_label(self):
        for key in _CONTACTS_DEPARTMENT_VALID:
            assert _contacts_department_short_label(key) == _contacts_department_label(key)


# ---------------------------------------------------------------------------
# Palette
# ---------------------------------------------------------------------------

class TestPalette:
    BANNED_HEXES = ("#1d4ed8", "#166534", "#991b1b", "#0891b2")

    @pytest.mark.parametrize("key", list(_CONTACTS_DEPARTMENT_VALID))
    def test_returns_bg_fg_tuple(self, key):
        bg, fg = _contacts_department_palette(key)
        assert isinstance(bg, str) and bg
        assert isinstance(fg, str) and fg

    @pytest.mark.parametrize("key", list(_CONTACTS_DEPARTMENT_VALID))
    def test_no_banned_hexes(self, key):
        bg, fg = _contacts_department_palette(key)
        for banned in self.BANNED_HEXES:
            assert banned not in bg.lower()
            assert banned not in fg.lower()

    def test_invalid_uses_muted(self):
        bg, fg = _contacts_department_palette("bogus")
        assert bg == "#f9f9f9"  # _G8_MUTED_BG

    def test_sales_uses_accent(self):
        bg, fg = _contacts_department_palette("sales")
        assert bg == "#f2eafe"  # _G8_ACCENT_BG
        assert fg == "#7d2df3"  # _G8_PRIMARY

    def test_marketing_uses_accent(self):
        bg, fg = _contacts_department_palette("marketing")
        assert bg == "#f2eafe"

    def test_engineering_uses_accent(self):
        bg, fg = _contacts_department_palette("engineering")
        assert bg == "#f2eafe"

    def test_product_uses_accent(self):
        bg, fg = _contacts_department_palette("product")
        assert bg == "#f2eafe"

    def test_executive_uses_accent(self):
        bg, fg = _contacts_department_palette("executive")
        assert bg == "#f2eafe"

    def test_customer_success_uses_warning(self):
        bg, fg = _contacts_department_palette("customer_success")
        assert bg == "#fff3c4"  # _G8_WARNING_BG

    def test_design_uses_warning(self):
        bg, fg = _contacts_department_palette("design")
        assert bg == "#fff3c4"

    def test_data_uses_warning(self):
        bg, fg = _contacts_department_palette("data")
        assert bg == "#fff3c4"

    def test_operations_uses_muted(self):
        bg, fg = _contacts_department_palette("operations")
        assert bg == "#f9f9f9"

    def test_finance_uses_muted(self):
        bg, fg = _contacts_department_palette("finance")
        assert bg == "#f9f9f9"

    def test_hr_uses_muted(self):
        bg, fg = _contacts_department_palette("hr")
        assert bg == "#f9f9f9"

    def test_support_uses_muted(self):
        bg, fg = _contacts_department_palette("support")
        assert bg == "#f9f9f9"


# ---------------------------------------------------------------------------
# Clip
# ---------------------------------------------------------------------------

class TestClip:
    def test_short_unchanged(self):
        assert _contacts_department_clip("hi", 100) == "hi"

    def test_exactly_at_cap(self):
        s = "a" * 10
        assert _contacts_department_clip(s, 10) == s

    def test_truncates_over_cap(self):
        result = _contacts_department_clip("a" * 100, 10)
        assert result.endswith("…")
        assert len(result) == 10

    def test_none(self):
        assert _contacts_department_clip(None, 10) == ""

    def test_empty(self):
        assert _contacts_department_clip("", 10) == ""

    def test_whitespace(self):
        assert _contacts_department_clip("   ", 10) == ""

    def test_coerces_int(self):
        assert _contacts_department_clip(42, 10) == "42"

    def test_strips_whitespace(self):
        assert _contacts_department_clip("  hello  ", 100) == "hello"


# ---------------------------------------------------------------------------
# Display name
# ---------------------------------------------------------------------------

class TestDisplayName:
    def test_first_last(self):
        name = _contacts_department_display_name(
            {"first_name": "Jane", "last_name": "Doe"}
        )
        assert "Jane" in name and "Doe" in name

    def test_first_only(self):
        name = _contacts_department_display_name({"first_name": "Jane"})
        assert "Jane" in name

    def test_last_only(self):
        name = _contacts_department_display_name({"last_name": "Doe"})
        assert "Doe" in name

    def test_email_fallback(self):
        name = _contacts_department_display_name(
            {"work_email": "user@example.com"}
        )
        assert "user@example.com" in name

    def test_unnamed_fallback(self):
        assert _contacts_department_display_name({}) == "(unnamed contact)"

    def test_non_dict(self):
        assert _contacts_department_display_name(None) == "(unnamed contact)"
        assert _contacts_department_display_name("foo") == "(unnamed contact)"
        assert _contacts_department_display_name([]) == "(unnamed contact)"

    def test_xss_escape(self):
        name = _contacts_department_display_name(
            {"first_name": "<script>", "last_name": "Doe"}
        )
        assert "<script>" not in name
        assert "&lt;script&gt;" in name


# ---------------------------------------------------------------------------
# Location
# ---------------------------------------------------------------------------

class TestLocation:
    def test_all_three(self):
        loc = _contacts_department_location(
            {"city": "SF", "state": "CA", "country": "US"}
        )
        assert "SF, CA, US" in loc

    def test_missing_city(self):
        loc = _contacts_department_location(
            {"state": "CA", "country": "US"}
        )
        assert loc == "CA, US"

    def test_missing_state(self):
        loc = _contacts_department_location(
            {"city": "SF", "country": "US"}
        )
        assert loc == "SF, US"

    def test_empty_fields(self):
        loc = _contacts_department_location(
            {"city": "", "state": "  ", "country": None}
        )
        assert loc == ""

    def test_all_missing(self):
        assert _contacts_department_location({}) == ""

    def test_non_dict(self):
        assert _contacts_department_location(None) == ""
        assert _contacts_department_location("foo") == ""

    def test_xss_escape(self):
        loc = _contacts_department_location({"city": "<b>City</b>"})
        assert "<b>" not in loc
        assert "&lt;b&gt;" in loc


# ---------------------------------------------------------------------------
# Header
# ---------------------------------------------------------------------------

class TestHeader:
    def test_contains_label(self):
        html = _contacts_department_header_html("sales", 5)
        assert "Sales" in html

    def test_contains_count(self):
        html = _contacts_department_header_html("sales", 5)
        assert "5 contacts" in html

    def test_singular(self):
        html = _contacts_department_header_html("sales", 1)
        assert "1 contact" in html
        assert "1 contacts" not in html

    def test_zero(self):
        html = _contacts_department_header_html("sales", 0)
        assert "0 contacts" in html

    def test_uses_graph8_primary(self):
        html = _contacts_department_header_html("sales", 10)
        assert "#7d2df3" in html.lower()

    def test_department_prefix(self):
        html = _contacts_department_header_html("sales", 10)
        assert "Department" in html


# ---------------------------------------------------------------------------
# KPI card / stats row
# ---------------------------------------------------------------------------

class TestKpiCard:
    def test_label_and_value(self):
        html = _contacts_department_kpi_card_html("Total", "42")
        assert "Total" in html
        assert "42" in html

    def test_accent_variant_uses_primary(self):
        html = _contacts_department_kpi_card_html("T", "1", accent=True)
        assert "#7d2df3" in html.lower() or "#f2eafe" in html.lower()


class TestStatsRow:
    def test_four_cards(self):
        html = _contacts_department_stats_row_html([
            {"work_email": "a@b.com", "company_name": "X", "seniority_level": "vp"},
        ])
        assert "Total" in html
        assert "With email" in html
        assert "Unique companies" in html
        assert "Seniority tiers" in html

    def test_has_unique_companies_not_with_title(self):
        """Department pane is cross-account discovery — show distinct company
        count, not title verification. That's #76's signature."""
        html = _contacts_department_stats_row_html([
            {"company_name": "A", "seniority_level": "vp"},
        ])
        assert "Unique companies" in html
        # Seniority signature label MUST be present.
        assert "Seniority tiers" in html
        # #76's title-verification label MUST be absent.
        assert "With title" not in html
        assert "With company" not in html

    def test_counts_correctly(self):
        html = _contacts_department_stats_row_html([
            {"work_email": "a@b.com", "company_name": "Acme", "seniority_level": "vp"},
            {"work_email": "b@b.com", "company_name": "Acme", "seniority_level": "director"},
            {"work_email": "", "company_name": "Beta", "seniority_level": "vp"},
        ])
        # 3 total, 2 with_email, 2 unique companies (Acme+Beta), 2 seniority tiers
        assert "3" in html
        assert "2" in html

    def test_empty_list(self):
        html = _contacts_department_stats_row_html([])
        assert "0" in html

    def test_non_dict_entries_filtered(self):
        html = _contacts_department_stats_row_html([
            {"work_email": "a@b.com"},
            "bogus",
            None,
        ])
        # Total is raw len; the dict-only filters apply only to the sub-counts.
        assert "Total" in html


# ---------------------------------------------------------------------------
# Chip
# ---------------------------------------------------------------------------

class TestChip:
    def test_renders_label(self):
        html = _contacts_department_chip_html("Sales", bg="#fff", fg="#000")
        assert "Sales" in html

    def test_border_optional(self):
        html_no_border = _contacts_department_chip_html(
            "Sales", bg="#fff", fg="#000"
        )
        assert "border:none" in html_no_border
        html_with_border = _contacts_department_chip_html(
            "Sales", bg="#fff", fg="#000", border="#000"
        )
        assert "border:1px solid" in html_with_border


# ---------------------------------------------------------------------------
# Row
# ---------------------------------------------------------------------------

class TestRow:
    def test_basic(self):
        html = _contacts_department_row_html(
            {
                "first_name": "Jane",
                "last_name": "Doe",
                "job_title": "VP Sales",
                "company_name": "Acme",
                "work_email": "jane@acme.com",
            },
            "sales",
        )
        assert "Jane Doe" in html
        assert "VP Sales" in html
        assert "Acme" in html
        assert "jane@acme.com" in html

    def test_xss_escape_name(self):
        html = _contacts_department_row_html(
            {"first_name": "<script>alert('x')</script>"},
            "sales",
        )
        assert "<script>" not in html
        assert "&lt;script&gt;" in html

    def test_xss_escape_title(self):
        html = _contacts_department_row_html(
            {"first_name": "A", "job_title": "<img onerror=x>"},
            "sales",
        )
        assert "<img onerror" not in html
        assert "&lt;img" in html

    def test_xss_escape_email(self):
        html = _contacts_department_row_html(
            {"first_name": "A", "work_email": "<x>@y"},
            "sales",
        )
        assert "<x>" not in html

    def test_xss_escape_company(self):
        html = _contacts_department_row_html(
            {"first_name": "A", "company_name": "<h1>Evil</h1>"},
            "sales",
        )
        assert "<h1>Evil</h1>" not in html

    def test_missing_fields_graceful(self):
        html = _contacts_department_row_html({}, "sales")
        assert "(unnamed contact)" in html

    def test_chip_present(self):
        html = _contacts_department_row_html(
            {"first_name": "A"}, "customer_success"
        )
        assert "Customer Success" in html

    def test_seniority_chip_when_present(self):
        html = _contacts_department_row_html(
            {"first_name": "A", "seniority_level": "VP"},
            "sales",
        )
        assert "VP" in html

    def test_no_seniority_chip_when_missing(self):
        html = _contacts_department_row_html({"first_name": "A"}, "sales")
        # Just ensure the render doesn't error; seniority column missing is fine.
        assert "A" in html

    def test_location_rendered(self):
        html = _contacts_department_row_html(
            {
                "first_name": "A",
                "city": "SF",
                "state": "CA",
                "country": "US",
            },
            "sales",
        )
        assert "SF, CA, US" in html


# ---------------------------------------------------------------------------
# List
# ---------------------------------------------------------------------------

class TestList:
    def test_renders_all_rows(self):
        contacts = [
            {"first_name": f"C{i}", "last_name": "X"} for i in range(5)
        ]
        html = _contacts_department_list_html(contacts, "sales")
        for i in range(5):
            assert f"C{i}" in html

    def test_caps_at_100(self):
        contacts = [
            {"first_name": f"C{i}"} for i in range(150)
        ]
        html = _contacts_department_list_html(contacts, "sales")
        # Only first 100 names present
        assert "C99" in html
        assert "C100" not in html


# ---------------------------------------------------------------------------
# Overflow banner
# ---------------------------------------------------------------------------

class TestOverflowBanner:
    def test_zero(self):
        assert _contacts_department_overflow_banner_html(0, "sales") == ""

    def test_negative(self):
        assert _contacts_department_overflow_banner_html(-5, "sales") == ""

    def test_positive(self):
        html = _contacts_department_overflow_banner_html(42, "sales")
        assert "42 more" in html
        assert "job_department=sales" in html
        assert "page=2" in html

    def test_uses_normalized_key_in_url(self):
        html = _contacts_department_overflow_banner_html(5, "sdr")
        assert "job_department=sales" in html

    def test_uses_muted_bg(self):
        html = _contacts_department_overflow_banner_html(10, "sales")
        assert "#f9f9f9" in html.lower()


# ---------------------------------------------------------------------------
# Drill up
# ---------------------------------------------------------------------------

class TestDrillUp:
    def test_has_dashboard(self):
        html = _contacts_department_drill_up_html("sales")
        assert "g8://contacts/dashboard" in html

    def test_siblings_present(self):
        html = _contacts_department_drill_up_html("sales")
        for sibling in _CONTACTS_DEPARTMENT_VALID:
            if sibling == "sales":
                continue
            assert f"g8://contacts/department/{sibling}" in html

    def test_cross_axis_drill_up_to_seniority(self):
        """#77 adds what #76 deferred: cross-axis link back to seniority axis."""
        html = _contacts_department_drill_up_html("sales")
        assert "g8://contacts/seniority/vp" in html
        assert "cross-axis" in html.lower()

    def test_no_self_reference(self):
        html = _contacts_department_drill_up_html("sales")
        # Self URI should NOT appear under drill-up card as a sibling link
        sibling_uri = "g8://contacts/department/sales"
        assert sibling_uri + "</code>" not in html

    def test_all_siblings_for_customer_success(self):
        html = _contacts_department_drill_up_html("customer_success")
        for sibling in _CONTACTS_DEPARTMENT_VALID:
            if sibling == "customer_success":
                continue
            assert sibling in html

    def test_related_surfaces_label(self):
        html = _contacts_department_drill_up_html("sales")
        assert "Related surfaces" in html


# ---------------------------------------------------------------------------
# Empty state
# ---------------------------------------------------------------------------

class TestEmptyState:
    def test_zero_state_accent(self):
        html = _contacts_department_empty_state_html("sales", zero_state=True)
        assert "#7d2df3" in html.lower() or "#f2eafe" in html.lower()
        assert "No Sales contacts" in html

    def test_zero_state_customer_success(self):
        html = _contacts_department_empty_state_html("customer_success", zero_state=True)
        assert "Customer Success" in html

    def test_unavailable_muted(self):
        html = _contacts_department_empty_state_html("sales", zero_state=False)
        assert "unavailable" in html.lower()
        assert "#f9f9f9" in html.lower() or "#dfdfdf" in html.lower()

    def test_unavailable_invalid_key(self):
        html = _contacts_department_empty_state_html("bogus", zero_state=False)
        assert "Contacts unavailable" in html

    def test_unavailable_hints_valid_keys(self):
        html = _contacts_department_empty_state_html("bogus", zero_state=False)
        assert "sales" in html
        assert "marketing" in html
        assert "engineering" in html


# ---------------------------------------------------------------------------
# render_contacts_department_html — full render
# ---------------------------------------------------------------------------

class TestRenderHtml:
    def test_happy_path(self):
        contacts = [
            {
                "first_name": "Jane",
                "last_name": "Doe",
                "job_title": "VP Sales",
                "company_name": "Acme",
                "work_email": "jane@acme.com",
                "seniority_level": "vp",
            },
        ]
        html = render_contacts_department_html(contacts=contacts, department="sales")
        assert "<!DOCTYPE html>" in html
        assert "Jane Doe" in html
        assert "Acme" in html
        assert "Contacts · Sales" in html

    def test_invalid_department(self):
        html = render_contacts_department_html(contacts=[], department="bogus")
        assert "unavailable" in html.lower()

    def test_invalid_non_string(self):
        html = render_contacts_department_html(contacts=[], department=None)
        assert "unavailable" in html.lower()

    def test_none_payload(self):
        html = render_contacts_department_html(contacts=None, department="sales")
        assert "unavailable" in html.lower()

    def test_empty_list_zero_state(self):
        html = render_contacts_department_html(contacts=[], department="sales")
        assert "No Sales contacts" in html
        # Zero-state is accent, not muted
        assert "#7d2df3" in html.lower() or "#f2eafe" in html.lower()

    def test_non_list_payload_treated_as_empty(self):
        html = render_contacts_department_html(
            contacts={"weird": "dict"}, department="sales"
        )
        assert "No Sales contacts" in html

    def test_non_dict_entries_filtered(self):
        contacts = [
            {"first_name": "Real"},
            "string entry",
            None,
            42,
            {"first_name": "Real2"},
        ]
        html = render_contacts_department_html(contacts=contacts, department="sales")
        assert "Real" in html
        assert "Real2" in html
        assert "2 contacts" in html

    def test_sort_by_seniority_rank_then_company_last_first(self):
        """Departments sort by seniority rank ASC (execs first), then company,
        last, first. Divergence from #76 which sorts strictly alphabetically."""
        contacts = [
            {"first_name": "IC", "last_name": "Z", "company_name": "Acme",
             "seniority_level": "ic"},
            {"first_name": "CEO", "last_name": "A", "company_name": "Acme",
             "seniority_level": "c_suite"},
            {"first_name": "VP", "last_name": "M", "company_name": "Acme",
             "seniority_level": "vp"},
        ]
        html = render_contacts_department_html(
            contacts=contacts, department="sales"
        )
        # CEO (c_suite rank 0) should come before VP (rank 3), before IC (rank 9)
        idx_ceo = html.find("CEO A")
        idx_vp = html.find("VP M")
        idx_ic = html.find("IC Z")
        assert idx_ceo < idx_vp < idx_ic

    def test_alias_routed(self):
        html = render_contacts_department_html(
            contacts=[{"first_name": "Jane"}], department="sdr"
        )
        # "sdr" normalizes to "sales" → header label "Sales"
        assert "Sales" in html

    def test_customer_success_alias_routed(self):
        html = render_contacts_department_html(
            contacts=[{"first_name": "Jane"}], department="cs"
        )
        assert "Customer Success" in html

    def test_xss_in_render(self):
        html = render_contacts_department_html(
            contacts=[{"first_name": "<script>alert('xss')</script>"}],
            department="sales",
        )
        assert "<script>" not in html
        assert "&lt;script&gt;" in html

    def test_overflow_banner_appears(self):
        contacts = [
            {"first_name": f"C{i}"} for i in range(150)
        ]
        html = render_contacts_department_html(
            contacts=contacts, department="sales"
        )
        assert "50 more" in html
        assert "job_department=sales" in html

    def test_cross_axis_link_in_html(self):
        html = render_contacts_department_html(
            contacts=[{"first_name": "Jane"}], department="sales"
        )
        assert "g8://contacts/seniority/vp" in html


# ---------------------------------------------------------------------------
# Design tokens — lock-out banned hexes
# ---------------------------------------------------------------------------

class TestDesignTokens:
    BANNED = ("#1d4ed8", "#166534", "#991b1b", "#0891b2")

    def _sample_render(self):
        return render_contacts_department_html(
            contacts=[
                {
                    "first_name": "J",
                    "last_name": "D",
                    "job_title": "VP",
                    "company_name": "Acme",
                    "work_email": "j@acme.com",
                    "seniority_level": "vp",
                    "city": "SF",
                    "state": "CA",
                    "country": "US",
                },
            ],
            department="sales",
        )

    @pytest.mark.parametrize("banned", list(BANNED))
    def test_no_banned_hexes_in_html(self, banned):
        html = self._sample_render()
        assert banned not in html.lower()

    @pytest.mark.parametrize("token", [
        "#7d2df3",  # _G8_PRIMARY
        "#f2eafe",  # _G8_ACCENT_BG
        "#dfdfdf",  # _G8_BORDER
        "#f9f9f9",  # _G8_MUTED_BG
    ])
    def test_graph8_tokens_present(self, token):
        html = self._sample_render()
        assert token in html.lower()

    def test_aeonik_font(self):
        html = self._sample_render()
        assert "Aeonik" in html


# ---------------------------------------------------------------------------
# No JavaScript
# ---------------------------------------------------------------------------

class TestNoJs:
    def test_no_script_tag(self):
        html = render_contacts_department_html(
            contacts=[{"first_name": "A"}], department="sales"
        )
        assert "<script" not in html.lower()
        assert "</script" not in html.lower()

    def test_no_event_handlers(self):
        html = render_contacts_department_html(
            contacts=[{"first_name": "A"}], department="sales"
        )
        for attr in ("onclick=", "onerror=", "onload=", "onmouseover="):
            assert attr not in html.lower()


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------

class TestTextFallback:
    def test_invalid_department(self):
        txt = render_contacts_department_text_fallback(
            contacts=[], department="bogus"
        )
        assert "unavailable" in txt.lower()
        assert "sales" in txt
        assert "engineering" in txt

    def test_none_payload(self):
        txt = render_contacts_department_text_fallback(
            contacts=None, department="sales"
        )
        assert "unavailable" in txt.lower()

    def test_empty_list(self):
        txt = render_contacts_department_text_fallback(
            contacts=[], department="sales"
        )
        assert "No Sales contacts yet" in txt
        assert "Related surfaces" in txt

    def test_happy_path(self):
        contacts = [
            {
                "first_name": "Jane",
                "last_name": "Doe",
                "job_title": "VP Sales",
                "company_name": "Acme",
                "work_email": "jane@acme.com",
            },
        ]
        txt = render_contacts_department_text_fallback(
            contacts=contacts, department="sales"
        )
        assert "Jane Doe" in txt
        assert "VP Sales" in txt
        assert "Acme" in txt
        assert "jane@acme.com" in txt
        assert "Related surfaces" in txt
        assert "Backend filter" in txt

    def test_stats_in_text(self):
        contacts = [
            {
                "first_name": "A", "work_email": "a@b.com",
                "company_name": "X", "seniority_level": "vp",
            },
        ]
        txt = render_contacts_department_text_fallback(
            contacts=contacts, department="sales"
        )
        assert "Total: 1" in txt
        assert "With email: 1" in txt
        assert "Unique companies: 1" in txt
        assert "Seniority tiers: 1" in txt

    def test_overflow_note(self):
        contacts = [
            {"first_name": f"C{i}"} for i in range(150)
        ]
        txt = render_contacts_department_text_fallback(
            contacts=contacts, department="sales"
        )
        assert "50 more contact" in txt

    def test_unnamed_fallback(self):
        contacts = [{"seniority_level": "vp"}]
        txt = render_contacts_department_text_fallback(
            contacts=contacts, department="sales"
        )
        assert "(unnamed contact)" in txt

    def test_cross_axis_link_in_text(self):
        txt = render_contacts_department_text_fallback(
            contacts=[{"first_name": "Jane"}], department="sales"
        )
        assert "g8://contacts/seniority/vp" in txt


# ---------------------------------------------------------------------------
# Smoke — every alias normalizes + renders cleanly
# ---------------------------------------------------------------------------

class TestSmoke:
    @pytest.mark.parametrize(
        "alias",
        list(_CONTACTS_DEPARTMENT_ALIASES.keys())
        + list(_CONTACTS_DEPARTMENT_VALID),
    )
    def test_alias_renders_without_error(self, alias):
        html = render_contacts_department_html(
            contacts=[{"first_name": "A"}], department=alias
        )
        assert html.startswith("<!DOCTYPE html>")

    @pytest.mark.parametrize(
        "alias",
        list(_CONTACTS_DEPARTMENT_ALIASES.keys())
        + list(_CONTACTS_DEPARTMENT_VALID),
    )
    def test_alias_text_without_error(self, alias):
        txt = render_contacts_department_text_fallback(
            contacts=[{"first_name": "A"}], department=alias
        )
        assert len(txt) > 0


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

class TestConstants:
    def test_valid_keys_is_tuple(self):
        assert isinstance(_CONTACTS_DEPARTMENT_VALID, tuple)
        assert len(_CONTACTS_DEPARTMENT_VALID) == 14

    def test_labels_covers_all_valid(self):
        for key in _CONTACTS_DEPARTMENT_VALID:
            assert key in _CONTACTS_DEPARTMENT_LABELS
            assert isinstance(_CONTACTS_DEPARTMENT_LABELS[key], str)

    def test_aliases_target_valid(self):
        for alias, target in _CONTACTS_DEPARTMENT_ALIASES.items():
            assert target in _CONTACTS_DEPARTMENT_VALID, (
                f"Alias {alias!r} → {target!r} not in canonical set"
            )

    def test_no_alias_equals_canonical(self):
        """Aliases must not shadow canonical keys."""
        canonical_set = set(_CONTACTS_DEPARTMENT_VALID)
        for alias in _CONTACTS_DEPARTMENT_ALIASES:
            assert alias not in canonical_set, (
                f"Alias {alias!r} shadows canonical key"
            )

    def test_aliases_has_100_plus(self):
        """Department has wide alias coverage (sdr/bdr/ae/mkt/eng/pm/etc.)."""
        assert len(_CONTACTS_DEPARTMENT_ALIASES) >= 80
