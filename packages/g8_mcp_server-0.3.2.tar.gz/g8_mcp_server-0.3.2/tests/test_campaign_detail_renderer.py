"""Unit tests for the surface #27 campaign-detail renderer + helpers.

Surface #27 is the per-campaign top-level overview at URI
`g8://campaigns/{campaign_id}/overview`. Complements surface #6
(campaigns dashboard, org-wide list), surface #21 (per-campaign docs),
surface #22 (per-campaign sequence plan).

Answers "what is THIS campaign about at a glance — status, narrative,
channels, document coverage?".
"""

from __future__ import annotations

import pytest

from g8_mcp_server.app_renderer import (
    _CAMPAIGN_DETAIL_CHANNEL_COLORS,
    _CAMPAIGN_DETAIL_CHANNEL_DEFAULT,
    _CAMPAIGN_DETAIL_STATUS_COLORS,
    _CAMPAIGN_DETAIL_STATUS_DEFAULT,
    _campaign_detail_channel_palette,
    _campaign_detail_derive_display_name,
    _campaign_detail_normalize_channels,
    _campaign_detail_status_palette,
    _campaign_detail_tally_doc_statuses,
    render_campaign_detail_html,
    render_campaign_detail_text_fallback,
)

_BANNED_HEXES = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}


class TestCampaignDetailPalettesNoBannedHexes:
    """Lock tests: palettes must not reintroduce banned Studio hexes."""

    def test_no_banned_hexes_in_status_palette(self):
        for key, pal in _CAMPAIGN_DETAIL_STATUS_COLORS.items():
            for field in ("bg", "fg", "border"):
                assert pal[field].lower() not in _BANNED_HEXES, (
                    f"Banned hex {pal[field]!r} in _CAMPAIGN_DETAIL_STATUS_COLORS[{key!r}][{field!r}]"
                )

    def test_no_banned_hexes_in_channel_palette(self):
        for key, pal in _CAMPAIGN_DETAIL_CHANNEL_COLORS.items():
            for field in ("bg", "fg", "border"):
                assert pal[field].lower() not in _BANNED_HEXES, (
                    f"Banned hex {pal[field]!r} in _CAMPAIGN_DETAIL_CHANNEL_COLORS[{key!r}][{field!r}]"
                )


def _sample_campaign() -> dict:
    return {
        "id": "b3c1f9d2-4f23-4e9c-a8b7-5f18a76e4e22",
        "name": "Q2 Enterprise Push",
        "slug": "q2-enterprise-push",
        "status": "live",
        "category": "Outbound",
        "goal": "decision",
        "target_persona": "VP of Engineering at 500-2000 employee SaaS companies",
        "brief": (
            "Warm up enterprise accounts that downloaded the Q1 whitepaper. "
            "Focus on organizations showing hiring signals for platform eng."
        ),
        "core_concept": "Reference the hiring signal + whitepaper opens as a natural lead-in.",
        "primary_hook": "Saw your team is doubling platform eng headcount — thought you might want this.",
        "channels": ["email", "linkedin"],
        "created_at": "2026-02-01T09:00:00Z",
        "updated_at": "2026-04-15T14:30:00Z",
    }


# -----------------------------------------------------------------------
# _campaign_detail_status_palette
# -----------------------------------------------------------------------


class TestCampaignDetailStatusPalette:
    def test_live_returns_green(self):
        pal = _campaign_detail_status_palette("live")
        assert pal["fg"] == "#059669"  # was banned #166534 → _G8_POSITIVE_FG

    def test_active_returns_green(self):
        assert _campaign_detail_status_palette("active")["fg"] == "#059669"  # was banned #166534

    def test_launched_returns_green(self):
        assert _campaign_detail_status_palette("launched")["fg"] == "#059669"  # was banned #166534

    def test_running_returns_green(self):
        assert _campaign_detail_status_palette("running")["fg"] == "#059669"  # was banned #166534

    def test_scheduled_returns_blue(self):
        assert _campaign_detail_status_palette("scheduled")["fg"] == "#1e40af"

    def test_draft_returns_gray(self):
        assert _campaign_detail_status_palette("draft")["fg"] == "#777777"

    def test_paused_returns_amber(self):
        assert _campaign_detail_status_palette("paused")["fg"] == "#92400e"

    def test_ended_returns_dark_gray(self):
        assert _campaign_detail_status_palette("ended")["fg"] == "#0A0A0A"

    def test_archived_returns_dark_gray(self):
        assert _campaign_detail_status_palette("archived")["fg"] == "#0A0A0A"

    def test_failed_returns_red(self):
        assert _campaign_detail_status_palette("failed")["fg"] == "#b91c1c"  # was banned #991b1b

    def test_error_returns_red(self):
        assert _campaign_detail_status_palette("error")["fg"] == "#b91c1c"  # was banned #991b1b

    def test_uppercase_matches(self):
        assert _campaign_detail_status_palette("LIVE")["fg"] == "#059669"  # was banned #166534

    def test_mixed_case_matches(self):
        assert _campaign_detail_status_palette("Paused")["fg"] == "#92400e"

    def test_surrounding_whitespace_stripped(self):
        assert _campaign_detail_status_palette("  draft  ")["fg"] == "#777777"

    def test_empty_string_returns_default(self):
        assert _campaign_detail_status_palette("") == _CAMPAIGN_DETAIL_STATUS_DEFAULT

    def test_whitespace_only_returns_default(self):
        assert _campaign_detail_status_palette("   ") == _CAMPAIGN_DETAIL_STATUS_DEFAULT

    def test_none_returns_default(self):
        assert _campaign_detail_status_palette(None) == _CAMPAIGN_DETAIL_STATUS_DEFAULT

    def test_unknown_status_returns_default(self):
        assert _campaign_detail_status_palette("mystery-state") == _CAMPAIGN_DETAIL_STATUS_DEFAULT

    def test_non_string_returns_default(self):
        assert _campaign_detail_status_palette(123) == _CAMPAIGN_DETAIL_STATUS_DEFAULT
        assert _campaign_detail_status_palette(True) == _CAMPAIGN_DETAIL_STATUS_DEFAULT
        assert _campaign_detail_status_palette(["live"]) == _CAMPAIGN_DETAIL_STATUS_DEFAULT

    def test_palette_always_has_required_keys(self):
        pal = _campaign_detail_status_palette("live")
        assert set(pal) >= {"bg", "fg", "border"}


# -----------------------------------------------------------------------
# _campaign_detail_channel_palette
# -----------------------------------------------------------------------


class TestCampaignDetailChannelPalette:
    def test_email_returns_blue(self):
        assert _campaign_detail_channel_palette("email")["fg"] == "#1e40af"

    def test_linkedin_returns_indigo(self):
        assert _campaign_detail_channel_palette("linkedin")["fg"] == "#7d2df3"

    def test_sms_returns_green(self):
        assert _campaign_detail_channel_palette("sms")["fg"] == "#059669"  # was banned #166534

    def test_phone_returns_amber(self):
        assert _campaign_detail_channel_palette("phone")["fg"] == "#92400e"

    def test_call_alias_returns_amber(self):
        assert _campaign_detail_channel_palette("call")["fg"] == "#92400e"

    def test_voice_alias_returns_amber(self):
        assert _campaign_detail_channel_palette("voice")["fg"] == "#92400e"

    def test_slack_returns_purple(self):
        assert _campaign_detail_channel_palette("slack")["fg"] == "#5b21b6"

    def test_whatsapp_returns_green(self):
        assert _campaign_detail_channel_palette("whatsapp")["fg"] == "#059669"  # was banned #166534

    def test_twitter_returns_sky(self):
        assert _campaign_detail_channel_palette("twitter")["fg"] == "#075985"

    def test_x_alias_returns_sky(self):
        assert _campaign_detail_channel_palette("x")["fg"] == "#075985"

    def test_case_insensitive(self):
        assert _campaign_detail_channel_palette("EMAIL")["fg"] == "#1e40af"

    def test_empty_returns_default(self):
        assert _campaign_detail_channel_palette("") == _CAMPAIGN_DETAIL_CHANNEL_DEFAULT

    def test_none_returns_default(self):
        assert _campaign_detail_channel_palette(None) == _CAMPAIGN_DETAIL_CHANNEL_DEFAULT

    def test_unknown_returns_default(self):
        assert _campaign_detail_channel_palette("fax") == _CAMPAIGN_DETAIL_CHANNEL_DEFAULT

    def test_non_string_returns_default(self):
        assert _campaign_detail_channel_palette(42) == _CAMPAIGN_DETAIL_CHANNEL_DEFAULT


# -----------------------------------------------------------------------
# _campaign_detail_normalize_channels
# -----------------------------------------------------------------------


class TestCampaignDetailNormalizeChannels:
    def test_simple_list(self):
        assert _campaign_detail_normalize_channels(["email", "linkedin"]) == ["email", "linkedin"]

    def test_preserves_order(self):
        assert _campaign_detail_normalize_channels(["linkedin", "email"]) == ["linkedin", "email"]

    def test_dedupes_case_insensitive(self):
        result = _campaign_detail_normalize_channels(["email", "EMAIL", "Email"])
        assert result == ["email"]

    def test_drops_empty_strings(self):
        assert _campaign_detail_normalize_channels(["", "email"]) == ["email"]

    def test_drops_whitespace_only(self):
        assert _campaign_detail_normalize_channels(["   ", "email"]) == ["email"]

    def test_trims_whitespace(self):
        assert _campaign_detail_normalize_channels(["  email  "]) == ["email"]

    def test_lowercases(self):
        assert _campaign_detail_normalize_channels(["EMAIL", "LinkedIn"]) == ["email", "linkedin"]

    def test_dict_entry_via_channel_key(self):
        result = _campaign_detail_normalize_channels([{"channel": "email"}])
        assert result == ["email"]

    def test_dict_entry_via_name_key(self):
        result = _campaign_detail_normalize_channels([{"name": "sms", "weight": 0.3}])
        assert result == ["sms"]

    def test_dict_entry_via_type_key(self):
        result = _campaign_detail_normalize_channels([{"type": "phone"}])
        assert result == ["phone"]

    def test_dict_entry_via_label_key(self):
        result = _campaign_detail_normalize_channels([{"label": "slack"}])
        assert result == ["slack"]

    def test_dict_channel_key_takes_precedence_over_name(self):
        # channel is checked first
        result = _campaign_detail_normalize_channels(
            [{"channel": "email", "name": "linkedin"}]
        )
        assert result == ["email"]

    def test_mixed_strings_and_dicts(self):
        result = _campaign_detail_normalize_channels(
            ["email", {"channel": "sms"}, "linkedin"]
        )
        assert result == ["email", "sms", "linkedin"]

    def test_single_string_treated_as_list(self):
        assert _campaign_detail_normalize_channels("email") == ["email"]

    def test_single_string_lowercased(self):
        assert _campaign_detail_normalize_channels("EMAIL") == ["email"]

    def test_string_with_whitespace(self):
        assert _campaign_detail_normalize_channels("  email  ") == ["email"]

    def test_empty_string_rejected(self):
        assert _campaign_detail_normalize_channels("") == []

    def test_whitespace_only_string_rejected(self):
        assert _campaign_detail_normalize_channels("   ") == []

    def test_none_returns_empty(self):
        assert _campaign_detail_normalize_channels(None) == []

    def test_int_rejected(self):
        assert _campaign_detail_normalize_channels(42) == []

    def test_empty_list(self):
        assert _campaign_detail_normalize_channels([]) == []

    def test_nested_list_entry_skipped(self):
        result = _campaign_detail_normalize_channels(["email", ["nested"], "linkedin"])
        assert result == ["email", "linkedin"]

    def test_dict_without_known_key_skipped(self):
        result = _campaign_detail_normalize_channels(
            ["email", {"unknown_key": "sms"}, "linkedin"]
        )
        assert result == ["email", "linkedin"]

    def test_dict_with_empty_name_skipped(self):
        result = _campaign_detail_normalize_channels(
            ["email", {"name": ""}, "linkedin"]
        )
        assert result == ["email", "linkedin"]

    def test_dict_with_non_string_name_skipped(self):
        result = _campaign_detail_normalize_channels(
            ["email", {"name": 123}, "linkedin"]
        )
        assert result == ["email", "linkedin"]


# -----------------------------------------------------------------------
# _campaign_detail_derive_display_name
# -----------------------------------------------------------------------


class TestCampaignDetailDeriveDisplayName:
    def test_name_preferred(self):
        assert (
            _campaign_detail_derive_display_name(
                {"name": "Q2 Push", "slug": "q2-push"}
            )
            == "Q2 Push"
        )

    def test_slug_fallback(self):
        assert (
            _campaign_detail_derive_display_name({"name": "", "slug": "q2-push"})
            == "q2-push"
        )

    def test_whitespace_name_falls_back_to_slug(self):
        assert (
            _campaign_detail_derive_display_name(
                {"name": "   ", "slug": "q2-push"}
            )
            == "q2-push"
        )

    def test_no_name_no_slug_returns_default(self):
        assert _campaign_detail_derive_display_name({}) == "Campaign"

    def test_empty_strings_return_default(self):
        assert (
            _campaign_detail_derive_display_name({"name": "", "slug": ""})
            == "Campaign"
        )

    def test_none_returns_default(self):
        assert _campaign_detail_derive_display_name(None) == "Campaign"

    def test_non_dict_returns_default(self):
        assert _campaign_detail_derive_display_name("nope") == "Campaign"
        assert _campaign_detail_derive_display_name(42) == "Campaign"
        assert _campaign_detail_derive_display_name([]) == "Campaign"

    def test_trims_whitespace(self):
        assert _campaign_detail_derive_display_name({"name": "  Q2  "}) == "Q2"

    def test_non_string_name_falls_back_to_slug(self):
        assert (
            _campaign_detail_derive_display_name({"name": 123, "slug": "q2"})
            == "q2"
        )


# -----------------------------------------------------------------------
# _campaign_detail_tally_doc_statuses
# -----------------------------------------------------------------------


class TestCampaignDetailTallyDocStatuses:
    def test_all_zero_for_empty_list(self):
        tally = _campaign_detail_tally_doc_statuses([])
        assert tally == {
            "ready": 0,
            "generating": 0,
            "pending": 0,
            "stale": 0,
            "failed": 0,
            "other": 0,
        }

    def test_none_returns_zeros(self):
        tally = _campaign_detail_tally_doc_statuses(None)
        assert sum(tally.values()) == 0

    def test_non_list_returns_zeros(self):
        tally = _campaign_detail_tally_doc_statuses("nope")
        assert sum(tally.values()) == 0

    def test_ready_bucket_aliases(self):
        tally = _campaign_detail_tally_doc_statuses(
            [
                {"status": "ready"},
                {"status": "completed"},
                {"status": "complete"},
                {"status": "done"},
            ]
        )
        assert tally["ready"] == 4

    def test_generating_bucket_aliases(self):
        tally = _campaign_detail_tally_doc_statuses(
            [
                {"status": "generating"},
                {"status": "running"},
                {"status": "in_progress"},
                {"status": "processing"},
            ]
        )
        assert tally["generating"] == 4

    def test_pending_bucket_aliases(self):
        tally = _campaign_detail_tally_doc_statuses(
            [
                {"status": "pending"},
                {"status": "queued"},
                {"status": "waiting"},
            ]
        )
        assert tally["pending"] == 3

    def test_failed_bucket_aliases(self):
        tally = _campaign_detail_tally_doc_statuses(
            [
                {"status": "failed"},
                {"status": "error"},
            ]
        )
        assert tally["failed"] == 2

    def test_stale_bucket(self):
        tally = _campaign_detail_tally_doc_statuses([{"status": "stale"}])
        assert tally["stale"] == 1

    def test_unknown_status_goes_to_other(self):
        tally = _campaign_detail_tally_doc_statuses([{"status": "unknown-status"}])
        assert tally["other"] == 1

    def test_missing_status_goes_to_other(self):
        tally = _campaign_detail_tally_doc_statuses([{"id": "a"}])
        assert tally["other"] == 1

    def test_case_insensitive(self):
        tally = _campaign_detail_tally_doc_statuses([{"status": "READY"}])
        assert tally["ready"] == 1

    def test_surrounding_whitespace_ok(self):
        tally = _campaign_detail_tally_doc_statuses([{"status": "  ready  "}])
        assert tally["ready"] == 1

    def test_non_dict_entries_skipped(self):
        tally = _campaign_detail_tally_doc_statuses(
            ["stringy", None, 42, {"status": "ready"}]
        )
        assert tally["ready"] == 1
        assert tally["other"] == 0

    def test_mixed_bag(self):
        tally = _campaign_detail_tally_doc_statuses(
            [
                {"status": "ready"},
                {"status": "ready"},
                {"status": "generating"},
                {"status": "failed"},
                {"status": "some-weird-state"},
            ]
        )
        assert tally["ready"] == 2
        assert tally["generating"] == 1
        assert tally["failed"] == 1
        assert tally["other"] == 1


# -----------------------------------------------------------------------
# render_campaign_detail_html — empty state
# -----------------------------------------------------------------------


class TestRenderCampaignDetailEmptyState:
    def test_none_triggers_empty_state(self):
        html = render_campaign_detail_html(campaign=None, campaign_id="abc-123")
        assert "Campaign not available" in html

    def test_non_dict_triggers_empty_state(self):
        html = render_campaign_detail_html(campaign="stringy", campaign_id="abc-123")
        assert "Campaign not available" in html

    def test_list_triggers_empty_state(self):
        html = render_campaign_detail_html(campaign=[], campaign_id="abc-123")
        assert "Campaign not available" in html

    def test_empty_state_shows_requested_id(self):
        html = render_campaign_detail_html(campaign=None, campaign_id="abc-123")
        assert "abc-123" in html

    def test_empty_state_suggests_list_campaigns_tool(self):
        html = render_campaign_detail_html(campaign=None, campaign_id="abc-123")
        assert "g8_list_campaigns" in html

    def test_empty_state_references_overview_uri(self):
        html = render_campaign_detail_html(campaign=None, campaign_id="abc-123")
        assert "g8://campaigns/{campaign_id}/overview" in html

    def test_empty_state_escapes_id(self):
        html = render_campaign_detail_html(
            campaign=None, campaign_id="<script>alert('xss')</script>"
        )
        assert "<script>alert('xss')</script>" not in html
        assert "&lt;script&gt;" in html


# -----------------------------------------------------------------------
# render_campaign_detail_html — populated
# -----------------------------------------------------------------------


class TestRenderCampaignDetailPopulated:
    def test_contains_campaign_name(self):
        html = render_campaign_detail_html(
            campaign=_sample_campaign(), campaign_id="b3c1f9d2"
        )
        assert "Q2 Enterprise Push" in html

    def test_contains_status_badge_element(self):
        html = render_campaign_detail_html(
            campaign=_sample_campaign(), campaign_id="b3c1f9d2"
        )
        assert '<span class="status-badge"' in html

    def test_status_rendered_uppercase(self):
        html = render_campaign_detail_html(
            campaign=_sample_campaign(), campaign_id="b3c1f9d2"
        )
        assert "LIVE" in html

    def test_unknown_status_renders_unknown(self):
        c = _sample_campaign()
        c["status"] = None
        html = render_campaign_detail_html(campaign=c, campaign_id="x")
        assert "UNKNOWN" in html

    def test_contains_category(self):
        html = render_campaign_detail_html(
            campaign=_sample_campaign(), campaign_id="b3c1f9d2"
        )
        assert "Outbound" in html

    def test_contains_goal(self):
        html = render_campaign_detail_html(
            campaign=_sample_campaign(), campaign_id="b3c1f9d2"
        )
        assert "decision" in html

    def test_contains_target_persona(self):
        html = render_campaign_detail_html(
            campaign=_sample_campaign(), campaign_id="b3c1f9d2"
        )
        assert "VP of Engineering" in html

    def test_contains_slug(self):
        html = render_campaign_detail_html(
            campaign=_sample_campaign(), campaign_id="b3c1f9d2"
        )
        assert "q2-enterprise-push" in html

    def test_contains_brief(self):
        html = render_campaign_detail_html(
            campaign=_sample_campaign(), campaign_id="b3c1f9d2"
        )
        assert "Warm up enterprise accounts" in html

    def test_contains_core_concept(self):
        html = render_campaign_detail_html(
            campaign=_sample_campaign(), campaign_id="b3c1f9d2"
        )
        assert "hiring signal" in html

    def test_contains_primary_hook(self):
        html = render_campaign_detail_html(
            campaign=_sample_campaign(), campaign_id="b3c1f9d2"
        )
        assert "doubling platform eng headcount" in html

    def test_contains_channels(self):
        html = render_campaign_detail_html(
            campaign=_sample_campaign(), campaign_id="b3c1f9d2"
        )
        assert '<span class="channel-chip"' in html
        assert "email" in html
        assert "linkedin" in html

    def test_contains_created_at(self):
        html = render_campaign_detail_html(
            campaign=_sample_campaign(), campaign_id="b3c1f9d2"
        )
        assert "2026-02-01" in html

    def test_contains_updated_at(self):
        html = render_campaign_detail_html(
            campaign=_sample_campaign(), campaign_id="b3c1f9d2"
        )
        assert "2026-04-15" in html

    def test_missing_slug_omits_row(self):
        c = _sample_campaign()
        c.pop("slug")
        html = render_campaign_detail_html(campaign=c, campaign_id="b3c1f9d2")
        # "Slug" label should not appear when slug is absent
        assert "Slug" not in html

    def test_missing_brief_omits_brief_block(self):
        c = _sample_campaign()
        c.pop("brief")
        html = render_campaign_detail_html(campaign=c, campaign_id="b3c1f9d2")
        assert "Brief" not in html

    def test_narrative_section_omitted_when_all_narrative_empty(self):
        c = _sample_campaign()
        c.pop("brief")
        c.pop("core_concept")
        c.pop("primary_hook")
        html = render_campaign_detail_html(campaign=c, campaign_id="b3c1f9d2")
        assert "narrative-section" not in html

    def test_empty_channels_omits_channels_section(self):
        c = _sample_campaign()
        c["channels"] = []
        html = render_campaign_detail_html(campaign=c, campaign_id="b3c1f9d2")
        assert "channels-section" not in html

    def test_documents_none_omits_docs_section(self):
        html = render_campaign_detail_html(
            campaign=_sample_campaign(),
            campaign_id="b3c1f9d2",
            documents=None,
        )
        assert "docs-section" not in html

    def test_documents_empty_list_still_renders_section_with_empty_message(self):
        html = render_campaign_detail_html(
            campaign=_sample_campaign(),
            campaign_id="b3c1f9d2",
            documents=[],
        )
        assert "docs-section" in html
        assert "No documents generated yet" in html

    def test_documents_populated_renders_tally_chips(self):
        html = render_campaign_detail_html(
            campaign=_sample_campaign(),
            campaign_id="b3c1f9d2",
            documents=[
                {"status": "ready"},
                {"status": "ready"},
                {"status": "generating"},
                {"status": "failed"},
            ],
        )
        assert "Ready: 2" in html
        assert "Generating: 1" in html
        assert "Failed: 1" in html

    def test_documents_other_bucket_rendered(self):
        html = render_campaign_detail_html(
            campaign=_sample_campaign(),
            campaign_id="b3c1f9d2",
            documents=[{"status": "novel"}],
        )
        assert "Other: 1" in html

    def test_docs_footer_links_to_surface_21(self):
        html = render_campaign_detail_html(
            campaign=_sample_campaign(),
            campaign_id="b3c1f9d2",
            documents=[],
        )
        assert "g8://campaigns/b3c1f9d2/documents" in html

    def test_related_surfaces_link_documents(self):
        html = render_campaign_detail_html(
            campaign=_sample_campaign(), campaign_id="b3c1f9d2"
        )
        assert "g8://campaigns/b3c1f9d2/documents" in html

    def test_related_surfaces_link_sequence(self):
        html = render_campaign_detail_html(
            campaign=_sample_campaign(), campaign_id="b3c1f9d2"
        )
        assert "g8://campaigns/b3c1f9d2/sequence" in html

    def test_xss_in_name_escaped(self):
        c = _sample_campaign()
        c["name"] = "<script>alert('xss')</script>"
        html = render_campaign_detail_html(campaign=c, campaign_id="b3c1f9d2")
        assert "<script>alert('xss')</script>" not in html
        assert "&lt;script&gt;" in html

    def test_xss_in_brief_escaped(self):
        c = _sample_campaign()
        c["brief"] = "<img src=x onerror=alert(1)>"
        html = render_campaign_detail_html(campaign=c, campaign_id="b3c1f9d2")
        assert "<img src=x" not in html
        assert "&lt;img" in html

    def test_xss_in_primary_hook_escaped(self):
        c = _sample_campaign()
        c["primary_hook"] = "<svg onload=alert(1)>"
        html = render_campaign_detail_html(campaign=c, campaign_id="b3c1f9d2")
        assert "<svg onload=alert(1)>" not in html
        assert "&lt;svg" in html

    def test_xss_in_slug_escaped(self):
        c = _sample_campaign()
        c["slug"] = "<script>"
        html = render_campaign_detail_html(campaign=c, campaign_id="b3c1f9d2")
        assert "<script>" not in html.split('<title>')[1].split('</title>')[0]  # not in title
        assert "&lt;script&gt;" in html

    def test_xss_in_target_persona_escaped(self):
        c = _sample_campaign()
        c["target_persona"] = "<b>VP</b>"
        html = render_campaign_detail_html(campaign=c, campaign_id="b3c1f9d2")
        assert "<b>VP</b>" not in html
        assert "&lt;b&gt;VP" in html

    def test_channel_overflow_when_too_many(self):
        c = _sample_campaign()
        c["channels"] = ["email", "linkedin", "sms", "phone", "slack", "whatsapp",
                         "twitter", "x", "call", "voice", "task", "other",
                         "extra1", "extra2"]
        html = render_campaign_detail_html(campaign=c, campaign_id="b3c1f9d2")
        # "task", "other", "x", "call", "voice" are all duplicates of each other
        # at the lowercase-trimmed level? No — they're distinct labels.
        # Default cap is 12; after dedup we have 12 unique channels then 2 extras.
        assert "channel-overflow" in html

    def test_campaign_id_in_header(self):
        html = render_campaign_detail_html(
            campaign=_sample_campaign(), campaign_id="b3c1f9d2"
        )
        # The campaign's own id field is used when present, not the URI id
        assert "b3c1f9d2-4f23-4e9c-a8b7-5f18a76e4e22" in html

    def test_uses_uri_id_when_campaign_lacks_id(self):
        c = _sample_campaign()
        c.pop("id")
        html = render_campaign_detail_html(campaign=c, campaign_id="fallback-id")
        assert "fallback-id" in html

    def test_empty_state_for_dict_with_nothing_useful_still_renders(self):
        # non-empty dict with no recognized fields still returns a valid document
        html = render_campaign_detail_html(campaign={"x": "y"}, campaign_id="abc")
        assert "<!DOCTYPE html>" in html
        assert "Campaign" in html  # title / default display name

    def test_name_truncated_when_extremely_long(self):
        c = _sample_campaign()
        c["name"] = "A" * 500
        html = render_campaign_detail_html(campaign=c, campaign_id="b3c1f9d2")
        # Truncation marker ellipsis present
        assert "…" in html

    def test_brief_truncated_when_extremely_long(self):
        c = _sample_campaign()
        c["brief"] = "B" * 5000
        html = render_campaign_detail_html(campaign=c, campaign_id="b3c1f9d2")
        assert "…" in html

    def test_stat_card_for_status_category_goal_channels_docs(self):
        html = render_campaign_detail_html(
            campaign=_sample_campaign(),
            campaign_id="b3c1f9d2",
            documents=[{"status": "ready"}, {"status": "pending"}],
        )
        assert "Status" in html
        assert "Category" in html
        assert "Goal" in html
        assert "Channels" in html
        assert "Documents" in html

    def test_stat_card_docs_shows_ready_over_total(self):
        html = render_campaign_detail_html(
            campaign=_sample_campaign(),
            campaign_id="b3c1f9d2",
            documents=[{"status": "ready"}, {"status": "ready"}, {"status": "pending"}],
        )
        assert "2 / 3" in html


# -----------------------------------------------------------------------
# render_campaign_detail_text_fallback
# -----------------------------------------------------------------------


class TestRenderCampaignDetailTextFallback:
    def test_empty_state_when_campaign_none(self):
        txt = render_campaign_detail_text_fallback(campaign=None, campaign_id="abc")
        assert "# Campaign not available" in txt

    def test_empty_state_when_non_dict(self):
        txt = render_campaign_detail_text_fallback(campaign="string", campaign_id="abc")
        assert "Campaign not available" in txt

    def test_empty_state_includes_id(self):
        txt = render_campaign_detail_text_fallback(campaign=None, campaign_id="abc")
        assert "abc" in txt

    def test_empty_state_suggests_list_campaigns(self):
        txt = render_campaign_detail_text_fallback(campaign=None, campaign_id="abc")
        assert "g8_list_campaigns" in txt

    def test_populated_has_title_heading(self):
        txt = render_campaign_detail_text_fallback(
            campaign=_sample_campaign(), campaign_id="b3c1f9d2"
        )
        assert "# Q2 Enterprise Push" in txt

    def test_populated_has_status_line(self):
        txt = render_campaign_detail_text_fallback(
            campaign=_sample_campaign(), campaign_id="b3c1f9d2"
        )
        assert "Status: **live**" in txt

    def test_populated_has_overview_section(self):
        txt = render_campaign_detail_text_fallback(
            campaign=_sample_campaign(), campaign_id="b3c1f9d2"
        )
        assert "## Overview" in txt
        assert "Category: Outbound" in txt
        assert "Goal: decision" in txt

    def test_populated_has_target_persona(self):
        txt = render_campaign_detail_text_fallback(
            campaign=_sample_campaign(), campaign_id="b3c1f9d2"
        )
        assert "Target persona" in txt

    def test_populated_has_slug(self):
        txt = render_campaign_detail_text_fallback(
            campaign=_sample_campaign(), campaign_id="b3c1f9d2"
        )
        assert "q2-enterprise-push" in txt

    def test_populated_has_channels(self):
        txt = render_campaign_detail_text_fallback(
            campaign=_sample_campaign(), campaign_id="b3c1f9d2"
        )
        assert "## Channels" in txt
        assert "email" in txt
        assert "linkedin" in txt

    def test_populated_has_brief(self):
        txt = render_campaign_detail_text_fallback(
            campaign=_sample_campaign(), campaign_id="b3c1f9d2"
        )
        assert "## Brief" in txt
        assert "Warm up enterprise accounts" in txt

    def test_populated_has_core_concept(self):
        txt = render_campaign_detail_text_fallback(
            campaign=_sample_campaign(), campaign_id="b3c1f9d2"
        )
        assert "## Core concept" in txt

    def test_populated_has_primary_hook(self):
        txt = render_campaign_detail_text_fallback(
            campaign=_sample_campaign(), campaign_id="b3c1f9d2"
        )
        assert "## Primary hook" in txt

    def test_populated_has_drill_in_pointers(self):
        txt = render_campaign_detail_text_fallback(
            campaign=_sample_campaign(), campaign_id="b3c1f9d2"
        )
        assert "g8://campaigns/b3c1f9d2/documents" in txt
        assert "g8://campaigns/b3c1f9d2/sequence" in txt

    def test_documents_section_omitted_when_none(self):
        txt = render_campaign_detail_text_fallback(
            campaign=_sample_campaign(),
            campaign_id="b3c1f9d2",
            documents=None,
        )
        assert "## Documents" not in txt

    def test_documents_section_empty_message(self):
        txt = render_campaign_detail_text_fallback(
            campaign=_sample_campaign(),
            campaign_id="b3c1f9d2",
            documents=[],
        )
        assert "## Documents" in txt
        assert "No documents generated yet" in txt

    def test_documents_section_tally(self):
        txt = render_campaign_detail_text_fallback(
            campaign=_sample_campaign(),
            campaign_id="b3c1f9d2",
            documents=[
                {"status": "ready"},
                {"status": "ready"},
                {"status": "failed"},
            ],
        )
        assert "Total: 3" in txt
        assert "ready: 2" in txt
        assert "failed: 1" in txt

    def test_empty_channels_omits_section(self):
        c = _sample_campaign()
        c["channels"] = []
        txt = render_campaign_detail_text_fallback(campaign=c, campaign_id="b3c1f9d2")
        assert "## Channels" not in txt

    def test_missing_brief_omits_section(self):
        c = _sample_campaign()
        c.pop("brief")
        txt = render_campaign_detail_text_fallback(campaign=c, campaign_id="b3c1f9d2")
        assert "## Brief" not in txt

    def test_trailing_newline(self):
        txt = render_campaign_detail_text_fallback(
            campaign=_sample_campaign(), campaign_id="b3c1f9d2"
        )
        assert txt.endswith("\n")

    def test_no_html_escaping_in_text_fallback(self):
        """Markdown fallback should NOT run html-escape on text content."""
        c = _sample_campaign()
        c["brief"] = "Use < and > freely here"
        txt = render_campaign_detail_text_fallback(campaign=c, campaign_id="b3c1f9d2")
        assert "Use < and > freely here" in txt

    def test_status_unknown_when_missing(self):
        c = _sample_campaign()
        c.pop("status")
        txt = render_campaign_detail_text_fallback(campaign=c, campaign_id="b3c1f9d2")
        assert "Status: **unknown**" in txt

    def test_slug_fallback_display_name(self):
        c = _sample_campaign()
        c.pop("name")
        txt = render_campaign_detail_text_fallback(campaign=c, campaign_id="b3c1f9d2")
        assert "# q2-enterprise-push" in txt
