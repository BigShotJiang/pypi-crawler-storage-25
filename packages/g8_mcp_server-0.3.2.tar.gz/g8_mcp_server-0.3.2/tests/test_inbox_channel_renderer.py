"""Unit tests for Surface #73 — Channel-scoped inbox renderer.

Covers `render_inbox_channel_html` + `render_inbox_channel_text_fallback`
plus every `_inbox_channel_*` helper and the channel-scoped reuse of
the `_seq_inbox_*` helpers (palette / thread rows / stats counts).
"""

from __future__ import annotations

import pytest

from mcp_server.g8_mcp_server.app_renderer import (
    _INBOX_CHANNEL_VALID,
    _MAX_INBOX_CHANNEL_THREADS_RENDERED,
    _inbox_channel_drill_up_html,
    _inbox_channel_empty_state_html,
    _inbox_channel_header_html,
    _inbox_channel_label,
    _inbox_channel_normalize,
    _inbox_channel_overflow_banner_html,
    _inbox_channel_stats_row_html,
    render_inbox_channel_html,
    render_inbox_channel_text_fallback,
)


# ----------------------------------------------------------------- #
# Factories
# ----------------------------------------------------------------- #


def _make_thread(**overrides) -> dict:
    base = {
        "id": "th_abc123",
        "channel": "email",
        "subject": "Re: Hello",
        "contact": {"name": "Alice", "email": "alice@acme.com"},
        "messages": [{"content": "Sure, interested."}],
        "status": "responded",
        "tags": [],
        "assignees": [],
        "created_at": "2026-04-20T10:00:00Z",
        "updated_at": "2026-04-21T09:00:00Z",
    }
    base.update(overrides)
    return base


def _make_threads(n: int, channel: str = "email") -> list:
    return [
        _make_thread(
            id=f"th_{i}",
            channel=channel,
            subject=f"Thread {i}",
            status="open" if i % 2 == 0 else "responded",
        )
        for i in range(n)
    ]


# ----------------------------------------------------------------- #
# _inbox_channel_normalize
# ----------------------------------------------------------------- #


class TestChannelNormalize:
    @pytest.mark.parametrize(
        "raw,expected",
        [
            ("email", "email"),
            ("EMAIL", "email"),
            ("Email", "email"),
            ("  email  ", "email"),
            ("sms", "sms"),
            ("SMS", "sms"),
            ("linkedin", "linkedin"),
            ("LinkedIn", "linkedin"),
            ("heyreach", "linkedin"),
            ("HEYREACH", "linkedin"),
        ],
    )
    def test_valid_channels(self, raw, expected):
        assert _inbox_channel_normalize(raw) == expected

    @pytest.mark.parametrize(
        "raw",
        ["", " ", "garbage", "whatsapp", "unknown", "sms!"],
    )
    def test_invalid_channels(self, raw):
        assert _inbox_channel_normalize(raw) is None

    @pytest.mark.parametrize(
        "raw",
        [None, 42, 3.14, True, [], {}, ["email"]],
    )
    def test_non_string(self, raw):
        assert _inbox_channel_normalize(raw) is None


# ----------------------------------------------------------------- #
# _inbox_channel_label
# ----------------------------------------------------------------- #


class TestChannelLabel:
    @pytest.mark.parametrize(
        "channel,expected",
        [
            ("email", "Email"),
            ("sms", "SMS"),
            ("linkedin", "LinkedIn"),
        ],
    )
    def test_known(self, channel, expected):
        assert _inbox_channel_label(channel) == expected

    def test_unknown_falls_through(self):
        # Non-canonical channel: title-cased.
        assert _inbox_channel_label("telegram") == "Telegram"

    def test_empty(self):
        assert _inbox_channel_label("") == ""


# ----------------------------------------------------------------- #
# _inbox_channel_header_html
# ----------------------------------------------------------------- #


class TestHeader:
    def test_label_in_header(self):
        out = _inbox_channel_header_html("email", 5)
        assert "Email replies" in out
        assert "EMAIL" in out

    def test_thread_count_singular(self):
        out = _inbox_channel_header_html("sms", 1)
        assert "1 thread" in out
        assert "1 threads" not in out

    def test_thread_count_plural(self):
        out = _inbox_channel_header_html("linkedin", 42)
        assert "42 threads" in out

    def test_eyebrow_present(self):
        out = _inbox_channel_header_html("email", 3)
        assert "Channel inbox" in out


# ----------------------------------------------------------------- #
# _inbox_channel_stats_row_html
# ----------------------------------------------------------------- #


class TestStatsRow:
    def test_four_cards(self):
        threads = [
            _make_thread(status="open"),
            _make_thread(status="responded"),
            _make_thread(status="ai_responded"),
            _make_thread(status="responded"),
        ]
        out = _inbox_channel_stats_row_html(threads)
        assert "Total" in out
        assert "Open" in out
        assert "Responded" in out
        assert "AI-responded" in out

    def test_counts_reflected(self):
        threads = [
            _make_thread(status="open"),
            _make_thread(status="open"),
            _make_thread(status="responded"),
        ]
        out = _inbox_channel_stats_row_html(threads)
        # Two opens, one responded.
        assert ">2<" in out
        assert ">1<" in out

    def test_empty(self):
        out = _inbox_channel_stats_row_html([])
        # All zeros.
        assert out.count(">0<") >= 4


# ----------------------------------------------------------------- #
# _inbox_channel_overflow_banner_html
# ----------------------------------------------------------------- #


class TestOverflowBanner:
    def test_no_overflow(self):
        assert _inbox_channel_overflow_banner_html(0, "email") == ""
        assert _inbox_channel_overflow_banner_html(-3, "email") == ""

    def test_singular(self):
        out = _inbox_channel_overflow_banner_html(1, "email")
        assert "1 more thread" in out
        assert "1 more threads" not in out

    def test_plural(self):
        out = _inbox_channel_overflow_banner_html(5, "sms")
        assert "5 more threads" in out

    def test_mentions_backend_url(self):
        out = _inbox_channel_overflow_banner_html(3, "linkedin")
        assert "/inbox?channel=linkedin" in out
        assert "page=2" in out


# ----------------------------------------------------------------- #
# _inbox_channel_drill_up_html
# ----------------------------------------------------------------- #


class TestDrillUp:
    def test_mentions_inbox_dashboard(self):
        out = _inbox_channel_drill_up_html("email")
        assert "g8://inbox/dashboard" in out

    def test_mentions_siblings(self):
        out = _inbox_channel_drill_up_html("email")
        assert "g8://inbox/channels/sms" in out
        assert "g8://inbox/channels/linkedin" in out

    def test_does_not_self_reference(self):
        # Current channel should not appear as its own drill-up link.
        out = _inbox_channel_drill_up_html("email")
        assert "g8://inbox/channels/email" not in out

    def test_backend_filter_pointer(self):
        out = _inbox_channel_drill_up_html("linkedin")
        assert "GET /inbox?channel=linkedin" in out

    def test_related_heading(self):
        out = _inbox_channel_drill_up_html("sms")
        assert "Related surfaces" in out


# ----------------------------------------------------------------- #
# _inbox_channel_empty_state_html
# ----------------------------------------------------------------- #


class TestEmptyState:
    def test_zero_state_accent_tone(self):
        out = _inbox_channel_empty_state_html("email", zero_state=True)
        assert "No Email replies yet" in out
        # Accent tone → contains the primary purple token.
        assert "#7d2df3" in out.lower() or "7d2df3" in out

    def test_unavailable_muted_tone(self):
        out = _inbox_channel_empty_state_html("sms", zero_state=False)
        assert "SMS inbox unavailable" in out
        # Muted tone → contains the border/muted tokens.
        assert "#dfdfdf" in out or "f9f9f9" in out

    def test_empty_channel_fallback_label(self):
        out = _inbox_channel_empty_state_html("", zero_state=False)
        assert "Inbox unavailable" in out


# ----------------------------------------------------------------- #
# render_inbox_channel_html
# ----------------------------------------------------------------- #


class TestRenderHtml:
    def test_valid_channel_with_threads(self):
        threads = _make_threads(5, channel="email")
        out = render_inbox_channel_html(threads=threads, channel="email")
        assert "<!doctype html>" in out.lower()
        assert "Email replies" in out
        assert "5 threads" in out

    def test_valid_channel_empty_threads_zero_state(self):
        out = render_inbox_channel_html(threads=[], channel="sms")
        assert "No SMS replies yet" in out

    def test_valid_channel_none_threads_unavailable(self):
        out = render_inbox_channel_html(threads=None, channel="linkedin")
        assert "LinkedIn inbox unavailable" in out

    def test_invalid_channel(self):
        out = render_inbox_channel_html(threads=[], channel="whatsapp")
        assert "Inbox unavailable" in out or "unavailable" in out.lower()

    def test_heyreach_normalized_in_render(self):
        out = render_inbox_channel_html(threads=[], channel="heyreach")
        assert "No LinkedIn replies yet" in out

    def test_overflow_banner_above_50(self):
        threads = _make_threads(
            _MAX_INBOX_CHANNEL_THREADS_RENDERED + 7, channel="email"
        )
        out = render_inbox_channel_html(threads=threads, channel="email")
        assert "7 more thread" in out

    def test_no_overflow_at_exactly_cap(self):
        threads = _make_threads(
            _MAX_INBOX_CHANNEL_THREADS_RENDERED, channel="email"
        )
        out = render_inbox_channel_html(threads=threads, channel="email")
        assert "more thread" not in out

    def test_non_dict_threads_skipped(self):
        threads = [_make_thread(), "bad", None, _make_thread(), 42]
        out = render_inbox_channel_html(threads=threads, channel="email")
        assert "2 threads" in out

    def test_non_list_threads_coerced(self):
        out = render_inbox_channel_html(threads="bogus", channel="email")
        # non-list → handled gracefully; treated as unavailable since
        # neither a valid list nor None were passed. Accept either
        # empty-state path.
        assert "Email" in out or "unavailable" in out.lower()

    def test_well_formed(self):
        out = render_inbox_channel_html(
            threads=_make_threads(2), channel="email"
        )
        assert "<!doctype html>" in out.lower()
        assert "<body>" in out
        assert "</body></html>" in out


# ----------------------------------------------------------------- #
# Design tokens + no legacy hexes
# ----------------------------------------------------------------- #


class TestDesignTokens:
    def _sample(self) -> str:
        return render_inbox_channel_html(
            threads=_make_threads(3, channel="email"), channel="email"
        )

    def test_primary_present(self):
        assert "#7d2df3" in self._sample().lower()

    def test_border_present(self):
        assert "#dfdfdf" in self._sample()

    def test_font_aeonik(self):
        assert "Aeonik" in self._sample()

    def test_card_radius(self):
        assert "12px" in self._sample()

    def test_no_legacy_studio_hexes(self):
        """Reject the legacy Studio hexes that must never appear."""
        out = self._sample()
        for bad in ("#3730a3", "#eef2ff", "#ff0000"):
            assert bad not in out.lower(), f"legacy hex {bad} leaked"


# ----------------------------------------------------------------- #
# No JS / no dangerous patterns
# ----------------------------------------------------------------- #


class TestNoJs:
    def test_no_script_tags(self):
        out = render_inbox_channel_html(
            threads=_make_threads(3), channel="email"
        )
        assert "<script" not in out.lower()

    def test_no_event_handlers(self):
        out = render_inbox_channel_html(
            threads=_make_threads(3), channel="email"
        )
        # No `onerror=`, `onload=`, `onclick=` unescaped attributes in
        # the rendered markup (user-supplied `onerror=` text may
        # appear as HTML-escaped text content, which is safe).
        # Verify no unescaped `<tag onerror=` or similar.
        import re

        tag_with_handler = re.search(
            r"<[a-z]+[^>]*\son[a-z]+\s*=", out, re.IGNORECASE
        )
        assert tag_with_handler is None


# ----------------------------------------------------------------- #
# XSS escape
# ----------------------------------------------------------------- #


class TestXssEscape:
    def test_xss_in_subject(self):
        threads = [
            _make_thread(subject='<img src=x onerror="alert(1)">'),
        ]
        out = render_inbox_channel_html(threads=threads, channel="email")
        # Tag brackets escaped; the original `<img` raw tag must NOT
        # survive into the output.
        assert "<img" not in out
        assert "&lt;img" in out

    def test_xss_in_channel(self):
        out = render_inbox_channel_html(
            threads=None, channel="<script>alert(1)</script>"
        )
        # Invalid channel → unavailable path; no raw script tag in
        # the output.
        assert "<script>" not in out

    def test_xss_in_contact_name(self):
        threads = [
            _make_thread(
                contact={
                    "name": "<script>alert(1)</script>",
                    "email": "x@x.com",
                }
            )
        ]
        out = render_inbox_channel_html(threads=threads, channel="email")
        assert "<script>" not in out


# ----------------------------------------------------------------- #
# render_inbox_channel_text_fallback
# ----------------------------------------------------------------- #


class TestTextFallback:
    def test_populated(self):
        threads = _make_threads(3, channel="email")
        out = render_inbox_channel_text_fallback(
            threads=threads, channel="email"
        )
        assert "# Email inbox" in out
        assert "## Stats" in out
        assert "## Threads" in out
        assert "## Related surfaces" in out
        assert "<html" not in out.lower()

    def test_zero_state(self):
        out = render_inbox_channel_text_fallback(
            threads=[], channel="sms"
        )
        assert "# SMS inbox" in out
        assert "No SMS replies yet" in out

    def test_unavailable(self):
        out = render_inbox_channel_text_fallback(
            threads=None, channel="linkedin"
        )
        assert "# LinkedIn inbox" in out
        assert "unavailable" in out.lower()

    def test_invalid_channel(self):
        out = render_inbox_channel_text_fallback(
            threads=[], channel="bogus"
        )
        assert "Inbox unavailable" in out
        assert "not a valid inbox channel" in out
        # Lists all valid channels as siblings.
        assert "g8://inbox/channels/email" in out
        assert "g8://inbox/channels/sms" in out
        assert "g8://inbox/channels/linkedin" in out

    def test_heyreach_normalizes_in_text(self):
        out = render_inbox_channel_text_fallback(
            threads=[], channel="heyreach"
        )
        assert "# LinkedIn inbox" in out

    def test_no_self_ref(self):
        out = render_inbox_channel_text_fallback(
            threads=_make_threads(2, channel="email"), channel="email"
        )
        # Email inbox should not self-reference as a drill-up link.
        # Count how many times g8://inbox/channels/email appears — it
        # should appear in the backend filter pointer but NOT as a
        # sibling drill-up.
        # The backend line uses `GET /inbox?channel=email` which does
        # not contain the resource URI, so the URI should only appear
        # in sibling drill-ups (for email as the current channel, zero
        # self-refs expected).
        count = out.count("g8://inbox/channels/email")
        assert count == 0, f"self-ref in text fallback: {out}"

    def test_stats_bullets(self):
        threads = [
            _make_thread(status="open"),
            _make_thread(status="responded"),
            _make_thread(status="ai_responded"),
        ]
        out = render_inbox_channel_text_fallback(
            threads=threads, channel="email"
        )
        assert "- Total: 3" in out
        assert "- Open: 1" in out
        assert "- Responded: 1" in out
        assert "- AI-responded: 1" in out

    def test_overflow_in_text(self):
        threads = _make_threads(
            _MAX_INBOX_CHANNEL_THREADS_RENDERED + 3, channel="email"
        )
        out = render_inbox_channel_text_fallback(
            threads=threads, channel="email"
        )
        assert "+ 3 more thread" in out
        assert "page=2" in out

    def test_xss_plaintext(self):
        threads = [_make_thread(subject="<script>alert(1)</script>")]
        out = render_inbox_channel_text_fallback(
            threads=threads, channel="email"
        )
        # Plain text: tag stays as literal text (not an active script).
        # We just verify no HTML-wrapped tag is present.
        assert "<html" not in out.lower()


# ----------------------------------------------------------------- #
# Smoke
# ----------------------------------------------------------------- #


class TestSmoke:
    def test_html_roundtrip(self):
        threads = _make_threads(8, channel="email")
        out = render_inbox_channel_html(threads=threads, channel="email")
        assert len(out) > 1000
        assert "<!doctype html>" in out.lower()

    def test_text_roundtrip(self):
        threads = _make_threads(8, channel="sms")
        out = render_inbox_channel_text_fallback(
            threads=threads, channel="sms"
        )
        assert len(out) > 200
        assert "# SMS inbox" in out


# ----------------------------------------------------------------- #
# Channel constants sanity
# ----------------------------------------------------------------- #


class TestConstants:
    def test_valid_set(self):
        assert set(_INBOX_CHANNEL_VALID) == {"email", "sms", "linkedin"}

    def test_cap_positive(self):
        assert _MAX_INBOX_CHANNEL_THREADS_RENDERED > 0
