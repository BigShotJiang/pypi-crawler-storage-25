"""Unit tests for the Surface #66 copilot-home renderer.

Covers the hub layout (header / entry quadrant / explore grid / optional
recent-activity / suggested prompts) plus token regressions (graph8
palette only, no legacy hexes, no single-side colored accent borders on
accent palette, no inline JS).
"""

from __future__ import annotations

import re

import pytest

from mcp_server.g8_mcp_server import app_renderer as ar


# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------


_SAMPLE_ACTIVITIES = [
    {
        "kind": "email_sent",
        "subject": "Q2 kickoff outreach",
        "created_at": "2026-04-20T10:00:00Z",
    },
    {
        "kind": "reply_received",
        "subject": "Re: Q2 kickoff outreach",
        "created_at": "2026-04-20T11:30:00Z",
    },
    {
        "kind": "meeting_booked",
        "title": "Demo with Acme",
        "timestamp": "2026-04-20T14:00:00Z",
    },
]

# Legacy hex palette that must NEVER appear in Surface #66 (or any born
# graph8-native surface shipped from Surface #36 onward).
_LEGACY_STUDIO_HEXES = [
    "#eef2ff",
    "#4338ca",
    "#f59e0b",
    "#166534",
    "#a16207",
    "#7c2d12",
    "#6b7280",
]


# ---------------------------------------------------------------------------
# _copilot_home_clip
# ---------------------------------------------------------------------------


class TestClip:
    def test_none(self):
        assert ar._copilot_home_clip(None, 100) == ""

    def test_non_string(self):
        assert ar._copilot_home_clip(42, 100) == ""

    def test_whitespace(self):
        assert ar._copilot_home_clip("   ", 100) == ""

    def test_under_cap(self):
        assert ar._copilot_home_clip("hi", 100) == "hi"

    def test_over_cap(self):
        out = ar._copilot_home_clip("hello world", 5)
        assert out.endswith("…")
        assert len(out) == 5

    def test_no_escape(self):
        # Callers escape — clip must not double-escape.
        assert ar._copilot_home_clip("<script>", 100) == "<script>"


# ---------------------------------------------------------------------------
# _copilot_home_format_datetime
# ---------------------------------------------------------------------------


class TestFormatDatetime:
    def test_none(self):
        assert ar._copilot_home_format_datetime(None) == ""

    def test_empty(self):
        assert ar._copilot_home_format_datetime("") == ""

    def test_iso_utc(self):
        out = ar._copilot_home_format_datetime("2026-04-20T10:00:00Z")
        assert out == "2026-04-20 10:00"

    def test_iso_offset(self):
        out = ar._copilot_home_format_datetime("2026-04-20T10:00:00+00:00")
        assert out == "2026-04-20 10:00"

    def test_garbage(self):
        assert ar._copilot_home_format_datetime("not-a-date") == ""

    def test_non_string(self):
        assert ar._copilot_home_format_datetime(12345) == ""


# ---------------------------------------------------------------------------
# _copilot_home_entry_card
# ---------------------------------------------------------------------------


class TestEntryCard:
    def test_primary(self):
        out = ar._copilot_home_entry_card(
            "Campaigns", "Build", "g8://campaigns/dashboard", "desc",
            accent="primary",
        )
        assert ar._G8_PRIMARY in out
        assert ar._G8_ACCENT_BG in out
        assert "g8://campaigns/dashboard" in out

    def test_positive(self):
        out = ar._copilot_home_entry_card(
            "Contacts", "Grow", "g8://contacts/dashboard", "desc",
            accent="positive",
        )
        assert ar._G8_POSITIVE_FG in out
        assert ar._G8_POSITIVE_BG in out

    def test_default(self):
        out = ar._copilot_home_entry_card(
            "Inbox", "Reply", "g8://inbox/dashboard", "desc",
            accent="default",
        )
        assert ar._G8_MUTED_BG in out

    def test_escape(self):
        out = ar._copilot_home_entry_card(
            "<evil>", "<script>", "g8://x", "<img>",
            accent="primary",
        )
        assert "<evil>" not in out.split("<code")[0]
        assert "&lt;evil&gt;" in out
        assert "&lt;script&gt;" in out


# ---------------------------------------------------------------------------
# _copilot_home_explore_item
# ---------------------------------------------------------------------------


class TestExploreItem:
    def test_basic(self):
        out = ar._copilot_home_explore_item("g8://contacts/dashboard", "Grid of contacts")
        assert "g8://contacts/dashboard" in out
        assert "Grid of contacts" in out
        assert "<li" in out

    def test_escape(self):
        out = ar._copilot_home_explore_item("g8://x", "<script>alert(1)</script>")
        assert "<script>alert(1)</script>" not in out
        assert "&lt;script&gt;" in out


# ---------------------------------------------------------------------------
# _copilot_home_explore_section
# ---------------------------------------------------------------------------


class TestExploreSection:
    def test_empty(self):
        out = ar._copilot_home_explore_section("Build", [])
        assert out == ""

    def test_basic(self):
        out = ar._copilot_home_explore_section(
            "Build",
            [("g8://campaigns/ideas", "AI ideas"), ("g8://personas/dashboard", "Buyers")],
        )
        assert "Build" in out
        assert "g8://campaigns/ideas" in out
        assert "g8://personas/dashboard" in out

    def test_title_escaped(self):
        out = ar._copilot_home_explore_section(
            "<evil>",
            [("g8://x", "y")],
        )
        assert "<evil>" not in out.split("g8://x")[0]
        assert "&lt;evil&gt;" in out


# ---------------------------------------------------------------------------
# _copilot_home_activity_row
# ---------------------------------------------------------------------------


class TestActivityRow:
    def test_basic(self):
        out = ar._copilot_home_activity_row(_SAMPLE_ACTIVITIES[0])
        assert "email_sent" in out
        assert "Q2 kickoff outreach" in out
        assert "2026-04-20 10:00" in out

    def test_title_fallback(self):
        # When "subject" is missing, fall through to "title".
        out = ar._copilot_home_activity_row(_SAMPLE_ACTIVITIES[2])
        assert "meeting_booked" in out
        assert "Demo with Acme" in out

    def test_non_dict(self):
        assert ar._copilot_home_activity_row(None) == ""
        assert ar._copilot_home_activity_row("str") == ""
        assert ar._copilot_home_activity_row([1, 2]) == ""

    def test_missing_kind_fallback(self):
        out = ar._copilot_home_activity_row({"subject": "hello"})
        assert "activity" in out  # fallback

    def test_missing_subject_silent(self):
        out = ar._copilot_home_activity_row({"kind": "signal", "created_at": "2026-04-20T09:00:00Z"})
        # Still renders the kind chip + ts, just no subject span.
        assert "signal" in out
        assert "2026-04-20 09:00" in out

    def test_missing_ts_silent(self):
        out = ar._copilot_home_activity_row({"kind": "signal", "subject": "hi"})
        assert "signal" in out
        assert "hi" in out

    def test_escape_kind(self):
        out = ar._copilot_home_activity_row({"kind": "<evil>", "subject": "ok"})
        assert "<evil>" not in out
        assert "&lt;evil&gt;" in out

    def test_escape_subject(self):
        out = ar._copilot_home_activity_row({"kind": "ok", "subject": "<script>alert(1)</script>"})
        assert "<script>alert(1)</script>" not in out
        assert "&lt;script&gt;" in out


# ---------------------------------------------------------------------------
# _copilot_home_activity_section
# ---------------------------------------------------------------------------


class TestActivitySection:
    def test_none(self):
        assert ar._copilot_home_activity_section(None) == ""

    def test_empty_list(self):
        assert ar._copilot_home_activity_section([]) == ""

    def test_all_non_dict(self):
        assert ar._copilot_home_activity_section([None, "s", 42]) == ""

    def test_basic(self):
        out = ar._copilot_home_activity_section(_SAMPLE_ACTIVITIES)
        assert "Recent activity" in out
        assert "email_sent" in out
        assert "meeting_booked" in out

    def test_cap_at_max(self):
        # Force 15 activities — renderer should cap at 10.
        many = [{"kind": f"k{i}", "subject": f"s{i}"} for i in range(15)]
        out = ar._copilot_home_activity_section(many)
        for i in range(10):
            assert f"k{i}" in out
        for i in range(10, 15):
            assert f"k{i}" not in out


# ---------------------------------------------------------------------------
# _copilot_home_prompt_card
# ---------------------------------------------------------------------------


class TestPromptCard:
    def test_basic(self):
        out = ar._copilot_home_prompt_card("Draft outreach", "Helps with outreach")
        assert "Draft outreach" in out
        assert "Helps with outreach" in out

    def test_escape(self):
        out = ar._copilot_home_prompt_card("<evil>", "<script>")
        assert "<evil>" not in out
        assert "<script>" not in out
        assert "&lt;evil&gt;" in out
        assert "&lt;script&gt;" in out


# ---------------------------------------------------------------------------
# render_copilot_home_html
# ---------------------------------------------------------------------------


class TestRenderHtml:
    def test_no_activities(self):
        out = ar.render_copilot_home_html()
        assert "<!DOCTYPE html>" in out
        assert "<html>" in out
        assert "<head>" in out
        assert "<body" in out

    def test_welcome_header(self):
        out = ar.render_copilot_home_html()
        assert "Welcome" in out
        # Eyebrow label
        assert "Copilot home" in out or "Copilot Home" in out

    def test_entry_cards(self):
        out = ar.render_copilot_home_html()
        assert "g8://campaigns/dashboard" in out
        assert "g8://contacts/dashboard" in out
        assert "g8://inbox/dashboard" in out
        assert "g8://deals/dashboard" in out

    def test_explore_build_section(self):
        out = ar.render_copilot_home_html()
        assert "Build" in out
        assert "g8://campaigns/ideas" in out
        assert "g8://personas/dashboard" in out
        assert "g8://icps/dashboard" in out
        assert "g8://global-context/library" in out
        assert "g8://kb/library" in out

    def test_explore_run_section(self):
        out = ar.render_copilot_home_html()
        assert "Run" in out
        assert "g8://sequences/dashboard" in out
        assert "g8://lists/dashboard" in out
        assert "g8://audience-syncs/dashboard" in out
        assert "g8://crm-syncs/dashboard" in out
        assert "g8://webhooks" in out

    def test_explore_monitor_section(self):
        out = ar.render_copilot_home_html()
        assert "Monitor" in out
        assert "g8://activities/feed" in out
        assert "g8://tasks/dashboard" in out
        assert "g8://pipelines/overview" in out
        assert "g8://repos/dashboard" in out

    def test_explore_context_section(self):
        out = ar.render_copilot_home_html()
        assert "Context" in out
        assert "g8://fields/contacts" in out
        assert "g8://fields/companies" in out
        assert "g8://snippet/install" in out
        assert "g8://snippet/form" in out

    def test_no_activity_section_when_empty(self):
        out = ar.render_copilot_home_html()
        assert "Recent activity" not in out

    def test_activity_section_when_provided(self):
        out = ar.render_copilot_home_html(activities=_SAMPLE_ACTIVITIES)
        assert "Recent activity" in out
        assert "email_sent" in out
        assert "Q2 kickoff outreach" in out
        assert "meeting_booked" in out

    def test_prompts_section(self):
        out = ar.render_copilot_home_html()
        assert "Ask the copilot" in out
        assert "Draft an outreach sequence" in out
        assert "Summarize unread replies" in out

    def test_no_javascript(self):
        out = ar.render_copilot_home_html(activities=_SAMPLE_ACTIVITIES)
        assert "<script" not in out
        assert "javascript:" not in out
        assert "onerror=" not in out
        assert "onclick=" not in out

    def test_no_legacy_accent_hexes(self):
        out = ar.render_copilot_home_html(activities=_SAMPLE_ACTIVITIES)
        for legacy in _LEGACY_STUDIO_HEXES:
            assert legacy.lower() not in out.lower(), (
                f"legacy hex {legacy} leaked into copilot home"
            )

    def test_uses_graph8_primary(self):
        out = ar.render_copilot_home_html()
        assert ar._G8_PRIMARY in out

    def test_uses_graph8_border(self):
        out = ar.render_copilot_home_html()
        assert ar._G8_BORDER in out

    def test_uses_aeonik(self):
        out = ar.render_copilot_home_html()
        assert "Aeonik" in out

    def test_no_single_side_colored_accent_border(self):
        # Detail: single-side borders are fine for dividers (neutral
        # colors). But a single-side border in an accent palette color
        # would read as an "AI-tell" colored accent — banned.
        out = ar.render_copilot_home_html(activities=_SAMPLE_ACTIVITIES)
        accent_palette = [
            ar._G8_PRIMARY,
            ar._G8_POSITIVE_FG,
            ar._G8_WARNING_FG,
        ]
        for color in accent_palette:
            # Match patterns like "border-top:1px solid #7d2df3" (single
            # side) but NOT "border:1px solid #7d2df3" (all sides).
            pattern = re.compile(
                r"border-(?:top|right|bottom|left):[^;\"]*"
                + re.escape(color),
                re.IGNORECASE,
            )
            assert not pattern.search(out), (
                f"single-side colored accent border using {color} detected"
            )

    def test_xss_activity_kind(self):
        acts = [{"kind": "<script>alert(1)</script>", "subject": "hi", "created_at": "2026-04-20T10:00:00Z"}]
        out = ar.render_copilot_home_html(activities=acts)
        assert "<script>alert(1)</script>" not in out
        assert "&lt;script&gt;" in out

    def test_xss_activity_subject(self):
        acts = [{"kind": "email", "subject": "<img src=x onerror=alert(1)>", "created_at": "2026-04-20T10:00:00Z"}]
        out = ar.render_copilot_home_html(activities=acts)
        # Raw tag form must not appear — tag brackets must be escaped so the
        # payload is inert text, not an executable element.
        assert "<img src=x" not in out
        assert "&lt;img src=x onerror=alert(1)&gt;" in out

    def test_html_has_doctype(self):
        out = ar.render_copilot_home_html()
        assert out.startswith("<!DOCTYPE html>")

    def test_html_well_formed(self):
        out = ar.render_copilot_home_html(activities=_SAMPLE_ACTIVITIES)
        assert out.count("<html>") == out.count("</html>") == 1
        assert out.count("<body") == out.count("</body>") == 1
        assert out.count("<head>") == out.count("</head>") == 1

    def test_activities_capped_in_render(self):
        many = [{"kind": f"k{i}", "subject": f"sub{i}", "created_at": "2026-04-20T10:00:00Z"} for i in range(15)]
        out = ar.render_copilot_home_html(activities=many)
        for i in range(10):
            assert f"sub{i}" in out
        for i in range(10, 15):
            assert f"sub{i}" not in out


# ---------------------------------------------------------------------------
# render_copilot_home_text_fallback
# ---------------------------------------------------------------------------


class TestTextFallback:
    def test_basic(self):
        out = ar.render_copilot_home_text_fallback()
        assert out.startswith("# Copilot Home")
        assert "g8://campaigns/dashboard" in out

    def test_entry_points_section(self):
        out = ar.render_copilot_home_text_fallback()
        assert "## Entry points" in out
        assert "g8://contacts/dashboard" in out
        assert "g8://inbox/dashboard" in out
        assert "g8://deals/dashboard" in out

    def test_explore_sections(self):
        out = ar.render_copilot_home_text_fallback()
        assert "## Explore — Build" in out
        assert "## Explore — Run" in out
        assert "## Explore — Monitor" in out
        assert "## Explore — Context" in out

    def test_no_activity_when_empty(self):
        out = ar.render_copilot_home_text_fallback()
        assert "## Recent activity" not in out

    def test_activity_section_when_provided(self):
        out = ar.render_copilot_home_text_fallback(activities=_SAMPLE_ACTIVITIES)
        assert "## Recent activity" in out
        assert "email_sent" in out
        assert "Q2 kickoff outreach" in out

    def test_prompts_section(self):
        out = ar.render_copilot_home_text_fallback()
        assert "## Ask the copilot" in out
        assert "Draft an outreach sequence" in out

    def test_no_html(self):
        out = ar.render_copilot_home_text_fallback(activities=_SAMPLE_ACTIVITIES)
        assert "<" not in out
        assert "<!DOCTYPE" not in out

    def test_xss_plaintext(self):
        # Plaintext renderer does not HTML-escape — the raw value
        # flows through. We only verify the plaintext doesn't contain
        # HTML structural tags we'd render.
        acts = [{"kind": "<script>", "subject": "<img>", "created_at": "2026-04-20T10:00:00Z"}]
        out = ar.render_copilot_home_text_fallback(activities=acts)
        # Raw values preserved as plain text
        assert "<script>" in out  # plaintext — not escaped (no HTML)
        assert "<img>" in out

    def test_trailing_newline(self):
        out = ar.render_copilot_home_text_fallback()
        assert out.endswith("\n")


# ---------------------------------------------------------------------------
# Smoke tests — lightweight roundtrip
# ---------------------------------------------------------------------------


class TestSmoke:
    def test_roundtrip_without_activities(self):
        html_out = ar.render_copilot_home_html()
        text_out = ar.render_copilot_home_text_fallback()
        assert len(html_out) > 1000
        assert len(text_out) > 200

    def test_roundtrip_with_activities(self):
        html_out = ar.render_copilot_home_html(activities=_SAMPLE_ACTIVITIES)
        text_out = ar.render_copilot_home_text_fallback(activities=_SAMPLE_ACTIVITIES)
        assert "Recent activity" in html_out
        assert "Recent activity" in text_out
