"""Unit tests for Surface #68 — `render_activity_detail_html` / text fallback.

Per-activity detail: `g8://activities/{activity_id}` (+ `.txt` sibling).
Mirrors the structure of test_task_detail_renderer.py (Surface #67).

graph8-native design: only `_G8_*` tokens — no Studio legacy hexes.
"""

from __future__ import annotations

import re

import pytest

from mcp_server.g8_mcp_server import app_renderer as ar


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


_ACTIVITY_ID = "act_7e1a8c42aaaa4bbb8ccc"


_SAMPLE_ACTIVITY: dict = {
    "id": _ACTIVITY_ID,
    "activity_type": "call",
    "activity_subtype": "discovery",
    "subject": "Discovery call with Acme Q2 champion",
    "description": (
        "Thomas mentioned wanting to extend the contract.\n"
        "Ask about stakeholder changes.\n\n"
        "- Is Sarah still the decision-maker?\n"
        "- What's the expected close date?"
    ),
    "activity_date": "2026-04-18T14:22:00Z",
    "duration_minutes": 45,
    "status": "completed",
    "outcome": "connected",
    "next_steps": "Send proposal by Friday; loop in Sarah on pricing.",
    "owner_id": "user_usjid",
    "owner_name": "Usjid Iqbal",
    "company_id": "99",
    "contact_id": "42",
    "deal_id": "7",
    "source": "manual",
    "external_id": "ext_xyz_789",
}


_LEGACY_STUDIO_HEXES = (
    "#eef2ff",
    "#4338ca",
    "#f59e0b",
    "#166534",
    "#a16207",
    "#7c2d12",
    "#6b7280",
)


# ---------------------------------------------------------------------------
# _activity_detail_clip
# ---------------------------------------------------------------------------


class TestClip:
    def test_none(self):
        assert ar._activity_detail_clip(None, 100) == ""

    def test_non_string(self):
        assert ar._activity_detail_clip(123, 100) == ""

    def test_whitespace(self):
        assert ar._activity_detail_clip("   \n\t  ", 100) == ""

    def test_under_cap(self):
        assert ar._activity_detail_clip("short", 100) == "short"

    def test_over_cap(self):
        out = ar._activity_detail_clip("a" * 200, 50)
        assert len(out) <= 50
        assert out.endswith("…")

    def test_no_escape(self):
        """Clip does NOT escape — callers escape. Avoids double-escape."""
        assert ar._activity_detail_clip("<script>", 100) == "<script>"


# ---------------------------------------------------------------------------
# _activity_detail_subject
# ---------------------------------------------------------------------------


class TestSubject:
    def test_from_subject(self):
        out = ar._activity_detail_subject({"subject": "Discovery call"}, "a-1")
        assert out == "Discovery call"

    def test_none_activity(self):
        out = ar._activity_detail_subject(None, "a-1")
        assert "Activity #a-1" in out

    def test_none_activity_no_id(self):
        out = ar._activity_detail_subject(None, "")
        assert out == "Activity"

    def test_missing_subject(self):
        out = ar._activity_detail_subject({"id": "x"}, "a-1")
        assert "Activity #a-1" in out

    def test_whitespace_subject(self):
        out = ar._activity_detail_subject({"subject": "   "}, "a-1")
        assert "Activity #a-1" in out

    def test_non_string_subject(self):
        out = ar._activity_detail_subject({"subject": 123}, "a-1")
        assert "Activity #a-1" in out

    def test_escape(self):
        out = ar._activity_detail_subject(
            {"subject": "<script>alert(1)</script>"}, "x"
        )
        assert "<script>" not in out
        assert "&lt;script&gt;" in out

    def test_clip(self):
        out = ar._activity_detail_subject({"subject": "A" * 500}, "x")
        assert len(out) < 500
        assert out.endswith("…")

    def test_fallback_id_escaped(self):
        out = ar._activity_detail_subject(None, "<evil>")
        assert "<evil>" not in out
        assert "&lt;evil&gt;" in out


# ---------------------------------------------------------------------------
# _activity_detail_id_matches
# ---------------------------------------------------------------------------


class TestIdMatches:
    def test_match(self):
        assert ar._activity_detail_id_matches({"id": "a-1"}, "a-1") is True

    def test_mismatch(self):
        assert ar._activity_detail_id_matches({"id": "a-1"}, "a-2") is False

    def test_none_doc_lenient(self):
        assert ar._activity_detail_id_matches(None, "a-1") is True

    def test_non_dict_lenient(self):
        assert ar._activity_detail_id_matches("not-a-dict", "a-1") is True

    def test_missing_id_lenient(self):
        assert ar._activity_detail_id_matches({}, "a-1") is True

    def test_whitespace_in_uri(self):
        assert ar._activity_detail_id_matches({"id": "a-1"}, " a-1 ") is True


# ---------------------------------------------------------------------------
# _activity_detail_type_accent
# ---------------------------------------------------------------------------


class TestTypeAccent:
    def test_none(self):
        bg, fg, _ = ar._activity_detail_type_accent(None)
        assert bg == ar._G8_MUTED_BG

    def test_call_primary(self):
        bg, fg, _ = ar._activity_detail_type_accent("call")
        assert bg == ar._G8_ACCENT_BG
        assert fg == ar._G8_PRIMARY

    def test_email_primary(self):
        bg, fg, _ = ar._activity_detail_type_accent("email")
        assert fg == ar._G8_PRIMARY

    def test_message_primary(self):
        bg, fg, _ = ar._activity_detail_type_accent("message")
        assert fg == ar._G8_PRIMARY

    def test_meeting_positive(self):
        bg, fg, _ = ar._activity_detail_type_accent("meeting")
        assert bg == ar._G8_POSITIVE_BG
        assert fg == ar._G8_POSITIVE_FG

    def test_demo_positive(self):
        bg, fg, _ = ar._activity_detail_type_accent("demo")
        assert fg == ar._G8_POSITIVE_FG

    def test_appointment_positive(self):
        bg, fg, _ = ar._activity_detail_type_accent("appointment")
        assert fg == ar._G8_POSITIVE_FG

    def test_note_muted(self):
        bg, fg, _ = ar._activity_detail_type_accent("note")
        assert bg == ar._G8_MUTED_BG
        assert fg == ar._G8_TEXT_MUTED

    def test_task_default(self):
        bg, fg, _ = ar._activity_detail_type_accent("task")
        assert bg == ar._G8_CARD_BG

    def test_unknown_muted(self):
        bg, fg, _ = ar._activity_detail_type_accent("weird_type")
        assert bg == ar._G8_MUTED_BG

    def test_case_insensitive(self):
        assert (
            ar._activity_detail_type_accent("CALL")
            == ar._activity_detail_type_accent("call")
        )

    def test_whitespace(self):
        bg, _, _ = ar._activity_detail_type_accent("   ")
        assert bg == ar._G8_MUTED_BG

    def test_non_string(self):
        bg, _, _ = ar._activity_detail_type_accent(42)
        assert bg == ar._G8_MUTED_BG


# ---------------------------------------------------------------------------
# _activity_detail_outcome_accent
# ---------------------------------------------------------------------------


class TestOutcomeAccent:
    def test_none(self):
        bg, fg, _ = ar._activity_detail_outcome_accent(None)
        assert bg == ar._G8_MUTED_BG

    def test_connected_positive(self):
        bg, fg, _ = ar._activity_detail_outcome_accent("connected")
        assert fg == ar._G8_POSITIVE_FG

    def test_booked_positive(self):
        bg, fg, _ = ar._activity_detail_outcome_accent("booked")
        assert fg == ar._G8_POSITIVE_FG

    def test_won_positive(self):
        bg, fg, _ = ar._activity_detail_outcome_accent("won")
        assert fg == ar._G8_POSITIVE_FG

    def test_no_answer_warning(self):
        bg, fg, _ = ar._activity_detail_outcome_accent("no_answer")
        assert bg == ar._G8_WARNING_BG
        assert fg == ar._G8_WARNING_FG

    def test_voicemail_warning(self):
        bg, fg, _ = ar._activity_detail_outcome_accent("voicemail")
        assert fg == ar._G8_WARNING_FG

    def test_bounced_warning(self):
        bg, fg, _ = ar._activity_detail_outcome_accent("bounced")
        assert fg == ar._G8_WARNING_FG

    def test_lost_warning_not_destructive(self):
        """Lost is negative but we use warning amber — not destructive red."""
        bg, fg, _ = ar._activity_detail_outcome_accent("lost")
        assert fg == ar._G8_WARNING_FG
        assert fg != ar._G8_DESTRUCTIVE_FG

    def test_disqualified_warning(self):
        bg, fg, _ = ar._activity_detail_outcome_accent("disqualified")
        assert fg == ar._G8_WARNING_FG

    def test_unknown_muted(self):
        bg, fg, _ = ar._activity_detail_outcome_accent("weird_outcome")
        assert bg == ar._G8_MUTED_BG

    def test_case_insensitive(self):
        assert (
            ar._activity_detail_outcome_accent("CONNECTED")
            == ar._activity_detail_outcome_accent("connected")
        )


# ---------------------------------------------------------------------------
# _activity_detail_status_accent
# ---------------------------------------------------------------------------


class TestStatusAccent:
    def test_none(self):
        bg, fg, _ = ar._activity_detail_status_accent(None)
        assert bg == ar._G8_MUTED_BG

    def test_completed_positive(self):
        bg, fg, _ = ar._activity_detail_status_accent("completed")
        assert fg == ar._G8_POSITIVE_FG

    def test_done_positive(self):
        bg, fg, _ = ar._activity_detail_status_accent("done")
        assert fg == ar._G8_POSITIVE_FG

    def test_pending_primary(self):
        bg, fg, _ = ar._activity_detail_status_accent("pending")
        assert fg == ar._G8_PRIMARY

    def test_scheduled_primary(self):
        bg, fg, _ = ar._activity_detail_status_accent("scheduled")
        assert fg == ar._G8_PRIMARY

    def test_cancelled_muted(self):
        bg, fg, _ = ar._activity_detail_status_accent("cancelled")
        assert fg == ar._G8_TEXT_MUTED

    def test_archived_muted(self):
        bg, fg, _ = ar._activity_detail_status_accent("archived")
        assert fg == ar._G8_TEXT_MUTED

    def test_unknown_muted(self):
        bg, fg, _ = ar._activity_detail_status_accent("weird_status")
        assert bg == ar._G8_MUTED_BG

    def test_case_insensitive(self):
        assert (
            ar._activity_detail_status_accent("COMPLETED")
            == ar._activity_detail_status_accent("completed")
        )


# ---------------------------------------------------------------------------
# _activity_detail_parse_duration
# ---------------------------------------------------------------------------


class TestParseDuration:
    def test_none(self):
        assert ar._activity_detail_parse_duration(None) is None

    def test_int(self):
        assert ar._activity_detail_parse_duration(45) == 45

    def test_float(self):
        assert ar._activity_detail_parse_duration(45.5) == 45

    def test_str_numeric(self):
        assert ar._activity_detail_parse_duration("45") == 45

    def test_str_whitespace(self):
        assert ar._activity_detail_parse_duration(" 45 ") == 45

    def test_str_garbage(self):
        assert ar._activity_detail_parse_duration("abc") is None

    def test_negative(self):
        assert ar._activity_detail_parse_duration(-5) is None

    def test_negative_str(self):
        assert ar._activity_detail_parse_duration("-5") is None

    def test_zero(self):
        assert ar._activity_detail_parse_duration(0) == 0

    def test_bool_rejected(self):
        """bool is an int in Python — True would otherwise parse as 1."""
        assert ar._activity_detail_parse_duration(True) is None
        assert ar._activity_detail_parse_duration(False) is None

    def test_list_rejected(self):
        assert ar._activity_detail_parse_duration([45]) is None


# ---------------------------------------------------------------------------
# _activity_detail_format_duration
# ---------------------------------------------------------------------------


class TestFormatDuration:
    def test_none(self):
        assert ar._activity_detail_format_duration(None) == ""

    def test_zero(self):
        assert ar._activity_detail_format_duration(0) == "0m"

    def test_minutes_only(self):
        assert ar._activity_detail_format_duration(45) == "45m"

    def test_exact_hour(self):
        assert ar._activity_detail_format_duration(60) == "1h"

    def test_hour_and_minutes(self):
        assert ar._activity_detail_format_duration(90) == "1h 30m"

    def test_two_hours(self):
        assert ar._activity_detail_format_duration(120) == "2h"

    def test_two_hours_fifteen(self):
        assert ar._activity_detail_format_duration(135) == "2h 15m"


# ---------------------------------------------------------------------------
# _activity_detail_format_datetime
# ---------------------------------------------------------------------------


class TestFormatDatetime:
    def test_none(self):
        assert ar._activity_detail_format_datetime(None) == ""

    def test_empty(self):
        assert ar._activity_detail_format_datetime("") == ""

    def test_iso_utc(self):
        out = ar._activity_detail_format_datetime("2026-04-18T14:22:00Z")
        assert out == "2026-04-18 14:22"

    def test_iso_with_tz(self):
        out = ar._activity_detail_format_datetime("2026-04-18T14:22:00+00:00")
        assert out == "2026-04-18 14:22"

    def test_garbage(self):
        assert ar._activity_detail_format_datetime("not-a-date") == ""

    def test_non_string(self):
        assert ar._activity_detail_format_datetime(12345) == ""


# ---------------------------------------------------------------------------
# _activity_detail_chip
# ---------------------------------------------------------------------------


class TestChip:
    def test_basic(self):
        out = ar._activity_detail_chip("CALL")
        assert "CALL" in out
        assert "<span" in out

    def test_escape(self):
        out = ar._activity_detail_chip("<script>")
        assert "<script>" not in out
        assert "&lt;script&gt;" in out


# ---------------------------------------------------------------------------
# _activity_detail_kpi_card
# ---------------------------------------------------------------------------


class TestKpiCard:
    def test_default(self):
        out = ar._activity_detail_kpi_card("Duration", "45m")
        assert "Duration" in out
        assert "45m" in out
        assert ar._G8_CARD_BG in out

    def test_primary(self):
        out = ar._activity_detail_kpi_card("Duration", "45m", accent="primary")
        assert ar._G8_PRIMARY in out
        assert ar._G8_ACCENT_BG in out

    def test_warning(self):
        out = ar._activity_detail_kpi_card("Outcome", "lost", accent="warning")
        assert ar._G8_WARNING_BG in out
        assert ar._G8_WARNING_FG in out

    def test_positive(self):
        out = ar._activity_detail_kpi_card("Outcome", "won", accent="positive")
        assert ar._G8_POSITIVE_BG in out
        assert ar._G8_POSITIVE_FG in out

    def test_muted(self):
        out = ar._activity_detail_kpi_card("Owner", "—", accent="muted")
        assert ar._G8_MUTED_BG in out
        assert ar._G8_TEXT_MUTED in out


# ---------------------------------------------------------------------------
# _activity_detail_text_block
# ---------------------------------------------------------------------------


class TestTextBlock:
    def test_none(self):
        assert ar._activity_detail_text_block("Description", None, cap=100) == ""

    def test_non_string(self):
        assert ar._activity_detail_text_block("Description", 123, cap=100) == ""

    def test_whitespace(self):
        assert ar._activity_detail_text_block("Description", "    ", cap=100) == ""

    def test_short(self):
        out = ar._activity_detail_text_block("Description", "Short body", cap=100)
        assert "Short body" in out
        # Label text itself is not uppercased in HTML; CSS text-transform handles display.
        assert "Description" in out
        assert "text-transform:uppercase" in out

    def test_multi_line(self):
        out = ar._activity_detail_text_block(
            "Description", "line1\nline2", cap=100
        )
        assert "<br>" in out

    def test_escape_first(self):
        out = ar._activity_detail_text_block("Description", "<evil>", cap=100)
        assert "<evil>" not in out
        assert "&lt;evil&gt;" in out

    def test_clip_at_cap(self):
        out = ar._activity_detail_text_block("Description", "x" * 1000, cap=50)
        assert "…" in out


# ---------------------------------------------------------------------------
# _activity_detail_metadata_section
# ---------------------------------------------------------------------------


class TestMetadataSection:
    def test_empty(self):
        assert ar._activity_detail_metadata_section([]) == ""

    def test_basic(self):
        out = ar._activity_detail_metadata_section([("Source", "manual")])
        assert "Source" in out
        assert "manual" in out
        assert "Details" in out


# ---------------------------------------------------------------------------
# empty-state
# ---------------------------------------------------------------------------


class TestEmptyState:
    def test_not_found(self):
        out = ar._activity_detail_empty_state_html(
            mode="not_found", activity_id="xyz"
        )
        assert "Activity not found" in out
        assert "xyz" in out

    def test_unavailable(self):
        out = ar._activity_detail_empty_state_html(
            mode="unavailable", activity_id="xyz"
        )
        assert "Activity detail not available" in out

    def test_id_escaped(self):
        out = ar._activity_detail_empty_state_html(
            mode="not_found", activity_id="<evil>"
        )
        assert "<evil>" not in out
        assert "&lt;evil&gt;" in out

    def test_no_js(self):
        out = ar._activity_detail_empty_state_html(
            mode="unavailable", activity_id="x"
        )
        assert "<script" not in out.lower()
        assert "javascript:" not in out.lower()
        assert "onerror=" not in out.lower()


# ---------------------------------------------------------------------------
# render_activity_detail_html
# ---------------------------------------------------------------------------


class TestRenderHtml:
    def test_basic(self):
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "Discovery call with Acme" in out
        assert "<!DOCTYPE html>" in out

    def test_none_activity(self):
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=None
        )
        assert "Activity detail not available" in out

    def test_non_dict_activity(self):
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity="not-a-dict"
        )
        assert "Activity detail not available" in out

    def test_id_mismatch(self):
        out = ar.render_activity_detail_html(
            activity_id="other-id", activity=_SAMPLE_ACTIVITY
        )
        assert "Activity not found" in out

    def test_subject(self):
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "Discovery call with Acme" in out

    def test_type_chip_uppercased(self):
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "CALL" in out

    def test_subtype_chip(self):
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "discovery" in out

    def test_status_chip_uppercased(self):
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "COMPLETED" in out

    def test_outcome_chip(self):
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "connected" in out

    def test_duration_formatted(self):
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "45m" in out

    def test_duration_hours(self):
        activity = {**_SAMPLE_ACTIVITY, "duration_minutes": 90}
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=activity
        )
        assert "1h 30m" in out

    def test_date_formatted(self):
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "2026-04-18 14:22" in out

    def test_owner_name_shown(self):
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "Usjid Iqbal" in out

    def test_owner_fallback_to_id(self):
        activity = {
            k: v
            for k, v in _SAMPLE_ACTIVITY.items()
            if k != "owner_name"
        }
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=activity
        )
        assert "user_usjid" in out

    def test_description_rendered(self):
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "stakeholder changes" in out

    def test_next_steps_rendered(self):
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "Send proposal by Friday" in out

    def test_contact_drill_up(self):
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "g8://contacts/42" in out
        assert "g8://contacts/42/activities" in out

    def test_company_drill_up(self):
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "g8://companies/99" in out

    def test_deal_drill_up(self):
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "g8://deals/7" in out

    def test_no_contact_drill_up_when_missing(self):
        activity = {
            k: v
            for k, v in _SAMPLE_ACTIVITY.items()
            if k != "contact_id"
        }
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=activity
        )
        assert "g8://contacts/" not in out

    def test_no_company_drill_up_when_missing(self):
        activity = {
            k: v
            for k, v in _SAMPLE_ACTIVITY.items()
            if k != "company_id"
        }
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=activity
        )
        assert "g8://companies/" not in out

    def test_no_deal_drill_up_when_missing(self):
        activity = {
            k: v for k, v in _SAMPLE_ACTIVITY.items() if k != "deal_id"
        }
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=activity
        )
        assert "g8://deals/" not in out

    def test_drill_up_activities_feed(self):
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "g8://activities/feed" in out

    def test_drill_up_tasks_dashboard(self):
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "g8://tasks/dashboard" in out

    def test_drill_up_copilot_home(self):
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "g8://copilot/home" in out

    def test_no_javascript(self):
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "<script" not in out.lower()
        assert "javascript:" not in out.lower()
        assert " onclick=" not in out.lower()
        assert " onerror=" not in out.lower()

    def test_no_legacy_hexes(self):
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        ).lower()
        for hex_color in _LEGACY_STUDIO_HEXES:
            assert hex_color not in out, f"Legacy Studio hex {hex_color} leaked"

    def test_uses_graph8_primary(self):
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "#7d2df3" in out

    def test_uses_graph8_border(self):
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "#dfdfdf" in out

    def test_uses_aeonik(self):
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "Aeonik" in out

    def test_no_single_side_colored_accent_border(self):
        """Single-side colored accent borders are an AI-tell; use neutral borders."""
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        for color in (
            ar._G8_PRIMARY,
            ar._G8_POSITIVE_FG,
            ar._G8_WARNING_FG,
            ar._G8_DESTRUCTIVE_FG,
        ):
            for side in (
                "border-left",
                "border-right",
                "border-top",
                "border-bottom",
            ):
                pattern = re.compile(
                    rf"{side}[^;]*{re.escape(color)}", re.IGNORECASE
                )
                assert not pattern.search(out), (
                    f"single-side colored accent border using {color} on {side} detected"
                )

    def test_xss_subject(self):
        activity = {
            **_SAMPLE_ACTIVITY,
            "subject": "<script>alert(1)</script>",
        }
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=activity
        )
        assert "<script>alert(1)</script>" not in out
        assert "&lt;script&gt;" in out

    def test_xss_description(self):
        activity = {
            **_SAMPLE_ACTIVITY,
            "description": "<img src=x onerror=alert(1)>",
        }
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=activity
        )
        assert "<img src=x" not in out
        assert "&lt;img src=x" in out

    def test_xss_next_steps(self):
        activity = {
            **_SAMPLE_ACTIVITY,
            "next_steps": "<img src=x onerror=alert(1)>",
        }
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=activity
        )
        assert "<img src=x" not in out
        assert "&lt;img src=x" in out

    def test_xss_owner_name(self):
        activity = {**_SAMPLE_ACTIVITY, "owner_name": "<b>nope</b>"}
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=activity
        )
        assert "<b>nope</b>" not in out
        assert "&lt;b&gt;nope&lt;/b&gt;" in out

    def test_xss_contact_id_in_drill_up(self):
        activity = {**_SAMPLE_ACTIVITY, "contact_id": "<evil>"}
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=activity
        )
        assert "<evil>" not in out

    def test_xss_activity_id_in_fallback_title(self):
        out = ar.render_activity_detail_html(
            activity_id="<evil>", activity=None
        )
        assert "<evil>" not in out

    def test_minimal(self):
        out = ar.render_activity_detail_html(
            activity_id="m-1",
            activity={"id": "m-1", "activity_type": "note"},
        )
        assert "NOTE" in out
        assert "<!DOCTYPE html>" in out

    def test_well_formed(self):
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert out.count("<html>") == out.count("</html>") == 1
        assert out.count("<body") == out.count("</body>") == 1
        assert out.count("<head>") == out.count("</head>") == 1

    def test_duration_missing_shows_em_dash(self):
        activity = {
            k: v
            for k, v in _SAMPLE_ACTIVITY.items()
            if k != "duration_minutes"
        }
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=activity
        )
        # Duration card should fall back to em-dash
        assert "—" in out

    def test_description_clipped_at_cap(self):
        activity = {
            **_SAMPLE_ACTIVITY,
            "description": "x" * (ar._MAX_ACTIVITY_DETAIL_DESCRIPTION_LEN + 100),
        }
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=activity
        )
        assert "…" in out


# ---------------------------------------------------------------------------
# render_activity_detail_text_fallback
# ---------------------------------------------------------------------------


class TestTextFallback:
    def test_basic(self):
        out = ar.render_activity_detail_text_fallback(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert out.startswith("# Discovery call with Acme")
        assert out.endswith("\n")

    def test_none_activity(self):
        out = ar.render_activity_detail_text_fallback(
            activity_id=_ACTIVITY_ID, activity=None
        )
        assert "Activity detail not available" in out

    def test_id_mismatch(self):
        out = ar.render_activity_detail_text_fallback(
            activity_id="other", activity=_SAMPLE_ACTIVITY
        )
        assert "No activity with id" in out

    def test_type_inline(self):
        out = ar.render_activity_detail_text_fallback(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "Type: CALL" in out

    def test_subtype_inline(self):
        out = ar.render_activity_detail_text_fallback(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "Subtype: discovery" in out

    def test_status_inline(self):
        out = ar.render_activity_detail_text_fallback(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "Status: COMPLETED" in out

    def test_outcome_inline(self):
        out = ar.render_activity_detail_text_fallback(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "Outcome: connected" in out

    def test_kpis_section(self):
        out = ar.render_activity_detail_text_fallback(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "## KPIs" in out
        assert "Duration: 45m" in out

    def test_description_section(self):
        out = ar.render_activity_detail_text_fallback(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "## Description" in out
        assert "stakeholder changes" in out

    def test_next_steps_section(self):
        out = ar.render_activity_detail_text_fallback(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "## Next steps" in out
        assert "Send proposal by Friday" in out

    def test_metadata_section(self):
        out = ar.render_activity_detail_text_fallback(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "## Metadata" in out

    def test_related_surfaces(self):
        out = ar.render_activity_detail_text_fallback(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "## Related surfaces" in out
        assert "g8://activities/feed" in out
        assert "g8://contacts/42" in out
        assert "g8://companies/99" in out
        assert "g8://deals/7" in out
        assert "g8://tasks/dashboard" in out
        assert "g8://copilot/home" in out

    def test_no_html(self):
        out = ar.render_activity_detail_text_fallback(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert "<div" not in out
        assert "<span" not in out
        assert "<script" not in out

    def test_xss_plaintext(self):
        activity = {
            **_SAMPLE_ACTIVITY,
            "subject": "<script>alert(1)</script>",
        }
        out = ar.render_activity_detail_text_fallback(
            activity_id=_ACTIVITY_ID, activity=activity
        )
        # Plaintext: the raw <script> tag is inert — preserve literally.
        assert "<script>alert(1)</script>" in out


# ---------------------------------------------------------------------------
# Smoke
# ---------------------------------------------------------------------------


class TestSmoke:
    def test_html_roundtrip(self):
        out = ar.render_activity_detail_html(
            activity_id=_ACTIVITY_ID, activity=_SAMPLE_ACTIVITY
        )
        assert len(out) > 1000
        assert "<!DOCTYPE html>" in out
        assert out.rstrip().endswith("</html>")

    def test_empty_roundtrip(self):
        out = ar.render_activity_detail_html(activity_id="x", activity=None)
        assert "<!DOCTYPE html>" in out
        assert out.rstrip().endswith("</html>")
