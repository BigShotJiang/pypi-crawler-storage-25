"""Tests for contact detail HTML app surface (surface #25).

Surface #25 renders a per-contact drilldown: identity, seniority badge,
confidence, linked deals, open tasks, recent notes. Completes the CRM
entity triad: contacts (#25) <-> deals (#24) -> companies (future).

Coverage emphasises:
- Seniority palette classification
  - direct match (c_suite, vp, director, manager, lead, senior, ic, entry)
  - alias / prefix match (e.g. "c-suite" -> c_suite, "Director, Engineering")
  - empty / non-string / unknown -> None (no badge rendered)
- Priority palette mapping (1=URGENT / 2=HIGH / 3=NORMAL / 4=LOW)
  - non-int / bool / out-of-range -> None
- Display name derivation: full_name > first+last > work_email > "Contact"
- Location formatting: "City, State, Country" with empty parts skipped
- Confidence formatting: 0.0-1.0 -> percentage, >1 treated as already-pct
- Open-task filter: completed/done/closed/cancelled dropped; non-dicts skipped
- Empty-state triggers (None / non-dict / empty)
- HTML escape of user-controlled fields (name, about, job title, email, id)
- Populated render: stat cards, info rows, social chips, deals/tasks/notes
  sections, overflow footers, timestamps
- Text fallback parity with markdown structure
"""

from g8_mcp_server.app_renderer import (
    _CONTACT_DETAIL_SENIORITY_COLORS,
    _CONTACT_DETAIL_TASK_PRIORITY_LABELS,
    _contact_detail_derive_display_name,
    _contact_detail_filter_open_tasks,
    _contact_detail_format_confidence,
    _contact_detail_format_location,
    _contact_detail_priority_palette,
    _contact_detail_seniority_palette,
    _render_contact_detail_empty_state_html,
    render_contact_detail_html,
    render_contact_detail_text_fallback,
)

_BANNED_HEXES = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}


class TestContactDetailPalettesNoBannedHexes:
    """Lock tests: palettes must not reintroduce banned Studio hexes."""

    def test_no_banned_hexes_in_seniority_palette(self):
        for key, pal in _CONTACT_DETAIL_SENIORITY_COLORS.items():
            for field in ("bg", "fg", "border"):
                assert pal[field].lower() not in _BANNED_HEXES, (
                    f"Banned hex {pal[field]!r} found in _CONTACT_DETAIL_SENIORITY_COLORS[{key!r}][{field!r}]"
                )

    def test_no_banned_hexes_in_task_priority_labels(self):
        for key, (_label, pal) in _CONTACT_DETAIL_TASK_PRIORITY_LABELS.items():
            for field in ("bg", "fg", "border"):
                assert pal[field].lower() not in _BANNED_HEXES, (
                    f"Banned hex {pal[field]!r} found in _CONTACT_DETAIL_TASK_PRIORITY_LABELS[{key!r}][{field!r}]"
                )


# ---------------------------------------------------------------------------
# Seniority palette
# ---------------------------------------------------------------------------


class TestContactDetailSeniorityPalette:
    def test_direct_match_c_suite(self):
        pal = _contact_detail_seniority_palette("c_suite")
        assert pal is not None
        assert pal["fg"] == "#86198f"

    def test_direct_match_vp(self):
        pal = _contact_detail_seniority_palette("vp")
        assert pal is not None
        assert pal["fg"] == "#7d2df3"

    def test_direct_match_director(self):
        pal = _contact_detail_seniority_palette("director")
        assert pal["fg"] == "#7d2df3"  # was banned #1d4ed8 → _G8_PRIMARY

    def test_direct_match_manager(self):
        pal = _contact_detail_seniority_palette("manager")
        assert pal["fg"] == "#0e7490"

    def test_direct_match_senior(self):
        pal = _contact_detail_seniority_palette("senior")
        assert pal["fg"] == "#059669"  # was banned #166534 → _G8_POSITIVE_FG

    def test_direct_match_ic(self):
        pal = _contact_detail_seniority_palette("ic")
        assert pal["fg"] == "#0A0A0A"

    def test_direct_match_entry(self):
        pal = _contact_detail_seniority_palette("entry")
        assert pal["fg"] == "#777777"

    def test_dash_normalised_to_underscore(self):
        pal = _contact_detail_seniority_palette("c-suite")
        assert pal is not None
        assert pal["fg"] == "#86198f"

    def test_space_normalised_to_underscore(self):
        pal = _contact_detail_seniority_palette("c suite")
        assert pal is not None
        assert pal["fg"] == "#86198f"

    def test_case_insensitive(self):
        pal = _contact_detail_seniority_palette("DIRECTOR")
        assert pal is not None
        assert pal["fg"] == "#7d2df3"  # was banned #1d4ed8 → _G8_PRIMARY

    def test_prefix_match_director_of_eng(self):
        pal = _contact_detail_seniority_palette("director_of_engineering")
        assert pal is not None
        assert pal["fg"] == "#7d2df3"  # was banned #1d4ed8 → _G8_PRIMARY

    def test_head_matches(self):
        pal = _contact_detail_seniority_palette("head")
        assert pal is not None
        assert pal["fg"] == "#7d2df3"  # was banned #1d4ed8 → _G8_PRIMARY

    def test_founder_purple(self):
        pal = _contact_detail_seniority_palette("founder")
        assert pal is not None
        assert pal["fg"] == "#86198f"

    def test_executive_purple(self):
        pal = _contact_detail_seniority_palette("executive")
        assert pal is not None
        assert pal["fg"] == "#86198f"

    def test_lead_cyan(self):
        pal = _contact_detail_seniority_palette("lead")
        assert pal is not None
        assert pal["fg"] == "#0e7490"

    def test_none_returns_none(self):
        assert _contact_detail_seniority_palette(None) is None

    def test_empty_returns_none(self):
        assert _contact_detail_seniority_palette("") is None

    def test_whitespace_returns_none(self):
        assert _contact_detail_seniority_palette("   ") is None

    def test_non_string_returns_none(self):
        assert _contact_detail_seniority_palette(42) is None
        assert _contact_detail_seniority_palette(["director"]) is None

    def test_unknown_returns_none(self):
        # "intern" isn't in the map and doesn't alias to anything
        assert _contact_detail_seniority_palette("intern") is None


# ---------------------------------------------------------------------------
# Priority palette
# ---------------------------------------------------------------------------


class TestContactDetailPriorityPalette:
    def test_urgent_priority_1(self):
        result = _contact_detail_priority_palette(1)
        assert result is not None
        label, pal = result
        assert label == "URGENT"
        assert pal["fg"] == "#b91c1c"  # was banned #991b1b → _G8_DESTRUCTIVE_ON_LIGHT_FG

    def test_high_priority_2(self):
        result = _contact_detail_priority_palette(2)
        assert result is not None
        label, pal = result
        assert label == "HIGH"
        assert pal["fg"] == "#9a3412"

    def test_normal_priority_3(self):
        result = _contact_detail_priority_palette(3)
        assert result is not None
        label, pal = result
        assert label == "NORMAL"
        assert pal["fg"] == "#7d2df3"  # was banned #1d4ed8 → _G8_PRIMARY

    def test_low_priority_4(self):
        result = _contact_detail_priority_palette(4)
        assert result is not None
        label, _ = result
        assert label == "LOW"

    def test_priority_0_returns_none(self):
        # 0 = no badge
        assert _contact_detail_priority_palette(0) is None

    def test_out_of_range_returns_none(self):
        assert _contact_detail_priority_palette(5) is None
        assert _contact_detail_priority_palette(-1) is None

    def test_non_int_string_returns_none(self):
        assert _contact_detail_priority_palette("URGENT") is None

    def test_bool_returns_none(self):
        # bool is a subclass of int — guard explicitly
        assert _contact_detail_priority_palette(True) is None
        assert _contact_detail_priority_palette(False) is None

    def test_none_returns_none(self):
        assert _contact_detail_priority_palette(None) is None

    def test_float_coerced_to_int(self):
        result = _contact_detail_priority_palette(1.0)
        assert result is not None
        assert result[0] == "URGENT"


# ---------------------------------------------------------------------------
# Display name derivation
# ---------------------------------------------------------------------------


class TestContactDetailDeriveDisplayName:
    def test_full_name_wins(self):
        c = {"full_name": "Ada Lovelace", "first_name": "A", "last_name": "L", "work_email": "x@y"}
        assert _contact_detail_derive_display_name(c) == "Ada Lovelace"

    def test_full_name_stripped(self):
        assert _contact_detail_derive_display_name({"full_name": "  Ada  "}) == "Ada"

    def test_first_last_fallback(self):
        c = {"first_name": "Ada", "last_name": "Lovelace", "work_email": "x@y"}
        assert _contact_detail_derive_display_name(c) == "Ada Lovelace"

    def test_first_only(self):
        assert _contact_detail_derive_display_name({"first_name": "Ada"}) == "Ada"

    def test_last_only(self):
        assert _contact_detail_derive_display_name({"last_name": "Lovelace"}) == "Lovelace"

    def test_email_fallback(self):
        assert _contact_detail_derive_display_name({"work_email": "ada@example.com"}) == "ada@example.com"

    def test_empty_full_name_falls_through(self):
        c = {"full_name": "   ", "first_name": "Ada"}
        assert _contact_detail_derive_display_name(c) == "Ada"

    def test_empty_contact_returns_fallback(self):
        assert _contact_detail_derive_display_name({}) == "Contact"

    def test_non_string_fields_ignored(self):
        c = {"full_name": 42, "first_name": None, "work_email": ""}
        assert _contact_detail_derive_display_name(c) == "Contact"


# ---------------------------------------------------------------------------
# Location formatting
# ---------------------------------------------------------------------------


class TestContactDetailFormatLocation:
    def test_all_parts(self):
        c = {"city": "Austin", "state": "TX", "country": "USA"}
        assert _contact_detail_format_location(c) == "Austin, TX, USA"

    def test_missing_state(self):
        c = {"city": "Austin", "country": "USA"}
        assert _contact_detail_format_location(c) == "Austin, USA"

    def test_only_country(self):
        assert _contact_detail_format_location({"country": "USA"}) == "USA"

    def test_empty_strings_skipped(self):
        c = {"city": "Austin", "state": "", "country": "USA"}
        assert _contact_detail_format_location(c) == "Austin, USA"

    def test_whitespace_skipped(self):
        c = {"city": "Austin", "state": "  ", "country": "USA"}
        assert _contact_detail_format_location(c) == "Austin, USA"

    def test_all_empty(self):
        assert _contact_detail_format_location({}) == ""

    def test_non_string_skipped(self):
        c = {"city": "Austin", "state": 42, "country": "USA"}
        assert _contact_detail_format_location(c) == "Austin, USA"

    def test_parts_stripped(self):
        c = {"city": "  Austin  ", "country": " USA "}
        assert _contact_detail_format_location(c) == "Austin, USA"


# ---------------------------------------------------------------------------
# Confidence formatting
# ---------------------------------------------------------------------------


class TestContactDetailFormatConfidence:
    def test_fraction_rendered_as_percent(self):
        assert _contact_detail_format_confidence(0.85) == "85%"

    def test_one_rendered_as_100(self):
        assert _contact_detail_format_confidence(1.0) == "100%"

    def test_zero_rendered_as_0(self):
        assert _contact_detail_format_confidence(0.0) == "0%"

    def test_over_one_treated_as_already_pct(self):
        # E.g. API sometimes returns 85 instead of 0.85
        assert _contact_detail_format_confidence(85) == "85%"

    def test_int_fraction(self):
        assert _contact_detail_format_confidence(1) == "100%"

    def test_none_returns_dash(self):
        assert _contact_detail_format_confidence(None) == "\u2014"

    def test_string_returns_dash(self):
        assert _contact_detail_format_confidence("0.85") == "\u2014"

    def test_bool_returns_dash(self):
        # bool is a subclass of int — guard explicitly
        assert _contact_detail_format_confidence(True) == "\u2014"

    def test_rounded_to_integer(self):
        assert _contact_detail_format_confidence(0.856) == "86%"


# ---------------------------------------------------------------------------
# Open-task filter
# ---------------------------------------------------------------------------


class TestContactDetailFilterOpenTasks:
    def test_none_returns_empty(self):
        assert _contact_detail_filter_open_tasks(None) == []

    def test_empty_returns_empty(self):
        assert _contact_detail_filter_open_tasks([]) == []

    def test_non_list_returns_empty(self):
        assert _contact_detail_filter_open_tasks("tasks") == []
        assert _contact_detail_filter_open_tasks({}) == []

    def test_completed_dropped(self):
        tasks = [{"status": "completed", "title": "t1"}, {"status": "open", "title": "t2"}]
        out = _contact_detail_filter_open_tasks(tasks)
        assert len(out) == 1
        assert out[0]["title"] == "t2"

    def test_done_dropped(self):
        tasks = [{"status": "done", "title": "t1"}]
        assert _contact_detail_filter_open_tasks(tasks) == []

    def test_closed_dropped(self):
        tasks = [{"status": "closed", "title": "t1"}]
        assert _contact_detail_filter_open_tasks(tasks) == []

    def test_cancelled_dropped(self):
        tasks = [{"status": "cancelled", "title": "t1"}]
        assert _contact_detail_filter_open_tasks(tasks) == []

    def test_case_insensitive_drop(self):
        tasks = [{"status": "COMPLETED", "title": "t1"}]
        assert _contact_detail_filter_open_tasks(tasks) == []

    def test_non_dict_skipped(self):
        tasks = ["not a dict", None, {"status": "open", "title": "t1"}]
        out = _contact_detail_filter_open_tasks(tasks)
        assert len(out) == 1
        assert out[0]["title"] == "t1"

    def test_missing_status_kept(self):
        # Missing status = open by default
        tasks = [{"title": "t1"}]
        out = _contact_detail_filter_open_tasks(tasks)
        assert len(out) == 1

    def test_empty_status_kept(self):
        tasks = [{"status": "", "title": "t1"}]
        out = _contact_detail_filter_open_tasks(tasks)
        assert len(out) == 1


# ---------------------------------------------------------------------------
# Empty state rendering
# ---------------------------------------------------------------------------


class TestRenderContactDetailEmptyStates:
    def test_none_contact_renders_empty_state(self):
        html = render_contact_detail_html(contact=None, contact_id="c_123")
        assert "Contact not found" in html
        assert "c_123" in html

    def test_non_dict_contact_renders_empty_state(self):
        html = render_contact_detail_html(contact="not a dict", contact_id="c_123")
        assert "Contact not found" in html
        assert "c_123" in html

    def test_empty_state_references_search(self):
        html = render_contact_detail_html(contact=None, contact_id="c_123")
        # Empty-state invites user to recover via search tool
        assert "g8_search_contacts" in html

    def test_empty_state_html_escapes_id(self):
        html = _render_contact_detail_empty_state_html(contact_id="<script>alert(1)</script>")
        assert "<script>alert(1)</script>" not in html
        assert "&lt;script&gt;" in html

    def test_empty_state_handles_empty_id(self):
        html = _render_contact_detail_empty_state_html(contact_id="")
        assert "(unknown)" in html

    def test_empty_state_text_fallback(self):
        text = render_contact_detail_text_fallback(contact=None, contact_id="c_123")
        assert "Contact not found" in text
        assert "c_123" in text

    def test_empty_state_text_fallback_non_dict(self):
        text = render_contact_detail_text_fallback(contact="nope", contact_id="c_123")
        assert "Contact not found" in text


# ---------------------------------------------------------------------------
# Populated HTML rendering
# ---------------------------------------------------------------------------


def _sample_contact():
    return {
        "id": "c_123",
        "full_name": "Ada Lovelace",
        "first_name": "Ada",
        "last_name": "Lovelace",
        "job_title": "VP of Engineering",
        "job_department": "Engineering",
        "seniority_level": "vp",
        "work_email": "ada@example.com",
        "direct_phone": "+1-555-0100",
        "mobile_phone": "+1-555-0200",
        "linkedin_url": "https://linkedin.com/in/ada",
        "twitter_url": "https://x.com/ada",
        "facebook_url": "",
        "about": "Built the first analytical engine programs.",
        "confidence_score": 0.92,
        "city": "London",
        "state": "",
        "country": "UK",
        "company": {"id": "co_1", "name": "Analytical Engines Ltd"},
        "created_at": "2024-01-15T10:00:00Z",
        "updated_at": "2026-04-18T14:30:00Z",
    }


class TestRenderContactDetailPopulated:
    def test_name_in_header(self):
        html = render_contact_detail_html(contact=_sample_contact(), contact_id="c_123")
        assert "Ada Lovelace" in html

    def test_contact_id_in_header(self):
        html = render_contact_detail_html(contact=_sample_contact(), contact_id="c_123")
        assert "c_123" in html

    def test_seniority_badge_rendered(self):
        html = render_contact_detail_html(contact=_sample_contact(), contact_id="c_123")
        # Badge span is emitted (CSS rule `.seniority-badge` is always in <style>,
        # so we look for the inline span tag)
        assert '<span class="seniority-badge"' in html
        assert "VP" in html

    def test_seniority_badge_skipped_when_unknown(self):
        c = _sample_contact()
        c["seniority_level"] = "intern"
        html = render_contact_detail_html(contact=c, contact_id="c_123")
        # CSS rule `.seniority-badge` is always in <style>; check for the span
        assert '<span class="seniority-badge"' not in html

    def test_confidence_stat_card(self):
        html = render_contact_detail_html(contact=_sample_contact(), contact_id="c_123")
        assert "Confidence" in html
        assert "92%" in html

    def test_confidence_green_when_high(self):
        html = render_contact_detail_html(contact=_sample_contact(), contact_id="c_123")
        # 0.92 > 0.7 → green (was banned #166534 → _G8_POSITIVE_FG)
        assert "#059669" in html

    def test_confidence_neutral_when_low(self):
        c = _sample_contact()
        c["confidence_score"] = 0.5
        html = render_contact_detail_html(contact=c, contact_id="c_123")
        # 0.5 not > 0.7 → should not have green confidence color in the stat
        # (other elements may still be green, but the confidence value should be neutral)
        assert "50%" in html

    def test_role_with_department(self):
        html = render_contact_detail_html(contact=_sample_contact(), contact_id="c_123")
        assert "VP of Engineering" in html
        assert "Engineering" in html

    def test_role_without_department(self):
        c = _sample_contact()
        c["job_department"] = ""
        html = render_contact_detail_html(contact=c, contact_id="c_123")
        assert "VP of Engineering" in html

    def test_company_name_rendered(self):
        html = render_contact_detail_html(contact=_sample_contact(), contact_id="c_123")
        assert "Analytical Engines Ltd" in html

    def test_location_rendered(self):
        html = render_contact_detail_html(contact=_sample_contact(), contact_id="c_123")
        assert "London, UK" in html

    def test_work_email_rendered(self):
        html = render_contact_detail_html(contact=_sample_contact(), contact_id="c_123")
        assert "ada@example.com" in html

    def test_phones_rendered(self):
        html = render_contact_detail_html(contact=_sample_contact(), contact_id="c_123")
        assert "+1-555-0100" in html
        assert "+1-555-0200" in html

    def test_linkedin_chip(self):
        html = render_contact_detail_html(contact=_sample_contact(), contact_id="c_123")
        assert "LinkedIn" in html

    def test_twitter_chip(self):
        html = render_contact_detail_html(contact=_sample_contact(), contact_id="c_123")
        assert "Twitter" in html

    def test_facebook_chip_skipped_when_empty(self):
        html = render_contact_detail_html(contact=_sample_contact(), contact_id="c_123")
        # facebook_url is "" in sample — chip should not appear
        assert "Facebook" not in html

    def test_about_rendered(self):
        html = render_contact_detail_html(contact=_sample_contact(), contact_id="c_123")
        assert "analytical engine" in html.lower()

    def test_about_skipped_when_empty(self):
        c = _sample_contact()
        c["about"] = ""
        html = render_contact_detail_html(contact=c, contact_id="c_123")
        assert "about-section" not in html

    def test_xss_escape_in_name(self):
        c = _sample_contact()
        c["full_name"] = "<script>alert('xss')</script>"
        html = render_contact_detail_html(contact=c, contact_id="c_123")
        assert "<script>alert" not in html
        assert "&lt;script&gt;" in html

    def test_xss_escape_in_about(self):
        c = _sample_contact()
        c["about"] = "<img src=x onerror=alert(1)>"
        html = render_contact_detail_html(contact=c, contact_id="c_123")
        assert "<img src=x" not in html
        assert "&lt;img" in html

    def test_xss_escape_in_job_title(self):
        c = _sample_contact()
        c["job_title"] = "<b>VP</b>"
        html = render_contact_detail_html(contact=c, contact_id="c_123")
        assert "<b>VP</b>" not in html
        assert "&lt;b&gt;" in html

    def test_xss_escape_in_email(self):
        c = _sample_contact()
        c["work_email"] = "<script>alert(1)</script>@evil.com"
        html = render_contact_detail_html(contact=c, contact_id="c_123")
        assert "<script>alert" not in html

    def test_xss_escape_in_contact_id(self):
        html = render_contact_detail_html(
            contact=_sample_contact(), contact_id="<script>alert(1)</script>"
        )
        assert "<script>alert" not in html
        assert "&lt;script&gt;" in html

    def test_timestamps_rendered(self):
        html = render_contact_detail_html(contact=_sample_contact(), contact_id="c_123")
        assert "created" in html.lower()
        assert "updated" in html.lower()

    def test_minimal_contact_just_email(self):
        # Only an email — no name, no company, no profile data
        c = {"work_email": "anon@example.com"}
        html = render_contact_detail_html(contact=c, contact_id="c_999")
        assert "anon@example.com" in html
        # Should still render without errors

    def test_anonymous_contact_no_data(self):
        html = render_contact_detail_html(contact={}, contact_id="c_999")
        assert "Contact" in html  # display-name fallback
        assert "c_999" in html


# ---------------------------------------------------------------------------
# Linked deals / tasks / notes sections
# ---------------------------------------------------------------------------


class TestRenderContactDetailRelatedSections:
    def test_deals_section_rendered(self):
        deals = [
            {"name": "Enterprise Deal", "stage": "Proposal", "value": 100000, "currency": "USD"},
            {"name": "Pilot Deal", "stage": "Discovery", "value": 5000, "currency": "USD"},
        ]
        html = render_contact_detail_html(
            contact=_sample_contact(), contact_id="c_123", deals=deals
        )
        assert "Enterprise Deal" in html
        assert "Pilot Deal" in html
        assert "Proposal" in html
        assert "Discovery" in html

    def test_deals_section_skipped_when_none(self):
        html = render_contact_detail_html(contact=_sample_contact(), contact_id="c_123")
        assert "deals-section" not in html

    def test_deals_overflow_note(self):
        deals = [{"name": f"Deal {i}", "stage": "Open"} for i in range(25)]
        html = render_contact_detail_html(
            contact=_sample_contact(), contact_id="c_123", deals=deals
        )
        # 20 rendered, 5 omitted
        assert "5 more deal(s) omitted" in html

    def test_deals_non_dict_entries_skipped(self):
        deals = [{"name": "Real"}, "not a deal", None, {"name": "Also Real"}]
        html = render_contact_detail_html(
            contact=_sample_contact(), contact_id="c_123", deals=deals
        )
        assert "Real" in html
        assert "Also Real" in html

    def test_open_tasks_section_rendered(self):
        tasks = [
            {"title": "Follow up Q1", "priority": 1, "due_date": "2026-04-25", "status": "open"},
            {"title": "Send proposal", "priority": 3, "status": "in_progress"},
        ]
        html = render_contact_detail_html(
            contact=_sample_contact(), contact_id="c_123", tasks=tasks
        )
        assert "Follow up Q1" in html
        assert "Send proposal" in html
        assert "URGENT" in html
        assert "NORMAL" in html

    def test_completed_tasks_filtered(self):
        tasks = [
            {"title": "Done task", "status": "completed"},
            {"title": "Open task", "status": "open"},
        ]
        html = render_contact_detail_html(
            contact=_sample_contact(), contact_id="c_123", tasks=tasks
        )
        assert "Done task" not in html
        assert "Open task" in html

    def test_tasks_section_skipped_when_all_completed(self):
        tasks = [{"title": "Done", "status": "done"}]
        html = render_contact_detail_html(
            contact=_sample_contact(), contact_id="c_123", tasks=tasks
        )
        # "Open tasks" appears as a stat-card label always; check for section class
        assert "tasks-section" not in html
        assert "Done" not in html

    def test_tasks_overflow(self):
        tasks = [{"title": f"Task {i}", "priority": 3, "status": "open"} for i in range(25)]
        html = render_contact_detail_html(
            contact=_sample_contact(), contact_id="c_123", tasks=tasks
        )
        # 20 rendered, 5 omitted
        assert "5 more task(s) omitted" in html

    def test_task_due_date_chip(self):
        tasks = [{"title": "t", "due_date": "2026-04-25", "status": "open"}]
        html = render_contact_detail_html(
            contact=_sample_contact(), contact_id="c_123", tasks=tasks
        )
        assert "2026-04-25" in html

    def test_task_assignee_chip(self):
        tasks = [{"title": "t", "assignee_name": "Bob", "status": "open"}]
        html = render_contact_detail_html(
            contact=_sample_contact(), contact_id="c_123", tasks=tasks
        )
        assert "@Bob" in html

    def test_notes_section_rendered(self):
        notes = [
            {
                "content": "Great meeting with them.",
                "created_by_name": "Alice",
                "created_at": "2026-04-18",
            }
        ]
        html = render_contact_detail_html(
            contact=_sample_contact(), contact_id="c_123", notes=notes
        )
        assert "Great meeting" in html
        assert "Alice" in html
        assert "2026-04-18" in html

    def test_notes_overflow(self):
        notes = [{"content": f"Note {i}"} for i in range(15)]
        html = render_contact_detail_html(
            contact=_sample_contact(), contact_id="c_123", notes=notes
        )
        # 10 rendered, 5 omitted
        assert "5 more note(s) omitted" in html

    def test_notes_xss_escape(self):
        notes = [{"content": "<script>evil</script>"}]
        html = render_contact_detail_html(
            contact=_sample_contact(), contact_id="c_123", notes=notes
        )
        assert "<script>evil" not in html
        assert "&lt;script&gt;" in html

    def test_all_sections_populated(self):
        deals = [{"name": "Deal1", "stage": "Open"}]
        tasks = [{"title": "Task1", "status": "open"}]
        notes = [{"content": "Note1"}]
        html = render_contact_detail_html(
            contact=_sample_contact(),
            contact_id="c_123",
            deals=deals,
            tasks=tasks,
            notes=notes,
        )
        assert "Deal1" in html
        assert "Task1" in html
        assert "Note1" in html


# ---------------------------------------------------------------------------
# Stat-card counts
# ---------------------------------------------------------------------------


class TestRenderContactDetailStatCards:
    def test_deal_count_zero(self):
        html = render_contact_detail_html(contact=_sample_contact(), contact_id="c_123")
        # "0" appears in multiple stat cards; verify card label is present
        assert "Linked deals" in html

    def test_deal_count_matches(self):
        deals = [{"name": "d1"}, {"name": "d2"}, {"name": "d3"}]
        html = render_contact_detail_html(
            contact=_sample_contact(), contact_id="c_123", deals=deals
        )
        assert ">3<" in html  # count "3" rendered in a stat-value span

    def test_open_task_count_matches(self):
        tasks = [
            {"title": "t1", "status": "open"},
            {"title": "t2", "status": "done"},  # filtered out
        ]
        html = render_contact_detail_html(
            contact=_sample_contact(), contact_id="c_123", tasks=tasks
        )
        # Only 1 open task
        assert ">1<" in html

    def test_notes_count_matches(self):
        notes = [{"content": "n1"}, {"content": "n2"}]
        html = render_contact_detail_html(
            contact=_sample_contact(), contact_id="c_123", notes=notes
        )
        assert ">2<" in html


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------


class TestRenderContactDetailTextFallback:
    def test_markdown_header_is_name(self):
        text = render_contact_detail_text_fallback(contact=_sample_contact(), contact_id="c_123")
        assert text.startswith("# Ada Lovelace")

    def test_contact_id_in_backticks(self):
        text = render_contact_detail_text_fallback(contact=_sample_contact(), contact_id="c_123")
        assert "`c_123`" in text

    def test_seniority_line(self):
        text = render_contact_detail_text_fallback(contact=_sample_contact(), contact_id="c_123")
        assert "Seniority: **VP**" in text

    def test_overview_section(self):
        text = render_contact_detail_text_fallback(contact=_sample_contact(), contact_id="c_123")
        assert "## Overview" in text
        assert "Confidence: 92%" in text

    def test_profile_section(self):
        text = render_contact_detail_text_fallback(contact=_sample_contact(), contact_id="c_123")
        assert "## Profile" in text
        assert "Role: VP of Engineering" in text
        assert "Company: Analytical Engines Ltd" in text
        assert "Location: London, UK" in text

    def test_contact_methods_section(self):
        text = render_contact_detail_text_fallback(contact=_sample_contact(), contact_id="c_123")
        assert "## Contact methods" in text
        assert "Work email: ada@example.com" in text
        assert "Direct phone: +1-555-0100" in text
        assert "LinkedIn: https://linkedin.com/in/ada" in text

    def test_about_section(self):
        text = render_contact_detail_text_fallback(contact=_sample_contact(), contact_id="c_123")
        assert "## About" in text
        assert "analytical engine" in text.lower()

    def test_deals_section(self):
        deals = [
            {"name": "Deal A", "stage": "Proposal", "value": 50000, "currency": "USD"},
        ]
        text = render_contact_detail_text_fallback(
            contact=_sample_contact(), contact_id="c_123", deals=deals
        )
        assert "## Linked deals (1)" in text
        assert "Deal A" in text
        assert "[Proposal]" in text

    def test_tasks_section(self):
        tasks = [{"title": "Task A", "priority": 1, "due_date": "2026-04-25", "status": "open"}]
        text = render_contact_detail_text_fallback(
            contact=_sample_contact(), contact_id="c_123", tasks=tasks
        )
        assert "## Open tasks (1)" in text
        assert "[URGENT]" in text
        assert "Task A" in text
        assert "due 2026-04-25" in text

    def test_tasks_filter_completed(self):
        tasks = [
            {"title": "Done", "status": "completed"},
            {"title": "Open", "status": "open"},
        ]
        text = render_contact_detail_text_fallback(
            contact=_sample_contact(), contact_id="c_123", tasks=tasks
        )
        assert "Done" not in text
        assert "Open" in text

    def test_notes_section(self):
        notes = [{"content": "Great meeting", "created_by_name": "Alice", "created_at": "2026-04-18"}]
        text = render_contact_detail_text_fallback(
            contact=_sample_contact(), contact_id="c_123", notes=notes
        )
        assert "## Recent notes (1)" in text
        assert "Great meeting" in text
        assert "Alice" in text

    def test_note_newlines_flattened(self):
        notes = [{"content": "Line 1\nLine 2\nLine 3"}]
        text = render_contact_detail_text_fallback(
            contact=_sample_contact(), contact_id="c_123", notes=notes
        )
        # Newlines inside content are flattened to spaces
        assert "Line 1 Line 2 Line 3" in text

    def test_deals_overflow_line(self):
        deals = [{"name": f"D{i}", "stage": "Open"} for i in range(25)]
        text = render_contact_detail_text_fallback(
            contact=_sample_contact(), contact_id="c_123", deals=deals
        )
        assert "and 5 more" in text

    def test_tasks_overflow_line(self):
        tasks = [{"title": f"T{i}", "status": "open"} for i in range(25)]
        text = render_contact_detail_text_fallback(
            contact=_sample_contact(), contact_id="c_123", tasks=tasks
        )
        assert "and 5 more" in text

    def test_notes_overflow_line(self):
        notes = [{"content": f"N{i}"} for i in range(15)]
        text = render_contact_detail_text_fallback(
            contact=_sample_contact(), contact_id="c_123", notes=notes
        )
        assert "and 5 more" in text

    def test_timestamps_footer(self):
        text = render_contact_detail_text_fallback(contact=_sample_contact(), contact_id="c_123")
        assert "created 2024-01-15T10:00:00Z" in text
        assert "updated 2026-04-18T14:30:00Z" in text

    def test_minimal_contact_no_crash(self):
        text = render_contact_detail_text_fallback(contact={}, contact_id="c_999")
        assert "# Contact" in text
        assert "c_999" in text

    def test_anonymous_no_email_no_name(self):
        # Empty contact should not render profile/contact/about sections
        text = render_contact_detail_text_fallback(contact={}, contact_id="c_999")
        assert "## Profile" not in text
        assert "## About" not in text

    def test_seniority_line_skipped_when_empty(self):
        c = _sample_contact()
        c["seniority_level"] = ""
        text = render_contact_detail_text_fallback(contact=c, contact_id="c_123")
        assert "Seniority:" not in text
