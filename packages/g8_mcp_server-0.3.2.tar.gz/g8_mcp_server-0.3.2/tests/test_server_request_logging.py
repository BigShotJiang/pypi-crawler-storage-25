"""Unit tests for the lightweight MCP request logger in ``server.py``.

``_log_mcp_request`` runs on every inbound JSON-RPC request so it has to
be cheap, never raise on weird shapes, and never leak PII. These tests
lock those invariants.
"""

from __future__ import annotations

import logging

import pytest

from g8_mcp_server import server as srv


class TestApiKeyFingerprint:
    def test_none_returns_anon(self):
        assert srv._api_key_fingerprint(None) == "anon"

    def test_empty_returns_anon(self):
        assert srv._api_key_fingerprint("") == "anon"

    def test_same_key_same_fingerprint(self):
        assert srv._api_key_fingerprint("sk-xyz") == srv._api_key_fingerprint("sk-xyz")

    def test_different_keys_different_fingerprints(self):
        assert srv._api_key_fingerprint("sk-one") != srv._api_key_fingerprint("sk-two")

    def test_never_logs_raw_key(self):
        key = "sk-live-abcdef1234567890"
        fp = srv._api_key_fingerprint(key)
        assert key not in fp
        assert len(fp) == 10  # 10 hex chars of sha256


class TestLogMcpRequest:
    def test_tools_call_logs_name_at_info(self, caplog):
        caplog.set_level(logging.INFO, logger="g8_mcp_server.server")
        srv._log_mcp_request(
            "tools/call",
            {"method": "tools/call", "params": {"name": "g8_gtm_list_campaigns", "arguments": {}}},
            "sk-test",
        )
        assert any(
            "tools/call" in r.message and "g8_gtm_list_campaigns" in r.message
            for r in caplog.records
        )

    def test_tools_call_never_logs_arg_values_at_info(self, caplog):
        """At INFO level we must log the tool name + caller only -
        never the actual argument values (may contain PII)."""
        caplog.set_level(logging.INFO, logger="g8_mcp_server.server")
        srv._log_mcp_request(
            "tools/call",
            {
                "method": "tools/call",
                "params": {
                    "name": "g8_gtm_hide_ad_image",
                    "arguments": {
                        "campaign_id": "secret-uuid-abc-123",
                        "image_id": "private-bucket-path",
                        "email": "customer@example.com",
                    },
                },
            },
            "sk-test",
        )
        info_messages = " ".join(r.message for r in caplog.records if r.levelno == logging.INFO)
        assert "secret-uuid-abc-123" not in info_messages
        assert "private-bucket-path" not in info_messages
        assert "customer@example.com" not in info_messages

    def test_tools_call_debug_logs_arg_shape_without_values(self, caplog):
        caplog.set_level(logging.DEBUG, logger="g8_mcp_server.server")
        srv._log_mcp_request(
            "tools/call",
            {
                "method": "tools/call",
                "params": {
                    "name": "g8_find_contacts",
                    "arguments": {"query": "secret-query", "limit": 10},
                },
            },
            "sk-test",
        )
        debug_lines = [r.message for r in caplog.records if r.levelno == logging.DEBUG]
        joined = " ".join(debug_lines)
        # Shape metadata present…
        assert "query" in joined
        assert "str" in joined
        # …but actual value absent.
        assert "secret-query" not in joined

    def test_resources_read_logs_uri(self, caplog):
        caplog.set_level(logging.INFO, logger="g8_mcp_server.server")
        srv._log_mcp_request(
            "resources/read",
            {"method": "resources/read", "params": {"uri": "ui://campaigns/dashboard"}},
            None,
        )
        assert any(
            "resources/read" in r.message and "ui://campaigns/dashboard" in r.message
            for r in caplog.records
        )
        assert any("anon" in r.message for r in caplog.records)

    def test_tools_list_and_resources_list_logged(self, caplog):
        caplog.set_level(logging.INFO, logger="g8_mcp_server.server")
        srv._log_mcp_request("tools/list", {"method": "tools/list"}, "sk")
        srv._log_mcp_request("resources/list", {"method": "resources/list"}, "sk")
        messages = [r.message for r in caplog.records]
        assert any("tools/list" in m for m in messages)
        assert any("resources/list" in m for m in messages)

    def test_unknown_method_still_logged(self, caplog):
        caplog.set_level(logging.INFO, logger="g8_mcp_server.server")
        srv._log_mcp_request("prompts/get", {"method": "prompts/get"}, "sk")
        assert any("prompts/get" in r.message for r in caplog.records)

    def test_none_method_is_noop(self, caplog):
        caplog.set_level(logging.INFO, logger="g8_mcp_server.server")
        srv._log_mcp_request(None, {}, "sk")
        # No records emitted for unknown/missing method.
        assert not any(r.name == "g8_mcp_server.server" for r in caplog.records)

    def test_malformed_tools_call_params_are_defensive(self, caplog):
        """A malformed request (params missing, wrong type, etc.) must
        not raise - the logger is wrapped but we still want the helper
        itself to tolerate junk.
        """
        caplog.set_level(logging.INFO, logger="g8_mcp_server.server")
        # params completely missing
        srv._log_mcp_request("tools/call", {"method": "tools/call"}, "sk")
        # params is a list instead of a dict (protocol violation)
        srv._log_mcp_request(
            "tools/call", {"method": "tools/call", "params": ["weird"]}, "sk"
        )
        # arguments is not a dict
        srv._log_mcp_request(
            "tools/call",
            {"method": "tools/call", "params": {"name": "x", "arguments": "not-a-dict"}},
            "sk",
        )
        # Must not have raised, and at least one INFO line must exist.
        assert any("tools/call" in r.message for r in caplog.records)


class TestLogHelperIsWrappedInMiddleware:
    """Smoke test: the ASGI middleware calls ``_log_mcp_request`` inside a
    ``try/except`` so that a logger bug can never 500 a real request.
    Verify the wiring is actually there by inspecting the source; this is
    cheaper and more stable than booting the ASGI stack.
    """

    def test_middleware_calls_log_helper_in_try(self):
        import inspect

        # The logger call lives inside ASGIAuthMiddleware.__call__ -
        # find that method's source and check that both the call and a
        # guarding `try:` are present.
        src = inspect.getsource(srv)
        # Reference the helper by name so a rename shows up here.
        assert "_log_mcp_request(method, rpc, resolved_key)" in src
        # And the call is wrapped - look for the nearby except handler
        # specifically mentioning "request logging failed" as a canary.
        assert "MCP: request logging failed" in src
