"""Tests for the sync runs history renderer (upgrade 4 — #18)."""

from __future__ import annotations

from g8_mcp_server import app_renderer
from g8_mcp_server.app_renderer import (
    _format_delta,
    _sync_run_status_color,
    render_sync_runs_history_html,
    render_sync_runs_history_text_fallback,
)


def _run(
    id_: int = 1,
    started_at: str | None = "2026-04-10T12:00:00Z",
    finished_at: str | None = "2026-04-10T12:01:30Z",
    status: str | None = "success",
    member_count: int | None = 1234,
    added_count: int | None = 15,
    removed_count: int | None = 3,
    error_message: str | None = None,
) -> dict:
    return {
        "id": id_,
        "started_at": started_at,
        "finished_at": finished_at,
        "status": status,
        "member_count": member_count,
        "added_count": added_count,
        "removed_count": removed_count,
        "error_message": error_message,
    }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class TestSyncRunStatusColor:
    def test_success(self):
        # Backported to graph8 tokens 2026-04-21
        c = _sync_run_status_color("success")
        assert c["fg"] == "#059669"  # _G8_POSITIVE_FG
        assert c["bg"] == "#d1fae5"

    def test_completed_same_as_success(self):
        """'completed' should map to green, like 'success'."""
        c = _sync_run_status_color("completed")
        assert c["fg"] == "#059669"  # _G8_POSITIVE_FG

    def test_running_blue(self):
        c = _sync_run_status_color("running")
        assert c["fg"] == "#1e40af"

    def test_in_progress_blue(self):
        c = _sync_run_status_color("in_progress")
        assert c["fg"] == "#1e40af"

    def test_pending_indigo(self):
        c = _sync_run_status_color("pending")
        assert c["fg"] == "#7d2df3"

    def test_queued_indigo(self):
        c = _sync_run_status_color("queued")
        assert c["fg"] == "#7d2df3"

    def test_failed_red(self):
        c = _sync_run_status_color("failed")
        assert c["fg"] == "#b91c1c"  # _G8_DESTRUCTIVE_ON_LIGHT_FG

    def test_error_red(self):
        c = _sync_run_status_color("error")
        assert c["fg"] == "#b91c1c"  # _G8_DESTRUCTIVE_ON_LIGHT_FG

    def test_unknown_default(self):
        c = _sync_run_status_color("mystery")
        assert c["fg"] == "#777777"

    def test_none(self):
        c = _sync_run_status_color(None)
        assert c["fg"] == "#777777"

    def test_case_insensitive(self):
        c = _sync_run_status_color("SUCCESS")
        assert c["fg"] == "#059669"  # _G8_POSITIVE_FG

    def test_no_banned_fg_hexes(self):
        banned = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}
        from mcp_server.g8_mcp_server.app_renderer import _SYNC_RUN_STATUS_COLORS
        for k, v in _SYNC_RUN_STATUS_COLORS.items():
            assert v["fg"].lower() not in banned, (
                f"status={k!r} fg={v['fg']!r} is banned"
            )


class TestFormatDelta:
    def test_none(self):
        assert _format_delta(None) == "-"

    def test_zero(self):
        assert _format_delta(0) == "0"

    def test_small(self):
        assert _format_delta(42) == "42"

    def test_thousand(self):
        assert _format_delta(1500) == "1.5k"

    def test_exact_thousand(self):
        assert _format_delta(1000) == "1.0k"

    def test_million(self):
        assert _format_delta(2_500_000) == "2.5M"

    def test_negative(self):
        assert _format_delta(-1500) == "-1.5k"

    def test_non_int(self):
        assert _format_delta("garbage") == "-"  # type: ignore[arg-type]

    def test_string_int(self):
        """String-encoded int should convert via int()."""
        assert _format_delta("1500") == "1.5k"  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# render_sync_runs_history_html
# ---------------------------------------------------------------------------


class TestRenderSyncRunsHistoryHtml:
    def test_empty_list_returns_empty_state(self):
        html_out = render_sync_runs_history_html(runs=[], config_id=42)
        assert "No sync runs yet" in html_out

    def test_none_returns_empty_state(self):
        html_out = render_sync_runs_history_html(runs=None, config_id=42)
        assert "No sync runs yet" in html_out

    def test_non_list_returns_empty_state(self):
        html_out = render_sync_runs_history_html(runs="garbage", config_id=42)  # type: ignore[arg-type]
        assert "No sync runs yet" in html_out

    def test_only_garbage_returns_empty_state(self):
        html_out = render_sync_runs_history_html(
            runs=["a", 1, None],  # type: ignore[list-item]
            config_id=42,
        )
        assert "No sync runs yet" in html_out

    def test_renders_basic_run(self):
        runs = [_run()]
        html_out = render_sync_runs_history_html(runs=runs, config_id=42)
        assert "success" in html_out.lower()
        assert "1.2k members" in html_out

    def test_config_id_in_header(self):
        runs = [_run()]
        html_out = render_sync_runs_history_html(runs=runs, config_id=12345)
        assert "#12345" in html_out

    def test_sync_label_rendered(self):
        runs = [_run()]
        html_out = render_sync_runs_history_html(
            runs=runs, config_id=42, sync_label="Enterprise Buyers"
        )
        assert "Enterprise Buyers" in html_out

    def test_success_count_in_subhead(self):
        runs = [
            _run(id_=1, status="success"),
            _run(id_=2, status="failed"),
            _run(id_=3, status="completed"),
        ]
        html_out = render_sync_runs_history_html(runs=runs, config_id=42)
        assert "2 succeeded" in html_out
        assert "1 failed" in html_out

    def test_added_delta_rendered_green(self):
        runs = [_run(added_count=50, removed_count=0)]
        html_out = render_sync_runs_history_html(runs=runs, config_id=42)
        assert "+50" in html_out
        assert '<span class="run-delta run-added"' in html_out

    def test_removed_delta_rendered_red(self):
        runs = [_run(added_count=0, removed_count=12)]
        html_out = render_sync_runs_history_html(runs=runs, config_id=42)
        assert "-12" in html_out
        assert '<span class="run-delta run-removed"' in html_out

    def test_zero_deltas_not_rendered(self):
        """When added=0 and removed=0, no delta SPAN badges should appear.

        The CSS class names still appear in the <style> block — check the
        body-side <span class="run-delta ..."> instead.
        """
        runs = [_run(added_count=0, removed_count=0)]
        html_out = render_sync_runs_history_html(runs=runs, config_id=42)
        assert '<span class="run-delta run-added"' not in html_out
        assert '<span class="run-delta run-removed"' not in html_out

    def test_error_message_rendered(self):
        runs = [_run(status="failed", error_message="OAuth token expired")]
        html_out = render_sync_runs_history_html(runs=runs, config_id=42)
        assert "OAuth token expired" in html_out
        assert "run-error" in html_out

    def test_error_message_truncated(self):
        long_err = "X" * (app_renderer._MAX_SYNC_RUN_ERROR_LEN + 100)
        runs = [_run(status="failed", error_message=long_err)]
        html_out = render_sync_runs_history_html(runs=runs, config_id=42)
        assert long_err not in html_out

    def test_html_escaped_in_error(self):
        runs = [_run(status="failed", error_message="<script>evil</script>")]
        html_out = render_sync_runs_history_html(runs=runs, config_id=42)
        assert "<script>evil" not in html_out
        assert "&lt;script&gt;" in html_out

    def test_html_escaped_in_status(self):
        runs = [_run(status="<svg>")]
        html_out = render_sync_runs_history_html(runs=runs, config_id=42)
        assert "<svg>" not in html_out
        assert "&lt;svg&gt;" in html_out

    def test_timestamps_rendered(self):
        runs = [
            _run(
                started_at="2026-04-10T12:00:00Z",
                finished_at="2026-04-10T12:01:30Z",
            )
        ]
        html_out = render_sync_runs_history_html(runs=runs, config_id=42)
        assert "2026-04-10T12:00:00Z" in html_out
        assert "2026-04-10T12:01:30Z" in html_out

    def test_missing_finished_timestamp(self):
        """Still-running: only started_at present, no arrow."""
        runs = [_run(started_at="2026-04-10T12:00:00Z", finished_at=None)]
        html_out = render_sync_runs_history_html(runs=runs, config_id=42)
        assert "2026-04-10T12:00:00Z" in html_out
        # No arrow since finished is missing
        assert "→" not in html_out

    def test_cap_enforced(self):
        runs = [_run(id_=i) for i in range(app_renderer._MAX_SYNC_RUNS_RENDERED + 10)]
        html_out = render_sync_runs_history_html(runs=runs, config_id=42)
        assert "10 run(s) omitted" in html_out

    def test_no_overflow_footer_within_cap(self):
        runs = [_run(id_=i) for i in range(5)]
        html_out = render_sync_runs_history_html(runs=runs, config_id=42)
        assert "omitted" not in html_out

    def test_non_dict_items_filtered(self):
        runs = [_run(id_=1), "garbage", None, _run(id_=2)]  # type: ignore[list-item]
        html_out = render_sync_runs_history_html(runs=runs, config_id=42)
        assert "2 run(s)" in html_out

    def test_config_id_none_fallback(self):
        """config_id=None should render '#?' placeholder."""
        runs = [_run()]
        html_out = render_sync_runs_history_html(runs=runs, config_id=None)
        assert "#?" in html_out

    def test_large_member_count_compacted(self):
        runs = [_run(member_count=2_500_000)]
        html_out = render_sync_runs_history_html(runs=runs, config_id=42)
        assert "2.5M members" in html_out


# ---------------------------------------------------------------------------
# render_sync_runs_history_text_fallback
# ---------------------------------------------------------------------------


class TestRenderSyncRunsHistoryTextFallback:
    def test_empty_list(self):
        text = render_sync_runs_history_text_fallback(runs=[], config_id=42)
        assert "No runs yet" in text

    def test_none(self):
        text = render_sync_runs_history_text_fallback(runs=None, config_id=42)
        assert "No runs yet" in text

    def test_non_list(self):
        text = render_sync_runs_history_text_fallback(runs="garbage", config_id=42)  # type: ignore[arg-type]
        assert "No runs yet" in text

    def test_only_garbage_items(self):
        text = render_sync_runs_history_text_fallback(
            runs=["a", 1],  # type: ignore[list-item]
            config_id=42,
        )
        assert "No runs yet" in text

    def test_renders_basic_run(self):
        runs = [_run()]
        text = render_sync_runs_history_text_fallback(runs=runs, config_id=42)
        assert "success" in text.lower()
        assert "1.2k members" in text

    def test_config_id_in_header(self):
        runs = [_run()]
        text = render_sync_runs_history_text_fallback(runs=runs, config_id=12345)
        assert "#12345" in text

    def test_sync_label_in_header(self):
        runs = [_run()]
        text = render_sync_runs_history_text_fallback(
            runs=runs, config_id=42, sync_label="High Intent"
        )
        assert "High Intent" in text

    def test_count_summary_line(self):
        runs = [
            _run(id_=1, status="success"),
            _run(id_=2, status="failed"),
        ]
        text = render_sync_runs_history_text_fallback(runs=runs, config_id=42)
        assert "1 succeeded" in text
        assert "1 failed" in text

    def test_added_removed_in_text(self):
        runs = [_run(added_count=25, removed_count=5)]
        text = render_sync_runs_history_text_fallback(runs=runs, config_id=42)
        assert "+25 added" in text
        assert "-5 removed" in text

    def test_zero_deltas_no_added_removed(self):
        runs = [_run(added_count=0, removed_count=0)]
        text = render_sync_runs_history_text_fallback(runs=runs, config_id=42)
        assert "added" not in text
        assert "removed" not in text

    def test_error_line(self):
        runs = [_run(status="failed", error_message="401 Unauthorized")]
        text = render_sync_runs_history_text_fallback(runs=runs, config_id=42)
        assert "error: 401 Unauthorized" in text

    def test_error_truncation(self):
        long_err = "X" * (app_renderer._MAX_SYNC_RUN_ERROR_LEN + 50)
        runs = [_run(status="failed", error_message=long_err)]
        text = render_sync_runs_history_text_fallback(runs=runs, config_id=42)
        # Exactly the truncation length should appear
        assert "X" * app_renderer._MAX_SYNC_RUN_ERROR_LEN in text
        assert long_err not in text

    def test_cap_overflow_message(self):
        runs = [
            _run(id_=i)
            for i in range(app_renderer._MAX_SYNC_RUNS_RENDERED + 7)
        ]
        text = render_sync_runs_history_text_fallback(runs=runs, config_id=42)
        assert "and 7 more run(s)" in text

    def test_timestamps_in_text(self):
        runs = [_run(started_at="2026-04-10T12:00:00Z", finished_at="2026-04-10T12:01:30Z")]
        text = render_sync_runs_history_text_fallback(runs=runs, config_id=42)
        assert "2026-04-10T12:00:00Z" in text
        assert "→" in text

    def test_no_timestamp_placeholder(self):
        runs = [_run(started_at=None, finished_at=None)]
        text = render_sync_runs_history_text_fallback(runs=runs, config_id=42)
        assert "(no timestamp)" in text

    def test_no_overflow_within_cap(self):
        runs = [_run(id_=i) for i in range(5)]
        text = render_sync_runs_history_text_fallback(runs=runs, config_id=42)
        assert "more run(s)" not in text
