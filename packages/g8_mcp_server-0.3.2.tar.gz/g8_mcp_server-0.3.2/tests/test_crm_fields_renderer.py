"""Tests for the CRM fields schema renderer (upgrade 4 — #19)."""

from __future__ import annotations

from g8_mcp_server import app_renderer
from g8_mcp_server.app_renderer import (
    _crm_field_type_color,
    _sort_crm_fields,
    render_crm_fields_schema_html,
    render_crm_fields_schema_text_fallback,
)


def _field(
    name: str = "email",
    label: str | None = "Email",
    type_: str | None = "email",
    is_required: bool | None = False,
    is_custom: bool | None = False,
) -> dict:
    return {
        "name": name,
        "label": label,
        "type": type_,
        "is_required": is_required,
        "is_custom": is_custom,
    }


# ---------------------------------------------------------------------------
# _crm_field_type_color
# ---------------------------------------------------------------------------


class TestCrmFieldTypeColor:
    def test_string(self):
        c = _crm_field_type_color("string")
        assert c["fg"] == "#7d2df3"

    def test_text_same_as_string(self):
        c = _crm_field_type_color("text")
        assert c["fg"] == "#7d2df3"

    def test_number_blue(self):
        c = _crm_field_type_color("number")
        assert c["fg"] == "#1e40af"

    def test_integer_blue(self):
        c = _crm_field_type_color("integer")
        assert c["fg"] == "#1e40af"

    def test_boolean_amber(self):
        c = _crm_field_type_color("boolean")
        assert c["fg"] == "#92400e"

    def test_enum_purple(self):
        c = _crm_field_type_color("enum")
        assert c["fg"] == "#6b21a8"

    def test_picklist_purple(self):
        c = _crm_field_type_color("picklist")
        assert c["fg"] == "#6b21a8"

    def test_email_teal(self):
        c = _crm_field_type_color("email")
        assert c["fg"] == "#0f766e"

    def test_phone_teal(self):
        c = _crm_field_type_color("phone")
        assert c["fg"] == "#0f766e"

    def test_date_green(self):
        # Backported to graph8 token 2026-04-21
        c = _crm_field_type_color("date")
        assert c["fg"] == "#059669"  # _G8_POSITIVE_FG

    def test_datetime_green(self):
        c = _crm_field_type_color("datetime")
        assert c["fg"] == "#059669"  # _G8_POSITIVE_FG

    def test_timestamp_green(self):
        c = _crm_field_type_color("timestamp")
        assert c["fg"] == "#059669"  # _G8_POSITIVE_FG

    def test_no_banned_fg_hexes(self):
        banned = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}
        from mcp_server.g8_mcp_server.app_renderer import _CRM_FIELD_TYPE_COLORS
        for k, v in _CRM_FIELD_TYPE_COLORS.items():
            assert v["fg"].lower() not in banned, (
                f"type={k!r} fg={v['fg']!r} is banned"
            )

    def test_unknown_default(self):
        c = _crm_field_type_color("mystery")
        assert c["fg"] == "#777777"

    def test_none(self):
        c = _crm_field_type_color(None)
        assert c["fg"] == "#777777"

    def test_case_insensitive(self):
        c = _crm_field_type_color("EMAIL")
        assert c["fg"] == "#0f766e"


# ---------------------------------------------------------------------------
# _sort_crm_fields
# ---------------------------------------------------------------------------


class TestSortCrmFields:
    def test_empty(self):
        assert _sort_crm_fields([]) == []

    def test_required_first(self):
        items = [
            _field(name="notes", is_required=False),
            _field(name="email", is_required=True),
        ]
        result = _sort_crm_fields(items)
        assert result[0]["name"] == "email"
        assert result[1]["name"] == "notes"

    def test_required_standard_before_required_custom(self):
        """Within required, standard sorts before custom."""
        items = [
            _field(name="custom_x", is_required=True, is_custom=True, label="Custom X"),
            _field(name="email", is_required=True, is_custom=False, label="Email"),
        ]
        result = _sort_crm_fields(items)
        assert result[0]["name"] == "email"
        assert result[1]["name"] == "custom_x"

    def test_optional_standard_before_optional_custom(self):
        items = [
            _field(name="custom_y", is_required=False, is_custom=True, label="Custom Y"),
            _field(name="phone", is_required=False, is_custom=False, label="Phone"),
        ]
        result = _sort_crm_fields(items)
        assert result[0]["name"] == "phone"
        assert result[1]["name"] == "custom_y"

    def test_alphabetical_within_group(self):
        items = [
            _field(name="zulu", is_required=True, label="Zulu"),
            _field(name="alpha", is_required=True, label="Alpha"),
            _field(name="mike", is_required=True, label="Mike"),
        ]
        result = _sort_crm_fields(items)
        names = [f["name"] for f in result]
        assert names == ["alpha", "mike", "zulu"]

    def test_label_fallback_to_name(self):
        """Fields without label should sort by name."""
        items = [
            _field(name="zzz", label=None),
            _field(name="aaa", label=None),
        ]
        result = _sort_crm_fields(items)
        assert result[0]["name"] == "aaa"
        assert result[1]["name"] == "zzz"

    def test_full_ordering_chain(self):
        """All four groups correctly interleaved."""
        items = [
            _field(name="opt_custom", is_required=False, is_custom=True, label="Opt Custom"),
            _field(name="opt_std", is_required=False, is_custom=False, label="Opt Std"),
            _field(name="req_custom", is_required=True, is_custom=True, label="Req Custom"),
            _field(name="req_std", is_required=True, is_custom=False, label="Req Std"),
        ]
        result = _sort_crm_fields(items)
        names = [f["name"] for f in result]
        assert names == ["req_std", "req_custom", "opt_std", "opt_custom"]


# ---------------------------------------------------------------------------
# render_crm_fields_schema_html
# ---------------------------------------------------------------------------


class TestRenderCrmFieldsSchemaHtml:
    def test_empty_list_returns_empty_state(self):
        html_out = render_crm_fields_schema_html(fields=[], provider="hubspot")
        assert "No fields available" in html_out

    def test_none_returns_empty_state(self):
        html_out = render_crm_fields_schema_html(fields=None, provider="hubspot")
        assert "No fields available" in html_out

    def test_non_list_returns_empty_state(self):
        html_out = render_crm_fields_schema_html(fields="junk", provider="hubspot")  # type: ignore[arg-type]
        assert "No fields available" in html_out

    def test_only_garbage_returns_empty_state(self):
        html_out = render_crm_fields_schema_html(
            fields=["x", 1, None],  # type: ignore[list-item]
            provider="hubspot",
        )
        assert "No fields available" in html_out

    def test_renders_basic_field(self):
        fields = [_field(name="email", label="Email", type_="email")]
        html_out = render_crm_fields_schema_html(fields=fields, provider="hubspot")
        assert "Email" in html_out
        assert "email" in html_out

    def test_provider_in_header(self):
        fields = [_field()]
        html_out = render_crm_fields_schema_html(fields=fields, provider="hubspot")
        assert "HubSpot" in html_out

    def test_provider_unknown_title_case(self):
        fields = [_field()]
        html_out = render_crm_fields_schema_html(fields=fields, provider="freshsales")
        assert "Freshsales" in html_out

    def test_entity_type_in_header(self):
        fields = [_field()]
        html_out = render_crm_fields_schema_html(
            fields=fields, provider="hubspot", entity_type="companies"
        )
        assert "Companies" in html_out

    def test_default_entity_type(self):
        fields = [_field()]
        html_out = render_crm_fields_schema_html(fields=fields, provider="hubspot")
        assert "Contacts" in html_out

    def test_field_counts_in_subhead(self):
        fields = [
            _field(name="a", is_required=True),
            _field(name="b", is_required=True, is_custom=True),
            _field(name="c"),
        ]
        html_out = render_crm_fields_schema_html(fields=fields, provider="hubspot")
        assert "3 field(s)" in html_out
        assert "2 required" in html_out
        assert "1 custom" in html_out

    def test_required_badge_rendered(self):
        fields = [_field(is_required=True)]
        html_out = render_crm_fields_schema_html(fields=fields, provider="hubspot")
        assert "field-required" in html_out
        assert "required" in html_out.lower()

    def test_custom_badge_rendered(self):
        fields = [_field(is_custom=True)]
        html_out = render_crm_fields_schema_html(fields=fields, provider="hubspot")
        assert "field-custom" in html_out

    def test_no_required_badge_when_optional(self):
        """Optional fields should not have the required badge span."""
        fields = [_field(is_required=False, is_custom=False)]
        html_out = render_crm_fields_schema_html(fields=fields, provider="hubspot")
        assert '<span class="field-required"' not in html_out

    def test_name_subtitle_when_different_from_label(self):
        fields = [_field(name="hs_email_id", label="Email")]
        html_out = render_crm_fields_schema_html(fields=fields, provider="hubspot")
        assert "<code>hs_email_id</code>" in html_out

    def test_no_name_subtitle_when_same_as_label(self):
        fields = [_field(name="email", label="email")]
        html_out = render_crm_fields_schema_html(fields=fields, provider="hubspot")
        assert "<code>email</code>" not in html_out

    def test_type_chip_rendered(self):
        fields = [_field(type_="boolean")]
        html_out = render_crm_fields_schema_html(fields=fields, provider="hubspot")
        assert "field-type" in html_out
        assert "boolean" in html_out

    def test_unnamed_field_placeholder(self):
        """Field with no name and no label should show '(unnamed)'."""
        fields = [{"type": "string"}]
        html_out = render_crm_fields_schema_html(fields=fields, provider="hubspot")
        assert "(unnamed)" in html_out

    def test_html_escaped_in_label(self):
        fields = [_field(label="<script>bad</script>")]
        html_out = render_crm_fields_schema_html(fields=fields, provider="hubspot")
        assert "<script>bad" not in html_out
        assert "&lt;script&gt;" in html_out

    def test_html_escaped_in_type(self):
        fields = [_field(type_="<svg>")]
        html_out = render_crm_fields_schema_html(fields=fields, provider="hubspot")
        assert "<svg>" not in html_out
        assert "&lt;svg&gt;" in html_out

    def test_required_sorts_first_in_render(self):
        fields = [
            _field(name="b_optional", label="B Optional", is_required=False),
            _field(name="a_required", label="A Required", is_required=True),
        ]
        html_out = render_crm_fields_schema_html(fields=fields, provider="hubspot")
        req_pos = html_out.find("A Required")
        opt_pos = html_out.find("B Optional")
        assert 0 < req_pos < opt_pos

    def test_cap_enforced(self):
        fields = [
            _field(name=f"field_{i}", label=f"Label {i}")
            for i in range(app_renderer._MAX_CRM_FIELDS_RENDERED + 5)
        ]
        html_out = render_crm_fields_schema_html(fields=fields, provider="hubspot")
        assert "5 field(s) omitted" in html_out

    def test_no_overflow_footer_within_cap(self):
        fields = [_field(name=f"f_{i}") for i in range(20)]
        html_out = render_crm_fields_schema_html(fields=fields, provider="hubspot")
        assert "omitted" not in html_out

    def test_non_dict_items_filtered(self):
        fields = [_field(name="a"), "garbage", None, _field(name="b")]  # type: ignore[list-item]
        html_out = render_crm_fields_schema_html(fields=fields, provider="hubspot")
        assert "2 field(s)" in html_out

    def test_long_label_truncated(self):
        long_label = "X" * (app_renderer._MAX_CRM_FIELD_LABEL_LEN + 100)
        fields = [_field(label=long_label)]
        html_out = render_crm_fields_schema_html(fields=fields, provider="hubspot")
        assert long_label not in html_out

    def test_no_provider_fallback(self):
        fields = [_field()]
        html_out = render_crm_fields_schema_html(fields=fields, provider=None)
        assert "CRM" in html_out


# ---------------------------------------------------------------------------
# render_crm_fields_schema_text_fallback
# ---------------------------------------------------------------------------


class TestRenderCrmFieldsSchemaTextFallback:
    def test_empty_list(self):
        text = render_crm_fields_schema_text_fallback(fields=[], provider="hubspot")
        assert "No fields available" in text

    def test_none(self):
        text = render_crm_fields_schema_text_fallback(fields=None, provider="hubspot")
        assert "No fields available" in text

    def test_non_list(self):
        text = render_crm_fields_schema_text_fallback(fields="junk", provider="hubspot")  # type: ignore[arg-type]
        assert "No fields available" in text

    def test_only_garbage_items(self):
        text = render_crm_fields_schema_text_fallback(
            fields=["a", 1],  # type: ignore[list-item]
            provider="hubspot",
        )
        assert "No fields available" in text

    def test_provider_label(self):
        fields = [_field()]
        text = render_crm_fields_schema_text_fallback(fields=fields, provider="salesforce")
        assert "Salesforce" in text

    def test_entity_type(self):
        fields = [_field()]
        text = render_crm_fields_schema_text_fallback(
            fields=fields, provider="hubspot", entity_type="deals"
        )
        assert "Deals" in text

    def test_default_entity_type(self):
        fields = [_field()]
        text = render_crm_fields_schema_text_fallback(fields=fields, provider="hubspot")
        assert "Contacts" in text

    def test_counts_summary_line(self):
        fields = [
            _field(is_required=True),
            _field(is_custom=True),
        ]
        text = render_crm_fields_schema_text_fallback(fields=fields, provider="hubspot")
        assert "2 field(s)" in text
        assert "1 required" in text
        assert "1 custom" in text

    def test_required_flag(self):
        fields = [_field(is_required=True)]
        text = render_crm_fields_schema_text_fallback(fields=fields, provider="hubspot")
        assert "[required]" in text

    def test_custom_flag(self):
        fields = [_field(is_custom=True)]
        text = render_crm_fields_schema_text_fallback(fields=fields, provider="hubspot")
        assert "[custom]" in text

    def test_both_flags(self):
        fields = [_field(is_required=True, is_custom=True)]
        text = render_crm_fields_schema_text_fallback(fields=fields, provider="hubspot")
        assert "[required, custom]" in text

    def test_type_angle_bracketed(self):
        fields = [_field(type_="string")]
        text = render_crm_fields_schema_text_fallback(fields=fields, provider="hubspot")
        assert "<string>" in text

    def test_name_suffix_when_different(self):
        fields = [_field(name="hs_email_id", label="Email")]
        text = render_crm_fields_schema_text_fallback(fields=fields, provider="hubspot")
        assert "Email (hs_email_id)" in text

    def test_no_name_suffix_when_same(self):
        fields = [_field(name="email", label="email")]
        text = render_crm_fields_schema_text_fallback(fields=fields, provider="hubspot")
        # Should not have "email (email)" duplication
        assert "(email)" not in text

    def test_cap_overflow_message(self):
        fields = [
            _field(name=f"f_{i}")
            for i in range(app_renderer._MAX_CRM_FIELDS_RENDERED + 3)
        ]
        text = render_crm_fields_schema_text_fallback(fields=fields, provider="hubspot")
        assert "and 3 more field(s)" in text

    def test_no_overflow_within_cap(self):
        fields = [_field(name=f"f_{i}") for i in range(10)]
        text = render_crm_fields_schema_text_fallback(fields=fields, provider="hubspot")
        assert "more field(s)" not in text

    def test_provider_none_fallback(self):
        fields = [_field()]
        text = render_crm_fields_schema_text_fallback(fields=fields, provider=None)
        assert "CRM" in text
