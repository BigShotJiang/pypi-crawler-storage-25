"""Unit tests for surface #33 — audience-sync errors renderer.

Covers the helpers + renderers in app_renderer.py for the per-config
error list surface:

  g8://audience-syncs/{config_id}/errors
  g8://audience-syncs/{config_id}/errors.txt

Focus areas:
- normalize_message (first-line, length cap, None/empty/non-string)
- group (bucket by normalized message, count + first/last seen)
- clip_message (trimming, escape paths)
- stat_card (escape)
- empty_state (two modes: not-available vs zero-errors)
- render_html (label derivation, 4-stat grid, group section with
  counts + %, timeline with id + ts + message, overflow notes,
  drill-up, XSS escape, empty states)
- render_text_fallback (markdown mirror)
"""

from __future__ import annotations

import pytest

from g8_mcp_server.app_renderer import (
    _render_sync_errors_empty_state_html,
    _sync_errors_clip_message,
    _sync_errors_group,
    _sync_errors_normalize_message,
    _sync_errors_stat_card,
    render_sync_errors_html,
    render_sync_errors_text_fallback,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _sample_errors() -> list[dict]:
    return [
        {
            "id": 105,
            "started_at": "2026-04-20T12:00:00Z",
            "error_message": "Rate limit exceeded",
            "details": {},
        },
        {
            "id": 104,
            "started_at": "2026-04-20T11:30:00Z",
            "error_message": "Rate limit exceeded",
            "details": {},
        },
        {
            "id": 103,
            "started_at": "2026-04-20T10:00:00Z",
            "error_message": "Invalid credentials",
            "details": {},
        },
    ]


def _sample_config() -> dict:
    return {
        "id": 42,
        "name": "LinkedIn Custom Audience",
        "platform": "linkedin",
        "status": "active",
    }


# ---------------------------------------------------------------------------
# TestNormalizeMessage
# ---------------------------------------------------------------------------


class TestNormalizeMessage:
    def test_simple_string(self):
        assert _sync_errors_normalize_message("Rate limit exceeded") == "Rate limit exceeded"

    def test_strips_whitespace(self):
        assert _sync_errors_normalize_message("   Rate limit exceeded  ") == "Rate limit exceeded"

    def test_takes_first_line(self):
        msg = "Rate limit exceeded\nRetry after 60s\nRequest ID abc123"
        assert _sync_errors_normalize_message(msg) == "Rate limit exceeded"

    def test_empty_returns_placeholder(self):
        assert _sync_errors_normalize_message("") == "(no message)"

    def test_whitespace_only_returns_placeholder(self):
        assert _sync_errors_normalize_message("   ") == "(no message)"

    def test_newline_only_returns_placeholder(self):
        assert _sync_errors_normalize_message("\n\n\n") == "(no message)"

    def test_none_returns_placeholder(self):
        assert _sync_errors_normalize_message(None) == "(no message)"

    def test_non_string_returns_placeholder(self):
        assert _sync_errors_normalize_message(123) == "(no message)"  # type: ignore[arg-type]

    def test_long_message_truncated(self):
        msg = "x" * 500
        out = _sync_errors_normalize_message(msg)
        assert len(out) <= 121  # key limit + ellipsis
        assert out.endswith("…")

    def test_short_not_truncated(self):
        msg = "short"
        assert _sync_errors_normalize_message(msg) == "short"

    def test_preserves_case(self):
        assert _sync_errors_normalize_message("Upstream DOWN") == "Upstream DOWN"


# ---------------------------------------------------------------------------
# TestGroup
# ---------------------------------------------------------------------------


class TestGroup:
    def test_empty_list(self):
        assert _sync_errors_group([]) == []

    def test_single_error(self):
        groups = _sync_errors_group([
            {"id": 1, "started_at": "2026-04-20T12:00:00Z", "error_message": "x"}
        ])
        assert len(groups) == 1
        assert groups[0]["count"] == 1
        assert groups[0]["key"] == "x"

    def test_groups_by_normalized_message(self):
        errs = [
            {"id": 1, "started_at": "t1", "error_message": "A"},
            {"id": 2, "started_at": "t2", "error_message": "A"},
            {"id": 3, "started_at": "t3", "error_message": "B"},
        ]
        groups = _sync_errors_group(errs)
        assert len(groups) == 2
        counts = {g["key"]: g["count"] for g in groups}
        assert counts["A"] == 2
        assert counts["B"] == 1

    def test_tracks_last_seen(self):
        errs = [
            {"id": 1, "started_at": "2026-04-20T10:00:00Z", "error_message": "A"},
            {"id": 2, "started_at": "2026-04-20T12:00:00Z", "error_message": "A"},
        ]
        groups = _sync_errors_group(errs)
        assert groups[0]["last_seen"] == "2026-04-20T12:00:00Z"

    def test_tracks_first_seen(self):
        errs = [
            {"id": 1, "started_at": "2026-04-20T12:00:00Z", "error_message": "A"},
            {"id": 2, "started_at": "2026-04-20T10:00:00Z", "error_message": "A"},
        ]
        groups = _sync_errors_group(errs)
        assert groups[0]["first_seen"] == "2026-04-20T10:00:00Z"

    def test_tracks_sample_id(self):
        errs = [
            {"id": 77, "started_at": "t1", "error_message": "A"},
        ]
        groups = _sync_errors_group(errs)
        assert groups[0]["sample_id"] == 77

    def test_missing_timestamps_ok(self):
        errs = [
            {"id": 1, "error_message": "A"},
            {"id": 2, "error_message": "A"},
        ]
        groups = _sync_errors_group(errs)
        assert groups[0]["count"] == 2
        assert groups[0]["last_seen"] is None

    def test_missing_message_groups_as_no_message(self):
        errs = [
            {"id": 1, "started_at": "t1"},
            {"id": 2, "started_at": "t2", "error_message": None},
        ]
        groups = _sync_errors_group(errs)
        assert len(groups) == 1
        assert groups[0]["key"] == "(no message)"
        assert groups[0]["count"] == 2

    def test_filters_non_dict(self):
        errs = [
            {"id": 1, "error_message": "A"},
            "not-a-dict",  # type: ignore[list-item]
            None,  # type: ignore[list-item]
            {"id": 2, "error_message": "A"},
        ]
        groups = _sync_errors_group(errs)
        assert len(groups) == 1
        assert groups[0]["count"] == 2


# ---------------------------------------------------------------------------
# TestClipMessage
# ---------------------------------------------------------------------------


class TestClipMessage:
    def test_short_message_unchanged(self):
        assert _sync_errors_clip_message("short") == "short"

    def test_strips_whitespace(self):
        assert _sync_errors_clip_message("  padded  ") == "padded"

    def test_none_returns_placeholder(self):
        assert _sync_errors_clip_message(None) == "(no message)"

    def test_empty_returns_placeholder(self):
        assert _sync_errors_clip_message("") == "(no message)"

    def test_whitespace_returns_placeholder(self):
        assert _sync_errors_clip_message("    ") == "(no message)"

    def test_non_string_returns_placeholder(self):
        assert _sync_errors_clip_message(42) == "(no message)"  # type: ignore[arg-type]

    def test_long_message_truncated(self):
        msg = "a" * 500
        out = _sync_errors_clip_message(msg)
        assert len(out) <= 301
        assert out.endswith("…")

    def test_exactly_at_limit_not_truncated(self):
        msg = "x" * 300
        out = _sync_errors_clip_message(msg)
        assert out == msg


# ---------------------------------------------------------------------------
# TestStatCard
# ---------------------------------------------------------------------------


class TestStatCard:
    def test_label_and_value_present(self):
        html = _sync_errors_stat_card("Total", "42")
        assert "Total" in html
        assert "42" in html

    def test_escapes_label(self):
        html = _sync_errors_stat_card("<script>", "ok")
        assert "<script>" not in html
        assert "&lt;script&gt;" in html

    def test_escapes_value(self):
        html = _sync_errors_stat_card("Label", "<b>x</b>")
        assert "<b>x</b>" not in html

    def test_accent_applied(self):
        html = _sync_errors_stat_card("Total", "0", accent="#059669")
        assert "#059669" in html

    def test_no_accent_default(self):
        html = _sync_errors_stat_card("Total", "0", accent=None)
        assert "border-top" not in html


# ---------------------------------------------------------------------------
# TestEmptyState
# ---------------------------------------------------------------------------


class TestEmptyState:
    def test_zero_errors_is_celebratory(self):
        html = _render_sync_errors_empty_state_html(
            config_id="42", zero_errors=True
        )
        assert "No recent failures" in html
        assert "Great" in html

    def test_zero_errors_green_accent(self):
        html = _render_sync_errors_empty_state_html(
            config_id="42", zero_errors=True
        )
        assert "#059669" in html  # green

    def test_not_available_when_backend_missing(self):
        html = _render_sync_errors_empty_state_html(
            config_id="42", zero_errors=False
        )
        assert "not available" in html.lower()

    def test_contains_config_id(self):
        html = _render_sync_errors_empty_state_html(
            config_id="42_abc", zero_errors=False
        )
        assert "42_abc" in html

    def test_escapes_config_id(self):
        html = _render_sync_errors_empty_state_html(
            config_id="<id>", zero_errors=False
        )
        assert "<id>" not in html

    def test_no_double_escape(self):
        html = _render_sync_errors_empty_state_html(
            config_id="<id>", zero_errors=False
        )
        assert "&amp;lt;" not in html

    def test_empty_config_id_shows_unknown(self):
        html = _render_sync_errors_empty_state_html(
            config_id="", zero_errors=False
        )
        assert "(unknown)" in html


# ---------------------------------------------------------------------------
# TestRenderHtml
# ---------------------------------------------------------------------------


class TestRenderHtml:
    def test_contains_sync_label_from_config(self):
        html = render_sync_errors_html(
            errors=_sample_errors(),
            config_id="42",
            config=_sample_config(),
        )
        assert "LinkedIn Custom Audience" in html

    def test_generic_label_when_no_config(self):
        html = render_sync_errors_html(
            errors=_sample_errors(), config_id="42", config=None
        )
        assert "Audience sync" in html

    def test_total_badge_in_header(self):
        html = render_sync_errors_html(
            errors=_sample_errors(), config_id="42"
        )
        assert "3 TOTAL" in html

    def test_contains_config_id_in_header(self):
        html = render_sync_errors_html(
            errors=_sample_errors(), config_id="cfg_42"
        )
        assert "cfg_42" in html

    # Stat grid

    def test_four_stat_cards(self):
        html = render_sync_errors_html(
            errors=_sample_errors(), config_id="42"
        )
        assert html.count('class="stat-card"') == 4

    def test_stat_total_failures(self):
        html = render_sync_errors_html(
            errors=_sample_errors(), config_id="42"
        )
        assert "Total failures" in html

    def test_stat_unique_messages(self):
        html = render_sync_errors_html(
            errors=_sample_errors(), config_id="42"
        )
        assert "Unique messages" in html

    def test_stat_first_seen(self):
        html = render_sync_errors_html(
            errors=_sample_errors(), config_id="42"
        )
        assert "First seen" in html

    def test_stat_last_seen(self):
        html = render_sync_errors_html(
            errors=_sample_errors(), config_id="42"
        )
        assert "Last seen" in html

    def test_unique_messages_count_correct(self):
        # 2 unique messages in _sample_errors
        html = render_sync_errors_html(
            errors=_sample_errors(), config_id="42"
        )
        # Unique messages card should show "2"
        assert ">2<" in html  # inside a stat-value span

    # Error groups

    def test_group_header_shows_count(self):
        html = render_sync_errors_html(
            errors=_sample_errors(), config_id="42"
        )
        # "Rate limit exceeded" appeared twice
        assert "× 2" in html

    def test_group_percentage_shown(self):
        html = render_sync_errors_html(
            errors=_sample_errors(), config_id="42"
        )
        # 2/3 = 66%, 1/3 = 33%
        assert "(66%)" in html or "(67%)" in html
        assert "(33%)" in html

    def test_group_shows_message_key(self):
        html = render_sync_errors_html(
            errors=_sample_errors(), config_id="42"
        )
        assert "Rate limit exceeded" in html
        assert "Invalid credentials" in html

    def test_group_overflow_note(self):
        # Create 10 unique messages (limit is 6)
        errs = [
            {"id": i, "started_at": f"t{i}", "error_message": f"Message {i}"}
            for i in range(10)
        ]
        html = render_sync_errors_html(errors=errs, config_id="42")
        assert "4 more unique messages" in html

    def test_no_group_overflow_when_within_limit(self):
        errs = [
            {"id": i, "started_at": f"t{i}", "error_message": f"Message {i}"}
            for i in range(3)
        ]
        html = render_sync_errors_html(errors=errs, config_id="42")
        assert "more unique" not in html

    # Timeline

    def test_timeline_shows_each_error_id(self):
        html = render_sync_errors_html(
            errors=_sample_errors(), config_id="42"
        )
        assert "id: 105" in html
        assert "id: 104" in html
        assert "id: 103" in html

    def test_timeline_shows_timestamps(self):
        html = render_sync_errors_html(
            errors=_sample_errors(), config_id="42"
        )
        assert "2026-04-20T12:00:00Z" in html

    def test_timeline_overflow_note(self):
        errs = [
            {"id": i, "started_at": f"2026-04-20T{i:02d}:00:00Z", "error_message": "x"}
            for i in range(20)
        ]
        html = render_sync_errors_html(errors=errs, config_id="42")
        # limit 15, so 5 older
        assert "5 older failure" in html

    def test_no_timeline_overflow_when_within_limit(self):
        errs = [
            {"id": i, "started_at": f"t{i}", "error_message": "x"}
            for i in range(5)
        ]
        html = render_sync_errors_html(errors=errs, config_id="42")
        assert "older failure" not in html

    # Long message handling

    def test_long_message_clipped_in_timeline(self):
        errs = [{
            "id": 1,
            "started_at": "t",
            "error_message": "x" * 500,
        }]
        html = render_sync_errors_html(errors=errs, config_id="42")
        assert "x" * 400 not in html

    # XSS escape tests

    def test_escapes_error_message(self):
        errs = [{
            "id": 1,
            "started_at": "t",
            "error_message": "<script>alert(1)</script>",
        }]
        html = render_sync_errors_html(errors=errs, config_id="42")
        assert "<script>alert(1)</script>" not in html
        assert "&lt;script&gt;" in html

    def test_escapes_config_name(self):
        config = {"name": "<script>evil</script>"}
        html = render_sync_errors_html(
            errors=_sample_errors(), config_id="42", config=config
        )
        assert "<script>evil</script>" not in html

    def test_escapes_config_id_in_header(self):
        html = render_sync_errors_html(
            errors=_sample_errors(), config_id="<id>"
        )
        assert "<id>" not in html

    def test_escapes_error_id(self):
        errs = [{
            "id": "<script>",
            "started_at": "t",
            "error_message": "x",
        }]
        html = render_sync_errors_html(errors=errs, config_id="42")
        assert "<script>" not in html

    def test_no_double_escape(self):
        errs = [{"id": 1, "started_at": "t", "error_message": "<x>"}]
        html = render_sync_errors_html(errors=errs, config_id="42")
        assert "&amp;lt;" not in html

    def test_no_script_tags_emitted(self):
        html = render_sync_errors_html(
            errors=_sample_errors(), config_id="42"
        )
        assert "<script" not in html.lower()

    # Label derivation fallback chain

    def test_label_falls_back_to_platform(self):
        config = {"platform": "facebook"}
        html = render_sync_errors_html(
            errors=_sample_errors(), config_id="42", config=config
        )
        assert "facebook" in html

    def test_label_falls_back_to_audience_name(self):
        config = {"audience_name": "VIP Leads"}
        html = render_sync_errors_html(
            errors=_sample_errors(), config_id="42", config=config
        )
        assert "VIP Leads" in html

    def test_label_ignores_empty_name(self):
        config = {"name": "", "platform": "linkedin"}
        html = render_sync_errors_html(
            errors=_sample_errors(), config_id="42", config=config
        )
        assert "linkedin" in html

    # Empty state pathways

    def test_none_errors_returns_not_available(self):
        html = render_sync_errors_html(errors=None, config_id="42")
        assert "not available" in html.lower()

    def test_empty_errors_returns_no_failures(self):
        html = render_sync_errors_html(errors=[], config_id="42")
        assert "No recent failures" in html

    def test_only_non_dict_errors_returns_no_failures(self):
        html = render_sync_errors_html(
            errors=["not-a-dict", None, 42],  # type: ignore[list-item]
            config_id="42",
        )
        assert "No recent failures" in html

    # Drill-up

    def test_drill_up_overview(self):
        html = render_sync_errors_html(
            errors=_sample_errors(), config_id="42"
        )
        assert "g8://audience-syncs/42/overview" in html

    def test_drill_up_runs(self):
        html = render_sync_errors_html(
            errors=_sample_errors(), config_id="42"
        )
        assert "g8://audience-syncs/42/runs" in html

    def test_drill_up_trigger(self):
        html = render_sync_errors_html(
            errors=_sample_errors(), config_id="42"
        )
        assert "/trigger" in html

    # HTML structure sanity

    def test_is_full_document(self):
        html = render_sync_errors_html(
            errors=_sample_errors(), config_id="42"
        )
        assert html.startswith("<!DOCTYPE html>")
        assert html.rstrip().endswith("</html>")

    def test_has_title(self):
        html = render_sync_errors_html(
            errors=_sample_errors(), config_id="42"
        )
        assert "<title>" in html


# ---------------------------------------------------------------------------
# TestRenderTextFallback
# ---------------------------------------------------------------------------


class TestRenderTextFallback:
    def test_header_contains_label(self):
        text = render_sync_errors_text_fallback(
            errors=_sample_errors(),
            config_id="42",
            config=_sample_config(),
        )
        assert "LinkedIn" in text

    def test_lists_total_failures(self):
        text = render_sync_errors_text_fallback(
            errors=_sample_errors(), config_id="42"
        )
        assert "Total failures: 3" in text

    def test_lists_unique_messages(self):
        text = render_sync_errors_text_fallback(
            errors=_sample_errors(), config_id="42"
        )
        assert "Unique error messages: 2" in text

    def test_contains_first_and_last_seen(self):
        text = render_sync_errors_text_fallback(
            errors=_sample_errors(), config_id="42"
        )
        assert "First seen" in text
        assert "Last seen" in text

    def test_group_count_formatted(self):
        text = render_sync_errors_text_fallback(
            errors=_sample_errors(), config_id="42"
        )
        assert "× 2" in text

    def test_group_keys_in_output(self):
        text = render_sync_errors_text_fallback(
            errors=_sample_errors(), config_id="42"
        )
        assert "Rate limit exceeded" in text
        assert "Invalid credentials" in text

    def test_recent_failures_section(self):
        text = render_sync_errors_text_fallback(
            errors=_sample_errors(), config_id="42"
        )
        assert "## Recent failures" in text

    def test_timeline_lines_have_ts_and_id(self):
        text = render_sync_errors_text_fallback(
            errors=_sample_errors(), config_id="42"
        )
        assert "id=105" in text
        assert "2026-04-20T12:00:00Z" in text

    def test_multiline_message_joined(self):
        errs = [{
            "id": 1,
            "started_at": "t",
            "error_message": "line1\nline2",
        }]
        text = render_sync_errors_text_fallback(errors=errs, config_id="42")
        # Newlines in the timeline line should be replaced with marker
        # (clip_message keeps first 300 chars incl. newlines, then we join)
        assert "⏎" in text or "line1" in text

    def test_drill_up_listed(self):
        text = render_sync_errors_text_fallback(
            errors=_sample_errors(), config_id="42"
        )
        assert "g8://audience-syncs/42/overview" in text
        assert "g8://audience-syncs/42/runs" in text
        assert "/trigger" in text

    def test_none_errors_empty_state(self):
        text = render_sync_errors_text_fallback(errors=None, config_id="42")
        assert "Errors not available" in text

    def test_empty_errors_empty_state(self):
        text = render_sync_errors_text_fallback(errors=[], config_id="42")
        assert "No recent failures" in text

    def test_empty_state_includes_config_id(self):
        text = render_sync_errors_text_fallback(errors=None, config_id="cfg_99")
        assert "cfg_99" in text

    def test_empty_state_missing_id_shows_unknown(self):
        text = render_sync_errors_text_fallback(errors=None, config_id="")
        assert "(unknown)" in text

    def test_ends_with_newline(self):
        text = render_sync_errors_text_fallback(
            errors=_sample_errors(), config_id="42"
        )
        assert text.endswith("\n")

    def test_overflow_note_when_many_errors(self):
        errs = [
            {"id": i, "started_at": f"2026-04-20T{i:02d}:00:00Z", "error_message": "x"}
            for i in range(20)
        ]
        text = render_sync_errors_text_fallback(errors=errs, config_id="42")
        assert "older failures" in text

    def test_group_overflow_when_many_unique(self):
        errs = [
            {"id": i, "started_at": f"t{i}", "error_message": f"Unique-{i}"}
            for i in range(10)
        ]
        text = render_sync_errors_text_fallback(errors=errs, config_id="42")
        assert "more unique messages" in text
