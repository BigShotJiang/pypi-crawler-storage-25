"""Tests for the ICP dashboard HTML + text renderers (upgrade 4 — surface #5).

Ensures:
- Empty / None input produces a valid empty-state document.
- Each ICP card renders name, total/priority/status badges, score trio,
  buying signals, firmographics, and tech stack.
- All user-controlled strings are HTML-escaped.
- Caps (`_MAX_ICPS_RENDERED`, `_MAX_ICP_SIGNALS_RENDERED`,
  `_MAX_ICP_REASON_LEN`) clamp runaway inputs.
- Plaintext mirror exposes the same essentials with no markup leak.
"""

from __future__ import annotations

from g8_mcp_server import app_renderer
from g8_mcp_server.app_renderer import (
    _flatten_icp_facts,
    _format_icp_score,
    _icp_score_color,
    render_icp_dashboard_html,
    render_icp_dashboard_text_fallback,
)


def _icp(idx: int = 0, **overrides) -> dict:
    """Build a default ICP dict matching the `GET /api/v1/icps` shape."""
    base = {
        "id": f"icp_{idx}",
        "name": f"ICP {idx}",
        "description": f"Default description for ICP {idx}.",
        "firmographics": {
            "industry": "SaaS",
            "employee_count": "200-1000",
            "revenue_range": "$10M-$100M",
        },
        "tech_stack": {
            "crm": "Salesforce",
            "marketing": ["HubSpot", "Marketo"],
        },
        "buying_signals": ["Hiring SDRs", "Series B funding", "New exec team"],
        "fit_score": 85,
        "opportunity_score": 72,
        "readiness_score": 60,
        "total_score": 76,
        "status": "active",
        "pinned": False,
        "priority": "P1",
        "created_at": "2026-01-01",
        "updated_at": "2026-04-01",
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


class TestIcpScoreColor:
    def test_none_returns_gray(self):
        assert _icp_score_color(None) == "#777777"

    def test_invalid_returns_gray(self):
        assert _icp_score_color("not-a-number") == "#777777"
        assert _icp_score_color([]) == "#777777"

    def test_buckets(self):
        # Backported to graph8 _G8_POSITIVE_FG 2026-04-21 (was banned #166534)
        assert _icp_score_color(95) == "#059669"  # _G8_POSITIVE_FG (>=80)
        assert _icp_score_color(80) == "#059669"
        assert _icp_score_color(70) == "#4d7c0f"  # lime (>=60)
        assert _icp_score_color(55) == "#b45309"  # amber (>=40)
        assert _icp_score_color(10) == "#b91c1c"  # red (<40)

    def test_score_color_no_banned_hexes(self):
        # Lock: no banned Studio hex from any score bucket
        banned = {"#1d4ed8", "#166534", "#991b1b", "#0891b2"}
        for score in (0, 10, 20, 40, 55, 60, 70, 79, 80, 95, 100):
            assert _icp_score_color(score).lower() not in banned
        assert _icp_score_color(None).lower() not in banned
        assert _icp_score_color("x").lower() not in banned


class TestFormatIcpScore:
    def test_none_is_dash(self):
        assert _format_icp_score(None) == "—"

    def test_invalid_is_dash(self):
        assert _format_icp_score("abc") == "—"
        assert _format_icp_score([]) == "—"

    def test_whole_numbers_are_ints(self):
        assert _format_icp_score(80) == "80"
        assert _format_icp_score(80.0) == "80"

    def test_decimals_formatted_one_digit(self):
        assert _format_icp_score(75.5) == "75.5"
        assert _format_icp_score(75.55) == "75.5"  # rounds, doesn't overflow


class TestFlattenIcpFacts:
    def test_none_or_empty(self):
        assert _flatten_icp_facts(None) == []
        assert _flatten_icp_facts({}) == []
        assert _flatten_icp_facts("not a dict") == []  # type: ignore[arg-type]

    def test_simple_key_value(self):
        result = _flatten_icp_facts({"industry": "SaaS", "size": "Mid-market"})
        assert ("Industry", "SaaS") in result
        assert ("Size", "Mid-market") in result

    def test_key_prettification(self):
        result = _flatten_icp_facts({"employee_count": "200-1000"})
        assert result[0][0] == "Employee Count"

    def test_list_values_joined(self):
        result = _flatten_icp_facts({"tags": ["a", "b", "c"]})
        assert result[0][1] == "a, b, c"

    def test_long_lists_truncated(self):
        result = _flatten_icp_facts({"tags": [str(i) for i in range(10)]})
        assert "+5" in result[0][1]

    def test_none_and_empty_skipped(self):
        result = _flatten_icp_facts({"a": None, "b": "", "c": [], "d": "ok"})
        labels = [r[0] for r in result]
        assert labels == ["D"]

    def test_nested_dict_preview(self):
        result = _flatten_icp_facts({"config": {"k1": "v1", "k2": "v2"}})
        assert "k1: v1" in result[0][1]

    def test_max_items_cap(self):
        big = {f"key_{i}": f"val_{i}" for i in range(10)}
        result = _flatten_icp_facts(big, max_items=3)
        assert len(result) == 3


# ---------------------------------------------------------------------------
# HTML renderer
# ---------------------------------------------------------------------------


class TestRenderIcpDashboardHtml:
    def test_empty_input_renders_empty_state(self):
        html_out = render_icp_dashboard_html(icps=None)
        assert "<!doctype html>" in html_out
        assert "No ICPs configured" in html_out

        html_out2 = render_icp_dashboard_html(icps=[])
        assert "No ICPs configured" in html_out2

    def test_non_list_input_renders_empty_state(self):
        html_out = render_icp_dashboard_html(icps="not a list")  # type: ignore[arg-type]
        assert "No ICPs configured" in html_out

    def test_non_dict_entries_filtered(self):
        html_out = render_icp_dashboard_html(icps=[None, "string", 42, _icp()])  # type: ignore[list-item]
        assert "ICP 0" in html_out

    def test_all_dict_garbage_renders_empty(self):
        html_out = render_icp_dashboard_html(icps=[None, "x", 1])  # type: ignore[list-item]
        assert "No ICPs configured" in html_out

    def test_renders_single_icp(self):
        html_out = render_icp_dashboard_html(icps=[_icp()])
        assert "ICP 0" in html_out
        assert "Total 76" in html_out

    def test_renders_scores(self):
        html_out = render_icp_dashboard_html(icps=[_icp()])
        assert "Fit" in html_out
        assert "Opportunity" in html_out
        assert "Readiness" in html_out
        assert "85" in html_out
        assert "72" in html_out
        assert "60" in html_out

    def test_renders_priority_and_status_badges(self):
        html_out = render_icp_dashboard_html(
            icps=[_icp(priority="P0", status="draft")]
        )
        assert "Priority P0" in html_out
        assert "draft" in html_out

    def test_pinned_star_rendered(self):
        html_out = render_icp_dashboard_html(icps=[_icp(pinned=True)])
        assert "★" in html_out

        html_no_pin = render_icp_dashboard_html(icps=[_icp(pinned=False)])
        assert "★" not in html_no_pin

    def test_description_section_rendered(self):
        html_out = render_icp_dashboard_html(
            icps=[_icp(description="Well-funded B2B SaaS teams.")]
        )
        assert "Description" in html_out
        assert "Well-funded B2B SaaS teams." in html_out

    def test_buying_signals_rendered(self):
        html_out = render_icp_dashboard_html(
            icps=[_icp(buying_signals=["Hiring SDRs", "Series C"])]
        )
        assert "Hiring SDRs" in html_out
        assert "Series C" in html_out

    def test_firmographics_and_tech_rendered(self):
        html_out = render_icp_dashboard_html(icps=[_icp()])
        assert "Firmographics" in html_out
        assert "Industry" in html_out
        assert "SaaS" in html_out
        assert "Tech stack" in html_out
        assert "Salesforce" in html_out

    def test_org_label_in_title(self):
        html_out = render_icp_dashboard_html(icps=[_icp()], org_label="Acme Inc")
        assert "Acme Inc" in html_out

    def test_missing_scores_render_dash(self):
        html_out = render_icp_dashboard_html(
            icps=[_icp(
                fit_score=None,
                opportunity_score=None,
                readiness_score=None,
                total_score=None,
            )]
        )
        assert "Total —" in html_out

    def test_missing_firmographics_no_section(self):
        """If firmographics is empty/None, the section shouldn't render."""
        html_out = render_icp_dashboard_html(
            icps=[_icp(firmographics=None, tech_stack=None)]
        )
        # Description + scores still there, but Firmographics header should not.
        assert "Firmographics" not in html_out
        assert "Tech stack" not in html_out


class TestEscaping:
    def test_name_escaped(self):
        html_out = render_icp_dashboard_html(
            icps=[_icp(name="<script>evil</script>")]
        )
        assert "<script>evil</script>" not in html_out
        assert "&lt;script&gt;" in html_out

    def test_description_escaped(self):
        html_out = render_icp_dashboard_html(
            icps=[_icp(description="<img src=x onerror=alert(1)>")]
        )
        assert "onerror=alert(1)" not in html_out or "&lt;img" in html_out

    def test_signals_escaped(self):
        html_out = render_icp_dashboard_html(
            icps=[_icp(buying_signals=["<b>xss</b>"])]
        )
        assert "<b>xss</b>" not in html_out
        assert "&lt;b&gt;" in html_out

    def test_org_label_escaped(self):
        html_out = render_icp_dashboard_html(
            icps=[_icp()], org_label="<script>"
        )
        assert "<script>" not in html_out.replace("<script>evil</script>", "")
        assert "&lt;script&gt;" in html_out

    def test_firmographics_key_escaped(self):
        html_out = render_icp_dashboard_html(
            icps=[_icp(firmographics={"<evil>": "value"})]
        )
        assert "<evil>" not in html_out


class TestBounds:
    def test_max_icps_rendered(self):
        """Exceed the cap, verify footer warns and cards are truncated."""
        icps = [_icp(idx=i, name=f"ICP_unique_{i}") for i in range(30)]
        html_out = render_icp_dashboard_html(icps=icps)
        assert "ICP_unique_0" in html_out
        assert "ICP_unique_25" not in html_out  # past cap 20
        assert "omitted" in html_out

    def test_max_signals_rendered(self):
        signals = [f"signal_{i}" for i in range(20)]
        html_out = render_icp_dashboard_html(icps=[_icp(buying_signals=signals)])
        assert "signal_0" in html_out
        # First 6 shown
        assert "signal_5" in html_out
        # 7th onwards NOT shown as a pill
        assert "signal_15" not in html_out

    def test_long_description_truncated(self):
        long_desc = "x" * 5000
        html_out = render_icp_dashboard_html(icps=[_icp(description=long_desc)])
        # Truncation marker
        assert "…" in html_out
        # Full 5000-char string not dumped
        assert "x" * 1000 not in html_out


# ---------------------------------------------------------------------------
# Text fallback
# ---------------------------------------------------------------------------


class TestIcpDashboardTextFallback:
    def test_empty_input(self):
        out = render_icp_dashboard_text_fallback(icps=None)
        assert "No ICPs configured" in out

        out2 = render_icp_dashboard_text_fallback(icps=[])
        assert "No ICPs configured" in out2

    def test_non_list_input(self):
        out = render_icp_dashboard_text_fallback(icps="nope")  # type: ignore[arg-type]
        assert "No ICPs configured" in out

    def test_renders_key_fields(self):
        out = render_icp_dashboard_text_fallback(icps=[_icp()])
        assert "ICP 0" in out
        assert "Total: 76" in out
        assert "Priority: P1" in out
        assert "fit=85" in out
        assert "opportunity=72" in out
        assert "readiness=60" in out

    def test_buying_signals_listed(self):
        out = render_icp_dashboard_text_fallback(
            icps=[_icp(buying_signals=["Sig A", "Sig B"])]
        )
        assert "Sig A" in out
        assert "Sig B" in out

    def test_firmographics_and_tech_listed(self):
        out = render_icp_dashboard_text_fallback(icps=[_icp()])
        assert "Firmographics:" in out
        assert "Tech stack:" in out
        assert "Industry" in out
        assert "Salesforce" in out

    def test_pinned_marker(self):
        out = render_icp_dashboard_text_fallback(icps=[_icp(pinned=True)])
        assert "★" in out

    def test_no_markup_leaked(self):
        out = render_icp_dashboard_text_fallback(
            icps=[_icp(name="<tag>", buying_signals=["<sig>"])]
        )
        # Plaintext preserves raw strings — that's fine, but the document
        # itself must not contain HTML wrappers.
        assert "<html>" not in out
        assert "<body>" not in out

    def test_max_cap_in_text(self):
        icps = [_icp(idx=i) for i in range(30)]
        out = render_icp_dashboard_text_fallback(icps=icps)
        assert "more ICP(s)" in out

    def test_org_label_in_heading(self):
        out = render_icp_dashboard_text_fallback(icps=[_icp()], org_label="Acme")
        assert "# ICPs — Acme" in out


# ---------------------------------------------------------------------------
# Sanity-check the cap constants exist (guard against accidental removal)
# ---------------------------------------------------------------------------


class TestCapsExist:
    def test_constants(self):
        assert app_renderer._MAX_ICPS_RENDERED >= 1
        assert app_renderer._MAX_ICP_SIGNALS_RENDERED >= 1
        assert app_renderer._MAX_ICP_REASON_LEN >= 100
